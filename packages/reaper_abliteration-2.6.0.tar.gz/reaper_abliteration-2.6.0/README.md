# Reaper Abliteration

[![PyPI](https://img.shields.io/pypi/v/reaper-abliteration)](https://pypi.org/project/reaper-abliteration/)
[![License: PolyForm Noncommercial](https://img.shields.io/badge/License-PolyForm%20NC-purple.svg)](https://polyformproject.org/licenses/noncommercial/1.0.0/)

Remove censorship from LLMs. No training, no fine-tuning, no manual parameter selection.

Reaper finds and removes the internal "refusal subspace" of transformer models using directional ablation with automatic parameter optimization. Point it at a model, walk away, come back to an uncensored version that retains the original model's capabilities.

```bash
pip install -U reaper-abliteration
abliterate Qwen/Qwen3-4B-Instruct-2507
```

That's it. Reaper handles batch size detection, refusal direction computation, multi-objective optimization, and Pareto-optimal trial selection automatically.

## What Makes Reaper Different

Most abliteration tools remove a single direction from a few weight matrices and call it done. Reaper goes further:

**Continuous per-component LayerEnvelope optimization** -- Each ablation target gets its own 4-parameter bell curve (`peak`, `peak_position`, `floor`, `floor_distance`) that produces a smooth per-layer ablation strength multiplier. This is not binary skip/include -- it's a continuous function the optimizer uses to precisely control how aggressively each layer is ablated. With 4-6 independent components (attn.o_proj, mlp.down_proj, mlp.gate_proj, mlp.up_proj, linear_attn.out_proj, plus fused expert hooks), Reaper optimizes 18-26 Optuna dimensions simultaneously. Competitors typically have 2 component types with binary layer masks.

**Float direction interpolation** -- In global mode, `layer_focus` is a continuous float (not an integer layer index). Reaper lerps between adjacent layer directions and re-normalizes, so the optimizer can smoothly blend directions from any position in the network -- not just pick one layer.

**Supervised direction extraction** -- Instead of naive mean-difference, Reaper can extract refusal directions via Fisher LDA (`--lda-direction`) or LEACE (`--leace-direction`, provably optimal linear concept erasure from [Belrose et al. 2023](https://arxiv.org/abs/2306.03819)). These methods separate refusal signal from topic shift, producing cleaner directions. Directions are then gradient-optimized against actual model behavior with RDO (`--rdo-refine`).

**Subspace-level ablation** -- Refusal is not a single vector -- it's a manifold. Rank-k ablation (`--ablation-rank`) extracts a k-dimensional refusal subspace via SVD and removes the entire thing. With `--som-directions`, Reaper clusters harmful activations via KMeans to discover distinct refusal modes (hard refusal, safety lectures, consequence warnings, crisis hotline redirects) and targets each independently.

**MoE-native ablation** -- Fused MoE expert parameters (single 3D tensor shared across experts) can't use LoRA. Reaper uses activation-space hooks post-routing, with expert-aware scaling that lets the optimizer target refusal-mediating experts. Hook ablation and LoRA ablation coexist in the same trial. Automatic super expert detection (3-sigma outlier in routing weights) protects the 2-3 critical experts per layer whose removal causes model collapse.

**Capability-aware ablation** -- The weight-SVD stability guard identifies the most important dimensions of each weight matrix (via truncated SVD) and projects refusal directions away from them. Concept atoms / SRA (`--concept-atoms`) orthogonalize the refusal direction against capability-probing directions (math, code, reasoning) to preserve what the model is good at, rather than hoping for the best.

**Sparse, targeted modification** -- After computing what to change, Reaper zeros out low-impact entries via `--sparsity-threshold`, so the actual weight modification touches as few dimensions as necessary. Less collateral damage, better capability retention.

**Multi-layered refusal detection** -- Five detection layers work together: keyword matching, lecture pattern detection, degenerate output detection (trigram frequency analysis, 40% threshold), semantic embedding similarity, and Minos-v1 neural classifier (`--minos-refusal-detection`). The neural classifier overrides keyword matching when they disagree, eliminating false positives from words like "sorry" in compliant responses.

**Multi-token capability measurement** -- Single-token KL divergence misses a lot. Reaper measures divergence over multiple autoregressive tokens using teacher-forcing (`--kl-tokens`), catching capability damage that superficial metrics miss.

**4-pool prompt architecture** -- Four distinct prompt pools: `safe_prompts` and `harmful_prompts` for direction extraction, `safe_eval_prompts` and `harmful_eval_prompts` for Optuna evaluation. Training/test split prevents overfitting to the evaluation set. All four pools are independently configurable.

**FP8 model support** -- Reaper abliterates FP8 quantized models (e.g. Qwen3.5-122B-A10B-FP8). When native FP8 kernels are broken (common on Blackwell SM 12.0), it auto-dequantizes to BF16 via monkey-patching. Export supports FP8 streaming merge -- per-module GPU-side dequantization that keeps RAM usage low for 100B+ parameter models.

**Automatic everything** -- Up to 1000 trials of TPE optimization with live Pareto front tracking, progressive evaluation for 2-4x speedup, seed parameter persistence across runs, multi-GPU data parallelism with proportional batch splitting for asymmetric GPU setups, 4-bit quantization support, and a real-time dashboard with clipboard copy.

## Installation

Requires Python 3.10+ with PyTorch 2.2+ configured for your hardware.

```bash
pip install -U reaper-abliteration
```

## Usage

### Minimal

```bash
abliterate <model_id>
```

Reaper will:
1. Benchmark your hardware and pick an optimal batch size
2. Compute per-layer refusal directions from harmless/harmful prompt datasets
3. Run 200 optimization trials with a live terminal dashboard
4. Present Pareto-optimal results (refusals vs KL divergence)
5. Let you save, upload to HuggingFace, or chat-test the result

### With advanced features

```bash
abliterate --projected-direction --partial-projection \
  --adaptive-layer-selection --use-pca-directions --rdo-refine \
  --iterative-refinement --winsorize-residuals 0.05 --kl-tokens 3 <model>
```

### Multi-GPU

**Data parallelism** -- model fits on each GPU, batches split across them (fastest):

```bash
abliterate --multi-gpu <model>
```

**Pipeline parallelism** -- model too large for one GPU, layers split across devices:

```bash
CUDA_VISIBLE_DEVICES=0,1 abliterate <large_model>
```

**Asymmetric GPUs** -- different VRAM sizes (e.g. 96GB + 48GB):

```bash
CUDA_VISIBLE_DEVICES=0,1 abliterate --max-memory '{"0": "90GB", "1": "42GB"}' <large_model>
```

### FP8 & Quantized Models

FP8 models (like Qwen3.5-122B-A10B-FP8) are detected automatically from the model config. Reaper dequantizes FP8 weights to BF16 before wrapping with LoRA, then offers FP8 streaming merge at export time.

```bash
abliterate Qwen/Qwen3.5-122B-A10B-FP8
```

4-bit quantization via bitsandbytes for large models on limited VRAM:

```bash
abliterate --quantization bnb_4bit <large_model>
```

### Blackwell GPU Support

Blackwell GPUs (RTX PRO 6000, etc.) have two known issues that Reaper handles automatically:

1. **BF16 P2P DMA bug** -- cross-GPU transfers corrupt data. Reaper probes each GPU pair at init and patches broken pairs with CPU-staged fallback.
2. **fla GatedDeltaNet Triton kernel bug** -- the TMEM hoist compilation pass produces garbage on SM 12.0. Reaper disables the pass via import nullification.

No user intervention needed. If you still see garbage on multi-GPU Blackwell, force the workaround:

```bash
abliterate --force-p2p-cpu-staging <model>
```

### Reasoning Models

Models with `<think>` blocks (DeepSeek-R1, QwQ, o1-style):

```bash
abliterate --model-type reasoning deepseek-ai/DeepSeek-R1-Distill-Qwen-7B
```

CoT prefix stripping, thinking block detection, and configurable delimiters are handled automatically.

### Configuration

All options work as CLI flags, environment variables (`REAPER_` prefix), or `reaper.toml`:

```toml
model = "Qwen/Qwen3-4B-Instruct-2507"
trials = 300
ablation_rank = 3
weight_svd_guard = true
norm_preserve = true
partial_projection = true
kl_tokens = 3
multi_gpu = true
```

Run `abliterate --help` for the full option list.

## Core Concepts

### The Optimization Loop

Each trial samples a set of ablation parameters -- per-component LayerEnvelope parameters, direction indices, layer selection thresholds -- applies them to the model via LoRA adapters, then evaluates refusal count and KL divergence. Optuna's TPE sampler learns which regions of parameter space produce good tradeoffs.

LoRA adapters make trials fast -- resetting between trials zeros the adapter weights and removes activation hooks instead of reloading the model.

### LayerEnvelope: Per-Component Ablation Curves

Each transformer component (attn.o_proj, mlp.down_proj, mlp.gate_proj, mlp.up_proj, etc.) gets its own `LayerEnvelope` -- a 4-parameter continuous bell curve:

| Parameter | Controls |
|-----------|----------|
| `peak` | Maximum ablation strength at the center |
| `peak_position` | Which layer gets peak ablation (float, optimized) |
| `floor` | Minimum ablation strength at the edges (as ratio of peak) |
| `floor_distance` | How many layers from peak before ablation drops to zero |

The optimizer independently tunes all 4 parameters for each component. For a model with 5 component types, that's 20 dimensions just for the LayerEnvelopes, plus `layer_focus`, direction blend mode, and optional per-head masks. Total search space: 18-26 Optuna dimensions.

Layers outside `floor_distance` from `peak_position` are skipped entirely (no ablation applied). This means Reaper can learn that attention layers need aggressive ablation in layers 20-30 while MLP down-projections need gentle ablation across layers 15-35 -- all within the same trial.

### Refusal Directions

Reaper computes per-layer "refusal directions" from residual activations. The default mean-difference approach works well for most models. For harder targets, `--lda-direction` uses Fisher LDA to separate refusal signal from topic shift, and `--leace-direction` uses provably optimal linear concept erasure. For hybrid architectures (e.g. DeltaNet + attention), Reaper automatically extracts separate directions per layer type.

With `--use-pca-directions`, Reaper extracts additional directions via contrastive PCA -- a generalized eigenvalue decomposition that finds axes maximizing harmful variance relative to harmless variance (Cholesky-whitened). This captures refusal-specific signal rather than general activation variance.

With `--ablation-rank > 1`, Reaper extracts the top-k directions via SVD of the centered difference matrix, capturing the full refusal subspace rather than just its centroid.

With `--som-directions`, Reaper clusters harmful residual deviations per-layer via KMeans (inspired by [Zhang et al. 2025](https://arxiv.org/abs/2511.08379)) to discover multiple refusal modes -- keyword refusal, safety lectures, consequence warnings, crisis hotline redirects -- as distinct directions. A greedy diversity selection ensures the chosen directions are maximally different from each other.

With `--iterative-refinement`, Reaper runs a two-pass pipeline: first applying a fixed-strength rank-1 ablation probe to identify which prompts still refuse, then re-extracting residuals through the ablated model from only those resistant prompts to discover secondary refusal circuits that the mean direction misses. The stacked directions are then jointly optimized at rank-2.

With `--rdo-refine`, Reaper gradient-optimizes the refusal direction against actual model behavior before the main optimization loop. Starting from the statistical mean direction, it runs projected gradient descent on the unit sphere -- minimizing refusal token probability on harmful prompts while preserving KL divergence on harmless prompts. The RDO seed is random by default and cached with directions for reproducibility; use `--rdo-seed N` to pin it.

### Weight Modification

For each transformer component, Reaper orthogonalizes the weight matrix against the refusal direction(s):

```
delta_W = -lambda * V^T (V @ W)    # rank-k projection removal
```

This is applied via LoRA adapters (`lora_A = V @ W`, `lora_B = -lambda * V^T`), so the base weights are never modified until you export. For fused MoE experts (where LoRA can't be applied), activation-space hooks apply the equivalent projection post-routing.

### Progressive Evaluation

Most trials are bad. Reaper detects this early: a quick KL check on a subset of prompts prunes obviously-damaged trials before running the full (expensive) refusal evaluation. Trials that pass KL screening get progressively more expensive evaluation -- subset refusal scan, then full refusal count. This gives 2-4x speedup with no quality loss.

### Seed Management

Pareto-optimal parameters from prior runs are persisted as JSON seed files in `seed_params/`. On subsequent runs, these seeds are enqueued as early Optuna trials, giving the optimizer a warm start from known-good regions. Atomic writes via tempfile+rename prevent corruption during concurrent runs.

## Export Formats

After optimization, Reaper offers multiple export strategies:

| Format | Flag/Option | Use case |
|--------|-------------|----------|
| **Safetensors merge** | `Merge full model` | Standard full-weight export. Base weights + LoRA delta merged on CPU. |
| **LoRA adapter** | `Save LoRA adapter only` | Lightweight ~10MB adapter. Merge later with llama.cpp or PEFT. |
| **GGUF** | `Export as GGUF` | Merge + convert via llama.cpp. Supports Q4_K_M, Q5_K_M, Q8_0, F16, BF16. |
| **GGUF + LoRA** | `GGUF + LoRA adapter` | Base model as GGUF + ablation as separate LoRA GGUF. Ablation signal survives quantization. |
| **FP8 streaming merge** | Auto for FP8 models | GPU-side per-module dequant to BF16. Low RAM for 100B+ FP8 models. |
| **MXFP4 dequant merge** | When hooks detected | Reload + bake activation hooks into weights for MXFP4 models. |
| **Ablation recipe** | Auto-saved as sidecar | JSON + safetensors with hook parameters. Reproducible via `Model.apply_ablation_recipe()`. |
| **HuggingFace upload** | Interactive prompt | Direct push with auto-generated model card. Vision encoder weights re-attached for VLMs. |

## Feature Reference

### Direction Refinement

| Flag | What it does |
|------|-------------|
| `--use-pca-directions` | Contrastive PCA: extract directions maximizing harmful vs harmless variance |
| `--combine-directions` | Let optimizer weight-combine mean + PCA directions |
| `--projected-direction` | Gram-Schmidt orthogonalize refusal against harmless direction |
| `--concept-atoms` | SRA: orthogonalize against capability-probing directions (math, code, reasoning) |
| `--concept-atom-ridge F` | Ridge regularization for SRA (default: 0.1) |
| `--som-directions` | Cluster harmful residuals to find multiple refusal modes (keyword, lecture, redirect) |
| `--som-clusters N` | Number of KMeans clusters for SOM direction finding (default: 16) |
| `--iterative-refinement` | Two-pass: find secondary refusal circuits after initial rank-1 ablation |
| `--deep-ablation` | Filtered iterative refinement -- re-extract only from still-refusing prompts |
| `--rdo-refine` | Gradient-optimize direction via first-token logit loss (projected GD on unit sphere) |
| `--rdo-seed N` | Fixed RDO seed for reproducibility (random if unset, cached with directions) |
| `--rdo-steps N` | Number of RDO gradient steps (default: 100) |
| `--rdo-lr F` | RDO learning rate (default: 0.01) |
| `--rdo-kl-weight F` | KL penalty weight for RDO (default: 1.0) |
| `--winsorize-residuals F` | Clamp residual magnitudes at this quantile before direction extraction (default: 0.0 = off) |
| `--multi-position-residuals` | Gather residuals at positions [-1, -2, -3] for richer direction estimation |
| `--lda-direction` | Fisher LDA supervised direction estimation |
| `--leace-direction` | LEACE provably optimal linear concept erasure |

### Ablation Control

| Flag | What it does |
|------|-------------|
| `--ablation-rank N` | LoRA rank / number of refusal directions to remove (default: 1) |
| `--weight-svd-guard` | Protect top singular vectors of each weight matrix from ablation |
| `--svd-guard-rank N` | Number of singular vectors to protect (default: 3) |
| `--sparsity-threshold F` | Zero low-magnitude ablation entries; Optuna tunes 0.01-0.5 (default: 0.0 = off) |
| `--norm-preserve` | Rescale weight rows to original L2 norms after ablation |
| `--partial-projection` | Let Optuna tune removal strength 0.1-1.0 instead of full removal |
| `--adaptive-layer-selection` | COSMIC layer scoring: skip layers with low causal refusal signal |
| `--per-head-ablation` | Target specific attention heads (optimizer picks which) |

### Evaluation

| Flag | What it does |
|------|-------------|
| `--kl-tokens N` | Multi-token KL divergence via teacher-forcing (default: 1) |
| `--semantic-refusal-detection` | Embedding similarity instead of keyword matching |
| `--lecture-refusal-detection` | Detect compliant refusals (safety lectures, consequence warnings) |
| `--minos-refusal-detection` | Minos-v1 neural refusal classifier (overrides keyword matching) |
| `--harmful-dataset-preset P` | Override harmful prompts with a preset (`mlabonne`, `strongreject`) |

### Hardware & Performance

| Flag | What it does |
|------|-------------|
| `--multi-gpu` | Data-parallel inference across GPUs (requires model fits on each GPU) |
| `--gpu-devices 0,1` | Restrict to specific GPUs |
| `--max-memory '{"0":"90GB","1":"42GB"}'` | Per-GPU VRAM budget for asymmetric setups (e.g. mixing 96GB + 48GB cards) |
| `--force-p2p-cpu-staging` | Skip P2P probe, force CPU-staged transfers between all GPU pairs (Blackwell DMA workaround) |
| `--quantization bnb_4bit` | 4-bit quantization for large models |
| `--use-gradient-checkpointing` | Trade compute for 60-80% VRAM reduction |
| `--batch-size N` | Manual batch size (0 = auto) |

### Optimization

| Flag | What it does |
|------|-------------|
| `--trials N` | Number of optimization trials (default: 200) |
| `--warmup-trials N` | Random exploration before TPE kicks in (default: 60) |
| `--use-seed-params / --no-use-seed-params` | Load/skip Pareto-optimal seeds from prior runs |
| `--dashboard / --no-dashboard` | Live terminal dashboard |
| `--routing-analysis` | MoE expert routing diagnostic with super expert detection |

## Research Tools

Included in the base install.

**Residual plots** (`--save-plots`): PaCMAP 2D projections of per-layer residual vectors for harmful vs harmless prompts. Generates per-layer PNGs and an animated GIF.

**Residual geometry** (`--show-geometry`): Quantitative table of cosine similarities, norms, and silhouette scores between harmful/harmless residuals at each layer.

## Technical Details

### Ablation Pipeline

```
1. Extract residuals for harmful + harmless prompts (4-pool architecture)
   + Multi-position: gather at [-1, -2, -3] token positions
   + Winsorize: clamp residual magnitudes at quantile threshold
2. Compute per-layer refusal directions (mean diff, LDA, or LEACE)
   + Layer-type-aware extraction for hybrid architectures (DeltaNet + attention)
   + SOM clustering: KMeans on harmful deviations -> diverse refusal modes
3. Refine: project out harmless, orthogonalize against capability atoms (SRA)
4. RDO: gradient-optimize direction via first-token logit loss
5. COSMIC layer scoring: causal cosine-similarity scores per layer
6. Iterative refinement: rank-1 pass -> re-extract -> secondary direction
7. For each trial:
   a. Zero LoRA adapters + remove activation hooks (fast reset)
   b. Sample parameters: per-component LayerEnvelopes (4 dims each),
      direction scope (global/per-layer), layer_focus (float lerp),
      head masks, projection strength, sparsity threshold
   c. For each weight matrix:
      i.   [optional] SVD guard: project directions away from top singular vectors
      ii.  Compute LoRA: lora_A = V @ W, lora_B = -lambda * V^T
      iii. [optional] Sparsity: zero entries below threshold * max(|lora_A|)
      iv.  [optional] Norm preserve: adjust lora_B so row norms match original W
      v.   Write LoRA adapter weights
   d. For fused MoE experts:
      i.   Register activation-space hooks post-routing
      ii.  Apply expert-aware scaling (0.0 for super experts, 1.0 for others)
   e. Evaluate: progressive KL -> subset refusal -> full refusal + degenerate detection
   f. Record to Pareto front, update seeds
8. Present Pareto-optimal trials for selection
9. Export: merge/adapter/GGUF/FP8-stream + ablation recipe sidecar
```

### Supported Architectures

- **Dense transformers**: Llama, Mistral, Qwen, Gemma, Phi, GPT-style (c_fc/c_proj), Falcon, and others
- **Mixture-of-experts**: Qwen-MoE, Phi-MoE, Granite-MoE, gpt-oss fused experts, Mixtral block-sparse
- **Hybrid architectures**: DeltaNet + attention (e.g. Qwen3.5), with per-layer-type direction extraction and frequency-based Optuna range scaling for rare components
- **FP8 quantized models**: Block-scaled FP8 (Qwen3.5-122B-A10B-FP8), FBGEMM per-row FP8. Auto-dequant to BF16 for LoRA, FP8 streaming merge for export.
- **Multimodal models**: Vision-language with `AutoModelForImageTextToText`. Vision encoder weights preserved during export and re-attached.
- **Reasoning models**: CoT prefix stripping, thinking block detection, configurable delimiters (`<think>` blocks)
- **4-bit quantized**: BitsAndBytes NF4/FP4 with dequant-on-CPU merge at export

Not yet supported: pure SSMs (Mamba, RWKV without attention layers).

## References

This project builds on research by:

- Arditi et al. 2024 -- [Refusal in Language Models Is Mediated by a Single Direction](https://arxiv.org/abs/2406.11717)
- Labonne 2024 -- [Uncensor any LLM with abliteration](https://huggingface.co/blog/mlabonne/abliteration)
- Lai 2024 -- [Projected Abliteration](https://huggingface.co/blog/grimjim/projected-abliteration)
- Pres et al. 2025 -- [Surgical Refusal Ablation](https://arxiv.org/abs/2601.08489)
- Ibrahim 2025 -- [Gabliteration: Norm-Preserving Biprojected Abliteration](https://arxiv.org/abs/2512.18901)
- Li et al. 2025 -- [COSMIC: Causal Layer Scoring](https://arxiv.org/abs/2506.00085)
- Chen et al. 2025 -- [The Geometry of Refusal in LLMs (RDO)](https://arxiv.org/abs/2502.17420)
- Zhang et al. 2025 -- [SOM-Based Multi-Directional Refusal Suppression](https://arxiv.org/abs/2511.08379)
- Belrose et al. 2023 -- [LEACE: Perfect Linear Concept Erasure](https://arxiv.org/abs/2306.03819)

## License

Copyright 2025-2026 HauhauCS (hauhaut901@gmail.com)

PolyForm Noncommercial 1.0.0 -- free for personal, research, and non-commercial use. Commercial use requires a separate license. See [LICENSE](LICENSE) for details. Contact hauhaut901@gmail.com for commercial licensing.
