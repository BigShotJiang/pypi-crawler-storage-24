"""garantipay -- Python client for the Garanti BBVA Virtual POS (GVP) API.

A modern, fully-typed Python library for integrating with the Garanti BBVA
Virtual POS payment gateway. Supports sales, refunds, voids, and 3D Secure
transactions.

Quick Start
-----------

**High-level API** (recommended)::

    from garantipay import GarantiClient

    client = GarantiClient(
        terminal_id="12345678",
        merchant_id="1234567",
        prov_user_id="PROVAUT",
        user_id="99999999999",
        password="123qweASD*",
        mode="TEST",
    )

    response = client.sale(
        card_number="1234567890123456",
        card_expire_date="0326",
        card_cvv2="123",
        amount="100",
        customer_ip="1.2.3.4",
    )

    if response.is_successful:
        print("Payment approved!")

**Low-level API** (full control)::

    from garantipay import API, Request, Terminal, Customer, Transaction
    from garantipay.hash import compute_hash_data

    api = API()
    request = Request(mode="TEST", version="v1.0")
    # ... populate all fields manually ...
    response = api.transaction(request)

Classes
-------

.. autosummary::

    GarantiClient
    API
    Request
    Response
    Card
    Customer
    Terminal
    Transaction
    Order
    Address
    AddressList
    Secure3D

Constants
---------

.. autosummary::

    CURRENCIES
    ENDPOINTS

Exceptions
----------

All exceptions inherit from :class:`~garantipay.exceptions.GarantiPayError`.

.. autosummary::

    GarantiPayError
    GarantiPayConnectionError
    GarantiPayAPIError
    GarantiPayValidationError
    GarantiPayXMLError
"""

__version__ = "1.0.0"

from garantipay.client import API, GarantiClient
from garantipay.constants import CURRENCIES, ENDPOINTS
from garantipay.exceptions import (
    GarantiPayAPIError,
    GarantiPayConnectionError,
    GarantiPayError,
    GarantiPayValidationError,
    GarantiPayXMLError,
)
from garantipay.hash import compute_hash_data, compute_password_hash, sha1
from garantipay.models import (
    Address,
    AddressList,
    Card,
    Customer,
    Order,
    Request,
    Response,
    ResponseTransaction,
    RewardInqResult,
    Secure3D,
    Terminal,
    Transaction,
    TransactionResponse,
)
from garantipay.xml_parser import response_to_pretty_xml

__all__ = [
    # Version
    "__version__",
    # Clients
    "GarantiClient",
    "API",
    # Request models
    "Request",
    "Terminal",
    "Card",
    "Customer",
    "Order",
    "AddressList",
    "Address",
    "Transaction",
    "Secure3D",
    # Response models
    "Response",
    "TransactionResponse",
    "ResponseTransaction",
    "RewardInqResult",
    # Constants
    "CURRENCIES",
    "ENDPOINTS",
    # Hash utilities
    "sha1",
    "compute_hash_data",
    "compute_password_hash",
    # XML utilities
    "response_to_pretty_xml",
    # Exceptions
    "GarantiPayError",
    "GarantiPayConnectionError",
    "GarantiPayAPIError",
    "GarantiPayValidationError",
    "GarantiPayXMLError",
]
