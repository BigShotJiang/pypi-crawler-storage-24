"""Constants used throughout the garantipay library.

This module defines the API endpoints for Garanti BBVA Virtual POS
and ISO 4217 currency code mappings supported by the gateway.
"""

from typing import Dict

ENDPOINTS: Dict[str, str] = {
    "TEST": "https://sanalposprovtest.garantibbva.com.tr/VPServlet",
    "PROD": "https://sanalposprov.garanti.com.tr/VPServlet",
}
"""Mapping of environment mode to Garanti BBVA Virtual POS API endpoint URL.

- ``"TEST"``: Sandbox endpoint for development and integration testing.
- ``"PROD"``: Live production endpoint for real transactions.
"""

CURRENCIES: Dict[str, str] = {
    "TRY": "949",
    "YTL": "949",
    "TRL": "949",
    "TL": "949",
    "USD": "840",
    "EUR": "978",
    "GBP": "826",
    "JPY": "392",
}
"""Mapping of common currency abbreviations to their ISO 4217 numeric codes.

The Garanti BBVA GVP API requires ISO 4217 numeric codes (e.g. ``"949"``
for Turkish Lira). This dictionary allows you to look up the code using
familiar string abbreviations.

Multiple aliases are provided for Turkish Lira (``TRY``, ``YTL``, ``TRL``, ``TL``)
for convenience.

Example::

    >>> from garantipay import CURRENCIES
    >>> CURRENCIES["TRY"]
    '949'
    >>> CURRENCIES["USD"]
    '840'
"""
