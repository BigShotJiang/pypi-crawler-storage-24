from enum import Enum

class PostPublicAuthenticationCreateIframeTokenResponse400ErrorCode(str, Enum):
    ENVELOPE_NOT_FOUND = "ENVELOPE_NOT_FOUND"
    INVALID_REQUEST_FORMAT = "INVALID_REQUEST_FORMAT"
    RECIPIENT_VERIFICATION_DISABLED = "RECIPIENT_VERIFICATION_DISABLED"
    SIGNER_NOT_IN_ENVELOPE = "SIGNER_NOT_IN_ENVELOPE"
    WORKSPACE_NOT_FOUND = "WORKSPACE_NOT_FOUND"

    def __str__(self) -> str:
        return str(self.value)
