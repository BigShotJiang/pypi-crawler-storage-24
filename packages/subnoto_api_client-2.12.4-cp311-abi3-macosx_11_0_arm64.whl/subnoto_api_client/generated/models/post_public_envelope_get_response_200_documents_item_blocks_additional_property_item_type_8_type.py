from enum import Enum

class PostPublicEnvelopeGetResponse200DocumentsItemBlocksAdditionalPropertyItemType8Type(str, Enum):
    DROPDOWN = "dropdown"

    def __str__(self) -> str:
        return str(self.value)
