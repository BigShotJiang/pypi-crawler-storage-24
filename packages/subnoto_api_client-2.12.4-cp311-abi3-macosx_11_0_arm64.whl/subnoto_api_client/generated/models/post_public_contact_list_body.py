from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="PostPublicContactListBody")



@_attrs_define
class PostPublicContactListBody:
    """ 
        Attributes:
            workspace_uuid (str | Unset): Optional. When omitted, the team's default workspace is used.
            page (int | Unset): The page number (1-indexed). Defaults to 1. Each page contains up to 50 results. Default: 1.
            limit (int | Unset): The number of results per page. Defaults to 50, maximum is 50. Default: 50.
     """

    workspace_uuid: str | Unset = UNSET
    page: int | Unset = 1
    limit: int | Unset = 50
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        workspace_uuid = self.workspace_uuid

        page = self.page

        limit = self.limit


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if workspace_uuid is not UNSET:
            field_dict["workspaceUuid"] = workspace_uuid
        if page is not UNSET:
            field_dict["page"] = page
        if limit is not UNSET:
            field_dict["limit"] = limit

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        workspace_uuid = d.pop("workspaceUuid", UNSET)

        page = d.pop("page", UNSET)

        limit = d.pop("limit", UNSET)

        post_public_contact_list_body = cls(
            workspace_uuid=workspace_uuid,
            page=page,
            limit=limit,
        )


        post_public_contact_list_body.additional_properties = d
        return post_public_contact_list_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
