from enum import Enum

class PostPublicEnvelopeAddRecipientsBodyRecipientsItemType0Language(str, Enum):
    EN = "en"
    ES = "es"
    FI = "fi"
    FR = "fr"
    IT = "it"

    def __str__(self) -> str:
        return str(self.value)
