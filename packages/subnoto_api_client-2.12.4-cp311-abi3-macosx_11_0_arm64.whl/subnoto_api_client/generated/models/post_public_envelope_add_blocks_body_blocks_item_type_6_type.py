from enum import Enum

class PostPublicEnvelopeAddBlocksBodyBlocksItemType6Type(str, Enum):
    RADIO = "radio"

    def __str__(self) -> str:
        return str(self.value)
