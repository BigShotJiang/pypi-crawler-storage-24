from enum import Enum

class PostPublicEnvelopeAddRecipientsBodyRecipientsItemType1VerificationType(str, Enum):
    EMAIL = "email"
    NONE = "none"
    SMS = "sms"

    def __str__(self) -> str:
        return str(self.value)
