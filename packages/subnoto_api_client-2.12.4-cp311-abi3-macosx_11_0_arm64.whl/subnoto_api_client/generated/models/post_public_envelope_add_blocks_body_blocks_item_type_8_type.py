from enum import Enum

class PostPublicEnvelopeAddBlocksBodyBlocksItemType8Type(str, Enum):
    DROPDOWN = "dropdown"

    def __str__(self) -> str:
        return str(self.value)
