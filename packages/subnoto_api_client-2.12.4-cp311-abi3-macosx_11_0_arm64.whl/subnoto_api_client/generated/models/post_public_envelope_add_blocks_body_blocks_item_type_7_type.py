from enum import Enum

class PostPublicEnvelopeAddBlocksBodyBlocksItemType7Type(str, Enum):
    CHECKBOX = "checkbox"

    def __str__(self) -> str:
        return str(self.value)
