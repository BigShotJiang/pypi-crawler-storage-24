from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="PostPublicContactGetBody")



@_attrs_define
class PostPublicContactGetBody:
    """ 
        Attributes:
            email (str): The email of the contact.
            workspace_uuid (str | Unset): Optional. When omitted, the team's default workspace is used.
     """

    email: str
    workspace_uuid: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        email = self.email

        workspace_uuid = self.workspace_uuid


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "email": email,
        })
        if workspace_uuid is not UNSET:
            field_dict["workspaceUuid"] = workspace_uuid

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        workspace_uuid = d.pop("workspaceUuid", UNSET)

        post_public_contact_get_body = cls(
            email=email,
            workspace_uuid=workspace_uuid,
        )


        post_public_contact_get_body.additional_properties = d
        return post_public_contact_get_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
