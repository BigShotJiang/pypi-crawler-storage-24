from enum import Enum

class PostPublicEnvelopeGetResponse200DocumentsItemBlocksAdditionalPropertyItemType5Type(str, Enum):
    NUMBER = "number"

    def __str__(self) -> str:
        return str(self.value)
