from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="PostPublicEnvelopeGetDocumentResponse500ErrorDetailsItem")



@_attrs_define
class PostPublicEnvelopeGetDocumentResponse500ErrorDetailsItem:
    """ Single validation issue (e.g. from request body schema)

        Attributes:
            path (list[str]): JSON path to the invalid field
            message (str): Validation error message for this field
     """

    path: list[str]
    message: str





    def to_dict(self) -> dict[str, Any]:
        path = self.path



        message = self.message


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "path": path,
            "message": message,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        path = cast(list[str], d.pop("path"))


        message = d.pop("message")

        post_public_envelope_get_document_response_500_error_details_item = cls(
            path=path,
            message=message,
        )

        return post_public_envelope_get_document_response_500_error_details_item

