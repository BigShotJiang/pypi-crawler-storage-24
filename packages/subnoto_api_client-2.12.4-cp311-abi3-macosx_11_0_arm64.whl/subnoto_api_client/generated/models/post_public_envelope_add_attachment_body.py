from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field
import json
from .. import types

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="PostPublicEnvelopeAddAttachmentBody")



@_attrs_define
class PostPublicEnvelopeAddAttachmentBody:
    """ 
        Attributes:
            envelope_uuid (str): The UUID of the envelope to attach the document to.
            document_title (str): The title of the document attachment.
            file (Any): The file to attach (PDF, Word, ODT, or RTF document, max 11MB).
            workspace_uuid (str | Unset): Optional. When omitted, the team's default workspace is used.
     """

    envelope_uuid: str
    document_title: str
    file: Any
    workspace_uuid: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        envelope_uuid = self.envelope_uuid

        document_title = self.document_title

        file = self.file

        workspace_uuid = self.workspace_uuid


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "envelopeUuid": envelope_uuid,
            "documentTitle": document_title,
            "file": file,
        })
        if workspace_uuid is not UNSET:
            field_dict["workspaceUuid"] = workspace_uuid

        return field_dict


    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("envelopeUuid", (None, str(self.envelope_uuid).encode(), "text/plain")))



        files.append(("documentTitle", (None, str(self.document_title).encode(), "text/plain")))



        files.append(("file", (None, str(self.file).encode(), "text/plain")))



        if not isinstance(self.workspace_uuid, Unset):
            files.append(("workspaceUuid", (None, str(self.workspace_uuid).encode(), "text/plain")))




        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))



        return files


    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        envelope_uuid = d.pop("envelopeUuid")

        document_title = d.pop("documentTitle")

        file = d.pop("file")

        workspace_uuid = d.pop("workspaceUuid", UNSET)

        post_public_envelope_add_attachment_body = cls(
            envelope_uuid=envelope_uuid,
            document_title=document_title,
            file=file,
            workspace_uuid=workspace_uuid,
        )


        post_public_envelope_add_attachment_body.additional_properties = d
        return post_public_envelope_add_attachment_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
