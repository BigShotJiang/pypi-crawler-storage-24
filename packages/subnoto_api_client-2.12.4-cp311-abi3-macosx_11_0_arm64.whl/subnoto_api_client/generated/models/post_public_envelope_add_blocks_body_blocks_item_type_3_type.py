from enum import Enum

class PostPublicEnvelopeAddBlocksBodyBlocksItemType3Type(str, Enum):
    SIGNATURE = "signature"

    def __str__(self) -> str:
        return str(self.value)
