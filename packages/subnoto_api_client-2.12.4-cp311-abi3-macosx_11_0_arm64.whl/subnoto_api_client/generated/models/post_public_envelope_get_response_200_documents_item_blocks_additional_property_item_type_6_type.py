from enum import Enum

class PostPublicEnvelopeGetResponse200DocumentsItemBlocksAdditionalPropertyItemType6Type(str, Enum):
    RADIO = "radio"

    def __str__(self) -> str:
        return str(self.value)
