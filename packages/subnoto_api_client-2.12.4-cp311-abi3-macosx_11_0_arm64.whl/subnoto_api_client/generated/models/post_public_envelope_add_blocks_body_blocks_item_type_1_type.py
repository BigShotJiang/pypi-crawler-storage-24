from enum import Enum

class PostPublicEnvelopeAddBlocksBodyBlocksItemType1Type(str, Enum):
    TEXTINPUT = "textInput"

    def __str__(self) -> str:
        return str(self.value)
