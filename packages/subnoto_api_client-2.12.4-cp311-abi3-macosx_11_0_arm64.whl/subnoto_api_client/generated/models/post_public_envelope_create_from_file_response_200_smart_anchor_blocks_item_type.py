from enum import Enum

class PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItemType(str, Enum):
    DATE = "date"
    SIGNATURE = "signature"

    def __str__(self) -> str:
        return str(self.value)
