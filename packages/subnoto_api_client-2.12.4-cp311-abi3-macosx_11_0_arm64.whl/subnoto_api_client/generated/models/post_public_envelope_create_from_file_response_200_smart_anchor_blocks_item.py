from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_blocks_item_type import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItemType






T = TypeVar("T", bound="PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItem")



@_attrs_define
class PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItem:
    """ 
        Attributes:
            uuid (str):
            type_ (PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItemType):
            page_number (float):
            recipient_email (str):
            recipient_label (str):
            x (float):
            y (float):
            width (float):
            height (float):
     """

    uuid: str
    type_: PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItemType
    page_number: float
    recipient_email: str
    recipient_label: str
    x: float
    y: float
    width: float
    height: float





    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        type_ = self.type_.value

        page_number = self.page_number

        recipient_email = self.recipient_email

        recipient_label = self.recipient_label

        x = self.x

        y = self.y

        width = self.width

        height = self.height


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "uuid": uuid,
            "type": type_,
            "pageNumber": page_number,
            "recipientEmail": recipient_email,
            "recipientLabel": recipient_label,
            "x": x,
            "y": y,
            "width": width,
            "height": height,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid")

        type_ = PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItemType(d.pop("type"))




        page_number = d.pop("pageNumber")

        recipient_email = d.pop("recipientEmail")

        recipient_label = d.pop("recipientLabel")

        x = d.pop("x")

        y = d.pop("y")

        width = d.pop("width")

        height = d.pop("height")

        post_public_envelope_create_from_file_response_200_smart_anchor_blocks_item = cls(
            uuid=uuid,
            type_=type_,
            page_number=page_number,
            recipient_email=recipient_email,
            recipient_label=recipient_label,
            x=x,
            y=y,
            width=width,
            height=height,
        )

        return post_public_envelope_create_from_file_response_200_smart_anchor_blocks_item

