"""Comando de estatísticas."""

from __future__ import annotations

import typer
from rich.console import Console

from tecjustica_cli.client import MCPClient
from tecjustica_cli.formatting import format_stats

console = Console()


def _get_json_mode(ctx: typer.Context) -> bool:
    return ctx.obj.get("json", False) if ctx.obj else False


def register_estatisticas(app: typer.Typer) -> None:
    """Registra comandos de estatísticas no app principal."""

    @app.command()
    def stats_docs(
        ctx: typer.Context,
        cnj: str = typer.Argument(help="Número CNJ do processo"),
        fonte: str | None = typer.Option(None, "--fonte", "-f", help="Filtrar por fonte"),
    ) -> None:
        """Estatísticas de documentos de um processo."""
        client = MCPClient()
        args: dict = {"numero_processo": cnj}
        if fonte:
            args["fonte"] = fonte
        with console.status("Calculando estatísticas..."):
            result = client.call_tool("stats_documentos", args)
        format_stats(result, json_mode=_get_json_mode(ctx))
