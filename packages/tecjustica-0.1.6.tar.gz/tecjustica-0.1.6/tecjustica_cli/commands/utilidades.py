"""Comandos utilitários — calculadora, data/hora, whoami."""

from __future__ import annotations

import typer
from rich.console import Console

from tecjustica_cli.client import MCPClient
from tecjustica_cli.formatting import format_calculadora, format_generic, format_whoami

console = Console()


def _get_json_mode(ctx: typer.Context) -> bool:
    return ctx.obj.get("json", False) if ctx.obj else False


def register_utilidades(app: typer.Typer) -> None:
    """Registra comandos utilitários no app principal."""

    @app.command()
    def calc(
        ctx: typer.Context,
        modo: str = typer.Argument(help="Modo: expressao ou prazo"),
        expressao: str | None = typer.Option(
            None, "--expressao", "-e", help="Expressão matemática"
        ),
        data_intimacao: str | None = typer.Option(
            None, "--data-intimacao", help="Data da intimação (ISO 8601)"
        ),
        dias: int | None = typer.Option(None, "--dias", "-d", help="Número de dias do prazo"),
    ) -> None:
        """Calculadora de expressões e prazos processuais."""
        client = MCPClient()
        args: dict = {"modo": modo}
        if expressao:
            args["expressao"] = expressao
        if data_intimacao:
            args["data_intimacao"] = data_intimacao
        if dias is not None:
            args["dias"] = dias
        with console.status("Calculando..."):
            result = client.call_tool("calculadora", args)
        format_calculadora(result, json_mode=_get_json_mode(ctx))

    @app.command()
    def agora(
        ctx: typer.Context,
        timezone: str | None = typer.Option(
            None, "--timezone", "-tz", help="Timezone (ex: America/Sao_Paulo)"
        ),
    ) -> None:
        """Data e hora atual."""
        client = MCPClient()
        args: dict = {}
        if timezone:
            args["timezone"] = timezone
        result = client.call_tool("data_hora_atual", args)
        format_generic(result, json_mode=_get_json_mode(ctx))

    @app.command()
    def whoami(ctx: typer.Context) -> None:
        """Identidade do usuário autenticado."""
        client = MCPClient()
        with console.status("Verificando..."):
            result = client.call_tool("whoami")
        format_whoami(result, json_mode=_get_json_mode(ctx))
