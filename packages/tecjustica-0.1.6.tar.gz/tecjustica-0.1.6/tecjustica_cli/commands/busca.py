"""Comandos de busca — grep, glob, localizar."""

from __future__ import annotations

import typer
from rich.console import Console

from tecjustica_cli.client import MCPClient
from tecjustica_cli.formatting import format_documentos, format_grep_results

console = Console()


def _get_json_mode(ctx: typer.Context) -> bool:
    return ctx.obj.get("json", False) if ctx.obj else False


def register_busca(app: typer.Typer) -> None:
    """Registra comandos de busca no app principal."""

    @app.command()
    def grep_docs(
        ctx: typer.Context,
        padrao: str = typer.Argument(help="Padrão de busca textual"),
        processo: str = typer.Option(..., "--processo", "-p", help="Número CNJ do processo"),
        fonte: str | None = typer.Option(None, "--fonte", "-f", help="Filtrar por fonte"),
    ) -> None:
        """Buscar texto em documentos (full-text search).

        Exemplo: tecjustica grep-docs "dano moral" --processo 0000105-15.2017.8.06.0203
        """
        client = MCPClient()
        args: dict = {"numero_processo": processo, "padrao": padrao}
        if fonte:
            args["fonte"] = fonte
        with console.status("Buscando em documentos..."):
            result = client.call_tool("grep_documentos", args)
        format_grep_results(result, json_mode=_get_json_mode(ctx))

    @app.command()
    def grep_movs(
        ctx: typer.Context,
        padrao: str = typer.Argument(help="Padrão de busca textual"),
        processo: str = typer.Option(..., "--processo", "-p", help="Número CNJ do processo"),
        fonte: str | None = typer.Option(None, "--fonte", "-f", help="Filtrar por fonte"),
    ) -> None:
        """Buscar texto em movimentações (full-text search).

        Exemplo: tecjustica grep-movs "audiencia" --processo 0000105-15.2017.8.06.0203
        """
        client = MCPClient()
        args: dict = {"numero_processo": processo, "padrao": padrao}
        if fonte:
            args["fonte"] = fonte
        with console.status("Buscando em movimentações..."):
            result = client.call_tool("grep_movimentacoes", args)
        format_grep_results(result, json_mode=_get_json_mode(ctx))

    @app.command()
    def glob_docs(
        ctx: typer.Context,
        cnj: str = typer.Argument(help="Número CNJ do processo"),
        padrao: str = typer.Argument(help="Padrão de nome/tipo de documento"),
        fonte: str | None = typer.Option(None, "--fonte", "-f", help="Filtrar por fonte"),
    ) -> None:
        """Filtrar documentos por nome/tipo."""
        client = MCPClient()
        args: dict = {"numero_processo": cnj, "padrao_tipo": padrao}
        if fonte:
            args["fonte"] = fonte
        with console.status("Filtrando documentos..."):
            result = client.call_tool("glob_documentos", args)
        format_documentos(result, json_mode=_get_json_mode(ctx))

    @app.command()
    def localizar(
        ctx: typer.Context,
        doc_id: str = typer.Argument(help="ID do documento"),
        termo: str = typer.Argument(help="Termo a localizar"),
    ) -> None:
        """Localizar termo em documento (posições exatas)."""
        client = MCPClient()
        with console.status("Localizando..."):
            result = client.call_tool(
                "localizar_no_documento",
                {
                    "document_id": doc_id,
                    "termo": termo,
                },
            )
        format_grep_results(result, json_mode=_get_json_mode(ctx))
