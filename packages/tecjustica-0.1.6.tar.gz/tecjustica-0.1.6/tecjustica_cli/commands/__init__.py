"""Comandos CLI TecJustica."""
