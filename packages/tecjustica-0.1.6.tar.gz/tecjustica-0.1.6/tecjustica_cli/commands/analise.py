"""Comandos de análise — analisar, precedentes."""

from __future__ import annotations

import typer
from rich.console import Console

from tecjustica_cli.client import MCPClient
from tecjustica_cli.formatting import format_analise, format_precedentes

console = Console()


def _get_json_mode(ctx: typer.Context) -> bool:
    return ctx.obj.get("json", False) if ctx.obj else False


def register_analise(app: typer.Typer) -> None:
    """Registra comandos de análise no app principal."""

    @app.command()
    def analisar(
        ctx: typer.Context,
        cnj: str = typer.Argument(help="Número CNJ do processo"),
        pergunta: str = typer.Option(
            "Faça um resumo geral do processo", "--pergunta", "-q", help="Pergunta para análise"
        ),
        perspectiva: str | None = typer.Option(
            None, "--perspectiva", "-p", help="Perspectiva: autor, reu, juiz, etc."
        ),
    ) -> None:
        """Analisar processo com IA (Gemini Flash)."""
        client = MCPClient()
        args: dict = {"numero_processo": cnj, "pergunta": pergunta}
        if perspectiva:
            args["perspectiva"] = perspectiva
        with console.status("Analisando processo (pode levar alguns minutos)..."):
            result = client.call_tool("analisar", args)
        format_analise(result, json_mode=_get_json_mode(ctx))

    @app.command()
    def precedentes(
        ctx: typer.Context,
        busca: str = typer.Argument(help="Termo de busca para precedentes"),
        orgaos: str | None = typer.Option(None, "--orgaos", help="Órgãos (separados por vírgula)"),
        tipos: str | None = typer.Option(None, "--tipos", help="Tipos (separados por vírgula)"),
    ) -> None:
        """Buscar precedentes (súmulas, temas repetitivos, IRDR)."""
        client = MCPClient()
        args: dict = {"busca": busca}
        if orgaos:
            args["orgaos"] = [o.strip() for o in orgaos.split(",")]
        if tipos:
            args["tipos"] = [t.strip() for t in tipos.split(",")]
        with console.status("Buscando precedentes..."):
            result = client.call_tool("buscar_precedentes", args)
        format_precedentes(result, json_mode=_get_json_mode(ctx))
