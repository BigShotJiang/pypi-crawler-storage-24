"""Comandos de navegação — listar, visualizar, ler."""

from __future__ import annotations

import typer
from rich.console import Console

from tecjustica_cli.client import MCPClient
from tecjustica_cli.formatting import (
    format_documento_conteudo,
    format_documentos,
    format_movimentacoes,
    format_processos,
    format_visao_geral,
)

console = Console()


def _get_json_mode(ctx: typer.Context) -> bool:
    return ctx.obj.get("json", False) if ctx.obj else False


def register_navegacao(app: typer.Typer) -> None:
    """Registra comandos de navegação no app principal."""

    @app.command()
    def listar_processos(
        ctx: typer.Context,
        busca: str | None = typer.Option(None, "--busca", "-b", help="Buscar por parte/nome"),
    ) -> None:
        """Listar processos disponíveis."""
        client = MCPClient()
        args: dict = {}
        if busca:
            args["busca"] = busca
        with console.status("Consultando processos..."):
            result = client.call_tool("listar_processos", args)
        format_processos(result, json_mode=_get_json_mode(ctx))

    @app.command()
    def visao_geral(
        ctx: typer.Context,
        cnj: str = typer.Argument(help="Número CNJ do processo"),
    ) -> None:
        """Visão geral de um processo (metadados, partes, stats)."""
        client = MCPClient()
        with console.status("Carregando processo..."):
            result = client.call_tool("visao_geral_processo", {"numero_processo": cnj})
        format_visao_geral(result, json_mode=_get_json_mode(ctx))

    @app.command()
    def ls_docs(
        ctx: typer.Context,
        cnj: str = typer.Argument(help="Número CNJ do processo"),
        fonte: str | None = typer.Option(
            None, "--fonte", "-f", help="Filtrar por fonte (api/segmentation)"
        ),
        offset: int = typer.Option(0, "--offset", help="Offset para paginação"),
        limit: int = typer.Option(20, "--limit", "-l", help="Limite de resultados"),
    ) -> None:
        """Listar documentos de um processo."""
        client = MCPClient()
        args: dict = {"numero_processo": cnj, "offset": offset, "limite": limit}
        if fonte:
            args["fonte"] = fonte
        with console.status("Listando documentos..."):
            result = client.call_tool("ls_documentos", args)
        format_documentos(result, json_mode=_get_json_mode(ctx))

    @app.command()
    def ls_movs(
        ctx: typer.Context,
        cnj: str = typer.Argument(help="Número CNJ do processo"),
        fonte: str | None = typer.Option(None, "--fonte", "-f", help="Filtrar por fonte"),
        offset: int = typer.Option(0, "--offset", help="Offset para paginação"),
        limit: int = typer.Option(20, "--limit", "-l", help="Limite de resultados"),
    ) -> None:
        """Listar movimentações de um processo."""
        client = MCPClient()
        args: dict = {"numero_processo": cnj, "offset": offset, "limite": limit}
        if fonte:
            args["fonte"] = fonte
        with console.status("Listando movimentações..."):
            result = client.call_tool("ls_movimentacoes", args)
        format_movimentacoes(result, json_mode=_get_json_mode(ctx))

    @app.command()
    def read_doc(
        ctx: typer.Context,
        doc_id: str = typer.Argument(help="ID do documento"),
        offset: int = typer.Option(0, "--offset", help="Offset em caracteres"),
        max_chars: int = typer.Option(10000, "--max-chars", "-m", help="Máximo de caracteres"),
    ) -> None:
        """Ler conteúdo de um documento."""
        client = MCPClient()
        with console.status("Lendo documento..."):
            result = client.call_tool(
                "read_documento",
                {
                    "document_id": doc_id,
                    "offset": offset,
                    "max_chars": max_chars,
                },
            )
        format_documento_conteudo(result, json_mode=_get_json_mode(ctx))
