"""Comandos de autenticação."""

from __future__ import annotations

import typer
from rich.console import Console

from tecjustica_cli.client import AuthError, MCPClient
from tecjustica_cli.config import (
    SUPABASE_ANON_KEY,
    SUPABASE_URL,
    get_token,
    remove_token,
    save_token,
)

console = Console()
app = typer.Typer(help="Autenticação com o servidor TecJustica.")


@app.command()
def login(
    token: str | None = typer.Option(None, "--token", "-t", help="API key (tk_...) ou JWT direto"),
    email: str | None = typer.Option(None, "--email", "-e", help="Email Supabase (login direto)"),
    password: str | None = typer.Option(
        None, "--password", "-p", help="Senha Supabase (login direto)"
    ),
) -> None:
    """Autenticar via navegador (padrão), token ou credenciais.

    Sem argumentos: abre o navegador para login seguro via OAuth.
    Com --token: salva API key ou JWT diretamente.
    Com --email + --password: login direto via API (sem navegador).
    """
    # Opção 1: Token direto
    if token:
        save_token(token)
        console.print("[green]Token salvo com sucesso.[/green]")
        return

    # Opção 2: Email + senha (API direta)
    if email and password:
        _login_credentials(email, password)
        return

    if email or password:
        console.print("[yellow]Informe --email e --password juntos.[/yellow]")
        raise typer.Exit(1)

    # Opção 3 (padrão): OAuth via navegador
    _login_browser()


def _login_browser() -> None:
    """Login via OAuth PKCE abrindo o navegador."""
    from tecjustica_cli.oauth import oauth_browser_login

    console.print("[dim]Abrindo navegador para login...[/dim]")
    try:
        with console.status("Aguardando login no navegador..."):
            access_token = oauth_browser_login()
        save_token(access_token)
        console.print("[green]Login realizado com sucesso![/green]")

        # Verificar identidade
        try:
            client = MCPClient(token=access_token)
            result = client.call_tool("whoami")
            email = result.get("email", "") if isinstance(result, dict) else ""
            if email:
                console.print(f"[dim]Autenticado como {email}[/dim]")
        except Exception:
            pass
    except RuntimeError as e:
        console.print(f"[red]{e}[/red]")
        console.print(
            "[yellow]Alternativas: tecjustica auth login --token <TOKEN> "
            "ou --email <EMAIL> --password <SENHA>[/yellow]"
        )
        raise typer.Exit(1) from None
    except Exception as e:
        console.print(f"[red]Erro ao abrir navegador: {e}[/red]")
        console.print(
            "[yellow]Alternativas: tecjustica auth login --token <TOKEN> "
            "ou --email <EMAIL> --password <SENHA>[/yellow]"
        )
        raise typer.Exit(1) from None


def _login_credentials(email: str, password: str) -> None:
    """Login direto via API Supabase (email + senha)."""
    import httpx

    resp = httpx.post(
        f"{SUPABASE_URL}/auth/v1/token?grant_type=password",
        headers={
            "apikey": SUPABASE_ANON_KEY,
            "Content-Type": "application/json",
        },
        json={"email": email, "password": password},
    )
    if resp.status_code != 200:
        console.print(f"[red]Erro de autenticação: {resp.text[:200]}[/red]")
        raise typer.Exit(1)

    data = resp.json()
    jwt = data.get("access_token")
    if not jwt:
        console.print("[red]Resposta inesperada do Supabase.[/red]")
        raise typer.Exit(1)

    save_token(jwt)
    console.print(f"[green]Autenticado como {email}. Token JWT salvo.[/green]")


@app.command()
def status() -> None:
    """Verificar autenticação atual."""
    token = get_token()
    if not token:
        console.print("[yellow]Não autenticado. Use: tecjustica auth login[/yellow]")
        raise typer.Exit(1)

    token_preview = token[:10] + "..." if len(token) > 10 else token
    console.print(f"[dim]Token: {token_preview}[/dim]")

    try:
        client = MCPClient()
        with console.status("Verificando..."):
            result = client.call_tool("whoami")
        from tecjustica_cli.formatting import format_whoami

        format_whoami(result)
    except AuthError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from None
    except Exception as e:
        console.print(f"[red]Erro ao verificar: {e}[/red]")
        raise typer.Exit(1) from None


@app.command()
def logout() -> None:
    """Remover token salvo."""
    remove_token()
    console.print("[green]Token removido.[/green]")
