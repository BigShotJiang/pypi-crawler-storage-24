"""CLI TecJustica — Cliente MCP para terminal."""
