"""Formatadores Rich para exibição no terminal."""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree

console = Console()


def print_json_or_rich(data: Any, *, json_mode: bool) -> None:
    """Imprime data como JSON puro ou formatado com Rich."""
    if json_mode:
        import json

        console.print_json(json.dumps(data, ensure_ascii=False, default=str))
        return
    # Fallback: tenta formatador específico, senão imprime dict/str
    if isinstance(data, str):
        console.print(data)
    elif isinstance(data, dict):
        console.print_json(data=data)
    elif isinstance(data, list):
        import json

        console.print_json(json.dumps(data, ensure_ascii=False, default=str))
    else:
        console.print(data)


def format_processos(data: Any, *, json_mode: bool = False) -> None:
    """Formata lista de processos como tabela Rich."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    processos = (
        data if isinstance(data, list) else data.get("resultados", data.get("processos", []))
    )
    if not processos:
        console.print("[yellow]Nenhum processo encontrado.[/yellow]")
        return

    table = Table(title="Processos", show_lines=True)
    table.add_column("Número CNJ", style="cyan", no_wrap=True)
    table.add_column("Classe", style="green")
    table.add_column("Partes", style="white")

    for p in processos:
        table.add_row(
            p.get("numero_processo", ""),
            p.get("classe_descricao", p.get("classe_judicial", "")) or "",
            p.get("partes", p.get("assunto", "")) or "",
        )

    console.print(table)
    total = data.get("total") if isinstance(data, dict) else len(processos)
    if total:
        console.print(f"[dim]Total: {total} processo(s)[/dim]")


def format_visao_geral(data: Any, *, json_mode: bool = False) -> None:
    """Formata visão geral de um processo com painéis Rich."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    if isinstance(data, str):
        console.print(data)
        return

    # Metadados
    title = data.get("numero_processo", "Processo")
    panel_content = []
    field_map = {
        "classe_descricao": "Classe",
        "sigla_tribunal": "Tribunal",
        "instancia": "Instância",
        "natureza": "Natureza",
        "valor_causa": "Valor da Causa",
        "data_ajuizamento": "Data Ajuizamento",
        "justica_gratuita": "Justiça Gratuita",
    }
    for key, label in field_map.items():
        val = data.get(key)
        if val is not None:
            panel_content.append(f"[bold]{label}:[/bold] {val}")

    if panel_content:
        console.print(
            Panel("\n".join(panel_content), title=f"[cyan]{title}[/cyan]", border_style="blue")
        )

    # Assuntos
    assuntos = data.get("assuntos", [])
    if assuntos:
        assuntos_text = ", ".join(
            a.get("descricao", str(a)) if isinstance(a, dict) else str(a) for a in assuntos
        )
        console.print(Panel(assuntos_text, title="Assuntos", border_style="dim"))

    # Partes
    partes = data.get("partes", [])
    if partes:
        tree = Tree("[bold]Partes[/bold]")
        for parte in partes:
            nome = parte.get("nome", "")
            tipo = parte.get("tipo", "")
            advogados = parte.get("advogados", [])
            branch = tree.add(f"[green]{tipo}:[/green] {nome}")
            for adv in advogados:
                if isinstance(adv, dict):
                    branch.add(f"[dim]Adv: {adv.get('nome', adv)}[/dim]")
                else:
                    branch.add(f"[dim]Adv: {adv}[/dim]")
        console.print(tree)

    # Stats
    stats = data.get("stats_documentos", {})
    if stats:
        stats_text = []
        for k, v in stats.items():
            if k == "por_fonte":
                continue
            label = k.replace("_", " ").title()
            stats_text.append(f"[bold]{label}:[/bold] {v}")
        if stats_text:
            console.print(Panel(" | ".join(stats_text), title="Estatísticas", border_style="green"))

    # Movimentações recentes
    movs = data.get("ultimas_movimentacoes", [])
    if movs:
        table = Table(title="Movimentações Recentes", show_lines=True)
        table.add_column("Data", style="cyan", no_wrap=True)
        table.add_column("Tipo", style="green")
        table.add_column("Descrição", style="white")
        table.add_column("Fonte", style="dim")
        for mov in movs[:10]:
            table.add_row(
                mov.get("data_hora", ""),
                mov.get("tipo_nome", ""),
                mov.get("descricao", ""),
                mov.get("fonte", ""),
            )
        console.print(table)


def format_documentos(data: Any, *, json_mode: bool = False) -> None:
    """Formata lista de documentos como tabela."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    docs = data if isinstance(data, list) else data.get("resultados", data.get("documentos", []))
    if not docs:
        console.print("[yellow]Nenhum documento encontrado.[/yellow]")
        return

    table = Table(title="Documentos", show_lines=True)
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Tipo", style="cyan")
    table.add_column("Nome", style="white")
    table.add_column("Fonte", style="green")
    table.add_column("Páginas", style="yellow", justify="right")

    for doc in docs:
        table.add_row(
            str(doc.get("id", "")),
            doc.get("tipo_nome", doc.get("tipo", "")),
            doc.get("nome", doc.get("titulo", "")),
            doc.get("fonte", doc.get("source", "")),
            str(doc.get("paginas", "")),
        )

    console.print(table)
    if isinstance(data, dict):
        total = data.get("total")
        has_more = data.get("has_more", False)
        if total:
            more_label = " (há mais)" if has_more else ""
            console.print(f"[dim]Total: {total}{more_label}[/dim]")


def format_movimentacoes(data: Any, *, json_mode: bool = False) -> None:
    """Formata lista de movimentações como tabela."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    movs = data if isinstance(data, list) else data.get("resultados", data.get("movimentacoes", []))
    if not movs:
        console.print("[yellow]Nenhuma movimentação encontrada.[/yellow]")
        return

    table = Table(title="Movimentações", show_lines=True)
    table.add_column("Data", style="cyan", no_wrap=True)
    table.add_column("Tipo", style="green")
    table.add_column("Descrição", style="white")
    table.add_column("Fonte", style="dim")

    for mov in movs:
        table.add_row(
            mov.get("data_hora", mov.get("data", "")),
            mov.get("tipo_nome", ""),
            mov.get("descricao", ""),
            mov.get("fonte", ""),
        )

    console.print(table)
    if isinstance(data, dict):
        total = data.get("total")
        has_more = data.get("has_more", False)
        if total:
            more_label = " (há mais)" if has_more else ""
            console.print(f"[dim]Total: {total}{more_label}[/dim]")


def format_documento_conteudo(data: Any, *, json_mode: bool = False) -> None:
    """Formata conteúdo de um documento."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    if isinstance(data, str):
        console.print(data)
        return

    titulo = data.get("nome", data.get("tipo_nome", "Documento"))
    conteudo = data.get("conteudo", data.get("texto", ""))
    fonte = data.get("fonte", "")
    confianca = data.get("confianca")

    header_parts = [f"[cyan]{titulo}[/cyan]"]
    if fonte:
        header_parts.append(f"[dim](fonte: {fonte})[/dim]")
    if confianca is not None:
        header_parts.append(f"[dim](confiança: {confianca})[/dim]")

    console.print(Panel(conteudo, title=" ".join(header_parts), border_style="blue"))

    # Info de leitura (paginação do conteúdo)
    leitura = data.get("leitura", {})
    if leitura:
        total_chars = leitura.get("tamanho_total", 0)
        retornados = leitura.get("chars_retornados", 0)
        tem_mais = leitura.get("tem_mais", False)
        offset = leitura.get("offset", 0)
        proximo = leitura.get("proximo_offset")
        info_parts = [f"Chars: {retornados}/{total_chars}"]
        if offset:
            info_parts.append(f"offset: {offset}")
        if tem_mais and proximo is not None:
            info_parts.append(f"próximo offset: {proximo}")
        console.print(f"[dim]{' | '.join(info_parts)}[/dim]")

    # Fallback: metadata legado
    meta = data.get("metadata", {})
    if not leitura and meta.get("foi_resumido"):
        console.print(
            f"[yellow]Conteúdo resumido: {meta.get('tamanho_original')} → {meta.get('tamanho_final')} chars[/yellow]"
        )


def format_grep_results(data: Any, *, json_mode: bool = False) -> None:
    """Formata resultados de busca grep ou localizar."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    # Detectar se é localizar_no_documento (tem "ocorrencias")
    if isinstance(data, dict) and "ocorrencias" in data:
        _format_localizar(data)
        return

    # Grep: resultados paginados
    resultados = data if isinstance(data, list) else data.get("resultados", [])
    if not resultados:
        console.print("[yellow]Nenhum resultado encontrado.[/yellow]")
        return

    for r in resultados:
        nome = r.get("nome", r.get("tipo_nome", r.get("documento", "")))
        tipo = r.get("tipo_nome", "")
        snippet = r.get("snippet", "")
        fonte = r.get("fonte", "")

        header = f"[bold cyan]{nome}[/bold cyan]"
        if tipo and tipo != nome:
            header += f" [dim]({tipo})[/dim]"
        if fonte:
            header += f" [dim]— {fonte}[/dim]"
        console.print(header)
        if snippet:
            console.print(f"  ...{snippet}...")
        console.print()

    if isinstance(data, dict):
        total = data.get("total", len(resultados))
        has_more = data.get("has_more", False)
        more_label = " (há mais)" if has_more else ""
        console.print(f"[dim]Total: {total} resultado(s){more_label}[/dim]")


def _format_localizar(data: dict[str, Any]) -> None:
    """Formata resultado de localizar_no_documento."""
    termo = data.get("termo", "")
    total = data.get("total_ocorrencias", 0)
    fonte = data.get("fonte", "")
    confianca = data.get("confianca")

    header_parts = [f"Termo: [bold]{termo}[/bold]", f"Ocorrências: {total}"]
    if fonte:
        header_parts.append(f"Fonte: {fonte}")
    if confianca is not None:
        header_parts.append(f"Confiança: {confianca}")
    console.print(Panel(" | ".join(header_parts), title="Localizar", border_style="yellow"))

    ocorrencias = data.get("ocorrencias", [])
    for oc in ocorrencias:
        pos = oc.get("posicao", "?")
        ctx = oc.get("contexto", "")
        console.print(f"  [dim]pos {pos}:[/dim] ...{ctx}...")


def format_stats(data: Any, *, json_mode: bool = False) -> None:
    """Formata estatísticas de documentos."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    if isinstance(data, str):
        console.print(data)
        return

    table = Table(title="Estatísticas de Documentos", show_lines=True)
    table.add_column("Métrica", style="cyan")
    table.add_column("Valor", style="white", justify="right")

    for k, v in data.items():
        if k == "por_fonte":
            continue
        label = k.replace("_", " ").title()
        table.add_row(label, str(v))

    console.print(table)

    por_fonte = data.get("por_fonte", {})
    if por_fonte:
        ft = Table(title="Por Fonte", show_lines=True)
        ft.add_column("Fonte", style="green")
        ft.add_column("Quantidade", style="white", justify="right")
        for fonte, qtd in por_fonte.items():
            ft.add_row(fonte, str(qtd))
        console.print(ft)


def format_analise(data: Any, *, json_mode: bool = False) -> None:
    """Formata resultado de análise."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    if isinstance(data, str):
        console.print(Panel(data, title="Análise", border_style="magenta"))
        return

    resposta = data.get("resposta", data.get("analise", ""))
    custo = data.get("custo")

    console.print(Panel(str(resposta), title="[magenta]Análise[/magenta]", border_style="magenta"))

    if custo:
        console.print(f"[dim]Custo: ${custo}[/dim]")


def format_precedentes(data: Any, *, json_mode: bool = False) -> None:
    """Formata resultados de busca de precedentes."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    resultados = (
        data if isinstance(data, list) else data.get("resultados", data.get("precedentes", []))
    )
    if not resultados:
        console.print("[yellow]Nenhum precedente encontrado.[/yellow]")
        return

    for r in resultados:
        tipo = r.get("tipo", "")
        nr = r.get("nr", "")
        orgao = r.get("orgao", "")
        situacao = r.get("situacao", "")
        tese = r.get("tese", "")

        # Título: "TIPO NR" (ex: "SUM 227", "TEMA 123")
        titulo = f"{tipo} {nr}".strip() if tipo or nr else "Precedente"
        header = f"[bold]{titulo}[/bold]"
        if situacao:
            header += f" [yellow]({situacao})[/yellow]"
        if orgao:
            header += f" [dim]— {orgao}[/dim]"

        content = str(tese)[:500] if tese else "[dim]Sem tese disponível[/dim]"
        console.print(Panel(content, title=header, border_style="yellow"))

    if isinstance(data, dict):
        total = data.get("total", len(resultados))
        has_more = data.get("has_more", False)
        if total:
            more_label = " (há mais)" if has_more else ""
            console.print(f"[dim]Total: {total} precedente(s){more_label}[/dim]")


def format_calculadora(data: Any, *, json_mode: bool = False) -> None:
    """Formata resultado da calculadora."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    if isinstance(data, str):
        console.print(data)
        return

    resultado = data.get("resultado", data)
    console.print(Panel(str(resultado), title="Calculadora", border_style="green"))


def format_whoami(data: Any, *, json_mode: bool = False) -> None:
    """Formata resultado do whoami."""
    if json_mode:
        print_json_or_rich(data, json_mode=True)
        return

    if isinstance(data, str):
        console.print(data)
        return

    parts = []
    field_map = {
        "autenticado": "Autenticado",
        "email": "Email",
        "user_id": "User ID",
        "role": "Role",
        "scopes": "Scopes",
        "client_id": "Client ID",
        "token_emitido_em": "Token Emitido Em",
        "token_expira_em": "Token Expira Em",
    }
    for key, label in field_map.items():
        val = data.get(key)
        if val is not None:
            parts.append(f"[bold]{label}:[/bold] {val}")

    if parts:
        console.print(Panel("\n".join(parts), title="[cyan]Usuário[/cyan]", border_style="cyan"))
    else:
        print_json_or_rich(data, json_mode=False)


def format_generic(data: Any, *, json_mode: bool = False) -> None:
    """Formatador genérico para qualquer resposta."""
    print_json_or_rich(data, json_mode=json_mode)
