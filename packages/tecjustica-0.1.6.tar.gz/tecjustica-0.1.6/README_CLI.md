# TecJustica CLI

CLI para consulta de processos judiciais brasileiros via MCP.

Acesse seus processos diretamente do terminal — navegue, busque, analise e consulte precedentes sem sair da linha de comando.

## Instalacao

```bash
# Recomendado (instala em venv isolado)
pipx install tecjustica

# Alternativa (dentro de um venv existente)
pip install tecjustica
```

> **Nota**: Em sistemas com Python 3.12+ (Ubuntu 24.04, Debian 13, etc.), `pip install` global e bloqueado por PEP 668. Use `pipx` ou instale dentro de um virtual environment.

## Autenticacao

```bash
# Login via navegador (metodo padrao — abre OAuth no browser)
tecjustica login

# Alternativa: login com API key
tecjustica login --token tk_SUA_CHAVE

# Alternativa: login com email/senha
tecjustica login --email seu@email.com --password suasenha

# Verificar autenticacao
tecjustica whoami

# Desconectar
tecjustica logout
```

## Comandos

| Comando | Descricao |
|---------|-----------|
| `login` | Autenticar (abre navegador por padrao) |
| `logout` | Remover autenticacao salva |
| `listar-processos` | Listar processos disponiveis |
| `visao-geral` | Visao geral de um processo (metadados, partes, stats) |
| `ls-docs` | Listar documentos de um processo |
| `ls-movs` | Listar movimentacoes de um processo |
| `read-doc` | Ler conteudo de um documento |
| `grep-docs` | Buscar texto em documentos (full-text search) |
| `grep-movs` | Buscar texto em movimentacoes |
| `glob-docs` | Filtrar documentos por nome/tipo |
| `localizar` | Localizar termo em documento (posicoes exatas) |
| `analisar` | Analisar processo com IA |
| `precedentes` | Buscar precedentes (sumulas, temas repetitivos, IRDR) |
| `stats-docs` | Estatisticas de documentos de um processo |
| `calc` | Calculadora de expressoes e prazos processuais |
| `agora` | Data e hora atual |
| `whoami` | Identidade do usuario autenticado |

## Exemplos

```bash
# Login
tecjustica login

# Listar processos
tecjustica listar-processos

# Visao geral de um processo
tecjustica visao-geral 1234567-89.2024.8.26.0100

# Buscar "dano moral" nos documentos
tecjustica grep-docs "dano moral" --processo 1234567-89.2024.8.26.0100

# Analisar processo com IA
tecjustica analisar 1234567-89.2024.8.26.0100 --pergunta "Qual a situacao atual?"

# Buscar precedentes
tecjustica precedentes "dano moral"

# Saida em JSON (para scripting)
tecjustica --json listar-processos
```

## Configuracao

O token e configuracoes ficam em `~/.config/tecjustica/config.toml`.

Para usar um servidor diferente:

```bash
tecjustica login --token tk_SUA_CHAVE --server https://seu-servidor.com/mcp
```

## Links

- [TecJustica](https://tecjustica.com)
- [Model Context Protocol](https://modelcontextprotocol.io)
