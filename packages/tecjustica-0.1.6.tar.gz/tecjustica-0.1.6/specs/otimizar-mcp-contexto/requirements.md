# Requisitos: Otimizar MCP - Consolidação e Qualidade v2

## Descrição

Segunda fase de otimização do MCP Server. A primeira fase implementou seleção inteligente de modelo, normalização de acentos e filtros. Esta fase foca em:

1. **Aplicar padrões de sucesso** - Levar seleção inteligente de modelo para TODAS as tools de análise
2. **Eliminar redundâncias** - Remover tools duplicadas que fazem a mesma coisa
3. **Consolidar APIs** - Unificar múltiplas tools similares em uma parametrizável
4. **Melhorar contexto** - Adicionar snippets nas buscas

## Critérios de Aceitação

### Qualidade (Prioridade Alta)
- [ ] Criar helper `_helpers.py` com `analisar_com_selecao_modelo()`
- [ ] Todas as 8 tools de `analise_juridica.py` usam seleção inteligente (Gemini < 3M, Grok > 3M)
- [ ] `buscar_em_documentos` retorna snippet de 200 chars ao redor do termo

### Remoções
- [ ] Deletar `ultima_movimentacao` (redundante com `movimentacoes_processo(limite=1)`)
- [ ] Deletar `modelos_disponiveis` (informação estática)
- [ ] Deletar `tipos_movimentacoes` (agregação sem valor jurídico)

### Consolidações
- [ ] Consolidar 4 tools de listagem de docs → 1 parametrizável
- [ ] Consolidar 3 tools de perguntas → 1 parametrizável
- [ ] Consolidar 2 tools de timeline → 1 parametrizável

### Validação
- [ ] Total de tools reduzido de 33 para ~24
- [ ] `ruff check` e `mypy` passam
- [ ] Respostas mantêm qualidade

## Dependências

- Fase 1 concluída (seleção de modelo em `analisar_processo`)
- FastMCP 2.14+
- OpenRouter API (Gemini Flash + Grok Fast)

## Features Relacionadas

- `analisar_processo` com seleção inteligente (implementado)
- `documentos_importantes` com filtros (implementado)
- `analisar_documentos_por_nome` com normalização (implementado)
