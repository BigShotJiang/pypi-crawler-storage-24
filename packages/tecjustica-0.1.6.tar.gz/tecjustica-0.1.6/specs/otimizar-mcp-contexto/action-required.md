# Acoes Manuais: Otimizar MCP Server para Contexto Inteligente

Nenhuma acao manual necessaria para esta feature.

Todas as tarefas podem ser implementadas automaticamente.

## Verificacoes Recomendadas Apos Implementacao

- [x] Testar com processo pequeno (< 500k chars): deve usar Gemini Flash
- [x] Testar com processo medio (1-3M chars): deve usar Gemini Flash
- [x] Testar com processo grande (> 3M chars): deve usar Grok Fast
- [x] Testar busca por nome com acentos: "sentenca" deve encontrar "Sentenca.pdf"
- [x] Verificar que nomes nao estao mais truncados nas respostas

## Processos de Teste Disponiveis

| Processo | Tamanho Markdown | Modelo Esperado |
|----------|------------------|-----------------|
| 0010166-56.2022.8.06.0203 | 445k chars | Gemini Flash |
| 0201649-98.2024.8.06.0303 | 771k chars | Gemini Flash |
| 0010007-84.2020.8.06.0203 | 1.3M chars | Gemini Flash |
| 0852936-58.2023.8.19.0001 | 2.5M chars | Gemini Flash |
