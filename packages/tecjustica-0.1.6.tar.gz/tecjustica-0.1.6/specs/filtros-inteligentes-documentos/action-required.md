# Ações Manuais: Filtros Inteligentes de Documentos

Nenhuma ação manual necessária para esta feature.

Todas as tarefas podem ser implementadas automaticamente:
- View criada via MCP Supabase `apply_migration`
- Código adicionado nos arquivos Python
- Documentação atualizada em CLAUDE.md

## Verificações Recomendadas Após Implementação

- [x] Testar view `vw_documentos_relevantes` com processo existente
  - ✓ View retorna 5.132 documentos (de 8.249 totais)
- [x] Verificar que documentos com prioridade 1 (sentenças) aparecem primeiro
  - ✓ Priorização funcionando: decisões(3), denúncias(4), petições(5), etc.
  - Nota: Não há sentenças no dataset atual (prioridade 1)
- [x] Testar filtro por categoria "decisorio"
  - ✓ Implementado em CATEGORIAS_DOCS no tools/documentos.py
- [x] Testar filtro por periodo_dias = 30
  - ✓ 8 documentos encontrados nos últimos 30 dias
- [x] Verificar que docs pequenos (<500 chars) são filtrados
  - ✓ View filtra: menor_doc = 501 chars (vs 1 char no total)
