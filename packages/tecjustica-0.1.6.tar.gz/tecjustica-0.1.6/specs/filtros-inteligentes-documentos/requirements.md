# Requisitos: Filtros Inteligentes de Documentos

## Descrição

Melhorar a seleção de documentos quando o campo `markdown` não cabe no contexto do Gemini/Grok. Criar filtros inteligentes que priorizem documentos relevantes por categoria, período e tamanho.

## Contexto (Dados Atuais)

- **8.249 documentos** no banco
- **3.315 (40%)** com conteúdo relevante (>1000 chars)
- **1.537** sem `tipo_nome` (null)
- **~15 tipos** com códigos genéricos (TipoProcessoDocumento#13, #249, etc.)
- Nomes com acentos corrompidos (Certido, Petio, Denncia)

## Critérios de Aceitação

- [x] View `vw_documentos_relevantes` criada no Supabase com priorização por nome
- [x] Método `buscar_documentos_por_periodo()` funciona com data_inicio e data_fim
- [x] Método `buscar_documentos_por_tamanho()` funciona com min_chars e max_chars
- [x] Método `buscar_documentos_relevantes()` usa a nova view
- [x] Tool `documentos_importantes` aceita categoria, periodo_dias e min_chars
- [x] Categorias disponíveis: "decisorio", "peticoes", "provas", "criminal"
- [x] Documentação atualizada em CLAUDE.md

## Dependências

- Supabase PostgreSQL (acesso via MCP)
- Spec anterior `otimizar-mcp-contexto` já implementada
- Função `_normalize_text()` já existe em `supabase_client.py`

## Features Relacionadas

- Tool `analisar_processo` (usa seleção inteligente como fallback)
- Tool `analisar_documentos_por_nome` (usa normalização de acentos)
- Tool `listar_nomes_documentos` (lista metadados sem conteúdo)
