# Ações Manuais: Fix MCP v4 Bugs

Nenhuma ação manual necessária para esta feature.

Todas as correções são em código Python existente — sem migrations, sem novas dependências, sem configuração externa.

## Após a Implementação

- [ ] **Deploy no Railway** — Após validação local, fazer deploy para produção (`https://mcp.tecjustica.com`)
- [ ] **Testar em produção** — Verificar que `analisar` retorna `{erro, dica}` em caso de falha (ex: processo inexistente)

---

> Estas ações também estão listadas em contexto no `implementation-plan.md`
