# Acoes Manuais: Consolidar Tools MCP v2

Nenhuma acao manual necessaria para esta feature.

Todas as tarefas podem ser implementadas automaticamente:
- Nao requer criacao de contas ou API keys
- Nao requer mudancas no banco de dados (views e tabelas permanecem intactas)
- Nao requer mudancas em servicos externos (Supabase, OpenRouter, Railway)
- Nao requer mudancas de infraestrutura

## Validacao Pos-Implementacao (Recomendado)

Apos implementacao, validar manualmente:

- [ ] **Testar com Claude Code** — Conectar ao MCP server local e testar as 6 tools com um processo real
- [ ] **Testar eviction** — Ler documento grande (> 10k chars) e verificar que Gemini resume automaticamente
- [ ] **Testar explorar_processo** — Verificar que catalogo de documentos retorna todos os IDs e nomes
- [ ] **Testar analisar com document_ids** — Passar IDs obtidos do catalogo e verificar analise
- [ ] **Verificar prompts** — Executar prompt `analise_completa` e verificar que agent usa tools corretas
- [ ] **Deploy no Railway** — Apos validacao local, fazer deploy e testar em producao
