# Acoes Manuais: CLI TecJustica

Passos que precisam ser executados manualmente por um humano.

## Antes da Implementacao

Nenhuma acao manual necessaria antes de comecar.

## Apos a Implementacao

- [ ] **Registrar nome `tecjustica` no PyPI** - Verificar disponibilidade do nome e criar conta/projeto no pypi.org
- [ ] **Publicar primeira versao no PyPI** - `uv build && uv publish` (precisa de token PyPI configurado)
- [ ] **Decidir sobre ANON_KEY no codigo** - A ANON_KEY do Supabase esta no CLAUDE.md e seria embutida no CLI para `auth login --email`. Avaliar se isso e aceitavel ou se deve ser configuravel

---

> Estas acoes tambem estao listadas em contexto no `implementation-plan.md`
