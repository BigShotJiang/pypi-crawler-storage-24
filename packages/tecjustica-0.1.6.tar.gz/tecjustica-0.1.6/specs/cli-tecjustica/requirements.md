# Requisitos: CLI TecJustica

## Descricao

CLI Python que se conecta ao MCP server remoto (`mcp.tecjustica.com`) e expoe as 15 tools como comandos de terminal. Permite que usuarios consultem processos judiciais diretamente pela linha de comando, sem precisar de Claude Code. Distribuida via `pip install tecjustica` no PyPI.

## Criterios de Aceitacao

- [ ] `pip install -e .` instala o comando `tecjustica` no PATH
- [ ] `tecjustica --help` lista todos os 15 comandos disponiveis
- [ ] `tecjustica auth login --token tk_...` salva token em `~/.config/tecjustica/config.toml`
- [ ] `tecjustica auth login --email X --password Y` obtem JWT do Supabase e salva
- [ ] `tecjustica auth status` verifica token chamando `whoami`
- [ ] `tecjustica whoami` mostra usuario autenticado
- [ ] `tecjustica listar-processos` lista processos em tabela Rich
- [ ] `tecjustica visao-geral CNJ` mostra metadados do processo
- [ ] Todos os 15 comandos funcionam contra producao
- [ ] Flag `--json` em qualquer comando retorna JSON puro (para scripting)
- [ ] Spinner Rich durante comandos lentos (analisar)
- [ ] Erros amigaveis: 401 → "Token invalido, rode tecjustica auth login"
- [ ] `uv run ruff check . && uv run ruff format --check . && uv run mypy .` passa limpo

## Dependencias

- `typer[all]>=0.12.0` — framework CLI (inclui Rich e shellingham)
- `httpx>=0.27.0` — ja e dependencia do projeto
- `tomli-w>=1.0.0` — escrita de arquivos TOML

## Features Relacionadas

- MCP server existente (server.py) — a CLI e cliente deste servidor
- Auth dual (API key tk_ + JWT Supabase) — a CLI suporta ambos
- 15 tools registradas em tools/ — mapeadas 1:1 para comandos CLI
