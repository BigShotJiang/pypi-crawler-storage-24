# Requisitos: Consolidar Tools do MCP Server

## Descrição

Otimizar as ferramentas do MCP Server aplicando padrões de sucesso já validados e eliminando redundâncias. Objetivo: menos tools, mesma funcionalidade, melhor qualidade.

**Padrões de sucesso identificados:**
- Seleção inteligente de modelo (Gemini < 3M, Grok > 3M) em `analisar_processo`
- Normalização de acentos em `analisar_documentos_por_nome`
- Filtros compostos em `documentos_importantes`

## Critérios de Aceitação

### Qualidade (Prioridade Alta)
- [x] Helper `analisar_com_selecao_modelo()` criado em `tools/_helpers.py`
- [x] 8 tools de `analise_juridica.py` usam seleção inteligente de modelo
- [x] `buscar_em_documentos` retorna snippet de 200 chars ao redor do termo

### Remoções
- [x] `ultima_movimentacao` deletada (usar `movimentacoes_processo(limite=1)`)
- [x] `modelos_disponiveis` deletada (informação estática)
- [x] `tipos_movimentacoes` deletada (agregação sem valor)

### Consolidações
- [x] 4 listagens de docs → 1 parametrizável (`listar_documentos`, `preview_documentos`, `documentos_recentes`, `listar_nomes_documentos`)
- [x] 2 perguntas → 1 parametrizável (`sobre_processo`, `perguntar`) - Nota: `resumo_processo` mantida separada por ter função distinta
- [x] 2 timelines → 1 parametrizável (`timeline_processo`, `movimentacoes_processo`)

### Validação
- [x] Tools reduzidas de 33 para 26
- [x] `ruff check` e `mypy` passam
- [x] Qualidade das respostas mantida ou melhorada

## Dependências

- FastMCP 2.14+
- OpenRouter API (Gemini Flash + Grok Fast)
- Supabase client e LLM service existentes

## Features Relacionadas

- Seleção inteligente em `analisar_processo` (já implementado)
- Filtros em `documentos_importantes` (já implementado)
- Normalização em `analisar_documentos_por_nome` (já implementado)
