# Ações Manuais: MCP v4 — Deep Agent Tools

Passos que precisam ser executados manualmente por um humano.

## Antes da Implementação

- [ ] **Verificar projeto Supabase ativo** - As migrations serão aplicadas via Supabase MCP. Confirmar que o projeto `pglghyznirxkewcmuhvp` está online e acessível.

## Durante a Implementação

Nenhuma ação manual necessária durante a implementação. Todas as migrations SQL e alterações de código são automatizáveis.

## Após a Implementação

- [ ] **Deploy no Railway** - Após validação local, fazer deploy para produção (`https://mcp.tecjustica.com`)
- [ ] **Testar em produção** - Seguir o fluxo completo de teste do CLAUDE.md: obter token → initialize → notifications/initialized → tools/list (verificar 12 tools) → testar cada tool
- [ ] **Comunicar mudança de API** - Se há clientes MCP consumindo as tools antigas (explorar_processo, consultar_documentos, consultar_movimentacoes), informá-los sobre a migração

---

> Estas ações também estão listadas em contexto no `implementation-plan.md`
