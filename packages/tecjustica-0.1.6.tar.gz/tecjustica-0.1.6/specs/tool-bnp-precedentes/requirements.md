# Requisitos: Tool BNP - Banco Nacional de Precedentes

## Descricao

Adicionar tool MCP `buscar_precedentes` que consulta a API publica do BNP (Banco Nacional de Precedentes) do PDPJ/CNJ. Permite ao agent buscar sumulas, repercussao geral, IRDR, IRR, temas repetitivos e outros precedentes de todos os tribunais brasileiros.

A API e publica mas requer headers anti-WAF (Origin, Referer, User-Agent). O endpoint e `POST https://pangeabnp.pdpj.jus.br/api/v1/precedentes`.

## Criterios de Aceitacao

- [ ] Tool `buscar_precedentes` registrada no MCP server com parametros: `busca` (obrigatorio), `orgaos`, `tipos`, `pagina`, `tamanho_pagina`
- [ ] Chamada HTTP async via httpx com headers anti-WAF corretos
- [ ] Payload envelopado em `{"filtro": {...}}` conforme API exige
- [ ] Resposta formatada com teses limpas (sem HTML) e paginacao padrao (`paginar_resultado`)
- [ ] Agregacoes por tipo e orgao incluidas na resposta
- [ ] Logging de tool call via `get_usage_logger().log_tool_call()`
- [ ] Erros tratados com `erro_instrutivo()` e dicas uteis
- [ ] Lint/format/typecheck passando (`ruff check`, `ruff format`, `mypy`)
- [ ] Tool aparece em `tools/list` apos deploy (13 tools total)

## Dependencias

- `httpx>=0.27.0` (ja no `requirements.txt`)
- Helpers existentes: `paginar_resultado()`, `erro_instrutivo()`, `_get_current_user()`, `ms_since()`

## Features Relacionadas

- Tools de navegacao (`listar_processos`, `visao_geral_processo`) — complementar para pesquisa juridica
- Tool `analisar` — pode usar precedentes como contexto para analise
