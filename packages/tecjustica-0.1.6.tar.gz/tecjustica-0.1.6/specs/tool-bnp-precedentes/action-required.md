# Acoes Manuais: Tool BNP - Banco Nacional de Precedentes

Nenhuma acao manual necessaria para esta feature.

Todas as tarefas podem ser implementadas automaticamente:
- A API BNP e publica (sem autenticacao)
- `httpx` ja esta no `requirements.txt`
- Deploy e automatico via `git push origin master`
