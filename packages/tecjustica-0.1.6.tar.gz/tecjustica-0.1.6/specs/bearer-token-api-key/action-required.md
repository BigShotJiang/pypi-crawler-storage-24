# Acoes Manuais: Bearer Token Fixo (API Key) via Env Var

Passos que precisam ser executados manualmente por um humano.

## Antes da Implementacao

Nenhuma acao manual necessaria.

## Durante a Implementacao

Nenhuma acao manual necessaria.

## Apos a Implementacao

- [ ] **Gerar token tk_ e hash SHA-256** - Executar script Python para gerar token seguro e seu hash
- [ ] **Configurar env var `API_KEY_HASHES` no Railway** - Formato: `hash:user_id:email` (usar hash gerado, NAO o token em texto)
- [ ] **Redeploy no Railway** - Para carregar nova env var
- [ ] **Configurar token no Manus** - `Authorization: Bearer tk_<token_gerado>` apontando para `https://mcp.tecjustica.com/mcp`
- [ ] **Testar OAuth nao quebrou** - Fluxo completo com token Supabase (initialize + notification + tools/list + whoami)
- [ ] **Testar API key funciona** - initialize + whoami com token `tk_`
- [ ] **Guardar token em local seguro** - O token so e visivel no momento da geracao (hash irreversivel)

---

> Estas acoes tambem estao listadas em contexto no `implementation-plan.md`
