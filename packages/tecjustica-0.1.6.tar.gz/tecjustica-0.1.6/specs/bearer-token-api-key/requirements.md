# Requisitos: Bearer Token Fixo (API Key) via Env Var

## Descricao

Clientes como Manus nao suportam OAuth flow — so aceitam header fixo `Authorization: Bearer <token>`. Precisamos de autenticacao dual: tokens `tk_` validados via hash SHA-256 em env var, JWTs validados via JWKS (fluxo atual intacto).

Abordagem ultra-simples: zero banco, zero migracao, zero scripts. Tokens fixos armazenados como hash SHA-256 em variavel de ambiente no Railway.

## Criterios de Aceitacao

- [ ] Tokens com prefixo `tk_` sao validados via hash SHA-256 contra env var `API_KEY_HASHES`
- [ ] JWTs do Supabase (`eyJ...`) continuam funcionando exatamente como antes (OAuth nao quebra)
- [ ] `_get_current_user()` retorna `(user_id, email)` corretos para ambos os tipos de token
- [ ] `whoami()` retorna dados corretos para tokens `tk_`
- [ ] Token `tk_` invalido retorna 401
- [ ] Env var `API_KEY_HASHES` inexistente = apenas OAuth funciona (graceful degradation)
- [ ] Nenhuma tool precisa ser modificada (12 tools intactas)
- [ ] `ruff check`, `ruff format`, `mypy` passam sem erros

## Dependencias

- FastMCP >= 2.14.0 (ja instalado — `TokenVerifier`, `AccessToken` disponiveis)
- `SupabaseProvider` aceita `token_verifier` como parametro opcional (confirmado)

## Features Relacionadas

- Autenticacao OAuth via Supabase DCR (existente, nao deve ser afetada)
- Usage logging (`tool_call_logs`, `llm_usage_logs`) — deve logar corretamente para tokens `tk_`
