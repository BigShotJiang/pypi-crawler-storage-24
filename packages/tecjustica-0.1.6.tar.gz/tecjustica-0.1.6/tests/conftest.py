"""Fixtures compartilhadas para testes."""

import os
from collections.abc import Generator
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture(autouse=True)
def mock_env_vars() -> Generator[None, None, None]:
    """Mock das variaveis de ambiente para testes."""
    env_vars = {
        "SUPABASE_URL": "https://test.supabase.co",
        "SUPABASE_SERVICE_KEY": "test-service-key",
        "OPENROUTER_API_KEY": "test-openrouter-key",
    }
    with patch.dict(os.environ, env_vars):
        yield


@pytest.fixture
def mock_supabase_client() -> MagicMock:
    """Mock do cliente Supabase."""
    client = MagicMock()
    client.table.return_value = client
    client.select.return_value = client
    client.eq.return_value = client
    client.limit.return_value = client
    client.execute.return_value = MagicMock(data=None)
    return client


@pytest.fixture
def sample_processo() -> dict:
    """Dados de exemplo de um processo."""
    return {
        "numero_processo": "0000001-00.2024.8.26.0100",
        "classe_descricao": "Procedimento Comum",
        "sigla_tribunal": "TJSP",
        "instancia": 1,
        "natureza": "CIVEL",
        "valor_causa": 50000.00,
        "data_ajuizamento": "2024-01-15",
        "justica_gratuita": False,
        "partes": [
            {"nome": "Autor Teste", "tipo": "AUTOR", "polo": "ATIVO"},
            {"nome": "Reu Teste", "tipo": "REU", "polo": "PASSIVO"},
        ],
        "assuntos": [{"nome": "Indenizacao por Dano Moral"}],
        "total_docs": 10,
        "total_movs": 25,
    }


@pytest.fixture
def sample_documento() -> dict:
    """Dados de exemplo de um documento."""
    return {
        "id": "doc-uuid-123",
        "numero_processo": "0000001-00.2024.8.26.0100",
        "tipo_nome": "Peticao Inicial",
        "nome": "Peticao Inicial",
        "sequencia": 1,
        "data_juntada": "2024-01-15T10:00:00",
        "conteudo": "Conteudo do documento de teste...",
        "paginas": 5,
        "tamanho_bytes": 102400,
    }


@pytest.fixture
def sample_movimentacao() -> dict:
    """Dados de exemplo de uma movimentacao."""
    return {
        "id": "mov-uuid-123",
        "numero_processo": "0000001-00.2024.8.26.0100",
        "sequencia": 1,
        "data_hora": "2024-01-15T10:30:00",
        "descricao": "Distribuido por sorteio",
        "tipo_nome": "Distribuicao",
        "tipo_descricao": "Distribuicao do processo",
        "orgao_julgador_nome": "1a Vara Civel",
        "magistrado_nome": None,
    }


@pytest.fixture
def sample_stats() -> dict:
    """Dados de exemplo de estatisticas."""
    return {
        "numero_processo": "0000001-00.2024.8.26.0100",
        "classe_descricao": "Procedimento Comum",
        "valor_causa": 50000.00,
        "sigla_tribunal": "TJSP",
        "instancia": 1,
        "total_docs_api": 15,
        "docs_extraidos": 10,
        "docs_sigilosos": 2,
        "docs_ocr": 3,
        "media_paginas": 8.5,
        "total_movs_api": 30,
        "movs_sincronizados": 25,
        "tamanho_total_bytes": 5242880,
    }
