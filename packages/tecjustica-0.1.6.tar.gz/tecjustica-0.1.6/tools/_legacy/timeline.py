"""Tools para consulta de timeline e movimentacoes processuais."""

from typing import Any

from fastmcp import Context, FastMCP

from services.supabase_client import get_supabase_client

# Limites para respostas compactas
MAX_TIMELINE = 30
MAX_MOVS = 20
MAX_DESC_LEN = 100


def register_timeline_tools(mcp: FastMCP) -> None:
    """Registra tools de timeline no servidor MCP."""

    @mcp.tool
    async def listar_movimentacoes(
        numero_processo: str,
        tipo: str | None = None,
        limite: int = 30,
        formato: str = "completo",
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Lista movimentacoes de um processo.

        Args:
            numero_processo: Numero do processo
            tipo: Filtrar por tipo (opcional)
            limite: Maximo de movimentacoes (default 30, max 100)
            formato: "completo" ou "compacto" (descricao truncada)

        Substitui: timeline_processo, movimentacoes_processo

        Returns:
            Lista de movimentacoes
        """
        limite = min(limite, MAX_TIMELINE)

        client = get_supabase_client()
        movs = await client.listar_movimentacoes(
            numero_processo=numero_processo,
            tipo=tipo,
            limite=limite,
        )

        resultados = []
        for m in movs:
            item = {
                "data_hora": m.get("data_hora"),
                "tipo": m.get("tipo_nome"),
                "descricao": m.get("descricao"),
            }
            if formato == "compacto":
                item["descricao"] = (item["descricao"] or "")[:MAX_DESC_LEN]
            if m.get("complemento"):
                item["complemento"] = m["complemento"]
            resultados.append(item)

        return {
            "numero_processo": numero_processo,
            "filtro": tipo,
            "total": len(resultados),
            "movimentacoes": resultados,
        }

    @mcp.tool
    async def movimentacoes_recentes(
        limite: int = 15,
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Movimentacoes recentes de todos os processos do sistema.

        Args:
            limite: Quantidade (default: 15, max: 20)

        Returns:
            Movimentacoes recentes
        """
        limite = min(limite, MAX_MOVS)

        client = get_supabase_client()
        movs = await client.movimentacoes_recentes(limite=limite)

        return {
            "total": len(movs),
            "movimentacoes": [
                {
                    "processo": m.get("numero_processo"),
                    "data": m.get("data_hora"),
                    "tipo": m.get("tipo_nome"),
                    "desc": (m.get("descricao") or "")[:80],
                }
                for m in movs
            ],
        }

    @mcp.tool
    async def buscar_movimentacao(
        numero_processo: str,
        termo: str,
        limite: int = 10,
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Busca movimentacoes por termo.

        Args:
            numero_processo: Numero do processo
            termo: Termo para buscar
            limite: Quantidade (default: 10)

        Returns:
            Movimentacoes encontradas
        """
        limite = min(limite, 15)

        client = get_supabase_client()
        movs = await client.buscar_movimentacoes_por_termo(
            numero_processo=numero_processo,
            termo=termo,
            limite=limite,
        )

        return {
            "numero_processo": numero_processo,
            "termo": termo,
            "total": len(movs),
            "movimentacoes": [
                {
                    "data": m.get("data_hora"),
                    "tipo": m.get("tipo_nome"),
                    "desc": (m.get("descricao") or "")[:MAX_DESC_LEN],
                }
                for m in movs
            ],
        }
