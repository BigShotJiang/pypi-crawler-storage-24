"""Tools avancadas para analise juridica profissional.

Ferramentas especializadas para advogados, juizes e operadores do direito.
Usa LLM com prompts estruturados para extracao e analise de elementos processuais.
"""

from typing import Any

from fastmcp import Context, FastMCP

from services.supabase_client import get_supabase_client
from tools._helpers import analisar_com_selecao_modelo

# URL para sincronizar processos
SYNC_URL = "https://tecjusticamcp3.vercel.app/login"

# Mensagem padrao para processo nao encontrado
MSG_PROCESSO_NAO_ENCONTRADO = (
    "Processo {numero} nao encontrado no sistema. "
    f"Acesse {SYNC_URL} para sincronizar o processo antes de consultar."
)


def register_analise_juridica_tools(mcp: FastMCP) -> None:
    """Registra tools de analise juridica avancada."""

    # ==================== EXTRACAO DE ELEMENTOS ====================

    @mcp.tool
    async def extrair_pedidos(
        numero_processo: str,
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Extrai e estrutura pedidos/pretensoes do processo.

        Para processos CIVEIS:
        - Pedidos principais e subsidiarios
        - Pedidos de tutela de urgencia
        - Valores pleiteados

        Para processos CRIMINAIS:
        - Tipificacao penal (crimes imputados)
        - Pena requerida
        - Medidas cautelares

        Args:
            numero_processo: Numero do processo

        Returns:
            Pedidos/pretensoes estruturados com classificacao e status
        """
        client = get_supabase_client()

        # Detecta tipo de processo automaticamente
        tipo_processo = await client.detectar_tipo_processo(numero_processo)

        contexto = await client.obter_contexto_processo(
            numero_processo=numero_processo,
            incluir_docs=True,
            incluir_movs=False,
            max_chars=300000,
        )

        if not contexto or len(contexto) < 100:
            return {
                "erro": MSG_PROCESSO_NAO_ENCONTRADO.format(numero=numero_processo),
                "sucesso": False,
            }

        # Prompt adaptado ao tipo de processo
        if tipo_processo == "criminal":
            prompt = """Analise os documentos do processo CRIMINAL e extraia as PRETENSOES ACUSATORIAS E DEFENSIVAS.

## IMPUTACAO PENAL

### Crimes Imputados
Para cada crime, identifique:
1. TIPO PENAL: Artigo e lei (ex: Art. 157, CP - Roubo)
2. MODALIDADE: Simples, Qualificado, Privilegiado
3. CIRCUNSTANCIAS: Agravantes, atenuantes
4. PENA EM ABSTRATO: Minima e maxima
5. STATUS: Recebida, Rejeitada, Pendente

### Pena Requerida pelo MP
- Pena privativa de liberdade: [tempo]
- Regime inicial: [fechado/semiaberto/aberto]
- Multa: [se houver]

## MEDIDAS CAUTELARES

### Solicitadas
- [ ] Prisao preventiva - Status: [deferida/indeferida/revogada]
- [ ] Fianca - Valor: R$ X - Status: [arbitrada/dispensada]
- [ ] Medidas diversas da prisao - Quais: [listar]

### Situacao do Acusado
- [ ] Preso preventivamente
- [ ] Em liberdade provisoria
- [ ] Em cumprimento de medidas cautelares

## TESES DA DEFESA
- [principais argumentos defensivos]

## RESUMO
- Total de crimes imputados: X
- Pena maxima possivel: X anos
- Acusado preso: Sim/Nao
- Fase atual: [Denuncia/Instrucao/Sentenca]"""
        else:
            prompt = """Analise os documentos do processo CIVEL e EXTRAIA TODOS OS PEDIDOS formulados.

Para cada pedido, identifique:
1. TIPO: Principal, Subsidiario, Alternativo, Tutela de Urgencia, Tutela de Evidencia
2. NATUREZA: Condenatorio, Declaratorio, Constitutivo, Mandamental, Executivo
3. DESCRICAO: O que esta sendo pedido (resumo claro)
4. VALOR: Se houver valor especifico
5. STATUS: Deferido, Indeferido, Pendente, Parcialmente Deferido (se ja decidido)
6. FUNDAMENTO LEGAL: Artigos e leis citados

Estruture a resposta assim:

## PEDIDOS DE TUTELA DE URGENCIA
[lista de pedidos liminares/antecipacao]

## PEDIDOS PRINCIPAIS DE MERITO
[lista dos pedidos principais]

## PEDIDOS SUBSIDIARIOS/ALTERNATIVOS
[lista se houver]

## RESUMO QUANTITATIVO
- Total de pedidos: X
- Valor total pleiteado: R$ X
- Pedidos ja decididos: X
- Pedidos pendentes: X"""

        resposta, modelo = await analisar_com_selecao_modelo(
            contexto=contexto,
            prompt=prompt,
            max_tokens=2000,
        )

        return {
            "sucesso": True,
            "numero_processo": numero_processo,
            "tipo_processo": tipo_processo,
            "pedidos": resposta,
            "modelo": modelo,
        }

    @mcp.tool
    async def analisar_decisao(
        numero_processo: str,
        tipo_decisao: str = "todas",
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Analisa decisoes judiciais do processo com profundidade.

        Extrai:
        - Dispositivo (o que foi decidido)
        - Fundamentacao (razoes de decidir)
        - Ratio decidendi vs obiter dictum
        - Precedentes citados

        Args:
            numero_processo: Numero do processo
            tipo_decisao: "sentenca", "acordao", "decisao", "despacho" ou "todas"

        Returns:
            Analise estruturada das decisoes
        """
        client = get_supabase_client()
        contexto = await client.obter_contexto_processo(
            numero_processo=numero_processo,
            incluir_docs=True,
            incluir_movs=True,
            max_chars=400000,
        )

        if not contexto or len(contexto) < 100:
            return {
                "erro": MSG_PROCESSO_NAO_ENCONTRADO.format(numero=numero_processo),
                "sucesso": False,
            }

        filtro = ""
        if tipo_decisao != "todas":
            filtro = f" Foque especialmente em: {tipo_decisao.upper()}"

        prompt = f"""Analise as DECISOES JUDICIAIS do processo.{filtro}

Para CADA decisao relevante, estruture:

### [TIPO DA DECISAO] - [DATA]

**1. DISPOSITIVO (O QUE FOI DECIDIDO)**
- Comando judicial claro
- Consequencias praticas

**2. FUNDAMENTACAO (RAZOES DE DECIDIR)**
- Argumentos juridicos utilizados
- Fatos considerados relevantes
- Provas valoradas

**3. RATIO DECIDENDI**
- Tese juridica central que fundamenta a decisao
- Precedentes que podem ser extraidos

**4. OBITER DICTUM**
- Consideracoes acessorias (se houver)

**5. PRECEDENTES E JURISPRUDENCIA CITADOS**
- Tribunais superiores mencionados
- Sumulas aplicadas

**6. IMPLICACOES PRATICAS**
- O que as partes devem fazer
- Prazos decorrentes
- Recursos cabiveis

---

Ao final, faca um RESUMO EXECUTIVO do estado decisorio do processo."""

        resposta, modelo = await analisar_com_selecao_modelo(
            contexto=contexto,
            prompt=prompt,
            max_tokens=2500,
        )

        return {
            "sucesso": True,
            "numero_processo": numero_processo,
            "tipo_filtro": tipo_decisao,
            "analise": resposta,
            "modelo": modelo,
        }

    @mcp.tool
    async def identificar_prazos(
        numero_processo: str,
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Identifica todos os prazos processuais relevantes.

        Detecta:
        - Prazos ja vencidos
        - Prazos em curso
        - Prazos futuros previstos
        - Intimacoes pendentes

        Args:
            numero_processo: Numero do processo

        Returns:
            Lista de prazos com status e datas
        """
        client = get_supabase_client()

        # Busca movimentacoes recentes para prazos
        movs = await client.listar_movimentacoes(numero_processo, limite=100)
        timeline = await client.timeline_processo(numero_processo, limite=50)

        if not movs and not timeline:
            return {"erro": f"Processo {numero_processo} sem movimentacoes", "sucesso": False}

        # Formata contexto
        movs_text = "\n".join(
            f"- [{m.get('data_hora')}] {m.get('tipo_nome')}: {m.get('descricao')}"
            for m in movs[:50]
        )

        prompt = f"""Analise as movimentacoes e IDENTIFIQUE TODOS OS PRAZOS PROCESSUAIS.

MOVIMENTACOES:
{movs_text}

Para cada prazo identificado, informe:

## PRAZOS IDENTIFICADOS

| Data Inicio | Prazo | Tipo | Parte | Status | Data Limite |
|-------------|-------|------|-------|--------|-------------|

### DETALHAMENTO:

**PRAZOS VENCIDOS (acao necessaria)**
- [lista com consequencias]

**PRAZOS EM CURSO**
- [lista com dias restantes]

**PRAZOS PREVISTOS/FUTUROS**
- [lista com eventos que dispararao prazos]

**INTIMACOES PENDENTES**
- [intimacoes ainda nao cumpridas]

### ALERTAS CRITICOS
[Situacoes que exigem atencao imediata]

### CALENDARIO SUGERIDO
[Proximas acoes recomendadas com datas]"""

        resposta, modelo = await analisar_com_selecao_modelo(
            contexto=movs_text,
            prompt=prompt,
            max_tokens=1500,
        )

        return {
            "sucesso": True,
            "numero_processo": numero_processo,
            "total_movimentacoes": len(movs),
            "prazos": resposta,
            "modelo": modelo,
        }

    # ==================== ANALISE ESTRATEGICA ====================

    @mcp.tool
    async def analise_risco(
        numero_processo: str,
        perspectiva: str = "parte_ativa",
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Analise de risco processual completa.

        Avalia:
        - Probabilidade de exito
        - Riscos juridicos e processuais
        - Riscos financeiros (civel) ou penais (criminal)
        - Recomendacoes estrategicas

        Args:
            numero_processo: Numero do processo
            perspectiva: Perspectiva da analise:
                - Civel: "autor", "reu", "terceiro"
                - Criminal: "acusado", "ministerio_publico", "vitima", "defensor"
                - Neutro: "juiz", "assessor"

        Returns:
            Matriz de riscos e recomendacoes
        """
        client = get_supabase_client()

        # Detecta tipo de processo
        tipo_processo = await client.detectar_tipo_processo(numero_processo)

        contexto = await client.obter_contexto_processo(
            numero_processo=numero_processo,
            incluir_docs=True,
            incluir_movs=True,
            max_chars=400000,
        )

        if not contexto or len(contexto) < 100:
            return {
                "erro": MSG_PROCESSO_NAO_ENCONTRADO.format(numero=numero_processo),
                "sucesso": False,
            }

        # Normaliza perspectiva
        perspectiva_upper = perspectiva.upper().replace("_", " ")

        if tipo_processo == "criminal":
            prompt = f"""Realize uma ANALISE DE RISCO COMPLETA do processo CRIMINAL, sob a perspectiva do {perspectiva_upper}.

## 1. PROBABILIDADE DE RESULTADO

### Para a ACUSACAO:
- Chance de condenacao: X%
- Chance de absolvicao: X%

### Fatores Considerados:
- Solidez da prova acusatoria
- Qualidade da defesa tecnica
- Jurisprudencia aplicavel
- Perfil do juizo/vara criminal

## 2. MATRIZ DE RISCOS

| Risco | Probabilidade | Impacto | Score | Mitigacao |
|-------|---------------|---------|-------|-----------|
| [Risco 1] | Alta/Media/Baixa | Alto/Medio/Baixo | X | [acao] |

### 2.1 RISCOS PARA O ACUSADO
- Condenacao
- Agravamento de pena
- Prisao preventiva
- Perda de primariedade

### 2.2 RISCOS PROCESSUAIS
- Nulidades
- Prescricao
- Incompetencia
- Provas ilicitas

### 2.3 RISCOS PENAIS
- Pena privativa de liberdade estimada: [X anos]
- Regime inicial provavel: [fechado/semiaberto/aberto]
- Multa estimada: R$ X
- Efeitos secundarios da condenacao

## 3. CENARIOS

**MELHOR CENARIO (PARA DEFESA):**
Absolvicao - Probabilidade: X%

**CENARIO INTERMEDIARIO:**
Condenacao com pena minima - Probabilidade: X%

**PIOR CENARIO (PARA DEFESA):**
Condenacao com pena maxima - Probabilidade: X%

## 4. RECOMENDACOES ESTRATEGICAS

**PARA A DEFESA:**
- Teses defensivas mais fortes
- Nulidades a arguir
- Recursos cabiveis

**CONSIDERAR:**
- Acordo de nao persecucao penal (ANPP)?
- Transacao penal?
- Colaboracao premiada?
- Recursos especiais/extraordinarios?"""
        else:
            prompt = f"""Realize uma ANALISE DE RISCO COMPLETA do processo CIVEL, sob a perspectiva do {perspectiva_upper}.

## 1. PROBABILIDADE DE EXITO
Avalie de 0-100% a chance de vitoria, considerando:
- Solidez dos argumentos juridicos
- Qualidade das provas
- Jurisprudencia predominante
- Historico do juizo

## 2. MATRIZ DE RISCOS

| Risco | Probabilidade | Impacto | Score | Mitigacao |
|-------|---------------|---------|-------|-----------|
| [Juridico 1] | Alta/Media/Baixa | Alto/Medio/Baixo | X | [acao] |
| [Processual 1] | ... | ... | ... | ... |
| [Financeiro 1] | ... | ... | ... | ... |

### 2.1 RISCOS JURIDICOS
- Fragilidades na tese
- Contradicoes com jurisprudencia
- Lacunas probatorias

### 2.2 RISCOS PROCESSUAIS
- Nulidades potenciais
- Preclusoes
- Recursos pendentes

### 2.3 RISCOS FINANCEIROS
- Custas e honorarios
- Sucumbencia estimada
- Execucao provisoria

## 3. CENARIOS

**MELHOR CENARIO:**
[Descricao e probabilidade]

**CENARIO PROVAVEL:**
[Descricao e probabilidade]

**PIOR CENARIO:**
[Descricao e probabilidade]

## 4. RECOMENDACOES ESTRATEGICAS

**ACOES IMEDIATAS:**
1. [acao prioritaria]

**ACOES DE MEDIO PRAZO:**
1. [acao tatica]

**CONSIDERAR:**
- Acordo? Valor sugerido
- Recurso? Viabilidade
- Desistencia? Quando considerar"""

        resposta, modelo = await analisar_com_selecao_modelo(
            contexto=contexto,
            prompt=prompt,
            max_tokens=2500,
        )

        return {
            "sucesso": True,
            "numero_processo": numero_processo,
            "tipo_processo": tipo_processo,
            "perspectiva": perspectiva,
            "analise": resposta,
            "modelo": modelo,
        }

    @mcp.tool
    async def argumentos_por_polo(
        numero_processo: str,
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Extrai e organiza argumentos de cada polo processual.

        Funciona para processos CIVEIS e CRIMINAIS:

        Civel:
        - Teses do autor vs reu
        - Preliminares e merito

        Criminal:
        - Teses do MP/Acusacao vs Defesa
        - Materialidade e autoria

        Args:
            numero_processo: Numero do processo

        Returns:
            Argumentos estruturados por polo
        """
        client = get_supabase_client()

        # Detecta tipo de processo
        tipo_processo = await client.detectar_tipo_processo(numero_processo)

        contexto = await client.obter_contexto_processo(
            numero_processo=numero_processo,
            incluir_docs=True,
            incluir_movs=False,
            max_chars=400000,
        )

        if not contexto or len(contexto) < 100:
            return {
                "erro": MSG_PROCESSO_NAO_ENCONTRADO.format(numero=numero_processo),
                "sucesso": False,
            }

        if tipo_processo == "criminal":
            prompt = """Analise o processo CRIMINAL e EXTRAIA OS ARGUMENTOS de cada polo.

## ACUSACAO (MP / QUERELANTE)

### Tese Acusatoria
[Imputacao penal e sua fundamentacao]

### Materialidade
[Como a acusacao prova que o crime ocorreu]
1. [prova de materialidade 1]
2. [prova de materialidade 2]

### Autoria
[Como a acusacao imputa o crime ao acusado]
1. [elemento de autoria 1]
2. [elemento de autoria 2]

### Provas Acusatorias
- [prova 1 e o que pretende demonstrar]

### Pedido de Pena
- Pena requerida: [X anos]
- Regime: [fechado/semiaberto/aberto]

---

## DEFESA (ACUSADO / DEFENSOR)

### Tese Defensiva Principal
[Argumento central da defesa: negativa de autoria, excludente, atipicidade, etc.]

### Preliminares (se houver)
1. [nulidade alegada]
2. [incompetencia, etc.]

### Teses de Merito
1. [tese defensiva 1]
2. [tese defensiva 2]

### Provas Defensivas
- [prova 1 e o que pretende demonstrar]

---

## ANALISE COMPARATIVA

### Pontos Controvertidos
| Tema | Posicao Acusacao | Posicao Defesa | Prova Pendente |
|------|------------------|----------------|----------------|

### Fatos Incontroversos
- [fatos aceitos por ambas as partes]

### Avaliacao da Forca dos Argumentos
| Argumento | Polo | Forca (1-5) | Justificativa |
|-----------|------|-------------|---------------|

### Questoes a Serem Decididas
1. [materialidade]
2. [autoria]
3. [excludentes]
4. [dosimetria da pena]"""
        else:
            prompt = """Analise o processo CIVEL e EXTRAIA OS ARGUMENTOS de cada polo processual.

## POLO ATIVO (AUTOR / REQUERENTE)

### Tese Principal
[Argumento central da pretensao]

### Fundamentos Faticos
1. [fato alegado 1]
2. [fato alegado 2]

### Fundamentos Juridicos
1. [base legal 1]
2. [base legal 2]

### Provas Apresentadas
- [prova 1 e o que pretende demonstrar]

---

## POLO PASSIVO (REU / REQUERIDO)

### Defesa Principal
[Argumento central da defesa]

### Preliminares (se houver)
1. [preliminar 1]

### Merito - Contestacao
1. [argumento de defesa 1]

### Provas Apresentadas
- [prova 1 e o que pretende demonstrar]

---

## ANALISE COMPARATIVA

### Pontos Controvertidos
| Tema | Posicao Autor | Posicao Reu | Prova Necessaria |
|------|---------------|-------------|------------------|

### Pontos Incontroversos
- [fatos aceitos por ambas as partes]

### Avaliacao da Forca dos Argumentos
| Argumento | Polo | Forca (1-5) | Justificativa |
|-----------|------|-------------|---------------|

### Questoes a Serem Decididas
1. [questao juridica central]
2. [questao fatica central]"""

        resposta, modelo = await analisar_com_selecao_modelo(
            contexto=contexto,
            prompt=prompt,
            max_tokens=2500,
        )

        return {
            "sucesso": True,
            "numero_processo": numero_processo,
            "tipo_processo": tipo_processo,
            "argumentos": resposta,
            "modelo": modelo,
        }

    @mcp.tool
    async def cronologia_detalhada(
        numero_processo: str,
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Gera cronologia detalhada e estruturada do processo.

        Funciona para processos CIVEIS e CRIMINAIS:

        Civel (CPC): Postulatoria > Saneadora > Instrutoria > Decisoria > Recursal
        Criminal (CPP): Investigacao > Denuncia > Resposta > Instrucao > Julgamento > Recursal > Execucao

        Args:
            numero_processo: Numero do processo

        Returns:
            Timeline estruturada com analise
        """
        client = get_supabase_client()

        # Detecta tipo de processo
        tipo_processo = await client.detectar_tipo_processo(numero_processo)

        # Busca dados
        processo = await client.processo_completo(numero_processo)
        movs = await client.listar_movimentacoes(numero_processo, limite=200)

        if not movs:
            return {"erro": f"Processo {numero_processo} sem movimentacoes", "sucesso": False}

        # Formata contexto
        movs_text = "\n".join(
            f"- [{m.get('data_hora')}] {m.get('tipo_nome')}: {m.get('descricao')}" for m in movs
        )

        if tipo_processo == "criminal":
            prompt = f"""Analise as movimentacoes e CONSTRUA UMA CRONOLOGIA ESTRUTURADA do processo CRIMINAL.

DATA INICIO: {processo.get("data_ajuizamento") if processo else "N/A"}

MOVIMENTACOES:
{movs_text}

Estruture a cronologia conforme as FASES DO PROCESSO PENAL (CPP):

## LINHA DO TEMPO

### FASE INVESTIGATORIA (Inquerito Policial)
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|
[Se houver inquerito anexado]

### FASE DE DENUNCIA/QUEIXA
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|
[Recebimento ou rejeicao da denuncia/queixa]

### FASE DE RESPOSTA A ACUSACAO
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|
[Resposta a acusacao, absolvicao sumaria]

### FASE DE INSTRUCAO
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|
[Audiencia de instrucao, oitiva de testemunhas, interrogatorio]

### FASE DE JULGAMENTO
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|
[Sentenca, acordao do juri]

### FASE RECURSAL (se houver)
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|
[Apelacao, recursos especiais/extraordinarios]

### FASE DE EXECUCAO PENAL (se houver)
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|
[Cumprimento de pena, progressao de regime]

---

## MARCOS CRITICOS
1. [evento mais importante 1]
2. [evento mais importante 2]

## METRICAS TEMPORAIS
- Tempo total do processo: X dias/meses/anos
- Tempo de prisao preventiva: X dias (se aplicavel)
- Fase mais longa: [fase] com X dias
- Periodos de inatividade: [datas]

## SITUACAO DO ACUSADO
- Preso ou em liberdade
- Medidas cautelares vigentes

## SITUACAO ATUAL
- Fase atual: [fase]
- Ultima movimentacao: [data e descricao]
- Proxima acao esperada: [previsao]"""
        else:
            prompt = f"""Analise as movimentacoes e CONSTRUA UMA CRONOLOGIA ESTRUTURADA do processo CIVEL.

DATA AJUIZAMENTO: {processo.get("data_ajuizamento") if processo else "N/A"}

MOVIMENTACOES:
{movs_text}

Estruture a cronologia conforme as FASES DO PROCESSO CIVIL (CPC):

## LINHA DO TEMPO

### FASE POSTULATORIA
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|

### FASE SANEADORA (se houver)
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|

### FASE INSTRUTORIA (se houver)
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|

### FASE DECISORIA
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|

### FASE RECURSAL (se houver)
| Data | Evento | Descricao | Impacto |
|------|--------|-----------|---------|

---

## MARCOS CRITICOS
1. [evento mais importante 1]
2. [evento mais importante 2]

## METRICAS TEMPORAIS
- Tempo total do processo: X dias/meses/anos
- Tempo medio entre movimentacoes: X dias
- Fase mais longa: [fase] com X dias
- Periodos de inatividade: [datas]

## SITUACAO ATUAL
- Fase atual: [fase]
- Ultima movimentacao: [data e descricao]
- Proxima acao esperada: [previsao]"""

        resposta, modelo = await analisar_com_selecao_modelo(
            contexto=movs_text,
            prompt=prompt,
            max_tokens=2000,
        )

        return {
            "sucesso": True,
            "numero_processo": numero_processo,
            "tipo_processo": tipo_processo,
            "total_movimentacoes": len(movs),
            "cronologia": resposta,
            "modelo": modelo,
        }

    # ==================== PARECER E RELATORIO ====================

    @mcp.tool
    async def parecer_juridico(
        numero_processo: str,
        questao_especifica: str | None = None,
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Gera parecer juridico estruturado sobre o processo.

        Segue formato profissional:
        - Ementa
        - Relatorio
        - Fundamentacao
        - Conclusao

        Args:
            numero_processo: Numero do processo
            questao_especifica: Questao juridica a responder (opcional)

        Returns:
            Parecer juridico completo
        """
        client = get_supabase_client()
        contexto = await client.obter_contexto_processo(
            numero_processo=numero_processo,
            incluir_docs=True,
            incluir_movs=True,
            max_chars=500000,
        )

        if not contexto or len(contexto) < 100:
            return {
                "erro": MSG_PROCESSO_NAO_ENCONTRADO.format(numero=numero_processo),
                "sucesso": False,
            }

        questao_texto = ""
        if questao_especifica:
            questao_texto = f"\n\nQUESTAO ESPECIFICA A RESPONDER: {questao_especifica}"

        prompt = f"""Elabore um PARECER JURIDICO profissional sobre o processo.{questao_texto}

# PARECER JURIDICO

## EMENTA
[Sintese do caso e conclusao em 3-5 linhas]

---

## I. RELATORIO

### 1. Identificacao
- Processo: [numero]
- Partes: [autor vs reu]
- Juizo: [vara/tribunal]
- Classe: [tipo de acao]

### 2. Sintese dos Fatos
[Narrativa cronologica dos fatos relevantes]

### 3. Questao Juridica
[A pergunta que precisa ser respondida]

---

## II. FUNDAMENTACAO

### 1. Legislacao Aplicavel
- [Lei/Artigo 1]
- [Lei/Artigo 2]

### 2. Doutrina
[Posicionamentos doutrinarios relevantes]

### 3. Jurisprudencia
[Precedentes aplicaveis]

### 4. Analise do Caso Concreto
[Aplicacao do direito aos fatos]

---

## III. CONCLUSAO

### Resposta Objetiva
[Resposta direta a questao juridica]

### Recomendacoes
1. [acao recomendada 1]
2. [acao recomendada 2]

### Ressalvas
[Pontos de atencao e riscos]

---

*Este parecer tem carater orientativo e nao substitui consulta a advogado.*"""

        resposta, modelo = await analisar_com_selecao_modelo(
            contexto=contexto,
            prompt=prompt,
            max_tokens=3000,
        )

        return {
            "sucesso": True,
            "numero_processo": numero_processo,
            "questao": questao_especifica,
            "parecer": resposta,
            "modelo": modelo,
        }

    @mcp.tool
    async def situacao_atual(
        numero_processo: str,
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Diagnostico rapido da situacao atual do processo.

        Funciona para processos CIVEIS e CRIMINAIS.

        Retorna:
        - Status atual
        - Fase processual (CPC ou CPP)
        - Pendencias
        - Proximos passos
        - Alertas

        Args:
            numero_processo: Numero do processo

        Returns:
            Diagnostico conciso do estado atual
        """
        client = get_supabase_client()

        # Detecta tipo de processo
        tipo_processo = await client.detectar_tipo_processo(numero_processo)

        # Busca dados essenciais
        processo = await client.processo_completo(numero_processo)
        stats = await client.stats_processo(numero_processo)
        movs = await client.listar_movimentacoes(numero_processo, limite=10)

        if not processo:
            return {
                "erro": MSG_PROCESSO_NAO_ENCONTRADO.format(numero=numero_processo),
                "sucesso": False,
            }

        ultima_mov = movs[0] if movs else None

        # Formata contexto minimo
        contexto = f"""PROCESSO: {numero_processo}
TIPO: {tipo_processo.upper()}
CLASSE: {processo.get("classe_descricao")}
TRIBUNAL: {processo.get("sigla_tribunal")}
VALOR: R$ {processo.get("valor_causa", 0):,.2f}
DATA AJUIZAMENTO: {processo.get("data_ajuizamento")}
TOTAL DOCS: {stats.get("docs_extraidos", 0) if stats else 0}
TOTAL MOVS: {stats.get("movs_sincronizados", 0) if stats else 0}

ULTIMA MOVIMENTACAO: {ultima_mov.get("data_hora") if ultima_mov else "N/A"} - {ultima_mov.get("descricao") if ultima_mov else "N/A"}

ULTIMAS 10 MOVIMENTACOES:
""" + "\n".join(f"- [{m.get('data_hora')}] {m.get('descricao')}" for m in movs)

        if tipo_processo == "criminal":
            prompt = """Faca um DIAGNOSTICO RAPIDO do processo CRIMINAL.

Responda de forma DIRETA e OBJETIVA:

## STATUS ATUAL
[Em uma linha: o que esta acontecendo agora]

## FASE PROCESSUAL (CPP)
[Investigacao/Denuncia/Resposta/Instrucao/Julgamento/Recursal/Execucao Penal]

## SITUACAO DO ACUSADO
- [ ] Preso preventivamente
- [ ] Em liberdade provisoria
- [ ] Cumprindo medidas cautelares
- [ ] Foragido
- [ ] Condenado em execucao

## PENDENCIAS IDENTIFICADAS
- [ ] [pendencia 1]
- [ ] [pendencia 2]

## PROXIMOS PASSOS ESPERADOS
1. [acao provavel 1]
2. [acao provavel 2]

## ALERTAS
[Pontos que exigem atencao imediata: prazos, prescricao, prisao, etc.]

## TEMPO DESDE ULTIMA MOVIMENTACAO
[X dias - normal/atencao/critico]"""
        else:
            prompt = """Faca um DIAGNOSTICO RAPIDO do processo CIVEL.

Responda de forma DIRETA e OBJETIVA:

## STATUS ATUAL
[Em uma linha: o que esta acontecendo agora]

## FASE PROCESSUAL (CPC)
[Postulatoria/Saneadora/Instrutoria/Decisoria/Recursal/Execucao]

## PENDENCIAS IDENTIFICADAS
- [ ] [pendencia 1]
- [ ] [pendencia 2]

## PROXIMOS PASSOS ESPERADOS
1. [acao provavel 1]
2. [acao provavel 2]

## ALERTAS
[Pontos que exigem atencao imediata, se houver]

## TEMPO DESDE ULTIMA MOVIMENTACAO
[X dias - normal/atencao/critico]"""

        resposta, modelo = await analisar_com_selecao_modelo(
            contexto=contexto,
            prompt=prompt,
            max_tokens=1000,
        )

        return {
            "sucesso": True,
            "numero_processo": numero_processo,
            "tipo_processo": tipo_processo,
            "classe": processo.get("classe_descricao"),
            "tribunal": processo.get("sigla_tribunal"),
            "ultima_movimentacao": ultima_mov.get("data_hora") if ultima_mov else None,
            "diagnostico": resposta,
            "modelo": modelo,
        }
