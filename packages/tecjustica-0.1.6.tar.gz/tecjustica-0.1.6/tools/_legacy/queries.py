"""Tools para queries complexas usando LLM."""

from typing import Any

from fastmcp import Context, FastMCP

from services.llm_service import get_llm_service
from services.supabase_client import get_supabase_client
from tools._helpers import analisar_com_selecao_modelo

# URL para sincronizar processos
SYNC_URL = "https://tecjusticamcp3.vercel.app/login"

# Mensagem padrao para processo nao encontrado
MSG_PROCESSO_NAO_ENCONTRADO = (
    "Processo {numero} nao encontrado no sistema. "
    f"Acesse {SYNC_URL} para sincronizar o processo antes de consultar."
)


def register_queries_tools(mcp: FastMCP) -> None:
    """Registra tools de queries com LLM no servidor MCP."""

    @mcp.tool
    async def perguntar(
        numero_processo: str,
        pergunta: str = "Faca uma analise completa deste processo",
        modelo: str | None = None,
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Pergunta sobre um processo usando LLM.

        Selecao automatica de modelo pelo tamanho do contexto:
        - <= 3M chars: Gemini Flash
        - > 3M chars: Grok Fast

        Args:
            numero_processo: Numero do processo
            pergunta: Pergunta em linguagem natural
            modelo: "gemini-flash", "grok-fast" ou None (automatico)

        Substitui: sobre_processo, perguntar (antiga)

        Returns:
            Resposta do LLM com modelo utilizado
        """
        if not pergunta or len(pergunta.strip()) < 5:
            return {
                "erro": "Pergunta muito curta",
                "sucesso": False,
            }

        client = get_supabase_client()
        contexto = await client.obter_contexto_processo(
            numero_processo=numero_processo,
            incluir_docs=True,
            incluir_movs=True,
            max_chars=500000,
        )

        if not contexto or len(contexto) < 100:
            return {
                "erro": MSG_PROCESSO_NAO_ENCONTRADO.format(numero=numero_processo),
                "sucesso": False,
            }

        # Se modelo especificado, usa direto
        if modelo:
            llm = get_llm_service()
            resposta = await llm.query(
                pergunta=pergunta,
                contexto=contexto,
                model=modelo,
                max_tokens=4000,
            )
            return {
                "sucesso": True,
                "modelo": modelo,
                "resposta": resposta.text,
            }

        # Selecao automatica de modelo
        resposta, modelo_usado = await analisar_com_selecao_modelo(
            contexto=contexto,
            prompt=pergunta,
            max_tokens=4000,
        )

        return {
            "sucesso": True,
            "modelo": modelo_usado,
            "resposta": resposta,
        }

    @mcp.tool
    async def comparar_documentos(
        document_ids: list[str],
        aspecto: str | None = None,
        ctx: Context = None,
    ) -> dict[str, Any]:
        """
        Compara 2-4 documentos.

        Args:
            document_ids: Lista de IDs (2-4)
            aspecto: Aspecto a comparar (opcional)

        Returns:
            Comparacao
        """
        if len(document_ids) < 2:
            return {"erro": "Minimo 2 documentos", "sucesso": False}
        if len(document_ids) > 4:
            return {"erro": "Maximo 4 documentos", "sucesso": False}

        client = get_supabase_client()
        docs = []
        for doc_id in document_ids:
            doc = await client.ler_documento(doc_id)
            if doc:
                docs.append(doc)

        if len(docs) < 2:
            return {"erro": "Documentos insuficientes", "sucesso": False}

        # Monta contexto
        partes = []
        for i, doc in enumerate(docs, 1):
            conteudo = (doc.get("conteudo") or "")[:50000]
            partes.append(f"""## DOC {i}: {doc.get("nome", "N/A")}
Tipo: {doc.get("tipo_nome") or doc.get("tipo")}
Data: {doc.get("data_juntada")}

{conteudo}""")

        contexto = "\n\n---\n\n".join(partes)

        pergunta = f"Compare os {len(docs)} documentos: diferencas, pontos em comum, evolucao."
        if aspecto:
            pergunta += f" Foque em: {aspecto}"

        llm = get_llm_service()
        resposta = await llm.query(
            pergunta=pergunta,
            contexto=contexto,
            model="gemini-flash",
            max_tokens=1500,
        )

        return {
            "sucesso": True,
            "documentos": [d.get("nome") for d in docs],
            "comparacao": resposta.text,
        }
