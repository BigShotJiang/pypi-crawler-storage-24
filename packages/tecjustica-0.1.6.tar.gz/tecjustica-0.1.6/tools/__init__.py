"""Tools do MCP Server TecJustica."""

from .analise import register_analise_tools
from .busca import register_busca_tools
from .estatisticas import register_estatisticas_tools
from .navegacao import register_navegacao_tools
from .precedentes import register_precedentes_tools
from .user import register_user_tools
from .utilidades import register_utilidades_tools

__all__ = [
    "register_analise_tools",
    "register_busca_tools",
    "register_estatisticas_tools",
    "register_navegacao_tools",
    "register_precedentes_tools",
    "register_user_tools",
    "register_utilidades_tools",
]
