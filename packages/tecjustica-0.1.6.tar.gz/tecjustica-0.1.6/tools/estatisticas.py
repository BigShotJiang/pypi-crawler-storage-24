"""Tools de estatisticas — contagens agregadas sem texto."""

import logging
import time
from typing import Any

from fastmcp import FastMCP

from services.supabase_client import get_supabase_client
from services.usage_logger import get_usage_logger, ms_since
from tools._helpers import (
    MSG_PROCESSO_NAO_ENCONTRADO,
    _get_current_user,
    erro_instrutivo,
)

logger = logging.getLogger("tecjustica-mcp.estatisticas")


def register_estatisticas_tools(mcp: FastMCP) -> None:
    """Registra tools de estatisticas."""

    @mcp.tool(annotations={"readOnlyHint": True, "openWorldHint": False})
    async def stats_documentos(
        numero_processo: str,
        fonte: str | None = None,
    ) -> dict[str, Any]:
        """
        Retorna estatisticas agregadas dos documentos de um processo, sem nenhum texto.

        QUANDO USAR:
        - Obter panorama quantitativo: total de docs, tipos, tamanhos, periodo
        - Entender a composicao do processo antes de buscar documentos
        - Planejar estrategia de leitura (quantos docs, quais tipos existem)
        - Ver breakdown por fonte (api vs segmentation) no campo por_fonte

        QUANDO NAO USAR:
        - Quer listar documentos individuais → use ls_documentos()
        - Quer ler conteudo → use read_documento()
        - Quer visao geral completa (com partes, movs) → use visao_geral_processo()

        Args:
            numero_processo: Numero CNJ do processo (formato NNNNNNN-DD.AAAA.J.TR.OOOO).
            fonte: Filtrar por origem dos dados: "api" ou "segmentation" (opcional, default=ambas).

        Returns:
            Contagens por tipo, por sigilo, por fonte, tamanhos totais, periodo dos documentos.
        """
        _start = time.perf_counter()
        user_id, user_email = _get_current_user()

        try:
            sb = get_supabase_client().client

            response = sb.rpc(
                "stats_documentos",
                {"p_numero_processo": numero_processo, "p_source": fonte},
            ).execute()

            dados = response.data
            if isinstance(dados, list) and dados:
                dados = dados[0]

            if not dados or dados.get("total_documentos", 0) == 0:
                try:
                    get_usage_logger().log_tool_call(
                        tool_name="stats_documentos",
                        duration_ms=ms_since(_start),
                        user_id=user_id,
                        user_email=user_email,
                        success=False,
                        error_message="processo_sem_documentos",
                        params={"numero_processo": numero_processo},
                    )
                except Exception:
                    pass
                return erro_instrutivo(
                    MSG_PROCESSO_NAO_ENCONTRADO,
                    "Use listar_processos() para ver processos disponiveis.",
                )

            try:
                get_usage_logger().log_tool_call(
                    tool_name="stats_documentos",
                    duration_ms=ms_since(_start),
                    user_id=user_id,
                    user_email=user_email,
                    params={"numero_processo": numero_processo, "fonte": fonte},
                )
            except Exception:
                pass
            return dados
        except Exception as e:
            try:
                get_usage_logger().log_tool_call(
                    tool_name="stats_documentos",
                    duration_ms=ms_since(_start),
                    user_id=user_id,
                    user_email=user_email,
                    success=False,
                    error_message=str(e),
                )
            except Exception:
                pass
            return erro_instrutivo(str(e), "Verifique o numero do processo.")
