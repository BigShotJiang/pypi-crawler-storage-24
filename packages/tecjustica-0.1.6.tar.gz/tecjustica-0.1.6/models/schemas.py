"""Pydantic models para o MCP Server TecJustica."""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class Parte(BaseModel):
    """Parte do processo (autor, reu, etc)."""

    nome: str
    tipo: str
    polo: str | None = None
    cpf_cnpj: str | None = None
    advogados: list[str] = Field(default_factory=list)


class Assunto(BaseModel):
    """Assunto do processo."""

    codigo: int
    nome: str
    principal: bool = False


class Processo(BaseModel):
    """Metadados basicos do processo judicial."""

    id: str
    numero_processo: str
    sigla_tribunal: str | None = None
    nome_tribunal: str | None = None
    classe_descricao: str | None = None
    instancia: str | None = None
    natureza: str | None = None
    valor_causa: float | None = None
    data_ajuizamento: datetime | None = None
    justica_gratuita: bool = False
    orgao_julgador_nome: str | None = None
    cidade_nome: str | None = None
    uf: str | None = None


class ProcessoCompleto(Processo):
    """Processo com todos os dados incluindo partes e assuntos."""

    partes: list[dict[str, Any]] = Field(default_factory=list)
    assuntos: list[dict[str, Any]] = Field(default_factory=list)
    markdown: str | None = None
    total_docs: int = 0
    total_movs: int = 0
    total_chars: int = 0


class Documento(BaseModel):
    """Documento do processo."""

    id: str
    numero_processo: str
    tipo: str | None = None
    tipo_nome: str | None = None
    nome: str | None = None
    sequencia: int | None = None
    nivel_sigilo: str | None = None
    data_juntada: datetime | None = None
    paginas: int | None = None
    tamanho_bytes: int | None = None
    metodo_extracao: str | None = None
    conteudo: str | None = None
    signatarios: list[str] = Field(default_factory=list)


class DocumentoPreview(BaseModel):
    """Preview de documento com texto truncado."""

    id: str
    numero_processo: str
    tipo: str | None = None
    nome: str | None = None
    sequencia: int | None = None
    nivel_sigilo: str | None = None
    data_juntada: datetime | None = None
    paginas: int | None = None
    tamanho_chars: int | None = None
    preview: str | None = None
    truncated: bool = False


class Movimentacao(BaseModel):
    """Movimentacao processual."""

    id: str
    numero_processo: str
    sequencia: int
    data_hora: datetime
    descricao: str
    tipo_nome: str | None = None
    tipo_descricao: str | None = None
    orgao_julgador_nome: str | None = None
    documento_id: str | None = None
    magistrado_nome: str | None = None
    usuario_nome: str | None = None


class TimelineEvent(BaseModel):
    """Evento na timeline do processo (movimentacao ou documento)."""

    numero_processo: str
    tipo_evento: str  # 'movimentacao' ou 'documento'
    data: datetime | None = None
    descricao: str | None = None
    documento_id: str | None = None
    tamanho_bytes: int | None = None


class StatsProcesso(BaseModel):
    """Estatisticas do processo."""

    numero_processo: str
    classe_descricao: str | None = None
    valor_causa: float | None = None
    sigla_tribunal: str | None = None
    instancia: str | None = None
    natureza: str | None = None
    total_docs_api: int | None = None
    total_movs_api: int | None = None
    docs_extraidos: int = 0
    movs_sincronizados: int = 0
    tamanho_total_bytes: int | None = None
    media_paginas: float | None = None
    docs_sigilosos: int = 0
    docs_ocr: int = 0


class QueryResult(BaseModel):
    """Resultado de uma query em linguagem natural."""

    pergunta: str
    resposta: str
    numero_processo: str
    contexto_usado: int  # chars de contexto utilizados
    modelo: str
    tokens_utilizados: int | None = None
