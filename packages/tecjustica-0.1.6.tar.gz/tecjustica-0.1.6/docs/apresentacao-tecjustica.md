# TecJustiça MCP: Um Explorador Inteligente da Base Judicial para Qualquer IA

## O Problema Não é Falta de IA — É Falta de Acesso Inteligente aos Dados

Não faltam ferramentas de inteligência artificial. O Claude, o ChatGPT, o Gemini, o Manus — todos são capazes de ler, resumir, analisar e responder perguntas sobre textos jurídicos com qualidade impressionante. Muitos magistrados, assessores e servidores já usam essas ferramentas no dia a dia.

O problema é que **nenhuma delas consegue acessar os dados do seu tribunal**.

Hoje, quem quer usar IA para analisar um processo precisa fazer um trabalho artesanal: abrir o PJE, copiar o documento, colar no ChatGPT, fazer a pergunta, repetir para o próximo documento. Isso funciona para um documento. Não funciona para 200.

A proposta do TecJustiça é simples: **cada magistrado, servidor e assessor continua usando a IA que já usa, o fluxo que já conhece.** O TecJustiça entra como um explorador inteligente da base judicial — dando a qualquer IA a capacidade de navegar, buscar e analisar processos diretamente, sem copiar e colar nada.

---

## MCP: O "USB" da Inteligência Artificial

O **Model Context Protocol (MCP)** é um protocolo aberto, criado pela Anthropic e adotado por toda a indústria de IA. Ele funciona como um padrão universal de conexão — da mesma forma que o USB permitiu que qualquer dispositivo se conectasse a qualquer computador, o MCP permite que **qualquer IA se conecte a qualquer fonte de dados**.

```mermaid
flowchart TB
    subgraph IAs["Qualquer IA"]
        C["Claude"]
        G["ChatGPT"]
        M["Manus"]
        L["Agentes\ncustomizados"]
    end

    subgraph MCP["TecJustiça MCP Server"]
        T["Protocolo MCP\n(conexão padronizada)"]
    end

    subgraph Dados["Dados do Tribunal"]
        P["Processos"]
        D["Documentos"]
        MV["Movimentações"]
        PR["Precedentes\n(BNP/CNJ)"]
    end

    C --> T
    G --> T
    M --> T
    L --> T
    T --> P
    T --> D
    T --> MV
    T --> PR

    style IAs fill:#ebf8ff,stroke:#2b6cb0,color:#1a365d
    style MCP fill:#f0fff4,stroke:#2f855a,color:#1a365d
    style Dados fill:#fffff0,stroke:#744210,color:#1a365d
```

O TecJustiça é um **MCP Server** — mas não é uma ponte passiva que simplesmente repassa dados do tribunal para a IA. Ele **prepara, organiza e disponibiliza ferramentas inteligentes** que permitem que qualquer agente de IA explore os dados judiciais de forma eficiente e estratégica. Não é um chatbot. Não é um aplicativo. É **infraestrutura inteligente**.

---

## O que Isso Significa na Prática?

### Continue usando o que você já usa. O TecJustiça se encaixa.

O ponto central é este: **ninguém precisa mudar seu fluxo de trabalho.** Ninguém precisa aprender uma ferramenta nova. Ninguém precisa trocar o ChatGPT pelo Claude ou vice-versa.

- O magistrado que já usa o **Claude** no navegador? Conecta o TecJustiça e o Claude passa a enxergar seus processos.
- O assessor que prefere o **ChatGPT**? Mesma coisa — conecta e funciona.
- A equipe que usa o **Manus** para automação? Conecta e ganha um agente que navega nos autos.
- O núcleo de inovação que está construindo **agentes customizados**? Conecta e tem 13 ferramentas especializadas à disposição.

Cada pessoa, cada unidade, cada vara continua com sua IA preferida, seu fluxo preferido. O TecJustiça não é a IA — é o **explorador inteligente** que dá a qualquer IA acesso à base judicial do tribunal.

**O tribunal não cria mais um sistema para as pessoas aprenderem.** O tribunal cria a infraestrutura que faz os sistemas que as pessoas já usam ficarem mais poderosos.

---

## Como Funciona: 3 Linhas de Configuração

Conectar uma IA ao TecJustiça é tão simples quanto adicionar uma URL.

### No Claude (claude.ai)

1. Vá em **Settings > Connectors**
2. Adicione a URL: `https://mcp.tecjustica.com/mcp`
3. Faça login com sua conta do tribunal
4. Pronto. O Claude agora enxerga seus processos.

### No Manus

1. Vá em **Settings > MCP Servers**
2. Adicione o servidor com a URL e seu token
3. Pronto. O Manus agora pode navegar nos autos.

### Em qualquer ferramenta com suporte a MCP

```json
{
  "mcpServers": {
    "tecjustica": {
      "url": "https://mcp.tecjustica.com/mcp"
    }
  }
}
```

Três linhas. Sem instalação de software. Sem integração complexa. A IA ganha **13 ferramentas especializadas** para navegar, buscar e analisar processos judiciais.

---

## Mais do que Dados: Ferramentas Inteligentes para a IA

Aqui está o ponto que diferencia o TecJustiça de simplesmente "expor uma API do tribunal".

Uma API convencional entrega dados brutos: JSON, tabelas, campos. A IA recebe tudo de uma vez e tenta se virar. É como entregar 500 páginas de autos empilhadas na mesa de alguém e dizer "se vira".

O TecJustiça faz o oposto. Ele entrega **13 ferramentas especializadas** que ensinam a IA a trabalhar como um profissional jurídico experiente — navegando pelos autos de forma estratégica, buscando exatamente o que precisa, lendo apenas os trechos relevantes.

```mermaid
flowchart TB
    subgraph D["1. Descobrir"]
        D1["Listar processos"]
        D2["Visão geral instantânea\n(partes, pedidos, valores, status)"]
    end

    subgraph B["2. Buscar"]
        B1["Busca por palavras-chave\ndentro do conteúdo dos documentos"]
        B2["Busca em movimentações"]
        B3["Filtrar documentos\npor tipo ou categoria"]
        B4["Localizar trechos\nexatos em um documento"]
    end

    subgraph A["3. Ler e Analisar"]
        A1["Leitura controlada\n(trecho específico, não o documento inteiro)"]
        A2["Análise sob perspectiva\n(autor, réu, juiz, MP)"]
        A3["Buscar precedentes\nno BNP/CNJ"]
        A4["Estatísticas\ndo processo"]
    end

    D --> B --> A

    style D fill:#ebf8ff,stroke:#2b6cb0,color:#1a365d
    style B fill:#f0fff4,stroke:#2f855a,color:#1a365d
    style A fill:#fffff0,stroke:#744210,color:#1a365d
```

### Por que isso importa?

Imagine um processo com 200 documentos e 3.000 páginas de conteúdo. Nenhuma IA do mundo consegue processar tudo isso de uma vez — há limites técnicos de contexto. E mesmo que conseguisse, seria um desperdício: a maioria das perguntas exige informação de 5 ou 10 páginas, não de 3.000.

O TecJustiça resolve isso com um design inspirado em como sistemas operacionais organizam arquivos:

| Ferramenta | Analogia | O que faz |
|-----------|----------|-----------|
| **Listar processos** | Abrir a pasta | Descobre o que existe, busca por nome de parte |
| **Visão geral** | Ler o cabeçalho | Entende o caso em segundos: partes, valores, status, últimas movimentações |
| **Busca no conteúdo** | `Ctrl+F` turbinado | Procura palavras, frases ou padrões **dentro** dos documentos — não apenas nos títulos |
| **Leitura controlada** | Abrir na página certa | Lê apenas o trecho necessário de um documento, com controle de posição e tamanho |
| **Localizar no documento** | Marcador de página | Encontra todas as ocorrências de um termo e mostra o contexto ao redor |
| **Análise com IA** | O parecer do assessor | Analisa o processo sob a perspectiva escolhida (autor, réu, juiz, MP) |
| **Precedentes** | Pesquisa jurisprudencial | Consulta o Banco Nacional de Precedentes do CNJ |

**O resultado:** a IA não recebe um "textão" e tenta se virar. Ela navega pelos autos com a mesma lógica que um profissional experiente usaria — mas em segundos, não em horas.

### Exemplo concreto: como a IA analisa um processo complexo

Quando você pergunta *"Houve prescrição neste processo?"*, a IA não tenta ler todos os 200 documentos. Ela faz o seguinte:

1. **Visão geral** — entende o tipo de processo, as partes, o valor, o status
2. **Busca por "prescrição"** — encontra quais documentos e movimentações mencionam o termo
3. **Busca por "citação", "arquivamento", "desarquivamento"** — localiza marcos temporais relevantes
4. **Leitura controlada** — lê apenas os trechos específicos onde esses termos aparecem
5. **Análise** — cruza as informações e responde com fundamentação

São 5 chamadas cirúrgicas em vez de um dump de 3.000 páginas. Mais rápido, mais preciso, mais barato.

Isso é fundamentalmente diferente de colar um PDF no ChatGPT. E é fundamentalmente diferente de uma API que simplesmente entrega JSON bruto.

---

## Cenários Reais

### Magistrado preparando pauta de audiências

> *"Tenho 10 audiências amanhã. Me dê uma visão geral de cada processo, focando nos pontos controvertidos."*

A IA acessa os 10 processos via TecJustiça, lê as petições iniciais e contestações, e entrega um briefing estruturado de cada caso — com os pontos que merecem atenção na audiência.

**Antes:** uma noite inteira lendo autos. **Depois:** uma conversa de 15 minutos com a IA.

### Servidor triando processos urgentes

> *"Quais dos processos distribuídos esta semana têm pedido de tutela de urgência?"*

A IA busca **no conteúdo** dos documentos (não apenas nos metadados) e identifica quais processos mencionam tutela de urgência, liminar, alimentos provisórios — com o trecho exato onde o pedido aparece.

### Assessor pesquisando precedentes

> *"Busque precedentes do STJ sobre responsabilidade civil objetiva em acidente de trânsito e compare com os fatos deste processo."*

A IA consulta o Banco Nacional de Precedentes (BNP/CNJ), cruza com os fatos narrados nos autos, e indica quais precedentes se aplicam ao caso concreto.

### Juiz analisando caso complexo

> *"Este processo tem 200 documentos. Quais são as datas relevantes para análise de prescrição? Houve período superior a 5 anos sem manifestação do exequente?"*

A IA varre todos os documentos e movimentações, monta a linha do tempo, e responde com referência exata às fontes.

---

## Por que MCP e Não um Aplicativo Próprio?

| | Aplicativo tradicional | TecJustiça (MCP) |
|--|----------------------|------------------|
| **Interface** | Uma só, fixa | Qualquer IA: Claude, ChatGPT, Manus, agentes custom |
| **Atualização da IA** | Depende do fornecedor | Troca a IA quando quiser, sem perder a conexão |
| **Customização** | Limitada ao que foi previsto | Ilimitada — cada equipe usa como quiser |
| **Vendor lock-in** | Alto | Zero — protocolo aberto (MCP é padrão de mercado) |
| **Integração com outros sistemas** | Desenvolvimento caso a caso | Qualquer MCP Server se conecta da mesma forma |
| **Inteligência na camada de dados** | A IA recebe dados brutos e se vira | Ferramentas especializadas guiam a IA a navegar, buscar e ler de forma eficiente |
| **Custo de manutenção** | Interface + backend + IA | Apenas a conexão com os dados |

O MCP é um **padrão aberto** mantido pela indústria. Não é tecnologia proprietária. Quem adota MCP está investindo em infraestrutura que vai evoluir com o ecossistema inteiro de IA — não em um produto que pode ficar obsoleto.

---

## Segurança e Privacidade

| Proteção | Como funciona |
|----------|---------------|
| **Isolamento de dados** | Cada usuário acessa apenas seus processos. A IA não vê dados de outros usuários. |
| **Autenticação forte** | OAuth 2.1 — o mesmo padrão usado por bancos e serviços governamentais. |
| **Sem cópia de dados** | A IA consulta os dados sob demanda e descarta o contexto. Não cria banco paralelo. |
| **Auditoria completa** | Toda consulta é registrada: quem acessou, o que pediu, quando. |
| **LGPD** | Dados pessoais sensíveis tratados conforme a Lei Geral de Proteção de Dados. |
| **Protocolo aberto** | MCP é auditável e transparente — sem caixas-pretas. |

Os dados **permanecem sob controle do tribunal**. O TecJustiça é uma camada de acesso inteligente — não armazena, não exporta, não compartilha.

---

## Escalabilidade: Do TJ-PB para Todo o Judiciário

A arquitetura do TecJustiça é **tribunal-agnóstica**. A mesma infraestrutura que funciona para o TJ da Paraíba funciona para qualquer tribunal.

```mermaid
flowchart TB
    subgraph IAs["IAs dos Usuários"]
        IA1["Claude / ChatGPT / Manus / Agentes"]
    end

    subgraph Servers["MCP Servers (um por tribunal)"]
        S1["TecJustiça\nTJ-PB"]
        S2["TecJustiça\nTJ-SP"]
        S3["TecJustiça\nTJ-MG"]
        S4["TecJustiça\nTRF-5"]
        S5["TecJustiça\nTRT-13"]
    end

    subgraph Fonte["Fonte de Dados"]
        API["API padronizada\n(PDPJ/CNJ)"]
    end

    IA1 --> S1
    IA1 --> S2
    IA1 --> S3
    IA1 --> S4
    IA1 --> S5

    S1 --> API
    S2 --> API
    S3 --> API
    S4 --> API
    S5 --> API

    style IAs fill:#ebf8ff,stroke:#2b6cb0,color:#1a365d
    style Servers fill:#f0fff4,stroke:#2f855a,color:#1a365d
    style Fonte fill:#fffff0,stroke:#744210,color:#1a365d
```

**O que muda entre tribunais?** Apenas a fonte de dados. As 13 ferramentas, a lógica de análise, a segurança — tudo permanece igual. E como o Judiciário brasileiro já caminha para padronização via PDPJ (Plataforma Digital do Poder Judiciário), conectar um novo tribunal é questão de configuração.

**Potencial de escala:**
- 27 Tribunais de Justiça estaduais
- 5 Tribunais Regionais Federais
- 24 Tribunais Regionais do Trabalho
- Tribunais Superiores (STJ, TST, TSE)

E mais: um magistrado que atua em diferentes tribunais pode conectar **múltiplos MCP Servers** na mesma IA — e perguntar sobre processos de jurisdições diferentes na mesma conversa.

---

## Por que Agora?

**O MCP já é padrão de mercado.** Claude, ChatGPT, Gemini, Copilot — todos já suportam MCP. O protocolo deixou de ser experimental e virou infraestrutura. Tribunais que adotam agora se posicionam na vanguarda.

**A IA já é capaz.** Modelos atuais compreendem linguagem jurídica, interpretam contexto processual e mantêm precisão mesmo em documentos extensos. A barreira não é mais a qualidade da IA — é o acesso aos dados.

**O volume processual exige.** Com ~6.000 processos por magistrado, ganhos de produtividade não são luxo — são necessidade. Ferramentas que multipliquem a capacidade de análise têm impacto direto na prestação jurisdicional.

---

## Próximos Passos

### Piloto no TJ-PB

| Item | Detalhe |
|------|---------|
| **Varas** | 2 a 3 varas cíveis e/ou criminais |
| **Duração** | 3 a 6 meses |
| **Usuários** | Magistrados, assessores e servidores das varas selecionadas |
| **IA** | Livre escolha dos participantes (Claude, ChatGPT, Manus, etc.) |

### Métricas de Impacto Esperadas

| Indicador | Meta |
|-----------|------|
| Tempo de preparação de audiências | Redução de 50-70% |
| Tempo de triagem de processos urgentes | Redução de 60-80% |
| Tempo de pesquisa de precedentes | Redução de 70-90% |
| Satisfação dos usuários | Acima de 80% de aprovação |

### O TecJustiça já está em operação

O servidor MCP está funcional e em produção. O próximo passo é conectá-lo aos dados do tribunal e iniciar o piloto.

---

**Marcos Fonseca**
Desenvolvedor — TecJustiça
marcosmarf27@gmail.com

---

*O TecJustiça não é mais uma IA. É o explorador inteligente que dá a qualquer IA — a que você já usa hoje e a que vai surgir amanhã — acesso estruturado à base judicial do tribunal. Sem trocar de ferramenta. Sem vendor lock-in. Sem reinventar a roda.*
