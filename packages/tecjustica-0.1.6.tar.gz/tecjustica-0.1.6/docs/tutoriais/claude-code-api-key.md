# Tutorial: Conectar ao TecJustica MCP via API Key no Claude Code (WSL/Linux)

Tutorial passo-a-passo para conectar o MCP server TecJustica no Claude Code usando API key fixa (`tk_...`).

---

## Pre-requisitos

1. **Claude Code instalado**:
   ```bash
   npm install -g @anthropic-ai/claude-code
   ```
2. **API key do TecJustica** no formato `tk_...`

---

## Passo 1: Adicionar o MCP server via CLI

```bash
claude mcp add --transport http tecjustica https://mcp.tecjustica.com/mcp \
  --header "Authorization: Bearer tk_SUA_API_KEY_AQUI"
```

Isso salva a configuracao no scope `local` (padrao) — fica em `.claude/settings.local.json` do projeto atual, so voce ve.

> **Dica**: para disponibilizar em todos os projetos, use `--scope user`:
> ```bash
> claude mcp add --transport http --scope user tecjustica https://mcp.tecjustica.com/mcp \
>   --header "Authorization: Bearer tk_SUA_API_KEY_AQUI"
> ```

---

## Passo 2: Abrir o Claude Code

```bash
claude
```

---

## Passo 3: Verificar a conexao

Dentro do Claude Code, digitar:

```
/mcp
```

Deve mostrar o server `tecjustica` com status **conectado** e as **15 tools** disponiveis.

---

## Passo 4: Testar as tools

Exemplos de prompts para testar:

| Prompt | Tool usada |
|--------|-----------|
| `Quem sou eu?` | `whoami` |
| `Liste meus processos` | `listar_processos` |
| `Me de uma visao geral do processo 1234567-89.2024.8.26.0100` | `visao_geral_processo` |
| `Que horas sao?` | `data_hora_atual` |

---

## Alternativa: Configuracao manual via .mcp.json

Se preferir configurar manualmente, crie o arquivo `.mcp.json` na raiz do projeto:

```json
{
  "mcpServers": {
    "tecjustica": {
      "type": "http",
      "url": "https://mcp.tecjustica.com/mcp",
      "headers": {
        "Authorization": "Bearer tk_SUA_API_KEY_AQUI"
      }
    }
  }
}
```

> **Atencao**: se o `.mcp.json` for commitado no git, a API key ficara exposta. Use a opcao com variavel de ambiente abaixo para evitar isso.

---

## Alternativa: Variavel de ambiente (mais seguro)

Ideal para compartilhar o `.mcp.json` via git sem expor a key:

**`.mcp.json`**:
```json
{
  "mcpServers": {
    "tecjustica": {
      "type": "http",
      "url": "https://mcp.tecjustica.com/mcp",
      "headers": {
        "Authorization": "Bearer ${TECJUSTICA_API_KEY}"
      }
    }
  }
}
```

**No terminal** (antes de abrir o Claude Code):
```bash
export TECJUSTICA_API_KEY="tk_sua_key_aqui"
claude
```

**Dica**: adicione o `export` no seu `~/.bashrc` ou `~/.zshrc` para nao precisar repetir toda vez.

---

## Scopes disponiveis

| Scope | Onde salva | Quando usar |
|-------|-----------|-------------|
| `local` (padrao) | `.claude/settings.local.json` | Uso pessoal, credenciais sensiveis |
| `project` | `.mcp.json` na raiz | Compartilhar com equipe via git |
| `user` | `~/.claude/settings.json` | Disponivel em todos os projetos |

---

## Comandos uteis

```bash
claude mcp list              # Listar servers configurados
claude mcp get tecjustica    # Detalhes do server
claude mcp remove tecjustica # Remover server
```

---

## Troubleshooting

| Problema | Causa provavel | Solucao |
|----------|---------------|---------|
| `/mcp` mostra "disconnected" | API key invalida ou expirada | Verificar a key com `claude mcp get tecjustica` |
| `whoami` retorna erro de auth | Token nao e do formato `tk_...` | Confirmar que a key comeca com `tk_` |
| Server nao aparece em `/mcp` | Adicionou em scope diferente | Usar `claude mcp list` para verificar; re-adicionar no scope correto |
| "Could not connect" | URL incorreta | Confirmar URL: `https://mcp.tecjustica.com/mcp` (com `/mcp` no final) |

---

## Checklist de verificacao

- [ ] `claude mcp list` mostra `tecjustica`
- [ ] `/mcp` dentro do Claude Code mostra status conectado
- [ ] Prompt "quem sou eu?" retorna dados do usuario via `whoami`
- [ ] Prompt "liste meus processos" retorna processos via `listar_processos`
