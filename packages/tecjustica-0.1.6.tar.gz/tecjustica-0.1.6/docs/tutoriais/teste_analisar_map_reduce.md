# Teste E2E: Tool `analisar` com Map-Reduce

## Caso de teste principal

| Campo | Valor |
|-------|-------|
| **Processo** | `0000105-15.2017.8.06.0203` |
| **Tipo** | Criminal (Ceara) |
| **Pergunta** | "Para a audiencia do dia 23 de marco de 2006, o acusado e seu advogado foram intimados para a audiencia?" |
| **Resposta esperada** | **SIM** — confirmacao de que acusado e advogado foram intimados |
| **Modelo** | `google/gemini-2.5-flash` (unico) |
| **Estrategia** | `contexto_unico` ou `map_reduce` (depende do tamanho do processo) |

## Como executar

```bash
# Testes unitarios (sempre — nao precisa de producao)
uv run pytest tests/ -m "not e2e" -v

# Teste e2e contra producao (requer deploy atualizado)
uv run pytest tests/test_e2e_analisar.py -m e2e -v -s --timeout=180

# Ou com API key explicita
MCP_API_KEY="tk_..." uv run pytest tests/test_e2e_analisar.py -m e2e -v -s
```

## Validacao

O teste verifica:

1. **Estrutural**: `sucesso=True`, `modelo=gemini-flash`, campo `resposta` presente
2. **Semantica**: a resposta contem confirmacao de intimacao (regex: "sim", "foram intimados", "houve intimacao", etc.)
3. **Metadata**: `estrategia` e `docs_total` presentes no retorno

## Fluxo interno

```
analisar("0000105-15.2017.8.06.0203", pergunta)
  → detectar_tipo_processo → "criminal"
  → listar_documentos(limite=5000, incluir_preview=True)
  → filtrar docs com conteudo
  → analisar_map_reduce(docs, pergunta, tipo_processo="criminal")
    → _dividir_em_lotes(docs, 800K chars)
    → Se 1 lote: contexto_unico → query Gemini Flash
    → Se N lotes: MAP paralelo → REDUCE consolidado
  → retorno com metadata (estrategia, lotes, docs_total)
```

## Notas

- O processo tem documentos de um caso criminal do Ceara
- A data 23/03/2006 se refere a uma audiencia especifica nos autos
- A informacao de intimacao deve estar nas movimentacoes ou documentos do processo
- Timeout recomendado: 180s (map-reduce com lotes paralelos pode demorar)
