# Integração com Clientes MCP

Configurações para conectar o TecJustica MCP Server a diferentes plataformas e frameworks.

**URL do servidor**: `https://mcp.tecjustica.com/mcp`
**Transporte**: Streamable HTTP
**Autenticação**: Bearer Token (API Key ou JWT Supabase)

### API Key de Produção

```
tk_0bd3797d2b16d47471b4454418f7f8e378ac79635b8316e31eb47c910fe611dd
```

Use esta chave nos exemplos abaixo substituindo `tk_0bd3797d2b16d47471b4454418f7f8e378ac79635b8316e31eb47c910fe611dd`.

---

## Sumário

- [Manus](#manus)
- [Claude Code (CLI)](#claude-code-cli)
- [LangChain / LangGraph](#langchain--langgraph)
- [Autenticação](#autenticação)
- [Tools disponíveis](#tools-disponíveis)

---

## Manus

Na interface do Manus, vá em **Settings > MCP Servers** e adicione um novo servidor:

| Campo | Valor |
|-------|-------|
| Server URL | `https://mcp.tecjustica.com/mcp` |
| Authentication | Bearer Token |
| Token | API key de produção (veja acima) |

### JSON (se solicitado)

```json
{
  "mcpServers": {
    "tecjustica": {
      "url": "https://mcp.tecjustica.com/mcp",
      "headers": {
        "Authorization": "Bearer tk_0bd3797d2b16d47471b4454418f7f8e378ac79635b8316e31eb47c910fe611dd"
      }
    }
  }
}
```

---

## Claude Code (CLI)

### Opção 1: Via comando (recomendado)

```bash
claude mcp add --transport http tecjustica https://mcp.tecjustica.com/mcp \
  --header "Authorization: Bearer tk_0bd3797d2b16d47471b4454418f7f8e378ac79635b8316e31eb47c910fe611dd"
```

### Opção 2: Arquivo de configuração

Adicione ao `~/.claude/settings.json` (global) ou `.mcp.json` (por projeto):

```json
{
  "mcpServers": {
    "tecjustica": {
      "type": "http",
      "url": "https://mcp.tecjustica.com/mcp",
      "headers": {
        "Authorization": "Bearer tk_0bd3797d2b16d47471b4454418f7f8e378ac79635b8316e31eb47c910fe611dd"
      }
    }
  }
}
```

### Opção 3: Via OAuth (sem API key)

O Claude Code suporta OAuth nativo. Basta adicionar sem header de auth:

```bash
claude mcp add --transport http tecjustica https://mcp.tecjustica.com/mcp
```

O Claude vai iniciar o fluxo OAuth automaticamente e abrir o navegador para login no Supabase.

---

## LangChain / LangGraph

### Instalação

```bash
pip install langchain-mcp-adapters langchain-anthropic
```

### Uso básico com ChatAnthropic

```python
import asyncio

from langchain_anthropic import ChatAnthropic
from langchain_mcp_adapters.client import MultiServerMCPClient

async def main():
    client = MultiServerMCPClient(
        {
            "tecjustica": {
                "url": "https://mcp.tecjustica.com/mcp",
                "transport": "http",
                "headers": {
                    "Authorization": "Bearer tk_0bd3797d2b16d47471b4454418f7f8e378ac79635b8316e31eb47c910fe611dd",
                },
            }
        }
    )
    # Obter tools como LangChain tools
    tools = await client.get_tools()

    # Usar com um modelo
    model = ChatAnthropic(model="claude-sonnet-4-20250514")
    model_with_tools = model.bind_tools(tools)

    response = await model_with_tools.ainvoke(
        "Liste os processos disponíveis"
    )
    print(response)


asyncio.run(main())
```

### Uso com LangGraph Agent (create_agent — LangChain v1)

```python
import asyncio

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent

async def main():
    client = MultiServerMCPClient(
        {
            "tecjustica": {
                "url": "https://mcp.tecjustica.com/mcp",
                "transport": "http",
                "headers": {
                    "Authorization": "Bearer tk_0bd3797d2b16d47471b4454418f7f8e378ac79635b8316e31eb47c910fe611dd",
                },
            }
        }
    )
    tools = await client.get_tools()

    agent = create_agent("anthropic:claude-sonnet-4-20250514", tools)

    result = await agent.ainvoke(
        {"messages": [{"role": "user", "content": "Faça uma análise do processo 1234567-89.2024.8.26.0100"}]}
    )

    for msg in result["messages"]:
        print(msg.content)


asyncio.run(main())
```

> **Nota**: `create_agent` (de `langchain.agents`) é o padrão atual do LangChain v1, substituindo `create_react_agent` de `langgraph.prebuilt` (que ainda funciona como legacy). Para padrões avançados (memória, human-in-the-loop, multi-agentes, streaming, structured output), veja o [Guia de Desenvolvimento de Agentes](./guia-desenvolvimento-agentes.md#11-construindo-agentes-com-langgraph).

### Uso com múltiplos MCP servers

```python
client = MultiServerMCPClient(
    {
        "tecjustica": {
            "url": "https://mcp.tecjustica.com/mcp",
            "transport": "http",
            "headers": {
                "Authorization": "Bearer tk_0bd3797d2b16d47471b4454418f7f8e378ac79635b8316e31eb47c910fe611dd",
            },
        },
        "outro-servidor": {
            "url": "https://outro-mcp.example.com/mcp",
            "transport": "http",
        },
    }
)
# Tools de todos os servidores combinados
tools = await client.get_tools()
```

---

## Autenticação

### Via API Key (recomendado para automação)

API keys no formato `tk_` funcionam como Bearer token direto:

```
Authorization: Bearer tk_0bd3797d2b16d47471b4454418f7f8e378ac79635b8316e31eb47c910fe611dd
```

### Via JWT Supabase (para aplicações web)

Obter token via Supabase Auth:

```bash
ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBnbGdoeXpuaXJ4a2V3Y211aHZwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjYzNjk4MTgsImV4cCI6MjA4MTk0NTgxOH0.hac05fv66miyiRqzwBIZYSA8gjA8dcRFOJMs3wSqWpA"

TOKEN=$(curl -s -X POST \
  "https://pglghyznirxkewcmuhvp.supabase.co/auth/v1/token?grant_type=password" \
  -H "apikey: $ANON_KEY" \
  -H "Content-Type: application/json" \
  -d '{"email":"seu@email.com","password":"sua_senha"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")
```

Depois usar:

```
Authorization: Bearer $TOKEN
```

---

## Tools disponíveis

Após conectar, as seguintes 15 tools ficam disponíveis:

| Tool | Descrição |
|------|-----------|
| `listar_processos` | Listar processos ou buscar por nome de parte |
| `visao_geral_processo` | Metadados, partes, stats e movimentações recentes |
| `ls_documentos` | Listar documentos (metadados, sem conteúdo) |
| `ls_movimentacoes` | Timeline de movimentações |
| `read_documento` | Ler conteúdo de documento com controle de offset |
| `grep_documentos` | Busca full-text/regex no conteúdo dos documentos |
| `grep_movimentacoes` | Busca full-text nas movimentações |
| `glob_documentos` | Filtrar documentos por nome/tipo/sigilo |
| `localizar_no_documento` | Encontrar posições exatas de um termo |
| `stats_documentos` | Estatísticas agregadas dos documentos |
| **`analisar`** | **Análise com LLM — a tool mais poderosa (ver seção abaixo)** |
| `buscar_precedentes` | Busca no Banco Nacional de Precedentes (BNP/CNJ) |
| `calculadora` | Cálculos matemáticos e prazos processuais (CPC/CPP) |
| `data_hora_atual` | Data/hora atual com dia da semana |
| `whoami` | Informações do usuário autenticado |

---

## Tool `analisar` — Análise com LLM (Map-Reduce)

A tool `analisar` é a **ferramenta principal** para extrair informações de processos judiciais. Ela lê **todos os documentos** do processo (sentenças, petições, laudos, decisões) e responde qualquer pergunta usando Gemini 2.5 Flash.

### Como funciona

```
analisar(numero_processo, pergunta)
  → Busca TODOS os documentos do processo
  → Se cabem no contexto (< 800K tokens): envia tudo de uma vez
  → Se NÃO cabem: Map-Reduce automático
    → MAP: divide em lotes, resume cada lote em paralelo
    → REDUCE: consolida resumos e responde a pergunta
```

**Não há limite de tamanho** — processos com centenas de documentos são processados automaticamente em lotes.

### Parâmetros

| Parâmetro | Tipo | Descrição |
|-----------|------|-----------|
| `numero_processo` | string (obrigatório) | Número CNJ (formato `NNNNNNN-DD.AAAA.J.TR.OOOO`) |
| `pergunta` | string | Pergunta ou instrução em linguagem natural |
| `document_ids` | string | IDs separados por vírgula para analisar docs específicos |
| `perspectiva` | string | Ponto de vista: `autor`, `reu`, `juiz`, `acusado`, `defensor`, etc. |

### Estratégia recomendada para agentes

A tool pode (e deve) ser chamada **múltiplas vezes** no mesmo processo com perguntas diferentes:

```
1. visao_geral_processo(cnj)                           → contexto rápido
2. analisar(cnj, "Qual a situação atual?")             → panorama geral
3. analisar(cnj, "Quais os pedidos e seus status?")    → detalhamento
4. analisar(cnj, "Análise de risco", perspectiva="autor") → perspectiva
5. analisar(cnj, "Houve intimação para audiência X?")  → pergunta pontual
6. analisar(cnj, document_ids="id1,id2", pergunta="Compare") → docs específicos
```

### Retorno

```json
{
  "sucesso": true,
  "numero_processo": "0000105-15.2017.8.06.0203",
  "tipo_processo": "criminal",
  "modelo": "gemini-flash",
  "estrategia": "map_reduce",
  "lotes": 3,
  "docs_total": 47,
  "resposta": "..."
}
```

| Campo | Descrição |
|-------|-----------|
| `estrategia` | `contexto_unico` (cabe tudo) ou `map_reduce` (dividido em lotes) |
| `lotes` | Número de lotes processados |
| `docs_total` | Total de documentos analisados |
| `resposta` | Resposta completa do LLM |

### Exemplos de perguntas

- "Qual a situação atual? Fase, pendências, alertas."
- "Extraia todos os pedidos com tipo, valor e status."
- "Análise de risco completa com cenários."
- "O réu foi citado? Quando e como?"
- "Houve acordo ou tentativa de conciliação?"
- "Resuma os laudos periciais e suas conclusões."
- "Elabore parecer jurídico sobre viabilidade recursal."

---

## Verificação rápida

Para testar se a conexão está funcionando, chame a tool `whoami` — ela retorna os dados do usuário autenticado sem precisar de parâmetros.
