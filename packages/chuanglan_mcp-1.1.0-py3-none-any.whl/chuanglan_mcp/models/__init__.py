"""
数据模型模块

使用 Pydantic v2 定义数据结构，适配创蓝 V2 API
提供自动验证和序列化
"""

from .request import (
    SmsSendRequest,
    BalanceRequest,
    StatusRequest,
)
from .response import (
    SmsResponse,
    BalanceResponse,
    StatusResponse,
    StatusItem,
    APIResponse,
)

__all__ = [
    "SmsSendRequest",
    "BalanceRequest",
    "StatusRequest",
    "SmsResponse",
    "BalanceResponse",
    "StatusResponse",
    "StatusItem",
    "APIResponse",
]
