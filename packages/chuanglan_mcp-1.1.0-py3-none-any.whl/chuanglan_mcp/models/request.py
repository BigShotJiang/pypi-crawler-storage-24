"""
请求模型模块

定义创蓝 V2 API 请求数据结构
"""

from datetime import datetime
from typing import Optional, Dict, List

from pydantic import BaseModel, Field, field_validator, ConfigDict


class SmsSendRequest(BaseModel):
    """V2 短信发送请求模型"""

    model_config = ConfigDict(extra="forbid")

    phone_numbers: str = Field(
        ...,
        alias="phoneNumbers",
        description="接收手机号，支持单个手机号或逗号分隔的多个手机号（最多 1000 个）",
        min_length=11,
        max_length=15000,
    )
    template_id: str = Field(
        ...,
        alias="templateId",
        description="模板 ID，需在创蓝平台提前创建并审核通过",
        min_length=1,
        max_length=50,
    )
    template_param_json: Optional[List[Dict[str, str]]] = Field(
        default=None,
        alias="templateParamJson",
        description="模板变量参数，JSON 数组格式，如：[{'param1': '张三', 'param2': '13'}]",
    )
    signature: Optional[str] = Field(
        default=None,
        description="短信签名，如：【创蓝云智】",
        max_length=50,
    )
    report: str = Field(
        default="true",
        description="状态回执开关，true 或 false",
    )
    callback_url: Optional[str] = Field(
        default=None,
        alias="callbackUrl",
        description="状态回执的回调地址",
        max_length=500,
    )
    uid: Optional[str] = Field(
        default=None,
        description="自定义参数，如订单号，最大 256 位",
        max_length=256,
    )
    extend: Optional[str] = Field(
        default=None,
        description="下发短信号码扩展码，用于匹配上行回复",
        max_length=10,
    )

    @field_validator("phone_numbers")
    @classmethod
    def validate_phone_numbers(cls, value: str) -> str:
        """验证手机号格式"""
        phones = [p.strip() for p in value.split(",")]
        for phone in phones:
            if not phone.isdigit():
                raise ValueError("手机号必须全为数字")
            if len(phone) != 11:
                raise ValueError(f"手机号格式错误：{phone}（应为 11 位）")
        if len(phones) > 1000:
            raise ValueError("一次最多发送 1000 个手机号")
        return value

    @field_validator("report")
    @classmethod
    def validate_report(cls, value: str) -> str:
        """验证回执开关"""
        if value.lower() not in ("true", "false"):
            raise ValueError("report 参数必须为 'true' 或 'false'")
        return value.lower()


class BalanceRequest(BaseModel):
    """余额查询请求模型"""

    model_config = ConfigDict(extra="forbid")

    account: str = Field(..., description="API 账号")
    password: str = Field(..., description="API 密码")


class StatusRequest(BaseModel):
    """状态查询请求模型"""

    model_config = ConfigDict(extra="forbid")

    account: str = Field(..., description="API 账号")
    password: str = Field(..., description="API 密码")
    task_id: str = Field(..., alias="taskId", description="任务 ID")
    start_time: Optional[str] = Field(
        default=None,
        alias="startTime",
        description="开始时间，格式：yyyy-MM-dd HH:mm:ss",
    )
    end_time: Optional[str] = Field(
        default=None,
        alias="endTime",
        description="结束时间，格式：yyyy-MM-dd HH:mm:ss",
    )
    page: int = Field(default=1, description="页码", ge=1, le=1000)
    page_size: int = Field(default=50, description="每页数量", ge=1, le=100)

    @field_validator("start_time", "end_time")
    @classmethod
    def validate_datetime(cls, value: Optional[str]) -> Optional[str]:
        """验证时间格式"""
        if value is None:
            return value
        try:
            datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            raise ValueError("时间格式错误，应为：yyyy-MM-dd HH:mm:ss")
        return value
