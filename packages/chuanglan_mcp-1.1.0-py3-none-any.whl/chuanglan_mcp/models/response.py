"""
响应模型模块

定义创蓝 V2 API 响应数据结构
"""

from typing import Optional, Dict, List, Any

from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict


class SmsResponse(BaseModel):
    """V2 短信发送响应模型"""

    model_config = ConfigDict(from_attributes=True)

    code: str = Field(..., description="返回码")
    msg: str = Field(default="", description="返回消息")
    msg_id: Optional[str] = Field(default=None, description="消息 ID")
    time: Optional[str] = Field(default=None, description="响应时间")
    success_num: int = Field(default=0, description="提交成功数量")
    fail_num: int = Field(default=0, description="提交失败数量")
    error_msg: str = Field(default="", description="错误描述")
    success: bool = Field(default=False, description="是否成功")

    @model_validator(mode="after")
    def set_success(self) -> "SmsResponse":
        """根据返回码自动设置成功状态"""
        self.success = self.code == "000000"
        return self


class BalanceResponse(BaseModel):
    """余额查询响应模型"""

    model_config = ConfigDict(from_attributes=True)

    code: str = Field(..., description="返回码")
    msg: str = Field(..., description="返回消息")
    balance: Optional[float] = Field(default=None, description="账户余额")
    success: bool = Field(default=False, description="是否成功")

    @model_validator(mode="after")
    def set_success(self) -> "BalanceResponse":
        """根据返回码自动设置成功状态"""
        self.success = self.code == "0"
        return self


class StatusItem(BaseModel):
    """单条短信状态"""

    model_config = ConfigDict(from_attributes=True)

    phone: str = Field(..., description="手机号")
    status: str = Field(..., description="发送状态")
    send_time: Optional[str] = Field(default=None, description="发送时间")
    receive_time: Optional[str] = Field(default=None, description="接收时间")
    report_status: Optional[str] = Field(default=None, description="报告状态")


class StatusResponse(BaseModel):
    """状态查询响应模型"""

    model_config = ConfigDict(from_attributes=True)

    code: str = Field(..., description="返回码")
    msg: str = Field(..., description="返回消息")
    statuses: List[StatusItem] = Field(default_factory=list, description="状态列表")
    total: int = Field(default=0, description="总数")
    page: int = Field(default=1, description="当前页码")
    page_size: int = Field(default=50, description="每页数量")
    success: bool = Field(default=False, description="是否成功")

    @model_validator(mode="after")
    def set_success(self) -> "StatusResponse":
        """根据返回码自动设置成功状态"""
        self.success = self.code == "0"
        return self


class APIResponse(BaseModel):
    """通用 API 响应模型"""

    model_config = ConfigDict(from_attributes=True)

    success: bool = Field(..., description="是否成功")
    data: Optional[Dict[str, Any]] = Field(default=None, description="响应数据")
    error: Optional[str] = Field(default=None, description="错误信息")
    code: Optional[str] = Field(default=None, description="错误码")
