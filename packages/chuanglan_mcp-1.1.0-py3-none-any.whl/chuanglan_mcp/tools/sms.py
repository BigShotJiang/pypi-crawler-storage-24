"""
短信工具模块

提供短信发送相关功能，适配创蓝 V2 API

支持：
- 每次调用时传入 account 和 password 参数
- 或通过环境变量配置账号密码，调用时可不传参数
"""

import logging
from typing import Optional, Dict, List

from ..models import SmsSendRequest
from ..core import ChuanglanClient, settings
from ..core.exceptions import ChuanglanError

logger = logging.getLogger(__name__)


def _mask_account(account: str) -> str:
    """对账号进行脱敏处理"""
    if not account:
        return "***"
    if len(account) >= 4:
        return f"{account[:4]}****"
    return f"{account[0]}****"


def _get_credentials(account: Optional[str], password: Optional[str]) -> tuple[str, str]:
    """
    获取账号密码凭证

    优先级：
    1. 如果传入了 account 和 password，使用传入的值
    2. 否则使用环境变量中配置的账号密码

    Args:
        account: 传入的账号（可选）
        password: 传入的密码（可选）

    Returns:
        tuple: (account, password)

    Raises:
        ValueError: 无法获取有效凭证时抛出
    """
    # 优先使用传入的参数
    if account and password:
        return account, password

    # 使用环境变量配置的账号密码
    if settings.chuanglan_account and settings.chuanglan_password:
        return settings.chuanglan_account, settings.chuanglan_password

    # 无法获取有效凭证
    raise ValueError("必须传入 account 和 password 参数，或在 .env 文件中配置 CHUANGLAN_ACCOUNT 和 CHUANGLAN_PASSWORD")


def create_client(account: Optional[str] = None, password: Optional[str] = None) -> ChuanglanClient:
    """创建创蓝 API 客户端

    Args:
        account: 创蓝 API 账号（可选，调用时传入则使用传入的值）
        password: 创蓝 API 密码（可选，调用时传入则使用传入的值）

    Returns:
        ChuanglanClient: API 客户端实例

    Raises:
        ValueError: 账号或密码为空时抛出

    Example:
        ```python
        # 传入账号密码
        client = create_client("N6000001", "your_password")

        # 使用环境变量配置（需在.env 中配置账号密码）
        client = create_client()
        ```
    """
    # 获取凭证
    final_account, final_password = _get_credentials(account, password)

    # 创建带账号密码的配置
    config = settings.model_copy(update={
        "chuanglan_account": final_account,
        "chuanglan_password": final_password,
    })

    logger.debug(f"创建客户端：account={_mask_account(final_account)}")
    return ChuanglanClient(config)


async def send_template_sms(
    phone: str,
    template_id: str,
    params: Optional[List[Dict[str, str]]] = None,
    signature: Optional[str] = None,
    report: str = "true",
    callback_url: Optional[str] = None,
    uid: Optional[str] = None,
    extend: Optional[str] = None,
    account: Optional[str] = None,
    password: Optional[str] = None,
) -> dict:
    """发送模板短信（V2 接口）

    使用预设模板发送短信，支持变量替换。
    模板需要在创蓝平台提前创建并审核通过。

    Args:
        phone: 接收手机号，支持单个手机号或逗号分隔的多个手机号（最多 1000 个）
        template_id: 模板 ID，需在创蓝平台提前创建并审核通过
        params: 模板变量参数，JSON 数组格式，如：[{"param1": "张三", "param2": "13"}]
        signature: 短信签名，可选，如：【创蓝云智】
        report: 状态回执开关，"true" 或 "false"
        callback_url: 状态回执回调地址，可选
        uid: 自定义参数，如订单号，最大 256 位
        extend: 扩展码，用于匹配上行回复
        account: 创蓝 API 账号（可选，不传则使用环境变量配置）
        password: 创蓝 API 密码（可选，不传则使用环境变量配置）

    Returns:
        dict: 发送结果，包含 code、msg、msgId、successNum、failNum、success 字段

    Example:
        ```python
        # 传入账号密码
        result = await send_template_sms(
            phone="13800138000",
            template_id="1021143438",
            params=[{"param1": "张三", "param2": "13"}],
            account="N6000001",
            password="your_password"
        )

        # 使用环境变量配置（需在.env 中配置账号密码）
        result = await send_template_sms(
            phone="13800138000",
            template_id="1021143438",
            params=[{"param1": "张三", "param2": "13"}]
        )
        ```
    """
    # 日志记录请求参数（密码脱敏）
    logger.info(
        f"请求：send_template_sms | "
        f"account={_mask_account(account or settings.chuanglan_account)} | "
        f"phone={phone} | "
        f"template_id={template_id} | "
        f"params={params} | "
        f"signature={signature} | "
        f"report={report}"
    )

    try:
        # 获取凭证
        final_account, final_password = _get_credentials(account, password)
        logger.info(f"使用账号：{_mask_account(final_account)}")

        # 验证参数
        request = SmsSendRequest(
            phoneNumbers=phone,
            templateId=template_id,
            templateParamJson=params,
            signature=signature,
            report=report,
            callbackUrl=callback_url,
            uid=uid,
            extend=extend,
        )

        # 创建客户端
        client = create_client(final_account, final_password)
        result = await client.send_template_sms(
            phone_numbers=request.phone_numbers,
            template_id=request.template_id,
            template_param_json=request.template_param_json,
            signature=request.signature,
            report=request.report,
            callback_url=request.callback_url,
            uid=request.uid,
            extend=request.extend,
        )

        logger.info(
            f"响应：send_template_sms | "
            f"code={result.code} | "
            f"msg_id={result.msg_id} | "
            f"success_num={result.success_num} | "
            f"fail_num={result.fail_num} | "
            f"success={result.success}"
        )
        return result.model_dump()

    except ValueError as e:
        logger.error(f"凭证验证失败：{e}")
        return {
            "code": "AUTH_REQUIRED",
            "msg": str(e),
            "success": False,
        }

    except ChuanglanError as e:
        logger.error(f"创蓝 API 错误：{e}")
        return e.to_dict() | {"success": False}

    except Exception as e:
        logger.error(f"未知错误：{e}", exc_info=True)
        return {
            "code": "UNKNOWN_ERROR",
            "msg": f"发送失败：{str(e)}",
            "success": False,
        }
