"""
余额查询工具模块

提供账户余额查询功能

支持：
- 每次调用时传入 account 和 password 参数
- 或通过环境变量配置账号密码，调用时可不传参数
"""

import logging
from typing import Optional

from ..core import ChuanglanClient, settings
from ..core.exceptions import ChuanglanError

logger = logging.getLogger(__name__)


def _mask_account(account: str) -> str:
    """对账号进行脱敏处理"""
    if not account:
        return "***"
    if len(account) >= 4:
        return f"{account[:4]}****"
    return f"{account[0]}****"


def _get_credentials(account: Optional[str], password: Optional[str]) -> tuple[str, str]:
    """
    获取账号密码凭证

    优先级：
    1. 如果传入了 account 和 password，使用传入的值
    2. 否则使用环境变量中配置的账号密码

    Args:
        account: 传入的账号（可选）
        password: 传入的密码（可选）

    Returns:
        tuple: (account, password)

    Raises:
        ValueError: 无法获取有效凭证时抛出
    """
    # 优先使用传入的参数
    if account and password:
        return account, password

    # 使用环境变量配置的账号密码
    if settings.chuanglan_account and settings.chuanglan_password:
        return settings.chuanglan_account, settings.chuanglan_password

    # 无法获取有效凭证
    raise ValueError("必须传入 account 和 password 参数，或在 .env 文件中配置 CHUANGLAN_ACCOUNT 和 CHUANGLAN_PASSWORD")


def create_client(account: Optional[str] = None, password: Optional[str] = None) -> ChuanglanClient:
    """创建创蓝 API 客户端

    Args:
        account: 创蓝 API 账号（可选，调用时传入则使用传入的值）
        password: 创蓝 API 密码（可选，调用时传入则使用传入的值）

    Returns:
        ChuanglanClient: API 客户端实例

    Raises:
        ValueError: 账号或密码为空时抛出

    Example:
        ```python
        # 传入账号密码
        client = create_client("N6000001", "your_password")

        # 使用环境变量配置（需在.env 中配置账号密码）
        client = create_client()
        ```
    """
    # 获取凭证
    final_account, final_password = _get_credentials(account, password)

    # 创建带账号密码的配置
    config = settings.model_copy(update={
        "chuanglan_account": final_account,
        "chuanglan_password": final_password,
    })

    logger.debug(f"创建客户端：account={_mask_account(final_account)}")
    return ChuanglanClient(config)


async def query_balance(
    account: Optional[str] = None,
    password: Optional[str] = None,
) -> dict:
    """查询账户余额

    查看当前账户剩余金额。

    Args:
        account: 创蓝 API 账号（可选，不传则使用环境变量配置）
        password: 创蓝 API 密码（可选，不传则使用环境变量配置）

    Returns:
        dict: 查询结果，包含 code、msg、balance、success 字段

    Example:
        ```python
        # 传入账号密码
        result = await query_balance(
            account="N6000001",
            password="your_password"
        )

        # 使用环境变量配置（需在.env 中配置账号密码）
        result = await query_balance()
        ```
    """
    logger.info(f"请求：query_balance | account={_mask_account(account or settings.chuanglan_account)}")

    try:
        # 获取凭证
        final_account, final_password = _get_credentials(account, password)
        logger.info(f"使用账号：{_mask_account(final_account)}")

        # 创建客户端
        client = create_client(final_account, final_password)
        result = await client.query_balance()

        logger.info(f"响应：query_balance | code={result.code} | balance={result.balance} | success={result.success}")
        return result.model_dump()

    except ValueError as e:
        logger.error(f"凭证错误：{e}")
        return {
            "code": "AUTH_REQUIRED",
            "msg": str(e),
            "success": False,
        }

    except ChuanglanError as e:
        logger.error(f"创蓝 API 错误：{e}")
        return e.to_dict() | {"success": False}

    except Exception as e:
        logger.error(f"未知错误：{e}", exc_info=True)
        return {
            "code": "UNKNOWN_ERROR",
            "msg": f"查询失败：{str(e)}",
            "success": False,
        }
