"""
创蓝 253 MCP Server

企业级创蓝 253 短信平台 MCP 服务器实现
基于 FastMCP 框架构建，提供完整的类型注解和错误处理

支持两种运行模式：
1. 多租户模式：每次工具调用都必须传入 account 和 password 参数（推荐）
2. 单租户模式：通过环境变量配置账号密码

Copyright (c) 2026 ChuangLan. MIT License.
"""

# 支持相对导入和绝对导入两种模式
try:
    from .server import mcp, main
    from .core import ChuanglanClient, Settings, get_settings, settings
    from .core import (
        ChuanglanError,
        ChuanglanAuthError,
        ChuanglanApiError,
        ChuanglanValidationError,
        ChuanglanNetworkError,
        ChuanglanTimeoutError,
    )
    from .models import (
        SmsResponse,
        BalanceResponse,
        StatusResponse,
        SmsSendRequest,
        StatusRequest,
        StatusItem,
        APIResponse,
    )
    from .tools import (
        send_template_sms,
        query_balance,
    )
except ImportError:
    from server import mcp, main
    from core import ChuanglanClient, Settings, get_settings, settings
    from core import (
        ChuanglanError,
        ChuanglanAuthError,
        ChuanglanApiError,
        ChuanglanValidationError,
        ChuanglanNetworkError,
        ChuanglanTimeoutError,
    )
    from models import (
        SmsResponse,
        BalanceResponse,
        StatusResponse,
        SmsSendRequest,
        StatusRequest,
        StatusItem,
        APIResponse,
    )
    from tools import (
        send_template_sms,
        query_balance,
    )

__version__ = "1.0.0"
__author__ = "ChuangLan"
__email__ = "support@chuanglan.com"
__all__ = [
    # Version
    "__version__",
    # Server
    "mcp",
    "main",
    # Client
    "ChuanglanClient",
    # Config
    "Settings",
    "get_settings",
    "settings",
    # Models
    "SmsResponse",
    "BalanceResponse",
    "StatusResponse",
    "SmsSendRequest",
    "StatusRequest",
    "StatusItem",
    "APIResponse",
    # Exceptions
    "ChuanglanError",
    "ChuanglanAuthError",
    "ChuanglanApiError",
    "ChuanglanValidationError",
    "ChuanglanNetworkError",
    "ChuanglanTimeoutError",
    # Tools
    "send_template_sms",
    "query_balance",
]
