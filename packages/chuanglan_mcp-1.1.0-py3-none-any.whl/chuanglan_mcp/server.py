"""
MCP 服务器入口

基于 FastMCP 框架构建 MCP 服务器
提供短信发送、余额查询等工具

凭证获取优先级：
1. 工具调用时传入 account 和 password 参数
2. 否则使用环境变量 CHUANGLAN_ACCOUNT 和 CHUANGLAN_PASSWORD 配置

V2 API 说明：
- 接口地址：https://smssh.253.com/msg/sms/v2/tpl/send
- 账号密码明文鉴权

支持的传输方式：
- stdio: 标准输入输出（默认，用于本地开发）
- http: HTTP POST
- sse: Server-Sent Events
- streamable-http: 可流式 HTTP
"""

import logging
import argparse

from fastmcp import FastMCP

# 支持相对导入和绝对导入两种模式
try:
    from .core import settings
    from .tools import send_template_sms, query_balance
except ImportError:
    from core import settings
    from tools import send_template_sms, query_balance

# 配置日志
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# 初始化 MCP 服务器
mcp = FastMCP(
    name="chuanglan-mcp",
    version="1.0.0",
)

# 注册工具
mcp.tool()(send_template_sms)
mcp.tool()(query_balance)


def main() -> None:
    """启动 MCP 服务器

    支持的传输方式：
    - stdio: 标准输入输出（默认，用于本地开发和 Claude Desktop）
    - http: HTTP POST
    - sse: Server-Sent Events（端口 8000）
    - streamable-http: 可流式 HTTP（端口 8000）

    环境变量配置：
    - CHUANGLAN_SMS_URL: 短信发送地址（可选）
    - CHUANGLAN_BALANCE_URL: 余额查询地址（可选）
    - CHUANGLAN_STATUS_URL: 状态报告查询地址（可选）
    - CHUANGLAN_ACCOUNT: 创蓝 API 账号（可选）
    - CHUANGLAN_PASSWORD: 创蓝 API 密码（可选）
    - REQUEST_TIMEOUT: 请求超时时间（可选，默认 30 秒）
    - LOG_LEVEL: 日志级别（可选，默认 INFO）
    """
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="Chuanglan MCP Server")
    parser.add_argument(
        "--transport", "-t",
        type=str,
        default="stdio",
        choices=["stdio", "http", "sse", "streamable-http"],
        help="传输方式 (默认：stdio)",
    )
    parser.add_argument(
        "--port", "-p",
        type=int,
        default=8000,
        help="HTTP/SSE 监听端口 (默认：8000)",
    )
    args = parser.parse_args()

    logger.info(f"启动 Chuanglan MCP Server v{mcp.version}")
    logger.info(f"当前短信接口：{settings.sms_url}")
    logger.info(f"传输方式：{args.transport}")

    if settings.chuanglan_account and settings.chuanglan_password:
        logger.info("使用环境变量配置的账号")
    else:
        logger.info("工具调用时需传入 account/password 参数")

    logger.info("鉴权方式：账号密码明文")

    # 运行服务器
    if args.transport in ("sse", "streamable-http", "http"):
        logger.info(f"监听端口：{args.port}")
        mcp.run(transport=args.transport, port=args.port)
    else:
        mcp.run(transport=args.transport)


if __name__ == "__main__":
    main()
