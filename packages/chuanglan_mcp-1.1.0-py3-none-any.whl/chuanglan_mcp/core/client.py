"""
创蓝 253 API 客户端模块 (V2)

提供异步 HTTP 客户端，用于与创蓝 253 V2 API 进行交互
支持账号密码明文鉴权
"""

import asyncio
import hashlib
import json
import logging
import time
from typing import Optional, Dict, List

import httpx
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    RetryError,
)

from .config import Settings
from .exceptions import (
    ChuanglanAuthError,
    ChuanglanApiError,
    ChuanglanNetworkError,
    ChuanglanTimeoutError,
)
from ..models import (
    SmsResponse,
    BalanceResponse,
    StatusResponse,
    StatusItem,
)

logger = logging.getLogger(__name__)


class ChuanglanClient:
    """创蓝 253 V2 API 客户端

    提供短信发送、余额查询、状态查询等功能的异步 HTTP 客户端
    支持账号密码明文鉴权

    Attributes:
        config: 配置对象
        _http_client: HTTP 客户端实例

    Example:
        ```python
        from chuanglan_mcp.core import ChuanglanClient, Settings

        settings = Settings(
            chuanglan_account="N6000001",
            chuanglan_password="your_password"
        )
        client = ChuanglanClient(settings)

        # 发送短信
        response = await client.send_template_sms(
            phone_numbers="13800138000",
            template_id="1021143438",
            template_param_json=[{"param1": "张三", "param2": "13"}]
        )

        # 查询余额
        balance = await client.query_balance()

        # 关闭客户端
        await client.close()
        ```
    """

    # V2 API 返回码说明
    RESPONSE_CODES: Dict[str, str] = {
        "000000": "提交成功",
        "101": "无此用户",
        "102": "密码错",
        "103": "提交过快",
        "104": "系统忙",
        "105": "敏感短信",
        "106": "消息长度错",
        "107": "包含错误的手机号码",
        "108": "手机号码个数错",
        "109": "无发送额度",
        "110": "不在发送时间内",
        "111": "超出该账户当月发送额度限制",
        "112": "产品错误",
        "113": "扩展码格式错",
        "114": "可用参数组个数错误",
        "116": "签名不合法或未带签名",
        "117": "客户端 IP 错误",
        "118": "用户没有相应的发送权限",
        "119": "用户已过期",
        "120": "违反防盗用策略",
        "123": "发送类型错误",
        "124": "白模板匹配错误",
        "125": "匹配驳回模板，提交失败",
        "127": "定时发送时间格式错误",
        "128": "内容编码失败",
        "129": "JSON 格式错误",
        "130": "请求参数错误",
        "132": "消息长度错",
        "133": "单一手机号错误",
        "134": "违反防盗策略，超过月发送限制",
        "135": "超过同一手机号相同内容发送限制",
        "136": "不可批量提交验证码短信",
        "139": "超出安全发送时间",
        "140": "短信内容解密错误",
        "144": "产品未上线限制日发送数量",
        "145": "验签失败",
        "152": "模板不存在",
        "153": "消息长度错",
        "154": "长短信拼接错误",
        "155": "转发失败",
        "158": "退订语不符合规范",
        "159": "触发反轰炸策略",
    }

    def __init__(self, config: Settings, http_client: Optional[httpx.AsyncClient] = None) -> None:
        """初始化客户端

        Args:
            config: 配置对象
            http_client: 可选的 HTTP 客户端实例（用于测试注入）
        """
        self.config = config
        self._http_client: Optional[httpx.AsyncClient] = http_client
        self._lock = asyncio.Lock()

    async def _get_client(self) -> httpx.AsyncClient:
        """获取 HTTP 客户端实例（线程安全的单例模式）

        Returns:
            httpx.AsyncClient: HTTP 客户端实例
        """
        if self._http_client is None:
            async with self._lock:
                if self._http_client is None:
                    self._http_client = httpx.AsyncClient(
                        timeout=httpx.Timeout(
                            self.config.request_timeout,
                            connect=10.0,
                        ),
                        headers={
                            "Content-Type": "application/json",
                            "User-Agent": "ChuanglanMCP/1.0.0",
                        },
                        limits=httpx.Limits(
                            max_keepalive_connections=10,
                            max_connections=100,
                        ),
                    )
        return self._http_client

    async def close(self) -> None:
        """关闭 HTTP 客户端"""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None
            logger.info("HTTP client closed")

    @staticmethod
    def _md5(password: str) -> str:
        """MD5 加密密码（用于账号密码明文鉴权）"""
        return hashlib.md5(password.encode("utf-8")).hexdigest().lower()

    def _check_response_code(self, code: str, is_balance: bool = False) -> None:
        """检查 API 返回码并抛出相应异常

        Args:
            code: API 返回码
            is_balance: 是否为余额查询接口（余额查询返回"0"表示成功）

        Raises:
            ChuanglanAuthError: 认证错误
            ChuanglanApiError: API 错误
        """
        # 余额查询接口返回"0"表示成功，短信接口返回"000000"表示成功
        if code == "000000" or code == "0":
            return

        # 认证错误
        if code in ("101", "102", "103", "117", "118", "119", "145"):
            raise ChuanglanAuthError(code)

        # API 业务错误
        if code in self.RESPONSE_CODES:
            raise ChuanglanApiError(code)

        # 未知错误
        logger.warning(f"未知的返回码：{code}")
        raise ChuanglanApiError(code, f"未知错误码：{code}")

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type((httpx.NetworkError, httpx.TimeoutException)),
    )
    async def _request(
        self,
        method: str,
        url: str,
        payload: Dict,
    ) -> Dict:
        """发送 HTTP 请求（带重试机制）

        Args:
            method: HTTP 方法
            url: 请求 URL
            payload: 请求体

        Returns:
            dict: 响应数据

        Raises:
            ChuanglanNetworkError: 网络错误
            ChuanglanTimeoutError: 超时错误
        """
        client = await self._get_client()
        headers = {"Content-Type": "application/json"}

        # 记录请求日志（密码脱敏）
        log_payload = payload.copy()
        if "password" in log_payload:
            log_payload["password"] = "***REDACTED***"
        logger.debug(f"请求 URL: {url}")
        logger.debug(f"请求方法：{method}")
        logger.debug(f"请求头：{headers}")
        logger.debug(f"请求体：{json.dumps(log_payload, ensure_ascii=False)}")

        try:
            response = await client.request(method, url, json=payload, headers=headers)
            response.raise_for_status()
            response_data = response.json()

            # 记录响应日志
            logger.debug(f"响应状态码：{response.status_code}")
            logger.debug(f"响应内容：{json.dumps(response_data, ensure_ascii=False)}")
            return response_data

        except httpx.TimeoutException as e:
            logger.error(f"请求超时：{url}")
            raise ChuanglanTimeoutError(self.config.request_timeout) from e

        except httpx.NetworkError as e:
            logger.error(f"网络错误：{url}")
            raise ChuanglanNetworkError(str(e), e) from e

        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP 错误：{e.response.status_code}")
            raise ChuanglanApiError(
                str(e.response.status_code),
                e.response.text,
            ) from e

        except RetryError as e:
            logger.error(f"重试失败：{e}")
            raise ChuanglanNetworkError("重试失败", e) from e

    async def send_template_sms(
        self,
        phone_numbers: str,
        template_id: str,
        template_param_json: Optional[List[Dict[str, str]]] = None,
        signature: Optional[str] = None,
        report: str = "true",
        callback_url: Optional[str] = None,
        uid: Optional[str] = None,
        extend: Optional[str] = None,
    ) -> SmsResponse:
        """发送模板短信（V2 接口）

        使用预设模板发送短信，支持变量替换。
        模板需要在创蓝平台提前创建并审核通过。

        Args:
            phone_numbers: 接收手机号，支持单个手机号或逗号分隔的多个手机号（最多 1000 个）
            template_id: 模板 ID
            template_param_json: 模板变量参数，JSON 数组格式
            signature: 短信签名，可选
            report: 状态回执开关，"true" 或 "false"
            callback_url: 状态回执的回调地址，可选
            uid: 自定义参数，如订单号，可选
            extend: 下发短信号码扩展码，可选

        Returns:
            SmsResponse: 发送响应

        Raises:
            ChuanglanAuthError: 认证失败时抛出
            ChuanglanApiError: API 调用失败时抛出
            ChuanglanNetworkError: 网络错误时抛出
            ChuanglanTimeoutError: 请求超时

        Example:
            ```python
            # 单条短信
            response = await client.send_template_sms(
                phone_numbers="13800138000",
                template_id="1021143438",
                template_param_json=[{"param1": "张三", "param2": "13"}]
            )

            # 多条短信
            response = await client.send_template_sms(
                phone_numbers="13800138000,13900139000",
                template_id="1021143438",
                template_param_json=[
                    {"param1": "张三", "param2": "13"},
                    {"param1": "李四", "param2": "88"}
                ]
            )
            if response.success:
                print(f"发送成功，成功{response.success_num}条，失败{response.fail_num}条")
            ```
        """
        # 构建请求体
        payload = {
            "account": self.config.chuanglan_account,
            "password": self.config.chuanglan_password,
            "phoneNumbers": phone_numbers,
            "templateId": template_id,
            "report": report,
        }

        if template_param_json:
            payload["templateParamJson"] = json.dumps(
                template_param_json, ensure_ascii=False
            )

        if signature:
            payload["signature"] = signature

        if callback_url:
            payload["callbackUrl"] = callback_url

        if uid:
            payload["uid"] = uid

        if extend:
            payload["extend"] = extend

        logger.info(f"发送模板短信：手机号={phone_numbers}, 模板 ID={template_id}")

        try:
            data = await self._request(
                "POST",
                self.config.sms_url,
                payload,
            )

            code = str(data.get("code", ""))

            self._check_response_code(code)

            return SmsResponse(
                code=code,
                msg=data.get("errorMsg", self.RESPONSE_CODES.get(code, "")),
                msg_id=data.get("msgId"),
                time=data.get("time"),
                success_num=int(data.get("successNum", 0)),
                fail_num=int(data.get("failNum", 0)),
            )

        except (ChuanglanAuthError, ChuanglanApiError):
            raise
        except Exception as e:
            logger.error(f"未知错误：{e}")
            return SmsResponse(
                code="ERROR",
                msg=f"发送失败：{str(e)}",
            )

    async def query_balance(self) -> BalanceResponse:
        """查询账户余额

        Returns:
            BalanceResponse: 余额响应

        Raises:
            ChuanglanAuthError: 认证失败时抛出
            ChuanglanApiError: API 调用失败时抛出
            ChuanglanNetworkError: 网络错误时抛出
            ChuanglanTimeoutError: 请求超时

        Example:
            ```python
            balance = await client.query_balance()
            if balance.success:
                print(f"账户余额：{balance.balance}元")
            ```
        """
        payload = {
            "account": self.config.chuanglan_account,
            "password": self.config.chuanglan_password,
        }

        logger.info("查询账户余额")

        try:
            data = await self._request("POST", self.config.balance_url, payload)
            code = str(data.get("code", ""))

            self._check_response_code(code)

            balance = data.get("balance")
            if balance is not None:
                try:
                    balance = float(balance)
                except (ValueError, TypeError):
                    balance = None

            return BalanceResponse(
                code=code,
                msg=data.get("msg", self.RESPONSE_CODES.get(code, "")),
                balance=balance,
            )

        except (ChuanglanAuthError, ChuanglanApiError):
            raise
        except Exception as e:
            logger.error(f"未知错误：{e}")
            return BalanceResponse(
                code="ERROR",
                msg=f"查询失败：{str(e)}",
            )

    async def query_status(
        self,
        task_id: str,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        page: int = 1,
        page_size: int = 50,
    ) -> StatusResponse:
        """查询短信发送状态

        查看短信的发送状态，支持按时间范围查询。

        Args:
            task_id: 任务 ID，发送短信时返回
            start_time: 开始时间，格式：yyyy-MM-dd HH:mm:ss
            end_time: 结束时间，格式：yyyy-MM-dd HH:mm:ss
            page: 页码，默认 1
            page_size: 每页数量，默认 50

        Returns:
            StatusResponse: 状态响应

        Raises:
            ChuanglanAuthError: 认证失败时抛出
            ChuanglanApiError: API 调用失败时抛出
            ChuanglanNetworkError: 网络错误时抛出
            ChuanglanTimeoutError: 请求超时

        Example:
            ```python
            status = await client.query_status(
                task_id="25071018345400902898000000000001",
                start_time="2024-01-01 00:00:00",
                end_time="2024-01-01 23:59:59"
            )
            for item in status.statuses:
                print(f"{item.phone}: {item.status}")
            ```
        """
        payload = {
            "account": self.config.chuanglan_account,
            "password": self.config.chuanglan_password,
            "taskId": task_id,
            "page": page,
            "pageSize": page_size,
        }

        if start_time:
            payload["startTime"] = start_time

        if end_time:
            payload["endTime"] = end_time

        logger.info(f"查询发送状态：任务 ID={task_id}")

        try:
            data = await self._request("POST", self.config.status_url, payload)
            code = str(data.get("code", ""))

            self._check_response_code(code)

            status_list = data.get("status", [])
            statuses = [
                StatusItem(
                    phone=item.get("phone", ""),
                    status=item.get("status", ""),
                    send_time=item.get("sendTime"),
                    receive_time=item.get("receiveTime"),
                    report_status=item.get("reportStatus"),
                )
                for item in status_list
            ]

            return StatusResponse(
                code=code,
                msg=data.get("msg", self.RESPONSE_CODES.get(code, "")),
                statuses=statuses,
                total=len(statuses),
                page=page,
                page_size=page_size,
            )

        except (ChuanglanAuthError, ChuanglanApiError):
            raise
        except Exception as e:
            logger.error(f"未知错误：{e}")
            return StatusResponse(
                code="ERROR",
                msg=f"查询失败：{str(e)}",
            )
