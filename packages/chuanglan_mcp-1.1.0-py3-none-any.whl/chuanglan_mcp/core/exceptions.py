"""
异常处理模块

定义创蓝 V2 API 相关的自定义异常类，提供完善的错误处理能力
"""

from typing import Optional, Dict, Any


class ChuanglanError(Exception):
    """创蓝 API 基础异常类

    所有创蓝 API 相关异常的基类

    Attributes:
        message: 错误消息
        code: 错误代码
    """

    def __init__(self, message: str, code: Optional[str] = None) -> None:
        self.message = message
        self.code = code
        super().__init__(self.message)

    def to_dict(self) -> Dict[str, Optional[str]]:
        """转换为字典格式，便于序列化"""
        return {
            "error": self.__class__.__name__,
            "message": self.message,
            "code": self.code,
        }


class ChuanglanAuthError(ChuanglanError):
    """认证错误

    当账号、密码错误或账户状态异常时抛出

    V2 错误码说明:
        101: 无此用户
        102: 密码错
        103: 提交过快
        117: 客户端 IP 错误
        118: 用户没有相应的发送权限
        119: 用户已过期
        145: 验签失败
    """

    ERROR_CODES: Dict[str, str] = {
        "101": "无此用户",
        "102": "密码错",
        "103": "提交过快",
        "117": "客户端 IP 错误",
        "118": "用户没有相应的发送权限",
        "119": "用户已过期",
        "145": "验签失败",
    }

    def __init__(self, code: str, message: Optional[str] = None) -> None:
        if message is None:
            message = self.ERROR_CODES.get(code, "认证失败")
        super().__init__(message, code)


class ChuanglanApiError(ChuanglanError):
    """API 调用错误

    当 API 请求参数错误或业务处理失败时抛出

    V2 错误码说明:
        104: 系统忙
        105: 敏感短信
        106: 消息长度错
        107: 包含错误的手机号码
        108: 手机号码个数错
        109: 无发送额度
        110: 不在发送时间内
        111: 超出该账户当月发送额度限制
        112: 产品错误
        113: 扩展码格式错
        114: 可用参数组个数错误
        116: 签名不合法或未带签名
        120: 违反防盗用策略
        123: 发送类型错误
        124: 白模板匹配错误
        125: 匹配驳回模板，提交失败
        127: 定时发送时间格式错误
        128: 内容编码失败
        129: JSON 格式错误
        130: 请求参数错误
        132: 消息长度错 (>3500 或<=0)
        133: 单一手机号错误
        134: 违反防盗策略，超过月发送限制
        135: 超过同一手机号相同内容发送限制
        136: 不可批量提交验证码短信
        139: 超出安全发送时间
        140: 短信内容解密错误
        144: 产品未上线限制日发送数量
        152: 模板不存在
        153: 消息长度错 (>2000 或<=0)
        154: 长短信拼接错误
        155: 转发失败
        158: 退订语不符合规范
        159: 触发反轰炸策略
    """

    ERROR_CODES: Dict[str, str] = {
        "104": "系统忙",
        "105": "敏感短信",
        "106": "消息长度错",
        "107": "包含错误的手机号码",
        "108": "手机号码个数错",
        "109": "无发送额度",
        "110": "不在发送时间内",
        "111": "超出该账户当月发送额度限制",
        "112": "产品错误",
        "113": "扩展码格式错",
        "114": "可用参数组个数错误",
        "116": "签名不合法或未带签名",
        "120": "违反防盗用策略",
        "123": "发送类型错误",
        "124": "白模板匹配错误",
        "125": "匹配驳回模板，提交失败",
        "127": "定时发送时间格式错误",
        "128": "内容编码失败",
        "129": "JSON 格式错误",
        "130": "请求参数错误",
        "132": "消息长度错",
        "133": "单一手机号错误",
        "134": "违反防盗策略，超过月发送限制",
        "135": "超过同一手机号相同内容发送限制",
        "136": "不可批量提交验证码短信",
        "139": "超出安全发送时间",
        "140": "短信内容解密错误",
        "144": "产品未上线限制日发送数量",
        "152": "模板不存在",
        "153": "消息长度错",
        "154": "长短信拼接错误",
        "155": "转发失败",
        "158": "退订语不符合规范",
        "159": "触发反轰炸策略",
    }

    def __init__(self, code: str, message: Optional[str] = None) -> None:
        if message is None:
            message = self.ERROR_CODES.get(code, f"API 错误：{code}")
        super().__init__(message, code)


class ChuanglanValidationError(ChuanglanError):
    """参数验证错误

    当输入参数验证失败时抛出

    Attributes:
        field: 验证失败的字段名
    """

    def __init__(self, field: str, message: str) -> None:
        self.field = field
        super().__init__(f"{field}: {message}", "VALIDATION_ERROR")

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        result = super().to_dict()
        result["field"] = self.field
        return result


class ChuanglanNetworkError(ChuanglanError):
    """网络错误

    当网络请求失败时抛出

    Attributes:
        original_error: 原始异常对象
    """

    def __init__(
        self,
        message: str,
        original_error: Optional[Exception] = None,
    ) -> None:
        self.original_error = original_error
        super().__init__(f"网络错误：{message}", "NETWORK_ERROR")


class ChuanglanTimeoutError(ChuanglanError):
    """超时错误

    当请求超时时抛出
    """

    def __init__(self, timeout: int) -> None:
        super().__init__(f"请求超时（{timeout}秒）", "TIMEOUT_ERROR")
