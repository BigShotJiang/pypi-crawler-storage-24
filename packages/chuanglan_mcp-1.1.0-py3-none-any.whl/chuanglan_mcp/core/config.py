"""
配置管理模块

使用 Pydantic Settings 进行配置管理，支持环境变量和 .env 文件
提供类型安全的配置访问
"""

import logging
from functools import lru_cache
from typing import Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)


class Settings(BaseSettings):
    """
    应用配置类

    配置优先级：
    1. 环境变量
    2. .env 文件
    3. 默认值

    Attributes:
        sms_url: 短信发送地址 (V2)
        balance_url: 余额查询地址
        status_url: 状态报告查询地址
        chuanglan_account: 创蓝 API 账号
        chuanglan_password: 创蓝 API 密码
        request_timeout: 请求超时时间（秒）
        max_retries: 最大重试次数
        retry_delay: 重试延迟（秒）
        log_level: 日志级别
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ==================== API 端点配置 (V2) ====================
    sms_url: str = Field(
        default="https://smssh.253.com/msg/sms/v2/tpl/send",
        description="短信发送地址 (V2 接口)",
        alias="CHUANGLAN_SMS_URL",
    )

    balance_url: str = Field(
        default="https://smssh.253.com/msg/balance/json",
        description="余额查询地址",
        alias="CHUANGLAN_BALANCE_URL",
    )

    status_url: str = Field(
        default="https://smssh.253.com/msg/status/json",
        description="状态报告查询地址",
        alias="CHUANGLAN_STATUS_URL",
    )

    # ==================== 创蓝账号配置 ====================
    chuanglan_account: Optional[str] = Field(
        default=None,
        description="创蓝 API 账号",
        alias="CHUANGLAN_ACCOUNT",
    )

    chuanglan_password: Optional[str] = Field(
        default=None,
        description="创蓝 API 密码 (明文)",
        alias="CHUANGLAN_PASSWORD",
    )

    # ==================== 请求配置 ====================
    request_timeout: int = Field(
        default=30,
        description="请求超时时间（秒）",
        alias="REQUEST_TIMEOUT",
        ge=1,
        le=300,
    )

    max_retries: int = Field(
        default=3,
        description="最大重试次数",
        alias="REQUEST_MAX_RETRIES",
        ge=0,
        le=10,
    )

    retry_delay: float = Field(
        default=1.0,
        description="重试延迟（秒）",
        alias="REQUEST_RETRY_DELAY",
        ge=0,
        le=30,
    )

    # ==================== 日志配置 ====================
    log_level: str = Field(
        default="INFO",
        description="日志级别",
        alias="LOG_LEVEL",
    )

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, value: str) -> str:
        """验证日志级别"""
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if value.upper() not in valid_levels:
            raise ValueError(
                f"日志级别必须是 {', '.join(valid_levels)} 之一"
            )
        return value.upper()

    def validate_credentials(self) -> bool:
        """
        验证是否配置了凭证

        Returns:
            bool: 是否配置了凭证
        """
        return bool(self.chuanglan_account and self.chuanglan_password)


@lru_cache
def get_settings() -> Settings:
    """
    获取配置实例（单例模式）

    Returns:
        Settings: 配置实例
    """
    return Settings()


# 全局配置实例
settings = get_settings()
