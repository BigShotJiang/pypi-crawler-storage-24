"""
Core cutout logic: create rectangular pixel crops from a GeoTIFF centred on
GeoJSON bounding boxes, with optional random shift.  Intersecting annotations
are returned in COCO format (clipped and flagged when truncated).

Author: Steffen Merseburg
"""

import os
import json
from typing import Optional

import numpy as np
import geopandas as gpd
import rasterio
from rasterio.features import rasterize
from PIL import Image
from rasterio.windows import Window
from shapely import union
from shapely.geometry import box, Polygon


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _load_and_reproject_features(
    geojson: str,
    src 
) -> gpd.GeoDataFrame:

    """
    Load GeoJSON features in EPSG:4326 and reproject them into the CRS of the GeoTIFF and then into pixel space.

    Parameters
    ----------
    geojson : str
        Path to a GeoJSON file or GeoJSON string containing features in EPSG:4326 to be reprojected.
    src : rasterio.DatasetReader
        GeoTIFF dataset to reproject into.

    Returns
    -------
    gpd.GeoDataFrame
        GeoDataFrame with the reprojected features in pixel space in col, row coordinates.
    """
    gdf = gpd.read_file(geojson)              # loads as EPSG:4326

    if src.crs.to_epsg() != 4326:
        gdf = gdf.to_crs(f"EPSG:{src.crs.to_epsg()}")

    # Convert all geometries to pixel space (col, row) in one pass
    
    #transformer = lambda x: np.array(src.index(x[:, 0], x[:, 1]),dtype=np.float64).T
    # transform to row, col
    transformer = lambda x: np.array(rasterio.transform.AffineTransformer(src.transform).rowcol(x[:, 0], x[:, 1]),dtype=np.float64).T
    gdf.geometry = gdf.geometry.transform(transformer)

    #change from rowcol to colrow
    transformer = lambda x: np.array([x[:, 1], x[:, 0]],dtype=np.float64).T
    gdf.geometry = gdf.geometry.transform(transformer)

    return gdf

def _save_image_cut_out(src, window, image_id, output_dir,bands=None, geotiff=True, png=True):

    image = src.read(bands,window=window)  # (bands, H, W)

    if not os.path.exists(f"{output_dir}"):
        os.makedirs(f"{output_dir}")
    if png:
        try:
            if image.dtype != np.uint8:
                data = image.astype(np.float32)
                band_min = data.min(axis=(1, 2), keepdims=True)
                band_max = data.max(axis=(1, 2), keepdims=True)
                denom = np.where(band_max - band_min == 0, 1, band_max - band_min)
                data = ((data - band_min) / denom * 255).astype(np.uint8)

            data = np.transpose(data, (1, 2, 0))  # (H, W, C)
            Image.fromarray(data).save(f"{output_dir}/cutout_{image_id}.png")
        except Exception as e:
            print(f"failed to save png {image_id}\n{e}")

    if geotiff:
        meta = src.meta.copy()
        meta.update(
                {
                    "driver": "GTiff",
                    "height": image.shape[1],
                    "width": image.shape[2],
                    "transform": src.window_transform(window),
                }
        )
        try:
            with rasterio.open(f"{output_dir}/cutout_{image_id}.tiff", "w", **meta) as dest:
                dest.write(image)
        except Exception as e:
            print(f"failed to save geotiff {image_id}\n{e}")


def _create_save_cutout_mask(width, height, cutout_width_px, cutout_height_px, gdf):

    gdf_x_y = gdf.translate(xoff=-cutout_width_px, yoff=-cutout_height_px)
    gdf_x = gdf.translate(xoff=-cutout_width_px, yoff=0)
    gdf_y = gdf.translate(xoff=0, yoff=-cutout_height_px)

    gdf_1 = union(gdf.geometry.union(gdf_x.geometry).convex_hull,
                        gdf.geometry.union(gdf_y.geometry).convex_hull)

    gdf_2 = union(gdf_x_y.geometry.union(gdf_x.geometry).convex_hull,
                        gdf_x_y.geometry.union(gdf_y.geometry).convex_hull)

    mask = rasterize(
        shapes = gdf_1.union(gdf_2),
        out_shape = (height,width),
        fill = 0,
        dtype = np.uint8
    )
    return mask.astype(np.bool)
    

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def make_cutouts(
    geotiff_path: str,
    geojson: str,
    output_dir: str,
    coco_path: str,
    cutout_width_px: int = 512,
    cutout_height_px: Optional[int] = None,
    random_shift: float = 0.0,
    bands :list[int] = None,
    method :str = "save",
    geotiff_out :bool = True,
    png_out :bool = True,
    rng_seed: Optional[int] = None,
) -> tuple[np.ndarray, dict]:
    
    """
    Create rectangular pixel crops from a GeoTIFF centred on GeoJSON bounding
    boxes, with optional random shift.  Intersecting annotations are returned in
    COCO format (clipped and flagged when truncated).

    Parameters
    ----------
    geotiff_path : str
        Path to the GeoTIFF file.
    geojson : str
        Path to the GeoJSON file containing bounding boxes.
    output_dir : str
        Directory where output images will be saved.
    coco_path : str
        Path to the COCO annotations file (appended or overwritten).
    cutout_width_px : int, default=512
        Width of the cutouts in pixels.
    cutout_height_px : int, optional
        Height of the cutouts in pixels.  Defaults to `cutout_width_px` if not
        specified.
    random_shift : float, default=0.0
        Random shift factor: 0-1, where 0 means no shift and 1 means maximum shift.
    bands : list[int], optional
        List of bands to read from the GeoTIFF file.  If not specified, all bands
        are read.
    method : str, default="save"
        Method for saving cutouts.  One of "save" or "fallback" or "ignore".
    rng_seed : int, optional
        RNG seed for reproducibility.

    Returns
    -------
    tuple
        A tuple containing the cutout image as a numpy array and the COCO annotations
        as a dictionary.
    """
    if method not in ["save", "fallback", "ignore"]:
        raise ValueError(f"unknown method {method}, use one of ['save', 'fallback', 'ignore']")

    np.random.seed(rng_seed)

    if cutout_height_px is None:
        cutout_height_px = cutout_width_px

    half_w = cutout_width_px  / 2.0
    half_h = cutout_height_px / 2.0

    # load coco annotations
    if os.path.exists(coco_path):
        with open(coco_path, "r") as f:
            coco = json.load(f)
        image_id = 1
        ann_id = 1
        for img in coco["images"]:
            image_id = max(image_id, int(img['id'])) + 1
        for ann in coco["annotations"]:
            ann_id = max(ann['id'], ann_id) +1
        categories = {}
        for cat in coco["categories"]:
            categories[cat["name"]] = cat['id']
    else:
        coco = {
                "images": [],
                "categories": [],
                "annotations": [],
            }
        image_id = 1
        ann_id = 1
        categories  = {}

    with rasterio.open(geotiff_path) as src:
        img_w, img_h  = src.width, src.height

        features = _load_and_reproject_features(geojson, src)
        if method != "ignore":
            raster_mask = _create_save_cutout_mask(img_w, img_h, cutout_width_px, cutout_height_px, features)

        for target_px in features.geometry:

            t_minx, t_miny, t_maxx, t_maxy = target_px.bounds

            bbox_w_px = t_maxx - t_minx
            bbox_h_px = t_maxy - t_miny
            
            max_shift_col = max(0, round(random_shift*(half_w-bbox_w_px/2)))
            max_shift_row = max(0, round(random_shift*(half_h-bbox_h_px/2)))

            raw_col0_center = target_px.centroid.x - half_w
            raw_row0_center = target_px.centroid.y - half_h

            col0_min = int(round(max(0.0, min(raw_col0_center - max_shift_col, img_w - cutout_width_px))))
            col0_max = int(round(max(0.0, min(raw_col0_center + max_shift_col, img_w - cutout_width_px))))

            row0_min = int(round(max(0.0, min(raw_row0_center - max_shift_row, img_h - cutout_height_px))))
            row0_max = int(round(max(0.0, min(raw_row0_center + max_shift_row, img_h - cutout_height_px))))

            if method == "ignore":
                col0 = np.random.randint(col0_min, col0_max + 1)
                row0 = np.random.randint(row0_min, row0_max + 1)
            else:
                cols = np.arange(col0_min, col0_max+1)
                rows = np.arange(row0_min, row0_max+1)
                origins = np.array(np.meshgrid(cols, rows)).transpose(1, 2, 0)
                mask = ~raster_mask[row0_min:row0_max+1, col0_min:col0_max+1].astype(bool)
                if mask.max() == False:
                    # No valid cut out origins
                    if method == "save":
                        continue
                    else:
                        mask[:,:] = 1
                origins = origins[mask]
                
                idx=np.random.choice(np.arange(origins.shape[0]))
                col0, row0 = origins[idx]


            actual_w = min(cutout_width_px,  img_w - col0)
            actual_h = min(cutout_height_px, img_h - row0)

            window = Window(col_off=col0, row_off=row0, width=actual_w, height=actual_h)
            
            _save_image_cut_out(src, window, image_id, output_dir, bands, geotiff=geotiff_out, png=png_out)
            coco_image = {
                "id": image_id,
                "width": actual_w,
                "height": actual_h,
                "file_name": f"cutout_{image_id}.png",
                "geotiff_source": str(geotiff_path),
                "cutout_col_offset": int(col0),
                "cutout_row_offset": int(row0),
            }
            coco["images"].append(coco_image)

            cutout_box = box(col0, row0, col0 + actual_w, row0 + actual_h)
            intersecting = features[features.intersects(cutout_box)]

            for idx, feat in intersecting.iterrows():
                feat_px = feat.geometry
                clipped = cutout_box.intersection(feat_px)

                if clipped.is_empty:
                    continue

                is_truncated = not cutout_box.contains(feat_px)

                fx_min, fy_min, fx_max, fy_max = clipped.bounds
                bbox= [
                        round(fx_min - col0, 4),
                        round(fy_min - row0, 4),
                        round(fx_max - fx_min, 4),
                        round(fy_max - fy_min, 4),
                    ]

                ox_min, oy_min, ox_max, oy_max = feat_px.bounds
                original_bbox = [
                    round(ox_min - col0, 4),
                    round(oy_min - row0, 4),
                    round(ox_max - ox_min, 4),
                    round(oy_max - oy_min, 4),
                ]
                
                cat_name = str(
                    feat.get("category", feat.get("class", feat.get("label", "object")))
                )
                if cat_name not in categories.keys():
                    categories[cat_name] = len(categories.keys()) + 1
                cat_id = categories[cat_name]

                annotation = {
                    "id": ann_id,
                    "image_id": image_id,
                    "category_id": cat_id,
                    "bbox": bbox,
                    "bbox_mode": "xywh",
                    "area": round(bbox[2] * bbox[3], 4),
                    "iscrowd": 0,
                    "is_truncated": is_truncated,
                    "original_bbox": original_bbox,
                }
                if type(feat_px) == Polygon:
                    annotation["segmentation"] = [[float(value) for value in np.array([ (x-col0, y-row0) for x,y in list(clipped.exterior.coords) ]).flatten()]]
                    annotation["original_segmentation"] = [[float(value) for value in np.array([ (x-col0, y-row0) for x,y in list(feat_px.exterior.coords) ]).flatten()]]

                coco["annotations"].append(annotation)
                ann_id += 1
            image_id += 1

    coco["categories"] = [{"id": cat_id, "name": cat_name} for cat_name, cat_id in categories.items()]
    with open(coco_path, "w") as f:
        json.dump(coco, f, indent=4)

if __name__ == "__main__":

    make_cutouts(
        "tests/S2_test_image.tif",
        "tests/test_annotation_points.geojson",
        "tests/cutouts/data",
        coco_path="tests/cutouts/annotations.json",
        cutout_width_px=400,
        cutout_height_px=200,
        random_shift=0,
        method="fallback"
    )