"""
Command-line interface for geotiff-cutout.

Usage
-----
geotiff-cutout <image.tif> <annotations.geojson> [OPTIONS]

Options
-------
--width   INT    Cutout width in pixels  (default: 512)
--height  INT    Cutout height in pixels (default: same as width -> square)
--shift   FLOAT  Random shift factor 0-1 (default: 0.5)
--output  DIR    Output directory        (default: cutouts_output)
--seed    INT    RNG seed for reproducibility
"""

from __future__ import annotations

import argparse

from .cutout import make_cutouts


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="geotiff-cutout",
        description=(
            "Create rectangular pixel cutouts from a GeoTIFF centred on "
            "GeoJSON bounding boxes, with optional random shift.  "
            "One cutout is generated per feature in the GeoJSON."
        ),
    )

    parser.add_argument("geotiff",  help="Path to the source GeoTIFF file.")
    parser.add_argument("geojson",  help="Path to the GeoJSON annotation file (EPSG:4326).")

    parser.add_argument(
        "--width", type=int, default=512, metavar="PX",
        help="Cutout width in pixels (default: 512).",
    )
    parser.add_argument(
        "--height", type=int, default=None, metavar="PX",
        help="Cutout height in pixels (default: same as --width, i.e. square).",
    )
    parser.add_argument(
        "--shift", type=float, default=0.5, metavar="F",
        help=(
            "Random shift factor in [0, 1].  "
            "0 = centred on bbox centroid; "
            "1 = bbox may touch cutout edge (default: 0.5)."
        ),
    )
    parser.add_argument(
        "--output", default="cutouts_output", metavar="DIR",
        help="Directory to write cutout PNGs and COCO JSONs (default: cutouts_output).",
    )
    parser.add_argument(
        "--seed", type=int, default=42, metavar="N",
        help="Integer RNG seed for reproducibility (default: 42).",
    )
    parser.add_argument(
        "--coco" type=str, default=None, metavar="PATH",
        help="Path to the COCO annotations file (appended).",
    )
    parser.add_argument(
        "--bands", type=list, default=None, metavar="LIST",
        help="List of bands to read from the GeoTIFF (default: all).",
    )
    parser.add_argument(
        "--method", type=str, default="fallback", metavar="STR",
        help=(
            "Method for creating cutouts: "
            "'fallback' (default), 'save' or 'ignore'."
            "save: cutouts never cut through annotation"
            "ignore: other bounding boxes are ignored"
            "fallback: if possible no cut through other bounding boxes"
        ),
    )
    parser.add_argument(
        "--geotiff_out", type=bool, default=True, metavar="BOOL",
        help="Save GeoTIFF cutouts (default: True).",
    )
    parser.add_argument(
        "--png_out", type=bool, default=True, metavar="BOOL",
        help="Save PNG cutouts (default: True).",
    )

    args = parser.parse_args(argv)

    if not (0.0 <= args.shift <= 1.0):
        parser.error("--shift must be in the range [0, 1].")

    make_cutouts(
        geotiff_path=args.geotiff,
        geojson_path=args.geojson,
        output_dir=args.output,
        coco_path=args.coco,
        cutout_width_px=args.width,
        cutout_height_px=args.height,
        random_shift=args.shift,
        bands=None,
        method=args.method,
        geotiff_out=args.geotiff_out,
        png_out=args.png_out,
        rng_seed=args.seed,
    )

if __name__ == "__main__":
    main()
