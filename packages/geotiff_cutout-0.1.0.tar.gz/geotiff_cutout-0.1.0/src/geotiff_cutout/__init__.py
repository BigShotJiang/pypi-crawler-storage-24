"""
geotiff-cutout
==============
Create rectangular pixel crops from a GeoTIFF centred on GeoJSON bounding
boxes, with optional random shift.  Intersecting annotations are returned in
COCO format.
"""

from importlib.metadata import version, PackageNotFoundError

from .cutout import make_cutout, make_all_cutouts

try:
    __version__ = version("geotiff-cutout")
except PackageNotFoundError:  # running from source without installation
    __version__ = "unknown"

__all__ = [
    "make_cutout",
    "make_all_cutouts",
]
