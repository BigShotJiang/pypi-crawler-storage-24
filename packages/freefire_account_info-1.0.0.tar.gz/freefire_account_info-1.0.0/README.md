# Free Fire Account Info

A Python library to retrieve Free Fire account information using UID and password.

## Installation

```bash
pip install freefire-account-info