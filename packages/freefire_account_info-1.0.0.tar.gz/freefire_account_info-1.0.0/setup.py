from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="freefire-account-info",           # Package name on PyPI
    version="1.0.0",
    author="Unknown666",
    author_email="your.email@example.com",
    description="Retrieve Free Fire account details using UID and password",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(include=["freefire_account", "freefire_account.*"]),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "aiohttp>=3.8.0",
        "pycryptodome>=3.15.0",
        "protobuf>=3.20.0",
        "requests>=2.25.0",
        "psutil>=5.9.0",
        "jwt>=1.3.0",
        "google-play-scraper>=0.1.2",
        "cfonts>=1.0.0",
    ],
    include_package_data=True,
)