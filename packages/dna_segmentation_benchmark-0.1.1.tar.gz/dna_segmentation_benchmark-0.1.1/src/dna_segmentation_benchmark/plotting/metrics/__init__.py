# Create the metrics module
