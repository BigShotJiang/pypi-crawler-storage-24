"""Alembic migration helpers for consuming applications."""

from alembic import context
from sqlalchemy import engine_from_config, pool


def run_migrations_offline(target_metadata):
    """Run migrations in 'offline' mode — emit SQL without a live connection."""
    config = context.config
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online(target_metadata):
    """Run migrations in 'online' mode — execute against a live database."""
    config = context.config
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
        )
        with context.begin_transaction():
            context.run_migrations()
