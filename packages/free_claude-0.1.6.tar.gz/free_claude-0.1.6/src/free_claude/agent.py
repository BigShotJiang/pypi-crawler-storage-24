"""Core agent loop for free-claude — streaming, tools, MCP, and rich UI."""
import contextlib
import io
import json
import os
import sys
import threading
from typing import Optional
import urllib.error
import urllib.request

from .auth import get_token, refresh_token
from .config import API_BASE, DEFAULT_SYSTEM_PROMPT, MODELS
from .app_config import config as app_config
from .logger import log
from .mcp import StdioMCPClient, create_mcp_client, discover_hfi_plugins
from .tools import BUILTIN_TOOLS, execute_tool
from . import rich_ui as ui
from .search import ProjectIndexer
from .teammates import AgentTeam, TeammateRole, ROLE_DESCRIPTIONS, TaskStatus
from .ui_components import show_search_results, show_team_status, show_task_monitor
from .core import ContextManager, StreamingClient, ToolExecutor
from .core.streaming import DEFAULT_THINKING_BUDGET
from .intelligence import TaskPlanner, MemoryStore, ContextSummarizer
from .session import SessionHistory, CheckpointManager, SessionExporter


class Agent:
    """Free Claude agent with tool use, MCP support, and rich UI."""

    def __init__(self, model: str = "default", system: str = None,
                 mcp_servers: dict = None, mcp_clients: list = None,
                 auto_plugins: bool = True,
                 thinking_budget: int = 0):
        app_config.load()

        # ── Step 1: Auth (with visible feedback) ──────────────────────────
        self.token = self._init_token()

        # CLI model arg overrides config file
        resolved_model = model if model != "default" else app_config.model
        self.model = MODELS.get(resolved_model, MODELS["default"])
        self.system = system or app_config.system_prompt or DEFAULT_SYSTEM_PROMPT
        log.info("Agent init: model=%s", self.model)
        self.mcp_clients: list = []
        self.tools: list = list(BUILTIN_TOOLS)
        self.thinking_budget: int = thinking_budget  # 0 = disabled

        # Core subsystems
        self._ctx = ContextManager()
        self._rate_limits: dict = {}

        # Phase 2 — Intelligence & Session
        self._memory = MemoryStore()
        self._planner = TaskPlanner()
        self._summarizer = ContextSummarizer()
        self._history = SessionHistory()
        self._checkpoint = CheckpointManager()
        self._exporter = SessionExporter()
        self._current_session_id: Optional[str] = None

        # ── Step 2: Plugin loading ────────────────────────────────────────
        # Auto-load is intentionally disabled at startup to avoid blocking/hanging.
        # Whitelisted stdio plugins (context7, playwright, serena) can take 5-30s
        # on first run (npx downloads the package). Instead, we note they're available
        # and let the user opt-in via --plugin <name> or /plugin <name> in chat.
        self._bg_plugin_thread: Optional[threading.Thread] = None

        # Pre-created MCP clients (already started by cli.py — don't start again!)
        if mcp_clients:
            for client in mcp_clients:
                self.mcp_clients.append(client)
                self.tools.extend(client.get_tool_definitions())

        # stdio MCP servers from {name: [cmd, args...]} dict
        if mcp_servers:
            for name, cmd in mcp_servers.items():
                client = StdioMCPClient(name, cmd)
                if client.start():
                    self.mcp_clients.append(client)
                    self.tools.extend(client.get_tool_definitions())

    # ── Token init with feedback ───────────────────────────────────────

    def _init_token(self) -> str:
        """Refresh/load auth token with a visible spinner so user knows we're working."""
        from rich.text import Text
        from .config import TOKEN_FILE

        if not os.path.exists(TOKEN_FILE):
            # No token at all — get_token() will print the error and exit
            return get_token()

        # Show spinner while refreshing (network call can take 1-5s)
        result_holder = [None]
        error_holder = [None]

        def _do_refresh():
            try:
                result_holder[0] = refresh_token() or get_token()
            except Exception as e:
                error_holder[0] = e

        t = threading.Thread(target=_do_refresh, daemon=True)
        t.start()

        # Only show spinner if it takes > 0.3s (avoid flicker on fast connections)
        t.join(timeout=0.3)
        if t.is_alive():
            status_text = Text.assemble(
                ("  🔐 ", "dim"), ("Authenticating", "dim cyan"), ("...", "dim")
            )
            with ui.console.status(status_text, spinner="dots"):
                t.join(timeout=12)  # max 12s for auth

        if error_holder[0]:
            raise error_holder[0]
        if result_holder[0] is None:
            return get_token()
        return result_holder[0]

    # ── Compatibility shims for old code that reads self.messages ──────

    @property
    def messages(self) -> list:
        return self._ctx.messages

    @messages.setter
    def messages(self, val: list):
        self._ctx.messages = val

    # ── Plugin loading ─────────────────────────────────────────────────

    def _auto_load_plugins(self):
        """Auto-discover and load MCP plugins in parallel with progress feedback."""
        import shutil
        from rich.text import Text

        plugins = discover_hfi_plugins()
        if not plugins:
            return

        # Filter candidates first (skip unresolvable ones immediately)
        # Rules for auto-load (startup):
        #   - Only whitelisted stdio plugins are auto-loaded (fast, well-known ones)
        #   - HTTP/SSE plugins are NEVER auto-loaded (network calls = hang)
        #   - Non-whitelisted stdio plugins require explicit: --plugin <name> or /plugin <name>
        #   - Whitelisted plugins are still skipped if command not in PATH
        _AUTOLOAD_WHITELIST = {"context7", "serena", "playwright"}

        candidates = {}
        skipped_reasons = {}
        for name, config in plugins.items():
            transport = config.get("type", "stdio")
            headers = config.get("headers", {})
            # Only whitelist — skip everything else at startup
            if name not in _AUTOLOAD_WHITELIST:
                skipped_reasons[name] = f"not in auto-load list — use: fclaude --plugin {name}"
                continue
            # Skip plugins that need env vars not set
            if any("${" in v for v in headers.values()):
                skipped_reasons[name] = "needs API key (env var not set)"
                continue
            # Skip stdio plugins whose command is not installed
            if transport == "stdio":
                cmd = config.get("command", "")
                if cmd and not shutil.which(cmd):
                    install_hint = {
                        "npx": "install Node.js: brew install node (macOS) | apt install nodejs npm (Linux)",
                        "node": "install Node.js: brew install node (macOS) | apt install nodejs npm (Linux)",
                        "uvx": "install uv: pip install uv  OR  curl -Lsf https://astral.sh/uv/install.sh | sh",
                        "php": "install PHP: brew install php (macOS) | apt install php (Linux)",
                    }.get(cmd, f"install {cmd!r} and ensure it is on your PATH")
                    skipped_reasons[name] = f"command not found: {cmd!r} — {install_hint}"
                    continue
            candidates[name] = config

        if not candidates:
            # Show why nothing loaded (only if there were plugins defined)
            if plugins and skipped_reasons:
                ui.console.print(Text.assemble(
                    ("  ⚙ ", "dim"), ("MCP: ", "dim cyan"),
                    (f"0/{len(plugins)} plugins available ", "dim"),
                    ("(run 'fclaude --plugins' to see requirements)", "dim"),
                ))
            return

        # Show spinner while loading plugins in parallel
        results_lock = threading.Lock()
        loaded_clients = []  # list of (client, new_tools)

        def _try_start_one(name, config):
            # Each worker runs in its own thread — timeout enforced by outer deadline
            try:
                client = create_mcp_client(name, config)
                success_holder = [False]

                def _start():
                    buf = io.StringIO()
                    try:
                        with contextlib.redirect_stdout(buf):
                            success_holder[0] = client.start(verbose=False)
                    except Exception:
                        success_holder[0] = False

                st = threading.Thread(target=_start, daemon=True)
                st.start()
                st.join(timeout=35)  # per-plugin cap: generous for slow starters (Serena ~3-5s warmup + retries)

                if success_holder[0]:
                    new_tools = client.get_tool_definitions()
                    with results_lock:
                        loaded_clients.append((client, new_tools))
            except Exception:
                pass

        # Launch all candidates in parallel
        workers = []
        for name, config in candidates.items():
            w = threading.Thread(target=_try_start_one, args=(name, config), daemon=True)
            workers.append(w)
            w.start()

        # Wait for ALL workers simultaneously — background thread, max 12s total
        import time
        deadline = time.monotonic() + 45.0  # global deadline: accommodates slow MCP servers
        while any(w.is_alive() for w in workers):
            if time.monotonic() > deadline:
                break
            time.sleep(0.05)
        # Reap all threads (non-blocking cleanup)
        for w in workers:
            w.join(timeout=0.05)

        # Register results (thread-safe, all workers done now)
        loaded_names = []
        for client, new_tools in loaded_clients:
            self.mcp_clients.append(client)
            self.tools.extend(new_tools)
            loaded_names.append(f"{client.name}({len(new_tools)})")

        # Summary line
        total = len(plugins)
        ok = len(loaded_clients)
        skipped = total - ok
        if ok > 0:
            ui.console.print(Text.assemble(
                ("  ✓ ", "bold green"),
                ("MCP: ", "dim cyan"),
                (f"{ok} plugin{'s' if ok != 1 else ''} loaded", "green"),
                (f" — {', '.join(loaded_names)}", "dim"),
            ))
        if skipped_reasons:
            ui.console.print(Text.assemble(
                ("  ⚙ ", "dim"),
                (f"{len(skipped_reasons)} plugin{'s' if len(skipped_reasons) != 1 else ''} skipped", "dim"),
                (" (run 'fclaude --plugins' for details)", "dim"),
            ))

    # ── Internal helpers ───────────────────────────────────────────────

    def _streamer(self) -> StreamingClient:
        """Return a fresh StreamingClient with current token/model/tools."""
        return StreamingClient(API_BASE, self.token, self.model,
                               self.system, self.tools,
                               thinking_budget=self.thinking_budget)

    def _is_simple_query(self, text: str) -> bool:
        """Heuristic: detect if a query needs tools or can be answered directly.

        Simple queries → haiku without tools (~1s TTFT)
        Complex queries → full model with tools (~2.5s TTFT)
        """
        t = text.strip().lower()
        # "Continue / tiếp tục" signals → always complex (need tools + context)
        _continue_signals = (
            "continue", "tiếp tục", "tiep tuc", "keep going", "go on",
            "carry on", "proceed", "next", "finish", "complete", "done yet",
            "still working", "fix it", "fix that", "try again", "retry",
            "làm tiếp", "làm nốt", "hoàn thành", "xong chưa",
        )
        if any(sig in t for sig in _continue_signals):
            return False

        # Short greetings / chitchat
        if len(t) < 60 and any(t.startswith(w) for w in (
            "hi", "hello", "hey", "xin chào", "chào", "cảm ơn", "thanks",
            "thank you", "ok", "okay", "yes", "no", "yep", "nope",
        )):
            return True
        # Pure math / conversions
        import re
        if re.match(r'^[\d\s\+\-\*\/\^\(\)\%\.]+[=\?]?\s*$', t):
            return True
        # Knowledge/explanation questions (no file/system access needed)
        simple_patterns = [
            r'^(what|who|when|where|why|how)\s+is\b',
            r'^(explain|define|describe|tell me about)\b',
            r'^(translate|dịch)\b',
            r'^(write a (poem|joke|story|haiku))',
            r'^(list|name) \d+ ',
            r'^\d+\s*[\+\-\*\/]\s*\d+',  # math
        ]
        for pat in simple_patterns:
            if re.search(pat, t):
                return True
        # Contains file/system keywords → complex
        complex_keywords = [
            "file", "folder", "directory", "path", "run", "execute", "install",
            "tệp", "thư mục", "chạy", "cài",
            "code", "script", "function", "class", "debug", "error", "fix",
            "git", "docker", "pip", "npm", "bash", "terminal",
            "read", "write", "open", "save", "delete", "create",
            "search", "find", "grep", "ls", "cd",
            "web", "url", "http", "api", "fetch",
            "excel", "pdf", "csv", "image",
            # Image/file extensions mentioned in path
            ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
            ".mp4", ".mp3", ".wav", ".pdf", ".docx", ".xlsx",
            # Vietnamese image/file keywords
            "ảnh", "hình", "đọc", "xem", "phân tích", "mô tả",
            "tài liệu", "văn bản",
        ]
        if any(kw in t for kw in complex_keywords):
            return False
        # Default: use full model for anything over 80 chars (likely complex)
        return len(t) < 80

    def _fast_streamer(self) -> StreamingClient:
        """Return a haiku streamer without tools — for simple queries (~1s TTFT).
        Uses a compact system prompt to keep responses brief and fast.
        """
        from .config import MODELS
        haiku_model = MODELS.get("haiku", self.model)
        fast_system = (
            "You are a concise AI assistant. "
            "Answer directly and briefly — no bullet lists of features, "
            "no preamble. Match the user's language (Vietnamese if they write Vietnamese)."
        )
        return StreamingClient(API_BASE, self.token, haiku_model,
                               fast_system, [],  # no tools = faster
                               thinking_budget=0)

    def _maybe_summarize(self):
        """Auto-compress context if it's getting too large."""
        if self._summarizer.should_summarize(self._ctx.messages):
            from . import rich_ui as _ui
            _ui.print_info("📝 Context large — summarizing older messages...")
            self._ctx.messages = self._summarizer.maybe_compress(
                self._ctx.messages, API_BASE, self.token
            )

    def _executor(self) -> ToolExecutor:
        """Return a ToolExecutor bound to current mcp_clients."""
        return ToolExecutor(self.mcp_clients, execute_tool)

    # ── Public API ─────────────────────────────────────────────────────

    def run(self, user_input: str, max_iters: int = None, stream: bool = False) -> str:
        """Run the agent loop for a single user turn."""
        if max_iters is None:
            max_iters = app_config.max_tool_iterations
        self._ctx.add_user(user_input)
        header_printed = False

        # Always use the selected model with full tools — no haiku fast-routing.
        streamer = self._streamer()
        executor = self._executor()

        # Auto-compress context if too large before each turn
        self._maybe_summarize()

        for i in range(max_iters):
            try:
                if stream:
                    if not header_printed:
                        ui.print_assistant_header()
                        header_printed = True
                    response, rl = streamer.stream(self._ctx.get(), ui.console)
                else:
                    response, rl = streamer.call(self._ctx.get())
            except urllib.error.HTTPError as e:
                if e.code == 401:
                    self.token = refresh_token() or get_token()
                    streamer = self._streamer()
                    response, rl = streamer.call(self._ctx.get())
                else:
                    err = e.read().decode()
                    self._ctx.pop_last()
                    return f"❌ API Error {e.code}: {err[:200]}"
            except KeyboardInterrupt:
                self._ctx.pop_last()
                raise

            self._rate_limits = rl
            self._ctx.track_usage(response.get("usage", {}))

            stop_reason = response.get("stop_reason")
            content = response.get("content", [])
            self._ctx.add_assistant(content)

            # Text is already streamed chunk-by-chunk in streaming.py
            # No need to render again after the fact

            # Thinking blocks already streamed realtime in streaming.py
            # No need to render again after the fact

            if stop_reason == "end_turn":
                final_text = " ".join(
                    b.get("text", "") for b in content if b.get("type") == "text"
                ).strip()
                if stream:
                    ui.print_response_end()
                # Guard: if Claude returned nothing (e.g. only tool calls, no text),
                # avoid silent empty response — prompt user to retry.
                if not final_text and not stream:
                    return "(No response from model — please try again)"
                return final_text

            elif stop_reason == "tool_use":
                ui.print_step(i + 1, max_iters)

                tool_results = []
                for block in content:
                    if block.get("type") != "tool_use":
                        continue
                    tool_out = executor.run(block)
                    ui.print_tool_call(tool_out["name"], tool_out["detail"])
                    if tool_out["dropped"]:
                        ui.print_warning(f"Tool result truncated ({tool_out['dropped']:,} chars dropped)")
                    ui.print_tool_result(tool_out["result"])
                    tool_results.append(tool_out["payload"])

                self._ctx.add_user(tool_results)
                ui.print_step_end()
                if stream:
                    ui.console.print()
                continue

            else:
                text = " ".join(
                    b.get("text", "") for b in content if b.get("type") == "text"
                ).strip()
                return text or f"(stop: {stop_reason})"

        # Max iterations — force a final text-only summary
        return self._force_summary(streamer, stream)

    def _force_summary(self, streamer: StreamingClient, stream: bool) -> str:
        """Called when max_iters is hit — get a final answer without tools."""
        ui.print_summarizing()
        summary_msgs = self._ctx.get() + [{
            "role": "user",
            "content": (
                "You have used all available steps. "
                "Summarize what you have done so far and what still needs to be done. "
                "Be explicit about any unfinished parts so the user knows what to ask next. "
                "Do NOT call any more tools - text only."
            ),
        }]
        try:
            if stream:
                ui.print_assistant_header()
                response, _ = streamer.stream(summary_msgs, ui.console,
                                              include_tools=False)
                ui.print_response_end()
                result = response.get("full_text", "")
            else:
                response, _ = streamer.call(summary_msgs)
                result = " ".join(
                    b.get("text", "") for b in response.get("content", [])
                    if b.get("type") == "text"
                ).strip()
            # Hint user they can continue
            ui.console.print(
                "\n[dim]💡 Reached max tool steps. "
                "Type [bold cyan]'continue'[/bold cyan] to keep going, "
                "or [bold cyan]/save session[/bold cyan] to save progress.[/dim]\n"
            )
            return result
        except Exception:
            return "❌ Max iterations reached"

    def _wait_for_plugins(self, timeout: float = 12.0):
        """Wait for background plugin loading to finish (called before first API call)."""
        if self._bg_plugin_thread and self._bg_plugin_thread.is_alive():
            self._bg_plugin_thread.join(timeout=timeout)

    # ── Interactive chat ───────────────────────────────────────────────

    def chat(self):
        n_builtin = sum(1 for t in self.tools if not t["name"].startswith("mcp_"))
        n_mcp = len(self.tools) - n_builtin
        plugin_names = [c.name for c in self.mcp_clients] if self.mcp_clients else None
        ui.set_current_model(self.model)
        ui.print_banner(self.model, n_builtin, n_mcp, plugin_names=plugin_names,
                        thinking_budget=self.thinking_budget)

        while True:
            try:
                cwd = os.path.basename(os.getcwd())
                user_input = ui.print_user_prompt(cwd)
            except (KeyboardInterrupt, EOFError):
                ui.print_goodbye()
                self.cleanup()
                break

            stripped_input = user_input.strip()
            if not stripped_input:
                continue

            # "!" → run as shell command directly
            if stripped_input.startswith("!"):
                shell_cmd = stripped_input[1:].strip()
                if shell_cmd:
                    try:
                        result = os.popen(shell_cmd).read()
                        if result:
                            ui.console.print(result, end="")
                    except Exception as e:
                        ui.print_error(str(e))
                continue

            # Friendly command aliases without a leading slash for common chat controls
            lowered = stripped_input.lower()
            if lowered == "help" or lowered.startswith("help "):
                self._handle_cmd("/help")
                continue
            if lowered == "models" or lowered == "model" or lowered.startswith("model "):
                suffix = stripped_input[5:].strip() if lowered.startswith("model") and len(stripped_input) > 5 else ""
                self._handle_cmd(f"/model {suffix}".rstrip())
                continue

            if stripped_input.startswith("/"):
                self._handle_cmd(stripped_input)
                continue

            try:
                self.run(user_input, stream=True)
            except KeyboardInterrupt:
                ui.print_interrupted()
                self._ctx.pop_last()

    # ── Command handler ────────────────────────────────────────────────

    def _handle_cmd(self, cmd_line: str):
        parts = cmd_line.split()
        cmd = parts[0].lower()

        if cmd in ("/quit", "/exit"):
            ui.print_goodbye()
            self.cleanup()
            sys.exit(0)

        elif cmd in ("/clear", "/c"):
            self._ctx.clear()
            ui.print_success("Conversation cleared")

        elif cmd in ("/usage", "/u"):
            self._show_usage()

        elif cmd in ("/model", "/m"):
            if len(parts) > 1:
                requested = parts[1]
                resolved = MODELS.get(requested)
                if not resolved and requested in MODELS.values():
                    resolved = requested
                if resolved:
                    self.model = resolved
                    ui.set_current_model(self.model)
                    if hasattr(self, "_team") and self._team:
                        self._team.set_runtime(model=self.model)
                    ui.print_success(f"Model switched to: {self.model}")
                    ui.print_info("Use /model anytime to list choices again.")
                else:
                    ui.print_warning(f"Unknown model '{requested}'")
                    ui.console.print(f"[dim]Try one of:[/dim] [cyan]{', '.join(MODELS.keys())}[/cyan]")
                    ui.console.print("[dim]You can also paste the full model name, e.g.:[/dim] [cyan]model claude-opus-4-6[/cyan]")
            else:
                ui.print_models_table(MODELS, self.model)

        elif cmd in ("/tools", "/t"):
            ui.print_tools_table(self.tools)

        elif cmd == "/plugins":
            ui.print_plugins_table(discover_hfi_plugins())

        elif cmd == "/plugin":
            self._load_plugin(parts)

        elif cmd == "/mcp":
            self._add_mcp(parts)

        elif cmd in ("/search", "/find"):
            self._cmd_search(cmd_line, parts)

        elif cmd == "/index":
            self._cmd_index(cmd_line)

        elif cmd == "/teammate":
            self._cmd_teammate(cmd_line, parts)

        elif cmd == "/tasks":
            self._cmd_tasks(parts)

        elif cmd == "/task":
            self._cmd_task(parts)

        elif cmd == "/cd":
            if len(parts) > 1:
                try:
                    os.chdir(os.path.expanduser(parts[1]))
                    ui.print_success(f"Directory: {os.getcwd()}")
                except Exception as e:
                    ui.print_error(str(e))

        elif cmd == "/system":
            self.system = cmd_line[8:].strip() or DEFAULT_SYSTEM_PROMPT
            ui.print_success("System prompt updated")

        elif cmd == "/config":
            self._show_config()

        elif cmd in ("/save", "/s"):
            self._cmd_save(parts)

        elif cmd in ("/resume", "/r"):
            self._cmd_resume(parts)

        elif cmd == "/sessions":
            self._cmd_sessions()

        elif cmd in ("/memory", "/mem"):
            self._cmd_memory(cmd_line, parts)

        elif cmd == "/plan":
            self._cmd_plan(cmd_line, parts)

        elif cmd in ("/think", "/thinking"):
            self._cmd_think(parts)

        elif cmd in ("/autoplan", "/ap"):
            self._cmd_autoplan(cmd_line)

        elif cmd in ("/help", "/?"):
            self._show_help()

        else:
            ui.print_warning(f"Unknown command '{cmd}'. Type /help.")

    # ── Command implementations ────────────────────────────────────────

    def _show_usage(self):
        from rich.table import Table
        from rich import box
        summary = self._ctx.usage_summary()
        rl = self._rate_limits

        table = Table(box=box.ROUNDED, show_header=True,
                      header_style="bold cyan", border_style="dim cyan",
                      padding=(0, 2), show_edge=True)
        table.add_column("Metric", style="yellow", min_width=26, no_wrap=True)
        table.add_column("Value", style="white", justify="right")

        table.add_row("[bold]Session[/bold]", "")
        table.add_row("  Requests",      str(summary["requests"]))
        table.add_row("  Input tokens",  f"{summary['input_tokens']:,}")
        table.add_row("  Output tokens", f"{summary['output_tokens']:,}")
        table.add_row("  Total tokens",  f"[bold]{summary['total_tokens']:,}[/bold]")

        if rl:
            table.add_row("", "")
            table.add_row("[bold]Rate Limits[/bold]", "")
            table.add_row("  Input tokens  (remaining/limit)",
                          f"{rl.get('anthropic-ratelimit-input-tokens-remaining','?')} / "
                          f"{rl.get('anthropic-ratelimit-input-tokens-limit','?')}")
            table.add_row("  Output tokens (remaining/limit)",
                          f"{rl.get('anthropic-ratelimit-output-tokens-remaining','?')} / "
                          f"{rl.get('anthropic-ratelimit-output-tokens-limit','?')}")
            table.add_row("  Requests      (remaining/limit)",
                          f"{rl.get('anthropic-ratelimit-requests-remaining','?')} / "
                          f"{rl.get('anthropic-ratelimit-requests-limit','?')}")
            table.add_row("  Resets at", rl.get("anthropic-ratelimit-tokens-reset", "?"))
        else:
            table.add_row("", "")
            table.add_row("[dim]Rate limits[/dim]", "[dim](make a request first)[/dim]")

        table.add_row("", "")
        table.add_row("Cost", "[bold green]$0.00 — FREE! 🎉[/bold green]")
        ui.console.print()
        ui.console.print(table)
        ui.console.print()

    def _show_config(self):
        from rich.table import Table
        from rich import box
        from .app_config import _CONFIG_FILE
        table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan",
                      border_style="dim cyan", padding=(0, 2), show_edge=True)
        table.add_column("Key", style="yellow", min_width=22, no_wrap=True)
        table.add_column("Value", style="white")
        table.add_column("Source", style="dim", justify="center")

        file_exists = _CONFIG_FILE.exists()
        source = str(_CONFIG_FILE) if file_exists else "[dim]defaults[/dim]"

        for k, v in app_config._data.items():
            table.add_row(k, str(v), "file" if file_exists else "default")

        ui.console.print()
        ui.console.print(f"[dim]Config file: {_CONFIG_FILE}[/dim]")
        ui.console.print(table)
        ui.console.print(f"[dim]Edit {_CONFIG_FILE} and restart to apply changes.[/dim]")
        ui.console.print()

    def _show_help(self):
        ui.print_help()

    def _load_plugin(self, parts: list):
        if len(parts) < 2:
            ui.print_info("Usage: /plugin <name>")
            return
        plugin_name = parts[1]
        available = discover_hfi_plugins()
        if plugin_name not in available:
            ui.print_error(f"Plugin '{plugin_name}' not found. Use /plugins to list.")
            return
        try:
            client = create_mcp_client(plugin_name, available[plugin_name])
            if client.start():
                self.mcp_clients.append(client)
                new_tools = client.get_tool_definitions()
                self.tools.extend(new_tools)
                ui.print_success(f"Plugin [{plugin_name}]: {len(new_tools)} tools added")
        except Exception as e:
            ui.print_error(f"Plugin error: {e}")

    def _add_mcp(self, parts: list):
        if len(parts) >= 3:
            name, mcp_cmd = parts[1], parts[2:]
            client = StdioMCPClient(name, mcp_cmd)
            if client.start():
                self.mcp_clients.append(client)
                new_tools = client.get_tool_definitions()
                self.tools.extend(new_tools)
                ui.print_success(f"MCP [{name}]: {len(new_tools)} tools added")
        else:
            ui.print_info("Usage: /mcp <name> <command> [args...]")
            for c in self.mcp_clients:
                ui.print_info(f"Active: {c.name} ({len(c.tools)} tools)")

    def _cmd_search(self, cmd_line: str, parts: list):
        if len(parts) < 2:
            ui.print_info("Usage: /search <query> [--glob pattern]")
            return
        query = " ".join(parts[1:]).split("--glob")[0].strip()
        file_pattern = None
        if "--glob" in cmd_line:
            file_pattern = cmd_line.split("--glob")[1].strip().split()[0]
        indexer = ProjectIndexer(os.getcwd())
        results = indexer.search(query, file_pattern)
        if results:
            ui.console.print(f"[cyan]Found {len(results)} matches[/cyan]")
            show_search_results(ui.console, [
                {"file_path": r.file_path, "line_num": r.line_num,
                 "matched_text": r.matched_text}
                for r in results
            ])
        else:
            ui.print_info("No matches found")

    def _cmd_index(self, cmd_line: str):
        force = "--force" in cmd_line
        indexer = ProjectIndexer(os.getcwd())
        ui.console.print("[cyan]Indexing project...[/cyan]")
        stats = indexer.index_project(force=force)
        ui.console.print(f"[green]✓ Indexed {stats['files_indexed']} files[/green]")
        if stats["errors"]:
            ui.print_warning(f"{len(stats['errors'])} errors during indexing")

    def _ensure_team(self) -> AgentTeam:
        if not hasattr(self, "_team") or self._team is None:
            self._team = AgentTeam(api_base=API_BASE, token=self.token, model=self.model)
        else:
            self._team.set_runtime(token=self.token, model=self.model)
        return self._team

    def _show_teammate_roles(self):
        from rich.table import Table
        from rich import box
        table = Table(title="Teammate roles", box=box.ROUNDED, header_style="bold cyan",
                      border_style="dim cyan", padding=(0, 2), show_edge=True)
        table.add_column("Role", style="yellow", no_wrap=True)
        table.add_column("Use it for", style="white")
        for role, desc in ROLE_DESCRIPTIONS.items():
            table.add_row(role.value, desc)
        ui.console.print()
        ui.console.print(table)
        ui.console.print("[dim]Example:[/dim] [cyan]/teammate add debugger[/cyan]")
        ui.console.print()

    def _show_task_detail(self, task):
        from rich.console import Group
        from rich.panel import Panel
        from rich.text import Text
        body = Group(
            Text.assemble(("ID: ", "bold"), (task.id, "yellow")),
            Text.assemble(("Role: ", "bold"), (task.role, "cyan")),
            Text.assemble(("Assigned: ", "bold"), ((task.assigned_to or "unassigned"), "white")),
            Text.assemble(("Status: ", "bold"), (task.status, "green" if task.status == TaskStatus.DONE.value else "yellow")),
            Text.assemble(("Priority: ", "bold"), (str(task.priority), "magenta")),
            Text.assemble(("Created: ", "bold"), (task.created_at.strftime("%Y-%m-%d %H:%M:%S"), "dim")),
            Text.assemble(("Started: ", "bold"), (task.started_at.strftime("%Y-%m-%d %H:%M:%S") if task.started_at else "-", "dim")),
            Text.assemble(("Completed: ", "bold"), (task.completed_at.strftime("%Y-%m-%d %H:%M:%S") if task.completed_at else "-", "dim")),
            Text(""),
            Text("Description", style="bold cyan"),
            Text(task.description),
        )
        ui.console.print()
        ui.console.print(Panel(body, title=f"Task {task.id}", border_style="cyan"))
        if task.result:
            ui.console.print(Panel(task.result, title="Result", border_style="green"))
        elif task.error:
            ui.console.print(Panel(task.error, title="Error", border_style="red"))
        ui.console.print()

    def _cmd_teammate(self, cmd_line: str, parts: list):
        team = self._ensure_team()
        if len(parts) < 2:
            show_team_status(ui.console, team.get_team_status())
            ui.print_info("Use /teammate roles, /teammate add <role> [name], /teammate ask <role> <question>, or /teammate delegate <role> <task>")
            return

        subcmd = parts[1]
        if subcmd == "roles":
            self._show_teammate_roles()
        elif subcmd == "add":
            if len(parts) < 3:
                ui.print_info("Usage: /teammate add <role> [name]")
                ui.print_info("Creates one role-based AI specialist in the current session.")
                ui.print_info(f"Roles: {', '.join(r.value for r in TeammateRole)}")
                return
            try:
                role = TeammateRole(parts[2])
                name = parts[3] if len(parts) > 3 else None
                teammate = team.add_teammate(name, role)
                ui.print_success(f"Added teammate: {teammate.name} ({role.value})")
            except ValueError as e:
                ui.print_error(str(e))
        elif subcmd == "list":
            show_team_status(ui.console, team.get_team_status())
        elif subcmd == "remove":
            if len(parts) < 3:
                ui.print_info("Usage: /teammate remove <name>")
                return
            if team.remove_teammate(parts[2]):
                ui.print_success(f"Removed teammate: {parts[2]}")
            else:
                ui.print_error(f"Could not remove teammate '{parts[2]}' (not found or currently busy)")
        elif subcmd == "ask":
            if len(parts) < 4:
                ui.print_info("Usage: /teammate ask <role> <question>")
                ui.print_info("Example: /teammate ask architect how should we split auth and session logic?")
                return
            try:
                role = TeammateRole(parts[2])
            except ValueError:
                ui.print_error(f"Unknown role: {parts[2]}")
                return
            answer = team.ask_teammate(role, " ".join(parts[3:]))
            if answer is None:
                ui.print_warning(f"No teammate with role '{role.value}' yet. Add one first with /teammate add {role.value}")
                return
            ui.print_assistant_header()
            ui.render_markdown(answer)
            ui.print_response_end()
        elif subcmd == "delegate":
            if len(parts) < 4:
                ui.print_info("Usage: /teammate delegate <role> <task>")
                ui.print_info("Example: /teammate delegate debugger investigate MCP startup timeout")
                return
            try:
                role = TeammateRole(parts[2])
            except ValueError:
                ui.print_error(f"Unknown role: {parts[2]}")
                return
            description = " ".join(parts[3:])
            task = team.delegate_task(
                title=description[:80],
                description=description,
                role=role,
                run_async=True,
            )
            if task.assigned_to:
                ui.print_success(f"Delegated task {task.id} to {task.assigned_to}")
                ui.print_info("Check progress with /tasks active, /tasks all, or /task <id>")
            else:
                ui.print_warning(f"No teammate available for role '{role.value}' yet — task queued as pending ({task.id})")
        else:
            ui.print_warning("Unknown teammate subcommand. Try: roles, add, list, remove, ask, delegate")

    def _cmd_tasks(self, parts: list):
        team = self._ensure_team()
        status = parts[1].lower() if len(parts) > 1 else "active"
        valid = {"active", "all", "pending", "assigned", "in_progress", "done", "failed", "blocked", "cancelled"}
        if status not in valid:
            ui.print_info("Usage: /tasks [active|all|pending|assigned|in_progress|done|failed|blocked|cancelled]")
            return
        tasks = team.list_tasks(status)
        if tasks:
            show_task_monitor(ui.console, [
                {
                    "id": t.id,
                    "title": t.title,
                    "assigned_to": t.assigned_to or "unassigned",
                    "status": t.status,
                    "priority": t.priority,
                    "role": t.role,
                }
                for t in tasks
            ])
            ui.print_info("Use /task <id> for full detail or /task result <id> for just the output")
        else:
            ui.print_info(f"No {status} tasks")

    def _cmd_task(self, parts: list):
        team = self._ensure_team()
        if len(parts) < 2:
            ui.print_info("Usage: /task <id> | /task result <id>")
            return
        if parts[1] == "result":
            if len(parts) < 3:
                ui.print_info("Usage: /task result <id>")
                return
            task = team.get_task(parts[2])
            if not task:
                ui.print_error(f"Task '{parts[2]}' not found")
                return
            if task.result:
                ui.console.print()
                ui.console.print(f"[bold cyan]Result for {task.id}[/bold cyan]")
                ui.render_markdown(task.result)
                ui.console.print()
            elif task.error:
                ui.print_error(task.error)
            else:
                ui.print_info(f"Task {task.id} has no result yet (status: {task.status})")
            return

        task = team.get_task(parts[1])
        if not task:
            ui.print_error(f"Task '{parts[1]}' not found")
            return
        self._show_task_detail(task)

    # ── Phase 2 command implementations ───────────────────────────────

    def _cmd_save(self, parts: list):
        """Save conversation to file or named session."""
        if not self._ctx.messages:
            ui.print_info("Nothing to save yet")
            return
        # /save             → export to markdown on Desktop
        # /save session     → save as named session
        # /save json        → export as JSON
        fmt = parts[1].lower() if len(parts) > 1 else "md"
        if fmt == "session":
            session = self._history.save(
                self._ctx.messages, self.model,
                session_id=self._current_session_id,
            )
            self._current_session_id = session.id
            ui.print_success(f"Session saved: {session.id}  ({session.message_count} messages)")
        elif fmt == "json":
            path = self._exporter.to_json(self._ctx.messages, model=self.model)
            ui.print_success(f"Exported JSON: {path}")
        else:
            path = self._exporter.to_markdown(self._ctx.messages, model=self.model)
            ui.print_success(f"Exported Markdown: {path}")
        # Always keep a quick checkpoint too
        self._checkpoint.save(self._ctx.messages, self.model, self.system)

    def _cmd_resume(self, parts: list):
        """Resume a saved session by ID."""
        if len(parts) < 2:
            # No ID — resume from checkpoint
            data = self._checkpoint.load()
            if not data:
                ui.print_info("No checkpoint found. Use /save first or provide a session ID.")
                return
            self._ctx.messages = data["messages"]
            self.model = data.get("model", self.model)
            ui.print_success(
                f"Resumed checkpoint: {data['message_count']} messages  "
                f"(saved {data['saved_at'][:16]})"
            )
        else:
            session = self._history.load(parts[1])
            if not session:
                ui.print_error(f"Session '{parts[1]}' not found. Use /sessions to list.")
                return
            self._ctx.messages = session.messages
            self._current_session_id = session.id
            self.model = session.model
            ui.print_success(
                f"Resumed session: {session.id}  "
                f"'{session.preview}'  ({session.message_count} messages)"
            )

    def _cmd_sessions(self):
        """List saved sessions."""
        sessions = self._history.list()
        if not sessions:
            ui.print_info("No saved sessions. Use /save session to save one.")
            return
        from rich.table import Table
        from rich import box
        table = Table(box=box.ROUNDED, header_style="bold cyan",
                      border_style="dim cyan", padding=(0, 2), show_edge=True)
        table.add_column("ID", style="yellow", min_width=18, no_wrap=True)
        table.add_column("Preview", style="white", width=40)
        table.add_column("Msgs", style="cyan", justify="right")
        table.add_column("Saved", style="dim")
        for s in sessions:
            table.add_row(s.id, s.preview, str(s.message_count), s.updated_at[:16])
        ui.console.print()
        ui.console.print(table)
        ui.console.print(f"\n[dim]Resume with: /resume <id>[/dim]\n")

    def _cmd_memory(self, cmd_line: str, parts: list):
        """Manage long-term memory."""
        if len(parts) < 2:
            # Show all memories
            entries = self._memory.all()
            if not entries:
                ui.print_info("No memories yet. Use /memory set <key> <value>")
                return
            from rich.table import Table
            from rich import box
            table = Table(box=box.ROUNDED, header_style="bold cyan",
                          border_style="dim cyan", padding=(0, 2), show_edge=True)
            table.add_column("Key", style="yellow", min_width=16)
            table.add_column("Value", style="white")
            table.add_column("Category", style="dim", justify="center")
            for e in entries:
                table.add_row(e.key, e.value[:60], e.category)
            ui.console.print()
            ui.console.print(table)
            ui.console.print()
            return

        subcmd = parts[1]
        if subcmd == "set" and len(parts) >= 4:
            key, value = parts[2], " ".join(parts[3:])
            self._memory.remember(key, value)
            ui.print_success(f"Remembered: {key} = {value}")
        elif subcmd == "get" and len(parts) >= 3:
            val = self._memory.recall(parts[2])
            if val:
                ui.console.print(f"  [yellow]{parts[2]}[/yellow]: {val}")
            else:
                ui.print_info(f"No memory for '{parts[2]}'")
        elif subcmd == "forget" and len(parts) >= 3:
            if self._memory.forget(parts[2]):
                ui.print_success(f"Forgotten: {parts[2]}")
            else:
                ui.print_info(f"Key '{parts[2]}' not found")
        elif subcmd == "clear":
            self._memory.clear()
            ui.print_success("All memories cleared")
        elif subcmd == "search" and len(parts) >= 3:
            results = self._memory.search(" ".join(parts[2:]))
            for e in results:
                ui.console.print(f"  [yellow]{e.key}[/yellow]: {e.value}")
        else:
            ui.print_info("Usage: /memory [set <key> <val> | get <key> | forget <key> | search <q> | clear]")

    def _cmd_plan(self, cmd_line: str, parts: list):
        """Task planning commands."""
        if len(parts) < 2 or parts[1] == "show":
            if self._planner.current_plan:
                ui.console.print(self._planner.current_plan.summary())
            else:
                ui.print_info("No active plan. Use /plan new <goal>")
            return

        subcmd = parts[1]
        if subcmd == "new" and len(parts) >= 3:
            goal = " ".join(parts[2:])
            plan = self._planner.new_plan(goal)
            ui.print_success(f"New plan: {goal}")
        elif subcmd == "next":
            step = self._planner.advance()
            if step:
                ui.console.print(f"[cyan]▶ Step {step.index + 1}:[/cyan] {step.title}")
                ui.console.print(f"  {step.description}")
            else:
                ui.print_info("Plan complete or no active plan")
        elif subcmd == "done":
            self._planner.complete_step()
            if self._planner.current_plan:
                ui.console.print(self._planner.current_plan.summary())
        elif subcmd == "reset":
            self._planner.reset()
            ui.print_success("Plan reset")
        else:
            ui.print_info("Usage: /plan [new <goal> | next | done | show | reset]")

    def _cmd_think(self, parts: list):
        """Toggle or set extended thinking budget."""
        if len(parts) >= 2:
            arg = parts[1].lower()
            if arg in ("off", "0", "disable"):
                self.thinking_budget = 0
                ui.print_success("Extended thinking disabled")
                return
            try:
                budget = int(arg)
                if budget < 1000:
                    ui.print_warning("Budget must be >= 1000 tokens. Setting to 1000.")
                    budget = 1000
                self.thinking_budget = budget
                ui.print_thinking_status(budget)
                return
            except ValueError:
                pass
        # Toggle: if off → enable with default, if on → show status
        if self.thinking_budget == 0:
            self.thinking_budget = DEFAULT_THINKING_BUDGET
            ui.print_thinking_status(self.thinking_budget)
            ui.print_info("Extended thinking ON. Use /think off to disable.")
        else:
            ui.print_thinking_status(self.thinking_budget)
            ui.print_info(f"Use '/think off' to disable or '/think <n>' to change budget.")

    def _cmd_autoplan(self, cmd_line: str):
        """Ask Claude to decompose a goal into a plan and display it."""
        goal = cmd_line.split(None, 1)[1].strip() if len(cmd_line.split(None, 1)) > 1 else ""
        if not goal:
            ui.print_info("Usage: /autoplan <goal description>")
            return

        ui.print_info(f"🗺️  Planning: {goal}")
        plan_prompt = (
            f"Break down this goal into 5-10 clear, ordered steps that I can execute one by one.\n"
            f"Format each step as: N. Title — Brief description of what to do.\n\n"
            f"Goal: {goal}"
        )
        # Use a lightweight streamer (no tools, no thinking for planning itself)
        from .core.streaming import StreamingClient as SC
        from .config import API_BASE
        streamer = SC(API_BASE, self.token, self.model, "", [])
        try:
            response, _ = streamer.call([{"role": "user", "content": plan_prompt}],
                                        max_tokens=1024)
            plan_text = " ".join(
                b.get("text", "") for b in response.get("content", [])
                if b.get("type") == "text"
            ).strip()
            if plan_text:
                plan = self._planner.parse_from_text(goal, plan_text)
                ui.print_plan(plan.summary())
                ui.print_success(f"Plan created with {len(plan.steps)} steps. Use /plan next to start.")
            else:
                ui.print_error("Could not generate plan")
        except Exception as e:
            ui.print_error(f"Planning failed: {e}")

    def cleanup(self):
        for client in self.mcp_clients:
            client.stop()
