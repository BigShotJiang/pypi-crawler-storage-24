# MCP plugin definitions package
