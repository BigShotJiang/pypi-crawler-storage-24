"""Streaming API logic — builds requests and parses SSE stream."""
import json
import queue
import sys
import threading
import time
import urllib.request
from typing import Dict, List, Optional, Tuple

from rich.live import Live
from rich.spinner import Spinner

# ── Typewriter renderer ────────────────────────────────────────────────────────

class _TypewriterRenderer:
    """
    Typewriter renderer: accumulates streamed text and prints it all at once
    when the API finishes. Avoids sys.stdout/Rich console conflicts.
    """
    _INDENT = "  "

    def __init__(self):
        self._chunks: List[str] = []
        self._lock = threading.Lock()
        self._api_done = threading.Event()
        self._render_done = threading.Event()

    def write(self, text: str):
        """Accumulate chunk."""
        if text:
            with self._lock:
                self._chunks.append(text)

    def flush_all(self):
        """Called when API stream is done — print everything at once via sys.stdout."""
        self._api_done.set()
        with self._lock:
            full_text = "".join(self._chunks)
        if full_text:
            # Indent each line with 2 spaces for readability
            indented = full_text.replace("\n", "\n" + self._INDENT)
            sys.stdout.write(self._INDENT + indented + "\n")
            sys.stdout.flush()
        self._render_done.set()

# Extended Thinking beta header (Anthropic API requirement)
_THINKING_BETA = "interleaved-thinking-2025-05-14"
# Default thinking budget in tokens (~medium depth)
DEFAULT_THINKING_BUDGET = 8000


def _render_structured_thinking(console, thinking_text: str, block_num: int):
    """Render a thinking block as structured numbered steps (Solution 6B)."""
    from rich.panel import Panel
    from rich.text import Text

    raw_lines = thinking_text.strip().split("\n")
    steps = []
    current_step = []

    for line in raw_lines:
        stripped = line.strip()
        if not stripped:
            if current_step:
                steps.append(" ".join(current_step))
                current_step = []
            continue
        current_step.append(stripped)
    if current_step:
        steps.append(" ".join(current_step))

    label = "🧠 Reasoning" if block_num <= 1 else f"🧠 Reasoning [{block_num}]"

    content = Text()
    for j, step_text in enumerate(steps[:12]):
        display = step_text[:200] + ("…" if len(step_text) > 200 else "")
        content.append(f"  {j + 1}. ", style="bold dim cyan")
        content.append(display, style="dim white")
        if j < len(steps) - 1 and j < 11:
            content.append("\n")

    if len(steps) > 12:
        content.append(f"\n  … ({len(steps) - 12} more steps)", style="dim")

    console.print()
    console.print(Panel(
        content,
        title=f"[bold magenta]{label}[/bold magenta]",
        border_style="dim magenta",
        padding=(0, 1),
        expand=False,
    ))


class StreamingClient:
    """Handles both blocking and streaming Anthropic API calls.

    Extended Thinking:
        Set thinking_budget > 0 to enable Claude's extended thinking mode.
        This sends the 'thinking' parameter and required beta header.
        Thinking blocks are captured and returned in response['thinking_blocks'].
    """

    def __init__(self, api_base: str, token: str, model: str,
                 system: str, tools: list,
                 thinking_budget: int = 0):
        self.api_base = api_base
        self.token = token
        self.model = model
        self.system = system
        self.tools = tools
        self.thinking_budget = thinking_budget  # 0 = disabled

    def _build_request(self, messages: list, stream: bool,
                       max_tokens: int, include_tools: bool):
        payload = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": self.system,
            "messages": messages,
            "stream": stream,
        }
        if include_tools and self.tools:
            payload["tools"] = self.tools

        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01",
        }

        # Extended Thinking: add thinking param + beta header
        if self.thinking_budget > 0:
            payload["thinking"] = {
                "type": "enabled",
                "budget_tokens": self.thinking_budget,
            }
            # Extended thinking requires higher max_tokens than budget
            payload["max_tokens"] = max(max_tokens, self.thinking_budget + 1000)
            # Disable tools when thinking (Anthropic restriction on some models)
            payload.pop("tools", None)
            headers["anthropic-beta"] = _THINKING_BETA

        return urllib.request.Request(
            f"{self.api_base}/v1/messages",
            data=json.dumps(payload).encode(),
            headers=headers,
            method="POST",
        )

    def call(self, messages: list, max_tokens: int = 8096) -> Tuple[dict, dict]:
        """Blocking API call. Returns (response_dict, rate_limits)."""
        req = self._build_request(messages, stream=False,
                                   max_tokens=max_tokens, include_tools=True)
        with urllib.request.urlopen(req, timeout=120) as resp:
            rate_limits = _extract_rate_limits(resp.headers)
            result = json.loads(resp.read())
        # Extract thinking blocks for caller
        result["thinking_blocks"] = _extract_thinking(result.get("content", []))
        return result, rate_limits

    def stream(self, messages: list, console,
               max_tokens: int = 8096,
               include_tools: bool = True) -> Tuple[dict, dict]:
        """
        Streaming API call. Shows spinner while receiving.
        Returns (response_dict, rate_limits).
        response_dict has extra keys:
          'full_text'      — concatenated text output
          'thinking_blocks' — list of thinking block texts (if thinking enabled)
        """
        req = self._build_request(messages, stream=True,
                                   max_tokens=max_tokens,
                                   include_tools=include_tools)
        full_text = ""
        thinking_texts: List[str] = []
        current_thinking = ""
        in_thinking_block = False
        had_thinking = False  # True once any thinking block was printed
        tool_uses = []
        current_tool = None
        stop_reason = None
        usage = {}
        rate_limits = {}

        import time
        from rich.text import Text as RichText

        _t0 = time.monotonic()
        thinking_enabled = self.thinking_budget > 0

        def _make_status():
            elapsed = int(time.monotonic() - _t0)
            if thinking_enabled and in_thinking_block:
                t = RichText()
                t.append("🧠 ", style="bold magenta")
                t.append("thinking deeply", style="magenta")
                t.append(f" [{elapsed}s]", style="dim yellow")
                return t
            if elapsed < 5:
                return Spinner("dots", style="dim cyan")
            t = RichText()
            t.append("⠋ ", style="dim cyan")
            t.append("thinking ", style="dim")
            t.append(f"[{elapsed}s]", style="dim yellow")
            return t

        # Show spinner while waiting for first response from API.
        # Use transient=True so spinner disappears cleanly when stopped.
        spinner_live = Live(_make_status(), console=console, refresh_per_second=8,
                            transient=True)
        spinner_live.start()
        spinner_stopped = False
        typewriter = _TypewriterRenderer()

        def _stop_spinner():
            nonlocal spinner_stopped
            if not spinner_stopped:
                spinner_live.stop()
                spinner_stopped = True

        try:
            with urllib.request.urlopen(req, timeout=180) as resp:
                rate_limits = _extract_rate_limits(resp.headers)
                for raw_line in resp:
                    if not spinner_stopped:
                        spinner_live.update(_make_status())
                    line = raw_line.decode("utf-8").rstrip()
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str == "[DONE]":
                        break
                    try:
                        event = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    etype = event.get("type", "")

                    if etype == "content_block_start":
                        block = event.get("content_block", {})
                        btype = block.get("type", "")
                        if btype == "thinking":
                            in_thinking_block = True
                            current_thinking = ""
                        elif btype == "tool_use":
                            in_thinking_block = False
                            current_tool = {
                                "id": block["id"],
                                "name": block["name"],
                                "input_str": "",
                            }
                        else:
                            in_thinking_block = False

                    elif etype == "content_block_delta":
                        delta = event.get("delta", {})
                        dtype = delta.get("type", "")
                        if dtype == "thinking_delta":
                            chunk = delta.get("thinking", "")
                            if chunk:
                                current_thinking += chunk
                        elif dtype == "text_delta":
                            chunk = delta.get("text", "")
                            if chunk:
                                full_text += chunk
                                typewriter.write(chunk)
                        elif dtype == "input_json_delta" and current_tool is not None:
                            current_tool["input_str"] += delta.get("partial_json", "")

                    elif etype == "content_block_stop":
                        if in_thinking_block and current_thinking:
                            thinking_texts.append(current_thinking)
                            _stop_spinner()
                            _render_structured_thinking(console, current_thinking, len(thinking_texts))
                            current_thinking = ""
                            in_thinking_block = False
                        if current_tool is not None:
                            tool_uses.append(current_tool)
                            current_tool = None

                    elif etype == "message_delta":
                        delta = event.get("delta", {})
                        stop_reason = delta.get("stop_reason", stop_reason)
                        usage = event.get("usage", usage)

                    elif etype == "message_stop":
                        break
        finally:
            _stop_spinner()
            # Flush all accumulated text at once via console (no sys.stdout conflict)
            typewriter.flush_all()

        content = []
        if full_text:
            content.append({"type": "text", "text": full_text})
        for tu in tool_uses:
            try:
                parsed = json.loads(tu["input_str"]) if tu["input_str"] else {}
            except json.JSONDecodeError:
                parsed = {}
            content.append({
                "type": "tool_use",
                "id": tu["id"],
                "name": tu["name"],
                "input": parsed,
            })

        response = {
            "content": content,
            "stop_reason": stop_reason or ("tool_use" if tool_uses else "end_turn"),
            "usage": usage,
            "full_text": full_text,
            "thinking_blocks": thinking_texts,
        }
        return response, rate_limits


def _extract_thinking(content: list) -> List[str]:
    """Extract thinking block texts from a non-streaming response."""
    return [
        b.get("thinking", "")
        for b in content
        if b.get("type") == "thinking" and b.get("thinking")
    ]


def _extract_rate_limits(headers) -> dict:
    return {k: headers[k] for k in headers if "ratelimit" in k.lower()}


__all__ = ["StreamingClient", "DEFAULT_THINKING_BUDGET"]
