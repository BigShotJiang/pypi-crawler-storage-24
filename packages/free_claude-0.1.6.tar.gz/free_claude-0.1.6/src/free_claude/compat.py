"""Cross-platform compatibility utilities for free-claude.

Centralizes all OS-specific logic so the rest of the codebase can stay clean.
Supports: Linux, macOS (Darwin), Windows.
"""
import os
import platform
import stat
import subprocess
from pathlib import Path
from typing import List, Optional

# ── OS detection ───────────────────────────────────────────────────────────

SYSTEM = platform.system()      # "Linux", "Darwin", "Windows"
IS_WINDOWS = SYSTEM == "Windows"
IS_MACOS = SYSTEM == "Darwin"
IS_LINUX = SYSTEM == "Linux"


# ── Config / data directories (follow OS conventions) ─────────────────────

def get_config_dir() -> Path:
    """Return the standard config directory for free-claude.

    - Linux:   ~/.config/free-claude/          (XDG)
    - macOS:   ~/Library/Application Support/free-claude/
    - Windows: %APPDATA%/free-claude/          (typically C:/Users/<user>/AppData/Roaming)

    Overridable via FREE_CLAUDE_CONFIG_DIR env var.
    """
    env_override = os.environ.get("FREE_CLAUDE_CONFIG_DIR")
    if env_override:
        return Path(env_override)

    if IS_WINDOWS:
        base = os.environ.get("APPDATA")
        if base:
            return Path(base) / "free-claude"
        # Fallback for edge cases where APPDATA is not set
        return Path.home() / "AppData" / "Roaming" / "free-claude"

    if IS_MACOS:
        return Path.home() / "Library" / "Application Support" / "free-claude"

    # Linux / other POSIX — follow XDG
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "free-claude"
    return Path.home() / ".config" / "free-claude"


def get_data_dir() -> Path:
    """Return the standard data directory for free-claude.

    Used for: sessions, memory, search index, logs.

    - Linux:   ~/.local/share/free-claude/     (XDG)
    - macOS:   ~/Library/Application Support/free-claude/   (same as config)
    - Windows: %LOCALAPPDATA%/free-claude/

    Overridable via FREE_CLAUDE_DATA_DIR env var.
    """
    env_override = os.environ.get("FREE_CLAUDE_DATA_DIR")
    if env_override:
        return Path(env_override)

    if IS_WINDOWS:
        base = os.environ.get("LOCALAPPDATA")
        if base:
            return Path(base) / "free-claude"
        return Path.home() / "AppData" / "Local" / "free-claude"

    if IS_MACOS:
        return Path.home() / "Library" / "Application Support" / "free-claude"

    # Linux — XDG data home
    xdg = os.environ.get("XDG_DATA_HOME")
    if xdg:
        return Path(xdg) / "free-claude"
    return Path.home() / ".local" / "share" / "free-claude"


def get_token_dir() -> Path:
    """Directory for storing auth tokens (sensitive data).

    Same as config dir on all platforms — tokens sit beside config.
    """
    return get_config_dir()


# ── Pre-computed paths (commonly used) ─────────────────────────────────────

CONFIG_DIR = get_config_dir()
DATA_DIR = get_data_dir()


# ── File security ──────────────────────────────────────────────────────────

def secure_file(path: str) -> None:
    """Make a file readable only by the owner (best-effort on all platforms).

    - Unix:    chmod 600
    - Windows: Uses icacls to restrict access (best-effort, no crash on failure)
    """
    try:
        if IS_WINDOWS:
            # Windows: use icacls to remove inherited permissions and grant only current user
            username = os.environ.get("USERNAME", "")
            if username:
                subprocess.run(
                    ["icacls", str(path), "/inheritance:r",
                     "/grant:r", f"{username}:(R,W)"],
                    capture_output=True, timeout=5, check=False,
                )
        else:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    except Exception:
        pass  # Best-effort — don't crash over permission hardening


# ── Shell execution ────────────────────────────────────────────────────────

def get_shell_command(command: str) -> str:
    """Wrap a command string for shell execution on the current platform.

    On Windows, this is passed to cmd.exe via `shell=True` in subprocess.
    On Unix, `shell=True` uses /bin/sh.

    For most uses, just pass `shell=True` to subprocess.run() — it auto-selects.
    This function is for cases where you need explicit shell wrapping.
    """
    return command  # subprocess handles shell selection via shell=True


def run_shell(command: str, timeout: int = 30, cwd: str = None) -> str:
    """Execute a shell command cross-platform. Returns stdout + stderr.

    - Unix:    Uses default shell (/bin/sh or $SHELL)
    - Windows: Uses cmd.exe (via shell=True)
    """
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd or os.getcwd(),
        )
        out = result.stdout or ""
        if result.stderr:
            out += f"\n[stderr]: {result.stderr}"
        if result.returncode != 0:
            out += f"\n[exit code: {result.returncode}]"
        return out.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return f"[ERROR] Command timed out after {timeout}s"
    except Exception as e:
        return f"[ERROR] {e}"


# ── Directory listing (pure Python, no external commands) ──────────────────

def list_directory_recursive(path: str, max_entries: int = 500) -> str:
    """List directory contents recursively using pure Python (no `find` command).

    Skips hidden files/dirs (those starting with '.').
    Works identically on Linux, macOS, and Windows.
    """
    entries = []
    root_path = Path(path)
    try:
        for item in sorted(root_path.rglob("*")):
            # Skip hidden files/directories
            if any(part.startswith(".") for part in item.relative_to(root_path).parts):
                continue
            entries.append(str(item))
            if len(entries) >= max_entries:
                entries.append(f"... (truncated at {max_entries} entries)")
                break
    except PermissionError:
        entries.append(f"[Permission denied: {path}]")
    except Exception as e:
        entries.append(f"[ERROR] {e}")
    return "\n".join(entries) if entries else "(empty)"


# ── External tool detection ────────────────────────────────────────────────

def get_install_hint(tool_name: str) -> str:
    """Return OS-appropriate install instructions for common external tools."""
    hints = {
        "tesseract": {
            "Linux": "sudo apt install tesseract-ocr",
            "Darwin": "brew install tesseract",
            "Windows": "choco install tesseract OR download from https://github.com/UB-Mannheim/tesseract/wiki",
        },
        "pdftotext": {
            "Linux": "sudo apt install poppler-utils",
            "Darwin": "brew install poppler",
            "Windows": "choco install poppler OR download from https://github.com/oschwartz10612/poppler-windows/releases",
        },
        "ripgrep": {
            "Linux": "sudo apt install ripgrep",
            "Darwin": "brew install ripgrep",
            "Windows": "choco install ripgrep OR scoop install ripgrep",
        },
        "git": {
            "Linux": "sudo apt install git",
            "Darwin": "xcode-select --install  (or: brew install git)",
            "Windows": "Download from https://git-scm.com/download/win",
        },
    }
    tool_hints = hints.get(tool_name, {})
    return tool_hints.get(SYSTEM, f"Install {tool_name} for your platform")


# ── readline fallback ──────────────────────────────────────────────────────

def setup_readline() -> None:
    """Enable readline (arrow keys, history) for input() — cross-platform.

    - Linux/macOS: Uses built-in readline module
    - Windows: Tries pyreadline3, then falls back silently
    """
    try:
        if IS_WINDOWS:
            # pyreadline3 provides readline-compatible interface on Windows
            try:
                import pyreadline3  # noqa: F401
            except ImportError:
                # No readline support — input() still works, just no arrow keys
                return
        import readline
        readline.parse_and_bind("set editing-mode emacs")
        try:
            readline.set_auto_history(True)
        except AttributeError:
            pass  # Some readline implementations don't have set_auto_history
    except ImportError:
        pass  # Silently degrade — input() still works


# ── MCP / subprocess helpers ───────────────────────────────────────────────

def resolve_command(command: str) -> str:
    """Resolve a command name for the current platform.

    On Windows, some commands need '.cmd' or '.exe' suffix.
    E.g., 'npx' → 'npx.cmd' on Windows.
    """
    if not IS_WINDOWS:
        return command

    import shutil
    # If the command already has an extension or is found as-is, use it
    if shutil.which(command):
        return command

    # Try common Windows extensions
    for ext in (".cmd", ".exe", ".bat", ".ps1"):
        full = command + ext
        if shutil.which(full):
            return full

    return command  # Return as-is; let it fail naturally with a clear error


def get_default_export_dir() -> Path:
    """Get the default directory for exporting files.

    Uses ~/Desktop if it exists, otherwise ~/Documents, otherwise home.
    """
    home = Path.home()
    for candidate in [home / "Desktop", home / "Documents"]:
        if candidate.is_dir():
            return candidate
    return home


__all__ = [
    "SYSTEM", "IS_WINDOWS", "IS_MACOS", "IS_LINUX",
    "CONFIG_DIR", "DATA_DIR",
    "get_config_dir", "get_data_dir", "get_token_dir",
    "secure_file", "run_shell", "list_directory_recursive",
    "get_install_hint", "setup_readline", "resolve_command",
    "get_default_export_dir",
]
