"""Built-in tools for free-claude agent."""
import os
import re
import subprocess
import urllib.request
from pathlib import Path

from .compat import (
    IS_WINDOWS, run_shell, list_directory_recursive, get_install_hint,
)

BUILTIN_TOOLS = [
    {
        "name": "bash",
        "description": "Execute a bash shell command. Use for running scripts, system commands, git, etc.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The bash command to execute"},
                "timeout": {"type": "integer", "description": "Timeout in seconds (default: 30)"},
            },
            "required": ["command"],
        },
    },
    {
        "name": "read_file",
        "description": "Read the contents of a file.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to read"},
                "start_line": {"type": "integer", "description": "Start line (1-indexed)"},
                "end_line": {"type": "integer", "description": "End line (1-indexed)"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "description": "Write or create a file.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to write"},
                "content": {"type": "string", "description": "Content to write"},
                "append": {"type": "boolean", "description": "Append instead of overwrite"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "list_dir",
        "description": "List directory contents with file sizes.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory path (default: .)"},
                "recursive": {"type": "boolean", "description": "List recursively"},
            },
            "required": [],
        },
    },
    {
        "name": "web_fetch",
        "description": "Fetch content from a URL (HTML, JSON, text).",
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL to fetch"},
                "max_chars": {"type": "integer", "description": "Max chars to return (default: 5000)"},
            },
            "required": ["url"],
        },
    },
    {
        "name": "python_eval",
        "description": "Execute Python code and return output. Good for calculations and data processing.",
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute"},
            },
            "required": ["code"],
        },
    },
    {
        "name": "read_document",
        "description": (
            "Read and extract text/data from various file types: "
            "PDF (.pdf), Excel (.xlsx/.xls), Word (.docx), CSV (.csv), "
            "Image (.png/.jpg/.jpeg/.gif/.webp — OCR via tesseract if available, "
            "otherwise sent directly to Claude Vision API for analysis), "
            "and plain text files. Returns extracted text content or image analysis."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to read"},
                "sheet": {"type": "string", "description": "Excel sheet name (optional, default: first sheet)"},
                "max_rows": {"type": "integer", "description": "Max rows for Excel/CSV (default: 200)"},
                "pages": {"type": "string", "description": "PDF pages to extract, e.g. '1-3' or 'all' (default: all)"},
            },
            "required": ["path"],
        },
    },
]


def run_bash(command: str, timeout: int = 30) -> str:
    """Execute a shell command cross-platform.

    Uses the OS default shell:
    - Linux/macOS: /bin/sh (via shell=True)
    - Windows: cmd.exe (via shell=True)
    """
    return run_shell(command, timeout=timeout, cwd=os.getcwd())


def run_read_file(path: str, start_line: int = None, end_line: int = None) -> str:
    try:
        path = os.path.expanduser(path)
        with open(path, errors="replace") as f:
            lines = f.readlines()
        if start_line or end_line:
            s = (start_line - 1) if start_line else 0
            e = end_line if end_line else len(lines)
            lines = lines[s:e]
        content = "".join(lines)
        if len(content) > 20000:
            content = content[:20000] + f"\n...[truncated, {len(lines)} lines total]"
        return content
    except FileNotFoundError:
        return f"[ERROR] File not found: {path}"
    except Exception as e:
        return f"[ERROR] {e}"


def run_write_file(path: str, content: str, append: bool = False) -> str:
    try:
        path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        mode = "a" if append else "w"
        with open(path, mode) as f:
            f.write(content)
        action = "Appended to" if append else "Written"
        return f"✅ {action} {path} ({len(content)} chars)"
    except Exception as e:
        return f"[ERROR] {e}"


def run_list_dir(path: str = ".", recursive: bool = False) -> str:
    """List directory contents. Uses pure Python (cross-platform, no `find` dependency)."""
    try:
        path = os.path.expanduser(path)
        if recursive:
            # Pure Python recursive listing — works on Linux, macOS, and Windows
            return list_directory_recursive(path)[:5000]
        entries = []
        for item in sorted(Path(path).iterdir()):
            try:
                stat_info = item.stat()
                kind = "📁" if item.is_dir() else "📄"
                entries.append(f"{kind} {item.name:<40} {stat_info.st_size:>10} bytes")
            except Exception:
                entries.append(f"  {item.name}")
        return "\n".join(entries) if entries else "(empty directory)"
    except Exception as e:
        return f"[ERROR] {e}"


def run_web_fetch(url: str, max_chars: int = 5000) -> str:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            content_type = resp.headers.get("Content-Type", "")
            raw = resp.read().decode("utf-8", errors="replace")
        if "html" in content_type:
            raw = re.sub(r"<script[^>]*>.*?</script>", "", raw, flags=re.DOTALL)
            raw = re.sub(r"<style[^>]*>.*?</style>", "", raw, flags=re.DOTALL)
            raw = re.sub(r"<[^>]+>", " ", raw)
            raw = re.sub(r"\s+", " ", raw).strip()
        return raw[:max_chars] + ("..." if len(raw) > max_chars else "")
    except Exception as e:
        return f"[ERROR] {e}"


def run_python_eval(code: str) -> str:
    """Execute Python code safely in a subprocess sandbox."""
    import sys
    import tempfile
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8"
        ) as f:
            # Wrap code: try to print last expression if no explicit print
            wrapped = (
                "import sys, io\n"
                "_buf = io.StringIO()\n"
                "_old_stdout = sys.stdout\n"
                "sys.stdout = _buf\n"
                "try:\n"
                + "\n".join(f"    {line}" for line in code.splitlines())
                + "\nexcept Exception as _e:\n"
                "    sys.stdout = _old_stdout\n"
                "    print(f'[ERROR] {_e}')\n"
                "else:\n"
                "    sys.stdout = _old_stdout\n"
                "    _out = _buf.getvalue()\n"
                "    print(_out, end='')\n"
            )
            f.write(wrapped)
            tmp_path = f.name

        result = subprocess.run(
            [sys.executable, tmp_path],
            capture_output=True,
            text=True,
            timeout=15,
            cwd=os.getcwd(),
        )
        output = result.stdout or ""
        if result.stderr:
            output += f"\n[stderr]: {result.stderr}"
        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return "[ERROR] Python code timed out after 15s"
    except Exception as e:
        return f"[ERROR] {e}"
    finally:
        try:
            import os as _os
            _os.unlink(tmp_path)
        except Exception:
            pass


def run_read_document(path: str, sheet: str = None,
                      max_rows: int = 200, pages: str = "all") -> str:
    """Extract text/data from PDF, Excel, Word, CSV, Image files."""
    path = os.path.expanduser(path)
    if not os.path.exists(path):
        return f"[ERROR] File not found: {path}"

    ext = Path(path).suffix.lower()

    # ── CSV ───────────────────────────────────────────────────────────
    if ext == ".csv":
        try:
            import csv
            rows = []
            with open(path, newline="", encoding="utf-8", errors="replace") as f:
                reader = csv.reader(f)
                for i, row in enumerate(reader):
                    if i >= max_rows:
                        rows.append(f"... (truncated at {max_rows} rows)")
                        break
                    rows.append(", ".join(row))
            return "\n".join(rows) or "(empty CSV)"
        except Exception as e:
            return f"[ERROR] CSV read failed: {e}"

    # ── Excel ─────────────────────────────────────────────────────────
    if ext in (".xlsx", ".xls", ".xlsm"):
        try:
            import openpyxl
            wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
            ws = wb[sheet] if sheet and sheet in wb.sheetnames else wb.active
            lines = [f"Sheet: {ws.title}"]
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i >= max_rows:
                    lines.append(f"... (truncated at {max_rows} rows)")
                    break
                lines.append("\t".join("" if v is None else str(v) for v in row))
            wb.close()
            return "\n".join(lines)
        except ImportError:
            return "[ERROR] openpyxl not installed. Run: pip install openpyxl"
        except Exception as e:
            return f"[ERROR] Excel read failed: {e}"

    # ── Word (.docx) ──────────────────────────────────────────────────
    if ext == ".docx":
        try:
            import zipfile, xml.etree.ElementTree as ET
            ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
            with zipfile.ZipFile(path) as z:
                xml_content = z.read("word/document.xml")
            root = ET.fromstring(xml_content)
            paragraphs = []
            for para in root.iter(f"{ns}p"):
                text = "".join(t.text or "" for t in para.iter(f"{ns}t"))
                if text.strip():
                    paragraphs.append(text)
            return "\n".join(paragraphs) or "(empty document)"
        except Exception as e:
            return f"[ERROR] Word read failed: {e}"

    # ── PDF ───────────────────────────────────────────────────────────
    if ext == ".pdf":
        # Try pdfminer first (pure python, no binary needed)
        try:
            from pdfminer.high_level import extract_text
            # Parse pages arg
            page_nums = None
            if pages and pages != "all":
                try:
                    if "-" in pages:
                        a, b = pages.split("-")
                        page_nums = list(range(int(a) - 1, int(b)))
                    else:
                        page_nums = [int(pages) - 1]
                except ValueError:
                    pass
            text = extract_text(path, page_numbers=page_nums)
            return text[:20000] + ("..." if len(text) > 20000 else "") if text.strip() else "(empty PDF)"
        except ImportError:
            pass
        # Fallback: try pdftotext (poppler)
        try:
            result = subprocess.run(
                ["pdftotext", path, "-"],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0 and result.stdout.strip():
                text = result.stdout
                return text[:20000] + ("..." if len(text) > 20000 else "")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        return (
            "[ERROR] PDF extraction failed. Install one of:\n"
            f"  pip install pdfminer.six\n"
            f"  {get_install_hint('pdftotext')}"
        )

    # ── Images ────────────────────────────────────────────────────────
    if ext in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tiff"):
        # Try OCR via tesseract first (fast, no API call)
        # Only use OCR result if it looks like real text (not garbage characters).
        # Heuristic: at least 30% of chars must be ASCII printable alphanumeric.
        try:
            result = subprocess.run(
                ["tesseract", path, "stdout", "-l", "eng+vie"],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                ocr_text = result.stdout.strip()
                if ocr_text:
                    alnum = sum(c.isalnum() or c.isspace() for c in ocr_text)
                    ratio = alnum / max(len(ocr_text), 1)
                    if ratio >= 0.4:  # at least 40% readable chars → trust OCR
                        return (
                            f"[OCR text extracted from image — do NOT call read_document again]\n"
                            f"{ocr_text}"
                        )
                    # else: garbage OCR → fall through to Vision API
        except FileNotFoundError:
            pass

        # Fallback: send image to Claude Vision API via base64
        # Return a special sentinel that ToolExecutor will convert to
        # a proper image content block for the API.
        try:
            import base64 as _b64
            with open(path, "rb") as f:
                raw = f.read()
            b64_data = _b64.b64encode(raw).decode()
            size = len(raw)

            # Map extension → MIME type accepted by Anthropic Vision API
            _MIME = {
                ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                ".png": "image/png", ".gif": "image/gif",
                ".webp": "image/webp",
                # bmp/tiff not supported by Anthropic — convert hint
                ".bmp": None, ".tiff": None,
            }
            mime = _MIME.get(ext)
            if mime is None:
                return (
                    f"[ERROR] Image format '{ext}' is not supported by Claude Vision.\n"
                    f"Please convert to PNG, JPEG, GIF, or WebP first.\n"
                    f"Tip: convert {Path(path).name} output.png   (ImageMagick)"
                )

            # Size guard: Anthropic Vision max is 5 MB per image
            if size > 5 * 1024 * 1024:
                return (
                    f"[ERROR] Image too large for Claude Vision ({size/1024/1024:.1f} MB > 5 MB limit).\n"
                    f"Please resize or compress the image first."
                )

            # Return sentinel — ToolExecutor will detect this and build
            # the proper multi-content tool_result block.
            return f"__IMAGE_VISION__:{mime}:{b64_data}"

        except Exception as e:
            return f"[ERROR] Image read failed: {e}"

    # ── Fallback: plain text ──────────────────────────────────────────
    return run_read_file(path)


def execute_tool(name: str, inputs: dict) -> str:
    dispatch = {
        "bash": lambda i: run_bash(i["command"], i.get("timeout", 30)),
        "read_file": lambda i: run_read_file(i["path"], i.get("start_line"), i.get("end_line")),
        "write_file": lambda i: run_write_file(i["path"], i["content"], i.get("append", False)),
        "list_dir": lambda i: run_list_dir(i.get("path", "."), i.get("recursive", False)),
        "web_fetch": lambda i: run_web_fetch(i["url"], i.get("max_chars", 5000)),
        "python_eval": lambda i: run_python_eval(i["code"]),
        "read_document": lambda i: run_read_document(
            i["path"], i.get("sheet"), i.get("max_rows", 200), i.get("pages", "all")
        ),
    }
    fn = dispatch.get(name)
    if fn:
        return fn(inputs)
    return f"[ERROR] Unknown tool: {name}"
