import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { viteSingleFile } from "vite-plugin-singlefile";
import { devDataPlugin } from "./gui/vitePluginDevData";

export default defineConfig({
  root: "gui",
  plugins: [react(), tailwindcss(), devDataPlugin(), viteSingleFile()],
});
