# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class HostVulnItemCveList:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'link': 'str'
    }

    attribute_map = {
        'id': 'id',
        'link': 'link'
    }

    def __init__(self, id=None, link=None):
        r"""HostVulnItemCveList

        The model defined in huaweicloud sdk

        :param id: CVE漏洞ID
        :type id: str
        :param link: CVE漏洞链接
        :type link: str
        """
        
        

        self._id = None
        self._link = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if link is not None:
            self.link = link

    @property
    def id(self):
        r"""Gets the id of this HostVulnItemCveList.

        CVE漏洞ID

        :return: The id of this HostVulnItemCveList.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this HostVulnItemCveList.

        CVE漏洞ID

        :param id: The id of this HostVulnItemCveList.
        :type id: str
        """
        self._id = id

    @property
    def link(self):
        r"""Gets the link of this HostVulnItemCveList.

        CVE漏洞链接

        :return: The link of this HostVulnItemCveList.
        :rtype: str
        """
        return self._link

    @link.setter
    def link(self, link):
        r"""Sets the link of this HostVulnItemCveList.

        CVE漏洞链接

        :param link: The link of this HostVulnItemCveList.
        :type link: str
        """
        self._link = link

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, HostVulnItemCveList):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
