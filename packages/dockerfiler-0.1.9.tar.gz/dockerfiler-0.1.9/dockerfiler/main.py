import re
from dotenv import load_dotenv
from .cli import select_project, ask_params
from jinja2 import Environment, FileSystemLoader
from pathlib import Path
from .config import TEMPLATES_PATH, OUTPUT_PATH
from .data import PROJECTS

env = Environment(loader=FileSystemLoader(Path(__file__).parent / TEMPLATES_PATH))
load_dotenv()

def main():
    project = select_project()
    params = ask_params(PROJECTS[project])
    dockerfile = generate_dockerfile(project_type=project,params=params)
    output_file = Path().cwd() / OUTPUT_PATH
    output_file.write_text(dockerfile.strip())

def generate_dockerfile(project_type : str, params : dict) -> str:
    template = env.get_template(f"{project_type}.j2")
    content = template.render(**params)
    return re.sub(r'\n{3,}','\n\n', content)

if __name__ == "__main__":
    main()
