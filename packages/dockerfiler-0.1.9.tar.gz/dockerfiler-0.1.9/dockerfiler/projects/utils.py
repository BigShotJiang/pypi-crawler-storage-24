from dataclasses import field
from typing import Optional, List

def ask(
    question: str, default: str = "", type: str = "text", choices: Optional[List] = None, list_parse : bool = False
):
    return field(
        default=None,
        metadata={
            "question": question,
            "default": default,
            "type": type,
            "choices": choices,
            "list_parse" : list_parse
        },
    )
