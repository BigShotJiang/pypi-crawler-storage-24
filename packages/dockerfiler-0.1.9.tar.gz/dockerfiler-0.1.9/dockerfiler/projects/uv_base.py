from dataclasses import dataclass
from typing import Optional
from .utils import ask

python_versions = ["3.9", "3.10", "3.11", "3.12", "3.13", "3.14"]


@dataclass
class UVBaseParams:
    version: str = ask(
        question="Python version?",
        default="3.12",
        type="select",
        choices=python_versions,
    )
    port: Optional[int] = ask(question="Port?", default="", type="text")
    entrypoint: Optional[str] = ask(question="Entrypoint?", default="main.py", type="text", list_parse=True)
