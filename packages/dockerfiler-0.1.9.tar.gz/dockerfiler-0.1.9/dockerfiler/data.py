from .projects import uv_base, django_uv

PROJECTS = {
    "uv_base" : uv_base.UVBaseParams,
    "django_uv" : django_uv.DjangoUVParams
}
