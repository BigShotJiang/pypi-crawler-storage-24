#!/bin/bash
# Run PhaseNet or PhaseNet-DAS prediction on DAS data
#
# Usage:
#   # PhaseNet (base) on arcata, single GPU
#   bash scripts/predict_das.sh
#
#   # PhaseNet (base) on arcata, 8 GPUs
#   bash scripts/predict_das.sh phasenet arcata 8
#
#   # PhaseNet-DAS with checkpoint, 8 GPUs
#   bash scripts/predict_das.sh phasenet_das_plus arcata 8 output/train_das_arcata_v24/model_best.pth

set -euo pipefail

cd /global/home/groups-sw/pc_montereydas/zhuwq0/phasenet-pytorch

MODEL_TYPE=${1:-phasenet}
SUBSET=${2:-arcata}
NUM_GPUS=${3:-1}
CHECKPOINT=${4:-}

DATA_DIR=/global/scratch/users/zhuwq0/quakeflow_das_hf/data/${SUBSET}
# DATA_DIR=gs://quakeflow_das/${SUBSET}/data

CKPT_FLAG=""
if [ -n "$CHECKPOINT" ]; then
    CKPT_FLAG="--checkpoint $CHECKPOINT"
fi

echo "Model: $MODEL_TYPE, Data: $DATA_DIR, GPUs: $NUM_GPUS"

for gpu in $(seq 0 $((NUM_GPUS - 1))); do
    CUDA_VISIBLE_DEVICES=$gpu python scripts/predict_das.py \
        --data-dir "$DATA_DIR" \
        --model-type "$MODEL_TYPE" \
        --plot \
        --num-tasks "$NUM_GPUS" --task-id "$gpu" \
        $CKPT_FLAG &
done
wait

# Generate labels.txt after all tasks finish
if [ -n "$CHECKPOINT" ]; then
    MODEL_NAME=$(basename "$(dirname "$(realpath "$CHECKPOINT")")")
else
    MODEL_NAME=phasenet2018
fi
python -c "
import sys; sys.path.insert(0, '.')
from scripts.predict_das import generate_labels_txt
generate_labels_txt('results/das/$MODEL_NAME/labels', 'results/das/$MODEL_NAME')
"

echo "Done"
