#!/bin/bash
# Run PhaseNet prediction on CEED seismic data
#
# Usage:
#   # Demo (3 events with plots)
#   bash scripts/predict_ceed.sh
#
#   # Full year, single GPU
#   bash scripts/predict_ceed.sh phasenet 2025 1
#
#   # Full year, 4 GPUs
#   bash scripts/predict_ceed.sh phasenet 2025 4
#
#   # With checkpoint
#   bash scripts/predict_ceed.sh phasenet_plus 2025 4 output/train_ceed/model_best.pth

set -euo pipefail

cd /global/home/groups-sw/pc_montereydas/zhuwq0/phasenet-pytorch

MODEL_TYPE=${1:-phasenet}
YEAR=${2:-2025}
NUM_GPUS=${3:-1}
CHECKPOINT=${4:-}

CKPT_FLAG=""
if [ -n "$CHECKPOINT" ]; then
    CKPT_FLAG="--checkpoint $CHECKPOINT"
fi

echo "Model: $MODEL_TYPE, Year: $YEAR, GPUs: $NUM_GPUS"

for gpu in $(seq 0 $((NUM_GPUS - 1))); do
    CUDA_VISIBLE_DEVICES=$gpu python scripts/predict_ceed.py \
        --model-type "$MODEL_TYPE" \
        --year "$YEAR" \
        --num-tasks "$NUM_GPUS" --task-id "$gpu" \
        $CKPT_FLAG &
done
wait
echo "Done"
