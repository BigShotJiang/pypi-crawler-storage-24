#!/bin/bash
# Train PhaseNet-DAS on USGS DAS data
#
# Usage:
#   bash scripts/train_das.sh                    # arcata, GPU 0
#   bash scripts/train_das.sh 2 ridgecrest_north # ridgecrest, GPU 2
#   bash scripts/train_das.sh 0 arcata v25       # arcata v25, GPU 0

set -euo pipefail

cd /global/home/groups-sw/pc_montereydas/zhuwq0/phasenet-pytorch

GPU=${1:-0}
SUBSET=${2:-arcata}
VERSION=${3:-}

# Data and label paths
DATA_DIR=data/quakeflow_das/${SUBSET}/data
LABEL_DIR=results/das/phasenet/${SUBSET}/picks
LABEL_LIST=results/das/phasenet/${SUBSET}/labels.txt

# Output dir
if [ -n "$VERSION" ]; then
    OUTPUT_DIR=output/train_das_${SUBSET}_${VERSION}
    WANDB_NAME="das_${SUBSET}_${VERSION}"
else
    OUTPUT_DIR=output/train_das_${SUBSET}
    WANDB_NAME="das_${SUBSET}"
fi

# Auto-resume if checkpoint exists
RESUME_FLAG=""
if [ -f "$OUTPUT_DIR/checkpoint.pth" ]; then
    RESUME_FLAG="--resume"
    echo "Resuming from $OUTPUT_DIR/checkpoint.pth"
fi

echo "GPU: $GPU"
echo "Data: $DATA_DIR"
echo "Labels: $LABEL_DIR (list: $LABEL_LIST)"
echo "Output: $OUTPUT_DIR"

CUDA_VISIBLE_DEVICES=$GPU python train.py \
    --model phasenet_das_plus \
    --dataset-type das \
    --data-path "$DATA_DIR" \
    --label-path "$LABEL_DIR" \
    --label-list "$LABEL_LIST" \
    --output-dir "$OUTPUT_DIR" \
    --nx 2048 --nt 4096 \
    --batch-size 2 --num-patch 16 --workers 4 \
    --max-iters 50000 \
    --lr 1e-4 --weight-decay 0.01 \
    --model-ema --model-ema-decay 0.999 --model-ema-steps 1 \
    --eval-interval 1000 --plot-interval 100 --save-interval 1000 \
    --wandb --wandb-project phasenet-das --wandb-name "$WANDB_NAME" \
    $RESUME_FLAG
