#!/bin/bash
# Train PhaseNet on CEED seismic data
#
# Usage:
#   bash scripts/train_ceed.sh [gpu_id]

set -euo pipefail

cd /global/home/groups-sw/pc_montereydas/zhuwq0/phasenet-pytorch

GPU=${1:-0}

CUDA_VISIBLE_DEVICES=$GPU python train.py \
    --model phasenet_plus \
    --dataset-type ceed \
    --label-path results/ceed \
    --nx 16 \
    --compile \
    --wandb --wandb-project phasenet \
    --wandb-name "ceed" \
    --output-dir output/train_ceed
