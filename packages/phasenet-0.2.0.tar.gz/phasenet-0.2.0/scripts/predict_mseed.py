#!/usr/bin/env python
"""
predict_mseed.py — Run PhaseNet (UNet2018) on local mseed files.

Reads 3-component seismic waveforms from SDS archive, runs phase picking
on raw data, and measures amplitude on velocity (sensitivity-removed,
acceleration-to-velocity converted).

Input:  pipe-separated mseed file list (one station-instrument per line)
Output: CSV pick files with same directory structure as input

Usage:
    # Single-station benchmark
    python scripts/predict_mseed.py \\
        --data-list benchmark.txt \\
        --inventory stations.xml \\
        --result-dir results/benchmark

    # Full prediction with skip-existing
    python scripts/predict_mseed.py \\
        --data-list results/mseed_list/2026_3c.txt \\
        --inventory /home/jovyan/data/inventory/ \\
        --result-dir results/picks \\
        --skip-existing
"""
import argparse
import gc
import os
import sys
import time
from collections import deque
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import warnings

import numpy as np
import obspy
from obspy.io.mseed.headers import InternalMSEEDWarning
import pandas as pd
import torch

from phasenet.utils.inference import (
    detect_picks,
    load_phasenet2018_model,
    predict_2d,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
NT_WIN = 3000        # ~30 s at 100 Hz
SAMPLING_RATE = 100  # Hz
DT_S = 1.0 / SAMPLING_RATE
MIN_PROB = 0.3
WINDOW_P = 10        # amplitude window after P pick (seconds)
WINDOW_S = 5         # amplitude window after S pick (seconds)

# Component-code → array-index mappings by convention
# ENZ: standard orientation codes (E=East, N=North, Z=Vertical)
# XYZ: rotated orientation (same indices as ENZ)
# 12Z: numbered horizontals + Z vertical
# 123: fully numbered (3=vertical, reversed order)
COMP_MAP = {
    "ENZ": {"E": 0, "N": 1, "Z": 2},
    "XYZ": {"X": 0, "Y": 1, "Z": 2},
    "12Z": {"1": 0, "2": 1, "Z": 2},
    "123": {"1": 2, "2": 1, "3": 0},
}


def component_index(comp_codes):
    """Return a component→array-index dict for the given set of component codes.

    comp_codes: set of last characters from channel codes (e.g. {'E','N','Z'}).
    """
    codes = set(comp_codes)
    if codes <= {"E", "N", "Z"}:
        return COMP_MAP["ENZ"]
    if codes <= {"X", "Y", "Z"}:
        return COMP_MAP["XYZ"]
    if "Z" in codes and codes <= {"1", "2", "Z"}:
        return COMP_MAP["12Z"]
    if codes <= {"1", "2", "3"}:
        return COMP_MAP["123"]
    # Fallback: merge all known mappings
    merged = {}
    for m in COMP_MAP.values():
        merged.update(m)
    return merged


# ---------------------------------------------------------------------------
# Mseed I/O — single read for both waveform and velocity
# ---------------------------------------------------------------------------

def _resample(tr, target_rate):
    """Resample trace to target_rate using decimate (fast) or interpolate."""
    sr = tr.stats.sampling_rate
    if abs(sr - target_rate) <= 0.1:
        return
    ratio = sr / target_rate
    int_ratio = round(ratio)
    if int_ratio >= 2 and abs(ratio - int_ratio) < 0.01:
        tr.decimate(int_ratio, no_filter=True)
    else:
        tr.interpolate(target_rate, method="linear")


def read_station_data(file_paths, inv=None, sampling_rate=SAMPLING_RATE):
    """Read mseed files once, return raw waveform and velocity arrays.

    Returns (waveform, velocity, station_id, begin_iso) where:
    - waveform: (3, nt) raw counts for inference
    - velocity: (3, nt) physical velocity for amplitude, or None
    - station_id: e.g. "IV.ACER..HH"
    - begin_iso: ISO-8601 start time
    """
    stream = obspy.Stream()
    for fp in file_paths:
        try:
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=InternalMSEEDWarning)
                stream += obspy.read(fp)
        except Exception:
            # Corrupted file — skip this component, use remaining ones
            pass
    if len(stream) == 0:
        raise ValueError("all mseed files unreadable")

    # Drop non-seismic traces (e.g. LOG, SOH) before merge to avoid div-by-zero
    stream.traces = [tr for tr in stream if tr.stats.sampling_rate >= 10.0]
    if len(stream) == 0:
        raise ValueError("no seismic traces (all dropped due to low sample rate)")

    stream.merge(fill_value="latest")

    # Fork before destructive operations: copy for velocity processing
    vel_stream = stream.copy() if inv is not None else None

    # --- Raw waveform (for inference) ---
    for tr in stream:
        _resample(tr, sampling_rate)
        tr.detrend("demean")

    begin_time = min(tr.stats.starttime for tr in stream)
    end_time = max(tr.stats.endtime for tr in stream)
    stream.trim(begin_time, end_time, pad=True, fill_value=0)

    nt = max(len(tr.data) for tr in stream)
    waveform = np.zeros((3, nt), dtype=np.float32)
    comp_idx = component_index({tr.stats.channel[-1] for tr in stream})

    station_id = None
    for tr in stream:
        comp = tr.stats.channel[-1]
        idx = comp_idx.get(comp)
        if idx is None:
            continue
        waveform[idx, : len(tr.data)] = tr.data.astype(np.float32)[:nt]
        if station_id is None:
            s = tr.stats
            station_id = f"{s.network}.{s.station}.{s.location}.{s.channel[:2]}"

    begin_iso = begin_time.datetime.isoformat(timespec="milliseconds")

    # --- Velocity (for amplitude) ---
    velocity = None
    if vel_stream is not None:
        try:
            vel_stream.remove_sensitivity(inv)
            for tr in vel_stream:
                _resample(tr, sampling_rate)
                tr.detrend("demean")
                if tr.stats.channel[1] == "N":
                    tr.integrate()
                    tr.filter("highpass", freq=1.0)
            vel_stream.trim(begin_time, end_time, pad=True, fill_value=0)
            velocity = np.zeros((3, nt), dtype=np.float32)
            for tr in vel_stream:
                comp = tr.stats.channel[-1]
                idx = comp_idx.get(comp)
                if idx is not None:
                    velocity[idx, : len(tr.data)] = tr.data.astype(np.float32)[:nt]
        except Exception as e:
            raise ValueError(f"amplitude prep failed: {e}")

    return waveform, velocity, station_id, begin_iso


# ---------------------------------------------------------------------------
# Amplitude measurement
# ---------------------------------------------------------------------------

def measure_amplitudes(picks, velocity, dt_s=DT_S):
    """Add phase_amplitude to each pick dict (peak velocity in window)."""
    if velocity is None:
        return

    amp_envelope = np.max(np.abs(velocity), axis=0)  # max across 3 channels
    nt = len(amp_envelope)

    for pick in picks:
        window_s = WINDOW_P if pick["phase_type"] == "P" else WINDOW_S
        window_n = int(window_s / dt_s)
        lo = pick["phase_index"]
        hi = min(lo + window_n, nt)
        if lo < hi:
            pick["phase_amplitude"] = float(np.max(amp_envelope[lo:hi]))
        else:
            pick["phase_amplitude"] = 0.0


# ---------------------------------------------------------------------------
# Core prediction (operates on pre-loaded data)
# ---------------------------------------------------------------------------

def run_inference(model, waveform, velocity, station_id, begin_iso,
                  min_prob=MIN_PROB):
    """Run PhaseNet inference and post-processing on pre-loaded data."""
    waveform_3d = waveform[:, np.newaxis, :]  # (3, 1, nt)

    scores = predict_2d(
        model, waveform_3d,
        nx_win=1, nt_win=NT_WIN,
        min_t_overlap=0.1, device=DEVICE,
        taper_nt=True,
    )

    picks = detect_picks(
        scores,
        channel_ids=[station_id],
        event_id="",
        begin_time_iso=begin_iso,
        dt_s=DT_S,
        vmin=min_prob,
        kernel=101,
        id_key="station_id",
        device=DEVICE,
    )

    for pick in picks:
        pick["begin_time"] = begin_iso

    measure_amplitudes(picks, velocity)
    return picks


# ---------------------------------------------------------------------------
# File list helpers
# ---------------------------------------------------------------------------

def parse_mseed_list(list_path):
    """Parse pipe-separated mseed file list. Returns list of path-lists."""
    entries = []
    with open(list_path) as f:
        for line in f:
            line = line.strip()
            if line:
                entries.append(line.split("|"))
    return entries


def output_csv_path(result_dir, file_paths):
    """Derive output CSV path from the first component's SDS path.

    Input:  .../sds/2026/IV/ACER/HHE.D/IV.ACER..HHE.D.2026.001
    Output: result_dir/2026/IV/ACER/IV.ACER..HHE.D.2026.001.csv
    """
    first = file_paths[0]
    basename = os.path.basename(first)
    parts = first.split("/")
    try:
        sds_idx = parts.index("sds")
        year, net, sta = parts[sds_idx + 1], parts[sds_idx + 2], parts[sds_idx + 3]
        return os.path.join(result_dir, year, net, sta, basename + ".csv")
    except (ValueError, IndexError):
        return os.path.join(result_dir, basename + ".csv")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def build_inv_path_index(inv_path):
    """Build a dict mapping station key → StationXML file path.

    Supports two layouts:
    - Flat: inv_dir/*.xml
    - Nested: inv_dir/{network}/{network}.{station}.xml
    Returns (path_index, single_path) where single_path is set for a
    single-file inventory.
    """
    if inv_path is None:
        return {}, None
    if not os.path.isdir(inv_path):
        return {}, inv_path  # single file for all stations

    index = {}
    for root, _dirs, files in os.walk(inv_path):
        for f in files:
            if not f.endswith(".xml"):
                continue
            fpath = os.path.join(root, f)
            stem = f[:-4]
            index[stem] = fpath
            if "." in stem:
                for part in stem.split("."):
                    index.setdefault(part, fpath)
    print(f"Inventory index: {len(index)} paths")
    return index, None


def resolve_inv_path(inv_index, single_path, station_key):
    """Resolve station_key to an inventory XML file path (or None)."""
    if single_path is not None:
        return single_path
    if not inv_index:
        return None
    parts = station_key.split(".")
    net = parts[0] if len(parts) > 0 else ""
    sta = parts[1] if len(parts) > 1 else ""
    for key in [f"{net}.{sta}", sta, f"{net}_network"]:
        if key in inv_index:
            return inv_index[key]
    return None


_inv_cache = {}

def load_one(file_paths, inv_xml_path):
    """Worker function: read mseed + compute velocity. Runs in thread."""
    if inv_xml_path:
        if inv_xml_path not in _inv_cache:
            _inv_cache[inv_xml_path] = obspy.read_inventory(inv_xml_path)
        inv = _inv_cache[inv_xml_path]
    else:
        inv = None
    return read_station_data(file_paths, inv)


def write_picks(picks, out_path):
    """Write picks to CSV."""
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    if picks:
        df = pd.DataFrame(picks)
        cols = ["station_id", "begin_time", "phase_index", "phase_time",
                "phase_score", "phase_type"]
        if "phase_amplitude" in df.columns:
            df["phase_amplitude"] = df["phase_amplitude"].map(
                lambda x: f"{x:.3e}")
            cols.append("phase_amplitude")
        df[cols].to_csv(out_path, index=False)
        return len(df[df["phase_type"] == "P"]), len(df[df["phase_type"] == "S"])
    pd.DataFrame().to_csv(out_path, index=False)
    return 0, 0


def main():
    parser = argparse.ArgumentParser(description="PhaseNet mseed prediction")
    parser.add_argument("--data-list", required=True,
                        help="Pipe-separated mseed file list")
    parser.add_argument("--inventory", default=None,
                        help="StationXML file or directory for amplitude")
    parser.add_argument("--result-dir", default="results/phasenet_origin",
                        help="Output directory")
    parser.add_argument("--min-prob", type=float, default=MIN_PROB,
                        help="Minimum pick probability threshold")
    parser.add_argument("--skip-existing", action="store_true",
                        help="Skip files that already have results")
    args = parser.parse_args()

    print(f"Loading PhaseNet-2018 on {DEVICE}...")
    model = load_phasenet2018_model(device=DEVICE)

    inv_index, single_inv = build_inv_path_index(args.inventory)

    entries = parse_mseed_list(args.data_list)

    # Pre-filter: build work list with resolved inventory paths
    work = []  # (file_paths, inv_xml_path, out_path)
    n_skip = 0
    for file_paths in entries:
        out_path = output_csv_path(args.result_dir, file_paths)
        if args.skip_existing and os.path.exists(out_path):
            n_skip += 1
            continue
        bp = os.path.basename(file_paths[0]).split(".")
        station_key = f"{bp[0]}.{bp[1]}" if len(bp) >= 2 else ""
        inv_path = resolve_inv_path(inv_index, single_inv, station_key)
        work.append((file_paths, inv_path, out_path))

    print(f"Processing {len(work)} entries ({n_skip} skipped)\n")

    t0 = time.time()
    n_done = 0
    total_p, total_s = 0, 0
    cum_io, cum_gpu, cum_post = 0.0, 0.0, 0.0

    # Prefetch pool: workers read mseed + compute velocity ahead of GPU.
    # Uses ProcessPool because obspy's C library (libmseed) is not thread-safe
    # and segfaults under concurrent ThreadPool reads.
    n_workers = min(2, len(work)) or 1
    GC_INTERVAL = 50  # force garbage collection every N iterations

    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        # Use a deque of (index, future) to keep only prefetched items
        pending = deque()
        io_start = time.time()
        for j in range(min(n_workers, len(work))):
            pending.append(pool.submit(load_one, work[j][0], work[j][1]))

        for i, (file_paths, inv_path, out_path) in enumerate(work):
            future = pending.popleft()
            try:
                waveform, velocity, station_id, begin_iso = future.result()
                del future
                io_wait = time.time() - io_start
                cum_io += io_wait

                # Submit next work item (keep pool full)
                io_start = time.time()
                next_j = i + n_workers
                if next_j < len(work):
                    pending.append(pool.submit(
                        load_one, work[next_j][0], work[next_j][1],
                    ))

                # GPU inference (main process only)
                t_gpu = time.time()
                picks = run_inference(
                    model, waveform, velocity, station_id, begin_iso,
                    min_prob=args.min_prob,
                )
                cum_gpu += time.time() - t_gpu
                del waveform, velocity

                # Write output
                t_post = time.time()
                n_p, n_s = write_picks(picks, out_path)
                cum_post += time.time() - t_post
                del picks

                n_done += 1
                total_p += n_p
                total_s += n_s
                elapsed = time.time() - t0
                rate = n_done / elapsed if elapsed > 0 else 0
                print(f"[{n_done}/{len(work)}] {os.path.basename(file_paths[0])}: "
                      f"{n_p}P+{n_s}S  ({rate:.1f} f/s  "
                      f"io={cum_io/n_done:.2f} gpu={cum_gpu/n_done:.2f} "
                      f"post={cum_post/n_done:.2f})")

            except Exception as e:
                del future
                # Submit next work even on error
                io_start = time.time()
                next_j = i + n_workers
                if next_j < len(work):
                    pending.append(pool.submit(
                        load_one, work[next_j][0], work[next_j][1],
                    ))
                err_msg = str(e).split("\n")[0]  # first line only
                print(f"[{i+1}/{len(work)}] ERROR "
                      f"{os.path.basename(file_paths[0])}: {err_msg}")

            # Periodic garbage collection to prevent memory buildup
            if (i + 1) % GC_INTERVAL == 0:
                gc.collect()
                if DEVICE == "cuda":
                    torch.cuda.empty_cache()

    elapsed = time.time() - t0
    print(f"\nDone: {n_done} processed, {n_skip} skipped in {elapsed:.0f}s")
    print(f"Total: {total_p} P-picks, {total_s} S-picks")
    if n_done > 0:
        print(f"Avg per file: io_wait={cum_io/n_done:.2f}s "
              f"gpu={cum_gpu/n_done:.2f}s post={cum_post/n_done:.2f}s "
              f"(workers={n_workers})")


if __name__ == "__main__":
    main()
