#!/bin/bash
# Semi-supervised DAS training with iterative label refinement
#
# Pipeline (start_from=phasenet, default):
#   Iteration 0: phasenet predicts on DAS → labels v0
#   Iteration 1: train phasenet_das_plus from scratch (FIRST_ITERS, with warmup)
#   Iteration 2+: resume from prev model (CONT_ITERS, no warmup) → predict → vN
#
# Pipeline (start_from=phasenet_das):
#   Iteration 0: pretrained phasenet_das predicts → labels v0
#   Iteration 1+: resume from pretrained/prev (CONT_ITERS, no warmup) → predict → vN
#
# Usage:
#   bash scripts/semisupervised_das.sh [subset] [num_iterations] [gpu] [start_from] [checkpoint]
#
# Examples:
#   bash scripts/semisupervised_das.sh arcata 5 2
#   bash scripts/semisupervised_das.sh arcata 5 2 phasenet_das output/train_das_v26/model_10000.pth

set -euo pipefail

cd /global/home/groups-sw/pc_montereydas/zhuwq0/phasenet-pytorch

# --- Arguments ---
SUBSET=${1:-arcata}
NUM_ITERS=${2:-5}
GPU=${3:-0}
START_FROM=${4:-phasenet}           # "phasenet" or "phasenet_das"
PRETRAINED=${5:-}                   # checkpoint path (required for phasenet_das)

# --- Training config ---
FIRST_ITERS=10000                   # v1 from phasenet: train from scratch with warmup
CONT_ITERS=1000                     # continuation iterations: no warmup

# --- Paths ---
DATA_DIR=data/quakeflow_das/${SUBSET}/data
RUN_NAME=semisupervised_das
RESULTS_DIR=results/${RUN_NAME}
OUTPUT_BASE=output/${RUN_NAME}

# --- Events (TODO: auto-discover or pass as argument) ---
EVENT_IDS=(20221231T175220Z 20230101T164220Z 20230104T153220Z 20230105T112815Z)

# --- Validate ---
if [ "$START_FROM" = "phasenet_das" ] && [ -z "$PRETRAINED" ]; then
    echo "ERROR: --start_from=phasenet_das requires a checkpoint path as 5th argument"
    exit 1
fi

# --- Setup ---
mkdir -p "$RESULTS_DIR"
FILE_LIST=${RESULTS_DIR}/file_list.txt
printf '%s\n' "${EVENT_IDS[@]/#/${DATA_DIR}/}" | sed 's/$/.h5/' > "$FILE_LIST"

echo "============================================================"
echo "Semi-supervised DAS Training"
echo "  Subset:     $SUBSET"
echo "  Start from: $START_FROM"
echo "  Pretrained: ${PRETRAINED:-none}"
echo "  Iterations: $NUM_ITERS"
echo "  GPU:        $GPU"
echo "  First iters: ${FIRST_ITERS} (warmup), Cont iters: ${CONT_ITERS} (no warmup)"
echo "  Results:    $RESULTS_DIR"
echo "  Checkpoints: $OUTPUT_BASE"
echo "============================================================"

# --- Download from HuggingFace if needed ---
python -c "
from huggingface_hub import hf_hub_download
import os
local = 'data/quakeflow_das'
for eid in '${EVENT_IDS[*]}'.split():
    path = '${SUBSET}/data/' + eid + '.h5'
    if not os.path.exists(os.path.join(local, path)):
        hf_hub_download('AI4EPS/quakeflow_das', path, repo_type='dataset', local_dir=local)
        print(f'Downloaded {path}')
    else:
        print(f'Already cached: {path}')
"

# --- Helper: generate labels.txt from parquet files ---
generate_labels() {
    local label_dir=$1
    local output_file=$2
    python -c "
import os
label_dir = '${label_dir}'
eids = sorted(f.replace('.parquet', '') for f in os.listdir(label_dir) if f.endswith('.parquet'))
with open('${output_file}', 'w') as fout:
    fout.write('\n'.join(eids) + '\n')
print(f'  labels.txt: {len(eids)} entries -> ${output_file}')
"
}

# --- Helper: check if all picks exist ---
all_picks_exist() {
    local pick_dir=$1
    for eid in "${EVENT_IDS[@]}"; do
        [ ! -f "${pick_dir}/${eid}.parquet" ] && return 1
    done
    return 0
}

# --- Helper: label dir for iteration N ---
label_dir_for() {
    local iter=$1
    if [ "$iter" -eq 0 ]; then
        if [ "$START_FROM" = "phasenet_das" ]; then
            echo "${RESULTS_DIR}/v0/${SUBSET}"
        else
            echo "${RESULTS_DIR}/phasenet/${SUBSET}"
        fi
    else
        echo "${RESULTS_DIR}/v${iter}/${SUBSET}"
    fi
}

# ==========================================================
# Iteration 0: Initial prediction (no training)
# ==========================================================
LABEL_DIR_0=$(label_dir_for 0)

echo ""
if [ "$START_FROM" = "phasenet_das" ]; then
    echo "=== Iteration 0: Predict with pretrained DAS model ==="
    PREDICT_ARGS=(--model-type phasenet_das_plus --checkpoint "$PRETRAINED" --no-ema)
else
    echo "=== Iteration 0: Predict with PhaseNet ==="
    PREDICT_ARGS=(--model-type phasenet)
fi

if ! all_picks_exist "${LABEL_DIR_0}/picks"; then
    CUDA_VISIBLE_DEVICES=${GPU} python scripts/predict_das.py \
        --file-list "$FILE_LIST" \
        --output-dir "$LABEL_DIR_0" \
        --plot \
        "${PREDICT_ARGS[@]}"
else
    echo "  All picks exist, skipping"
fi
generate_labels "${LABEL_DIR_0}/picks" "${LABEL_DIR_0}/labels.txt"

# ==========================================================
# Iterations 1..N: Train → Predict → Label
# ==========================================================
for ITER in $(seq 1 "$NUM_ITERS"); do

    PREV_LABEL_DIR=$(label_dir_for $((ITER-1)))
    CUR_LABEL_DIR=$(label_dir_for "$ITER")
    TRAIN_DIR=${OUTPUT_BASE}_v${ITER}
    CHECKPOINT=${TRAIN_DIR}/checkpoint.pth

    # Decide training schedule and source checkpoint
    RESUME_ARGS=()
    if [ "$ITER" -eq 1 ] && [ "$START_FROM" != "phasenet_das" ]; then
        # From phasenet: train from scratch with warmup
        MAX_ITERS="$FIRST_ITERS"
        WARMUP_ITERS=1000
    else
        # Resume from pretrained (iter 1) or previous model (iter 2+)
        if [ "$ITER" -eq 1 ]; then
            RESUME_ARGS=(--resume --checkpoint "$PRETRAINED" --reset-lr)
        else
            RESUME_ARGS=(--resume --checkpoint "${OUTPUT_BASE}_v$((ITER-1))/checkpoint.pth" --reset-lr)
        fi
        MAX_ITERS="$CONT_ITERS"
        WARMUP_ITERS=0
    fi

    echo ""
    echo "=== Iteration $ITER: Train v${ITER} (${MAX_ITERS} steps, warmup=${WARMUP_ITERS}) ==="

    # --- Train ---
    if [ -f "$CHECKPOINT" ]; then
        echo "  Checkpoint exists, skipping training"
    else
        mkdir -p "$TRAIN_DIR"
        CUDA_VISIBLE_DEVICES=${GPU} python -u train.py \
            --model phasenet_das_plus \
            --dataset-type das \
            --data-path "$DATA_DIR" \
            --label-path "${PREV_LABEL_DIR}/picks" \
            --label-list "${PREV_LABEL_DIR}/labels.txt" \
            --batch-size 2 --num-patch 16 --workers 8 \
            --nx 2048 --nt 4096 \
            --lr 1e-4 --weight-decay 0.01 \
            --model-ema --model-ema-decay 0.999 \
            --max-iters "$MAX_ITERS" \
            --lr-warmup-iters "$WARMUP_ITERS" \
            --eval-interval 1000 --plot-interval 100 --save-interval 1000 \
            "${RESUME_ARGS[@]}" \
            --wandb --wandb-project phasenet_das \
            --wandb-name "${RUN_NAME}_v${ITER}" \
            --output-dir "$TRAIN_DIR" \
            2>&1 | tee "${TRAIN_DIR}/training.log"
        echo "  Training complete: $TRAIN_DIR"
    fi

    # --- Predict ---
    if ! all_picks_exist "${CUR_LABEL_DIR}/picks"; then
        echo "  Predicting..."
        CUDA_VISIBLE_DEVICES=${GPU} python scripts/predict_das.py \
            --file-list "$FILE_LIST" \
            --model-type phasenet_das_plus \
            --checkpoint "$CHECKPOINT" \
            --output-dir "$CUR_LABEL_DIR" \
            --no-ema --plot
    else
        echo "  All picks exist, skipping prediction"
    fi

    generate_labels "${CUR_LABEL_DIR}/picks" "${CUR_LABEL_DIR}/labels.txt"
done

echo ""
echo "============================================================"
echo "Semi-supervised training complete!"
echo "  Iterations: $NUM_ITERS"
echo "  Results:    $RESULTS_DIR"
echo "  Checkpoints: $OUTPUT_BASE"
echo "============================================================"
