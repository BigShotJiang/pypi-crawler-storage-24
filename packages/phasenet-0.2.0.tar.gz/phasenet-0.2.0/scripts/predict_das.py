#!/usr/bin/env python
"""
predict_das.py — Run PhaseNet or PhaseNet-DAS on DAS data,
associate picks into origins, and save results.

Supports local files, GCS paths, and HuggingFace datasets.
Supports SLURM array sharding for multi-node parallelism.

Usage:
    # Quick test (first 3 events with plots)
    python scripts/predict_das.py --data-dir /path/to/h5 --n-events 3 --plot

    # Full prediction
    python scripts/predict_das.py --data-dir /path/to/h5 --all

    # GCS data
    python scripts/predict_das.py --data-dir gs://quakeflow_das/arcata/data --n-events 3

    # PhaseNet-DAS with checkpoint
    python scripts/predict_das.py --data-dir /path/to/h5 --model-type phasenet_das_plus --checkpoint model.pth

    # Multi-GPU sharding
    python scripts/predict_das.py --data-dir /path/to/h5 --all --task-id $SLURM_ARRAY_TASK_ID --num-tasks 4
"""
import argparse
import functools
import fsspec
import logging
import os
import sys
import time
import urllib.request
from collections import deque
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timedelta
from glob import glob

sys.path.insert(0, ".")

import h5py
import numpy as np
import pandas as pd
import torch

from phasenet.data.das import Sample, Target, plot_overview
from phasenet.utils.inference import (
    predict_2d, detect_picks, build_targets_from_linked_map,
)
from phasenet.utils.postprocess import (
    estimate_origins_from_ps_pairs,
    estimate_origins_from_event_heads,
    associate_picks,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

from huggingface_hub import hf_hub_download, list_repo_files

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MIN_T_OVERLAP = 0.1
MIN_PROB = 0.3
HF_REPO_ID = "AI4EPS/quakeflow_das"
GITHUB_MODELS_REPO = "AI4EPS/models"

# Pretrained model registry: name -> config dict
# All properties needed for inference are explicit here.
PRETRAINED_MODELS = {
    "phasenet": {
        "release": "PhaseNet-2018",
        "filename": "phasenet2018.pth",
        "model": "phasenet",
        "backbone": "unet2018",
        "in_channels": 3,
        "nx": 256,
        "nt": 3000,
    },
    "phasenet-das-plus-arcata": {
        "release": "PhaseNet-DAS-Plus-Arcata-v1",
        "filename": "phasenet_das_plus_arcata_v1.pth",
        "model": "phasenet_das_plus",
        "in_channels": 1,
        "nx": 2048,
        "nt": 4096,
    },
}

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


# Association config per model type
# origin_window: max distance from median origin time to link a pick (seconds)
# moveout_window: max RANSAC residual on midpoint moveout curve (seconds)
ASSOC_CONFIG = {
    "phasenet": dict(
        mph=100, mpd=50, min_ps_dt=1.0, max_ps_dt=30.0, bin_size=0.1,
        origin_window=0.2, moveout_window=0.2,
    ),
    "phasenet-tf": dict(
        mph=100, mpd=50, min_ps_dt=1.0, max_ps_dt=30.0, bin_size=0.1,
        origin_window=0.2, moveout_window=0.2,
    ),
    "phasenet-plus": dict(
        mph=100, mpd=50, min_ps_dt=1.0, max_ps_dt=30.0, bin_size=0.1,
        origin_window=0.2, moveout_window=0.2,
    ),
    "phasenet_das": dict(
        mph=100, mpd=50, min_ps_dt=1.0, max_ps_dt=30.0, bin_size=0.1,
        origin_window=0.2, moveout_window=0.2,
    ),
    "phasenet_das_plus": dict(
        mph=100, mpd=50, min_ps_dt=1.0, max_ps_dt=30.0, bin_size=0.1,
        origin_window=0.2, moveout_window=0.2,
    ),
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _download_from_release(release: str, filename: str) -> str:
    """Download a file from a GitHub release. Returns cached local path."""
    cache_dir = os.path.join(os.path.expanduser("~"), ".cache", "phasenet", release)
    local_path = os.path.join(cache_dir, filename)
    if not os.path.exists(local_path):
        os.makedirs(cache_dir, exist_ok=True)
        url = f"https://github.com/{GITHUB_MODELS_REPO}/releases/download/{release}/{filename}"
        print(f"Downloading {url}")
        urllib.request.urlretrieve(url, local_path)
    return local_path


def load_model(model_or_path: str = "phasenet", use_ema: bool = True) -> torch.nn.Module:
    """Load a model for prediction.

    Args:
        model_or_path: Either a pretrained model name (key in PRETRAINED_MODELS)
                       or a path to a checkpoint file (.pth).
        use_ema: If True, prefer EMA weights when available.

    Sets these attributes on the returned model:
        _model_type:  str  — model name (e.g. 'phasenet', 'phasenet_das_plus')
        n_channels:   int  — input channels (1 for DAS, 3 for seismic)
        inference_nx: int  — sliding window width in station/channel dim
        inference_nt: int  — sliding window width in time dim
    """
    import phasenet.models

    # --- Pretrained model from registry ---
    if model_or_path in PRETRAINED_MODELS:
        cfg = PRETRAINED_MODELS[model_or_path]
        ckpt_path = _download_from_release(cfg["release"], cfg["filename"])
        ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)

        build_kwargs = ckpt.get("model_config", {})
        if "backbone" in cfg:
            build_kwargs["backbone"] = cfg["backbone"]
        model = phasenet.models.__dict__[cfg["model"]].build_model(**build_kwargs)

        if use_ema and "model_ema_weights" in ckpt:
            model.load_state_dict(ckpt["model_ema_weights"])
        else:
            model.load_state_dict(ckpt["model"])

        model._model_type = cfg["model"]
        model.n_channels = cfg["in_channels"]
        model.inference_nx = cfg["nx"]
        model.inference_nt = cfg["nt"]
        print(f"Loaded pretrained '{model_or_path}' from {ckpt_path}")
        model.to(DEVICE).eval()
        return model

    # --- Custom checkpoint file ---
    ckpt = torch.load(model_or_path, map_location="cpu", weights_only=False)
    ckpt_args = ckpt.get("args")
    model_name = getattr(ckpt_args, "model", "phasenet")
    build_kwargs = ckpt.get("model_config", {})
    model = phasenet.models.__dict__[model_name].build_model(**build_kwargs)

    if use_ema and "model_ema_weights" in ckpt:
        model.load_state_dict(ckpt["model_ema_weights"])
        print("Using EMA weights")
    else:
        model.load_state_dict(ckpt["model"])
        print("Using regular weights")

    model._model_type = model_name
    model.n_channels = build_kwargs.get("in_channels", 1 if "das" in model_name else 3)
    model.inference_nx = getattr(ckpt_args, "nx", 2048)
    model.inference_nt = getattr(ckpt_args, "nt", 4096)
    print(f"Loaded {model_name} from {model_or_path} "
          f"(nch={model.n_channels}, nx={model.inference_nx}, nt={model.inference_nt})")
    model.to(DEVICE).eval()
    return model


def load_das_event(h5_path: str, n_channels: int = 3):
    """Load a single local DAS H5 file and return (event_id, waveform, channel_ids, begin_time, dt_s, attrs).

    Args:
        n_channels: Number of input channels. 3 for PhaseNet (ENZ), 1 for DAS models.
    """
    event_id = os.path.splitext(os.path.basename(h5_path))[0]
    with fsspec.open(h5_path, "rb") as f:
        with h5py.File(f, "r") as fp:
            raw = fp["data"][:]  # (nx, nt)
            attrs = dict(fp["data"].attrs)
    dt_s = float(attrs.get("dt_s", 0.008))
    begin_time = str(attrs.get("begin_time", ""))
    nx, nt = raw.shape
    if n_channels == 1:
        waveform = raw.astype(np.float32)[np.newaxis, :, :]  # (1, nx, nt)
    else:
        waveform = np.zeros((3, nx, nt), dtype=np.float32)
        waveform[2] = raw.astype(np.float32)
    channel_ids = [str(i) for i in range(nx)]
    return event_id, waveform, channel_ids, begin_time, dt_s, attrs


def generate_labels_txt(labels_dir: str, output_dir: str):
    """Generate labels.txt listing event IDs that have label parquet files."""
    label_files = sorted(f for f in os.listdir(labels_dir) if f.endswith(".parquet"))
    if not label_files:
        return
    labels_path = os.path.join(output_dir, "labels.txt")
    eids = [f.replace(".parquet", "") for f in label_files]
    with open(labels_path, "w") as fout:
        fout.write("\n".join(eids) + "\n")
    print(f"  Generated {labels_path}: {len(eids)} entries")


def list_h5_files(data_dir: str, event_id_filter: "str | None" = None) -> list[str]:
    """Return sorted list of H5 file paths from a local or remote directory."""
    data_dir = data_dir.rstrip("/")
    if event_id_filter:
        return [f"{data_dir}/{event_id_filter}.h5"]
    if data_dir.startswith("gs://"):
        fs = fsspec.filesystem("gcs")
        path = data_dir.replace("gs://", "")
        return sorted(f"gs://{f}" for f in fs.ls(path, detail=False) if f.endswith(".h5"))
    return sorted(glob(os.path.join(data_dir, "*.h5")))


def list_hf_files(subset: str) -> list[str]:
    """List all .h5 repo paths for a HuggingFace subset."""
    prefix = f"{subset}/data/"
    return sorted(
        f for f in list_repo_files(HF_REPO_ID, repo_type="dataset")
        if f.startswith(prefix) and f.endswith(".h5")
    )


def download_and_load(repo_path: str, local_dir: str = "data/quakeflow_das",
                      n_channels: int = 3):
    """Download an H5 file from HuggingFace (cached) and load it.

    Checks local_dir first to skip the hf_hub_download overhead (~0.2s per
    cache-hit check). Only calls the HF API if the file is missing locally.
    """
    local_path = os.path.join(local_dir, repo_path)
    if not os.path.exists(local_path):
        local_path = hf_hub_download(
            HF_REPO_ID, repo_path, repo_type="dataset", local_dir=local_dir,
        )
    return load_das_event(local_path, n_channels=n_channels)


def process_one_file(model, event_data, output_rows=None, use_event_head=False):
    """Run inference + association on one DAS file.

    Returns (event_id, picks, targets, attrs, linked_chs, p_total, s_total) or None.
    Each pick dict is enriched with origin_id, origin_index, origin_time, dt_s.
    """
    event_id, waveform, channel_ids, begin_time, dt_s, attrs = event_data
    nx, nt = waveform.shape[1], waveform.shape[2]

    # 1. Inference
    nx_win = getattr(model, "inference_nx", 2048)
    nt_win = getattr(model, "inference_nt", 4096)
    # DAS models: taper both axes. PhaseNet (independent channels): taper nt only.
    is_das = "das" in getattr(model, "_model_type", "")
    result = predict_2d(model, waveform, nx_win, nt_win, MIN_T_OVERLAP, DEVICE,
                        taper_nx=is_das, taper_nt=True)

    # Unpack: event models return (scores, event_detections)
    event_detections = None
    if isinstance(result, tuple):
        scores, event_detections = result
    else:
        scores = result

    picks = detect_picks(scores, channel_ids, event_id, begin_time,
                         dt_s=dt_s, vmin=MIN_PROB, device=DEVICE)
    if not picks:
        return None

    # 2-7. Association
    model_type = getattr(model, "_model_type", "phasenet")
    config = ASSOC_CONFIG.get(model_type, ASSOC_CONFIG["phasenet"])

    assoc_kwargs = dict(
        nt=nt, dt_s=dt_s,
        bin_size=config.get("bin_size", 0.1),
        mph=config.get("mph", 100), mpd=config.get("mpd", 50),
        origin_window=config.get("origin_window"),
        moveout_window=config.get("moveout_window"),
    )

    if use_event_head and event_detections is not None:
        # Event-head path: use model-predicted event centers
        pairs = estimate_origins_from_event_heads(
            event_detections,
            picks, dt_s=dt_s, vp_vs=config.get("vp_vs", 1.73),
        )
    else:
        # PS-pair path: pair P and S picks per channel (default)
        pairs = estimate_origins_from_ps_pairs(
            picks, dt_s=dt_s, vp_vs=config.get("vp_vs", 1.73),
            min_ps_dt=config.get("min_ps_dt", 0.0),
            max_ps_dt=config.get("max_ps_dt", 20.0),
        )
    assoc = associate_picks(pairs, **assoc_kwargs)

    # Build targets from associated picks
    cid_to_idx = {cid: i for i, cid in enumerate(channel_ids)}
    targets, p_total, s_total = [], 0, 0
    if assoc.pick_to_event:
        targets, p_total, s_total = build_targets_from_linked_map(
            assoc.pick_to_event,
            resolve_index=lambda cid: cid_to_idx.get(cid, int(cid)),
            target_cls=Target,
            event_id_prefix=event_id,
        )

    # Enrich picks with origin info (single pass)
    try:
        t0_abs = datetime.fromisoformat(begin_time.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        t0_abs = None

    event_idx = {eid: int(round(t / dt_s)) for eid, t in enumerate(assoc.event_times)}
    event_iso = {eid: (t0_abs + timedelta(seconds=t)).isoformat(timespec="milliseconds")
                 if t0_abs else None
                 for eid, t in enumerate(assoc.event_times)}
    pair_origin = {(ch, int(pi)): int(round(t0 / dt_s))
                   for ch, pi, t0 in zip(assoc.pair_channels, assoc.pair_p_indices, assoc.pair_t0)}
    pair_info = {}
    for ch, pi, si, pc, ps in zip(assoc.pair_channels, assoc.pair_p_indices,
                                   assoc.pair_s_indices, assoc.pair_centers, assoc.pair_intervals):
        pair_info[(ch, int(pi))] = (pc, ps)
        pair_info[(ch, int(si))] = (pc, ps)

    for pk in picks:
        key = (pk["channel_index"], pk["phase_index"], pk["phase_type"])
        oid = assoc.pick_to_event.get(key, -1)
        pk["origin_id"] = int(oid)
        pk["origin_index"] = event_idx.get(oid) or pair_origin.get(
            (pk["channel_index"], int(pk["phase_index"])))
        pk["origin_time"] = event_iso.get(oid)
        pk["dt_s"] = dt_s
        info = pair_info.get((pk["channel_index"], int(pk["phase_index"])))
        pk["ps_center"] = info[0] if info else None
        pk["ps_interval"] = info[1] if info else None

    # 8. Output
    if output_rows is not None:
        output_rows.extend(picks)

    linked_chs = len({ch for ch, _, _ in assoc.pick_to_event}) if assoc.pick_to_event else 0
    return event_id, picks, targets, attrs, linked_chs, p_total, s_total


# ---------------------------------------------------------------------------
# Full prediction with prefetch pipeline and optional sharding
# ---------------------------------------------------------------------------

def predict_all(
    model: torch.nn.Module,
    file_list: list[str],
    output_dir: str = "results/das",
    task_id: int = 0,
    num_tasks: int = 1,
    load_fn=None,
    plot: bool = False,
    use_event_head: bool = False,
) -> None:
    """Run prediction on all events (or a shard) with IO prefetching.

    Args:
        file_list: List of file paths (local H5) or repo paths (HuggingFace).
        load_fn: Callable that takes a path and returns event_data tuple.
        output_dir: Root output dir. Structure:
            output_dir/picks/  — all picks (origin_id=-1 for unassociated)
            output_dir/labels/ — only associated picks (origin_id >= 0)
            output_dir/figures/ — overview plots (if plot=True)
    """
    if load_fn is None:
        load_fn = load_das_event

    # Shard: this task processes every num_tasks-th file
    shard_files = file_list[task_id::num_tasks]
    total = len(file_list)
    print(f"\n=== Predict DAS — task {task_id}/{num_tasks}, "
          f"{len(shard_files)}/{total} events ===")

    picks_dir = os.path.join(output_dir, "picks")
    labels_dir = os.path.join(output_dir, "labels")
    done_dir = os.path.join(output_dir, "done")
    figure_dir = os.path.join(output_dir, "figures")
    os.makedirs(picks_dir, exist_ok=True)
    os.makedirs(labels_dir, exist_ok=True)
    os.makedirs(done_dir, exist_ok=True)
    if plot:
        os.makedirs(figure_dir, exist_ok=True)

    n_processed = 0
    n_detected = 0
    n_picks_total = 0
    t_start = time.time()

    # Prefetch pipeline: keep multiple files loading in parallel
    # IO (~7s) >> compute (~1s), so we need several workers to keep GPU fed
    prefetch_depth = max(1, min(8, len(shard_files)))
    with ProcessPoolExecutor(max_workers=prefetch_depth) as pool:
        futures = deque()
        for p in shard_files[:prefetch_depth]:
            futures.append(pool.submit(load_fn, p))

        for i, h5_path in enumerate(shard_files):
            try:
                event_data = futures.popleft().result()
            except Exception as exc:
                eid = os.path.splitext(os.path.basename(h5_path))[0]
                print(f"  [WARN] {eid}: {exc}")
                if i + prefetch_depth < len(shard_files):
                    futures.append(pool.submit(load_fn, shard_files[i + prefetch_depth]))
                continue

            # Submit next file to keep the queue full
            if i + prefetch_depth < len(shard_files):
                futures.append(pool.submit(load_fn, shard_files[i + prefetch_depth]))

            event_id = event_data[0]
            picks_out = os.path.join(picks_dir, f"{event_id}.parquet")
            done_marker = os.path.join(done_dir, f"{event_id}.done")
            if os.path.exists(done_marker):
                n_processed += 1
                if os.path.exists(picks_out):
                    n_detected += 1
                continue

            try:
                rows: list[dict] = []
                result = process_one_file(model, event_data, output_rows=rows,
                                         use_event_head=use_event_head)
                n_processed += 1

                if result is not None and len(rows) > 0:
                    n_detected += 1
                    df = pd.DataFrame(rows)
                    df.to_parquet(picks_out, index=False)
                    n_picks_total += len(rows)
                    # Save associated picks (origin_id >= 0) to labels/
                    associated = df[df["origin_id"] >= 0]
                    if len(associated) > 0:
                        associated.to_parquet(
                            os.path.join(labels_dir, f"{event_id}.parquet"),
                            index=False,
                        )

                # Mark as done (even with 0 picks)
                open(done_marker, "w").close()

                # Plot regardless of detection count
                if plot:
                    if result is not None:
                        eid, picks, targets, attrs, linked_chs, p_total, s_total = result
                    else:
                        eid, picks, targets = event_id, [], []
                    waveform = event_data[1]
                    dt_s = event_data[4]
                    das_wf = waveform if waveform.shape[0] == 1 else waveform[[2]]
                    sample = Sample(waveform=das_wf, targets=targets, dt_s=dt_s, file_name=eid)
                    begin_time = event_data[3]
                    if begin_time:
                        try:
                            sample.begin_time = datetime.fromisoformat(
                                begin_time.replace("Z", "+00:00"))
                        except Exception:
                            pass
                    plot_overview(
                        sample,
                        title=eid,
                        save_path=os.path.join(figure_dir, f"{eid}.png"),
                        all_picks=picks,
                    )
            except Exception:
                import traceback
                traceback.print_exc()

            if n_processed % 10 == 0:
                elapsed = time.time() - t_start
                rate = n_processed / elapsed if elapsed > 0 else 0
                eta = (len(shard_files) - n_processed) / rate if rate > 0 else 0
                print(f"  [{n_processed}/{len(shard_files)}] "
                      f"{rate:.1f} events/s  detected={n_detected}  "
                      f"ETA {eta/60:.0f}min")

    elapsed = time.time() - t_start
    print(f"\n  Done: {n_processed} events in {elapsed:.0f}s "
          f"({n_processed/elapsed:.1f} events/s), "
          f"{n_detected} with detections, "
          f"{n_picks_total} picks → {picks_dir}/ + {labels_dir}/")

    # Generate labels.txt listing event IDs with labels
    if num_tasks == 1:
        generate_labels_txt(labels_dir, output_dir)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="DAS prediction with PhaseNet")
    # Data source (one required)
    parser.add_argument("--data-dir", help="Local or GCS directory with H5 files")
    parser.add_argument("--file-list", help="Text file with H5 paths (one per line, or data,label format)")
    parser.add_argument("--subset", help="HuggingFace subset (e.g. arcata, ridgecrest_north)")
    parser.add_argument("--local-dir", default="data/quakeflow_das",
                        help="Local cache dir for HuggingFace downloads")
    # Model
    parser.add_argument("--model", default="phasenet",
                        help=f"Pretrained model name ({', '.join(PRETRAINED_MODELS)}) or path to .pth checkpoint")
    parser.add_argument("--no-ema", action="store_true", help="Use regular weights instead of EMA")
    parser.add_argument("--use-event-head", action="store_true",
                        help="Use event-head detections for association (default: PS-pair)")
    # Output
    parser.add_argument("--output-dir", help="Output dir (default: results/das/{model_name})")
    parser.add_argument("--plot", action="store_true", help="Generate overview plots")
    # Filtering
    parser.add_argument("--event-id", help="Process a single event (filename without .h5)")
    parser.add_argument("--n-events", type=int, help="Limit to first N events")
    # Parallelism
    parser.add_argument("--task-id", type=int, default=0, help="Shard index (0-based)")
    parser.add_argument("--num-tasks", type=int, default=1, help="Total number of shards")
    args = parser.parse_args()

    # Load model first — it carries all config (n_channels, nx, nt, model_type)
    model = load_model(args.model, use_ema=not args.no_ema)

    # Derive display name for output dir
    if args.model in PRETRAINED_MODELS:
        model_name = args.model
    elif os.path.isfile(args.model):
        model_name = os.path.basename(os.path.dirname(os.path.abspath(args.model)))
    else:
        model_name = args.model

    # Auto-derive output dir
    if args.output_dir is None:
        args.output_dir = os.path.join("results/das", model_name)

    # Data loader uses model's n_channels
    n_channels = model.n_channels
    load_fn = functools.partial(load_das_event, n_channels=n_channels)
    if args.file_list:
        with open(args.file_list) as f:
            file_list = [line.strip().split(",")[0] for line in f if line.strip()]
    elif args.subset:
        print(f"Listing HuggingFace files for subset: {args.subset}")
        file_list = list_hf_files(args.subset)
        load_fn = functools.partial(download_and_load,
                                    local_dir=args.local_dir, n_channels=n_channels)
    elif args.data_dir:
        file_list = list_h5_files(args.data_dir, args.event_id)
    else:
        parser.error("Provide --data-dir, --subset, or --file-list")

    if args.n_events:
        file_list = file_list[:args.n_events]

    print("=" * 60)
    print(f"DAS Prediction ({len(file_list)} events)")
    print(f"  source={args.subset or args.data_dir or args.file_list}")
    print(f"  model={model_name}")
    print(f"  output={args.output_dir}")
    print("=" * 60)

    print(f"Model loaded on {DEVICE}")

    predict_all(model, file_list, args.output_dir,
                task_id=args.task_id, num_tasks=args.num_tasks,
                load_fn=load_fn, plot=args.plot,
                use_event_head=args.use_event_head)

    print("\n" + "=" * 60)
    print("Done!")
    print("=" * 60)


if __name__ == "__main__":
    main()
