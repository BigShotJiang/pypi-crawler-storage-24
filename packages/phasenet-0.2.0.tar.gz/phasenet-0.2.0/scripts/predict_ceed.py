#!/usr/bin/env python
"""
predict_ceed.py — Run PhaseNet on QuakeFlow seismic data from GCS,
associate picks into origins, and save picks/labels.

Supports local checkpoints or pretrained PhaseNet-2018.
Supports SLURM array sharding for multi-node parallelism.

Usage:
    # Demo mode (top 3 events with plots)
    python scripts/predict_ceed.py --n-events 3

    # Full prediction (all days, both regions)
    python scripts/predict_ceed.py --year 2025

    # Single region
    python scripts/predict_ceed.py --year 2025 --regions NC

    # With custom checkpoint
    python scripts/predict_ceed.py --year 2025 --model-type phasenet_plus \
        --checkpoint output/train_ceed/model_best.pth

    # Multi-GPU sharding
    python scripts/predict_ceed.py --year 2025 --task-id $SLURM_ARRAY_TASK_ID --num-tasks 4
"""
import argparse
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

sys.path.insert(0, ".")

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import gcsfs
import torch

from phasenet.data.ceed import (
    records_to_sample, plot_overview, Target,
)
from phasenet.utils.inference import (
    predict_2d, detect_picks, load_phasenet2018_model, build_targets_from_linked_map,
)
from phasenet.utils.postprocess import (
    estimate_origin_times,
    estimate_origins_from_ps_pairs,
    estimate_origins_from_event_heads,
    associate_picks,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
NX_WIN = 16
NT_WIN = 3000
MIN_T_OVERLAP = 0.1
SAMPLING_RATE = 100  # Hz
MIN_PROB = 0.3
GCS_CRED_PATH = os.path.expanduser("~/.config/gcloud/application_default_credentials.json")

BUCKETS = {
    "NC": "quakeflow_dataset/NCEDC",
    "SC": "quakeflow_dataset/SCEDC",
}
REGION_NAMES = {"NC": "NCEDC", "SC": "SCEDC"}

# Association config per model type (matching predict_das.py pattern)
# moveout_window=None because CEED has too few stations for RANSAC
ASSOC_CONFIG = {
    "phasenet": dict(
        mph=5, mpd=5, min_ps_dt=0.5, max_ps_dt=20.0, bin_size=1.0,
        origin_window=1.0, moveout_window=None,
    ),
    "phasenet_plus": dict(
        mph=5, mpd=5, min_ps_dt=0.5, max_ps_dt=20.0, bin_size=1.0,
        origin_window=1.0, moveout_window=None,
    ),
}


# ---------------------------------------------------------------------------
# GCS helpers
# ---------------------------------------------------------------------------

def get_storage_options() -> dict:
    if os.path.exists(GCS_CRED_PATH):
        with open(GCS_CRED_PATH) as f:
            return {"token": json.load(f)}
    return {}


def build_event_array(
    records: list[dict],
) -> tuple[np.ndarray, list[str], str | None]:
    records = sorted(records, key=lambda r: r.get("distance_km") or 0.0)
    waves, trace_ids = [], []
    for rec in records:
        w = np.asarray(rec["waveform"], dtype=np.float32)
        if w.ndim == 1:
            w = w.reshape(3, -1)
        waves.append(w)
        net = rec.get("network", "")
        sta = rec.get("station", "")
        trace_ids.append(f"{net}.{sta}")
    waveform = np.stack(waves, axis=1)  # (3, nx, nt)
    begin_time = records[0].get("begin_time") if records else None
    return waveform, trace_ids, begin_time


# ---------------------------------------------------------------------------
# Model loading
# ---------------------------------------------------------------------------

def load_model(checkpoint: str = None, model_name: str = "phasenet") -> torch.nn.Module:
    """Load a model for prediction.

    Args:
        checkpoint: Path to trained checkpoint (.pth). If None, loads pretrained PhaseNet-2018.
        model_name: Model type (e.g. 'phasenet', 'phasenet_plus').
    """
    if checkpoint is None:
        model = load_phasenet2018_model(device=DEVICE)
        model._model_type = "phasenet"
        return model

    import phasenet.models
    ckpt = torch.load(checkpoint, map_location="cpu", weights_only=False)
    build_kwargs = ckpt.get("model_config", {})
    model = phasenet.models.__dict__[model_name].build_model(**build_kwargs)
    # Prefer EMA weights if available (saved without module. prefix)
    if "model_ema_weights" in ckpt:
        model.load_state_dict(ckpt["model_ema_weights"])
        print(f"Loaded EMA weights from {checkpoint}")
    else:
        model.load_state_dict(ckpt["model"])
        print(f"Loaded model weights from {checkpoint}")
    model._model_type = model_name
    model.to(DEVICE).eval()

    ckpt_args = ckpt.get("args")
    model.inference_nt = getattr(ckpt_args, "nt", NT_WIN) if ckpt_args else NT_WIN
    model.inference_nx = getattr(ckpt_args, "nx", NX_WIN) if ckpt_args else NX_WIN
    return model


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def iter_day_events(fs: gcsfs.GCSFileSystem, bucket: str, year: int, day: str):
    """Yield (event_id, records, waveform_index_map) from a single day parquet.

    waveform_index_map: dict[station_id, int] — absolute row index in the
    parquet file for each station in this event.
    """
    path = f"{bucket}/waveform_parquet/{year}/{day}.parquet"
    pf = pq.ParquetFile(fs.open(path))
    if "waveform" not in pf.schema_arrow.names:
        return

    non_wave_cols = [c for c in pf.schema_arrow.names if c != "waveform"]
    cur_eid: str | None = None
    cur_group: list[dict] = []
    cur_widx: dict[str, int] = {}
    row_offset = 0

    for batch in pf.iter_batches(batch_size=256):
        n = len(batch)
        col = batch.column("waveform")
        flat = col.flatten().flatten()
        buf = flat.buffers()[1]
        waveforms = np.frombuffer(
            buf, dtype=np.float32, offset=flat.offset * 4
        ).reshape(n, 3, -1).copy()
        meta = batch.select(non_wave_cols).to_pydict()
        for i in range(n):
            rec = {k: meta[k][i] for k in non_wave_cols}
            rec["waveform"] = waveforms[i]
            rec["_row_index"] = row_offset + i
            eid = rec.get("event_id") or ""
            if not eid:
                continue
            sid = f"{rec.get('network', '')}.{rec.get('station', '')}"
            if eid != cur_eid:
                if cur_eid and cur_group:
                    yield cur_eid, cur_group, cur_widx
                cur_eid, cur_group, cur_widx = eid, [rec], {sid: row_offset + i}
            else:
                cur_group.append(rec)
                cur_widx[sid] = row_offset + i
        row_offset += n

    if cur_eid and cur_group:
        yield cur_eid, cur_group, cur_widx


# ---------------------------------------------------------------------------
# Core pipeline (single day)
# ---------------------------------------------------------------------------

def process_day(model: torch.nn.Module, fs: gcsfs.GCSFileSystem,
                bucket: str, year: int, day: str,
                output_dir: str,
                plot: bool = False, n_events: int = None) -> str:
    """Run prediction for one region-day. Returns output parquet path."""
    out_path = os.path.join(output_dir, "picks", str(year), f"{day}.parquet")
    if os.path.exists(out_path):
        return out_path

    dt_s = 1.0 / SAMPLING_RATE
    nx_win = getattr(model, "inference_nx", NX_WIN)
    nt_win = getattr(model, "inference_nt", NT_WIN)
    all_rows: list[dict] = []
    if plot:
        figure_dir = os.path.join(output_dir, "figures")
        os.makedirs(figure_dir, exist_ok=True)

    for event_count, (event_id, records, widx_map) in enumerate(
            iter_day_events(fs, bucket, year, day)):
        if n_events is not None and event_count >= n_events:
            break
        try:
            waveform, trace_ids, begin_time = build_event_array(records)
        except Exception as e:
            print(f"  [WARN] {event_id}: {e}")
            continue

        # 1. Inference
        result = predict_2d(model, waveform, nx_win, nt_win,
                            MIN_T_OVERLAP, device=DEVICE, taper_nt=True)
        event_detections = None
        if isinstance(result, tuple):
            scores, event_detections = result
        else:
            scores = result

        picks = detect_picks(scores, trace_ids, event_id, begin_time,
                             dt_s=dt_s, vmin=MIN_PROB,
                             id_key="station_id", device=DEVICE)

        # 2. Association (two-path: event heads or PS pairs)
        nt_wf = waveform.shape[2]
        model_type = getattr(model, "_model_type", "phasenet")
        config = ASSOC_CONFIG.get(model_type, ASSOC_CONFIG["phasenet"])

        assoc_kwargs = dict(
            nt=nt_wf, dt_s=dt_s,
            bin_size=config.get("bin_size", 1.0),
            mph=config.get("mph", 5), mpd=config.get("mpd", 5),
            origin_window=config.get("origin_window"),
            moveout_window=config.get("moveout_window"),
        )

        if event_detections is not None:
            # Remap integer channel indices to station_id
            for det in event_detections:
                ch_idx = int(det["channel_index"])
                if ch_idx < len(trace_ids):
                    det["channel_index"] = trace_ids[ch_idx]
            pairs = estimate_origins_from_event_heads(
                event_detections, picks, dt_s=dt_s,
                id_key="station_id",
            )
        else:
            pairs = estimate_origins_from_ps_pairs(
                picks, dt_s=dt_s,
                min_ps_dt=config.get("min_ps_dt", 0.0),
                max_ps_dt=config.get("max_ps_dt", 20.0),
                id_key="station_id",
            )
        assoc = associate_picks(pairs, **assoc_kwargs)

        # 3. Enrich picks with origin info (for plotting and output)
        try:
            t0_abs = datetime.fromisoformat(begin_time.replace("Z", "+00:00")) if begin_time else None
        except (ValueError, AttributeError):
            t0_abs = None

        event_idx = {eid: int(round(t / dt_s)) for eid, t in enumerate(assoc.event_times)}
        event_iso = {eid: (t0_abs + timedelta(seconds=t)).isoformat(timespec="milliseconds")
                     if t0_abs else None
                     for eid, t in enumerate(assoc.event_times)}
        pair_origin = {(ch, int(pi)): int(round(t0 / dt_s))
                       for ch, pi, t0 in zip(assoc.pair_channels, assoc.pair_p_indices, assoc.pair_t0)}
        pair_info = {}
        for ch, pi, si, pc, ps in zip(assoc.pair_channels, assoc.pair_p_indices,
                                       assoc.pair_s_indices, assoc.pair_centers, assoc.pair_intervals):
            pair_info[(ch, int(pi))] = (pc, ps)
            pair_info[(ch, int(si))] = (pc, ps)

        for pk in picks:
            key = (pk["station_id"], pk["phase_index"], pk["phase_type"])
            oid = assoc.pick_to_event.get(key, -1)
            pk["origin_id"] = int(oid)
            pk["origin_index"] = event_idx.get(oid) or pair_origin.get(
                (pk["station_id"], int(pk["phase_index"])))
            pk["origin_time"] = event_iso.get(oid)
            info = pair_info.get((pk["station_id"], int(pk["phase_index"])))
            pk["ps_center"] = info[0] if info else None
            pk["ps_interval"] = info[1] if info else None

        # 4. Output all picks (matching predict_das.py pattern)
        for pk in picks:
            pk["event_id"] = event_id
            pk["waveform_index"] = widx_map.get(pk["station_id"])
            pk["dt_s"] = dt_s
        all_rows.extend(picks)

        # 5. Plot if requested
        if plot and assoc.pick_to_event:
            tid_all = {tid: i for i, tid in enumerate(trace_ids)}
            targets, p_total, s_total = build_targets_from_linked_map(
                assoc.pick_to_event,
                resolve_index=lambda sid: tid_all[sid],
                target_cls=Target,
                event_id_prefix=event_id,
            )
            sample = records_to_sample(records)
            if targets:
                sample.targets = targets
            linked_stas = len({sid for sid, _, _ in assoc.pick_to_event})
            print(f"  {event_id}: nx={waveform.shape[1]} nt={nt_wf}  "
                  f"linked_sta={linked_stas}  P={p_total} S={s_total}  "
                  f"origins={len(targets)}")
            save_path = os.path.join(figure_dir, f"{event_id}.png")
            plot_overview(sample, title=event_id, save_path=save_path, all_picks=picks)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    if all_rows:
        df = pd.DataFrame(all_rows)
        for col in ["origin_id", "origin_index", "phase_index", "waveform_index"]:
            if col in df.columns:
                df[col] = df[col].astype("Int64")
        df.to_parquet(out_path, index=False)
    return out_path


# ---------------------------------------------------------------------------
# Full prediction with sharding and prefetch
# ---------------------------------------------------------------------------

def list_day_files(fs: gcsfs.GCSFileSystem, bucket: str, year: int) -> list[str]:
    """Return sorted list of day numbers with parquet files."""
    files = fs.glob(f"{bucket}/waveform_parquet/{year}/*.parquet")
    return sorted(os.path.splitext(os.path.basename(f))[0] for f in files)


def predict_all(
    model: torch.nn.Module,
    year: int = 2025,
    output_dir: str = "results/ceed",
    task_id: int = 0,
    num_tasks: int = 1,
    regions: list[str] = None,
    plot: bool = False,
    n_days: int = None,
    n_events: int = None,
) -> None:
    """Run prediction on all days/regions with sharding and prefetch.

    Args:
        n_days: Limit to first N days per region (for quick testing).
        n_events: Limit to first N events per day.
        plot: Generate plots for each event.
    """
    if regions is None:
        regions = list(BUCKETS.keys())

    storage_options = get_storage_options()
    fs = gcsfs.GCSFileSystem(**storage_options)

    # Build work items: (region, bucket, day)
    work = []
    for region in regions:
        bucket = BUCKETS[region]
        days = list_day_files(fs, bucket, year)
        if n_days:
            days = days[:n_days]
        for day in days:
            work.append((region, bucket, day))

    # Shard
    shard_work = work[task_id::num_tasks]
    print(f"\n=== Predict CEED (year {year}) — task {task_id}/{num_tasks}, "
          f"{len(shard_work)}/{len(work)} day-files ===")

    t_start = time.time()
    n_done = 0

    with ThreadPoolExecutor(max_workers=1) as prefetch:
        def prefetch_day(_region, bucket, day):
            try:
                path = f"{bucket}/waveform_parquet/{year}/{day}.parquet"
                pf = pq.ParquetFile(fs.open(path))
                return pf.metadata.num_rows
            except Exception:
                return 0

        future = None
        if shard_work:
            future = prefetch.submit(prefetch_day, *shard_work[0])

        for i, (region, bucket, day) in enumerate(shard_work):
            if future is not None:
                future.result()
            if i + 1 < len(shard_work):
                future = prefetch.submit(prefetch_day, *shard_work[i + 1])

            process_day(model, fs, bucket, year, day,
                        output_dir=output_dir,
                        plot=plot, n_events=n_events)
            n_done += 1

            if n_done % 50 == 0:
                elapsed = time.time() - t_start
                rate = n_done / elapsed
                eta = (len(shard_work) - n_done) / rate if rate > 0 else 0
                print(f"  [{n_done}/{len(shard_work)}] {region}/{day}  "
                      f"{rate:.1f} days/s  ETA {eta/60:.0f}min")

    elapsed = time.time() - t_start
    print(f"\n  Done: {n_done} days in {elapsed:.0f}s "
          f"({n_done/elapsed:.1f} days/s) -> {output_dir}")



# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="CEED seismic prediction")
    # Model
    parser.add_argument("--model-type", default="phasenet",
                        help="Model architecture (e.g. phasenet, phasenet_plus)")
    parser.add_argument("--checkpoint",
                        help="Path to checkpoint (.pth). Default: pretrained PhaseNet-2018")
    # Data
    parser.add_argument("--year", type=int, default=2025, help="Year to process")
    parser.add_argument("--regions", nargs="+", default=["NC", "SC"],
                        help="Regions to process (default: NC SC)")
    # Output
    parser.add_argument("--output-dir",
                        help="Output dir (default: results/ceed/{model_name})")
    parser.add_argument("--plot", action="store_true", help="Generate plots for events")
    # Filtering
    parser.add_argument("--n-days", type=int,
                        help="Limit to first N days per region (for quick testing)")
    parser.add_argument("--n-events", type=int,
                        help="Limit to first N events per day (for quick testing)")
    # Parallelism
    parser.add_argument("--task-id", type=int, default=0, help="Shard index (0-based)")
    parser.add_argument("--num-tasks", type=int, default=1, help="Total number of shards")
    args = parser.parse_args()

    # Derive model name from checkpoint
    if args.checkpoint:
        model_name = os.path.basename(os.path.dirname(os.path.abspath(args.checkpoint)))
    else:
        model_name = "phasenet2018"

    model = load_model(checkpoint=args.checkpoint, model_name=args.model_type)
    print(f"Model loaded on {DEVICE}")

    for region in args.regions:
        output_dir = args.output_dir or f"results/ceed_{region.lower()}/{model_name}"

        print("=" * 60)
        print(f"CEED Prediction — {region}")
        print(f"  model={model_name}  year={args.year}")
        print(f"  output={output_dir}")
        print("=" * 60)

        predict_all(model, year=args.year, output_dir=output_dir,
                    task_id=args.task_id, num_tasks=args.num_tasks,
                    regions=[region], plot=args.plot,
                    n_days=args.n_days, n_events=args.n_events)

    print("\nDone.")


if __name__ == "__main__":
    main()
