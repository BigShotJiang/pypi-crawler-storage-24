#!/usr/bin/env python
"""Generate training label plots from CEED prediction results.

Loads a prediction parquet, joins with original waveforms from GCS,
and plots top-N events with training labels.

Usage:
    python examples/ceed_training_plots.py \
        --parquet results/ceed/phasenet2018/NC/2025_001.parquet \
        --region NC --year 2025 --day 001
"""
import argparse
import json
import os
import sys

sys.path.insert(0, ".")

import gcsfs
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from phasenet.data.ceed import (
    records_to_sample, default_train_transforms, plot_demo, Target,
)

BUCKETS = {
    "NC": "quakeflow_dataset/NCEDC",
    "SC": "quakeflow_dataset/SCEDC",
}
GCS_CRED_PATH = os.path.expanduser("~/.config/gcloud/application_default_credentials.json")


def get_storage_options():
    if os.path.exists(GCS_CRED_PATH):
        with open(GCS_CRED_PATH) as f:
            return {"token": json.load(f)}
    return {}


def load_day_waveforms(fs, bucket, year, day):
    """Return {waveform_index: ndarray (3, nt)} for a day parquet."""
    path = f"{bucket}/waveform_parquet/{year}/{day}.parquet"
    pf = pq.ParquetFile(fs.open(path))
    non_wave_cols = [c for c in pf.schema_arrow.names if c != "waveform"]
    result = {}
    row_offset = 0
    for batch in pf.iter_batches(batch_size=256):
        n = len(batch)
        col = batch.column("waveform")
        flat = col.flatten().flatten()
        buf = flat.buffers()[1]
        waveforms = np.frombuffer(
            buf, dtype=np.float32, offset=flat.offset * 4
        ).reshape(n, 3, -1).copy()
        meta = batch.select(non_wave_cols).to_pydict()
        for i in range(n):
            eid = meta["event_id"][i] or ""
            if eid:
                result[row_offset + i] = waveforms[i]
        row_offset += n
    return result


def generate_training_plots(parquet_path, region, fs, year, day,
                            n_events=3, figure_dir="figures/ceed"):
    """Load label parquet, join with original waveforms, plot training labels."""
    print(f"\n=== Training label plots for {region} ===")

    df = pd.read_parquet(parquet_path)
    print(f"  {len(df)} pick rows, "
          f"{df.groupby(['event_id','origin_index']).ngroups} detected origins")

    bucket = BUCKETS[region]
    print("  Loading waveforms from original parquet...")
    wave_by_idx = load_day_waveforms(fs, bucket, year, day)
    print(f"  {len(wave_by_idx)} waveforms loaded")

    raw_pq = pq.read_table(
        fs.open(f"{bucket}/waveform_parquet/{year}/{day}.parquet"),
        columns=["event_id", "network", "station", "distance_km", "begin_time"],
    ).to_pydict()
    n_raw = len(raw_pq["event_id"])
    meta_by_idx = {i: {k: raw_pq[k][i] for k in raw_pq} for i in range(n_raw)}

    top_eids = (
        df.groupby("event_id")["phase_index"].count()
        .nlargest(n_events).index
    )

    transforms = default_train_transforms(crop_length=4096, enable_stacking=False)
    fig_dir = os.path.join(figure_dir, region)

    for src_eid in top_eids:
        ev_df = df[df["event_id"] == src_eid]
        linked = ev_df[ev_df["origin_index"].notna()]
        valid_widxs = set(linked["waveform_index"].unique())

        if not valid_widxs:
            print(f"  [WARN] {src_eid}: no stations with model picks")
            continue

        recs_tagged = []
        for widx in valid_widxs:
            wave = wave_by_idx.get(widx)
            meta = meta_by_idx.get(widx, {})
            if wave is None:
                continue
            recs_tagged.append({
                "event_id": src_eid,
                "network": meta.get("network", ""),
                "station": meta.get("station", ""),
                "distance_km": meta.get("distance_km"),
                "begin_time": meta.get("begin_time"),
                "waveform": wave,
                "_widx": widx,
            })

        if not recs_tagged:
            print(f"  [WARN] {src_eid}: no waveforms found")
            continue

        recs_tagged.sort(key=lambda r: r.get("distance_km") or 0.0)
        widx_to_sta = {r["_widx"]: i for i, r in enumerate(recs_tagged)}
        recs = [{k: v for k, v in r.items() if k != "_widx"} for r in recs_tagged]

        p_picks_all, s_picks_all = [], []
        ps_centers_all, ps_intervals_all = [], []

        for widx, sta_grp in linked.groupby("waveform_index"):
            sta_idx = widx_to_sta.get(widx)
            if sta_idx is None:
                continue
            for pidx in sta_grp.loc[sta_grp["phase_type"] == "P", "phase_index"].dropna():
                p_picks_all.append((sta_idx, float(pidx)))
            for sidx in sta_grp.loc[sta_grp["phase_type"] == "S", "phase_index"].dropna():
                s_picks_all.append((sta_idx, float(sidx)))
            for _, o_grp in sta_grp.groupby("origin_index"):
                p_o = o_grp.loc[o_grp["phase_type"] == "P", "phase_index"].dropna()
                s_o = o_grp.loc[o_grp["phase_type"] == "S", "phase_index"].dropna()
                if p_o.empty or s_o.empty:
                    continue
                p_i, s_i = float(p_o.iloc[0]), float(s_o.iloc[0])
                ps_centers_all.append((sta_idx, (p_i + s_i) / 2.0))
                ps_intervals_all.append((sta_idx, s_i - p_i))

        try:
            sample = records_to_sample(recs)
            if p_picks_all or s_picks_all:
                sample.targets = [Target(
                    p_picks=p_picks_all, s_picks=s_picks_all,
                    ps_centers=ps_centers_all, ps_intervals=ps_intervals_all,
                    event_id=src_eid,
                )]
            n_origins = int(linked["origin_index"].nunique())
            print(f"  {src_eid}: {len(recs)} stations  origins={n_origins}  "
                  f"waveform {sample.waveform.shape}")
            plot_demo(sample, transforms, event_id=src_eid,
                      output_dir=fig_dir, n_augmented=2)
        except Exception as e:
            print(f"  [WARN] {src_eid}: {e}")


def main():
    parser = argparse.ArgumentParser(description="CEED training label plots")
    parser.add_argument("--parquet", required=True, help="Path to prediction parquet")
    parser.add_argument("--region", default="NC", help="Region (NC or SC)")
    parser.add_argument("--year", type=int, required=True)
    parser.add_argument("--day", required=True, help="Day string (e.g. 001)")
    parser.add_argument("--n-events", type=int, default=3)
    parser.add_argument("--figure-dir", default="figures/ceed")
    args = parser.parse_args()

    fs = gcsfs.GCSFileSystem(**get_storage_options())
    generate_training_plots(args.parquet, args.region, fs,
                            args.year, args.day, args.n_events, args.figure_dir)


if __name__ == "__main__":
    main()
