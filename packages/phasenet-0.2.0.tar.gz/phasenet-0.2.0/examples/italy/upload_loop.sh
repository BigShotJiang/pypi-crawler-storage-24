#!/bin/bash
# Continuously upload phasenet results every 10 minutes.
cd "$(dirname "$0")/.."

while true; do
    echo "$(date '+%Y-%m-%d %H:%M:%S') Running merge..."
    python scripts/convert_phasenet_origin.py
    echo "$(date '+%Y-%m-%d %H:%M:%S') Starting upload..."
    bash scripts/upload_phasenet_origin.sh
    echo "$(date '+%Y-%m-%d %H:%M:%S') Done. Sleeping 1 hour..."
    sleep 3600
done
