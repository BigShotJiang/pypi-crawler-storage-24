#!/bin/bash
# Upload phasenet_origin and phasenet results to GCS.
#
# Uses gsutil -m rsync for parallel upload with skip-existing behavior.
#
# Usage:
#   bash scripts/upload_phasenet_origin.sh              # all years
#   bash scripts/upload_phasenet_origin.sh 2024 2025    # specific years

set -euo pipefail
cd "$(dirname "$0")/.."

FOLDERS=("phasenet_origin" "phasenet")

if [ $# -gt 0 ]; then
    YEARS=("$@")
fi

for folder in "${FOLDERS[@]}"; do
    LOCAL="results/$folder"
    GCS="gs://quakeflow_catalog/Italy/$folder"

    if [ ! -d "$LOCAL" ]; then
        echo "[SKIP] $LOCAL not found"
        continue
    fi

    if [ $# -eq 0 ]; then
        YEARS=($(ls "$LOCAL"/))
    fi

    echo "=== Uploading $folder ==="
    for year in "${YEARS[@]}"; do
        src="$LOCAL/$year"
        dst="$GCS/$year"
        if [ ! -d "$src" ]; then
            echo "[SKIP] $src not found"
            continue
        fi
        n=$(find "$src" -name "*.csv" | wc -l)
        printf "[UPLOAD] %s: %'d files → %s\n" "$year" "$n" "$dst"
        gsutil -m rsync -r "$src" "$dst"
    done
    echo ""
done

echo "Done."
