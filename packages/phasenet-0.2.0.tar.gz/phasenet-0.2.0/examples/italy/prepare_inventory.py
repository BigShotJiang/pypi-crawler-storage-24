#!/usr/bin/env python
"""
prepare_inventory.py — Build per-station FDSNstationXML inventory files.

Saves inventory files as:
    {inventory_dir}/{network}/{network}.{station}.xml

Two-step strategy:
  1. Convert any existing local XML files into per-station format
  2. Parse mseed list to find all needed (network, station) pairs,
     then fetch missing ones via obspy FDSN (INGV first, then IRIS)

Usage:
    # Full pipeline: convert local + fetch missing for a year's mseed list
    python scripts/prepare_inventory.py --mseed-list results/mseed_list/2024_3c.txt

    # Process all mseed lists
    python scripts/prepare_inventory.py

    # Upload results to GCS
    python scripts/prepare_inventory.py --upload
"""
import argparse
import shutil
import subprocess
from collections import defaultdict
from pathlib import Path

from obspy import Inventory, read_inventory
from obspy.clients.fdsn import Client

# Default provider order: INGV (primary for Italy), then IRIS, then European FDSN nodes
DEFAULT_PROVIDERS = ["INGV", "IRIS", "ODC", "ETH", "RESIF", "GFZ", "NOA", "KNMI", "LMU", "BGR", "NIEP"]

# Network -> preferred providers (tried before the default list)
NETWORK_PROVIDERS = {
    "CH": ["ETH"],
    "FR": ["RESIF"],
    "OE": ["GFZ", "ODC"],
    "CR": ["ODC", "GFZ"],
    "HL": ["NOA"],
    "RD": ["RESIF"],
    "VR": ["GFZ", "ODC"],
    "IT": ["INGV", "ODC", "GFZ"],
}

INVENTORY_CACHE = Path("/home/jovyan/data/inventory")  # read-only pre-existing cache
INVENTORY_DIR = Path("/home/jovyan/phasenet-pytorch/results/FDSNstationXML")
MSEED_LIST_DIR = Path("/home/jovyan/phasenet-pytorch/results/mseed_list")
GCS_INVENTORY = "gs://quakeflow_catalog/Italy/FDSNstationXML"


def get_network_stations_from_mseed_list(mseed_list_files: list[Path]) -> dict[str, set[str]]:
    """Parse mseed list files to extract all (network -> set of stations).

    Each line is pipe-separated paths like:
        /path/to/NET.STA..CHN.D.YEAR.JDAY|...
    We parse net and station from the filename (first two dot-separated fields).
    """
    net_stations = defaultdict(set)
    for list_file in mseed_list_files:
        for line in list_file.read_text().strip().split("\n"):
            # Take the first component path to get net.sta
            first_path = line.split("|")[0]
            fname = Path(first_path).name  # e.g. IV.ACATE..EHE.D.2024.043
            parts = fname.split(".")
            if len(parts) >= 2 and parts[0]:
                net_stations[parts[0]].add(parts[1])
    return dict(net_stations)


def station_xml_path(inventory_dir: Path, network: str, station: str) -> Path:
    """Return the expected path for a station XML file."""
    return inventory_dir / network / f"{network}.{station}.xml"


def save_station_inventory(inv: Inventory, network: str, station: str, inventory_dir: Path) -> Path:
    """Extract a single station from an Inventory and save it."""
    out_path = station_xml_path(inventory_dir, network, station)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Select just this station
    sta_inv = inv.select(network=network, station=station)
    sta_inv.write(str(out_path), format="STATIONXML")
    return out_path


def fetch_network_inventory(
    network: str,
    stations: set[str],
    inventory_dir: Path,
) -> tuple[list[str], list[str]]:
    """Fetch inventory for all missing stations in a network. Returns (succeeded, failed) station lists."""
    # Determine which stations still need fetching
    missing = []
    succeeded = []
    for station in sorted(stations):
        out_path = station_xml_path(inventory_dir, network, station)
        if out_path.exists():
            succeeded.append(station)
            continue
        missing.append(station)

    if not missing:
        print(f"  {network}: all {len(stations)} stations already cached")
        return succeeded, []

    print(f"  {network}: {len(missing)} stations to fetch ({len(succeeded)} cached)")

    # Build provider list: network-specific first, then defaults, deduplicated
    preferred = NETWORK_PROVIDERS.get(network, [])
    providers = list(dict.fromkeys(preferred + DEFAULT_PROVIDERS))

    # Try providers until all stations are found or providers exhausted
    still_missing = set(missing)
    for provider in providers:
        if not still_missing:
            break
        try:
            print(f"  {network}: trying {provider} ({len(still_missing)} remaining)...")
            client = Client(provider)
            inv = client.get_stations(network=network, level="response")

            # Split into per-station files
            fetched = set()
            for net_obj in inv:
                for sta_obj in net_obj:
                    sta_code = sta_obj.code
                    if sta_code in still_missing:
                        save_station_inventory(inv, network, sta_code, inventory_dir)
                        fetched.add(sta_code)

            if fetched:
                succeeded.extend(sorted(fetched))
                still_missing -= fetched
                print(f"  {network}: got {len(fetched)} stations from {provider}")
            else:
                print(f"  {network}: {provider} had no new stations")

        except Exception as e:
            print(f"  {network}: {provider} failed ({e})")

    if still_missing:
        print(f"  {network}: {len(still_missing)} stations not found anywhere: {sorted(still_missing)[:10]}...")
    return succeeded, sorted(still_missing)


def convert_local_cache(cache_dir: Path, inventory_dir: Path) -> int:
    """Read all XML files from cache_dir and split into per-station files."""
    total = 0
    for xml in sorted(cache_dir.glob("*.xml")):
        try:
            inv = read_inventory(str(xml))
        except Exception as e:
            print(f"  SKIP {xml.name}: {e}")
            continue
        count = 0
        for net_obj in inv:
            for sta_obj in net_obj:
                out_path = station_xml_path(inventory_dir, net_obj.code, sta_obj.code)
                if out_path.exists():
                    continue
                save_station_inventory(inv, net_obj.code, sta_obj.code, inventory_dir)
                count += 1
        if count:
            print(f"  {xml.name}: converted {count} stations")
        total += count
    return total


def main():
    parser = argparse.ArgumentParser(description="Build per-station FDSNstationXML inventory")
    parser.add_argument("--mseed-list", type=str, default=None,
                        help="Path to a specific mseed list file (default: all files in mseed_list_dir)")
    parser.add_argument("--mseed-list-dir", type=str, default=str(MSEED_LIST_DIR),
                        help="Directory containing mseed list files")
    parser.add_argument("--upload", action="store_true", help="Upload inventory files to GCS")
    parser.add_argument("--inventory-dir", type=str, default=str(INVENTORY_DIR),
                        help="Output directory for per-station XMLs")
    parser.add_argument("--cache-dir", type=str, default=str(INVENTORY_CACHE),
                        help="Read-only inventory cache directory")
    args = parser.parse_args()

    inventory_dir = Path(args.inventory_dir)
    inventory_dir.mkdir(parents=True, exist_ok=True)
    cache_dir = Path(args.cache_dir)

    # Step 1: Convert local XML cache into per-station format
    print(f"Step 1: Converting local XML files from {cache_dir}...")
    converted = convert_local_cache(cache_dir, inventory_dir)
    total_xmls = sum(1 for _ in inventory_dir.rglob("*.xml"))
    print(f"  Converted {converted} new station XMLs (total: {total_xmls})\n")

    # Step 2: Parse mseed lists to find needed stations, fetch missing from FDSN
    if args.mseed_list:
        mseed_list_files = [Path(args.mseed_list)]
    else:
        mseed_list_dir = Path(args.mseed_list_dir)
        mseed_list_files = sorted(mseed_list_dir.glob("*_3c.txt"))

    if not mseed_list_files:
        print("No mseed list files found. Run prepare_mseed_list.py first.")
        return

    print(f"Step 2: Parsing {len(mseed_list_files)} mseed list file(s)...")
    net_stations = get_network_stations_from_mseed_list(mseed_list_files)
    total_stations = sum(len(s) for s in net_stations.values())
    print(f"  Found {len(net_stations)} networks, {total_stations} unique stations\n")

    print("Step 3: Fetching missing inventory from FDSN...")
    all_succeeded = []
    all_failed = []
    for network in sorted(net_stations):
        stations = net_stations[network]
        succeeded, failed = fetch_network_inventory(network, stations, inventory_dir)
        all_succeeded.extend((network, s) for s in succeeded)
        all_failed.extend((network, s) for s in failed)

    if args.upload and all_succeeded:
        print(f"\nUploading {len(all_succeeded)} inventory files to GCS...")
        for network, station in all_succeeded:
            local_path = station_xml_path(inventory_dir, network, station)
            gcs_path = f"{GCS_INVENTORY}/{network}/{network}.{station}.xml"
            print(f"  {local_path.name} -> {gcs_path}")
            subprocess.run(["gsutil", "cp", str(local_path), gcs_path], check=True)

    print(f"\nSummary: {len(all_succeeded)} succeeded, {len(all_failed)} failed")
    if all_failed:
        print(f"Failed (first 20): {all_failed[:20]}")


if __name__ == "__main__":
    main()
