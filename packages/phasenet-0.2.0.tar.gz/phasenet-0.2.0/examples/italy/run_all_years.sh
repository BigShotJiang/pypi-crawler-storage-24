#!/bin/bash
# Launch PhaseNet prediction for all years as separate nohup sessions.
#
# Each year runs in its own background process with --skip-existing,
# so any year can be safely restarted.
#
# Usage:
#   bash scripts/run_all_years.sh              # all years
#   bash scripts/run_all_years.sh 2024 2025    # specific years
#
# Monitor: tail -f logs/predict_2024.log
# Check:   ps aux | grep predict_mseed

set -euo pipefail
cd "$(dirname "$0")/.."

PYTHON="${PYTHON:-/home/jovyan/.local/miniconda3/bin/python}"
#PYTHON="${PYTHON:-/opt/conda/bin/python}"
INVENTORY="results/FDSNstationXML/"
RESULT_DIR="results/phasenet_origin"
LIST_DIR="results/mseed_list"
LOG_DIR="logs"

mkdir -p "$LOG_DIR"

# Years from args or all available
if [ $# -gt 0 ]; then
    YEARS=("$@")
else
    YEARS=()
    for f in "$LIST_DIR"/*_3c.txt; do
        YEARS+=($(basename "$f" | cut -d_ -f1))
    done
fi

echo "Launching ${#YEARS[@]} years: ${YEARS[*]}"
echo ""

for year in "${YEARS[@]}"; do
    list="$LIST_DIR/${year}_3c.txt"
    log="$LOG_DIR/predict_${year}.log"

    if [ ! -f "$list" ]; then
        echo "  [SKIP] $year: $list not found"
        continue
    fi

    n=$(wc -l < "$list")
    printf "  [START] %s (%'d entries) → %s\n" "$year" "$n" "$log"

    nohup $PYTHON -u scripts/predict_mseed.py \
        --data-list "$list" \
        --inventory "$INVENTORY" \
        --result-dir "$RESULT_DIR" \
        --skip-existing \
        > "$log" 2>&1 &

    echo "         PID: $!"
done

echo ""
echo "All launched. Monitor with:"
echo "  tail -f logs/predict_*.log"
echo "  ps aux | grep predict_mseed"
