#!/usr/bin/env python
"""
prepare_mseed_list.py — Build 3-component mseed file lists from an SDS archive.

For each station+instrument combination on each day, groups up to 3 component
files (E/N/Z or 1/2/Z) into a single pipe-separated row. The output is one
text file per year: {year}_3c.txt

Optionally uploads the lists to GCS.

Usage:
    # Build lists for all years
    python scripts/prepare_mseed_list.py

    # Build list for a specific year
    python scripts/prepare_mseed_list.py --year 2024

    # Build and upload to GCS
    python scripts/prepare_mseed_list.py --year 2024 --upload
"""
import argparse
import os
import subprocess
from collections import defaultdict
from pathlib import Path

SDS_ROOT = Path("/home/jovyan/data/sds")
OUTPUT_DIR = Path("/home/jovyan/phasenet-pytorch/results/mseed_list")
GCS_MSEED_LIST = "gs://quakeflow_catalog/Italy/mseed_list"


def build_mseed_list(year: int) -> list[str]:
    """Scan SDS archive for a given year and return sorted 3-component rows."""
    year_dir = SDS_ROOT / str(year)
    if not year_dir.is_dir():
        print(f"  Skipping {year}: directory not found")
        return []

    # Collect: (net, sta, instrument, jday) -> [file paths]
    groups = defaultdict(list)
    for net_dir in sorted(year_dir.iterdir()):
        if not net_dir.is_dir():
            continue
        net = net_dir.name
        for sta_dir in sorted(net_dir.iterdir()):
            if not sta_dir.is_dir():
                continue
            sta = sta_dir.name
            for chan_dir in sorted(sta_dir.iterdir()):
                if not chan_dir.is_dir():
                    continue
                # chan_dir.name is like "EHE.D"
                chan_code = chan_dir.name.split(".")[0]  # e.g. "EHE"
                if len(chan_code) < 3:
                    continue
                instrument = chan_code[:2]  # e.g. "EH"

                for fname in sorted(chan_dir.iterdir()):
                    if not fname.is_file() or fname.name.startswith("."):
                        continue
                    # fname: IV.ACATE..EHE.D.2024.043
                    parts = fname.name.split(".")
                    if len(parts) < 7:
                        continue
                    jday = parts[-1]  # e.g. "043"
                    key = (net, sta, instrument, jday)
                    fpath = str(fname)
                    groups[key].append(fpath)

    # Build rows: sort components and join with |
    rows = []
    for key in sorted(groups.keys()):
        files = sorted(groups[key])
        rows.append("|".join(files))

    print(f"  Year {year}: {len(rows)} station-instrument-day entries")
    return rows


def main():
    parser = argparse.ArgumentParser(description="Build 3-component mseed file lists from SDS archive")
    parser.add_argument("--year", type=int, default=None, help="Process a specific year (default: all)")
    parser.add_argument("--upload", action="store_true", help="Upload lists to GCS")
    parser.add_argument("--sds-root", type=str, default=str(SDS_ROOT), help="SDS root directory")
    parser.add_argument("--output-dir", type=str, default=str(OUTPUT_DIR), help="Output directory for lists")
    args = parser.parse_args()

    sds_root = Path(args.sds_root)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if args.year:
        years = [args.year]
    else:
        years = sorted(int(d.name) for d in sds_root.iterdir() if d.is_dir() and d.name.isdigit())

    for year in years:
        print(f"Processing year {year}...")
        rows = build_mseed_list(year)
        if not rows:
            continue

        out_file = output_dir / f"{year}_3c.txt"
        with open(out_file, "w") as f:
            f.write("\n".join(rows) + "\n")
        print(f"  Wrote {out_file}")

        if args.upload:
            gcs_path = f"{GCS_MSEED_LIST}/{year}_3c.txt"
            print(f"  Uploading to {gcs_path}...")
            subprocess.run(["gsutil", "cp", str(out_file), gcs_path], check=True)
            print(f"  Done.")

    print("All done.")


if __name__ == "__main__":
    main()
