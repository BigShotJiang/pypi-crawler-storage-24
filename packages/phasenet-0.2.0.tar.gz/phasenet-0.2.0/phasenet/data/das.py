# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "fsspec",
#     "gcsfs",
#     "h5py",
#     "numpy",
#     "pandas",
#     "scipy",
#     "torch",
# ]
# ///
"""
DAS (Distributed Acoustic Sensing) Data Loading Module

A modern, efficient dataset implementation for DAS phase picking following
best practices from computer vision (torchvision, timm, albumentations).

Design Principles:
1. COCO-style Target annotations: each event is a separate Target object,
   making multi-event stacking trivial and per-event metadata preserved
2. Unified (nch, nx, nt) internal format: (1, num_channels, num_time_samples)
3. Transform-based augmentation operating on raw picks before label generation
4. Compose pattern for chaining transforms
5. Clean separation: loading -> transforms -> label generation
6. Support for both local filesystem and Google Cloud Storage (GCS)

Example:
    >>> from phasenet.data.das import Sample, default_train_transforms, DASIterableDataset
    >>> transforms = default_train_transforms(nt=4096, nx=2048)
    >>> dataset = DASIterableDataset(
    ...     data_path="gs://quakeflow_das/ridgecrest_north",
    ...     label_path="gs://quakeflow_das/ridgecrest_north",
    ...     training=True,
    ...     transforms=transforms,
    ... )
"""
from __future__ import annotations

import json
import os
import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from glob import glob
from typing import Any, Callable, Iterator

import fsspec
import h5py
import numpy as np
import pandas as pd
import scipy
import scipy.signal
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, IterableDataset

from .transforms import (
    Transform, Compose, Identity, Normalize, HighpassFilter,
    RandomGain, ColoredNoise, RandomBandpass, ResampleTime,
    RandomCrop, StackEvents, SampleBuffer, measure_signal_noise,
)


# =============================================================================
# Configuration
# =============================================================================

BUCKET_DAS = "gs://quakeflow_das"
GCS_CREDENTIALS_PATH = os.path.expanduser("~/.config/gcloud/application_default_credentials.json")
DEFAULT_SAMPLING_RATE = 100  # Hz
DEFAULT_SPATIAL_INTERVAL = 10.0  # meters
VP_VS_RATIO = 1.73  # Vp/Vs


@dataclass
class LabelConfig:
    """Configuration for DAS label generation."""
    phase_width: int = 60  # Gaussian width for phase picks (samples)
    event_width: int = 150  # Gaussian width for event center
    mask_width_factor: float = 1.5  # mask_width = width * factor
    gaussian_threshold: float = 0.05  # Values below this are zeroed
    vp: float = 6.0  # P-wave velocity (km/s)
    vp_vs_ratio: float = 1.73  # Vp/Vs ratio


# =============================================================================
# Data Structures — COCO-style Target + Sample
# =============================================================================

@dataclass
class Target:
    """Per-event annotation for DAS data, following COCO/torchvision conventions.

    Each Target represents ONE seismic event's picks on the waveform.
    A Sample can have multiple Targets (e.g. from event stacking).

    Picks are (channel_index, time_sample) tuples.
    """
    p_picks: list[tuple[int, float]] = field(default_factory=list)
    s_picks: list[tuple[int, float]] = field(default_factory=list)
    ps_centers: list[tuple[int, float]] = field(default_factory=list)  # (ch, center_time)
    ps_intervals: list[tuple[int, float]] = field(default_factory=list)  # (ch, S-P interval)

    # Per-event metadata
    event_id: str = ""
    snr: float = 0.0
    amp_signal: float = 0.0
    amp_noise: float = 0.0

    def copy(self) -> "Target":
        return Target(
            p_picks=self.p_picks.copy(),
            s_picks=self.s_picks.copy(),
            ps_centers=self.ps_centers.copy(),
            ps_intervals=self.ps_intervals.copy(),
            event_id=self.event_id,
            snr=self.snr,
            amp_signal=self.amp_signal,
            amp_noise=self.amp_noise,
        )

    @property
    def is_empty(self) -> bool:
        return not self.p_picks and not self.s_picks

    def all_times(self) -> list[float]:
        """All pick times (P + S)."""
        return [t for _, t in self.p_picks] + [t for _, t in self.s_picks]

    # -- Pick adjustment methods (in-place, return self for chaining) --

    def crop(self, t0: int, nt: int, x0: int, nx: int) -> "Target":
        """Keep picks in [x0, x0+nx) x [t0, t0+nt), shift to new origin."""
        self.p_picks = [
            (ch - x0, t - t0) for ch, t in self.p_picks
            if x0 <= ch < x0 + nx and t0 <= t < t0 + nt
        ]
        self.s_picks = [
            (ch - x0, t - t0) for ch, t in self.s_picks
            if x0 <= ch < x0 + nx and t0 <= t < t0 + nt
        ]
        ec, ps = [], []
        for (ch, t), (_, d) in zip(self.ps_centers, self.ps_intervals):
            if x0 <= ch < x0 + nx and t0 <= t < t0 + nt:
                ec.append((ch - x0, t - t0))
                ps.append((ch - x0, d))
        self.ps_centers, self.ps_intervals = ec, ps
        return self

    def shift_time(self, shift: int, nt: int, wrap: bool = True) -> "Target":
        """Shift all time indices. Wraps modulo nt or clips to [0, nt)."""
        if wrap:
            self.p_picks = [(ch, (t + shift) % nt) for ch, t in self.p_picks]
            self.s_picks = [(ch, (t + shift) % nt) for ch, t in self.s_picks]
            self.ps_centers = [(ch, (t + shift) % nt) for ch, t in self.ps_centers]
        else:
            self.p_picks = [(ch, t + shift) for ch, t in self.p_picks if 0 <= t + shift < nt]
            self.s_picks = [(ch, t + shift) for ch, t in self.s_picks if 0 <= t + shift < nt]
            ec, ps = [], []
            for (ch, t), (_, d) in zip(self.ps_centers, self.ps_intervals):
                if 0 <= t + shift < nt:
                    ec.append((ch, t + shift))
                    ps.append((ch, d))
            self.ps_centers, self.ps_intervals = ec, ps
        return self

    def scale_time(self, factor: float) -> "Target":
        """Scale time indices by factor."""
        self.p_picks = [(ch, t * factor) for ch, t in self.p_picks]
        self.s_picks = [(ch, t * factor) for ch, t in self.s_picks]
        ec, ps = [], []
        for (ch, t), (_, d) in zip(self.ps_centers, self.ps_intervals):
            ec.append((ch, t * factor))
            ps.append((ch, d * factor))
        self.ps_centers, self.ps_intervals = ec, ps
        return self

    def flip_space(self, nx: int) -> "Target":
        """Flip channel indices for spatial flip."""
        self.p_picks = [(nx - 1 - ch, t) for ch, t in self.p_picks]
        self.s_picks = [(nx - 1 - ch, t) for ch, t in self.s_picks]
        self.ps_centers = [(nx - 1 - ch, t) for ch, t in self.ps_centers]
        self.ps_intervals = [(nx - 1 - ch, d) for ch, d in self.ps_intervals]
        return self

    def scale_space(self, factor: float) -> "Target":
        """Scale channel indices by factor."""
        self.p_picks = [(int(ch * factor), t) for ch, t in self.p_picks]
        self.s_picks = [(int(ch * factor), t) for ch, t in self.s_picks]
        self.ps_centers = [(int(ch * factor), t) for ch, t in self.ps_centers]
        self.ps_intervals = [(int(ch * factor), d) for ch, d in self.ps_intervals]
        return self

    def mask_time(self, t0: int, t1: int) -> "Target":
        """Remove picks in time window [t0, t1)."""
        self.p_picks = [(ch, t) for ch, t in self.p_picks if not (t0 <= t < t1)]
        self.s_picks = [(ch, t) for ch, t in self.s_picks if not (t0 <= t < t1)]
        ec, ps = [], []
        for (ch, t), (_, d) in zip(self.ps_centers, self.ps_intervals):
            if not (t0 <= t < t1):
                ec.append((ch, t))
                ps.append((ch, d))
        self.ps_centers, self.ps_intervals = ec, ps
        return self


@dataclass
class Sample:
    """A DAS sample with waveform and per-event annotations.

    Waveform shape: (nch, nx, nt) = (1, num_channels, num_time_samples).
    targets: list of Target, one per seismic event in the window.
    """
    waveform: np.ndarray  # (nch, nx, nt) — always 3D
    targets: list[Target] = field(default_factory=list)

    # Metadata
    dt_s: float = 0.01
    dx_m: float = 10.0
    file_name: str = ""
    begin_time: datetime | None = None
    # All picks (incl. unassociated) for noise exclusion
    all_pick_times: list[float] = field(default_factory=list)
    all_origin_times: list[float] = field(default_factory=list)
    all_ps_centers: list[float] = field(default_factory=list)
    all_ps_intervals: list[float] = field(default_factory=list)

    @property
    def nch(self) -> int:
        return self.waveform.shape[0]

    @property
    def nx(self) -> int:
        return self.waveform.shape[1]

    @property
    def nt(self) -> int:
        return self.waveform.shape[2]

    @property
    def snr(self) -> float:
        """Max SNR across all targets."""
        vals = [t.snr for t in self.targets if t.snr > 0]
        return max(vals) if vals else 0.0

    @property
    def amp_signal(self) -> float:
        """Weakest event signal (conservative for stacking ratio)."""
        vals = [t.amp_signal for t in self.targets if t.amp_signal > 0]
        return min(vals) if vals else 0.0

    @property
    def amp_noise(self) -> float:
        """Worst-case noise level across events."""
        vals = [t.amp_noise for t in self.targets if t.amp_noise > 0]
        return max(vals) if vals else 0.0

    def copy(self, deep_waveform: bool = False) -> "Sample":
        return Sample(
            waveform=self.waveform.copy() if deep_waveform else self.waveform,
            targets=[t.copy() for t in self.targets],
            dt_s=self.dt_s,
            dx_m=self.dx_m,
            file_name=self.file_name,
            begin_time=self.begin_time,
            all_pick_times=self.all_pick_times,
            all_origin_times=self.all_origin_times,
            all_ps_centers=self.all_ps_centers,
            all_ps_intervals=self.all_ps_intervals,
        )


# =============================================================================
# Transforms — Following CV Best Practices (torchvision/albumentations pattern)
# =============================================================================
# Base transforms (Transform, Compose, Identity, Normalize, HighpassFilter,
# RandomGain, ColoredNoise, RandomBandpass, ResampleTime, RandomCrop,
# StackEvents, SampleBuffer) are imported from phasenet.data.transforms.
# DAS-specific transforms are defined below.


class MedianFilter(Transform):
    """Remove median along spatial axis (common-mode rejection).

    Args:
        p: Probability of applying
    """

    def __init__(self, p: float = 1.0):
        self.p = p

    def __call__(self, sample: Sample) -> Sample:
        if random.random() > self.p:
            return sample
        # torch.median is ~9x faster than np.median on CPU
        t = torch.from_numpy(sample.waveform)
        med = torch.median(t, dim=-2, keepdim=True).values
        t -= med
        sample.waveform = t.numpy()
        return sample

    def __repr__(self) -> str:
        return f"MedianFilter(p={self.p})"


# -----------------------------------------------------------------------------
# Spatial-Temporal Transforms
# -----------------------------------------------------------------------------


class FlipLR(Transform):
    """Randomly flip waveform horizontally (spatial axis).

    Args:
        p: Probability of flipping
    """

    def __init__(self, p: float = 0.5):
        self.p = p

    def __call__(self, sample: Sample) -> Sample:
        if random.random() < self.p:
            nx = sample.nx
            sample.waveform = np.flip(sample.waveform, axis=-2).copy()  # flip spatial axis
            for target in sample.targets:
                target.flip_space(nx)
        return sample

    def __repr__(self) -> str:
        return f"FlipLR(p={self.p})"


class ResampleSpace(Transform):
    """Resample spatial axis by a random factor.

    Applied before crop. If resampling shrinks nx below crop size,
    RandomCrop._pad_if_needed uses reflection padding (physically valid).

    Args:
        min_factor: Minimum scale factor
        max_factor: Maximum scale factor
        p: Probability of applying
    """

    def __init__(self, min_factor: float = 0.5, max_factor: float = 5.0, p: float = 1.0):
        self.min_factor = min_factor
        self.max_factor = max_factor
        self.p = p

    def __call__(self, sample: Sample) -> Sample:
        if random.random() > self.p:
            return sample
        factor = random.uniform(self.min_factor, self.max_factor)
        if abs(factor - 1.0) < 0.01:
            return sample

        data_tensor = torch.from_numpy(sample.waveform).unsqueeze(0)
        data_resampled = F.interpolate(
            data_tensor, scale_factor=(factor, 1), mode="bilinear", align_corners=False
        ).squeeze(0).numpy()
        sample.waveform = data_resampled

        for target in sample.targets:
            target.scale_space(factor)

        if hasattr(sample, 'dx_m') and sample.dx_m is not None:
            sample.dx_m = sample.dx_m / factor

        return sample

    def __repr__(self) -> str:
        return f"ResampleSpace(min_factor={self.min_factor}, max_factor={self.max_factor})"


# -----------------------------------------------------------------------------
# Masking Transforms
# -----------------------------------------------------------------------------

class Masking(Transform):
    """Randomly mask a time window in the waveform.

    Args:
        max_mask_nt: Maximum mask width in time samples
        p: Probability of applying mask
    """

    def __init__(self, max_mask_nt: int = 256, p: float = 0.2):
        self.max_mask_nt = max_mask_nt
        self.p = p

    def __call__(self, sample: Sample) -> Sample:
        if random.random() > self.p:
            return sample

        nt = sample.nt
        mask_nt = random.randint(32, min(self.max_mask_nt, nt // 2))

        # Histogram of all pick times across channels to find active time ranges
        all_times = [t for tgt in sample.targets for t in tgt.all_times()]
        if not all_times:
            t0 = random.randint(0, nt - mask_nt)
            sample.waveform[:, :, t0:t0 + mask_nt] = 0.0
            return sample

        bin_size = 100
        margin = 500
        bins = np.arange(0, nt + bin_size, bin_size)
        counts, edges = np.histogram(all_times, bins=bins)
        hot = np.where(counts > 0)[0]

        # Merge adjacent hot bins + margin into excluded intervals
        excluded = []
        if len(hot) > 0:
            start = int(edges[hot[0]]) - margin
            end = int(edges[hot[0] + 1]) + margin
            for i in hot[1:]:
                s_new = int(edges[i]) - margin
                e_new = int(edges[i + 1]) + margin
                if s_new <= end:
                    end = max(end, e_new)
                else:
                    excluded.append((max(0, start), min(nt, end)))
                    start, end = s_new, e_new
            excluded.append((max(0, start), min(nt, end)))

        # Collect valid start positions (gaps between excluded intervals)
        valid = []
        prev_end = 0
        for start, end in excluded:
            if start - prev_end >= mask_nt:
                valid.append((prev_end, start - mask_nt))
            prev_end = end
        if nt - prev_end >= mask_nt:
            valid.append((prev_end, nt - mask_nt))

        if not valid:
            return sample

        region = random.choice(valid)
        t0 = random.randint(region[0], region[1])
        sample.waveform[:, :, t0:t0 + mask_nt] = 0.0
        return sample

    def __repr__(self) -> str:
        return f"Masking(max_mask_nt={self.max_mask_nt}, p={self.p})"


# -----------------------------------------------------------------------------
# Stacking Transforms
# -----------------------------------------------------------------------------


class StackNoise(Transform):
    """Stack noise onto the waveform to achieve a target SNR.

    Supports two noise sources (tried in order):
    1. Dedicated noise files via set_noise_fn
    2. Pre-arrival extraction from other samples via set_sample_fn

    Args:
        min_snr: Minimum target SNR after stacking (most noisy)
        max_snr: Maximum target SNR after stacking (least noisy)
        p: Probability of applying
    """

    def __init__(self, min_snr: float = 1.0, max_snr: float = 5.0, p: float = 0.5):
        self.min_snr = min_snr
        self.max_snr = max_snr
        self.p = p
        self._noise_fn: Callable[[], np.ndarray | None] | None = None
        self._sample_fn: Callable[[], Sample | None] | None = None

    def set_noise_fn(self, fn: Callable[[], np.ndarray | None]):
        """Set function to get random noise arrays (e.g., from dedicated noise files)."""
        self._noise_fn = fn

    def set_sample_fn(self, fn: Callable[[], Sample | None]):
        """Set function to get random samples (for pre-arrival noise extraction)."""
        self._sample_fn = fn

    def _extract_tail_noise(self, donor: Sample, length: int) -> np.ndarray | None:
        """Extract noise from the end of the donor waveform, past all picks."""
        nt = donor.waveform.shape[-1]
        if nt < length:
            return None
        all_times = [t for tgt in donor.targets for t in tgt.all_times()]
        last_pick = int(max(all_times)) if all_times else 0
        start = nt - length
        if start < last_pick + 100:  # margin for label Gaussian tail
            return None
        return donor.waveform[..., start:]

    def _get_noise(self, sample: Sample) -> np.ndarray | None:
        """Get noise: dedicated files first, then tail extraction."""
        if self._noise_fn is not None:
            noise = self._noise_fn()
            if noise is not None:
                return noise
        if self._sample_fn is not None:
            donor = self._sample_fn()
            if donor is not None:
                return self._extract_tail_noise(donor, sample.nt)
        return None

    def __call__(self, sample: Sample) -> Sample:
        if random.random() > self.p:
            return sample
        S1, N1 = measure_signal_noise(sample.waveform, sample.targets, sample.nx, sample.nt)
        if S1 <= 0 or N1 <= 0 or S1 <= N1:
            return sample
        noise = self._get_noise(sample)
        if noise is None:
            return sample
        # Random crop noise to match sample dimensions
        _, nx_n, nt_n = noise.shape
        _, nx_s, nt_s = sample.waveform.shape
        if nx_n < nx_s or nt_n < nt_s:
            return sample
        x0 = random.randint(0, nx_n - nx_s) if nx_n > nx_s else 0
        t0 = random.randint(0, nt_n - nt_s) if nt_n > nt_s else 0
        noise = noise[:, x0:x0 + nx_s, t0:t0 + nt_s]
        N2 = np.std(noise)
        if N2 <= 0:
            return sample
        # Same linear model as self-stacking:
        # After stacking: SNR = S1 / (N1 + r * N2)
        # → r = (S1 / target_snr - N1) / N2
        target_snr = random.uniform(self.min_snr, self.max_snr)
        r = (S1 / target_snr - N1) / N2
        if r <= 0:
            return sample  # original SNR already below target
        sample.waveform = sample.waveform + noise * r
        return sample

    def __repr__(self) -> str:
        return f"StackNoise(min_snr={self.min_snr}, max_snr={self.max_snr}, p={self.p})"


# =============================================================================
# Label Generation
# =============================================================================

def generate_labels(
    sample: Sample,
    config: LabelConfig = LabelConfig(),
) -> dict[str, np.ndarray]:
    """Generate all labels from Sample.targets.

    Iterates over all targets (events) in the sample, accumulating
    Gaussian labels. Naturally handles multi-event windows from stacking.

    Returns:
        All arrays have shape (label_ch, nx, nt) matching the unified format.
        - phase_pick: (3, nx, nt) — [noise, P, S]
        - phase_mask: (1, nx, nt)
        - event_center: (1, nx, nt)
        - event_time: (1, nx, nt)
        - event_center_mask: (1, nx, nt)
        - event_time_mask: (1, nx, nt)
    """
    nx, nt = sample.nx, sample.nt
    sigma = config.phase_width / 6
    sigma_event = config.event_width / 6
    event_mask_w = int(config.event_width * config.mask_width_factor)

    vp = config.vp
    vs = vp / config.vp_vs_ratio

    half_w_phase = int(3 * sigma + 1)
    half_w_event = int(3 * sigma_event + 1)

    # Pre-compute Gaussian templates (avoid repeated np.exp calls)
    phase_template = np.arange(-half_w_phase, half_w_phase + 1, dtype=np.float32)
    phase_template = np.exp(-(phase_template ** 2) / (2 * sigma ** 2))
    phase_template[phase_template < config.gaussian_threshold] = 0.0

    event_template = np.arange(-half_w_event, half_w_event + 1, dtype=np.float32)
    event_template = np.exp(-(event_template ** 2) / (2 * sigma_event ** 2))
    event_template[event_template < config.gaussian_threshold] = 0.0

    # Allocate output arrays directly — (3, nx, nt) for phase_pick avoids
    # separate p_label/s_label/noise_label + np.stack overhead
    phase_pick = np.zeros((3, nx, nt), dtype=np.float32)
    p_label = phase_pick[1]  # views into phase_pick
    s_label = phase_pick[2]
    event_center_label = np.zeros((1, nx, nt), dtype=np.float32)
    event_time_label = np.zeros((1, nx, nt), dtype=np.float32)
    event_center_mask = np.zeros((1, nx, nt), dtype=np.float32)
    event_time_mask = np.zeros((1, nx, nt), dtype=np.float32)
    phase_mask = np.zeros((1, nx, nt), dtype=np.float32)

    def add_phase_picks(picks, label):
        for ch, ti in picks:
            ch = int(ch)
            if 0 <= ch < nx:
                ti_int = int(ti)
                t0 = max(0, ti_int - half_w_phase)
                t1 = min(nt, ti_int + half_w_phase + 1)
                # Slice template to handle boundary clipping
                tmpl_start = t0 - (ti_int - half_w_phase)
                tmpl_end = tmpl_start + (t1 - t0)
                # Adjust for fractional pick time
                frac = ti - ti_int
                if abs(frac) < 0.01:
                    label[ch, t0:t1] += phase_template[tmpl_start:tmpl_end]
                else:
                    local_t = np.arange(t0, t1, dtype=np.float32)
                    g = np.exp(-((local_t - ti) ** 2) / (2 * sigma ** 2))
                    g[g < config.gaussian_threshold] = 0.0
                    label[ch, t0:t1] += g

    for target in sample.targets:
        add_phase_picks(target.p_picks, p_label)
        add_phase_picks(target.s_picks, s_label)

    # Event labels: only for channels with BOTH P and S picks in crop window
    for target in sample.targets:
        p_chs = {int(ch) for ch, _ in target.p_picks}
        s_chs = {int(ch) for ch, _ in target.s_picks}
        for (ch, center), (_, ps_int) in zip(target.ps_centers, target.ps_intervals):
            ch = int(ch)
            if 0 <= ch < nx and ch in p_chs and ch in s_chs:
                center_int = int(center)
                t0e = max(0, center_int - half_w_event)
                t1e = min(nt, center_int + half_w_event + 1)
                frac = center - center_int
                if abs(frac) < 0.01:
                    tmpl_start = t0e - (center_int - half_w_event)
                    tmpl_end = tmpl_start + (t1e - t0e)
                    event_center_label[0, ch, t0e:t1e] += event_template[tmpl_start:tmpl_end]
                else:
                    t_local = np.arange(t0e, t1e, dtype=np.float32)
                    g = np.exp(-((t_local - center) ** 2) / (2 * sigma_event ** 2))
                    g[g < config.gaussian_threshold] = 0.0
                    event_center_label[0, ch, t0e:t1e] += g

                # shift in samples — dt_s cancels out algebraically
                shift = ps_int * (vp + vs) / (2 * (vp - vs))

                # Windowed mask covering [P - 0.5(S-P) - ext, S + 0.5(S-P) + ext]
                p_time = center - ps_int / 2
                s_time = center + ps_int / 2
                ext = int(0.5 * ps_int) + 300
                cm_t0 = max(0, int(p_time) - ext)
                cm_t1 = min(nt, int(s_time) + ext)
                event_center_mask[0, ch, cm_t0:cm_t1] = 1.0

                t0 = max(0, int(center) - event_mask_w)
                t1 = min(nt, int(center) + event_mask_w)
                event_time_mask[0, ch, t0:t1] = 1.0
                t_range = np.arange(t0, t1, dtype=np.float32)
                event_time_label[0, ch, t0:t1] = (t_range - center) + shift

    # Phase mask: only for channels with BOTH P and S picks per event.
    # Single-event → full trace mask.
    # Multi-event → windowed mask around each P-S interval.
    ps_intervals_per_ch: dict[int, list[tuple[float, float]]] = {}
    for target in sample.targets:
        p_chs = {int(ch) for ch, _ in target.p_picks}
        s_chs = {int(ch) for ch, _ in target.s_picks}
        for (ch, center), (_, ps_int) in zip(target.ps_centers, target.ps_intervals):
            ch = int(ch)
            if 0 <= ch < nx and ch in p_chs and ch in s_chs:
                p_time = center - ps_int / 2
                s_time = center + ps_int / 2
                ps_intervals_per_ch.setdefault(ch, []).append((p_time, s_time))

    is_single_event = (
        not ps_intervals_per_ch
        or max(len(v) for v in ps_intervals_per_ch.values()) <= 1
    )

    for ch, intervals in ps_intervals_per_ch.items():
        if is_single_event:
            phase_mask[0, ch, :] = 1.0
        else:
            for p_time, s_time in intervals:
                ext = int(0.5 * (s_time - p_time)) + 300
                t0 = max(0, int(p_time) - ext)
                t1 = min(nt, int(s_time) + ext)
                phase_mask[0, ch, t0:t1] = 1.0

    # event_center_mask: single-event → full trace for all event channels
    if is_single_event:
        for ch in ps_intervals_per_ch:
            event_center_mask[0, ch, :] = 1.0

    # Compute noise label in-place: noise = max(0, 1 - P - S)
    phase_pick[0] = 1.0
    phase_pick[0] -= p_label
    phase_pick[0] -= s_label
    np.maximum(phase_pick[0], 0, out=phase_pick[0])

    return {
        "phase_pick": phase_pick,  # (3, nx, nt)
        "phase_mask": phase_mask,  # (1, nx, nt)
        "event_center": event_center_label,  # (1, nx, nt)
        "event_time": event_time_label,  # (1, nx, nt)
        "event_center_mask": event_center_mask,  # (1, nx, nt)
        "event_time_mask": event_time_mask,  # (1, nx, nt)
    }


# =============================================================================
# Default Transform Presets
# =============================================================================

def default_train_transforms(
    nt: int = 4096,
    nx: int = 2048,
    enable_stacking: bool = False,
    enable_self_stacking: bool = True,
    enable_noise_stacking: bool = True,
    enable_resample_time: bool = True,
    enable_resample_space: bool = False,
    enable_masking: bool = True,
    enable_colored_noise: bool = False,
    enable_bandpass: bool = False,
    augment: bool = True,
) -> Compose:
    """Default transforms for DAS training.

    When augment=False, only Normalize + RandomCrop are applied (for overfit testing).
    """
    # Note: load_sample_from_h5 already normalizes (std + demean), so we
    # crop FIRST to avoid normalizing the full 1.5 GB waveform (~6s → 0.02s).
    if not augment:
        return Compose([RandomCrop(nt=nt, nx=nx), Normalize()])

    transforms = []

    # ResampleTime and ResampleSpace are applied per-sample (not per-patch)
    # in _sample_training. Only one is applied at a time.

    if enable_stacking:
        transforms.append(StackEvents(max_events=1, max_shift=2048, p=0.3, allow_overlap="full"))

    transforms.append(RandomCrop(nt=nt, nx=nx, stack_self=enable_self_stacking))

    if enable_noise_stacking:
        transforms.append(StackNoise(min_snr=1.0, max_snr=5.0, p=0.5))

    if enable_colored_noise:
        transforms.append(ColoredNoise(snr_db_range=(5, 30), p=0.5))

    transforms.append(FlipLR(p=0.5))

    if enable_masking:
        transforms.append(Masking(max_mask_nt=256, p=0.2))

    if enable_bandpass:
        transforms.append(RandomBandpass(p=0.3))

    transforms.extend([
        MedianFilter(p=0.5),
        Normalize(),  # Final normalization
    ])

    return Compose(transforms)


def default_eval_transforms() -> Compose:
    """Default transforms for DAS evaluation."""
    return Compose([Normalize()])


def minimal_transforms() -> Compose:
    """Minimal transforms - just normalize."""
    return Compose([Normalize()])


def _ds_event_np(arr, s):
    """Downsample event labels using numpy: max-pool along nx, stride along nt.

    Replaces torch F.max_pool2d (CPU) to avoid numpy→torch→numpy conversion overhead.
    """
    # arr: (1, nx, nt)
    _, nx, nt = arr.shape
    nx_trim = (nx // s) * s
    # Reshape to group s channels, take max within each group
    pooled = arr[:, :nx_trim, :].reshape(1, nx_trim // s, s, nt).max(axis=2)  # (1, nx//s, nt)
    # Stride along nt
    return pooled[:, :, ::s]


def _to_output(
    sample: Sample,
    label_config: LabelConfig,
    event_feature_scale: int,
) -> dict[str, torch.Tensor]:
    """Convert transformed Sample to output dict with labels."""
    labels = generate_labels(sample, label_config)
    s = event_feature_scale

    return {
        "data": torch.nan_to_num(torch.from_numpy(np.ascontiguousarray(sample.waveform)).float()),
        "phase_pick": torch.from_numpy(labels["phase_pick"]).float(),
        "phase_mask": torch.from_numpy(labels["phase_mask"]).float(),
        "event_center": torch.from_numpy(np.ascontiguousarray(_ds_event_np(labels["event_center"], s))).float(),
        "event_time": torch.from_numpy(np.ascontiguousarray(_ds_event_np(labels["event_time"], s))).float(),
        "event_center_mask": torch.from_numpy(np.ascontiguousarray(_ds_event_np(labels["event_center_mask"], s))).float(),
        "event_time_mask": torch.from_numpy(np.ascontiguousarray(_ds_event_np(labels["event_time_mask"], s))).float(),
        "file_name": sample.file_name,
        "height": sample.waveform.shape[-2],
        "width": sample.waveform.shape[-1],
        "dt_s": sample.dt_s,
        "dx_m": sample.dx_m,
    }


# =============================================================================
# GCS Utilities
# =============================================================================

def get_gcs_storage_options() -> dict:
    """Load GCS credentials for authenticated access."""
    if os.path.exists(GCS_CREDENTIALS_PATH):
        with open(GCS_CREDENTIALS_PATH, "r") as f:
            token = json.load(f)
        return {"token": token}
    return {}


def get_filesystem(path: str):
    """Get appropriate filesystem for the given path."""
    if path.startswith("gs://"):
        storage_options = get_gcs_storage_options()
        fs = fsspec.filesystem("gcs", **storage_options)
        path_clean = path[5:]
        return fs, path_clean
    else:
        fs = fsspec.filesystem("file")
        return fs, path


def open_file(path: str, mode: str = "rb"):
    """Open a file from local or GCS path."""
    if path.startswith("gs://"):
        storage_options = get_gcs_storage_options()
        return fsspec.open(path, mode, **storage_options)
    else:
        return fsspec.open(path, mode)


# =============================================================================
# Data Loading Utilities
# =============================================================================

def calc_snr(
    data: np.ndarray,
    picks: list[tuple[int, float]],
    noise_window: int = 300,
    signal_window: int = 300,
    gap_window: int = 50,
) -> tuple[float, float, float]:
    """Calculate SNR from waveform and picks.

    Uses a gap window around the pick to avoid Gaussian label bleed.

    Args:
        data: Waveform array (nch, nx, nt)
        picks: List of (channel_index, time_index) tuples
        noise_window: Samples before pick for noise estimation
        signal_window: Samples after pick for signal estimation
        gap_window: Gap around pick to exclude from both windows

    Returns:
        (snr, signal_std, noise_std)
    """
    nch, nx, nt = data.shape

    snrs, signals, noises = [], [], []
    for ch, phase_time in picks:
        ch = int(ch)
        phase_time = int(phase_time)
        if 0 <= ch < nx and gap_window < phase_time < nt - gap_window:
            for c in range(nch):
                noise = np.std(data[c, ch, max(0, phase_time - noise_window):phase_time - gap_window])
                signal = np.std(data[c, ch, phase_time + gap_window:phase_time + signal_window])
                if noise > 0 and signal > 0:
                    snrs.append(signal / noise)
                    signals.append(signal)
                    noises.append(noise)

    if not snrs:
        return 0.0, 0.0, 0.0

    idx = np.argmax(snrs)
    return float(snrs[idx]), float(signals[idx]), float(noises[idx])


def read_PASSCAL_segy(fid, nTraces=1250, nSample=900000, TraceOff=0, strain_rate=True):
    """Read PASSCAL segy raw data.

    For Ridgecrest data: 1250 channels, sampling rate 250 Hz.
    Author: Jiuxun Yin
    Source: https://github.com/SCEDC/cloud/blob/master/pds_ridgecrest_das.ipynb
    """
    fs = nSample / 3600
    data = np.zeros((nTraces, nSample), dtype=np.float32)

    fid.seek(3600)
    fid.seek(TraceOff * (240 + nSample * 4), 1)
    for ii in range(nTraces):
        fid.seek(240, 1)
        bytes = fid.read(nSample * 4)
        data[ii, :] = np.frombuffer(bytes, dtype=np.float32)

    fid.close()

    Ridgecrest_conversion_factor = 1550.12 / (0.78 * 4 * np.pi * 1.46 * 8)
    data = data * Ridgecrest_conversion_factor

    if strain_rate:
        data = np.gradient(data, axis=1) * fs

    return data


def padding(data: torch.Tensor, min_nx: int = 256, min_nt: int = 256) -> torch.Tensor:
    """Pad data to multiples of min_nx and min_nt.

    Args:
        data: Tensor of shape (nch, nx, nt)
        min_nx: Minimum space samples (pads to multiple)
        min_nt: Minimum time samples (pads to multiple)

    Returns:
        Padded tensor
    """
    nch, nx, nt = data.shape
    pad_nx = (min_nx - nx % min_nx) % min_nx
    pad_nt = (min_nt - nt % min_nt) % min_nt

    if pad_nt > 0 or pad_nx > 0:
        with torch.no_grad():
            # F.pad for 3D: (last_right, last_left, second_last_right, second_last_left)
            data = F.pad(data, (0, pad_nt, 0, pad_nx), mode="constant")

    return data


def load_sample_from_h5(
    file_path: str,
    picks_df: pd.DataFrame | None = None,
    phases: list[str] = ["P", "S"],
) -> Sample:
    """Load a Sample from an HDF5 file.

    Args:
        file_path: Path to H5 file (local or GCS)
        picks_df: DataFrame with picks (channel_index, phase_index, phase_type)
        phases: Phase types to extract

    Returns:
        Sample instance with waveform shape (1, nx, nt)
    """
    with open_file(file_path, "rb") as f:
        with h5py.File(f, "r") as fp:
            data = fp["data"][:, :]  # (nx, nt) — keep native ordering
            dt_s = fp["data"].attrs.get("dt_s", 0.01)
            dx_m = fp["data"].attrs.get("dx_m", 10.0)

    data = data[np.newaxis, :, :]  # (1, nx, nt)
    data = data / (np.std(data) + 1e-10)
    data = data - np.mean(data, axis=-1, keepdims=True)  # demean along time

    p_picks = []
    s_picks = []
    ps_centers = []
    ps_intervals = []

    if picks_df is not None:
        if "channel_index" not in picks_df.columns and "station_id" in picks_df.columns:
            picks_df = picks_df.rename(columns={"station_id": "channel_index"})

        for phase in phases:
            phase_picks = picks_df[picks_df["phase_type"] == phase][
                ["channel_index", "phase_index"]
            ].values.tolist()
            phase_picks = [(int(ch), float(t)) for ch, t in phase_picks]

            if phase == "P":
                p_picks = phase_picks
            elif phase == "S":
                s_picks = phase_picks

        # Compute event centers from P and S picks
        if p_picks and s_picks:
            p_dict = {ch: t for ch, t in p_picks}
            s_dict = {ch: t for ch, t in s_picks}
            for ch in set(p_dict.keys()) & set(s_dict.keys()):
                center = (p_dict[ch] + s_dict[ch]) / 2
                ps_int = s_dict[ch] - p_dict[ch]
                ps_centers.append((ch, center))
                ps_intervals.append((ch, ps_int))

    target = Target(
        p_picks=p_picks,
        s_picks=s_picks,
        ps_centers=ps_centers,
        ps_intervals=ps_intervals,
    )

    return Sample(
        waveform=data.astype(np.float32),
        targets=[target] if not target.is_empty else [],
        dt_s=dt_s,
        dx_m=dx_m,
        file_name=os.path.basename(file_path),
    )


# =============================================================================
# Dataset Classes
# =============================================================================

class DASIterableDataset(IterableDataset):
    """DAS Iterable Dataset supporting local and GCS paths.

    For training, uses the transform pipeline with Sample dataclass.
    For inference, handles multiple data formats (h5, npz, npy, segy).

    Args:
        data_path: Local path or GCS path (gs://...) to data directory
        data_list: List of data files or path to file containing list
        format: Data format ("h5", "npz", "npy", "segy")
        prefix: File prefix filter
        suffix: File suffix filter
        nt: Number of time samples per patch
        nx: Number of space samples per patch
        min_nt: Minimum time samples for padding
        min_nx: Minimum space samples for padding
        training: Whether in training mode
        phases: Phase types to use (e.g., ["P", "S"])
        label_path: Local path or GCS path to labels directory
        subdir: Subdirectory depth for label->data path conversion
        label_list: List of label files or path to file containing list
        noise_list: List of noise files for augmentation
        transforms: Transform pipeline (overrides individual augmentation flags)
        label_config: Configuration for label generation
        buffer_size: Size of sample buffer for stacking
        skip_existing: Skip files with existing picks
        pick_path: Path to save/check picks
        folder_depth: Parent folder depth for pick_path
        num_patch: Number of patches per sample
        highpass_filter: Highpass filter frequency
        system: DAS system type ("optasense" or None)
        cut_patch: Whether to cut into patches
        event_feature_scale: Downsampling factor for event labels
        rank: Worker rank for distributed training
        world_size: Total workers for distributed training
    """

    def __init__(
        self,
        data_path="./",
        data_list=None,
        format="h5",
        prefix="",
        suffix="",
        nt=1024 * 3,
        nx=1024 * 5,
        min_nt=256,
        min_nx=256,
        # Training
        training=False,
        phases=["P", "S"],
        label_path="./",
        subdir=3,
        label_list=None,
        noise_list=None,
        transforms: Transform | None = None,
        label_config: LabelConfig = LabelConfig(),
        buffer_size: int = 100,
        # Overfit mode: "fixed" (same crop), "random" (different crops), or None
        overfit: str | None = None,
        # Inference
        skip_existing=False,
        pick_path="./",
        folder_depth=1,
        num_patch=2,
        highpass_filter=0.0,
        system=None,
        cut_patch=False,
        resample_time=False,
        event_feature_scale: int = 16,
        rank=0,
        world_size=1,
        **kwargs,
    ):
        super().__init__()
        self.rank = rank
        self.world_size = world_size
        self.data_path = data_path
        self.format = format
        self.prefix = prefix
        self.suffix = suffix
        self.subdir = subdir
        self.label_path = label_path
        self.use_gcs = data_path.startswith("gs://") if data_path else False

        # Load data list
        if data_list is not None:
            if isinstance(data_list, list):
                self.data_list = []
                for data_list_ in data_list:
                    self.data_list += self._read_text_file(data_list_).rstrip("\n").split("\n")
            else:
                self.data_list = self._read_text_file(data_list).rstrip("\n").split("\n")
        else:
            self.data_list = self._list_files(self.data_path, f"{prefix}*{suffix}.{format}")

        if not training:
            self.data_list = self.data_list[rank::world_size]

        # Continuous data / inference
        self.system = system
        self.cut_patch = cut_patch
        self.resample_time = resample_time
        self.dt = kwargs.get("dt", 0.01)
        self.dx = kwargs.get("dx", 10.0)
        self.nt = nt
        self.nx = nx
        self.min_nt = min_nt
        self.min_nx = min_nx
        assert self.nt % self.min_nt == 0
        assert self.nx % self.min_nx == 0

        # Training
        self.training = training
        self.phases = phases
        self.label_config = label_config
        self.num_patch = num_patch
        self.overfit = overfit
        self.event_feature_scale = event_feature_scale
        self.highpass_filter = highpass_filter
        self.skip_existing = skip_existing
        self.pick_path = pick_path
        self.folder_depth = folder_depth

        # Load label list
        if label_list is not None:
            if isinstance(label_list, list):
                self.label_list = []
                for label_list_ in label_list:
                    self.label_list += self._read_text_file(label_list_).rstrip("\n").split("\n")
            else:
                self.label_list = self._read_text_file(label_list).rstrip("\n").split("\n")
            if training:
                self.label_list = self.label_list[: len(self.label_list) // world_size * world_size]
            self.label_list = self.label_list[rank::world_size]
        else:
            self.label_list = self._list_files(self.label_path, "*.csv") + self._list_files(self.label_path, "*.parquet")

        # Noise list for stacking
        self.noise_list = None
        if noise_list is not None:
            if isinstance(noise_list, list):
                self.noise_list = []
                for noise_list_ in noise_list:
                    self.noise_list += self._read_text_file(noise_list_).rstrip("\n").split("\n")
            else:
                self.noise_list = self._read_text_file(noise_list).rstrip("\n").split("\n")

        # Transforms
        if transforms is not None:
            self.transforms = transforms
        elif training:
            self.transforms = default_train_transforms(nt=nt, nx=nx)
        else:
            self.transforms = default_eval_transforms()

        # Per-sample resampling (applied once per sample, not per patch)
        # Only one of time/space is applied at a time
        self.resample_time = ResampleTime(0.3, 3.0) if training else None
        self.resample_space = ResampleSpace(0.3, 3.0) if training else None

        # Sample buffer for stacking
        self.sample_buffer = SampleBuffer(buffer_size)
        self._setup_stacking_transforms()

        if self.training:
            print(f"DASIterableDataset: {len(self.label_list)} label files")
        else:
            print(f"DASIterableDataset: {len(self.data_list)} data files")


    def _setup_stacking_transforms(self):
        """Connect stacking transforms to sample buffer and noise loader."""
        if not isinstance(self.transforms, Compose):
            return
        for t in self.transforms.transforms:
            if isinstance(t, StackEvents):
                t.set_sample_fn(self.sample_buffer.get_random)
            elif isinstance(t, StackNoise):
                if self.noise_list:
                    t.set_noise_fn(self._load_random_noise)
                else:
                    t.set_noise_fn(self._crop_noise_from_signal)
                t.set_sample_fn(self.sample_buffer.get_random)

    def _crop_noise_from_signal(self) -> np.ndarray | None:
        """Crop a noise window from a cached signal sample.

        Detects events via origin_index histogram (median + 20*MAD threshold),
        then uses median ps_center/ps_interval to define signal windows:
          [median(ps_center) - median(ps_interval) - margin,
           median(ps_center) + 3 * median(ps_interval) + margin]
        Crops from time ranges outside all signal windows.
        """
        donor = self.sample_buffer.get_random()
        if donor is None:
            return None
        nt = donor.waveform.shape[-1]
        nt_crop = self.nt
        if nt < nt_crop:
            return None

        margin = 500
        bin_size = 200
        windows = []

        if donor.all_origin_times and donor.all_ps_centers:
            # Histogram of origin_index to detect events
            origin_arr = np.array(donor.all_origin_times)
            bins = np.arange(0, nt + bin_size, bin_size)
            counts, edges = np.histogram(origin_arr, bins=bins)
            median_c = np.median(counts)
            mad_c = np.median(np.abs(counts - median_c))
            threshold = max(median_c + 20 * mad_c, 10)
            hot = np.where(counts >= threshold)[0]

            # Merge hot bins into origin windows
            origin_windows = []
            if len(hot) > 0:
                start, end = int(edges[hot[0]]), int(edges[hot[0] + 1])
                for i in hot[1:]:
                    if int(edges[i]) <= end + bin_size:
                        end = int(edges[i + 1])
                    else:
                        origin_windows.append((start, end))
                        start, end = int(edges[i]), int(edges[i + 1])
                origin_windows.append((start, end))

            # Convert each origin window to signal window via median ps_center/ps_interval
            ps_c_arr = np.array(donor.all_ps_centers)
            ps_i_arr = np.array(donor.all_ps_intervals)
            for ow_start, ow_end in origin_windows:
                mask = (origin_arr >= ow_start) & (origin_arr <= ow_end)
                # Match by index — origin_times and ps_centers have same length
                idx = np.where(mask)[0]
                valid = idx[idx < len(ps_c_arr)]
                pc = ps_c_arr[valid] if len(valid) > 0 else np.array([])
                pi = ps_i_arr[valid] if len(valid) > 0 else np.array([])
                pc = pc[~np.isnan(pc)]
                pi = pi[~np.isnan(pi)]
                if len(pc) == 0 or len(pi) == 0:
                    windows.append((max(0, ow_start - margin), min(nt, ow_end + 1000)))
                    continue
                med_c = float(np.median(pc))
                med_i = float(np.median(pi))
                win_start = int(med_c - med_i) - margin
                win_end = int(med_c + 3 * med_i) + margin
                windows.append((max(0, win_start), min(nt, win_end)))
        else:
            # Fallback: use target picks directly
            for tgt in donor.targets:
                times = tgt.all_times()
                if times:
                    windows.append((max(0, int(min(times)) - margin),
                                    min(nt, int(max(times)) + margin)))

        if not windows:
            t0 = random.randint(0, nt - nt_crop)
            return donor.waveform[..., t0:t0 + nt_crop]

        # Merge overlapping windows
        windows.sort()
        merged = [windows[0]]
        for s, e in windows[1:]:
            if s <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], e))
            else:
                merged.append((s, e))

        # Find free gaps large enough for nt_crop
        gaps = []
        prev_end = 0
        for s, e in merged:
            if s - prev_end >= nt_crop:
                gaps.append((prev_end, s))
            prev_end = e
        if nt - prev_end >= nt_crop:
            gaps.append((prev_end, nt))

        if not gaps:
            return None
        gap_start, gap_end = random.choice(gaps)
        t0 = random.randint(gap_start, gap_end - nt_crop)
        return donor.waveform[..., t0:t0 + nt_crop]

    def _load_random_noise(self) -> np.ndarray | None:
        """Load a random noise file for stacking (cached after first load)."""
        if not self.noise_list:
            return None
        if not hasattr(self, '_noise_cache'):
            self._noise_cache = {}
        noise_file = self.noise_list[random.randint(0, len(self.noise_list) - 1)]
        if noise_file in self._noise_cache:
            return self._noise_cache[noise_file]
        noise_path = self._construct_file_path(self.data_path, noise_file)
        try:
            with open_file(noise_path, "rb") as f:
                with h5py.File(f, "r") as fp:
                    noise = fp["data"][:, :]  # (nx, nt) — keep native ordering
                noise = noise[np.newaxis, :, :].astype(np.float32)  # (1, nx, nt)
                self._noise_cache[noise_file] = noise
                return noise
        except Exception as e:
            print(f"Error reading noise file {noise_path}: {e}")
            return None

    def _list_files(self, path: str, pattern: str) -> list[str]:
        """List files matching pattern from local or GCS path."""
        if path.startswith("gs://"):
            fs, path_clean = get_filesystem(path)
            files = fs.glob(f"{path_clean}/{pattern}")
            return [f"gs://{f}" for f in files]
        else:
            return glob(os.path.join(path, pattern))

    @staticmethod
    def _read_text_file(file_path: str) -> str:
        """Read text file from local or GCS."""
        if file_path.startswith("gs://"):
            fs = fsspec.filesystem("gcs", **get_gcs_storage_options())
            with fs.open(file_path, "r") as f:
                return f.read()
        else:
            with open(file_path, "r") as f:
                return f.read()

    def _read_picks(self, file_path: str) -> pd.DataFrame:
        """Read pick file (CSV or parquet) from local or GCS."""
        if file_path.startswith("gs://"):
            storage_options = get_gcs_storage_options()
            if file_path.endswith(".parquet"):
                return pd.read_parquet(file_path, storage_options=storage_options)
            return pd.read_csv(file_path, storage_options=storage_options)
        if file_path.endswith(".parquet"):
            return pd.read_parquet(file_path)
        return pd.read_csv(file_path)

    def _construct_file_path(self, base_path: str, relative_path: str) -> str:
        """Construct full file path preserving GCS prefix."""
        if base_path.startswith("gs://"):
            return f"{base_path.rstrip('/')}/{relative_path.lstrip('/')}"
        else:
            return os.path.join(base_path, relative_path)

    def _load_sample(self, label_file: str) -> Sample | None:
        """Load a training sample.

        Accepts:
          - "data.h5,label.parquet" — comma-separated full paths (legacy)
          - "file_id" — bare file ID (e.g. 20221223T085557Z), resolved as:
              data:  {data_path}/{file_id}.h5
              label: {label_path}/{file_id}.parquet

        When picks have an origin_id column, only associated picks (origin_id >= 0)
        are used as training targets. All pick times are stored on the Sample for
        noise window exclusion.
        """
        if "," in label_file:
            data_path_full, label_path_full = label_file.split(",", 1)
        else:
            file_id = os.path.splitext(label_file.strip())[0]
            data_path_full = os.path.join(self.data_path, f"{file_id}.h5")
            label_path_full = os.path.join(self.label_path, f"{file_id}.parquet")

        picks_df = self._read_picks(label_path_full)
        if "channel_index" not in picks_df.columns:
            picks_df = picks_df.rename(columns={"station_id": "channel_index"})

        # Collect all pick/origin info for noise window exclusion (before filtering)
        all_pick_times = picks_df["phase_index"].dropna().astype(float).tolist()
        # Collect origin/ps info from rows that have all three (aligned)
        has_all = ["origin_index", "ps_center", "ps_interval"]
        if all(c in picks_df.columns for c in has_all):
            valid = picks_df.dropna(subset=has_all)
            all_origin_times = valid["origin_index"].astype(float).tolist()
            all_ps_centers = valid["ps_center"].astype(float).tolist()
            all_ps_intervals = valid["ps_interval"].astype(float).tolist()
        else:
            all_origin_times, all_ps_centers, all_ps_intervals = [], [], []

        # Filter to associated picks for training targets
        if "origin_id" in picks_df.columns:
            picks_df = picks_df[picks_df["origin_id"] >= 0]

        try:
            sample = load_sample_from_h5(data_path_full, picks_df, self.phases)
        except Exception as e:
            print(f"Error reading {data_path_full}: {e}")
            return None

        sample.all_pick_times = all_pick_times
        sample.all_origin_times = all_origin_times
        sample.all_ps_centers = all_ps_centers
        sample.all_ps_intervals = all_ps_intervals

        # Calculate SNR for the target
        if sample.targets:
            target = sample.targets[0]
            if target.p_picks:
                target.snr, target.amp_signal, target.amp_noise = calc_snr(
                    sample.waveform, target.p_picks
                )

        sample.file_name = os.path.splitext(label_file.split("/")[-1])[0]
        return sample

    def _sample_to_output(self, sample: Sample) -> dict[str, torch.Tensor]:
        return _to_output(sample, self.label_config, self.event_feature_scale)

    def _count(self):
        if self.training:
            return len(self.label_list) * self.num_patch

        if not self.cut_patch:
            return len(self.data_list)
        else:
            if self.format == "h5":
                with open_file(self.data_list[0], "rb") as fs:
                    with h5py.File(fs, "r") as meta:
                        if self.system == "optasense":
                            attrs = {}
                            if "Data" in meta:
                                nx, nt = meta["Data"].shape
                                attrs["dt_s"] = meta["Data"].attrs["dt"]
                                attrs["dx_m"] = meta["Data"].attrs["dCh"]
                            else:
                                nx, nt = meta["Acquisition/Raw[0]/RawData"].shape
                                dx = meta["Acquisition"].attrs["SpatialSamplingInterval"]
                                fs_rate = meta["Acquisition/Raw[0]"].attrs["OutputDataRate"]
                                attrs["dx_m"] = dx
                                attrs["dt_s"] = 1.0 / fs_rate
                        else:
                            nx, nt = meta["data"].shape
                            attrs = dict(meta["data"].attrs)
                if self.resample_time and ("dt_s" in attrs):
                    if (attrs["dt_s"] != 0.01) and (int(round(1.0 / attrs["dt_s"])) % 100 == 0):
                        nt = int(nt / round(0.01 / attrs["dt_s"]))

            elif self.format == "segy":
                print("Start reading segy file")
                with open_file(self.data_list[0], "rb") as fs:
                    nx, nt = read_PASSCAL_segy(fs).shape
                print("End reading segy file")
            else:
                raise ValueError("Unknown dataset")

            return len(self.data_list) * ((nt - 1) // self.nt + 1) * ((nx - 1) // self.nx + 1)

    def __iter__(self):
        worker_info = torch.utils.data.get_worker_info()
        if worker_info is None:
            num_workers = 1
            worker_id = 0
        else:
            num_workers = worker_info.num_workers
            worker_id = worker_info.id

        if self.training:
            # Allow more workers than files: wrap around so each worker gets
            # at least one file, enabling higher prefetch parallelism
            n_files = len(self.label_list)
            if num_workers > n_files:
                # Each worker gets the file at (worker_id % n_files)
                worker_files = [self.label_list[worker_id % n_files]]
            else:
                worker_files = self.label_list[worker_id::num_workers]
            return iter(self._sample_training(worker_files))
        else:
            return iter(self._sample_inference(self.data_list[worker_id::num_workers]))

    def _sample_training(self, file_list):
        """Training sample generator using transform pipeline.

        Caches loaded samples in memory after the first epoch to avoid
        repeated H5 file reads (~10s per file → ~0s from cache).
        """
        cache = {}
        while True:
            file_list = np.random.permutation(file_list)
            for label_file in file_list:
                if label_file in cache:
                    sample = cache[label_file]
                else:
                    sample = self._load_sample(label_file)
                    if sample is None:
                        continue
                    cache[label_file] = sample

                # Add to buffer for stacking transforms
                self.sample_buffer.add(sample)

                # Resample once per sample (not per patch) for efficiency
                # 50% no resample, 25% time, 25% space — never both
                # Shallow copy is safe: ResampleTime/Space replace waveform
                # (via F.interpolate) rather than modifying in-place.
                resampled = sample
                r = random.random()
                if r < 0.25 and self.resample_time is not None:
                    resampled = sample.copy(deep_waveform=False)
                    resampled = self.resample_time(resampled)
                elif r < 0.50 and self.resample_space is not None:
                    resampled = sample.copy(deep_waveform=False)
                    resampled = self.resample_space(resampled)

                for ii in range(self.num_patch):
                    # ~10% chance: yield a pure noise crop for negative training
                    if random.random() < 0.1:
                        noise = self._crop_noise_from_signal()
                        if noise is not None and noise.shape[-1] >= self.nt and noise.shape[-2] >= self.nx:
                            noise_crop = noise[:, :self.nx, :self.nt]
                            noise_sample = Sample(
                                waveform=noise_crop, targets=[],
                                dt_s=sample.dt_s, file_name=sample.file_name,
                            )
                            noise_sample = Normalize()(noise_sample)
                            output = self._sample_to_output(noise_sample)
                            # Predict "no picks" and "no event center" everywhere
                            output["phase_mask"] = torch.ones_like(output["phase_mask"])
                            output["event_center_mask"] = torch.ones_like(output["event_center_mask"])
                            # event_time_mask stays zero — no origin time to regress
                            output["file_name"] = sample.file_name + f"_{ii:02d}_noise"
                            yield output
                            continue
                    for _retry in range(10):
                        s = resampled.copy(deep_waveform=False)
                        s = self.transforms(s)
                        output = self._sample_to_output(s)
                        # Skip crops where event center mask covers < 2%
                        if output["event_center_mask"].mean() >= 0.02:
                            break
                    output["file_name"] = sample.file_name + f"_{ii:02d}"
                    yield output

    def _sample_inference(self, file_list):
        """Inference sample generator supporting multiple formats."""
        for file in file_list:
            if not self.cut_patch:
                existing = self._check_existing(file)
                if self.skip_existing and existing:
                    print(f"Skip existing file {file}")
                    continue

            meta = {}

            if self.format == "npz":
                with open_file(file, "rb") as f:
                    data = np.load(f)["data"]
            elif self.format == "npy":
                with open_file(file, "rb") as f:
                    data = np.load(f)  # (nx, nt)
                meta["begin_time"] = datetime.fromisoformat("1970-01-01 00:00:00")
                meta["dt_s"] = 0.01
                meta["dx_m"] = 10.0
            elif self.format == "h5" and self.system is None:
                with open_file(file, "rb") as fs:
                    with h5py.File(fs, "r") as fp:
                        dataset = fp["data"]
                        data = dataset[()]
                        if "begin_time" in dataset.attrs:
                            meta["begin_time"] = datetime.fromisoformat(
                                dataset.attrs["begin_time"].rstrip("Z")
                            )
                        meta["dt_s"] = dataset.attrs.get("dt_s", self.dt)
                        meta["dx_m"] = dataset.attrs.get("dx_m", self.dx)
            elif self.format == "h5" and self.system == "optasense":
                with open_file(file, "rb") as fs:
                    with h5py.File(fs, "r") as fp:
                        if "Data" in fp:
                            dataset = fp["Data"]
                            meta["begin_time"] = datetime.fromisoformat(
                                dataset.attrs["startTime"].rstrip("Z")
                            )
                            meta["dt_s"] = dataset.attrs["dt"]
                            meta["dx_m"] = dataset.attrs["dCh"]
                        else:
                            dataset = fp["Acquisition/Raw[0]/RawData"]
                            dx = fp["Acquisition"].attrs["SpatialSamplingInterval"]
                            fs_rate = fp["Acquisition/Raw[0]"].attrs["OutputDataRate"]
                            begin_time = dataset.attrs["PartStartTime"].decode()
                            meta["dx_m"] = dx
                            meta["dt_s"] = 1.0 / fs_rate
                            meta["begin_time"] = datetime.fromisoformat(begin_time.rstrip("Z"))

                        nx, nt = dataset.shape
                        meta["nx"] = nx
                        meta["nt"] = nt

                        existing = self._check_existing(file, meta)
                        if self.skip_existing and existing:
                            print(f"Skip existing file {file}")
                            continue

                        data = dataset[()]
                        data = np.gradient(data, axis=-1, edge_order=2) / meta["dt_s"]
            elif self.format == "segy":
                with open_file(file, "rb") as fs:
                    data = read_PASSCAL_segy(fs)
                meta["begin_time"] = datetime.strptime(
                    file.split("/")[-1].rstrip(".segy"), "%Y%m%d%H"
                )
                meta["dt_s"] = 1.0 / 250.0
                meta["dx_m"] = 8.0
            else:
                raise ValueError(f"Unsupported format: {self.format}")

            # Resample time if needed
            if self.resample_time:
                dt_s = meta.get("dt_s", self.dt)
                if (dt_s != 0.01) and (int(round(1.0 / dt_s)) % 100 == 0):
                    print(f"Resample {file} from time interval {dt_s} to 0.01")
                    data = data[..., :: int(0.01 / dt_s)]
                    meta["dt_s"] = 0.01

            # Preprocessing — data is (nx, nt)
            # Match training Normalize: nan_to_num → demean → median → [highpass] → std
            data = np.asarray(data, dtype=np.float32)
            np.nan_to_num(data, copy=False)
            data -= np.mean(data, axis=-1, keepdims=True)  # demean along time
            data -= np.median(data, axis=-2, keepdims=True)  # common-mode rejection
            if self.highpass_filter:
                b, a = scipy.signal.butter(2, self.highpass_filter, "hp", fs=100)
                data = scipy.signal.filtfilt(b, a, data, axis=-1).astype(np.float32)
            std = np.std(data, axis=-1, keepdims=True)
            np.maximum(std, 1e-10, out=std)
            data /= std

            # (nx, nt) -> (1, nx, nt) — no transpose needed
            data = torch.from_numpy(data[np.newaxis, :, :])

            if not self.cut_patch:
                nx, nt = data.shape[1:]
                data = padding(data, self.min_nx, self.min_nt)

                yield {
                    "data": data,
                    "nt": nt,
                    "nx": nx,
                    "file_name": file,
                    "begin_time": meta["begin_time"].isoformat(timespec="milliseconds"),
                    "begin_time_index": 0,
                    "begin_channel_index": 0,
                    "dt_s": meta.get("dt_s", self.dt),
                    "dx_m": meta.get("dx_m", self.dx),
                }
            else:
                _, nx, nt = data.shape
                for it in range(0, nt, self.nt):
                    for ix in range(0, nx, self.nx):
                        if self.skip_existing:
                            patch_name = (
                                os.path.splitext(file.split("/")[-1])[0] + f"_{it:04d}_{ix:04d}.csv"
                            )
                            if os.path.exists(os.path.join(self.pick_path, patch_name)):
                                print(f"Skip existing file {patch_name}")
                                continue

                        data_patch = data[:, ix:ix + self.nx, it:it + self.nt]
                        _, nx_, nt_ = data_patch.shape
                        data_patch = padding(data_patch, self.min_nx, self.min_nt)

                        yield {
                            "data": data_patch,
                            "nt": nt_,
                            "nx": nx_,
                            "file_name": os.path.splitext(file)[0] + f"_{it:04d}_{ix:04d}",
                            "begin_time": (
                                meta["begin_time"] + timedelta(seconds=it * float(meta["dt_s"]))
                            ).isoformat(timespec="milliseconds"),
                            "begin_time_index": it,
                            "begin_channel_index": ix,
                            "dt_s": meta.get("dt_s", self.dt),
                            "dx_m": meta.get("dx_m", self.dx),
                        }

    def _check_existing(self, file, meta=None):
        """Check if picks already exist for a file."""
        parent_dir = "/".join(file.split("/")[-self.folder_depth:-1])
        existing = True
        if not self.cut_patch:
            path = os.path.join(
                self.pick_path, parent_dir, os.path.splitext(file.split("/")[-1])[0] + ".csv"
            )
            if not os.path.exists(path):
                existing = False
        else:
            nx, nt = meta["nx"], meta["nt"]
            if self.resample_time:
                dt_s = meta.get("dt_s", self.dt)
                if (dt_s != 0.01) and (int(round(1.0 / dt_s)) % 100 == 0):
                    nt = int(nt / round(0.01 / dt_s))
            for i in range(0, nt, self.nt):
                for j in range(0, nx, self.nx):
                    path = os.path.join(
                        self.pick_path, parent_dir,
                        os.path.splitext(file.split("/")[-1])[0] + f"_{i:04d}_{j:04d}.csv",
                    )
                    if not os.path.exists(path):
                        existing = False

        return existing


class DASDataset(Dataset):
    """DAS Map-style Dataset.

    For use with DataLoader when data fits in memory or is pre-downloaded.

    Args:
        data_path: Path to data files (local or GCS)
        label_path: Path to label CSV files
        noise_list: List of noise files for augmentation
        format: Data format ("h5")
        transforms: Transform pipeline
        label_config: Label generation config
        phases: Phase types
        buffer_size: Size of sample buffer for stacking
        event_feature_scale: Downsampling factor for event labels
    """

    def __init__(
        self,
        data_path: str = "./",
        label_path: str | None = None,
        noise_list: list[str] | None = None,
        format: str = "h5",
        prefix: str = "",
        suffix: str = "",
        transforms: Transform | None = None,
        label_config: LabelConfig = LabelConfig(),
        phases: list[str] = ["P", "S"],
        buffer_size: int = 100,
        event_feature_scale: int = 16,
        training: bool = True,
        **kwargs,
    ):
        super().__init__()
        self.data_path = data_path
        self.label_path = label_path
        self.format = format
        self.phases = phases
        self.training = training
        self.label_config = label_config
        self.event_feature_scale = event_feature_scale

        self.transforms = transforms or (default_train_transforms() if training else minimal_transforms())

        # Build file lists
        self.data_list = sorted(glob(os.path.join(data_path, f"{prefix}*{suffix}.{format}")))
        self.label_list = []
        if label_path is not None:
            if isinstance(label_path, list):
                for lp in label_path:
                    self.label_list += sorted(glob(os.path.join(lp, f"{prefix}*{suffix}.csv")))
                    self.label_list += sorted(glob(os.path.join(lp, f"{prefix}*{suffix}.parquet")))
            else:
                self.label_list = sorted(glob(os.path.join(label_path, f"{prefix}*{suffix}.csv")))
                self.label_list += sorted(glob(os.path.join(label_path, f"{prefix}*{suffix}.parquet")))

        # Noise list
        self.noise_list = noise_list

        # Sample buffer for stacking
        self.sample_buffer = SampleBuffer(buffer_size)
        self._setup_stacking_transforms()

        print(f"DASDataset: {len(self.label_list or self.data_list)} samples")

    def _setup_stacking_transforms(self):
        """Connect stacking transforms to sample buffer."""
        if not isinstance(self.transforms, Compose):
            return
        for t in self.transforms.transforms:
            if isinstance(t, StackEvents):
                t.set_sample_fn(self.sample_buffer.get_random)
            elif isinstance(t, StackNoise):
                t.set_sample_fn(self.sample_buffer.get_random)

    def __len__(self) -> int:
        if self.label_list:
            return len(self.label_list)
        return len(self.data_list)

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        if self.training and self.label_list:
            return self._get_training_item(idx)
        else:
            return self._get_inference_item(idx)

    def _get_training_item(self, idx: int) -> dict[str, torch.Tensor]:
        """Load and process a training sample."""
        label_file = self.label_list[idx]
        if label_file.endswith(".parquet"):
            picks_df = pd.read_parquet(label_file)
        else:
            picks_df = pd.read_csv(label_file)
        if "channel_index" not in picks_df.columns:
            picks_df = picks_df.rename(columns={"station_id": "channel_index"})

        # Construct data path from label path
        parts = label_file.split("/")
        parts[-2] = "data"
        parts[-1] = os.path.splitext(parts[-1])[0] + ".h5"
        data_file = "/".join(parts)

        sample = load_sample_from_h5(data_file, picks_df, self.phases)

        # Calculate SNR
        if sample.targets:
            target = sample.targets[0]
            if target.p_picks:
                target.snr, target.amp_signal, target.amp_noise = calc_snr(
                    sample.waveform, target.p_picks
                )

        # Add to buffer for stacking
        self.sample_buffer.add(sample)

        # Apply transforms
        sample = self.transforms(sample)
        sample.file_name = os.path.splitext(os.path.basename(label_file))[0]
        return _to_output(sample, self.label_config, self.event_feature_scale)

    def _get_inference_item(self, idx: int) -> dict[str, torch.Tensor]:
        """Load an inference sample."""
        file = self.data_list[idx]
        meta = {}

        if self.format == "h5":
            with h5py.File(file, "r") as f:
                data = f["data"][()]  # (nx, nt) from H5
                if "begin_time" in f["data"].attrs:
                    meta["begin_time"] = f["data"].attrs["begin_time"]
                meta["dt_s"] = f["data"].attrs.get("dt_s", 0.01)
                meta["dx_m"] = f["data"].attrs.get("dx_m", 10.0)
        elif self.format == "npz":
            data = np.load(file)["data"]  # (nx, nt)
        else:
            raise ValueError(f"Unsupported format: {self.format}")

        # Normalize — data is (nx, nt)
        # Match training Normalize: nan_to_num → demean → median → std
        data = np.asarray(data, dtype=np.float32)
        np.nan_to_num(data, copy=False)
        data -= np.mean(data, axis=-1, keepdims=True)  # demean along time
        data -= np.median(data, axis=-2, keepdims=True)  # common-mode rejection
        std = np.std(data, axis=-1, keepdims=True)
        np.maximum(std, 1e-10, out=std)
        data /= std

        # (nx, nt) -> (1, nx, nt)
        data = torch.from_numpy(data[np.newaxis, :, :])

        return {
            "data": data,
            "file_name": os.path.splitext(os.path.basename(file))[0],
            "height": data.shape[-2],
            "width": data.shape[-1],
            **meta,
        }


# =============================================================================
# Factory Functions
# =============================================================================

def create_train_dataset(
    data_path: str,
    label_path: str,
    label_list: str | list[str] | None = None,
    noise_list: str | list[str] | None = None,
    nt: int = 4096,
    nx: int = 2048,
    phases: list[str] = ["P", "S"],
    transforms: Transform | None = None,
    enable_stacking: bool = True,
    enable_noise_stacking: bool = True,
    enable_resample_time: bool = False,
    enable_resample_space: bool = False,
    enable_masking: bool = True,
    **kwargs,
) -> DASIterableDataset:
    """Create a DAS training dataset with default augmentation."""
    if transforms is None:
        transforms = default_train_transforms(
            nt=nt, nx=nx,
            enable_stacking=enable_stacking,
            enable_noise_stacking=enable_noise_stacking,
            enable_resample_time=enable_resample_time,
            enable_resample_space=enable_resample_space,
            enable_masking=enable_masking,
        )

    return DASIterableDataset(
        data_path=data_path,
        label_path=label_path,
        label_list=label_list,
        noise_list=noise_list,
        nt=nt,
        nx=nx,
        training=True,
        phases=phases,
        transforms=transforms,
        **kwargs,
    )


def create_eval_dataset(
    data_path: str,
    nt: int = 4096,
    nx: int = 2048,
    format: str = "h5",
    system: str | None = None,
    cut_patch: bool = False,
    highpass_filter: float | None = None,
    **kwargs,
) -> DASIterableDataset:
    """Create a DAS evaluation dataset without augmentation."""
    return DASIterableDataset(
        data_path=data_path,
        format=format,
        nt=nt,
        nx=nx,
        training=False,
        system=system,
        cut_patch=cut_patch,
        highpass_filter=highpass_filter,
        transforms=default_eval_transforms(),
        **kwargs,
    )


# =============================================================================
# Main - Demo and Testing
# =============================================================================

def plot_trace(
    sample: Sample,
    labels: dict[str, np.ndarray],
    ch: int,
    title: str = "",
    save_path: str = "das_trace.png",
):
    """Plot a single DAS channel with labels (4-panel vertical stack).

    Layout:
        [1] Waveform (strain rate) with P/S pick lines
        [2] P/S zoom-in (1s waveform at P and S picks, side by side)
        [3] Phase labels + phase_mask
        [4] Event center + event_time + masks
    """
    import matplotlib.pyplot as plt

    nt = sample.nt
    t = np.arange(nt)
    waveform = sample.waveform[0, ch, :]  # (nt,) — (nch, nx, nt)
    one_sec = int(1.0 / sample.dt_s)

    p_times = [ti for tgt in sample.targets for c, ti in tgt.p_picks if int(c) == ch]
    s_times = [ti for tgt in sample.targets for c, ti in tgt.s_picks if int(c) == ch]

    fig, axes = plt.subplots(4, 1, figsize=(12, 8), gridspec_kw={"height_ratios": [2, 1, 1, 1]})

    # [1] Waveform
    ax = axes[0]
    ax.plot(t, waveform, "k", linewidth=0.5)
    for ti in p_times:
        ax.axvline(ti, color="red", alpha=0.5, linewidth=0.8)
    for ti in s_times:
        ax.axvline(ti, color="blue", alpha=0.5, linewidth=0.8)
    ax.set_ylabel("Amplitude")
    ax.set_xlim(0, nt)

    # [2] P/S zoom-in (side by side subplots via insets)
    ax = axes[1]
    ax.set_axis_off()
    for pick_t, color, label, x_pos in [
        (p_times[0] if p_times else None, "red", "P", 0.0),
        (s_times[0] if s_times else None, "blue", "S", 0.52),
    ]:
        if pick_t is None:
            continue
        inset = ax.inset_axes([x_pos, 0.0, 0.46, 1.0])
        t0 = max(0, int(pick_t) - one_sec // 4)
        t1 = min(nt, t0 + one_sec)
        inset.plot(t[t0:t1], waveform[t0:t1], "k", linewidth=0.8)
        inset.axvline(pick_t, color=color, linewidth=1.0, alpha=0.8)
        inset.set_title(f"{label} zoom (t={pick_t:.0f})", fontsize=9)
        inset.tick_params(labelsize=7)

    # [3] Phase labels + mask — labels are (label_ch, nx, nt)
    ax = axes[2]
    ax.plot(t, labels["phase_pick"][1, ch, :], label="P", color="red")
    ax.plot(t, labels["phase_pick"][2, ch, :], label="S", color="blue")
    ax.fill_between(t, labels["phase_mask"][0, ch, :], alpha=0.15, color="green", label="mask")
    ax.set_ylabel("Phase Labels")
    ax.set_ylim(-0.05, 1.1)
    ax.set_xlim(0, nt)
    ax.legend(loc="upper right", fontsize=8)

    # [4] Event center + event_time + masks
    ax = axes[3]
    ax.plot(t, labels["event_center"][0, ch, :], label="Event Center", color="purple")
    ax.fill_between(t, labels["event_center_mask"][0, ch, :], alpha=0.1, color="green", label="Center Mask")
    ax.fill_between(t, labels["event_time_mask"][0, ch, :], alpha=0.2, color="green", label="Time Mask")
    ax.set_ylabel("Event")
    ax.set_xlabel("Time Sample")
    ax.set_xlim(0, nt)
    ax.legend(loc="upper right", fontsize=8)
    ax2 = ax.twinx()
    event_time_ch = labels["event_time"][0, ch, :]
    mask = labels["event_time_mask"][0, ch, :] > 0
    if mask.any():
        ax2.plot(t[mask], event_time_ch[mask], color="orange", linewidth=1.0, alpha=0.7)
        ax2.set_ylabel("Event Time", color="orange")
        ax2.set_ylim(min(0, event_time_ch[mask].min()), None)
    ax2.tick_params(axis="y", labelcolor="orange")

    if title:
        fig.suptitle(title, fontsize=12, fontweight="bold")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_overview(sample: Sample, labels: "dict[str, np.ndarray] | None" = None, title: str = "",
                  save_path: str = "das_overview.png", max_display_px: int = 1000,
                  all_picks: "list[dict] | None" = None,
                  plot_labels: bool = False):
    """Plot a DAS sample overview.

    When plot_labels=False (default): single panel with waveform + picks.
    When plot_labels=True: 2x2 grid with labels.

    Layout (plot_labels=True):
        [1,1] DAS waveform (per-channel normalized)
        [1,2] DAS waveform + P/S picks + per-channel origin time estimates
        [2,1] P/S labels + event center + origin time estimates
        [2,2] Event time (hot_r, absolute value)

    Data is (nch, nx, nt). Display as (nt, nx) — time on y-axis, channel on x-axis.

    Args:
        all_picks: Optional list of pick dicts (from detect_picks). If provided,
            unassociated picks (not in sample.targets) are shown in gray.
    """
    import matplotlib.pyplot as plt

    nx = sample.nx
    nt = sample.nt

    # Downsample large arrays for display performance
    sx = max(1, nx // max_display_px)
    sy = max(1, nt // max_display_px)
    _ds = lambda a: a[::sy, ::sx]  # stride-decimate (nt, nx) — for waveforms

    def _ds_max(a):
        """Block-max downsample (nt, nx) — preserves narrow peaks in labels."""
        nt_a, nx_a = a.shape
        nt_t, nx_t = (nt_a // sy) * sy, (nx_a // sx) * sx
        return a[:nt_t, :nx_t].reshape(nt_t // sy, sy, nx_t // sx, sx).max(axis=(1, 3))

    extent = [0, nx, nt, 0]  # [left, right, bottom, top] — original coords
    imshow_kwargs = dict(aspect="auto", interpolation="nearest", extent=extent)

    wf_raw = sample.waveform[0]  # (nx, nt)
    # # Moving window normalization along time axis (matches ceed.py)
    # _win, _stride = 1024, 256
    # _starts  = np.arange(0, nt, _stride)
    # _centers = np.clip(_starts + _win // 2, 0, nt - 1).astype(float)
    # _t = np.arange(nt, dtype=float)
    # # Per-channel moving window mean: (nx, n_wins)
    # _mean_wins = np.stack(
    #     [wf_raw[:, s:min(s + _win, nt)].mean(axis=1) for s in _starts], axis=1
    # )
    # # Per-channel moving window std (demeaned within window): (nx, n_wins)
    # _std_wins = np.stack([
    #     (wf_raw[:, s:min(s + _win, nt)]
    #      - wf_raw[:, s:min(s + _win, nt)].mean(axis=1, keepdims=True)).std(axis=1)
    #     for s in _starts
    # ], axis=1)
    # # Interpolate mean and std to full time axis: (nx, nt)
    # _mean_full = np.array([np.interp(_t, _centers, _mean_wins[i]) for i in range(nx)])
    # _std_full  = np.array([np.interp(_t, _centers, _std_wins[i])  for i in range(nx)])
    # wf_norm = (wf_raw - _mean_full) / (_std_full + 1e-10)
    # waveform_display = wf_norm.T  # (nt, nx) — time on y-axis
    waveform_display = wf_raw.T  # (nt, nx) — time on y-axis, no normalization
    vmax = np.percentile(np.abs(waveform_display), 95)

    # Collect all P/S picks for scatter and origin time estimation
    all_p = [(ch, ti) for tgt in sample.targets for ch, ti in tgt.p_picks]
    all_s = [(ch, ti) for tgt in sample.targets for ch, ti in tgt.s_picks]

    # Per-target origin time estimates: t0 = t_P - dt_PS / (Vp/Vs - 1)
    # Each target represents one detected origin — compute per-channel segments
    # and a median origin time line for each.
    _origin_segments: list[tuple[int, float]] = []
    _origin_medians: list[float] = []  # one median t0 (in samples) per target
    for tgt in sample.targets:
        p_map = {int(ch): ti for ch, ti in tgt.p_picks}
        s_map = {int(ch): ti for ch, ti in tgt.s_picks}
        t0_this: list[float] = []
        for ch_i, p_ti in sorted(p_map.items()):
            if ch_i in s_map and s_map[ch_i] > p_ti:
                dt_ps = s_map[ch_i] - p_ti
                t0_samp = p_ti - dt_ps / (VP_VS_RATIO - 1)
                _origin_segments.append((ch_i, t0_samp))
                t0_this.append(t0_samp)
        if t0_this:
            _origin_medians.append(float(np.median(t0_this)))

    # Index-based axis helper
    def _nice_step(total: int, n: int = 6) -> int:
        if total <= 0:
            return 1
        raw = total / n
        exp = 10 ** int(np.floor(np.log10(raw + 1e-10)))
        return max(exp, round(raw / exp) * exp)

    x_step = _nice_step(nx)
    x_ticks = np.arange(0, nx + 1, x_step)

    y_step = _nice_step(nt)
    y_ticks = np.arange(0, nt + 1, y_step)

    def _set_phys_axes(ax, *, xlabel: bool = True, ylabel: bool = True) -> None:
        ax.set_xticks(x_ticks)
        ax.set_xticklabels([f"{int(x)}" for x in x_ticks], fontsize=8)
        ax.set_yticks(y_ticks)
        ax.set_yticklabels([f"{int(y)}" for y in y_ticks], fontsize=8)
        if xlabel:
            ax.set_xlabel("Channel")
        if ylabel:
            ax.set_ylabel("Sample")

    wf_ds = _ds(waveform_display)

    if plot_labels and labels is not None:
        fig, axes = plt.subplots(2, 2, figsize=(14, 8))
        # [1,1] DAS waveform (per-channel normalized)
        ax = axes[0, 0]
        ax.imshow(wf_ds, cmap="seismic", vmin=-vmax, vmax=vmax, **imshow_kwargs)
        _set_phys_axes(ax, xlabel=False, ylabel=True)
        ax.set_title("DAS Waveform")
        ax = axes[0, 1]
    else:
        fig, ax = plt.subplots(1, 1, figsize=(10, 8))

    # Waveform + P/S picks + per-channel origin time estimates
    ax.imshow(wf_ds, cmap="seismic", vmin=-vmax * 5, vmax=vmax * 5, **imshow_kwargs)
    # Unassociated picks in black (from all_picks minus associated)
    if all_picks is not None:
        assoc_set = set()
        for tgt in sample.targets:
            for ch, ti in tgt.p_picks:
                assoc_set.add((int(ch), int(ti), "P"))
            for ch, ti in tgt.s_picks:
                assoc_set.add((int(ch), int(ti), "S"))
        unassoc_p = [(int(pk["channel_index"]), pk["phase_index"])
                     for pk in all_picks
                     if pk["phase_type"] == "P" and (int(pk["channel_index"]), int(pk["phase_index"]), "P") not in assoc_set]
        unassoc_s = [(int(pk["channel_index"]), pk["phase_index"])
                     for pk in all_picks
                     if pk["phase_type"] == "S" and (int(pk["channel_index"]), int(pk["phase_index"]), "S") not in assoc_set]
        if unassoc_p:
            stride = max(1, len(unassoc_p) // max_display_px)
            u_ch, u_t = zip(*unassoc_p[::stride])
            ax.scatter(u_ch, u_t, c="lightsalmon", s=0.5, alpha=0.4, label=f"P unassoc ({len(unassoc_p)})", zorder=3)
        if unassoc_s:
            stride = max(1, len(unassoc_s) // max_display_px)
            u_ch, u_t = zip(*unassoc_s[::stride])
            ax.scatter(u_ch, u_t, c="lightskyblue", s=0.5, alpha=0.4, label=f"S unassoc ({len(unassoc_s)})", zorder=3)
    # Unassociated origin times
    if all_picks is not None and all_picks and "origin_index" in all_picks[0]:
        unassoc_origins = list({(int(pk["channel_index"]), pk["origin_index"])
                                for pk in all_picks
                                if pk.get("origin_id", -1) == -1
                                and pk.get("origin_index") is not None})
        if unassoc_origins:
            stride = max(1, len(unassoc_origins) // max_display_px)
            uo_ch, uo_t = zip(*unassoc_origins[::stride])
            ax.scatter(uo_ch, uo_t, c="lightgreen", s=0.3, alpha=0.4,
                       label=f"Origin unassoc ({len(unassoc_origins)})", zorder=3)
    if all_p:
        p_ch, p_t = zip(*all_p)
        ax.scatter(p_ch, p_t, c="red", s=0.5, alpha=0.7, label=f"P ({len(all_p)})", zorder=4)
    if all_s:
        s_ch, s_t = zip(*all_s)
        ax.scatter(s_ch, s_t, c="blue", s=0.5, alpha=0.7, label=f"S ({len(all_s)})", zorder=4)
    if _origin_segments:
        o_ch, o_t = zip(*_origin_segments)
        ax.scatter(o_ch, o_t, c="green", s=0.3, alpha=0.5, label=f"Origin ({len(_origin_segments)})", zorder=5)
    for _t0_samp in _origin_medians:
        ax.axhline(_t0_samp, color="green",
                   linewidth=0.5, linestyle="--", alpha=0.5, zorder=6)
    ax.set_ylim(nt, 0)  # lock y-axis: 0 at top, nt at bottom (time increases down)
    ax.set_xlim(0, nx - 1)
    _set_phys_axes(ax, xlabel=False, ylabel=False)
    ax.legend(loc="upper right", fontsize=8, markerscale=10)
    ax.set_title("Waveform + Picks + Origin Times")

    if plot_labels and labels is not None:
        # [2,1] P/S phase labels + event center + origin time estimates
        ax = axes[1, 0]
        mask = _ds_max(labels["phase_mask"][0].T)
        p_disp = _ds_max(labels["phase_pick"][1].T)
        s_disp = _ds_max(labels["phase_pick"][2].T)
        nt_d, nx_d = mask.shape
        rgb = np.ones((nt_d, nx_d, 3))
        rgb[:, :, 1] = np.clip(1.0 - p_disp * 0.7, 0, 1)  # P -> red
        rgb[:, :, 2] = np.clip(1.0 - p_disp * 0.7, 0, 1)
        rgb[:, :, 0] = np.clip(rgb[:, :, 0] - s_disp * 0.7, 0, 1)  # S -> blue
        rgb[:, :, 1] = np.clip(rgb[:, :, 1] - s_disp * 0.7, 0, 1)
        rgb[:, :, 0] = np.where(mask > 0, rgb[:, :, 0] * 0.85, rgb[:, :, 0])
        rgb[:, :, 2] = np.where(mask > 0, rgb[:, :, 2] * 0.85, rgb[:, :, 2])
        ax.imshow(rgb, **imshow_kwargs)
        ec_disp = _ds_max(labels["event_center"][0].T)
        event_rgba = np.zeros((nt_d, nx_d, 4))
        event_rgba[:, :, 0] = 1.0
        event_rgba[:, :, 1] = 1.0
        event_rgba[:, :, 3] = ec_disp * 0.8
        ax.imshow(event_rgba, **imshow_kwargs)
        # P/S picks on label panel
        if all_p:
            p_ch, p_t = zip(*all_p)
            ax.scatter(p_ch, p_t, c="red", s=0.5, alpha=0.7, zorder=4)
        if all_s:
            s_ch, s_t = zip(*all_s)
            ax.scatter(s_ch, s_t, c="blue", s=0.5, alpha=0.7, zorder=4)
        if _origin_segments:
            o_ch, o_t = zip(*_origin_segments)
            ax.scatter(o_ch, o_t, c="green", s=0.3, alpha=0.5, zorder=5)
        for _t0_samp in _origin_medians:
            ax.axhline(_t0_samp, color="green",
                       linewidth=0.5, linestyle="--", alpha=0.5, zorder=6)
        ax.set_ylim(nt, 0)
        ax.set_xlim(0, nx - 1)
        _set_phys_axes(ax, xlabel=True, ylabel=True)
        ax.set_title("Phase Labels + Event Center")

        # [2,2] Event time + event center + event mask
        ax = axes[1, 1]
        event_center_mask = _ds_max(labels["event_center_mask"][0].T)
        event_time_mask = _ds_max(labels["event_time_mask"][0].T)
        vp, vs = 6.0, 6.0 / VP_VS_RATIO
        t_arr = np.arange(nt)
        event_time_full = np.zeros((nx, nt), dtype=np.float32)
        ps_dict: dict[int, float] = {}
        for tgt in sample.targets:
            ps_dict.update({int(ch): d for ch, d in tgt.ps_intervals})
        for tgt in sample.targets:
            for ch_c, center in tgt.ps_centers:
                ch = int(ch_c)
                if 0 <= ch < nx:
                    ps_int = ps_dict.get(ch, 0.0)
                    ps_seconds = ps_int * sample.dt_s
                    distance = ps_seconds * vp * vs / (vp - vs)
                    shift = distance * (1 / vp + 1 / vs) / (2 * sample.dt_s)
                    event_time_full[ch, :] = (t_arr - center) + shift
        event_time_disp = _ds(event_time_full.T)
        nt_d2, nx_d2 = event_center_mask.shape
        event_time_disp = event_time_disp[:nt_d2, :nx_d2]
        bg = np.ones((nt_d2, nx_d2, 3))
        bg[:, :, 0] = np.where(event_center_mask > 0, 0.85, 1.0)
        bg[:, :, 2] = np.where(event_center_mask > 0, 0.85, 1.0)
        ax.imshow(bg, **imshow_kwargs)
        im = ax.imshow(np.abs(event_time_disp), cmap="hot_r", vmin=0, vmax=2000, **imshow_kwargs)
        mask_rgba = np.zeros((nt_d2, nx_d2, 4))
        mask_rgba[:, :, 1] = 1.0
        mask_rgba[:, :, 3] = event_time_mask * 0.3
        ax.imshow(mask_rgba, **imshow_kwargs)
        fig.colorbar(im, ax=ax, shrink=0.8)
        _set_phys_axes(ax, xlabel=True, ylabel=False)
        ax.set_title("Event Time + Center")

    if title:
        fig.suptitle(title, fontsize=14, fontweight="bold")
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    print(f"Saved plot to {save_path}")
    plt.close(fig)


def plot_demo(
    sample: Sample,
    transforms: Compose,
    output_dir: str = "figures",
    event_id: str = "das_event",
    n_augmented: int = 0,
    n_traces: int = 5,
    config: LabelConfig = LabelConfig(),
):
    """Generate demo plots: overview, individual traces, and augmented overviews."""
    event_dir = os.path.join(output_dir, event_id)
    os.makedirs(event_dir, exist_ok=True)

    # Raw overview
    print(f"\nRaw data: {sample.waveform.shape}")
    raw_labels = generate_labels(sample, config)
    plot_overview(sample, raw_labels, title=event_id, save_path=os.path.join(event_dir, "overview.png"))

    # Individual trace details (channels with picks, evenly sampled)
    all_p_chs = {int(c) for tgt in sample.targets for c, _ in tgt.p_picks}
    all_s_chs = {int(c) for tgt in sample.targets for c, _ in tgt.s_picks}
    labeled_chs = sorted(all_p_chs & all_s_chs)
    if labeled_chs:
        trace_dir = os.path.join(event_dir, "traces")
        os.makedirs(trace_dir, exist_ok=True)
        n = min(n_traces, len(labeled_chs))
        channels = [labeled_chs[i] for i in np.linspace(0, len(labeled_chs) - 1, n, dtype=int)]
        for j, ch in enumerate(channels):
            plot_trace(
                sample, raw_labels, ch,
                title=f"{event_id} | ch={ch}",
                save_path=os.path.join(trace_dir, f"{j:03d}.png"),
            )
        print(f"  Saved {n} trace plots to {trace_dir}/")

    # N augmented overviews
    if n_augmented > 0:
        aug_dir = os.path.join(event_dir, "augmented")
        os.makedirs(aug_dir, exist_ok=True)
        print(f"\nGenerating {n_augmented} augmented views...")
        seed_offset = 0
        for i in range(n_augmented):
            for seed in range(seed_offset, seed_offset + 100):
                random.seed(seed)
                np.random.seed(seed)
                transformed = transforms(sample.copy(deep_waveform=True))
                if any(not t.is_empty for t in transformed.targets):
                    seed_offset = seed + 1
                    break
            aug_labels = generate_labels(transformed, config)
            plot_overview(
                transformed, aug_labels,
                title=f"{event_id} | augmented #{i}",
                save_path=os.path.join(aug_dir, f"{i:03d}.png"),
            )
        print(f"  Saved {n_augmented} augmented overviews to {aug_dir}/")


if __name__ == "__main__":
    import argparse
    import sys
    import time
    sys.path.insert(0, ".")

    parser = argparse.ArgumentParser(description="DAS Dataset Demo")
    parser.add_argument("--data-file", default="debug_data/mammoth_north/data/nc71121689.h5")
    parser.add_argument("--label-file", default="debug_data/mammoth_north/labels/nc71121689.csv")
    parser.add_argument("--gcs-path", default=None,
                        help="GCS path, e.g. gs://quakeflow_das/ridgecrest_north")
    parser.add_argument("--model", default="phasenet",
                        help="Pick directory under gcs-path (phasenet or phasenet_das)")
    parser.add_argument("--n-events", type=int, default=3,
                        help="Number of events to plot in GCS mode")
    parser.add_argument("--event-id", default=None,
                        help="Plot a single specific event ID (skips speed test)")
    parser.add_argument("--no-speed-test", action="store_true",
                        help="Skip the GCS speed test")
    parser.add_argument("--nt", type=int, default=4096)
    parser.add_argument("--nx", type=int, default=2048)
    parser.add_argument("--n-augmented", type=int, default=0)
    parser.add_argument("--output-dir", default="figures")
    args = parser.parse_args()

    # Figures will be saved to args.output_dir (existing files may be overwritten)

    print("=" * 60)
    print("DAS Dataset Demo")
    print("=" * 60)

    transforms = default_train_transforms(
        nt=args.nt, nx=args.nx, enable_stacking=False, enable_noise_stacking=False,
    )

    if args.gcs_path:
        # ----------------------------------------------------------------
        # GCS mode: load events from cloud storage
        # ----------------------------------------------------------------
        storage_options = get_gcs_storage_options()
        fs, path_clean = get_filesystem(args.gcs_path)
        region = args.gcs_path.rstrip("/").split("/")[-1]

        if args.event_id:
            event_ids = [args.event_id]
            print(f"\n[GCS] single event: {args.event_id}")
        else:
            label_files = fs.glob(f"{path_clean}/{args.model}/picks/*.csv")
            event_ids = sorted(
                os.path.splitext(os.path.basename(f))[0] for f in label_files
            )
            print(f"\n[GCS] {len(event_ids)} events in {args.gcs_path}/{args.model}")

        # Speed test (skipped when --event-id or --no-speed-test)
        if not args.event_id and not args.no_speed_test:
            n_speed = min(50, len(event_ids))
            print(f"\n[Speed test] Loading {n_speed} H5 files from GCS")
            t_start = time.time()
            for eid in event_ids[:n_speed]:
                try:
                    with fsspec.open(f"{args.gcs_path}/data/{eid}.h5", "rb",
                                     **storage_options) as f:
                        with h5py.File(f, "r") as fp:
                            _ = fp["data"][:, :]
                except Exception:
                    pass
            elapsed = time.time() - t_start
            print(f"  {n_speed} files in {elapsed:.1f}s ({n_speed / elapsed:.0f} files/s)")

        from phasenet.utils.postprocess import estimate_origin_times
        from collections import defaultdict

        # Plot N events
        n_plot = len(event_ids) if args.event_id else args.n_events
        print(f"\n[Plot] {n_plot} events with {args.model} picks")
        count = 0
        for eid in event_ids:
            if count >= n_plot:
                break
            try:
                data_path = f"{args.gcs_path}/data/{eid}.h5"
                picks_path = f"{args.gcs_path}/{args.model}/picks/{eid}.csv"
                picks_df = pd.read_csv(picks_path, storage_options=storage_options)
                if "station_id" in picks_df.columns and "channel_index" not in picks_df.columns:
                    picks_df = picks_df.rename(columns={"station_id": "channel_index"})

                # Load waveform (no picks in sample yet — we'll build targets from linked picks)
                sample_raw = load_sample_from_h5(data_path, picks_df=None)
                nx = sample_raw.nx
                nt = sample_raw.nt
                dt_s = sample_raw.dt_s
                channel_ids = [str(i) for i in range(nx)]

                # Convert picks_df to list[dict] for estimate_origin_times
                picks = picks_df.to_dict("records")
                for pk in picks:
                    pk["channel_index"] = str(int(pk["channel_index"]))

                assoc = estimate_origin_times(
                    picks, channel_ids, nt, dt_s, mph=100, max_ps_dt=30.0, bin_size=0.1
                )
                linked_map = assoc.pick_to_event

                if not linked_map:
                    print(f"  {eid}: no linked picks — skipping")
                    continue

                # Build one Target per detected origin (only linked picks)
                picks_by_origin: dict[int, dict[str, list]] = defaultdict(
                    lambda: {"P": [], "S": []}
                )
                for (cid, phase_idx, ptype), oidx in linked_map.items():
                    picks_by_origin[oidx][ptype].append((cid, float(phase_idx)))

                targets = []
                p_total, s_total = 0, 0
                for oidx in sorted(picks_by_origin):
                    p_by_ch: dict[str, float] = {}
                    s_by_ch: dict[str, float] = {}
                    p_picks_o: list[tuple[int, float]] = []
                    s_picks_o: list[tuple[int, float]] = []
                    ps_centers_o: list[tuple[int, float]] = []
                    ps_intervals_o:  list[tuple[int, float]] = []
                    for cid, pidx in picks_by_origin[oidx]["P"]:
                        p_picks_o.append((int(cid), pidx))
                        p_by_ch[cid] = pidx
                    for cid, sidx in picks_by_origin[oidx]["S"]:
                        s_picks_o.append((int(cid), sidx))
                        s_by_ch[cid] = sidx
                    for cid in set(p_by_ch) & set(s_by_ch):
                        p_i, s_i = p_by_ch[cid], s_by_ch[cid]
                        if s_i > p_i:
                            ps_centers_o.append((int(cid), (p_i + s_i) / 2.0))
                            ps_intervals_o.append((int(cid), s_i - p_i))
                    if p_picks_o or s_picks_o:
                        targets.append(Target(
                            p_picks=p_picks_o, s_picks=s_picks_o,
                            ps_centers=ps_centers_o, ps_intervals=ps_intervals_o,
                        ))
                    p_total += len(p_picks_o)
                    s_total += len(s_picks_o)

                linked_chs = len({cid for cid, _, _ in linked_map})
                print(f"  {eid}: nx={nx} nt={nt}  "
                      f"linked_ch={linked_chs}  "
                      f"origins={len(targets)}  P={p_total} S={s_total}")

                sample = Sample(
                    waveform=sample_raw.waveform,
                    targets=targets,
                    dt_s=dt_s,
                    dx_m=sample_raw.dx_m,
                    file_name=eid,
                )
                plot_demo(
                    sample, transforms,
                    event_id=f"{region}_{eid}/catalog",
                    output_dir=args.output_dir,
                    n_augmented=args.n_augmented,
                )

            except Exception as exc:
                import traceback
                traceback.print_exc()
                print(f"  [WARN] {eid}: {exc}")
                continue

            count += 1

    else:
        # ----------------------------------------------------------------
        # Local mode: load from file system
        # ----------------------------------------------------------------
        if os.path.exists(args.label_file):
            picks_df = pd.read_csv(args.label_file)
            print(f"Labels: {args.label_file} ({len(picks_df)} picks)")
        else:
            picks_df = None
            print(f"No label file at {args.label_file}")

        sample = load_sample_from_h5(args.data_file, picks_df)
        print(f"Waveform: {sample.waveform.shape}, targets: {len(sample.targets)}")

        if sample.targets:
            target = sample.targets[0]
            if target.p_picks:
                target.snr, target.amp_signal, target.amp_noise = calc_snr(
                    sample.waveform, target.p_picks
                )

        event_id = os.path.splitext(os.path.basename(args.data_file))[0]
        plot_demo(sample, transforms, output_dir=args.output_dir,
                  event_id=event_id, n_augmented=args.n_augmented)

    print("\n" + "=" * 60)
    print("Demo complete!")
    print("=" * 60)
