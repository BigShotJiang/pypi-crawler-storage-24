"""Shared transforms for seismic and DAS data augmentation.

All transforms operate on duck-typed Sample objects (must have .waveform,
.nt, .nx, .nch, .targets attributes). This allows both ceed.Sample and
das.Sample to use them without inheritance.

Design principles:
- Only extract transforms that process each station/channel independently
- No spatial ordering assumptions
- Transforms that depend on spatial relationships stay domain-specific
"""
from __future__ import annotations

import random
from abc import ABC, abstractmethod
from collections import defaultdict
from typing import Callable, Sequence

import numpy as np
import scipy.signal
import torch
import torch.nn.functional as F


def measure_signal_noise(waveform, targets, nx, nt, window=300):
    """Measure signal and noise std from pick locations.

    Signal: std of window after each pick (contains arriving wave).
    Noise: std of window before each pick (pre-arrival background).

    Returns:
        (S, N) — median signal std and median noise std.
    """
    sigs, noises = [], []
    for tgt in targets:
        for ch, t in tgt.p_picks + tgt.s_picks:
            ch, t = int(ch), int(t)
            if 0 <= ch < nx and 0 <= t < nt:
                s_seg = waveform[0, ch, t:min(t + window, nt)]
                n_seg = waveform[0, ch, max(0, t - window):t]
                if len(s_seg) > 10:
                    sigs.append(np.std(s_seg))
                if len(n_seg) > 10:
                    noises.append(np.std(n_seg))
    S = float(np.median(sigs)) if sigs else 0.0
    N = float(np.median(noises)) if noises else 0.0
    return S, N


# =============================================================================
# Transform Base Classes
# =============================================================================

class Transform(ABC):
    """Base class for all transforms."""

    @abstractmethod
    def __call__(self, sample):
        pass

    def set_sample_fn(self, fn):
        """Optional: set function to get random samples (for stacking)."""
        pass

    def set_noise_fn(self, fn):
        """Optional: set function to get noise samples."""
        pass

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"


class Compose(Transform):
    """Compose multiple transforms together."""

    def __init__(self, transforms: Sequence[Transform]):
        self.transforms = list(transforms)

    def __call__(self, sample):
        for t in self.transforms:
            sample = t(sample)
        return sample

    def __repr__(self) -> str:
        lines = [f"{self.__class__.__name__}(["]
        for t in self.transforms:
            lines.append(f"    {t},")
        lines.append("])")
        return "\n".join(lines)


class Identity(Transform):
    def __call__(self, sample):
        return sample


# =============================================================================
# Basic Waveform Transforms (per-time-axis, no spatial assumptions)
# =============================================================================

class Normalize(Transform):
    """Normalize waveform to zero mean and unit std.

    Args:
        mode: "station" (default) normalizes each spatial channel independently
              with std over (nch, nt), preserving relative component amplitudes.
              "global" normalizes the entire waveform with a single std.
        eps: Small value for numerical stability
    """

    def __init__(self, mode: str = "station", eps: float = 1e-10):
        self.mode = mode
        self.eps = eps

    def __call__(self, sample):
        data = sample.waveform
        np.nan_to_num(data, copy=False)  # in-place
        data -= data.mean(axis=-1, keepdims=True)  # in-place subtract

        if self.mode == "global":
            std = data.std()
        elif self.mode == "station":
            # std per station: (nch, nx, nt) → std over (nch, nt) → (1, nx, 1)
            std = data.std(axis=(0, 2), keepdims=True)
        else:
            # per-component: std over nt → (nch, nx, 1)
            std = data.std(axis=-1, keepdims=True)

        if np.any(std > self.eps):
            np.maximum(std, self.eps, out=std)
            data /= std  # in-place divide

        sample.waveform = data
        return sample

    def __repr__(self) -> str:
        return f"Normalize(mode='{self.mode}')"


class HighpassFilter(Transform):
    """Apply highpass filter to waveform."""

    def __init__(self, freq: float = 1.0, sampling_rate: float = 100):
        self.freq = freq
        self.sampling_rate = sampling_rate
        self.sos = scipy.signal.butter(4, freq, btype='high', fs=sampling_rate, output='sos')

    def __call__(self, sample):
        sample.waveform = scipy.signal.sosfilt(self.sos, sample.waveform, axis=-1).astype(np.float32)
        return sample

    def __repr__(self) -> str:
        return f"HighpassFilter(freq={self.freq})"


# =============================================================================
# Amplitude Augmentation (per-channel independent)
# =============================================================================

class RandomGain(Transform):
    """Apply independent random gain to each station/channel.

    Forces the model to learn waveform shape rather than absolute amplitude.
    Per-channel gain creates relative differences that survive final normalization,
    unlike global amplitude scaling which is washed out.

    Args:
        min_gain: Minimum per-channel gain factor
        max_gain: Maximum per-channel gain factor
    """

    def __init__(self, min_gain: float = 0.5, max_gain: float = 2.0):
        self.min_gain = min_gain
        self.max_gain = max_gain

    def __call__(self, sample):
        log_min = np.log10(self.min_gain)
        log_max = np.log10(self.max_gain)
        gains = 10 ** np.random.uniform(log_min, log_max, size=sample.nx)
        # gains shape: (nx,) → broadcast over (nch, nx, nt)
        sample.waveform = sample.waveform * gains[np.newaxis, :, np.newaxis].astype(np.float32)
        return sample

    def __repr__(self) -> str:
        return f"RandomGain(min_gain={self.min_gain}, max_gain={self.max_gain})"


# =============================================================================
# Noise Augmentation (per-element, no spatial assumptions)
# =============================================================================

class ColoredNoise(Transform):
    """Add colored (1/f^alpha) noise to waveform.

    Args:
        snr_db_range: Range of SNR in dB (min, max)
        alpha_range: Range of spectral exponent (0=white, 1=pink, 2=brown)
        p: Probability of applying
    """

    def __init__(
        self,
        snr_db_range: tuple[float, float] = (5, 30),
        alpha_range: tuple[float, float] = (0.5, 2.0),
        p: float = 0.5,
    ):
        self.snr_db_range = snr_db_range
        self.alpha_range = alpha_range
        self.p = p

    def __call__(self, sample):
        if random.random() > self.p:
            return sample

        alpha = random.uniform(*self.alpha_range)
        nt = sample.nt
        white = np.random.randn(*sample.waveform.shape).astype(np.float32)

        # Shape spectrum: multiply FFT by f^(-alpha/2)
        freqs = np.fft.rfftfreq(nt)
        freqs[0] = 1.0  # avoid division by zero at DC
        spectrum = np.fft.rfft(white, axis=-1)
        spectrum *= (freqs ** (-alpha / 2)).astype(np.float32)
        noise = np.fft.irfft(spectrum, n=nt, axis=-1).astype(np.float32)

        # Scale to target SNR
        snr_db = random.uniform(*self.snr_db_range)
        signal_power = np.mean(sample.waveform ** 2)
        if signal_power > 0:
            noise_power = signal_power / (10 ** (snr_db / 10))
            current_power = np.mean(noise ** 2)
            if current_power > 0:
                noise *= np.sqrt(noise_power / current_power)
                sample.waveform = sample.waveform + noise

        return sample

    def __repr__(self) -> str:
        return f"ColoredNoise(snr_db_range={self.snr_db_range}, alpha_range={self.alpha_range})"


class RandomBandpass(Transform):
    """Apply bandpass filter with random corner frequencies.

    Args:
        low_range: Range for low corner frequency (Hz)
        high_range: Range for high corner frequency (Hz)
        sampling_rate: Sampling rate (Hz)
        p: Probability of applying
    """

    def __init__(
        self,
        low_range: tuple[float, float] = (0.1, 2.0),
        high_range: tuple[float, float] = (10.0, 45.0),
        sampling_rate: float = 100,
        p: float = 0.3,
    ):
        self.low_range = low_range
        self.high_range = high_range
        self.sampling_rate = sampling_rate
        self.p = p

    def __call__(self, sample):
        if random.random() > self.p:
            return sample

        low = random.uniform(*self.low_range)
        high = random.uniform(*self.high_range)
        if low >= high or high >= self.sampling_rate / 2:
            return sample

        sos = scipy.signal.butter(2, [low, high], btype='band', fs=self.sampling_rate, output='sos')
        sample.waveform = scipy.signal.sosfiltfilt(sos, sample.waveform, axis=-1).astype(np.float32)
        return sample

    def __repr__(self) -> str:
        return f"RandomBandpass(low_range={self.low_range}, high_range={self.high_range})"


# =============================================================================
# Temporal Augmentation
# =============================================================================

class ResampleTime(Transform):
    """Resample time axis by a random factor.

    Replaces both TimeStretch (CEED) and ResampleTime (DAS).
    Uses F.interpolate for GPU-friendly resampling.

    Args:
        min_factor: Minimum scale factor
        max_factor: Maximum scale factor
    """

    def __init__(self, min_factor: float = 0.9, max_factor: float = 1.1, p: float = 1.0):
        self.min_factor = min_factor
        self.max_factor = max_factor
        self.p = p

    def __call__(self, sample):
        if random.random() > self.p:
            return sample
        factor = random.uniform(self.min_factor, self.max_factor)
        if abs(factor - 1.0) < 0.01:
            return sample

        data_tensor = torch.from_numpy(sample.waveform).unsqueeze(0)
        data_resampled = F.interpolate(
            data_tensor, scale_factor=(1, factor), mode="bilinear", align_corners=False
        ).squeeze(0).numpy()
        sample.waveform = data_resampled

        for target in sample.targets:
            target.scale_time(factor)

        # Update dt_s so event time labels remain physically correct
        if hasattr(sample, 'dt_s') and sample.dt_s is not None:
            sample.dt_s = sample.dt_s / factor

        return sample

    def __repr__(self) -> str:
        return f"ResampleTime(min_factor={self.min_factor}, max_factor={self.max_factor})"


class RandomCrop(Transform):
    """Randomly crop waveform to fixed size, adjusting picks.

    Unified crop for both seismic and DAS:
    - nx=None: crop time only (seismic behavior)
    - nx=int: crop both spatial and temporal dimensions (DAS behavior)

    Pick-anchored: when picks exist, a random pick is chosen and the crop
    window is constrained to include it.

    Args:
        nt: Target time samples
        nx: Target spatial samples (None = don't crop spatial dimension)
        max_tries: Max attempts for time-only crop to find picks
    """

    def __init__(self, nt: int = 4096, nx: int | None = None, max_tries: int = 100,
                 deterministic: bool = False, stack_self: bool = False,
                 stack_self_p: float = 0.3, stack_self_min_snr: float = 1.0):
        self.nt = nt
        self.nx = nx
        self.max_tries = max_tries
        self.deterministic = deterministic
        self.stack_self = stack_self
        self.stack_self_p = stack_self_p
        self.stack_self_min_snr = stack_self_min_snr

    def _pad_if_needed(self, sample):
        """Pad waveform with reflection if smaller than target (spatial-temporal mode).

        Uses iterative reflect padding when pad > input size.
        """
        _, nx_orig, nt_orig = sample.waveform.shape
        target_nx = self.nx if self.nx is not None else nx_orig

        if nt_orig >= self.nt and nx_orig >= target_nx:
            return sample

        data_tensor = torch.from_numpy(sample.waveform).unsqueeze(0)
        target_nt = max(self.nt, nt_orig)

        # Iterative reflect padding: each step pads at most (dim - 1)
        while data_tensor.shape[3] < target_nt or data_tensor.shape[2] < target_nx:
            pad_nt = min(max(0, target_nt - data_tensor.shape[3]), data_tensor.shape[3] - 1)
            pad_nx = min(max(0, target_nx - data_tensor.shape[2]), data_tensor.shape[2] - 1)
            if pad_nt > 0 or pad_nx > 0:
                data_tensor = F.pad(data_tensor, (0, pad_nt, 0, pad_nx), mode="reflect")
            else:
                break

        sample.waveform = data_tensor.squeeze(0).numpy()
        return sample

    def _get_rng(self, sample):
        """Return a seeded RNG for deterministic mode, or the global random."""
        if self.deterministic:
            # Seed from waveform content so same sample → same crop
            seed = hash(sample.waveform[:, :, :8].tobytes()) & 0xFFFFFFFF
            return random.Random(seed)
        return random

    def __call__(self, sample):
        if self.nx is not None:
            return self._crop_2d(sample)
        return self._crop_time(sample)

    def _crop_time(self, sample):
        """Time-only crop (seismic mode)."""
        nt_orig = sample.nt
        if nt_orig <= self.nt:
            return sample

        all_times = [t for tgt in sample.targets for t in tgt.all_times()]
        rng = self._get_rng(sample)

        t0 = 0
        for _ in range(self.max_tries):
            t0 = rng.randint(0, nt_orig - self.nt)
            t_end = t0 + self.nt
            if sum(1 for t in all_times if t0 <= t < t_end) >= 1:
                break

        t_end = t0 + self.nt
        sample.waveform = sample.waveform[:, :, t0:t_end]
        for target in sample.targets:
            target.crop_time(t0, t_end)
        sample.targets = [t for t in sample.targets if not t.is_empty]
        return sample

    def _crop_2d(self, sample):
        """Spatial-temporal crop (DAS mode).

        When stack_self=True, with probability stack_self_p, crops a second
        time window from the same channel range and stacks it onto the primary
        crop with a random amplitude ratio. The two windows are constrained so
        their event_time masks (P-to-S) don't overlap.
        """
        sample = self._pad_if_needed(sample)
        _, nx_orig, nt_orig = sample.waveform.shape

        if nt_orig <= self.nt and nx_orig <= self.nx:
            return sample

        all_picks = [
            (ch, t) for target in sample.targets
            for ch, t in target.p_picks + target.s_picks
        ]

        rng = self._get_rng(sample)

        if all_picks:
            ch_ref, t_ref = rng.choice(all_picks)
            ch_ref, t_ref = int(ch_ref), int(t_ref)
            x0_lo = max(0, ch_ref - self.nx + 1)
            x0_hi = min(nx_orig - self.nx, ch_ref)
            t0_lo = max(0, t_ref - self.nt + 1)
            t0_hi = min(nt_orig - self.nt, t_ref)
            x0 = rng.randint(x0_lo, max(x0_lo, x0_hi))
            t0 = rng.randint(t0_lo, max(t0_lo, t0_hi))
        else:
            x0 = rng.randint(0, max(0, nx_orig - self.nx))
            t0 = rng.randint(0, max(0, nt_orig - self.nt))

        crop1 = sample.waveform[:, x0:x0 + self.nx, t0:t0 + self.nt].copy()

        # Crop targets for primary window
        targets1 = []
        for target in sample.targets:
            t = target.copy()
            t.crop(t0, self.nt, x0, self.nx)
            if not t.is_empty:
                targets1.append(t)

        # Self-stacking: take a second time crop from the same channels
        if self.stack_self and rng.random() < self.stack_self_p and targets1 and nt_orig > self.nt:
            # Compute event span of primary crop (relative to crop window)
            ps_span = 0
            for tgt in targets1:
                all_t = tgt.all_times()
                if all_t:
                    ps_span = max(ps_span, max(all_t) - min(all_t))

            # Try to find a second crop that doesn't overlap in event time
            for _ in range(self.max_tries):
                t0_2 = rng.randint(0, max(0, nt_orig - self.nt))
                # The two crops overlap in absolute coords if they share time range
                # But we're stacking them into the same output window, so we need
                # the *events* in crop2 to not overlap with events in crop1
                # Events in crop1 span [min_pick - t0, max_pick - t0] in relative coords
                # Events in crop2 span [min_pick2 - t0_2, max_pick2 - t0_2] in relative coords

                targets2 = []
                for target in sample.targets:
                    t = target.copy()
                    t.crop(t0_2, self.nt, x0, self.nx)
                    if not t.is_empty:
                        targets2.append(t)

                if not targets2:
                    continue

                # Check event windows don't overlap (in relative crop coordinates)
                # Use margin large enough to cover event_time_mask (center ± 225 samples)
                margin = max(ps_span * 0.5, 300)
                windows1 = []
                for tgt in targets1:
                    times = tgt.all_times()
                    if times:
                        windows1.append((min(times) - margin, max(times) + margin))

                windows2 = []
                for tgt in targets2:
                    times = tgt.all_times()
                    if times:
                        windows2.append((min(times) - margin, max(times) + margin))

                overlap = any(
                    w1_0 < w2_1 and w2_0 < w1_1
                    for w1_0, w1_1 in windows1
                    for w2_0, w2_1 in windows2
                )
                if overlap:
                    continue

                # Measure S and N for both crops
                crop2 = sample.waveform[:, x0:x0 + self.nx, t0_2:t0_2 + self.nt].copy()

                S1, N1 = measure_signal_noise(crop1, targets1, self.nx, self.nt)
                S2, N2 = measure_signal_noise(crop2, targets2, self.nx, self.nt)

                if S1 <= N1 or S2 <= N2 or N2 <= 0:
                    continue

                # Same linear model as StackNoise:
                # After stacking, noise added to event1 = r * N2
                # SNR1 = S1 / (N1 + r*N2) = target_snr → r = (S1/target_snr - N1) / N2
                # SNR2 = r*S2 / (N1 + r*N2) — must also check >= min_snr
                min_snr = self.stack_self_min_snr
                # Max ratio from event1 constraint
                r_max = (S1 / min_snr - N1) / N2
                if r_max <= 0:
                    continue
                # Min ratio from event2 constraint
                r_min_denom = S2 - min_snr * N2
                if r_min_denom <= 0:
                    continue
                r_min = min_snr * N1 / r_min_denom

                if r_min > r_max:
                    continue

                ratio = rng.uniform(r_min, r_max)
                crop1 = crop1 + crop2 * ratio

                # Scale target amplitudes
                for tgt in targets2:
                    tgt.amp_signal = tgt.amp_signal * ratio
                    tgt.amp_noise = tgt.amp_noise * ratio
                targets1.extend(targets2)
                break

        sample.waveform = crop1
        sample.targets = targets1

        return sample

    def __repr__(self) -> str:
        if self.nx is not None:
            return f"RandomCrop(nt={self.nt}, nx={self.nx})"
        return f"RandomCrop(nt={self.nt})"


# =============================================================================
# Event Stacking (unified for seismic and DAS)
# =============================================================================

class StackEvents(Transform):
    """Stack multiple events onto a single waveform (Mixup-inspired).

    Each stacked event becomes a separate Target in sample.targets.
    Uses SNR-based amplitude ratio control and overlap checking.

    Duration estimation uses ps_intervals from Target (available in both
    seismic and DAS) rather than distance + velocity model.

    Args:
        max_events: Maximum number of additional events to stack
        max_shift: Maximum shift in samples for alignment
        min_ratio: Minimum amplitude ratio (log10 scale)
        max_ratio: Maximum amplitude ratio (log10 scale)
        max_tries: Maximum attempts to find valid position
        allow_overlap: Overlap policy ("none", "partial", "full")
        p: Probability of applying stacking
        default_ps_width: Fallback event window width when ps_intervals
                          is empty (in samples)
    """

    def __init__(
        self,
        max_events: int = 2,
        max_shift: int = 4096,
        min_ratio: float = -2.0,
        max_ratio: float = 2.0,
        max_tries: int = 10,
        allow_overlap: str = "none",
        p: float = 1.0,
        default_ps_width: int = 300,
    ):
        self.max_events = max_events
        self.max_shift = max_shift
        self.min_ratio = min_ratio
        self.max_ratio = max_ratio
        self.max_tries = max_tries
        self.allow_overlap = allow_overlap
        self.p = p
        self.default_ps_width = default_ps_width
        self._sample_fn: Callable | None = None

    def set_sample_fn(self, fn: Callable):
        """Set function to get random samples for stacking."""
        self._sample_fn = fn

    def _get_ps_width(self, target) -> float:
        """Get event window width from ps_intervals, or use default."""
        if target.ps_intervals:
            return max(d for _, d in target.ps_intervals)
        return self.default_ps_width

    def _get_target_windows(self, target) -> list[tuple[int, int]]:
        """Get event windows (P to S) for a target using ps_intervals."""
        ps_width = self._get_ps_width(target)
        windows = []
        for _, p_time in target.p_picks:
            windows.append((int(p_time), int(p_time + ps_width)))
        if len(target.s_picks) > len(target.p_picks):
            for _, s_time in target.s_picks[len(target.p_picks):]:
                windows.append((int(s_time - ps_width), int(s_time)))
        return windows

    def _check_overlap(
        self,
        windows_existing: list[tuple[int, int]],
        windows_new: list[tuple[int, int]],
        picks_existing: list[float],
        picks_new: list[float],
    ) -> bool:
        """Check if stacking is valid based on overlap policy."""
        if self.allow_overlap == "full":
            return True

        # New picks must not fall in existing windows
        if any(w0 <= t <= w1 for t in picks_new for w0, w1 in windows_existing):
            return False

        if self.allow_overlap == "none":
            # Existing picks must not fall in new windows
            if any(w0 <= t <= w1 for t in picks_existing for w0, w1 in windows_new):
                return False
        return True

    def __call__(self, sample):
        if random.random() > self.p:
            return sample
        if self._sample_fn is None:
            return sample

        n_events = random.randint(1, self.max_events)

        for _ in range(n_events):
            sample2 = self._sample_fn()
            if sample2 is None or not sample2.targets:
                continue

            target2 = sample2.targets[0]

            # Check amp_signal/amp_noise are available and nonzero
            amp_sig_1 = getattr(sample, 'amp_signal', None)
            amp_noise_1 = getattr(sample, 'amp_noise', None)
            if amp_sig_1 is None:
                # Aggregate from targets
                amp_sig_1 = max((t.amp_signal for t in sample.targets), default=0)
                amp_noise_1 = min((t.amp_noise for t in sample.targets if t.amp_noise > 0), default=0)
            if target2.amp_signal == 0 or target2.amp_noise == 0:
                continue
            if amp_sig_1 == 0 or amp_noise_1 == 0:
                continue

            # Existing picks/windows
            all_times_existing = [t for tgt in sample.targets for t in tgt.all_times()]
            windows_existing = [
                w for tgt in sample.targets
                for w in self._get_target_windows(tgt)
            ]

            # Donor first arrival for alignment
            times2 = target2.all_times()
            first1 = min(all_times_existing) if all_times_existing else sample.nt // 2
            first2 = min(times2) if times2 else sample.nt // 2

            for _ in range(self.max_tries):
                shift = random.randint(-self.max_shift, self.max_shift) + int(first1 - first2)
                nt = sample.nt

                # Shifted donor picks and windows
                p2_shifted = [(t + shift) % nt for _, t in target2.p_picks]
                s2_shifted = [(t + shift) % nt for _, t in target2.s_picks]
                windows2 = self._get_target_windows(target2)
                windows2_shifted = [((w0 + shift) % nt, (w1 + shift) % nt) for w0, w1 in windows2]

                if not self._check_overlap(
                    windows_existing, windows2_shifted,
                    all_times_existing, p2_shifted + s2_shifted,
                ):
                    continue

                # Calculate amplitude ratio (SNR-aware)
                min_r = max(self.min_ratio, np.log10(amp_noise_1 * 2 / target2.amp_signal + 1e-10))
                max_r = min(self.max_ratio, np.log10(amp_sig_1 / 2 / target2.amp_noise + 1e-10))
                if min_r > max_r:
                    continue

                ratio = 10 ** random.uniform(min_r, max_r)
                flip = random.choice([-1.0, 1.0])

                # Stack waveforms — pad smaller nx to match larger
                donor = np.roll(sample2.waveform, shift, axis=-1) * ratio * flip
                nx1, nx2 = sample.nx, sample2.nx
                if nx1 < nx2:
                    pad = np.zeros((sample.nch, nx2 - nx1, sample.nt), dtype=sample.waveform.dtype)
                    sample.waveform = np.concatenate([sample.waveform, pad], axis=1)
                elif nx2 < nx1:
                    pad = np.zeros((sample2.nch, nx1 - nx2, sample2.nt), dtype=donor.dtype)
                    donor = np.concatenate([donor, pad], axis=1)
                sample.waveform = sample.waveform + donor

                # Create shifted target
                new_target = target2.copy()
                new_target.p_picks = [(s, (t + shift) % nt) for s, t in target2.p_picks]
                new_target.s_picks = [(s, (t + shift) % nt) for s, t in target2.s_picks]
                new_target.ps_centers = [(s, (t + shift) % nt) for s, t in target2.ps_centers]
                new_target.amp_signal = target2.amp_signal * ratio
                new_target.amp_noise = target2.amp_noise * ratio

                # Handle polarity if present (CEED targets)
                if hasattr(target2, 'polarity') and target2.polarity:
                    sign_flip = 1 if flip > 0 else -1
                    new_target.polarity = [
                        (s, (t + shift) % nt, sign * sign_flip)
                        for s, t, sign in target2.polarity
                    ]

                sample.targets.append(new_target)
                break

        return sample

    def __repr__(self) -> str:
        return f"StackEvents(max_events={self.max_events}, max_shift={self.max_shift}, p={self.p})"


# =============================================================================
# Utility Classes
# =============================================================================

class SampleBuffer:
    """Efficient buffer for random sample access during stacking.
    Uses reservoir sampling for streaming datasets.
    """

    def __init__(self, max_size: int = 100):
        self.max_size = max_size
        self.buffer: list = []
        self.count = 0

    def add(self, sample):
        if len(self.buffer) < self.max_size:
            self.buffer.append(sample.copy(deep_waveform=True))
        else:
            idx = random.randint(0, self.count)
            if idx < self.max_size:
                self.buffer[idx] = sample.copy(deep_waveform=True)
        self.count += 1

    def get_random(self):
        if not self.buffer:
            return None
        return random.choice(self.buffer).copy(deep_waveform=True)

    def __len__(self) -> int:
        return len(self.buffer)
