# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "datasets",
#     "numpy",
#     "torch",
#     "gcsfs",
# ]
# ///
"""
CEED: California Earthquake Event Dataset

A modern, efficient dataset implementation for seismic phase picking following
best practices from computer vision (torchvision, timm, albumentations).

Design Principles:
1. COCO-style Target annotations: each event is a separate Target object,
   making multi-event stacking trivial and per-event metadata preserved
2. Unified (nch, nx, nt) internal format: (3, nx, nt) for multi-station seismic
3. Transform-based augmentation operating on raw picks before label generation
4. Compose pattern for chaining transforms
5. Clean separation: loading -> transforms -> label generation

Example:
    >>> from ceed import CEEDDataset, default_train_transforms
    >>> dataset = CEEDDataset(
    ...     region="SC", years=[2025], days=[1, 2, 3],
    ...     transforms=default_train_transforms(),
    ...     streaming=False,
    ... )
    >>> sample = dataset[0]
"""

from __future__ import annotations

import json
import os
import random
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Callable, Iterator

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, IterableDataset

from .transforms import (
    Transform, Compose, Identity, Normalize, HighpassFilter,
    RandomGain, ColoredNoise, RandomBandpass, ResampleTime,
    RandomCrop, StackEvents, SampleBuffer,
)

# =============================================================================
# Configuration
# =============================================================================

BUCKET = "gs://quakeflow_dataset"
GCS_CREDENTIALS_PATH = os.path.expanduser("~/.config/gcloud/application_default_credentials.json")
CEED_HF_REPO = "AI4EPS/CEED"
CEED_HF_REVISION = "claude"
DEFAULT_SAMPLING_RATE = 100  # Hz
DEFAULT_WINDOW_LENGTH = 12288  # samples at 100Hz (~122.88s)

# GCS bucket-name for each region code (NC → NCEDC, SC → SCEDC)
REGION_TO_BUCKET: dict[str, str] = {
    "NC": "NCEDC",
    "SC": "SCEDC",
}

# Origin-time estimation defaults
VP_VS_RATIO = 1.73   # Vp/Vs
MAX_PS_DT = 20.0     # seconds — maximum P-S interval to consider a valid pair

# Earth radius for distance calculations
_EARTH_RADIUS_KM = 6371.0


def _station_xy_km(locs: np.ndarray) -> np.ndarray:
    """Project station lat/lon to local (x_km, y_km) through median center.

    Args:
        locs: (nx, 3) array of [lat, lon, depth_km] per station.

    Returns:
        (nx, 2) array of [x_km, y_km] relative to the median station.
    """
    lat = locs[:, 0]
    lon = locs[:, 1]

    # Median center as reference
    lat0 = np.median(lat)
    lon0 = np.median(lon)

    # Project to km (approximate for regional distances)
    x_km = (lon - lon0) * np.cos(np.radians(lat0)) * (np.pi / 180.0) * _EARTH_RADIUS_KM
    y_km = (lat - lat0) * (np.pi / 180.0) * _EARTH_RADIUS_KM

    return np.stack([x_km, y_km], axis=-1).astype(np.float32)


@dataclass
class LabelConfig:
    """Configuration for label generation."""
    phase_width: int = 60  # Gaussian width for phase picks (samples)
    polarity_width: int = 20  # Gaussian width for polarity
    polarity_shift: float = 0.5  # output = raw * scale + shift; default maps [-1,1] → [0,1]
    polarity_scale: float = 0.5
    event_width: int = 150  # Gaussian width for event center
    mask_width_factor: float = 1.5  # mask_width = phase_width * factor
    gaussian_threshold: float = 0.05  # Values below this are zeroed
    vp: float = 6.0  # P-wave velocity (km/s)
    vp_vs_ratio: float = 1.73  # Vp/Vs ratio


# =============================================================================
# Data Structures — COCO-style Target + Sample
# =============================================================================

@dataclass
class Target:
    """Per-event annotation, following COCO/torchvision detection conventions.

    Each Target represents ONE seismic event's picks on the waveform.
    A Sample can have multiple Targets (e.g. from event stacking).

    Picks are (station_idx, time_sample) tuples where station_idx is the
    index in the sorted station array (0 to nx-1).
    """
    p_picks: list[tuple[int, float]] = field(default_factory=list)
    s_picks: list[tuple[int, float]] = field(default_factory=list)
    polarity: list[tuple[int, float, int]] = field(default_factory=list)  # (sta, time, sign)
    ps_centers: list[tuple[int, float]] = field(default_factory=list)  # (sta, center_time)
    ps_intervals: list[tuple[int, float]] = field(default_factory=list)  # (sta, S-P interval)

    # Per-event metadata
    snr: float = 0.0
    amp_signal: float = 0.0
    amp_noise: float = 0.0
    distance_km: float = 0.0
    event_id: str = ""

    def copy(self) -> "Target":
        return Target(
            p_picks=self.p_picks.copy(),
            s_picks=self.s_picks.copy(),
            polarity=self.polarity.copy(),
            ps_centers=self.ps_centers.copy(),
            ps_intervals=self.ps_intervals.copy(),
            snr=self.snr,
            amp_signal=self.amp_signal,
            amp_noise=self.amp_noise,
            distance_km=self.distance_km,
            event_id=self.event_id,
        )

    @property
    def is_empty(self) -> bool:
        return not self.p_picks and not self.s_picks

    def all_times(self) -> list[float]:
        """All pick times (P + S)."""
        return [t for _, t in self.p_picks] + [t for _, t in self.s_picks]

    # -- Pick adjustment methods (in-place, return self for chaining) --

    def crop_time(self, start: int, end: int) -> "Target":
        """Keep picks in [start, end), shift to new origin."""
        self.p_picks = [(s, t - start) for s, t in self.p_picks if start <= t < end]
        self.s_picks = [(s, t - start) for s, t in self.s_picks if start <= t < end]
        self.polarity = [(s, t - start, sign) for s, t, sign in self.polarity if start <= t < end]
        ec, ps = [], []
        for (s, t), (_, d) in zip(self.ps_centers, self.ps_intervals):
            if start <= t < end:
                ec.append((s, t - start))
                ps.append((s, d))
        self.ps_centers, self.ps_intervals = ec, ps
        return self

    def shift_time(self, shift: int, nt: int, wrap: bool = True) -> "Target":
        """Shift all time indices. Wraps modulo nt or clips to [0, nt)."""
        if wrap:
            self.p_picks = [(s, (t + shift) % nt) for s, t in self.p_picks]
            self.s_picks = [(s, (t + shift) % nt) for s, t in self.s_picks]
            self.polarity = [(s, (t + shift) % nt, sign) for s, t, sign in self.polarity]
            self.ps_centers = [(s, (t + shift) % nt) for s, t in self.ps_centers]
            # ps_intervals unchanged by circular shift
        else:
            self.p_picks = [(s, t + shift) for s, t in self.p_picks if 0 <= t + shift < nt]
            self.s_picks = [(s, t + shift) for s, t in self.s_picks if 0 <= t + shift < nt]
            self.polarity = [(s, t + shift, sign) for s, t, sign in self.polarity if 0 <= t + shift < nt]
            ec, ps = [], []
            for (s, t), (_, d) in zip(self.ps_centers, self.ps_intervals):
                if 0 <= t + shift < nt:
                    ec.append((s, t + shift))
                    ps.append((s, d))
            self.ps_centers, self.ps_intervals = ec, ps
        return self

    def scale_time(self, factor: float) -> "Target":
        """Scale time indices by factor."""
        self.p_picks = [(s, t * factor) for s, t in self.p_picks]
        self.s_picks = [(s, t * factor) for s, t in self.s_picks]
        self.polarity = [(s, t * factor, sign) for s, t, sign in self.polarity]
        ec, ps = [], []
        for (s, t), (_, d) in zip(self.ps_centers, self.ps_intervals):
            ec.append((s, t * factor))
            ps.append((s, d * factor))
        self.ps_centers, self.ps_intervals = ec, ps
        return self

    def crop_space(self, start: int, nx: int) -> "Target":
        """Keep picks in station range [start, start+nx), shift to new origin."""
        end = start + nx
        self.p_picks = [(s - start, t) for s, t in self.p_picks if start <= s < end]
        self.s_picks = [(s - start, t) for s, t in self.s_picks if start <= s < end]
        self.polarity = [(s - start, t, sign) for s, t, sign in self.polarity if start <= s < end]
        ec, ps = [], []
        for (s, t), (_, d) in zip(self.ps_centers, self.ps_intervals):
            if start <= s < end:
                ec.append((s - start, t))
                ps.append((s - start, d))
        self.ps_centers, self.ps_intervals = ec, ps
        return self

    def flip_polarity_sign(self) -> "Target":
        """Negate polarity signs (for waveform polarity flip)."""
        self.polarity = [(s, t, -sign) for s, t, sign in self.polarity]
        return self


@dataclass
class Sample:
    """A seismic sample with waveform and per-event annotations.

    Waveform shape: (nch, nx, nt) = (3, num_stations, num_time_samples).
    Stations are sorted by distance for spatial coherence.

    targets: list of Target, one per seismic event in the window.
    """
    waveform: np.ndarray  # (nch, nx, nt) — always 3D
    targets: list[Target] = field(default_factory=list)

    # Metadata
    sampling_rate: float = DEFAULT_SAMPLING_RATE
    trace_ids: list[str] = field(default_factory=list)
    sensors: list[str] = field(default_factory=list)
    station_event_index: np.ndarray | None = None  # (nx,) int, event index per station
    station_locs: np.ndarray | None = None  # (nx, 3) lat, lon, depth_km

    @property
    def nch(self) -> int:
        return self.waveform.shape[0]

    @property
    def nx(self) -> int:
        return self.waveform.shape[1]

    @property
    def nt(self) -> int:
        return self.waveform.shape[2]

    @property
    def amp_signal(self) -> float:
        """Weakest event signal (conservative for stacking ratio)."""
        vals = [t.amp_signal for t in self.targets if t.amp_signal > 0]
        return min(vals) if vals else 0.0

    @property
    def amp_noise(self) -> float:
        """Worst-case noise level across events."""
        vals = [t.amp_noise for t in self.targets if t.amp_noise > 0]
        return max(vals) if vals else 0.0

    def copy(self, deep_waveform: bool = False) -> "Sample":
        return Sample(
            waveform=self.waveform.copy() if deep_waveform else self.waveform,
            targets=[t.copy() for t in self.targets],
            sampling_rate=self.sampling_rate,
            trace_ids=self.trace_ids.copy(),
            sensors=self.sensors.copy(),
            station_event_index=self.station_event_index.copy() if self.station_event_index is not None else None,
            station_locs=self.station_locs.copy() if self.station_locs is not None else None,
        )


# =============================================================================
# Transforms — Following CV Best Practices (torchvision/albumentations pattern)
# =============================================================================
# Core transforms (Transform, Compose, Identity, Normalize, HighpassFilter,
# RandomGain, ColoredNoise, RandomBandpass, ResampleTime, RandomCrop,
# StackEvents, SampleBuffer) are imported from phasenet.data.transforms.
# Only CEED-specific transforms are defined below.
# =============================================================================


class Taper(Transform):
    """Apply cosine taper to waveform edges."""

    def __init__(self, max_percentage: float = 0.05):
        self.max_percentage = max_percentage

    def __call__(self, sample: Sample) -> Sample:
        nt = sample.nt
        taper_len = int(nt * self.max_percentage)
        if taper_len > 0:
            taper = np.ones(nt, dtype=np.float32)
            taper[:taper_len] = 0.5 * (1 - np.cos(np.pi * np.arange(taper_len) / taper_len))
            taper[-taper_len:] = 0.5 * (1 - np.cos(np.pi * np.arange(taper_len, 0, -1) / taper_len))
            sample.waveform = sample.waveform * taper
        return sample

    def __repr__(self) -> str:
        return f"Taper(max_percentage={self.max_percentage})"


# -----------------------------------------------------------------------------
# Temporal Transforms (modify both waveform and picks via Target methods)
# -----------------------------------------------------------------------------
# RandomCrop is imported from phasenet.data.transforms

class CenterCrop(Transform):
    """Crop waveform from center to fixed length."""

    def __init__(self, length: int = 4096):
        self.length = length

    def __call__(self, sample: Sample) -> Sample:
        nt = sample.nt
        if nt <= self.length:
            return sample

        start = (nt - self.length) // 2
        end = start + self.length
        sample.waveform = sample.waveform[:, :, start:end]
        for target in sample.targets:
            target.crop_time(start, end)
        sample.targets = [t for t in sample.targets if not t.is_empty]
        return sample

    def __repr__(self) -> str:
        return f"CenterCrop(length={self.length})"


# RandomShift: removed (replaced by RandomCrop's position randomization)
# TimeStretch: removed (replaced by ResampleTime from phasenet.data.transforms)

# -----------------------------------------------------------------------------
# Amplitude/Polarity Transforms
# -----------------------------------------------------------------------------

class FlipPolarity(Transform):
    """Randomly flip waveform polarity (multiply by -1). Also negates polarity signs."""

    def __init__(self, p: float = 0.5):
        self.p = p

    def __call__(self, sample: Sample) -> Sample:
        if random.random() < self.p:
            sample.waveform = -sample.waveform
            for target in sample.targets:
                target.flip_polarity_sign()
        return sample

    def __repr__(self) -> str:
        return f"FlipPolarity(p={self.p})"


# RandomAmplitudeScale: removed (global scaling washed out by Normalize;
# only per-channel RandomGain from phasenet.data.transforms matters)

class DropChannel(Transform):
    """Randomly drop (zero out) channels.

    Channels: 0=E, 1=N, 2=Z. Dropping Z clears polarity labels since
    polarity is measured on the vertical component.

    Args:
        p: Probability of applying the transform
    """

    # (channels_to_drop, drops_z) — equally weighted
    _DROP_PATTERNS = [
        ([0],    False),  # drop E
        ([1],    False),  # drop N
        ([0, 1], False),  # drop E+N
        ([2],    True),   # drop Z
        ([0, 2], True),   # drop E+Z
        ([1, 2], True),   # drop N+Z
    ]

    def __init__(self, p: float = 0.1):
        self.p = p

    def __call__(self, sample: Sample) -> Sample:
        if random.random() > self.p:
            return sample

        channels, drops_z = random.choice(self._DROP_PATTERNS)
        for ch in channels:
            sample.waveform[ch] = 0

        if drops_z:
            for target in sample.targets:
                target.polarity = []

        return sample

    def __repr__(self) -> str:
        return f"DropChannel(p={self.p})"


# RandomGain: imported from phasenet.data.transforms

# -----------------------------------------------------------------------------
# Noise Augmentation
# -----------------------------------------------------------------------------

class AddGaussianNoise(Transform):
    """Add Gaussian noise to waveform.

    Args:
        snr_db_range: Range of SNR in dB (min, max)
    """

    def __init__(self, snr_db_range: tuple[float, float] = (10, 30)):
        self.snr_db_range = snr_db_range

    def __call__(self, sample: Sample) -> Sample:
        snr_db = random.uniform(*self.snr_db_range)
        signal_power = np.mean(sample.waveform ** 2)
        noise_power = signal_power / (10 ** (snr_db / 10))
        noise = np.random.randn(*sample.waveform.shape).astype(np.float32) * np.sqrt(noise_power)
        sample.waveform = sample.waveform + noise
        return sample

    def __repr__(self) -> str:
        return f"AddGaussianNoise(snr_db_range={self.snr_db_range})"


# ColoredNoise: imported from phasenet.data.transforms
# RandomBandpass: imported from phasenet.data.transforms
# StackEvents: imported from phasenet.data.transforms
# predict_ps_times: removed (StackEvents now uses ps_intervals from Target)


class StackNoise(Transform):
    """Stack noise onto the waveform.

    Supports two noise sources (tried in order):
    1. Dedicated noise files via set_noise_fn
    2. Pre-arrival extraction from other samples via set_sample_fn

    Args:
        max_ratio: Maximum noise amplitude ratio relative to signal
        p: Probability of applying
    """

    def __init__(self, max_ratio: float = 2.0, p: float = 0.5):
        self.max_ratio = max_ratio
        self.p = p
        self._noise_fn: Callable[[], np.ndarray | None] | None = None
        self._sample_fn: Callable[[], Sample | None] | None = None

    def set_noise_fn(self, fn: Callable[[], np.ndarray | None]):
        """Set function to get random noise arrays (e.g., from dedicated noise files)."""
        self._noise_fn = fn

    def set_sample_fn(self, fn: Callable[[], Sample | None]):
        """Set function to get random samples (for pre-arrival noise extraction)."""
        self._sample_fn = fn

    def _extract_head_noise(self, donor: Sample, length: int) -> np.ndarray | None:
        """Extract noise from the beginning of the donor waveform, before first pick."""
        nt = donor.waveform.shape[-1]
        if nt < length:
            return None
        all_times = [t for tgt in donor.targets for t in tgt.all_times()]
        first_pick = int(min(all_times)) if all_times else nt
        if first_pick < length + 100:  # margin for label Gaussian tail
            return None
        return donor.waveform[..., :length]

    def _get_noise(self, sample: Sample) -> np.ndarray | None:
        """Get noise: dedicated files first, then head extraction."""
        if self._noise_fn is not None:
            noise = self._noise_fn()
            if noise is not None:
                return noise
        if self._sample_fn is not None:
            donor = self._sample_fn()
            if donor is not None:
                return self._extract_head_noise(donor, sample.nt)
        return None

    def __call__(self, sample: Sample) -> Sample:
        if random.random() > self.p or sample.amp_signal == 0:
            return sample
        noise = self._get_noise(sample)
        if noise is None or noise.shape != sample.waveform.shape:
            return sample
        noise_std = np.std(noise)
        if noise_std <= 0:
            return sample
        ratio = random.uniform(0, self.max_ratio) * sample.amp_signal
        sample.waveform = sample.waveform + noise / noise_std * ratio
        return sample

    def __repr__(self) -> str:
        return f"StackNoise(max_ratio={self.max_ratio}, p={self.p})"


# =============================================================================
# Label Generation
# =============================================================================


def generate_labels(
    sample: Sample,
    config: LabelConfig = LabelConfig(),
) -> dict[str, np.ndarray]:
    """Generate all labels from Sample.targets.

    Iterates over all targets (events) in the sample, accumulating
    Gaussian labels. Naturally handles multi-event windows from stacking.

    Returns:
        All arrays have shape (label_ch, nx, nt) matching the unified format.
        - phase_pick: (3, nx, nt) — [noise, P, S]
        - phase_mask: (1, nx, nt)
        - polarity: (1, nx, nt)
        - polarity_mask: (1, nx, nt)
        - event_center: (1, nx, nt)
        - event_time: (1, nx, nt)
        - event_center_mask: (1, nx, nt)
        - event_time_mask: (1, nx, nt)
    """
    nx, nt = sample.nx, sample.nt
    sigma_phase = config.phase_width / 6
    sigma_pol = config.polarity_width / 6
    sigma_event = config.event_width / 6
    mask_w = int(config.phase_width * config.mask_width_factor)
    event_mask_w = int(config.event_width * config.mask_width_factor)
    t = np.arange(nt)

    p_label = np.zeros((nx, nt), dtype=np.float32)
    s_label = np.zeros((nx, nt), dtype=np.float32)
    polarity_raw = np.zeros((nx, nt), dtype=np.float32)
    polarity_mask = np.zeros((nx, nt), dtype=np.float32)
    event_center_label = np.zeros((nx, nt), dtype=np.float32)
    event_time_label = np.zeros((nx, nt), dtype=np.float32)
    event_center_mask = np.zeros((nx, nt), dtype=np.float32)
    event_time_mask = np.zeros((nx, nt), dtype=np.float32)
    phase_mask = np.zeros((nx, nt), dtype=np.float32)

    has_p = np.zeros(nx, dtype=bool)
    has_s = np.zeros(nx, dtype=bool)

    vp = config.vp
    vs = vp / config.vp_vs_ratio
    dt_s = 1.0 / sample.sampling_rate

    # Tracks per-station list of (p_time, s_time) from ps_centers+ps_intervals
    # Used to build windowed phase_mask / event_center_mask for multi-event stations
    ps_intervals_per_sta: dict[int, list[tuple[float, float]]] = {}

    half_w_phase = int(3 * sigma_phase + 1)
    half_w_pol = int(3 * sigma_pol + 1)
    half_w_event = int(3 * sigma_event + 1)

    def add_phase_picks(picks, label, has_flag):
        for sta, ti in picks:
            sta = int(sta)
            if 0 <= sta < nx:
                t0 = max(0, int(ti) - half_w_phase)
                t1 = min(nt, int(ti) + half_w_phase + 1)
                t_local = np.arange(t0, t1)
                g = np.exp(-((t_local - ti) ** 2) / (2 * sigma_phase ** 2))
                g[g < config.gaussian_threshold] = 0.0
                label[sta, t0:t1] += g
                has_flag[sta] = True

    for target in sample.targets:
        add_phase_picks(target.p_picks, p_label, has_p)
        add_phase_picks(target.s_picks, s_label, has_s)

        # Polarity labels
        for sta, ti, sign in target.polarity:
            sta = int(sta)
            if 0 <= sta < nx:
                t0 = max(0, int(ti) - half_w_pol)
                t1 = min(nt, int(ti) + half_w_pol + 1)
                t_local = np.arange(t0, t1)
                g = np.exp(-((t_local - ti) ** 2) / (2 * sigma_pol ** 2))
                g[g < config.gaussian_threshold] = 0.0
                polarity_raw[sta, t0:t1] += sign * g
                t0 = max(0, int(ti) - mask_w)
                t1 = min(nt, int(ti) + mask_w)
                polarity_mask[sta, t0:t1] = 1.0

        # Event labels: only for stations with BOTH P and S picks in crop window
        p_stas = {int(s) for s, _ in target.p_picks}
        s_stas = {int(s) for s, _ in target.s_picks}
        for (sta, center), (_, ps_int) in zip(target.ps_centers, target.ps_intervals):
            sta = int(sta)
            if 0 <= sta < nx and sta in p_stas and sta in s_stas:
                t0e = max(0, int(center) - half_w_event)
                t1e = min(nt, int(center) + half_w_event + 1)
                t_local = np.arange(t0e, t1e)
                g = np.exp(-((t_local - center) ** 2) / (2 * sigma_event ** 2))
                g[g < config.gaussian_threshold] = 0.0
                event_center_label[sta, t0e:t1e] += g

                ps_seconds = ps_int * dt_s
                distance = ps_seconds * vp * vs / (vp - vs)
                center_travel = distance * (1 / vp + 1 / vs) / 2
                shift = center_travel / dt_s

                # Windowed mask covering [P - 0.5(S-P) - 3, S + 0.5(S-P) + 3]
                p_time = center - ps_int / 2
                s_time = center + ps_int / 2
                ext = int(0.5 * ps_int) + 300
                cm_t0 = max(0, int(p_time) - ext)
                cm_t1 = min(nt, int(s_time) + ext)
                event_center_mask[sta, cm_t0:cm_t1] = 1.0
                ps_intervals_per_sta.setdefault(sta, []).append((p_time, s_time))

                t0 = max(0, int(center) - event_mask_w)
                t1 = min(nt, int(center) + event_mask_w)
                event_time_mask[sta, t0:t1] = 1.0
                event_time_label[sta, t0:t1] = (t[t0:t1] - center) + shift

    # Single-event sample: every station has at most 1 event → full trace masks.
    # Multi-event sample: use windowed masks around each event's P-S interval.
    is_single_event = (
        not ps_intervals_per_sta
        or max(len(v) for v in ps_intervals_per_sta.values()) <= 1
    )

    # Phase mask: only for stations with BOTH P and S picks in ps_intervals.
    # Single-event → full trace mask.
    # Multi-event → windowed mask around each P-S interval.
    for sta, intervals in ps_intervals_per_sta.items():
        if is_single_event:
            phase_mask[sta, :] = 1.0
        else:
            for p_time, s_time in intervals:
                ext = int(0.5 * (s_time - p_time)) + 300
                t0 = max(0, int(p_time) - ext)
                t1 = min(nt, int(s_time) + ext)
                phase_mask[sta, t0:t1] = 1.0

    # event_center_mask: single-event sample → full trace for all event stations
    if is_single_event:
        for sta in ps_intervals_per_sta:
            event_center_mask[sta, :] = 1.0

    noise_label = np.maximum(0, 1.0 - p_label - s_label)
    polarity_label = polarity_raw * config.polarity_scale + config.polarity_shift

    # All outputs: (label_ch, nx, nt)
    return {
        "phase_pick": np.stack([noise_label, p_label, s_label], axis=0),  # (3, nx, nt)
        "phase_mask": phase_mask[np.newaxis],  # (1, nx, nt)
        "polarity": polarity_label[np.newaxis],  # (1, nx, nt)
        "polarity_mask": polarity_mask[np.newaxis],  # (1, nx, nt)
        "event_center": event_center_label[np.newaxis],  # (1, nx, nt)
        "event_time": event_time_label[np.newaxis],  # (1, nx, nt)
        "event_center_mask": event_center_mask[np.newaxis],  # (1, nx, nt)
        "event_time_mask": event_time_mask[np.newaxis],  # (1, nx, nt)
    }


# =============================================================================
# Default Transform Presets
# =============================================================================

def default_train_transforms(
    crop_length: int = 4096,
    enable_stacking: bool = True,
    enable_noise_stacking: bool = False,
    augment: bool = True,
) -> Compose:
    """Default transforms for training.

    When augment=False, only Normalize + RandomCrop are applied (for overfit testing).
    """
    if not augment:
        return Compose([Normalize(), RandomCrop(nt=crop_length), Normalize()])

    transforms = [Normalize()]

    if enable_stacking:
        transforms.append(StackEvents(max_events=2, max_shift=4096))

    transforms.append(RandomCrop(nt=crop_length))

    if enable_noise_stacking:
        transforms.append(StackNoise(max_ratio=2.0))

    transforms.append(Normalize())
    return Compose(transforms)


def default_eval_transforms(crop_length: int = 4096) -> Compose:
    """Default transforms for evaluation."""
    return Compose([
        Normalize(),
        RandomCrop(nt=crop_length, deterministic=True),
        Normalize(),
    ])


def minimal_transforms() -> Compose:
    """Minimal transforms — just normalize."""
    return Compose([Normalize()])


# =============================================================================
# Data Loading
# =============================================================================

def get_gcs_storage_options() -> dict:
    """Load GCS credentials for authenticated access."""
    if os.path.exists(GCS_CREDENTIALS_PATH):
        with open(GCS_CREDENTIALS_PATH, "r") as f:
            token = json.load(f)
        return {"token": token}
    return {}


def load_ceed_dataset(
    region: str = "NC,SC",
    split: str = "train",
    streaming: bool = False,
    repo: str = CEED_HF_REPO,
    revision: str = CEED_HF_REVISION,
):
    """Load CEED dataset from HuggingFace Hub.

    The HF repo defines configs (``default``, ``NC``, ``SC``) with
    train (2023-2024) / test (2025) splits.

    Args:
        region: ``"NC,SC"`` (default config), ``"NC"``, or ``"SC"``.
        split: ``"train"`` (2023-2024) or ``"test"`` (2025).
        streaming: If True, stream without downloading.
        repo: HuggingFace dataset repo ID.
        revision: Git branch / tag / commit on the HF repo.

    Returns:
        HuggingFace Dataset object
    """
    from datasets import load_dataset

    config = None if "," in region else region
    return load_dataset(repo, config, split=split, streaming=streaming, revision=revision)


def load_quakeflow_dataset(
    region: str = "NC,SC",
    years: list[int] | None = None,
    batch_size: int = 256,
    shuffle_files: bool = False,
) -> Iterator[dict]:
    """Iterate over QuakeFlow GCS parquet records with zero-copy waveform extraction.

    Parquet waveforms are stored as ``fixed_size_list<fixed_size_list<float>[12288]>[3]``,
    which Arrow can expose as a raw buffer — no Python-list materialisation needed.
    This gives ~66× higher throughput than the old HuggingFace-backed version.

    For training, prefer ``CEEDIterableDataset(source="quakeflow")`` which adds
    transforms, label generation, and DataLoader-worker file sharding on top.

    Args:
        region: ``"SC"``, ``"NC"``, or comma-separated ``"NC,SC"``.
        years: Years to load. ``None`` = all available.
        batch_size: PyArrow ``iter_batches`` batch size.
        shuffle_files: Shuffle parquet file order before iterating.

    Yields:
        Record dicts with ``waveform`` as ``np.ndarray`` of shape ``(3, 12288)``.
    """
    import gcsfs
    import pyarrow.parquet as pq

    storage_opts = get_gcs_storage_options()
    fs = gcsfs.GCSFileSystem(token=storage_opts.get("token"))

    paths: list[str] = []
    for reg in region.split(","):
        bucket_name = REGION_TO_BUCKET.get(reg.strip().upper(), f"quakeflow_{reg.strip().lower()}")
        if years is None:
            paths += fs.glob(f"quakeflow_dataset/{bucket_name}/waveform_parquet/*/*.parquet")
        else:
            for y in years:
                paths += fs.glob(
                    f"quakeflow_dataset/{bucket_name}/waveform_parquet/{y}/*.parquet"
                )

    if shuffle_files:
        random.shuffle(paths)

    for path in paths:
        pf = pq.ParquetFile(fs.open(path))
        non_wave_cols = [f for f in pf.schema_arrow.names if f != "waveform"]
        for batch in pf.iter_batches(batch_size=batch_size):
            n = len(batch)
            # Zero-copy: fixed_size_list[3] → flatten → fixed_size_list[12288] → flatten → float
            col = batch.column("waveform")
            flat = col.flatten().flatten()
            buf = flat.buffers()[1]
            waveforms = np.frombuffer(
                buf, dtype=np.float32, offset=flat.offset * 4
            ).reshape(n, 3, 12288).copy()
            meta = batch.select(non_wave_cols).to_pydict()
            for i in range(n):
                rec = {k: meta[k][i] for k in non_wave_cols}
                rec["waveform"] = waveforms[i]
                yield rec


def calc_snr(
    waveform: np.ndarray,
    p_picks: list[tuple[int, float]],
    noise_window: int = 300,
    signal_window: int = 300,
    gap_window: int = 50,
) -> tuple[float, float, float]:
    """Calculate SNR from waveform and P picks.

    Args:
        waveform: (nch, nx, nt)
        p_picks: [(station_idx, time_idx), ...]
    """
    nch, nx, nt = waveform.shape
    snrs, signals, noises = [], [], []
    for sta, t in p_picks:
        sta, t = int(sta), int(t)
        if 0 <= sta < nx and gap_window < t < nt - gap_window:
            for c in range(nch):
                noise = np.std(waveform[c, sta, max(0, t - noise_window):t - gap_window])
                signal = np.std(waveform[c, sta, t + gap_window:t + signal_window])
                if noise > 0 and signal > 0:
                    snrs.append(signal / noise)
                    signals.append(signal)
                    noises.append(noise)

    if not snrs:
        return 0.0, 0.0, 0.0
    idx = np.argmax(snrs)
    return snrs[idx], signals[idx], noises[idx]


def records_to_sample(records: list[dict],
                      picks_df: "pd.DataFrame | None" = None,
                      labeled_only: bool = False) -> Sample:
    """Convert HuggingFace records for one event into a multi-station Sample.

    All records must belong to the same event. Stations are sorted by distance
    to give spatial coherence along the nx axis.

    Args:
        records: List of HF records (one per station, same event)
        picks_df: Optional DataFrame with predicted picks (station_id,
            phase_index, phase_type). When provided, overrides the inline
            p_phase_index/s_phase_index from records. Supports multiple
            events per station (multiple rows per station_id).
        labeled_only: If True and picks_df is provided, only include stations
            that have at least one pick in picks_df.

    Returns:
        Sample with waveform shape (3, nx, nt) where nx = len(records)
    """
    # Sort by distance for spatial coherence
    records = sorted(records, key=lambda r: r.get("distance_km", 0.0) or 0.0)

    # Optionally filter to only stations with prediction picks
    if labeled_only and picks_df is not None:
        labeled_sids = set(
            picks_df.loc[picks_df["phase_type"].notna(), "station_id"].unique()
        )
        records = [r for r in records
                   if f"{r.get('network','')}.{r.get('station','')}" in labeled_sids]
        if not records:
            return Sample(waveform=np.zeros((3, 0, 0), dtype=np.float32))

    waveforms = []
    trace_ids, sensors, locs = [], [], []
    event_id = records[0].get("event_id", "")

    # Build station_id → sta_idx mapping
    sta_id_to_idx = {}
    for sta_idx, record in enumerate(records):
        w = np.asarray(record["waveform"], dtype=np.float32)
        if w.ndim == 1:
            w = w.reshape(3, -1)
        waveforms.append(w)  # (3, nt)

        net = record.get("network", "")
        sta = record.get("station", "")
        sid = f"{net}.{sta}"
        trace_ids.append(f"{event_id}/{sid}")
        sensors.append(record.get("instrument", ""))
        sta_id_to_idx[sid] = sta_idx

        # Station coordinates (lat, lon, depth_km)
        lat = record.get("station_latitude", 0.0) or 0.0
        lon = record.get("station_longitude", 0.0) or 0.0
        depth = (record.get("station_elevation_m", 0.0) or 0.0) / -1000.0  # elevation → depth
        locs.append([lat, lon, depth])

    waveform = np.stack(waveforms, axis=1)  # (3, nx, nt)

    # Build picks from picks_df (prediction labels) or inline fields (catalog)
    p_picks, s_picks, polarity_picks = [], [], []
    ps_centers, ps_intervals = [], []

    if picks_df is not None:
        # Use prediction labels: multiple picks per station supported
        for _, row in picks_df.iterrows():
            sid = row.get("station_id", "")
            sta_idx = sta_id_to_idx.get(sid)
            if sta_idx is None:
                continue
            if pd.isna(row.get("phase_index")) or pd.isna(row.get("phase_type")):
                continue
            phase_idx = int(row["phase_index"])
            if row["phase_type"] == "P":
                p_picks.append((sta_idx, phase_idx))
            elif row["phase_type"] == "S":
                s_picks.append((sta_idx, phase_idx))

        # Compute ps_centers and ps_intervals from P/S pairs
        p_by_sta: dict[int, list[float]] = {}
        s_by_sta: dict[int, list[float]] = {}
        for idx, t in p_picks:
            p_by_sta.setdefault(idx, []).append(t)
        for idx, t in s_picks:
            s_by_sta.setdefault(idx, []).append(t)
        for idx in set(p_by_sta) & set(s_by_sta):
            for p_t in p_by_sta[idx]:
                for s_t in s_by_sta[idx]:
                    if s_t > p_t:
                        ps_centers.append((idx, (p_t + s_t) / 2))
                        ps_intervals.append((idx, s_t - p_t))
                        break
    else:
        # Use inline catalog labels
        for sta_idx, record in enumerate(records):
            p_idx = record.get("p_phase_index")
            s_idx = record.get("s_phase_index")

            if p_idx is not None:
                p_picks.append((sta_idx, int(p_idx)))
            if s_idx is not None:
                s_picks.append((sta_idx, int(s_idx)))

            pol = record.get("p_phase_polarity")
            if pol == "U" and p_idx is not None:
                polarity_picks.append((sta_idx, int(p_idx), 1))
            elif pol == "D" and p_idx is not None:
                polarity_picks.append((sta_idx, int(p_idx), -1))

            if p_idx is not None and s_idx is not None:
                center = (int(p_idx) + int(s_idx)) / 2
                ps_int = int(s_idx) - int(p_idx)
                ps_centers.append((sta_idx, center))
                ps_intervals.append((sta_idx, ps_int))

    distance_km = records[0].get("distance_km", 0.0) or 0.0
    target = Target(
        p_picks=p_picks,
        s_picks=s_picks,
        polarity=polarity_picks,
        ps_centers=ps_centers,
        ps_intervals=ps_intervals,
        distance_km=distance_km,
        event_id=event_id,
    )

    station_locs = np.array(locs, dtype=np.float32) if locs else None  # (nx, 3)

    return Sample(
        waveform=waveform,
        targets=[target] if not target.is_empty else [],
        sampling_rate=DEFAULT_SAMPLING_RATE,
        trace_ids=trace_ids,
        sensors=sensors,
        station_locs=station_locs,
    )


def record_to_sample(record: dict) -> Sample:
    """Convert a single HF record to a Sample. Thin wrapper around records_to_sample."""
    return records_to_sample([record])


# =============================================================================
# Dataset Classes
# =============================================================================

# SampleBuffer: imported from phasenet.data.transforms

def _pad_crop_nx(tensors: dict[str, torch.Tensor], target_nx: int, training: bool = True) -> dict[str, torch.Tensor]:
    """Pad or crop all tensors along the nx (axis=1) dimension to target_nx."""
    result = {}
    for key, val in tensors.items():
        if not isinstance(val, torch.Tensor):
            result[key] = val
            continue
        if val.ndim < 2:
            result[key] = val
            continue
        nx = val.shape[-2]
        if nx == target_nx:
            result[key] = val
        elif nx < target_nx:
            pad_size = target_nx - nx
            # station_event_index: pad with -1 (no event) instead of 0 (which is event index 0)
            pad_value = -1 if key == "station_event_index" else 0
            result[key] = torch.nn.functional.pad(val, (0, 0, 0, pad_size), value=pad_value)
        else:
            # Crop
            if training:
                start = random.randint(0, nx - target_nx)
            else:
                start = (nx - target_nx) // 2
            result[key] = val[..., start:start + target_nx, :]
    return result



def _validate_sample(sample: Sample, min_snr: float = 0.0) -> bool:
    """Check that sample has valid P picks and meets minimum SNR.

    S picks are optional — most CEED records only have P annotations.
    """
    target = sample.targets[0] if sample.targets else None
    if target is None or ((not target.p_picks) and (not target.s_picks)):
        return False
    target.snr, target.amp_signal, target.amp_noise = calc_snr(
        sample.waveform, target.p_picks,
    )
    return target.snr >= min_snr and target.snr > 0


def _to_output(
    sample: Sample,
    label_config: LabelConfig,
    event_feature_scale: int,
    target_nx: int | None = None,
    training: bool = True,
) -> dict[str, torch.Tensor]:
    """Convert transformed Sample to output dict with labels."""
    labels = generate_labels(sample, label_config)
    s = event_feature_scale
    out = {
        "data": torch.nan_to_num(torch.from_numpy(sample.waveform).float()),
        "phase_pick": torch.from_numpy(labels["phase_pick"]).float(),
        "phase_mask": torch.from_numpy(labels["phase_mask"]).float(),
        "polarity": torch.from_numpy(labels["polarity"]).float(),
        "polarity_mask": torch.from_numpy(labels["polarity_mask"]).float(),
        "event_center": torch.from_numpy(labels["event_center"]).float()[:, :, ::s],
        "event_time": torch.from_numpy(labels["event_time"]).float()[:, :, ::s],
        "event_center_mask": torch.from_numpy(labels["event_center_mask"]).float()[:, :, ::s],
        "event_time_mask": torch.from_numpy(labels["event_time_mask"]).float()[:, :, ::s],
    }
    if sample.station_event_index is not None:
        # (nx,) → (1, nx, 1) to match tensor layout for _pad_crop_nx
        em = torch.from_numpy(sample.station_event_index).long().unsqueeze(0).unsqueeze(-1)
        out["station_event_index"] = em  # (1, nx, 1)
    if sample.station_locs is not None:
        # Project lat/lon to local (x_km, y_km) through median center
        xy_km = _station_xy_km(sample.station_locs)  # (nx, 2)
        # Reshape to (2, nx, 1) so _pad_crop_nx pads along axis -2 (=nx)
        out["station_locs_km"] = torch.from_numpy(xy_km.T).float().unsqueeze(-1)  # (2, nx, 1)
    if target_nx is not None:
        out = _pad_crop_nx(out, target_nx, training=training)
    return out


class CEEDDataset(Dataset):
    """California Earthquake Event Dataset — Map-style Dataset.

    Args:
        region: "NC,SC" (default), "NC", or "SC"
        split: "train" (2023-2024) or "test" (2025)
        transforms: Transform pipeline
        label_config: Configuration for label generation
        min_snr: Minimum SNR to include sample
        buffer_size: Size of sample buffer for stacking
        group_by: How to group records — "event" for multi-station (nx=N),
            "station" for single-station (nx=1)
        target_nx: When group_by="event", pad/crop nx to this size for batching
        event_feature_scale: Downsampling factor for event labels along time
    """

    def __init__(
        self,
        region: str = "NC,SC",
        split: str = "train",
        transforms: Transform | None = None,
        label_config: LabelConfig = LabelConfig(),
        min_snr: float = 0.0,
        buffer_size: int = 1000,
        group_by: str = "station",
        target_nx: int | None = None,
        event_feature_scale: int = 16,
    ):
        self.transforms = transforms or minimal_transforms()
        self.label_config = label_config
        self.min_snr = min_snr
        self.group_by = group_by
        self.target_nx = target_nx if group_by == "event" else None
        self.event_feature_scale = event_feature_scale

        hf_dataset = load_ceed_dataset(region, split=split, streaming=False)

        self.samples: list[Sample] = []
        if group_by == "station":
            for record in hf_dataset:
                sample = record_to_sample(record)
                if _validate_sample(sample, min_snr):
                    self.samples.append(sample)
        else:
            records_by_event: dict[str, list] = defaultdict(list)
            for record in hf_dataset:
                eid = record.get("event_id", "")
                if eid:
                    records_by_event[eid].append(record)
            for event_records in records_by_event.values():
                sample = records_to_sample(event_records)
                if _validate_sample(sample, min_snr):
                    self.samples.append(sample)

        self.sample_buffer = SampleBuffer(buffer_size)
        for s in random.sample(self.samples, min(buffer_size, len(self.samples))):
            self.sample_buffer.add(s)

        self._setup_stacking_transforms()
        print(f"CEEDDataset ({group_by}): loaded {len(self.samples)} samples")

    def _setup_stacking_transforms(self):
        if isinstance(self.transforms, Compose):
            for t in self.transforms.transforms:
                if isinstance(t, (StackEvents, StackNoise)):
                    t.set_sample_fn(self.sample_buffer.get_random)

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        sample = self.samples[idx].copy(deep_waveform=True)
        sample = self.transforms(sample)
        return _to_output(sample, self.label_config, self.event_feature_scale, self.target_nx, training=True)


class CEEDIterableDataset(IterableDataset):
    """Iterable dataset for seismic phase picking, backed by either source:

    - ``source="ceed"``: streams from the HuggingFace Hub repo (``AI4EPS/CEED``).
      Use ``split="train"`` (2023-2024) or ``split="test"`` (2025).
    - ``source="quakeflow"``: streams directly from GCS (``gs://quakeflow_dataset``)
      using zero-copy PyArrow reads — ~66× faster waveform extraction than the
      HuggingFace path. Use ``years=[2021, 2022, 2023]`` to select specific years.
      DataLoader workers are sharded by file (one parquet per year).

    Args:
        source: ``"ceed"`` (HuggingFace Hub) or ``"quakeflow"`` (GCS direct).
        region: ``"NC,SC"`` (default), ``"NC"``, or ``"SC"``.
        split: ``"train"`` or ``"test"``. Used by ``source="ceed"`` only.
        years: List of years to load. ``None`` = all available. QuakeFlow only.
        shuffle_files: Shuffle parquet file order each epoch. QuakeFlow only.
        transforms: Transform pipeline.
        label_config: Configuration for label generation.
        min_snr: Minimum SNR to include a sample.
        buffer_size: Size of sample buffer for stacking transforms.
        group_by: ``"station"`` for single-station (nx=1) or ``"event"`` for
            multi-station (nx=N).
        target_nx: When ``group_by="event"``, pad/crop nx to this size.
        event_feature_scale: Downsampling factor for event labels along time.
        streaming: Stream without downloading. ``source="ceed"`` only.
        overfit: ``"fixed"`` (same crop) or ``"random"`` (different crops).
        training: If ``False``, stop after one pass through the data.
    """

    def __init__(
        self,
        source: str = "ceed",
        region: str = "NC,SC",
        split: str = "train",
        years: list[int] | None = None,
        shuffle_files: bool = True,
        transforms: Transform | None = None,
        label_config: LabelConfig = LabelConfig(),
        label_path: str | None = None,
        label_list: list[str] | str | None = None,
        labeled_only: bool = False,
        min_snr: float = 0.0,
        buffer_size: int = 1000,
        group_by: str = "station",
        target_nx: int | None = None,
        event_feature_scale: int = 16,
        streaming: bool = True,
        overfit: str | None = None,
        training: bool = True,
    ):
        self.source = source
        self.region = region
        self.split = split
        self.streaming = streaming
        self.transforms = transforms or minimal_transforms()
        self.label_config = label_config
        self.min_snr = min_snr
        self.buffer_size = buffer_size
        self.event_feature_scale = event_feature_scale
        self.group_by = group_by
        self.target_nx = target_nx if group_by == "event" else None
        self.overfit = overfit
        self.training = training

        # Prediction label directory (e.g. "results/ceed").
        # Labels are loaded per day file during iteration to match waveform streaming.
        self.label_path = label_path
        self.labeled_only = labeled_only
        self.label_list = label_list
        self._picks_by_event: dict[str, pd.DataFrame] | None = None

        if source == "quakeflow":
            import gcsfs
            storage_opts = get_gcs_storage_options()
            self._fs = gcsfs.GCSFileSystem(token=storage_opts.get("token"))
            self._gcs_paths = self._resolve_gcs_paths(region, years)
            # Filter to only days that have labels
            if label_list is not None:
                label_days = self._parse_label_list(label_list)
                if label_days:
                    self._gcs_paths = [
                        p for p in self._gcs_paths
                        if os.path.splitext(os.path.basename(p))[0] in label_days
                    ]
            elif label_path is not None:
                # Auto-discover: keep only GCS paths with corresponding label files
                # Label filename "2025_001.parquet" → key "2025_001"
                # GCS path ".../waveform_parquet/2025/001.parquet" → key "2025_001"
                import glob as globmod
                available = set()
                for region_code in self._REGION_MAP.values():
                    for f in globmod.glob(os.path.join(label_path, region_code, "*.parquet")):
                        available.add(os.path.splitext(os.path.basename(f))[0])
                if available:
                    def _gcs_to_key(p):
                        parts = p.split("/")
                        return f"{parts[-2]}_{os.path.splitext(parts[-1])[0]}"
                    self._gcs_paths = [
                        p for p in self._gcs_paths if _gcs_to_key(p) in available
                    ]
                    print(f"CEEDIterableDataset: filtered to {len(self._gcs_paths)} "
                          f"day files with labels")
            self.shuffle_files = shuffle_files
        else:
            # Resolve HF dataset once in main process; forked workers inherit it.
            self._hf_dataset = load_ceed_dataset(
                region, split=split, streaming=streaming,
            )

    def _resolve_gcs_paths(self, region: str, years: list[int] | None) -> list[str]:
        paths: list[str] = []
        for reg in region.split(","):
            bucket_name = REGION_TO_BUCKET.get(reg.strip().upper(), f"quakeflow_{reg.strip().lower()}")
            if years is None:
                paths += self._fs.glob(
                    f"quakeflow_dataset/{bucket_name}/waveform_parquet/*/*.parquet"
                )
            else:
                for y in years:
                    paths += self._fs.glob(
                        f"quakeflow_dataset/{bucket_name}/waveform_parquet/{y}/*.parquet"
                    )
        return paths

    # Map GCS bucket region name → label subfolder name
    _REGION_MAP = {"NCEDC": "NC", "SCEDC": "SC"}

    @staticmethod
    def _parse_label_list(label_list: list[str] | str) -> set[str]:
        """Parse label_list into a set of day identifiers (e.g. {"001", "002"}).

        label_list can be a text file path or a list of day strings/file paths.
        Extracts the day number from filenames like "2025_001.parquet" or just "001".
        """
        if isinstance(label_list, str):
            with open(label_list) as f:
                items = [ln.strip() for ln in f if ln.strip()]
        else:
            items = list(label_list)

        days = set()
        for item in items:
            stem = os.path.splitext(os.path.basename(item))[0]
            # Handle "2025_001" → "001", or just "001"
            if "_" in stem:
                days.add(stem.split("_", 1)[1])
            else:
                days.add(stem)
        return days

    def _load_day_labels(self, gcs_path: str) -> None:
        """Load prediction labels for one day file, indexed by event_id.

        GCS path like "quakeflow_dataset/NCEDC/waveform_parquet/2025/001.parquet"
        maps to label path like "results/ceed/NC/2025_001.parquet".
        """
        if self.label_path is None:
            self._picks_by_event = None
            return

        # Extract region and day from GCS path
        # quakeflow_dataset/NCEDC/waveform_parquet/2025/001.parquet
        parts = gcs_path.replace("gs://", "").split("/")
        gcs_region = parts[1]   # "NCEDC"
        year = parts[3]         # "2025"
        day = parts[4].replace(".parquet", "")  # "001"

        region = self._REGION_MAP.get(gcs_region, gcs_region)
        label_file = os.path.join(self.label_path, region, f"{year}_{day}.parquet")

        if os.path.exists(label_file):
            df = pd.read_parquet(label_file)
            self._picks_by_event = {
                eid: group for eid, group in df.groupby("event_id")
            }
        else:
            self._picks_by_event = None

    def _get_picks_df(self, event_id: str) -> "pd.DataFrame | None":
        """Look up prediction labels for an event, or None for catalog labels."""
        if self._picks_by_event is None:
            return None
        return self._picks_by_event.get(event_id)

    def _iter_gcs_records(self, paths: list[str]) -> Iterator[dict]:
        """Yield records with waveforms as numpy arrays via zero-copy Arrow buffers."""
        import pyarrow.parquet as pq
        for path in paths:
            # Load prediction labels for this day file (if label_path is set)
            self._load_day_labels(path)
            pf = pq.ParquetFile(self._fs.open(path))
            non_wave_cols = [f for f in pf.schema_arrow.names if f != "waveform"]
            for batch in pf.iter_batches(batch_size=256):
                n = len(batch)
                col = batch.column("waveform")
                flat = col.flatten().flatten()
                buf = flat.buffers()[1]
                waveforms = np.frombuffer(
                    buf, dtype=np.float32, offset=flat.offset * 4
                ).reshape(n, 3, 12288).copy()
                meta = batch.select(non_wave_cols).to_pydict()
                for i in range(n):
                    rec = {k: meta[k][i] for k in non_wave_cols}
                    rec["waveform"] = waveforms[i]
                    yield rec

    def _emit_and_buffer(self, sample: Sample, sample_buffer: SampleBuffer) -> Sample | None:
        if not _validate_sample(sample, self.min_snr):
            return None
        sample_buffer.add(sample)
        return sample

    def _init_iter(self):
        """Return a record iterable and sample buffer, sharded across workers."""
        sample_buffer = SampleBuffer(self.buffer_size)
        if isinstance(self.transforms, Compose):
            for t in self.transforms.transforms:
                if isinstance(t, (StackEvents, StackNoise)):
                    t.set_sample_fn(sample_buffer.get_random)
        worker_info = torch.utils.data.get_worker_info()

        if self.source == "quakeflow":
            paths = list(self._gcs_paths)
            if self.shuffle_files:
                import random
                random.shuffle(paths)
            if worker_info is not None:
                # Shard by file: each worker reads a disjoint subset.
                paths = [p for i, p in enumerate(paths)
                         if i % worker_info.num_workers == worker_info.id]
            records = self._iter_gcs_records(paths)
        else:
            records = self._hf_dataset
            if worker_info is not None and self.streaming:
                from datasets.distributed import split_dataset_by_node
                records = split_dataset_by_node(
                    records, rank=worker_info.id, world_size=worker_info.num_workers,
                )
        return records, sample_buffer, worker_info

    def __iter__(self) -> Iterator[dict[str, torch.Tensor]]:
        iter_fn = self._iter_by_station if self.group_by == "station" else self._iter_by_event
        while True:
            records, sample_buffer, worker_info = self._init_iter()
            yield from iter_fn(records, sample_buffer, worker_info)
            if not self.training:
                return

    def _emit_noise_sample(self, sample: Sample) -> dict[str, torch.Tensor]:
        """Create a pure-noise sample for negative training."""
        noise_sample = Sample(
            waveform=np.random.randn(*sample.waveform.shape).astype(np.float32),
            targets=[],
            sampling_rate=sample.sampling_rate,
        )
        noise_sample = Normalize()(noise_sample)
        out = _to_output(noise_sample, self.label_config, self.event_feature_scale,
                         self.target_nx, training=self.training)
        out["phase_mask"] = torch.ones_like(out["phase_mask"])
        out["event_center_mask"] = torch.ones_like(out["event_center_mask"])
        out["raw_data"] = out["data"].clone()
        return out

    def _emit_sample(self, sample: Sample) -> dict[str, torch.Tensor]:
        """Transform a sample and convert to output dict."""
        # ~10% chance: yield a pure noise sample for negative training
        if self.training and random.random() < 0.1:
            return self._emit_noise_sample(sample)
        s = sample.copy(deep_waveform=True)
        raw_waveform = s.waveform.copy()
        s = self.transforms(s)
        out = _to_output(s, self.label_config, self.event_feature_scale,
                         self.target_nx, training=self.training)
        # Save raw waveform (before transforms) for visualization
        raw = torch.nan_to_num(torch.from_numpy(raw_waveform).float())
        if self.target_nx is not None:
            # Pad/crop to match target_nx
            _, nx_raw, _ = raw.shape
            if nx_raw < self.target_nx:
                raw = torch.nn.functional.pad(raw, (0, 0, 0, self.target_nx - nx_raw))
            elif nx_raw > self.target_nx:
                raw = raw[:, :self.target_nx, :]
        out["raw_data"] = raw[:, :, :out["data"].shape[-1]]
        return out

    def _iter_by_station(self, records, sample_buffer, worker_info):
        """Each record → single-station Sample (nx=1). No grouping needed."""
        for record in records:
            eid = record.get("event_id")
            if not eid:
                continue
            picks_df = self._get_picks_df(eid)
            sample = self._emit_and_buffer(
                records_to_sample([record], picks_df=picks_df,
                                  labeled_only=self.labeled_only), sample_buffer
            )
            if sample is not None:
                yield self._emit_sample(sample)

    def _build_packed_sample(self, records_window, event_ids_window, sample_buffer):
        """Build a Sample from a packed window of traces from multiple events.

        Preserves the original station order within each event (already sorted
        by distance in the source parquet). Sets station_event_index to track which
        event each trace belongs to.
        """
        waveforms = []
        trace_ids, sensors, locs = [], [], []
        targets = []
        station_event_index = np.zeros(len(records_window), dtype=np.int32)
        groups: dict[str, list[tuple[int, dict]]] = {}  # eid → [(sta_idx, record)]

        eid_to_idx: dict[str, int] = {}
        for sta_idx, (record, eid) in enumerate(zip(records_window, event_ids_window)):
            if eid not in eid_to_idx:
                eid_to_idx[eid] = len(eid_to_idx)
            station_event_index[sta_idx] = eid_to_idx[eid]
            groups.setdefault(eid, []).append((sta_idx, record))

            w = np.asarray(record["waveform"], dtype=np.float32)
            if w.ndim == 1:
                w = w.reshape(3, -1)
            waveforms.append(w)
            net = record.get("network", "")
            sta = record.get("station", "")
            trace_ids.append(f"{eid}/{net}.{sta}")
            sensors.append(record.get("instrument", ""))

            lat = record.get("station_latitude", 0.0) or 0.0
            lon = record.get("station_longitude", 0.0) or 0.0
            depth = (record.get("station_elevation_m", 0.0) or 0.0) / -1000.0
            locs.append([lat, lon, depth])

        waveform = np.stack(waveforms, axis=1)  # (3, nx, nt)

        # Build one Target per origin (origin_id groups P/S pairs correctly)
        for eid, sta_records in groups.items():
            picks_df = self._get_picks_df(eid)

            if picks_df is not None:
                # Build station_id → sta_idx mapping and polarity lookup from source records
                labeled_sids = {}
                polarity_by_sid: dict[str, int] = {}  # station_id → polarity sign
                for sta_idx, rec in sta_records:
                    sid = f"{rec.get('network','')}.{rec.get('station','')}"
                    labeled_sids[sid] = sta_idx
                    pol = rec.get("p_phase_polarity")
                    if pol == "U":
                        polarity_by_sid[sid] = 1
                    elif pol == "D":
                        polarity_by_sid[sid] = -1

                # Filter to valid picks with station mapping
                valid = picks_df[
                    picks_df["station_id"].isin(labeled_sids)
                    & picks_df["phase_index"].notna()
                    & picks_df["phase_type"].notna()
                ].copy()
                if valid.empty:
                    continue

                # Group by origin_id — each origin becomes one Target
                origin_col = "origin_id" if "origin_id" in valid.columns else None
                if origin_col and valid[origin_col].notna().any():
                    origin_groups = valid.groupby(origin_col)
                else:
                    origin_groups = [("0", valid)]

                for oid, origin_df in origin_groups:
                    p_picks, s_picks, polarity_picks = [], [], []
                    ps_centers, ps_intervals = [], []
                    for _, row in origin_df.iterrows():
                        sid = row["station_id"]
                        sta_idx = labeled_sids[sid]
                        phase_idx = int(row["phase_index"])
                        if row["phase_type"] == "P":
                            p_picks.append((sta_idx, phase_idx))
                            # Add polarity from source record at the predicted P time
                            if sid in polarity_by_sid:
                                polarity_picks.append((sta_idx, phase_idx, polarity_by_sid[sid]))
                        elif row["phase_type"] == "S":
                            s_picks.append((sta_idx, phase_idx))
                    # P/S are from same origin — simple dict pairing works
                    p_by_sta = {s: t for s, t in p_picks}
                    s_by_sta = {s: t for s, t in s_picks}
                    for s in set(p_by_sta) & set(s_by_sta):
                        if s_by_sta[s] > p_by_sta[s]:
                            ps_centers.append((s, (p_by_sta[s] + s_by_sta[s]) / 2))
                            ps_intervals.append((s, s_by_sta[s] - p_by_sta[s]))
                    target = Target(
                        p_picks=p_picks, s_picks=s_picks, polarity=polarity_picks,
                        ps_centers=ps_centers, ps_intervals=ps_intervals,
                        event_id=f"{eid}_{oid}",
                    )
                    if not target.is_empty:
                        targets.append(target)

            elif self.label_path is None:
                # Catalog inline labels (only when no label_path is set)
                p_picks, s_picks, polarity_picks = [], [], []
                ps_centers, ps_intervals = [], []
                for sta_idx, rec in sta_records:
                    p_idx = rec.get("p_phase_index")
                    s_idx = rec.get("s_phase_index")
                    if p_idx is not None:
                        p_picks.append((sta_idx, int(p_idx)))
                    if s_idx is not None:
                        s_picks.append((sta_idx, int(s_idx)))
                    pol = rec.get("p_phase_polarity")
                    if pol == "U" and p_idx is not None:
                        polarity_picks.append((sta_idx, int(p_idx), 1))
                    elif pol == "D" and p_idx is not None:
                        polarity_picks.append((sta_idx, int(p_idx), -1))
                p_by_sta = {s: t for s, t in p_picks}
                s_by_sta = {s: t for s, t in s_picks}
                for s in set(p_by_sta) & set(s_by_sta):
                    if s_by_sta[s] > p_by_sta[s]:
                        ps_centers.append((s, (p_by_sta[s] + s_by_sta[s]) / 2))
                        ps_intervals.append((s, s_by_sta[s] - p_by_sta[s]))
                target = Target(
                    p_picks=p_picks, s_picks=s_picks, polarity=polarity_picks,
                    ps_centers=ps_centers, ps_intervals=ps_intervals,
                    event_id=eid,
                )
                if not target.is_empty:
                    targets.append(target)

        station_locs = np.array(locs, dtype=np.float32) if locs else None

        sample = Sample(
            waveform=waveform,
            targets=targets,
            sampling_rate=DEFAULT_SAMPLING_RATE,
            trace_ids=trace_ids,
            sensors=sensors,
            station_event_index=station_event_index,
            station_locs=station_locs,
        )
        return self._emit_and_buffer(sample, sample_buffer)

    def _iter_by_event(self, records, sample_buffer, worker_info):
        """Pack traces into fixed-size windows of target_nx stations.

        Loops through traces sequentially. When the buffer reaches target_nx
        traces, emits a sample. Multiple small events are packed together;
        large events span multiple windows. station_event_index tracks which event
        each trace belongs to.

        If target_nx is None, falls back to one sample per event.
        """
        if self.target_nx is None:
            # No packing — emit one sample per event
            cur_eid: str | None = None
            cur_records: list[dict] = []
            for record in records:
                eid = record.get("event_id", "")
                if not eid:
                    continue
                if eid != cur_eid:
                    if cur_eid and cur_records:
                        picks_df = self._get_picks_df(cur_eid)
                        sample = self._emit_and_buffer(
                            records_to_sample(cur_records, picks_df=picks_df,
                                              labeled_only=self.labeled_only),
                            sample_buffer,
                        )
                        if sample is not None:
                            yield self._emit_sample(sample)
                    cur_eid = eid
                    cur_records = [record]
                else:
                    cur_records.append(record)
            if cur_eid and cur_records:
                picks_df = self._get_picks_df(cur_eid)
                sample = self._emit_and_buffer(
                    records_to_sample(cur_records, picks_df=picks_df,
                                      labeled_only=self.labeled_only),
                    sample_buffer,
                )
                if sample is not None:
                    yield self._emit_sample(sample)
            return

        # Pack traces into windows of target_nx
        buf_records: list[dict] = []
        buf_eids: list[str] = []

        for record in records:
            eid = record.get("event_id", "")
            if not eid:
                continue
            buf_records.append(record)
            buf_eids.append(eid)

            if len(buf_records) >= self.target_nx:
                window_records = buf_records[:self.target_nx]
                window_eids = buf_eids[:self.target_nx]
                buf_records = buf_records[self.target_nx:]
                buf_eids = buf_eids[self.target_nx:]

                sample = self._build_packed_sample(
                    window_records, window_eids, sample_buffer
                )
                if sample is not None:
                    yield self._emit_sample(sample)

        # Emit remaining traces (zero-padded to target_nx)
        if buf_records:
            sample = self._build_packed_sample(
                buf_records, buf_eids, sample_buffer
            )
            if sample is not None:
                yield self._emit_sample(sample)


# =============================================================================
# Convenience Functions
# =============================================================================

def create_train_dataset(
    region: str = "NC,SC",
    crop_length: int = 4096,
    streaming: bool = False,
    **kwargs,
) -> Dataset | IterableDataset:
    """Create a training dataset with default augmentation."""
    transforms = default_train_transforms(crop_length=crop_length)

    if streaming:
        return CEEDIterableDataset(
            region=region, split="train",
            transforms=transforms, **kwargs,
        )
    return CEEDDataset(
        region=region, split="train",
        transforms=transforms, **kwargs,
    )


def create_eval_dataset(
    region: str = "NC,SC",
    crop_length: int = 4096,
    streaming: bool = False,
    **kwargs,
) -> Dataset | IterableDataset:
    """Create an evaluation dataset without augmentation."""
    transforms = default_eval_transforms(crop_length=crop_length)

    if streaming:
        return CEEDIterableDataset(
            region=region, split="test",
            transforms=transforms, **kwargs,
        )
    return CEEDDataset(
        region=region, split="test",
        transforms=transforms, **kwargs,
    )


# =============================================================================
# Plotting
# =============================================================================

def plot_trace(
    sample: Sample,
    labels: dict[str, np.ndarray],
    sta: int = 0,
    title: str = "",
    save_path: str = "ceed_trace.png",
):
    """Plot a single station from a multi-station Sample with labels (5-panel vertical stack).

    Layout:
        [1] Waveform (E/N/Z components) with P/S pick lines
        [2] P/S zoom-in (1s waveform at P and S picks, side by side)
        [3] Phase labels + phase_mask
        [4] Polarity label + polarity_mask
        [5] Event center + event_time + masks
    """
    import matplotlib.pyplot as plt

    nt = sample.nt
    t = np.arange(nt)
    waveform_z = sample.waveform[2, sta]  # Z component at station sta
    one_sec = int(sample.sampling_rate)

    p_times = [ti for tgt in sample.targets for s, ti in tgt.p_picks if int(s) == sta]
    s_times = [ti for tgt in sample.targets for s, ti in tgt.s_picks if int(s) == sta]

    fig, axes = plt.subplots(5, 1, figsize=(12, 10), gridspec_kw={"height_ratios": [2, 1, 1, 1, 1]})

    # Estimate one origin time per event target using P-S pairs at this station.
    # Iterating per-target ensures cross-event pairing is avoided.
    origin_times = []
    for tgt in sample.targets:
        p_sta = sorted(ti for s, ti in tgt.p_picks if int(s) == sta)
        s_sta = sorted(ti for s, ti in tgt.s_picks if int(s) == sta)
        for pt in p_sta:
            for st in s_sta:
                if st > pt:
                    dt_ps = st - pt  # samples
                    t0_origin = pt - dt_ps / (VP_VS_RATIO - 1)
                    origin_times.append(t0_origin)
                    break

    # [1] Waveform
    ax = axes[0]
    for i, name in enumerate(["E", "N", "Z"]):
        ax.plot(t, sample.waveform[i, sta] / 3 + i, label=name, alpha=0.7, linewidth=0.5)
    for pt in p_times:
        ax.axvline(pt, color="red", alpha=0.5, linewidth=0.8)
    for st in s_times:
        ax.axvline(st, color="blue", alpha=0.5, linewidth=0.8)
    for ot in origin_times:
        ax.axvline(ot, color="green", alpha=0.7, linewidth=0.8, linestyle="--", label="Origin" if ot == origin_times[0] else None)
    ax.set_ylabel("Waveform")
    ax.set_xlim(0, nt)
    ax.legend(loc="upper right", fontsize=8)

    # [2] P/S zoom-in
    ax = axes[1]
    ax.set_axis_off()
    for pick_t, color, label, x_pos in [
        (p_times[0] if p_times else None, "red", "P", 0.0),
        (s_times[0] if s_times else None, "blue", "S", 0.52),
    ]:
        if pick_t is None:
            continue
        inset = ax.inset_axes([x_pos, 0.0, 0.46, 1.0])
        t0 = max(0, int(pick_t) - one_sec // 4)
        t1 = min(nt, t0 + one_sec)
        inset.plot(t[t0:t1], waveform_z[t0:t1], "k", linewidth=0.8)
        inset.axvline(pick_t, color=color, linewidth=1.0, alpha=0.8)
        inset.set_title(f"{label} zoom (t={pick_t:.0f})", fontsize=9)
        inset.tick_params(labelsize=7)

    def _draw_origin_vlines(ax, add_legend: bool = False):
        for ot in origin_times:
            ax.axvline(ot, color="green", alpha=0.7, linewidth=0.8, linestyle="--")
        if add_legend and origin_times:
            ax.plot([], [], color="green", linewidth=0.8, linestyle="--", label="Origin")

    # [3] Phase labels + mask — labels are (label_ch, nx, nt)
    ax = axes[2]
    ax.plot(t, labels["phase_pick"][1, sta], label="P", color="red")
    ax.plot(t, labels["phase_pick"][2, sta], label="S", color="blue")
    ax.fill_between(t, labels["phase_mask"][0, sta], alpha=0.15, color="green", label="mask")
    _draw_origin_vlines(ax, add_legend=True)
    ax.set_ylabel("Phase Labels")
    ax.set_ylim(-0.05, 1.1)
    ax.set_xlim(0, nt)
    ax.legend(loc="upper right", fontsize=8)

    # [4] Polarity + mask
    ax = axes[3]
    ax.plot(t, labels["polarity"][0, sta], label="Polarity", color="green")
    ax.fill_between(t, labels["polarity_mask"][0, sta], alpha=0.15, color="green")
    ax.axhline(0.5, color="gray", linestyle="--", alpha=0.5)
    _draw_origin_vlines(ax)
    ax.set_ylabel("Polarity")
    ax.set_ylim(-0.05, 1.1)
    ax.set_xlim(0, nt)
    ax.legend(loc="upper right", fontsize=8)

    # [5] Event center + event_time + masks
    ax = axes[4]
    ax.plot(t, labels["event_center"][0, sta], label="Event Center", color="purple")
    ax.fill_between(t, labels["event_center_mask"][0, sta], alpha=0.1, color="green", label="Center Mask")
    ax.fill_between(t, labels["event_time_mask"][0, sta], alpha=0.2, color="green", label="Time Mask")
    _draw_origin_vlines(ax)
    ax.set_ylabel("Event")
    ax.set_xlabel("Time Sample")
    ax.set_xlim(0, nt)
    ax.legend(loc="upper right", fontsize=8)
    ax2 = ax.twinx()
    et = np.abs(labels["event_time"][0, sta])
    ax2.plot(t, et, color="orange", linewidth=1.0, alpha=0.7)
    ax2.set_ylabel("|Event Time|", color="orange")
    ax2.set_ylim(0, None)
    ax2.tick_params(axis="y", labelcolor="orange")

    if title:
        fig.suptitle(title, fontsize=12, fontweight="bold")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_overview(
    sample: Sample,
    config: LabelConfig = LabelConfig(),
    title: str = "",
    save_path: str = "ceed_overview.png",
    plot_labels: bool = False,
    all_picks: "list[dict] | None" = None,
):
    """Plot multi-station view of one event.

    Sample has waveform (3, nx, nt). Stations already sorted by distance.

    When plot_labels=False (default): single panel with waveform + picks.
    When plot_labels=True: 2x2 grid with labels and event time.

    Args:
        all_picks: list of pick dicts from detect_picks. If provided,
            shows unassociated picks in light colors. Uses station_id key.
    """
    import matplotlib.pyplot as plt

    ns = sample.nx
    nt = sample.nt
    wf = sample.waveform  # (3, nx, nt)

    if plot_labels:
        labels = generate_labels(sample, config)
        p_disp = labels["phase_pick"][1].T
        s_disp = labels["phase_pick"][2].T
        phase_mask = labels["phase_mask"][0].T
        event_center = labels["event_center"][0].T
        event_center_mask = labels["event_center_mask"][0].T
        event_time_mask = labels["event_time_mask"][0].T

    vp, vs = config.vp, config.vp / config.vp_vs_ratio
    t = np.arange(nt)
    dt_s = 1.0 / sample.sampling_rate
    event_time_arr = np.zeros((ns, nt), dtype=np.float32)
    _et_best_abs = np.full((ns, nt), np.inf, dtype=np.float32)
    for tgt in sample.targets:
        for (sta, center), (_, ps_int) in zip(tgt.ps_centers, tgt.ps_intervals):
            sta = int(sta)
            if 0 <= sta < ns:
                ps_seconds = ps_int * dt_s
                distance = ps_seconds * vp * vs / (vp - vs)
                shift = distance * (1 / vp + 1 / vs) / (2 * dt_s)
                new_vals = (t - center) + shift
                better = np.abs(new_vals) < _et_best_abs[sta]
                event_time_arr[sta, better] = new_vals[better]
                _et_best_abs[sta, better] = np.abs(new_vals[better])
    event_time_disp = event_time_arr.T  # (nt, nx)

    if plot_labels:
        fig, axes = plt.subplots(2, 2, figsize=(14, 8))
    else:
        fig, ax_single = plt.subplots(1, 1, figsize=(8, 8))
    imshow_kwargs = dict(aspect="auto", interpolation="nearest")

    dt_s_plot = 1.0 / sample.sampling_rate
    total_s = nt * dt_s_plot

    def _nice_step(total: float, n: int = 6) -> float:
        if total <= 0:
            return 1.0
        raw = total / n
        exp = 10 ** int(np.floor(np.log10(raw + 1e-10)))
        return max(exp, round(raw / exp) * exp)

    y_step = _nice_step(total_s)
    y_s = np.arange(0, total_s + y_step * 0.01, y_step)
    y_idx = y_s / dt_s_plot
    x_ticks = np.arange(0, ns, max(1, ns // 6))

    def _set_phys_axes(ax, *, xlabel: bool = True, ylabel: bool = True) -> None:
        ax.set_xticks(x_ticks)
        ax.set_xticklabels([str(int(x)) for x in x_ticks], fontsize=8)
        ax.set_yticks(y_idx)
        ax.set_yticklabels([f"{s:.0f}" for s in y_s], fontsize=8)
        if xlabel:
            ax.set_xlabel("Station (sorted by distance)")
        if ylabel:
            ax.set_ylabel("Time (s)")

    # Moving window normalization
    # norm_z = np.sign(waveform_z) * np.log1p(np.abs(waveform_z))
    _win, _stride = 1024, 256
    _starts = np.arange(0, nt, _stride)
    _centers = np.clip(_starts + _win // 2, 0, nt - 1).astype(float)
    _t = np.arange(nt, dtype=float)
    # Per-channel moving window mean: (3, ns, n_wins)
    _mean_wins = np.stack(
        [wf[:, :, s:min(s + _win, nt)].mean(axis=2) for s in _starts], axis=2
    )
    # Moving window std from all 3 demeaned channels: (ns, n_wins)
    _std_wins = np.stack([
        (wf[:, :, s:min(s + _win, nt)]
         - wf[:, :, s:min(s + _win, nt)].mean(axis=2, keepdims=True)).std(axis=(0, 2))
        for s in _starts
    ], axis=1)
    # Interpolate to full time axis
    _mean_z_full = np.array(
        [np.interp(_t, _centers, _mean_wins[2, i]) for i in range(ns)]
    )  # (ns, nt) — Z channel mean
    _std_full = np.array(
        [np.interp(_t, _centers, _std_wins[i]) for i in range(ns)]
    )  # (ns, nt)
    norm_z = (wf[2] - _mean_z_full) / (_std_full + 1e-10)  # (nx, nt)
    scale = 0.5 / 3

    # [1,1] Waveform (Z) — wiggle traces (only in full layout)
    if plot_labels:
        ax = axes[0, 0]
        for i in range(ns):
            ax.plot(norm_z[i] * scale + i, np.arange(nt), "k", linewidth=0.3)
        ax.set_xlim(-1, ns)
        ax.set_ylim(nt, 0)
        ax.set_title("Waveform (Z)")
        _set_phys_axes(ax, xlabel=False, ylabel=True)

    # Waveform + picks + estimated origin times
    ax = axes[0, 1] if plot_labels else ax_single
    for i in range(ns):
        ax.plot(norm_z[i] * scale + i, np.arange(nt), color="0.6", linewidth=0.3)
    hw = 0.4

    # Build associated pick set
    assoc_set = set()
    for tgt in sample.targets:
        for sta, idx in tgt.p_picks:
            assoc_set.add((int(sta), int(idx), "P"))
        for sta, idx in tgt.s_picks:
            assoc_set.add((int(sta), int(idx), "S"))

    # Unassociated picks (light colors)
    n_unassoc_p, n_unassoc_s = 0, 0
    if all_picks is not None:
        tid_to_idx = {tid: i for i, tid in enumerate(sample.trace_ids)} if hasattr(sample, "trace_ids") else {}
        for pk in all_picks:
            sid = pk.get("station_id", pk.get("channel_index"))
            sta = tid_to_idx.get(sid)
            if sta is None:
                continue
            pidx = int(pk["phase_index"])
            ptype = pk["phase_type"]
            if (sta, pidx, ptype) in assoc_set:
                continue
            c = "lightsalmon" if ptype == "P" else "lightskyblue"
            ax.plot([sta - hw, sta + hw], [pidx, pidx], c=c, linewidth=0.5, alpha=0.4, zorder=3)
            if ptype == "P":
                n_unassoc_p += 1
            else:
                n_unassoc_s += 1

    # Associated picks (solid colors)
    for tgt in sample.targets:
        for sta, idx in tgt.p_picks:
            ax.plot([int(sta) - hw, int(sta) + hw], [idx, idx], c="red", linewidth=0.8, alpha=0.7, zorder=5)
        for sta, idx in tgt.s_picks:
            ax.plot([int(sta) - hw, int(sta) + hw], [idx, idx], c="blue", linewidth=0.8, alpha=0.7, zorder=5)

    # Unassociated origin times (lightgreen)
    n_unassoc_origin = 0
    if all_picks is not None:
        tid_to_idx = tid_to_idx if 'tid_to_idx' in dir() else (
            {tid: i for i, tid in enumerate(sample.trace_ids)} if hasattr(sample, "trace_ids") else {})
        for pk in all_picks:
            if pk.get("origin_id", -1) != -1 or pk.get("origin_index") is None:
                continue
            sid = pk.get("station_id", pk.get("channel_index"))
            sta = tid_to_idx.get(sid)
            if sta is None:
                continue
            ax.plot([sta - hw, sta + hw], [pk["origin_index"], pk["origin_index"]],
                    c="lightgreen", linewidth=0.5, alpha=0.4, zorder=3)
            n_unassoc_origin += 1

    # Associated origin time estimates: t0 = t_P - dt_PS / (Vp/Vs - 1)
    n_assoc_origin = 0
    _origin_medians: list[float] = []
    for tgt in sample.targets:
        p_map = {int(s): ti for s, ti in tgt.p_picks}
        s_map = {int(s): ti for s, ti in tgt.s_picks}
        t0_this: list[float] = []
        for sta_i, p_ti in sorted(p_map.items()):
            if sta_i in s_map and s_map[sta_i] > p_ti:
                dt_ps = s_map[sta_i] - p_ti
                t0_samp = p_ti - dt_ps / (VP_VS_RATIO - 1)
                ax.plot([sta_i - hw, sta_i + hw], [t0_samp, t0_samp],
                        c="green", linewidth=0.8, alpha=0.7, zorder=5)
                n_assoc_origin += 1
                t0_this.append(t0_samp)
        if t0_this:
            _origin_medians.append(float(np.median(t0_this)))

    for _t0_samp in _origin_medians:
        ax.axhline(_t0_samp, color="green",
                   linewidth=0.5, linestyle="--", alpha=0.5, zorder=6)

    # Legend with counts
    n_assoc_p = sum(len(tgt.p_picks) for tgt in sample.targets)
    n_assoc_s = sum(len(tgt.s_picks) for tgt in sample.targets)
    if n_unassoc_p:
        ax.plot([], [], c="lightsalmon", linewidth=1.5, label=f"P unassoc ({n_unassoc_p})")
    if n_unassoc_s:
        ax.plot([], [], c="lightskyblue", linewidth=1.5, label=f"S unassoc ({n_unassoc_s})")
    if n_unassoc_origin:
        ax.plot([], [], c="lightgreen", linewidth=1.5, label=f"Origin unassoc ({n_unassoc_origin})")
    ax.plot([], [], c="red", linewidth=1.5, label=f"P ({n_assoc_p})")
    ax.plot([], [], c="blue", linewidth=1.5, label=f"S ({n_assoc_s})")
    ax.plot([], [], c="green", linewidth=1.5, label=f"Origin ({n_assoc_origin})")
    ax.legend(loc="upper right", fontsize=6, markerscale=2)
    if plot_labels:
        picks_mask_rgba = np.zeros((nt, ns, 4))
        picks_mask_rgba[:, :, 1] = 1.0
        picks_mask_rgba[:, :, 3] = phase_mask * 0.2
        ax.imshow(picks_mask_rgba, **imshow_kwargs)
    ax.set_xlim(-1, ns)
    ax.set_ylim(nt, 0)
    _set_phys_axes(ax, xlabel=True, ylabel=True)
    ax.set_title("Waveform + Picks + Origin Times")

    if not plot_labels:
        if title:
            ax.set_title(title, fontsize=14, fontweight="bold")
        plt.tight_layout()
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.close()
        return

    # [2,1] Phase labels + event center + phase mask
    ax = axes[1, 0]
    rgb = np.ones((nt, ns, 3))
    rgb[:, :, 1] = np.clip(1.0 - p_disp * 0.9, 0, 1)
    rgb[:, :, 2] = np.clip(1.0 - p_disp * 0.9, 0, 1)
    rgb[:, :, 0] = np.clip(rgb[:, :, 0] - s_disp * 0.9, 0, 1)
    rgb[:, :, 1] = np.clip(rgb[:, :, 1] - s_disp * 0.9, 0, 1)
    rgb[:, :, 0] = np.where(phase_mask > 0, rgb[:, :, 0] * 0.85, rgb[:, :, 0])
    rgb[:, :, 2] = np.where(phase_mask > 0, rgb[:, :, 2] * 0.85, rgb[:, :, 2])
    ax.imshow(rgb, **imshow_kwargs)
    event_rgba = np.zeros((nt, ns, 4))
    event_rgba[:, :, 0] = 1.0
    event_rgba[:, :, 1] = 1.0
    event_rgba[:, :, 3] = event_center * 0.8
    ax.imshow(event_rgba, **imshow_kwargs)
    phase_mask_rgba = np.zeros((nt, ns, 4))
    phase_mask_rgba[:, :, 1] = 1.0
    phase_mask_rgba[:, :, 3] = phase_mask * 0.2
    ax.imshow(phase_mask_rgba, **imshow_kwargs)
    # Per-station origin time segments (same style as panel [1,2])
    for tgt in sample.targets:
        p_map = {int(s): ti for s, ti in tgt.p_picks}
        s_map = {int(s): ti for s, ti in tgt.s_picks}
        for sta_i, p_ti in sorted(p_map.items()):
            if sta_i in s_map and s_map[sta_i] > p_ti:
                dt_ps = s_map[sta_i] - p_ti
                t0_samp = p_ti - dt_ps / (VP_VS_RATIO - 1)
                ax.plot([sta_i - hw, sta_i + hw], [t0_samp, t0_samp],
                        c="green", linewidth=0.8, alpha=0.7, zorder=5)
    # Per-target median origin time dashed lines
    for _t0_samp in _origin_medians:
        ax.axhline(_t0_samp, color="green",
                   linewidth=0.5, linestyle="--", alpha=0.5, zorder=6)
    ax.set_xlim(-1, ns)
    ax.set_ylim(nt, 0)
    ax.set_title("Phase Labels + Event Center")
    _set_phys_axes(ax, xlabel=True, ylabel=True)

    # [2,2] Event time + center + event mask
    ax = axes[1, 1]
    bg = np.ones((nt, ns, 3))
    bg[:, :, 0] = np.where(event_center_mask > 0, 0.85, 1.0)
    bg[:, :, 2] = np.where(event_center_mask > 0, 0.85, 1.0)
    ax.imshow(bg, **imshow_kwargs)
    event_time_display = np.abs(event_time_disp)
    im = ax.imshow(event_time_display, cmap="hot_r", vmin=0, vmax=2000, **imshow_kwargs)
    mask_rgba = np.zeros((nt, ns, 4))
    mask_rgba[:, :, 1] = 1.0
    mask_rgba[:, :, 3] = event_time_mask * 0.3
    ax.imshow(mask_rgba, **imshow_kwargs)
    fig.colorbar(im, ax=ax, shrink=0.8)
    ax.set_title("Event Time + Center")
    _set_phys_axes(ax, xlabel=True, ylabel=False)

    if title:
        fig.suptitle(title, fontsize=14, fontweight="bold")
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_demo(
    sample: Sample,
    transforms: Compose,
    output_dir: str = "figures",
    event_id: str = "ceed_event",
    n_augmented: int = 0,
    n_traces: int = 3,
    config: LabelConfig = LabelConfig(),
):
    """Generate demo plots: overview, individual traces, and augmented overviews."""
    event_dir = os.path.join(output_dir, event_id)
    os.makedirs(event_dir, exist_ok=True)

    print(f"\nRaw data: {sample.waveform.shape}")
    plot_overview(sample, config, title=event_id, save_path=os.path.join(event_dir, "overview.png"))

    if n_traces > 0:
        # Find stations with both P and S picks for trace plots
        labeled_stations = set()
        for tgt in sample.targets:
            p_stas = {int(s) for s, _ in tgt.p_picks}
            s_stas = {int(s) for s, _ in tgt.s_picks}
            labeled_stations |= (p_stas & s_stas)
        labeled_stations = sorted(labeled_stations)

        if labeled_stations:
            trace_dir = os.path.join(event_dir, "traces")
            os.makedirs(trace_dir, exist_ok=True)
            raw_labels = generate_labels(sample, config)
            n = min(n_traces, len(labeled_stations))
            stations = [labeled_stations[i] for i in np.linspace(0, len(labeled_stations) - 1, n, dtype=int)]
            for j, sta in enumerate(stations):
                trace_id = sample.trace_ids[sta] if sta < len(sample.trace_ids) else f"station_{sta}"
                plot_trace(
                    sample, raw_labels, sta=sta,
                    title=f"{event_id} | {trace_id}",
                    save_path=os.path.join(trace_dir, f"{j:03d}.png"),
                )
            print(f"  Saved {n} trace plots to {trace_dir}/")

    if n_augmented > 0:
        aug_dir = os.path.join(event_dir, "augmented")
        os.makedirs(aug_dir, exist_ok=True)
        print(f"\nGenerating {n_augmented} augmented views...")
        seed_offset = 0
        for i in range(n_augmented):
            for seed in range(seed_offset, seed_offset + 100):
                random.seed(seed)
                np.random.seed(seed)
                aug = transforms(sample.copy(deep_waveform=True))
                if any(not t.is_empty for t in aug.targets):
                    seed_offset = seed + 1
                    break
            plot_overview(
                aug, config,
                title=f"{event_id} | augmented #{i}",
                save_path=os.path.join(aug_dir, f"{i:03d}.png"),
            )
        print(f"  Saved {n_augmented} augmented overviews to {aug_dir}/")


# =============================================================================
# Main — Demo and Testing
# =============================================================================

if __name__ == "__main__":
    import sys as _sys
    _sys.path.insert(0, ".")   # make `phasenet` importable when run as a script
    import time

    # Figures will be saved to figures/ (existing files may be overwritten)

    print("=" * 60)
    print("CEED Dataset Demo")
    print("=" * 60)

    # --- [1] CEED plot ---
    print("\n[1] CEED (HuggingFace) — plot")
    try:
        ds = load_ceed_dataset(region="SC", split="test", streaming=True)
        records_by_event = defaultdict(list)
        for i, record in enumerate(ds):
            if record.get("event_id"):
                records_by_event[record["event_id"]].append(record)
            if i >= 500:
                break
        best_event = max(records_by_event, key=lambda k: len(records_by_event[k]))
        event_records = records_by_event[best_event]
        sample = records_to_sample(event_records)
        print(f"  Event {best_event}: {len(event_records)} stations, waveform {sample.waveform.shape}")
        transforms = default_train_transforms(crop_length=4096, enable_stacking=False)
        plot_demo(sample, transforms, event_id=f"ceed_{best_event}/catalog",
                  output_dir="figures/ceed")
    except Exception as e:
        import traceback
        traceback.print_exc()

    # --- [2] QuakeFlow NCEDC + SCEDC — 3 events per region (year 2025) ---
    print("\n[2] QuakeFlow (GCS) NCEDC + SCEDC — 3 events per region (year 2025)")
    try:
        for reg, source_name in [("NC", "NCEDC"), ("SC", "SCEDC")]:
            ds = load_quakeflow_dataset(region=reg, years=[2025])
            records_by_event: dict[str, list] = defaultdict(list)
            for i, record in enumerate(ds):
                if record.get("event_id"):
                    records_by_event[record["event_id"]].append(record)
                if i >= 1500:
                    break
            # Pick top-3 events with the most stations
            top3 = sorted(records_by_event, key=lambda k: len(records_by_event[k]), reverse=True)[:3]
            for eid in top3:
                event_records = records_by_event[eid]
                sample = records_to_sample(event_records)
                print(f"  Event {eid} ({source_name}): {len(event_records)} stations, "
                      f"waveform {sample.waveform.shape}")
                transforms = default_train_transforms(crop_length=4096, enable_stacking=False)
                plot_demo(sample, transforms,
                          event_id=f"{source_name}_{eid}/catalog",
                          output_dir="figures/ceed")
    except Exception as e:
        import traceback
        traceback.print_exc()

    # --- [3] CEED speed test ---
    print("\n[3] CEED (HuggingFace) — speed test")
    try:
        ds = load_ceed_dataset(region="SC", split="test", streaming=True)
        t0 = time.time()
        n = 0
        for record in ds:
            n += 1
            if n >= 2000:
                break
        elapsed = time.time() - t0
        print(f"  {n} records in {elapsed:.1f}s ({n / elapsed:.0f} records/s)")
    except Exception as e:
        import traceback
        traceback.print_exc()

    # --- [4] QuakeFlow speed test ---
    print("\n[4] QuakeFlow (GCS) — speed test")
    try:
        ds = load_quakeflow_dataset(region="SC")
        t0 = time.time()
        n = 0
        for record in ds:
            n += 1
            if n >= 2000:
                break
        elapsed = time.time() - t0
        print(f"  {n} records in {elapsed:.1f}s ({n / elapsed:.0f} records/s)")
    except Exception as e:
        import traceback
        traceback.print_exc()

    print("\n" + "=" * 60)
    print("Done!")
    print("=" * 60)
