"""Shared inference utilities for PhaseNet prediction scripts.

Provides sliding-window inference, peak detection, model loading, and
target construction from linked pick maps. All functions process each
station/channel independently — no spatial ordering assumptions.
"""
from __future__ import annotations

import math
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Callable

import numpy as np
import torch
import torch.nn.functional as F

import phasenet.models.phasenet

PHASENET_2018_URL = (
    "https://github.com/AI4EPS/models/releases/download/"
    "PhaseNet-2018/phasenet2018.pth"
)
PHASES = ["P", "S"]


# ---------------------------------------------------------------------------
# Sliding-window helpers
# ---------------------------------------------------------------------------

def nx_window_starts(nx: int, nx_win: int) -> list[int]:
    """Compute start positions for overlapping windows along the nx axis."""
    if nx <= nx_win:
        return [0]
    k = math.ceil(nx / nx_win)
    stride = math.ceil((nx - nx_win) / (k - 1))
    starts = [i * stride for i in range(k)]
    starts[-1] = nx - nx_win
    return starts


def nt_window_starts(nt: int, nt_win: int,
                     min_overlap: float = 0.1) -> list[int]:
    """Compute start positions for overlapping windows along the nt axis."""
    if nt <= nt_win:
        return [0]
    max_stride = int(nt_win * (1.0 - min_overlap))
    k = math.ceil((nt - nt_win) / max_stride) + 1
    stride = math.ceil((nt - nt_win) / (k - 1))
    starts = [i * stride for i in range(k)]
    starts[-1] = nt - nt_win
    return starts


# ---------------------------------------------------------------------------
# 2-D sliding-window inference
# ---------------------------------------------------------------------------

def predict_2d(model: torch.nn.Module,
               waveform: np.ndarray,
               nx_win: int,
               nt_win: int,
               min_t_overlap: float = 0.1,
               device: str = "cpu",
               max_batch_size: int = 8,
               taper_nx: bool = False,
               taper_nt: bool = False) -> np.ndarray:
    """Run PhaseNet on overlapping (nx, nt) patches and average scores.

    All patches are collected and processed in batched forward passes to
    minimize CPU↔GPU transfer overhead.

    Args:
        model: PhaseNet model in eval mode.
        waveform: Input array of shape (nch, nx, nt).
        nx_win: Patch width in the station/channel dimension.
        nt_win: Patch width in the time dimension.
        min_t_overlap: Minimum fractional overlap between time patches.
        device: Torch device string.
        max_batch_size: Max patches per forward pass (memory safety valve).
        taper_nx: Apply cosine taper along nx overlap zones.
        taper_nt: Apply cosine taper along nt overlap zones.

    Returns:
        Phase scores of shape (3, nx, nt) — [noise, P, S].
        If model outputs event_center/event_time, returns
        (scores, event_center, event_time) at their native resolution.
    """
    nch, nx, nt = waveform.shape
    data = torch.from_numpy(waveform)

    use_gpu = device != "cpu" and torch.cuda.is_available()
    acc_device = device if use_gpu else "cpu"
    scores_sum = torch.zeros(3, nx, nt, dtype=torch.float32, device=acc_device)

    x_starts = nx_window_starts(nx, nx_win)
    t_starts = nt_window_starts(nt, nt_win, min_t_overlap)

    # Build per-window 2D taper: cosine ramp only in overlap zones.
    # First/last windows keep full weight at outer edges (no neighbor to blend).
    taper_list = None
    if taper_nx or taper_nt:
        def _build_taper_1d(win_size, starts, idx):
            """Build 1D taper for window at position idx in the start list."""
            tap = torch.ones(win_size)
            if len(starts) <= 1:
                return tap
            s = starts[1] - starts[0]
            overlap = win_size - s
            if overlap > 0:
                ramp = 0.5 * (1.0 - torch.cos(math.pi * (torch.arange(overlap) + 0.5) / overlap))
                if idx > 0:
                    tap[:overlap] = ramp
                if idx < len(starts) - 1:
                    tap[win_size - overlap:] = ramp.flip(0)
            return tap

        taper_list = {}
        for xi, xs in enumerate(x_starts):
            for ti, ts in enumerate(t_starts):
                tx = _build_taper_1d(nx_win, x_starts, xi) if taper_nx else torch.ones(nx_win)
                tt = _build_taper_1d(nt_win, t_starts, ti) if taper_nt else torch.ones(nt_win)
                taper_list[(xs, ts)] = (tx.unsqueeze(1) * tt.unsqueeze(0)).to(acc_device)

    use_counts = taper_list is None
    if use_counts:
        counts = torch.zeros(1, nx, nt, dtype=torch.float32, device=acc_device)

    # --- Collect all patches on CPU ---
    patches = []
    coords = []  # (xs, nx_valid, ts, nt_valid)
    for xs in x_starts:
        x_end    = min(xs + nx_win, nx)
        nx_valid = x_end - xs
        for ts in t_starts:
            t_end    = min(ts + nt_win, nt)
            nt_valid = t_end - ts

            patch = data[:, xs:x_end, ts:t_end]

            pad_x = nx_win - nx_valid
            pad_t = nt_win - nt_valid
            if pad_x > 0 or pad_t > 0:
                patch = F.pad(patch, (0, pad_t, 0, pad_x))

            mean  = patch.mean(dim=2, keepdim=True)
            patch = patch - mean
            std   = patch.std(dim=(0, 2), keepdim=True).clamp(min=1e-8)
            patch = patch / std

            patches.append(patch)
            coords.append((xs, nx_valid, ts, nt_valid))

    # --- Batched forward passes ---
    has_event = None  # determined on first batch
    ec_sum = et_sum = ec_counts = None
    with torch.inference_mode():
        for i in range(0, len(patches), max_batch_size):
            batch = torch.stack(patches[i:i + max_batch_size]).to(device)
            with torch.autocast(device_type="cuda", enabled=use_gpu):
                out = model({"data": batch})
            probs = torch.softmax(out["phase"].float(), dim=1)
            if not use_gpu:
                probs = probs.cpu()

            # Auto-detect event outputs on first batch
            if has_event is None:
                has_event = "event_center" in out and "event_time" in out
                if has_event:
                    # Infer stride from ratio of phase to event_center resolution
                    ec_shape = out["event_center"].shape  # (B, 1, nx_ds, nt_ds)
                    stride_x = nx_win // ec_shape[2]
                    stride_t = nt_win // ec_shape[3]
                    nx_ds = (nx + stride_x - 1) // stride_x
                    nt_ds = (nt + stride_t - 1) // stride_t
                    ec_sum = torch.zeros(1, nx_ds, nt_ds, dtype=torch.float32, device=acc_device)
                    et_sum = torch.zeros(1, nx_ds, nt_ds, dtype=torch.float32, device=acc_device)
                    ec_counts = torch.zeros(1, nx_ds, nt_ds, dtype=torch.float32, device=acc_device)

            if has_event:
                ec_patch = torch.sigmoid(out["event_center"].float())
                et_patch = out["event_time"].float()  # in full-resolution samples
                if not use_gpu:
                    ec_patch = ec_patch.cpu()
                    et_patch = et_patch.cpu()

            for j, (xs, nx_v, ts, nt_v) in enumerate(coords[i:i + max_batch_size]):
                if taper_list is not None:
                    w = taper_list[(xs, ts)][:nx_v, :nt_v]
                    scores_sum[:, xs:xs + nx_v, ts:ts + nt_v] += probs[j, :, :nx_v, :nt_v] * w
                else:
                    scores_sum[:, xs:xs + nx_v, ts:ts + nt_v] += probs[j, :, :nx_v, :nt_v]
                    counts    [:, xs:xs + nx_v, ts:ts + nt_v] += 1

                if has_event:
                    xs_ds = xs // stride_x
                    ts_ds = ts // stride_t
                    nx_v_ds = min(nx_v // stride_x, nx_ds - xs_ds)
                    nt_v_ds = min(nt_v // stride_t, nt_ds - ts_ds)
                    ec_sum[:, xs_ds:xs_ds + nx_v_ds, ts_ds:ts_ds + nt_v_ds] += ec_patch[j, :, :nx_v_ds, :nt_v_ds]
                    et_sum[:, xs_ds:xs_ds + nx_v_ds, ts_ds:ts_ds + nt_v_ds] += et_patch[j, :, :nx_v_ds, :nt_v_ds]
                    ec_counts[:, xs_ds:xs_ds + nx_v_ds, ts_ds:ts_ds + nt_v_ds] += 1

    if use_counts:
        scores_sum = scores_sum / counts.clamp(min=1)

    scores = scores_sum.cpu().numpy()

    if has_event:
        ec_avg = ec_sum / ec_counts.clamp(min=1)
        et_avg = et_sum / ec_counts.clamp(min=1)
        # Upsample to full resolution for peak detection
        ec_full = F.interpolate(ec_avg.unsqueeze(0), size=(nx, nt), mode='bilinear', align_corners=False).squeeze(0)
        et_full = F.interpolate(et_avg.unsqueeze(0), size=(nx, nt), mode='bilinear', align_corners=False).squeeze(0)
        # event_time label is already in full-resolution samples (not /stride)

        # Detect event center peaks (same logic as detect_picks)
        ec_kernel = 101
        ec_threshold = 0.3
        pad = ec_kernel // 2
        ec_2d = ec_full[0]  # (nx, nt)
        ec_3d = ec_2d.unsqueeze(1)  # (nx, 1, nt)
        ec_maxp = F.max_pool1d(ec_3d, ec_kernel, stride=1, padding=pad)[:, :, :nt]
        ec_peaks = (ec_maxp == ec_3d).reshape(nx, nt) & (ec_2d >= ec_threshold)

        event_detections = []
        for ch in range(nx):
            peak_inds = ec_peaks[ch].nonzero(as_tuple=False).squeeze(1)
            for idx in peak_inds:
                tidx = idx.item()
                event_detections.append({
                    "channel_index": str(ch),
                    "event_center_index": tidx,
                    "event_center_score": ec_full[0, ch, tidx].item(),
                    "event_time": et_full[0, ch, tidx].item(),
                })

        return scores, event_detections

    return scores


# ---------------------------------------------------------------------------
# Peak detection and pick extraction (per-channel independent)
# ---------------------------------------------------------------------------

def detect_picks(scores: np.ndarray,
                 channel_ids: list[str],
                 event_id: str,
                 begin_time_iso: str | None,
                 dt_s: float = 0.01,
                 vmin: float = 0.3,
                 kernel: int = 101,
                 id_key: str = "channel_index",
                 phases: list[str] | None = None,
                 device: str = "cpu") -> list[dict]:
    """Extract phase picks from score array via local-max peak detection.

    Each channel is processed independently. Uses max_pool1d (since peak
    detection is per-channel along time) for efficiency on GPU.

    Args:
        scores: Phase scores of shape (3, nx, nt) — [noise, P, S].
        channel_ids: Identifier for each channel/station (length nx).
        event_id: Event identifier to include in each pick dict.
        begin_time_iso: ISO-8601 start time for absolute time computation.
        dt_s: Sampling interval in seconds.
        vmin: Minimum score threshold.
        kernel: Max-pool kernel width for local maxima detection.
        id_key: Key name for the channel/station identifier in output dicts
                (e.g. "channel_index" for DAS, "station_id" for seismic).
        phases: Phase names (default ["P", "S"]).
        device: Torch device for max_pool computation ("cpu" or "cuda").

    Returns:
        List of pick dicts, each with keys: event_id, <id_key>,
        phase_index, phase_time, phase_score, phase_type, dt_s.
    """
    if phases is None:
        phases = PHASES
    _nch, nx, nt = scores.shape

    try:
        t0 = datetime.fromisoformat(str(begin_time_iso).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        t0 = datetime(1970, 1, 1, tzinfo=timezone.utc)

    picks = []
    pad = kernel // 2

    for ph_idx, phase in enumerate(phases, start=1):
        ph_scores = torch.from_numpy(scores[ph_idx]).to(device)
        # (nx, nt) → (nx, 1, nt) for max_pool1d along time axis
        ph_3d = ph_scores.unsqueeze(1)
        smax = F.max_pool1d(ph_3d, kernel, stride=1, padding=pad)[:, :, :nt]
        keep = (smax == ph_3d).reshape(nx, nt)
        masked = (ph_scores * keep).cpu()

        for ch_idx in range(nx):
            row = masked[ch_idx]
            peak_inds = (row > vmin).nonzero(as_tuple=False).squeeze(1)
            for idx in peak_inds:
                tidx = idx.item()
                prob = row[tidx].item()
                phase_time = (t0 + timedelta(seconds=tidx * dt_s)).isoformat(
                    timespec="milliseconds"
                )
                picks.append({
                    "event_id":    event_id,
                    id_key:        channel_ids[ch_idx],
                    "phase_index": tidx,
                    "phase_time":  phase_time,
                    "phase_score": round(prob, 4),
                    "phase_type":  phase,
                    "dt_s":        dt_s,
                })

    return picks


# ---------------------------------------------------------------------------
# Model loading
# ---------------------------------------------------------------------------

def load_phasenet2018_model(
    device: str = "cpu",
    model_dir: str = "./model_phasenet",
) -> torch.nn.Module:
    """Load the pretrained PhaseNet-2018 (unet2018) model."""
    model = phasenet.models.phasenet.build_model(backbone="unet2018")
    ckpt = torch.hub.load_state_dict_from_url(
        PHASENET_2018_URL, model_dir=model_dir, progress=False,
        check_hash=True, map_location="cpu",
    )
    model.load_state_dict(ckpt["model"])
    model.to(device).eval()
    return model


# ---------------------------------------------------------------------------
# Target construction from linked_map (per-channel independent)
# ---------------------------------------------------------------------------

def build_targets_from_linked_map(
    linked_map: dict[tuple[str, int, str], int],
    resolve_index: Callable[[str], int],
    target_cls: type,
    event_id_prefix: str = "",
) -> tuple[list, int, int]:
    """Build Target objects from an origin-linked pick map.

    Groups picks by origin index, constructs one Target per origin with
    p_picks, s_picks, ps_centers, and ps_intervals.

    Args:
        linked_map: Maps (channel_id, phase_index, phase_type) → origin_index.
        resolve_index: Converts a channel_id string to an integer spatial index.
        target_cls: Target dataclass to instantiate (e.g. ceed.Target or das.Target).
        event_id_prefix: Prefix for target event_id (appended with _{origin_idx}).

    Returns:
        (targets, p_total, s_total) — list of Target objects and pick counts.
    """
    picks_by_origin: dict[int, dict[str, list[tuple[str, float]]]] = defaultdict(
        lambda: {"P": [], "S": []}
    )
    for (cid, phase_idx, ptype), oidx in linked_map.items():
        picks_by_origin[oidx][ptype].append((cid, float(phase_idx)))

    targets = []
    p_total, s_total = 0, 0

    for oidx in sorted(picks_by_origin):
        p_by_id: dict[str, float] = {}
        s_by_id: dict[str, float] = {}
        p_picks_o: list[tuple[int, float]] = []
        s_picks_o: list[tuple[int, float]] = []
        ps_centers_o: list[tuple[int, float]] = []
        ps_intervals_o:  list[tuple[int, float]] = []

        for cid, pidx in picks_by_origin[oidx]["P"]:
            idx = resolve_index(cid)
            p_picks_o.append((idx, pidx))
            p_by_id[cid] = pidx
        for cid, sidx in picks_by_origin[oidx]["S"]:
            idx = resolve_index(cid)
            s_picks_o.append((idx, sidx))
            s_by_id[cid] = sidx
        for cid in set(p_by_id) & set(s_by_id):
            p_i, s_i = p_by_id[cid], s_by_id[cid]
            if s_i > p_i:
                idx = resolve_index(cid)
                ps_centers_o.append((idx, (p_i + s_i) / 2.0))
                ps_intervals_o.append((idx, s_i - p_i))

        if p_picks_o or s_picks_o:
            targets.append(target_cls(
                p_picks=p_picks_o, s_picks=s_picks_o,
                ps_centers=ps_centers_o, ps_intervals=ps_intervals_o,
                event_id=f"{event_id_prefix}_{oidx}",
            ))
        p_total += len(p_picks_o)
        s_total += len(s_picks_o)

    return targets, p_total, s_total
