import os
import shutil
from collections import defaultdict, namedtuple
from datetime import datetime, timedelta
from glob import glob
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm

from phasenet.utils.detect_peaks_cpu import detect_peaks as detect_peaks_1d


def detect_peaks(scores, vmin=0.3, kernel=101, stride=1, K=0, dt=0.01):
    # nb, nc, nt, nx = scores.shape
    nb, nc, nx, nt = scores.shape
    pad = kernel // 2
    # smax = F.max_pool2d(scores, (kernel, 1), stride=(stride, 1), padding=(pad, 0))[:, :, :nt, :]
    smax = F.max_pool2d(scores, (1, kernel), stride=(1, stride), padding=(0, pad))[:, :, :, :nt]
    keep = (smax == scores).float()
    scores = scores * keep
    # if there are multiple peaks with the same score, keep the first one
    # pos = torch.arange(nt, 0, -1, device=scores.device)[None, None, :, None].float()
    pos = torch.arange(nt, 0, -1, device=scores.device)[None, None, None, :].float()
    # sfirst = F.max_pool2d(keep * pos, (kernel, 1), stride=(stride, 1), padding=(pad, 0))[:, :, :nt, :]
    sfirst = F.max_pool2d(keep * pos, (1, kernel), stride=(1, stride), padding=(0, pad))[:, :, :, :nt]
    scores = scores * (sfirst == pos).float()

    # batch, chn, nt, ns = scores.size()
    # scores = torch.transpose(scores, 2, 3)  # [nb, nc, nt, nx] -> [nb, nc, nx, nt]
    if K == 0:
        K = max(round(nt / (30.0 / dt) * 10.0), 3)  # maximum 10 picks per 30 seconds
    if nc == 1:
        topk_scores, topk_inds = torch.topk(scores, K)
    else:
        # topk_scores, topk_inds = torch.topk(scores[:, 1:, :, :].view(batch, chn - 1, ns, -1), K)
        topk_scores, topk_inds = torch.topk(scores[:, 1:, :, :].view(nb, nc - 1, nx, -1), K)
    # topk_inds = topk_inds % nt

    return topk_scores.detach().cpu(), topk_inds.detach().cpu()


def extract_picks(
    topk_index,
    topk_score,
    file_name=None,
    begin_time=None,
    station_id=None,
    phases=["P", "S"],
    vmin=0.3,
    dt=0.01,
    polarity_score=None,
    waveform=None,
    window_amp=[10, 5],
    polarity_scale=1,
    **kwargs,
):
    """Extract picks from prediction results.
    Args:
        topk_scores ([type]): [Nb, Nc, Ns, Ntopk] "batch, channel, station, topk"
        file_names ([type], optional): [Nb]. Defaults to None.
        station_ids ([type], optional): [Ns]. Defaults to None.
        t0 ([type], optional): [Nb]. Defaults to None.
        config ([type], optional): [description]. Defaults to None.

    Returns:
        picks [type]: {file_name, station_id, pick_time, pick_prob, pick_type}
    """

    batch, nch, nst, ntopk = topk_score.shape
    # assert nch == len(phases)

    picks = []
    if isinstance(dt, float):
        dt = [dt for i in range(batch)]
    else:
        dt = [dt[i].item() for i in range(batch)]
    if ("begin_channel_index" in kwargs) and (kwargs["begin_channel_index"] is not None):
        begin_channel_index = [x.item() for x in kwargs["begin_channel_index"]]
    else:
        begin_channel_index = [0 for i in range(batch)]
    if ("begin_time_index" in kwargs) and (kwargs["begin_time_index"] is not None):
        begin_time_index = [x.item() for x in kwargs["begin_time_index"]]
    else:
        begin_time_index = [0 for i in range(batch)]

    if waveform is not None:
        waveform_amp = torch.max(torch.abs(waveform), dim=1)[0]
        # waveform_amp = torch.sqrt(torch.mean(waveform ** 2, dim=1))

        if len(window_amp) == 1:
            window_amp = [window_amp[0] for i in range(len(phases))]

    for i in range(batch):
        picks_per_file = []
        if file_name is None:
            file_i = f"{i:04d}"
        else:
            file_i = file_name[i]

        if begin_time is None:
            begin_i = "1970-01-01T00:00:00.000"
        else:
            begin_i = begin_time[i]
            if len(begin_i) == 0:
                begin_i = "1970-01-01T00:00:00.000"
        begin_i = datetime.fromisoformat(begin_i.rstrip("Z"))

        for j in range(nch):
            if waveform is not None:
                window_amp_i = int(window_amp[j] / dt[i])  ## index of window

            for k in range(nst):
                if station_id is None:
                    station_i = f"{k + begin_channel_index[i]:04d}"
                else:
                    station_i = station_id[k][i]

                topk_index_ijk, ii = torch.sort(topk_index[i, j, k])
                topk_score_ijk = topk_score[i, j, k][ii]

                idx = topk_score_ijk > vmin
                topk_index_ijk = topk_index_ijk[idx]
                topk_score_ijk = topk_score_ijk[idx]

                # for ii, (index, score) in enumerate(zip(topk_index[i, j, k], topk_score[i, j, k])):
                for ii, (index, score) in enumerate(zip(topk_index_ijk, topk_score_ijk)):
                    # if score > vmin:
                    pick_index = index.item() + begin_time_index[i]
                    pick_time = (begin_i + timedelta(seconds=index.item() * dt[i])).isoformat(timespec="milliseconds")
                    pick_dict = {
                        # "file_name": file_i,
                        "station_id": station_i,
                        "phase_index": pick_index,
                        "phase_time": pick_time,
                        "phase_score": f"{score.item():.3f}",
                        "phase_type": phases[j],
                        "dt_s": dt[i],
                    }

                    if polarity_score is not None:
                        # pick_dict["phase_polarity"] = (
                        #     f"{(polarity_score[i, 1, index.item()//polarity_scale, k].item() - polarity_score[i, 2, index.item()//polarity_scale, k].item()):.3f}"
                        # )
                        # score = polarity_score[i, 1, :, k] - polarity_score[i, 2, :, k]
                        # score = (polarity_score[i, 0, :, k] - 0.5) * 2.0
                        score = (polarity_score[i, 0, k, :] - 0.5) * 2.0
                        score = score[max(0, index.item() // polarity_scale - 3) : index.item() // polarity_scale + 3]
                        idx = torch.argmax(torch.abs(score))
                        pick_dict["phase_polarity"] = round(score[idx].item(), 3)

                    if waveform is not None:
                        j1 = topk_index_ijk[ii]
                        j2 = (
                            min(j1 + window_amp_i, topk_index_ijk[ii + 1])
                            if ii < len(topk_index_ijk) - 1
                            else j1 + window_amp_i
                        )
                        # pick_dict["phase_amplitude"] = f"{torch.max(waveform_amp[i, j1:j2, k]).item():.3e}"
                        pick_dict["phase_amplitude"] = f"{torch.max(waveform_amp[i, k, j1:j2]).item():.3e}"

                    picks_per_file.append(pick_dict)

        picks.append(picks_per_file)
    return picks


def extract_events(
    topk_index,
    topk_score,
    file_name=None,
    begin_time=None,
    station_id=None,
    vmin=0.3,
    dt=0.01,
    event_scale=16,
    event_time=None,
    waveform=None,
    window_amp=[2, 2],
    VPVS_RATIO=1.73,
    **kwargs,
):
    """Extract picks from prediction results.
    Args:
        topk_scores ([type]): [Nb, Nc, Ns, Ntopk] "batch, channel, station, topk"
        file_names ([type], optional): [Nb]. Defaults to None.
        station_ids ([type], optional): [Ns]. Defaults to None.
        t0 ([type], optional): [Nb]. Defaults to None.
        config ([type], optional): [description]. Defaults to None.

    Returns:
        picks [type]: {file_name, station_id, pick_time, pick_prob, pick_type}
    """

    batch, nch, nst, ntopk = topk_score.shape
    # assert nch == len(phases)

    events = []
    if isinstance(dt, float):
        dt = [dt for i in range(batch)]
    else:
        dt = [dt[i].item() for i in range(batch)]
    if ("begin_channel_index" in kwargs) and (kwargs["begin_channel_index"] is not None):
        begin_channel_index = [x.item() for x in kwargs["begin_channel_index"]]
    else:
        begin_channel_index = [0 for i in range(batch)]
    if ("begin_time_index" in kwargs) and (kwargs["begin_time_index"] is not None):
        begin_time_index = [x.item() / event_scale for x in kwargs["begin_time_index"]]
    else:
        begin_time_index = [0 for i in range(batch)]

    for i in range(batch):
        events_per_file = []
        # if file_name is None:
        #     file_i = f"{i:04d}"
        # else:
        #     file_i = file_name[i]

        if begin_time is None:
            begin_i = "1970-01-01T00:00:00.000"
        else:
            begin_i = begin_time[i]
            if len(begin_i) == 0:
                begin_i = "1970-01-01T00:00:00.000"
        begin_i = datetime.fromisoformat(begin_i.rstrip("Z"))

        p_window = int(window_amp[0] / dt[i])  ## index of window
        s_window = int(window_amp[1] / dt[i])  ## index of window

        for j in range(nch):
            for k in range(nst):
                if station_id is None:
                    station_i = f"{k + begin_channel_index[i]:04d}"
                else:
                    station_i = station_id[k][i]

                topk_index_ijk, ii = torch.sort(topk_index[i, j, k])
                topk_score_ijk = topk_score[i, j, k][ii]

                # for ii, (index, score) in enumerate(zip(topk_index[i, j, k], topk_score[i, j, k])):
                for ii, (index, score) in enumerate(zip(topk_index_ijk, topk_score_ijk)):
                    if score > vmin:
                        center_index = index.item() + begin_time_index[i]
                        center_time = begin_i + timedelta(seconds=index.item() * dt[i] * event_scale)
                        event_dict = {
                            # "file_name": file_i,
                            "station_id": station_i,
                            "center_index": center_index,
                            "center_time": center_time.strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "event_score": f"{score.item():.3f}",
                            "dt_s": dt[i] * event_scale,
                        }

                        if event_time is not None:
                            # t0 = center_time - timedelta(seconds=event_time[i, 0, index.item(), k].item() * dt[i])
                            t0 = center_time - timedelta(seconds=event_time[i, 0, k, index.item()].item() * dt[i])
                            event_dict["event_time"] = t0.strftime("%Y-%m-%dT%H:%M:%S.%f")
                            # event_dict["travel_time"] = event_time[i, 0, index.item(), k].item() * dt[i]
                            event_dict["travel_time"] = event_time[i, 0, k, index.item()].item() * dt[i]
                            if event_dict["travel_time"] <= 0:
                                continue

                        if waveform is not None:
                            ## calculate PS ratio
                            ps_delta = max(
                                2,
                                event_time[i, 0, k, index.item()].item() * 2.0 * (VPVS_RATIO - 1) / (VPVS_RATIO + 1),
                            )  # 2 is to prevent error of torch.max()
                            itp = max(
                                0, index.item() * event_scale - int(ps_delta * 0.5)
                            )  # waveform is not downsampled
                            its = max(0, index.item() * event_scale + int(ps_delta * 0.5))

                            # p_amp = torch.max(torch.abs(waveform[i, :, k, itp : min(itp + p_window, its)]))
                            # s_amp = torch.max(torch.abs(waveform[i, :, k, its : its + s_window]))
                            waveform_cut = waveform[i, :, k, itp : min(itp + p_window, its)]
                            p_amp = torch.max(waveform_cut) - torch.min(waveform_cut)
                            waveform_cut = waveform[i, :, k, its : its + s_window]
                            if waveform_cut.numel() == 0:
                                s_amp = torch.tensor(0.0)
                            else:
                                s_amp = torch.max(waveform_cut) - torch.min(waveform_cut)
                            event_dict["sp_ratio"] = s_amp.item() / p_amp.item()

                            ## calculate event amplitude
                            # event_amp = torch.max(torch.abs(waveform[i, :, itp : its + (its - itp), k]))
                            waveform_cut = waveform[i, :, k, itp : its + (its - itp)]
                            event_amp = (torch.max(torch.abs(waveform_cut)) - torch.min(torch.abs(waveform_cut))) / 2.0
                            event_dict["event_amplitude"] = event_amp.item()

                        events_per_file.append(event_dict)

        events.append(events_per_file)
    return events


def merge_picks(pick_dir):
    pick_dir = Path(pick_dir)

    num_p = 0
    num_s = 0
    picks = []
    for file in tqdm(
        pick_dir.rglob(
            "*.csv",
        ),
        desc=f"Merging {pick_dir.name}",
    ):
        if os.stat(file).st_size == 0:
            continue
        picks_ = pd.read_csv(file)
        num_p += len(picks_[picks_["phase_type"] == "P"])
        num_s += len(picks_[picks_["phase_type"] == "S"])
        picks.append(picks_)
    if len(picks) == 0:
        with open(str(pick_dir) + ".csv", "w") as fp:
            fp.write("")
    else:
        picks = pd.concat(picks)
        picks = picks.sort_values(["phase_time", "station_id", "phase_type"])
        picks = picks.reset_index(drop=True)
        picks.to_csv(str(pick_dir) + ".csv", index=False)

    print(f"Number of picks: {len(picks)}")
    if (num_p > 0) and (num_s > 0):
        print(f"Number of P picks: {num_p}")
        print(f"Number of S picks: {num_s}")
    return 0


def merge_events(event_dir):
    event_dir = Path(event_dir)

    events = []
    for file in tqdm(
        event_dir.rglob(
            "*.csv",
        ),
        desc=f"Merging {event_dir.name}",
    ):
        if os.stat(file).st_size == 0:
            continue
        events_ = pd.read_csv(file)
        events.append(events_)
    if len(events) == 0:
        with open(str(event_dir) + ".csv", "w") as fp:
            fp.write("")
    else:
        events = pd.concat(events)
        events = events.sort_values(["event_time", "station_id"])
        events = events.reset_index(drop=True)
        events.to_csv(str(event_dir) + ".csv", index=False)

    print(f"Number of event x station: {len(events)}")
    return 0


def merge_patch(patch_dir, merged_dir, return_single_file=False):
    patch_dir = Path(patch_dir)
    merged_dir = Path(merged_dir)
    if not merged_dir.exists():
        merged_dir.mkdir()

    files = list(patch_dir.rglob("*_*_*.csv"))
    group = defaultdict(list)
    for file in files:
        key = "_".join((str(file).replace(f"{patch_dir}/", "")).split("_")[:-2])
        group[key].append(file)  ## event_id

    if return_single_file:
        fp_total = open(str(merged_dir).rstrip("/") + ".csv", "w")

    num_picks = 0
    header0 = None
    for k in tqdm(group, desc=f"Merging {merged_dir}"):
        header = None
        if not (merged_dir / f"{k}.csv").parent.exists():
            (merged_dir / f"{k}.csv").parent.mkdir()
        with open(merged_dir / f"{k}.csv", "w") as fp_file:
            for file in sorted(group[k]):
                with open(file, "r") as f:
                    lines = f.readlines()
                    if len(lines) > 0:
                        if header is None:
                            header = lines[0]
                            fp_file.writelines(header)
                        if return_single_file and (header0 is None):
                            header = lines[0]
                            fp_total.writelines(header)
                        fp_file.writelines(lines[1:])
                        if return_single_file:
                            fp_total.writelines(lines[1:])
                        num_picks += len(lines[1:])

    print(f"Number of detections: {num_picks}")
    return 0


def _ransac_midpoint_filter(
    origin_pairs: list[tuple],
    dt_s: float,
    threshold: float,
) -> list[tuple]:
    """Filter P-S pairs using RANSAC on midpoint moveout.

    Fits a quadratic curve to (channel, midpoint_time) and removes outliers.

    Args:
        origin_pairs: list of (channel_id, p_idx, s_idx)
        dt_s: sampling interval in seconds
        threshold: RANSAC residual threshold in seconds (typically 2*MAD)

    Returns:
        Filtered list of (channel_id, p_idx, s_idx)
    """
    from sklearn.linear_model import RANSACRegressor, LinearRegression
    from sklearn.preprocessing import PolynomialFeatures
    from sklearn.pipeline import make_pipeline

    chs = np.array([int(cid) for cid, _, _ in origin_pairs]).reshape(-1, 1)
    mids = np.array([(p + s) / 2 * dt_s for _, p, s in origin_pairs])

    try:
        ransac = RANSACRegressor(
            estimator=make_pipeline(PolynomialFeatures(2), LinearRegression()),
            residual_threshold=threshold, min_samples=3, random_state=0,
        )
        ransac.fit(chs, mids)
        inliers = ransac.inlier_mask_
        return [p for p, keep in zip(origin_pairs, inliers) if keep]
    except Exception:
        return origin_pairs


AssociationResult = namedtuple('AssociationResult', [
    'event_times',      # detected event origin times (seconds), one per event
    'candidate_times',  # all histogram peak candidates (before mph filter)
    'associated_set',   # set of (ch, idx, type) tuples for associated picks
    'pair_t0',          # origin time per P-S pair (seconds)
    'pair_weights',     # score-based weight per P-S pair
    'pair_channels',    # channel ID per P-S pair
    'pair_p_indices',   # P sample index per P-S pair
    'pair_s_indices',   # S sample index per P-S pair
    'pair_centers',     # (P+S)/2 sample index per pair
    'pair_intervals',   # S-P sample interval per pair
    'hist_counts',      # histogram bin counts
    'hist_edges',       # histogram bin edges
    'pick_to_event',    # {(ch, idx, type): event_id} — maps picks to events
])


def estimate_origins_from_ps_pairs(
    picks: list[dict],
    dt_s: float = 0.01,
    vp_vs: float = 1.73,
    min_ps_dt: float = 0.0,
    max_ps_dt: float = 20.0,
    id_key: str = "channel_index",
) -> list[tuple]:
    """Estimate origin times by pairing P and S picks per channel.

    For each P pick, finds the first S pick after it within max_ps_dt.
    Computes origin time: t0 = (tp+ts)/2 - (ts-tp)/2 * (r+1)/(r-1).

    Returns:
        List of (cid, p_idx, s_idx, t0_seconds, weight, ps_center, ps_interval) tuples.
        ps_center = (p_idx + s_idx) / 2 in samples, ps_interval = s_idx - p_idx in samples.
    """
    all_by_ch: dict[str, list[tuple[int, float, str, float]]] = {}
    for pk in picks:
        cid = pk[id_key]
        pidx = int(pk["phase_index"])
        all_by_ch.setdefault(cid, []).append(
            (pidx, pidx * dt_s, pk["phase_type"], float(pk.get("phase_score", 1.0)))
        )
    for cid in all_by_ch:
        all_by_ch[cid].sort(key=lambda x: x[1])

    pairs = []
    for cid, ch_picks in all_by_ch.items():
        for i, (p_idx, tp, ptype, p_score) in enumerate(ch_picks):
            if ptype != "P":
                continue
            for s_idx, ts, stype, s_score in ch_picks[i + 1:]:
                dt_ps = ts - tp
                if dt_ps >= max_ps_dt:
                    break
                if stype == "S" and dt_ps >= min_ps_dt:
                    weight = (p_score + s_score) / 2.0
                    t0 = (tp + ts) / 2 - (ts - tp) / 2 * (vp_vs + 1) / (vp_vs - 1)
                    ps_center = (p_idx + s_idx) / 2.0
                    ps_interval = s_idx - p_idx
                    pairs.append((cid, p_idx, s_idx, t0, weight, ps_center, ps_interval))
                break
    return pairs


def estimate_origins_from_event_heads(
    event_detections: list[dict],
    picks: list[dict],
    dt_s: float = 0.01,
    vp_vs: float = 1.73,
    id_key: str = "channel_index",
) -> list[tuple]:
    """Estimate origin times from detected event centers and event times.

    For each event detection (from predict_2d), uses event_time to compute
    origin and expected S-P window, then links nearby P and/or S picks.

    Args:
        event_detections: list of dicts from predict_2d, each with
            channel_index, event_center_index, event_center_score, event_time.
        picks: list of pick dicts with phase_index, phase_type, phase_score.
        dt_s: sampling interval in seconds.
        vp_vs: Vp/Vs ratio for S-P estimation.
        id_key: key for channel identifier in pick dicts.

    Returns:
        List of (cid, p_idx, s_idx, t0_seconds, weight, ps_center, ps_interval) tuples.
        p_idx or s_idx is -1 when only one phase is found.
        ps_center and ps_interval are -1 when only one phase is found.
    """
    if not event_detections:
        return []

    # Group picks by channel for fast lookup
    picks_by_ch: dict = {}
    for pk in picks:
        cid = pk[id_key]
        picks_by_ch.setdefault(cid, []).append(
            (int(pk["phase_index"]), pk["phase_type"], float(pk.get("phase_score", 1.0)))
        )
    for cid in picks_by_ch:
        picks_by_ch[cid].sort()

    pairs = []
    sp_ratio = 2.0 * (vp_vs - 1.0) / (vp_vs + 1.0)

    for det in event_detections:
        cid = det["channel_index"]
        center = det["event_center_index"]
        shift = det["event_time"]  # origin-to-center offset in samples
        ec_score = det["event_center_score"]

        origin_sample = center - shift
        t0_sec = origin_sample * dt_s

        ch_picks = picks_by_ch.get(cid, [])
        if not ch_picks:
            continue

        # Expected S-P window from event_time
        sp_samples = abs(shift) * sp_ratio
        p_window = (center - sp_samples * 1.5, center - sp_samples * 0.2)
        s_window = (center + sp_samples * 0.2, center + sp_samples * 1.5)

        p_idx, s_idx = -1, -1
        p_score, s_score = 0.0, 0.0
        for pidx, ptype, pscore in ch_picks:
            if ptype == "P" and p_window[0] <= pidx <= p_window[1]:
                if pscore > p_score:
                    p_idx, p_score = pidx, pscore
            elif ptype == "S" and s_window[0] <= pidx <= s_window[1]:
                if pscore > s_score:
                    s_idx, s_score = pidx, pscore

        if p_idx >= 0 or s_idx >= 0:
            w = max(p_score, s_score) * ec_score
            if p_idx >= 0 and s_idx >= 0:
                ps_center = (p_idx + s_idx) / 2.0
                ps_interval = s_idx - p_idx
            else:
                ps_center = -1.0
                ps_interval = -1.0
            pairs.append((cid, p_idx, s_idx, t0_sec, w, ps_center, ps_interval))

    return pairs


def associate_picks(
    pairs: list[tuple],
    nt: int,
    dt_s: float = 0.01,
    bin_size: float = 1.0,
    mph: int = 5,
    mpd: int = 5,
    use_weights: bool = True,
    origin_window: float = None,
    moveout_window: float = None,
) -> AssociationResult:
    """Associate origin-time estimates into events via histogram peak detection.

    Shared by both PS-pair and event-head origin estimation paths.

    Args:
        pairs: list of (cid, p_idx, s_idx, t0_seconds, weight, ps_center, ps_interval).
            p_idx or s_idx may be -1 (single-phase detection).
        nt: total number of time samples.
        dt_s: sampling interval in seconds.
        bin_size: histogram bin width in seconds.
        mph: minimum peak height for event detection.
        mpd: minimum peak distance for event detection.
        use_weights: weight histogram by pick scores.
        origin_window: max distance from median origin to link (default: bin_size).
        moveout_window: RANSAC residual threshold (default: None = no RANSAC).

    Returns:
        AssociationResult namedtuple.
    """
    if origin_window is None:
        origin_window = bin_size
    _empty = AssociationResult(
        np.array([]), np.array([]), set(), np.array([]), np.array([]),
        [], [], [], [], [], np.array([]), np.array([]), {})

    if not pairs:
        return _empty

    pair_t0 = np.array([p[3] for p in pairs])
    pair_weights = np.array([p[4] for p in pairs])
    t_max = nt * dt_s
    hist_edges = np.arange(0, t_max + bin_size, bin_size)
    bin_centers = 0.5 * (hist_edges[:-1] + hist_edges[1:])

    unweighted_counts, _ = np.histogram(pair_t0, bins=hist_edges)
    if unweighted_counts.max() == 0:
        return _empty

    hist_counts, _ = np.histogram(pair_t0, bins=hist_edges,
                                  weights=pair_weights if use_weights else None)

    # Detect peaks
    cand_inds, _ = detect_peaks_1d(unweighted_counts, mpd=mpd, mph=1)
    candidate_times = bin_centers[cand_inds] if len(cand_inds) else np.array([])

    peak_inds, _ = detect_peaks_1d(unweighted_counts, mpd=mpd, mph=mph)
    if not len(peak_inds):
        return AssociationResult(
            np.array([]), candidate_times, set(),
            pair_t0, pair_weights,
            [p[0] for p in pairs], [p[1] for p in pairs], [p[2] for p in pairs],
            [p[5] for p in pairs], [p[6] for p in pairs],
            hist_counts, hist_edges, {})

    event_times = bin_centers[peak_inds]

    # Link pairs to peaks
    pick_to_event: dict[tuple[str, int, str], int] = {}
    for oidx, t0_peak in enumerate(event_times):
        nearby_t0 = pair_t0[np.abs(pair_t0 - t0_peak) <= bin_size]
        if len(nearby_t0) == 0:
            continue
        center = float(np.median(nearby_t0))

        origin_pairs = [(cid, p_idx, s_idx)
                        for cid, p_idx, s_idx, t0, _w, *_ in pairs
                        if abs(t0 - center) <= origin_window]

        # RANSAC filter on midpoint moveout (only for pairs with both P and S)
        if moveout_window is not None:
            full_pairs = [(c, p, s) for c, p, s in origin_pairs if p >= 0 and s >= 0]
            if len(full_pairs) >= 10:
                full_pairs = _ransac_midpoint_filter(full_pairs, dt_s, threshold=moveout_window)
            single_pairs = [(c, p, s) for c, p, s in origin_pairs if p < 0 or s < 0]
            origin_pairs = full_pairs + single_pairs

        for cid, p_idx, s_idx in origin_pairs:
            if p_idx >= 0:
                pick_to_event.setdefault((cid, p_idx, "P"), oidx)
            if s_idx >= 0:
                pick_to_event.setdefault((cid, s_idx, "S"), oidx)

    return AssociationResult(
        event_times, candidate_times, set(pick_to_event.keys()),
        pair_t0, pair_weights,
        [p[0] for p in pairs], [p[1] for p in pairs], [p[2] for p in pairs],
        [p[5] for p in pairs], [p[6] for p in pairs],
        hist_counts, hist_edges, pick_to_event)


def estimate_origin_times(
    picks: list[dict],
    channel_ids: list[str],
    nt: int,
    dt_s: float = 0.01,
    vp_vs: float = 1.73,
    min_ps_dt: float = 0.0,
    max_ps_dt: float = 20.0,
    bin_size: float = 1.0,
    mph: int = 5,
    mpd: int = 5,
    use_weights: bool = True,
    id_key: str = "channel_index",
    origin_window: float = None,
    moveout_window: float = None,
) -> AssociationResult:
    """Convenience wrapper: PS-pair origin estimation + association."""
    pairs = estimate_origins_from_ps_pairs(
        picks, dt_s=dt_s, vp_vs=vp_vs,
        min_ps_dt=min_ps_dt, max_ps_dt=max_ps_dt, id_key=id_key,
    )
    return associate_picks(
        pairs, nt, dt_s=dt_s, bin_size=bin_size,
        mph=mph, mpd=mpd, use_weights=use_weights,
        origin_window=origin_window, moveout_window=moveout_window,
    )
