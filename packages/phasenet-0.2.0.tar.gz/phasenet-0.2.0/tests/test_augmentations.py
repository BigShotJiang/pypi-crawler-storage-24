#!/usr/bin/env python
"""Visualize each augmentation independently.

For each augmentation, generates N figures showing the effect on training samples.
This helps verify that each augmentation is working correctly.

Usage:
    python scripts/test_augmentations.py \
        --label-list results/das_arcata/phasenet/labels.txt \
        --noise-list results/das_arcata/phasenet/noise_list.txt \
        --output-dir figures/test_augmentations \
        --n-samples 10
"""
import argparse
import os
import random
import sys

sys.path.insert(0, ".")

import matplotlib
matplotlib.use("Agg")
import numpy as np

from phasenet.data.das import (
    ColoredNoise,
    FlipLR,
    LabelConfig,
    Masking,
    MedianFilter,
    Normalize,
    RandomCrop,
    Sample,
    StackNoise,
    generate_labels,
    load_sample_from_h5,
    plot_overview,
)
from phasenet.data.transforms import (
    Compose,
    RandomBandpass,
    ResampleTime,
)


def load_samples(label_list_file, n=5):
    """Load n samples from label list."""
    with open(label_list_file) as f:
        lines = [l.strip() for l in f if l.strip()]

    samples = []
    for line in lines[:n]:
        data_path, label_path = line.split(",", 1)
        import pandas as pd
        picks_df = pd.read_parquet(label_path)
        if "channel_index" not in picks_df.columns:
            picks_df = picks_df.rename(columns={"station_id": "channel_index"})
        sample = load_sample_from_h5(data_path, picks_df, ["P", "S"])
        if sample is not None:
            sample.file_name = os.path.splitext(os.path.basename(data_path))[0]
            samples.append(sample)
    return samples


def plot_sample(sample, output_path, title=""):
    """Generate labels and plot a sample."""
    config = LabelConfig()
    labels = generate_labels(sample, config)
    plot_overview(sample, labels, title=title, save_path=output_path)


def test_single_augmentation(samples, transform, name, output_dir, nt=3072, nx=1024,
                             n_per_sample=5, before_crop=False):
    """Apply a single augmentation to samples and plot results.

    Args:
        before_crop: If True, apply transform before RandomCrop (for ResampleTime/ResampleSpace).
    """
    aug_dir = os.path.join(output_dir, name)
    os.makedirs(aug_dir, exist_ok=True)

    count = 0
    for sample in samples:
        for i in range(n_per_sample):
            s = sample.copy()
            if before_crop:
                s = transform(s)
            crop = RandomCrop(nt=nt, nx=nx)
            s = crop(s)
            if not before_crop:
                s = transform(s)
            norm = Normalize()
            s = norm(s)

            plot_sample(s, os.path.join(aug_dir, f"{sample.file_name}_{i:02d}.png"),
                        title=f"{name} — {sample.file_name}_{i:02d}")
            count += 1

    print(f"  {name}: {count} figures → {aug_dir}/")


def test_self_stacking(samples, output_dir, nt=3072, nx=1024, n_per_sample=5):
    """Test RandomCrop with stack_self=True."""
    name = "self_stacking"
    aug_dir = os.path.join(output_dir, name)
    os.makedirs(aug_dir, exist_ok=True)

    count = 0
    for sample in samples:
        for i in range(n_per_sample):
            s = sample.copy()
            crop = RandomCrop(nt=nt, nx=nx, stack_self=True, stack_self_p=1.0)
            s = crop(s)
            norm = Normalize()
            s = norm(s)

            plot_sample(s, os.path.join(aug_dir, f"{sample.file_name}_{i:02d}.png"),
                        title=f"{name} — {sample.file_name}_{i:02d}")
            count += 1

    print(f"  {name}: {count} figures → {aug_dir}/")


def test_noise_stacking(samples, noise_list_file, output_dir, nt=3072, nx=1024,
                        n_per_sample=5, min_snr=1.0, max_snr=5.0,
                        name="noise_stacking"):
    """Test StackNoise with actual noise files."""
    import h5py

    aug_dir = os.path.join(output_dir, name)
    os.makedirs(aug_dir, exist_ok=True)

    with open(noise_list_file) as f:
        noise_files = [l.strip() for l in f if l.strip()]

    def load_noise():
        path = random.choice(noise_files)
        with h5py.File(path, "r") as fp:
            data = fp["data"][:, :]
        return data[np.newaxis, :, :].astype(np.float32)

    stack_noise = StackNoise(min_snr=min_snr, max_snr=max_snr, p=1.0)
    stack_noise.set_noise_fn(load_noise)

    count = 0
    for sample in samples:
        for i in range(n_per_sample):
            s = sample.copy()
            crop = RandomCrop(nt=nt, nx=nx)
            s = crop(s)
            s = stack_noise(s)
            norm = Normalize()
            s = norm(s)

            plot_sample(s, os.path.join(aug_dir, f"{sample.file_name}_{i:02d}.png"),
                        title=f"{name} — {sample.file_name}_{i:02d}")
            count += 1

    print(f"  {name}: {count} figures → {aug_dir}/")


def main():
    parser = argparse.ArgumentParser(description="Test augmentations visually")
    parser.add_argument("--label-list", required=True)
    parser.add_argument("--noise-list", default=None)
    parser.add_argument("--output-dir", default="figures/test_augmentations")
    parser.add_argument("--n-samples", type=int, default=5, help="Number of source samples to load")
    parser.add_argument("--n-per-sample", type=int, default=5, help="Augmented versions per sample")
    parser.add_argument("--nt", type=int, default=3072)
    parser.add_argument("--nx", type=int, default=1024)
    parser.add_argument("--only", nargs="+", default=None,
                        help="Only test specific augmentations (e.g. --only noise_stacking self_stacking)")
    args = parser.parse_args()

    print("Loading samples...")
    samples = load_samples(args.label_list, n=args.n_samples)
    print(f"Loaded {len(samples)} samples")

    # Baseline: just crop + normalize (no augmentation)
    print("\nGenerating baseline (crop only)...")
    test_single_augmentation(
        samples, Compose([]),  # identity — crop is applied inside test_single_augmentation
        "00_baseline", args.output_dir, args.nt, args.nx, args.n_per_sample)

    # Test each augmentation independently
    # (name, transform, before_crop)
    augmentations = [
        ("01_resample_time_0.5x", ResampleTime(0.5, 0.5), True),
        ("02_resample_time_2.0x", ResampleTime(2.0, 2.0), True),
        ("03_resample_time_random", ResampleTime(0.5, 3.0), True),
        ("04_flip_lr", FlipLR(p=1.0), False),
        ("05_masking", Masking(max_mask_nt=256, p=1.0), False),
        ("06_median_filter", MedianFilter(p=1.0), False),
        ("07_colored_noise", ColoredNoise(snr_db_range=(5, 15), p=1.0), False),
        ("08_random_bandpass", RandomBandpass(p=1.0), False),
    ]

    for name, transform, before_crop in augmentations:
        print(f"Testing {name}...")
        test_single_augmentation(
            samples, transform, name, args.output_dir,
            args.nt, args.nx, args.n_per_sample, before_crop=before_crop)

    # Self-stacking (inside RandomCrop)
    print("Testing self_stacking...")
    test_self_stacking(samples, args.output_dir, args.nt, args.nx, args.n_per_sample)

    # Noise stacking tests
    if args.noise_list:
        print("Testing noise_stacking (SNR 1-5, random)...")
        test_noise_stacking(
            samples, args.noise_list, args.output_dir,
            args.nt, args.nx, args.n_per_sample,
            min_snr=1.0, max_snr=5.0, name="noise_stacking_snr_1-5")

        # Fixed target SNR = 2.0
        print("Testing noise_stacking (SNR=2.0, fixed)...")
        test_noise_stacking(
            samples, args.noise_list, args.output_dir,
            args.nt, args.nx, args.n_per_sample,
            min_snr=2.0, max_snr=2.0, name="noise_stacking_snr_2.0")

        # Fixed target SNR = 1.0 (signal barely visible)
        print("Testing noise_stacking (SNR=1.0, fixed)...")
        test_noise_stacking(
            samples, args.noise_list, args.output_dir,
            args.nt, args.nx, args.n_per_sample,
            min_snr=1.0, max_snr=1.0, name="noise_stacking_snr_1.0")

    print(f"\nDone! All figures in {args.output_dir}/")


if __name__ == "__main__":
    main()
