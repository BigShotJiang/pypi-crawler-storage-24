"""Synthetic corner-case tests for generate_labels in ceed.py and das.py.

Each case runs BOTH ceed and das label generation side by side.
Run: python tests/test_labels.py
"""
import sys
sys.path.insert(0, ".")

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

from phasenet.data.ceed import (
    Target as CTarget, Sample as CSample,
    LabelConfig as CLabelConfig, generate_labels as ceed_labels,
)
from phasenet.data.das import (
    Target as DTarget, Sample as DSample,
    LabelConfig as DLabelConfig, generate_labels as das_labels,
)

NX = 16  # default number of stations/channels


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_targets(p_picks, s_picks, ps_centers, ps_intervals):
    """Create both CEED and DAS Target from the same pick data."""
    ct = CTarget(
        p_picks=list(p_picks), s_picks=list(s_picks),
        ps_centers=list(ps_centers), ps_intervals=list(ps_intervals),
    )
    dt = DTarget(
        p_picks=list(p_picks), s_picks=list(s_picks),
        ps_centers=list(ps_centers), ps_intervals=list(ps_intervals),
    )
    return ct, dt


def picks_from_ps(nx, p_times, s_times):
    """Build picks, centers, intervals from per-station P and S time arrays.

    p_times/s_times: list of (sta, time) or None entries.
    Only stations with both P and S get ps_centers/ps_intervals.
    """
    p_picks = [(sta, t) for sta, t in p_times]
    s_picks = [(sta, t) for sta, t in s_times]
    p_dict = {sta: t for sta, t in p_picks}
    s_dict = {sta: t for sta, t in s_picks}
    centers, intervals = [], []
    for sta in sorted(set(p_dict) & set(s_dict)):
        if s_dict[sta] > p_dict[sta]:
            centers.append((sta, (p_dict[sta] + s_dict[sta]) / 2))
            intervals.append((sta, s_dict[sta] - p_dict[sta]))
    return p_picks, s_picks, centers, intervals


def run_both(nx, nt, ceed_targets, das_targets):
    """Generate labels from both ceed and das, return (ceed_labels, das_labels)."""
    cs = CSample(
        waveform=np.random.randn(3, nx, nt).astype(np.float32),
        targets=ceed_targets,
    )
    ds = DSample(
        waveform=np.random.randn(1, nx, nt).astype(np.float32),
        targets=das_targets,
    )
    return ceed_labels(cs, CLabelConfig()), das_labels(ds, DLabelConfig())


def plot_pair(cl, dl, title, nx, nt):
    """Plot ceed (left) and das (right) labels side by side."""
    panel_names = ["Noise", "P", "S", "Phase Mask",
                   "Event Center", "Event Center Mask",
                   "Event Time", "Event Time Mask"]

    def get_arrays(labels):
        return [
            labels["phase_pick"][0],
            labels["phase_pick"][1],
            labels["phase_pick"][2],
            labels["phase_mask"][0],
            labels["event_center"][0],
            labels["event_center_mask"][0],
            labels["event_time"][0],
            labels["event_time_mask"][0],
        ]

    c_arr = get_arrays(cl)
    d_arr = get_arrays(dl)
    n_panels = len(panel_names)

    fig, axes = plt.subplots(n_panels, 2, figsize=(18, 2.0 * n_panels), sharex=True)
    fig.suptitle(title, fontsize=14, fontweight="bold")
    axes[0, 0].set_title("CEED", fontsize=12)
    axes[0, 1].set_title("DAS", fontsize=12)

    for row, (name, ca, da) in enumerate(zip(panel_names, c_arr, d_arr)):
        for col, arr in enumerate([ca, da]):
            ax = axes[row, col]
            if nx == 1:
                ax.plot(arr[0], linewidth=0.8)
                ax.set_ylim(-0.1 if "Time" not in name else None,
                            1.1 if "Time" not in name else None)
            else:
                im = ax.imshow(arr, aspect="auto", origin="lower",
                               extent=[0, nt, 0, nx], interpolation="none")
                plt.colorbar(im, ax=ax, fraction=0.02, pad=0.01)
            if col == 0:
                ax.set_ylabel(name, fontsize=9)
    axes[-1, 0].set_xlabel("Time (samples)")
    axes[-1, 1].set_xlabel("Time (samples)")
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    return fig


# ---------------------------------------------------------------------------
# Test cases — each returns (ceed_labels, das_labels, title, nx, nt)
# ---------------------------------------------------------------------------

def case1_single_event():
    """Single event across all stations with moveout."""
    nx, nt = NX, 4096
    p_times = [(sta, 800 + sta * 50) for sta in range(nx)]
    s_times = [(sta, 800 + sta * 50 + 400 + sta * 20) for sta in range(nx)]
    p, s, ec, ps = picks_from_ps(nx, p_times, s_times)
    ct, dt = make_targets(p, s, ec, ps)
    cl, dl = run_both(nx, nt, [ct], [dt])
    return cl, dl, "Case 1: Single event, moveout across all stations", nx, nt


def case2_two_events():
    """Two events on the same stations — multi-event windowed masking."""
    nx, nt = NX, 8192
    ceed_targets, das_targets = [], []
    for t_offset in [1000, 5000]:
        p_times = [(sta, t_offset + sta * 30) for sta in range(nx)]
        s_times = [(sta, t_offset + sta * 30 + 500) for sta in range(nx)]
        p, s, ec, ps = picks_from_ps(nx, p_times, s_times)
        ct, dt = make_targets(p, s, ec, ps)
        ceed_targets.append(ct)
        das_targets.append(dt)
    cl, dl = run_both(nx, nt, ceed_targets, das_targets)
    return cl, dl, "Case 2: Two events on same stations (windowed masks)", nx, nt


def case3_p_only_stations():
    """Some stations have only P, no S — should get NO phase mask."""
    nx, nt = NX, 4096
    # Stations 0-7: both P and S
    # Stations 8-15: P only
    p_times = [(sta, 600 + sta * 30) for sta in range(nx)]
    s_times = [(sta, 1000 + sta * 30) for sta in range(nx // 2)]
    p, s, ec, ps = picks_from_ps(nx, p_times, s_times)
    ct, dt = make_targets(p, s, ec, ps)
    cl, dl = run_both(nx, nt, [ct], [dt])
    return cl, dl, "Case 3: Sta 0-7 have P+S (masked), Sta 8-15 P only (no mask)", nx, nt


def case4_cross_event_picks():
    """P from event A, S from event B on same station — no mask.

    Stations 0-7: normal event A (P+S pair)
    Stations 8-15: P from event A, S from event B (cross-event)
    """
    nx, nt = NX, 4096
    # Event A: P+S on sta 0-7, P only on sta 8-15
    p_a = [(sta, 500 + sta * 30) for sta in range(nx)]
    s_a = [(sta, 900 + sta * 30) for sta in range(nx // 2)]
    _, _, ec_a, ps_a = picks_from_ps(nx, p_a, s_a)
    ct_a = CTarget(p_picks=p_a, s_picks=s_a, ps_centers=ec_a, ps_intervals=ps_a)
    dt_a = DTarget(p_picks=list(p_a), s_picks=list(s_a), ps_centers=list(ec_a), ps_intervals=list(ps_a))

    # Event B: S only on sta 8-15
    s_b = [(sta, 2500 + sta * 30) for sta in range(nx // 2, nx)]
    ct_b = CTarget(p_picks=[], s_picks=s_b, ps_centers=[], ps_intervals=[])
    dt_b = DTarget(p_picks=[], s_picks=list(s_b), ps_centers=[], ps_intervals=[])

    cl, dl = run_both(nx, nt, [ct_a, ct_b], [dt_a, dt_b])
    return cl, dl, "Case 4: Sta 0-7 normal, Sta 8-15 cross-event P(A)+S(B)", nx, nt


def case5_no_events():
    """Pure noise — no targets."""
    nx, nt = NX, 4096
    cl, dl = run_both(nx, nt, [], [])
    return cl, dl, "Case 5: No events (pure noise)", nx, nt


def case6_event_near_boundary():
    """Event near start of window — Gaussian clipped at t=0."""
    nx, nt = NX, 4096
    p_times = [(sta, 50 + sta * 10) for sta in range(nx)]
    s_times = [(sta, 450 + sta * 15) for sta in range(nx)]
    p, s, ec, ps = picks_from_ps(nx, p_times, s_times)
    ct, dt = make_targets(p, s, ec, ps)
    cl, dl = run_both(nx, nt, [ct], [dt])
    return cl, dl, "Case 6: Event near boundary (P~50, S~450)", nx, nt


def case7_crop_loses_picks():
    """Crop causes far stations to lose S picks.

    S-P interval grows with distance. After crop_time/crop,
    near stations keep both picks, far stations lose S.
    Centers may survive the crop even when S is gone —
    the p_stas/s_stas guard in generate_labels handles this.
    """
    nx = NX
    p_picks, s_picks, centers, intervals = [], [], [], []
    for sta in range(nx):
        p_t = 2000 + sta * 50
        s_t = p_t + 400 + sta * 150  # S-P: 400..2650
        p_picks.append((sta, p_t))
        s_picks.append((sta, s_t))
        centers.append((sta, (p_t + s_t) / 2))
        intervals.append((sta, s_t - p_t))

    crop_start, crop_end = 1800, 3800

    # CEED
    ct = CTarget(
        p_picks=list(p_picks), s_picks=list(s_picks),
        ps_centers=list(centers), ps_intervals=list(intervals),
    )
    ct.crop_time(crop_start, crop_end)

    # DAS (crop in time only: x0=0, nx=nx)
    dt = DTarget(
        p_picks=list(p_picks), s_picks=list(s_picks),
        ps_centers=list(centers), ps_intervals=list(intervals),
    )
    dt.crop(crop_start, crop_end - crop_start, 0, nx)

    nt_crop = crop_end - crop_start
    cl, dl = run_both(nx, nt_crop, [ct], [dt])
    return cl, dl, "Case 7: Cropped — near sta keep P+S, far sta lose S", nx, nt_crop


def case8_partial_channels():
    """Event only on a subset of stations/channels."""
    nx, nt = NX, 4096
    # Event on stations 4-11 only
    p_times = [(sta, 1000 + (sta - 4) * 30) for sta in range(4, 12)]
    s_times = [(sta, 1500 + (sta - 4) * 30) for sta in range(4, 12)]
    p, s, ec, ps = picks_from_ps(nx, p_times, s_times)
    ct, dt = make_targets(p, s, ec, ps)
    cl, dl = run_both(nx, nt, [ct], [dt])
    return cl, dl, "Case 8: Event on stations 4-11 only", nx, nt


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    cases = [
        case1_single_event,
        case2_two_events,
        case3_p_only_stations,
        case4_cross_event_picks,
        case5_no_events,
        case6_event_near_boundary,
        case7_crop_loses_picks,
        case8_partial_channels,
    ]

    figs = []
    for case_fn in cases:
        cl, dl, title, nx, nt = case_fn()
        fig = plot_pair(cl, dl, title, nx, nt)
        figs.append(fig)
        pm_c = cl["phase_mask"][0].mean()
        pm_d = dl["phase_mask"][0].mean()
        ecm_c = cl["event_center_mask"][0].mean()
        ecm_d = dl["event_center_mask"][0].mean()
        print(f"  {title}")
        print(f"    CEED: phase_mask={pm_c:.3f}  event_center_mask={ecm_c:.3f}")
        print(f"    DAS:  phase_mask={pm_d:.3f}  event_center_mask={ecm_d:.3f}")

    out_path = "tests/test_labels.pdf"
    with PdfPages(out_path) as pdf:
        for fig in figs:
            pdf.savefig(fig)
            plt.close(fig)
    print(f"\nSaved {len(figs)} pages to {out_path}")
