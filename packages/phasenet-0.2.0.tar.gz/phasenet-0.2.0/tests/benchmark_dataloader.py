"""Benchmark the DAS data loading pipeline step by step."""
import time
import argparse
import numpy as np
import random
import torch
import torch.nn.functional as F

# ── Step 0: measure H5 load time ──────────────────────────────────────────
def benchmark_h5_load(label_files, label_path, data_path, n=4):
    """Time loading H5 files from disk."""
    import h5py
    import os
    import pandas as pd

    times = []
    for lf in label_files[:n]:
        h5_file = os.path.join(data_path, lf + ".h5")
        pick_file = os.path.join(label_path, lf + ".csv")
        t0 = time.perf_counter()
        with h5py.File(h5_file, "r") as fp:
            data = fp["data"][:, :]
        t1 = time.perf_counter()
        times.append(t1 - t0)
        print(f"  H5 load {lf}: {t1-t0:.3f}s  shape={data.shape}  size={data.nbytes/1e6:.0f}MB")
    print(f"  Average H5 load: {np.mean(times):.3f}s")
    return times


# ── Step 1: measure copy costs ────────────────────────────────────────────
def benchmark_copy(sample, n=20):
    """Compare deep vs shallow copy."""
    # Deep copy
    times_deep = []
    for _ in range(n):
        t0 = time.perf_counter()
        s = sample.copy(deep_waveform=True)
        times_deep.append(time.perf_counter() - t0)

    # Shallow copy
    times_shallow = []
    for _ in range(n):
        t0 = time.perf_counter()
        s = sample.copy(deep_waveform=False)
        times_shallow.append(time.perf_counter() - t0)

    print(f"  Deep copy:    {np.mean(times_deep)*1000:.1f}ms  (waveform {sample.waveform.nbytes/1e6:.0f}MB)")
    print(f"  Shallow copy: {np.mean(times_shallow)*1000:.3f}ms")
    return times_deep, times_shallow


# ── Step 2: measure individual transforms ─────────────────────────────────
def benchmark_transforms(sample, transforms, n=10):
    """Time each transform individually on a sample."""
    from phasenet.data.transforms import Compose

    for tfm in transforms.transforms:
        times = []
        for _ in range(n):
            s = sample.copy(deep_waveform=True)  # fresh copy each time
            t0 = time.perf_counter()
            s = tfm(s)
            times.append(time.perf_counter() - t0)
        print(f"  {tfm.__class__.__name__:20s}: {np.mean(times)*1000:8.2f}ms  (median {np.median(times)*1000:.2f}ms)")

    # Full pipeline
    times = []
    for _ in range(n):
        s = sample.copy(deep_waveform=True)
        t0 = time.perf_counter()
        s = transforms(s)
        times.append(time.perf_counter() - t0)
    print(f"  {'FULL PIPELINE':20s}: {np.mean(times)*1000:8.2f}ms  (median {np.median(times)*1000:.2f}ms)")


# ── Step 3: measure label generation ──────────────────────────────────────
def benchmark_labels(sample, transforms, label_config, event_feature_scale, n=20):
    """Time generate_labels and _to_output on a cropped sample."""
    from phasenet.data.das import generate_labels, _to_output

    # Crop first
    cropped = sample.copy(deep_waveform=True)
    cropped = transforms(cropped)

    # generate_labels
    times_gen = []
    for _ in range(n):
        t0 = time.perf_counter()
        labels = generate_labels(cropped, label_config)
        times_gen.append(time.perf_counter() - t0)
    print(f"  generate_labels:    {np.mean(times_gen)*1000:.2f}ms  (nx={cropped.nx}, nt={cropped.nt})")

    # max_pool2d downsampling
    times_ds = []
    s = event_feature_scale
    for _ in range(n):
        t0 = time.perf_counter()
        for key in ["event_center", "event_time", "event_center_mask", "event_time_mask"]:
            t = torch.from_numpy(labels[key]).float().unsqueeze(0)
            t = F.max_pool2d(t, kernel_size=(s, 1), stride=(s, 1)).squeeze(0)
            _ = t[:, :, ::s]
        times_ds.append(time.perf_counter() - t0)
    print(f"  max_pool2d ds:      {np.mean(times_ds)*1000:.2f}ms")

    # Full _to_output
    times_out = []
    for _ in range(n):
        t0 = time.perf_counter()
        output = _to_output(cropped, label_config, event_feature_scale)
        times_out.append(time.perf_counter() - t0)
    print(f"  _to_output total:   {np.mean(times_out)*1000:.2f}ms")


# ── Step 4: measure resample transforms ───────────────────────────────────
def benchmark_resample(sample, n=5):
    """Time ResampleTime and ResampleSpace on full-size waveform."""
    from phasenet.data.das import ResampleSpace
    from phasenet.data.transforms import ResampleTime

    rt = ResampleTime(min_factor=0.5, max_factor=2.0, p=1.0)
    times_rt = []
    for _ in range(n):
        s = sample.copy(deep_waveform=True)
        t0 = time.perf_counter()
        s = rt(s)
        times_rt.append(time.perf_counter() - t0)
    print(f"  ResampleTime (full): {np.mean(times_rt)*1000:.1f}ms  shape {sample.waveform.shape}")

    rs = ResampleSpace(min_factor=0.5, max_factor=2.0, p=1.0)
    times_rs = []
    for _ in range(n):
        s = sample.copy(deep_waveform=True)
        t0 = time.perf_counter()
        s = rs(s)
        times_rs.append(time.perf_counter() - t0)
    print(f"  ResampleSpace(full): {np.mean(times_rs)*1000:.1f}ms")


# ── Step 5: measure retry cost ────────────────────────────────────────────
def benchmark_retry_loop(sample, transforms, label_config, event_feature_scale, n_files=2, num_patch=8):
    """Simulate the retry loop and count retries + time."""
    from phasenet.data.das import _to_output

    total_retries = 0
    total_samples = 0
    times = []

    for _ in range(n_files):
        for ii in range(num_patch):
            t0 = time.perf_counter()
            for retry in range(10):
                s = sample.copy(deep_waveform=False)
                s = transforms(s)
                output = _to_output(s, label_config, event_feature_scale)
                if output["event_center_mask"].mean() >= 0.02:
                    break
            times.append(time.perf_counter() - t0)
            total_retries += retry
            total_samples += 1

    print(f"  Avg retries per patch: {total_retries/total_samples:.1f}")
    print(f"  Avg time per patch:    {np.mean(times)*1000:.1f}ms")
    print(f"  Total for {n_files} files × {num_patch} patches: {sum(times):.2f}s")


# ── Step 6: measure full DataLoader throughput ────────────────────────────
def benchmark_dataloader(dataset, batch_size, num_workers, n_batches=20):
    """End-to-end DataLoader throughput."""
    loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        num_workers=num_workers,
        drop_last=True,
        pin_memory=True,
        persistent_workers=num_workers > 0,
        prefetch_factor=2 if num_workers > 0 else None,
    )
    it = iter(loader)

    # Warmup (first batch includes H5 loading)
    t0 = time.perf_counter()
    batch = next(it)
    t_first = time.perf_counter() - t0
    print(f"  First batch:  {t_first:.2f}s  (includes H5 load + cache warmup)")

    # Steady-state
    times = []
    for i in range(n_batches):
        t0 = time.perf_counter()
        batch = next(it)
        times.append(time.perf_counter() - t0)

    print(f"  Steady-state: {np.mean(times)*1000:.1f}ms/batch  (median {np.median(times)*1000:.1f}ms)")
    print(f"  Throughput:   {batch_size / np.mean(times):.1f} samples/s")
    print(f"  Batch shape:  data={batch['data'].shape}")

    del loader, it
    return times


# ── Step 7: measure GPU forward+backward ──────────────────────────────────
def benchmark_gpu(model, batch, n=20):
    """Time GPU forward + backward pass."""

    device = next(model.parameters()).device
    data = batch["data"].to(device, non_blocking=True)
    targets = {k: v.to(device, non_blocking=True) for k, v in batch.items()
               if isinstance(v, torch.Tensor) and k != "data"}

    # Warmup
    with torch.amp.autocast("cuda", dtype=torch.bfloat16):
        out = model(data)
    torch.cuda.synchronize()

    # Forward only
    times_fwd = []
    for _ in range(n):
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        with torch.amp.autocast("cuda", dtype=torch.bfloat16):
            out = model(data)
        torch.cuda.synchronize()
        times_fwd.append(time.perf_counter() - t0)

    # Forward + backward
    times_fb = []
    for _ in range(n):
        model.zero_grad()
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        with torch.amp.autocast("cuda", dtype=torch.bfloat16):
            out = model(data)
            # Simple loss: sum all outputs
            loss = sum(v.sum() for v in out.values() if isinstance(v, torch.Tensor) and v.requires_grad)
        loss.backward()
        torch.cuda.synchronize()
        times_fb.append(time.perf_counter() - t0)

    print(f"  Forward:          {np.mean(times_fwd)*1000:.1f}ms")
    print(f"  Forward+Backward: {np.mean(times_fb)*1000:.1f}ms")
    print(f"  Data shape: {data.shape}  Device: {device}")

    return times_fwd, times_fb


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-path", default="data/quakeflow_das/arcata/data")
    parser.add_argument("--label-path", default="results/das_debug/phasenet/arcata/picks")
    parser.add_argument("--label-list", default="results/das_debug/phasenet/arcata/labels.txt")
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--num-patch", type=int, default=8)
    parser.add_argument("--nx", type=int, default=2048)
    parser.add_argument("--nt", type=int, default=4096)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()

    with open(args.label_list) as f:
        label_files = [line.strip() for line in f if line.strip()]
    print(f"Label files: {label_files}")

    # ── Step 0: H5 load ───────────────────────────────────────────────────
    print("\n=== Step 0: H5 File Loading ===")
    benchmark_h5_load(label_files, args.label_path, args.data_path)

    # ── Setup dataset for remaining benchmarks ────────────────────────────
    from phasenet.data.das import (
        DASIterableDataset, load_sample_from_h5, generate_labels,
        _to_output, LabelConfig, default_train_transforms,
    )
    from phasenet.data.das import ResampleSpace
    from phasenet.data.transforms import ResampleTime
    import os
    import pandas as pd

    # Load one sample for micro-benchmarks
    lf = label_files[0]
    h5_file = os.path.join(args.data_path, lf + ".h5")
    pick_file = os.path.join(args.label_path, lf + ".parquet")
    if os.path.exists(pick_file):
        picks_df = pd.read_parquet(pick_file)
    else:
        pick_file = os.path.join(args.label_path, lf + ".csv")
        picks_df = pd.read_csv(pick_file)
    sample = load_sample_from_h5(h5_file, picks_df)
    print(f"\nSample loaded: waveform={sample.waveform.shape}, targets={len(sample.targets)}")

    transforms = default_train_transforms(nt=args.nt, nx=args.nx)
    label_config = LabelConfig()
    event_feature_scale = 4

    # ── Step 1: Copy costs ────────────────────────────────────────────────
    print("\n=== Step 1: Copy Costs ===")
    benchmark_copy(sample)

    # ── Step 2: Individual transforms ─────────────────────────────────────
    print("\n=== Step 2a: Individual Transforms (on full-size sample — for reference) ===")
    benchmark_transforms(sample, transforms, n=10)

    # Also measure on cropped data (the realistic case)
    from phasenet.data.transforms import RandomCrop, Compose
    crop_tfm = RandomCrop(nt=args.nt, nx=args.nx)
    cropped_sample = sample.copy(deep_waveform=True)
    cropped_sample = crop_tfm(cropped_sample)

    post_crop_transforms = Compose(transforms.transforms[1:])  # skip RandomCrop
    print(f"\n=== Step 2b: Individual Transforms (on CROPPED sample {cropped_sample.waveform.shape}) ===")
    benchmark_transforms(cropped_sample, post_crop_transforms, n=20)

    # ── Step 3: Label generation ──────────────────────────────────────────
    print("\n=== Step 3: Label Generation (on cropped sample) ===")
    benchmark_labels(sample, transforms, label_config, event_feature_scale, n=20)

    # ── Step 4: Resample transforms ───────────────────────────────────────
    print("\n=== Step 4: Resample Transforms (on full-size waveform) ===")
    benchmark_resample(sample, n=5)

    # ── Step 5: Retry loop simulation ─────────────────────────────────────
    print("\n=== Step 5: Retry Loop Simulation ===")
    benchmark_retry_loop(sample, transforms, label_config, event_feature_scale,
                         n_files=2, num_patch=args.num_patch)

    # ── Step 6: DataLoader throughput ─────────────────────────────────────
    for nw in [0, 2, 4]:
        print(f"\n=== Step 6: DataLoader Throughput (workers={nw}) ===")
        dataset = DASIterableDataset(
            data_path=args.data_path,
            label_path=args.label_path,
            label_list=[args.label_list],
            nt=args.nt,
            nx=args.nx,
            num_patch=args.num_patch,
            training=True,
        )
        try:
            benchmark_dataloader(dataset, args.batch_size, nw, n_batches=20)
        except Exception as e:
            print(f"  Error: {e}")

    # ── Step 7: GPU forward+backward ──────────────────────────────────────
    if torch.cuda.is_available() and args.device == "cuda":
        print(f"\n=== Step 7: GPU Forward+Backward ===")
        from phasenet.models.phasenet_das_plus import build_model
        model = build_model().to(args.device)
        model.train()

        # Get a real batch
        dataset = DASIterableDataset(
            data_path=args.data_path,
            label_path=args.label_path,
            label_list=[args.label_list],
            nt=args.nt,
            nx=args.nx,
            num_patch=args.num_patch,
            training=True,
        )
        loader = torch.utils.data.DataLoader(dataset, batch_size=args.batch_size,
                                              num_workers=0, drop_last=True)
        batch = next(iter(loader))
        del loader

        benchmark_gpu(model, batch, n=20)

    # ── Summary ───────────────────────────────────────────────────────────
    print("\n=== Summary ===")
    print("Target: GPU should never wait for data.")
    print("If data_time >> model_time, increase workers or optimize transforms.")
    print("If data_time << model_time, GPU is the bottleneck (good).")


if __name__ == "__main__":
    main()
