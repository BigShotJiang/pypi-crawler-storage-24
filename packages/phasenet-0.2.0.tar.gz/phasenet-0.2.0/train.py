"""
Training script for PhaseNet models.

Follows best practices from:
- Karpathy's nanoGPT: Clean, minimal, educational
- timm: Registry patterns, good defaults
- torchvision: Reference training scripts, distributed utilities

Usage:
    python train.py --model phasenet --dataset-type ceed --streaming
    python train.py --model phasenet_das --data-path /path/to/data
"""
import datetime
import logging
import math
import os
import random
import time
from contextlib import nullcontext
from typing import Optional

import matplotlib
import numpy as np
import torch
import torch.nn as nn
import torch.utils.data

matplotlib.use("agg")

import phasenet
import phasenet.utils as phasenet_utils
import utils

try:
    import wandb
except ImportError:
    wandb = None
from phasenet.data import (
    CEEDDataset,
    CEEDIterableDataset,
    DASIterableDataset,
)
from phasenet.data.ceed import default_eval_transforms as ceed_eval_transforms
from phasenet.data.ceed import default_train_transforms as ceed_train_transforms
from phasenet.data.das import default_eval_transforms as das_eval_transforms
from phasenet.data.das import default_train_transforms as das_train_transforms
from phasenet.models.unet import moving_normalize

# DAS model names for dataset selection
DAS_MODELS = {"phasenet_das", "phasenet_das_plus"}

logger = logging.getLogger("PhaseNet")

# =============================================================================
# Configuration
# =============================================================================

# Model feature registry - which losses each model uses
MODEL_FEATURES = {
    "phasenet": {"phase"},
    "phasenet_tf": {"phase"},
    "phasenet_plus": {"phase", "event", "polarity"},
    "phasenet_tf_plus": {"phase", "event", "polarity"},
    "phasenet_prompt": {"phase", "event", "polarity", "prompt"},
    "phasenet_das": {"phase"},
    "phasenet_das_plus": {"phase", "event"},
}


def get_model_features(model_name: str) -> set:
    """Get features supported by a model."""
    return MODEL_FEATURES.get(model_name, {"phase"})


# =============================================================================
# Learning Rate Schedule (Karpathy style)
# =============================================================================

def get_lr(step: int, max_lr: float, min_lr: float, warmup_steps: int, max_steps: int) -> float:
    """Cosine learning rate schedule with linear warmup."""
    if step < warmup_steps:
        return (max_lr - min_lr) * step / max(1, warmup_steps) + min_lr
    if step >= max_steps or max_steps <= warmup_steps:
        return min_lr
    decay_ratio = (step - warmup_steps) / (max_steps - warmup_steps)
    coeff = 0.5 * (1.0 + math.cos(math.pi * decay_ratio))
    return min_lr + coeff * (max_lr - min_lr)


# =============================================================================
# Training Step and Evaluation
# =============================================================================

def train_step(model, batch, optimizer, lr_scheduler, scaler, model_ema, args, global_step,
               micro_step=0):
    """Execute a single training step (micro-batch). Returns output dict.

    With gradient accumulation (--gradient-accumulation-steps N), this is called
    N times per optimizer step. Only the last micro-step triggers optimizer.step().
    """
    accum_steps = args.gradient_accumulation_steps
    is_last_micro = (micro_step + 1) == accum_steps
    ctx = (
        nullcontext()
        if args.device in ["cpu", "mps"]
        else torch.amp.autocast(device_type=args.device, dtype=args.ptdtype)
    )

    with ctx:
        output = model(batch)
    loss = output["loss"] / accum_steps

    # Skip backward if loss has no grad_fn (all masked losses returned None)
    if not loss.requires_grad:
        return output

    if scaler is not None:
        scaler.scale(loss).backward()
        if is_last_micro:
            if args.clip_grad_norm is not None:
                scaler.unscale_(optimizer)
                nn.utils.clip_grad_norm_(model.parameters(), args.clip_grad_norm)
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad()
    else:
        loss.backward()
        if is_last_micro:
            if args.clip_grad_norm is not None:
                nn.utils.clip_grad_norm_(model.parameters(), args.clip_grad_norm)
            optimizer.step()
            optimizer.zero_grad()

    if is_last_micro:
        lr_scheduler.step()
        if model_ema and global_step % args.model_ema_steps == 0:
            model_ema.update_parameters(model)
            if global_step < args.lr_warmup_iters:
                model_ema.n_averaged.fill_(0)

    return output


def cache_test_batches(data_loader, max_batches):
    """Cache a fixed set of test batches from a dataloader for deterministic eval."""
    batches = []
    for i, batch in enumerate(data_loader):
        if i >= max_batches:
            break
        batches.append(batch)
    print(f"Cached {len(batches)} test batches (fixed across evaluations)")
    return batches


@torch.inference_mode()
def evaluate(model, test_batches, args, global_step):
    """Evaluate the model on a fixed set of cached test batches."""
    features = get_model_features(args.model)
    metric_logger = utils.MetricLogger(delimiter="  ")

    for feat in features:
        if feat == "phase":
            metric_logger.add_meter("loss_phase", utils.SmoothedValue(window_size=1, fmt="{value}"))
        elif feat == "event":
            metric_logger.add_meter("loss_event_center", utils.SmoothedValue(window_size=1, fmt="{value}"))
            metric_logger.add_meter("loss_event_time", utils.SmoothedValue(window_size=1, fmt="{value}"))
        elif feat == "polarity":
            metric_logger.add_meter("loss_polarity", utils.SmoothedValue(window_size=1, fmt="{value}"))
        elif feat == "prompt":
            metric_logger.add_meter("loss_prompt", utils.SmoothedValue(window_size=1, fmt="{value}"))

    model.eval()
    last_batch, last_output = None, None

    for i, batch in enumerate(metric_logger.log_every(test_batches, args.print_freq, "Test:")):
        output = model(batch)
        last_batch, last_output = batch, output
        batch_size = batch["data"].shape[0]

        metric_logger.meters["loss"].update(output["loss"].item(), n=batch_size)
        for feat in features:
            if feat == "phase" and "loss_phase" in output:
                metric_logger.meters["loss_phase"].update(output["loss_phase"].item(), n=batch_size)
            elif feat == "event":
                if "loss_event_center" in output:
                    metric_logger.meters["loss_event_center"].update(output["loss_event_center"].item(), n=batch_size)
                if "loss_event_time" in output:
                    metric_logger.meters["loss_event_time"].update(output["loss_event_time"].item(), n=batch_size)
            elif feat == "polarity" and "loss_polarity" in output:
                metric_logger.meters["loss_polarity"].update(output["loss_polarity"].item(), n=batch_size)
            elif feat == "prompt" and "loss_prompt" in output:
                metric_logger.meters["loss_prompt"].update(output["loss_prompt"].item(), n=batch_size)

    metric_logger.synchronize_between_processes()
    print(f"Test loss = {metric_logger.loss.global_avg:.3e}")

    if args.wandb and utils.is_main_process():
        log = {"test/loss": metric_logger.loss.global_avg, "test/step": global_step}
        for key in ["loss_phase", "loss_event_center", "loss_event_time", "loss_polarity", "loss_prompt"]:
            if hasattr(metric_logger, key):
                log[f"test/{key}"] = getattr(metric_logger, key).global_avg
        wandb.log(log, step=global_step)

    plot_results(last_batch, last_output, args, global_step, "test")
    return metric_logger


def plot_results(batch, output, args, step, prefix=""):
    """Plot training/evaluation results."""
    if batch is None or output is None:
        return

    with torch.inference_mode():
        if "phase" not in output:
            return

        phase = torch.softmax(output["phase"], dim=1).cpu().float()
        if args.moving_norm:
            normalized = moving_normalize(batch["data"]).cpu().float()
        data = batch["data"].cpu().float()
        batch["raw_data"] = data
        batch["data"] = normalized if args.moving_norm else data

        # DAS models
        if args.model == "phasenet_das":
            phasenet_utils.plot_phasenet_das_train(
                batch, phase, epoch=step, figure_dir=args.figure_dir, prefix=prefix,
            )
        elif args.model == "phasenet_das_plus":
            event_center = torch.sigmoid(output["event_center"]).cpu().float() if "event_center" in output else None
            event_time = output["event_time"].cpu().float() if "event_time" in output else None
            phasenet_utils.plot_phasenet_das_plus_train(
                batch, phase, event_center=event_center, event_time=event_time,
                epoch=step, figure_dir=args.figure_dir, prefix=prefix,
            )
        # Seismic models with polarity
        elif args.model in ("phasenet_plus", "phasenet_tf_plus"):
            polarity = torch.sigmoid(output["polarity"]).cpu().float() if "polarity" in output else None
            event_center = torch.sigmoid(output["event_center"]).cpu().float() if "event_center" in output else None
            event_time = output["event_time"].cpu().float() if "event_time" in output else None
            nx = batch["data"].shape[2]
            if nx > 1:
                phasenet_utils.plot_multi_station_phasenet_plus_train(
                    batch, phase, polarity=polarity, event_center=event_center,
                    event_time=event_time, epoch=step, figure_dir=args.figure_dir, prefix=prefix,
                )
            else:
                phasenet_utils.plot_phasenet_plus_train(
                    batch, phase, polarity=polarity, event_center=event_center,
                    event_time=event_time, epoch=step, figure_dir=args.figure_dir, prefix=prefix,
                )
        # Seismic models with spectrogram
        elif args.model in ("phasenet_tf",):
            batch["spectrogram"] = output["spectrogram"].cpu().float() if "spectrogram" in output else None
            phasenet_utils.plot_phasenet_tf_train(
                batch, phase, event_center=None, event_time=None,
                epoch=step, figure_dir=args.figure_dir, prefix=prefix,
            )
        # Base phasenet
        else:
            phasenet_utils.plot_phasenet_train(
                batch, phase, epoch=step, figure_dir=args.figure_dir, prefix=prefix,
            )
        print("Plotting...")


# =============================================================================
# Dataset Factory
# =============================================================================

def get_dataset_type(args) -> str:
    """Determine dataset type based on args and model."""
    if args.dataset_type != "auto":
        return args.dataset_type
    # Auto-detect: DAS models use DAS dataset
    if args.model in DAS_MODELS:
        return "das"
    # Default to seismic_trace for other models
    return "seismic_trace"


def create_dataset(args, training: bool = True, rank: int = 0, world_size: int = 1):
    """Create dataset based on configuration."""
    dataset_type = get_dataset_type(args)

    # CEED dataset (seismic, 3-component)
    if dataset_type == "ceed":
        transforms = ceed_train_transforms(crop_length=4096, augment=not args.no_augment) if training else ceed_eval_transforms(crop_length=4096)
        group_by = "station" if args.nx == 1 else "event"
        target_nx = args.nx if group_by == "event" else None
        region = args.ceed_region
        split = "train" if training else "test"
        label_path = args.label_path if training else (args.test_label_path or args.label_path)
        label_list = args.label_list if training else args.test_label_list
        # Use streaming iterable dataset for both train and eval to avoid downloading entire dataset
        source = "quakeflow" if (label_path and label_path != "./") else ("quakeflow" if args.streaming else "ceed")
        if args.streaming or label_path or label_list:
            return CEEDIterableDataset(
                source=source,
                region=region,
                split=split,
                transforms=transforms,
                label_path=label_path if label_path != "./" else None,
                label_list=label_list,
                min_snr=args.min_snr,
                buffer_size=args.buffer_size,
                group_by=group_by,
                target_nx=target_nx,
                streaming=args.streaming,
                training=training,
            )
        else:
            return CEEDDataset(
                region=region,
                split=split,
                transforms=transforms,
                min_snr=args.min_snr,
                group_by=group_by,
                target_nx=target_nx,
            )

    # DAS dataset (single-channel strain rate)
    if dataset_type == "das":
        if training:
            transforms = das_train_transforms(
                nt=args.nt, nx=args.nx,
                augment=not args.no_augment,
            )
        else:
            transforms = das_eval_transforms()

        return DASIterableDataset(
            data_path=args.data_path if training else (args.test_data_path or args.data_path),
            data_list=args.data_list if training else args.test_data_list,
            label_path=args.label_path if training else (args.test_label_path or args.label_path),
            label_list=args.label_list if training else args.test_label_list,
            noise_list=args.noise_list if training else args.test_noise_list,
            phases=args.phases,
            nt=args.nt,
            nx=args.nx,
            min_nt=min(args.nt, 256),
            min_nx=min(args.nx, 256),
            format=args.format,
            training=training,
            transforms=transforms,
            overfit=args.overfit if training else None,
            num_patch=args.num_patch if training else 1,
            subdir=args.subdir,
            rank=rank,
            world_size=world_size,
        )

    raise ValueError(f"Unsupported dataset type: {dataset_type}")


# =============================================================================
# Main Training Loop
# =============================================================================

def main(args):
    # Setup output directory
    if args.output_dir:
        utils.mkdir(args.output_dir)
        args.figure_dir = os.path.join(args.output_dir, "figures")
        utils.mkdir(args.figure_dir)

    utils.init_distributed_mode(args)
    print(args)

    # Distributed setup
    rank = utils.get_rank() if args.distributed else 0
    world_size = utils.get_world_size() if args.distributed else 1

    # Set seeds for reproducibility
    seed = 1337 + rank
    torch.manual_seed(seed)
    random.seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)

    device = torch.device(args.device)

    # Mixed precision setup
    dtype = "bfloat16" if (torch.cuda.is_available() and torch.cuda.is_bf16_supported()) else "float16"
    ptdtype = {"float32": torch.float32, "bfloat16": torch.bfloat16, "float16": torch.float16}[dtype]
    scaler = torch.cuda.amp.GradScaler(enabled=(dtype == "float16" and torch.cuda.is_available()))
    args.dtype, args.ptdtype = dtype, ptdtype

    # CUDA optimizations
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    torch.backends.cudnn.benchmark = not args.use_deterministic_algorithms
    if args.use_deterministic_algorithms:
        torch.use_deterministic_algorithms(True)

    # Create datasets
    dataset = create_dataset(args, training=True, rank=rank, world_size=world_size)
    dataset_type = get_dataset_type(args)
    has_test_data = (
        args.test_hdf5_file
        or args.test_data_path
        or args.test_data_list
        or args.test_label_list
        or dataset_type == "ceed"
    )
    dataset_test = create_dataset(args, training=False, rank=rank, world_size=world_size) if has_test_data else None

    data_loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=args.batch_size,
        num_workers=args.workers,
        drop_last=True,
        pin_memory=True,
        persistent_workers=args.workers > 0,
        prefetch_factor=2 if args.workers > 0 else None,
    )
    data_loader_test = torch.utils.data.DataLoader(
        dataset_test,
        batch_size=args.batch_size,
        num_workers=args.workers,
        drop_last=False,
        pin_memory=True,
        persistent_workers=args.workers > 0,
        prefetch_factor=2 if args.workers > 0 else None,
    ) if dataset_test else None

    # Build model
    # Auto-compute RoPE dt_s: bottleneck time resolution = dt_data * time_stride^num_layers
    # Default UNet: time_stride=4, dim_mults=(1,2,4,8) → 4 layers → 256x downsampling
    # At 100Hz (dt=0.01s): 256 * 0.01 = 2.56s per bottleneck position
    rope_dt_s = args.rope_dt_s if args.rope_dt_s is not None else 0.01 * (4 ** 4)  # 2.56s
    model_kwargs = {
        "log_scale": args.log_scale,
        "moving_norm": (1024, 256) if args.moving_norm else None,
        "attend_at_middle": args.mid_attn,
        "rope_base_nx": args.rope_base,
        "rope_base_nt": args.rope_base_nt,
        "rope_res_nx": args.rope_res_nx,
        "rope_dx_km": args.rope_dx_km,
        "rope_dt_s": rope_dt_s,
        "event_center_loss_weight": args.event_center_loss_weight,
        "event_time_loss_weight": args.event_time_loss_weight,
        "polarity_loss_weight": args.polarity_loss_weight,
    }
    model_config = {"backbone": args.backbone, **model_kwargs}
    model = phasenet.models.__dict__[args.model].build_model(**model_config)
    logger.info(f"Model:\n{model}")
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
    model.to(device)

    if args.compile:
        print("Compiling model...")
        model = torch.compile(model)

    if args.distributed and args.sync_bn:
        model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(model)

    # Wandb logging
    if args.wandb and utils.is_main_process():
        wandb.init(
            project=args.wandb_project or args.model,
            name=args.wandb_name,
            entity=args.wandb_group,
            dir=args.wandb_dir,
            config=vars(args),
        )

    # Optimizer and scheduler
    parameters = utils.set_weight_decay(
        model, args.weight_decay,
        norm_weight_decay=args.norm_weight_decay,
    )
    optimizer = torch.optim.AdamW(parameters, lr=1.0, weight_decay=args.weight_decay)

    warmup_steps = min(args.lr_warmup_iters, max(1, args.max_iters // 10))
    max_steps = args.max_iters
    lr_scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer,
        lr_lambda=lambda it: get_lr(it, args.lr, args.lr * args.lr_min_ratio, warmup_steps, max_steps)
    )

    # Distributed wrapper
    model_without_ddp = model
    if args.distributed:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.gpu])
        model_without_ddp = model.module

    # EMA
    model_ema = None
    if args.model_ema:
        model_ema = utils.ExponentialMovingAverage(model_without_ddp, device=device, decay=args.model_ema_decay)

    # Resume from checkpoint
    if args.resume:
        checkpoint_path = args.checkpoint or os.path.join(args.output_dir, "checkpoint.pth")
        if os.path.isfile(checkpoint_path):
            print(f"Loading checkpoint from {checkpoint_path}")
            checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
            model_without_ddp.load_state_dict(checkpoint["model"])
            if args.reset_lr:
                print(f"Resetting LR schedule (warmup={warmup_steps}, max_steps={max_steps})")
            else:
                optimizer.load_state_dict(checkpoint["optimizer"])
                lr_scheduler.load_state_dict(checkpoint["lr_scheduler"])
                args.start_iter = checkpoint.get("global_step", 0)
            if model_ema and "model_ema" in checkpoint:
                model_ema.load_state_dict(checkpoint["model_ema"])
            if scaler and "scaler" in checkpoint:
                scaler.load_state_dict(checkpoint["scaler"])

    # Cache fixed test batches for deterministic evaluation
    max_eval_iters = args.max_eval_iters or max(1, args.eval_interval // 20)
    test_batches = None
    if data_loader_test is not None:
        test_batches = cache_test_batches(data_loader_test, max_eval_iters)

    # =========================================================================
    # Iteration-based training loop
    # =========================================================================
    start_time = time.time()
    best_loss = float("inf")
    global_step = args.start_iter
    features = get_model_features(args.model)

    # Metric logger
    metric_logger = utils.MetricLogger(delimiter="  ")
    metric_logger.add_meter("lr", utils.SmoothedValue(window_size=1, fmt="{value:.2e}"))
    for feat in features:
        if feat == "phase":
            metric_logger.add_meter("loss_phase", utils.SmoothedValue(window_size=1, fmt="{value:.4f}"))
        elif feat == "event":
            metric_logger.add_meter("loss_event_center", utils.SmoothedValue(window_size=1, fmt="{value:.4f}"))
            metric_logger.add_meter("loss_event_time", utils.SmoothedValue(window_size=1, fmt="{value:.4f}"))
        elif feat == "polarity":
            metric_logger.add_meter("loss_polarity", utils.SmoothedValue(window_size=1, fmt="{value:.4f}"))
        elif feat == "prompt":
            metric_logger.add_meter("loss_prompt", utils.SmoothedValue(window_size=1, fmt="{value:.4f}"))

    model.train()
    data_iter = iter(data_loader)
    last_batch, last_output = None, None

    # CUDA event timing for profiling data vs model time
    use_cuda_timing = torch.cuda.is_available() and args.device == "cuda"
    if use_cuda_timing:
        t_data_start = torch.cuda.Event(enable_timing=True)
        t_data_end = torch.cuda.Event(enable_timing=True)
        t_model_start = torch.cuda.Event(enable_timing=True)
        t_model_end = torch.cuda.Event(enable_timing=True)

    accum_steps = args.gradient_accumulation_steps
    print(f"Training: {global_step}/{args.max_iters} iters, eval every {args.eval_interval}, "
          f"eval iters: {max_eval_iters}, warmup: {warmup_steps}"
          + (f", grad accum: {accum_steps}" if accum_steps > 1 else ""))

    optimizer.zero_grad()
    while global_step < args.max_iters:
        # Gradient accumulation: accumulate over accum_steps micro-batches
        if use_cuda_timing:
            t_data_start.record()
        for micro_step in range(accum_steps):
            try:
                batch = next(data_iter)
            except StopIteration:
                data_iter = iter(data_loader)
                batch = next(data_iter)
            if use_cuda_timing and micro_step == accum_steps - 1:
                t_data_end.record()

            if use_cuda_timing and micro_step == accum_steps - 1:
                t_model_start.record()
            output = train_step(model, batch, optimizer, lr_scheduler, scaler, model_ema,
                                args, global_step, micro_step)
            if use_cuda_timing and micro_step == accum_steps - 1:
                t_model_end.record()
        last_batch, last_output = batch, output
        global_step += 1

        # Update metrics only at print_freq to avoid GPU-CPU sync overhead
        loss = output["loss"]
        if global_step % args.print_freq == 0:
            metric_logger.update(loss=loss.item(), lr=optimizer.param_groups[0]["lr"])
            for feat in features:
                if feat == "phase" and "loss_phase" in output:
                    metric_logger.update(loss_phase=output["loss_phase"].item())
                elif feat == "event":
                    if "loss_event_center" in output:
                        metric_logger.update(loss_event_center=output["loss_event_center"].item())
                    if "loss_event_time" in output:
                        metric_logger.update(loss_event_time=output["loss_event_time"].item())
                elif feat == "polarity" and "loss_polarity" in output:
                    metric_logger.update(loss_polarity=output["loss_polarity"].item())
                elif feat == "prompt" and "loss_prompt" in output:
                    metric_logger.update(loss_prompt=output["loss_prompt"].item())

        # Logging
        if global_step % args.print_freq == 0:
            eta = str(datetime.timedelta(
                seconds=int((time.time() - start_time) / max(1, global_step - args.start_iter)
                            * (args.max_iters - global_step))
            ))
            timing_str = ""
            if use_cuda_timing:
                torch.cuda.synchronize()
                d_ms = t_data_start.elapsed_time(t_data_end)
                m_ms = t_model_start.elapsed_time(t_model_end)
                timing_str = f"  data: {d_ms:.0f}ms  model: {m_ms:.0f}ms"
            print(f"[{global_step}/{args.max_iters}]  "
                  f"{metric_logger}  "
                  f"eta: {eta}{timing_str}")

        if args.wandb and utils.is_main_process() and global_step % args.print_freq == 0:
            log = {
                "train/loss": loss.item(),
                "train/lr": optimizer.param_groups[0]["lr"],
            }
            for key in ["loss_phase", "loss_event_center", "loss_event_time", "loss_polarity", "loss_prompt"]:
                if key in output:
                    log[f"train/{key}"] = output[key].item()
            wandb.log(log, step=global_step)

        # Plot at plot_interval
        if global_step % args.plot_interval == 0:
            plot_results(last_batch, last_output, args, global_step, "train")
            if args.wandb and utils.is_main_process():
                import glob as _glob
                fig_dir = args.figure_dir
                for fig_path in sorted(_glob.glob(os.path.join(fig_dir, f"{global_step}_*.png"))):
                    fig_name = os.path.basename(fig_path).replace(f"{global_step}_", "")
                    wandb.log({f"figures/{fig_name}": wandb.Image(fig_path)}, step=global_step)

        # Eval at eval_interval
        if global_step % args.eval_interval == 0:
            metric = None
            if test_batches is not None:
                metric = evaluate(model, test_batches, args, global_step)
                if model_ema:
                    evaluate(model_ema, test_batches, args, global_step)

            # Save checkpoint at save_interval (defaults to eval_interval)
            save_interval = min(args.save_interval, max(1, args.max_iters // 10))
            if global_step % save_interval == 0:
                checkpoint = {
                    "model": model_without_ddp.state_dict(),
                    "model_config": model_config,
                    "optimizer": optimizer.state_dict(),
                    "lr_scheduler": lr_scheduler.state_dict(),
                    "global_step": global_step,
                    "args": args,
                }
                if model_ema:
                    checkpoint["model_ema"] = model_ema.state_dict()
                    # Save standalone EMA weights for easy inference loading
                    ema_state = {k.removeprefix("module."): v for k, v in model_ema.module.state_dict().items()}
                    checkpoint["model_ema_weights"] = ema_state
                if scaler:
                    checkpoint["scaler"] = scaler.state_dict()

                utils.save_on_master(checkpoint, os.path.join(args.output_dir, f"model_{global_step}.pth"))
                utils.save_on_master(checkpoint, os.path.join(args.output_dir, "checkpoint.pth"))

                # Save best model (only when test data is available)
                if utils.is_main_process() and metric is not None:
                    current_loss = metric.loss.global_avg
                    if current_loss < best_loss:
                        best_loss = current_loss
                        torch.save(checkpoint, os.path.join(args.output_dir, "model_best.pth"))

                        if args.wandb:
                            artifact = wandb.Artifact(
                                args.wandb_name or "model", type="model",
                                metadata={"step": global_step, "loss": best_loss},
                            )
                            artifact.add_file(os.path.join(args.output_dir, "model_best.pth"))
                            wandb.log_artifact(artifact)

            # Back to training mode
            model.train()

    total_time = str(datetime.timedelta(seconds=int(time.time() - start_time)))
    print(f"Training completed in {total_time}")

    if args.wandb and utils.is_main_process():
        wandb.finish()


# =============================================================================
# Argument Parser
# =============================================================================

def get_args_parser(add_help=True):
    import argparse
    parser = argparse.ArgumentParser(description="PhaseNet Training", add_help=add_help)

    # Data
    parser.add_argument("--data-path", default="./", type=str)
    parser.add_argument("--data-list", nargs="+", default=None)
    parser.add_argument("--hdf5-file", default=None, type=str)
    parser.add_argument("--hf-dataset", default=None, type=str)
    parser.add_argument("--format", default="h5", type=str, choices=["h5", "hf"])
    parser.add_argument("--test-data-path", default=None, type=str)
    parser.add_argument("--test-data-list", nargs="+", default=None)
    parser.add_argument("--test-hdf5-file", default=None, type=str)
    parser.add_argument("--picks-dict", default=None, type=str)
    parser.add_argument("--events-dict", default=None, type=str)

    # Dataset type (auto-detected for DAS models)
    parser.add_argument("--dataset-type", default="auto", choices=["auto", "seismic_trace", "ceed", "das"])

    # CEED dataset
    parser.add_argument("--ceed-region", default="NC,SC", type=str)
    parser.add_argument("--min-snr", type=float, default=0.0)
    parser.add_argument("--streaming", action="store_true")
    parser.add_argument("--buffer-size", type=int, default=1000, help="Buffer size for sample stacking")

    # DAS dataset
    parser.add_argument("--label-path", default="./", type=str)
    parser.add_argument("--label-list", nargs="+", default=None)
    parser.add_argument("--noise-list", nargs="+", default=None)
    parser.add_argument("--test-label-path", default=None, type=str)
    parser.add_argument("--test-label-list", nargs="+", default=None)
    parser.add_argument("--test-noise-list", nargs="+", default=None)
    parser.add_argument("--phases", nargs="+", default=["P", "S"], type=str)
    parser.add_argument("--nt", default=4096, type=int, help="DAS time samples")
    parser.add_argument("--nx", default=2048, type=int, help="DAS space samples")
    parser.add_argument("--num-patch", default=8, type=int,
                        help="Number of random crops per DAS sample (amortize IO cost)")
    parser.add_argument("--subdir", default=3, type=int,
                        help="Subdirectory depth for DAS label→data path mapping")
    parser.add_argument("--random-crop", action="store_true")

    # Model
    parser.add_argument("--model", default="phasenet", type=str)
    parser.add_argument("--backbone", default="unet", type=str)
    parser.add_argument("--mid-attn", action="store_true", help="Enable transformer attention at UNet bottleneck")
    parser.add_argument("--rope-base", type=float, default=None, help="RoPE base frequency for station dim (km), enables RoPE when set")
    parser.add_argument("--rope-base-nt", type=float, default=205.0, help="RoPE base frequency for time dim (s)")
    parser.add_argument("--rope-dx-km", type=float, default=5.0, help="Station spacing at bottleneck (km)")
    parser.add_argument("--rope-res-nx", type=float, default=5.0, help="Spatial resolution for highest RoPE frequency (km)")
    parser.add_argument("--rope-dt-s", type=float, default=None, help="Time spacing at bottleneck (s), auto-computed if not set")

    # Training
    parser.add_argument("--device", default="cuda", type=str)
    parser.add_argument("--compile", action="store_true")
    parser.add_argument("-b", "--batch-size", default=8, type=int)
    parser.add_argument("--max-iters", default=50000, type=int, help="Total training iterations")
    parser.add_argument("--eval-interval", default=1000, type=int, help="Evaluate every N iters")
    parser.add_argument("--plot-interval", default=100, type=int, help="Plot training figures every N iters")
    parser.add_argument("--save-interval", default=2000, type=int, help="Checkpoint every N iters (capped at 10%% of max-iters)")
    parser.add_argument("--max-eval-iters", default=None, type=int, help="Max eval iterations (default: 5%% of eval-interval)")
    parser.add_argument("-j", "--workers", default=4, type=int)
    parser.add_argument("--gradient-accumulation-steps", default=1, type=int,
                        help="Accumulate gradients over N micro-batches")

    # Optimizer
    parser.add_argument("--lr", default=1e-4, type=float)
    parser.add_argument("--weight-decay", default=0.01, type=float)
    parser.add_argument("--norm-weight-decay", default=None, type=float)
    parser.add_argument("--clip-grad-norm", default=1.0, type=float)
    parser.add_argument("--lr-warmup-iters", default=1000, type=int, help="LR warmup iterations")
    parser.add_argument("--lr-min-ratio", default=0.01, type=float)

    # Checkpointing
    parser.add_argument("--output-dir", default="./output", type=str)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--checkpoint", default=None, type=str)
    parser.add_argument("--reset-lr", action="store_true", help="Reset optimizer and LR schedule on resume (keep model weights)")
    parser.add_argument("--start-iter", default=0, type=int)

    # EMA
    parser.add_argument("--model-ema", action="store_true", default=True)
    parser.add_argument("--no-model-ema", dest="model_ema", action="store_false")
    parser.add_argument("--model-ema-steps", type=int, default=1)
    parser.add_argument("--model-ema-decay", type=float, default=0.999)

    # Distributed
    parser.add_argument("--world-size", default=1, type=int)
    parser.add_argument("--dist-url", default="env://", type=str)
    parser.add_argument("--sync-bn", action="store_true")
    parser.add_argument("--use-deterministic-algorithms", action="store_true")

    # Augmentation
    parser.add_argument("--no-augment", action="store_true", help="Disable all augmentations")
    parser.add_argument("--overfit", default=None, choices=["fixed", "random"], help="Overfit mode")
    parser.add_argument("--log-scale", action="store_true", help="Enable log transform in model")
    parser.add_argument("--moving-norm", action="store_true", help="Enable moving normalization in model")

    # Loss weights
    parser.add_argument("--event-center-loss-weight", default=1.0, type=float)
    parser.add_argument("--event-time-loss-weight", default=1.0, type=float)
    parser.add_argument("--polarity-loss-weight", default=1.0, type=float)

    # Logging
    parser.add_argument("--print-freq", default=10, type=int)
    parser.add_argument("--wandb", action="store_true")
    parser.add_argument("--wandb-project", default=None, type=str)
    parser.add_argument("--wandb-name", default=None, type=str)
    parser.add_argument("--wandb-group", default=None, type=str)
    parser.add_argument("--wandb-dir", default="./", type=str)

    return parser


if __name__ == "__main__":
    args = get_args_parser().parse_args()
    main(args)
