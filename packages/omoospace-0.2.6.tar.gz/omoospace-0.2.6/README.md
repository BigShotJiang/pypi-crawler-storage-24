# Omoospace

[中文文档](https://docs.omoolab.xyz/omoospace/0.2.x/)

![overview](https://docs.omoolab.xyz/omoospace/latest/assets/overview.png)

Omoospace is a universal folder structure guideline for creative projects. Its goals are **universality, flexibility, and semantic clarity**. It works for complex projects and team collaboration, as well as simple projects and individual work. [Why Omoospace?](https://docs.omoolab.xyz/omoospace/0.2.x/en/why/)


## Getting Started

### New Project

1. Create a new folder as the project root.
2. Create `Omoospace.yml` in the root.
3. Create `Contents/` in the root and put your resource files in it.
4. (Optional) Create `Subspaces/` in the root and put your source files in it.
5. (Optional) Add other folders as needed and place the corresponding file types in them.


### Existing Project

1. Create `Omoospace.yml` in the project root.
2. Edit `Omoospace.yml` and add:
    ```YAML
    contents_dir: <resource_folder_name>
    ```
    Example:
    ```YAML
    contents_dir: Assets
    ```

3. (Optional) Edit `Omoospace.yml` and add:
    ```YAML
    subspaces_dir: <source_folder_name>
    ```
    Example:
    ```YAML
    subspaces_dir: ProjectFiles
    ```


## Command Line Tool

### Install uv and tool

[https://docs.astral.sh/uv/getting-started/installation/](https://docs.astral.sh/uv/getting-started/installation/)

```bash
uv tool install omoospace[cli]
```

### New Project

```bash
omoos create <Name>
```

### Existing Project

```bash
cd <project folder>
omoos init
```