"""Mighty Spatial -- IFC-to-GIS conversion Python SDK.

Convert IFC (Industry Foundation Classes) files to GeoJSON, GeoPackage,
Shapefile, and File Geodatabase with a single function call.

Quickstart::

    from mightyspatial import convert

    result = convert("building.ifc", output_format="geojson")

Or use the full client::

    from mightyspatial import MightySpatial

    ms = MightySpatial(api_key="ms_...")
    result = ms.convert("building.ifc")

Full documentation: https://mightyspatial.com/docs
Free web converter: https://mightyspatial.com/convert
"""

from ._version import __version__
from .client import MightySpatial
from .exceptions import (
    AuthenticationError,
    ConversionError,
    FileTooLargeError,
    MightySpatialError,
    RateLimitError,
)

__all__ = [
    "__version__",
    "MightySpatial",
    "convert",
    "MightySpatialError",
    "RateLimitError",
    "FileTooLargeError",
    "ConversionError",
    "AuthenticationError",
]


def convert(
    file_path: str,
    *,
    file_url: str | None = None,
    output_format: str = "geojson",
    output_path: str | None = None,
    api_key: str | None = None,
    source_crs: str | None = None,
    strip_prefix: str | None = None,
    strip_suffix: str | None = None,
    include_csv: bool = False,
) -> str:
    """One-step IFC to GIS conversion (convenience function).

    This creates a temporary :class:`MightySpatial` client, converts the
    file, and returns the path to the output.

    Parameters
    ----------
    file_path:
        Path to a local ``.ifc`` file.
    file_url:
        URL of a remote ``.ifc`` file (use instead of *file_path*).
    output_format:
        ``"geojson"`` (default), ``"geopackage"``, ``"shapefile"``, or
        ``"filegdb"``.
    output_path:
        Where to save the result. Defaults to the input filename with
        the appropriate extension.
    api_key:
        API key. Falls back to ``MIGHTY_SPATIAL_API_KEY`` env var.
    source_crs:
        Override source CRS (e.g. ``"EPSG:28356"``).
    strip_prefix:
        Remove this prefix from property names.
    strip_suffix:
        Remove this suffix from property names.
    include_csv:
        Bundle a CSV attribute export alongside the GIS data.

    Returns
    -------
    str
        Absolute path to the saved output file.

    Examples
    --------
    >>> from mightyspatial import convert
    >>> convert("building.ifc")
    '/path/to/building.geojson'

    >>> convert("building.ifc", output_format="geopackage")
    '/path/to/building.gpkg'
    """
    client = MightySpatial(api_key=api_key)
    return client.convert(
        file_path=file_path,
        file_url=file_url,
        output_format=output_format,
        output_path=output_path,
        source_crs=source_crs,
        strip_prefix=strip_prefix,
        strip_suffix=strip_suffix,
        include_csv=include_csv,
    )
