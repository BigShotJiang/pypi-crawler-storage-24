"""Custom exceptions for the Mighty Spatial SDK."""

__all__ = [
    "MightySpatialError",
    "RateLimitError",
    "FileTooLargeError",
    "ConversionError",
    "AuthenticationError",
]


class MightySpatialError(Exception):
    """Base exception for all Mighty Spatial API errors."""

    help_url: str = "https://mightyspatial.com/docs"

    def __init__(self, message: str, help_url: str | None = None) -> None:
        super().__init__(message)
        if help_url is not None:
            self.help_url = help_url


class RateLimitError(MightySpatialError):
    """Raised when the API rate limit is exceeded (HTTP 429)."""

    help_url: str = "https://mightyspatial.com/dashboard"

    def __init__(
        self,
        message: str | None = None,
        help_url: str | None = None,
    ) -> None:
        if message is None:
            message = (
                "Rate limit exceeded. Upgrade to Pro ($0.50/conversion) "
                "for 100 conversions/month: https://mightyspatial.com/dashboard"
            )
        super().__init__(message, help_url=help_url or self.help_url)


class FileTooLargeError(MightySpatialError):
    """Raised when the uploaded file exceeds the tier size limit (HTTP 413)."""

    help_url: str = "https://mightyspatial.com/dashboard"

    def __init__(
        self,
        message: str | None = None,
        help_url: str | None = None,
    ) -> None:
        if message is None:
            message = (
                "File too large for your current tier. "
                "Tier limits: Free (50 MB), Pro (500 MB), Enterprise (custom). "
                "Upgrade at https://mightyspatial.com/dashboard"
            )
        super().__init__(message, help_url=help_url or self.help_url)


class ConversionError(MightySpatialError):
    """Raised when the IFC conversion fails server-side."""

    help_url: str = "https://mightyspatial.com/docs"


class AuthenticationError(MightySpatialError):
    """Raised when the API key is invalid or missing for a protected resource."""

    help_url: str = "https://mightyspatial.com/dashboard"

    def __init__(
        self,
        message: str | None = None,
        help_url: str | None = None,
    ) -> None:
        if message is None:
            message = (
                "Authentication failed. Check your API key or get one at "
                "https://mightyspatial.com/dashboard"
            )
        super().__init__(message, help_url=help_url or self.help_url)
