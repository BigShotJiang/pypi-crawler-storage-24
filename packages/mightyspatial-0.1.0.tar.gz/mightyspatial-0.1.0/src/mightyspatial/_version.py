"""Single-source version for the mightyspatial package."""

__version__ = "0.1.0"
