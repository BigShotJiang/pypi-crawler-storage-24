# mightyspatial

[![PyPI version](https://img.shields.io/pypi/v/mightyspatial.svg)](https://pypi.org/project/mightyspatial/)
[![Python versions](https://img.shields.io/pypi/pyversions/mightyspatial.svg)](https://pypi.org/project/mightyspatial/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

Python SDK for the [Mighty Spatial](https://mightyspatial.com) IFC-to-GIS conversion API. Convert IFC (BIM) files to GeoJSON, GeoPackage, Shapefile, and File Geodatabase.

**[Documentation](https://mightyspatial.com/docs)** | **[Free Web Converter](https://mightyspatial.com/convert)** | **[Get API Key](https://mightyspatial.com/dashboard)**

## Installation

```bash
pip install mightyspatial
```

## Quick Start

### One-step conversion

```python
from mightyspatial import convert

# Convert with no API key (free tier: 5/month, up to 50MB)
result = convert("building.ifc")
print(result)  # /path/to/building.geojson

# Specify output format
convert("building.ifc", output_format="geopackage")
```

### Using the client

```python
from mightyspatial import MightySpatial

ms = MightySpatial(api_key="ms_...")

# One-step convert
ms.convert("building.ifc", output_format="geojson")

# Convert from a URL
ms.convert(file_url="https://example.com/model.ifc", output_path="output.geojson")

# Strip property name prefixes/suffixes
ms.convert("building.ifc", strip_prefix="Pset_", strip_suffix="_Value")

# Include CSV attribute tables
ms.convert("building.ifc", include_csv=True)
```

### Preview and download (two-step)

```python
ms = MightySpatial(api_key="ms_...")

# Step 1: Preview -- inspect layers and metadata before downloading
preview = ms.preview("building.ifc")
print(preview["detected_crs"])
print(preview["layers"])

# Step 2: Download in your preferred format
job_id = preview["job_id"]
ms.download(job_id, output_format="geopackage", output_path="building.gpkg")
```

### Pipe generation

```python
ms = MightySpatial(api_key="ms_...")

preview = ms.preview("pipes.ifc")
job_id = preview["job_id"]

# Find the polyline layer
polyline_layer = next(l for l in preview["layers"] if "Line" in l["geometry_type"])

# Generate 3D pipe geometry
pipes = ms.generate_pipes(
    job_id=job_id,
    source_layer=polyline_layer["name"],
    features=polyline_layer["geojson"]["features"],
    default_diameter=300,
    uom="mm",
    segments=8,
)
print(pipes["layer"]["feature_count"])
```

### API key from environment variable

```bash
export MIGHTY_SPATIAL_API_KEY="ms_..."
```

```python
from mightyspatial import convert

# Automatically uses MIGHTY_SPATIAL_API_KEY
convert("building.ifc")
```

## Supported Output Formats

| Format       | Extension    | Free Tier | Pro Tier |
| ------------ | ------------ | --------- | -------- |
| GeoJSON      | `.geojson`   | Yes       | Yes      |
| GeoPackage   | `.gpkg`      | --        | Yes      |
| Shapefile    | `.shp.zip`   | --        | Yes      |
| File GDB     | `.gdb.zip`   | --        | Yes      |

## Pricing

| Tier         | Price                | Conversions  | Max File Size |
| ------------ | -------------------- | ------------ | ------------- |
| **Free**     | $0                   | 5/month      | 50 MB         |
| **Pro**      | $0.50/conversion     | 100/month    | 500 MB        |
| **Enterprise** | Custom             | Unlimited    | Custom        |

Get your API key at [mightyspatial.com/dashboard](https://mightyspatial.com/dashboard).

## Error Handling

```python
from mightyspatial import MightySpatial, RateLimitError, FileTooLargeError

ms = MightySpatial()

try:
    ms.convert("large_building.ifc")
except RateLimitError as e:
    print(e)           # Includes upgrade URL
    print(e.help_url)  # https://mightyspatial.com/dashboard
except FileTooLargeError as e:
    print(e)           # Includes tier limits
```

## Links

- [Full Documentation](https://mightyspatial.com/docs)
- [Free Web Converter](https://mightyspatial.com/convert)
- [API Key / Dashboard](https://mightyspatial.com/dashboard)
- [GitHub Repository](https://github.com/mightyspatial/mightyspatial-python)

## License

MIT -- see [LICENSE](LICENSE) for details.
