import asyncio
from typing import Any, Coroutine, Literal

import aiohttp
from openreward.api._session.http import (
    _finalize_session,
    request_retryable,
    resumable_sse,
)
from openreward.api._session.ping import ErrorResponse, get_ping_manager


class SessionTerminatedError(RuntimeError):
    def __init__(self, reason: str, *, sid: str | None):
        super().__init__(f"Session terminated (sid={sid!r}): {reason}")
        self.reason = reason
        self.sid = sid


class BaseAsyncSession:

    def __init__(
        self,
        base_url: str,
        api_key: str | None,
        creation_endpoint: str,
        creation_payload: dict[str, Any],
        creation_timeout: int = 60 * 30,
        ping_start_method: Literal["fork"] | None = None,
        deployment: str | None = None,
        client: aiohttp.ClientSession | None = None,
        default_headers: dict[str, str] | None = None,
        creation_headers: dict[str, str] | None = None,
    ) -> None:
        self.base_url = base_url
        self.api_key = api_key
        self._creation_endpoint = creation_endpoint
        self._creation_payload = creation_payload
        self.creation_timeout = creation_timeout
        self.deployment = deployment
        self._default_headers = default_headers
        self._creation_headers = creation_headers

        # External client: we don't own it, don't close it
        self._external_client = client
        # Our own client + connector, created in __aenter__ if no external client
        self._own_connector: aiohttp.TCPConnector | None = None
        self._own_client: aiohttp.ClientSession | None = None

        self.sid: str | None = None
        self._pending_task_id: str | None = None

        self._ping_manager = get_ping_manager(start_method=ping_start_method)
        self._ping_id = id(self)
        self._dead = asyncio.Event()
        self._dead_exception: SessionTerminatedError | None = None

    @property
    def client(self) -> aiohttp.ClientSession:
        c = self._external_client or self._own_client
        if c is None:
            raise RuntimeError("Session not started. Use as async context manager.")
        return c

    def _mark_dead(self, exc: ErrorResponse):
        if self._dead_exception is None:
            self._dead_exception = SessionTerminatedError(exc.message, sid=self.sid)
            self._dead.set()

    def _ensure_alive(self):
        if self._dead_exception is not None:
            raise self._dead_exception

    async def _run_or_die(self, coro: Coroutine[Any, Any, Any]) -> Any:
        """Run a coroutine until completion or until the session dies."""
        if self._dead_exception is not None:
            raise self._dead_exception

        task = asyncio.create_task(coro)
        stopper = asyncio.create_task(self._dead.wait())
        try:
            done, pending = await asyncio.wait(
                {task, stopper},
                return_when=asyncio.FIRST_COMPLETED,
            )

            if self._dead.is_set() and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                if self._dead_exception:
                    raise self._dead_exception

            return await task

        finally:
            stopper.cancel()
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

    async def _post_create(self) -> None:
        """Subclass hook called after SID is obtained. No-op in base."""
        pass

    async def _pre_delete(self) -> None:
        """Subclass hook called before session deletion. No-op in base."""
        pass

    async def __aenter__(self) -> "BaseAsyncSession":
        # Create client if not provided externally
        if self._external_client is None:
            self._own_connector = aiohttp.TCPConnector(limit=1_000_000)
            self._own_client = aiohttp.ClientSession(
                base_url=self.base_url,
                connector=self._own_connector,
                headers=self._default_headers,
                trust_env=True,
            )

        def on_event(event: str, data: str) -> None:
            if event == "task_id":
                self._pending_task_id = data.strip()

        res = await resumable_sse(
            self.client,
            self._creation_endpoint,
            token=self.api_key,
            json=self._creation_payload,
            deployment=self.deployment,
            max_retries=3,
            timeout=self.creation_timeout,
            on_event=on_event,
            extra_headers=self._creation_headers,
        )

        # Extract SID from SSE response
        if res and isinstance(res, dict):
            self.sid = res.get("sid")
        if self.sid is None:
            self.sid = self._pending_task_id
        self._pending_task_id = None

        assert self.sid is not None, "No SID returned from creation endpoint"

        await self._post_create()

        # Start ping
        await self._ping_manager.start_ping(
            task_id=str(self._ping_id),
            url=f"{self.base_url}/ping",
            sid=self.sid,
            api_key=self.api_key,
            sleep_time=10,
            on_error=self._mark_dead,
            deployment=self.deployment,
        )

        return self

    async def __aexit__(self, *exc):
        # Stop ping
        try:
            await self._ping_manager.stop_ping(str(self._ping_id))
        except:
            pass

        # Subclass hook (e.g. environment teardown)
        try:
            await self._pre_delete()
        except Exception:
            pass

        # Fast cleanup: pending task from interrupted creation
        if self._pending_task_id is not None:
            try:
                await request_retryable(
                    self.client, "POST", "/delete_session",
                    expect_json=False, token=self.api_key,
                    sid=self._pending_task_id,
                )
            except Exception:
                pass
            self._pending_task_id = None

        # Main cleanup: delete session
        if self.sid is not None:
            try:
                await request_retryable(
                    self.client, "POST", "/delete_session",
                    expect_json=False, token=self.api_key,
                    sid=self.sid,
                )
            except:
                pass

        # Close client if we own it
        if self._own_client is not None and not self._own_client.closed:
            await self._own_client.close()

    def __del__(self):
        if getattr(self, "_own_client", None) is not None:
            _finalize_session(self._own_client)
