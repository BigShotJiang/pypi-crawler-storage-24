from setuptools import setup

setup(
    name="aemuctrl",
    version="0.1.1",
    py_modules=["aemuctrl"],
    install_requires=[
        "opencv-python",
        "pyautogui",
        "numpy"
    ],
    description="ADB-based emulator control library",
    author="Solin",
    url="https://github.com/Solee-in/aemuctrl",
)