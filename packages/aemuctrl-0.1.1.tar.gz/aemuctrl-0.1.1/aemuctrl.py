import subprocess
import time
import os
import re
import cv2
import pyautogui 
from typing import List, Optional



# ================== CONFIGURATION ==================
ADB_PATH = "adb"  # Ensure this is in your System PATH
FAILSAFE = False
__version__ = "0.1.1"

COMMON_PORTS = [
    5554, 5555, 5556, 5557,   # Generic / BlueStacks
    62001, 62025,             # Nox
    21503, 21513,             # MeMu
    7555,                     # Genymotion / MuMu
]

# ================== CORE EXECUTION ==================

def _run(cmd: str, wait: float = 0) -> str:
    """Executes an ADB command and returns stdout."""
    try:
        result = subprocess.run(
            f'{ADB_PATH} {cmd}',
            shell=True,
            capture_output=True,
            text=True
        )
        if wait > 0:
            time.sleep(wait)
        if result.stderr:
            print(f"ADB ERROR: {result.stderr.strip()}")
        return result.stdout.strip()
    except Exception as e:
        return f"Error: {str(e)}"

# ================== CONNECTION ==================

def connect( ip="127.0.0.1", port=5555):
    """
    Connects to a specific ADB device.
    """
    return _run(f"connect {ip}:{port}")

def disconnect():
    """
    Disconnects all ADB devices.
    """
    return _run("disconnect")


def discover_services() -> List[str]:
    """
    Uses ADB mDNS to find active ADB services on the network/local machine.
    Returns a list of 'IP:PORT' strings.
    """
    output = _run("mdns services")
    # Regex to find patterns like 127.0.0.1:5555
    pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}:\d+\b'
    services = re.findall(pattern, output)
    return list(set(services))

def get_connected_devices() -> List[str]:
    """Returns a list of currently connected device IDs."""
    out = _run("devices")
    lines = out.splitlines()
    return [line.split("\t")[0] for line in lines if "\tdevice" in line]

def smart_connect() -> Optional[str]:
    """
    The 'Brain' of the connection:
    1. Checks for already active connections.
    2. Uses mDNS to discover services automatically.
    3. Falls back to scanning common emulator ports if discovery fails.
    """
    print("🔍 [SmartConnect] Checking existing connections...")
    active = get_connected_devices()
    if active:
        print(f"✅ Already connected to: {active[0]}")
        return active[0]

    print("📡 [SmartConnect] Discovering ADB services via mDNS...")
    services = discover_services()
    if services:
        for service in services:
            print(f"🔗 Found service! Attempting to connect: {service}")
            _run(f"connect {service}")
            time.sleep(0.5)
            if get_connected_devices():
                return service

    print("⚠️ [SmartConnect] No services found. Using fallback port scan...")
    for port in COMMON_PORTS:
        target = f"127.0.0.1:{port}"
        _run(f"connect {target}")
        if get_connected_devices():
            print(f"🎯 Connected to fallback: {target}")
            return target

    print("❌ [SmartConnect] Failed to find any device.")
    return None

def disconnect():
    """Disconnects all ADB devices."""
    return _run("disconnect")

# ================== INTERACTION ==================

def tap(x: int, y: int, wait: float = 0):
    """Taps the screen at (x, y)."""
    return _run(f"shell input tap {x} {y}", wait)

def swipe(x1, y1, x2, y2, duration=300, wait=0):
    """Swipes from point A to point B."""
    return _run(f"shell input swipe {x1} {y1} {x2} {y2} {duration}", wait)

def text(msg: str, wait: float = 0):
    """Inputs text safely (replaces spaces with %s)."""
    safe = msg.replace(" ", "%s")
    return _run(f'shell input text "{safe}"', wait)

def press_key(keycode: str, wait: float = 0):
    """Sends a specific key event."""
    return _run(f"shell input keyevent {keycode}", wait)

def home(wait=0): return press_key("KEYCODE_HOME", wait)
def back(wait=0): return press_key("KEYCODE_BACK", wait)
def recent(wait=0): return press_key("KEYCODE_APP_SWITCH", wait)

# ================== APPS ==================

def open_app(package: str, wait: float = 0):
    """Launches an app by package name."""
    return _run(f"shell monkey -p {package} -c android.intent.category.LAUNCHER 1", wait)

def close_app(package: str, wait: float = 0):
    """Force-stops an app."""
    return _run(f"shell am force-stop {package}", wait)

# ================== SCREENSHOT ==================

def screenshot(path: str = "screen.png", wait: float = 0) -> str:
    """Takes a screenshot using exec-out (fast)."""
    with open(path, "wb") as f:
        subprocess.run(f'{ADB_PATH} exec-out screencap -p', shell=True, stdout=f)
    if wait > 0: time.sleep(wait)
    return path

def screencap(x1, y1, x2, y2, path="crop.png", wait=0):
    img = cv2.imread(screenshot("bro_don't_delete_me.png"))
    img_cropped = img[y1:y2, x1:x2]
    cv2.imwrite(path, img_cropped)
    os.remove("bro_don't_delete_me.png")


# ================== VISUAL ==================

def locate_center_on_screen(template_path: str, confidence: float = 0.8):
    """Finds image on screen and taps its center if confidence is high enough."""
    img_path = screenshot("temp_view.png")
    time.sleep(0.1)
    img = cv2.imread(img_path)
    template = cv2.imread(template_path)

    if img is None or template is None:
        return False

    res = cv2.matchTemplate(img, template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(res)

    if max_val >= confidence:
        h, w, _ = template.shape
        cx = max_loc[0] + (w // 2)
        cy = max_loc[1] + (h // 2)
        tap(cx, cy)
    
    if os.path.exists(img_path): os.remove(img_path)
    time.sleep(0.2)


# ================== ZOOM (BOT FRIENDLY) ==================

def zoom_out(key="S", hold=0.7):
    """Standard zoom out."""
    pyautogui.keyDown(key)
    time.sleep(hold)
    pyautogui.keyUp(key)

def zoom_in(key="B", hold=0.7):
    """Standard zoom in."""
    pyautogui.keyDown(key)
    time.sleep(hold)
    pyautogui.keyUp(key)

def human_zoom_out(key="S"):
    """Human-like multi-tap zoom out."""
    for t in (0.4, 0.3):
        pyautogui.keyDown(key)
        time.sleep(t)
        pyautogui.keyUp(key)
        time.sleep(0.2)

def human_zoom_in(key="B"):
    """Human-like multi-tap zoom in."""
    for t in (0.4, 0.3):
        pyautogui.keyDown(key)
        time.sleep(t)
        pyautogui.keyUp(key)
        time.sleep(0.2)

# ================== SERVER CONTROL ==================

def kill_server(): return _run("kill-server")
def start_server(): return _run("start-server")
def adb_reconnect(): return _run("reconnect")
def adb_reconnect_device(): return _run("reconnect device")