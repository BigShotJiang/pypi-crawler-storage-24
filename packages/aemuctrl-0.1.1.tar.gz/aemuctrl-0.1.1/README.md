Here is the professionally translated and localized README.md file for your library, optimized for an international audience.
Markdown

# 🤖 Android Emulator Automation & Control Library

This library leverages the power of ADB (Android Debug Bridge), OpenCV, and PyAutoGUI to provide seamless and automated control over Android emulators (BlueStacks, Nox, MeMu, Genymotion, etc.).

By performing image detection on the screen, you can click buttons, simulate keyboard/mouse movements, and fully automate in-app or in-game operations in a "bot-friendly" manner.

---


⚙️ ADB (Android Debug Bridge) Requirement

This library uses ADB to communicate with devices. It is mandatory to have ADB installed on your system and added to your system PATH for the library to function.

If ADB is not yet installed on your system, you can follow these setup guides:

    🪟 Windows: Video guide for ADB installation on Windows

    🍎 macOS: Video guide for ADB installation on macOS

    🐧 Linux: Video guide for ADB installation on Linux

⚠️ Important: Zoom Configuration

The zoom functions in this library trigger the emulator's native Keymapping (Game Controls).

By default, the library uses "B" for Zoom In and "S" for Zoom Out. To ensure these work correctly:

    Open the Game Controls / Advanced Editor interface from your emulator's sidebar.

    Add two "Tap Spots" to the screen.

    Assign "B" to one and "S" to the other, then place them over the game's zoom in/out areas.
    (If you prefer different keys, you can customize them by using the key="X" parameter when calling the functions.)

📖 Function Reference

This library simplifies complex operations into single-line commands. Here is the full list of available features:
📡 Connection Management

    smart_connect(): The "brain" of the connection. It checks for existing connections, scans for ADB services via mDNS, or falls back to common emulator ports (5554, 62001, etc.) automatically.

    connect(ip, port): Manually connects to a device at a specific IP and Port.

    disconnect(): Disconnects all active ADB devices.

    get_connected_devices(): Returns a list of currently active and responsive devices.

📱 App Management

    open_app(package, wait): Launches an app by its package name.

    close_app(package, wait): Force-stops a specified app.

❓ How to Find the App Package Name

To use open_app, you need the package name. The easiest way is to open the app on the Google Play Store in your browser. The part following id= in the URL is the package name.

(As seen in the example, the package name for Instagram is com.instagram.android.)
📸 Visual Detection and Screenshots

    locate_center_on_screen(template_path, confidence): (Most Powerful Feature!) Uses OpenCV to find a specific image or button on the screen and automatically clicks its center. confidence defines the matching threshold (Default: 0.8 / 80%).

    screenshot(path, wait): Rapidly captures the current screen and saves it locally.

    screencap(x1, y1, x2, y2, path, wait): Captures and crops a specific region of the screen based on (X, Y) coordinates.

🕹️ Interaction and Input

    tap(x, y, wait): Taps specific (X, Y) coordinates on the screen.

    swipe(x1, y1, x2, y2, duration, wait): Swipes from the first point to the second.

    text(msg, wait): Safely inputs text into an active text field.

    press_key(keycode, wait): Sends Android system key events (e.g., Enter, Home).

    home(), back(), recent(): Simulates Android navigation buttons.

🔍 Bot-Friendly Zoom

    zoom_out(key="S", hold=0.7): Standard zoom out by holding a key.

    zoom_in(key="B", hold=0.7): Standard zoom in by holding a key.

    human_zoom_out(key="S"): Simulates human behavior by using multiple taps instead of a continuous hold to evade anti-bot systems.

    human_zoom_in(key="B"): Mimics human reflexes with iterative zooming.

⚙️ Server Control

    kill_server(): Completely shuts down the ADB server (useful for troubleshooting).

    start_server(): Manually starts the ADB server.

    adb_reconnect(): Refreshes connections without restarting the server.

🚀 Quick Start Example
Python

from your_library_name import smart_connect, open_app, locate_center_on_screen, text, human_zoom_in

# 1. Automatically connect to the active emulator
smart_connect()

# 2. Open Instagram and wait 2 seconds
open_app("com.instagram.android", wait=2)

# 3. Perform a human-like zoom-in
human_zoom_in()

# 4. Search for 'search_button.png' on the screen and click its center
if locate_center_on_screen("search_button.png", confidence=0.8):
    # 5. Type text into the search box
    text("Open Source Projects", wait=1)