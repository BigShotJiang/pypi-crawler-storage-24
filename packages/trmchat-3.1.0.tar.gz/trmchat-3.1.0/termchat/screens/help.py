from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Static


HELP_TEXT = """\
[bold $primary]TERMCHAT HELP[/]

[bold]COMMANDS[/]
  /code [lang] <code>     share code snippet
  /edit [text]            edit your last message
  /delete                 delete your last message
  /reply                  reply to last message
  /react <emoji>          react to last message
  /status available|away|dnd
  /profile [@user]        view profile
  /search <text>          search messages
  /rename <name>          rename group
  /add @user              add to group
  /kick @user             remove from group
  /block @user            block a user
  /unblock @user          unblock a user
  /file <path>            share a file (max 2MB)
  /download               list files in chat
  /download <name>        download file by name
  /notes                  open notes to self
  /logout                 log out
  /mute                   mute current chat
  /unmute                 unmute current chat
  /silent                 toggle all notification sounds
  /password               change password
  /info                   show chat info
  /online                 show online users
  /clear                  clear message view
  /help                   show this help

[bold]KEYBINDINGS[/]
  enter                   send message
  shift+enter             insert newline
  pageup                  load older messages
  ctrl+n                  new direct message
  ctrl+g                  new group chat
  ctrl+f                  search messages
  ctrl+d                  delete/leave chat
  ctrl+o                  open settings
  ctrl+l                  logout
  ctrl+q                  quit
  tab / shift+tab         cycle panels
  escape                  deselect chat / cancel edit

[bold]VIM NAVIGATION[/] (when not typing)
  j / k                   scroll messages down/up
  g / G                   scroll to top/bottom
  i                       focus input (insert mode)
  /                       start search

[bold]MESSAGE FORMATTING[/]
  **bold**                bold text
  *italic*                italic text
  `code`                  inline code
  ```lang                 code block
  code here
  ```

[dim]press escape to close[/]\
"""


class HelpScreen(ModalScreen[None]):

    def compose(self) -> ComposeResult:
        with VerticalScroll(id="help-modal"):
            yield Static(HELP_TEXT, id="help-text")

    def on_key(self, event) -> None:
        if event.key == "escape":
            event.stop()
            event.prevent_default()
            self.dismiss(None)
