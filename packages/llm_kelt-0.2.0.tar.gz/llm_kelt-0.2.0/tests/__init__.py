"""Kelt framework tests."""
