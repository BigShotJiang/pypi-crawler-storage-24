"""
mirror_mirror.core
------------------
Outlier detection for semi-normal distributions using the mirroring technique.
"""

import numpy as np
from scipy import stats
from typing import Union


def find_outliers(
    data: Union[list, "np.ndarray", "pd.Series"],
    method: str = "mode",
    threshold: float = 2.0,
) -> dict:
    """
    Detect outliers in a semi-normal distribution using the mirroring technique.

    The algorithm finds the peak of the distribution, mirrors the tail-side data
    across the peak to construct a synthetic normal distribution, then flags
    points that fall below mean - threshold * std as outliers.

    Parameters
    ----------
    data : list, numpy.ndarray, or pandas.Series
        1-D array of numeric values. NaNs are ignored.
    method : {"mode", "max"}, default "mode"
        How to locate the peak of the distribution.
        - "mode"  : uses kernel density estimation (KDE) to find the most
                    frequent value region (recommended for real-world data).
        - "max"   : uses the maximum value as the peak .
    threshold : float, default 2.0
        Number of standard deviations below the mirror mean to use as the
        outlier cutoff. Higher values are more conservative (fewer outliers).

    Returns
    -------
    dict with keys:
        - "outliers"    : numpy.ndarray of values identified as outliers
        - "cutoff"      : float, the threshold value below which points are outliers
        - "mirror_mean" : float, mean of the synthetic mirrored distribution
        - "mirror_std"  : float, std dev of the synthetic mirrored distribution

    Raises
    ------
    ValueError
        If data has fewer than 3 non-NaN values, method is unrecognised,
        or threshold is not a positive number.

    Examples
    --------
    >>> from mirror_mirror import find_outliers
    >>> data = [88, 91, 93, 95, 97, 99, 100, 72, 65, 55]
    >>> result = find_outliers(data, method="mode", threshold=2)
    >>> result["outliers"]
    array([55])
    """
    # ------------------------------------------------------------------ #
    # 1. Validate and clean input                                          #
    # ------------------------------------------------------------------ #
    arr = _to_numpy(data)

    if arr.size < 3:
        raise ValueError("data must contain at least 3 non-NaN values.")
    if method not in ("mode", "max"):
        raise ValueError(f"method must be 'mode' or 'max', got {method!r}.")
    if not (isinstance(threshold, (int, float)) and threshold > 0):
        raise ValueError("threshold must be a positive number.")

    # ------------------------------------------------------------------ #
    # 2. Find the peak                                                     #
    # ------------------------------------------------------------------ #
    if method == "max":
        peak = float(arr.max())
    else:  # "mode" — KDE peak
        peak = _kde_peak(arr)

    # ------------------------------------------------------------------ #
    # 3. Take data at or below the peak (the tail side)                   #
    # ------------------------------------------------------------------ #
    tail = arr[arr <= peak]

    if tail.size < 2:
        raise ValueError(
            "Too few data points at or below the detected peak. "
            "Try method='max' or check your data."
        )

    # ------------------------------------------------------------------ #
    # 4. Mirror the tail across the peak                                  #
    # ------------------------------------------------------------------ #
    mirrored = 2 * peak - tail          # reflect: new_x = peak + (peak - x)

    # ------------------------------------------------------------------ #
    # 5. Combine to form synthetic normal distribution                    #
    # ------------------------------------------------------------------ #
    synthetic = np.concatenate([tail, mirrored])

    # ------------------------------------------------------------------ #
    # 6. Compute mean and std of synthetic distribution                   #
    # ------------------------------------------------------------------ #
    mirror_mean = float(synthetic.mean())
    mirror_std = float(synthetic.std(ddof=1))

    # ------------------------------------------------------------------ #
    # 7. Compute cutoff                                                    #
    # ------------------------------------------------------------------ #
    cutoff = mirror_mean - threshold * mirror_std

    # ------------------------------------------------------------------ #
    # 8. Return outliers (original values below cutoff)                   #
    # ------------------------------------------------------------------ #
    outliers = arr[arr < cutoff]

    return {
        "outliers": outliers,
        "cutoff": cutoff,
        "mirror_mean": mirror_mean,
        "mirror_std": mirror_std,
    }


# ------------------------------------------------------------------ #
# Helpers                                                              #
# ------------------------------------------------------------------ #

def _to_numpy(data) -> np.ndarray:
    """Convert input to a clean 1-D float numpy array, dropping NaNs."""
    try:
        # Handles pandas Series, lists, numpy arrays
        arr = np.asarray(data, dtype=float).ravel()
    except (TypeError, ValueError) as exc:
        raise ValueError(f"data could not be converted to a numeric array: {exc}") from exc

    arr = arr[~np.isnan(arr)]
    return arr


def _kde_peak(arr: np.ndarray) -> float:
    """Return the x-value at the peak of the KDE for arr."""
    kde = stats.gaussian_kde(arr)
    # Evaluate on a fine grid spanning the data
    x_grid = np.linspace(arr.min(), arr.max(), 1000)
    densities = kde(x_grid)
    return float(x_grid[np.argmax(densities)])
