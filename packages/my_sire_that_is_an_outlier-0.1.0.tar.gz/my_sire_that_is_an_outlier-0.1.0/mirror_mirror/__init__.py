from .core import find_outliers

__all__ = ["find_outliers"]
__version__ = "0.1.0"
