"""Tests for mirror_mirror.find_outliers"""

import numpy as np
import pytest
from mirror_mirror import find_outliers


# ------------------------------------------------------------------ #
# Fixtures / helpers                                                   #
# ------------------------------------------------------------------ #

def make_semi_normal(peak=100, n=500, seed=42):
    """Create a left-skewed semi-normal: values from (peak - ~30) to peak."""
    rng = np.random.default_rng(seed)
    data = peak - np.abs(rng.normal(0, 10, n))
    return data


# ------------------------------------------------------------------ #
# Basic correctness                                                    #
# ------------------------------------------------------------------ #

class TestBasicCorrectness:
    def test_returns_dict_with_expected_keys(self):
        data = make_semi_normal()
        result = find_outliers(data)
        assert set(result.keys()) == {"outliers", "cutoff", "mirror_mean", "mirror_std"}

    def test_outliers_are_subset_of_input(self):
        data = make_semi_normal()
        result = find_outliers(data)
        for v in result["outliers"]:
            assert v in data

    def test_outliers_are_all_below_cutoff(self):
        data = make_semi_normal()
        result = find_outliers(data)
        assert np.all(result["outliers"] < result["cutoff"])

    def test_non_outliers_above_cutoff(self):
        data = make_semi_normal()
        result = find_outliers(data)
        non_outliers = data[data >= result["cutoff"]]
        assert len(non_outliers) > 0

    def test_detects_injected_outlier(self):
        rng = np.random.default_rng(0)
        data = 100 - np.abs(rng.normal(0, 5, 300))
        data_with_outlier = np.append(data, [30.0])   # far below the bulk
        result = find_outliers(data_with_outlier, method="mode", threshold=2)
        assert 30.0 in result["outliers"]

    def test_no_false_positives_on_clean_data(self):
        """Tight distribution — threshold=3 should find nothing."""
        rng = np.random.default_rng(1)
        data = 100 - np.abs(rng.normal(0, 3, 500))
        result = find_outliers(data, threshold=3)
        assert len(result["outliers"]) == 0


# ------------------------------------------------------------------ #
# Input types                                                          #
# ------------------------------------------------------------------ #

class TestInputTypes:
    def test_accepts_list(self):
        data = [95, 97, 92, 88, 91, 99, 100, 72, 65, 55]
        result = find_outliers(data)
        assert "outliers" in result

    def test_accepts_numpy_array(self):
        data = np.array([95, 97, 92, 88, 91, 99, 100, 72, 65, 55], dtype=float)
        result = find_outliers(data)
        assert "outliers" in result

    def test_accepts_pandas_series(self):
        pd = pytest.importorskip("pandas")
        data = pd.Series([95, 97, 92, 88, 91, 99, 100, 72, 65, 55])
        result = find_outliers(data)
        assert "outliers" in result

    def test_ignores_nans(self):
        data = [95, 97, np.nan, 88, 91, 99, 100, np.nan, 65, 55]
        result = find_outliers(data)   # should not raise
        assert "outliers" in result


# ------------------------------------------------------------------ #
# method parameter                                                     #
# ------------------------------------------------------------------ #

class TestMethod:
    def test_method_mode_runs(self):
        data = make_semi_normal()
        result = find_outliers(data, method="mode")
        assert isinstance(result["cutoff"], float)

    def test_method_max_runs(self):
        data = make_semi_normal()
        result = find_outliers(data, method="max")
        assert isinstance(result["cutoff"], float)

    def test_method_max_peak_is_max(self):
        data = make_semi_normal()
        result = find_outliers(data, method="max")
        # With method=max, mirror_mean should equal the max value
        # (because peak == max, mirroring lower half gives symmetric dist centred at max)
        assert result["mirror_mean"] == pytest.approx(data.max(), rel=1e-6)

    def test_invalid_method_raises(self):
        with pytest.raises(ValueError, match="method"):
            find_outliers([1, 2, 3, 4, 5], method="median")


# ------------------------------------------------------------------ #
# threshold parameter                                                  #
# ------------------------------------------------------------------ #

class TestThreshold:
    def test_higher_threshold_fewer_outliers(self):
        data = make_semi_normal()
        r2 = find_outliers(data, threshold=2)
        r3 = find_outliers(data, threshold=3)
        assert len(r2["outliers"]) >= len(r3["outliers"])

    def test_lower_threshold_more_outliers(self):
        data = make_semi_normal()
        r2 = find_outliers(data, threshold=2)
        r1 = find_outliers(data, threshold=1)
        assert len(r1["outliers"]) >= len(r2["outliers"])

    def test_invalid_threshold_zero(self):
        with pytest.raises(ValueError, match="threshold"):
            find_outliers([1, 2, 3, 4, 5], threshold=0)

    def test_invalid_threshold_negative(self):
        with pytest.raises(ValueError, match="threshold"):
            find_outliers([1, 2, 3, 4, 5], threshold=-1)


# ------------------------------------------------------------------ #
# Edge cases / error handling                                          #
# ------------------------------------------------------------------ #

class TestEdgeCases:
    def test_too_few_values_raises(self):
        with pytest.raises(ValueError):
            find_outliers([1, 2])

    def test_all_nans_raises(self):
        with pytest.raises(ValueError):
            find_outliers([np.nan, np.nan, np.nan])

    def test_identical_values_doesnt_crash(self):
        """All identical — std will be 0, no outliers expected."""
        data = [5.0] * 50
        result = find_outliers(data, method="max")
        assert len(result["outliers"]) == 0
