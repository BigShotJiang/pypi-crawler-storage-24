# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""OpenClaw security audit tools for Trent MCP Server.

Reads an OpenClaw deployment configuration, redacts secrets locally,
and sends metadata to Trent's AppSec Advisor for AI-powered security analysis.
Also provides deep skill analysis for uploaded skill packages.
"""

import logging
from pathlib import Path
from typing import Annotated

from mcp.server.fastmcp import Context
from pydantic import Field

from trent_mcp.mcp_instance import get_mcp
from trent_mcp.tools.appsec import _get_shared_client

mcp = get_mcp()

logger = logging.getLogger(__name__)

SOURCE_NAME = "HumberAgent OpenClaw Security Audit"


@mcp.tool()
async def audit_openclaw_setup(
    openclaw_config_path: Annotated[
        str | None,
        Field(
            description="Path to OpenClaw config directory. Defaults to ~/.openclaw. "
            "Only metadata is collected — no secret values are sent to the API."
        ),
    ] = None,
    ctx: Context | None = None,
) -> dict:
    """
    Audit an OpenClaw deployment for security risks.

    Reads the OpenClaw configuration from ~/.openclaw/ (or specified path),
    extracts METADATA ONLY (secret values are redacted locally), and sends
    the metadata to Trent's AppSec Advisor for AI-powered security analysis.

    Checks for: gateway security, tool permissions, MCP server config,
    plugin risks, sandbox escapes, elevated mode, DM policies, file
    permissions, network exposure, skill safety, and chained attack paths.
    """
    from trent_mcp.openclaw.openclaw_config.collector import collect_openclaw_metadata
    from trent_mcp.openclaw.system_analyzer import collect_system_analysis

    if ctx:
        await ctx.info("Collecting OpenClaw configuration metadata...")
        await ctx.report_progress(progress=10, total=100)

    # Collect metadata (safe file reading, secret redaction)
    path_arg = Path(openclaw_config_path) if openclaw_config_path else None
    metadata = collect_openclaw_metadata(openclaw_path=path_arg)

    if metadata.get("error"):
        return {
            "source": SOURCE_NAME,
            "error": True,
            "message": metadata["message"],
        }

    if ctx:
        await ctx.info("Collecting system context...")
        await ctx.report_progress(progress=20, total=100)

    system_info = collect_system_analysis(openclaw_path=path_arg)

    if ctx:
        await ctx.info("Metadata collected. Sending to AppSec Advisor for analysis...")
        await ctx.report_progress(progress=30, total=100)

    client = _get_shared_client()
    from trent_mcp.openclaw.audit_prompt import build_audit_prompt

    message = build_audit_prompt(metadata, system_info=system_info)

    if ctx:
        await ctx.info("Analyzing OpenClaw configuration security...")
        await ctx.report_progress(progress=50, total=100)

    response = await client.chat(message=message)

    if ctx:
        await ctx.info("Security audit complete")
        await ctx.report_progress(progress=100, total=100)

    if response.get("error"):
        return {
            "source": SOURCE_NAME,
            "error": True,
            "message": response["content"],
        }

    return {
        "source": SOURCE_NAME,
        "review": response["content"],
        "thread_id": response.get("thread_id"),
        "metadata_summary": {
            "config_present": metadata.get("config") is not None,
            "skill_count": len(metadata.get("skills", [])),
            "workspace_exists": metadata.get("workspace", {}).get("exists", False),
            "redacted_count": len(metadata.get("redacted_paths", [])),
            "errors": metadata.get("errors", []),
        },
        "system_summary": {
            "os_type": system_info.get("os", {}).get("os_type"),
            "hardware_type": system_info.get("hardware", {}).get("type"),
            "user_mode": system_info.get("user_mode", {}).get("mode"),
            "channel_count": system_info.get("channels", {}).get("channel_count", 0),
        },
    }


SKILL_ANALYSIS_SOURCE = "HumberAgent OpenClaw Skill Analysis"


def _build_skill_analysis_prompt(upload_summary: dict) -> str:
    """Build a chat prompt requesting analysis of uploaded skills."""
    skills = upload_summary.get("skills", [])
    summary = upload_summary.get("summary", {})

    uploaded_skills = [s for s in skills if s.get("status") in ("uploaded", "skipped")]
    skill_list = "\n".join(f"- {s['name']} ({s['type']})" for s in uploaded_skills)
    total = summary.get("uploaded", 0) + summary.get("skipped", 0)

    return (
        f"I have uploaded {total} OpenClaw skill packages for security analysis. "
        f"Please analyse them and return the results.\n\n"
        f"Uploaded skills:\n{skill_list}\n\n"
        f"Focus on: prompt injection vectors, tool permission escalation, "
        f"data exfiltration paths, secrets in skill code, unsafe subprocess calls, "
        f"and chained attack paths between skills.\n"
        f"Group findings by severity (CRITICAL, HIGH, MEDIUM, LOW)."
    )


def _build_per_skill_analysis_prompt(skill: dict) -> str:
    """Build a chat prompt requesting analysis of a single uploaded skill."""
    return (
        f"Please analyse the uploaded OpenClaw skill package '{skill['name']}' "
        f"(type: {skill['type']}) for security risks.\n\n"
        f"Focus on: prompt injection vectors, tool permission escalation, "
        f"data exfiltration paths, secrets in skill code, unsafe subprocess calls, "
        f"and chained attack paths with other skills in this deployment.\n"
        f"Group findings by severity (CRITICAL, HIGH, MEDIUM, LOW)."
    )


@mcp.tool()
async def analyse_openclaw_skills(
    upload_summary: Annotated[
        dict,
        Field(
            description="The summary dict returned by upload_openclaw_skills. "
            "Contains the list of uploaded skills and their metadata."
        ),
    ],
    ctx: Context | None = None,
) -> dict:
    """
    Analyse uploaded OpenClaw skills for security risks.

    Call this after upload_openclaw_skills completes. Sends a request to
    Trent's AppSec Advisor to analyse the skill code that was uploaded
    to S3, and returns the security findings.

    The analysis runs on the same chat thread as audit_openclaw_setup,
    so the advisor has full context from the configuration audit.
    """
    if ctx:
        await ctx.info("Requesting deep skill analysis...")
        await ctx.report_progress(progress=10, total=100)

    message = _build_skill_analysis_prompt(upload_summary)

    if ctx:
        await ctx.info("Analysing uploaded skill code...")
        await ctx.report_progress(progress=30, total=100)

    client = _get_shared_client()
    response = await client.chat(message=message)

    if ctx:
        await ctx.info("Skill analysis complete")
        await ctx.report_progress(progress=100, total=100)

    if response.get("error"):
        return {
            "source": SKILL_ANALYSIS_SOURCE,
            "error": True,
            "message": response["content"],
        }

    summary = upload_summary.get("summary", {})
    return {
        "source": SKILL_ANALYSIS_SOURCE,
        "review": response["content"],
        "thread_id": response.get("thread_id"),
        "skills_analysed": summary.get("uploaded", 0) + summary.get("skipped", 0),
    }
