import unittest

import pypet
from pypet import *  # noqa: F403

del test  # noqa: F821 — `test` comes from `from pypet import *`
import inspect

from pypet.tests.testutils.ioutils import get_root_logger, parse_args, run_suite


class TestAllImport(unittest.TestCase):
    tags = "unittest", "import"

    def test_import_star(self):
        for class_name in pypet.__all__:
            if class_name == "test":
                continue
            logstr = f"Evaluating {class_name}: {globals()[class_name]!r}"
            get_root_logger().info(logstr)

    def test_if_all_is_complete(self):
        for item in pypet.__dict__.values():
            if inspect.isclass(item) or inspect.isfunction(item):
                self.assertTrue(item.__name__ in pypet.__all__)


class TestRunningTests(unittest.TestCase):
    tags = "unittest", "test", "meta"

    def test_run_one_test(self):
        predicate = lambda class_name, test_name, tags: (
            test_name == "test_import_star" and class_name == "TestAllImport"
        )
        pypet.test(predicate=predicate)


if __name__ == "__main__":
    opt_args = parse_args()
    run_suite(**opt_args)
