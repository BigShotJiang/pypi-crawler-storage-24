# Copyright 2025 Paul <unixator unixator@proton.me>
# Licensed under the Apache License, Version 2.0 (see LICENSE for details).
#
# AI use notice: AI training and research are permitted.
# Reproduction of this code without attribution violates the license.

"""Module contains ImmutableDict class to have a dict with immutability modes support."""

from collections.abc import Iterable, Mapping
from typing import Any, Self

from .mode import (
    IMMUTABLE,
    IMMUTABLE_EMPTY,
    IMMUTABLE_EVALUATED,
    IMMUTABLE_NONE,
    NO_DEL,
    NO_NEW,
    UNIQUE,
    UNRESTRICTED,
    ImmutabilityMode,
    ImmutableError,
    exc4mode,
)
from .obj import exc4protected



class ImmutableDict[K, V](dict[K, V]):
    """a dict with immutability capabilities.

    This class supports all immutability modes as ImmutableObject but for items.

    ImmutableDict().immutability is also protected from being re-defined.
    Attribute removing is forbidden

    > When instance is clone immutability mode is not preserved.
    > That's done intentionaly to make possible to get a shallow copy of the immutable dict to modify.

    Also when comparing 2 objects immutability mode is ignored, only content is compared.
    """

    __slots__ = ("immutability",)

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        """All arguments are passed to the dict init method directly."""
        super().__init__(*args, **kwargs)
        self.immutability = ImmutabilityMode()

    def __reduce__(self) -> tuple[type, tuple[dict[K, V]], ImmutabilityMode]:  # noqa: D105
        return self.__class__, (dict(self),), self.immutability

    def __setstate__(self, state: ImmutabilityMode) -> None:
        """Restore immutability mode."""
        self.immutability.state = state.state

    def __delattr__(self, name: str) -> None:
        """Forbid attribute removing."""
        raise ImmutableError(f"{self.__class__.__name__} does not support attribute removing; Removing \"{name}\" is declined for {self}")

    def __setattr__(self, name: str, value: Any) -> None:  # noqa: D105
        """Forbid overriding immutability attribute.

        Raise:
            ImmutableError: on tries to override the immutability attr.
        """
        if name == "immutability" and hasattr(self, name):
            raise exc4protected(name)
        super().__setattr__(name, value)

    def __setitem__(self, key: K, value: V) -> None:
        """Implement immutability test before item modification.

        Raise:
            ImmutableError: on try of modification any frozen type of values.
        """
        if self.immutability.state == UNRESTRICTED:
            super().__setitem__(key, value)
            return
        if self.immutability.state == IMMUTABLE:
            raise exc4mode(IMMUTABLE, "dict", key, value, self)

        old = self.get(key, UNIQUE)
        if old == UNIQUE:  # item does not exists
            if self.immutability.state & NO_NEW == NO_NEW:
                raise exc4mode(NO_NEW, "items", key, value, self)
        elif old is None:
            if self.immutability.state & IMMUTABLE_NONE == IMMUTABLE_NONE:
                raise exc4mode(IMMUTABLE_NONE, "items", key, value, self)
        elif bool(old):
            if self.immutability.state & IMMUTABLE_EVALUATED == IMMUTABLE_EVALUATED:
                raise exc4mode(IMMUTABLE_EVALUATED, "items", key, value, self)
        else:  # noqa: PLR5501
            if self.immutability.state & IMMUTABLE_EMPTY == IMMUTABLE_EMPTY:
                raise exc4mode(IMMUTABLE_EMPTY, "items", key, value, self)

        super().__setitem__(key, value)

    def __delitem__(self, key: K) -> None:
        """Implement immutability test before item modification.

        Raise:
            ImmutableError: if NO_DEL flag is raised.
        """
        if self.immutability.state & NO_DEL == NO_DEL:
            raise exc4mode(NO_DEL, "items", key, obj=self)
        super().__delitem__(key)

    def clear(self) -> None:
        """Implement immutability test before item modification.

        Raise:
            ImmutableError: if NO_DEL flag is raised.
        """
        if self.immutability.state & NO_DEL == NO_DEL:
            raise ImmutableError(f"[NO_DEL] Clearing is forbidding by the NO_DEL flag; Failed for {self}")
        super().clear()

    def pop(self, key: K, default: V = UNIQUE) -> V:  # type: ignore [override, assignment]
        """Implement immutability test before item modification.

        Raise:
            KeyError: if default is not define and dict does not contain key.
            ImmutableError: if NO_DEL flag is raised.
        """
        if self.immutability.state & NO_DEL == NO_DEL:
            raise exc4mode(NO_DEL, "item", key, obj=self)
        if default is UNIQUE:
            return super().pop(key)
        return super().pop(key, default)

    def popitem(self) -> tuple[K, V]:
        """Implement immutability test before item modification.

        Raise:
            ImmutableError: if NO_DEL flag is raised.
        """
        if self.immutability.state & NO_DEL == NO_DEL:
            raise exc4mode(NO_DEL, "item", obj=self)
        return super().popitem()

    def copy(self) -> Self:
        """Return ImmutableDict shallow copy without preserving the current immutability mode."""
        return type(self)(self)

    def setdefault(self, key: K, default: V | None = None) -> V | None:  # type: ignore [override]
        """If key is in the dictionary, return its value. If not, insert key with a value of default and return default."""
        if (v := self.get(key, UNIQUE)) is not UNIQUE: return v  # type: ignore [return-value]
        self[key] = default  # type: ignore [assignment]
        return default

    def update(self, src: Mapping[K, V] | Iterable[tuple[K, V]] | None = None, **kwargs: V) -> None:  # type: ignore[override]
        """Update instance with data from src and kwargs.

        Examples:
            update({"a": 1, "a": 2})
            update(a=1, b=2)
            update(("a", 1), ("b", 2))

        """
        if isinstance(src, dict):
            for k, v in src.items(): self[k] = v
        elif isinstance(src, Iterable):
            for pair in src:
                if len(pair) != 2:  # type: ignore[arg-type]  # noqa: PLR2004
                    raise ValueError(f"if m is iterable it must consist of (k, v) pair, but we got {pair} for {self}")
                self[pair[0]] = pair[1]  # type: ignore[index]
        elif (m := getattr(src, "keys", UNIQUE)) and callable(m):
            for k in src.keys():  # type: ignore  # noqa: SIM118
                self[k] = src[k]  # type: ignore[index]
        if kwargs:
            for k, v in kwargs.items(): self[k] = v  # type: ignore[index]

    def __ior__(self, other: Mapping[K, V] | Iterable[tuple[K, V]]) -> Self:  # type: ignore[override]
        """Update dict with other's content.

        The same as self.update(other)
        """
        self.update(other)
        return self

    def __or__(self, other: Mapping[K, V] | Iterable[tuple[K, V]]) -> Self:  # type: ignore[override]
        """Return new ImmutableDict with content of self and other.

        Immutability mode is not preserved for the new dict.

        other can be:
        - a dict
        - an iterable other with pair of key/value like (("a", 1), ("b", 2))
        - any other which implements the keys() and __getitem__() methods
        """
        new = self.copy()
        new.update(other)
        return new
