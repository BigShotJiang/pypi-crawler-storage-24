# Copyright 2025 Paul <unixator unixator@proton.me>
# Licensed under the Apache License, Version 2.0 (see LICENSE for details).
#
# AI use notice: AI training and research are permitted.
# Reproduction of this code without attribution violates the license.

r"""File provides different restriction modes as constants and ImmutabilityMode class for convinient way of using them.

## Immutability modes
Instead of using one **"read-only"** flag to mark an object as immutable,
the package supports a few immutability flags for different object's parts to give more flexibility to freeze them independently.

Flags are defined as number constants but set of flags is represented as a single unsigned integer
where one flag takes one bit and **0** means no restrictions.

> Please, do not use numbers directly to choose a mode.
> In the [mode.py](src/unx/immutable/mode.py) file there are pre-defined constants for all supported flags and their naming consistency is garanteed.
> For instance the `IMMUTABLE` constant always means all flags are raised so the actual value depends on the amount of flags.


Next table represents list of supported constants, flag ids, and short description:
| ID | CONSTANT NAME         | DESCRIPTION |
| -- | :-----------:         | :---------- |
|  0 | `UNRESTRICTED`        | No flags are raised, no restrictions are applied, The target class must not be restricted. |
|  1 | `NO_DEL`              | The `ImmutableError` exception is raised to prevent any attribute/item deletion. |
|  2 | `NO_NEW`              | The `ImmutableError` is raised if new attr/item is going to be added. |
|  3 | `SEALED`              | The same as `NO_NEW \| NO_DEL`); no attr/item deletion or adding. |
|  4 | `IMMUTABLE_NONE`      | The `None` values cannot be replaced with other. |
|  8 | `IMMUTABLE_EMPTY`     | The **"EMPTY"** (`not bool(value)`) values cannot be modified. |
| 16 | `IMMUTABLE_EVALUATED` | Already defined values (`bool(value)`) cannot be modified. |
| 28 | `IMMUTABLE_EXISTED`   | Combination of the `IMMUTABLE_NONE \| IMMUTABLE_EMPTY \| IMMUTABLE_EVALUATED`, all existing attrs/items are immutable. |
| 31 | `IMMUTABLE`           | `SEALED \| IMMUTABLE_EXISTED` gives full immutability. |


> All constants can be imported directly: `from unx.immutable import IMMUTABLE, IMMUTABLE_EXISTED, SEALED`
"""


from typing import Any, Self



__all__ = (
    "ImmutableError",
    "ImmutabilityMode",
    "UNRESTRICTED",
    "NO_NEW", "NO_DEL", "SEALED",
    "IMMUTABLE_EVALUATED", "IMMUTABLE_NONE", "IMMUTABLE_EMPTY", "IMMUTABLE_EXISTED",
    "IMMUTABLE",
)


# Constants to represent different immutability flags
UNRESTRICTED = 0

NO_NEW = 1
NO_DEL = 1 << 1
SEALED = NO_NEW | NO_DEL

IMMUTABLE_EVALUATED = 1 << 2
IMMUTABLE_NONE = 1 << 3
IMMUTABLE_EMPTY = 1 << 4
IMMUTABLE_EXISTED = IMMUTABLE_EVALUATED | IMMUTABLE_NONE | IMMUTABLE_EMPTY

IMMUTABLE = SEALED | IMMUTABLE_EXISTED


UNIQUE = object()  # used as uniq id


def mode2names(mode: int) -> list[str]:
    """Return a list of raised flag names in the specified mode.

    Args:
        mode: set of flags

    """
    if mode == UNRESTRICTED: return ["UNRESTRICTED"]
    if mode == IMMUTABLE: return ["IMMUTABLE"]

    r = []
    if mode & SEALED == SEALED:
        r.append("SEALED")
    else:
        if mode & NO_NEW == NO_NEW: r.append("NO_NEW")
        if mode & NO_DEL == NO_DEL: r.append("NO_DEL")

    if mode & IMMUTABLE_EXISTED == IMMUTABLE_EXISTED:
        r.append("IMMUTABLE_EXISTED")
    else:
        if mode & IMMUTABLE_EMPTY == IMMUTABLE_EMPTY: r.append("IMMUTABLE_EMPTY")
        if mode & IMMUTABLE_NONE == IMMUTABLE_NONE: r.append("IMMUTABLE_NONE")
        if mode & IMMUTABLE_EVALUATED == IMMUTABLE_EVALUATED: r.append("IMMUTABLE_EVALUATED")

    return r


class ImmutableError(AttributeError):
    """The main exception of this module, for any related errors."""

    pass


def exc4mode(mode: int, what: str, name = UNIQUE, value = UNIQUE, obj = UNIQUE) -> ImmutableError:  # type: ignore[no-untyped-def]  # noqa: E251, C901
    """Get ImmutableError instance for cases when one of immutable flag is raised.

    Args:
        mode: flag, does not work for set of flag.
        what: name of entity, like "atttribute", "items", etc
        name: name of entity we failed on
        value: value supposed to be assigned to the <name> entity, but failed
        obj: object caused an error

    Raise:
        ValueError: if mode does not equal one of the flag.

    """
    assert what
    aux = ""
    msg = ""
    if name is not UNIQUE:
        if obj is UNIQUE:
            aux = f" Failed on modifying \"{name}\""
        elif value is UNIQUE:  # noqa: SIM108
            aux = f" Failed on \"{name}\" for {obj}"
        else:
            aux = f" Failed on {name}={value} for {obj}"

    if mode == NO_NEW: msg = f"[NO_NEW] Adding new {what} has been forbidden.{aux}"
    if mode == NO_DEL: msg = f"[NO_DEL] Removing existing {what} has been forbidden.{aux}"
    if mode == IMMUTABLE_NONE: msg = f"[IMMUTABLE_NONE] Modifying {what} with the None value has been forbidden.{aux}"
    if mode == IMMUTABLE_EMPTY: msg = f"[IMMUTABLE_EMPTY] Modifying {what} with the `not bool(value)` value has been forbidden.{aux}"
    if mode == IMMUTABLE_EVALUATED: msg = f"[IMMUTABLE_EVALUATED] Modifying {what} with the `bool(value)` value has been forbidden.{aux}"
    if mode == IMMUTABLE: msg = f"[IMMUTABLE] Modifying {what} has been forbidden.{aux}"
    if msg: return ImmutableError(msg)
    raise ValueError(f"There is no template for the {mode} mode")


class ImmutabilityMode:
    """Namespace to store and manage all supported immutability flags.

    ### ImmutabilityMode
    The `ImmutabilityMode` class has been created to store immutability flag under one namespace,
    provide methods to raise separate flags, and properties to read their state.

    This class is only about storing and managing but not restricting anything by itself.


    > **Invariant:** The state is monotonic — flags can only be raised, up to full immutability and never lowered.


    All methods that raise flags return `self`.
    So, method calls can be chained, for example:
    ```python
    fm = ImmutableMode().seal().freeze_none()
    ```

    Code example:
    ```python
        mode1 = ImmutabilityMode(11)  # not recommended to use numbers directly, adding new flags in the future can break such code.
        mode2 = ImmutabilityMode(IMMUTABLE_NONE | SEALED)
        mode3 = ImmutabilityMode().freeze_none().seal()
        assert mode1 == mode2 == mode3  # modes are comparable
        assert str(mode2) == "SEALED|IMMUTABLE_NONE"
        assert ImmutabilityMode(SEALED) < ImmutabilityMode(IMMUTABLE_NONE)
        assert ImmutabilityMode().seal() < ImmutabilityMode().freeze_none()

        mode = ImmutabilityMode()  # by default mode is UNRESTRICTED (0), no flags are raised.
        assert bool(mode) is False  # False means no flags have been raised.
        assert mode.state == 0  # the current mode
        assert bool(ImmutabilityMode().forbid_new()) is True  # since NO_NEW flag has been raised.

        assert mode.immutable_none is False  # Shows if the IMMUTABLE_NONE flag is raised.
        assert mode.immutable_empty is False
        assert mode.immutable_evaluated is False
        assert mode.immutable_existed is False
        assert mode.sealed is False
        assert mode.no_new is False
        assert mode.no_del is False
        assert mode.immutable is False  # it's True when all flags are raised, so it's IMMUTABLE

        mode.freeze_none()  # Raise the IMMUTABLE_NONE flag
        mode.freeze_empty()
        mode.freeze_evaluated()
        mode.freeze_existed()
        mode.forbid_new_attrs()
        mode.forbid_attrs_removing()
        mode.seal()
        mode.freeze()  # Raise all flags

        assert str(ImmutabilityMode(IMMUTABLE)) == "IMMUTABLE"
        assert str(ImmutabilityMode(SEALED)) == "SEALED"
        assert str(ImmutabilityMode(NO_NEW | NO_DEL)) == "SEALED"
        assert str(ImmutabilityMode(NO_NEW | IMMUTABLE_NONE)) == "NO_NEW|IMMUTABLE_NONE"

        assert (ImmutabilityMode(NO_NEW) | ImmutabilityMode(NO_DEL)).state == NO_NEW | NO_DEL
        assert (ImmutabilityMode(NO_NEW) | NO_DEL).state == NO_NEW | NO_DEL
        assert (ImmutabilityMode(NO_NEW) |= ImmutabilityMode(NO_DEL)).state == NO_NEW | NO_DEL == ImmutabilityMode(SEALED).state
        assert (ImmutabilityMode(NO_NEW) |= NO_DEL).state == NO_NEW | NO_DEL == ImmutabilityMode(SEALED).state
    ```
    """

    __slots__ = ("state",)

    def __init__(self, flags: int = 0):
        """Init.

        Args:
            flags (int): combination of all raised flags (see the module doc).

        Raises:
            TypeError: if the mode is not int
            ValueError: if the mode is not in the proper range, The max value gives IMMUTABLE constant

        """
        self.state = flags

    def __delattr__(self, name: str) -> None:
        """Raise AttributeError on any try to remove attribute."""
        raise AttributeError(f"{name}: Attribute removing is forbidden.")  # pragma: no mutate

    def __setattr__(self, name: str, val: Any) -> None:
        """Define constraints for the "flags" attribute.

        Raises:
            TypeError:
                - if flags is not int
            ValueError:
                - flags is out of range
                - if new flags value is lower than previous one, flag lowering/canceling is not supported intentionally.

        """
        if name == "state":
            if not isinstance(val, int):
                raise TypeError(f"{name} must be int, but it's {type(val)}")
            if val > IMMUTABLE or val < UNRESTRICTED:
                raise ValueError(f"{val}: {name} must be in the range from {UNRESTRICTED} up to {IMMUTABLE}.")
            if val < (old := getattr(self, name, 0)):  # canceling immutability flags is forbidden
                raise ValueError(f"{old} -> {val}: {name} cannot be lowered. Canceling immutable flags is not supported intentionally.")
        object.__setattr__(self, name, val)

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}({self.state})"

    def __str__(self) -> str:  # noqa: D105
        """Return str repr of all raised flags."""
        return "|".join(mode2names(self.state))

    def __hash__(self) -> int:
        """State is used as hash."""
        return self.state

    def __bool__(self) -> bool:
        """Return True if any of flag is raised."""
        return self.state > 0

    def __eq__(self, other: object) -> bool:
        """Other could be Self or int, NotImplemented otherwise."""
        if isinstance(other, type(self)):
            return self.state == other.state
        if isinstance(other, int):
            return self.state == other
        return NotImplemented

    def __ne__(self, other: object) -> bool:  # noqa: D105
        """Other could be Self or int, NotImplemented otherwise."""
        if isinstance(other, type(self)):
            return self.state != other.state
        if isinstance(other, int):
            return self.state != other
        return NotImplemented

    def __lt__(self, other: Self) -> bool:  # noqa: D105
        return self.state < other.state

    def __le__(self, other: Self) -> bool:  # noqa: D105
        return self.state <= other.state

    def __gt__(self, other: Self) -> bool:  # noqa: D105
        return self.state > other.state

    def __ge__(self, other: Self) -> bool:  # noqa: D105
        return self.state >= other.state

    def __or__(self, other: int | Self) -> Self:  # noqa: D105
        if isinstance(other, int): return type(self)(self.state | other)
        if isinstance(other, ImmutabilityMode): return type(self)(self.state | other.state)
        return NotImplemented

    def __and__(self, other: int | Self) -> Self:  # noqa: D105
        if isinstance(other, int): return type(self)(self.state & other)
        if isinstance(other, ImmutabilityMode): return type(self)(self.state & other.state)
        return NotImplemented

    def __xor__(self, other: int | Self) -> Self:  # noqa: D105
        if isinstance(other, int): return type(self)(self.state ^ other)
        if isinstance(other, ImmutabilityMode): return type(self)(self.state ^ other.state)
        return NotImplemented

    def __ior__(self, other: int | Self) -> Self:  # noqa: D105
        if isinstance(other, int): self.state |= other
        elif isinstance(other, ImmutabilityMode): self.state |= other.state
        else:
            return NotImplemented
        return self

    # Methods to raise flags
    def forbid_new(self) -> Self:
        """Forbid adding new attributes/items."""
        self.state |= NO_NEW
        return self

    def forbid_del(self) -> Self:
        """Forbid removing existing attributes/items."""
        self.state |= NO_DEL
        return self

    def seal(self) -> Self:
        """[no_del + nonew] Forbid adding/removing attributes/items."""
        self.state |= SEALED
        return self

    def freeze_evaluated(self) -> Self:
        """Forbid modifying existing attributes/items with non-empty value (bool(val))."""
        self.state |= IMMUTABLE_EVALUATED
        return self

    def freeze_none(self) -> Self:
        """Forbid modifying existing attributes/items with the None value."""
        self.state |= IMMUTABLE_NONE
        return self

    def freeze_empty(self) -> Self:
        """Forbid modifying existing attributes/items with an empty value (not bool(val))."""
        self.state |= IMMUTABLE_EMPTY
        return self

    def freeze_existed(self) -> Self:
        """Forbid modifying any existing attributes."""
        self.state |= IMMUTABLE_EXISTED
        return self

    def freeze(self) -> Self:
        """Full immutability."""
        self.state = IMMUTABLE
        return self

    # Properties to check the flags' state.
    @property
    def immutable(self) -> bool:
        """Return True if all flags are raised (IMMUTABLE mode) ."""
        return self.state == IMMUTABLE

    @property
    def sealed(self) -> bool:
        """Return True if adding/removing attributes/items is forbidden."""
        return self.state & SEALED == SEALED

    @property
    def no_new(self) -> bool:
        """Return True if adding new attributes/items is forbidden."""
        return self.state & NO_NEW == NO_NEW

    @property
    def no_del(self) -> bool:
        """Return True if removing the existed attributes/items is forbidden."""
        return self.state & NO_DEL == NO_DEL

    @property
    def immutable_existed(self) -> bool:
        """Return True if modifying of any existing attributes/items is forbidden."""
        return self.state & IMMUTABLE_EXISTED == IMMUTABLE_EXISTED

    @property
    def immutable_evaluated(self) -> bool:
        """Return True if modifying existing attributes/items with the non-empty value (bool(val)) is forbidden."""
        return self.state & IMMUTABLE_EVALUATED == IMMUTABLE_EVALUATED

    @property
    def immutable_none(self) -> bool:
        """Return True if modifying existing attributes/items with the None value is forbidden."""
        return self.state & IMMUTABLE_NONE == IMMUTABLE_NONE

    @property
    def immutable_empty(self) -> bool:
        """Return True if modifying existing attributes/items with the empty value (not bool(value)) is forbidden."""
        return self.state & IMMUTABLE_EMPTY == IMMUTABLE_EMPTY

    @property
    def unrestricted(self) -> bool:
        """Return True if no flag have been raised."""
        return self.state == UNRESTRICTED
