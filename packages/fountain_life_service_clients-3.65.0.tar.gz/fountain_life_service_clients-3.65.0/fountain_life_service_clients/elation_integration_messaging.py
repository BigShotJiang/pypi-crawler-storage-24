# This file was generated automatically. Do not edit it directly.
from typing import List, Literal, NotRequired, Optional, TypedDict, Unpack, cast

from fountain_life_service_clients._base_client import (
    AlphaConfig,
    AlphaResponse,
    BaseClient,
)


class SendCareTeamMessageRequest(TypedDict):
    patientId: str
    message: str
    urgent: NotRequired[bool]


class Patient(TypedDict):
    phcId: str
    elationId: str


class CareTeamMember(TypedDict):
    phcId: str
    userId: NotRequired[float]
    practice: NotRequired[float]


class SendCareTeamMessageResponse(TypedDict):
    patient: Patient
    careTeamMembers: List[CareTeamMember]
    message: str
    urgent: bool
    messageThreadId: float


class GetCareTeamInfoParams(TypedDict):
    patientId: str


class patient(TypedDict):
    phcId: str
    elationId: Optional[str]


class Warning(TypedDict):
    type: Literal["patient", "careTeamMember"]
    phcId: str
    field: str
    message: str


class GetCareTeamInfoResponse(TypedDict):
    patient: patient
    careTeamMembers: List[CareTeamMember]
    warnings: List[Warning]


class SendClinicianMessageRequest(TypedDict):
    email: str
    message: str
    urgent: NotRequired[bool]
    patientId: NotRequired[str]


class SendClinicianMessageResponse(TypedDict):
    userId: float
    practice: float
    message: str
    urgent: bool
    messageThreadId: float


class ElationIntegrationMessagingClient(BaseClient):
    def __init__(self, **cfg: Unpack[AlphaConfig]):
        kwargs = {
            "target": "lambda://elation-integration-messaging-api:deployed",
            **(cfg or {}),
        }
        super().__init__(**kwargs)

    async def send_care_team_message(self, body: SendCareTeamMessageRequest):
        """Send a message to a patient's care team"""
        res = await self.client.request(
            path="/v1/private/messages/careteam", method="POST", body=cast(dict, body)
        )
        return cast(AlphaResponse[SendCareTeamMessageResponse], res)

    async def get_care_team_info(self, params: GetCareTeamInfoParams):
        """Get a patient's care team information with warnings for missing data"""
        res = await self.client.request(
            path="/v1/private/messages/careteam",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[GetCareTeamInfoResponse], res)

    async def send_clinician_message(self, body: SendClinicianMessageRequest):
        """Send a message to a clinician"""
        res = await self.client.request(
            path="/v1/private/messages/clinician", method="POST", body=cast(dict, body)
        )
        return cast(AlphaResponse[SendClinicianMessageResponse], res)
