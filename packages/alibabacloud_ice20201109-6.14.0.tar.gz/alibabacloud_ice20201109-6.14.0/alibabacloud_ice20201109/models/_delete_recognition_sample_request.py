# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class DeleteRecognitionSampleRequest(DaraModel):
    def __init__(
        self,
        algorithm: str = None,
        entity_id: str = None,
        lib_id: str = None,
        owner_account: str = None,
        owner_id: int = None,
        resource_owner_account: str = None,
        resource_owner_id: int = None,
        sample_id: str = None,
    ):
        # The type of recognition algorithm. Valid values:
        # 
        # *   landmark
        # *   object
        # *   logo
        # *   face
        # *   label
        # 
        # This parameter is required.
        self.algorithm = algorithm
        # The ID of the entity.
        # 
        # This parameter is required.
        self.entity_id = entity_id
        # The ID of the recognition library.
        # 
        # This parameter is required.
        self.lib_id = lib_id
        self.owner_account = owner_account
        self.owner_id = owner_id
        self.resource_owner_account = resource_owner_account
        self.resource_owner_id = resource_owner_id
        # The ID of the sample that you want to delete.
        # 
        # This parameter is required.
        self.sample_id = sample_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.algorithm is not None:
            result['Algorithm'] = self.algorithm

        if self.entity_id is not None:
            result['EntityId'] = self.entity_id

        if self.lib_id is not None:
            result['LibId'] = self.lib_id

        if self.owner_account is not None:
            result['OwnerAccount'] = self.owner_account

        if self.owner_id is not None:
            result['OwnerId'] = self.owner_id

        if self.resource_owner_account is not None:
            result['ResourceOwnerAccount'] = self.resource_owner_account

        if self.resource_owner_id is not None:
            result['ResourceOwnerId'] = self.resource_owner_id

        if self.sample_id is not None:
            result['SampleId'] = self.sample_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Algorithm') is not None:
            self.algorithm = m.get('Algorithm')

        if m.get('EntityId') is not None:
            self.entity_id = m.get('EntityId')

        if m.get('LibId') is not None:
            self.lib_id = m.get('LibId')

        if m.get('OwnerAccount') is not None:
            self.owner_account = m.get('OwnerAccount')

        if m.get('OwnerId') is not None:
            self.owner_id = m.get('OwnerId')

        if m.get('ResourceOwnerAccount') is not None:
            self.resource_owner_account = m.get('ResourceOwnerAccount')

        if m.get('ResourceOwnerId') is not None:
            self.resource_owner_id = m.get('ResourceOwnerId')

        if m.get('SampleId') is not None:
            self.sample_id = m.get('SampleId')

        return self

