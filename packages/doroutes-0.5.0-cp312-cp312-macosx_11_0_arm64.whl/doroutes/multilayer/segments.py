"""Segment/corner analysis, backtrack detection — zero PDK refs."""

from .path import _has_local_backtrack_corners, _has_local_backtrack_path


# Re-export from path for backward compatibility
def _has_local_backtrack_corners_seg(corners_3d: list[tuple[int, int, int]]) -> bool:
    """Detect immediate A->B->A position reversals."""
    return _has_local_backtrack_corners(corners_3d)


def _has_local_backtrack_path_seg(
    path: list[tuple[float, float]], tol: float = 1e-6
) -> bool:
    """Detect immediate A->B->A position reversals in 2D path."""
    return _has_local_backtrack_path(path, tol)


def _transition_target_via_width(
    corners_3d: list[tuple[int, int, int]],
    seg_widths: list[float],
    transition_idx: int,
    fallback_width: float,
) -> float:
    """Target via-driving width from neighboring straight segments around a layer transition."""
    widths: list[float] = []
    n = len(seg_widths)
    for cand in (transition_idx - 1, transition_idx, transition_idx + 1):
        if 0 <= cand < n:
            widths.append(float(seg_widths[cand]))
    if not widths:
        widths.append(float(fallback_width))
    return max(widths)
