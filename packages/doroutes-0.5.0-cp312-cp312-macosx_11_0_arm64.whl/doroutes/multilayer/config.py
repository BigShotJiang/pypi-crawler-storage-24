"""Configuration dataclasses for PDK-agnostic multi-layer routing."""

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class MetalLayerSpec:
    """Specification for a single metal routing layer."""

    layer_tuple: tuple[int, int]
    preferred_direction: str  # 'h' or 'v'
    min_width: float  # um
    min_via_pad: float  # um
    below_cut_layer: tuple[int, int] | None = None
    pitch: float | None = None  # um, track pitch
    spacing: float | None = None  # um, min spacing


@dataclass
class BatchRoutingParams:
    """Parameters for the GRT+DRT batch router."""

    gcell_size_um: float = 5.0
    max_grt_iters: int = 50
    max_drt_iters: int = 30


@dataclass(frozen=True)
class RoutingConfig:
    """PDK-specific routing configuration injected into all routing functions."""

    metal_layers: tuple[MetalLayerSpec, ...]
    via_factory: Callable  # (width, length) -> Component
    via_metal_enclosure_add: float = 0.07  # um
    via_straighten_threshold_um: float = 3.0
    min_jog_coalesce_factor: float = 1.0

    @property
    def layer_m1(self) -> tuple[int, int]:
        """Return the first metal layer tuple."""
        return self.metal_layers[0].layer_tuple

    @property
    def layer_m2(self) -> tuple[int, int]:
        """Return the second metal layer tuple."""
        return self.metal_layers[1].layer_tuple

    def min_width(self, layer: tuple[int, int]) -> float:
        """Return minimum width for the given layer."""
        for spec in self.metal_layers:
            if spec.layer_tuple == layer:
                return spec.min_width
        return self.metal_layers[0].min_width

    def min_via_pad(self, layer: tuple[int, int]) -> float:
        """Return minimum via pad size for the given layer."""
        for spec in self.metal_layers:
            if spec.layer_tuple == layer:
                return spec.min_via_pad
        return self.metal_layers[0].min_via_pad

    def below_cut_layer(self, layer: tuple[int, int]) -> tuple[int, int] | None:
        """Return the cut layer below the given metal layer, if any."""
        for spec in self.metal_layers:
            if spec.layer_tuple == layer:
                return spec.below_cut_layer
        return None

    def layer_for_index(self, idx: int) -> tuple[int, int]:
        """Return the layer tuple at the given index."""
        return self.metal_layers[idx].layer_tuple

    def index_for_layer(self, layer: tuple[int, int]) -> int:
        """Return the index of the given layer tuple."""
        for i, spec in enumerate(self.metal_layers):
            if spec.layer_tuple == layer:
                return i
        return 0

    def min_width_any(self) -> float:
        """Return the smallest min_width across all layers."""
        return min(s.min_width for s in self.metal_layers)

    def min_via_pad_any(self) -> float:
        """Return the largest min_via_pad across all layers."""
        return max(s.min_via_pad for s in self.metal_layers)

    def layer_pitches_dbu(self, dbu: float) -> list[int]:
        """Track pitch per layer in DBU; fallback = min_width*2 + spacing."""
        result = []
        for spec in self.metal_layers:
            if spec.pitch is not None:
                result.append(int(round(spec.pitch / dbu)))
            else:
                spacing = spec.spacing if spec.spacing is not None else spec.min_width
                result.append(int(round((spec.min_width * 2 + spacing) / dbu)))
        return result

    def layer_widths_dbu(self, dbu: float) -> list[int]:
        """Min wire width per layer in DBU."""
        return [int(round(spec.min_width / dbu)) for spec in self.metal_layers]

    def layer_spacings_dbu(self, dbu: float) -> list[int]:
        """Min spacing per layer in DBU; fallback = min_width."""
        return [
            int(
                round(
                    (spec.spacing if spec.spacing is not None else spec.min_width) / dbu
                )
            )
            for spec in self.metal_layers
        ]

    def layer_directions(self) -> list[str]:
        """Preferred direction per layer as single-char strings."""
        return [spec.preferred_direction for spec in self.metal_layers]


@dataclass
class PortGeometry:
    """Geometry information extracted from a routing port."""

    width_x: float
    width_y: float
    bbox_dbu: tuple[int, int, int, int] | None
    dev_center_dbu: tuple[int, int] | None
    layer_tuple: tuple[int, int] | None
    below_cut_count: int
    orig_bbox_dbu: tuple[int, int, int, int] | None = None
    orig_min_extent_um: float = 0.0
    orig_extent_x_um: float = 0.0  # original polygon X extent (width)
    orig_extent_y_um: float = 0.0  # original polygon Y extent (height)

    @property
    def width(self) -> float:
        """Return the X-axis width."""
        return self.width_x

    @property
    def preferred_exit_direction(self) -> str | None:
        """'h' or 'v' — always exit along the port's longer side.

        Returns None only for effectively square ports (within 5% tolerance)
        or degenerate (zero-extent) ports.
        """
        if self.orig_extent_x_um <= 0 or self.orig_extent_y_um <= 0:
            return None
        aspect = max(self.orig_extent_x_um, self.orig_extent_y_um) / max(
            0.001, min(self.orig_extent_x_um, self.orig_extent_y_um)
        )
        if aspect <= 1.05:
            return None  # effectively square
        # Long axis = preferred exit direction
        # Wide port (X > Y) -> horizontal exit
        # Tall port (Y > X) -> vertical exit
        return "h" if self.orig_extent_x_um > self.orig_extent_y_um else "v"


@dataclass
class RouteResult:
    """Structured result from route_multilayer_3d()."""

    ports: list  # segment ports (empty on failure)
    success: bool
    failure_reason: str | None = None
    fallback_used: str | None = None


@dataclass(frozen=True)
class PinLabelSpec:
    """Label-only specification for an unrouted top-level pin.

    Used when a top-level pin is connected to a single device port and
    requires no routing — only a pin-layer label for LVS.
    """

    pin_name: str  # schematic pin name (becomes the label text)
    port: Any  # device Port to label


@dataclass(frozen=True)
class RouteNetSpec:
    """Single-net specification for deterministic multi-net routing."""

    name: str
    start: Any  # Port
    stop: Any  # Port
    port_name_prefix: str = "seg"
    is_top_level_pin: bool = False
