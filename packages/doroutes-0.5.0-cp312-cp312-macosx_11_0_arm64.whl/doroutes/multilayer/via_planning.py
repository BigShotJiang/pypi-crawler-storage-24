"""Via candidate generation, legality checks, pad sizing — config-dependent."""

from .config import RoutingConfig
from .geometry import _bbox_overlap, _via_envelope_um


def _via_pad_size_um(width_um: float, config: RoutingConfig) -> float:
    """Square via pad size used for M1<->M2 transitions."""
    return max(
        width_um,
        config.min_via_pad(config.layer_m1),
        config.min_via_pad(config.layer_m2),
    )


def _via_metal_footprint_um(via_pad_um: float, config: RoutingConfig) -> float:
    """Actual M1/M2 square metal footprint produced by via component."""
    return via_pad_um + float(config.via_metal_enclosure_add)


def _is_via_legal_on_both_layers(
    center_um: tuple[float, float],
    via_pad_um: float,
    m1_bboxes: list[tuple[float, float, float, float]],
    m2_bboxes: list[tuple[float, float, float, float]],
    config: RoutingConfig,
) -> bool:
    """True if via envelope at center is clear on both adjacent routing layers."""
    via_metal = _via_metal_footprint_um(via_pad_um, config)
    via_box = _via_envelope_um(center_um, via_metal, via_metal)
    if any(_bbox_overlap(via_box, obox) for obox in m1_bboxes):
        return False
    if any(_bbox_overlap(via_box, obox) for obox in m2_bboxes):
        return False
    return True


def _deterministic_via_candidate_centers(
    base_center_um: tuple[float, float],
    step_um: float,
    radius_um: float,
    max_candidates: int,
    dbu: float,
) -> list[tuple[float, float]]:
    """Generate stable nearby via centers around base point, snapped to DBU."""
    step = max(step_um, dbu)
    max_ring = max(0, int(round(radius_um / step)))
    centers: list[tuple[float, float]] = []
    seen = set()

    def _append(center: tuple[float, float]) -> None:
        key = (int(round(center[0] / dbu)), int(round(center[1] / dbu)))
        if key in seen:
            return
        seen.add(key)
        centers.append((key[0] * dbu, key[1] * dbu))

    _append(base_center_um)
    if len(centers) >= max_candidates:
        return centers

    for md in range(1, max_ring + 1):
        offsets = []
        for ix in range(-md, md + 1):
            iy_abs = md - abs(ix)
            if iy_abs == 0:
                offsets.append((ix, 0))
            else:
                offsets.append((ix, iy_abs))
                offsets.append((ix, -iy_abs))
        offsets = sorted(
            set(offsets),
            key=lambda p: (
                0 if (p[0] == 0 or p[1] == 0) else 1,
                0
                if (p[0] > 0 and p[1] == 0)
                else 1
                if (p[0] == 0 and p[1] > 0)
                else 2
                if (p[0] < 0 and p[1] == 0)
                else 3
                if (p[0] == 0 and p[1] < 0)
                else 4
                if (p[0] > 0 and p[1] > 0)
                else 5
                if (p[0] < 0 and p[1] > 0)
                else 6
                if (p[0] < 0 and p[1] < 0)
                else 7,
                abs(p[1]),
                abs(p[0]),
            ),
        )
        for ix, iy in offsets:
            _append(
                (
                    base_center_um[0] + ix * step,
                    base_center_um[1] + iy * step,
                )
            )
            if len(centers) >= max_candidates:
                return centers

    return centers


def _resolve_legal_via_center(
    base_center_um: tuple[float, float],
    via_pad_um: float,
    m1_bboxes: list[tuple[float, float, float, float]],
    m2_bboxes: list[tuple[float, float, float, float]],
    dbu: float,
    config: RoutingConfig,
    relocate_step_um: float = 0.14,
    relocate_radius_um: float = 1.0,
    max_candidates: int = 64,
    allow_relocate: bool = True,
) -> tuple[float, float] | None:
    """Return first legal via center (base first), else None."""
    if not allow_relocate:
        return (
            base_center_um
            if _is_via_legal_on_both_layers(
                base_center_um, via_pad_um, m1_bboxes, m2_bboxes, config
            )
            else None
        )
    for center in _deterministic_via_candidate_centers(
        base_center_um,
        step_um=relocate_step_um,
        radius_um=relocate_radius_um,
        max_candidates=max_candidates,
        dbu=dbu,
    ):
        if _is_via_legal_on_both_layers(
            center, via_pad_um, m1_bboxes, m2_bboxes, config
        ):
            return center
    return None


def _via_pad_candidates(target_pad_um: float, config: RoutingConfig) -> list[float]:
    """Deterministic descending via-pad fallback ladder down to minimum legal pad."""
    min_pad = _via_pad_size_um(0.0, config)
    target = max(min_pad, float(target_pad_um))
    vals = [target]
    for scale in (0.85, 0.70, 0.55, 0.40, 0.25):
        vals.append(max(min_pad, target * scale))
    vals.append(min_pad)
    out: list[float] = []
    for v in sorted(vals, reverse=True):
        if not out or abs(v - out[-1]) > 1e-6:
            out.append(v)
    return out
