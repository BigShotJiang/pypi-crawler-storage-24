"""Batch multi-net routing via Rust GRT+DRT — config-dependent."""

from collections.abc import Iterable, Sequence
from typing import Optional

import numpy as np
from gdsfactory.component import Component
from gdsfactory.typings import LayerSpec, Port

from .config import BatchRoutingParams, PortGeometry, RouteNetSpec, RoutingConfig
from .draw import (
    _draw_dynamic_geometry_for_corners,
)
from .obstacles import _extract_polys_for_layers
from .path import (
    _coalesce_via_jogs,
    _collapse_extended_via_detours,
    _collapse_ping_pong_transitions,
    _collapse_same_layer_staircases,
    _collapse_via_detours,
    _dedup_corners,
    _fix_non_manhattan_after_anchor,
    _force_endpoints,
    _force_port_exit_direction,
    _has_local_backtrack_corners,
    _is_manhattan_layered_path,
    _manhattanize_corners,
    _prune_redundant_jogs_corners,
    _remove_corner_on_segment_overlaps,
    _straighten_via_jogs,
)
from .port_analysis import _get_pos_with_dir

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_batch_nets(
    nets: Sequence[RouteNetSpec],
    config: RoutingConfig,
    dbu: float,
    geom_cache: dict[tuple[int, int], PortGeometry],
    width: float,
) -> tuple[
    list,
    dict[str, tuple],
]:
    """Convert RouteNetSpecs to the format expected by ``doroutes.route_batch()``.

    Returns:
        (batch_nets, net_meta) where:
        - batch_nets: list of (name, subnets) for route_batch()
        - net_meta: dict mapping net name to (start_xy_dbu, stop_xy_dbu,
          start_geom, stop_geom, orig_start_xy, orig_stop_xy) for post-processing

    """
    LAYER_M1 = config.layer_m1
    LAYER_M2 = config.layer_m2

    batch_nets = []
    net_meta: dict[str, tuple] = {}

    for net in nets:
        start_pos = _get_pos_with_dir(net.start, dbu)
        stop_pos = _get_pos_with_dir(net.stop, dbu)

        # Flip stop direction (same as engine_3d)
        stop_dir_map = {"n": "s", "s": "n", "e": "w", "w": "e", "o": "o"}
        stop_pos = (stop_pos[0], stop_pos[1], stop_dir_map[stop_pos[2]])

        start_key = (int(net.start.dcenter[0] / dbu), int(net.start.dcenter[1] / dbu))  # type: ignore[union-attr]
        stop_key = (int(net.stop.dcenter[0] / dbu), int(net.stop.dcenter[1] / dbu))  # type: ignore[union-attr]

        start_geom = geom_cache.get(start_key)
        stop_geom = geom_cache.get(stop_key)

        # Use squared bbox centers as routing coords (same as engine_3d)
        orig_start_x, orig_start_y = start_pos[0], start_pos[1]
        orig_stop_x, orig_stop_y = stop_pos[0], stop_pos[1]

        if start_geom and start_geom.dev_center_dbu is not None:
            start_x, start_y = start_geom.dev_center_dbu
        else:
            start_x, start_y = orig_start_x, orig_start_y

        if stop_geom and stop_geom.dev_center_dbu is not None:
            stop_x, stop_y = stop_geom.dev_center_dbu
        else:
            stop_x, stop_y = orig_stop_x, orig_stop_y

        # Determine layer indices
        def _get_layer_tuple_local(port, component):
            if hasattr(port, "layer"):
                info = component.kcl.get_info(port.layer)
                return (info.layer, info.datatype)
            return None

        # We pass c=None here — we need the component to determine layer.
        # Instead, infer from geom cache
        start_layer_idx = 0
        stop_layer_idx = 0
        if start_geom and start_geom.layer_tuple == LAYER_M2:
            start_layer_idx = 1
        if stop_geom and stop_geom.layer_tuple == LAYER_M2:
            stop_layer_idx = 1

        # Map direction strings for the Rust API
        start_dir = start_pos[2] if start_pos[2] != "o" else "none"
        stop_dir = stop_pos[2] if stop_pos[2] != "o" else "none"

        # Skip degenerate nets (same position, same layer)
        if (
            abs(start_x - stop_x) <= 1
            and abs(start_y - stop_y) <= 1
            and start_layer_idx == stop_layer_idx
        ):
            continue

        # Per-net wire half width from port geometry (matching serial router)
        if start_geom and stop_geom:
            net_width = max(
                config.min_width(LAYER_M1),
                min(start_geom.width, stop_geom.width),
            )
        else:
            net_width = max(config.min_width(LAYER_M1), width)
        whw_dbu = int(round(net_width / 2 / dbu))

        subnet = (
            start_x,
            start_y,
            start_layer_idx,
            start_dir,
            stop_x,
            stop_y,
            stop_layer_idx,
            stop_dir,
            whw_dbu,
        )
        batch_nets.append((net.name, [subnet]))

        # Store metadata for post-processing
        net_meta[net.name] = (
            (start_x, start_y),
            (stop_x, stop_y),
            start_geom,
            stop_geom,
            (orig_start_x, orig_start_y),
            (orig_stop_x, orig_stop_y),
        )

    return batch_nets, net_meta


def _build_batch_obstacles(
    kc,
    config: RoutingConfig,
    dbu: float,
    port_points: list[tuple[int, int]],
    port_bboxes: list[tuple[int, int, int, int]],
    clearance: float,
) -> list[list[np.ndarray]]:
    """Extract per-layer obstacle polygons for batch routing."""
    buffer_dbu = int(round(clearance / dbu))
    polys_per_layer = []
    for spec in config.metal_layers:
        polys = _extract_polys_for_layers(
            kc,
            [spec.layer_tuple],
            dbu,
            port_points,
            port_bboxes=port_bboxes,
            buffer_dbu=buffer_dbu,
        )
        polys_per_layer.append(polys)
    return polys_per_layer


def _tune_from_placement(
    params: BatchRoutingParams,
    placement_report: dict,
) -> BatchRoutingParams:
    """Adjust batch routing params based on placement metrics."""
    hpwl = placement_report.get("hpwl", 0)
    num_nets = len(placement_report.get("placements", {}))

    # Heuristic: more devices / higher HPWL → more routing iterations
    if num_nets >= 8:
        params.max_drt_iters = max(params.max_drt_iters, 50)
        params.gcell_size_um = min(params.gcell_size_um, 3.0)
    if hpwl > 50000:
        params.max_grt_iters = max(params.max_grt_iters, 80)

    return params


def _path_crosses_foreign_ports(
    corners_3d: list[tuple[int, int, int]],
    self_ports: list[tuple[int, int]],
    all_port_bboxes: list[tuple[int, int, int, int]],
    self_bboxes: list[tuple[int, int, int, int]],
    body_half_width_dbu: int,
    dbu: float,
) -> bool:
    """Check if any segment of a routed path crosses a non-self port bbox.

    A segment envelope (considering body_half_width) is checked against
    all port bboxes.  Port bboxes belonging to the current net (self_bboxes)
    are skipped.  Returns True if a foreign port overlap is detected.
    """
    margin = int(round(0.01 / dbu))  # 10nm tolerance

    # Build set of self bbox tuples for fast lookup
    self_set = set(self_bboxes)

    for i in range(len(corners_3d) - 1):
        x0, y0, z0 = corners_3d[i]
        x1, y1, z1 = corners_3d[i + 1]
        if z0 != z1:
            continue  # via transitions, skip

        # Only check M1 (layer 0) segments — M2 is above ports
        if z0 != 0:
            continue

        # Compute segment envelope in dbu
        hw = body_half_width_dbu
        seg_left = min(x0, x1) - hw
        seg_right = max(x0, x1) + hw
        seg_bottom = min(y0, y1) - hw
        seg_top = max(y0, y1) + hw

        for bbox in all_port_bboxes:
            if bbox in self_set:
                continue
            bl, bb, br, bt = bbox
            # Check overlap (with margin)
            if (
                seg_right > bl + margin
                and seg_left < br - margin
                and seg_top > bb + margin
                and seg_bottom < bt - margin
            ):
                return True

    return False


def _cleanup_corners(
    corners_3d: list[tuple[int, int, int]],
    start_xy: tuple[int, int],
    stop_xy: tuple[int, int],
    config: RoutingConfig,
    grid_unit_dbu: int,
    dbu: float,
    start_geom: Optional["PortGeometry"] = None,
    stop_geom: Optional["PortGeometry"] = None,
) -> list[tuple[int, int, int]] | None:
    """Run the 10-pass path cleanup pipeline on corners.

    Returns cleaned corners or None if path collapses.
    """
    min_jog_dbu = int(config.min_jog_coalesce_factor * grid_unit_dbu)
    h_layers = {
        i
        for i, spec in enumerate(config.metal_layers)
        if spec.preferred_direction == "h"
    }
    max_np_dbu = (
        2 * grid_unit_dbu
    )  # collapse non-preferred via round-trips up to 2 grid cells

    corners_3d = _manhattanize_corners(corners_3d)
    corners_3d = _straighten_via_jogs(
        corners_3d, dbu, config.via_straighten_threshold_um
    )
    corners_3d = _coalesce_via_jogs(corners_3d, min_jog_dbu)
    corners_3d = _dedup_corners(corners_3d)
    corners_3d = _collapse_via_detours(
        corners_3d,
        preferred_horizontal_layers=h_layers,
        max_non_preferred_dbu=max_np_dbu,
    )
    corners_3d = _collapse_extended_via_detours(
        corners_3d,
        preferred_horizontal_layers=h_layers,
        max_non_preferred_dbu=max_np_dbu,
    )
    corners_3d = _collapse_same_layer_staircases(corners_3d)
    corners_3d = _remove_corner_on_segment_overlaps(corners_3d)
    corners_3d = _collapse_ping_pong_transitions(corners_3d, protect_endpoints=True)
    protected = {0, len(corners_3d) - 1} if len(corners_3d) >= 2 else set()
    corners_3d = _prune_redundant_jogs_corners(corners_3d, protected_indices=protected)
    corners_3d = _dedup_corners(corners_3d)
    corners_3d = _force_endpoints(corners_3d, start_xy, stop_xy)
    corners_3d = _fix_non_manhattan_after_anchor(corners_3d)
    if start_geom is not None and stop_geom is not None:
        pre_force_corners = list(corners_3d)
        corners_3d = _force_port_exit_direction(corners_3d, start_geom, stop_geom, dbu)
        # Post-force cleanup: collapse collinear/zero-length artifacts
        corners_3d = _prune_redundant_jogs_corners(
            corners_3d, protected_indices={0, len(corners_3d) - 1}
        )
        corners_3d = _remove_corner_on_segment_overlaps(corners_3d)
        corners_3d = _dedup_corners(corners_3d)
        if _has_local_backtrack_corners(corners_3d):
            corners_3d = pre_force_corners

    if len(corners_3d) < 2:
        return None

    if (corners_3d[0][0], corners_3d[0][1]) != (start_xy[0], start_xy[1]):
        return None
    if (corners_3d[-1][0], corners_3d[-1][1]) != (stop_xy[0], stop_xy[1]):
        return None

    if not _is_manhattan_layered_path(corners_3d):
        return None

    return corners_3d


# ---------------------------------------------------------------------------
# Main batch routing entry point
# ---------------------------------------------------------------------------


def route_batch_multilayer(
    c: Component,
    nets: Sequence[RouteNetSpec],
    config: RoutingConfig,
    grid_unit: float = 1.0,
    width: float = 0.25,
    dynamic_width: bool = True,
    layers_to_avoid: Iterable[LayerSpec] | None = None,
    add_segment_ports: bool = True,
    via_cost: float = 10.0,
    wrong_way_penalty: float = 8.0,
    clearance: float = 0.14,
    batch_params: BatchRoutingParams | None = None,
    geom_cache: dict[tuple[int, int], PortGeometry] | None = None,
    all_port_bboxes: list[tuple[int, int, int, int]] | None = None,
    placement_report: dict | None = None,
    debug: bool = False,
) -> tuple[dict[str, list[Port]], list[str], dict[str, list[tuple[int, int, int]]]]:
    """Route all nets simultaneously using Rust GRT+DRT batch router.

    Returns:
        (routed_ports_by_net, failed_net_names, corners_by_net)
        where corners_by_net maps net name to cleaned corner paths.

    """
    from doroutes import doroutes as _doroutes  # type: ignore[attr-defined]

    if layers_to_avoid is None:
        layers_to_avoid = []
    if not nets:
        return {}, [], {}

    params = batch_params or BatchRoutingParams()
    if placement_report is not None:
        params = _tune_from_placement(params, placement_report)

    dbu = c.kcl.dbu
    kc = c.kcl.kcells[c.name]
    grid_unit_dbu = int(grid_unit / dbu)

    # 1. Build net data
    batch_nets, net_meta = _build_batch_nets(nets, config, dbu, geom_cache or {}, width)

    if not batch_nets:
        print("[BATCH] No routable nets after filtering degenerates")
        return {}, [n.name for n in nets], {}

    # 2. Collect all port points for obstacle exclusion
    port_points = []
    for net_name, meta in net_meta.items():
        start_xy, stop_xy = meta[0], meta[1]
        port_points.append(start_xy)
        port_points.append(stop_xy)

    # 3. Build obstacles
    polys_per_layer = _build_batch_obstacles(
        kc,
        config,
        dbu,
        port_points,
        all_port_bboxes or [],
        clearance,
    )
    obs_counts = [len(p) for p in polys_per_layer]
    print(f"[BATCH] Obstacles per layer: {obs_counts}")

    # 4. Compute bounding box (union of component + all ports + padding)
    comp_bbox = kc.bbox()
    all_xs = [comp_bbox.left, comp_bbox.right]
    all_ys = [comp_bbox.bottom, comp_bbox.top]
    for (sx, sy), (ex, ey), *_ in net_meta.values():
        all_xs.extend([sx, ex])
        all_ys.extend([sy, ey])

    padding_dbu = int(round(10.0 / dbu))  # 10um padding
    min_x = min(all_xs) - padding_dbu
    max_x = max(all_xs) + padding_dbu
    min_y = min(all_ys) - padding_dbu
    max_y = max(all_ys) + padding_dbu
    bbox_tuple = (max_y, max_x, min_y, min_x)

    # 5. Layer params
    layer_directions = config.layer_directions()
    layer_pitches = config.layer_pitches_dbu(dbu)
    layer_widths = config.layer_widths_dbu(dbu)
    layer_spacings = config.layer_spacings_dbu(dbu)
    gcell_size_dbu = int(round(params.gcell_size_um / dbu))
    wire_half_width_dbu = (
        int(round(max(config.min_width(config.layer_m1), width) / 2 / dbu))
        if dynamic_width
        else 0
    )

    print(f"[BATCH] Routing {len(batch_nets)} nets via GRT+DRT")
    print(
        f"[BATCH] BBox: ({min_x * dbu:.1f}, {min_y * dbu:.1f}) -> ({max_x * dbu:.1f}, {max_y * dbu:.1f})"
    )
    print(
        f"[BATCH] GCell={params.gcell_size_um}um  GRT_iters={params.max_grt_iters}  DRT_iters={params.max_drt_iters}"
    )

    # 6. Call Rust batch router
    try:
        results = _doroutes.route_batch(
            polys_per_layer=polys_per_layer,
            nets=batch_nets,
            bbox=bbox_tuple,
            grid_unit=grid_unit_dbu,
            layer_directions=layer_directions,
            layer_pitches=layer_pitches,
            layer_widths=layer_widths,
            layer_spacings=layer_spacings,
            gcell_size=gcell_size_dbu,
            max_grt_iters=params.max_grt_iters,
            max_drt_iters=params.max_drt_iters,
            via_cost=via_cost,
            wrong_way_penalty=wrong_way_penalty,
            wire_half_width=wire_half_width_dbu,
        )
    except Exception as e:
        print(f"[BATCH] Rust route_batch() failed: {e}")
        return {}, [n.name for n in nets], {}

    # 7. Post-process each net result
    routed_ports: dict[str, list[Port]] = {}
    failed_names: list[str] = []
    corners_by_net: dict[str, list[tuple[int, int, int]]] = {}

    # We need per-layer obstacle polys for drawing validation.
    # Re-extract after each net draw so newly placed metal is visible as
    # obstacles for subsequent nets (prevents inter-net shorts).
    buffer_dbu = int(round(clearance / dbu))

    def _refresh_draw_polys():
        """Extract fresh per-layer obstacle polygons from the current layout."""
        fresh = []
        for spec in config.metal_layers:
            polys = _extract_polys_for_layers(
                kc,
                [spec.layer_tuple],
                dbu,
                port_points,
                port_bboxes=all_port_bboxes or [],
                buffer_dbu=buffer_dbu,
            )
            fresh.append(polys)
        return fresh

    draw_polys_per_layer = _refresh_draw_polys()

    # Build per-net port bboxes for cross-net overlap checking.
    # Uses orig_bbox_dbu (unsquared) so the check matches actual metal.
    _net_self_bboxes: dict[str, list[tuple[int, int, int, int]]] = {}
    for _nn, _meta in net_meta.items():
        _s_geom, _e_geom = _meta[2], _meta[3]
        _bbs: list[tuple[int, int, int, int]] = []
        for _pg in (_s_geom, _e_geom):
            if _pg is not None:
                _bb = (
                    _pg.orig_bbox_dbu if _pg.orig_bbox_dbu is not None else _pg.bbox_dbu
                )
                if _bb is not None:
                    _bbs.append(_bb)
        _net_self_bboxes[_nn] = _bbs

    # Build extra port points for obstacle exclusion during drawing
    extra_port_pts_um = None
    if all_port_bboxes:
        extra_port_pts_um = []
        for epb in all_port_bboxes:
            cx = (epb[0] + epb[2]) / 2.0 * dbu
            cy = (epb[1] + epb[3]) / 2.0 * dbu
            extra_port_pts_um.append((cx, cy))

    for net_name, corners_raw, num_vias in results:
        if not corners_raw:
            print(f"[BATCH] Net '{net_name}' failed (no path found)")
            failed_names.append(net_name)
            continue

        corners_3d = [(x, y, z) for (x, y, z) in corners_raw]
        meta = net_meta.get(net_name)
        if meta is None:
            print(f"[BATCH] Net '{net_name}' missing metadata, skipping")
            failed_names.append(net_name)
            continue

        start_xy, stop_xy, start_geom, stop_geom, orig_start_xy, orig_stop_xy = meta

        print(f"[BATCH] Net '{net_name}': {len(corners_3d)} corners, {num_vias} vias")

        # Path cleanup
        cleaned = _cleanup_corners(
            corners_3d,
            start_xy,
            stop_xy,
            config,
            grid_unit_dbu,
            dbu,
            start_geom=start_geom,
            stop_geom=stop_geom,
        )
        if cleaned is None:
            print(f"[BATCH] Net '{net_name}' collapsed after cleanup")
            failed_names.append(net_name)
            continue

        corners_3d = cleaned
        corners_by_net[net_name] = corners_3d

        # Check if the batch-routed path crosses any non-self port pad.
        # The batch router excludes ALL port pads from its obstacles, so it
        # can produce paths that physically cross other nets' port metal.
        # Reject such paths early and let the serial fallback re-route them.
        if all_port_bboxes:
            body_hw_dbu = int(
                round(max(config.min_width(config.layer_m1), width) / 2 / dbu)
            )
            self_bbs = _net_self_bboxes.get(net_name, [])
            if _path_crosses_foreign_ports(
                corners_3d,
                [start_xy, stop_xy],
                all_port_bboxes,
                self_bbs,
                body_hw_dbu,
                dbu,
            ):
                print(
                    f"[BATCH] Net '{net_name}' path crosses foreign port, deferring to serial"
                )
                failed_names.append(net_name)
                continue

        # Use default geom if None
        if start_geom is None:
            start_geom = PortGeometry(
                width,
                width,
                None,
                None,
                None,
                0,
                orig_min_extent_um=width,
                orig_extent_x_um=width,
                orig_extent_y_um=width,
            )
        if stop_geom is None:
            stop_geom = PortGeometry(
                width,
                width,
                None,
                None,
                None,
                0,
                orig_min_extent_um=width,
                orig_extent_x_um=width,
                orig_extent_y_um=width,
            )

        body_width = max(config.min_width(config.layer_m1), width)

        # Draw using existing pipeline
        dyn_ports = _draw_dynamic_geometry_for_corners(
            c=c,
            corners_3d=corners_3d,
            start_geom=start_geom,
            stop_geom=stop_geom,
            body_width=body_width,
            width=width,
            dynamic_width=dynamic_width,
            m1_polys=draw_polys_per_layer[0] if len(draw_polys_per_layer) > 0 else [],
            m2_polys=draw_polys_per_layer[1] if len(draw_polys_per_layer) > 1 else [],
            start_xy_dbu=orig_start_xy,
            stop_xy_dbu=orig_stop_xy,
            dbu=dbu,
            clearance=clearance,
            add_segment_ports=_find_net_is_top_level_pin(nets, net_name),
            port_name_prefix=_find_net_prefix(nets, net_name),
            config=config,
            debug=debug,
            extra_port_points_um=extra_port_pts_um,
        )

        if dyn_ports is not None:
            routed_ports[net_name] = dyn_ports
            # Refresh obstacles so the next net sees this net's metal
            draw_polys_per_layer = _refresh_draw_polys()
            print(f"[BATCH] Net '{net_name}' drawn successfully")
        else:
            print(f"[BATCH] Net '{net_name}' geometry blocked during drawing")
            failed_names.append(net_name)

    succeeded = len(routed_ports)
    failed = len(failed_names)
    print(
        f"[BATCH] Results: {succeeded} succeeded, {failed} failed out of {len(batch_nets)} nets"
    )

    return routed_ports, failed_names, corners_by_net


def _find_net_prefix(nets: Sequence[RouteNetSpec], name: str) -> str:
    """Find port_name_prefix for a net by name."""
    for net in nets:
        if net.name == name:
            return net.port_name_prefix
    return "seg"


def _find_net_is_top_level_pin(nets: Sequence[RouteNetSpec], name: str) -> bool:
    """Find is_top_level_pin for a net by name."""
    for net in nets:
        if net.name == name:
            return net.is_top_level_pin
    return False
