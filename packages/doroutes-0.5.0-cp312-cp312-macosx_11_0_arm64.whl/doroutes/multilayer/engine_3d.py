"""Main 3D multi-layer A* router — config-dependent."""

from collections.abc import Iterable
from typing import Optional

from gdsfactory.component import Component
from gdsfactory.typings import LayerSpec, Port

from .config import PortGeometry, RouteResult, RoutingConfig
from .draw import (
    _draw_dynamic_geometry_for_corners,
)
from .engine_hierarchical import _deterministic_clearance_attempts
from .obstacles import _extract_polys_for_layers
from .path import (
    _coalesce_via_jogs,
    _collapse_extended_via_detours,
    _collapse_ping_pong_transitions,
    _collapse_same_layer_staircases,
    _collapse_via_detours,
    _dedup_corners,
    _fix_non_manhattan_after_anchor,
    _force_endpoints,
    _force_port_exit_direction,
    _has_local_backtrack_corners,
    _is_manhattan_layered_path,
    _manhattanize_corners,
    _prune_redundant_jogs_corners,
    _remove_corner_on_segment_overlaps,
    _straighten_via_jogs,
)
from .port_analysis import (
    _get_port_geometry,
    _get_pos_with_dir,
    _selected_straight_width,
)


def route_multilayer_3d(
    c: Component,
    start: Port,
    stop: Port,
    config: RoutingConfig,
    grid_unit: float = 1.0,
    width: float = 0.25,
    dynamic_width: bool = True,
    layers_to_avoid: Iterable[LayerSpec] | None = None,
    add_segment_ports: bool = False,
    port_name_prefix: str = "seg",
    via_cost: float = 10.0,
    wrong_way_penalty: float = 8.0,
    clearance: float = 0.14,
    clearance_ladder: tuple[float, ...] = (0.14, 0.10, 0.07),
    deterministic: bool = True,
    debug: bool = False,
    extra_port_bboxes: list[tuple[int, int, int, int]] | None = None,
    cached_start_geom: Optional["PortGeometry"] = None,
    cached_stop_geom: Optional["PortGeometry"] = None,
) -> RouteResult:
    """Route using the 3D multi-layer A* router."""
    from doroutes import doroutes as _doroutes  # type: ignore[attr-defined]

    # Avoid circular import at module level
    from .engine_hierarchical import route_hierarchical

    LAYER_M1 = config.layer_m1
    LAYER_M2 = config.layer_m2

    if layers_to_avoid is None:
        layers_to_avoid = []

    dbu = c.kcl.dbu
    kc = c.kcl.kcells[c.name]

    _layers = [
        layer if isinstance(layer, tuple) else (layer, 0) for layer in layers_to_avoid
    ]

    start_pos = _get_pos_with_dir(start, dbu)
    stop_pos = _get_pos_with_dir(stop, dbu)

    start_geom = cached_start_geom or _get_port_geometry(
        start, kc, dbu, config, default_width=width
    )
    stop_geom = cached_stop_geom or _get_port_geometry(
        stop, kc, dbu, config, default_width=width
    )

    if debug:
        for _dbg_geom, _dbg_label in [
            (start_geom, "START"),
            (stop_geom, "STOP"),
        ]:
            if _dbg_geom.layer_tuple is not None:
                if _dbg_geom.orig_bbox_dbu is not None:
                    _ol, _ob, _or_, _ot = _dbg_geom.orig_bbox_dbu
                    print(
                        f"[DEBUG] {_dbg_label} fill (orig bbox): "
                        f"({_ol * dbu:.3f}, {_ob * dbu:.3f}) -> ({_or_ * dbu:.3f}, {_ot * dbu:.3f})  "
                        f"size={(_or_ - _ol) * dbu:.3f}x{(_ot - _ob) * dbu:.3f}um"
                    )
                if _dbg_geom.bbox_dbu is not None:
                    _sl, _sb, _sr, _st = _dbg_geom.bbox_dbu
                    print(
                        f"[DEBUG] {_dbg_label} squared bbox:    "
                        f"({_sl * dbu:.3f}, {_sb * dbu:.3f}) -> ({_sr * dbu:.3f}, {_st * dbu:.3f})  "
                        f"size={(_sr - _sl) * dbu:.3f}x{(_st - _sb) * dbu:.3f}um  "
                        f"width={_dbg_geom.width:.3f}um"
                    )
        _dbg_copy = c.dup()
        _dbg_copy.flatten()
        _dbg_copy.show()
        input(
            "[DEBUG] Port fills (orig bbox) + widened endpoint segments. Press Enter to continue routing..."
        )

    selected_straight_width = _selected_straight_width(
        start_geom, stop_geom, width, config
    )
    if dynamic_width:
        start_width = max(width, start_geom.width)
        stop_width = max(width, stop_geom.width)
        body_width = max(config.min_width(LAYER_M1), width)
    else:
        start_width = width
        stop_width = width
        body_width = width

    stop_dir_map = {"n": "s", "s": "n", "e": "w", "w": "e", "o": "o"}
    stop_pos = (stop_pos[0], stop_pos[1], stop_dir_map[stop_pos[2]])

    # Use squared bbox centers as routing coordinates
    orig_start_x, orig_start_y = start_pos[0], start_pos[1]
    orig_stop_x, orig_stop_y = stop_pos[0], stop_pos[1]
    if start_geom.dev_center_dbu is not None:
        start_x, start_y = start_geom.dev_center_dbu
    else:
        start_x, start_y = orig_start_x, orig_start_y
    if stop_geom.dev_center_dbu is not None:
        stop_x, stop_y = stop_geom.dev_center_dbu
    else:
        stop_x, stop_y = orig_stop_x, orig_stop_y

    port_points = [
        (start_x, start_y),
        (stop_x, stop_y),
    ]

    port_bboxes = []
    for geom in (start_geom, stop_geom):
        if geom.bbox_dbu is not None:
            port_bboxes.append(geom.bbox_dbu)
    if extra_port_bboxes:
        port_bboxes.extend(extra_port_bboxes)

    def _get_layer_tuple_local(port, component):
        if hasattr(port, "layer"):
            layer_idx = port.layer
            info = component.kcl.get_info(layer_idx)
            return (info.layer, info.datatype)
        return None

    start_layer_idx = 0
    stop_layer_idx = 0

    start_layer = _get_layer_tuple_local(start, c)
    stop_layer = _get_layer_tuple_local(stop, c)

    if start_layer == LAYER_M2:
        start_layer_idx = 1
    if stop_layer == LAYER_M2:
        stop_layer_idx = 1

    # --- Degenerate case: same position, same layer ---
    if abs(start_x - stop_x) <= 1 and abs(start_y - stop_y) <= 1:
        if start_layer_idx == stop_layer_idx:
            return RouteResult(ports=[], success=True)

    def _fallback_hierarchical(failure_reason: str = "unknown") -> RouteResult:
        ports = route_hierarchical(
            c,
            start,
            stop,
            config=config,
            global_grid_unit=grid_unit * 2,
            detail_grid_unit=grid_unit,
            width=width,
            dynamic_width=dynamic_width,
            layers_to_avoid=layers_to_avoid,
            clearance=clearance,
            clearance_ladder=clearance_ladder,
            deterministic=deterministic,
            add_segment_ports=add_segment_ports,
            port_name_prefix=port_name_prefix,
            start_xy_override_um=(start_x * dbu, start_y * dbu),
            stop_xy_override_um=(stop_x * dbu, stop_y * dbu),
            port_exclusion_points_um=[
                (orig_start_x * dbu, orig_start_y * dbu),
                (orig_stop_x * dbu, orig_stop_y * dbu),
            ],
        )
        return RouteResult(
            ports=ports,
            success=len(ports) > 0 or True,  # hierarchical always "succeeds" in drawing
            failure_reason=failure_reason,
            fallback_used="hierarchical",
        )

    dist = max(abs(stop_x - start_x), abs(stop_y - start_y))
    padding = int(dist * 0.5)

    comp_bbox = kc.bbox()
    min_x = min(start_x, stop_x, comp_bbox.left) - padding
    max_x = max(start_x, stop_x, comp_bbox.right) + padding
    min_y = min(start_y, stop_y, comp_bbox.bottom) - padding
    max_y = max(start_y, stop_y, comp_bbox.top) + padding

    bbox_tuple = (max_y, max_x, min_y, min_x)

    grid_unit_dbu = int(grid_unit / dbu)

    # Ensure minimum grid dimensions
    grid_w = max(2, (max_x - min_x) // grid_unit_dbu)
    grid_h = max(2, (max_y - min_y) // grid_unit_dbu)

    start_3d = (start_x, start_y, start_layer_idx, start_pos[2])
    stop_3d = (stop_x, stop_y, stop_layer_idx, stop_pos[2])

    print(
        f"[3D ROUTE] Grid: {grid_w}x{grid_h} x 2 layers = {grid_w * grid_h * 2} cells"
    )
    print(
        f"[3D ROUTE] from ({start_x * dbu:.3f}, {start_y * dbu:.3f}, L{start_layer_idx}) "
        f"to ({stop_x * dbu:.3f}, {stop_y * dbu:.3f}, L{stop_layer_idx})"
    )
    print(
        f"[3D ROUTE] BBox: ({min_x * dbu:.1f}, {min_y * dbu:.1f}) -> ({max_x * dbu:.1f}, {max_y * dbu:.1f})"
    )
    print(
        f"[3D ROUTE] widths dynamic={dynamic_width} "
        f"start={start_width:.3f}um body={body_width:.3f}um stop={stop_width:.3f}um "
        f"selected_straight={selected_straight_width:.3f}um"
    )

    wire_half_width_dbu = int(body_width / 2 / dbu) if dynamic_width else 0

    def _show_3d_with_width(bbox_value, grid_unit_value, polys_per_layer):
        kwargs = dict(
            polys_per_layer=polys_per_layer,
            start=start_3d,
            stop=stop_3d,
            bbox=bbox_value,
            grid_unit=grid_unit_value,
            layer_directions=["h", "v"],
            via_cost=via_cost,
            wrong_way_penalty=wrong_way_penalty,
        )
        if dynamic_width and wire_half_width_dbu > 0:
            kwargs["wire_half_width"] = wire_half_width_dbu
            try:
                return _doroutes.show_3d(**kwargs)
            except TypeError:
                kwargs.pop("wire_half_width", None)
        return _doroutes.show_3d(**kwargs)

    clearance_attempts = (
        _deterministic_clearance_attempts(clearance, clearance_ladder)
        if deterministic
        else [max(0.0, clearance)]
    )

    corners_3d = None
    num_vias = 0
    last_error: Exception | None = None
    clearance_um = clearance
    m1_polys: list = []
    m2_polys: list = []

    for clearance_um in clearance_attempts:
        buffer_dbu = int(round(clearance_um / dbu))
        m1_polys = (
            _extract_polys_for_layers(
                kc,
                [LAYER_M1],
                dbu,
                port_points,
                port_bboxes=port_bboxes,
                buffer_dbu=buffer_dbu,
            )
            if LAYER_M1 in _layers
            else []
        )
        m2_polys = (
            _extract_polys_for_layers(
                kc,
                [LAYER_M2],
                dbu,
                port_points,
                port_bboxes=port_bboxes,
                buffer_dbu=buffer_dbu,
            )
            if LAYER_M2 in _layers
            else []
        )
        polys_per_layer = [m1_polys, m2_polys]
        print(
            f"[3D ROUTE] Obstructions@{clearance_um:.3f}um: M1={len(m1_polys)}, M2={len(m2_polys)}"
        )

        try:
            corners_3d, num_vias = _show_3d_with_width(
                bbox_tuple, grid_unit_dbu, polys_per_layer
            )
            print(f"[3D ROUTE] clearance={clearance_um:.3f}um succeeded")
            break
        except Exception as e:
            last_error = e
            print(f"[3D ROUTE] clearance={clearance_um:.3f}um failed: {e}")
            print(
                "[3D ROUTE] Retrying this clearance with expanded bbox and finer grid..."
            )
            try:
                retry_min_x = min_x - padding
                retry_max_x = max_x + padding
                retry_min_y = min_y - padding
                retry_max_y = max_y + padding
                retry_bbox = (retry_max_y, retry_max_x, retry_min_y, retry_min_x)

                retry_grid_unit = grid_unit * 0.5
                retry_grid_unit_dbu = int(retry_grid_unit / dbu)
                r_grid_w = (retry_max_x - retry_min_x) // retry_grid_unit_dbu
                r_grid_h = (retry_max_y - retry_min_y) // retry_grid_unit_dbu
                print(f"[3D ROUTE RETRY] Grid: {r_grid_w}x{r_grid_h} x 2 layers")

                corners_3d, num_vias = _show_3d_with_width(
                    retry_bbox, retry_grid_unit_dbu, polys_per_layer
                )
                print(f"[3D ROUTE] clearance={clearance_um:.3f}um succeeded on retry")
                break
            except Exception as e2:
                last_error = e2
                print(f"[3D ROUTE] clearance={clearance_um:.3f}um retry failed: {e2}")

    if corners_3d is None:
        print(f"[3D ROUTE] All clearance attempts failed: {clearance_attempts}")
        if last_error is not None:
            print(f"[3D ROUTE] Last error: {last_error}")
        print("[3D ROUTE] Falling back to hierarchical router...")
        return _fallback_hierarchical(failure_reason="rust_no_path")

    # If pathfinding succeeded with reduced clearance, re-extract obstacles
    # at DRC-legal clearance for drawing validation.
    if clearance_um < clearance:
        drc_buffer = int(round(clearance / dbu))
        m1_polys = (
            _extract_polys_for_layers(
                kc,
                [LAYER_M1],
                dbu,
                port_points,
                port_bboxes=port_bboxes,
                buffer_dbu=drc_buffer,
            )
            if LAYER_M1 in _layers
            else []
        )
        m2_polys = (
            _extract_polys_for_layers(
                kc,
                [LAYER_M2],
                dbu,
                port_points,
                port_bboxes=port_bboxes,
                buffer_dbu=drc_buffer,
            )
            if LAYER_M2 in _layers
            else []
        )
        print(
            f"[3D ROUTE] Re-extracted obstacles at DRC clearance {clearance:.3f}um for drawing validation"
        )

    print(f"[3D ROUTE] Found path with {len(corners_3d)} corners, {num_vias} vias")

    # --- Path cleanup pipeline ---
    min_jog_dbu = int(config.min_jog_coalesce_factor * grid_unit_dbu)
    h_layers = {
        i
        for i, spec in enumerate(config.metal_layers)
        if spec.preferred_direction == "h"
    }
    max_np_dbu = (
        2 * grid_unit_dbu
    )  # collapse non-preferred via round-trips up to 2 grid cells

    corners_3d = _manhattanize_corners(corners_3d)
    corners_3d = _straighten_via_jogs(
        corners_3d, dbu, config.via_straighten_threshold_um
    )
    corners_3d = _coalesce_via_jogs(corners_3d, min_jog_dbu)
    corners_3d = _dedup_corners(corners_3d)

    pre_collapse_vias = sum(
        1
        for i in range(len(corners_3d) - 1)
        if corners_3d[i][2] != corners_3d[i + 1][2]
    )
    corners_3d = _collapse_via_detours(
        corners_3d,
        preferred_horizontal_layers=h_layers,
        max_non_preferred_dbu=max_np_dbu,
    )
    corners_3d = _collapse_extended_via_detours(
        corners_3d,
        preferred_horizontal_layers=h_layers,
        max_non_preferred_dbu=max_np_dbu,
    )
    post_collapse_vias = sum(
        1
        for i in range(len(corners_3d) - 1)
        if corners_3d[i][2] != corners_3d[i + 1][2]
    )
    if post_collapse_vias < pre_collapse_vias:
        print(
            f"[3D ROUTE] Via detour collapse: {pre_collapse_vias} → {post_collapse_vias} transitions"
        )

    corners_3d = _collapse_same_layer_staircases(corners_3d)
    corners_3d = _remove_corner_on_segment_overlaps(corners_3d)
    corners_3d = _collapse_ping_pong_transitions(corners_3d, protect_endpoints=True)
    protected = {0, len(corners_3d) - 1} if len(corners_3d) >= 2 else set()
    corners_3d = _prune_redundant_jogs_corners(corners_3d, protected_indices=protected)
    corners_3d = _dedup_corners(corners_3d)
    corners_3d = _force_endpoints(corners_3d, (start_x, start_y), (stop_x, stop_y))
    corners_3d = _fix_non_manhattan_after_anchor(corners_3d)
    pre_force_corners = list(corners_3d)
    corners_3d = _force_port_exit_direction(corners_3d, start_geom, stop_geom, dbu)
    # Post-force cleanup: collapse collinear/zero-length artifacts
    corners_3d = _prune_redundant_jogs_corners(
        corners_3d, protected_indices={0, len(corners_3d) - 1}
    )
    corners_3d = _remove_corner_on_segment_overlaps(corners_3d)
    corners_3d = _dedup_corners(corners_3d)
    if _has_local_backtrack_corners(corners_3d):
        corners_3d = pre_force_corners

    if len(corners_3d) < 2:
        print(
            "[3D ROUTE] Path collapsed after cleanup; falling back to hierarchical router..."
        )
        return _fallback_hierarchical(failure_reason="path_collapsed")

    if (corners_3d[0][0], corners_3d[0][1]) != (start_x, start_y) or (
        corners_3d[-1][0],
        corners_3d[-1][1],
    ) != (stop_x, stop_y):
        print(
            "[3D ROUTE] Endpoint anchoring failed after cleanup; falling back to hierarchical router..."
        )
        return _fallback_hierarchical(failure_reason="path_collapsed")

    if not _is_manhattan_layered_path(corners_3d):
        print(
            "[3D ROUTE] Non-manhattan same-layer segment after cleanup; falling back to hierarchical router..."
        )
        return _fallback_hierarchical(failure_reason="non_manhattan")

    # Debug: print final path
    print(f"[3D ROUTE] Final path ({len(corners_3d)} corners):")
    for idx, (cx, cy, cz) in enumerate(corners_3d):
        print(
            f"  [{idx}] ({cx * dbu:.3f}, {cy * dbu:.3f}) L{cz} ({'M1' if cz == 0 else 'M2'})"
        )

    # Build extra port points (um) for obstacle exclusion from extra_port_bboxes
    _extra_port_pts_um = None
    if extra_port_bboxes:
        _extra_port_pts_um = []
        for _epb in extra_port_bboxes:
            _cx = (_epb[0] + _epb[2]) / 2.0 * dbu
            _cy = (_epb[1] + _epb[3]) / 2.0 * dbu
            _extra_port_pts_um.append((_cx, _cy))

    # Unified drawing path (handles both dynamic_width=True and False)
    dyn_ports = _draw_dynamic_geometry_for_corners(
        c=c,
        corners_3d=corners_3d,
        start_geom=start_geom,
        stop_geom=stop_geom,
        body_width=body_width,
        width=width,
        dynamic_width=dynamic_width,
        m1_polys=m1_polys,
        m2_polys=m2_polys,
        start_xy_dbu=(orig_start_x, orig_start_y),
        stop_xy_dbu=(orig_stop_x, orig_stop_y),
        dbu=dbu,
        clearance=clearance,
        add_segment_ports=add_segment_ports,
        port_name_prefix=port_name_prefix,
        config=config,
        debug=debug,
        extra_port_points_um=_extra_port_pts_um,
    )
    if dyn_ports is not None:
        return RouteResult(ports=dyn_ports, success=True)
    print(
        "[3D ROUTE] Planned geometry violates obstruction clearance; falling back to hierarchical router..."
    )
    return _fallback_hierarchical(failure_reason="geometry_blocked")
