"""Pure geometry utilities — zero PDK references."""


def _bbox_overlap(
    a: tuple[float, float, float, float], b: tuple[float, float, float, float]
) -> bool:
    """Axis-aligned bbox overlap check."""
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    return ax0 < bx1 and ax1 > bx0 and ay0 < by1 and ay1 > by0


def _segment_envelope_um(
    p1: tuple[float, float],
    p2: tuple[float, float],
    width_um: float,
) -> tuple[float, float, float, float]:
    """Rectangular envelope for a Manhattan segment with finite width.

    For horizontal segments the width expands the y-axis only;
    for vertical segments it expands the x-axis only.
    """
    half = max(0.0, width_um / 2.0)
    x0, y0 = p1
    x1, y1 = p2
    is_horiz = abs(y1 - y0) < 0.001
    is_vert = abs(x1 - x0) < 0.001
    if is_horiz:
        return (min(x0, x1), min(y0, y1) - half, max(x0, x1), max(y0, y1) + half)
    if is_vert:
        return (min(x0, x1) - half, min(y0, y1), max(x0, x1) + half, max(y0, y1))
    # Diagonal fallback — conservative
    return (
        min(x0, x1) - half,
        min(y0, y1) - half,
        max(x0, x1) + half,
        max(y0, y1) + half,
    )


def _rect_envelope_um(
    center: tuple[float, float],
    width_um: float,
    height_um: float,
) -> tuple[float, float, float, float]:
    """Rectangular envelope from center and explicit width/height."""
    x, y = center
    return (
        x - width_um / 2.0,
        y - height_um / 2.0,
        x + width_um / 2.0,
        y + height_um / 2.0,
    )


def _via_envelope_um(
    center: tuple[float, float],
    pad_w_um: float,
    pad_h_um: float,
) -> tuple[float, float, float, float]:
    """Rectangular via envelope from center and pad dimensions."""
    x, y = center
    return (
        x - pad_w_um / 2.0,
        y - pad_h_um / 2.0,
        x + pad_w_um / 2.0,
        y + pad_h_um / 2.0,
    )


def _snap_even_dbu_width_um(
    width_um: float,
    dbu: float,
    min_um: float = 0.0,
) -> float:
    """Snap a width to an even number of DBU units (>= min_um)."""
    if dbu <= 0:
        return max(width_um, min_um)
    units = max(1, int(round(max(width_um, min_um) / dbu)))
    if units % 2 != 0:
        units += 1
    return units * dbu
