"""Port geometry extraction, cut counting, width selection — config-dependent."""

from .config import PortGeometry, RoutingConfig


def _get_pos_with_dir(port, dbu: float) -> tuple[int, int, str]:
    """Convert port to (x_dbu, y_dbu, direction) tuple."""
    x, y = int(port.dcenter[0] / dbu), int(port.dcenter[1] / dbu)
    angle = port.orientation
    if angle is None:
        d = "o"
    elif abs(angle) < 1:
        d = "e"
    elif abs(angle - 90) < 1:
        d = "n"
    elif abs(angle - 180) < 1 or abs(angle + 180) < 1:
        d = "w"
    elif abs(angle - 270) < 1 or abs(angle + 90) < 1:
        d = "s"
    else:
        d = "o"
    return (x, y, d)


def _count_below_port_cuts(
    kc, port_poly, layer_tuple: tuple[int, int] | None, config: RoutingConfig
) -> int:
    """Count lower-cut shapes whose centers are inside the selected port polygon."""
    from kfactory import kdb

    if layer_tuple is None:
        return 0
    cut_layer = config.below_cut_layer(layer_tuple)
    if cut_layer is None:
        return 0

    cut_idx = kc.kcl.layer(*cut_layer)
    cut_region = kdb.Region(kc.begin_shapes_rec(cut_idx))
    count = 0
    for cut in cut_region.each():
        bbox = cut.bbox()
        center = kdb.Point((bbox.left + bbox.right) // 2, (bbox.bottom + bbox.top) // 2)
        if port_poly.inside(center):
            count += 1
    return count


def _fanout_hops_from_cut_count(cut_count: int) -> int:
    """Deterministic width-fanout horizon from below-cut density."""
    if cut_count <= 1:
        return 0
    if cut_count <= 3:
        return 1
    if cut_count <= 6:
        return 2
    return 3


def _selected_straight_width(
    start_geom: PortGeometry,
    stop_geom: PortGeometry,
    fallback_width: float,
    config: RoutingConfig,
) -> float:
    """Select route width from the smaller port polygon's width."""
    candidate = min(float(start_geom.width), float(stop_geom.width))
    _ = fallback_width  # retained for call-site compatibility
    return max(float(config.min_width(config.layer_m1)), candidate)


def _edge_opposite_exit(
    bbox_dbu: tuple[int, int, int, int], exit_dir: str
) -> tuple[int, int]:
    """Return the midpoint on the edge **opposite** the port exit direction.

    Parameters
    ----------
    bbox_dbu : (left, bottom, right, top) in DBU
    exit_dir : one of 'n', 's', 'e', 'w', 'o'

    The idea: the route extension starts from the far edge of the port
    polygon so it traverses the full port area, replacing the old
    square-fill approach.

    """
    left, bottom, right, top = bbox_dbu
    cx = (left + right) // 2
    cy = (bottom + top) // 2
    if exit_dir == "e":
        return (left, cy)
    if exit_dir == "w":
        return (right, cy)
    if exit_dir == "n":
        return (cx, bottom)
    if exit_dir == "s":
        return (cx, top)
    # 'o' or unknown — fall back to center
    return (cx, cy)


def _get_port_geometry(
    port,
    kc,
    dbu: float,
    config: RoutingConfig,
    default_width: float = 0.25,
) -> PortGeometry:
    """Extract squared port geometry from the containing metal polygon."""
    from kfactory import kdb

    px_dbu = int(port.dcenter[0] / dbu)
    py_dbu = int(port.dcenter[1] / dbu)
    port_point = kdb.Point(px_dbu, py_dbu)

    layer_tuple = None
    if hasattr(port, "layer"):
        info = kc.kcl.get_info(port.layer)
        layer_tuple = (info.layer, info.datatype)

    if layer_tuple is None:
        return PortGeometry(default_width, default_width, None, None, None, 0)

    layer_idx = kc.kcl.layer(*layer_tuple)
    region = kdb.Region(kc.begin_shapes_rec(layer_idx))

    best_poly = None
    best_area = 0
    for poly in region.each():
        if poly.inside(port_point):
            area = poly.area()
            if area > best_area:
                best_area = area
                best_poly = poly

    if best_poly is None:
        return PortGeometry(default_width, default_width, None, None, layer_tuple, 0)

    bbox = best_poly.bbox()
    orig_bbox_dbu = (bbox.left, bbox.bottom, bbox.right, bbox.top)
    orig_x_um = max(config.min_width(config.layer_m1), (bbox.right - bbox.left) * dbu)
    orig_y_um = max(config.min_width(config.layer_m1), (bbox.top - bbox.bottom) * dbu)
    orig_min_extent_um = min(orig_x_um, orig_y_um)

    # Square up: use max(width_x, width_y) for both dimensions
    side = max(orig_x_um, orig_y_um)
    x_extent_um = side
    y_extent_um = side

    # Recompute bbox expanded symmetrically from center to match the square
    cx = (bbox.left + bbox.right) // 2
    cy = (bbox.bottom + bbox.top) // 2
    half_side_dbu = int(round(side / dbu / 2))
    bbox_dbu = (
        cx - half_side_dbu,
        cy - half_side_dbu,
        cx + half_side_dbu,
        cy + half_side_dbu,
    )
    dev_center = (cx, cy)
    below_cut_count = _count_below_port_cuts(kc, best_poly, layer_tuple, config)

    return PortGeometry(
        width_x=x_extent_um,
        width_y=y_extent_um,
        bbox_dbu=bbox_dbu,
        dev_center_dbu=dev_center,
        layer_tuple=layer_tuple,
        below_cut_count=below_cut_count,
        orig_bbox_dbu=orig_bbox_dbu,
        orig_min_extent_um=orig_min_extent_um,
        orig_extent_x_um=orig_x_um,
        orig_extent_y_um=orig_y_um,
    )
