"""Drawing segments, vias, corners, extensions onto Components — config-dependent."""

from collections.abc import Sequence
from dataclasses import dataclass

import gdsfactory as gf
import numpy as np
from gdsfactory.component import Component
from gdsfactory.typings import Port

from .config import PinLabelSpec, PortGeometry, RoutingConfig
from .geometry import (
    _bbox_overlap,
    _rect_envelope_um,
    _segment_envelope_um,
    _snap_even_dbu_width_um,
)
from .path import (
    _prune_redundant_jogs_corners,
)
from .segments import _transition_target_via_width
from .via_planning import (
    _is_via_legal_on_both_layers,
    _resolve_legal_via_center,
    _via_pad_candidates,
    _via_pad_size_um,
)


def label_unrouted_pins(
    c: Component,
    pins: Sequence[PinLabelSpec],
    config: RoutingConfig,
    debug: bool = False,
) -> list[Port]:
    """Place pin-layer labels on device ports that have no routing.

    For top-level pins connected to a single device port (no routing
    needed), this places a small metal-layer waypoint rectangle at the
    port centre, adds a port on the pin layer ``(layer, 16)``, and
    calls ``draw_ports()`` to materialise the pin geometry so that LVS
    tools can identify the net.

    Parameters
    ----------
    debug : bool
        Print the placed label details when True.

    """
    labeled: list[Port] = []
    for pin in pins:
        port = pin.port
        # Determine drawing layer from the port
        layer_tuple = None
        if hasattr(port, "layer"):
            info = c.kcl.get_info(port.layer)
            layer_tuple = (info.layer, info.datatype)
        if layer_tuple is None:
            layer_tuple = config.layer_m1
        pin_layer = (layer_tuple[0], 16)

        center = (float(port.dcenter[0]), float(port.dcenter[1]))
        orientation = float(port.orientation) if hasattr(port, "orientation") else 0

        # Place a small waypoint rectangle on the metal drawing layer so
        # that draw_ports() has owned geometry to anchor the pin label.
        marker_size = config.min_width(layer_tuple)
        rect = c.add_ref(
            gf.components.rectangle(size=(marker_size, marker_size), layer=layer_tuple)
        )
        rect.dmove((center[0] - marker_size / 2, center[1] - marker_size / 2))

        p = c.add_port(
            name=pin.pin_name,
            center=center,
            width=0.01,
            orientation=orientation,
            layer=pin_layer,
            port_type="electrical",
        )
        c.draw_ports()
        labeled.append(p)

        if debug:
            print(
                f"[PIN-LABEL] '{pin.pin_name}' at ({center[0]:.3f}, {center[1]:.3f}) "
                f"metal={layer_tuple} pin={pin_layer} marker={marker_size:.3f}um"
            )
    return labeled


MIN_SEGMENT_LENGTH = 0.01  # 10nm minimum


# ---------------------------------------------------------------------------
# GeometryPlan: a validated, drawable route geometry
# ---------------------------------------------------------------------------


@dataclass
class GeometryPlan:
    """A fully validated route geometry ready for drawing."""

    segments: list[
        tuple[tuple[float, float], tuple[float, float], tuple[int, int], float]
    ]
    vias: list[tuple[tuple[float, float], float]]
    patches: list[tuple[tuple[float, float], tuple[int, int], float, float]]


# ---------------------------------------------------------------------------
# Obstacle bbox helpers
# ---------------------------------------------------------------------------


def _build_obstacle_bboxes(
    polys: list[np.ndarray],
    dbu: float,
    exclusion_points_um: list[tuple[float, float]],
) -> list[tuple[float, float, float, float]]:
    """Convert inflated obstacle polygons to bbox tuples, excluding port regions."""
    bboxes: list[tuple[float, float, float, float]] = []
    for poly in polys:
        if len(poly) >= 3:
            box = (
                float(poly[:, 0].min()) * dbu,
                float(poly[:, 1].min()) * dbu,
                float(poly[:, 0].max()) * dbu,
                float(poly[:, 1].max()) * dbu,
            )
            if not any(
                box[0] <= px <= box[2] and box[1] <= py <= box[3]
                for px, py in exclusion_points_um
            ):
                bboxes.append(box)
    return bboxes


# ---------------------------------------------------------------------------
# Width computation
# ---------------------------------------------------------------------------


def _endpoint_exit_direction(
    corners_3d: list[tuple[int, int, int]],
    is_start: bool,
) -> str:
    """Return 'h' if the endpoint segment is horizontal, 'v' if vertical."""
    if len(corners_3d) < 2:
        return "h"
    if is_start:
        a, b = corners_3d[0], corners_3d[1]
    else:
        a, b = corners_3d[-2], corners_3d[-1]
    dx = abs(b[0] - a[0])
    dy = abs(b[1] - a[1])
    return "h" if dx >= dy else "v"


def _exit_edge_width(geom: PortGeometry, direction: str) -> float:
    """Return the port polygon extent perpendicular to the trace direction.

    - Horizontal trace -> cap to Y extent (trace runs along X, width is in Y)
    - Vertical trace -> cap to X extent (trace runs along Y, width is in X)

    For highly asymmetric ports (aspect ratio > 2:1), the perpendicular extent
    is clamped to ``orig_min_extent_um`` to prevent wide segments from bridging
    across to adjacent pads (e.g. PMOS source ~0.23x0.75 bridging to gate).
    """
    if geom.orig_extent_x_um > 0 and geom.orig_extent_y_um > 0:
        perp = geom.orig_extent_y_um if direction == "h" else geom.orig_extent_x_um
        aspect = max(geom.orig_extent_x_um, geom.orig_extent_y_um) / max(
            0.001, min(geom.orig_extent_x_um, geom.orig_extent_y_um)
        )
        if aspect > 2.0:
            perp = min(perp, geom.orig_min_extent_um)
        return perp
    if geom.orig_min_extent_um > 0:
        return geom.orig_min_extent_um
    return float(geom.width)


def _longest_edge(geom: PortGeometry) -> float:
    """Return the *shorter* edge of the original port polygon.

    Using the shorter edge for body segments avoids inflating traces into
    constrained spacing areas while still producing a uniform cross-section
    wider than ``min_width`` for most ports.
    """
    if geom.orig_min_extent_um > 0:
        return geom.orig_min_extent_um
    if geom.orig_extent_x_um > 0 and geom.orig_extent_y_um > 0:
        return min(geom.orig_extent_x_um, geom.orig_extent_y_um)
    return float(geom.width)


def _build_segment_widths_dynamic(
    corners_3d: list[tuple[int, int, int]],
    start_geom: PortGeometry,
    stop_geom: PortGeometry,
    body_width: float,
    fallback_width: float,
    dynamic_width: bool,
    config: RoutingConfig,
) -> list[float]:
    """Compute per-segment widths: wider at port endpoints, body_width in between.

    First segment matches start port width (contact row length) for EM
    coverage.  Last segment matches stop port width.  Middle segments
    use body_width.
    """
    n_segs = len(corners_3d) - 1 if len(corners_3d) >= 2 else 0
    if n_segs <= 0:
        return []
    if not dynamic_width:
        return [fallback_width] * n_segs

    min_w = float(config.min_width(config.layer_m1))
    # Body width: uniform at the shorter port edge so the trace covers
    # both port polygons without inflating into constrained spacing areas.
    # Cap at body_width to avoid exceeding the caller's safe limit.
    body_w = min(
        max(min_w, _longest_edge(start_geom), _longest_edge(stop_geom)),
        max(min_w, body_width),
    )
    # Port extensions: direction-aware exit edge width (clamped for
    # asymmetric ports >2:1 aspect).  Take the larger of body and exit
    # edge so endpoints never pinch narrower than the body.
    start_dir = _endpoint_exit_direction(corners_3d, is_start=True)
    stop_dir = _endpoint_exit_direction(corners_3d, is_start=False)
    start_w = max(body_w, _exit_edge_width(start_geom, start_dir))
    stop_w = max(body_w, _exit_edge_width(stop_geom, stop_dir))

    if n_segs == 1:
        return [max(start_w, stop_w)]
    if n_segs == 2:
        return [start_w, stop_w]
    return [start_w] + [body_w] * (n_segs - 2) + [stop_w]


def _build_corner_patches_from_segments(
    plan_segments: list[
        tuple[tuple[float, float], tuple[float, float], tuple[int, int], float]
    ],
    config: RoutingConfig,
) -> list[tuple[tuple[float, float], tuple[int, int], float, float]]:
    """Build anisotropic corner patches from adjacent straight segments."""
    endpoint_map: dict[
        tuple[float, float, tuple[int, int]], list[tuple[bool, float]]
    ] = {}
    for p0, p1, layer, seg_w in plan_segments:
        is_h = abs(p1[1] - p0[1]) < 0.001
        key0 = (p0[0], p0[1], layer)
        key1 = (p1[0], p1[1], layer)
        endpoint_map.setdefault(key0, []).append((is_h, seg_w))
        endpoint_map.setdefault(key1, []).append((is_h, seg_w))

    patches: list[tuple[tuple[float, float], tuple[int, int], float, float]] = []
    for (x, y, layer), entries in endpoint_map.items():
        h_widths = [w for is_h, w in entries if is_h]
        v_widths = [w for is_h, w in entries if not is_h]
        if not h_widths or not v_widths:
            continue
        min_w = float(config.min_width(layer))
        patch_w = max(min_w, max(v_widths))
        patch_h = max(min_w, max(h_widths))
        patches.append(((x, y), layer, patch_w, patch_h))
    return patches


# ---------------------------------------------------------------------------
# Legacy single-width drawing (used by hierarchical router)
# ---------------------------------------------------------------------------


def _draw_route_segments(
    c: Component,
    points_um: list[tuple[float, float]],
    width: float,
    config: RoutingConfig,
    add_segment_ports: bool = False,
    port_name_prefix: str = "seg",
    horizontal_layer: tuple[int, int] | None = None,
    vertical_layer: tuple[int, int] | None = None,
    add_vias: bool = True,
) -> list[Port]:
    """Draw metal segments and vias for a route path."""
    if horizontal_layer is None:
        horizontal_layer = config.layer_m1
    if vertical_layer is None:
        vertical_layer = config.layer_m2

    segment_ports = []

    if horizontal_layer == vertical_layer:
        for p in points_um:
            patch = c.add_ref(
                gf.components.rectangle(size=(width, width), layer=horizontal_layer)
            )
            patch.dcenter = p

    if len(points_um) < 2:
        return segment_ports

    from .path import _is_horizontal

    for i in range(len(points_um) - 1):
        p_curr = points_um[i]
        p_next = points_um[i + 1]

        dx = abs(p_next[0] - p_curr[0])
        dy = abs(p_next[1] - p_curr[1])
        if dx < MIN_SEGMENT_LENGTH and dy < MIN_SEGMENT_LENGTH:
            continue

        horiz = _is_horizontal(p_curr, p_next)

        if horiz:
            x_min = min(p_curr[0], p_next[0])
            x_max = max(p_curr[0], p_next[0])
            length = x_max - x_min
            y = p_curr[1]

            if length >= 0.001:
                rect = c.add_ref(
                    gf.components.rectangle(
                        size=(length, width), layer=horizontal_layer
                    )
                )
                rect.dmove((x_min, y - width / 2))

                if add_segment_ports:
                    port_center = (x_min + length / 2, y)
                    port_name = f"{port_name_prefix}"
                    port = c.add_port(
                        name=port_name,
                        center=port_center,
                        width=0.01,
                        orientation=0,
                        layer=(horizontal_layer[0], 16),
                        port_type="electrical",
                    )
                    segment_ports.append(port)
                    c.draw_ports()
        else:
            y_min = min(p_curr[1], p_next[1])
            y_max = max(p_curr[1], p_next[1])
            length = y_max - y_min
            x = p_curr[0]

            if length >= 0.001:
                rect = c.add_ref(
                    gf.components.rectangle(size=(width, length), layer=vertical_layer)
                )
                rect.dmove((x - width / 2, y_min))

                if add_segment_ports:
                    port_center = (x, y_min + length / 2)
                    port_name = f"{port_name_prefix}"
                    port = c.add_port(
                        name=port_name,
                        center=port_center,
                        width=0.01,
                        orientation=90,
                        layer=(vertical_layer[0], 16),
                        port_type="electrical",
                    )
                    segment_ports.append(port)
                    c.draw_ports()

        if add_vias and i < len(points_um) - 2:
            via_w = _via_pad_size_um(width, config)
            via = c.add_ref(config.via_factory(width=via_w, length=via_w))
            via.dcenter = p_next

    return segment_ports


# ---------------------------------------------------------------------------
# Plan → Validate → Draw pipeline
# ---------------------------------------------------------------------------


def _place_vias(
    corners: list[tuple[int, int, int]],
    seg_widths: list[float],
    width: float,
    start_geom: PortGeometry,
    stop_geom: PortGeometry,
    m1_bboxes: list[tuple[float, float, float, float]],
    m2_bboxes: list[tuple[float, float, float, float]],
    dbu: float,
    clearance: float,
    config: RoutingConfig,
) -> tuple[dict[int, float], list[tuple[int, int, int]]] | None:
    """Resolve legal via centers for all layer transitions.

    Returns (via_pad_by_transition, updated_corners) or None if any via is blocked.
    """
    corners = list(corners)
    via_pad_by_transition: dict[int, float] = {}
    for i in range(len(corners) - 1):
        x0, y0, z0 = corners[i]
        _, _, z1 = corners[i + 1]
        if z0 == z1:
            continue
        target_w = _transition_target_via_width(corners, seg_widths, i, width)
        # Cap via width at port endpoints
        for _pg in (start_geom, stop_geom):
            if _pg.orig_bbox_dbu is not None and _pg.dev_center_dbu is not None:
                _gcx, _gcy = _pg.dev_center_dbu
                if abs(x0 - _gcx) <= 1 and abs(y0 - _gcy) <= 1:
                    _ol, _ob, _or, _ot = _pg.orig_bbox_dbu
                    _min_ext = min((_or - _ol) * dbu, (_ot - _ob) * dbu)
                    target_w = min(target_w, _min_ext)
                    break
        target_pad = _snap_even_dbu_width_um(
            _via_pad_size_um(target_w, config),
            dbu,
            config.min_via_pad_any(),
        )
        base_center = (x0 * dbu, y0 * dbu)
        allow_relocate = i > 0 and (i + 1) < (len(corners) - 1)
        resolved = None
        chosen_pad = None
        tried_pads: set = set()
        for via_pad_raw in _via_pad_candidates(target_pad, config):
            via_pad = _snap_even_dbu_width_um(
                via_pad_raw, dbu, config.min_via_pad_any()
            )
            key = int(round(via_pad / dbu))
            if key in tried_pads:
                continue
            tried_pads.add(key)
            candidate = _resolve_legal_via_center(
                base_center_um=base_center,
                via_pad_um=via_pad,
                m1_bboxes=m1_bboxes,
                m2_bboxes=m2_bboxes,
                dbu=dbu,
                config=config,
                relocate_step_um=max(clearance, 0.14),
                relocate_radius_um=max(1.0, 2.0 * clearance),
                max_candidates=64,
                allow_relocate=allow_relocate,
            )
            if candidate is None:
                continue
            resolved = candidate
            chosen_pad = via_pad
            break
        if resolved is None or chosen_pad is None:
            return None
        via_pad_by_transition[i] = chosen_pad
        if resolved != base_center:
            rx = int(round(resolved[0] / dbu))
            ry = int(round(resolved[1] / dbu))
            corners[i] = (rx, ry, z0)
            corners[i + 1] = (rx, ry, z1)
    return via_pad_by_transition, corners


def _build_planned_segments(
    corners: list[tuple[int, int, int]],
    seg_widths: list[float],
    via_pad_by_transition: dict[int, float],
    width: float,
    dbu: float,
    config: RoutingConfig,
) -> tuple[
    list[tuple[tuple[float, float], tuple[float, float], tuple[int, int], float]],
    list[tuple[tuple[float, float], float]],
]:
    """Build planned segments and via placements from corners.

    Returns (plan_segments, plan_vias).
    """
    LAYER_M1 = config.layer_m1

    plan_segments: list[
        tuple[tuple[float, float], tuple[float, float], tuple[int, int], float]
    ] = []
    plan_vias: list[tuple[tuple[float, float], float]] = []

    def _plan_add_segment(
        p0: tuple[float, float],
        p1: tuple[float, float],
        layer: tuple[int, int],
        seg_w: float,
    ) -> None:
        dx = abs(p1[0] - p0[0])
        dy = abs(p1[1] - p0[1])
        if dx < MIN_SEGMENT_LENGTH and dy < MIN_SEGMENT_LENGTH:
            return
        if dx > 0.001 and dy > 0.001:
            mid = (p1[0], p0[1]) if layer == LAYER_M1 else (p0[0], p1[1])
            _plan_add_segment(p0, mid, layer, seg_w)
            _plan_add_segment(mid, p1, layer, seg_w)
            return
        plan_segments.append((p0, p1, layer, seg_w))

    for i in range(len(corners) - 1):
        x0, y0, z0 = corners[i]
        x1, y1, z1 = corners[i + 1]
        seg_w = seg_widths[i] if i < len(seg_widths) else width
        p0 = (x0 * dbu, y0 * dbu)
        p1 = (x1 * dbu, y1 * dbu)
        if z0 != z1:
            via_pad = via_pad_by_transition.get(
                i,
                _snap_even_dbu_width_um(
                    _via_pad_size_um(
                        _transition_target_via_width(corners, seg_widths, i, width),
                        config,
                    ),
                    dbu,
                    config.min_via_pad_any(),
                ),
            )
            plan_vias.append((p0, via_pad))
            _plan_add_segment(p0, p1, config.layer_for_index(z1), seg_w)
        else:
            _plan_add_segment(p0, p1, config.layer_for_index(z0), seg_w)

    return plan_segments, plan_vias


def _validate_geometry(
    plan_segments: list[
        tuple[tuple[float, float], tuple[float, float], tuple[int, int], float]
    ],
    plan_vias: list[tuple[tuple[float, float], float]],
    plan_patches: list[tuple[tuple[float, float], tuple[int, int], float, float]],
    m1_bboxes: list[tuple[float, float, float, float]],
    m2_bboxes: list[tuple[float, float, float, float]],
    config: RoutingConfig,
) -> bool:
    """Validate all geometry elements against obstacle bboxes. Returns True if clear."""
    LAYER_M1 = config.layer_m1

    for p0, p1, layer, seg_w in plan_segments:
        seg_box = _segment_envelope_um(p0, p1, seg_w)
        target = m1_bboxes if layer == LAYER_M1 else m2_bboxes
        if any(_bbox_overlap(seg_box, obox) for obox in target):
            return False

    for center, layer, patch_w, patch_h in plan_patches:
        patch_box = _rect_envelope_um(center, patch_w, patch_h)
        target = m1_bboxes if layer == LAYER_M1 else m2_bboxes
        if any(_bbox_overlap(patch_box, obox) for obox in target):
            return False

    for center, via_w in plan_vias:
        if not _is_via_legal_on_both_layers(
            center, via_w, m1_bboxes, m2_bboxes, config
        ):
            return False

    return True


def _plan_route_geometry(
    corners: list[tuple[int, int, int]],
    seg_widths: list[float],
    width: float,
    start_geom: PortGeometry,
    stop_geom: PortGeometry,
    m1_bboxes: list[tuple[float, float, float, float]],
    m2_bboxes: list[tuple[float, float, float, float]],
    dbu: float,
    clearance: float,
    config: RoutingConfig,
) -> GeometryPlan | None:
    """Build and validate a complete geometry plan. Returns None if blocked."""
    corners = _prune_redundant_jogs_corners(list(corners))
    if len(corners) < 2:
        return None

    via_result = _place_vias(
        corners,
        seg_widths,
        width,
        start_geom,
        stop_geom,
        m1_bboxes,
        m2_bboxes,
        dbu,
        clearance,
        config,
    )
    if via_result is None:
        return None
    via_pad_by_transition, corners = via_result

    # Widen segments at via transitions to match the actual via metal
    # footprint (pad + enclosure).  Prevents DRC notches where the wider
    # via metal meets narrower routing segments.
    for idx, via_pad_w in via_pad_by_transition.items():
        via_metal_w = via_pad_w + float(config.via_metal_enclosure_add)
        if idx < len(seg_widths):
            seg_widths[idx] = max(seg_widths[idx], via_metal_w)
        if idx > 0 and (idx - 1) < len(seg_widths):
            seg_widths[idx - 1] = max(seg_widths[idx - 1], via_metal_w)
        # Also widen the segment AFTER the via transition to prevent
        # DRC notches where the via metal pad meets a narrower departing segment.
        if (idx + 1) < len(seg_widths):
            seg_widths[idx + 1] = max(seg_widths[idx + 1], via_metal_w)

    corners = _prune_redundant_jogs_corners(corners)
    if len(corners) < 2:
        return None

    plan_segments, plan_vias = _build_planned_segments(
        corners,
        seg_widths,
        via_pad_by_transition,
        width,
        dbu,
        config,
    )
    plan_patches = _build_corner_patches_from_segments(plan_segments, config)

    if not _validate_geometry(
        plan_segments, plan_vias, plan_patches, m1_bboxes, m2_bboxes, config
    ):
        return None

    return GeometryPlan(
        segments=plan_segments,
        vias=plan_vias,
        patches=plan_patches,
    )


def _draw_geometry_plan(
    c: Component,
    plan: GeometryPlan,
    config: RoutingConfig,
    add_segment_ports: bool,
    port_name_prefix: str,
    debug: bool = False,
) -> list[Port]:
    """Draw a validated geometry plan onto the component."""
    segment_ports: list[Port] = []

    for center, layer, patch_w, patch_h in plan.patches:
        patch = c.add_ref(gf.components.rectangle(size=(patch_w, patch_h), layer=layer))
        patch.dcenter = center

    for center, via_w in plan.vias:
        via = c.add_ref(config.via_factory(width=via_w, length=via_w))
        via.dcenter = center

    if debug:
        _dbg_copy = c.dup()
        _dbg_copy.flatten()
        _dbg_copy.show()
        input(
            "[DEBUG] Corner patches + vias drawn. Press Enter to draw straight segments..."
        )

    n_segs = len(plan.segments)
    for seg_idx, (p0, p1, layer, seg_w) in enumerate(plan.segments):
        is_horiz = abs(p1[1] - p0[1]) < 0.001
        if is_horiz:
            x_min = min(p0[0], p1[0])
            x_max = max(p0[0], p1[0])
            seg_len = x_max - x_min
            if seg_len >= 0.001:
                rect = c.add_ref(
                    gf.components.rectangle(size=(seg_len, seg_w), layer=layer)
                )
                rect.dmove((x_min, p0[1] - seg_w / 2))
                if add_segment_ports:
                    if n_segs >= 2 and seg_idx == 0:
                        port_cx = p1[0]
                    elif n_segs >= 2 and seg_idx == n_segs - 1:
                        port_cx = p0[0]
                    else:
                        port_cx = x_min + seg_len / 2
                    port = c.add_port(
                        name=f"{port_name_prefix}",
                        center=(port_cx, p0[1]),
                        width=0.01,
                        orientation=0,
                        layer=(layer[0], 16),
                        port_type="electrical",
                    )
                    segment_ports.append(port)
                    c.draw_ports()
        else:
            y_min = min(p0[1], p1[1])
            y_max = max(p0[1], p1[1])
            seg_len = y_max - y_min
            if seg_len >= 0.001:
                rect = c.add_ref(
                    gf.components.rectangle(size=(seg_w, seg_len), layer=layer)
                )
                rect.dmove((p0[0] - seg_w / 2, y_min))
                if add_segment_ports:
                    if n_segs >= 2 and seg_idx == 0:
                        port_cy = p1[1]
                    elif n_segs >= 2 and seg_idx == n_segs - 1:
                        port_cy = p0[1]
                    else:
                        port_cy = y_min + seg_len / 2
                    port = c.add_port(
                        name=f"{port_name_prefix}",
                        center=(p0[0], port_cy),
                        width=0.01,
                        orientation=90,
                        layer=(layer[0], 16),
                        port_type="electrical",
                    )
                    segment_ports.append(port)
                    c.draw_ports()

    return segment_ports


# ---------------------------------------------------------------------------
# Main entry point (called from engine_3d)
# ---------------------------------------------------------------------------


def _draw_dynamic_geometry_for_corners(
    c: Component,
    corners_3d: list[tuple[int, int, int]],
    start_geom: PortGeometry,
    stop_geom: PortGeometry,
    body_width: float,
    width: float,
    dynamic_width: bool,
    m1_polys: list[np.ndarray],
    m2_polys: list[np.ndarray],
    start_xy_dbu: tuple[int, int],
    stop_xy_dbu: tuple[int, int],
    dbu: float,
    clearance: float,
    add_segment_ports: bool,
    port_name_prefix: str,
    config: RoutingConfig,
    debug: bool = False,
    extra_port_points_um: list[tuple[float, float]] | None = None,
    verbose: bool = False,
) -> list[Port] | None:
    """Draw dynamic-width route geometry from layered corners.

    Returns:
        List of segment ports if drawing succeeds, otherwise None.

    """
    if len(corners_3d) < 2:
        return []

    port_points_um = [
        (start_xy_dbu[0] * dbu, start_xy_dbu[1] * dbu),
        (stop_xy_dbu[0] * dbu, stop_xy_dbu[1] * dbu),
    ]
    if extra_port_points_um:
        port_points_um.extend(extra_port_points_um)

    m1_bboxes = _build_obstacle_bboxes(m1_polys, dbu, port_points_um)
    m2_bboxes = _build_obstacle_bboxes(m2_polys, dbu, port_points_um)

    seg_widths = _build_segment_widths_dynamic(
        corners_3d=corners_3d,
        start_geom=start_geom,
        stop_geom=stop_geom,
        body_width=body_width,
        fallback_width=width,
        dynamic_width=dynamic_width,
        config=config,
    )
    min_seg_w = max(float(config.min_width(config.layer_m1)), float(width))
    seg_widths = [_snap_even_dbu_width_um(sw, dbu, min_seg_w) for sw in seg_widths]

    if verbose:
        print(f"[DRAW-VERBOSE] net='{port_name_prefix}'")
        print(
            f"  start_geom: ext_x={start_geom.orig_extent_x_um:.3f} "
            f"ext_y={start_geom.orig_extent_y_um:.3f} "
            f"min_ext={start_geom.orig_min_extent_um:.3f} "
            f"width={float(start_geom.width):.3f}"
        )
        print(
            f"  stop_geom:  ext_x={stop_geom.orig_extent_x_um:.3f} "
            f"ext_y={stop_geom.orig_extent_y_um:.3f} "
            f"min_ext={stop_geom.orig_min_extent_um:.3f} "
            f"width={float(stop_geom.width):.3f}"
        )
        print(f"  seg_widths={[f'{w:.3f}' for w in seg_widths]}")

    width_profiles: list[list[float]] = [list(seg_widths)]
    fallback = [
        _snap_even_dbu_width_um(max(min_seg_w, body_width), dbu, min_seg_w)
    ] * len(seg_widths)
    if fallback != width_profiles[0]:
        width_profiles.append(fallback)

    base_corners: list[tuple[int, int, int]] = [
        (int(c_[0]), int(c_[1]), int(c_[2])) for c_ in corners_3d
    ]
    for seg_widths_trial in width_profiles:
        plan = _plan_route_geometry(
            corners=list(base_corners),
            seg_widths=seg_widths_trial,
            width=width,
            start_geom=start_geom,
            stop_geom=stop_geom,
            m1_bboxes=m1_bboxes,
            m2_bboxes=m2_bboxes,
            dbu=dbu,
            clearance=clearance,
            config=config,
        )
        if plan is not None:
            return _draw_geometry_plan(
                c, plan, config, add_segment_ports, port_name_prefix, debug
            )

    return None
