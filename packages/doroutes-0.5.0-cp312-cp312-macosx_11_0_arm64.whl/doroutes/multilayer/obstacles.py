"""Polygon extraction for obstacle avoidance — requires config for layer mapping."""

import numpy as np


def _extract_polys_for_layers(
    kc,
    layers: list[tuple[int, int]],
    dbu: float,
    port_points: list[tuple[int, int]] | None = None,
    port_bboxes: list[tuple[int, int, int, int]] | None = None,
    buffer_dbu: int = 0,
) -> list[np.ndarray]:
    """Extract obstruction polygons from specified layers.

    Args:
        kc: KCell to extract polygons from.
        layers: List of (layer, datatype) tuples to extract.
        dbu: Database unit.
        port_points: Optional list of (x_dbu, y_dbu) port positions.
                    ONLY polygons containing these exact points are excluded.
        port_bboxes: Optional list of (left, bottom, right, top) in DBU.
                    Polygons whose bbox overlaps any port bbox are excluded.
                    Takes precedence over port_points when provided.
        buffer_dbu: Optional obstruction inflation in DBU.

    Returns:
        List of polygon point arrays.

    """
    from kfactory import kdb

    all_polys = []
    for layer in layers:
        layer_idx = kc.kcl.layer(*layer)
        r = kdb.Region(kc.begin_shapes_rec(layer_idx))
        for poly in r.each():
            all_polys.append(poly)

    excluded_indices = set()
    if port_bboxes:
        # Use containment check: only exclude a polygon whose bbox fits
        # within a port bbox (with tolerance).  This avoids excluding
        # long routing segments that were merged with a port-area polygon
        # by the Region operation.
        margin = 100  # 100nm tolerance for merged edges
        for i, poly in enumerate(all_polys):
            pb = poly.bbox()
            for pl, pbottom, pr, pt in port_bboxes:
                if (
                    pb.left >= pl - margin
                    and pb.right <= pr + margin
                    and pb.bottom >= pbottom - margin
                    and pb.top <= pt + margin
                ):
                    excluded_indices.add(i)
                    break
    elif port_points:
        for px, py in port_points:
            port_point = kdb.Point(px, py)
            for i, poly in enumerate(all_polys):
                if poly.inside(port_point):
                    excluded_indices.add(i)
                    break

    obstruction_region = kdb.Region()
    for i, poly in enumerate(all_polys):
        if i not in excluded_indices:
            obstruction_region.insert(poly)

    if buffer_dbu > 0:
        obstruction_region = obstruction_region.sized(buffer_dbu)

    polys = []
    for poly in obstruction_region.each():
        pts = np.array([(p.x, p.y) for p in poly.each_point_hull()], dtype=np.int64)
        if len(pts) >= 3:
            polys.append(pts)

    return polys
