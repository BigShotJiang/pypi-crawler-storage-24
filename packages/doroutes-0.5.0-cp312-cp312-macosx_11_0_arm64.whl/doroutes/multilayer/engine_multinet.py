"""Multi-net deterministic routing — config-dependent."""

from collections.abc import Iterable, Sequence
from itertools import permutations
from typing import Optional

from gdsfactory.component import Component
from gdsfactory.typings import LayerSpec, Port

from .config import (
    PortGeometry,
    RouteNetSpec,
    RoutingConfig,
)
from .engine_3d import route_multilayer_3d
from .port_analysis import _get_port_geometry


def _precompute_port_geometries(
    c: Component,
    nets: Sequence[RouteNetSpec],
    config: RoutingConfig,
    width: float,
) -> "dict[tuple[int, int], PortGeometry]":
    """Pre-compute port geometries for ALL nets before any routing/fills.

    Must be called while the component contains only original device metal,
    before port fills or route segments are drawn.  Later routing passes
    use the cached geometries so they aren't corrupted by merged polygons.

    Returns dict keyed by (x_dbu, y_dbu) port center.
    """
    dbu = c.kcl.dbu
    kc = c.kcl.kcells[c.name]
    cache: dict[tuple[int, int], PortGeometry] = {}
    for net in nets:
        for port in (net.start, net.stop):
            key = (int(port.dcenter[0] / dbu), int(port.dcenter[1] / dbu))
            if key not in cache:
                cache[key] = _get_port_geometry(
                    port, kc, dbu, config, default_width=width
                )
    return cache


def _draw_port_fills(
    c: Component,
    nets: Sequence[RouteNetSpec],
    config: RoutingConfig,
    width: float,
    dynamic_width: bool,
    geom_cache: Optional["dict[tuple[int, int], PortGeometry]"] = None,
) -> None:
    """Draw port fill metal matching original polygon bounds for all nets upfront.

    Uses orig_bbox_dbu (the actual polygon shape) — no expansion beyond
    the original polygon, so no DRC spacing violations.  EM coverage
    beyond the polygon is handled by widened first/last route segments.
    """
    if not dynamic_width:
        return
    import gdsfactory as gf

    dbu = c.kcl.dbu
    kc = c.kcl.kcells[c.name]
    for net in nets:
        for port in (net.start, net.stop):
            key = (int(port.dcenter[0] / dbu), int(port.dcenter[1] / dbu))
            if geom_cache and key in geom_cache:
                geom = geom_cache[key]
            else:
                geom = _get_port_geometry(port, kc, dbu, config, default_width=width)
            fill_bbox = (
                geom.orig_bbox_dbu if geom.orig_bbox_dbu is not None else geom.bbox_dbu
            )
            if fill_bbox is not None and geom.layer_tuple is not None:
                left, bottom, right, top = fill_bbox
                fill_w = (right - left) * dbu
                fill_h = (top - bottom) * dbu
                if fill_w > 0 and fill_h > 0:
                    rect = c.add_ref(
                        gf.components.rectangle(
                            size=(fill_w, fill_h), layer=geom.layer_tuple
                        )
                    )
                    rect.dmove((left * dbu, bottom * dbu))


def _collect_all_port_bboxes(
    c: Component,
    nets: Sequence[RouteNetSpec],
    config: RoutingConfig,
    width: float,
    geom_cache: Optional["dict[tuple[int, int], PortGeometry]"] = None,
) -> "list[tuple[int, int, int, int]]":
    """Collect port bboxes from all nets for obstacle exclusion.

    Uses ``orig_bbox_dbu`` (the actual polygon extent) instead of the
    squared ``bbox_dbu`` to prevent over-exclusion.  Squared bboxes on
    asymmetric ports (e.g. PMOS SOURCE 0.23x0.75um → 0.75x0.75um) can
    overlap adjacent port pads, hiding them from obstacle detection and
    allowing routes from other nets to pass through them.
    """
    dbu = c.kcl.dbu
    kc = c.kcl.kcells[c.name]
    bboxes = []
    seen = set()
    for net in nets:
        for port in (net.start, net.stop):
            key = (int(port.dcenter[0] / dbu), int(port.dcenter[1] / dbu))
            if key in seen:
                continue
            seen.add(key)
            if geom_cache and key in geom_cache:
                geom = geom_cache[key]
            else:
                geom = _get_port_geometry(port, kc, dbu, config, default_width=width)
            # Prefer the original (unsquared) bbox to avoid over-exclusion
            bbox = (
                geom.orig_bbox_dbu if geom.orig_bbox_dbu is not None else geom.bbox_dbu
            )
            if bbox is not None:
                bboxes.append(bbox)
    return bboxes


def _clear_component_routes_from_baseline(
    c: Component,
    baseline_instances: set,
    baseline_port_count: int,
) -> None:
    """Rollback route-created instances/ports to a known baseline."""
    for inst in list(c.insts):
        if inst.instance not in baseline_instances:
            inst.instance.delete()
    if len(c.ports.bases) > baseline_port_count:
        del c.ports.bases[baseline_port_count:]


def _build_deterministic_net_orders(
    nets: Sequence[RouteNetSpec],
) -> list[tuple[RouteNetSpec, ...]]:
    """Build deterministic net ordering candidates."""
    if not nets:
        return []

    idxs = list(range(len(nets)))

    def _manhattan(i: int) -> float:
        s = nets[i].start.dcenter
        t = nets[i].stop.dcenter
        return abs(float(s[0]) - float(t[0])) + abs(float(s[1]) - float(t[1]))

    seed_orders: list[tuple[int, ...]] = [tuple(idxs)]
    seed_orders.append(tuple(sorted(idxs, key=lambda i: (-_manhattan(i), i))))
    seed_orders.append(tuple(sorted(idxs, key=lambda i: (_manhattan(i), i))))
    seed_orders.append(tuple(reversed(idxs)))

    if len(nets) <= 6:
        seed_orders.extend(permutations(idxs))

    dedup: list[tuple[int, ...]] = []
    seen = set()
    for ord_idxs in seed_orders:
        if ord_idxs in seen:
            continue
        seen.add(ord_idxs)
        dedup.append(ord_idxs)

    return [tuple(nets[i] for i in ord_idxs) for ord_idxs in dedup]


def route_nets_deterministic(
    c: Component,
    nets: Sequence[RouteNetSpec],
    config: RoutingConfig,
    grid_unit: float = 1.0,
    width: float = 0.25,
    dynamic_width: bool = True,
    layers_to_avoid: Iterable[LayerSpec] | None = None,
    via_cost: float = 10.0,
    wrong_way_penalty: float = 8.0,
    clearance: float = 0.14,
    clearance_ladder: tuple[float, ...] = (0.14, 0.10, 0.07),
    deterministic: bool = True,
    add_segment_ports: bool = True,
    require_all: bool = True,
    debug: bool = False,
    placement_report: dict | None = None,
) -> dict[str, list[Port]]:
    """Deterministically route multiple nets with whole-attempt rollback/retry."""
    if layers_to_avoid is None:
        layers_to_avoid = []
    if not nets:
        return {}

    dbu = c.kcl.dbu
    # Pre-compute port geometries BEFORE fills/routing corrupt the layout
    geom_cache = _precompute_port_geometries(c, nets, config, width)
    all_port_bboxes = _collect_all_port_bboxes(
        c, nets, config, width, geom_cache=geom_cache
    )
    _draw_port_fills(c, nets, config, width, dynamic_width, geom_cache=geom_cache)

    baseline_instances = {inst.instance for inst in c.insts}  # type: ignore[reportUnhashable]
    baseline_port_count = len(c.ports.bases)
    net_orders = _build_deterministic_net_orders(nets)

    best_partial: dict[str, list[Port]] = {}

    for attempt_idx, ordered_nets in enumerate(net_orders, start=1):
        if attempt_idx > 1:
            _clear_component_routes_from_baseline(
                c, baseline_instances, baseline_port_count
            )
        print(
            f"[MULTINET] Attempt {attempt_idx}/{len(net_orders)} order="
            f"{','.join(net.name for net in ordered_nets)}"
        )

        routed: dict[str, list[Port]] = {}
        failed_name: str | None = None

        for net in ordered_nets:
            start_key = (
                int(net.start.dcenter[0] / dbu),
                int(net.start.dcenter[1] / dbu),
            )
            stop_key = (int(net.stop.dcenter[0] / dbu), int(net.stop.dcenter[1] / dbu))
            result = route_multilayer_3d(
                c,
                start=net.start,
                stop=net.stop,
                config=config,
                grid_unit=grid_unit,
                width=width,
                dynamic_width=dynamic_width,
                layers_to_avoid=layers_to_avoid,
                add_segment_ports=net.is_top_level_pin,
                port_name_prefix=net.port_name_prefix,
                via_cost=via_cost,
                wrong_way_penalty=wrong_way_penalty,
                clearance=clearance,
                clearance_ladder=clearance_ladder,
                deterministic=deterministic,
                debug=debug,
                extra_port_bboxes=all_port_bboxes,
                cached_start_geom=geom_cache.get(start_key),
                cached_stop_geom=geom_cache.get(stop_key),
            )
            if not result.success:
                failed_name = net.name
                print(
                    f"[MULTINET] net '{net.name}' failed in attempt {attempt_idx}"
                    f" (reason={result.failure_reason})"
                )
                break
            routed[net.name] = result.ports

        if failed_name is None and len(routed) == len(nets):
            print(f"[MULTINET] Success on attempt {attempt_idx}")
            return routed

        if len(routed) > len(best_partial):
            best_partial = routed

    if require_all:
        raise RuntimeError(
            "[MULTINET] Unable to complete all requested nets without obstruction conflicts."
        )
    return best_partial


def route_nets_deterministic_copy(
    c: Component,
    nets: Sequence[RouteNetSpec],
    config: RoutingConfig,
    grid_unit: float = 1.0,
    width: float = 0.25,
    dynamic_width: bool = True,
    layers_to_avoid: Iterable[LayerSpec] | None = None,
    via_cost: float = 10.0,
    wrong_way_penalty: float = 8.0,
    clearance: float = 0.14,
    clearance_ladder: tuple[float, ...] = (0.14, 0.10, 0.07),
    deterministic: bool = True,
    add_segment_ports: bool = True,
    require_all: bool = True,
    debug: bool = False,
    placement_report: dict | None = None,
    geom_cache: dict[tuple[int, int], PortGeometry] | None = None,
) -> tuple[Component, dict[str, list[Port]]]:
    """Deterministically route multiple nets on copy-attempts.

    Strategy: batch-first (GRT+DRT) with serial fallback for failed nets.

    Parameters
    ----------
    geom_cache : optional
        Pre-computed port geometry cache.  When provided, skips internal
        ``_precompute_port_geometries()`` call — useful when earlier routing
        passes have already modified the component and would corrupt fresh
        geometry extraction.

    """
    if layers_to_avoid is None:
        layers_to_avoid = []
    if not nets:
        return c.copy(), {}

    dbu = c.kcl.dbu
    # Use provided cache or pre-compute on the ORIGINAL component before copies
    if geom_cache is None:
        geom_cache = _precompute_port_geometries(c, nets, config, width)
    all_port_bboxes = _collect_all_port_bboxes(
        c, nets, config, width, geom_cache=geom_cache
    )

    # --- Phase 1: Try batch routing (GRT+DRT) ---
    batch_result = _try_batch_routing(
        c,
        nets,
        config,
        grid_unit=grid_unit,
        width=width,
        dynamic_width=dynamic_width,
        layers_to_avoid=layers_to_avoid,
        add_segment_ports=add_segment_ports,
        via_cost=via_cost,
        wrong_way_penalty=wrong_way_penalty,
        clearance=clearance,
        geom_cache=geom_cache,
        all_port_bboxes=all_port_bboxes,
        placement_report=placement_report,
        debug=debug,
    )

    if batch_result is not None:
        batch_trial, batch_routed, batch_failed = batch_result

        if not batch_failed:
            print(f"[MULTINET-COPY] Batch routing succeeded for all {len(nets)} nets")
            return batch_trial, batch_routed

        # Partial batch success — try serial fallback for failed nets
        if batch_routed:
            print(
                f"[MULTINET-COPY] Batch routed {len(batch_routed)}/{len(nets)} nets; "
                f"trying serial fallback for {len(batch_failed)} failed nets"
            )
            remaining_nets = [n for n in nets if n.name in batch_failed]
            serial_routed = _serial_route_on_component(
                batch_trial,
                remaining_nets,
                config,
                grid_unit=grid_unit,
                width=width,
                dynamic_width=dynamic_width,
                layers_to_avoid=layers_to_avoid,
                add_segment_ports=add_segment_ports,
                via_cost=via_cost,
                wrong_way_penalty=wrong_way_penalty,
                clearance=clearance,
                clearance_ladder=clearance_ladder,
                deterministic=deterministic,
                debug=debug,
                geom_cache=geom_cache,
                all_port_bboxes=all_port_bboxes,
                dbu=dbu,
            )
            combined = dict(batch_routed)
            combined.update(serial_routed)

            if len(combined) == len(nets):
                print(
                    f"[MULTINET-COPY] Batch+serial fallback succeeded for all {len(nets)} nets"
                )
                return batch_trial, combined

            # Batch+serial partial — compare against pure serial below
            batch_combined_trial = batch_trial
            batch_combined_routed = combined
        else:
            batch_combined_trial = None
            batch_combined_routed = {}
    else:
        batch_combined_trial = None
        batch_combined_routed = {}

    # --- Phase 2: Serial fallback (existing permutation search) ---
    net_orders = _build_deterministic_net_orders(nets)
    best_trial: Component | None = batch_combined_trial
    best_partial: dict[str, list[Port]] = batch_combined_routed

    for attempt_idx, ordered_nets in enumerate(net_orders, start=1):
        trial = c.copy()
        _draw_port_fills(
            trial, nets, config, width, dynamic_width, geom_cache=geom_cache
        )
        print(
            f"[MULTINET-COPY] Serial attempt {attempt_idx}/{len(net_orders)} order="
            f"{','.join(net.name for net in ordered_nets)}"
        )

        routed: dict[str, list[Port]] = {}
        failed_name: str | None = None

        for net in ordered_nets:
            start_key = (
                int(net.start.dcenter[0] / dbu),
                int(net.start.dcenter[1] / dbu),
            )
            stop_key = (int(net.stop.dcenter[0] / dbu), int(net.stop.dcenter[1] / dbu))
            result = route_multilayer_3d(
                trial,
                start=net.start,
                stop=net.stop,
                config=config,
                grid_unit=grid_unit,
                width=width,
                dynamic_width=dynamic_width,
                layers_to_avoid=layers_to_avoid,
                add_segment_ports=net.is_top_level_pin,
                port_name_prefix=net.port_name_prefix,
                via_cost=via_cost,
                wrong_way_penalty=wrong_way_penalty,
                clearance=clearance,
                clearance_ladder=clearance_ladder,
                deterministic=deterministic,
                debug=debug,
                extra_port_bboxes=all_port_bboxes,
                cached_start_geom=geom_cache.get(start_key),
                cached_stop_geom=geom_cache.get(stop_key),
            )
            if not result.success:
                failed_name = net.name
                print(
                    f"[MULTINET-COPY] net '{net.name}' failed in serial attempt {attempt_idx}"
                    f" (reason={result.failure_reason})"
                )
                break
            routed[net.name] = result.ports

        if failed_name is None and len(routed) == len(nets):
            print(f"[MULTINET-COPY] Serial success on attempt {attempt_idx}")
            return trial, routed

        if len(routed) > len(best_partial):
            best_partial = routed
            best_trial = trial

    if require_all:
        raise RuntimeError(
            "[MULTINET-COPY] Unable to complete all requested nets without obstruction conflicts."
        )
    return (best_trial if best_trial is not None else c.copy()), best_partial


def _try_batch_routing(
    c: Component,
    nets: Sequence[RouteNetSpec],
    config: RoutingConfig,
    grid_unit: float,
    width: float,
    dynamic_width: bool,
    layers_to_avoid: Iterable[LayerSpec],
    add_segment_ports: bool,
    via_cost: float,
    wrong_way_penalty: float,
    clearance: float,
    geom_cache: dict[tuple[int, int], PortGeometry],
    all_port_bboxes: list[tuple[int, int, int, int]],
    placement_report: dict | None,
    debug: bool,
) -> tuple[Component, dict[str, list[Port]], list[str]] | None:
    """Try batch routing on a copy of the component.

    Returns (trial_component, routed_ports, failed_net_names) or None if
    the batch router is unavailable or fails entirely.
    """
    try:
        from .engine_batch import route_batch_multilayer
    except ImportError:
        print("[MULTINET-COPY] Batch router not available (import failed)")
        return None

    # Verify the Rust route_batch function exists
    try:
        from doroutes import doroutes as _doroutes  # type: ignore[attr-defined]

        if not hasattr(_doroutes, "route_batch"):
            print("[MULTINET-COPY] Rust route_batch() not available in doroutes build")
            return None
    except (ImportError, AttributeError):
        print("[MULTINET-COPY] doroutes module not available")
        return None

    trial = c.copy()
    _draw_port_fills(trial, nets, config, width, dynamic_width, geom_cache=geom_cache)

    print(f"[MULTINET-COPY] Trying batch routing (GRT+DRT) for {len(nets)} nets...")

    try:
        routed_ports, failed_names, corners_by_net = route_batch_multilayer(
            trial,
            nets=nets,
            config=config,
            grid_unit=grid_unit,
            width=width,
            dynamic_width=dynamic_width,
            layers_to_avoid=layers_to_avoid,
            add_segment_ports=add_segment_ports,
            via_cost=via_cost,
            wrong_way_penalty=wrong_way_penalty,
            clearance=clearance,
            geom_cache=geom_cache,
            all_port_bboxes=all_port_bboxes,
            placement_report=placement_report,
            debug=debug,
        )
    except Exception as e:
        print(f"[MULTINET-COPY] Batch routing raised exception: {e}")
        return None

    if not routed_ports and failed_names:
        print("[MULTINET-COPY] Batch routing failed for all nets")
        return None

    return trial, routed_ports, failed_names


def _serial_route_on_component(
    trial: Component,
    nets: Sequence[RouteNetSpec],
    config: RoutingConfig,
    grid_unit: float,
    width: float,
    dynamic_width: bool,
    layers_to_avoid: Iterable[LayerSpec],
    add_segment_ports: bool,
    via_cost: float,
    wrong_way_penalty: float,
    clearance: float,
    clearance_ladder: tuple[float, ...],
    deterministic: bool,
    debug: bool,
    geom_cache: dict[tuple[int, int], PortGeometry],
    all_port_bboxes: list[tuple[int, int, int, int]],
    dbu: float,
) -> dict[str, list[Port]]:
    """Route nets serially on an existing component (no copy).

    Only the current net's port bboxes are excluded from obstacles;
    foreign port bboxes remain as obstacles so routes cannot cross them.
    """
    # Build a map from port key → bbox for per-net exclusion lookup.
    _port_key_to_bbox: dict[tuple[int, int], tuple[int, int, int, int]] = {}
    for net in nets:
        for port in (net.start, net.stop):
            key = (int(port.dcenter[0] / dbu), int(port.dcenter[1] / dbu))
            if key in _port_key_to_bbox:
                continue
            if geom_cache and key in geom_cache:
                geom = geom_cache[key]
            else:
                from .port_analysis import _get_port_geometry

                kc = trial.kcl.kcells[trial.name]
                geom = _get_port_geometry(port, kc, dbu, config, default_width=width)
            bbox = (
                geom.orig_bbox_dbu if geom.orig_bbox_dbu is not None else geom.bbox_dbu
            )
            if bbox is not None:
                _port_key_to_bbox[key] = bbox

    routed: dict[str, list[Port]] = {}
    for net in nets:
        start_key = (int(net.start.dcenter[0] / dbu), int(net.start.dcenter[1] / dbu))
        stop_key = (int(net.stop.dcenter[0] / dbu), int(net.stop.dcenter[1] / dbu))

        # Only exclude self-port bboxes from obstacles (not foreign ports).
        self_bboxes = []
        for key in (start_key, stop_key):
            if key in _port_key_to_bbox:
                self_bboxes.append(_port_key_to_bbox[key])

        result = route_multilayer_3d(
            trial,
            start=net.start,
            stop=net.stop,
            config=config,
            grid_unit=grid_unit,
            width=width,
            dynamic_width=dynamic_width,
            layers_to_avoid=layers_to_avoid,
            add_segment_ports=net.is_top_level_pin,
            port_name_prefix=net.port_name_prefix,
            via_cost=via_cost,
            wrong_way_penalty=wrong_way_penalty,
            clearance=clearance,
            clearance_ladder=clearance_ladder,
            deterministic=deterministic,
            debug=debug,
            extra_port_bboxes=self_bboxes,
            cached_start_geom=geom_cache.get(start_key),
            cached_stop_geom=geom_cache.get(stop_key),
        )
        if result.success:
            routed[net.name] = result.ports
        else:
            print(
                f"[MULTINET-COPY] serial fallback net '{net.name}' failed "
                f"(reason={result.failure_reason})"
            )
    return routed
