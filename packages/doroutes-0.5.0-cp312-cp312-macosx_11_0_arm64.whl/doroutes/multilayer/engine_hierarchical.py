"""Hierarchical two-phase A* routing engine — config-dependent."""

from collections.abc import Iterable

import numpy as np
from gdsfactory.component import Component
from gdsfactory.typings import LayerSpec, Port

from .config import RoutingConfig
from .draw import (
    _draw_dynamic_geometry_for_corners,
    _draw_route_segments,
)
from .geometry import (
    _bbox_overlap,
    _segment_envelope_um,
    _via_envelope_um,
)
from .obstacles import _extract_polys_for_layers
from .path import (
    _calc_path_length,
    _is_horizontal,
    _is_valid_manhattan_path,
    _make_manhattan,
    _simplify_path,
)
from .port_analysis import (
    _get_port_geometry,
    _get_pos_with_dir,
)
from .via_planning import _is_via_legal_on_both_layers, _via_pad_size_um


def _deterministic_clearance_attempts(
    clearance: float,
    clearance_ladder: tuple[float, ...],
) -> list[float]:
    """Return deterministic clearance attempts: requested first, then ladder order."""
    attempts: list[float] = []
    if clearance > 0:
        attempts.append(float(clearance))
    for c in clearance_ladder:
        c = float(c)
        if c > 0 and c not in attempts:
            attempts.append(c)
    return attempts


def _run_astar_rectilinear(
    polys: list,
    start_pos: tuple[int, int, str],
    stop_pos: tuple[int, int, str],
    bbox_tuple: tuple[int, int, int, int],
    grid_unit_dbu: int,
    straight_width: int,
    bend_radius: int,
) -> list[tuple[int, int]] | None:
    """Low-level A* rectilinear routing call."""
    from doroutes import doroutes as _doroutes  # type: ignore[attr-defined]

    rectilinear_bend = [(i, 0) for i in range(1, bend_radius + 1)] + [
        (bend_radius, i) for i in range(1, bend_radius + 1)
    ]

    try:
        print(straight_width)
        print(grid_unit_dbu)
        corners = _doroutes.show(
            polys=polys,
            start=start_pos,
            stop=stop_pos,
            bbox=bbox_tuple,
            grid_unit=grid_unit_dbu,
            straight_width=straight_width,
            discretized_bend_east_to_north=rectilinear_bend,
        )
        return corners
    except Exception as e:
        print(f"A* failed: {e}")
        return None


def route_hierarchical_astar(
    c: Component,
    start: Port,
    stop: Port,
    config: RoutingConfig,
    global_grid_unit: float = 2.0,
    detail_grid_unit: float = 0.25,
    width: float = 0.25,
    layers_to_avoid: Iterable[LayerSpec] | None = None,
    detail_margin: float = 5.0,
    clearance: float = 0.14,
) -> list[tuple[float, float]] | None:
    """Hierarchical two-phase routing: global then detailed."""
    if layers_to_avoid is None:
        layers_to_avoid = []

    dbu = c.kcl.dbu
    kc = c.kcl.kcells[c.name]

    _layers = [
        layer if isinstance(layer, tuple) else (layer, 0) for layer in layers_to_avoid
    ]

    start_pos = _get_pos_with_dir(start, dbu)
    stop_pos = _get_pos_with_dir(stop, dbu)

    port_points = [
        (start_pos[0], start_pos[1]),
        (stop_pos[0], stop_pos[1]),
    ]

    buffer_dbu = int(round(max(0.0, clearance) / dbu))
    polys = _extract_polys_for_layers(
        kc, _layers, dbu, port_points, buffer_dbu=buffer_dbu
    )

    stop_dir_map = {"n": "s", "s": "n", "e": "w", "w": "e", "o": "o"}
    stop_pos = (stop_pos[0], stop_pos[1], stop_dir_map[stop_pos[2]])

    start_x, start_y = start_pos[0], start_pos[1]
    stop_x, stop_y = stop_pos[0], stop_pos[1]
    dist = max(abs(stop_x - start_x), abs(stop_y - start_y))
    padding = int(dist * 0.5)

    comp_bbox = kc.bbox()
    min_x = min(start_x, stop_x, comp_bbox.left) - padding
    max_x = max(start_x, stop_x, comp_bbox.right) + padding
    min_y = min(start_y, stop_y, comp_bbox.bottom) - padding
    max_y = max(start_y, stop_y, comp_bbox.top) + padding

    bbox_tuple = (max_y, max_x, min_y, min_x)

    # ========== PHASE 1: GLOBAL ROUTING ==========
    print(f"[GLOBAL] Routing with grid_unit={global_grid_unit}um...")

    global_grid_dbu = int(global_grid_unit / dbu)
    width_dbu = int(width / dbu)
    global_straight_width = max(1, width_dbu // global_grid_dbu + 1)
    global_straight_width += (global_straight_width + 1) % 2
    global_bend_radius = max(1, (width_dbu + global_grid_dbu - 1) // global_grid_dbu)

    global_corners = _run_astar_rectilinear(
        polys=polys,
        start_pos=start_pos,
        stop_pos=stop_pos,
        bbox_tuple=bbox_tuple,
        grid_unit_dbu=global_grid_dbu,
        straight_width=global_straight_width,
        bend_radius=global_bend_radius,
    )

    if global_corners is None:
        print("[GLOBAL] Retrying with relaxed orientations...")
        start_relaxed = (start_pos[0], start_pos[1], "o")
        stop_relaxed = (stop_pos[0], stop_pos[1], "o")
        global_corners = _run_astar_rectilinear(
            polys=polys,
            start_pos=start_relaxed,
            stop_pos=stop_relaxed,
            bbox_tuple=bbox_tuple,
            grid_unit_dbu=global_grid_dbu,
            straight_width=global_straight_width,
            bend_radius=global_bend_radius,
        )

    if not global_corners or len(global_corners) < 2:
        print("[GLOBAL] No route found!")
        return None

    print(f"[GLOBAL] Found path with {len(global_corners)} corners")

    global_path_um = [(p[0] * dbu, p[1] * dbu) for p in global_corners]

    if not polys or detail_grid_unit >= global_grid_unit:
        print("[DETAIL] Skipping (no obstructions or detail not finer than global)")
        return global_path_um

    # ========== PHASE 2: DETAILED ROUTING ==========
    print(f"[DETAIL] Refining with grid_unit={detail_grid_unit}um...")

    detail_grid_dbu = int(detail_grid_unit / dbu)
    detail_straight_width = max(int(width), width_dbu // detail_grid_dbu + 1)
    detail_straight_width += (detail_straight_width + 1) % 2
    detail_bend_radius = max(1, (width_dbu + detail_grid_dbu - 1) // detail_grid_dbu)
    margin_dbu = int(detail_margin / dbu)

    refined_path = [global_corners[0]]

    for i in range(len(global_corners) - 1):
        seg_start = global_corners[i]
        seg_end = global_corners[i + 1]

        seg_min_x = min(seg_start[0], seg_end[0]) - margin_dbu
        seg_max_x = max(seg_start[0], seg_end[0]) + margin_dbu
        seg_min_y = min(seg_start[1], seg_end[1]) - margin_dbu
        seg_max_y = max(seg_start[1], seg_end[1]) + margin_dbu
        seg_bbox = (seg_max_y, seg_max_x, seg_min_y, seg_min_x)

        dx = seg_end[0] - seg_start[0]
        dy = seg_end[1] - seg_start[1]

        if abs(dx) > abs(dy):
            start_dir = "e" if dx > 0 else "w"
            end_dir = "w" if dx > 0 else "e"
        else:
            start_dir = "n" if dy > 0 else "s"
            end_dir = "s" if dy > 0 else "n"

        seg_start_pos = (seg_start[0], seg_start[1], start_dir)
        seg_end_pos = (seg_end[0], seg_end[1], end_dir)

        print("detailed...")
        detail_corners = _run_astar_rectilinear(
            polys=polys,
            start_pos=seg_start_pos,
            stop_pos=seg_end_pos,
            bbox_tuple=seg_bbox,
            grid_unit_dbu=detail_grid_dbu,
            straight_width=detail_straight_width,
            bend_radius=detail_bend_radius,
        )
        detail_corners = None

        if detail_corners and len(detail_corners) > 1:
            refined_path.extend(detail_corners[1:])
        else:
            refined_path.append(seg_end)

    print(f"[DETAIL] Refined path has {len(refined_path)} corners")

    refined_path_um = [(p[0] * dbu, p[1] * dbu) for p in refined_path]
    return refined_path_um


def route_hierarchical(
    c: Component,
    start: Port,
    stop: Port,
    config: RoutingConfig,
    global_grid_unit: float = 2.0,
    detail_grid_unit: float = 0.25,
    width: float = 0.25,
    layers_to_avoid: Iterable[LayerSpec] | None = None,
    detail_margin: float = 5.0,
    clearance: float = 0.14,
    clearance_ladder: tuple[float, ...] = (0.14, 0.10, 0.07),
    deterministic: bool = True,
    add_segment_ports: bool = False,
    port_name_prefix: str = "seg",
    dynamic_width: bool = True,
    start_xy_override_um: tuple[float, float] | None = None,
    stop_xy_override_um: tuple[float, float] | None = None,
    port_exclusion_points_um: list[tuple[float, float]] | None = None,
) -> list[Port]:
    """Route using hierarchical two-phase approach: global then detailed."""
    LAYER_M1 = config.layer_m1
    LAYER_M2 = config.layer_m2

    dbu = c.kcl.dbu
    kc = c.kcl.kcells[c.name]
    _layers = [
        layer if isinstance(layer, tuple) else (layer, 0)
        for layer in (layers_to_avoid or [])
    ]

    start_x = start_xy_override_um[0] if start_xy_override_um else start.dcenter[0]
    start_y = start_xy_override_um[1] if start_xy_override_um else start.dcenter[1]
    stop_x = stop_xy_override_um[0] if stop_xy_override_um else stop.dcenter[0]
    stop_y = stop_xy_override_um[1] if stop_xy_override_um else stop.dcenter[1]
    orig_start_x = start.dcenter[0]
    orig_start_y = start.dcenter[1]
    orig_stop_x = stop.dcenter[0]
    orig_stop_y = stop.dcenter[1]
    start_dbu = (int(orig_start_x / dbu), int(orig_start_y / dbu))
    stop_dbu = (int(orig_stop_x / dbu), int(orig_stop_y / dbu))
    if port_exclusion_points_um:
        port_points_um = list(port_exclusion_points_um)
    else:
        port_points_um = [(orig_start_x, orig_start_y), (orig_stop_x, orig_stop_y)]
    port_points_dbu = [start_dbu, stop_dbu]

    def _get_layer_tuple_local(port: Port, component: Component):
        if hasattr(port, "layer"):
            info = component.kcl.get_info(port.layer)
            return (info.layer, info.datatype)
        return None

    def _poly_bboxes_um(
        polys: list[np.ndarray],
    ) -> list[tuple[float, float, float, float]]:
        bboxes = []
        for poly in polys:
            if len(poly) < 3:
                continue
            x0 = float(poly[:, 0].min()) * dbu
            x1 = float(poly[:, 0].max()) * dbu
            y0 = float(poly[:, 1].min()) * dbu
            y1 = float(poly[:, 1].max()) * dbu
            bboxes.append((x0, y0, x1, y1))
        return bboxes

    def _bbox_contains_any_point(
        bbox: tuple[float, float, float, float],
        points: list[tuple[float, float]],
    ) -> bool:
        x0, y0, x1, y1 = bbox
        for px, py in points:
            if x0 <= px <= x1 and y0 <= py <= y1:
                return True
        return False

    path = route_hierarchical_astar(
        c=c,
        start=start,
        stop=stop,
        config=config,
        global_grid_unit=global_grid_unit,
        detail_grid_unit=detail_grid_unit,
        width=width,
        layers_to_avoid=layers_to_avoid,
        detail_margin=detail_margin,
        clearance=clearance,
    )

    use_m2_horiz = False
    if path is not None and len(path) >= 2:
        path = _simplify_path(_make_manhattan(path))
        start_layer = _get_layer_tuple_local(start, c)
        stop_layer = _get_layer_tuple_local(stop, c)

        buffer_dbu = int(round(max(0.0, clearance) / dbu))
        m1_polys = (
            _extract_polys_for_layers(
                kc, [LAYER_M1], dbu, port_points_dbu, buffer_dbu=buffer_dbu
            )
            if LAYER_M1 in _layers
            else []
        )
        m2_polys = (
            _extract_polys_for_layers(
                kc, [LAYER_M2], dbu, port_points_dbu, buffer_dbu=buffer_dbu
            )
            if LAYER_M2 in _layers
            else []
        )
        m1_bboxes = [
            b
            for b in _poly_bboxes_um(m1_polys)
            if not _bbox_contains_any_point(b, port_points_um)
        ]
        m2_bboxes = [
            b
            for b in _poly_bboxes_um(m2_polys)
            if not _bbox_contains_any_point(b, port_points_um)
        ]

        path_blocked = False
        for i in range(len(path) - 1):
            p0 = path[i]
            p1 = path[i + 1]
            seg_layer = LAYER_M1 if _is_horizontal(p0, p1) else LAYER_M2
            seg_box = _segment_envelope_um(p0, p1, width)
            target = m1_bboxes if seg_layer == LAYER_M1 else m2_bboxes
            if any(_bbox_overlap(seg_box, obox) for obox in target):
                path_blocked = True
                break

        if not path_blocked:
            via_points = []
            if len(path) >= 3:
                via_points.extend(path[1:-1])
            first_layer = LAYER_M1 if _is_horizontal(path[0], path[1]) else LAYER_M2
            if start_layer and start_layer != first_layer:
                via_points.append(path[0])
            last_layer = LAYER_M1 if _is_horizontal(path[-2], path[-1]) else LAYER_M2
            if stop_layer and stop_layer != last_layer:
                via_points.append(path[-1])

            via_w = _via_pad_size_um(width, config)
            for vpt in via_points:
                if not _is_via_legal_on_both_layers(
                    vpt, via_w, m1_bboxes, m2_bboxes, config
                ):
                    path_blocked = True
                    break

        if path_blocked:
            print(
                "[ROUTE] Initial A* path violates corner/via obstruction clearance; "
                "switching to via-escape search."
            )
            path = None

    if path is None:
        print(
            "[VIA-ESCAPE] M1 routing blocked - trying deterministic escape routing..."
        )

        x_tolerance = 0.01
        y_tolerance = 0.01
        ports_vertically_aligned = abs(start_x - stop_x) < x_tolerance
        ports_horizontally_aligned = abs(start_y - stop_y) < y_tolerance

        def _candidate_uses_m2_horiz(name: str) -> bool:
            return name == "direct_m2_horizontal"

        def _count_bends(candidate_path: list[tuple[float, float]]) -> int:
            return max(0, len(candidate_path) - 2)

        def _candidate_via_points(
            candidate_path: list[tuple[float, float]],
            use_m2_horiz: bool,
            start_layer: tuple[int, int] | None,
            stop_layer: tuple[int, int] | None,
        ) -> list[tuple[float, float]]:
            via_points = []
            if len(candidate_path) >= 3 and not use_m2_horiz:
                via_points.extend(candidate_path[1:-1])
            if len(candidate_path) >= 2:
                first_horiz = _is_horizontal(candidate_path[0], candidate_path[1])
                first_layer = (
                    LAYER_M2
                    if use_m2_horiz
                    else (LAYER_M1 if first_horiz else LAYER_M2)
                )
                if start_layer and start_layer != first_layer:
                    via_points.append(candidate_path[0])
                last_horiz = _is_horizontal(candidate_path[-2], candidate_path[-1])
                last_layer = (
                    LAYER_M2 if use_m2_horiz else (LAYER_M1 if last_horiz else LAYER_M2)
                )
                if stop_layer and stop_layer != last_layer:
                    via_points.append(candidate_path[-1])
            seen = set()
            unique_points = []
            for x, y in via_points:
                key = (round(x / dbu), round(y / dbu))
                if key not in seen:
                    seen.add(key)
                    unique_points.append((x, y))
            return unique_points

        def _candidate_blocking_boxes(
            candidate_path: list[tuple[float, float]],
            use_m2_horiz: bool,
            m1_bboxes: list[tuple[float, float, float, float]],
            m2_bboxes: list[tuple[float, float, float, float]],
            via_pad_w: float,
            via_pad_h: float,
            start_layer: tuple[int, int] | None,
            stop_layer: tuple[int, int] | None,
        ) -> list[tuple[float, float, float, float]]:
            blocking = []
            for i in range(len(candidate_path) - 1):
                p0 = candidate_path[i]
                p1 = candidate_path[i + 1]
                is_h = _is_horizontal(p0, p1)
                seg_layer = (
                    LAYER_M2 if use_m2_horiz else (LAYER_M1 if is_h else LAYER_M2)
                )
                seg_box = _segment_envelope_um(p0, p1, width)
                target_bboxes = m1_bboxes if seg_layer == LAYER_M1 else m2_bboxes
                for obox in target_bboxes:
                    if _bbox_overlap(seg_box, obox):
                        blocking.append(obox)
            via_points = _candidate_via_points(
                candidate_path, use_m2_horiz, start_layer, stop_layer
            )
            for vpt in via_points:
                if not _is_via_legal_on_both_layers(
                    vpt, max(via_pad_w, via_pad_h), m1_bboxes, m2_bboxes, config
                ):
                    blocking.append((vpt[0], vpt[1], vpt[0], vpt[1]))
            return blocking

        clearance_attempts = (
            _deterministic_clearance_attempts(clearance, clearance_ladder)
            if deterministic
            else [max(0.0, float(clearance))]
        )
        if not clearance_attempts:
            clearance_attempts = [0.0]

        use_m2_horiz = False
        start_layer = _get_layer_tuple_local(start, c)
        stop_layer = _get_layer_tuple_local(stop, c)

        for attempt_idx, clearance_try in enumerate(clearance_attempts, start=1):
            buffer_dbu = int(round(max(0.0, clearance_try) / dbu))
            m1_polys = (
                _extract_polys_for_layers(
                    kc,
                    [LAYER_M1],
                    dbu,
                    port_points_dbu,
                    buffer_dbu=buffer_dbu,
                )
                if LAYER_M1 in _layers
                else []
            )
            m2_polys = (
                _extract_polys_for_layers(
                    kc,
                    [LAYER_M2],
                    dbu,
                    port_points_dbu,
                    buffer_dbu=buffer_dbu,
                )
                if LAYER_M2 in _layers
                else []
            )
            m1_bboxes = [
                b
                for b in _poly_bboxes_um(m1_polys)
                if not _bbox_contains_any_point(b, port_points_um)
            ]
            m2_bboxes = [
                b
                for b in _poly_bboxes_um(m2_polys)
                if not _bbox_contains_any_point(b, port_points_um)
            ]
            print(
                f"[VIA-ESCAPE] attempt {attempt_idx}/{len(clearance_attempts)} "
                f"clearance={clearance_try:.3f}um m1_obs={len(m1_bboxes)} m2_obs={len(m2_bboxes)}"
            )

            direct_candidates = [
                (
                    "direct_h_first",
                    [
                        (start_x, start_y),
                        (stop_x, start_y),
                        (stop_x, stop_y),
                    ],
                ),
                (
                    "direct_v_first",
                    [
                        (start_x, start_y),
                        (start_x, stop_y),
                        (stop_x, stop_y),
                    ],
                ),
            ]
            if ports_vertically_aligned:
                direct_candidates.append(
                    ("direct_vertical", [(start_x, start_y), (stop_x, stop_y)])
                )
            if ports_horizontally_aligned:
                direct_candidates.append(
                    ("direct_horizontal", [(start_x, start_y), (stop_x, stop_y)])
                )
                direct_candidates.append(
                    (
                        "direct_m2_horizontal",
                        [(start_x, start_y), (stop_x, stop_y)],
                    )
                )

            direct_blockers = []
            for name, candidate in direct_candidates:
                simp = _simplify_path(candidate)
                if not _is_valid_manhattan_path(simp):
                    continue
                direct_blockers.extend(
                    _candidate_blocking_boxes(
                        simp,
                        _candidate_uses_m2_horiz(name),
                        m1_bboxes,
                        m2_bboxes,
                        _via_pad_size_um(width, config),
                        _via_pad_size_um(width, config),
                        start_layer,
                        stop_layer,
                    )
                )

            if direct_blockers:
                blocker_x_min = min(b[0] for b in direct_blockers)
                blocker_y_min = min(b[1] for b in direct_blockers)
                blocker_x_max = max(b[2] for b in direct_blockers)
                blocker_y_max = max(b[3] for b in direct_blockers)
            else:
                blocker_x_min = min(start_x, stop_x) - clearance_try
                blocker_y_min = min(start_y, stop_y) - clearance_try
                blocker_x_max = max(start_x, stop_x) + clearance_try
                blocker_y_max = max(start_y, stop_y) + clearance_try

            min_escape = max(1.0, width + clearance_try)
            blocker_x_min = min(blocker_x_min, min(start_x, stop_x) - min_escape)
            blocker_y_min = min(blocker_y_min, min(start_y, stop_y) - min_escape)
            blocker_x_max = max(blocker_x_max, max(start_x, stop_x) + min_escape)
            blocker_y_max = max(blocker_y_max, max(start_y, stop_y) + min_escape)

            escape_x_left = blocker_x_min - clearance_try
            escape_x_right = blocker_x_max + clearance_try
            escape_y_top = blocker_y_max + clearance_try
            escape_y_bottom = blocker_y_min - clearance_try
            far_delta = max(2.0, 2.0 * min_escape)
            escape_x_left_far = escape_x_left - far_delta
            escape_x_right_far = escape_x_right + far_delta
            escape_y_top_far = escape_y_top + far_delta
            escape_y_bottom_far = escape_y_bottom - far_delta

            candidate_paths = list(direct_candidates)
            candidate_paths.extend(
                [
                    (
                        "escape_left",
                        [
                            (start_x, start_y),
                            (escape_x_left, start_y),
                            (escape_x_left, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "escape_right",
                        [
                            (start_x, start_y),
                            (escape_x_right, start_y),
                            (escape_x_right, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "escape_top",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_top),
                            (stop_x, escape_y_top),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "escape_bottom",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_bottom),
                            (stop_x, escape_y_bottom),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "escape_left_far",
                        [
                            (start_x, start_y),
                            (escape_x_left_far, start_y),
                            (escape_x_left_far, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "escape_right_far",
                        [
                            (start_x, start_y),
                            (escape_x_right_far, start_y),
                            (escape_x_right_far, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "escape_top_far",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_top_far),
                            (stop_x, escape_y_top_far),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "escape_bottom_far",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_bottom_far),
                            (stop_x, escape_y_bottom_far),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "s_up_left",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_top),
                            (escape_x_left, escape_y_top),
                            (escape_x_left, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "s_up_right",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_top),
                            (escape_x_right, escape_y_top),
                            (escape_x_right, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "s_down_left",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_bottom),
                            (escape_x_left, escape_y_bottom),
                            (escape_x_left, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "s_down_right",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_bottom),
                            (escape_x_right, escape_y_bottom),
                            (escape_x_right, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "s_up_left_far",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_top_far),
                            (escape_x_left_far, escape_y_top_far),
                            (escape_x_left_far, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "s_up_right_far",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_top_far),
                            (escape_x_right_far, escape_y_top_far),
                            (escape_x_right_far, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "s_down_left_far",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_bottom_far),
                            (escape_x_left_far, escape_y_bottom_far),
                            (escape_x_left_far, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                    (
                        "s_down_right_far",
                        [
                            (start_x, start_y),
                            (start_x, escape_y_bottom_far),
                            (escape_x_right_far, escape_y_bottom_far),
                            (escape_x_right_far, stop_y),
                            (stop_x, stop_y),
                        ],
                    ),
                ]
            )

            best_choice = None
            for name, candidate in candidate_paths:
                simplified = _simplify_path(candidate)
                if not _is_valid_manhattan_path(simplified):
                    print(f"[VIA-ESCAPE] Path '{name}': INVALID")
                    continue

                use_m2_horiz_candidate = _candidate_uses_m2_horiz(name)
                via_points = _candidate_via_points(
                    simplified, use_m2_horiz_candidate, start_layer, stop_layer
                )
                via_pad_w = _via_pad_size_um(width, config)
                via_pad_h = via_pad_w
                blocking = _candidate_blocking_boxes(
                    simplified,
                    use_m2_horiz_candidate,
                    m1_bboxes,
                    m2_bboxes,
                    via_pad_w,
                    via_pad_h,
                    start_layer,
                    stop_layer,
                )
                is_blocked = len(blocking) > 0
                length = _calc_path_length(simplified)
                bends = _count_bends(simplified)
                vias = len(via_points)
                lex_key = tuple(
                    (int(round(px / dbu)), int(round(py / dbu)))
                    for px, py in simplified
                )
                rank = (length, vias, bends, lex_key) if deterministic else (length,)
                print(
                    f"[VIA-ESCAPE] Path '{name}': length={length:.3f}um vias={vias} bends={bends} "
                    f"{'BLOCKED' if is_blocked else 'CLEAR'}"
                )
                if is_blocked:
                    continue
                if best_choice is None or rank < best_choice["rank"]:
                    best_choice = {
                        "name": name,
                        "path": simplified,
                        "rank": rank,
                        "length": length,
                        "use_m2_horiz": use_m2_horiz_candidate,
                    }

            if best_choice is not None:
                path = best_choice["path"]
                use_m2_horiz = best_choice["use_m2_horiz"]
                print(
                    f"[VIA-ESCAPE] Selected '{best_choice['name']}' on clearance {clearance_try:.3f}um "
                    f"(length={best_choice['length']:.3f}um)"
                )
                break

    if "use_m2_horiz" not in locals():
        use_m2_horiz = False

    if path is None:
        print("Hierarchical routing failed - no path found on M1 or M2")
        return []

    path[0] = (float(start.dcenter[0]), float(start.dcenter[1]))
    path[-1] = (float(stop.dcenter[0]), float(stop.dcenter[1]))

    path = _make_manhattan(path)
    path = _simplify_path(path)

    print(f"Route from {start.dcenter} to {stop.dcenter}")
    print(f"Final path ({len(path)} points): {path}")

    horiz_layer = LAYER_M2 if use_m2_horiz else LAYER_M1
    vert_layer = LAYER_M2
    add_vias = not use_m2_horiz

    via_guard_buffer_dbu = int(round(max(0.0, clearance) / dbu))
    via_guard_m1 = _extract_polys_for_layers(
        kc, [LAYER_M1], dbu, port_points_dbu, buffer_dbu=via_guard_buffer_dbu
    )
    via_guard_m2 = _extract_polys_for_layers(
        kc, [LAYER_M2], dbu, port_points_dbu, buffer_dbu=via_guard_buffer_dbu
    )
    m1_via_bboxes = [
        b
        for b in _poly_bboxes_um(via_guard_m1)
        if not _bbox_contains_any_point(b, port_points_um)
    ]
    m2_via_bboxes = [
        b
        for b in _poly_bboxes_um(via_guard_m2)
        if not _bbox_contains_any_point(b, port_points_um)
    ]

    if dynamic_width:
        start_geom = _get_port_geometry(start, kc, dbu, config, default_width=width)
        stop_geom = _get_port_geometry(stop, kc, dbu, config, default_width=width)
        body_width = max(config.min_width(LAYER_M1), width)

        def _layer_idx_from_tuple(
            layer_tuple: tuple[int, int] | None, default_idx: int
        ) -> int:
            if layer_tuple == LAYER_M2:
                return 1
            if layer_tuple == LAYER_M1:
                return 0
            return default_idx

        def _segment_layer_idx(p0: tuple[float, float], p1: tuple[float, float]) -> int:
            is_h = _is_horizontal(p0, p1)
            if is_h:
                return 1 if use_m2_horiz else 0
            return 1

        if len(path) < 2:
            return []

        start_layer_tuple = _get_layer_tuple_local(start, c)
        stop_layer_tuple = _get_layer_tuple_local(stop, c)

        def _build_corners_from_path(
            path_pts: list[tuple[float, float]],
        ) -> list[tuple[int, int, int]]:
            first_seg_layer = _segment_layer_idx(path_pts[0], path_pts[1])
            current_layer = _layer_idx_from_tuple(start_layer_tuple, first_seg_layer)
            x0 = int(round(path_pts[0][0] / dbu))
            y0 = int(round(path_pts[0][1] / dbu))
            out: list[tuple[int, int, int]] = [(x0, y0, current_layer)]
            if current_layer != first_seg_layer:
                out.append((x0, y0, first_seg_layer))
            for i in range(len(path_pts) - 1):
                sx = int(round(path_pts[i][0] / dbu))
                sy = int(round(path_pts[i][1] / dbu))
                ex = int(round(path_pts[i + 1][0] / dbu))
                ey = int(round(path_pts[i + 1][1] / dbu))
                seg_layer = _segment_layer_idx(path_pts[i], path_pts[i + 1])
                if out[-1][0] != sx or out[-1][1] != sy:
                    out.append((sx, sy, out[-1][2]))
                if out[-1][2] != seg_layer:
                    out.append((sx, sy, seg_layer))
                out.append((ex, ey, seg_layer))
            last_seg_layer = _segment_layer_idx(path_pts[-2], path_pts[-1])
            stop_layer_idx = _layer_idx_from_tuple(stop_layer_tuple, last_seg_layer)
            if out[-1][2] != stop_layer_idx:
                out.append((out[-1][0], out[-1][1], stop_layer_idx))
            return out

        corners_3d = _build_corners_from_path(path)
        dyn_ports = _draw_dynamic_geometry_for_corners(
            c=c,
            corners_3d=corners_3d,
            start_geom=start_geom,
            stop_geom=stop_geom,
            body_width=body_width,
            width=width,
            dynamic_width=True,
            m1_polys=via_guard_m1,
            m2_polys=via_guard_m2,
            start_xy_dbu=(
                int(round(orig_start_x / dbu)),
                int(round(orig_start_y / dbu)),
            ),
            stop_xy_dbu=(
                int(round(orig_stop_x / dbu)),
                int(round(orig_stop_y / dbu)),
            ),
            dbu=dbu,
            clearance=clearance,
            add_segment_ports=add_segment_ports,
            port_name_prefix=port_name_prefix,
            config=config,
        )
        if dyn_ports is not None:
            return dyn_ports
        print(
            "[ROUTE] Dynamic fallback geometry blocked; downgrading to fixed-width fallback."
        )

    for i in range(len(path) - 1):
        p0 = path[i]
        p1 = path[i + 1]
        seg_layer = horiz_layer if _is_horizontal(p0, p1) else vert_layer
        seg_box = _segment_envelope_um(p0, p1, width)
        seg_obs = m1_via_bboxes if seg_layer == LAYER_M1 else m2_via_bboxes
        if any(_bbox_overlap(seg_box, obox) for obox in seg_obs):
            print(
                "[ROUTE] Final planned segment blocked on "
                f"{'M1' if seg_layer == LAYER_M1 else 'M2'}; aborting route."
            )
            return []

    if horiz_layer == vert_layer and len(path) >= 3:
        patch_obs = m1_via_bboxes if horiz_layer == LAYER_M1 else m2_via_bboxes
        for corner in path[1:-1]:
            patch_box = _via_envelope_um(corner, width, width)
            if any(_bbox_overlap(patch_box, obox) for obox in patch_obs):
                print(
                    "[ROUTE] Final planned corner patch blocked on "
                    f"{'M1' if horiz_layer == LAYER_M1 else 'M2'} at "
                    f"({corner[0]:.3f}, {corner[1]:.3f}); aborting route."
                )
                return []

    if add_vias:
        via_pad = _via_pad_size_um(width, config)
        for via_pt in path[1:-1]:
            if not _is_via_legal_on_both_layers(
                via_pt, via_pad, m1_via_bboxes, m2_via_bboxes, config
            ):
                print(
                    "[ROUTE] Intermediate via blocked on M1/M2 at "
                    f"({via_pt[0]:.3f}, {via_pt[1]:.3f}); aborting route."
                )
                return []

    start_transition_via = None
    stop_transition_via = None
    if len(path) >= 2:
        first_horiz = _is_horizontal(path[0], path[1])
        first_layer = horiz_layer if first_horiz else vert_layer

        def _get_layer_tuple(port: Port, component: Component):
            if hasattr(port, "layer"):
                layer_idx = port.layer
                info = component.kcl.get_info(layer_idx)
                return (info.layer, info.datatype)
            return None

        start_layer = _get_layer_tuple(start, c)
        if start_layer and start_layer != first_layer:
            start_transition_via = path[0]
            via_w = _via_pad_size_um(width, config)
            if not _is_via_legal_on_both_layers(
                start_transition_via, via_w, m1_via_bboxes, m2_via_bboxes, config
            ):
                print(
                    "[ROUTE] Start transition via blocked on M1/M2 at "
                    f"({start_transition_via[0]:.3f}, {start_transition_via[1]:.3f}); aborting route."
                )
                return []

        last_horiz = _is_horizontal(path[-2], path[-1])
        last_layer = horiz_layer if last_horiz else vert_layer
        stop_layer = _get_layer_tuple(stop, c)
        if stop_layer and stop_layer != last_layer:
            stop_transition_via = path[-1]
            via_w = _via_pad_size_um(width, config)
            if not _is_via_legal_on_both_layers(
                stop_transition_via, via_w, m1_via_bboxes, m2_via_bboxes, config
            ):
                print(
                    "[ROUTE] Stop transition via blocked on M1/M2 at "
                    f"({stop_transition_via[0]:.3f}, {stop_transition_via[1]:.3f}); aborting route."
                )
                return []

    segment_ports = _draw_route_segments(
        c,
        path,
        width,
        config=config,
        add_segment_ports=add_segment_ports,
        port_name_prefix=port_name_prefix,
        horizontal_layer=horiz_layer,
        vertical_layer=vert_layer,
        add_vias=add_vias,
    )

    if start_transition_via is not None:
        via_w = _via_pad_size_um(width, config)
        via = c.add_ref(config.via_factory(width=via_w, length=via_w))
        via.dcenter = start_transition_via

    if stop_transition_via is not None:
        via_w = _via_pad_size_um(width, config)
        via = c.add_ref(config.via_factory(width=via_w, length=via_w))
        via.dcenter = stop_transition_via

    return segment_ports
