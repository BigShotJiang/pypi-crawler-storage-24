"""Manhattan path manipulation — zero PDK references."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .config import PortGeometry

# ---------------------------------------------------------------------------
# 3D corner cleanup passes (operate on List[Tuple[int, int, int]])
# ---------------------------------------------------------------------------


def _manhattanize_corners(
    corners_3d: list[tuple[int, int, int]],
) -> list[tuple[int, int, int]]:
    """Insert jog points where same-layer corners are diagonal.

    Via transitions (different layer) pass through unchanged.
    Even-indexed layers jog horizontal-first; odd layers vertical-first.
    """
    if not corners_3d:
        return []
    result = [corners_3d[0]]
    for i in range(1, len(corners_3d)):
        prev = result[-1]
        curr = corners_3d[i]
        if prev[2] != curr[2]:
            result.append(curr)
            continue
        dx = abs(curr[0] - prev[0])
        dy = abs(curr[1] - prev[1])
        if dx > 1 and dy > 1:
            layer_idx = curr[2]
            if layer_idx % 2 == 0:
                result.append((curr[0], prev[1], layer_idx))
            else:
                result.append((prev[0], curr[1], layer_idx))
        result.append(curr)
    return result


def _straighten_via_jogs(
    corners_3d: list[tuple[int, int, int]],
    dbu: float,
    threshold_um: float = 3.0,
) -> list[tuple[int, int, int]]:
    """Align via transition points to neighbouring segment axis when close.

    Looks for the pattern prev(Z) ─ via_start(Z) ─ via_end(Z') ─ next(Z')
    where prev and next share an axis coordinate.  If the via is within
    *threshold_um* of that axis, snap the via pair onto it.

    Modifies and returns the list (may be in-place on a copy).
    """
    pts = list(corners_3d)
    if len(pts) < 4:
        return pts
    for i in range(1, len(pts) - 2):
        p_prev = pts[i - 1]
        p_via_start = pts[i]
        p_via_end = pts[i + 1]
        p_next = pts[i + 2]
        if p_via_start[2] == p_via_end[2]:
            continue
        if p_prev[2] != p_via_start[2] or p_via_end[2] != p_next[2]:
            continue
        if abs(p_prev[1] - p_next[1]) < 1:
            common_y = p_prev[1]
            if (
                abs(p_via_start[1] - common_y) > 0
                and abs(p_via_start[1] - common_y) * dbu < threshold_um
            ):
                pts[i] = (p_via_start[0], common_y, p_via_start[2])
                pts[i + 1] = (p_via_end[0], common_y, p_via_end[2])
        elif abs(p_prev[0] - p_next[0]) < 1:
            common_x = p_prev[0]
            if (
                abs(p_via_start[0] - common_x) > 0
                and abs(p_via_start[0] - common_x) * dbu < threshold_um
            ):
                pts[i] = (common_x, p_via_start[1], p_via_start[2])
                pts[i + 1] = (common_x, p_via_end[1], p_via_end[2])
    return pts


def _force_endpoints(
    corners_3d: list[tuple[int, int, int]],
    start_xy: tuple[int, int],
    stop_xy: tuple[int, int],
) -> list[tuple[int, int, int]]:
    """Override first/last corner XY and insert jogs to stay Manhattan.

    After setting the endpoint coordinates, if the first or last same-layer
    segment becomes diagonal, an intermediate corner is inserted.
    """
    if len(corners_3d) < 2:
        return list(corners_3d)
    pts = list(corners_3d)
    pts[0] = (start_xy[0], start_xy[1], pts[0][2])
    pts[-1] = (stop_xy[0], stop_xy[1], pts[-1][2])

    # Fix diagonal at start
    if pts[0][2] == pts[1][2]:
        dx = abs(pts[1][0] - pts[0][0])
        dy = abs(pts[1][1] - pts[0][1])
        if dx > 1 and dy > 1:
            layer_idx = pts[0][2]
            if layer_idx % 2 == 0:
                pts.insert(1, (pts[1][0], pts[0][1], layer_idx))
            else:
                pts.insert(1, (pts[0][0], pts[1][1], layer_idx))

    # Fix diagonal at end
    if pts[-1][2] == pts[-2][2]:
        dx = abs(pts[-1][0] - pts[-2][0])
        dy = abs(pts[-1][1] - pts[-2][1])
        if dx > 1 and dy > 1:
            layer_idx = pts[-1][2]
            if layer_idx % 2 == 0:
                pts.insert(-1, (pts[-1][0], pts[-2][1], layer_idx))
            else:
                pts.insert(-1, (pts[-2][0], pts[-1][1], layer_idx))

    return pts


def _coalesce_via_jogs(
    corners_3d: list[tuple[int, int, int]],
    min_jog_dbu: int,
) -> list[tuple[int, int, int]]:
    """Absorb tiny same-layer jog segments adjacent to via transitions.

    When a segment before or after a via transition is shorter than
    *min_jog_dbu*, snap the via to the other end of that segment and
    remove the redundant corner.  Endpoints (index 0 and last) are
    never removed.
    """
    pts = list(corners_3d)
    changed = True
    while changed:
        changed = False
        i = 0
        while i < len(pts) - 1:
            if pts[i][2] != pts[i + 1][2]:
                via_start_idx = i
                via_end_idx = i + 1

                # Check segment before via
                if (
                    via_start_idx > 0
                    and pts[via_start_idx - 1][2] == pts[via_start_idx][2]
                ):
                    prev = pts[via_start_idx - 1]
                    curr = pts[via_start_idx]
                    seg_len = abs(curr[0] - prev[0]) + abs(curr[1] - prev[1])
                    if 0 < seg_len < min_jog_dbu:
                        if via_start_idx == 0 or via_end_idx == len(pts) - 1:
                            i += 1
                            continue
                        pts[via_start_idx] = (prev[0], prev[1], curr[2])
                        pts[via_end_idx] = (prev[0], prev[1], pts[via_end_idx][2])
                        if via_start_idx - 1 == 0:
                            i += 1
                            continue
                        pts.pop(via_start_idx - 1)
                        changed = True
                        continue

                # Check segment after via
                if (
                    via_end_idx + 1 < len(pts)
                    and pts[via_end_idx][2] == pts[via_end_idx + 1][2]
                ):
                    curr = pts[via_end_idx]
                    nxt = pts[via_end_idx + 1]
                    seg_len = abs(nxt[0] - curr[0]) + abs(nxt[1] - curr[1])
                    if 0 < seg_len < min_jog_dbu:
                        if via_start_idx == 0 or via_end_idx == len(pts) - 1:
                            i += 1
                            continue
                        pts[via_start_idx] = (nxt[0], nxt[1], pts[via_start_idx][2])
                        pts[via_end_idx] = (nxt[0], nxt[1], curr[2])
                        if via_end_idx + 1 == len(pts) - 1:
                            i += 1
                            continue
                        pts.pop(via_end_idx + 1)
                        changed = True
                        continue
            i += 1
    return pts


def _dedup_corners(
    corners_3d: list[tuple[int, int, int]],
) -> list[tuple[int, int, int]]:
    """Remove consecutive duplicate corners (same x, y, layer)."""
    if not corners_3d:
        return []
    result = [corners_3d[0]]
    for j in range(1, len(corners_3d)):
        prev = result[-1]
        curr = corners_3d[j]
        if prev[0] == curr[0] and prev[1] == curr[1] and prev[2] == curr[2]:
            continue
        result.append(curr)
    return result


def _make_manhattan(points: list[tuple[float, float]]) -> list[tuple[float, float]]:
    """Convert a list of points to a proper Manhattan path.

    If consecutive points are not aligned (share neither x nor y),
    insert an intermediate jog point to make it Manhattan.
    Horizontal first (M1), then vertical (M2).
    """
    if len(points) < 2:
        return points

    result = [points[0]]

    for i in range(1, len(points)):
        p_prev = result[-1]
        p_curr = points[i]

        dx = abs(p_curr[0] - p_prev[0])
        dy = abs(p_curr[1] - p_prev[1])

        if dx < 0.001 or dy < 0.001:
            result.append(p_curr)
        else:
            jog_point = (p_curr[0], p_prev[1])
            result.append(jog_point)
            result.append(p_curr)

    return result


def _is_horizontal(p1: tuple[float, float], p2: tuple[float, float]) -> bool:
    """Check if a segment between two points is horizontal."""
    return abs(p2[1] - p1[1]) < 0.001


def _calc_path_length(path: list[tuple[float, float]]) -> float:
    """Calculate total Manhattan length of a path."""
    if len(path) < 2:
        return 0.0
    total = 0.0
    for i in range(len(path) - 1):
        dx = abs(path[i + 1][0] - path[i][0])
        dy = abs(path[i + 1][1] - path[i][1])
        total += dx + dy
    return total


def _is_valid_manhattan_path(path: list[tuple[float, float]]) -> bool:
    """Check if path is valid Manhattan (no consecutive same-direction segments)."""
    if len(path) < 3:
        return True

    tolerance = 0.001

    for i in range(len(path) - 2):
        p1, p2, p3 = path[i], path[i + 1], path[i + 2]

        seg1_horiz = abs(p2[1] - p1[1]) < tolerance
        seg1_vert = abs(p2[0] - p1[0]) < tolerance
        seg2_horiz = abs(p3[1] - p2[1]) < tolerance
        seg2_vert = abs(p3[0] - p2[0]) < tolerance

        if seg1_horiz and seg2_horiz:
            return False
        if seg1_vert and seg2_vert:
            return False

    return True


def _simplify_path(corners: list[tuple[float, float]]) -> list[tuple[float, float]]:
    """Remove redundant corners that don't change direction."""
    if not corners:
        return []

    unique_corners = [corners[0]]
    for i in range(1, len(corners)):
        curr = corners[i]
        prev = unique_corners[-1]
        if abs(curr[0] - prev[0]) > 0.001 or abs(curr[1] - prev[1]) > 0.001:
            unique_corners.append(curr)

    if len(unique_corners) < 3:
        return unique_corners

    result = [unique_corners[0]]
    for i in range(1, len(unique_corners) - 1):
        prev = unique_corners[i - 1]
        curr = unique_corners[i]
        next_pt = unique_corners[i + 1]

        dx1 = curr[0] - prev[0]
        dy1 = curr[1] - prev[1]
        dx2 = next_pt[0] - curr[0]
        dy2 = next_pt[1] - curr[1]

        tol = 0.001
        seg1_h = abs(dy1) <= tol and abs(dx1) > tol
        seg1_v = abs(dx1) <= tol and abs(dy1) > tol
        seg2_h = abs(dy2) <= tol and abs(dx2) > tol
        seg2_v = abs(dx2) <= tol and abs(dy2) > tol

        if not ((seg1_h and seg2_h) or (seg1_v and seg2_v)):
            result.append(curr)

    result.append(unique_corners[-1])
    return result


def _has_local_backtrack_corners(corners_3d: list[tuple[int, int, int]]) -> bool:
    """Detect immediate A->B->A position reversals."""
    if len(corners_3d) < 3:
        return False
    for i in range(1, len(corners_3d) - 1):
        a = corners_3d[i - 1]
        b = corners_3d[i]
        c = corners_3d[i + 1]
        if a[0] == c[0] and a[1] == c[1] and not (a[0] == b[0] and a[1] == b[1]):
            return True
    return False


def _has_local_backtrack_path(
    path: list[tuple[float, float]], tol: float = 1e-6
) -> bool:
    """Detect immediate A->B->A position reversals in 2D path."""
    if len(path) < 3:
        return False
    for i in range(1, len(path) - 1):
        a = path[i - 1]
        b = path[i]
        c = path[i + 1]
        if abs(a[0] - c[0]) <= tol and abs(a[1] - c[1]) <= tol:
            if abs(a[0] - b[0]) > tol or abs(a[1] - b[1]) > tol:
                return True
    return False


def _prune_redundant_jogs_corners(
    corners_3d: list[tuple[int, int, int]],
    protected_indices: set[int] | None = None,
) -> list[tuple[int, int, int]]:
    """Collapse immediate same-layer jog reversals and collinear stubs."""
    if len(corners_3d) < 3:
        return corners_3d
    pts = list(corners_3d)
    protected = set(protected_indices or set())
    changed = True
    while changed and len(pts) >= 3:
        changed = False
        i = 1
        while i < len(pts) - 1:
            if i in protected:
                i += 1
                continue
            a = pts[i - 1]
            b = pts[i]
            c = pts[i + 1]
            same_layer = a[2] == b[2] == c[2]
            if same_layer:
                if a[0] == c[0] and a[1] == c[1] and (a[0] != b[0] or a[1] != b[1]):
                    pts.pop(i)
                    changed = True
                    break
                ab_h = a[1] == b[1] and a[0] != b[0]
                bc_h = b[1] == c[1] and b[0] != c[0]
                ab_v = a[0] == b[0] and a[1] != b[1]
                bc_v = b[0] == c[0] and b[1] != c[1]
                if (ab_h and bc_h) or (ab_v and bc_v):
                    pts.pop(i)
                    changed = True
                    break
            i += 1
    return pts


def _collapse_ping_pong_transitions(
    corners_3d: list[tuple[int, int, int]],
    protect_endpoints: bool = True,
) -> list[tuple[int, int, int]]:
    """Remove no-op Lx->Ly->Lx transitions at identical XY."""
    if len(corners_3d) < 3:
        return list(corners_3d)
    pts = list(corners_3d)
    changed = True
    while changed and len(pts) >= 3:
        changed = False
        i = 0
        while i + 2 < len(pts):
            a = pts[i]
            b = pts[i + 1]
            c = pts[i + 2]
            same_xy = a[0] == b[0] == c[0] and a[1] == b[1] == c[1]
            ping_pong = a[2] == c[2] and a[2] != b[2]
            if same_xy and ping_pong:
                if protect_endpoints and (i == 0 or (i + 2) == (len(pts) - 1)):
                    i += 1
                    continue
                del pts[i + 1 : i + 3]
                changed = True
                break
            i += 1
    return pts


def _anchor_corners_endpoints(
    corners_3d: list[tuple[int, int, int]],
    start_xy: tuple[int, int],
    stop_xy: tuple[int, int],
) -> None:
    """Force first/last corner XY to exact routed port centers."""
    if len(corners_3d) < 2:
        return
    corners_3d[0] = (start_xy[0], start_xy[1], corners_3d[0][2])
    corners_3d[-1] = (stop_xy[0], stop_xy[1], corners_3d[-1][2])


def _fix_non_manhattan_after_anchor(
    corners_3d: list[tuple[int, int, int]],
) -> list[tuple[int, int, int]]:
    """Insert jog points to fix non-Manhattan same-layer segments.

    After endpoint anchoring, the first/last corners may be off-grid,
    creating diagonal same-layer segments.  This inserts intermediate
    corners to restore Manhattan routing.
    """
    if len(corners_3d) < 2:
        return corners_3d
    result = list(corners_3d)
    changed = True
    while changed:
        changed = False
        i = 0
        while i < len(result) - 1:
            x0, y0, z0 = result[i]
            x1, y1, z1 = result[i + 1]
            if z0 == z1 and abs(x1 - x0) > 0 and abs(y1 - y0) > 0:
                # Insert a jog: go horizontal first, then vertical
                jog = (x1, y0, z0)
                result.insert(i + 1, jog)
                changed = True
                break
            i += 1
    return result


def _is_manhattan_layered_path(corners_3d: list[tuple[int, int, int]]) -> bool:
    """True if every same-layer segment is axis-aligned and non-diagonal."""
    if len(corners_3d) < 2:
        return True
    for i in range(len(corners_3d) - 1):
        x0, y0, z0 = corners_3d[i]
        x1, y1, z1 = corners_3d[i + 1]
        if z0 != z1:
            continue
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        if dx > 0 and dy > 0:
            return False
    return True


def _collapse_via_detours(
    corners_3d: list[tuple[int, int, int]],
    preferred_horizontal_layers: set[int] | None = None,
    max_non_preferred_dbu: int = 0,
) -> list[tuple[int, int, int]]:
    """Collapse unnecessary via round-trips back to same-layer segments.

    Detects the pattern::

        ...A(Z) ─via─ B(Z') ── C(Z') ─via─ D(Z)...

    where A and D are on the same layer Z, and the detour B→C on layer Z'
    could be replaced by a direct A→D on layer Z (if the resulting segment
    is Manhattan).

    When *preferred_horizontal_layers* is provided and the resulting
    segment goes against the layer's preferred direction, collapse is only
    performed if the segment length is ≤ *max_non_preferred_dbu*.
    Direction preference for port exits is enforced later by
    ``_force_port_exit_direction()``.
    """
    if len(corners_3d) < 4:
        return list(corners_3d)

    result = list(corners_3d)
    changed = True
    while changed:
        changed = False
        i = 0
        while i < len(result) - 3:
            a_x, a_y, a_z = result[i]
            b_x, b_y, b_z = result[i + 1]
            c_x, c_y, c_z = result[i + 2]
            d_x, d_y, d_z = result[i + 3]

            # Check pattern: A→B is via, B→C same layer, C→D is via back
            if a_z == d_z and a_z != b_z and b_z == c_z:
                # The replacement segment A→D must be Manhattan
                a_to_d_dx = abs(d_x - a_x)
                a_to_d_dy = abs(d_y - a_y)
                is_horiz = a_to_d_dy == 0 and a_to_d_dx > 0
                is_vert = a_to_d_dx == 0 and a_to_d_dy > 0
                is_manhattan = is_horiz or is_vert

                if is_manhattan:
                    # Block long non-preferred segments to avoid DRC
                    if preferred_horizontal_layers is not None:
                        layer_prefers_h = a_z in preferred_horizontal_layers
                        if is_horiz != layer_prefers_h:
                            seg_len = a_to_d_dx + a_to_d_dy
                            if seg_len > max_non_preferred_dbu:
                                i += 1
                                continue

                    # Remove B and C (the via detour);
                    # A and D stay in place, so endpoints are preserved.
                    del result[i + 1 : i + 3]
                    changed = True
                    continue
            i += 1

    return result


def _collapse_same_layer_staircases(
    corners_3d: list[tuple[int, int, int]],
) -> list[tuple[int, int, int]]:
    """Collapse same-layer staircase jogs into L-shaped bends.

    Detects 4-point patterns A-B-C-D all on the same layer where:
    - A->B and C->D are parallel (both horizontal or both vertical)
    - B->C connects them (perpendicular)
    Replaces with A->E->D where E is the direct L-bend corner.

    For example, a horizontal staircase:
        A(x0,y0) -> B(x1,y0) -> C(x1,y1) -> D(x2,y1)
    becomes:
        A(x0,y0) -> E(x2,y0) -> D(x2,y1)   [or A -> (x0,y1) -> D]
    """
    if len(corners_3d) < 4:
        return list(corners_3d)

    result = list(corners_3d)
    changed = True
    while changed:
        changed = False
        i = 0
        while i < len(result) - 3:
            a_x, a_y, a_z = result[i]
            b_x, b_y, b_z = result[i + 1]
            c_x, c_y, c_z = result[i + 2]
            d_x, d_y, d_z = result[i + 3]

            # All four must be on the same layer
            if not (a_z == b_z == c_z == d_z):
                i += 1
                continue

            # Check: A->B horizontal, B->C vertical, C->D horizontal (H-V-H staircase)
            ab_h = a_y == b_y and a_x != b_x
            bc_v = b_x == c_x and b_y != c_y
            cd_h = c_y == d_y and c_x != d_x

            if ab_h and bc_v and cd_h:
                # Collapse to A -> (d_x, a_y) -> D
                result[i + 1] = (d_x, a_y, a_z)
                del result[i + 2]
                changed = True
                continue

            # Check: A->B vertical, B->C horizontal, C->D vertical (V-H-V staircase)
            ab_v = a_x == b_x and a_y != b_y
            bc_h = b_y == c_y and b_x != c_x
            cd_v = c_x == d_x and c_y != d_y

            if ab_v and bc_h and cd_v:
                # Collapse to A -> (a_x, d_y) -> D
                result[i + 1] = (a_x, d_y, a_z)
                del result[i + 2]
                changed = True
                continue

            i += 1

    return result


def _remove_corner_on_segment_overlaps(
    corners_3d: list[tuple[int, int, int]],
) -> list[tuple[int, int, int]]:
    """Remove self-overlapping loops where a corner lies on a non-adjacent segment.

    For corner ``Pi`` at ``(xi, yi, zi)``, checks every segment ``Pj → Pj+1``
    on the same layer.  If ``Pi`` lies strictly in the interior of a horizontal
    or vertical segment, the loop between the overlapping points is removed.

    Iterates until no overlaps remain.
    """
    if len(corners_3d) <= 2:
        return list(corners_3d)

    pts = list(corners_3d)
    changed = True
    while changed:
        changed = False
        for i in range(len(pts)):
            pi_x, pi_y, pi_z = pts[i]
            for j in range(len(pts) - 1):
                # Skip adjacent segments
                if j + 1 == i or j == i:
                    continue
                pj_x, pj_y, pj_z = pts[j]
                pk_x, pk_y, pk_z = pts[j + 1]
                # Same layer check
                if pj_z != pi_z or pk_z != pi_z:
                    continue
                on_seg = False
                if pj_y == pk_y == pi_y:
                    # Horizontal segment
                    lo = min(pj_x, pk_x)
                    hi = max(pj_x, pk_x)
                    on_seg = lo < pi_x < hi
                elif pj_x == pk_x == pi_x:
                    # Vertical segment
                    lo = min(pj_y, pk_y)
                    hi = max(pj_y, pk_y)
                    on_seg = lo < pi_y < hi
                if on_seg:
                    if j + 1 < i:
                        del pts[j + 1 : i]
                    elif i < j:
                        del pts[i + 1 : j + 1]
                    changed = True
                    break
            if changed:
                break

    return pts


def _collapse_extended_via_detours(
    corners_3d: list[tuple[int, int, int]],
    preferred_horizontal_layers: set[int] | None = None,
    max_non_preferred_dbu: int = 0,
) -> list[tuple[int, int, int]]:
    """Collapse multi-segment via detours back to the base layer.

    Finds patterns A(Z)->via->B(Z')->...->C(Z')->via->D(Z) where the
    intermediate segments on Z' can be replaced by a direct A->D on Z
    (if the resulting segment is Manhattan).

    Same non-preferred length gating as ``_collapse_via_detours()``.

    This extends _collapse_via_detours() to handle detours spanning
    more than one intermediate segment.
    """
    if len(corners_3d) < 4:
        return list(corners_3d)

    result = list(corners_3d)
    changed = True
    while changed:
        changed = False
        i = 0
        while i < len(result) - 3:
            a_x, a_y, a_z = result[i]

            # Look for A(Z) -> B(Z') where Z != Z' (first via)
            b_x, b_y, b_z = result[i + 1]
            if a_z == b_z:
                i += 1
                continue

            # Scan forward to find the return via back to layer a_z
            found_end = False
            for j in range(i + 2, len(result)):
                jx, jy, jz = result[j]

                # All intermediate points must be on layer b_z
                if j < len(result) and jz != b_z:
                    # This point is not on the intermediate layer —
                    # check if it's a return to a_z
                    if jz == a_z:
                        # Found: result[j] is D(Z), result[j-1] is C(Z')
                        d_x, d_y, _ = jx, jy, jz

                        # Check that A->D is Manhattan
                        dx = abs(d_x - a_x)
                        dy = abs(d_y - a_y)
                        is_horiz = dy == 0 and dx > 0
                        is_vert = dx == 0 and dy > 0
                        is_same_point = dx == 0 and dy == 0

                        if is_horiz or is_vert or is_same_point:
                            # Block long non-preferred segments to avoid DRC
                            ok = True
                            if (
                                preferred_horizontal_layers is not None
                                and not is_same_point
                            ):
                                layer_prefers_h = a_z in preferred_horizontal_layers
                                if is_horiz != layer_prefers_h:
                                    seg_len = dx + dy
                                    if seg_len > max_non_preferred_dbu:
                                        ok = False

                            if ok:
                                # Remove all intermediate points between A and D
                                del result[i + 1 : j]
                                changed = True
                                found_end = True
                                break
                    # Not a return to a_z, not on b_z — break the scan
                    break

            if not found_end:
                i += 1

    return result


# ---------------------------------------------------------------------------
# Port exit direction forcing for asymmetric ports
# ---------------------------------------------------------------------------

MIN_FORCED_SEGMENT_DBU = 100  # ~10nm at 0.001 dbu; skip forcing if new segment < this


def _point_inside_bbox_dbu(x: int, y: int, bbox_dbu: tuple[int, int, int, int]) -> bool:
    """True if (x, y) is within the bbox (inclusive)."""
    return bbox_dbu[0] <= x <= bbox_dbu[2] and bbox_dbu[1] <= y <= bbox_dbu[3]


def _force_port_exit_direction(
    corners_3d: list[tuple[int, int, int]],
    start_geom: "PortGeometry",
    stop_geom: "PortGeometry",
    dbu: float,
) -> list[tuple[int, int, int]]:
    """Force extension segments at asymmetric ports to follow the long axis.

    For ports with aspect > 2:1, the first/last extension segment should exit
    along the port's long axis to avoid wide segments bridging adjacent ports.

    Only acts when the first corner after the port is OUTSIDE the port's
    original (unsquared) bbox — if the corner is inside, the port polygon
    provides metal coverage and no forcing is needed.
    """
    if len(corners_3d) < 2:
        return corners_3d

    pts = list(corners_3d)

    # --- Start endpoint ---
    pts = _force_exit_at_start(pts, start_geom)

    # --- Stop endpoint (mirror logic) ---
    pts = _force_exit_at_stop(pts, stop_geom)

    return pts


def _force_exit_at_start(
    pts: list[tuple[int, int, int]],
    geom: "PortGeometry",
) -> list[tuple[int, int, int]]:
    """Force exit direction at the start of the path."""
    preferred = geom.preferred_exit_direction
    if preferred is None:
        return pts
    orig_bbox = geom.orig_bbox_dbu
    if orig_bbox is None:
        return pts

    # Find first same-layer corner after start
    idx = 1
    while idx < len(pts) and pts[idx][2] != pts[0][2]:
        idx += 1
    if idx >= len(pts):
        return pts

    c0 = pts[0]
    c1 = pts[idx]

    # If first corner is inside the original port bbox, skip
    if _point_inside_bbox_dbu(c1[0], c1[1], orig_bbox):
        return pts

    # Determine current exit direction
    dx = abs(c1[0] - c0[0])
    dy = abs(c1[1] - c0[1])

    if dx == 0 and dy == 0:
        return pts  # collinear / zero-length

    current_dir = "h" if dx >= dy else "v"
    if current_dir == preferred:
        return pts  # already correct

    # Need to swap L-bend order.  Only works if the segment is a true L
    # (both dx > 0 and dy > 0), meaning there's an intermediate corner.
    if idx == 1 and dx > 0 and dy > 0:
        # c0 and c1 are diagonal on the same layer — there must be an
        # intermediate corner at idx=1 that was inserted by manhattanize.
        # This shouldn't happen after _fix_non_manhattan_after_anchor,
        # but guard against it.
        return pts

    # Look for the L-bend pattern: c0 -> c_mid -> c_next where c_mid is the
    # corner between two perpendicular segments.
    if idx != 1:
        return pts  # via between start and first same-layer corner, skip

    # Check if there's an L-bend: c0 -> c1 -> c2 on same layer
    if len(pts) < 3:
        return pts
    c2 = pts[2]
    if c2[2] != c0[2]:
        # c2 is on a different layer (via), so c0->c1 is the only segment
        # before a via.  We can only force direction for this single segment
        # if it's currently wrong — but we need somewhere to put the bend.
        # Insert a new L-bend corner.
        if preferred == "h":
            # Want horizontal exit: go (c0.x -> c1.x, c0.y) then vertical
            new_corner = (c1[0], c0[1], c0[2])
        else:
            # Want vertical exit: go (c0.x, c0.y -> c1.y) then horizontal
            new_corner = (c0[0], c1[1], c0[2])
        # Check new segment isn't too short
        seg_len = abs(new_corner[0] - c0[0]) + abs(new_corner[1] - c0[1])
        if seg_len < MIN_FORCED_SEGMENT_DBU:
            return pts
        pts[1] = new_corner
        pts.insert(2, c1)
        return pts

    # c0 -> c1 -> c2 all on same layer: swap the L-bend at c1
    # Current: c0 --(dir A)--> c1 --(dir B)--> c2
    # Swap:    c0 --(dir B)--> c1' --(dir A)--> c2
    if preferred == "h":
        # Want horizontal first: new c1 = (c2.x, c0.y, z) ... but we need
        # to keep c2 where it is.  Actually, swap the intermediate corner:
        new_c1 = (c1[0], c0[1], c0[2]) if current_dir == "v" else (c0[0], c1[1], c0[2])
        # Recalculate: if preferred is "h", start should go horizontal first
        # c0 -> (c_next_x, c0.y) -> c_next
        # The "next" point after the L is c2 (or c1 if it's just 2 segments)
        new_c1 = (c2[0], c0[1], c0[2])
    else:
        # Want vertical first
        new_c1 = (c0[0], c2[1], c0[2])

    # Verify new corner creates Manhattan segments
    nc1_dx0 = abs(new_c1[0] - c0[0])
    nc1_dy0 = abs(new_c1[1] - c0[1])
    nc1_dx2 = abs(c2[0] - new_c1[0])
    nc1_dy2 = abs(c2[1] - new_c1[1])

    # Must be axis-aligned on both sides
    if (nc1_dx0 > 0 and nc1_dy0 > 0) or (nc1_dx2 > 0 and nc1_dy2 > 0):
        return pts  # wouldn't be Manhattan, skip

    # Check new first segment isn't too short
    seg_len = nc1_dx0 + nc1_dy0
    if seg_len < MIN_FORCED_SEGMENT_DBU:
        return pts

    pts[1] = new_c1
    return pts


def _force_exit_at_stop(
    pts: list[tuple[int, int, int]],
    geom: "PortGeometry",
) -> list[tuple[int, int, int]]:
    """Force exit direction at the stop (end) of the path."""
    preferred = geom.preferred_exit_direction
    if preferred is None:
        return pts
    orig_bbox = geom.orig_bbox_dbu
    if orig_bbox is None:
        return pts

    last = len(pts) - 1

    # Find last same-layer corner before stop
    idx = last - 1
    while idx >= 0 and pts[idx][2] != pts[last][2]:
        idx -= 1
    if idx < 0:
        return pts

    cN = pts[last]
    cP = pts[idx]

    # If penultimate corner is inside the original port bbox, skip
    if _point_inside_bbox_dbu(cP[0], cP[1], orig_bbox):
        return pts

    dx = abs(cN[0] - cP[0])
    dy = abs(cN[1] - cP[1])

    if dx == 0 and dy == 0:
        return pts

    current_dir = "h" if dx >= dy else "v"
    if current_dir == preferred:
        return pts

    if idx != last - 1:
        return pts  # via between last same-layer corner and stop, skip

    if idx == last - 1 and dx > 0 and dy > 0:
        return pts  # diagonal, shouldn't happen after manhattan fix

    # Check for L-bend: c_prev -> cP -> cN on same layer
    if idx < 1:
        return pts
    cPP = pts[idx - 1]
    if cPP[2] != cN[2]:
        # Via before the last segment — insert new L-bend
        if preferred == "h":
            new_corner = (cP[0], cN[1], cN[2])
        else:
            new_corner = (cN[0], cP[1], cN[2])
        seg_len = abs(cN[0] - new_corner[0]) + abs(cN[1] - new_corner[1])
        if seg_len < MIN_FORCED_SEGMENT_DBU:
            return pts
        pts[idx] = cP  # keep original
        pts.insert(idx + 1, new_corner)
        return pts

    # cPP -> cP -> cN all on same layer: swap the L-bend at cP
    if preferred == "h":
        new_cP = (cPP[0], cN[1], cN[2])
    else:
        new_cP = (cN[0], cPP[1], cN[2])

    # Verify Manhattan
    ncP_dxPP = abs(new_cP[0] - cPP[0])
    ncP_dyPP = abs(new_cP[1] - cPP[1])
    ncP_dxN = abs(cN[0] - new_cP[0])
    ncP_dyN = abs(cN[1] - new_cP[1])

    if (ncP_dxPP > 0 and ncP_dyPP > 0) or (ncP_dxN > 0 and ncP_dyN > 0):
        return pts

    seg_len = ncP_dxN + ncP_dyN
    if seg_len < MIN_FORCED_SEGMENT_DBU:
        return pts

    pts[idx] = new_cP
    return pts
