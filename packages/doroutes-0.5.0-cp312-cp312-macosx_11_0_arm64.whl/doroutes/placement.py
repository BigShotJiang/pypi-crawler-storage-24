"""Automatic placement API backed by the Rust placement core."""

from __future__ import annotations

from typing import Any, Literal, NotRequired, TypedDict, cast

from kfactory.kcell import KCell, ProtoTKCell

from . import doroutes as _doroutes  # type: ignore[reportAttributeAccess]
from . import util

PlacementMode = Literal["openroad", "tiling", "auto"]


class PlacedInstanceSpec(TypedDict):
    """Instance placement input specification."""

    name: str
    fixed: NotRequired[bool]
    keepout: NotRequired[int]
    group: NotRequired[str]
    padding_left: NotRequired[int]
    padding_right: NotRequired[int]
    fence: NotRequired[str]


class PlacementNetSpec(TypedDict):
    """Net specification for placement objective."""

    name: str
    pins: list[str]
    weight: NotRequired[float]


class FenceRegionSpec(TypedDict):
    """Fence region constraining instances to a sub-area (analog guard ring, matched pair)."""

    name: str
    bbox: tuple[int, int, int, int]  # (x_min, y_min, x_max, y_max) in DBU


class PlacementConstraints(TypedDict):
    """Placement constraints."""

    min_spacing: NotRequired[int]
    density_target: NotRequired[float]
    bbox: NotRequired[tuple[int, int, int, int]]  # (north, east, south, west)
    max_displacement: NotRequired[int]
    fence_regions: NotRequired[list[FenceRegionSpec]]


class PlacementObjective(TypedDict):
    """Placement objective weights."""

    hpwl_weight: NotRequired[float]
    congestion_weight: NotRequired[float]
    density_weight: NotRequired[float]
    displacement_weight: NotRequired[float]
    grouping_weight: NotRequired[float]
    timing_driven: NotRequired[bool]
    timing_net_weight_max: NotRequired[float]
    timing_nets_percentage: NotRequired[float]
    routability_driven: NotRequired[bool]
    max_inflation_ratio: NotRequired[float]
    routability_overflow_threshold: NotRequired[float]


class RoutingFeedbackConfig(TypedDict):
    """Routing feedback configuration (v1 supports proxy feedback only)."""

    enabled: NotRequired[bool]
    strategy: NotRequired[Literal["proxy", "sampled"]]


class PlacementReport(TypedDict):
    """Placement output report."""

    mode_used: str
    placements: dict[str, tuple[int, int, str]]
    hpwl: float
    congestion: float
    density_overflow: float
    legalized: bool
    iterations: list[tuple[int, float, float, float]]
    placement_violations: NotRequired[list[str]]


def _as_kcell(c: ProtoTKCell) -> KCell:
    return util.as_kcell(c)


def _instance_center_and_size(inst: object) -> tuple[int, int, int, int]:
    # kfactory Instance API exposes bbox in DBU.
    bbox = inst.bbox()  # type: ignore[reportAttributeAccess]
    width = int(bbox.right - bbox.left)
    height = int(bbox.top - bbox.bottom)
    x = int((bbox.left + bbox.right) // 2)
    y = int((bbox.bottom + bbox.top) // 2)
    return x, y, width, height


def _pin_to_instance_name(pin: str) -> str:
    # Accept either "inst" or "inst,port".
    if "," in pin:
        return pin.split(",", maxsplit=1)[0]
    return pin


def _abut_groups(
    placement_map: dict[str, tuple[int, int, str]],
    inst_specs: list[PlacedInstanceSpec],
    inst_sizes: dict[str, tuple[int, int]],
    min_gap: int = 0,
) -> dict[str, tuple[int, int, str]]:
    """Snap same-group instances with *min_gap* between edges.

    For each group with 2+ instances, determines whether to tile
    horizontally or vertically based on the current placement spread,
    then packs them with *min_gap* DBU between edges, centered at the
    group centroid.
    """
    # Collect groups with 2+ members.
    groups: dict[str, list[str]] = {}
    for spec in inst_specs:
        group = spec.get("group", "")
        if group:
            groups.setdefault(group, []).append(spec["name"])

    result = dict(placement_map)

    for _group_name, names in groups.items():
        if len(names) < 2:
            continue

        # Gather current positions and sizes.
        items: list[tuple[str, int, int, int, int, str]] = []
        for name in names:
            if name not in result or name not in inst_sizes:
                continue
            x, y, orient = result[name]
            w, h = inst_sizes[name]
            items.append((name, x, y, w, h, orient))

        if len(items) < 2:
            continue

        # Determine arrangement direction from current placement spread.
        xs = [x for _, x, _, _, _, _ in items]
        ys = [y for _, _, y, _, _, _ in items]
        x_spread = max(xs) - min(xs)
        y_spread = max(ys) - min(ys)

        cx = sum(xs) // len(xs)
        cy = sum(ys) // len(ys)

        if x_spread >= y_spread:
            # Tile horizontally: sort by x, pack left-to-right, align y.
            items.sort(key=lambda t: t[1])
            total_w = sum(w for _, _, _, w, _, _ in items) + min_gap * (len(items) - 1)
            cur_left = cx - total_w // 2
            for name, _, _, w, _, orient in items:
                new_x = cur_left + w // 2
                result[name] = (new_x, cy, orient)
                cur_left += w + min_gap
        else:
            # Tile vertically: sort by y, pack bottom-to-top, align x.
            items.sort(key=lambda t: t[2])
            total_h = sum(h for _, _, _, _, h, _ in items) + min_gap * (len(items) - 1)
            cur_bot = cy - total_h // 2
            for name, _, _, _, h, orient in items:
                new_y = cur_bot + h // 2
                result[name] = (cx, new_y, orient)
                cur_bot += h + min_gap

    return result


def derive_placement_nets(
    routing_nets: list[object],
    instance_names: list[str],
    *,
    supply_net_weight: float = 0.5,
    supply_prefixes: tuple[str, ...] = ("vdd", "vss", "gnd"),
) -> list[PlacementNetSpec]:
    """Derive placement nets from routing ``RouteNetSpec`` objects.

    For each routing net, extract instance names from port names by
    longest-prefix match against *instance_names*.  Group routing nets
    by net name, collect unique instances per group, and filter out
    single-instance (intra-device) nets.  Supply nets (detected by name
    prefix) receive a lower weight so placement is not dominated by
    power routing.

    Returns a list of ``PlacementNetSpec`` dicts suitable for
    ``place_auto()``.
    """
    # Sort instance names longest-first so longest-prefix match wins.
    sorted_names = sorted(instance_names, key=len, reverse=True)

    def _port_to_instance(port_name: str) -> str | None:
        for name in sorted_names:
            if port_name.startswith(name):
                return name
        return None

    # Group routing nets by net name → set of instance names.
    net_instances: dict[str, set[str]] = {}
    for rnet in routing_nets:
        net_name: str = rnet.name  # type: ignore[attr-defined]
        start_name: str = rnet.start.name  # type: ignore[attr-defined]
        stop_name: str = rnet.stop.name  # type: ignore[attr-defined]

        start_inst = _port_to_instance(start_name)
        stop_inst = _port_to_instance(stop_name)

        if start_inst is None or stop_inst is None:
            continue

        net_instances.setdefault(net_name, set())
        net_instances[net_name].add(start_inst)
        net_instances[net_name].add(stop_inst)

    # Build PlacementNetSpec list, filtering single-instance nets.
    placement_nets: list[PlacementNetSpec] = []
    for net_name, insts in net_instances.items():
        if len(insts) < 2:
            continue  # intra-device body tie — skip
        is_supply = any(net_name.lower().startswith(p) for p in supply_prefixes)
        weight = supply_net_weight if is_supply else 1.0
        placement_nets.append(
            {
                "name": net_name,
                "pins": sorted(insts),
                "weight": weight,
            }
        )

    return placement_nets


def place_auto(
    c: ProtoTKCell,
    instances: list[str] | list[PlacedInstanceSpec],
    nets: list[PlacementNetSpec] | list[object],
    *,
    mode: PlacementMode = "auto",
    objective: PlacementObjective | None = None,
    constraints: PlacementConstraints | None = None,
    routing_feedback: RoutingFeedbackConfig | None = None,
    apply: bool = True,
    iterations: int = 30,
) -> PlacementReport:
    """Automatically place instances using openroad-style or tiling mode.

    Args:
        c: component/KCell to place instances in.
        instances: list of instance names or specs.
        nets: placement netlist — either ``PlacementNetSpec`` dicts (pins
            refer to instance names) or ``RouteNetSpec`` objects.  When
            ``RouteNetSpec`` objects are given they are auto-converted via
            ``derive_placement_nets()``.
        mode: "openroad", "tiling", or "auto".
        objective: objective weights.
        constraints: placement constraints.
        routing_feedback: reserved for future routing-in-loop strategies.
        apply: apply placement in-place when True.
        iterations: optimizer iteration budget.

    Returns:
        Structured placement report with final locations and metrics.

    """
    del routing_feedback  # v1 uses congestion-proxy feedback internally.

    kc = _as_kcell(c)

    constraints = constraints or {}
    objective = objective or {}

    # Auto-convert RouteNetSpec objects to PlacementNetSpec dicts.
    if nets and hasattr(nets[0], "start") and hasattr(nets[0], "stop"):
        # Collect instance names for derive_placement_nets.
        inst_names: list[str] = []
        if instances and isinstance(instances[0], str):
            inst_names = list(instances)  # type: ignore[arg-type]
        else:
            inst_names = [spec["name"] for spec in instances]  # type: ignore[index]
        nets = derive_placement_nets(nets, inst_names)  # type: ignore[arg-type]

    pnets = cast(list[PlacementNetSpec], nets)

    # Normalize instance specs.
    inst_specs: list[PlacedInstanceSpec] = []
    if instances and isinstance(instances[0], str):
        inst_specs = [{"name": str(name)} for name in instances]  # type: ignore[arg-type]
    else:
        inst_specs = list(instances)  # type: ignore[assignment]

    rust_instances: list[tuple[str, int, int, int, int, bool, int, str]] = []
    name_to_idx: dict[str, int] = {}
    current_centers: dict[str, tuple[int, int]] = {}
    inst_sizes: dict[str, tuple[int, int]] = {}

    for idx, spec in enumerate(inst_specs):
        name = spec["name"]
        try:
            inst = kc.insts[name]
        except (
            Exception
        ) as e:  # pragma: no cover - kfactory error type depends on backend
            msg = f"Instance '{name}' not found in component."
            raise ValueError(msg) from e

        x, y, width, height = _instance_center_and_size(inst)
        fixed = bool(spec.get("fixed", False))
        keepout = int(spec.get("keepout", 0))
        group = str(spec.get("group", ""))
        rust_instances.append((name, x, y, width, height, fixed, keepout, group))
        name_to_idx[name] = idx
        current_centers[name] = (x, y)
        inst_sizes[name] = (width, height)

    # Normalize net specs to rust format: pins reference instance indices.
    rust_nets: list[tuple[str, list[tuple[int, float]], float]] = []
    for net in pnets:
        pin_refs: list[tuple[int, float]] = []
        net_weight = float(net.get("weight", 1.0))
        for pin in net["pins"]:
            inst_name = _pin_to_instance_name(pin)
            if inst_name not in name_to_idx:
                msg = f"Net '{net['name']}' references unknown instance '{inst_name}'."
                raise ValueError(msg)
            pin_refs.append((name_to_idx[inst_name], 1.0))
        if len(pin_refs) >= 2:
            rust_nets.append((net["name"], pin_refs, net_weight))

    if "bbox" in constraints:
        bbox = constraints["bbox"]
    else:
        cb = kc.bbox()
        bbox = (int(cb.top), int(cb.right), int(cb.bottom), int(cb.left))

    if not hasattr(_doroutes, "place_batch"):
        msg = (
            "doroutes extension does not expose place_batch yet. "
            "Rebuild the Rust extension (e.g. `maturin develop`) and retry."
        )
        raise RuntimeError(msg)

    placements, mode_used, hpwl, congestion, density_ovf, legalized, iter_metrics = (
        _doroutes.place_batch(
            instances=rust_instances,
            nets=rust_nets,
            bbox=bbox,
            mode=mode,
            min_spacing=int(constraints.get("min_spacing", 0)),
            density_target=float(constraints.get("density_target", 0.7)),
            iterations=max(1, int(iterations)),
            hpwl_weight=float(objective.get("hpwl_weight", 1.0)),
            congestion_weight=float(objective.get("congestion_weight", 1.2)),
            density_weight=float(objective.get("density_weight", 1.0)),
            displacement_weight=float(objective.get("displacement_weight", 0.15)),
            grouping_weight=float(objective.get("grouping_weight", 0.0)),
            timing_driven=bool(objective.get("timing_driven", False)),
            routability_driven=bool(objective.get("routability_driven", False)),
            max_displacement=int(constraints.get("max_displacement", 0)),
        )
    )

    placement_map = {name: (x, y, orient) for name, x, y, orient in placements}

    # Post-process: abut same-group instances with min_spacing gap.
    placement_map = _abut_groups(
        placement_map,
        inst_specs,
        inst_sizes,
        min_gap=int(constraints.get("min_spacing", 0)),
    )

    if apply:
        inv_dbu = util.get_inv_dbu(kc.kcl)
        for name, (x, y, _orient) in placement_map.items():
            inst = kc.insts[name]
            curx, cury = current_centers[name]
            dx = x - curx
            dy = y - cury
            inst.dmove((float(dx / inv_dbu), float(dy / inv_dbu)))

    return {
        "mode_used": mode_used,
        "placements": placement_map,
        "hpwl": float(hpwl),
        "congestion": float(congestion),
        "density_overflow": float(density_ovf),
        "legalized": bool(legalized),
        "iterations": [
            (int(i), float(h), float(cg), float(d)) for i, h, cg, d in iter_metrics
        ],
    }


def place_openroad_style(
    c: ProtoTKCell,
    instances: list[str] | list[PlacedInstanceSpec],
    nets: list[PlacementNetSpec],
    **kwargs: Any,
) -> PlacementReport:
    """Convenience wrapper for `place_auto(..., mode="openroad")`."""
    return place_auto(c, instances, nets, mode="openroad", **kwargs)


def place_tiling(
    c: ProtoTKCell,
    instances: list[str] | list[PlacedInstanceSpec],
    nets: list[PlacementNetSpec],
    **kwargs: Any,
) -> PlacementReport:
    """Convenience wrapper for `place_auto(..., mode="tiling")`."""
    return place_auto(c, instances, nets, mode="tiling", **kwargs)


__all__ = [
    "FenceRegionSpec",
    "PlacedInstanceSpec",
    "PlacementConstraints",
    "PlacementNetSpec",
    "PlacementObjective",
    "PlacementReport",
    "RoutingFeedbackConfig",
    "derive_placement_nets",
    "place_auto",
    "place_openroad_style",
    "place_tiling",
]
