"""Operations module — re-export shim.

Project discovery and tree: ops_project.py
Git operations: ops_git.py
Context packing: ops_context.py
Feature branch management: ops_feature.py
Local CI runner: ops_ci.py
"""
from .ops_project import (  # noqa: F401
    ProjectRootNotFoundError,
    find_project_root,
    find_paircoder_dir,
    ProjectTree,
)
from .ops_git import GitOps  # noqa: F401
from .ops_context import ContextPacker  # noqa: F401
from .ops_feature import FeatureOps  # noqa: F401
from .ops_ci import LocalCI  # noqa: F401

__all__ = [
    "ProjectRootNotFoundError",
    "find_project_root",
    "find_paircoder_dir",
    "ProjectTree",
    "GitOps",
    "ContextPacker",
    "FeatureOps",
    "LocalCI",
]
