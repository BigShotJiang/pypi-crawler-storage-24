"""Git operations helper."""
from __future__ import annotations

import subprocess
from pathlib import Path
from typing import List


class GitOps:
    """Git operations helper."""

    @staticmethod
    def is_repo(path: Path) -> bool:
        """Check if path is a git repo."""
        return (path / ".git").exists()

    @staticmethod
    def is_clean(path: Path) -> bool:
        """Check if working tree is clean."""
        try:
            # Check for unstaged changes
            result = subprocess.run(
                ["git", "diff", "--quiet"],
                cwd=path,
                capture_output=True
            )
            if result.returncode != 0:
                return False

            # Check for staged changes
            staged = subprocess.run(
                ["git", "diff", "--cached", "--quiet"],
                cwd=path,
                capture_output=True
            )
            if staged.returncode != 0:
                return False

            # Check for untracked files
            untracked = subprocess.run(
                ["git", "ls-files", "--other", "--exclude-standard"],
                cwd=path,
                capture_output=True,
                text=True
            )
            if untracked.stdout.strip():
                return False

            return True
        except:
            return False

    @staticmethod
    def current_branch(path: Path) -> str:
        """Get current branch name."""
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=path,
            capture_output=True,
            text=True
        )
        return result.stdout.strip() if result.returncode == 0 else ""

    @staticmethod
    def create_branch(path: Path, branch: str, from_branch: str = "main") -> bool:
        """Create and checkout a new branch."""
        # Check if source branch exists
        check = subprocess.run(
            ["git", "rev-parse", "--verify", from_branch],
            cwd=path,
            capture_output=True
        )
        if check.returncode != 0:
            return False

        # Checkout source branch
        subprocess.run(["git", "checkout", from_branch], cwd=path, capture_output=True)

        # Pull if upstream exists
        upstream = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"],
            cwd=path,
            capture_output=True
        )
        if upstream.returncode == 0:
            subprocess.run(["git", "pull", "--ff-only"], cwd=path, capture_output=True)

        # Create new branch
        result = subprocess.run(
            ["git", "checkout", "-b", branch],
            cwd=path,
            capture_output=True
        )
        return result.returncode == 0

    @staticmethod
    def add_commit(path: Path, files: List[Path], message: str) -> bool:
        """Add files and commit."""
        for f in files:
            subprocess.run(["git", "add", str(f)], cwd=path, capture_output=True)

        result = subprocess.run(
            ["git", "commit", "-m", message],
            cwd=path,
            capture_output=True
        )
        return result.returncode == 0
