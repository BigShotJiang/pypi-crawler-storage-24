"""Feature branch management operations."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from .ops_git import GitOps
from .ops_project import ProjectTree


class FeatureOps:
    """Operations for feature branch management."""

    @staticmethod
    def create_feature(
        root: Path,
        name: str,
        branch_type: str = "feature",
        primary_goal: str = "",
        phase: str = "",
        force: bool = False
    ) -> bool:
        """Create a feature branch and update context."""
        # Check if working tree is clean
        if not force and not GitOps.is_clean(root):
            raise ValueError("Working tree not clean. Commit or stash changes, or use --force")

        # Create branch
        branch_name = f"{branch_type}/{name}"
        if not GitOps.create_branch(root, branch_name):
            raise ValueError(f"Failed to create branch {branch_name}")

        # Ensure context directory structure (v2.1 path)
        context_dir = root / ".paircoder" / "context"
        context_dir.mkdir(parents=True, exist_ok=True)

        # Update or create state.md (v2.1) or development.md (legacy)
        state_file = context_dir / "state.md"
        legacy_dev_file = root / "context" / "development.md"

        if state_file.exists():
            # Update v2.1 state.md
            import re
            content = state_file.read_text(encoding="utf-8")

            # Update Current Focus section
            if primary_goal or phase:
                focus_text = f"Working on: {primary_goal or 'To be defined'}"
                if phase:
                    focus_text += f"\nPhase: {phase}"
                content = re.sub(
                    r'## Current Focus\n\n.*?(?=\n## |\Z)',
                    f'## Current Focus\n\n{focus_text}\n\n',
                    content,
                    flags=re.DOTALL
                )
            state_file.write_text(content, encoding="utf-8")

        elif legacy_dev_file.exists():
            # Update legacy development.md
            import re
            content = legacy_dev_file.read_text(encoding="utf-8")

            if primary_goal:
                content = re.sub(
                    r'\*\*Primary Goal:\*\*.*',
                    f'**Primary Goal:** {primary_goal}',
                    content
                )
                content = re.sub(
                    r'Overall goal is:.*',
                    f'Overall goal is: {primary_goal}',
                    content
                )

            if phase:
                content = re.sub(
                    r'\*\*Phase:\*\*.*',
                    f'**Phase:** {phase}',
                    content
                )
                content = re.sub(
                    r'Next action will be:.*',
                    f'Next action will be: {phase}',
                    content
                )

            content = re.sub(
                r'Last action was:.*',
                f'Last action was: Created feature branch {branch_name}',
                content
            )
            legacy_dev_file.write_text(content, encoding="utf-8")

        else:
            # Create new v2.1 state.md
            state_content = f"""# Current State

> Last updated: {__import__('datetime').datetime.now().strftime('%Y-%m-%d')}

## Active Plan

**Branch:** `{branch_name}`
**Type:** {branch_type}

## Current Focus

Working on: {primary_goal or 'To be defined'}
Phase: {phase or 'Phase 1'}

## What Was Just Done

Created feature branch `{branch_name}`.

## What's Next

{phase or 'Define first task'}

## Blockers

None
"""
            state_file.write_text(state_content, encoding="utf-8")

        # Create AGENTS.md at root if missing (v2.1)
        agents_file = root / "AGENTS.md"
        if not agents_file.exists():
            agents_content = """# AGENTS.md

## Project Overview

This project uses **PairCoder v2** for structured development workflows.

## Quick Setup

```bash
pip install -e ".[dev]"
pytest
```

## PairCoder Integration

Read these files to understand the project:
- `.paircoder/context/state.md` - Current state and active tasks
- `.paircoder/context/project.md` - Project overview
- `.paircoder/context/workflow.md` - Development workflow

## Workflow Quick Reference

1. Check state: Read `.paircoder/context/state.md`
2. Find task: Look in `.paircoder/tasks/`
3. Set task status to `in_progress`
4. Do the work
5. Set task status to `done`
6. Run `bpsai-pair context-sync`

## Context Pack

Run `bpsai-pair pack --out agent_pack.tgz` to create context package.
"""
            agents_file.write_text(agents_content, encoding="utf-8")

        # Generate project tree
        tree_file = context_dir / "project_tree.md"
        tree_content = f"""# Project Tree (snapshot)
_Generated: {datetime.now(timezone.utc).isoformat()}Z_

```
{ProjectTree.generate(root)}
```
"""
        tree_file.write_text(tree_content, encoding="utf-8")

        # Commit changes
        files_to_commit = [agents_file, tree_file]
        if state_file.exists():
            files_to_commit.append(state_file)
        if legacy_dev_file.exists():
            files_to_commit.append(legacy_dev_file)
        GitOps.add_commit(
            root,
            files_to_commit,
            f"feat(context): start {branch_name} — Primary Goal: {primary_goal or 'TBD'}"
        )

        return True
