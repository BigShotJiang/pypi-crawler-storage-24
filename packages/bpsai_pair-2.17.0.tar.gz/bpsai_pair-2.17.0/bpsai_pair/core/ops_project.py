"""Project discovery and tree generation operations."""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Set


class ProjectRootNotFoundError(Exception):
    """Raised when no project root (.paircoder or .git) is found."""

    pass


def find_project_root(start_path: Path = None) -> Path:
    """Find project root by walking up to find .paircoder/ or .git/

    Args:
        start_path: Starting path (defaults to cwd)

    Returns:
        Path to project root

    Raises:
        ProjectRootNotFoundError: If no .paircoder or .git directory is found
    """
    cwd = start_path or Path.cwd()

    for parent in [cwd, *cwd.parents]:
        if (parent / ".paircoder").exists():
            return parent
        if (parent / ".git").exists():
            return parent

    raise ProjectRootNotFoundError(
        f"No .paircoder or .git directory found starting from {cwd}. "
        "Run 'bpsai-pair init' to initialize a project, or run from a git repository."
    )


def find_paircoder_dir(start_path: Path = None) -> Path:
    """Find .paircoder directory in current or parent directories.

    Args:
        start_path: Starting path (defaults to cwd)

    Returns:
        Path to .paircoder directory (may not exist yet)

    Raises:
        ProjectRootNotFoundError: If no project root is found
    """
    root = find_project_root(start_path)
    return root / ".paircoder"


class ProjectTree:
    """Generate project tree snapshots."""

    @staticmethod
    def generate(root: Path, excludes: Optional[Set[str]] = None) -> str:
        """Generate a tree structure of the project."""
        if excludes is None:
            excludes = {
                '.git', '.venv', 'venv', '__pycache__',
                'node_modules', 'dist', 'build', '.mypy_cache',
                '.pytest_cache', '.tox', '*.egg-info', '.DS_Store'
            }

        tree_lines = []

        def should_skip(path: Path) -> bool:
            name = path.name
            for pattern in excludes:
                if pattern.startswith('*') and name.endswith(pattern[1:]):
                    return True
                if name == pattern:
                    return True
            return False

        def walk_dir(dir_path: Path, prefix: str = ""):
            items = sorted(dir_path.iterdir(), key=lambda x: (x.is_file(), x.name))
            items = [i for i in items if not should_skip(i)]

            for i, item in enumerate(items):
                is_last = i == len(items) - 1
                current = "└── " if is_last else "├── "
                tree_lines.append(f"{prefix}{current}{item.name}")

                if item.is_dir():
                    extension = "    " if is_last else "│   "
                    walk_dir(item, prefix + extension)

        tree_lines.append(".")
        walk_dir(root)
        return "\n".join(tree_lines)
