"""Helpers for enrichment hook handlers.

Internal utilities for workspace detection, telemetry snapshots,
git operations, and calibration engine initialization. All helpers
return None on failure — callers handle gracefully.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


def find_project_root() -> Path | None:
    """Find the project root by searching for .paircoder directory."""
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / ".paircoder").is_dir():
            return parent
    return None


def load_workspace(project_root: Path) -> Any:
    """Load workspace config if it exists."""
    try:
        from bpsai_pair.workspace.parser import WorkspaceParser

        parser = WorkspaceParser()
        config_path = parser.find_workspace_config(project_root)
        if config_path is None:
            return None
        return parser.parse(config_path)
    except (ImportError, FileNotFoundError, ValueError):
        return None


def gather_workspace_changes(workspace: Any, merge_base: str) -> list[Any]:
    """Gather contract changes across all workspace projects.

    Uses per-repo merge base to avoid passing the current repo's SHA
    to sibling repos where it doesn't exist.
    """
    from bpsai_pair.workspace.contracts import ContractDetector

    detector = ContractDetector(workspace)
    all_changes: list[Any] = []
    for name in workspace.get_project_names():
        project = workspace.get_project(name)
        if project is None:
            continue
        repo_path = workspace.root_path / project.path
        if not repo_path.exists():
            continue
        repo_merge_base = get_merge_base(repo_path) or merge_base
        all_changes.extend(
            detector.detect_changes(repo_path, repo_merge_base, repo_name=name)
        )
    return all_changes


def get_merge_base(project_root: Path) -> str | None:
    """Get the merge base commit for the current branch."""
    import subprocess

    try:
        default_branch = detect_default_branch(project_root)
        result = subprocess.run(
            ["git", "merge-base", "HEAD", default_branch],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def detect_default_branch(project_root: Path) -> str:
    """Detect the default branch (main/master/trunk) for a repo."""
    import subprocess

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "origin/HEAD"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            ref = result.stdout.strip()
            return ref.split("/", 1)[-1] if "/" in ref else ref
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return "main"


def build_snapshot(project_root: Path) -> Any:
    """Build a usage snapshot, returning None on failure."""
    try:
        from bpsai_pair.telemetry.config import TelemetryConfig
        from bpsai_pair.telemetry.snapshot import build_usage_snapshot

        config = TelemetryConfig.load(project_root)
        return build_usage_snapshot(project_root, config.privacy_level)
    except Exception:
        return None


def get_calibration_engine(project_root: Path) -> Any:
    """Get a CalibrationEngine, returning None on failure."""
    try:
        from bpsai_pair.feedback.calibration import CalibrationEngine

        return CalibrationEngine(project_root)
    except Exception:
        return None
