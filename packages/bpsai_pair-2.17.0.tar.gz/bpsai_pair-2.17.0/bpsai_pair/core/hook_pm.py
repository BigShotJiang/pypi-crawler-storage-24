"""Provider-agnostic PM sync hook handler.

Routes through the PM abstraction layer instead of constructing
raw TrelloService instances.  Drop-in replacement for sync_trello.
"""

from __future__ import annotations

import logging

from bpsai_pair.core.hook_types import HookContext
from bpsai_pair.pm.registry import get_active_provider
from bpsai_pair.pm.types import WorkItemStatus

logger = logging.getLogger(__name__)

_EVENT_TO_STATUS: dict[str, WorkItemStatus] = {
    "on_task_ready": WorkItemStatus.ENQUEUED,
    "on_task_start": WorkItemStatus.IN_PROGRESS,
    "on_task_review": WorkItemStatus.REVIEW,
    "on_task_complete": WorkItemStatus.DONE,
    "on_task_block": WorkItemStatus.BLOCKED,
    "on_epic_completed": WorkItemStatus.DONE,
    "on_story_completed": WorkItemStatus.DONE,
}


def sync_pm(ctx: HookContext, config: dict) -> dict:
    """Sync task state to PM provider.

    Signature matches hook "cfg" style: ``(ctx, config) -> dict``.
    """
    try:
        provider = get_active_provider(config)

        if provider.name == "none":
            return {"pm_synced": False, "reason": "No PM provider configured"}

        status = _EVENT_TO_STATUS.get(ctx.event)
        if status is None:
            return {"pm_synced": False, "reason": f"Unknown event: {ctx.event}"}

        moved = provider.move_item(ctx.task_id, status)
        if not moved:
            return {"pm_synced": False, "reason": f"move_item failed for {ctx.task_id}"}

        provider.add_comment(ctx.task_id, _format_comment(ctx))

        logger.info("PM sync: %s → %s (%s)", ctx.task_id, status.value, provider.name)
        result: dict = {
            "pm_synced": True,
            "provider": provider.name,
            "status": status.value,
        }

        # Trigger completion cascade for task-complete events (skip if already cascading)
        cascade_depth = ctx.extra.get("cascade_depth", 0)
        if ctx.event == "on_task_complete" and cascade_depth == 0:
            result["cascade_results"] = _run_cascade(provider, ctx.task_id, config)

        return result
    except Exception as e:
        logger.warning("PM sync failed: %s", e)
        logger.debug("PM sync error detail: %s", e)
        return {"pm_synced": False, "error": "provider_error"}



def _run_cascade(provider, task_id: str, config: dict | None = None) -> list[dict]:
    """Run completion cascade after a task completes."""
    if "hierarchy" not in provider.capabilities():
        return []
    try:
        from bpsai_pair.pm.compat import load_pm_config
        from bpsai_pair.pm.completion_cascade import CompletionCascade
        from bpsai_pair.pm.completion_eval import CompletionRuleEvaluator
        from bpsai_pair.pm.workflow import WorkflowConfig, WorkflowEngine

        if config:
            _, workflow_config = load_pm_config(config)
        else:
            workflow_config = WorkflowConfig.simple()
        engine = WorkflowEngine(workflow_config)
        evaluator = CompletionRuleEvaluator(provider, engine)
        cascade = CompletionCascade(provider, evaluator, engine=engine)
        results = cascade.evaluate(task_id)
        return [
            {"item_id": r.item_id, "completed": r.completed, "event": r.event}
            for r in results
        ]
    except Exception as e:
        logger.warning("Cascade failed: %s", e)
        return []


def _format_comment(ctx: HookContext) -> str:
    """Format a human-readable comment for the PM item."""
    agent = ctx.agent or "Agent"
    summary = ctx.extra.get("summary", "")
    reason = ctx.extra.get("reason", "")

    parts = [f"[{ctx.task_id}] {ctx.event} by {agent}"]
    if summary:
        parts.append(f"Summary: {summary}")
    if reason:
        parts.append(f"Reason: {reason}")
    return "\n".join(parts)
