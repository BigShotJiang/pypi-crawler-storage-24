"""Data types for the hook system.

Separated from hooks.py to keep function counts within limits.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class HookContext:
    """Context passed to hook handlers."""

    task_id: str
    event: str  # on_task_start, on_task_complete, on_task_block
    task: Any = None  # Task object (None for project-level events)
    agent: Optional[str] = None
    agent_id: Optional[str] = None  # CC 2.1.69: unique agent identifier
    agent_type: Optional[str] = None  # CC 2.1.69: "main", "subagent", etc.
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HookResult:
    """Result of a hook execution."""

    hook: str
    success: bool
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    blocked: bool = False

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        d = {"hook": self.hook, "success": self.success}
        if self.result:
            d["result"] = self.result
        if self.error:
            d["error"] = self.error
        if self.blocked:
            d["blocked"] = True
        return d
