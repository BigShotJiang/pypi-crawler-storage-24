"""Context packing operations for AI agents."""
from __future__ import annotations

import tarfile
from pathlib import Path
from typing import List, Optional, Set


class ContextPacker:
    """Package context files for AI agents."""

    @staticmethod
    def read_ignore_patterns(ignore_file: Path) -> Set[str]:
        """Read patterns from .agentpackignore file."""
        patterns = set()
        if ignore_file.exists():
            with open(ignore_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        patterns.add(line)
        else:
            # Default patterns
            patterns = {
                '.git', '.venv', '__pycache__', 'node_modules',
                'dist', 'build', '*.log', '*.bak', '*.tgz',
                '*.tar.gz', '*.zip', '.env*'
            }
        return patterns

    @staticmethod
    def should_exclude(path: Path, patterns: Set[str]) -> bool:
        """Check if path should be excluded based on patterns."""
        from pathlib import PurePath

        p = PurePath(path.as_posix())

        for pattern in patterns:
            # Handle directory patterns (ending with /)
            if pattern.endswith('/'):
                dir_pattern = pattern.rstrip('/')
                # Check if this is the directory itself or if it's inside the directory
                if path.is_dir() and p.match(dir_pattern):
                    return True
                if any(parent.match(dir_pattern) for parent in p.parents):
                    return True
            # Handle file/general patterns
            else:
                if p.match(pattern):
                    return True
                if any(parent.match(pattern) for parent in p.parents):
                    return True

        return False

    @staticmethod
    def pack(
        root: Path,
        output: Path,
        extra_files: Optional[List[str]] = None,
        dry_run: bool = False,
        lite: bool = False,
    ) -> List[Path]:
        """Create a context pack for AI agents.

        Args:
            root: Project root directory
            output: Output archive path
            extra_files: Additional files to include
            dry_run: If True, don't create archive
            lite: If True, create minimal pack for Codex (< 32KB)
        """
        if lite:
            # Minimal context for Codex CLI (32KB limit)
            context_files = [
                root / ".paircoder" / "context" / "state.md",
                root / "AGENTS.md",
            ]
        else:
            # Full context pack (v1 + v2 paths)
            context_files = [
                # v1 paths
                root / "context" / "development.md",
                root / "context" / "agents.md",
                root / "context" / "project_tree.md",
                # v2 paths
                root / ".paircoder" / "context" / "project.md",
                root / ".paircoder" / "context" / "state.md",
                root / ".paircoder" / "context" / "workflow.md",
                root / ".paircoder" / "capabilities.yaml",
                root / "AGENTS.md",
                root / "CLAUDE.md",
            ]

            # Add directory_notes if it exists
            dir_notes = root / "context" / "directory_notes"
            if dir_notes.exists():
                for note in dir_notes.rglob("*.md"):
                    context_files.append(note)

        # Add extra files
        if extra_files:
            for extra in extra_files:
                extra_path = root / extra
                if extra_path.exists():
                    context_files.append(extra_path)

        # Filter out non-existent files
        context_files = [f for f in context_files if f.exists()]

        if dry_run:
            return context_files

        # Read ignore patterns
        ignore_file = root / ".agentpackignore"
        patterns = ContextPacker.read_ignore_patterns(ignore_file)

        # Create tarball
        with tarfile.open(output, "w:gz") as tar:
            for file_path in context_files:
                # Check if file should be excluded
                if not ContextPacker.should_exclude(file_path, patterns):
                    arcname = file_path.relative_to(root)
                    tar.add(file_path, arcname=str(arcname))

        return context_files
