"""Config section builders for preset configuration.

Standalone functions that build individual sections of the
v2.9.3 config dictionary. Extracted from Preset.to_config_dict
to keep each builder under 50 lines.
"""

from __future__ import annotations

import copy
from typing import Any, Dict, Optional


def build_models_section() -> Dict[str, Any]:
    """Build the models section with default provider config."""
    return {
        "navigator": "claude-opus-4-6",
        "driver": "claude-sonnet-4-6",
        "reviewer": "claude-sonnet-4-6",
        "providers": {
            "anthropic": {
                "models": [
                    "claude-opus-4-6",
                    "claude-sonnet-4-6",
                    "claude-sonnet-4-5",
                    "claude-haiku-4-5",
                ],
                "default_effort": "medium",
            },
        },
    }


def build_routing_section(
    model_routing: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Build routing section, using custom or defaults."""
    if model_routing:
        return model_routing
    return {
        "by_complexity": {
            "trivial": {"max_score": 20, "model": "claude-haiku-4-5"},
            "simple": {"max_score": 40, "model": "claude-sonnet-4-6"},
            "moderate": {"max_score": 60, "model": "claude-sonnet-4-6"},
            "complex": {"max_score": 80, "model": "claude-opus-4-6"},
            "epic": {"max_score": 100, "model": "claude-opus-4-6"},
        },
        "overrides": {
            "security": "claude-opus-4-6",
            "architecture": "claude-opus-4-6",
        },
    }


def build_estimation_section(
    estimation_config: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Build estimation section with complexity-to-hours mapping."""
    if estimation_config:
        return estimation_config
    return {
        "complexity_to_hours": {
            "xs": {"range": [0, 15], "hours": [0.5, 1.0, 2.0]},
            "s": {"range": [16, 30], "hours": [1.0, 2.0, 4.0]},
            "m": {"range": [31, 50], "hours": [2.0, 4.0, 8.0]},
            "l": {"range": [51, 75], "hours": [4.0, 8.0, 16.0]},
            "xl": {"range": [76, 100], "hours": [8.0, 16.0, 32.0]},
        },
    }


def build_token_estimates_section() -> Dict[str, Any]:
    """Build token_estimates section (top-level in v2.9.3)."""
    return {
        "base_context": 15000,
        "per_complexity_point": 500,
        "per_file_touched": 2000,
        "by_task_type": {
            "feature": 1.2,
            "bugfix": 0.8,
            "docs": 0.6,
            "refactor": 1.5,
            "chore": 0.9,
        },
    }


def build_token_budget_section() -> Dict[str, Any]:
    """Build token_budget section."""
    return {
        "warning_threshold": 75,
        "critical_threshold": 90,
    }


def build_metrics_section(
    metrics_config: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Build metrics section with defaults."""
    if metrics_config:
        return metrics_config
    return {
        "enabled": True,
        "store_path": ".paircoder/history/metrics.jsonl",
    }


def build_hooks_section(
    hooks_config: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Build hooks section with v2.9.3 event structure."""
    if hooks_config:
        return hooks_config
    return {
        "enabled": True,
        "on_task_ready": [
            "sync_pm",
            "update_state",
        ],
        "on_task_start": [
            "select_model",
            "check_token_budget",
            "start_timer",
            "sync_pm",
            "update_state",
        ],
        "on_task_review": [
            "sync_pm",
            "update_state",
        ],
        "on_task_complete": [
            "arch_check_modified",
            "contract_break_check",
            "stop_timer",
            "workspace_impact_scan",
            "telemetry_snapshot",
            "calibration_update_incremental",
            "feedback_calibrate",
            "sync_pm",
            "update_state",
            "check_unblocked",
        ],
        "on_task_block": [
            "sync_pm",
            "update_state",
        ],
    }


def build_pm_section() -> Dict[str, Any]:
    """Build default PM section for projects without custom config."""
    return {
        "provider": "none",
        "workflow": "simple",
    }


def build_containment_section() -> Dict[str, Any]:
    """Build containment section with v2.9.3 structure."""
    return {
        "enabled": False,
        "mode": "strict",
        "auto_checkpoint": True,
        "rollback_on_violation": False,
        "blocked_directories": [],
        "blocked_files": [
            ".env",
            ".env.local",
            ".env.production",
            "credentials.json",
            "secrets.yaml",
        ],
        "readonly_directories": [
            ".claude/agents",
            ".claude/commands",
            ".claude/skills",
        ],
        "readonly_files": [
            "CLAUDE.md",
            "AGENTS.md",
        ],
        "allow_network": [
            "api.anthropic.com",
            "api.trello.com",
            "github.com",
            "pypi.org",
        ],
    }


_DEFAULT_TRELLO_LABELS = [
    {"name": "Frontend", "color": "green", "matches": ["react", "ui", "frontend", "css"]},
    {"name": "Backend", "color": "blue", "matches": ["flask", "api", "backend", "python"]},
    {"name": "Worker / Function", "color": "purple", "matches": ["worker", "function", "background", "async", "cli"]},
    {"name": "Deployment", "color": "red", "matches": ["deploy", "ci", "cd", "infra", "config"]},
    {"name": "Bug / Issue", "color": "orange", "matches": ["bug", "fix", "issue", "error"]},
    {"name": "Documentation", "color": "sky", "matches": ["docs", "documentation", "readme", "guide"]},
]

_DEFAULT_TRELLO_AUTOMATION = {
    "on_task_ready": {"move_to_list": "Planned/Ready", "set_status": "Enqueued"},
    "on_task_start": {"move_to_list": "In Progress", "set_status": "In progress"},
    "on_task_review": {"move_to_list": "Review/Testing", "set_status": "Testing"},
    "on_task_complete": {"move_to_list": "Deployed/Done", "set_status": "Done"},
    "on_task_block": {"move_to_list": "Issues/Tech Debt", "set_status": "Blocked"},
}

_DEFAULT_TRELLO_LISTS = [
    {"name": "Intake/Backlog", "maps_to_status": ["pending", "backlog"]},
    {"name": "Planned/Ready", "maps_to_status": ["ready", "planned"]},
    {"name": "In Progress", "maps_to_status": ["in_progress"]},
    {"name": "Review/Testing", "maps_to_status": ["review", "testing"]},
    {"name": "Deployed/Done", "maps_to_status": ["done", "deployed"]},
    {"name": "Issues/Tech Debt", "maps_to_status": ["blocked", "issue"]},
]


_STACK_MAPPING = {
    "cli": "Worker/Function", "python": "Flask", "backend": "Flask",
    "frontend": "React", "ui": "React", "worker": "Worker/Function",
    "function": "Worker/Function", "infra": "Infra", "deploy": "Infra",
    "ci": "Infra", "docs": "Collection", "documentation": "Collection",
}

_STATUS_MAPPING = {
    "pending": "Planning", "ready": "Enqueued", "in_progress": "In progress",
    "review": "Testing", "testing": "Testing", "done": "Done",
    "blocked": "Blocked", "waiting": "Waiting",
}


def _build_default_custom_fields(project_name: str) -> Dict[str, Any]:
    """Build default Trello custom fields with project name."""
    return {
        "project": {
            "type": "dropdown",
            "options": ["--", project_name],
            "default": project_name,
        },
        "stack": {
            "type": "dropdown",
            "options": ["--", "React", "Flask", "Worker/Function", "Infra", "Collection"],
            "mapping": dict(_STACK_MAPPING),
            "default": "Worker/Function",
        },
        "status": {
            "type": "dropdown",
            "options": ["--", "Planning", "In progress", "Testing", "Done", "Enqueued", "Waiting", "Blocked"],
            "mapping": dict(_STATUS_MAPPING),
            "default": "Planning",
        },
        "effort": {
            "type": "dropdown",
            "options": ["--", "S", "M", "L"],
            "mapping": {"0-30": "S", "31-60": "M", "61-100": "L"},
            "default": "M",
        },
        "agent_task": {"type": "checkbox", "default": False},
    }


def build_default_trello_section(project_name: str) -> Dict[str, Any]:
    """Build default Trello section for projects without custom config."""
    return {
        "enabled": False,
        "board_id": "",
        "board_name": "",
        "defaults": {
            "project": project_name,
            "stack": "Worker/Function",
            "repo_url": "",
        },
        "board_structure": {"lists": copy.deepcopy(_DEFAULT_TRELLO_LISTS)},
        "custom_fields": _build_default_custom_fields(project_name),
        "labels": copy.deepcopy(_DEFAULT_TRELLO_LABELS),
        "automation": copy.deepcopy(_DEFAULT_TRELLO_AUTOMATION),
    }


def convert_trello_config(trello_config: Dict[str, Any]) -> Dict[str, Any]:
    """Convert Trello config to v2.9.3 format if needed."""
    result: Dict[str, Any] = {
        "enabled": trello_config.get("enabled", True),
        "board_id": trello_config.get("board_id", ""),
        "board_name": trello_config.get("board_name", ""),
    }

    result["defaults"] = trello_config.get("defaults", {
        "project": "",
        "stack": "Worker/Function",
        "repo_url": "",
    })

    if "lists" in trello_config:
        old_lists = trello_config["lists"]
        result["board_structure"] = {
            "lists": [
                {"name": old_lists.get("backlog", "Intake/Backlog"), "maps_to_status": ["pending", "backlog"]},
                {"name": old_lists.get("ready", "Planned/Ready"), "maps_to_status": ["ready", "planned"]},
                {"name": old_lists.get("in_progress", "In Progress"), "maps_to_status": ["in_progress"]},
                {"name": old_lists.get("review", "Review/Testing"), "maps_to_status": ["review", "testing"]},
                {"name": old_lists.get("done", "Deployed/Done"), "maps_to_status": ["done", "deployed"]},
                {"name": old_lists.get("blocked", "Issues/Tech Debt"), "maps_to_status": ["blocked", "issue"]},
            ],
        }
    elif "board_structure" in trello_config:
        result["board_structure"] = trello_config["board_structure"]
    else:
        result["board_structure"] = {
            "lists": [
                {"name": "Intake/Backlog", "maps_to_status": ["pending", "backlog"]},
                {"name": "Planned/Ready", "maps_to_status": ["ready", "planned"]},
                {"name": "In Progress", "maps_to_status": ["in_progress"]},
                {"name": "Review/Testing", "maps_to_status": ["review", "testing"]},
                {"name": "Deployed/Done", "maps_to_status": ["done", "deployed"]},
                {"name": "Issues/Tech Debt", "maps_to_status": ["blocked", "issue"]},
            ],
        }

    for key in ["custom_fields", "labels", "automation"]:
        if key in trello_config:
            result[key] = trello_config[key]

    return result
