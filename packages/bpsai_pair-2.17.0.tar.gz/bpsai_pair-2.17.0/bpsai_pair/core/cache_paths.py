"""Cache path resolution with backward-compatible migration.

Centralizes paths for transient cache files that were previously written
to the .paircoder/ root. New location: .paircoder/cache/.
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path

logger = logging.getLogger(__name__)


def _ensure_cache_dir(paircoder_dir: Path) -> Path:
    """Ensure cache/ subdirectory exists."""
    cache_dir = paircoder_dir / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def _migrate_if_needed(old_path: Path, new_path: Path) -> None:
    """Move file from old to new location if old exists and new doesn't."""
    if old_path.exists() and not new_path.exists():
        new_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            old_path.rename(new_path)
            logger.debug("Migrated %s -> %s", old_path, new_path)
        except OSError:
            # Cross-device rename fallback
            new_path.write_bytes(old_path.read_bytes())
            old_path.unlink()


def time_tracking_cache_path(paircoder_dir: Path) -> Path:
    """Get time-tracking-cache.json path, migrating from root if needed."""
    cache_dir = _ensure_cache_dir(paircoder_dir)
    new_path = cache_dir / "time-tracking-cache.json"
    old_path = paircoder_dir / "time-tracking-cache.json"
    _migrate_if_needed(old_path, new_path)
    return new_path


def routing_decision_path(paircoder_dir: Path, task_id: str) -> Path:
    """Get routing_decision_{task_id}.json path, migrating from root if needed."""
    cache_dir = _ensure_cache_dir(paircoder_dir)
    filename = f"routing_decision_{task_id}.json"
    new_path = cache_dir / filename
    old_path = paircoder_dir / filename
    _migrate_if_needed(old_path, new_path)
    return new_path


def cleanup_orphaned_cache(
    paircoder_dir: Path,
    *,
    max_age_days: int = 7,
    max_snapshots: int = 10,
) -> dict:
    """Remove stale cache files. Returns stats dict."""
    cutoff = time.time() - (max_age_days * 86400)
    stats = {"routing_decisions_removed": 0, "snapshots_removed": 0}

    # Clean routing decisions in both old and new locations
    for search_dir in [paircoder_dir, paircoder_dir / "cache"]:
        if not search_dir.exists():
            continue
        for f in search_dir.glob("routing_decision_*.json"):
            if f.stat().st_mtime < cutoff:
                f.unlink()
                stats["routing_decisions_removed"] += 1

    # Trim compaction snapshots to max_snapshots (keep newest)
    cache_dir = paircoder_dir / "cache"
    if cache_dir.exists():
        snapshots = sorted(
            cache_dir.glob("compaction_snapshot_*.json"),
            key=lambda p: p.stat().st_mtime,
        )
        excess = len(snapshots) - max_snapshots
        if excess > 0:
            for f in snapshots[:excess]:
                f.unlink()
                stats["snapshots_removed"] += 1

    return stats


_STATE_SIZE_THRESHOLD = 200


def check_state_size(
    paircoder_dir: Path, *, threshold: int = _STATE_SIZE_THRESHOLD,
) -> str | None:
    """Check if state.md exceeds line threshold. Returns advisory or None."""
    state_file = paircoder_dir / "context" / "state.md"
    if not state_file.exists():
        return None
    try:
        line_count = len(state_file.read_text(encoding="utf-8").splitlines())
    except OSError:
        return None
    if line_count <= threshold:
        return None
    if line_count > threshold * 2:
        return (
            f"CRITICAL: state.md is {line_count} lines (threshold: {threshold}). "
            f"This consumes significant context window budget. "
            f"Consider archiving completed sprint entries."
        )
    return (
        f"state.md is {line_count} lines (threshold: {threshold}). "
        f"Consider archiving completed sprint entries to reduce context consumption."
    )
