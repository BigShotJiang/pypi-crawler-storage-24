"""State and dependency checking hook handlers.

Extracted from hooks.py to keep each module under architecture limits.
All functions accept paircoder_dir param instead of self.
"""

from __future__ import annotations

import logging
from pathlib import Path

from bpsai_pair.core.hook_types import HookContext

logger = logging.getLogger(__name__)


def update_state(ctx: HookContext, paircoder_dir: Path) -> dict:
    """Update state.md with task status based on lifecycle event.

    Only marks tasks done and writes completion entries for on_task_complete.
    Other events (on_task_ready, on_task_start, on_task_review, on_task_block)
    are no-ops — state.md completion should only reflect actual completions.
    """
    if ctx.event != "on_task_complete":
        return {"state_updated": True, "task_id": ctx.task_id}

    try:
        state_path = Path(paircoder_dir) / "context" / "state.md"
        if not state_path.exists():
            return {"state_updated": True, "task_id": ctx.task_id}

        content = state_path.read_text(encoding="utf-8")
        content = _mark_task_done_in_table(content, ctx.task_id)
        content = _prepend_what_was_just_done(content, ctx.task_id)
        state_path.write_text(content, encoding="utf-8")

        return {"state_updated": True, "task_id": ctx.task_id}
    except Exception as e:
        logger.warning(f"State update failed: {e}")
        return {"state_updated": False, "error": str(e)}


def _mark_task_done_in_table(content: str, task_id: str) -> str:
    """Mark a task as done in any markdown table row matching task_id."""
    import re
    esc_id = re.escape(task_id)
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if re.search(r'\|\s*' + esc_id + r'\s*\|', line):
            lines[i] = re.sub(
                r'\|\s*(pending|in_progress|in progress|review|blocked)\s*\|(\s*)$',
                r'| done ✓ |\2',
                line,
            )
            break
    return '\n'.join(lines)


def _prepend_what_was_just_done(content: str, task_id: str) -> str:
    """Add a completion entry to the 'What Was Just Done' section."""
    marker = "## What Was Just Done"
    idx = content.find(marker)
    if idx == -1:
        return content
    insert_at = idx + len(marker)
    entry = f"\n\n- **{task_id} done** (auto-updated by hook)"
    return content[:insert_at] + entry + content[insert_at:]


def check_unblocked(ctx: HookContext, paircoder_dir: Path) -> dict:
    """Check if completing this task unblocks others."""
    try:
        from bpsai_pair.planning.parser import TaskParser
        from bpsai_pair.planning.models import TaskStatus

        parser = TaskParser(paircoder_dir / "tasks")
        all_tasks = parser.parse_all()

        unblocked = []
        for task in all_tasks:
            depends_on = getattr(task, 'depends_on', None) or []
            if not depends_on:
                continue

            if ctx.task_id in depends_on:
                all_done = True
                for dep_id in depends_on:
                    dep_task = parser.get_task_by_id(dep_id)
                    if dep_task and dep_task.status != TaskStatus.DONE:
                        all_done = False
                        break

                if all_done and task.status == TaskStatus.BLOCKED:
                    unblocked.append(task.id)
                    logger.info(f"Task {task.id} unblocked by {ctx.task_id}")

        return {"unblocked_tasks": unblocked, "count": len(unblocked)}
    except Exception as e:
        logger.warning(f"Unblock check failed: {e}")
        return {"unblocked_tasks": [], "error": str(e)}
