"""Architecture enforcement configuration."""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Dict, Any, List


@dataclass
class ArchitectureConfig:
    """Configuration for architecture enforcement.

    Controls thresholds and behavior for architecture checks including
    file size limits, function length limits, and exclude patterns.
    """

    enabled: bool = True
    """Enable architecture enforcement."""

    max_file_lines: int = 400
    """Maximum lines before error."""

    warning_file_lines: int = 200
    """Lines before warning."""

    max_function_lines: int = 50
    """Maximum lines per function."""

    max_functions_per_file: int = 15
    """Maximum functions per file."""

    max_imports: int = 20
    """Maximum import statements."""

    exclude_patterns: List[str] = field(default_factory=list)
    """Glob patterns to exclude from checks."""

    enforce_on_commit: bool = True
    """Enable pre-commit hook enforcement."""

    enforce_on_pr: bool = True
    """Enable PR check enforcement."""

    enforce_on_ci: bool = True
    """Enable CI pipeline enforcement."""

    # Test file overrides (relaxed limits for test files)
    test_max_file_lines: int = 600
    """Maximum lines before error for test files."""

    test_warning_file_lines: int = 400
    """Lines before warning for test files."""

    test_max_function_lines: int = 50
    """Maximum lines per function for test files."""

    test_max_functions_per_file: int = 40
    """Maximum functions per file for test files."""

    test_max_imports: int = 30
    """Maximum import statements for test files."""

    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        for attr in (
            "max_file_lines", "warning_file_lines", "max_function_lines",
            "max_functions_per_file", "max_imports",
            "test_max_file_lines", "test_warning_file_lines",
            "test_max_function_lines", "test_max_functions_per_file",
            "test_max_imports",
        ):
            if getattr(self, attr) <= 0:
                raise ValueError(f"{attr} must be positive")

        if self.warning_file_lines > self.max_file_lines:
            raise ValueError(
                f"warning_file_lines ({self.warning_file_lines}) cannot exceed "
                f"max_file_lines ({self.max_file_lines})"
            )

        if self.test_warning_file_lines > self.test_max_file_lines:
            raise ValueError(
                f"test_warning_file_lines ({self.test_warning_file_lines}) "
                f"cannot exceed test_max_file_lines ({self.test_max_file_lines})"
            )

        for i, pattern in enumerate(self.exclude_patterns):
            if not pattern or not isinstance(pattern, str):
                raise ValueError(
                    f"Invalid exclude pattern at index {i}: patterns must be non-empty strings"
                )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def _flatten_legacy_keys(cls, data: Dict[str, Any]) -> None:
        """Flatten legacy nested dicts (thresholds, enforce_on, test_overrides)."""
        if "thresholds" in data and isinstance(data["thresholds"], dict):
            for k, v in data.pop("thresholds").items():
                data.setdefault(k, v)

        if "exclude" in data and "exclude_patterns" not in data:
            data["exclude_patterns"] = data.pop("exclude")
        elif "exclude" in data:
            data.pop("exclude")

        if "enforce_on" in data and isinstance(data["enforce_on"], dict):
            enforce_on = data.pop("enforce_on")
            for short, full in [("commit", "enforce_on_commit"),
                                ("pr", "enforce_on_pr"),
                                ("ci", "enforce_on_ci")]:
                if short in enforce_on:
                    data.setdefault(full, enforce_on[short])

        if "test_overrides" in data and isinstance(data["test_overrides"], dict):
            for k, v in data.pop("test_overrides").items():
                data.setdefault(f"test_{k}", v)

    _VALID_KEYS = {
        "enabled", "max_file_lines", "warning_file_lines",
        "max_function_lines", "max_functions_per_file", "max_imports",
        "exclude_patterns", "enforce_on_commit", "enforce_on_pr",
        "enforce_on_ci", "test_max_file_lines", "test_warning_file_lines",
        "test_max_function_lines", "test_max_functions_per_file",
        "test_max_imports",
    }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ArchitectureConfig":
        """Create ArchitectureConfig from dictionary."""
        cls._flatten_legacy_keys(data)
        filtered = {k: v for k, v in data.items() if k in cls._VALID_KEYS}
        return cls(**filtered)
