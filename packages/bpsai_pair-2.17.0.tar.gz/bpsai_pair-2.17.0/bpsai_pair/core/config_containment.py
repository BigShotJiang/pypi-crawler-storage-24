"""Containment configuration for controlled autonomy mode."""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Dict, Any, List

from .config_defaults import DEFAULT_CONTAINMENT_NETWORK_ALLOWLIST
from .config_helpers import validate_path_list, validate_domain_list


@dataclass
class ContainmentConfig:
    """Configuration for contained autonomy mode with three-tier access control.

    Access tiers:
    - Blocked: No read, no write (secrets, credentials, .env files)
    - Read-only: Can read, cannot write (CLAUDE.md, skills, enforcement code)
    - Read-write: Normal access (everything else - the working area)

    This configuration controls containment mode behavior, including
    which directories and files are in each tier, which network
    domains are allowed, and checkpoint/rollback behavior.

    Note: This is separate from the Docker sandbox system (security.sandbox).
    """

    enabled: bool = False
    """Enable containment mode for contained autonomy."""

    mode: str = "advisory"
    """Containment enforcement mode:
    - 'advisory': Log violations but don't block (default)
    - 'strict': Docker-based enforcement with read-only mounts
    """

    # Tier 1: Blocked (no read, no write)
    blocked_directories: List[str] = field(default_factory=list)
    """Directories that cannot be read or written (secrets, credentials)."""

    blocked_files: List[str] = field(default_factory=list)
    """Files that cannot be read or written (e.g., .env, credentials.json)."""

    # Tier 2: Read-only (can read, cannot write)
    readonly_directories: List[str] = field(default_factory=list)
    """Directories that can be read but not written (enforcement code, skills)."""

    readonly_files: List[str] = field(default_factory=list)
    """Files that can be read but not written (CLAUDE.md, config files)."""

    allow_network: List[str] = field(
        default_factory=lambda: DEFAULT_CONTAINMENT_NETWORK_ALLOWLIST.copy()
    )
    """Network domains allowed in containment mode."""

    auto_checkpoint: bool = True
    """Create git checkpoint on containment entry."""

    rollback_on_violation: bool = False
    """Rollback to checkpoint on containment violation attempts."""

    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        valid_modes = ("advisory", "strict")
        if self.mode not in valid_modes:
            raise ValueError(
                f"Invalid containment mode: {self.mode!r}. "
                f"Must be one of: {', '.join(valid_modes)}"
            )

        self.blocked_directories = validate_path_list(
            self.blocked_directories, "blocked_directories"
        )
        self.blocked_files = validate_path_list(self.blocked_files, "blocked_files")
        self.readonly_directories = validate_path_list(
            self.readonly_directories, "readonly_directories"
        )
        self.readonly_files = validate_path_list(self.readonly_files, "readonly_files")
        self.allow_network = validate_domain_list(self.allow_network)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ContainmentConfig":
        """Create ContainmentConfig from dictionary.

        Supports backward compatibility with old 'locked_*' field names
        by mapping them to 'readonly_*'.
        """
        # Handle backward compatibility: locked_* -> readonly_*
        if "locked_directories" in data and "readonly_directories" not in data:
            data["readonly_directories"] = data.pop("locked_directories")
        elif "locked_directories" in data:
            data.pop("locked_directories")

        if "locked_files" in data and "readonly_files" not in data:
            data["readonly_files"] = data.pop("locked_files")
        elif "locked_files" in data:
            data.pop("locked_files")

        valid_keys = {
            "enabled",
            "mode",
            "blocked_directories",
            "blocked_files",
            "readonly_directories",
            "readonly_files",
            "allow_network",
            "auto_checkpoint",
            "rollback_on_violation",
        }
        filtered_data = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered_data)


# Backwards compatibility alias
SandboxConfig = ContainmentConfig
