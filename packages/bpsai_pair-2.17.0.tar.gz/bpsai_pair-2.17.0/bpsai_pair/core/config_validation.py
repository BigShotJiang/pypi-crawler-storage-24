"""Configuration validation and update functions."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple

import yaml

from .config_defaults import CURRENT_CONFIG_VERSION, DEPRECATED_HOOKS, REQUIRED_SECTIONS
from .config_helpers import validate_no_unrendered_templates


@dataclass
class ConfigValidationResult:
    """Result of config validation."""

    is_valid: bool
    current_version: Optional[str]
    target_version: str
    missing_sections: List[str]
    missing_keys: Dict[str, List[str]]  # section -> missing keys
    warnings: List[str]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "is_valid": self.is_valid,
            "current_version": self.current_version,
            "target_version": self.target_version,
            "missing_sections": self.missing_sections,
            "missing_keys": self.missing_keys,
            "warnings": self.warnings,
        }


def _load_raw_config_for_validation(
    root: Path,
) -> Tuple[Optional[Dict[str, Any]], Optional[Path]]:
    """Load raw config for validation purposes."""
    v2_config = root / ".paircoder" / "config.yaml"
    v2_config_yml = root / ".paircoder" / "config.yml"
    legacy_config = root / ".paircoder.yml"

    config_file = None
    if v2_config.exists():
        config_file = v2_config
    elif v2_config_yml.exists():
        config_file = v2_config_yml
    elif legacy_config.exists():
        config_file = legacy_config

    if not config_file:
        return None, None

    validate_no_unrendered_templates(config_file)

    with open(config_file, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    return data, config_file


def _no_config_result() -> ConfigValidationResult:
    """Return validation result when no config file is found."""
    return ConfigValidationResult(
        is_valid=False,
        current_version=None,
        target_version=CURRENT_CONFIG_VERSION,
        missing_sections=REQUIRED_SECTIONS,
        missing_keys={},
        warnings=["No config file found. Run 'bpsai-pair init' to create one."],
    )


def validate_config(
    root: Path, preset_name: str = "minimal"
) -> ConfigValidationResult:
    """Validate config against preset template."""
    from .presets import get_preset

    raw_config, config_file = _load_raw_config_for_validation(root)

    if raw_config is None:
        return _no_config_result()

    preset = get_preset(preset_name)
    if not preset:
        preset = get_preset("minimal")

    template = preset.to_config_dict("Project", "Build software")

    current_version = raw_config.get("version")
    warnings = []

    if current_version and current_version != CURRENT_CONFIG_VERSION:
        warnings.append(
            f"Config version {current_version} is outdated (current: {CURRENT_CONFIG_VERSION})"
        )

    missing_sections = [
        section for section in REQUIRED_SECTIONS if section not in raw_config
    ]

    missing_keys = _find_missing_keys(template, raw_config)
    is_valid = not missing_sections and not missing_keys and not warnings

    return ConfigValidationResult(
        is_valid=is_valid,
        current_version=current_version,
        target_version=CURRENT_CONFIG_VERSION,
        missing_sections=missing_sections,
        missing_keys=missing_keys,
        warnings=warnings,
    )


def update_config(
    root: Path, preset_name: str = "minimal"
) -> Tuple[Dict[str, Any], List[str]]:
    """Update config with missing sections from preset.

    Args:
        root: Project root directory
        preset_name: Preset to use for defaults

    Returns:
        Tuple of (updated config dict, list of changes made)
    """
    from .presets import get_preset

    raw_config, config_file = _load_raw_config_for_validation(root)

    if raw_config is None:
        raise ValueError("No config file found. Run 'bpsai-pair init' first.")

    preset = get_preset(preset_name)
    if not preset:
        preset = get_preset("minimal")

    project_name = raw_config.get("project", {}).get("name", "My Project")
    primary_goal = raw_config.get("project", {}).get(
        "primary_goal", "Build software"
    )

    template = preset.to_config_dict(project_name, primary_goal)

    changes = []

    old_version = raw_config.get("version")
    if old_version != CURRENT_CONFIG_VERSION:
        raw_config["version"] = CURRENT_CONFIG_VERSION
        changes.append(f"Updated version: {old_version} → {CURRENT_CONFIG_VERSION}")

    _apply_template_defaults(raw_config, template, changes)

    return raw_config, changes


def _find_missing_keys(
    template: Dict[str, Any], raw_config: Dict[str, Any],
) -> Dict[str, List[str]]:
    """Find keys present in template but missing from raw_config sections."""
    missing_keys: Dict[str, List[str]] = {}
    for section, section_template in template.items():
        if (
            section in raw_config
            and isinstance(section_template, dict)
            and isinstance(raw_config[section], dict)
        ):
            section_missing = [
                key for key in section_template if key not in raw_config[section]
            ]
            if section_missing:
                missing_keys[section] = section_missing
    return missing_keys


def _merge_hook_lists(
    template_hooks: List[str], project_hooks: List[str],
) -> List[str]:
    """Merge project hooks with template hooks.

    Strategy: template order first, then custom project hooks appended.
    Deprecated hooks are removed from the result.
    """
    template_set = set(template_hooks)
    # Custom hooks: in project but not in template, and not deprecated
    custom = [
        h for h in project_hooks
        if h not in template_set and h not in DEPRECATED_HOOKS
    ]
    return list(template_hooks) + custom


def _apply_template_defaults(
    raw_config: Dict[str, Any],
    template: Dict[str, Any],
    changes: List[str],
) -> None:
    """Add missing sections and keys from template to raw_config."""
    for section in REQUIRED_SECTIONS:
        if section not in raw_config and section in template:
            raw_config[section] = template[section]
            changes.append(f"Added section: {section}")

    for section, section_template in template.items():
        if (
            section in raw_config
            and isinstance(section_template, dict)
            and isinstance(raw_config[section], dict)
        ):
            for key, value in section_template.items():
                if key not in raw_config[section]:
                    raw_config[section][key] = value
                    changes.append(f"Added key: {section}.{key}")

    _apply_hooks_update(raw_config, template, changes)


def _apply_hooks_update(
    raw_config: Dict[str, Any],
    template: Dict[str, Any],
    changes: List[str],
) -> None:
    """Update hook event lists to match template, preserving custom hooks."""
    if "hooks" not in raw_config or "hooks" not in template:
        return
    project_hooks = raw_config["hooks"]
    template_hooks = template["hooks"]
    if not isinstance(project_hooks, dict) or not isinstance(template_hooks, dict):
        return

    for event, template_list in template_hooks.items():
        if not isinstance(template_list, list):
            continue
        project_list = project_hooks.get(event, [])
        if not isinstance(project_list, list):
            continue
        merged = _merge_hook_lists(template_list, project_list)
        if merged != project_list:
            project_hooks[event] = merged
            changes.append(f"Updated hooks: {event}")
