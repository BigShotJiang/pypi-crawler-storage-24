"""Model routing — static complexity-based and data-driven selection.

Loads the routing section from config.yaml for static complexity
routing, and provides a DataDrivenRouter that uses per-model
calibration stats to select the cheapest model meeting quality
thresholds.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

# Default model fallbacks - used when config doesn't specify
_DEFAULT_DRIVER_MODEL = "claude-sonnet-4-6"
_DEFAULT_NAVIGATOR_MODEL = "claude-opus-4-6"


def _get_default_driver_model() -> str:
    """Get default driver model from config.yaml models section."""
    try:
        import yaml
        from pathlib import Path
        from .ops import find_project_root

        root = find_project_root()
        config_file = root / ".paircoder" / "config.yaml"
        if config_file.exists():
            with open(config_file, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            return config.get("models", {}).get("driver", _DEFAULT_DRIVER_MODEL)
    except (OSError, yaml.YAMLError, KeyError, TypeError, AttributeError):
        pass
    return _DEFAULT_DRIVER_MODEL


def _get_default_navigator_model() -> str:
    """Get default navigator model from config.yaml models section."""
    try:
        import yaml
        from pathlib import Path
        from .ops import find_project_root

        root = find_project_root()
        config_file = root / ".paircoder" / "config.yaml"
        if config_file.exists():
            with open(config_file, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            return config.get("models", {}).get("navigator", _DEFAULT_NAVIGATOR_MODEL)
    except (OSError, yaml.YAMLError, KeyError, TypeError, AttributeError):
        pass
    return _DEFAULT_NAVIGATOR_MODEL


@dataclass
class RoutingLevel:
    """Configuration for a complexity routing level."""
    max_score: int
    model: str

    @classmethod
    def from_dict(cls, data: dict) -> "RoutingLevel":
        # Use config-aware default for model
        default_model = data.get("model")
        if default_model is None:
            default_model = _get_default_driver_model()
        return cls(
            max_score=data.get("max_score", 100),
            model=default_model,
        )


@dataclass
class RoutingConfig:
    """Model routing configuration.
    
    Determines which AI model to use based on task complexity
    or task type overrides.
    """
    by_complexity: dict[str, RoutingLevel] = field(default_factory=dict)
    overrides: dict[str, str] = field(default_factory=dict)
    
    @classmethod
    def from_dict(cls, data: dict) -> "RoutingConfig":
        """Create RoutingConfig from config dict."""
        by_complexity = {}
        for name, level_data in data.get("by_complexity", {}).items():
            by_complexity[name] = RoutingLevel.from_dict(level_data)
        
        return cls(
            by_complexity=by_complexity,
            overrides=data.get("overrides", {}),
        )
    
    def get_model_for_complexity(self, score: int) -> str:
        """Get appropriate model for complexity score.

        Args:
            score: Complexity score (0-100)

        Returns:
            Model identifier string
        """
        if not self.by_complexity:
            # No routing config - use default driver model from config
            return _get_default_driver_model()

        # Sort levels by max_score and find appropriate level
        sorted_levels = sorted(
            self.by_complexity.items(),
            key=lambda x: x[1].max_score
        )

        for level_name, level in sorted_levels:
            if score <= level.max_score:
                return level.model

        # Score exceeds all levels — return most capable model
        return sorted_levels[-1][1].model
    
    def get_model_for_task_type(self, task_type: str) -> Optional[str]:
        """Get model override for task type.
        
        Args:
            task_type: Type of task (security, architecture, etc.)
            
        Returns:
            Model identifier if override exists, None otherwise
        """
        return self.overrides.get(task_type)
    
    def get_model(self, complexity: int = 50, task_type: Optional[str] = None) -> str:
        """Get best model for given parameters.
        
        Task type overrides take precedence over complexity routing.
        
        Args:
            complexity: Task complexity score (0-100)
            task_type: Optional task type for override lookup
            
        Returns:
            Model identifier string
        """
        # Check for type override first
        if task_type:
            override = self.get_model_for_task_type(task_type)
            if override:
                return override
        
        # Fall back to complexity routing
        return self.get_model_for_complexity(complexity)


@dataclass
class EnforcementConfig:
    """Enforcement configuration settings."""
    state_machine: bool = False
    strict_mode: bool = True
    require_ac_verification: bool = True
    require_budget_check: bool = True
    
    @classmethod
    def from_dict(cls, data: dict) -> "EnforcementConfig":
        return cls(
            state_machine=data.get("state_machine", False),
            strict_mode=data.get("strict_mode", True),
            require_ac_verification=data.get("require_ac_verification", True),
            require_budget_check=data.get("require_budget_check", True),
        )


def load_config_with_routing(path=None):
    """Load config with routing and enforcement sections parsed."""
    import yaml
    from pathlib import Path
    from .ops import find_paircoder_dir
    
    if path is None:
        paircoder_dir = find_paircoder_dir()
        path = paircoder_dir / "config.yaml"
    
    if not path.exists():
        return {
            "routing": RoutingConfig(),
            "enforcement": EnforcementConfig(),
        }
    
    with open(path, "r", encoding='utf-8') as f:
        data = yaml.safe_load(f) or {}
    
    # Parse routing section
    routing_data = data.get("routing", {})
    routing = RoutingConfig.from_dict(routing_data)
    
    # Parse enforcement section
    enforcement_data = data.get("enforcement", {})
    enforcement = EnforcementConfig.from_dict(enforcement_data)
    
    # Return full config with parsed sections
    return {
        **data,
        "routing": routing,
        "enforcement": enforcement,
    }


# ============================================================================
# DATA-DRIVEN ROUTER
# ============================================================================

# Default cost multiplier for unknown models
_DEFAULT_COST = 5.0


@dataclass
class DataDrivenRouter:
    """Data-driven model selection using per-model calibration stats.

    Selects the cheapest model whose success rate meets the quality
    threshold. Falls back to None when insufficient calibration data.
    """

    quality_threshold: float = 0.80
    min_samples: int = 3
    cost_weights: dict[str, float] = field(default_factory=lambda: {
        "haiku": 1.0, "sonnet": 3.0, "opus": 10.0,
    })

    def select_model(
        self, task_type: str, calibration_data: Any,
    ) -> str | None:
        """Select cheapest model meeting quality threshold.

        Args:
            task_type: Task type to query calibration for.
            calibration_data: CalibrationData with per-model stats.

        Returns:
            Model name, or None if insufficient data.
        """
        prefix = f"{task_type}:"
        candidates: list[tuple[str, float, float]] = []

        for key, stats in calibration_data.task_types.items():
            if not key.startswith(prefix):
                continue
            if stats.sample_count < self.min_samples:
                continue
            if stats.success_rate >= self.quality_threshold:
                model = stats.model
                cost = self._model_cost(model)
                candidates.append((model, cost, stats.success_rate))

        if not candidates:
            return None

        # Cheapest first; break ties by highest success rate
        candidates.sort(key=lambda x: (x[1], -x[2]))
        return candidates[0][0]

    def _model_cost(self, model: str) -> float:
        """Look up cost weight, matching full model IDs to short family names."""
        # Try exact match first, then substring match against family names
        if model in self.cost_weights:
            return self.cost_weights[model]
        model_lower = model.lower()
        for family, cost in self.cost_weights.items():
            if family in model_lower:
                return cost
        return _DEFAULT_COST

    @classmethod
    def from_config(cls, config: dict) -> DataDrivenRouter:
        """Create from config dict (routing.data_driven section)."""
        dd = config.get("routing", {})
        if isinstance(dd, dict):
            dd = dd.get("data_driven", {})
        else:
            dd = {}
        return cls(
            quality_threshold=dd.get("quality_threshold", 0.80),
            min_samples=dd.get("min_samples", 3),
            cost_weights=dd.get("cost_weights", {
                "haiku": 1.0, "sonnet": 3.0, "opus": 10.0,
            }),
        )


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_routing_config() -> RoutingConfig:
    """Get routing configuration from config.yaml."""
    config = load_config_with_routing()
    routing = config.get("routing")
    if isinstance(routing, RoutingConfig):
        return routing
    return RoutingConfig()


def get_model_for_task(complexity: int, task_type: Optional[str] = None) -> str:
    """Get appropriate model for a task.
    
    Convenience function that loads config and returns model.
    
    Args:
        complexity: Task complexity score (0-100)
        task_type: Optional task type for override lookup
        
    Returns:
        Model identifier string
    """
    routing = get_routing_config()
    return routing.get_model(complexity=complexity, task_type=task_type)
