"""Acceptance criteria verification for task files.

Verifies, syncs, and checks AC items in local task markdown files.
"""
import re
from pathlib import Path
from typing import Optional


def _find_tasks_dir(tasks_dir: Optional[Path]) -> tuple[Optional[Path], Optional[str]]:
    """Resolve tasks directory, returning (path, error)."""
    if tasks_dir is not None:
        return tasks_dir, None
    try:
        from .ops import find_paircoder_dir
        paircoder_dir = find_paircoder_dir()
        if paircoder_dir:
            return paircoder_dir / "tasks", None
        return None, "Could not find .paircoder directory"
    except Exception as e:
        return None, str(e)


def _find_task_file(task_id: str, tasks_dir: Path) -> Optional[Path]:
    """Find task file by ID, searching subdirectories if needed."""
    task_file = tasks_dir / f"{task_id}.task.md"
    if task_file.exists():
        return task_file
    found_files = list(tasks_dir.glob(f"**/{task_id}.task.md"))
    return found_files[0] if found_files else None


def _read_task_content(
    task_id: str, tasks_dir: Optional[Path]
) -> tuple[Optional[str], Optional[Path], Optional[str]]:
    """Resolve dir, find file, read content. Returns (content, file_path, error)."""
    resolved_dir, error = _find_tasks_dir(tasks_dir)
    if error:
        return None, None, error
    task_file = _find_task_file(task_id, resolved_dir)
    if task_file is None:
        return None, None, None  # No file found (not an error)
    try:
        content = task_file.read_text(encoding="utf-8")
        return content, task_file, None
    except Exception as e:
        return None, task_file, f"Could not read task file: {e}"


def verify_ac_from_content(content: str) -> dict:
    """Verify AC from content string. Used by pre-edit hooks."""
    # Matches - [ ]/- [x] and * [ ]/* [x] markdown checkboxes
    checked_pattern = re.compile(r'^[ \t]*[-*]\s*\[x\]\s*(.+)$', re.MULTILINE | re.IGNORECASE)
    unchecked_pattern = re.compile(r'^[ \t]*[-*]\s*\[\s*\]\s*(.+)$', re.MULTILINE)

    checked_items = checked_pattern.findall(content)
    unchecked_items = unchecked_pattern.findall(content)
    total = len(checked_items) + len(unchecked_items)

    if total == 0:
        return {"verified": True, "total": 0, "checked": 0, "unchecked_items": []}

    return {
        "verified": len(unchecked_items) == 0,
        "total": total,
        "checked": len(checked_items),
        "unchecked_items": unchecked_items,
    }


def _empty_ac_result(verified: bool, error: Optional[str] = None) -> dict:
    """Build an empty AC result dict."""
    return {"verified": verified, "total": 0, "checked": 0,
            "unchecked_items": [], "error": error}


def verify_local_ac(task_id: str, tasks_dir: Optional[Path] = None) -> dict:
    """Verify all AC in local task file are checked. Returns dict with verified/error."""
    content, _, error = _read_task_content(task_id, tasks_dir)
    if error:
        return _empty_ac_result(False, error)
    if content is None:
        return _empty_ac_result(True)  # No file = verified

    # Local files use - [ ] only (not * [ ])
    checked_pattern = re.compile(r'^[ \t]*-\s*\[x\]\s*(.+)$', re.MULTILINE | re.IGNORECASE)
    unchecked_pattern = re.compile(r'^[ \t]*-\s*\[\s*\]\s*(.+)$', re.MULTILINE)

    checked_items = checked_pattern.findall(content)
    unchecked_items = unchecked_pattern.findall(content)
    total = len(checked_items) + len(unchecked_items)

    if total == 0:
        return _empty_ac_result(True)

    return {
        "verified": len(unchecked_items) == 0,
        "total": total,
        "checked": len(checked_items),
        "unchecked_items": unchecked_items,
        "error": None,
    }


def sync_trello_ac_to_local(task_id: str, tasks_dir: Optional[Path] = None) -> dict:
    """Check all unchecked AC items in local task file (sync from Trello)."""
    content, task_file, error = _read_task_content(task_id, tasks_dir)
    if error:
        return {"success": False, "checked_count": 0, "error": error}
    if content is None:
        return {"success": True, "checked_count": 0, "error": None}

    unchecked_pattern = re.compile(r'^([ \t]*-\s*)\[\s*\]', re.MULTILINE)
    checked_count = len(unchecked_pattern.findall(content))

    if checked_count == 0:
        return {"success": True, "checked_count": 0, "error": None}

    new_content = unchecked_pattern.sub(r'\1[x]', content)
    try:
        task_file.write_text(new_content, encoding="utf-8")
    except Exception as e:
        return {"success": False, "checked_count": 0,
                "error": f"Could not write task file: {e}"}

    return {"success": True, "checked_count": checked_count, "error": None}


def is_trello_task(task_id: str, tasks_dir: Optional[Path] = None) -> bool:
    """Check if a task has a linked Trello card (trello_card_id in frontmatter)."""
    content, _, error = _read_task_content(task_id, tasks_dir)
    if error or content is None:
        return False
    pattern = re.compile(r'^trello_card_id:\s*[\'"]?(\d+)[\'"]?\s*$', re.MULTILINE)
    return pattern.search(content) is not None
