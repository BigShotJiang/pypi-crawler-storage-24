"""Token budget checking hook handler.

Extracted from hooks.py to keep each module under architecture limits.
All functions accept config/paircoder_dir params instead of self.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

from bpsai_pair.core.hook_types import HookContext

logger = logging.getLogger(__name__)


def check_token_budget(
    ctx: HookContext, config: dict, paircoder_dir: Path,
) -> dict:
    """Check token budget before starting a task."""
    try:
        from bpsai_pair.tokens import estimate_from_task_file, get_budget_status, THRESHOLDS

        task_file = _find_task_file(ctx.task_id, paircoder_dir)
        if not task_file:
            return {"budget_checked": False, "reason": f"Task file not found for {ctx.task_id}"}
        estimate = estimate_from_task_file(task_file)
        if not estimate:
            return {"budget_checked": False, "reason": "Could not estimate tokens"}

        budget_config = config.get("token_budget", {})
        warning_threshold = budget_config.get("warning_threshold", THRESHOLDS["warning"])
        status = get_budget_status(estimate.total)
        over_threshold = estimate.budget_percent >= warning_threshold

        result: dict[str, Any] = {
            "budget_checked": True, "task_id": ctx.task_id,
            "estimated_tokens": estimate.total, "budget_percent": estimate.budget_percent,
            "threshold": warning_threshold, "over_threshold": over_threshold,
            "status": status.status,
        }

        if over_threshold:
            _handle_over_threshold(result, estimate, warning_threshold, ctx)
        else:
            result["action"] = "passed"
        return result
    except ImportError as e:
        logger.warning(f"Token budget check failed: {e}")
        return {"budget_checked": False, "error": f"Import error: {e}"}
    except Exception as e:
        logger.warning(f"Token budget check failed: {e}")
        return {"budget_checked": False, "error": str(e)}


def _find_task_file(task_id: str, paircoder_dir: Path) -> Path | None:
    """Find the task file for a given task ID."""
    tasks_dir = paircoder_dir / "tasks"
    for pattern in [f"{task_id}.task.md", f"TASK-{task_id}.task.md"]:
        path = tasks_dir / pattern
        if path.exists():
            return path
    return None


def _handle_over_threshold(
    result: dict, estimate: Any, warning_threshold: float, ctx: HookContext,
) -> None:
    """Handle the case when budget exceeds threshold."""
    is_interactive = sys.stdout.isatty() and sys.stdin.isatty()
    force = ctx.extra.get("force", False)

    if force:
        result["action"] = "continued_with_force"
        logger.warning(
            f"Token budget warning bypassed with --force for {ctx.task_id}"
        )
        _log_budget_bypass(ctx, estimate)
    elif is_interactive:
        _prompt_interactive(result, estimate, warning_threshold, ctx)
    else:
        _block_non_interactive(result, estimate, ctx)


def _log_budget_bypass(ctx: HookContext, estimate: Any) -> None:
    """Log a budget override to the bypass audit trail."""
    try:
        from bpsai_pair.core.bypass_log import log_bypass
        log_bypass(
            command="check_token_budget",
            target=ctx.task_id,
            reason=(
                f"Budget override: {estimate.total:,} tokens "
                f"({estimate.budget_percent}% of budget)"
            ),
            bypass_type="budget_override",
            metadata={
                "estimated_tokens": estimate.total,
                "budget_percent": estimate.budget_percent,
            },
            silent=True,
        )
    except Exception as e:
        logger.error(f"Failed to log budget bypass: {e}")


def _block_non_interactive(
    result: dict, estimate: Any, ctx: HookContext,
) -> None:
    """Block execution in non-interactive mode when over budget."""
    reason = (
        f"Task {ctx.task_id} estimated at {estimate.total:,} tokens "
        f"({estimate.budget_percent}% of budget) — exceeds threshold. "
        f"Use --force to override."
    )
    result["action"] = "blocked_non_interactive"
    result["blocked"] = True
    result["reason"] = reason
    logger.warning(
        f"Token budget BLOCKED (non-interactive) for {ctx.task_id}: "
        f"{estimate.total:,} tokens ({estimate.budget_percent}%)"
    )


def _prompt_interactive(
    result: dict, estimate: Any, warning_threshold: float, ctx: HookContext,
) -> None:
    """Print budget warning and prompt user for confirmation."""
    print(f"\n\u26a0\ufe0f  TOKEN BUDGET WARNING")
    print(
        f"Task {ctx.task_id} estimated at {estimate.total:,} tokens "
        f"({estimate.budget_percent}% of budget)"
    )
    print(f"Threshold: {warning_threshold}%")
    print("\nBreakdown:")
    print(f"  Base context:  {estimate.base_context:,}")
    print(f"  Task file:     {estimate.task_file:,}")
    print(f"  Source files:  {estimate.source_files:,}")
    print(f"  Est. output:   {estimate.estimated_output:,}")
    print(f"  Total:         {estimate.total:,}")
    print("\nConsider breaking into smaller subtasks.")

    try:
        response = input("\nContinue anyway? [y/N]: ").strip().lower()
        if response == "y":
            result["action"] = "user_continued"
            logger.info(
                f"User chose to continue despite budget warning for {ctx.task_id}"
            )
        else:
            result["action"] = "user_aborted"
            result["aborted"] = True
            logger.info(
                f"User aborted task {ctx.task_id} due to budget warning"
            )
    except (EOFError, KeyboardInterrupt):
        result["action"] = "user_aborted"
        result["aborted"] = True
