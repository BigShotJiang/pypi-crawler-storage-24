"""Orchestration stop-condition hooks for CC 2.1.69 TeammateIdle/TaskCompleted.

EXPERIMENTAL: Enabled via config flag `orchestration.experimental_stop_conditions`.

Evaluates whether a teammate agent should be stopped based on:
- Sprint/task token budget exceeded
- Review found blocking issues
- All sprint tasks completed

Returns JSON for CC hook response: {"continue": false, "reason": "..."} to stop,
or {"continue": true} to let the agent continue.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

logger = logging.getLogger(__name__)

_STATUS_RE = re.compile(r"^status:\s+(\S+)", re.MULTILINE)


@dataclass
class StopCondition:
    """Result of a single stop-condition check."""

    triggered: bool = False
    reason: Optional[str] = None


def evaluate_stop_conditions(
    event: str,
    agent_id: Optional[str],
    agent_type: Optional[str],
    project_root: Path,
) -> dict:
    """Evaluate all stop conditions and return CC hook response.

    Safe by default: any error returns {"continue": true} so we never
    accidentally block an agent due to our own bug.
    """
    result: dict = {"continue": True}
    if agent_id:
        result["agent_id"] = agent_id

    config = _load_config(project_root)
    if not config:
        return result

    orch = config.get("orchestration", {})
    if not orch.get("experimental_stop_conditions"):
        return result

    try:
        conditions = [
            _check_budget_exceeded(project_root, orch),
            _check_review_blocked(project_root),
            _check_all_tasks_done(project_root),
        ]
        for condition in conditions:
            if condition.triggered:
                result["continue"] = False
                result["reason"] = condition.reason
                logger.info(
                    "Stop condition met for %s (%s): %s",
                    agent_id or "unknown", event, condition.reason,
                )
                return result
    except Exception as e:
        logger.warning("Stop condition evaluation failed: %s", e)
        result["continue"] = True

    return result


def _load_config(project_root: Path) -> Optional[Dict[str, Any]]:
    """Load and parse config.yaml once. Returns None on failure."""
    config_path = project_root / ".paircoder" / "config.yaml"
    if not config_path.exists():
        return None
    try:
        return yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except Exception:
        return None


def _check_budget_exceeded(
    project_root: Path, orch_config: dict,
) -> StopCondition:
    """Check if sprint or task token budget is exceeded."""
    budget_limit = orch_config.get("token_budget_limit")
    if not budget_limit:
        return StopCondition()
    try:
        from bpsai_pair.telemetry.queries import TelemetryQueries
        from bpsai_pair.telemetry.store import TelemetryStore

        store = TelemetryStore(project_root)
        queries = TelemetryQueries(store)
        summary = queries.get_cost_summary()
        if summary["total_input_tokens"] > budget_limit:
            return StopCondition(
                triggered=True,
                reason=f"Sprint budget exceeded: {summary['total_input_tokens']:,}/{budget_limit:,} tokens",
            )
    except Exception as e:
        logger.debug("Budget check skipped: %s", e)
    return StopCondition()


def _check_review_blocked(project_root: Path) -> StopCondition:
    """Check if a recent review has blocking findings."""
    review_dir = project_root / ".paircoder" / "reviews"
    if not review_dir.exists():
        return StopCondition()
    try:
        reviews = sorted(review_dir.glob("*.json"), reverse=True)
        if not reviews:
            return StopCondition()
        latest = json.loads(reviews[0].read_text(encoding="utf-8"))
        blockers = latest.get("blockers", [])
        if blockers:
            return StopCondition(
                triggered=True,
                reason=f"Review has {len(blockers)} blocker(s)",
            )
    except Exception as e:
        logger.debug("Review check skipped: %s", e)
    return StopCondition()


def _check_all_tasks_done(project_root: Path) -> StopCondition:
    """Check if all tasks in the current sprint are done."""
    tasks_dir = project_root / ".paircoder" / "tasks"
    if not tasks_dir.exists():
        return StopCondition()
    try:
        # Match TaskParser.list_tasks: flat + one level of subdirectories
        task_files = list(tasks_dir.glob("*.task.md"))
        for subdir in tasks_dir.iterdir():
            if subdir.is_dir():
                task_files.extend(subdir.glob("*.task.md"))
        if not task_files:
            return StopCondition()
        total = 0
        done = 0
        for tf in task_files:
            content = tf.read_text(encoding="utf-8")
            match = _STATUS_RE.search(content)
            if match:
                total += 1
                if match.group(1) == "done":
                    done += 1
        if total > 0 and done == total:
            return StopCondition(
                triggered=True,
                reason=f"All {done}/{total} tasks complete",
            )
    except Exception as e:
        logger.debug("All-tasks-done check skipped: %s", e)
    return StopCondition()
