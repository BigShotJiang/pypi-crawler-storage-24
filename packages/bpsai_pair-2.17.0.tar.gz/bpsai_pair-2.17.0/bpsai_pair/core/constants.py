"""
Central constants for PairCoder CLI.

This module contains shared constants used across the CLI,
particularly task ID patterns for consistent validation.

Task IDs are format-agnostic: the source of truth is the ``id:``
field in each task file's YAML frontmatter, not a regex.
"""
import re
from pathlib import Path
from typing import Dict

import yaml

# ---------------------------------------------------------------------------
# Legacy pattern (restrictive) -- kept for PR-title extraction, card name
# fallback on unbracketed names, and any code that specifically needs the
# old known formats.
# ---------------------------------------------------------------------------
TASK_ID_PATTERN_LEGACY = (
    r"(TASK-\d+|(?:[A-Z]+-)?T-[A-Za-z0-9]+\.\d+"
    r"|(?:[A-Z]+-)?T\d+\.\d+(?:\.\d+)?|REL-\d+-\d+|BUG-\d+)"
)
_LEGACY_REGEX = re.compile(TASK_ID_PATTERN_LEGACY, re.IGNORECASE)

# ---------------------------------------------------------------------------
# Permissive pattern -- any reasonable identifier token.
# Matches: TASK-123, T18.1, PROJ-456, #4567, CLI-T35.3, my-task-1, etc.
# Characters allowed: A-Za-z0-9 . _ # -
# Must start with an alphanumeric or '#'.
# ---------------------------------------------------------------------------
TASK_ID_PATTERN = r"([A-Za-z0-9#][A-Za-z0-9._#-]*)"

# Compiled regex for performance
TASK_ID_REGEX = re.compile(TASK_ID_PATTERN)

# Pattern for matching task IDs in titles like "[TASK-001] Title"
TASK_ID_IN_TITLE_PATTERN = r"\[" + TASK_ID_PATTERN[1:-1] + r"\]"

# ---------------------------------------------------------------------------
# Glob patterns for finding task files -- single universal pattern.
# All *.task.md files are discovered; the id: frontmatter field is the
# source of truth for the task ID.
# ---------------------------------------------------------------------------
TASK_FILE_GLOBS = [
    "*.task.md",
]


def is_valid_task_id(task_id: str) -> bool:
    """Check if a string is a valid task ID.

    Must be a well-formed token (alphanumeric + ``. _ # -``) AND have
    at least one structural signal: contains a digit, a separator
    (``-``, ``.``, ``#``), or matches a legacy known format.
    Plain English words like ``"hello"`` or ``"Status"`` are rejected.

    Args:
        task_id: String to check

    Returns:
        True if valid task ID format
    """
    if not task_id or not task_id.strip():
        return False
    if not TASK_ID_REGEX.fullmatch(task_id):
        return False
    # Require structural signal: digit, separator, or hash prefix
    if _HAS_STRUCTURAL_SIGNAL.search(task_id):
        return True
    return False


_HAS_STRUCTURAL_SIGNAL = re.compile(r"[\d.#-]")


def extract_task_id(text: str) -> str | None:
    """Extract task ID from text.

    Looks for a bracketed ``[ID]`` first (most reliable), then falls
    back to the legacy restrictive pattern for unbracketed text.

    Args:
        text: Text potentially containing a task ID

    Returns:
        Task ID or None if not found
    """
    if not text:
        return None

    # Priority 1: bracketed [ID]
    bracket_match = re.search(r"\[([A-Za-z0-9#][A-Za-z0-9._#-]*)\]", text)
    if bracket_match and is_valid_task_id(bracket_match.group(1)):
        return bracket_match.group(1)

    # Priority 2: legacy restrictive pattern (avoids false positives on
    # random English words when there are no brackets)
    legacy_match = _LEGACY_REGEX.search(text)
    if legacy_match:
        return legacy_match.group(1)

    return None


def extract_task_id_from_card_name(card_name: str) -> str | None:
    """Extract task ID from Trello card name.

    For bracketed format ``[ID] Title``, accepts any valid task ID
    inside the brackets. For unbracketed card names, falls back to
    the legacy restrictive pattern.

    Args:
        card_name: Card name with potential task ID prefix

    Returns:
        Task ID or None if not found
    """
    if card_name.startswith("[") and "]" in card_name:
        potential_id = card_name[1:card_name.index("]")]
        if potential_id and is_valid_task_id(potential_id):
            return potential_id
    return None


def discover_task_ids(tasks_dir: Path) -> Dict[str, Path]:
    """Scan ``*.task.md`` files and return ``{id: path}`` mapping.

    Reads the YAML frontmatter ``id:`` field from each file. If a
    file has no frontmatter or no ``id`` field, falls back to the
    filename stem (without ``.task``).

    Args:
        tasks_dir: Directory to scan for task files

    Returns:
        Mapping of task ID to its file path
    """
    result: Dict[str, Path] = {}
    if not tasks_dir.is_dir():
        return result

    for task_file in sorted(tasks_dir.glob("*.task.md")):
        task_id = _read_task_id_from_file(task_file)
        if task_id:
            result[task_id] = task_file

    return result


def _read_task_id_from_file(task_file: Path) -> str | None:
    """Read the task ID from a task file's frontmatter or filename.

    Args:
        task_file: Path to a ``*.task.md`` file

    Returns:
        Task ID string, or None on read failure
    """
    try:
        content = task_file.read_text(encoding="utf-8")
    except OSError:
        return None

    # Try YAML frontmatter
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            try:
                frontmatter = yaml.safe_load(parts[1])
                if isinstance(frontmatter, dict) and frontmatter.get("id"):
                    return str(frontmatter["id"])
            except Exception:
                pass

    # Fallback: derive from filename (strip .task.md suffix)
    stem = task_file.stem  # e.g. "PROJ-123.task" from "PROJ-123.task.md"
    if stem.endswith(".task"):
        stem = stem[: -len(".task")]
    return stem if stem else None
