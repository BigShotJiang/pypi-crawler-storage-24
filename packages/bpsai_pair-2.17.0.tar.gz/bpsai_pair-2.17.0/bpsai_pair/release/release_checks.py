"""Release readiness checks for release_prep command.

Check functions for version consistency, changelog, git status,
test suite, documentation freshness, and template drift.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path
from typing import Optional

import yaml
from rich.console import Console
from rich.table import Table

console = Console()


def load_release_config(paircoder_dir: Path) -> dict:
    """Load release config from config.yaml with defaults."""
    config = {
        "version_source": "pyproject.toml",
        "documentation": ["CHANGELOG.md", "README.md", ".paircoder/docs/FEATURE_MATRIX.md"],
        "freshness_days": 7,
    }
    config_path = paircoder_dir / "config.yaml"
    if config_path.exists():
        with open(config_path, encoding='utf-8') as f:
            full_config = yaml.safe_load(f) or {}
            if "release" in full_config:
                config.update(full_config["release"])
    return config


def get_template_path(paircoder_dir: Path) -> Optional[Path]:
    """Get the cookie cutter template path from config or default."""
    config_path = paircoder_dir / "config.yaml"
    template_path = None
    if config_path.exists():
        with open(config_path, encoding='utf-8') as f:
            config = yaml.safe_load(f) or {}
            template_path = config.get("release", {}).get("cookie_cutter", {}).get("template_path")
    if template_path:
        resolved = paircoder_dir.parent / template_path
        if resolved.exists():
            return resolved
    default = paircoder_dir.parent / "tools" / "cli" / "bpsai_pair" / "data" / "cookiecutter-paircoder"
    return default if default.exists() else None


def check_version_consistency(project_root: Path) -> tuple[list, list, Optional[str]]:
    """Check version between pyproject.toml and __init__.py. Returns (checks, tasks, version)."""
    checks, tasks = [], []
    pyproject_path = next(
        (p for p in [project_root / "pyproject.toml", project_root / "tools/cli/pyproject.toml"] if p.exists()),
        None,
    )
    pyproject_version = None
    if pyproject_path:
        match = re.search(r'^version\s*=\s*["\']([^"\']+)["\']',
                          pyproject_path.read_text(encoding="utf-8"), re.MULTILINE)
        if match:
            pyproject_version = match.group(1)

    package_version = None
    for init_path in project_root.glob("*/__init__.py"):
        if init_path.parent.name.startswith("."):
            continue
        ver_match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']',
                              init_path.read_text(encoding="utf-8"))
        if ver_match:
            package_version = ver_match.group(1)
            break

    if pyproject_version:
        if package_version and pyproject_version != package_version:
            checks.append(("Version consistency", "❌",
                          f"Mismatch: pyproject.toml={pyproject_version}, __init__.py={package_version}"))
            tasks.append({"id": "REL-VER", "title": "Fix version mismatch",
                         "description": f"pyproject.toml={pyproject_version}, __init__.py={package_version}"})
        else:
            checks.append(("Version consistency", "✅", f"v{pyproject_version}"))
    else:
        checks.append(("Version consistency", "⚠️", "Could not find version in pyproject.toml"))
    return checks, tasks, pyproject_version


def check_changelog_entry(project_root: Path, version: Optional[str]) -> tuple[list, list]:
    """Check if CHANGELOG.md has entry for current version."""
    checks, tasks = [], []
    changelog = project_root / "CHANGELOG.md"
    if changelog.exists() and version:
        content = changelog.read_text(encoding="utf-8")
        patterns = [rf"\[{re.escape(version)}\]", rf"v{re.escape(version)}", rf"## {re.escape(version)}"]
        if any(re.search(p, content) for p in patterns):
            checks.append(("CHANGELOG entry", "✅", f"Found entry for v{version}"))
        else:
            checks.append(("CHANGELOG entry", "❌", f"Missing entry for v{version}"))
            tasks.append({"id": "REL-CHANGELOG", "title": f"Update CHANGELOG for v{version}",
                         "description": "Add release notes for the new version"})
    elif not changelog.exists():
        checks.append(("CHANGELOG entry", "⚠️", "CHANGELOG.md not found"))
    else:
        checks.append(("CHANGELOG entry", "⚠️", "Could not determine version"))
    return checks, tasks


def check_git_status(project_root: Path) -> tuple[list, list]:
    """Check for uncommitted changes."""
    checks, tasks = [], []
    try:
        result = subprocess.run(["git", "status", "--porcelain"], cwd=project_root,
                                capture_output=True, text=True)
        if result.returncode == 0:
            if result.stdout.strip():
                count = len(result.stdout.strip().split("\n"))
                checks.append(("Git status", "❌", f"{count} uncommitted change(s)"))
                tasks.append({"id": "REL-GIT", "title": "Commit or stash changes",
                             "description": f"Found {count} uncommitted file(s)"})
            else:
                checks.append(("Git status", "✅", "Working tree clean"))
        else:
            checks.append(("Git status", "⚠️", "Not a git repository"))
    except FileNotFoundError:
        checks.append(("Git status", "⚠️", "git command not found"))
    return checks, tasks


def check_test_suite(project_root: Path, skip: bool = False) -> tuple[list, list]:
    """Check if test suite collects successfully."""
    checks, tasks = [], []
    if skip:
        checks.append(("Test suite", "⚠️", "Skipped (--skip-tests)"))
        return checks, tasks
    try:
        result = subprocess.run(["python", "-m", "pytest", "--collect-only", "-q"],
                                cwd=project_root, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            test_count = sum(1 for l in result.stdout.strip().split("\n")
                           if "test" in l.lower() and "::" in l)
            status = ("✅", f"{test_count} tests collected") if test_count else ("⚠️", "No tests found")
            checks.append(("Test suite", status[0], status[1]))
        elif "no tests" in (result.stderr + result.stdout).lower():
            checks.append(("Test suite", "⚠️", "No tests found"))
        else:
            checks.append(("Test suite", "❌", "Test collection failed"))
            tasks.append({"id": "REL-TESTS", "title": "Fix failing tests",
                         "description": "Test collection failed"})
    except subprocess.TimeoutExpired:
        checks.append(("Test suite", "⚠️", "Test collection timed out"))
    except FileNotFoundError:
        checks.append(("Test suite", "⚠️", "pytest not found"))
    return checks, tasks


def check_doc_freshness(project_root: Path, docs: list[str], days: int = 7) -> list:
    """Check documentation freshness. Returns list of check results."""
    import os
    from datetime import datetime
    checks = []
    for doc_file in docs:
        doc_path = project_root / doc_file
        if doc_path.exists():
            days_old = (datetime.now() - datetime.fromtimestamp(os.path.getmtime(doc_path))).days
            emoji = "⚠️" if days_old > days else "✅"
            checks.append((f"Doc: {doc_file}", emoji, f"{'Last u' if days_old > days else 'U'}pdated {days_old} days ago"))
        elif doc_file != "CHANGELOG.md":
            checks.append((f"Doc: {doc_file}", "⚠️", "Not found"))
    return checks


def check_template_drift(paircoder_dir: Path, project_root: Path, config: dict) -> tuple[list, list]:
    """Check cookie cutter template drift."""
    checks, tasks = [], []
    if not config.get("cookie_cutter", {}).get("sync_required", True):
        return checks, tasks
    template_path = get_template_path(paircoder_dir)
    if not template_path:
        checks.append(("Template drift", "⚠️", "Template not configured"))
        return checks, tasks
    tpl_dir = template_path / "{{cookiecutter.project_slug}}"
    if not tpl_dir.exists():
        checks.append(("Template drift", "⚠️", "Template directory not found"))
        return checks, tasks
    drift = sum(1 for rp in [".paircoder/config.yaml", "CLAUDE.md", ".paircoder/capabilities.yaml"]
                if (project_root / rp).exists() and (tpl_dir / rp).exists()
                and (project_root / rp).read_text(encoding="utf-8") != (tpl_dir / rp).read_text(encoding="utf-8"))
    if drift:
        checks.append(("Template drift", "⚠️", f"{drift} file(s) need sync"))
        tasks.append({"id": "REL-TEMPLATE", "title": "Sync cookie cutter template",
                     "description": f"{drift} file(s) drifted. Run: bpsai-pair template check --fix"})
    else:
        checks.append(("Template drift", "✅", "All files in sync"))
    return checks, tasks


def run_all_checks(
    paircoder_dir: Path, project_root: Path, config: dict, skip_tests: bool,
) -> tuple[list, list]:
    """Run all release checks. Returns (all_checks, all_tasks_needed)."""
    all_checks, all_tasks = [], []

    ver_checks, ver_tasks, version = check_version_consistency(project_root)
    all_checks.extend(ver_checks)
    all_tasks.extend(ver_tasks)

    for fn, args in [
        (check_changelog_entry, (project_root, version)),
        (check_git_status, (project_root,)),
        (check_test_suite, (project_root, skip_tests)),
    ]:
        checks, tasks = fn(*args)
        all_checks.extend(checks)
        all_tasks.extend(tasks)

    all_checks.extend(check_doc_freshness(
        project_root, config.get("documentation", []), config.get("freshness_days", 7)))

    drift_checks, drift_tasks = check_template_drift(paircoder_dir, project_root, config)
    all_checks.extend(drift_checks)
    all_tasks.extend(drift_tasks)

    return all_checks, all_tasks


def display_check_results(checks: list, tasks_needed: list) -> None:
    """Display check results table and summary."""
    table = Table(title=None, show_header=True, header_style="bold")
    table.add_column("Check", style="cyan")
    table.add_column("Status")
    table.add_column("Details")
    for name, status, details in checks:
        table.add_row(name, status, details)
    console.print(table)

    passed = sum(1 for _, s, _ in checks if s == "✅")
    failed = sum(1 for _, s, _ in checks if s == "❌")
    warned = sum(1 for _, s, _ in checks if s == "⚠️")
    console.print()
    console.print(f"[bold]Summary:[/bold] {passed} passed, {failed} failed, {warned} warnings")

    if tasks_needed:
        console.print(f"\n[bold]Tasks needed ({len(tasks_needed)}):[/bold]")
        for task in tasks_needed:
            console.print(f"  • {task['id']}: {task['title']}")
    else:
        console.print("\n[green]✓ All checks passed - ready for release![/green]")
