"""Release CLI commands for PairCoder.

Provides commands for release management: plan, checklist, and prep.
Check functions extracted to release_checks.py.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..planning.state import StateManager

console = Console()

app = typer.Typer(
    help="Release management commands",
    context_settings={"help_option_names": ["-h", "--help"]}
)


def find_paircoder_dir() -> Path:
    """Find .paircoder directory in current or parent directories."""
    from ..core.ops import find_paircoder_dir as _find
    return _find()


def get_state_manager() -> StateManager:
    """Get a StateManager instance for the current project."""
    return StateManager(find_paircoder_dir())


# Re-exported from release_checks.py for backward compatibility (used by template.py)
from .release_checks import get_template_path  # noqa: F401, E402


# Release task definitions for the "plan" command
RELEASE_TASK_DEFS = [
    {"id": "REL-001", "title": "Sync cookie cutter template with project changes",
     "type": "chore", "priority": "P1", "complexity": 25,
     "description": "Ensure the cookie cutter template reflects all recent changes:\n"
     "- New configuration options\n- New skills and commands\n- Updated documentation\n"
     "- New directory structure\n\nFiles: tools/cli/bpsai_pair/data/cookiecutter-paircoder/"},
    {"id": "REL-002", "title": "Update CHANGELOG.md",
     "type": "docs", "priority": "P1", "complexity": 15,
     "description": "Add release notes: new features, bug fixes, breaking changes, migration guide.\n"
     "Run: bpsai-pair task changelog-preview"},
    {"id": "REL-003", "title": "Bump version number",
     "type": "chore", "priority": "P1", "complexity": 10,
     "description": "Update version in: pyproject.toml, __init__.py (if applicable), README.md"},
    {"id": "REL-004", "title": "Update documentation",
     "type": "docs", "priority": "P2", "complexity": 20,
     "description": "Ensure docs reflect new features:\n"
     "- README.md\n- USER_GUIDE.md\n- FEATURE_MATRIX.md\n- MCP_SETUP.md (if MCP changes)"},
    {"id": "REL-005", "title": "Run full test suite",
     "type": "chore", "priority": "P1", "complexity": 15,
     "description": "Verify all tests pass: pytest -v, check coverage, manual smoke tests"},
]


def _display_release_tasks(tasks: list[dict], sprint_id: Optional[str], version: Optional[str]) -> None:
    """Display release tasks in a table."""
    console.print("\n[bold]Release Preparation Tasks[/bold]")
    if sprint_id:
        console.print(f"Sprint: {sprint_id}")
    if version:
        console.print(f"Target Version: {version}")
    console.print()

    table = Table()
    table.add_column("ID", style="cyan")
    table.add_column("Title")
    table.add_column("Type")
    table.add_column("Priority")
    table.add_column("Points", justify="right")

    for t in tasks:
        table.add_row(t["id"], t["title"], t["type"], t["priority"], str(t["complexity"]))

    console.print(table)
    console.print(f"\nTotal: {len(tasks)} tasks, {sum(t['complexity'] for t in tasks)} points")


def _create_release_tasks(
    paircoder_dir: Path, tasks: list[dict], plan_id: Optional[str], sprint_id: Optional[str],
) -> None:
    """Create release task files."""
    console.print("\n[bold]Creating tasks...[/bold]")
    tasks_dir = paircoder_dir / "tasks"
    tasks_dir.mkdir(exist_ok=True)

    for task_def in tasks:
        task_id = f"TASK-{task_def['id']}"
        task_file = tasks_dir / f"{task_id}.task.md"
        task_file.write_text(
            f"---\nid: {task_id}\ntitle: \"{task_def['title']}\"\n"
            f"plan: {plan_id or 'release'}\nsprint: {sprint_id or 'release'}\n"
            f"type: {task_def['type']}\npriority: {task_def['priority']}\n"
            f"complexity: {task_def['complexity']}\nstatus: pending\ndepends_on: []\n---\n\n"
            f"# {task_id}: {task_def['title']}\n\n## Description\n\n{task_def['description']}\n\n"
            f"## Acceptance Criteria\n\n- [ ] Task completed\n- [ ] Changes verified\n",
            encoding="utf-8",
        )
        console.print(f"  [green]✓[/green] Created {task_id}")

    console.print(f"\n[green]Created {len(tasks)} release tasks[/green]")
    console.print("\n[dim]View tasks: bpsai-pair task list[/dim]")


@app.command("plan")
def release_plan(
    sprint_id: Optional[str] = typer.Option(None, "--sprint", "-s", help="Sprint ID"),
    version: Optional[str] = typer.Option(None, "--version", "-v", help="Target version"),
    create_tasks: bool = typer.Option(False, "--create", "-c", help="Actually create the tasks"),
):
    """Generate release preparation tasks."""
    paircoder_dir = find_paircoder_dir()
    state = get_state_manager().load_state()
    plan_id = state.active_plan_id if state else None
    if not plan_id:
        console.print("[yellow]No active plan. Release tasks will be standalone.[/yellow]")

    _display_release_tasks(RELEASE_TASK_DEFS, sprint_id, version)

    if not create_tasks:
        console.print("\n[dim]Run with --create to create these tasks[/dim]")
        return

    _create_release_tasks(paircoder_dir, RELEASE_TASK_DEFS, plan_id, sprint_id)


@app.command("checklist")
def release_checklist():
    """Show the release preparation checklist."""
    console.print("\n[bold]Release Preparation Checklist[/bold]\n")

    for section, items in [
        ("Pre-Release", [
            "All sprint tasks completed or deferred", "Tests passing (pytest -v)",
            "No critical bugs open", "Code reviewed and approved",
        ]),
        ("Documentation", [
            "CHANGELOG.md updated with release notes", "README.md reflects current features",
            "USER_GUIDE.md up to date", "FEATURE_MATRIX.md accurate",
        ]),
        ("Template Sync", [
            "Cookie cutter template synced", "New skills/commands in template",
            "Config options in template", "Documentation in template",
        ]),
        ("Version & Release", [
            "Version bumped in pyproject.toml", "Git tag created",
            "Package published (pip)", "Release notes on GitHub",
        ]),
    ]:
        console.print(f"[bold cyan]{section}[/bold cyan]")
        for item in items:
            console.print(f"  [ ] {item}")
        console.print()


@app.command("prep")
def release_prep(
    since: Optional[str] = typer.Option(None, "--since", "-s", help="Git tag/commit for baseline"),
    create_tasks: bool = typer.Option(False, "--create-tasks", "-c", help="Generate tasks for missing items"),
    skip_tests: bool = typer.Option(False, "--skip-tests", help="Skip test suite check"),
):
    """Verify release readiness and generate tasks for missing items."""
    from .release_checks import (
        display_check_results, load_release_config, run_all_checks,
    )

    paircoder_dir = find_paircoder_dir()
    project_root = paircoder_dir.parent
    config = load_release_config(paircoder_dir)

    console.print("\n[bold]Release Preparation Check[/bold]")
    if since:
        console.print(f"Comparing since: {since}")
    console.print()

    checks, tasks_needed = run_all_checks(paircoder_dir, project_root, config, skip_tests)
    display_check_results(checks, tasks_needed)

    if tasks_needed and create_tasks:
        _create_check_fix_tasks(paircoder_dir, tasks_needed)
    elif tasks_needed:
        console.print("\n[dim]Run with --create-tasks to generate these tasks[/dim]")


def _create_check_fix_tasks(paircoder_dir: Path, tasks_needed: list[dict]) -> None:
    """Create task files for failed release checks."""
    console.print("\n[bold]Creating tasks...[/bold]")
    tasks_dir = paircoder_dir / "tasks"
    tasks_dir.mkdir(exist_ok=True)

    state = get_state_manager().load_state()
    plan_id = state.active_plan_id if state else "release"

    for task_def in tasks_needed:
        task_id = task_def["id"]
        (tasks_dir / f"{task_id}.task.md").write_text(
            f"---\nid: {task_id}\ntitle: \"{task_def['title']}\"\nplan: {plan_id}\n"
            f"type: chore\npriority: P1\ncomplexity: 10\nstatus: pending\n"
            f"depends_on: []\ntags:\n  - release\n---\n\n"
            f"# {task_def['title']}\n\n## Description\n\n{task_def['description']}\n\n"
            f"## Acceptance Criteria\n\n- [ ] Issue resolved\n- [ ] Changes verified\n",
            encoding="utf-8",
        )
        console.print(f"  [green]✓[/green] Created {task_id}")

    console.print(f"\n[green]Generated {len(tasks_needed)} task(s)[/green]")
