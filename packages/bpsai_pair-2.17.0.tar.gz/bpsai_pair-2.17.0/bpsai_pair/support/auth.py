"""Support portal authentication flow.

Authenticates a local license against the PairCoder API to obtain
a JWT and single-use auth code for the support portal.
"""

from __future__ import annotations

import os
from typing import Optional

import httpx

from ..licensing.core import load_license

DEFAULT_API_URL = os.environ.get("PAIRCODER_API_URL", "https://api.paircoder.ai")
DEFAULT_PORTAL_URL = os.environ.get("PAIRCODER_PORTAL_URL", "https://paircoder.ai")
DEFAULT_TIMEOUT = 10


def get_support_jwt(api_url: str = DEFAULT_API_URL) -> Optional[dict]:
    """Authenticate local license and return a support JWT.

    Returns:
        Dict with token, expires_at, tier on success. None on failure.
    """
    license_data = load_license()
    if license_data is None:
        return None

    license_id = str(license_data.payload.license_id)
    url = f"{api_url.rstrip('/')}/api/v1/support/auth"

    try:
        with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
            resp = client.post(url, json={"license_id": license_id})
            if resp.status_code == 200:
                return resp.json()
            return None
    except httpx.RequestError:
        return None


def get_auth_code(
    jwt_token: str, api_url: str = DEFAULT_API_URL,
) -> Optional[dict]:
    """Exchange a support JWT for a single-use auth code.

    Returns:
        Dict with code, expires_at on success. None on failure.
    """
    url = f"{api_url.rstrip('/')}/api/v1/support/code"
    headers = {"Authorization": f"Bearer {jwt_token}"}

    try:
        with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
            resp = client.post(url, headers=headers)
            if resp.status_code == 200:
                return resp.json()
            return None
    except httpx.RequestError:
        return None


def get_portal_url(
    code: str, base_url: str = DEFAULT_PORTAL_URL,
) -> str:
    """Build the support portal URL with an auth code."""
    return f"{base_url.rstrip('/')}/support?code={code}"
