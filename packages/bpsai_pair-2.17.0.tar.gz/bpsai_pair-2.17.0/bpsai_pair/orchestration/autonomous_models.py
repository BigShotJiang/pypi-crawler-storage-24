"""
Data models for autonomous workflow orchestration.

Contains enums and dataclasses used by the autonomous workflow system:
- WorkflowPhase: Phases in the autonomous workflow
- WorkflowEvent: Events in the autonomous workflow
- WorkflowState: Current state of the autonomous workflow
- WorkflowConfig: Configuration for autonomous workflow
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional, List, Dict, Any, Callable

logger = logging.getLogger(__name__)


def call_hook(hooks: Dict[str, Callable], name: str, *args, **kwargs):
    """Call a hook if registered."""
    if name in hooks:
        try:
            return hooks[name](*args, **kwargs)
        except Exception as e:
            logger.error(f"Hook {name} failed: {e}")


class WorkflowPhase(Enum):
    """Phases in the autonomous workflow."""

    IDLE = "idle"
    SELECTING_TASK = "selecting_task"
    PLANNING = "planning"
    IMPLEMENTING = "implementing"
    TESTING = "testing"
    REVIEWING = "reviewing"
    CREATING_PR = "creating_pr"
    COMPLETING = "completing"
    ERROR = "error"


class WorkflowEvent(Enum):
    """Events in the autonomous workflow."""

    TASK_SELECTED = "task_selected"
    PLANNING_STARTED = "planning_started"
    PLANNING_COMPLETED = "planning_completed"
    IMPLEMENTATION_STARTED = "implementation_started"
    IMPLEMENTATION_COMPLETED = "implementation_completed"
    TESTS_PASSED = "tests_passed"
    TESTS_FAILED = "tests_failed"
    REVIEW_STARTED = "review_started"
    REVIEW_COMPLETED = "review_completed"
    PR_CREATED = "pr_created"
    PR_MERGED = "pr_merged"
    TASK_COMPLETED = "task_completed"
    ERROR_OCCURRED = "error_occurred"


@dataclass
class WorkflowState:
    """Current state of the autonomous workflow."""

    phase: WorkflowPhase = WorkflowPhase.IDLE
    current_task_id: Optional[str] = None
    current_plan_id: Optional[str] = None
    current_flow: Optional[str] = None
    pr_number: Optional[int] = None
    started_at: Optional[datetime] = None
    events: List[Dict[str, Any]] = field(default_factory=list)
    error: Optional[str] = None

    def record_event(self, event: WorkflowEvent, data: Optional[Dict] = None):
        """Record a workflow event."""
        self.events.append({
            "event": event.value,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data": data or {},
        })

    def to_dict(self) -> Dict[str, Any]:
        """Convert state to dictionary."""
        return {
            "phase": self.phase.value,
            "current_task_id": self.current_task_id,
            "current_plan_id": self.current_plan_id,
            "current_flow": self.current_flow,
            "pr_number": self.pr_number,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "events_count": len(self.events),
            "error": self.error,
        }


@dataclass
class WorkflowConfig:
    """Configuration for autonomous workflow."""

    auto_select_tasks: bool = True
    auto_create_pr: bool = True
    auto_update_trello: bool = True
    run_tests_before_pr: bool = True
    require_review: bool = True
    max_tasks_per_session: int = 5
    task_timeout_minutes: int = 30

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkflowConfig":
        """Create config from dictionary."""
        return cls(**{k: v for k, v in data.items() if k in cls.__annotations__})
