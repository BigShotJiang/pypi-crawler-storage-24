"""
Cross-repo impact deduplication.

Consolidates overlapping contract changes and actions when multiple tasks
or files affect the same repo+contract_type combination.
"""

from __future__ import annotations

from bpsai_pair.workspace.contracts import ContractChange
from bpsai_pair.workspace.impact import ImpactReport


def dedup_impacts(changes: list[ContractChange]) -> list[ContractChange]:
    """Consolidate changes that share the same repo and change_type.

    Multiple files in the same repo with the same contract type are merged
    into a single ContractChange with combined file paths and consumers.
    """
    if not changes:
        return []

    groups: dict[tuple[str, str], list[ContractChange]] = {}
    for change in changes:
        key = (change.repo, change.change_type)
        groups.setdefault(key, []).append(change)

    result: list[ContractChange] = []
    for (repo, change_type), group in groups.items():
        if len(group) == 1:
            result.append(group[0])
            continue

        files = [c.file for c in group]
        consumers: set[str] = set()
        for c in group:
            consumers.update(c.affected_consumers)

        merged = ContractChange(
            repo=repo,
            file=", ".join(files),
            change_type=change_type,
            description=f"{change_type.replace('_', ' ').title()}: {', '.join(files)}",
            affected_consumers=sorted(consumers),
        )
        result.append(merged)

    return result


def dedup_actions(actions: list[str]) -> list[str]:
    """Remove duplicate action strings while preserving order."""
    seen: set[str] = set()
    result: list[str] = []
    for action in actions:
        if action not in seen:
            seen.add(action)
            result.append(action)
    return result


def dedup_report(report: ImpactReport) -> ImpactReport:
    """Deduplicate both changes and actions in an ImpactReport."""
    return ImpactReport(
        changes=dedup_impacts(report.changes),
        affected_repos=report.affected_repos,
        recommended_actions=dedup_actions(report.recommended_actions),
        severity=report.severity,
    )
