"""
Worktree reconciliation protocol.

Detects stale task files after worktree merges and reconciles state.
"""

from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def detect_stale_tasks(
    project_root: Path,
    active_worktrees: list[Path] | None = None,
) -> list[str]:
    """Detect task files still marked in_progress after a worktree merge.

    Args:
        project_root: Path to the project root.
        active_worktrees: Optional list of active worktree paths. If provided,
            a task is only stale if its ID does not appear in any worktree
            directory name. If None, all in_progress tasks are stale
            (backward-compatible behavior for post-merge reconciliation).

    Returns list of task IDs that are stale (in_progress but likely done).
    """
    tasks_dir = project_root / ".paircoder" / "tasks"
    if not tasks_dir.exists():
        return []

    worktree_names: set[str] | None = None
    if active_worktrees is not None:
        worktree_names = {wt.name for wt in active_worktrees}

    stale: list[str] = []
    for path in tasks_dir.glob("*.task.md"):
        content = path.read_text(encoding="utf-8")
        status = _extract_frontmatter_field(content, "status")
        if status == "in_progress":
            task_id = _extract_frontmatter_field(content, "id")
            if task_id:
                if worktree_names is not None and task_id in worktree_names:
                    continue
                stale.append(task_id)

    return stale


def reconcile_after_merge(
    project_root: Path,
    completed_task_ids: list[str],
) -> dict[str, Any]:
    """Reconcile task files after a worktree merge.

    Marks completed tasks as done in their task files.
    Returns dict with reconciliation stats.
    """
    tasks_dir = project_root / ".paircoder" / "tasks"
    reconciled = 0

    for task_id in completed_task_ids:
        task_file = tasks_dir / f"{task_id}.task.md"
        if not task_file.exists():
            continue

        content = task_file.read_text(encoding="utf-8")
        updated = _update_status(content, "done")
        if updated != content:
            task_file.write_text(updated, encoding="utf-8")
            reconciled += 1
            logger.info("Reconciled task %s → done", task_id)

    return {"reconciled": reconciled}


def check_worktree_clean(worktree_path: Path) -> bool:
    """Check if a worktree has no uncommitted changes.

    Returns True if the worktree is clean.
    """
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=str(worktree_path),
            capture_output=True,
            text=True,
            timeout=10,
        )
    except subprocess.TimeoutExpired:
        logger.warning("git status timed out for %s", worktree_path)
        return False
    return result.stdout.strip() == ""


def _extract_frontmatter_field(content: str, field: str) -> str | None:
    """Extract a field value from YAML frontmatter."""
    match = re.search(rf"^{field}:\s*(.+)$", content, re.MULTILINE)
    return match.group(1).strip() if match else None


def _update_status(content: str, new_status: str) -> str:
    """Update status field in YAML frontmatter."""
    return re.sub(
        r"^(status:\s*).+$",
        rf"\g<1>{new_status}",
        content,
        count=1,
        flags=re.MULTILINE,
    )
