"""
Review utility functions.

Contains helper functions for the reviewer workflow:
- extract_changed_files: Parse changed files from git diff
- extract_line_changes: Parse added/deleted line numbers from git diff
- should_trigger_reviewer: Determine if reviewer should run
- invoke_reviewer: Convenience function to run a review
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from .invoker import InvocationResult
from .review_models import ReviewOutput, ReviewVerdict

# Default location for agent definitions
DEFAULT_AGENTS_DIR = ".claude/agents"


def extract_changed_files(diff: str) -> list[str]:
    """
    Extract list of changed files from a git diff.

    Args:
        diff: Git diff output

    Returns:
        List of file paths that were changed
    """
    files = []
    pattern = r"diff --git a/(.+?) b/\1"

    for match in re.finditer(pattern, diff):
        files.append(match.group(1))

    return files


def extract_line_changes(diff: str) -> tuple[list[int], list[int]]:
    """
    Extract line numbers of additions and deletions from a diff.

    Args:
        diff: Git diff output

    Returns:
        Tuple of (added_lines, deleted_lines)
    """
    additions = []
    deletions = []

    # Find hunk headers: @@ -start,count +start,count @@
    hunk_pattern = r"@@ -(\d+),?\d* \+(\d+),?\d* @@"

    current_line = 0
    in_hunk = False

    for line in diff.split("\n"):
        hunk_match = re.match(hunk_pattern, line)
        if hunk_match:
            current_line = int(hunk_match.group(2))
            in_hunk = True
            continue

        if in_hunk:
            if line.startswith("+") and not line.startswith("+++"):
                additions.append(current_line)
                current_line += 1
            elif line.startswith("-") and not line.startswith("---"):
                deletions.append(current_line)
                # Don't increment for deletions (they don't exist in new file)
            else:
                current_line += 1

    return additions, deletions


def should_trigger_reviewer(
    task_type: Optional[str] = None,
    task_title: Optional[str] = None,
    pre_pr: bool = False,
    explicit_request: bool = False,
) -> bool:
    """
    Determine if the reviewer agent should be triggered.

    Trigger conditions:
    - Task type is REVIEW
    - Task title contains "review"
    - Pre-PR creation
    - User explicitly requests review

    Args:
        task_type: Type of the task (REVIEW, IMPLEMENT, etc.)
        task_title: Title of the task
        pre_pr: Whether this is a pre-PR review
        explicit_request: Whether user explicitly requested review

    Returns:
        True if reviewer should be triggered
    """
    if explicit_request:
        return True

    if pre_pr:
        return True

    if task_type and task_type.upper() == "REVIEW":
        return True

    if task_title:
        title_lower = task_title.lower()
        trigger_words = ["review", "code review", "pr review", "check code"]
        if any(word in title_lower for word in trigger_words):
            return True

    return False


def invoke_reviewer(
    prompt: Optional[str] = None,
    diff: Optional[str] = None,
    changed_files: Optional[list[str]] = None,
    working_dir: Optional[Path] = None,
    agents_dir: Optional[Path] = None,
    timeout: int = 300,
) -> InvocationResult | ReviewOutput:
    """
    Convenience function for invoking the reviewer.

    Can be called with either a prompt or diff context:
    - With prompt: Returns raw InvocationResult
    - With diff: Returns structured ReviewOutput

    Args:
        prompt: The review prompt
        diff: Git diff to review (uses review() method)
        changed_files: List of changed files
        working_dir: Working directory for the command
        agents_dir: Directory containing agent definitions
        timeout: Timeout in seconds

    Returns:
        InvocationResult (for prompt) or ReviewOutput (for diff)

    Example:
        >>> # With prompt
        >>> result = invoke_reviewer("Review the auth module")
        >>> print(result.output)

        >>> # With diff
        >>> output = invoke_reviewer(diff="...", changed_files=["auth.py"])
        >>> for item in output.items:
        ...     print(item.message)
    """
    # Import inside function to avoid circular import
    # (ReviewerAgent imports from review_models, review_checks imports ReviewerAgent)
    from .reviewer import ReviewerAgent

    reviewer = ReviewerAgent(
        agents_dir=agents_dir or Path(DEFAULT_AGENTS_DIR),
        working_dir=working_dir,
        timeout_seconds=timeout,
    )

    if diff is not None:
        return reviewer.review(
            diff=diff,
            changed_files=changed_files,
        )

    if prompt:
        return reviewer.invoke(prompt)

    raise ValueError("Either prompt or diff must be provided")
