"""Materialize parsed backlog into plan YAML and task markdown files."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .backlog_parser import ParsedBacklog, ParsedTask


def materialize(
    project_root: Path, backlog: ParsedBacklog, sprint: str
) -> Path:
    """Write plan YAML and task .md files from a parsed backlog."""
    plans_dir = project_root / ".paircoder" / "plans"
    tasks_dir = project_root / ".paircoder" / "tasks"
    plans_dir.mkdir(parents=True, exist_ok=True)
    tasks_dir.mkdir(parents=True, exist_ok=True)

    plan_id = f"plan-sprint-{sprint}-engage"
    plan_data = {
        "id": plan_id,
        "title": f"Sprint {sprint}",
        "type": "feature",
        "status": "planned",
        "phases": _build_phases(backlog),
    }

    plan_path = plans_dir / f"{plan_id}.plan.yaml"
    with open(plan_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(plan_data, f, default_flow_style=False)

    for task in backlog.tasks:
        _write_task_file(tasks_dir, task, plan_id, sprint)

    return plan_path


def _build_phases(backlog: ParsedBacklog) -> list[dict[str, Any]]:
    """Group tasks into phase structures."""
    phases: dict[int, list[str]] = {}
    for task in backlog.tasks:
        phases.setdefault(task.phase, []).append(f"CLI-T{task.id[1:]}")
    return [
        {"id": pid, "tasks": tids}
        for pid, tids in sorted(phases.items())
    ]


def _write_task_file(
    tasks_dir: Path, task: ParsedTask, plan_id: str, sprint: str
) -> None:
    """Write a single task .md file with frontmatter and AC."""
    task_id = f"CLI-T{task.id[1:]}"
    lines = [
        "---",
        f"id: {task_id}",
        f"title: {task.title}",
        f"plan: {plan_id}",
        "type: feature",
        f"priority: {task.priority}",
        f"complexity: {task.complexity}",
        "status: pending",
        f'sprint: "{sprint}"',
        f"depends_on: [{', '.join(f'CLI-T{dep[1:]}' for dep in task.depends_on)}]",
        "---",
        "",
        f"# {task.title}",
        "",
    ]
    if task.description:
        lines.append(task.description)
        lines.append("")
    lines.append("# Acceptance Criteria")
    lines.append("")
    for ac in task.ac_items:
        lines.append(f"- [ ] {ac}")
    lines.append("")
    (tasks_dir / f"{task_id}.task.md").write_text("\n".join(lines))
