"""
Reviewer Agent Implementation.

Provides the ReviewerAgent class for code review tasks.
The reviewer operates in read-only mode (permissionMode: plan) and
returns structured review feedback.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .invoker import AgentDefinition, AgentInvoker, InvocationResult
from .review_models import (
    ReviewSeverity,
    ReviewVerdict,
    ReviewItem,
    ReviewOutput,
    _parse_review_items,
)
from .review_checks import (
    extract_changed_files,
    extract_line_changes,
    should_trigger_reviewer,
    invoke_reviewer,
)

logger = logging.getLogger(__name__)

# Default location for agent definitions
DEFAULT_AGENTS_DIR = ".claude/agents"


_REVIEW_PROMPT_TEMPLATE = """Please review the following code changes.

Your review should include:
1. A brief summary of the changes
2. Any blocking issues that must be fixed (🔴 Must Fix)
3. Suggestions that should be addressed (🟡 Should Fix)
4. Optional improvements to consider (🟢 Consider)
5. Positive notes about the code (👍 Positive Notes)
6. An overall verdict (Approve / Approve with comments / Request changes)

Format your response with these sections:
- ## Review Summary
- ## 🔴 Must Fix (Blocking)
- ## 🟡 Should Fix (Non-blocking)
- ## 🟢 Consider (Optional)
- ## 👍 Positive Notes
- ## Verdict (with **Status**: value)

For each issue, use the format:
**[file.py:line_number]** Issue description

---

{context}"""


@dataclass
class ReviewerAgent:
    """
    Reviewer agent for code review tasks.

    Uses the AgentInvoker framework to invoke the reviewer agent
    defined in .claude/agents/reviewer.md. Always operates in
    read-only 'plan' permission mode.

    Example:
        >>> reviewer = ReviewerAgent()
        >>> result = reviewer.invoke("Review the authentication changes")
        >>> print(result.output)

        >>> # Or get structured review output
        >>> output = reviewer.review(diff="...", changed_files=["auth.py"])
        >>> for item in output.items:
        ...     print(f"{item.severity}: {item.message}")
    """

    agents_dir: Path = field(default_factory=lambda: Path(DEFAULT_AGENTS_DIR))
    working_dir: Optional[Path] = None
    timeout_seconds: int = 300
    agent_name: str = "reviewer"
    permission_mode: str = "plan"  # Always read-only

    _invoker: Optional[AgentInvoker] = field(default=None, repr=False)
    _agent_definition: Optional[AgentDefinition] = field(default=None, repr=False)

    def __post_init__(self):
        """Initialize the agent invoker."""
        if not self.agents_dir.is_absolute():
            base = self.working_dir or Path.cwd()
            self.agents_dir = base / self.agents_dir

    def _get_invoker(self) -> AgentInvoker:
        """Get or create the AgentInvoker instance."""
        if self._invoker is None:
            self._invoker = AgentInvoker(
                agents_dir=self.agents_dir,
                working_dir=self.working_dir,
                timeout_seconds=self.timeout_seconds,
            )
        return self._invoker

    def load_agent_definition(self) -> AgentDefinition:
        """
        Load the reviewer agent definition.

        Returns:
            AgentDefinition for the reviewer agent
        """
        if self._agent_definition is None:
            self._agent_definition = self._get_invoker().load_agent(self.agent_name)
        return self._agent_definition

    def build_context(
        self,
        diff: str = "",
        changed_files: Optional[list[str]] = None,
        include_file_contents: bool = False,
        test_results: Optional[str] = None,
    ) -> str:
        """Build context string combining diff, files, and test results."""
        context_parts = []

        # Inject prior agent context (SubagentStart injection)
        prior_ctx = self._get_prior_context()
        if prior_ctx:
            context_parts.append(prior_ctx)

        if diff:
            context_parts.append(f"## Git Diff\n\n```diff\n{diff}\n```")
        if changed_files:
            files_list = "\n".join(f"- {f}" for f in changed_files)
            context_parts.append(f"## Changed Files\n\n{files_list}")
            if include_file_contents and self.working_dir:
                self._append_file_contents(context_parts, changed_files)
        if test_results:
            context_parts.append(f"## Test Results\n\n```\n{test_results}\n```")
        return "\n\n---\n\n".join(context_parts) if context_parts else "No context provided"

    def _get_prior_context(self) -> str:
        """Get context from prior agent sessions (best-effort)."""
        try:
            from .subagent_context import build_agent_context

            root = self.working_dir or Path.cwd()
            return build_agent_context("reviewer", root)
        except Exception:
            return ""

    def _append_file_contents(self, parts: list[str], files: list[str]):
        """Append full file contents to context parts."""
        for file_path in files:
            full_path = self.working_dir / file_path
            resolved = full_path.resolve()
            if not resolved.is_relative_to(self.working_dir.resolve()):
                continue  # skip files outside working directory
            if full_path.exists():
                try:
                    content = full_path.read_text(encoding="utf-8")
                    parts.append(f"## File: {file_path}\n\n```\n{content}\n```")
                except Exception as e:
                    logger.warning(f"Could not read {file_path}: {e}")

    def invoke(self, prompt: str, **kwargs) -> InvocationResult:
        """
        Invoke the reviewer agent with a prompt.

        Args:
            prompt: The review prompt/task description
            **kwargs: Additional arguments for the invoker

        Returns:
            InvocationResult with output and metadata
        """
        invoker = self._get_invoker()
        return invoker.invoke(self.agent_name, prompt, **kwargs)

    def review(
        self,
        diff: str = "",
        changed_files: Optional[list[str]] = None,
        include_file_contents: bool = False,
        test_results: Optional[str] = None,
    ) -> ReviewOutput:
        """Perform a structured code review and return parsed output."""
        context = self.build_context(
            diff=diff, changed_files=changed_files,
            include_file_contents=include_file_contents, test_results=test_results,
        )
        review_prompt = _REVIEW_PROMPT_TEMPLATE.format(context=context)
        result = self.invoke(review_prompt)

        if not result.success:
            logger.error(f"Review invocation failed: {result.error}")
            return ReviewOutput(
                verdict=ReviewVerdict.REQUEST_CHANGES,
                summary=f"Review failed: {result.error}",
                items=[], raw_output="",
            )
        return ReviewOutput.from_raw_text(result.output)
