"""SubagentStart context injection.

Builds a context snippet from prior agent sessions so newly spawned
agents are immediately aware of what happened before them.
A reviewer sees what the driver changed; a driver sees what the
reviewer flagged.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Which prior agent roles are relevant for each spawning role
_RELEVANT_ROLES: dict[str, list[str]] = {
    "reviewer": ["driver"],
    "driver": ["reviewer"],
    "qa": ["driver", "reviewer"],
    "qc": ["driver", "reviewer"],
    "security": ["driver"],
}


def build_agent_context(agent_role: str, project_root: Path) -> str:
    """Build a context snippet for a spawning agent.

    Reads the most recent session outcome from SQLite and any
    incomplete tasks from TaskStateIndex. Returns empty string
    when no relevant context exists (no noise).
    """
    try:
        parts: list[str] = []

        session_ctx = _build_session_context(agent_role, project_root)
        if session_ctx:
            parts.append(session_ctx)

        incomplete_ctx = _build_incomplete_tasks_context(project_root)
        if incomplete_ctx:
            parts.append(incomplete_ctx)

        if not parts:
            return ""

        return "## Prior Agent Context\n\n" + "\n\n".join(parts)

    except Exception as e:
        logger.debug("Context injection skipped: %s", e)
        return ""


def _build_session_context(agent_role: str, project_root: Path) -> str:
    """Build context from the most recent relevant session."""
    try:
        from bpsai_pair.telemetry.session_store import SessionStore

        db_path = project_root / ".paircoder" / "data" / "store.db"
        if not db_path.exists():
            return ""

        store = SessionStore(db_path)
        sessions = store.query_recent(limit=5)
        if not sessions:
            return ""

        relevant_roles = _RELEVANT_ROLES.get(agent_role, [])
        # Find the most recent session from a relevant role,
        # falling back to most recent session regardless of role.
        session = sessions[0]
        for s in sessions:
            if relevant_roles and s.agent_role in relevant_roles:
                session = s
                break

        return _format_session(session)

    except Exception as e:
        logger.debug("Session context failed: %s", e)
        return ""


def _format_session(session: Any) -> str:
    """Format a session outcome as a concise context snippet."""
    ended = session.ended_at[:10] if session.ended_at else "unknown"
    lines = [f"**Last {session.agent_role} session** ({ended}):"]

    if session.tasks_touched:
        tasks = ", ".join(session.tasks_touched[:5])
        lines.append(f"- Tasks: {tasks}")

    if session.tests_run > 0:
        lines.append(
            f"- Tests: {session.tests_passed}/{session.tests_run} passed"
        )

    if session.errors:
        lines.append("- Issues found:")
        for err in session.errors[:3]:
            lines.append(f"  - {err}")

    if session.outcome != "success":
        lines.append(f"- Outcome: {session.outcome}")

    return "\n".join(lines)


def _build_incomplete_tasks_context(project_root: Path) -> str:
    """List tasks started but not completed."""
    try:
        from bpsai_pair.telemetry.task_state_index import TaskStateIndex

        db_path = project_root / ".paircoder" / "data" / "store.db"
        if not db_path.exists():
            return ""

        idx = TaskStateIndex(db_path)
        incomplete = idx.query_incomplete_tasks()
        if not incomplete:
            return ""

        task_ids = ", ".join(t["task_id"] for t in incomplete[:5])
        return f"**Incomplete tasks:** {task_ids}"

    except Exception as e:
        logger.debug("Incomplete tasks context failed: %s", e)
        return ""
