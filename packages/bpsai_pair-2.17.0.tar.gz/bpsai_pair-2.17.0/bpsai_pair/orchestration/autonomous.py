"""
Autonomous workflow orchestration for PairCoder.

Ties together task selection, intent detection, flow execution,
and integration with GitHub and Trello for full autonomy.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List, Dict, Any, Callable

from .autonomous_models import WorkflowPhase, WorkflowEvent, WorkflowState, WorkflowConfig, call_hook
from .autonomous_steps import WorkflowRunner, WorkflowSequencer, report_test_failure

logger = logging.getLogger(__name__)


class AutonomousWorkflow:
    """
    Autonomous workflow orchestrator for PairCoder.

    Manages the full task lifecycle from selection to completion,
    integrating with all PairCoder systems.
    """

    def __init__(
        self,
        paircoder_dir: Path,
        config: Optional[WorkflowConfig] = None,
        hooks: Optional[Dict[str, Callable]] = None,
    ):
        self.paircoder_dir = paircoder_dir
        self.project_root = paircoder_dir.parent
        self.config = config or WorkflowConfig()
        self.hooks = hooks or {}
        self.state = WorkflowState()
        self._task_parser = None
        self._github_pr_manager = None
        self._intent_detector = None

    @property
    def task_parser(self):
        """Lazy-load task parser."""
        if self._task_parser is None:
            from ..planning.parser import TaskParser
            self._task_parser = TaskParser(self.paircoder_dir / "tasks")
        return self._task_parser

    @property
    def github_pr_manager(self):
        """Lazy-load GitHub PR manager."""
        if self._github_pr_manager is None:
            try:
                from ..github.pr import PRManager
                self._github_pr_manager = PRManager(
                    project_root=self.project_root,
                    paircoder_dir=self.paircoder_dir,
                )
            except ImportError:
                logger.warning("GitHub module not available")
        return self._github_pr_manager

    @property
    def intent_detector(self):
        """Lazy-load intent detector."""
        if self._intent_detector is None:
            from ..planning.intent_detection import IntentDetector
            self._intent_detector = IntentDetector()
        return self._intent_detector

    # =========================================================================
    # Task Selection Phase
    # =========================================================================

    def select_next_task(self, plan_id: Optional[str] = None) -> Optional[str]:
        """Select the next task to work on.

        Args:
            plan_id: Optional plan ID to filter tasks

        Returns:
            Task ID if selected, None otherwise
        """
        from ..planning.auto_assign import get_next_pending_task

        self.state.phase = WorkflowPhase.SELECTING_TASK

        task = get_next_pending_task(self.paircoder_dir, plan_id)

        if task:
            self.state.current_task_id = task.id
            self.state.current_plan_id = task.plan_id
            self.state.started_at = datetime.now(timezone.utc)
            self.state.record_event(WorkflowEvent.TASK_SELECTED, {
                "task_id": task.id,
                "title": task.title,
                "priority": task.priority,
            })
            call_hook(self.hooks, "on_task_selected", task)
            logger.info(f"Selected task: {task.id} - {task.title}")
            return task.id

        logger.info("No pending tasks available")
        self.state.phase = WorkflowPhase.IDLE
        return None

    # =========================================================================
    # Planning Phase
    # =========================================================================

    def start_planning(self) -> Optional[str]:
        """Start planning phase for current task.

        Returns:
            Suggested flow name
        """
        if not self.state.current_task_id:
            logger.warning("No task selected for planning")
            return None

        self.state.phase = WorkflowPhase.PLANNING
        self.state.record_event(WorkflowEvent.PLANNING_STARTED)

        # Get task content
        task = self.task_parser.get_task_by_id(self.state.current_task_id)
        if not task:
            logger.error(f"Task not found: {self.state.current_task_id}")
            return None

        # Detect intent and suggest flow
        flow = self.intent_detector.get_flow_suggestion(task.title)
        self.state.current_flow = flow or "tdd-implement"

        call_hook(self.hooks, "on_planning_started", task, self.state.current_flow)
        logger.info(f"Started planning with flow: {self.state.current_flow}")

        return self.state.current_flow

    def complete_planning(self):
        """Complete the planning phase."""
        self.state.record_event(WorkflowEvent.PLANNING_COMPLETED)
        call_hook(self.hooks, "on_planning_completed", self.state.current_task_id)
        logger.info("Planning completed")

    # =========================================================================
    # Implementation Phase
    # =========================================================================

    def start_implementation(self) -> bool:
        """Start implementation phase.

        Returns:
            True if started successfully
        """
        if not self.state.current_task_id:
            logger.warning("No task selected for implementation")
            return False

        self.state.phase = WorkflowPhase.IMPLEMENTING
        self.state.record_event(WorkflowEvent.IMPLEMENTATION_STARTED)

        # Update task status to in_progress
        from ..planning.models import TaskStatus
        task = self.task_parser.get_task_by_id(self.state.current_task_id)
        if task:
            task.status = TaskStatus.IN_PROGRESS
            self.task_parser.save(task)

        call_hook(self.hooks, "on_implementation_started", self.state.current_task_id)
        logger.info(f"Started implementing: {self.state.current_task_id}")
        return True

    def complete_implementation(self, success: bool = True):
        """Complete implementation phase.

        Args:
            success: Whether implementation was successful
        """
        if success:
            self.state.record_event(WorkflowEvent.IMPLEMENTATION_COMPLETED)
            call_hook(self.hooks, "on_implementation_completed", self.state.current_task_id)
            logger.info("Implementation completed")
        else:
            self.state.phase = WorkflowPhase.ERROR
            self.state.error = "Implementation failed"
            self.state.record_event(WorkflowEvent.ERROR_OCCURRED, {"reason": "implementation_failed"})

    # =========================================================================
    # Testing Phase
    # =========================================================================

    def run_tests(self) -> bool:
        """Run tests for current implementation.

        Returns:
            True if tests pass
        """
        self.state.phase = WorkflowPhase.TESTING
        logger.info("Running tests...")

        # This is a placeholder - actual test running would be done by the agent
        call_hook(self.hooks, "on_tests_started", self.state.current_task_id)

        # Assume tests pass for now
        self.state.record_event(WorkflowEvent.TESTS_PASSED)
        call_hook(self.hooks, "on_tests_completed", True)
        return True

    # report_test_failure delegated via __getattr__ to autonomous_steps.report_test_failure

    # =========================================================================
    # Review Phase
    # =========================================================================

    def start_review(self) -> bool:
        """Start review phase.

        Returns:
            True if review started
        """
        if not self.config.require_review:
            logger.info("Review not required, skipping")
            return True

        self.state.phase = WorkflowPhase.REVIEWING
        self.state.record_event(WorkflowEvent.REVIEW_STARTED)
        call_hook(self.hooks, "on_review_started", self.state.current_task_id)
        logger.info("Review phase started")
        return True

    def complete_review(self, approved: bool = True):
        """Complete review phase.

        Args:
            approved: Whether review was approved
        """
        self.state.record_event(WorkflowEvent.REVIEW_COMPLETED, {"approved": approved})
        call_hook(self.hooks, "on_review_completed", approved)

        if not approved:
            self.state.phase = WorkflowPhase.IMPLEMENTING
            logger.info("Review not approved, returning to implementation")
        else:
            logger.info("Review approved")

    # =========================================================================
    # PR Creation Phase
    # =========================================================================

    def create_pr(self, summary: Optional[str] = None) -> Optional[int]:
        """Create a pull request for the completed work.

        Args:
            summary: Optional summary of changes

        Returns:
            PR number if created
        """
        if not self.config.auto_create_pr:
            logger.info("Auto PR creation disabled")
            return None

        if not self.github_pr_manager:
            logger.warning("GitHub PR manager not available")
            return None

        self.state.phase = WorkflowPhase.CREATING_PR

        task = self.task_parser.get_task_by_id(self.state.current_task_id)
        if not task:
            return None

        pr = self.github_pr_manager.create_pr_for_task(
            task_id=self.state.current_task_id,
            summary=summary or f"Implementation of {task.title}",
        )

        if pr:
            self.state.pr_number = pr.number
            self.state.record_event(WorkflowEvent.PR_CREATED, {
                "pr_number": pr.number,
                "url": pr.url,
            })
            call_hook(self.hooks, "on_pr_created", pr)
            logger.info(f"Created PR #{pr.number}")
            return pr.number

        return None

    # =========================================================================
    # Completion Phase
    # =========================================================================

    def complete_task(self) -> bool:
        """Complete the current task.

        Returns:
            True if completed successfully
        """
        if not self.state.current_task_id:
            return False

        self.state.phase = WorkflowPhase.COMPLETING

        # Update task status to done
        from ..planning.models import TaskStatus
        task = self.task_parser.get_task_by_id(self.state.current_task_id)
        if task:
            task.status = TaskStatus.DONE
            self.task_parser.save(task)

        self.state.record_event(WorkflowEvent.TASK_COMPLETED, {
            "task_id": self.state.current_task_id,
            "duration_seconds": (datetime.now(timezone.utc) - self.state.started_at).total_seconds()
            if self.state.started_at else 0,
        })

        call_hook(self.hooks, "on_task_completed", self.state.current_task_id)
        logger.info(f"Completed task: {self.state.current_task_id}")

        # Reset state for next task
        completed_task_id = self.state.current_task_id
        self.state.current_task_id = None
        self.state.current_plan_id = None
        self.state.current_flow = None
        self.state.pr_number = None
        self.state.phase = WorkflowPhase.IDLE

        return True

    # Full workflow methods delegated to WorkflowRunner
    def __getattr__(self, name: str):
        if name in ("run_task_workflow", "run_session", "get_status"):
            return getattr(WorkflowRunner(self), name)
        if name == "report_test_failure":
            from functools import partial
            return partial(report_test_failure, self)
        if name == "_call_hook":
            from functools import partial
            return partial(call_hook, self.hooks)
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
