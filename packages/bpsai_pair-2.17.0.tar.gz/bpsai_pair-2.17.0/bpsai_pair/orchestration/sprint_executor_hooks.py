"""Hooks for sprint executor — review dispatch and security detection.

These hooks are called after phase completion to trigger reviews
and flag security-relevant changes. Actual agent dispatch will be
wired in T39.8 (post-sprint review hook).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

SECURITY_PATTERNS = ["/security/", "/auth/", "auth_", "_auth.", "credential", "secret_", "_secret", "/secrets/"]


def dispatch_review(
    project_root: Path, changed_files: list[str],
) -> dict[str, Any]:
    """Dispatch review after a phase completes. Returns dispatch metadata.

    Actual review agent dispatch will be wired in T39.8.
    For now, logs the dispatch and returns metadata.
    """
    if not changed_files:
        return {"dispatched": False, "file_count": 0}

    logger.info(
        "Review dispatch: %d files from %s", len(changed_files), project_root,
    )
    return {
        "dispatched": True,
        "file_count": len(changed_files),
        "security_relevant": detect_security_relevant(changed_files),
    }


def detect_security_relevant(changed_files: list[str]) -> bool:
    """Check if any changed files are security-relevant."""
    for filepath in changed_files:
        lower = filepath.lower()
        if any(pattern in lower for pattern in SECURITY_PATTERNS):
            return True
    return False
