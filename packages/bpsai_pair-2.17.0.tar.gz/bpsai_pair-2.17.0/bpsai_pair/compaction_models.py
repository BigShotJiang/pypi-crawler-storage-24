"""Data models for compaction snapshots and markers.

Extracted from compaction.py for architecture compliance.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class CompactionSnapshot:
    """A snapshot of context taken before compaction."""

    timestamp: datetime
    trigger: str  # "auto" or "manual"
    active_plan: Optional[str] = None
    current_task_id: Optional[str] = None
    current_task_title: Optional[str] = None
    progress: Optional[str] = None
    last_done: Optional[str] = None
    whats_next: Optional[str] = None
    recent_files: Optional[List[str]] = None
    containment: Optional[Dict[str, Any]] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        result = {
            "timestamp": self.timestamp.isoformat(),
            "trigger": self.trigger,
            "active_plan": self.active_plan,
            "current_task_id": self.current_task_id,
            "current_task_title": self.current_task_title,
            "progress": self.progress,
            "last_done": self.last_done,
            "whats_next": self.whats_next,
            "recent_files": self.recent_files,
        }
        if self.containment is not None:
            result["containment"] = self.containment
        return result

    @classmethod
    def from_dict(cls, data: dict) -> "CompactionSnapshot":
        """Create from dictionary."""
        return cls(
            timestamp=datetime.fromisoformat(data["timestamp"]),
            trigger=data.get("trigger", "unknown"),
            active_plan=data.get("active_plan"),
            current_task_id=data.get("current_task_id"),
            current_task_title=data.get("current_task_title"),
            progress=data.get("progress"),
            last_done=data.get("last_done"),
            whats_next=data.get("whats_next"),
            recent_files=data.get("recent_files"),
            containment=data.get("containment"),
        )


@dataclass
class CompactionMarker:
    """Marker indicating a compaction event occurred."""

    timestamp: datetime
    trigger: str  # "auto" or "manual"
    recovered: bool = False
    snapshot_file: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "trigger": self.trigger,
            "recovered": self.recovered,
            "snapshot_file": self.snapshot_file,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CompactionMarker":
        """Create from dictionary."""
        return cls(
            timestamp=datetime.fromisoformat(data["timestamp"]),
            trigger=data.get("trigger", "unknown"),
            recovered=data.get("recovered", False),
            snapshot_file=data.get("snapshot_file"),
        )
