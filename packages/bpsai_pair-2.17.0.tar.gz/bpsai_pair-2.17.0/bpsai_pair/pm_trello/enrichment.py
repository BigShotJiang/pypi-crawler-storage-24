"""Config-driven post-creation card enrichment."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from bpsai_pair.pm.workflow import EnrichmentPolicy
from bpsai_pair.trello.client import TrelloService

logger = logging.getLogger(__name__)


def enrich_item(
    service: TrelloService,
    card: Any,
    policy: EnrichmentPolicy,
    *,
    config: dict[str, Any],
    checklist_items: dict[str, list[str]] | None = None,
    set_start_date: bool = False,
    add_member: bool = False,
) -> None:
    """Apply config-driven enrichment to a card after creation.

    Each enrichment step is best-effort — failures are logged, not raised.
    """
    _apply_custom_fields(service, card, policy.custom_fields, config)
    _apply_labels(service, card, policy.labels)
    _apply_checklists(service, card, policy.checklists, checklist_items or {})

    if set_start_date:
        try:
            service.set_start_date(card)
        except Exception as e:
            logger.debug("Could not set start date: %s", e)

    if add_member:
        try:
            service.add_member_to_card(card)
        except Exception as e:
            logger.debug("Could not add member: %s", e)


def _apply_custom_fields(
    service: TrelloService, card: Any, field_names: list[str], config: dict,
) -> None:
    fields = {k: config[k] for k in field_names if k in config}
    if not fields:
        return
    try:
        service.set_card_custom_fields(card, fields)
    except Exception as e:
        logger.warning("Could not set custom fields: %s", e)


def _apply_labels(service: TrelloService, card: Any, labels: list[str]) -> None:
    for label_name in labels:
        try:
            service.add_label_to_card(card, label_name)
        except Exception as e:
            logger.warning("Could not add label %s: %s", label_name, e)


def set_completed_date(service: TrelloService, card: Any) -> None:
    """Set the completed date on a card (Trello convention: due date = completed)."""
    try:
        service.set_due_date(card, datetime.now(timezone.utc))
    except Exception as e:
        logger.debug("Could not set completed date: %s", e)


def set_deploy_tag(service: TrelloService, card: Any, version: str) -> None:
    """Set the deploy tag custom field with a vX.Y.Z version string."""
    tag = version if version.startswith("v") else f"v{version}"
    try:
        service.set_card_custom_fields(card, {"Deploy Tag": tag})
    except Exception as e:
        logger.debug("Could not set deploy tag: %s", e)


def resolve_domain_labels(
    config: dict[str, Any],
    file_paths: list[str] | None = None,
    tags: list[str] | None = None,
) -> list[str]:
    """Resolve domain labels from file paths/tags using project config.

    Uses the ``trello.labels`` config section with ``matches`` patterns.
    Falls back to ``trello.defaults.labels`` when no patterns match.
    """
    from bpsai_pair.pm_trello.label_resolver import LabelResolver

    trello_cfg = config.get("trello", config)
    label_config = trello_cfg.get("labels", [])
    defaults = trello_cfg.get("defaults", {}).get("labels", [])
    resolver = LabelResolver(label_config, default_labels=defaults)
    return resolver.resolve(file_paths or [], tags or [])


def _apply_checklists(
    service: TrelloService, card: Any, checklist_names: list[str],
    items_map: dict[str, list[str]],
) -> None:
    for cl_name in checklist_names:
        try:
            service.ensure_checklist(card, cl_name, items_map.get(cl_name, []))
        except Exception as e:
            logger.debug("Could not create checklist %s: %s", cl_name, e)
