"""Configuration and utility helpers for Trello provider."""

from __future__ import annotations

from typing import Any, Optional

import yaml


def load_board_id_from_config() -> Optional[str]:
    """Read board_id from .paircoder/config.yaml."""
    try:
        from bpsai_pair.core.ops import find_paircoder_dir

        paircoder_dir = find_paircoder_dir()
        config_path = paircoder_dir / "config.yaml"
        raw = yaml.safe_load(config_path.read_text()) or {}
        return raw.get("trello", {}).get("board_id") or raw.get("pm", {}).get("board_id")
    except (FileNotFoundError, OSError):
        return None


def load_workflow_config_from_project():
    """Load WorkflowConfig from .paircoder/config.yaml.

    Returns the WorkflowConfig if found, None otherwise.
    Uses load_pm_config to resolve presets and custom workflows.
    """
    try:
        from bpsai_pair.core.ops import find_paircoder_dir

        paircoder_dir = find_paircoder_dir()
        config_path = paircoder_dir / "config.yaml"
        raw = yaml.safe_load(config_path.read_text()) or {}
        if "pm" not in raw and "trello" not in raw:
            return None
        from bpsai_pair.pm.compat import load_pm_config
        _, wf_config = load_pm_config(raw)
        return wf_config
    except Exception:
        return None


def find_card(service: Any, item_id: str) -> tuple[Any, Any]:
    """Find a card by Trello ID first, then by bracket prefix.

    Returns (card, list) or (None, None).
    """
    if service is None:
        return None, None
    card, lst = service.find_card(item_id)
    if card is not None:
        return card, lst
    return service.find_card_with_prefix(item_id)
