"""Sync operations for TrelloProvider — create and update cards."""

from __future__ import annotations

import logging
from typing import Any

from bpsai_pair.pm.types import PMWorkItem, SyncAction, SyncResult
from bpsai_pair.pm.workflow import WorkflowEngine
from bpsai_pair.pm_trello.adapter import TrelloAdapter
from bpsai_pair.trello.client import TrelloService

logger = logging.getLogger(__name__)


def create_card(
    service: TrelloService, engine: WorkflowEngine, item: PMWorkItem,
) -> SyncResult:
    """Create a new Trello card from a PMWorkItem."""
    data = TrelloAdapter.work_item_to_card_data(item)

    try:
        list_name = engine.get_destination_for_status(item.status.value)
    except KeyError:
        list_name = "Intake/Backlog"

    try:
        card = service.create_card_with_custom_fields(
            list_name=list_name,
            name=data["name"],
            desc=data["description"],
            custom_fields=data.get("custom_fields"),
        )
    except Exception as e:
        logger.warning("sync_ops: create_card failed for %s: %s", item.id, e)
        return SyncResult(
            item_id=item.id, action=SyncAction.ERROR, error=str(e),
        )
    if card is None:
        return SyncResult(
            item_id=item.id, action=SyncAction.ERROR,
            error=f"Failed to create card in '{list_name}'",
        )

    return SyncResult(
        item_id=item.id, action=SyncAction.CREATED,
        changes={"provider_id": card.id},
    )


def create_card_and_populate(
    service: TrelloService, engine: WorkflowEngine, item: PMWorkItem,
) -> PMWorkItem | None:
    """Create a Trello card and populate item.provider_meta with card ID."""
    data = TrelloAdapter.work_item_to_card_data(item)

    try:
        list_name = engine.get_destination_for_status(item.status.value)
    except KeyError:
        list_name = "Intake/Backlog"

    try:
        card = service.create_card_with_custom_fields(
            list_name=list_name,
            name=data["name"],
            desc=data["description"],
            custom_fields=data.get("custom_fields"),
        )
    except Exception as e:
        logger.warning("create_card_and_populate failed for %s: %s", item.id, e)
        return None

    if card is None:
        return None

    item.provider_meta["provider_id"] = card.id

    # Enrich card with labels, checklists, and fields (best-effort)
    _enrich_card(service, card, data, item)

    return item


def _enrich_card(
    service: TrelloService, card: Any, data: dict[str, Any], item: PMWorkItem,
) -> None:
    """Set labels, AC checklist, and effort on a newly created card."""
    for label_name in data.get("labels", []):
        try:
            service.add_label_to_card(card, label_name)
        except Exception as e:
            logger.debug("Could not add label %s: %s", label_name, e)

    ac_items = data.get("ac_checklist")
    if ac_items:
        try:
            service.ensure_checklist(card, "Acceptance Criteria", ac_items)
        except Exception as e:
            logger.debug("Could not create AC checklist: %s", e)

    if item.complexity is not None:
        try:
            service.set_effort_field(card, item.complexity)
        except Exception as e:
            logger.debug("Could not set effort field: %s", e)


def update_card_if_changed(
    service: TrelloService, engine: WorkflowEngine,
    card: Any, lst: Any, item: PMWorkItem,
) -> SyncResult:
    """Update an existing Trello card if fields differ from the PMWorkItem."""
    data = TrelloAdapter.work_item_to_card_data(item)
    changes: dict[str, str] = {}

    try:
        # Name
        expected_name = data["name"]
        if getattr(card, "name", "") != expected_name:
            card.set_name(expected_name)
            changes["name"] = expected_name

        # Description
        expected_desc = data["description"]
        if getattr(card, "description", "") != expected_desc:
            card.set_description(expected_desc)
            changes["description"] = expected_desc

        # Status -> move card
        current_list = getattr(lst, "name", "") if lst else ""
        try:
            target_list = engine.get_destination_for_status(item.status.value)
        except KeyError:
            target_list = None

        if target_list and target_list != current_list:
            service.move_card(card, target_list)
            changes["status"] = item.status.value

        # Custom fields (always set if present -- Trello API is idempotent)
        custom_fields = data.get("custom_fields")
        if custom_fields:
            service.set_card_custom_fields(card, custom_fields)
            changes["custom_fields"] = str(custom_fields)
    except Exception as e:
        logger.warning("sync_ops: update_card failed for %s: %s", item.id, e)
        return SyncResult(
            item_id=item.id, action=SyncAction.ERROR, error=str(e),
        )

    if not changes:
        return SyncResult(item_id=item.id, action=SyncAction.SKIPPED)

    return SyncResult(item_id=item.id, action=SyncAction.UPDATED, changes=changes)
