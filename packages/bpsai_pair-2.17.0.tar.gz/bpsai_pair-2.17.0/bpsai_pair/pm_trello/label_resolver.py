"""File-path-based domain label resolver for card enrichment.

Resolves Trello labels by matching file paths and tags against the
``trello.labels[].matches`` keyword patterns from project config.
Falls back to ``default_labels`` when no patterns match.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


class LabelResolver:
    """Resolve domain labels from file paths and tags.

    Parameters
    ----------
    label_config:
        List of label dicts, each with ``name`` and ``matches`` (keyword list).
    default_labels:
        Fallback labels when no patterns match.
    """

    def __init__(
        self,
        label_config: list[dict[str, Any]],
        *,
        default_labels: list[str] | None = None,
    ) -> None:
        self._labels = label_config
        self._defaults = default_labels or []

    _MAX_PATHS = 500
    _MAX_PATH_LEN = 1024

    def resolve(
        self,
        file_paths: list[str],
        tags: list[str],
    ) -> list[str]:
        """Return matching label names for *file_paths* and *tags*.

        Resolution order:
        1. Match path segments against each label's ``matches`` keywords
        2. Match tags against ``matches`` keywords
        3. Fall back to ``default_labels`` if nothing matched
        """
        if len(file_paths) > self._MAX_PATHS:
            logger.debug(
                "Truncating file_paths from %d to %d entries",
                len(file_paths), self._MAX_PATHS,
            )
            file_paths = file_paths[:self._MAX_PATHS]
        capped: list[str] = []
        for p in file_paths:
            if len(p) > self._MAX_PATH_LEN:
                logger.debug("Truncating path from %d to %d chars", len(p), self._MAX_PATH_LEN)
                capped.append(p[:self._MAX_PATH_LEN])
            else:
                capped.append(p)
        tokens = self._tokenize_paths(capped)
        tag_tokens = {t.lower() for t in tags}
        all_tokens = tokens | tag_tokens

        if not all_tokens:
            return list(self._defaults)

        matched: list[str] = []
        for label in self._labels:
            keywords = {k.lower() for k in label.get("matches", [])}
            if keywords & all_tokens:
                name = label["name"]
                if name not in matched:
                    matched.append(name)

        if not matched:
            return list(self._defaults)

        return matched

    @staticmethod
    def _tokenize_paths(paths: list[str]) -> set[str]:
        """Split file paths into lowercase segment tokens."""
        tokens: set[str] = set()
        for path in paths:
            # Normalize separators and split
            normalized = path.replace("\\", "/")
            for segment in normalized.split("/"):
                # Split on dots for file extensions
                for part in segment.split("."):
                    stripped = part.strip().lower()
                    if stripped:
                        tokens.add(stripped)
        return tokens
