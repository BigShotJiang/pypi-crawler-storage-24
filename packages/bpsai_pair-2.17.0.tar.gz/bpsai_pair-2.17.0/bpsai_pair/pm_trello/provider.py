"""TrelloProvider — concrete PM provider wrapping TrelloService."""

from __future__ import annotations

import logging
from typing import Any, Optional

from bpsai_pair.licensing.core import has_feature_api
from bpsai_pair.pm.provider import ProjectManagementProvider
from bpsai_pair.pm.types import (
    PMChecklistItem,
    PMRelationship,
    PMWorkItem,
    RelationshipType,
    SyncAction,
    SyncResult,
    WorkItemStatus,
)
from bpsai_pair.pm.workflow import WorkflowConfig, WorkflowEngine
from bpsai_pair.pm_trello.adapter import TrelloAdapter, parse_api_checklists
from bpsai_pair.pm_trello.config import (
    find_card as _find_card,
    load_board_id_from_config,
    load_workflow_config_from_project,
)
from bpsai_pair.pm_trello.relationship_ops import (
    get_children_from_trello,
    remove_relationship_on_trello,
    set_relationship_on_trello,
)
from bpsai_pair.trello.auth import load_token
from bpsai_pair.trello.client import TrelloService

logger = logging.getLogger(__name__)


class TrelloProvider(ProjectManagementProvider):
    """PM provider backed by Trello via TrelloService composition."""

    name = "trello"
    _CAPS = frozenset({
        "basic", "checklists", "comments", "custom_fields",
        "automations", "relationships", "hierarchy",
    })

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        token: Optional[str] = None,
        board_id: Optional[str] = None,
        workflow_config: Optional[WorkflowConfig] = None,
    ) -> None:
        self._api_key = api_key
        self._token = token
        self._board_id = board_id
        self._workflow_config = workflow_config
        self._service: Optional[TrelloService] = None
        self._engine: Optional[WorkflowEngine] = None

    def connect(self) -> bool:
        api_key = self._api_key
        token = self._token

        if not api_key or not token:
            creds = load_token()
            if not creds:
                logger.warning("No Trello credentials found")
                return False
            api_key = creds["api_key"]
            token = creds["token"]

        self._service = TrelloService(api_key=api_key, token=token)

        board_id = self._board_id
        if not board_id:
            board_id = load_board_id_from_config()

        if board_id:
            self._service.set_board(board_id)

        wf_config = self._workflow_config or load_workflow_config_from_project() or WorkflowConfig.simple()
        self._engine = WorkflowEngine(wf_config)
        return True

    def healthcheck(self) -> bool:
        if self._service is None:
            return False
        return self._service.healthcheck()

    def find_item(self, item_id: str) -> PMWorkItem | None:
        if self._service is None:
            return None

        card, lst = _find_card(self._service, item_id)
        if card is None:
            return None

        return TrelloAdapter.card_to_work_item(card, lst)

    def move_item(self, item_id: str, status: WorkItemStatus) -> bool:
        if self._service is None:
            return False

        card, _ = _find_card(self._service, item_id)
        if card is None:
            return False

        try:
            list_name = self._engine.get_destination_for_status(status.value)
        except KeyError:
            logger.debug("No list mapping for status '%s'", status.value)
            return False

        self._service.move_card(card, list_name)
        return True

    def move_to_destination(self, item_id: str, destination: str) -> bool:
        if self._service is None:
            return False

        if len(destination) > 256:
            logger.warning("Destination string exceeds 256 chars, rejecting")
            return False

        card, _ = _find_card(self._service, item_id)
        if card is None:
            return False

        board_lists = self._service.get_board_lists()
        if destination not in board_lists:
            logger.warning(
                "Destination '%s' not found in board lists: %s",
                destination,
                list(board_lists.keys()),
            )

        self._service.move_card(card, destination)
        return True

    def set_fields(self, item_id: str, fields: dict[str, Any]) -> bool:
        if self._service is None:
            return False

        card, _ = _find_card(self._service, item_id)
        if card is None:
            return False

        # Handle labels separately — they're not custom fields
        labels = fields.pop("labels", None)
        if labels:
            for label_name in labels:
                if not self._add_label_with_fallback(card, label_name):
                    logger.debug("Label '%s' not found on board", label_name)

        if fields:
            self._service.set_card_custom_fields(card, fields)
        return True

    def _add_label_with_fallback(self, card, label_name: str) -> bool:
        """Add a label to a card, trying name variants for spacing differences."""
        import re
        if self._service.add_label_to_card(card, label_name):
            return True
        # Try normalizing spaces around / (e.g. "Worker / Function" vs "Worker/Function")
        normalized = re.sub(r"\s*/\s*", "/", label_name)
        if normalized != label_name and self._service.add_label_to_card(card, normalized):
            return True
        spaced = re.sub(r"\s*/\s*", " / ", label_name)
        if spaced != label_name and self._service.add_label_to_card(card, spaced):
            return True
        return False

    def add_comment(self, item_id: str, text: str) -> bool:
        if self._service is None:
            return False

        card, _ = _find_card(self._service, item_id)
        if card is None:
            return False

        self._service.add_comment(card, text)
        return True

    def create_item(self, item: PMWorkItem) -> PMWorkItem | None:
        if self._service is None or self._engine is None:
            return None

        from bpsai_pair.pm_trello.sync_ops import create_card_and_populate

        result = create_card_and_populate(self._service, self._engine, item)
        if result is None:
            return None

        if item.parent_id:
            self.set_relationship(PMRelationship(
                source_id=item.parent_id,
                target_id=result.provider_meta["provider_id"],
                relationship_type=RelationshipType.PARENT_CHILD,
            ))

        return result

    def sync_item(self, item: PMWorkItem) -> SyncResult:
        if self._service is None or self._engine is None:
            return SyncResult(
                item_id=item.id, action=SyncAction.ERROR,
                error="Service not connected",
            )

        from bpsai_pair.pm_trello.sync_ops import create_card, update_card_if_changed

        card, lst = _find_card(self._service, item.id)
        if card is None:
            return create_card(self._service, self._engine, item)
        return update_card_if_changed(self._service, self._engine, card, lst, item)

    def check_checklist_item(
        self, item_id: str, checklist_item_id: str, *, checked: bool
    ) -> bool:
        if self._service is None:
            return False

        card, _ = _find_card(self._service, item_id)
        if card is None:
            return False

        # checklist_item_id format: "checklist_id:item_id"
        parts = checklist_item_id.split(":", 1)
        if len(parts) != 2:
            logger.debug("Invalid checklist_item_id format (no colon): %s", checklist_item_id)
            return False

        cl_id, ci_id = parts
        return self._service.update_checklist_item(
            card, cl_id, ci_id, checked=checked
        )

    def get_checklist_items(self, item_id: str) -> list[PMChecklistItem]:
        if self._service is None:
            return []

        card, _ = _find_card(self._service, item_id)
        if card is None:
            return []

        return parse_api_checklists(self._service.get_card_checklists(card))

    # Relationship methods delegate to relationship_ops (extracted for arch limits).
    set_relationship = lambda self, rel: (  # noqa: E731
        set_relationship_on_trello(self._service, rel) if self._service else False
    )
    remove_relationship = lambda self, rel: (  # noqa: E731
        remove_relationship_on_trello(self._service, rel) if self._service else False
    )
    get_children = lambda self, item_id: (  # noqa: E731
        get_children_from_trello(self._service, item_id, self.find_item)
        if self._service else []
    )

    def discover_created_item(self, local_id: str) -> PMWorkItem | None:
        if not has_feature_api("pm_automations"):
            return None
        if self._service is None or self._engine is None:
            return None

        from bpsai_pair.pm_trello.discovery import discover_created_item as _discover

        return _discover(self._service, self._engine, local_id)

    def add_checklist_item(
        self, item_id: str, checklist_name: str, item_name: str,
    ) -> str | None:
        if self._service is None:
            return None

        card, _ = _find_card(self._service, item_id)
        if card is None:
            return None

        cl = self._service.get_checklist_by_name(card, checklist_name)
        if cl is None:
            cl = self._service.create_checklist(card, checklist_name)
        if cl is None:
            return None

        result = self._service.add_checklist_item(card, cl["id"], item_name)
        if result is None:
            return None
        return f"{cl['id']}:{result['id']}"

    # Lambda to stay within 15-function arch limit (provider has 15 methods).
    capabilities = lambda self: set(TrelloProvider._CAPS)  # noqa: E731