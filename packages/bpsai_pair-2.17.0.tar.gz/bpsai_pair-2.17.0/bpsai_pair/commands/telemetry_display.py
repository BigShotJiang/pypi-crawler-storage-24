"""Display helpers for telemetry status output.

Extracted from telemetry_helpers.py to maintain architecture compliance.
"""

from __future__ import annotations

from datetime import datetime

from rich.console import Console

from ..telemetry.schema import TelemetryRecord
from ..telemetry.store import TelemetryStats

console = Console()


def _format_bytes(size: int) -> str:
    """Format byte size to human-readable string."""
    if size < 1024:
        return f"{size} bytes"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    else:
        return f"{size / (1024 * 1024):.1f} MB"


def _format_tokens(tokens: int) -> str:
    """Format token count with thousands separator and K suffix."""
    if tokens >= 1000:
        return f"{tokens / 1000:.1f}K"
    return str(tokens)


def print_status_output(data) -> None:
    """Print rich formatted status output."""
    console.print("\n[bold]Telemetry Status[/bold]")
    console.print("=" * 40)
    console.print()

    # Config section
    if data.config.enabled:
        console.print("  Collection: [green]enabled[/green]")
    else:
        console.print("  Collection: [red]disabled[/red]")
    console.print(f"  Privacy Level: {data.config.privacy_level.value}")
    console.print(f"  Retention: {data.config.retention_days} days")
    console.print()

    _print_stats_section(data.stats, data.records, data.storage_bytes, data.oldest_date)

    _print_aggregate_section(
        data.aggregate_count, data.cache_hit_rate,
        data.last_compaction, data.telemetry_file_size,
    )

    _print_audit_section(
        data.audit_count, data.audit_valid, data.audit_error, data.last_audit_time
    )


def _print_stats_section(
    stats: TelemetryStats,
    records: list[TelemetryRecord],
    storage_bytes: int,
    oldest_date: str | None,
) -> None:
    """Print statistics section."""
    console.print("[bold]Statistics:[/bold]")
    if stats.total_records == 0:
        console.print("  No telemetry data collected yet.")
        console.print()
        return

    console.print(f"  Total Records: {stats.total_records}")
    if oldest_date:
        console.print(f"  Since: {oldest_date}")
    console.print(f"  Storage: {_format_bytes(storage_bytes)}")
    console.print(f"  Total Tokens: {_format_tokens(stats.total_tokens)}")
    console.print(f"  Success Rate: {stats.success_rate * 100:.1f}%")
    console.print()

    if stats.avg_tokens_by_task_type:
        console.print("[bold]By Task Type:[/bold]")
        type_counts: dict[str, int] = {}
        for r in records:
            type_counts[r.task_type] = type_counts.get(r.task_type, 0) + 1

        for task_type, avg_tokens in stats.avg_tokens_by_task_type.items():
            count = type_counts.get(task_type, 0)
            console.print(
                f"  {task_type}: {count} records, avg {_format_tokens(int(avg_tokens))} tokens"
            )
        console.print()


def _print_aggregate_section(
    aggregate_count: int,
    cache_hit_rate: float,
    last_compaction: str | None = None,
    telemetry_file_size: int = 0,
) -> None:
    """Print aggregate, cache, and compaction statistics section."""
    has_data = aggregate_count > 0 or cache_hit_rate > 0.0 or last_compaction
    if not has_data:
        return
    console.print("[bold]Compaction & Cache:[/bold]")
    if aggregate_count > 0:
        console.print(f"  Aggregate Records: {aggregate_count}")
    console.print(f"  Cache Hit Rate: {cache_hit_rate * 100:.1f}%")
    if last_compaction:
        console.print(f"  Last Compaction: {last_compaction[:19]}")
    if telemetry_file_size > 0:
        console.print(f"  Telemetry File: {_format_bytes(telemetry_file_size)}")
    console.print()


def _print_audit_section(
    audit_count: int,
    audit_valid: bool,
    audit_error: str | None,
    last_audit_time: datetime | None,
) -> None:
    """Print audit log section."""
    console.print("[bold]Audit Log:[/bold]")
    console.print(f"  Entries: {audit_count}")
    if audit_valid:
        console.print("  Chain Valid: [green]\u2713[/green]")
    else:
        console.print(f"  Chain Valid: [red]\u2717[/red] (warning: {audit_error})")
    if last_audit_time:
        last_entry = last_audit_time.strftime("%Y-%m-%d %H:%M:%S")
        console.print(f"  Last Entry: {last_entry}")
    console.print()
