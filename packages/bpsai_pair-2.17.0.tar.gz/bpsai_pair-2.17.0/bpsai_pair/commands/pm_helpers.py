"""Internal helpers for PM commands — extracted from pm.py."""

from __future__ import annotations

import logging
from typing import Optional

import typer
from rich.console import Console

from .pm_diagnostics import _load_raw_config, _load_workflow_config
from ..core.ops import find_paircoder_dir
from ..planning.parser import TaskParser
from ..pm.lifecycle import PMLifecycleManager
from ..pm.provider import ProjectManagementProvider
from ..pm.registry import get_active_provider
from ..pm.sync import PMSyncManager
from ..pm.types import PMWorkItem
from ..pm.workflow import WorkflowEngine

logger = logging.getLogger(__name__)
console = Console()


def _get_provider() -> Optional[ProjectManagementProvider]:
    """Get the active PM provider from config."""
    raw_config = _load_raw_config()
    if not raw_config:
        return None
    try:
        provider = get_active_provider(raw_config)
    except (KeyError, ImportError) as e:
        logger.debug("Could not load provider: %s", e)
        return None

    if provider.name == "none":
        return None
    return provider


def _get_lifecycle() -> PMLifecycleManager:
    """Build a PMLifecycleManager from the active provider."""
    provider = _get_provider()
    if provider is None:
        console.print("[red]No PM provider configured. Set pm.provider in config.yaml[/red]")
        raise typer.Exit(1)
    raw_config = _load_raw_config()
    workflow = _load_workflow_config(raw_config)
    engine = WorkflowEngine(workflow)
    return PMLifecycleManager(provider, engine)


def _get_sync_manager() -> PMSyncManager:
    """Build a PMSyncManager from the active provider."""
    provider = _get_provider()
    if provider is None:
        console.print("[red]No PM provider configured. Set pm.provider in config.yaml[/red]")
        raise typer.Exit(1)
    raw_config = _load_raw_config()
    workflow = _load_workflow_config(raw_config)
    engine = WorkflowEngine(workflow)
    return PMSyncManager(provider, engine)


def _load_sync_items() -> list[PMWorkItem]:
    """Load local tasks as PMWorkItems for sync."""
    try:
        paircoder_dir = find_paircoder_dir()
    except (FileNotFoundError, OSError):
        return []

    try:
        parser = TaskParser(paircoder_dir / "tasks")
        tasks = parser.parse_all()
        return [PMWorkItem.from_task(t) for t in tasks]
    except FileNotFoundError:
        return []
    except (ValueError, OSError) as e:
        logger.warning("Could not load tasks for sync: %s", e)
        return []
