"""Orchestration evaluate logic for CC TeammateIdle/TaskCompleted hooks.

EXPERIMENTAL: Outputs JSON for CC hook response. CC reads stdout to decide
whether to stop or continue a teammate agent.

Separated from orchestrate.py to stay under architecture line limits.
"""

from __future__ import annotations

import json
import sys
from typing import Optional

from ..core import ops


def run_evaluate(
    event: str,
    agent_id: Optional[str] = None,
    agent_type: Optional[str] = None,
) -> None:
    """Evaluate stop conditions and output JSON to stdout."""
    from ..core.orchestration_hooks import evaluate_stop_conditions

    try:
        root = ops.find_project_root()
    except Exception:
        _output({"continue": True})
        return

    result = evaluate_stop_conditions(
        event=event,
        agent_id=agent_id,
        agent_type=agent_type,
        project_root=root,
    )
    _output(result)


def _output(data: dict) -> None:
    """Write JSON to stdout without Rich formatting."""
    sys.stdout.write(json.dumps(data))
    sys.stdout.write("\n")
    sys.stdout.flush()
