"""Query CLI command for structured state queries.

Exposes the QueryBuilder as `bpsai-pair query` with subcommands:
  - metrics <name> [--task-type TYPE] [--days N] [--json]
  - state <key> [--json]
  - tasks [--status STATUS] [--json]
  - skill <name> [--format json|a2a] [--root PATH]
  - qc-trends [--suite NAME] [--env ENV] [--json]
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..core import ops

console = Console()

app = typer.Typer(
    help="Query project state, metrics, and tasks.",
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _get_root() -> Path:
    return ops.find_project_root()


def _get_qc_db_path() -> Path:
    return _get_root() / ".paircoder" / "data" / "qc_telemetry.db"


def _print_result(data: dict, as_json: bool) -> None:
    if as_json:
        sys.stdout.write(json.dumps(data, indent=2, default=str))
        sys.stdout.write("\n")
        sys.stdout.flush()
    else:
        _print_table(data)


def _print_table(data: dict) -> None:
    category = data.get("category", "result")
    table = Table(title=f"Query: {category}")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="white")
    for key, value in data.items():
        if key == "category":
            continue
        table.add_row(str(key), str(value))
    console.print(table)


@app.command()
def metrics(
    name: str = typer.Argument(..., help="Metric name: success_rate, estimation_accuracy, agent_performance"),
    task_type: Optional[str] = typer.Option(None, "--task-type", "-t", help="Filter by task type"),
    days: Optional[int] = typer.Option(None, "--days", "-d", help="Filter by recency (days)"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Query metrics (success rates, estimation accuracy, agent performance)."""
    from ..feedback.query_builder import QueryBuilder

    root = _get_root()
    q = QueryBuilder(root).metrics(name)
    if task_type:
        q = q.where(task_type=task_type)
    if days:
        q = q.where(days=days)

    try:
        result = q.execute()
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    _print_result(result, json_out)


@app.command()
def state(
    key: str = typer.Argument(..., help="State key: active-tasks, current-plan"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Query project state (active tasks, current plan)."""
    from ..feedback.query_builder import QueryBuilder

    root = _get_root()
    try:
        result = QueryBuilder(root).state(key).execute()
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    _print_result(result, json_out)


@app.command()
def tasks(
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Query tasks with optional status filter."""
    from ..feedback.query_builder import QueryBuilder

    root = _get_root()
    q = QueryBuilder(root).tasks()
    if status:
        q = q.where(status=status)

    result = q.execute()
    _print_result(result, json_out)


@app.command("task-state")
def task_state(
    task_id: Optional[str] = typer.Option(None, "--task-id", "-t", help="Filter by task ID"),
    plan_id: Optional[str] = typer.Option(None, "--plan-id", "-p", help="Filter by plan ID"),
    new_state: Optional[str] = typer.Option(None, "--state", "-s", help="Filter by target state"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Query task state transitions (pending → in_progress → done)."""
    from ..feedback.query_builder import QueryBuilder

    root = _get_root()
    q = QueryBuilder(root).task_state()
    if task_id:
        q = q.where(task_id=task_id)
    if plan_id:
        q = q.where(plan_id=plan_id)
    if new_state:
        q = q.where(new_state=new_state)

    result = q.execute()
    _print_result(result, json_out)


@app.command()
def skill(
    name: str = typer.Argument(..., help="Skill name: sprint_status, driver_activity, review_findings, quality_metrics, session_outcomes"),
    fmt: str = typer.Option("json", "--format", "-f", help="Output format: json (raw) or a2a (framework schema)"),
    root: Optional[str] = typer.Option(None, "--root", help="Project root override"),
):
    """Execute a query skill and output results."""
    from ..query_skills import discover_skills, get_skill
    discover_skills()

    skill_cls = get_skill(name)
    if not skill_cls:
        console.print(f"[red]Unknown skill: {name}[/red]")
        raise typer.Exit(1)

    project_root = Path(root) if root else _get_root()
    paircoder_dir = project_root / ".paircoder"
    db_path = paircoder_dir / "data" / "store.db"

    instance = skill_cls(
        paircoder_dir=paircoder_dir,
        db_path=db_path,
        fallback_dir=paircoder_dir / "telemetry",
    )
    result = instance.execute()

    if fmt == "a2a":
        from ..query_skills.a2a_adapter import format_a2a
        sys.stdout.write(format_a2a(name, result))
        sys.stdout.write("\n")
        sys.stdout.flush()
    else:
        sys.stdout.write(json.dumps(result, indent=2, default=str))
        sys.stdout.write("\n")
        sys.stdout.flush()


@app.command("qc-trends")
def qc_trends(
    suite: Optional[str] = typer.Option(None, "--suite", "-s", help="Filter by suite name"),
    environment: Optional[str] = typer.Option(None, "--env", "-e", help="Filter by environment"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Query QC historical trends and flaky scenarios."""
    from ..query_skills.qc_trends import QCTrendsSkill

    db_path = _get_qc_db_path()
    skill_instance = QCTrendsSkill(db_path=db_path)
    request: dict = {}
    if suite:
        request["suite"] = suite
    if environment:
        request["environment"] = environment

    result = skill_instance.execute(request or None)
    _print_result(result, json_out)
