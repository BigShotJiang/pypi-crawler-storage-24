"""PM command group — provider-agnostic project management operations."""

from __future__ import annotations

import typer
from rich.console import Console

from . import pm_diagnostics
from .pm_crud import crud_app
from .pm_hierarchy_cmd import hierarchy_app
from .pm_sprint import sprint_app
from .pm_diagnostics import _load_raw_config, _load_workflow_config
from .pm_helpers import _get_lifecycle, _get_provider, _get_sync_manager, _load_sync_items  # noqa: F401
from ..licensing import require_feature
from ..pm.errors import PMItemNotFoundError, PMTransitionError
from ..pm.provider import ProjectManagementProvider
from ..pm.types import PMWorkItem, WorkItemStatus

console = Console()

app = typer.Typer(name="pm", help="Project management operations")
app.add_typer(crud_app)
app.add_typer(hierarchy_app)
app.add_typer(sprint_app)


@app.command()
@require_feature("pm_basic")
def start(
    item_id: str = typer.Argument(..., help="Work item ID"),
) -> None:
    """Start a work item (move to in_progress)."""
    lifecycle = _get_lifecycle()
    try:
        item = lifecycle.start_item(item_id)
        console.print(f"[green]Started: {item.title}[/green]")
    except PMItemNotFoundError:
        console.print(f"[red]Item not found: {item_id}[/red]")
        raise typer.Exit(1)
    except PMTransitionError as e:
        console.print(f"[red]Cannot start: {e}[/red]")
        raise typer.Exit(1)


@app.command()
@require_feature("pm_basic")
def done(
    item_id: str = typer.Argument(..., help="Work item ID"),
    summary: str = typer.Option(..., "--summary", "-s", help="Completion summary"),
    strict: bool = typer.Option(True, "--strict/--no-strict", help="Enforce AC check"),
) -> None:
    """Complete a work item (move to done)."""
    lifecycle = _get_lifecycle()
    try:
        item = lifecycle.complete_item(item_id, summary=summary, strict_ac=strict)
        console.print(f"[green]Completed: {item.title}[/green]")
        console.print(f"  Summary: {summary}")
    except PMItemNotFoundError:
        console.print(f"[red]Item not found: {item_id}[/red]")
        raise typer.Exit(1)
    except PMTransitionError as e:
        console.print(f"[red]Cannot complete: {e}[/red]")
        raise typer.Exit(1)


@app.command()
@require_feature("pm_basic")
def block(
    item_id: str = typer.Argument(..., help="Work item ID"),
    reason: str = typer.Option(..., "--reason", "-r", help="Block reason"),
) -> None:
    """Block a work item with a reason."""
    lifecycle = _get_lifecycle()
    try:
        item = lifecycle.block_item(item_id, reason=reason)
        console.print(f"[yellow]Blocked: {item.title}[/yellow]")
        console.print(f"  Reason: {reason}")
    except PMItemNotFoundError:
        console.print(f"[red]Item not found: {item_id}[/red]")
        raise typer.Exit(1)


@app.command()
@require_feature("pm_basic")
def sync() -> None:
    """Sync local tasks to the PM provider."""
    sync_mgr = _get_sync_manager()
    items = _load_sync_items()

    if not items:
        console.print("[yellow]No tasks to sync[/yellow]")
        return

    results = sync_mgr.sync_batch(items)

    created = sum(1 for r in results if r.action.value == "created")
    updated = sum(1 for r in results if r.action.value == "updated")
    skipped = sum(1 for r in results if r.action.value == "skipped")
    errors = sum(1 for r in results if r.action.value == "error")

    console.print(f"[green]Sync complete:[/green] {created} created, {updated} updated, {skipped} skipped, {errors} errors")


@app.command()
@require_feature("pm_basic")
def status() -> None:
    """Show PM provider connection status."""
    provider = _get_provider()

    if provider is None:
        console.print("[yellow]No PM provider configured[/yellow]")
        console.print("[dim]Configure with: pm.provider in config.yaml[/dim]")
        return

    healthy = provider.healthcheck()
    health_str = "[green]healthy[/green]" if healthy else "[red]unhealthy[/red]"
    console.print(f"Provider: {provider.name} ({health_str})")
    console.print(f"Capabilities: {', '.join(sorted(provider.capabilities()))}")

    raw_config = _load_raw_config()
    workflow = _load_workflow_config(raw_config)
    console.print(f"Workflow: {workflow.mode}")

    if "pm" in raw_config:
        console.print("Config source: pm: (native)")
    elif "trello" in raw_config:
        console.print("Config source: trello: (compat)")


@app.command()
@require_feature("pm_hierarchy")
def children(
    parent_id: str = typer.Argument(..., help="Parent work item ID"),
) -> None:
    """List children of a work item."""
    provider = _get_provider()
    if provider is None:
        console.print("[red]No PM provider configured[/red]")
        raise typer.Exit(1)

    items = provider.get_children(parent_id)
    if not items:
        console.print(f"[yellow]No children found for {parent_id}[/yellow]")
        return

    for item in items:
        status_color = "green" if item.status == WorkItemStatus.DONE else "white"
        console.print(f"  [{status_color}]{item.id}[/{status_color}] {item.title} ({item.status.value})")


@app.command()
@require_feature("pm_hierarchy")
def tree(
    root_id: str = typer.Argument(..., help="Root work item ID"),
) -> None:
    """Display hierarchy tree of a work item."""
    provider = _get_provider()
    if provider is None:
        console.print("[red]No PM provider configured[/red]")
        raise typer.Exit(1)

    root = provider.find_item(root_id)
    if root is None:
        console.print(f"[red]Item not found: {root_id}[/red]")
        raise typer.Exit(1)

    _print_tree(provider, root, indent=0, visited=set())


def _print_tree(
    provider: ProjectManagementProvider, item: PMWorkItem, indent: int,
    *, max_depth: int = 10, visited: set | None = None,
) -> None:
    visited = visited if visited is not None else set()
    if item.id in visited:
        return
    visited.add(item.id)
    prefix = "  " * indent
    color = "green" if item.status == WorkItemStatus.DONE else "white"
    console.print(f"{prefix}[{color}]{item.id}[/{color}] {item.title} ({item.status.value})")
    if max_depth <= 0:
        return
    for child in provider.get_children(item.id):
        _print_tree(provider, child, indent + 1, max_depth=max_depth - 1, visited=visited)


@app.command()
@require_feature("pm_basic")
def diagnostics() -> None:
    """Run PM provider diagnostics."""
    provider = _get_provider()
    pm_diagnostics.run_diagnostics(provider)


@app.command()
@require_feature("pm_basic")
def config() -> None:
    """Show resolved PM workflow configuration."""
    pm_diagnostics.show_config()
