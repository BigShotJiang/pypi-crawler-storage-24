"""Workspace check-impact and audit CLI commands.

Part of Sprint 34 Cross-Repo Orchestration.
Commands: check-impact, audit.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from ..core import ops
from ..licensing import require_feature
from ..workspace.audit import WorkspaceAuditLog
from ..workspace.contracts import ContractDetector
from ..workspace.impact import ImpactAnalyzer
from ..workspace.parser import WorkspaceParser

console = Console()
_CONFIG_FILENAME = ".paircoder-workspace.yaml"


def _print_json(data: dict) -> None:
    """Print JSON to stdout."""
    sys.stdout.write(json.dumps(data, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


def _repo_root() -> Path:
    """Get repo root with error message."""
    p = ops.find_project_root()
    if not ops.GitOps.is_repo(p):
        console.print("[red]Error: Not in a git repository.[/red]")
        raise typer.Exit(1)
    return p


def _find_config() -> Path:
    """Find workspace config at repo root or in parent directories."""
    root = _repo_root()
    config_path = WorkspaceParser().find_workspace_config(root)
    if config_path:
        return config_path
    console.print(
        "[red]Error: No workspace config found.[/red]\n"
        "Run 'bpsai-pair workspace init' first."
    )
    raise typer.Exit(1)


def _load_workspace() -> Any:
    """Load workspace config or exit."""
    config_path = _find_config()
    return WorkspaceParser().parse(config_path)


def register_impact_commands(app: typer.Typer) -> None:
    """Register check-impact and audit commands on workspace app."""

    @app.command("check-impact")
    @require_feature("workspace")
    def check_impact(
        since: str = typer.Option("HEAD~1", "--since", help="Commit to compare from"),
        json_out: bool = typer.Option(False, "--json", help="JSON output"),
    ) -> None:
        """Check contract changes and their cross-repo impact."""
        root = _repo_root()
        ws = _load_workspace()
        report_data = _run_impact_check(ws, root, since)

        if json_out:
            _print_json(report_data)
        else:
            _print_impact(report_data)

    @app.command("audit")
    @require_feature("workspace")
    def audit_project(
        project: str = typer.Argument(..., help="Project name to audit"),
        fix: bool = typer.Option(False, "--fix", help="Auto-fix trivial issues"),
        json_out: bool = typer.Option(False, "--json", help="JSON output"),
    ) -> None:
        """Run a full audit of a sibling project."""
        root = _repo_root()
        ws = _load_workspace()

        proj = ws.get_project(project)
        if proj is None:
            console.print(f"[red]Error: Project '{project}' not found.[/red]")
            raise typer.Exit(1)

        report_data = _run_audit(ws, root, project, fix)

        audit_log = WorkspaceAuditLog(ws.root_path)
        audit_log.append(
            action="sibling_audit",
            projects=[project],
            details=report_data,
        )

        if json_out:
            _print_json({"project": project, **report_data})
        else:
            _print_audit(project, report_data)


def _run_impact_check(ws: Any, root: Path, since: str) -> dict:
    """Run contract detection + impact analysis."""
    detector = ContractDetector(ws)
    analyzer = ImpactAnalyzer(ws)

    all_changes = []
    for name, proj in ws.projects.items():
        proj_path = ws.root_path / proj.path
        if not proj_path.exists():
            continue
        if not ops.GitOps.is_repo(proj_path):
            console.print(f"[yellow]Warning: '{name}' at {proj_path} is not a git repo, skipping.[/yellow]")
            continue
        changes = detector.detect_changes(
            proj_path, since, repo_name=name
        )
        all_changes.extend(changes)

    report = analyzer.analyze(all_changes)
    return report.to_dict()


def _run_audit(ws: Any, root: Path, project: str, fix: bool) -> dict:
    """Run audit for a single sibling project."""
    proj = ws.get_project(project)
    proj_path = ws.root_path / proj.path

    detector = ContractDetector(ws)
    analyzer = ImpactAnalyzer(ws)

    changes = detector.detect_changes(
        proj_path, "HEAD~1", repo_name=project
    )
    report = analyzer.analyze(changes)

    return {
        "severity": report.severity,
        "affected_repos": report.affected_repos,
        "recommended_actions": report.recommended_actions,
        "changes": [c.to_dict() for c in changes],
        "fix_applied": fix,
    }


def _print_impact(data: dict) -> None:
    """Print impact report in Rich format."""
    sev = data.get("severity", "low")
    color = {"high": "red", "medium": "yellow", "low": "green"}.get(sev, "white")

    console.print(f"\n[bold]Impact Analysis[/bold]")
    console.print(f"  Severity: [{color}]{sev}[/{color}]")
    console.print(f"  Affected repos: {', '.join(data.get('affected_repos', [])) or 'none'}")

    actions = data.get("recommended_actions", [])
    if actions:
        console.print("\n[bold]Recommended Actions:[/bold]")
        for action in actions:
            console.print(f"  - {action}")
    console.print()


def _print_audit(project: str, data: dict) -> None:
    """Print audit report in Rich format."""
    sev = data.get("severity", "low")
    color = {"high": "red", "medium": "yellow", "low": "green"}.get(sev, "white")

    console.print(f"\n[bold]Audit: {project}[/bold]")
    console.print(f"  Severity: [{color}]{sev}[/{color}]")
    console.print(f"  Changes: {len(data.get('changes', []))}")

    actions = data.get("recommended_actions", [])
    if actions:
        console.print("\n[bold]Recommended Actions:[/bold]")
        for action in actions:
            console.print(f"  - {action}")
    console.print()
