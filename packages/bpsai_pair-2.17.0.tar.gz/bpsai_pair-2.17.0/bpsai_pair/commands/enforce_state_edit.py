"""State-edit enforcement logic.

Extracted from enforce.py for arch compliance. Contains the core
verification logic for blocking state.md edits that would mark
tasks as done without proper completion workflow.
"""

import sys
from pathlib import Path

from .enforce import (
    find_paircoder_dir,
    is_strict_ac_enabled,
    is_trello_enabled,
    output_block_message,
)


def run_state_edit_enforcement(file_path: str, new_content: str) -> None:
    """Execute state-edit enforcement logic.

    Exits with 0 (allow) or 2 (block).
    """
    path = Path(file_path)
    if path.name != "state.md":
        sys.exit(0)

    if not is_strict_ac_enabled():
        sys.exit(0)

    paircoder_dir = find_paircoder_dir()
    if not paircoder_dir:
        sys.exit(0)

    old_content = _read_existing_state(file_path)
    newly_done = _find_newly_done_tasks(old_content, new_content)

    if not newly_done:
        sys.exit(0)

    invalid_tasks = _validate_newly_done(newly_done, paircoder_dir)

    if invalid_tasks:
        _block_invalid_tasks(invalid_tasks)

    sys.exit(0)


def _read_existing_state(file_path: str) -> str:
    """Read existing state.md content for comparison."""
    state_path = Path(file_path)
    if state_path.exists():
        try:
            return state_path.read_text(encoding='utf-8')
        except Exception:
            pass
    return ""


def _find_newly_done_tasks(old_content: str, new_content: str) -> set:
    """Find tasks newly marked as done in state.md."""
    from ..commands.state import extract_done_tasks_from_state_md

    old_done = set(extract_done_tasks_from_state_md(old_content)) if old_content else set()
    new_done = set(extract_done_tasks_from_state_md(new_content))
    return new_done - old_done


def _validate_newly_done(newly_done: set, paircoder_dir: Path) -> list:
    """Validate each newly done task using fast local-only checks."""
    from ..commands.state import validate_task_completion_local

    invalid_tasks = []
    for task_id in newly_done:
        result = validate_task_completion_local(task_id, paircoder_dir)
        if not result.get("has_source", False):
            continue
        if not result["valid"]:
            invalid_tasks.append({"task_id": task_id, "errors": result["errors"]})
    return invalid_tasks


def _block_invalid_tasks(invalid_tasks: list) -> None:
    """Block edit and show error details for invalid tasks."""
    error_details = []
    for task in invalid_tasks:
        error_details.append(f"\n{task['task_id']}:")
        for err in task["errors"]:
            error_details.append(f"  - {err}")

    trello_enabled = is_trello_enabled()
    if trello_enabled:
        complete_cmd = "  bpsai-pair ttask done TRELLO-XXX --summary \"...\""
        validate_cmd = "\n\nFull validation with Trello:\n  bpsai-pair state validate --full"
    else:
        complete_cmd = "  bpsai-pair task update <id> --status done"
        validate_cmd = ""

    output_block_message(
        f"Cannot mark {len(invalid_tasks)} task(s) as done in state.md:\n"
        + "\n".join(error_details) + "\n\n"
        "Complete tasks properly:\n"
        f"{complete_cmd}{validate_cmd}\n\n"
        "Do NOT edit state.md to mark tasks as done manually."
    )
    sys.exit(2)
