"""Feature branch command."""
from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from ..core import ops

console = Console()


def _create_feature_branch(root, name, branch_type, primary, phase, force):
    """Create the feature branch with progress display."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Creating {branch_type}/{name}...", total=None)
        try:
            if force:
                from ..core.bypass_log import log_bypass
                log_bypass(
                    command="feature",
                    target=name,
                    reason="Bypassing dirty-tree check",
                    bypass_type="dirty_tree_bypass",
                )
            ops.FeatureOps.create_feature(
                root=root, name=name, branch_type=branch_type,
                primary_goal=primary, phase=phase, force=force,
            )
            progress.update(task, completed=True)
            console.print(f"[green]![/green] Created branch [bold]{branch_type}/{name}[/bold]")
            console.print("[green]![/green] Updated context with primary goal and phase")
            console.print("[dim]Next: Connect your agent and share /context files[/dim]")
        except ValueError as e:
            progress.update(task, completed=True)
            console.print(f"[red]x {e}[/red]")
            raise typer.Exit(1)


def feature_command(
    name: str = typer.Argument(..., help="Feature branch name (without prefix)"),
    primary: str = typer.Option("", "--primary", "-p", help="Primary goal to stamp into context"),
    phase: str = typer.Option("", "--phase", help="Phase goal for Next action"),
    force: bool = typer.Option(False, "--force", "-f", help="Bypass dirty-tree check"),
    type: str = typer.Option(
        "feature", "--type", "-t",
        help="Branch type: feature|fix|refactor",
        case_sensitive=False,
    ),
):
    """Create feature branch and scaffold context (cross-platform)."""
    from bpsai_pair.commands import init_commands as _cmds
    root = _cmds.repo_root()
    branch_type = type.lower()
    if branch_type not in {"feature", "fix", "refactor"}:
        console.print(
            f"[red]x Invalid branch type: {type}[/red]\n"
            "Must be one of: feature, fix, refactor"
        )
        raise typer.Exit(1)
    _create_feature_branch(root, name, branch_type, primary, phase, force)
