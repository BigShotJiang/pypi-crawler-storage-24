"""Burndown chart command."""
from __future__ import annotations

from datetime import datetime, timedelta

import typer
from rich.table import Table
from .helpers import app, console


def _parse_date(date_str, default):
    """Parse a date string or return default."""
    if not date_str:
        return default
    try:
        return datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        console.print(f"[red]Invalid date format: {date_str}. Use YYYY-MM-DD.[/red]")
        raise typer.Exit(1)


def _display_burndown(data, config, sprint):
    """Display burndown chart table and summary."""
    console.print(f"[bold]Burndown Chart: {sprint}[/bold]")
    console.print("")
    console.print(f"Period: {config.start_date.strftime('%Y-%m-%d')} to {config.end_date.strftime('%Y-%m-%d')}")
    console.print(f"Total Points: {config.total_points}")
    console.print("")

    if not data.data_points:
        console.print("[dim]No data points generated. Check sprint dates.[/dim]")
        return

    table = Table()
    table.add_column("Date", style="cyan")
    table.add_column("Remaining", justify="right")
    table.add_column("Ideal", justify="right")
    table.add_column("Completed", justify="right")
    table.add_column("Status")

    for point in data.data_points:
        diff = point.remaining - point.ideal
        if diff < -5:
            status = "[green]\u25b2 Ahead[/green]"
        elif diff > 5:
            status = "[red]\u25bc Behind[/red]"
        else:
            status = "[yellow]\u25cf On Track[/yellow]"

        table.add_row(
            point.date.strftime("%Y-%m-%d"),
            str(point.remaining),
            f"{point.ideal:.0f}",
            str(point.completed),
            status,
        )

    console.print(table)

    last_point = data.data_points[-1]
    console.print("")
    console.print(f"Current Progress: {last_point.completed}/{config.total_points} points")
    pct = (last_point.completed / config.total_points * 100) if config.total_points > 0 else 0
    console.print(f"Completion: {pct:.0f}%")


@app.command("burndown")
def metrics_burndown(
    sprint: str = typer.Option(None, "--sprint", "-s", help="Sprint ID (default: current sprint)"),
    start_date: str = typer.Option(None, "--start", help="Sprint start date (YYYY-MM-DD)"),
    end_date: str = typer.Option(None, "--end", help="Sprint end date (YYYY-MM-DD)"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Generate burndown chart data for a sprint."""
    from bpsai_pair.commands import metrics as _m
    from ...metrics import SprintConfig
    from ...planning.state import StateManager
    from ...planning.parser import TaskParser

    root = _m.repo_root()
    generator = _m._get_burndown_generator()

    if not sprint:
        state_manager = StateManager(root / ".paircoder")
        sprint = state_manager.state.active_sprint_id or ""
        if not sprint:
            console.print("[yellow]No sprint specified and no active sprint found.[/yellow]")
            console.print("Use --sprint to specify a sprint ID.")
            raise typer.Exit(1)

    start_dt = _parse_date(start_date, datetime.now() - timedelta(days=14))
    end_dt = _parse_date(end_date, datetime.now())

    task_parser = TaskParser(root / ".paircoder" / "tasks")
    tasks = task_parser.parse_all()
    sprint_tasks = [t for t in tasks if t.sprint == sprint]
    total_points = sum(t.complexity for t in sprint_tasks)

    if total_points == 0:
        console.print(f"[yellow]No tasks found for sprint '{sprint}'.[/yellow]")
        raise typer.Exit(1)

    config = SprintConfig(
        sprint_id=sprint,
        start_date=start_dt,
        end_date=end_dt,
        total_points=total_points,
    )

    data = generator.generate(config)

    if json_out:
        _m.print_json(data.to_dict())
    else:
        _display_burndown(data, config, sprint)
