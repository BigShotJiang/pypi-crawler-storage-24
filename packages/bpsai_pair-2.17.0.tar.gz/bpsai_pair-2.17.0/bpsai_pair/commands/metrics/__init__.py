"""Metrics commands for token tracking and cost estimation.

Re-exports all helpers and names for backward-compatible mock paths
(tests mock at ``bpsai_pair.commands.metrics.XXX``).
"""
from .helpers import (
    app,
    console,
    print_json,
    repo_root,
    ops,
    MetricsCollector,
    MetricsReporter,
    BudgetEnforcer,
    _get_metrics_collector,
    _get_telemetry_queries,
    _get_burndown_generator,
    _get_token_tracker,
)

# Import submodules so @app.command decorators register with the shared app
from . import summary_commands  # noqa: F401
from . import analysis_commands  # noqa: F401
from . import burndown_command  # noqa: F401

__all__ = [
    "app",
    "console",
    "print_json",
    "repo_root",
    "ops",
    "MetricsCollector",
    "MetricsReporter",
    "BudgetEnforcer",
    "_get_metrics_collector",
    "_get_telemetry_queries",
    "_get_burndown_generator",
    "_get_token_tracker",
]
