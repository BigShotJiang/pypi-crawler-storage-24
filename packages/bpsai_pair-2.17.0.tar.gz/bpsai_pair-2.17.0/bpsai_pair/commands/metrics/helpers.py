"""Shared helpers for metrics commands."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import typer
from rich.console import Console
from ...core import ops
from ...metrics import MetricsCollector, MetricsReporter, BudgetEnforcer

console = Console()

app = typer.Typer(
    help="Token tracking and cost estimation",
    context_settings={"help_option_names": ["-h", "--help"]}
)


def print_json(data: dict) -> None:
    """Print JSON to stdout without Rich formatting."""
    sys.stdout.write(json.dumps(data, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


def repo_root() -> Path:
    """Get repo root with better error message."""
    # Import via the metrics __init__ shim so test mocks on
    # bpsai_pair.commands.metrics.ops take effect. Python's module
    # cache prevents circular import issues at call time.
    from bpsai_pair.commands import metrics as _m
    p = _m.ops.find_project_root()
    if not _m.ops.GitOps.is_repo(p):
        console.print(
            "[red]\u2717 Not in a git repository.[/red]\n"
            "Please run from your project root directory (where .git exists).\n"
            "[dim]Hint: cd to your project directory first[/dim]"
        )
        raise typer.Exit(1)
    return p


def _get_metrics_collector() -> MetricsCollector:
    """Get a metrics collector instance."""
    root = repo_root()
    history_dir = root / ".paircoder" / "history"
    return MetricsCollector(history_dir)


def _get_telemetry_queries():
    """Get a TelemetryQueries instance backed by TelemetryStore."""
    from ...telemetry.queries import TelemetryQueries
    from ...telemetry.store import TelemetryStore
    root = repo_root()
    store = TelemetryStore(root)
    return TelemetryQueries(store)


def _get_burndown_generator():
    """Get a burndown generator instance."""
    from ...metrics import BurndownGenerator
    root = repo_root()
    history_dir = root / ".paircoder" / "history"
    return BurndownGenerator(history_dir)


def _get_token_tracker():
    """Get a token feedback tracker instance."""
    from ...metrics.estimation import TokenFeedbackTracker
    root = repo_root()
    history_dir = root / ".paircoder" / "history"
    return TokenFeedbackTracker(history_dir)
