"""Setup commands for bpsai-pair.

Commands:
- setup statusline: Install/remove/preview the PairCoder status line
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
import yaml
from rich.console import Console

from ..statusline import THEME_NAMES, THEMES, build_status_line
from ..statusline_install import install_statusline, remove_statusline

console = Console()

setup_app = typer.Typer(
    help="Setup commands",
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _find_root() -> Path:
    """Find project root (used for testability)."""
    from ..core.ops import find_project_root
    return find_project_root()


@setup_app.callback(invoke_without_command=True)
def _callback(ctx: typer.Context):
    """Setup commands for PairCoder."""
    if ctx.invoked_subcommand is None:
        ctx.get_help()
        raise typer.Exit(0)


@setup_app.command("statusline")
def statusline_command(
    theme: Optional[str] = typer.Option(
        None, "--theme", help=f"Color theme: {', '.join(THEME_NAMES)}",
    ),
    remove: bool = typer.Option(False, "--remove", help="Remove statusLine config"),
    preview: bool = typer.Option(False, "--preview", help="Preview all themes"),
):
    """Configure the PairCoder status line for Claude Code."""
    root = _find_root()

    if preview:
        _show_preview()
        return

    if remove:
        removed = remove_statusline(root)
        if removed:
            console.print("[green]Status line removed from .claude/settings.json[/green]")
        else:
            console.print("[dim]Status line was not configured[/dim]")
        return

    if theme:
        if theme not in THEMES:
            console.print(f"[red]Unknown theme: {theme}[/red]")
            console.print(f"[dim]Available: {', '.join(THEME_NAMES)}[/dim]")
            raise typer.Exit(1)
        _set_theme(root, theme)
        console.print(f"[green]Theme set to: {theme}[/green]")

    changed = install_statusline(root)
    if changed:
        console.print("[green]Status line installed in .claude/settings.json[/green]")
    else:
        console.print("[dim]Status line already installed[/dim]")


def _set_theme(root: Path, theme_name: str) -> None:
    """Write theme to config.yaml under statusline section."""
    config_path = root / ".paircoder" / "config.yaml"
    try:
        config = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except Exception:
        config = {}
    config.setdefault("statusline", {})["theme"] = theme_name
    config_path.write_text(
        yaml.dump(config, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )


def _show_preview() -> None:
    """Print a sample status line for each theme."""
    import os

    session = {
        "model": {"display_name": "Opus 4.6"},
        "workspace": {"current_dir": "/home/user/myproject", "project_dir": "."},
        "cost": {
            "total_cost_usd": 0.08,
            "total_duration_ms": 125000,
            "total_lines_added": 47,
            "total_lines_removed": 12,
        },
    }
    for name in THEME_NAMES:
        os.environ["PAIRCODER_THEME"] = name
        line = build_status_line(session)
        console.print(f"  [bold]{name:>8}[/bold]  {line}")
    os.environ.pop("PAIRCODER_THEME", None)
