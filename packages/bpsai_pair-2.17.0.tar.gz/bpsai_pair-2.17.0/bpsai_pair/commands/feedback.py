"""Feedback system CLI commands.

Part of Sprint 33 Feedback Loop.
Commands: status, accuracy, calibrate, query.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from ..core import ops
from ..feedback.anomaly import AnomalyDetector
from ..licensing.core import require_feature
from ..feedback.calibration import CalibrationEngine
from ..feedback.service import FeedbackService
from .feedback_helpers import (
    print_accuracy_output,
    print_calibrate_output,
    print_demand_summary,
    print_query_output,
    print_status_output,
)

console = Console()


def print_json(data: dict) -> None:
    """Print JSON to stdout without Rich formatting."""
    sys.stdout.write(json.dumps(data, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


def repo_root() -> Path:
    """Get repo root with better error message."""
    p = ops.find_project_root()
    if not ops.GitOps.is_repo(p):
        console.print(
            "[red]Error: Not in a git repository.[/red]\n"
            "Please run from your project root directory (where .git exists)."
        )
        raise typer.Exit(1)
    return p


app = typer.Typer(
    help="Feedback system commands",
    context_settings={"help_option_names": ["-h", "--help"]},
)


@app.command("status")
@require_feature("feedback")
def feedback_status(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show calibration health and statistics."""
    root = repo_root()
    svc = FeedbackService(root)
    detector = AnomalyDetector(root)

    cal_status = svc.get_calibration_status()
    anomaly_summary = detector.get_anomaly_summary()
    demand_signals = svc.get_demand_signals()

    # Build per-type estimates
    type_estimates: dict[str, dict[str, Any]] = {}
    for task_type in cal_status.get("task_types", []):
        tokens = svc.estimate_tokens(task_type)
        duration = svc.estimate_duration(task_type)
        type_estimates[task_type] = {**tokens, **duration}

    if json_out:
        data: dict[str, Any] = {
            **cal_status,
            "type_estimates": type_estimates,
            "anomalies": anomaly_summary,
        }
        if demand_signals is not None:
            data["demand_signals"] = demand_signals
        print_json(data)
    else:
        print_status_output(cal_status, anomaly_summary, type_estimates)
        if demand_signals is not None:
            print_demand_summary(demand_signals)


@app.command("accuracy")
@require_feature("feedback")
def feedback_accuracy(
    days: int = typer.Option(7, "--days", help="Number of days to analyze"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Compare estimated vs actual performance."""
    root = repo_root()
    svc = FeedbackService(root)
    performance = svc.get_recent_performance(days=days)

    if json_out:
        print_json(performance)
    else:
        print_accuracy_output(performance)


@app.command("calibrate")
@require_feature("feedback")
def feedback_calibrate(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Trigger recalibration from telemetry data."""
    root = repo_root()
    engine = CalibrationEngine(root)
    cal_data = engine.calibrate()

    result = cal_data.to_dict()

    if json_out:
        print_json(result)
    else:
        print_calibrate_output(result)


@app.command("query")
@require_feature("feedback")
def feedback_query(
    task_type: str = typer.Argument(..., help="Task type to query estimates for"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Get estimates for a specific task type."""
    root = repo_root()
    svc = FeedbackService(root)

    token_est = svc.estimate_tokens(task_type)
    dur_est = svc.estimate_duration(task_type)
    effort = svc.get_effort_recommendation(task_type)
    stats = svc.engine._get_stats(task_type)

    if json_out:
        print_json({
            "task_type": task_type,
            "tokens": token_est,
            "duration": dur_est,
            "sample_count": stats.sample_count,
            "success_rate": stats.success_rate,
            "recommended_model": stats.recommended_model,
            "recommended_effort": effort,
        })
    else:
        print_query_output(
            task_type,
            token_est,
            dur_est,
            stats.sample_count,
            stats.success_rate,
            effort,
        )
