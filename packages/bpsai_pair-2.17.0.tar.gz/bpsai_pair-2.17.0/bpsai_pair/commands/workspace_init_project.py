"""Workspace init-project CLI command.

Registers the `init-project` subcommand on the workspace command group.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from ..licensing import require_feature
from ..workspace.init_project import InitResult, ProjectInitializer
from ..workspace.parser import WorkspaceParser
from ..workspace.schema import WorkspaceConfig

console = Console()


def _load_workspace() -> Any:
    """Find and load workspace config, or exit with error."""
    root = Path.cwd()
    parser = WorkspaceParser()
    config_path = parser.find_workspace_config(root)
    if config_path is None:
        console.print(
            "[red]Error: No workspace config found.[/red]\n"
            "Run 'bpsai-pair workspace init' first.",
        )
        raise typer.Exit(1)
    return parser.parse(config_path)


def _print_result(result: InitResult) -> None:
    """Print a single init result to the console."""
    if result.error:
        console.print(f"[red]✗ {result.project_name}:[/red] {result.error}")
        return
    status = "[dim]dry-run[/dim]" if result.dry_run else "[green]✓[/green]"
    console.print(f"{status} {result.project_name} ({result.stack_classification})")
    if result.inherited_from:
        console.print(f"  Inherited from: {', '.join(result.inherited_from)}")
    if result.created_files and not result.dry_run:
        console.print(f"  Created: {', '.join(result.created_files)}")


def _result_to_dict(result: InitResult) -> dict[str, Any]:
    """Convert InitResult to a JSON-serializable dict."""
    return {
        "project_name": result.project_name,
        "project_path": str(result.project_path),
        "stack": result.stack_classification,
        "inherited_from": result.inherited_from,
        "created_files": result.created_files,
        "dry_run": result.dry_run,
        "error": result.error,
    }


def _print_json(data: Any) -> None:
    """Print JSON to stdout."""
    sys.stdout.write(json.dumps(data, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


def _detect_current_project(ws: WorkspaceConfig) -> str | None:
    """Auto-detect which workspace project the CWD is inside.

    When multiple projects match (nested layouts), returns the deepest
    match so that e.g. ``api/web`` is preferred over ``api``.
    """
    cwd = Path.cwd().resolve()
    best_name: str | None = None
    best_depth = -1
    for name in ws.get_project_names():
        project = ws.get_project(name)
        project_path = (ws.root_path / project.path).resolve()
        if cwd == project_path or project_path in cwd.parents:
            depth = len(project_path.parts)
            if depth > best_depth:
                best_name = name
                best_depth = depth
    return best_name


def _exit_code_for(result: InitResult) -> int:
    """Determine exit code from an InitResult."""
    if result.error is None:
        return 0
    return result.error_code or 1


def register_init_project_commands(app: typer.Typer) -> None:
    """Register init-project command on workspace app."""

    @app.command("init-project")
    @require_feature("workspace")
    def init_project(
        name: str = typer.Argument(None, help="Project name to initialize"),
        all_projects: bool = typer.Option(False, "--all", help="Initialize all projects"),
        force: bool = typer.Option(False, "--force", help="Overwrite existing with backup"),
        dry_run: bool = typer.Option(False, "--dry-run", help="Preview without writing"),
        json_out: bool = typer.Option(False, "--json", help="JSON output"),
        no_claude: bool = typer.Option(False, "--no-claude", help="Skip .claude/ scaffolding"),
    ) -> None:
        """Initialize a project in the workspace with PairCoder scaffolding."""
        ws = _load_workspace()

        if not name and not all_projects:
            name = _detect_current_project(ws)
            if name is None:
                console.print(
                    "[red]Error: Provide a project name or use --all.[/red]",
                )
                raise typer.Exit(1)
            console.print(f"Auto-detected project: [bold]{name}[/bold]")
        initializer = ProjectInitializer(ws)

        if all_projects:
            results = initializer.initialize_all(
                force=force, dry_run=dry_run, include_claude=not no_claude,
            )
            if json_out:
                _print_json([_result_to_dict(r) for r in results])
            else:
                for r in results:
                    _print_result(r)
            errors = [r for r in results if r.error]
            raise typer.Exit(1 if errors else 0)

        result = initializer.initialize(
            name, force=force, dry_run=dry_run, include_claude=not no_claude,
        )
        if json_out:
            _print_json(_result_to_dict(result))
        else:
            _print_result(result)
        raise typer.Exit(_exit_code_for(result))
