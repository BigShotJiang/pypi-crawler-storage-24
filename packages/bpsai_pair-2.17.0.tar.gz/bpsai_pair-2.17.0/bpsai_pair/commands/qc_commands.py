"""QC CLI commands for initializing, discovering, validating, and reporting.

Provides `bpsai-pair qc init|list|validate|report` with env/tag/json flags.
"""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

import typer
from rich.console import Console
from rich.table import Table

from ..core import ops
from ..qc.templates import DEFAULT_CONFIG, EXAMPLE_SUITE

console = Console()

app = typer.Typer(
    help="QC test suite management --- list, validate, and report.",
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _get_project_root() -> Path:
    return ops.find_project_root()


@app.command()
def init():
    """Initialize QC directory structure with example config and suite."""
    root = _get_project_root()
    qc_dir = root / ".paircoder" / "qc"
    suites_dir = qc_dir / "suites"
    reports_dir = qc_dir / "reports"

    suites_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)

    # Config (non-destructive)
    config_path = qc_dir / "config.yaml"
    if not config_path.exists():
        config_path.write_text(DEFAULT_CONFIG, encoding="utf-8")
        console.print("[green]Created[/green] .paircoder/qc/config.yaml")
    else:
        console.print("[dim]Skipped[/dim] config.yaml (already exists)")

    # Example suite (non-destructive)
    example_path = suites_dir / "example.qa.yaml"
    if not example_path.exists():
        example_path.write_text(EXAMPLE_SUITE, encoding="utf-8")
        console.print("[green]Created[/green] .paircoder/qc/suites/example.qa.yaml")
    else:
        console.print("[dim]Skipped[/dim] example.qa.yaml (already exists)")

    # Reports .gitignore
    gitignore_path = reports_dir / ".gitignore"
    if not gitignore_path.exists():
        gitignore_path.write_text("*\n!.gitignore\n", encoding="utf-8")

    console.print("\nQC initialized. Next steps:")
    console.print("  1. Edit [cyan].paircoder/qc/config.yaml[/cyan] with your URLs and credentials")
    console.print("  2. Edit [cyan].paircoder/qc/suites/example.qa.yaml[/cyan] for your app")
    console.print("  3. Run [cyan]bpsai-pair qc validate[/cyan] to check your specs")
    console.print("  4. Run [cyan]/run-qc[/cyan] to execute tests via Chrome")


def _discover_suites(project_root: Path) -> list[Path]:
    """Find all .qa.yaml files in .paircoder/qc/suites/.

    Applies a symlink/path-traversal guard: any file whose resolved
    path escapes the resolved suites directory is silently skipped.
    """
    suites_dir = project_root / ".paircoder" / "qc" / "suites"
    if not suites_dir.exists():
        return []
    resolved_dir = suites_dir.resolve()
    safe: list[Path] = []
    for found in sorted(suites_dir.rglob("*.qa.yaml")):
        try:
            resolved = found.resolve()
            resolved.relative_to(resolved_dir)
        except (ValueError, OSError):
            continue
        safe.append(found)
    return safe


@app.command("list")
def list_suites(
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Filter by tags (comma-separated)"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List discovered QC test suites."""
    root = _get_project_root()
    suite_paths = _discover_suites(root)

    if not suite_paths:
        if json_out:
            _json_print({"suites": []})
        else:
            console.print("No QC suites found in .paircoder/qc/suites/")
        return

    tag_filter = set(tags.split(",")) if tags else None
    entries = []
    for path in suite_paths:
        info = _parse_suite_info(path)
        if info and (not tag_filter or tag_filter & set(info["tags"])):
            entries.append(info)

    if json_out:
        _json_print({"suites": entries})
        return

    if not entries:
        console.print("No QC suites match the specified tags")
        return

    table = Table(title="QC Test Suites")
    table.add_column("Name", style="cyan")
    table.add_column("Tags", style="yellow")
    table.add_column("Scenarios", justify="right")
    table.add_column("File", style="dim")

    for e in entries:
        table.add_row(
            e["name"],
            ", ".join(e["tags"]),
            str(e["scenario_count"]),
            e["file"],
        )
    console.print(table)


@app.command()
def validate(
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Validate all QC suite specs."""
    from ..qc.loader import load_suite
    from ..qc.models import QCValidationError, QCUnresolvedVariableError

    root = _get_project_root()
    suite_paths = _discover_suites(root)
    results = []

    for path in suite_paths:
        try:
            load_suite(path, env_vars={})
            results.append({"file": path.name, "valid": True, "error": None})
        except QCUnresolvedVariableError:
            # Unresolved vars are expected during validation (no env loaded)
            results.append({"file": path.name, "valid": True, "error": None})
        except QCValidationError as e:
            results.append({"file": path.name, "valid": False, "error": str(e)})
        except Exception as e:
            results.append({"file": path.name, "valid": False, "error": str(e)})

    if json_out:
        _json_print({"results": results})
        return

    valid_count = sum(1 for r in results if r["valid"])
    invalid = [r for r in results if not r["valid"]]

    if invalid:
        for r in invalid:
            console.print(f"  [red]INVALID[/red] {r['file']}: {r['error']}")
        console.print("")

    console.print(f"{valid_count} suite(s) valid, {len(invalid)} invalid")


@app.command()
def report(
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Display results from the last QC run."""
    from ..qc.reporter import QCReporter

    root = _get_project_root()
    reports_dir = root / ".paircoder" / "qc" / "reports"
    reporter = QCReporter(reports_dir=reports_dir)

    latest = reporter.load_latest()
    if latest is None:
        if json_out:
            _json_print({"error": "No reports found"})
        else:
            console.print("No QC reports found in .paircoder/qc/reports/")
        return

    if json_out:
        _json_print(latest.to_dict())
        return

    console.print(reporter.format_summary(latest))


def _parse_suite_info(path: Path) -> dict | None:
    """Quick parse of suite metadata without full validation."""
    try:
        import yaml

        with open(path, encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return {
            "name": data.get("name", path.stem),
            "tags": data.get("tags", []),
            "scenario_count": len(data.get("scenarios") or []),
            "file": path.name,
        }
    except Exception as e:
        logger.debug("Failed to parse suite %s: %s", path, e)
        return None


def _json_print(data: dict) -> None:
    sys.stdout.write(json.dumps(data, indent=2, default=str))
    sys.stdout.write("\n")
    sys.stdout.flush()


# Backward-compat: deprecated `qa` alias
_deprecated_app = typer.Typer(
    help="[DEPRECATED] Use 'bpsai-pair qc' instead.",
    deprecated=True,
)


@_deprecated_app.callback(invoke_without_command=True)
def _qa_deprecated(ctx: typer.Context):
    """Deprecated --- use 'bpsai-pair qc' instead."""
    _deprecation_warning()
    if ctx.invoked_subcommand is None:
        raise typer.Exit()


def _deprecation_warning():
    """Print deprecation warning to stderr."""
    sys.stderr.write(
        "\033[33mWarning: 'bpsai-pair qa' is deprecated. "
        "Use 'bpsai-pair qc' instead.\033[0m\n"
    )


@_deprecated_app.command("init")
def _qa_init():
    """[DEPRECATED] Use 'bpsai-pair qc init'."""
    _deprecation_warning()
    init()


@_deprecated_app.command("list")
def _qa_list(
    tags: Optional[str] = typer.Option(None, "--tags", "-t"),
    json_out: bool = typer.Option(False, "--json"),
):
    """[DEPRECATED] Use 'bpsai-pair qc list'."""
    _deprecation_warning()
    list_suites(tags=tags, json_out=json_out)


@_deprecated_app.command("validate")
def _qa_validate(json_out: bool = typer.Option(False, "--json")):
    """[DEPRECATED] Use 'bpsai-pair qc validate'."""
    _deprecation_warning()
    validate(json_out=json_out)


@_deprecated_app.command("report")
def _qa_report(json_out: bool = typer.Option(False, "--json")):
    """[DEPRECATED] Use 'bpsai-pair qc report'."""
    _deprecation_warning()
    report(json_out=json_out)
