"""Workspace index CLI command for cross-repo document discovery.

Registers the 'workspace index' subcommand for querying
the workspace-index.yaml file by topic.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from ..workspace.parser import WorkspaceParser
from ..workspace.workspace_index import load_index, query_by_topic

console = Console()

_CONFIG_FILENAME = ".paircoder-workspace.yaml"


def _find_workspace_root() -> Path:
    """Find workspace root by locating workspace config."""
    from ..core import ops

    root = ops.find_project_root()
    parser = WorkspaceParser()
    config_path = parser.find_workspace_config(root)
    if config_path:
        return config_path.parent
    console.print(
        "[red]Error: No workspace config found.[/red]\n"
        "Run 'bpsai-pair workspace init' first."
    )
    raise typer.Exit(1)


def _print_index_table(entries: list, topic_filter: str | None) -> None:
    """Print index entries as a Rich table."""
    if not entries:
        if topic_filter:
            console.print(f"No entries found for topic '{topic_filter}'.")
        else:
            console.print("Workspace index is empty — no entries found.")
        return

    title = f"Workspace Index — topic: {topic_filter}" if topic_filter else "Workspace Index"
    table = Table(title=title, show_lines=False)
    table.add_column("Path", style="cyan", no_wrap=False)
    table.add_column("Topics", style="green")
    table.add_column("Description", style="white")

    for entry in entries:
        table.add_row(
            entry.path,
            ", ".join(entry.topics),
            entry.description,
        )
    console.print(table)


def _print_json(entries: list) -> None:
    """Print entries as JSON to stdout."""
    data = {
        "entries": [
            {
                "path": e.path,
                "topics": e.topics,
                "description": e.description,
            }
            for e in entries
        ]
    }
    sys.stdout.write(json.dumps(data, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


def register_index_command(app: typer.Typer) -> None:
    """Register the 'index' subcommand on the workspace app."""

    @app.command("index")
    def workspace_index(
        topic: str = typer.Option(None, "--topic", "-t", help="Filter by topic"),
        json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
    ) -> None:
        """Query the workspace document index by topic."""
        ws_root = _find_workspace_root()
        index = load_index(ws_root)

        if topic:
            entries = query_by_topic(index, topic)
        else:
            entries = index.entries

        if json_out:
            _print_json(entries)
        else:
            _print_index_table(entries, topic)
