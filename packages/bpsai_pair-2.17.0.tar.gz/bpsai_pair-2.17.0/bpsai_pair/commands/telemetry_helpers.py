"""Helper functions for telemetry commands.

Data collection helpers for telemetry status.
Display helpers are in telemetry_display.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from ..telemetry.audit import AuditLog
from ..telemetry.config import TelemetryConfig
from ..telemetry.queries import TelemetryQueries
from ..telemetry.schema import TelemetryRecord
from ..telemetry.store import TelemetryStats, TelemetryStore

# Re-export display functions for backward compatibility
from .telemetry_display import (  # noqa: F401
    _format_bytes,
    _format_tokens,
    print_status_output,
)


@dataclass
class StatusData:
    """Collected data for telemetry status display."""

    config: TelemetryConfig
    stats: TelemetryStats
    records: list[TelemetryRecord]
    storage_bytes: int
    oldest_date: str | None
    audit_count: int
    audit_valid: bool
    audit_error: str | None
    last_audit_time: datetime | None
    aggregate_count: int = 0
    cache_hit_rate: float = 0.0
    last_compaction: str | None = None
    telemetry_file_size: int = 0


def _collect_storage_and_audit(
    root: Path,
) -> dict[str, Any]:
    """Collect storage, audit, compaction, and aggregate data.

    Returns:
        Dict with keys: storage_bytes, audit_count, audit_valid,
        audit_error, last_audit_time, aggregate_count, cache_hit_rate,
        last_compaction, telemetry_file_size.
    """
    telemetry_dir = root / ".paircoder" / "telemetry"
    audit_file = telemetry_dir / "audit.jsonl"
    audit = AuditLog(audit_file)
    audit_entries = audit.get_entries(limit=1)
    audit_valid, audit_error = audit.verify()
    audit_count = len(audit.get_entries(limit=10000))

    telemetry_file = telemetry_dir / "telemetry.jsonl"
    storage_bytes = 0
    if telemetry_file.exists():
        storage_bytes = telemetry_file.stat().st_size
    if audit_file.exists():
        storage_bytes += audit_file.stat().st_size

    store = TelemetryStore(root)
    queries = TelemetryQueries(store)
    aggregates = store.load_aggregates()
    cache_stats = queries.get_cache_stats()

    from ..telemetry.auto_compaction import get_last_compaction_info
    compaction_info = get_last_compaction_info(root)

    return {
        "storage_bytes": storage_bytes,
        "audit_count": audit_count,
        "audit_valid": audit_valid,
        "audit_error": audit_error,
        "last_audit_time": audit_entries[0].timestamp if audit_entries else None,
        "aggregate_count": sum(a.record_count for a in aggregates),
        "cache_hit_rate": cache_stats["cache_hit_rate"],
        "last_compaction": (
            compaction_info["last_compaction"] if compaction_info else None
        ),
        "telemetry_file_size": (
            telemetry_file.stat().st_size if telemetry_file.exists() else 0
        ),
    }


def collect_status_data(root: Path) -> StatusData:
    """Collect all data needed for status display."""
    config = TelemetryConfig.load(root)
    store = TelemetryStore(root)
    stats = store.get_stats()

    records = store.query(limit=10000)
    oldest_date = None
    if records:
        oldest_date = min(r.timestamp for r in records).strftime("%Y-%m-%d")

    info = _collect_storage_and_audit(root)

    return StatusData(
        config=config,
        stats=stats,
        records=records,
        storage_bytes=info["storage_bytes"],
        oldest_date=oldest_date,
        audit_count=info["audit_count"],
        audit_valid=info["audit_valid"],
        audit_error=info["audit_error"],
        last_audit_time=info["last_audit_time"],
        aggregate_count=info["aggregate_count"],
        cache_hit_rate=info["cache_hit_rate"],
        last_compaction=info["last_compaction"],
        telemetry_file_size=info["telemetry_file_size"],
    )


def build_status_json(data: StatusData) -> dict[str, Any]:
    """Build JSON output dictionary from status data."""
    return {
        "enabled": data.config.enabled,
        "privacy_level": data.config.privacy_level.value,
        "retention_days": data.config.retention_days,
        "statistics": {
            "total_records": data.stats.total_records,
            "total_tokens": data.stats.total_tokens,
            "total_duration_seconds": data.stats.total_duration_seconds,
            "success_rate": data.stats.success_rate,
            "by_task_type": data.stats.avg_tokens_by_task_type,
            "storage_bytes": data.storage_bytes,
            "oldest_record": data.oldest_date,
            "aggregate_records": data.aggregate_count,
            "cache_hit_rate": data.cache_hit_rate,
        },
        "compaction": {
            "last_compaction": data.last_compaction,
            "telemetry_file_size": data.telemetry_file_size,
        },
        "audit": {
            "entries": data.audit_count,
            "valid": data.audit_valid,
            "error": data.audit_error,
            "last_entry": (
                data.last_audit_time.isoformat() if data.last_audit_time else None
            ),
        },
    }


