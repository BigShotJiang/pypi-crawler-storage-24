"""Post-install upgrade detection and prompting.

Detects when the CLI package version has changed (e.g. after pip upgrade)
and prompts the user to run `bpsai-pair upgrade` if the project config
is stale.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from ..core.config_defaults import is_config_stale


def get_last_run_version(project_root: Path) -> Optional[str]:
    """Read the last-run CLI version from .paircoder/.cli_version."""
    version_file = project_root / ".paircoder" / ".cli_version"
    if not version_file.exists():
        return None
    try:
        return version_file.read_text(encoding="utf-8").strip()
    except Exception:
        return None


def save_last_run_version(project_root: Path, version: str) -> None:
    """Save the current CLI version to .paircoder/.cli_version."""
    paircoder_dir = project_root / ".paircoder"
    if not paircoder_dir.exists():
        return
    try:
        (paircoder_dir / ".cli_version").write_text(version, encoding="utf-8")
    except Exception:
        pass


def check_upgrade_needed(project_root: Path, current_version: str) -> bool:
    """Check if an upgrade prompt should be shown.

    Returns True when:
    1. The CLI version has changed since last run (or first run), AND
    2. The project config version is behind the current schema version.
    """
    last_version = get_last_run_version(project_root)
    if last_version == current_version:
        return False

    stale, _, _ = is_config_stale(project_root)
    return stale


def _prompt_user() -> bool:
    """Ask the user whether to run upgrade now. Returns True if accepted."""
    import sys
    sys.stderr.write(
        "\033[33mProject config is outdated after upgrade. "
        "Run 'bpsai-pair upgrade' now? [Y/n] \033[0m"
    )
    sys.stderr.flush()
    try:
        answer = input().strip().lower()
        return answer in ("", "y", "yes")
    except (EOFError, KeyboardInterrupt):
        return False


def _run_upgrade_inline(project_root: Path) -> None:
    """Run upgrade programmatically (no interactive prompts)."""
    try:
        from .upgrade_helpers import (
            get_template_dir, plan_upgrade, execute_upgrade,
        )

        template = get_template_dir()
        if not template:
            return

        plan = plan_upgrade(project_root, template)
        execute_upgrade(project_root, template, plan)
    except Exception:
        import sys
        sys.stderr.write(
            "\033[33mAuto-upgrade failed. Run 'bpsai-pair upgrade' manually.\033[0m\n"
        )


def maybe_prompt_upgrade(project_root: Path, current_version: str) -> None:
    """Check for version change and prompt user to upgrade if needed.

    Called during CLI startup. TTY-gated to avoid prompting in
    non-interactive contexts (tests, piped commands, CI).
    """
    import sys

    try:
        if not check_upgrade_needed(project_root, current_version):
            save_last_run_version(project_root, current_version)
            return

        # Only prompt on real TTY
        if not hasattr(sys.stderr, "isatty") or not sys.stderr.isatty():
            save_last_run_version(project_root, current_version)
            return

        if _prompt_user():
            _run_upgrade_inline(project_root)
        else:
            sys.stderr.write(
                "\033[33mSkipped. Run 'bpsai-pair upgrade' when ready.\033[0m\n"
            )

        save_last_run_version(project_root, current_version)
    except Exception:
        pass
