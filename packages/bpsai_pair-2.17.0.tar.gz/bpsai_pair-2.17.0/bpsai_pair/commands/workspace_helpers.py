"""Display and utility helpers for workspace commands.

Extracts Rich formatting and git operations from the main workspace
command module to keep function counts within architecture limits.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from rich.console import Console

from ..workspace.agent_teams import AgentTeamInfo
from ..workspace.git_ops import git_branch, git_is_dirty, git_last_commit, git_pull
from ..workspace.schema import WorkspaceConfig

console = Console()


def print_status_output(
    name: str,
    config_path: Path,
    project_states: list[dict[str, Any]],
    dependencies: list[str],
) -> None:
    """Print workspace status in Rich formatted output."""
    console.print(f"\n[bold]Workspace:[/bold] {name}")
    console.print(f"  Config: {config_path}")
    console.print(f"  Projects: {len(project_states)}")

    if project_states:
        console.print("\n[bold]Projects:[/bold]")
        for proj in project_states:
            _print_project_state(proj)

    if dependencies:
        console.print("\n[bold]Dependencies:[/bold]")
        for dep in dependencies:
            console.print(f"  {dep}")

    console.print()


def _print_project_state(proj: dict[str, Any]) -> None:
    """Print a single project state entry."""
    name = proj["name"]
    if not proj.get("exists", False):
        console.print(f"  {name}: [red]path not found[/red]")
        return

    branch = proj.get("branch") or "unknown"
    is_dirty = proj.get("is_dirty", False)
    status_str = "[yellow]uncommitted changes[/yellow]" if is_dirty else "[green]Clean[/green]"

    console.print(f"  [bold]{name}[/bold] ({proj.get('path', '?')})")
    console.print(f"    Branch: {branch}")
    console.print(f"    Status: {status_str}")


def format_dependencies(
    projects: dict[str, dict[str, Any]],
) -> list[str]:
    """Format project dependency relationships as strings."""
    deps: list[str] = []
    for pname, pdata in projects.items():
        consumers = pdata.get("consumers", [])
        consumes = pdata.get("consumes", [])
        if consumers:
            deps.append(f"{pname} -> {', '.join(consumers)} (consumers)")
        if consumes:
            deps.append(f"{pname} consumes {', '.join(consumes)}")
    return deps


def gather_project_states(ws: WorkspaceConfig) -> list[dict[str, Any]]:
    """Gather runtime state for all projects."""
    states: list[dict[str, Any]] = []
    for name, proj in ws.projects.items():
        abs_path = ws.root_path / proj.path
        state: dict[str, Any] = {"name": name, "path": str(proj.path)}
        if not abs_path.is_dir():
            state["exists"] = False
            state["branch"] = None
            state["is_dirty"] = False
        else:
            state["exists"] = True
            is_git = (abs_path / ".git").exists()
            state["branch"] = git_branch(abs_path) if is_git else None
            state["last_commit"] = git_last_commit(abs_path) if is_git else None
            state["is_dirty"] = git_is_dirty(abs_path) if is_git else False
        states.append(state)
    return states


def gather_dependencies(ws: WorkspaceConfig) -> list[str]:
    """Gather dependency strings from workspace config."""
    raw = {n: p.to_dict() for n, p in ws.projects.items()}
    return format_dependencies(raw)



def pull_project(
    name: str, abs_path: Path, rebase: bool = False,
) -> dict[str, Any]:
    """Pull a single project, returning result dict."""
    if not abs_path.is_dir():
        return {"name": name, "status": "error", "message": "path not found"}

    if not (abs_path / ".git").exists():
        return {"name": name, "status": "error", "message": "not a git repo"}

    if git_is_dirty(abs_path):
        return {
            "name": name, "status": "skipped",
            "message": "uncommitted changes",
        }

    try:
        result = git_pull(abs_path, rebase=rebase)
    except (subprocess.SubprocessError, OSError) as e:
        return {"name": name, "status": "error", "message": str(e)}

    if result.returncode != 0:
        return {
            "name": name, "status": "error",
            "message": result.stderr.strip() or "pull failed",
        }

    stdout = result.stdout.strip()
    if "already up to date" in stdout.lower():
        return {"name": name, "status": "up_to_date", "message": stdout}

    return {"name": name, "status": "updated", "message": stdout}


def print_pull_output(results: list[dict[str, Any]]) -> None:
    """Print pull results in Rich formatted output."""
    console.print("\n[bold]Pulling workspace projects...[/bold]\n")

    updated = 0
    skipped = 0
    errors = 0

    for r in results:
        name = r["name"]
        status = r["status"]
        msg = r.get("message", "")

        if status == "up_to_date":
            console.print(f"  {name}: [green]Already up to date[/green]")
            updated += 1
        elif status == "updated":
            console.print(f"  {name}: [green]Pulled[/green] — {msg}")
            updated += 1
        elif status == "skipped":
            console.print(f"  {name}: [yellow]Skipped[/yellow] — {msg}")
            skipped += 1
        else:
            console.print(f"  {name}: [red]Error[/red] — {msg}")
            errors += 1

    console.print(f"\nSummary: {updated} updated, {skipped} skipped, {errors} errors")
    console.print()


def print_agent_teams_output(teams: list[AgentTeamInfo]) -> None:
    """Print agent team information if any teams detected."""
    if not teams:
        return
    console.print("\n[bold]Agent Teams:[/bold]")
    for team in teams:
        status = "[green]active[/green]" if team.is_active else "[dim]inactive[/dim]"
        console.print(f"  [bold]{team.team_name}[/bold] — {team.agent_count} agents ({status})")
    console.print()
