"""DriverActivity query skill — recent driver session stats."""

from __future__ import annotations

from pathlib import Path

from bpsai_pair.query_skills import register_skill, safe_limit


class DriverActivitySkill:
    """Summarizes recent driver agent sessions."""

    def __init__(
        self, db_path: Path | None = None, fallback_dir: Path | None = None,
        **_kw,
    ) -> None:
        self._db_path = db_path
        self._fallback_dir = fallback_dir

    def execute(self, request: dict | None = None) -> dict:
        empty = {
            "sessions": 0, "total_duration_s": 0,
            "tasks_touched": [], "avg_tests_passed": 0.0,
        }
        sessions = self._load_sessions(request)
        drivers = [s for s in sessions if s.agent_role == "driver"]
        if not drivers:
            return empty
        tasks: list[str] = []
        for s in drivers:
            tasks.extend(s.tasks_touched)
        total_tests = sum(s.tests_passed for s in drivers)
        return {
            "sessions": len(drivers),
            "total_duration_s": sum(s.duration_s for s in drivers),
            "tasks_touched": sorted(set(tasks)),
            "avg_tests_passed": round(total_tests / len(drivers), 1),
        }

    def _load_sessions(self, request: dict | None = None):
        limit = safe_limit(request)
        try:
            from bpsai_pair.telemetry.session_store import SessionStore
            if self._db_path and self._db_path.exists():
                return SessionStore(self._db_path, self._fallback_dir).query_recent(limit)
        except ImportError:
            pass
        return []


register_skill("driver_activity", DriverActivitySkill)