"""QualityMetrics query skill — test pass rate and token stats."""

from __future__ import annotations

from pathlib import Path

from bpsai_pair.query_skills import register_skill, safe_limit


class QualityMetricsSkill:
    """Combines telemetry stats and session data for quality indicators."""

    def __init__(
        self, db_path: Path | None = None, fallback_dir: Path | None = None,
        **_kw,
    ) -> None:
        self._db_path = db_path
        self._fallback_dir = fallback_dir

    def execute(self, request: dict | None = None) -> dict:
        empty = {
            "test_pass_rate": 0.0, "avg_tokens_per_task": 0.0,
            "success_rate": 0.0, "sample_count": 0,
        }
        sessions = self._load_sessions(request)
        stats = self._load_telemetry_stats()
        if not sessions:
            return empty
        total_run = sum(s.tests_run for s in sessions)
        total_passed = sum(s.tests_passed for s in sessions)
        successes = sum(1 for s in sessions if s.outcome == "success")
        pass_rate = (total_passed / total_run * 100) if total_run > 0 else 0.0
        avg_tokens = stats.get("avg_tokens_per_task", 0.0)
        return {
            "test_pass_rate": round(pass_rate, 1),
            "avg_tokens_per_task": round(avg_tokens, 1),
            "success_rate": round(successes / len(sessions) * 100, 1),
            "sample_count": len(sessions),
        }

    def _load_sessions(self, request: dict | None = None):
        limit = safe_limit(request, default=20)
        try:
            from bpsai_pair.telemetry.session_store import SessionStore
            if self._db_path and self._db_path.exists():
                return SessionStore(self._db_path, self._fallback_dir).query_recent(limit)
        except ImportError:
            pass
        return []

    def _load_telemetry_stats(self) -> dict:
        try:
            from bpsai_pair.telemetry.sqlite_telemetry_store import SQLiteTelemetryStore
            if self._db_path and self._db_path.exists():
                stats = SQLiteTelemetryStore(self._db_path).get_stats()
                total = stats.get("total_records", 0)
                tokens = stats.get("total_tokens", 0)
                avg = (tokens / total) if total > 0 else 0.0
                return {"avg_tokens_per_task": avg}
        except ImportError:
            pass
        except Exception:
            pass
        return {}


register_skill("quality_metrics", QualityMetricsSkill)