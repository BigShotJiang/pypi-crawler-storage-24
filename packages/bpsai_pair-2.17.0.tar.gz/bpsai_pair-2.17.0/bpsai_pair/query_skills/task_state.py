"""TaskState query skill — task state transition history from SQLite."""

from __future__ import annotations

from pathlib import Path

from bpsai_pair.query_skills import register_skill, safe_limit


class TaskStateSkill:
    """Queries task state transitions from TaskStateIndex."""

    def __init__(
        self, db_path: Path | None = None, **_kw,
    ) -> None:
        self._db_path = db_path

    def execute(self, request: dict | None = None) -> dict:
        empty = {"transitions": [], "incomplete": []}
        if not self._db_path:
            return empty

        try:
            from bpsai_pair.telemetry.task_state_index import TaskStateIndex

            idx = TaskStateIndex(self._db_path)
            req = request or {}
            limit = safe_limit(request, default=50)
            transitions = idx.query_transitions(
                task_id=req.get("task_id"),
                plan_id=req.get("plan_id"),
                new_state=req.get("new_state"),
                limit=limit,
            )
            incomplete = idx.query_incomplete_tasks()
            return {
                "transitions": transitions,
                "incomplete": incomplete,
            }
        except Exception:
            return empty


register_skill("task_state", TaskStateSkill)
