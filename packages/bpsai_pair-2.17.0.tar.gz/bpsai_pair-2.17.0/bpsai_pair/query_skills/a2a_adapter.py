"""A2A adapter for CLI query skills.

Converts flat dict output from CLI query skill stubs into
framework-schema-conformant dicts for A2A transport.
"""

from __future__ import annotations

import json
from enum import Enum
from typing import Any


class QueryCategory(str, Enum):
    """Categories matching the 5 framework query result schemas."""

    SPRINT_STATUS = "sprint_status"
    DRIVER_ACTIVITY = "driver_activity"
    REVIEW_FINDINGS = "review_findings"
    QUALITY_METRICS = "quality_metrics"
    SESSION_OUTCOMES = "session_outcomes"


def adapt_result(category: str | QueryCategory, raw: dict[str, Any]) -> dict[str, Any]:
    """Convert a CLI skill's flat dict to framework result schema."""
    key = category.value if isinstance(category, QueryCategory) else category
    adapter = _ADAPTERS.get(key)
    if adapter:
        return adapter(raw)
    return raw


def format_a2a(category: str | QueryCategory, raw: dict[str, Any]) -> str:
    """Convert and serialize to JSON string for --format a2a output."""
    adapted = adapt_result(category, raw)
    return json.dumps(adapted, indent=2, default=str)


# --- Adapter functions (one per framework result schema) ---


def _adapt_sprint_status(raw: dict[str, Any]) -> dict[str, Any]:
    done = raw.get("tasks_done", 0)
    in_progress = raw.get("tasks_in_progress", 0)
    blocked = raw.get("tasks_blocked", 0)
    pending = raw.get("tasks_pending", 0)
    total = done + in_progress + blocked + pending
    pct = round((done / total * 100), 1) if total > 0 else 0.0
    return {
        "sprint_id": raw.get("sprint", 0),
        "title": raw.get("title", ""),
        "task_total": total,
        "task_done": done,
        "completion_pct": pct,
        "blockers": blocked,
        "test_count": raw.get("test_count", 0),
        "test_delta": raw.get("test_delta", 0),
        "metadata": {"total_complexity": raw.get("total_complexity", 0)},
    }


def _adapt_driver_activity(raw: dict[str, Any]) -> dict[str, Any]:
    return {
        "active_drivers": [
            {
                "sessions": raw.get("sessions", 0),
                "avg_tests_passed": raw.get("avg_tests_passed", 0),
            }
        ],
        "in_progress_tasks": raw.get("tasks_touched", []),
        "estimated_completion": None,
        "metadata": {"total_duration_s": raw.get("total_duration_s", 0)},
    }


def _adapt_review_findings(raw: dict[str, Any]) -> dict[str, Any]:
    categories = raw.get("error_categories", {})
    return {
        "total_findings": raw.get("total_errors", 0),
        "by_severity": dict(categories) if categories else {},
        "files_flagged": [],
        "metadata": {
            "reviews": raw.get("reviews", 0),
            "enforcement_overrides": raw.get("enforcement_overrides", 0),
        },
    }


def _adapt_quality_metrics(raw: dict[str, Any]) -> dict[str, Any]:
    return {
        "test_to_code_ratio": 0.0,
        "arch_violations": 0,
        "enforcement_override_rate": 100.0 - raw.get("success_rate", 100.0),
        "file_size_violations": 0,
        "metadata": {
            "test_pass_rate": raw.get("test_pass_rate", 0),
            "avg_tokens_per_task": raw.get("avg_tokens_per_task", 0),
            "sample_count": raw.get("sample_count", 0),
        },
    }


def _adapt_session_outcomes(raw: dict[str, Any]) -> dict[str, Any]:
    outcomes = raw.get("outcomes", {})
    sessions = [{"outcome": k, "count": v} for k, v in outcomes.items()]
    return {
        "sessions": sessions,
        "total_available": raw.get("total_sessions", 0),
        "metadata": {"avg_duration_s": raw.get("avg_duration_s", 0)},
    }


_ADAPTERS: dict[str, Any] = {
    "sprint_status": _adapt_sprint_status,
    "driver_activity": _adapt_driver_activity,
    "review_findings": _adapt_review_findings,
    "quality_metrics": _adapt_quality_metrics,
    "session_outcomes": _adapt_session_outcomes,
}
