"""Statistical helper functions for calibration calculations.

Provides mean, standard deviation, percentile, model recommendation,
and Welford's online algorithm helpers used by the CalibrationEngine.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from bpsai_pair.feedback.schema import TaskTypeStats

# Model recommendation thresholds (average total tokens)
HAIKU_THRESHOLD = 20_000
SONNET_THRESHOLD = 60_000

# Normal distribution z-score for 80th percentile
_P80_Z = 0.842


def mean(values: list[float]) -> float:
    """Calculate arithmetic mean."""
    if not values:
        return 0.0
    return sum(values) / len(values)


def std_dev(values: list[float]) -> float:
    """Calculate population standard deviation."""
    if len(values) < 2:
        return 0.0
    avg = mean(values)
    variance = sum((x - avg) ** 2 for x in values) / len(values)
    return math.sqrt(variance)


def percentile(values: list[float], pct: int) -> float:
    """Calculate percentile using linear interpolation."""
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    k = (pct / 100.0) * (len(sorted_vals) - 1)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return sorted_vals[int(k)]
    return sorted_vals[f] * (c - k) + sorted_vals[c] * (k - f)


def recommend_model(avg_tokens: float) -> str:
    """Recommend model based on average token usage.

    - haiku: avg_tokens < 20K (simple docs/fixes)
    - sonnet: 20K-60K tokens (standard features)
    - opus: >60K tokens (complex refactors)
    """
    if avg_tokens < HAIKU_THRESHOLD:
        return "haiku"
    if avg_tokens < SONNET_THRESHOLD:
        return "sonnet"
    return "opus"


def welford_update(
    old_mean: float, old_m2: float, old_n: int, new_value: float
) -> tuple[float, float]:
    """Single-step Welford online mean/M2 update.

    Returns:
        (new_mean, new_m2) tuple.
    """
    n = old_n + 1
    delta = new_value - old_mean
    new_mean = old_mean + delta / n
    delta2 = new_value - new_mean
    new_m2 = old_m2 + delta * delta2
    return new_mean, new_m2


_LOW_EFFORT_TYPES = {"docs_page", "config", "schema"}
_MEDIUM_EFFORT_TYPES = {"cli_command", "test_suite"}


def effort_for_type(task_type: str) -> str:
    """Map task type to default effort level."""
    if task_type in _LOW_EFFORT_TYPES:
        return "low"
    if task_type in _MEDIUM_EFFORT_TYPES:
        return "medium"
    return "high"


def new_empty_stats(task_type: str) -> TaskTypeStats:
    """Create a zeroed-out TaskTypeStats for incremental seeding."""
    from bpsai_pair.feedback.schema import TaskTypeStats as _TTS

    return _TTS(
        task_type=task_type,
        sample_count=0,
        avg_tokens=0.0,
        std_dev=0.0,
        p80_tokens=0.0,
        avg_duration_seconds=0.0,
        success_rate=0.0,
        recommended_model="haiku",
        recommended_effort=effort_for_type(task_type),
    )


def compute_batch_stats(
    task_type: str, records: list
) -> TaskTypeStats:
    """Compute statistical summary for a group of telemetry records."""
    from bpsai_pair.feedback.schema import TaskTypeStats as _TTS
    from bpsai_pair.telemetry.schema import Outcome

    tokens = [float(r.tokens.total) for r in records]
    durations = [float(r.duration_seconds) for r in records]
    successes = sum(1 for r in records if r.outcome == Outcome.SUCCESS)

    avg_tok = mean(tokens)
    tok_sd = std_dev(tokens)
    dur_sd = std_dev(durations)
    n = len(records)

    # Seed Welford M2 accumulators for incremental continuity.
    # M2 = population_variance * n = std_dev^2 * n
    m2_tok = (tok_sd ** 2) * n if n > 1 else 0.0
    m2_dur = (dur_sd ** 2) * n if n > 1 else 0.0

    return _TTS(
        task_type=task_type,
        sample_count=n,
        avg_tokens=avg_tok,
        std_dev=tok_sd,
        p80_tokens=percentile(tokens, 80),
        avg_duration_seconds=mean(durations),
        success_rate=successes / n if records else 0.0,
        recommended_model=recommend_model(avg_tok),
        recommended_effort=effort_for_type(task_type),
        _m2_tokens=m2_tok,
        _m2_duration=m2_dur,
    )


def track_mape(stats: "TaskTypeStats", estimated_tokens: int | None, actual_total: int) -> None:
    """Track estimation MAPE when estimated_tokens is available.

    Mutates stats.estimation_mape and stats.estimation_sample_count
    using an online running average.
    """
    if estimated_tokens is not None and actual_total > 0:
        pct_error = abs(estimated_tokens - actual_total) / actual_total * 100
        n = stats.estimation_sample_count
        prev_mape = stats.estimation_mape or 0.0
        stats.estimation_sample_count = n + 1
        stats.estimation_mape = prev_mape + (pct_error - prev_mape) / (n + 1)


def build_incremental_stats(
    prev: TaskTypeStats, tokens: float, duration: float, is_success: bool
) -> TaskTypeStats:
    """Build updated TaskTypeStats from one new observation via Welford's.

    Args:
        prev: Previous stats (sample_count may be 0 for first record).
        tokens: Total tokens from the new record.
        duration: Duration seconds from the new record.
        is_success: Whether the new record was a success.

    Returns:
        New TaskTypeStats with updated running statistics.
    """
    from bpsai_pair.feedback.schema import TaskTypeStats as _TTS

    n = prev.sample_count + 1
    avg_tok, m2_tok = welford_update(
        prev.avg_tokens, prev._m2_tokens, prev.sample_count, tokens
    )
    avg_dur, m2_dur = welford_update(
        prev.avg_duration_seconds, prev._m2_duration, prev.sample_count, duration
    )
    tok_std = math.sqrt(m2_tok / n) if n > 1 else 0.0
    success_count = round(prev.success_rate * prev.sample_count)
    success_count += 1 if is_success else 0

    return _TTS(
        task_type=prev.task_type,
        sample_count=n,
        avg_tokens=avg_tok,
        std_dev=tok_std,
        p80_tokens=avg_tok + _P80_Z * tok_std,
        avg_duration_seconds=avg_dur,
        success_rate=success_count / n,
        recommended_model=recommend_model(avg_tok),
        recommended_effort=prev.recommended_effort,
        _m2_tokens=m2_tok,
        _m2_duration=m2_dur,
        estimation_mape=prev.estimation_mape,
        estimation_sample_count=prev.estimation_sample_count,
    )
