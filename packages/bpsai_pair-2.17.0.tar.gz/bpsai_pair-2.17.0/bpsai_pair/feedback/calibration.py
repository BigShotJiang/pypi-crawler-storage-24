"""Calibration engine for processing telemetry into actionable estimates.

Transforms raw telemetry records into statistical coefficients that
enable data-driven task sizing and model recommendations.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from bpsai_pair.feedback.schema import (
    CalibrationData,
    MAX_TELEMETRY_QUERY_LIMIT,
    TaskTypeStats,
)
from bpsai_pair.feedback.calibration_helpers import seed_from_aggregates
from bpsai_pair.feedback.stats import (
    build_incremental_stats,
    compute_batch_stats,
    effort_for_type,
    new_empty_stats,
    percentile,
    recommend_model,
    track_mape,
)
from bpsai_pair.telemetry.schema import MAX_TASK_TOKENS, Outcome, TelemetryRecord
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)

# Cache staleness threshold
_CACHE_MAX_AGE = timedelta(hours=24)

# Default estimates when no data exists
_DEFAULT_AVG_TOKENS = 30_000.0
_DEFAULT_STD_DEV = 10_000.0
_DEFAULT_P80_TOKENS = 40_000.0
_DEFAULT_AVG_DURATION_SECONDS = 2700.0
_DEFAULT_MODEL = "sonnet"


class CalibrationEngine:
    """Processes telemetry data into calibration estimates.

    Usage:
        engine = CalibrationEngine(project_root)
        engine.calibrate()
        estimate = engine.estimate_tokens("feature")
        # {"avg": 48200, "p80": 58000, "std_dev": 5000, "recommended_model": "sonnet"}
    """

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root
        self.store = TelemetryStore(project_root)
        self.cache_path = (
            project_root / ".paircoder" / "feedback" / "calibration.json"
        )
        self._calibration: CalibrationData | None = None

    def calibrate(self, min_samples: int = 1) -> CalibrationData:
        """Process all telemetry into calibration data.

        Blends raw records (recent) with aggregate records (historical).
        Aggregates seed task types not covered by raw data and contribute
        to the total record count.

        Args:
            min_samples: Minimum records per task type to include.

        Returns:
            CalibrationData with per-type statistics.
        """
        all_records = self.store.query(limit=MAX_TELEMETRY_QUERY_LIMIT)
        now = datetime.now(timezone.utc)

        # Filter outlier records (likely raw session totals from token unit mismatch)
        records = [r for r in all_records if r.tokens.total <= MAX_TASK_TOKENS]
        filtered_count = len(all_records) - len(records)
        if filtered_count:
            logger.info("Filtered %d outlier records (tokens > %d)", filtered_count, MAX_TASK_TOKENS)

        # Build stats from raw records
        task_types = _build_grouped_stats(records, min_samples) if records else {}

        # Seed from aggregates for types not covered by raw data
        aggregates = self.store.load_aggregates()
        agg_record_count = seed_from_aggregates(task_types, aggregates)

        total = len(records) + agg_record_count
        if total == 0:
            self._calibration = CalibrationData(
                task_types={}, last_calibrated=now, total_records=0
            )
            self._save_cache(self._calibration)
            return self._calibration

        self._calibration = CalibrationData(
            task_types=task_types,
            last_calibrated=now,
            total_records=total,
        )
        self._save_cache(self._calibration)
        return self._calibration

    def estimate_tokens(
        self, task_type: str, model: str | None = None,
    ) -> dict[str, Any]:
        """Get token estimates for a task type, optionally filtered by model.

        Args:
            task_type: The task type to estimate for.
            model: Optional model name. When given, looks up
                   "{task_type}:{model}" first, falling back to aggregate.

        Returns:
            Dict with avg, p80, std_dev, recommended_model.
        """
        stats = self._get_stats(task_type, model=model)
        return {
            "avg": stats.avg_tokens,
            "p80": stats.p80_tokens,
            "std_dev": stats.std_dev,
            "recommended_model": stats.recommended_model,
        }

    def estimate_duration(self, task_type: str) -> dict[str, Any]:
        """Get duration estimates for a task type.

        Returns:
            Dict with avg_minutes and p80_minutes.
        """
        stats = self._get_stats(task_type)
        records = self.store.query(task_type=task_type, limit=MAX_TELEMETRY_QUERY_LIMIT)
        durations = [float(r.duration_seconds) for r in records]

        if durations:
            p80_seconds = percentile(durations, 80)
        else:
            p80_seconds = stats.avg_duration_seconds * 1.3

        return {
            "avg_minutes": stats.avg_duration_seconds / 60.0,
            "p80_minutes": p80_seconds / 60.0,
        }

    def get_model_recommendation(
        self, task_type: str, complexity: str = "medium"
    ) -> str:
        """Get recommended model based on task type and complexity.

        Returns:
            Model name: "haiku", "sonnet", or "opus".
        """
        return self._get_stats(task_type).recommended_model

    def estimate_effort(
        self, task_type: str, complexity: int | None = None
    ) -> str:
        """Get recommended effort level for a task type.

        Uses complexity override if provided, otherwise maps by task type.

        Args:
            task_type: The type of task.
            complexity: Optional complexity score (0-100).

        Returns:
            Effort string: "low", "medium", or "high".
        """
        if complexity is not None:
            if complexity < 20:
                return "low"
            if complexity <= 40:
                return "medium"
            return "high"
        return effort_for_type(task_type)

    def check_budget_fit(
        self, estimated_tokens: int, target_utilization: float = 0.8
    ) -> dict[str, Any]:
        """Check if estimated tokens fit within budget target.

        Args:
            estimated_tokens: Estimated token count for the task.
            target_utilization: Budget utilization target (0.0-1.0).

        Returns:
            Dict with fits_budget bool and utilization float.
        """
        cal = self.get_calibration()
        if cal.total_records == 0:
            budget = 200_000
        else:
            all_tokens = [s.avg_tokens for s in cal.task_types.values()]
            budget = max(all_tokens) * 3 if all_tokens else 200_000

        effective_budget = budget * target_utilization
        utilization = estimated_tokens / budget if budget > 0 else 0.0

        return {
            "fits_budget": estimated_tokens <= effective_budget,
            "utilization": round(utilization, 3),
            "budget": budget,
            "effective_budget": effective_budget,
        }

    def update_incremental(self, record: TelemetryRecord) -> TaskTypeStats:
        """Update calibration for one record using Welford's algorithm.

        O(1) per call — no batch re-read of telemetry required.
        Updates both the aggregate "{task_type}" and per-model
        "{task_type}:{model}" entries.

        Args:
            record: The new telemetry record to incorporate.

        Returns:
            Updated TaskTypeStats for the record's task type (aggregate).
        """
        cal = self.get_calibration()
        tokens = float(record.tokens.total)
        duration = float(record.duration_seconds)
        is_success = record.outcome == Outcome.SUCCESS

        # Update aggregate entry
        prev = cal.task_types.get(record.task_type)
        if prev is None:
            prev = new_empty_stats(record.task_type)
        stats = build_incremental_stats(prev, tokens, duration, is_success)
        track_mape(stats, record.estimated_tokens, record.tokens.total)
        cal.task_types[record.task_type] = stats

        # Update per-model entry
        model_key = f"{record.task_type}:{record.model}"
        prev_model = cal.task_types.get(model_key)
        if prev_model is None:
            prev_model = new_empty_stats(record.task_type)
        model_stats = build_incremental_stats(prev_model, tokens, duration, is_success)
        model_stats.model = record.model
        track_mape(model_stats, record.estimated_tokens, record.tokens.total)
        cal.task_types[model_key] = model_stats

        cal.total_records += 1
        cal.last_calibrated = datetime.now(timezone.utc)
        self._calibration = cal
        self._save_cache(cal)
        return stats

    # -- Cache management --

    def _save_cache(self, data: CalibrationData) -> None:
        """Save calibration data to JSON cache."""
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text(
            json.dumps(data.to_dict(), indent=2), encoding="utf-8"
        )

    def _load_cache(self) -> CalibrationData | None:
        """Load calibration data from JSON cache."""
        if not self.cache_path.exists():
            return None
        try:
            raw = json.loads(self.cache_path.read_text(encoding="utf-8"))
            return CalibrationData.from_dict(raw)
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            logger.debug("Failed to load calibration cache: %s", e)
            return None

    def is_cache_stale(self) -> bool:
        """Check if cache is stale (>24h old or missing)."""
        cached = self._load_cache()
        if cached is None:
            return True
        age = datetime.now(timezone.utc) - cached.last_calibrated
        return age > _CACHE_MAX_AGE

    # -- Internal helpers --

    @property
    def is_calibrated(self) -> bool:
        """Check if calibration data is available (in memory or cache)."""
        if self._calibration is not None:
            return True
        return self._load_cache() is not None

    def get_calibration(self) -> CalibrationData:
        """Get current calibration, loading from cache if needed."""
        if self._calibration is not None:
            return self._calibration
        cached = self._load_cache()
        if cached is not None:
            self._calibration = cached
            return cached
        return self.calibrate()

    def _get_stats(
        self, task_type: str, model: str | None = None,
    ) -> TaskTypeStats:
        """Get stats for a task type, returning defaults if missing.

        When model is given, looks up "{task_type}:{model}" first,
        falling back to the aggregate "{task_type}" key.
        """
        cal = self.get_calibration()
        if model is not None:
            key = f"{task_type}:{model}"
            if key in cal.task_types:
                return cal.task_types[key]
        if task_type in cal.task_types:
            return cal.task_types[task_type]
        return TaskTypeStats(
            task_type=task_type,
            sample_count=0,
            avg_tokens=_DEFAULT_AVG_TOKENS,
            std_dev=_DEFAULT_STD_DEV,
            p80_tokens=_DEFAULT_P80_TOKENS,
            avg_duration_seconds=_DEFAULT_AVG_DURATION_SECONDS,
            success_rate=0.0,
            recommended_model=_DEFAULT_MODEL,
        )


def _build_grouped_stats(
    records: list[TelemetryRecord],
    min_samples: int,
) -> dict[str, TaskTypeStats]:
    """Group records by task_type (aggregate) and (task_type, model)."""
    agg_groups: dict[str, list[TelemetryRecord]] = {}
    model_groups: dict[str, list[TelemetryRecord]] = {}
    for r in records:
        agg_groups.setdefault(r.task_type, []).append(r)
        model_groups.setdefault(f"{r.task_type}:{r.model}", []).append(r)

    result: dict[str, TaskTypeStats] = {}
    for task_type, group in agg_groups.items():
        if len(group) >= min_samples:
            result[task_type] = compute_batch_stats(task_type, group)
    for key, group in model_groups.items():
        if len(group) >= min_samples:
            task_type, model = key.split(":", 1)
            stats = compute_batch_stats(task_type, group)
            stats.model = model
            result[key] = stats
    return result
