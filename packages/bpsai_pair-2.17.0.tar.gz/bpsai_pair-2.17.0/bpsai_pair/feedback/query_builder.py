"""Composable QueryBuilder for structured state queries (SIG-008)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from bpsai_pair.feedback.state_query import StateQuery
from bpsai_pair.planning.task_parser import TaskParser


_VALID_METRICS = {"estimation_accuracy", "success_rate", "agent_performance"}
_VALID_STATE = {"active-tasks", "current-plan"}
_VALID_TASK_STATUSES = {"pending", "in_progress", "done", "blocked", "ready", "review"}

_ACCEPTED_FILTERS: dict[str, set[str]] = {
    "metrics": {"task_type"},
    "tasks": {"status"},
    "state": set(),
    "task_state": {"task_id", "plan_id", "new_state", "scope"},
}


class QueryBuilder:
    """Composable query interface with category routing."""

    def __init__(self, project_root: Path) -> None:
        self._root = project_root
        self._category: str = ""
        self._metric: str = ""
        self._state_key: str = ""
        self._filters: dict[str, Any] = {}

    def metrics(self, metric_name: str) -> QueryBuilder:
        """Select metrics category with a specific metric."""
        self._category = "metrics"
        self._metric = metric_name
        return self

    def state(self, key: str) -> QueryBuilder:
        """Select state category with a specific state key."""
        self._category = "state"
        self._state_key = key
        return self

    def tasks(self) -> QueryBuilder:
        """Select tasks category."""
        self._category = "tasks"
        return self

    def task_state(self) -> QueryBuilder:
        """Select task_state category for transition history."""
        self._category = "task_state"
        return self

    def where(self, **kwargs: Any) -> QueryBuilder:
        """Add filter conditions."""
        self._filters.update(kwargs)
        return self

    def execute(self) -> dict[str, Any]:
        """Execute the query and return structured results."""
        if not self._category:
            raise ValueError("No category selected")
        self._validate_filters()
        if self._category == "metrics":
            return self._execute_metrics()
        if self._category == "state":
            return self._execute_state()
        if self._category == "tasks":
            return self._execute_tasks()
        if self._category == "task_state":
            return self._execute_task_state()
        raise ValueError(f"Unknown category: {self._category}")

    def _validate_filters(self) -> None:
        """Validate filter keys are accepted for the current category."""
        accepted = _ACCEPTED_FILTERS.get(self._category, set())
        invalid = set(self._filters.keys()) - accepted
        if invalid:
            raise ValueError(
                f"Unsupported filter(s) for {self._category}: {sorted(invalid)}"
            )

    def _execute_metrics(self) -> dict[str, Any]:
        if self._metric not in _VALID_METRICS:
            raise ValueError(f"Unknown metric: {self._metric}")

        sq = StateQuery(self._root)
        task_type = self._filters.get("task_type")

        if self._metric == "estimation_accuracy":
            data = sq.estimation_accuracy(task_type=task_type)
            return {"category": "metrics", "metric": self._metric, **data}

        if self._metric == "success_rate":
            if task_type:
                rate = sq.success_rate_for(task_type)
            else:
                rate = self._aggregate_success_rate(sq)
            return {"category": "metrics", "metric": self._metric, "rate": rate}

        if self._metric == "agent_performance":
            data = sq.agent_performance_by_role()
            return {"category": "metrics", "metric": self._metric, "models": data}

        raise ValueError(f"Unknown metric: {self._metric}")

    def _execute_state(self) -> dict[str, Any]:
        if self._state_key not in _VALID_STATE:
            raise ValueError(f"Unknown state key: {self._state_key}")

        if self._state_key == "active-tasks":
            tasks = self._read_active_tasks()
            return {"category": "state", "key": "active-tasks", "tasks": tasks}

        # self._state_key == "current-plan"
        plan = self._read_current_plan()
        return {"category": "state", "key": "current-plan", **plan}

    def _execute_tasks(self) -> dict[str, Any]:
        status_filter = self._filters.get("status")
        if status_filter and status_filter not in _VALID_TASK_STATUSES:
            raise ValueError(
                f"Invalid status filter '{status_filter}'. "
                f"Valid statuses: {sorted(_VALID_TASK_STATUSES)}"
            )

        tasks_dir = self._root / ".paircoder" / "tasks"
        items: list[dict[str, Any]] = []

        if tasks_dir.exists():
            parser = TaskParser(tasks_dir)
            for task_path in parser.list_tasks():
                task = parser.parse_task(task_path)
                if task and self._task_matches_filters(task):
                    items.append({
                        "id": task.id,
                        "title": task.title,
                        "status": task.status,
                    })

        return {"category": "tasks", "items": items}

    def _execute_task_state(self) -> dict[str, Any]:
        """Query task state transitions from SQLite index."""
        scope = self._filters.get("scope", "local")
        if scope == "workspace":
            return self._execute_task_state_workspace()
        return self._execute_task_state_local()

    def _execute_task_state_local(self) -> dict[str, Any]:
        """Query transitions from the current repo's store."""
        try:
            from bpsai_pair.telemetry.task_state_index import TaskStateIndex

            db_path = self._root / ".paircoder" / "data" / "store.db"
            idx = TaskStateIndex(db_path, read_only=True)
            transitions = idx.query_transitions(
                task_id=self._filters.get("task_id"),
                plan_id=self._filters.get("plan_id"),
                new_state=self._filters.get("new_state"),
            )
        except Exception:
            transitions = []

        return {"category": "task_state", "transitions": transitions}

    def _execute_task_state_workspace(self) -> dict[str, Any]:
        """Query transitions across sibling repos in the workspace."""
        from bpsai_pair.feedback.workspace_query import query_workspace_task_state

        transitions = query_workspace_task_state(
            self._root,
            task_id=self._filters.get("task_id"),
            plan_id=self._filters.get("plan_id"),
            new_state=self._filters.get("new_state"),
        )
        return {"category": "task_state", "transitions": transitions}

    def _task_matches_filters(self, task: Any) -> bool:
        status_filter = self._filters.get("status")
        if status_filter and task.status != status_filter:
            return False
        return True

    def _aggregate_success_rate(self, sq: StateQuery) -> float:
        """Compute aggregate success rate across all task types."""
        cal = sq.engine.get_calibration()
        if not cal.task_types:
            return 0.0
        total_tasks = 0
        total_successes = 0.0
        for tt in cal.task_types.values():
            total_tasks += tt.sample_count
            total_successes += tt.success_rate * tt.sample_count
        if total_tasks == 0:
            return 0.0
        return total_successes / total_tasks

    def _read_active_tasks(self) -> list[dict[str, Any]]:
        tasks_dir = self._root / ".paircoder" / "tasks"
        if not tasks_dir.exists():
            return []
        parser = TaskParser(tasks_dir)
        result = []
        for task_path in parser.list_tasks():
            task = parser.parse_task(task_path)
            if task and task.status == "in_progress":
                result.append({"id": task.id, "title": task.title})
        return result

    def _read_current_plan(self) -> dict[str, Any]:
        plans_dir = self._root / ".paircoder" / "plans"
        if not plans_dir.exists():
            return {"plan_id": None}
        plan_files = sorted(plans_dir.glob("*.plan.yaml"), reverse=True)
        if not plan_files:
            return {"plan_id": None}
        best = _select_best_plan(plan_files)
        return {
            "plan_id": best.get("id"),
            "title": best.get("title"),
            "status": best.get("status"),
        }


def _select_best_plan(plan_files: list[Path]) -> dict[str, Any]:
    """Select the best plan by semantic status priority.

    Priority: in_progress > planned > most recent by filename.
    """
    plans: list[dict[str, Any]] = []
    for pf in plan_files:
        with open(pf, encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        plans.append(data)

    # Priority order for status
    for target_status in ("in_progress", "planned"):
        for plan in plans:
            if plan.get("status") == target_status:
                return plan

    # Fallback: first in list (already sorted reverse by filename)
    return plans[0] if plans else {}
