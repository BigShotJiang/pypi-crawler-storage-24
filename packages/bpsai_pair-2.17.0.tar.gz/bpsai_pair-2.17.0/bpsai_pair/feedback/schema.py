"""Data structures for calibration results.

Defines the schema for task type statistics and calibration data
produced by the CalibrationEngine.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


# Maximum number of telemetry records to query in a single batch
MAX_TELEMETRY_QUERY_LIMIT: int = 10_000


class EffortLevel(Enum):
    """Effort levels mapping to Claude API effort parameter."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class TaskTypeStats:
    """Statistical summary for a single task type."""

    task_type: str
    sample_count: int
    avg_tokens: float
    std_dev: float
    p80_tokens: float
    avg_duration_seconds: float
    success_rate: float
    recommended_model: str
    model: str = field(default="aggregate")
    recommended_effort: str = field(default="high")
    _m2_tokens: float = field(default=0.0)
    _m2_duration: float = field(default=0.0)
    estimation_mape: float | None = field(default=None)
    estimation_sample_count: int = field(default=0)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "task_type": self.task_type,
            "sample_count": self.sample_count,
            "avg_tokens": self.avg_tokens,
            "std_dev": self.std_dev,
            "p80_tokens": self.p80_tokens,
            "avg_duration_seconds": self.avg_duration_seconds,
            "success_rate": self.success_rate,
            "recommended_model": self.recommended_model,
            "model": self.model,
            "recommended_effort": self.recommended_effort,
            "_m2_tokens": self._m2_tokens,
            "_m2_duration": self._m2_duration,
            "estimation_mape": self.estimation_mape,
            "estimation_sample_count": self.estimation_sample_count,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaskTypeStats:
        """Deserialize from dictionary."""
        return cls(
            task_type=data["task_type"],
            sample_count=data["sample_count"],
            avg_tokens=data["avg_tokens"],
            std_dev=data["std_dev"],
            p80_tokens=data["p80_tokens"],
            avg_duration_seconds=data["avg_duration_seconds"],
            success_rate=data["success_rate"],
            recommended_model=data["recommended_model"],
            model=data.get("model", "aggregate"),
            recommended_effort=data.get("recommended_effort", "high"),
            _m2_tokens=data.get("_m2_tokens", 0.0),
            _m2_duration=data.get("_m2_duration", 0.0),
            estimation_mape=data.get("estimation_mape"),
            estimation_sample_count=data.get("estimation_sample_count", 0),
        )


@dataclass
class CalibrationData:
    """Complete calibration results from telemetry processing."""

    task_types: dict[str, TaskTypeStats]
    last_calibrated: datetime
    total_records: int

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "task_types": {
                k: v.to_dict() for k, v in self.task_types.items()
            },
            "last_calibrated": self.last_calibrated.isoformat(),
            "total_records": self.total_records,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CalibrationData:
        """Deserialize from dictionary."""
        from datetime import timezone

        last_calibrated = data.get("last_calibrated")
        if isinstance(last_calibrated, str):
            last_calibrated = datetime.fromisoformat(last_calibrated)
        elif last_calibrated is None:
            last_calibrated = datetime.now(timezone.utc)

        # Skip non-TaskTypeStats keys (e.g. "version", "global" from old schema)
        task_types = {}
        for k, v in data.get("task_types", {}).items():
            if isinstance(v, dict) and "task_type" in v:
                task_types[k] = TaskTypeStats.from_dict(v)

        return cls(
            task_types=task_types,
            last_calibrated=last_calibrated,
            total_records=data.get("total_records", 0),
        )
