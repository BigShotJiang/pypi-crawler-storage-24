"""QC telemetry store — SQLite persistence for historical QC trends."""

from __future__ import annotations

import json
import os
import sqlite3
import stat
from pathlib import Path
from typing import Any

from .results import QCRunResult

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS qc_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    suite_name TEXT NOT NULL,
    environment TEXT NOT NULL DEFAULT '',
    timestamp TEXT NOT NULL,
    pass_rate REAL NOT NULL,
    duration_s REAL NOT NULL DEFAULT 0.0,
    total_scenarios INTEGER NOT NULL DEFAULT 0,
    passed INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0,
    skipped INTEGER NOT NULL DEFAULT 0,
    error INTEGER NOT NULL DEFAULT 0,
    scenario_results TEXT NOT NULL DEFAULT '[]'
)
"""

_CREATE_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_qc_runs_suite ON qc_runs(suite_name)",
    "CREATE INDEX IF NOT EXISTS idx_qc_runs_timestamp ON qc_runs(timestamp)",
]


_MAX_QUERY_LIMIT = 1000  # Store-level cap
_MAX_SCENARIO_JSON_SIZE = 65536  # 64KB


class QCTelemetryStore:
    """SQLite-backed store for QC run history."""

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        created = not self._db_path.exists()
        with sqlite3.connect(str(self._db_path)) as conn:
            conn.execute(_CREATE_TABLE)
            for idx in _CREATE_INDEXES:
                conn.execute(idx)
            conn.commit()
        if created and os.name != "nt":
            self._db_path.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0o600

    def record(self, result: QCRunResult) -> None:
        """Persist a QC run result to SQLite."""
        s = result.summary()
        dur = sum(st.duration_s for sc in result.scenarios for st in sc.steps)
        sc_json = json.dumps(
            [{"name": sc.name, "verdict": sc.verdict.value} for sc in result.scenarios]
        )
        with sqlite3.connect(str(self._db_path)) as conn:
            conn.execute(
                """INSERT INTO qc_runs
                   (suite_name, environment, timestamp, pass_rate, duration_s,
                    total_scenarios, passed, failed, skipped, error, scenario_results)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (result.suite_name, result.environment, result.timestamp,
                 s["pass_rate"], dur, s["total"], s["passed"],
                 s["failed"], s["skipped"], s["error"], sc_json),
            )
            conn.commit()

    def query_trends(
        self,
        suite: str | None = None,
        environment: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Query historical QC trends."""
        limit = max(1, min(limit, _MAX_QUERY_LIMIT))
        query = (
            "SELECT id, suite_name, environment, timestamp, pass_rate, "
            "duration_s, total_scenarios, passed, failed, skipped, error, "
            "scenario_results FROM qc_runs"
        )
        params: list[Any] = []
        conditions: list[str] = []
        if suite:
            conditions.append("suite_name = ?")
            params.append(suite)
        if environment:
            conditions.append("environment = ?")
            params.append(environment)
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        with sqlite3.connect(str(self._db_path)) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]

    def detect_flaky(
        self,
        suite: str | None = None,
        min_runs: int = 3,
    ) -> list[dict[str, Any]]:
        """Detect flaky scenarios that flip between pass/fail."""
        runs = self.query_trends(suite=suite, limit=100)
        if len(runs) < min_runs:
            return []
        history: dict[str, list[str]] = {}
        for run in runs:
            sc_json = run.get("scenario_results", "[]")
            if len(sc_json) > _MAX_SCENARIO_JSON_SIZE:
                continue
            try:
                scenarios = json.loads(sc_json)
            except (json.JSONDecodeError, TypeError):
                continue
            for sc in scenarios:
                name = sc.get("name", "")
                verdict = sc.get("verdict", "")
                if name:
                    history.setdefault(name, []).append(verdict)
        flaky: list[dict[str, Any]] = []
        for name, verdicts in history.items():
            unique = set(verdicts)
            if "passed" in unique and ("failed" in unique or "error" in unique):
                flip_count = sum(
                    1 for i in range(1, len(verdicts)) if verdicts[i] != verdicts[i - 1]
                )
                flaky.append(
                    {"scenario": name, "verdicts": verdicts[:10], "flip_count": flip_count}
                )
        return sorted(flaky, key=lambda x: x["flip_count"], reverse=True)
