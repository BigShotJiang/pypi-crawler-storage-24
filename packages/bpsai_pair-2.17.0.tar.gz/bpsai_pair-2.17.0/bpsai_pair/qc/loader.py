"""YAML loader for QC suite specs.

Parses .qa.yaml files into model instances with validation
and ${VAR} variable interpolation.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import yaml

from .models import (
    QCScenario, QCStep, QCStepType, QCSuite,
    QCValidationError, QCUnresolvedVariableError,
    VAR_PATTERN,
)

_VAR_RE = VAR_PATTERN
_VALID_STEP_KEYS = {t.value for t in QCStepType}


def load_suite(
    path: Path, env_vars: Optional[dict[str, str]] = None,
) -> QCSuite:
    """Load and validate a QC suite from a .qa.yaml file."""
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    _validate_suite_data(data, path)

    # Interpolate variables throughout the data structure
    if env_vars is not None:
        data = _interpolate(data, env_vars)

    # Check for unresolved variables only when env was provided
    if env_vars is not None:
        _check_unresolved(data, path)

    return _build_suite(data)


def _validate_suite_data(data: dict, path: Path) -> None:
    """Validate required fields."""
    if not data.get("name"):
        raise QCValidationError(f"{path.name}: missing required field 'name'")
    if "scenarios" not in data or data["scenarios"] is None:
        raise QCValidationError(f"{path.name}: missing required field 'scenarios'")


def _interpolate(data: Any, env_vars: dict[str, str]) -> Any:
    """Recursively replace ${VAR} patterns in strings."""
    if isinstance(data, str):
        return _VAR_RE.sub(lambda m: env_vars.get(m.group(1), m.group(0)), data)
    if isinstance(data, list):
        return [_interpolate(item, env_vars) for item in data]
    if isinstance(data, dict):
        return {k: _interpolate(v, env_vars) for k, v in data.items()}
    return data


def _check_unresolved(data: Any, path: Path) -> None:
    """Raise if any ${VAR} patterns remain after interpolation."""
    if isinstance(data, str):
        match = _VAR_RE.search(data)
        if match:
            raise QCUnresolvedVariableError(
                f"{path.name}: unresolved variable ${{{match.group(1)}}}"
            )
    elif isinstance(data, list):
        for item in data:
            _check_unresolved(item, path)
    elif isinstance(data, dict):
        for v in data.values():
            _check_unresolved(v, path)


def _build_suite(data: dict) -> QCSuite:
    """Build a QCSuite from validated, interpolated data."""
    scenarios = [_build_scenario(s) for s in (data.get("scenarios") or [])]
    return QCSuite(
        name=data["name"],
        description=data.get("description", ""),
        tags=data.get("tags", []),
        preconditions=data.get("preconditions", []),
        scenarios=scenarios,
    )


def _build_scenario(data: dict) -> QCScenario:
    """Build a QCScenario from a dict."""
    if not data.get("name"):
        raise QCValidationError("scenario missing required field 'name'")
    steps = [_build_step(s) for s in (data.get("steps") or [])]
    return QCScenario(name=data["name"], steps=steps, tags=data.get("tags", []))


def _build_step(data: Any) -> QCStep:
    """Build a QCStep from a YAML step entry.

    Steps come in two forms:
      - Simple: {navigate: "/login"} or {click: "Submit"}
      - Fill:   {fill: {field: "Email", value: "test@test.com"}}
    """
    if not isinstance(data, dict):
        raise QCValidationError(f"step must be a mapping, got {type(data).__name__}")

    # Find the step type key
    step_key = None
    for key in data:
        if key in _VALID_STEP_KEYS:
            step_key = key
            break

    if step_key is None:
        keys = ", ".join(data.keys())
        raise QCValidationError(
            f"unknown step type(s): {keys}. "
            f"Valid types: {', '.join(sorted(_VALID_STEP_KEYS))}"
        )

    step_type = QCStepType(step_key)
    value = data[step_key]

    if step_type == QCStepType.FILL and isinstance(value, dict):
        return QCStep(
            type=step_type,
            field=value.get("field", ""),
            value=value.get("value", ""),
        )

    return QCStep(type=step_type, target=str(value))
