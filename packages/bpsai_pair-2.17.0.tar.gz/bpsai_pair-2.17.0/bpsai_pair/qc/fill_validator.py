"""Fill step validation for QC test suites.

Handles different form element types (text, dropdown, checkbox, radio)
using the element discovery protocol. Respects read_only restrictions.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any

from .models import QCStep
from .results import QCVerdict

if TYPE_CHECKING:
    from .step_handlers import ChromeToolProvider

logger = logging.getLogger(__name__)


class FillFieldType(Enum):
    """Detected form field type."""

    TEXT = "text"
    DROPDOWN = "dropdown"
    CHECKBOX = "checkbox"
    RADIO = "radio"

    @classmethod
    def from_element(cls, element_info: dict[str, Any]) -> FillFieldType:
        """Detect field type from find result metadata."""
        tag = element_info.get("tag", "").lower()
        input_type = element_info.get("type", "").lower()

        if tag == "select":
            return cls.DROPDOWN
        if tag == "textarea":
            return cls.TEXT
        if tag == "input":
            if input_type == "checkbox":
                return cls.CHECKBOX
            if input_type == "radio":
                return cls.RADIO
        return cls.TEXT


@dataclass
class FillResult:
    """Result of a fill step validation."""

    verdict: QCVerdict
    observation: str
    field_type: FillFieldType = FillFieldType.TEXT
    duration_s: float = 0.0


def _discover_element(
    chrome: ChromeToolProvider, field_name: str,
) -> tuple[dict[str, Any] | None, str | None]:
    """Find an element by field name. Returns (element_info, error_msg)."""
    try:
        found = chrome.find(field_name)
        ref = found.get("ref")
        if not ref:
            return None, f"Element not found for field: {field_name}"
        return found, None
    except Exception as exc:
        return None, f"Error finding field '{field_name}': {exc}"


def _execute_fill(
    chrome: ChromeToolProvider,
    ref: str,
    value: str,
    field_name: str,
    field_type: FillFieldType,
) -> tuple[str | None, str | None]:
    """Execute the fill action. Returns (observation, error_msg)."""
    try:
        if field_type in (FillFieldType.CHECKBOX, FillFieldType.RADIO):
            # TODO(QC Phase 3): Check checkbox/radio current state before clicking
            # to avoid toggling -- clicking a checked checkbox unchecks it.
            chrome.click(ref=ref)
            return f"Clicked {field_type.value} '{field_name}'", None
        chrome.form_input(ref, value)
        return f"Filled {field_type.value} '{field_name}' with value", None
    except Exception as exc:
        return None, f"Error filling '{field_name}': {exc}"


def validate_fill_step(
    step: QCStep,
    chrome: ChromeToolProvider,
    read_only: bool = False,
) -> FillResult:
    """Validate and execute a fill step.

    Args:
        step: The fill step to execute.
        chrome: Chrome tool provider.
        read_only: If True, block fill and return SKIPPED.

    Returns:
        FillResult with verdict and observation.
    """
    start = time.monotonic()
    field_name = step.field or step.target
    value = step.value or ""

    if read_only:
        return FillResult(
            verdict=QCVerdict.SKIPPED,
            observation=f"Fill blocked: read_only environment ({field_name})",
            duration_s=time.monotonic() - start,
        )

    found, err = _discover_element(chrome, field_name)
    if err:
        verdict = QCVerdict.FAILED if "not found" in err else QCVerdict.ERROR
        return FillResult(
            verdict=verdict, observation=err,
            duration_s=time.monotonic() - start,
        )

    field_type = FillFieldType.from_element(found)  # type: ignore[arg-type]
    ref = found["ref"]  # type: ignore[index]

    observation, fill_err = _execute_fill(chrome, ref, value, field_name, field_type)
    if fill_err:
        return FillResult(
            verdict=QCVerdict.ERROR, observation=fill_err,
            field_type=field_type, duration_s=time.monotonic() - start,
        )

    return FillResult(
        verdict=QCVerdict.PASSED, observation=observation or "",
        field_type=field_type, duration_s=time.monotonic() - start,
    )
