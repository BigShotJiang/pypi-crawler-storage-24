"""QC Execution Runtime.

Bridges QC suite YAML specs with Chrome MCP tool calls.
The executor reads a suite, resolves environment config,
dispatches Chrome actions per step, and collects structured results.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Callable

from .config import QCEnvironment
from .models import QCScenario, QCStep, QCStepType, QCSuite
from .results import QCRunResult, QCScenarioResult, QCStepResult, QCVerdict
from .step_handlers import (
    ChromeToolProvider,
    execute_check_console,
    execute_click,
    execute_fill,
    execute_navigate,
    execute_verify,
    execute_wait,
)

logger = logging.getLogger(__name__)

# Re-export for public API
__all__ = ["ChromeToolProvider", "ExecutorConfig", "QCExecutor"]


@dataclass
class ExecutorConfig:
    """Runtime configuration for the executor."""

    post_navigate_delay: float = 2.0
    step_timeout: float = 30.0
    continue_on_failure: bool = True


class QCExecutor:
    """Executes QC suites against a Chrome browser via tool provider."""

    def __init__(
        self,
        chrome: ChromeToolProvider,
        environment: QCEnvironment,
        config: ExecutorConfig | None = None,
    ) -> None:
        self._chrome = chrome
        self._env = environment
        self._config = config or ExecutorConfig()
        self._step_handlers: dict[QCStepType, Callable[[QCStep], QCStepResult]] = {
            QCStepType.NAVIGATE: self._handle_navigate,
            QCStepType.VERIFY: self._handle_verify,
            QCStepType.CLICK: self._handle_click,
            QCStepType.FILL: self._handle_fill,
            QCStepType.CHECK_CONSOLE: self._handle_check_console,
            QCStepType.WAIT: self._handle_wait,
        }

    def run(self, suite: QCSuite, environment_name: str = "") -> QCRunResult:
        """Execute a full suite and return structured results."""
        scenarios = self._filter_scenarios(suite)
        scenario_results = [self._run_scenario(s) for s in scenarios]
        return QCRunResult(
            suite_name=suite.name,
            environment=environment_name,
            scenarios=scenario_results,
        )

    def _filter_scenarios(self, suite: QCSuite) -> list[QCScenario]:
        """Filter scenarios by skip_tags using per-scenario tags."""
        skip_tags = set(self._env.restrictions.skip_tags)
        if not skip_tags:
            return suite.scenarios
        return [
            s for s in suite.scenarios
            if not (skip_tags & set(s.tags))
        ]

    def _run_scenario(self, scenario: QCScenario) -> QCScenarioResult:
        """Execute all steps in a scenario."""
        step_results: list[QCStepResult] = []
        scenario_verdict = QCVerdict.PASSED
        failure_reason = ""

        for step in scenario.steps:
            result = self._execute_step(step)
            step_results.append(result)

            if result.verdict in (QCVerdict.FAILED, QCVerdict.ERROR):
                # Track worst verdict: ERROR > FAILED > PASSED
                if scenario_verdict == QCVerdict.PASSED or (
                    result.verdict == QCVerdict.ERROR
                    and scenario_verdict == QCVerdict.FAILED
                ):
                    scenario_verdict = result.verdict
                    failure_reason = result.observation

                if not self._config.continue_on_failure:
                    break

        return QCScenarioResult(
            name=scenario.name,
            verdict=scenario_verdict,
            steps=step_results,
            failure_reason=failure_reason,
        )

    def _execute_step(self, step: QCStep) -> QCStepResult:
        """Dispatch a single step to its handler."""
        handler = self._step_handlers.get(step.type)
        if not handler:
            return QCStepResult(
                step_description=f"{step.type.value}: {step.target}",
                verdict=QCVerdict.ERROR,
                observation=f"Unknown step type: {step.type.value}",
            )

        start = time.monotonic()
        try:
            result = handler(step)
            result.duration_s = time.monotonic() - start
            return result
        except Exception as e:
            return QCStepResult(
                step_description=f"{step.type.value}: {step.target}",
                verdict=QCVerdict.ERROR,
                observation=f"Step execution error: {e}",
                duration_s=time.monotonic() - start,
            )

    # -- Thin wrappers that delegate to step_handlers module --

    def _handle_navigate(self, step: QCStep) -> QCStepResult:
        return execute_navigate(self._chrome, step, self._config.post_navigate_delay)

    def _handle_verify(self, step: QCStep) -> QCStepResult:
        return execute_verify(self._chrome, step)

    def _handle_click(self, step: QCStep) -> QCStepResult:
        return execute_click(self._chrome, step)

    def _handle_fill(self, step: QCStep) -> QCStepResult:
        return execute_fill(self._chrome, step, self._env)

    def _handle_check_console(self, step: QCStep) -> QCStepResult:
        return execute_check_console(self._chrome, step)

    def _handle_wait(self, step: QCStep) -> QCStepResult:
        return execute_wait(step)
