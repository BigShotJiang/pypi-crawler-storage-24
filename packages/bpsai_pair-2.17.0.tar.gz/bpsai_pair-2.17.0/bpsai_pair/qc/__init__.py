"""QC testing framework for interactive browser-based regression testing."""
