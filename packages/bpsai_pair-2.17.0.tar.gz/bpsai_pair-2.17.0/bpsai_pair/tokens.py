"""Token counting and budget estimation.

Provides accurate token counting using tiktoken for estimating
Claude API context usage and preventing context compaction.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import tiktoken


# Model context limits (tokens)
MODEL_LIMITS = {
    "claude-sonnet-4-6": 200000,
    "claude-sonnet-4-5": 200000,
    "claude-opus-4-6": 200000,
    "claude-opus-4-5": 200000,
    "claude-haiku-4-5": 200000,
    # Legacy models
    "claude-3-opus": 200000,
    "claude-3-sonnet": 200000,
    "claude-3-haiku": 200000,
}

# Default budget thresholds (percentages) - can be overridden by config
DEFAULT_THRESHOLDS = {
    "info": 50,      # 50% - informational
    "warning": 75,   # 75% - consider breaking up
    "critical": 90,  # 90% - compaction likely
}

# Legacy alias for backward compatibility
THRESHOLDS = DEFAULT_THRESHOLDS


def load_thresholds_from_config() -> dict:
    """Load budget thresholds from config.yaml if available.

    Returns thresholds from config.yaml token_budget section,
    falling back to DEFAULT_THRESHOLDS for any missing values.
    """
    thresholds = dict(DEFAULT_THRESHOLDS)

    try:
        from .core.ops import find_project_root
        import yaml

        root = find_project_root()
        config_file = root / ".paircoder" / "config.yaml"
        if config_file.exists():
            with open(config_file, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            token_budget = config.get("token_budget", {})

            # Map config keys to threshold keys
            if "warning_threshold" in token_budget:
                thresholds["warning"] = token_budget["warning_threshold"]
            if "critical_threshold" in token_budget:
                thresholds["critical"] = token_budget["critical_threshold"]
            # info_threshold is optional
            if "info_threshold" in token_budget:
                thresholds["info"] = token_budget["info_threshold"]
    except Exception:
        # If config loading fails, use defaults
        pass

    return thresholds


def _get_default_model_for_estimation() -> str:
    """Get default model from config.yaml for estimation.

    Returns models.driver from config, falling back to claude-sonnet-4-5.
    """
    try:
        from .core.ops import find_project_root
        import yaml

        root = find_project_root()
        config_file = root / ".paircoder" / "config.yaml"
        if config_file.exists():
            with open(config_file, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            return config.get("models", {}).get("driver", "claude-sonnet-4-5")
    except Exception:
        pass
    return "claude-sonnet-4-5"


# Estimation multipliers by task type
TASK_TYPE_MULTIPLIERS = {
    "feature": 1.5,    # New features tend to generate more output
    "bugfix": 1.2,     # Bug fixes moderate output
    "refactor": 1.3,   # Refactors touch many files
    "chore": 1.0,      # Chores are typically small
    "docs": 0.8,       # Docs are lighter on code
}

# Default base context tokens (system prompt, instructions, etc.)
DEFAULT_BASE_CONTEXT = 15000


def _get_base_context_from_config() -> int:
    """Get base context tokens from config.yaml if available.

    Returns token_estimates.base_context from config, falling back to default.
    """
    try:
        from .core.ops import find_project_root
        import yaml

        root = find_project_root()
        config_file = root / ".paircoder" / "config.yaml"
        if config_file.exists():
            with open(config_file, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            return config.get("token_estimates", {}).get("base_context", DEFAULT_BASE_CONTEXT)
    except Exception:
        pass
    return DEFAULT_BASE_CONTEXT


@dataclass
class TokenEstimate:
    """Token estimate breakdown for a task."""
    base_context: int
    task_file: int
    source_files: int
    estimated_output: int
    total: int
    budget_percent: float


@dataclass
class BudgetStatus:
    """Budget status with thresholds."""
    used: int
    limit: int
    remaining: int
    percent: float
    status: str  # "ok" | "warning" | "critical"
    message: str


def get_encoding(model: str = "cl100k_base") -> tiktoken.Encoding:
    """Get tiktoken encoding for a model.

    Args:
        model: Encoding name or model name. Defaults to cl100k_base
               which is compatible with Claude models.

    Returns:
        tiktoken.Encoding instance
    """
    return tiktoken.get_encoding(model)


def count_tokens(text: str, model: str = "cl100k_base") -> int:
    """Count tokens in text using tiktoken.

    Args:
        text: Text to count tokens for
        model: Encoding name. Defaults to cl100k_base (Claude-compatible)

    Returns:
        Number of tokens in the text
    """
    if not text:
        return 0
    encoding = get_encoding(model)
    return len(encoding.encode(text))


def count_file_tokens(path: Path) -> int:
    """Count tokens in a file.

    Handles various encodings and binary files gracefully.

    Args:
        path: Path to the file

    Returns:
        Number of tokens, or 0 if file can't be read
    """
    if not path.exists():
        return 0

    # Skip binary files by extension
    binary_extensions = {'.pyc', '.pyo', '.so', '.dll', '.exe', '.bin',
                        '.jpg', '.jpeg', '.png', '.gif', '.ico', '.pdf',
                        '.zip', '.tar', '.gz', '.bz2', '.7z', '.rar'}
    if path.suffix.lower() in binary_extensions:
        return 0

    try:
        # Try UTF-8 first
        content = path.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        try:
            # Fall back to latin-1 for legacy files
            content = path.read_text(encoding='latin-1')
        except Exception:
            return 0
    except Exception:
        return 0

    return count_tokens(content)


def estimate_task_tokens(
    task_id: str,
    files: list[Path],
    complexity: int = 10,
    task_type: str = "feature",
    base_context: Optional[int] = None,
    model: Optional[str] = None,
) -> TokenEstimate:
    """Estimate total tokens for a task.

    Args:
        task_id: Task identifier (for finding task file)
        files: List of source files to be read/modified
        complexity: Task complexity score (1-100)
        task_type: Type of task (feature, bugfix, refactor, chore, docs)
        base_context: Base context tokens (default: from config or 15000)
        model: Model name for context limit (default: from config or claude-sonnet-4-5)

    Returns:
        TokenEstimate with breakdown
    """
    # Resolve base_context from config if not specified
    if base_context is None:
        base_context = _get_base_context_from_config()

    # Count task file tokens (estimate if not found)
    task_file_tokens = 500  # Default estimate
    task_paths = [
        Path(f".paircoder/tasks/{task_id}.task.md"),
        Path(f".paircoder/tasks/TASK-{task_id}.task.md"),
    ]
    for task_path in task_paths:
        if task_path.exists():
            task_file_tokens = count_file_tokens(task_path)
            break

    # Count source file tokens
    source_tokens = sum(count_file_tokens(f) for f in files)

    # Estimate output tokens based on complexity and task type
    multiplier = TASK_TYPE_MULTIPLIERS.get(task_type, 1.0)
    # Scale output estimate: base 1000 tokens + complexity factor
    estimated_output = int((1000 + complexity * 50) * multiplier)

    # Calculate total
    total = base_context + task_file_tokens + source_tokens + estimated_output

    # Get model limit - use config if model not specified
    if model is None:
        model = _get_default_model_for_estimation()
    context_limit = MODEL_LIMITS.get(model, 200000)

    # Calculate budget percentage based on model's context limit
    budget_percent = round((total / context_limit) * 100, 1)

    return TokenEstimate(
        base_context=base_context,
        task_file=task_file_tokens,
        source_files=source_tokens,
        estimated_output=estimated_output,
        total=total,
        budget_percent=budget_percent
    )


def get_budget_status(
    estimated: int,
    model: str = "claude-sonnet-4-5"
) -> BudgetStatus:
    """Get budget status with thresholds.

    Args:
        estimated: Estimated token usage
        model: Model name to get limit for

    Returns:
        BudgetStatus with usage info and status level
    """
    limit = MODEL_LIMITS.get(model, 200000)
    remaining = max(0, limit - estimated)
    percent = round((estimated / limit) * 100, 1)

    # Determine status
    if percent >= THRESHOLDS["critical"]:
        status = "critical"
        message = "Context compaction likely! Consider breaking up the task."
    elif percent >= THRESHOLDS["warning"]:
        status = "warning"
        message = "Approaching context limit. Monitor closely."
    elif percent >= THRESHOLDS["info"]:
        status = "info"
        message = "Budget at 50%. Plan remaining work carefully."
    else:
        status = "ok"
        message = "Budget healthy."

    return BudgetStatus(
        used=estimated,
        limit=limit,
        remaining=remaining,
        percent=percent,
        status=status,
        message=message
    )


def estimate_from_task_file(task_path: Path) -> Optional[TokenEstimate]:
    """Estimate tokens from a task file by parsing its contents.

    Extracts:
    - Complexity from frontmatter
    - Task type from frontmatter
    - Files to modify from "Files to Modify" section

    Args:
        task_path: Path to the .task.md file

    Returns:
        TokenEstimate or None if file can't be parsed
    """
    if not task_path.exists():
        return None

    try:
        content = task_path.read_text(encoding='utf-8')
    except Exception:
        return None

    # Parse frontmatter
    complexity = 10
    task_type = "feature"
    task_id = task_path.stem.replace('.task', '')

    if content.startswith('---'):
        try:
            end_idx = content.index('---', 3)
            frontmatter = content[3:end_idx]
            for line in frontmatter.split('\n'):
                if line.startswith('complexity:'):
                    try:
                        complexity = int(line.split(':')[1].strip())
                    except ValueError:
                        pass
                elif line.startswith('type:'):
                    task_type = line.split(':')[1].strip()
                elif line.startswith('id:'):
                    task_id = line.split(':')[1].strip()
        except ValueError:
            pass

    # Parse "Files to Modify" section
    files = []
    in_files_section = False
    for line in content.split('\n'):
        if '## Files to Modify' in line or '## Files to Create' in line:
            in_files_section = True
            continue
        if in_files_section:
            if line.startswith('##'):
                break
            if line.strip().startswith('- '):
                # Extract file path from markdown list
                file_str = line.strip()[2:].split()[0].strip('`')
                file_path = Path(file_str)
                if file_path.exists():
                    files.append(file_path)

    return estimate_task_tokens(
        task_id=task_id,
        files=files,
        complexity=complexity,
        task_type=task_type
    )
