"""PairCoder Licensing Module.

This module handles license loading, validation, and feature gating.

Key locations:
- Public key (embedded): bpsai_pair/licensing/public_key.pem
- Private key (secure): ~/.paircoder/keys/license_private_key.pem
  - Only accessible to license generation script
  - NOT included in the package or repository

Usage:
    from bpsai_pair.licensing import get_tier, has_feature, require_feature

    # Check current tier
    tier = get_tier()  # "solo", "pro", "enterprise"

    # Check if a feature is available
    if has_feature("trello"):
        # Use trello integration
        pass

    # Require a feature via decorator
    @require_feature("github")
    def sync_with_github():
        pass
"""

from bpsai_pair.licensing.core import (
    FeatureNotAvailable,
    clear_license_cache,
    get_all_features_api,
    get_current_tier_display_name,
    get_tier,
    has_feature_api,
    is_expired,
    load_license,
    require_feature,
    verify_license,
    verify_signature,
)
from bpsai_pair.licensing.keys import (
    DEFAULT_API_URL,
    compare_key_fingerprints,
    fetch_api_public_key,
    get_embedded_public_key,
    get_key_fingerprint,
    verify_key_alignment,
)
from bpsai_pair.licensing.binding import (
    GRACE_PERIOD_DAYS,
    MachineNotActivated,
    check_machine_binding,
    get_available_slots,
    is_in_grace_period,
    is_machine_activated,
    record_first_seen,
)
from bpsai_pair.licensing.machine import (
    get_machine_id,
    mask_machine_id,
)
from bpsai_pair.licensing.online import (
    DEFAULT_TIMEOUT,
    OFFLINE_GRACE_DAYS,
    LicenseNotFoundError,
    LicenseRevoked,
    NetworkError,
    OfflineValidationExpired,
    ValidationResult,
    is_cache_valid,
    is_online_validation_enabled,
    load_validation_cache,
    save_validation_cache,
    validate_license_online,
    validate_with_fallback,
)
from bpsai_pair.licensing.startup import (
    clear_session_cache,
    get_session_tier_change,
    get_tier_change_warning,
    get_validation_warning,
    is_offline_flag_set,
    run_startup_validation,
)
from bpsai_pair.licensing.activation import (
    ActivationError,
    ActivationResult,
    DeactivationResult,
    MachineInfo,
    MachinesListResult,
    activate_machine,
    deactivate_machine,
    list_machines,
)
from bpsai_pair.licensing.security import (
    MAX_BACKOFF_SECONDS,
    calculate_backoff_delay,
    clear_license_cache as clear_security_cache,
    clear_rate_limit,
    constant_time_compare,
    log_security_event,
    record_validation_failure,
    set_cache_file_permissions,
    should_rate_limit,
)
from bpsai_pair.licensing.schema import (
    CATEGORY_TO_FEATURES,
    LicensePayload,
    LicenseTier,
    LicenseType,
    MachineActivation,
    SignedLicense,
    get_all_features,
    get_default_max_machines,
    get_tier_display_name,
    has_feature,
)
from bpsai_pair.licensing.tier_change import (
    TierChangeResult,
    detect_tier_change,
    fetch_updated_license,
    get_tier_change_message,
    handle_tier_change,
    save_updated_license,
)

__all__ = [
    # Enums
    "LicenseTier",
    "LicenseType",
    # Models
    "LicensePayload",
    "MachineActivation",
    "SignedLicense",
    # Constants
    "CATEGORY_TO_FEATURES",
    # Exceptions
    "FeatureNotAvailable",
    # Schema Functions (low-level)
    "get_tier_display_name",
    "get_default_max_machines",
    "has_feature",
    "get_all_features",
    # Core API Functions (high-level)
    "load_license",
    "verify_signature",
    "verify_license",
    "is_expired",
    "get_tier",
    "get_current_tier_display_name",
    "has_feature_api",
    "get_all_features_api",
    "require_feature",
    "clear_license_cache",
    # Key Utilities
    "DEFAULT_API_URL",
    "get_key_fingerprint",
    "get_embedded_public_key",
    "compare_key_fingerprints",
    "fetch_api_public_key",
    "verify_key_alignment",
    # Machine ID
    "get_machine_id",
    "mask_machine_id",
    # Machine Binding
    "GRACE_PERIOD_DAYS",
    "MachineNotActivated",
    "is_machine_activated",
    "check_machine_binding",
    "get_available_slots",
    "is_in_grace_period",
    "record_first_seen",
    # Online Validation
    "DEFAULT_TIMEOUT",
    "OFFLINE_GRACE_DAYS",
    "NetworkError",
    "LicenseNotFoundError",
    "LicenseRevoked",
    "OfflineValidationExpired",
    "ValidationResult",
    "validate_license_online",
    "validate_with_fallback",
    "save_validation_cache",
    "load_validation_cache",
    "is_cache_valid",
    "is_online_validation_enabled",
    # Startup Validation
    "run_startup_validation",
    "get_validation_warning",
    "get_tier_change_warning",
    "get_session_tier_change",
    "is_offline_flag_set",
    "clear_session_cache",
    # Activation
    "ActivationError",
    "ActivationResult",
    "DeactivationResult",
    "MachineInfo",
    "MachinesListResult",
    "activate_machine",
    "deactivate_machine",
    "list_machines",
    # Security
    "MAX_BACKOFF_SECONDS",
    "calculate_backoff_delay",
    "clear_security_cache",
    "clear_rate_limit",
    "constant_time_compare",
    "log_security_event",
    "record_validation_failure",
    "set_cache_file_permissions",
    "should_rate_limit",
    # Tier Change
    "TierChangeResult",
    "detect_tier_change",
    "fetch_updated_license",
    "get_tier_change_message",
    "handle_tier_change",
    "save_updated_license",
]
