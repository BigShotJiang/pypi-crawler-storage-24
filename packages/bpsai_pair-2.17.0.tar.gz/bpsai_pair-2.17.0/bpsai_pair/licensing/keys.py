"""License key utilities for fingerprint comparison and verification.

This module provides utilities for computing and comparing public key fingerprints
to verify that CLI and API use the same keypair.
"""

import hashlib
import json
import logging
import urllib.error
import urllib.request
from pathlib import Path
from typing import TypedDict

from .online import DEFAULT_API_URL

logger = logging.getLogger(__name__)


class KeyComparisonResult(TypedDict):
    """Result of comparing two public keys."""

    cli_fingerprint: str
    api_fingerprint: str
    matching: bool


def get_key_fingerprint(public_key_pem: bytes | str) -> str:
    """Compute SHA-256 fingerprint of a public key.

    The fingerprint is computed as the SHA-256 hash of the DER-encoded
    public key, returned as a lowercase hex string.

    Args:
        public_key_pem: PEM-encoded public key (bytes or string)

    Returns:
        64-character lowercase hex string representing the fingerprint

    Raises:
        ValueError: If the input is not a valid PEM-encoded public key
    """
    try:
        from cryptography.hazmat.primitives import serialization
    except ImportError as e:
        raise ValueError("cryptography package required for key fingerprinting") from e

    # Normalize to bytes
    if isinstance(public_key_pem, str):
        public_key_pem = public_key_pem.encode("utf-8")

    try:
        # Load the public key
        public_key = serialization.load_pem_public_key(public_key_pem)

        # Get DER-encoded form for consistent fingerprinting
        der_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

        # Compute SHA-256 fingerprint
        return hashlib.sha256(der_bytes).hexdigest()

    except Exception as e:
        logger.debug(f"Failed to compute key fingerprint: {e}")
        raise ValueError(f"Invalid public key: {e}") from e


def compare_key_fingerprints(
    cli_key_pem: bytes | str, api_key_pem: bytes | str
) -> KeyComparisonResult:
    """Compare fingerprints of two public keys.

    Args:
        cli_key_pem: PEM-encoded CLI public key (bytes or string)
        api_key_pem: PEM-encoded API public key (bytes or string)

    Returns:
        KeyComparisonResult with fingerprints and matching status
    """
    cli_fingerprint = get_key_fingerprint(cli_key_pem)
    api_fingerprint = get_key_fingerprint(api_key_pem)

    return {
        "cli_fingerprint": cli_fingerprint,
        "api_fingerprint": api_fingerprint,
        "matching": cli_fingerprint == api_fingerprint,
    }


def get_embedded_public_key() -> bytes:
    """Get the public key embedded in the CLI package.

    Returns:
        PEM-encoded public key bytes

    Raises:
        FileNotFoundError: If the embedded key file is missing
    """
    key_path = Path(__file__).parent / "public_key.pem"
    return key_path.read_bytes()


def fetch_api_public_key(api_url: str = DEFAULT_API_URL) -> bytes:
    """Fetch the public key from the API.

    Args:
        api_url: Base URL of the API

    Returns:
        PEM-encoded public key bytes

    Raises:
        Exception: If the request fails
    """
    url = f"{api_url.rstrip('/')}/licenses/public-key"

    try:
        with urllib.request.urlopen(url, timeout=10) as response:
            data = json.loads(response.read().decode("utf-8"))
            return data["public_key"].encode("utf-8")
    except urllib.error.URLError as e:
        raise Exception(f"Failed to fetch API public key: {e}") from e
    except (json.JSONDecodeError, KeyError) as e:
        raise Exception(f"Invalid API response format: {e}") from e


class VerifyKeyResult(TypedDict):
    """Result of key verification against API."""

    cli_fingerprint: str
    api_fingerprint: str | None
    matching: bool | None
    error: str | None


def verify_key_alignment(api_url: str = DEFAULT_API_URL) -> VerifyKeyResult:
    """Verify CLI key matches API's public key.

    Args:
        api_url: Base URL of the API

    Returns:
        VerifyKeyResult with comparison details
    """
    cli_key = get_embedded_public_key()
    cli_fingerprint = get_key_fingerprint(cli_key)

    try:
        api_key = fetch_api_public_key(api_url)
        api_fingerprint = get_key_fingerprint(api_key)
        return {
            "cli_fingerprint": cli_fingerprint,
            "api_fingerprint": api_fingerprint,
            "matching": cli_fingerprint == api_fingerprint,
            "error": None,
        }
    except Exception as e:
        return {
            "cli_fingerprint": cli_fingerprint,
            "api_fingerprint": None,
            "matching": None,
            "error": str(e),
        }
