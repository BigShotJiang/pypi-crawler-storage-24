"""Machine ID Generation for License Binding.

Generates a stable, privacy-preserving machine identifier that:
- Persists across restarts
- Works on Linux, macOS, and Windows
- Falls back gracefully in VMs/containers

The machine ID is a SHA-256 hash of hardware identifiers, not raw values.
"""

import hashlib
import logging
import os
import platform
import re
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def _get_paircoder_dir() -> Path:
    """Get the ~/.paircoder directory path."""
    return Path.home() / ".paircoder"


def _get_mac_address() -> Optional[str]:
    """Get the primary MAC address.

    Returns:
        MAC address in aa:bb:cc:dd:ee:ff format, or None if unavailable.
    """
    try:
        import uuid

        mac_int = uuid.getnode()
        # Check if it's a random MAC (bit 1 of first byte is set)
        if (mac_int >> 40) & 1:
            return None
        mac_hex = f"{mac_int:012x}"
        return ":".join(mac_hex[i : i + 2] for i in range(0, 12, 2))
    except Exception as e:
        logger.debug(f"Failed to get MAC address: {e}")
        return None


def _get_hardware_uuid() -> Optional[str]:
    """Get hardware UUID based on platform.

    Returns:
        Hardware UUID string, or None if unavailable.
    """
    system = platform.system()

    try:
        if system == "Linux":
            return _get_linux_uuid()
        elif system == "Darwin":
            return _get_macos_uuid()
        elif system == "Windows":
            return _get_windows_uuid()
    except Exception as e:
        logger.debug(f"Failed to get hardware UUID: {e}")

    return None


def _get_linux_uuid() -> Optional[str]:
    """Get hardware UUID on Linux."""
    # Try DMI product UUID first (requires root on some systems)
    uuid_paths = [
        "/sys/class/dmi/id/product_uuid",
        "/sys/devices/virtual/dmi/id/product_uuid",
    ]

    for path in uuid_paths:
        try:
            with open(path, encoding="utf-8") as f:
                return f.read().strip()
        except (FileNotFoundError, PermissionError):
            continue

    # Fall back to machine-id
    try:
        with open("/etc/machine-id", encoding="utf-8") as f:
            return f.read().strip()
    except (FileNotFoundError, PermissionError):
        pass

    return None


def _get_macos_uuid() -> Optional[str]:
    """Get hardware UUID on macOS."""
    try:
        result = subprocess.run(
            ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            match = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', result.stdout)
            if match:
                return match.group(1)
    except Exception as e:
        logger.debug(f"Failed to get macOS UUID: {e}")

    return None


def _get_windows_uuid() -> Optional[str]:
    """Get hardware UUID on Windows."""
    try:
        result = subprocess.run(
            ["wmic", "csproduct", "get", "UUID"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            lines = result.stdout.strip().split("\n")
            if len(lines) >= 2:
                uuid_val = lines[1].strip()
                if uuid_val and uuid_val != "FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF":
                    return uuid_val
    except Exception as e:
        logger.debug(f"Failed to get Windows UUID: {e}")

    return None


def _get_fallback_identifier() -> str:
    """Get fallback identifier using hostname and username.

    Used when hardware identifiers are unavailable (VMs, containers).

    Returns:
        String combining hostname and username.
    """
    hostname = platform.node()
    try:
        username = os.getlogin()
    except (OSError, AttributeError):
        # getlogin may fail in some environments
        username = os.environ.get("USER", os.environ.get("USERNAME", "unknown"))

    return f"{hostname}:{username}"


def _collect_hardware_identifiers() -> dict:
    """Collect hardware identifiers for hashing.

    Returns:
        Dict of identifier names to values.
    """
    identifiers = {
        "hostname": platform.node(),
        "platform": platform.system(),
        "machine": platform.machine(),
    }

    # Add MAC address if available
    mac = _get_mac_address()
    if mac:
        identifiers["mac"] = mac

    # Add hardware UUID if available
    hw_uuid = _get_hardware_uuid()
    if hw_uuid:
        identifiers["hw_uuid"] = hw_uuid

    # Always include fallback for consistency
    identifiers["fallback"] = _get_fallback_identifier()

    return identifiers


def _generate_machine_id() -> str:
    """Generate a machine ID from hardware identifiers.

    Returns:
        32-character hex string (first 128 bits of SHA-256).
    """
    identifiers = _collect_hardware_identifiers()

    # Sort keys for consistent ordering
    sorted_items = sorted(identifiers.items())
    id_string = "|".join(f"{k}={v}" for k, v in sorted_items)

    # Hash with SHA-256
    hash_bytes = hashlib.sha256(id_string.encode("utf-8")).hexdigest()

    # Return first 32 characters (128 bits)
    return hash_bytes[:32]


def _is_valid_machine_id(machine_id: str) -> bool:
    """Check if a machine ID is valid.

    Args:
        machine_id: The ID to validate.

    Returns:
        True if valid 32-char hex string.
    """
    if not machine_id or len(machine_id) != 32:
        return False
    try:
        int(machine_id, 16)
        return True
    except ValueError:
        return False


def get_machine_id() -> str:
    """Get the machine ID, generating and storing if needed.

    The ID is stored in ~/.paircoder/machine_id after first generation.

    Returns:
        32-character hex string machine ID.
    """
    paircoder_dir = _get_paircoder_dir()
    id_file = paircoder_dir / "machine_id"

    # Try to read existing ID
    if id_file.exists():
        try:
            stored_id = id_file.read_text(encoding="utf-8").strip()
            if _is_valid_machine_id(stored_id):
                return stored_id
            logger.debug("Stored machine ID is invalid, regenerating")
        except Exception as e:
            logger.debug(f"Failed to read machine ID file: {e}")

    # Generate new ID
    machine_id = _generate_machine_id()

    # Store it
    try:
        paircoder_dir.mkdir(parents=True, exist_ok=True)
        id_file.write_text(machine_id, encoding="utf-8")
        logger.debug(f"Stored machine ID in {id_file}")
    except Exception as e:
        logger.warning(f"Failed to store machine ID: {e}")

    return machine_id


def mask_machine_id(machine_id: str) -> str:
    """Mask a machine ID for display.

    Shows first 8 and last 6 characters, masks the middle.

    Args:
        machine_id: The machine ID to mask.

    Returns:
        Masked string like "abcdef12****567890".
    """
    if len(machine_id) < 14:
        return machine_id[:4] + "****" + machine_id[-4:] if len(machine_id) > 8 else "****"

    return machine_id[:8] + "****" + machine_id[-6:]
