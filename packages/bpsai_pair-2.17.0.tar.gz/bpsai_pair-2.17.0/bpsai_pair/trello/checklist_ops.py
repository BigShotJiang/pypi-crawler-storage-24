"""Checklist operations for Trello cards.

Extracted from client.py for modular architecture.
"""

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ChecklistMixin:
    """Mixin providing checklist operations on Trello cards."""

    # These attributes are provided by TrelloService
    client: Any

    def get_card_checklists(self, card: Any) -> List[Dict[str, Any]]:
        """Get all checklists on a card."""
        try:
            checklists = []
            for cl in card.checklists:
                items = []
                for item in cl.items:
                    items.append({
                        'id': item.get('id'),
                        'name': item.get('name'),
                        'checked': item.get('checked', False),
                        'pos': item.get('pos', 0),
                    })
                checklists.append({
                    'id': cl.id,
                    'name': cl.name,
                    'items': items,
                })
            return checklists
        except Exception as e:
            logger.error(f"Failed to get checklists: {e}")
            return []

    def get_checklist_by_name(self, card: Any, name: str) -> Optional[Dict[str, Any]]:
        """Find a checklist by name on a card."""
        checklists = self.get_card_checklists(card)
        for cl in checklists:
            if cl['name'].lower() == name.lower():
                return cl
        return None

    def create_checklist(self, card: Any, name: str) -> Optional[Dict[str, Any]]:
        """Create a new checklist on a card."""
        try:
            checklist = card.add_checklist(name, [])
            return {
                'id': checklist.id,
                'name': checklist.name,
                'items': [],
            }
        except Exception as e:
            logger.error(f"Failed to create checklist: {e}")
            return None

    def add_checklist_item(
        self,
        card: Any,
        checklist_id: str,
        name: str,
        checked: bool = False
    ) -> Optional[Dict[str, Any]]:
        """Add an item to a checklist."""
        try:
            result = self.client.fetch_json(
                f'/checklists/{checklist_id}/checkItems',
                http_method='POST',
                post_args={
                    'name': name,
                    'checked': 'true' if checked else 'false',
                }
            )
            return {
                'id': result.get('id'),
                'name': result.get('name'),
                'checked': result.get('state') == 'complete',
            }
        except Exception as e:
            logger.error(f"Failed to add checklist item: {e}")
            return None

    def update_checklist_item(
        self,
        card: Any,
        checklist_id: str,
        item_id: str,
        checked: Optional[bool] = None,
        name: Optional[str] = None
    ) -> bool:
        """Update a checklist item."""
        try:
            post_args: Dict[str, str] = {}
            if checked is not None:
                post_args['state'] = 'complete' if checked else 'incomplete'
            if name is not None:
                post_args['name'] = name

            if not post_args:
                return True

            self.client.fetch_json(
                f'/cards/{card.id}/checkItem/{item_id}',
                http_method='PUT',
                post_args=post_args
            )
            return True
        except Exception as e:
            logger.error(f"Failed to update checklist item: {e}")
            return False

    def delete_checklist(self, checklist_id: str) -> bool:
        """Delete a checklist."""
        try:
            self.client.fetch_json(
                f'/checklists/{checklist_id}',
                http_method='DELETE'
            )
            return True
        except Exception as e:
            logger.error(f"Failed to delete checklist: {e}")
            return False

    def delete_checklist_item(self, checklist_id: str, item_id: str) -> bool:
        """Delete a checklist item."""
        try:
            self.client.fetch_json(
                f'/checklists/{checklist_id}/checkItems/{item_id}',
                http_method='DELETE'
            )
            return True
        except Exception as e:
            logger.error(f"Failed to delete checklist item: {e}")
            return False

    def ensure_checklist(
        self,
        card: Any,
        name: str,
        items: List[str],
        checked_items: Optional[List[str]] = None
    ) -> Optional[Dict[str, Any]]:
        """Ensure a checklist exists with the specified items.

        Creates the checklist if it doesn't exist, or updates it if it does.
        Stale items (on card but not in items list) are removed.
        """
        checked_items = checked_items or []
        existing = self.get_checklist_by_name(card, name)

        if existing:
            return self._update_existing_checklist(card, existing, items, checked_items)
        else:
            return self._create_new_checklist(card, name, items, checked_items)

    def _update_existing_checklist(
        self,
        card: Any,
        existing: Dict[str, Any],
        items: List[str],
        checked_items: List[str],
    ) -> Dict[str, Any]:
        """Update an existing checklist to match the expected items."""
        existing_names = {item['name']: item for item in existing['items']}
        items_set = set(items)

        # Remove stale items
        for item_name, item in existing_names.items():
            if item_name not in items_set:
                self.delete_checklist_item(existing['id'], item['id'])
                logger.info(f"Removed stale checklist item: {item_name}")

        # Add missing items or update existing ones
        for item_name in items:
            if item_name not in existing_names:
                checked = item_name in checked_items
                self.add_checklist_item(card, existing['id'], item_name, checked)
            else:
                item = existing_names[item_name]
                should_be_checked = item_name in checked_items
                if item['checked'] != should_be_checked:
                    self.update_checklist_item(
                        card, existing['id'], item['id'],
                        checked=should_be_checked
                    )

        return existing

    def _create_new_checklist(
        self,
        card: Any,
        name: str,
        items: List[str],
        checked_items: List[str],
    ) -> Optional[Dict[str, Any]]:
        """Create a new checklist with the specified items."""
        checklist = self.create_checklist(card, name)
        if not checklist:
            return None

        for item_name in items:
            checked = item_name in checked_items
            self.add_checklist_item(card, checklist['id'], item_name, checked)

        return checklist
