"""
Trello client wrapper.

TrelloService is the main facade. Operations are organized into mixins:
- CustomFieldMixin (custom_fields.py) — custom field CRUD
- ChecklistMixin (checklist_ops.py) — checklist CRUD
- LabelMixin, BoardTemplateMixin (label_ops.py) — labels + board templates
"""
from typing import List, Optional, Dict, Any
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class CustomFieldDefinition:
    """Represents a Trello custom field definition."""
    id: str
    name: str
    field_type: str  # 'text', 'number', 'checkbox', 'list', 'date'
    options: Dict[str, str]  # For list type: option_id -> option_text


@dataclass
class EffortMapping:
    """Maps complexity scores to effort values (S/M/L)."""
    small: tuple = (0, 25)
    medium: tuple = (26, 50)
    large: tuple = (51, 100)

    def get_effort(self, complexity: int) -> str:
        """Convert complexity score to S/M/L effort."""
        if complexity <= self.small[1]:
            return "S"
        elif complexity <= self.medium[1]:
            return "M"
        else:
            return "L"


# Import mixins after dataclasses to avoid circular imports
from .custom_fields import CustomFieldMixin  # noqa: E402
from .checklist_ops import ChecklistMixin  # noqa: E402
from .label_ops import LabelMixin, BoardTemplateMixin  # noqa: E402


class TrelloService(
    CustomFieldMixin,
    ChecklistMixin,
    LabelMixin,
    BoardTemplateMixin,
):
    """Wrapper around the Trello API client.

    Core operations (init, board setup, card finding/moving) are defined here.
    Extended operations are provided by mixins:
    - CustomFieldMixin: get/set custom fields, effort mapping
    - ChecklistMixin: checklist CRUD, ensure_checklist
    - LabelMixin: label CRUD, add_label_to_card
    - BoardTemplateMixin: find/copy board templates, board info
    """

    def __init__(self, api_key: str, token: str):
        """Initialize Trello service."""
        try:
            from trello import TrelloClient
            self.client = TrelloClient(api_key=api_key, token=token)
        except ImportError as e:
            raise ImportError(f"Error importing Trello client: {e}")
        self.board = None
        self.lists: Dict[str, Any] = {}

    def healthcheck(self) -> bool:
        """Check if the connection is working."""
        try:
            self.client.list_boards()
            return True
        except Exception as e:
            logger.warning(f"Trello healthcheck failed: {e}")
            return False

    def list_boards(self) -> List[Any]:
        """List all accessible boards."""
        return self.client.list_boards()

    def set_board(self, board_id: str) -> Any:
        """Set the active board."""
        self.board = self.client.get_board(board_id)
        self.lists = {lst.name: lst for lst in self.board.all_lists()}
        return self.board

    def get_board_lists(self) -> Dict[str, Any]:
        """Get all lists on the current board."""
        if not self.board:
            raise ValueError("Board not set. Call set_board() first.")
        return self.lists

    def get_cards_in_list(self, list_name: str) -> List[Any]:
        """Get all cards in a list."""
        lst = self.lists.get(list_name)
        if not lst:
            return []
        return lst.list_cards()

    def move_card(self, card: Any, list_name: str) -> None:
        """Move a card to a different list (created if doesn't exist)."""
        target = self.lists.get(list_name)
        if not target:
            target = self.board.add_list(list_name)
            self.lists[list_name] = target
        card.change_list(target.id)

    def add_comment(self, card: Any, comment: str) -> None:
        """Add a comment to a card."""
        card.comment(comment)

    def is_card_blocked(self, card: Any) -> bool:
        """Check if a card has unchecked dependencies."""
        try:
            for checklist in card.checklists:
                if checklist.name.lower() == 'card dependencies':
                    for item in checklist.items:
                        if not item.get('checked', False):
                            return True
        except Exception:
            pass
        return False

    def find_card(self, card_id: str) -> tuple[Optional[Any], Optional[Any]]:
        """Find a card by ID or short ID."""
        if not self.board:
            return None, None

        if card_id.startswith("TRELLO-"):
            card_id = card_id[7:]

        for lst in self.board.all_lists():
            for card in lst.list_cards():
                if (card.id == card_id or
                    str(card.short_id) == card_id):
                    return card, lst
        return None, None

    def find_card_with_prefix(self, prefix: str) -> tuple[Optional[Any], Optional[Any]]:
        """Find a card by prefix in title (e.g., '[TASK-001]')."""
        if not self.board:
            return None, None

        search_prefix = prefix if prefix.startswith("[") else f"[{prefix}]"

        for lst in self.board.all_lists():
            for card in lst.list_cards():
                if search_prefix in card.name:
                    return card, lst
        return None, None

    def move_card_by_task_id(self, task_id: str, target_list: str, comment: Optional[str] = None) -> bool:
        """Move a card by task ID to a target list."""
        card, _ = self.find_card_with_prefix(task_id)
        if not card:
            return False

        self.move_card(card, target_list)

        if comment:
            self.add_comment(card, comment)

        return True

    # ========== Due Date ==========

    def get_due_date(self, card: Any) -> Optional[Any]:
        """Get the due date from a card."""
        return getattr(card, 'due_date', None)

    def set_due_date(self, card: Any, due_date: Optional[Any]) -> bool:
        """Set the due date on a card."""
        try:
            card.set_due(due_date)
            return True
        except Exception as e:
            logger.error(f"Failed to set due date: {e}")
            return False
