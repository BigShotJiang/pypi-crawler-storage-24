"""Install/remove PairCoder status line in .claude/settings.json.

Provides the shared primitive called by all init paths (init, wizard,
workspace init-project, upgrade, migrate) and the CLI command.
"""

from __future__ import annotations

import json
from pathlib import Path


STATUSLINE_CONFIG = {
    "type": "command",
    "command": "bpsai-pair-statusline",
    "padding": 0,
}


def merge_settings_json(settings_path: Path) -> bool:
    """Merge statusLine key into .claude/settings.json.

    Creates the file from scratch if missing. Backs up and rewrites if
    the existing file contains malformed JSON. Returns True if the file
    was modified, False if already correct (idempotent).
    """
    if settings_path.exists():
        try:
            data = json.loads(settings_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            data = _backup_and_reset(settings_path)
    else:
        data = {}

    if data.get("statusLine") == STATUSLINE_CONFIG:
        return False

    data["statusLine"] = STATUSLINE_CONFIG
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(
        json.dumps(data, indent=2) + "\n", encoding="utf-8",
    )
    return True


def install_statusline(project_root: Path) -> bool:
    """Ensure statusLine is configured in .claude/settings.json.

    Creates .claude/ directory if needed. Never raises — all exceptions
    are swallowed so callers don't need try/except wrappers.
    """
    try:
        settings_path = project_root / ".claude" / "settings.json"
        return merge_settings_json(settings_path)
    except Exception:
        return False


def remove_statusline(project_root: Path) -> bool:
    """Remove statusLine key from .claude/settings.json.

    Returns True if removed, False if wasn't present or file missing.
    """
    settings_path = project_root / ".claude" / "settings.json"
    if not settings_path.exists():
        return False
    try:
        data = json.loads(settings_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return False

    if "statusLine" not in data:
        return False

    del data["statusLine"]
    settings_path.write_text(
        json.dumps(data, indent=2) + "\n", encoding="utf-8",
    )
    return True


def _backup_and_reset(settings_path: Path) -> dict:
    """Backup corrupt JSON file and return empty dict to rebuild from."""
    backup_path = settings_path.with_suffix(".json.bak")
    try:
        settings_path.rename(backup_path)
    except OSError:
        pass
    return {}
