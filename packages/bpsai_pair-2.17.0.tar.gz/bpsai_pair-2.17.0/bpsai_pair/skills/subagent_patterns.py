"""Subagent detection patterns and data types.

Contains SubagentGap dataclass and keyword constants used
by the subagent gap detector for pattern matching.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class SubagentGap:
    """Detected pattern suggesting a subagent would be beneficial."""

    id: str
    suggested_name: str  # kebab-case, e.g., "security-reviewer"
    description: str
    detected_at: str = field(default_factory=lambda: datetime.now().isoformat())
    confidence: float = 0.0  # 0.0 to 1.0

    # Subagent-specific fields
    indicators: List[str] = field(default_factory=list)
    suggested_tools: Optional[List[str]] = None
    suggested_model: Optional[str] = None
    needs_context_isolation: bool = False
    needs_resumability: bool = False
    suggested_persona: Optional[str] = None

    # Source patterns
    source_commands: List[str] = field(default_factory=list)
    occurrence_count: int = 0
    estimated_context_savings: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "suggested_name": self.suggested_name,
            "description": self.description,
            "detected_at": self.detected_at,
            "confidence": self.confidence,
            "indicators": self.indicators,
            "suggested_tools": self.suggested_tools,
            "suggested_model": self.suggested_model,
            "needs_context_isolation": self.needs_context_isolation,
            "needs_resumability": self.needs_resumability,
            "suggested_persona": self.suggested_persona,
            "source_commands": self.source_commands,
            "occurrence_count": self.occurrence_count,
            "estimated_context_savings": self.estimated_context_savings,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SubagentGap":
        """Create SubagentGap from dictionary."""
        return cls(
            id=data.get("id", ""),
            suggested_name=data.get("suggested_name", ""),
            description=data.get("description", ""),
            detected_at=data.get("detected_at", datetime.now().isoformat()),
            confidence=data.get("confidence", 0.0),
            indicators=data.get("indicators", []),
            suggested_tools=data.get("suggested_tools"),
            suggested_model=data.get("suggested_model"),
            needs_context_isolation=data.get("needs_context_isolation", False),
            needs_resumability=data.get("needs_resumability", False),
            suggested_persona=data.get("suggested_persona"),
            source_commands=data.get("source_commands", []),
            occurrence_count=data.get("occurrence_count", 0),
            estimated_context_savings=data.get("estimated_context_savings"),
        )


# Keywords indicating persona-based work
PERSONA_KEYWORDS = [
    "act as", "you are a", "pretend to be", "role of",
    "reviewer", "analyst", "expert", "specialist",
    "advocate", "critic", "auditor",
]

# Keywords indicating context isolation need
ISOLATION_KEYWORDS = [
    "separately", "in parallel", "don't mix", "fresh context",
    "new conversation", "isolated", "independent", "aside",
    "background", "concurrent",
]

# Keywords indicating resumability need
RESUMABLE_KEYWORDS = [
    "continue", "pick up where", "resume", "last time",
    "remember when", "earlier we", "back to", "follow up",
    "next session", "later",
]

# Keywords indicating model preference
MODEL_KEYWORDS = {
    "opus": ["complex", "difficult", "nuanced", "thorough analysis", "deep reasoning"],
    "haiku": ["quick", "fast", "simple", "straightforward", "just", "briefly"],
}

# Tool restriction patterns (read-only operations suggest restricted tools)
READ_ONLY_PATTERNS = [
    "review", "analyze", "check", "audit", "inspect",
    "examine", "scan", "look at", "read through",
]
