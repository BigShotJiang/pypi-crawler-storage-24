"""
Unified Gap Classifier — re-export shim.

All implementation has moved to focused modules:
- classifier_models.py: Data models (GapType, ClassifiedGap, etc.)
- classifier_engine.py: GapClassifier class
- classifier_report.py: detect_and_classify_all(), format_classification_report()
"""

from .classifier_models import (  # noqa: F401
    AllGaps,
    ClassificationScores,
    ClassifiedGap,
    GapType,
    SkillRecommendation,
    SubagentRecommendation,
)
from .classifier_engine import GapClassifier  # noqa: F401
from .classifier_report import (  # noqa: F401
    detect_and_classify_all,
    format_classification_report,
)

__all__ = [
    "GapType",
    "ClassificationScores",
    "SkillRecommendation",
    "SubagentRecommendation",
    "ClassifiedGap",
    "AllGaps",
    "GapClassifier",
    "detect_and_classify_all",
    "format_classification_report",
]
