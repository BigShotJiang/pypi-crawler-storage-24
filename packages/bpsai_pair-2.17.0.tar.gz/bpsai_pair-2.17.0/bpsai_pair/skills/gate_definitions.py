"""Gate data types and constants for quality gate evaluation.

Contains GateStatus, GateResult, QualityGateResult dataclasses
and the constant pattern lists used for novelty/trivial detection.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional


class GateStatus(Enum):
    """Result status for a quality gate."""

    PASS = "pass"
    WARN = "warn"  # Passes but with warnings
    BLOCK = "block"  # Hard rejection


@dataclass
class GateResult:
    """Result from evaluating a single gate."""

    gate_name: str
    status: GateStatus
    score: float  # 0.0 to 1.0
    reason: str
    details: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "gate_name": self.gate_name,
            "status": self.status.value,
            "score": self.score,
            "reason": self.reason,
            "details": self.details,
        }


@dataclass
class QualityGateResult:
    """Combined result from all quality gates."""

    gap_id: str
    gap_name: str
    overall_status: GateStatus
    gate_results: List[GateResult]
    recommendation: str
    can_generate: bool

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "gap_id": self.gap_id,
            "gap_name": self.gap_name,
            "overall_status": self.overall_status.value,
            "gate_results": [g.to_dict() for g in self.gate_results],
            "recommendation": self.recommendation,
            "can_generate": self.can_generate,
        }


# Generic commands that shouldn't form the basis of a skill alone
GENERIC_COMMANDS = {
    # Testing
    "pytest", "npm test", "npm run test", "yarn test", "make test",
    "go test", "cargo test", "ruby test", "jest", "mocha", "rspec",
    # Git basics
    "git add", "git commit", "git push", "git pull", "git status",
    "git diff", "git log", "git checkout", "git branch", "git merge",
    "git stash",
    # Package management
    "pip install", "npm install", "yarn add", "brew install",
    "apt install", "cargo add",
    # Build basics
    "npm run build", "make", "make build", "cargo build", "go build",
    # Vague action words (too generic)
    "fix", "edit", "update", "change", "modify", "check", "run",
    "start", "stop",
}

# Pattern pairs that are always blocked (too simple to be skills)
TRIVIAL_PATTERN_PAIRS = [
    # test + fix is just development, not a skill
    ({"pytest", "test", "jest", "mocha", "npm test", "yarn test"}, {"fix", "edit", "update"}),
    # basic git workflow
    ({"git add"}, {"git commit"}),
    ({"git commit"}, {"git push"}),
    # install + run
    ({"pip install", "npm install", "yarn add"}, {"python", "npm run", "yarn run"}),
]

# Patterns that indicate generic commands
GENERIC_PATTERNS = [
    r"^(pip|npm|yarn|cargo|go)\s+(install|add|get)",
    r"^git\s+(add|commit|push|pull|status|diff|log)",
    r"^(pytest|jest|mocha|rspec|cargo test|go test)",
    r"^make\s*$",
    r"^(npm|yarn)\s+run\s+(test|build|start)",
]
