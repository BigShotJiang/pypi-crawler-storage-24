"""Config-driven export infrastructure for skill exporter.

Provides ExportConfig dataclass and EXPORT_CONFIGS registry that replace
per-format path/format/write functions with a unified config-driven approach.
"""

import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from datetime import datetime


class ExportFormat(Enum):
    """Supported export formats."""

    CURSOR = "cursor"
    CONTINUE = "continue"
    WINDSURF = "windsurf"
    CODEX = "codex"
    CHATGPT = "chatgpt"
    ALL = "all"


@dataclass
class ExportConfig:
    """Configuration for a single export format."""

    path_template: str
    strip_frontmatter: bool = True
    header_template: str = ""
    footer_template: str = ""
    append_mode: bool = False
    section_marker: str = ""
    use_home: bool = False
    transform_name: bool = False
    include_description: bool = False


EXPORT_CONFIGS = {
    ExportFormat.CURSOR: ExportConfig(
        path_template=".cursor/rules/{name}.md",
        header_template=(
            "<!-- Exported from bpsai-pair skill: {skill_name} -->\n"
            "<!-- Export date: {date} -->\n\n"
        ),
    ),
    ExportFormat.CONTINUE: ExportConfig(
        path_template=".continue/context/{name}.md",
        header_template=(
            "# Context: {skill_name}\n\n"
            "<!-- Exported from bpsai-pair -->\n\n"
        ),
    ),
    ExportFormat.WINDSURF: ExportConfig(
        path_template=".windsurfrules",
        header_template="\n\n## --- BEGIN SKILL: {skill_name} ---\n\n",
        footer_template="\n\n## --- END SKILL: {skill_name} ---\n",
        append_mode=True,
        section_marker="BEGIN SKILL: {skill_name}",
    ),
    ExportFormat.CODEX: ExportConfig(
        path_template=".codex/skills/{name}/SKILL.md",
        strip_frontmatter=False,
        use_home=True,
    ),
    ExportFormat.CHATGPT: ExportConfig(
        path_template="chatgpt-skills/{name}/skill.md",
        header_template="# {display_name}\n\n{description_block}",
        footer_template="\n\n---\n*Exported from PairCoder skill: {skill_name}*",
        transform_name=True,
        include_description=True,
    ),
}


def resolve_path(config: ExportConfig, project_dir: Path, skill_name: str) -> Path:
    """Resolve output path from config template.

    Args:
        config: Export format configuration
        project_dir: Project root directory
        skill_name: Skill name for path interpolation

    Returns:
        Resolved output file path
    """
    rendered = config.path_template.format(name=skill_name)
    base = Path.home() if config.use_home else project_dir
    return base / rendered


def _strip_frontmatter(content: str) -> str:
    """Remove YAML frontmatter from content."""
    if not content.startswith("---"):
        return content

    lines = content.split("\n")
    end_idx = None
    for i, line in enumerate(lines[1:], 1):
        if line.strip() == "---":
            end_idx = i
            break

    if end_idx is None:
        return content

    body = "\n".join(lines[end_idx + 1 :])
    return body.lstrip("\n")


def format_content(
    config: ExportConfig,
    skill_name: str,
    content: str,
    description: str = "",
) -> str:
    """Format skill content using config-driven templates.

    Args:
        config: Export format configuration
        skill_name: Skill name
        content: Original SKILL.md content
        description: Skill description from frontmatter

    Returns:
        Formatted content for the target format
    """
    if not config.strip_frontmatter:
        return content

    body = _strip_frontmatter(content)
    display_name = skill_name.replace("-", " ").title() if config.transform_name else skill_name
    description_block = f"{description}\n\n" if (config.include_description and description) else ""

    header = config.header_template.format(
        skill_name=skill_name,
        display_name=display_name,
        description_block=description_block,
        date=datetime.now().strftime("%Y-%m-%d"),
    )
    footer = config.footer_template.format(skill_name=skill_name)

    return header + body + footer


def write_export(
    config: ExportConfig,
    output_path: Path,
    formatted: str,
    skill_name: str,
) -> None:
    """Write formatted content to output path.

    Handles both normal write and append mode (Windsurf).

    Args:
        config: Export format configuration
        output_path: Resolved output file path
        formatted: Already-formatted content to write
        skill_name: Skill name (for section dedup in append mode)
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if config.append_mode and output_path.exists():
        existing = output_path.read_text(encoding="utf-8")
        marker = config.section_marker.format(skill_name=skill_name)
        if marker in existing:
            pattern = rf"## --- {re.escape(marker)} ---.*?## --- END SKILL: {re.escape(skill_name)} ---"
            existing = re.sub(pattern, "", existing, flags=re.DOTALL)
        formatted = existing.rstrip() + formatted

    output_path.write_text(formatted, encoding="utf-8")
