"""Generator Models — Error types and data classes for skill generation."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List


class SkillGeneratorError(Exception):
    """Error during skill generation."""
    pass


@dataclass
class GeneratedSkill:
    """Represents a generated skill draft."""

    name: str
    content: str
    source_pattern: List[str]
    requires_review: bool = True
    generated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "name": self.name,
            "content": self.content,
            "source_pattern": self.source_pattern,
            "requires_review": self.requires_review,
            "generated_at": self.generated_at,
        }
