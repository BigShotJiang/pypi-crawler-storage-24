"""
Gap classification reporting and orchestration.

Contains the high-level detect-and-classify function and
the report formatting function.
"""

from pathlib import Path
from typing import List, Optional

from .classifier_models import AllGaps, ClassifiedGap, GapType
from .classifier_engine import GapClassifier


def _discover_existing_names(
    skills_dir: Optional[Path],
    subagents_dir: Optional[Path],
    history_dir: Path,
) -> tuple:
    """Discover existing skill and subagent names from directories."""
    existing_skills = []
    if skills_dir and skills_dir.exists():
        for skill_dir in skills_dir.iterdir():
            if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
                existing_skills.append(skill_dir.name)

    existing_subagents = []
    if subagents_dir and subagents_dir.exists():
        for agent_file in subagents_dir.glob("*.md"):
            existing_subagents.append(agent_file.stem)

    claude_agents = history_dir.parent.parent / ".claude" / "agents"
    if claude_agents.exists():
        for agent_file in claude_agents.glob("*.md"):
            existing_subagents.append(agent_file.stem)

    return existing_skills, existing_subagents


def detect_and_classify_all(
    history_dir: Path,
    skills_dir: Optional[Path] = None,
    subagents_dir: Optional[Path] = None,
) -> List[ClassifiedGap]:
    """Detect and classify all gaps from history.

    High-level function that runs both skill and subagent detection,
    then classifies all results.

    Args:
        history_dir: Path to history directory
        skills_dir: Path to skills directory
        subagents_dir: Path to subagents directory

    Returns:
        List of classified gaps
    """
    from .gap_detector import detect_gaps_from_history
    from .subagent_detector import detect_subagent_gaps

    skill_gaps = detect_gaps_from_history(history_dir, skills_dir)
    subagent_gaps = detect_subagent_gaps(history_dir, subagents_dir)

    existing_skills, existing_subagents = _discover_existing_names(
        skills_dir, subagents_dir, history_dir
    )

    classifier = GapClassifier(
        existing_skills=existing_skills,
        existing_subagents=existing_subagents,
    )

    all_gaps = AllGaps(skills=skill_gaps, subagents=subagent_gaps)
    return classifier.classify_all(all_gaps)


def format_classification_report(gaps: List[ClassifiedGap]) -> str:
    """Format a classification report.

    Args:
        gaps: List of classified gaps

    Returns:
        Formatted report string
    """
    if not gaps:
        return "No gaps detected."

    lines = [
        "Gap Classification Report",
        "=" * 40,
        "",
    ]

    # Group by type
    skills = [g for g in gaps if g.gap_type == GapType.SKILL]
    subagents = [g for g in gaps if g.gap_type == GapType.SUBAGENT]
    ambiguous = [g for g in gaps if g.gap_type == GapType.AMBIGUOUS]

    if skills:
        lines.append(f"SKILLS ({len(skills)}):")
        for gap in skills:
            lines.append(f"  - {gap.suggested_name} ({gap.confidence:.0%})")
        lines.append("")

    if subagents:
        lines.append(f"SUBAGENTS ({len(subagents)}):")
        for gap in subagents:
            lines.append(f"  - {gap.suggested_name} ({gap.confidence:.0%})")
        lines.append("")

    if ambiguous:
        lines.append(f"AMBIGUOUS ({len(ambiguous)}):")
        for gap in ambiguous:
            lines.append(f"  - {gap.suggested_name} ({gap.confidence:.0%})")
            lines.append("    (Could be skill or subagent - user decision needed)")
        lines.append("")

    lines.append(f"Total: {len(gaps)} gaps classified")

    return "\n".join(lines)
