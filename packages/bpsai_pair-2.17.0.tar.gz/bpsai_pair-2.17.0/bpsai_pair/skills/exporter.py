"""Skill Exporter - Export skills to other AI coding tool formats."""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from .export_base import (
    ExportFormat,
    EXPORT_CONFIGS,
    resolve_path,
    format_content,
    write_export,
    _strip_frontmatter,
)

logger = logging.getLogger(__name__)


class SkillExporterError(Exception):
    """Error during skill export."""

    pass


def find_project_root() -> Path:
    """Find project root by looking for .paircoder directory."""
    from ..core.ops import find_project_root as _find_project_root

    return _find_project_root()


def _check_scripts_portability(
    skill_dir: Path, target_format: Optional[ExportFormat],
) -> Optional[str]:
    """Check scripts directory portability for target format."""
    scripts_dir = skill_dir / "scripts"
    if not scripts_dir.exists() or not any(scripts_dir.iterdir()):
        return None
    if target_format == ExportFormat.CHATGPT:
        return "Skill has scripts/ directory - not supported in ChatGPT"
    if target_format in (ExportFormat.CURSOR, ExportFormat.CONTINUE):
        return "Skill has scripts/ directory - scripts won't work on other platforms"
    return "Skill has scripts/ directory - scripts may not work on all platforms"


def _check_content_portability(
    content: str, target_format: Optional[ExportFormat],
) -> List[str]:
    """Check SKILL.md content for platform-specific patterns."""
    warnings = []
    if "bpsai-pair" in content:
        warnings.append("Skill references bpsai-pair commands - may not work on other platforms")
    if "claude code" in content.lower() or "/compact" in content or "/context" in content:
        warnings.append("Skill references Claude Code features - may not work on other platforms")
    if target_format in (ExportFormat.CODEX, ExportFormat.ALL):
        if "mcp" in content.lower() or "model context protocol" in content.lower():
            warnings.append("Skill references MCP tools - may not be available in Codex")
    return warnings


def check_portability(skill_dir: Path, target_format: Optional[ExportFormat] = None) -> List[str]:
    """Check skill for portability issues."""
    warnings = []
    script_warn = _check_scripts_portability(skill_dir, target_format)
    if script_warn:
        warnings.append(script_warn)
    skill_file = skill_dir / "SKILL.md"
    if skill_file.exists():
        content = skill_file.read_text(encoding="utf-8")
        warnings.extend(_check_content_portability(content, target_format))
    return warnings


def _extract_description(content: str) -> str:
    """Extract description from YAML frontmatter."""
    if not content.startswith("---"):
        return ""
    for line in content.split("\n")[1:]:
        if line.strip() == "---":
            break
        if line.startswith("description:"):
            desc = line.split(":", 1)[1].strip()
            if (desc.startswith('"') and desc.endswith('"')) or (
                desc.startswith("'") and desc.endswith("'")
            ):
                desc = desc[1:-1]
            return desc
    return ""


def _validate_format(format: ExportFormat) -> ExportFormat:
    """Validate and coerce format argument."""
    if isinstance(format, str):
        try:
            return ExportFormat(format)
        except ValueError:
            raise SkillExporterError(f"Invalid export format: {format}")
    return format


def _load_skill(skills_dir: Path, skill_name: str) -> str:
    """Load skill content, raising if not found."""
    skill_file = skills_dir / skill_name / "SKILL.md"
    if not skill_file.exists():
        raise SkillExporterError(f"Skill not found: {skill_name}")
    return skill_file.read_text(encoding="utf-8")


def export_skill(
    skill_name: str,
    format: ExportFormat,
    skills_dir: Path,
    project_dir: Path,
    dry_run: bool = False,
) -> Dict[str, Any]:
    """Export a single skill to target format."""
    format = _validate_format(format)

    if format == ExportFormat.ALL:
        return export_to_all_formats(skill_name, skills_dir, project_dir, dry_run)

    config = EXPORT_CONFIGS.get(format)
    if config is None:
        raise SkillExporterError(f"Unsupported format: {format}")

    content = _load_skill(skills_dir, skill_name)
    warnings = check_portability(skills_dir / skill_name, target_format=format)
    output_path = resolve_path(config, project_dir, skill_name)
    formatted = format_content(config, skill_name, content, _extract_description(content))

    result = {
        "success": True, "skill_name": skill_name, "format": format.value,
        "path": str(output_path), "warnings": warnings,
    }

    if dry_run:
        result["dry_run"] = True
        result["would_create"] = str(output_path)
        return result

    write_export(config, output_path, formatted, skill_name)
    result["created"] = str(output_path)
    return result


def export_to_all_formats(
    skill_name: str, skills_dir: Path, project_dir: Path, dry_run: bool = False,
) -> Dict[str, Any]:
    """Export a skill to all supported formats."""
    _load_skill(skills_dir, skill_name)  # fail fast

    formats = [f for f in ExportFormat if f != ExportFormat.ALL]
    results = []
    all_warnings: set = set()

    for fmt in formats:
        try:
            result = export_skill(skill_name, fmt, skills_dir, project_dir, dry_run)
            results.append(result)
            all_warnings.update(result.get("warnings", []))
        except SkillExporterError as e:
            results.append({"success": False, "format": fmt.value, "error": str(e)})

    success_count = sum(1 for r in results if r.get("success"))
    paths = {r["format"]: r.get("path") or r.get("would_create") for r in results if r.get("success")}
    return {
        "success": success_count > 0, "skill_name": skill_name, "format": "all",
        "exported_to": paths, "warnings": list(all_warnings), "results": results,
        "summary": f"Exported to {success_count}/{len(formats)} formats",
    }


def export_all_skills(
    format: ExportFormat, skills_dir: Path, project_dir: Path, dry_run: bool = False,
) -> List[Dict[str, Any]]:
    """Export all skills to target format."""
    if not skills_dir.exists():
        return []

    results = []
    for skill_dir in skills_dir.iterdir():
        if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
            try:
                results.append(export_skill(skill_dir.name, format, skills_dir, project_dir, dry_run))
            except SkillExporterError as e:
                results.append({"success": False, "skill_name": skill_dir.name, "error": str(e)})
    return results
