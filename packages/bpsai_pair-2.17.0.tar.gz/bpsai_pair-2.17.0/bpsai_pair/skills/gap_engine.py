"""Skill gap detection engine.

This module provides the SkillGapDetector class that analyzes
session logs to find repeated command patterns that could be automated.
"""

import re
from collections import Counter
from typing import Any, Dict, List

from .gap_models import SkillGap, TRIVIAL_PATTERNS, COMMAND_VERBS


class SkillGapDetector:
    """Detects potential skill gaps from session logs."""

    def __init__(
        self,
        existing_skills: List[str],
        pattern_threshold: int = 5,
        max_sequence_length: int = 5,
        min_sequence_length: int = 3,
    ):
        """Initialize detector.

        Args:
            existing_skills: List of existing skill names
            pattern_threshold: Minimum occurrences to detect as gap (default: 5)
            max_sequence_length: Maximum length of command sequences to detect
            min_sequence_length: Minimum length (2-step patterns blocked)
        """
        self.existing_skills = [s.lower() for s in existing_skills]
        self.pattern_threshold = pattern_threshold
        self.max_sequence_length = max_sequence_length
        self.min_sequence_length = min_sequence_length

    def analyze_session(self, session_log: List[Dict[str, Any]]) -> List[SkillGap]:
        """Analyze session log for potential skill gaps.

        Args:
            session_log: List of session messages with 'type' and 'content' keys

        Returns:
            List of detected skill gaps
        """
        if not session_log:
            return []

        commands = self._extract_commands(session_log)

        if len(commands) < self.pattern_threshold:
            return []

        patterns = self._detect_patterns(commands)

        gaps = []
        for pattern_tuple, count in patterns.items():
            pattern_list = list(pattern_tuple)
            suggested_name = self._generate_name(pattern_list)
            confidence = self._calculate_confidence(count, pattern_list)

            if self._has_matching_skill(pattern_list, suggested_name):
                confidence *= 0.3

            time_estimate = self._estimate_time_savings(count, len(pattern_list))

            gaps.append(SkillGap(
                pattern=pattern_list,
                suggested_name=suggested_name,
                confidence=confidence,
                frequency=count,
                time_saved_estimate=time_estimate,
            ))

        gaps.sort(key=lambda g: g.confidence, reverse=True)
        return gaps

    def _extract_commands(self, session_log: List[Dict[str, Any]]) -> List[str]:
        """Extract command strings from session log."""
        commands = []
        for msg in session_log:
            if msg.get("type") == "command":
                content = msg.get("content", "")
                if content:
                    commands.append(content.strip())
        return commands

    def _detect_patterns(self, commands: List[str]) -> Dict[tuple, int]:
        """Detect repeated command patterns."""
        pattern_counts: Dict[tuple, int] = Counter()

        for n in range(self.min_sequence_length, min(self.max_sequence_length + 1, len(commands) + 1)):
            for i in range(len(commands) - n + 1):
                pattern = tuple(commands[i:i + n])
                pattern_counts[pattern] += 1

        return {
            p: c for p, c in pattern_counts.items()
            if c >= self.pattern_threshold and not self._is_trivial_pattern(p)
        }

    def _is_trivial_pattern(self, pattern: tuple) -> bool:
        """Check if pattern is in the trivial blocklist."""
        normalized = tuple(cmd.lower().strip() for cmd in pattern)

        for trivial in TRIVIAL_PATTERNS:
            if len(normalized) == len(trivial):
                matches = all(
                    t in n or n in t
                    for t, n in zip(trivial, normalized)
                )
                if matches:
                    return True

        if len(normalized) == 2:
            test_words = {"pytest", "test", "npm test", "yarn test", "jest", "mocha"}
            fix_words = {"fix", "edit", "update", "change", "modify"}

            first_is_test = any(tw in normalized[0] for tw in test_words)
            second_is_fix = any(fw in normalized[1] for fw in fix_words)

            if first_is_test and second_is_fix:
                return True

        return False

    def _generate_name(self, pattern: List[str]) -> str:
        """Generate a skill name from a command pattern."""
        primary_verb = None
        for cmd in pattern:
            cmd_lower = cmd.lower()
            for key, verb in COMMAND_VERBS.items():
                if key in cmd_lower:
                    primary_verb = verb
                    break
            if primary_verb:
                break

        if not primary_verb:
            primary_verb = "managing"

        context_words = []
        for cmd in pattern:
            words = re.findall(r"[a-z]+", cmd.lower())
            for word in words:
                if word not in COMMAND_VERBS and len(word) > 2:
                    context_words.append(word)

        if context_words:
            context = Counter(context_words).most_common(1)[0][0]
            name = f"{primary_verb}-{context}"
        else:
            name = f"{primary_verb}-workflows"

        return name.lower()

    def _calculate_confidence(self, frequency: int, pattern: List[str]) -> float:
        """Calculate confidence score for a gap."""
        freq_score = min(frequency / 10, 0.5)
        length_bonus = min((len(pattern) - 1) * 0.1, 0.3)
        return min(freq_score + length_bonus + 0.2, 1.0)

    def _has_matching_skill(self, pattern: List[str], suggested_name: str) -> bool:
        """Check if pattern matches an existing skill."""
        name_words = set(suggested_name.split("-"))

        for skill in self.existing_skills:
            skill_words = set(skill.split("-"))

            common = name_words & skill_words
            if len(common) >= min(len(name_words), len(skill_words)) * 0.5:
                return True

            pattern_keywords = set()
            for cmd in pattern:
                pattern_keywords.update(re.findall(r"[a-z]+", cmd.lower()))

            if pattern_keywords & skill_words:
                return True

        return False

    def _estimate_time_savings(self, frequency: int, pattern_length: int) -> str:
        """Estimate time savings from automating this pattern."""
        estimated_seconds = frequency * pattern_length * 20

        if estimated_seconds < 60:
            return f"~{estimated_seconds} seconds per cycle"
        else:
            minutes = estimated_seconds // 60
            return f"~{minutes} min per cycle"
