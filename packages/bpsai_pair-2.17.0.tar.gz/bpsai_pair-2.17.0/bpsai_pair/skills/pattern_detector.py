"""Pattern detection in command sequences.

Extracted from suggestion.py for modular architecture.
"""

import logging
from collections import Counter
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Trivial patterns that should never become skills
TRIVIAL_PATTERNS = [
    ("pytest", "fix"),
    ("npm test", "fix"),
    ("yarn test", "fix"),
    ("make test", "fix"),
    ("jest", "fix"),
    ("mocha", "fix"),
    ("test", "fix"),
    ("test", "edit"),
    ("test", "update"),
    ("git add", "git commit"),
    ("git commit", "git push"),
    ("pip install", "python"),
    ("npm install", "npm run"),
    ("cargo build", "cargo run"),
]

# Generic commands that shouldn't form the basis of a skill
GENERIC_COMMANDS = {
    "pytest", "npm test", "yarn test", "make test", "go test", "cargo test",
    "jest", "mocha", "rspec",
    "git add", "git commit", "git push", "git pull", "git status", "git diff",
    "fix", "edit", "update", "change", "modify", "check", "run", "start", "stop",
}


_TEST_WORDS = {"pytest", "test", "npm test", "yarn test", "jest", "mocha", "go test", "cargo test"}
_FIX_WORDS = {"fix", "edit", "update", "change", "modify"}


def _is_test_fix_mix(normalized: list) -> bool:
    """Check if normalized commands are all test+fix combinations."""
    unique = set(normalized)
    return (
        all(
            any(tw in cmd for tw in _TEST_WORDS) or any(fw in cmd for fw in _FIX_WORDS)
            for cmd in unique
        )
        and any(any(tw in cmd for tw in _TEST_WORDS) for cmd in unique)
        and any(any(fw in cmd for fw in _FIX_WORDS) for cmd in unique)
    )


class PatternDetector:
    """Detects repeated patterns in command sequences."""

    def __init__(self, min_occurrences: int = 3, max_sequence_length: int = 5):
        self.min_occurrences = min_occurrences
        self.max_sequence_length = max_sequence_length

    def detect_patterns(self, history: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Detect patterns in command history."""
        if not history:
            return []

        commands = [entry.get("command", "") for entry in history if entry.get("command")]

        if len(commands) < self.min_occurrences:
            return []

        patterns = []

        for n in range(2, min(self.max_sequence_length + 1, len(commands) + 1)):
            ngram_counts = self._count_ngrams(commands, n)

            for ngram, count in ngram_counts.items():
                if count >= self.min_occurrences:
                    confidence = self._calculate_confidence(count, len(commands), n)
                    patterns.append({
                        "sequence": list(ngram),
                        "occurrences": count,
                        "confidence": confidence,
                        "sequence_length": n,
                    })

        patterns.sort(key=lambda p: (p["confidence"], p["occurrences"]), reverse=True)
        patterns = self._deduplicate_patterns(patterns)
        patterns = [p for p in patterns if not self._is_trivial_pattern(p["sequence"])]

        return patterns

    def _is_trivial_pattern(self, sequence: List[str]) -> bool:
        """Check if a pattern is too trivial to become a skill."""
        if not sequence:
            return True

        normalized = [cmd.lower().strip() for cmd in sequence]

        # Check exact matches in trivial patterns list
        for trivial in TRIVIAL_PATTERNS:
            if len(normalized) == len(trivial):
                matches = all(
                    t in n or n in t
                    for t, n in zip(trivial, normalized)
                )
                if matches:
                    logger.debug(f"Blocked trivial pattern: {sequence}")
                    return True

        # Block any 2-step pattern that's just "test" + "fix/edit/update"
        if len(normalized) == 2:
            first_is_test = any(tw in normalized[0] for tw in _TEST_WORDS)
            second_is_fix = any(fw in normalized[1] for fw in _FIX_WORDS)
            if first_is_test and second_is_fix:
                logger.debug(f"Blocked test+fix pattern: {sequence}")
                return True

        if _is_test_fix_mix(normalized):
            logger.debug(f"Blocked test+fix repetition pattern: {sequence}")
            return True

        # Block patterns where all commands are generic (too basic)
        generic_count = sum(1 for cmd in normalized if any(g in cmd for g in GENERIC_COMMANDS))
        if generic_count == len(normalized) and len(normalized) <= 2:
            logger.debug(f"Blocked all-generic pattern: {sequence}")
            return True

        return False

    def _count_ngrams(self, commands: List[str], n: int) -> Counter:
        """Count n-gram occurrences in command sequence."""
        ngrams = []
        for i in range(len(commands) - n + 1):
            ngram = tuple(commands[i:i + n])
            ngrams.append(ngram)
        return Counter(ngrams)

    def _calculate_confidence(self, count: int, total_commands: int, sequence_length: int) -> int:
        """Calculate confidence score for a pattern."""
        frequency_score = min(count / self.min_occurrences * 50, 50)
        length_bonus = min((sequence_length - 1) * 10, 30)
        coverage_score = min(count * sequence_length / total_commands * 20, 20)
        return min(int(frequency_score + length_bonus + coverage_score), 100)

    def _deduplicate_patterns(self, patterns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Remove redundant patterns (subsets of longer patterns)."""
        if len(patterns) <= 1:
            return patterns

        result = []
        seen_sequences = set()

        for pattern in patterns:
            seq_tuple = tuple(pattern["sequence"])

            is_subset = False
            for seen in seen_sequences:
                if len(seq_tuple) < len(seen):
                    seen_str = " ".join(seen)
                    seq_str = " ".join(seq_tuple)
                    if seq_str in seen_str:
                        is_subset = True
                        break

            if not is_subset:
                result.append(pattern)
                seen_sequences.add(seq_tuple)

        return result
