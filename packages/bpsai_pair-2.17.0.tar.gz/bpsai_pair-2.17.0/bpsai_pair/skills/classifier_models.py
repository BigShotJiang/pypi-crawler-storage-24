"""
Data models for gap classification.

Contains all dataclasses, enums, and type containers used by the
gap classifier engine and reporting functions.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from .gap_detector import SkillGap
from .subagent_detector import SubagentGap


class GapType(Enum):
    """Classification result for a gap."""

    SKILL = "skill"
    SUBAGENT = "subagent"
    AMBIGUOUS = "ambiguous"  # Could be either, user decides


@dataclass
class ClassificationScores:
    """Scores used for gap classification."""

    portability: float = 0.0  # Higher = skill
    isolation: float = 0.0  # Higher = subagent
    persona: float = 0.0  # Higher = subagent
    resumability: float = 0.0  # Higher = subagent
    simplicity: float = 0.0  # Higher = skill


@dataclass
class SkillRecommendation:
    """Skill-specific recommendation details."""

    suggested_name: str  # gerund form
    allowed_tools: Optional[List[str]] = None
    estimated_portability: List[str] = field(
        default_factory=lambda: ["claude-code", "cursor", "continue"]
    )


@dataclass
class SubagentRecommendation:
    """Subagent-specific recommendation details."""

    suggested_name: str  # kebab-case
    suggested_model: Optional[str] = None
    suggested_tools: Optional[List[str]] = None
    persona_hint: Optional[str] = None


@dataclass
class ClassifiedGap:
    """A gap that has been classified as skill, subagent, or ambiguous."""

    id: str
    gap_type: GapType
    confidence: float
    reasoning: str  # Human-readable explanation

    # Original gap data
    suggested_name: str
    description: str
    source_commands: List[str] = field(default_factory=list)
    occurrence_count: int = 0

    # Classification factors (scores 0-1)
    portability_score: float = 0.0
    isolation_score: float = 0.0
    persona_score: float = 0.0
    resumability_score: float = 0.0
    simplicity_score: float = 0.0

    # Recommendations
    skill_recommendation: Optional[SkillRecommendation] = None
    subagent_recommendation: Optional[SubagentRecommendation] = None

    # Metadata
    classified_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "id": self.id,
            "gap_type": self.gap_type.value,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "suggested_name": self.suggested_name,
            "description": self.description,
            "source_commands": self.source_commands,
            "occurrence_count": self.occurrence_count,
            "scores": {
                "portability": self.portability_score,
                "isolation": self.isolation_score,
                "persona": self.persona_score,
                "resumability": self.resumability_score,
                "simplicity": self.simplicity_score,
            },
            "classified_at": self.classified_at,
        }

        if self.skill_recommendation:
            result["skill_recommendation"] = {
                "suggested_name": self.skill_recommendation.suggested_name,
                "allowed_tools": self.skill_recommendation.allowed_tools,
                "estimated_portability": self.skill_recommendation.estimated_portability,
            }

        if self.subagent_recommendation:
            result["subagent_recommendation"] = {
                "suggested_name": self.subagent_recommendation.suggested_name,
                "suggested_model": self.subagent_recommendation.suggested_model,
                "suggested_tools": self.subagent_recommendation.suggested_tools,
                "persona_hint": self.subagent_recommendation.persona_hint,
            }

        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ClassifiedGap":
        """Create ClassifiedGap from dictionary."""
        scores = data.get("scores", {})

        skill_rec = None
        if "skill_recommendation" in data:
            rec = data["skill_recommendation"]
            skill_rec = SkillRecommendation(
                suggested_name=rec.get("suggested_name", ""),
                allowed_tools=rec.get("allowed_tools"),
                estimated_portability=rec.get(
                    "estimated_portability", ["claude-code"]
                ),
            )

        subagent_rec = None
        if "subagent_recommendation" in data:
            rec = data["subagent_recommendation"]
            subagent_rec = SubagentRecommendation(
                suggested_name=rec.get("suggested_name", ""),
                suggested_model=rec.get("suggested_model"),
                suggested_tools=rec.get("suggested_tools"),
                persona_hint=rec.get("persona_hint"),
            )

        return cls(
            id=data.get("id", ""),
            gap_type=GapType(data.get("gap_type", "skill")),
            confidence=data.get("confidence", 0.0),
            reasoning=data.get("reasoning", ""),
            suggested_name=data.get("suggested_name", ""),
            description=data.get("description", ""),
            source_commands=data.get("source_commands", []),
            occurrence_count=data.get("occurrence_count", 0),
            portability_score=scores.get("portability", 0.0),
            isolation_score=scores.get("isolation", 0.0),
            persona_score=scores.get("persona", 0.0),
            resumability_score=scores.get("resumability", 0.0),
            simplicity_score=scores.get("simplicity", 0.0),
            skill_recommendation=skill_rec,
            subagent_recommendation=subagent_rec,
            classified_at=data.get("classified_at", datetime.now().isoformat()),
        )


@dataclass
class AllGaps:
    """Container for both skill and subagent gaps."""

    skills: List[SkillGap] = field(default_factory=list)
    subagents: List[SubagentGap] = field(default_factory=list)
