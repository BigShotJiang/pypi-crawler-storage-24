"""Skill score CLI command.

Commands:
- skill_score_cmd(): Score skills on quality dimensions
"""

from typing import Optional

import typer


def _hub():
    """Lazy import the hub module for mock compatibility."""
    from bpsai_pair.skills import skill_commands as _cmds
    return _cmds


def skill_score_cmd(
    skill_name: Optional[str] = typer.Argument(None, help="Specific skill to score"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Score skills on quality dimensions.

    Evaluates skills on token efficiency, trigger clarity, completeness,
    usage frequency, and portability.

    Examples:

        # Score all skills
        bpsai-pair skill score

        # Score specific skill
        bpsai-pair skill score implementing-with-tdd

        # Output as JSON
        bpsai-pair skill score --json
    """
    import json
    _cmds = _hub()

    try:
        skills_dir = _cmds.find_skills_dir()
    except FileNotFoundError:
        _cmds.console.print("[red]Could not find .claude/skills directory[/red]")
        raise typer.Exit(1)

    scorer = _cmds.SkillScorer(skills_dir)

    if skill_name:
        _score_single(_cmds, scorer, skill_name, json_out)
    else:
        _score_all(_cmds, scorer, json_out)


def _score_single(_cmds, scorer, skill_name: str, json_out: bool) -> None:
    """Score a single skill by name."""
    import json

    score = scorer.score_skill(skill_name)
    if not score:
        _cmds.console.print(f"[red]Skill not found: {skill_name}[/red]")
        raise typer.Exit(1)

    if json_out:
        _cmds.console.print(json.dumps(score.to_dict(), indent=2))
        return

    _cmds.display_skill_score(score)


def _score_all(_cmds, scorer, json_out: bool) -> None:
    """Score all skills."""
    import json

    scores = scorer.score_all()

    if not scores:
        _cmds.console.print("[dim]No skills found to score.[/dim]")
        return

    if json_out:
        output = {
            "skills": [s.to_dict() for s in scores],
            "total": len(scores),
            "average_score": sum(s.overall_score for s in scores) // len(scores),
        }
        _cmds.console.print(json.dumps(output, indent=2))
        return

    _cmds.display_score_table(scores)
