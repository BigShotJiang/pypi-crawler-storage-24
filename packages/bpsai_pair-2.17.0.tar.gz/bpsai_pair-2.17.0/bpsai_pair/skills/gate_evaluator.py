"""Gate evaluation engine for gap quality assessment.

Contains GapQualityGate class with individual gate checks
(redundancy, novelty, complexity, time value) and helpers.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from .classifier import ClassifiedGap
from .gap_detector import SkillGap
from .gate_definitions import (
    GENERIC_COMMANDS,
    GENERIC_PATTERNS,
    TRIVIAL_PATTERN_PAIRS,
    GateResult,
    GateStatus,
    QualityGateResult,
)
from .subagent_detector import SubagentGap


class GapQualityGate:
    """Quality gate for evaluating gaps before skill generation."""

    REDUNDANCY_THRESHOLD = 0.4
    NOVELTY_THRESHOLD = 0.4
    COMPLEXITY_THRESHOLD = 0.4
    TIME_VALUE_THRESHOLD = 0.4

    MIN_COMMANDS = 3
    MIN_PATTERN_LENGTH = 3
    MIN_TIME_SAVINGS_MINUTES = 5
    MIN_OCCURRENCES = 5

    def __init__(
        self,
        existing_skills: Optional[List[str]] = None,
        skills_dir: Optional[Path] = None,
    ):
        self.existing_skills = [s.lower() for s in (existing_skills or [])]
        self.skills_dir = skills_dir
        self._skill_content_cache: Dict[str, str] = {}

    def _extract_gap_info(
        self, gap: Union[SkillGap, SubagentGap, ClassifiedGap],
    ) -> Tuple[str, str, List[str], int]:
        """Extract (gap_id, gap_name, source_commands, occurrence_count)."""
        if isinstance(gap, ClassifiedGap):
            return gap.id, gap.suggested_name, gap.source_commands, gap.occurrence_count
        elif isinstance(gap, SkillGap):
            return f"skill-{gap.suggested_name}", gap.suggested_name, gap.pattern, gap.frequency
        else:
            return gap.id, gap.suggested_name, gap.source_commands, gap.occurrence_count

    def _make_rejection(
        self, gap_id: str, gap_name: str,
        gate_result: GateResult, recommendation: str,
    ) -> QualityGateResult:
        """Create a BLOCK QualityGateResult for early rejection."""
        return QualityGateResult(
            gap_id=gap_id, gap_name=gap_name,
            overall_status=GateStatus.BLOCK,
            gate_results=[gate_result],
            recommendation=recommendation,
            can_generate=False,
        )

    def _check_early_rejections(
        self, gap_id: str, gap_name: str,
        source_commands: List[str], occurrence_count: int,
    ) -> Optional[QualityGateResult]:
        """Check for early rejection conditions (trivial, short, low occurrence)."""
        trivial = self._check_trivial_pattern(source_commands)
        if trivial:
            return self._make_rejection(
                gap_id, gap_name, trivial,
                f"BLOCKED: {trivial.reason}. Pattern too simple to be a skill.",
            )
        if len(source_commands) < self.MIN_PATTERN_LENGTH:
            return self._make_rejection(
                gap_id, gap_name,
                GateResult("pattern_length", GateStatus.BLOCK, 0.0,
                           f"Pattern has only {len(source_commands)} steps (min: {self.MIN_PATTERN_LENGTH})",
                           "2-step patterns are too simple to warrant skills"),
                "BLOCKED: Pattern too short. Skills need 3+ distinct steps.",
            )
        if occurrence_count < self.MIN_OCCURRENCES:
            return self._make_rejection(
                gap_id, gap_name,
                GateResult("occurrence_count", GateStatus.BLOCK, 0.0,
                           f"Only {occurrence_count} occurrences (min: {self.MIN_OCCURRENCES})",
                           "Need more evidence before creating a skill"),
                f"BLOCKED: Pattern only seen {occurrence_count} times. Need {self.MIN_OCCURRENCES}+ occurrences.",
            )
        return None

    def evaluate(
        self, gap: Union[SkillGap, SubagentGap, ClassifiedGap],
    ) -> QualityGateResult:
        """Evaluate a gap against all quality gates."""
        gap_id, gap_name, source_commands, occurrence_count = self._extract_gap_info(gap)

        rejection = self._check_early_rejections(gap_id, gap_name, source_commands, occurrence_count)
        if rejection:
            return rejection

        gate_results = [
            self._check_redundancy(gap_name, source_commands),
            self._check_novelty(source_commands),
            self._check_complexity(source_commands),
            self._check_time_value(source_commands, occurrence_count),
        ]

        if any(g.status == GateStatus.BLOCK for g in gate_results):
            overall_status, can_generate = GateStatus.BLOCK, False
        elif any(g.status == GateStatus.WARN for g in gate_results):
            overall_status, can_generate = GateStatus.WARN, True
        else:
            overall_status, can_generate = GateStatus.PASS, True

        return QualityGateResult(
            gap_id=gap_id, gap_name=gap_name,
            overall_status=overall_status, gate_results=gate_results,
            recommendation=self._generate_recommendation(gate_results, overall_status),
            can_generate=can_generate,
        )

    def _check_trivial_pattern(self, source_commands: List[str]) -> Optional[GateResult]:
        """Check if pattern matches a known trivial pattern pair."""
        if len(source_commands) < 2:
            return None

        normalized = [cmd.lower().strip() for cmd in source_commands]

        if len(normalized) == 2:
            first, second = normalized[0], normalized[1]
            for first_set, second_set in TRIVIAL_PATTERN_PAIRS:
                first_matches = any(f in first or first in f for f in first_set)
                second_matches = any(s in second or second in s for s in second_set)
                if first_matches and second_matches:
                    return GateResult(
                        "trivial_pattern", GateStatus.BLOCK, 0.0,
                        f"Trivial pattern: '{first}' + '{second}'",
                        "This is just normal development workflow, not a skill",
                    )

        # Check for "test + fix" pattern regardless of length
        test_cmds = {"pytest", "test", "jest", "mocha", "npm test", "yarn test", "cargo test", "go test"}
        fix_cmds = {"fix", "edit", "update", "change", "modify", "patch"}
        has_test = any(any(t in cmd for t in test_cmds) for cmd in normalized)
        has_fix = any(any(f in cmd for f in fix_cmds) for cmd in normalized)

        if has_test and has_fix and len(normalized) == 2:
            return GateResult(
                "trivial_pattern", GateStatus.BLOCK, 0.0,
                "Pattern is just 'test + fix' - basic development, not a skill",
                "Running tests and fixing failures is universal developer knowledge",
            )
        return None

    def _compute_name_overlap(self, gap_name: str) -> Tuple[float, Optional[str]]:
        """Compute max name overlap with existing skills."""
        gap_words = set(gap_name.lower().split("-"))
        max_overlap = 0.0
        overlapping_skill = None
        for skill in self.existing_skills:
            skill_words = set(skill.split("-"))
            if gap_words & skill_words:
                overlap = len(gap_words & skill_words) / max(len(gap_words), len(skill_words))
                if overlap > max_overlap:
                    max_overlap = overlap
                    overlapping_skill = skill
        return max_overlap, overlapping_skill

    def _check_redundancy(self, gap_name: str, source_commands: List[str]) -> GateResult:
        """Check if gap overlaps with existing skills."""
        if not self.existing_skills:
            return GateResult("redundancy", GateStatus.PASS, 1.0, "No existing skills to compare")

        max_overlap, overlapping_skill = self._compute_name_overlap(gap_name)

        # Check command overlap with skill content
        if self.skills_dir and overlapping_skill:
            skill_content = self._get_skill_content(overlapping_skill)
            if skill_content:
                command_overlap = self._calculate_command_overlap(source_commands, skill_content)
                max_overlap = max(max_overlap, command_overlap)

        score = 1.0 - max_overlap
        if score < self.REDUNDANCY_THRESHOLD:
            return GateResult("redundancy", GateStatus.BLOCK, score,
                              f"High overlap with '{overlapping_skill}'",
                              f"Overlap: {max_overlap:.0%}. Consider extending existing skill instead.")
        elif score < 0.6:
            return GateResult("redundancy", GateStatus.WARN, score,
                              f"Partial overlap with '{overlapping_skill}'",
                              "May duplicate existing functionality")
        return GateResult("redundancy", GateStatus.PASS, score,
                          "No significant overlap with existing skills")

    def _count_generic_ratio(self, source_commands: List[str]) -> float:
        """Count ratio of generic commands in source_commands."""
        generic_count = 0
        for cmd in source_commands:
            cmd_lower = cmd.lower().strip()
            if cmd_lower in GENERIC_COMMANDS:
                generic_count += 1
                continue
            cmd_words = set(cmd_lower.split())
            if cmd_words & GENERIC_COMMANDS:
                generic_count += 0.5
                continue
            for pattern in GENERIC_PATTERNS:
                if re.match(pattern, cmd_lower):
                    generic_count += 0.7
                    break
        return generic_count / len(source_commands) if source_commands else 1.0

    def _check_novelty(self, source_commands: List[str]) -> GateResult:
        """Check if commands are novel (not just generic)."""
        if not source_commands:
            return GateResult("novelty", GateStatus.BLOCK, 0.0, "No commands to analyze")

        generic_ratio = self._count_generic_ratio(source_commands)
        score = 1.0 - generic_ratio
        total = len(source_commands)
        generic_count = int(generic_ratio * total)

        if score < self.NOVELTY_THRESHOLD:
            return GateResult("novelty", GateStatus.BLOCK, score,
                              "Pattern contains only generic commands",
                              f"{generic_count}/{total} commands are generic developer knowledge")
        elif score < 0.5:
            return GateResult("novelty", GateStatus.WARN, score,
                              "Pattern contains mostly generic commands",
                              "Consider whether this adds unique value")
        return GateResult("novelty", GateStatus.PASS, score,
                          "Pattern contains novel/specialized commands")

    def _check_complexity(self, source_commands: List[str]) -> GateResult:
        """Check if pattern is complex enough for a skill."""
        distinct = len(set(cmd.strip().lower() for cmd in source_commands))
        if distinct >= 5:
            score = 1.0
        elif distinct >= self.MIN_COMMANDS:
            score = 0.5 + (distinct - self.MIN_COMMANDS) * 0.25
        else:
            score = distinct / self.MIN_COMMANDS * 0.3

        if score < self.COMPLEXITY_THRESHOLD:
            return GateResult("complexity", GateStatus.BLOCK, score,
                              f"Only {distinct} distinct commands (min: {self.MIN_COMMANDS})",
                              "Pattern too simple to warrant a skill")
        elif score < 0.5:
            return GateResult("complexity", GateStatus.WARN, score,
                              f"{distinct} commands - borderline complexity",
                              "Consider if more steps should be included")
        return GateResult("complexity", GateStatus.PASS, score,
                          f"{distinct} distinct commands - good complexity")

    def _check_time_value(self, source_commands: List[str], occurrence_count: int) -> GateResult:
        """Check if pattern provides meaningful time savings."""
        seconds_per_command = 20
        savings_per_use = len(source_commands) * seconds_per_command
        minutes_saved = savings_per_use * occurrence_count / 60

        if minutes_saved >= 10:
            score = 1.0
        elif minutes_saved >= self.MIN_TIME_SAVINGS_MINUTES:
            score = 0.5 + (minutes_saved - self.MIN_TIME_SAVINGS_MINUTES) * 0.1
        else:
            score = minutes_saved / self.MIN_TIME_SAVINGS_MINUTES * 0.3

        if score < self.TIME_VALUE_THRESHOLD:
            return GateResult("time_value", GateStatus.BLOCK, score,
                              f"Only ~{minutes_saved:.1f} min saved (min: {self.MIN_TIME_SAVINGS_MINUTES})",
                              "Automation overhead exceeds time savings")
        elif score < 0.5:
            return GateResult("time_value", GateStatus.WARN, score,
                              f"~{minutes_saved:.1f} min saved - marginal value",
                              "Consider if pattern frequency will increase")
        return GateResult("time_value", GateStatus.PASS, score,
                          f"~{minutes_saved:.1f} min saved - good time value")

    def _get_skill_content(self, skill_name: str) -> Optional[str]:
        """Get content of an existing skill."""
        if skill_name in self._skill_content_cache:
            return self._skill_content_cache[skill_name]
        if not self.skills_dir:
            return None
        skill_file = self.skills_dir / skill_name / "SKILL.md"
        if skill_file.exists():
            try:
                content = skill_file.read_text(encoding="utf-8")
                self._skill_content_cache[skill_name] = content
                return content
            except (OSError, IOError):
                pass
        return None

    def _calculate_command_overlap(self, commands: List[str], skill_content: str) -> float:
        """Calculate overlap between commands and skill content."""
        content_lower = skill_content.lower()
        matches = 0
        for cmd in commands:
            cmd_lower = cmd.lower()
            if cmd_lower in content_lower:
                matches += 1
            else:
                words = cmd_lower.split()
                word_matches = sum(1 for w in words if w in content_lower and len(w) > 3)
                if word_matches >= len(words) * 0.5:
                    matches += 0.5
        return matches / len(commands) if commands else 0.0

    def _generate_recommendation(
        self, gate_results: List[GateResult], overall_status: GateStatus,
    ) -> str:
        """Generate a recommendation based on gate results."""
        if overall_status == GateStatus.PASS:
            return "Ready for auto-generation. Pattern meets all quality criteria."
        blocked = [g for g in gate_results if g.status == GateStatus.BLOCK]
        warnings = [g for g in gate_results if g.status == GateStatus.WARN]
        if blocked:
            return f"BLOCKED: {'; '.join(g.reason for g in blocked)}. Use --force to override."
        if warnings:
            return f"WARNINGS: {'; '.join(g.reason for g in warnings)}. Review before generating."
        return "Evaluation complete."
