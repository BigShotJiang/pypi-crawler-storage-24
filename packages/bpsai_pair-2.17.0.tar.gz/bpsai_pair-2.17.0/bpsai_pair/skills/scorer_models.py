"""Skill scoring data models."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List


@dataclass
class DimensionScore:
    """Score for a single quality dimension."""

    name: str
    weight: float
    score: float  # 0.0 to 1.0
    reason: str
    recommendations: List[str] = field(default_factory=list)

    @property
    def weighted_score(self) -> float:
        """Get weighted contribution to overall score."""
        return self.score * self.weight

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "weight": self.weight,
            "score": self.score,
            "weighted_score": self.weighted_score,
            "reason": self.reason,
            "recommendations": self.recommendations,
        }


@dataclass
class SkillScore:
    """Complete quality score for a skill."""

    skill_name: str
    skill_path: Path
    overall_score: int  # 0-100
    dimensions: List[DimensionScore]
    recommendations: List[str]
    grade: str  # A, B, C, D, F

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "skill_name": self.skill_name,
            "skill_path": str(self.skill_path),
            "overall_score": self.overall_score,
            "grade": self.grade,
            "dimensions": [d.to_dict() for d in self.dimensions],
            "recommendations": self.recommendations,
        }
