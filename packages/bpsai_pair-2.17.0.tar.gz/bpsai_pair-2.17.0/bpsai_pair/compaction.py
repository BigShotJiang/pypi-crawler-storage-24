"""Compaction detection and recovery for PairCoder."""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from .compaction_models import CompactionSnapshot, CompactionMarker
from .compaction_recovery import (
    parse_state_for_snapshot,
    read_containment_config,
    recover_state_context,
    recover_from_snapshot,
)
from .compaction_helpers import (
    get_recent_files,
    save_marker,
    log_compaction,
    list_snapshots as _list_snapshots,
    cleanup_old_snapshots as _cleanup_old_snapshots,
)

__all__ = ["CompactionSnapshot", "CompactionMarker", "CompactionManager"]

logger = logging.getLogger(__name__)


class CompactionManager:
    """Manages compaction detection and recovery."""

    def __init__(self, paircoder_dir: Path):
        """Initialize with path to .paircoder directory."""
        self.paircoder_dir = Path(paircoder_dir)
        self.cache_dir = self.paircoder_dir / "cache"
        self.history_dir = self.paircoder_dir / "history"
        self.context_dir = self.paircoder_dir / "context"
        self.marker_file = self.cache_dir / "compaction_marker.json"
        self.compaction_log = self.history_dir / "compaction.log"

        # Ensure directories exist
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.history_dir.mkdir(parents=True, exist_ok=True)

    def save_snapshot(
        self, trigger: str = "manual", reason: Optional[str] = None
    ) -> Path:
        """Save a compaction snapshot with current context."""
        now = datetime.now()
        snapshot = self._create_snapshot_from_state(now, trigger)
        snapshot.recent_files = get_recent_files(self.history_dir)
        snapshot.containment = read_containment_config(self.paircoder_dir)

        filename = f"compaction_snapshot_{now.strftime('%Y%m%d_%H%M%S')}.json"
        snapshot_path = self.cache_dir / filename

        with open(snapshot_path, "w", encoding="utf-8") as f:
            json.dump(snapshot.to_dict(), f, indent=2)

        marker = CompactionMarker(
            timestamp=now, trigger=trigger, recovered=False, snapshot_file=filename
        )
        save_marker(self.marker_file, marker)
        log_compaction(self.compaction_log, trigger, reason, snapshot_path)
        return snapshot_path

    def _create_snapshot_from_state(
        self, timestamp: datetime, trigger: str
    ) -> CompactionSnapshot:
        """Create a snapshot by parsing state.md."""
        snapshot = CompactionSnapshot(timestamp=timestamp, trigger=trigger)
        state_path = self.context_dir / "state.md"
        if not state_path.exists():
            return snapshot
        try:
            content = state_path.read_text(encoding="utf-8")
            snapshot = parse_state_for_snapshot(content, timestamp, trigger)
        except IOError as e:
            logger.warning(f"Failed to read state.md: {e}")
        return snapshot

    def check_compaction(self) -> Optional[CompactionMarker]:
        """Check if compaction recently occurred and needs recovery."""
        if not self.marker_file.exists():
            return None
        try:
            with open(self.marker_file, encoding="utf-8") as f:
                data = json.load(f)
            marker = CompactionMarker.from_dict(data)
            if not marker.recovered:
                return marker
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            logger.warning(f"Failed to read compaction marker: {e}")
        return None

    def recover_context(self) -> str:
        """Recover context after compaction."""
        lines: List[str] = [
            "Context compaction detected. Restoring from state.md...", ""
        ]
        lines.extend(recover_state_context(self.context_dir, self.paircoder_dir))

        marker = self.check_compaction()
        if marker and marker.snapshot_file:
            lines.extend(
                recover_from_snapshot(
                    self.cache_dir, self.paircoder_dir, marker.snapshot_file
                )
            )

        lines.append("")
        lines.append("Note: Some conversation details were compacted.")
        lines.append("Run `bpsai-pair status` for full project status.")

        if marker:
            marker.recovered = True
            save_marker(self.marker_file, marker)
        return "\n".join(lines)

    def list_snapshots(self) -> List[CompactionSnapshot]:
        """List all available compaction snapshots."""
        return _list_snapshots(self.cache_dir)

    def cleanup_old_snapshots(self, keep: int = 5) -> int:
        """Remove old snapshots, keeping the most recent."""
        return _cleanup_old_snapshots(self.cache_dir, keep)
