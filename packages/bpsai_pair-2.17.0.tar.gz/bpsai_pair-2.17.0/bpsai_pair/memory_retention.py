"""Memory retention policy — archive stale agent memory files."""

from __future__ import annotations

import logging
import shutil
import time
from pathlib import Path

logger = logging.getLogger(__name__)

DEFAULT_MAX_AGE_DAYS = 60


class MemoryRetentionPolicy:
    """Archive agent memory files older than a configurable threshold."""

    def __init__(self, memory_dir: Path) -> None:
        self._dir = memory_dir

    def cleanup(self, max_age_days: int = DEFAULT_MAX_AGE_DAYS) -> int:
        """Archive memory files older than *max_age_days*. Returns count archived."""
        if not self._dir.exists():
            return 0
        cutoff = time.time() - (max_age_days * 86400)
        archived = 0
        for role_dir in self._dir.iterdir():
            if not role_dir.is_dir() or role_dir.name == "archived":
                continue
            for memory_file in role_dir.glob("*.md"):
                if memory_file.name == "MEMORY.md":
                    continue
                if memory_file.stat().st_mtime < cutoff:
                    self._archive(memory_file)
                    archived += 1
        return archived

    def _archive(self, path: Path) -> None:
        """Move *path* into an ``archived/`` subdirectory beside it."""
        archive_dir = path.parent / "archived"
        archive_dir.mkdir(exist_ok=True)
        dest = archive_dir / path.name
        shutil.move(str(path), str(dest))
        logger.info("Archived memory: %s", path.name)

    def stats(self) -> dict:
        """Return memory file statistics per role directory."""
        result: dict = {"roles": {}, "total_files": 0}
        if not self._dir.exists():
            return result
        total = 0
        for role_dir in self._dir.iterdir():
            if not role_dir.is_dir() or role_dir.name == "archived":
                continue
            files = list(role_dir.glob("*.md"))
            count = len(files)
            total += count
            result["roles"][role_dir.name] = {"file_count": count}
        result["total_files"] = total
        return result
