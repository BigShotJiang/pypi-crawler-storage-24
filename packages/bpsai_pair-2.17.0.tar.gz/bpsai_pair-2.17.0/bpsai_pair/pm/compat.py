"""Backward compatibility layer and config migration for PM abstraction."""

from __future__ import annotations

from bpsai_pair.licensing.core import FeatureNotAvailable, get_tier, has_feature_api
from bpsai_pair.pm.presets import load_preset
from bpsai_pair.pm.workflow import WorkflowConfig
from bpsai_pair.pm.workflow_validation import merge_workflow, validate_workflow


def load_pm_config(raw_config: dict) -> tuple[str, WorkflowConfig]:
    """Detect config style and return (provider_name, WorkflowConfig).

    Resolution order:
    1. ``pm:`` section (new style) takes precedence
    2. ``trello:`` section (old style) as fallback
    3. Default to ("none", WorkflowConfig.local_only())
    """
    if "pm" in raw_config:
        provider, workflow, is_custom = _load_new_style(raw_config["pm"])
    elif "trello" in raw_config:
        provider, workflow, is_custom = _load_old_style(raw_config["trello"])
    else:
        return "none", WorkflowConfig.local_only()

    _check_feature_gates(workflow, is_custom)
    return provider, workflow


def migrate_trello_config(trello_config: dict) -> dict:
    """Convert a legacy trello config dict to a workflow-compatible dict.

    For simple cases (no board_structure), returns the simple preset
    equivalent. For configs with board_structure.lists, converts those
    to status mappings.
    """
    result: dict = {
        "mode": "simple",
        "work_items": {"task": {"name": "task", "label": "Task"}},
        "statuses": {},
        "transitions": {},
    }

    board = trello_config.get("board_structure", {})
    lists_map = board.get("lists", {})
    if lists_map:
        result["statuses"] = dict(lists_map)

    automation = trello_config.get("automation", [])
    if automation:
        result["automations"] = list(automation)

    return result


# -- Internal helpers ------------------------------------------------------


def _load_new_style(
    pm_section: dict,
) -> tuple[str, WorkflowConfig, bool]:
    """Parse new-style ``pm:`` config section."""
    provider = pm_section.get("provider", "none")
    workflow_val = pm_section.get("workflow", "simple")

    if isinstance(workflow_val, str):
        return provider, load_preset(workflow_val), False

    # Dict: check for preset+overrides pattern
    if "preset" in workflow_val:
        overrides = {k: v for k, v in workflow_val.items() if k != "preset"}
        base = load_preset(workflow_val["preset"])
        merged = merge_workflow(base, overrides)
        errors = validate_workflow(merged)
        if errors:
            raise ValueError("Invalid workflow config: " + "; ".join(errors))
        return provider, merged, True

    # Plain dict config
    config = WorkflowConfig.from_dict(workflow_val)
    errors = validate_workflow(config)
    if errors:
        raise ValueError("Invalid workflow config: " + "; ".join(errors))
    return provider, config, True


def _load_old_style(
    trello_section: dict,
) -> tuple[str, WorkflowConfig, bool]:
    """Parse old-style ``trello:`` config section."""
    if not trello_section.get("enabled", False):
        return "none", WorkflowConfig.local_only(), False

    return "trello", WorkflowConfig.simple(), False


def _check_feature_gates(workflow: WorkflowConfig, is_custom: bool) -> None:
    """Raise FeatureNotAvailable if the workflow exceeds the license."""
    tier = get_tier()

    if is_custom and not has_feature_api("pm_custom_workflow"):
        raise FeatureNotAvailable("pm_custom_workflow", tier)

    if workflow.has_hierarchy and not has_feature_api("pm_hierarchy"):
        raise FeatureNotAvailable("pm_hierarchy", tier)

    if workflow.has_automations and not has_feature_api("pm_automations"):
        raise FeatureNotAvailable("pm_automations", tier)
