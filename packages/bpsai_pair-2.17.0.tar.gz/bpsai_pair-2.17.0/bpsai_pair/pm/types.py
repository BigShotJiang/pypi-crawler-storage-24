"""Core PM data types shared by all providers and consumers."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


# ── Enums ───────────────────────────────────────────────────────────


class WorkItemType(str, Enum):
    """Type of work item in the PM hierarchy."""

    TASK = "task"
    STORY = "story"
    EPIC = "epic"


class WorkItemStatus(str, Enum):
    """Provider-agnostic work item status."""

    PENDING = "pending"
    PLANNING = "planning"
    ENQUEUED = "enqueued"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    TESTING = "testing"
    DONE = "done"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"


class RelationshipType(str, Enum):
    """Type of relationship between work items."""

    PARENT_CHILD = "parent_child"
    BLOCKS = "blocks"
    RELATES_TO = "relates_to"


class SyncAction(str, Enum):
    """Outcome of a sync operation on a single item."""

    CREATED = "created"
    UPDATED = "updated"
    SKIPPED = "skipped"
    ERROR = "error"


class FieldType(str, Enum):
    """Type of a custom field."""

    TEXT = "text"
    DROPDOWN = "dropdown"
    CHECKBOX = "checkbox"
    NUMBER = "number"


# ── Small value types ───────────────────────────────────────────────


@dataclass
class PMChecklistItem:
    """A single checklist/acceptance-criteria item."""

    id: str
    name: str
    checked: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "name": self.name, "checked": self.checked}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PMChecklistItem:
        return cls(
            id=data["id"],
            name=data["name"],
            checked=data.get("checked", False),
        )


@dataclass
class PMCustomField:
    """A custom field on a work item."""

    name: str
    field_type: FieldType
    value: Any = None
    options: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "field_type": self.field_type.value,
            "value": self.value,
            "options": self.options,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PMCustomField:
        return cls(
            name=data["name"],
            field_type=FieldType(data["field_type"]),
            value=data.get("value"),
            options=data.get("options", []),
        )


@dataclass
class PMRelationship:
    """A directed relationship between two work items."""

    source_id: str
    target_id: str
    relationship_type: RelationshipType

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "relationship_type": self.relationship_type.value,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PMRelationship:
        return cls(
            source_id=data["source_id"],
            target_id=data["target_id"],
            relationship_type=RelationshipType(data["relationship_type"]),
        )


# ── Sync types ──────────────────────────────────────────────────────


@dataclass
class SyncConflict:
    """A field-level conflict detected during sync."""

    field: str
    local_value: Any
    remote_value: Any
    resolution: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "field": self.field,
            "local_value": self.local_value,
            "remote_value": self.remote_value,
            "resolution": self.resolution,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SyncConflict:
        return cls(
            field=data["field"],
            local_value=data["local_value"],
            remote_value=data["remote_value"],
            resolution=data.get("resolution"),
        )


@dataclass
class SyncResult:
    """Result of syncing a single work item."""

    item_id: str
    action: SyncAction
    changes: dict[str, Any] = field(default_factory=dict)
    conflicts: list[SyncConflict] = field(default_factory=list)
    error: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "item_id": self.item_id,
            "action": self.action.value,
            "changes": self.changes,
            "conflicts": [c.to_dict() for c in self.conflicts],
            "error": self.error,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SyncResult:
        return cls(
            item_id=data["item_id"],
            action=SyncAction(data["action"]),
            changes=data.get("changes", {}),
            conflicts=[
                SyncConflict.from_dict(c) for c in data.get("conflicts", [])
            ],
            error=data.get("error"),
        )


# ── PMWorkItem ──────────────────────────────────────────────────────

# Status mapping from planning TaskStatus to WorkItemStatus
_TASK_STATUS_MAP = {
    "pending": WorkItemStatus.PENDING,
    "in_progress": WorkItemStatus.IN_PROGRESS,
    "review": WorkItemStatus.REVIEW,
    "done": WorkItemStatus.DONE,
    "blocked": WorkItemStatus.BLOCKED,
    "cancelled": WorkItemStatus.CANCELLED,
}


@dataclass
class PMWorkItem:
    """Provider-agnostic work item — the central PM type."""

    id: str
    title: str
    status: WorkItemStatus
    item_type: WorkItemType = WorkItemType.TASK
    parent_id: Optional[str] = None
    children_ids: list[str] = field(default_factory=list)
    priority: Optional[str] = None
    complexity: Optional[int] = None
    tags: list[str] = field(default_factory=list)
    description: str = ""
    checklist_items: list[PMChecklistItem] = field(default_factory=list)
    custom_fields: list[PMCustomField] = field(default_factory=list)
    provider_meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "status": self.status.value,
            "item_type": self.item_type.value,
            "parent_id": self.parent_id,
            "children_ids": self.children_ids,
            "priority": self.priority,
            "complexity": self.complexity,
            "tags": self.tags,
            "description": self.description,
            "checklist_items": [c.to_dict() for c in self.checklist_items],
            "custom_fields": [f.to_dict() for f in self.custom_fields],
            "provider_meta": self.provider_meta,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PMWorkItem:
        return cls(
            id=data["id"],
            title=data["title"],
            status=WorkItemStatus(data["status"]),
            item_type=WorkItemType(data.get("item_type", "task")),
            parent_id=data.get("parent_id"),
            children_ids=data.get("children_ids", []),
            priority=data.get("priority"),
            complexity=data.get("complexity"),
            tags=data.get("tags", []),
            description=data.get("description", ""),
            checklist_items=[
                PMChecklistItem.from_dict(c)
                for c in data.get("checklist_items", [])
            ],
            custom_fields=[
                PMCustomField.from_dict(f)
                for f in data.get("custom_fields", [])
            ],
            provider_meta=data.get("provider_meta", {}),
        )

    @classmethod
    def from_task(cls, task: Any) -> PMWorkItem:
        """Convert a planning.task_model.Task to a PMWorkItem."""
        status = _TASK_STATUS_MAP.get(
            task.status.value if hasattr(task.status, "value") else str(task.status),
            WorkItemStatus.PENDING,
        )
        checklist_items = [
            PMChecklistItem(
                id=f"ac-{i}",
                name=ac.text,
                checked=ac.checked,
            )
            for i, ac in enumerate(task.acceptance_criteria)
        ]
        return cls(
            id=task.id,
            title=task.title,
            status=status,
            item_type=WorkItemType.TASK,
            priority=task.priority,
            complexity=task.complexity,
            tags=list(task.tags),
            description=task.description,
            checklist_items=checklist_items,
        )
