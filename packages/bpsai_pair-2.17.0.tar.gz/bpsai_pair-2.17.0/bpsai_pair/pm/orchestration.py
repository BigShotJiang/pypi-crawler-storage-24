"""HierarchyOrchestrator — check→discover→enrich→link flow."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable

from bpsai_pair.pm.provider import ProjectManagementProvider
from bpsai_pair.pm.types import PMRelationship, PMWorkItem, RelationshipType
from bpsai_pair.pm.workflow import AutomationRule, WorkflowEngine

logger = logging.getLogger(__name__)

# Signature: enrich_fn(child, automation_rule, *, inherited_labels=[])
EnrichFn = Callable[..., None]


@dataclass
class OrchestrationResult:
    """Outcome of a child-creation orchestration step."""

    item: PMWorkItem | None
    enriched: bool
    linked: bool
    error: str | None = None


def _err(msg: str) -> OrchestrationResult:
    return OrchestrationResult(item=None, enriched=False, linked=False, error=msg)


class HierarchyOrchestrator:
    """Orchestrates the check→discover→enrich→link flow.

    Works with any PM provider via the abstract interface.  Enrichment
    is delegated to an optional ``enrich_fn`` callback so provider-specific
    logic stays outside this module.
    """

    def __init__(
        self,
        provider: ProjectManagementProvider,
        engine: WorkflowEngine,
        *,
        enrich_fn: EnrichFn | None = None,
    ) -> None:
        self._provider = provider
        self._engine = engine
        self._enrich_fn = enrich_fn

    # ── Public API ───────────────────────────────────────────────

    def create_child_via_automation(
        self, parent_id: str, checklist_item_name: str,
    ) -> OrchestrationResult:
        """Execute the full Butler automation flow for one checklist item.

        Steps: find parent → match automation → check item → discover
        child → enrich → set parent-child relationship.
        """
        parent = self._provider.find_item(parent_id)
        if parent is None:
            return _err(f"Parent not found: {parent_id}")

        auto = self._find_automation(parent)
        if auto is None:
            return _err("No automation rule matches parent type/label")

        # Check the checklist item (triggers Butler automation)
        cl_item_id = self._resolve_checklist_id(parent_id, checklist_item_name)
        self._provider.check_checklist_item(
            parent_id, cl_item_id, checked=True,
        )

        # Discover the created child
        child = self._provider.discover_created_item(checklist_item_name)
        if child is None:
            return _err(f"Could not discover child for '{checklist_item_name}'")

        enriched = self._run_enrich(child, auto, parent)
        linked = self._link_parent_child(parent_id, child.id)
        return OrchestrationResult(item=child, enriched=enriched, linked=linked)

    def create_child_directly(
        self, parent_id: str, item: PMWorkItem,
    ) -> OrchestrationResult:
        """Create a child item directly (non-Butler fallback).

        Uses ``provider.create_item()`` then sets the parent-child
        relationship.
        """
        created = self._provider.create_item(item)
        if created is None:
            return _err(f"Failed to create item '{item.title}'")

        enriched = self._run_enrich(created, None, None)
        linked = self._link_parent_child(parent_id, created.id)
        return OrchestrationResult(item=created, enriched=enriched, linked=linked)

    # ── Private helpers ──────────────────────────────────────────

    def _link_parent_child(self, parent_id: str, child_id: str) -> bool:
        return self._provider.set_relationship(
            PMRelationship(
                source_id=parent_id,
                target_id=child_id,
                relationship_type=RelationshipType.PARENT_CHILD,
            ),
        )

    def _find_automation(self, parent: PMWorkItem) -> AutomationRule | None:
        """Find the first automation matching the parent's label/type."""
        for auto in self._engine.get_automations():
            if auto.trigger != "checklist_to_card":
                continue
            if auto.source_card_label and auto.source_card_label.lower() in [
                t.lower() for t in parent.tags
            ]:
                return auto
        # Fallback: return first checklist_to_card if no label match
        for auto in self._engine.get_automations():
            if auto.trigger == "checklist_to_card":
                return auto
        return None

    def _resolve_checklist_id(
        self, parent_id: str, item_name: str,
    ) -> str:
        """Map a checklist item name to its composite ID, or return name.

        Tries exact match first, then substring match for cases where
        the checklist item has a prefix (e.g. "[36.7a] Story Title").
        """
        cl_items = self._provider.get_checklist_items(parent_id)
        for ci in cl_items:
            if ci.name == item_name:
                return ci.id
        # Substring fallback: plan title may be embedded in "[sprint] title"
        for ci in cl_items:
            if item_name in ci.name:
                return ci.id
        return item_name

    def _run_enrich(
        self,
        child: PMWorkItem,
        auto: AutomationRule | None,
        parent: PMWorkItem | None,
    ) -> bool:
        """Run enrichment callback if provided. Returns True on success."""
        if self._enrich_fn is None:
            return False
        inherited = self._get_inherited_labels(auto, parent)
        try:
            self._enrich_fn(child, auto, inherited_labels=inherited)
            return True
        except Exception as exc:
            logger.debug("Enrichment failed for %s: %s", child.id, exc)
            return False

    def _get_inherited_labels(
        self,
        auto: AutomationRule | None,
        parent: PMWorkItem | None,
    ) -> list[str]:
        """Compute domain labels to inherit from parent."""
        if auto is None or not auto.inherit_labels or parent is None:
            return []
        return [
            tag for tag in parent.tags
            if self._engine.is_domain_label(tag)
        ]
