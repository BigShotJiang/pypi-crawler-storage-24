"""Button action executor — replicates Trello Butler button side effects.

Trello's API doesn't support programmatic Butler button triggers, so this
module reads ``ButtonAction`` configs from the workflow and executes them
as composite provider operations (move + fields + comments + dates).
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import datetime, timezone

from bpsai_pair.pm.engine import WorkflowEngine
from bpsai_pair.pm.provider import ProjectManagementProvider
from bpsai_pair.pm.types import WorkItemStatus

logger = logging.getLogger(__name__)


class ButtonActionExecutor:
    """Execute button actions as composite provider operations."""

    def __init__(
        self,
        provider: ProjectManagementProvider,
        engine: WorkflowEngine,
    ) -> None:
        self._provider = provider
        self._engine = engine

    def execute(self, action_name: str, item_id: str) -> bool:
        """Run the named button action against *item_id*.

        Returns True if all operations succeed, False on any failure.
        """
        actions = self._engine.get_button_actions()
        action = actions.get(action_name)
        if action is None:
            logger.warning("Unknown button action: %s", action_name)
            return False

        # Validate requires_field before any operations
        if action.requires_field:
            if not self._check_required_field(item_id, action.requires_field):
                return False

        # Execute operations in sequence — stop on first failure
        steps: list[tuple[str, Callable]] = []

        if action.move_to:
            steps.append(("move_to", lambda: self._move_to(item_id, action.move_to)))
        if action.set_status:
            steps.append(("set_status", lambda: self._set_status(item_id, action.set_status)))
        if action.add_member:
            steps.append(("add_member", lambda: self._add_member(item_id)))
        if action.set_start_date:
            steps.append(("set_start_date", lambda: self._set_start_date(item_id)))
        if action.set_completed_date:
            steps.append(("set_completed_date", lambda: self._set_completed_date(item_id)))
        if action.mark_complete:
            steps.append(("mark_complete", lambda: self._mark_complete(item_id)))
        if action.position:
            steps.append(("position", lambda: self._set_position(item_id, action.position)))
        if action.post_comment:
            steps.append(("post_comment", lambda: self._post_comment(item_id, action.post_comment)))

        for name, step in steps:
            if not step():
                logger.error("Button action %s failed at step: %s", action_name, name)
                return False

        return True

    # ── Individual operations ─────────────────────────────────────────

    def _check_required_field(self, item_id: str, field_name: str) -> bool:
        item = self._provider.find_item(item_id)
        if item is None:
            logger.error("Item %s not found for requires_field check", item_id)
            return False
        fields = item.provider_meta.get("custom_fields", {})
        if field_name not in fields:
            logger.error("Required field '%s' missing on %s", field_name, item_id)
            return False
        return True

    def _move_to(self, item_id: str, status_value: str) -> bool:
        try:
            target = WorkItemStatus(status_value)
        except ValueError:
            logger.error("Invalid status '%s' in move_to action", status_value)
            return False
        return self._provider.move_item(item_id, target)

    def _set_status(self, item_id: str, status: str) -> bool:
        return self._provider.set_fields(item_id, {"Status": status})

    def _add_member(self, item_id: str) -> bool:
        return self._provider.set_fields(item_id, {"add_member": True})

    def _set_start_date(self, item_id: str) -> bool:
        now = datetime.now(tz=timezone.utc).isoformat()
        return self._provider.set_fields(item_id, {"start_date": now})

    def _set_completed_date(self, item_id: str) -> bool:
        now = datetime.now(tz=timezone.utc).isoformat()
        return self._provider.set_fields(item_id, {"completed_date": now})

    def _mark_complete(self, item_id: str) -> bool:
        return self._provider.set_fields(item_id, {"complete": True})

    def _set_position(self, item_id: str, position: str) -> bool:
        return self._provider.set_fields(item_id, {"position": position})

    def _post_comment(self, item_id: str, template: str) -> bool:
        text = self._render_template(template)
        if len(text) > self._MAX_COMMENT_LEN:
            logger.warning("Comment truncated from %d to %d chars", len(text), self._MAX_COMMENT_LEN)
            text = text[:self._MAX_COMMENT_LEN]
        return self._provider.add_comment(item_id, text)

    # Maximum rendered comment length sent to the provider.
    _MAX_COMMENT_LEN = 16_000

    @staticmethod
    def _render_template(template: str) -> str:
        """Substitute known placeholders in *template*.

        Only ``{date}`` is recognized.  Never interpolate user-supplied
        values — all placeholders must resolve to safe, internal data.
        """
        today = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")
        return template.replace("{date}", today)
