"""NullProvider — no-op PM provider for unconfigured projects."""

from __future__ import annotations

from typing import Any

from bpsai_pair.pm.provider import ProjectManagementProvider
from bpsai_pair.pm.types import (
    PMWorkItem,
    SyncAction,
    SyncResult,
    WorkItemStatus,
)


class NullProvider(ProjectManagementProvider):
    """No-op provider used when no PM backend is configured."""

    name = "none"

    def connect(self) -> bool:
        return True

    def healthcheck(self) -> bool:
        return True

    def find_item(self, item_id: str) -> PMWorkItem | None:
        return None

    def move_item(self, item_id: str, status: WorkItemStatus) -> bool:
        return False

    def set_fields(self, item_id: str, fields: dict[str, Any]) -> bool:
        return False

    def add_comment(self, item_id: str, text: str) -> bool:
        return False

    def create_item(self, item: PMWorkItem) -> PMWorkItem | None:
        return None

    def sync_item(self, item: PMWorkItem) -> SyncResult:
        return SyncResult(item_id=item.id, action=SyncAction.SKIPPED)
