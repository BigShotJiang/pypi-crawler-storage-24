"""Project-level hook event handlers.

Handles events beyond task scope: plan creation, sprint lifecycle,
epic/story completion.  All handlers follow the ``(ctx, config) -> dict``
hook signature.
"""

from __future__ import annotations

import logging
from collections.abc import Callable

from bpsai_pair.core.hook_types import HookContext
from bpsai_pair.pm.registry import get_active_provider
from bpsai_pair.pm.types import WorkItemStatus

logger = logging.getLogger(__name__)

# Events handled by this module
PROJECT_EVENTS = frozenset({
    "on_plan_created",
    "on_sprint_planned",
    "on_sprint_completed",
    "on_epic_completed",
    "on_story_completed",
})

_NOT_HANDLED = {"handled": False}


def _with_provider(
    event: str, config: dict, body: Callable,
) -> dict:
    """Shared wrapper: resolve provider, skip if none, catch errors."""
    try:
        provider = get_active_provider(config)
        if provider.name == "none":
            return {**_NOT_HANDLED, "reason": "no provider"}
        return body(provider)
    except Exception as e:
        logger.warning("%s failed: %s", event, e)
        logger.debug("%s error detail: %s", event, e)
        return {**_NOT_HANDLED, "error": "provider_error"}


def handle_project_event(ctx: HookContext, config: dict) -> dict:
    """Config-driven dispatcher — only fires if the event is configured."""
    hooks_cfg = config.get("hooks", {})
    if not hooks_cfg.get("enabled", True):
        return {"handled": False, "reason": "hooks disabled"}

    configured = hooks_cfg.get(ctx.event, [])
    if not configured:
        return {"handled": False, "reason": "event not configured"}

    handler = _HANDLER_MAP.get(ctx.event)
    if handler is None:
        return {"handled": False, "reason": f"no handler for {ctx.event}"}

    return handler(ctx, config)


def on_plan_created(ctx: HookContext, config: dict) -> dict:
    """Fires when ``plan new`` completes. Adds comment if PM provider active."""
    def _body(provider):
        plan_id = ctx.extra.get("plan_id", "unknown")
        provider.add_comment(
            ctx.task_id,
            f"Plan created: {plan_id} by {ctx.agent or 'Agent'}",
        )
        logger.info("on_plan_created: plan=%s provider=%s", plan_id, provider.name)
        return {"handled": True, "event": "on_plan_created", "plan_id": plan_id}
    return _with_provider("on_plan_created", config, _body)


def on_sprint_planned(ctx: HookContext, config: dict) -> dict:
    """Fires when plan sync completes."""
    def _body(provider):
        sprint_id = ctx.extra.get("sprint_id", "unknown")
        logger.info("on_sprint_planned: sprint=%s provider=%s", sprint_id, provider.name)
        return {"handled": True, "event": "on_sprint_planned", "sprint_id": sprint_id}
    return _with_provider("on_sprint_planned", config, _body)


def on_sprint_completed(ctx: HookContext, config: dict) -> dict:
    """Fires when ``pm sprint complete`` runs."""
    def _body(provider):
        sprint_id = ctx.extra.get("sprint_id", "unknown")
        logger.info("on_sprint_completed: sprint=%s provider=%s", sprint_id, provider.name)
        return {"handled": True, "event": "on_sprint_completed", "sprint_id": sprint_id}
    return _with_provider("on_sprint_completed", config, _body)


def _resolve_completion_destination(config: dict, item_type: str) -> str | None:
    """Look up completion_destination for *item_type* from workflow config."""
    try:
        from bpsai_pair.pm.compat import load_pm_config
        from bpsai_pair.pm.workflow import WorkflowEngine

        _, workflow_config = load_pm_config(config)
        engine = WorkflowEngine(workflow_config)
        rule = engine.get_completion_rule(item_type)
        if rule and rule.completion_destination:
            return rule.completion_destination
    except Exception:
        logger.debug("Could not resolve completion destination for %s", item_type)
    return None


def _move_to_done_if_needed(
    provider, item_id: str, *, destination: str | None = None,
) -> bool:
    """Move item to DONE if hierarchy-capable and not already done.

    When *destination* is provided, uses ``move_to_destination`` to
    move to the correct completion list (e.g. "Completed Epics/Stories").
    """
    if "hierarchy" not in provider.capabilities():
        return False
    item = provider.find_item(item_id)
    if item is not None and item.status != WorkItemStatus.DONE:
        if destination:
            return provider.move_to_destination(item_id, destination)
        return provider.move_item(item_id, WorkItemStatus.DONE)
    return False


def on_epic_completed(ctx: HookContext, config: dict) -> dict:
    """Fires when all stories under an epic are done."""
    def _body(provider):
        item_id = ctx.extra.get("item_id", ctx.task_id)
        destination = _resolve_completion_destination(config, "epic")
        moved = _move_to_done_if_needed(provider, item_id, destination=destination)
        logger.info("on_epic_completed: item=%s moved=%s", item_id, moved)
        return {"handled": True, "event": "on_epic_completed", "moved": moved}
    return _with_provider("on_epic_completed", config, _body)


def on_story_completed(ctx: HookContext, config: dict) -> dict:
    """Fires when all tasks under a story are done."""
    def _body(provider):
        item_id = ctx.extra.get("item_id", ctx.task_id)
        destination = _resolve_completion_destination(config, "story")
        moved = _move_to_done_if_needed(provider, item_id, destination=destination)
        logger.info("on_story_completed: item=%s moved=%s", item_id, moved)
        return {"handled": True, "event": "on_story_completed", "moved": moved}
    return _with_provider("on_story_completed", config, _body)


_HANDLER_MAP: dict[str, Callable] = {
    "on_plan_created": on_plan_created,
    "on_sprint_planned": on_sprint_planned,
    "on_sprint_completed": on_sprint_completed,
    "on_epic_completed": on_epic_completed,
    "on_story_completed": on_story_completed,
}
