"""CompletionRuleEvaluator — pluggable completion rule evaluation."""

from __future__ import annotations

import logging
from typing import Callable

from bpsai_pair.pm.provider import ProjectManagementProvider
from bpsai_pair.pm.types import WorkItemStatus
from bpsai_pair.pm.workflow import WorkflowEngine

logger = logging.getLogger(__name__)

# Handler signature: (provider, item_id) -> bool
CompletionHandler = Callable[[ProjectManagementProvider, str], bool]


def _all_children_done(
    provider: ProjectManagementProvider, item_id: str,
) -> bool:
    """Return True when every child of *item_id* has status DONE."""
    children = provider.get_children(item_id)
    if not children:
        return False
    return all(c.status == WorkItemStatus.DONE for c in children)


def _ac_complete(
    provider: ProjectManagementProvider, item_id: str,
) -> bool:
    """Return True when all acceptance-criteria checklist items are checked."""
    item = provider.find_item(item_id)
    if item is None:
        return True
    return all(ci.checked for ci in item.checklist_items)


class CompletionRuleEvaluator:
    """Evaluate completion rules using pluggable handlers."""

    def __init__(
        self,
        provider: ProjectManagementProvider,
        engine: WorkflowEngine,
    ) -> None:
        self.provider = provider
        self.engine = engine
        self._handlers: dict[str, CompletionHandler] = {
            "all_children_done": _all_children_done,
            "ac_complete": _ac_complete,
        }

    def evaluate(self, rule_name: str, item_id: str) -> bool:
        """Evaluate a single rule by name. Raises ValueError if unknown."""
        handler = self._handlers.get(rule_name)
        if handler is None:
            raise ValueError(f"Unknown completion rule: {rule_name!r}")
        return handler(self.provider, item_id)

    def register_handler(self, name: str, handler: CompletionHandler) -> None:
        """Register (or override) a named completion handler."""
        self._handlers[name] = handler

    def all_satisfied(self, item_type: str, item_id: str) -> bool:
        """Return True when all completion rules for *item_type* pass."""
        rule = self.engine.get_completion_rule(item_type)
        if rule is None:
            return True
        return all(self.evaluate(r, item_id) for r in rule.requires)
