"""Sprint lifecycle: start and complete operations."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from bpsai_pair.planning.plan_enums import PlanStatus

if TYPE_CHECKING:
    from bpsai_pair.planning.plan_parser import PlanParser
    from bpsai_pair.planning.task_parser import TaskParser

logger = logging.getLogger(__name__)

_DONE_STATUSES = frozenset({"done", "completed"})
_IN_PROGRESS_STATUSES = frozenset({"in_progress", "in_review", "review"})
_BLOCKED_STATUSES = frozenset({"blocked"})


@dataclass
class SprintSummary:
    """Summary of a sprint's task statuses."""

    completed: int = 0
    in_progress: int = 0
    blocked: int = 0
    pending: int = 0
    carry_forward_ids: list[str] = field(default_factory=list)

    @property
    def all_done(self) -> bool:
        return self.in_progress == 0 and self.blocked == 0 and self.pending == 0

    def to_dict(self) -> dict:
        return {
            "completed": self.completed, "in_progress": self.in_progress,
            "blocked": self.blocked, "pending": self.pending,
            "carry_forward_ids": self.carry_forward_ids,
        }

    @classmethod
    def from_tasks(cls, tasks) -> SprintSummary:
        """Categorize tasks by status and build summary."""
        completed = 0
        in_progress = 0
        blocked = 0
        pending = 0
        carry_forward: list[str] = []

        for task in tasks:
            status = getattr(task, "status", "pending")
            if isinstance(status, str):
                status_val = status.lower()
            else:
                status_val = str(status.value).lower() if hasattr(status, "value") else str(status).lower()

            if status_val in _DONE_STATUSES:
                completed += 1
            elif status_val in _IN_PROGRESS_STATUSES:
                in_progress += 1
                carry_forward.append(task.id)
            elif status_val in _BLOCKED_STATUSES:
                blocked += 1
                carry_forward.append(task.id)
            else:
                pending += 1
                carry_forward.append(task.id)

        return cls(
            completed=completed, in_progress=in_progress,
            blocked=blocked, pending=pending,
            carry_forward_ids=carry_forward,
        )


def start_sprint(plan_id: str, plan_parser: "PlanParser") -> bool:
    """Mark a plan as in-progress. Returns True on success."""
    plan = plan_parser.get_plan_by_id(plan_id)
    if plan is None:
        logger.warning("Plan not found: %s", plan_id)
        return False

    plan.status = PlanStatus.IN_PROGRESS
    plan_parser.save(plan)
    logger.info("Sprint started: %s", plan_id)
    return True


def complete_sprint(
    plan_id: str,
    plan_parser: "PlanParser",
    task_parser: "TaskParser",
) -> SprintSummary | None:
    """Evaluate sprint tasks and produce summary. Returns None if plan missing."""
    plan = plan_parser.get_plan_by_id(plan_id)
    if plan is None:
        logger.warning("Plan not found: %s", plan_id)
        return None

    tasks = task_parser.get_tasks_for_plan(plan_id)
    summary = SprintSummary.from_tasks(tasks)

    if summary.all_done:
        plan.status = PlanStatus.COMPLETE
    plan_parser.save(plan)

    logger.info(
        "Sprint completed: %s — %d done, %d carry-forward",
        plan_id, summary.completed, len(summary.carry_forward_ids),
    )
    return summary


@dataclass
class CarryForwardResult:
    """Result of carrying incomplete tasks to a new plan."""

    moved_count: int
    task_ids: list[str]
    from_plan: str
    to_plan: str


def carry_forward(
    old_plan_id: str,
    new_plan_id: str,
    plan_parser: "PlanParser",
    task_parser: "TaskParser",
) -> CarryForwardResult | None:
    """Move incomplete tasks from old plan to new plan.

    Returns None if either plan is missing.
    """
    old_plan = plan_parser.get_plan_by_id(old_plan_id)
    if old_plan is None:
        logger.warning("Source plan not found: %s", old_plan_id)
        return None

    new_plan = plan_parser.get_plan_by_id(new_plan_id)
    if new_plan is None:
        logger.warning("Target plan not found: %s", new_plan_id)
        return None

    tasks = task_parser.get_tasks_for_plan(old_plan_id)
    moved_ids = _move_incomplete_tasks(tasks, new_plan_id, task_parser)
    _update_carry_forward_metadata(old_plan, new_plan, moved_ids, plan_parser)

    return CarryForwardResult(
        moved_count=len(moved_ids), task_ids=moved_ids,
        from_plan=old_plan_id, to_plan=new_plan_id,
    )


def _move_incomplete_tasks(tasks, new_plan_id, task_parser) -> list[str]:
    """Update plan_id on incomplete tasks, return moved IDs."""
    moved: list[str] = []
    for task in tasks:
        status = getattr(task, "status", "pending")
        status_val = status.lower() if isinstance(status, str) else str(getattr(status, "value", status)).lower()
        if status_val in _DONE_STATUSES:
            continue
        task.plan_id = new_plan_id
        task_parser.save(task)
        moved.append(task.id)
    return moved


def _update_carry_forward_metadata(old_plan, new_plan, moved_ids, plan_parser):
    """Set carry-forward metadata on both plans and save."""
    if moved_ids:
        old_plan.metadata["carry_forward_to"] = new_plan.id
        old_plan.metadata["carried_tasks"] = moved_ids
        new_plan.metadata["carry_forward_from"] = old_plan.id
    plan_parser.save(old_plan)
    plan_parser.save(new_plan)
