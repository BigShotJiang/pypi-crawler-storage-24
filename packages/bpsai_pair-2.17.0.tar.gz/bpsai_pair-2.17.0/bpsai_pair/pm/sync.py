"""PMSyncManager — provider-agnostic sync with conflict detection."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from bpsai_pair.pm.provider import ProjectManagementProvider
from bpsai_pair.pm.types import (
    PMWorkItem,
    SyncAction,
    SyncConflict,
    SyncResult,
)
from bpsai_pair.pm.workflow import WorkflowEngine

logger = logging.getLogger(__name__)

# Fields compared for conflict detection
_COMPARE_FIELDS = ("title", "status", "description")


@dataclass
class SyncPlan:
    """Dry-run plan categorising items before actual sync."""

    to_create: list[PMWorkItem] = field(default_factory=list)
    to_update: list[PMWorkItem] = field(default_factory=list)
    to_skip: list[str] = field(default_factory=list)
    conflicts: list[SyncConflict] = field(default_factory=list)


class PMSyncManager:
    """Coordinates sync between local work items and a PM provider."""

    def __init__(
        self,
        provider: ProjectManagementProvider,
        engine: WorkflowEngine,
    ) -> None:
        self.provider = provider
        self.engine = engine

    def sync_item(self, local: PMWorkItem) -> SyncResult:
        """Push a local work item to the provider.

        - Not found remotely → delegates to provider.sync_item (CREATE)
        - Found, no diff     → SKIPPED
        - Found, has diff     → checks for conflicts
          - Conflicts found   → ERROR with conflicts list
          - No conflicts      → delegates to provider.sync_item (UPDATE)
        """
        remote = self.provider.find_item(local.id)

        if remote is None:
            return self.provider.sync_item(local)

        conflicts = self.detect_conflicts(local, remote)
        if conflicts:
            return SyncResult(
                item_id=local.id,
                action=SyncAction.ERROR,
                conflicts=conflicts,
                error=f"{len(conflicts)} conflict(s) detected",
            )

        if not self._has_changes(local, remote):
            return SyncResult(item_id=local.id, action=SyncAction.SKIPPED)

        return self.provider.sync_item(local)

    def sync_batch(self, items: list[PMWorkItem]) -> list[SyncResult]:
        """Sync multiple items. Returns a result per item with per-item errors."""
        results: list[SyncResult] = []
        for item in items:
            result = self.sync_item(item)
            if result.action == SyncAction.ERROR:
                logger.warning(
                    "Sync failed for %s: %s", item.id, result.error,
                )
                for c in (result.conflicts or []):
                    logger.warning(
                        "  Conflict on %s field '%s': local=%r remote=%r",
                        item.id, c.field, c.local_value, c.remote_value,
                    )
            results.append(result)
        return results

    def plan_sync(self, items: list[PMWorkItem]) -> SyncPlan:
        """Dry-run: categorise items without calling provider.sync_item."""
        plan = SyncPlan()

        for local in items:
            remote = self.provider.find_item(local.id)

            if remote is None:
                plan.to_create.append(local)
                continue

            conflicts = self.detect_conflicts(local, remote)
            if conflicts:
                plan.conflicts.extend(conflicts)
                continue

            if self._has_changes(local, remote):
                plan.to_update.append(local)
            else:
                plan.to_skip.append(local.id)

        return plan

    def detect_conflicts(
        self, local: PMWorkItem, remote: PMWorkItem,
    ) -> list[SyncConflict]:
        """Compare local and remote, returning field-level conflicts.

        A conflict occurs when both sides have different non-empty values.
        When only one side has a value (the other is empty), it is a safe
        update rather than a conflict.
        """
        conflicts: list[SyncConflict] = []

        for fname in _COMPARE_FIELDS:
            local_val = self._field_value(local, fname)
            remote_val = self._field_value(remote, fname)
            if local_val != remote_val and local_val and remote_val:
                conflicts.append(
                    SyncConflict(
                        field=fname,
                        local_value=local_val,
                        remote_value=remote_val,
                    )
                )

        return conflicts

    def reverse_sync(self, item_id: str) -> SyncResult:
        """Pull remote state for a work item."""
        remote = self.provider.find_item(item_id)
        if remote is None:
            return SyncResult(
                item_id=item_id,
                action=SyncAction.ERROR,
                error=f"Item not found: {item_id}",
            )
        return SyncResult(
            item_id=item_id,
            action=SyncAction.UPDATED,
            changes=remote.to_dict(),
        )

    # ── Private helpers ──────────────────────────────────────────────

    @staticmethod
    def _field_value(item: PMWorkItem, field_name: str) -> str:
        val = getattr(item, field_name, "")
        if hasattr(val, "value"):
            return val.value
        return str(val) if val else ""

    @staticmethod
    def _has_changes(local: PMWorkItem, remote: PMWorkItem) -> bool:
        for fname in _COMPARE_FIELDS:
            local_val = PMSyncManager._field_value(local, fname)
            remote_val = PMSyncManager._field_value(remote, fname)
            if local_val != remote_val:
                return True
        return False
