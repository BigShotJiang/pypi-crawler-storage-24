"""Workflow customization validation and merging."""

from __future__ import annotations

from bpsai_pair.licensing.core import FeatureNotAvailable, get_tier, has_feature_api
from bpsai_pair.pm.workflow import (
    AutomationRule,
    CompletionRule,
    WorkflowConfig,
    WorkItemTypeConfig,
)

_VALID_MODES = {"simple", "hierarchy", "local"}


def validate_workflow(config: WorkflowConfig) -> list[str]:
    """Validate a WorkflowConfig and return a list of error messages."""
    errors: list[str] = []
    _check_mode_and_statuses(config, errors)
    _check_transitions(config, errors)
    _check_work_items_and_rules(config, errors)
    return errors


def merge_workflow(base: WorkflowConfig, overrides: dict) -> WorkflowConfig:
    """Deep-merge overrides onto a base WorkflowConfig, returning a new one.

    Merge rules:
    - work_items, statuses, transitions: merge by key (override replaces/adds)
    - automations, completion_rules: overrides replace base entirely
    - mode: override replaces if present

    Raises FeatureNotAvailable if pm_custom_workflow is not licensed.
    """
    if not has_feature_api("pm_custom_workflow"):
        raise FeatureNotAvailable("pm_custom_workflow", get_tier())
    return WorkflowConfig(
        mode=overrides.get("mode", base.mode),
        work_items=_merge_work_items(base, overrides),
        statuses=_merge_by_key(base.statuses, overrides.get("statuses", {})),
        transitions=_merge_by_key(base.transitions, overrides.get("transitions", {})),
        automations=_merge_automations(base, overrides),
        completion_rules=_merge_completion_rules(base, overrides),
        button_actions=_merge_by_key(base.button_actions, overrides.get("button_actions", {})),
        label_categories=_merge_by_key(base.label_categories, overrides.get("label_categories", {})),
    )


# -- Validation helpers -------------------------------------------------------


def _check_mode_and_statuses(config: WorkflowConfig, errors: list[str]) -> None:
    """Validate mode value and that at least one status exists."""
    if config.mode not in _VALID_MODES:
        errors.append(
            f"Invalid mode '{config.mode}'; must be one of {sorted(_VALID_MODES)}"
        )
    if not config.statuses:
        errors.append("At least one status must be defined")


def _check_transitions(config: WorkflowConfig, errors: list[str]) -> None:
    """Validate transition keys and targets reference defined statuses."""
    status_keys = set(config.statuses.keys())
    transition_sources = set(config.transitions.keys())

    for key in config.transitions:
        if key not in status_keys:
            errors.append(f"Transition key '{key}' is not a defined status")

    all_targets = {
        t for targets in config.transitions.values() for t in targets
    }
    for key, targets in config.transitions.items():
        for target in targets:
            if target not in status_keys:
                if target in transition_sources:
                    errors.append(
                        f"Transition target '{target}' (from '{key}') "
                        f"is not a defined status"
                    )
                elif target in all_targets and target not in status_keys:
                    pass  # Allow terminal sinks like "cancelled"


def _check_work_items_and_rules(config: WorkflowConfig, errors: list[str]) -> None:
    """Validate work item references, completion rules, and automations."""
    wi_keys = set(config.work_items.keys())

    for key, wi in config.work_items.items():
        if wi.children_type and wi.children_type not in wi_keys:
            errors.append(
                f"Work item '{key}' has children_type '{wi.children_type}' "
                f"which is not a defined work item"
            )

    for key in config.completion_rules:
        if key not in wi_keys:
            errors.append(f"Completion rule '{key}' references nonexistent work item")

    for key, rule in config.completion_rules.items():
        if "all_children_done" in rule.requires:
            wi = config.work_items.get(key)
            if wi and not wi.children_type:
                errors.append(
                    f"Completion rule '{key}' requires 'all_children_done' "
                    f"but work item has no children_type"
                )

    checklist_names = {
        wi.checklist_name for wi in config.work_items.values() if wi.checklist_name
    }
    for auto in config.automations:
        if auto.source_checklist and auto.source_checklist not in checklist_names:
            errors.append(
                f"Automation source_checklist '{auto.source_checklist}' "
                f"does not match any work item's checklist_name"
            )


# -- Merge helpers -------------------------------------------------------------


def _merge_by_key(base: dict, overrides: dict) -> dict:
    """Shallow-merge two dicts (overrides win on key collision)."""
    merged = dict(base)
    merged.update(overrides)
    return merged


def _merge_work_items(
    base: WorkflowConfig, overrides: dict,
) -> dict[str, WorkItemTypeConfig]:
    """Merge work_items by key; override replaces matching keys, adds new."""
    work_items = dict(base.work_items)
    for key, val in overrides.get("work_items", {}).items():
        work_items[key] = WorkItemTypeConfig(
            name=val.get("name", key),
            label=val.get("label", ""),
            checklist_name=val.get("checklist_name"),
            children_type=val.get("children_type"),
            completion_destination=val.get(
                "completion_destination", val.get("completion_list"),
            ),
            default_effort=val.get("default_effort", "M"),
            ac_checklist_name=val.get("ac_checklist_name"),
        )
    return work_items


def _merge_automations(
    base: WorkflowConfig, overrides: dict,
) -> list[AutomationRule]:
    """Replace automations entirely if overrides has the key."""
    if "automations" not in overrides:
        return list(base.automations)
    return [
        AutomationRule(
            trigger=a.get("trigger", ""),
            source_checklist=a.get("source_checklist"),
            source_card_label=a.get("source_card_label"),
            creates_in=a.get("creates_in"),
            created_label=a.get("created_label"),
        )
        for a in overrides["automations"]
    ]


def _merge_completion_rules(
    base: WorkflowConfig, overrides: dict,
) -> dict[str, CompletionRule]:
    """Replace completion_rules entirely if overrides has the key."""
    if "completion_rules" not in overrides:
        return dict(base.completion_rules)
    return {
        key: CompletionRule(
            completion_destination=val.get(
                "completion_destination", val.get("target_list"),
            ),
            requires=val.get("requires", []),
            uses_button=val.get("uses_button", False),
        )
        for key, val in overrides["completion_rules"].items()
    }
