"""PMLifecycleManager — provider-agnostic work item lifecycle operations."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from bpsai_pair.pm.errors import PMItemNotFoundError, PMTransitionError
from bpsai_pair.pm.provider import ProjectManagementProvider
from bpsai_pair.pm.types import PMWorkItem, WorkItemStatus
from bpsai_pair.pm.workflow import WorkflowEngine

if TYPE_CHECKING:
    from bpsai_pair.pm.completion_eval import CompletionRuleEvaluator

logger = logging.getLogger(__name__)


class PMLifecycleManager:
    """Coordinates lifecycle transitions using a provider and workflow engine.

    Handles start/complete/block/status queries. Does NOT manage local
    file sync, state machines, or telemetry — those remain in the CLI layer.
    """

    def __init__(
        self,
        provider: ProjectManagementProvider,
        engine: WorkflowEngine,
        *,
        evaluator: Optional[CompletionRuleEvaluator] = None,
    ) -> None:
        self.provider = provider
        self.engine = engine
        self._evaluator = evaluator

    def start_item(self, item_id: str) -> PMWorkItem:
        """Move a work item to in_progress.

        Raises PMItemNotFoundError if item doesn't exist.
        Raises PMTransitionError if transition is invalid.
        """
        item = self._find_or_raise(item_id)
        self._validate_transition(item, WorkItemStatus.IN_PROGRESS)

        moved = self.provider.move_item(item_id, WorkItemStatus.IN_PROGRESS)
        if moved:
            self.provider.add_comment(item_id, "[pm] Started")
            item.status = WorkItemStatus.IN_PROGRESS
        else:
            logger.warning("move_item returned False for %s → in_progress", item_id)
        return item

    def complete_item(
        self,
        item_id: str,
        summary: str,
        *,
        strict_ac: bool = True,
    ) -> PMWorkItem:
        """Move a work item to done.

        When strict_ac is True, raises PMTransitionError if any
        acceptance criteria are unchecked.
        """
        item = self._find_or_raise(item_id)
        self._validate_transition(item, WorkItemStatus.DONE)

        if strict_ac:
            if self._evaluator is not None:
                if not self._evaluator.evaluate("ac_complete", item_id):
                    raise PMTransitionError(
                        "Cannot complete: acceptance criteria not satisfied"
                    )
            else:
                passed, unchecked = self._check_ac(item)
                if not passed:
                    names = ", ".join(unchecked)
                    raise PMTransitionError(
                        f"Cannot complete: {len(unchecked)} unchecked acceptance criteria: {names}"
                    )

        moved = self.provider.move_item(item_id, WorkItemStatus.DONE)
        if moved:
            self.provider.add_comment(item_id, f"[pm] Completed: {summary}")
            item.status = WorkItemStatus.DONE
        else:
            logger.warning("move_item returned False for %s → done", item_id)
        return item

    def block_item(self, item_id: str, reason: str) -> PMWorkItem:
        """Move a work item to blocked with a reason comment.

        Raises PMItemNotFoundError if item doesn't exist.
        Raises PMTransitionError if transition is invalid.
        """
        item = self._find_or_raise(item_id)
        self._validate_transition(item, WorkItemStatus.BLOCKED)

        moved = self.provider.move_item(item_id, WorkItemStatus.BLOCKED)
        if moved:
            self.provider.add_comment(item_id, f"[pm] Blocked: {reason}")
            item.status = WorkItemStatus.BLOCKED
        else:
            logger.warning("move_item returned False for %s → blocked", item_id)
        return item

    def get_item_status(self, item_id: str) -> Optional[WorkItemStatus]:
        """Return the current status of a work item, or None if not found."""
        item = self.provider.find_item(item_id)
        if item is None:
            return None
        return item.status

    def check_acceptance_criteria(
        self, item_id: str,
    ) -> tuple[bool, list[str]]:
        """Check whether all acceptance criteria are complete.

        Returns (True, []) if all checked or no criteria exist.
        Returns (False, [names...]) with unchecked item names otherwise.
        """
        item = self._find_or_raise(item_id)
        return self._check_ac(item)

    # ── Private helpers ──────────────────────────────────────────────

    def _find_or_raise(self, item_id: str) -> PMWorkItem:
        item = self.provider.find_item(item_id)
        if item is None:
            raise PMItemNotFoundError(f"Work item not found: {item_id}")
        return item

    def _validate_transition(
        self, item: PMWorkItem, target: WorkItemStatus,
    ) -> None:
        if not self.engine.can_transition(item.status.value, target.value):
            raise PMTransitionError(
                f"Cannot transition {item.id} from {item.status.value} to {target.value}"
            )

    @staticmethod
    def _check_ac(item: PMWorkItem) -> tuple[bool, list[str]]:
        unchecked = [ci.name for ci in item.checklist_items if not ci.checked]
        return (len(unchecked) == 0, unchecked)
