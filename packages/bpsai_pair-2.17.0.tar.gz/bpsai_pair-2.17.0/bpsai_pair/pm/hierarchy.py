"""HierarchyManager — epic/story/task tree operations."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Optional

from bpsai_pair.licensing.core import FeatureNotAvailable, get_tier, has_feature_api
from bpsai_pair.pm.errors import PMItemNotFoundError
from bpsai_pair.pm.provider import ProjectManagementProvider
from bpsai_pair.pm.types import (
    PMRelationship,
    PMWorkItem,
    RelationshipType,
    WorkItemStatus,
)
from bpsai_pair.pm.workflow import WorkflowEngine

if TYPE_CHECKING:
    from bpsai_pair.pm.completion_eval import CompletionRuleEvaluator

logger = logging.getLogger(__name__)


class HierarchyManager:
    """Manages parent-child relationships in work item hierarchies.

    Uses the same constructor pattern as PMLifecycleManager: takes a
    provider (for remote operations) and a workflow engine (for rules).
    """

    def __init__(
        self,
        provider: ProjectManagementProvider,
        engine: WorkflowEngine,
        *,
        evaluator: Optional[CompletionRuleEvaluator] = None,
    ) -> None:
        if not has_feature_api("pm_hierarchy"):
            raise FeatureNotAvailable("pm_hierarchy", get_tier())
        self.provider = provider
        self.engine = engine
        self._evaluator = evaluator

    # ── Public API ───────────────────────────────────────────────────

    def create_children_from_items(
        self, parent_id: str, checklist_items: list[str],
    ) -> list[PMWorkItem]:
        """Check checklist items and discover created children.

        For each item: check it on the parent, then try to discover
        the remotely-created child. Sets PARENT_CHILD relationship
        for discovered items. Undiscovered items are skipped.
        """
        parent = self._find_or_raise(parent_id)
        created: list[PMWorkItem] = []

        # Resolve checklist item names → composite IDs for check_checklist_item
        cl_items = self.provider.get_checklist_items(parent_id)
        name_to_id = {ci.name: ci.id for ci in cl_items}

        for item_name in checklist_items:
            checklist_item_id = name_to_id.get(item_name, item_name)
            self.provider.check_checklist_item(
                parent_id, checklist_item_id, checked=True,
            )
            child = self.provider.discover_created_item(item_name)
            if child is None:
                logger.debug("Item %r not discovered, skipping", item_name)
                continue
            self.provider.set_relationship(
                PMRelationship(
                    source_id=parent_id,
                    target_id=child.id,
                    relationship_type=RelationshipType.PARENT_CHILD,
                ),
            )
            created.append(child)

        return created

    def create_children_from_checklist(
        self, parent_id: str, checklist_items: list[str],
    ) -> list[PMWorkItem]:
        """Deprecated alias for create_children_from_items."""
        return self.create_children_from_items(parent_id, checklist_items)

    def are_all_children_done(self, parent_id: str) -> bool:
        """Return True when every child has status DONE.

        Returns False for items with no children (consistent with
        CompletionRuleEvaluator._all_children_done).
        """
        children = self.provider.get_children(parent_id)
        if not children:
            return False
        return all(c.status == WorkItemStatus.DONE for c in children)

    def complete_parent_if_ready(self, parent_id: str) -> PMWorkItem | None:
        """Move parent to DONE if its completion rule is satisfied.

        Returns the updated item on success, None if conditions are
        not met or no applicable rule exists.
        Raises PMItemNotFoundError when parent is not found.
        """
        parent = self._find_or_raise(parent_id)
        item_type = parent.item_type.value

        if self._evaluator is not None:
            if not self._evaluator.all_satisfied(item_type, parent_id):
                return None
        else:
            rule = self.engine.get_completion_rule(item_type)
            if rule is None or "all_children_done" not in rule.requires:
                return None
            if not self.are_all_children_done(parent_id):
                return None

        moved = self.provider.move_item(parent_id, WorkItemStatus.DONE)
        if moved:
            parent.status = WorkItemStatus.DONE
        return parent

    def get_tree(
        self, root_id: str, *, max_depth: int = 10,
    ) -> dict[str, Any]:
        """Build a recursive tree starting at root_id.

        Returns ``{"item": PMWorkItem, "children": [subtrees]}``.
        Raises PMItemNotFoundError when root is not found.
        Stops recursing at *max_depth* to prevent stack overflow
        from cyclic metadata.
        """
        item = self._find_or_raise(root_id)
        if max_depth <= 0:
            return {"item": item, "children": []}
        children = self.provider.get_children(root_id)
        child_trees = [
            self.get_tree(c.id, max_depth=max_depth - 1) for c in children
        ]
        return {"item": item, "children": child_trees}

    # ── Private helpers ──────────────────────────────────────────────

    def _find_or_raise(self, item_id: str) -> PMWorkItem:
        item = self.provider.find_item(item_id)
        if item is None:
            raise PMItemNotFoundError(f"Work item not found: {item_id}")
        return item
