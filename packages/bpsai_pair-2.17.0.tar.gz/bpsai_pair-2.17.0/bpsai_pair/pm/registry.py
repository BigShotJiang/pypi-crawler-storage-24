"""Provider registry — registration, discovery, and factory."""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Optional

from bpsai_pair.pm.null_provider import NullProvider
from bpsai_pair.pm.provider import ProjectManagementProvider

logger = logging.getLogger(__name__)

# Module-level state
_registry: dict[str, type[ProjectManagementProvider]] = {}
_active_provider: Optional[ProjectManagementProvider] = None
_active_config_hash: Optional[str] = None


def register_provider(name: str, cls: type[ProjectManagementProvider]) -> None:
    """Register a provider class by name.

    Duplicate names log a warning; last registration wins.
    """
    if not name or not isinstance(name, str) or not name.strip():
        raise ValueError(f"Provider name must be a non-empty string, got: {name!r}")
    if not (isinstance(cls, type) and issubclass(cls, ProjectManagementProvider)):
        raise TypeError(f"{cls} is not a ProjectManagementProvider subclass")
    if name in _registry:
        logger.warning("Provider '%s' re-registered (was %s, now %s)", name, _registry[name].__name__, cls.__name__)
    _registry[name] = cls


def get_provider_class(name: str) -> type[ProjectManagementProvider]:
    """Look up a registered provider class by name.

    Raises KeyError with a helpful message if not found.
    """
    try:
        return _registry[name]
    except KeyError:
        available = ", ".join(sorted(_registry)) or "(none)"
        raise KeyError(f"Provider '{name}' not registered. Available: {available}")


def _compute_config_hash(config: dict | None) -> str:
    """Compute a stable hash of the PM config section."""
    pm_config = config.get("pm", {}) if config else {}
    return hashlib.sha256(json.dumps(pm_config, sort_keys=True).encode()).hexdigest()


def get_active_provider(
    config: dict | None = None,
) -> ProjectManagementProvider:
    """Return the active provider instance (cached).

    Reads ``config["pm"]["provider"]`` to determine which provider to
    instantiate.  Defaults to ``"none"`` (NullProvider).
    Invalidates cache when config changes between calls.
    """
    global _active_provider, _active_config_hash
    new_hash = _compute_config_hash(config)

    if _active_provider is not None and new_hash == _active_config_hash:
        return _active_provider

    provider_name = "none"
    if config:
        provider_name = config.get("pm", {}).get("provider", "none")

    cls = get_provider_class(provider_name)
    # Providers are constructed with no arguments; credential injection
    # happens in connect().  Future providers must follow this contract.
    instance = cls()
    if not instance.connect():
        logger.warning("Provider '%s' connect() returned False", provider_name)
        instance = NullProvider()
    _active_provider = instance
    _active_config_hash = new_hash
    return instance


def list_providers() -> list[str]:
    """Return sorted list of registered provider names."""
    return sorted(_registry)


def reset_provider_cache(*, include_registry: bool = False) -> None:
    """Clear the cached active provider (for testing).

    When *include_registry* is True, also clears the provider registry
    and re-registers the built-in ``"none"`` provider.
    """
    global _active_provider, _active_config_hash, _registry
    _active_provider = None
    _active_config_hash = None
    if include_registry:
        _registry.clear()
        _registry["none"] = NullProvider


def _discover_providers() -> None:
    """Try to import known provider packages and call their register()."""
    for package in ("bpsai_pair.pm_trello", "bpsai_pair.pm_jira", "bpsai_pair.pm_slack"):
        try:
            mod = __import__(package, fromlist=["register"])
            if hasattr(mod, "register"):
                mod.register()
        except ImportError:
            pass


# Auto-register built-in providers and run discovery on import
register_provider("none", NullProvider)
_discover_providers()
