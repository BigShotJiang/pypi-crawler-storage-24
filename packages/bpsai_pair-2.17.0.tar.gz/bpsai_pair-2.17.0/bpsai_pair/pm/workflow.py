"""Workflow configuration and engine for PM abstraction layer."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ── Data types ────────────────────────────────────────────────────


@dataclass
class WorkItemTypeConfig:
    """Configuration for a single work item type in a workflow."""

    name: str
    label: str = ""
    checklist_name: Optional[str] = None
    children_type: Optional[str] = None
    completion_destination: Optional[str] = None
    default_effort: str = "M"
    ac_checklist_name: Optional[str] = None

    @property
    def completion_list(self) -> Optional[str]:
        """Deprecated alias for completion_destination."""
        return self.completion_destination


@dataclass
class CompletionRule:
    """Rule describing how a work item type is completed."""

    completion_destination: Optional[str] = None
    requires: list[str] = field(default_factory=list)
    uses_button: bool = False

    @property
    def target_list(self) -> Optional[str]:
        """Deprecated alias for completion_destination."""
        return self.completion_destination


@dataclass
class EnrichmentPolicy:
    """Policy for post-creation enrichment of work items."""

    custom_fields: list[str] = field(default_factory=list)
    labels: list[str] = field(default_factory=list)
    relationships: list[str] = field(default_factory=list)
    checklists: list[str] = field(default_factory=list)


@dataclass
class ButtonAction:
    """A button action that can be configured in the workflow YAML."""

    name: str
    move_to: Optional[str] = None
    set_status: Optional[str] = None
    add_member: bool = False
    set_start_date: bool = False
    set_completed_date: bool = False
    mark_complete: bool = False
    post_comment: Optional[str] = None
    requires_field: Optional[str] = None
    position: Optional[str] = None


@dataclass
class AutomationRule:
    """Rule describing an automation triggered by workflow events."""

    trigger: str
    source_checklist: Optional[str] = None
    source_card_label: Optional[str] = None
    creates_in: Optional[str] = None
    created_label: Optional[str] = None
    enrich_after: Optional[EnrichmentPolicy] = None
    created_checklist: Optional[str] = None
    sets_start_date: bool = False
    adds_member: bool = False
    discover_after: bool = False
    inherit_labels: bool = False


# ── WorkflowConfig ───────────────────────────────────────────────


@dataclass
class WorkflowConfig:
    """Full workflow configuration for a PM setup."""

    mode: str
    work_items: dict[str, WorkItemTypeConfig]
    statuses: dict[str, str | list[str]]
    transitions: dict[str, list[str]]
    automations: list[AutomationRule] = field(default_factory=list)
    completion_rules: dict[str, CompletionRule] = field(default_factory=dict)
    button_actions: dict[str, ButtonAction] = field(default_factory=dict)
    label_categories: dict[str, list[str]] = field(default_factory=dict)

    @property
    def has_hierarchy(self) -> bool:
        """True if workflow has more than one work item type."""
        return len(self.work_items) > 1

    @property
    def has_automations(self) -> bool:
        """True if workflow has any automation rules."""
        return len(self.automations) > 0

    @classmethod
    def local_only(cls) -> WorkflowConfig:
        """Return a local-only workflow with no PM provider."""
        return cls(
            mode="local",
            work_items={},
            statuses={},
            transitions={},
        )

    @classmethod
    def simple(cls) -> WorkflowConfig:
        """Return a minimal single-type workflow configuration."""
        return cls(
            mode="simple",
            work_items={
                "task": WorkItemTypeConfig(
                    name="task",
                    label="Task",
                    completion_destination="Deployed/Done",
                    default_effort="M",
                ),
            },
            statuses={
                "pending": ["Intake/Backlog", "Planned/Ready"],
                "in_progress": "In Progress",
                "review": "Review/Testing",
                "done": "Deployed/Done",
                "blocked": "Issues/Tech Debt",
            },
            transitions={
                "pending": ["in_progress", "cancelled"],
                "in_progress": ["review", "done", "blocked"],
                "review": ["done", "in_progress"],
                "done": [],
                "blocked": ["in_progress"],
            },
            completion_rules={
                "task": CompletionRule(completion_destination="Deployed/Done"),
            },
        )

    @classmethod
    def from_dict(cls, data: dict) -> WorkflowConfig:
        """Parse a dict (e.g. from YAML) into a WorkflowConfig."""
        work_items = {
            key: WorkItemTypeConfig(
                name=val.get("name", key),
                label=val.get("label", ""),
                checklist_name=val.get("checklist_name"),
                children_type=val.get("children_type"),
                completion_destination=val.get(
                    "completion_destination", val.get("completion_list"),
                ),
                default_effort=val.get("default_effort", "M"),
                ac_checklist_name=val.get("ac_checklist_name"),
            )
            for key, val in data.get("work_items", {}).items()
        }
        return cls(
            mode=data["mode"],
            work_items=work_items,
            statuses=data.get("statuses", {}),
            transitions=data.get("transitions", {}),
            automations=_parse_automations(data),
            completion_rules=_parse_completion_rules(data),
            button_actions=_parse_button_actions(data),
            label_categories=data.get("label_categories", {}),
        )


def _parse_automations(data: dict) -> list[AutomationRule]:
    return [
        AutomationRule(
            trigger=a["trigger"],
            source_checklist=a.get("source_checklist"),
            source_card_label=a.get("source_card_label"),
            creates_in=a.get("creates_in"),
            created_label=a.get("created_label"),
            enrich_after=EnrichmentPolicy(**a["enrich_after"]) if a.get("enrich_after") else None,
            created_checklist=a.get("created_checklist"),
            sets_start_date=a.get("sets_start_date", False),
            adds_member=a.get("adds_member", False),
            discover_after=a.get("discover_after", False),
            inherit_labels=a.get("inherit_labels", False),
        )
        for a in data.get("automations", [])
    ]


def _parse_completion_rules(data: dict) -> dict[str, CompletionRule]:
    return {
        key: CompletionRule(
            completion_destination=val.get("completion_destination", val.get("target_list")),
            requires=val.get("requires", []),
            uses_button=val.get("uses_button", False),
        )
        for key, val in data.get("completion_rules", {}).items()
    }


def _parse_button_actions(data: dict) -> dict[str, ButtonAction]:
    return {
        key: ButtonAction(
            name=key,
            move_to=val.get("move_to"),
            set_status=val.get("set_status"),
            add_member=val.get("add_member", False),
            set_start_date=val.get("set_start_date", False),
            set_completed_date=val.get("set_completed_date", False),
            mark_complete=val.get("mark_complete", False),
            post_comment=val.get("post_comment"),
            requires_field=val.get("requires_field"),
            position=val.get("position"),
        )
        for key, val in data.get("button_actions", {}).items()
    }


# ── WorkflowEngine (re-exported for backward compatibility) ──────

from bpsai_pair.pm.engine import WorkflowEngine  # noqa: E402, F401
