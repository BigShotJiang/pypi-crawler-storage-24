"""Token feedback loop for estimation accuracy tracking and learning.

Extracted from estimation.py for modular architecture.
"""

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
import json
import logging

import yaml

from .token_estimator import TokenEstimationConfig

logger = logging.getLogger(__name__)


# Bounds for coefficient learning
MIN_MULTIPLIER = 0.3  # Don't go below 30% of base
MAX_MULTIPLIER = 3.0  # Don't go above 3x of base
LEARNING_RATE = 0.1   # How quickly to adjust (10% per iteration)


@dataclass
class TokenComparison:
    """Comparison of estimated vs actual tokens for a task."""

    task_id: str
    estimated_tokens: int
    actual_tokens: int
    task_type: str
    complexity: int
    completed_at: Optional[datetime] = None

    @property
    def ratio(self) -> float:
        """Calculate ratio (actual/estimated). 1.0 = perfect estimate."""
        if self.estimated_tokens == 0:
            return 1.0
        return self.actual_tokens / self.estimated_tokens

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSONL storage."""
        return {
            "task_id": self.task_id,
            "estimated_tokens": self.estimated_tokens,
            "actual_tokens": self.actual_tokens,
            "ratio": self.ratio,
            "task_type": self.task_type,
            "complexity": self.complexity,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class TokenFeedbackTracker:
    """Tracks token estimation accuracy and enables learning.

    The feedback loop works as follows:
    1. Record estimated vs actual tokens on task completion
    2. Calculate accuracy statistics by task type and complexity
    3. Recommend coefficient adjustments based on historical data
    4. Apply learning to improve future estimates
    """

    def __init__(self, history_dir: Path):
        self.history_dir = Path(history_dir)
        self.history_dir.mkdir(parents=True, exist_ok=True)
        self._comparisons_path = self.history_dir / "token-comparisons.jsonl"

    def record_usage(
        self,
        task_id: str,
        estimated_tokens: int,
        actual_tokens: int,
        task_type: str,
        complexity: int,
        completed_at: Optional[datetime] = None,
    ) -> Dict[str, Any]:
        """Record a token usage comparison."""
        comparison = TokenComparison(
            task_id=task_id,
            estimated_tokens=estimated_tokens,
            actual_tokens=actual_tokens,
            task_type=task_type,
            complexity=complexity,
            completed_at=completed_at or datetime.now(),
        )

        data = comparison.to_dict()

        try:
            with open(self._comparisons_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(data) + "\n")
        except Exception as e:
            logger.warning(f"Failed to record token comparison: {e}")

        return data

    def load_comparisons(self) -> List[Dict[str, Any]]:
        """Load all token comparisons."""
        comparisons = []

        if not self._comparisons_path.exists():
            return comparisons

        try:
            with open(self._comparisons_path, encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            data = json.loads(line)
                            comparisons.append(data)
                        except json.JSONDecodeError as e:
                            logger.warning(f"Failed to parse token comparison: {e}")
        except Exception as e:
            logger.warning(f"Failed to load token comparisons: {e}")

        return comparisons

    def get_accuracy_stats(self) -> Dict[str, Any]:
        """Get token accuracy statistics."""
        comparisons = self.load_comparisons()

        if not comparisons:
            return {
                "total_tasks": 0,
                "avg_ratio": 1.0,
                "by_task_type": {},
            }

        ratios = [c.get("ratio", 1.0) for c in comparisons]
        avg_ratio = sum(ratios) / len(ratios)

        by_type: Dict[str, List[float]] = {}
        for c in comparisons:
            task_type = c.get("task_type", "unknown")
            if task_type not in by_type:
                by_type[task_type] = []
            by_type[task_type].append(c.get("ratio", 1.0))

        by_type_stats = {}
        for task_type, type_ratios in by_type.items():
            by_type_stats[task_type] = {
                "count": len(type_ratios),
                "avg_ratio": sum(type_ratios) / len(type_ratios),
            }

        return {
            "total_tasks": len(comparisons),
            "avg_ratio": avg_ratio,
            "by_task_type": by_type_stats,
        }

    def get_recommended_adjustments(self, min_samples: int = 2) -> Dict[str, float]:
        """Get recommended coefficient adjustments based on data."""
        stats = self.get_accuracy_stats()
        by_type = stats.get("by_task_type", {})

        adjustments = {}
        for task_type, type_stats in by_type.items():
            if type_stats["count"] >= min_samples:
                adjustments[task_type] = type_stats["avg_ratio"]

        return adjustments

    def apply_learning(
        self,
        config: TokenEstimationConfig,
        min_samples: int = 2,
    ) -> TokenEstimationConfig:
        """Apply learning to adjust config coefficients."""
        adjustments = self.get_recommended_adjustments(min_samples)

        if not adjustments:
            return config

        new_multipliers = dict(config.by_task_type)

        for task_type, avg_ratio in adjustments.items():
            if task_type in new_multipliers:
                old_mult = new_multipliers[task_type]
                adjustment_factor = 1 + LEARNING_RATE * (avg_ratio - 1)
                new_mult = old_mult * adjustment_factor

                new_mult = max(MIN_MULTIPLIER, min(MAX_MULTIPLIER, new_mult))
                new_multipliers[task_type] = new_mult

        return TokenEstimationConfig(
            base_context=config.base_context,
            per_complexity_point=config.per_complexity_point,
            by_task_type=new_multipliers,
            per_file_touched=config.per_file_touched,
        )

    def persist_coefficients(
        self,
        config_path: Path,
        config: TokenEstimationConfig,
    ) -> None:
        """Write adjusted coefficients back to config.yaml.

        Merges token_estimates into the existing config file,
        preserving all other sections.

        Args:
            config_path: Path to config.yaml.
            config: The updated TokenEstimationConfig to persist.
        """
        try:
            if config_path.exists():
                data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
            else:
                config_path.parent.mkdir(parents=True, exist_ok=True)
                data = {}

            data["token_estimates"] = {
                "base_context": config.base_context,
                "per_complexity_point": config.per_complexity_point,
                "by_task_type": dict(config.by_task_type),
                "per_file_touched": config.per_file_touched,
            }
            config_path.write_text(
                yaml.dump(data, default_flow_style=False), encoding="utf-8"
            )
        except OSError:
            logger.warning("Could not persist coefficients to %s", config_path)

    def generate_report(self) -> Dict[str, Any]:
        """Generate a token accuracy report."""
        stats = self.get_accuracy_stats()
        adjustments = self.get_recommended_adjustments()

        recommendations = []
        for task_type, adj in adjustments.items():
            if adj > 1.1:
                pct = int((adj - 1) * 100)
                recommendations.append(
                    f"Increase {task_type} multiplier by ~{pct}%"
                )
            elif adj < 0.9:
                pct = int((1 - adj) * 100)
                recommendations.append(
                    f"Decrease {task_type} multiplier by ~{pct}%"
                )

        return {
            "stats": stats,
            "by_task_type": stats.get("by_task_type", {}),
            "recommendations": recommendations,
        }
