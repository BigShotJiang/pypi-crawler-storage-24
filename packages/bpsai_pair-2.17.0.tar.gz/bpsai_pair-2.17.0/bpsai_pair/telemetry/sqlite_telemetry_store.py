"""SQLite-backed telemetry record store.

Replaces JSONL TelemetryStore with SQL-backed storage for
queryable aggregates and efficient compaction.
"""

from __future__ import annotations

import logging
from pathlib import Path

from bpsai_pair.telemetry.schema import TelemetryRecord
from bpsai_pair.telemetry.sqlite_schema import ensure_schema, get_connection

logger = logging.getLogger(__name__)


_QUERY_FILTER_COLUMNS = {
    "task_id": "task_id = ?",
    "task_type": "task_type = ?",
    "model": "model = ?",
}

_PURGE_FILTER_COLUMNS = {
    "task_id": "task_id = ?",
    "before": "recorded_at < ?",
}


def _build_clauses(
    filters: dict[str, object],
    allowed: dict[str, str],
    method_name: str,
) -> tuple[list[str], list[object]]:
    """Build parameterized WHERE clauses from a fixed column allowlist.

    Raises ``ValueError`` for any key not present in *allowed*.
    """
    clauses: list[str] = []
    params: list[object] = []
    for key, value in filters.items():
        if key not in allowed:
            raise ValueError(
                f"Unknown filter '{key}' in {method_name}(). "
                f"Allowed: {sorted(allowed)}"
            )
        if value is not None:
            clauses.append(allowed[key])
            params.append(value)
    return clauses, params


class SQLiteTelemetryStore:
    """SQLite-backed telemetry storage with SQL aggregates."""

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = Path(db_path)
        conn = ensure_schema(self._db_path)
        conn.close()

    def append(self, record: TelemetryRecord) -> None:
        """Write a telemetry record to SQLite."""
        conn = get_connection(self._db_path)
        try:
            t = record.tokens
            conn.execute(
                "INSERT OR IGNORE INTO telemetry_records "
                "(task_id, task_type, repo, model, tokens_input, "
                "tokens_output, tokens_cache_read, tokens_cache_write, "
                "duration_seconds, human_interventions, compactions, "
                "outcome, recorded_at, session_id, sprint, complexity) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    record.task_id, record.task_type, record.repo,
                    record.model, t.input, t.output, t.cache_read,
                    t.cache_write, record.duration_seconds,
                    record.human_interventions, record.compactions,
                    record.outcome.value, record.timestamp.isoformat(),
                    record.session_id, record.sprint, record.complexity,
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def query(self, *, limit: int = 100, **filters: object) -> list[dict]:
        """Query records with optional filters. Returns list of dicts.

        Allowed filter keys: task_id, task_type, model.
        Raises ``ValueError`` for unknown keys.
        """
        limit = max(1, min(limit, 10000))
        clauses, params = _build_clauses(
            filters, _QUERY_FILTER_COLUMNS, "query"
        )
        conn = get_connection(self._db_path)
        try:
            sql = "SELECT * FROM telemetry_records"
            if clauses:
                sql += " WHERE " + " AND ".join(clauses)
            sql += " ORDER BY recorded_at DESC LIMIT ?"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_stats(self) -> dict:
        """Aggregate statistics via SQL."""
        conn = get_connection(self._db_path)
        try:
            row = conn.execute(
                "SELECT COUNT(*) as cnt, "
                "COALESCE(SUM(tokens_input + tokens_output), 0) as total_tok, "
                "COALESCE(SUM(duration_seconds), 0) as total_dur, "
                "SUM(CASE WHEN outcome='success' THEN 1 ELSE 0 END) as ok, "
                "SUM(CASE WHEN outcome='fail' THEN 1 ELSE 0 END) as fail "
                "FROM telemetry_records"
            ).fetchone()
            by_type = self._avg_tokens_by_type(conn)
            return {
                "total_records": row["cnt"],
                "total_tokens": row["total_tok"],
                "total_duration_seconds": row["total_dur"],
                "success_count": row["ok"] or 0,
                "fail_count": row["fail"] or 0,
                "avg_tokens_by_task_type": by_type,
            }
        finally:
            conn.close()

    def purge(self, **filters: object) -> int:
        """Delete records matching criteria. Returns count removed.

        Allowed filter keys: task_id, before.
        At least one filter must be provided to prevent accidental
        deletion of all records.  Raises ``ValueError`` for unknown keys.
        """
        clauses, params = _build_clauses(
            filters, _PURGE_FILTER_COLUMNS, "purge"
        )
        if not clauses:
            raise ValueError("purge() requires at least task_id or before")
        conn = get_connection(self._db_path)
        try:
            sql = "DELETE FROM telemetry_records WHERE " + " AND ".join(clauses)
            cursor = conn.execute(sql, params)
            conn.commit()
            return cursor.rowcount
        finally:
            conn.close()

    def _avg_tokens_by_type(self, conn) -> dict[str, float]:
        """Compute average total tokens per task type."""
        rows = conn.execute(
            "SELECT task_type, "
            "AVG(tokens_input + tokens_output) as avg_tok "
            "FROM telemetry_records GROUP BY task_type"
        ).fetchall()
        return {r["task_type"]: r["avg_tok"] for r in rows}
