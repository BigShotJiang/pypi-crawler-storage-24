"""SQLite-backed session outcome store.

Replaces per-session JSON files with SQLite storage.
Falls back to reading JSON files when SQLite DB doesn't exist.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from bpsai_pair.telemetry.session_outcomes import SessionOutcome
from bpsai_pair.telemetry.sqlite_schema import ensure_schema, get_connection

logger = logging.getLogger(__name__)


class SessionStore:
    """SQLite-backed session outcome storage with JSONL fallback."""

    def __init__(
        self, db_path: str | Path, fallback_dir: Path | None = None
    ) -> None:
        self._db_path = Path(db_path)
        self._fallback_dir = fallback_dir

    def record(self, outcome: SessionOutcome) -> None:
        """Write a session outcome to SQLite. Idempotent by session_id."""
        conn = ensure_schema(self._db_path)
        try:
            conn.execute(
                "INSERT OR IGNORE INTO sessions "
                "(session_id, started_at, ended_at, duration_s, outcome, "
                "agent_role, tasks_touched, tests_run, tests_passed, "
                "errors, enforcement_overrides) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    outcome.session_id,
                    outcome.started_at,
                    outcome.ended_at,
                    outcome.duration_s,
                    outcome.outcome,
                    outcome.agent_role,
                    json.dumps(outcome.tasks_touched),
                    outcome.tests_run,
                    outcome.tests_passed,
                    json.dumps(outcome.errors),
                    json.dumps(outcome.enforcement_overrides),
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def query_recent(self, limit: int = 10) -> list[SessionOutcome]:
        """Query recent sessions, newest first. Falls back to JSON."""
        limit = max(1, min(limit, 10000))
        if not self._db_path.exists():
            return self._fallback_query(limit)
        conn = get_connection(self._db_path)
        try:
            rows = conn.execute(
                "SELECT * FROM sessions ORDER BY ended_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return [self._row_to_outcome(r) for r in rows]
        finally:
            conn.close()

    def query_by_time_range(
        self, start: str, end: str
    ) -> list[SessionOutcome]:
        """Query sessions within a time range by started_at."""
        if not self._db_path.exists():
            return []
        conn = get_connection(self._db_path)
        try:
            rows = conn.execute(
                "SELECT * FROM sessions "
                "WHERE started_at >= ? AND started_at <= ? "
                "ORDER BY started_at",
                (start, end),
            ).fetchall()
            return [self._row_to_outcome(r) for r in rows]
        finally:
            conn.close()

    def _row_to_outcome(self, row) -> SessionOutcome:
        """Convert a SQLite row to SessionOutcome."""
        return SessionOutcome(
            session_id=row["session_id"],
            started_at=row["started_at"],
            ended_at=row["ended_at"],
            duration_s=row["duration_s"],
            tasks_touched=json.loads(row["tasks_touched"]),
            tests_run=row["tests_run"],
            tests_passed=row["tests_passed"],
            errors=json.loads(row["errors"]),
            enforcement_overrides=json.loads(row["enforcement_overrides"]),
            outcome=row["outcome"],
            agent_role=row["agent_role"],
        )

    def _dict_to_outcome(self, data: dict) -> SessionOutcome:
        """Convert a dict to SessionOutcome with explicit field mapping."""
        return SessionOutcome(
            session_id=data["session_id"],
            started_at=data["started_at"],
            ended_at=data["ended_at"],
            duration_s=data.get("duration_s", 0),
            tasks_touched=data.get("tasks_touched", []),
            tests_run=data.get("tests_run", 0),
            tests_passed=data.get("tests_passed", 0),
            errors=data.get("errors", []),
            enforcement_overrides=data.get("enforcement_overrides", []),
            outcome=data.get("outcome", "success"),
            agent_role=data.get("agent_role", "driver"),
        )

    def _fallback_query(self, limit: int) -> list[SessionOutcome]:
        """Read from JSON session files when SQLite doesn't exist."""
        if not self._fallback_dir:
            return []
        sessions_dir = self._fallback_dir / "sessions"
        if not sessions_dir.exists():
            return []
        results: list[SessionOutcome] = []
        for f in sessions_dir.glob("session_*.json"):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                results.append(self._dict_to_outcome(data))
            except (json.JSONDecodeError, TypeError, KeyError):
                logger.warning("Skipping corrupt session: %s", f)
        results.sort(key=lambda o: o.ended_at, reverse=True)
        return results[:limit]
