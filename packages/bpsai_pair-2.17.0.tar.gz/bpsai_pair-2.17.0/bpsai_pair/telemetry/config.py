"""Telemetry configuration management.

This module handles loading and saving telemetry configuration,
including privacy settings and retention policies.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

import yaml

from bpsai_pair.telemetry.schema import PrivacyLevel

logger = logging.getLogger(__name__)


@dataclass
class TelemetryConfig:
    """Configuration for telemetry collection and storage.

    Attributes:
        enabled: Whether telemetry collection is enabled
        privacy_level: The privacy level controlling what data is collected
        retention_days: How long to retain telemetry data
    """

    enabled: bool = True
    privacy_level: PrivacyLevel = PrivacyLevel.STANDARD
    retention_days: int = 90

    @classmethod
    def load(cls, project_root: Path) -> TelemetryConfig:
        """Load configuration from project telemetry config file.

        Args:
            project_root: Path to the project root directory

        Returns:
            TelemetryConfig with loaded or default values
        """
        config_file = project_root / ".paircoder" / "telemetry" / "config.yaml"

        if not config_file.exists():
            return cls()

        try:
            data = yaml.safe_load(config_file.read_text(encoding="utf-8")) or {}
        except (yaml.YAMLError, OSError) as e:
            logger.warning("Error loading telemetry config: %s", e)
            return cls()

        return cls._from_dict(data)

    @classmethod
    def _from_dict(cls, data: dict) -> TelemetryConfig:
        """Create config from dictionary with defaults for missing fields."""
        enabled = data.get("enabled", True)
        retention_days = data.get("retention_days", 90)

        # Parse privacy level with fallback to default
        privacy_level_str = data.get("privacy_level", "standard")

        # Auto-migrate removed OFF level to MINIMAL
        if privacy_level_str == "off":
            logger.info("Migrating removed privacy level 'off' to 'minimal'")
            privacy_level_str = "minimal"

        try:
            privacy_level = PrivacyLevel(privacy_level_str)
        except ValueError:
            logger.warning(
                "Invalid privacy level '%s', using default 'standard'",
                privacy_level_str,
            )
            privacy_level = PrivacyLevel.STANDARD

        return cls(
            enabled=enabled,
            privacy_level=privacy_level,
            retention_days=retention_days,
        )

    def save(self, project_root: Path) -> None:
        """Save configuration to project telemetry config file.

        Args:
            project_root: Path to the project root directory
        """
        config_dir = project_root / ".paircoder" / "telemetry"
        config_dir.mkdir(parents=True, exist_ok=True)
        config_file = config_dir / "config.yaml"

        data = {
            "enabled": self.enabled,
            "privacy_level": self.privacy_level.value,
            "retention_days": self.retention_days,
        }

        config_file.write_text(yaml.dump(data, default_flow_style=False), encoding="utf-8")
