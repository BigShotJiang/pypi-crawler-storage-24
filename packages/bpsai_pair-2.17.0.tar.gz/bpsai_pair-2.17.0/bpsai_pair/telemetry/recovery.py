"""Historical data recovery from Claude Code session archives.

Parses weekly archive snapshots (~/.claude-archives/claude-sessions-YYYY-MM-DD.tar.gz)
to reconstruct telemetry with correct cache field values. Recovered data is
compacted into weekly aggregates for long-term retention.

Low-level archive helpers live in ``recovery_helpers`` to keep both modules
under architecture limits.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from bpsai_pair.telemetry.parser import ClaudeSessionParser
from bpsai_pair.telemetry.recovery_helpers import (
    ProjectSessions,
    SessionData,
    extract_cache_fields,
    extract_session_id,
    identify_project,
    parse_archive,
    week_key_from_datetime,
)

logger = logging.getLogger(__name__)

# Re-export for public API
__all__ = [
    "RecoveredAggregate",
    "aggregate_sessions",
    "identify_project",
    "parse_archive",
    "ProjectSessions",
    "SessionData",
]


@dataclass
class RecoveredAggregate:
    """Weekly aggregate of recovered session telemetry."""

    week_key: str  # ISO week like "2026-W03"
    project_name: str
    session_count: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    cache_creation_tokens: int = 0
    cache_read_tokens: int = 0
    total_duration_seconds: float = 0.0
    models_seen: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "week_key": self.week_key,
            "project_name": self.project_name,
            "session_count": self.session_count,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "cache_creation_tokens": self.cache_creation_tokens,
            "cache_read_tokens": self.cache_read_tokens,
            "total_duration_seconds": self.total_duration_seconds,
            "models_seen": self.models_seen,
        }


def aggregate_sessions(
    sessions: list[SessionData], *, project_name: str
) -> list[RecoveredAggregate]:
    """Aggregate session data into weekly buckets.

    Uses ``ClaudeSessionParser`` for metrics extraction and groups results
    by ISO week. Cache fields are extracted directly from raw entries.

    Args:
        sessions: List of session dicts with ``entries`` and ``session_file``.
        project_name: Human-readable project name for the aggregates.

    Returns:
        List of ``RecoveredAggregate``, one per week, sorted oldest-first.
    """
    parser = ClaudeSessionParser()
    buckets: dict[str, RecoveredAggregate] = {}

    for session in sessions:
        entries = session.get("entries", [])
        if not entries:
            continue

        metrics = parser.extract_metrics(entries)
        if metrics.start_time is None:
            continue

        week = week_key_from_datetime(metrics.start_time)
        if week not in buckets:
            buckets[week] = RecoveredAggregate(
                week_key=week, project_name=project_name
            )
        agg = buckets[week]
        agg.session_count += 1
        agg.total_input_tokens += metrics.total_input_tokens
        agg.total_output_tokens += metrics.total_output_tokens
        agg.total_duration_seconds += metrics.duration_seconds

        cc, cr = extract_cache_fields(entries)
        agg.cache_creation_tokens += cc
        agg.cache_read_tokens += cr

        if metrics.model and metrics.model not in agg.models_seen:
            agg.models_seen.append(metrics.model)

    return sorted(buckets.values(), key=lambda a: a.week_key)


def deduplicate_sessions(
    sessions: list[SessionData], seen_ids: set[str]
) -> list[SessionData]:
    """Filter out sessions that have already been processed.

    Uses session IDs when available; falls back to the archive file path.
    Mutates ``seen_ids`` by adding newly encountered identifiers.

    Args:
        sessions: List of session dicts from ``parse_archive()``.
        seen_ids: Set of already-processed identifiers (mutated in-place).

    Returns:
        List of sessions that have not been seen before.
    """
    unique: list[SessionData] = []
    for session in sessions:
        key = extract_session_id(session.get("entries", []))
        if key is None:
            key = session.get("session_file", "")
        if key in seen_ids:
            continue
        seen_ids.add(key)
        unique.append(session)
    return unique


@dataclass
class RecoveryResult:
    """Summary of a recovery run."""

    archives_processed: int = 0
    sessions_recovered: int = 0
    duplicates_skipped: int = 0
    aggregates_written: int = 0


class RecoveryOrchestrator:
    """Scans an archive directory and recovers historical telemetry.

    Processes archives oldest-first, deduplicates sessions across archives,
    aggregates into weekly buckets, and writes results as JSONL.
    """

    def __init__(
        self,
        archive_dir: Path,
        output_dir: Path,
        *,
        dry_run: bool = False,
        project_filter: str | None = None,
    ) -> None:
        self.archive_dir = archive_dir
        self.output_dir = output_dir
        self.dry_run = dry_run
        self.project_filter = project_filter

    def _find_archives(self) -> list[Path]:
        """Find .tar.gz archives sorted oldest-first by name."""
        archives = list(self.archive_dir.glob("claude-sessions-*.tar.gz"))
        archives.sort(key=lambda p: p.name)
        return archives

    def run(self) -> RecoveryResult:
        """Execute the full recovery pipeline.

        Returns:
            RecoveryResult with processing statistics.
        """
        result = RecoveryResult()
        seen_ids: set[str] = set()
        all_aggregates: list[RecoveredAggregate] = []

        for archive_path in self._find_archives():
            project_sessions = parse_archive(archive_path)
            result.archives_processed += 1

            for _hash, sessions in project_sessions.items():
                project_name = identify_project(_hash, None)
                if self.project_filter and project_name != self.project_filter:
                    continue

                before = len(seen_ids)
                unique = deduplicate_sessions(sessions, seen_ids)
                after = len(seen_ids)
                skipped = len(sessions) - len(unique)
                result.duplicates_skipped += skipped
                result.sessions_recovered += len(unique)

                aggregates = aggregate_sessions(unique, project_name=project_name)
                all_aggregates.extend(aggregates)

        if all_aggregates and not self.dry_run:
            self._write_aggregates(all_aggregates)
            result.aggregates_written = len(all_aggregates)
        elif all_aggregates:
            result.aggregates_written = 0

        return result

    def _write_aggregates(self, aggregates: list[RecoveredAggregate]) -> None:
        """Write aggregates to JSONL file in the output directory."""
        self.output_dir.mkdir(parents=True, exist_ok=True)
        output_file = self.output_dir / "recovered_aggregates.jsonl"
        with open(output_file, "w", encoding="utf-8") as f:
            for agg in aggregates:
                f.write(json.dumps(agg.to_dict()) + "\n")
