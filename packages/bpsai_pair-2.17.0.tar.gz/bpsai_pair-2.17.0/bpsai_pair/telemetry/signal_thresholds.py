"""Signal threshold configuration and defaults."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class SignalThresholds:
    """Configurable thresholds for session signal emission."""

    duration_multiplier: float = 2.0
    budget_breach_pct: float = 1.0
    enforcement_failure_count: int = 3
    rolling_window: int = 10


def load_thresholds(config_path: Path) -> SignalThresholds:
    """Load thresholds from config.yaml signals.thresholds section.

    Returns defaults when config is missing or malformed.
    """
    import yaml

    if not config_path.exists():
        return SignalThresholds()
    try:
        config = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        section = config.get("signals", {}).get("thresholds", {})
        kwargs = {k: v for k, v in section.items() if hasattr(SignalThresholds, k)}
        return SignalThresholds(**kwargs)
    except Exception:
        return SignalThresholds()