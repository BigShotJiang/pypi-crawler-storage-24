"""SQLite schema for PairCoder telemetry, sessions, and Computer tick state.

Defines 6 tables: sessions, telemetry_records, calibration_data,
ticks, tick_events, schema_version. WAL mode for concurrent access.
"""

from __future__ import annotations

import logging
import os
import stat
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

SCHEMA_VERSION = 1

_ENSURED_PATHS: set[str] = set()

_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    started_at TEXT NOT NULL,
    ended_at TEXT NOT NULL,
    duration_s INTEGER DEFAULT 0,
    outcome TEXT DEFAULT 'success',
    agent_role TEXT DEFAULT 'driver',
    tasks_touched TEXT DEFAULT '[]',
    tests_run INTEGER DEFAULT 0,
    tests_passed INTEGER DEFAULT 0,
    errors TEXT DEFAULT '[]',
    enforcement_overrides TEXT DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS telemetry_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    task_type TEXT NOT NULL,
    repo TEXT NOT NULL,
    model TEXT NOT NULL,
    tokens_input INTEGER DEFAULT 0,
    tokens_output INTEGER DEFAULT 0,
    tokens_cache_read INTEGER DEFAULT 0,
    tokens_cache_write INTEGER DEFAULT 0,
    duration_seconds INTEGER DEFAULT 0,
    human_interventions INTEGER DEFAULT 0,
    compactions INTEGER DEFAULT 0,
    outcome TEXT DEFAULT 'success',
    recorded_at TEXT NOT NULL,
    session_id TEXT,
    sprint TEXT,
    complexity INTEGER,
    UNIQUE(task_id, recorded_at)
);

CREATE TABLE IF NOT EXISTS calibration_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_type TEXT NOT NULL,
    model TEXT,
    success_rate REAL,
    avg_tokens REAL,
    avg_duration REAL,
    sample_count INTEGER DEFAULT 0,
    updated_at TEXT NOT NULL,
    UNIQUE(task_type, model)
);

CREATE TABLE IF NOT EXISTS ticks (
    tick_id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    tick_number INTEGER NOT NULL,
    system_state TEXT,
    cadence_decision_ms INTEGER,
    phases_completed TEXT DEFAULT '[]',
    phase_durations_ms TEXT DEFAULT '{}',
    events_processed INTEGER DEFAULT 0,
    signals_emitted INTEGER DEFAULT 0,
    decisions_recorded INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS tick_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tick_id INTEGER,
    event_type TEXT NOT NULL,
    priority TEXT DEFAULT 'NORMAL',
    source TEXT,
    payload TEXT DEFAULT '{}',
    received_at TEXT NOT NULL,
    processed_at TEXT,
    FOREIGN KEY (tick_id) REFERENCES ticks(tick_id)
);

CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL,
    description TEXT
);
"""

_INDEXES_SQL = """
CREATE INDEX IF NOT EXISTS idx_sessions_started_at
    ON sessions(started_at);
CREATE INDEX IF NOT EXISTS idx_telemetry_recorded_at
    ON telemetry_records(recorded_at, task_type, model);
CREATE INDEX IF NOT EXISTS idx_ticks_timestamp
    ON ticks(timestamp);
CREATE INDEX IF NOT EXISTS idx_tick_events_tick_id
    ON tick_events(tick_id, priority);
"""


def ensure_schema(db_path: str | Path) -> sqlite3.Connection:
    """Create tables if needed, enable WAL, return connection."""
    db_path = Path(db_path)
    path_key = str(db_path)
    if path_key in _ENSURED_PATHS:
        return get_connection(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    created = not db_path.exists()
    conn = sqlite3.connect(str(db_path), timeout=10)
    conn.row_factory = sqlite3.Row
    if created and os.name != "nt":
        db_path.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(_TABLES_SQL)
    conn.executescript(_INDEXES_SQL)
    _record_version(conn)
    _ENSURED_PATHS.add(path_key)
    return conn


def get_connection(db_path: str | Path) -> sqlite3.Connection:
    """Open an existing database with row factory."""
    conn = sqlite3.connect(str(db_path), timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def _record_version(conn: sqlite3.Connection) -> None:
    """Record schema version if not already present."""
    existing = conn.execute(
        "SELECT version FROM schema_version WHERE version = ?",
        (SCHEMA_VERSION,),
    ).fetchone()
    if existing:
        return
    conn.execute(
        "INSERT INTO schema_version (version, applied_at, description) "
        "VALUES (?, ?, ?)",
        (
            SCHEMA_VERSION,
            datetime.now(timezone.utc).isoformat(),
            "Initial schema: sessions, telemetry, calibration, ticks",
        ),
    )
    conn.commit()
    logger.info("Schema version %d recorded", SCHEMA_VERSION)
