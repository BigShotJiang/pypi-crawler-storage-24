"""Convenience function for logging task state transitions.

Called from task update and ttask done code paths. Non-blocking —
failures are logged but never interrupt task completion.
"""

from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def log_task_state_transition(
    paircoder_dir: Path,
    task_id: str,
    old_state: str,
    new_state: str,
    plan_id: str | None = None,
    metadata: dict | None = None,
) -> None:
    """Record a task state transition to SQLite. Best-effort, non-blocking."""
    try:
        from bpsai_pair.telemetry.task_state_index import TaskStateIndex

        db_path = paircoder_dir / "data" / "store.db"
        idx = TaskStateIndex(db_path)
        idx.log_transition(
            task_id, old_state, new_state,
            plan_id=plan_id, metadata=metadata,
        )
        logger.debug(
            "Task state logged: %s %s -> %s", task_id, old_state, new_state
        )
    except Exception as e:
        logger.debug("Task state logging skipped: %s", e)
