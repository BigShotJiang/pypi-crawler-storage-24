"""Helper functions for telemetry analytics queries.

Extracted from queries.py to maintain architecture compliance
(max 15 functions per file).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from bpsai_pair.telemetry.aggregates import AggregateRecord
    from bpsai_pair.telemetry.schema import TelemetryRecord


def sum_aggregate_tokens(
    aggregates: list[AggregateRecord],
) -> tuple[int, int, int]:
    """Sum input, output tokens and record count from aggregates.

    Returns:
        (total_input, total_output, total_count) tuple.
    """
    total_input = sum(a.total_tokens.input for a in aggregates)
    total_output = sum(a.total_tokens.output for a in aggregates)
    total_count = sum(a.record_count for a in aggregates)
    return total_input, total_output, total_count


def estimate_aggregate_cost(
    total_input: int, total_output: int, pricing: dict
) -> float:
    """Estimate cost for aggregate tokens using given pricing.

    Args:
        total_input: Total input tokens from aggregates.
        total_output: Total output tokens from aggregates.
        pricing: Dict with input_per_1m and output_per_1m keys.

    Returns:
        Estimated cost in dollars.
    """
    input_cost = (total_input / 1_000_000) * pricing.get("input_per_1m", 3.0)
    output_cost = (total_output / 1_000_000) * pricing.get("output_per_1m", 15.0)
    return input_cost + output_cost


def compute_cache_stats(
    records: list[TelemetryRecord],
    aggregates: list[AggregateRecord],
) -> dict:
    """Compute cache effectiveness statistics from raw + aggregates.

    Args:
        records: Raw telemetry records.
        aggregates: Compacted aggregate records.

    Returns:
        Dict with total_cache_read, total_cache_write,
        cache_hit_rate, total_input_tokens.
    """
    raw_cache_read = sum(r.tokens.cache_read for r in records)
    raw_cache_write = sum(r.tokens.cache_write for r in records)
    raw_input = sum(r.tokens.input for r in records)

    agg_cache_read = sum(a.total_tokens.cache_read for a in aggregates)
    agg_cache_write = sum(a.total_tokens.cache_write for a in aggregates)
    agg_input = sum(a.total_tokens.input for a in aggregates)

    total_cache_read = raw_cache_read + agg_cache_read
    total_cache_write = raw_cache_write + agg_cache_write
    total_input = raw_input + agg_input

    denominator = total_cache_read + total_input
    hit_rate = total_cache_read / denominator if denominator > 0 else 0.0

    return {
        "total_cache_read": total_cache_read,
        "total_cache_write": total_cache_write,
        "cache_hit_rate": round(hit_rate, 4),
        "total_input_tokens": total_input,
    }
