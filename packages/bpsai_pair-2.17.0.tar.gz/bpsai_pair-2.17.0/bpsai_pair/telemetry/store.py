"""Telemetry store for persisting telemetry records.

This module provides storage for telemetry records in JSONL format,
supporting append operations, queries with filtering, and aggregate statistics.
"""

from __future__ import annotations

import json
import logging
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from bpsai_pair.telemetry.schema import Outcome, TelemetryRecord

logger = logging.getLogger(__name__)

# Cross-platform file locking
if sys.platform == "win32":
    import msvcrt

    def _lock_file(f) -> None:
        """Lock file on Windows."""
        msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)

    def _unlock_file(f) -> None:
        """Unlock file on Windows."""
        msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
else:
    import fcntl

    def _lock_file(f) -> None:
        """Lock file on Unix."""
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)

    def _unlock_file(f) -> None:
        """Unlock file on Unix."""
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)


@dataclass
class TelemetryStats:
    """Aggregate statistics from telemetry records."""

    total_records: int
    total_tokens: int
    total_duration_seconds: int
    success_rate: float
    avg_tokens_by_task_type: dict[str, float] = field(default_factory=dict)


class TelemetryStore:
    """Store for telemetry records with JSONL persistence.

    Records are stored in `.paircoder/telemetry/telemetry.jsonl` as
    append-only JSONL format. Supports filtering queries and aggregate
    statistics for the feedback loop.
    """

    def __init__(self, project_root: Path) -> None:
        """Initialize the telemetry store.

        Args:
            project_root: Path to the project root directory
        """
        self.project_root = project_root
        self.telemetry_dir = project_root / ".paircoder" / "telemetry"
        self._telemetry_file = self.telemetry_dir / "telemetry.jsonl"
        self._aggregates_file = self.telemetry_dir / "telemetry_aggregates.jsonl"

    def _ensure_directory(self) -> None:
        """Create telemetry directory if it doesn't exist."""
        self.telemetry_dir.mkdir(parents=True, exist_ok=True)

    def append(self, record: TelemetryRecord) -> None:
        """Append a telemetry record to the store.

        Creates the telemetry directory and file if they don't exist.
        Uses file locking for concurrent access safety.

        Args:
            record: The telemetry record to append
        """
        self._ensure_directory()
        json_line = record.to_json() + "\n"

        with open(self._telemetry_file, "a", encoding="utf-8") as f:
            _lock_file(f)
            try:
                f.write(json_line)
            finally:
                _unlock_file(f)

    def _read_all_records(self) -> list[TelemetryRecord]:
        """Read all records from the telemetry file.

        Returns:
            List of all telemetry records, or empty list if file doesn't exist
        """
        if not self._telemetry_file.exists():
            return []

        records: list[TelemetryRecord] = []
        try:
            with open(self._telemetry_file, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        records.append(TelemetryRecord.from_json(line))
                    except (json.JSONDecodeError, KeyError, ValueError) as e:
                        logger.debug(
                            "Skipping malformed record at line %d: %s", line_num, e
                        )
        except OSError as e:
            logger.warning("Error reading telemetry file: %s", e)

        return records

    def query(
        self,
        task_id: str | None = None,
        task_type: str | None = None,
        since: datetime | None = None,
        until: datetime | None = None,
        limit: int = 100,
        session_id: str | None = None,
    ) -> list[TelemetryRecord]:
        """Query telemetry records with filters.

        Args:
            task_id: Filter by exact task_id match
            task_type: Filter by task type (feature, bugfix, chore, etc.)
            since: Filter records with timestamp >= since
            until: Filter records with timestamp <= until
            limit: Maximum number of records to return (default 100)
            session_id: Filter by exact session_id match

        Returns:
            List of matching records, sorted by timestamp descending (recent first)
        """
        records = self._read_all_records()

        # Apply filters
        if task_id is not None:
            records = [r for r in records if r.task_id == task_id]
        if task_type is not None:
            records = [r for r in records if r.task_type == task_type]
        if session_id is not None:
            records = [r for r in records if r.session_id == session_id]
        if since is not None:
            records = [r for r in records if r.timestamp >= since]
        if until is not None:
            records = [r for r in records if r.timestamp <= until]

        # Sort by timestamp descending (most recent first)
        records.sort(key=lambda r: r.timestamp, reverse=True)

        # Apply limit
        return records[:limit]

    def purge(
        self,
        task_id: str | None = None,
        before: str | None = None,
    ) -> int:
        """Remove telemetry records matching criteria.

        Args:
            task_id: Remove records with this task_id
            before: Remove records with timestamp before this date (YYYY-MM-DD)

        Returns:
            Count of removed records
        """
        records = self._read_all_records()
        if not records:
            return 0

        before_dt = None
        if before:
            before_dt = datetime.strptime(before, "%Y-%m-%d").replace(
                tzinfo=records[0].timestamp.tzinfo
                if records[0].timestamp.tzinfo
                else None
            )

        def should_remove(r: TelemetryRecord) -> bool:
            if task_id and r.task_id == task_id:
                return True
            if before_dt and r.timestamp < before_dt:
                return True
            return False

        kept = [r for r in records if not should_remove(r)]
        removed = len(records) - len(kept)

        if removed > 0:
            self._ensure_directory()
            with open(self._telemetry_file, "w", encoding="utf-8") as f:
                _lock_file(f)
                try:
                    for r in kept:
                        f.write(r.to_json() + "\n")
                finally:
                    _unlock_file(f)

        return removed

    def get_stats(self) -> TelemetryStats:
        """Get blended statistics from raw records + compacted aggregates."""
        records = self._read_all_records()
        aggregates = self.load_aggregates()
        raw_count, raw_tokens, raw_dur, raw_ok = len(records), 0, 0, 0
        for r in records:
            raw_tokens += r.tokens.total
            raw_dur += r.duration_seconds
            raw_ok += 1 if r.outcome == Outcome.SUCCESS else 0

        agg_count = sum(a.record_count for a in aggregates)
        agg_tokens = sum(a.total_tokens.input + a.total_tokens.output for a in aggregates)
        agg_dur = sum(int(a.total_duration_seconds) for a in aggregates)
        agg_ok = sum(a.success_count for a in aggregates)
        total = raw_count + agg_count
        if total == 0:
            return TelemetryStats(
                total_records=0, total_tokens=0,
                total_duration_seconds=0, success_rate=0.0,
                avg_tokens_by_task_type={},
            )

        tokens_by_type: dict[str, list[int]] = {}
        for r in records:
            tokens_by_type.setdefault(r.task_type, []).append(r.tokens.total)

        return TelemetryStats(
            total_records=total,
            total_tokens=raw_tokens + agg_tokens,
            total_duration_seconds=raw_dur + agg_dur,
            success_rate=(raw_ok + agg_ok) / total,
            avg_tokens_by_task_type={
                t: sum(v) / len(v) for t, v in tokens_by_type.items()
            },
        )

    def save_aggregate(self, aggregate: object) -> None:
        """Append an aggregate record to the aggregates file."""
        self._ensure_directory()
        json_line = json.dumps(aggregate.to_dict()) + "\n"  # type: ignore[union-attr]

        with open(self._aggregates_file, "a", encoding="utf-8") as f:
            _lock_file(f)
            try:
                f.write(json_line)
            finally:
                _unlock_file(f)

    def load_aggregates(self) -> list:
        """Load all aggregate records from the aggregates file."""
        from bpsai_pair.telemetry.aggregates import AggregateRecord

        if not self._aggregates_file.exists():
            return []

        aggregates: list = []
        try:
            with open(self._aggregates_file, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        aggregates.append(
                            AggregateRecord.from_dict(json.loads(line))
                        )
                    except (json.JSONDecodeError, KeyError, ValueError) as e:
                        logger.debug(
                            "Skipping malformed aggregate at line %d: %s",
                            line_num,
                            e,
                        )
        except OSError as e:
            logger.warning("Error reading aggregates file: %s", e)

        return aggregates

    def _write_records(self, records: list[TelemetryRecord]) -> None:
        """Overwrite the telemetry file with the given records.

        Used by the compaction engine to remove compacted records.
        """
        self._ensure_directory()
        with open(self._telemetry_file, "w", encoding="utf-8") as f:
            _lock_file(f)
            try:
                for record in records:
                    f.write(record.to_json() + "\n")
            finally:
                _unlock_file(f)
