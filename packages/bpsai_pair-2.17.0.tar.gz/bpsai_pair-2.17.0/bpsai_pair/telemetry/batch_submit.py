"""Batch telemetry submission on compaction.

Submits aggregated usage snapshots to the API when compaction runs,
respecting privacy tier settings. Queues snapshots offline for later
submission when the API is unreachable.
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_API_URL = os.environ.get(
    "PAIRCODER_API_URL", "https://api.paircoder.ai"
)
DEFAULT_TIMEOUT = 5

_OFFLINE_QUEUE_FILE = "submit_queue.jsonl"


def submit_telemetry_snapshot(
    snapshot: dict[str, Any],
    api_url: str = DEFAULT_API_URL,
    timeout: int = DEFAULT_TIMEOUT,
) -> bool:
    """POST a usage snapshot to the telemetry ingest endpoint.

    Args:
        snapshot: Snapshot dict (from UsageSnapshot.to_dict()).
        api_url: Base API URL.
        timeout: Request timeout in seconds.

    Returns:
        True if submission succeeded, False on any failure.
    """
    url = f"{api_url.rstrip('/')}/telemetry/ingest"
    data = json.dumps({"usage_snapshot": snapshot}).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            resp.read()
        return True
    except (urllib.error.URLError, urllib.error.HTTPError, OSError):
        logger.debug("Telemetry submission failed", exc_info=True)
        return False


def _queue_offline(project_root: Path, snapshot: dict[str, Any]) -> None:
    """Append a snapshot to the offline queue for later submission."""
    queue_path = (
        project_root / ".paircoder" / "telemetry" / _OFFLINE_QUEUE_FILE
    )
    queue_path.parent.mkdir(parents=True, exist_ok=True)
    with queue_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(snapshot) + "\n")
    logger.info("Queued telemetry snapshot for later submission")


def build_and_submit_on_compaction(project_root: Path) -> None:
    """Build a usage snapshot and submit it after compaction.

    Reads privacy level from config, builds snapshot accordingly,
    and POSTs to the API. On failure, queues for next online session.

    Args:
        project_root: Path to the project root directory.
    """
    from bpsai_pair.telemetry.config import TelemetryConfig
    from bpsai_pair.telemetry.snapshot import build_usage_snapshot

    try:
        config = TelemetryConfig.load(project_root)
        snapshot = build_usage_snapshot(project_root, config.privacy_level)
        snapshot_dict = snapshot.to_dict()
    except Exception:
        logger.debug("Failed to build snapshot for submission", exc_info=True)
        return

    success = submit_telemetry_snapshot(snapshot_dict)
    if not success:
        _queue_offline(project_root, snapshot_dict)
