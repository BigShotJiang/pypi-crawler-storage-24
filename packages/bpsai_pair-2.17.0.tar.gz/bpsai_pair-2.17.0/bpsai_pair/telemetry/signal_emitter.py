"""Signal emission from session hooks.

Analyzes session outcomes and emits signals for anomalies:
duration spikes, budget breaches, enforcement failure patterns.
Signals persisted to local JSONL file.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .session_outcomes import (
    SessionOutcome,
    SessionOutcomeRecorder,
)
from .signal_thresholds import SignalThresholds

logger = logging.getLogger(__name__)


@dataclass
class EmittedSignal:
    """A signal emitted from session analysis."""

    signal_type: str
    severity: str
    timestamp: str
    session_id: str
    payload: dict = field(default_factory=dict)


class SignalEmitter:
    """Analyzes session outcomes and emits anomaly signals."""

    def __init__(
        self, project_root: Path, thresholds: SignalThresholds | None = None
    ) -> None:
        self._root = project_root
        self._thresholds = thresholds or SignalThresholds()
        self._signals_path = (
            project_root / ".paircoder" / "telemetry" / "signals.jsonl"
        )

    def emit_session_signals(
        self, outcome: SessionOutcome
    ) -> list[EmittedSignal]:
        """Analyze outcome and emit relevant signals."""
        signals: list[EmittedSignal] = []
        for check in (
            self._check_duration_anomaly,
            self._check_budget_breach,
            self._check_enforcement_failures,
        ):
            signal = check(outcome)
            if signal:
                signals.append(signal)
        self._persist_signals(signals)
        return signals

    def _check_duration_anomaly(
        self, outcome: SessionOutcome
    ) -> EmittedSignal | None:
        """Emit if session duration exceeds rolling avg * multiplier."""
        recorder = SessionOutcomeRecorder(self._root)
        recent = recorder.list_recent(self._thresholds.rolling_window)
        other = [s for s in recent if s.session_id != outcome.session_id]
        if len(other) < 2:
            return None
        avg_duration = sum(s.duration_s for s in other) / len(other)
        if avg_duration <= 0:
            return None
        if outcome.duration_s <= avg_duration * self._thresholds.duration_multiplier:
            return None
        return EmittedSignal(
            signal_type="session_duration_anomaly",
            severity="warning",
            timestamp=datetime.now(timezone.utc).isoformat(),
            session_id=outcome.session_id,
            payload={
                "duration_s": outcome.duration_s,
                "rolling_avg_s": round(avg_duration, 1),
                "multiplier": self._thresholds.duration_multiplier,
            },
        )

    def _check_budget_breach(
        self, outcome: SessionOutcome
    ) -> EmittedSignal | None:
        """Emit if session errors contain budget-related messages."""
        budget_errors = [e for e in outcome.errors if "budget" in e.lower()]
        if not budget_errors:
            return None
        return EmittedSignal(
            signal_type="budget_threshold_breach",
            severity="warning",
            timestamp=datetime.now(timezone.utc).isoformat(),
            session_id=outcome.session_id,
            payload={"budget_errors": budget_errors},
        )

    def _check_enforcement_failures(
        self, outcome: SessionOutcome
    ) -> EmittedSignal | None:
        """Emit if enforcement overrides exceed threshold."""
        count = len(outcome.enforcement_overrides)
        if count < self._thresholds.enforcement_failure_count:
            return None
        return EmittedSignal(
            signal_type="enforcement_failure_pattern",
            severity="critical",
            timestamp=datetime.now(timezone.utc).isoformat(),
            session_id=outcome.session_id,
            payload={
                "override_count": count,
                "overrides": outcome.enforcement_overrides[:5],
            },
        )

    def emit_api_failure(
        self,
        stop_reason: str,
        error_detail: str = "",
        session_id: str = "",
    ) -> EmittedSignal:
        """Emit an api_failure signal when Claude Code stops due to API error.

        Called by the StopFailure hook to make autonomous dispatch failures
        visible in telemetry.

        Args:
            stop_reason: The stop reason from $CLAUDE_STOP_REASON.
            error_detail: Additional detail about the failure.
            session_id: The session ID, if available.

        Returns:
            The emitted signal.
        """
        signal = EmittedSignal(
            signal_type="api_failure",
            severity="warning",
            timestamp=datetime.now(timezone.utc).isoformat(),
            session_id=session_id,
            payload={
                "stop_reason": stop_reason,
                "error_detail": error_detail,
            },
        )
        self._persist_signals([signal])
        return signal

    def emit_sprint_lifecycle(
        self,
        event: str,
        sprint_id: int | str,
        details: dict[str, Any] | None = None,
    ) -> EmittedSignal:
        """Emit a sprint lifecycle signal (start/complete)."""
        signal = EmittedSignal(
            signal_type="sprint_lifecycle",
            severity="info",
            timestamp=datetime.now(timezone.utc).isoformat(),
            session_id="",
            payload={
                "event": event,
                "sprint_id": sprint_id,
                **(details or {}),
            },
        )
        self._persist_signals([signal])
        return signal

    def emit_task_failure_pattern(
        self,
        failed_tasks: list[str],
        pattern_description: str = "",
    ) -> EmittedSignal:
        """Emit when consecutive task failures are detected."""
        signal = EmittedSignal(
            signal_type="task_failure_pattern",
            severity="critical",
            timestamp=datetime.now(timezone.utc).isoformat(),
            session_id="",
            payload={
                "failed_tasks": failed_tasks,
                "failure_count": len(failed_tasks),
                "pattern": pattern_description,
            },
        )
        self._persist_signals([signal])
        return signal

    def emit_qc_gate_result(
        self,
        suite_name: str,
        pass_rate: float,
        blocked: bool,
        failed_count: int,
        error_count: int,
    ) -> EmittedSignal:
        """Emit QC gate evaluation result."""
        if blocked:
            severity = "critical"
        elif failed_count > 0 or error_count > 0:
            severity = "warning"
        else:
            severity = "info"

        signal = EmittedSignal(
            signal_type="qc_gate_result",
            severity=severity,
            timestamp=datetime.now(timezone.utc).isoformat(),
            session_id="",
            payload={
                "suite_name": suite_name,
                "pass_rate": pass_rate,
                "blocked": blocked,
                "failed_count": failed_count,
                "error_count": error_count,
            },
        )
        self._persist_signals([signal])
        return signal

    def _persist_signals(self, signals: list[EmittedSignal]) -> None:
        """Append signals to JSONL file."""
        if not signals:
            return
        self._signals_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._signals_path, "a", encoding="utf-8") as f:
            for signal in signals:
                f.write(json.dumps(asdict(signal)) + "\n")