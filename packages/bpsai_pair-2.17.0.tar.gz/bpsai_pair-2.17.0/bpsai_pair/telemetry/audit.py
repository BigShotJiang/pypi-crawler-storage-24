"""Hash-chained audit log for tamper-evident telemetry tracking.

This module provides an immutable audit trail where each entry includes
a hash of the previous entry, creating a chain that detects any modifications.
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class AuditEntry:
    """A single audit log entry with hash chain linking."""

    sequence: int
    timestamp: datetime
    action: str
    data_hash: str
    previous_hash: str
    entry_hash: str

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "sequence": self.sequence,
            "timestamp": self.timestamp.isoformat(),
            "action": self.action,
            "data_hash": self.data_hash,
            "previous_hash": self.previous_hash,
            "entry_hash": self.entry_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AuditEntry:
        """Deserialize from dictionary."""
        timestamp = data["timestamp"]
        if isinstance(timestamp, str):
            timestamp = datetime.fromisoformat(timestamp)
        return cls(
            sequence=data["sequence"],
            timestamp=timestamp,
            action=data["action"],
            data_hash=data["data_hash"],
            previous_hash=data["previous_hash"],
            entry_hash=data["entry_hash"],
        )

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> AuditEntry:
        """Deserialize from JSON string."""
        return cls.from_dict(json.loads(json_str))


class AuditLog:
    """Hash-chained audit log for tamper-evident tracking.

    Each entry includes a SHA-256 hash that incorporates the previous
    entry's hash, creating an immutable chain. Any modification to
    the log breaks the chain and is detectable via verify().
    """

    GENESIS_HASH = "0" * 64  # Known constant for chain start

    def __init__(self, audit_file: Path) -> None:
        """Initialize the audit log.

        Args:
            audit_file: Path to the audit log JSONL file
        """
        self.audit_file = audit_file

    def _ensure_directory(self) -> None:
        """Create parent directory if it doesn't exist."""
        self.audit_file.parent.mkdir(parents=True, exist_ok=True)

    def _compute_data_hash(self, data: dict[str, Any]) -> str:
        """Compute SHA-256 hash of data dictionary."""
        data_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(data_str.encode()).hexdigest()

    def _compute_entry_hash(
        self,
        sequence: int,
        timestamp: datetime,
        action: str,
        data_hash: str,
        previous_hash: str,
    ) -> str:
        """Compute SHA-256 hash of entry fields including previous hash."""
        content = f"{sequence}|{timestamp.isoformat()}|{action}|{data_hash}|{previous_hash}"
        return hashlib.sha256(content.encode()).hexdigest()

    def _get_last_entry(self) -> AuditEntry | None:
        """Get the last entry in the log, or None if empty."""
        if not self.audit_file.exists():
            return None

        last_line = None
        try:
            with open(self.audit_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        last_line = line
        except OSError as e:
            logger.warning("Error reading audit file: %s", e)
            return None

        if last_line is None:
            return None

        try:
            return AuditEntry.from_json(last_line)
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning("Error parsing last audit entry: %s", e)
            return None

    def append(self, action: str, data: dict[str, Any]) -> AuditEntry:
        """Append an audit entry with hash chain linking.

        Args:
            action: The action being logged (e.g., record_added, config_changed)
            data: Dictionary of data associated with the action

        Returns:
            The created AuditEntry
        """
        self._ensure_directory()

        last_entry = self._get_last_entry()
        if last_entry is None:
            sequence = 1
            previous_hash = self.GENESIS_HASH
        else:
            sequence = last_entry.sequence + 1
            previous_hash = last_entry.entry_hash

        timestamp = datetime.now(timezone.utc)
        data_hash = self._compute_data_hash(data)
        entry_hash = self._compute_entry_hash(
            sequence, timestamp, action, data_hash, previous_hash
        )

        entry = AuditEntry(
            sequence=sequence,
            timestamp=timestamp,
            action=action,
            data_hash=data_hash,
            previous_hash=previous_hash,
            entry_hash=entry_hash,
        )

        with open(self.audit_file, "a", encoding="utf-8") as f:
            f.write(entry.to_json() + "\n")

        return entry

    def _read_all_entries(self) -> list[AuditEntry]:
        """Read all entries from the audit file."""
        if not self.audit_file.exists():
            return []

        entries: list[AuditEntry] = []
        try:
            with open(self.audit_file, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entries.append(AuditEntry.from_json(line))
                    except (json.JSONDecodeError, KeyError) as e:
                        logger.debug(
                            "Skipping malformed entry at line %d: %s", line_num, e
                        )
        except OSError as e:
            logger.warning("Error reading audit file: %s", e)

        return entries

    def verify(self) -> tuple[bool, str | None]:
        """Verify the entire hash chain for tampering.

        Returns:
            Tuple of (is_valid, error_message). If valid, error_message is None.
        """
        entries = self._read_all_entries()

        if not entries:
            return True, None

        # Verify first entry references genesis
        if entries[0].previous_hash != self.GENESIS_HASH:
            return False, "First entry does not reference genesis hash"

        expected_previous_hash = self.GENESIS_HASH

        for i, entry in enumerate(entries):
            # Verify sequence number
            if entry.sequence != i + 1:
                return False, f"Sequence gap at entry {i + 1}: expected {i + 1}, got {entry.sequence}"

            # Verify chain link
            if entry.previous_hash != expected_previous_hash:
                return False, f"Chain broken at entry {entry.sequence}: previous_hash mismatch"

            # Recompute and verify entry hash
            computed_hash = self._compute_entry_hash(
                entry.sequence,
                entry.timestamp,
                entry.action,
                entry.data_hash,
                entry.previous_hash,
            )
            if entry.entry_hash != computed_hash:
                return False, f"Hash mismatch at entry {entry.sequence}: entry has been tampered"

            expected_previous_hash = entry.entry_hash

        return True, None

    def get_entries(self, limit: int = 100) -> list[AuditEntry]:
        """Get audit entries, most recent first.

        Args:
            limit: Maximum number of entries to return (default 100)

        Returns:
            List of AuditEntry objects, sorted by sequence descending
        """
        entries = self._read_all_entries()
        entries.sort(key=lambda e: e.sequence, reverse=True)
        return entries[:limit]
