"""Aggregate data structures for compacted telemetry records.

Weekly aggregate summaries produced by the compaction engine.
Raw JSONL records older than the retention window get compacted
into these structures to reduce storage while preserving statistical value.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from bpsai_pair.telemetry.schema import TokenUsage


@dataclass
class TaskTypeAggregate:
    """Aggregate statistics for a single task type within a period."""

    task_type: str
    record_count: int
    total_input: int
    total_output: int
    total_cache_read: int
    total_cache_write: int
    total_duration_seconds: float
    success_count: int
    fail_count: int
    avg_tokens: float
    std_dev_tokens: float
    p80_tokens: float
    avg_duration_seconds: float

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "task_type": self.task_type,
            "record_count": self.record_count,
            "total_input": self.total_input,
            "total_output": self.total_output,
            "total_cache_read": self.total_cache_read,
            "total_cache_write": self.total_cache_write,
            "total_duration_seconds": self.total_duration_seconds,
            "success_count": self.success_count,
            "fail_count": self.fail_count,
            "avg_tokens": self.avg_tokens,
            "std_dev_tokens": self.std_dev_tokens,
            "p80_tokens": self.p80_tokens,
            "avg_duration_seconds": self.avg_duration_seconds,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaskTypeAggregate:
        """Deserialize from dictionary."""
        return cls(
            task_type=data["task_type"],
            record_count=data["record_count"],
            total_input=data["total_input"],
            total_output=data["total_output"],
            total_cache_read=data["total_cache_read"],
            total_cache_write=data["total_cache_write"],
            total_duration_seconds=data["total_duration_seconds"],
            success_count=data["success_count"],
            fail_count=data["fail_count"],
            avg_tokens=data["avg_tokens"],
            std_dev_tokens=data["std_dev_tokens"],
            p80_tokens=data["p80_tokens"],
            avg_duration_seconds=data["avg_duration_seconds"],
        )


@dataclass
class ModelAggregate:
    """Aggregate statistics for a single model within a period."""

    model: str
    record_count: int
    total_input: int
    total_output: int
    total_cache_read: int
    total_cache_write: int
    total_duration_seconds: float

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "model": self.model,
            "record_count": self.record_count,
            "total_input": self.total_input,
            "total_output": self.total_output,
            "total_cache_read": self.total_cache_read,
            "total_cache_write": self.total_cache_write,
            "total_duration_seconds": self.total_duration_seconds,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ModelAggregate:
        """Deserialize from dictionary."""
        return cls(
            model=data["model"],
            record_count=data["record_count"],
            total_input=data["total_input"],
            total_output=data["total_output"],
            total_cache_read=data["total_cache_read"],
            total_cache_write=data["total_cache_write"],
            total_duration_seconds=data["total_duration_seconds"],
        )


@dataclass
class AggregateRecord:
    """A compacted aggregate covering one ISO week of telemetry data."""

    period_start: str  # ISO 8601 date (Monday of week)
    period_end: str  # ISO 8601 date (Sunday of week)
    record_count: int
    task_type_stats: dict[str, TaskTypeAggregate]
    model_stats: dict[str, ModelAggregate]
    total_tokens: TokenUsage
    total_duration_seconds: float
    success_count: int
    fail_count: int
    estimate_count: int  # is_estimate=True records
    compacted_at: str  # ISO 8601 timestamp
    source_version: str  # CLI version

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "period_start": self.period_start,
            "period_end": self.period_end,
            "record_count": self.record_count,
            "task_type_stats": {
                k: v.to_dict() for k, v in self.task_type_stats.items()
            },
            "model_stats": {
                k: v.to_dict() for k, v in self.model_stats.items()
            },
            "total_tokens": self.total_tokens.to_dict(),
            "total_duration_seconds": self.total_duration_seconds,
            "success_count": self.success_count,
            "fail_count": self.fail_count,
            "estimate_count": self.estimate_count,
            "compacted_at": self.compacted_at,
            "source_version": self.source_version,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AggregateRecord:
        """Deserialize from dictionary."""
        return cls(
            period_start=data["period_start"],
            period_end=data["period_end"],
            record_count=data["record_count"],
            task_type_stats={
                k: TaskTypeAggregate.from_dict(v)
                for k, v in data["task_type_stats"].items()
            },
            model_stats={
                k: ModelAggregate.from_dict(v)
                for k, v in data["model_stats"].items()
            },
            total_tokens=TokenUsage.from_dict(data["total_tokens"]),
            total_duration_seconds=data["total_duration_seconds"],
            success_count=data["success_count"],
            fail_count=data["fail_count"],
            estimate_count=data["estimate_count"],
            compacted_at=data["compacted_at"],
            source_version=data["source_version"],
        )
