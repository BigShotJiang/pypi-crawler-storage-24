"""JSONL-to-SQLite migration engine for PairCoder telemetry.

Migrates existing session JSON files and telemetry JSONL records
into the SQLite store. Idempotent and preserves source files.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from bpsai_pair.telemetry.sqlite_schema import ensure_schema

logger = logging.getLogger(__name__)


def run_migration(db_path: str | Path, telemetry_dir: str | Path) -> None:
    """Orchestrate full migration from JSONL/JSON to SQLite."""
    db_path = Path(db_path)
    telemetry_dir = Path(telemetry_dir)
    conn = ensure_schema(db_path)
    try:
        migrate_sessions(conn, telemetry_dir)
        migrate_telemetry(conn, telemetry_dir)
        migrate_aggregates(conn, telemetry_dir)
        conn.commit()
        logger.info("Migration complete: %s", db_path)
    finally:
        conn.close()


def migrate_sessions(conn, telemetry_dir: Path) -> int:
    """Migrate session JSON files to sessions table. Returns count."""
    sessions_dir = telemetry_dir / "sessions"
    if not sessions_dir.exists():
        return 0
    count = 0
    for f in sessions_dir.glob("session_*.json"):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            _insert_session(conn, data)
            count += 1
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning("Skipping malformed session %s: %s", f.name, e)
    logger.info("Migrated %d sessions", count)
    return count


def migrate_telemetry(conn, telemetry_dir: Path) -> int:
    """Migrate telemetry.jsonl to telemetry_records table. Returns count."""
    jsonl_path = telemetry_dir / "telemetry.jsonl"
    if not jsonl_path.exists():
        return 0
    count = 0
    with open(jsonl_path, encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                _insert_telemetry_record(conn, data)
                count += 1
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning("Skipping line %d: %s", line_num, e)
    logger.info("Migrated %d telemetry records", count)
    return count


def migrate_aggregates(conn, telemetry_dir: Path) -> int:
    """Migrate telemetry_aggregates.jsonl to calibration_data. Returns count."""
    jsonl_path = telemetry_dir / "telemetry_aggregates.jsonl"
    if not jsonl_path.exists():
        return 0
    count = 0
    with open(jsonl_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                _insert_calibration(conn, data)
                count += 1
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning("Skipping aggregate line: %s", e)
    logger.info("Migrated %d calibration records", count)
    return count


def _insert_session(conn, data: dict) -> None:
    """Insert a session record, skip if already exists."""
    conn.execute(
        "INSERT OR IGNORE INTO sessions "
        "(session_id, started_at, ended_at, duration_s, outcome, "
        "agent_role, tasks_touched, tests_run, tests_passed, "
        "errors, enforcement_overrides) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            data["session_id"],
            data["started_at"],
            data["ended_at"],
            data.get("duration_s", 0),
            data.get("outcome", "success"),
            data.get("agent_role", "driver"),
            json.dumps(data.get("tasks_touched", [])),
            data.get("tests_run", 0),
            data.get("tests_passed", 0),
            json.dumps(data.get("errors", [])),
            json.dumps(data.get("enforcement_overrides", [])),
        ),
    )


def _insert_telemetry_record(conn, data: dict) -> None:
    """Insert a telemetry record. Uses task_id+timestamp for dedup."""
    tokens = data.get("tokens", {})
    conn.execute(
        "INSERT OR IGNORE INTO telemetry_records "
        "(task_id, task_type, repo, model, tokens_input, tokens_output, "
        "tokens_cache_read, tokens_cache_write, duration_seconds, "
        "human_interventions, compactions, outcome, recorded_at, "
        "session_id, sprint, complexity) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            data["task_id"],
            data["task_type"],
            data["repo"],
            data["model"],
            tokens.get("input", 0),
            tokens.get("output", 0),
            tokens.get("cache_read", 0),
            tokens.get("cache_write", 0),
            data.get("duration_seconds", 0),
            data.get("human_interventions", 0),
            data.get("compactions", 0),
            data.get("outcome", "success"),
            data.get("timestamp", ""),
            data.get("session_id"),
            data.get("sprint"),
            data.get("complexity"),
        ),
    )


def _insert_calibration(conn, data: dict) -> None:
    """Insert a calibration/aggregate record."""
    conn.execute(
        "INSERT OR IGNORE INTO calibration_data "
        "(task_type, model, success_rate, avg_tokens, avg_duration, "
        "sample_count, updated_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (
            data.get("task_type", "unknown"),
            data.get("model"),
            data.get("success_rate"),
            data.get("avg_tokens"),
            data.get("avg_duration_seconds", data.get("avg_duration")),
            data.get("record_count", data.get("sample_count", 0)),
            data.get("updated_at", data.get("period_start", "")),
        ),
    )
