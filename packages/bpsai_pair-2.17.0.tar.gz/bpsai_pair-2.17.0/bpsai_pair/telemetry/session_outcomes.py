"""Session outcome recording for structured session telemetry.

Records structured session outcomes to local JSON storage.
Each session produces a single JSON file in .paircoder/telemetry/sessions/.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class SessionOutcome:
    """Structured record of a single session's outcome."""

    session_id: str
    started_at: str  # ISO datetime
    ended_at: str  # ISO datetime
    duration_s: int = 0
    tasks_touched: list[str] = field(default_factory=list)
    tests_run: int = 0
    tests_passed: int = 0
    errors: list[str] = field(default_factory=list)
    enforcement_overrides: list[str] = field(default_factory=list)
    outcome: str = "success"  # success | partial | abandoned
    agent_role: str = "driver"


class SessionOutcomeRecorder:
    """Records and queries session outcomes on disk."""

    def __init__(self, project_root: Path) -> None:
        self._sessions_dir = (
            Path(project_root) / ".paircoder" / "telemetry" / "sessions"
        )

    def record(self, outcome: SessionOutcome) -> Path:
        """Write session outcome to JSON file. Returns written path."""
        self._sessions_dir.mkdir(parents=True, exist_ok=True)
        safe_id = re.sub(r"[^\w\-]", "_", outcome.session_id)
        filename = f"session_{safe_id}_{outcome.ended_at[:10]}.json"
        path = self._sessions_dir / filename
        with open(path, "w", encoding="utf-8") as f:
            json.dump(asdict(outcome), f, indent=2)
        logger.debug("Recorded session outcome: %s", path)
        return path

    def list_recent(self, limit: int = 10) -> list[SessionOutcome]:
        """List recent session outcomes, newest first by ended_at."""
        if not self._sessions_dir.exists():
            return []
        results: list[SessionOutcome] = []
        for f in self._sessions_dir.glob("session_*.json"):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                results.append(SessionOutcome(**data))
            except (json.JSONDecodeError, TypeError):
                logger.warning("Skipping corrupt session file: %s", f)
                continue
        results.sort(key=lambda o: o.ended_at, reverse=True)
        return results[:limit]

    def recover_partial(
        self, session_id: str, tasks_touched: list[str]
    ) -> SessionOutcome:
        """Create a partial outcome for a session that didn't finalize."""
        now = datetime.now(timezone.utc).isoformat()
        return SessionOutcome(
            session_id=session_id,
            started_at="unknown",
            ended_at=now,
            tasks_touched=tasks_touched,
            outcome="abandoned",
        )
