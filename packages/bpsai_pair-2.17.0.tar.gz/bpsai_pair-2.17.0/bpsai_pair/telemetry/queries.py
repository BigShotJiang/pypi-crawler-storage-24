"""Analytics query module for telemetry data.

Replaces the read paths of MetricsCollector (cost), VelocityTracker
(velocity), and AccuracyAnalyzer (accuracy) with a single module
that queries TelemetryStore as the source of truth.

Blends raw (recent) records with aggregate (historical) data
produced by the compaction engine.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING

from bpsai_pair.telemetry.query_helpers import (
    compute_cache_stats,
    estimate_aggregate_cost,
    sum_aggregate_tokens,
)
from bpsai_pair.telemetry.schema import TelemetryRecord
from bpsai_pair.telemetry.store import TelemetryStore

if TYPE_CHECKING:
    from bpsai_pair.telemetry.aggregates import AggregateRecord

DEFAULT_PRICING = {
    # Opus 4.5/4.6: $5/$25 per MTok
    "claude-opus-4-6": {"input_per_1m": 5.00, "output_per_1m": 25.00},
    "claude-opus-4-5-20251101": {"input_per_1m": 5.00, "output_per_1m": 25.00},
    # Opus 4.0/4.1: $15/$75 per MTok
    "claude-opus-4-1-20250414": {"input_per_1m": 15.00, "output_per_1m": 75.00},
    "claude-opus-4-20250514": {"input_per_1m": 15.00, "output_per_1m": 75.00},
    # Sonnet 4.5/4.6: $3/$15 per MTok
    "claude-sonnet-4-6": {"input_per_1m": 3.00, "output_per_1m": 15.00},
    "claude-sonnet-4-5-20250929": {"input_per_1m": 3.00, "output_per_1m": 15.00},
    "claude-sonnet-4-20250514": {"input_per_1m": 3.00, "output_per_1m": 15.00},
    # Haiku 4.5: $1/$5 per MTok
    "claude-haiku-4-5-20251001": {"input_per_1m": 1.00, "output_per_1m": 5.00},
    # Default assumes Sonnet-class pricing
    "default": {"input_per_1m": 3.00, "output_per_1m": 15.00},
}


class TelemetryQueries:
    """Analytics queries over TelemetryStore data."""

    def __init__(self, store: TelemetryStore, pricing: dict | None = None) -> None:
        self._store = store
        self._pricing = pricing or DEFAULT_PRICING

    def _all_records(self, limit: int = 10000) -> list[TelemetryRecord]:
        return self._store.query(limit=limit)

    def _load_aggregates(self) -> list[AggregateRecord]:
        return self._store.load_aggregates()

    # --- Velocity ---

    def get_velocity_stats(self, current_sprint: str, weeks: int = 4) -> dict:
        """Get velocity statistics for the current sprint."""
        records = self._all_records()
        sprint_points = sum(
            r.complexity or 0 for r in records if r.sprint == current_sprint
        )
        sprints = self._sprint_breakdown(records)
        sprint_values = list(sprints.values())
        avg_sprint = (sum(sprint_values) / len(sprint_values)) if sprint_values else 0.0
        weekly = self._weekly_breakdown(records, weeks)
        week_values = [w["points"] for w in weekly]
        avg_weekly = (sum(week_values) / len(week_values)) if week_values else 0.0

        aggregates = self._load_aggregates()
        agg_count = sum(a.record_count for a in aggregates)

        return {
            "points_this_sprint": sprint_points,
            "avg_sprint_velocity": round(avg_sprint, 1),
            "avg_weekly_velocity": round(avg_weekly, 1),
            "sprints_tracked": len(sprints),
            "aggregate_periods": len(aggregates),
            "total_tasks_all_time": len(records) + agg_count,
        }

    @staticmethod
    def _sprint_breakdown(records: list[TelemetryRecord]) -> dict[str, int]:
        """Group complexity points by sprint from pre-loaded records."""
        breakdown: dict[str, int] = defaultdict(int)
        for r in records:
            if r.sprint is not None:
                breakdown[r.sprint] += r.complexity or 0
        return dict(breakdown)

    def get_sprint_breakdown(self) -> dict[str, int]:
        """Get complexity points grouped by sprint."""
        return self._sprint_breakdown(self._all_records())

    @staticmethod
    def _weekly_breakdown(records: list[TelemetryRecord], weeks: int) -> list[dict]:
        """Group complexity points by week from pre-loaded records."""
        now = datetime.now(timezone.utc)
        result = []
        for i in range(weeks):
            week_start = now - timedelta(days=now.weekday() + 7 * i)
            week_start = week_start.replace(hour=0, minute=0, second=0, microsecond=0)
            week_end = week_start + timedelta(days=7)
            points = sum(
                r.complexity or 0
                for r in records
                if week_start <= r.timestamp < week_end
            )
            result.append({
                "week_start": week_start.strftime("%Y-%m-%d"),
                "points": points,
            })
        return result

    def get_weekly_breakdown(self, weeks: int = 4) -> list[dict]:
        """Get complexity points grouped by week (most recent first)."""
        return self._weekly_breakdown(self._all_records(), weeks)

    # --- Accuracy ---

    def get_accuracy_stats(self) -> dict:
        """Get estimation accuracy statistics."""
        records = self._all_records()
        pairs = [
            (r.estimated_hours, r.actual_hours)
            for r in records
            if r.estimated_hours is not None and r.actual_hours is not None
        ]
        if not pairs:
            return {"total_tasks": 0, "avg_accuracy": 0.0, "bias": "neutral"}
        accuracies = []
        total_variance = 0.0
        for est, act in pairs:
            variance = ((act - est) / est * 100) if est > 0 else 0.0
            accuracy = max(0.0, 100.0 - abs(variance))
            accuracies.append(accuracy)
            total_variance += variance
        avg_accuracy = sum(accuracies) / len(accuracies)
        avg_variance = total_variance / len(pairs)
        if avg_variance > 5:
            bias = "optimistic"
        elif avg_variance < -5:
            bias = "pessimistic"
        else:
            bias = "neutral"
        return {
            "total_tasks": len(pairs),
            "avg_accuracy": round(avg_accuracy, 1),
            "bias": bias,
            "avg_variance_percent": round(avg_variance, 1),
        }

    # --- Cost ---

    def _get_model_pricing(self, model: str) -> dict:
        return self._pricing.get(model, self._pricing.get("default", {}))

    def _record_cost(self, r: TelemetryRecord) -> float:
        pricing = self._get_model_pricing(r.model)
        input_cost = (r.tokens.input / 1_000_000) * pricing.get("input_per_1m", 3.0)
        output_cost = (r.tokens.output / 1_000_000) * pricing.get("output_per_1m", 15.0)
        return round(input_cost + output_cost, 6)

    def get_cost_summary(self) -> dict:
        """Get total cost summary across raw records + aggregates."""
        records = self._all_records()
        aggregates = self._load_aggregates()

        raw_input = sum(r.tokens.input for r in records)
        raw_output = sum(r.tokens.output for r in records)
        raw_cost = sum(self._record_cost(r) for r in records)
        raw_count = len(records)

        agg_input, agg_output, agg_count = sum_aggregate_tokens(aggregates)
        default_pricing = self._pricing.get("default", {})
        agg_cost = estimate_aggregate_cost(agg_input, agg_output, default_pricing)

        total_input = raw_input + agg_input
        total_output = raw_output + agg_output
        total_cost = raw_cost + agg_cost
        total_count = raw_count + agg_count

        if total_count == 0:
            return {
                "total_cost": 0.0,
                "total_input_tokens": 0,
                "total_output_tokens": 0,
                "task_count": 0,
            }
        return {
            "total_cost": round(total_cost, 2),
            "total_input_tokens": total_input,
            "total_output_tokens": total_output,
            "task_count": total_count,
        }

    def get_cost_breakdown(self, by: str = "model") -> dict:
        """Get cost grouped by model or task_type."""
        records = self._all_records()
        groups: dict[str, list[TelemetryRecord]] = defaultdict(list)
        for r in records:
            key = r.model if by == "model" else r.task_type
            groups[key].append(r)
        return {
            key: {
                "cost": round(sum(self._record_cost(r) for r in recs), 2),
                "tasks": len(recs),
                "input_tokens": sum(r.tokens.input for r in recs),
                "output_tokens": sum(r.tokens.output for r in recs),
            }
            for key, recs in groups.items()
        }

    # --- Cache ---

    def get_cache_stats(self) -> dict:
        """Get cache effectiveness statistics from raw + aggregates."""
        records = self._all_records()
        aggregates = self._load_aggregates()
        return compute_cache_stats(records, aggregates)

    # --- Task-level ---

    def get_task_metrics(self, task_id: str) -> dict | None:
        """Get metrics for a single task."""
        records = self._store.query(task_id=task_id, limit=1)
        if not records:
            return None
        r = records[0]
        return {
            "task_id": r.task_id,
            "task_type": r.task_type,
            "model": r.model,
            "input_tokens": r.tokens.input,
            "output_tokens": r.tokens.output,
            "cost": self._record_cost(r),
            "duration_seconds": r.duration_seconds,
            "sprint": r.sprint,
            "complexity": r.complexity,
            "outcome": r.outcome.value,
        }
