"""Low-level helpers for archive parsing and session data extraction.

Separated from recovery.py to keep both modules under architecture limits.
"""

from __future__ import annotations

import json
import logging
import tarfile
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Type alias for a parsed session from an archive
SessionData = dict[str, Any]
# project_hash -> list of SessionData
ProjectSessions = dict[str, list[SessionData]]


def parse_archive(archive_path: Path) -> ProjectSessions:
    """Extract session JSONL files from a .tar.gz archive.

    Args:
        archive_path: Path to the archive file.

    Returns:
        Dict mapping project hash to list of session dicts, each with
        ``session_file`` (relative path) and ``entries`` (parsed JSON lines).
    """
    result: ProjectSessions = {}
    try:
        with tarfile.open(archive_path, "r:gz") as tar:
            for member in tar.getmembers():
                if not member.isfile():
                    continue
                if not member.name.endswith(".jsonl"):
                    continue
                if ".claude/projects/" not in member.name:
                    continue

                project_hash = extract_project_hash(member.name)
                if project_hash is None:
                    continue

                entries = read_member_jsonl(tar, member)
                session: SessionData = {
                    "session_file": member.name,
                    "entries": entries,
                }
                result.setdefault(project_hash, []).append(session)
    except (tarfile.TarError, OSError) as exc:
        logger.warning("Failed to read archive %s: %s", archive_path, exc)

    return result


def extract_project_hash(member_name: str) -> str | None:
    """Extract the project hash from an archive member path.

    Expected format: ``.claude/projects/<project-hash>/filename.jsonl``
    """
    parts = member_name.split("/")
    try:
        idx = parts.index("projects")
        if idx + 1 < len(parts):
            return parts[idx + 1]
    except ValueError:
        pass
    return None


def identify_project(project_hash: str, claude_md_content: str | None) -> str:
    """Map a project hash to a human-readable project name.

    Parses the first ``# Title`` heading from CLAUDE.md content. Falls back
    to the raw project hash if no content or heading is found.

    Args:
        project_hash: The hash directory name from the archive.
        claude_md_content: Content of the project's CLAUDE.md, or None.

    Returns:
        A human-readable project name.
    """
    if claude_md_content:
        for line in claude_md_content.splitlines():
            stripped = line.strip()
            if stripped.startswith("# ") and len(stripped) > 2:
                return stripped[2:].strip()
    return project_hash


def read_member_jsonl(
    tar: tarfile.TarFile, member: tarfile.TarInfo
) -> list[dict[str, Any]]:
    """Read and parse JSONL content from a tar member."""
    entries: list[dict[str, Any]] = []
    fobj = tar.extractfile(member)
    if fobj is None:
        return entries
    try:
        for line in fobj:
            line_str = line.decode("utf-8", errors="replace").strip()
            if not line_str:
                continue
            try:
                entries.append(json.loads(line_str))
            except json.JSONDecodeError:
                continue
    finally:
        fobj.close()
    return entries


def week_key_from_datetime(dt: datetime) -> str:
    """Return ISO week string like '2026-W03' from a datetime."""
    iso = dt.isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


def extract_cache_fields(entries: list[dict[str, Any]]) -> tuple[int, int]:
    """Sum cache_creation and cache_read tokens from raw session entries."""
    cache_creation = 0
    cache_read = 0
    for entry in entries:
        if entry.get("type") != "assistant":
            continue
        usage = entry.get("message", {}).get("usage", {})
        cache_creation += usage.get("cache_creation_input_tokens", 0)
        cache_read += usage.get("cache_read_input_tokens", 0)
    return cache_creation, cache_read


def extract_session_id(entries: list[dict[str, Any]]) -> str | None:
    """Extract the session ID from session entries."""
    for entry in entries:
        sid = entry.get("sessionId")
        if sid:
            return str(sid)
    return None
