"""Migration for cumulative telemetry records to per-task deltas.

The telemetry collector had a bug where it recorded cumulative session
totals instead of per-task deltas. This module retroactively fixes
existing records by computing deltas from consecutive cumulative values.
"""

from __future__ import annotations

import json
import logging
import shutil
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _is_session_boundary(prev: dict[str, Any], curr: dict[str, Any]) -> bool:
    """Detect if two consecutive records are from different sessions."""
    if prev.get("model") != curr.get("model"):
        return True

    prev_input = prev.get("tokens", {}).get("input", 0)
    curr_input = curr.get("tokens", {}).get("input", 0)
    if curr_input < prev_input:
        return True

    prev_duration = prev.get("duration_seconds", 0)
    curr_duration = curr.get("duration_seconds", 0)
    if curr_duration < prev_duration:
        return True

    return False


def _compute_delta(prev: dict[str, Any], curr: dict[str, Any]) -> dict[str, Any]:
    """Compute per-task delta from two consecutive cumulative records."""
    result = dict(curr)
    result["tokens"] = dict(curr["tokens"])

    result["tokens"]["input"] = max(
        0, curr["tokens"]["input"] - prev["tokens"]["input"]
    )
    result["tokens"]["output"] = max(
        0, curr["tokens"]["output"] - prev["tokens"]["output"]
    )
    result["duration_seconds"] = max(
        0, curr["duration_seconds"] - prev["duration_seconds"]
    )
    result["human_interventions"] = max(
        0, curr["human_interventions"] - prev["human_interventions"]
    )

    return result


def migrate_cumulative_records(
    records: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Convert cumulative telemetry records to per-task deltas.

    Detects session boundaries (model change or value decrease) and
    computes deltas within each session group. First record in each
    session is kept as-is.
    """
    if not records:
        return []

    migrated = [dict(records[0])]
    migrated[0]["tokens"] = dict(records[0]["tokens"])

    for i in range(1, len(records)):
        prev = records[i - 1]
        curr = records[i]

        if _is_session_boundary(prev, curr):
            migrated.append(dict(curr))
            migrated[-1]["tokens"] = dict(curr["tokens"])
        else:
            migrated.append(_compute_delta(prev, curr))

    return migrated


def migrate_telemetry_file(telemetry_path: Path) -> dict[str, Any]:
    """Migrate a telemetry.jsonl file from cumulative to delta records.

    Creates a backup (.cumulative_bak) and rewrites the file with
    corrected delta values.

    Returns dict with migration stats.
    """
    content = telemetry_path.read_text(encoding="utf-8")
    records = []
    for line in content.strip().split("\n"):
        if line.strip():
            records.append(json.loads(line))

    backup_path = telemetry_path.with_suffix(".jsonl.cumulative_bak")
    shutil.copy2(telemetry_path, backup_path)

    migrated = migrate_cumulative_records(records)

    with open(telemetry_path, "w", encoding="utf-8") as f:
        for record in migrated:
            f.write(json.dumps(record) + "\n")

    return {
        "records_migrated": len(migrated),
        "backup_path": str(backup_path),
    }
