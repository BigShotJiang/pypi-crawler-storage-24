"""Hook event schemas for Claude Code telemetry integration.

Defines the data contracts for SubagentStart/Stop hook events
and telemetry hook configuration. Schema only — hook registration
is Sprint 34 scope.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class HookType(Enum):
    """Claude Code hook event types."""

    PRE_TOOL_USE = "pre_tool_use"
    POST_TOOL_USE = "post_tool_use"
    SUBAGENT_START = "subagent_start"
    SUBAGENT_STOP = "subagent_stop"


class CollectionLevel(Enum):
    """Telemetry collection granularity levels."""

    MINIMAL = "minimal"
    STANDARD = "standard"
    FULL = "full"


@dataclass
class HookEventSchema:
    """Schema for SubagentStart/Stop hook events.

    This is the contract for Sprint 34's telemetry integration.
    """

    agent_id: str
    agent_type: str
    team_name: str
    transcript_path: str
    timestamp: datetime

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "team_name": self.team_name,
            "transcript_path": self.transcript_path,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HookEventSchema:
        """Deserialize from dictionary."""
        ts = data["timestamp"]
        if isinstance(ts, str):
            ts = datetime.fromisoformat(ts)
        return cls(
            agent_id=data["agent_id"],
            agent_type=data["agent_type"],
            team_name=data["team_name"],
            transcript_path=data["transcript_path"],
            timestamp=ts,
        )


@dataclass
class TelemetryHookConfig:
    """Configuration for a telemetry hook.

    Defines which hook events to capture and at what detail level.
    """

    hook_type: HookType
    enabled: bool = True
    collection_level: CollectionLevel = CollectionLevel.STANDARD

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "hook_type": self.hook_type.value,
            "enabled": self.enabled,
            "collection_level": self.collection_level.value,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TelemetryHookConfig:
        """Deserialize from dictionary."""
        return cls(
            hook_type=HookType(data["hook_type"]),
            enabled=data.get("enabled", True),
            collection_level=CollectionLevel(
                data.get("collection_level", "standard")
            ),
        )
