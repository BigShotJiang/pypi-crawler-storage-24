"""TaskStateIndex — SQLite-backed task state transition logging.

Tracks every task state change (pending → in_progress → done) with
timestamp and metadata. Enables queries like "tasks started but not
completed" and "estimation accuracy by task type."
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS task_state_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    plan_id TEXT,
    old_state TEXT NOT NULL,
    new_state TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    metadata_json TEXT DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_task_state_task_id
    ON task_state_log(task_id);
CREATE INDEX IF NOT EXISTS idx_task_state_new_state
    ON task_state_log(new_state);
CREATE INDEX IF NOT EXISTS idx_task_state_plan_id
    ON task_state_log(plan_id);
"""

SCHEMA_VERSION = 2

# Fixed lookup table — only these columns can appear in WHERE clauses.
# Prevents SQL injection even if callers are extended in the future.
_FILTER_COLUMNS = {
    "task_id": "task_id = ?",
    "plan_id": "plan_id = ?",
    "new_state": "new_state = ?",
}


def _build_filters(
    task_id: str | None,
    plan_id: str | None,
    new_state: str | None,
) -> tuple[list[str], list[Any]]:
    """Build parameterized WHERE clauses from fixed column lookup."""
    filters = {"task_id": task_id, "plan_id": plan_id, "new_state": new_state}
    clauses: list[str] = []
    params: list[Any] = []
    for key, value in filters.items():
        if value is not None:
            clauses.append(_FILTER_COLUMNS[key])
            params.append(value)
    return clauses, params


class TaskStateIndex:
    """SQLite-backed task state transition index."""

    def __init__(self, db_path: str | Path, read_only: bool = False) -> None:
        self._db_path = Path(db_path)
        self._read_only = read_only
        if not read_only:
            self._ensure_schema()

    def _ensure_schema(self) -> None:
        """Create task_state_log table and record schema version."""
        from bpsai_pair.telemetry.sqlite_schema import ensure_schema

        conn = ensure_schema(self._db_path)
        try:
            conn.executescript(_TABLE_SQL)
            self._record_version(conn)
            conn.commit()
        finally:
            conn.close()

    def _record_version(self, conn: sqlite3.Connection) -> None:
        """Record schema version 2 if not present."""
        existing = conn.execute(
            "SELECT version FROM schema_version WHERE version = ?",
            (SCHEMA_VERSION,),
        ).fetchone()
        if existing:
            return
        conn.execute(
            "INSERT INTO schema_version (version, applied_at, description) "
            "VALUES (?, ?, ?)",
            (
                SCHEMA_VERSION,
                datetime.now(timezone.utc).isoformat(),
                "Add task_state_log table for transition tracking",
            ),
        )

    def log_transition(
        self,
        task_id: str,
        old_state: str,
        new_state: str,
        plan_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Record a task state transition."""
        from bpsai_pair.telemetry.sqlite_schema import get_connection

        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        if not self._db_path.exists():
            self._ensure_schema()

        conn = get_connection(self._db_path)
        try:
            conn.execute(
                "INSERT INTO task_state_log "
                "(task_id, plan_id, old_state, new_state, timestamp, metadata_json) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    task_id,
                    plan_id,
                    old_state,
                    new_state,
                    datetime.now(timezone.utc).isoformat(),
                    json.dumps(metadata or {}),
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def query_transitions(
        self,
        task_id: str | None = None,
        plan_id: str | None = None,
        new_state: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Query state transitions with optional filters."""
        if not self._db_path.exists():
            return []

        from bpsai_pair.telemetry.sqlite_schema import get_connection

        conn = get_connection(self._db_path)
        try:
            clauses, params = _build_filters(task_id, plan_id, new_state)
            safe_limit = max(1, min(limit, 10000))
            params.append(safe_limit)

            sql = "SELECT * FROM task_state_log"
            if clauses:
                sql += " WHERE " + " AND ".join(clauses)
            sql += " ORDER BY timestamp DESC LIMIT ?"

            rows = conn.execute(sql, params).fetchall()

            return [self._row_to_dict(r) for r in rows]
        finally:
            conn.close()

    def query_incomplete_tasks(self) -> list[dict[str, Any]]:
        """Find tasks whose latest state is in_progress (not done)."""
        if not self._db_path.exists():
            return []

        from bpsai_pair.telemetry.sqlite_schema import get_connection

        conn = get_connection(self._db_path)
        try:
            rows = conn.execute(
                "SELECT task_id FROM ("
                "  SELECT task_id, new_state,"
                "    ROW_NUMBER() OVER ("
                "      PARTITION BY task_id ORDER BY timestamp DESC, id DESC"
                "    ) AS rn"
                "  FROM task_state_log"
                ") sub "
                "WHERE rn = 1 AND new_state = 'in_progress' "
                "ORDER BY task_id "
                "LIMIT 500"
            ).fetchall()

            return [{"task_id": r["task_id"]} for r in rows]
        finally:
            conn.close()

    def _row_to_dict(self, row: sqlite3.Row) -> dict[str, Any]:
        """Convert a SQLite row to a dict."""
        return {
            "id": row["id"],
            "task_id": row["task_id"],
            "plan_id": row["plan_id"],
            "old_state": row["old_state"],
            "new_state": row["new_state"],
            "timestamp": row["timestamp"],
            "metadata": json.loads(row["metadata_json"]),
        }
