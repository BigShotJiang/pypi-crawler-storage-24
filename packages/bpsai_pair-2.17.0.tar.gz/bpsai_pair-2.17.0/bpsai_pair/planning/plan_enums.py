"""Planning enums and small data types.

This module provides the enum types and simple data classes
used across the planning system.
"""

import re
from dataclasses import dataclass
from enum import Enum
from typing import List

# Regex to parse AC items from markdown: - [ ] or - [x]
AC_ITEM_PATTERN = re.compile(r'^[-*]\s+\[([ xX])\]\s+(.+)$', re.MULTILINE)


@dataclass
class AcceptanceCriteriaItem:
    """A single acceptance criteria item."""
    text: str
    checked: bool = False

    def to_markdown(self) -> str:
        """Convert to markdown checkbox format."""
        check = "x" if self.checked else " "
        return f"- [{check}] {self.text}"


class TaskStatus(str, Enum):
    """Status of a task."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    DONE = "done"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"


class PlanStatus(str, Enum):
    """Status of a plan."""
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    ARCHIVED = "archived"


class PlanType(str, Enum):
    """Type of plan."""
    FEATURE = "feature"
    BUGFIX = "bugfix"
    REFACTOR = "refactor"
    CHORE = "chore"
