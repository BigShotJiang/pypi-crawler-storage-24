"""Plan CRUD commands — create and add-task.

These functions are registered on plan_app by the plan_commands shim.
Uses late imports from plan_commands for mockable dependencies.
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import Optional, List

import typer

from .models import Plan, Task, TaskStatus, PlanStatus, PlanType

logger = logging.getLogger(__name__)


def plan_new(
    slug: str = typer.Argument(..., help="Short identifier (e.g., 'workspace-filter')"),
    plan_type: str = typer.Option(
        "feature", "--type", "-t",
        help="Type: feature|bugfix|refactor|chore"
    ),
    title: Optional[str] = typer.Option(None, "--title", "-T", help="Plan title"),
    skill: str = typer.Option(
        "planning-with-pm",
        "--skill", "-s",
        help="Associated skill for this plan"
    ),
    flow: Optional[str] = typer.Option(
        None,
        "--flow", "-f",
        help="[DEPRECATED] Use --skill instead",
        hidden=True
    ),
    goal: Optional[List[str]] = typer.Option(None, "--goal", "-g", help="Plan goals (repeatable)"),
    scope: Optional[str] = typer.Option(
        None, "--scope",
        help="PM hierarchy scope: epic|story",
    ),
    feature_id: Optional[str] = typer.Option(
        None, "--feature-id",
        help="Feature grouping ID (e.g., 'pm-framework-alignment')",
    ),
    total_cx: Optional[int] = typer.Option(
        None, "--total-cx",
        help="Total complexity estimate (triggers auto-scope detection)",
    ),
):
    """Create a new plan."""
    _execute_plan_new(slug, plan_type, title, skill, flow, goal, scope, feature_id, total_cx)


def _execute_plan_new(slug, plan_type, title, skill, flow, goal, scope, feature_id, total_cx=None):
    """Core logic for plan new command."""
    import bpsai_pair.planning.plan_commands as pc

    paircoder_dir = pc.find_paircoder_dir()
    plan_parser = pc.PlanParser(paircoder_dir / "plans")
    plan_id = _validate_plan_new_args(pc, slug, plan_type, plan_parser)
    ptype, actual_skill = _resolve_type_and_skill(pc, plan_type, skill, flow)
    metadata = _build_scope_metadata(pc, scope, feature_id)
    _auto_detect_scope_from_cx(pc, metadata, total_cx, paircoder_dir)
    _auto_detect_scope(pc, metadata, plan_parser, paircoder_dir)

    plan = Plan(
        id=plan_id,
        title=title or slug.replace("-", " ").title(),
        type=ptype, status=PlanStatus.PLANNED,
        created_at=datetime.now(),
        skills=[actual_skill],
        goals=list(goal) if goal else [],
        metadata=metadata,
    )

    plan_path = plan_parser.save(plan)
    pm_scope = metadata.get("pm_scope", "epic")
    parent_epic_id = metadata.get("parent_epic_id")
    card_id = _create_pm_card_if_available(plan, paircoder_dir, pm_scope, parent_epic_id)
    if card_id:
        key = "story_provider_id" if pm_scope == "story" else "epic_provider_id"
        plan.metadata[key] = card_id
        plan_parser.save(plan)

    if pm_scope == "story" and parent_epic_id:
        _link_story_to_epic_if_available(plan, paircoder_dir, card_id, parent_epic_id)

    _display_plan_created(pc, plan_id, plan.title, plan_type, actual_skill, goal, paircoder_dir, plan_path)
    _fire_plan_created_hook(paircoder_dir, plan_id, epic_provider_id=card_id if pm_scope == "epic" else None)


def _validate_plan_new_args(pc, slug, plan_type, plan_parser) -> str:
    """Validate plan_new arguments, return plan_id or exit."""
    date_str = datetime.now().strftime("%Y-%m")
    plan_id = f"plan-{date_str}-{slug}"
    if plan_parser.get_plan_by_id(plan_id):
        pc.console.print(f"[red]Plan already exists: {plan_id}[/red]")
        raise typer.Exit(1)
    return plan_id


def _resolve_type_and_skill(pc, plan_type, skill, flow):
    """Parse plan type and resolve skill (handling deprecated --flow)."""
    try:
        ptype = PlanType(plan_type)
    except ValueError:
        pc.console.print(f"[red]Invalid plan type: {plan_type}[/red]")
        pc.console.print("Valid types: feature, bugfix, refactor, chore")
        raise typer.Exit(1)
    actual_skill = skill
    if flow:
        pc.console.print("[yellow]\u26a0 Warning: --flow is deprecated, use --skill instead[/yellow]")
        actual_skill = flow
    return ptype, actual_skill


_VALID_SCOPES = {"epic", "story"}


def _build_scope_metadata(pc, scope: str | None, feature_id: str | None) -> dict:
    """Build plan metadata dict from --scope and --feature-id options."""
    metadata: dict = {}
    if isinstance(scope, str):
        if scope not in _VALID_SCOPES:
            pc.console.print(
                f"[red]Invalid scope: {scope}[/red]\n"
                f"Valid scopes: {', '.join(sorted(_VALID_SCOPES))}"
            )
            raise typer.Exit(1)
        metadata["pm_scope"] = scope
    if isinstance(feature_id, str):
        metadata["feature_id"] = feature_id
    return metadata


def _find_epic_plan_by_feature_id(plan_parser, feature_id: str) -> Plan | None:
    """Search existing plans for one with matching feature_id and pm_scope=epic."""
    for plan in plan_parser.parse_all():
        meta = plan.metadata
        if meta.get("feature_id") == feature_id and meta.get("pm_scope") == "epic":
            return plan
    return None


def _has_hierarchy_provider(paircoder_dir: Path) -> bool:
    """Check if the active PM provider supports hierarchy."""
    try:
        from ..pm.registry import get_active_provider
        import yaml

        config_path = paircoder_dir / "config.yaml"
        if not config_path.exists():
            return False
        with open(config_path) as f:
            full_config = yaml.safe_load(f) or {}

        provider = get_active_provider(full_config)
        return provider.name != "none" and "hierarchy" in provider.capabilities()
    except Exception:
        return False


def _read_sprint_cx_budget(paircoder_dir: Path) -> int:
    """Read sprint_cx_budget from config, defaulting to 300."""
    from .scope_detector import DEFAULT_SPRINT_CX_BUDGET

    try:
        import yaml
        config_path = paircoder_dir / "config.yaml"
        if not config_path.exists():
            return DEFAULT_SPRINT_CX_BUDGET
        with open(config_path) as f:
            cfg = yaml.safe_load(f) or {}
        return cfg.get("token_budget", {}).get(
            "sprint_cx_budget", DEFAULT_SPRINT_CX_BUDGET
        )
    except Exception:
        return DEFAULT_SPRINT_CX_BUDGET


def _auto_detect_scope_from_cx(
    pc, metadata: dict, total_cx: int | None, paircoder_dir: Path,
) -> None:
    """Auto-detect pm_scope from total complexity. Mutates metadata."""
    if "pm_scope" in metadata:
        return  # Explicit --scope provided
    if total_cx is None:
        return  # No complexity estimate given

    from .scope_detector import detect_scope

    budget = _read_sprint_cx_budget(paircoder_dir)
    result = detect_scope(total_cx, budget)
    metadata["pm_scope"] = result.scope
    pc.console.print(
        f"[dim]Auto-scope: {result.scope} ({result.reason})[/dim]"
    )


def _auto_detect_scope(pc, metadata: dict, plan_parser, paircoder_dir: Path) -> None:
    """Auto-detect pm_scope when not explicitly set. Mutates metadata in-place."""
    if "pm_scope" in metadata:
        return  # Explicit --scope provided, skip detection

    if not _has_hierarchy_provider(paircoder_dir):
        return  # No hierarchy provider, no detection needed

    feature_id = metadata.get("feature_id")
    if feature_id:
        epic_plan = _find_epic_plan_by_feature_id(plan_parser, feature_id)
        if epic_plan:
            metadata["pm_scope"] = "story"
            epic_pid = epic_plan.metadata.get("epic_provider_id")
            if epic_pid:
                metadata["parent_epic_id"] = epic_pid
            return
        pc.console.print(
            f"[red]No Epic plan found for feature '{feature_id}'.[/red]\n"
            f"Use --scope epic to create one."
        )
        raise typer.Exit(1)

    pc.console.print(
        "[red]Hierarchy provider connected but no scope specified.[/red]\n"
        "Use --scope epic|story or --feature-id to auto-detect."
    )
    raise typer.Exit(1)


def plan_add_task(
    plan_id: str = typer.Argument(..., help="Plan ID"),
    task_id: str = typer.Option(..., "--id", help="Task ID (e.g., TASK-007)"),
    title: str = typer.Option(..., "--title", "-t", help="Task title"),
    task_type: str = typer.Option("feature", "--type", help="Task type"),
    priority: str = typer.Option("P1", "--priority", "-p", help="Priority (P0, P1, P2)"),
    complexity: int = typer.Option(50, "--complexity", "-c", help="Complexity (0-100)"),
    sprint: Optional[str] = typer.Option(None, "--sprint", "-s", help="Sprint ID"),
):
    """Add a task to a plan."""
    import bpsai_pair.planning.plan_commands as pc

    paircoder_dir = pc.find_paircoder_dir()
    plan_parser = pc.PlanParser(paircoder_dir / "plans")
    task_parser = pc.TaskParser(paircoder_dir / "tasks")

    plan = plan_parser.get_plan_by_id(plan_id)
    if not plan:
        pc.console.print(f"[red]Plan not found: {plan_id}[/red]")
        raise typer.Exit(1)

    task = Task(
        id=task_id,
        title=title,
        plan_id=plan.id,
        type=task_type,
        priority=priority,
        complexity=complexity,
        status=TaskStatus.PENDING,
        sprint=sprint,
    )

    task_path = task_parser.save(task)

    pc.console.print(f"[green]Created task:[/green] {task_id}")
    pc.console.print(f"  Path: {task_path}")
    pc.console.print(f"  Plan: {plan_id}")
    pc.display_task_intelligence(paircoder_dir, task_type, complexity)


def _display_plan_created(pc, plan_id, title, plan_type, skill, goal, paircoder_dir, plan_path):
    """Display plan creation output."""
    pc.console.print(f"[green]Created plan:[/green] {plan_id}")
    pc.console.print(f"  Path: {plan_path}")
    pc.console.print(f"  Type: {plan_type}")
    pc.console.print(f"  Skill: {skill}")

    if goal:
        pc.console.print("  Goals:")
        for g in goal:
            pc.console.print(f"    - {g}")

    pc.display_scope_analysis(paircoder_dir, title)
    pc.display_push_results(paircoder_dir, title)

    pc.console.print("")
    pc.console.print("[dim]Next steps:[/dim]")
    pc.console.print(f"  1. Add tasks: bpsai-pair plan add-task {plan_id}")
    pc.console.print(f"  2. Read skill: .claude/skills/{skill}/SKILL.md")


def _create_pm_card_if_available(
    plan: Plan, paircoder_dir: Path, scope: str = "epic",
    parent_epic_id: str | None = None,
) -> str | None:
    """Create an Epic or Story in the PM provider if connected with hierarchy."""
    try:
        from ..pm.registry import get_active_provider

        config_path = paircoder_dir / "config.yaml"
        if not config_path.exists():
            return None

        import yaml
        with open(config_path) as f:
            full_config = yaml.safe_load(f) or {}

        provider = get_active_provider(full_config)
        if provider.name == "none":
            return None

        from .plan_pm_sync import create_plan_pm_card
        return create_plan_pm_card(plan, provider, scope=scope, parent_epic_id=parent_epic_id)
    except Exception as exc:
        logger.debug("PM card creation skipped: %s", exc)
        return None


def _link_story_to_epic_if_available(
    plan: Plan, paircoder_dir: Path, story_card_id: str, parent_epic_id: str,
) -> None:
    """Link a Story card to its parent Epic's checklist + relationship."""
    try:
        from ..pm.registry import get_active_provider
        import yaml

        config_path = paircoder_dir / "config.yaml"
        if not config_path.exists():
            return

        with open(config_path) as f:
            full_config = yaml.safe_load(f) or {}

        provider = get_active_provider(full_config)
        if provider.name == "none":
            return

        from .plan_pm_sync import link_story_to_parent_epic
        sprint_id = plan.metadata.get("sprint") if plan.metadata else None
        link_story_to_parent_epic(
            provider, parent_epic_id, story_card_id, plan.title, sprint_id,
        )
    except Exception as exc:
        logger.debug("Story-to-Epic linking skipped: %s", exc)


def _fire_plan_created_hook(
    paircoder_dir: Path, plan_id: str, *, epic_provider_id: str | None = None,
) -> None:
    """Fire the on_plan_created hook event."""
    try:
        from ..core.hooks import HookRunner, HookContext, load_config

        config = load_config(paircoder_dir)
        runner = HookRunner(config, paircoder_dir)
        if not runner.enabled:
            return

        extra = {"plan_id": plan_id}
        if epic_provider_id:
            extra["epic_provider_id"] = epic_provider_id

        ctx = HookContext(
            task_id=plan_id, event="on_plan_created",
            agent="cli", extra=extra,
        )
        runner.run_hooks("on_plan_created", ctx)
    except ImportError:
        pass
    except Exception as exc:
        logger.debug("on_plan_created hook failed: %s", exc)
