"""Unified task done command — atomically completes a task.

Updates the task file status to 'done', sets completed_at,
runs completion hooks, and performs a consistency check.
"""
from pathlib import Path
from typing import Any, Optional

from .helpers import console


def execute_task_done(
    task_id: str,
    paircoder_dir: Path,
    plan_id: Optional[str] = None,
    no_hooks: bool = False,
) -> dict[str, Any]:
    """Atomically mark a task as done.

    Returns:
        Dict with 'success', 'error' (if failed), 'consistency_checked'.
    """
    from .task_parser import TaskParser
    from .parser import PlanParser

    task_parser = TaskParser(paircoder_dir / "tasks")
    plan_parser = PlanParser(paircoder_dir / "plans")
    plan_slug = _resolve_plan_slug(plan_parser, plan_id)
    task = task_parser.get_task_by_id(task_id, plan_slug)

    if task is None:
        return {"success": False, "error": f"Task not found: {task_id}"}

    old_status = task.status.value
    success = task_parser.update_status(task_id, "done", plan_slug)
    if not success:
        return {"success": False, "error": f"Failed to update task file: {task_id}"}

    console.print(f"[green]\u2713 {task_id} -> done[/green]")

    return _post_update(
        paircoder_dir, task_id, task, old_status, plan_parser, no_hooks
    )


def _post_update(
    paircoder_dir: Path, task_id: str, task, old_status: str,
    plan_parser, no_hooks: bool,
) -> dict[str, Any]:
    """Run post-update steps: cache, hooks, state machine, plan, consistency."""
    _record_cli_cache(paircoder_dir, task_id)

    if not no_hooks and old_status != "done":
        _run_hooks(paircoder_dir, task_id, task)

    _run_state_machine(task_id)

    if task.plan_id:
        _update_plan_status(plan_parser, task, paircoder_dir)

    from .task_consistency import warn_on_inconsistency
    warned = warn_on_inconsistency(paircoder_dir)

    return {
        "success": True,
        "consistency_checked": True,
        "consistency_warned": warned,
    }


def _resolve_plan_slug(plan_parser, plan_id: Optional[str]) -> Optional[str]:
    """Resolve plan_id to plan_slug."""
    if not plan_id:
        return None
    plan = plan_parser.get_plan_by_id(plan_id)
    return plan.slug if plan else None


def _record_cli_cache(paircoder_dir: Path, task_id: str) -> None:
    """Record the update in CLI cache for manual-edit detection."""
    try:
        from .cli_update_cache import get_cli_update_cache
        cache = get_cli_update_cache(paircoder_dir)
        cache.record_update(task_id, "done")
    except Exception:
        pass


def _run_hooks(paircoder_dir: Path, task_id: str, task) -> None:
    """Run status-change hooks for task completion."""
    try:
        from .status_hooks import run_status_hooks
        run_status_hooks(paircoder_dir, task_id, "done", task)
    except Exception as e:
        console.print(f"  [yellow]\u2192 Hook error: {e}[/yellow]")


def _run_state_machine(task_id: str) -> None:
    """Transition task via state machine if enabled."""
    try:
        from .completion_helpers import complete_task_with_state_machine
        ok, msg = complete_task_with_state_machine(task_id, trigger="task_done")
        if not ok:
            console.print(f"[yellow]\u26a0 State machine: {msg}[/yellow]")
    except Exception:
        pass


def _update_plan_status(plan_parser, task, paircoder_dir: Path) -> None:
    """Check and update plan status after task completion."""
    try:
        updated = plan_parser.check_and_update_plan_status(
            task.plan_id, paircoder_dir / "tasks"
        )
        if updated:
            plan = plan_parser.get_plan_by_id(task.plan_id)
            if plan:
                console.print(f"  \u2192 Plan {plan.id} is now {plan.status.value}")
    except Exception:
        pass
