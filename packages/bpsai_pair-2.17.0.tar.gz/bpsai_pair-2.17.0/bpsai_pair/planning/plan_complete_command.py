"""Plan complete command — formally close a completed plan.

Verifies all tasks are in terminal state (done/cancelled) before
marking the plan as complete. Use --force to override.
"""
import typer

from .helpers import find_paircoder_dir, console
from .parser import PlanParser, TaskParser
from .plan_enums import PlanStatus, TaskStatus


TERMINAL_STATUSES = {TaskStatus.DONE, TaskStatus.CANCELLED}


def plan_complete_cmd(
    plan_id: str = typer.Argument(..., help="Plan ID to complete"),
    force: bool = typer.Option(False, "--force", help="Complete even if tasks are not all done"),
):
    """Mark a plan as complete."""
    paircoder_dir = find_paircoder_dir()
    plan_parser = PlanParser(paircoder_dir / "plans")
    task_parser = TaskParser(paircoder_dir / "tasks")

    plan = plan_parser.get_plan_by_id(plan_id)
    if not plan:
        console.print(f"[red]Plan not found: {plan_id}[/red]")
        raise typer.Exit(1)

    if plan.status == PlanStatus.COMPLETE:
        console.print(f"[yellow]Plan {plan_id} is already complete.[/yellow]")
        return

    tasks = task_parser.get_tasks_for_plan(plan_id)
    if not tasks:
        console.print(f"[red]No tasks found for plan {plan_id}.[/red]")
        raise typer.Exit(1)

    incomplete = [t for t in tasks if t.status not in TERMINAL_STATUSES]

    if incomplete and not force:
        console.print(f"[red]Cannot complete plan: {len(incomplete)} task(s) not done[/red]")
        console.print("\n[dim]Incomplete tasks:[/dim]")
        for t in incomplete:
            console.print(f"  {t.status.value:12s}  {t.id}: {t.title}")
        console.print(f"\n[dim]Use --force to complete anyway.[/dim]")
        raise typer.Exit(1)

    if incomplete and force:
        console.print(f"[yellow]Forcing completion with {len(incomplete)} incomplete task(s)[/yellow]")

    plan_parser.update_plan_status(plan_id, PlanStatus.COMPLETE)

    done_count = sum(1 for t in tasks if t.status == TaskStatus.DONE)
    cancelled_count = sum(1 for t in tasks if t.status == TaskStatus.CANCELLED)
    total = len(tasks)

    console.print(f"\n[green]Plan {plan_id} marked as complete.[/green]")
    console.print(f"  Tasks: {done_count} done, {cancelled_count} cancelled, {total} total")
