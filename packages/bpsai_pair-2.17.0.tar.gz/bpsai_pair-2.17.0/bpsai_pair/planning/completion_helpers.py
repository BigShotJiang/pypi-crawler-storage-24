"""Task completion checks and state machine transitions.

Extracted from helpers.py for architecture compliance.
Handles state.md verification, local AC sync, and
state machine transitions for task completion.
"""

import json
import os
from datetime import datetime
from pathlib import Path

from . import helpers as _helpers


def _get_task_start_time(paircoder_dir: Path, task_id: str) -> float | None:
    """Get task start timestamp from timer cache or task file mtime."""
    timer_cache_path = paircoder_dir / "time-tracking-cache.json"
    task_start_time = None

    if timer_cache_path.exists():
        try:
            with open(timer_cache_path, encoding='utf-8') as f:
                cache_data = json.load(f)

            active = cache_data.get("_active", {})
            if active.get("task_id") == task_id and active.get("start"):
                task_start_time = datetime.fromisoformat(active["start"]).timestamp()

            if task_start_time is None and task_id in cache_data:
                entries = cache_data[task_id].get("entries", [])
                if entries and entries[-1].get("start"):
                    task_start_time = datetime.fromisoformat(entries[-1]["start"]).timestamp()

        except (json.JSONDecodeError, KeyError, ValueError):
            pass

    if task_start_time is None:
        task_files = list(paircoder_dir.glob(f"tasks/**/{task_id}.task.md"))
        task_files.extend(list(paircoder_dir.glob(f"tasks/{task_id}.task.md")))
        if task_files:
            task_start_time = os.path.getmtime(task_files[0])

    return task_start_time


def check_state_md_updated(paircoder_dir: Path, task_id: str) -> dict:
    """Check if state.md was updated since task started (uses timer or file mtime)."""
    state_path = paircoder_dir / "context" / "state.md"

    if not state_path.exists():
        return {"updated": True, "reason": "state.md not found - skipping check"}

    state_mtime = os.path.getmtime(state_path)
    task_start_time = _get_task_start_time(paircoder_dir, task_id)

    if task_start_time is None:
        return {"updated": True, "reason": "Could not determine task start time - skipping check"}

    if state_mtime > task_start_time:
        return {"updated": True, "reason": "state.md updated after task started"}
    return {
        "updated": False,
        "reason": "state.md was last modified before task started",
    }


def _transition_to_local_ac_verified(task_id: str, is_trello: bool) -> None:
    """Transition state machine to LOCAL_AC_VERIFIED if enabled."""
    from ..core.task_state import (
        TaskState, get_state_manager, is_state_machine_enabled,
    )

    if not is_state_machine_enabled():
        return

    manager = get_state_manager()
    current = manager.get_state(task_id)

    if is_trello and current == TaskState.AC_VERIFIED:
        manager.transition(task_id, TaskState.LOCAL_AC_VERIFIED, trigger="sync_local_ac")
    elif current == TaskState.IN_PROGRESS:
        manager.transition(task_id, TaskState.LOCAL_AC_VERIFIED, trigger="verify_local_ac")
    # LOCAL_AC_VERIFIED or untracked: no-op


def sync_local_ac_for_completion(task_id: str, is_trello: bool = False) -> tuple[bool, str]:
    """Sync local AC items and verify state machine transition for completion.

    Args:
        task_id: The task ID to sync AC for
        is_trello: True if coming from ttask done (Trello path), False for local path

    Returns:
        Tuple of (success: bool, message: str)
    """
    try:
        from ..core.task_state import verify_local_ac, sync_trello_ac_to_local

        if is_trello:
            sync_result = sync_trello_ac_to_local(task_id)
            if sync_result.get("error"):
                return False, f"Failed to sync local AC: {sync_result['error']}"
            if sync_result.get("checked_count", 0) > 0:
                _helpers.console.print(f"[green]\u2713 Synced {sync_result['checked_count']} local AC item(s)[/green]")

        ac_result = verify_local_ac(task_id)
        if ac_result.get("error"):
            return False, f"AC verification error: {ac_result['error']}"

        if not ac_result["verified"]:
            unchecked = ac_result["unchecked_items"]
            unchecked_list = "\n".join(f"  \u25cb {item}" for item in unchecked[:5])
            if len(unchecked) > 5:
                unchecked_list += f"\n  ... and {len(unchecked) - 5} more"
            return False, (
                f"{len(unchecked)} local AC item(s) unchecked:\n{unchecked_list}\n"
                f"Check items: bpsai-pair task check {task_id}"
            )

        _transition_to_local_ac_verified(task_id, is_trello)
        return True, "Local AC verified"

    except Exception as e:
        return False, f"Error syncing local AC: {e}"


def complete_task_with_state_machine(task_id: str, trigger: str = "completion") -> tuple[bool, str]:
    """Transition task to COMPLETED state via state machine (if enabled).

    Args:
        task_id: The task ID to complete
        trigger: Description of what triggered completion

    Returns:
        Tuple of (success: bool, message: str)
    """
    try:
        from ..core.task_state import (
            TaskState, get_state_manager, is_state_machine_enabled,
        )

        if not is_state_machine_enabled():
            return True, "State machine not enabled"

        manager = get_state_manager()
        current = manager.get_state(task_id)

        if current != TaskState.LOCAL_AC_VERIFIED:
            allowed, reason = manager.can_transition(task_id, TaskState.COMPLETED)
            if not allowed:
                return False, reason

        manager.transition(task_id, TaskState.COMPLETED, trigger=trigger)
        return True, "Task completed"

    except Exception as e:
        return False, f"Error completing task: {e}"
