"""Task/state consistency validation.

Compares task statuses in state.md with actual task file statuses
to detect drift (e.g., state.md says 'done' but task file says 'in_progress').
"""
from pathlib import Path
from typing import Any


def check_consistency(paircoder_dir: Path) -> dict[str, Any]:
    """Check that state.md and task files agree on completion status.

    Returns:
        Dict with 'consistent' (bool) and 'mismatches' (list of dicts).
        Each mismatch has: task_id, state_md_status, task_file_status.
    """
    from .task_parser import TaskParser
    from ..commands.state_validation import extract_done_tasks_from_state_md

    state_path = paircoder_dir / "context" / "state.md"
    if not state_path.exists():
        return {"consistent": True, "mismatches": []}

    content = state_path.read_text(encoding="utf-8")
    done_in_state = extract_done_tasks_from_state_md(content)

    if not done_in_state:
        return {"consistent": True, "mismatches": []}

    task_parser = TaskParser(paircoder_dir / "tasks")
    mismatches = []

    for task_id in sorted(done_in_state):
        task = task_parser.get_task_by_id(task_id)
        if task is None:
            # No task file — could be Trello-only, skip
            continue

        file_status = task.status.value if hasattr(task.status, "value") else str(task.status)
        if file_status != "done":
            mismatches.append({
                "task_id": task_id,
                "state_md_status": "done",
                "task_file_status": file_status,
            })

    return {
        "consistent": len(mismatches) == 0,
        "mismatches": mismatches,
    }


def warn_on_inconsistency(paircoder_dir: Path) -> bool:
    """Check consistency and print warnings for mismatches.

    Returns:
        True if warnings were emitted, False if consistent.
    """
    from .helpers import console

    result = check_consistency(paircoder_dir)
    if result["consistent"]:
        return False

    console.print(
        "\n[yellow]Warning: state.md and task files disagree "
        "on completion status:[/yellow]"
    )
    for m in result["mismatches"]:
        console.print(
            f"  [yellow]{m['task_id']}:[/yellow] state.md says "
            f"[green]done[/green], task file says "
            f"[red]{m['task_file_status']}[/red]"
        )
    console.print(
        "[dim]Fix with: bpsai-pair task done <id>[/dim]\n"
    )
    return True
