"""Plan status command — detailed plan progress view.

This function is registered on plan_app by the plan_commands shim.
Uses late imports from plan_commands for mockable dependencies.
"""

from typing import Optional
import json

import typer
from rich.table import Table

from .models import TaskStatus


def plan_status_cmd(
    plan_id: str = typer.Argument("current", help="Plan ID or 'current' for active plan"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show individual task list"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show plan status with sprint/task breakdown."""
    import bpsai_pair.planning.plan_commands as pc

    paircoder_dir = pc.find_paircoder_dir()
    state_manager = pc.get_state_manager()
    plan_parser = pc.PlanParser(paircoder_dir / "plans")
    task_parser = pc.TaskParser(paircoder_dir / "tasks")

    if plan_id == "current":
        plan_id = state_manager.get_active_plan_id()
        if not plan_id:
            pc.console.print("[yellow]No active plan. Specify a plan ID.[/yellow]")
            pc.console.print("[dim]List plans: bpsai-pair plan list[/dim]")
            raise typer.Exit(1)

    plan = plan_parser.get_plan_by_id(plan_id)
    if not plan:
        pc.console.print(f"[red]Plan not found: {plan_id}[/red]")
        raise typer.Exit(1)

    tasks = task_parser.get_tasks_for_plan(plan.id)

    task_counts = {"pending": 0, "in_progress": 0, "done": 0, "blocked": 0, "cancelled": 0}
    for task in tasks:
        status_key = task.status.value
        if status_key in task_counts:
            task_counts[status_key] += 1

    total_tasks = len(tasks)
    done_count = task_counts["done"]
    progress_pct = int((done_count / total_tasks) * 100) if total_tasks > 0 else 0

    sprints_tasks = {}
    no_sprint = []
    for task in tasks:
        if task.sprint:
            if task.sprint not in sprints_tasks:
                sprints_tasks[task.sprint] = []
            sprints_tasks[task.sprint].append(task)
        else:
            no_sprint.append(task)

    blockers = []
    for task in tasks:
        if task.status == TaskStatus.BLOCKED:
            if task.depends_on:
                reason = f"depends on {', '.join(task.depends_on)}"
            else:
                reason = "blocked"
            blockers.append((task.id, task.title, reason))

    if json_out:
        data = {
            "plan_id": plan.id,
            "title": plan.title,
            "status": plan.status.value,
            "type": plan.type.value,
            "goals": plan.goals,
            "progress_percent": progress_pct,
            "task_counts": task_counts,
            "total_tasks": total_tasks,
            "sprints": {
                sprint_id: {
                    "tasks": len(tasks_list),
                    "done": sum(1 for t in tasks_list if t.status == TaskStatus.DONE),
                }
                for sprint_id, tasks_list in sprints_tasks.items()
            },
            "blockers": [{"id": b[0], "title": b[1], "reason": b[2]} for b in blockers],
        }
        pc.console.print(json.dumps(data, indent=2))
        return

    pc.console.print(f"\n[bold]Plan:[/bold] {plan.id}")
    pc.console.print(f"[bold]Title:[/bold] {plan.title}")
    pc.console.print(f"[bold]Status:[/bold] {plan.status_emoji} {plan.status.value}")
    pc.console.print(f"[bold]Type:[/bold] {plan.type.value}")

    if plan.goals:
        pc.console.print("\n[bold]Goals:[/bold]")
        for goal in plan.goals:
            check = "\u2713" if "complete" in goal.lower() or "done" in goal.lower() else "\u25cb"
            pc.console.print(f"  {check} {goal}")

    if sprints_tasks:
        pc.console.print("\n[bold]Sprint Progress:[/bold]")
        for sprint_id in sorted(sprints_tasks.keys()):
            sprint_tasks = sprints_tasks[sprint_id]
            sprint_total = len(sprint_tasks)
            sprint_done = sum(1 for t in sprint_tasks if t.status == TaskStatus.DONE)
            sprint_pct = int((sprint_done / sprint_total) * 100) if sprint_total > 0 else 0

            filled = int(sprint_pct / 6.25)
            bar = "\u2588" * filled + "\u2591" * (16 - filled)
            pc.console.print(f"  {sprint_id} [{bar}] {sprint_pct:3d}%  ({sprint_done}/{sprint_total} tasks)")

    pc.console.print("\n[bold]Task Status:[/bold]")
    pc.console.print(f"  \u2713 Done:        {task_counts['done']}")
    pc.console.print(f"  \u25cf In Progress: {task_counts['in_progress']}")
    pc.console.print(f"  \u25cb Pending:     {task_counts['pending']}")
    pc.console.print(f"  \u2298 Blocked:     {task_counts['blocked']}")
    if task_counts['cancelled'] > 0:
        pc.console.print(f"  \u2717 Cancelled:   {task_counts['cancelled']}")

    filled = int(progress_pct / 6.25)
    bar = "\u2588" * filled + "\u2591" * (16 - filled)
    pc.console.print(f"\n[bold]Overall:[/bold] [{bar}] {progress_pct}% ({done_count}/{total_tasks} tasks)")

    if blockers:
        pc.console.print("\n[bold]Blockers:[/bold]")
        for task_id, title, reason in blockers:
            pc.console.print(f"  [red]\u2298[/red] {task_id}: {title}")
            pc.console.print(f"    [dim]\u2192 {reason}[/dim]")

    if verbose:
        pc.console.print("\n[bold]All Tasks:[/bold]")
        table = Table(show_header=True)
        table.add_column("Status", width=3)
        table.add_column("ID", style="cyan")
        table.add_column("Title")
        table.add_column("Sprint")
        table.add_column("Priority")

        for task in sorted(tasks, key=lambda t: (t.sprint or "", t.priority, t.id)):
            table.add_row(
                task.status_emoji,
                task.id,
                task.title[:40] + "..." if len(task.title) > 40 else task.title,
                task.sprint or "-",
                task.priority,
            )

        pc.console.print(table)

    pc.console.print("")
