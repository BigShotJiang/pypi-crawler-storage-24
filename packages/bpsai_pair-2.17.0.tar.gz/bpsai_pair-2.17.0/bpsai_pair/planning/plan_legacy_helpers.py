"""Helpers for legacy Trello sync — card post-processing.

Extracted from plan_legacy_sync.py to keep file sizes under limits.
"""

from .helpers import console, update_task_with_card_id
from .parser import TaskParser


def handle_synced_card(
    task, task_data, card, existing_card, service, sync_manager,
    results, link_cards, apply_defaults, fire_ready,
    trello_config, task_parser, paircoder_dir,
) -> None:
    """Process a successfully synced card (created or updated)."""
    if existing_card:
        results["cards_updated"].append({
            "task_id": task.id, "card_id": card.id,
        })
        console.print(f"    [yellow]↻[/yellow] {task.id}: {task.title}")
        return

    results["cards_created"].append({
        "task_id": task.id, "card_id": card.id,
    })
    stack = sync_manager.infer_stack(task_data)
    stack_info = f" [{stack}]" if stack else ""
    console.print(f"    [green]+[/green] {task.id}: {task.title}{stack_info}")

    if link_cards:
        update_task_with_card_id(task, str(card.short_id), task_parser)

    if apply_defaults:
        apply_card_defaults(service, card, trello_config)

    if fire_ready:
        fire_ready_hooks(task, paircoder_dir)


def apply_card_defaults(service, card, trello_config: dict) -> None:
    """Apply project defaults from config to a Trello card."""
    defaults = trello_config.get("defaults", {})
    if not defaults:
        return
    field_mapping = {
        "project": "Project", "stack": "Stack",
        "repo_url": "Repo URL", "deployment_tag": "Deployment Tag",
    }
    field_values = {}
    for key, val in defaults.items():
        field_name = field_mapping.get(key, key.replace("_", " ").title())
        field_values[field_name] = val
    if field_values:
        service.set_card_custom_fields(card, field_values)


def fire_ready_hooks(task, paircoder_dir) -> None:
    """Fire on_task_ready hooks for ready tasks."""
    from ..core.task_ready import is_task_ready, fire_on_task_ready
    if is_task_ready(task):
        hook_results = fire_on_task_ready(task, paircoder_dir)
        for hr in hook_results:
            if hr.success and hr.result and hr.result.get("target_list"):
                console.print(f"      [dim]→ Moved to {hr.result['target_list']}[/dim]")
