"""Pull request workflow automation.

Contains PRWorkflow class and module-level convenience functions
for auto-creating PRs and archiving tasks on merge.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, List

from ..core.constants import extract_task_id
from .pr_models import PRInfo
from .pr_manager import PRManager

logger = logging.getLogger(__name__)


class PRWorkflow:
    """Workflow automation for PRs."""

    def __init__(
        self,
        pr_manager: PRManager,
        auto_assign_next: bool = True,
    ):
        """Initialize PR workflow.

        Args:
            pr_manager: PR manager instance
            auto_assign_next: Auto-assign next task on merge
        """
        self.pr_manager = pr_manager
        self.auto_assign_next = auto_assign_next

    def on_task_complete(self, task_id: str) -> Optional[PRInfo]:
        """Handle task completion - create PR if on feature branch.

        Args:
            task_id: Completed task ID

        Returns:
            PRInfo if PR was created
        """
        branch = self.pr_manager.service.get_current_branch()
        if not branch:
            return None

        default = self.pr_manager.service.client.get_default_branch(
            self.pr_manager.project_root
        )
        if branch == default:
            logger.info("On default branch, skipping PR creation")
            return None

        existing = self.pr_manager.get_pr_for_branch(branch)
        if existing:
            logger.info(f"PR already exists: #{existing.number}")
            return existing

        return self.pr_manager.create_pr_for_task(
            task_id=task_id,
            summary=f"Implementation of {task_id}",
        )

    def on_pr_merge(self, pr_number: int) -> Optional[str]:
        """Handle PR merge - update task and optionally assign next.

        Args:
            pr_number: Merged PR number

        Returns:
            Next task ID if assigned
        """
        next_task_id = None

        def on_merge(task_id: str):
            nonlocal next_task_id
            if self.auto_assign_next:
                try:
                    from ..planning.auto_assign import auto_assign_next
                    next_task = auto_assign_next(self.pr_manager.paircoder_dir)
                    if next_task:
                        next_task_id = next_task.id
                        logger.info(f"Auto-assigned next task: {next_task_id}")
                except Exception as e:
                    logger.error(f"Failed to auto-assign next task: {e}")

        self.pr_manager.update_task_on_merge(pr_number, on_merge)
        return next_task_id


def auto_create_pr_for_branch(
    project_root: Optional[Path] = None,
    paircoder_dir: Optional[Path] = None,
    draft: bool = True,
) -> Optional[PRInfo]:
    """Auto-create a draft PR when a feature branch is pushed.

    Args:
        project_root: Project root directory
        paircoder_dir: Path to .paircoder directory
        draft: Create as draft PR (default True)

    Returns:
        PRInfo if PR was created, None otherwise
    """
    project_root = project_root or Path.cwd()
    paircoder_dir = paircoder_dir or (project_root / ".paircoder")

    manager = PRManager(project_root=project_root, paircoder_dir=paircoder_dir)

    branch = manager.service.get_current_branch()
    if not branch:
        logger.warning("Could not determine current branch")
        return None

    default_branch = manager.service.client.get_default_branch(project_root)
    if branch == default_branch:
        logger.info("On default branch, skipping PR creation")
        return None

    existing = manager.get_pr_for_branch(branch)
    if existing:
        logger.info(f"PR already exists: #{existing.number}")
        return existing

    task_id = extract_task_id(branch)
    if not task_id:
        logger.info(f"No task ID found in branch name: {branch}")
        return None

    logger.info(f"Creating draft PR for {task_id} on branch {branch}")
    return manager.create_pr_for_task(
        task_id=task_id,
        summary=f"Implementation of {task_id}",
        draft=draft,
    )


def _find_task_file(paircoder_dir: Path, task_id: str) -> Optional[Path]:
    """Find task file by ID, checking both rglob and direct path."""
    for f in (paircoder_dir / "tasks").rglob(f"{task_id}.task.md"):
        return f

    task_file = paircoder_dir / "tasks" / f"{task_id}.task.md"
    if task_file.exists():
        return task_file

    return None


def _get_merged_pr_info(manager: PRManager, pr_number: int, project_root: Path):
    """Get PRInfo for a merged PR, or None if not merged/not found."""
    status = manager.service.client.get_pr_status(
        pr_number=pr_number, cwd=project_root,
    )
    if not status:
        logger.warning(f"Could not get PR #{pr_number} status")
        return None

    pr_info = PRInfo.from_gh_json(status)
    if pr_info.state != "merged":
        logger.info(f"PR #{pr_number} is not merged (state: {pr_info.state})")
        return None
    if not pr_info.task_id:
        logger.info(f"PR #{pr_number} is not linked to a task")
        return None
    return pr_info


def _archive_task(project_root: Path, paircoder_dir: Path, task_id: str, pr_number: int) -> bool:
    """Archive a task file using TaskArchiver."""
    try:
        from ..tasks import TaskArchiver, TaskLifecycle

        task_file = _find_task_file(paircoder_dir, task_id)
        if not task_file or not task_file.exists():
            logger.warning(f"Task file not found: {task_id}")
            return False

        lifecycle = TaskLifecycle(paircoder_dir / "tasks")
        task = lifecycle.load_task(task_file)
        result = TaskArchiver(project_root).archive_batch([task], task.sprint or "merged")

        if result.archived:
            logger.info(f"Archived {task_id} after PR #{pr_number} merge")
            return True
        logger.warning(f"Failed to archive {task_id}: {result.errors}")
        return False
    except ImportError:
        logger.warning("Task archiver not available")
        return False
    except Exception as e:
        logger.error(f"Failed to archive task: {e}")
        return False


def archive_task_on_merge(
    pr_number: int,
    project_root: Optional[Path] = None,
    paircoder_dir: Optional[Path] = None,
) -> bool:
    """Archive a task when its associated PR is merged.

    Args:
        pr_number: PR number to check
        project_root: Project root directory
        paircoder_dir: Path to .paircoder directory

    Returns:
        True if task was archived
    """
    project_root = project_root or Path.cwd()
    paircoder_dir = paircoder_dir or (project_root / ".paircoder")

    manager = PRManager(project_root=project_root, paircoder_dir=paircoder_dir)
    pr_info = _get_merged_pr_info(manager, pr_number, project_root)
    if not pr_info:
        return False

    return _archive_task(project_root, paircoder_dir, pr_info.task_id, pr_number)


def check_and_archive_merged_prs(
    project_root: Optional[Path] = None,
    paircoder_dir: Optional[Path] = None,
    limit: int = 10,
) -> List[str]:
    """Check recent merged PRs and archive associated tasks.

    Args:
        project_root: Project root directory
        paircoder_dir: Path to .paircoder directory
        limit: Maximum PRs to check

    Returns:
        List of archived task IDs
    """
    project_root = project_root or Path.cwd()
    paircoder_dir = paircoder_dir or (project_root / ".paircoder")

    manager = PRManager(project_root=project_root, paircoder_dir=paircoder_dir)

    prs = manager.service.client.list_prs(
        state="closed",
        limit=limit,
        cwd=project_root,
    )

    archived = []
    for pr_data in prs:
        pr_info = PRInfo.from_gh_json(pr_data)

        if pr_info.state == "merged" and pr_info.task_id:
            task_file = paircoder_dir / "tasks" / f"{pr_info.task_id}.task.md"
            if task_file.exists():
                if archive_task_on_merge(pr_info.number, project_root, paircoder_dir):
                    archived.append(pr_info.task_id)

    return archived
