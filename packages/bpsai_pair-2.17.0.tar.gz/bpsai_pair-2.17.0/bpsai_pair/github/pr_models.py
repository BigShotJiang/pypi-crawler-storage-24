"""Pull request data models.

Contains the PRInfo dataclass for representing pull request information.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict, Any

from ..core.constants import extract_task_id


@dataclass
class PRInfo:
    """Pull request information."""

    number: int
    title: str
    url: str
    state: str  # open, closed, merged
    task_id: Optional[str] = None
    branch: Optional[str] = None
    base_branch: str = "main"
    draft: bool = False
    mergeable: Optional[bool] = None
    review_decision: Optional[str] = None  # APPROVED, CHANGES_REQUESTED, etc.
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @classmethod
    def from_gh_json(cls, data: Dict[str, Any]) -> "PRInfo":
        """Create PRInfo from gh CLI JSON output.

        Args:
            data: JSON data from gh pr view/list

        Returns:
            PRInfo instance
        """
        title = data.get("title", "")
        task_id = extract_task_id(title)

        return cls(
            number=data.get("number", 0),
            title=title,
            url=data.get("url", data.get("html_url", "")),
            state=data.get("state", "open").lower(),
            task_id=task_id,
            branch=data.get("headRefName"),
            base_branch=data.get("baseRefName", "main"),
            draft=data.get("isDraft", False),
            mergeable=data.get("mergeable") == "MERGEABLE",
            review_decision=data.get("reviewDecision"),
        )

    def is_approved(self) -> bool:
        """Check if PR is approved."""
        return self.review_decision == "APPROVED"

    def is_ready_to_merge(self) -> bool:
        """Check if PR is ready to merge."""
        return (
            self.state == "open"
            and not self.draft
            and self.mergeable is True
            and self.is_approved()
        )
