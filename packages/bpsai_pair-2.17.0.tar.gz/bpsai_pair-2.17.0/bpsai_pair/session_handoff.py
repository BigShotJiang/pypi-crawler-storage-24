"""Handoff consumption for session check.

Thin wrapper around orchestration.handoff_consumer that preserves the
original dict-based public API used by session_check and its tests.

Public API:
    receive_handoffs(handoffs_dir) -> list[dict]
    format_handoff_summary(summaries) -> str
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

_MAX_DISPLAY = 5


def _item_to_dict(item: Any) -> dict[str, Any]:
    """Convert a HandoffSummaryItem to the legacy dict format."""
    return {
        "version": item.version,
        "handoff_id": item.handoff_id,
        "task_id": item.task_id,
        "source_agent": item.source_agent,
        "target_agent": item.target_agent,
        "task_description": "",
        "work_completed": item.work_completed,
        "remaining_work": item.remaining_work,
        "created_at": "",
    }


def receive_handoffs(handoffs_dir: Path) -> list[dict[str, Any]]:
    """Read all handoff files and return lightweight summaries.

    Delegates to HandoffConsumer and converts results to dicts.
    Uses lazy import to avoid triggering orchestration.__init__ side effects.

    Args:
        handoffs_dir: Path to directory containing handoff JSON files.

    Returns:
        List of summary dicts, one per successfully-parsed handoff.
        Empty list if directory doesn't exist or contains no valid files.
    """
    from bpsai_pair.orchestration.handoff_consumer import HandoffConsumer

    consumer = HandoffConsumer(handoffs_dir)
    summary = consumer.consume_all()
    return [_item_to_dict(item) for item in summary.handoffs]


def format_handoff_summary(summaries: list[dict[str, Any]]) -> str:
    """Format handoff summaries for display during session check.

    Shows up to 5 most recent handoffs with task ID and work completed.
    Includes a total count when there are more than the display limit.

    Args:
        summaries: List of summary dicts from receive_handoffs().

    Returns:
        Formatted string for console display, or empty string if none.
    """
    if not summaries:
        return ""

    total = len(summaries)
    recent = summaries[-_MAX_DISPLAY:]

    lines: list[str] = []
    lines.append(f"Prior handoffs ({total} total):")

    for s in recent:
        task_id = s.get("task_id", "?")
        work = s.get("work_completed", "")
        agent = s.get("source_agent", "?")
        line = f"  - [{task_id}] {agent}: {work}" if work else f"  - [{task_id}] {agent}"
        lines.append(line)

    if total > _MAX_DISPLAY:
        lines.append(f"  ... and {total - _MAX_DISPLAY} more")

    return "\n".join(lines)
