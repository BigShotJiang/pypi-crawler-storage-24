"""Data models for security review.

Contains ReviewResult and AuditLogEntry dataclasses used by
the review hook, scanner, and agent-enhanced review components.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class ReviewResult:
    """Result of a security review.

    Attributes:
        allowed: Whether the operation is allowed to proceed
        reason: Explanation for blocking (if blocked)
        warnings: List of warnings that don't block execution
        suggested_fixes: List of suggested remediation steps
    """

    allowed: bool
    reason: str = ""
    warnings: list[str] = field(default_factory=list)
    suggested_fixes: list[str] = field(default_factory=list)

    @classmethod
    def allow(cls) -> "ReviewResult":
        """Create an allowed result with no issues."""
        return cls(allowed=True)

    @classmethod
    def block(
        cls,
        reason: str,
        suggested_fixes: Optional[list[str]] = None
    ) -> "ReviewResult":
        """Create a blocked result with reason.

        Args:
            reason: Why the operation is blocked
            suggested_fixes: Optional list of remediation steps
        """
        return cls(
            allowed=False,
            reason=reason,
            suggested_fixes=suggested_fixes or []
        )

    @classmethod
    def warn(cls, warnings: list[str]) -> "ReviewResult":
        """Create an allowed result with warnings.

        Args:
            warnings: List of warning messages
        """
        return cls(allowed=True, warnings=warnings)

    @property
    def is_blocked(self) -> bool:
        """Check if the result blocks execution."""
        return not self.allowed

    @property
    def has_warnings(self) -> bool:
        """Check if the result has any warnings."""
        return len(self.warnings) > 0

    def format_message(self) -> str:
        """Format the result as a human-readable message."""
        lines = []

        if self.is_blocked:
            lines.append(f"BLOCKED: {self.reason}")
            if self.suggested_fixes:
                lines.append("\nSuggested fixes:")
                for fix in self.suggested_fixes:
                    lines.append(f"  - {fix}")
        elif self.has_warnings:
            lines.append("ALLOWED with warnings:")
            for warning in self.warnings:
                lines.append(f"  - {warning}")
        else:
            lines.append("ALLOWED: Security checks passed.")

        return "\n".join(lines)

    def __repr__(self) -> str:
        if self.is_blocked:
            return f"ReviewResult(blocked: {self.reason})"
        elif self.has_warnings:
            return f"ReviewResult(allowed with {len(self.warnings)} warnings)"
        return "ReviewResult(allowed)"


@dataclass
class AuditLogEntry:
    """Entry in the security audit log."""
    timestamp: datetime
    command: str
    allowed: bool
    reason: str
    warnings: list[str]
