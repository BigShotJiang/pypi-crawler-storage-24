"""Checkpoint display formatting.

This module provides formatting functions for checkpoint
lists and rollback previews.
"""


def format_checkpoint_list(checkpoints: list[dict]) -> str:
    """Format checkpoint list for CLI display.

    Args:
        checkpoints: List of checkpoint info dicts

    Returns:
        Formatted string for display
    """
    if not checkpoints:
        return "No checkpoints found."

    lines = ["Checkpoints:", ""]
    for cp in sorted(checkpoints, key=lambda c: c["timestamp"], reverse=True):
        lines.append(f"  {cp['tag']}")
        lines.append(f"    Commit:  {cp['commit']}")
        lines.append(f"    Time:    {cp['timestamp']}")
        if cp.get("message"):
            lines.append(f"    Message: {cp['message']}")
        lines.append("")

    return "\n".join(lines)


def format_rollback_preview(preview: dict) -> str:
    """Format rollback preview for CLI display.

    Args:
        preview: Preview dict from preview_rollback()

    Returns:
        Formatted string for display
    """
    lines = [
        f"Rollback Preview: {preview['tag']}",
        "",
        f"Commits to revert: {preview['commits_to_revert']}",
        "",
        "Files that will be changed:"
    ]

    for f in preview["files_changed"]:
        lines.append(f"  - {f}")

    if not preview["files_changed"]:
        lines.append("  (no files changed)")

    return "\n".join(lines)
