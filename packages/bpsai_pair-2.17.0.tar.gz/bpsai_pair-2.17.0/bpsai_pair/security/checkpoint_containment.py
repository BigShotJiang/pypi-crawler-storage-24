"""Containment-specific checkpoint operations.

This module provides a mixin class adding containment checkpoint
methods to the git checkpoint system.
"""

import subprocess
from datetime import datetime
from typing import Optional

from .checkpoint_models import CONTAINMENT_CHECKPOINT_PREFIX


class ContainmentCheckpointMixin:
    """Mixin providing containment-specific checkpoint operations.

    Methods in this mixin use self._run_git, self.checkpoints, and
    self.stash_if_dirty from GitCheckpointBase.
    """

    def create_containment_checkpoint(self, auto_stash: bool = True) -> tuple[str, Optional[str]]:
        """Create a containment checkpoint with optional auto-stash.

        Uses containment-YYYYMMDD-HHMMSS format. Optionally stashes
        uncommitted changes before creating the checkpoint.

        Args:
            auto_stash: Whether to stash uncommitted changes before checkpoint

        Returns:
            Tuple of (checkpoint_id, stash_ref) where stash_ref is None if no stash
        """
        stash_ref = None

        if auto_stash:
            stash_ref = self.stash_if_dirty(
                "Auto-stash before containment checkpoint"
            )

        tag_name = self._generate_tag_name(CONTAINMENT_CHECKPOINT_PREFIX)

        timestamp = datetime.now().isoformat()
        tag_message = f"Containment entry checkpoint at {timestamp}"
        self._run_git("tag", "-a", tag_name, "-m", tag_message)

        self.checkpoints.append(tag_name)

        return tag_name, stash_ref

    def list_containment_checkpoints(self) -> list[dict]:
        """List all containment checkpoints.

        Returns:
            List of checkpoint info dicts with tag, commit, timestamp, message
        """
        result = self._run_git("tag", "-l", f"{CONTAINMENT_CHECKPOINT_PREFIX}*")
        tags = result.stdout.strip().split("\n")
        tags = [t for t in tags if t]

        checkpoints = []
        for tag in tags:
            try:
                commit_result = self._run_git("rev-list", "-n", "1", tag)
                commit = commit_result.stdout.strip()[:7]

                msg_result = self._run_git("tag", "-l", "-n1", tag)
                parts = msg_result.stdout.strip().split(None, 1)
                message = parts[1] if len(parts) > 1 else ""

                timestamp_part = tag.replace(CONTAINMENT_CHECKPOINT_PREFIX, "")
                try:
                    dt = datetime.strptime(timestamp_part, "%Y%m%d-%H%M%S")
                    timestamp = dt.strftime("%Y-%m-%d %H:%M:%S")
                except ValueError:
                    timestamp = timestamp_part

                checkpoints.append({
                    "tag": tag,
                    "commit": commit,
                    "timestamp": timestamp,
                    "message": message
                })
            except subprocess.CalledProcessError:
                continue

        return checkpoints

    def get_latest_containment_checkpoint(self) -> Optional[dict]:
        """Get the most recent containment checkpoint.

        Returns:
            Checkpoint info dict or None if no containment checkpoints exist
        """
        checkpoints = self.list_containment_checkpoints()
        if not checkpoints:
            return None
        return sorted(checkpoints, key=lambda c: c["timestamp"], reverse=True)[0]
