"""Dependency vulnerability scanning — re-export shim.

Data models: dep_models.py
Scanner: dep_scanner.py
"""
from .dep_models import (  # noqa: F401
    Severity,
    Vulnerability,
    ScanReport,
    format_scan_report,
)
from .dep_scanner import DependencyScanner  # noqa: F401

__all__ = [
    "Severity",
    "Vulnerability",
    "ScanReport",
    "DependencyScanner",
    "format_scan_report",
]
