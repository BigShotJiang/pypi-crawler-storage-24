"""Secret detection patterns for PairCoder.

This module provides regex patterns for detecting secrets:
- SECRET_PATTERNS: Patterns matched against file content
- IGNORE_PATTERNS: Patterns for false positive suppression
"""

from .secrets_types import SecretType


# Secret detection patterns with confidence scores
SECRET_PATTERNS: list[tuple[str, SecretType, float]] = [
    # AWS Credentials
    (r'AKIA[0-9A-Z]{16}', SecretType.AWS_ACCESS_KEY, 1.0),
    (r'(?i)aws_secret_access_key\s*[=:]\s*["\']?([A-Za-z0-9/+=]{40})["\']?', SecretType.AWS_SECRET_KEY, 0.95),
    (r'(?i)AWS_SECRET_ACCESS_KEY\s*[=:]\s*["\']?([A-Za-z0-9/+=]{40})["\']?', SecretType.AWS_SECRET_KEY, 0.95),

    # GitHub Tokens
    (r'ghp_[A-Za-z0-9]{36}', SecretType.GITHUB_TOKEN, 1.0),
    (r'github_pat_[A-Za-z0-9]{22}_[A-Za-z0-9]{59}', SecretType.GITHUB_PAT, 1.0),
    (r'gho_[A-Za-z0-9]{36}', SecretType.GITHUB_OAUTH, 1.0),
    (r'ghs_[A-Za-z0-9]{36}', SecretType.GITHUB_TOKEN, 1.0),
    (r'ghr_[A-Za-z0-9]{36}', SecretType.GITHUB_TOKEN, 1.0),

    # Slack Tokens
    (r'xox[baprs]-[A-Za-z0-9-]{10,}', SecretType.SLACK_TOKEN, 1.0),
    (r'https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[A-Za-z0-9]+', SecretType.SLACK_WEBHOOK, 1.0),

    # Private Keys - use non-capturing groups to ensure full header is matched
    (r'-----BEGIN\s+(?:RSA\s+)?PRIVATE\s+KEY-----', SecretType.PRIVATE_KEY, 1.0),
    (r'-----BEGIN\s+OPENSSH\s+PRIVATE\s+KEY-----', SecretType.SSH_PRIVATE_KEY, 1.0),
    (r'-----BEGIN\s+EC\s+PRIVATE\s+KEY-----', SecretType.PRIVATE_KEY, 1.0),
    (r'-----BEGIN\s+DSA\s+PRIVATE\s+KEY-----', SecretType.PRIVATE_KEY, 1.0),
    (r'-----BEGIN\s+PGP\s+PRIVATE\s+KEY\s+BLOCK-----', SecretType.PRIVATE_KEY, 1.0),

    # JWT Tokens
    (r'eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}', SecretType.JWT_TOKEN, 0.9),

    # Database URLs with credentials
    (r'(?i)(postgresql|mysql|mongodb|redis)://[^:]+:[^@]+@[^/]+', SecretType.DATABASE_URL, 0.95),

    # Stripe Keys
    (r'sk_live_[A-Za-z0-9]{24,}', SecretType.STRIPE_KEY, 1.0),
    (r'sk_test_[A-Za-z0-9]{24,}', SecretType.STRIPE_KEY, 0.8),
    (r'pk_live_[A-Za-z0-9]{24,}', SecretType.STRIPE_KEY, 0.9),

    # SendGrid
    (r'SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}', SecretType.SENDGRID_KEY, 1.0),

    # Twilio
    (r'SK[A-Za-z0-9]{32}', SecretType.TWILIO_KEY, 0.85),

    # Google API Keys
    (r'AIza[A-Za-z0-9_-]{35}', SecretType.GOOGLE_API_KEY, 1.0),

    # Generic patterns (lower confidence)
    (r'(?i)api[_-]?key\s*[=:]\s*["\']([^"\']{16,})["\']', SecretType.GENERIC_API_KEY, 0.7),
    (r'(?i)apikey\s*[=:]\s*["\']([^"\']{16,})["\']', SecretType.GENERIC_API_KEY, 0.7),
    (r'(?i)password\s*[=:]\s*["\']([^"\']{8,})["\']', SecretType.GENERIC_PASSWORD, 0.6),
    (r'(?i)passwd\s*[=:]\s*["\']([^"\']{8,})["\']', SecretType.GENERIC_PASSWORD, 0.6),
    (r'(?i)secret\s*[=:]\s*["\']([^"\']{8,})["\']', SecretType.GENERIC_SECRET, 0.6),
    (r'(?i)token\s*[=:]\s*["\']([^"\']{20,})["\']', SecretType.GENERIC_TOKEN, 0.6),
]

# Patterns to ignore (false positives)
IGNORE_PATTERNS: list[str] = [
    r'os\.environ\.get\s*\(["\']',  # Reading from env vars
    r'os\.getenv\s*\(["\']',  # Reading from env vars
    r'environ\[["\']',  # Accessing environ dict
    r'#.*password',  # Comments about passwords
    r'#.*secret',  # Comments about secrets
    r'#.*token',  # Comments about tokens
    r'#.*key',  # Comments about keys
    r'EXAMPLE_',  # Example values
    r'example_',  # Example values
    r'your[_-]?api[_-]?key',  # Placeholder text
    r'<[A-Z_]+>',  # Placeholder in angle brackets
    r'\$\{[^}]+\}',  # Environment variable references
    r'process\.env\.',  # Node.js env access
    r'\.env\.',  # dotenv references
    r'placeholder',  # Placeholder values
    r'changeme',  # Placeholder values
    r'xxx+',  # Placeholder patterns
    r'\*{4,}',  # Redacted values
]
