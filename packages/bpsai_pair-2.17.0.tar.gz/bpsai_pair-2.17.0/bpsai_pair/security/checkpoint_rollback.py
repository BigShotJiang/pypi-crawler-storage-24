"""Checkpoint rollback and listing operations.

This module extends GitCheckpointBase with rollback, listing,
preview, and cleanup operations.
"""

import subprocess
from datetime import datetime
from typing import Optional

from .checkpoint_models import (
    CheckpointNotFoundError,
    NoCheckpointsError,
    CHECKPOINT_PREFIX,
)
from .checkpoint_base import GitCheckpointBase


class GitCheckpointRollback(GitCheckpointBase):
    """Adds rollback, listing, preview, and cleanup to checkpoint base."""

    def rollback_to(
        self,
        checkpoint: str,
        stash_uncommitted: bool = True
    ) -> Optional[str]:
        """Rollback to a checkpoint.

        Args:
            checkpoint: Tag name of checkpoint to rollback to
            stash_uncommitted: Whether to stash uncommitted changes

        Returns:
            Stash reference if changes were stashed, None otherwise

        Raises:
            CheckpointNotFoundError: If checkpoint doesn't exist
        """
        # Verify checkpoint exists
        result = self._run_git("tag", "-l", checkpoint, check=False)
        if checkpoint not in result.stdout:
            raise CheckpointNotFoundError(f"Checkpoint '{checkpoint}' not found")

        stash_ref = None

        # Stash uncommitted changes if requested and dirty
        if stash_uncommitted and self.is_dirty():
            stash_message = f"paircoder-rollback-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
            self._run_git("stash", "push", "-m", stash_message)
            stash_ref = stash_message

        # Reset to checkpoint
        self._run_git("reset", "--hard", checkpoint)

        return stash_ref

    def rollback_to_last(self, stash_uncommitted: bool = True) -> Optional[str]:
        """Rollback to the most recent checkpoint.

        Args:
            stash_uncommitted: Whether to stash uncommitted changes

        Returns:
            Stash reference if changes were stashed

        Raises:
            NoCheckpointsError: If no checkpoints exist
        """
        checkpoints = self.list_checkpoints()
        if not checkpoints:
            raise NoCheckpointsError("No checkpoints available")

        latest = sorted(checkpoints, key=lambda c: c["timestamp"], reverse=True)[0]
        return self.rollback_to(latest["tag"], stash_uncommitted)

    def list_checkpoints(self) -> list[dict]:
        """List all paircoder checkpoints.

        Returns:
            List of checkpoint info dicts with tag, commit, timestamp, message
        """
        result = self._run_git("tag", "-l", f"{CHECKPOINT_PREFIX}*")
        tags = result.stdout.strip().split("\n")
        tags = [t for t in tags if t]

        checkpoints = []
        for tag in tags:
            try:
                commit_result = self._run_git("rev-list", "-n", "1", tag)
                commit = commit_result.stdout.strip()[:7]

                msg_result = self._run_git("tag", "-l", "-n1", tag)
                parts = msg_result.stdout.strip().split(None, 1)
                message = parts[1] if len(parts) > 1 else ""

                timestamp_part = tag.replace(CHECKPOINT_PREFIX, "")
                try:
                    dt = datetime.strptime(timestamp_part, "%Y%m%d-%H%M%S-%f")
                    timestamp = dt.strftime("%Y-%m-%d %H:%M:%S.%f")
                except ValueError:
                    try:
                        dt = datetime.strptime(timestamp_part[:15], "%Y%m%d-%H%M%S")
                        timestamp = dt.strftime("%Y-%m-%d %H:%M:%S")
                    except ValueError:
                        timestamp = timestamp_part

                checkpoints.append({
                    "tag": tag,
                    "commit": commit,
                    "timestamp": timestamp,
                    "message": message
                })
            except subprocess.CalledProcessError:
                continue

        return checkpoints

    def preview_rollback(self, checkpoint: str) -> dict:
        """Preview what would be reverted by rolling back.

        Args:
            checkpoint: Tag name of checkpoint

        Returns:
            Dict with files_changed, commits_to_revert

        Raises:
            CheckpointNotFoundError: If checkpoint doesn't exist
        """
        result = self._run_git("tag", "-l", checkpoint, check=False)
        if checkpoint not in result.stdout:
            raise CheckpointNotFoundError(f"Checkpoint '{checkpoint}' not found")

        diff_result = self._run_git(
            "diff", "--name-only", checkpoint, "HEAD",
            check=False
        )
        files = [f for f in diff_result.stdout.strip().split("\n") if f]

        log_result = self._run_git(
            "rev-list", "--count", f"{checkpoint}..HEAD",
            check=False
        )
        try:
            commits = int(log_result.stdout.strip())
        except ValueError:
            commits = 0

        return {
            "tag": checkpoint,
            "files_changed": files,
            "commits_to_revert": commits
        }

    def cleanup_old_checkpoints(self) -> list[str]:
        """Remove old checkpoints beyond max_checkpoints.

        Returns:
            List of removed tag names
        """
        checkpoints = self.list_checkpoints()

        if len(checkpoints) <= self.max_checkpoints:
            return []

        sorted_checkpoints = sorted(checkpoints, key=lambda c: c["timestamp"])
        to_remove = sorted_checkpoints[:-self.max_checkpoints]
        removed = []

        for cp in to_remove:
            try:
                self._run_git("tag", "-d", cp["tag"])
                removed.append(cp["tag"])
            except subprocess.CalledProcessError:
                pass

        return removed
