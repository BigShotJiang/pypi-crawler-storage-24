"""Git checkpoint and rollback functionality.

This module re-exports all public names from the checkpoint sub-modules
for backwards compatibility. Import from here or from the sub-modules directly.
"""

from .checkpoint_models import (
    CheckpointError,
    NotAGitRepoError,
    CheckpointNotFoundError,
    NoCheckpointsError,
    CheckpointInfo,
    CHECKPOINT_PREFIX,
    CONTAINMENT_CHECKPOINT_PREFIX,
)
from .checkpoint_rollback import GitCheckpointRollback
from .checkpoint_containment import ContainmentCheckpointMixin
from .checkpoint_format import format_checkpoint_list, format_rollback_preview


class GitCheckpoint(ContainmentCheckpointMixin, GitCheckpointRollback):
    """Full checkpoint manager combining standard and containment operations."""
    pass


__all__ = [
    "GitCheckpoint",
    "CheckpointError",
    "NotAGitRepoError",
    "CheckpointNotFoundError",
    "NoCheckpointsError",
    "CheckpointInfo",
    "CHECKPOINT_PREFIX",
    "CONTAINMENT_CHECKPOINT_PREFIX",
    "format_checkpoint_list",
    "format_rollback_preview",
]
