"""Fast containment access checker for PreToolUse hooks.

Lightweight checker that determines if a file operation is allowed
based on the containment config tiers (blocked/readonly/readwrite).
Designed for <1ms per check using in-memory path matching.
"""

from __future__ import annotations

import fnmatch
import json
import logging
import os
import stat
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class AccessResult:
    """Result of a containment access check."""

    allowed: bool
    tier: str  # "blocked", "readonly", "readwrite"
    path: str
    operation: str  # "read" or "write"
    reason: str | None = None


class ContainmentChecker:
    """Fast in-memory containment tier checker.

    Builds path sets once at init, then checks in O(n) where n is
    the number of configured paths (typically <20).
    """

    def __init__(self, project_root: Path, config: dict | None) -> None:
        self._root = Path(project_root)
        self._enabled = False
        self._blocked_exact: set[str] = set()
        self._blocked_globs: list[str] = []
        self._blocked_dirs: list[str] = []
        self._readonly_dirs: list[str] = []
        self._readonly_files: set[str] = set()
        if config and config.get("enabled", False):
            self._enabled = True
            for pat in config.get("blocked_files", []):
                if "*" in pat or "?" in pat:
                    self._blocked_globs.append(pat)
                else:
                    self._blocked_exact.add(pat)
            self._blocked_dirs = list(config.get("blocked_directories", []))
            self._readonly_dirs = list(config.get("readonly_directories", []))
            self._readonly_files = set(config.get("readonly_files", []))

    def check_access(self, path: Path, operation: str) -> AccessResult:
        """Check if an operation is allowed on a path."""
        if operation not in {"read", "write"}:
            operation = "write"  # safe default for unknown operations
        if not self._enabled:
            return AccessResult(True, "readwrite", str(path), operation)
        rel = self._relative_path(path)
        if rel is None:
            return AccessResult(
                False, "blocked", str(path), operation,
                "Path is outside project root; blocked in containment mode",
            )
        if self._is_blocked(rel):
            return AccessResult(
                False, "blocked", str(path), operation,
                f"Path '{rel}' is in blocked tier",
            )
        if operation == "write" and self._is_readonly(rel):
            return AccessResult(
                False, "readonly", str(path), operation,
                f"Path '{rel}' is read-only",
            )
        return AccessResult(True, "readwrite", str(path), operation)

    def _relative_path(self, path: Path) -> str | None:
        """Get resolved path relative to project root. Returns None if outside.

        Both path and root are resolved to prevent symlink escape and
        directory traversal via '..' segments.
        """
        try:
            resolved = Path(path).resolve()
            root_resolved = self._root.resolve()
            return str(resolved.relative_to(root_resolved))
        except (ValueError, OSError):
            return None

    def _is_blocked(self, rel_path: str) -> bool:
        """Check if relative path matches any blocked file or directory."""
        name = Path(rel_path).name
        if name in self._blocked_exact or rel_path in self._blocked_exact:
            return True
        for pat in self._blocked_globs:
            if fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(rel_path, pat):
                return True
        normalized = rel_path.replace("\\", "/")
        for bd in self._blocked_dirs:
            bd_norm = bd.replace("\\", "/")
            if normalized.startswith(bd_norm + "/") or normalized == bd_norm:
                return True
        return False

    def _is_readonly(self, rel_path: str) -> bool:
        """Check if relative path is a read-only file or under a read-only dir."""
        normalized = rel_path.replace("\\", "/")
        if normalized in self._readonly_files or Path(rel_path).name in self._readonly_files:
            return True
        for ro_dir in self._readonly_dirs:
            ro_normalized = ro_dir.replace("\\", "/")
            if normalized.startswith(ro_normalized + "/") or normalized == ro_normalized:
                return True
        return False


def log_rejection(log_path: Path, result: AccessResult) -> None:
    """Append rejection to bypass_log.jsonl. No-op if allowed."""
    if result.allowed:
        return
    log_path.parent.mkdir(parents=True, exist_ok=True)
    created = not log_path.exists()
    def _sanitize(val: str | None) -> str:
        if val is None:
            return ""
        return val.replace("\n", "\\n").replace("\r", "\\r")

    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "type": "containment_rejection",
        "path": _sanitize(result.path),
        "operation": _sanitize(result.operation),
        "tier": _sanitize(result.tier),
        "reason": _sanitize(result.reason),
    }
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
    if created and os.name != "nt":
        log_path.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    logger.info("Containment rejection logged: %s %s", result.operation, result.path)
