"""Secret detection for PairCoder.

This module re-exports all public names from the secrets sub-modules
for backwards compatibility. Import from here or from the sub-modules directly.
"""

from .secrets_types import SecretType, SecretMatch, AllowlistConfig
from .secrets_patterns import SECRET_PATTERNS, IGNORE_PATTERNS
from .secrets_scanner import SecretScanner
from .secrets_format import format_scan_results

__all__ = [
    "SecretType",
    "SecretMatch",
    "AllowlistConfig",
    "SECRET_PATTERNS",
    "IGNORE_PATTERNS",
    "SecretScanner",
    "format_scan_results",
]
