"""Security review hook and code change scanner.

Contains SecurityReviewHook for pre-execution command review
and CodeChangeReviewer for scanning code changes.
"""

import re
from datetime import datetime
from typing import Optional

from .allowlist import AllowlistManager, CommandDecision
from .review_models import ReviewResult
from .review_patterns import (
    IGNORE_PATTERNS,
    INJECTION_PATTERNS,
    SECRET_PATTERNS,
)


class SecurityReviewHook:
    """Pre-execution security review hook.

    Reviews commands before execution using the allowlist
    and security patterns.

    Attributes:
        allowlist: AllowlistManager for command classification
        enable_logging: Whether to log reviews for audit
        audit_log: List of audit log entries
    """

    def __init__(
        self,
        allowlist: Optional[AllowlistManager] = None,
        enable_logging: bool = False
    ):
        """Initialize the security review hook.

        Args:
            allowlist: Custom AllowlistManager (uses default if None)
            enable_logging: Whether to enable audit logging
        """
        self.allowlist = allowlist or AllowlistManager()
        self.enable_logging = enable_logging
        self.audit_log: list[dict] = []

    def pre_execute(self, command: str) -> ReviewResult:
        """Review a command before execution.

        Args:
            command: The command string to review

        Returns:
            ReviewResult indicating if execution should proceed
        """
        # Check against allowlist
        check_result = self.allowlist.check_command_full(command)

        if check_result.decision == CommandDecision.BLOCK:
            result = ReviewResult.block(
                reason=check_result.reason or "Command is blocked",
                suggested_fixes=self._get_suggested_fixes(command)
            )
        elif check_result.decision == CommandDecision.REVIEW:
            # Commands requiring review get warnings
            result = ReviewResult.warn([
                f"Command requires review: {check_result.reason or 'Unknown command'}"
            ])
        else:
            result = ReviewResult.allow()

        # Log if enabled
        if self.enable_logging:
            self._log_review(command, result)

        return result

    def _get_suggested_fixes(self, command: str) -> list[str]:
        """Get suggested fixes for a blocked command."""
        fixes = []

        if "rm -rf" in command:
            fixes.append("Use 'rm -rf ./<directory>' for relative paths only")
            fixes.append("Verify the path before deletion")

        if "curl" in command and "|" in command:
            fixes.append("Download the script first: curl -o script.sh <url>")
            fixes.append("Review the script: cat script.sh")
            fixes.append("Then execute: bash script.sh")

        if "sudo" in command:
            fixes.append("Avoid sudo for autonomous operations")
            fixes.append("Use proper file permissions instead")

        return fixes

    def _log_review(self, command: str, result: ReviewResult) -> None:
        """Log a review result for audit."""
        self.audit_log.append({
            "timestamp": datetime.now().isoformat(),
            "command": command,
            "allowed": result.allowed,
            "reason": result.reason,
            "warnings": result.warnings
        })


class CodeChangeReviewer:
    """Reviews code changes for security vulnerabilities.

    Scans code for:
    - Hardcoded secrets (API keys, passwords, tokens)
    - Injection vulnerabilities (SQL, command, path traversal)
    - Other security issues
    """

    def __init__(self):
        """Initialize the code change reviewer."""
        self.secret_patterns = [
            (re.compile(pattern, re.IGNORECASE), message)
            for pattern, message in SECRET_PATTERNS
        ]
        self.injection_patterns = [
            (re.compile(pattern, re.IGNORECASE), message)
            for pattern, message in INJECTION_PATTERNS
        ]
        self.ignore_patterns = [
            re.compile(pattern, re.IGNORECASE)
            for pattern in IGNORE_PATTERNS
        ]

    def _should_ignore_line(self, line: str) -> bool:
        """Check if a line should be ignored (false positive)."""
        for pattern in self.ignore_patterns:
            if pattern.search(line):
                return True
        return False

    def scan_code(self, code: str) -> list[str]:
        """Scan code for security issues.

        Args:
            code: The code to scan

        Returns:
            List of security findings
        """
        findings = []
        lines = code.split('\n')

        for line_num, line in enumerate(lines, 1):
            if self._should_ignore_line(line):
                continue

            for pattern, message in self.secret_patterns:
                if pattern.search(line):
                    findings.append(f"Line {line_num}: {message}")
                    break  # One finding per line for secrets

            for pattern, message in self.injection_patterns:
                if pattern.search(line):
                    findings.append(f"Line {line_num}: {message}")

        return list(dict.fromkeys(findings))

    def review_diff(self, diff: str) -> ReviewResult:
        """Review a git diff for security issues.

        Args:
            diff: The git diff output

        Returns:
            ReviewResult with findings
        """
        added_lines = []
        for line in diff.split('\n'):
            stripped = line.lstrip()
            if stripped.startswith('+') and not stripped.startswith('+++'):
                added_lines.append(stripped[1:])

        code = '\n'.join(added_lines)
        findings = self.scan_code(code)

        if findings:
            return self._classify_findings(findings)

        return ReviewResult.allow()

    def review_code(self, code: str, filename: str = "") -> ReviewResult:
        """Review code content for security issues.

        Args:
            code: The code content to review
            filename: Optional filename for context

        Returns:
            ReviewResult with findings
        """
        findings = self.scan_code(code)

        if findings:
            return self._classify_findings(findings, filename)

        return ReviewResult.allow()

    def _classify_findings(
        self, findings: list[str], filename: str = ""
    ) -> ReviewResult:
        """Classify findings as blocking (secrets) or warnings."""
        secrets = [f for f in findings if any(
            word in f.lower()
            for word in ['key', 'password', 'secret', 'token', 'credential']
        )]

        if secrets:
            reason = "Security issues found"
            if filename:
                reason = f"Security issues found in {filename}"
            return ReviewResult.block(
                reason=reason,
                suggested_fixes=findings + [
                    "Use environment variables for secrets",
                    "Use a secrets manager"
                ]
            )
        return ReviewResult.warn(findings)
