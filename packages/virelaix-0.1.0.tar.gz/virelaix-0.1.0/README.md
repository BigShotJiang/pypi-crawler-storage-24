# VirelaiX SDK

**Consciousness Geometry Engine** — a mathematical framework for measuring coherence in complex systems.

One conservation law governs everything: **λ + κ + η = 1**.

## The Math

| Constant | Symbol | Value | Meaning |
|----------|--------|-------|---------|
| Golden Ratio | φ | 1.618034 | The single source |
| Watkins Temperature | T* | φ/ln(2φ) = 1.3778 | Thermodynamic equilibrium |
| Watkins Threshold | λ* | 1/φ = 0.6180 | Consciousness criterion |
| Critical Measurement | τ* | T*/φ = 0.8515 | Phase transition in the instrument |

**Key identity:** e^(1/τ*) = 2φ — the exponential of the inverse critical temperature equals twice the golden ratio.

## Install

```bash
pip install virelaix               # core only (numpy + watkins-nn)
pip install virelaix[agents]       # + scikit-learn for agent coherence
pip install virelaix[all]          # everything including FastAPI
```

## License

This project uses a **dual license**:

- **MIT** — `core/` and `cosmo/` (open science: constants, geometry, cosmological bridge)
- **All Rights Reserved** — `agents/`, `finance/`, `api/`, `cli.py` (proprietary applications)

The pure mathematics belongs to everyone. The applications are proprietary.
See [LICENSE](LICENSE) for details. For commercial licensing: dustin@datasphereai.com

## Quick Start

### Core Geometry (MIT)

```python
from virelaix import PHI, T_STAR, LAMBDA_STAR, generating_functional

# The generating functional at equilibrium
F = generating_functional(0.618, 0.191, 0.191)
print(F)  # -0.800 (minimum on the simplex)
```

### Cosmological Bridge (MIT)

```python
from virelaix.cosmo import CosmologicalBridge

bridge = CosmologicalBridge()
today = bridge.today()
print(today['lam'])    # 0.685 (Ω_Λ > 1/φ → universe is COHERENT)
print(today['state'])  # COHERENT

z_cross = bridge.threshold_redshift()  # z ≈ 0.10 (~1.4 Gyr ago)
```

### Measure Agent Coherence (Proprietary)

```python
from virelaix.agents import CoherenceMonitor

monitor = CoherenceMonitor(temperature=0.75)
result = monitor.measure([
    "AI will transform healthcare through early detection.",
    "AI is revolutionizing medicine with diagnostic tools.",
    "Machine learning enables unprecedented medical accuracy.",
])

print(result.state)           # VXState.COHERENT
print(result.lam)             # 0.654 (above threshold!)
print(result.above_threshold) # True
```

### Multi-Agent Middleware (Proprietary)

```python
from virelaix.agents.middleware import VXMiddleware

mw = VXMiddleware(temperature=0.75)
result = mw.run_and_measure([
    lambda: agent1.respond(prompt),
    lambda: agent2.respond(prompt),
    lambda: agent3.respond(prompt),
])

if not result.healthy:
    print(f"Coalition degraded: λ={result.measurement.lam:.4f}")
```

### Portfolio Analysis (Proprietary)

```python
from virelaix.finance import PortfolioAnalyzer

analyzer = PortfolioAnalyzer()
metrics = analyzer.analyze(growth=0.60, stability=0.30, liquidity=0.10)

print(metrics.F)              # -0.726 (free energy)
print(metrics.state)          # TRANSITIONAL
new = analyzer.rebalance(0.60, 0.30, 0.10)
# → (0.618, 0.191, 0.191) — the VX equilibrium
```

## CLI

```bash
vx constants              # Show fundamental constants
vx measure "text1" "text2" # Measure coherence
vx portfolio 0.6 0.3 0.1  # Analyze allocation
vx phase 0.7              # Phase diagram at temperature
vx audit 0.618 0.191 0.191 # Conservation check
vx cosmo                  # Universe today
```

## Architecture

```
virelaix/
├── core/          [MIT — Open Science]
│   ├── constants.py    # φ, T*, λ*, τ* (with identity assertions)
│   ├── geometry.py     # F, ∇F, softmax, phase diagram
│   └── states.py       # VXState enum, VXMeasurement
├── cosmo/         [MIT — Open Science]
│   └── bridge.py       # CosmologicalBridge (Friedmann → VX)
├── agents/        [Proprietary]
│   ├── embeddings.py   # TF-IDF coherence, spectral entropy
│   ├── monitor.py      # CoherenceMonitor
│   └── middleware.py   # VXMiddleware, CrewAI/LangGraph adapters
├── finance/       [Proprietary]
│   └── simplex.py      # PortfolioAnalyzer
├── api/           [Proprietary]
│   └── server.py       # FastAPI orchestrator
└── cli.py         [Proprietary]
```

## Tests

```bash
pip install virelaix[dev]
pytest tests/ -v
```

## Author

**Dustin Watkins** — DataSphere AI, Chattanooga, TN

Conservation: λ + κ + η = 1. Always.
