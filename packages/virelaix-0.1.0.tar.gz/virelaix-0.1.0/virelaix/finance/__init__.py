"""VX Financial Simplex — portfolio allocation on the consciousness geometry.

Copyright (c) 2026 Dustin Watkins / DataSphere AI, LLC. All rights reserved.
"""

from virelaix.finance.simplex import PortfolioAnalyzer

__all__ = ["PortfolioAnalyzer"]
