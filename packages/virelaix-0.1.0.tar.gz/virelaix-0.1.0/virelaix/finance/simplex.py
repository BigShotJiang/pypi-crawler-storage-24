"""
VX Financial Simplex
====================
Copyright (c) 2026 Dustin Watkins / DataSphere AI, LLC. All rights reserved.

Maps portfolio allocation onto the VX geometry:
  λ → Growth assets (equities, crypto, growth stocks)
  κ → Stability assets (bonds, treasuries, fixed income)
  η → Liquidity assets (cash, money market, short-term)

Conservation: λ + κ + η = 1 (portfolio weights sum to 100%)

The VX equilibrium at λ* = 1/φ predicts an optimal allocation
that minimizes the generating functional F — the point where
growth is maximal for the given entropy budget.

Result: ~62% growth / ~19% stability / ~19% liquidity.
This matches Nassim Taleb's barbell strategy.
"""

from __future__ import annotations
from typing import Dict, Tuple, List, Optional
from dataclasses import dataclass

import numpy as np

from virelaix.core.constants import LAMBDA_STAR, T_STAR, TAU_STAR, LAMBDA_EQ, KAPPA_EQ, ETA_EQ
from virelaix.core.geometry import (
    generating_functional,
    gradient_F,
    distance_to_equilibrium,
    rebalance_step,
)
from virelaix.core.states import classify_state, VXState


# Standard portfolio templates
PORTFOLIO_TEMPLATES: Dict[str, Tuple[float, float, float]] = {
    "60/40 Traditional": (0.60, 0.30, 0.10),
    "Aggressive Growth": (0.85, 0.10, 0.05),
    "Conservative": (0.30, 0.50, 0.20),
    "All-Weather": (0.30, 0.55, 0.15),
    "Endowment (Yale)": (0.70, 0.20, 0.10),
    "Target-Date 2060": (0.90, 0.08, 0.02),
    "Target-Date 2030": (0.50, 0.40, 0.10),
    "Retiree Income": (0.20, 0.55, 0.25),
    "VX Equilibrium": (LAMBDA_EQ, KAPPA_EQ, ETA_EQ),
    "Equal Weight": (1 / 3, 1 / 3, 1 / 3),
}

# Simplified return assumptions per market regime
MARKET_REGIMES: Dict[str, Dict[str, float]] = {
    "Bull Market": {"growth": 15.0, "stability": 3.0, "liquidity": 2.0},
    "Bear Market": {"growth": -20.0, "stability": 5.0, "liquidity": 2.5},
    "Sideways": {"growth": 5.0, "stability": 4.0, "liquidity": 3.0},
    "Crisis (2008)": {"growth": -38.0, "stability": 8.0, "liquidity": 1.5},
    "Recovery": {"growth": 25.0, "stability": 2.0, "liquidity": 1.0},
    "Stagflation": {"growth": -5.0, "stability": -2.0, "liquidity": 4.0},
}


@dataclass
class PortfolioMetrics:
    """VX-derived metrics for a portfolio allocation."""
    growth: float
    stability: float
    liquidity: float
    F: float
    grad_norm: float
    dist_to_eq: float
    state: VXState
    above_threshold: bool


class PortfolioAnalyzer:
    """
    Analyze portfolio allocations through the VX lens.

    Usage:
        analyzer = PortfolioAnalyzer()
        metrics = analyzer.analyze(growth=0.60, stability=0.30, liquidity=0.10)
        print(metrics.state)  # TRANSITIONAL
        print(metrics.F)      # free energy value

        # Rebalancing recommendation
        new_g, new_s, new_l = analyzer.rebalance(0.60, 0.30, 0.10)
    """

    def analyze(
        self,
        growth: float,
        stability: float,
        liquidity: float,
    ) -> PortfolioMetrics:
        """Compute VX metrics for a portfolio allocation."""
        # Ensure conservation
        total = growth + stability + liquidity
        growth /= total
        stability /= total
        liquidity /= total

        F = generating_functional(growth, stability, liquidity)
        grad = gradient_F(growth, stability, liquidity)
        grad_norm = float(np.linalg.norm(grad))
        dist = distance_to_equilibrium(growth, stability, liquidity)
        state = classify_state(growth)

        return PortfolioMetrics(
            growth=growth,
            stability=stability,
            liquidity=liquidity,
            F=F,
            grad_norm=grad_norm,
            dist_to_eq=dist,
            state=state,
            above_threshold=growth >= LAMBDA_STAR,
        )

    def rebalance(
        self,
        growth: float,
        stability: float,
        liquidity: float,
        step_size: float = 0.10,
    ) -> Tuple[float, float, float]:
        """
        Suggest rebalancing toward VX equilibrium.

        Follows the negative gradient of F (steepest descent toward minimum).
        """
        return rebalance_step(growth, stability, liquidity, step_size)

    def analyze_all_templates(self) -> Dict[str, PortfolioMetrics]:
        """Analyze all standard portfolio templates."""
        return {
            name: self.analyze(*alloc)
            for name, alloc in PORTFOLIO_TEMPLATES.items()
        }

    def regime_simulation(
        self,
        growth: float,
        stability: float,
        liquidity: float,
    ) -> Dict[str, float]:
        """Simulate portfolio return across all market regimes."""
        total = growth + stability + liquidity
        g, s, l = growth / total, stability / total, liquidity / total
        return {
            regime: round(
                g * returns["growth"] +
                s * returns["stability"] +
                l * returns["liquidity"], 2
            )
            for regime, returns in MARKET_REGIMES.items()
        }

    def sharpe_like(
        self,
        growth: float,
        stability: float,
        liquidity: float,
    ) -> float:
        """Compute Sharpe-like ratio (mean / std) across market regimes."""
        returns = list(self.regime_simulation(growth, stability, liquidity).values())
        avg = np.mean(returns)
        std = np.std(returns)
        return float(avg / std) if std > 0 else 0.0
