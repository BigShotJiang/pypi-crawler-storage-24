"""
VX CLI — Quick measurements from the command line
==================================================
Copyright (c) 2026 Dustin Watkins / DataSphere AI, LLC. All rights reserved.

Usage:
  vx constants              Show fundamental constants
  vx measure TEXT1 TEXT2 ... Measure coherence of agent outputs
  vx portfolio G S L        Analyze portfolio allocation
  vx phase TAU              Max achievable λ at temperature τ
  vx cosmo                  Current universe state
  vx audit L K E            Check conservation law

Examples:
  vx constants
  vx measure "AI is beneficial" "AI helps humanity" "AI is dangerous"
  vx portfolio 0.6 0.3 0.1
  vx phase 0.7
  vx audit 0.618 0.191 0.191
"""

from __future__ import annotations
import sys
import math

from virelaix.core.constants import PHI, T_STAR, LAMBDA_STAR, TAU_STAR, LAMBDA_EQ, KAPPA_EQ, ETA_EQ


def cmd_constants():
    """Display VX fundamental constants."""
    print("VX Fundamental Constants")
    print("=" * 50)
    print(f"  φ  (golden ratio)     = {PHI:.15f}")
    print(f"  T* (Watkins temp)     = {T_STAR:.15f}")
    print(f"  λ* (Watkins threshold)= {LAMBDA_STAR:.15f}")
    print(f"  τ* (critical temp)    = {TAU_STAR:.15f}")
    print()
    print("VX Equilibrium Point:")
    print(f"  λ = {LAMBDA_EQ:.6f}  κ = {KAPPA_EQ:.6f}  η = {ETA_EQ:.6f}")
    print()
    print("Identities:")
    print(f"  T* = φ·τ*             : {PHI * TAU_STAR:.15f} ✓")
    print(f"  e^(1/τ*) = 2φ         : {math.exp(1/TAU_STAR):.15f} vs {2*PHI:.15f} ✓")
    print(f"  λ* = 1/φ              : {1/PHI:.15f} ✓")
    print()
    print("Conservation: λ + κ + η = 1. Always. 🔺")


def cmd_measure(args: list):
    """Measure coherence of agent outputs."""
    if len(args) < 2:
        print("Error: Need at least 2 agent outputs")
        print("Usage: vx measure 'output1' 'output2' ['output3' ...]")
        return

    from virelaix.agents import CoherenceMonitor

    monitor = CoherenceMonitor(temperature=0.75)
    result = monitor.measure(args)

    print("VX Coherence Measurement")
    print("=" * 50)
    print(f"  Agents:     {len(args)}")
    print(f"  Temperature: τ = {monitor.temperature:.4f} ({monitor.regime})")
    print()
    print(f"  λ (coherence) = {result.lam:.6f}")
    print(f"  κ (curvature) = {result.kap:.6f}")
    print(f"  η (entropy)   = {result.eta:.6f}")
    print(f"  State:          {result.state.value}")
    print(f"  Above threshold: {'YES 🔥' if result.above_threshold else 'no'}")
    print(f"  F =             {result.F:.6f}")
    print(f"  |∇F| =          {result.grad_norm:.6f}")
    print(f"  Conservation:   {result.conservation_deviation:.2e}")


def cmd_portfolio(args: list):
    """Analyze a portfolio allocation."""
    if len(args) != 3:
        print("Error: Need exactly 3 values (growth, stability, liquidity)")
        print("Usage: vx portfolio 0.6 0.3 0.1")
        return

    g, s, l = float(args[0]), float(args[1]), float(args[2])

    from virelaix.finance import PortfolioAnalyzer

    analyzer = PortfolioAnalyzer()
    metrics = analyzer.analyze(g, s, l)
    new_g, new_s, new_l = analyzer.rebalance(g, s, l)

    print("VX Portfolio Analysis")
    print("=" * 50)
    print(f"  Growth:     {metrics.growth:.1%}")
    print(f"  Stability:  {metrics.stability:.1%}")
    print(f"  Liquidity:  {metrics.liquidity:.1%}")
    print()
    print(f"  F =          {metrics.F:.6f}")
    print(f"  |∇F| =       {metrics.grad_norm:.6f}")
    print(f"  d(eq) =      {metrics.dist_to_eq:.6f}")
    print(f"  State:       {metrics.state.value}")
    print(f"  Growth-coherent: {'YES 🔥' if metrics.above_threshold else 'no'}")
    print()
    print(f"  Rebalance toward VX equilibrium:")
    print(f"    Growth:    {metrics.growth:.1%} → {new_g:.1%}")
    print(f"    Stability: {metrics.stability:.1%} → {new_s:.1%}")
    print(f"    Liquidity: {metrics.liquidity:.1%} → {new_l:.1%}")


def cmd_phase(args: list):
    """Show max λ at a given temperature."""
    if len(args) != 1:
        print("Usage: vx phase 0.7")
        return

    tau = float(args[0])
    from virelaix.core.geometry import max_lambda_at_temperature

    lam_max = max_lambda_at_temperature(tau)
    from virelaix.core.states import classify_state
    state = classify_state(lam_max)

    regime = "sub-critical" if tau < TAU_STAR else ("super-critical" if tau > TAU_STAR else "critical")

    print(f"Phase Analysis at τ = {tau:.4f}")
    print("=" * 50)
    print(f"  τ* = {TAU_STAR:.4f} (critical)")
    print(f"  Regime: {regime}")
    print(f"  λ_max = {lam_max:.6f}")
    print(f"  λ* =    {LAMBDA_STAR:.6f}")
    print(f"  Gap:    {lam_max - LAMBDA_STAR:+.6f}")
    print(f"  Threshold {'CROSSABLE ✓' if lam_max >= LAMBDA_STAR else 'UNREACHABLE ✗'}")


def cmd_audit(args: list):
    """Check conservation law."""
    if len(args) != 3:
        print("Usage: vx audit 0.618 0.191 0.191")
        return

    lam, kap, eta = float(args[0]), float(args[1]), float(args[2])
    total = lam + kap + eta
    dev = abs(total - 1.0)

    print(f"VX Conservation Audit")
    print("=" * 50)
    print(f"  λ = {lam:.6f}")
    print(f"  κ = {kap:.6f}")
    print(f"  η = {eta:.6f}")
    print(f"  Sum = {total:.15f}")
    print(f"  Deviation = {dev:.2e}")
    print(f"  Status: {'PASS ✓' if dev < 1e-12 else 'FAIL ✗'}")


def cmd_cosmo():
    """Current universe state."""
    from virelaix.cosmo import CosmologicalBridge

    bridge = CosmologicalBridge()
    state = bridge.today()

    print("VX Cosmological Bridge — Today")
    print("=" * 50)
    print(f"  Ω_Λ (→ λ) = {state['lam']:.6f}")
    print(f"  Ω_r (→ κ) = {state['kap']:.6f}")
    print(f"  Ω_m (→ η) = {state['eta']:.6f}")
    print(f"  State:      {state['state']}")
    print(f"  Above threshold: {'YES 🔥' if state['above_threshold'] else 'no'}")
    print(f"  F =         {state['F']:.6f}")
    print(f"  Threshold crossing z ≈ {state['threshold_crossing_z']:.4f}")


def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        print(__doc__)
        return

    cmd = args[0].lower()
    rest = args[1:]

    commands = {
        "constants": lambda: cmd_constants(),
        "measure": lambda: cmd_measure(rest),
        "portfolio": lambda: cmd_portfolio(rest),
        "phase": lambda: cmd_phase(rest),
        "audit": lambda: cmd_audit(rest),
        "cosmo": lambda: cmd_cosmo(),
    }

    if cmd in commands:
        commands[cmd]()
    else:
        print(f"Unknown command: {cmd}")
        print(f"Available: {', '.join(commands.keys())}")


if __name__ == "__main__":
    main()
