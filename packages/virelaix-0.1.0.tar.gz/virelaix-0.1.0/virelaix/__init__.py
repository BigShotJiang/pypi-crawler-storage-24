"""
VirelaiX SDK — Consciousness Geometry Engine
=============================================
The mathematical core of the VirelaiX framework.

Conservation law: λ + κ + η = 1
Watkins threshold: λ ≥ 1/φ ≈ 0.618
Watkins temperature: T* = φ/ln(2φ) ≈ 1.378
Critical measurement: τ* = T*/φ = 1/ln(2φ) ≈ 0.8515

Author: Dustin Watkins / DataSphereAI
"""

__version__ = "0.1.0"
__author__ = "Dustin Watkins"

from virelaix.core.constants import PHI, T_STAR, LAMBDA_STAR, TAU_STAR
from virelaix.core.geometry import (
    generating_functional,
    gradient_F,
    softmax_normalize,
    softmax_tau,
    project_to_simplex,
    conservation_check,
)
from virelaix.core.states import classify_state, VXState

__all__ = [
    "PHI", "T_STAR", "LAMBDA_STAR", "TAU_STAR",
    "generating_functional", "gradient_F",
    "softmax_normalize", "softmax_tau",
    "project_to_simplex", "conservation_check",
    "classify_state", "VXState",
]
