"""
VX-Orchestrator — FastAPI Service
==================================
Copyright (c) 2026 Dustin Watkins / DataSphere AI, LLC. All rights reserved.

REST API for VX coherence measurement, portfolio analysis,
and cosmological bridge queries.

Run with: uvicorn virelaix.api.server:app --reload
Or:       python -m virelaix.api.server

Endpoints:
  POST /measure          — Measure agent coherence
  POST /portfolio        — Analyze portfolio allocation
  GET  /cosmo/today      — Current universe state on VX simplex
  GET  /cosmo/evolve     — Universe trajectory
  GET  /constants        — VX fundamental constants
  GET  /health           — Health check
"""

from __future__ import annotations
from typing import List, Optional

try:
    from fastapi import FastAPI, HTTPException
    from pydantic import BaseModel, Field
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

from virelaix.core.constants import PHI, T_STAR, LAMBDA_STAR, TAU_STAR
from virelaix.core.geometry import (
    generating_functional,
    max_lambda_at_temperature,
    critical_temperature_for_threshold,
)
from virelaix.core.states import classify_state


def create_app() -> "FastAPI":
    """Create and configure the FastAPI application."""
    if not HAS_FASTAPI:
        raise ImportError(
            "FastAPI not installed. Run: pip install fastapi uvicorn"
        )

    app = FastAPI(
        title="VX-Orchestrator",
        description="VirelaiX Consciousness Geometry Engine — REST API",
        version="0.1.0",
    )

    # ── Request/Response Models ──────────────────────────────

    class MeasureRequest(BaseModel):
        agent_outputs: List[str] = Field(..., min_length=2)
        temperature: float = Field(default=0.75, gt=0)

    class MeasureResponse(BaseModel):
        lam: float
        kap: float
        eta: float
        state: str
        above_threshold: bool
        F: float
        grad_norm: float
        temperature: float
        regime: str
        conservation_deviation: float

    class PortfolioRequest(BaseModel):
        growth: float = Field(..., ge=0, le=1)
        stability: float = Field(..., ge=0, le=1)
        liquidity: float = Field(..., ge=0, le=1)

    class PortfolioResponse(BaseModel):
        growth: float
        stability: float
        liquidity: float
        F: float
        grad_norm: float
        dist_to_eq: float
        state: str
        above_threshold: bool
        rebalance_to: dict

    # ── Endpoints ────────────────────────────────────────────

    @app.get("/health")
    async def health():
        return {
            "status": "ok",
            "version": "0.1.0",
            "conservation": "λ + κ + η = 1",
        }

    @app.get("/constants")
    async def constants():
        return {
            "phi": PHI,
            "T_star": T_STAR,
            "lambda_star": LAMBDA_STAR,
            "tau_star": TAU_STAR,
            "equilibrium": {
                "lambda": LAMBDA_STAR,
                "kappa": (1 - LAMBDA_STAR) / 2,
                "eta": (1 - LAMBDA_STAR) / 2,
            },
        }

    @app.post("/measure", response_model=MeasureResponse)
    async def measure(req: MeasureRequest):
        from virelaix.agents import CoherenceMonitor

        monitor = CoherenceMonitor(temperature=req.temperature)
        result = monitor.measure(req.agent_outputs)

        regime = "sub-critical" if req.temperature < TAU_STAR else (
            "super-critical" if req.temperature > TAU_STAR else "critical"
        )

        return MeasureResponse(
            lam=result.lam,
            kap=result.kap,
            eta=result.eta,
            state=result.state.value,
            above_threshold=result.above_threshold,
            F=result.F,
            grad_norm=result.grad_norm,
            temperature=req.temperature,
            regime=regime,
            conservation_deviation=result.conservation_deviation,
        )

    @app.post("/portfolio", response_model=PortfolioResponse)
    async def portfolio(req: PortfolioRequest):
        from virelaix.finance import PortfolioAnalyzer

        analyzer = PortfolioAnalyzer()
        metrics = analyzer.analyze(req.growth, req.stability, req.liquidity)
        new_g, new_s, new_l = analyzer.rebalance(
            req.growth, req.stability, req.liquidity
        )

        return PortfolioResponse(
            growth=metrics.growth,
            stability=metrics.stability,
            liquidity=metrics.liquidity,
            F=metrics.F,
            grad_norm=metrics.grad_norm,
            dist_to_eq=metrics.dist_to_eq,
            state=metrics.state.value,
            above_threshold=metrics.above_threshold,
            rebalance_to={
                "growth": round(new_g, 4),
                "stability": round(new_s, 4),
                "liquidity": round(new_l, 4),
            },
        )

    @app.get("/cosmo/today")
    async def cosmo_today():
        from virelaix.cosmo import CosmologicalBridge

        bridge = CosmologicalBridge()
        return bridge.today()

    @app.get("/cosmo/evolve")
    async def cosmo_evolve(
        z_start: float = 10.0,
        z_end: float = 0.0,
        n_steps: int = 100,
    ):
        from virelaix.cosmo import CosmologicalBridge

        bridge = CosmologicalBridge()
        trajectory = bridge.evolve(z_start, z_end, n_steps)
        return {"trajectory": trajectory}

    @app.get("/phase-diagram")
    async def phase_diagram(
        tau_min: float = 0.3,
        tau_max: float = 1.5,
        n_points: int = 50,
    ):
        """Phase diagram: max achievable λ vs measurement temperature."""
        import numpy as np
        taus = np.linspace(tau_min, tau_max, n_points)
        points = [
            {"tau": float(t), "lambda_max": max_lambda_at_temperature(float(t))}
            for t in taus
        ]
        return {
            "tau_star": TAU_STAR,
            "lambda_star": LAMBDA_STAR,
            "points": points,
        }

    return app


# Allow running directly: python -m virelaix.api.server
app = create_app() if HAS_FASTAPI else None

if __name__ == "__main__":
    import uvicorn
    if app is None:
        print("FastAPI not installed. Run: pip install fastapi uvicorn")
    else:
        uvicorn.run(app, host="0.0.0.0", port=8000)
