"""VX Cosmological Bridge — mapping Friedmann cosmology onto the VX simplex."""

from virelaix.cosmo.bridge import CosmologicalBridge

__all__ = ["CosmologicalBridge"]
