"""
VX Coherence Monitor
====================
Copyright (c) 2026 Dustin Watkins / DataSphere AI, LLC. All rights reserved.

The primary interface for measuring coherence in multi-agent AI systems.

Usage:
    from virelaix.agents import CoherenceMonitor

    monitor = CoherenceMonitor(temperature=0.7)
    result = monitor.measure(["Agent 1 output", "Agent 2 output", "Agent 3 output"])
    print(result.state)        # VXState.COHERENT
    print(result.lam)          # 0.672
    print(result.above_threshold)  # True
"""

from __future__ import annotations
from typing import List, Optional
from dataclasses import dataclass

import numpy as np

from virelaix.core.constants import TAU_STAR, LAMBDA_STAR
from virelaix.core.geometry import (
    softmax_tau,
    generating_functional,
    gradient_F,
    conservation_check,
)
from virelaix.core.states import classify_state, VXState, VXMeasurement
from virelaix.agents.embeddings import (
    tfidf_coherence,
    spectral_entropy,
    curvature_from_similarities,
)


class CoherenceMonitor:
    """
    Measures coherence of multi-agent AI system outputs.

    The monitor maps raw text outputs from N agents onto the VX simplex Δ²,
    producing a measurement (λ, κ, η) where:
      λ = coherence (agreement between agents)
      κ = curvature (geometric spread of agreement patterns)
      η = entropy (effective dimensionality of agent divergence)

    The softmax temperature τ controls measurement sensitivity:
      τ < τ* ≈ 0.8515: sensitive (threshold crossable)
      τ = τ*: critical (threshold at max coherence only)
      τ > τ*: diffuse (threshold unreachable)

    Parameters
    ----------
    temperature : float
        Softmax temperature for normalization. Default is 0.75 (sub-critical,
        slightly below τ* to allow genuine coherence to cross the threshold).
    """

    def __init__(self, temperature: float = 0.75):
        if temperature <= 0:
            raise ValueError(f"Temperature must be positive, got {temperature}")
        self.temperature = temperature
        self._history: List[VXMeasurement] = []

    @property
    def regime(self) -> str:
        """Current measurement regime based on temperature."""
        if self.temperature < TAU_STAR - 0.01:
            return "sub-critical"
        elif self.temperature > TAU_STAR + 0.01:
            return "super-critical"
        else:
            return "critical"

    def measure(self, agent_outputs: List[str]) -> VXMeasurement:
        """
        Measure coherence of agent outputs.

        Parameters
        ----------
        agent_outputs : list of str
            Text outputs from N agents (N ≥ 2).

        Returns
        -------
        VXMeasurement
            The (λ, κ, η) measurement with state classification.
        """
        if len(agent_outputs) < 2:
            raise ValueError("Need at least 2 agent outputs to measure coherence")

        # Compute raw measurements
        coherence_raw = tfidf_coherence(agent_outputs)
        curvature_raw = curvature_from_similarities(agent_outputs)
        entropy_raw = spectral_entropy(agent_outputs)

        # Scale to comparable ranges [0, 1]
        scaled_coherence = float(np.clip(coherence_raw, 0, 1))
        scaled_curvature = float(np.clip(curvature_raw * 4, 0, 1))
        scaled_entropy = float(np.clip(entropy_raw, 0, 1))

        # Softmax normalize onto simplex with measurement temperature
        raw = np.array([scaled_coherence, scaled_curvature, scaled_entropy])
        lam, kap, eta = softmax_tau(raw, self.temperature)

        # Verify conservation
        dev = conservation_check(lam, kap, eta, tol=1e-10)

        # Compute generating functional and gradient
        F = generating_functional(lam, kap, eta)
        grad = gradient_F(lam, kap, eta)
        grad_norm = float(np.linalg.norm(grad))

        # Classify state
        state = classify_state(lam)

        measurement = VXMeasurement(
            lam=lam,
            kap=kap,
            eta=eta,
            state=state,
            conservation_deviation=dev,
            F=F,
            grad_norm=grad_norm,
            temperature=self.temperature,
        )

        self._history.append(measurement)
        return measurement

    def detect_transition(self, window: int = 5) -> Optional[str]:
        """
        Detect state transitions in recent measurement history.

        Returns a string like "STRESSED → TRANSITIONAL" or None if no transition.
        """
        if len(self._history) < window:
            return None

        recent = self._history[-window:]
        states = [m.state for m in recent]

        # Check if there's a transition in the window
        for i in range(1, len(states)):
            if states[i] != states[i - 1]:
                return f"{states[i-1].value} → {states[i].value}"

        return None

    def convergence_trajectory(self) -> List[float]:
        """Return the λ values from measurement history."""
        return [m.lam for m in self._history]

    def clear_history(self):
        """Clear measurement history."""
        self._history.clear()

    def summary(self) -> dict:
        """Summary statistics of measurement history."""
        if not self._history:
            return {"count": 0}

        lambdas = [m.lam for m in self._history]
        return {
            "count": len(self._history),
            "temperature": self.temperature,
            "regime": self.regime,
            "lambda_mean": float(np.mean(lambdas)),
            "lambda_std": float(np.std(lambdas)),
            "lambda_min": float(np.min(lambdas)),
            "lambda_max": float(np.max(lambdas)),
            "above_threshold_count": sum(1 for m in self._history if m.above_threshold),
            "current_state": self._history[-1].state.value,
        }
