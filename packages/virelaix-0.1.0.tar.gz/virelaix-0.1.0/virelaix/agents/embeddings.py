"""
VX Agent Embeddings
===================
Copyright (c) 2026 Dustin Watkins / DataSphere AI, LLC. All rights reserved.

Compute coherence, curvature, and entropy from agent text outputs.

Key insight from March 2026 prototyping:
- Coherence: mean pairwise cosine similarity of TF-IDF vectors
- Curvature: standard deviation of similarities (geometric spread)
- Entropy: spectral entropy via SVD (effective dimensionality of agent space)

Spectral entropy is CRITICAL — word-level Shannon entropy does NOT work
because text always has high word entropy regardless of semantic agreement.
Spectral entropy measures how many independent "directions" the agents span.
"""

from __future__ import annotations
from typing import List, Optional

import numpy as np
from numpy.linalg import svd


def _build_tfidf_matrix(texts: List[str]) -> np.ndarray:
    """
    Build a TF-IDF matrix from texts using pure numpy.

    Uses unigram + bigram tokens with sublinear TF (1 + log(tf)).
    Falls back gracefully if sklearn is unavailable.
    """
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        vectorizer = TfidfVectorizer(
            ngram_range=(1, 2),
            sublinear_tf=True,
            max_features=5000,
        )
        matrix = vectorizer.fit_transform(texts)
        return matrix.toarray()
    except ImportError:
        # Pure numpy fallback: word-level TF with L2 normalization
        from collections import Counter
        all_tokens: set = set()
        text_tokens: List[Counter] = []
        for text in texts:
            words = text.lower().split()
            tokens = list(words)
            for i in range(len(words) - 1):
                tokens.append(words[i] + " " + words[i + 1])
            counter = Counter(tokens)
            text_tokens.append(counter)
            all_tokens.update(counter.keys())

        token_list = sorted(all_tokens)
        token_idx = {t: i for i, t in enumerate(token_list)}
        matrix = np.zeros((len(texts), len(token_list)))
        for i, counter in enumerate(text_tokens):
            for token, count in counter.items():
                matrix[i, token_idx[token]] = 1 + np.log(count) if count > 0 else 0

        # L2 normalize rows
        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        norms[norms == 0] = 1
        matrix /= norms
        return matrix


def tfidf_coherence(texts: List[str]) -> float:
    """
    Compute mean pairwise cosine similarity from TF-IDF vectors.

    Returns value in [0, 1] where 1 = identical outputs.
    """
    if len(texts) < 2:
        return 1.0

    matrix = _build_tfidf_matrix(texts)
    n = len(texts)

    # Cosine similarity: since rows are L2-normalized, dot product = cosine
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0] = 1
    normed = matrix / norms
    sim_matrix = normed @ normed.T

    # Mean of upper triangle (exclude diagonal)
    total = 0.0
    count = 0
    for i in range(n):
        for j in range(i + 1, n):
            total += sim_matrix[i, j]
            count += 1

    return total / count if count > 0 else 1.0


def spectral_entropy(texts: List[str]) -> float:
    """
    Compute spectral entropy of the agent output space via SVD.

    This measures the effective dimensionality of the agent responses:
    - 0.0 = all agents identical (rank 1) → no divergence
    - 1.0 = all agents maximally different → maximum divergence

    Key discovery: this correctly captures semantic agreement/disagreement
    where word-level Shannon entropy fails.
    """
    if len(texts) < 2:
        return 0.0

    matrix = _build_tfidf_matrix(texts)

    _, s, _ = svd(matrix, full_matrices=False)
    s_pos = s[s > 1e-10]

    if len(s_pos) <= 1:
        return 0.0

    p = s_pos ** 2
    p = p / p.sum()
    H = -np.sum(p * np.log(p + 1e-30))
    max_H = np.log(len(s_pos))

    return float(H / max_H) if max_H > 0 else 0.0


def curvature_from_similarities(texts: List[str]) -> float:
    """
    Compute curvature as the standard deviation of pairwise cosine similarities.

    High curvature = agents are inconsistently related (some agree, some don't).
    Low curvature = uniform agreement or uniform disagreement.
    """
    if len(texts) < 3:
        return 0.0

    matrix = _build_tfidf_matrix(texts)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0] = 1
    normed = matrix / norms
    sim_matrix = normed @ normed.T

    sims = []
    n = len(texts)
    for i in range(n):
        for j in range(i + 1, n):
            sims.append(sim_matrix[i, j])

    return float(np.std(sims)) if sims else 0.0
