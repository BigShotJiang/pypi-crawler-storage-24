"""
VX Agent Middleware
===================
Copyright (c) 2026 Dustin Watkins / DataSphere AI, LLC. All rights reserved.

Drop-in coherence monitoring for any multi-agent framework.

Supports:
  - Generic Python callables (any function that returns text)
  - CrewAI tasks (via crew wrapper)
  - LangGraph nodes (via graph wrapper)
  - Raw text streams (via direct monitor)

Usage:
    from virelaix.agents.middleware import VXMiddleware

    # Generic: wrap any callable agents
    mw = VXMiddleware(temperature=0.75)
    result = mw.run_and_measure([
        lambda: agent1.respond(prompt),
        lambda: agent2.respond(prompt),
        lambda: agent3.respond(prompt),
    ])
    print(result.measurement.state)   # COHERENT / TRANSITIONAL / etc.
    print(result.outputs)              # list of agent outputs
    print(result.measurement.lam)      # coherence value

    # With automatic rebalancing recommendation
    if not result.measurement.above_threshold:
        print(f"Coalition degraded: λ={result.measurement.lam:.4f}")
        print(f"Recommend: increase temperature to {result.recommended_tau:.4f}")
"""

from __future__ import annotations
from typing import List, Callable, Optional, Any, Dict
from dataclasses import dataclass, field
from datetime import datetime
import time

from virelaix.core.constants import TAU_STAR, LAMBDA_STAR
from virelaix.core.geometry import critical_temperature_for_threshold
from virelaix.core.states import VXMeasurement, VXState
from virelaix.agents.monitor import CoherenceMonitor


@dataclass
class VXRunResult:
    """Result of running agents through VX middleware."""
    outputs: List[str]
    measurement: VXMeasurement
    elapsed_seconds: float
    timestamp: str
    agent_count: int
    recommended_tau: Optional[float] = None
    transition: Optional[str] = None

    @property
    def healthy(self) -> bool:
        """True if coalition is above the Watkins threshold."""
        return self.measurement.above_threshold

    def summary_line(self) -> str:
        """One-line summary for logging."""
        status = "✓ COHERENT" if self.healthy else f"⚠ {self.measurement.state.value}"
        return (
            f"[VX] {status} | λ={self.measurement.lam:.4f} "
            f"κ={self.measurement.kap:.4f} η={self.measurement.eta:.4f} | "
            f"F={self.measurement.F:.4f} | {self.agent_count} agents | "
            f"{self.elapsed_seconds:.2f}s"
        )


class VXMiddleware:
    """
    Drop-in coherence monitoring for multi-agent systems.

    Wraps agent execution, measures coherence of outputs,
    and provides real-time state classification and rebalancing
    recommendations.

    Parameters
    ----------
    temperature : float
        Softmax temperature for measurement. Default 0.75 (sub-critical).
    alert_on_degradation : bool
        If True, prints warning when coalition drops below threshold.
    history_limit : int
        Max measurements to retain in history.
    """

    def __init__(
        self,
        temperature: float = 0.75,
        alert_on_degradation: bool = True,
        history_limit: int = 1000,
    ):
        self.monitor = CoherenceMonitor(temperature=temperature)
        self.alert_on_degradation = alert_on_degradation
        self.history_limit = history_limit
        self._results: List[VXRunResult] = []

    @property
    def temperature(self) -> float:
        return self.monitor.temperature

    @temperature.setter
    def temperature(self, value: float):
        self.monitor.temperature = value

    def run_and_measure(
        self,
        agent_callables: List[Callable[[], str]],
    ) -> VXRunResult:
        """
        Execute agent callables and measure coherence of their outputs.

        Each callable should return a string (the agent's response).
        """
        t0 = time.time()
        outputs = []
        for fn in agent_callables:
            try:
                output = fn()
                outputs.append(str(output))
            except Exception as e:
                outputs.append(f"[ERROR: {e}]")

        measurement = self.monitor.measure(outputs)
        elapsed = time.time() - t0
        transition = self.monitor.detect_transition()

        # Compute recommended temperature if below threshold
        recommended_tau = None
        if not measurement.above_threshold:
            # Find the temperature that would make their max coherence = threshold
            try:
                target_lam = min(measurement.lam + 0.1, 0.99)
                recommended_tau = critical_temperature_for_threshold(
                    max(target_lam, LAMBDA_STAR)
                )
            except (ValueError, ZeroDivisionError):
                recommended_tau = TAU_STAR * 0.8  # safe default

        result = VXRunResult(
            outputs=outputs,
            measurement=measurement,
            elapsed_seconds=elapsed,
            timestamp=datetime.now().isoformat(),
            agent_count=len(outputs),
            recommended_tau=recommended_tau,
            transition=transition,
        )

        self._results.append(result)
        if len(self._results) > self.history_limit:
            self._results.pop(0)

        if self.alert_on_degradation and not measurement.above_threshold:
            print(f"⚠ VX ALERT: {result.summary_line()}")

        if transition:
            print(f"🔄 VX TRANSITION: {transition}")

        return result

    def measure_texts(self, texts: List[str]) -> VXRunResult:
        """Measure coherence of pre-collected agent outputs (no execution)."""
        t0 = time.time()
        measurement = self.monitor.measure(texts)
        elapsed = time.time() - t0
        transition = self.monitor.detect_transition()

        result = VXRunResult(
            outputs=texts,
            measurement=measurement,
            elapsed_seconds=elapsed,
            timestamp=datetime.now().isoformat(),
            agent_count=len(texts),
            transition=transition,
        )
        self._results.append(result)
        return result

    def trajectory(self) -> List[Dict]:
        """Return history as list of dicts for plotting."""
        return [
            {
                "round": i + 1,
                "lam": r.measurement.lam,
                "kap": r.measurement.kap,
                "eta": r.measurement.eta,
                "state": r.measurement.state.value,
                "F": r.measurement.F,
                "healthy": r.healthy,
                "agents": r.agent_count,
                "elapsed": r.elapsed_seconds,
            }
            for i, r in enumerate(self._results)
        ]

    def health_report(self) -> Dict:
        """Aggregate health report across all measurements."""
        if not self._results:
            return {"status": "no_data", "measurements": 0}

        lambdas = [r.measurement.lam for r in self._results]
        healthy_count = sum(1 for r in self._results if r.healthy)

        import numpy as np
        return {
            "status": "healthy" if self._results[-1].healthy else "degraded",
            "measurements": len(self._results),
            "current_state": self._results[-1].measurement.state.value,
            "lambda_mean": float(np.mean(lambdas)),
            "lambda_trend": float(lambdas[-1] - lambdas[0]) if len(lambdas) > 1 else 0,
            "healthy_ratio": healthy_count / len(self._results),
            "temperature": self.temperature,
            "regime": self.monitor.regime,
        }


# ── Framework-Specific Adapters ──────────────────────────────

class CrewAIAdapter:
    """
    Adapter for CrewAI framework.

    Usage:
        from crewai import Crew, Agent, Task
        adapter = CrewAIAdapter(temperature=0.75)

        # Wrap crew execution
        result = adapter.monitor_crew(crew, inputs={"topic": "AI safety"})
    """

    def __init__(self, temperature: float = 0.75):
        self.middleware = VXMiddleware(temperature=temperature)

    def monitor_crew(self, crew: Any, inputs: Dict = None) -> VXRunResult:
        """
        Run a CrewAI crew and measure task output coherence.

        Extracts text outputs from each task's result.
        """
        crew_result = crew.kickoff(inputs=inputs or {})

        # Extract outputs from crew tasks
        outputs = []
        if hasattr(crew_result, 'tasks_output'):
            for task_output in crew_result.tasks_output:
                outputs.append(str(task_output))
        else:
            outputs.append(str(crew_result))

        if len(outputs) < 2:
            # Need at least 2 for coherence measurement
            outputs.append(str(crew_result))

        return self.middleware.measure_texts(outputs)


class LangGraphAdapter:
    """
    Adapter for LangGraph framework.

    Usage:
        adapter = LangGraphAdapter(temperature=0.75)

        # Monitor graph execution by collecting node outputs
        adapter.record_node("researcher", researcher_output)
        adapter.record_node("writer", writer_output)
        adapter.record_node("reviewer", reviewer_output)
        result = adapter.measure()
    """

    def __init__(self, temperature: float = 0.75):
        self.middleware = VXMiddleware(temperature=temperature)
        self._node_outputs: Dict[str, str] = {}

    def record_node(self, node_name: str, output: str):
        """Record output from a graph node."""
        self._node_outputs[node_name] = str(output)

    def measure(self) -> VXRunResult:
        """Measure coherence across all recorded node outputs."""
        if len(self._node_outputs) < 2:
            raise ValueError(
                f"Need at least 2 node outputs, have {len(self._node_outputs)}"
            )
        outputs = list(self._node_outputs.values())
        result = self.middleware.measure_texts(outputs)
        self._node_outputs.clear()
        return result

    def measure_and_keep(self) -> VXRunResult:
        """Measure coherence without clearing node outputs."""
        outputs = list(self._node_outputs.values())
        return self.middleware.measure_texts(outputs)
