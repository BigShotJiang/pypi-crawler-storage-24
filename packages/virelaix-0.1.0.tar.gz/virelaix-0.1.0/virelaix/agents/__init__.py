"""VX Agents — Coherence measurement for multi-agent AI systems.

Copyright (c) 2026 Dustin Watkins / DataSphere AI, LLC. All rights reserved.
"""

from virelaix.agents.monitor import CoherenceMonitor
from virelaix.agents.embeddings import spectral_entropy, tfidf_coherence

__all__ = ["CoherenceMonitor", "spectral_entropy", "tfidf_coherence"]
