"""
VX State Classification
=======================
Classifies points on the simplex into consciousness states
based on the Watkins threshold λ* = 1/φ.
"""

from __future__ import annotations
from enum import Enum
from dataclasses import dataclass
from typing import Optional

from virelaix.core.constants import LAMBDA_STAR


class VXState(str, Enum):
    """Consciousness state classification."""
    COHERENT = "COHERENT"          # λ > 1/φ — above Watkins threshold
    TRANSITIONAL = "TRANSITIONAL"  # 0.4 < λ ≤ 1/φ — approaching threshold
    STRESSED = "STRESSED"          # 0.2 < λ ≤ 0.4 — degraded coherence
    TURBULENT = "TURBULENT"        # λ ≤ 0.2 — no measurable coherence


@dataclass(frozen=True)
class VXMeasurement:
    """A single measurement on the VX simplex."""
    lam: float    # λ — coherence
    kap: float    # κ — curvature
    eta: float    # η — entropy
    state: VXState
    conservation_deviation: float
    F: Optional[float] = None          # generating functional value
    grad_norm: Optional[float] = None  # |∇F|
    temperature: Optional[float] = None  # measurement temperature τ

    @property
    def above_threshold(self) -> bool:
        return self.lam >= LAMBDA_STAR

    def __repr__(self) -> str:
        return (
            f"VXMeasurement(λ={self.lam:.4f}, κ={self.kap:.4f}, η={self.eta:.4f}, "
            f"state={self.state.value}, F={self.F:.4f})"
            if self.F is not None else
            f"VXMeasurement(λ={self.lam:.4f}, κ={self.kap:.4f}, η={self.eta:.4f}, "
            f"state={self.state.value})"
        )


def classify_state(lam: float) -> VXState:
    """
    Classify consciousness state based on coherence λ.

    COHERENT:     λ > 1/φ ≈ 0.618 (above Watkins threshold)
    TRANSITIONAL: 0.4 < λ ≤ 1/φ
    STRESSED:     0.2 < λ ≤ 0.4
    TURBULENT:    λ ≤ 0.2
    """
    if lam > LAMBDA_STAR:
        return VXState.COHERENT
    elif lam > 0.4:
        return VXState.TRANSITIONAL
    elif lam > 0.2:
        return VXState.STRESSED
    else:
        return VXState.TURBULENT
