"""VX Core — Constants, geometry, and state classification."""
