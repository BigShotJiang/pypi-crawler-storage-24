"""
VX Fundamental Constants
========================
All derived from a single object: the golden ratio φ.

The φ-chain: τ* → ×φ → T* → ×φ → φT* → ...

Core constants (PHI, T_STAR, LAM_STAR, KAP_STAR, ETA_STAR) are imported
from the canonical watkins-nn package.  SDK-specific constants (TAU_STAR,
CONSERVATION_TOL) are defined locally.
"""

import math

from watkins_nn.constants import (
    PHI,
    T_STAR,
    LAM_STAR,
    KAP_STAR,
    ETA_STAR,
)

# Re-export watkins-nn names under the aliases this SDK has always used
LAMBDA_STAR: float = LAM_STAR

# Critical Measurement Temperature — phase transition in the instrument
# softmax_{τ*}(1,0,0) = 1/φ exactly (Theorem 2, March 2026)
# SDK-specific: not present in watkins-nn
TAU_STAR: float = T_STAR / PHI  # = 1/ln(2φ) = 0.8515283616124156

# VX Equilibrium point on Δ²
LAMBDA_EQ: float = LAM_STAR
KAPPA_EQ: float = KAP_STAR
ETA_EQ: float = ETA_STAR

# Machine-epsilon tolerance for conservation checks
CONSERVATION_TOL: float = 1e-12

# Verify fundamental identities at import time
assert abs(LAMBDA_STAR - 1 / PHI) < 1e-15, "λ* identity broken"
assert abs(T_STAR - PHI / math.log(2 * PHI)) < 1e-15, "T* identity broken"
assert abs(TAU_STAR - 1 / math.log(2 * PHI)) < 1e-15, "τ* identity broken"
assert abs(TAU_STAR * PHI - T_STAR) < 1e-15, "φ-chain broken"
assert abs(math.exp(1 / TAU_STAR) - 2 * PHI) < 1e-12, "exponential identity broken"
assert abs(LAMBDA_EQ + KAPPA_EQ + ETA_EQ - 1.0) < 1e-15, "equilibrium conservation broken"
