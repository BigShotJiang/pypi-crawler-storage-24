import settings

from pynop.core.biz import Biz
from pynop.core.db import AutoDao
from pynop.core.utils import *

from sync.staging.staging_data import *
from sync.staging.staging_sql import StagingQuery
from sync.rws.rws_sql import RwsQuery
from sync.shop.shop_tools import *
from sync.shop.shop_data import *

class StagingBiz(Biz):

    def __init__(self):
        super().__init__(settings)
    
    def start_biz(self):
        self.staging_erp_data()
        self.staging_rws_data()
        self.staging_sys_data()

    def end_biz(self):        
        #self.reports['created_products_n'] = len(self.created_pid_list)
        #self.reports['updated_products_n'] = len(self.updated_pid_list)
        super().end_biz()


    def staging_erp_data(self):
        self.logger.log_step("Staging erp data")

        staging_dao = AutoDao("staging")
                
        if not StagingErpData.products:
            erp_products = staging_dao.get_hashtable(StagingQuery.GET_STA_PRODUCT_SQL, [], 8)
            for sku, erp_product_dict in erp_products.items():
                StagingErpData.products[sku] = ErpProductData(erp_product_dict=erp_product_dict)
            StagingErpData.item_number_list = staging_dao.get_one_col_list(StagingQuery.GET_STA_ITEM_NUMBER_SQL)
            StagingErpData.item_number_sku_map = staging_dao.get_hashmap(StagingQuery.GET_STA_ITEM_NUMBER_SKU_MAP_SQL)
        self.reports['number_of_staging_erp_products'] = len(StagingErpData.products.keys())
        self.logger.log_data({'StagingErpData.products':len(StagingErpData.products.keys())})

        if not StagingErpData.pr_file_discounts:            
            StagingErpData.pr_file_discounts = staging_dao.get_hashtable(StagingQuery.GET_STA_PR_FILE_DISCOUNTS_SQL)
        #self.logger.log_data({'StagingErpData.pr_file_discounts':StagingErpData.pr_file_discounts})

        if not StagingErpData.accessories:
            StagingErpData.accessories = staging_dao.get_hashtable(StagingQuery.GET_STA_ACCESSORY_SQL)        
        #self.logger.log_data({'StagingErpData.accessories':StagingErpData.accessories})

        if not StagingErpData.manufacturers:
            StagingErpData.manufacturers = staging_dao.get_hashtable(StagingQuery.GET_STA_MANUFACTURER_SQL, [], 1)
        #self.logger.log_data({'StagingErpData.manufacturers':StagingErpData.manufacturers})

        if not StagingErpData.product_manufacturer_mappings:
            StagingErpData.product_manufacturer_mappings = staging_dao.get_hashmap(StagingQuery.GET_STA_PRODUCT_MANUFACTURER_MAPPING_SQL)
        #self.logger.log_data({'StagingErpData.product_manufacturer_mappings':StagingErpData.product_manufacturer_mappings})

        if not StagingErpData.product_category_mappings:
            StagingErpData.product_category_mappings = staging_dao.get_hashtable(StagingQuery.GET_STA_PRODUCT_CATEGORY_MAPPING_SQL)
        #self.logger.log_data({'StagingErpData.product_category_mappings':StagingErpData.product_category_mappings})

        if not StagingErpData.scandown_date:
            StagingErpData.scandown_date = staging_dao.get_hashtable(StagingQuery.GET_STA_SCANDOWN_DATE_SQL, [], 1)
        #self.logger.log_data({'StagingErpData.scandaown_date':StagingErpData.scandown_date})
  
                
        sql = ""
        if 'haw' in settings.DB_CONFIG['env']:
            sql = StagingQuery.GET_STA_NOP_CATEGORY_HASHMAP_SQL.format(tbl_prefix = 'haw')
        else:
            sql = StagingQuery.GET_STA_NOP_CATEGORY_HASHMAP_SQL.format(tbl_prefix = 'abc')
        StagingSysData.erp_nop_category_map = staging_dao.get_hashmap(sql)
        #self.logger.log_data({'StagingSysData.erp_nop_category_map':StagingSysData.erp_nop_category_map})
        
        StagingSysData.clearance_items = staging_dao.get_hashtable(StagingQuery.GET_CLEARANCE_ITEM_HASHTABLE_SQL)
        #self.logger.log_data({'StagingSysData.clearance_items':StagingSysData.clearance_items})


    def staging_rws_data(self):
        self.logger.log_step("Staging second data")

        staging_dao = AutoDao("staging")
                
        if settings.SECOND_DATA_OPTION == 'RWS' and not StagingRwsData.products:
            StagingRwsData.products = staging_dao.get_hashtable(
                "SELECT item_key, * FROM rws_product", [])
            self.reports['number_of_staging_rws_products'] = len(StagingRwsData.products.keys())            
            self.logger.log_data({'StagingRwsData.products':len(StagingRwsData.products)})
        
            StagingRwsData.managed_data_tbl = staging_dao.get_hashtable(
                "SELECT rws_product_id, * FROM rws_managed_data", [])
            #self.logger.log_data({'StagingRwsData.managed_data':StagingRwsData.managed_data_tbl})

            StagingRwsData.marketing_copy_tbl = staging_dao.get_hasharrtable(
                "SELECT rws_product_id, * FROM rws_marketing_copy", [])
            #self.logger.log_data({'StagingRwsData.markting_copy':StagingRwsData.marketing_copy_tbl})
            
            StagingRwsData.marketing_copy_feature_tbl = staging_dao.get_hasharrtable(
                "SELECT rws_product_id, * FROM rws_marketing_copy_feature", [])
            #self.logger.log_data({'StagingRwsData.markting_copy':StagingRwsData.marketing_copy_feature_tbl})

            StagingRwsData.marketing_copy_image_feature_tbl = staging_dao.get_hasharrtable(
                "SELECT rws_product_id, * FROM rws_marketing_copy_image_feature", [])
            #self.logger.log_data({'StagingRwsData.markting_copy':StagingRwsData.marketing_copy_image_feature_tbl})
            
            StagingRwsData.brands = staging_dao.get_hashtable(RwsQuery.GET_RWS_BRANDS_SQL)
            #self.logger.log_data({'StagingRwsData.brands':StagingRwsData.brands})
            
            GET_ABC_CATEGORIES_SQL = """
                SELECT [Category_Code], 
                    [Category_Description], 
                    [NOP_ID] 
                FROM [dbo].[_abc_rws_nop_category_mapping]
            """
            StagingRwsData.abc_categories = staging_dao.get_hashtable(GET_ABC_CATEGORIES_SQL)
            #self.logger.log_data({'StagingRwsData.abc_categories':StagingRwsData.abc_categories})

            GET_HAW_CATEGORIES_SQL = """
                SELECT [Category_Code], 
                    [Category_Description], 
                    [NOP_ID] 
                FROM [dbo].[_haw_rws_nop_category_mapping]
            """
            StagingRwsData.haw_categories = staging_dao.get_hashtable(GET_HAW_CATEGORIES_SQL)
            #self.logger.log_data({'StagingRwsData.haw_categories':StagingRwsData.haw_categories})

            GET_RWS_DOCUMENTS_SQL = """
                SELECT [id]
                      ,[rws_product_id]
                      ,[pdf_description]
                      ,[pdf_file_name]
                      ,[pdf_url]
                  FROM [dbo].[rws_media_pdf]
            """
            StagingRwsData.media_pdfs = staging_dao.get_hashtable(GET_RWS_DOCUMENTS_SQL)
            message = "StagingRwsData.media_pdfs: {n}".format(n=StagingRwsData.media_pdfs.keys())
            #self.logger.log_data({'StagingRwsData.media_pdfs':StagingRwsData.media_pdfs})
                        
            GET_RWS_SPEC_TABLE_SQL = "SELECT * FROM [dbo].[rws_spec_table_as_key_value_pairs]"
            StagingRwsData.spec_table_as_key_value_pairs_tbl = staging_dao.get_hashtable(GET_RWS_SPEC_TABLE_SQL)
            self.reports['number_of_staging_rws_spec_table_as_key_value_paris'] = len(StagingRwsData.spec_table_as_key_value_pairs_tbl.keys())
            #self.logger.log_data({'StagingRwsData.spec_table_as_key_value_pairs':StagingRwsData.spec_table_as_key_value_pairs_tbl})
        
        self.logger.log_divider()

    
    def staging_sys_data(self):
        self.logger.log_step("Staging sys data")

        staging_dao = AutoDao("staging")
        GET_NO_UDATE_DESCRIPTIONS_CATEGORY_ID_LIST_SQL = """
            SELECT [Id] FROM [_no_update_descriptions_category]
        """
        StagingSysData.no_update_descriptions_category_id_list = staging_dao.get_list(GET_NO_UDATE_DESCRIPTIONS_CATEGORY_ID_LIST_SQL)


class StagingImageBiz(Biz):
    
    def __init__(self):
        super().__init__(settings)
        self.src_image_dir_dict = {'erp':settings.ERP_IMAGE_DIR, 'rws': settings.RWS_IMAGE_DIR, 'promo': settings.PROMO_IMAGE_DIR}
        self.stage_error_dict = {'erp':[], 'rws':[], 'promo': []}

    def download_nop_picture_to_stage_folder(self, pid, nop_ppms):
        # create /contents/product_images/stage/{pid}/nop folder
        stg_pid_folder_path = os.path.join(os.path.join(settings.STG_IMAGE_DIR, f"{pid}"), "nop")
        if not os.path.exists(stg_pid_folder_path):
            os.makedirs(stg_pid_folder_path)

    def insert_or_update_stg_image_mapping(self, sku, image_src, image_id, display_order):
        stg_image_mapping = staging_dao.get_one_row_dict(
            "SELECT * FROM stg_image_mapping WHERE sku = ? AND image_src = ? AND image_id = ?",
            [sku, image_src, image_id]
        )
        self.logger.log_biz_msg("stg_image_mapping", str(stg_image_mapping))

        if stg_image_mapping:
            if stg_image_mapping['display_order'] != display_order:
                staging_dao.update(
                    """
                        UPDATE stg_image_mapping
                        SET display_order = ?
                        WHERE id = ?
                    """,
                    [display_order, stg_image_mapping['id']]
                )
                self.reports['stg_mapping_updated'] = self.reports.get('stg_mapping_updated', 0) + 1
                self.logger.log_biz_msg(
                    "display_order in stg_image_mapping is changed", 
                    f"stg_image_mapping id: {stg_image_mapping['id']}, display_order: {display_order}"
                )
        else:
            stg_image_mapping = staging_dao.update_r_dict(
                """
                    INSERT INTO stg_image_mapping 
                        ([sku]
                        ,[image_src]
                        ,[image_id]
                        ,[display_order])
                    OUTPUT INSERTED.*
                    VALUES (?, ?, ?, ?)
                """, 
                [
                    sku,
                    image_src,
                    image_id,
                    display_order
                ]
            )
            self.logger.log_biz_msg("stg_image_mapping", "New stg_image_mapping is inserted.")
            self.reports['stg_mapping_inserted'] = self.reports.get('stg_mapping_inserted', 0) + 1

        self.seen_stg_image_mapping_id_list.append(stg_image_mapping['id'])
        
        return stg_image_mapping

    def stage_image(self, image_src, image_row, stg_pid_folder_path, sku, display_order):
        is_staged = False
        image_dir = self.src_image_dir_dict[image_src]
        if image_dir:
            src_image_path = os.path.join(image_dir, image_row['filename'])
            # copy erp image from erp image path to stage/pid path
            stg_image_filename = f"{image_src}_{image_row['filename']}"
            dst_image_path = os.path.join(stg_pid_folder_path, stg_image_filename)
            
            if not os.path.exists(dst_image_path):
                if os.path.exists(src_image_path):
                    copy_file(src_image_path, dst_image_path)
                    self.logger.log_biz_msg("Successfully staged image mapping", f"Copyed file from: {src_image_path} to: {dst_image_path}")
                    is_staged = True
                else:
                    staging_dao.update(
                        f"""
                            UPDATE {image_src}_image
                            SET status = 'STAGE-ERROR'
                            WHERE id = ?
                        """,
                        [image_row['id']]
                    )
                    self.stage_error_dict[image_src].append(image_row['id'])
                    self.logger.log("Error: source file is not existing", "error")
            else:
                is_staged = True

            if is_staged:
                staging_dao.update(
                    f"""
                        UPDATE {image_src}_image
                        SET status = 'STAGED'
                        WHERE id = ?
                    """,
                    [image_row['id']]
                )                    
                self.insert_or_update_stg_image_mapping(sku, image_src, image_row['id'], display_order)
                self.reports[f'images_staged_{image_src}'] = self.reports.get(f'images_staged_{image_src}', 0) + 1
        else:
            self.logger.log("Error: image_src value must be erp, promo or rws.", "error")
        
        return is_staged

    def remove_unstaged_image_mapping_data(self):
        DELETE_UNSTAGED_IMAGE_MAPPINGS_SQL = """
            DELETE FROM {stg}.dbo.stg_image_mapping 
            WHERE sku NOT IN (
                Select Sku From {nop}.dbo.Product Where Published = 1 AND Deleted = 0
            )
        """.format(
            nop=settings.DB_CONFIG[settings.DB_CONFIG['env']]['nop']['db_name'], 
            stg=settings.DB_CONFIG[settings.DB_CONFIG['env']]['staging']['db_name']
        )
        all_dao = AutoDao("all")
        n = all_dao.update_return_rowcount(DELETE_UNSTAGED_IMAGE_MAPPINGS_SQL)
        self.reports['unstaged_mappings_removed'] = n

    def unstage_sku_dir(self, sku, pid):
        stg_pid_folder_path = os.path.join(settings.STG_IMAGE_DIR, f"{pid}")
        if os.path.exists(stg_pid_folder_path):
            unstg_pid_folder_path = os.path.join(settings.UNSTG_IMAGE_DIR, f"{pid}")
            if os.path.exists(unstg_pid_folder_path):
                remove_folder(unstg_pid_folder_path)
            move_dir(stg_pid_folder_path, unstg_pid_folder_path)
            return True
        return False

    def start_biz(self):
        self.logger.log_big_divider()
        self.logger.log_task_title("Staging pictures per NopProduct...")
        
        self.reports['published_products_processed'] = 0
        self.reports['unpublished_products_unstaged'] = 0
        self.reports['stg_mapping_inserted'] = 0
        self.reports['stg_mapping_updated'] = 0
        self.reports['stg_mapping_pruned'] = 0
        self.reports['images_staged_erp'] = 0
        self.reports['images_staged_rws'] = 0
        self.reports['images_staged_promo'] = 0
        self.reports['unstaged_mappings_removed'] = 0

        total_products = len(NopData.sku_pid_map)
        published_count = sum(
            1 for _sku, pid in NopData.sku_pid_map.items()
            if NopData.products_pub_del_tbl.get(pid, {}).get('Published', False)
        )
        self.reports['nop_total_products'] = total_products
        self.reports['nop_published_products'] = published_count
        self.reports['nop_unpublished_products'] = total_products - published_count

        StagingErpData.item_number_sku_map = staging_dao.get_hashmap(StagingQuery.GET_STA_ITEM_NUMBER_SKU_MAP_SQL)
        StagingRwsData.products = staging_dao.get_hashtable("SELECT item_key, * FROM rws_product", [])
        
        reset_folder_flag = False
        for sku, pid in NopData.sku_pid_map.items():
            is_published_product = NopData.products_pub_del_tbl[pid]['Published']
            if is_published_product: # currently do not check is_published_product
                self.reports['published_products_processed'] = self.reports.get('published_products_processed', 0) + 1
                self.logger.log_divider()
                self.logger.log_biz_msg("SKU  -  PID", f"{sku}  -  {pid}")
                
                # create /contents/product_images/stage/{pid} folder
                stg_pid_folder_path = os.path.join(settings.STG_IMAGE_DIR, f"{pid}")
                if not os.path.exists(stg_pid_folder_path):
                    os.makedirs(stg_pid_folder_path)
                else:
                    if reset_folder_flag:
                        remove_folder(stg_pid_folder_path)
                        os.makedirs(stg_pid_folder_path)
                
                self.seen_stg_image_mapping_id_list = []

                erp_image = {}
                erp_display_order = 0
                # loading erp-primary image
                item_number = staging_dao.get_one_value("SELECT ItemNumber FROM erp_product WHERE Sku = ?", sku)

                if item_number:
                    erp_image = staging_dao.get_one_row_dict(
                        """
                            SELECT * FROM erp_image WHERE status <> 'DISABLED' AND item_number = ?
                        """,
                        [item_number]
                    )
                    if erp_image:
                        self.logger.log_biz_msg("ErpImage", str(erp_image))
                        self.stage_image('erp', erp_image, stg_pid_folder_path, sku, erp_display_order)
                    else:
                        self.logger.log_biz_msg(f"item_number: {item_number}", "But No erp_image.")
                else:
                    self.logger.log_biz_msg("No item_number", "Not found erp_image.")

                rws_images = {}
                rws_display_order = 100 if erp_image else 0
                # loading rws images list
                item_key = ""
                rws_product = StagingRwsData.get_rws_product_from_sku(sku)
                if rws_product:
                    item_key = rws_product.item_key
                    self.logger.log_biz_msg("item_key", str(item_key))
                    rws_images = staging_dao.get_hashtable(
                        """
                            SELECT TOP {c} ri.* FROM rws_image ri
                                JOIN rws_media_image rmi ON ri.url = rmi.img_full_size_url AND rmi.item_key = ?
                            ORDER BY rmi.id
                        """.format(c=settings.RWS_PICTURE_MAX_IMPORT_NUMBER),
                        [item_key]
                    )
                    if rws_images:                        
                        for rws_image in rws_images.values():
                            self.logger.log_biz_msg("RwsImage", str(rws_image))
                            self.stage_image('rws', rws_image, stg_pid_folder_path, sku, rws_display_order)

                            self.logger.log_biz_msg("rws_display_order", str(rws_display_order))
                            rws_display_order = rws_display_order + 10 if rws_display_order > 0 else 110
                    else:
                        self.logger.log_biz_msg(f"item_key: {item_key}", "But No rws_images.")
                else:
                    self.logger.log_biz_msg("No item_key", "Not found rws_product for this sku.")
                
                #if erp_image or rws_images or nop_ppms: non-image product can't have promo image
                promo_images = {}
                promo_display_order = 1
                # loading promo images list
                promo_id_list = nop_dao.get_one_col_list(
                    """
                        SELECT a.Id, a.Name
                        FROM ProductAbcPromo pa 
                            JOIN AbcPromo a ON pa.AbcPromoId = a.Id
                        WHERE ProductId = ? 
                            AND CAST(GETDATE() AS DATE) >= [StartDate] AND CAST(GETDATE() AS DATE) <= [EndDate]
                    """,
                    [pid]
                )
                if promo_id_list:
                    for promo_id in promo_id_list:
                        promo_image = staging_dao.get_one_row_dict(
                            "SELECT * FROM promo_image WHERE abc_promo_id = ?",
                            [promo_id]
                        )
                        if promo_image:
                            self.logger.log_biz_msg("PromoImage", str(promo_image))
                            self.logger.log_biz_msg("promo_display_order", str(promo_display_order))

                            self.stage_image('promo', promo_image, stg_pid_folder_path, sku, promo_display_order)
                            
                            promo_display_order = promo_display_order + 1
                            
                            promo_images[promo_id] = promo_image
                        else:
                            self.logger.log_biz_msg("PromoImage", f"No promo_image for promo_id: {promo_id}")
                else:
                    self.logger.log_biz_msg("PromoImage", "Not found promo data for this sku.")

                # get stg_ppms for this sku
                GET_STG_IMAGE_MAPPINGS_BY_SKU_SQL = """
                    SELECT [id]
                        ,[sku]
                        ,[image_src]
                        ,[image_id]
                        ,[display_order]
                        ,[nop_ppm_id]
                    FROM [stg_image_mapping]
                    WHERE sku = ?
                    ORDER BY display_order
                """
                stg_image_mappings = staging_dao.get_hashtable(
                    GET_STG_IMAGE_MAPPINGS_BY_SKU_SQL,
                    [sku]
                )
            
                for stg_image_mapping_id, stg_image_mapping in stg_image_mappings.items():
                    if stg_image_mapping_id not in self.seen_stg_image_mapping_id_list:                            
                        image_src = stg_image_mapping['image_src']
                        image_id = stg_image_mapping['image_id']
                        image_row = staging_dao.get_one_row_dict(
                            f"SELECT * FROM {image_src}_image WHERE id = ?",
                            [image_id]
                        )
                        if image_row:
                            image_filename = f"{image_src}_{image_row['filename']}"
                            full_image_path = os.path.join(stg_pid_folder_path, image_filename)
                            deleted_dir_path = os.path.join(stg_pid_folder_path, 'deleted')
                            if not os.path.exists(deleted_dir_path):
                                os.makedirs(deleted_dir_path)
                            deleted_image_filename = f"{Path(image_filename).stem}_{date.today()}{Path(image_filename).suffix}"
                            full_deleted_image_path = os.path.join(deleted_dir_path, deleted_image_filename)
                            if os.path.isfile(full_image_path):
                                move_file(full_image_path, full_deleted_image_path)
                                self.logger.log_biz_msg("Unstaged image file is moved to deleted folder", f"{full_deleted_image_path}")

                        staging_dao.update(
                            "DELETE FROM stg_image_mapping WHERE id = ?", 
                            [stg_image_mapping_id]
                        )
                        self.reports['stg_mapping_pruned'] = self.reports.get('stg_mapping_pruned', 0) + 1
                        self.logger.log_biz_msg("Deleted unstaged stg_image_mapping", str(stg_image_mapping_id))

            else: #if unpublished sku
                if self.unstage_sku_dir(sku, pid):
                    self.reports['unpublished_products_unstaged'] = self.reports.get('unpublished_products_unstaged', 0) + 1

        self.remove_unstaged_image_mapping_data()

    def end_biz(self):
        self.reports['stage_errors_erp'] = len(self.stage_error_dict['erp'])
        self.reports['stage_errors_rws'] = len(self.stage_error_dict['rws'])
        self.reports['stage_errors_promo'] = len(self.stage_error_dict['promo'])
        super().end_biz()


class StagingNopPictureBiz(Biz):
    
    def __init__(self):
        super().__init__(settings)
    
    def stage_nop_pictures(self):
        self.logger.log_step("Staging Nop picture biz")

        self.logger.log_big_divider()
        self.logger.log_task_title("Staging pictures per NopProduct...")
        StagingErpData.item_number_sku_map = staging_dao.get_hashmap(StagingQuery.GET_STA_ITEM_NUMBER_SKU_MAP_SQL)
        StagingRwsData.products = staging_dao.get_hashtable("SELECT item_key, * FROM rws_product", [])
        
        for sku, pid in NopData.sku_pid_map.items():
            is_published_product = NopData.products_pub_del_tbl[pid]['Published']
            if is_published_product:
                self.logger.log_divider()
                self.logger.log_biz_msg("SKU: ", sku)

                # create /contents/product_images/stage/{pid} folder
                stg_pid_folder_path = os.path.join(settings.STG_IMAGE_DIR, str(pid))
                if not os.path.exists(stg_pid_folder_path):
                    os.makedirs(stg_pid_folder_path)

                GET_NOP_PICTURE_SQL = """
                    SELECT p.Id, p.MimeType, p.TitleAttribute, pb.BinaryData, ppm.DisplayOrder
                    FROM Product_Picture_Mapping ppm
                    JOIN PictureBinary pb ON ppm.PictureId=pb.PictureId
                    JOIN Picture p ON ppm.PictureId=p.Id
                    WHERE ppm.ProductId=?
                    Order By ppm.DisplayOrder
                """
                pictures = nop_dao.get_hashtable(
                    GET_NOP_PICTURE_SQL,
                    [pid]
                )
                for id, picture_info in pictures.items():
                    picture_mime = picture_info["MimeType"]
                    picture_filename = picture_info["TitleAttribute"]
                    display_order = picture_info["DisplayOrder"]
                    picture_full_path = os.path.join(stg_pid_folder_path, f'{display_order}_nop_{picture_filename}_{id}.jpg')

                    if not os.path.isfile(picture_full_path):
                        message = "There is no Nop image file in the path: " + picture_full_path
                        self.logger.log(message, "debug")
                        with open(picture_full_path, 'wb') as f:
                            f.write(picture_info["BinaryData"])

    def end_biz(self):        
        #self.reports['created_products_n'] = len(self.created_pid_list)
        #self.reports['updated_products_n'] = len(self.updated_pid_list)
        super().end_biz()
