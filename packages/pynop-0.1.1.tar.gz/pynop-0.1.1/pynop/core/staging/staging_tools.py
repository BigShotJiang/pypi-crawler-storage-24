
class StagingTool:

    @staticmethod
    def get_stg_picture_by_key():
        pass