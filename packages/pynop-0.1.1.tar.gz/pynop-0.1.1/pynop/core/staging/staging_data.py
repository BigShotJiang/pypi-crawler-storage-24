from sync.erp.erp_data import ErpProductData
from sync.rws.rws_data import RwsProductData
from sync.shop.shop_data import ShopData
from settings import SECOND_DATA_OPTION

from pynop.core.utils import *


class StagingSysData:
    clearance_items = {}
    erp_nop_category_map = {}
    no_update_descriptions_category_id_list = []

class StagingErpData:
    item_number_list = []
    item_number_sku_map = {}
    products = {}
    pr_file_discounts = {}
    accessories = {}
    product_manufacturer_mappings = {}
    manufacturers = {}
    product_category_mappings = {}
    scandown_date = {}
    #warranty_groups = {}
    #warranty_items = {}
    #product_warranty_mappings = {}
    picture_info_tbl = {}
            
    def get_acc_item_number_list(item_number):
        result = []
        for acc_dict in StagingErpData.accessories.values():
            if item_number == acc_dict['item_number']:
                result.append(acc_dict['acc_item_number'])
        return result

    def get_sku_from_item_number(item_number):
        if item_number in StagingErpData.item_number_sku_map.keys():
            return StagingErpData.item_number_sku_map[item_number]
    
    
class StagingRwsData:
    products = {}
    managed_data_tbl = {}
    marketing_copy_tbl = {}
    marketing_copy_feature_tbl = {}
    marketing_copy_image_feature_tbl = {}
    related_items = {}
    this_item_in_other_color = {}
    videos = {}
    media_images = {}
    media_pdfs = {}
    picture_info_tbl = {}
    spec_table_as_key_value_pairs_tbl = {}

    brands = {}
    abc_categories = {}
    haw_categories = {}

    sku_brand_map = {}
    new_product_item_key_list = []
    checked_item_key_list = []
        
    def get_rws_brand(brand_code):
        brand = None
        if brand_code in StagingRwsData.brands.keys():
            brand = StagingRwsData.brands[brand_code]
        return brand

    def get_rws_category(category_code):
        category = None
        if category_code in StagingRwsData.abc_categories.keys():
            category = StagingRwsData.abc_categories[category_code]
        elif category_code in StagingRwsData.haw_categories.keys():
            category = StagingRwsData.haw_categories[category_code]        
        
        return category
    
    def is_rws_category(rws_product):
        result = False
        category = StagingRwsData.get_rws_category(rws_product.category_code)
        if category and (category['NOP_ID'] != 5000):
            result = True
        return result

    def get_item_key_list(sku):
        result = []
        for item_key in StagingRwsData.products.keys():
            rws_brand_code, rws_sku = item_key.split(':')
            if sku == rws_sku:
                result.append(item_key)

        return result

    def get_rws_product_from_sku(sku):
        result = None
        rws_item_key_list = StagingRwsData.get_item_key_list(sku)
        if len(rws_item_key_list) == 1:
            item_key = rws_item_key_list[0]
            rws_product_dict = StagingRwsData.products[item_key]
            rws_managed_data_dict = StagingRwsData.managed_data_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.managed_data_tbl.keys() else None
            rws_marketing_copy_array = StagingRwsData.marketing_copy_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.marketing_copy_tbl.keys() else None
            rws_marketing_copy_feature_array = StagingRwsData.marketing_copy_feature_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.marketing_copy_feature_tbl.keys() else None
            rws_marketing_copy_image_feature_array = StagingRwsData.marketing_copy_image_feature_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.marketing_copy_image_feature_tbl.keys() else None
            result = RwsProductData(rws_product_dict, rws_managed_data_dict, rws_marketing_copy_array, rws_marketing_copy_feature_array, rws_marketing_copy_image_feature_array)                            
        elif len(rws_item_key_list) > 1:
            rws_product = None
            for item_key in StagingRwsData.get_item_key_list(sku):
                rws_product_dict = StagingRwsData.products[item_key]
                rws_managed_data_dict = StagingRwsData.managed_data_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.managed_data_tbl.keys() else None
                rws_marketing_copy_array = StagingRwsData.marketing_copy_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.marketing_copy_tbl.keys() else None
                rws_marketing_copy_feature_array = StagingRwsData.marketing_copy_feature_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.marketing_copy_feature_tbl.keys() else None
                rws_marketing_copy_image_feature_array = StagingRwsData.marketing_copy_image_feature_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.marketing_copy_image_feature_tbl.keys() else None
                rws_product = RwsProductData(rws_product_dict, rws_managed_data_dict, rws_marketing_copy_array, rws_marketing_copy_feature_array, rws_marketing_copy_image_feature_array)
                erp_product = StagingErpData.products[sku] if sku in StagingErpData.products.keys() else None
                if erp_product:
                    rws_brand = StagingRwsData.brands[rws_product.brand_code] if rws_product.brand_code in StagingRwsData.brands.keys() else None
                    erp_brand_code = None
                    if erp_product.sku in StagingErpData.product_manufacturer_mappings.keys():
                        erp_brand_code = StagingErpData.product_manufacturer_mappings[erp_product.sku]                    
                    if rws_brand and erp_brand_code:
                        if rws_brand['erp_brand_code'] == erp_brand_code:
                            result = rws_product
                            break
                else:
                    if item_key not in StagingRwsData.checked_item_key_list:
                        result = rws_product
        else:
            for item_key, rws_product_dict in StagingRwsData.products.items():
                if rws_product_dict['manufacturer_pn'] == sku:
                    rws_managed_data_dict = StagingRwsData.managed_data_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.managed_data_tbl.keys() else None
                    rws_marketing_copy_array = StagingRwsData.marketing_copy_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.marketing_copy_tbl.keys() else None
                    rws_marketing_copy_feature_array = StagingRwsData.marketing_copy_feature_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.marketing_copy_feature_tbl.keys() else None
                    rws_marketing_copy_image_feature_array = StagingRwsData.marketing_copy_image_feature_tbl[rws_product_dict['id']] if rws_product_dict['id'] in StagingRwsData.marketing_copy_image_feature_tbl.keys() else None
                    result = RwsProductData(rws_product_dict, rws_managed_data_dict, rws_marketing_copy_array, rws_marketing_copy_feature_array, rws_marketing_copy_image_feature_array)
                    break                                             

        if result:
            StagingRwsData.checked_item_key_list.append(result.item_key)

        return result

    def get_product_media_image_id_list(pid):
        result = []
        for id, media in StagingRwsData.media_images.items():
            if pid == media['rws_product_id']:
                result.append(id)
        return result

    def get_spec_key_value_list(pid):
        result = []
        for id, spec_table in StagingRwsData.spec_table_as_key_value_pairs_tbl.items():
            if spec_table['rws_product_id'] == pid:
                result.append(spec_table)
        return result

    def get_picture_info_list(item_key):
        result = []
        for picture_info in StagingRwsData.picture_info_tbl.values():
            if picture_info['item_key'] == item_key:
                result.append(picture_info)
        return result
    

class StagingProduct:

    def __init__(self, sku):
        self.erp_product = StagingErpData.products[sku] if sku in StagingErpData.products.keys() else None 
        self.second_product = StagingRwsData.get_rws_product_from_sku(sku)
        
    def get_rws_product(sku):
        return StagingRwsData.get_rws_product_from_sku(sku)

    def get_pr_file_discount(self, stores):
        for pr in StagingErpData.pr_file_discounts.values():
            if self.sku == pr['sku']:
                if (stores['abc'] and pr['is_abc_discount']) or (stores['haw'] and pr['is_haw_discount']):
                    return pr['discount_amount']
        return 0


    @property
    def is_active_in_erp(self):
        if self.erp_product:
            return True
        else:
            return False

    @property
    def name(self):
        if self.erp_product and self.erp_product.name:
            result = self.erp_product.name        
        elif self.second_product:
            result = self.second_product.name
        else:
            result = None

        return result

    @property
    def short_description(self):
        if self.second_product and self.second_product.short_description:
            result = self.second_product.short_description
        elif self.erp_product:
            result = self.erp_product.short_description
        else:
            result = None

        return result
        
    @property
    def short_description_features(self):
        if self.second_product and self.second_product.short_description_features:
            result = self.second_product.short_description_features        
        else:
            result = None

        return result
    
    @property
    def full_description(self):
        result = None
        if self.second_product and self.second_product.full_description:
            result = self.second_product.full_description
        elif self.erp_product:
            result = self.erp_product.fact_tag

        return result    
    
    @property
    def image_feature_html(self):
        result = None
        if self.second_product and self.second_product.image_feature_html:
            result = self.second_product.image_feature_html
        
        return result
	
    @property
    def hierachical_feature_html(self):
        result = None
        if self.second_product and self.second_product.hierachical_feature_html:
            result = self.second_product.hierachical_feature_html
        
        return result

    @property
    def paragraph_description_html(self):
        result = None
        if self.second_product and self.second_product.paragraph_description_html:
            result = self.second_product.paragraph_description_html
        
        return result
    
    @property
    def on_abc_store(self):
        result = None
        if self.erp_product and self.erp_product.on_abc_store is not None:
            result = self.erp_product.on_abc_store
        elif self.second_product:
            result = StagingRwsData.brands[self.second_product.brand_code]['abc']

        # if self.second_product:
        #     result = StagingRwsData.brands[self.second_product.brand_code]['abc']
        # elif self.erp_product:
        #     result = self.erp_product.on_abc_store
        
        return result
    
    @property
    def on_haw_store(self):
        result = None
        if self.erp_product and self.erp_product.on_haw_store is not None:
            result = self.erp_product.on_haw_store
        elif self.second_product:
            result = StagingRwsData.brands[self.second_product.brand_code]['new_haw']

        # if self.second_product:
        #     result = StagingRwsData.brands[self.second_product.brand_code]['new_haw']
        # elif self.erp_product:
        #     result = self.erp_product.on_haw_store
        
        return result
        
    @property
    def on_abc_clearance_store(self):
        if self.erp_product and self.erp_product.on_abc_clearance_store is not None:
            result = self.erp_product.on_abc_clearance_store
        elif self.second_product:
            result = self.second_product.on_abc_clearance_store
        else:
            result = None

        return result
    
    @property
    def on_haw_clearance_store(self):
        if self.erp_product and self.erp_product.on_haw_clearance_store is not None:
            result = self.erp_product.on_haw_clearance_store
        elif self.second_product:
            result = self.second_product.on_haw_clearance_store
        else:
            result = None

        return result
    
    @property
    def sku(self):
        if self.erp_product and self.erp_product.sku is not None:
            result = self.erp_product.sku
        elif self.second_product:
            result = self.second_product.sku
        else:
            result = None

        return result
    
    @property
    def manufacturer_number(self):
        if self.erp_product and self.erp_product.manufacturer_number is not None:
            result = self.erp_product.manufacturer_number
        elif self.second_product:
            result = self.second_product.manufacturer_number
        else:
            result = None

        return result
    
    @property
    def erp_manufacturer_name(self):
        result = ''

        if self.erp_product:
            brand_code = ''
            if self.erp_product.sku in StagingErpData.product_manufacturer_mappings.keys():
                brand_code = StagingErpData.product_manufacturer_mappings[self.erp_product.sku]
            
            manufacturer = None
            if brand_code and brand_code in StagingErpData.manufacturers.keys():
                manufacturer = StagingErpData.manufacturers[brand_code]
            
            if manufacturer:
                result = manufacturer['name']
        
        return result.upper()

    @property
    def manufacturer_name(self):
        result = ''

        if self.erp_manufacturer_name:
            result = self.erp_manufacturer_name
        elif self.second_product:
            result = self.second_product.manufacturer_name
        
        return dup_brands_filter(result)

    @property
    def buy_button_disabled(self):
        if self.erp_product and self.erp_product.buy_button_disabled is not None:
            result = self.erp_product.buy_button_disabled
        elif self.second_product:
            result = self.second_product.buy_button_disabled
        else:
            result = None

        return result
    
    @property
    def weight(self):
        if self.erp_product and self.erp_product.weight is not None:
            result = self.erp_product.weight
        elif self.second_product:
            result = self.second_product.weight
        else:
            result = None

        return result
    
    @property
    def length(self):
        if self.erp_product and self.erp_product.length is not None:
            result = self.erp_product.length
        elif self.second_product:
            result = self.second_product.length
        else:
            result = None

        return result
    
    @property
    def pickup_in_store(self):
        if self.erp_product:
            result = self.erp_product.pickup_in_store
        elif self.second_product:
            result = self.second_product.pickup_in_store
        else:
            result = None

        return result
    
    @property
    def is_new(self):
        if self.erp_product and self.erp_product.is_new is not None:
            result = self.erp_product.is_new
        elif self.second_product:
            result = self.second_product.is_new
        else:
            result = None

        return result
    
    @property
    def new_end_date(self):
        if self.erp_product and self.erp_product.new_end_date is not None:
            result = self.erp_product.new_end_date
        elif self.second_product:
            result = self.second_product.new_end_date
        else:
            result = None

        return result
    
    @property
    def limited_stock_end_date(self):
        if self.erp_product and self.erp_product.limited_stock_end_date is not None:
            result = self.erp_product.limited_stock_end_date
        elif self.second_product:
            result = self.second_product.limited_stock_end_date
        else:
            result = None

        return result
    
    @property
    def base_price(self):
        if self.erp_product and self.erp_product.base_price is not None:
            result = self.erp_product.base_price
        elif self.second_product:
            result = self.second_product.base_price
        else:
            result = None

        return result
    
    @property
    def display_price(self):
        if self.erp_product and self.erp_product.display_price is not None:
            result = self.erp_product.display_price
        elif self.second_product:
            result = self.second_product.display_price
        else:
            result = None

        return result
    
    @property
    def cart_price(self):
        if self.erp_product and self.erp_product.cart_price is not None:
            result = self.erp_product.cart_price
        elif self.second_product:
            result = self.second_product.cart_price
        else:
            result = None

        return result
    
    @property
    def use_pair_pricing(self):
        if self.erp_product and self.erp_product.use_pair_pricing is not None:
            result = self.erp_product.use_pair_pricing
        elif self.second_product:
            result = self.second_product.use_pair_pricing
        else:
            result = None

        return result
    
    @property
    def price_bucket(self):
        if self.erp_product and self.erp_product.price_bucket is not None:
            result = self.erp_product.price_bucket
        elif self.second_product:
            result = self.second_product.price_bucket
        else:
            result = None

        return result
    
    @property
    def can_use_ups(self):
        if self.erp_product and self.erp_product.can_use_ups is not None:
            result = self.erp_product.can_use_ups        
        else:
            result = 0

        return result
    
    @property
    def isam_item_number(self):
        if self.erp_product:
            result = self.erp_product.item_number
        else:
            result = None

        return result
    
    @property
    def second_sku(self):
        if self.second_product:
            result = self.second_product.sku
        else:
            result = None

        return result
    
    @property
    def upc(self):
        if self.second_product and self.second_product.upc:
            result = self.second_product.upc
        elif self.erp_product:
            result = self.erp_product.upc
        else:
            result = None

        return result
    
    @property
    def fact_tag(self):
        if self.erp_product:
            result = self.erp_product.fact_tag
        else:
            result = None

        return result

    @property
    def is_add_to_cart(self):
        if self.price_bucket:
            return self.erp_product.is_add_to_cart
        else:
            return False

    @property
    def is_requires_login(self):
        if self.price_bucket:
            return self.erp_product.is_requires_login
        else:
            return False

    @property
    def colors(self):
        result = []
        if self.erp_product and self.erp_product.color:
            result.append(self.erp_product.color.upper())
        if self.second_product and self.second_product.colors:
            if result:
                if result[0] in self.second_product.colors:
                    result = self.second_product.colors
                else:
                    result.extend(self.second_product.colors)
            else:
                result = self.second_product.colors

        return result
        
    @property
    def screen_size(self):
        result = None

        if self.second_product and self.second_product.screen_size:
            result = self.second_product.screen_size

        return result

    @property
    def is_wifi_enabled(self):
        result=None
        if self.second_product:
            result = self.second_product.is_wifi_enabled
        return result

    @property
    def resolution(self):
        result = None
        if self.second_product:
            result = self.second_product.resolution
        return result

    @property
    def burner_type(self):
        result = None
        if self.second_product:
            result = self.second_product.burner_type
        return result

    @property
    def refrigerator_has_ice_maker(self):
        result = None

        if self.second_product:
            result = self.second_product.refrigerator_has_ice_maker

        return result
    
    @property
    def refrigerator_is_counter_depth(self):
        result = None
        if self.second_product:
            result = self.second_product.refrigerator_is_counter_depth
        return result
    
    @property
    def cooking_oven_nmbr_of_cooktop_elmt(self):
        result = None
        if self.second_product:
            result = self.second_product.cooking_oven_nmbr_of_cooktop_elmt
        return result
    
    @property
    def dish_has_stainless_steel_tub(self):
        result = None
        if self.second_product:
            result = self.second_product.dish_has_stainless_steel_tub
        return result
        
    @property
    def laund_has_steam(self):
        result = None
        if self.second_product:
            result = self.second_product.laund_has_steam
        return result
    
    @property
    def cooking_oven_nmbr_of_burners(self):
        result = None
        if self.second_product:
            result = self.second_product.cooking_oven_nmbr_of_burners
        return result

    @property
    def energy_star_compliant(self):
        result = None
        if self.second_product:
            result = self.second_product.energy_star_compliant
        return result
    
    
    @property
    def depth(self):
        result = 0

        if self.erp_product and self.erp_product.length is not None:
            result = self.erp_product.length
        elif self.second_product:
            result = self.second_product.length
        
        result = round(result, 2)

        return result
    
    @property
    def depth_range(self):
        result = None
        if self.depth and self.depth > 1:
            result = find_range_and_index(
                    self.depth, 5, '5 and Under', 80, '80 and Above', 5, 'to', ''
                )
        return result
            
    @property
    def width(self):
        result = 0

        if self.erp_product and self.erp_product.width is not None:
            result = self.erp_product.width
        elif self.second_product:
            result = self.second_product.width
        
        result = round(result, 2)            

        return result
    
    @property
    def width_range(self):
        result = None
        if self.width and self.width > 1:
            result = find_range_and_index(
                    self.width, 5, '5 and Under', 100, '100 and Above', 5, 'to', ''
                )
        return result
        
    @property
    def height(self):
        result = 0
        
        if self.erp_product and self.erp_product.height is not None:
            result = self.erp_product.height
        elif self.second_product:
            result = self.second_product.height

        result = round(result, 2)

        return result    
    
    @property
    def height_range(self):
        result = None
        if self.height and self.height > 1:
            result = find_range_and_index(
                    self.height, 5, '5 and Under', 90, '90 and Above', 5, 'to', ''
                )
        return result
    
    
    @property
    def capacity(self):
        result = None

        if self.second_product:
            result = self.second_product.capacity

        return result
    
    @property
    def capacity_range(self):
        result = None

        if self.capacity:
            result = find_range_and_index(
                self.capacity, 3.0, '3.0 and Under Cu Ft', 30.0, '30.0 and Above', 3.0, 'to', ' Cu Ft'
            )

        return result

    @property
    def dish_decibel_level(self):
        result = None

        if self.second_product:
            result = self.second_product.dish_decibel_level

        return result
    
    @property
    def dish_decibel_level_range(self):
        result = None

        if self.dish_decibel_level:
            result = find_range_and_index(
                self.dish_decibel_level, 40, '40 and Under dB', 60, '60 and Above', 5.0, 'to', ' dB'
            )

        return result
    
    @property
    
    def laund_rpm(self):
        result = None
        if self.second_product:
            result = self.second_product.laund_rpm
        return result    
    
    @property
    def laund_rpm_range(self):
        result = None
        if self.laund_rpm:
            result = find_range_and_index(
                self.laund_rpm, 600, '600 and Under', 1300, '1300 and Above', 100, 'to', ''
            )
        return result



def dup_brands_filter(brand: str) -> str:
    result = brand

    for k, v in dup_brands_dict.items():
        if isinstance(v,str):
            if brand.upper() == v.upper():
                result = k
        elif isinstance(v,list):
            upper_v=[i.upper() for i in v]
            if brand.upper() in upper_v:
                result = k

    return result

######## duplicated brands dictionary structure ########
# key: standard brand name, values: similar brand list
########################################################
dup_brands_dict = {
    "ADESSO": [
        "ADESSO, INC."
    ],
    "AUDIO-TECHNICA": [
        "AUDIO-TECHNICA US INC"
    ],
    "BEATS": [
        "BEATS BY DR.DRE"
    ],
    "BLACK AND DECKER": [
        "BLACK + DECKER",
        "BLACK & DECKER"
    ],
    "BLUE STAR": [
        "BLUESTAR"
    ],
    "CHAR-BROIL": [
        "CHAR BROIL"
    ],
    "COMFORT-AIRE": [
        "COMFORT AIRE"
    ],
    "CROCK-POT": [
        "CROCK POT",
        "CROCKPOT"
    ],
    "DEAL PARTNERS": [
        "DEAL PARTNERS, LLC"
    ],
    "KLASSICO GAMES": [
        "KLASSICO GAME COMPANY"
    ],
    "GE APPLIANCES": [
        "GE",
        "GENERAL ELECTRIC"
    ],
    "FRIGIDAIRE": [
        "FRIGIDIARE"
    ],
    "LIBERTY FURNITURE": [
        "LIBERT FURNITURE"
    ],
    "LIEBHERR": [
        "LIBHERR"
    ],
    "MIELE": [
        "MIELE APPLIANCE DIST. INC"
    ],
    "MR. COFFEE": [
        "MR COFFEE"
    ],
    "Nectar": [
        "NECTAR BRAND LLC"
    ],
    "NIKON": [
        "NIKON INC"
    ],
    "OTTERBOX": [
        "OTTER BOX"
    ],
    "PROGRESSIVE": [
        "PROGRESSIVE FURNITURE INC"
    ],
    "QFX": [
        "QFX, INC."
    ],
    "ROWONE": [
        "ROW ONE"
    ],
    "SCOTT LIVING BY RESTONIC": [
        "SCOTT LIVING"
    ],
    "SONY": [
        "SONY HI-FI"
    ],
    "SUBZERO": [
        "SUB ZERO",
        "SUB-ZERO"
    ],
    "SUNBRITE TV": [
        "SUNBRITETV"
    ],
    "U-LINE": [
        "ULINE"
    ],
    "VENT-A-HOOD": [
        "VENTAHOOD"
    ],
    "VIKING": [
        "VIKING RANGE, LLC"
    ],
    "WEBER": [
        "WEBER SUMMIT",
        "WEBER SUMMIT GRILL CENTER"
    ],
}
