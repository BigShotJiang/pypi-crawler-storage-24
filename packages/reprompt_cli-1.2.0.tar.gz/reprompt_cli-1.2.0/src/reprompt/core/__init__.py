"""Core domain models and logic."""
