from eve_sde.models.map import SolarSystem

from django import forms

from drifters.app_settings import DRIFTERS_JOVE_OBSERVATORIES

from .models import Wormhole


class WormholeForm(forms.ModelForm):
    class Meta:
        model = Wormhole
        fields = ["solar_system", "complex", "mass", "lifetime", "bookmarked_k", "bookmarked_w"]

    def __init__(self, user=None, **kwargs):
        self.region = kwargs.pop('region', None)
        self.solar_system = kwargs.pop('solar_system', None)
        super().__init__(**kwargs)
        if self.region:
            self.fields['solar_system'].queryset = SolarSystem.objects.filter(name__in=DRIFTERS_JOVE_OBSERVATORIES, constellation__region=self.region)
        elif self.solar_system:
            self.fields['solar_system'].queryset = SolarSystem.objects.filter(id=self.solar_system.id)
        else:
            self.fields['solar_system'].queryset = SolarSystem.objects.filter(name__in=DRIFTERS_JOVE_OBSERVATORIES)
