from unittest.mock import Mock, patch

from django.forms import ModelChoiceField

from allianceauth.utils.testing import NoSocketsTestCase

from drifters.app_settings import DRIFTERS_JOVE_OBSERVATORIES
from drifters.forms import WormholeForm


class TestWormholeForm(NoSocketsTestCase):
    @patch("drifters.forms.SolarSystem")
    def test_init_uses_region_filter(self, mock_solar_system) -> None:
        queryset = Mock()
        mock_solar_system.objects.filter.return_value = queryset
        region = Mock()

        form = WormholeForm(region=region)
        solar_system_field = form.fields["solar_system"]
        assert isinstance(solar_system_field, ModelChoiceField)

        self.assertEqual(solar_system_field.queryset, queryset.all.return_value)
        mock_solar_system.objects.filter.assert_called_once_with(
            name__in=DRIFTERS_JOVE_OBSERVATORIES,
            constellation__region=region,
        )

    @patch("drifters.forms.SolarSystem")
    def test_init_uses_solar_system_filter(self, mock_solar_system) -> None:
        queryset = Mock()
        mock_solar_system.objects.filter.return_value = queryset
        solar_system = Mock(id=301)

        form = WormholeForm(solar_system=solar_system)
        solar_system_field = form.fields["solar_system"]
        assert isinstance(solar_system_field, ModelChoiceField)

        self.assertEqual(solar_system_field.queryset, queryset.all.return_value)
        mock_solar_system.objects.filter.assert_called_once_with(id=301)

    @patch("drifters.forms.SolarSystem")
    def test_init_uses_default_observatory_filter(self, mock_solar_system) -> None:
        queryset = Mock()
        mock_solar_system.objects.filter.return_value = queryset

        form = WormholeForm()
        solar_system_field = form.fields["solar_system"]
        assert isinstance(solar_system_field, ModelChoiceField)

        self.assertEqual(solar_system_field.queryset, queryset.all.return_value)
        mock_solar_system.objects.filter.assert_called_once_with(name__in=DRIFTERS_JOVE_OBSERVATORIES)
