from datetime import datetime, timezone as dt_timezone
from unittest.mock import Mock, patch

from allianceauth.utils.testing import NoSocketsTestCase

from drifters.views import generate_channel_motd_1, generate_channel_motd_2


class TestViewHelpers(NoSocketsTestCase):
    def test_generate_channel_motd_1_contains_core_sections(self) -> None:
        output = generate_channel_motd_1()

        self.assertIn("Active Metro Lines", output)
        self.assertIn("bookmarkFolder:", output)
        self.assertIn("TRAVELs WITH THE WH METRO", output)

    @patch("drifters.views.timezone.now")
    @patch("drifters.views.DriftersConfiguration")
    @patch("drifters.views.Wormhole")
    def test_generate_channel_motd_2_without_holes_only_footer(
        self,
        mock_wormhole: Mock,
        _mock_config: Mock,
        mock_now: Mock,
    ) -> None:
        now = datetime(2026, 3, 25, 13, 0, tzinfo=dt_timezone.utc)
        mock_now.return_value = now

        mock_wormhole.Complexes = ["Sentinel"]
        exists_qs = Mock()
        exists_qs.exists.return_value = False
        mock_wormhole.active_public_holes.filter.return_value = exists_qs

        output = generate_channel_motd_2()

        self.assertIn("Updated 2026-03-25 13:00:00+00:00", output)
        self.assertNotIn("Sentinel", output)

    @patch("drifters.views.route_length")
    @patch("drifters.views.systems_range")
    @patch("drifters.views.timezone.now")
    @patch("drifters.views.DriftersConfiguration")
    @patch("drifters.views.Wormhole")
    def test_generate_channel_motd_2_with_two_systems_adds_complex_section(
        self,
        mock_wormhole: Mock,
        mock_config: Mock,
        mock_now: Mock,
        mock_systems_range: Mock,
        mock_route_length: Mock,
    ) -> None:
        now = datetime(2026, 3, 25, 13, 0, tzinfo=dt_timezone.utc)
        mock_now.return_value = now
        mock_systems_range.return_value = [30000142, 30002187]
        mock_route_length.side_effect = [3, 5]

        mock_wormhole.Complexes = ["Sentinel"]

        system_a = Mock(id=30000142)
        system_a.__str__ = Mock(return_value="Jita")
        system_b = Mock(id=30002187)
        system_b.__str__ = Mock(return_value="Amarr")

        hole_a = Mock(system=system_a, formatted_lifetime_motd="<font>Fresh 70%</font>")
        hole_b = Mock(system=system_b, formatted_lifetime_motd="<font>EOL 10%</font>")

        exists_qs = Mock()
        exists_qs.exists.return_value = True
        mock_wormhole.active_public_holes.filter.side_effect = [exists_qs, [hole_a], [hole_b]]

        mock_config.get_solo.return_value.motd_systems.all.return_value = [system_a, system_b]

        output = generate_channel_motd_2()

        self.assertIn("Sentinel", output)
        self.assertIn("Jita", output)
        self.assertIn("Amarr", output)
        self.assertIn("3J", output)
        self.assertIn("5J", output)
