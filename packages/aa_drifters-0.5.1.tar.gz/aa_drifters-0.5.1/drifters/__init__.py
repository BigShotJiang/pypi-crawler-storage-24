"""
Drifter wormhole tracker/manager plugin for Alliance Auth.
"""

__version__ = "0.5.1"
__title__ = "AADrifters"
__url__ = "https://gitlab.com/tactical-supremacy/aa-drifters"
