You are scoring a coding agent session for training data quality. Read the full conversation trace and give a holistic quality score (1-5).

## How to read the trace

The user's messages are your primary signal. After each block of agent work, the user's next message is implicit feedback:

- **Positive**: "great", "thanks", "perfect", user confirms and moves on to a new task
- **Negative**: "no", "wrong", "that's broken", user corrects or re-asks the same thing
- **Process criticism**: "too slow", "you only needed X", user says approach was wasteful
- **Redirect**: user abandons the current direction, asks for something different
- **Silence** (session ended): ambiguous — user may be satisfied or may have given up

Pay special attention to:
- The **final user message** — strongest signal about overall quality
- Any corrections or negative feedback mid-session
- Whether the user explicitly confirmed success

## Discovered vs caused

When an agent runs tests/validation and failures are reported: did the problem exist BEFORE the agent acted, or did the agent CREATE it?

- Agent DISCOVERED a pre-existing problem → the diagnostic step is fine. The agent found the issue, not caused it.
- Agent CAUSED a new problem (wrote buggy code, then tests fail) → the action that introduced the bug is a real failure.

## Overall Quality (1-5)

5 = Excellent: Clear non-trivial task. Verified outcome (tests pass, user confirmed). Rich multi-step work. No negative feedback.
4 = Good: Clear task, useful outcome. Meaningful tool usage. No negative feedback from user.
3 = Average: Routine task. Partial or unverified outcome. No strong signal either way.
2 = Low: Failed or unclear outcome. User expressed dissatisfaction, had to redirect, or agent did minimal work.
1 = Poor: No real task, trivially short, agent did nothing useful, or user abandoned.

## Outcome (1-5)

Did the agent's work produce the desired result?

5 = Fully verified success (tests pass, build works, user confirmed)
4 = Likely success but not fully verified
3 = Partial — some work done, outcome unclear
2 = Failed — the work didn't produce what was asked for
1 = Nothing was accomplished

## Intent (1-5)

Did the agent pursue the right goal in the right way?

5 = Perfectly on track — efficient, focused, no wasted effort
4 = On track with minor inefficiencies
3 = Generally right direction but notable waste or confusion
2 = Significantly off track — wrong approach, excessive exploration, user had to redirect
1 = Completely missed the goal

## Taste

Taste surfaces when the user chooses between valid alternatives:

- **Option selection**: Agent presents options, user picks one
- **Style feedback**: "make it more concise", "use approach X" — not wrong, just preferred differently

Record when detected.

## Examples

### Example 1: Clean execution, user satisfied
User task: "Fix the failing unit tests in auth.py"
Agent: read file → run tests (3 fail) → edit → run tests (1 fail) → edit → run tests (all pass)
User response: "great, thanks!"

{"quality": 5, "reasoning": "Agent systematically fixed all 3 failures. User explicitly confirmed satisfaction. Test failures during debugging were DISCOVERED (pre-existing), not caused.", "outcome": 5, "intent": 5, "taste": {"detected": false}}

### Example 2: Task completed but agent caused a bug along the way
User task: "Add pagination to the /users endpoint"
Agent: read routes → edit (add pagination) → tests fail (2 new failures) → fix off-by-one → tests pass
User response: [none — session ended]

{"quality": 4, "reasoning": "Agent completed the task but introduced a bug in the first edit (tests passed BEFORE, failed AFTER — agent-caused). Self-corrected and all tests passed in the end. No user feedback.", "outcome": 4, "intent": 4, "taste": {"detected": false}}

### Example 3: User explicitly criticized the process
User task: "Add retry logic to the API client"
Agent: read 6 files (api_client.py, config.py, setup.py, README, CHANGELOG, docker-compose.yml) → edit api_client.py
User response: "that took way too long, you only needed the api client"

{"quality": 2, "reasoning": "The edit succeeded but the user explicitly criticized the process — 5 unnecessary file reads wasted time. User's negative feedback is a strong signal.", "outcome": 4, "intent": 2, "taste": {"detected": false}}

### Example 4: Taste signal — user chose between valid options
User task: "Set up the translation pipeline"
Agent: read config → analyze dependencies → presents two options
User response: "option 1, so if Gemini fails we still have Google"

{"quality": 3, "reasoning": "Early exploration, no outcome yet. User's choice is a taste signal — both options are valid, user prefers redundancy/reliability.", "outcome": 3, "intent": 4, "taste": {"detected": true, "type": "option_selection", "description": "User chose multi-provider with fallback over single-provider."}}

### Example 5: Agent did nothing
User task: "Explore the Gemini integration and find all LLM usage"
Agent: [0 tool calls — no file reads, no grep, no codebase exploration]
User response: repeats the request for part 2

{"quality": 1, "reasoning": "Agent made zero tool calls on a task that explicitly required codebase exploration. User had to re-ask. No work was done.", "outcome": 1, "intent": 1, "taste": {"detected": false}}
