---
name: code
description: "Enhanced coding with automatic mirdan quality orchestration"
argument-hint: "Describe what to build"
model: inherit
allowed-tools: mcp__mirdan__enhance_prompt, mcp__mirdan__validate_code_quality, mcp__mirdan__get_quality_standards, mcp__mirdan__validate_quick, mcp__sequential-thinking__sequentialthinking, mcp__enyal__enyal_recall, mcp__enyal__enyal_remember, mcp__enyal__enyal_traverse, mcp__context7__resolve-library-id, mcp__context7__query-docs, Read, Write, Edit, Glob, Grep, Bash
---

# /code — Quality-Orchestrated Coding

Execute coding tasks with automatic quality enforcement via mirdan.

## Dynamic Context

Recent changes:
```
!`git diff --stat HEAD 2>/dev/null | tail -5`
```

## Workflow

1. **Analyze** — Call `mcp__mirdan__enhance_prompt` with the user's task to get:
   - Detected language and frameworks
   - Quality requirements to follow
   - Security sensitivity (touches_security)
   - A session_id for the task

2. **Recall** — Call `mcp__enyal__enyal_recall` with `input: { query: "<task description>" }` to load project conventions, past decisions, and relevant patterns before writing any code

3. **Standards** — Call `mcp__mirdan__get_quality_standards` for the detected language/framework

4. **Think** — Use `mcp__sequential-thinking__sequentialthinking` to plan the implementation approach: break down the task, identify components, dependencies, and edge cases before writing code

5. **Implement** — Write the code following the quality_requirements from step 1 and conventions from step 2

6. **Validate** — Call `mcp__mirdan__validate_code_quality` on each changed file:
   - Set `check_security=true` if touches_security was flagged
   - Fix all errors immediately
   - Note warnings for review

7. **Persist** — Call `mcp__enyal__enyal_remember` with `input: { content: "<knowledge>", content_type: "<type>", tags: [...] }` to store any new decisions, patterns, or conventions discovered during implementation

8. **Complete** — Confirm:
   - All validation errors resolved
   - Quality requirements from enhance_prompt satisfied
   - No placeholder code (AI001) or hallucinated imports (AI002)
