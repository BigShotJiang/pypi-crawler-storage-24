"""
rtlinux Runtime — AI assistant loop running inside an rtlinux container.

This module runs INSIDE the built image on startup.
It reads /opt/rtlinux/template.json and:
  1. Connects to Wire mesh
  2. Starts scheduled tasks (if configured)
  3. Listens for mpop messages on a Unix socket
  4. Calls the configured LLM for every request

Entry point: python3 -m rtlinux.runtime  (or /opt/rtlinux/runtime.py)
"""

import json
import os
import sys
import time
import socket
import threading
import subprocess
import re
from pathlib import Path

CONFIG_PATH = os.environ.get("RTLINUX_CONFIG", "/opt/rtlinux/template.json")
LOG_PATH    = os.environ.get("RTLINUX_LOG",    "/opt/rtlinux/assistant.log")
SOCK_PATH   = "/tmp/rtlinux-{name}.sock"

_INTERVAL_RE = re.compile(r"(\d+)\s*([mhd])", re.IGNORECASE)


# ── Logging ──────────────────────────────────────────────────────────

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
        with open(LOG_PATH, "a") as f:
            f.write(line + "\n")
    except Exception:
        pass


# ── LLM call ─────────────────────────────────────────────────────────

def call_llm(config: dict, user_prompt: str) -> str:
    """Call the configured LLM model."""
    model = config.get("model", "claude-sonnet-4-6")
    system = config.get("system_prompt", "You are a helpful assistant.")
    max_tokens = config.get("max_tokens", 2048)

    # Anthropic / Claude
    if "claude" in model:
        try:
            import anthropic
            api_key = os.environ.get("ANTHROPIC_API_KEY", "")
            if not api_key:
                return "Error: ANTHROPIC_API_KEY not set"
            client = anthropic.Anthropic(api_key=api_key)
            resp = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user_prompt}],
            )
            return resp.content[0].text
        except Exception as e:
            return f"Error (claude): {e}"

    # OpenAI / GPT
    if "gpt" in model:
        try:
            import openai
            client = openai.OpenAI(api_key=os.environ.get("OPENAI_API_KEY", ""))
            resp = client.chat.completions.create(
                model=model,
                max_tokens=max_tokens,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user_prompt},
                ],
            )
            return resp.choices[0].message.content
        except Exception as e:
            return f"Error (openai): {e}"

    # Ollama (local)
    if model.startswith("ollama/"):
        try:
            import urllib.request
            ollama_model = model.split("/", 1)[1]
            ollama_url = os.environ.get("OLLAMA_URL", "http://localhost:11434")
            payload = json.dumps({
                "model": ollama_model,
                "prompt": f"{system}\n\n{user_prompt}",
                "stream": False,
            }).encode()
            req = urllib.request.Request(
                f"{ollama_url}/api/generate",
                data=payload,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read())["response"]
        except Exception as e:
            return f"Error (ollama): {e}"

    return f"Error: unsupported model '{model}'"


# ── Schedule ─────────────────────────────────────────────────────────

def _parse_interval(s: str) -> int:
    m = _INTERVAL_RE.search(s)
    if not m:
        return 0
    n, unit = int(m.group(1)), m.group(2).lower()
    return n * {"m": 60, "h": 3600, "d": 86400}[unit]


def run_schedule_loop(config: dict):
    """Background thread: run scheduled prompts on interval."""
    schedule = config.get("schedule", "")
    task     = config.get("schedule_task", "")
    if not schedule or not task:
        return

    interval = _parse_interval(schedule)
    if not interval:
        log(f"Schedule: could not parse interval '{schedule}'")
        return

    log(f"Schedule: {schedule} ({interval}s) — task: {task[:60]}")
    while True:
        time.sleep(interval)
        log(f"Running scheduled task...")
        try:
            result = call_llm(config, task)
            log(f"Scheduled result: {result[:300]}")
            # Optionally: write to file, send via mpop, etc.
            out_path = f"/opt/rtlinux/schedule_output.txt"
            with open(out_path, "w") as f:
                f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}]\n{result}\n")
        except Exception as e:
            log(f"Schedule error: {e}")


# ── Message server ────────────────────────────────────────────────────

def handle_connection(conn: socket.socket, config: dict):
    """Handle a single mpop message connection."""
    try:
        data = b""
        while True:
            chunk = conn.recv(4096)
            if not chunk:
                break
            data += chunk
            if b"\x04" in data or b"\n" in data:
                break
        msg = data.replace(b"\x04", b"").decode(errors="replace").strip()
        if not msg:
            conn.close()
            return
        log(f"Message: {msg[:100]}")
        reply = call_llm(config, msg)
        conn.sendall(reply.encode() + b"\x04")
    except Exception as e:
        log(f"Connection error: {e}")
        try:
            conn.sendall(f"Error: {e}".encode() + b"\x04")
        except Exception:
            pass
    finally:
        conn.close()


def run_message_server(config: dict):
    """Main loop: Unix socket server for mpop messages."""
    sock_path = SOCK_PATH.format(name=config["name"])
    if os.path.exists(sock_path):
        os.unlink(sock_path)

    srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    srv.bind(sock_path)
    srv.listen(16)
    os.chmod(sock_path, 0o666)
    log(f"Listening on {sock_path}")

    while True:
        try:
            conn, _ = srv.accept()
            threading.Thread(
                target=handle_connection,
                args=(conn, config),
                daemon=True,
            ).start()
        except Exception as e:
            log(f"Server error: {e}")
            time.sleep(1)


# ── Wire mesh ─────────────────────────────────────────────────────────

def connect_wire():
    """Attempt Wire mesh connection (non-fatal if unavailable)."""
    try:
        r = subprocess.run(
            ["wire", "connect"],
            capture_output=True, text=True, timeout=15,
        )
        out = (r.stdout + r.stderr).strip()
        log(f"Wire: {out[:100] or 'connected'}")
    except FileNotFoundError:
        log("Wire: not installed (skipping)")
    except subprocess.TimeoutExpired:
        log("Wire: connect timed out (skipping)")
    except Exception as e:
        log(f"Wire: {e} (skipping)")


# ── Health check ──────────────────────────────────────────────────────

def write_health(config: dict):
    """Write /opt/rtlinux/health.json for fleet monitoring."""
    import platform
    health = {
        "name": config["name"],
        "version": config.get("version", "?"),
        "model": config.get("model", "?"),
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "python": platform.python_version(),
        "hostname": platform.node(),
    }
    with open("/opt/rtlinux/health.json", "w") as f:
        json.dump(health, f, indent=2)


# ── Entry point ───────────────────────────────────────────────────────

def main():
    log("=" * 50)
    log("rtlinux assistant runtime starting")

    if not os.path.exists(CONFIG_PATH):
        log(f"Config not found: {CONFIG_PATH}")
        sys.exit(1)

    with open(CONFIG_PATH) as f:
        config = json.load(f)

    log(f"Assistant: {config['name']} v{config.get('version', '?')}")
    log(f"Model:     {config.get('model', '?')}")
    if config.get("schedule"):
        log(f"Schedule:  {config['schedule']}")

    # Check required env vars
    missing = [k for k in config.get("env", []) if not os.environ.get(k)]
    if missing:
        log(f"Warning: missing env vars: {', '.join(missing)}")

    # Connect to Wire mesh
    connect_wire()

    # Write health file
    try:
        write_health(config)
    except Exception:
        pass

    # Start schedule thread (if configured)
    if config.get("schedule") and config.get("schedule_task"):
        t = threading.Thread(target=run_schedule_loop, args=(config,), daemon=True)
        t.start()

    log("Ready.")

    # Main loop: message server (blocking)
    run_message_server(config)


if __name__ == "__main__":
    main()
