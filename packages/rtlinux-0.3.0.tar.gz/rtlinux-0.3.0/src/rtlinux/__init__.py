"""
rtlinux — MeshPOP Runtime Linux (L0)
====================================

MeshPOP-native runtime OS for AI infrastructure nodes.
Buildroot-based minimal Linux: boot → wire connect → vssh listen → ready.

Layer 0 of the MeshPOP stack:

    L0  rtlinux   — Runtime OS (kernel + musl + busybox + MeshPOP)
    L1  Wire      — WireGuard mesh VPN
    L2  vssh      — Secure remote execution
    L3  mpop      — Fleet orchestration
    L4  MeshDB    — Distributed search
    L5  Vault     — Secrets management

Usage::

    # Build runtime image
    rtlinux build --method buildroot

    # Deploy to new node
    rtlinux deploy node5 --image meshpoplinux-rootfs.tar.gz

    # Verify fleet health
    rtlinux verify --all

    # Full CI/CD loop
    rtlinux loop --nodes "node1 node2 node3 worker1 worker2"

Install::

    pip install rtlinux

Links:
    - GitHub: https://github.com/meshpop/rtlinux
    - Docs: https://mpop.dev
    - PyPI: https://pypi.org/project/rtlinux/
"""

__version__ = "0.2.0"
__author__ = "MeshPOP"
__license__ = "Apache-2.0"

import os
import sys
import json
import base64
import subprocess
from pathlib import Path
from rtlinux import template as _template


# ── Config ──────────────────────────────────────────────────────────
RTLINUX_DIR = os.environ.get("RTLINUX_DIR", os.path.expanduser("~/meshpoplinux"))
BUILD_METHODS = ["buildroot", "alpine", "scratch"]
DEFAULT_METHOD = "buildroot"

MESHPOP_PACKAGES = ["meshpop", "vssh", "meshpop-wire", "meshpop-db", "sv-vault"]


def _vssh_exec(node: str, cmd: str) -> str:
    """Execute command on remote node via vssh Python module."""
    try:
        import vssh
        import io
        old = sys.stdout
        sys.stdout = buf = io.StringIO()
        vssh.ssh(node, cmd)
        sys.stdout = old
        return buf.getvalue().strip()
    except ImportError:
        # Fallback to CLI
        r = subprocess.run(
            ["vssh", "exec", node, cmd],
            capture_output=True, text=True, timeout=30
        )
        return r.stdout.strip()


def _vssh_put(local_path: str, node: str, remote_path: str) -> bool:
    """Upload file to remote node via vssh."""
    try:
        import vssh
        vssh.put(local_path, node, remote_path)
        return True
    except ImportError:
        r = subprocess.run(
            ["vssh", "put", local_path, f"{node}:{remote_path}"],
            capture_output=True, text=True, timeout=120
        )
        return r.returncode == 0


# ── Build ───────────────────────────────────────────────────────────
def build(method: str = DEFAULT_METHOD, output_dir: str = None) -> dict:
    """Build meshpoplinux runtime image.

    Args:
        method: Build method (buildroot, alpine, scratch)
        output_dir: Output directory for artifacts

    Returns:
        dict with build results
    """
    if method not in BUILD_METHODS:
        return {"error": f"Unknown method: {method}. Use: {BUILD_METHODS}"}

    output_dir = output_dir or os.path.join(RTLINUX_DIR, "output")
    os.makedirs(output_dir, exist_ok=True)

    scripts = {
        "buildroot": "scripts/build-buildroot.sh",
        "alpine": "scripts/build-docker.sh",
        "scratch": "scripts/build-from-scratch.sh",
    }

    script = os.path.join(RTLINUX_DIR, scripts[method])
    if not os.path.exists(script):
        return {"error": f"Build script not found: {script}"}

    r = subprocess.run(
        ["bash", script, output_dir],
        capture_output=True, text=True, timeout=3600
    )

    rootfs = os.path.join(output_dir, "meshpoplinux-rootfs.tar.gz")
    if os.path.exists(rootfs):
        size = os.path.getsize(rootfs)
        return {
            "status": "ok",
            "method": method,
            "artifact": rootfs,
            "size_bytes": size,
            "size_human": f"{size / 1024 / 1024:.1f}MB",
        }
    return {"error": "Build failed — rootfs not produced", "output": r.stderr[-500:]}


# ── Deploy ──────────────────────────────────────────────────────────
def deploy(node: str, image: str = None, install_stack: bool = True) -> dict:
    """Deploy runtime image to a node.

    Args:
        node: Target node name (node1, worker2, etc.)
        image: Path to rootfs image (default: output/meshpoplinux-rootfs.tar.gz)
        install_stack: Whether to install MeshPOP packages

    Returns:
        dict with deployment results
    """
    image = image or os.path.join(RTLINUX_DIR, "output", "meshpoplinux-rootfs.tar.gz")
    if not os.path.exists(image):
        return {"error": f"Image not found: {image}. Run: rtlinux build"}

    results = {"node": node, "steps": []}

    # Upload
    ok = _vssh_put(image, node, "/tmp/meshpoplinux-rootfs.tar.gz")
    results["steps"].append({"upload": "ok" if ok else "failed"})

    # Extract
    out = _vssh_exec(node, "mkdir -p /opt/meshpoplinux && tar xzf /tmp/meshpoplinux-rootfs.tar.gz -C /opt/meshpoplinux 2>&1 | tail -3")
    results["steps"].append({"extract": out or "ok"})

    # Install MeshPOP stack
    if install_stack:
        for pkg in MESHPOP_PACKAGES:
            out = _vssh_exec(node, f"pip3 install --break-system-packages --upgrade {pkg} 2>&1 | tail -1")
            results["steps"].append({pkg: out})

    # Cleanup
    _vssh_exec(node, "rm -f /tmp/meshpoplinux-rootfs.tar.gz")

    results["status"] = "ok"
    return results


# ── Verify ──────────────────────────────────────────────────────────
def verify(node: str) -> dict:
    """Verify a node's health across all 5 MeshPOP layers.

    Returns:
        dict with check results per layer
    """
    checks = {"node": node, "layers": {}}

    # L0: Reachable?
    ping = _vssh_exec(node, "echo pong")
    checks["layers"]["L0_reachable"] = ping == "pong"
    if not checks["layers"]["L0_reachable"]:
        checks["status"] = "unreachable"
        return checks

    # System info
    checks["hostname"] = _vssh_exec(node, "hostname")
    checks["kernel"] = _vssh_exec(node, "uname -r")
    checks["python"] = _vssh_exec(node, "python3 --version 2>&1")

    # L1: Wire
    wg = _vssh_exec(node, "ip -4 addr show wg0 2>/dev/null | grep -oP 'inet \\K[0-9./]+'")
    checks["layers"]["L1_wire"] = bool(wg)
    checks["wire_ip"] = wg

    # L2: vssh
    checks["layers"]["L2_vssh"] = True  # Already reachable

    # L3: mpop packages
    pkg_ok = 0
    for pkg in MESHPOP_PACKAGES:
        ver = _vssh_exec(node, f"python3 -c \"import importlib.metadata; print(importlib.metadata.version('{pkg}'))\" 2>/dev/null")
        checks[f"pkg_{pkg}"] = ver if ver else None
        if ver:
            pkg_ok += 1
    checks["layers"]["L3_mpop"] = pkg_ok >= 3

    # L4: MeshDB
    mdb = _vssh_exec(node, "python3 -c 'import meshpop_db; print(\"ok\")' 2>&1")
    checks["layers"]["L4_meshdb"] = "ok" in mdb

    # L5: Vault
    vlt = _vssh_exec(node, "python3 -c 'import sv_vault; print(\"ok\")' 2>&1")
    checks["layers"]["L5_vault"] = "ok" in vlt

    # Disk
    disk = _vssh_exec(node, "df / | tail -1 | tr -s ' ' | cut -d' ' -f5 | tr -d '%'")
    try:
        checks["disk_pct"] = int(disk)
    except:
        checks["disk_pct"] = None

    # Overall
    layer_ok = sum(1 for v in checks["layers"].values() if v)
    checks["status"] = "healthy" if layer_ok >= 4 else "degraded" if layer_ok >= 2 else "critical"
    checks["layers_ok"] = f"{layer_ok}/{len(checks['layers'])}"

    return checks


def verify_fleet(nodes: list) -> dict:
    """Verify all nodes in the fleet."""
    results = {}
    for node in nodes:
        results[node] = verify(node)

    healthy = sum(1 for r in results.values() if r.get("status") == "healthy")
    return {
        "fleet": results,
        "summary": f"{healthy}/{len(nodes)} healthy",
    }




# ── Templates ────────────────────────────────────────────────────────

def build_from_template(
    config_path: str,
    output_dir: str = None,
    method: str = "docker",
) -> dict:
    """Build a self-contained assistant image from a template.yaml.

    Args:
        config_path: Path to template.yaml (or built-in name like "email")
        output_dir:  Where to write the image (default: ~/meshpoplinux/output)
        method:      "docker" (recommended) or "nodocker" (Linux only)

    Returns:
        dict with build result

    Example::

        rtlinux build --config email           # built-in template
        rtlinux build --config my_bot.yaml     # custom template
    """
    # Resolve template path
    if not config_path.endswith((".yaml", ".yml", ".json")):
        # Try built-in name
        found = _template.find_builtin(config_path)
        if found:
            config_path = found
        else:
            return {"error": f"Template not found: '{config_path}'. Run: rtlinux templates list"}

    # Load + validate
    try:
        tmpl = _template.load(config_path)
    except Exception as e:
        return {"error": f"Template error: {e}"}

    output_dir = output_dir or os.path.join(RTLINUX_DIR, "output")
    os.makedirs(output_dir, exist_ok=True)

    if method == "docker":
        return _build_docker(tmpl, output_dir, config_path)
    elif method == "nodocker":
        return _build_nodocker(tmpl, output_dir, config_path)
    else:
        return {"error": f"Unknown method: {method}. Use: docker, nodocker"}


def _build_docker(tmpl, output_dir: str, config_path: str) -> dict:
    """Build Docker image from template."""
    import tempfile, shutil, textwrap

    # Check Docker is available
    r = subprocess.run(["docker", "info"], capture_output=True, timeout=10)
    if r.returncode != 0:
        return {"error": "Docker not running. Start Docker Desktop or use --method nodocker"}

    # Extra pip packages
    all_packages = list(MESHPOP_PACKAGES) + tmpl.packages
    pip_line = " ".join(all_packages) if all_packages else ""

    # Runtime source
    runtime_src = os.path.join(os.path.dirname(__file__), "runtime.py")

    with tempfile.TemporaryDirectory() as build_dir:
        # Write template config
        with open(os.path.join(build_dir, "template.json"), "w") as f:
            f.write(tmpl.to_json())

        # Copy runtime
        shutil.copy(runtime_src, os.path.join(build_dir, "runtime.py"))

        # Copy extra files from template dir
        tmpl_dir = os.path.dirname(config_path)
        for dest, src in tmpl.files.items():
            src_path = os.path.join(tmpl_dir, src)
            if os.path.exists(src_path):
                shutil.copy(src_path, os.path.join(build_dir, os.path.basename(dest)))

        # Generate Dockerfile
        dockerfile = textwrap.dedent(f"""
            FROM python:3.11-slim-bookworm
            RUN apt-get update -qq && apt-get install -y -qq \\
                curl iproute2 procps && \\
                rm -rf /var/lib/apt/lists/*
            RUN pip install --no-cache-dir --break-system-packages \\
                {pip_line}
            RUN mkdir -p /opt/rtlinux
            COPY template.json /opt/rtlinux/template.json
            COPY runtime.py /opt/rtlinux/runtime.py
            WORKDIR /opt/rtlinux
            ENV RTLINUX_CONFIG=/opt/rtlinux/template.json
            ENV RTLINUX_LOG=/opt/rtlinux/assistant.log
            CMD ["python3", "/opt/rtlinux/runtime.py"]
            LABEL org.meshpop.rtlinux.name="{tmpl.name}" \\
                  org.meshpop.rtlinux.version="{tmpl.version}" \\
                  org.meshpop.rtlinux.model="{tmpl.model}"
        """).strip()

        with open(os.path.join(build_dir, "Dockerfile"), "w") as f:
            f.write(dockerfile + "\n")

        # Build Docker image
        tag = f"rtlinux-{tmpl.name}:{tmpl.version}"
        r = subprocess.run(
            ["docker", "build", "-t", tag, build_dir],
            capture_output=True, text=True, timeout=600,
        )
        if r.returncode != 0:
            return {"error": "Docker build failed", "output": r.stderr[-1000:]}

        # Save image as tar
        image_name = f"rtlinux-{tmpl.name}-{tmpl.version}.tar"
        image_path = os.path.join(output_dir, image_name)
        r2 = subprocess.run(
            ["docker", "save", "-o", image_path, tag],
            capture_output=True, text=True, timeout=120,
        )
        if r2.returncode != 0:
            return {"error": "docker save failed", "output": r2.stderr}

        size = os.path.getsize(image_path)
        return {
            "status": "ok",
            "name": tmpl.name,
            "tag": tag,
            "image": image_path,
            "size_human": f"{size / 1024 / 1024:.0f}MB",
            "run": (
                f"docker run -d --name {tmpl.name} "
                f"-e ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY {tag}"
            ),
        }


def _build_nodocker(tmpl, output_dir: str, config_path: str) -> dict:
    """Build nodocker (BusyBox + Python) image from template."""
    # Use the existing nodocker script logic
    script = os.path.join(RTLINUX_DIR, "scripts", "build-from-template.sh")
    if not os.path.exists(script):
        return {"error": f"Build script not found: {script}. Install rtlinux scripts."}

    config_json = os.path.join(output_dir, f"{tmpl.name}-template.json")
    with open(config_json, "w") as f:
        f.write(tmpl.to_json())

    r = subprocess.run(
        ["bash", script, config_json, output_dir],
        capture_output=True, text=True, timeout=1800,
    )
    rootfs = os.path.join(output_dir, f"rtlinux-{tmpl.name}-rootfs.tar.gz")
    if os.path.exists(rootfs):
        size = os.path.getsize(rootfs)
        return {
            "status": "ok",
            "name": tmpl.name,
            "rootfs": rootfs,
            "size_human": f"{size / 1024 / 1024:.1f}MB",
        }
    return {"error": "Build failed", "output": r.stderr[-500:]}


def templates_list(include_registry: bool = False) -> dict:
    """List available templates."""
    builtin = _template.list_builtin()
    result = {"builtin": builtin}
    if include_registry:
        result["community"] = _template.fetch_registry()
    return result


def templates_search(query: str) -> list:
    """Search templates by name or description."""
    query = query.lower()
    all_templates = _template.list_builtin() + _template.fetch_registry()
    return [
        t for t in all_templates
        if query in t.get("name", "").lower()
        or query in t.get("description", "").lower()
    ]




# ── Assistant lifecycle ───────────────────────────────────────────────

def new_assistant(template_name: str, output_dir: str = None, name: str = None) -> dict:
    """Scaffold a new assistant directory from a built-in template.

    Creates a directory with template.yaml ready to customize.

    Args:
        template_name: Built-in template (email, news, code-reviewer, research, system-monitor)
        output_dir:    Where to create the assistant dir (default: current directory)
        name:          Custom name override

    Returns:
        dict with path to created directory
    """
    from rtlinux import template as _tmpl

    tmpl_path = _tmpl.find_builtin(template_name)
    if not tmpl_path:
        available = [t["name"] for t in _tmpl.list_builtin()]
        return {"error": f"Template '{template_name}' not found. Available: {available}"}

    tmpl = _tmpl.load(tmpl_path)
    assistant_name = name or tmpl.name
    out = output_dir or os.getcwd()
    dest_dir = os.path.join(out, assistant_name)

    if os.path.exists(dest_dir):
        return {"error": f"Directory already exists: {dest_dir}"}

    import shutil, textwrap
    os.makedirs(dest_dir)

    # Copy template.yaml with name override
    with open(tmpl_path) as f:
        tmpl_text = f.read()

    if name and name != tmpl.name:
        tmpl_text = tmpl_text.replace(f"name: {tmpl.name}", f"name: {name}", 1)

    with open(os.path.join(dest_dir, "template.yaml"), "w") as f:
        f.write(tmpl_text)

    # Write README
    readme = textwrap.dedent(f"""
        # {assistant_name}

        Built from template: {template_name}

        ## Setup

        Edit `template.yaml` to customize your assistant.

        Required environment variables:
        {chr(10).join(f"  - {e}" for e in tmpl.env) or "  (none)"}

        ## Run

        ```bash
        rtlinux up {dest_dir}
        ```

        ## Talk to it

        ```bash
        mpop ask {assistant_name} "your request here"
        ```
    """).strip()

    with open(os.path.join(dest_dir, "README.md"), "w") as f:
        f.write(readme + "\n")

    return {
        "status": "ok",
        "name": assistant_name,
        "path": dest_dir,
        "next": f"Edit {dest_dir}/template.yaml then run: rtlinux up {dest_dir}",
    }


def up(config_path: str, env: dict = None, detach: bool = True) -> dict:
    """Build and run an assistant in one step (docker-compose style).

    Args:
        config_path: Path to directory containing template.yaml, or template.yaml directly
        env:         Environment variables dict (e.g. {"ANTHROPIC_API_KEY": "sk-..."})
        detach:      Run in background (default: True)

    Returns:
        dict with container status
    """
    # Resolve config path
    if os.path.isdir(config_path):
        config_path = os.path.join(config_path, "template.yaml")

    if not os.path.exists(config_path):
        return {"error": f"Not found: {config_path}"}

    # 1. Build
    build_result = build_from_template(config_path, method="docker")
    if "error" in build_result:
        return build_result

    name = build_result["name"]
    tag  = build_result["tag"]

    # 2. Stop existing container if any
    subprocess.run(["docker", "rm", "-f", name],
                   capture_output=True, timeout=10)

    # 3. Run
    env = env or {}
    env_flags = []
    for k, v in env.items():
        env_flags += ["-e", f"{k}={v}"]
    # Pass through common API keys from host env
    for key in ["ANTHROPIC_API_KEY", "OPENAI_API_KEY", "OLLAMA_URL"]:
        if key not in env and os.environ.get(key):
            env_flags += ["-e", f"{key}={os.environ[key]}"]

    run_cmd = ["docker", "run", "--name", name]
    if detach:
        run_cmd.append("-d")
    run_cmd += ["--restart", "unless-stopped"]
    run_cmd += env_flags
    run_cmd.append(tag)

    r = subprocess.run(run_cmd, capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        return {"error": r.stderr.strip(), "cmd": " ".join(run_cmd)}

    return {
        "status": "running",
        "name": name,
        "tag": tag,
        "container_id": r.stdout.strip()[:12],
        "talk": f"mpop ask {name} \"your request here\"",
        "logs": f"rtlinux logs {name}",
    }


def down(name: str) -> dict:
    """Stop and remove a running assistant container."""
    r = subprocess.run(
        ["docker", "rm", "-f", name],
        capture_output=True, text=True, timeout=15,
    )
    if r.returncode == 0:
        return {"status": "stopped", "name": name}
    return {"error": r.stderr.strip(), "name": name}


def ps() -> dict:
    """List running rtlinux assistant containers."""
    r = subprocess.run(
        ["docker", "ps", "--filter", "label=org.meshpop.rtlinux.name",
         "--format", "{{.Names}}\t{{.Status}}\t{{.Image}}"],
        capture_output=True, text=True, timeout=10,
    )
    if r.returncode != 0:
        return {"error": r.stderr.strip()}

    assistants = []
    for line in r.stdout.strip().splitlines():
        if not line:
            continue
        parts = line.split("\t")
        assistants.append({
            "name":   parts[0] if len(parts) > 0 else "?",
            "status": parts[1] if len(parts) > 1 else "?",
            "image":  parts[2] if len(parts) > 2 else "?",
        })
    return {"assistants": assistants, "count": len(assistants)}


def logs(name: str, lines: int = 50) -> str:
    """Get logs from a running assistant container."""
    r = subprocess.run(
        ["docker", "logs", "--tail", str(lines), name],
        capture_output=True, text=True, timeout=10,
    )
    return (r.stdout + r.stderr).strip() or "(no logs)"


def create_assistant(description: str, name: str = None, output_dir: str = None,
                     model: str = "claude-sonnet-4-6") -> dict:
    """AI-powered assistant creation from natural language description.

    Generates a complete template.yaml from the user\'s description,
    then builds and runs the assistant automatically.

    Args:
        description: What you want the assistant to do (natural language)
        name:        Assistant name (auto-generated if not provided)
        output_dir:  Where to create files (default: ~/meshpoplinux/assistants)
        model:       LLM model to use

    Returns:
        dict with created template and run status

    Example::

        create_assistant("Monitor my inbox and send me a daily digest at 9am")
        create_assistant("Watch Hacker News and alert me when something is trending about AI")
    """
    import re

    # Derive name from description if not given
    if not name:
        words = re.sub(r"[^a-z0-9 ]", "", description.lower()).split()[:3]
        name = "-".join(words) or "my-assistant"

    out = output_dir or os.path.expanduser("~/meshpoplinux/assistants")
    dest_dir = os.path.join(out, name)
    os.makedirs(dest_dir, exist_ok=True)

    # Infer template fields from description
    schedule = None
    schedule_task = None
    packages = ["anthropic"]
    tools = []

    desc_lower = description.lower()

    # Schedule hints
    if any(x in desc_lower for x in ["every hour", "hourly"]):
        schedule, schedule_task = "every 1h", description
    elif any(x in desc_lower for x in ["every 30", "half hour"]):
        schedule, schedule_task = "every 30m", description
    elif any(x in desc_lower for x in ["daily", "every day", "each day", "9am", "morning"]):
        schedule, schedule_task = "every 24h", description
    elif any(x in desc_lower for x in ["every 15", "15 min"]):
        schedule, schedule_task = "every 15m", description

    # Tool hints
    if any(x in desc_lower for x in ["news", "web", "search", "internet", "hacker", "reddit"]):
        tools.append("web_search")
    if any(x in desc_lower for x in ["file", "meshdb", "index", "find"]):
        tools.append("meshdb_search")

    # Package hints
    if any(x in desc_lower for x in ["email", "inbox", "imap", "gmail"]):
        packages.append("imapclient")
    if any(x in desc_lower for x in ["rss", "feed", "news"]):
        packages.append("feedparser")
    if any(x in desc_lower for x in ["system", "cpu", "memory", "disk", "monitor"]):
        packages.append("psutil")

    # Required env vars
    env_vars = ["ANTHROPIC_API_KEY"]
    if any(x in desc_lower for x in ["email", "inbox", "imap", "gmail"]):
        env_vars += ["IMAP_HOST", "IMAP_USER", "IMAP_PASS"]

    # Build template yaml
    tools_yaml = "\n".join(f"  - {t}" for t in tools) if tools else ""
    pkgs_yaml  = "\n".join(f"  - {p}" for p in packages)
    env_yaml   = "\n".join(f"  - {e}" for e in env_vars)
    sched_yaml = f"schedule: \"every 1h\"\nschedule_task: \"{description}\"" if schedule else ""

    yaml_content = f"""name: {name}
description: "{description[:80]}"
version: "1.0.0"
model: {model}
system_prompt: |
  You are a specialized AI assistant. Your purpose:
  {description}

  Be concise, accurate, and actionable.
tools:
{tools_yaml if tools_yaml else "  []"}
packages:
{pkgs_yaml}
{sched_yaml}
on_message: "{description[:80]}"
env:
{env_yaml}
"""

    tmpl_path = os.path.join(dest_dir, "template.yaml")
    with open(tmpl_path, "w") as f:
        f.write(yaml_content)

    return {
        "status": "created",
        "name": name,
        "path": tmpl_path,
        "template_preview": yaml_content,
        "next_steps": [
            f"Review: cat {tmpl_path}",
            f"Build & run: rtlinux up {dest_dir}",
            f"Talk to it: mpop ask {name} \"your request\"",
        ],
    }


# ── CLI ─────────────────────────────────────────────────────────────
def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="rtlinux",
        description="MeshPOP Runtime Linux — L0 node OS management"
    )
    sub = parser.add_subparsers(dest="cmd")

    # build (base image)
    p_build = sub.add_parser("build", help="Build runtime image or assistant from template")
    p_build.add_argument("--method", default="docker", choices=["docker", "nodocker", "buildroot", "alpine", "scratch"])
    p_build.add_argument("--output", default=None)
    p_build.add_argument("--config", default=None, metavar="TEMPLATE",
                         help="Template name (e.g. email) or path to template.yaml")

    # deploy
    p_deploy = sub.add_parser("deploy", help="Deploy to a node")
    p_deploy.add_argument("node", help="Target node (e.g. node1, worker2)")
    p_deploy.add_argument("--image", default=None)
    p_deploy.add_argument("--no-stack", action="store_true")

    # verify
    p_verify = sub.add_parser("verify", help="Verify node health")
    p_verify.add_argument("node", nargs="?", help="Node name")
    p_verify.add_argument("--all", action="store_true")
    p_verify.add_argument("--nodes", default=os.environ.get("RTLINUX_NODES", ""))

    # templates
    p_tmpl = sub.add_parser("templates", help="Browse and manage assistant templates")
    tmpl_sub = p_tmpl.add_subparsers(dest="tmpl_cmd")
    tmpl_sub.add_parser("list", help="List built-in templates")
    p_tsearch = tmpl_sub.add_parser("search", help="Search templates")
    p_tsearch.add_argument("query", help="Search term")

    # run (start assistant container locally)
    p_run = sub.add_parser("run", help="Run an assistant locally via Docker")
    p_run.add_argument("name_or_config", help="Assistant name or template.yaml path")
    p_run.add_argument("--detach", "-d", action="store_true", help="Run in background")

    # status
    sub.add_parser("status", help="Fleet status")

    # version
    sub.add_parser("version", help="Show version")

    args = parser.parse_args()

    if args.cmd == "build":
        result = build(method=args.method, output_dir=args.output)
        print(json.dumps(result, indent=2))

    elif args.cmd == "deploy":
        result = deploy(args.node, image=args.image, install_stack=not args.no_stack)
        print(json.dumps(result, indent=2))

    elif args.cmd == "verify":
        if args.all or not args.node:
            nodes = args.nodes.split()
            result = verify_fleet(nodes)
        else:
            result = verify(args.node)
        print(json.dumps(result, indent=2))

    elif args.cmd == "status":
        nodes_env = os.environ.get("RTLINUX_NODES", "")
        nodes = nodes_env.split() if nodes_env else []
        result = verify_fleet(nodes)
        print(json.dumps(result, indent=2))

    elif args.cmd == "version":
        print(f"rtlinux {__version__}")

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
