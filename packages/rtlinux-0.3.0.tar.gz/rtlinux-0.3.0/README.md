# rtlinux — MeshPOP Runtime Linux

**Spawn your own AI assistants. Run them anywhere. Distribute them across machines.**

`pip install rtlinux` → Claude attaches → describe what you want → your assistant is running.

---

## The Idea

Most AI assistants are someone else's service. rtlinux lets you build and own yours — running on your laptop, your VPS, your home server. Each assistant is a self-contained node that auto-joins your MeshPOP mesh and responds to `mpop ask`.

```
You: "I want an assistant that monitors Hacker News and tells me about AI news every 6 hours"
Claude: [calls rtlinux_create] → builds image → starts container → joins Wire mesh
You: mpop ask hn-monitor "what's trending today?"
```

Multiple assistants, multiple machines, all talking to each other. Your fleet.

---

## Install

```bash
pip install rtlinux
```

Add to Claude Desktop (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "rtlinux": {
      "command": "python3",
      "args": ["-m", "rtlinux.mcp.rtlinux_mcp_server"]
    }
  }
}
```

Restart Claude Desktop. You now have rtlinux tools.

---

## Usage

### Via Claude (recommended)

Just tell Claude what you want:

> "Make me an assistant that checks my email every 30 minutes and flags anything urgent"

> "I want a research bot that summarizes AI papers daily"

> "Set up a system monitor that alerts me if any server goes above 80% CPU"

Claude will use `rtlinux_create` to build it, run it, and tell you how to talk to it.

### Via CLI

```bash
# See available templates
rtlinux templates list

# Scaffold from template (then customize)
rtlinux new email --name my-email-bot
# → creates my-email-bot/template.yaml

# Edit it
nano my-email-bot/template.yaml

# Build + run (docker-compose style)
rtlinux up my-email-bot/

# Talk to it
mpop ask my-email-bot "check my inbox"

# Manage
rtlinux ps              # list running assistants
rtlinux logs my-email-bot
rtlinux down my-email-bot
```

### Deploy to remote server

```bash
# Build locally
rtlinux build --config my-email-bot/template.yaml

# Deploy to VPS
rtlinux deploy node1 --image output/rtlinux-my-email-bot-1.0.0.tar

# It joins the Wire mesh on that server — talk to it from anywhere
mpop ask my-email-bot "what's in my inbox?"
```

---

## Built-in Templates

| Template | Description | Schedule |
|----------|-------------|----------|
| `email` | Monitor inbox, draft replies, flag urgent | every 30m |
| `news` | Aggregate and summarize news by topic | every 6h |
| `code-reviewer` | Review code, explain diffs, suggest improvements | on demand |
| `research` | Deep research on any topic | on demand |
| `system-monitor` | Monitor server health, alert on anomalies | every 15m |

---

## template.yaml Format

```yaml
name: my-assistant
description: "What this assistant does"
model: claude-sonnet-4-6          # or claude-opus-4-6, claude-haiku-4-5

system_prompt: |
  You are a specialized assistant that...

tools:
  - web_search
  - meshdb_search

packages:
  - imapclient                    # extra pip packages baked into image

schedule: "every 6h"              # optional: run automatically
schedule_task: "Summarize the latest AI news"

on_message: "Handle the user request"

env:
  - ANTHROPIC_API_KEY             # required environment variables
  - IMAP_USER
```

---

## Architecture

```
pip install rtlinux
        │
        ▼
Claude Desktop (MCP)
        │ rtlinux_create / rtlinux_up
        ▼
  template.yaml ──► Docker image
                         │
                    BusyBox + Python
                    + MeshPOP stack
                    + your assistant code
                    + Wire mesh auto-connect
                         │
              ┌──────────┴──────────┐
         MacBook               VPS / server
         (local)               (remote)
              │                    │
              └────── Wire ────────┘
                         │
                    mpop ask assistant "..."
```

Each assistant is a lightweight container (~150MB) that:
- Boots directly into the assistant loop
- Auto-connects to your Wire mesh
- Responds to `mpop ask <name> "..."`
- Runs scheduled tasks autonomously

---

## MeshPOP Stack

| Layer | Package | Role |
|-------|---------|------|
| L0 | **rtlinux** | Runtime OS + assistant builder |
| L1 | Wire | WireGuard mesh VPN |
| L2 | vssh | Secure remote execution |
| L3 | mpop | Fleet orchestration |
| L4 | MeshDB | Distributed file search |
| L5 | Vault | Secrets management |

---

## Share Your Templates

Built something useful? Share it:

1. Fork [github.com/meshpop/rtlinux-templates](https://github.com/meshpop/rtlinux-templates)
2. Add your template directory with `template.yaml`
3. Open a PR

Community templates are browsable via `rtlinux templates search`.

---

## Links

- **Homepage**: [mpop.dev](https://mpop.dev)
- **GitHub**: [github.com/meshpop/rtlinux](https://github.com/meshpop/rtlinux)
- **Templates**: [github.com/meshpop/rtlinux-templates](https://github.com/meshpop/rtlinux-templates)

## License

Apache-2.0
