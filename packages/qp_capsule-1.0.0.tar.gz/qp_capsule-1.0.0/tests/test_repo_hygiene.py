"""
Repo hygiene tests for open-source launch readiness.

Guards against regressions when adding new examples, fixtures, or docs.
"""

import json
import re
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).parent.parent
SPEC_DIR = REPO_ROOT / "specs" / "cps"
SRC_DIR = REPO_ROOT / "src" / "qp_capsule"
EXAMPLES_DIR = REPO_ROOT / "examples"
DOCS_DIR = REPO_ROOT / "docs"


class TestExampleDomains:
    """New examples must use RFC 2606 placeholder domains, not internal ones."""

    def _scan_examples(self, pattern: str) -> list[str]:
        violations = []
        for path in EXAMPLES_DIR.glob("*.json"):
            matches = re.findall(pattern, path.read_text())
            if matches:
                violations.append(f"{path.name}: {matches}")
        return violations

    def test_no_non_example_dot_com_emails(self):
        """Example emails must use @example.com (RFC 2606)."""
        violations = self._scan_examples(r"[\w.-]+@(?!example\.com)[\w.-]+\.com")
        assert not violations, f"Non-example.com emails in examples:\n" + "\n".join(violations)

    def test_no_dot_internal_hostnames(self):
        """Example hostnames must not use .internal."""
        violations = self._scan_examples(r"[\w.-]+\.internal\b")
        assert not violations, f".internal hostnames in examples:\n" + "\n".join(violations)


class TestPackageIntegrity:
    """Package markers and metadata must be correct."""

    def test_py_typed_marker_exists(self):
        """PEP 561 py.typed marker is required for typed package support."""
        assert (SRC_DIR / "py.typed").exists()

    def test_package_name_is_qp_capsule(self):
        """Package name must be qp-capsule."""
        import tomllib

        with open(REPO_ROOT / "pyproject.toml", "rb") as f:
            config = tomllib.load(f)
        assert config["project"]["name"] == "qp-capsule"

    def test_version_matches_changelog(self):
        """pyproject.toml version must match the latest CHANGELOG entry."""
        import tomllib

        with open(REPO_ROOT / "pyproject.toml", "rb") as f:
            version = tomllib.load(f)["project"]["version"]
        changelog = (REPO_ROOT / "CHANGELOG.md").read_text()
        match = re.search(r"\[(\d+\.\d+\.\d+)\]", changelog)
        assert match and match.group(1) == version


class TestGoldenFixtures:
    """Golden fixture file must be structurally valid."""

    @pytest.fixture()
    def fixtures(self) -> dict:
        with open(SPEC_DIR / "fixtures.json") as f:
            return json.load(f)

    def test_fixture_count_is_fifteen(self, fixtures: dict):
        """CPS v1.0 defines exactly 15 golden test vectors."""
        assert len(fixtures["fixtures"]) == 15

    def test_fixture_names_are_unique(self, fixtures: dict):
        names = [f["name"] for f in fixtures["fixtures"]]
        assert len(names) == len(set(names))

    def test_fixture_hashes_are_valid_sha3_hex(self, fixtures: dict):
        for f in fixtures["fixtures"]:
            assert re.fullmatch(r"[0-9a-f]{64}", f["sha3_256_hash"]), f["name"]


class TestCIMakefileAlignment:
    """CI workflow must match Makefile so local and remote checks agree."""

    def test_ruff_check_scope_matches(self):
        ci = (REPO_ROOT / ".github" / "workflows" / "ci.yaml").read_text()
        makefile = (REPO_ROOT / "Makefile").read_text()
        ci_paths = set(re.search(r"ruff check (.+)", ci).group(1).split())  # type: ignore[union-attr]
        make_paths = set(re.search(r"ruff check (.+)", makefile).group(1).split())  # type: ignore[union-attr]
        assert ci_paths == make_paths
