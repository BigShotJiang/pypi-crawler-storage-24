
### Fixed

- Add pandas as explicit dependency for inlined SHACL helpers

### Improved

- Remove thisisneat references, update docs to reflect inlined SHACL validation
- Remove outdated "What's New" section from documentation index