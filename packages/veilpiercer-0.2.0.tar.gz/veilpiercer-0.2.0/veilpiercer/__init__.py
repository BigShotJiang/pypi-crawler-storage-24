"""
VeilPiercer — Local-first AI agent observability.
LangSmith for your laptop.
"""
from veilpiercer.callback import VeilPiercerCallback
from veilpiercer.ollama_hook import enable_ollama_tracing

try:
    from veilpiercer.__version__ import __version__
except ImportError:
    __version__ = "0.2.0-dev"

__all__ = ["VeilPiercerCallback", "enable_ollama_tracing", "__version__"]
