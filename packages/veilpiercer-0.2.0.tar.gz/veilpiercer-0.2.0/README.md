# VeilPiercer

**LangSmith for your laptop.** Local-first AI agent observability — per-step tracing, divergence detection, zero cloud.

```bash
pip install veilpiercer
```

## Quick Start

### LangChain (2 lines)
```python
from veilpiercer import VeilPiercerCallback
chain = LLMChain(llm=ollama, callbacks=[VeilPiercerCallback()])
```

### Ollama direct (1 line)
```python
import veilpiercer.ollama_hook  # all ollama.chat() calls now traced
```

### Any framework (manual)
```python
from veilpiercer import SessionLogger
with SessionLogger.new("my-agent") as sess:
    sess.log_step(prompt=p, response=r, state_version="v1")
```

## Why VeilPiercer

- ✅ **100% local** — nothing leaves your machine
- ✅ **Zero setup** — no Docker, no OpenTelemetry, no cloud account
- ✅ **LangChain + Ollama + CrewAI + LangGraph + LlamaIndex**
- ✅ **Visual diff UI** — see exactly where two agent runs diverged
- ✅ **Hallucination flags** — automatic anomaly detection per step

## Compare two runs

```bash
veilpiercer diff session-A session-B
```

Or open `vp_session_diff.html` in your browser.

## Learn more

[veil-piercer.com](https://veil-piercer.com)
