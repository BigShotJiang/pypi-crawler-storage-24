"""Swagger-like documentation UI for FastMCP servers."""

from .server import create_docs_router, mount_mcp_docs

__all__ = ["create_docs_router", "mount_mcp_docs"]
