from __future__ import annotations

import asyncio

from mcp_swagger_ui import create_docs_router, mount_mcp_docs
from mcp_swagger_ui.introspection import (
    _call_list_method,
    _extract_description,
    _extract_extra_metadata,
    _extract_name,
    _extract_schema,
    _iter_registry,
    _prompt_args_as_schema,
    _resource_input_schema,
    _resource_template_uri,
    _safe_getattr,
    _sdk_obj,
    _to_dict_maybe,
    collect_all,
    collect_prompts,
    collect_resources,
    collect_tools,
)


class ExplodingAttribute:
    @property
    def broken(self) -> str:
        raise RuntimeError("boom")


class DumpableModel:
    def model_dump(self) -> dict[str, object]:
        return {"name": "dumped"}


class DictableModel:
    def dict(self) -> dict[str, object]:
        return {"name": "dict-dumped"}


class ModelDumpRaises:
    def model_dump(self) -> dict[str, object]:
        raise RuntimeError("bad dump")


class AsyncRegistry:
    async def list_items(self) -> list[str]:
        return ["x", "y"]


class BrokenRegistry:
    def list_items(self) -> list[str]:
        raise RuntimeError("bad list")


class FakeToolSDK:
    def __init__(self) -> None:
        self.name = "sdk_tool"
        self.description = "Tool from SDK object."
        self.inputSchema = {"type": "object", "properties": {"term": {"type": "string"}}, "required": ["term"]}
        self.outputSchema = {"type": "object", "properties": {"ok": {"type": "boolean"}}}
        self.title = "Search Tool"
        self.execution = None


class FakeTool:
    def __init__(self) -> None:
        self.name = "fallback_tool"
        self.description = "fallback tool description"
        self.input_schema = {"type": "object", "properties": {"query": {"type": "string"}}}
        self.output_schema = {"type": "object", "properties": {"result": {"type": "string"}}}

    def to_mcp_tool(self) -> FakeToolSDK:
        return FakeToolSDK()


class FakePromptArg:
    def __init__(self, name: object, description: object, required: object) -> None:
        self.name = name
        self.description = description
        self.required = required


class FakePrompt:
    def __init__(self) -> None:
        self.name = "summary_prompt"
        self.description = "Prompt fallback description"
        self.arguments = [
            FakePromptArg("text", "Prompt text", True),
            FakePromptArg("tone", None, False),
            FakePromptArg("", "ignored", True),
            FakePromptArg(123, "ignored", True),
        ]
        self.title = "Prompt Title"


class FakeResourceSDK:
    def __init__(self) -> None:
        self.uri = "users://profile/{id}"
        self.description = "Profile resource"
        self.kind = "template"


class FakeResource:
    def __init__(self) -> None:
        self.name = "profile_resource"
        self.description = "Resource fallback description"

    def to_mcp_resource(self) -> FakeResourceSDK:
        return FakeResourceSDK()


class FallbackMCP:
    def __init__(self) -> None:
        self.tools = {"tool": FakeTool()}
        self.prompts = [FakePrompt()]
        self.resources = [FakeResource()]


def test_package_exports_public_server_helpers() -> None:
    assert callable(create_docs_router)
    assert callable(mount_mcp_docs)


def test_low_level_introspection_helpers_cover_edge_cases() -> None:
    assert _safe_getattr(ExplodingAttribute(), "broken", "default") == "default"
    assert _safe_getattr(object(), "missing", "default") == "default"

    assert _to_dict_maybe({"x": 1}) == {"x": 1}
    assert _to_dict_maybe(None) == {}
    assert _to_dict_maybe(DumpableModel()) == {"name": "dumped"}
    assert _to_dict_maybe(DictableModel()) == {"name": "dict-dumped"}
    assert _to_dict_maybe(ModelDumpRaises()) == {}
    assert _to_dict_maybe(object()) == {}

    assert _iter_registry(FallbackMCP(), ("tools",)) != []
    assert _iter_registry(FallbackMCP(), ("prompts",)) != []
    assert _iter_registry(object(), ("missing",)) == []

    assert asyncio.run(_call_list_method(AsyncRegistry(), "list_items")) == ["x", "y"]
    assert asyncio.run(_call_list_method(BrokenRegistry(), "list_items")) == []
    assert asyncio.run(_call_list_method(object(), "list_items")) == []

    named = type("Named", (), {"id": "abc"})()
    described = type("Described", (), {"docs": "  some docs  "})()
    undescribed = type("Undescribed", (), {"description": None, "doc": None, "docs": None, "__doc__": None})()
    schema_holder = type("SchemaHolder", (), {"inputSchema": DumpableModel()})()

    assert _extract_name(named, "fallback") == "abc"
    assert _extract_name(object(), "fallback") == "fallback"
    assert _extract_description(described) == "some docs"
    assert _extract_description(undescribed) == ""
    assert _extract_schema(schema_holder, ("inputSchema",)) == {"name": "dumped"}
    assert _extract_schema(object(), ("inputSchema",)) == {}


def test_sdk_and_metadata_helpers_cover_success_and_failure_paths() -> None:
    class SdkSource:
        def to_mcp_tool(self) -> dict[str, str]:
            return {"ok": "yes"}

    class BrokenSdkSource:
        def to_mcp_tool(self) -> dict[str, str]:
            raise RuntimeError("bad")

    class MetadataSource:
        def __init__(self) -> None:
            self.name = "ignored"
            self.title = "Visible"
            self.count = 1
            self.enabled = True
            self.data = {"nested": "ignored"}

    assert _sdk_obj(SdkSource(), ("to_mcp_tool",)) == {"ok": "yes"}
    assert _sdk_obj(BrokenSdkSource(), ("to_mcp_tool",)) is None
    assert _sdk_obj(object(), ("to_mcp_tool",)) is None
    assert _extract_extra_metadata(MetadataSource(), skip={"name"}) == {
        "title": "Visible",
        "count": 1,
        "enabled": True,
    }


def test_prompt_args_schema_handles_required_optional_and_missing_arguments() -> None:
    schema = _prompt_args_as_schema(FakePrompt())
    assert schema == {
        "type": "object",
        "properties": {
            "text": {"type": "string", "description": "Prompt text"},
            "tone": {"type": "string", "description": ""},
        },
        "required": ["text"],
    }
    assert _prompt_args_as_schema(object()) == {}


def test_resource_schema_extracts_template_variables() -> None:
    sdk_resource = FakeResourceSDK()

    assert _resource_template_uri(sdk_resource) == "users://profile/{id}"
    assert _resource_input_schema(sdk_resource) == {
        "type": "object",
        "properties": {
            "uri": {"type": "string"},
            "id": {
                "type": "string",
                "description": "Value for resource template variable `id`.",
            },
        },
        "required": ["id"],
    }


def test_collectors_cover_fallback_registries() -> None:
    mcp = FallbackMCP()

    tools = asyncio.run(collect_tools(mcp))
    prompts = asyncio.run(collect_prompts(mcp))
    resources = asyncio.run(collect_resources(mcp))
    all_items = asyncio.run(collect_all(mcp))

    assert len(tools) == 1
    assert tools[0].name == "fallback_tool"
    assert tools[0].description == "Tool from SDK object."
    assert tools[0].input_schema["required"] == ["term"]
    assert tools[0].metadata["title"] == "Search Tool"

    assert len(prompts) == 1
    assert prompts[0].name == "summary_prompt"
    assert prompts[0].input_schema["required"] == ["text"]
    assert prompts[0].metadata["title"] == "Prompt Title"

    assert len(resources) == 1
    assert resources[0].name == "profile_resource"
    assert resources[0].description == "Profile resource"
    assert resources[0].input_schema == {
        "type": "object",
        "properties": {
            "uri": {"type": "string"},
            "id": {
                "type": "string",
                "description": "Value for resource template variable `id`.",
            },
        },
        "required": ["id"],
    }
    assert resources[0].metadata["kind"] == "template"

    assert set(all_items.keys()) == {"tools", "prompts", "resources"}
