from __future__ import annotations

import asyncio

from mcp.server.fastmcp import FastMCP

from mcp_swagger_ui.introspection import MCPItem
from mcp_swagger_ui.openapi_like import (
    _build_route_names,
    _example_object_from_schema,
    _example_value_from_schema,
    _field_requirements,
    _operation_description,
    _operation_summary,
    _parameter_description,
    _responses,
    _required_and_optional_text,
    _schema_properties,
    _schema_required,
    generate_openapi_like,
)


def build_test_mcp() -> FastMCP:
    mcp = FastMCP("Schema Test MCP")

    @mcp.tool()
    def search_users(query: str, limit: int = 10) -> dict:
        """Search users by text query."""
        return {"items": [{"query": query, "limit": limit}]}

    @mcp.prompt()
    def summarize_text(text: str) -> str:
        """Prompt template for concise summaries."""
        return f"Summarize: {text}"

    @mcp.resource("users://profile/{id}")
    def user_profile(id: str) -> str:
        """User profile resource by id."""
        return f"User {id}"

    return mcp


def test_schema_helpers_handle_expected_shapes() -> None:
    schema = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Lookup text"},
            "limit": {"type": "integer", "default": 10},
        },
        "required": ["query"],
    }

    assert _schema_properties(schema) == schema["properties"]
    assert _schema_required(schema) == ["query"]
    assert _required_and_optional_text(schema) == "Required arguments: query. Optional arguments: limit."
    assert _field_requirements(schema["properties"], ["query"]) == [
        {
            "name": "query",
            "required": True,
            "type": "string",
            "description": "Lookup text",
            "default": None,
        },
        {
            "name": "limit",
            "required": False,
            "type": "integer",
            "description": "",
            "default": 10,
        },
    ]


def test_example_helpers_cover_scalar_array_object_and_defaults() -> None:
    assert _example_value_from_schema({"type": "string"}) == "string"
    assert _example_value_from_schema({"type": "integer"}) == 0
    assert _example_value_from_schema({"type": "number"}) == 0
    assert _example_value_from_schema({"type": "boolean"}) is False
    assert _example_value_from_schema({"type": "array", "items": {"type": "string"}}) == ["string"]
    assert _example_value_from_schema({"type": "array", "items": "bad"}) == []
    assert _example_value_from_schema({"default": 3}) == 3
    assert _example_value_from_schema({"example": "x"}) == "x"
    assert _example_value_from_schema({"type": "unknown"}) is None
    assert _example_object_from_schema(
        {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "count": {"type": "integer"},
            },
        }
    ) == {"name": "string", "count": 0}
    assert _example_object_from_schema({"type": "object", "properties": {"bad": "value"}}) == {}


def test_operation_helpers_and_response_builder() -> None:
    item = MCPItem(
        name="search_users",
        description="Search users by text query.",
        category="tool",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Lookup text"},
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["query"],
        },
        output_schema={"type": "array", "items": {"type": "string"}},
    )

    assert _operation_summary("tools", item) == "Inspect tool `search_users`"
    assert _operation_description("tools", item) == (
        "Search users by text query.\n\nRequired arguments: query. Optional arguments: limit."
    )
    assert _parameter_description({"type": "integer", "default": 10}) == "Type: integer. Default: 10."
    assert _parameter_description({"description": "Lookup text", "type": "string"}) == (
        "Lookup text Type: string."
    )
    assert _responses(item) == {
        "200": {
            "description": "Success",
            "content": {
                "application/json": {
                    "schema": {"type": "array", "items": {"type": "string"}},
                    "example": ["string"],
                }
            },
        }
    }


def test_route_builder_only_namespaces_colliding_item_names() -> None:
    registries = {
        "tools": [MCPItem(name="shared", category="tool"), MCPItem(name="tool_only", category="tool")],
        "prompts": [MCPItem(name="shared", category="prompt")],
        "resources": [MCPItem(name="resource_only", category="resource")],
    }

    assert _build_route_names(registries) == {
        ("tools", "shared"): "/tools/shared",
        ("tools", "tool_only"): "/tool_only",
        ("prompts", "shared"): "/prompts/shared",
        ("resources", "resource_only"): "/resource_only",
    }


def test_generate_openapi_like_documents_tools_prompts_and_resources() -> None:
    document = asyncio.run(generate_openapi_like(build_test_mcp(), title="Docs", version="1.2.3"))

    assert document["openapi"] == "3.1.0"
    assert document["info"]["title"] == "Docs"
    assert document["info"]["version"] == "1.2.3"
    assert document["x-mcp"] == {
        "tools": ["search_users"],
        "prompts": ["summarize_text"],
        "resources": ["user_profile"],
    }

    tool_operation = document["paths"]["/search_users"]["get"]
    prompt_operation = document["paths"]["/summarize_text"]["get"]
    resource_operation = document["paths"]["/user_profile"]["get"]

    assert tool_operation["tags"] == ["tools"]
    assert tool_operation["description"].startswith("Search users by text query.")
    assert tool_operation["parameters"][0]["name"] == "query"
    assert tool_operation["parameters"][0]["required"] is True
    assert tool_operation["parameters"][1]["example"] == 10

    assert prompt_operation["tags"] == ["prompts"]
    assert prompt_operation["parameters"][0]["name"] == "text"

    assert resource_operation["tags"] == ["resources"]
    assert resource_operation["parameters"] == [
        {
            "name": "uri",
            "in": "query",
            "required": False,
            "schema": {"type": "string"},
            "description": "Type: string.",
            "example": "string",
        },
        {
            "name": "id",
            "in": "query",
            "required": True,
            "schema": {
                "type": "string",
                "description": "Value for resource template variable `id`.",
            },
            "description": "Value for resource template variable `id`. Type: string.",
            "example": "string",
        },
    ]


def test_generate_openapi_like_namespaces_only_colliding_routes() -> None:
    registries = {
        "tools": [MCPItem(name="shared", category="tool"), MCPItem(name="tool_only", category="tool")],
        "prompts": [MCPItem(name="shared", category="prompt")],
        "resources": [MCPItem(name="resource_only", category="resource")],
    }

    routes = _build_route_names(registries)

    assert routes[("tools", "shared")] == "/tools/shared"
    assert routes[("prompts", "shared")] == "/prompts/shared"
    assert routes[("tools", "tool_only")] == "/tool_only"
    assert routes[("resources", "resource_only")] == "/resource_only"
