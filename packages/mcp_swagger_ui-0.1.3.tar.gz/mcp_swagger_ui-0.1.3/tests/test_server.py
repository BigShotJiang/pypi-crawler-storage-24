from __future__ import annotations

from fastapi import FastAPI, Header, HTTPException
from fastapi.testclient import TestClient
from mcp.server.fastmcp import FastMCP

from mcp_swagger_ui.server import create_docs_router, mount_mcp_docs


def build_test_mcp() -> FastMCP:
    mcp = FastMCP("Test MCP")

    @mcp.tool()
    def search_users(query: str, limit: int = 10) -> dict:
        """Search users by text query."""
        return {"items": [{"query": query, "limit": limit}]}

    @mcp.prompt()
    def summarize_text(text: str) -> str:
        """Prompt template for concise summaries."""
        return f"Summarize: {text}"

    @mcp.resource("users://profile/{id}")
    def user_profile(id: str) -> str:
        """User profile resource by id."""
        return f"User {id}"

    return mcp


def docs_auth(x_api_key: str | None = Header(default=None)) -> None:
    if x_api_key != "secret-docs-key":
        raise HTTPException(status_code=401, detail="Unauthorized")


def test_create_docs_router_serves_swagger_ui() -> None:
    app = FastAPI(openapi_url=None)
    app.include_router(create_docs_router(build_test_mcp(), title="Demo Docs"), prefix="/mcp-docs")

    client = TestClient(app)
    response = client.get("/mcp-docs/")

    assert response.status_code == 200
    assert "SwaggerUIBundle" in response.text
    assert "Demo Docs" in response.text
    assert "./openapi.json" in response.text


def test_docs_openapi_serves_generated_schema() -> None:
    app = FastAPI(openapi_url=None)
    app.include_router(create_docs_router(build_test_mcp(), title="Demo Docs", version="0.2.0"))

    client = TestClient(app)
    response = client.get("/openapi.json")

    assert response.status_code == 200
    payload = response.json()
    assert payload["info"]["title"] == "Demo Docs"
    assert payload["info"]["version"] == "0.2.0"
    assert "/search_users" in payload["paths"]


def test_mount_mcp_docs_respects_prefix() -> None:
    app = FastAPI()
    mount_mcp_docs(app, build_test_mcp(), mount_path="/custom-docs", title="Custom Docs")

    client = TestClient(app)

    docs_response = client.get("/custom-docs/")
    openapi_response = client.get("/custom-docs/openapi.json")

    assert docs_response.status_code == 200
    assert "Custom Docs" in docs_response.text
    assert openapi_response.status_code == 200
    assert openapi_response.json()["info"]["title"] == "Custom Docs"


def test_auth_dependency_protects_docs_endpoints() -> None:
    app = FastAPI()
    mount_mcp_docs(app, build_test_mcp(), auth_dependency=docs_auth)
    client = TestClient(app)

    unauthorized = client.get("/mcp-docs/openapi.json")
    authorized = client.get("/mcp-docs/openapi.json", headers={"x-api-key": "secret-docs-key"})

    assert unauthorized.status_code == 401
    assert authorized.status_code == 200
