# Native extensions: pattern_core, gram_codec
