"""SDK logger configuration."""
from __future__ import annotations

import logging

logger = logging.getLogger("pillar")
