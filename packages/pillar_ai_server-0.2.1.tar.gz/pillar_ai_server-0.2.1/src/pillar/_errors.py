"""SDK-specific exception types."""
from __future__ import annotations


class PillarError(Exception):
    """Base exception for all Pillar SDK errors."""


class RegistrationError(PillarError):
    """Raised when tool registration with Pillar Cloud fails."""


class SignatureVerificationError(PillarError):
    """Raised when webhook signature verification fails."""


class ToolNotFoundError(PillarError):
    """Raised when a tool call references an unregistered tool name."""
