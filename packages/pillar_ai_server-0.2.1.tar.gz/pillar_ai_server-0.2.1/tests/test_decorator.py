from __future__ import annotations

from typing import Literal

from pillar._context import ToolContext
from pillar._decorator import ToolRegistration, make_tool_decorator


class TestMakeToolDecorator:
    def test_registers_tool(self) -> None:
        registry: dict[str, ToolRegistration] = {}

        @make_tool_decorator(registry, "Look up a customer")
        def lookup_customer(email: str, ctx: ToolContext) -> dict:
            return {"found": True}

        assert "lookup_customer" in registry
        reg = registry["lookup_customer"]
        assert reg.name == "lookup_customer"
        assert reg.description == "Look up a customer"
        assert reg.input_schema["properties"]["email"] == {"type": "string"}
        assert "ctx" not in reg.input_schema["properties"]

    def test_custom_name(self) -> None:
        registry: dict[str, ToolRegistration] = {}

        @make_tool_decorator(registry, "Find user", name="find_user")
        def lookup(email: str) -> dict:
            return {}

        assert "find_user" in registry
        assert "lookup" not in registry

    def test_explicit_schema_overrides(self) -> None:
        registry: dict[str, ToolRegistration] = {}
        custom_schema = {
            "type": "object",
            "properties": {"id": {"type": "integer"}},
            "required": ["id"],
        }

        @make_tool_decorator(registry, "Get by ID", input_schema=custom_schema)
        def get_item(id: int) -> dict:
            return {}

        assert registry["get_item"].input_schema == custom_schema

    def test_function_still_callable(self) -> None:
        registry: dict[str, ToolRegistration] = {}

        @make_tool_decorator(registry, "Add numbers")
        def add(a: int, b: int) -> int:
            return a + b

        assert add(2, 3) == 5

    def test_pillar_tool_attribute(self) -> None:
        registry: dict[str, ToolRegistration] = {}

        @make_tool_decorator(registry, "A tool")
        def my_tool(x: str) -> str:
            return x

        assert hasattr(my_tool, "__pillar_tool__")
        assert my_tool.__pillar_tool__.name == "my_tool"

    def test_timeout_and_channels(self) -> None:
        registry: dict[str, ToolRegistration] = {}

        @make_tool_decorator(
            registry,
            "Slow tool",
            timeout_ms=60_000,
            channel_compatibility=["web"],
        )
        def slow(x: str) -> str:
            return x

        reg = registry["slow"]
        assert reg.timeout_ms == 60_000
        assert reg.channel_compatibility == ["web"]

    def test_default_channels(self) -> None:
        registry: dict[str, ToolRegistration] = {}

        @make_tool_decorator(registry, "Default channels")
        def tool(x: str) -> str:
            return x

        assert registry["tool"].channel_compatibility == [
            "web", "slack", "discord", "email", "api"
        ]
