from __future__ import annotations

from pillar._context import CallerInfo, ToolContext


class TestCallerInfo:
    def test_defaults(self) -> None:
        caller = CallerInfo(channel="web")
        assert caller.channel == "web"
        assert caller.channel_user_id is None
        assert caller.external_user_id is None
        assert caller.email is None
        assert caller.display_name is None

    def test_all_fields(self) -> None:
        caller = CallerInfo(
            channel="slack",
            channel_user_id="U04ABC",
            external_user_id="7842",
            email="sarah@acme.com",
            display_name="Sarah Chen",
        )
        assert caller.channel == "slack"
        assert caller.channel_user_id == "U04ABC"
        assert caller.external_user_id == "7842"


class TestToolContext:
    def test_is_identified_true(self) -> None:
        ctx = ToolContext(
            caller=CallerInfo(channel="web", external_user_id="123"),
            conversation_id="conv_1",
            call_id="tc_1",
        )
        assert ctx.is_identified is True

    def test_is_identified_false(self) -> None:
        ctx = ToolContext(
            caller=CallerInfo(channel="web"),
            conversation_id="conv_1",
            call_id="tc_1",
        )
        assert ctx.is_identified is False

    def test_from_payload_full(self) -> None:
        payload = {
            "call_id": "tc_abc123",
            "conversation_id": "conv_xyz",
            "caller": {
                "channel": "slack",
                "channel_user_id": "U04ABCDEF",
                "external_user_id": "7842",
                "email": "sarah@acme.com",
                "display_name": "Sarah Chen",
            },
        }
        ctx = ToolContext.from_payload(payload)
        assert ctx.call_id == "tc_abc123"
        assert ctx.conversation_id == "conv_xyz"
        assert ctx.caller.channel == "slack"
        assert ctx.caller.email == "sarah@acme.com"
        assert ctx.is_identified is True

    def test_from_payload_minimal(self) -> None:
        payload = {"call_id": "tc_1"}
        ctx = ToolContext.from_payload(payload)
        assert ctx.call_id == "tc_1"
        assert ctx.conversation_id == ""
        assert ctx.caller.channel == "web"
        assert ctx.is_identified is False

    def test_from_payload_no_caller(self) -> None:
        ctx = ToolContext.from_payload({})
        assert ctx.caller.channel == "web"
        assert ctx.call_id == ""
