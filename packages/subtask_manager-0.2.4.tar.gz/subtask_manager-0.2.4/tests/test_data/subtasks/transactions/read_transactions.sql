select *
from transactions;
