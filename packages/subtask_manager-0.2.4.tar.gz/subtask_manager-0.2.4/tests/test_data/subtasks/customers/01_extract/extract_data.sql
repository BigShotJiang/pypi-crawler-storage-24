select *
from public.customers;