# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowOpLogRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'operation_log_id': 'str'
    }

    attribute_map = {
        'operation_log_id': 'operation_log_id'
    }

    def __init__(self, operation_log_id=None):
        r"""ShowOpLogRequest

        The model defined in huaweicloud sdk

        :param operation_log_id: 任务ID
        :type operation_log_id: str
        """
        
        

        self._operation_log_id = None
        self.discriminator = None

        self.operation_log_id = operation_log_id

    @property
    def operation_log_id(self):
        r"""Gets the operation_log_id of this ShowOpLogRequest.

        任务ID

        :return: The operation_log_id of this ShowOpLogRequest.
        :rtype: str
        """
        return self._operation_log_id

    @operation_log_id.setter
    def operation_log_id(self, operation_log_id):
        r"""Sets the operation_log_id of this ShowOpLogRequest.

        任务ID

        :param operation_log_id: The operation_log_id of this ShowOpLogRequest.
        :type operation_log_id: str
        """
        self._operation_log_id = operation_log_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowOpLogRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
