# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class PolicyCreate:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'enabled': 'bool',
        'name': 'str',
        'operation_definition': 'PolicyoODCreate',
        'operation_type': 'str',
        'trigger': 'PolicyTriggerReq'
    }

    attribute_map = {
        'enabled': 'enabled',
        'name': 'name',
        'operation_definition': 'operation_definition',
        'operation_type': 'operation_type',
        'trigger': 'trigger'
    }

    def __init__(self, enabled=None, name=None, operation_definition=None, operation_type=None, trigger=None):
        r"""PolicyCreate

        The model defined in huaweicloud sdk

        :param enabled: 是否启用策略
        :type enabled: bool
        :param name: 策略名称，长度限制：1- 64，只能由中文、字母、数字、“_”、“-”组成。
        :type name: str
        :param operation_definition: 
        :type operation_definition: :class:`huaweicloudsdkcbr.v1.PolicyoODCreate`
        :param operation_type: 策略类型，如备份，复制 Enum:[ backup，replication]
        :type operation_type: str
        :param trigger: 
        :type trigger: :class:`huaweicloudsdkcbr.v1.PolicyTriggerReq`
        """
        
        

        self._enabled = None
        self._name = None
        self._operation_definition = None
        self._operation_type = None
        self._trigger = None
        self.discriminator = None

        if enabled is not None:
            self.enabled = enabled
        self.name = name
        self.operation_definition = operation_definition
        self.operation_type = operation_type
        self.trigger = trigger

    @property
    def enabled(self):
        r"""Gets the enabled of this PolicyCreate.

        是否启用策略

        :return: The enabled of this PolicyCreate.
        :rtype: bool
        """
        return self._enabled

    @enabled.setter
    def enabled(self, enabled):
        r"""Sets the enabled of this PolicyCreate.

        是否启用策略

        :param enabled: The enabled of this PolicyCreate.
        :type enabled: bool
        """
        self._enabled = enabled

    @property
    def name(self):
        r"""Gets the name of this PolicyCreate.

        策略名称，长度限制：1- 64，只能由中文、字母、数字、“_”、“-”组成。

        :return: The name of this PolicyCreate.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this PolicyCreate.

        策略名称，长度限制：1- 64，只能由中文、字母、数字、“_”、“-”组成。

        :param name: The name of this PolicyCreate.
        :type name: str
        """
        self._name = name

    @property
    def operation_definition(self):
        r"""Gets the operation_definition of this PolicyCreate.

        :return: The operation_definition of this PolicyCreate.
        :rtype: :class:`huaweicloudsdkcbr.v1.PolicyoODCreate`
        """
        return self._operation_definition

    @operation_definition.setter
    def operation_definition(self, operation_definition):
        r"""Sets the operation_definition of this PolicyCreate.

        :param operation_definition: The operation_definition of this PolicyCreate.
        :type operation_definition: :class:`huaweicloudsdkcbr.v1.PolicyoODCreate`
        """
        self._operation_definition = operation_definition

    @property
    def operation_type(self):
        r"""Gets the operation_type of this PolicyCreate.

        策略类型，如备份，复制 Enum:[ backup，replication]

        :return: The operation_type of this PolicyCreate.
        :rtype: str
        """
        return self._operation_type

    @operation_type.setter
    def operation_type(self, operation_type):
        r"""Sets the operation_type of this PolicyCreate.

        策略类型，如备份，复制 Enum:[ backup，replication]

        :param operation_type: The operation_type of this PolicyCreate.
        :type operation_type: str
        """
        self._operation_type = operation_type

    @property
    def trigger(self):
        r"""Gets the trigger of this PolicyCreate.

        :return: The trigger of this PolicyCreate.
        :rtype: :class:`huaweicloudsdkcbr.v1.PolicyTriggerReq`
        """
        return self._trigger

    @trigger.setter
    def trigger(self, trigger):
        r"""Sets the trigger of this PolicyCreate.

        :param trigger: The trigger of this PolicyCreate.
        :type trigger: :class:`huaweicloudsdkcbr.v1.PolicyTriggerReq`
        """
        self._trigger = trigger

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PolicyCreate):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
