# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CheckpointReplicateRespbackups:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'backup_id': 'str',
        'replication_record_id': 'str'
    }

    attribute_map = {
        'backup_id': 'backup_id',
        'replication_record_id': 'replication_record_id'
    }

    def __init__(self, backup_id=None, replication_record_id=None):
        r"""CheckpointReplicateRespbackups

        The model defined in huaweicloud sdk

        :param backup_id: 待复制的备份ID
        :type backup_id: str
        :param replication_record_id: 复制记录ID
        :type replication_record_id: str
        """
        
        

        self._backup_id = None
        self._replication_record_id = None
        self.discriminator = None

        self.backup_id = backup_id
        self.replication_record_id = replication_record_id

    @property
    def backup_id(self):
        r"""Gets the backup_id of this CheckpointReplicateRespbackups.

        待复制的备份ID

        :return: The backup_id of this CheckpointReplicateRespbackups.
        :rtype: str
        """
        return self._backup_id

    @backup_id.setter
    def backup_id(self, backup_id):
        r"""Sets the backup_id of this CheckpointReplicateRespbackups.

        待复制的备份ID

        :param backup_id: The backup_id of this CheckpointReplicateRespbackups.
        :type backup_id: str
        """
        self._backup_id = backup_id

    @property
    def replication_record_id(self):
        r"""Gets the replication_record_id of this CheckpointReplicateRespbackups.

        复制记录ID

        :return: The replication_record_id of this CheckpointReplicateRespbackups.
        :rtype: str
        """
        return self._replication_record_id

    @replication_record_id.setter
    def replication_record_id(self, replication_record_id):
        r"""Sets the replication_record_id of this CheckpointReplicateRespbackups.

        复制记录ID

        :param replication_record_id: The replication_record_id of this CheckpointReplicateRespbackups.
        :type replication_record_id: str
        """
        self._replication_record_id = replication_record_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CheckpointReplicateRespbackups):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
