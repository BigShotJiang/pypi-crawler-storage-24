# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class SyncReq:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'sync': 'SyncParam'
    }

    attribute_map = {
        'sync': 'sync'
    }

    def __init__(self, sync=None):
        r"""SyncReq

        The model defined in huaweicloud sdk

        :param sync: 
        :type sync: :class:`huaweicloudsdkcbr.v1.SyncParam`
        """
        
        

        self._sync = None
        self.discriminator = None

        self.sync = sync

    @property
    def sync(self):
        r"""Gets the sync of this SyncReq.

        :return: The sync of this SyncReq.
        :rtype: :class:`huaweicloudsdkcbr.v1.SyncParam`
        """
        return self._sync

    @sync.setter
    def sync(self, sync):
        r"""Sets the sync of this SyncReq.

        :param sync: The sync of this SyncReq.
        :type sync: :class:`huaweicloudsdkcbr.v1.SyncParam`
        """
        self._sync = sync

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, SyncReq):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
