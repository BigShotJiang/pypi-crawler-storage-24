# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class VaultRemoveResourceReq:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'resource_ids': 'list[str]'
    }

    attribute_map = {
        'resource_ids': 'resource_ids'
    }

    def __init__(self, resource_ids=None):
        r"""VaultRemoveResourceReq

        The model defined in huaweicloud sdk

        :param resource_ids: 要移除的资源ID列表 最小长度：1 最大长度：256
        :type resource_ids: list[str]
        """
        
        

        self._resource_ids = None
        self.discriminator = None

        self.resource_ids = resource_ids

    @property
    def resource_ids(self):
        r"""Gets the resource_ids of this VaultRemoveResourceReq.

        要移除的资源ID列表 最小长度：1 最大长度：256

        :return: The resource_ids of this VaultRemoveResourceReq.
        :rtype: list[str]
        """
        return self._resource_ids

    @resource_ids.setter
    def resource_ids(self, resource_ids):
        r"""Sets the resource_ids of this VaultRemoveResourceReq.

        要移除的资源ID列表 最小长度：1 最大长度：256

        :param resource_ids: The resource_ids of this VaultRemoveResourceReq.
        :type resource_ids: list[str]
        """
        self._resource_ids = resource_ids

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, VaultRemoveResourceReq):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
