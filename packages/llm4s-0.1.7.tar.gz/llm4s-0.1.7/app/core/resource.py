import psutil
try:
    import GPUtil
    HAS_GPUTIL = True
except ImportError:
    HAS_GPUTIL = False
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

def get_system_stats() -> Dict[str, Any]:
    """
    CPU, RAM 사용량을 가져옵니다. (psutil 활용)
    """
    try:
        cpu_usage = psutil.cpu_percent(interval=None)
        memory = psutil.virtual_memory()
        return {
            "cpu_usage": cpu_usage,
            "ram_used_gb": round(memory.used / (1024**3), 1),
            "ram_total_gb": round(memory.total / (1024**3), 1),
            "ram_percent": memory.percent
        }
    except Exception as e:
        logger.error(f"Error fetching system stats: {e}")
        return {}

def get_gpu_stats() -> List[Dict[str, Any]]:
    """
    NVIDIA GPU 상태(VRAM, 사용량, 온도)를 가져옵니다. (GPUtil 활용)
    """
    try:
        if not HAS_GPUTIL:
            return []
        gpus = GPUtil.getGPUs()
        gpu_list = []
        for gpu in gpus:
            gpu_list.append({
                "id": gpu.id,
                "name": gpu.name,
                "load_percent": round(gpu.load * 100, 1),
                "vram_used_mb": gpu.memoryUsed,
                "vram_total_mb": gpu.memoryTotal,
                "vram_percent": round((gpu.memoryUsed / gpu.memoryTotal) * 100, 1) if gpu.memoryTotal > 0 else 0,
                "temperature": gpu.temperature
            })
        return gpu_list
    except Exception as e:
        # GPU가 없거나 드라이버 이슈가 있을 경우 빈 리스트 반환
        logger.debug(f"No GPU detected or error: {e}")
        return []

def get_combined_metrics() -> Dict[str, Any]:
    """
    TUI 상단 바에 표시할 모든 지표를 통합합니다.
    """
    stats = get_system_stats()
    gpus = get_gpu_stats()
    
    # 대표 GPU 1개의 정보만 추출 (없으면 None)
    main_gpu = gpus[0] if gpus else None
    
    # [Fix] Mac (Apple Silicon) 및 기타 환경을 위한 하드웨어 모델명 검색
    hw_model = "None"
    if main_gpu:
        hw_model = main_gpu['name']
    else:
        # Mac의 경우 시스템 칩 이름을 가져옴
        try:
            import platform
            if platform.system() == "Darwin":
                import subprocess
                hw_model = subprocess.check_output(["sysctl", "-n", "machdep.cpu.brand_string"]).decode().strip()
                # 불필요한 공백이나 "Apple " 접두사 제거 (예: Apple M2 -> M2)
                hw_model = hw_model.replace("Apple ", "")
        except:
            pass

    return {
        "system": stats,
        "gpus": gpus,
        "main_gpu": main_gpu,
        "hw_model": hw_model
    }
