from importlib.metadata import version, PackageNotFoundError

from ironflock.ironflock import IronFlock
from ironflock.CrossbarConnection import CrossbarConnection, Stage

__all__ = [
    "IronFlock", 
    "CrossbarConnection",
    "Stage"
]

try:
    __version__ = version("ironflock")
except PackageNotFoundError:
    __version__ = "0.0.0"  # fallback for development
