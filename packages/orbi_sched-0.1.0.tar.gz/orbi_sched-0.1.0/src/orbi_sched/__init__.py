def hello() -> str:
    return "Hello from orbi-sched!"
