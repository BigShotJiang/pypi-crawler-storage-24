"""Orbi Task Scheduler using APScheduler."""

from __future__ import annotations

from collections.abc import Callable
from functools import wraps
from typing import Any, Literal

from apscheduler.events import EVENT_JOB_ERROR, EVENT_JOB_EXECUTED
from apscheduler.schedulers.background import BackgroundScheduler

# Global scheduler instance
_scheduler: BackgroundScheduler | None = None


def get_scheduler() -> BackgroundScheduler:
    """Lazy init singleton scheduler with defaults and listener."""
    global _scheduler
    if _scheduler is None:
        _scheduler = BackgroundScheduler(
            job_defaults={"misfire_grace_time": 60, "coalesce": True},
            timezone="Asia/Kolkata",  # IST default
        )
        _scheduler.start()

        # Execution listener for Celery-like logs
        def listener(event):
            job = _scheduler.get_job(event.job_id)
            if event.exception:
                print(f"💥 Job '{event.job_id}' ERROR: {event.exception}")
            else:
                print(
                    f"🔥 Job '{event.job_id}' executed at {event.scheduled_run_time} "
                    f"(next: {job.next_run_time if job else 'None'})"
                )

        _scheduler.add_listener(listener, EVENT_JOB_EXECUTED | EVENT_JOB_ERROR)

    return _scheduler


def orbi_task(
    trigger: Literal["date", "cron"] = "cron",
    *,
    time: str | None = None,  # For date trigger: "YYYY-MM-DD HH:MM:SS"
    day_of_week: str | None = None,
    hour: int | None = None,
    minute: int | None = None,
    **kwargs: Any,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator: @orbi_task(trigger='date', time='2026-03-25 16:05:00') or cron."""

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        sched = get_scheduler()

        # Build trigger kwargs
        trigger_kwargs: dict[str, Any] = dict(kwargs.items())

        if time is not None:
            if trigger == "date":
                trigger_kwargs["run_date"] = time
            else:
                raise ValueError(
                    "`time` requires trigger='date'; use hour/minute for cron"
                )

        if day_of_week is not None:
            trigger_kwargs["day_of_week"] = day_of_week
        if hour is not None:
            trigger_kwargs["hour"] = hour
        if minute is not None:
            trigger_kwargs["minute"] = minute

        job_id = f"orbi_{func.__name__}"  # type:ignore

        sched.add_job(
            func,
            trigger,
            id=job_id,
            replace_existing=True,
            **trigger_kwargs,
        )

        job = sched.get_job(job_id)
        print(f" Scheduled '{func.__name__}' (ID: {job_id})")  # type:ignore
        print(f"   Trigger: {trigger} {trigger_kwargs}")
        print(f"   Next run: {job.next_run_time}")
        print()

        @wraps(func)
        def wrapper(*args: Any, **kw: Any) -> Any:
            """Wrapper does nothing; job runs async."""
            pass

        return wrapper

    return decorator
