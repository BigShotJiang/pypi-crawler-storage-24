# 分片上传功能文档

## 📌 概述

本项目实现了支持多个存储后端的分片上传功能，包括：
- **Local** - 本地文件系统
- **MinIO** - MinIO 对象存储
- **S3** - AWS S3

## 🚀 快速开始

### 1. 启动测试应用

```bash
python examples/app_multipart_demo.py
```

输出：
```
╔════════════════════════════════════════════════════════════╗
║  分片上传服务已启动                                         ║
║                                                            ║
║  📍 测试页面: http://localhost:8000/api/v1/upload/multipart/test
║  📍 API 文档: http://localhost:8000/docs                   ║
╚════════════════════════════════════════════════════════════╝
```

### 2. 访问测试页面

打开浏览器访问：
```
http://localhost:8000/api/v1/upload/multipart/test
```

### 3. 在前端页面上传文件

- 选择存储后端（Local/MinIO/S3）
- 输入文件名称
- 设置分片大小（单位 MB）
- 选择要上传的文件
- 点击"开始上传"

## 📡 API 端点

### 1. 初始化分片上传

```http
POST /api/v1/upload/multipart/init
Content-Type: application/x-www-form-urlencoded

key=test.txt
content_type=text/plain
backend=local
```

**响应：**
```json
{
  "success": true,
  "upload_id": "a1b2c3d4e5f6g7h8",
  "key": "test.txt",
  "backend": "local"
}
```

### 2. 上传单个分片

```http
PUT /api/v1/upload/multipart/part/1
Content-Type: multipart/form-data

upload_id: a1b2c3d4e5f6g7h8
key: test.txt
chunk: <文件二进制数据>
backend: local
```

**响应：**
```json
{
  "success": true,
  "part_number": 1,
  "etag": "5d41402abc4b2a76b9719d911017c592",
  "size": 5242880
}
```

### 3. 完成分片上传

```http
POST /api/v1/upload/multipart/complete
Content-Type: application/x-www-form-urlencoded

upload_id=a1b2c3d4e5f6g7h8
key=test.txt
parts_json=[{"part_number": 1, "etag": "5d41402abc4b2a76b9719d911017c592"}]
backend=local
```

**响应：**
```json
{
  "success": true,
  "key": "test.txt",
  "etag": "abc123def456",
  "message": "分片上传完成"
}
```

### 4. 取消分片上传

```http
POST /api/v1/upload/multipart/abort
Content-Type: application/x-www-form-urlencoded

upload_id=a1b2c3d4e5f6g7h8
key=test.txt
backend=local
```

**响应：**
```json
{
  "success": true,
  "message": "上传已取消"
}
```

## 🔧 后端配置

### Local 后端配置

```python
backends={
    "local": {
        "type": "local",
        "root_path": "./storage"
    }
}
```

**文件结构：**
```
./storage/
├── test.txt              # 最终合并的文件
├── test.txt.meta         # 元数据
└── .multipart/
    └── upload_id/        # 临时分片目录
        ├── _meta.json    # 分片元信息
        ├── part1         # 分片 1
        ├── part2         # 分片 2
        └── part3         # 分片 3
```

### MinIO 后端配置

```python
backends={
    "minio": {
        "type": "minio",
        "endpoint": "localhost:9000",
        "access_key": "appuser",
        "secret_key": "appsecret123",
        "bucket_name": "yolo-bucket",
        "secure": False
    }
}
```

### S3 后端配置

```python
backends={
    "s3": {
        "type": "s3",
        "endpoint": "s3.amazonaws.com",
        "access_key": "YOUR_ACCESS_KEY",
        "secret_key": "YOUR_SECRET_KEY",
        "bucket_name": "your-bucket",
        "region": "us-east-1",
        "secure": True
    }
}
```

## 💻 代码示例

### Python 同步客户端

```python
from sneakydog_object_storage_service.client import OSSClient
from sneakydog_object_storage_service.config import OSSConfig

config = OSSConfig(
    default_backend="local",
    backends={
        "local": {"type": "local", "root_path": "./storage"}
    }
)

client = OSSClient(config=config)
backend = client.get_backend("local")

# 初始化上传
upload_id = backend.initiate_multipart_upload(
    key="test.bin",
    content_type="application/octet-stream"
)

# 上传分片
with open("large_file.bin", "rb") as f:
    chunk = f.read(5 * 1024 * 1024)  # 5MB
    etag = backend.upload_part(
        key="test.bin",
        upload_id=upload_id,
        part_number=1,
        bytes_data=chunk
    )

# 完成上传
from sneakydog_object_storage_service.utils.multipart import UploadPart

parts = [UploadPart(part_number=1, etag=etag, size=len(chunk))]
final_etag = backend.complete_multipart_upload(
    key="test.bin",
    upload_id=upload_id,
    parts=parts
)

print(f"✓ 上传完成，最终 ETag: {final_etag}")
```

### 使用 MultipartUploader 工具类

```python
from sneakydog_object_storage_service.client import OSSClient
from sneakydog_object_storage_service.config import OSSConfig
from sneakydog_object_storage_service.utils.multipart import MultipartUploader

config = OSSConfig(
    default_backend="local",
    backends={
        "local": {"type": "local", "root_path": "./storage"}
    }
)

client = OSSClient(config=config)
backend = client.get_backend("local")

# 创建分片上传器
uploader = MultipartUploader(backend, chunk_size=5*1024*1024, max_workers=4)

# 设置进度回调
def progress_callback(uploaded, total):
    percent = (uploaded / total) * 100
    print(f"上传进度: {percent:.1f}%")

uploader.set_progress_callback(progress_callback)

# 上传文件
result = uploader.upload(
    key="large_file.bin",
    file_path="./path/to/large_file.bin",
    content_type="application/octet-stream"
)

print(f"✓ 上传完成")
print(f"  文件: {result.key}")
print(f"  大小: {result.total_size} 字节")
print(f"  分片数: {len(result.parts)}")
```

## 🎨 前端 HTML 页面

完整的测试 HTML 页面可通过以下方式访问：

```
GET http://localhost:8000/api/v1/upload/multipart/test
```

页面特性：
- ✅ React 响应式设计
- ✅ 实时进度条
- ✅ 分片状态显示
- ✅ 支持取消上传
- ✅ 错误提示
- ✅ 支持切换存储后端

## 测试步骤

### 1. 本地存储 (Local) 测试

```bash
# 创建存储目录
mkdir -p ./storage

# 启动应用
python examples/app_multipart_demo.py

# 访问测试页面并上传文件
# http://localhost:8000/api/v1/upload/multipart/test
```

### 2. MinIO 测试

```bash
# 启动 MinIO (Docker)
docker run -d \
  -p 9000:9000 \
  -p 9001:9001 \
  -e MINIO_ROOT_USER=appuser \
  -e MINIO_ROOT_PASSWORD=appsecret123 \
  minio/minio server /data --console-address ":9001"

# 访问 MinIO 控制台并创建 bucket: yolo-bucket
# http://localhost:9001

# 启动应用
python examples/app_multipart_demo.py

# 访问测试页面，选择 MinIO 后端上传
# http://localhost:8000/api/v1/upload/multipart/test
```

### 3. AWS S3 测试

配置 AWS 凭证：

```python
# 修改 app_multipart_demo.py 中的 S3 配置
"s3": {
    "type": "s3",
    "endpoint": "s3.amazonaws.com",
    "access_key": "YOUR_AWS_ACCESS_KEY",
    "secret_key": "YOUR_AWS_SECRET_KEY",
    "bucket_name": "your-bucket-name",
    "region": "us-east-1",
    "secure": True
}

# 启动应用并在前端选择 S3 后端
```

## 📊 性能优化

### 分片大小建议

- **小文件 (< 50MB)**：5MB - 10MB
- **中等文件 (50MB - 1GB)**：10MB - 50MB
- **大文件 (> 1GB)**：50MB - 100MB

### 并发上传

```python
# MultipartUploader 支持并发上传
uploader = MultipartUploader(
    backend=backend,
    chunk_size=10*1024*1024,  # 10MB
    max_workers=8  # 8 线程并发上传
)
```

## 🐛 故障排除

### 问题：连接 MinIO 失败

**原因**：Network unreachable 或 credentials 错误

**解决**：
- 确保 MinIO 服务已启动
- 检查 endpoint、access_key、secret_key、bucket_name

### 问题：大文件上传超时

**原因**：分片过大或网络延迟

**解决**：
- 减小分片大小
- 增加 max_workers 并发数量
- 检查网络连接

### 问题：本地存储目录权限错误

**原因**：目录权限不足

**解决**：
```bash
chmod 755 ./storage
```

## 📝 文件结构

```
examples/
├── app_multipart_demo.py          # 完整的 FastAPI 示例应用
├── fastapiupload_multipart.py    # API 路由模块
└── README.md                      # 本文档

src/sneakydog_object_storage_service/
├── base.py                        # 抽象基类
├── backends/
│   ├── local.py                   # 本地存储后端
│   ├── minio.py                   # MinIO 后端
│   └── s3.py                      # S3 后端
└── utils/multipart.py             # 分片上传工具类
```

## 📞 支持

如有问题，请：
1. 检查 API 文档：http://localhost:8000/docs
2. 查看应用日志
3. 参考上述故障排除章节

---

**最后更新**：2024 年
**版本**：1.0
