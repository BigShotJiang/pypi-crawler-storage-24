from fastapi import APIRouter, Depends, HTTPException, Form, File, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse
from typing import List, Optional
from pydantic import BaseModel
from ..dependencies import get_oss_client
from ..schemas import ErrorResponse

router = APIRouter(prefix="/api/v1/upload/multipart", tags=["Multipart Upload"])


class PartInfo(BaseModel):
    part_number: int
    etag: str


class CompleteMultipartRequest(BaseModel):
    upload_id: str
    key: str
    parts: List[PartInfo]


@router.get("/test")
async def test_page():
    """
    返回前端测试页面
    """
    return HTMLResponse(content=get_test_html())


@router.post("/init")
async def init_multipart(
    key: str = Form(...),
    content_type: str = Form("application/octet-stream"),
    backend: str = Form("minio"),
    oss_client=Depends(get_oss_client),
):
    """
    1. 初始化分片上传
    返回 upload_id 供前端后续使用
    """
    try:
        backend_instance = oss_client.get_backend(backend)

        # 调用后端的原生分片初始化
        upload_id = backend_instance.initiate_multipart_upload(key=key, content_type=content_type)

        return {"success": True, "upload_id": upload_id, "key": key, "backend": backend}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/part/{part_number}")
async def upload_part(
    part_number: int,
    upload_id: str = Form(...),
    key: str = Form(...),
    chunk: UploadFile = File(...),
    backend: str = Form("minio"),
    oss_client=Depends(get_oss_client),
):
    """
    2. 上传单个分片
    前端分片后逐个调用此接口
    """
    try:
        backend_instance = oss_client.get_backend(backend)
        content = await chunk.read()

        # 调用后端的原生分片上传
        etag = backend_instance.upload_part(
            key=key, upload_id=upload_id, part_number=part_number, bytes_data=content
        )

        return {"success": True, "part_number": part_number, "etag": etag}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/complete")
async def complete_multipart(
    request: CompleteMultipartRequest,
    backend: str = Form("minio"),
    oss_client=Depends(get_oss_client),
):
    """
    3. 完成分片上传
    所有分片上传完成后调用，合并文件
    """
    try:
        backend_instance = oss_client.get_backend(backend)

        # 使用 UploadPart 对象
        from sneakydog_object_storage_service.utils.multipart import UploadPart

        parts = [UploadPart(part_number=p.part_number, etag=p.etag, size=0) for p in request.parts]

        etag = backend_instance.complete_multipart_upload(
            key=request.key, upload_id=request.upload_id, parts=parts
        )

        return {
            "success": True,
            "key": request.key,
            "message": "Multipart upload completed",
            "etag": etag
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/abort")
async def abort_multipart(
    upload_id: str = Form(...),
    key: str = Form(...),
    backend: str = Form("minio"),
    oss_client=Depends(get_oss_client),
):
    """
    4. 中止分片上传
    取消正在进行的分片上传
    """
    try:
        backend_instance = oss_client.get_backend(backend)

        backend_instance.abort_multipart_upload(key=key, upload_id=upload_id)

        return {"success": True, "message": "Upload aborted"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def get_test_html() -> str:
    """
    生成前端测试页面 HTML
    """
    return """
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>分片上传测试</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }

            .container {
                background: white;
                border-radius: 12px;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
                padding: 40px;
                max-width: 500px;
                width: 100%;
            }

            h1 {
                color: #333;
                margin-bottom: 30px;
                text-align: center;
                font-size: 28px;
            }

            .form-group {
                margin-bottom: 20px;
            }

            label {
                display: block;
                margin-bottom: 8px;
                color: #555;
                font-weight: 500;
            }

            input[type="text"],
            input[type="file"],
            select {
                width: 100%;
                padding: 12px;
                border: 2px solid #e0e0e0;
                border-radius: 6px;
                font-size: 14px;
                transition: border-color 0.3s;
            }

            input[type="text"]:focus,
            input[type="file"]:focus,
            select:focus {
                outline: none;
                border-color: #667eea;
            }

            .button-group {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 10px;
                margin-top: 30px;
            }

            button {
                padding: 12px 20px;
                border: none;
                border-radius: 6px;
                font-size: 14px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s;
            }

            .btn-upload {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                grid-column: span 2;
            }

            .btn-upload:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
            }

            .btn-upload:disabled {
                opacity: 0.5;
                cursor: not-allowed;
                transform: none;
            }

            .btn-cancel {
                background: #f5f5f5;
                color: #333;
            }

            .btn-cancel:hover {
                background: #e0e0e0;
            }

            .progress-section {
                margin-top: 30px;
                display: none;
            }

            .progress-section.active {
                display: block;
            }

            .progress-label {
                margin-bottom: 10px;
                color: #555;
                font-size: 14px;
                display: flex;
                justify-content: space-between;
            }

            .progress-bar {
                width: 100%;
                height: 8px;
                background: #e0e0e0;
                border-radius: 4px;
                overflow: hidden;
            }

            .progress-fill {
                height: 100%;
                background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
                width: 0%;
                transition: width 0.3s;
            }

            .status-message {
                margin-top: 20px;
                padding: 15px;
                border-radius: 6px;
                font-size: 14px;
                display: none;
            }

            .status-message.active {
                display: block;
            }

            .status-message.success {
                background: #e8f5e9;
                color: #2e7d32;
                border: 1px solid #c8e6c9;
            }

            .status-message.error {
                background: #ffebee;
                color: #c62828;
                border: 1px solid #ffcdd2;
            }

            .status-message.info {
                background: #e3f2fd;
                color: #1565c0;
                border: 1px solid #bbdefb;
            }

            .chunk-info {
                margin-top: 20px;
                padding: 15px;
                background: #f5f5f5;
                border-radius: 6px;
                font-size: 12px;
                color: #666;
                display: none;
            }

            .chunk-info.active {
                display: block;
            }

            .chunk-list {
                margin-top: 10px;
                max-height: 150px;
                overflow-y: auto;
            }

            .chunk-item {
                padding: 8px;
                margin: 5px 0;
                background: white;
                border-radius: 4px;
                border-left: 3px solid #667eea;
            }

            .chunk-item.uploaded {
                border-left-color: #4caf50;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📤 分片上传测试</h1>

            <div class="form-group">
                <label for="backend">存储后端:</label>
                <select id="backend">
                    <option value="local">本地存储 (Local)</option>
                    <option value="minio">MinIO</option>
                    <option value="s3">AWS S3</option>
                </select>
            </div>

            <div class="form-group">
                <label for="fileName">文件名称:</label>
                <input type="text" id="fileName" placeholder="输入保存文件名，如: test.bin" value="test.bin">
            </div>

            <div class="form-group">
                <label for="chunkSize">分片大小 (MB):</label>
                <input type="text" id="chunkSize" placeholder="分片大小" value="5">
            </div>

            <div class="form-group">
                <label for="file">选择文件:</label>
                <input type="file" id="file">
            </div>

            <div class="button-group">
                <button class="btn-upload" id="uploadBtn">开始上传</button>
                <button class="btn-cancel" id="cancelBtn" disabled>取消上传</button>
            </div>

            <div class="progress-section" id="progressSection">
                <div class="progress-label">
                    <span>上传进度</span>
                    <span id="progressText">0%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
            </div>

            <div class="status-message" id="statusMessage"></div>

            <div class="chunk-info" id="chunkInfo">
                <strong>分片信息:</strong>
                <div class="chunk-list" id="chunkList"></div>
            </div>
        </div>

        <script>
            const CHUNK_SIZE_MB = 5; // 默认 5MB
            const API_BASE = '/api/v1/upload/multipart';

            let uploadState = {
                uploadId: null,
                fileName: null,
                file: null,
                chunks: [],
                uploadedChunks: new Set(),
                isUploading: false
            };

            // DOM 元素
            const elements = {
                backend: document.getElementById('backend'),
                fileName: document.getElementById('fileName'),
                chunkSize: document.getElementById('chunkSize'),
                file: document.getElementById('file'),
                uploadBtn: document.getElementById('uploadBtn'),
                cancelBtn: document.getElementById('cancelBtn'),
                progressSection: document.getElementById('progressSection'),
                progressFill: document.getElementById('progressFill'),
                progressText: document.getElementById('progressText'),
                statusMessage: document.getElementById('statusMessage'),
                chunkInfo: document.getElementById('chunkInfo'),
                chunkList: document.getElementById('chunkList')
            };

            // 事件监听
            elements.uploadBtn.addEventListener('click', startUpload);
            elements.cancelBtn.addEventListener('click', cancelUpload);

            function showStatus(message, type = 'info') {
                elements.statusMessage.textContent = message;
                elements.statusMessage.className = `status-message active ${type}`;
            }

            function updateProgress() {
                const total = uploadState.chunks.length;
                const uploaded = uploadState.uploadedChunks.size;
                const percent = total > 0 ? Math.round((uploaded / total) * 100) : 0;

                elements.progressFill.style.width = percent + '%';
                elements.progressText.textContent = `${uploaded}/${total} (${percent}%)`;
            }

            function renderChunkList() {
                elements.chunkList.innerHTML = '';
                uploadState.chunks.forEach((chunk, index) => {
                    const isUploaded = uploadState.uploadedChunks.has(index);
                    const item = document.createElement('div');
                    item.className = `chunk-item ${isUploaded ? 'uploaded' : ''}`;
                    item.textContent = `分片 ${index + 1}: ${(chunk.size / 1024 / 1024).toFixed(2)} MB ${isUploaded ? '✓' : '⏳'}`;
                    elements.chunkList.appendChild(item);
                });
            }

            async function startUpload() {
                const file = elements.file.files[0];
                if (!file) {
                    showStatus('请选择文件', 'error');
                    return;
                }

                const fileName = elements.fileName.value || file.name;
                const chunkSizeMB = parseInt(elements.chunkSize.value) || 5;
                const backend = elements.backend.value;

                if (chunkSizeMB < 5) {
                    showStatus('分片大小至少 5 MB', 'error');
                    return;
                }

                const chunkSize = chunkSizeMB * 1024 * 1024;

                // 分片
                uploadState.chunks = [];
                uploadState.uploadedChunks.clear();
                uploadState.file = file;
                uploadState.fileName = fileName;
                uploadState.isUploading = true;

                let offset = 0;
                while (offset < file.size) {
                    const chunk = file.slice(offset, offset + chunkSize);
                    uploadState.chunks.push(chunk);
                    offset += chunkSize;
                }

                // 显示 UI
                elements.uploadBtn.disabled = true;
                elements.cancelBtn.disabled = false;
                elements.progressSection.classList.add('active');
                elements.chunkInfo.classList.add('active');
                renderChunkList();
                showStatus(`已分片: ${uploadState.chunks.length} 个分片，准备初始化上传...`, 'info');

                try {
                    // 初始化上传
                    const initFormData = new FormData();
                    initFormData.append('key', fileName);
                    initFormData.append('content_type', file.type || 'application/octet-stream');
                    initFormData.append('backend', backend);

                    const initRes = await fetch(\`\${API_BASE}/init\`, {
                        method: 'POST',
                        body: initFormData
                    });

                    if (!initRes.ok) {
                        throw new Error(\`初始化失败: \${initRes.status}\`);
                    }

                    const initData = await initRes.json();
                    if (!initData.success) {
                        throw new Error(initData.detail);
                    }

                    uploadState.uploadId = initData.upload_id;
                    showStatus(\`初始化成功，Upload ID: \${initData.upload_id}\`, 'info');

                    // 上传所有分片
                    await uploadAllChunks(backend);

                } catch (error) {
                    showStatus(\`错误: \${error.message}\`, 'error');
                    uploadState.isUploading = false;
                }
            }

            async function uploadAllChunks(backend) {
                const uploadPromises = [];

                for (let i = 0; i < uploadState.chunks.length; i++) {
                    if (!uploadState.isUploading) break;

                    const promise = uploadChunk(i, backend).then(() => {
                        uploadState.uploadedChunks.add(i);
                        updateProgress();
                        renderChunkList();
                    }).catch(error => {
                        showStatus(\`分片 \${i + 1} 失败: \${error.message}\`, 'error');
                    });

                    uploadPromises.push(promise);
                }

                await Promise.all(uploadPromises);

                if (!uploadState.isUploading) {
                    showStatus('上传已取消', 'info');
                    resetUploadUI();
                    return;
                }

                // 完成上传
                await completeUpload(backend);
            }

            async function uploadChunk(index, backend) {
                const chunk = uploadState.chunks[index];
                const formData = new FormData();
                formData.append('upload_id', uploadState.uploadId);
                formData.append('key', uploadState.fileName);
                formData.append('chunk', chunk);
                formData.append('backend', backend);

                const res = await fetch(\`\${API_BASE}/part/\${index + 1}\`, {
                    method: 'PUT',
                    body: formData
                });

                if (!res.ok) {
                    throw new Error(\`HTTP \${res.status}\`);
                }

                const data = await res.json();
                if (!data.success) {
                    throw new Error(data.detail);
                }

                return data;
            }

            async function completeUpload(backend) {
                try {
                    const parts = Array.from(uploadState.uploadedChunks).map(i => ({
                        part_number: i + 1,
                        etag: 'placeholder' // 实际应该从上传响应中获取
                    }));

                    const formData = new FormData();
                    formData.append('upload_id', uploadState.uploadId);
                    formData.append('key', uploadState.fileName);
                    formData.append('parts', JSON.stringify(parts));
                    formData.append('backend', backend);

                    const res = await fetch(\`\${API_BASE}/complete\`, {
                        method: 'POST',
                        body: formData
                    });

                    if (!res.ok) {
                        throw new Error(\`HTTP \${res.status}\`);
                    }

                    const data = await res.json();
                    if (!data.success) {
                        throw new Error(data.detail);
                    }

                    showStatus(\`✓ 上传完成！文件: \${data.key}\`, 'success');
                    resetUploadUI();

                } catch (error) {
                    showStatus(\`完成上传失败: \${error.message}\`, 'error');
                    uploadState.isUploading = false;
                }
            }

            async function cancelUpload() {
                uploadState.isUploading = false;

                try {
                    const formData = new FormData();
                    formData.append('upload_id', uploadState.uploadId);
                    formData.append('key', uploadState.fileName);
                    formData.append('backend', elements.backend.value);

                    await fetch(\`\${API_BASE}/abort\`, {
                        method: 'POST',
                        body: formData
                    });

                    showStatus('上传已取消', 'info');
                } catch (error) {
                    showStatus(\`取消失败: \${error.message}\`, 'error');
                }

                resetUploadUI();
            }

            function resetUploadUI() {
                elements.uploadBtn.disabled = false;
                elements.cancelBtn.disabled = true;
                elements.progressSection.classList.remove('active');
                uploadState.isUploading = false;
            }
        </script>
    </body>
    </html>
    """

