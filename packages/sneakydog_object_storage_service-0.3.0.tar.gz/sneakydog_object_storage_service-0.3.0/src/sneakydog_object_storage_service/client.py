from typing import Any, Optional

from sneakydog_object_storage_service.backends.local import LocalStorage
from sneakydog_object_storage_service.backends.minio import MinIOStorage
from sneakydog_object_storage_service.backends.rustfs import RustFSStorage
from sneakydog_object_storage_service.backends.s3 import S3Storage
from sneakydog_object_storage_service.base import StorageBackend, StorageConfig
from sneakydog_object_storage_service.config import OSSConfig
from sneakydog_object_storage_service.exceptions import BackendNotSupportedError


class OSSClient:
    """统一对象存储客户端"""

    BACKEND_REGISTRY = {
        "local": LocalStorage,
        "minio": MinIOStorage,
        "s3": S3Storage,  # S3 兼容
        "rustfs": RustFSStorage,
    }

    def __init__(
        self,
        config: Optional[OSSConfig] = None,
        backend_type: Optional[str] = None,
        backend_config: Optional[dict[str, Any]] = None,
    ):
        """
        初始化客户端

        Args:
            config: 完整配置对象
            backend_type: 后端类型 (local/minio/rustfs)
            backend_config: 后端具体配置
        """
        if config:
            self.config = config
        else:
            self.config = OSSConfig.from_dict(
                {
                    "default_backend": backend_type or "local",
                    "backends": {backend_type or "local": backend_config or {}},
                }
            )

        self.backends: dict[str, StorageBackend] = {}
        self.default_backend = self.config.default_backend

        # 初始化所有配置的后端
        for name, cfg in self.config.backends.items():
            self.register_backend(name, cfg)

    def register_backend(self, name: str, config: dict[str, Any]):
        """注册存储后端"""
        backend_type = config.get("type", name)

        if backend_type not in self.BACKEND_REGISTRY:
            raise BackendNotSupportedError(f"Backend type '{backend_type}' not supported")

        storage_config = StorageConfig(backend_type=backend_type, name=name, config=config)

        backend_class = self.BACKEND_REGISTRY[backend_type]
        self.backends[name] = backend_class(storage_config)

    def get_backend(self, name: Optional[str] = None) -> StorageBackend:
        """获取存储后端"""
        backend_name = name or self.default_backend
        if backend_name not in self.backends:
            raise BackendNotSupportedError(f"Backend '{backend_name}' not registered")

        return self.backends[backend_name]

    # 多后端操作
    def copy_to_backend(
        self, key: str, from_backend: str, to_backend: str, new_key: Optional[str] = None
    ) -> bool:
        """跨后端复制文件"""

        data = self.get_backend(from_backend).get_object(key)
        info = self.get_backend(from_backend).get_object_info(key)

        return self.get_backend(to_backend).put_object(
            new_key or key, data, content_type=info.content_type, metadata=info.metadata
        )

    def sync_backends(
        self, from_backend: str, to_backend: str, prefix: Optional[str] = None
    ) -> int:
        """同步两个后端的数据"""

        objects = self.get_backend(from_backend).list_objects(prefix)
        count = 0

        for obj in objects:
            try:
                self.copy_to_backend(obj.key, from_backend, to_backend)
                count += 1
            except Exception as e:
                print(f"Sync failed for {obj.key}: {e}")

        return count
