"""进度跟踪工具"""

import time
from dataclasses import dataclass
from typing import Callable, Optional


@dataclass
class ProgressInfo:
    """进度信息"""

    uploaded: int
    total: int
    speed: float  # bytes/s
    percent: float
    elapsed: float
    eta: float  # 预计剩余时间


class ProgressTracker:
    """进度跟踪器"""

    def __init__(
        self,
        total: int,
        callback: Optional[Callable[[ProgressInfo], None]] = None,
    ) -> None:
        self.total = total
        self.uploaded = 0
        self.start_time = time.time()
        self.callback = callback
        self.last_update = 0

    def update(self, bytes_uploaded: int):
        """更新进度"""
        self.uploaded += bytes_uploaded
        elapsed = time.time() - self.start_time

        speed = self.uploaded / elapsed if elapsed > 0 else 0
        percent = (self.uploaded / self.total * 100) if self.total > 0 else 0
        eta = (self.total - self.uploaded) / speed if speed > 0 else 0

        info = ProgressInfo(
            uploaded=self.uploaded,
            total=self.total,
            speed=speed,
            percent=percent,
            elapsed=elapsed,
            eta=eta,
        )

        # 限制回调频率 (每 0.5 秒)
        if elapsed - self.last_update >= 0.5:
            if self.callback:
                self.callback(info)
            self.last_update = elapsed

    def finish(self):
        """完成"""
        if self.callback:
            elapsed = time.time() - self.start_time
            info = ProgressInfo(
                uploaded=self.total,
                total=self.total,
                speed=self.total / elapsed if elapsed > 0 else 0,
                percent=100.0,
                elapsed=elapsed,
                eta=0,
            )
            self.callback(info)


def format_size(size: int) -> str:
    """格式化文件大小"""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024:
            return f"{size:.2f} {unit}"
        size /= 1024
    return f"{size:.2f} PB"


def format_time(seconds: float) -> str:
    """格式化时间"""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        mins = seconds / 60
        return f"{mins:.1f}m"
    else:
        hours = seconds / 3600
        return f"{hours:.1f}h"
