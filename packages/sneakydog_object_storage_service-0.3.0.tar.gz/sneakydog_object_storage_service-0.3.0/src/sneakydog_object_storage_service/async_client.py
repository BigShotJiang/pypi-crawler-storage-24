"""异步 OSS 客户端"""

import asyncio
from datetime import timedelta
from typing import AsyncIterator, Callable, Optional

from sneakydog_object_storage_service.base import ObjectInfo, StorageBackend
from sneakydog_object_storage_service.client import OSSClient
from sneakydog_object_storage_service.utils.progress import ProgressTracker


class AsyncOSSClient:
    """异步对象存储客户端"""

    def __init__(self, sync_client: OSSClient) -> None:
        self.sync_client = sync_client

    def get_backend(self, name: Optional[str] = None) -> StorageBackend:
        """获取存储后端"""
        return self.sync_client.get_backend(name)

    async def put_object(
        self,
        key: str,
        data: bytes,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
        backend: Optional[str] = None,
        progress_callback: Optional[Callable] = None,
    ) -> bool:
        """异步上传"""
        backend: StorageBackend = self.get_backend(backend)
        if progress_callback:
            tracker = ProgressTracker(len(data), progress_callback)
            # 分块上报进度
            chunk_size = 1024 * 1024  # 1MB
            for i in range(0, len(data), chunk_size):
                chunk = data[i : i + chunk_size]
                tracker.update(len(chunk))
                await asyncio.sleep(0)  # 让出事件循环
            tracker.finish()

        # 在 executor 中运行同步方法
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, lambda: backend.put_object(key, data, content_type, metadata)
        )

    async def get_object(self, key: str, backend: Optional[str] = None) -> bytes:
        """异步下载"""
        backend: StorageBackend = self.get_backend(backend)
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: backend.get_object(key))

    async def get_object_stream(
        self, key: str, chunk_size: int = 8 * 1024, backend: str | None = None
    ) -> AsyncIterator[bytes]:
        """流式下载"""
        backend: StorageBackend = self.get_backend(backend)
        loop = asyncio.get_running_loop()
        queue: asyncio.Queue[bytes | None] = asyncio.Queue()

        def worker():
            try:
                for chunk in backend.get_object_stream(key, chunk_size):
                    loop.call_soon_threadsafe(queue.put_nowait, chunk)
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, None)

        # 放到线程池执行
        threading_task = asyncio.to_thread(worker)
        asyncio.create_task(threading_task)

        while True:
            chunk = await queue.get()
            if chunk is None:
                break
            yield chunk

    async def delete(self, key: str, backend: Optional[str] = None) -> bool:
        """异步删除"""
        backend: StorageBackend = self.get_backend(backend)
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: backend.delete(key))

    async def exists(self, key: str, backend: Optional[str] = None) -> bool:
        """异步检查存在"""
        backend: StorageBackend = self.get_backend(backend)
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: backend.exists(key))

    async def list_objects(
        self, prefix: Optional[str] = None, max_keys: int = 1000, backend: Optional[str] = None
    ) -> list[ObjectInfo]:
        """异步列出对象"""
        backend: StorageBackend = self.get_backend(backend)
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: backend.list_objects(prefix, max_keys))

    async def presigned_url(
        self, key: str, expires_in: timedelta = timedelta(days=7), backend: Optional[str] = None
    ) -> str:
        """异步生成预签名 URL"""
        backend: StorageBackend = self.get_backend(backend)
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: backend.presigned_url(key, expires_in))

    async def upload_multipart(
        self,
        key: str,
        file_path: str,
        chunk_size: int = 5 * 1024 * 1024,
        max_workers: int = 4,
        backend: Optional[str] = None,
        progress_callback: Optional[Callable] = None,
    ) -> bool:
        """异步分片上传"""
        from .utils.multipart import MultipartUploader

        backend: StorageBackend = self.get_backend(backend)
        uploader = MultipartUploader(backend, chunk_size, max_workers)

        if progress_callback:
            uploader.set_progress_callback(progress_callback)

        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, lambda: uploader.upload(key, file_path))

        return result.etag is not None
