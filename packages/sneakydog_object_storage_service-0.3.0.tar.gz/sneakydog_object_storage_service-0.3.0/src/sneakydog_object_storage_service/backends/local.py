import hashlib
import json
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Iterator, Optional

from sneakydog_object_storage_service.base import ObjectInfo, StorageBackend, StorageConfig
from sneakydog_object_storage_service.exceptions import ObjectNotFoundError, PermissionDeniedError


class LocalStorage(StorageBackend):
    """本地文件存储

    Args:
        StorageBackend (_type_): _description_
    """

    def __init__(self, config: StorageConfig) -> None:
        """初始化

        Args:
            config (StorageConfig): _description_
        """
        super().__init__(config)
        self.root_path = Path(config.config.get("root_path"))
        self.root_path.mkdir(parents=True, exist_ok=True)

    def _get_full_path(self, key: str) -> Path:
        """获取完整路径

        Args:
            key (str): _description_

        Raises:
            PermissionDeniedError: _description_

        Returns:
            Path: _description_
        """
        # 防止路径遍历攻击
        key = key.lstrip("/")
        full_path = (self.root_path / key).resolve()
        if not str(full_path).startswith(str(self.root_path.resolve())):
            raise PermissionDeniedError(f"Invalid path: {key}")
        return full_path

    def put_object(
        self,
        key: str,
        data: bytes,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> bool:
        """上传文件

        Args:
            key (str): _description_
            data (bytes): _description_
            content_type (Optional[str], optional): _description_. Defaults to None.
            metadata (Optional[dict[str, str]], optional): _description_. Defaults to None.

        Raises:
            Exception: _description_

        Returns:
            bool: _description_
        """
        try:
            path = self._get_full_path(key)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "wb") as f:
                f.write(data)

            # 保存元数据 (可选)
            if metadata:
                meta_path = path.with_suffix(path.suffix + ".meta")
                import json

                with open(meta_path, "w") as f:
                    json.dump(metadata, f)

            return True
        except Exception as e:
            raise Exception(f"Upload failed: {str(e)}")

    def get_object(self, key: str) -> bytes:
        """下载文件

        Args:
            key (str): _description_

        Raises:
            ObjectNotFoundError: _description_

        Returns:
            bytes: _description_
        """
        path = self._get_full_path(key)
        if not path.exists():
            raise ObjectNotFoundError(f"Object not found: {key}")
        with open(path, "rb") as f:
            return f.read()

    def get_object_stream(self, key, chunk_size: int = 8 * 1024) -> Iterator[bytes]:
        """文件流下载

        Args:
            key (_type_): _description_
            chunk_size (int, optional): _description_. Defaults to 8*1024.

        Yields:
            Iterator[bytes]: _description_
        """
        path = self._get_full_path(key)
        with open(path, "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                yield chunk

    def delete(self, key: str) -> bool:
        """删除文件

        Args:
            key (str): _description_

        Raises:
            ObjectNotFoundError: _description_

        Returns:
            bool: _description_
        """
        path = self._get_full_path(key)
        if not path.exists():
            raise ObjectNotFoundError(f"Object not found: {key}")
        path.unlink()

        # 删除元数据文件
        meta_path = path.with_suffix(path.suffix + ".meta")
        if meta_path.exists():
            meta_path.unlink()

        return True

    def exists(self, key: str) -> bool:
        """检查文件是否存在

        Args:
            key (str): _description_

        Returns:
            bool: _description_
        """
        path = self._get_full_path(key)
        return path.exists() and path.is_file()

    def list_objects(self, prefix: Optional[str] = None, max_keys: int = 1000) -> list[ObjectInfo]:
        """列出对象

        Args:
            prefix (Optional[str], optional): _description_. Defaults to None.
            max_keys (int, optional): _description_. Defaults to 1000.

        Returns:
            list[ObjectInfo]: _description_
        """
        objects = []
        search_path = self.root_path / prefix if prefix else self.root_path

        for path in search_path.rglob("*"):
            if path.is_file() and not path.name.endswith(".meta"):
                try:
                    rel_path = path.relative_to(self.root_path)
                    stat = path.stat()
                    objects.append(
                        ObjectInfo(
                            key=str(rel_path),
                            size=stat.st_size,
                            last_modified=datetime.fromtimestamp(stat.st_mtime),
                            content_type=None,
                        )
                    )
                    if len(objects) >= max_keys:
                        break
                except Exception:
                    continue

        return objects

    def get_object_info(self, key: str) -> ObjectInfo:
        """获取对象元信息

        Args:
            key (str): _description_

        Raises:
            ObjectNotFoundError: _description_

        Returns:
            ObjectInfo: _description_
        """
        path = self._get_full_path(key)
        if not path.exists():
            raise ObjectNotFoundError(f"Object not found: {key}")

        stat = path.stat()
        return ObjectInfo(
            key=key,
            size=stat.st_size,
            last_modified=datetime.fromtimestamp(stat.st_mtime),
            content_type=None,
        )

    def presigned_url(self, key: str, expires_in: timedelta = timedelta(days=7)) -> str:
        """本地存储不支持预签名 URL，返回 file:// 路径

        Args:
            key (str): _description_
            expires_in (timedelta, optional): _description_. Defaults to timedelta(days=7).

        Returns:
            str: _description_
        """
        path = self._get_full_path(key)
        return f"file://{path.absolute()}"

    def initiate_multipart_upload(
        self,
        key: str,
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> str:
        """初始化分片上传

        Args:
            key (str): _description_
            content_type (Optional[str], optional): _description_. Defaults to None.
            metadata (Optional[Dict[str, str]], optional): _description_. Defaults to None.

        Returns:
            str: _description_
        """
        upload_id = hashlib.md5(f"{key}{datetime.now().isoformat()}".encode()).hexdigest()

        # 创建分片临时目录
        parts_dir = self.root_path / ".multipart" / upload_id
        parts_dir.mkdir(parents=True, exist_ok=True)

        # 保存元信息
        meta_file = parts_dir / "_meta.json"
        with open(meta_file, "w") as f:
            json.dump(
                {
                    "key": key,
                    "content_type": content_type,
                    "metadata": metadata,
                },
                f,
            )

        return upload_id

    def upload_part(self, key: str, upload_id: str, part_number: int, bytes_data: bytes) -> str:
        """上传单片

        Args:
            key (str): _description_
            upload_id (str): _description_
            part_number (int): _description_
            bytes_data (_type_): _description_

        Returns:
            str: _description_
        """
        parts_dir = self.root_path / ".multipart" / upload_id
        parts_dir.mkdir(parents=True, exist_ok=True)

        # 保存分片
        part_file = parts_dir / f"part{part_number}"
        with open(part_file, "wb") as f:
            f.write(bytes_data)

        # 计算 ETag (MD5)
        etag = hashlib.md5(bytes_data).hexdigest()
        return etag

    def complete_multipart_upload(self, key: str, upload_id: str, parts: list) -> str:
        """完成分片上传

        Args:
            key (str): _description_
            upload_id (str): _description_
            parts (list): _description_

        Returns:
            str: _description_
        """
        parts_dir = self.root_path / ".multipart" / upload_id

        # 合并所有分片
        path = self._get_full_path(key)
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "wb") as f:
            for i in range(1, len(parts) + 1):
                part_file = parts_dir / f"part{i}"
                if part_file.exists():
                    with open(part_file, "rb") as pf:
                        f.write(pf.read())

        # 读取元信息
        meta_file = parts_dir / "_meta.json"
        if meta_file.exists():
            with open(meta_file, "r") as f:
                meta = json.load(f)

            # 保存元数据
            if meta.get("metadata"):
                meta_path = path.with_suffix(path.suffix + ".meta")
                with open(meta_path, "w") as f:
                    json.dump(meta["metadata"], f)

        # 清理临时文件
        shutil.rmtree(parts_dir)

        # 计算最终 ETag
        with open(path, "rb") as f:
            etag = hashlib.md5(f.read()).hexdigest()

        return etag

    def abort_multipart_upload(self, key: str, upload_id: str) -> bool:
        """中止分片上传

        Args:
            key (str): _description_
            upload_id (str): _description_

        Returns:
            bool: _description_
        """
        parts_dir = self.root_path / ".multipart" / upload_id
        if parts_dir.exists():
            shutil.rmtree(parts_dir)
        return True
