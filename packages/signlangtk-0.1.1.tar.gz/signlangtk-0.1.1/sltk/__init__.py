"""
Sign Language Toolkit (SLTK)

A Python toolkit for sign language research: unified data loading,
feature extraction, evaluation metrics, and ELAN integration.

Quick Start:
    from sltk import PoseSequence, Segment, SegmentList
    from sltk.io import read_eaf, load_poses_h5
    from sltk.extraction import MediaPipeExtractor
    from sltk.processing import normalize_poses, compute_velocity
    from sltk.analysis import cluster_embeddings, lexical_statistics
    from sltk.utils import compute_dataset_statistics, export_segments_for_training
"""

__version__ = "0.1.1"

# Core data structures
from sltk.data.core import PoseSequence, Sample, Segment, SegmentList

# Exceptions
from sltk.exceptions import (
    AnnotationError,
    ConfigurationError,
    DatasetError,
    DatasetNotFoundError,
    DependencyError,
    ExtractionCancelled,
    ExtractionError,
    FeatureNotFoundError,
    FormatError,
    MetricsError,
    ModelNotFoundError,
    SampleNotFoundError,
    SegmentationError,
    SLTKError,
    UnsupportedFormatError,
    ValidationError,
)


# Convenient re-exports for common operations
def load_poses(path, format=None, fps=25.0, **kwargs):
    """Load poses from file. Convenience wrapper."""
    from sltk.data.formats import load_poses as _load

    return _load(path, format=format or "auto", fps=fps, **kwargs)


def read_elan(path):
    """Read segments from ELAN file. Convenience wrapper."""
    from sltk.io.elan import read_eaf

    return read_eaf(path)


def normalize(poses, method="shoulder_centered", scale="unit_torso"):
    """Normalize poses. Convenience wrapper."""
    from sltk.processing.normalization import normalize_poses

    return normalize_poses(poses, method=method, scale=scale)


__all__ = [
    # Core data structures
    "PoseSequence",
    "Segment",
    "SegmentList",
    "Sample",
    # Convenience functions
    "load_poses",
    "read_elan",
    "normalize",
    # Exceptions
    "SLTKError",
    "ConfigurationError",
    "DatasetError",
    "SampleNotFoundError",
    "FeatureNotFoundError",
    "DatasetNotFoundError",
    "ExtractionError",
    "ExtractionCancelled",
    "ModelNotFoundError",
    "ValidationError",
    "FormatError",
    "UnsupportedFormatError",
    "MetricsError",
    "DependencyError",
    "AnnotationError",
    "SegmentationError",
]
