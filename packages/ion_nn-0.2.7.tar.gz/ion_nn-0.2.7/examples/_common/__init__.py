"""Shared utilities for examples."""
