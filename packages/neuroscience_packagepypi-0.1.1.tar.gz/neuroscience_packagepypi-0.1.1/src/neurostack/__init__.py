from .eeg import load_eeg
from .simulation import run_simple_neuron
from .imaging import load_brain_atlas