import mne

def load_eeg(file):
    """Load EEG file using MNE."""
    raw = mne.io.read_raw(file, preload=True)
    return raw