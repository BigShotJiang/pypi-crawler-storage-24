from brian2 import *

def run_simple_neuron():
    start_scope()

    eqs = '''
    dv/dt = (1 - v) / (10*ms) : 1
    '''

    G = NeuronGroup(10, eqs, method='exact')
    G.v = 0

    run(100*ms)

    return G.v[:]