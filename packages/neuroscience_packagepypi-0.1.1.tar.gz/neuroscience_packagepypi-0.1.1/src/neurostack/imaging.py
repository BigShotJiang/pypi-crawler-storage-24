from nilearn import datasets

def load_brain_atlas():
    return datasets.fetch_atlas_aal()