# NeuroStack

Unified neuroscience toolkit built on:

- MNE-Python (EEG/MEG analysis)
- Brian2 (neural simulation)
- Nilearn (brain imaging)

## Install

pip install neuroscience-packagepypi

## Example

from neurostack import run_simple_neuron
run_simple_neuron()