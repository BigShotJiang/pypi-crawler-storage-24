"""Tests for previously untested PatternsAnnotator behaviours."""

import pytest
from pymultirole_plugins.v1.schema import Document, Sentence

from pyannotators_patterns.patterns import (
    PATTERNS_EXAMPLE_STR,
    PatternsAnnotator,
    PatternsParameters,
)

CC_MAPPING = {"cc": PATTERNS_EXAMPLE_STR}


@pytest.fixture(scope="module")
def annotator():
    return PatternsAnnotator()


@pytest.fixture(scope="module")
def cc_parameters():
    return PatternsParameters(mapping=CC_MAPPING)


# ---------------------------------------------------------------------------
# get_model
# ---------------------------------------------------------------------------


def test_get_model_returns_parameters_class():
    assert PatternsAnnotator.get_model() is PatternsParameters


# ---------------------------------------------------------------------------
# Language validation
# ---------------------------------------------------------------------------


def test_missing_language_raises(annotator, cc_parameters):
    """Document without 'language' metadata must raise AttributeError."""
    with pytest.raises(AttributeError, match="language"):
        annotator.annotate([Document(text="4111111111111111")], cc_parameters)


def test_unsupported_language_raises(annotator, cc_parameters):
    """Document with an unsupported language code must raise AttributeError."""
    with pytest.raises(AttributeError, match="language"):
        annotator.annotate(
            [Document(text="4111111111111111", metadata={"language": "xx"})],
            cc_parameters,
        )


# ---------------------------------------------------------------------------
# Score threshold
# ---------------------------------------------------------------------------


def test_score_threshold_filters_low_confidence(annotator):
    """Results below score_threshold must not be returned."""
    # CC pattern score is 0.3; threshold 0.5 suppresses it when no context words
    params = PatternsParameters(mapping=CC_MAPPING, score_threshold=0.5)
    docs = annotator.annotate([Document(text="4111111111111111", metadata={"language": "en"})], params)
    assert docs[0].annotations == []


def test_score_threshold_zero_returns_results(annotator, cc_parameters):
    """With threshold 0.0 a matching pattern must produce an annotation."""
    docs = annotator.annotate(
        [Document(text="4111111111111111", metadata={"language": "en"})],
        cc_parameters,
    )
    assert len(docs[0].annotations) == 1


# ---------------------------------------------------------------------------
# Context word enhancement
# ---------------------------------------------------------------------------


def test_context_words_boost_score(annotator, cc_parameters):
    """Presence of context words near the match should boost score above the
    raw pattern score of 0.3."""
    # Text without context words — raw score 0.3
    text_no_ctx = "4111111111111111"
    doc_no_ctx = annotator.annotate([Document(text=text_no_ctx, metadata={"language": "en"})], cc_parameters)[0]

    # Text with context words "credit card" — score should be boosted
    text_with_ctx = "my credit card number is 4111111111111111"
    doc_with_ctx = annotator.annotate([Document(text=text_with_ctx, metadata={"language": "en"})], cc_parameters)[0]

    assert len(doc_no_ctx.annotations) == 1
    assert len(doc_with_ctx.annotations) == 1
    assert doc_with_ctx.annotations[0].score > doc_no_ctx.annotations[0].score


# ---------------------------------------------------------------------------
# Multiple documents
# ---------------------------------------------------------------------------


def test_multiple_documents_annotated(annotator, cc_parameters):
    """annotate() must process every document in the input list."""
    docs = annotator.annotate(
        [
            Document(text="4111111111111111", metadata={"language": "en"}),
            Document(text="5555555555554444", metadata={"language": "en"}),
            Document(text="no card here", metadata={"language": "en"}),
        ],
        cc_parameters,
    )
    assert len(docs[0].annotations) == 1
    assert len(docs[1].annotations) == 1
    assert len(docs[2].annotations) == 0


# ---------------------------------------------------------------------------
# Sentence-scoped annotation
# ---------------------------------------------------------------------------


def test_annotations_respect_sentence_spans(annotator, cc_parameters):
    """When sentences are defined, annotation offsets must be absolute (relative
    to the full document text), not relative to the sentence."""
    text = "irrelevant prefix. 4111111111111111 is the number."
    sentence_start = 19
    sentence_end = 35
    doc = Document(
        text=text,
        metadata={"language": "en"},
        sentences=[Sentence(start=sentence_start, end=sentence_end)],
    )
    docs = annotator.annotate([doc], cc_parameters)
    ann = docs[0].annotations
    assert len(ann) == 1
    assert ann[0].start == sentence_start
    assert ann[0].end == sentence_end


def test_no_sentences_uses_full_text(annotator, cc_parameters):
    """Without sentences the annotator spans the full document."""
    text = "4111111111111111"
    docs = annotator.annotate([Document(text=text, metadata={"language": "en"})], cc_parameters)
    ann = docs[0].annotations
    assert len(ann) == 1
    assert ann[0].start == 0
    assert ann[0].end == len(text)


# ---------------------------------------------------------------------------
# Empty / no-match
# ---------------------------------------------------------------------------


def test_empty_sentence_span_produces_no_annotations(annotator, cc_parameters):
    """A sentence span with start == end must be skipped without error."""
    doc = Document(
        text="4111111111111111",
        metadata={"language": "en"},
        sentences=[Sentence(start=5, end=5)],
    )
    docs = annotator.annotate([doc], cc_parameters)
    assert docs[0].annotations == []


def test_no_match_produces_empty_annotations(annotator, cc_parameters):
    """Text with no matching pattern must result in an empty annotation list."""
    docs = annotator.annotate(
        [Document(text="no numbers here", metadata={"language": "en"})],
        cc_parameters,
    )
    assert docs[0].annotations == []
