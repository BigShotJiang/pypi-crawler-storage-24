# pyannotators_patterns

[![license](https://img.shields.io/github/license/oterrier/pyannotators_patterns)](https://github.com/oterrier/pyannotators_patterns/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyannotators_patterns/workflows/tests/badge.svg)](https://github.com/oterrier/pyannotators_patterns/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyannotators_patterns)](https://codecov.io/gh/oterrier/pyannotators_patterns)
[![docs](https://img.shields.io/readthedocs/pyannotators_patterns)](https://pyannotators_patterns.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyannotators_patterns)](https://pypi.org/project/pyannotators_patterns/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyannotators_patterns)](https://pypi.org/project/pyannotators_patterns/)

Annotator based on Presidio regex pattern recognizers.

## Installation

```
pip install pyannotators-patterns
```

## Developing

### Prerequisites

You will need [uv](https://github.com/astral-sh/uv) (package manager) and Python 3.12+.

Clone the repository:

```
git clone https://github.com/oterrier/pyannotators_patterns
cd pyannotators_patterns
```

Install dependencies (including test extras):

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting and formatting

```
uv run ruff check .
uv run ruff format --check .
```

To auto-fix formatting:

```
uv run ruff format .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
