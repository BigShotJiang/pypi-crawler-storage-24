"""Tests for clipboard tools."""

import pytest
from fastmcp import Client


async def test_get_clipboard(client: Client):
    result = await client.call_tool("vnc_get_clipboard", {"session_id": "testhost:5900"})
    assert "test clipboard content" in result.content[0].text


async def test_set_clipboard(client: Client):
    result = await client.call_tool("vnc_set_clipboard", {
        "session_id": "testhost:5900",
        "text": "pasted text",
    })
    assert "11 characters" in result.content[0].text


async def test_set_clipboard_non_latin1(client: Client):
    """M3: Non-latin-1 characters produce clear ToolError."""
    with pytest.raises(Exception, match="latin-1"):
        await client.call_tool("vnc_set_clipboard", {
            "session_id": "testhost:5900",
            "text": "hello \u4e16\u754c",  # Chinese characters
        })


async def test_set_clipboard_latin1_accented(client: Client):
    """Latin-1 accented characters should work fine."""
    result = await client.call_tool("vnc_set_clipboard", {
        "session_id": "testhost:5900",
        "text": "caf\u00e9 cr\u00e8me",
    })
    assert "characters" in result.content[0].text
