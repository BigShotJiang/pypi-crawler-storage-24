"""Tests for mouse input tools."""

import pytest
from fastmcp import Client


async def test_click(client: Client):
    result = await client.call_tool("vnc_click", {
        "session_id": "testhost:5900",
        "x": 500,
        "y": 300,
    })
    assert "left" in result.content[0].text
    assert "(500, 300)" in result.content[0].text


async def test_click_right(client: Client):
    result = await client.call_tool("vnc_click", {
        "session_id": "testhost:5900",
        "x": 100,
        "y": 200,
        "button": "right",
    })
    assert "right" in result.content[0].text


async def test_click_invalid_button(client: Client):
    with pytest.raises(Exception, match="Unknown button"):
        await client.call_tool("vnc_click", {
            "session_id": "testhost:5900",
            "x": 0,
            "y": 0,
            "button": "banana",
        })


async def test_double_click(client: Client):
    result = await client.call_tool("vnc_double_click", {
        "session_id": "testhost:5900",
        "x": 400,
        "y": 500,
    })
    assert "Double-clicked" in result.content[0].text


async def test_move(client: Client):
    result = await client.call_tool("vnc_move", {
        "session_id": "testhost:5900",
        "x": 960,
        "y": 540,
    })
    assert "Moved" in result.content[0].text
    assert "(960, 540)" in result.content[0].text


async def test_drag(client: Client):
    result = await client.call_tool("vnc_drag", {
        "session_id": "testhost:5900",
        "start_x": 100,
        "start_y": 100,
        "end_x": 300,
        "end_y": 300,
    })
    assert "Dragged" in result.content[0].text
    assert "(100, 100)" in result.content[0].text
    assert "(300, 300)" in result.content[0].text


async def test_scroll_down(client: Client):
    result = await client.call_tool("vnc_scroll", {
        "session_id": "testhost:5900",
        "x": 500,
        "y": 500,
        "direction": "down",
        "clicks": 5,
    })
    assert "down" in result.content[0].text
    assert "5x" in result.content[0].text


async def test_scroll_up(client: Client):
    result = await client.call_tool("vnc_scroll", {
        "session_id": "testhost:5900",
        "x": 500,
        "y": 500,
        "direction": "up",
    })
    assert "up" in result.content[0].text


async def test_scroll_invalid_direction(client: Client):
    with pytest.raises(Exception, match="must be"):
        await client.call_tool("vnc_scroll", {
            "session_id": "testhost:5900",
            "x": 0,
            "y": 0,
            "direction": "sideways",
        })


async def test_click_negative_x(client: Client):
    """H4: Negative coordinates produce clear ToolError."""
    with pytest.raises(Exception, match="out of range"):
        await client.call_tool("vnc_click", {
            "session_id": "testhost:5900",
            "x": -1,
            "y": 100,
        })


async def test_click_negative_y(client: Client):
    with pytest.raises(Exception, match="out of range"):
        await client.call_tool("vnc_click", {
            "session_id": "testhost:5900",
            "x": 100,
            "y": -1,
        })


async def test_click_x_too_large(client: Client):
    """H4: x >= width is out of range."""
    with pytest.raises(Exception, match="out of range"):
        await client.call_tool("vnc_click", {
            "session_id": "testhost:5900",
            "x": 1920,  # width is 1920, so valid is 0..1919
            "y": 100,
        })


async def test_click_y_too_large(client: Client):
    with pytest.raises(Exception, match="out of range"):
        await client.call_tool("vnc_click", {
            "session_id": "testhost:5900",
            "x": 100,
            "y": 1080,  # height is 1080, valid is 0..1079
        })


async def test_move_out_of_bounds(client: Client):
    with pytest.raises(Exception, match="out of range"):
        await client.call_tool("vnc_move", {
            "session_id": "testhost:5900",
            "x": 5000,
            "y": 100,
        })


async def test_drag_end_out_of_bounds(client: Client):
    """H4: Drag validates both start and end coordinates."""
    with pytest.raises(Exception, match="out of range"):
        await client.call_tool("vnc_drag", {
            "session_id": "testhost:5900",
            "start_x": 100,
            "start_y": 100,
            "end_x": 5000,
            "end_y": 100,
        })
