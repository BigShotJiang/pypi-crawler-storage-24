"""mcvnc -- VNC client MCP server for remote desktop interaction."""

__version__ = "2026.03.07"
