"""mcvnc entry point -- VNC client MCP server."""

import sys

import mcvnc._clipboard  # noqa: F401
import mcvnc._connect  # noqa: F401
import mcvnc._keyboard  # noqa: F401
import mcvnc._mouse  # noqa: F401
import mcvnc._prompts  # noqa: F401
import mcvnc._resources  # noqa: F401
import mcvnc._screen  # noqa: F401
from mcvnc import __version__
from mcvnc._state import mcp  # noqa: F401


def main():
    print(f"mcvnc v{__version__}", file=sys.stderr)
    mcp.run()
