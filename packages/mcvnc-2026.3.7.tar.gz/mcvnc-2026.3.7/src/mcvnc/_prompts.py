"""Guided workflow prompts."""

from fastmcp import Context

from mcvnc._state import mcp


@mcp.prompt()
async def remote_desktop(ctx: Context) -> str:
    """Guided workflow for interacting with a remote desktop via VNC.

    Walks through connecting, observing the screen, and interacting.
    """
    return """\
You are remotely controlling a desktop via VNC. Follow this workflow:

1. **Connect** — Use vnc_connect(host, port, password) to establish a session.
   The session_id defaults to "host:port" or provide your own alias.

2. **Observe** — Take a screenshot with vnc_screenshot(session_id).
   Study the image carefully to understand what's on screen.
   Note window positions, button locations, text fields, and their coordinates.

3. **Interact** — Based on what you see:
   - Click buttons/links: vnc_click(session_id, x, y)
   - Type text: vnc_type_text(session_id, "text") for content,
     vnc_press_key(session_id, "Return") for special keys
   - Key combos: vnc_key_combo(session_id, ["ctrl", "c"]) for shortcuts
   - Scroll: vnc_scroll(session_id, x, y, "down", 3)
   - Drag: vnc_drag(session_id, start_x, start_y, end_x, end_y)

4. **Verify** — After each interaction, take another screenshot to confirm
   the action had the expected effect. The screen may take a moment to update.

5. **Clipboard** — Use vnc_get_clipboard / vnc_set_clipboard to transfer text
   between you and the remote desktop.

6. **Disconnect** — When done, use vnc_disconnect(session_id).

Tips:
- Coordinates are absolute pixels from the top-left corner.
- Use vnc_screen_info to check dimensions without a full screenshot.
- If the screen looks blurry, the server may still be sending updates.
  Wait a moment and take another screenshot.
- For menus, click to open, screenshot to see options, then click the option.
"""
