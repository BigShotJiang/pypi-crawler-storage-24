"""Core errors raised by EnvBind."""

from __future__ import annotations


class EnvParseError(RuntimeError):
    """Base class for all EnvBind failures."""


class MissingEnvironmentVariableError(EnvParseError):
    """Raised when a required variable is missing from the process environment."""


class InvalidEnvironmentValueError(EnvParseError):
    """Raised when an environment variable value cannot be converted to target type."""
