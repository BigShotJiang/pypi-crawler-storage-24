"""Core container that materialises all environment descriptors."""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from ._fields import EnvField


class ParameterSource:
    """Base class for classes backed by environment variable descriptors."""

    def __init__(self) -> None:
        """Load all declared environment fields at construction time."""
        self._coerce_fields()

    @classmethod
    def _declared_fields(cls) -> dict[str, EnvField]:
        """Collect declared ``EnvField`` descriptors from the class hierarchy."""
        fields: dict[str, EnvField] = {}
        for base in reversed(cls.__mro__):
            for name, value in base.__dict__.items():
                if isinstance(value, EnvField):
                    fields[name] = value
        return fields

    @classmethod
    def _iter_fields(cls) -> Iterator[tuple[str, EnvField]]:
        """Yield declared field names and descriptors in deterministic order."""
        yield from cls._declared_fields().items()

    def _coerce_fields(self) -> None:
        """Resolve all configured fields and cache values on this instance."""
        for name, field in self._declared_fields().items():
            self.__dict__[name] = field.resolve()

    def as_dict(self) -> dict[str, Any]:
        """Return all parsed fields as a dictionary."""
        return {name: getattr(self, name) for name in self._declared_fields()}

    def __repr__(self) -> str:
        """Return a short representation with parsed values."""
        parts = [f"{name}={value!r}" for name, value in self.as_dict().items()]
        return f"{self.__class__.__name__}({', '.join(parts)})"
