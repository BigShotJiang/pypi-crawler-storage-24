"""Environment field descriptors."""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import Any

from ._exceptions import MissingEnvironmentVariableError

_MISSING = object()


class EnvField(ABC):
    """Descriptor that reads one environment variable and returns a typed value."""

    def __init__(
        self,
        *,
        envar: str,
        optional: bool = False,
        default: Any = _MISSING,
    ) -> None:
        """Create the descriptor.

        Args:
            envar: The environment variable name to read.
            optional: Set true to allow missing value.
            default: Optional default value used when input is not present.
        """
        if not envar:
            raise ValueError("envar must be a non-empty string.")
        self._envar = envar
        self._optional = optional
        self._default = default
        self._attr_name: str | None = None

    @property
    def envar(self) -> str:
        """Return the linked environment variable name."""
        return self._envar

    @property
    def optional(self) -> bool:
        """Return whether this field allows a missing variable."""
        return self._optional

    def __set_name__(self, owner: type[object], name: str) -> None:
        """Store the attribute name when class body binds the descriptor."""
        self._attr_name = name

    @property
    def attr_name(self) -> str:
        """Return the bound attribute name."""
        if self._attr_name is None:
            raise RuntimeError("Environment field is not attached to a class.")
        return self._attr_name

    @property
    def has_default(self) -> bool:
        """Return True when a default value exists."""
        return self._default is not _MISSING

    def __get__(self, instance: object | None, owner: type[object]) -> Any:
        """Resolve and cache the parsed value for the current instance."""
        if instance is None:
            return self
        if self._attr_name is None:
            raise RuntimeError("Environment field is not attached to a class.")
        if self._attr_name in instance.__dict__:
            return instance.__dict__[self._attr_name]
        value = self.resolve()
        instance.__dict__[self._attr_name] = value
        return value

    def __set__(self, instance: object, value: Any) -> None:
        """Block assignment after parse time to preserve deterministic parsing."""
        raise AttributeError("Environment fields are read-only.")

    def resolve(self) -> Any:
        """Resolve the environment variable and return a typed value."""
        raw = os.getenv(self._envar)
        if raw is not None:
            return self._coerce(raw)
        if self._optional:
            if self.has_default:
                return self._default
            return None
        if self.has_default:
            return self._default
        raise MissingEnvironmentVariableError(
            f"Missing required environment variable: {self._envar}"
        )

    @abstractmethod
    def _coerce(self, raw: str) -> Any:
        """Convert a raw environment string into the target type."""
