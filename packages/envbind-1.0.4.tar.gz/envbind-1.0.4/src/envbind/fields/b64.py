"""Base64-decoded string environment field."""

from __future__ import annotations

import base64

from .._exceptions import InvalidEnvironmentValueError
from .._fields import EnvField


class B64DecodedStringEnv(EnvField):
    """Decode a base64 value and return text."""

    def _coerce(self, raw: str) -> str:
        """Decode a base64-encoded certificate string."""
        if raw == "":
            raise InvalidEnvironmentValueError(f"Value for {self._envar} must not be empty")
        try:
            decoded = base64.b64decode(raw, validate=True)
        except ValueError as exc:
            raise InvalidEnvironmentValueError(
                f"Value for {self._envar} is not valid base64"
            ) from exc
        try:
            return decoded.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise InvalidEnvironmentValueError(
                f"Value for {self._envar} is not valid utf-8 text"
            ) from exc
