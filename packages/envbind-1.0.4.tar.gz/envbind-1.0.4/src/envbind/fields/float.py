"""Float environment field."""

from __future__ import annotations

from .._exceptions import InvalidEnvironmentValueError
from .._fields import EnvField


class FloatEnv(EnvField):
    """Parse decimal values."""

    def _coerce(self, raw: str) -> float:
        """Convert text into a float."""
        try:
            return float(raw)
        except ValueError as exc:
            raise InvalidEnvironmentValueError(
                f"Value for {self._envar} must be a float, got {raw!r}"
            ) from exc
