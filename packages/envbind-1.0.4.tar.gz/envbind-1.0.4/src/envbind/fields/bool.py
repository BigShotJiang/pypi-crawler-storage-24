"""Boolean environment field."""

from __future__ import annotations

from .._exceptions import InvalidEnvironmentValueError
from .._fields import EnvField


class BooleanEnv(EnvField):
    """Parse booleans from text."""

    _TRUTHY = {"1", "true", "yes", "on", "y", "t"}
    _FALSEY = {"0", "false", "no", "off", "n", "f"}

    def _coerce(self, raw: str) -> bool:
        """Convert input text into a bool."""
        value = raw.strip().lower()
        if value in self._TRUTHY:
            return True
        if value in self._FALSEY:
            return False
        raise InvalidEnvironmentValueError(f"Value for {self._envar} must be a boolean text")
