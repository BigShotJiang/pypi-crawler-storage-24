"""Integer environment field."""

from __future__ import annotations

from .._exceptions import InvalidEnvironmentValueError
from .._fields import EnvField


class IntEnv(EnvField):
    """Parse integer values."""

    def _coerce(self, raw: str) -> int:
        """Convert text into an ``int``."""
        try:
            return int(raw)
        except ValueError as exc:
            raise InvalidEnvironmentValueError(
                f"Value for {self._envar} must be an integer, got {raw!r}"
            ) from exc
