"""String environment field."""

from __future__ import annotations

from .._exceptions import InvalidEnvironmentValueError
from .._fields import EnvField


class StringEnv(EnvField):
    """Parse string values and reject empty input."""

    def _coerce(self, raw: str) -> str:
        """Return a non-empty string."""
        if raw == "":
            raise InvalidEnvironmentValueError(f"Value for {self._envar} must not be empty")
        return raw
