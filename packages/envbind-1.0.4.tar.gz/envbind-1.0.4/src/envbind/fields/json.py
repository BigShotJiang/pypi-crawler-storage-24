"""JSON environment field."""

from __future__ import annotations

import json
from typing import Any

from .._exceptions import InvalidEnvironmentValueError
from .._fields import EnvField


class JSONEnv(EnvField):
    """Parse JSON payloads."""

    def _coerce(self, raw: str) -> Any:
        """Parse JSON text."""
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise InvalidEnvironmentValueError(
                f"Value for {self._envar} must be valid JSON"
            ) from exc
