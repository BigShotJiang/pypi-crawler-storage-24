"""Enum environment field."""

from __future__ import annotations

from enum import Enum
from typing import Any

from .._exceptions import InvalidEnvironmentValueError
from .._fields import _MISSING, EnvField


class EnumEnv(EnvField):
    """Parse enum members from text."""

    def __init__(
        self,
        *,
        enum_type: type[Enum],
        envar: str,
        optional: bool = False,
        default: Any = _MISSING,
        case_sensitive: bool = False,
    ) -> None:
        """Create enum field.

        Args:
            enum_type: Target enum class.
            envar: The environment variable name to read.
            optional: Set true to allow missing variable.
            default: Optional default value used when input is not present.
            case_sensitive: Keep name and value comparison case-sensitive.
        """
        if not isinstance(enum_type, type) or not issubclass(enum_type, Enum):
            raise TypeError("enum_type must be an Enum subclass")
        super().__init__(envar=envar, optional=optional, default=default)
        self._enum_type = enum_type
        self._case_sensitive = case_sensitive

    def _coerce(self, raw: str) -> Enum:
        """Map text to an enum member."""
        candidate = raw.strip()
        if self._case_sensitive:
            for option in self._enum_type:
                if candidate == option.name or candidate == str(option.value):
                    return option
        else:
            candidate_lower = candidate.lower()
            for option in self._enum_type:
                option_name = option.name.lower()
                option_value = str(option.value).lower()
                if candidate_lower in (option_name, option_value):
                    return option
        raise InvalidEnvironmentValueError(
            f"Value for {self._envar} must match enum {self._enum_type.__name__}"
        )
