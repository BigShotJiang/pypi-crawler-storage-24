"""List environment field."""

from __future__ import annotations

from typing import Any

from .._exceptions import InvalidEnvironmentValueError
from .._fields import _MISSING, EnvField


class ListEnv(EnvField):
    """Parse delimiter-separated values into a list."""

    def __init__(
        self,
        *,
        envar: str,
        delimiter: str = ",",
        strip: bool = True,
        optional: bool = False,
        default: Any = _MISSING,
    ) -> None:
        """Create list field.

        Args:
            envar: The environment variable name to read.
            delimiter: Character used to split values.
            strip: Remove surrounding spaces from each item.
            optional: Set true to allow missing variable.
            default: Optional default value used when input is not present.
        """
        if delimiter == "":
            raise ValueError("delimiter must not be empty")
        super().__init__(envar=envar, optional=optional, default=default)
        self._delimiter = delimiter
        self._strip = strip

    def _coerce(self, raw: str) -> list[str]:
        """Split incoming value into list items."""
        if raw == "":
            raise InvalidEnvironmentValueError(f"Value for {self._envar} must not be empty")
        parts = raw.split(self._delimiter)
        if self._strip:
            return [part.strip() for part in parts]
        return parts
