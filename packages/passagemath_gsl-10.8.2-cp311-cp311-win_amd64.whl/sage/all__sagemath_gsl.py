# sage_setup: distribution = sagemath-gsl
# start delvewheel patch
def _delvewheel_patch_1_12_0():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'passagemath_gsl.libs'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_12_0()
del _delvewheel_patch_1_12_0
# end delvewheel patch

from sage.all__sagemath_modules import *

from sage.calculus.all__sagemath_gsl import *

from sage.probability.all import *
