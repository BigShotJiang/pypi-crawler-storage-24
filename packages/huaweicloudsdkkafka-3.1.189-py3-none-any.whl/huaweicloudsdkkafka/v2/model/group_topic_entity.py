# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class GroupTopicEntity:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'topic': 'str',
        'partitions': 'int',
        'lag': 'int'
    }

    attribute_map = {
        'topic': 'topic',
        'partitions': 'partitions',
        'lag': 'lag'
    }

    def __init__(self, topic=None, partitions=None, lag=None):
        r"""GroupTopicEntity

        The model defined in huaweicloud sdk

        :param topic: Topic名称
        :type topic: str
        :param partitions: 分区
        :type partitions: int
        :param lag: 消息堆积数量
        :type lag: int
        """
        
        

        self._topic = None
        self._partitions = None
        self._lag = None
        self.discriminator = None

        if topic is not None:
            self.topic = topic
        if partitions is not None:
            self.partitions = partitions
        if lag is not None:
            self.lag = lag

    @property
    def topic(self):
        r"""Gets the topic of this GroupTopicEntity.

        Topic名称

        :return: The topic of this GroupTopicEntity.
        :rtype: str
        """
        return self._topic

    @topic.setter
    def topic(self, topic):
        r"""Sets the topic of this GroupTopicEntity.

        Topic名称

        :param topic: The topic of this GroupTopicEntity.
        :type topic: str
        """
        self._topic = topic

    @property
    def partitions(self):
        r"""Gets the partitions of this GroupTopicEntity.

        分区

        :return: The partitions of this GroupTopicEntity.
        :rtype: int
        """
        return self._partitions

    @partitions.setter
    def partitions(self, partitions):
        r"""Sets the partitions of this GroupTopicEntity.

        分区

        :param partitions: The partitions of this GroupTopicEntity.
        :type partitions: int
        """
        self._partitions = partitions

    @property
    def lag(self):
        r"""Gets the lag of this GroupTopicEntity.

        消息堆积数量

        :return: The lag of this GroupTopicEntity.
        :rtype: int
        """
        return self._lag

    @lag.setter
    def lag(self, lag):
        r"""Sets the lag of this GroupTopicEntity.

        消息堆积数量

        :param lag: The lag of this GroupTopicEntity.
        :type lag: int
        """
        self._lag = lag

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, GroupTopicEntity):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
