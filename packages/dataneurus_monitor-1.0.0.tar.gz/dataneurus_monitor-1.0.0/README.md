# Drift Monitor SDK

SDK for sending telemetry to Drift Model Accelerator backend.

## Install

pip install -e .

## Example

from drift_monitor import DataNeurusMonitor

monitor = DataNeurusMonitor(
    model_id="fraud_model",
    model_version_id="v1",
    endpoint="http://localhost:8000"
)

monitor.log_prediction(
    {"age":45,"income":80000},
    prediction=0.72
)