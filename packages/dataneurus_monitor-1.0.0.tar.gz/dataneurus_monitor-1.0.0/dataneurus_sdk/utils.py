import uuid
from datetime import datetime, timezone


def generate_prediction_id():
    return str(uuid.uuid4())


def utc_timestamp():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
