"""Smoke tests for opinions and tool structure."""

from clawdflare.lib.opinions import OPINIONS


def test_opinions_not_empty():
    assert len(OPINIONS) > 0


def test_opinions_have_required_keys():
    required = {"setting", "want", "reason", "severity"}
    for op in OPINIONS:
        assert required.issubset(op.keys()), f"Missing keys in opinion: {op['setting']}"


def test_severities_valid():
    valid = {"critical", "warning", "info"}
    for op in OPINIONS:
        assert op["severity"] in valid, f"Invalid severity in {op['setting']}: {op['severity']}"
