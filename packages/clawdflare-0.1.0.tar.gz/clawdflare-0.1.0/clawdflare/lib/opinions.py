"""Opinionated defaults for Cloudflare zone settings.

Each opinion is a dict with:
  - setting: the Cloudflare setting ID
  - want: the desired value
  - reason: why this is the right default
  - severity: "critical" | "warning" | "info"
"""

OPINIONS: list[dict] = [
    {
        "setting": "ssl",
        "want": "full",
        "reason": "Full SSL encrypts traffic between Cloudflare and your origin. "
                  "'flexible' leaves origin traffic unencrypted.",
        "severity": "critical",
    },
    {
        "setting": "always_use_https",
        "want": "on",
        "reason": "Redirects all HTTP requests to HTTPS.",
        "severity": "critical",
    },
    {
        "setting": "min_tls_version",
        "want": "1.2",
        "reason": "TLS 1.0 and 1.1 are deprecated and vulnerable.",
        "severity": "critical",
    },
    {
        "setting": "automatic_https_rewrites",
        "want": "on",
        "reason": "Fixes mixed content by rewriting HTTP URLs to HTTPS.",
        "severity": "warning",
    },
    {
        "setting": "security_header",
        "want": {
            "strict_transport_security": {
                "enabled": True,
                "max_age": 31536000,
                "include_subdomains": True,
                "nosniff": True,
            }
        },
        "reason": "HSTS tells browsers to only connect via HTTPS. "
                  "max_age=1yr, include subdomains, X-Content-Type-Options: nosniff.",
        "severity": "critical",
    },
    {
        "setting": "tls_1_3",
        "want": "zrt",
        "reason": "TLS 1.3 with 0-RTT for faster handshakes.",
        "severity": "warning",
    },
    {
        "setting": "opportunistic_encryption",
        "want": "on",
        "reason": "Enables opportunistic encryption for HTTP/2.",
        "severity": "info",
    },
    {
        "setting": "browser_cache_ttl",
        "want": 14400,
        "reason": "4-hour browser cache is a sensible default. "
                  "Too short wastes bandwidth, too long causes stale content.",
        "severity": "info",
    },
    {
        "setting": "early_hints",
        "want": "on",
        "reason": "HTTP 103 Early Hints improves page load performance.",
        "severity": "info",
    },
    {
        "setting": "http3",
        "want": "on",
        "reason": "HTTP/3 (QUIC) reduces latency, especially on mobile.",
        "severity": "warning",
    },
    {
        "setting": "0rtt",
        "want": "on",
        "reason": "0-RTT resumption speeds up repeat connections.",
        "severity": "info",
    },
    {
        "setting": "always_online",
        "want": "on",
        "reason": "Serves cached pages when your origin is down.",
        "severity": "warning",
    },
    {
        "setting": "email_obfuscation",
        "want": "on",
        "reason": "Obfuscates email addresses on your site from scrapers.",
        "severity": "info",
    },
    {
        "setting": "hotlink_protection",
        "want": "on",
        "reason": "Prevents other sites from embedding your images.",
        "severity": "info",
    },
]
