"""clawdflare — Opinionated Cloudflare management."""

__version__ = "0.1.0"


def run():
    """Entry point for `clawdflare-mcp` console script."""
    from clawdflare.mcp import mcp
    mcp.run()
