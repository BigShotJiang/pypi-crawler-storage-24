"""
uni_gzip.py 单元测试

覆盖所有导出函数：
- readJsonGz / writeJsonGz
- compressJSON
- readTxtGz / writeTxtGz
- compressTxt
"""

import gzip
import json
import os
from pathlib import Path

import pytest
from uni_gzip import (
    compressJSON,
    compressTxt,
    readJsonGz,
    readTxtGz,
    writeJsonGz,
    writeTxtGz,
)
from uni_gzip.exceptions import (
    UniGzipJsonReadError,
    UniGzipJsonWriteError,
    UniGzipTxtReadError,
    UniGzipTxtWriteError,
)


# ---------------------------------------------------------------------------
# compressJSON
# ---------------------------------------------------------------------------

class TestCompressJSON:
    def test_dict_returns_gzip_bytes(self):
        data = {"key": "value", "num": 123}
        result = compressJSON(data)
        assert isinstance(result, bytes)
        assert result[:2] == b"\x1f\x8b"  # gzip magic number

    def test_roundtrip_dict(self):
        data = {"你好": [1, 2, 3], "nested": {"a": True}}
        compressed = compressJSON(data)
        decompressed = gzip.decompress(compressed).decode("utf-8")
        assert json.loads(decompressed) == data

    def test_empty_list(self):
        result = compressJSON([])
        decompressed = gzip.decompress(result).decode("utf-8")
        assert json.loads(decompressed) == []

    def test_compact_format_no_spaces(self):
        """Compact JSON: no spaces after separators"""
        result = compressJSON({"a": 1, "b": 2})
        decompressed = gzip.decompress(result).decode("utf-8")
        assert " " not in decompressed
        assert "," in decompressed  # compact but still valid JSON

    def test_unicode_preserved(self):
        data = {"中文": "你好", "emoji": "😀"}
        compressed = compressJSON(data)
        decompressed = gzip.decompress(compressed).decode("utf-8")
        assert json.loads(decompressed) == data

    def test_non_serializable_raises_type_error(self):
        class NotSerializable:
            pass
        with pytest.raises(TypeError):
            compressJSON({"bad": NotSerializable()})

    def test_none_value(self):
        compressed = compressJSON(None)
        decompressed = gzip.decompress(compressed).decode("utf-8")
        assert json.loads(decompressed) is None


# ---------------------------------------------------------------------------
# compressTxt
# ---------------------------------------------------------------------------

class TestCompressTxt:
    def test_string_returns_gzip_bytes(self):
        result = compressTxt("hello world")
        assert isinstance(result, bytes)
        assert result[:2] == b"\x1f\x8b"

    def test_roundtrip_string(self):
        original = "hello\nworld"
        compressed = compressTxt(original)
        decompressed = gzip.decompress(compressed).decode("utf-8")
        assert decompressed == original

    def test_iterable_of_strings_joined(self):
        lines = ["line1", "line2", "line3"]
        compressed = compressTxt(lines)
        decompressed = gzip.decompress(compressed).decode("utf-8")
        assert decompressed == "".join(lines)

    def test_unicode_string(self):
        data = "中文内容\n英文内容\n日本語"
        compressed = compressTxt(data)
        decompressed = gzip.decompress(compressed).decode("utf-8")
        assert decompressed == data

    def test_empty_string(self):
        compressed = compressTxt("")
        decompressed = gzip.decompress(compressed).decode("utf-8")
        assert decompressed == ""

    def test_empty_iterable(self):
        compressed = compressTxt([])
        decompressed = gzip.decompress(compressed).decode("utf-8")
        assert decompressed == ""

    def test_non_string_non_iterable_raises_type_error(self):
        with pytest.raises(TypeError):
            compressTxt(12345)


# ---------------------------------------------------------------------------
# readJsonGz / writeJsonGz — 真实文件测试
# ---------------------------------------------------------------------------

class TestReadWriteJsonGz:
    def test_write_then_read_roundtrip(self, tmp_path):
        data = {"key": "value", "list": [1, 2, 3], "unicode": "你好"}
        path = tmp_path / "test.json.gz"
        writeJsonGz(path, data)
        result = readJsonGz(path)
        assert result == data

    def test_pathlib_path_both_directions(self, tmp_path):
        data = {"pathlib": True}
        path = Path(tmp_path) / "path.json.gz"
        writeJsonGz(path, data)
        result = readJsonGz(path)
        assert result == data

    def test_empty_list_roundtrip(self, tmp_path):
        path = tmp_path / "empty.json.gz"
        writeJsonGz(path, [])
        assert readJsonGz(path) == []

    def test_nested_dict_roundtrip(self, tmp_path):
        data = {"outer": {"inner": {"deep": True}}}
        path = tmp_path / "nested.json.gz"
        writeJsonGz(path, data)
        assert readJsonGz(path) == data


# ---------------------------------------------------------------------------
# readTxtGz / writeTxtGz — 真实文件测试
# ---------------------------------------------------------------------------

class TestReadWriteTxtGz:
    def test_write_then_read_string_roundtrip(self, tmp_path):
        content = "hello world 你好"
        path = tmp_path / "test.txt.gz"
        writeTxtGz(path, content)
        result = readTxtGz(path)
        assert result == content

    def test_write_then_read_iterable_roundtrip(self, tmp_path):
        lines = ["line1\n", "line2\n", "line3"]
        path = tmp_path / "test.txt.gz"
        writeTxtGz(path, lines)
        result = readTxtGz(path)
        assert result == "".join(lines)

    def test_unicode_content_roundtrip(self, tmp_path):
        content = "中文\n日本語\n한국어\nالعربية"
        path = tmp_path / "unicode.txt.gz"
        writeTxtGz(path, content)
        assert readTxtGz(path) == content

    def test_pathlib_path_both_directions(self, tmp_path):
        content = "pathlib test"
        path = Path(tmp_path) / "path.txt.gz"
        writeTxtGz(path, content)
        assert readTxtGz(path) == content


# ---------------------------------------------------------------------------
# 错误路径 — mock gzip.open
# ---------------------------------------------------------------------------

class TestReadJsonGzErrors:
    def test_file_not_found_raises_json_read_error(self, mocker):
        mocker.patch("gzip.open", side_effect=FileNotFoundError("no such file"))
        with pytest.raises(UniGzipJsonReadError) as exc_info:
            readJsonGz("/nonexistent/file.json.gz")
        assert exc_info.value.file_path == "/nonexistent/file.json.gz"

    def test_bad_gzip_format_raises_json_read_error(self, mocker):
        mocker.patch("gzip.open", side_effect=gzip.BadGzipFile("not valid gzip"))
        with pytest.raises(UniGzipJsonReadError) as exc_info:
            readJsonGz("/corrupt/file.json.gz")
        assert "Invalid gzip format" in str(exc_info.value)

    def test_invalid_json_raises_json_read_error(self, mocker):
        from io import StringIO
        mock_file = StringIO("not valid json{")
        mocker.patch("gzip.open", return_value=mock_file)
        with pytest.raises(UniGzipJsonReadError) as exc_info:
            readJsonGz("/bad/file.json.gz")
        assert "JSON parsing error" in str(exc_info.value)

    def test_os_error_raises_json_read_error(self, mocker):
        mocker.patch("gzip.open", side_effect=OSError("I/O error"))
        with pytest.raises(UniGzipJsonReadError):
            readJsonGz("/error/file.json.gz")


class TestWriteJsonGzErrors:
    def test_permission_error_raises_write_error(self, mocker):
        mocker.patch("gzip.open", side_effect=PermissionError("access denied"))
        with pytest.raises(UniGzipJsonWriteError) as exc_info:
            writeJsonGz("/denied/file.json.gz", {"data": True})
        assert exc_info.value.file_path == "/denied/file.json.gz"

    def test_os_error_raises_write_error(self, mocker):
        mocker.patch("gzip.open", side_effect=OSError("disk error"))
        with pytest.raises(UniGzipJsonWriteError):
            writeJsonGz("/error/file.json.gz", {"data": True})

    def test_non_serializable_raises_type_error(self, mocker):
        class Bad:
            pass
        with pytest.raises(TypeError):
            writeJsonGz("/tmp/out.json.gz", {"bad": Bad()})


class TestReadTxtGzErrors:
    def test_file_not_found_raises_txt_read_error(self, mocker):
        mocker.patch("gzip.open", side_effect=FileNotFoundError("no such file"))
        with pytest.raises(UniGzipTxtReadError) as exc_info:
            readTxtGz("/nonexistent/file.txt.gz")
        assert exc_info.value.file_path == "/nonexistent/file.txt.gz"

    def test_bad_gzip_format_raises_txt_read_error(self, mocker):
        mocker.patch("gzip.open", side_effect=gzip.BadGzipFile("not valid gzip"))
        with pytest.raises(UniGzipTxtReadError):
            readTxtGz("/corrupt/file.txt.gz")

    def test_unicode_decode_error_raises_txt_read_error(self, mocker):
        mocker.patch("gzip.open", side_effect=UnicodeDecodeError("utf-8", b"\x80", 0, 1, "invalid"))
        with pytest.raises(UniGzipTxtReadError) as exc_info:
            readTxtGz("/bad/file.txt.gz")
        assert "Encoding error" in str(exc_info.value)

    def test_os_error_raises_txt_read_error(self, mocker):
        mocker.patch("gzip.open", side_effect=OSError("I/O error"))
        with pytest.raises(UniGzipTxtReadError):
            readTxtGz("/error/file.txt.gz")


class TestWriteTxtGzErrors:
    def test_permission_error_raises_write_error(self, mocker):
        mocker.patch("gzip.open", side_effect=PermissionError("access denied"))
        with pytest.raises(UniGzipTxtWriteError) as exc_info:
            writeTxtGz("/denied/file.txt.gz", "content")
        assert exc_info.value.file_path == "/denied/file.txt.gz"

    def test_os_error_raises_write_error(self, mocker):
        mocker.patch("gzip.open", side_effect=OSError("disk error"))
        with pytest.raises(UniGzipTxtWriteError):
            writeTxtGz("/error/file.txt.gz", "content")

    def test_non_string_non_iterable_raises_type_error(self, mocker):
        with pytest.raises(TypeError):
            writeTxtGz("/tmp/out.txt.gz", 12345)


# ---------------------------------------------------------------------------
# Exception 属性
# ---------------------------------------------------------------------------

class TestExceptionAttributes:
    def test_json_read_error_has_message_and_file_path(self, mocker):
        mocker.patch("gzip.open", side_effect=FileNotFoundError())
        with pytest.raises(UniGzipJsonReadError) as exc_info:
            readJsonGz("/test/path.json.gz")
        assert exc_info.value.file_path == "/test/path.json.gz"
        assert exc_info.value.message is not None

    def test_json_write_error_has_message_and_file_path(self, mocker):
        mocker.patch("gzip.open", side_effect=PermissionError())
        with pytest.raises(UniGzipJsonWriteError) as exc_info:
            writeJsonGz("/test/path.json.gz", {})
        assert exc_info.value.file_path == "/test/path.json.gz"

    def test_txt_read_error_has_message_and_file_path(self, mocker):
        mocker.patch("gzip.open", side_effect=FileNotFoundError())
        with pytest.raises(UniGzipTxtReadError) as exc_info:
            readTxtGz("/test/path.txt.gz")
        assert exc_info.value.file_path == "/test/path.txt.gz"

    def test_txt_write_error_has_message_and_file_path(self, mocker):
        mocker.patch("gzip.open", side_effect=PermissionError())
        with pytest.raises(UniGzipTxtWriteError) as exc_info:
            writeTxtGz("/test/path.txt.gz", "content")
        assert exc_info.value.file_path == "/test/path.txt.gz"
