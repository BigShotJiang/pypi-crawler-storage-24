#!/usr/bin/env python3
"""minilambda: a minimal agent that uses lambda-Tool for safe tool composition.

Demonstrates why lambda-Tool is safer than Python PTC:
  - Row types catch field access errors at compile time (not KeyError at runtime)
  - Mandatory Result matching forces error handling (no unhandled exceptions)
  - Effect tracking prevents Writes inside pure map (must use traverse)
  - Bounded iteration only (no while True, no recursion)
"""

import json
import os
import random
import re

import anthropic
from lambda_tool import LambdaTool, LambdaToolError

# -- Tools ------------------------------------------------------------------
# Simulate an order processing pipeline: fetch orders, charge cards, send receipts.
# In Python PTC, this task commonly fails via wrong field names, unhandled payment
# failures, or accidental double-charges in loops. lambda-Tool prevents all of these.

ORDERS_DB = [
    {"id": 1, "customer": "Alice", "email": "alice@example.com", "amount": 4999, "status": "pending"},
    {"id": 2, "customer": "Bob", "email": "bob@example.com", "amount": 1250, "status": "pending"},
    {"id": 3, "customer": "Carol", "email": "carol@example.com", "amount": 8700, "status": "pending"},
    {"id": 4, "customer": "Dave", "email": "dave@example.com", "amount": 320, "status": "shipped"},
]

def get_orders(arg) -> dict:
    """Fetch orders, optionally filtered by status."""
    status = arg.get("status", "") if isinstance(arg, dict) else ""
    if status:
        orders = [o for o in ORDERS_DB if o["status"] == status]
    else:
        orders = ORDERS_DB
    print(f"  [get_orders] fetched {len(orders)} orders")
    return {"orders": orders}

def charge_card(arg: dict) -> dict:
    """Charge a customer's card. Fails ~30% of the time (card declined)."""
    order_id, amount = arg["order_id"], arg["amount"]
    if random.random() < 0.1:
        raise RuntimeError(f"Card declined for order #{order_id}")
    tx_id = f"tx_{order_id}_{random.randint(1000,9999)}"
    print(f"  [charge_card] order #{order_id}: charged ${amount/100:.2f} -> {tx_id}")
    return {"transaction_id": tx_id, "charged": True}

def send_receipt(arg: dict) -> dict:
    """Send an email receipt to a customer."""
    print(f"  [send_receipt] emailed {arg['email']}: order #{arg['order_id']}")
    return {"delivered": True}

EXECUTORS = {
    "get_orders": get_orders,
    "charge_card": charge_card,
    "send_receipt": send_receipt,
}

MAX_HISTORY = 40

# System prompt — load the lambda-tool skill file for a comprehensive reference,
# then prepend the tool declarations specific to this agent.

SKILL_PATH = os.path.join(os.path.dirname(__file__), "skill.md")

TOOL_PREAMBLE = """You are an assistant that composes tools using lambda-Tool, a type-safe language for Programmatic Tool Calling.

Available tools (include these declarations at the top of every program):
```
tool get_orders: {status: String} -{Read}-> {orders: List {id: Int, customer: String, email: String, amount: Int, status: String}};
tool charge_card: {order_id: Int, amount: Int} -{Write}-> {transaction_id: String, charged: Bool};
tool send_receipt: {order_id: Int, email: String} -{Write}-> {delivered: Bool};
```

Key syntax rules:
- Comments use // or (* *). NEVER use -- for comments.
- Tool declarations must appear at the top of the program.
- Every exec tool call returns a Result that MUST be matched with Ok/Err.
- In match branches, Ok MUST come before Err: match expr { Ok(x) => ..., Err(e) => ... }
- The program's top-level expression must NOT be a Result type. Since traverse returns a Result, you must match it: match traverse (...) list { Ok(xs) => xs, Err(e) => []: T }
- Use traverse (not map) when the callback calls tools.
- Use filter for pure predicates.

When the user's request needs tools, respond with a lambda-Tool program in a ```lambda-tool block.
If the request is conversational, respond normally without code.

"""

def _load_system_prompt() -> str:
    """Build the system prompt from the skill file + tool declarations."""
    try:
        with open(SKILL_PATH) as f:
            skill = f.read()
    except FileNotFoundError:
        # Fallback: if skill file is missing, use the preamble alone
        skill = ""
    return TOOL_PREAMBLE + skill

SYSTEM = _load_system_prompt()

# -- Agent loop -------------------------------------------------------------

def extract_code(text: str) -> str | None:
    m = re.search(r'```lambda-tool\s*\n(.*?)```', text, re.DOTALL)
    return m.group(1).strip() if m else None

def main():
    try:
        client = anthropic.Anthropic()
        lt = LambdaTool()
    except (FileNotFoundError, anthropic.AuthenticationError) as e:
        print(f"Setup error: {e}")
        return

    messages = []
    print("minilambda — type 'quit' to exit")
    print("Try: \"Charge all pending orders and send receipts\"\n")

    while True:
        try:
            user_input = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if user_input.lower() in ("quit", "exit", "q"):
            break
        if not user_input:
            continue

        messages.append({"role": "user", "content": user_input})
        if len(messages) > MAX_HISTORY:
            messages = messages[-MAX_HISTORY:]
            # Ensure messages start with a user turn (API requirement)
            while messages and messages[0]["role"] != "user":
                messages.pop(0)

        try:
            response = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=1024,
                system=SYSTEM,
                messages=messages,
            )
        except anthropic.APIError as e:
            print(f"\nAPI error: {e}\n")
            messages.pop()
            continue

        if not response.content or not hasattr(response.content[0], "text"):
            print("\n(empty response)\n")
            messages.pop()
            continue
        text = response.content[0].text
        messages.append({"role": "assistant", "content": text})

        code = extract_code(text)
        if not code:
            print(f"\n{text}\n")
            continue

        print(f"\n--- lambda-Tool program ---\n{code}\n---------------------------\n")

        try:
            result = lt.run(code, executors=EXECUTORS)
            value_str = json.dumps(result.value, default=str, indent=2)
            print(f"Result: {value_str}")
            print(f"Type: {result.type}  Effects: {result.effects}\n")

            messages.append({"role": "user", "content": f"[Tool result: {value_str}]"})
            try:
                summary = client.messages.create(
                    model="claude-sonnet-4-6",
                    max_tokens=256,
                    system=SYSTEM,
                    messages=messages,
                )
                summary_text = summary.content[0].text if summary.content else "(no summary)"
                messages.append({"role": "assistant", "content": summary_text})
                print(f"{summary_text}\n")
            except anthropic.APIError as e:
                print(f"(summary failed: {e})\n")

        except LambdaToolError as e:
            print(f"Type/runtime error: {e}\n")
            messages.append({
                "role": "user",
                "content": f"[Error: {e}. Please fix the program.]",
            })

if __name__ == "__main__":
    main()
