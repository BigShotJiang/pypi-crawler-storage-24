# minilambda

[![License: LGPL-3.0-or-later](https://img.shields.io/badge/License-LGPL--3.0--or--later-blue.svg)](LICENSE)
[![Python >= 3.10](https://img.shields.io/badge/Python-%3E%3D%203.10-3776ab.svg)](https://python.org)
[![Requires: lambda-tool](https://img.shields.io/badge/requires-lambda--tool%20%3E%3D%200.1.0-orange.svg)](https://github.com/matchcase/lambda-tool)

A minimal agent that uses [λ-Tool](https://github.com/matchcase/lambda-tool) for safe tool composition. Claude generates λ-Tool code; the type checker verifies it's safe; the interpreter executes it with real tools.

A compact agent in under 200 lines.

## Why Not Python PTC?

Anthropic's Programmatic Tool Calling lets Claude write Python to compose tools. But Python has runtime failure modes that λ-Tool catches at **compile time**:

| Failure mode                                       | Python PTC                 | λ-Tool                                                  |
|----------------------------------------------------|----------------------------|---------------------------------------------------------|
| Wrong field name (`order.total` vs `order.amount`) | `KeyError` at runtime      | Type error before execution                             |
| Unhandled tool failure (card declined)             | Unhandled exception, crash | Won't compile — must `match Ok/Err`                     |
| Write tool in a loop (`charge_card` inside `for`)  | Runs, may double-charge    | `map` rejects effectful callbacks — must use `traverse` |
| Infinite loop (`while True: retry(...)`)           | Timeout after 60s          | No `while` or recursion exists in the language          |

minilambda demonstrates all four with an order processing pipeline.

## Prerequisites

- Python 3.10+
- [uv](https://docs.astral.sh/uv/)
- The `lambda_tool` CLI binary ([build from source](https://github.com/matchcase/lambda-tool))
- An [Anthropic API key](https://console.anthropic.com/)

## Setup

```bash
# 1. Build the λ-Tool CLI (requires OCaml 5.x and opam)
cd lambda-tool
opam install . --deps-only && eval $(opam env)
dune build && dune install
cd ..

# 2. Install Python dependencies
cd minilambda
uv venv && uv pip install anthropic lambda-tool

# 3. Set your API key
export ANTHROPIC_API_KEY=sk-ant-...

# 4. Run
uv run python agent.py
```

## How It Works

```
You: "Charge all pending orders and send receipts"
         |
         v
  +--------------+
  |    Claude     |  generates λ-Tool code
  +--------------+
         |
         v
  +--------------+
  | Type Checker  |  rejects if: wrong fields, unhandled errors, writes in map
  +--------------+
         |
         v
  +--------------+
  | Interpreter   |  executes with real Python tool callbacks
  +--------------+
         |
         v
  +--------------+
  |    Claude     |  summarizes the result
  +--------------+
```

## Available Tools

| Tool           | Effect | Input                | Output                                                 |
|----------------|--------|----------------------|--------------------------------------------------------|
| `get_orders`   | Read   | `{status: String}`   | `{orders: List {id, customer, email, amount, status}}` |
| `charge_card`  | Write  | `{order_id, amount}` | `{transaction_id, charged}`                            |
| `send_receipt` | Write  | `{order_id, email}`  | `{delivered}`                                          |

`charge_card` fails ~30% of the time (simulating card declines), forcing the LLM to handle errors properly.

## What the Type Checker Catches

If Claude generates code with any of these bugs, λ-Tool rejects it **before execution**:

- **Wrong field access**
`order.total` when the field is `amount`:
```
Type error: Missing field 'total' in {id: Int, customer: String, email: String, amount: Int, status: String}
```

- **Ignoring a tool result**
`exec tool charge_card {...}` without matching:
```
Type error: Unhandled Result type — must pattern match
```

- **Write tool in pure map**
`map (fn o => exec tool charge_card {...}) orders`:
```
Type error: Effect violation — allowed {} but got {Write}
```

## Example Session

```
> Charge all pending orders and send receipts

--- λ-Tool program ---
tool get_orders: Unit -{Read}-> {orders: List {id: Int, customer: String, email: String, amount: Int, status: String}};
tool charge_card: {order_id: Int, amount: Int} -{Write}-> {transaction_id: String, charged: Bool};
tool send_receipt: {order_id: Int, email: String} -{Write}-> {delivered: Bool};

match exec tool get_orders () {
  Ok(data) =>
    let pending = filter (fn o: {id: Int, customer: String, email: String, amount: Int, status: String} =>
      o.status == "pending") data.orders in
    traverse (fn o: {id: Int, customer: String, email: String, amount: Int, status: String} =>
      match exec tool charge_card {order_id = o.id, amount = o.amount} {
        Ok(payment) =>
          match exec tool send_receipt {order_id = o.id, email = o.email} {
            Ok(receipt) => Ok({id = o.id, charged = true, notified = receipt.delivered}),
            Err(e) => Ok({id = o.id, charged = true, notified = false})
          },
        Err(e) => Ok({id = o.id, charged = false, notified = false})
      }
    ) pending,
  Err(e) => Err(e)
}
---------------------------

  [get_orders] fetched 4 orders
  [charge_card] order #1: charged $49.99 -> tx_1_3847
  [send_receipt] emailed alice@example.com: order #1
  [charge_card] order #2: charged $12.50 -> tx_2_9012
  [send_receipt] emailed bob@example.com: order #2
  Card declined for order #3

Result: ["Ok", [{"id": 1, "charged": true, "notified": true}, ...]]
```

## Related Projects

- [lambda-tool](https://github.com/matchcase/lambda-tool): The core type checker and interpreter (OCaml)
- [lambda-tool-python](https://github.com/matchcase/lambda-tool-python): Python bindings wrapping the CLI

## License

LGPL-3.0-or-later. Check [LICENSE](LICENSE) for details.
© Sarthak Shah (matchcase), 2026.
