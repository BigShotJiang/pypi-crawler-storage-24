import{l as o,a as r}from"../chunks/alrj19tF.js";export{o as load_css,r as start};
