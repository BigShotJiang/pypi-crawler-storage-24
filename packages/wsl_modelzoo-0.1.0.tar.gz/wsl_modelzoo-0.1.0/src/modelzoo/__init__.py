__version__ = "0.1.0"

import logging

# Prevent "No handlers could be found" warnings when used as a library.
logging.getLogger(__name__).addHandler(logging.NullHandler())
