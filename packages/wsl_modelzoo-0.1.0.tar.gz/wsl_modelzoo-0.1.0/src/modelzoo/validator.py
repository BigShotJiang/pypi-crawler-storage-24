import argparse
import modelzoo.constants as c
from typing import Optional, Union, List


def args_validator(parser: argparse.ArgumentParser) -> argparse.Namespace:
    """
    Validate command-line arguments based on the specified model zoo.
    This function parses command-line arguments and delegates validation to
    zoo-specific validator functions based on the 'zoo' argument value.

    Args:
        parser (argparse.ArgumentParser): An ArgumentParser instance containing
            the command-line argument definitions to be parsed and validated.
    Returns:
        argparse.Namespace: The validated and processed command-line arguments.
    Raises:
        May raise exceptions from zoo-specific validator functions or argparse
        parsing errors.
    Note:
        The function expects the parser to have a 'zoo' argument defined.
        Supported zoo values include 'core', 'eurosat', 'vit', and 'pt'.
    """

    args = parser.parse_args()

    zoo: str = args.zoo.rstrip().lower()

    if zoo == "core":
        args = __core_zoo_args_validator(args, zoo)
    elif zoo == "eurosat":
        args = __eurosat_zoo_args_validator(args)
    elif zoo == "vit":
        args = __vit_zoo_args_validator(args, zoo)
    else:  # zoo == "pt"
        ...
    return args


def zoo_arg_validator(zoo: str) -> bool:
    """
    Validates if the provided zoo argument is a valid zoo identifier.

    Args:
        zoo (str): The zoo identifier to validate.

    Returns:
        bool: True if the zoo argument is valid (exists in c.ZOO), False otherwise.
    """
    if zoo not in c.ZOO:
        return False
    return True


def __core_zoo_args_validator(args: argparse.Namespace, zoo: str) -> None:
    """
    Core Zoo validator
    """
    architecture: str = args.arch.rstrip().lower()
    dataset: str = args.dataset.rstrip().lower().replace("-", "")
    config: str = args.config.rstrip().lower() if args.config is not None else None
    init: str = args.init.rstrip().lower() if args.init is not None else None
    dropout: float = float(args.dropout) if args.dropout is not None else None
    activation: str = (
        args.activation.rstrip().lower() if args.activation is not None else None
    )
    lr: Optional[float] = float(args.lr) if args.lr is not None else None
    optimizer: Optional[str] = (
        args.optimizer.rstrip().lower() if args.optimizer is not None else None
    )
    wd: Optional[float] = float(args.wd) if args.wd is not None else None
    seeds: Union[str, List[str], None] = args.seed
    checkpoints: Union[str, List[str], None] = args.ckpts

    computed_seeds: List[int] = []
    computed_ckpts: List[int] = []

    if architecture not in c.ARCHITECTURES.get("core", None):
        raise argparse.ArgumentError(
            None,
            "'{}' is not a valid backbone for the zoo '{}'. Please select one of the following: {}".format(
                architecture, "core", c.ARCHITECTURES.get("core", None)
            ),
        )
    setattr(args, "arch", architecture)

    if dataset not in c.CORE_ARCHITECTURE_DATASET.get(architecture, None):
        raise argparse.ArgumentError(
            None,
            "'{}' is not a valid dataset for the zoo '{}' and architecture '{}'. Please select one of the following: {}".format(
                dataset,
                "core",
                architecture,
                c.CORE_ARCHITECTURE_DATASET.get(architecture, None),
            ),
        )
    setattr(args, "dataset", dataset)

    if config is not None and config not in c.CORE_CONFIG.get(
        f"{architecture}_{dataset}", None
    ):
        raise argparse.ArgumentError(
            None,
            "'{}' is not a valid configuration for the zoo '{}', architecture '{}' and dataset '{}'. Please select one of the following: {}".format(
                config,
                "core",
                architecture,
                dataset,
                c.CORE_CONFIG.get(f"{architecture}_{dataset}", None),
            ),
        )
    setattr(args, "config", config)

    if "sparsified" in dataset:
        if seeds is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on seeds if --dataset is set to 'sparsified'; switch to a non-sparsified dataset to do so",
            )
        if init is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on initialization methods if --dataset is set to 'sparsified'; switch to a non-sparsified dataset to do so",
            )
        if activation is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on activation function if --dataset is set to 'sparsified'; switch to a non-sparsified dataset to do so",
            )
        if optimizer is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on optimizer if --dataset is set to 'sparsified'; switch to a non-sparsified dataset to do so",
            )
        if dropout is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on dropout values if --dataset is set to 'sparsified'; switch to a non-sparsified dataset to do so",
            )
        if lr is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on learning rates if --dataset is set to 'sparsified'; switch to a non-sparsified dataset to do so",
            )
        if wd is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on weight decay values if --dataset is set to 'sparsified'; switch to a non-sparsified dataset to do so",
            )

    if config == "uniform":  # This is also valid for Resnets
        if init is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on initialization methods if --config is set to 'uniform'; switch to --config 'fixed' or --config 'random' to do so",
            )
        if activation is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on activation function if --config is set to 'uniform'; switch to --config 'fixed' or --config 'random' to do so",
            )
        if optimizer is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on optimizer if --config is set to 'uniform'; switch to --config 'fixed' or --config 'random' to do so",
            )
        if dropout is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on dropout values if --config is set to 'uniform'; switch to --config 'fixed' or --config 'random' to do so",
            )
        if lr is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on learning rates if --config is set to 'uniform'; switch to --config 'fixed' or --config 'random' to do so",
            )
        if wd is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on weight decay values if --config is set to 'uniform'; switch to --config 'fixed' or --config 'random' to do so",
            )
    else:
        if "sparsified" not in dataset:
            if init not in c.CORE_INIT.get(f"{architecture}_{dataset}_{config}", None):
                raise argparse.ArgumentError(
                    None,
                    "{} is not a valid initialization method. Please select one of the following: {}".format(
                        init,
                        c.CORE_INIT.get(f"{architecture}_{dataset}_{config}", None),
                    ),
                )
            setattr(args, "init", init)

            if dropout not in c.CORE_DROPOUT.get(
                f"{architecture}_{dataset}_{config}", None
            ):
                raise argparse.ArgumentError(
                    None,
                    "{} is not a valid dropout value. Please select one of the following: {}".format(
                        dropout,
                        c.CORE_DROPOUT.get(f"{architecture}_{dataset}_{config}", None),
                    ),
                )
            setattr(args, "dropout", dropout)

            if activation not in c.CORE_ACTIVATION.get(
                f"{architecture}_{dataset}_{config}", None
            ):
                raise argparse.ArgumentError(
                    None,
                    "{} is not a valid activation function. Please select one of the following: {}".format(
                        activation,
                        c.CORE_ACTIVATION.get(
                            f"{architecture}_{dataset}_{config}", None
                        ),
                    ),
                )
            setattr(args, "activation", activation)

            if lr not in c.CORE_LR.get(f"{architecture}_{dataset}_{config}", None):
                raise argparse.ArgumentError(
                    None,
                    "{} is not a valid learning rate. Please select one of the following: {}".format(
                        lr, c.CORE_LR.get(f"{architecture}_{dataset}_{config}", None)
                    ),
                )
            setattr(args, "lr", lr)

            if optimizer not in c.CORE_OPTIMIZER.get(
                f"{architecture}_{dataset}_{config}", None
            ):
                raise argparse.ArgumentError(
                    None,
                    "{} is not a valid optimizer. Please select one of the following: {}".format(
                        optimizer,
                        c.CORE_OPTIMIZER.get(
                            f"{architecture}_{dataset}_{config}", None
                        ),
                    ),
                )
            setattr(args, "optimizer", optimizer)

            if wd not in c.CORE_WD.get(f"{architecture}_{dataset}_{config}", None):
                raise argparse.ArgumentError(
                    None,
                    "{} is not a valid weight decay value. Please select one of the following: {}".format(
                        wd, c.CORE_WD.get(f"{architecture}_{dataset}_{config}", None)
                    ),
                )
            setattr(args, "wd", wd)

    if config == "uniform" and "sparsified" not in dataset:
        if seeds is None or "all" in seeds:
            first_seed, last_seed, step = c.CORE_SEEDS_RANGE
            for seed in range(first_seed, last_seed + 1, step):
                computed_seeds.append(seed)
        else:
            for value in seeds:
                if "-" in value:
                    val = value.split("-")
                    if val:
                        start, end = int(val[0]), int(val[-1])
                        for v in range(start, end + 1):
                            __seed_validator(
                                v, c.CORE_SEEDS_RANGE[0], c.CORE_SEEDS_RANGE[1]
                            )
                            computed_seeds.append(v)
                else:
                    __seed_validator(
                        int(value), c.CORE_SEEDS_RANGE[0], c.CORE_SEEDS_RANGE[1]
                    )
                    computed_seeds.append(int(value))

        computed_seeds = sorted(computed_seeds)
        setattr(args, "seed", computed_seeds)
    else:
        setattr(args, "seed", None)

    if checkpoints is None or "all" in checkpoints:
        first_ckpt, last_ckpt, step = c.CORE_ARCHITECTURE_DATASET_CKPTS.get(
            f"{architecture}_{dataset}", None
        )
        for ckpt in range(first_ckpt, last_ckpt + 1, step):
            computed_ckpts.append(ckpt)
    else:
        for value in checkpoints:
            if "-" in value:
                val = value.split("-")
                if val:
                    start, end = int(val[0]), int(val[-1])
                    for v in range(start, end + 1):
                        __checkpoint_validator(
                            ckpt=v,
                            min_ckpt=c.CORE_ARCHITECTURE_DATASET_CKPTS.get(
                                f"{architecture}_{dataset}", None
                            )[0],
                            max_ckpt=c.CORE_ARCHITECTURE_DATASET_CKPTS.get(
                                f"{architecture}_{dataset}", None
                            )[1],
                        )
                        computed_ckpts.append(v)
            else:
                __checkpoint_validator(
                    ckpt=int(value),
                    min_ckpt=c.CORE_ARCHITECTURE_DATASET_CKPTS.get(
                        f"{architecture}_{dataset}", None
                    )[0],
                    max_ckpt=c.CORE_ARCHITECTURE_DATASET_CKPTS.get(
                        f"{architecture}_{dataset}", None
                    )[1],
                )
                computed_ckpts.append(int(value))

    computed_ckpts = sorted(computed_ckpts)
    setattr(args, "ckpts", computed_ckpts)
    return args


def __eurosat_zoo_args_validator(args: argparse.Namespace) -> argparse.Namespace:
    """
    EuroSAT Zoo validator
    """
    architecture: str = args.arch.rstrip().lower()
    dataset: str = args.dataset.rstrip().lower()
    config: str = args.config.rstrip().lower() if args.config is not None else None
    seeds: Union[str, List[str], None] = args.seed
    checkpoints: Union[str, List[str], None] = args.ckpts

    computed_seeds: List[int] = []
    computed_ckpts: List[int] = []

    if architecture not in c.ARCHITECTURES.get("eurosat", None):
        raise argparse.ArgumentError(
            None,
            "'{}' is not a valid backbone for the zoo '{}'. Please select one of the following: {}".format(
                architecture, "eurosat", c.ARCHITECTURES.get("eurosat", None)
            ),
        )
    setattr(args, "arch", architecture)

    if dataset not in c.DATASETS.get("eurosat", None):
        raise argparse.ArgumentError(
            None,
            "'{}' is not a valid dataset for the zoo '{}'. Please select one of the following: {}".format(
                dataset, "eurosat", c.DATASETS.get("eurosat", None)
            ),
        )
    setattr(args, "dataset", dataset)

    # Validate config
    if args.dataset == "eurosat_sparsified":
        if config not in c.EUROSAT_SPARSIFIED_CONFIGS:
            raise argparse.ArgumentError(
                None,
                "'{}' is not a valid configuration for the zoo '{}', dataset '{}'. Please select one of the following: {}".format(
                    config,
                    "eurosat",
                    args.dataset,
                    c.EUROSAT_SPARSIFIED_CONFIGS,
                ),
            )
        setattr(args, "config", config)
        if seeds is not None and not ("all" in seeds or seeds == "all"):
            raise argparse.ArgumentError(
                None,
                "Filter on seeds if --dataset is set to 'eurosat_sparsified' is not allowed; switch to 'eurosat' to do so or skip the --seed argument to retrieve all available seeds",
            )
    else:
        if config is not None:
            raise argparse.ArgumentError(
                None,
                "Unable to filter on configuration if --dataset is set to 'eurosat'; switch to 'eurosat_sparsified' to do so",
            )
        if seeds is None or "all" in seeds or seeds == "all":
            first_seed, last_seed, step = c.EUROSAT_SEED_RANGE
            for seed in range(first_seed, last_seed + 1, step):
                computed_seeds.append(seed)
        else:
            for value in seeds:
                if "-" in value:
                    val = value.split("-")
                    if val:
                        start, end = int(val[0]), int(val[-1])
                        for v in range(start, end + 1):
                            __seed_validator(
                                seed=int(v),
                                min_seed=c.EUROSAT_SEED_RANGE[0],
                                max_seed=c.EUROSAT_SEED_RANGE[1],
                            )
                            computed_seeds.append(int(v))
                else:
                    __seed_validator(
                        seed=int(value),
                        min_seed=c.EUROSAT_SEED_RANGE[0],
                        max_seed=c.EUROSAT_SEED_RANGE[1],
                    )
                    computed_seeds.append(int(value))

        computed_seeds = sorted(computed_seeds)
        setattr(args, "seed", computed_seeds)

    if args.dataset == "eurosat":
        first_ckpt, last_ckpt, step = c.EUROSAT_CKPTS_RANGE
    else:
        first_ckpt, last_ckpt, step = c.EUROSAT_SPARSIFIED_CKPTS_RANGE[args.config]

    if checkpoints is None or "all" in checkpoints or checkpoints == "all":
        for ckpt in range(first_ckpt, last_ckpt + 1, step):
            computed_ckpts.append(ckpt)
    else:
        for value in checkpoints:
            if "-" in value:
                val = value.split("-")
                if val:
                    start, end = int(val[0]), int(val[-1])
                    for v in range(start, end + 1):
                        __checkpoint_validator(v, first_ckpt, last_ckpt)
                        computed_ckpts.append(v)
            else:
                __checkpoint_validator(int(value), first_ckpt, last_ckpt)
                computed_ckpts.append(int(value))
    computed_ckpts = sorted(computed_ckpts)
    setattr(args, "ckpts", computed_ckpts)
    return args


def __vit_zoo_args_validator(args: argparse.Namespace, zoo: str) -> argparse.Namespace:
    """
    ViT Zoo validator
    """
    # Pretraining info
    dataset_pretraining: str = args.dataset_pt.rstrip().lower()
    training_regime: str = args.config.rstrip().lower()
    ddp: bool = True if args.ddp.lower() == "true" else False
    seed_pretraining: Union[str, List[str], None] = (
        args.seed_pt if args.seed_pt is not None else None
    )
    ckpts_pretraining: Union[str, List[str], None] = (
        args.ckpts_pt if args.ckpts_pt is not None else None
    )

    computed_seeds_pt: List[int] = []
    computed_ckpts_pt: List[int] = []

    # Finetuning info
    dataset_finetuning: str = (
        args.dataset_ft.rstrip().lower().replace("-", "") if args.dataset_ft else None
    )

    seed_finetuning: Union[str, List[str], None] = (
        args.seed_ft if args.seed_ft is not None else None
    )
    learning_rate_finetuning: Union[List[str], None] = (
        args.lr_ft if args.lr_ft is not None else None
    )

    optimizer_finetuning: Union[List[str], None] = (
        args.optim_ft if args.optim_ft is not None else None
    )

    hd_finetuning: Union[int, None] = (
        args.hd_ft.rstrip().lower() if args.hd_ft is not None else None
    )

    fcmlp_finetuning: Union[str, None] = (
        args.fcmlp_ft.lower().rstrip() if args.fcmlp_ft is not None else None
    )
    ckpts_finetuning: Union[str, List[str], None] = (
        args.ckpts_ft if args.ckpts_ft is not None else None
    )

    computed_seeds_ft: List[int] = []
    computed_lr_ft: List[float] = []
    computed_optimizer_ft: List[str] = []
    computed_hd_ft: List[int] = []
    computed_fcmlp_ft: List[bool] = []
    computed_ckpts_ft: List[int] = []

    if dataset_pretraining not in c.VIT_DATASET_PT:
        raise argparse.ArgumentError(
            None,
            "'{}' is not a valid pretraining dataset for the zoo '{}'. Please select one of the following: {}".format(
                dataset_pretraining, "vit", c.VIT_DATASET_PT
            ),
        )
    setattr(args, "dataset_pt", dataset_pretraining)

    if training_regime not in c.VIT_CONFIG:
        raise argparse.ArgumentError(
            None,
            "'{}' is not a valid pretraining regime for the zoo '{}' and dataset '{}'. Please select one of the following: {}".format(
                training_regime, "vit", dataset_pretraining, c.VIT_CONFIG
            ),
        )
    setattr(args, "config", training_regime)

    if training_regime == "cl" and ddp is True:
        raise argparse.ArgumentError(
            None,
            "Can't select 'ddp' and '{}' as training regime. To select '{}' as training regime disable 'ddp' or switch to 'sl' and keep 'ddp' True".format(
                training_regime, training_regime
            ),
        )

    if seed_pretraining is None or "all" in seed_pretraining:
        if ddp:
            computed_seeds_pt.extend(
                c.VIT_PRETRAINING_SEED.get(f"{training_regime}_ddp")
            )
        else:
            computed_seeds_pt.extend(c.VIT_PRETRAINING_SEED.get(f"{training_regime}"))
    else:
        int_seed_pretraining: List[int] = [int(s.rstrip()) for s in seed_pretraining]
        if not ddp:
            if training_regime == "cl":
                not_common_seeds = list(
                    set(int_seed_pretraining) - (set(c.VIT_PRETRAINING_SEED.get("cl")))
                )
                if not_common_seeds:
                    raise argparse.ArgumentError(
                        None,
                        "Unable to select the following seed(s): {}. Select one or more of the following '{}' given the training regime '{}'.".format(
                            not_common_seeds,
                            c.VIT_PRETRAINING_SEED.get("cl"),
                            training_regime,
                        ),
                    )
                computed_seeds_pt.extend(int_seed_pretraining)
            if training_regime == "sl":
                not_common_seeds = list(
                    set(int_seed_pretraining) - (set(c.VIT_PRETRAINING_SEED.get("sl")))
                )
                if not_common_seeds:
                    raise argparse.ArgumentError(
                        None,
                        "Unable to select the following seed(s): {}. Select one or more of the following '{}' given the training regime '{}'.".format(
                            not_common_seeds,
                            c.VIT_PRETRAINING_SEED.get("sl"),
                            training_regime,
                        ),
                    )
                computed_seeds_pt.extend(int_seed_pretraining)
        else:
            not_common_seeds = list(
                set(int_seed_pretraining) - (set(c.VIT_PRETRAINING_SEED.get("sl_ddp")))
            )
            if not_common_seeds:
                raise argparse.ArgumentError(
                    None,
                    "Unable to select the following seed(s): {}. Select one or more of the following '{}' given the training regime '{}' and ddp True.".format(
                        not_common_seeds,
                        c.VIT_PRETRAINING_SEED.get("sl_ddp"),
                        training_regime,
                    ),
                )
            computed_seeds_pt.extend(int_seed_pretraining)

    setattr(args, "seed_pt", computed_seeds_pt)

    if ckpts_pretraining is None or "all" in ckpts_pretraining:
        first_ckpt, last_ckpt, step = c.VIT_PRETRAINING_CHECKPOINTS
        for ckpt in range(first_ckpt, last_ckpt + 1, step):
            computed_ckpts_pt.append(ckpt)
    else:
        for value in ckpts_pretraining:
            if "-" in value:
                val = value.split("-")
                if val:
                    start, end = int(val[0]), int(val[-1])
                    for v in range(start, end + 1):
                        __checkpoint_validator(
                            v,
                            c.VIT_PRETRAINING_CHECKPOINTS[0],
                            c.VIT_PRETRAINING_CHECKPOINTS[1],
                        )
                        computed_ckpts_pt.append(v)
            else:
                __checkpoint_validator(
                    int(value),
                    c.VIT_PRETRAINING_CHECKPOINTS[0],
                    c.VIT_PRETRAINING_CHECKPOINTS[1],
                )
                computed_ckpts_pt.append(int(value.rstrip().lower()))

    computed_ckpts_pt = sorted(computed_ckpts_pt)
    setattr(args, "ckpts_pt", computed_ckpts_pt)

    if dataset_finetuning is not None:
        if dataset_finetuning not in c.VIT_DATASET_FT:
            raise argparse.ArgumentError(
                None,
                "'{}' is not a valid finetuning dataset for the zoo '{}'. Please select one of the following: {}".format(
                    dataset_finetuning, "vit", c.VIT_DATASET_FT
                ),
            )
        setattr(args, "dataset_ft", dataset_finetuning)

        if seed_finetuning is None or "all" in seed_finetuning:
            computed_seeds_ft.extend(c.VIT_FINETUNING_SEED)
        else:
            for value in seed_finetuning:
                if "-" in value:
                    raise argparse.ArgumentError(
                        None,
                        "Range seeds are not allowed for finetuned models. Please select one or more of the following seed(s): {}".format(
                            c.VIT_FINETUNING_SEED
                        ),
                    )
            int_seed_finetuning: List[int] = [int(s.rstrip()) for s in seed_finetuning]
            for int_seed in int_seed_finetuning:
                if int_seed not in c.VIT_FINETUNING_SEED:
                    raise argparse.ArgumentError(
                        None,
                        "Unable to select the following seed(s): {}. Select one or more of the following seed(s) for finetuning: {}".format(
                            int_seed, c.VIT_FINETUNING_SEED
                        ),
                    )
                else:
                    computed_seeds_ft.append(int_seed)

        computed_seeds_ft = sorted(computed_seeds_ft)
        setattr(args, "seed_ft", computed_seeds_ft)

        if learning_rate_finetuning is None or "all" in learning_rate_finetuning:
            computed_lr_ft.extend(c.VIT_FINETUNING_LR)
        else:
            for value in learning_rate_finetuning:
                if "-" in value:
                    raise argparse.ArgumentError(
                        None,
                        "Range learning rates are not allowed for finetuned models. Please select one or more of the following learning rate(s): {}".format(
                            c.VIT_FINETUNING_LR
                        ),
                    )

                if value not in c.VIT_FINETUNING_LR:
                    raise argparse.ArgumentError(
                        None,
                        "Unable to select the following learning rate(s): {}. Select one or more of the following learning rate(s) for finetuning: {}".format(
                            value, c.VIT_FINETUNING_LR
                        ),
                    )
                else:
                    computed_lr_ft.append(value)
        setattr(args, "lr_ft", computed_lr_ft)

        if optimizer_finetuning is None or "all" in optimizer_finetuning:
            computed_optimizer_ft.extend(c.VIT_FINETUNING_OPTIMIZER)
        else:
            if optimizer_finetuning not in c.VIT_FINETUNING_OPTIMIZER:
                raise argparse.ArgumentError(
                    None,
                    "Unable to select the following optimizer: {}. Select one of the following optimizer(s) for finetuning: {}".format(
                        optimizer_finetuning, c.VIT_FINETUNING_OPTIMIZER
                    ),
                )
            else:
                computed_optimizer_ft.append(optimizer_finetuning)

        setattr(args, "optim_ft", computed_optimizer_ft)

        if hd_finetuning is None or hd_finetuning == "all":
            computed_hd_ft.extend(c.VIT_FINETUNING_HD)
        else:
            if hd_finetuning not in c.VIT_FINETUNING_HD:
                raise argparse.ArgumentError(
                    None,
                    "Unable to select the following hidden dimension: {}. Select one of the following hidden dimension(s) for finetuning: {}".format(
                        hd_finetuning, c.VIT_FINETUNING_HD
                    ),
                )
            else:
                computed_hd_ft.append(hd_finetuning)
        setattr(args, "hd_ft", computed_hd_ft)

        if fcmlp_finetuning is None or fcmlp_finetuning == "all":
            computed_fcmlp_ft.extend(c.VIT_FINETUNING_FCMLP)
        else:
            if fcmlp_finetuning not in c.VIT_FINETUNING_FCMLP:
                raise argparse.ArgumentError(
                    None,
                    "Unable to select the following fcmlp option: {}. Select one of the following fcmlp option(s) for finetuning: {}".format(
                        fcmlp_finetuning, c.VIT_FINETUNING_FCMLP
                    ),
                )
            else:
                computed_fcmlp_ft.append(fcmlp_finetuning)
        setattr(args, "fcmlp_ft", computed_fcmlp_ft)

        if ckpts_finetuning is None or "all" in ckpts_finetuning:
            first_ckpt, last_ckpt, step = c.VIT_FINETUNING_CHECKPOINTS
            for ckpt in range(first_ckpt, last_ckpt + 1, step):
                computed_ckpts_ft.append(ckpt)
        else:
            for value in ckpts_finetuning:
                if "-" in value:
                    val = value.split("-")
                    if val:
                        start, end = int(val[0]), int(val[-1])
                        for v in range(start, end + 1):
                            __checkpoint_validator(
                                v,
                                c.VIT_FINETUNING_CHECKPOINTS[0],
                                c.VIT_FINETUNING_CHECKPOINTS[1],
                            )
                            computed_ckpts_ft.append(v)
                else:
                    __checkpoint_validator(
                        int(value),
                        c.VIT_FINETUNING_CHECKPOINTS[0],
                        c.VIT_FINETUNING_CHECKPOINTS[1],
                    )
                    computed_ckpts_ft.append(int(value.rstrip().lower()))

        computed_ckpts_ft = sorted(computed_ckpts_ft)
        setattr(args, "ckpts_ft", computed_ckpts_ft)
    else:
        setattr(args, "dataset_ft", None)
        setattr(args, "seed_ft", None)
        setattr(args, "lr_ft", None)
        setattr(args, "optim_ft", None)
        setattr(args, "hd_ft", None)
        setattr(args, "fcmlp_ft", None)
        setattr(args, "ckpts_ft", None)
    return args


def __pt_zoo_args_validator() -> None: ...


def __checkpoint_validator(ckpt: int, min_ckpt: int, max_ckpt: int) -> None:
    """
    Validates that a checkpoint value falls within the acceptable range.

    Args:
        ckpt (int): The checkpoint value to validate.
        min_ckpt (int): The minimum valid checkpoint value.
        max_ckpt (int): The maximum valid checkpoint value.

    Raises:
        ValueError: If ckpt is smaller than min_ckpt.
        ValueError: If ckpt is larger than max_ckpt.

    Returns:
        None: This function returns nothing if validation passes.
    """
    if ckpt < min_ckpt:
        raise ValueError(
            "{} is smaller than the first valid checkpoint ({})".format(ckpt, min_ckpt)
        )
    elif ckpt > max_ckpt:
        raise ValueError(
            "{} is larger than the last valid checkpoint ({})".format(ckpt, max_ckpt)
        )
    else:
        pass


def __seed_validator(seed: int, min_seed: int, max_seed: int) -> None:
    """
    Validates that a seed value falls within the specified range.

    Args:
        seed (int): The seed value to validate.
        min_seed (int): The minimum allowed seed value (inclusive).
        max_seed (int): The maximum allowed seed value (inclusive).

    Raises:
        ValueError: If seed is less than min_seed.
        ValueError: If seed is greater than max_seed.

    Returns:
        None: This function returns nothing if validation passes.
    """
    if seed < min_seed:
        raise ValueError(
            "{} is smaller than the first valid seed ({})".format(seed, min_seed)
        )
    elif seed > max_seed:
        raise ValueError(
            "{} is larger than the last valid seed ({})".format(seed, max_seed)
        )
    else:
        pass
