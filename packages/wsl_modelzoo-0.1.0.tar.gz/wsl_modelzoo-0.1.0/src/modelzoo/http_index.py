from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import requests
from tqdm import tqdm
from typing import Iterable, List, Tuple, Union, Dict
from urllib.parse import urljoin
import subprocess
import logging
import shutil
from .constants import (
    ALLOWED_CORE_MODELZOO_METADATA,
    ALLOWED_CORE_MODELZOO_MODELS_METADATA,
    CORE_MODELZOO_URL,
    EUROSAT_MODELZOO_URL,
    ALLOWED_EUROSAT_MODELZOO_METADATA,
    ALLOWED_EUROSAT_MODELZOO_MODELS_METADATA,
    VIT_MODELZOO_URL,
    URL_PREFIX,
    DOWNLOAD_ROOT,
    ALLOWED_VIT_MODELZOO_MODELS_METADATA_PRETRAINED,
    ALLOWED_VIT_MODELZOO_MODELS_METADATA_FINETUNED,
)

logger = logging.getLogger(__name__)


def _ensure_wget_installed() -> None:
    if shutil.which("wget") is None:
        raise RuntimeError(
            "This command requires the 'wget' executable to be installed and available "
            "on PATH. Install it with your system package manager, e.g. "
            "'brew install wget' or 'sudo apt install wget'."
        )


def list_files(url: Union[str, Path]) -> List[dict]:
    """
    List the files inside a directory in JSON format
    """
    if not url.endswith("/"):
        url += "/"
    r = requests.get(url, timeout=60)
    r.raise_for_status()
    data = r.json()
    if not isinstance(data, list):
        raise ValueError(f"Expected JSON array at {url}, got {type(data)}")
    return data


def fetch_and_download(args: argparse.Namespace) -> None:
    """
    Fetch the file URLs based on the provided arguments and download the checkpoints.
    """

    _ensure_wget_installed()

    if args.dir is not None:
        _ensure_permissions(args.dir)

    if args.zoo == "core":
        _core_fetch_and_download(args)
    elif args.zoo == "eurosat":
        _eurosat_fetch_and_download(args)
    elif args.zoo == "vit":
        _vit_fetch_and_download(args)
    else:  # args.zoo == "pt"
        pass


def _ensure_permissions(download_path: Union[str, Path]) -> None:
    """
    Ensure that the directory exists and has the correct permissions.
    """
    if not isinstance(download_path, Path):
        download_path = Path(download_path)
    if not download_path.exists():
        download_path.mkdir(parents=True, exist_ok=True)
    if not os.access(download_path, os.W_OK):
        raise PermissionError(
            f"Directory {download_path} is not writable. Please check the permissions."
        )


def download_urls_wget(urls: Iterable[str], dir: Union[str, Path, None] = None) -> None:
    """
    Download a list of HTTPS URLs using wget, while:
      - resuming partial downloads (-c)
      - retrying on flaky connections
      - writing each file under *dir* (or DOWNLOAD_ROOT when dir is None),
        preserving the path AFTER URL_PREFIX
    """
    root = Path(dir) if dir is not None else DOWNLOAD_ROOT
    root.mkdir(parents=True, exist_ok=True)

    url_list: List[str] = [u for u in urls if u]
    for url in tqdm(url_list, desc="Downloading files"):
        if not url.startswith(URL_PREFIX):
            raise ValueError(f"Unexpected URL prefix: {url}")

        rel = url[len(URL_PREFIX) :]
        out_path = root / rel
        out_path.parent.mkdir(parents=True, exist_ok=True)

        cmd = [
            "wget",
            "-c",  # resume if connection drops
            "-q",  # quiet output, progress shown by tqdm
            "--tries=20",
            "--timeout=30",
            "--waitretry=2",
            "-O",
            str(out_path),  # explicit output path (your custom root)
            url,
        ]

        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed downloading {url}: {e}")
            continue


def _eurosat_fetch_and_download(args: argparse.Namespace) -> List[Path]:
    """Fetch the file URLs for the EuroSAT model zoo based on the provided arguments and download the checkpoints."""

    zoo_metadata: List[Path] = []
    models: List[Path] = []
    model_metadata: List[Path] = []
    model_ckpts: List[Path] = []

    if args.dataset == "eurosat_sparsified":
        zoo_path = urljoin(
            EUROSAT_MODELZOO_URL,
            f"{args.arch}_{args.dataset}/{args.arch}_eurosat_{args.config}/",
        )
        zoo_content = list_files(url=zoo_path)
        for f in tqdm(zoo_content, desc="Retrieving zoo metadata and model URLs"):
            if f["type"] == "directory":
                models.append(urljoin(zoo_path, f["name"] + "/"))
            else:
                if f["name"] in ALLOWED_EUROSAT_MODELZOO_METADATA:
                    zoo_metadata.append(urljoin(zoo_path, f["name"]))

        for model in tqdm(models, desc="Retrieving models metadata and checkpoints"):
            model_content = list_files(url=model)
            all_ckpt_urls = [
                urljoin(model, f["name"] + "/")
                for f in model_content
                if f["type"] == "directory"
            ]
            if not all_ckpt_urls:
                logger.warning(f"No checkpoint directories found for model {model}")
                continue
            filtered_ckpt_urls = [all_ckpt_urls[ckpt] for ckpt in args.ckpts]

            for c_url in filtered_ckpt_urls:
                ckpt_content = list_files(url=c_url)
                for f in ckpt_content:
                    if f["name"] == "checkpoints":
                        model_ckpts.append(urljoin(c_url, f["name"]))
            # Model metadata (e.g., params.json, progress.csv, result.json, events.out)
            for f in model_content:
                if (
                    f["type"] != "directory"
                    and f["name"] in ALLOWED_EUROSAT_MODELZOO_MODELS_METADATA
                ):
                    model_metadata.append(urljoin(model, f["name"]))
    else:
        zoo_path = urljoin(
            EUROSAT_MODELZOO_URL,
            f"{args.arch}_{args.dataset}/tune_zoo_eurosat_cnn_kaiming_uniform/",
        )
        zoo_content = list_files(url=zoo_path)
        zoo_metadata = [
            urljoin(zoo_path, f["name"])
            for f in tqdm(zoo_content, desc="Retrieving zoo metadata and model URLs")
            if f["type"] != "directory"
            and f["name"] in ALLOWED_EUROSAT_MODELZOO_METADATA
        ]  # Ready to be downloaded

        for seed in args.seed:
            if zoo_content[seed - 1]["type"] == "directory":
                models.append(urljoin(zoo_path, zoo_content[seed - 1]["name"] + "/"))

        for model in tqdm(models, desc="Retrieving models metadata and checkpoints"):
            model_content = list_files(url=model)
            all_ckpt_urls = [
                urljoin(model, f["name"] + "/")
                for f in model_content
                if f["type"] == "directory"
            ]
            if not all_ckpt_urls:
                logger.warning(
                    f"No checkpoint directories found for model {model['name']}"
                )
                continue
            filtered_ckpt_urls = [all_ckpt_urls[ckpt] for ckpt in args.ckpts]
            for c_url in filtered_ckpt_urls:
                ckpt_content = list_files(url=c_url)
                for f in ckpt_content:
                    if f["name"] == "checkpoints":
                        model_ckpts.append(urljoin(c_url, f["name"]))
            # Model metadata (e.g., params.json, progress.csv, result.json, events.out)
            for f in model_content:
                if (
                    f["type"] != "directory"
                    and f["name"] in ALLOWED_EUROSAT_MODELZOO_MODELS_METADATA
                ):
                    model_metadata.append(urljoin(model, f["name"]))

    # To download: model_ckpts + model_metadata + zoo_metadata
    to_download = [*model_ckpts, *model_metadata, *zoo_metadata]
    download_urls_wget(to_download, dir=args.dir)
    return


def _core_fetch_and_download(args: argparse.Namespace) -> None:
    """Fetch the file URLs for the Core model zoo based on the provided arguments and download the checkpoints."""

    zoo_metadata: List[Path] = []
    models: List[Path] = []
    model_metadata: List[Path] = []
    model_ckpts: List[Path] = []

    ###################################################
    #################### CNN-SMALL ####################
    ###################################################

    if args.arch == "cnn-small":
        if "sparsified" not in args.dataset:
            external_zoo_path = urljoin(
                CORE_MODELZOO_URL,
                f"{args.arch}_{args.dataset}/",
            )
            if args.config in ["fixed", "random"]:
                zoo_path = urljoin(
                    external_zoo_path,
                    f"tune_zoo_{args.dataset}_hyperparameter_10_{args.config}_seeds/",
                )
                zoo_content = list_files(url=zoo_path)
                zoo_metadata = [
                    urljoin(zoo_path, f["name"])
                    for f in tqdm(zoo_content, desc="Retrieving zoo metadata")
                    if f["type"] != "directory"
                    and f["name"] in ALLOWED_CORE_MODELZOO_METADATA
                ]  # Ready to be downloaded
                model_metadata, model_ckpts = filter_on_args(
                    zoo_path, model_metadata, model_ckpts, zoo_content, args
                )
                to_download = [*model_ckpts, *model_metadata, *zoo_metadata]
                download_urls_wget(to_download, dir=args.dir)
                return
            else:
                ## CNN-SMALL uniform
                zoo_path = urljoin(
                    external_zoo_path,
                    f"tune_zoo_{args.dataset}_uniform/",
                )
            zoo_content = list_files(url=zoo_path)
            zoo_metadata = [
                urljoin(zoo_path, f["name"])
                for f in tqdm(zoo_content, desc="Retrieving zoo metadata")
                if f["type"] != "directory"
                and f["name"] in ALLOWED_CORE_MODELZOO_METADATA
            ]  # Ready to be downloaded
            for seed in args.seed:
                if zoo_content[seed - 1]["type"] == "directory":
                    models.append(
                        urljoin(zoo_path, zoo_content[seed - 1]["name"] + "/")
                    )
            for model in tqdm(
                models, desc="Retrieving models metadata and checkpoints"
            ):
                model_content = list_files(url=model)
                all_ckpt_urls = [
                    urljoin(model, f["name"] + "/")
                    for f in model_content
                    if f["type"] == "directory" and "ipynb" not in f["name"]
                ]
                if not all_ckpt_urls:
                    logger.warning(
                        f"No checkpoint directories found for model {model['name']}"
                    )
                    continue
                filtered_ckpt_urls = [all_ckpt_urls[ckpt] for ckpt in args.ckpts]
                for c_url in filtered_ckpt_urls:
                    ckpt_content = list_files(url=c_url)
                    for f in ckpt_content:
                        if f["name"] == "checkpoints":
                            model_ckpts.append(urljoin(c_url, f["name"]))
                # Model metadata (e.g., params.json, progress.csv, result.json, events.out)
                for f in model_content:
                    if f["type"] != "directory":
                        model_metadata.append(urljoin(model, f["name"]))

        # To download: model_ckpts + model_metadata + zoo_metadata
        to_download = [*model_ckpts, *model_metadata, *zoo_metadata]
        download_urls_wget(to_download, dir=args.dir)
        return

        ###################################################
        #################### CNN-LARGE ####################
        ###################################################

    elif args.arch == "cnn-large":
        if "sparsified" not in args.dataset:
            external_zoo_path = urljoin(
                CORE_MODELZOO_URL,
                f"{args.arch}_{args.dataset}/",
            )
            if args.config in ["fixed", "random"]:
                zoo_path = urljoin(
                    external_zoo_path,
                    f"tune_zoo_{args.dataset}_large_hyperparameter_10_{args.config}_seeds/",
                )
                zoo_content = list_files(url=zoo_path)
                zoo_metadata = [
                    urljoin(zoo_path, f["name"])
                    for f in tqdm(zoo_content, desc="Retrieving zoo metadata")
                    if f["type"] != "directory"
                    and f["name"] in ALLOWED_CORE_MODELZOO_METADATA
                ]  # Ready to be downloaded
                model_metadata, model_ckpts = filter_on_args(
                    zoo_path, model_metadata, model_ckpts, zoo_content, args
                )
                to_download = [*model_ckpts, *model_metadata, *zoo_metadata]
                download_urls_wget(to_download, dir=args.dir)
                return
            else:
                zoo_path = urljoin(
                    external_zoo_path,
                    f"tune_zoo_{args.dataset}_uniform_large/",
                )
            zoo_content = list_files(url=zoo_path)
            zoo_metadata = [
                urljoin(zoo_path, f["name"])
                for f in tqdm(zoo_content, desc="Retrieving zoo metadata")
                if f["type"] != "directory"
                and f["name"] in ALLOWED_CORE_MODELZOO_METADATA
            ]  # Ready to be downloaded
            for seed in args.seed:
                if zoo_content[seed - 1]["type"] == "directory":
                    models.append(
                        urljoin(zoo_path, zoo_content[seed - 1]["name"] + "/")
                    )
            for model in tqdm(
                models, desc="Retrieving models metadata and checkpoints"
            ):
                model_content = list_files(url=model)
                all_ckpt_urls = [
                    urljoin(model, f["name"] + "/")
                    for f in model_content
                    if f["type"] == "directory" and "ipynb" not in f["name"]
                ]
                if not all_ckpt_urls:
                    logger.warning(
                        f"No checkpoint directories found for model {model['name']}"
                    )
                    continue
                filtered_ckpt_urls = [all_ckpt_urls[ckpt] for ckpt in args.ckpts]
                for c_url in filtered_ckpt_urls:
                    ckpt_content = list_files(url=c_url)
                    for f in ckpt_content:
                        if f["name"] == "checkpoints":
                            model_ckpts.append(urljoin(c_url, f["name"]))
                # Model metadata (e.g., params.json, progress.csv, result.json, events.out)
                for f in model_content:
                    if (
                        f["type"] != "directory"
                        and f["name"] in ALLOWED_EUROSAT_MODELZOO_MODELS_METADATA
                    ):
                        model_metadata.append(urljoin(model, f["name"]))
            to_download = [*model_ckpts, *model_metadata, *zoo_metadata]
            download_urls_wget(to_download, dir=args.dir)
            return
        else:
            # Sparsified
            external_zoo_path = urljoin(
                CORE_MODELZOO_URL,
                f"{args.arch}_{args.dataset}/",
            )
            dataset_name = args.dataset.split("_sparsified")[0]
            ### Sparsified CNN-LARGE
            if args.config in ["fixed", "random"]:
                zoo_path = urljoin(
                    external_zoo_path,
                    f"{args.arch}_{dataset_name}_ard_vd/",
                )
            else:
                zoo_path = urljoin(
                    external_zoo_path,
                    f"{args.arch}_{dataset_name}_ard_vd/",
                )
            zoo_content = list_files(url=zoo_path)
            zoo_metadata = [
                urljoin(zoo_path, f["name"])
                for f in tqdm(zoo_content, desc="Retrieving zoo metadata")
                if f["type"] != "directory"
                and f["name"] in ALLOWED_CORE_MODELZOO_METADATA
            ]  # Ready to be downloaded
            for c in tqdm(
                zoo_content, desc="Retrieving models metadata and checkpoints"
            ):
                if c["type"] == "directory" and c["name"].startswith(
                    "NN_tune_trainable"
                ):
                    model_path = urljoin(zoo_path, c["name"] + "/")
                    model_content = list_files(url=model_path)
                    all_ckpt_urls = [
                        urljoin(model_path, f["name"] + "/")
                        for f in model_content
                        if f["type"] == "directory"
                    ]
                    if not all_ckpt_urls:
                        logger.warning(
                            f"No checkpoint directories found for model {c['name']}"
                        )
                        continue
                    filtered_ckpt_urls = [all_ckpt_urls[ckpt] for ckpt in args.ckpts]
                    for c_url in filtered_ckpt_urls:
                        ckpt_content = list_files(url=c_url)
                        for f in ckpt_content:
                            if f["name"] == "checkpoints":
                                model_ckpts.append(urljoin(c_url, f["name"]))
                    # Model metadata (e.g., params.json, progress.csv, result.json)
                    for f in model_content:
                        if f["type"] != "directory":
                            model_metadata.append(urljoin(model_path, f["name"]))
        # To download: model_ckpts + model_metadata + zoo_metadata
        to_download = [*model_ckpts, *model_metadata, *zoo_metadata]
        download_urls_wget(to_download, dir=args.dir)
        # return
    elif "resnet" in args.arch:
        external_zoo_path = urljoin(
            CORE_MODELZOO_URL,
            f"{args.arch}_{args.dataset}/",
        )
        zoo_path = urljoin(
            external_zoo_path,
            f"tune_zoo_{args.dataset}_{args.arch}_kaiming_uniform/",
        )
        zoo_content = list_files(url=zoo_path)
        zoo_metadata = [
            urljoin(zoo_path, f["name"])
            for f in tqdm(zoo_content, desc="Retrieving zoo metadata")
            if f["type"] != "directory" and f["name"] in ALLOWED_CORE_MODELZOO_METADATA
        ]  # Ready to be downloaded

        seed_set = set(args.seed)
        models = [
            urljoin(zoo_path, f["name"] + "/")
            for f in zoo_content
            if f["type"] == "directory"
            and any(f"seed={s}_" in f["name"] for s in seed_set)
        ]

        for model in tqdm(models, desc="Retrieving models metadata and checkpoints"):
            model_content = list_files(url=model)
            all_ckpt_urls = [
                urljoin(model, f["name"] + "/")
                for f in model_content
                if f["type"] == "directory" and "checkpoint" in f["name"].lower()
            ]
            if not all_ckpt_urls:
                logger.warning(
                    f"No checkpoint directories found for model {model['name']}"
                )
                continue
            filtered_ckpt_urls = [all_ckpt_urls[ckpt] for ckpt in args.ckpts]
            for c_url in filtered_ckpt_urls:
                ckpt_content = list_files(url=c_url)
                for f in ckpt_content:
                    if f["name"] == "checkpoints":
                        model_ckpts.append(urljoin(c_url, f["name"]))
            # Model metadata (e.g., params.json, progress.csv, result.json, events.out)
            for f in model_content:
                if f["type"] != "directory":
                    model_metadata.append(urljoin(model, f["name"]))
        to_download = [*model_ckpts, *model_metadata, *zoo_metadata]
        download_urls_wget(to_download, dir=args.dir)
        return
    else:
        raise ValueError(f"Unsupported architecture: {args.arch}")


def _vit_fetch_and_download(args: argparse.Namespace) -> None:
    ptm_ckpts: List[Path] = []
    ptm_metadata: List[Path] = []

    ftm_ckpts: List[Path] = []
    ftm_metadata: List[Path] = []

    pretrained_zoo_path = urljoin(
        VIT_MODELZOO_URL, f"vit_{args.dataset_pt}_pretrained/"
    )

    all_pretrained_zoos = list_files(url=pretrained_zoo_path)

    if args.config == "sl":
        if args.ddp == "true":
            pretrained_zoos = [
                z
                for z in all_pretrained_zoos
                if "ddp" in z["name"].lower()
                and z["type"] == "directory"
                and z["name"].startswith("sl")
            ]
        else:
            pretrained_zoos = [
                z
                for z in all_pretrained_zoos
                if "ddp" not in z["name"].lower()
                and z["type"] == "directory"
                and z["name"].startswith("sl")
            ]
    elif args.config == "cl":
        pretrained_zoos = [
            z
            for z in all_pretrained_zoos
            if z["name"].startswith("cl") and z["type"] == "directory"
        ]
    else:
        raise ValueError(f"Unsupported training regime: {args.config}")

    seed_set = set(args.seed_pt)
    pretrained_models = [
        urljoin(pretrained_zoo_path, f["name"] + "/")
        for f in pretrained_zoos
        if f["type"] == "directory" and any(f"seed_{s}_" in f["name"] for s in seed_set)
    ]

    if not pretrained_models:
        raise ValueError(
            f"No pretrained models found for dataset {args.dataset_pt} with training regime {args.config} and ddp={args.ddp}"
        )

    msg = (
        "Retrieving pretrained models only"
        if args.dataset_ft is None
        else "Retrieving pretrained and finetuned models"
    )

    for pm in tqdm(pretrained_models, desc=f"{msg}"):
        ptm_ckpt_content = list_files(url=pm)
        all_ptm_ckpts_urls = [
            urljoin(pm, f["name"] + "/")
            for f in ptm_ckpt_content
            if f["type"] == "directory" and "checkpoint" in f["name"].lower()
        ]
        if not all_ptm_ckpts_urls:
            logger.warning(f"No checkpoint directories found for model {pm}")
            continue
        ptm_ckpts += [
            all_ptm_ckpts_urls[ckpt] for ckpt in args.ckpts_pt
        ]  # Ready to be downloaded
        ptm_metadata += [
            urljoin(pm, f["name"])
            for f in ptm_ckpt_content
            if f["type"] != "directory"
            and f["name"] in ALLOWED_VIT_MODELZOO_MODELS_METADATA_PRETRAINED
        ]  # Ready to be downloaded

        if args.dataset_ft is not None:
            # If I am here, it means that I need to fetch the finetuning models as well
            source_model = urljoin(
                VIT_MODELZOO_URL,
                f"vit_{args.dataset_ft}_finetuned/{pm.split('/')[-2]}/",
            )
            corresponding_finetuned_models = list_files(url=source_model)

            ftm_metadata, ftm_ckpts = filter_vit_on_args(
                source_model,
                corresponding_finetuned_models,
                ftm_ckpts,
                ftm_metadata,
                args,
            )
    to_download = [*ptm_ckpts, *ptm_metadata, *ftm_ckpts, *ftm_metadata]
    download_urls_wget(to_download, dir=args.dir)
    return


def filter_vit_on_args(
    source_model: str,
    finetuned_models: List[Dict],
    ftm_ckpts: List[Path],
    ftm_metadata: List[Path],
    args: argparse.Namespace,
) -> Tuple[List[Path], List[Path]]:
    """
    Filter the list of finetuned models in the zoo based on the provided arguments (e.g., seed, lr, optimizer, hd, fcmlp).
    This function is specific for the ViT model zoo, where the finetuned models are organized differently than in the other zoos.
    """
    for model in finetuned_models:
        if model["type"] == "directory" and (
            model["name"].startswith("sl") or model["name"].startswith("cl")
        ):
            # I am inside a finetuned model
            finetuned_model_content = list_files(
                url=urljoin(source_model, model["name"] + "/")
            )
            # I get its config.json to check its hyperparameters and filter based on the provided arguments
            if (
                f["name"] == "config.json" and f["type"] == "file"
                for f in finetuned_model_content
            ):
                config_url = urljoin(source_model, model["name"] + "/config.json")
                r = requests.head(config_url, timeout=10)
                if r.status_code != 200:
                    logger.warning(
                        f"Config URL {config_url} not found (status code {r.status_code}), skipping model {model['name']}"
                    )
                    continue
                else:
                    config = json.loads(requests.get(config_url, timeout=10).text)
                    if (
                        int(config.get("model::head::seed", None)) in args.seed_ft
                        and (str(config.get("optim::lr", None)).lower() in args.lr_ft)
                        and (
                            str(config.get("optim::optimizer", None)).lower()
                            in args.optim_ft
                        )
                        and (
                            str(config.get("model::head::hidden_dim", None)).lower()
                            in args.hd_ft
                        )
                        and (
                            str(config.get("model::head::mlp", None)).lower()
                            in args.fcmlp_ft
                        )
                    ):
                        # If I am here, it means that this model matches the provided arguments and should be downloaded
                        # We further filter on the checkpoints to download only the ones specified in args.ckpts_ft
                        selected_finetuned_model = urljoin(
                            source_model, model["name"] + "/"
                        )
                        finetuned_model_content = list_files(
                            url=selected_finetuned_model,
                        )
                        all_ckpt_urls = [
                            urljoin(selected_finetuned_model, f["name"] + "/")
                            for f in finetuned_model_content
                            if f["type"] == "directory"
                            and "checkpoint" in f["name"].lower()
                        ]
                        if not all_ckpt_urls:
                            logger.warning(
                                f"No checkpoint directories found for model {model['name']}"
                            )
                            continue
                        filtered_ckpt_urls = [
                            all_ckpt_urls[ckpt] for ckpt in args.ckpts_ft
                        ]
                        for c_url in filtered_ckpt_urls:
                            ckpt_content = list_files(url=c_url)
                            for f in ckpt_content:
                                if f["name"] == "checkpoints":
                                    ftm_ckpts.append(urljoin(c_url, f["name"]))
                        # Model metadata (e.g., params.json, progress.csv, result.json, events.out)
                        for f in finetuned_model_content:
                            if (
                                f["type"] != "directory"
                                and f["name"]
                                in ALLOWED_VIT_MODELZOO_MODELS_METADATA_FINETUNED
                            ):
                                ftm_metadata.append(
                                    urljoin(selected_finetuned_model, f["name"])
                                )
                    else:
                        continue
    return ftm_metadata, ftm_ckpts


def filter_on_args(
    zoo_path: str,
    model_metadata: List[Path],
    model_ckpts: List[Path],
    zoo_content: List[Dict],
    args: argparse.Namespace,
) -> Tuple[List[Path], List[Path]]:
    """
    Filter the list of models in the zoo based on the provided arguments (e.g., seed).
    """
    for model in tqdm(zoo_content, desc="Filtering models based on provided arguments"):
        if model["type"] == "directory" and model["name"].startswith(
            f"NN_tune_trainable"
        ):
            # Get the config.json of the model to check its hyperparameters
            config_url = urljoin(zoo_path, model["name"] + "/params.json")

            # How to check if the config_url exists? If it doesn't, skip this model
            r = requests.head(config_url, timeout=10)
            if r.status_code != 200:
                logger.warning(
                    f"Config URL {config_url} not found (status code {r.status_code}), skipping model {model['name']}"
                )
                continue
            else:
                config = json.loads(requests.get(config_url, timeout=10).text)
                if (
                    (
                        args.dropout is None
                        or config.get("model::dropout", None) == args.dropout
                    )
                    and (
                        args.init is None
                        or config.get("model::init_type", None) == args.init
                    )
                    and (
                        args.activation is None
                        or config.get("model::nlin", None) == args.activation
                    )
                    and (args.lr is None or config.get("optim::lr", None) == args.lr)
                    and (
                        args.optimizer is None
                        or config.get("optim::optimizer", None) == args.optimizer
                    )
                    and (args.wd is None or config.get("optim::wd", None) == args.wd)
                ):
                    # If I am here, it means that this model matches the provided arguments and should be downloaded
                    model_path = urljoin(zoo_path, model["name"] + "/")
                    model_content = list_files(
                        url=model_path,
                    )
                    all_ckpt_urls = [
                        urljoin(model_path, f["name"] + "/")
                        for f in model_content
                        if f["type"] == "directory"
                    ]
                    if not all_ckpt_urls:
                        logger.warning(
                            f"No checkpoint directories found for model {model['name']}"
                        )
                        continue
                    filtered_ckpt_urls = [all_ckpt_urls[ckpt] for ckpt in args.ckpts]
                    for c_url in filtered_ckpt_urls:
                        ckpt_content = list_files(url=c_url)
                        for f in ckpt_content:
                            if f["name"] == "checkpoints":
                                model_ckpts.append(urljoin(c_url, f["name"]))
                    # Model metadata (e.g., params.json, progress.csv, result.json)
                    for f in model_content:
                        if (
                            f["type"] != "directory"
                            and f["name"] in ALLOWED_CORE_MODELZOO_MODELS_METADATA
                        ):
                            model_metadata.append(urljoin(model_path, f["name"]))
                else:
                    continue
    return model_metadata, model_ckpts
