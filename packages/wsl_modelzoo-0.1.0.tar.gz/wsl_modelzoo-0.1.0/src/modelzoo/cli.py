import argparse
import logging
from modelzoo.validator import args_validator, zoo_arg_validator
import modelzoo.constants as c
from textwrap import dedent
from modelzoo.http_index import fetch_and_download


def parser_builder(zoo: str) -> argparse.ArgumentParser:
    """Constructs and returns an argparse.ArgumentParser for a specific model zoo.

    This function acts as a factory, creating a different command-line
    interface parser depending on the `zoo` parameter. This is necessary
    because each model zoo may support a unique set of arguments,
    subcommands, and flags.

    Args:
        zoo (str): The name of the model zoo (e.g., 'eurosat', 'vit') for which
            to generate the argument parser.

    Returns:
        argparse.ArgumentParser: A configured parser instance tailored to the
            specified model zoo.
    """

    parser = argparse.ArgumentParser(
        prog="modelzoo",
        description="Model Zoo CLI Downloader",
        add_help=True,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    fetch = sub.add_parser(name="fetch", formatter_class=argparse.RawTextHelpFormatter)

    if zoo == "core":
        fetch.add_argument(
            "--zoo",
            required=True,
            type=str,
            help="The Model Zoo to fetch the checkpoint(s) from (core)",
        )

        fetch.add_argument(
            "--dir",
            type=str,
            help=dedent(
                """\
                The directory to save the fetched checkpoint(s). If not specified, it defaults to the current working directory.
                
                --dir /path/to/save/checkpoints/and/metadata
                
                """
            ),
        )

        fetch.add_argument(
            "--arch",
            required=True,
            type=str,
            help=dedent(
                """\
                The architecture of the model. Accepts 'cnn-small', 'cnn-large' or 'resnet18'.
                
                --arch cnn-small
                --arch cnn-large
                --arch resnet18
                
                """
            ),
        )

        fetch.add_argument(
            "--dataset",
            required=True,
            type=str,
            help=dedent(
                """\
            The dataset used for training. 
            
            Datasets marked with an asterisk (*) also have a sparsified version, e.g. mnist_sparsified, cifar10_sparsified etc.
            
            If the architecture is 'cnn-small', the dataset must be 'mnist *', 'fmnist *', 'svhn *', 'usps *', 'cifar10 *', 'stl10 *'
            If the architecture is 'cnn-large', the dataset must be 'cifar10 *' or 'stl10 *'
            If the architecture is 'resnet18', the dataset must be 'cifar10 'stl10' or 'tinyimagenet'
            
            Examples:
              --dataset mnist
              --dataset mnist_sparsified

            """
            ),
        )

        fetch.add_argument(
            "--config",
            type=str,
            help=dedent(
                """\
                The configuration type (look at the README for more details)
            """
            ),
        )

        fetch.add_argument(
            "--init",
            type=str,
            help=dedent(
                """
                The initialization method (look at the README for more details)
                        
            """
            ),
        )

        fetch.add_argument(
            "--activation",
            type=str,
            help=dedent(
                """\
                The activation function (look at the README for more details).
                        
            """
            ),
        )

        fetch.add_argument(
            "--optimizer",
            type=str,
            help=dedent(
                """\
                The optimizer (look at the README for more details).

            """
            ),
        )

        fetch.add_argument(
            "--dropout",
            type=float,
            help=dedent(
                """\
                The dropout value (look at the README for more details).

            """
            ),
        )

        fetch.add_argument(
            "--lr",
            type=float,
            help=dedent(
                """\
                The learning rate (look at the README for more details).
                        
            """
            ),
        )

        fetch.add_argument(
            "--wd",
            type=float,
            help=dedent(
                """\
                The weight decay (look at the README for more details).

            """
            ),
        )

        fetch.add_argument(
            "--seed",
            nargs="+",
            help=dedent(
                """\
                Seed(s): accepts single integers, inclusive ranges, or 'all'.

                Examples:
                  --seed 30
                  --seed 20 30 50
                  --seed 1-30
                  --seed 1-5 10 12-14 20 25

                If skipped, it retrieves all available seeds by default.
            """
            ),
        )

        fetch.add_argument(
            "--ckpts",
            nargs="+",
            default="all",
            help=dedent(
                """\
                Checkpoint(s): accepts single integers, inclusive ranges, 'all'.

                Examples:
                  --ckpts 30
                  --ckpts 20 30 50
                  --ckpts 1-30
                  --ckpts 1-5 10 12-14 20 25

                If skipped, it retrieves all available checkpoints by default.
                        
            """
            ),
        )

    elif zoo == "eurosat":
        fetch.add_argument(
            "--zoo",
            required=True,
            type=str,
            help="The Model Zoo to fetch checkpoint(s) and metadata from (EuroSAT)",
        )

        fetch.add_argument(
            "--dir",
            type=str,
            help=dedent(
                """\
                The directory to save the fetched checkpoint(s). If not specified, it defaults to the current working directory.
                
                --dir /path/to/save/checkpoints/and/metadata
                
                """
            ),
        )

        fetch.add_argument(
            "--arch",
            required=True,
            type=str,
            help=dedent(
                """\
                The architecture of the model. Accepts only 'cnn-small'.

                  --arch cnn-small
                  
            """
            ),
        )

        fetch.add_argument(
            "--dataset",
            type=str,
            help=dedent(
                """\
                The Dataset. Default to 'eurosat'
                
                Accepts 'eurosat' or 'eurosat_sparsified'.
                
                """
            ),
            default="eurosat",
        )

        fetch.add_argument(
            "--config",
            type=str,
            help=dedent(
                """\
                The configuration type. If the dataset is 'eurosat', no extra configuration is needed. 
                If the dataset is 'eurosat_sparsified', it accepts one of:
                'ard_vd', 'magn_10', 'magn_20', 'magn_30', 'magn_40', 'magn_50', 'magn_60', 'magn_70', 'magn_80', 'magn_90'.

                Examples:
                  --config ard_vd
                  --config magn_10
                  
            """
            ),
        )

        fetch.add_argument(
            "--seed",
            nargs="+",
            help=dedent(
                """\
            Seed(s): accepts single integers, inclusive ranges, or 'all'.

            It cannot be used with the sparsified dataset.
            Seeds go from 1 to 1000 (inclusive)
            
            
            Examples:
                --seed 20 30 50
                --seed 1-30
                --seed 1-5 10 12-14 20 25
                --seed all
            If skipped, it will retrieve all the available seeds by default.
            
        """
            ),
        )

        fetch.add_argument(
            "--ckpts",
            nargs="+",
            help=dedent(
                """\
            Checkpoint(s): accepts single integers, inclusive ranges, or 'all'.
            
            Checkpoints go from 0 to 50 (inclusive) for the non-sparsified dataset, 
            0 to 25 (inclusive) for ard_vd config and 0 to 15 (inclusive) for the other sparsified configs.

            Examples:
              --ckpts 20 30 50
              --ckpts 1-30
              --ckpts 1-5 10 12-14 20 25
            --ckpts all

            If skipped, it will retrieve all the available checkpoints by default.
            
        """
            ),
        )

    elif zoo == "vit":
        fetch.add_argument(
            "--zoo",
            required=True,
            type=str,
            help=dedent(
                """\
                The Model Zoo to fetch the checkpoint(s) from (vit).
                
                It is possible to download only pretrained checkpoints or pretrained and finetuned checkpoints together. 
                If you want to download only pretrained checkpoints, skip the finetuning-related arguments
                It is not possible to download only finetuned checkpoints without downloading the corresponding pretrained ones.
                
                """
            ),
        )

        fetch.add_argument(
            "--dir",
            type=str,
            help=dedent(
                """\
                The directory to save the fetched checkpoint(s). If not specified, it defaults to the current working directory.
                
                --dir /path/to/save/checkpoints/and/metadata
                
                """
            ),
        )

        # -------------------- Pretraining -------------------- #
        fetch.add_argument(
            "--dataset_pt",
            required=True,
            type=str,
            help=dedent(
                """\
                The pretraining dataset. Only 'imagenet' is supported.
                
                """
            ),
        )

        fetch.add_argument(
            "--config",
            required=True,
            type=str,
            help=dedent(
                """\
                The pretraining regime.
                Accepts: 'sl' (supervised learning) or 'cl' (contrastive learning)
                
            """
            ),
        )

        fetch.add_argument(
            "--ddp",
            type=str,
            default="false",
            help=dedent(
                """\
                Distributed Data Parallel training option.
                
                Accepts either True or False only when --config is set to 'sl'.
                
                Examples:
                --ddp True
                --ddp False
                
                Skip this argument if you passed --config 'cl'
                
                """
            ),
        )

        fetch.add_argument(
            "--seed_pt",
            nargs="+",
            help=dedent(
                """\
                Pretrained model(s) seed(s): accepts single integers, inclusive ranges, or 'all'.

                If 'all' is passed, other seeds will be ignored.

                Examples:
                --seed_pt 20 30 50
                --seed_pt 1-30
                --seed_pt 1-5 10 12-14 20 25
                --seed_pt all

                If skipped, all available pretraining seeds will be retrieved by default.
                        
            """
            ),
        )

        fetch.add_argument(
            "--ckpts_pt",
            nargs="+",
            help=dedent(
                """\
                Pretrained model(s) checkpoint(s): accepts single integers or 'all'.

                If 'all' is passed, other checkpoints will be ignored.
                
                Checkpoints go from 0 to 89 (inclusive).

                Examples:
                --ckpts_pt 20 30 50
                --ckpts_pt 1-30
                --ckpts_pt 1-5 10 12-14 20 25
                --ckpts_pt all
                
            """
            ),
        )

        # -------------------- Finetuning -------------------- #
        fetch.add_argument(
            "--dataset_ft",
            required=False,
            type=str,
            help=dedent(
                """\
                The finetuning dataset. Only 'cifar100' is supported.
                
                """
            ),
        )

        fetch.add_argument(
            "--seed_ft",
            nargs="+",
            help=dedent(
                """\
                Finetuned model(s) seed(s): accepts only 42 , 6312 or 'all'.

                Examples:
                --seed_ft 42
                --seed_ft 6312
                --seed_ft all

                If skipped, all available finetuning seeds will be retrieved by default.
                
            """
            ),
        )

        fetch.add_argument(
            "--lr_ft",
            type=str,
            nargs="+",
            help=dedent(
                """\
                The learning rate(s) used for finetuning.

                Accepts a single value or multiple values among the following: 0.001, 0.0003, 0.0001, 'all'.

                Examples:
                --lr_ft 0.001
                --lr_ft 0.001 0.0003 0.0001
                
                If skipped or if 'all' is passed, it will retrieve all available finetuning learning rates by default.
                
            """
            ),
        )

        fetch.add_argument(
            "--optim_ft",
            type=str,
            help=dedent(
                """\
                The optimizer(s) used for finetuning.

                Accepts 'adamw', 'sgd' or 'all'.

                Examples:
                --optim_ft adamw
                --optim_ft sgd 
                
                If skipped or if 'all' is passed, it will retrieve all available finetuning optimizers by default.
            """
            ),
        )

        fetch.add_argument(
            "--hd_ft",
            type=str,
            help=dedent(
                """\
                The hidden dimension used for finetuning.

                Accepts a single value, '256', 'null', or 'all'.

                Examples:
                --hd_ft 256
                --hd_ft null
                --hd_ft all
                
            """
            ),
        )

        fetch.add_argument(
            "--fcmlp_ft",
            type=str,
            help=dedent(
                """\
                The fully connected MLP layer used for finetuning.

                Accepts either True or False or 'all'.

                Examples:
                --fcmlp_ft True
                --fcmlp_ft False
                --fcmlp_ft all
                
            """
            ),
        )

        fetch.add_argument(
            "--ckpts_ft",
            nargs="+",
            help=dedent(
                """\
                Finetuned model(s) checkpoint(s): accepts single integers, inclusive ranges, or 'all'.

                Checkpoints go from 0 to 49 (inclusive).
                
                Examples:
                --ckpts_ft 20 30 49
                --ckpts_ft 0-49 (equivalent to --ckpts_ft all)
                --ckpts_ft 1-5 10 12-14 20 25
                --ckpts_ft all

                If skipped, it will retrieve all available finetuning checkpoints by default.
                        
            """
            ),
        )

    else:  # TODO: to be implemented (Phase Transitions Zoo)
        pass

    return parser


class _CleanFormatter(logging.Formatter):
    """Show plain messages for INFO; prefix level for WARNING and above."""

    _FORMATS = {
        logging.DEBUG: "[debug] %(message)s",
        logging.INFO: "%(message)s",
        logging.WARNING: "WARNING: %(message)s",
        logging.ERROR: "ERROR: %(message)s",
        logging.CRITICAL: "CRITICAL: %(message)s",
    }

    def format(self, record: logging.LogRecord) -> str:
        self._style._fmt = self._FORMATS.get(
            record.levelno, "%(levelname)s: %(message)s"
        )
        return super().format(record)


def _configure_logging() -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(_CleanFormatter())
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(handler)


def main() -> None:
    _configure_logging()

    pre_parser = argparse.ArgumentParser(add_help=False, prog="modelzoo")
    pre_subparser = pre_parser.add_subparsers(dest="cmd")

    pre_fetch = pre_subparser.add_parser("fetch", add_help=False)
    pre_fetch.add_argument(
        "--zoo",
        required=True,
        type=str,
        help="The Model Zoo to fetch the checkpoint(s) from",
    )

    pre_args, _ = pre_parser.parse_known_args()
    zoo = getattr(pre_args, "zoo", None)

    if not zoo_arg_validator(zoo):
        raise argparse.ArgumentError(
            None,
            "'{}' is not a valid zoo. Please select one of the following: {}".format(
                zoo, c.ZOO
            ),
        )

    parser = parser_builder(zoo=zoo)
    args = args_validator(parser)
    fetch_and_download(args)


if __name__ == "__main__":
    main()
