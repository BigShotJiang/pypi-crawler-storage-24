from typing import List, Dict, Tuple
from pathlib import Path

# Zoos
ZOO: List[str] = ["core", "eurosat", "vit", "pt"]


# Zoo-Architectures combination
ARCHITECTURES: Dict[str, List[str]] = {
    ZOO[0]: [
        "cnn-small",
        "cnn-large",
        "resnet18",
        # "resnet34",
        # "resnet-34",
        # "resnet50",
        # "resnet-50",
        # "resnet101",
        # "resnet-101",
        # "resnet152",
        # "resnet-152",
        # "densenet121",
        # "densenet-121",
        # "densenet161",
        # "densenet-161",
        # "efficientnetv2small",
        # "efficientnet-v2-small",
        # "efficientnet-v2-medium",
        # "efficientnetv2medium",
    ],
    ZOO[1]: ["cnn-small"],
    ZOO[2]: ["vit"],
    ZOO[3]: ["resnet-18", "resnet-50", "vit"],
}

# Zoo-Dataset combination
DATASETS: Dict[str, List[str]] = {
    ZOO[0]: [
        "cifar10",
        "cifar10_sparsified",
        "stl10",
        "stl10_sparsified",
        "fmnist",
        "fmnist_sparsified",
        "mnist",
        "mnist_sparsified",
        "svhn",
        "svhn_sparsified",
        "usps",
        "usps_sparsified",
        "cifar100",
        "tinyimagenet",
    ],
    ZOO[1]: ["eurosat", "eurosat_sparsified"],
    ZOO[2]: ["imagenet", "cifar100"],
    ZOO[3]: ["cifar10", "cifar100", "svhn", "tinyimagenet"],
}


################################
####### Core Model Zoo #########
################################

CORE_ARCHITECTURE_DATASET: Dict[str, List[str]] = {
    "cnn-small": [
        "mnist",
        "mnist_sparsified",
        "fmnist",
        "fmnist_sparsified",
        "svhn",
        "svhn_sparsified",
        "usps",
        "usps_sparsified",
        "cifar10",
        "cifar10_sparsified",
        "stl10",
        "stl10_sparsified",
    ],
    "cnn-large": ["cifar10", "cifar10_sparsified", "stl10", "stl10_sparsified"],
    "resnet18": ["cifar10", "cifar100", "tinyimagenet"],
    # "resnet34": ["cifar10", "cifar100", "tinyimagenet"],
    # "resnet50": ["tinyimagenet"],
    # "resnet101": ["tinyimagenet"],
    # "resnet152": ["tinyimagenet"],
    # "densenet121": ["tinyimagenet"],
    # "densenet161": ["tinyimagenet"],
    # "efficientnet-v2-small": ["tinyimagenet"],
    # "efficientnet-v2-medium": ["tinyimagenet"],
}

CORE_CONFIG: Dict[str, List[str]] = {
    "cnn-small_mnist": ["uniform", "fixed", "random"],
    "cnn-small_mnist_sparsified": ["uniform", "fixed", "random"],
    "cnn-small_fmnist": ["uniform", "fixed", "random"],
    "cnn-small_fmnist_sparsified": ["uniform", "fixed", "random"],
    "cnn-small_svhn": ["uniform", "fixed", "random"],
    "cnn-small_svhn_sparsified": ["uniform", "fixed", "random"],
    "cnn-small_usps": ["uniform", "fixed", "random"],
    "cnn-small_usps_sparsified": ["uniform"],
    "cnn-small_cifar10": ["uniform", "fixed", "random"],
    "cnn-small_cifar10_sparsified": ["uniform"],
    "cnn-small_stl10": ["uniform", "fixed", "random"],
    "cnn-small_stl10_sparsified": ["uniform"],
    "cnn-large_cifar10": ["uniform", "fixed", "random"],
    "cnn-large_stl10": ["uniform", "fixed", "random"],
    "cnn-large_cifar10_sparsified": ["uniform", "fixed", "random"],
    "cnn-large_stl10_sparsified": ["uniform", "fixed", "random"],
    "resnet18_cifar10": ["uniform"],
    "resnet18_cifar100": ["uniform"],
    "resnet18_tinyimagenet": ["uniform"],
}

CORE_INIT: Dict[str, List[str]] = {
    "cnn-small_mnist_fixed": ["uniform", "normal", "kaiming_uniform", "kaiming_normal"],
    "cnn-small_mnist_random": [
        "uniform",
        "normal",
        "kaiming_uniform",
        "kaiming_normal",
    ],
    "cnn-small_fmnist_fixed": [
        "uniform",
        "normal",
        "kaiming_uniform",
        "kaiming_normal",
    ],
    "cnn-small_fmnist_random": [
        "uniform",
        "normal",
        "kaiming_uniform",
        "kaiming_normal",
    ],
    "cnn-small_svhn_fixed": ["uniform", "normal", "kaiming_uniform", "kaiming_normal"],
    "cnn-small_svhn_random": ["uniform", "normal", "kaiming_uniform", "kaiming_normal"],
    "cnn-small_usps_fixed": ["uniform", "normal", "kaiming_uniform", "kaiming_normal"],
    "cnn-small_usps_random": ["uniform", "normal", "kaiming_uniform", "kaiming_normal"],
    "cnn-small_cifar10_fixed": [
        "uniform",
        "normal",
        "kaiming_uniform",
        "kaiming_normal",
    ],
    "cnn-small_cifar10_random": [
        "uniform",
        "normal",
        "kaiming_uniform",
        "kaiming_normal",
    ],
    "cnn-small_stl10_fixed": ["uniform", "normal", "kaiming_uniform", "kaiming_normal"],
    "cnn-small_stl10_random": [
        "uniform",
        "normal",
        "kaiming_uniform",
        "kaiming_normal",
    ],
    "cnn-large_cifar10_fixed": [
        "uniform",
        "normal",
        "kaiming_uniform",
        "kaiming_normal",
    ],
    "cnn-large_cifar10_random": [
        "uniform",
        "normal",
        "kaiming_uniform",
        "kaiming_normal",
    ],
    "cnn-large_stl10_fixed": ["uniform", "normal", "kaiming_uniform", "kaiming_normal"],
    "cnn-large_stl10_random": [
        "uniform",
        "normal",
        "kaiming_uniform",
        "kaiming_normal",
    ],
}

CORE_DROPOUT: Dict[str, List[float]] = {
    "cnn-small_mnist_fixed": [0, 0.5],
    "cnn-small_mnist_random": [0, 0.5],
    "cnn-small_fmnist_fixed": [0, 0.5],
    "cnn-small_fmnist_random": [0, 0.5],
    "cnn-small_svhn_fixed": [0, 0.3, 0.5],
    "cnn-small_svhn_random": [0, 0.3, 0.5],
    "cnn-small_usps_fixed": [0, 0.5],
    "cnn-small_usps_random": [0, 0.5],
    "cnn-small_cifar10_fixed": [0, 0.5],
    "cnn-small_cifar10_random": [0, 0.5],
    "cnn-small_stl10_fixed": [0, 0.5],
    "cnn-small_stl10_random": [0, 0.5],
    "cnn-large_cifar10_fixed": [0, 0.5],
    "cnn-large_cifar10_random": [0, 0.5],
    "cnn-large_stl10_fixed": [0, 0.5],
    "cnn-large_stl10_random": [0, 0.5],
}
CORE_ACTIVATION: Dict[str, List[str]] = {
    "cnn-small_mnist_fixed": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_mnist_random": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_fmnist_fixed": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_fmnist_random": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_svhn_fixed": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_svhn_random": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_usps_fixed": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_usps_random": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_cifar10_fixed": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_cifar10_random": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_stl10_fixed": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-small_stl10_random": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-large_cifar10_fixed": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-large_cifar10_random": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-large_stl10_fixed": ["tanh", "relu", "gelu", "sigmoid"],
    "cnn-large_stl10_random": ["tanh", "relu", "gelu", "sigmoid"],
}
CORE_OPTIMIZER: Dict[str, List[str]] = {
    "cnn-small_mnist_fixed": ["adam", "sgd"],
    "cnn-small_mnist_random": ["adam", "sgd"],
    "cnn-small_fmnist_fixed": ["adam", "sgd"],
    "cnn-small_fmnist_random": ["adam", "sgd"],
    "cnn-small_svhn_fixed": ["sgd"],
    "cnn-small_svhn_random": ["sgd"],
    "cnn-small_usps_fixed": ["adam", "sgd"],
    "cnn-small_usps_random": ["adam", "sgd"],
    "cnn-small_cifar10_fixed": ["adam", "sgd"],
    "cnn-small_cifar10_random": ["adam", "sgd"],
    "cnn-small_stl10_fixed": ["adam", "sgd"],
    "cnn-small_stl10_random": ["adam", "sgd"],
    "cnn-large_cifar10_fixed": ["adam", "sgd"],
    "cnn-large_cifar10_random": ["adam", "sgd"],
    "cnn-large_stl10_fixed": ["adam", "sgd"],
    "cnn-large_stl10_random": ["adam", "sgd"],
}
CORE_WD: Dict[str, List[str]] = {
    "cnn-small_mnist_fixed": [0.01, 0.001],
    "cnn-small_mnist_random": [0.01, 0.001],
    "cnn-small_fmnist_fixed": [0.01, 0.001],
    "cnn-small_fmnist_random": [0.01, 0.001],
    "cnn-small_svhn_fixed": [0, 0.001, 0.1],
    "cnn-small_svhn_random": [0, 0.001, 0.1],
    "cnn-small_usps_fixed": [0.01, 0.001],
    "cnn-small_usps_random": [0.01, 0.001],
    "cnn-small_cifar10_fixed": [0.01, 0.001],
    "cnn-small_cifar10_random": [0.01, 0.001],
    "cnn-small_stl10_fixed": [0.01, 0.001],
    "cnn-small_stl10_random": [0.01, 0.001],
    "cnn-large_cifar10_fixed": [0.01, 0.001],
    "cnn-large_cifar10_random": [0.01, 0.001],
    "cnn-large_stl10_fixed": [0.01, 0.001],
    "cnn-large_stl10_random": [0.01, 0.001],
}

CORE_LR: Dict[str, List[float]] = {
    "cnn-small_mnist_fixed": [0.001, 0.0001],
    "cnn-small_mnist_random": [0.001, 0.0001],
    "cnn-small_fmnist_fixed": [0.001, 0.0001],
    "cnn-small_fmnist_random": [0.001, 0.0001],
    "cnn-small_svhn_fixed": [0.1, 0.001, 0.0001],
    "cnn-small_svhn_random": [0.1, 0.001, 0.0001],
    "cnn-small_usps_fixed": [0.001, 0.0001],
    "cnn-small_usps_random": [0.001, 0.0001],
    "cnn-small_cifar10_fixed": [0.001, 0.0001],
    "cnn-small_cifar10_random": [0.001],
    "cnn-small_stl10_fixed": [0.001, 0.0001],
    "cnn-small_stl10_random": [0.001, 0.0001],
    "cnn-large_cifar10_fixed": [0.001],
    "cnn-large_cifar10_random": [0.001],
    "cnn-large_stl10_fixed": [0.001, 0.0001],
    "cnn-large_stl10_random": [0.001, 0.0001],
}


CORE_SEEDS_RANGE: Tuple[int, int, int] = (1, 1000, 1)

CORE_ARCHITECTURE_DATASET_CKPTS: Dict[str, List[str]] = {
    "cnn-small_mnist": (0, 50, 1),
    "cnn-small_mnist_sparsified": (0, 25, 1),
    "cnn-small_fmnist": (0, 50, 1),
    "cnn-small_fmnist_sparsified": (0, 25, 1),
    "cnn-small_svhn": (0, 50, 1),
    "cnn-small_svhn_sparsified": (0, 25, 1),
    "cnn-small_usps": (0, 50, 1),
    "cnn-small_usps_sparsified": (0, 25, 1),
    "cnn-small_cifar10": (0, 50, 1),
    "cnn-small_cifar10_sparsified": (0, 25, 1),
    "cnn-small_stl10": (0, 50, 1),
    "cnn-small_stl10_sparsified": (0, 25, 1),
    "cnn-large_cifar10": (0, 50, 1),
    "cnn-large_cifar10_sparsified": (0, 25, 1),
    "cnn-large_stl10": (0, 50, 1),
    "cnn-large_stl10_sparsified": (0, 25, 1),
    "resnet18_cifar10": (0, 50, 1),
    "resnet18_cifar100": (0, 60, 1),
    "resnet18_tinyimagenet": (0, 60, 1),
}

################################
####### EuroSAT Model Zoo ######
################################

EUROSAT_ARCHITECTURE_DATASET: Dict[str, List[str]] = {
    "cnn-small": ["eurosat", "eurosat_sparsified"],
}

EUROSAT_SPARSIFIED_CONFIGS: List[str] = [
    "ard_vd",
    "magn_10",
    "magn_20",
    "magn_30",
    "magn_40",
    "magn_50",
    "magn_60",
    "magn_70",
    "magn_80",
    "magn_90",
]

EUROSAT_SEED_RANGE: Tuple[int, int, int] = (1, 1000, 1)

EUROSAT_CKPTS_RANGE: Tuple[int, int, int] = (0, 50, 1)
EUROSAT_SPARSIFIED_CKPTS_RANGE: Dict[str, Tuple[int, int, int]] = {
    "ard_vd": (0, 25, 1),
    "magn_10": (0, 15, 1),
    "magn_20": (0, 15, 1),
    "magn_30": (0, 15, 1),
    "magn_40": (0, 15, 1),
    "magn_50": (0, 15, 1),
    "magn_60": (0, 15, 1),
    "magn_70": (0, 15, 1),
    "magn_80": (0, 15, 1),
    "magn_90": (0, 15, 1),
}

################################
####### ViT Model Zoo ##########
################################

# Pretraining
VIT_DATASET_PT: List[str] = ["imagenet"]

VIT_CONFIG: List[str] = ["sl", "cl"]

VIT_PRETRAINING_SEED: Dict[str, List[int]] = {
    "cl": [42, 2517, 6312],
    "sl": [42, 6312],
    "sl_ddp": [1957, 2517, 3753, 6312, 7853],
}


VIT_PRETRAINING_CHECKPOINTS: Tuple[int, int, int] = (0, 89, 1)


# Finetuning
VIT_DATASET_FT: List[str] = ["cifar100"]

VIT_FINETUNING_SEED: List[int] = [42, 6312]
VIT_FINETUNING_LR: List[float] = ["0.003", "0.0001", "0.001"]
VIT_FINETUNING_OPTIMIZER: List[str] = ["sgd", "adamw"]
VIT_FINETUNING_HD: List[str] = ["256", "none"]
VIT_FINETUNING_FCMLP: List[str] = ["true", "false"]
VIT_FINETUNING_CHECKPOINTS: Tuple[int, int, int] = (0, 49, 1)

URL_PREFIX = "https://ai.unisg.ch/files/weight_space_learning/model_zoos/"
DOWNLOAD_ROOT = Path("downloads")
EUROSAT_MODELZOO_URL: str = (
    "https://ai.unisg.ch/files/weight_space_learning/model_zoos/eurosat-modelzoo/"
)
CORE_MODELZOO_URL: str = (
    "https://ai.unisg.ch/files/weight_space_learning/model_zoos/core-modelzoo/"
)
VIT_MODELZOO_URL: str = (
    "https://ai.unisg.ch/files/weight_space_learning/model_zoos/vit-modelzoo/"
)

ALLOWED_CORE_MODELZOO_METADATA: List[str] = [
    "config.json",
    # "dataset.pt",
    "index_dict.json",
]
ALLOWED_CORE_MODELZOO_MODELS_METADATA: List[str] = [
    "params.json",
    "progress.csv",
    "result.json",
]

ALLOWED_EUROSAT_MODELZOO_METADATA: List[str] = [
    "config.json",
    # "dataset.pt",
]
ALLOWED_EUROSAT_MODELZOO_MODELS_METADATA: List[str] = [
    "params.json",
    "progress.csv",
    "result.json",
]

ALLOWED_VIT_MODELZOO_MODELS_METADATA_PRETRAINED: List[str] = [
    "config.json",
    "result.json",
]

ALLOWED_VIT_MODELZOO_MODELS_METADATA_FINETUNED: List[str] = [
    "config.json",
    "result.json",
]
