# Pygwan

Unofficial Python wrapper for the WhatsApp Cloud API by <b>[Tarmica Chiwara](https://github.com/lordskyzw)</b>.

## Installation

To install the WhatsApp Python wrapper, use the following command:

```bash
pip install pygwan
```

## Usage

Import the `WhatsApp` class from the package and initialize an instance with your WhatsApp token and phone number ID:

```python
from pygwan import WhatsApp

whatsapp = WhatsApp(token="your_token", phone_number_id="your_phone_number_id")
```

### Sending a Message

You can send a text message to a WhatsApp user using the `send_message` method:

```python
whatsapp.send_message("Hello, this is a test message.", "recipient_phone_number")
```

### Replying to a Message

Reply to a message using the `reply_to_message` method:

```python
whatsapp.reply_to_message("message_id", "recipient_phone_number", "Reply message.")
```

### Sending a Template

Send a template message using the `send_template` method:

```python
components = [
    # List of template components
    # Example: {"type": "text", "text": "Hello, this is a template message."}
]
whatsapp.send_template("template_name", "recipient_phone_number", components)
```

### Sending a Location

Send a location message using the `send_location` method:

```python
whatsapp.send_location("-23.564", "-46.654", "Location Name", "Location Address", "recipient_phone_number")
```

### Sending an Image

Send an image message using the `send_image` method:

```python
image_link = "https://example.com/image.jpg"
whatsapp.send_image(image_link, "recipient_phone_number")
```


## LATEST NOTES:
Here's what changed and why:
The rabbit 🐇 — human_reply
```python
wa.human_reply(message_id, "263779281345", "Sure, let me check that for you!")
```
- One call does: read receipt → typing bubble → 1.5s pause → reply. Your bot instantly feels like a person. For even more realism, use a length-aware delay:
```python
delay=len(response_text) * 0.03  # ~30ms per character
```
Template improvements
```python
wa.send_simple_template("hello_world", "263779281345")           # static templates

wa.send_flow_template("agentd", "263779281345")                  # flow templates, zero config

wa.send_flow_template("onboarding", "263779281345",              # flow + variables
    body_variables=["Alice"], flow_token="sess-123")
```

- TemplateComponents builder for anything more complex — chainable, readable, no raw dicts:
```python
components = (
    TemplateComponents()
    .add_header("Invoice #1023")
    .add_body("Alice", "shipped")
    .add_flow_button()
    .add_quick_reply_button("CONFIRM")
    .build()
)
wa.send_template("order_update", "263779281345", components)
```

- Also quietly fixed: 

send_templatev2 was calling send_template without self, get_message now also handles list_reply, and create_button is kept as an alias so nothing breaks.


For more detailed usage and information, please refer to the official documentation in the code lol

## License

This project is licensed under the [MIT License](https://opensource.org/licenses/MIT).
