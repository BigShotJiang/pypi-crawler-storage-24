#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：BBScriptToolBundle 
@File    ：LockFileUpdater.py
@Author  ：Aron
@Date    ：2026/3/13 10:57 
"""
import re


class LockFileUpdater:

    def __init__(self, lock_file_path):
        self.lock_file_path = lock_file_path

    def update_commit(self, component_name, new_commit):
        with open(self.lock_file_path, "r") as file:
            lines = file.readlines()

        updated_lines = []
        pattern = rf"^\s+{re.escape(component_name)}:\n(\s+:git: .+\n)?\s+:commit: .+\n"
        regex = re.compile(pattern, re.MULTILINE)

        found = False
        i = 0
        while i < len(lines):
            if lines[i].strip() == f"{component_name}:":
                found = True
                updated_lines.append(lines[i])
                i += 1
                # 可选的 :git: 行
                if lines[i].strip().startswith(":git:"):
                    updated_lines.append(lines[i])
                    i += 1
                # Skip if :branch: line exists
                if lines[i].strip().startswith(":branch:"):
                    updated_lines.append(lines[i])
                    i += 1
                    print(f"[!] Skipping update for {component_name} as it uses a branch.")
                    continue
                # 替换 :commit: 行
                updated_lines.append(f"    :commit: {new_commit}\n")
                i += 1
            else:
                updated_lines.append(lines[i])
                i += 1

        if not found:
            print(f"[!] Component '{component_name}' not found in Podfile.lock")
            return False

        with open(self.lock_file_path, "w") as file:
            file.writelines(updated_lines)

        print(f"[✓] Updated {component_name} commit to {new_commit} in Podfile.lock")
        return True

