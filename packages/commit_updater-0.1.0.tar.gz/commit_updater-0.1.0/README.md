# CommitUpdater

用于在主工程中批量更新 `Podfile.lock` 里的组件 commit，并自动提交推送主工程仓库。

## 功能概述

- 拉取主工程最新代码（`git pull`）
- 根据组件名定位本地组件仓库路径
- 获取组件仓库最新 commit（`git fetch` + `git rev-parse HEAD`）
- 更新主工程 `Podfile.lock` 对应组件的 `:commit:`
- 自动执行 `git add Podfile.lock`、`git commit`、`git push`

## 目录说明

- `main.py`：入口脚本（命令行参数解析）
- `MainProjUpdater.py`：主流程编排（pull、更新、提交推送）
- `ComponentGitFinder.py`：组件本地仓库路径查找
- `CommitFetcher.py`：获取组件仓库最新 commit
- `LockFileUpdater.py`：更新 `Podfile.lock` 里的 commit

## 组件路径查找规则

`ComponentGitFinder` 会优先按以下方式定位组件目录：

1. 如果初始化时传入 `repo_root`，直接拼接 `repo_root/component_name`
2. 否则自动读取主工程下的开发者配置目录：
   - `cocoapods/Member_modules/*.rb`
   - 从各配置文件的 `:pathes => [...]` 解析本地仓库根目录
   - 依次检查 `<repo_root>/<component_name>` 是否存在
   - 找到即返回对应路径

已适配以下 `:pathes` 写法：
- 多行数组
- 行内或独立行注释（`# ...`）
- 单引号/双引号路径

## 安装与使用

### 方式一：pip 安装（推荐，独立包）

`pyproject.toml` 位于 `CommitUpdater` 目录，可将该目录作为独立包根目录安装，并得到全局命令 `commit-updater`：

```bash
# 在 CommitUpdater 目录
cd CommitUpdater
pip install -e .

# 之后可在任意目录执行（需先 cd 到含 Podfile.lock 的主工程目录）
commit-updater BBUnlock BBEngine
```

发布到 PyPI 后，他人可直接：

```bash
pip install commit-updater
commit-updater BBUnlock BBEngine
```

### 方式二：不安装，在仓库根目录运行

在仓库根目录（`BBScriptToolBundle`）执行：

```bash
python3 -m CommitUpdater.main BBUnlock BBEngine
```

或直接运行脚本：

```bash
python3 CommitUpdater/main.py BBUnlock BBEngine
```

## PyCharm 运行注意事项

若使用 PyCharm 直接运行脚本，且 `Working directory` 设置不正确，可能出现：

- `No module named 'CommitUpdater.MainProjUpdater'`
- `'CommitUpdater' is not a package`

推荐方案：

- 在 PyCharm 里使用 **Module name** 运行：`CommitUpdater.main`
- Working directory 设为项目根目录：`BBScriptToolBundle`

## 提交信息规则

- 单组件更新：`[update] <component>`
- 多组件更新：`[update] Multiple components: <comp1>, <comp2>, ...`

## 发布（维护者）

打包与上传 PyPI（需先安装 `build`、`twine`）：

```bash
# 在 CommitUpdater 目录
cd CommitUpdater
python3 -m build
twine upload dist/*
```

若使用私有 PyPI，将 `twine upload` 目标改为对应 index。单独发布 CommitUpdater 时，直接复制整个 `CommitUpdater` 目录到新仓库根目录即可，在该目录执行上述命令即可。

## 注意事项

- `MainProjUpdater` 会自动执行提交和推送，请确保主工程分支、权限和远程状态正确
- `LockFileUpdater` 遇到 `:branch:` 配置会跳过该组件更新
- 运行前请确保主工程目录下存在 `Podfile.lock`
- 当前 `main.py` 中有 `isTest` 测试入口，正式使用命令行时请保持 `isTest = False`
