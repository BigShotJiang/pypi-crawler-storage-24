#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：BBScriptToolBundle 
@File    ：ComponentGitFinder.py
@Author  ：Aron
@Date    ：2026/3/13 11:10 
"""

import os
import re
from typing import List, Optional, Tuple


class ComponentGitFinder:

    PATHES_START_PATTERN = re.compile(r":pathes\s*=>\s*\[")
    QUOTED_PATH_PATTERN = re.compile(r"""['"]([^'"]+)['"]""")

    def __init__(self, repo_root: Optional[str] = None, current_proj_dir: Optional[str] = None):
        self.repo_root = repo_root
        self.current_proj_dir = current_proj_dir or os.getcwd()

    def _get_member_modules_dir(self) -> str:
        return os.path.join(self.current_proj_dir, "cocoapods", "Member_modules")

    def _parse_repo_roots_from_config(self, file_path: str) -> List[str]:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
        except (OSError, UnicodeDecodeError):
            return []

        pathes_body = self._extract_pathes_body(content)
        if pathes_body is None:
            return []

        # Remove ruby comments in the array body while preserving quoted strings.
        pathes_body = self._strip_ruby_comments(pathes_body)
        paths = self.QUOTED_PATH_PATTERN.findall(pathes_body)
        normalized_paths = []
        for path in paths:
            normalized_path = os.path.abspath(os.path.expanduser(path.strip()))
            normalized_paths.append(normalized_path)
        return normalized_paths

    def _extract_pathes_body(self, content: str) -> Optional[str]:
        """
        Extract text inside :pathes => [ ... ].
        Handles multiline arrays and nested brackets safely.
        """
        match = self.PATHES_START_PATTERN.search(content)
        if not match:
            return None

        start_idx = match.end() - 1  # index of '['
        bracket_depth = 0
        in_single_quote = False
        in_double_quote = False
        escape_next = False

        for idx in range(start_idx, len(content)):
            ch = content[idx]

            if escape_next:
                escape_next = False
                continue

            if (in_single_quote or in_double_quote) and ch == "\\":
                escape_next = True
                continue

            if ch == "'" and not in_double_quote:
                in_single_quote = not in_single_quote
                continue

            if ch == '"' and not in_single_quote:
                in_double_quote = not in_double_quote
                continue

            if in_single_quote or in_double_quote:
                continue

            if ch == "[":
                bracket_depth += 1
            elif ch == "]":
                bracket_depth -= 1
                if bracket_depth == 0:
                    return content[start_idx + 1:idx]

        return None

    def _strip_ruby_comments(self, text: str) -> str:
        """
        Strip '#' comments from ruby snippet, ignoring hashes inside quotes.
        """
        output_chars = []
        in_single_quote = False
        in_double_quote = False
        escape_next = False
        idx = 0

        while idx < len(text):
            ch = text[idx]

            if escape_next:
                output_chars.append(ch)
                escape_next = False
                idx += 1
                continue

            if (in_single_quote or in_double_quote) and ch == "\\":
                output_chars.append(ch)
                escape_next = True
                idx += 1
                continue

            if ch == "'" and not in_double_quote:
                in_single_quote = not in_single_quote
                output_chars.append(ch)
                idx += 1
                continue

            if ch == '"' and not in_single_quote:
                in_double_quote = not in_double_quote
                output_chars.append(ch)
                idx += 1
                continue

            if ch == "#" and not in_single_quote and not in_double_quote:
                # Skip comment content until newline.
                while idx < len(text) and text[idx] != "\n":
                    idx += 1
                continue

            output_chars.append(ch)
            idx += 1

        return "".join(output_chars)

    def _iter_repo_roots_from_member_configs(self) -> List[Tuple[str, str]]:
        """
        Return a list of tuples: (developer_config_filename, repo_root_path)
        """
        member_modules_dir = self._get_member_modules_dir()
        if not os.path.isdir(member_modules_dir):
            return []

        roots = []
        for file_name in sorted(os.listdir(member_modules_dir)):
            if not file_name.endswith(".rb"):
                continue
            file_path = os.path.join(member_modules_dir, file_name)
            for repo_root in self._parse_repo_roots_from_config(file_path):
                roots.append((file_name, repo_root))
        return roots

    def find_git_root(self, component_name):
        # 1) 兼容旧逻辑：指定了repo_root时直接拼接
        if self.repo_root:
            return os.path.join(self.repo_root, component_name)

        # 2) 自动遍历所有开发者配置，找到实际存在的组件仓库路径
        for config_name, repo_root in self._iter_repo_roots_from_member_configs():
            candidate_path = os.path.join(repo_root, component_name)
            if os.path.isdir(candidate_path):
                print(
                    f"[✓] Found component '{component_name}' by config '{config_name}' -> {candidate_path}"
                )
                return candidate_path

        # 3) 未找到则返回None，让调用方决定兜底策略
        print(f"[!] Cannot find local git root for component '{component_name}'")
        return None