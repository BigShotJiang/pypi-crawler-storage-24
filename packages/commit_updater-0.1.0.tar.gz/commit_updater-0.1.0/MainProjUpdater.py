#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：BBScriptToolBundle 
@File    ：MainProjUpdater.py
@Author  ：Aron
@Date    ：2026/3/13 11:02 
"""
import os
import subprocess

from CommitUpdater.CommitFetcher import CommitFetcher
from CommitUpdater.ComponentGitFinder import ComponentGitFinder
from CommitUpdater.LockFileUpdater import LockFileUpdater


class MainProjUpdater:

    def __init__(self, current_proj_dir):
        self.current_proj_dir = current_proj_dir
        self.PODFILE_LOCK_PATH = os.path.join(current_proj_dir, "Podfile.lock")

    # 拉取主工程的最新代码
    def _pull_main_proj(self):
        os.chdir(self.current_proj_dir)
        subprocess.run(["git", "pull"], check=True)
        print(f"[✓] Pulled latest changes for main project at {self.current_proj_dir}")


    def _git_commit_and_push(self, component_names):
        os.chdir(self.current_proj_dir)
        subprocess.run(["git", "add", "Podfile.lock"], check=True)

        if len(component_names) == 1:
            commit_message = f"[update] {component_names[0]}"
        else:
            components_str = ", ".join(component_names)
            commit_message = f"[update] Multiple components: {components_str}"

        subprocess.run(["git", "commit", "-m", commit_message], check=True)
        subprocess.run(["git", "push"], check=True)
        print(f"[✓] Git commit and push complete for {', '.join(component_names)}")


    def update_components(self, components):
        # Pull the latest changes for the main project
        self._pull_main_proj()

        # Track successfully updated components
        updated_components = []

        # Update each component
        for component in components:
            print(f"\n[*] Processing component: {component}")

            # Find the git repository for the component
            gitFinder = ComponentGitFinder(current_proj_dir=self.current_proj_dir)  # Initialize to ensure any setup is done
            repo_path = gitFinder.find_git_root(component)  # Call to ensure any internal state is set if needed

            # Get the latest commit hash for the component
            commitFetcher = CommitFetcher(self.current_proj_dir)
            commit_val = commitFetcher.get_latest_commit(component, repo_path)

            if commit_val:
                # Update the commit in Podfile.lock
                lockFileUpdater = LockFileUpdater(self.PODFILE_LOCK_PATH)
                if lockFileUpdater.update_commit(component, commit_val):
                    updated_components.append(component)
            else:
                print(f"[!] Failed to get latest commit for {component}, skipping")

        # Push changes if any components were updated
        if updated_components:
            self._git_commit_and_push(updated_components)
            return True
        else:
            print("[!] No components were updated successfully")
            return False

