#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：BBScriptToolBundle 
@File    ：CommitFetcher.py
@Author  ：Aron
@Date    ：2026/3/13 11:06 
"""
import os
import subprocess


class CommitFetcher:

    def __init__(self, POD_REPO_ROOT):
        self.POD_REPO_ROOT = POD_REPO_ROOT

    def get_latest_commit(self, component_name, repo_path):
        """
        Get the latest commit hash from a git repository.

        Args:
            component_name (str): Name of the component repository

        Returns:
            str: Latest commit hash or None if an error occurs
        """
        try:
            # Check if the directory exists
            if not os.path.isdir(repo_path):
                print(f"[!] Repository for {component_name} not found at {repo_path}")
                return None

            # Change to the repository directory
            current_path = os.getcwd()
            os.chdir(repo_path)

            # Make sure we're up to date
            subprocess.run(["git", "fetch"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # Get the latest commit hash
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                check=True,
                capture_output=True,
                text=True
            )
            commit_hash = result.stdout.strip()

            # Return to the original directory
            os.chdir(current_path)

            print(f"[✓] Found latest commit for {component_name}: {commit_hash}")
            return commit_hash

        except subprocess.CalledProcessError as e:
            print(f"[!] Git command failed: {e}")
            # Return to the original directory if an error occurred
            if 'current_path' in locals():
                os.chdir(current_path)
            return None
        except Exception as e:
            print(f"[!] Error getting latest commit for {component_name}: {e}")
            # Return to the original directory if an error occurred
            if 'current_path' in locals():
                os.chdir(current_path)
            return None

