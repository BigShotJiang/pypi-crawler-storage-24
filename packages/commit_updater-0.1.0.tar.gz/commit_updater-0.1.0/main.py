#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：BBScriptToolBundle
@File    ：CommitUpdater.py
@Author  ：Aron
@Date    ：2025/4/17 10:50
"""

import os
import re
import subprocess
import argparse

from CommitUpdater.MainProjUpdater import MainProjUpdater

# POD_REPO_ROOT = "/Users/aron/MyWorkSpaces/CodeRepos/"
current_proj_dir = os.getcwd()
# current_proj_dir = "/Users/aron/MyWorkSpaces/CodeRepos/bbframework_iOS_New_3D/proj.ios"
PODFILE_LOCK_PATH = os.path.join(current_proj_dir, "Podfile.lock")


def main():
    parser = argparse.ArgumentParser(description="Update component commit(s) in Podfile.lock and push to Git")
    parser.add_argument("components", nargs="+", help="Component name(s) (e.g., BBUnlock BBEngine)")
    args = parser.parse_args()

    MainProjUpdater(current_proj_dir).update_components(args.components)


if __name__ == "__main__":
    isTest = False
    if isTest:
        # For testing purposes, you can hardcode component names here
        current_proj_dir = "/Volumes/Realtek/MyWorkSpaces/CodeRepos/Baby_Recommend2"
        test_components = ["BBVocabMemoTool"]
        MainProjUpdater(current_proj_dir).update_components(test_components)
    else:
        main()