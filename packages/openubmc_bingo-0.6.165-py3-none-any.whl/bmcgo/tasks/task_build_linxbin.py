#!/usr/bin/env python
# coding:utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2022-2024. All rights reserved.
 
"""
文件名：task_build_linxbin.py
功能：编译灵犀核固件
版权信息：华为技术有限公司，版本所有(C) 2020-2021
"""
import os

from bmcgo import errors

from bmcgo.tasks.task import Task
from bmcgo.utils.config import Config


class TaskClass(Task):
    def __init__(self, config: Config, work_name=""):
        super(TaskClass, self).__init__(config, work_name=work_name)
        self.download_conf = None
        self.linx_bin = None
        # 构建linx bin的工作目录
        self.build_dir = self.config.linx_build_dir
        self.code_dir = os.path.join(self.build_dir, "code")
        self.output_dir = os.path.join(self.build_dir, "out")
        self.linx_sign_dir = os.path.join(self.build_dir, "sign")
        self.liteos_dir = os.path.join(self.code_dir, "kernel_liteos_m")
        self.linx_conf = self.get_manufacture_config("linx")
    
    def down_linx_code(self):
        if self.config.partner_mode:
            return

    def build_linx_bin(self):
        if os.path.exists(self.output_dir):
            self.run_command(f"rm -rf {self.output_dir}", sudo=True)
        os.mkdir(self.output_dir)

        partner_sdk_dir = f"{os.path.expanduser('~')}/sdk"
        if self.config.partner_mode:
            self.run_command(f"cp -af {partner_sdk_dir}/LiteOS_M.bin {self.output_dir}/origin_LiteOS_M.bin")
            return

    def encrypt_sign_linx(self):
        self.info("开始签名linx固件")
        self.prepare_sign_files()

        # linx固件的加密和签名方式产品包一致。
        encrypt_sign_type = "rsa"
        if self.config.self_sign and encrypt_sign_type != "rsa":
            raise errors.BmcGoException("自签名模式仅支持rsa算法 !!!")
        #兼容老旧linx加密签名逻辑
        if os.path.exists("build_sign_riscv_fw.sh"):
            self.run_command(f"sh build_sign_riscv_fw.sh {encrypt_sign_type}", shell=True, check=True)
        else:
            self.encrypt_sign_linx_new(encrypt_sign_type)

        self.run_command(f"cp -af {self.linx_sign_dir}/output/riscv_fw_{encrypt_sign_type}_cms.bin \
            {self.output_dir}/LiteOS_M.bin")

        # 将top_header复制到共享目录output_dir，后面制作gpp3的linx分区会使用
        self.run_command(f"cp -af {self.linx_sign_dir}/output/gpp4_top_hdr.bin {self.output_dir}/")
    
    def prepare_sign_files(self):
        if os.path.exists(self.linx_sign_dir):
            self.run_command(f"rm -rf {self.linx_sign_dir}", sudo=True)
        os.mkdir(self.linx_sign_dir)
        self.chdir(self.linx_sign_dir)

        if not self.config.self_sign:
            # 复制linx签名所需的根证书到 linx_sign_dir
            files = self.get_manufacture_config(f"linx/files")
            if files is None:
                raise errors.BmcGoException("获取 manifest.yml 中 linx/files 配置失败, 请检查 linx/files 配置, 退出 !!!")
            exclude_files = None
            self.copy_manifest_files(files, exclude_files)

        # 复制未加密和签名的linx固件到 linx_sign_dir
        self.run_command(f"cp -af {self.output_dir}/origin_LiteOS_M.bin riscv_fw_sec.bin")
        # 将加密签名脚本复制到 linx_sign_dir
        self.run_command(f"cp -ar {self.config.temp_platform_build_dir}/linx/sign_coprocessor/. .")

    def encrypt_sign_linx_new(self, encrypt_sign_type):
        self.run_command(f"sh 01_prepare_build.sh {encrypt_sign_type}", shell=True, check=True)
        self.run_command(f"sh 02_build_cop_param.sh {encrypt_sign_type}", shell=True, check=True)
        if self.config.self_sign:
            self.signature("riscv_fw_sec.bin", "riscv_fw_sec.bin.cms", "crldata_g2.crl", "host_cms_root_cert_g2.bin")
        else:
            self.run_command(f"sh 03_build_sign.sh {encrypt_sign_type}", shell=True, check=True)
        self.run_command(f"sh 04_generate_image.sh {encrypt_sign_type}", shell=True, check=True)
        self.run_command(f"sh 05_build_header.sh {encrypt_sign_type}", shell=True, check=True)

    def run(self):
        if self.config.chip == "1711":
            return

        skip_linx = self.get_manufacture_config("skip_linx", False)
        if skip_linx:
            # 兼容升级模块，如跳过打包linx估计，构建空文件占位
            self.run_command(f"rm -rf {self.output_dir}")
            os.makedirs(self.output_dir, exist_ok=True)
            self.run_command(f"dd if=/dev/zero of={self.output_dir}/LiteOS_M.bin bs=1024 count=100")
            self.run_command(f"dd if=/dev/zero of={self.output_dir}/gpp4_top_hdr.bin bs=512 count=1")
            return

        self.info(">>>===== Build LINX start ==============>>>")
        # 下载linx源码文件
        self.down_linx_code()
        # 构建linx bin
        self.build_linx_bin()
        if not os.getenv("SKIP_SIGN_LINX"):
            # 签名linx bin
            self.encrypt_sign_linx()
        self.info(">>>===== Build LINX end ==============<<<")
