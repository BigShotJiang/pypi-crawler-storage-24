"""
Contact property resource for managing contact property definitions.
"""

from typing import Any, Dict, List

from emailr.http import AsyncHttpClient, HttpClient
from emailr.types import (
    ContactPropertyDefinition,
    CreateContactPropertyDefinitionRequest,
    SuccessResponse,
)


class ContactPropertiesResource:
    """Synchronous resource for managing contact property definitions."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(self) -> List[ContactPropertyDefinition]:
        """
        List all contact property definitions.

        Returns:
            List of property definitions
        """
        data = self._http.get("/v1/contact-properties")
        if isinstance(data, list):
            return [ContactPropertyDefinition.from_dict(p) for p in data]
        return [ContactPropertyDefinition.from_dict(p) for p in data.get("data", data)]

    def create(
        self,
        name: str,
        type: str,
    ) -> ContactPropertyDefinition:
        """
        Create a new contact property definition.

        Args:
            name: Property name
            type: Property type ('string', 'number', 'boolean', 'date')

        Returns:
            Created property definition
        """
        request = CreateContactPropertyDefinitionRequest(name=name, type=type)
        data = self._http.post("/v1/contact-properties", request.to_dict())
        return ContactPropertyDefinition.from_dict(data)

    def delete(self, id: str) -> SuccessResponse:
        """
        Delete a contact property definition.

        Args:
            id: Property definition ID

        Returns:
            Success response
        """
        data = self._http.delete(f"/v1/contact-properties/{id}")
        return SuccessResponse(success=data.get("success", True))


class AsyncContactPropertiesResource:
    """Asynchronous resource for managing contact property definitions."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(self) -> List[ContactPropertyDefinition]:
        """List all contact property definitions."""
        data = await self._http.get("/v1/contact-properties")
        if isinstance(data, list):
            return [ContactPropertyDefinition.from_dict(p) for p in data]
        return [ContactPropertyDefinition.from_dict(p) for p in data.get("data", data)]

    async def create(
        self,
        name: str,
        type: str,
    ) -> ContactPropertyDefinition:
        """Create a new contact property definition."""
        request = CreateContactPropertyDefinitionRequest(name=name, type=type)
        data = await self._http.post("/v1/contact-properties", request.to_dict())
        return ContactPropertyDefinition.from_dict(data)

    async def delete(self, id: str) -> SuccessResponse:
        """Delete a contact property definition."""
        data = await self._http.delete(f"/v1/contact-properties/{id}")
        return SuccessResponse(success=data.get("success", True))
