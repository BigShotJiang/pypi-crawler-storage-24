"""
Topic resource for managing broadcast topics.
"""

from typing import Any, Dict, List, Optional

from emailr.http import AsyncHttpClient, HttpClient
from emailr.types import (
    CreateTopicRequest,
    Topic,
    SuccessResponse,
    UpdateTopicRequest,
)


class TopicsResource:
    """Synchronous topic resource for managing broadcast topics."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(self) -> List[Topic]:
        """
        List all topics.

        Returns:
            List of topics
        """
        data = self._http.get("/v1/topics")
        topics = data.get("topics", []) if isinstance(data, dict) else data
        return [Topic.from_dict(t) for t in topics]

    def create(
        self,
        name: str,
        *,
        description: Optional[str] = None,
    ) -> Topic:
        """
        Create a new topic.

        Args:
            name: Topic name
            description: Topic description

        Returns:
            Created topic
        """
        request = CreateTopicRequest(name=name, description=description)
        data = self._http.post("/v1/topics", request.to_dict())
        return Topic.from_dict(data)

    def update(
        self,
        id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Topic:
        """
        Update a topic.

        Args:
            id: Topic ID
            name: New topic name
            description: New topic description

        Returns:
            Updated topic
        """
        request = UpdateTopicRequest(name=name, description=description)
        data = self._http.put(f"/v1/topics/{id}", request.to_dict())
        return Topic.from_dict(data)

    def delete(self, id: str) -> SuccessResponse:
        """
        Delete a topic.

        Args:
            id: Topic ID

        Returns:
            Success response
        """
        data = self._http.delete(f"/v1/topics/{id}")
        return SuccessResponse(success=data.get("success", True))


class AsyncTopicsResource:
    """Asynchronous topic resource for managing broadcast topics."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(self) -> List[Topic]:
        """List all topics."""
        data = await self._http.get("/v1/topics")
        topics = data.get("topics", []) if isinstance(data, dict) else data
        return [Topic.from_dict(t) for t in topics]

    async def create(
        self,
        name: str,
        *,
        description: Optional[str] = None,
    ) -> Topic:
        """Create a new topic."""
        request = CreateTopicRequest(name=name, description=description)
        data = await self._http.post("/v1/topics", request.to_dict())
        return Topic.from_dict(data)

    async def update(
        self,
        id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Topic:
        """Update a topic."""
        request = UpdateTopicRequest(name=name, description=description)
        data = await self._http.put(f"/v1/topics/{id}", request.to_dict())
        return Topic.from_dict(data)

    async def delete(self, id: str) -> SuccessResponse:
        """Delete a topic."""
        data = await self._http.delete(f"/v1/topics/{id}")
        return SuccessResponse(success=data.get("success", True))
