"""
Logs resource for querying email event logs.
"""

from typing import Any, Dict, List, Optional

from emailr.http import AsyncHttpClient, HttpClient
from emailr.types import EmailEvent


class LogsResource:
    """Synchronous resource for querying email event logs."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(
        self,
        *,
        email_id: Optional[str] = None,
        event_type: Optional[str] = None,
    ) -> List[EmailEvent]:
        """
        List email event logs with optional filtering.

        Args:
            email_id: Filter by email ID
            event_type: Filter by event type

        Returns:
            List of email events
        """
        params: Dict[str, Any] = {}
        if email_id is not None:
            params["email_id"] = email_id
        if event_type is not None:
            params["event_type"] = event_type

        data = self._http.get("/v1/logs", params=params)
        if isinstance(data, list):
            return [EmailEvent.from_dict(e) for e in data]
        return [EmailEvent.from_dict(e) for e in data.get("data", data)]


class AsyncLogsResource:
    """Asynchronous resource for querying email event logs."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(
        self,
        *,
        email_id: Optional[str] = None,
        event_type: Optional[str] = None,
    ) -> List[EmailEvent]:
        """List email event logs with optional filtering."""
        params: Dict[str, Any] = {}
        if email_id is not None:
            params["email_id"] = email_id
        if event_type is not None:
            params["event_type"] = event_type

        data = await self._http.get("/v1/logs", params=params)
        if isinstance(data, list):
            return [EmailEvent.from_dict(e) for e in data]
        return [EmailEvent.from_dict(e) for e in data.get("data", data)]
