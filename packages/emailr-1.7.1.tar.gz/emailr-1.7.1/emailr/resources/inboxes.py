"""
Inbox resource for managing email inboxes.
"""

from typing import Any, Dict, List, Optional

from emailr.http import AsyncHttpClient, HttpClient
from emailr.types import (
    CreateInboxRequest,
    Inbox,
    SuccessResponse,
    UpdateInboxRequest,
)


class InboxesResource:
    """Synchronous inbox resource for managing email inboxes."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(
        self,
        name: str,
        username: str,
        domain: str,
        *,
        reply_to: Optional[str] = None,
    ) -> Inbox:
        """
        Create a new inbox.

        Args:
            name: Display name for the inbox
            username: Username part of the email address
            domain: Domain part of the email address
            reply_to: Custom reply-to address (defaults to username@mail.domain)

        Returns:
            Created inbox
        """
        request = CreateInboxRequest(
            name=name,
            username=username,
            domain=domain,
            reply_to=reply_to,
        )
        data = self._http.post("/v1/inboxes", request.to_dict())
        return Inbox.from_dict(data)

    def list(self) -> List[Inbox]:
        """
        List all inboxes for the organization.

        Returns:
            List of inboxes
        """
        data = self._http.get("/v1/inboxes")
        if isinstance(data, list):
            return [Inbox.from_dict(i) for i in data]
        return [Inbox.from_dict(i) for i in data.get("data", data)]

    def get(self, id: str) -> Inbox:
        """
        Get inbox by ID.

        Args:
            id: Inbox ID

        Returns:
            Inbox record
        """
        data = self._http.get(f"/v1/inboxes/{id}")
        return Inbox.from_dict(data)

    def update(
        self,
        id: str,
        *,
        name: Optional[str] = None,
        reply_to: Optional[str] = None,
    ) -> Inbox:
        """
        Update an inbox.

        Args:
            id: Inbox ID
            name: New display name
            reply_to: New reply-to address (set to empty string to reset to default)

        Returns:
            Updated inbox
        """
        request = UpdateInboxRequest(name=name, reply_to=reply_to)
        data = self._http.put(f"/v1/inboxes/{id}", request.to_dict())
        return Inbox.from_dict(data)

    def delete(self, id: str) -> SuccessResponse:
        """
        Delete an inbox.

        Args:
            id: Inbox ID

        Returns:
            Success response
        """
        data = self._http.delete(f"/v1/inboxes/{id}")
        return SuccessResponse(success=data.get("success", True))


class AsyncInboxesResource:
    """Asynchronous inbox resource for managing email inboxes."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(
        self,
        name: str,
        username: str,
        domain: str,
        *,
        reply_to: Optional[str] = None,
    ) -> Inbox:
        """Create a new inbox."""
        request = CreateInboxRequest(
            name=name,
            username=username,
            domain=domain,
            reply_to=reply_to,
        )
        data = await self._http.post("/v1/inboxes", request.to_dict())
        return Inbox.from_dict(data)

    async def list(self) -> List[Inbox]:
        """List all inboxes for the organization."""
        data = await self._http.get("/v1/inboxes")
        if isinstance(data, list):
            return [Inbox.from_dict(i) for i in data]
        return [Inbox.from_dict(i) for i in data.get("data", data)]

    async def get(self, id: str) -> Inbox:
        """Get inbox by ID."""
        data = await self._http.get(f"/v1/inboxes/{id}")
        return Inbox.from_dict(data)

    async def update(
        self,
        id: str,
        *,
        name: Optional[str] = None,
        reply_to: Optional[str] = None,
    ) -> Inbox:
        """Update an inbox."""
        request = UpdateInboxRequest(name=name, reply_to=reply_to)
        data = await self._http.put(f"/v1/inboxes/{id}", request.to_dict())
        return Inbox.from_dict(data)

    async def delete(self, id: str) -> SuccessResponse:
        """Delete an inbox."""
        data = await self._http.delete(f"/v1/inboxes/{id}")
        return SuccessResponse(success=data.get("success", True))
