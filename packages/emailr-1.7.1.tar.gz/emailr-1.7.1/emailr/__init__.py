"""
Emailr SDK for Python

Official Python SDK for the Emailr email API service.
Provides both synchronous and asynchronous clients for sending emails,
managing contacts, templates, domains, webhooks, broadcasts, and segments.

Example usage:
    >>> from emailr import Emailr
    >>> client = Emailr(api_key="your-api-key")
    >>> result = client.emails.send(
    ...     to="recipient@example.com",
    ...     from_="sender@yourdomain.com",
    ...     subject="Hello!",
    ...     html="<h1>Hello World</h1>"
    ... )

For async usage:
    >>> from emailr import AsyncEmailr
    >>> async with AsyncEmailr(api_key="your-api-key") as client:
    ...     result = await client.emails.send(
    ...         to="recipient@example.com",
    ...         from_="sender@yourdomain.com",
    ...         subject="Hello!",
    ...         html="<h1>Hello World</h1>"
    ...     )
"""

from emailr.client import AsyncEmailr, Emailr
from emailr.errors import (
    AuthenticationError,
    EmailrError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from emailr.types import (
    AddDomainRequest,
    ApiKey,
    Attachment,
    Broadcast,
    BroadcastStats,
    BulkCreateContactsRequest,
    BulkCreateContactsResponse,
    Contact,
    ContactListResponse,
    ContactPropertyDefinition,
    CreateApiKeyRequest,
    CreateBroadcastRequest,
    CreateContactPropertyDefinitionRequest,
    CreateContactRequest,
    CreateForwardingRuleRequest,
    CreateInboxRequest,
    CreateSegmentRequest,
    CreateTemplateRequest,
    CreateTopicRequest,
    CreateWebhookRequest,
    DnsRecord,
    DnsVerificationStatus,
    Domain,
    DomainDnsRecords,
    DomainVerificationStatus,
    Email,
    EmailEvent,
    ForwardEmailRequest,
    ForwardingRule,
    Inbox,
    ListApiKeysParams,
    ListBroadcastsParams,
    ListContactsParams,
    ListEmailsParams,
    ListLogsParams,
    ListSegmentsParams,
    ListTemplatesParams,
    ListWebhooksParams,
    PaginatedResponse,
    Pagination,
    PushPreviewResponse,
    ReplyTo,
    Segment,
    SegmentContactsResponse,
    SegmentCountResponse,
    SendBroadcastResponse,
    SendEmailRequest,
    SendEmailResponse,
    SuccessResponse,
    Template,
    Thread,
    ThreadDetail,
    ThreadDraft,
    ThreadDraftRequest,
    ThreadMessage,
    ThreadReplyRequest,
    ThreadReplyResponse,
    Topic,
    UpdateBroadcastRequest,
    UpdateContactRequest,
    UpdateDomainRequest,
    UpdateInboxRequest,
    UpdateLabelsRequest,
    UpdateLabelsResponse,
    UpdateSegmentRequest,
    UpdateTemplateRequest,
    UpdateThreadLabelsResponse,
    UpdateTopicRequest,
    UpdateWebhookRequest,
    Webhook,
    WebhookDelivery,
    WebhookToggleResponse,
)

__version__ = "1.7.1"

__all__ = [
    # Clients
    "Emailr",
    "AsyncEmailr",
    # Errors
    "EmailrError",
    "NetworkError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    "ValidationError",
    # Types - Common
    "PaginatedResponse",
    "Pagination",
    "SuccessResponse",
    # Types - Email
    "Attachment",
    "ReplyTo",
    "SendEmailRequest",
    "SendEmailResponse",
    "Email",
    "ListEmailsParams",
    "ForwardEmailRequest",
    "ForwardingRule",
    "CreateForwardingRuleRequest",
    # Types - Contact
    "Contact",
    "CreateContactRequest",
    "UpdateContactRequest",
    "ListContactsParams",
    "ContactListResponse",
    "BulkCreateContactsRequest",
    "BulkCreateContactsResponse",
    # Types - Template
    "Template",
    "CreateTemplateRequest",
    "UpdateTemplateRequest",
    "ListTemplatesParams",
    "PushPreviewResponse",
    # Types - Domain
    "DnsRecord",
    "DomainDnsRecords",
    "Domain",
    "AddDomainRequest",
    "UpdateDomainRequest",
    "DomainVerificationStatus",
    "DnsVerificationStatus",
    # Types - Webhook
    "Webhook",
    "CreateWebhookRequest",
    "WebhookToggleResponse",
    "WebhookDelivery",
    # Types - Broadcast
    "Broadcast",
    "BroadcastStats",
    "CreateBroadcastRequest",
    "UpdateBroadcastRequest",
    "SendBroadcastResponse",
    "ListBroadcastsParams",
    # Types - Inbox
    "Inbox",
    "CreateInboxRequest",
    "UpdateInboxRequest",
    # Types - Thread
    "Thread",
    "ThreadDetail",
    "ThreadMessage",
    "ThreadReplyRequest",
    "ThreadReplyResponse",
    "ThreadDraftRequest",
    "ThreadDraft",
    "UpdateLabelsRequest",
    "UpdateLabelsResponse",
    "UpdateThreadLabelsResponse",
    # Types - Segment
    "Segment",
    "SegmentContactsResponse",
    "SegmentCountResponse",
    "CreateSegmentRequest",
    "UpdateSegmentRequest",
    "ListSegmentsParams",
    # Types - API Key
    "ApiKey",
    "CreateApiKeyRequest",
    "ListApiKeysParams",
    # Types - Topic
    "Topic",
    "CreateTopicRequest",
    "UpdateTopicRequest",
    # Types - Contact Properties
    "ContactPropertyDefinition",
    "CreateContactPropertyDefinitionRequest",
    # Types - Logs
    "EmailEvent",
    "ListLogsParams",
]
