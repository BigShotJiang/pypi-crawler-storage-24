"""Custom exceptions for the quickbase-api package."""


class QuickbaseError(Exception):
    """Base exception for all Quickbase errors."""


class QuickbaseAPIError(QuickbaseError):
    """Raised when the Quickbase API returns an unexpected status code."""

    def __init__(self, status_code: int, response_body: dict):
        self.status_code = status_code
        self.response_body = response_body
        message = response_body.get("message", response_body)
        super().__init__(f"Quickbase API error {status_code}: {message}")


class QuickbaseNotFoundError(QuickbaseError):
    """Raised when a requested resource (table, field, etc.) is not found."""
