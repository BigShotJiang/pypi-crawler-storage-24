"""A simple Python wrapper for the Quickbase API.

Example::

    import quickbase_api

    # Option 1: Using the factory function (reads from environment variables)
    client = quickbase_api.client()

    # Option 2: Passing credentials directly
    client = quickbase_api.client(
        realm="mycompany.quickbase.com",
        user_token="my-token",
    )

    # Option 3: Using the class directly
    from quickbase_api import QuickbaseClient
    client = QuickbaseClient("mycompany.quickbase.com", "my-token")
"""

from __future__ import annotations

import os

from quickbase_api.api import QuickbaseClient
from quickbase_api.exceptions import (
    QuickbaseAPIError,
    QuickbaseError,
    QuickbaseNotFoundError,
)

__version__ = "0.1.0"

__all__ = [
    "QuickbaseClient",
    "QuickbaseAPIError",
    "QuickbaseError",
    "QuickbaseNotFoundError",
    "client",
]


def client(realm: str = None, user_token: str = None) -> QuickbaseClient:
    """Create a QuickbaseClient, falling back to environment variables.

    Args:
        realm: The Quickbase realm hostname. If not provided, reads from
            the ``QUICKBASE_REALM`` environment variable.
        user_token: The Quickbase user token. If not provided, reads from
            the ``QUICKBASE_USER_TOKEN`` environment variable.

    Returns:
        A configured QuickbaseClient instance.

    Raises:
        KeyError: If a credential is not provided and the corresponding
            environment variable is not set.

    Example::

        # Set environment variables, then:
        import quickbase_api
        client = quickbase_api.client()
    """
    return QuickbaseClient(
        realm=realm or os.environ["QUICKBASE_REALM"],
        user_token=user_token or os.environ["QUICKBASE_USER_TOKEN"],
    )
