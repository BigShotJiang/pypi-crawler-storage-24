"""Shared HTTP session factory for Quickbase API clients."""

import requests
from requests.adapters import HTTPAdapter, Retry


def create_session(realm: str, user_token: str) -> requests.Session:
    """Create a configured requests session with retry logic.

    Args:
        realm: The Quickbase realm hostname (e.g., 'mycompany.quickbase.com').
        user_token: The Quickbase user token for authentication.

    Returns:
        A configured requests.Session with retries and auth headers.
    """
    session = requests.Session()
    retries = Retry(
        total=5,
        backoff_factor=1,
        status_forcelist=[429, 502, 503, 504],
        respect_retry_after_header=True,
    )
    session.mount("https://", HTTPAdapter(max_retries=retries))
    session.headers.update(
        {
            "QB-Realm-Hostname": realm,
            "Authorization": f"QB-USER-TOKEN {user_token}",
            "Content-Type": "application/json",
        }
    )
    return session
