"""Client for Quickbase's legacy XML/URL-based API endpoints."""

from __future__ import annotations

import logging

from quickbase_api.session import create_session

logger = logging.getLogger(__name__)


class LegacyMethod:
    """Low-level HTTP client for legacy Quickbase API endpoints.

    Used for older API actions (e.g., API_SetKeyField) that are not
    available through the modern REST API.
    """

    def __init__(self, realm: str, user_token: str):
        self.realm = realm
        self.session = create_session(realm, user_token)

    def make_request(
        self,
        method: str,
        url: str,
        params: dict = None,
    ) -> tuple[dict, int]:
        """Execute an HTTP request against a legacy Quickbase endpoint.

        Args:
            method: HTTP method (GET, POST, DELETE).
            url: Full URL for the legacy endpoint.
            params: Optional query string parameters.

        Returns:
            A tuple of (response_body, status_code).
        """
        response = self.session.request(method=method, url=url, params=params)
        try:
            body = response.json()
        except ValueError:
            body = {"raw_response": response.text}

        if response.status_code >= 400:
            logger.error(
                "Legacy API error %d on %s %s: %s",
                response.status_code,
                method,
                url,
                body,
            )

        return body, response.status_code

    def get(self, url: str, params: dict = None) -> tuple[dict, int]:
        """Send a GET request."""
        return self.make_request("GET", url, params=params)

    def post(self, url: str, params: dict = None) -> tuple[dict, int]:
        """Send a POST request."""
        return self.make_request("POST", url, params=params)

    def delete(self, url: str, params: dict = None) -> tuple[dict, int]:
        """Send a DELETE request."""
        return self.make_request("DELETE", url, params=params)
