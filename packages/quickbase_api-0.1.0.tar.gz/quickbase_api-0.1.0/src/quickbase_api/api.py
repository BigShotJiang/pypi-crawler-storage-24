# FILE: api.py

"""Quickbase API client providing high-level methods for apps, tables, fields, and records."""

from __future__ import annotations

import logging
from typing import Optional

from quickbase_api.exceptions import QuickbaseAPIError, QuickbaseNotFoundError
from quickbase_api.legacy_method import LegacyMethod
from quickbase_api.rest_method import RestMethod

logger = logging.getLogger(__name__)


class QuickbaseClient:
    """High-level client for interacting with the Quickbase API.

    Args:
        realm: The Quickbase realm hostname (e.g., 'mycompany.quickbase.com').
        user_token: The Quickbase user token for authentication.

    Example::

        from quickbase_api import QuickbaseClient

        client = QuickbaseClient("mycompany.quickbase.com", "my-token")
        app = client.get_app("bqrg4xyza")
    """

    def __init__(self, realm: str, user_token: str):
        self.realm = realm
        self.user_token = user_token
        self._rm = RestMethod(realm, user_token)
        self._lm = LegacyMethod(realm, user_token)

    def _require_success(self, resp_json: dict, resp_code: int, context: str) -> dict:
        """Raise QuickbaseAPIError if the response code indicates failure.

        Args:
            resp_json: The parsed response body.
            resp_code: The HTTP status code.
            context: A human-readable description of the operation for error messages.

        Returns:
            The response body if successful.

        Raises:
            QuickbaseAPIError: If the status code is 400 or above.
        """
        if resp_code >= 400:
            raise QuickbaseAPIError(resp_code, resp_json)
        return resp_json

    # ── Apps ──────────────────────────────────────────────────────────────

    def create_app(
        self,
        name: str,
        description: str = None,
        assign_token: bool = None,
    ) -> str:
        """Create a new Quickbase app.

        Args:
            name: The name for the new app.
            description: Optional description for the app.
            assign_token: If True, assigns the user token to the new app.

        Returns:
            The app ID of the newly created app.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        body = {"name": name}
        if description is not None:
            body["description"] = description
        if assign_token is not None:
            body["assignToken"] = assign_token

        resp_json, resp_code = self._rm.post("apps", data=body)
        self._require_success(resp_json, resp_code, f"create app '{name}'")
        logger.info("Created app '%s' with ID: %s", resp_json["name"], resp_json["id"])
        return resp_json["id"]

    def delete_app(self, app_name: str, app_id: str) -> dict:
        """Delete a Quickbase app.

        Args:
            app_name: The name of the app (required for confirmation).
            app_id: The ID of the app to delete.

        Returns:
            The API response body.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.delete(
            f"apps/{app_id}",
            data={"name": app_name},
        )
        self._require_success(resp_json, resp_code, f"delete app '{app_name}'")
        logger.info("Deleted app '%s' (%s)", app_name, app_id)
        return resp_json

    def get_app(self, app_id: str) -> dict:
        """Get metadata for a Quickbase app.

        Args:
            app_id: The ID of the app.

        Returns:
            A dictionary of app metadata.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get(f"apps/{app_id}")
        self._require_success(resp_json, resp_code, f"get app '{app_id}'")
        return resp_json

    # ── Tables ────────────────────────────────────────────────────────────

    def create_table(self, app_id: str, properties: dict) -> str:
        """Create a new table in a Quickbase app.

        Args:
            app_id: The ID of the app to create the table in.
            properties: A dictionary of table properties (must include 'name').

        Returns:
            The table ID of the newly created table.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.post(
            "tables",
            params={"appId": app_id},
            data=properties,
        )
        self._require_success(resp_json, resp_code, f"create table in app '{app_id}'")
        logger.info("Created table '%s' with ID: %s", resp_json["name"], resp_json["id"])
        return resp_json["id"]

    def get_tables(self, app_id: str) -> list[dict]:
        """Get all tables for a Quickbase app.

        Args:
            app_id: The ID of the app.

        Returns:
            A list of table metadata dictionaries.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get("tables", params={"appId": app_id})
        self._require_success(resp_json, resp_code, f"get tables for app '{app_id}'")
        return resp_json

    def get_table_id(self, app_id: str, table_name: str) -> str:
        """Find a table ID by its name.

        Args:
            app_id: The ID of the app containing the table.
            table_name: The exact name of the table to find.

        Returns:
            The table ID.

        Raises:
            QuickbaseNotFoundError: If no table with the given name is found.
        """
        tables = self.get_tables(app_id)
        for table in tables:
            if table["name"] == table_name:
                return table["id"]
        raise QuickbaseNotFoundError(f"No table named '{table_name}' in app '{app_id}'")

    def delete_table(self, app_id: str, table_id: str) -> dict:
        """Delete a table from a Quickbase app.

        Args:
            app_id: The ID of the app containing the table.
            table_id: The ID of the table to delete.

        Returns:
            The API response body.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.delete(
            f"tables/{table_id}",
            params={"appId": app_id},
        )
        self._require_success(resp_json, resp_code, f"delete table '{table_id}'")
        logger.info("Deleted table %s from app %s", table_id, app_id)
        return resp_json

    # ── Reports ───────────────────────────────────────────────────────────

    def get_reports(self, table_id: str) -> list[dict]:
        """Get all reports for a table.

        Args:
            table_id: The ID of the table.

        Returns:
            A list of report metadata dictionaries.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get("reports", params={"tableId": table_id})
        self._require_success(resp_json, resp_code, f"get reports for table '{table_id}'")
        return resp_json

    def get_report(self, table_id: str, report_id: str) -> dict:
        """Get metadata for a specific report.

        Args:
            table_id: The ID of the table containing the report.
            report_id: The ID of the report.

        Returns:
            A dictionary of report metadata.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get(
            f"reports/{report_id}",
            params={"tableId": table_id},
        )
        self._require_success(resp_json, resp_code, f"get report '{report_id}'")
        return resp_json

    def run_report(
        self,
        table_id: str,
        report_id: str,
        skip: int = None,
        top: int = None,
    ) -> dict:
        """Run a report and return its results.

        Args:
            table_id: The ID of the table containing the report.
            report_id: The ID of the report to run.
            skip: Number of records to skip (for pagination).
            top: Maximum number of records to return.

        Returns:
            The report results.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        params = {"tableId": table_id}
        if skip is not None:
            params["skip"] = skip
        if top is not None:
            params["top"] = top

        resp_json, resp_code = self._rm.post(
            f"reports/{report_id}/run",
            params=params,
        )
        self._require_success(resp_json, resp_code, f"run report '{report_id}'")
        return resp_json

    # ── Fields ────────────────────────────────────────────────────────────

    def create_field(self, table_id: str, properties: dict) -> dict:
        """Create a new field in a table.

        Args:
            table_id: The ID of the table.
            properties: Field properties (must include 'label' and 'fieldType').

        Returns:
            The API response body with the created field's metadata.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.post(
            "fields",
            params={"tableId": table_id},
            data=properties,
        )
        self._require_success(resp_json, resp_code, f"create field in table '{table_id}'")
        logger.info(
            "Created field '%s' (ID: %s) in table %s",
            resp_json["label"],
            resp_json["id"],
            table_id,
        )
        return resp_json

    def create_fields(self, table_id: str, fields: list[dict]) -> dict:
        """Create multiple fields in a table.

        Args:
            table_id: The ID of the table.
            fields: A list of field property dictionaries.

        Returns:
            A dict with 'succeeded' and 'failed' lists.
        """
        results = {"succeeded": [], "failed": []}
        for field in fields:
            try:
                created = self.create_field(table_id, field)
                results["succeeded"].append(created)
            except QuickbaseAPIError as e:
                logger.warning("Failed to create field %s: %s", field, e)
                results["failed"].append({"field": field, "error": str(e)})

        logger.info(
            "%d of %d fields created for table %s",
            len(results["succeeded"]),
            len(fields),
            table_id,
        )
        return results

    def get_table_fields(self, table_id: str) -> list[dict]:
        """Get all fields for a table.

        Args:
            table_id: The ID of the table.

        Returns:
            A list of field metadata dictionaries.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get("fields", params={"tableId": table_id})
        self._require_success(resp_json, resp_code, f"get fields for table '{table_id}'")
        return resp_json

    def get_field_id(self, table_id: str, field_label: str) -> str:
        """Find a field ID by its label.

        Args:
            table_id: The ID of the table.
            field_label: The exact label of the field to find.

        Returns:
            The field ID as a string.

        Raises:
            QuickbaseNotFoundError: If no field with the given label is found.
        """
        fields = self.get_table_fields(table_id)
        for field in fields:
            if field["label"] == field_label:
                return str(field["id"])
        raise QuickbaseNotFoundError(f"No field labeled '{field_label}' in table '{table_id}'")

    def get_field_label_id_map(self, table_id: str) -> dict[str, str]:
        """Build a mapping of field labels to field IDs.

        Args:
            table_id: The ID of the table.

        Returns:
            A dict mapping field label strings to field ID strings.
        """
        fields = self.get_table_fields(table_id)
        return {f["label"]: str(f["id"]) for f in fields}

    def get_key_field_id(self, app_id: str, table_id: str) -> str:
        """Get the key field ID for a table.

        Args:
            app_id: The ID of the app.
            table_id: The ID of the table.

        Returns:
            The key field ID as a string.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get(
            f"tables/{table_id}",
            params={"appId": app_id},
        )
        self._require_success(resp_json, resp_code, f"get key field for table '{table_id}'")
        return str(resp_json["keyFieldId"])

    def set_key_field(self, table_id: str, field_id: str) -> bool:
        """Set the key field for a table using the legacy API.

        Args:
            table_id: The ID of the table.
            field_id: The ID of the field to set as the key field.

        Returns:
            True if the key field was set successfully.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        url = f"https://{self.realm}/db/{table_id}"
        params = {"a": "API_SetKeyField", "fid": field_id}

        resp_json, resp_code = self._lm.post(url, params=params)
        if resp_code != 200:
            raise QuickbaseAPIError(resp_code, resp_json)

        logger.info(
            "Set key field to %s for table %s",
            field_id,
            table_id,
        )
        return True

    def set_required_field(self, table_id: str, field_id: str) -> bool:
        """Mark a field as required.

        Args:
            table_id: The ID of the table.
            field_id: The ID of the field to mark as required.

        Returns:
            True if the field was successfully marked as required.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.post(
            f"fields/{field_id}",
            params={"tableId": table_id},
            data={"required": True},
        )
        self._require_success(resp_json, resp_code, f"set field '{field_id}' as required")
        return True

    # ── Records ───────────────────────────────────────────────────────────

    def upsert_records(self, table_id: str, data: list[dict]) -> dict:
        """Insert or update records in a table.

        Args:
            table_id: The ID of the table.
            data: A list of record dictionaries, keyed by field ID::

                [
                    {
                        "6": {"value": "Some text"},
                        "7": {"value": 42},
                        "8": {"value": "2024-01-15T08:00:00Z"},
                    }
                ]

        Returns:
            A dict with keys: processed, created, updated, unchanged,
            errored, errored_details.

        Raises:
            QuickbaseAPIError: If the API request fails entirely (4xx/5xx).
        """
        resp_json, resp_code = self._rm.post(
            "records",
            data={"to": table_id, "data": data},
        )
        if resp_code not in (200, 207):
            raise QuickbaseAPIError(resp_code, resp_json)

        metadata = resp_json["metadata"]
        line_errors = metadata.get("lineErrors", {})

        result = {
            "processed": metadata["totalNumberOfRecordsProcessed"] - len(line_errors),
            "created": len(metadata["createdRecordIds"]),
            "updated": len(metadata["updatedRecordIds"]),
            "unchanged": len(metadata["unchangedRecordIds"]),
            "errored": len(line_errors),
            "errored_details": line_errors,
        }

        if line_errors:
            logger.warning(
                "Upsert to table %s had %d line errors: %s",
                table_id,
                len(line_errors),
                line_errors,
            )

        return result

    def delete_records(self, table_id: str, where: str) -> int:
        """Delete records from a table.

        Args:
            table_id: The ID of the table.
            where: A Quickbase query string (e.g., "{6.EX.'123'}").

        Returns:
            The number of records deleted.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.delete(
            "records",
            data={"from": table_id, "where": where},
        )
        self._require_success(resp_json, resp_code, f"delete records from table '{table_id}'")
        deleted = resp_json["numberDeleted"]
        logger.info("Deleted %d records from table %s", deleted, table_id)
        return deleted

    def query_for_data(
        self,
        table_id: str,
        select: list[int] = None,
        where: str = None,
        sort_by: list[dict] = None,
        group_by: list[dict] = None,
        options: dict = None,
    ) -> dict:
        """Query for record data from a table.

        Args:
            table_id: The ID of the table to query.
            select: List of field IDs to return. If omitted, returns
                fields from the default report.
            where: A Quickbase query string (e.g., "{12.EX.'VPF'}").
            sort_by: Sort order, e.g., [{"fieldId": 6, "order": "ASC"}].
            group_by: Grouping, e.g., [{"fieldId": 6, "grouping": "equal-values"}].
            options: Additional options, e.g.,
                {"skip": 0, "top": 100, "compareWithAppLocalTime": False}.

        Returns:
            The query response including data and metadata.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        body = {"from": table_id}
        if select is not None:
            body["select"] = select
        if where is not None:
            body["where"] = where
        if sort_by is not None:
            body["sortBy"] = sort_by
        if group_by is not None:
            body["groupBy"] = group_by
        if options is not None:
            body["options"] = options

        resp_json, resp_code = self._rm.post("records/query", data=body)
        self._require_success(resp_json, resp_code, f"query table '{table_id}'")
        return resp_json
