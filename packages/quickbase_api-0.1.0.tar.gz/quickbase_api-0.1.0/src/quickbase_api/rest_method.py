"""Client for Quickbase's RESTful JSON API."""

from __future__ import annotations

import logging

from quickbase_api.session import create_session

logger = logging.getLogger(__name__)

BASE_URL = "https://api.quickbase.com/v1"


class RestMethod:
    """Low-level HTTP client for the Quickbase REST API.

    Handles URL construction, request execution, and response parsing
    for all REST API endpoints.
    """

    def __init__(self, realm: str, user_token: str):
        self.session = create_session(realm, user_token)

    def make_request(
        self,
        method: str,
        endpoint: str,
        params: dict = None,
        data: dict = None,
    ) -> tuple[dict, int]:
        """Execute an HTTP request against the Quickbase REST API.

        Args:
            method: HTTP method (GET, POST, DELETE).
            endpoint: API endpoint path (appended to base URL).
            params: Optional query string parameters.
            data: Optional JSON request body.

        Returns:
            A tuple of (response_body, status_code).
        """
        url = f"{BASE_URL}/{endpoint}"
        response = self.session.request(
            method=method,
            url=url,
            params=params,
            json=data,
        )
        try:
            body = response.json()
        except ValueError:
            body = {"raw_response": response.text}

        if response.status_code >= 400:
            logger.error(
                "REST API error %d on %s %s: %s",
                response.status_code,
                method,
                endpoint,
                body,
            )

        return body, response.status_code

    def get(self, endpoint: str, params: dict = None) -> tuple[dict, int]:
        """Send a GET request."""
        return self.make_request("GET", endpoint, params=params)

    def post(self, endpoint: str, params: dict = None, data: dict = None) -> tuple[dict, int]:
        """Send a POST request."""
        return self.make_request("POST", endpoint, params=params, data=data)

    def delete(self, endpoint: str, params: dict = None, data: dict = None) -> tuple[dict, int]:
        """Send a DELETE request."""
        return self.make_request("DELETE", endpoint, params=params, data=data)
