"""Tests for QuickbaseClient high-level API methods."""

import pytest
from quickbase_api.exceptions import QuickbaseAPIError, QuickbaseNotFoundError

BASE_URL = "https://api.quickbase.com/v1"
REALM = "testrealm.quickbase.com"


# ── App Tests ────────────────────────────────────────────────────────────


class TestCreateApp:
    def test_create_app_success(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps",
            json={"id": "abc123", "name": "Test App"},
            status=200,
        )
        app_id = client.create_app("Test App")
        assert app_id == "abc123"

    def test_create_app_with_optional_params(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps",
            json={"id": "abc123", "name": "Test App"},
            status=200,
        )
        app_id = client.create_app(
            "Test App",
            description="A test",
            assign_token=True,
        )
        assert app_id == "abc123"

    def test_create_app_failure_raises(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps",
            json={"message": "Unauthorized"},
            status=401,
        )
        with pytest.raises(QuickbaseAPIError) as exc_info:
            client.create_app("Test App")
        assert exc_info.value.status_code == 401


class TestDeleteApp:
    def test_delete_app_success(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/apps/abc123",
            json={"deletedAppId": "abc123"},
            status=200,
        )
        result = client.delete_app("Test App", "abc123")
        assert result["deletedAppId"] == "abc123"

    def test_delete_app_failure_raises(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/apps/abc123",
            json={"message": "Not found"},
            status=404,
        )
        with pytest.raises(QuickbaseAPIError):
            client.delete_app("Test App", "abc123")


class TestGetApp:
    def test_get_app_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/apps/abc123",
            json={"id": "abc123", "name": "Test App"},
            status=200,
        )
        app = client.get_app("abc123")
        assert app["name"] == "Test App"

    def test_get_app_failure_raises(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/apps/invalid",
            json={"message": "Not found"},
            status=404,
        )
        with pytest.raises(QuickbaseAPIError):
            client.get_app("invalid")


# ── Table Tests ──────────────────────────────────────────────────────────


class TestCreateTable:
    def test_create_table_success(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/tables",
            json={"id": "tbl1", "name": "Customers"},
            status=200,
        )
        table_id = client.create_table("abc123", {"name": "Customers"})
        assert table_id == "tbl1"


class TestGetTables:
    def test_get_tables_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/tables",
            json=[
                {"id": "tbl1", "name": "Customers"},
                {"id": "tbl2", "name": "Orders"},
            ],
            status=200,
        )
        tables = client.get_tables("abc123")
        assert len(tables) == 2
        assert tables[0]["name"] == "Customers"


class TestGetTableId:
    def test_get_table_id_found(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/tables",
            json=[
                {"id": "tbl1", "name": "Customers"},
                {"id": "tbl2", "name": "Orders"},
            ],
            status=200,
        )
        table_id = client.get_table_id("abc123", "Orders")
        assert table_id == "tbl2"

    def test_get_table_id_not_found(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/tables",
            json=[{"id": "tbl1", "name": "Customers"}],
            status=200,
        )
        with pytest.raises(QuickbaseNotFoundError):
            client.get_table_id("abc123", "Nonexistent")


class TestDeleteTable:
    def test_delete_table_success(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/tables/tbl1",
            json={"deletedTableId": "tbl1"},
            status=200,
        )
        result = client.delete_table("abc123", "tbl1")
        assert result["deletedTableId"] == "tbl1"


# ── Report Tests ─────────────────────────────────────────────────────────


class TestGetReports:
    def test_get_reports_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/reports",
            json=[{"id": "1", "name": "List All"}],
            status=200,
        )
        reports = client.get_reports("tbl1")
        assert len(reports) == 1


class TestGetReport:
    def test_get_report_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/reports/1",
            json={"id": "1", "name": "List All"},
            status=200,
        )
        report = client.get_report("tbl1", "1")
        assert report["name"] == "List All"


class TestRunReport:
    def test_run_report_success(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/reports/1/run",
            json={"data": [{"6": {"value": "test"}}], "metadata": {}},
            status=200,
        )
        result = client.run_report("tbl1", "1")
        assert "data" in result

    def test_run_report_with_pagination(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/reports/1/run",
            json={"data": [], "metadata": {}},
            status=200,
        )
        client.run_report("tbl1", "1", skip=10, top=50)
        params = mock_api.calls[0].request.params
        assert params["skip"] == "10"
        assert params["top"] == "50"


# ── Field Tests ──────────────────────────────────────────────────────────


class TestCreateField:
    def test_create_field_success(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 6, "label": "Name", "fieldType": "text"},
            status=200,
        )
        result = client.create_field("tbl1", {"label": "Name", "fieldType": "text"})
        assert result["id"] == 6

    def test_create_field_failure_raises(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"message": "Invalid field type"},
            status=400,
        )
        with pytest.raises(QuickbaseAPIError):
            client.create_field("tbl1", {"label": "Bad", "fieldType": "invalid"})


class TestCreateFields:
    def test_create_fields_all_succeed(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 6, "label": "Name", "fieldType": "text"},
            status=200,
        )
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 7, "label": "Email", "fieldType": "email"},
            status=200,
        )
        results = client.create_fields(
            "tbl1",
            [
                {"label": "Name", "fieldType": "text"},
                {"label": "Email", "fieldType": "email"},
            ],
        )
        assert len(results["succeeded"]) == 2
        assert len(results["failed"]) == 0

    def test_create_fields_partial_failure(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 6, "label": "Name", "fieldType": "text"},
            status=200,
        )
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"message": "Invalid"},
            status=400,
        )
        results = client.create_fields(
            "tbl1",
            [
                {"label": "Name", "fieldType": "text"},
                {"label": "Bad", "fieldType": "invalid"},
            ],
        )
        assert len(results["succeeded"]) == 1
        assert len(results["failed"]) == 1


class TestGetTableFields:
    def test_get_table_fields_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/fields",
            json=[
                {"id": 6, "label": "Name"},
                {"id": 7, "label": "Email"},
            ],
            status=200,
        )
        fields = client.get_table_fields("tbl1")
        assert len(fields) == 2


class TestGetFieldId:
    def test_get_field_id_found(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/fields",
            json=[
                {"id": 6, "label": "Name"},
                {"id": 7, "label": "Email"},
            ],
            status=200,
        )
        field_id = client.get_field_id("tbl1", "Email")
        assert field_id == "7"

    def test_get_field_id_not_found(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/fields",
            json=[{"id": 6, "label": "Name"}],
            status=200,
        )
        with pytest.raises(QuickbaseNotFoundError):
            client.get_field_id("tbl1", "Nonexistent")


class TestGetFieldLabelIdMap:
    def test_builds_correct_mapping(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/fields",
            json=[
                {"id": 6, "label": "Name"},
                {"id": 7, "label": "Email"},
                {"id": 8, "label": "Age"},
            ],
            status=200,
        )
        field_map = client.get_field_label_id_map("tbl1")
        assert field_map == {"Name": "6", "Email": "7", "Age": "8"}


class TestGetKeyFieldId:
    def test_get_key_field_id_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/tables/tbl1",
            json={"id": "tbl1", "keyFieldId": 3},
            status=200,
        )
        key_field = client.get_key_field_id("abc123", "tbl1")
        assert key_field == "3"


class TestSetKeyField:
    def test_set_key_field_success(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/tbl1",
            json={"errcode": 0},
            status=200,
        )
        result = client.set_key_field("tbl1", "6")
        assert result is True

    def test_set_key_field_failure_raises(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/tbl1",
            json={"errcode": 1, "errtext": "Failed"},
            status=400,
        )
        with pytest.raises(QuickbaseAPIError):
            client.set_key_field("tbl1", "6")


class TestSetRequiredField:
    def test_set_required_field_success(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields/6",
            json={"id": 6, "required": True},
            status=200,
        )
        result = client.set_required_field("tbl1", "6")
        assert result is True


# ── Record Tests ─────────────────────────────────────────────────────────


class TestUpsertRecords:
    def test_upsert_all_created(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records",
            json={
                "metadata": {
                    "totalNumberOfRecordsProcessed": 2,
                    "createdRecordIds": [1, 2],
                    "updatedRecordIds": [],
                    "unchangedRecordIds": [],
                },
            },
            status=200,
        )
        result = client.upsert_records(
            "tbl1",
            [
                {"6": {"value": "Alice"}},
                {"6": {"value": "Bob"}},
            ],
        )
        assert result["created"] == 2
        assert result["updated"] == 0
        assert result["errored"] == 0

    def test_upsert_partial_success_207(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records",
            json={
                "metadata": {
                    "totalNumberOfRecordsProcessed": 3,
                    "createdRecordIds": [1, 2],
                    "updatedRecordIds": [],
                    "unchangedRecordIds": [],
                    "lineErrors": {"3": ["Invalid value for field 7"]},
                },
            },
            status=207,
        )
        result = client.upsert_records(
            "tbl1",
            [
                {"6": {"value": "Alice"}},
                {"6": {"value": "Bob"}},
                {"6": {"value": "Bad"}},
            ],
        )
        assert result["created"] == 2
        assert result["errored"] == 1
        assert "3" in result["errored_details"]

    def test_upsert_all_updated(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records",
            json={
                "metadata": {
                    "totalNumberOfRecordsProcessed": 2,
                    "createdRecordIds": [],
                    "updatedRecordIds": [1, 2],
                    "unchangedRecordIds": [],
                },
            },
            status=200,
        )
        result = client.upsert_records(
            "tbl1",
            [
                {"3": {"value": 1}, "6": {"value": "Updated Alice"}},
                {"3": {"value": 2}, "6": {"value": "Updated Bob"}},
            ],
        )
        assert result["updated"] == 2
        assert result["created"] == 0

    def test_upsert_failure_raises(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records",
            json={"message": "Unauthorized"},
            status=401,
        )
        with pytest.raises(QuickbaseAPIError):
            client.upsert_records("tbl1", [{"6": {"value": "test"}}])


class TestDeleteRecords:
    def test_delete_records_success(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/records",
            json={"numberDeleted": 5},
            status=200,
        )
        deleted = client.delete_records("tbl1", "{6.EX.'test'}")
        assert deleted == 5

    def test_delete_records_failure_raises(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/records",
            json={"message": "Invalid query"},
            status=400,
        )
        with pytest.raises(QuickbaseAPIError):
            client.delete_records("tbl1", "bad query")


class TestQueryForData:
    def test_query_minimal(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records/query",
            json={
                "data": [{"6": {"value": "Alice"}}],
                "fields": [{"id": 6, "label": "Name"}],
                "metadata": {"totalRecordCount": 1},
            },
            status=200,
        )
        result = client.query_for_data("tbl1")
        assert len(result["data"]) == 1

    def test_query_with_all_params(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records/query",
            json={"data": [], "fields": [], "metadata": {"totalRecordCount": 0}},
            status=200,
        )
        client.query_for_data(
            "tbl1",
            select=[6, 7],
            where="{6.EX.'test'}",
            sort_by=[{"fieldId": 6, "order": "ASC"}],
            group_by=[{"fieldId": 6, "grouping": "equal-values"}],
            options={"skip": 0, "top": 100},
        )
        import json

        body = json.loads(mock_api.calls[0].request.body)
        assert body["from"] == "tbl1"
        assert body["select"] == [6, 7]
        assert body["where"] == "{6.EX.'test'}"
        assert body["sortBy"] == [{"fieldId": 6, "order": "ASC"}]
        assert body["groupBy"] == [{"fieldId": 6, "grouping": "equal-values"}]
        assert body["options"] == {"skip": 0, "top": 100}

    def test_query_omits_none_params(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records/query",
            json={"data": [], "fields": [], "metadata": {}},
            status=200,
        )
        client.query_for_data("tbl1", select=[6])
        import json

        body = json.loads(mock_api.calls[0].request.body)
        assert body == {"from": "tbl1", "select": [6]}
        assert "where" not in body
        assert "sortBy" not in body

    def test_query_failure_raises(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records/query",
            json={"message": "Invalid query"},
            status=400,
        )
        with pytest.raises(QuickbaseAPIError):
            client.query_for_data("tbl1", where="bad")
