"""Tests for LegacyMethod HTTP client."""

REALM = "testrealm.quickbase.com"


class TestLegacyMethodPost:
    def test_post_success(self, mock_api, legacy):
        url = f"https://{REALM}/db/tbl1"
        mock_api.post(url, json={"errcode": 0}, status=200)

        body, status = legacy.post(url, params={"a": "API_SetKeyField", "fid": "6"})
        assert status == 200
        assert body["errcode"] == 0

    def test_post_passes_params(self, mock_api, legacy):
        url = f"https://{REALM}/db/tbl1"
        mock_api.post(url, json={"errcode": 0}, status=200)

        legacy.post(url, params={"a": "API_SetKeyField", "fid": "6"})
        assert mock_api.calls[0].request.params["a"] == "API_SetKeyField"
        assert mock_api.calls[0].request.params["fid"] == "6"


class TestLegacyMethodGet:
    def test_get_success(self, mock_api, legacy):
        url = f"https://{REALM}/db/main"
        mock_api.get(url, json={"data": "test"}, status=200)

        body, status = legacy.get(url)
        assert status == 200
        assert body["data"] == "test"


class TestLegacyMethodHeaders:
    def test_session_has_auth_headers(self, legacy):
        assert legacy.session.headers["QB-Realm-Hostname"] == REALM
        assert legacy.session.headers["Authorization"] == "QB-USER-TOKEN test-token-123"


class TestLegacyMethodErrorHandling:
    def test_non_json_response(self, mock_api, legacy):
        url = f"https://{REALM}/db/tbl1"
        mock_api.post(
            url,
            body="<?xml version='1.0'?><error>Something broke</error>",
            status=500,
            content_type="text/xml",
        )
        body, status = legacy.post(url)
        assert status == 500
        assert "raw_response" in body
