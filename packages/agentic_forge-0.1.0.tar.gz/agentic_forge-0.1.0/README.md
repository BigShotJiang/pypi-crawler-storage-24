# AgenticForge Python SDK

Blueprint engine for AI agents -- project architecture generation and code scaffolding.

## Install

```bash
pip install agentic-forge
```

## Usage

```python
from agentic_forge import ForgeEngine

fe = ForgeEngine("project.forge")
fe.create_blueprint("auth-service", template="microservice")
fe.generate("auth-service", output_dir="./generated")
```

Requires the `aforge` CLI binary on PATH. Install via:

```bash
curl -fsSL https://agentralabs.tech/install/forge | bash
```
