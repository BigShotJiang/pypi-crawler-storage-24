"""AgenticForge — Blueprint engine for AI agents.

Pure-Python SDK that wraps the ``aforge`` CLI binary via subprocess.
Zero required dependencies; only stdlib: subprocess, json, pathlib, dataclasses.
"""

from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

__version__ = "0.1.0"

logger = logging.getLogger(__name__)


class ForgeError(Exception):
    """Raised when an aforge CLI command fails."""


@dataclass
class ForgeEngine:
    """Interface to a ``.forge`` blueprint file.

    Parameters
    ----------
    path : str | Path
        Path to the ``.forge`` file. Created automatically on first write
        if it does not exist.
    binary : str
        Name or path of the ``aforge`` CLI binary.
    """

    path: str | Path
    binary: str = "aforge"
    _resolved_binary: Optional[str] = field(default=None, repr=False, init=False)

    def __post_init__(self) -> None:
        self.path = Path(self.path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_binary(self) -> str:
        if self._resolved_binary is not None:
            return self._resolved_binary

        import shutil

        found = shutil.which(self.binary)
        if found is None:
            raise ForgeError(
                f"Cannot find '{self.binary}' on PATH. "
                "Install AgenticForge: curl -fsSL https://agentralabs.tech/install/forge | bash"
            )
        self._resolved_binary = found
        return found

    def _run(self, *args: str, check: bool = True) -> str:
        """Execute an aforge CLI command and return stdout."""
        cmd = [self._find_binary(), "--file", str(self.path), *args]
        logger.debug("Running: %s", " ".join(cmd))
        result = subprocess.run(cmd, capture_output=True, text=True)
        if check and result.returncode != 0:
            raise ForgeError(
                f"aforge command failed (exit {result.returncode}): {result.stderr.strip()}"
            )
        return result.stdout.strip()

    def _run_json(self, *args: str) -> Any:
        """Execute a command and parse JSON output."""
        raw = self._run(*args, "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # Blueprint operations
    # ------------------------------------------------------------------

    def create_blueprint(
        self,
        name: str,
        *,
        template: Optional[str] = None,
    ) -> str:
        """Create a new blueprint. Returns the blueprint ID."""
        args = ["blueprint", "create", name]
        if template:
            args.extend(["--template", template])
        return self._run(*args)

    def generate(
        self,
        name: str,
        *,
        output_dir: Optional[str] = None,
    ) -> str:
        """Generate code from a blueprint. Returns generation summary."""
        args = ["generate", name]
        if output_dir:
            args.extend(["--output", output_dir])
        return self._run(*args)

    def list_blueprints(self) -> list[dict[str, Any]]:
        """List all blueprints."""
        raw = self._run("blueprint", "list", "--format", "json")
        return json.loads(raw) if raw else []

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Get forge engine statistics."""
        raw = self._run("stats", "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Explicit save (most operations auto-save)."""
        pass

    @property
    def exists(self) -> bool:
        """Whether the .forge file exists on disk."""
        return self.path.exists()
