# pyannotators-entityfishing

Annotator based on [entity-fishing](https://github.com/kermitt2/entity-fishing) for named entity recognition and disambiguation against Wikidata.

## Installation

```bash
pip install pyannotators-entityfishing
```

For noun-form filtering (optional):

```bash
pip install pyannotators-entityfishing[spacy]
python -m spacy download en_core_web_sm  # or other language models
```

## Usage

```python
from pymultirole_plugins.v1.schema import Document
from pyannotators_entityfishing.entityfishing import EntityFishingAnnotator, EntityFishingParameters

annotator = EntityFishingAnnotator()
parameters = EntityFishingParameters(
    default_label="ENTITY",
    minSelectorScore=0.3,
)

docs = annotator.annotate(
    [Document(text="Albert Einstein was born in Ulm.", metadata={"language": "en"})],
    parameters,
)

for ann in docs[0].annotations:
    print(f"{ann.start}:{ann.end} {ann.labelName} {ann.terms[0].identifier}")
```

## Development

Install test dependencies:

```bash
uv pip install -e ".[test]"
```

### Linting

```bash
uv run ruff check src/ tests/
uv run ruff format --check src/ tests/
```

### Testing

```bash
uv run pytest
```

### Coverage

```bash
uv run pytest --cov=src --cov-report=term-missing
```

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
