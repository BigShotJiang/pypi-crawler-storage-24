#!/usr/bin/env python3
"""
Test script for IDE Memory MCP configuration system.
"""

import sys
from pathlib import Path

# Add src to path so we can import our modules
sys.path.insert(0, str(Path(__file__).parent / "src"))

from ide_memory_mcp.config import Config


def test_config():
    """Test the configuration system."""
    print("Testing IDE Memory MCP Configuration System")
    print("=" * 40)

    # Create a config instance
    config = Config()

    # Test getting default values
    print("Default configuration values:")
    print(f"  Auto-initialize: {config.should_auto_initialize()}")
    print(f"  Scan depth: {config.get('scan_depth')}")
    print(f"  Max files: {config.get('max_files')}")
    print(f"  Preserve annotations: {config.get('preserve_annotations')}")

    # Test getting ignore lists
    ignored_dirs = config.get_ignored_dirs()
    ignored_extensions = config.get_ignored_extensions()
    print(f"  Ignored directories: {len(ignored_dirs)} items")
    print(f"  Ignored extensions: {len(ignored_extensions)} items")

    # Test setting a value
    print("\nSetting auto_initialize to True...")
    config.set("auto_initialize", True)
    print(f"  Auto-initialize after setting: {config.should_auto_initialize()}")

    # Reset to default
    print("\nResetting to default...")
    config.set("auto_initialize", config.defaults["auto_initialize"])
    print(f"  Auto-initialize after reset: {config.should_auto_initialize()}")

    print("\nConfiguration system test completed successfully!")


if __name__ == "__main__":
    test_config()