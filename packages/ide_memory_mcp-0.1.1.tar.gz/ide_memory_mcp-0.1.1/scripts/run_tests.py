#!/usr/bin/env python3
"""Test runner script."""

import subprocess
import sys
from pathlib import Path


def run_tests():
    """Run the test suite."""
    # Run pytest with coverage
    result = subprocess.run([
        "pytest",
        "--cov=src/ide_memory_mcp",
        "--cov-report=html",
        "--cov-report=term-missing",
        "tests/",
        "-v"
    ])

    return result.returncode


if __name__ == "__main__":
    sys.exit(run_tests())