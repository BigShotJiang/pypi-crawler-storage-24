#!/usr/bin/env python3
"""
CLI management tool for IDE Memory MCP.

Provides command-line interface for managing projects and memory.
"""

import argparse
import sys
from pathlib import Path

# Add src to path so we can import our modules
sys.path.insert(0, str(Path(__file__).parent / "src"))

from ide_memory_mcp.storage import MemoryStorage
from ide_memory_mcp.models import MEMORY_SECTIONS


def list_projects(args):
    """List all registered projects."""
    storage = MemoryStorage()
    projects = storage.list_projects()

    if not projects:
        print("No projects registered yet.")
        return

    print(f"{'Name':<30} {'ID':<15} {'Path':<30} {'Last Updated'}")
    print("-" * 90)

    for project in sorted(projects, key=lambda p: p.updated_at, reverse=True):
        name = project.project_name[:29] if len(project.project_name) > 29 else project.project_name
        path = project.project_path[:29] if len(project.project_path) > 29 else project.project_path
        print(f"{name:<30} {project.project_id:<15} {path:<30} {project.updated_at}")


def show_project(args):
    """Show details for a specific project."""
    storage = MemoryStorage()
    meta = storage.resolve_project(args.project_identifier)

    if not meta:
        print(f"Project '{args.project_identifier}' not found.")
        return

    print(f"Project Details")
    print("=" * 50)
    print(f"Name: {meta.project_name}")
    print(f"ID: {meta.project_id}")
    print(f"Path: {meta.project_path}")
    print(f"Git Remote: {meta.git_remote_url or 'N/A'}")
    print(f"Created: {meta.created_at}")
    print(f"Last Updated: {meta.updated_at}")
    print()

    print("Memory Sections:")
    print("-" * 20)
    all_sections = storage.get_all_section_names(meta.project_id)

    for section in all_sections:
        content = storage.get_section(meta.project_id, section)
        is_empty = len(content.strip()) < 50
        status = "Empty" if is_empty else f"{len(content)} chars"
        print(f"  {section}: {status}")


def delete_project(args):
    """Delete a project."""
    storage = MemoryStorage()
    meta = storage.resolve_project(args.project_identifier)

    if not meta:
        print(f"Project '{args.project_identifier}' not found.")
        return

    if not args.force:
        response = input(f"Are you sure you want to delete project '{meta.project_name}'? [y/N] ")
        if response.lower() != 'y':
            print("Deletion cancelled.")
            return

    success = storage.delete_project(meta.project_id)
    if success:
        print(f"Deleted project '{meta.project_name}'.")
    else:
        print(f"Failed to delete project '{meta.project_name}'.")


def inspect_section(args):
    """Inspect a specific section of a project."""
    storage = MemoryStorage()
    meta = storage.resolve_project(args.project_identifier)

    if not meta:
        print(f"Project '{args.project_identifier}' not found.")
        return

    content = storage.get_section(meta.project_id, args.section)
    if not content.strip():
        print(f"Section '{args.section}' is empty.")
        return

    print(f"Section: {args.section}")
    print("=" * 40)
    print(content)


def search_memory(args):
    """Search memory across all sections of a project."""
    storage = MemoryStorage()
    meta = storage.resolve_project(args.project_identifier)

    if not meta:
        print(f"Project '{args.project_identifier}' not found.")
        return

    results = storage.search_memory(meta.project_id, args.query)
    if not results:
        print(f"No matches found for '{args.query}'.")
        return

    print(f"Search Results for '{args.query}'")
    print("=" * 40)

    for section, snippets in results.items():
        print(f"\n[{section}]")
        for snippet in snippets:
            print(f"  {snippet}")


def main():
    """Main entry point for the CLI tool."""
    parser = argparse.ArgumentParser(description="IDE Memory MCP Management Tool")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # List projects command
    list_parser = subparsers.add_parser('list', help='List all registered projects')
    list_parser.set_defaults(func=list_projects)

    # Show project details command
    show_parser = subparsers.add_parser('show', help='Show details for a project')
    show_parser.add_argument('project_identifier', help='Project ID or path')
    show_parser.set_defaults(func=show_project)

    # Delete project command
    delete_parser = subparsers.add_parser('delete', help='Delete a project')
    delete_parser.add_argument('project_identifier', help='Project ID or path')
    delete_parser.add_argument('-f', '--force', action='store_true', help='Force deletion without confirmation')
    delete_parser.set_defaults(func=delete_project)

    # Inspect section command
    inspect_parser = subparsers.add_parser('inspect', help='Inspect a section of a project')
    inspect_parser.add_argument('project_identifier', help='Project ID or path')
    inspect_parser.add_argument('section', help='Section name to inspect',
                               choices=MEMORY_SECTIONS + ['all'])
    inspect_parser.set_defaults(func=inspect_section)

    # Search command
    search_parser = subparsers.add_parser('search', help='Search memory for a query')
    search_parser.add_argument('project_identifier', help='Project ID or path')
    search_parser.add_argument('query', help='Search query')
    search_parser.set_defaults(func=search_memory)

    # Parse arguments
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    # Call the appropriate function
    try:
        args.func(args)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()