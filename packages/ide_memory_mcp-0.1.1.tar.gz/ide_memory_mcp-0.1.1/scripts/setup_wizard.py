#!/usr/bin/env python3
"""
Setup wizard for IDE Memory MCP.

This script guides users through the installation and configuration process.
"""

import json
import os
import platform
import sys
from pathlib import Path


def detect_ide_configs():
    """Detect existing IDE configuration files."""
    configs = {}

    # Define config paths for different operating systems
    if platform.system() == "Windows":
        appdata = Path(os.environ.get("APPDATA", ""))
        configs["Antigravity"] = appdata / "Antigravity" / "mcp_config.json"
    else:
        # Unix-like systems
        home = Path.home()
        configs["Antigravity"] = home / ".config" / "antigravity" / "mcp_config.json"

    # Common locations for other IDEs
    cwd = Path.cwd()
    configs["Claude Desktop"] = cwd / "claude_desktop_config.json"
    configs["Cursor"] = cwd / ".cursor" / "mcp.json"
    configs["VS Code"] = cwd / ".vscode" / "mcp.json"

    return configs


def find_available_ides(configs):
    """Find which IDEs are available based on existing config files."""
    available = []
    for ide, config_path in configs.items():
        if config_path.parent.exists():
            available.append(ide)
    return available


def create_mcp_config(install_method="global"):
    """Create MCP configuration for IDE."""
    config = {
        "mcpServers": {
            "ide-memory": {
                "command": "ide-memory-mcp"
            }
        }
    }

    if install_method == "local":
        # Find the project root
        project_root = Path(__file__).parent.parent.absolute()
        config["mcpServers"]["ide-memory"] = {
            "command": "uv",
            "args": ["--directory", str(project_root), "run", "ide-memory-mcp"]
        }

    return config


def write_config(config, config_path):
    """Write configuration to file."""
    config_path.parent.mkdir(parents=True, exist_ok=True)

    # If file exists, merge configurations
    if config_path.exists():
        try:
            with open(config_path, 'r') as f:
                existing = json.load(f)

            # Merge servers
            if "mcpServers" in existing:
                existing["mcpServers"].update(config["mcpServers"])
            else:
                existing["mcpServers"] = config["mcpServers"]

            config = existing
        except json.JSONDecodeError:
            # If file is corrupted, overwrite
            pass

    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)


def setup_wizard():
    """Run the interactive setup wizard."""
    print(" IDE Memory MCP Setup Wizard ")
    print("=" * 30)
    print()

    # Check if already installed
    try:
        import ide_memory_mcp
        print("✓ IDE Memory MCP is already installed")
    except ImportError:
        print("ℹ IDE Memory MCP not found in current environment")
        print("  Please install it first with: pip install ide-memory-mcp")
        print("  Or for development: uv sync")
        print()

    # Detect IDEs
    configs = detect_ide_configs()
    available_ides = find_available_ides(configs)

    if available_ides:
        print("Detected IDE configuration directories:")
        for ide in available_ides:
            print(f"  - {ide}: {configs[ide].parent}")
        print()

        # Ask user which IDEs to configure
        print("Which IDEs would you like to configure? (Press Enter for all)")
        selection = input("> ").strip()

        if selection:
            selected_ides = [ide.strip() for ide in selection.split(",")]
        else:
            selected_ides = available_ides

        # Ask installation method
        print("\nHow did you install IDE Memory MCP?")
        print("1. Global installation (pip install ide-memory-mcp)")
        print("2. Local installation from source")

        method_choice = input("Enter choice (1 or 2) [1]: ").strip() or "1"
        install_method = "global" if method_choice == "1" else "local"

        # Create and write configurations
        config = create_mcp_config(install_method)

        for ide in selected_ides:
            if ide in configs:
                write_config(config, configs[ide])
                print(f"✓ Configured {ide}")

        print("\n🎉 Setup complete!")
        print("Restart your IDE(s) to enable IDE Memory MCP.")
    else:
        print("No IDE configuration directories detected.")
        print("Please run this wizard from your project directory or")
        print("manually create the configuration files.")


def main():
    """Main entry point for the setup wizard."""
    try:
        setup_wizard()
    except KeyboardInterrupt:
        print("\n\nSetup cancelled.")
        sys.exit(0)
    except Exception as e:
        print(f"\n\nError during setup: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()