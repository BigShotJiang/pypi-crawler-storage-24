"""
Web dashboard for IDE Memory MCP.

Provides a web interface for viewing and managing projects.
"""

from flask import Flask, render_template, request, jsonify
import os
import sys
from pathlib import Path

# Add src to path so we can import our modules
sys.path.insert(0, str(Path(__file__).parent / "src"))

from ide_memory_mcp.storage import MemoryStorage
from ide_memory_mcp.models import MEMORY_SECTIONS


def create_app():
    """Create the Flask app."""
    app = Flask(__name__)
    storage = MemoryStorage()

    @app.route('/')
    def index():
        """Main dashboard page."""
        projects = storage.list_projects()
        return render_template('index.html', projects=projects)

    @app.route('/project/<project_id>')
    def project_detail(project_id):
        """Project detail page."""
        meta = storage.get_project(project_id)
        if not meta:
            return "Project not found", 404

        # Get all sections
        sections = {}
        for section in storage.get_all_section_names(project_id):
            content = storage.get_section(project_id, section)
            sections[section] = content

        return render_template('project.html', project=meta, sections=sections)

    @app.route('/api/projects')
    def api_projects():
        """API endpoint for projects list."""
        projects = storage.list_projects()
        return jsonify([{
            'project_id': p.project_id,
            'project_name': p.project_name,
            'project_path': p.project_path,
            'git_remote_url': p.git_remote_url,
            'created_at': p.created_at,
            'updated_at': p.updated_at
        } for p in projects])

    @app.route('/api/project/<project_id>')
    def api_project_detail(project_id):
        """API endpoint for project detail."""
        meta = storage.get_project(project_id)
        if not meta:
            return jsonify({'error': 'Project not found'}), 404

        # Get all sections
        sections = {}
        for section in storage.get_all_section_names(project_id):
            content = storage.get_section(project_id, section)
            sections[section] = content

        return jsonify({
            'project': {
                'project_id': meta.project_id,
                'project_name': meta.project_name,
                'project_path': meta.project_path,
                'git_remote_url': meta.git_remote_url,
                'created_at': meta.created_at,
                'updated_at': meta.updated_at
            },
            'sections': sections
        })

    @app.route('/api/project/<project_id>/delete', methods=['POST'])
    def api_delete_project(project_id):
        """API endpoint to delete a project."""
        success = storage.delete_project(project_id)
        return jsonify({'success': success})

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='127.0.0.1', port=5000)