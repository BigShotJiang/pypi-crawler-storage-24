# Testing Guide

This guide will help you test all the features implemented in the IDE Memory MCP project.

## Prerequisites

Before testing, ensure you have:

1. Python 3.11 or higher installed
2. [uv](https://docs.astral.sh/uv/) package manager installed
3. A test project directory to work with

## Setup for Testing

1. Clone the repository:
   ```bash
   git clone https://github.com/prasanna-pmpeople/IDE-Memory-MCP.git
   cd IDE-Memory-MCP
   ```

2. Install dependencies:
   ```bash
   uv sync
   ```

## Testing Individual Components

### 1. Configuration System

Test the configuration system:

```bash
uv run scripts/test_config.py
```

Expected output:
```
Testing IDE Memory MCP Configuration System
========================================
Default configuration values:
  Auto-initialize: False
  Scan depth: 4
  Max files: 200
  Preserve annotations: True
  Ignored directories: 22 items
  Ignored extensions: 31 items

Setting auto_initialize to True...
  Auto-initialize after setting: True

Resetting to default...
  Auto-initialize after reset: False

✅ Configuration system test completed successfully!
```

### 2. Core Server Functionality

Test the server with the MCP inspector:

```bash
uv run mcp dev src/ide_memory_mcp/server.py
```

In the MCP inspector, try the following commands:

1. Initialize a project:
   ```
   init_project("/path/to/your/test/project", "Test Project")
   ```

2. Scan project structure:
   ```
   scan_project_structure("/path/to/your/test/project")
   ```

3. Write memory:
   ```
   write_memory("/path/to/your/test/project", {"overview": "# Test Project\n\nThis is a test project."})
   ```

4. Read memory:
   ```
   read_memory("/path/to/your/test/project")
   ```

### 3. CLI Management Tool

Test the CLI management tool:

```bash
# List projects
uv run ide-memory-cli list

# Show project details (use actual project ID from list command)
uv run ide-memory-cli show <project-id>

# Search memory
uv run ide-memory-cli search <project-id> "test"

# Inspect a section
uv run ide-memory-cli inspect <project-id> overview
```

### 4. Setup Wizard

Test the setup wizard:

```bash
uv run ide-memory-setup
```

Follow the interactive prompts to configure your IDE.

### 5. Web Dashboard

Test the web dashboard:

```bash
uv run ide-memory-dashboard
```

Then open http://127.0.0.1:5000 in your browser to view the dashboard.

## Automated Testing

Run the automated test suite:

```bash
uv run pytest tests/ -v
```

Expected output should show all tests passing:
```
========================= test session starts =========================
...
tests/test_storage.py::test_normalize_path PASSED
tests/test_storage.py::test_normalize_git_url PASSED
tests/test_storage.py::TestMemoryStorage::test_init_project_creates_files PASSED
tests/test_storage.py::TestMemoryStorage::test_update_and_get_section PASSED
tests/test_storage.py::TestMemoryStorage::test_search_memory PASSED
tests/test_server.py::TestServerFunctions::test_is_valid_section_name PASSED
========================= X passed in X.XXs =========================
```

## Integration Testing

### Test Auto-initialization

1. Create a new test project directory:
   ```bash
   mkdir -p ~/test-ide-memory-project
   cd ~/test-ide-memory-project
   echo "# Test Project" > README.md
   mkdir src tests
   ```

2. Initialize with auto-initialization:
   ```bash
   uv run mcp dev ../IDE-Memory-MCP/src/ide_memory_mcp/server.py
   ```

3. In the MCP inspector, run:
   ```
   init_project("~/test-ide-memory-project", "Test Project", "", true)
   ```

4. Verify that the project was auto-initialized with structure scanning and basic overview.

### Test Cross-IDE Compatibility

If you have multiple IDEs installed:

1. Configure each IDE with the MCP configuration as documented in INSTALL.md
2. Open the same test project in different IDEs
3. Verify that the memory is shared across IDEs

## Testing with Different Project Types

Test with various project types:

1. **Git repository**:
   ```bash
   mkdir ~/test-git-project
   cd ~/test-git-project
   git init
   echo "# Git Test" > README.md
   ```

2. **Node.js project**:
   ```bash
   mkdir ~/test-node-project
   cd ~/test-node-project
   echo '{"name": "test-node-project"}' > package.json
   mkdir src
   ```

3. **Python project**:
   ```bash
   mkdir ~/test-python-project
   cd ~/test-python-project
   echo "print('hello')" > main.py
   ```

For each project type, test:
- Project initialization
- Structure scanning
- Memory reading/writing
- Cross-IDE compatibility

## Troubleshooting

### Common Issues

1. **Import errors**: Ensure you're running commands from the project root directory
2. **Permission errors**: Make sure the `~/.ide-memory` directory is writable
3. **Configuration not loading**: Check that `~/.ide-memory/config.json` is valid JSON

### Debugging Tips

1. Enable verbose logging by setting the logging level:
   ```bash
   export PYTHON_LOG_LEVEL=DEBUG
   uv run ide-memory-mcp
   ```

2. Check the memory storage directory:
   ```bash
   ls -la ~/.ide-memory/projects/
   ```

3. Validate configuration file:
   ```bash
   cat ~/.ide-memory/config.json | python -m json.tool
   ```

## Performance Testing

For large projects, test:

1. Directory scanning performance:
   ```bash
   time uv run mcp dev src/ide_memory_mcp/server.py
   # Then scan a large project directory
   ```

2. Memory usage with many projects:
   ```bash
   # Create multiple test projects and check memory usage
   ```

## Security Testing

Verify that:

1. Only authorized paths can be accessed
2. No sensitive information is exposed
3. Configuration files are properly secured

## Cleanup After Testing

To clean up test data:

```bash
# Remove test projects
rm -rf ~/test-*-project

# Clear IDE Memory storage
rm -rf ~/.ide-memory/projects/*

# Reset configuration
rm -f ~/.ide-memory/config.json
```

This testing guide covers all the major features implemented in the IDE Memory MCP project. Following these steps will help ensure that all components work correctly and integrate well together.