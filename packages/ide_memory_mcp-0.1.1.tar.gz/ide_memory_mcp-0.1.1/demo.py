#!/usr/bin/env python3
"""
Demo script showcasing all IDE Memory MCP features.
"""

import sys
import os
import tempfile
from pathlib import Path

# Add src to path so we can import our modules
sys.path.insert(0, str(Path(__file__).parent / "src"))

from ide_memory_mcp.config import Config
from ide_memory_mcp.storage import MemoryStorage


def demo_features():
    """Demonstrate all IDE Memory MCP features."""
    print("IDE Memory MCP Feature Demo")
    print("=" * 40)

    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        test_project_path = Path(temp_dir) / "test_project"
        test_project_path.mkdir()

        # Create some test files
        (test_project_path / "README.md").write_text("# Test Project\n\nThis is a test project.")
        (test_project_path / "main.py").write_text('print("Hello, World!")')
        (test_project_path / "utils.py").write_text('def utility():\n    return "utility"')

        # Initialize storage
        storage = MemoryStorage()

        print("\n1. Configuration System")
        print("-" * 20)
        config = Config()
        print(f"   Auto-initialize: {config.should_auto_initialize()}")
        print(f"   Scan depth: {config.get('scan_depth')}")
        print(f"   Ignored dirs count: {len(config.get_ignored_dirs())}")

        print("\n2. Project Initialization")
        print("-" * 20)
        meta, is_new = storage.init_project(
            str(test_project_path),
            "Demo Project"
        )
        print(f"   Project ID: {meta.project_id}")
        print(f"   Is new project: {is_new}")
        print(f"   Project name: {meta.project_name}")

        print("\n3. Directory Scanning")
        print("-" * 20)
        # Import scan function directly
        from ide_memory_mcp.storage import scan_directory_tree

        tree = scan_directory_tree(str(test_project_path))
        storage.update_section(meta.project_id, "structure", tree)
        print(f"   Directory tree scanned ({len(tree)} chars)")

        print("\n4. Memory Writing")
        print("-" * 20)
        overview_content = """# Demo Project Overview

This is a demonstration project for IDE Memory MCP.

## Features Demonstrated
- Configuration system
- Project initialization
- Directory scanning
- Memory writing and reading
"""

        storage.update_section(meta.project_id, "overview", overview_content)
        print("   Overview section written")

        decisions_content = """# Architectural Decisions

## Decision: Test Framework
- Chosen: Built-in unittest
- Reason: Simplicity and no external dependencies
"""

        storage.update_section(meta.project_id, "decisions", decisions_content)
        print("   Decisions section written")

        print("\n5. Memory Reading")
        print("-" * 20)
        overview = storage.get_section(meta.project_id, "overview")
        print(f"   Overview length: {len(overview)} chars")

        decisions = storage.get_section(meta.project_id, "decisions")
        print(f"   Decisions length: {len(decisions)} chars")

        print("\n6. Search Functionality")
        print("-" * 20)
        search_results = storage.search_memory(meta.project_id, "demonstration")
        if search_results:
            print(f"   Found 'demonstration' in {list(search_results.keys())}")
        else:
            print("   No search results found")

        search_results2 = storage.search_memory(meta.project_id, "Decision")
        if search_results2:
            print(f"   Found 'Decision' in {list(search_results2.keys())}")

        print("\n7. History Tracking")
        print("-" * 20)
        # Update section again to create history
        updated_overview = overview_content + "\n## Additional Info\n\nMore details here."
        storage.update_section(meta.project_id, "overview", updated_overview)

        history = storage.get_section_history(meta.project_id, "overview")
        print(f"   History snapshots: {len(history)}")

        print("\n8. Project Listing")
        print("-" * 20)
        projects = storage.list_projects()
        print(f"   Total projects: {len(projects)}")
        for project in projects:
            if project.project_id == meta.project_id:
                print(f"   Current project: {project.project_name}")

        print("\n9. Section Management")
        print("-" * 20)
        all_sections = storage.get_all_section_names(meta.project_id)
        print(f"   Available sections: {all_sections}")

        # Add a custom section
        storage.update_section(meta.project_id, "custom_notes", "# Custom Notes\n\nThese are custom notes.")
        all_sections_after = storage.get_all_section_names(meta.project_id)
        print(f"   Sections after custom add: {all_sections_after}")

        print("\n10. Append Functionality")
        print("-" * 20)
        storage.append_to_section(meta.project_id, "progress", "Completed initial setup", "Setup Phase")
        storage.append_to_section(meta.project_id, "progress", "Added configuration system", "Configuration")
        progress_content = storage.get_section(meta.project_id, "progress")
        print(f"   Progress section length: {len(progress_content)} chars")

    print("\n" + "=" * 40)
    print("All IDE Memory MCP features demonstrated successfully!")


if __name__ == "__main__":
    demo_features()