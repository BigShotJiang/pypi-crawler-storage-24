"""
Configuration system for IDE Memory MCP.

Handles user preferences and default settings.
"""

import json
import os
from pathlib import Path
from typing import Dict, Any


class Config:
    """Configuration manager for IDE Memory MCP."""

    def __init__(self, config_path: Path = None):
        """Initialize the configuration manager."""
        if config_path is None:
            # Default config location: ~/.ide-memory/config.json
            self.config_path = Path.home() / ".ide-memory" / "config.json"
        else:
            self.config_path = config_path

        # Default configuration values
        self.defaults = {
            "auto_initialize": False,
            "scan_depth": 4,
            "max_files": 200,
            "preserve_annotations": True,
            "default_sections": [
                "overview",
                "structure",
                "decisions",
                "active_context",
                "progress"
            ],
            "ignored_dirs": [
                ".git", ".svn", ".hg",
                "node_modules", ".node_modules",
                "__pycache__", ".pytest_cache", ".mypy_cache",
                ".venv", "venv", "env", ".env",
                ".tox", ".nox",
                "dist", "build", ".eggs",
                ".next", ".nuxt", ".output",
                ".idea", ".vscode", ".vs",
                "vendor", "target",
                ".terraform",
                ".history"
            ],
            "ignored_extensions": [
                ".pyc", ".pyo", ".class", ".o", ".so", ".dll", ".exe",
                ".lock", ".sum",
                ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".webp",
                ".woff", ".woff2", ".ttf", ".eot",
                ".mp3", ".mp4", ".avi", ".mov",
                ".zip", ".tar", ".gz", ".rar",
                ".db", ".sqlite", ".sqlite3"
            ]
        }

        # Load existing configuration or create default
        self.config = self.load_config()

    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file or return defaults."""
        # Create config directory if it doesn't exist
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing config or create default
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                    # Merge with defaults to ensure all keys exist
                    merged = self.defaults.copy()
                    merged.update(config)
                    return merged
            except (json.JSONDecodeError, IOError):
                # If file is corrupted, return defaults
                return self.defaults
        else:
            # Create default config file
            self.save_config(self.defaults)
            return self.defaults

    def save_config(self, config: Dict[str, Any]) -> None:
        """Save configuration to file."""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump(config, f, indent=2)

    def get(self, key: str, default: Any = None) -> Any:
        """Get a configuration value."""
        return self.config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set a configuration value."""
        self.config[key] = value
        self.save_config(self.config)

    def get_ignored_dirs(self) -> list:
        """Get list of directories to ignore during scanning."""
        return self.config.get("ignored_dirs", self.defaults["ignored_dirs"])

    def get_ignored_extensions(self) -> list:
        """Get list of file extensions to ignore during scanning."""
        return self.config.get("ignored_extensions", self.defaults["ignored_extensions"])

    def should_auto_initialize(self) -> bool:
        """Check if projects should be auto-initialized."""
        return self.config.get("auto_initialize", self.defaults["auto_initialize"])

    def get_scan_settings(self) -> Dict[str, Any]:
        """Get directory scanning settings."""
        return {
            "depth": self.config.get("scan_depth", self.defaults["scan_depth"]),
            "max_files": self.config.get("max_files", self.defaults["max_files"]),
            "preserve_annotations": self.config.get("preserve_annotations", self.defaults["preserve_annotations"])
        }


# Global configuration instance
_config = None


def get_config() -> Config:
    """Get the global configuration instance."""
    global _config
    if _config is None:
        _config = Config()
    return _config


def reload_config() -> Config:
    """Reload configuration from file."""
    global _config
    _config = Config()
    return _config