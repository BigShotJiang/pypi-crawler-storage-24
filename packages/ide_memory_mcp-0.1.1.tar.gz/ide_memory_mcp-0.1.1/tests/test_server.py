"""Tests for the server module."""

import pytest
from unittest.mock import AsyncMock, patch

from ide_memory_mcp.server import (
    init_project, read_memory, write_memory,
    scan_project_structure, manage_projects
)
from ide_memory_mcp.storage import MemoryStorage
from ide_memory_mcp.models import ProjectMeta


class TestServerFunctions:
    """Test the server functions."""

    @pytest.fixture
    def mock_storage(self):
        """Create a mock storage instance."""
        with patch("ide_memory_mcp.server.storage") as mock_storage:
            yield mock_storage

    def test_is_valid_section_name(self):
        """Test section name validation."""
        from ide_memory_mcp.storage import is_valid_section_name

        # Valid names
        assert is_valid_section_name("overview")
        assert is_valid_section_name("api_documentation")
        assert is_valid_section_name("test123")

        # Invalid names
        assert not is_valid_section_name("Overview")  # uppercase
        assert not is_valid_section_name("123test")   # starts with digit
        assert not is_valid_section_name("")          # empty
        assert not is_valid_section_name("test-test") # hyphen