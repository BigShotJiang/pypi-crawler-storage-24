"""Tests for the storage module."""

import os
import tempfile
from pathlib import Path

import pytest

from ide_memory_mcp.storage import MemoryStorage, _normalize_path, _normalize_git_url
from ide_memory_mcp.models import ProjectMeta


def test_normalize_path():
    """Test path normalization works correctly."""
    # Test Windows path normalization
    if os.name == "nt":
        assert _normalize_path("C:\\Users\\Test\\Project") == "c:/users/test/project"
        assert _normalize_path("C:/Users/Test/Project/") == "c:/users/test/project"
    else:
        # Test Unix path normalization
        assert _normalize_path("/home/user/project") == "/home/user/project"
        assert _normalize_path("/home/user/project/") == "/home/user/project"


def test_normalize_git_url():
    """Test git URL normalization."""
    # Test HTTPS URLs
    assert _normalize_git_url("https://github.com/user/repo.git") == "github.com/user/repo"
    assert _normalize_git_url("https://github.com/user/repo") == "github.com/user/repo"

    # Test SSH URLs
    assert _normalize_git_url("git@github.com:user/repo.git") == "github.com/user/repo"
    assert _normalize_git_url("git@github.com:user/repo") == "github.com/user/repo"

    # Test case insensitivity
    assert _normalize_git_url("HTTPS://GITHUB.COM/USER/REPO") == "github.com/user/repo"


class TestMemoryStorage:
    """Test the MemoryStorage class."""

    @pytest.fixture
    def temp_storage(self):
        """Create a temporary storage instance for testing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = MemoryStorage(Path(tmpdir))
            yield storage

    def test_init_project_creates_files(self, temp_storage):
        """Test that init_project creates the necessary files."""
        project_path = "/test/project"
        meta, is_new = temp_storage.init_project(project_path, "Test Project")

        assert is_new
        assert meta.project_name == "Test Project"
        assert meta.project_path == project_path

        # Check that project directory exists
        project_dir = temp_storage._project_dir(meta.project_id)
        assert project_dir.exists()

        # Check that meta.json exists
        meta_path = temp_storage._meta_path(meta.project_id)
        assert meta_path.exists()

        # Check that default sections exist
        from ide_memory_mcp.models import MEMORY_SECTIONS
        for section in MEMORY_SECTIONS:
            section_path = temp_storage._section_path(meta.project_id, section)
            assert section_path.exists()

    def test_update_and_get_section(self, temp_storage):
        """Test updating and retrieving a section."""
        project_path = "/test/project"
        meta, _ = temp_storage.init_project(project_path, "Test Project")

        # Update a section
        content = "# Test Content\n\nThis is a test."
        temp_storage.update_section(meta.project_id, "overview", content)

        # Retrieve the section
        retrieved = temp_storage.get_section(meta.project_id, "overview")
        assert retrieved == content

    def test_search_memory(self, temp_storage):
        """Test searching memory sections."""
        project_path = "/test/project"
        meta, _ = temp_storage.init_project(project_path, "Test Project")

        # Add some content
        content = "# Overview\n\nThis document contains important information about the project."
        temp_storage.update_section(meta.project_id, "overview", content)

        # Search for content
        results = temp_storage.search_memory(meta.project_id, "important")
        assert "overview" in results
        assert len(results["overview"]) > 0