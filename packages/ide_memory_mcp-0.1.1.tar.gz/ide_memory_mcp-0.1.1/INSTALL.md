# Installation Guide

This guide will help you install and set up the IDE Memory MCP server for use with various IDEs.

## Prerequisites

- Python 3.11 or higher
- [uv](https://docs.astral.sh/uv/) package manager (recommended)

## Installation Options

### Option 1: Install from PyPI (Recommended)

Once published to PyPI, you can install directly:

```bash
pip install ide-memory-mcp
```

### Option 2: Install from Source

Clone the repository and install locally:

```bash
git clone https://github.com/prasanna-pmpeople/IDE-Memory-MCP.git
cd IDE-Memory-MCP
pip install .
```

Or for development (editable install):

```bash
git clone https://github.com/prasanna-pmpeople/IDE-Memory-MCP.git
cd IDE-Memory-MCP
pip install -e .
```

### Option 3: Using uv (Recommended for Development)

```bash
git clone https://github.com/prasanna-pmpeople/IDE-Memory-MCP.git
cd IDE-Memory-MCP
uv sync
```

## Running the Server

After installation, you can run the server in stdio mode:

```bash
ide-memory-mcp
```

Or if installed with uv:

```bash
uv run ide-memory-mcp
```

## CLI Management Tool

The package includes a command-line interface for managing projects:

```bash
# List all projects
ide-memory-cli list

# Show project details
ide-memory-cli show <project-id-or-path>

# Inspect a section
ide-memory-cli inspect <project-id-or-path> overview

# Search memory
ide-memory-cli search <project-id-or-path> "search term"

# Delete a project
ide-memory-cli delete <project-id-or-path>
```

## Web Dashboard

Run the web dashboard to manage projects through a browser interface:

```bash
ide-memory-dashboard
```

Then open http://127.0.0.1:5000 in your browser.

## Setup Wizard

Run the interactive setup wizard to configure your IDE:

```bash
ide-memory-setup
```

## IDE Configuration

Add the following to your IDE's MCP configuration file:

### Antigravity
Location: `%APPDATA%\Antigravity\mcp_config.json`

### Claude Desktop
Location: `claude_desktop_config.json`

### Cursor
Location: `.cursor/mcp.json`

### VS Code
Location: `.vscode/mcp.json`

Configuration:
```json
{
  "mcpServers": {
    "ide-memory": {
      "command": "ide-memory-mcp"
    }
  }
}
```

If you installed from source and want to reference the local path:

```json
{
  "mcpServers": {
    "ide-memory": {
      "command": "uv",
      "args": ["--directory", "/path/to/IDE-Memory-MCP", "run", "ide-memory-mcp"]
    }
  }
}
```

## Testing the Installation

To test with the MCP inspector:

```bash
uv run mcp dev src/ide_memory_mcp/server.py
```

Or if installed globally:

```bash
mcp dev $(which ide-memory-mcp)
```

## Troubleshooting

### Common Issues

1. **Command not found**: Make sure Python scripts directory is in your PATH
2. **Permission errors**: Try installing with `--user` flag: `pip install --user ide-memory-mcp`
3. **IDE not connecting**: Verify the MCP configuration file path and syntax

### Verifying Installation

Check if the command is available:

```bash
ide-memory-mcp --help
```

Check installed version:

```bash
pip show ide-memory-mcp
```

## Configuration

The IDE Memory MCP can be configured through a JSON configuration file located at `~/.ide-memory/config.json`. An example configuration file is available at `config.example.json`.

To use the example configuration:

```bash
mkdir -p ~/.ide-memory
cp config.example.json ~/.ide-memory/config.json
```

Then edit `~/.ide-memory/config.json` to customize the settings according to your preferences.

Configuration options include:
- `auto_initialize`: Automatically initialize new projects
- `scan_depth`: Directory scanning depth
- `max_files`: Maximum files to include in directory scan
- `preserve_annotations`: Preserve inline annotations during rescanning
- `ignored_dirs`: Directories to ignore during scanning
- `ignored_extensions`: File extensions to ignore during scanning