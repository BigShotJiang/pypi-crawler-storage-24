import os
from overmind_sdk.client import OvermindError

LOCAL_API_KEY_PREFIX = "ovr_core_"
LOCAL_BASE_URL = "http://localhost:8000"
DEFAULT_BASE_URL = "https://api.overmindlab.ai"


def get_api_settings(
    overmind_api_key: str | None = None,
    base_url: str | None = None,
) -> tuple[str, str]:
    overmind_api_key = overmind_api_key or os.getenv("OVERMIND_API_KEY")
    if not overmind_api_key:
        raise OvermindError(
            "No Overmind API key provided. Either pass 'overmind_api_key' parameter "
            "or set OVERMIND_API_KEY environment variable."
        )

    is_local = overmind_api_key.startswith(LOCAL_API_KEY_PREFIX)
    default_url = LOCAL_BASE_URL if is_local else DEFAULT_BASE_URL

    if base_url is None:
        base_url = os.getenv("OVERMIND_API_URL") or default_url

    base_url = base_url.rstrip("/")

    return overmind_api_key, base_url
