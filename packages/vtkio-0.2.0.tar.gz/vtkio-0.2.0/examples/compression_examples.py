

# =============================================================================
# Usage examples
# =============================================================================

import numpy as np

from vtkio import unstructured_points
from vtkio.vtk_cell_types import (
    VTK_Hexahedron,
    VTK_Line,
    VTK_Pixel,
    VTK_Polygon,
    VTK_PolyLine,
    VTK_Quad,
    VTK_Tetra,
    VTK_Triangle,
    VTK_TriangleStrip,
    VTK_Vertex,
    VTK_Voxel,
)
from vtkio.writer.xml_writer import XMLUnstructuredGridWriter
from vtkio.reader.xml import read_vtkxml_data

# create some data for unstructured grid
# set numpy seed value so that all arrays contain repeatable numbers
np.random.seed(77)

# Create a set of points in 3D space
points = np.array([[0, 0, 0], [1, 0, 0], [2, 0, 0], [0, 1, 0], [1, 1, 0],
                   [2, 1, 0], [0, 0, 1], [1, 0, 1], [2, 0, 1], [0, 1, 1],
                   [1, 1, 1], [2, 1, 1], [0, 1, 2], [1, 1, 2], [2, 1, 2],
                   [0, 1, 3], [1, 1, 3], [2, 1, 3], [0, 1, 4], [1, 1, 4],
                   [2, 1, 4], [0, 1, 5], [1, 1, 5], [2, 1, 5], [0, 1, 6],
                   [1, 1, 6], [2, 1, 6],
                   ])

num_points = len(points)
num_cells = 11

# data for writing for each point or cell is defined in a dict of dicts
# where the keys represent the DataArray type and the nested keys the
# DataArray name
cell_scalars = np.arange(num_cells) + 1
point_vectors = np.random.random([num_points, 3])

point_data = {"vectors": {"velocity": point_vectors},

              }

cell_data = {"scalars": {"temp": cell_scalars}

             }
# create types and connectivity
cell_types = [VTK_Hexahedron, VTK_Voxel, VTK_Tetra, VTK_Pixel, VTK_Polygon.set_num_points(6),
              VTK_TriangleStrip.set_num_triangles(1), VTK_Quad, VTK_Triangle,
              VTK_PolyLine.set_num_points(3), VTK_Line, VTK_Vertex]

# create cell topology
cell_type = []
num_cell_nodes = []
for cell in cell_types:
    cell_type.append(cell.type_id)
    num_cell_nodes.append(cell.num_points)

connectivity = [0, 1, 4, 3, 6, 7, 10, 9,
                1, 2, 4, 5, 7, 8, 10, 11,
                6, 10, 9, 12,
                11, 14, 10, 13,
                15, 16, 17, 14, 13, 12,
                18, 15, 19, 16, 20, 17,
                22, 23, 20, 19,
                21, 22, 18,
                22, 19, 18,
                26, 25,
                24]

offsets = np.cumsum(num_cell_nodes)


# Writing with compression:
writer = XMLUnstructuredGridWriter(
    'output_compressed.vtu',
    nodes=points,
    cell_type=cell_type,
    connectivity=connectivity,
    offsets=offsets,
    point_data=point_data,
    cell_data=cell_data,
    field_data=None,
    encoding='binary',         # inline base64
    compression=True,          # zlib at default level
)
writer.write_xml_file()

# or with an explicit level:
writer = XMLUnstructuredGridWriter(    'output_compressed_max_zlib.vtu',
    nodes=points,
    cell_type=cell_type,
    connectivity=connectivity,
    offsets=offsets,
    point_data=point_data,
    cell_data=cell_data,
    field_data=None,
    encoding='binary',         # inline base64
    compression=9)
writer.write_xml_file()

# or with lzma (better ratio, slower):
writer = XMLUnstructuredGridWriter(    'output_compressed_lzma.vtu',
    nodes=points,
    cell_type=cell_type,
    connectivity=connectivity,
    offsets=offsets,
    point_data=point_data,
    cell_data=cell_data,
    field_data=None,
    encoding='binary',         # inline base64
    compression='lzma')
writer.write_xml_file()

# or appended raw + compression:
writer = XMLUnstructuredGridWriter(
    'output_compressed_appended.vtu',
    nodes=points,
    cell_type=cell_type,
    connectivity=connectivity,
    offsets=offsets,
    point_data=point_data,
    cell_data=cell_data,
    field_data=None,
    encoding='appended',
    appended_encoding='raw',
    compression=True
)
writer.write_xml_file()

from vtkio.writer.vtkhdf import VTKHDFUnstructuredGridWriter

# Write the file using the vtkhdf writer class
file = VTKHDFUnstructuredGridWriter('output_compressed_vtkhdf',
                                 nodes=points,
                                 cell_types=cell_type,
                                 connectivity=connectivity,
                                 offsets=offsets,
                                 point_data=point_data,
                                 cell_data=cell_data,
                                 field_data=None,
                                 additional_metadata=None,
                                    compression=True,
                                    compression_level=8
                                    )

file.write_vtkhdf_file()

# Reading (automatic — no user action required):

data = read_vtkxml_data('output_compressed.vtu')   # decompresses transparently