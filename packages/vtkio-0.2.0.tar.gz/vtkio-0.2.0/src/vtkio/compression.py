"""
Compression utilities for VTK XML files.

VTK XML supports three compressors, identified in the <VTKFile> root tag:
  compressor="vtkZLibDataCompressor"   (zlib, stdlib)
  compressor="vtkLZMADataCompressor"   (lzma, stdlib since Python 3.3)
  compressor="vtkLZ4DataCompressor"    (lz4, requires python-lz4)

When compression is active, each DataArray's binary payload changes from:
  Uncompressed:  [data_nbytes : header_t][raw_data]
  Compressed:    [n_blocks : header_t][uncomp_block_size : header_t]
                 [last_uncomp_size : header_t][comp_size_0 : header_t]
                 ... [comp_size_N-1 : header_t]
                 [compressed_block_0][...][compressed_block_N-1]

where header_t is uint32 (VTK version 0.1) or uint64 (VTK version 1.0).

For inline base64 ("format=binary") the whole payload is base64-encoded.
For appended raw the whole payload is written as raw bytes.
For appended base64 each payload is individually base64-encoded.

The DataArray XML tag attributes are unchanged — only the binary content differs.
The <VTKFile> root tag gains a compressor="..." attribute.
"""
import struct
import zlib
import lzma
from typing import Optional

# ---- public constants -------------------------------------------------------

COMPRESSOR_ZLIB = "vtkZLibDataCompressor"
COMPRESSOR_LZMA = "vtkLZMADataCompressor"
COMPRESSOR_LZ4  = "vtkLZ4DataCompressor"

# Friendly name → VTK string
COMPRESSOR_MAP = {
    "zlib": COMPRESSOR_ZLIB,
    "lzma": COMPRESSOR_LZMA,
    "lz4":  COMPRESSOR_LZ4,
}

# VTK string → friendly name (reverse)
COMPRESSOR_REVERSE = {v: k for k, v in COMPRESSOR_MAP.items()}

# Default zlib level used when compression=True
DEFAULT_ZLIB_LEVEL = -1   # zlib default (~6)

# ---- header helpers ---------------------------------------------------------

def _header_struct_char(header_type: str, byte_order_char: str) -> tuple[str, int]:
    """Return (struct_format_char, byte_size) for a single header integer."""
    if header_type in ("UInt64", "uint64"):
        return byte_order_char + "Q", 8
    else:  # UInt32 / Uint32
        return byte_order_char + "I", 4


def build_compression_header(
    n_blocks: int,
    uncomp_block_size: int,
    last_uncomp_size: int,
    comp_sizes: list[int],
    header_type: str,
    byte_order_char: str,
) -> bytes:
    """
    Pack the VTK compression header into bytes.

    Parameters
    ----------
    n_blocks : int
        Number of compressed blocks (almost always 1 for vtkio).
    uncomp_block_size : int
        Uncompressed size of each full block (= total size when n_blocks == 1).
    last_uncomp_size : int
        Uncompressed size of the last (possibly partial) block.
    comp_sizes : list[int]
        Compressed byte-length of each block (len == n_blocks).
    header_type : str
        'UInt64' (VTK v1.0) or 'UInt32'/'Uint32' (VTK v0.1).
    byte_order_char : str
        '<' (little-endian) or '>' (big-endian).
    """
    fmt, _ = _header_struct_char(header_type, byte_order_char)
    # fmt is already prefixed with byte_order_char, e.g. '<Q'
    # build one format string for the whole header
    type_char = fmt[-1]  # 'Q' or 'I'
    n_header_ints = 3 + n_blocks
    full_fmt = byte_order_char + type_char * n_header_ints
    return struct.pack(full_fmt, n_blocks, uncomp_block_size, last_uncomp_size, *comp_sizes)


# ---- compression ------------------------------------------------------------

def _compress_data(raw_bytes: bytes, compressor: str, level: int) -> bytes:
    """Compress raw bytes using the specified compressor. Returns compressed bytes only."""
    if compressor == COMPRESSOR_ZLIB:
        return zlib.compress(raw_bytes, level)
    elif compressor == COMPRESSOR_LZMA:
        return lzma.compress(raw_bytes, preset=(level if level >= 0 else 6))
    elif compressor == COMPRESSOR_LZ4:
        try:
            import lz4.block as _lz4block
        except ImportError:
            raise ImportError(
                "lz4 compression requires the 'lz4' package: pip install lz4"
            ) from None
        return _lz4block.compress(raw_bytes, store_size=False)
    else:
        raise ValueError(f"Unknown VTK compressor: {compressor!r}")


def compress_array_parts(
    raw_bytes: bytes,
    compressor: str,
    level: int,
    header_type: str,
    byte_order_char: str,
) -> tuple[bytes, bytes]:
    """
    Compress *raw_bytes* and return **(header, compressed_data)** separately.

    This is the correct form for base64 encoding, where VTK requires the
    header and data to be base64-encoded independently and then concatenated:
        base64(header) + base64(compressed_data)
    Encoding them together shifts the byte boundary and corrupts the header read.

    Returns
    -------
    tuple[bytes, bytes]
        (compression_header, compressed_data)
    """
    compressed = _compress_data(raw_bytes, compressor, level)
    uncomp_size = len(raw_bytes)
    header = build_compression_header(
        n_blocks=1,
        uncomp_block_size=uncomp_size,
        last_uncomp_size=uncomp_size,
        comp_sizes=[len(compressed)],
        header_type=header_type,
        byte_order_char=byte_order_char,
    )
    return header, compressed


def compress_array(
    raw_bytes: bytes,
    compressor: str,
    level: int,
    header_type: str,
    byte_order_char: str,
) -> bytes:
    """
    Compress *raw_bytes* and return header + compressed_data as one bytes object.

    Use this only for **raw binary** (appended raw encoding), where the bytes
    are written sequentially with no base64 padding boundary issues.
    For base64 encoding use compress_array_parts() instead.

    Returns
    -------
    bytes
        header + compressed_data
    """
    header, compressed = compress_array_parts(raw_bytes, compressor, level, header_type, byte_order_char)
    return header + compressed



# ---- decompression ----------------------------------------------------------

def decompress_array(
    data: bytes,
    compressor: str,
    header_type: str,
    byte_order_char: str,
) -> bytes:
    """
    Decompress a VTK-format compressed payload back to raw bytes.

    The *data* argument must start at the compression header (NOT at a base64
    boundary — the caller should already have decoded any base64).

    Parameters
    ----------
    data : bytes
        Raw bytes beginning with the VTK compression header.
    compressor : str
        One of the VTK compressor strings (e.g. 'vtkZLibDataCompressor').
    header_type : str
        'UInt64' or 'UInt32'/'Uint32'.
    byte_order_char : str
        '<' or '>'.

    Returns
    -------
    bytes
        Uncompressed data (no header).
    """
    fmt, hdr_sz = _header_struct_char(header_type, byte_order_char)
    type_char = fmt[-1]

    # Read n_blocks
    n_blocks = struct.unpack_from(fmt, data, 0)[0]

    # Read the rest of the header: uncomp_block_size, last_uncomp_size, comp_sizes[0..n-1]
    n_header_ints = 3 + n_blocks
    full_fmt = byte_order_char + type_char * n_header_ints
    header_vals = struct.unpack_from(full_fmt, data, 0)
    # header_vals[0] = n_blocks  (already read)
    # header_vals[1] = uncompressed block size (max per block)
    # header_vals[2] = last uncompressed block size
    # header_vals[3..] = compressed sizes per block
    comp_sizes = list(header_vals[3:])
    header_bytes = n_header_ints * hdr_sz

    decompressed_parts = []
    offset = header_bytes
    for comp_size in comp_sizes:
        block = data[offset: offset + comp_size]
        if compressor == COMPRESSOR_ZLIB:
            decompressed_parts.append(zlib.decompress(block))
        elif compressor == COMPRESSOR_LZMA:
            decompressed_parts.append(lzma.decompress(block))
        elif compressor == COMPRESSOR_LZ4:
            try:
                import lz4.block as _lz4block
            except ImportError:
                raise ImportError(
                    "lz4 decompression requires the 'lz4' package: pip install lz4"
                ) from None
            # LZ4 block format requires knowing the uncompressed size
            uncomp_size = (
                header_vals[2] if i == n_blocks - 1 else header_vals[1]
            )
            decompressed_parts.append(
                _lz4block.decompress(block, uncompressed_size=uncomp_size)
            )
        else:
            raise ValueError(f"Unknown VTK compressor: {compressor!r}")
        offset += comp_size

    return b"".join(decompressed_parts)