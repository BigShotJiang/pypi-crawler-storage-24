# constants-cli

CLI for running [Constants](https://app.constants.ai) tools from the command line.

## Install

```bash
uv tool install constants-cli
```

## Quick Start

```bash
# Authenticate (or set CONSTANTS_API_KEY env var)
constants auth

# List your tools
constants list

# Run a tool
constants run my_tool_abc12345 query="hello world"

# Run with file input (auto-uploaded)
constants run pdf_tool_abc12345 pdf_file=./report.pdf

# Run with JSON input
constants run my_tool_abc12345 --input-json '{"query": "hello", "limit": 10}'
```

## Authentication

Set your API key via environment variable:

```bash
export CONSTANTS_API_KEY="wk_your_key_here"
```

Or store it persistently:

```bash
constants auth
```

Get your API key at [app.constants.ai/settings](https://app.constants.ai/settings).
