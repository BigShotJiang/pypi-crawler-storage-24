"""CLI entry point."""

import click

from constants_cli import __version__


@click.group()
@click.version_option(version=__version__, prog_name="constants")
def cli():
    """Constants CLI - Run Constants.ai tools from the command line."""
    pass


# Commands are registered via imports below
from constants_cli.commands import auth, list_tools, run  # noqa: E402, F401
