"""API key resolution: env var -> config file -> error."""

import json
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".constants"
CONFIG_FILE = CONFIG_DIR / "config.json"
ENV_VAR = "CONSTANTS_API_KEY"


def get_api_key() -> str | None:
    """Resolve API key from env var or config file."""
    key = os.environ.get(ENV_VAR)
    if key:
        return key

    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text())
            return data.get("api_key")
        except (json.JSONDecodeError, OSError):
            pass

    return None


def save_api_key(key: str) -> None:
    """Persist API key to config file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps({"api_key": key}, indent=2) + "\n")
    CONFIG_FILE.chmod(0o600)


def require_api_key() -> str:
    """Get API key or raise with instructions."""
    key = get_api_key()
    if not key:
        raise SystemExit(
            "No API key found.\n"
            f"Set {ENV_VAR} or run: constants auth\n"
            "Get your key at https://app.constants.ai/settings"
        )
    return key
