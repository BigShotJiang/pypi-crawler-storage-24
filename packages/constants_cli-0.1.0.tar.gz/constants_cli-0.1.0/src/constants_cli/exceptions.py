"""Typed exceptions for the Constants client."""


class ConstantsError(Exception):
    """Base exception for Constants API errors."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class AuthError(ConstantsError):
    """Authentication or authorization failure (401/403)."""
    pass


class NotFoundError(ConstantsError):
    """Tool or resource not found (404)."""
    pass


class ExecutionError(ConstantsError):
    """Tool execution failed (500 or error in output)."""
    pass


class ValidationError(ConstantsError):
    """Input validation failure (e.g., file type mismatch)."""
    pass
