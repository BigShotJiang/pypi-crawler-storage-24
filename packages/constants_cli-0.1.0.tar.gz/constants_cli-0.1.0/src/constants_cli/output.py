"""Result formatting for CLI output."""

import json
import sys


def print_json(data: object) -> None:
    """Print data as formatted JSON to stdout."""
    print(json.dumps(data, indent=2, default=str))


def print_error(message: str) -> None:
    """Print error message to stderr."""
    print(f"Error: {message}", file=sys.stderr)


def print_table(rows: list[dict], columns: list[tuple[str, str]]) -> None:
    """Print a simple text table.

    columns: list of (key, header) tuples.
    """
    if not rows:
        print("(no results)")
        return

    widths = {key: len(header) for key, header in columns}
    for row in rows:
        for key, _ in columns:
            val = str(row.get(key, ""))
            widths[key] = max(widths[key], len(val))

    header_line = "  ".join(h.ljust(widths[k]) for k, h in columns)
    print(header_line)
    print("  ".join("-" * widths[k] for k, _ in columns))
    for row in rows:
        line = "  ".join(str(row.get(k, "")).ljust(widths[k]) for k, _ in columns)
        print(line)
