"""constants auth - store API key."""

import click

from constants_cli.main import cli
from constants_cli.auth import save_api_key
from constants_cli.client import ConstantsClient
from constants_cli.output import print_error


@cli.command("auth")
def auth():
    """Store your Constants API key."""
    key = click.prompt("Enter your API key", hide_input=True)

    if not key.startswith("wk_"):
        print_error("Invalid key format. Keys start with 'wk_'.")
        raise SystemExit(1)

    try:
        client = ConstantsClient(api_key=key)
        tools = client.list_tools()
        click.echo(f"Authenticated. {len(tools)} tool(s) available.")
    except Exception as e:
        print_error(f"Key validation failed: {e}")
        raise SystemExit(1)

    save_api_key(key)
    click.echo("API key saved to ~/.constants/config.json")
