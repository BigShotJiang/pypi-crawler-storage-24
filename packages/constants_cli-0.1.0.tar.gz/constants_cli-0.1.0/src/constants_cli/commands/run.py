"""constants run - execute a tool with key=value args and automatic file upload."""

from __future__ import annotations

import fnmatch
import json
import os
import sys
from pathlib import Path
from typing import Any

import click

from constants_cli.main import cli
from constants_cli.auth import require_api_key
from constants_cli.client import ConstantsClient
from constants_cli.exceptions import ValidationError
from constants_cli.output import print_json, print_error


def _coerce_value(raw: str, schema_type: str | None) -> Any:
    """Coerce a string value using the tool schema type."""
    if schema_type == "boolean":
        return raw.lower() in ("true", "1", "yes")
    if schema_type in ("number", "integer"):
        try:
            return int(raw) if schema_type == "integer" else float(raw)
        except ValueError:
            return raw
    return raw


def _parse_key_value_args(
    pairs: tuple[str, ...],
    input_schema: dict[str, Any] | None,
) -> dict[str, Any]:
    """Parse key=value pairs, coercing types via the tool's input schema."""
    type_map: dict[str, str] = {}
    if input_schema:
        for prop in input_schema.get("properties", {}):
            if isinstance(prop, str):
                info = input_schema["properties"][prop]
                type_map[prop] = info.get("type", "string")
            elif isinstance(prop, dict):
                pass

        if isinstance(input_schema.get("properties"), dict):
            for name, info in input_schema["properties"].items():
                type_map[name] = info.get("type", "string")

    result: dict[str, Any] = {}
    for pair in pairs:
        if "=" not in pair:
            print_error(f"Invalid argument '{pair}'. Use key=value format.")
            raise SystemExit(1)
        key, value = pair.split("=", 1)
        result[key] = _coerce_value(value, type_map.get(key))
    return result


def _validate_file_accept(file_path: Path, accept: list[str] | None) -> None:
    """Validate a file's extension against accept patterns."""
    if not accept:
        return
    name = file_path.name.lower()
    ext = file_path.suffix.lower()
    for pattern in accept:
        if pattern.startswith(".") and ext == pattern.lower():
            return
        if "/" in pattern and fnmatch.fnmatch(f"x/{name}", f"x/{pattern.split('/')[1]}"):
            return
        if pattern == "*/*" or pattern == "*":
            return
    raise ValidationError(
        f"File '{file_path.name}' does not match accepted types: {', '.join(accept)}"
    )


def _handle_file_uploads(
    client: ConstantsClient,
    tool_name: str,
    args: dict[str, Any],
    file_fields: list[dict[str, Any]],
) -> dict[str, Any]:
    """Detect local file paths in args, upload them, and substitute references."""
    file_field_map = {f["name"]: f for f in file_fields}
    result = dict(args)

    for field_name, field_info in file_field_map.items():
        value = result.get(field_name)
        if value is None:
            continue

        field_type = field_info.get("type", "file")
        accept = field_info.get("accept")
        multiple = field_info.get("multiple", False)

        if field_type == "directory":
            dir_path = Path(str(value))
            if dir_path.is_dir():
                click.echo(f"Uploading directory {dir_path}...", err=True)
                upload_id = client.upload_directory(tool_name, field_name, dir_path)
                result[field_name] = upload_id
            continue

        if multiple:
            paths = [Path(p.strip()) for p in str(value).split(",")]
            upload_ids = []
            for p in paths:
                if p.is_file():
                    _validate_file_accept(p, accept)
                    click.echo(f"Uploading {p}...", err=True)
                    upload_ids.append(client.upload_file(tool_name, field_name, p))
                else:
                    upload_ids.append(str(p))
            result[field_name] = upload_ids
        else:
            file_path = Path(str(value))
            if file_path.is_file():
                _validate_file_accept(file_path, accept)
                click.echo(f"Uploading {file_path}...", err=True)
                upload_id = client.upload_file(tool_name, field_name, file_path)
                result[field_name] = upload_id

    return result


@cli.command("run")
@click.argument("tool_name")
@click.argument("key_value_args", nargs=-1)
@click.option("--input-json", "input_json", default=None, help="JSON string with tool arguments")
@click.option("--raw", is_flag=True, help="Print only the output field")
def run(tool_name: str, key_value_args: tuple[str, ...], input_json: str | None, raw: bool):
    """Run a tool.

    Pass arguments as key=value pairs or via --input-json.

    \b
    Examples:
      constants run my_tool query="hello world"
      constants run my_tool --input-json '{"query": "hello"}'
      constants run pdf_tool pdf_file=./report.pdf
    """
    api_key = require_api_key()
    client = ConstantsClient(api_key=api_key)

    # Build args from key=value pairs
    tool = client.get_tool(tool_name)
    input_schema = tool.get("inputSchema") if tool else None
    args = _parse_key_value_args(key_value_args, input_schema)

    # Merge --input-json (takes precedence)
    if input_json:
        try:
            json_args = json.loads(input_json)
        except json.JSONDecodeError as e:
            print_error(f"Invalid --input-json: {e}")
            raise SystemExit(1)
        args.update(json_args)

    # Handle file uploads if tool has file fields
    file_fields = tool.get("fileFields", []) if tool else []
    if file_fields:
        try:
            args = _handle_file_uploads(client, tool_name, args, file_fields)
        except ValidationError as e:
            print_error(str(e))
            raise SystemExit(1)

    try:
        result = client.run_tool(tool_name, args)
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)

    if raw:
        output = result.get("output", result)
        if isinstance(output, str):
            print(output)
        else:
            print_json(output)
    else:
        print_json(result)
