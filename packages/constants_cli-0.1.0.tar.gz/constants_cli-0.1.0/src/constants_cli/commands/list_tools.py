"""constants list - list available tools."""

import click

from constants_cli.main import cli
from constants_cli.client import ConstantsClient
from constants_cli.auth import require_api_key
from constants_cli.output import print_json, print_table, print_error


@cli.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def list_tools(as_json: bool):
    """List available tools."""
    api_key = require_api_key()
    client = ConstantsClient(api_key=api_key)

    try:
        tools = client.list_tools()
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)

    if as_json:
        print_json(tools)
        return

    rows = [{"name": t["name"], "description": (t.get("description") or "")[:80]} for t in tools]
    print_table(rows, [("name", "Name"), ("description", "Description")])
