"""HTTP client for the Constants v1 REST API."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import requests

from constants_cli.auth import require_api_key
from constants_cli.exceptions import AuthError, NotFoundError, ExecutionError

DEFAULT_BASE_URL = "https://app.constants.ai"
ENV_BASE_URL = "CONSTANTS_API_URL"


class ConstantsClient:
    """Thin HTTP wrapper around /api/v1/* endpoints."""

    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        self.api_key = api_key or require_api_key()
        self.base_url = (base_url or os.environ.get(ENV_BASE_URL) or DEFAULT_BASE_URL).rstrip("/")
        self._tools_cache: list[dict[str, Any]] | None = None

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _handle_error(self, resp: requests.Response) -> None:
        if resp.status_code == 200 or resp.status_code == 201:
            return

        try:
            body = resp.json()
            message = body.get("message") or body.get("error") or resp.text
        except Exception:
            message = resp.text or f"HTTP {resp.status_code}"

        if resp.status_code in (401, 403):
            raise AuthError(message, resp.status_code)
        if resp.status_code == 404:
            raise NotFoundError(message, resp.status_code)
        raise ExecutionError(message, resp.status_code)

    # ── Tool listing ─────────────────────────────────────────────

    def list_tools(self) -> list[dict[str, Any]]:
        """Fetch all available tools. Returns the raw tools array."""
        resp = requests.get(f"{self.base_url}/api/v1/tools", headers=self._headers())
        self._handle_error(resp)
        tools = resp.json().get("tools", [])
        self._tools_cache = tools
        return tools

    def get_tool(self, name: str) -> dict[str, Any] | None:
        """Look up a single tool by name (uses cache if available)."""
        tools = self._tools_cache if self._tools_cache is not None else self.list_tools()
        for t in tools:
            if t["name"] == name:
                return t
        return None

    # ── Tool execution ───────────────────────────────────────────

    def run_tool(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        """Execute a tool and return the full response."""
        resp = requests.post(
            f"{self.base_url}/api/v1/run/{name}",
            headers=self._headers(),
            json=args,
        )
        self._handle_error(resp)
        return resp.json()

    # ── File upload ──────────────────────────────────────────────

    def upload_file(self, tool_name: str, field_name: str, file_path: str | Path) -> str:
        """Upload a local file for a tool field. Returns the upload ID."""
        path = Path(file_path)
        if not path.is_file():
            raise FileNotFoundError(f"File not found: {path}")

        resp = requests.post(
            f"{self.base_url}/api/v1/upload",
            headers=self._headers(),
            json={
                "toolName": tool_name,
                "fieldName": field_name,
                "filename": path.name,
            },
        )
        self._handle_error(resp)
        data = resp.json()

        signed_url = data["signedUrl"]
        mime_type = data.get("mimeType", "application/octet-stream")

        put_resp = requests.put(
            signed_url,
            headers={"Content-Type": mime_type},
            data=path.read_bytes(),
        )
        if put_resp.status_code not in (200, 201):
            raise ExecutionError(f"File upload PUT failed: HTTP {put_resp.status_code}")

        return data["uploadId"]

    def upload_directory(self, tool_name: str, field_name: str, dir_path: str | Path) -> str:
        """Zip a directory and upload it. Returns the upload ID."""
        import tempfile
        import zipfile

        path = Path(dir_path)
        if not path.is_dir():
            raise NotADirectoryError(f"Not a directory: {path}")

        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
            tmp_path = Path(tmp.name)

        try:
            with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for file in path.rglob("*"):
                    if file.is_file():
                        zf.write(file, file.relative_to(path))

            resp = requests.post(
                f"{self.base_url}/api/v1/upload",
                headers=self._headers(),
                json={
                    "toolName": tool_name,
                    "fieldName": field_name,
                    "filename": f"{path.name}.zip",
                },
            )
            self._handle_error(resp)
            data = resp.json()

            put_resp = requests.put(
                data["signedUrl"],
                headers={"Content-Type": "application/zip"},
                data=tmp_path.read_bytes(),
            )
            if put_resp.status_code not in (200, 201):
                raise ExecutionError(f"Directory upload PUT failed: HTTP {put_resp.status_code}")

            return data["uploadId"]
        finally:
            tmp_path.unlink(missing_ok=True)
