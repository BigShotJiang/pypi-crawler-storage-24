import os
import sys

from setuptools import find_packages, setup

current = os.path.dirname(os.path.realpath(__file__))
sys.path.append(current)

from base_model_tools import __version__  # noqa: E402

setup(
    name         = 'base_model_tools',
    version      = __version__,
    packages     = find_packages(exclude=['tests*']),
    author       = 'Nearly Human',
    author_email = 'support@nearlyhuman.ai',
    description  = 'Nearly Human Base Model Tools dependency for training, saving, loading, deploying, and inferencing models.',
    keywords     = 'nearlyhuman, nearly human, model, tools',

    python_requires  = '>=3.8.10',
    install_requires = [
        'mlflow-skinny>=3.4.0',
        'numpy>=2.3.5'
    ]
)
