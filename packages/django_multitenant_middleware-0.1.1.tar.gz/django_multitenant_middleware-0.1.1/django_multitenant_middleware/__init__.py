from django_multitenant_middleware.http_middleware import TenantHTTPMiddleware
from django_multitenant_middleware.resolvers import (
    FlexibleSubdomainTenantResolver,
    HeaderTenantResolver,
)
from django_multitenant_middleware.ws_middleware import TenantWebSocketMiddleware

__all__ = [
    "TenantWebSocketMiddleware",
    "FlexibleSubdomainTenantResolver",
    "HeaderTenantResolver",
    "TenantHTTPMiddleware",
]

__version__ = "0.1.1"


def get_http_middleware(
    get_response, tenant_model=None, resolver=None, tenant_setter=None
):
    """
    Easy integration: call this from settings.py
    """
    return TenantHTTPMiddleware(
        get_response=get_response,
        tenant_model=tenant_model,
        resolver=resolver,
        tenant_setter=tenant_setter,
    )
