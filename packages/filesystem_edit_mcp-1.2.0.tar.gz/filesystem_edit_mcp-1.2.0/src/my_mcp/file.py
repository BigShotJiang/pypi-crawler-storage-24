import pathlib

from my_mcp.umlaut_config import UmlautConfig
from my_mcp.umlaut_fixer import fix_document


class File:
    def __init__(
        self, path: pathlib.Path | str, encoding: str, umlaut_config: UmlautConfig
    ):
        self.path = pathlib.Path(path)
        self.encoding = encoding
        self.umlaut_config = umlaut_config
        self._content: str | None = None

    @property
    def content(self) -> str:
        if self._content is None:
            self._content = self.path.read_text(encoding=self.encoding)
        return self._content

    @content.setter
    def content(self, value: str) -> None:
        self._content = fix_document(value, self.umlaut_config)
        self.path.write_text(value, encoding=self.encoding)
