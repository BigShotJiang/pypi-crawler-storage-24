from pathlib import Path

from mcp.server.fastmcp import Context, FastMCP

mcp = FastMCP("my-mcp", json_response=True)


@mcp.tool()
def read_file(path: str, ctx: Context) -> str:
    """Reads the file at path. Must be given an absolute path"""
    return Path(path).read_text().title()
