import json
import os
import tempfile

import pytest
from fastmcp import Client
from fastmcp.exceptions import ToolError


@pytest.fixture
def tmp():
    with tempfile.TemporaryDirectory() as d:
        yield d


def tmp_path(tmp, name):
    return os.path.join(tmp, name).replace("\\", "/")


def write_file(path, content, encoding="utf-8"):
    with open(path, "w", encoding=encoding) as f:
        f.write(content)


def read_file(path, encoding="utf-8"):
    with open(path, encoding=encoding) as f:
        return f.read()


def make_client(tmp_dir, config=None):
    env = {**os.environ, "ALLOWED_DIRS": tmp_dir.replace("\\", "/")}
    if config:
        config_path = os.path.join(tmp_dir, "test_config.json")
        with open(config_path, "w") as f:
            json.dump(config, f)
        env["SERVER_CONFIG"] = config_path
    return Client(
        {
            "mcpServers": {
                "wrapper": {
                    "command": "uv",
                    "args": ["run", "python", "-m", "my_mcp"],
                    "env": env,
                }
            }
        }
    )


TEST_CONFIG = {
    "umlaut_config": {
        "string_mapping": {"Ä": "CAE_UMLT"},
        "comment_mapping": {"Ä": "Ae"},
    },
    "encoding_config": {
        "default": "utf-8",
        "mapping": {"*.cpp": "latin-1", "*.h": "latin-1"},
    },
}


# ── Tool discovery ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_lists_both_tools(tmp):
    async with make_client(tmp, TEST_CONFIG) as client:
        tools = [t.name for t in await client.list_tools()]
        assert "edit_file" in tools
        assert "read_text_file" in tools


# ── read_text_file ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_read_plain_text(tmp):
    path = tmp_path(tmp, "hello.txt")
    write_file(path, "hello world")

    async with make_client(tmp, TEST_CONFIG) as client:
        result = await client.call_tool("read_text_file", {"path": path})
        assert not result.is_error
        assert "hello world" in str(result)


@pytest.mark.asyncio
async def test_read_preserves_umlauts(tmp):
    path = tmp_path(tmp, "test.txt")
    write_file(path, "Ärger mit Übung\n")

    async with make_client(tmp, TEST_CONFIG) as client:
        content = str(await client.call_tool("read_text_file", {"path": path}))
        assert "Ärger" in content
        assert "Übung" in content


@pytest.mark.asyncio
async def test_read_cpp_uses_latin1_from_config(tmp):
    path = tmp_path(tmp, "test.cpp")
    write_file(path, 'const char* s = "Ärger";\n', encoding="latin-1")

    async with make_client(tmp, TEST_CONFIG) as client:
        result = await client.call_tool("read_text_file", {"path": path})
        assert not result.is_error
        assert "rger" in str(result)


@pytest.mark.asyncio
async def test_read_txt_uses_utf8_from_config(tmp):
    path = tmp_path(tmp, "test.txt")
    write_file(path, "Ärger\n", encoding="utf-8")

    async with make_client(tmp, TEST_CONFIG) as client:
        result = await client.call_tool("read_text_file", {"path": path})
        assert not result.is_error
        assert "Ärger" in str(result)


@pytest.mark.asyncio
async def test_read_nonexistent_file_returns_error(tmp):
    path = tmp_path(tmp, "nonexistent.txt")

    async with make_client(tmp, TEST_CONFIG) as client:
        with pytest.raises(ToolError):
            await client.call_tool("read_text_file", {"path": path})


@pytest.mark.asyncio
async def test_read_path_outside_allowed_dir_returns_error(tmp):
    async with make_client(tmp, TEST_CONFIG) as client:
        with pytest.raises(ToolError, match="not within allowed"):
            await client.call_tool("read_text_file", {"path": "/etc/passwd"})


# ── edit_file ───────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_edit_basic(tmp):
    path = tmp_path(tmp, "test.txt")
    write_file(path, "hello world")

    async with make_client(tmp, TEST_CONFIG) as client:
        result = await client.call_tool(
            "edit_file",
            {
                "path": path,
                "edits": [{"oldText": "hello", "newText": "goodbye"}],
                "dryRun": False,
            },
        )
        assert not result.is_error

    assert read_file(path) == "goodbye world"


@pytest.mark.asyncio
async def test_edit_applies_umlaut_fixing(tmp):
    path = tmp_path(tmp, "test.cpp")
    write_file(path, 'const char* s = "hello Ärger";\n', encoding="latin-1")

    async with make_client(tmp, TEST_CONFIG) as client:
        result = await client.call_tool(
            "edit_file",
            {
                "path": path,
                "edits": [{"oldText": "hello", "newText": "goodbye"}],
                "dryRun": False,
            },
        )
        assert not result.is_error

    on_disk = read_file(path, encoding="latin-1")
    assert "goodbye" in on_disk
    assert "CAE_UMLT" in on_disk


@pytest.mark.asyncio
async def test_edit_cpp_preserves_latin1_encoding(tmp):
    path = tmp_path(tmp, "test.cpp")
    write_file(path, "int x = 1;\n", encoding="latin-1")

    async with make_client(tmp, TEST_CONFIG) as client:
        result = await client.call_tool(
            "edit_file",
            {
                "path": path,
                "edits": [{"oldText": "1", "newText": "2"}],
                "dryRun": False,
            },
        )
        assert not result.is_error

    assert read_file(path, encoding="latin-1") == "int x = 2;\n"


@pytest.mark.asyncio
async def test_edit_dry_run_does_not_modify_file(tmp):
    path = tmp_path(tmp, "test.cpp")
    original = 'const char* s = "hello";\n'
    write_file(path, original, encoding="latin-1")

    async with make_client(tmp, TEST_CONFIG) as client:
        result = await client.call_tool(
            "edit_file",
            {
                "path": path,
                "edits": [{"oldText": "hello", "newText": "goodbye"}],
                "dryRun": True,
            },
        )
        assert not result.is_error

    assert read_file(path, encoding="latin-1") == original


@pytest.mark.asyncio
async def test_edit_multiple_edits(tmp):
    path = tmp_path(tmp, "test.txt")
    write_file(path, "aaa bbb ccc")

    async with make_client(tmp, TEST_CONFIG) as client:
        result = await client.call_tool(
            "edit_file",
            {
                "path": path,
                "edits": [
                    {"oldText": "aaa", "newText": "xxx"},
                    {"oldText": "ccc", "newText": "zzz"},
                ],
                "dryRun": False,
            },
        )
        assert not result.is_error

    assert read_file(path) == "xxx bbb zzz"


@pytest.mark.asyncio
async def test_edit_nonexistent_file_returns_error(tmp):
    path = tmp_path(tmp, "nonexistent.txt")

    async with make_client(tmp, TEST_CONFIG) as client:
        with pytest.raises(ToolError):
            await client.call_tool(
                "edit_file",
                {
                    "path": path,
                    "edits": [{"oldText": "old", "newText": "new"}],
                },
            )


@pytest.mark.asyncio
async def test_edit_path_outside_allowed_dir_returns_error(tmp):
    async with make_client(tmp, TEST_CONFIG) as client:
        with pytest.raises(ToolError, match="not within allowed"):
            await client.call_tool(
                "edit_file",
                {
                    "path": "/etc/passwd",
                    "edits": [{"oldText": "old", "newText": "new"}],
                },
            )


@pytest.mark.asyncio
async def test_edit_malformed_payload_missing_oldtext(tmp):
    path = tmp_path(tmp, "test.txt")
    write_file(path, "hello")

    async with make_client(tmp, TEST_CONFIG) as client:
        with pytest.raises(ToolError):
            await client.call_tool(
                "edit_file",
                {
                    "path": path,
                    "edits": [{"newText": "new"}],
                },
            )


# ── end-to-end: edit then read ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_edit_then_read(tmp):
    path = tmp_path(tmp, "test.txt")
    write_file(path, "hello world")

    async with make_client(tmp, TEST_CONFIG) as client:
        await client.call_tool(
            "edit_file",
            {
                "path": path,
                "edits": [{"oldText": "hello", "newText": "goodbye"}],
                "dryRun": False,
            },
        )
        result = await client.call_tool("read_text_file", {"path": path})
        assert not result.is_error
        assert "goodbye world" in str(result)
