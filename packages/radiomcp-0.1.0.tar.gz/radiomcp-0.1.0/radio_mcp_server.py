"""radiomcp - MCP server for internet radio (placeholder)."""

def main():
    print("radiomcp - coming soon. https://mpop.dev")

if __name__ == "__main__":
    main()
