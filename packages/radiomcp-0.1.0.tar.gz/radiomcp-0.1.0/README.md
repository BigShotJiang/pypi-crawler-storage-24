# radiomcp

MCP (Model Context Protocol) server for internet radio.

Search, play, and discover radio stations through any MCP-compatible AI client.

## Install

```bash
pip install radiomcp
```

## Part of MeshPOP

Built on the [MeshPOP](https://mpop.dev) 5-layer stack. Powers [airtune.ai](https://airtune.ai).

## Status

Early development — full release coming soon.
