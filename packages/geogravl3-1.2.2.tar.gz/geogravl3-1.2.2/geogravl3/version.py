# SPDX-License-Identifier: GPL-3.0-or-later
# FileType: SOURCE
# SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
# SPDX-FileCopyrightText: 2025, "Eva Boergens" at GFZ Potsdam


# -*- coding: utf-8 -*-
"""Version module for geogravL3."""

__version__ = "1.2.2"
__versionalias__ = "2026-03-11_01"
