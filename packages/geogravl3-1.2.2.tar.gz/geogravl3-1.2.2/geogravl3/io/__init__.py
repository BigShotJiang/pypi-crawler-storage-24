# SPDX-License-Identifier: GPL-3.0-or-later
# FileType: SOURCE
# SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
# SPDX-FileCopyrightText: 2025, "Eva Boergens" at GFZ Potsdam
"""Reader and writer functions for geogravL3."""
from .readers import (
    read_input_folder,
    read_folder_gfc,
    read_folder_yaml,
    read_gfc,
    read_yaml,
    read_nc,
    read_mask,
    read_region_geojson,
    read_ice_basins_from_kernel,
    read_l2b_spherical_harmonic_coefficients,
    read_sinex_data,
    read_lowdegree_coefficients,
    read_load_love_numbers,
    read_grid_definition,
)

from .writers import (
    write_nc,
    write_tws_nc,
    write_obp_nc,
    write_ice_nc,
    save_timeseries_to_csv,
    save_ice_timeseries_to_csv,
    write_spherical_harmonic_coefficients_to_netcdf,
)

__all__ = [
    # readers
    "read_input_folder",
    "read_folder_gfc",
    "read_folder_yaml",
    "read_yaml",
    "read_gfc",
    "read_nc",
    "read_mask",
    "read_region_geojson",
    "read_ice_basins_from_kernel",
    "read_l2b_spherical_harmonic_coefficients",
    "read_sinex_data",
    "read_lowdegree_coefficients",
    "read_load_love_numbers",
    "read_grid_definition",
    # writers
    "write_nc",
    "write_tws_nc",
    "write_obp_nc",
    "write_ice_nc",
    "save_timeseries_to_csv",
    "save_ice_timeseries_to_csv",
    "write_spherical_harmonic_coefficients_to_netcdf",
]
