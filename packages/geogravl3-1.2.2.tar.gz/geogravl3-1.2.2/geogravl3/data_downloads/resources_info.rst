.. SPDX-License-Identifier: GPL-3.0-or-later
.. FileType: DOCUMENTATION
.. SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
.. SPDX-FileCopyrightText: 2025, "Eva Boergens" at GFZ Potsdam

.. role:: bash(code)
   :language: bash

=================
Resources
=================
This folder contains resources (files) needed in the processing of spherical harmonic gravity field data to gridded data.

How-to adding new files to resources
====================================
* Add file to the correct folder (if needed create new folder)
* Check the file size for git-lfs:
    * Large files should not be pushed into git but git-lfs.
    * ".gitattributes" lists file endings that are automatically stored to git-lfs.
    * In case add new file ending or specific new file to ".gitattributes"
* run :bash:`$ python -m geogravl3.data_downloads.generate_resources_manifest` to update manifest
* Push to git
