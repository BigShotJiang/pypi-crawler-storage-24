# SPDX-License-Identifier: GPL-3.0-or-later
# FileType: SOURCE
# SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
# SPDX-FileCopyrightText: 2025, "Eva Boergens" at GFZ Potsdam
"""Module for l4 processing."""

from .l4_timeseries import generate_l4_timeseries

__all__ = [
    "generate_l4_timeseries",
]
