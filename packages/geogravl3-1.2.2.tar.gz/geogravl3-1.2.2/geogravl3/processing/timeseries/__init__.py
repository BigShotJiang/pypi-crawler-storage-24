# SPDX-License-Identifier: GPL-3.0-or-later
# FileType: SOURCE
# SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
# SPDX-FileCopyrightText: 2025, "Eva Boergens" at GFZ Potsdam
"""Processing module for geogravL3 containing everything related to the processing pipeline."""

from .timeseries import (
    FitConfig,
    fit_harmonics,
    apply_harmonic_components_grid,
    apply_harmonic_components_sh,
    remove_mean_grid,
    remove_mean_sh,
    gaussian_filter_grid,
    gaussian_filter_sh,
    fit_161d_with_phaseoffset_sh,
    fit_161d_with_phaseoffset,
    harmonic_signal_from_coefficients
)

__all__ = [
    "FitConfig",
    "fit_harmonics",
    "apply_harmonic_components_grid",
    "apply_harmonic_components_sh",
    "remove_mean_grid",
    "remove_mean_sh",
    "gaussian_filter_grid",
    "gaussian_filter_sh",
    "fit_161d_with_phaseoffset_sh",
    "fit_161d_with_phaseoffset",
    "harmonic_signal_from_coefficients"
]
