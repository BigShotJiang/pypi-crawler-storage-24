# SPDX-License-Identifier: GPL-3.0-or-later
# FileType: SOURCE
# SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
# SPDX-FileCopyrightText: 2025, "Eva Boergens" at GFZ Potsdam
"""Module for spherical harmonics processing."""

# Lifting the functions from their files
from .sh_analysis import sh_analysis
from .sh_synthesis import sh_synthesis
from .legendre import legendre
__all__ = [
    "sh_analysis",
    "sh_synthesis",
    "legendre",
]
