# SPDX-License-Identifier: GPL-3.0-or-later
# FileType: SOURCE
# SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
# SPDX-FileCopyrightText: 2025, "Eva Boergens" at GFZ Potsdam
"""Processing module for geogravL3 containing everything related to the processing pipeline."""

from . import grid_processing
from . import shc_processing
from . import l4_processing
from . import spherical_harmonics
from . timeseries import timeseries

__all__ = [
    "grid_processing",
    "shc_processing",
    "l4_processing",
    "spherical_harmonics",
    "timeseries",
]
