# SPDX-License-Identifier: GPL-3.0-or-later
# FileType: SOURCE
# SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
# SPDX-FileCopyrightText: 2025, "Eva Boergens" at GFZ Potsdam
"""Module for processing of spherical harmonic coefficients."""

from .run_filter import run_filter
from .ddk_filter import ddk_filter
from .vdk_filter_functions import vdk_filter
from .gaussian_filter import gaussian_filter
from .degree_1_terms import estimate_degree1_sh
from .replace_low_degrees import replace_low_degrees
from .gia_correction import reduce_gia_model
from .s2_aliased_signal import remove_s2_alias


__all__ = [
    # filters
    "run_filter",
    "ddk_filter",
    "vdk_filter",
    "gaussian_filter",
    # SHC corrections
    "estimate_degree1_sh",
    "replace_low_degrees",
    "reduce_gia_model",
    "remove_s2_alias",
]
