# AGENTS.md

Guidance for AI agents working on this repository.

## Project Overview

`dbcraft` is a pure-Python library for reading, writing, and creating WoW 3.3.5a (build 12340) DBC files. It uses a core binary engine plus a template system: Python dataclasses define each DBC file's record structure, and the engine handles all binary serialization. All 246 WoW 3.3.5a DBC tables are supported with byte-identical roundtrip fidelity.

## Architecture

```
dbcraft/
├── __init__.py                  # Public API: DbcFile, type aliases, re-exports all 246 record classes
├── dbc_file.py                  # High-level DbcFile class (read/write/create)
├── core/
│   ├── types.py                 # Field types: uint32, int32, int8, float32, string_ref, loc_string_ref, LocalizedString
│   ├── string_block.py          # StringBlockReader + StringBlockBuilder (with deduplication)
│   ├── header.py                # DbcHeader (parse/serialize the 20-byte WDBC header)
│   ├── reader.py                # read_dbc() — binary DBC -> record list
│   └── writer.py                # write_dbc() — record list -> binary DBC
└── templates/
    ├── __init__.py              # Auto-generated: imports all 246 templates for registration
    ├── base.py                  # Template registry, get_field_count, get_record_size, serialize/deserialize
    ├── achievement.py           # AchievementRecord
    ├── spell.py                 # SpellRecord (234 fields)
    ├── ...                      # 246 template files total, one per DBC table
    └── zone_music.py            # ZoneMusicRecord

scripts/
└── generate_templates.py        # Generator: reads DBC_SCHEMA.json, produces all 246 template .py files + __init__.py

DBC_SCHEMA.json                  # Machine-readable schema for all 246 tables
exampleDBCs/                     # 246 real 3.3.5a DBC files (not committed, used as golden reference)
docs/template_coverage.md        # Per-table status report
```

## Key Conventions

- **Python 3.10+**, no runtime dependencies. Dev: `pytest`, `pytest-cov`.
- **No raw/untyped mode.** Every DBC file must have a registered template. `get_template()` raises `KeyError` if the name is not registered.
- **Field types** are `NewType` aliases (`uint32`, `int32`, `int8`, `float32`, `string_ref`, `loc_string_ref`). Type identity is checked via `__name__` in `_resolve_type_name`.
- **`int8` fields** are truly packed (1 byte each). 5 tables use them: `CharBaseInfo`, `CharStartOutfit`, `PowerDisplay`, `SpellChainEffects`, `SpellItemEnchantmentCondition`.
- **`loc_string_ref`** expands to 17 uint32 fields on disk (16 locale string offsets + 1 flags field). Access locales by name: `.en_us`, `.de_de`, etc.
- **All 246 templates are generated** from `DBC_SCHEMA.json` via `scripts/generate_templates.py`. Field names come from the schema (e.g., `texture_filename`, not `icon_path`). Do not hand-edit generated template files — regenerate instead.
- **`base.py` is the only hand-maintained file** in `dbcraft/templates/`. The generator preserves it during regeneration.
- **Template registration** is done with `@register_template("Name")` on each dataclass. All 246 templates are imported in `templates/__init__.py` so they auto-register on `import dbcraft`.
- **String block** starts with a null byte at offset 0 (empty string sentinel). Strings are deduplicated by `StringBlockBuilder`.
- **`DbcFile.read(path)`** derives the template name from the filename stem. The template lookup happens before the file is opened, so `KeyError` is raised before `FileNotFoundError` if the stem is not registered.
- **Source-byte caching** in `DbcFile.to_bytes()` returns original bytes if records haven't been modified, preventing string-block reordering issues.
- **23 tables have no primary key** (all `gt*` game tables, `CharBaseInfo`, etc.). Their first field gets a default value instead of being positional.
- **6 tables have underscores** in DBC names: `Achievement_Category`, `Achievement_Criteria`, `Cfg_Categories`, `Cfg_Configs`, `Startup_Strings`, `WowError_Strings`. Class names strip underscores (e.g., `AchievementCategoryRecord`).

## Schema Type Mappings

When working with `DBC_SCHEMA.json`:
- `int32` → `int32`
- `float` → `float32`
- `string_ref` → `string_ref`
- `string_ref_loc` → `loc_string_ref`
- `int8` → `int8`
- Arrays like `int32[n]` → expanded to `n` individual `int32` fields with `_0.._n-1` suffixes
- Struct arrays like `AuraMod[3]` → 3× `int32`

## Testing

- **100% code coverage is required** at all times. The CI gate is `--cov-fail-under=100`.
- Run the full suite: `python -m pytest -v`
- Run without sample compatibility (faster): `python -m pytest -v --ignore=tests/test_sample_compatibility.py`
- Coverage config in `pyproject.toml` includes `exclude_also = ["case .*:"]` to suppress false-positive branch misses from `match`/`case`.
- Test layout:
  - `tests/core/` — unit tests for each core module
  - `tests/templates/test_base.py` — registry and serialize/deserialize logic
  - `tests/templates/test_templates.py` — per-template: registration, field count, construction, core roundtrip (13 key templates)
  - `tests/test_dbc_file.py` — DbcFile API (create, read, write, from_bytes, to_bytes)
  - `tests/test_roundtrip.py` — integration tests: full file I/O roundtrips, byte-fidelity checks, header validation, string deduplication, mutation safety (scalar, string_ref, loc_string_ref, array, int8 buckets)
  - `tests/test_sample_compatibility.py` — roundtrip tests against all 245 real 3.3.5a DBC files in `exampleDBCs/` (skipped gracefully if directory is absent)
  - `tests/conftest.py` — shared fixtures (`SimpleTestRecord`, `StringTestRecord`, `LocTestRecord`) with registry cleanup

## Regenerating Templates

To regenerate all 246 templates from the schema:

1. Run `python scripts/generate_templates.py`
2. This overwrites all `.py` files in `dbcraft/templates/` except `base.py`.
3. Run `python -m pytest -v` and confirm 100% coverage.
4. If `exampleDBCs/` is present, run sample compatibility tests to verify byte-identical roundtrips.

## Bumping the Version

The version is stored in a single place: `pyproject.toml` under `[project] version`.

1. Update the `version` field in `pyproject.toml`.
2. Commit with message `chore: bump package version to <version>`.
3. Tag the commit: `git tag v<version>`.

## Adding a New Template

New tables should be added to `DBC_SCHEMA.json` and regenerated. If manual creation is needed:

1. Create `dbcraft/templates/<name>.py` with a `@register_template("<Name>")` `@dataclass`.
2. Add the import to `dbcraft/templates/__init__.py`.
3. Add tests in `tests/templates/test_templates.py`: registration, field count, construction, roundtrip.
4. Add integration tests in `tests/test_roundtrip.py`: file I/O, byte fidelity, header values.
5. Verify field count against [wowdev.wiki](https://wowdev.wiki/) for build 12340.
6. Run `python -m pytest -v` and confirm 100% coverage.
