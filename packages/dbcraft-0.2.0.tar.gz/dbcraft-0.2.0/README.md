# dbcraft

A pure-Python library for reading, writing, and creating WoW 3.3.5a (build 12340) DBC files.

- All 246 client DBC tables supported
- Byte-identical roundtrip fidelity (`read -> write` produces identical bytes)
- Typed dataclass records with named fields for every table
- No runtime dependencies
- Python 3.10+

## Installation

Install from PyPI:

```bash
pip install dbcraft
```

Or install from source:

```bash
git clone https://github.com/slipo335/dbcraft.git
cd dbcraft
pip install .
```

For development (includes pytest and coverage):

```bash
pip install -e ".[dev]"
```

## Usage

### Reading a DBC file

```python
from dbcraft import DbcFile

# Template is auto-detected from the filename
dbc = DbcFile.read("Spell.dbc")

print(f"Loaded {len(dbc)} spells")

for spell in dbc.records[:5]:
    print(f"  [{spell.id}] {spell.name_lang.en_us}")
```

### Modifying and writing a DBC file

```python
from dbcraft import DbcFile

dbc = DbcFile.read("Spell.dbc")

# Find a spell by id and rename it
for spell in dbc.records:
    if spell.id == 133:  # Fireball
        spell.name_lang.en_us = "Super Fireball"
        spell.name_lang.de_de = "Superfeuerball"
        break

# Write the modified file
dbc.write("Spell_modified.dbc")
```

### Creating a DBC file from scratch

```python
from dbcraft import DbcFile, SpellIconRecord

# Create an empty DBC
dbc = DbcFile.create("SpellIcon")

# Add records
dbc.records.append(SpellIconRecord(id=1, texture_filename="Interface\\Icons\\Spell_Fire_FlameBolt"))
dbc.records.append(SpellIconRecord(id=2, texture_filename="Interface\\Icons\\Spell_Frost_FrostBolt02"))
dbc.records.append(SpellIconRecord(id=3, texture_filename="Interface\\Icons\\Spell_Holy_HolyBolt"))

# Write to disk
dbc.write("SpellIcon.dbc")
```

### Other useful operations

```python
from dbcraft import DbcFile, ItemRecord

dbc = DbcFile.read("Item.dbc")

# Upsert: insert or replace a record by id
dbc.upsert(ItemRecord(id=12345, class_id=2, subclass_id=7))

# Sort records by id
dbc.sort_by_id()

# Serialize to bytes without writing to disk
raw_bytes = dbc.to_bytes()

# Parse from raw bytes
dbc2 = DbcFile.from_bytes(raw_bytes, "Item")
```

## Supported Tables

All 246 DBC tables from WoW 3.3.5a (build 12340) are supported, including:

`Achievement`, `AreaTable`, `AuctionHouse`, `CharTitles`, `ChrClasses`, `ChrRaces`, `CreatureDisplayInfo`, `CreatureModelData`, `Faction`, `FactionTemplate`, `GameObjectDisplayInfo`, `GemProperties`, `GlyphProperties`, `Item`, `ItemDisplayInfo`, `ItemExtendedCost`, `ItemRandomProperties`, `ItemRandomSuffix`, `ItemSet`, `LFGDungeons`, `Light`, `Lock`, `Map`, `SkillLine`, `SkillLineAbility`, `SoundEntries`, `Spell`, `SpellCastTimes`, `SpellDuration`, `SpellIcon`, `SpellItemEnchantment`, `SpellRadius`, `SpellRange`, `SpellVisual`, `Talent`, `TalentTab`, `TaxiNodes`, `TaxiPath`, `Vehicle`, `VehicleSeat`, `WorldMapArea`, `WorldSafeLocs`, `ZoneMusic`, and 203 more.

Every record class is a Python dataclass with named, typed fields derived from the [wowdev.wiki](https://wowdev.wiki/) schema for build 12340.

## License

[MIT](LICENSE)
