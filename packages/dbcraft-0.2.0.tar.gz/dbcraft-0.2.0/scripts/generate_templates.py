#!/usr/bin/env python3
"""Generate static template .py files for all DBC tables.

Reads ``DBC_SCHEMA.json`` from the repository root and produces one Python
module per table in ``dbcraft/templates/``.  Also regenerates
``dbcraft/templates/__init__.py`` with all imports and ``__all__``.

Usage::

    python scripts/generate_templates.py

Re-run whenever ``DBC_SCHEMA.json`` changes.
"""

from __future__ import annotations

import json
import keyword
import re
import textwrap
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = REPO_ROOT / "DBC_SCHEMA.json"
TEMPLATES_DIR = REPO_ROOT / "dbcraft" / "templates"

# Files that should never be overwritten or deleted by the generator.
PROTECTED_FILES = {"__init__.py", "base.py", "__pycache__"}


# ---------------------------------------------------------------------------
# Naming helpers
# ---------------------------------------------------------------------------

def _dbc_name_to_module(dbc_name: str) -> str:
    """Convert a DBC table name to a Python module filename (without .py).

    Examples:
        Achievement -> achievement
        CharTitles -> char_titles
        ChrRaces -> chr_races
        Achievement_Category -> achievement_category
        Cfg_Categories -> cfg_categories
        gtBarberShopCostBase -> gt_barber_shop_cost_base
    """
    # First, replace explicit underscores in the DBC name with a marker
    # so they don't get doubled during CamelCase splitting.
    name = dbc_name.replace("_", " ")
    # Insert underscore before uppercase letters (CamelCase -> snake_case)
    name = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    name = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", name)
    # Restore spaces to underscores and lowercase
    name = name.replace(" ", "_").lower()
    # Collapse multiple underscores
    name = re.sub(r"_+", "_", name)
    return name


def _dbc_name_to_class(dbc_name: str) -> str:
    """Convert a DBC table name to a PascalCase class name with 'Record' suffix.

    Examples:
        Achievement -> AchievementRecord
        Achievement_Category -> AchievementCategoryRecord
        gtBarberShopCostBase -> GtBarberShopCostBaseRecord
    """
    # Split on underscores and non-alpha boundaries, then PascalCase each part
    parts = re.split(r"[_\W]+", dbc_name)
    pascal = "".join(p[:1].upper() + p[1:] for p in parts if p)
    return f"{pascal}Record"


def _sanitize_field_name(name: str) -> str:
    """Sanitize a schema field name to a valid Python identifier."""
    cleaned = re.sub(r"\W", "_", name)
    if not cleaned:
        cleaned = "field"
    if cleaned[0].isdigit():
        cleaned = f"field_{cleaned}"
    if keyword.iskeyword(cleaned):
        cleaned = f"{cleaned}_"
    return cleaned


# ---------------------------------------------------------------------------
# Schema type -> Python type mapping
# ---------------------------------------------------------------------------

# Maps schema type name to (python_type_str, default_expr_str, import_name)
_SCALAR_MAP: dict[str, tuple[str, str, str]] = {
    "int32": ("int32", "int32(0)", "int32"),
    "float": ("float32", "float32(0.0)", "float32"),
    "string_ref": ("string_ref", 'string_ref("")', "string_ref"),
    "string_ref_loc": ("loc_string_ref", "field(default_factory=LocalizedString)", "loc_string_ref"),
    "int8": ("int8", "int8(0)", "int8"),
    "AuraMod": ("int32", "int32(0)", "int32"),
}

_ARRAY_RE = re.compile(r"^(?P<base>[A-Za-z0-9_]+)\[(?P<count>\d+)\]$")


def _expand_field(name: str, schema_type: str) -> list[tuple[str, str, str, str]]:
    """Expand a schema field into (field_name, type_str, default_str, import_name) tuples."""
    m = _ARRAY_RE.match(schema_type)
    if m:
        base = m.group("base")
        count = int(m.group("count"))
        type_str, default_str, import_name = _SCALAR_MAP[base]
        return [
            (_sanitize_field_name(f"{name}_{i}"), type_str, default_str, import_name)
            for i in range(count)
        ]

    type_str, default_str, import_name = _SCALAR_MAP[schema_type]
    return [(_sanitize_field_name(name), type_str, default_str, import_name)]


# ---------------------------------------------------------------------------
# Record size calculation (for docstring)
# ---------------------------------------------------------------------------

def _calc_sizes(fields: list[tuple[str, str, str, str]]) -> tuple[int, int]:
    """Return (field_count, record_size_bytes) for expanded fields."""
    field_count = 0
    byte_size = 0
    for _, type_str, _, _ in fields:
        if type_str == "loc_string_ref":
            field_count += 17
            byte_size += 17 * 4
        elif type_str == "int8":
            field_count += 1
            byte_size += 1
        else:
            field_count += 1
            byte_size += 4
    return field_count, byte_size


# ---------------------------------------------------------------------------
# Code generation
# ---------------------------------------------------------------------------

def _generate_module(dbc_name: str, table: dict) -> str:
    """Generate the complete Python source for one template module."""
    class_name = _dbc_name_to_class(dbc_name)

    # Expand all fields
    expanded: list[tuple[str, str, str, str]] = []
    for raw_field in table.get("fields", []):
        expanded.extend(_expand_field(raw_field["name"], raw_field["type"]))

    # Deduplicate field names
    seen: set[str] = set()
    deduped: list[tuple[str, str, str, str]] = []
    for fname, ftype, fdefault, fimport in expanded:
        original = fname
        if fname in seen:
            suffix = 1
            while f"{fname}_{suffix}" in seen:
                suffix += 1
            fname = f"{fname}_{suffix}"
        seen.add(fname)
        deduped.append((fname, ftype, fdefault, fimport))
    expanded = deduped

    field_count, record_size = _calc_sizes(expanded)

    # Determine which type imports we need
    needed_types: set[str] = set()
    needs_localized_string = False
    needs_field_import = False
    for _, ftype, fdefault, fimport in expanded:
        needed_types.add(fimport)
        if ftype == "loc_string_ref":
            needs_localized_string = True
            needs_field_import = True

    # Sort type imports for deterministic output
    type_imports = sorted(needed_types)
    if needs_localized_string:
        type_imports.append("LocalizedString")
        type_imports.sort()

    # Build the size description for docstring
    type_counts: dict[str, int] = {}
    for _, ftype, _, _ in expanded:
        if ftype == "loc_string_ref":
            type_counts["loc_string_ref"] = type_counts.get("loc_string_ref", 0) + 1
        elif ftype == "int8":
            type_counts["int8"] = type_counts.get("int8", 0) + 1
        elif ftype == "float32":
            type_counts["float32"] = type_counts.get("float32", 0) + 1
        elif ftype == "string_ref":
            type_counts["string_ref"] = type_counts.get("string_ref", 0) + 1
        else:
            type_counts["int32"] = type_counts.get("int32", 0) + 1

    breakdown_parts = []
    for tname in ["int32", "float32", "string_ref", "int8", "loc_string_ref"]:
        cnt = type_counts.get(tname, 0)
        if cnt > 0:
            if tname == "loc_string_ref":
                breakdown_parts.append(f"{cnt} loc_string_ref field{'s' if cnt > 1 else ''} ({cnt} x 17 = {cnt * 17} on disk)")
            elif tname == "int8":
                breakdown_parts.append(f"{cnt} int8 field{'s' if cnt > 1 else ''} (1 byte each)")
            else:
                breakdown_parts.append(f"{cnt} {tname} field{'s' if cnt > 1 else ''}")

    breakdown_lines = "\n".join(f"  - {p}" for p in breakdown_parts)

    # Build record size expression
    size_parts = []
    non_int8_4byte = field_count - type_counts.get("int8", 0)
    int8_count = type_counts.get("int8", 0)
    if non_int8_4byte > 0:
        size_parts.append(f"{non_int8_4byte} * 4")
    if int8_count > 0:
        size_parts.append(f"{int8_count} * 1")
    size_expr = " + ".join(size_parts)

    # Build module docstring
    module_doc = f'"""{dbc_name}.dbc template for WoW 3.3.5a (build 12340).\n\nField count breakdown:\n{breakdown_lines}\n  - Total: {field_count} fields on disk\n\nRecord size: {size_expr} = {record_size} bytes\n\nSee Also:\n  - https://wowdev.wiki/DB/{dbc_name}\n"""'

    # Build imports
    lines: list[str] = []
    lines.append(module_doc)
    lines.append("")
    lines.append("from __future__ import annotations")
    lines.append("")

    dataclass_imports = ["dataclass"]
    if needs_field_import:
        dataclass_imports.append("field")
    lines.append(f"from dataclasses import {', '.join(dataclass_imports)}")
    lines.append("")
    lines.append(f"from dbcraft.core.types import {', '.join(type_imports)}")
    lines.append("from dbcraft.templates.base import register_template")
    lines.append("")
    lines.append("")
    lines.append(f'@register_template("{dbc_name}")')
    lines.append("@dataclass")
    lines.append(f"class {class_name}:")
    lines.append(f'    """A record from {dbc_name}.dbc (3.3.5a, build 12340)."""')

    # Determine if first field should be positional (no default)
    has_pk = table.get("primary_key") is not None

    for i, (fname, ftype, fdefault, _) in enumerate(expanded):
        lines.append("")
        if i == 0 and has_pk:
            # First field is the primary key -- no default
            lines.append(f"    {fname}: {ftype}")
        else:
            lines.append(f"    {fname}: {ftype} = {fdefault}")

    lines.append("")
    return "\n".join(lines)


def _generate_init(modules: list[tuple[str, str, str]]) -> str:
    """Generate __init__.py content.

    Args:
        modules: list of (module_name, class_name, dbc_name) sorted by module_name.
    """
    lines: list[str] = []
    lines.append('"""dbcraft templates - DBC record definitions for WoW 3.3.5a."""')
    lines.append("")
    lines.append("# Import all templates so they auto-register on package import.")

    for mod_name, cls_name, _ in modules:
        lines.append(f"from dbcraft.templates.{mod_name} import {cls_name}")

    lines.append("")
    lines.append("__all__ = [")
    for _, cls_name, _ in modules:
        lines.append(f'    "{cls_name}",')
    lines.append("]")
    lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    tables = schema["tables"]

    # Clean up old generated template files (keep protected files)
    for existing in TEMPLATES_DIR.iterdir():
        if existing.name in PROTECTED_FILES:
            continue
        if existing.suffix == ".py":
            existing.unlink()
            print(f"  Removed old: {existing.name}")

    # Generate all template modules
    modules: list[tuple[str, str, str]] = []  # (module_name, class_name, dbc_name)

    for dbc_name in sorted(tables.keys()):
        table = tables[dbc_name]
        mod_name = _dbc_name_to_module(dbc_name)
        cls_name = _dbc_name_to_class(dbc_name)

        source = _generate_module(dbc_name, table)
        out_path = TEMPLATES_DIR / f"{mod_name}.py"
        out_path.write_text(source, encoding="utf-8")
        modules.append((mod_name, cls_name, dbc_name))

    print(f"Generated {len(modules)} template modules in {TEMPLATES_DIR}")

    # Generate __init__.py
    modules.sort()
    init_source = _generate_init(modules)
    init_path = TEMPLATES_DIR / "__init__.py"
    init_path.write_text(init_source, encoding="utf-8")
    print(f"Generated {init_path}")

    # Summary
    print(f"\nDone! {len(modules)} templates generated.")


if __name__ == "__main__":
    main()
