"""Field type definitions for DBC record templates.

Provides type aliases and classes used in DBC record dataclass annotations
to drive serialization and deserialization of binary DBC data.

WoW 3.3.5a DBC files use 4-byte aligned fields:
- uint32: unsigned 32-bit integer
- int32: signed 32-bit integer
- int8: signed 8-bit integer
- float32: 32-bit IEEE 754 float
- string_ref: uint32 offset into the string block
- loc_string_ref: 16 locale string offsets + 1 flags field = 17 uint32 values

All fields are little-endian.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import NewType

# Primitive field type markers.
# These are used as type annotations in record dataclasses.
# The reader/writer uses these to determine binary format.
uint32 = NewType("uint32", int)
int32 = NewType("int32", int)
int8 = NewType("int8", int)
float32 = NewType("float32", float)
string_ref = NewType("string_ref", str)

# Locale indices for WotLK 3.3.5a (16 locale slots + 1 flags)
LOCALE_EN_US = 0
LOCALE_KO_KR = 1
LOCALE_FR_FR = 2
LOCALE_DE_DE = 3
LOCALE_ZH_CN = 4
LOCALE_ZH_TW = 5
LOCALE_ES_ES = 6
LOCALE_ES_MX = 7
LOCALE_RU_RU = 8
LOCALE_JA_JP = 9
LOCALE_PT_PT = 10
LOCALE_IT_IT = 11
LOCALE_UNK_12 = 12
LOCALE_UNK_13 = 13
LOCALE_UNK_14 = 14
LOCALE_UNK_15 = 15

LOCALE_COUNT = 16
LOC_FIELD_COUNT = LOCALE_COUNT + 1  # 16 locales + 1 flags field = 17

LOCALE_NAMES: tuple[str, ...] = (
    "en_us",
    "ko_kr",
    "fr_fr",
    "de_de",
    "zh_cn",
    "zh_tw",
    "es_es",
    "es_mx",
    "ru_ru",
    "ja_jp",
    "pt_pt",
    "it_it",
    "unk_12",
    "unk_13",
    "unk_14",
    "unk_15",
)

_LOCALE_NAME_TO_INDEX: dict[str, int] = {name: i for i, name in enumerate(LOCALE_NAMES)}


@dataclass
class LocalizedString:
    """A localized string with 16 locale slots and a flags bitmask.

    Provides named property access for each locale (e.g. `.en_us`, `.de_de`)
    and index-based access via `[]`.

    In the binary DBC format, each locale slot is a uint32 offset into the
    string block. This class stores the resolved string values, not the
    raw offsets. The writer converts back to offsets during serialization.
    """

    _strings: list[str] = field(default_factory=lambda: [""] * LOCALE_COUNT)
    flags: int = 0

    def __post_init__(self) -> None:
        if len(self._strings) != LOCALE_COUNT:
            raise ValueError(
                f"LocalizedString requires exactly {LOCALE_COUNT} locale strings, "
                f"got {len(self._strings)}"
            )

    def __getitem__(self, index: int) -> str:
        if not 0 <= index < LOCALE_COUNT:
            raise IndexError(
                f"Locale index {index} out of range (0-{LOCALE_COUNT - 1})"
            )
        return self._strings[index]

    def __setitem__(self, index: int, value: str) -> None:
        if not 0 <= index < LOCALE_COUNT:
            raise IndexError(
                f"Locale index {index} out of range (0-{LOCALE_COUNT - 1})"
            )
        self._strings[index] = value

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, LocalizedString):
            return NotImplemented
        return self._strings == other._strings and self.flags == other.flags

    def __repr__(self) -> str:
        non_empty = {
            LOCALE_NAMES[i]: s for i, s in enumerate(self._strings) if s
        }
        return f"LocalizedString({non_empty!r}, flags={self.flags})"

    def get_by_name(self, locale_name: str) -> str:
        """Get the string for a locale by its name (e.g. 'en_us')."""
        index = _LOCALE_NAME_TO_INDEX.get(locale_name)
        if index is None:
            raise KeyError(f"Unknown locale name: {locale_name!r}")
        return self._strings[index]

    def set_by_name(self, locale_name: str, value: str) -> None:
        """Set the string for a locale by its name (e.g. 'en_us')."""
        index = _LOCALE_NAME_TO_INDEX.get(locale_name)
        if index is None:
            raise KeyError(f"Unknown locale name: {locale_name!r}")
        self._strings[index] = value

    # Named locale properties for the most common locales.
    @property
    def en_us(self) -> str:
        return self._strings[LOCALE_EN_US]

    @en_us.setter
    def en_us(self, value: str) -> None:
        self._strings[LOCALE_EN_US] = value

    @property
    def ko_kr(self) -> str:
        return self._strings[LOCALE_KO_KR]

    @ko_kr.setter
    def ko_kr(self, value: str) -> None:
        self._strings[LOCALE_KO_KR] = value

    @property
    def fr_fr(self) -> str:
        return self._strings[LOCALE_FR_FR]

    @fr_fr.setter
    def fr_fr(self, value: str) -> None:
        self._strings[LOCALE_FR_FR] = value

    @property
    def de_de(self) -> str:
        return self._strings[LOCALE_DE_DE]

    @de_de.setter
    def de_de(self, value: str) -> None:
        self._strings[LOCALE_DE_DE] = value

    @property
    def zh_cn(self) -> str:
        return self._strings[LOCALE_ZH_CN]

    @zh_cn.setter
    def zh_cn(self, value: str) -> None:
        self._strings[LOCALE_ZH_CN] = value

    @property
    def zh_tw(self) -> str:
        return self._strings[LOCALE_ZH_TW]

    @zh_tw.setter
    def zh_tw(self, value: str) -> None:
        self._strings[LOCALE_ZH_TW] = value

    @property
    def es_es(self) -> str:
        return self._strings[LOCALE_ES_ES]

    @es_es.setter
    def es_es(self, value: str) -> None:
        self._strings[LOCALE_ES_ES] = value

    @property
    def es_mx(self) -> str:
        return self._strings[LOCALE_ES_MX]

    @es_mx.setter
    def es_mx(self, value: str) -> None:
        self._strings[LOCALE_ES_MX] = value

    @property
    def ru_ru(self) -> str:
        return self._strings[LOCALE_RU_RU]

    @ru_ru.setter
    def ru_ru(self, value: str) -> None:
        self._strings[LOCALE_RU_RU] = value

    @property
    def ja_jp(self) -> str:
        return self._strings[LOCALE_JA_JP]

    @ja_jp.setter
    def ja_jp(self, value: str) -> None:
        self._strings[LOCALE_JA_JP] = value

    @property
    def pt_pt(self) -> str:
        return self._strings[LOCALE_PT_PT]

    @pt_pt.setter
    def pt_pt(self, value: str) -> None:
        self._strings[LOCALE_PT_PT] = value

    @property
    def it_it(self) -> str:
        return self._strings[LOCALE_IT_IT]

    @it_it.setter
    def it_it(self, value: str) -> None:
        self._strings[LOCALE_IT_IT] = value

    @property
    def unk_12(self) -> str:
        return self._strings[LOCALE_UNK_12]

    @unk_12.setter
    def unk_12(self, value: str) -> None:
        self._strings[LOCALE_UNK_12] = value

    @property
    def unk_13(self) -> str:
        return self._strings[LOCALE_UNK_13]

    @unk_13.setter
    def unk_13(self, value: str) -> None:
        self._strings[LOCALE_UNK_13] = value

    @property
    def unk_14(self) -> str:
        return self._strings[LOCALE_UNK_14]

    @unk_14.setter
    def unk_14(self, value: str) -> None:
        self._strings[LOCALE_UNK_14] = value

    @property
    def unk_15(self) -> str:
        return self._strings[LOCALE_UNK_15]

    @unk_15.setter
    def unk_15(self, value: str) -> None:
        self._strings[LOCALE_UNK_15] = value


# Type alias used in record dataclass annotations.
# The actual runtime type is LocalizedString, but this NewType marker
# lets the template introspection system distinguish it from other fields.
loc_string_ref = NewType("loc_string_ref", LocalizedString)
