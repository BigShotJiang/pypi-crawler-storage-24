"""dbcraft core module - DBC binary format handling."""
