"""String block handling for DBC files.

DBC files store strings in a contiguous block at the end of the file.
Record fields contain uint32 offsets into this block. Strings are
null-terminated C strings.

The block always starts with a null byte at offset 0, which serves
as the empty string sentinel.
"""

from __future__ import annotations


class StringBlockReader:
    """Reads strings from a raw string block by offset.

    The string block is a bytes object containing null-terminated strings.
    Each string can be looked up by its byte offset within the block.
    """

    def __init__(self, data: bytes) -> None:
        self._data = data

    def get(self, offset: int) -> str:
        """Read a null-terminated string starting at the given offset.

        Args:
            offset: Byte offset into the string block.

        Returns:
            The decoded string (empty string for offset 0 in a valid block).

        Raises:
            ValueError: If offset is out of range or no null terminator found.
        """
        if offset < 0 or offset >= len(self._data):
            raise ValueError(
                f"String offset {offset} out of range "
                f"(block size: {len(self._data)})"
            )
        end = self._data.index(b"\x00", offset)
        return self._data[offset:end].decode("utf-8")

    @property
    def size(self) -> int:
        """Return the size of the string block in bytes."""
        return len(self._data)


class StringBlockBuilder:
    """Builds a string block for writing DBC files.

    Collects strings, deduplicates them, and produces the final
    bytes blob with a mapping from string -> offset.

    The block always starts with a single null byte (offset 0 = empty string).
    """

    def __init__(self) -> None:
        self._strings: dict[str, int] = {}
        # Start with a null byte at offset 0 for empty strings.
        self._buffer = bytearray(b"\x00")

    def add(self, value: str) -> int:
        """Add a string to the block and return its offset.

        If the string was already added, returns the existing offset
        (deduplication). Empty strings always return offset 0.

        Args:
            value: The string to add.

        Returns:
            The byte offset of the string in the block.
        """
        if not value:
            return 0

        if value in self._strings:
            return self._strings[value]

        offset = len(self._buffer)
        self._strings[value] = offset
        self._buffer.extend(value.encode("utf-8"))
        self._buffer.append(0)  # null terminator
        return offset

    def build(self) -> bytes:
        """Return the completed string block as bytes."""
        return bytes(self._buffer)

    @property
    def size(self) -> int:
        """Return the current size of the string block in bytes."""
        return len(self._buffer)
