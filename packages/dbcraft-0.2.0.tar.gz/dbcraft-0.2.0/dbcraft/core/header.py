"""DBC file header parsing and serialization.

The DBC header is a fixed 20-byte structure at the start of every DBC file:

    struct dbc_header {
        uint32_t magic;             // always 'WDBC' (0x43424457)
        uint32_t record_count;      // number of records
        uint32_t field_count;       // number of logical fields per record
        uint32_t record_size;       // bytes per record
        uint32_t string_block_size; // size of string block in bytes
    };

All values are little-endian unsigned 32-bit integers.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass

DBC_MAGIC = b"WDBC"
DBC_MAGIC_INT = 0x43424457
HEADER_SIZE = 20
HEADER_FORMAT = "<5I"  # 5 little-endian uint32


@dataclass
class DbcHeader:
    """Represents the 20-byte header of a DBC file."""

    record_count: int
    field_count: int
    record_size: int
    string_block_size: int

    @classmethod
    def parse(cls, data: bytes) -> DbcHeader:
        """Parse a DBC header from raw bytes.

        Args:
            data: At least 20 bytes of raw data.

        Returns:
            A DbcHeader instance.

        Raises:
            ValueError: If data is too short or magic bytes are invalid.
        """
        if len(data) < HEADER_SIZE:
            raise ValueError(
                f"DBC header requires {HEADER_SIZE} bytes, "
                f"got {len(data)}"
            )

        magic, record_count, field_count, record_size, string_block_size = (
            struct.unpack_from(HEADER_FORMAT, data)
        )

        if magic != DBC_MAGIC_INT:
            raise ValueError(
                f"Invalid DBC magic: expected {DBC_MAGIC!r}, "
                f"got {struct.pack('<I', magic)!r}"
            )

        return cls(
            record_count=record_count,
            field_count=field_count,
            record_size=record_size,
            string_block_size=string_block_size,
        )

    def to_bytes(self) -> bytes:
        """Serialize the header to 20 bytes.

        Returns:
            The header as raw bytes.
        """
        return struct.pack(
            HEADER_FORMAT,
            DBC_MAGIC_INT,
            self.record_count,
            self.field_count,
            self.record_size,
            self.string_block_size,
        )
