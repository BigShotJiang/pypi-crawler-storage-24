"""DBC file writer - serializes typed record lists to binary DBC data.

Takes a list of record instances and produces a complete DBC file
(header + records + string block) as bytes.
"""

from __future__ import annotations

from typing import Any

from dbcraft.core.header import DbcHeader
from dbcraft.core.string_block import StringBlockBuilder
from dbcraft.templates.base import get_field_count, get_record_size, serialize_record


def write_dbc(records: list[Any], record_cls: type) -> bytes:
    """Write a list of records to raw DBC file bytes.

    Args:
        records: List of record dataclass instances.
        record_cls: The record dataclass type (used for field introspection).

    Returns:
        The complete DBC file as raw bytes.
    """
    field_count = get_field_count(record_cls)
    record_size = get_record_size(record_cls)

    string_block_builder = StringBlockBuilder()

    # Serialize all records, collecting strings as we go.
    record_data_parts: list[bytes] = []
    for record in records:
        record_bytes = serialize_record(record, string_block_builder)
        if len(record_bytes) != record_size:
            raise ValueError(
                f"Serialized record size mismatch: expected {record_size} bytes, "
                f"got {len(record_bytes)}"
            )
        record_data_parts.append(record_bytes)

    string_block = string_block_builder.build()

    header = DbcHeader(
        record_count=len(records),
        field_count=field_count,
        record_size=record_size,
        string_block_size=len(string_block),
    )

    return header.to_bytes() + b"".join(record_data_parts) + string_block
