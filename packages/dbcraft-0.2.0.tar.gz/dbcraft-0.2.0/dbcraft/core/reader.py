"""DBC file reader - parses binary DBC data into typed record lists.

Reads a complete DBC file (header + records + string block) and returns
deserialized record instances using the appropriate template.
"""

from __future__ import annotations

from typing import Any

from dbcraft.core.header import HEADER_SIZE, DbcHeader
from dbcraft.core.string_block import StringBlockReader
from dbcraft.templates.base import deserialize_record, get_field_count, get_record_size


def read_dbc(data: bytes, record_cls: type) -> tuple[DbcHeader, list[Any]]:
    """Read a DBC file from raw bytes into a header and list of records.

    Args:
        data: The complete raw DBC file contents.
        record_cls: The record dataclass type to deserialize into.

    Returns:
        A tuple of (header, records) where records is a list of
        record_cls instances.

    Raises:
        ValueError: If the data is invalid, too short, or the template's
            field count doesn't match the header's field count.
    """
    header = DbcHeader.parse(data)

    expected_field_count = get_field_count(record_cls)
    if header.field_count != expected_field_count:
        raise ValueError(
            f"Template field count mismatch: header says {header.field_count} "
            f"fields, but template {record_cls.__name__} has "
            f"{expected_field_count} fields"
        )

    expected_record_size = get_record_size(record_cls)
    if header.record_size != expected_record_size:
        raise ValueError(
            f"Template record size mismatch: header says {header.record_size} "
            f"bytes, but template {record_cls.__name__} has "
            f"{expected_record_size} bytes"
        )

    records_start = HEADER_SIZE
    records_end = records_start + (header.record_count * header.record_size)
    expected_total = records_end + header.string_block_size

    if len(data) < expected_total:
        raise ValueError(
            f"DBC file too short: expected at least {expected_total} bytes, "
            f"got {len(data)}"
        )

    string_block_data = data[records_end : records_end + header.string_block_size]
    string_block = StringBlockReader(string_block_data)

    records: list[Any] = []
    for i in range(header.record_count):
        offset = records_start + (i * header.record_size)
        record = deserialize_record(record_cls, data, offset, string_block)
        records.append(record)

    return header, records
