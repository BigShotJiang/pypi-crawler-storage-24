"""FactionGroup.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 1 string_ref field
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 20 fields on disk

Record size: 20 * 4 = 80 bytes

See Also:
  - https://wowdev.wiki/DB/FactionGroup
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("FactionGroup")
@dataclass
class FactionGroupRecord:
    """A record from FactionGroup.dbc (3.3.5a, build 12340)."""

    id: int32

    mask_id: int32 = int32(0)

    internal_name: string_ref = string_ref("")

    name_lang: loc_string_ref = field(default_factory=LocalizedString)
