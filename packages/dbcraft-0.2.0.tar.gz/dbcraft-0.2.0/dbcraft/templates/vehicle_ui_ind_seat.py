"""VehicleUIIndSeat.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 2 float32 fields
  - Total: 5 fields on disk

Record size: 5 * 4 = 20 bytes

See Also:
  - https://wowdev.wiki/DB/VehicleUIIndSeat
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("VehicleUIIndSeat")
@dataclass
class VehicleUIIndSeatRecord:
    """A record from VehicleUIIndSeat.dbc (3.3.5a, build 12340)."""

    id: int32

    vehicle_u_i_indicator_id: int32 = int32(0)

    virtual_seat_index: int32 = int32(0)

    x_pos: float32 = float32(0.0)

    y_pos: float32 = float32(0.0)
