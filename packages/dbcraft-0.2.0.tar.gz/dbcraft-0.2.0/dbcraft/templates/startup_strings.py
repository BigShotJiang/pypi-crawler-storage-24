"""Startup_Strings.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 1 string_ref field
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 19 fields on disk

Record size: 19 * 4 = 76 bytes

See Also:
  - https://wowdev.wiki/DB/Startup_Strings
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("Startup_Strings")
@dataclass
class StartupStringsRecord:
    """A record from Startup_Strings.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    message_lang: loc_string_ref = field(default_factory=LocalizedString)
