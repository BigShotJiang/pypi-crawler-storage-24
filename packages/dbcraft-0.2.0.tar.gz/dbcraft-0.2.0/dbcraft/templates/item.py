"""Item.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/Item
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("Item")
@dataclass
class ItemRecord:
    """A record from Item.dbc (3.3.5a, build 12340)."""

    id: int32

    class_id: int32 = int32(0)

    subclass_id: int32 = int32(0)

    sound_override_subclass_id: int32 = int32(0)

    material: int32 = int32(0)

    display_info_id: int32 = int32(0)

    inventory_type: int32 = int32(0)

    sheathe_type: int32 = int32(0)
