"""AuctionHouse.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 21 fields on disk

Record size: 21 * 4 = 84 bytes

See Also:
  - https://wowdev.wiki/DB/AuctionHouse
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("AuctionHouse")
@dataclass
class AuctionHouseRecord:
    """A record from AuctionHouse.dbc (3.3.5a, build 12340)."""

    id: int32

    faction_id: int32 = int32(0)

    deposit_rate: int32 = int32(0)

    consignment_rate: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)
