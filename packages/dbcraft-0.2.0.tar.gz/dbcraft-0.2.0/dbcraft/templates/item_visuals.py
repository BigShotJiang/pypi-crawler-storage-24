"""ItemVisuals.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 6 int32 fields
  - Total: 6 fields on disk

Record size: 6 * 4 = 24 bytes

See Also:
  - https://wowdev.wiki/DB/ItemVisuals
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("ItemVisuals")
@dataclass
class ItemVisualsRecord:
    """A record from ItemVisuals.dbc (3.3.5a, build 12340)."""

    id: int32

    slot_0: int32 = int32(0)

    slot_1: int32 = int32(0)

    slot_2: int32 = int32(0)

    slot_3: int32 = int32(0)

    slot_4: int32 = int32(0)
