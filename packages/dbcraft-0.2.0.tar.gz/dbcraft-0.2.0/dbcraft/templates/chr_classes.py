"""ChrClasses.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 7 int32 fields
  - 2 string_ref fields
  - 3 loc_string_ref fields (3 x 17 = 51 on disk)
  - Total: 60 fields on disk

Record size: 60 * 4 = 240 bytes

See Also:
  - https://wowdev.wiki/DB/ChrClasses
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("ChrClasses")
@dataclass
class ChrClassesRecord:
    """A record from ChrClasses.dbc (3.3.5a, build 12340)."""

    id: int32

    damage_bonus_stat: int32 = int32(0)

    display_power: int32 = int32(0)

    pet_name_token: string_ref = string_ref("")

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    name_female_lang: loc_string_ref = field(default_factory=LocalizedString)

    name_male_lang: loc_string_ref = field(default_factory=LocalizedString)

    filename: string_ref = string_ref("")

    spell_class_set: int32 = int32(0)

    flags: int32 = int32(0)

    cinematic_sequence_id: int32 = int32(0)

    required_expansion: int32 = int32(0)
