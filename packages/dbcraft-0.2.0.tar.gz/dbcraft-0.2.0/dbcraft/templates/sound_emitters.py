"""SoundEmitters.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 6 float32 fields
  - 1 string_ref field
  - Total: 10 fields on disk

Record size: 10 * 4 = 40 bytes

See Also:
  - https://wowdev.wiki/DB/SoundEmitters
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("SoundEmitters")
@dataclass
class SoundEmittersRecord:
    """A record from SoundEmitters.dbc (3.3.5a, build 12340)."""

    id: int32

    position_0: float32 = float32(0.0)

    position_1: float32 = float32(0.0)

    position_2: float32 = float32(0.0)

    direction_0: float32 = float32(0.0)

    direction_1: float32 = float32(0.0)

    direction_2: float32 = float32(0.0)

    sound_entry_advanced_id: int32 = int32(0)

    map_id: int32 = int32(0)

    name: string_ref = string_ref("")
