"""ParticleColor.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 10 int32 fields
  - Total: 10 fields on disk

Record size: 10 * 4 = 40 bytes

See Also:
  - https://wowdev.wiki/DB/ParticleColor
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("ParticleColor")
@dataclass
class ParticleColorRecord:
    """A record from ParticleColor.dbc (3.3.5a, build 12340)."""

    id: int32

    start_0: int32 = int32(0)

    start_1: int32 = int32(0)

    start_2: int32 = int32(0)

    m_id_0: int32 = int32(0)

    m_id_1: int32 = int32(0)

    m_id_2: int32 = int32(0)

    end_0: int32 = int32(0)

    end_1: int32 = int32(0)

    end_2: int32 = int32(0)
