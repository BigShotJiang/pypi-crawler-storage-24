"""VehicleSeat.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 23 int32 fields
  - 35 float32 fields
  - Total: 58 fields on disk

Record size: 58 * 4 = 232 bytes

See Also:
  - https://wowdev.wiki/DB/VehicleSeat
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("VehicleSeat")
@dataclass
class VehicleSeatRecord:
    """A record from VehicleSeat.dbc (3.3.5a, build 12340)."""

    id: int32

    field_3_3_5_12213_001: float32 = float32(0.0)

    attachment_id: int32 = int32(0)

    attachment_offset_0: float32 = float32(0.0)

    attachment_offset_1: float32 = float32(0.0)

    attachment_offset_2: float32 = float32(0.0)

    field_3_3_5_12213_004: float32 = float32(0.0)

    enter_speed: float32 = float32(0.0)

    enter_gravity: float32 = float32(0.0)

    enter_min_duration: float32 = float32(0.0)

    enter_max_duration: float32 = float32(0.0)

    enter_min_arc_height: float32 = float32(0.0)

    enter_max_arc_height: float32 = float32(0.0)

    enter_anim_start: int32 = int32(0)

    enter_anim_loop: int32 = int32(0)

    ride_anim_start: int32 = int32(0)

    ride_anim_loop: int32 = int32(0)

    ride_upper_anim_start: int32 = int32(0)

    ride_upper_anim_loop: int32 = int32(0)

    field_3_3_5_12213_017: float32 = float32(0.0)

    exit_speed: float32 = float32(0.0)

    exit_gravity: float32 = float32(0.0)

    exit_min_duration: float32 = float32(0.0)

    exit_max_duration: float32 = float32(0.0)

    exit_min_arc_height: float32 = float32(0.0)

    exit_max_arc_height: float32 = float32(0.0)

    exit_anim_start: int32 = int32(0)

    exit_anim_loop: int32 = int32(0)

    exit_anim_end: int32 = int32(0)

    field_3_3_5_12213_027: float32 = float32(0.0)

    passenger_pitch: float32 = float32(0.0)

    field_3_3_5_12213_029: float32 = float32(0.0)

    passenger_attachment_id: int32 = int32(0)

    vehicle_enter_anim: int32 = int32(0)

    vehicle_exit_anim: int32 = int32(0)

    vehicle_ride_anim_loop: int32 = int32(0)

    field_3_3_5_12213_034: int32 = int32(0)

    vehicle_exit_anim_bone: int32 = int32(0)

    vehicle_enter_anim_bone: int32 = int32(0)

    field_3_3_5_12213_037: float32 = float32(0.0)

    field_3_3_5_12213_038: float32 = float32(0.0)

    vehicle_ability_display: int32 = int32(0)

    enter_u_i_sound_id: int32 = int32(0)

    field_3_3_5_12213_041: int32 = int32(0)

    ui_skin: int32 = int32(0)

    field_3_3_5_12213_043: float32 = float32(0.0)

    field_3_3_5_12213_044: float32 = float32(0.0)

    field_3_3_5_12213_045: float32 = float32(0.0)

    field_3_3_5_12213_046: int32 = int32(0)

    field_3_3_5_12213_047: float32 = float32(0.0)

    field_3_3_5_12213_048: float32 = float32(0.0)

    field_3_3_5_12213_049: float32 = float32(0.0)

    field_3_3_5_12213_050: float32 = float32(0.0)

    field_3_3_5_12213_051: float32 = float32(0.0)

    field_3_3_5_12213_052: float32 = float32(0.0)

    field_3_3_5_12213_053: float32 = float32(0.0)

    field_3_3_5_12213_054: float32 = float32(0.0)

    field_3_3_5_12213_055: float32 = float32(0.0)
