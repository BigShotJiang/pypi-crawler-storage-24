"""AreaTrigger.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 8 float32 fields
  - Total: 10 fields on disk

Record size: 10 * 4 = 40 bytes

See Also:
  - https://wowdev.wiki/DB/AreaTrigger
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("AreaTrigger")
@dataclass
class AreaTriggerRecord:
    """A record from AreaTrigger.dbc (3.3.5a, build 12340)."""

    id: int32

    continent_id: int32 = int32(0)

    pos_0: float32 = float32(0.0)

    pos_1: float32 = float32(0.0)

    pos_2: float32 = float32(0.0)

    radius: float32 = float32(0.0)

    box_length: float32 = float32(0.0)

    box_width: float32 = float32(0.0)

    box_height: float32 = float32(0.0)

    box_yaw: float32 = float32(0.0)
