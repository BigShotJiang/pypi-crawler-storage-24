"""LockType.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 1 string_ref field
  - 3 loc_string_ref fields (3 x 17 = 51 on disk)
  - Total: 53 fields on disk

Record size: 53 * 4 = 212 bytes

See Also:
  - https://wowdev.wiki/DB/LockType
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("LockType")
@dataclass
class LockTypeRecord:
    """A record from LockType.dbc (3.3.5a, build 12340)."""

    id: int32

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    resource_name_lang: loc_string_ref = field(default_factory=LocalizedString)

    verb_lang: loc_string_ref = field(default_factory=LocalizedString)

    cursor_name: string_ref = string_ref("")
