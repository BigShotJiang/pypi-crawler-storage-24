"""SoundSamplePreferences.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 10 int32 fields
  - 7 float32 fields
  - Total: 17 fields on disk

Record size: 17 * 4 = 68 bytes

See Also:
  - https://wowdev.wiki/DB/SoundSamplePreferences
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("SoundSamplePreferences")
@dataclass
class SoundSamplePreferencesRecord:
    """A record from SoundSamplePreferences.dbc (3.3.5a, build 12340)."""

    id: int32

    field_0_6_0_3592_001: int32 = int32(0)

    field_0_6_0_3592_002: int32 = int32(0)

    e_a_x2_sample_room: int32 = int32(0)

    field_0_6_0_3592_004: int32 = int32(0)

    field_0_6_0_3592_005: int32 = int32(0)

    field_0_6_0_3592_006: float32 = float32(0.0)

    field_0_6_0_3592_007: int32 = int32(0)

    e_a_x2_sample_occlusion_l_f_ratio: float32 = float32(0.0)

    e_a_x2_sample_occlusion_room_ratio: float32 = float32(0.0)

    field_0_6_0_3592_010: int32 = int32(0)

    e_a_x1_effect_level: float32 = float32(0.0)

    field_0_6_0_3592_012: int32 = int32(0)

    field_0_6_0_3592_013: float32 = float32(0.0)

    e_a_x3_sample_exclusion: float32 = float32(0.0)

    field_0_6_0_3592_015: float32 = float32(0.0)

    field_0_6_0_3592_016: int32 = int32(0)
