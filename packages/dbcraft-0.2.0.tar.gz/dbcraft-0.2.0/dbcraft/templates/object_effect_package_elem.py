"""ObjectEffectPackageElem.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/ObjectEffectPackageElem
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("ObjectEffectPackageElem")
@dataclass
class ObjectEffectPackageElemRecord:
    """A record from ObjectEffectPackageElem.dbc (3.3.5a, build 12340)."""

    id: int32

    object_effect_package_id: int32 = int32(0)

    object_effect_group_id: int32 = int32(0)

    state_type: int32 = int32(0)
