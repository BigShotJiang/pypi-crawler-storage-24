"""GameObjectDisplayInfo.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 12 int32 fields
  - 6 float32 fields
  - 1 string_ref field
  - Total: 19 fields on disk

Record size: 19 * 4 = 76 bytes

See Also:
  - https://wowdev.wiki/DB/GameObjectDisplayInfo
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("GameObjectDisplayInfo")
@dataclass
class GameObjectDisplayInfoRecord:
    """A record from GameObjectDisplayInfo.dbc (3.3.5a, build 12340)."""

    id: int32

    model_name: string_ref = string_ref("")

    sound_0: int32 = int32(0)

    sound_1: int32 = int32(0)

    sound_2: int32 = int32(0)

    sound_3: int32 = int32(0)

    sound_4: int32 = int32(0)

    sound_5: int32 = int32(0)

    sound_6: int32 = int32(0)

    sound_7: int32 = int32(0)

    sound_8: int32 = int32(0)

    sound_9: int32 = int32(0)

    geo_box_min_0: float32 = float32(0.0)

    geo_box_min_1: float32 = float32(0.0)

    geo_box_min_2: float32 = float32(0.0)

    geo_box_max_0: float32 = float32(0.0)

    geo_box_max_1: float32 = float32(0.0)

    geo_box_max_2: float32 = float32(0.0)

    object_effect_package_id: int32 = int32(0)
