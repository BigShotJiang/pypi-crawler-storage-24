"""WorldMapContinent.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 7 int32 fields
  - 7 float32 fields
  - Total: 14 fields on disk

Record size: 14 * 4 = 56 bytes

See Also:
  - https://wowdev.wiki/DB/WorldMapContinent
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("WorldMapContinent")
@dataclass
class WorldMapContinentRecord:
    """A record from WorldMapContinent.dbc (3.3.5a, build 12340)."""

    id: int32

    map_id: int32 = int32(0)

    left_boundary: int32 = int32(0)

    right_boundary: int32 = int32(0)

    top_boundary: int32 = int32(0)

    bottom_boundary: int32 = int32(0)

    continent_offset_0: float32 = float32(0.0)

    continent_offset_1: float32 = float32(0.0)

    scale: float32 = float32(0.0)

    taxi_min_0: float32 = float32(0.0)

    taxi_min_1: float32 = float32(0.0)

    taxi_max_0: float32 = float32(0.0)

    taxi_max_1: float32 = float32(0.0)

    world_map_id: int32 = int32(0)
