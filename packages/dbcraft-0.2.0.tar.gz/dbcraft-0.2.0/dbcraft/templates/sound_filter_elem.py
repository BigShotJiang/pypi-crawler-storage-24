"""SoundFilterElem.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 9 float32 fields
  - Total: 13 fields on disk

Record size: 13 * 4 = 52 bytes

See Also:
  - https://wowdev.wiki/DB/SoundFilterElem
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("SoundFilterElem")
@dataclass
class SoundFilterElemRecord:
    """A record from SoundFilterElem.dbc (3.3.5a, build 12340)."""

    id: int32

    sound_filter_id: int32 = int32(0)

    order_index: int32 = int32(0)

    filter_type: int32 = int32(0)

    params_0: float32 = float32(0.0)

    params_1: float32 = float32(0.0)

    params_2: float32 = float32(0.0)

    params_3: float32 = float32(0.0)

    params_4: float32 = float32(0.0)

    params_5: float32 = float32(0.0)

    params_6: float32 = float32(0.0)

    params_7: float32 = float32(0.0)

    params_8: float32 = float32(0.0)
