"""CharStartOutfit.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 73 int32 fields
  - 4 int8 fields (1 byte each)
  - Total: 77 fields on disk

Record size: 73 * 4 + 4 * 1 = 296 bytes

See Also:
  - https://wowdev.wiki/DB/CharStartOutfit
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, int8
from dbcraft.templates.base import register_template


@register_template("CharStartOutfit")
@dataclass
class CharStartOutfitRecord:
    """A record from CharStartOutfit.dbc (3.3.5a, build 12340)."""

    id: int32

    race_id: int8 = int8(0)

    class_id: int8 = int8(0)

    sex_id: int8 = int8(0)

    outfit_id: int8 = int8(0)

    item_id_0: int32 = int32(0)

    item_id_1: int32 = int32(0)

    item_id_2: int32 = int32(0)

    item_id_3: int32 = int32(0)

    item_id_4: int32 = int32(0)

    item_id_5: int32 = int32(0)

    item_id_6: int32 = int32(0)

    item_id_7: int32 = int32(0)

    item_id_8: int32 = int32(0)

    item_id_9: int32 = int32(0)

    item_id_10: int32 = int32(0)

    item_id_11: int32 = int32(0)

    item_id_12: int32 = int32(0)

    item_id_13: int32 = int32(0)

    item_id_14: int32 = int32(0)

    item_id_15: int32 = int32(0)

    item_id_16: int32 = int32(0)

    item_id_17: int32 = int32(0)

    item_id_18: int32 = int32(0)

    item_id_19: int32 = int32(0)

    item_id_20: int32 = int32(0)

    item_id_21: int32 = int32(0)

    item_id_22: int32 = int32(0)

    item_id_23: int32 = int32(0)

    display_item_id_0: int32 = int32(0)

    display_item_id_1: int32 = int32(0)

    display_item_id_2: int32 = int32(0)

    display_item_id_3: int32 = int32(0)

    display_item_id_4: int32 = int32(0)

    display_item_id_5: int32 = int32(0)

    display_item_id_6: int32 = int32(0)

    display_item_id_7: int32 = int32(0)

    display_item_id_8: int32 = int32(0)

    display_item_id_9: int32 = int32(0)

    display_item_id_10: int32 = int32(0)

    display_item_id_11: int32 = int32(0)

    display_item_id_12: int32 = int32(0)

    display_item_id_13: int32 = int32(0)

    display_item_id_14: int32 = int32(0)

    display_item_id_15: int32 = int32(0)

    display_item_id_16: int32 = int32(0)

    display_item_id_17: int32 = int32(0)

    display_item_id_18: int32 = int32(0)

    display_item_id_19: int32 = int32(0)

    display_item_id_20: int32 = int32(0)

    display_item_id_21: int32 = int32(0)

    display_item_id_22: int32 = int32(0)

    display_item_id_23: int32 = int32(0)

    inventory_type_0: int32 = int32(0)

    inventory_type_1: int32 = int32(0)

    inventory_type_2: int32 = int32(0)

    inventory_type_3: int32 = int32(0)

    inventory_type_4: int32 = int32(0)

    inventory_type_5: int32 = int32(0)

    inventory_type_6: int32 = int32(0)

    inventory_type_7: int32 = int32(0)

    inventory_type_8: int32 = int32(0)

    inventory_type_9: int32 = int32(0)

    inventory_type_10: int32 = int32(0)

    inventory_type_11: int32 = int32(0)

    inventory_type_12: int32 = int32(0)

    inventory_type_13: int32 = int32(0)

    inventory_type_14: int32 = int32(0)

    inventory_type_15: int32 = int32(0)

    inventory_type_16: int32 = int32(0)

    inventory_type_17: int32 = int32(0)

    inventory_type_18: int32 = int32(0)

    inventory_type_19: int32 = int32(0)

    inventory_type_20: int32 = int32(0)

    inventory_type_21: int32 = int32(0)

    inventory_type_22: int32 = int32(0)

    inventory_type_23: int32 = int32(0)
