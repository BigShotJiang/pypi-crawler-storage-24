"""DurabilityCosts.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 30 int32 fields
  - Total: 30 fields on disk

Record size: 30 * 4 = 120 bytes

See Also:
  - https://wowdev.wiki/DB/DurabilityCosts
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("DurabilityCosts")
@dataclass
class DurabilityCostsRecord:
    """A record from DurabilityCosts.dbc (3.3.5a, build 12340)."""

    id: int32

    weapon_sub_class_cost_0: int32 = int32(0)

    weapon_sub_class_cost_1: int32 = int32(0)

    weapon_sub_class_cost_2: int32 = int32(0)

    weapon_sub_class_cost_3: int32 = int32(0)

    weapon_sub_class_cost_4: int32 = int32(0)

    weapon_sub_class_cost_5: int32 = int32(0)

    weapon_sub_class_cost_6: int32 = int32(0)

    weapon_sub_class_cost_7: int32 = int32(0)

    weapon_sub_class_cost_8: int32 = int32(0)

    weapon_sub_class_cost_9: int32 = int32(0)

    weapon_sub_class_cost_10: int32 = int32(0)

    weapon_sub_class_cost_11: int32 = int32(0)

    weapon_sub_class_cost_12: int32 = int32(0)

    weapon_sub_class_cost_13: int32 = int32(0)

    weapon_sub_class_cost_14: int32 = int32(0)

    weapon_sub_class_cost_15: int32 = int32(0)

    weapon_sub_class_cost_16: int32 = int32(0)

    weapon_sub_class_cost_17: int32 = int32(0)

    weapon_sub_class_cost_18: int32 = int32(0)

    weapon_sub_class_cost_19: int32 = int32(0)

    weapon_sub_class_cost_20: int32 = int32(0)

    armor_sub_class_cost_0: int32 = int32(0)

    armor_sub_class_cost_1: int32 = int32(0)

    armor_sub_class_cost_2: int32 = int32(0)

    armor_sub_class_cost_3: int32 = int32(0)

    armor_sub_class_cost_4: int32 = int32(0)

    armor_sub_class_cost_5: int32 = int32(0)

    armor_sub_class_cost_6: int32 = int32(0)

    armor_sub_class_cost_7: int32 = int32(0)
