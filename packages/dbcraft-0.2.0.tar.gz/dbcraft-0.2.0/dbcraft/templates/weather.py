"""Weather.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 4 float32 fields
  - 1 string_ref field
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/Weather
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("Weather")
@dataclass
class WeatherRecord:
    """A record from Weather.dbc (3.3.5a, build 12340)."""

    id: int32

    ambience_id: int32 = int32(0)

    effect_type: int32 = int32(0)

    transition_sky_box: float32 = float32(0.0)

    effect_color_0: float32 = float32(0.0)

    effect_color_1: float32 = float32(0.0)

    effect_color_2: float32 = float32(0.0)

    effect_texture: string_ref = string_ref("")
