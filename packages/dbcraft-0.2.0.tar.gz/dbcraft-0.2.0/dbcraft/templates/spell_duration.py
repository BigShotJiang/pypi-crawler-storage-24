"""SpellDuration.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/SpellDuration
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("SpellDuration")
@dataclass
class SpellDurationRecord:
    """A record from SpellDuration.dbc (3.3.5a, build 12340)."""

    id: int32

    duration: int32 = int32(0)

    duration_per_level: int32 = int32(0)

    max_duration: int32 = int32(0)
