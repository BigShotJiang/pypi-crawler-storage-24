"""PowerDisplay.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 1 string_ref field
  - 3 int8 fields (1 byte each)
  - Total: 6 fields on disk

Record size: 3 * 4 + 3 * 1 = 15 bytes

See Also:
  - https://wowdev.wiki/DB/PowerDisplay
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, int8, string_ref
from dbcraft.templates.base import register_template


@register_template("PowerDisplay")
@dataclass
class PowerDisplayRecord:
    """A record from PowerDisplay.dbc (3.3.5a, build 12340)."""

    id: int32

    actual_type: int32 = int32(0)

    global_string_base_tag: string_ref = string_ref("")

    red: int8 = int8(0)

    green: int8 = int8(0)

    blue: int8 = int8(0)
