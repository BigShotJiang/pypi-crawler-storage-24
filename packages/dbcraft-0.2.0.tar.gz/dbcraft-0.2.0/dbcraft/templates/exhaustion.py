"""Exhaustion.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 4 float32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 23 fields on disk

Record size: 23 * 4 = 92 bytes

See Also:
  - https://wowdev.wiki/DB/Exhaustion
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("Exhaustion")
@dataclass
class ExhaustionRecord:
    """A record from Exhaustion.dbc (3.3.5a, build 12340)."""

    id: int32

    xp: int32 = int32(0)

    factor: float32 = float32(0.0)

    outdoor_hours: float32 = float32(0.0)

    inn_hours: float32 = float32(0.0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    threshold: float32 = float32(0.0)
