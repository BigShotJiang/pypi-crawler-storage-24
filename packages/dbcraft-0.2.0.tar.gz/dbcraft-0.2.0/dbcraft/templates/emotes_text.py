"""EmotesText.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 18 int32 fields
  - 1 string_ref field
  - Total: 19 fields on disk

Record size: 19 * 4 = 76 bytes

See Also:
  - https://wowdev.wiki/DB/EmotesText
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("EmotesText")
@dataclass
class EmotesTextRecord:
    """A record from EmotesText.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    emote_id: int32 = int32(0)

    emote_text_0: int32 = int32(0)

    emote_text_1: int32 = int32(0)

    emote_text_2: int32 = int32(0)

    emote_text_3: int32 = int32(0)

    emote_text_4: int32 = int32(0)

    emote_text_5: int32 = int32(0)

    emote_text_6: int32 = int32(0)

    emote_text_7: int32 = int32(0)

    emote_text_8: int32 = int32(0)

    emote_text_9: int32 = int32(0)

    emote_text_10: int32 = int32(0)

    emote_text_11: int32 = int32(0)

    emote_text_12: int32 = int32(0)

    emote_text_13: int32 = int32(0)

    emote_text_14: int32 = int32(0)

    emote_text_15: int32 = int32(0)
