"""SummonProperties.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 6 int32 fields
  - Total: 6 fields on disk

Record size: 6 * 4 = 24 bytes

See Also:
  - https://wowdev.wiki/DB/SummonProperties
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("SummonProperties")
@dataclass
class SummonPropertiesRecord:
    """A record from SummonProperties.dbc (3.3.5a, build 12340)."""

    id: int32

    control: int32 = int32(0)

    faction: int32 = int32(0)

    title: int32 = int32(0)

    slot: int32 = int32(0)

    flags: int32 = int32(0)
