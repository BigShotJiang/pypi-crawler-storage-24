"""CharSections.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 7 int32 fields
  - 3 string_ref fields
  - Total: 10 fields on disk

Record size: 10 * 4 = 40 bytes

See Also:
  - https://wowdev.wiki/DB/CharSections
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("CharSections")
@dataclass
class CharSectionsRecord:
    """A record from CharSections.dbc (3.3.5a, build 12340)."""

    id: int32

    race_id: int32 = int32(0)

    sex_id: int32 = int32(0)

    base_section: int32 = int32(0)

    texture_name_0: string_ref = string_ref("")

    texture_name_1: string_ref = string_ref("")

    texture_name_2: string_ref = string_ref("")

    flags: int32 = int32(0)

    variation_index: int32 = int32(0)

    color_index: int32 = int32(0)
