"""DanceMoves.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 6 int32 fields
  - 1 string_ref field
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 24 fields on disk

Record size: 24 * 4 = 96 bytes

See Also:
  - https://wowdev.wiki/DB/DanceMoves
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("DanceMoves")
@dataclass
class DanceMovesRecord:
    """A record from DanceMoves.dbc (3.3.5a, build 12340)."""

    id: int32

    type: int32 = int32(0)

    param: int32 = int32(0)

    fallback: int32 = int32(0)

    racemask: int32 = int32(0)

    internal_name: string_ref = string_ref("")

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    lock_id: int32 = int32(0)
