"""Vehicle.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 15 int32 fields
  - 21 float32 fields
  - 4 string_ref fields
  - Total: 40 fields on disk

Record size: 40 * 4 = 160 bytes

See Also:
  - https://wowdev.wiki/DB/Vehicle
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("Vehicle")
@dataclass
class VehicleRecord:
    """A record from Vehicle.dbc (3.3.5a, build 12340)."""

    id: int32

    flags: int32 = int32(0)

    turn_speed: float32 = float32(0.0)

    pitch_speed: float32 = float32(0.0)

    pitch_min: float32 = float32(0.0)

    pitch_max: float32 = float32(0.0)

    seat_id_0: int32 = int32(0)

    seat_id_1: int32 = int32(0)

    seat_id_2: int32 = int32(0)

    seat_id_3: int32 = int32(0)

    seat_id_4: int32 = int32(0)

    seat_id_5: int32 = int32(0)

    seat_id_6: int32 = int32(0)

    seat_id_7: int32 = int32(0)

    mouse_look_offset_pitch: float32 = float32(0.0)

    camera_fade_dist_scalar_min: float32 = float32(0.0)

    camera_fade_dist_scalar_max: float32 = float32(0.0)

    camera_pitch_offset: float32 = float32(0.0)

    facing_limit_right: float32 = float32(0.0)

    facing_limit_left: float32 = float32(0.0)

    mssl_trgt_turn_lingering: float32 = float32(0.0)

    mssl_trgt_pitch_lingering: float32 = float32(0.0)

    mssl_trgt_mouse_lingering: float32 = float32(0.0)

    mssl_trgt_end_opacity: float32 = float32(0.0)

    mssl_trgt_arc_speed: float32 = float32(0.0)

    mssl_trgt_arc_repeat: float32 = float32(0.0)

    mssl_trgt_arc_width: float32 = float32(0.0)

    mssl_trgt_impact_radius_0: float32 = float32(0.0)

    mssl_trgt_impact_radius_1: float32 = float32(0.0)

    mssl_trgt_arc_texture: string_ref = string_ref("")

    mssl_trgt_impact_texture: string_ref = string_ref("")

    mssl_trgt_impact_model_0: string_ref = string_ref("")

    mssl_trgt_impact_model_1: string_ref = string_ref("")

    camera_yaw_offset: float32 = float32(0.0)

    ui_locomotion_type: int32 = int32(0)

    mssl_trgt_impact_tex_radius: float32 = float32(0.0)

    vehicle_u_i_indicator_id: int32 = int32(0)

    power_display_id_0: int32 = int32(0)

    power_display_id_1: int32 = int32(0)

    power_display_id_2: int32 = int32(0)
