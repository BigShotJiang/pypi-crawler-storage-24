"""SpellDispelType.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 1 string_ref field
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 21 fields on disk

Record size: 21 * 4 = 84 bytes

See Also:
  - https://wowdev.wiki/DB/SpellDispelType
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("SpellDispelType")
@dataclass
class SpellDispelTypeRecord:
    """A record from SpellDispelType.dbc (3.3.5a, build 12340)."""

    id: int32

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    mask: int32 = int32(0)

    immunity_possible: int32 = int32(0)

    internal_name: string_ref = string_ref("")
