"""BankBagSlotPrices.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - Total: 2 fields on disk

Record size: 2 * 4 = 8 bytes

See Also:
  - https://wowdev.wiki/DB/BankBagSlotPrices
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("BankBagSlotPrices")
@dataclass
class BankBagSlotPricesRecord:
    """A record from BankBagSlotPrices.dbc (3.3.5a, build 12340)."""

    id: int32

    cost: int32 = int32(0)
