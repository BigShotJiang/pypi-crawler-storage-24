"""SpellVisualKitModelAttach.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 6 float32 fields
  - Total: 10 fields on disk

Record size: 10 * 4 = 40 bytes

See Also:
  - https://wowdev.wiki/DB/SpellVisualKitModelAttach
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("SpellVisualKitModelAttach")
@dataclass
class SpellVisualKitModelAttachRecord:
    """A record from SpellVisualKitModelAttach.dbc (3.3.5a, build 12340)."""

    id: int32

    parent_spell_visual_kit_id: int32 = int32(0)

    spell_visual_effect_name_id: int32 = int32(0)

    attachment_id: int32 = int32(0)

    offset_0: float32 = float32(0.0)

    offset_1: float32 = float32(0.0)

    offset_2: float32 = float32(0.0)

    yaw: float32 = float32(0.0)

    pitch: float32 = float32(0.0)

    roll: float32 = float32(0.0)
