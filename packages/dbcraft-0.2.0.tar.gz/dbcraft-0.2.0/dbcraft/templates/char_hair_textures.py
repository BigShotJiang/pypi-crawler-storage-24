"""CharHairTextures.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/CharHairTextures
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("CharHairTextures")
@dataclass
class CharHairTexturesRecord:
    """A record from CharHairTextures.dbc (3.3.5a, build 12340)."""

    id: int32

    field_0_5_3_3368_001_race: int32 = int32(0)

    field_0_5_3_3368_002_gender: int32 = int32(0)

    field_0_5_3_3368_003: int32 = int32(0)

    field_0_5_3_3368_004_mayberacemask: int32 = int32(0)

    field_0_5_3_3368_005_the_x_in_hair_xy_blp: int32 = int32(0)

    field_0_5_3_3368_006: int32 = int32(0)

    field_0_5_3_3368_007: int32 = int32(0)
