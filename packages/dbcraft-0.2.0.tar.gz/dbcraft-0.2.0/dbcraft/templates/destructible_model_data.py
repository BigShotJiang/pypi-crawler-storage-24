"""DestructibleModelData.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 19 int32 fields
  - Total: 19 fields on disk

Record size: 19 * 4 = 76 bytes

See Also:
  - https://wowdev.wiki/DB/DestructibleModelData
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("DestructibleModelData")
@dataclass
class DestructibleModelDataRecord:
    """A record from DestructibleModelData.dbc (3.3.5a, build 12340)."""

    id: int32

    state0_impact_effect_doodad_set: int32 = int32(0)

    state0_ambient_doodad_set: int32 = int32(0)

    state1_w_m_o: int32 = int32(0)

    state1_destruction_doodad_set: int32 = int32(0)

    state1_impact_effect_doodad_set: int32 = int32(0)

    state1_ambient_doodad_set: int32 = int32(0)

    state2_w_m_o: int32 = int32(0)

    state2_destruction_doodad_set: int32 = int32(0)

    state2_impact_effect_doodad_set: int32 = int32(0)

    state2_ambient_doodad_set: int32 = int32(0)

    state3_w_m_o: int32 = int32(0)

    state3_init_doodad_set: int32 = int32(0)

    state3_ambient_doodad_set: int32 = int32(0)

    eject_direction: int32 = int32(0)

    repair_ground_fx: int32 = int32(0)

    do_not_highlight: int32 = int32(0)

    heal_effect: int32 = int32(0)

    heal_effect_speed: int32 = int32(0)
