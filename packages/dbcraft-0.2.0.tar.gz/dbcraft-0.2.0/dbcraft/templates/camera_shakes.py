"""CameraShakes.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 5 float32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/CameraShakes
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("CameraShakes")
@dataclass
class CameraShakesRecord:
    """A record from CameraShakes.dbc (3.3.5a, build 12340)."""

    id: int32

    shake_type: int32 = int32(0)

    direction: int32 = int32(0)

    amplitude: float32 = float32(0.0)

    frequency: float32 = float32(0.0)

    duration: float32 = float32(0.0)

    phase: float32 = float32(0.0)

    coefficient: float32 = float32(0.0)
