"""TalentTab.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 6 int32 fields
  - 1 string_ref field
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 24 fields on disk

Record size: 24 * 4 = 96 bytes

See Also:
  - https://wowdev.wiki/DB/TalentTab
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("TalentTab")
@dataclass
class TalentTabRecord:
    """A record from TalentTab.dbc (3.3.5a, build 12340)."""

    id: int32

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    spell_icon_id: int32 = int32(0)

    race_mask: int32 = int32(0)

    class_mask: int32 = int32(0)

    category_enum_id: int32 = int32(0)

    order_index: int32 = int32(0)

    background_file: string_ref = string_ref("")
