"""LoadingScreens.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 2 string_ref fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/LoadingScreens
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("LoadingScreens")
@dataclass
class LoadingScreensRecord:
    """A record from LoadingScreens.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    file_name: string_ref = string_ref("")

    has_wide_screen: int32 = int32(0)
