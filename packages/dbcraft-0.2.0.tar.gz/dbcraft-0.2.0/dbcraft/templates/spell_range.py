"""SpellRange.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 4 float32 fields
  - 2 loc_string_ref fields (2 x 17 = 34 on disk)
  - Total: 40 fields on disk

Record size: 40 * 4 = 160 bytes

See Also:
  - https://wowdev.wiki/DB/SpellRange
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("SpellRange")
@dataclass
class SpellRangeRecord:
    """A record from SpellRange.dbc (3.3.5a, build 12340)."""

    id: int32

    range_min_0: float32 = float32(0.0)

    range_min_1: float32 = float32(0.0)

    range_max_0: float32 = float32(0.0)

    range_max_1: float32 = float32(0.0)

    flags: int32 = int32(0)

    display_name_lang: loc_string_ref = field(default_factory=LocalizedString)

    display_name_short_lang: loc_string_ref = field(default_factory=LocalizedString)
