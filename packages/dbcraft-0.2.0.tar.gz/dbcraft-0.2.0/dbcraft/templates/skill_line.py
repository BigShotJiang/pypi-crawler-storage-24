"""SkillLine.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 5 int32 fields
  - 3 loc_string_ref fields (3 x 17 = 51 on disk)
  - Total: 56 fields on disk

Record size: 56 * 4 = 224 bytes

See Also:
  - https://wowdev.wiki/DB/SkillLine
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("SkillLine")
@dataclass
class SkillLineRecord:
    """A record from SkillLine.dbc (3.3.5a, build 12340)."""

    id: int32

    category_id: int32 = int32(0)

    skill_costs_id: int32 = int32(0)

    display_name_lang: loc_string_ref = field(default_factory=LocalizedString)

    description_lang: loc_string_ref = field(default_factory=LocalizedString)

    spell_icon_id: int32 = int32(0)

    alternate_verb_lang: loc_string_ref = field(default_factory=LocalizedString)

    can_link: int32 = int32(0)
