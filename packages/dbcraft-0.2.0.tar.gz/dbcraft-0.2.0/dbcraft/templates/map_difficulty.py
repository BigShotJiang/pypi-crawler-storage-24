"""MapDifficulty.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 5 int32 fields
  - 1 string_ref field
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 23 fields on disk

Record size: 23 * 4 = 92 bytes

See Also:
  - https://wowdev.wiki/DB/MapDifficulty
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("MapDifficulty")
@dataclass
class MapDifficultyRecord:
    """A record from MapDifficulty.dbc (3.3.5a, build 12340)."""

    id: int32

    map_id: int32 = int32(0)

    difficulty: int32 = int32(0)

    message_lang: loc_string_ref = field(default_factory=LocalizedString)

    raid_duration: int32 = int32(0)

    max_players: int32 = int32(0)

    difficultystring: string_ref = string_ref("")
