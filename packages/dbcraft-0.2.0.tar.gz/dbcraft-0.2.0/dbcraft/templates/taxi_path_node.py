"""TaxiPathNode.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - 3 float32 fields
  - Total: 11 fields on disk

Record size: 11 * 4 = 44 bytes

See Also:
  - https://wowdev.wiki/DB/TaxiPathNode
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("TaxiPathNode")
@dataclass
class TaxiPathNodeRecord:
    """A record from TaxiPathNode.dbc (3.3.5a, build 12340)."""

    id: int32

    path_id: int32 = int32(0)

    node_index: int32 = int32(0)

    continent_id: int32 = int32(0)

    loc_0: float32 = float32(0.0)

    loc_1: float32 = float32(0.0)

    loc_2: float32 = float32(0.0)

    flags: int32 = int32(0)

    delay: int32 = int32(0)

    arrival_event_id: int32 = int32(0)

    departure_event_id: int32 = int32(0)
