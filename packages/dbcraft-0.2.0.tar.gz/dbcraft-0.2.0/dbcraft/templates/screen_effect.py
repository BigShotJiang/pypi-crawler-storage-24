"""ScreenEffect.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 9 int32 fields
  - 1 string_ref field
  - Total: 10 fields on disk

Record size: 10 * 4 = 40 bytes

See Also:
  - https://wowdev.wiki/DB/ScreenEffect
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("ScreenEffect")
@dataclass
class ScreenEffectRecord:
    """A record from ScreenEffect.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    effect: int32 = int32(0)

    param_0: int32 = int32(0)

    param_1: int32 = int32(0)

    param_2: int32 = int32(0)

    param_3: int32 = int32(0)

    light_params_id: int32 = int32(0)

    sound_ambience_id: int32 = int32(0)

    zone_music_id: int32 = int32(0)
