"""ChatProfanity.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 1 string_ref field
  - Total: 3 fields on disk

Record size: 3 * 4 = 12 bytes

See Also:
  - https://wowdev.wiki/DB/ChatProfanity
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("ChatProfanity")
@dataclass
class ChatProfanityRecord:
    """A record from ChatProfanity.dbc (3.3.5a, build 12340)."""

    id: int32

    text: string_ref = string_ref("")

    language: int32 = int32(0)
