"""CreatureModelData.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 9 int32 fields
  - 18 float32 fields
  - 1 string_ref field
  - Total: 28 fields on disk

Record size: 28 * 4 = 112 bytes

See Also:
  - https://wowdev.wiki/DB/CreatureModelData
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("CreatureModelData")
@dataclass
class CreatureModelDataRecord:
    """A record from CreatureModelData.dbc (3.3.5a, build 12340)."""

    id: int32

    flags: int32 = int32(0)

    model_name: string_ref = string_ref("")

    size_class: int32 = int32(0)

    model_scale: float32 = float32(0.0)

    blood_id: int32 = int32(0)

    footprint_texture_id: int32 = int32(0)

    footprint_texture_length: float32 = float32(0.0)

    footprint_texture_width: float32 = float32(0.0)

    footprint_particle_scale: float32 = float32(0.0)

    foley_material_id: int32 = int32(0)

    footstep_shake_size: int32 = int32(0)

    death_thud_shake_size: int32 = int32(0)

    sound_id: int32 = int32(0)

    collision_width: float32 = float32(0.0)

    collision_height: float32 = float32(0.0)

    mount_height: float32 = float32(0.0)

    geo_box_min_x: float32 = float32(0.0)

    geo_box_min_y: float32 = float32(0.0)

    geo_box_min_z: float32 = float32(0.0)

    geo_box_max_x: float32 = float32(0.0)

    geo_box_max_y: float32 = float32(0.0)

    geo_box_max_z: float32 = float32(0.0)

    world_effect_scale: float32 = float32(0.0)

    attached_effect_scale: float32 = float32(0.0)

    missile_collision_radius: float32 = float32(0.0)

    missile_collision_push: float32 = float32(0.0)

    missile_collision_raise: float32 = float32(0.0)
