"""PaperDollItemFrame.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 2 string_ref fields
  - Total: 3 fields on disk

Record size: 3 * 4 = 12 bytes

See Also:
  - https://wowdev.wiki/DB/PaperDollItemFrame
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("PaperDollItemFrame")
@dataclass
class PaperDollItemFrameRecord:
    """A record from PaperDollItemFrame.dbc (3.3.5a, build 12340)."""

    item_button_name: string_ref = string_ref("")

    slot_icon: string_ref = string_ref("")

    slot_number: int32 = int32(0)
