"""CinematicCamera.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 4 float32 fields
  - 1 string_ref field
  - Total: 7 fields on disk

Record size: 7 * 4 = 28 bytes

See Also:
  - https://wowdev.wiki/DB/CinematicCamera
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("CinematicCamera")
@dataclass
class CinematicCameraRecord:
    """A record from CinematicCamera.dbc (3.3.5a, build 12340)."""

    id: int32

    model: string_ref = string_ref("")

    sound_id: int32 = int32(0)

    origin_0: float32 = float32(0.0)

    origin_1: float32 = float32(0.0)

    origin_2: float32 = float32(0.0)

    origin_facing: float32 = float32(0.0)
