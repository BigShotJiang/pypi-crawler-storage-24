"""UnitBloodLevels.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/UnitBloodLevels
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("UnitBloodLevels")
@dataclass
class UnitBloodLevelsRecord:
    """A record from UnitBloodLevels.dbc (3.3.5a, build 12340)."""

    id: int32

    violencelevel_0: int32 = int32(0)

    violencelevel_1: int32 = int32(0)

    violencelevel_2: int32 = int32(0)
