"""gtOCTRegenMP.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 float32 field
  - Total: 1 fields on disk

Record size: 1 * 4 = 4 bytes

See Also:
  - https://wowdev.wiki/DB/gtOCTRegenMP
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32
from dbcraft.templates.base import register_template


@register_template("gtOCTRegenMP")
@dataclass
class GtOCTRegenMPRecord:
    """A record from gtOCTRegenMP.dbc (3.3.5a, build 12340)."""

    data: float32 = float32(0.0)
