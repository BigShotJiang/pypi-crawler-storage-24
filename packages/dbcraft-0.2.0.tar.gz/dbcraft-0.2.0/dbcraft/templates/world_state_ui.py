"""WorldStateUI.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 9 int32 fields
  - 3 string_ref fields
  - 3 loc_string_ref fields (3 x 17 = 51 on disk)
  - Total: 63 fields on disk

Record size: 63 * 4 = 252 bytes

See Also:
  - https://wowdev.wiki/DB/WorldStateUI
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("WorldStateUI")
@dataclass
class WorldStateUIRecord:
    """A record from WorldStateUI.dbc (3.3.5a, build 12340)."""

    id: int32

    map_id: int32 = int32(0)

    area_id: int32 = int32(0)

    phase_shift: int32 = int32(0)

    icon: string_ref = string_ref("")

    string_lang: loc_string_ref = field(default_factory=LocalizedString)

    tooltip_lang: loc_string_ref = field(default_factory=LocalizedString)

    state_variable: int32 = int32(0)

    type: int32 = int32(0)

    dynamic_icon: string_ref = string_ref("")

    dynamic_tooltip_lang: loc_string_ref = field(default_factory=LocalizedString)

    extended_u_i: string_ref = string_ref("")

    extended_u_i_state_variable_0: int32 = int32(0)

    extended_u_i_state_variable_1: int32 = int32(0)

    extended_u_i_state_variable_2: int32 = int32(0)
