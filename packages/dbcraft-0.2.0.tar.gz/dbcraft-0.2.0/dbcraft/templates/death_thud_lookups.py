"""DeathThudLookups.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 5 int32 fields
  - Total: 5 fields on disk

Record size: 5 * 4 = 20 bytes

See Also:
  - https://wowdev.wiki/DB/DeathThudLookups
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("DeathThudLookups")
@dataclass
class DeathThudLookupsRecord:
    """A record from DeathThudLookups.dbc (3.3.5a, build 12340)."""

    id: int32

    size_class: int32 = int32(0)

    terrain_type_sound_id: int32 = int32(0)

    sound_entry_id: int32 = int32(0)

    sound_entry_id_water: int32 = int32(0)
