"""ItemSet.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 36 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 53 fields on disk

Record size: 53 * 4 = 212 bytes

See Also:
  - https://wowdev.wiki/DB/ItemSet
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("ItemSet")
@dataclass
class ItemSetRecord:
    """A record from ItemSet.dbc (3.3.5a, build 12340)."""

    id: int32

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    item_id_0: int32 = int32(0)

    item_id_1: int32 = int32(0)

    item_id_2: int32 = int32(0)

    item_id_3: int32 = int32(0)

    item_id_4: int32 = int32(0)

    item_id_5: int32 = int32(0)

    item_id_6: int32 = int32(0)

    item_id_7: int32 = int32(0)

    item_id_8: int32 = int32(0)

    item_id_9: int32 = int32(0)

    item_id_10: int32 = int32(0)

    item_id_11: int32 = int32(0)

    item_id_12: int32 = int32(0)

    item_id_13: int32 = int32(0)

    item_id_14: int32 = int32(0)

    item_id_15: int32 = int32(0)

    item_id_16: int32 = int32(0)

    set_spell_id_0: int32 = int32(0)

    set_spell_id_1: int32 = int32(0)

    set_spell_id_2: int32 = int32(0)

    set_spell_id_3: int32 = int32(0)

    set_spell_id_4: int32 = int32(0)

    set_spell_id_5: int32 = int32(0)

    set_spell_id_6: int32 = int32(0)

    set_spell_id_7: int32 = int32(0)

    set_threshold_0: int32 = int32(0)

    set_threshold_1: int32 = int32(0)

    set_threshold_2: int32 = int32(0)

    set_threshold_3: int32 = int32(0)

    set_threshold_4: int32 = int32(0)

    set_threshold_5: int32 = int32(0)

    set_threshold_6: int32 = int32(0)

    set_threshold_7: int32 = int32(0)

    required_skill: int32 = int32(0)

    required_skill_rank: int32 = int32(0)
