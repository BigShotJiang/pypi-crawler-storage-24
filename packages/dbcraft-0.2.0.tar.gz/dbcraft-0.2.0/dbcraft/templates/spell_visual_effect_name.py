"""SpellVisualEffectName.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 4 float32 fields
  - 2 string_ref fields
  - Total: 7 fields on disk

Record size: 7 * 4 = 28 bytes

See Also:
  - https://wowdev.wiki/DB/SpellVisualEffectName
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("SpellVisualEffectName")
@dataclass
class SpellVisualEffectNameRecord:
    """A record from SpellVisualEffectName.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    file_name: string_ref = string_ref("")

    area_effect_size: float32 = float32(0.0)

    scale: float32 = float32(0.0)

    min_allowed_scale: float32 = float32(0.0)

    max_allowed_scale: float32 = float32(0.0)
