"""Resistances.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 20 fields on disk

Record size: 20 * 4 = 80 bytes

See Also:
  - https://wowdev.wiki/DB/Resistances
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("Resistances")
@dataclass
class ResistancesRecord:
    """A record from Resistances.dbc (3.3.5a, build 12340)."""

    id: int32

    flags: int32 = int32(0)

    fizzle_sound_id: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)
