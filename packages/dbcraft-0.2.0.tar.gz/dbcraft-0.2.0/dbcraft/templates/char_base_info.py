"""CharBaseInfo.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int8 fields (1 byte each)
  - Total: 2 fields on disk

Record size: 2 * 1 = 2 bytes

See Also:
  - https://wowdev.wiki/DB/CharBaseInfo
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int8
from dbcraft.templates.base import register_template


@register_template("CharBaseInfo")
@dataclass
class CharBaseInfoRecord:
    """A record from CharBaseInfo.dbc (3.3.5a, build 12340)."""

    race_id: int8 = int8(0)

    class_id: int8 = int8(0)
