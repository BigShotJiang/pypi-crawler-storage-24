"""Lock.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 33 int32 fields
  - Total: 33 fields on disk

Record size: 33 * 4 = 132 bytes

See Also:
  - https://wowdev.wiki/DB/Lock
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("Lock")
@dataclass
class LockRecord:
    """A record from Lock.dbc (3.3.5a, build 12340)."""

    id: int32

    type_0: int32 = int32(0)

    type_1: int32 = int32(0)

    type_2: int32 = int32(0)

    type_3: int32 = int32(0)

    type_4: int32 = int32(0)

    type_5: int32 = int32(0)

    type_6: int32 = int32(0)

    type_7: int32 = int32(0)

    index_0: int32 = int32(0)

    index_1: int32 = int32(0)

    index_2: int32 = int32(0)

    index_3: int32 = int32(0)

    index_4: int32 = int32(0)

    index_5: int32 = int32(0)

    index_6: int32 = int32(0)

    index_7: int32 = int32(0)

    skill_0: int32 = int32(0)

    skill_1: int32 = int32(0)

    skill_2: int32 = int32(0)

    skill_3: int32 = int32(0)

    skill_4: int32 = int32(0)

    skill_5: int32 = int32(0)

    skill_6: int32 = int32(0)

    skill_7: int32 = int32(0)

    action_0: int32 = int32(0)

    action_1: int32 = int32(0)

    action_2: int32 = int32(0)

    action_3: int32 = int32(0)

    action_4: int32 = int32(0)

    action_5: int32 = int32(0)

    action_6: int32 = int32(0)

    action_7: int32 = int32(0)
