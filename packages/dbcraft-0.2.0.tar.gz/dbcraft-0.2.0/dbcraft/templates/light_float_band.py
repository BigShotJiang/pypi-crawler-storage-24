"""LightFloatBand.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 18 int32 fields
  - 16 float32 fields
  - Total: 34 fields on disk

Record size: 34 * 4 = 136 bytes

See Also:
  - https://wowdev.wiki/DB/LightFloatBand
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("LightFloatBand")
@dataclass
class LightFloatBandRecord:
    """A record from LightFloatBand.dbc (3.3.5a, build 12340)."""

    id: int32

    num: int32 = int32(0)

    time_0: int32 = int32(0)

    time_1: int32 = int32(0)

    time_2: int32 = int32(0)

    time_3: int32 = int32(0)

    time_4: int32 = int32(0)

    time_5: int32 = int32(0)

    time_6: int32 = int32(0)

    time_7: int32 = int32(0)

    time_8: int32 = int32(0)

    time_9: int32 = int32(0)

    time_10: int32 = int32(0)

    time_11: int32 = int32(0)

    time_12: int32 = int32(0)

    time_13: int32 = int32(0)

    time_14: int32 = int32(0)

    time_15: int32 = int32(0)

    data_0: float32 = float32(0.0)

    data_1: float32 = float32(0.0)

    data_2: float32 = float32(0.0)

    data_3: float32 = float32(0.0)

    data_4: float32 = float32(0.0)

    data_5: float32 = float32(0.0)

    data_6: float32 = float32(0.0)

    data_7: float32 = float32(0.0)

    data_8: float32 = float32(0.0)

    data_9: float32 = float32(0.0)

    data_10: float32 = float32(0.0)

    data_11: float32 = float32(0.0)

    data_12: float32 = float32(0.0)

    data_13: float32 = float32(0.0)

    data_14: float32 = float32(0.0)

    data_15: float32 = float32(0.0)
