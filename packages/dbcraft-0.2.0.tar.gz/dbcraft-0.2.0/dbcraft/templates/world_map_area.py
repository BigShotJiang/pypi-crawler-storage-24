"""WorldMapArea.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 6 int32 fields
  - 4 float32 fields
  - 1 string_ref field
  - Total: 11 fields on disk

Record size: 11 * 4 = 44 bytes

See Also:
  - https://wowdev.wiki/DB/WorldMapArea
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("WorldMapArea")
@dataclass
class WorldMapAreaRecord:
    """A record from WorldMapArea.dbc (3.3.5a, build 12340)."""

    id: int32

    map_id: int32 = int32(0)

    area_id: int32 = int32(0)

    area_name: string_ref = string_ref("")

    loc_left: float32 = float32(0.0)

    loc_right: float32 = float32(0.0)

    loc_top: float32 = float32(0.0)

    loc_bottom: float32 = float32(0.0)

    display_map_id: int32 = int32(0)

    default_dungeon_floor: int32 = int32(0)

    parent_world_map_id: int32 = int32(0)
