"""SkillTiers.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 33 int32 fields
  - Total: 33 fields on disk

Record size: 33 * 4 = 132 bytes

See Also:
  - https://wowdev.wiki/DB/SkillTiers
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("SkillTiers")
@dataclass
class SkillTiersRecord:
    """A record from SkillTiers.dbc (3.3.5a, build 12340)."""

    id: int32

    cost_0: int32 = int32(0)

    cost_1: int32 = int32(0)

    cost_2: int32 = int32(0)

    cost_3: int32 = int32(0)

    cost_4: int32 = int32(0)

    cost_5: int32 = int32(0)

    cost_6: int32 = int32(0)

    cost_7: int32 = int32(0)

    cost_8: int32 = int32(0)

    cost_9: int32 = int32(0)

    cost_10: int32 = int32(0)

    cost_11: int32 = int32(0)

    cost_12: int32 = int32(0)

    cost_13: int32 = int32(0)

    cost_14: int32 = int32(0)

    cost_15: int32 = int32(0)

    value_0: int32 = int32(0)

    value_1: int32 = int32(0)

    value_2: int32 = int32(0)

    value_3: int32 = int32(0)

    value_4: int32 = int32(0)

    value_5: int32 = int32(0)

    value_6: int32 = int32(0)

    value_7: int32 = int32(0)

    value_8: int32 = int32(0)

    value_9: int32 = int32(0)

    value_10: int32 = int32(0)

    value_11: int32 = int32(0)

    value_12: int32 = int32(0)

    value_13: int32 = int32(0)

    value_14: int32 = int32(0)

    value_15: int32 = int32(0)
