"""Map.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - 3 float32 fields
  - 1 string_ref field
  - 3 loc_string_ref fields (3 x 17 = 51 on disk)
  - Total: 66 fields on disk

Record size: 66 * 4 = 264 bytes

See Also:
  - https://wowdev.wiki/DB/Map
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("Map")
@dataclass
class MapRecord:
    """A record from Map.dbc (3.3.5a, build 12340)."""

    id: int32

    directory: string_ref = string_ref("")

    instance_type: int32 = int32(0)

    flags: int32 = int32(0)

    p_v_p: int32 = int32(0)

    map_name_lang: loc_string_ref = field(default_factory=LocalizedString)

    area_table_id: int32 = int32(0)

    map_description0_lang: loc_string_ref = field(default_factory=LocalizedString)

    map_description1_lang: loc_string_ref = field(default_factory=LocalizedString)

    loading_screen_id: int32 = int32(0)

    minimap_icon_scale: float32 = float32(0.0)

    corpse_map_id: int32 = int32(0)

    corpse_0: float32 = float32(0.0)

    corpse_1: float32 = float32(0.0)

    time_of_day_override: int32 = int32(0)

    expansion_id: int32 = int32(0)

    raid_offset: int32 = int32(0)

    max_players: int32 = int32(0)
