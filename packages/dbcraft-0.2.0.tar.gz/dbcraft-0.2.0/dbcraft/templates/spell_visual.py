"""SpellVisual.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 26 int32 fields
  - 6 float32 fields
  - Total: 32 fields on disk

Record size: 32 * 4 = 128 bytes

See Also:
  - https://wowdev.wiki/DB/SpellVisual
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("SpellVisual")
@dataclass
class SpellVisualRecord:
    """A record from SpellVisual.dbc (3.3.5a, build 12340)."""

    id: int32

    precast_kit: int32 = int32(0)

    cast_kit: int32 = int32(0)

    impact_kit: int32 = int32(0)

    state_kit: int32 = int32(0)

    state_done_kit: int32 = int32(0)

    channel_kit: int32 = int32(0)

    has_missile: int32 = int32(0)

    missile_model: int32 = int32(0)

    missile_path_type: int32 = int32(0)

    missile_destination_attachment: int32 = int32(0)

    missile_sound: int32 = int32(0)

    anim_event_sound_id: int32 = int32(0)

    flags: int32 = int32(0)

    caster_impact_kit: int32 = int32(0)

    target_impact_kit: int32 = int32(0)

    missile_attachment: int32 = int32(0)

    missile_follow_ground_height: int32 = int32(0)

    missile_follow_ground_drop_speed: int32 = int32(0)

    missile_follow_ground_approach: int32 = int32(0)

    missile_follow_ground_flags: int32 = int32(0)

    missile_motion: int32 = int32(0)

    missile_targeting_kit: int32 = int32(0)

    instant_area_kit: int32 = int32(0)

    impact_area_kit: int32 = int32(0)

    persistent_area_kit: int32 = int32(0)

    missile_cast_offset_0: float32 = float32(0.0)

    missile_cast_offset_1: float32 = float32(0.0)

    missile_cast_offset_2: float32 = float32(0.0)

    missile_impact_offset_0: float32 = float32(0.0)

    missile_impact_offset_1: float32 = float32(0.0)

    missile_impact_offset_2: float32 = float32(0.0)
