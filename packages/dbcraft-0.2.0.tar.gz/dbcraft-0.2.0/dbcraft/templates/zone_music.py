"""ZoneMusic.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 7 int32 fields
  - 1 string_ref field
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/ZoneMusic
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("ZoneMusic")
@dataclass
class ZoneMusicRecord:
    """A record from ZoneMusic.dbc (3.3.5a, build 12340)."""

    id: int32

    set_name: string_ref = string_ref("")

    silence_interval_min_0: int32 = int32(0)

    silence_interval_min_1: int32 = int32(0)

    silence_interval_max_0: int32 = int32(0)

    silence_interval_max_1: int32 = int32(0)

    sounds_0: int32 = int32(0)

    sounds_1: int32 = int32(0)
