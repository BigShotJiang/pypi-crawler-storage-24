"""SpellItemEnchantment.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 21 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 38 fields on disk

Record size: 38 * 4 = 152 bytes

See Also:
  - https://wowdev.wiki/DB/SpellItemEnchantment
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("SpellItemEnchantment")
@dataclass
class SpellItemEnchantmentRecord:
    """A record from SpellItemEnchantment.dbc (3.3.5a, build 12340)."""

    id: int32

    charges: int32 = int32(0)

    effect_0: int32 = int32(0)

    effect_1: int32 = int32(0)

    effect_2: int32 = int32(0)

    effect_points_min_0: int32 = int32(0)

    effect_points_min_1: int32 = int32(0)

    effect_points_min_2: int32 = int32(0)

    effect_points_max_0: int32 = int32(0)

    effect_points_max_1: int32 = int32(0)

    effect_points_max_2: int32 = int32(0)

    effect_arg_0: int32 = int32(0)

    effect_arg_1: int32 = int32(0)

    effect_arg_2: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    item_visual: int32 = int32(0)

    flags: int32 = int32(0)

    src_item_id: int32 = int32(0)

    condition_id: int32 = int32(0)

    required_skill_id: int32 = int32(0)

    required_skill_rank: int32 = int32(0)

    min_level: int32 = int32(0)
