"""GlyphProperties.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/GlyphProperties
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("GlyphProperties")
@dataclass
class GlyphPropertiesRecord:
    """A record from GlyphProperties.dbc (3.3.5a, build 12340)."""

    id: int32

    spell_id: int32 = int32(0)

    glyph_slot_flags: int32 = int32(0)

    spell_icon_id: int32 = int32(0)
