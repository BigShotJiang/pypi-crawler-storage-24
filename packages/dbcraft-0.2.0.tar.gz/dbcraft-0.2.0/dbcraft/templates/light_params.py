"""LightParams.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 5 float32 fields
  - Total: 9 fields on disk

Record size: 9 * 4 = 36 bytes

See Also:
  - https://wowdev.wiki/DB/LightParams
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("LightParams")
@dataclass
class LightParamsRecord:
    """A record from LightParams.dbc (3.3.5a, build 12340)."""

    id: int32

    highlight_sky: int32 = int32(0)

    light_skybox_id: int32 = int32(0)

    glow: float32 = float32(0.0)

    water_shallow_alpha: float32 = float32(0.0)

    water_deep_alpha: float32 = float32(0.0)

    ocean_shallow_alpha: float32 = float32(0.0)

    ocean_deep_alpha: float32 = float32(0.0)

    flags: int32 = int32(0)
