"""LFGDungeonExpansion.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/LFGDungeonExpansion
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("LFGDungeonExpansion")
@dataclass
class LFGDungeonExpansionRecord:
    """A record from LFGDungeonExpansion.dbc (3.3.5a, build 12340)."""

    id: int32

    lfg_id: int32 = int32(0)

    expansion_level: int32 = int32(0)

    random_id: int32 = int32(0)

    hard_level_min: int32 = int32(0)

    hard_level_max: int32 = int32(0)

    target_level_min: int32 = int32(0)

    target_level_max: int32 = int32(0)
