"""SkillRaceClassInfo.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/SkillRaceClassInfo
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("SkillRaceClassInfo")
@dataclass
class SkillRaceClassInfoRecord:
    """A record from SkillRaceClassInfo.dbc (3.3.5a, build 12340)."""

    id: int32

    skill_id: int32 = int32(0)

    race_mask: int32 = int32(0)

    class_mask: int32 = int32(0)

    flags: int32 = int32(0)

    min_level: int32 = int32(0)

    skill_tier_id: int32 = int32(0)

    skill_cost_index: int32 = int32(0)
