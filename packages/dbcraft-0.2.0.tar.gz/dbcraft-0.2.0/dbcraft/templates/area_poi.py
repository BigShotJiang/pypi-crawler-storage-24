"""AreaPOI.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 17 int32 fields
  - 3 float32 fields
  - 2 loc_string_ref fields (2 x 17 = 34 on disk)
  - Total: 54 fields on disk

Record size: 54 * 4 = 216 bytes

See Also:
  - https://wowdev.wiki/DB/AreaPOI
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("AreaPOI")
@dataclass
class AreaPOIRecord:
    """A record from AreaPOI.dbc (3.3.5a, build 12340)."""

    id: int32

    importance: int32 = int32(0)

    icon_0: int32 = int32(0)

    icon_1: int32 = int32(0)

    icon_2: int32 = int32(0)

    icon_3: int32 = int32(0)

    icon_4: int32 = int32(0)

    icon_5: int32 = int32(0)

    icon_6: int32 = int32(0)

    icon_7: int32 = int32(0)

    icon_8: int32 = int32(0)

    faction_id: int32 = int32(0)

    pos_0: float32 = float32(0.0)

    pos_1: float32 = float32(0.0)

    pos_2: float32 = float32(0.0)

    continent_id: int32 = int32(0)

    flags: int32 = int32(0)

    area_id: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    description_lang: loc_string_ref = field(default_factory=LocalizedString)

    world_state_id: int32 = int32(0)

    world_map_link: int32 = int32(0)
