"""CharTitles.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 2 loc_string_ref fields (2 x 17 = 34 on disk)
  - Total: 37 fields on disk

Record size: 37 * 4 = 148 bytes

See Also:
  - https://wowdev.wiki/DB/CharTitles
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("CharTitles")
@dataclass
class CharTitlesRecord:
    """A record from CharTitles.dbc (3.3.5a, build 12340)."""

    id: int32

    condition_id: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    name1_lang: loc_string_ref = field(default_factory=LocalizedString)

    mask_id: int32 = int32(0)
