"""SpellChainEffects.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - 33 float32 fields
  - 2 string_ref fields
  - 5 int8 fields (1 byte each)
  - Total: 48 fields on disk

Record size: 43 * 4 + 5 * 1 = 177 bytes

See Also:
  - https://wowdev.wiki/DB/SpellChainEffects
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, int8, string_ref
from dbcraft.templates.base import register_template


@register_template("SpellChainEffects")
@dataclass
class SpellChainEffectsRecord:
    """A record from SpellChainEffects.dbc (3.3.5a, build 12340)."""

    id: int32

    avg_seg_len: float32 = float32(0.0)

    width: float32 = float32(0.0)

    noise_scale: float32 = float32(0.0)

    tex_coord_scale: float32 = float32(0.0)

    seg_duration: int32 = int32(0)

    seg_delay: int32 = int32(0)

    texture: string_ref = string_ref("")

    flags: int32 = int32(0)

    joint_count: int32 = int32(0)

    joint_offset_radius: float32 = float32(0.0)

    joints_per_minor_joint: int32 = int32(0)

    minor_joints_per_major_joint: int32 = int32(0)

    minor_joint_scale: float32 = float32(0.0)

    major_joint_scale: float32 = float32(0.0)

    joint_move_speed: float32 = float32(0.0)

    joint_smoothness: float32 = float32(0.0)

    min_duration_between_joint_jumps: float32 = float32(0.0)

    max_duration_between_joint_jumps: float32 = float32(0.0)

    wave_height: float32 = float32(0.0)

    wave_freq: float32 = float32(0.0)

    wave_speed: float32 = float32(0.0)

    min_wave_angle: float32 = float32(0.0)

    max_wave_angle: float32 = float32(0.0)

    min_wave_spin: float32 = float32(0.0)

    max_wave_spin: float32 = float32(0.0)

    arc_height: float32 = float32(0.0)

    min_arc_angle: float32 = float32(0.0)

    max_arc_angle: float32 = float32(0.0)

    min_arc_spin: float32 = float32(0.0)

    max_arc_spin: float32 = float32(0.0)

    delay_between_effects: float32 = float32(0.0)

    min_flicker_on_duration: float32 = float32(0.0)

    max_flicker_on_duration: float32 = float32(0.0)

    min_flicker_off_duration: float32 = float32(0.0)

    max_flicker_off_duration: float32 = float32(0.0)

    pulse_speed: float32 = float32(0.0)

    pulse_on_length: float32 = float32(0.0)

    pulse_fade_length: float32 = float32(0.0)

    alpha: int8 = int8(0)

    red: int8 = int8(0)

    green: int8 = int8(0)

    blue: int8 = int8(0)

    blend_mode: int8 = int8(0)

    combo: string_ref = string_ref("")

    render_layer: int32 = int32(0)

    texture_length: float32 = float32(0.0)

    wave_phase: float32 = float32(0.0)
