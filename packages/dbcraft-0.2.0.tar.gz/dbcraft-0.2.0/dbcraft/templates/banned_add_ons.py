"""BannedAddOns.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - Total: 11 fields on disk

Record size: 11 * 4 = 44 bytes

See Also:
  - https://wowdev.wiki/DB/BannedAddOns
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("BannedAddOns")
@dataclass
class BannedAddOnsRecord:
    """A record from BannedAddOns.dbc (3.3.5a, build 12340)."""

    id: int32

    name_m_d5_0: int32 = int32(0)

    name_m_d5_1: int32 = int32(0)

    name_m_d5_2: int32 = int32(0)

    name_m_d5_3: int32 = int32(0)

    version_m_d5_0: int32 = int32(0)

    version_m_d5_1: int32 = int32(0)

    version_m_d5_2: int32 = int32(0)

    version_m_d5_3: int32 = int32(0)

    last_modified: int32 = int32(0)

    flags: int32 = int32(0)
