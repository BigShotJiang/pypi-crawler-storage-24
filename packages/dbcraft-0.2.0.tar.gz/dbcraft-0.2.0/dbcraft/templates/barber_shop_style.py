"""BarberShopStyle.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 5 int32 fields
  - 1 float32 field
  - 2 loc_string_ref fields (2 x 17 = 34 on disk)
  - Total: 40 fields on disk

Record size: 40 * 4 = 160 bytes

See Also:
  - https://wowdev.wiki/DB/BarberShopStyle
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("BarberShopStyle")
@dataclass
class BarberShopStyleRecord:
    """A record from BarberShopStyle.dbc (3.3.5a, build 12340)."""

    id: int32

    type: int32 = int32(0)

    display_name_lang: loc_string_ref = field(default_factory=LocalizedString)

    description_lang: loc_string_ref = field(default_factory=LocalizedString)

    cost_modifier: float32 = float32(0.0)

    race: int32 = int32(0)

    sex: int32 = int32(0)

    data: int32 = int32(0)
