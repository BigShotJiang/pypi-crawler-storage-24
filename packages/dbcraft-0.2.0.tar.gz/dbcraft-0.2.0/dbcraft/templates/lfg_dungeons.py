"""LFGDungeons.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 14 int32 fields
  - 1 string_ref field
  - 2 loc_string_ref fields (2 x 17 = 34 on disk)
  - Total: 49 fields on disk

Record size: 49 * 4 = 196 bytes

See Also:
  - https://wowdev.wiki/DB/LFGDungeons
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("LFGDungeons")
@dataclass
class LFGDungeonsRecord:
    """A record from LFGDungeons.dbc (3.3.5a, build 12340)."""

    id: int32

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    min_level: int32 = int32(0)

    max_level: int32 = int32(0)

    target_level: int32 = int32(0)

    target_level_min: int32 = int32(0)

    target_level_max: int32 = int32(0)

    map_id: int32 = int32(0)

    difficulty: int32 = int32(0)

    flags: int32 = int32(0)

    type_id: int32 = int32(0)

    faction: int32 = int32(0)

    texture_filename: string_ref = string_ref("")

    expansion_level: int32 = int32(0)

    order_index: int32 = int32(0)

    group_id: int32 = int32(0)

    description_lang: loc_string_ref = field(default_factory=LocalizedString)
