"""FactionTemplate.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 14 int32 fields
  - Total: 14 fields on disk

Record size: 14 * 4 = 56 bytes

See Also:
  - https://wowdev.wiki/DB/FactionTemplate
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("FactionTemplate")
@dataclass
class FactionTemplateRecord:
    """A record from FactionTemplate.dbc (3.3.5a, build 12340)."""

    id: int32

    faction: int32 = int32(0)

    flags: int32 = int32(0)

    faction_group: int32 = int32(0)

    friend_group: int32 = int32(0)

    enemy_group: int32 = int32(0)

    enemies_0: int32 = int32(0)

    enemies_1: int32 = int32(0)

    enemies_2: int32 = int32(0)

    enemies_3: int32 = int32(0)

    friend_0: int32 = int32(0)

    friend_1: int32 = int32(0)

    friend_2: int32 = int32(0)

    friend_3: int32 = int32(0)
