"""VocalUISounds.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 7 int32 fields
  - Total: 7 fields on disk

Record size: 7 * 4 = 28 bytes

See Also:
  - https://wowdev.wiki/DB/VocalUISounds
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("VocalUISounds")
@dataclass
class VocalUISoundsRecord:
    """A record from VocalUISounds.dbc (3.3.5a, build 12340)."""

    id: int32

    vocal_u_i_enum: int32 = int32(0)

    race_id: int32 = int32(0)

    normal_sound_id_0: int32 = int32(0)

    normal_sound_id_1: int32 = int32(0)

    pissed_sound_id_0: int32 = int32(0)

    pissed_sound_id_1: int32 = int32(0)
