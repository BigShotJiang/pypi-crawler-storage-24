"""GroundEffectTexture.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - Total: 11 fields on disk

Record size: 11 * 4 = 44 bytes

See Also:
  - https://wowdev.wiki/DB/GroundEffectTexture
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("GroundEffectTexture")
@dataclass
class GroundEffectTextureRecord:
    """A record from GroundEffectTexture.dbc (3.3.5a, build 12340)."""

    id: int32

    doodad_id_0: int32 = int32(0)

    doodad_id_1: int32 = int32(0)

    doodad_id_2: int32 = int32(0)

    doodad_id_3: int32 = int32(0)

    doodad_weight_0: int32 = int32(0)

    doodad_weight_1: int32 = int32(0)

    doodad_weight_2: int32 = int32(0)

    doodad_weight_3: int32 = int32(0)

    density: int32 = int32(0)

    sound: int32 = int32(0)
