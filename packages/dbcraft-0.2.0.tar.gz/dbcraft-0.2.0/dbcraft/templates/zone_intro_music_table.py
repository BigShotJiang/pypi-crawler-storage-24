"""ZoneIntroMusicTable.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 1 string_ref field
  - Total: 5 fields on disk

Record size: 5 * 4 = 20 bytes

See Also:
  - https://wowdev.wiki/DB/ZoneIntroMusicTable
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("ZoneIntroMusicTable")
@dataclass
class ZoneIntroMusicTableRecord:
    """A record from ZoneIntroMusicTable.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    sound_id: int32 = int32(0)

    priority: int32 = int32(0)

    min_delay_minutes: int32 = int32(0)
