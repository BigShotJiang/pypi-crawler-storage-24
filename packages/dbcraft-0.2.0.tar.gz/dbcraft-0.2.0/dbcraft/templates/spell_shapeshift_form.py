"""SpellShapeshiftForm.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 18 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 35 fields on disk

Record size: 35 * 4 = 140 bytes

See Also:
  - https://wowdev.wiki/DB/SpellShapeshiftForm
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("SpellShapeshiftForm")
@dataclass
class SpellShapeshiftFormRecord:
    """A record from SpellShapeshiftForm.dbc (3.3.5a, build 12340)."""

    id: int32

    bonus_action_bar: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    flags: int32 = int32(0)

    creature_type: int32 = int32(0)

    attack_icon_id: int32 = int32(0)

    combat_round_time: int32 = int32(0)

    creature_display_id_0: int32 = int32(0)

    creature_display_id_1: int32 = int32(0)

    creature_display_id_2: int32 = int32(0)

    creature_display_id_3: int32 = int32(0)

    preset_spell_id_0: int32 = int32(0)

    preset_spell_id_1: int32 = int32(0)

    preset_spell_id_2: int32 = int32(0)

    preset_spell_id_3: int32 = int32(0)

    preset_spell_id_4: int32 = int32(0)

    preset_spell_id_5: int32 = int32(0)

    preset_spell_id_6: int32 = int32(0)

    preset_spell_id_7: int32 = int32(0)
