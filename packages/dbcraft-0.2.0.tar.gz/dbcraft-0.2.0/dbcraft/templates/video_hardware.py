"""VideoHardware.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 21 int32 fields
  - 2 string_ref fields
  - Total: 23 fields on disk

Record size: 23 * 4 = 92 bytes

See Also:
  - https://wowdev.wiki/DB/VideoHardware
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("VideoHardware")
@dataclass
class VideoHardwareRecord:
    """A record from VideoHardware.dbc (3.3.5a, build 12340)."""

    id: int32

    vendor_id: int32 = int32(0)

    device_id: int32 = int32(0)

    farclip_idx: int32 = int32(0)

    terrain_l_o_d_dist_idx: int32 = int32(0)

    terrain_shadow_l_o_d: int32 = int32(0)

    detail_doodad_density_idx: int32 = int32(0)

    detail_doodad_alpha: int32 = int32(0)

    animating_doodad_idx: int32 = int32(0)

    trilinear: int32 = int32(0)

    num_lights: int32 = int32(0)

    specularity: int32 = int32(0)

    water_l_o_d_idx: int32 = int32(0)

    particle_density_idx: int32 = int32(0)

    unit_draw_dist_idx: int32 = int32(0)

    small_cull_dist_idx: int32 = int32(0)

    resolution_idx: int32 = int32(0)

    base_mip_level: int32 = int32(0)

    ogl_overrides: string_ref = string_ref("")

    d3d_overrides: string_ref = string_ref("")

    fix_lag: int32 = int32(0)

    multisample: int32 = int32(0)

    atlasdisable: int32 = int32(0)
