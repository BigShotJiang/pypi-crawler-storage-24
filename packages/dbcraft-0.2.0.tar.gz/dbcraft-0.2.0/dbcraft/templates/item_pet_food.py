"""ItemPetFood.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 18 fields on disk

Record size: 18 * 4 = 72 bytes

See Also:
  - https://wowdev.wiki/DB/ItemPetFood
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("ItemPetFood")
@dataclass
class ItemPetFoodRecord:
    """A record from ItemPetFood.dbc (3.3.5a, build 12340)."""

    id: int32

    name_lang: loc_string_ref = field(default_factory=LocalizedString)
