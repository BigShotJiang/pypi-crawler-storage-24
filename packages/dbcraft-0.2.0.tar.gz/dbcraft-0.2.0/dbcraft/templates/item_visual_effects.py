"""ItemVisualEffects.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 1 string_ref field
  - Total: 2 fields on disk

Record size: 2 * 4 = 8 bytes

See Also:
  - https://wowdev.wiki/DB/ItemVisualEffects
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("ItemVisualEffects")
@dataclass
class ItemVisualEffectsRecord:
    """A record from ItemVisualEffects.dbc (3.3.5a, build 12340)."""

    id: int32

    model: string_ref = string_ref("")
