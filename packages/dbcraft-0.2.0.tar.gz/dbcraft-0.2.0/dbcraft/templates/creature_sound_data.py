"""CreatureSoundData.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 36 int32 fields
  - 2 float32 fields
  - Total: 38 fields on disk

Record size: 38 * 4 = 152 bytes

See Also:
  - https://wowdev.wiki/DB/CreatureSoundData
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("CreatureSoundData")
@dataclass
class CreatureSoundDataRecord:
    """A record from CreatureSoundData.dbc (3.3.5a, build 12340)."""

    id: int32

    sound_exertion_id: int32 = int32(0)

    sound_exertion_critical_id: int32 = int32(0)

    sound_injury_id: int32 = int32(0)

    sound_injury_critical_id: int32 = int32(0)

    sound_injury_crushing_blow_id: int32 = int32(0)

    sound_death_id: int32 = int32(0)

    sound_stun_id: int32 = int32(0)

    sound_stand_id: int32 = int32(0)

    sound_footstep_id: int32 = int32(0)

    sound_aggro_id: int32 = int32(0)

    sound_wing_flap_id: int32 = int32(0)

    sound_wing_glide_id: int32 = int32(0)

    sound_alert_id: int32 = int32(0)

    sound_fidget_0: int32 = int32(0)

    sound_fidget_1: int32 = int32(0)

    sound_fidget_2: int32 = int32(0)

    sound_fidget_3: int32 = int32(0)

    sound_fidget_4: int32 = int32(0)

    custom_attack_0: int32 = int32(0)

    custom_attack_1: int32 = int32(0)

    custom_attack_2: int32 = int32(0)

    custom_attack_3: int32 = int32(0)

    n_p_c_sound_id: int32 = int32(0)

    loop_sound_id: int32 = int32(0)

    creature_impact_type: int32 = int32(0)

    sound_jump_start_id: int32 = int32(0)

    sound_jump_end_id: int32 = int32(0)

    sound_pet_attack_id: int32 = int32(0)

    sound_pet_order_id: int32 = int32(0)

    sound_pet_dismiss_id: int32 = int32(0)

    fidget_delay_seconds_min: float32 = float32(0.0)

    fidget_delay_seconds_max: float32 = float32(0.0)

    birth_sound_id: int32 = int32(0)

    spell_cast_directed_sound_id: int32 = int32(0)

    submerge_sound_id: int32 = int32(0)

    submerged_sound_id: int32 = int32(0)

    creature_sound_data_id_pet: int32 = int32(0)
