"""DungeonMapChunk.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 1 float32 field
  - Total: 5 fields on disk

Record size: 5 * 4 = 20 bytes

See Also:
  - https://wowdev.wiki/DB/DungeonMapChunk
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("DungeonMapChunk")
@dataclass
class DungeonMapChunkRecord:
    """A record from DungeonMapChunk.dbc (3.3.5a, build 12340)."""

    id: int32

    map_id: int32 = int32(0)

    w_m_o_group_id: int32 = int32(0)

    dungeon_map_id: int32 = int32(0)

    min_z: float32 = float32(0.0)
