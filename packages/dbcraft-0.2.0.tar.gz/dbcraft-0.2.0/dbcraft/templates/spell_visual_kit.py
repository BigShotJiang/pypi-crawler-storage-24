"""SpellVisualKit.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 22 int32 fields
  - 16 float32 fields
  - Total: 38 fields on disk

Record size: 38 * 4 = 152 bytes

See Also:
  - https://wowdev.wiki/DB/SpellVisualKit
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("SpellVisualKit")
@dataclass
class SpellVisualKitRecord:
    """A record from SpellVisualKit.dbc (3.3.5a, build 12340)."""

    id: int32

    start_anim_id: int32 = int32(0)

    anim_id: int32 = int32(0)

    head_effect: int32 = int32(0)

    chest_effect: int32 = int32(0)

    base_effect: int32 = int32(0)

    left_hand_effect: int32 = int32(0)

    right_hand_effect: int32 = int32(0)

    breath_effect: int32 = int32(0)

    left_weapon_effect: int32 = int32(0)

    right_weapon_effect: int32 = int32(0)

    special_effect_0: int32 = int32(0)

    special_effect_1: int32 = int32(0)

    special_effect_2: int32 = int32(0)

    world_effect: int32 = int32(0)

    sound_id: int32 = int32(0)

    shake_id: int32 = int32(0)

    char_proc_0: int32 = int32(0)

    char_proc_1: int32 = int32(0)

    char_proc_2: int32 = int32(0)

    char_proc_3: int32 = int32(0)

    char_param_zero_0: float32 = float32(0.0)

    char_param_zero_1: float32 = float32(0.0)

    char_param_zero_2: float32 = float32(0.0)

    char_param_zero_3: float32 = float32(0.0)

    char_param_one_0: float32 = float32(0.0)

    char_param_one_1: float32 = float32(0.0)

    char_param_one_2: float32 = float32(0.0)

    char_param_one_3: float32 = float32(0.0)

    char_param_two_0: float32 = float32(0.0)

    char_param_two_1: float32 = float32(0.0)

    char_param_two_2: float32 = float32(0.0)

    char_param_two_3: float32 = float32(0.0)

    char_param_three_0: float32 = float32(0.0)

    char_param_three_1: float32 = float32(0.0)

    char_param_three_2: float32 = float32(0.0)

    char_param_three_3: float32 = float32(0.0)

    flags: int32 = int32(0)
