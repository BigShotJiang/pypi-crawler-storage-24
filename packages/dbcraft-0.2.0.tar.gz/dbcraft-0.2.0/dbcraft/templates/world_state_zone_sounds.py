"""WorldStateZoneSounds.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/WorldStateZoneSounds
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("WorldStateZoneSounds")
@dataclass
class WorldStateZoneSoundsRecord:
    """A record from WorldStateZoneSounds.dbc (3.3.5a, build 12340)."""

    world_state_id: int32 = int32(0)

    world_state_value: int32 = int32(0)

    area_id: int32 = int32(0)

    w_m_o_area_id: int32 = int32(0)

    zone_intro_music_id: int32 = int32(0)

    zone_music_id: int32 = int32(0)

    sound_ambience_id: int32 = int32(0)

    sound_provider_preferences_id: int32 = int32(0)
