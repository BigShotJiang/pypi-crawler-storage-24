"""BattlemasterList.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 15 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 32 fields on disk

Record size: 32 * 4 = 128 bytes

See Also:
  - https://wowdev.wiki/DB/BattlemasterList
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("BattlemasterList")
@dataclass
class BattlemasterListRecord:
    """A record from BattlemasterList.dbc (3.3.5a, build 12340)."""

    id: int32

    map_id_0: int32 = int32(0)

    map_id_1: int32 = int32(0)

    map_id_2: int32 = int32(0)

    map_id_3: int32 = int32(0)

    map_id_4: int32 = int32(0)

    map_id_5: int32 = int32(0)

    map_id_6: int32 = int32(0)

    map_id_7: int32 = int32(0)

    instance_type: int32 = int32(0)

    groups_allowed: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    max_group_size: int32 = int32(0)

    holiday_world_state: int32 = int32(0)

    min_level: int32 = int32(0)

    max_level: int32 = int32(0)
