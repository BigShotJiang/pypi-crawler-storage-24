"""ScalingStatValues.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 24 int32 fields
  - Total: 24 fields on disk

Record size: 24 * 4 = 96 bytes

See Also:
  - https://wowdev.wiki/DB/ScalingStatValues
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("ScalingStatValues")
@dataclass
class ScalingStatValuesRecord:
    """A record from ScalingStatValues.dbc (3.3.5a, build 12340)."""

    id: int32

    charlevel: int32 = int32(0)

    shoulder_budget: int32 = int32(0)

    trinket_budget: int32 = int32(0)

    weapon_budget1_h: int32 = int32(0)

    ranged_budget: int32 = int32(0)

    cloth_shoulder_armor: int32 = int32(0)

    leather_shoulder_armor: int32 = int32(0)

    mail_shoulder_armor: int32 = int32(0)

    plate_shoulder_armor: int32 = int32(0)

    weapon_d_p_s1_h: int32 = int32(0)

    weapon_d_p_s2_h: int32 = int32(0)

    spellcaster_d_p_s1_h: int32 = int32(0)

    spellcaster_d_p_s2_h: int32 = int32(0)

    ranged_d_p_s: int32 = int32(0)

    wand_d_p_s: int32 = int32(0)

    spell_power: int32 = int32(0)

    primary_budget: int32 = int32(0)

    tertiary_budget: int32 = int32(0)

    cloth_cloak_armor: int32 = int32(0)

    cloth_chest_armor: int32 = int32(0)

    leather_chest_armor: int32 = int32(0)

    mail_chest_armor: int32 = int32(0)

    plate_chest_armor: int32 = int32(0)
