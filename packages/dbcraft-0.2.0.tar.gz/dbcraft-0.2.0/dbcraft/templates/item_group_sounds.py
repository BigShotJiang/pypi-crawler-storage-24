"""ItemGroupSounds.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 5 int32 fields
  - Total: 5 fields on disk

Record size: 5 * 4 = 20 bytes

See Also:
  - https://wowdev.wiki/DB/ItemGroupSounds
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("ItemGroupSounds")
@dataclass
class ItemGroupSoundsRecord:
    """A record from ItemGroupSounds.dbc (3.3.5a, build 12340)."""

    id: int32

    sound_0: int32 = int32(0)

    sound_1: int32 = int32(0)

    sound_2: int32 = int32(0)

    sound_3: int32 = int32(0)
