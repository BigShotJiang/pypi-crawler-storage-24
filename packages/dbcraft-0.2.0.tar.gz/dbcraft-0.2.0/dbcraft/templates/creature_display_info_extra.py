"""CreatureDisplayInfoExtra.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 20 int32 fields
  - 1 string_ref field
  - Total: 21 fields on disk

Record size: 21 * 4 = 84 bytes

See Also:
  - https://wowdev.wiki/DB/CreatureDisplayInfoExtra
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("CreatureDisplayInfoExtra")
@dataclass
class CreatureDisplayInfoExtraRecord:
    """A record from CreatureDisplayInfoExtra.dbc (3.3.5a, build 12340)."""

    id: int32

    display_race_id: int32 = int32(0)

    display_sex_id: int32 = int32(0)

    skin_id: int32 = int32(0)

    face_id: int32 = int32(0)

    hair_style_id: int32 = int32(0)

    hair_color_id: int32 = int32(0)

    facial_hair_id: int32 = int32(0)

    n_p_c_item_display_0: int32 = int32(0)

    n_p_c_item_display_1: int32 = int32(0)

    n_p_c_item_display_2: int32 = int32(0)

    n_p_c_item_display_3: int32 = int32(0)

    n_p_c_item_display_4: int32 = int32(0)

    n_p_c_item_display_5: int32 = int32(0)

    n_p_c_item_display_6: int32 = int32(0)

    n_p_c_item_display_7: int32 = int32(0)

    n_p_c_item_display_8: int32 = int32(0)

    n_p_c_item_display_9: int32 = int32(0)

    n_p_c_item_display_10: int32 = int32(0)

    flags: int32 = int32(0)

    bake_name: string_ref = string_ref("")
