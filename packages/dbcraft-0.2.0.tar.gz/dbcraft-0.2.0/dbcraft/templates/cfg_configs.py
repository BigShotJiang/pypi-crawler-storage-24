"""Cfg_Configs.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/Cfg_Configs
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("Cfg_Configs")
@dataclass
class CfgConfigsRecord:
    """A record from Cfg_Configs.dbc (3.3.5a, build 12340)."""

    id: int32

    realm_type: int32 = int32(0)

    player_killing_allowed: int32 = int32(0)

    roleplaying: int32 = int32(0)
