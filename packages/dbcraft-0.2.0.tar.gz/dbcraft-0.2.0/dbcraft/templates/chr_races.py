"""ChrRaces.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 13 int32 fields
  - 5 string_ref fields
  - 3 loc_string_ref fields (3 x 17 = 51 on disk)
  - Total: 69 fields on disk

Record size: 69 * 4 = 276 bytes

See Also:
  - https://wowdev.wiki/DB/ChrRaces
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("ChrRaces")
@dataclass
class ChrRacesRecord:
    """A record from ChrRaces.dbc (3.3.5a, build 12340)."""

    id: int32

    flags: int32 = int32(0)

    faction_id: int32 = int32(0)

    exploration_sound_id: int32 = int32(0)

    male_display_id: int32 = int32(0)

    female_display_id: int32 = int32(0)

    client_prefix: string_ref = string_ref("")

    base_language: int32 = int32(0)

    creature_type: int32 = int32(0)

    res_sickness_spell_id: int32 = int32(0)

    splash_sound_id: int32 = int32(0)

    client_file_string: string_ref = string_ref("")

    cinematic_sequence_id: int32 = int32(0)

    alliance: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    name_female_lang: loc_string_ref = field(default_factory=LocalizedString)

    name_male_lang: loc_string_ref = field(default_factory=LocalizedString)

    facial_hair_customization_0: string_ref = string_ref("")

    facial_hair_customization_1: string_ref = string_ref("")

    hair_customization: string_ref = string_ref("")

    required_expansion: int32 = int32(0)
