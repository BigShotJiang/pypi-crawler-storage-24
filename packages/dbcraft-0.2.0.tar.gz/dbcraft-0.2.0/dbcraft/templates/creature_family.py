"""CreatureFamily.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - 2 float32 fields
  - 1 string_ref field
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 28 fields on disk

Record size: 28 * 4 = 112 bytes

See Also:
  - https://wowdev.wiki/DB/CreatureFamily
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("CreatureFamily")
@dataclass
class CreatureFamilyRecord:
    """A record from CreatureFamily.dbc (3.3.5a, build 12340)."""

    id: int32

    min_scale: float32 = float32(0.0)

    min_scale_level: int32 = int32(0)

    max_scale: float32 = float32(0.0)

    max_scale_level: int32 = int32(0)

    skill_line_0: int32 = int32(0)

    skill_line_1: int32 = int32(0)

    pet_food_mask: int32 = int32(0)

    pet_talent_type: int32 = int32(0)

    category_enum_id: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    icon_file: string_ref = string_ref("")
