"""Light.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 10 int32 fields
  - 5 float32 fields
  - Total: 15 fields on disk

Record size: 15 * 4 = 60 bytes

See Also:
  - https://wowdev.wiki/DB/Light
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("Light")
@dataclass
class LightRecord:
    """A record from Light.dbc (3.3.5a, build 12340)."""

    id: int32

    continent_id: int32 = int32(0)

    game_coords_0: float32 = float32(0.0)

    game_coords_1: float32 = float32(0.0)

    game_coords_2: float32 = float32(0.0)

    game_falloff_start: float32 = float32(0.0)

    game_falloff_end: float32 = float32(0.0)

    light_params_id_0: int32 = int32(0)

    light_params_id_1: int32 = int32(0)

    light_params_id_2: int32 = int32(0)

    light_params_id_3: int32 = int32(0)

    light_params_id_4: int32 = int32(0)

    light_params_id_5: int32 = int32(0)

    light_params_id_6: int32 = int32(0)

    light_params_id_7: int32 = int32(0)
