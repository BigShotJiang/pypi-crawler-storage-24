"""Base class and registry for DBC record templates.

Templates are Python dataclasses whose field annotations use the type
markers from `dbcraft.core.types` (uint32, int32, float32, string_ref,
loc_string_ref). The template system introspects these annotations to
determine the binary layout of each record.

Each template registers itself in a global registry keyed by DBC filename
(e.g. "Spell", "Map", "CharTitles") so that DbcFile can auto-detect
the correct template when reading a file.
"""

from __future__ import annotations

import dataclasses
import struct
from typing import Any, get_type_hints

from dbcraft.core.string_block import StringBlockBuilder, StringBlockReader
from dbcraft.core.types import (
    LOC_FIELD_COUNT,
    LOCALE_COUNT,
    LocalizedString,
)

# Global registry mapping DBC name -> record class.
_TEMPLATE_REGISTRY: dict[str, type] = {}


def register_template(dbc_name: str):
    """Class decorator that registers a record dataclass for a DBC file.

    Args:
        dbc_name: The DBC file name without extension (e.g. "Spell", "Map").
    """

    def decorator(cls: type) -> type:
        _TEMPLATE_REGISTRY[dbc_name] = cls
        return cls

    return decorator


def get_template(dbc_name: str) -> type:
    """Look up a registered template by DBC name.

    Args:
        dbc_name: The DBC file name without extension.

    Returns:
        The record dataclass type.

    Raises:
        KeyError: If no template is registered for the given name.
    """
    if dbc_name not in _TEMPLATE_REGISTRY:
        raise KeyError(
            f"No template registered for DBC '{dbc_name}'. "
            f"Available: {sorted(_TEMPLATE_REGISTRY.keys())}"
        )
    return _TEMPLATE_REGISTRY[dbc_name]


def get_all_templates() -> dict[str, type]:
    """Return a copy of the full template registry."""
    return dict(_TEMPLATE_REGISTRY)


# Field type identifiers used by the introspection system.
_TYPE_UINT32 = "uint32"
_TYPE_INT32 = "int32"
_TYPE_INT8 = "int8"
_TYPE_FLOAT32 = "float32"
_TYPE_STRING_REF = "string_ref"
_TYPE_LOC_STRING_REF = "loc_string_ref"


def _resolve_type_name(annotation: Any) -> str:
    """Resolve a field annotation to a type name string.

    Handles NewType aliases by checking __supertype__ chain.
    """
    # NewType objects in Python 3.10+ have __supertype__
    name = getattr(annotation, "__name__", None)
    if name in (
        _TYPE_UINT32,
        _TYPE_INT32,
        _TYPE_INT8,
        _TYPE_FLOAT32,
        _TYPE_STRING_REF,
        _TYPE_LOC_STRING_REF,
    ):
        return name

    raise ValueError(f"Unknown field type annotation: {annotation!r}")


def get_field_count(record_cls: type) -> int:
    """Calculate the number of logical fields a record template occupies.

    A loc_string_ref field expands to 17 fields (16 locales + 1 flags).
    All other field types (uint32, int32, int8, float32, string_ref)
    occupy exactly 1 logical field each. Note that int8 fields are 1 byte
    on disk but still count as 1 field here; use ``get_record_size`` to
    obtain the true byte width.

    Args:
        record_cls: A record dataclass type.

    Returns:
        The total number of logical fields per record.
    """
    hints = get_type_hints(record_cls)
    count = 0
    for annotation in hints.values():
        type_name = _resolve_type_name(annotation)
        if type_name == _TYPE_LOC_STRING_REF:
            count += LOC_FIELD_COUNT
        else:
            count += 1
    return count


def get_record_size(record_cls: type) -> int:
    """Calculate the number of bytes a record occupies on disk.

    Most field types are 4 bytes, loc_string_ref is 68 bytes (17 uint32),
    and int8 fields occupy 1 byte.
    """
    hints = get_type_hints(record_cls)
    size = 0
    for annotation in hints.values():
        type_name = _resolve_type_name(annotation)
        if type_name == _TYPE_LOC_STRING_REF:
            size += LOC_FIELD_COUNT * 4
        elif type_name == _TYPE_INT8:
            size += 1
        else:
            size += 4
    return size


def deserialize_record(
    record_cls: type,
    data: bytes,
    offset: int,
    string_block: StringBlockReader,
) -> Any:
    """Deserialize a single record from raw binary data.

    Args:
        record_cls: The record dataclass type.
        data: The full raw record data (all records concatenated).
        offset: Byte offset of this record within data.
        string_block: Reader for resolving string offsets.

    Returns:
        An instance of record_cls populated with deserialized values.
    """
    hints = get_type_hints(record_cls)
    fields = dataclasses.fields(record_cls)
    kwargs: dict[str, Any] = {}
    pos = offset

    for f in fields:
        annotation = hints[f.name]
        type_name = _resolve_type_name(annotation)

        match type_name:
            case "uint32":
                (value,) = struct.unpack_from("<I", data, pos)
                kwargs[f.name] = value
                pos += 4

            case "int32":
                (value,) = struct.unpack_from("<i", data, pos)
                kwargs[f.name] = value
                pos += 4

            case "int8":
                (value,) = struct.unpack_from("<b", data, pos)
                kwargs[f.name] = value
                pos += 1

            case "float32":
                (value,) = struct.unpack_from("<f", data, pos)
                kwargs[f.name] = value
                pos += 4

            case "string_ref":
                (str_offset,) = struct.unpack_from("<I", data, pos)
                kwargs[f.name] = string_block.get(str_offset)
                pos += 4

            case "loc_string_ref":
                strings = []
                for _ in range(LOCALE_COUNT):
                    (str_offset,) = struct.unpack_from("<I", data, pos)
                    strings.append(string_block.get(str_offset))
                    pos += 4
                (flags,) = struct.unpack_from("<I", data, pos)
                pos += 4
                kwargs[f.name] = LocalizedString(_strings=strings, flags=flags)

    return record_cls(**kwargs)


def serialize_record(
    record: Any,
    string_block_builder: StringBlockBuilder,
) -> bytes:
    """Serialize a single record to raw binary data.

    String values are added to the string block builder and replaced
    with their offsets in the binary output.

    Args:
        record: An instance of a record dataclass.
        string_block_builder: Builder for collecting strings.

    Returns:
        The raw binary representation of the record.
    """
    hints = get_type_hints(type(record))
    fields = dataclasses.fields(record)
    parts: list[bytes] = []

    for f in fields:
        annotation = hints[f.name]
        type_name = _resolve_type_name(annotation)
        value = getattr(record, f.name)

        match type_name:
            case "uint32":
                parts.append(struct.pack("<I", value))

            case "int32":
                parts.append(struct.pack("<i", value))

            case "int8":
                parts.append(struct.pack("<b", value))

            case "float32":
                parts.append(struct.pack("<f", value))

            case "string_ref":
                offset = string_block_builder.add(value)
                parts.append(struct.pack("<I", offset))

            case "loc_string_ref":
                loc: LocalizedString = value
                for i in range(LOCALE_COUNT):
                    offset = string_block_builder.add(loc[i])
                    parts.append(struct.pack("<I", offset))
                parts.append(struct.pack("<I", loc.flags))

    return b"".join(parts)
