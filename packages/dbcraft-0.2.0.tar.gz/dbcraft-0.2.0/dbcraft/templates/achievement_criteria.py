"""Achievement_Criteria.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 14 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 31 fields on disk

Record size: 31 * 4 = 124 bytes

See Also:
  - https://wowdev.wiki/DB/Achievement_Criteria
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("Achievement_Criteria")
@dataclass
class AchievementCriteriaRecord:
    """A record from Achievement_Criteria.dbc (3.3.5a, build 12340)."""

    id: int32

    achievement_id: int32 = int32(0)

    type: int32 = int32(0)

    asset_id: int32 = int32(0)

    quantity: int32 = int32(0)

    start_event: int32 = int32(0)

    start_asset: int32 = int32(0)

    fail_event: int32 = int32(0)

    fail_asset: int32 = int32(0)

    description_lang: loc_string_ref = field(default_factory=LocalizedString)

    flags: int32 = int32(0)

    timer_start_event: int32 = int32(0)

    timer_asset_id: int32 = int32(0)

    timer_time: int32 = int32(0)

    ui_order: int32 = int32(0)
