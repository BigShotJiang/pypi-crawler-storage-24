"""PetPersonality.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 3 float32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 24 fields on disk

Record size: 24 * 4 = 96 bytes

See Also:
  - https://wowdev.wiki/DB/PetPersonality
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("PetPersonality")
@dataclass
class PetPersonalityRecord:
    """A record from PetPersonality.dbc (3.3.5a, build 12340)."""

    id: int32

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    happiness_threshold_0: int32 = int32(0)

    happiness_threshold_1: int32 = int32(0)

    happiness_threshold_2: int32 = int32(0)

    happiness_damage_0: float32 = float32(0.0)

    happiness_damage_1: float32 = float32(0.0)

    happiness_damage_2: float32 = float32(0.0)
