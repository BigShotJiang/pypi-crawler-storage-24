"""CharacterFacialHairStyles.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/CharacterFacialHairStyles
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("CharacterFacialHairStyles")
@dataclass
class CharacterFacialHairStylesRecord:
    """A record from CharacterFacialHairStyles.dbc (3.3.5a, build 12340)."""

    race_id: int32 = int32(0)

    sex_id: int32 = int32(0)

    variation_id: int32 = int32(0)

    geoset_0: int32 = int32(0)

    geoset_1: int32 = int32(0)

    geoset_2: int32 = int32(0)

    geoset_3: int32 = int32(0)

    geoset_4: int32 = int32(0)
