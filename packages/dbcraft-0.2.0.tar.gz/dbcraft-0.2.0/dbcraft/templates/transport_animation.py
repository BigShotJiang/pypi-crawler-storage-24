"""TransportAnimation.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 3 float32 fields
  - Total: 7 fields on disk

Record size: 7 * 4 = 28 bytes

See Also:
  - https://wowdev.wiki/DB/TransportAnimation
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("TransportAnimation")
@dataclass
class TransportAnimationRecord:
    """A record from TransportAnimation.dbc (3.3.5a, build 12340)."""

    id: int32

    transport_id: int32 = int32(0)

    time_index: int32 = int32(0)

    pos_0: float32 = float32(0.0)

    pos_1: float32 = float32(0.0)

    pos_2: float32 = float32(0.0)

    sequence_id: int32 = int32(0)
