"""GMSurveySurveys.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - Total: 11 fields on disk

Record size: 11 * 4 = 44 bytes

See Also:
  - https://wowdev.wiki/DB/GMSurveySurveys
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("GMSurveySurveys")
@dataclass
class GMSurveySurveysRecord:
    """A record from GMSurveySurveys.dbc (3.3.5a, build 12340)."""

    id: int32

    q_0: int32 = int32(0)

    q_1: int32 = int32(0)

    q_2: int32 = int32(0)

    q_3: int32 = int32(0)

    q_4: int32 = int32(0)

    q_5: int32 = int32(0)

    q_6: int32 = int32(0)

    q_7: int32 = int32(0)

    q_8: int32 = int32(0)

    q_9: int32 = int32(0)
