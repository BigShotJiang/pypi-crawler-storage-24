"""SpellCastTimes.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/SpellCastTimes
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("SpellCastTimes")
@dataclass
class SpellCastTimesRecord:
    """A record from SpellCastTimes.dbc (3.3.5a, build 12340)."""

    id: int32

    base: int32 = int32(0)

    per_level: int32 = int32(0)

    minimum: int32 = int32(0)
