"""ItemDisplayInfo.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - 14 string_ref fields
  - Total: 25 fields on disk

Record size: 25 * 4 = 100 bytes

See Also:
  - https://wowdev.wiki/DB/ItemDisplayInfo
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("ItemDisplayInfo")
@dataclass
class ItemDisplayInfoRecord:
    """A record from ItemDisplayInfo.dbc (3.3.5a, build 12340)."""

    id: int32

    model_name_0: string_ref = string_ref("")

    model_name_1: string_ref = string_ref("")

    model_texture_0: string_ref = string_ref("")

    model_texture_1: string_ref = string_ref("")

    inventory_icon_0: string_ref = string_ref("")

    inventory_icon_1: string_ref = string_ref("")

    geoset_group_0: int32 = int32(0)

    geoset_group_1: int32 = int32(0)

    geoset_group_2: int32 = int32(0)

    flags: int32 = int32(0)

    spell_visual_id: int32 = int32(0)

    group_sound_index: int32 = int32(0)

    helmet_geoset_vis_id_0: int32 = int32(0)

    helmet_geoset_vis_id_1: int32 = int32(0)

    texture_0: string_ref = string_ref("")

    texture_1: string_ref = string_ref("")

    texture_2: string_ref = string_ref("")

    texture_3: string_ref = string_ref("")

    texture_4: string_ref = string_ref("")

    texture_5: string_ref = string_ref("")

    texture_6: string_ref = string_ref("")

    texture_7: string_ref = string_ref("")

    item_visual: int32 = int32(0)

    particle_color_id: int32 = int32(0)
