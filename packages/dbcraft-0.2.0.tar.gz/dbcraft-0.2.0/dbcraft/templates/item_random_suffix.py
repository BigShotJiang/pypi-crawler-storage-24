"""ItemRandomSuffix.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - 1 string_ref field
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 29 fields on disk

Record size: 29 * 4 = 116 bytes

See Also:
  - https://wowdev.wiki/DB/ItemRandomSuffix
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref, string_ref
from dbcraft.templates.base import register_template


@register_template("ItemRandomSuffix")
@dataclass
class ItemRandomSuffixRecord:
    """A record from ItemRandomSuffix.dbc (3.3.5a, build 12340)."""

    id: int32

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    internal_name: string_ref = string_ref("")

    enchantment_0: int32 = int32(0)

    enchantment_1: int32 = int32(0)

    enchantment_2: int32 = int32(0)

    enchantment_3: int32 = int32(0)

    enchantment_4: int32 = int32(0)

    allocation_pct_0: int32 = int32(0)

    allocation_pct_1: int32 = int32(0)

    allocation_pct_2: int32 = int32(0)

    allocation_pct_3: int32 = int32(0)

    allocation_pct_4: int32 = int32(0)
