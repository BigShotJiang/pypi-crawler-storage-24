"""ChatChannels.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 2 loc_string_ref fields (2 x 17 = 34 on disk)
  - Total: 37 fields on disk

Record size: 37 * 4 = 148 bytes

See Also:
  - https://wowdev.wiki/DB/ChatChannels
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("ChatChannels")
@dataclass
class ChatChannelsRecord:
    """A record from ChatChannels.dbc (3.3.5a, build 12340)."""

    id: int32

    flags: int32 = int32(0)

    faction_group: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    shortcut_lang: loc_string_ref = field(default_factory=LocalizedString)
