"""SoundAmbience.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - Total: 3 fields on disk

Record size: 3 * 4 = 12 bytes

See Also:
  - https://wowdev.wiki/DB/SoundAmbience
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("SoundAmbience")
@dataclass
class SoundAmbienceRecord:
    """A record from SoundAmbience.dbc (3.3.5a, build 12340)."""

    id: int32

    ambience_id_0: int32 = int32(0)

    ambience_id_1: int32 = int32(0)
