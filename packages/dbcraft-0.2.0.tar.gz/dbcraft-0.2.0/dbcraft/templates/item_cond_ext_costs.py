"""ItemCondExtCosts.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/ItemCondExtCosts
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("ItemCondExtCosts")
@dataclass
class ItemCondExtCostsRecord:
    """A record from ItemCondExtCosts.dbc (3.3.5a, build 12340)."""

    id: int32

    cond_extended_cost: int32 = int32(0)

    item_extended_cost_entry: int32 = int32(0)

    arena_season: int32 = int32(0)
