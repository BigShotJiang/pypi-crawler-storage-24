"""SpellItemEnchantmentCondition.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - 20 int8 fields (1 byte each)
  - Total: 31 fields on disk

Record size: 11 * 4 + 20 * 1 = 64 bytes

See Also:
  - https://wowdev.wiki/DB/SpellItemEnchantmentCondition
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, int8
from dbcraft.templates.base import register_template


@register_template("SpellItemEnchantmentCondition")
@dataclass
class SpellItemEnchantmentConditionRecord:
    """A record from SpellItemEnchantmentCondition.dbc (3.3.5a, build 12340)."""

    id: int32

    lt_operand_type_0: int8 = int8(0)

    lt_operand_type_1: int8 = int8(0)

    lt_operand_type_2: int8 = int8(0)

    lt_operand_type_3: int8 = int8(0)

    lt_operand_type_4: int8 = int8(0)

    lt_operand_0: int32 = int32(0)

    lt_operand_1: int32 = int32(0)

    lt_operand_2: int32 = int32(0)

    lt_operand_3: int32 = int32(0)

    lt_operand_4: int32 = int32(0)

    operator_0: int8 = int8(0)

    operator_1: int8 = int8(0)

    operator_2: int8 = int8(0)

    operator_3: int8 = int8(0)

    operator_4: int8 = int8(0)

    rt_operand_type_0: int8 = int8(0)

    rt_operand_type_1: int8 = int8(0)

    rt_operand_type_2: int8 = int8(0)

    rt_operand_type_3: int8 = int8(0)

    rt_operand_type_4: int8 = int8(0)

    rt_operand_0: int32 = int32(0)

    rt_operand_1: int32 = int32(0)

    rt_operand_2: int32 = int32(0)

    rt_operand_3: int32 = int32(0)

    rt_operand_4: int32 = int32(0)

    logic_0: int8 = int8(0)

    logic_1: int8 = int8(0)

    logic_2: int8 = int8(0)

    logic_3: int8 = int8(0)

    logic_4: int8 = int8(0)
