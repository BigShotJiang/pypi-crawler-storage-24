"""AttackAnimKits.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 5 int32 fields
  - Total: 5 fields on disk

Record size: 5 * 4 = 20 bytes

See Also:
  - https://wowdev.wiki/DB/AttackAnimKits
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("AttackAnimKits")
@dataclass
class AttackAnimKitsRecord:
    """A record from AttackAnimKits.dbc (3.3.5a, build 12340)."""

    id: int32

    item_subclass_id: int32 = int32(0)

    anim_type_id: int32 = int32(0)

    anim_frequency: int32 = int32(0)

    which_hand: int32 = int32(0)
