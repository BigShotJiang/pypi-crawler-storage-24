"""TerrainType.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 5 int32 fields
  - 1 string_ref field
  - Total: 6 fields on disk

Record size: 6 * 4 = 24 bytes

See Also:
  - https://wowdev.wiki/DB/TerrainType
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("TerrainType")
@dataclass
class TerrainTypeRecord:
    """A record from TerrainType.dbc (3.3.5a, build 12340)."""

    terrain_id: int32 = int32(0)

    terrain_desc: string_ref = string_ref("")

    footstep_spray_run: int32 = int32(0)

    footstep_spray_walk: int32 = int32(0)

    sound_id: int32 = int32(0)

    flags: int32 = int32(0)
