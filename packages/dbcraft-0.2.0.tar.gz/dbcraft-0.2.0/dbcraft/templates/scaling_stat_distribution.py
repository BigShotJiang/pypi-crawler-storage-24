"""ScalingStatDistribution.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 22 int32 fields
  - Total: 22 fields on disk

Record size: 22 * 4 = 88 bytes

See Also:
  - https://wowdev.wiki/DB/ScalingStatDistribution
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("ScalingStatDistribution")
@dataclass
class ScalingStatDistributionRecord:
    """A record from ScalingStatDistribution.dbc (3.3.5a, build 12340)."""

    id: int32

    stat_id_0: int32 = int32(0)

    stat_id_1: int32 = int32(0)

    stat_id_2: int32 = int32(0)

    stat_id_3: int32 = int32(0)

    stat_id_4: int32 = int32(0)

    stat_id_5: int32 = int32(0)

    stat_id_6: int32 = int32(0)

    stat_id_7: int32 = int32(0)

    stat_id_8: int32 = int32(0)

    stat_id_9: int32 = int32(0)

    bonus_0: int32 = int32(0)

    bonus_1: int32 = int32(0)

    bonus_2: int32 = int32(0)

    bonus_3: int32 = int32(0)

    bonus_4: int32 = int32(0)

    bonus_5: int32 = int32(0)

    bonus_6: int32 = int32(0)

    bonus_7: int32 = int32(0)

    bonus_8: int32 = int32(0)

    bonus_9: int32 = int32(0)

    maxlevel: int32 = int32(0)
