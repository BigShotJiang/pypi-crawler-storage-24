"""DungeonEncounter.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 6 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 23 fields on disk

Record size: 23 * 4 = 92 bytes

See Also:
  - https://wowdev.wiki/DB/DungeonEncounter
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("DungeonEncounter")
@dataclass
class DungeonEncounterRecord:
    """A record from DungeonEncounter.dbc (3.3.5a, build 12340)."""

    id: int32

    map_id: int32 = int32(0)

    difficulty: int32 = int32(0)

    order_index: int32 = int32(0)

    bit: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    spell_icon_id: int32 = int32(0)
