"""SpellMissileMotion.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 2 string_ref fields
  - Total: 5 fields on disk

Record size: 5 * 4 = 20 bytes

See Also:
  - https://wowdev.wiki/DB/SpellMissileMotion
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("SpellMissileMotion")
@dataclass
class SpellMissileMotionRecord:
    """A record from SpellMissileMotion.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    script_body: string_ref = string_ref("")

    flags: int32 = int32(0)

    missile_count: int32 = int32(0)
