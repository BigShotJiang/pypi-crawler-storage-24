"""MovieFileData.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - Total: 2 fields on disk

Record size: 2 * 4 = 8 bytes

See Also:
  - https://wowdev.wiki/DB/MovieFileData
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("MovieFileData")
@dataclass
class MovieFileDataRecord:
    """A record from MovieFileData.dbc (3.3.5a, build 12340)."""

    file_data_id: int32 = int32(0)

    resolution: int32 = int32(0)
