"""TransportRotation.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 4 float32 fields
  - Total: 7 fields on disk

Record size: 7 * 4 = 28 bytes

See Also:
  - https://wowdev.wiki/DB/TransportRotation
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("TransportRotation")
@dataclass
class TransportRotationRecord:
    """A record from TransportRotation.dbc (3.3.5a, build 12340)."""

    id: int32

    game_objects_id: int32 = int32(0)

    time_index: int32 = int32(0)

    rot_0: float32 = float32(0.0)

    rot_1: float32 = float32(0.0)

    rot_2: float32 = float32(0.0)

    rot_3: float32 = float32(0.0)
