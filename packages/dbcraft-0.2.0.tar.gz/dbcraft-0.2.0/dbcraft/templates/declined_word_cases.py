"""DeclinedWordCases.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 1 string_ref field
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/DeclinedWordCases
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("DeclinedWordCases")
@dataclass
class DeclinedWordCasesRecord:
    """A record from DeclinedWordCases.dbc (3.3.5a, build 12340)."""

    id: int32

    declined_word_id: int32 = int32(0)

    case_index: int32 = int32(0)

    declined_word: string_ref = string_ref("")
