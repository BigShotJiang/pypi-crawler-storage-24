"""ItemPurchaseGroup.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 9 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 26 fields on disk

Record size: 26 * 4 = 104 bytes

See Also:
  - https://wowdev.wiki/DB/ItemPurchaseGroup
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("ItemPurchaseGroup")
@dataclass
class ItemPurchaseGroupRecord:
    """A record from ItemPurchaseGroup.dbc (3.3.5a, build 12340)."""

    id: int32

    item_id_0: int32 = int32(0)

    item_id_1: int32 = int32(0)

    item_id_2: int32 = int32(0)

    item_id_3: int32 = int32(0)

    item_id_4: int32 = int32(0)

    item_id_5: int32 = int32(0)

    item_id_6: int32 = int32(0)

    item_id_7: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)
