"""GameTables.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 1 string_ref field
  - Total: 3 fields on disk

Record size: 3 * 4 = 12 bytes

See Also:
  - https://wowdev.wiki/DB/GameTables
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("GameTables")
@dataclass
class GameTablesRecord:
    """A record from GameTables.dbc (3.3.5a, build 12340)."""

    name: string_ref = string_ref("")

    num_rows: int32 = int32(0)

    num_columns: int32 = int32(0)
