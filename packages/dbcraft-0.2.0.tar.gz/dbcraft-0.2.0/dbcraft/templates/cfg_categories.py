"""Cfg_Categories.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 21 fields on disk

Record size: 21 * 4 = 84 bytes

See Also:
  - https://wowdev.wiki/DB/Cfg_Categories
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("Cfg_Categories")
@dataclass
class CfgCategoriesRecord:
    """A record from Cfg_Categories.dbc (3.3.5a, build 12340)."""

    id: int32

    locale_mask: int32 = int32(0)

    create_charset_mask: int32 = int32(0)

    flags: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)
