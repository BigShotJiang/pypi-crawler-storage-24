"""PvpDifficulty.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 6 int32 fields
  - Total: 6 fields on disk

Record size: 6 * 4 = 24 bytes

See Also:
  - https://wowdev.wiki/DB/PvpDifficulty
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("PvpDifficulty")
@dataclass
class PvpDifficultyRecord:
    """A record from PvpDifficulty.dbc (3.3.5a, build 12340)."""

    id: int32

    map_id: int32 = int32(0)

    range_index: int32 = int32(0)

    min_level: int32 = int32(0)

    max_level: int32 = int32(0)

    difficulty: int32 = int32(0)
