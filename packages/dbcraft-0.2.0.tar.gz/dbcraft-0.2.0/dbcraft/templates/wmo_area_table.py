"""WMOAreaTable.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 28 fields on disk

Record size: 28 * 4 = 112 bytes

See Also:
  - https://wowdev.wiki/DB/WMOAreaTable
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("WMOAreaTable")
@dataclass
class WMOAreaTableRecord:
    """A record from WMOAreaTable.dbc (3.3.5a, build 12340)."""

    id: int32

    w_m_o_id: int32 = int32(0)

    name_set_id: int32 = int32(0)

    w_m_o_group_id: int32 = int32(0)

    sound_provider_pref: int32 = int32(0)

    sound_provider_pref_underwater: int32 = int32(0)

    ambience_id: int32 = int32(0)

    zone_music: int32 = int32(0)

    intro_sound: int32 = int32(0)

    flags: int32 = int32(0)

    area_table_id: int32 = int32(0)

    area_name_lang: loc_string_ref = field(default_factory=LocalizedString)
