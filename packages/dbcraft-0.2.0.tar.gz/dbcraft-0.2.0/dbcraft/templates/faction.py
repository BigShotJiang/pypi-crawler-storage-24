"""Faction.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 21 int32 fields
  - 2 float32 fields
  - 2 loc_string_ref fields (2 x 17 = 34 on disk)
  - Total: 57 fields on disk

Record size: 57 * 4 = 228 bytes

See Also:
  - https://wowdev.wiki/DB/Faction
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("Faction")
@dataclass
class FactionRecord:
    """A record from Faction.dbc (3.3.5a, build 12340)."""

    id: int32

    reputation_index: int32 = int32(0)

    reputation_race_mask_0: int32 = int32(0)

    reputation_race_mask_1: int32 = int32(0)

    reputation_race_mask_2: int32 = int32(0)

    reputation_race_mask_3: int32 = int32(0)

    reputation_class_mask_0: int32 = int32(0)

    reputation_class_mask_1: int32 = int32(0)

    reputation_class_mask_2: int32 = int32(0)

    reputation_class_mask_3: int32 = int32(0)

    reputation_base_0: int32 = int32(0)

    reputation_base_1: int32 = int32(0)

    reputation_base_2: int32 = int32(0)

    reputation_base_3: int32 = int32(0)

    reputation_flags_0: int32 = int32(0)

    reputation_flags_1: int32 = int32(0)

    reputation_flags_2: int32 = int32(0)

    reputation_flags_3: int32 = int32(0)

    parent_faction_id: int32 = int32(0)

    parent_faction_mod_0: float32 = float32(0.0)

    parent_faction_mod_1: float32 = float32(0.0)

    parent_faction_cap_0: int32 = int32(0)

    parent_faction_cap_1: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    description_lang: loc_string_ref = field(default_factory=LocalizedString)
