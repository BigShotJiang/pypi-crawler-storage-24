"""CharHairGeosets.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 6 int32 fields
  - Total: 6 fields on disk

Record size: 6 * 4 = 24 bytes

See Also:
  - https://wowdev.wiki/DB/CharHairGeosets
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("CharHairGeosets")
@dataclass
class CharHairGeosetsRecord:
    """A record from CharHairGeosets.dbc (3.3.5a, build 12340)."""

    id: int32

    race_id: int32 = int32(0)

    sex_id: int32 = int32(0)

    variation_id: int32 = int32(0)

    geoset_id: int32 = int32(0)

    showscalp: int32 = int32(0)
