"""ItemExtendedCost.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 16 int32 fields
  - Total: 16 fields on disk

Record size: 16 * 4 = 64 bytes

See Also:
  - https://wowdev.wiki/DB/ItemExtendedCost
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("ItemExtendedCost")
@dataclass
class ItemExtendedCostRecord:
    """A record from ItemExtendedCost.dbc (3.3.5a, build 12340)."""

    id: int32

    honor_points: int32 = int32(0)

    arena_points: int32 = int32(0)

    arena_bracket: int32 = int32(0)

    item_id_0: int32 = int32(0)

    item_id_1: int32 = int32(0)

    item_id_2: int32 = int32(0)

    item_id_3: int32 = int32(0)

    item_id_4: int32 = int32(0)

    item_count_0: int32 = int32(0)

    item_count_1: int32 = int32(0)

    item_count_2: int32 = int32(0)

    item_count_3: int32 = int32(0)

    item_count_4: int32 = int32(0)

    required_arena_rating: int32 = int32(0)

    item_purchase_group: int32 = int32(0)
