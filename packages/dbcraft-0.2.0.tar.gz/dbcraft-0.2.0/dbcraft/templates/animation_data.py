"""AnimationData.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 7 int32 fields
  - 1 string_ref field
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/AnimationData
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("AnimationData")
@dataclass
class AnimationDataRecord:
    """A record from AnimationData.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    weaponflags: int32 = int32(0)

    bodyflags: int32 = int32(0)

    flags: int32 = int32(0)

    fallback: int32 = int32(0)

    behavior_id: int32 = int32(0)

    behavior_tier: int32 = int32(0)
