"""WorldChunkSounds.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 9 int32 fields
  - Total: 9 fields on disk

Record size: 9 * 4 = 36 bytes

See Also:
  - https://wowdev.wiki/DB/WorldChunkSounds
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("WorldChunkSounds")
@dataclass
class WorldChunkSoundsRecord:
    """A record from WorldChunkSounds.dbc (3.3.5a, build 12340)."""

    id: int32

    chunk_x: int32 = int32(0)

    chunk_y: int32 = int32(0)

    subchunk_x: int32 = int32(0)

    subchunk_y: int32 = int32(0)

    zone_intro_music_id: int32 = int32(0)

    zone_music_id: int32 = int32(0)

    sound_ambience_id: int32 = int32(0)

    sound_provider_preferences_id: int32 = int32(0)
