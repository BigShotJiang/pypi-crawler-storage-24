"""QuestXP.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - Total: 11 fields on disk

Record size: 11 * 4 = 44 bytes

See Also:
  - https://wowdev.wiki/DB/QuestXP
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("QuestXP")
@dataclass
class QuestXPRecord:
    """A record from QuestXP.dbc (3.3.5a, build 12340)."""

    id: int32

    difficulty_0: int32 = int32(0)

    difficulty_1: int32 = int32(0)

    difficulty_2: int32 = int32(0)

    difficulty_3: int32 = int32(0)

    difficulty_4: int32 = int32(0)

    difficulty_5: int32 = int32(0)

    difficulty_6: int32 = int32(0)

    difficulty_7: int32 = int32(0)

    difficulty_8: int32 = int32(0)

    difficulty_9: int32 = int32(0)
