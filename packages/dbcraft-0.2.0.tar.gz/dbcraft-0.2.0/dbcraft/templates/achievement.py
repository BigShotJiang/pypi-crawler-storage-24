"""Achievement.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - 3 loc_string_ref fields (3 x 17 = 51 on disk)
  - Total: 62 fields on disk

Record size: 62 * 4 = 248 bytes

See Also:
  - https://wowdev.wiki/DB/Achievement
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("Achievement")
@dataclass
class AchievementRecord:
    """A record from Achievement.dbc (3.3.5a, build 12340)."""

    id: int32

    faction: int32 = int32(0)

    instance_id: int32 = int32(0)

    supercedes: int32 = int32(0)

    title_lang: loc_string_ref = field(default_factory=LocalizedString)

    description_lang: loc_string_ref = field(default_factory=LocalizedString)

    category: int32 = int32(0)

    points: int32 = int32(0)

    ui_order: int32 = int32(0)

    flags: int32 = int32(0)

    icon_id: int32 = int32(0)

    reward_lang: loc_string_ref = field(default_factory=LocalizedString)

    minimum_criteria: int32 = int32(0)

    shares_criteria: int32 = int32(0)
