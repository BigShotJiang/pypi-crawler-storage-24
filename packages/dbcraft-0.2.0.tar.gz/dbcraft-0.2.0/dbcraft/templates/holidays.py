"""Holidays.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 54 int32 fields
  - 1 string_ref field
  - Total: 55 fields on disk

Record size: 55 * 4 = 220 bytes

See Also:
  - https://wowdev.wiki/DB/Holidays
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("Holidays")
@dataclass
class HolidaysRecord:
    """A record from Holidays.dbc (3.3.5a, build 12340)."""

    id: int32

    duration_0: int32 = int32(0)

    duration_1: int32 = int32(0)

    duration_2: int32 = int32(0)

    duration_3: int32 = int32(0)

    duration_4: int32 = int32(0)

    duration_5: int32 = int32(0)

    duration_6: int32 = int32(0)

    duration_7: int32 = int32(0)

    duration_8: int32 = int32(0)

    duration_9: int32 = int32(0)

    date_0: int32 = int32(0)

    date_1: int32 = int32(0)

    date_2: int32 = int32(0)

    date_3: int32 = int32(0)

    date_4: int32 = int32(0)

    date_5: int32 = int32(0)

    date_6: int32 = int32(0)

    date_7: int32 = int32(0)

    date_8: int32 = int32(0)

    date_9: int32 = int32(0)

    date_10: int32 = int32(0)

    date_11: int32 = int32(0)

    date_12: int32 = int32(0)

    date_13: int32 = int32(0)

    date_14: int32 = int32(0)

    date_15: int32 = int32(0)

    date_16: int32 = int32(0)

    date_17: int32 = int32(0)

    date_18: int32 = int32(0)

    date_19: int32 = int32(0)

    date_20: int32 = int32(0)

    date_21: int32 = int32(0)

    date_22: int32 = int32(0)

    date_23: int32 = int32(0)

    date_24: int32 = int32(0)

    date_25: int32 = int32(0)

    region: int32 = int32(0)

    looping: int32 = int32(0)

    calendar_flags_0: int32 = int32(0)

    calendar_flags_1: int32 = int32(0)

    calendar_flags_2: int32 = int32(0)

    calendar_flags_3: int32 = int32(0)

    calendar_flags_4: int32 = int32(0)

    calendar_flags_5: int32 = int32(0)

    calendar_flags_6: int32 = int32(0)

    calendar_flags_7: int32 = int32(0)

    calendar_flags_8: int32 = int32(0)

    calendar_flags_9: int32 = int32(0)

    holiday_name_id: int32 = int32(0)

    holiday_description_id: int32 = int32(0)

    texture_file_name: string_ref = string_ref("")

    priority: int32 = int32(0)

    calendar_filter_type: int32 = int32(0)

    flags: int32 = int32(0)
