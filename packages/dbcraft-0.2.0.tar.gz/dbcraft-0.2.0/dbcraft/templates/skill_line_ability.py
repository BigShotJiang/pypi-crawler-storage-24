"""SkillLineAbility.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 14 int32 fields
  - Total: 14 fields on disk

Record size: 14 * 4 = 56 bytes

See Also:
  - https://wowdev.wiki/DB/SkillLineAbility
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("SkillLineAbility")
@dataclass
class SkillLineAbilityRecord:
    """A record from SkillLineAbility.dbc (3.3.5a, build 12340)."""

    id: int32

    skill_line: int32 = int32(0)

    spell: int32 = int32(0)

    race_mask: int32 = int32(0)

    class_mask: int32 = int32(0)

    exclude_race: int32 = int32(0)

    exclude_class: int32 = int32(0)

    min_skill_line_rank: int32 = int32(0)

    superceded_by_spell: int32 = int32(0)

    acquire_method: int32 = int32(0)

    trivial_skill_line_rank_high: int32 = int32(0)

    trivial_skill_line_rank_low: int32 = int32(0)

    character_points_0: int32 = int32(0)

    character_points_1: int32 = int32(0)
