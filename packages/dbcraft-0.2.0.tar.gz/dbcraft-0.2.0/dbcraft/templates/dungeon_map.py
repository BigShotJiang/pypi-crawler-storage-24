"""DungeonMap.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 4 float32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/DungeonMap
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("DungeonMap")
@dataclass
class DungeonMapRecord:
    """A record from DungeonMap.dbc (3.3.5a, build 12340)."""

    id: int32

    map_id: int32 = int32(0)

    floor_index: int32 = int32(0)

    min_x: float32 = float32(0.0)

    max_x: float32 = float32(0.0)

    min_y: float32 = float32(0.0)

    max_y: float32 = float32(0.0)

    parent_world_map_id: int32 = int32(0)
