"""LiquidMaterial.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - Total: 3 fields on disk

Record size: 3 * 4 = 12 bytes

See Also:
  - https://wowdev.wiki/DB/LiquidMaterial
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("LiquidMaterial")
@dataclass
class LiquidMaterialRecord:
    """A record from LiquidMaterial.dbc (3.3.5a, build 12340)."""

    id: int32

    l_v_f: int32 = int32(0)

    flags: int32 = int32(0)
