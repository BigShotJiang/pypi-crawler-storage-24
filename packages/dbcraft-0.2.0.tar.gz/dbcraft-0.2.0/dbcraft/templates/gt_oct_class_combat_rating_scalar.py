"""gtOCTClassCombatRatingScalar.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 1 float32 field
  - Total: 2 fields on disk

Record size: 2 * 4 = 8 bytes

See Also:
  - https://wowdev.wiki/DB/gtOCTClassCombatRatingScalar
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("gtOCTClassCombatRatingScalar")
@dataclass
class GtOCTClassCombatRatingScalarRecord:
    """A record from gtOCTClassCombatRatingScalar.dbc (3.3.5a, build 12340)."""

    id: int32

    data: float32 = float32(0.0)
