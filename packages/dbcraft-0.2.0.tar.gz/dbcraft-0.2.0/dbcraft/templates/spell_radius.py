"""SpellRadius.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 3 float32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/SpellRadius
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("SpellRadius")
@dataclass
class SpellRadiusRecord:
    """A record from SpellRadius.dbc (3.3.5a, build 12340)."""

    id: int32

    radius: float32 = float32(0.0)

    radius_per_level: float32 = float32(0.0)

    radius_max: float32 = float32(0.0)
