"""Talent.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 23 int32 fields
  - Total: 23 fields on disk

Record size: 23 * 4 = 92 bytes

See Also:
  - https://wowdev.wiki/DB/Talent
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("Talent")
@dataclass
class TalentRecord:
    """A record from Talent.dbc (3.3.5a, build 12340)."""

    id: int32

    tab_id: int32 = int32(0)

    tier_id: int32 = int32(0)

    column_index: int32 = int32(0)

    spell_rank_0: int32 = int32(0)

    spell_rank_1: int32 = int32(0)

    spell_rank_2: int32 = int32(0)

    spell_rank_3: int32 = int32(0)

    spell_rank_4: int32 = int32(0)

    spell_rank_5: int32 = int32(0)

    spell_rank_6: int32 = int32(0)

    spell_rank_7: int32 = int32(0)

    spell_rank_8: int32 = int32(0)

    prereq_talent_0: int32 = int32(0)

    prereq_talent_1: int32 = int32(0)

    prereq_talent_2: int32 = int32(0)

    prereq_rank_0: int32 = int32(0)

    prereq_rank_1: int32 = int32(0)

    prereq_rank_2: int32 = int32(0)

    flags: int32 = int32(0)

    required_spell_id: int32 = int32(0)

    category_mask_0: int32 = int32(0)

    category_mask_1: int32 = int32(0)
