"""Material.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 5 int32 fields
  - Total: 5 fields on disk

Record size: 5 * 4 = 20 bytes

See Also:
  - https://wowdev.wiki/DB/Material
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("Material")
@dataclass
class MaterialRecord:
    """A record from Material.dbc (3.3.5a, build 12340)."""

    id: int32

    flags: int32 = int32(0)

    foley_sound_id: int32 = int32(0)

    sheathe_sound_id: int32 = int32(0)

    unsheathe_sound_id: int32 = int32(0)
