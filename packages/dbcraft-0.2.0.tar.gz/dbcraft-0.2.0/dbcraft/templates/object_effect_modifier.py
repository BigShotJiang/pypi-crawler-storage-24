"""ObjectEffectModifier.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 4 float32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/ObjectEffectModifier
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("ObjectEffectModifier")
@dataclass
class ObjectEffectModifierRecord:
    """A record from ObjectEffectModifier.dbc (3.3.5a, build 12340)."""

    id: int32

    input_type: int32 = int32(0)

    map_type: int32 = int32(0)

    output_type: int32 = int32(0)

    param_0: float32 = float32(0.0)

    param_1: float32 = float32(0.0)

    param_2: float32 = float32(0.0)

    param_3: float32 = float32(0.0)
