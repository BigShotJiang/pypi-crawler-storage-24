"""WorldMapOverlay.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 16 int32 fields
  - 1 string_ref field
  - Total: 17 fields on disk

Record size: 17 * 4 = 68 bytes

See Also:
  - https://wowdev.wiki/DB/WorldMapOverlay
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("WorldMapOverlay")
@dataclass
class WorldMapOverlayRecord:
    """A record from WorldMapOverlay.dbc (3.3.5a, build 12340)."""

    id: int32

    map_area_id: int32 = int32(0)

    area_id_0: int32 = int32(0)

    area_id_1: int32 = int32(0)

    area_id_2: int32 = int32(0)

    area_id_3: int32 = int32(0)

    map_point_x: int32 = int32(0)

    map_point_y: int32 = int32(0)

    texture_name: string_ref = string_ref("")

    texture_width: int32 = int32(0)

    texture_height: int32 = int32(0)

    offset_x: int32 = int32(0)

    offset_y: int32 = int32(0)

    hit_rect_top: int32 = int32(0)

    hit_rect_left: int32 = int32(0)

    hit_rect_bottom: int32 = int32(0)

    hit_rect_right: int32 = int32(0)
