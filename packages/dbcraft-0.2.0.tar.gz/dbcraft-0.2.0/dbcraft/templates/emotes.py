"""Emotes.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 6 int32 fields
  - 1 string_ref field
  - Total: 7 fields on disk

Record size: 7 * 4 = 28 bytes

See Also:
  - https://wowdev.wiki/DB/Emotes
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("Emotes")
@dataclass
class EmotesRecord:
    """A record from Emotes.dbc (3.3.5a, build 12340)."""

    id: int32

    emote_slash_command: string_ref = string_ref("")

    anim_id: int32 = int32(0)

    emote_flags: int32 = int32(0)

    emote_spec_proc: int32 = int32(0)

    emote_spec_proc_param: int32 = int32(0)

    event_sound_id: int32 = int32(0)
