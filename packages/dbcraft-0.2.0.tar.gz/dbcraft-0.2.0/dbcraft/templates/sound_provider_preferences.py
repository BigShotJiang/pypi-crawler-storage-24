"""SoundProviderPreferences.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - 15 float32 fields
  - 1 string_ref field
  - Total: 24 fields on disk

Record size: 24 * 4 = 96 bytes

See Also:
  - https://wowdev.wiki/DB/SoundProviderPreferences
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("SoundProviderPreferences")
@dataclass
class SoundProviderPreferencesRecord:
    """A record from SoundProviderPreferences.dbc (3.3.5a, build 12340)."""

    id: int32

    description: string_ref = string_ref("")

    flags: int32 = int32(0)

    e_a_x_environment_selection: int32 = int32(0)

    e_a_x_decay_time: float32 = float32(0.0)

    e_a_x2_environment_size: float32 = float32(0.0)

    e_a_x2_environment_diffusion: float32 = float32(0.0)

    e_a_x2_room: int32 = int32(0)

    e_a_x2_room_h_f: int32 = int32(0)

    e_a_x2_decay_h_f_ratio: float32 = float32(0.0)

    e_a_x2_reflections: int32 = int32(0)

    e_a_x2_reflections_delay: float32 = float32(0.0)

    e_a_x2_reverb: int32 = int32(0)

    e_a_x2_reverb_delay: float32 = float32(0.0)

    e_a_x2_room_rolloff: float32 = float32(0.0)

    e_a_x2_air_absorption: float32 = float32(0.0)

    e_a_x3_room_l_f: int32 = int32(0)

    e_a_x3_decay_l_f_ratio: float32 = float32(0.0)

    e_a_x3_echo_time: float32 = float32(0.0)

    e_a_x3_echo_depth: float32 = float32(0.0)

    e_a_x3_modulation_time: float32 = float32(0.0)

    e_a_x3_modulation_depth: float32 = float32(0.0)

    e_a_x3_h_f_reference: float32 = float32(0.0)

    e_a_x3_l_f_reference: float32 = float32(0.0)
