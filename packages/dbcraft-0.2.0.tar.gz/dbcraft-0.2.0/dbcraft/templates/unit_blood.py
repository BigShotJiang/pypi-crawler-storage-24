"""UnitBlood.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 5 int32 fields
  - 5 string_ref fields
  - Total: 10 fields on disk

Record size: 10 * 4 = 40 bytes

See Also:
  - https://wowdev.wiki/DB/UnitBlood
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("UnitBlood")
@dataclass
class UnitBloodRecord:
    """A record from UnitBlood.dbc (3.3.5a, build 12340)."""

    id: int32

    combat_blood_spurt_front_0: int32 = int32(0)

    combat_blood_spurt_front_1: int32 = int32(0)

    combat_blood_spurt_back_0: int32 = int32(0)

    combat_blood_spurt_back_1: int32 = int32(0)

    ground_blood_0: string_ref = string_ref("")

    ground_blood_1: string_ref = string_ref("")

    ground_blood_2: string_ref = string_ref("")

    ground_blood_3: string_ref = string_ref("")

    ground_blood_4: string_ref = string_ref("")
