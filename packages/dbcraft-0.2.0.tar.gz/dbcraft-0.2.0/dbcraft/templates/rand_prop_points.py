"""RandPropPoints.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 16 int32 fields
  - Total: 16 fields on disk

Record size: 16 * 4 = 64 bytes

See Also:
  - https://wowdev.wiki/DB/RandPropPoints
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("RandPropPoints")
@dataclass
class RandPropPointsRecord:
    """A record from RandPropPoints.dbc (3.3.5a, build 12340)."""

    id: int32

    epic_0: int32 = int32(0)

    epic_1: int32 = int32(0)

    epic_2: int32 = int32(0)

    epic_3: int32 = int32(0)

    epic_4: int32 = int32(0)

    superior_0: int32 = int32(0)

    superior_1: int32 = int32(0)

    superior_2: int32 = int32(0)

    superior_3: int32 = int32(0)

    superior_4: int32 = int32(0)

    good_0: int32 = int32(0)

    good_1: int32 = int32(0)

    good_2: int32 = int32(0)

    good_3: int32 = int32(0)

    good_4: int32 = int32(0)
