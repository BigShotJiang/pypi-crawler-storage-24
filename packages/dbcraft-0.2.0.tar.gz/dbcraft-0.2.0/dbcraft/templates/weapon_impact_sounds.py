"""WeaponImpactSounds.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 23 int32 fields
  - Total: 23 fields on disk

Record size: 23 * 4 = 92 bytes

See Also:
  - https://wowdev.wiki/DB/WeaponImpactSounds
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("WeaponImpactSounds")
@dataclass
class WeaponImpactSoundsRecord:
    """A record from WeaponImpactSounds.dbc (3.3.5a, build 12340)."""

    id: int32

    weapon_sub_class_id: int32 = int32(0)

    parry_sound_type: int32 = int32(0)

    impact_sound_id_0: int32 = int32(0)

    impact_sound_id_1: int32 = int32(0)

    impact_sound_id_2: int32 = int32(0)

    impact_sound_id_3: int32 = int32(0)

    impact_sound_id_4: int32 = int32(0)

    impact_sound_id_5: int32 = int32(0)

    impact_sound_id_6: int32 = int32(0)

    impact_sound_id_7: int32 = int32(0)

    impact_sound_id_8: int32 = int32(0)

    impact_sound_id_9: int32 = int32(0)

    crit_impact_sound_id_0: int32 = int32(0)

    crit_impact_sound_id_1: int32 = int32(0)

    crit_impact_sound_id_2: int32 = int32(0)

    crit_impact_sound_id_3: int32 = int32(0)

    crit_impact_sound_id_4: int32 = int32(0)

    crit_impact_sound_id_5: int32 = int32(0)

    crit_impact_sound_id_6: int32 = int32(0)

    crit_impact_sound_id_7: int32 = int32(0)

    crit_impact_sound_id_8: int32 = int32(0)

    crit_impact_sound_id_9: int32 = int32(0)
