"""SpellMissile.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 13 float32 fields
  - Total: 15 fields on disk

Record size: 15 * 4 = 60 bytes

See Also:
  - https://wowdev.wiki/DB/SpellMissile
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("SpellMissile")
@dataclass
class SpellMissileRecord:
    """A record from SpellMissile.dbc (3.3.5a, build 12340)."""

    id: int32

    flags: int32 = int32(0)

    default_pitch_min: float32 = float32(0.0)

    default_pitch_max: float32 = float32(0.0)

    default_speed_min: float32 = float32(0.0)

    default_speed_max: float32 = float32(0.0)

    randomize_facing_min: float32 = float32(0.0)

    randomize_facing_max: float32 = float32(0.0)

    randomize_pitch_min: float32 = float32(0.0)

    randomize_pitch_max: float32 = float32(0.0)

    randomize_speed_min: float32 = float32(0.0)

    randomize_speed_max: float32 = float32(0.0)

    gravity: float32 = float32(0.0)

    max_duration: float32 = float32(0.0)

    collision_radius: float32 = float32(0.0)
