"""ItemSubClassMask.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 19 fields on disk

Record size: 19 * 4 = 76 bytes

See Also:
  - https://wowdev.wiki/DB/ItemSubClassMask
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("ItemSubClassMask")
@dataclass
class ItemSubClassMaskRecord:
    """A record from ItemSubClassMask.dbc (3.3.5a, build 12340)."""

    class_id: int32 = int32(0)

    mask: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)
