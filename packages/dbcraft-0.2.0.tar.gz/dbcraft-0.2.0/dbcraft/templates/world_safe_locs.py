"""WorldSafeLocs.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 3 float32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 22 fields on disk

Record size: 22 * 4 = 88 bytes

See Also:
  - https://wowdev.wiki/DB/WorldSafeLocs
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("WorldSafeLocs")
@dataclass
class WorldSafeLocsRecord:
    """A record from WorldSafeLocs.dbc (3.3.5a, build 12340)."""

    id: int32

    continent: int32 = int32(0)

    loc_0: float32 = float32(0.0)

    loc_1: float32 = float32(0.0)

    loc_2: float32 = float32(0.0)

    area_name_lang: loc_string_ref = field(default_factory=LocalizedString)
