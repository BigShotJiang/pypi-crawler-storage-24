"""CurrencyTypes.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/CurrencyTypes
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("CurrencyTypes")
@dataclass
class CurrencyTypesRecord:
    """A record from CurrencyTypes.dbc (3.3.5a, build 12340)."""

    id: int32

    item_id: int32 = int32(0)

    category_id: int32 = int32(0)

    bit_index: int32 = int32(0)
