"""TaxiPath.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/TaxiPath
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("TaxiPath")
@dataclass
class TaxiPathRecord:
    """A record from TaxiPath.dbc (3.3.5a, build 12340)."""

    id: int32

    from_taxi_node: int32 = int32(0)

    to_taxi_node: int32 = int32(0)

    cost: int32 = int32(0)
