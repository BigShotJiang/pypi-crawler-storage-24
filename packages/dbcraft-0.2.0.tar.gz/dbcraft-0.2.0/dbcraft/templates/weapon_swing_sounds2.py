"""WeaponSwingSounds2.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/WeaponSwingSounds2
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("WeaponSwingSounds2")
@dataclass
class WeaponSwingSounds2Record:
    """A record from WeaponSwingSounds2.dbc (3.3.5a, build 12340)."""

    id: int32

    swing_type: int32 = int32(0)

    crit: int32 = int32(0)

    sound_id: int32 = int32(0)
