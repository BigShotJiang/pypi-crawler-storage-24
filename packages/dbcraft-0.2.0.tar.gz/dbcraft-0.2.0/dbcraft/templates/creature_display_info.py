"""CreatureDisplayInfo.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 11 int32 fields
  - 1 float32 field
  - 4 string_ref fields
  - Total: 16 fields on disk

Record size: 16 * 4 = 64 bytes

See Also:
  - https://wowdev.wiki/DB/CreatureDisplayInfo
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("CreatureDisplayInfo")
@dataclass
class CreatureDisplayInfoRecord:
    """A record from CreatureDisplayInfo.dbc (3.3.5a, build 12340)."""

    id: int32

    model_id: int32 = int32(0)

    sound_id: int32 = int32(0)

    extended_display_info_id: int32 = int32(0)

    creature_model_scale: float32 = float32(0.0)

    creature_model_alpha: int32 = int32(0)

    texture_variation_0: string_ref = string_ref("")

    texture_variation_1: string_ref = string_ref("")

    texture_variation_2: string_ref = string_ref("")

    portrait_texture_name: string_ref = string_ref("")

    size_class: int32 = int32(0)

    blood_id: int32 = int32(0)

    n_p_c_sound_id: int32 = int32(0)

    particle_color_id: int32 = int32(0)

    creature_geoset_data: int32 = int32(0)

    object_effect_package_id: int32 = int32(0)
