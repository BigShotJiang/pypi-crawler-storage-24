"""HelmetGeosetVisData.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/HelmetGeosetVisData
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("HelmetGeosetVisData")
@dataclass
class HelmetGeosetVisDataRecord:
    """A record from HelmetGeosetVisData.dbc (3.3.5a, build 12340)."""

    id: int32

    hide_geoset_0: int32 = int32(0)

    hide_geoset_1: int32 = int32(0)

    hide_geoset_2: int32 = int32(0)

    hide_geoset_3: int32 = int32(0)

    hide_geoset_4: int32 = int32(0)

    hide_geoset_5: int32 = int32(0)

    hide_geoset_6: int32 = int32(0)
