"""MailTemplate.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 2 loc_string_ref fields (2 x 17 = 34 on disk)
  - Total: 35 fields on disk

Record size: 35 * 4 = 140 bytes

See Also:
  - https://wowdev.wiki/DB/MailTemplate
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("MailTemplate")
@dataclass
class MailTemplateRecord:
    """A record from MailTemplate.dbc (3.3.5a, build 12340)."""

    id: int32

    subject_lang: loc_string_ref = field(default_factory=LocalizedString)

    body_lang: loc_string_ref = field(default_factory=LocalizedString)
