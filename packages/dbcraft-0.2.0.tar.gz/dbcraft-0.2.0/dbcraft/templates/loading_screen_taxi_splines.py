"""LoadingScreenTaxiSplines.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 16 float32 fields
  - Total: 19 fields on disk

Record size: 19 * 4 = 76 bytes

See Also:
  - https://wowdev.wiki/DB/LoadingScreenTaxiSplines
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("LoadingScreenTaxiSplines")
@dataclass
class LoadingScreenTaxiSplinesRecord:
    """A record from LoadingScreenTaxiSplines.dbc (3.3.5a, build 12340)."""

    id: int32

    path_id: int32 = int32(0)

    locx_0: float32 = float32(0.0)

    locx_1: float32 = float32(0.0)

    locx_2: float32 = float32(0.0)

    locx_3: float32 = float32(0.0)

    locx_4: float32 = float32(0.0)

    locx_5: float32 = float32(0.0)

    locx_6: float32 = float32(0.0)

    locx_7: float32 = float32(0.0)

    locy_0: float32 = float32(0.0)

    locy_1: float32 = float32(0.0)

    locy_2: float32 = float32(0.0)

    locy_3: float32 = float32(0.0)

    locy_4: float32 = float32(0.0)

    locy_5: float32 = float32(0.0)

    locy_6: float32 = float32(0.0)

    locy_7: float32 = float32(0.0)

    leg_index: int32 = int32(0)
