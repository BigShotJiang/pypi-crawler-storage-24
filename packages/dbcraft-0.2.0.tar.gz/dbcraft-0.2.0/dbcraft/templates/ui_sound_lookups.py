"""UISoundLookups.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 2 int32 fields
  - 1 string_ref field
  - Total: 3 fields on disk

Record size: 3 * 4 = 12 bytes

See Also:
  - https://wowdev.wiki/DB/UISoundLookups
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("UISoundLookups")
@dataclass
class UISoundLookupsRecord:
    """A record from UISoundLookups.dbc (3.3.5a, build 12340)."""

    id: int32

    sound_id: int32 = int32(0)

    sound_name: string_ref = string_ref("")
