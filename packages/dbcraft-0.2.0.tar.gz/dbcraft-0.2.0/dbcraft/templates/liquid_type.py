"""LiquidType.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 15 int32 fields
  - 23 float32 fields
  - 7 string_ref fields
  - Total: 45 fields on disk

Record size: 45 * 4 = 180 bytes

See Also:
  - https://wowdev.wiki/DB/LiquidType
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("LiquidType")
@dataclass
class LiquidTypeRecord:
    """A record from LiquidType.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    flags: int32 = int32(0)

    sound_bank: int32 = int32(0)

    sound_id: int32 = int32(0)

    spell_id: int32 = int32(0)

    max_darken_depth: float32 = float32(0.0)

    fog_darken_intensity: float32 = float32(0.0)

    amb_darken_intensity: float32 = float32(0.0)

    dir_darken_intensity: float32 = float32(0.0)

    light_id: int32 = int32(0)

    particle_scale: float32 = float32(0.0)

    particle_movement: int32 = int32(0)

    particle_tex_slots: int32 = int32(0)

    material_id: int32 = int32(0)

    texture_0: string_ref = string_ref("")

    texture_1: string_ref = string_ref("")

    texture_2: string_ref = string_ref("")

    texture_3: string_ref = string_ref("")

    texture_4: string_ref = string_ref("")

    texture_5: string_ref = string_ref("")

    color_0: int32 = int32(0)

    color_1: int32 = int32(0)

    float_0: float32 = float32(0.0)

    float_1: float32 = float32(0.0)

    float_2: float32 = float32(0.0)

    float_3: float32 = float32(0.0)

    float_4: float32 = float32(0.0)

    float_5: float32 = float32(0.0)

    float_6: float32 = float32(0.0)

    float_7: float32 = float32(0.0)

    float_8: float32 = float32(0.0)

    float_9: float32 = float32(0.0)

    float_10: float32 = float32(0.0)

    float_11: float32 = float32(0.0)

    float_12: float32 = float32(0.0)

    float_13: float32 = float32(0.0)

    float_14: float32 = float32(0.0)

    float_15: float32 = float32(0.0)

    float_16: float32 = float32(0.0)

    float_17: float32 = float32(0.0)

    int_0: int32 = int32(0)

    int_1: int32 = int32(0)

    int_2: int32 = int32(0)

    int_3: int32 = int32(0)
