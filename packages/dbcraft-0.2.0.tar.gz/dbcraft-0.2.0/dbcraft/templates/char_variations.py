"""CharVariations.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 6 int32 fields
  - Total: 6 fields on disk

Record size: 6 * 4 = 24 bytes

See Also:
  - https://wowdev.wiki/DB/CharVariations
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("CharVariations")
@dataclass
class CharVariationsRecord:
    """A record from CharVariations.dbc (3.3.5a, build 12340)."""

    race_id: int32 = int32(0)

    sex_id: int32 = int32(0)

    texture_hold_layer_0: int32 = int32(0)

    texture_hold_layer_1: int32 = int32(0)

    texture_hold_layer_2: int32 = int32(0)

    texture_hold_layer_3: int32 = int32(0)
