"""SpellRuneCost.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 5 int32 fields
  - Total: 5 fields on disk

Record size: 5 * 4 = 20 bytes

See Also:
  - https://wowdev.wiki/DB/SpellRuneCost
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("SpellRuneCost")
@dataclass
class SpellRuneCostRecord:
    """A record from SpellRuneCost.dbc (3.3.5a, build 12340)."""

    id: int32

    blood: int32 = int32(0)

    unholy: int32 = int32(0)

    frost: int32 = int32(0)

    runic_power: int32 = int32(0)
