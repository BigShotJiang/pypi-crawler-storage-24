"""CreatureSpellData.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 9 int32 fields
  - Total: 9 fields on disk

Record size: 9 * 4 = 36 bytes

See Also:
  - https://wowdev.wiki/DB/CreatureSpellData
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("CreatureSpellData")
@dataclass
class CreatureSpellDataRecord:
    """A record from CreatureSpellData.dbc (3.3.5a, build 12340)."""

    id: int32

    spells_0: int32 = int32(0)

    spells_1: int32 = int32(0)

    spells_2: int32 = int32(0)

    spells_3: int32 = int32(0)

    availability_0: int32 = int32(0)

    availability_1: int32 = int32(0)

    availability_2: int32 = int32(0)

    availability_3: int32 = int32(0)
