"""CinematicSequences.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 10 int32 fields
  - Total: 10 fields on disk

Record size: 10 * 4 = 40 bytes

See Also:
  - https://wowdev.wiki/DB/CinematicSequences
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("CinematicSequences")
@dataclass
class CinematicSequencesRecord:
    """A record from CinematicSequences.dbc (3.3.5a, build 12340)."""

    id: int32

    sound_id: int32 = int32(0)

    camera_0: int32 = int32(0)

    camera_1: int32 = int32(0)

    camera_2: int32 = int32(0)

    camera_3: int32 = int32(0)

    camera_4: int32 = int32(0)

    camera_5: int32 = int32(0)

    camera_6: int32 = int32(0)

    camera_7: int32 = int32(0)
