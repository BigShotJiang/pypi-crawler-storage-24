"""SoundEntriesAdvanced.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 13 int32 fields
  - 10 float32 fields
  - 1 string_ref field
  - Total: 24 fields on disk

Record size: 24 * 4 = 96 bytes

See Also:
  - https://wowdev.wiki/DB/SoundEntriesAdvanced
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("SoundEntriesAdvanced")
@dataclass
class SoundEntriesAdvancedRecord:
    """A record from SoundEntriesAdvanced.dbc (3.3.5a, build 12340)."""

    id: int32

    sound_entry_id: int32 = int32(0)

    inner_radius2_d: float32 = float32(0.0)

    time_a: int32 = int32(0)

    time_b: int32 = int32(0)

    time_c: int32 = int32(0)

    time_d: int32 = int32(0)

    random_offset_range: int32 = int32(0)

    usage: int32 = int32(0)

    time_interval_min: int32 = int32(0)

    time_interval_max: int32 = int32(0)

    volume_slider_category: int32 = int32(0)

    duck_to_s_f_x: float32 = float32(0.0)

    duck_to_music: float32 = float32(0.0)

    duck_to_ambience: float32 = float32(0.0)

    inner_radius_of_influence: float32 = float32(0.0)

    outer_radius_of_influence: float32 = float32(0.0)

    time_to_duck: int32 = int32(0)

    time_to_unduck: int32 = int32(0)

    inside_angle: float32 = float32(0.0)

    outside_angle: float32 = float32(0.0)

    outside_volume: float32 = float32(0.0)

    outer_radius2_d: float32 = float32(0.0)

    name: string_ref = string_ref("")
