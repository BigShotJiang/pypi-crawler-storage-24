"""dbcraft templates - DBC record definitions for WoW 3.3.5a."""

# Import all templates so they auto-register on package import.
from dbcraft.templates.achievement import AchievementRecord
from dbcraft.templates.achievement_category import AchievementCategoryRecord
from dbcraft.templates.achievement_criteria import AchievementCriteriaRecord
from dbcraft.templates.animation_data import AnimationDataRecord
from dbcraft.templates.area_group import AreaGroupRecord
from dbcraft.templates.area_poi import AreaPOIRecord
from dbcraft.templates.area_table import AreaTableRecord
from dbcraft.templates.area_trigger import AreaTriggerRecord
from dbcraft.templates.attack_anim_kits import AttackAnimKitsRecord
from dbcraft.templates.attack_anim_types import AttackAnimTypesRecord
from dbcraft.templates.auction_house import AuctionHouseRecord
from dbcraft.templates.bank_bag_slot_prices import BankBagSlotPricesRecord
from dbcraft.templates.banned_add_ons import BannedAddOnsRecord
from dbcraft.templates.barber_shop_style import BarberShopStyleRecord
from dbcraft.templates.battlemaster_list import BattlemasterListRecord
from dbcraft.templates.camera_shakes import CameraShakesRecord
from dbcraft.templates.cfg_categories import CfgCategoriesRecord
from dbcraft.templates.cfg_configs import CfgConfigsRecord
from dbcraft.templates.char_base_info import CharBaseInfoRecord
from dbcraft.templates.char_hair_geosets import CharHairGeosetsRecord
from dbcraft.templates.char_hair_textures import CharHairTexturesRecord
from dbcraft.templates.char_sections import CharSectionsRecord
from dbcraft.templates.char_start_outfit import CharStartOutfitRecord
from dbcraft.templates.char_titles import CharTitlesRecord
from dbcraft.templates.char_variations import CharVariationsRecord
from dbcraft.templates.character_facial_hair_styles import CharacterFacialHairStylesRecord
from dbcraft.templates.chat_channels import ChatChannelsRecord
from dbcraft.templates.chat_profanity import ChatProfanityRecord
from dbcraft.templates.chr_classes import ChrClassesRecord
from dbcraft.templates.chr_races import ChrRacesRecord
from dbcraft.templates.cinematic_camera import CinematicCameraRecord
from dbcraft.templates.cinematic_sequences import CinematicSequencesRecord
from dbcraft.templates.creature_display_info import CreatureDisplayInfoRecord
from dbcraft.templates.creature_display_info_extra import CreatureDisplayInfoExtraRecord
from dbcraft.templates.creature_family import CreatureFamilyRecord
from dbcraft.templates.creature_model_data import CreatureModelDataRecord
from dbcraft.templates.creature_movement_info import CreatureMovementInfoRecord
from dbcraft.templates.creature_sound_data import CreatureSoundDataRecord
from dbcraft.templates.creature_spell_data import CreatureSpellDataRecord
from dbcraft.templates.creature_type import CreatureTypeRecord
from dbcraft.templates.currency_category import CurrencyCategoryRecord
from dbcraft.templates.currency_types import CurrencyTypesRecord
from dbcraft.templates.dance_moves import DanceMovesRecord
from dbcraft.templates.death_thud_lookups import DeathThudLookupsRecord
from dbcraft.templates.declined_word import DeclinedWordRecord
from dbcraft.templates.declined_word_cases import DeclinedWordCasesRecord
from dbcraft.templates.destructible_model_data import DestructibleModelDataRecord
from dbcraft.templates.dungeon_encounter import DungeonEncounterRecord
from dbcraft.templates.dungeon_map import DungeonMapRecord
from dbcraft.templates.dungeon_map_chunk import DungeonMapChunkRecord
from dbcraft.templates.durability_costs import DurabilityCostsRecord
from dbcraft.templates.durability_quality import DurabilityQualityRecord
from dbcraft.templates.emotes import EmotesRecord
from dbcraft.templates.emotes_text import EmotesTextRecord
from dbcraft.templates.emotes_text_data import EmotesTextDataRecord
from dbcraft.templates.emotes_text_sound import EmotesTextSoundRecord
from dbcraft.templates.environmental_damage import EnvironmentalDamageRecord
from dbcraft.templates.exhaustion import ExhaustionRecord
from dbcraft.templates.faction import FactionRecord
from dbcraft.templates.faction_group import FactionGroupRecord
from dbcraft.templates.faction_template import FactionTemplateRecord
from dbcraft.templates.file_data import FileDataRecord
from dbcraft.templates.footprint_textures import FootprintTexturesRecord
from dbcraft.templates.footstep_terrain_lookup import FootstepTerrainLookupRecord
from dbcraft.templates.game_object_art_kit import GameObjectArtKitRecord
from dbcraft.templates.game_object_display_info import GameObjectDisplayInfoRecord
from dbcraft.templates.game_tables import GameTablesRecord
from dbcraft.templates.game_tips import GameTipsRecord
from dbcraft.templates.gem_properties import GemPropertiesRecord
from dbcraft.templates.glyph_properties import GlyphPropertiesRecord
from dbcraft.templates.glyph_slot import GlyphSlotRecord
from dbcraft.templates.gm_survey_answers import GMSurveyAnswersRecord
from dbcraft.templates.gm_survey_current_survey import GMSurveyCurrentSurveyRecord
from dbcraft.templates.gm_survey_questions import GMSurveyQuestionsRecord
from dbcraft.templates.gm_survey_surveys import GMSurveySurveysRecord
from dbcraft.templates.gm_ticket_category import GMTicketCategoryRecord
from dbcraft.templates.ground_effect_doodad import GroundEffectDoodadRecord
from dbcraft.templates.ground_effect_texture import GroundEffectTextureRecord
from dbcraft.templates.gt_barber_shop_cost_base import GtBarberShopCostBaseRecord
from dbcraft.templates.gt_chance_to_melee_crit import GtChanceToMeleeCritRecord
from dbcraft.templates.gt_chance_to_melee_crit_base import GtChanceToMeleeCritBaseRecord
from dbcraft.templates.gt_chance_to_spell_crit import GtChanceToSpellCritRecord
from dbcraft.templates.gt_chance_to_spell_crit_base import GtChanceToSpellCritBaseRecord
from dbcraft.templates.gt_combat_ratings import GtCombatRatingsRecord
from dbcraft.templates.gt_npc_mana_cost_scaler import GtNPCManaCostScalerRecord
from dbcraft.templates.gt_oct_class_combat_rating_scalar import GtOCTClassCombatRatingScalarRecord
from dbcraft.templates.gt_oct_regen_hp import GtOCTRegenHPRecord
from dbcraft.templates.gt_oct_regen_mp import GtOCTRegenMPRecord
from dbcraft.templates.gt_regen_hp_per_spt import GtRegenHPPerSptRecord
from dbcraft.templates.gt_regen_mp_per_spt import GtRegenMPPerSptRecord
from dbcraft.templates.helmet_geoset_vis_data import HelmetGeosetVisDataRecord
from dbcraft.templates.holiday_descriptions import HolidayDescriptionsRecord
from dbcraft.templates.holiday_names import HolidayNamesRecord
from dbcraft.templates.holidays import HolidaysRecord
from dbcraft.templates.item import ItemRecord
from dbcraft.templates.item_bag_family import ItemBagFamilyRecord
from dbcraft.templates.item_class import ItemClassRecord
from dbcraft.templates.item_cond_ext_costs import ItemCondExtCostsRecord
from dbcraft.templates.item_display_info import ItemDisplayInfoRecord
from dbcraft.templates.item_extended_cost import ItemExtendedCostRecord
from dbcraft.templates.item_group_sounds import ItemGroupSoundsRecord
from dbcraft.templates.item_limit_category import ItemLimitCategoryRecord
from dbcraft.templates.item_pet_food import ItemPetFoodRecord
from dbcraft.templates.item_purchase_group import ItemPurchaseGroupRecord
from dbcraft.templates.item_random_properties import ItemRandomPropertiesRecord
from dbcraft.templates.item_random_suffix import ItemRandomSuffixRecord
from dbcraft.templates.item_set import ItemSetRecord
from dbcraft.templates.item_sub_class import ItemSubClassRecord
from dbcraft.templates.item_sub_class_mask import ItemSubClassMaskRecord
from dbcraft.templates.item_visual_effects import ItemVisualEffectsRecord
from dbcraft.templates.item_visuals import ItemVisualsRecord
from dbcraft.templates.language_words import LanguageWordsRecord
from dbcraft.templates.languages import LanguagesRecord
from dbcraft.templates.lfg_dungeon_expansion import LFGDungeonExpansionRecord
from dbcraft.templates.lfg_dungeon_group import LFGDungeonGroupRecord
from dbcraft.templates.lfg_dungeons import LFGDungeonsRecord
from dbcraft.templates.light import LightRecord
from dbcraft.templates.light_float_band import LightFloatBandRecord
from dbcraft.templates.light_int_band import LightIntBandRecord
from dbcraft.templates.light_params import LightParamsRecord
from dbcraft.templates.light_skybox import LightSkyboxRecord
from dbcraft.templates.liquid_material import LiquidMaterialRecord
from dbcraft.templates.liquid_type import LiquidTypeRecord
from dbcraft.templates.loading_screen_taxi_splines import LoadingScreenTaxiSplinesRecord
from dbcraft.templates.loading_screens import LoadingScreensRecord
from dbcraft.templates.lock import LockRecord
from dbcraft.templates.lock_type import LockTypeRecord
from dbcraft.templates.mail_template import MailTemplateRecord
from dbcraft.templates.map import MapRecord
from dbcraft.templates.map_difficulty import MapDifficultyRecord
from dbcraft.templates.material import MaterialRecord
from dbcraft.templates.movie import MovieRecord
from dbcraft.templates.movie_file_data import MovieFileDataRecord
from dbcraft.templates.movie_variation import MovieVariationRecord
from dbcraft.templates.name_gen import NameGenRecord
from dbcraft.templates.names_profanity import NamesProfanityRecord
from dbcraft.templates.names_reserved import NamesReservedRecord
from dbcraft.templates.npc_sounds import NPCSoundsRecord
from dbcraft.templates.object_effect import ObjectEffectRecord
from dbcraft.templates.object_effect_group import ObjectEffectGroupRecord
from dbcraft.templates.object_effect_modifier import ObjectEffectModifierRecord
from dbcraft.templates.object_effect_package import ObjectEffectPackageRecord
from dbcraft.templates.object_effect_package_elem import ObjectEffectPackageElemRecord
from dbcraft.templates.override_spell_data import OverrideSpellDataRecord
from dbcraft.templates.package import PackageRecord
from dbcraft.templates.page_text_material import PageTextMaterialRecord
from dbcraft.templates.paper_doll_item_frame import PaperDollItemFrameRecord
from dbcraft.templates.particle_color import ParticleColorRecord
from dbcraft.templates.pet_personality import PetPersonalityRecord
from dbcraft.templates.petition_type import PetitionTypeRecord
from dbcraft.templates.power_display import PowerDisplayRecord
from dbcraft.templates.pvp_difficulty import PvpDifficultyRecord
from dbcraft.templates.quest_faction_reward import QuestFactionRewardRecord
from dbcraft.templates.quest_info import QuestInfoRecord
from dbcraft.templates.quest_sort import QuestSortRecord
from dbcraft.templates.quest_xp import QuestXPRecord
from dbcraft.templates.rand_prop_points import RandPropPointsRecord
from dbcraft.templates.resistances import ResistancesRecord
from dbcraft.templates.scaling_stat_distribution import ScalingStatDistributionRecord
from dbcraft.templates.scaling_stat_values import ScalingStatValuesRecord
from dbcraft.templates.screen_effect import ScreenEffectRecord
from dbcraft.templates.server_messages import ServerMessagesRecord
from dbcraft.templates.sheathe_sound_lookups import SheatheSoundLookupsRecord
from dbcraft.templates.skill_costs_data import SkillCostsDataRecord
from dbcraft.templates.skill_line import SkillLineRecord
from dbcraft.templates.skill_line_ability import SkillLineAbilityRecord
from dbcraft.templates.skill_line_category import SkillLineCategoryRecord
from dbcraft.templates.skill_race_class_info import SkillRaceClassInfoRecord
from dbcraft.templates.skill_tiers import SkillTiersRecord
from dbcraft.templates.sound_ambience import SoundAmbienceRecord
from dbcraft.templates.sound_emitters import SoundEmittersRecord
from dbcraft.templates.sound_entries import SoundEntriesRecord
from dbcraft.templates.sound_entries_advanced import SoundEntriesAdvancedRecord
from dbcraft.templates.sound_filter import SoundFilterRecord
from dbcraft.templates.sound_filter_elem import SoundFilterElemRecord
from dbcraft.templates.sound_provider_preferences import SoundProviderPreferencesRecord
from dbcraft.templates.sound_sample_preferences import SoundSamplePreferencesRecord
from dbcraft.templates.sound_water_type import SoundWaterTypeRecord
from dbcraft.templates.spam_messages import SpamMessagesRecord
from dbcraft.templates.spell import SpellRecord
from dbcraft.templates.spell_cast_times import SpellCastTimesRecord
from dbcraft.templates.spell_category import SpellCategoryRecord
from dbcraft.templates.spell_chain_effects import SpellChainEffectsRecord
from dbcraft.templates.spell_description_variables import SpellDescriptionVariablesRecord
from dbcraft.templates.spell_difficulty import SpellDifficultyRecord
from dbcraft.templates.spell_dispel_type import SpellDispelTypeRecord
from dbcraft.templates.spell_duration import SpellDurationRecord
from dbcraft.templates.spell_effect_camera_shakes import SpellEffectCameraShakesRecord
from dbcraft.templates.spell_focus_object import SpellFocusObjectRecord
from dbcraft.templates.spell_icon import SpellIconRecord
from dbcraft.templates.spell_item_enchantment import SpellItemEnchantmentRecord
from dbcraft.templates.spell_item_enchantment_condition import SpellItemEnchantmentConditionRecord
from dbcraft.templates.spell_mechanic import SpellMechanicRecord
from dbcraft.templates.spell_missile import SpellMissileRecord
from dbcraft.templates.spell_missile_motion import SpellMissileMotionRecord
from dbcraft.templates.spell_radius import SpellRadiusRecord
from dbcraft.templates.spell_range import SpellRangeRecord
from dbcraft.templates.spell_rune_cost import SpellRuneCostRecord
from dbcraft.templates.spell_shapeshift_form import SpellShapeshiftFormRecord
from dbcraft.templates.spell_visual import SpellVisualRecord
from dbcraft.templates.spell_visual_effect_name import SpellVisualEffectNameRecord
from dbcraft.templates.spell_visual_kit import SpellVisualKitRecord
from dbcraft.templates.spell_visual_kit_area_model import SpellVisualKitAreaModelRecord
from dbcraft.templates.spell_visual_kit_model_attach import SpellVisualKitModelAttachRecord
from dbcraft.templates.spell_visual_precast_transitions import SpellVisualPrecastTransitionsRecord
from dbcraft.templates.stable_slot_prices import StableSlotPricesRecord
from dbcraft.templates.startup_strings import StartupStringsRecord
from dbcraft.templates.stationery import StationeryRecord
from dbcraft.templates.string_lookups import StringLookupsRecord
from dbcraft.templates.summon_properties import SummonPropertiesRecord
from dbcraft.templates.talent import TalentRecord
from dbcraft.templates.talent_tab import TalentTabRecord
from dbcraft.templates.taxi_nodes import TaxiNodesRecord
from dbcraft.templates.taxi_path import TaxiPathRecord
from dbcraft.templates.taxi_path_node import TaxiPathNodeRecord
from dbcraft.templates.team_contribution_points import TeamContributionPointsRecord
from dbcraft.templates.terrain_type import TerrainTypeRecord
from dbcraft.templates.terrain_type_sounds import TerrainTypeSoundsRecord
from dbcraft.templates.totem_category import TotemCategoryRecord
from dbcraft.templates.transport_animation import TransportAnimationRecord
from dbcraft.templates.transport_physics import TransportPhysicsRecord
from dbcraft.templates.transport_rotation import TransportRotationRecord
from dbcraft.templates.ui_sound_lookups import UISoundLookupsRecord
from dbcraft.templates.unit_blood import UnitBloodRecord
from dbcraft.templates.unit_blood_levels import UnitBloodLevelsRecord
from dbcraft.templates.vehicle import VehicleRecord
from dbcraft.templates.vehicle_seat import VehicleSeatRecord
from dbcraft.templates.vehicle_ui_ind_seat import VehicleUIIndSeatRecord
from dbcraft.templates.vehicle_ui_indicator import VehicleUIIndicatorRecord
from dbcraft.templates.video_hardware import VideoHardwareRecord
from dbcraft.templates.vocal_ui_sounds import VocalUISoundsRecord
from dbcraft.templates.weapon_impact_sounds import WeaponImpactSoundsRecord
from dbcraft.templates.weapon_swing_sounds2 import WeaponSwingSounds2Record
from dbcraft.templates.weather import WeatherRecord
from dbcraft.templates.wmo_area_table import WMOAreaTableRecord
from dbcraft.templates.world_chunk_sounds import WorldChunkSoundsRecord
from dbcraft.templates.world_map_area import WorldMapAreaRecord
from dbcraft.templates.world_map_continent import WorldMapContinentRecord
from dbcraft.templates.world_map_overlay import WorldMapOverlayRecord
from dbcraft.templates.world_map_transforms import WorldMapTransformsRecord
from dbcraft.templates.world_safe_locs import WorldSafeLocsRecord
from dbcraft.templates.world_state_ui import WorldStateUIRecord
from dbcraft.templates.world_state_zone_sounds import WorldStateZoneSoundsRecord
from dbcraft.templates.wow_error_strings import WowErrorStringsRecord
from dbcraft.templates.zone_intro_music_table import ZoneIntroMusicTableRecord
from dbcraft.templates.zone_music import ZoneMusicRecord

__all__ = [
    "AchievementRecord",
    "AchievementCategoryRecord",
    "AchievementCriteriaRecord",
    "AnimationDataRecord",
    "AreaGroupRecord",
    "AreaPOIRecord",
    "AreaTableRecord",
    "AreaTriggerRecord",
    "AttackAnimKitsRecord",
    "AttackAnimTypesRecord",
    "AuctionHouseRecord",
    "BankBagSlotPricesRecord",
    "BannedAddOnsRecord",
    "BarberShopStyleRecord",
    "BattlemasterListRecord",
    "CameraShakesRecord",
    "CfgCategoriesRecord",
    "CfgConfigsRecord",
    "CharBaseInfoRecord",
    "CharHairGeosetsRecord",
    "CharHairTexturesRecord",
    "CharSectionsRecord",
    "CharStartOutfitRecord",
    "CharTitlesRecord",
    "CharVariationsRecord",
    "CharacterFacialHairStylesRecord",
    "ChatChannelsRecord",
    "ChatProfanityRecord",
    "ChrClassesRecord",
    "ChrRacesRecord",
    "CinematicCameraRecord",
    "CinematicSequencesRecord",
    "CreatureDisplayInfoRecord",
    "CreatureDisplayInfoExtraRecord",
    "CreatureFamilyRecord",
    "CreatureModelDataRecord",
    "CreatureMovementInfoRecord",
    "CreatureSoundDataRecord",
    "CreatureSpellDataRecord",
    "CreatureTypeRecord",
    "CurrencyCategoryRecord",
    "CurrencyTypesRecord",
    "DanceMovesRecord",
    "DeathThudLookupsRecord",
    "DeclinedWordRecord",
    "DeclinedWordCasesRecord",
    "DestructibleModelDataRecord",
    "DungeonEncounterRecord",
    "DungeonMapRecord",
    "DungeonMapChunkRecord",
    "DurabilityCostsRecord",
    "DurabilityQualityRecord",
    "EmotesRecord",
    "EmotesTextRecord",
    "EmotesTextDataRecord",
    "EmotesTextSoundRecord",
    "EnvironmentalDamageRecord",
    "ExhaustionRecord",
    "FactionRecord",
    "FactionGroupRecord",
    "FactionTemplateRecord",
    "FileDataRecord",
    "FootprintTexturesRecord",
    "FootstepTerrainLookupRecord",
    "GameObjectArtKitRecord",
    "GameObjectDisplayInfoRecord",
    "GameTablesRecord",
    "GameTipsRecord",
    "GemPropertiesRecord",
    "GlyphPropertiesRecord",
    "GlyphSlotRecord",
    "GMSurveyAnswersRecord",
    "GMSurveyCurrentSurveyRecord",
    "GMSurveyQuestionsRecord",
    "GMSurveySurveysRecord",
    "GMTicketCategoryRecord",
    "GroundEffectDoodadRecord",
    "GroundEffectTextureRecord",
    "GtBarberShopCostBaseRecord",
    "GtChanceToMeleeCritRecord",
    "GtChanceToMeleeCritBaseRecord",
    "GtChanceToSpellCritRecord",
    "GtChanceToSpellCritBaseRecord",
    "GtCombatRatingsRecord",
    "GtNPCManaCostScalerRecord",
    "GtOCTClassCombatRatingScalarRecord",
    "GtOCTRegenHPRecord",
    "GtOCTRegenMPRecord",
    "GtRegenHPPerSptRecord",
    "GtRegenMPPerSptRecord",
    "HelmetGeosetVisDataRecord",
    "HolidayDescriptionsRecord",
    "HolidayNamesRecord",
    "HolidaysRecord",
    "ItemRecord",
    "ItemBagFamilyRecord",
    "ItemClassRecord",
    "ItemCondExtCostsRecord",
    "ItemDisplayInfoRecord",
    "ItemExtendedCostRecord",
    "ItemGroupSoundsRecord",
    "ItemLimitCategoryRecord",
    "ItemPetFoodRecord",
    "ItemPurchaseGroupRecord",
    "ItemRandomPropertiesRecord",
    "ItemRandomSuffixRecord",
    "ItemSetRecord",
    "ItemSubClassRecord",
    "ItemSubClassMaskRecord",
    "ItemVisualEffectsRecord",
    "ItemVisualsRecord",
    "LanguageWordsRecord",
    "LanguagesRecord",
    "LFGDungeonExpansionRecord",
    "LFGDungeonGroupRecord",
    "LFGDungeonsRecord",
    "LightRecord",
    "LightFloatBandRecord",
    "LightIntBandRecord",
    "LightParamsRecord",
    "LightSkyboxRecord",
    "LiquidMaterialRecord",
    "LiquidTypeRecord",
    "LoadingScreenTaxiSplinesRecord",
    "LoadingScreensRecord",
    "LockRecord",
    "LockTypeRecord",
    "MailTemplateRecord",
    "MapRecord",
    "MapDifficultyRecord",
    "MaterialRecord",
    "MovieRecord",
    "MovieFileDataRecord",
    "MovieVariationRecord",
    "NameGenRecord",
    "NamesProfanityRecord",
    "NamesReservedRecord",
    "NPCSoundsRecord",
    "ObjectEffectRecord",
    "ObjectEffectGroupRecord",
    "ObjectEffectModifierRecord",
    "ObjectEffectPackageRecord",
    "ObjectEffectPackageElemRecord",
    "OverrideSpellDataRecord",
    "PackageRecord",
    "PageTextMaterialRecord",
    "PaperDollItemFrameRecord",
    "ParticleColorRecord",
    "PetPersonalityRecord",
    "PetitionTypeRecord",
    "PowerDisplayRecord",
    "PvpDifficultyRecord",
    "QuestFactionRewardRecord",
    "QuestInfoRecord",
    "QuestSortRecord",
    "QuestXPRecord",
    "RandPropPointsRecord",
    "ResistancesRecord",
    "ScalingStatDistributionRecord",
    "ScalingStatValuesRecord",
    "ScreenEffectRecord",
    "ServerMessagesRecord",
    "SheatheSoundLookupsRecord",
    "SkillCostsDataRecord",
    "SkillLineRecord",
    "SkillLineAbilityRecord",
    "SkillLineCategoryRecord",
    "SkillRaceClassInfoRecord",
    "SkillTiersRecord",
    "SoundAmbienceRecord",
    "SoundEmittersRecord",
    "SoundEntriesRecord",
    "SoundEntriesAdvancedRecord",
    "SoundFilterRecord",
    "SoundFilterElemRecord",
    "SoundProviderPreferencesRecord",
    "SoundSamplePreferencesRecord",
    "SoundWaterTypeRecord",
    "SpamMessagesRecord",
    "SpellRecord",
    "SpellCastTimesRecord",
    "SpellCategoryRecord",
    "SpellChainEffectsRecord",
    "SpellDescriptionVariablesRecord",
    "SpellDifficultyRecord",
    "SpellDispelTypeRecord",
    "SpellDurationRecord",
    "SpellEffectCameraShakesRecord",
    "SpellFocusObjectRecord",
    "SpellIconRecord",
    "SpellItemEnchantmentRecord",
    "SpellItemEnchantmentConditionRecord",
    "SpellMechanicRecord",
    "SpellMissileRecord",
    "SpellMissileMotionRecord",
    "SpellRadiusRecord",
    "SpellRangeRecord",
    "SpellRuneCostRecord",
    "SpellShapeshiftFormRecord",
    "SpellVisualRecord",
    "SpellVisualEffectNameRecord",
    "SpellVisualKitRecord",
    "SpellVisualKitAreaModelRecord",
    "SpellVisualKitModelAttachRecord",
    "SpellVisualPrecastTransitionsRecord",
    "StableSlotPricesRecord",
    "StartupStringsRecord",
    "StationeryRecord",
    "StringLookupsRecord",
    "SummonPropertiesRecord",
    "TalentRecord",
    "TalentTabRecord",
    "TaxiNodesRecord",
    "TaxiPathRecord",
    "TaxiPathNodeRecord",
    "TeamContributionPointsRecord",
    "TerrainTypeRecord",
    "TerrainTypeSoundsRecord",
    "TotemCategoryRecord",
    "TransportAnimationRecord",
    "TransportPhysicsRecord",
    "TransportRotationRecord",
    "UISoundLookupsRecord",
    "UnitBloodRecord",
    "UnitBloodLevelsRecord",
    "VehicleRecord",
    "VehicleSeatRecord",
    "VehicleUIIndSeatRecord",
    "VehicleUIIndicatorRecord",
    "VideoHardwareRecord",
    "VocalUISoundsRecord",
    "WeaponImpactSoundsRecord",
    "WeaponSwingSounds2Record",
    "WeatherRecord",
    "WMOAreaTableRecord",
    "WorldChunkSoundsRecord",
    "WorldMapAreaRecord",
    "WorldMapContinentRecord",
    "WorldMapOverlayRecord",
    "WorldMapTransformsRecord",
    "WorldSafeLocsRecord",
    "WorldStateUIRecord",
    "WorldStateZoneSoundsRecord",
    "WowErrorStringsRecord",
    "ZoneIntroMusicTableRecord",
    "ZoneMusicRecord",
]
