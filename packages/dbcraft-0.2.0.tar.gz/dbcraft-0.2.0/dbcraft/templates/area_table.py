"""AreaTable.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 17 int32 fields
  - 2 float32 fields
  - 1 loc_string_ref field (1 x 17 = 17 on disk)
  - Total: 36 fields on disk

Record size: 36 * 4 = 144 bytes

See Also:
  - https://wowdev.wiki/DB/AreaTable
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("AreaTable")
@dataclass
class AreaTableRecord:
    """A record from AreaTable.dbc (3.3.5a, build 12340)."""

    id: int32

    continent_id: int32 = int32(0)

    parent_area_id: int32 = int32(0)

    area_bit: int32 = int32(0)

    flags: int32 = int32(0)

    sound_provider_pref: int32 = int32(0)

    sound_provider_pref_underwater: int32 = int32(0)

    ambience_id: int32 = int32(0)

    zone_music: int32 = int32(0)

    intro_sound: int32 = int32(0)

    exploration_level: int32 = int32(0)

    area_name_lang: loc_string_ref = field(default_factory=LocalizedString)

    faction_group_mask: int32 = int32(0)

    liquid_type_id_0: int32 = int32(0)

    liquid_type_id_1: int32 = int32(0)

    liquid_type_id_2: int32 = int32(0)

    liquid_type_id_3: int32 = int32(0)

    min_elevation: float32 = float32(0.0)

    ambient_multiplier: float32 = float32(0.0)

    light_id: int32 = int32(0)
