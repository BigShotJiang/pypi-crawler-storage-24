"""SheatheSoundLookups.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 7 int32 fields
  - Total: 7 fields on disk

Record size: 7 * 4 = 28 bytes

See Also:
  - https://wowdev.wiki/DB/SheatheSoundLookups
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("SheatheSoundLookups")
@dataclass
class SheatheSoundLookupsRecord:
    """A record from SheatheSoundLookups.dbc (3.3.5a, build 12340)."""

    id: int32

    class_id: int32 = int32(0)

    subclass_id: int32 = int32(0)

    material: int32 = int32(0)

    check_material: int32 = int32(0)

    sheathe_sound: int32 = int32(0)

    unsheathe_sound: int32 = int32(0)
