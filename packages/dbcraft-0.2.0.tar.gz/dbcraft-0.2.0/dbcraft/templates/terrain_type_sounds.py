"""TerrainTypeSounds.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - Total: 1 fields on disk

Record size: 1 * 4 = 4 bytes

See Also:
  - https://wowdev.wiki/DB/TerrainTypeSounds
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("TerrainTypeSounds")
@dataclass
class TerrainTypeSoundsRecord:
    """A record from TerrainTypeSounds.dbc (3.3.5a, build 12340)."""

    id: int32
