"""ObjectEffect.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - 3 float32 fields
  - 1 string_ref field
  - Total: 12 fields on disk

Record size: 12 * 4 = 48 bytes

See Also:
  - https://wowdev.wiki/DB/ObjectEffect
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("ObjectEffect")
@dataclass
class ObjectEffectRecord:
    """A record from ObjectEffect.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    object_effect_group_id: int32 = int32(0)

    trigger_type: int32 = int32(0)

    event_type: int32 = int32(0)

    effect_rec_type: int32 = int32(0)

    effect_rec_id: int32 = int32(0)

    attachment: int32 = int32(0)

    offset_0: float32 = float32(0.0)

    offset_1: float32 = float32(0.0)

    offset_2: float32 = float32(0.0)

    object_effect_modifier_id: int32 = int32(0)
