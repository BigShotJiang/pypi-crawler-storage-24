"""Spell.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 150 int32 fields
  - 16 float32 fields
  - 4 loc_string_ref fields (4 x 17 = 68 on disk)
  - Total: 234 fields on disk

Record size: 234 * 4 = 936 bytes

See Also:
  - https://wowdev.wiki/DB/Spell
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, float32, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("Spell")
@dataclass
class SpellRecord:
    """A record from Spell.dbc (3.3.5a, build 12340)."""

    id: int32

    category: int32 = int32(0)

    dispel_type: int32 = int32(0)

    mechanic: int32 = int32(0)

    attributes: int32 = int32(0)

    attributes_ex: int32 = int32(0)

    attributes_ex_b: int32 = int32(0)

    attributes_ex_c: int32 = int32(0)

    attributes_ex_d: int32 = int32(0)

    attributes_ex_e: int32 = int32(0)

    attributes_ex_f: int32 = int32(0)

    attributes_ex_g: int32 = int32(0)

    shapeshift_mask_0: int32 = int32(0)

    shapeshift_mask_1: int32 = int32(0)

    shapeshift_exclude_0: int32 = int32(0)

    shapeshift_exclude_1: int32 = int32(0)

    targets: int32 = int32(0)

    target_creature_type: int32 = int32(0)

    requires_spell_focus: int32 = int32(0)

    facing_caster_flags: int32 = int32(0)

    caster_aura_state: int32 = int32(0)

    target_aura_state: int32 = int32(0)

    exclude_caster_aura_state: int32 = int32(0)

    exclude_target_aura_state: int32 = int32(0)

    caster_aura_spell: int32 = int32(0)

    target_aura_spell: int32 = int32(0)

    exclude_caster_aura_spell: int32 = int32(0)

    exclude_target_aura_spell: int32 = int32(0)

    casting_time_index: int32 = int32(0)

    recovery_time: int32 = int32(0)

    category_recovery_time: int32 = int32(0)

    interrupt_flags: int32 = int32(0)

    aura_interrupt_flags: int32 = int32(0)

    channel_interrupt_flags: int32 = int32(0)

    proc_type_mask: int32 = int32(0)

    proc_chance: int32 = int32(0)

    proc_charges: int32 = int32(0)

    max_level: int32 = int32(0)

    base_level: int32 = int32(0)

    spell_level: int32 = int32(0)

    duration_index: int32 = int32(0)

    power_type: int32 = int32(0)

    mana_cost: int32 = int32(0)

    mana_cost_per_level: int32 = int32(0)

    mana_per_second: int32 = int32(0)

    mana_per_second_per_level: int32 = int32(0)

    range_index: int32 = int32(0)

    speed: float32 = float32(0.0)

    modal_next_spell: int32 = int32(0)

    cumulative_aura: int32 = int32(0)

    totem_0: int32 = int32(0)

    totem_1: int32 = int32(0)

    reagent_0: int32 = int32(0)

    reagent_1: int32 = int32(0)

    reagent_2: int32 = int32(0)

    reagent_3: int32 = int32(0)

    reagent_4: int32 = int32(0)

    reagent_5: int32 = int32(0)

    reagent_6: int32 = int32(0)

    reagent_7: int32 = int32(0)

    reagent_count_0: int32 = int32(0)

    reagent_count_1: int32 = int32(0)

    reagent_count_2: int32 = int32(0)

    reagent_count_3: int32 = int32(0)

    reagent_count_4: int32 = int32(0)

    reagent_count_5: int32 = int32(0)

    reagent_count_6: int32 = int32(0)

    reagent_count_7: int32 = int32(0)

    equipped_item_class: int32 = int32(0)

    equipped_item_subclass: int32 = int32(0)

    equipped_item_inv_types: int32 = int32(0)

    effect_0: int32 = int32(0)

    effect_1: int32 = int32(0)

    effect_2: int32 = int32(0)

    effect_die_sides_0: int32 = int32(0)

    effect_die_sides_1: int32 = int32(0)

    effect_die_sides_2: int32 = int32(0)

    effect_real_points_per_level_0: float32 = float32(0.0)

    effect_real_points_per_level_1: float32 = float32(0.0)

    effect_real_points_per_level_2: float32 = float32(0.0)

    effect_base_points_0: int32 = int32(0)

    effect_base_points_1: int32 = int32(0)

    effect_base_points_2: int32 = int32(0)

    effect_mechanic_0: int32 = int32(0)

    effect_mechanic_1: int32 = int32(0)

    effect_mechanic_2: int32 = int32(0)

    implicit_target_a_0: int32 = int32(0)

    implicit_target_a_1: int32 = int32(0)

    implicit_target_a_2: int32 = int32(0)

    implicit_target_b_0: int32 = int32(0)

    implicit_target_b_1: int32 = int32(0)

    implicit_target_b_2: int32 = int32(0)

    effect_radius_index_0: int32 = int32(0)

    effect_radius_index_1: int32 = int32(0)

    effect_radius_index_2: int32 = int32(0)

    effect_aura_0: int32 = int32(0)

    effect_aura_1: int32 = int32(0)

    effect_aura_2: int32 = int32(0)

    effect_aura_period_0: int32 = int32(0)

    effect_aura_period_1: int32 = int32(0)

    effect_aura_period_2: int32 = int32(0)

    effect_amplitude_0: float32 = float32(0.0)

    effect_amplitude_1: float32 = float32(0.0)

    effect_amplitude_2: float32 = float32(0.0)

    effect_chain_targets_0: int32 = int32(0)

    effect_chain_targets_1: int32 = int32(0)

    effect_chain_targets_2: int32 = int32(0)

    effect_item_type_0: int32 = int32(0)

    effect_item_type_1: int32 = int32(0)

    effect_item_type_2: int32 = int32(0)

    effect_misc_value_0: int32 = int32(0)

    effect_misc_value_1: int32 = int32(0)

    effect_misc_value_2: int32 = int32(0)

    effect_misc_value_b_0: int32 = int32(0)

    effect_misc_value_b_1: int32 = int32(0)

    effect_misc_value_b_2: int32 = int32(0)

    effect_trigger_spell_0: int32 = int32(0)

    effect_trigger_spell_1: int32 = int32(0)

    effect_trigger_spell_2: int32 = int32(0)

    effect_points_per_combo_0: float32 = float32(0.0)

    effect_points_per_combo_1: float32 = float32(0.0)

    effect_points_per_combo_2: float32 = float32(0.0)

    effect_spell_class_mask_a_0: int32 = int32(0)

    effect_spell_class_mask_a_1: int32 = int32(0)

    effect_spell_class_mask_a_2: int32 = int32(0)

    effect_spell_class_mask_b_0: int32 = int32(0)

    effect_spell_class_mask_b_1: int32 = int32(0)

    effect_spell_class_mask_b_2: int32 = int32(0)

    effect_spell_class_mask_c_0: int32 = int32(0)

    effect_spell_class_mask_c_1: int32 = int32(0)

    effect_spell_class_mask_c_2: int32 = int32(0)

    spell_visual_id_0: int32 = int32(0)

    spell_visual_id_1: int32 = int32(0)

    spell_icon_id: int32 = int32(0)

    active_icon_id: int32 = int32(0)

    spell_priority: int32 = int32(0)

    name_lang: loc_string_ref = field(default_factory=LocalizedString)

    name_subtext_lang: loc_string_ref = field(default_factory=LocalizedString)

    description_lang: loc_string_ref = field(default_factory=LocalizedString)

    aura_description_lang: loc_string_ref = field(default_factory=LocalizedString)

    mana_cost_pct: int32 = int32(0)

    start_recovery_category: int32 = int32(0)

    start_recovery_time: int32 = int32(0)

    max_target_level: int32 = int32(0)

    spell_class_set: int32 = int32(0)

    spell_class_mask_0: int32 = int32(0)

    spell_class_mask_1: int32 = int32(0)

    spell_class_mask_2: int32 = int32(0)

    max_targets: int32 = int32(0)

    defense_type: int32 = int32(0)

    prevention_type: int32 = int32(0)

    stance_bar_order: int32 = int32(0)

    effect_chain_amplitude_0: float32 = float32(0.0)

    effect_chain_amplitude_1: float32 = float32(0.0)

    effect_chain_amplitude_2: float32 = float32(0.0)

    min_faction_id: int32 = int32(0)

    min_reputation: int32 = int32(0)

    required_aura_vision: int32 = int32(0)

    required_totem_category_id_0: int32 = int32(0)

    required_totem_category_id_1: int32 = int32(0)

    required_areas_id: int32 = int32(0)

    school_mask: int32 = int32(0)

    rune_cost_id: int32 = int32(0)

    spell_missile_id: int32 = int32(0)

    power_display_id: int32 = int32(0)

    effect_bonus_coefficient_0: float32 = float32(0.0)

    effect_bonus_coefficient_1: float32 = float32(0.0)

    effect_bonus_coefficient_2: float32 = float32(0.0)

    description_variables_id: int32 = int32(0)

    difficulty: int32 = int32(0)
