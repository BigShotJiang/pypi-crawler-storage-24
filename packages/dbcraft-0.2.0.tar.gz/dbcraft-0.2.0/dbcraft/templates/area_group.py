"""AreaGroup.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 8 int32 fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/AreaGroup
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("AreaGroup")
@dataclass
class AreaGroupRecord:
    """A record from AreaGroup.dbc (3.3.5a, build 12340)."""

    id: int32

    area_id_0: int32 = int32(0)

    area_id_1: int32 = int32(0)

    area_id_2: int32 = int32(0)

    area_id_3: int32 = int32(0)

    area_id_4: int32 = int32(0)

    area_id_5: int32 = int32(0)

    next_area_id: int32 = int32(0)
