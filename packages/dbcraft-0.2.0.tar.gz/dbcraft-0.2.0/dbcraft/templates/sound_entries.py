"""SoundEntries.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 15 int32 fields
  - 3 float32 fields
  - 12 string_ref fields
  - Total: 30 fields on disk

Record size: 30 * 4 = 120 bytes

See Also:
  - https://wowdev.wiki/DB/SoundEntries
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32, string_ref
from dbcraft.templates.base import register_template


@register_template("SoundEntries")
@dataclass
class SoundEntriesRecord:
    """A record from SoundEntries.dbc (3.3.5a, build 12340)."""

    id: int32

    sound_type: int32 = int32(0)

    name: string_ref = string_ref("")

    file_0: string_ref = string_ref("")

    file_1: string_ref = string_ref("")

    file_2: string_ref = string_ref("")

    file_3: string_ref = string_ref("")

    file_4: string_ref = string_ref("")

    file_5: string_ref = string_ref("")

    file_6: string_ref = string_ref("")

    file_7: string_ref = string_ref("")

    file_8: string_ref = string_ref("")

    file_9: string_ref = string_ref("")

    freq_0: int32 = int32(0)

    freq_1: int32 = int32(0)

    freq_2: int32 = int32(0)

    freq_3: int32 = int32(0)

    freq_4: int32 = int32(0)

    freq_5: int32 = int32(0)

    freq_6: int32 = int32(0)

    freq_7: int32 = int32(0)

    freq_8: int32 = int32(0)

    freq_9: int32 = int32(0)

    directory_base: string_ref = string_ref("")

    volume_float: float32 = float32(0.0)

    flags: int32 = int32(0)

    min_distance: float32 = float32(0.0)

    distance_cutoff: float32 = float32(0.0)

    e_a_x_def: int32 = int32(0)

    sound_entries_advanced_id: int32 = int32(0)
