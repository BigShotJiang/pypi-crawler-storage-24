"""WorldMapTransforms.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 4 int32 fields
  - 6 float32 fields
  - Total: 10 fields on disk

Record size: 10 * 4 = 40 bytes

See Also:
  - https://wowdev.wiki/DB/WorldMapTransforms
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("WorldMapTransforms")
@dataclass
class WorldMapTransformsRecord:
    """A record from WorldMapTransforms.dbc (3.3.5a, build 12340)."""

    id: int32

    map_id: int32 = int32(0)

    region_min_0: float32 = float32(0.0)

    region_min_1: float32 = float32(0.0)

    region_max_0: float32 = float32(0.0)

    region_max_1: float32 = float32(0.0)

    new_map_id: int32 = int32(0)

    region_offset_0: float32 = float32(0.0)

    region_offset_1: float32 = float32(0.0)

    new_dungeon_map_id: int32 = int32(0)
