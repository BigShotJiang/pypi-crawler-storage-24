"""NameGen.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 3 int32 fields
  - 1 string_ref field
  - Total: 4 fields on disk

Record size: 4 * 4 = 16 bytes

See Also:
  - https://wowdev.wiki/DB/NameGen
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("NameGen")
@dataclass
class NameGenRecord:
    """A record from NameGen.dbc (3.3.5a, build 12340)."""

    id: int32

    name: string_ref = string_ref("")

    race_id: int32 = int32(0)

    sex: int32 = int32(0)
