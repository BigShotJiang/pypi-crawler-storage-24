"""OverrideSpellData.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 12 int32 fields
  - Total: 12 fields on disk

Record size: 12 * 4 = 48 bytes

See Also:
  - https://wowdev.wiki/DB/OverrideSpellData
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32
from dbcraft.templates.base import register_template


@register_template("OverrideSpellData")
@dataclass
class OverrideSpellDataRecord:
    """A record from OverrideSpellData.dbc (3.3.5a, build 12340)."""

    id: int32

    spells_0: int32 = int32(0)

    spells_1: int32 = int32(0)

    spells_2: int32 = int32(0)

    spells_3: int32 = int32(0)

    spells_4: int32 = int32(0)

    spells_5: int32 = int32(0)

    spells_6: int32 = int32(0)

    spells_7: int32 = int32(0)

    spells_8: int32 = int32(0)

    spells_9: int32 = int32(0)

    flags: int32 = int32(0)
