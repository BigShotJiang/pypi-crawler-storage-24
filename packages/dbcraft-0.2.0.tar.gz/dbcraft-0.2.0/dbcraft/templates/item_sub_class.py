"""ItemSubClass.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 10 int32 fields
  - 2 loc_string_ref fields (2 x 17 = 34 on disk)
  - Total: 44 fields on disk

Record size: 44 * 4 = 176 bytes

See Also:
  - https://wowdev.wiki/DB/ItemSubClass
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dbcraft.core.types import LocalizedString, int32, loc_string_ref
from dbcraft.templates.base import register_template


@register_template("ItemSubClass")
@dataclass
class ItemSubClassRecord:
    """A record from ItemSubClass.dbc (3.3.5a, build 12340)."""

    class_id: int32 = int32(0)

    sub_class_id: int32 = int32(0)

    prerequisite_proficiency: int32 = int32(0)

    postrequisite_proficiency: int32 = int32(0)

    flags: int32 = int32(0)

    display_flags: int32 = int32(0)

    weapon_parry_seq: int32 = int32(0)

    weapon_ready_seq: int32 = int32(0)

    weapon_attack_seq: int32 = int32(0)

    weapon_swing_size: int32 = int32(0)

    display_name_lang: loc_string_ref = field(default_factory=LocalizedString)

    verbose_name_lang: loc_string_ref = field(default_factory=LocalizedString)
