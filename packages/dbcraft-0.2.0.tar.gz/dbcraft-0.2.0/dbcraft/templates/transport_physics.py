"""TransportPhysics.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 10 float32 fields
  - Total: 11 fields on disk

Record size: 11 * 4 = 44 bytes

See Also:
  - https://wowdev.wiki/DB/TransportPhysics
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import float32, int32
from dbcraft.templates.base import register_template


@register_template("TransportPhysics")
@dataclass
class TransportPhysicsRecord:
    """A record from TransportPhysics.dbc (3.3.5a, build 12340)."""

    id: int32

    wave_amp: float32 = float32(0.0)

    wave_time_scale: float32 = float32(0.0)

    roll_amp: float32 = float32(0.0)

    roll_time_scale: float32 = float32(0.0)

    pitch_amp: float32 = float32(0.0)

    pitch_time_scale: float32 = float32(0.0)

    max_bank: float32 = float32(0.0)

    max_bank_turn_speed: float32 = float32(0.0)

    speed_damp_thresh: float32 = float32(0.0)

    speed_damp: float32 = float32(0.0)
