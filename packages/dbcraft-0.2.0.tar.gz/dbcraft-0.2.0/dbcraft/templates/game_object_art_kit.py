"""GameObjectArtKit.dbc template for WoW 3.3.5a (build 12340).

Field count breakdown:
  - 1 int32 field
  - 7 string_ref fields
  - Total: 8 fields on disk

Record size: 8 * 4 = 32 bytes

See Also:
  - https://wowdev.wiki/DB/GameObjectArtKit
"""

from __future__ import annotations

from dataclasses import dataclass

from dbcraft.core.types import int32, string_ref
from dbcraft.templates.base import register_template


@register_template("GameObjectArtKit")
@dataclass
class GameObjectArtKitRecord:
    """A record from GameObjectArtKit.dbc (3.3.5a, build 12340)."""

    id: int32

    texture_variation_0: string_ref = string_ref("")

    texture_variation_1: string_ref = string_ref("")

    texture_variation_2: string_ref = string_ref("")

    attach_model_0: string_ref = string_ref("")

    attach_model_1: string_ref = string_ref("")

    attach_model_2: string_ref = string_ref("")

    attach_model_3: string_ref = string_ref("")
