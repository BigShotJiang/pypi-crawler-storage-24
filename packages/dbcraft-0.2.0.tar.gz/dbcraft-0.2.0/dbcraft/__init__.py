"""dbcraft - A Python library for reading, writing, and creating WoW 3.3.5a DBC files."""

from dbcraft.dbc_file import DbcFile
from dbcraft.core.types import (
    uint32,
    int32,
    int8,
    float32,
    string_ref,
    loc_string_ref,
    LocalizedString,
)

# Import all templates so they auto-register on package import.
# Re-export every record class for convenient top-level access.
from dbcraft.templates import *  # noqa: F401, F403
from dbcraft.templates import __all__ as _template_all

__all__ = [
    "DbcFile",
    "uint32",
    "int32",
    "int8",
    "float32",
    "string_ref",
    "loc_string_ref",
    "LocalizedString",
    *_template_all,
]

__version__ = "0.2.0"
