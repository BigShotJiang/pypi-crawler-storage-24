"""High-level DBC file API for reading, writing, and creating DBC files.

This module provides the main user-facing class `DbcFile` which wraps
the low-level reader/writer with template auto-detection and a
convenient API for manipulating DBC records.

Usage examples::

    # Read a DBC file
    dbc = DbcFile.read("Spell.dbc")
    print(dbc.records[0].spell_name.en_us)

    # Modify and write back
    dbc.records[0].spell_name.en_us = "Modified"
    dbc.write("Spell_modified.dbc")

    # Create a new DBC from scratch
    dbc = DbcFile.create("CharTitles")
    dbc.records.append(CharTitlesRecord(...))
    dbc.write("CharTitles.dbc")
"""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import dbcraft.templates  # noqa: F401 - ensure templates are registered
from dbcraft.core.reader import read_dbc
from dbcraft.core.writer import write_dbc
from dbcraft.templates.base import get_template


class DbcFile:
    """Main user-facing class for working with DBC files.

    Attributes:
        dbc_name: The DBC file name without extension (e.g. "Spell").
        record_cls: The record dataclass type for this DBC.
        records: Mutable list of record instances.
    """

    def __init__(
        self,
        dbc_name: str,
        record_cls: type,
        records: list[Any] | None = None,
        source_bytes: bytes | None = None,
    ) -> None:
        self.dbc_name = dbc_name
        self.record_cls = record_cls
        self.records: list[Any] = records if records is not None else []
        self._source_bytes = source_bytes
        self._source_records_snapshot = deepcopy(self.records) if source_bytes is not None else None

    @classmethod
    def read(cls, path: str | Path) -> DbcFile:
        """Read a DBC file from disk.

        The template is auto-detected from the filename. For example,
        reading "Spell.dbc" will use the registered "Spell" template.

        Args:
            path: Path to the DBC file.

        Returns:
            A DbcFile instance with the parsed records.

        Raises:
            FileNotFoundError: If the file doesn't exist.
            KeyError: If no template is registered for the filename.
            ValueError: If the file is malformed.
        """
        path = Path(path)
        dbc_name = path.stem
        record_cls = get_template(dbc_name)

        data = path.read_bytes()
        _, records = read_dbc(data, record_cls)

        return cls(
            dbc_name=dbc_name,
            record_cls=record_cls,
            records=records,
            source_bytes=data,
        )

    @classmethod
    def from_bytes(cls, data: bytes, dbc_name: str) -> DbcFile:
        """Read a DBC file from raw bytes with an explicit template name.

        Args:
            data: The complete raw DBC file contents.
            dbc_name: The DBC name to look up the template (e.g. "Spell").

        Returns:
            A DbcFile instance with the parsed records.

        Raises:
            KeyError: If no template is registered for the name.
            ValueError: If the data is malformed.
        """
        record_cls = get_template(dbc_name)
        _, records = read_dbc(data, record_cls)
        return cls(
            dbc_name=dbc_name,
            record_cls=record_cls,
            records=records,
            source_bytes=data,
        )

    @classmethod
    def create(cls, dbc_name: str) -> DbcFile:
        """Create a new empty DBC file for the given template.

        Args:
            dbc_name: The DBC name (e.g. "Spell", "Map", "CharTitles").

        Returns:
            A DbcFile instance with an empty record list.

        Raises:
            KeyError: If no template is registered for the name.
        """
        record_cls = get_template(dbc_name)
        return cls(dbc_name=dbc_name, record_cls=record_cls, records=[])

    def to_bytes(self) -> bytes:
        """Serialize this DBC file to raw bytes.

        Returns:
            The complete DBC file as raw bytes.
        """
        if (
            self._source_bytes is not None
            and self._source_records_snapshot is not None
            and self.records == self._source_records_snapshot
        ):
            return self._source_bytes

        data = write_dbc(self.records, self.record_cls)
        self._source_bytes = data
        self._source_records_snapshot = deepcopy(self.records)
        return data

    def write(self, path: str | Path) -> None:
        """Write this DBC file to disk.

        Args:
            path: Destination file path.
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.to_bytes())

    def __len__(self) -> int:
        """Return the number of records."""
        return len(self.records)

    def upsert(self, record: Any) -> None:
        """Insert a record or replace an existing one with the same id.

        Looks for an existing record whose ``id`` field matches
        ``record.id``.  If found, it is replaced in-place (preserving list
        order).  If not found, the record is appended.

        Args:
            record: A record dataclass instance whose type matches
                ``self.record_cls``.  Must have an ``id`` field.
        """
        for i, existing in enumerate(self.records):
            if existing.id == record.id:
                self.records[i] = record
                return
        self.records.append(record)

    def sort_by_id(self) -> None:
        """Sort records in-place by their ``id`` field in ascending order."""
        self.records.sort(key=lambda r: r.id)

    def __repr__(self) -> str:
        return (
            f"DbcFile(dbc_name={self.dbc_name!r}, "
            f"record_count={len(self.records)})"
        )
