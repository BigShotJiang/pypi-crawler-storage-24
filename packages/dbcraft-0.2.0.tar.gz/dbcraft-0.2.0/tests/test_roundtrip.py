"""Integration roundtrip tests for DbcFile with real templates.

These tests exercise the full pipeline:
  DbcFile.create -> populate records -> write to disk -> read back -> verify

Each template is tested with multiple records, localized strings, and
byte-level fidelity checks (write -> to_bytes -> from_bytes -> compare).
"""

from __future__ import annotations

import struct
from pathlib import Path

import pytest

from dbcraft.core.header import DBC_MAGIC_INT, HEADER_SIZE
from dbcraft.core.types import LocalizedString
from dbcraft.dbc_file import DbcFile
from dbcraft.templates.base import get_field_count, get_record_size, get_template

# Import templates to ensure registration
from dbcraft.templates.char_titles import CharTitlesRecord
from dbcraft.templates.chr_classes import ChrClassesRecord
from dbcraft.templates.chr_races import ChrRacesRecord
from dbcraft.templates.item import ItemRecord
from dbcraft.templates.item_display_info import ItemDisplayInfoRecord
from dbcraft.templates.item_extended_cost import ItemExtendedCostRecord
from dbcraft.templates.map import MapRecord
from dbcraft.templates.skill_line import SkillLineRecord
from dbcraft.templates.skill_line_ability import SkillLineAbilityRecord
from dbcraft.templates.skill_race_class_info import SkillRaceClassInfoRecord
from dbcraft.templates.skill_tiers import SkillTiersRecord
from dbcraft.templates.spell import SpellRecord
from dbcraft.templates.spell_icon import SpellIconRecord


# ── Helpers ──────────────────────────────────────────────────────────────


def _make_loc(en_us: str = "", de_de: str = "", flags: int = 0) -> LocalizedString:
    """Create a LocalizedString with optional en_us/de_de values."""
    loc = LocalizedString(flags=flags)
    if en_us:
        loc.en_us = en_us
    if de_de:
        loc.de_de = de_de
    return loc


def _parse_header(data: bytes):
    """Parse a DBC header and return (magic, rec_count, fld_count, rec_size, sb_size)."""
    return struct.unpack_from("<5I", data)


# ── CharTitles roundtrip ────────────────────────────────────────────────


class TestCharTitlesRoundtrip:
    def test_single_record_file_io(self, tmp_path):
        dbc = DbcFile.create("CharTitles")
        dbc.records.append(CharTitlesRecord(
            id=1, condition_id=0,
            name_lang=_make_loc("Private %s"),
            name1_lang=_make_loc("Private %s"),
            mask_id=1,
        ))

        path = tmp_path / "CharTitles.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 1
        assert loaded.records[0].id == 1
        assert loaded.records[0].name_lang.en_us == "Private %s"
        assert loaded.records[0].name1_lang.en_us == "Private %s"
        assert loaded.records[0].mask_id == 1

    def test_multiple_records(self, tmp_path):
        dbc = DbcFile.create("CharTitles")
        for i in range(5):
            dbc.records.append(CharTitlesRecord(
                id=i + 1, condition_id=0,
                name_lang=_make_loc(f"Title {i + 1}"),
                name1_lang=_make_loc(f"Title {i + 1}"),
                mask_id=i,
            ))

        path = tmp_path / "CharTitles.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 5
        for i in range(5):
            assert loaded.records[i].id == i + 1
            assert loaded.records[i].name_lang.en_us == f"Title {i + 1}"
            assert loaded.records[i].mask_id == i

    def test_byte_fidelity(self):
        """to_bytes -> from_bytes produces identical bytes."""
        dbc = DbcFile.create("CharTitles")
        dbc.records.append(CharTitlesRecord(
            id=42, condition_id=5,
            name_lang=_make_loc("Champion %s", "Champion %s"),
            name1_lang=_make_loc("Champion %s", "Championne %s"),
            mask_id=10,
        ))

        data1 = dbc.to_bytes()
        loaded = DbcFile.from_bytes(data1, "CharTitles")
        data2 = loaded.to_bytes()

        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("CharTitles")
        dbc.records.append(CharTitlesRecord(
            id=1, condition_id=0,
            name_lang=_make_loc(), name1_lang=_make_loc(),
            mask_id=0,
        ))

        data = dbc.to_bytes()
        magic, rec_count, fld_count, rec_size, sb_size = _parse_header(data)

        assert magic == DBC_MAGIC_INT
        assert rec_count == 1
        assert fld_count == 37
        assert rec_size == 37 * 4


# ── Map roundtrip ────────────────────────────────────────────────────────


class TestMapRoundtrip:
    def _make_map(self, id: int, name: str, directory: str, **kwargs) -> MapRecord:
        defaults = dict(
            id=id, directory=directory, instance_type=0, flags=0,
            p_v_p=0,
            map_name_lang=_make_loc(name), area_table_id=0,
            map_description0_lang=_make_loc(), map_description1_lang=_make_loc(),
            loading_screen_id=0, minimap_icon_scale=1.0,
            corpse_map_id=-1, corpse_0=0.0, corpse_1=0.0,
            time_of_day_override=-1, expansion_id=0,
            raid_offset=0, max_players=0,
        )
        defaults.update(kwargs)
        return MapRecord(**defaults)

    def test_file_io_with_strings(self, tmp_path):
        dbc = DbcFile.create("Map")
        dbc.records.append(self._make_map(
            0, "Eastern Kingdoms", "Azeroth",
            map_description0_lang=_make_loc("Alliance lands"),
            map_description1_lang=_make_loc("Horde territory"),
        ))
        dbc.records.append(self._make_map(
            1, "Kalimdor", "Kalimdor",
            expansion_id=0, max_players=0,
        ))

        path = tmp_path / "Map.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 2
        assert loaded.records[0].directory == "Azeroth"
        assert loaded.records[0].map_name_lang.en_us == "Eastern Kingdoms"
        assert loaded.records[0].map_description0_lang.en_us == "Alliance lands"
        assert loaded.records[1].directory == "Kalimdor"
        assert loaded.records[1].map_name_lang.en_us == "Kalimdor"

    def test_float_fields_preserved(self, tmp_path):
        dbc = DbcFile.create("Map")
        dbc.records.append(self._make_map(
            449, "Utgarde Pinnacle", "UtgardePinnacle",
            instance_type=1,
            minimap_icon_scale=0.65,
            corpse_map_id=571, corpse_0=1234.5, corpse_1=-678.25,
            expansion_id=2, max_players=5,
        ))

        path = tmp_path / "Map.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        r = loaded.records[0]
        assert r.id == 449
        assert abs(r.minimap_icon_scale - 0.65) < 1e-5
        assert r.corpse_map_id == 571
        assert abs(r.corpse_0 - 1234.5) < 1e-5
        assert abs(r.corpse_1 - (-678.25)) < 1e-5

    def test_byte_fidelity(self):
        dbc = DbcFile.create("Map")
        dbc.records.append(self._make_map(0, "Test", "TestDir"))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "Map").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("Map")
        dbc.records.append(self._make_map(0, "X", "Y"))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 66
        assert rec_size == 66 * 4


# ── ChrRaces roundtrip ──────────────────────────────────────────────────


class TestChrRacesRoundtrip:
    def _make_race(self, id: int, race_name: str, prefix: str, **kwargs) -> ChrRacesRecord:
        defaults = dict(
            id=id, flags=0, faction_id=1, exploration_sound_id=0,
            male_display_id=49, female_display_id=50,
            client_prefix=prefix,
            base_language=7, creature_type=7,
            res_sickness_spell_id=15007, splash_sound_id=1096,
            client_file_string=race_name, cinematic_sequence_id=0,
            alliance=0,
            name_lang=_make_loc(race_name), name_female_lang=_make_loc(), name_male_lang=_make_loc(),
            facial_hair_customization_0="", facial_hair_customization_1="",
            hair_customization="", required_expansion=0,
        )
        defaults.update(kwargs)
        return ChrRacesRecord(**defaults)

    def test_file_io_all_races(self, tmp_path):
        races = [
            (1, "Human", "Hu"),
            (2, "Orc", "Or"),
            (3, "Dwarf", "Dw"),
            (4, "Night Elf", "NE"),
        ]
        dbc = DbcFile.create("ChrRaces")
        for id_, name, prefix in races:
            dbc.records.append(self._make_race(id_, name, prefix))

        path = tmp_path / "ChrRaces.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 4
        for i, (id_, name, prefix) in enumerate(races):
            assert loaded.records[i].id == id_
            assert loaded.records[i].name_lang.en_us == name
            assert loaded.records[i].client_prefix == prefix

    def test_localized_race_names(self, tmp_path):
        dbc = DbcFile.create("ChrRaces")
        loc_name = _make_loc("Blood Elf", "Blutelf")
        dbc.records.append(self._make_race(
            10, "Blood Elf", "BE",
            name_lang=loc_name, required_expansion=1,
        ))

        path = tmp_path / "ChrRaces.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert loaded.records[0].name_lang.en_us == "Blood Elf"
        assert loaded.records[0].name_lang.de_de == "Blutelf"
        assert loaded.records[0].required_expansion == 1

    def test_byte_fidelity(self):
        dbc = DbcFile.create("ChrRaces")
        dbc.records.append(self._make_race(1, "Human", "Hu"))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "ChrRaces").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("ChrRaces")
        dbc.records.append(self._make_race(1, "X", "X"))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 69
        assert rec_size == 69 * 4


# ── ChrClasses roundtrip ────────────────────────────────────────────────


class TestChrClassesRoundtrip:
    def _make_class(self, id: int, class_name: str, filename: str, **kwargs) -> ChrClassesRecord:
        defaults = dict(
            id=id, damage_bonus_stat=0, display_power=0,
            pet_name_token="PET",
            name_lang=_make_loc(class_name), name_female_lang=_make_loc(), name_male_lang=_make_loc(),
            filename=filename, spell_class_set=0,
            flags=0, cinematic_sequence_id=0, required_expansion=0,
        )
        defaults.update(kwargs)
        return ChrClassesRecord(**defaults)

    def test_file_io_multiple_classes(self, tmp_path):
        classes = [
            (1, "Warrior", "WARRIOR", 1, 0),   # display_power=Rage
            (2, "Paladin", "PALADIN", 0, 0),   # display_power=Mana
            (3, "Hunter", "HUNTER", 0, 0),
            (6, "Death Knight", "DEATHKNIGHT", 6, 2),  # display_power=Runes, exp=WotLK
        ]
        dbc = DbcFile.create("ChrClasses")
        for id_, name, fname, ptype, exp in classes:
            dbc.records.append(self._make_class(
                id_, name, fname,
                display_power=ptype, required_expansion=exp,
            ))

        path = tmp_path / "ChrClasses.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 4
        assert loaded.records[0].name_lang.en_us == "Warrior"
        assert loaded.records[0].filename == "WARRIOR"
        assert loaded.records[0].display_power == 1
        assert loaded.records[3].name_lang.en_us == "Death Knight"
        assert loaded.records[3].required_expansion == 2

    def test_localized_class_names(self, tmp_path):
        dbc = DbcFile.create("ChrClasses")
        loc_name = _make_loc("Mage", "Magier")
        loc_name_f = _make_loc("Mage", "Magierin")
        dbc.records.append(self._make_class(
            8, "Mage", "MAGE",
            name_lang=loc_name, name_female_lang=loc_name_f, spell_class_set=3,
        ))

        path = tmp_path / "ChrClasses.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert loaded.records[0].name_lang.en_us == "Mage"
        assert loaded.records[0].name_lang.de_de == "Magier"
        assert loaded.records[0].name_female_lang.en_us == "Mage"
        assert loaded.records[0].name_female_lang.de_de == "Magierin"

    def test_byte_fidelity(self):
        dbc = DbcFile.create("ChrClasses")
        dbc.records.append(self._make_class(1, "Test", "TEST"))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "ChrClasses").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("ChrClasses")
        dbc.records.append(self._make_class(1, "X", "X"))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 60
        assert rec_size == 60 * 4


# ── Spell roundtrip ─────────────────────────────────────────────────────


class TestSpellRoundtrip:
    def _make_spell(self, **kwargs) -> SpellRecord:
        """Create a SpellRecord with sensible zero defaults."""
        defaults = dict(
            id=1, category=0, dispel_type=0, mechanic=0,
            attributes=0, attributes_ex=0, attributes_ex_b=0,
            attributes_ex_c=0, attributes_ex_d=0, attributes_ex_e=0,
            attributes_ex_f=0, attributes_ex_g=0,
            shapeshift_mask_0=0, shapeshift_mask_1=0, shapeshift_exclude_0=0, shapeshift_exclude_1=0,
            targets=0, target_creature_type=0, requires_spell_focus=0,
            facing_caster_flags=0,
            caster_aura_state=0, target_aura_state=0,
            exclude_caster_aura_state=0, exclude_target_aura_state=0,
            caster_aura_spell=0, target_aura_spell=0,
            exclude_caster_aura_spell=0, exclude_target_aura_spell=0,
            casting_time_index=1, recovery_time=0,
            category_recovery_time=0,
            interrupt_flags=0, aura_interrupt_flags=0,
            channel_interrupt_flags=0,
            proc_type_mask=0, proc_chance=0, proc_charges=0,
            max_level=0, base_level=1, spell_level=1,
            duration_index=0, power_type=0, mana_cost=0,
            mana_cost_per_level=0, mana_per_second=0,
            mana_per_second_per_level=0, range_index=1,
            speed=0.0, modal_next_spell=0, cumulative_aura=0,
            totem_0=0, totem_1=0,
            reagent_0=0, reagent_1=0, reagent_2=0, reagent_3=0,
            reagent_4=0, reagent_5=0, reagent_6=0, reagent_7=0,
            reagent_count_0=0, reagent_count_1=0, reagent_count_2=0,
            reagent_count_3=0, reagent_count_4=0, reagent_count_5=0,
            reagent_count_6=0, reagent_count_7=0,
            equipped_item_class=-1, equipped_item_subclass=0,
            equipped_item_inv_types=0,
            effect_0=0, effect_1=0, effect_2=0,
            effect_die_sides_0=0, effect_die_sides_1=0,
            effect_die_sides_2=0,
            effect_real_points_per_level_0=0.0,
            effect_real_points_per_level_1=0.0,
            effect_real_points_per_level_2=0.0,
            effect_base_points_0=0, effect_base_points_1=0,
            effect_base_points_2=0,
            effect_mechanic_0=0, effect_mechanic_1=0,
            effect_mechanic_2=0,
            implicit_target_a_0=0, implicit_target_a_1=0,
            implicit_target_a_2=0,
            implicit_target_b_0=0, implicit_target_b_1=0,
            implicit_target_b_2=0,
            effect_radius_index_0=0, effect_radius_index_1=0,
            effect_radius_index_2=0,
            effect_aura_0=0, effect_aura_1=0,
            effect_aura_2=0,
            effect_aura_period_0=0, effect_aura_period_1=0,
            effect_aura_period_2=0,
            effect_amplitude_0=0.0, effect_amplitude_1=0.0,
            effect_amplitude_2=0.0,
            effect_chain_targets_0=0, effect_chain_targets_1=0,
            effect_chain_targets_2=0,
            effect_item_type_0=0, effect_item_type_1=0,
            effect_item_type_2=0,
            effect_misc_value_0=0, effect_misc_value_1=0,
            effect_misc_value_2=0,
            effect_misc_value_b_0=0, effect_misc_value_b_1=0,
            effect_misc_value_b_2=0,
            effect_trigger_spell_0=0, effect_trigger_spell_1=0,
            effect_trigger_spell_2=0,
            effect_points_per_combo_0=0.0,
            effect_points_per_combo_1=0.0,
            effect_points_per_combo_2=0.0,
            effect_spell_class_mask_a_0=0, effect_spell_class_mask_a_1=0,
            effect_spell_class_mask_a_2=0,
            effect_spell_class_mask_b_0=0, effect_spell_class_mask_b_1=0,
            effect_spell_class_mask_b_2=0,
            effect_spell_class_mask_c_0=0, effect_spell_class_mask_c_1=0,
            effect_spell_class_mask_c_2=0,
            spell_visual_id_0=0, spell_visual_id_1=0,
            spell_icon_id=0, active_icon_id=0, spell_priority=0,
            name_lang=LocalizedString(),
            name_subtext_lang=LocalizedString(),
            description_lang=LocalizedString(),
            aura_description_lang=LocalizedString(),
            mana_cost_pct=0,
            start_recovery_category=0, start_recovery_time=0,
            max_target_level=0,
            spell_class_set=0, spell_class_mask_0=0,
            spell_class_mask_1=0, spell_class_mask_2=0,
            max_targets=0, defense_type=0,
            prevention_type=0, stance_bar_order=0,
            effect_chain_amplitude_0=0.0, effect_chain_amplitude_1=0.0,
            effect_chain_amplitude_2=0.0,
            min_faction_id=0, min_reputation=0,
            required_aura_vision=0,
            required_totem_category_id_0=0, required_totem_category_id_1=0,
            required_areas_id=0, school_mask=0,
            rune_cost_id=0, spell_missile_id=0,
            power_display_id=0,
            effect_bonus_coefficient_0=0.0, effect_bonus_coefficient_1=0.0,
            effect_bonus_coefficient_2=0.0,
            description_variables_id=0, difficulty=0,
        )
        defaults.update(kwargs)
        return SpellRecord(**defaults)

    def test_file_io_single_spell(self, tmp_path):
        name = _make_loc("Fireball", "Feuerball")
        desc = _make_loc("Hurls a fiery ball that causes 148 to 195 Fire damage.")
        tip = _make_loc("Deals fire damage to a single target.")
        spell = self._make_spell(
            id=133,
            name_lang=name,
            description_lang=desc,
            aura_description_lang=tip,
            mana_cost=200,
            speed=24.0,
            effect_0=6,
            effect_base_points_0=147,
            effect_die_sides_0=48,
            school_mask=4,
            casting_time_index=4,
        )

        dbc = DbcFile.create("Spell")
        dbc.records.append(spell)

        path = tmp_path / "Spell.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 1
        r = loaded.records[0]
        assert r.id == 133
        assert r.name_lang.en_us == "Fireball"
        assert r.name_lang.de_de == "Feuerball"
        assert r.description_lang.en_us.startswith("Hurls a fiery ball")
        assert r.mana_cost == 200
        assert abs(r.speed - 24.0) < 1e-5
        assert r.school_mask == 4

    def test_file_io_multiple_spells(self, tmp_path):
        spells = []
        for i in range(10):
            s = self._make_spell(id=i + 1, mana_cost=(i + 1) * 10)
            s.name_lang.en_us = f"Spell {i + 1}"
            spells.append(s)

        dbc = DbcFile.create("Spell")
        dbc.records = spells

        path = tmp_path / "Spell.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 10
        for i in range(10):
            assert loaded.records[i].id == i + 1
            assert loaded.records[i].name_lang.en_us == f"Spell {i + 1}"
            assert loaded.records[i].mana_cost == (i + 1) * 10

    def test_byte_fidelity(self):
        spell = self._make_spell(
            id=100,
            name_lang=_make_loc("TestSpell"),
            description_lang=_make_loc("A test description."),
            mana_cost=50,
        )
        dbc = DbcFile.create("Spell")
        dbc.records.append(spell)

        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "Spell").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("Spell")
        dbc.records.append(self._make_spell(id=1))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 234
        assert rec_size == 234 * 4


# ── Cross-template integration ──────────────────────────────────────────


class TestCrossTemplateIntegration:
    """Tests that verify independence between templates and general behavior."""

    def test_empty_files_all_templates(self, tmp_path):
        """All templates produce valid empty DBC files."""
        for name, fld_count in [
            ("CharTitles", 37),
            ("Map", 66),
            ("ChrRaces", 69),
            ("ChrClasses", 60),
            ("Spell", 234),
            ("Item", 8),
            ("ItemDisplayInfo", 25),
            ("ItemExtendedCost", 16),
            ("SkillLine", 56),
            ("SkillLineAbility", 14),
            ("SkillRaceClassInfo", 8),
            ("SkillTiers", 33),
            ("SpellIcon", 2),
        ]:
            dbc = DbcFile.create(name)
            data = dbc.to_bytes()
            magic, rec_count, fc, rec_size, sb_size = _parse_header(data)
            assert magic == DBC_MAGIC_INT
            assert rec_count == 0
            assert fc == fld_count
            assert rec_size == get_record_size(get_template(name))
            assert sb_size == 1  # just the null byte
            assert len(data) == HEADER_SIZE + sb_size

    def test_write_read_preserves_template_name(self, tmp_path):
        """DbcFile.read auto-detects template name from filename."""
        for name in [
            "CharTitles", "Map", "ChrRaces", "ChrClasses", "Spell",
            "Item", "ItemDisplayInfo", "ItemExtendedCost",
            "SkillLine", "SkillLineAbility", "SkillRaceClassInfo",
            "SkillTiers", "SpellIcon",
        ]:
            dbc = DbcFile.create(name)
            path = tmp_path / f"{name}.dbc"
            dbc.write(path)
            loaded = DbcFile.read(path)
            assert loaded.dbc_name == name

    def test_repr_all_templates(self):
        """repr works for all template types."""
        for name in [
            "CharTitles", "Map", "ChrRaces", "ChrClasses", "Spell",
            "Item", "ItemDisplayInfo", "ItemExtendedCost",
            "SkillLine", "SkillLineAbility", "SkillRaceClassInfo",
            "SkillTiers", "SpellIcon",
        ]:
            dbc = DbcFile.create(name)
            r = repr(dbc)
            assert name in r
            assert "record_count=0" in r

    def test_string_deduplication_across_records(self, tmp_path):
        """Shared strings across records should be deduplicated in the string block."""
        dbc = DbcFile.create("ChrClasses")
        # Both classes share the pet_name_token "PET" and filename
        for i in range(3):
            rec = ChrClassesRecord(
                id=i + 1, damage_bonus_stat=0, display_power=0,
                pet_name_token="PET",
                name_lang=_make_loc(f"Class {i + 1}"),
                name_female_lang=_make_loc(),
                name_male_lang=_make_loc(),
                filename="SHARED_FILE",
                spell_class_set=0, flags=0,
                cinematic_sequence_id=0, required_expansion=0,
            )
            dbc.records.append(rec)

        data = dbc.to_bytes()
        # "PET" and "SHARED_FILE" should each appear exactly once in the string block
        string_block = data[HEADER_SIZE + 3 * 60 * 4:]
        assert string_block.count(b"PET\x00") == 1
        assert string_block.count(b"SHARED_FILE\x00") == 1

        # Verify roundtrip
        loaded = DbcFile.from_bytes(data, "ChrClasses")
        assert len(loaded) == 3
        for r in loaded.records:
            assert r.pet_name_token == "PET"
            assert r.filename == "SHARED_FILE"

    def test_file_size_consistency(self):
        """File size = header + (record_count * record_size) + string_block_size."""
        dbc = DbcFile.create("Map")
        dbc.records.append(MapRecord(
            id=0, directory="Test", instance_type=0, flags=0,
            p_v_p=0,
            map_name_lang=_make_loc("Test"), area_table_id=0,
            map_description0_lang=_make_loc(),
            map_description1_lang=_make_loc(),
            loading_screen_id=0, minimap_icon_scale=1.0,
            corpse_map_id=-1, corpse_0=0.0, corpse_1=0.0,
            time_of_day_override=-1, expansion_id=0,
            raid_offset=0, max_players=0,
        ))

        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, sb_size = _parse_header(data)
        expected_size = HEADER_SIZE + (rec_count * rec_size) + sb_size
        assert len(data) == expected_size


# ── Item roundtrip ───────────────────────────────────────────────────────


class TestItemRoundtrip:
    def _make_item(self, id: int, **kwargs) -> ItemRecord:
        defaults = dict(
            id=id,
            class_id=4,
            subclass_id=0,
            sound_override_subclass_id=-1,
            material=-1,
            display_info_id=60202,
            inventory_type=1,
            sheathe_type=0,
        )
        defaults.update(kwargs)
        return ItemRecord(**defaults)

    def test_single_record_file_io(self, tmp_path):
        dbc = DbcFile.create("Item")
        dbc.records.append(self._make_item(12345, class_id=2, subclass_id=7))

        path = tmp_path / "Item.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 1
        r = loaded.records[0]
        assert r.id == 12345
        assert r.class_id == 2
        assert r.subclass_id == 7
        assert r.sound_override_subclass_id == -1
        assert r.material == -1

    def test_multiple_records(self, tmp_path):
        dbc = DbcFile.create("Item")
        for i in range(5):
            dbc.records.append(self._make_item(i + 1, inventory_type=i))

        path = tmp_path / "Item.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 5
        for i in range(5):
            assert loaded.records[i].id == i + 1
            assert loaded.records[i].inventory_type == i

    def test_byte_fidelity(self):
        dbc = DbcFile.create("Item")
        dbc.records.append(self._make_item(99999, class_id=2, material=1))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "Item").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("Item")
        dbc.records.append(self._make_item(1))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 8
        assert rec_size == 8 * 4


# ── ItemDisplayInfo roundtrip ─────────────────────────────────────────────


class TestItemDisplayInfoRoundtrip:
    def _make_record(self, id: int, icon: str = "", **kwargs) -> ItemDisplayInfoRecord:
        defaults = dict(
            id=id,
            model_name_0="", model_name_1="",
            model_texture_0="", model_texture_1="",
            inventory_icon_0=icon, inventory_icon_1="",
            geoset_group_0=0, geoset_group_1=0, geoset_group_2=0,
            flags=0, spell_visual_id=0, group_sound_index=0,
            helmet_geoset_vis_id_0=0, helmet_geoset_vis_id_1=0,
            texture_0="", texture_1="",
            texture_2="", texture_3="",
            texture_4="", texture_5="",
            texture_6="", texture_7="",
            item_visual=0, particle_color_id=0,
        )
        defaults.update(kwargs)
        return ItemDisplayInfoRecord(**defaults)

    def test_single_record_file_io(self, tmp_path):
        dbc = DbcFile.create("ItemDisplayInfo")
        dbc.records.append(self._make_record(60202, icon="INV_Misc_Coin_01"))

        path = tmp_path / "ItemDisplayInfo.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 1
        assert loaded.records[0].id == 60202
        assert loaded.records[0].inventory_icon_0 == "INV_Misc_Coin_01"

    def test_multiple_records(self, tmp_path):
        dbc = DbcFile.create("ItemDisplayInfo")
        icons = ["INV_Sword_01", "INV_Axe_01", "INV_Staff_01"]
        for i, icon in enumerate(icons):
            dbc.records.append(self._make_record(i + 1, icon=icon))

        path = tmp_path / "ItemDisplayInfo.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 3
        for i, icon in enumerate(icons):
            assert loaded.records[i].inventory_icon_0 == icon

    def test_byte_fidelity(self):
        dbc = DbcFile.create("ItemDisplayInfo")
        dbc.records.append(self._make_record(1, icon="INV_Custom_Test", flags=4))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "ItemDisplayInfo").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("ItemDisplayInfo")
        dbc.records.append(self._make_record(1))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 25
        assert rec_size == 25 * 4


# ── ItemExtendedCost roundtrip ────────────────────────────────────────────


class TestItemExtendedCostRoundtrip:
    def _make_record(self, id: int, **kwargs) -> ItemExtendedCostRecord:
        defaults = dict(
            id=id, honor_points=0, arena_points=0, arena_bracket=0,
            item_id_0=0, item_id_1=0, item_id_2=0,
            item_id_3=0, item_id_4=0,
            item_count_0=0, item_count_1=0, item_count_2=0,
            item_count_3=0, item_count_4=0,
            required_arena_rating=0, item_purchase_group=0,
        )
        defaults.update(kwargs)
        return ItemExtendedCostRecord(**defaults)

    def test_single_record_file_io(self, tmp_path):
        dbc = DbcFile.create("ItemExtendedCost")
        dbc.records.append(self._make_record(1001, honor_points=500))

        path = tmp_path / "ItemExtendedCost.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 1
        assert loaded.records[0].id == 1001
        assert loaded.records[0].honor_points == 500

    def test_multiple_records(self, tmp_path):
        dbc = DbcFile.create("ItemExtendedCost")
        for i in range(4):
            dbc.records.append(self._make_record(i + 1, arena_points=(i + 1) * 50))

        path = tmp_path / "ItemExtendedCost.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 4
        for i in range(4):
            assert loaded.records[i].arena_points == (i + 1) * 50

    def test_byte_fidelity(self):
        dbc = DbcFile.create("ItemExtendedCost")
        dbc.records.append(self._make_record(
            2002, arena_points=150, item_id_0=40752,
            item_count_0=2, required_arena_rating=1800,
        ))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "ItemExtendedCost").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("ItemExtendedCost")
        dbc.records.append(self._make_record(1))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 16
        assert rec_size == 16 * 4


# ── SkillLine roundtrip ───────────────────────────────────────────────────


class TestSkillLineRoundtrip:
    def _make_record(self, id: int, name: str, **kwargs) -> SkillLineRecord:
        loc_name = LocalizedString()
        loc_name.en_us = name
        defaults = dict(
            id=id, category_id=11, skill_costs_id=0,
            display_name_lang=loc_name,
            description_lang=LocalizedString(),
            spell_icon_id=0,
            alternate_verb_lang=LocalizedString(),
            can_link=1,
        )
        defaults.update(kwargs)
        return SkillLineRecord(**defaults)

    def test_single_record_file_io(self, tmp_path):
        dbc = DbcFile.create("SkillLine")
        dbc.records.append(self._make_record(776, "Runeforging", spell_icon_id=1376))

        path = tmp_path / "SkillLine.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 1
        r = loaded.records[0]
        assert r.id == 776
        assert r.display_name_lang.en_us == "Runeforging"
        assert r.spell_icon_id == 1376

    def test_localized_names(self, tmp_path):
        loc = _make_loc("Blacksmithing", "Schmiedekunst")
        dbc = DbcFile.create("SkillLine")
        dbc.records.append(SkillLineRecord(
            id=164, category_id=11, skill_costs_id=0,
            display_name_lang=loc,
            description_lang=LocalizedString(),
            spell_icon_id=45,
            alternate_verb_lang=LocalizedString(),
            can_link=1,
        ))

        path = tmp_path / "SkillLine.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert loaded.records[0].display_name_lang.en_us == "Blacksmithing"
        assert loaded.records[0].display_name_lang.de_de == "Schmiedekunst"

    def test_byte_fidelity(self):
        dbc = DbcFile.create("SkillLine")
        dbc.records.append(self._make_record(1, "TestSkill"))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "SkillLine").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("SkillLine")
        dbc.records.append(self._make_record(1, "X"))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 56
        assert rec_size == 56 * 4


# ── SkillLineAbility roundtrip ────────────────────────────────────────────


class TestSkillLineAbilityRoundtrip:
    def _make_record(self, id: int, spell: int, **kwargs) -> SkillLineAbilityRecord:
        defaults = dict(
            id=id, skill_line=776, spell=spell,
            race_mask=0, class_mask=0,
            exclude_race=0, exclude_class=0,
            min_skill_line_rank=0,
            superceded_by_spell=0, acquire_method=0,
            trivial_skill_line_rank_high=0, trivial_skill_line_rank_low=0,
            character_points_0=0, character_points_1=0,
        )
        defaults.update(kwargs)
        return SkillLineAbilityRecord(**defaults)

    def test_single_record_file_io(self, tmp_path):
        dbc = DbcFile.create("SkillLineAbility")
        dbc.records.append(self._make_record(
            50001, 54442, acquire_method=1,
        ))

        path = tmp_path / "SkillLineAbility.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 1
        r = loaded.records[0]
        assert r.id == 50001
        assert r.spell == 54442
        assert r.acquire_method == 1

    def test_multiple_records(self, tmp_path):
        dbc = DbcFile.create("SkillLineAbility")
        for i in range(3):
            dbc.records.append(self._make_record(
                i + 1, 50000 + i,
                min_skill_line_rank=i * 75,
            ))

        path = tmp_path / "SkillLineAbility.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 3
        for i in range(3):
            assert loaded.records[i].spell == 50000 + i
            assert loaded.records[i].min_skill_line_rank == i * 75

    def test_byte_fidelity(self):
        dbc = DbcFile.create("SkillLineAbility")
        dbc.records.append(self._make_record(1, 100, race_mask=0x7FF, class_mask=0x5FF))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "SkillLineAbility").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("SkillLineAbility")
        dbc.records.append(self._make_record(1, 1))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 14
        assert rec_size == 14 * 4


# ── SkillRaceClassInfo roundtrip ──────────────────────────────────────────


class TestSkillRaceClassInfoRoundtrip:
    def _make_record(self, id: int, skill_id: int, **kwargs) -> SkillRaceClassInfoRecord:
        defaults = dict(
            id=id, skill_id=skill_id,
            race_mask=0x7FF, class_mask=0x5FF,
            flags=0xA0, min_level=0,
            skill_tier_id=0, skill_cost_index=0,
        )
        defaults.update(kwargs)
        return SkillRaceClassInfoRecord(**defaults)

    def test_single_record_file_io(self, tmp_path):
        dbc = DbcFile.create("SkillRaceClassInfo")
        dbc.records.append(self._make_record(1, 776, skill_tier_id=100))

        path = tmp_path / "SkillRaceClassInfo.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 1
        r = loaded.records[0]
        assert r.id == 1
        assert r.skill_id == 776
        assert r.skill_tier_id == 100

    def test_multiple_records(self, tmp_path):
        dbc = DbcFile.create("SkillRaceClassInfo")
        for i in range(3):
            dbc.records.append(self._make_record(i + 1, 100 + i))

        path = tmp_path / "SkillRaceClassInfo.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 3
        for i in range(3):
            assert loaded.records[i].skill_id == 100 + i

    def test_byte_fidelity(self):
        dbc = DbcFile.create("SkillRaceClassInfo")
        dbc.records.append(self._make_record(42, 186, flags=0xA0, min_level=5))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "SkillRaceClassInfo").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("SkillRaceClassInfo")
        dbc.records.append(self._make_record(1, 1))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 8
        assert rec_size == 8 * 4


# ── SkillTiers roundtrip ──────────────────────────────────────────────────


class TestSkillTiersRoundtrip:
    def _make_record(self, id: int, values: list[int] | None = None, **kwargs) -> SkillTiersRecord:
        v = (values or []) + [0] * 16
        defaults = dict(
            id=id,
            cost_0=0, cost_1=0, cost_2=0, cost_3=0,
            cost_4=0, cost_5=0, cost_6=0, cost_7=0,
            cost_8=0, cost_9=0, cost_10=0, cost_11=0,
            cost_12=0, cost_13=0, cost_14=0, cost_15=0,
            value_0=v[0], value_1=v[1], value_2=v[2], value_3=v[3],
            value_4=v[4], value_5=v[5], value_6=v[6], value_7=v[7],
            value_8=v[8], value_9=v[9], value_10=v[10], value_11=v[11],
            value_12=v[12], value_13=v[13], value_14=v[14], value_15=v[15],
        )
        defaults.update(kwargs)
        return SkillTiersRecord(**defaults)

    def test_single_record_file_io(self, tmp_path):
        dbc = DbcFile.create("SkillTiers")
        dbc.records.append(self._make_record(
            100, [75, 150, 225, 300, 375, 450],
        ))

        path = tmp_path / "SkillTiers.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 1
        r = loaded.records[0]
        assert r.id == 100
        assert r.value_0 == 75
        assert r.value_5 == 450
        assert r.value_6 == 0

    def test_cost_fields_preserved(self, tmp_path):
        dbc = DbcFile.create("SkillTiers")
        rec = self._make_record(200, [75, 150, 225, 300, 375, 450],
                                cost_0=1, cost_1=1, cost_2=1,
                                cost_3=1, cost_4=1, cost_5=1)
        dbc.records.append(rec)

        path = tmp_path / "SkillTiers.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        r = loaded.records[0]
        assert r.cost_0 == 1
        assert r.cost_5 == 1
        assert r.cost_6 == 0

    def test_byte_fidelity(self):
        dbc = DbcFile.create("SkillTiers")
        dbc.records.append(self._make_record(1, [75, 150, 225]))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "SkillTiers").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("SkillTiers")
        dbc.records.append(self._make_record(1))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 33
        assert rec_size == 33 * 4


# ── SpellIcon roundtrip ───────────────────────────────────────────────────


class TestSpellIconRoundtrip:
    def test_single_record_file_io(self, tmp_path):
        dbc = DbcFile.create("SpellIcon")
        dbc.records.append(SpellIconRecord(
            id=1376,
            texture_filename=r"Interface\Icons\Spell_DeathKnight_ClassSymbol",
        ))

        path = tmp_path / "SpellIcon.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 1
        r = loaded.records[0]
        assert r.id == 1376
        assert r.texture_filename == r"Interface\Icons\Spell_DeathKnight_ClassSymbol"

    def test_multiple_records(self, tmp_path):
        dbc = DbcFile.create("SpellIcon")
        icons = [
            (1, r"Interface\Icons\Spell_Holy_BlessingOfProtection"),
            (2, r"Interface\Icons\Spell_Fire_Fireball"),
            (3, r"Interface\Icons\INV_Misc_Coin_01"),
        ]
        for id_, path_str in icons:
            dbc.records.append(SpellIconRecord(id=id_, texture_filename=path_str))

        path = tmp_path / "SpellIcon.dbc"
        dbc.write(path)
        loaded = DbcFile.read(path)

        assert len(loaded) == 3
        for i, (id_, icon) in enumerate(icons):
            assert loaded.records[i].id == id_
            assert loaded.records[i].texture_filename == icon

    def test_byte_fidelity(self):
        dbc = DbcFile.create("SpellIcon")
        dbc.records.append(SpellIconRecord(
            id=9999,
            texture_filename=r"Interface\Icons\INV_Custom_MyIcon",
        ))
        data1 = dbc.to_bytes()
        data2 = DbcFile.from_bytes(data1, "SpellIcon").to_bytes()
        assert data1 == data2

    def test_header_values(self):
        dbc = DbcFile.create("SpellIcon")
        dbc.records.append(SpellIconRecord(id=1, texture_filename=""))
        data = dbc.to_bytes()
        _, rec_count, fld_count, rec_size, _ = _parse_header(data)
        assert rec_count == 1
        assert fld_count == 2
        assert rec_size == 2 * 4


# ── Mutation safety tests ───────────────────────────────────────────────


class TestMutationSafety:
    """Prove that modifying a record after reading produces structurally
    valid output that reflects the mutation.

    Each test covers one "bucket" of field types:
    - scalar (uint32/int32/float32 only)
    - string_ref
    - loc_string_ref
    - array (schema-generated expanded fields)
    - int8
    """

    # --- scalar bucket (SkillRaceClassInfo: 8 × uint32) -----------------

    def test_scalar_mutation(self, tmp_path):
        """Mutating a uint32 field re-serializes correctly."""
        from dbcraft.templates.skill_race_class_info import (
            SkillRaceClassInfoRecord,
        )

        dbc = DbcFile.create("SkillRaceClassInfo")
        dbc.records.append(
            SkillRaceClassInfoRecord(
                id=1, skill_id=100, race_mask=0xFFFF, class_mask=0xFF,
                flags=0, min_level=10, skill_tier_id=5, skill_cost_index=2,
            )
        )
        path = tmp_path / "SkillRaceClassInfo.dbc"
        dbc.write(path)

        loaded = DbcFile.read(path)
        loaded.records[0].race_mask = 0x1234
        mutated_bytes = loaded.to_bytes()

        reloaded = DbcFile.from_bytes(mutated_bytes, "SkillRaceClassInfo")
        assert reloaded.records[0].race_mask == 0x1234
        assert reloaded.records[0].skill_id == 100  # unchanged
        _, rc, fc, rs, _ = _parse_header(mutated_bytes)
        assert rc == 1
        assert fc == 8
        assert rs == 8 * 4

    # --- string_ref bucket (SpellIcon: uint32 id + string_ref) ----------

    def test_string_ref_mutation(self, tmp_path):
        """Mutating a string_ref field updates the string block."""
        dbc = DbcFile.create("SpellIcon")
        dbc.records.append(
            SpellIconRecord(id=1, texture_filename=r"Interface\Icons\Original")
        )
        dbc.records.append(
            SpellIconRecord(id=2, texture_filename=r"Interface\Icons\Other")
        )
        path = tmp_path / "SpellIcon.dbc"
        dbc.write(path)

        loaded = DbcFile.read(path)
        loaded.records[0].texture_filename = r"Interface\Icons\Modified"
        mutated_bytes = loaded.to_bytes()

        reloaded = DbcFile.from_bytes(mutated_bytes, "SpellIcon")
        assert reloaded.records[0].texture_filename == r"Interface\Icons\Modified"
        assert reloaded.records[1].texture_filename == r"Interface\Icons\Other"

    # --- loc_string_ref bucket (CharTitles) -----------------------------

    def test_loc_string_ref_mutation(self, tmp_path):
        """Mutating a locale in a loc_string_ref field re-serializes."""
        loc_m = LocalizedString(flags=0)
        loc_m.en_us = "Knight"
        loc_f = LocalizedString(flags=0)
        loc_f.en_us = "Dame"

        dbc = DbcFile.create("CharTitles")
        dbc.records.append(CharTitlesRecord(
            id=1, condition_id=0, name_lang=loc_m,
            name1_lang=loc_f, mask_id=0,
        ))
        path = tmp_path / "CharTitles.dbc"
        dbc.write(path)

        loaded = DbcFile.read(path)
        loaded.records[0].name_lang.en_us = "Paladin"
        loaded.records[0].name1_lang.de_de = "Ritterin"
        mutated_bytes = loaded.to_bytes()

        reloaded = DbcFile.from_bytes(mutated_bytes, "CharTitles")
        assert reloaded.records[0].name_lang.en_us == "Paladin"
        assert reloaded.records[0].name1_lang.en_us == "Dame"
        assert reloaded.records[0].name1_lang.de_de == "Ritterin"
        _, rc, fc, rs, _ = _parse_header(mutated_bytes)
        assert rc == 1
        assert fc == 37

    # --- array bucket (schema-generated AreaGroup: int32[6] expansion) --

    def test_array_field_mutation(self, tmp_path):
        """Mutating an array-expanded field in a schema-generated template."""
        from dbcraft.templates.base import get_template as _get

        cls = _get("AreaGroup")
        rec = cls(id=1, area_id_0=10, area_id_1=20, area_id_2=30)

        dbc = DbcFile.create("AreaGroup")
        dbc.records.append(rec)
        path = tmp_path / "AreaGroup.dbc"
        dbc.write(path)

        loaded = DbcFile.read(path)
        loaded.records[0].area_id_1 = 999
        mutated_bytes = loaded.to_bytes()

        reloaded = DbcFile.from_bytes(mutated_bytes, "AreaGroup")
        assert reloaded.records[0].area_id_0 == 10
        assert reloaded.records[0].area_id_1 == 999
        assert reloaded.records[0].area_id_2 == 30

    # --- int8 bucket (CharBaseInfo: 2 × int8, no id field) --------------

    def test_int8_mutation(self, tmp_path):
        """Mutating an int8 field preserves packed record sizing."""
        from dbcraft.templates.base import get_template as _get

        cls = _get("CharBaseInfo")
        rec = cls()
        rec.race_id = 1
        rec.class_id = 2

        dbc = DbcFile.create("CharBaseInfo")
        dbc.records.append(rec)
        path = tmp_path / "CharBaseInfo.dbc"
        dbc.write(path)

        loaded = DbcFile.read(path)
        loaded.records[0].class_id = 7
        mutated_bytes = loaded.to_bytes()

        reloaded = DbcFile.from_bytes(mutated_bytes, "CharBaseInfo")
        assert reloaded.records[0].race_id == 1
        assert reloaded.records[0].class_id == 7
        _, rc, fc, rs, _ = _parse_header(mutated_bytes)
        assert rc == 1
        assert fc == 2
        assert rs == 2  # 2 × int8 = 2 bytes, not 8
