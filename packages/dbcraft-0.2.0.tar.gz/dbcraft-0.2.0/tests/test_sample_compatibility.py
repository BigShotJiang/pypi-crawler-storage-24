"""Compatibility checks against local sample DBC files.

These tests validate that registered template layouts match real 3.3.5a
headers in `exampleDBCs/`.
"""

from __future__ import annotations

from pathlib import Path

import pytest

import dbcraft.templates  # noqa: F401 - ensure schema registration side effects
from dbcraft.core.header import DbcHeader
from dbcraft.dbc_file import DbcFile
from dbcraft.templates.base import get_field_count, get_record_size, get_template


SAMPLE_DIR = Path("exampleDBCs")


def _sample_paths() -> list[Path]:
    if not SAMPLE_DIR.exists():
        return []
    return sorted(SAMPLE_DIR.glob("*.dbc"))


def _roundtrip_cases() -> list[object]:
    return [pytest.param(path, id=path.stem) for path in _sample_paths() if path.stat().st_size >= 20]


@pytest.mark.parametrize("path", _sample_paths(), ids=lambda p: p.stem)
def test_sample_header_matches_template_layout(path: Path):
    data = path.read_bytes()
    if len(data) < 20:
        pytest.skip("Sample file is empty or truncated")

    header = DbcHeader.parse(data)
    cls = get_template(path.stem)
    assert header.field_count == get_field_count(cls)
    assert header.record_size == get_record_size(cls)


@pytest.mark.parametrize(
    "table_name",
    [
        "CharBaseInfo",
        "CharStartOutfit",
        "PowerDisplay",
        "SpellChainEffects",
        "SpellItemEnchantmentCondition",
    ],
)
def test_int8_tables_roundtrip_bytes(table_name: str):
    path = SAMPLE_DIR / f"{table_name}.dbc"
    if not path.exists():
        pytest.skip("Sample file not available")

    original = path.read_bytes()
    dbc = DbcFile.read(path)
    assert dbc.to_bytes() == original


@pytest.mark.parametrize("path", _roundtrip_cases())
def test_sample_roundtrip_bytes(path: Path):
    original = path.read_bytes()
    dbc = DbcFile.read(path)
    assert dbc.to_bytes() == original
