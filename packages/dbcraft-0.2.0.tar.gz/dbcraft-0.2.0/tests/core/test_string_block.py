"""Tests for dbcraft.core.string_block module."""

import pytest

from dbcraft.core.string_block import StringBlockBuilder, StringBlockReader


class TestStringBlockReader:
    """Test reading strings from a raw string block."""

    def test_read_empty_string_at_offset_zero(self) -> None:
        block = b"\x00"
        reader = StringBlockReader(block)
        assert reader.get(0) == ""

    def test_read_single_string(self) -> None:
        block = b"\x00hello\x00"
        reader = StringBlockReader(block)
        assert reader.get(1) == "hello"

    def test_read_multiple_strings(self) -> None:
        block = b"\x00hello\x00world\x00"
        reader = StringBlockReader(block)
        assert reader.get(0) == ""
        assert reader.get(1) == "hello"
        assert reader.get(7) == "world"

    def test_read_utf8_string(self) -> None:
        text = "Feuerball"
        encoded = text.encode("utf-8")
        block = b"\x00" + encoded + b"\x00"
        reader = StringBlockReader(block)
        assert reader.get(1) == "Feuerball"

    def test_offset_negative_raises(self) -> None:
        reader = StringBlockReader(b"\x00")
        with pytest.raises(ValueError, match="out of range"):
            reader.get(-1)

    def test_offset_past_end_raises(self) -> None:
        reader = StringBlockReader(b"\x00")
        with pytest.raises(ValueError, match="out of range"):
            reader.get(1)

    def test_size_property(self) -> None:
        reader = StringBlockReader(b"\x00hello\x00")
        assert reader.size == 7


class TestStringBlockBuilder:
    """Test building string blocks for writing."""

    def test_empty_builder(self) -> None:
        builder = StringBlockBuilder()
        data = builder.build()
        assert data == b"\x00"
        assert builder.size == 1

    def test_add_empty_string_returns_zero(self) -> None:
        builder = StringBlockBuilder()
        offset = builder.add("")
        assert offset == 0
        assert builder.build() == b"\x00"

    def test_add_single_string(self) -> None:
        builder = StringBlockBuilder()
        offset = builder.add("hello")
        assert offset == 1  # after the initial null byte
        data = builder.build()
        assert data == b"\x00hello\x00"

    def test_add_multiple_strings(self) -> None:
        builder = StringBlockBuilder()
        off1 = builder.add("hello")
        off2 = builder.add("world")
        assert off1 == 1
        assert off2 == 7  # 1 + 5 (hello) + 1 (null)
        data = builder.build()
        assert data == b"\x00hello\x00world\x00"

    def test_deduplication(self) -> None:
        builder = StringBlockBuilder()
        off1 = builder.add("hello")
        off2 = builder.add("hello")
        assert off1 == off2
        # Should only appear once in the block.
        data = builder.build()
        assert data == b"\x00hello\x00"

    def test_deduplication_empty_string(self) -> None:
        builder = StringBlockBuilder()
        off1 = builder.add("")
        off2 = builder.add("")
        assert off1 == 0
        assert off2 == 0

    def test_size_property(self) -> None:
        builder = StringBlockBuilder()
        assert builder.size == 1
        builder.add("abc")
        assert builder.size == 5  # \x00 + abc + \x00

    def test_roundtrip_with_reader(self) -> None:
        """Build a block, then read strings back from it."""
        builder = StringBlockBuilder()
        off_empty = builder.add("")
        off_hello = builder.add("hello")
        off_world = builder.add("world")

        data = builder.build()
        reader = StringBlockReader(data)

        assert reader.get(off_empty) == ""
        assert reader.get(off_hello) == "hello"
        assert reader.get(off_world) == "world"

    def test_utf8_roundtrip(self) -> None:
        builder = StringBlockBuilder()
        offset = builder.add("Boule de feu")
        data = builder.build()
        reader = StringBlockReader(data)
        assert reader.get(offset) == "Boule de feu"
