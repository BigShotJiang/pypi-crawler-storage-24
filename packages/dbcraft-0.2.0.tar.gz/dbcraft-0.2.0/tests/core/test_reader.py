"""Tests for dbcraft.core.reader - DBC file reader."""

from __future__ import annotations

import struct

import pytest

from dbcraft.core.header import DBC_MAGIC_INT, HEADER_SIZE
from dbcraft.core.reader import read_dbc
from dbcraft.core.types import LocalizedString


def _build_header(
    record_count: int,
    field_count: int,
    record_size: int,
    string_block_size: int,
) -> bytes:
    """Build a raw DBC header."""
    return struct.pack(
        "<5I",
        DBC_MAGIC_INT,
        record_count,
        field_count,
        record_size,
        string_block_size,
    )


def _build_simple_dbc(records: list[tuple[int, int, float]]) -> bytes:
    """Build a complete DBC binary for SimpleTestRecord (3 fields: uint32, int32, float32)."""
    field_count = 3
    record_size = field_count * 4
    string_block = b"\x00"  # minimal string block

    header = _build_header(len(records), field_count, record_size, len(string_block))
    record_data = b"".join(
        struct.pack("<Iif", id_, val, ratio) for id_, val, ratio in records
    )
    return header + record_data + string_block


def _build_string_dbc(
    records: list[tuple[int, int]],
    string_block: bytes,
) -> bytes:
    """Build a complete DBC binary for StringTestRecord (2 fields: uint32, string_ref).

    records is a list of (id, string_offset) tuples.
    """
    field_count = 2
    record_size = field_count * 4

    header = _build_header(len(records), field_count, record_size, len(string_block))
    record_data = b"".join(
        struct.pack("<II", id_, str_off) for id_, str_off in records
    )
    return header + record_data + string_block


def _build_loc_dbc(
    records: list[tuple[int, list[int], int]],
    string_block: bytes,
) -> bytes:
    """Build a complete DBC binary for LocTestRecord (1 uint32 + 1 loc_string_ref = 18 fields).

    records is a list of (id, [16 string offsets], flags) tuples.
    """
    field_count = 1 + 17  # id + 16 locale offsets + 1 flags
    record_size = field_count * 4

    header = _build_header(len(records), field_count, record_size, len(string_block))
    parts = []
    for id_, offsets, flags in records:
        parts.append(struct.pack("<I", id_))
        for off in offsets:
            parts.append(struct.pack("<I", off))
        parts.append(struct.pack("<I", flags))
    record_data = b"".join(parts)
    return header + record_data + string_block


# ── Basic reading ────────────────────────────────────────────────────────


class TestReadDbcSimple:
    """Tests reading DBC files with simple field types."""

    def test_read_single_record(self, register_simple_template):
        data = _build_simple_dbc([(1, -42, 3.14)])
        header, records = read_dbc(data, register_simple_template)

        assert header.record_count == 1
        assert header.field_count == 3
        assert len(records) == 1
        assert records[0].id == 1
        assert records[0].value == -42
        assert abs(records[0].ratio - 3.14) < 1e-5

    def test_read_multiple_records(self, register_simple_template):
        data = _build_simple_dbc([
            (1, 100, 1.0),
            (2, -200, 2.5),
            (3, 0, 0.0),
        ])
        header, records = read_dbc(data, register_simple_template)

        assert header.record_count == 3
        assert len(records) == 3
        assert records[0].id == 1
        assert records[1].id == 2
        assert records[1].value == -200
        assert records[2].id == 3
        assert records[2].ratio == 0.0

    def test_read_zero_records(self, register_simple_template):
        data = _build_simple_dbc([])
        header, records = read_dbc(data, register_simple_template)

        assert header.record_count == 0
        assert len(records) == 0

    def test_header_returned_correctly(self, register_simple_template):
        data = _build_simple_dbc([(10, 20, 30.0)])
        header, _ = read_dbc(data, register_simple_template)

        assert header.record_count == 1
        assert header.field_count == 3
        assert header.record_size == 12
        assert header.string_block_size == 1  # just \x00


class TestReadDbcStrings:
    """Tests reading DBC files with string_ref fields."""

    def test_read_string_record(self, register_string_template):
        # String block: \x00 + "Hello\x00"
        string_block = b"\x00Hello\x00"
        data = _build_string_dbc([(1, 1)], string_block)
        header, records = read_dbc(data, register_string_template)

        assert len(records) == 1
        assert records[0].id == 1
        assert records[0].name == "Hello"

    def test_read_empty_string(self, register_string_template):
        string_block = b"\x00"
        data = _build_string_dbc([(1, 0)], string_block)
        _, records = read_dbc(data, register_string_template)

        assert records[0].name == ""

    def test_read_multiple_strings(self, register_string_template):
        # String block: \x00 + "Alpha\x00" + "Beta\x00"
        string_block = b"\x00Alpha\x00Beta\x00"
        alpha_off = 1
        beta_off = 7
        data = _build_string_dbc(
            [(1, alpha_off), (2, beta_off)],
            string_block,
        )
        _, records = read_dbc(data, register_string_template)

        assert records[0].name == "Alpha"
        assert records[1].name == "Beta"


class TestReadDbcLocalized:
    """Tests reading DBC files with loc_string_ref fields."""

    def test_read_loc_record(self, register_loc_template):
        # String block: \x00 + "Title\x00"
        string_block = b"\x00Title\x00"
        title_off = 1
        offsets = [title_off] + [0] * 15  # en_us has title, rest empty
        data = _build_loc_dbc([(1, offsets, 0)], string_block)
        _, records = read_dbc(data, register_loc_template)

        assert len(records) == 1
        assert records[0].id == 1
        assert isinstance(records[0].title, LocalizedString)
        assert records[0].title.en_us == "Title"
        assert records[0].title.de_de == ""
        assert records[0].title.flags == 0

    def test_read_loc_with_flags(self, register_loc_template):
        string_block = b"\x00"
        offsets = [0] * 16
        data = _build_loc_dbc([(1, offsets, 0xFF)], string_block)
        _, records = read_dbc(data, register_loc_template)

        assert records[0].title.flags == 0xFF

    def test_read_loc_multiple_locales(self, register_loc_template):
        # String block: \x00 + "EN\x00" + "DE\x00" + "FR\x00"
        string_block = b"\x00EN\x00DE\x00FR\x00"
        en_off = 1
        de_off = 4
        fr_off = 7
        offsets = [en_off, 0, fr_off, de_off] + [0] * 12
        data = _build_loc_dbc([(1, offsets, 0)], string_block)
        _, records = read_dbc(data, register_loc_template)

        assert records[0].title.en_us == "EN"
        assert records[0].title.de_de == "DE"
        assert records[0].title.fr_fr == "FR"
        assert records[0].title.ko_kr == ""


# ── Error cases ──────────────────────────────────────────────────────────


class TestReadDbcErrors:
    """Tests for error handling in read_dbc."""

    def test_field_count_mismatch(self, register_simple_template):
        """Header field_count doesn't match template."""
        # SimpleTestRecord has 3 fields, but we say 5 in the header
        string_block = b"\x00"
        header = _build_header(0, 5, 20, len(string_block))
        data = header + string_block

        with pytest.raises(ValueError, match="Template field count mismatch"):
            read_dbc(data, register_simple_template)

    def test_data_too_short(self, register_simple_template):
        """File is truncated - not enough bytes for declared records."""
        # Declare 2 records but only provide 1 record's worth of data
        field_count = 3
        record_size = field_count * 4
        string_block = b"\x00"
        header = _build_header(2, field_count, record_size, len(string_block))
        one_record = struct.pack("<Iif", 1, 2, 3.0)
        data = header + one_record + string_block  # missing second record

        with pytest.raises(ValueError, match="DBC file too short"):
            read_dbc(data, register_simple_template)

    def test_record_size_mismatch(self, register_simple_template):
        """Header record_size doesn't match template."""
        string_block = b"\x00"
        # SimpleTestRecord expects 12-byte records.
        header = _build_header(0, 3, 8, len(string_block))
        data = header + string_block

        with pytest.raises(ValueError, match="Template record size mismatch"):
            read_dbc(data, register_simple_template)

    def test_invalid_magic(self, register_simple_template):
        """Propagates header parse error for bad magic bytes."""
        data = b"\x00" * 20
        with pytest.raises(ValueError, match="Invalid DBC magic"):
            read_dbc(data, register_simple_template)

    def test_data_too_short_for_header(self, register_simple_template):
        """Propagates header parse error for truncated data."""
        data = b"WDBC"  # only 4 bytes, need 20
        with pytest.raises(ValueError, match="DBC header requires"):
            read_dbc(data, register_simple_template)


class TestReadDbcExtraData:
    """Edge case: file has extra trailing bytes beyond expected size."""

    def test_extra_trailing_bytes_ignored(self, register_simple_template):
        """Extra bytes after string block are silently ignored."""
        data = _build_simple_dbc([(1, 2, 3.0)])
        data += b"\xff" * 100  # garbage trailing bytes
        _, records = read_dbc(data, register_simple_template)

        assert len(records) == 1
        assert records[0].id == 1
