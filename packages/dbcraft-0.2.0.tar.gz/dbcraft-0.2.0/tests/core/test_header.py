"""Tests for dbcraft.core.header module."""

import struct

import pytest

from dbcraft.core.header import (
    DBC_MAGIC,
    DBC_MAGIC_INT,
    HEADER_FORMAT,
    HEADER_SIZE,
    DbcHeader,
)


class TestHeaderConstants:
    """Test header-related constants."""

    def test_magic_bytes(self) -> None:
        assert DBC_MAGIC == b"WDBC"

    def test_magic_int(self) -> None:
        assert DBC_MAGIC_INT == 0x43424457

    def test_header_size(self) -> None:
        assert HEADER_SIZE == 20

    def test_header_format_struct_size(self) -> None:
        assert struct.calcsize(HEADER_FORMAT) == HEADER_SIZE


class TestDbcHeader:
    """Test DbcHeader dataclass."""

    def test_construction(self) -> None:
        header = DbcHeader(
            record_count=100,
            field_count=10,
            record_size=40,
            string_block_size=256,
        )
        assert header.record_count == 100
        assert header.field_count == 10
        assert header.record_size == 40
        assert header.string_block_size == 256


class TestDbcHeaderParse:
    """Test DbcHeader.parse()."""

    def _make_header_bytes(
        self,
        magic: int = DBC_MAGIC_INT,
        record_count: int = 10,
        field_count: int = 5,
        record_size: int = 20,
        string_block_size: int = 100,
    ) -> bytes:
        return struct.pack(
            HEADER_FORMAT,
            magic,
            record_count,
            field_count,
            record_size,
            string_block_size,
        )

    def test_parse_valid(self) -> None:
        data = self._make_header_bytes()
        header = DbcHeader.parse(data)
        assert header.record_count == 10
        assert header.field_count == 5
        assert header.record_size == 20
        assert header.string_block_size == 100

    def test_parse_with_extra_data(self) -> None:
        data = self._make_header_bytes() + b"\x00" * 100
        header = DbcHeader.parse(data)
        assert header.record_count == 10

    def test_parse_too_short_raises(self) -> None:
        with pytest.raises(ValueError, match="requires 20 bytes"):
            DbcHeader.parse(b"\x00" * 19)

    def test_parse_empty_raises(self) -> None:
        with pytest.raises(ValueError, match="requires 20 bytes"):
            DbcHeader.parse(b"")

    def test_parse_bad_magic_raises(self) -> None:
        data = self._make_header_bytes(magic=0xDEADBEEF)
        with pytest.raises(ValueError, match="Invalid DBC magic"):
            DbcHeader.parse(data)


class TestDbcHeaderToBytes:
    """Test DbcHeader.to_bytes()."""

    def test_to_bytes_size(self) -> None:
        header = DbcHeader(
            record_count=0,
            field_count=0,
            record_size=0,
            string_block_size=0,
        )
        data = header.to_bytes()
        assert len(data) == HEADER_SIZE

    def test_to_bytes_magic(self) -> None:
        header = DbcHeader(
            record_count=0,
            field_count=0,
            record_size=0,
            string_block_size=0,
        )
        data = header.to_bytes()
        assert data[:4] == DBC_MAGIC

    def test_to_bytes_values(self) -> None:
        header = DbcHeader(
            record_count=42,
            field_count=7,
            record_size=28,
            string_block_size=512,
        )
        data = header.to_bytes()
        magic, rc, fc, rs, sbs = struct.unpack(HEADER_FORMAT, data)
        assert magic == DBC_MAGIC_INT
        assert rc == 42
        assert fc == 7
        assert rs == 28
        assert sbs == 512

    def test_roundtrip(self) -> None:
        original = DbcHeader(
            record_count=1000,
            field_count=234,
            record_size=936,
            string_block_size=65536,
        )
        data = original.to_bytes()
        parsed = DbcHeader.parse(data)
        assert parsed.record_count == original.record_count
        assert parsed.field_count == original.field_count
        assert parsed.record_size == original.record_size
        assert parsed.string_block_size == original.string_block_size
