"""Tests for dbcraft.core.writer - DBC file writer."""

from __future__ import annotations

import struct
from dataclasses import dataclass

import pytest

from dbcraft.core.header import DBC_MAGIC_INT, HEADER_SIZE
from dbcraft.core.reader import read_dbc
from dbcraft.core.types import LocalizedString, int8, int32
from dbcraft.core.writer import write_dbc
from dbcraft.templates.base import _TEMPLATE_REGISTRY, register_template


@dataclass
class _Int8TestRecord:
    id: int8
    value: int32


# ── Simple records ───────────────────────────────────────────────────────


class TestWriteDbcSimple:
    """Tests writing DBC files with simple field types."""

    def test_write_single_record(self, register_simple_template):
        cls = register_simple_template
        record = cls(id=1, value=-42, ratio=3.14)
        data = write_dbc([record], cls)

        # Parse the header
        magic, rec_count, fld_count, rec_size, sb_size = struct.unpack_from(
            "<5I", data
        )
        assert magic == DBC_MAGIC_INT
        assert rec_count == 1
        assert fld_count == 3
        assert rec_size == 12
        assert sb_size == 1  # just \x00

        # Parse the record
        id_, value, ratio = struct.unpack_from("<Iif", data, HEADER_SIZE)
        assert id_ == 1
        assert value == -42
        assert abs(ratio - 3.14) < 1e-5

        # String block is just a null byte
        assert data[HEADER_SIZE + 12 :] == b"\x00"

    def test_write_multiple_records(self, register_simple_template):
        cls = register_simple_template
        records = [
            cls(id=1, value=100, ratio=1.0),
            cls(id=2, value=-200, ratio=2.5),
            cls(id=3, value=0, ratio=0.0),
        ]
        data = write_dbc(records, cls)

        _, rec_count, _, _, _ = struct.unpack_from("<5I", data)
        assert rec_count == 3

        for i, (expected_id, expected_val, expected_ratio) in enumerate(
            [(1, 100, 1.0), (2, -200, 2.5), (3, 0, 0.0)]
        ):
            offset = HEADER_SIZE + i * 12
            id_, value, ratio = struct.unpack_from("<Iif", data, offset)
            assert id_ == expected_id
            assert value == expected_val
            assert abs(ratio - expected_ratio) < 1e-5

    def test_write_zero_records(self, register_simple_template):
        cls = register_simple_template
        data = write_dbc([], cls)

        _, rec_count, fld_count, rec_size, sb_size = struct.unpack_from(
            "<5I", data
        )
        assert rec_count == 0
        assert fld_count == 3
        assert rec_size == 12
        assert sb_size == 1  # empty string block is still \x00

        # Total size: header + string block
        assert len(data) == HEADER_SIZE + 1


# ── String records ───────────────────────────────────────────────────────


class TestWriteDbcStrings:
    """Tests writing DBC files with string_ref fields."""

    def test_write_string_record(self, register_string_template):
        cls = register_string_template
        record = cls(id=1, name="Hello")
        data = write_dbc([record], cls)

        _, rec_count, fld_count, rec_size, sb_size = struct.unpack_from(
            "<5I", data
        )
        assert rec_count == 1
        assert fld_count == 2
        assert rec_size == 8

        # Record: id + string offset
        id_, str_off = struct.unpack_from("<II", data, HEADER_SIZE)
        assert id_ == 1
        assert str_off > 0  # not empty string

        # String block should contain "Hello"
        sb_start = HEADER_SIZE + rec_size
        string_block = data[sb_start:]
        assert string_block[0:1] == b"\x00"  # sentinel
        assert b"Hello\x00" in string_block

    def test_write_empty_string(self, register_string_template):
        cls = register_string_template
        record = cls(id=1, name="")
        data = write_dbc([record], cls)

        id_, str_off = struct.unpack_from("<II", data, HEADER_SIZE)
        assert str_off == 0  # empty string -> offset 0

    def test_string_deduplication(self, register_string_template):
        cls = register_string_template
        records = [
            cls(id=1, name="Same"),
            cls(id=2, name="Same"),
            cls(id=3, name="Different"),
        ]
        data = write_dbc(records, cls)

        # Both "Same" records should have the same string offset
        _, off1 = struct.unpack_from("<II", data, HEADER_SIZE)
        _, off2 = struct.unpack_from("<II", data, HEADER_SIZE + 8)
        _, off3 = struct.unpack_from("<II", data, HEADER_SIZE + 16)
        assert off1 == off2
        assert off1 != off3


# ── Localized string records ────────────────────────────────────────────


class TestWriteDbcLocalized:
    """Tests writing DBC files with loc_string_ref fields."""

    def test_write_loc_record(self, register_loc_template):
        cls = register_loc_template
        loc = LocalizedString()
        loc.en_us = "Title"
        record = cls(id=1, title=loc)
        data = write_dbc([record], cls)

        _, rec_count, fld_count, rec_size, sb_size = struct.unpack_from(
            "<5I", data
        )
        assert rec_count == 1
        assert fld_count == 18  # 1 uint32 + 17 loc fields
        assert rec_size == 18 * 4

        # Parse the record manually
        offset = HEADER_SIZE
        (id_,) = struct.unpack_from("<I", data, offset)
        assert id_ == 1
        offset += 4

        # en_us should have a non-zero offset
        (en_off,) = struct.unpack_from("<I", data, offset)
        assert en_off > 0
        offset += 4

        # Remaining 15 locale offsets should be 0 (empty)
        for _ in range(15):
            (off,) = struct.unpack_from("<I", data, offset)
            assert off == 0
            offset += 4

        # Flags should be 0
        (flags,) = struct.unpack_from("<I", data, offset)
        assert flags == 0

    def test_write_loc_with_flags(self, register_loc_template):
        cls = register_loc_template
        loc = LocalizedString(flags=0xAB)
        record = cls(id=1, title=loc)
        data = write_dbc([record], cls)

        # Flags are the last uint32 of the record
        flags_offset = HEADER_SIZE + (18 - 1) * 4
        (flags,) = struct.unpack_from("<I", data, flags_offset)
        assert flags == 0xAB

    def test_write_loc_multiple_locales(self, register_loc_template):
        cls = register_loc_template
        loc = LocalizedString()
        loc.en_us = "EN"
        loc.de_de = "DE"
        loc.fr_fr = "FR"
        record = cls(id=1, title=loc)
        data = write_dbc([record], cls)

        # Parse locale offsets from record
        base = HEADER_SIZE + 4  # skip id
        en_off = struct.unpack_from("<I", data, base)[0]
        fr_off = struct.unpack_from("<I", data, base + 2 * 4)[0]  # fr is index 2
        de_off = struct.unpack_from("<I", data, base + 3 * 4)[0]  # de is index 3

        # All should be non-zero and different
        assert en_off > 0
        assert fr_off > 0
        assert de_off > 0
        assert len({en_off, fr_off, de_off}) == 3


# ── Roundtrip consistency ────────────────────────────────────────────────


class TestWriteReadRoundtrip:
    """Tests that write_dbc output can be read back by read_dbc."""

    def test_simple_roundtrip(self, register_simple_template):
        cls = register_simple_template
        original = [
            cls(id=1, value=-42, ratio=3.14),
            cls(id=2, value=0, ratio=0.0),
        ]
        data = write_dbc(original, cls)
        _, records = read_dbc(data, cls)

        assert len(records) == len(original)
        for orig, read in zip(original, records):
            assert orig.id == read.id
            assert orig.value == read.value
            assert abs(orig.ratio - read.ratio) < 1e-5

    def test_string_roundtrip(self, register_string_template):
        cls = register_string_template
        original = [
            cls(id=1, name="Hello"),
            cls(id=2, name="World"),
            cls(id=3, name=""),
        ]
        data = write_dbc(original, cls)
        _, records = read_dbc(data, cls)

        assert len(records) == len(original)
        for orig, read in zip(original, records):
            assert orig.id == read.id
            assert orig.name == read.name

    def test_loc_roundtrip(self, register_loc_template):
        cls = register_loc_template
        loc = LocalizedString(flags=42)
        loc.en_us = "English"
        loc.de_de = "Deutsch"
        original = [cls(id=1, title=loc)]

        data = write_dbc(original, cls)
        _, records = read_dbc(data, cls)

        assert len(records) == 1
        assert records[0].id == 1
        assert records[0].title.en_us == "English"
        assert records[0].title.de_de == "Deutsch"
        assert records[0].title.fr_fr == ""
        assert records[0].title.flags == 42

    def test_empty_roundtrip(self, register_simple_template):
        cls = register_simple_template
        data = write_dbc([], cls)
        _, records = read_dbc(data, cls)
        assert len(records) == 0


class TestWriteDbcInt8:
    def test_write_int8_record_size(self):
        original = dict(_TEMPLATE_REGISTRY)
        try:
            cls = register_template("Int8Test")(_Int8TestRecord)
            data = write_dbc([cls(id=-3, value=42)], cls)
            _, rec_count, fld_count, rec_size, _ = struct.unpack_from("<5I", data)
            assert rec_count == 1
            assert fld_count == 2
            assert rec_size == 5

            id_val, value = struct.unpack_from("<bi", data, HEADER_SIZE)
            assert id_val == -3
            assert value == 42
        finally:
            _TEMPLATE_REGISTRY.clear()
            _TEMPLATE_REGISTRY.update(original)

    def test_raises_on_serialized_size_mismatch(self, monkeypatch, register_simple_template):
        cls = register_simple_template

        def _bad_serialize(_record, _builder):
            return b"\x00"

        monkeypatch.setattr("dbcraft.core.writer.serialize_record", _bad_serialize)

        with pytest.raises(ValueError, match="Serialized record size mismatch"):
            write_dbc([cls(id=1, value=2, ratio=3.0)], cls)
