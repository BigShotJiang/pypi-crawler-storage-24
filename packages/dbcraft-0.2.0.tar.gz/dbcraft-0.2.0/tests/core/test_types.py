"""Tests for dbcraft.core.types module."""

import pytest

from dbcraft.core.types import (
    LOCALE_COUNT,
    LOCALE_NAMES,
    LOC_FIELD_COUNT,
    LocalizedString,
    loc_string_ref,
    string_ref,
    uint32,
    int32,
    int8,
    float32,
)


class TestTypeAliases:
    """Test that NewType aliases work correctly."""

    def test_uint32_is_int(self) -> None:
        val = uint32(42)
        assert val == 42
        assert isinstance(val, int)

    def test_int32_is_int(self) -> None:
        val = int32(-1)
        assert val == -1
        assert isinstance(val, int)

    def test_int8_is_int(self) -> None:
        val = int8(-7)
        assert val == -7
        assert isinstance(val, int)

    def test_float32_is_float(self) -> None:
        val = float32(3.14)
        assert abs(val - 3.14) < 0.001
        assert isinstance(val, float)

    def test_string_ref_is_str(self) -> None:
        val = string_ref("hello")
        assert val == "hello"
        assert isinstance(val, str)


class TestLocaleConstants:
    """Test locale-related constants."""

    def test_locale_count(self) -> None:
        assert LOCALE_COUNT == 16

    def test_loc_field_count(self) -> None:
        assert LOC_FIELD_COUNT == 17  # 16 locales + 1 flags

    def test_locale_names_length(self) -> None:
        assert len(LOCALE_NAMES) == LOCALE_COUNT

    def test_locale_names_content(self) -> None:
        assert LOCALE_NAMES[0] == "en_us"
        assert LOCALE_NAMES[1] == "ko_kr"
        assert LOCALE_NAMES[2] == "fr_fr"
        assert LOCALE_NAMES[3] == "de_de"
        assert LOCALE_NAMES[4] == "zh_cn"
        assert LOCALE_NAMES[5] == "zh_tw"
        assert LOCALE_NAMES[6] == "es_es"
        assert LOCALE_NAMES[7] == "es_mx"
        assert LOCALE_NAMES[8] == "ru_ru"
        assert LOCALE_NAMES[9] == "ja_jp"
        assert LOCALE_NAMES[10] == "pt_pt"
        assert LOCALE_NAMES[11] == "it_it"
        assert LOCALE_NAMES[12] == "unk_12"
        assert LOCALE_NAMES[13] == "unk_13"
        assert LOCALE_NAMES[14] == "unk_14"
        assert LOCALE_NAMES[15] == "unk_15"


class TestLocalizedString:
    """Test the LocalizedString class."""

    def test_default_construction(self) -> None:
        loc = LocalizedString()
        assert loc.flags == 0
        for i in range(LOCALE_COUNT):
            assert loc[i] == ""

    def test_construction_with_strings(self) -> None:
        strings = ["hello"] + [""] * 15
        loc = LocalizedString(_strings=strings)
        assert loc[0] == "hello"
        assert loc.en_us == "hello"

    def test_construction_with_flags(self) -> None:
        loc = LocalizedString(flags=0xFF)
        assert loc.flags == 0xFF

    def test_invalid_string_count_raises(self) -> None:
        with pytest.raises(ValueError, match="exactly 16"):
            LocalizedString(_strings=["a", "b"])

    def test_getitem(self) -> None:
        strings = [f"str_{i}" for i in range(LOCALE_COUNT)]
        loc = LocalizedString(_strings=strings)
        for i in range(LOCALE_COUNT):
            assert loc[i] == f"str_{i}"

    def test_getitem_out_of_range(self) -> None:
        loc = LocalizedString()
        with pytest.raises(IndexError, match="out of range"):
            _ = loc[16]
        with pytest.raises(IndexError, match="out of range"):
            _ = loc[-1]

    def test_setitem(self) -> None:
        loc = LocalizedString()
        loc[0] = "test"
        assert loc[0] == "test"

    def test_setitem_out_of_range(self) -> None:
        loc = LocalizedString()
        with pytest.raises(IndexError, match="out of range"):
            loc[16] = "x"
        with pytest.raises(IndexError, match="out of range"):
            loc[-1] = "x"

    def test_equality(self) -> None:
        a = LocalizedString()
        b = LocalizedString()
        assert a == b

        a.en_us = "hello"
        assert a != b

        b.en_us = "hello"
        assert a == b

    def test_equality_with_flags(self) -> None:
        a = LocalizedString(flags=1)
        b = LocalizedString(flags=2)
        assert a != b

    def test_equality_not_implemented_for_other_types(self) -> None:
        loc = LocalizedString()
        assert loc != "not a localized string"

    def test_repr_empty(self) -> None:
        loc = LocalizedString()
        r = repr(loc)
        assert "LocalizedString" in r
        assert "flags=0" in r

    def test_repr_with_values(self) -> None:
        loc = LocalizedString()
        loc.en_us = "Fireball"
        r = repr(loc)
        assert "en_us" in r
        assert "Fireball" in r

    def test_get_by_name(self) -> None:
        loc = LocalizedString()
        loc.en_us = "hello"
        assert loc.get_by_name("en_us") == "hello"

    def test_get_by_name_unknown(self) -> None:
        loc = LocalizedString()
        with pytest.raises(KeyError, match="Unknown locale name"):
            loc.get_by_name("xx_xx")

    def test_set_by_name(self) -> None:
        loc = LocalizedString()
        loc.set_by_name("de_de", "Hallo")
        assert loc.de_de == "Hallo"

    def test_set_by_name_unknown(self) -> None:
        loc = LocalizedString()
        with pytest.raises(KeyError, match="Unknown locale name"):
            loc.set_by_name("xx_xx", "value")

    # Named property tests for all 16 locales
    def test_en_us_property(self) -> None:
        loc = LocalizedString()
        loc.en_us = "English"
        assert loc.en_us == "English"
        assert loc[0] == "English"

    def test_ko_kr_property(self) -> None:
        loc = LocalizedString()
        loc.ko_kr = "Korean"
        assert loc.ko_kr == "Korean"
        assert loc[1] == "Korean"

    def test_fr_fr_property(self) -> None:
        loc = LocalizedString()
        loc.fr_fr = "French"
        assert loc.fr_fr == "French"
        assert loc[2] == "French"

    def test_de_de_property(self) -> None:
        loc = LocalizedString()
        loc.de_de = "German"
        assert loc.de_de == "German"
        assert loc[3] == "German"

    def test_zh_cn_property(self) -> None:
        loc = LocalizedString()
        loc.zh_cn = "Chinese"
        assert loc.zh_cn == "Chinese"
        assert loc[4] == "Chinese"

    def test_zh_tw_property(self) -> None:
        loc = LocalizedString()
        loc.zh_tw = "Taiwanese"
        assert loc.zh_tw == "Taiwanese"
        assert loc[5] == "Taiwanese"

    def test_es_es_property(self) -> None:
        loc = LocalizedString()
        loc.es_es = "Spanish"
        assert loc.es_es == "Spanish"
        assert loc[6] == "Spanish"

    def test_es_mx_property(self) -> None:
        loc = LocalizedString()
        loc.es_mx = "Mexican Spanish"
        assert loc.es_mx == "Mexican Spanish"
        assert loc[7] == "Mexican Spanish"

    def test_ru_ru_property(self) -> None:
        loc = LocalizedString()
        loc.ru_ru = "Russian"
        assert loc.ru_ru == "Russian"
        assert loc[8] == "Russian"

    def test_ja_jp_property(self) -> None:
        loc = LocalizedString()
        loc.ja_jp = "Japanese"
        assert loc.ja_jp == "Japanese"
        assert loc[9] == "Japanese"

    def test_pt_pt_property(self) -> None:
        loc = LocalizedString()
        loc.pt_pt = "Portuguese"
        assert loc.pt_pt == "Portuguese"
        assert loc[10] == "Portuguese"

    def test_it_it_property(self) -> None:
        loc = LocalizedString()
        loc.it_it = "Italian"
        assert loc.it_it == "Italian"
        assert loc[11] == "Italian"

    def test_unk_12_property(self) -> None:
        loc = LocalizedString()
        loc.unk_12 = "unk12"
        assert loc.unk_12 == "unk12"
        assert loc[12] == "unk12"

    def test_unk_13_property(self) -> None:
        loc = LocalizedString()
        loc.unk_13 = "unk13"
        assert loc.unk_13 == "unk13"
        assert loc[13] == "unk13"

    def test_unk_14_property(self) -> None:
        loc = LocalizedString()
        loc.unk_14 = "unk14"
        assert loc.unk_14 == "unk14"
        assert loc[14] == "unk14"

    def test_unk_15_property(self) -> None:
        loc = LocalizedString()
        loc.unk_15 = "unk15"
        assert loc.unk_15 == "unk15"
        assert loc[15] == "unk15"


class TestLocStringRef:
    """Test the loc_string_ref type alias."""

    def test_loc_string_ref_creates_localized_string(self) -> None:
        val = loc_string_ref(LocalizedString())
        assert isinstance(val, LocalizedString)
