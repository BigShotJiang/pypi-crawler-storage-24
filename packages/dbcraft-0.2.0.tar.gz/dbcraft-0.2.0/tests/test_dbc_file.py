"""Tests for dbcraft.dbc_file - High-level DbcFile API."""

from __future__ import annotations

import struct
from pathlib import Path

import pytest

from dbcraft.core.header import DBC_MAGIC_INT, HEADER_SIZE
from dbcraft.core.types import LocalizedString
from dbcraft.core.writer import write_dbc
from dbcraft.dbc_file import DbcFile


# ── DbcFile.create ──────────────────────────────────────────────────────


class TestDbcFileCreate:
    """Tests for creating new empty DbcFile instances."""

    def test_create_simple(self, register_simple_template):
        dbc = DbcFile.create("SimpleTest")
        assert dbc.dbc_name == "SimpleTest"
        assert dbc.record_cls is register_simple_template
        assert dbc.records == []
        assert len(dbc) == 0

    def test_create_string(self, register_string_template):
        dbc = DbcFile.create("StringTest")
        assert dbc.dbc_name == "StringTest"
        assert dbc.record_cls is register_string_template
        assert len(dbc) == 0

    def test_create_unknown_template(self):
        with pytest.raises(KeyError, match="No template registered"):
            DbcFile.create("NonExistent")


# ── DbcFile.from_bytes ──────────────────────────────────────────────────


class TestDbcFileFromBytes:
    """Tests for creating DbcFile from raw bytes."""

    def test_from_bytes_simple(self, register_simple_template):
        cls = register_simple_template
        records = [cls(id=1, value=-10, ratio=2.5)]
        raw = write_dbc(records, cls)

        dbc = DbcFile.from_bytes(raw, "SimpleTest")
        assert dbc.dbc_name == "SimpleTest"
        assert len(dbc) == 1
        assert dbc.records[0].id == 1
        assert dbc.records[0].value == -10

    def test_from_bytes_string(self, register_string_template):
        cls = register_string_template
        records = [cls(id=1, name="Hello")]
        raw = write_dbc(records, cls)

        dbc = DbcFile.from_bytes(raw, "StringTest")
        assert dbc.records[0].name == "Hello"

    def test_from_bytes_unknown_template(self):
        with pytest.raises(KeyError, match="No template registered"):
            DbcFile.from_bytes(b"", "NonExistent")

    def test_from_bytes_invalid_data(self, register_simple_template):
        with pytest.raises(ValueError):
            DbcFile.from_bytes(b"\x00" * 4, "SimpleTest")


# ── DbcFile.to_bytes ────────────────────────────────────────────────────


class TestDbcFileToBytes:
    """Tests for serializing DbcFile to bytes."""

    def test_to_bytes_empty(self, register_simple_template):
        dbc = DbcFile.create("SimpleTest")
        data = dbc.to_bytes()

        magic, rec_count, fld_count, rec_size, sb_size = struct.unpack_from(
            "<5I", data
        )
        assert magic == DBC_MAGIC_INT
        assert rec_count == 0
        assert fld_count == 3
        assert sb_size == 1

    def test_to_bytes_with_records(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.records.append(cls(id=42, value=7, ratio=1.5))
        data = dbc.to_bytes()

        _, rec_count, _, _, _ = struct.unpack_from("<5I", data)
        assert rec_count == 1


# ── DbcFile.read / write (file I/O) ─────────────────────────────────────


class TestDbcFileIO:
    """Tests for reading/writing DbcFile to disk."""

    def test_write_and_read(self, register_simple_template, tmp_path):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.records.append(cls(id=1, value=-5, ratio=3.0))
        dbc.records.append(cls(id=2, value=100, ratio=0.0))

        path = tmp_path / "SimpleTest.dbc"
        dbc.write(path)

        assert path.exists()

        loaded = DbcFile.read(path)
        assert loaded.dbc_name == "SimpleTest"
        assert len(loaded) == 2
        assert loaded.records[0].id == 1
        assert loaded.records[0].value == -5
        assert loaded.records[1].id == 2

    def test_write_creates_parent_dirs(self, register_simple_template, tmp_path):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.records.append(cls(id=1, value=0, ratio=0.0))

        path = tmp_path / "sub" / "dir" / "SimpleTest.dbc"
        dbc.write(path)

        assert path.exists()

    def test_read_auto_detects_template(self, register_string_template, tmp_path):
        cls = register_string_template
        dbc = DbcFile.create("StringTest")
        dbc.records.append(cls(id=1, name="Autodetect"))

        path = tmp_path / "StringTest.dbc"
        dbc.write(path)

        loaded = DbcFile.read(path)
        assert loaded.dbc_name == "StringTest"
        assert loaded.records[0].name == "Autodetect"

    def test_read_nonexistent_file(self, register_simple_template):
        """File doesn't exist but template name matches a registered one."""
        with pytest.raises(FileNotFoundError):
            DbcFile.read("SimpleTest.dbc")

    def test_read_unknown_template_from_filename(self, tmp_path):
        """File exists but filename doesn't match a registered template."""
        path = tmp_path / "Unknown.dbc"
        path.write_bytes(b"\x00" * 20)

        with pytest.raises(KeyError, match="No template registered"):
            DbcFile.read(path)

    def test_write_string_path(self, register_simple_template, tmp_path):
        """write() accepts string paths, not just Path objects."""
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.records.append(cls(id=1, value=0, ratio=0.0))

        path = str(tmp_path / "SimpleTest.dbc")
        dbc.write(path)

        assert Path(path).exists()

    def test_read_string_path(self, register_simple_template, tmp_path):
        """read() accepts string paths, not just Path objects."""
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.records.append(cls(id=1, value=0, ratio=0.0))

        path = tmp_path / "SimpleTest.dbc"
        dbc.write(path)

        loaded = DbcFile.read(str(path))
        assert loaded.records[0].id == 1

    def test_read_then_modify_invalidates_source_cache(self, register_simple_template, tmp_path):
        """After modifying records, to_bytes should reserialize data."""
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.records.append(cls(id=1, value=0, ratio=1.0))

        path = tmp_path / "SimpleTest.dbc"
        dbc.write(path)
        original = path.read_bytes()

        loaded = DbcFile.read(path)
        loaded.records[0].value = 99
        mutated = loaded.to_bytes()

        assert mutated != original


# ── DbcFile.__init__ / __repr__ / __len__ ───────────────────────────────


class TestDbcFileMethods:
    """Tests for DbcFile constructor, repr, and len."""

    def test_init_defaults(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile("SimpleTest", cls)
        assert dbc.dbc_name == "SimpleTest"
        assert dbc.record_cls is cls
        assert dbc.records == []

    def test_init_with_records(self, register_simple_template):
        cls = register_simple_template
        records = [cls(id=1, value=0, ratio=0.0)]
        dbc = DbcFile("SimpleTest", cls, records=records)
        assert len(dbc) == 1

    def test_len(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile("SimpleTest", cls)
        assert len(dbc) == 0
        dbc.records.append(cls(id=1, value=0, ratio=0.0))
        assert len(dbc) == 1
        dbc.records.append(cls(id=2, value=0, ratio=0.0))
        assert len(dbc) == 2

    def test_repr_empty(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile("SimpleTest", cls)
        r = repr(dbc)
        assert "SimpleTest" in r
        assert "record_count=0" in r

    def test_repr_with_records(self, register_simple_template):
        cls = register_simple_template
        records = [cls(id=1, value=0, ratio=0.0), cls(id=2, value=0, ratio=0.0)]
        dbc = DbcFile("SimpleTest", cls, records=records)
        r = repr(dbc)
        assert "record_count=2" in r


# ── Localized records through DbcFile ───────────────────────────────────


class TestDbcFileLocalized:
    """Tests DbcFile with loc_string_ref records."""

    def test_loc_roundtrip_via_dbcfile(self, register_loc_template, tmp_path):
        cls = register_loc_template
        loc = LocalizedString(flags=7)
        loc.en_us = "Test Title"
        loc.de_de = "Testtitel"

        dbc = DbcFile.create("LocTest")
        dbc.records.append(cls(id=1, title=loc))

        path = tmp_path / "LocTest.dbc"
        dbc.write(path)

        loaded = DbcFile.read(path)
        assert len(loaded) == 1
        assert loaded.records[0].title.en_us == "Test Title"
        assert loaded.records[0].title.de_de == "Testtitel"
        assert loaded.records[0].title.fr_fr == ""
        assert loaded.records[0].title.flags == 7


# ── DbcFile.upsert ──────────────────────────────────────────────────────


class TestDbcFileUpsert:
    """Tests for the upsert() method (insert-or-replace by id)."""

    def test_upsert_appends_new_record(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.upsert(cls(id=1, value=10, ratio=1.0))
        assert len(dbc) == 1
        assert dbc.records[0].value == 10

    def test_upsert_replaces_existing_record(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.upsert(cls(id=1, value=10, ratio=1.0))
        dbc.upsert(cls(id=1, value=99, ratio=2.0))
        assert len(dbc) == 1
        assert dbc.records[0].value == 99
        assert dbc.records[0].ratio == 2.0

    def test_upsert_multiple_different_ids(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.upsert(cls(id=1, value=1, ratio=0.0))
        dbc.upsert(cls(id=2, value=2, ratio=0.0))
        dbc.upsert(cls(id=3, value=3, ratio=0.0))
        assert len(dbc) == 3

    def test_upsert_replaces_preserves_order(self, register_simple_template):
        """Replace should not change position in the list."""
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.upsert(cls(id=10, value=10, ratio=0.0))
        dbc.upsert(cls(id=20, value=20, ratio=0.0))
        dbc.upsert(cls(id=30, value=30, ratio=0.0))
        # Replace the middle record
        dbc.upsert(cls(id=20, value=99, ratio=0.0))
        assert len(dbc) == 3
        assert dbc.records[0].id == 10
        assert dbc.records[1].id == 20
        assert dbc.records[1].value == 99
        assert dbc.records[2].id == 30

    def test_upsert_idempotent(self, register_simple_template):
        """Upserting the same record twice leaves exactly one record."""
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        rec = cls(id=5, value=42, ratio=3.14)
        dbc.upsert(rec)
        dbc.upsert(rec)
        assert len(dbc) == 1


# ── DbcFile.sort_by_id ──────────────────────────────────────────────────


class TestDbcFileSortById:
    """Tests for the sort_by_id() method."""

    def test_sort_empty(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.sort_by_id()  # should not raise
        assert len(dbc) == 0

    def test_sort_single_record(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.records.append(cls(id=42, value=0, ratio=0.0))
        dbc.sort_by_id()
        assert dbc.records[0].id == 42

    def test_sort_ascending(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        for id_ in [30, 10, 20, 5]:
            dbc.records.append(cls(id=id_, value=0, ratio=0.0))
        dbc.sort_by_id()
        ids = [r.id for r in dbc.records]
        assert ids == [5, 10, 20, 30]

    def test_sort_already_sorted(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        for id_ in [1, 2, 3, 4, 5]:
            dbc.records.append(cls(id=id_, value=0, ratio=0.0))
        dbc.sort_by_id()
        ids = [r.id for r in dbc.records]
        assert ids == [1, 2, 3, 4, 5]

    def test_sort_preserves_values(self, register_simple_template):
        cls = register_simple_template
        dbc = DbcFile.create("SimpleTest")
        dbc.records.append(cls(id=3, value=300, ratio=3.0))
        dbc.records.append(cls(id=1, value=100, ratio=1.0))
        dbc.records.append(cls(id=2, value=200, ratio=2.0))
        dbc.sort_by_id()
        assert dbc.records[0].value == 100
        assert dbc.records[1].value == 200
        assert dbc.records[2].value == 300
