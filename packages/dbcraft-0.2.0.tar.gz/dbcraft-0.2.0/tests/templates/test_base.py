"""Tests for dbcraft.templates.base module."""

from __future__ import annotations

import struct
from dataclasses import dataclass

import pytest

from dbcraft.core.string_block import StringBlockBuilder, StringBlockReader
from dbcraft.core.types import (
    LOC_FIELD_COUNT,
    LocalizedString,
    float32,
    int8,
    int32,
    loc_string_ref,
    string_ref,
    uint32,
)
from dbcraft.templates.base import (
    _TEMPLATE_REGISTRY,
    _resolve_type_name,
    deserialize_record,
    get_all_templates,
    get_field_count,
    get_record_size,
    get_template,
    register_template,
    serialize_record,
)


# --- Test fixtures: simple record dataclass ---


@dataclass
class SimpleRecord:
    id: uint32
    value: int32
    ratio: float32


@dataclass
class StringRecord:
    id: uint32
    name: string_ref


@dataclass
class LocRecord:
    id: uint32
    title: loc_string_ref


@dataclass
class MixedRecord:
    id: uint32
    name: string_ref
    label: loc_string_ref
    count: int32
    weight: float32


@dataclass
class Int8Record:
    id: int8
    kind: int32


class TestResolveTypeName:
    """Test the _resolve_type_name helper."""

    def test_uint32(self) -> None:
        assert _resolve_type_name(uint32) == "uint32"

    def test_int32(self) -> None:
        assert _resolve_type_name(int32) == "int32"

    def test_float32(self) -> None:
        assert _resolve_type_name(float32) == "float32"

    def test_string_ref(self) -> None:
        assert _resolve_type_name(string_ref) == "string_ref"

    def test_loc_string_ref(self) -> None:
        assert _resolve_type_name(loc_string_ref) == "loc_string_ref"

    def test_unknown_type_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown field type"):
            _resolve_type_name(dict)

    def test_int8(self) -> None:
        assert _resolve_type_name(int8) == "int8"


class TestRegistry:
    """Test template registration and lookup."""

    def test_register_and_get(self) -> None:
        # Save original registry state
        original = dict(_TEMPLATE_REGISTRY)
        try:

            @register_template("TestDBC")
            @dataclass
            class TestDBCRecord:
                id: uint32

            result = get_template("TestDBC")
            assert result is TestDBCRecord
        finally:
            # Restore registry
            _TEMPLATE_REGISTRY.clear()
            _TEMPLATE_REGISTRY.update(original)

    def test_get_template_not_found(self) -> None:
        with pytest.raises(KeyError, match="No template registered"):
            get_template("NonExistentDBC")

    def test_get_all_templates(self) -> None:
        original = dict(_TEMPLATE_REGISTRY)
        try:

            @register_template("AllTest1")
            @dataclass
            class AllTest1Record:
                id: uint32

            @register_template("AllTest2")
            @dataclass
            class AllTest2Record:
                id: uint32

            all_templates = get_all_templates()
            assert "AllTest1" in all_templates
            assert "AllTest2" in all_templates
            assert all_templates["AllTest1"] is AllTest1Record
            # Verify it's a copy
            all_templates["AllTest3"] = SimpleRecord
            assert "AllTest3" not in _TEMPLATE_REGISTRY
        finally:
            _TEMPLATE_REGISTRY.clear()
            _TEMPLATE_REGISTRY.update(original)


class TestGetFieldCount:
    """Test field count calculation from record templates."""

    def test_simple_record(self) -> None:
        # uint32 + int32 + float32 = 3 fields
        assert get_field_count(SimpleRecord) == 3

    def test_string_record(self) -> None:
        # uint32 + string_ref = 2 fields
        assert get_field_count(StringRecord) == 2

    def test_loc_record(self) -> None:
        # uint32 + loc_string_ref (17) = 18 fields
        assert get_field_count(LocRecord) == 1 + LOC_FIELD_COUNT

    def test_mixed_record(self) -> None:
        # uint32 + string_ref + loc_string_ref(17) + int32 + float32 = 21
        assert get_field_count(MixedRecord) == 1 + 1 + LOC_FIELD_COUNT + 1 + 1


class TestGetRecordSize:
    def test_simple_record(self) -> None:
        assert get_record_size(SimpleRecord) == 12

    def test_loc_record(self) -> None:
        assert get_record_size(LocRecord) == (1 * 4) + (LOC_FIELD_COUNT * 4)

    def test_int8_record(self) -> None:
        assert get_field_count(Int8Record) == 2
        assert get_record_size(Int8Record) == 5


class TestDeserializeRecord:
    """Test deserialization of binary data to record instances."""

    def test_simple_record(self) -> None:
        data = struct.pack("<Iif", 42, -10, 3.14)
        string_block = StringBlockReader(b"\x00")

        record = deserialize_record(SimpleRecord, data, 0, string_block)
        assert record.id == 42
        assert record.value == -10
        assert abs(record.ratio - 3.14) < 0.001

    def test_string_record(self) -> None:
        # String block: \x00hello\x00
        block_data = b"\x00hello\x00"
        string_block = StringBlockReader(block_data)

        # Record: id=1, name_offset=1
        data = struct.pack("<II", 1, 1)
        record = deserialize_record(StringRecord, data, 0, string_block)
        assert record.id == 1
        assert record.name == "hello"

    def test_loc_record(self) -> None:
        # String block: \x00Fireball\x00
        block_data = b"\x00Fireball\x00"
        string_block = StringBlockReader(block_data)

        # Record: id=100, then 16 locale offsets + 1 flags
        values = [100]  # id
        values.append(1)  # en_us -> "Fireball"
        values.extend([0] * 15)  # other locales -> ""
        values.append(0xFF)  # flags
        data = struct.pack(f"<{len(values)}I", *values)

        record = deserialize_record(LocRecord, data, 0, string_block)
        assert record.id == 100
        assert record.title.en_us == "Fireball"
        assert record.title.fr_fr == ""
        assert record.title.flags == 0xFF

    def test_deserialize_with_offset(self) -> None:
        # Prepend 8 bytes of junk before the actual record
        junk = b"\xff" * 8
        record_data = struct.pack("<Iif", 99, 7, 1.5)
        data = junk + record_data
        string_block = StringBlockReader(b"\x00")

        record = deserialize_record(SimpleRecord, data, 8, string_block)
        assert record.id == 99
        assert record.value == 7
        assert abs(record.ratio - 1.5) < 0.001

    def test_int8_record(self) -> None:
        data = struct.pack("<bi", -2, 123)
        string_block = StringBlockReader(b"\x00")
        record = deserialize_record(Int8Record, data, 0, string_block)
        assert record.id == -2
        assert record.kind == 123


class TestSerializeRecord:
    """Test serialization of record instances to binary data."""

    def test_simple_record(self) -> None:
        record = SimpleRecord(id=uint32(42), value=int32(-10), ratio=float32(3.14))
        builder = StringBlockBuilder()

        data = serialize_record(record, builder)
        # Should be 12 bytes (3 x 4)
        assert len(data) == 12

        id_val, val, ratio = struct.unpack("<Iif", data)
        assert id_val == 42
        assert val == -10
        assert abs(ratio - 3.14) < 0.001

    def test_string_record(self) -> None:
        record = StringRecord(id=uint32(1), name=string_ref("hello"))
        builder = StringBlockBuilder()

        data = serialize_record(record, builder)
        assert len(data) == 8

        id_val, name_offset = struct.unpack("<II", data)
        assert id_val == 1
        # Verify the string is in the builder's block
        block = builder.build()
        reader = StringBlockReader(block)
        assert reader.get(name_offset) == "hello"

    def test_loc_record(self) -> None:
        loc = LocalizedString()
        loc.en_us = "Fireball"
        loc.flags = 0xFF

        record = LocRecord(id=uint32(100), title=loc_string_ref(loc))
        builder = StringBlockBuilder()

        data = serialize_record(record, builder)
        # 1 (id) + 17 (loc) = 18 fields = 72 bytes
        assert len(data) == 72

        # Parse back
        values = struct.unpack(f"<{18}I", data)
        assert values[0] == 100  # id
        # en_us offset should be non-zero (since "Fireball" != "")
        assert values[1] != 0
        # Other locale offsets should be 0 (empty string)
        for i in range(2, 17):
            assert values[i] == 0
        # flags
        assert values[17] == 0xFF

        # Verify string via block
        block = builder.build()
        reader = StringBlockReader(block)
        assert reader.get(values[1]) == "Fireball"

    def test_empty_string_serialization(self) -> None:
        record = StringRecord(id=uint32(1), name=string_ref(""))
        builder = StringBlockBuilder()

        data = serialize_record(record, builder)
        _, name_offset = struct.unpack("<II", data)
        assert name_offset == 0  # Empty strings always get offset 0

    def test_int8_record(self) -> None:
        record = Int8Record(id=int8(-3), kind=int32(77))
        builder = StringBlockBuilder()
        data = serialize_record(record, builder)
        assert len(data) == 5
        id_val, kind_val = struct.unpack("<bi", data)
        assert id_val == -3
        assert kind_val == 77


class TestSerializeDeserializeRoundtrip:
    """Test that serialize -> deserialize produces identical records."""

    def test_simple_roundtrip(self) -> None:
        original = SimpleRecord(
            id=uint32(42), value=int32(-10), ratio=float32(3.14)
        )
        builder = StringBlockBuilder()
        data = serialize_record(original, builder)
        block = builder.build()
        reader = StringBlockReader(block)

        restored = deserialize_record(SimpleRecord, data, 0, reader)
        assert restored.id == original.id
        assert restored.value == original.value
        assert abs(restored.ratio - original.ratio) < 0.001

    def test_string_roundtrip(self) -> None:
        original = StringRecord(id=uint32(5), name=string_ref("Test Name"))
        builder = StringBlockBuilder()
        data = serialize_record(original, builder)
        block = builder.build()
        reader = StringBlockReader(block)

        restored = deserialize_record(StringRecord, data, 0, reader)
        assert restored.id == original.id
        assert restored.name == original.name

    def test_loc_roundtrip(self) -> None:
        loc = LocalizedString()
        loc.en_us = "Fireball"
        loc.de_de = "Feuerball"
        loc.fr_fr = "Boule de feu"
        loc.flags = 0x7

        original = LocRecord(id=uint32(133), title=loc_string_ref(loc))
        builder = StringBlockBuilder()
        data = serialize_record(original, builder)
        block = builder.build()
        reader = StringBlockReader(block)

        restored = deserialize_record(LocRecord, data, 0, reader)
        assert restored.id == original.id
        assert restored.title == original.title

    def test_mixed_roundtrip(self) -> None:
        loc = LocalizedString()
        loc.en_us = "Label"

        original = MixedRecord(
            id=uint32(1),
            name=string_ref("TestName"),
            label=loc_string_ref(loc),
            count=int32(-5),
            weight=float32(2.5),
        )
        builder = StringBlockBuilder()
        data = serialize_record(original, builder)
        block = builder.build()
        reader = StringBlockReader(block)

        restored = deserialize_record(MixedRecord, data, 0, reader)
        assert restored.id == original.id
        assert restored.name == original.name
        assert restored.label == original.label
        assert restored.count == original.count
        assert abs(restored.weight - original.weight) < 0.001
