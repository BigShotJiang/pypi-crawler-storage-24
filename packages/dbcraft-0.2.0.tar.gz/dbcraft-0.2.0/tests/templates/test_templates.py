"""Tests for DBC template definitions.

Tests field counts, registration, construction, and write/read roundtrips
for all 13 template record types.
"""

from __future__ import annotations

import pytest

from dbcraft.core.reader import read_dbc
from dbcraft.core.types import LocalizedString
from dbcraft.core.writer import write_dbc
from dbcraft.templates.base import get_field_count, get_template

# Import templates to trigger registration
from dbcraft.templates.char_titles import CharTitlesRecord
from dbcraft.templates.chr_classes import ChrClassesRecord
from dbcraft.templates.chr_races import ChrRacesRecord
from dbcraft.templates.item import ItemRecord
from dbcraft.templates.item_display_info import ItemDisplayInfoRecord
from dbcraft.templates.item_extended_cost import ItemExtendedCostRecord
from dbcraft.templates.map import MapRecord
from dbcraft.templates.skill_line import SkillLineRecord
from dbcraft.templates.skill_line_ability import SkillLineAbilityRecord
from dbcraft.templates.skill_race_class_info import SkillRaceClassInfoRecord
from dbcraft.templates.skill_tiers import SkillTiersRecord
from dbcraft.templates.spell import SpellRecord
from dbcraft.templates.spell_icon import SpellIconRecord


# ── CharTitles ───────────────────────────────────────────────────────────


class TestCharTitlesTemplate:
    def test_registered(self):
        assert get_template("CharTitles") is CharTitlesRecord

    def test_field_count(self):
        assert get_field_count(CharTitlesRecord) == 37

    def test_construct(self):
        loc_m = LocalizedString()
        loc_m.en_us = "Champion"
        loc_f = LocalizedString()
        loc_f.en_us = "Champion"
        rec = CharTitlesRecord(
            id=1,
            condition_id=0,
            name_lang=loc_m,
            name1_lang=loc_f,
            mask_id=42,
        )
        assert rec.id == 1
        assert rec.name_lang.en_us == "Champion"
        assert rec.mask_id == 42

    def test_roundtrip(self):
        loc_m = LocalizedString()
        loc_m.en_us = "of the Alliance"
        loc_f = LocalizedString()
        loc_f.en_us = "of the Alliance"
        rec = CharTitlesRecord(
            id=1, condition_id=0, name_lang=loc_m,
            name1_lang=loc_f, mask_id=5,
        )
        data = write_dbc([rec], CharTitlesRecord)
        _, records = read_dbc(data, CharTitlesRecord)
        assert len(records) == 1
        assert records[0].id == 1
        assert records[0].name_lang.en_us == "of the Alliance"
        assert records[0].mask_id == 5


# ── Map ──────────────────────────────────────────────────────────────────


class TestMapTemplate:
    def test_registered(self):
        assert get_template("Map") is MapRecord

    def test_field_count(self):
        assert get_field_count(MapRecord) == 66

    def test_construct(self):
        name = LocalizedString()
        name.en_us = "Eastern Kingdoms"
        desc_a = LocalizedString()
        desc_h = LocalizedString()
        rec = MapRecord(
            id=0, directory="Azeroth", instance_type=0, flags=0,
            p_v_p=0,
            map_name_lang=name, area_table_id=0,
            map_description0_lang=desc_a, map_description1_lang=desc_h,
            loading_screen_id=0, minimap_icon_scale=1.0,
            corpse_map_id=-1, corpse_0=0.0, corpse_1=0.0,
            time_of_day_override=-1, expansion_id=0,
            raid_offset=0, max_players=0,
        )
        assert rec.directory == "Azeroth"
        assert rec.map_name_lang.en_us == "Eastern Kingdoms"
        assert rec.corpse_map_id == -1

    def test_roundtrip(self):
        name = LocalizedString()
        name.en_us = "Test Map"
        desc_a = LocalizedString()
        desc_a.en_us = "Alliance desc"
        desc_h = LocalizedString()
        desc_h.en_us = "Horde desc"
        rec = MapRecord(
            id=999, directory="TestDir", instance_type=1, flags=0,
            p_v_p=0,
            map_name_lang=name, area_table_id=100,
            map_description0_lang=desc_a, map_description1_lang=desc_h,
            loading_screen_id=5, minimap_icon_scale=0.75,
            corpse_map_id=0, corpse_0=1.5, corpse_1=-2.5,
            time_of_day_override=-1, expansion_id=2,
            raid_offset=0, max_players=25,
        )
        data = write_dbc([rec], MapRecord)
        _, records = read_dbc(data, MapRecord)
        r = records[0]
        assert r.id == 999
        assert r.directory == "TestDir"
        assert r.map_name_lang.en_us == "Test Map"
        assert r.map_description0_lang.en_us == "Alliance desc"
        assert r.map_description1_lang.en_us == "Horde desc"
        assert abs(r.minimap_icon_scale - 0.75) < 1e-5
        assert r.corpse_map_id == 0
        assert abs(r.corpse_0 - 1.5) < 1e-5
        assert abs(r.corpse_1 - (-2.5)) < 1e-5
        assert r.time_of_day_override == -1
        assert r.expansion_id == 2
        assert r.max_players == 25


# ── ChrRaces ─────────────────────────────────────────────────────────────


class TestChrRacesTemplate:
    def test_registered(self):
        assert get_template("ChrRaces") is ChrRacesRecord

    def test_field_count(self):
        assert get_field_count(ChrRacesRecord) == 69

    def test_construct(self):
        name = LocalizedString()
        name.en_us = "Human"
        name_f = LocalizedString()
        name_m = LocalizedString()
        rec = ChrRacesRecord(
            id=1, flags=0, faction_id=1, exploration_sound_id=0,
            male_display_id=49, female_display_id=50,
            client_prefix="Hu",
            base_language=7, creature_type=7,
            res_sickness_spell_id=15007, splash_sound_id=1096,
            client_file_string="Human", cinematic_sequence_id=81,
            alliance=0,
            name_lang=name, name_female_lang=name_f, name_male_lang=name_m,
            facial_hair_customization_0="", facial_hair_customization_1="",
            hair_customization="", required_expansion=0,
        )
        assert rec.client_prefix == "Hu"
        assert rec.name_lang.en_us == "Human"

    def test_roundtrip(self):
        name = LocalizedString()
        name.en_us = "Orc"
        name.de_de = "Ork"
        name_f = LocalizedString()
        name_m = LocalizedString()
        rec = ChrRacesRecord(
            id=2, flags=0, faction_id=2, exploration_sound_id=0,
            male_display_id=51, female_display_id=52,
            client_prefix="Or",
            base_language=1, creature_type=7,
            res_sickness_spell_id=15007, splash_sound_id=1096,
            client_file_string="Orc", cinematic_sequence_id=21,
            alliance=0,
            name_lang=name, name_female_lang=name_f, name_male_lang=name_m,
            facial_hair_customization_0="Hair",
            facial_hair_customization_1="Earrings",
            hair_customization="Normal",
            required_expansion=0,
        )
        data = write_dbc([rec], ChrRacesRecord)
        _, records = read_dbc(data, ChrRacesRecord)
        r = records[0]
        assert r.id == 2
        assert r.name_lang.en_us == "Orc"
        assert r.name_lang.de_de == "Ork"
        assert r.client_file_string == "Orc"
        assert r.facial_hair_customization_0 == "Hair"
        assert r.facial_hair_customization_1 == "Earrings"
        assert r.hair_customization == "Normal"


# ── ChrClasses ───────────────────────────────────────────────────────────


class TestChrClassesTemplate:
    def test_registered(self):
        assert get_template("ChrClasses") is ChrClassesRecord

    def test_field_count(self):
        assert get_field_count(ChrClassesRecord) == 60

    def test_construct(self):
        name = LocalizedString()
        name.en_us = "Warrior"
        name_f = LocalizedString()
        name_m = LocalizedString()
        rec = ChrClassesRecord(
            id=1, damage_bonus_stat=0, display_power=1,
            pet_name_token="PET",
            name_lang=name, name_female_lang=name_f, name_male_lang=name_m,
            filename="WARRIOR", spell_class_set=4,
            flags=0, cinematic_sequence_id=0, required_expansion=0,
        )
        assert rec.name_lang.en_us == "Warrior"
        assert rec.display_power == 1

    def test_roundtrip(self):
        name = LocalizedString()
        name.en_us = "Death Knight"
        name_f = LocalizedString()
        name_f.en_us = "Death Knight"
        name_m = LocalizedString()
        name_m.en_us = "Death Knight"
        rec = ChrClassesRecord(
            id=6, damage_bonus_stat=9, display_power=6,
            pet_name_token="PET",
            name_lang=name, name_female_lang=name_f, name_male_lang=name_m,
            filename="DEATHKNIGHT", spell_class_set=15,
            flags=0, cinematic_sequence_id=165, required_expansion=2,
        )
        data = write_dbc([rec], ChrClassesRecord)
        _, records = read_dbc(data, ChrClassesRecord)
        r = records[0]
        assert r.id == 6
        assert r.name_lang.en_us == "Death Knight"
        assert r.name_female_lang.en_us == "Death Knight"
        assert r.filename == "DEATHKNIGHT"
        assert r.spell_class_set == 15
        assert r.cinematic_sequence_id == 165
        assert r.required_expansion == 2


# ── Spell ────────────────────────────────────────────────────────────────


class TestSpellTemplate:
    def test_registered(self):
        assert get_template("Spell") is SpellRecord

    def test_field_count(self):
        assert get_field_count(SpellRecord) == 234

    def _make_spell(self, **kwargs) -> SpellRecord:
        """Create a SpellRecord with sensible defaults."""
        defaults = dict(
            id=1, category=0, dispel_type=0, mechanic=0,
            attributes=0, attributes_ex=0, attributes_ex_b=0,
            attributes_ex_c=0, attributes_ex_d=0, attributes_ex_e=0,
            attributes_ex_f=0, attributes_ex_g=0,
            shapeshift_mask_0=0, shapeshift_mask_1=0,
            shapeshift_exclude_0=0, shapeshift_exclude_1=0,
            targets=0, target_creature_type=0, requires_spell_focus=0,
            facing_caster_flags=0,
            caster_aura_state=0, target_aura_state=0,
            exclude_caster_aura_state=0, exclude_target_aura_state=0,
            caster_aura_spell=0, target_aura_spell=0,
            exclude_caster_aura_spell=0, exclude_target_aura_spell=0,
            casting_time_index=1, recovery_time=0,
            category_recovery_time=0,
            interrupt_flags=0, aura_interrupt_flags=0,
            channel_interrupt_flags=0,
            proc_type_mask=0, proc_chance=0, proc_charges=0,
            max_level=0, base_level=1, spell_level=1,
            duration_index=0, power_type=0, mana_cost=0,
            mana_cost_per_level=0, mana_per_second=0,
            mana_per_second_per_level=0, range_index=1,
            speed=0.0, modal_next_spell=0, cumulative_aura=0,
            totem_0=0, totem_1=0,
            reagent_0=0, reagent_1=0, reagent_2=0, reagent_3=0,
            reagent_4=0, reagent_5=0, reagent_6=0, reagent_7=0,
            reagent_count_0=0, reagent_count_1=0, reagent_count_2=0,
            reagent_count_3=0, reagent_count_4=0, reagent_count_5=0,
            reagent_count_6=0, reagent_count_7=0,
            equipped_item_class=-1, equipped_item_subclass=0,
            equipped_item_inv_types=0,
            effect_0=0, effect_1=0, effect_2=0,
            effect_die_sides_0=0, effect_die_sides_1=0,
            effect_die_sides_2=0,
            effect_real_points_per_level_0=0.0,
            effect_real_points_per_level_1=0.0,
            effect_real_points_per_level_2=0.0,
            effect_base_points_0=0, effect_base_points_1=0,
            effect_base_points_2=0,
            effect_mechanic_0=0, effect_mechanic_1=0,
            effect_mechanic_2=0,
            implicit_target_a_0=0, implicit_target_a_1=0,
            implicit_target_a_2=0,
            implicit_target_b_0=0, implicit_target_b_1=0,
            implicit_target_b_2=0,
            effect_radius_index_0=0, effect_radius_index_1=0,
            effect_radius_index_2=0,
            effect_aura_0=0, effect_aura_1=0,
            effect_aura_2=0,
            effect_aura_period_0=0, effect_aura_period_1=0,
            effect_aura_period_2=0,
            effect_amplitude_0=0.0, effect_amplitude_1=0.0,
            effect_amplitude_2=0.0,
            effect_chain_targets_0=0, effect_chain_targets_1=0,
            effect_chain_targets_2=0,
            effect_item_type_0=0, effect_item_type_1=0,
            effect_item_type_2=0,
            effect_misc_value_0=0, effect_misc_value_1=0,
            effect_misc_value_2=0,
            effect_misc_value_b_0=0, effect_misc_value_b_1=0,
            effect_misc_value_b_2=0,
            effect_trigger_spell_0=0, effect_trigger_spell_1=0,
            effect_trigger_spell_2=0,
            effect_points_per_combo_0=0.0,
            effect_points_per_combo_1=0.0,
            effect_points_per_combo_2=0.0,
            effect_spell_class_mask_a_0=0, effect_spell_class_mask_a_1=0,
            effect_spell_class_mask_a_2=0,
            effect_spell_class_mask_b_0=0, effect_spell_class_mask_b_1=0,
            effect_spell_class_mask_b_2=0,
            effect_spell_class_mask_c_0=0, effect_spell_class_mask_c_1=0,
            effect_spell_class_mask_c_2=0,
            spell_visual_id_0=0, spell_visual_id_1=0,
            spell_icon_id=0, active_icon_id=0, spell_priority=0,
            name_lang=LocalizedString(),
            name_subtext_lang=LocalizedString(),
            description_lang=LocalizedString(),
            aura_description_lang=LocalizedString(),
            mana_cost_pct=0,
            start_recovery_category=0, start_recovery_time=0,
            max_target_level=0,
            spell_class_set=0, spell_class_mask_0=0,
            spell_class_mask_1=0, spell_class_mask_2=0,
            max_targets=0, defense_type=0,
            prevention_type=0, stance_bar_order=0,
            effect_chain_amplitude_0=0.0, effect_chain_amplitude_1=0.0,
            effect_chain_amplitude_2=0.0,
            min_faction_id=0, min_reputation=0,
            required_aura_vision=0,
            required_totem_category_id_0=0, required_totem_category_id_1=0,
            required_areas_id=0, school_mask=0,
            rune_cost_id=0, spell_missile_id=0,
            power_display_id=0,
            effect_bonus_coefficient_0=0.0, effect_bonus_coefficient_1=0.0,
            effect_bonus_coefficient_2=0.0,
            description_variables_id=0, difficulty=0,
        )
        defaults.update(kwargs)
        return SpellRecord(**defaults)

    def test_construct(self):
        name = LocalizedString()
        name.en_us = "Fireball"
        rec = self._make_spell(id=133, name_lang=name, mana_cost=200)
        assert rec.id == 133
        assert rec.name_lang.en_us == "Fireball"
        assert rec.mana_cost == 200

    def test_roundtrip(self):
        name = LocalizedString()
        name.en_us = "Fireball"
        name.de_de = "Feuerball"
        subtext = LocalizedString()
        subtext.en_us = "Rank 1"
        desc = LocalizedString()
        desc.en_us = "Hurls a fiery ball."
        tip = LocalizedString()
        tip.en_us = "Deals fire damage."
        rec = self._make_spell(
            id=133,
            name_lang=name,
            name_subtext_lang=subtext,
            description_lang=desc,
            aura_description_lang=tip,
            mana_cost=200,
            speed=24.0,
            effect_0=6,
            effect_base_points_0=14,
            effect_die_sides_0=12,
            school_mask=4,
        )
        data = write_dbc([rec], SpellRecord)
        _, records = read_dbc(data, SpellRecord)
        r = records[0]
        assert r.id == 133
        assert r.name_lang.en_us == "Fireball"
        assert r.name_lang.de_de == "Feuerball"
        assert r.name_subtext_lang.en_us == "Rank 1"
        assert r.description_lang.en_us == "Hurls a fiery ball."
        assert r.aura_description_lang.en_us == "Deals fire damage."
        assert r.mana_cost == 200
        assert abs(r.speed - 24.0) < 1e-5
        assert r.effect_0 == 6
        assert r.effect_base_points_0 == 14
        assert r.school_mask == 4

    def test_multiple_spells_roundtrip(self):
        s1 = self._make_spell(id=1, mana_cost=100)
        s1.name_lang.en_us = "Spell One"
        s2 = self._make_spell(id=2, mana_cost=200)
        s2.name_lang.en_us = "Spell Two"
        data = write_dbc([s1, s2], SpellRecord)
        _, records = read_dbc(data, SpellRecord)
        assert len(records) == 2
        assert records[0].id == 1
        assert records[0].name_lang.en_us == "Spell One"
        assert records[1].id == 2
        assert records[1].name_lang.en_us == "Spell Two"


# ── Item ─────────────────────────────────────────────────────────────────


class TestItemTemplate:
    def test_registered(self):
        assert get_template("Item") is ItemRecord

    def test_field_count(self):
        assert get_field_count(ItemRecord) == 8

    def test_construct(self):
        rec = ItemRecord(
            id=12345,
            class_id=4,
            subclass_id=0,
            sound_override_subclass_id=-1,
            material=-1,
            display_info_id=60202,
            inventory_type=1,
            sheathe_type=0,
        )
        assert rec.id == 12345
        assert rec.class_id == 4
        assert rec.sound_override_subclass_id == -1
        assert rec.material == -1

    def test_roundtrip(self):
        rec = ItemRecord(
            id=99999,
            class_id=2,
            subclass_id=7,
            sound_override_subclass_id=-1,
            material=1,
            display_info_id=40000,
            inventory_type=17,
            sheathe_type=3,
        )
        data = write_dbc([rec], ItemRecord)
        _, records = read_dbc(data, ItemRecord)
        r = records[0]
        assert r.id == 99999
        assert r.class_id == 2
        assert r.subclass_id == 7
        assert r.sound_override_subclass_id == -1
        assert r.material == 1
        assert r.display_info_id == 40000
        assert r.inventory_type == 17
        assert r.sheathe_type == 3


# ── ItemDisplayInfo ───────────────────────────────────────────────────────


class TestItemDisplayInfoTemplate:
    def test_registered(self):
        assert get_template("ItemDisplayInfo") is ItemDisplayInfoRecord

    def test_field_count(self):
        assert get_field_count(ItemDisplayInfoRecord) == 25

    def test_construct(self):
        rec = ItemDisplayInfoRecord(
            id=60202,
            model_name_0="",
            model_name_1="",
            model_texture_0="",
            model_texture_1="",
            inventory_icon_0="INV_Misc_Coin_01",
            inventory_icon_1="",
            geoset_group_0=0,
            geoset_group_1=0,
            geoset_group_2=0,
            flags=0,
            spell_visual_id=0,
            group_sound_index=0,
            helmet_geoset_vis_id_0=0,
            helmet_geoset_vis_id_1=0,
            texture_0="",
            texture_1="",
            texture_2="",
            texture_3="",
            texture_4="",
            texture_5="",
            texture_6="",
            texture_7="",
            item_visual=0,
            particle_color_id=0,
        )
        assert rec.id == 60202
        assert rec.inventory_icon_0 == "INV_Misc_Coin_01"

    def test_roundtrip(self):
        rec = ItemDisplayInfoRecord(
            id=70001,
            model_name_0="",
            model_name_1="",
            model_texture_0="",
            model_texture_1="",
            inventory_icon_0="INV_Sword_01",
            inventory_icon_1="",
            geoset_group_0=1,
            geoset_group_1=0,
            geoset_group_2=0,
            flags=4,
            spell_visual_id=0,
            group_sound_index=3,
            helmet_geoset_vis_id_0=0,
            helmet_geoset_vis_id_1=0,
            texture_0="",
            texture_1="",
            texture_2="",
            texture_3="",
            texture_4="",
            texture_5="",
            texture_6="",
            texture_7="",
            item_visual=0,
            particle_color_id=0,
        )
        data = write_dbc([rec], ItemDisplayInfoRecord)
        _, records = read_dbc(data, ItemDisplayInfoRecord)
        r = records[0]
        assert r.id == 70001
        assert r.inventory_icon_0 == "INV_Sword_01"
        assert r.geoset_group_0 == 1
        assert r.flags == 4
        assert r.group_sound_index == 3


# ── ItemExtendedCost ─────────────────────────────────────────────────────


class TestItemExtendedCostTemplate:
    def test_registered(self):
        assert get_template("ItemExtendedCost") is ItemExtendedCostRecord

    def test_field_count(self):
        assert get_field_count(ItemExtendedCostRecord) == 16

    def test_construct(self):
        rec = ItemExtendedCostRecord(
            id=1001,
            honor_points=500,
            arena_points=0,
            arena_bracket=0,
            item_id_0=0,
            item_id_1=0,
            item_id_2=0,
            item_id_3=0,
            item_id_4=0,
            item_count_0=0,
            item_count_1=0,
            item_count_2=0,
            item_count_3=0,
            item_count_4=0,
            required_arena_rating=0,
            item_purchase_group=0,
        )
        assert rec.id == 1001
        assert rec.honor_points == 500

    def test_roundtrip(self):
        rec = ItemExtendedCostRecord(
            id=2002,
            honor_points=0,
            arena_points=150,
            arena_bracket=1,
            item_id_0=40752,
            item_id_1=0,
            item_id_2=0,
            item_id_3=0,
            item_id_4=0,
            item_count_0=2,
            item_count_1=0,
            item_count_2=0,
            item_count_3=0,
            item_count_4=0,
            required_arena_rating=1800,
            item_purchase_group=0,
        )
        data = write_dbc([rec], ItemExtendedCostRecord)
        _, records = read_dbc(data, ItemExtendedCostRecord)
        r = records[0]
        assert r.id == 2002
        assert r.arena_points == 150
        assert r.arena_bracket == 1
        assert r.item_id_0 == 40752
        assert r.item_count_0 == 2
        assert r.required_arena_rating == 1800


# ── SkillLine ─────────────────────────────────────────────────────────────


class TestSkillLineTemplate:
    def test_registered(self):
        assert get_template("SkillLine") is SkillLineRecord

    def test_field_count(self):
        assert get_field_count(SkillLineRecord) == 56

    def test_construct(self):
        name = LocalizedString()
        name.en_us = "Runeforging"
        rec = SkillLineRecord(
            id=776,
            category_id=11,
            skill_costs_id=0,
            display_name_lang=name,
            description_lang=LocalizedString(),
            spell_icon_id=1376,
            alternate_verb_lang=LocalizedString(),
            can_link=1,
        )
        assert rec.id == 776
        assert rec.display_name_lang.en_us == "Runeforging"
        assert rec.category_id == 11

    def test_roundtrip(self):
        name = LocalizedString()
        name.en_us = "Runeforging"
        name.de_de = "Runenschmieden"
        desc = LocalizedString()
        desc.en_us = "The art of forging runes."
        rec = SkillLineRecord(
            id=776,
            category_id=11,
            skill_costs_id=0,
            display_name_lang=name,
            description_lang=desc,
            spell_icon_id=1376,
            alternate_verb_lang=LocalizedString(),
            can_link=1,
        )
        data = write_dbc([rec], SkillLineRecord)
        _, records = read_dbc(data, SkillLineRecord)
        r = records[0]
        assert r.id == 776
        assert r.display_name_lang.en_us == "Runeforging"
        assert r.display_name_lang.de_de == "Runenschmieden"
        assert r.description_lang.en_us == "The art of forging runes."
        assert r.category_id == 11
        assert r.spell_icon_id == 1376
        assert r.can_link == 1


# ── SkillLineAbility ──────────────────────────────────────────────────────


class TestSkillLineAbilityTemplate:
    def test_registered(self):
        assert get_template("SkillLineAbility") is SkillLineAbilityRecord

    def test_field_count(self):
        assert get_field_count(SkillLineAbilityRecord) == 14

    def test_construct(self):
        rec = SkillLineAbilityRecord(
            id=50001,
            skill_line=776,
            spell=54442,
            race_mask=0,
            class_mask=0,
            exclude_race=0,
            exclude_class=0,
            min_skill_line_rank=0,
            superceded_by_spell=0,
            acquire_method=1,
            trivial_skill_line_rank_high=0,
            trivial_skill_line_rank_low=0,
            character_points_0=0,
            character_points_1=0,
        )
        assert rec.id == 50001
        assert rec.skill_line == 776
        assert rec.acquire_method == 1

    def test_roundtrip(self):
        rec = SkillLineAbilityRecord(
            id=50002,
            skill_line=776,
            spell=54443,
            race_mask=0x7FF,
            class_mask=0x5FF,
            exclude_race=0,
            exclude_class=0,
            min_skill_line_rank=75,
            superceded_by_spell=0,
            acquire_method=0,
            trivial_skill_line_rank_high=150,
            trivial_skill_line_rank_low=100,
            character_points_0=0,
            character_points_1=0,
        )
        data = write_dbc([rec], SkillLineAbilityRecord)
        _, records = read_dbc(data, SkillLineAbilityRecord)
        r = records[0]
        assert r.id == 50002
        assert r.skill_line == 776
        assert r.spell == 54443
        assert r.race_mask == 0x7FF
        assert r.class_mask == 0x5FF
        assert r.min_skill_line_rank == 75
        assert r.trivial_skill_line_rank_high == 150
        assert r.trivial_skill_line_rank_low == 100


# ── SkillRaceClassInfo ────────────────────────────────────────────────────


class TestSkillRaceClassInfoTemplate:
    def test_registered(self):
        assert get_template("SkillRaceClassInfo") is SkillRaceClassInfoRecord

    def test_field_count(self):
        assert get_field_count(SkillRaceClassInfoRecord) == 8

    def test_construct(self):
        rec = SkillRaceClassInfoRecord(
            id=1,
            skill_id=776,
            race_mask=0x7FF,
            class_mask=0x5FF,
            flags=0xA0,
            min_level=0,
            skill_tier_id=100,
            skill_cost_index=0,
        )
        assert rec.id == 1
        assert rec.skill_id == 776
        assert rec.flags == 0xA0

    def test_roundtrip(self):
        rec = SkillRaceClassInfoRecord(
            id=42,
            skill_id=186,
            race_mask=0x7FF,
            class_mask=0x5FF,
            flags=0xA0,
            min_level=5,
            skill_tier_id=250,
            skill_cost_index=0,
        )
        data = write_dbc([rec], SkillRaceClassInfoRecord)
        _, records = read_dbc(data, SkillRaceClassInfoRecord)
        r = records[0]
        assert r.id == 42
        assert r.skill_id == 186
        assert r.race_mask == 0x7FF
        assert r.class_mask == 0x5FF
        assert r.flags == 0xA0
        assert r.min_level == 5
        assert r.skill_tier_id == 250


# ── SkillTiers ────────────────────────────────────────────────────────────


class TestSkillTiersTemplate:
    def test_registered(self):
        assert get_template("SkillTiers") is SkillTiersRecord

    def test_field_count(self):
        assert get_field_count(SkillTiersRecord) == 33

    def test_construct(self):
        rec = SkillTiersRecord(
            id=100,
            cost_0=0, cost_1=0, cost_2=0, cost_3=0,
            cost_4=0, cost_5=0, cost_6=0, cost_7=0,
            cost_8=0, cost_9=0, cost_10=0, cost_11=0,
            cost_12=0, cost_13=0, cost_14=0, cost_15=0,
            value_0=75, value_1=150, value_2=225, value_3=300,
            value_4=375, value_5=450, value_6=0, value_7=0,
            value_8=0, value_9=0, value_10=0, value_11=0,
            value_12=0, value_13=0, value_14=0, value_15=0,
        )
        assert rec.id == 100
        assert rec.value_0 == 75
        assert rec.value_5 == 450
        assert rec.value_6 == 0

    def test_roundtrip(self):
        rec = SkillTiersRecord(
            id=200,
            cost_0=1, cost_1=1, cost_2=1, cost_3=1,
            cost_4=1, cost_5=1, cost_6=0, cost_7=0,
            cost_8=0, cost_9=0, cost_10=0, cost_11=0,
            cost_12=0, cost_13=0, cost_14=0, cost_15=0,
            value_0=75, value_1=150, value_2=225, value_3=300,
            value_4=375, value_5=450, value_6=0, value_7=0,
            value_8=0, value_9=0, value_10=0, value_11=0,
            value_12=0, value_13=0, value_14=0, value_15=0,
        )
        data = write_dbc([rec], SkillTiersRecord)
        _, records = read_dbc(data, SkillTiersRecord)
        r = records[0]
        assert r.id == 200
        assert r.cost_0 == 1
        assert r.cost_5 == 1
        assert r.cost_6 == 0
        assert r.value_0 == 75
        assert r.value_5 == 450
        assert r.value_6 == 0


# ── SpellIcon ─────────────────────────────────────────────────────────────


class TestSpellIconTemplate:
    def test_registered(self):
        assert get_template("SpellIcon") is SpellIconRecord

    def test_field_count(self):
        assert get_field_count(SpellIconRecord) == 2

    def test_construct(self):
        rec = SpellIconRecord(
            id=1376,
            texture_filename=r"Interface\Icons\Spell_DeathKnight_ClassSymbol",
        )
        assert rec.id == 1376
        assert "Spell_DeathKnight" in rec.texture_filename

    def test_roundtrip(self):
        rec = SpellIconRecord(
            id=9999,
            texture_filename=r"Interface\Icons\INV_Custom_MyIcon",
        )
        data = write_dbc([rec], SpellIconRecord)
        _, records = read_dbc(data, SpellIconRecord)
        r = records[0]
        assert r.id == 9999
        assert r.texture_filename == r"Interface\Icons\INV_Custom_MyIcon"

    def test_defaults(self):
        rec = SpellIconRecord(id=1)
        assert rec.texture_filename == ""


# ── Default-value tests ───────────────────────────────────────────────────


class TestItemDefaults:
    def test_only_id_required(self):
        rec = ItemRecord(id=1)
        assert rec.class_id == 0
        assert rec.subclass_id == 0
        assert rec.sound_override_subclass_id == 0
        assert rec.material == 0
        assert rec.display_info_id == 0
        assert rec.inventory_type == 0
        assert rec.sheathe_type == 0


class TestItemDisplayInfoDefaults:
    def test_only_id_required(self):
        rec = ItemDisplayInfoRecord(id=1)
        assert rec.model_name_0 == ""
        assert rec.model_name_1 == ""
        assert rec.model_texture_0 == ""
        assert rec.model_texture_1 == ""
        assert rec.inventory_icon_0 == ""
        assert rec.inventory_icon_1 == ""
        assert rec.geoset_group_0 == 0
        assert rec.geoset_group_1 == 0
        assert rec.geoset_group_2 == 0
        assert rec.flags == 0
        assert rec.spell_visual_id == 0
        assert rec.group_sound_index == 0
        assert rec.helmet_geoset_vis_id_0 == 0
        assert rec.helmet_geoset_vis_id_1 == 0
        assert rec.texture_0 == ""
        assert rec.texture_1 == ""
        assert rec.texture_2 == ""
        assert rec.texture_3 == ""
        assert rec.texture_4 == ""
        assert rec.texture_5 == ""
        assert rec.texture_6 == ""
        assert rec.texture_7 == ""
        assert rec.item_visual == 0
        assert rec.particle_color_id == 0


class TestItemExtendedCostDefaults:
    def test_only_id_required(self):
        rec = ItemExtendedCostRecord(id=1)
        assert rec.honor_points == 0
        assert rec.arena_points == 0
        assert rec.arena_bracket == 0
        assert rec.item_id_0 == 0
        assert rec.item_id_1 == 0
        assert rec.item_id_2 == 0
        assert rec.item_id_3 == 0
        assert rec.item_id_4 == 0
        assert rec.item_count_0 == 0
        assert rec.item_count_1 == 0
        assert rec.item_count_2 == 0
        assert rec.item_count_3 == 0
        assert rec.item_count_4 == 0
        assert rec.required_arena_rating == 0
        assert rec.item_purchase_group == 0


class TestSkillLineDefaults:
    def test_only_id_required(self):
        rec = SkillLineRecord(id=1)
        assert rec.category_id == 0
        assert rec.skill_costs_id == 0
        assert rec.display_name_lang.en_us == ""
        assert rec.description_lang.en_us == ""
        assert rec.spell_icon_id == 0
        assert rec.alternate_verb_lang.en_us == ""
        assert rec.can_link == 0

    def test_loc_string_not_shared(self):
        r1 = SkillLineRecord(id=1)
        r2 = SkillLineRecord(id=2)
        r1.display_name_lang.en_us = "Skill A"
        assert r2.display_name_lang.en_us == ""


class TestSkillLineAbilityDefaults:
    def test_only_id_required(self):
        rec = SkillLineAbilityRecord(id=1)
        assert rec.skill_line == 0
        assert rec.spell == 0
        assert rec.race_mask == 0
        assert rec.class_mask == 0
        assert rec.exclude_race == 0
        assert rec.exclude_class == 0
        assert rec.min_skill_line_rank == 0
        assert rec.superceded_by_spell == 0
        assert rec.acquire_method == 0
        assert rec.trivial_skill_line_rank_high == 0
        assert rec.trivial_skill_line_rank_low == 0
        assert rec.character_points_0 == 0
        assert rec.character_points_1 == 0


class TestSkillRaceClassInfoDefaults:
    def test_only_id_required(self):
        rec = SkillRaceClassInfoRecord(id=1)
        assert rec.skill_id == 0
        assert rec.race_mask == 0
        assert rec.class_mask == 0
        assert rec.flags == 0
        assert rec.min_level == 0
        assert rec.skill_tier_id == 0
        assert rec.skill_cost_index == 0


class TestSkillTiersDefaults:
    def test_only_id_required(self):
        rec = SkillTiersRecord(id=1)
        for i in range(16):
            assert getattr(rec, f"cost_{i}") == 0
            assert getattr(rec, f"value_{i}") == 0


class TestSpellDefaults:
    def test_only_id_required(self):
        rec = SpellRecord(id=1)
        assert rec.category == 0
        assert rec.casting_time_index == 0
        assert rec.mana_cost == 0
        assert rec.name_lang.en_us == ""
        assert rec.name_subtext_lang.en_us == ""
        assert rec.description_lang.en_us == ""
        assert rec.aura_description_lang.en_us == ""
        assert rec.school_mask == 0
        assert rec.difficulty == 0

    def test_loc_string_not_shared(self):
        r1 = SpellRecord(id=1)
        r2 = SpellRecord(id=2)
        r1.name_lang.en_us = "My Spell"
        assert r2.name_lang.en_us == ""


class TestCharTitlesDefaults:
    def test_only_id_required(self):
        rec = CharTitlesRecord(id=1)
        assert rec.condition_id == 0
        assert rec.name_lang.en_us == ""
        assert rec.name1_lang.en_us == ""
        assert rec.mask_id == 0

    def test_loc_string_not_shared(self):
        r1 = CharTitlesRecord(id=1)
        r2 = CharTitlesRecord(id=2)
        r1.name_lang.en_us = "Champion"
        assert r2.name_lang.en_us == ""


class TestChrClassesDefaults:
    def test_only_id_required(self):
        rec = ChrClassesRecord(id=1)
        assert rec.damage_bonus_stat == 0
        assert rec.display_power == 0
        assert rec.pet_name_token == ""
        assert rec.name_lang.en_us == ""
        assert rec.name_female_lang.en_us == ""
        assert rec.name_male_lang.en_us == ""
        assert rec.filename == ""
        assert rec.spell_class_set == 0
        assert rec.flags == 0
        assert rec.cinematic_sequence_id == 0
        assert rec.required_expansion == 0


class TestChrRacesDefaults:
    def test_only_id_required(self):
        rec = ChrRacesRecord(id=1)
        assert rec.flags == 0
        assert rec.faction_id == 0
        assert rec.client_prefix == ""
        assert rec.alliance == 0
        assert rec.name_lang.en_us == ""
        assert rec.facial_hair_customization_0 == ""
        assert rec.required_expansion == 0


class TestMapDefaults:
    def test_only_id_required(self):
        rec = MapRecord(id=1)
        assert rec.directory == ""
        assert rec.instance_type == 0
        assert rec.flags == 0
        assert rec.p_v_p == 0
        assert rec.map_name_lang.en_us == ""
        assert rec.area_table_id == 0
        assert rec.map_description0_lang.en_us == ""
        assert rec.map_description1_lang.en_us == ""
        assert rec.loading_screen_id == 0
        assert abs(rec.minimap_icon_scale - 0.0) < 1e-6
        assert rec.corpse_map_id == 0
        assert rec.time_of_day_override == 0
        assert rec.expansion_id == 0
        assert rec.max_players == 0
