"""Shared test fixtures for dbcraft tests."""

from __future__ import annotations

from dataclasses import dataclass

import pytest

from dbcraft.core.types import (
    LocalizedString,
    float32,
    int32,
    loc_string_ref,
    string_ref,
    uint32,
)
from dbcraft.templates.base import _TEMPLATE_REGISTRY, register_template


@dataclass
class SimpleTestRecord:
    """A minimal test record with basic field types."""

    id: uint32
    value: int32
    ratio: float32


@dataclass
class StringTestRecord:
    """A test record with a string_ref field."""

    id: uint32
    name: string_ref


@dataclass
class LocTestRecord:
    """A test record with a loc_string_ref field."""

    id: uint32
    title: loc_string_ref


@pytest.fixture
def register_simple_template():
    """Register SimpleTestRecord as 'SimpleTest' and clean up after."""
    original = dict(_TEMPLATE_REGISTRY)
    register_template("SimpleTest")(SimpleTestRecord)
    yield SimpleTestRecord
    _TEMPLATE_REGISTRY.clear()
    _TEMPLATE_REGISTRY.update(original)


@pytest.fixture
def register_string_template():
    """Register StringTestRecord as 'StringTest' and clean up after."""
    original = dict(_TEMPLATE_REGISTRY)
    register_template("StringTest")(StringTestRecord)
    yield StringTestRecord
    _TEMPLATE_REGISTRY.clear()
    _TEMPLATE_REGISTRY.update(original)


@pytest.fixture
def register_loc_template():
    """Register LocTestRecord as 'LocTest' and clean up after."""
    original = dict(_TEMPLATE_REGISTRY)
    register_template("LocTest")(LocTestRecord)
    yield LocTestRecord
    _TEMPLATE_REGISTRY.clear()
    _TEMPLATE_REGISTRY.update(original)
