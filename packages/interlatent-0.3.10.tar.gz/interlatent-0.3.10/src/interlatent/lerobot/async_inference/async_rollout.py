"""Interlatent-instrumented backend for lerobot async inference.

Extends lerobot's PolicyServer with Interlatent activation capture.
The client side is lerobot's unmodified RobotClient.

Usage (drop-in replacement for lerobot's policy_server):
    interlatent-rollout --host=0.0.0.0 --port=8080 --fps=30 --layer=auto

The model name is derived from the policy path sent by the robot client
in SendPolicyInstructions. For a HuggingFace repo "org/model-name" this
becomes "model-name"; for a local file it becomes the basename without
extension. Override with --model-name if needed.

The environment and model must already exist in the Interlatent dashboard.
The SDK matches the model by env_name + layer.

Then run lerobot's robot client as normal:
    python -m lerobot.async_inference.robot_client \\
        --robot.type=so100_follower ... \\
        --server_address=HOST:8080
"""

import argparse
import os
import pickle  # nosec
import time
import logging
import signal
from concurrent import futures

import grpc
import numpy as np

from lerobot.async_inference.configs import PolicyServerConfig
from lerobot.async_inference.constants import SUPPORTED_POLICIES
from lerobot.async_inference.helpers import RemotePolicyConfig
from lerobot.async_inference.policy_server import PolicyServer
from lerobot.configs.types import RTCAttentionSchedule
from lerobot.policies.factory import get_policy_class, make_pre_post_processors
from lerobot.policies.rtc.configuration_rtc import RTCConfig
from lerobot.transport import services_pb2, services_pb2_grpc
from lerobot.utils.import_utils import register_third_party_plugins

logger = logging.getLogger(__name__)


def _get_model_name(policy_path: str | None, override: str | None = None) -> str:
    """Derive the model name from a policy path.

    - If override is provided, use it directly.
    - HF repo ID "org/model-name" -> "model-name"
    - Local file "/path/to/model.pt" -> "model"
    - None / fallback: current unix timestamp string
    """
    if override:
        return override
    if policy_path is None:
        return str(int(time.time()))
    if "/" in policy_path and not os.path.exists(policy_path):
        return policy_path.split("/")[-1]
    basename = os.path.basename(policy_path)
    name = os.path.splitext(basename)[0]
    return name or basename or str(int(time.time()))


def _proprio_context_fn(*, obs, reward, done, truncated, info):
    """context_fn for watch(): promotes named proprioception from info into ctx."""
    if info and "_proprio" in info:
        return {"observations": info["_proprio"]}
    return {}


class InterlatentPolicyServer(PolicyServer):
    """PolicyServer extended with Interlatent activation capture.

    Hooks Interlatent into the policy after it loads, capturing activations
    on every forward pass through the policy network automatically.
    On graceful shutdown, flushes and uploads all captured data to the Interlatent platform.
    """

    def __init__(
        self,
        config: PolicyServerConfig,
        *,
        interlatent_client,
        layer: str = "auto",
        env_name: str | None = None,
        model_name: str | None = None,
        failures: dict[str, str] | None = None,
        successes: dict[str, str] | None = None,
    ) -> None:
        super().__init__(config)
        self._il = interlatent_client
        self._layer = layer
        self._env_name = env_name
        self._model_name = model_name
        self._failures = failures
        self._successes = successes
        self._inference_count = 0

        logger.info(f"InterlatentPolicyServer initialized with layer='{self._layer}', env='{self._env_name}', model='{self._model_name}'")

    # ------------------------------------------------------------------
    # Override: checkpoint when a client session ends (new client connects)
    # ------------------------------------------------------------------

    def Ready(self, request, context):  # noqa: N802
        # A new client is connecting. If the prior session produced data,
        # upload it (no Modal processing — just make frames visible on dashboard).
        if self._il is not None and self._inference_count > 0:
            try:
                logger.info("New client connecting — uploading Interlatent data from prior session...")
                self._il.upload()
                logger.info("Interlatent mid-session upload complete")
            except Exception as exc:
                logger.warning(f"Interlatent mid-session upload failed: {exc}")
            finally:
                self._inference_count = 0

        return super().Ready(request, context)

    # ------------------------------------------------------------------
    # Override: hook Interlatent after policy loads
    # ------------------------------------------------------------------

    def SendPolicyInstructions(self, request, context):  # noqa: N802
        # Load the policy ourselves so we can inject RTC config before
        # make_pre_post_processors consumes policy.config.
        if not self.running:
            self.logger.warning("Server is not running. Ignoring policy instructions.")
            return services_pb2.Empty()

        policy_specs = pickle.loads(request.data)  # nosec

        if not isinstance(policy_specs, RemotePolicyConfig):
            raise TypeError(f"Policy specs must be a RemotePolicyConfig. Got {type(policy_specs)}")

        if policy_specs.policy_type not in SUPPORTED_POLICIES:
            raise ValueError(
                f"Policy type {policy_specs.policy_type} not supported. "
                f"Supported policies: {SUPPORTED_POLICIES}"
            )

        # Derive model name for Interlatent collection
        policy_path = getattr(policy_specs, "pretrained_name_or_path", None)
        model_name = _get_model_name(policy_path, override=self._model_name)

        self.logger.info(
            f"Receiving policy instructions | "
            f"Policy type: {policy_specs.policy_type} | "
            f"Pretrained name or path: {policy_specs.pretrained_name_or_path} | "
            f"Actions per chunk: {policy_specs.actions_per_chunk} | "
            f"Device: {policy_specs.device}"
        )

        self.device = policy_specs.device
        self.policy_type = policy_specs.policy_type
        self.lerobot_features = policy_specs.lerobot_features
        self.actions_per_chunk = policy_specs.actions_per_chunk

        policy_class = get_policy_class(self.policy_type)

        start = time.perf_counter()
        self.policy = policy_class.from_pretrained(policy_specs.pretrained_name_or_path)
        self.policy.to(self.device)

        # Inject RTC config before make_pre_post_processors so it is active
        # from the very first inference chunk.
        self.policy.config.rtc_config = RTCConfig(
            enabled=True,
            execution_horizon=10,
            max_guidance_weight=10.0,
            prefix_attention_schedule=RTCAttentionSchedule.EXP,
        )
        # from_pretrained() calls init_rtc_processor() during __init__ when
        # rtc_config is None, leaving rtc_processor=None. We must re-run it
        # now that rtc_config is set, otherwise _rtc_enabled() returns True
        # but rtc_processor is None → AttributeError silently swallowed by
        # GetActions, which returns Empty() forever (stall at observation 0).
        self.policy.init_rtc_processor()
        logger.info("RTC enabled (EXP schedule, execution_horizon=10)")

        device_override = {"device": self.device}
        self.preprocessor, self.postprocessor = make_pre_post_processors(
            self.policy.config,
            pretrained_path=policy_specs.pretrained_name_or_path,
            preprocessor_overrides={
                "device_processor": device_override,
                "rename_observations_processor": {"rename_map": policy_specs.rename_map},
            },
            postprocessor_overrides={"device_processor": device_override},
        )

        end = time.perf_counter()
        self.logger.info(f"Time taken to put policy on {self.device}: {end - start:.4f} seconds")

        # Hook Interlatent using watch() — the standard SDK flow.
        # model_id is the derived model name; env_name + layer must match
        # an environment + model already created in the dashboard.
        if self._il is not None:
            env_name = self._env_name or f"lerobot_{self.policy_type}"
            self._il.watch(
                self.policy,
                env_name=env_name,
                model_id=model_name.lower().replace(" ", "-"),
                layer=self._layer,
                capture_frames=True,
                context_fn=_proprio_context_fn,
                failure_descriptions=self._failures,
                success_descriptions=self._successes,
            )
            logger.info(f"Interlatent watching policy ({self.policy_type}) on layer '{self._layer}', model_id='{model_name}'")

        return services_pb2.Empty()

    # ------------------------------------------------------------------
    # Override: count inferences and tick Interlatent
    # ------------------------------------------------------------------

    def _predict_action_chunk(self, observation_t):
        result = super()._predict_action_chunk(observation_t)
        self._inference_count += 1

        logger.debug("observation keys: %s", list(observation_t.observation.keys()))

        if self._il is not None:
            raw_obs = observation_t.observation
            frame = None
            named_proprio: dict[str, float] = {}

            image_suffixes = {k.rsplit(".", 1)[-1] for k in (self.policy_image_features or {})}
            for key, value in raw_obs.items():
                if key in image_suffixes:
                    if frame is None:
                        frame = value
                else:
                    try:
                        arr = np.asarray(value).flatten()
                        if len(arr) == 1:
                            named_proprio[key] = float(arr[0])
                        else:
                            for i, v in enumerate(arr):
                                named_proprio[f"{key}_{i}"] = float(v)
                    except Exception:
                        pass

            try:
                self._il.tick(
                    obs=None,
                    frame=frame,
                    info={"_proprio": named_proprio} if named_proprio else None,
                )
            except Exception as exc:
                logger.debug(f"Interlatent tick failed: {exc}")

        return result

    # ------------------------------------------------------------------
    # Override: flush and upload on shutdown
    # ------------------------------------------------------------------

    def stop(self) -> None:
        if self._il is not None:
            try:
                logger.info("checkpointing Interlatent data...")
                self._il.checkpoint(sae_k=18)
                logger.info("Interlatent final checkpoint complete")
            except Exception as exc:
                logger.warning(f"Interlatent final checkpoint failed: {exc}")
            finally:
                self._il.close()

        super().stop()


# ---------------------------------------------------------------------------
# Server entrypoint
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="lerobot PolicyServer with Interlatent activation capture."
    )
    # Server config (mirrors lerobot PolicyServerConfig fields)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--inference-latency", type=float, default=1 / 30)
    parser.add_argument("--obs-queue-timeout", type=float, default=2.0)
    # Interlatent config
    parser.add_argument("--api-key", default=None)
    parser.add_argument("--env-name", default=None, help="Environment name override. Defaults to 'lerobot_<policy_type>'.")
    parser.add_argument("--model-name", default=None, help="Model display name override. Defaults to the policy name derived from the policy path.")
    parser.add_argument("--layer", default="auto", help="Layer to capture activations from.")
    return parser


def serve() -> None:
    """Console script entrypoint: interlatent-lerobot-server."""
    import os
    from interlatent import Interlatent

    logging.basicConfig(level=logging.INFO)
    register_third_party_plugins()

    args = _build_parser().parse_args()

    api_key = args.api_key or os.environ.get("INTERLATENT_API_KEY")
    if not api_key:
        raise ValueError(
            "An Interlatent API key is required. "
            "Pass --api-key or set the INTERLATENT_API_KEY environment variable."
        )

    il_client = Interlatent(api_key=api_key, db_path=f"./interlatent_runs/{time.time()}/raw.db")

    cfg = PolicyServerConfig(
        host=args.host,
        port=args.port,
        fps=args.fps,
        inference_latency=args.inference_latency,
        obs_queue_timeout=args.obs_queue_timeout,
    )

    server_impl = InterlatentPolicyServer(
        cfg,
        interlatent_client=il_client,
        layer=args.layer,
        env_name=args.env_name,
        model_name=args.model_name,
    )

    grpc_server = grpc.server(futures.ThreadPoolExecutor(max_workers=4))
    services_pb2_grpc.add_AsyncInferenceServicer_to_server(server_impl, grpc_server)
    grpc_server.add_insecure_port(f"{args.host}:{args.port}")

    def _handle_signal(signum, frame):
        logger.info("Shutdown signal received, stopping gRPC server...")
        grpc_server.stop(grace=10)

    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    logger.info(f"InterlatentPolicyServer listening on {args.host}:{args.port}")
    grpc_server.start()
    grpc_server.wait_for_termination()

    logger.info("Shutting down, flushing Interlatent data...")
    server_impl.stop()


if __name__ == "__main__":
    serve()
