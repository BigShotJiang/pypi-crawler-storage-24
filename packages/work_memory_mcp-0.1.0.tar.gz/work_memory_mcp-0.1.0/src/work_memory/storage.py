from __future__ import annotations

import json
import sqlite3
import re
from pathlib import Path

from .models import EventRecord, SearchQuery, SearchResult, StorageConfig


class Storage:
    def __init__(self, config: StorageConfig) -> None:
        self.config = config
        self.config.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.config.archive_path.parent.mkdir(parents=True, exist_ok=True)
        self._fts_enabled: bool | None = None

    def initialize(self) -> None:
        with self.connect() as connection:
            connection.executescript(
                """
                PRAGMA foreign_keys = ON;

                CREATE TABLE IF NOT EXISTS projects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    repo_name TEXT NOT NULL,
                    repo_path TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    project_id INTEGER NOT NULL,
                    branch TEXT NOT NULL,
                    source TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    FOREIGN KEY(project_id) REFERENCES projects(id)
                );

                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL UNIQUE,
                    external_ref TEXT,
                    project_id INTEGER NOT NULL,
                    session_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    role TEXT,
                    title TEXT,
                    text TEXT NOT NULL,
                    command_text TEXT,
                    cwd TEXT,
                    exit_code INTEGER,
                    source TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    branch TEXT NOT NULL,
                    repo_name TEXT NOT NULL,
                    repo_path TEXT NOT NULL,
                    tags_json TEXT NOT NULL,
                    entities_json TEXT NOT NULL,
                    topics_json TEXT NOT NULL,
                    files_json TEXT NOT NULL,
                    commit_refs_json TEXT NOT NULL,
                    FOREIGN KEY(project_id) REFERENCES projects(id),
                    FOREIGN KEY(session_id) REFERENCES sessions(session_id)
                );

                CREATE TABLE IF NOT EXISTS artifacts (
                    artifact_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL,
                    artifact_type TEXT NOT NULL,
                    value TEXT NOT NULL,
                    FOREIGN KEY(event_id) REFERENCES events(event_id)
                );

                CREATE TABLE IF NOT EXISTS event_tags (
                    event_id TEXT NOT NULL,
                    tag TEXT NOT NULL,
                    PRIMARY KEY(event_id, tag),
                    FOREIGN KEY(event_id) REFERENCES events(event_id)
                );

                CREATE TABLE IF NOT EXISTS event_entities (
                    event_id TEXT NOT NULL,
                    entity TEXT NOT NULL,
                    PRIMARY KEY(event_id, entity),
                    FOREIGN KEY(event_id) REFERENCES events(event_id)
                );

                CREATE TABLE IF NOT EXISTS event_topics (
                    event_id TEXT NOT NULL,
                    topic TEXT NOT NULL,
                    PRIMARY KEY(event_id, topic),
                    FOREIGN KEY(event_id) REFERENCES events(event_id)
                );

                CREATE TABLE IF NOT EXISTS event_files (
                    event_id TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    PRIMARY KEY(event_id, file_path),
                    FOREIGN KEY(event_id) REFERENCES events(event_id)
                );

                CREATE INDEX IF NOT EXISTS idx_projects_name ON projects(repo_name);
                CREATE INDEX IF NOT EXISTS idx_sessions_project ON sessions(project_id);
                CREATE INDEX IF NOT EXISTS idx_events_repo ON events(repo_name, repo_path);
                CREATE INDEX IF NOT EXISTS idx_events_session ON events(session_id);
                CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp);
                CREATE INDEX IF NOT EXISTS idx_events_branch ON events(branch);
                CREATE INDEX IF NOT EXISTS idx_events_source ON events(source);
                CREATE INDEX IF NOT EXISTS idx_event_tags_tag ON event_tags(tag);
                CREATE INDEX IF NOT EXISTS idx_event_entities_entity ON event_entities(entity);
                CREATE INDEX IF NOT EXISTS idx_event_topics_topic ON event_topics(topic);
                CREATE INDEX IF NOT EXISTS idx_event_files_file_path ON event_files(file_path);
                """
            )
            self._ensure_column(connection, "events", "external_ref", "TEXT")
            connection.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_events_external_ref ON events(external_ref) WHERE external_ref IS NOT NULL"
            )
            self._initialize_fts(connection)

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.config.db_path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize_fts(self, connection: sqlite3.Connection) -> None:
        if self._fts_enabled is False:
            return
        try:
            connection.execute(
                """
                CREATE VIRTUAL TABLE IF NOT EXISTS events_fts USING fts5(
                    searchable_text,
                    content='events',
                    content_rowid='id'
                );
                """
            )
            self._fts_enabled = True
        except sqlite3.OperationalError:
            self._fts_enabled = False

    def store_event(self, record: EventRecord) -> str:
        with self.connect() as connection:
            self._initialize_fts(connection)
            existing_event_id = self._find_existing_event_id(connection, record.external_ref)
            if existing_event_id is not None:
                return existing_event_id
            project_id = self._ensure_project(connection, record.repo_name, record.repo_path)
            self._ensure_session(connection, project_id, record)
            connection.execute(
                """
                INSERT INTO events (
                    event_id, external_ref, project_id, session_id, event_type, role, title, text,
                    command_text, cwd, exit_code, source, timestamp, branch,
                    repo_name, repo_path, tags_json, entities_json, topics_json,
                    files_json, commit_refs_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record.event_id,
                    record.external_ref,
                    project_id,
                    record.session_id,
                    record.event_type,
                    record.role,
                    record.title,
                    record.text,
                    record.command_text,
                    record.cwd,
                    record.exit_code,
                    record.source,
                    record.timestamp,
                    record.branch,
                    record.repo_name,
                    record.repo_path,
                    json.dumps(record.tags),
                    json.dumps(record.entities),
                    json.dumps(record.topics),
                    json.dumps(record.files),
                    json.dumps(record.commit_refs),
                ),
            )
            if self._fts_enabled:
                row_id = connection.execute(
                    "SELECT id FROM events WHERE event_id = ?", (record.event_id,)
                ).fetchone()[0]
                connection.execute(
                    "INSERT INTO events_fts(rowid, searchable_text) VALUES (?, ?)",
                    (row_id, self._build_searchable_text(record)),
                )
            self._store_metadata_rows(connection, record)
            self._store_artifacts(connection, record)
        self._append_archive(record)
        return record.event_id

    def search(self, query: SearchQuery) -> list[SearchResult]:
        with self.connect() as connection:
            self._initialize_fts(connection)
            sql, params = self._build_search_sql(query, self._fts_enabled is True)
            rows = connection.execute(sql, params).fetchall()
        return [self._row_to_result(row) for row in rows]

    def has_external_ref(self, external_ref: str) -> bool:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT 1 FROM events WHERE external_ref = ?",
                (external_ref,),
            ).fetchone()
        return row is not None

    def summarize_topic(self, topic: str, limit: int = 10) -> dict[str, object]:
        query = SearchQuery(topics=[topic], limit=limit)
        results = self.search(query)
        repo_names = sorted({result.repo_name for result in results})
        sessions = sorted({result.session_id for result in results})
        return {
            "topic": topic,
            "count": len(results),
            "repos": repo_names,
            "sessions": sessions,
            "highlights": [self._format_highlight(result) for result in results[:limit]],
        }

    def _ensure_project(self, connection: sqlite3.Connection, repo_name: str, repo_path: str) -> int:
        connection.execute(
            "INSERT OR IGNORE INTO projects(repo_name, repo_path) VALUES (?, ?)",
            (repo_name, repo_path),
        )
        row = connection.execute(
            "SELECT id FROM projects WHERE repo_path = ?",
            (repo_path,),
        ).fetchone()
        assert row is not None
        return int(row[0])

    def _find_existing_event_id(
        self,
        connection: sqlite3.Connection,
        external_ref: str | None,
    ) -> str | None:
        if not external_ref:
            return None
        row = connection.execute(
            "SELECT event_id FROM events WHERE external_ref = ?",
            (external_ref,),
        ).fetchone()
        if row is None:
            return None
        return str(row[0])

    def _ensure_column(
        self,
        connection: sqlite3.Connection,
        table_name: str,
        column_name: str,
        column_type: str,
    ) -> None:
        rows = connection.execute(f"PRAGMA table_info({table_name})").fetchall()
        columns = {row[1] for row in rows}
        if column_name not in columns:
            connection.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}")

    def _ensure_session(self, connection: sqlite3.Connection, project_id: int, record: EventRecord) -> None:
        connection.execute(
            """
            INSERT OR IGNORE INTO sessions(session_id, project_id, branch, source, started_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (record.session_id, project_id, record.branch, record.source, record.timestamp),
        )

    def _store_metadata_rows(self, connection: sqlite3.Connection, record: EventRecord) -> None:
        for tag in record.tags:
            connection.execute(
                "INSERT OR IGNORE INTO event_tags(event_id, tag) VALUES (?, ?)",
                (record.event_id, tag),
            )
        for entity in record.entities:
            connection.execute(
                "INSERT OR IGNORE INTO event_entities(event_id, entity) VALUES (?, ?)",
                (record.event_id, entity),
            )
        for topic in record.topics:
            connection.execute(
                "INSERT OR IGNORE INTO event_topics(event_id, topic) VALUES (?, ?)",
                (record.event_id, topic),
            )
        for file_path in record.files:
            connection.execute(
                "INSERT OR IGNORE INTO event_files(event_id, file_path) VALUES (?, ?)",
                (record.event_id, file_path),
            )

    def _store_artifacts(self, connection: sqlite3.Connection, record: EventRecord) -> None:
        for file_path in record.files:
            connection.execute(
                "INSERT INTO artifacts(event_id, artifact_type, value) VALUES (?, ?, ?)",
                (record.event_id, "file", file_path),
            )
        for commit_ref in record.commit_refs:
            connection.execute(
                "INSERT INTO artifacts(event_id, artifact_type, value) VALUES (?, ?, ?)",
                (record.event_id, "git_commit", commit_ref),
            )

    def _append_archive(self, record: EventRecord) -> None:
        payload = {
            "event_id": record.event_id,
            "event_type": record.event_type,
            "repo_name": record.repo_name,
            "repo_path": record.repo_path,
            "branch": record.branch,
            "session_id": record.session_id,
            "timestamp": record.timestamp,
            "source": record.source,
            "role": record.role,
            "title": record.title,
            "text": record.text,
            "command_text": record.command_text,
            "cwd": record.cwd,
            "exit_code": record.exit_code,
            "external_ref": record.external_ref,
            "tags": record.tags,
            "entities": record.entities,
            "topics": record.topics,
            "files": record.files,
            "commit_refs": record.commit_refs,
        }
        with self.config.archive_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=True) + "\n")

    def _build_searchable_text(self, record: EventRecord) -> str:
        parts = [
            record.title or "",
            record.text,
            record.command_text or "",
            " ".join(record.tags),
            " ".join(record.entities),
            " ".join(record.topics),
            " ".join(record.files),
            " ".join(record.commit_refs),
        ]
        return " ".join(part for part in parts if part)

    def _build_search_sql(self, query: SearchQuery, use_fts: bool) -> tuple[str, list[object]]:
        sql = [
            """
            SELECT DISTINCT
                e.event_id,
                e.event_type,
                e.repo_name,
                e.repo_path,
                e.branch,
                e.session_id,
                e.source,
                e.timestamp,
                e.role,
                e.title,
                e.text,
                e.command_text,
                e.cwd,
                e.exit_code,
                e.external_ref,
                e.tags_json,
                e.entities_json,
                e.topics_json,
                e.files_json,
                e.commit_refs_json
            FROM events e
            """
        ]
        params: list[object] = []
        where = ["1 = 1"]

        if query.text and use_fts:
            sql.append("JOIN events_fts fts ON fts.rowid = e.id")
            where.append("fts.searchable_text MATCH ?")
            params.append(self._to_fts_query(query.text))
        elif query.text:
            where.append("(e.text LIKE ? OR ifnull(e.command_text, '') LIKE ? OR ifnull(e.tags_json, '') LIKE ? OR ifnull(e.entities_json, '') LIKE ? OR ifnull(e.topics_json, '') LIKE ?)")
            like_value = f"%{query.text}%"
            params.extend([like_value, like_value, like_value, like_value, like_value])

        if query.repo_names:
            placeholders = ", ".join("?" for _ in query.repo_names)
            where.append(f"e.repo_name IN ({placeholders})")
            params.extend(query.repo_names)
        if query.repo_paths:
            placeholders = ", ".join("?" for _ in query.repo_paths)
            where.append(f"e.repo_path IN ({placeholders})")
            params.extend(query.repo_paths)
        if query.session_ids:
            placeholders = ", ".join("?" for _ in query.session_ids)
            where.append(f"e.session_id IN ({placeholders})")
            params.extend(query.session_ids)
        if query.branch:
            where.append("e.branch = ?")
            params.append(query.branch)
        if query.source:
            where.append("e.source = ?")
            params.append(query.source)
        if query.date_from:
            where.append("e.timestamp >= ?")
            params.append(query.date_from)
        if query.date_to:
            where.append("e.timestamp <= ?")
            params.append(query.date_to)

        self._append_exists_filter(where, params, "event_tags", "tag", query.tags)
        self._append_exists_filter(where, params, "event_entities", "entity", query.entities)
        self._append_exists_filter(where, params, "event_topics", "topic", query.topics)
        self._append_exists_filter(where, params, "event_files", "file_path", query.files)

        sql.append("WHERE " + " AND ".join(where))
        sql.append("ORDER BY e.timestamp DESC")
        sql.append("LIMIT ?")
        params.append(query.limit)
        return "\n".join(sql), params

    def _append_exists_filter(
        self,
        where: list[str],
        params: list[object],
        table: str,
        column: str,
        values: list[str],
    ) -> None:
        for value in values:
            where.append(
                f"EXISTS (SELECT 1 FROM {table} t WHERE t.event_id = e.event_id AND lower(t.{column}) = lower(?))"
            )
            params.append(value)

    def _row_to_result(self, row: sqlite3.Row) -> SearchResult:
        return SearchResult(
            event_id=row["event_id"],
            event_type=row["event_type"],
            repo_name=row["repo_name"],
            repo_path=row["repo_path"],
            branch=row["branch"],
            session_id=row["session_id"],
            source=row["source"],
            timestamp=row["timestamp"],
            role=row["role"],
            title=row["title"],
            text=row["text"],
            command_text=row["command_text"],
            cwd=row["cwd"],
            exit_code=row["exit_code"],
            external_ref=row["external_ref"],
            tags=json.loads(row["tags_json"]),
            entities=json.loads(row["entities_json"]),
            topics=json.loads(row["topics_json"]),
            files=json.loads(row["files_json"]),
            commit_refs=json.loads(row["commit_refs_json"]),
        )

    def _format_highlight(self, result: SearchResult) -> str:
        text = result.text or result.command_text or ""
        short_text = text.strip().replace("\n", " ")
        if len(short_text) > 120:
            short_text = short_text[:117] + "..."
        return f"[{result.repo_name}] {result.timestamp} {short_text}"

    def _to_fts_query(self, value: str) -> str:
        tokens = [token for token in re.split(r"\s+", value.strip()) if token]
        if not tokens:
            return '""'
        return " AND ".join(f'"{token.replace(chr(34), "")}"' for token in tokens)

