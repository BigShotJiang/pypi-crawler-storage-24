from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import venv
from pathlib import Path


def default_runtime_root() -> Path:
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        return Path(local_app_data) / "work-memory" / "runtime"
    return Path.home() / ".work-memory" / "runtime"


def default_vscode_user_dir() -> Path:
    app_data = os.environ.get("APPDATA")
    if app_data:
        return Path(app_data) / "Code" / "User"
    return Path.home() / ".config" / "Code" / "User"


def python_executable(venv_root: Path) -> Path:
    if os.name == "nt":
        return venv_root / "Scripts" / "python.exe"
    return venv_root / "bin" / "python"


def load_json(path: Path, default: dict) -> dict:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def ensure_runtime(runtime_root: Path, repo_root: Path) -> Path:
    venv_root = runtime_root / "venv"
    python_path = python_executable(venv_root)
    if not python_path.exists():
        runtime_root.mkdir(parents=True, exist_ok=True)
        venv.EnvBuilder(with_pip=True).create(venv_root)

    subprocess.run([str(python_path), "-m", "pip", "install", "--upgrade", "pip"], check=True)
    subprocess.run([str(python_path), "-m", "pip", "install", "-e", str(repo_root)], check=True)
    return python_path


def update_user_mcp(user_dir: Path, server_name: str, command_path: Path) -> Path:
    mcp_path = user_dir / "mcp.json"
    payload = load_json(mcp_path, {"servers": {}, "inputs": []})
    payload.setdefault("servers", {})
    payload.setdefault("inputs", [])
    payload["servers"][server_name] = {
        "type": "stdio",
        "command": command_path.as_posix(),
        "args": ["-m", "work_memory.mcp_server", "--transport", "stdio"],
    }
    write_json(mcp_path, payload)
    return mcp_path


def update_user_settings(user_dir: Path, auto_start: bool) -> Path:
    settings_path = user_dir / "settings.json"
    payload = load_json(settings_path, {})
    if auto_start:
        payload["chat.mcp.autoStart"] = True
    write_json(settings_path, payload)
    return settings_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Install Work Memory for all VS Code windows in the current user profile.")
    parser.add_argument("--server-name", default="work-memory")
    parser.add_argument("--runtime-root", type=Path, default=default_runtime_root())
    parser.add_argument("--user-dir", type=Path, default=default_vscode_user_dir())
    parser.add_argument("--no-auto-start", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    repo_root = Path(__file__).resolve().parents[2]
    python_path = ensure_runtime(args.runtime_root, repo_root)
    mcp_path = update_user_mcp(args.user_dir, args.server_name, python_path)
    settings_path = update_user_settings(args.user_dir, auto_start=not args.no_auto_start)

    print(f"Installed Work Memory runtime: {python_path}")
    print(f"Updated VS Code MCP config: {mcp_path}")
    print(f"Updated VS Code settings: {settings_path}")
    print("Restart VS Code or run 'MCP: List Servers' to verify the server is available.")


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as error:
        print(error, file=sys.stderr)
        raise SystemExit(error.returncode) from error
