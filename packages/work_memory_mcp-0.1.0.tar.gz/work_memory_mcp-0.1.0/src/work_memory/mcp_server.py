from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from .ingest import (
    discover_vscode_sources,
    import_vscode_chat_session_sources,
    import_vscode_copilot_sources,
)
from .models import SearchQuery
from .service import MemoryService, default_service


def create_mcp_server(
    root: Path | None = None,
    *,
    host: str = "127.0.0.1",
    port: int = 8000,
    json_response: bool = False,
    stateless_http: bool = True,
    mount_path: str = "/mcp",
) -> FastMCP:
    service = default_service(root)
    service.initialize()

    mcp = FastMCP(
        name="Work Memory",
        instructions=(
            "Use metadata filters first, then full-text matching. Cross-project recall should stay explicit. "
            "This server exposes local development memory from a shared SQLite and JSONL store."
        ),
        host=host,
        port=port,
        streamable_http_path=mount_path,
        stateless_http=stateless_http,
        json_response=json_response,
    )

    @mcp.tool(name="memory_status", description="Return storage paths and basic server status.")
    def memory_status() -> dict[str, Any]:
        return build_memory_status(service)

    @mcp.tool(
        name="search_memory",
        description="Search the local memory store with optional metadata filters.",
    )
    def search_memory(
        query: str | None = None,
        repo_names: list[str] | None = None,
        repo_paths: list[str] | None = None,
        session_ids: list[str] | None = None,
        branch: str | None = None,
        source: str | None = None,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        return search_memory_payload(
            service,
            query=query,
            repo_names=repo_names,
            repo_paths=repo_paths,
            session_ids=session_ids,
            branch=branch,
            source=source,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            date_from=date_from,
            date_to=date_to,
            limit=limit,
        )

    @mcp.tool(
        name="recall_project_memory",
        description="Recall memory scoped to a single project or repo path.",
    )
    def recall_project_memory(
        repo_name: str | None = None,
        repo_path: str | None = None,
        query: str | None = None,
        branch: str | None = None,
        session_id: str | None = None,
        source: str | None = None,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        return recall_project_payload(
            service,
            repo_name=repo_name,
            repo_path=repo_path,
            query=query,
            branch=branch,
            session_id=session_id,
            source=source,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            limit=limit,
        )

    @mcp.tool(
        name="recall_cross_project_memory",
        description="Recall memory across projects using explicit filters.",
    )
    def recall_cross_project_memory(
        query: str | None = None,
        repo_names: list[str] | None = None,
        repo_paths: list[str] | None = None,
        branch: str | None = None,
        source: str | None = None,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        return recall_cross_project_payload(
            service,
            query=query,
            repo_names=repo_names,
            repo_paths=repo_paths,
            branch=branch,
            source=source,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            date_from=date_from,
            date_to=date_to,
            limit=limit,
        )

    @mcp.tool(
        name="recursive_recall_memory",
        description="Run an RLM-inspired recursive recall plan with trajectory metadata.",
    )
    def recursive_recall_memory(
        query: str | None = None,
        repo_names: list[str] | None = None,
        repo_paths: list[str] | None = None,
        session_ids: list[str] | None = None,
        branch: str | None = None,
        source: str | None = None,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        limit: int = 20,
        max_depth: int = 2,
        branch_limit: int = 3,
    ) -> dict[str, Any]:
        return recursive_recall_payload(
            service,
            query=query,
            repo_names=repo_names,
            repo_paths=repo_paths,
            session_ids=session_ids,
            branch=branch,
            source=source,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            date_from=date_from,
            date_to=date_to,
            limit=limit,
            max_depth=max_depth,
            branch_limit=branch_limit,
        )

    @mcp.tool(
        name="summarize_memory_topic",
        description="Summarize a topic across the local memory store.",
    )
    def summarize_memory_topic(topic: str, limit: int = 10) -> dict[str, Any]:
        return summarize_topic_payload(service, topic=topic, limit=limit)

    @mcp.tool(
        name="store_memory_note",
        description="Store a manual note or handoff in the shared memory store.",
    )
    def store_memory_note(
        repo_name: str,
        repo_path: str,
        branch: str,
        session_id: str,
        source: str,
        title: str,
        text: str,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        commit_refs: list[str] | None = None,
        timestamp: str | None = None,
    ) -> dict[str, Any]:
        event_id = service.store_note(
            repo_name=repo_name,
            repo_path=repo_path,
            branch=branch,
            session_id=session_id,
            source=source,
            title=title,
            text=text,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            commit_refs=commit_refs,
            timestamp=timestamp,
        )
        return {"stored": event_id, "type": "note"}

    @mcp.tool(
        name="discover_memory_sources",
        description="Discover likely local VS Code memory sources that can be imported.",
    )
    def discover_memory_sources(limit: int = 50) -> dict[str, Any]:
        candidates = [asdict(candidate) for candidate in discover_vscode_sources(limit=limit)]
        return {"count": len(candidates), "sources": candidates}

    @mcp.tool(
        name="import_vscode_sessions",
        description="Import structured VS Code chat session files into local memory.",
    )
    def import_vscode_sessions(limit: int = 200) -> dict[str, Any]:
        return asdict(import_vscode_chat_session_sources(service, limit=limit))

    @mcp.tool(
        name="import_vscode_copilot_resources",
        description="Import VS Code Copilot chat resource files into local memory as raw notes.",
    )
    def import_vscode_copilot_resources(limit: int = 200) -> dict[str, Any]:
        return asdict(import_vscode_copilot_sources(service, limit=limit))

    @mcp.resource("memory://status")
    def memory_status_resource() -> str:
        return json.dumps(build_memory_status(service), indent=2)

    @mcp.prompt(name="memory_query_plan")
    def memory_query_plan(question: str, repo_name: str | None = None) -> str:
        repo_clause = f" Focus on repo {repo_name}." if repo_name else ""
        return (
            "Use Work Memory with metadata-first retrieval."
            f"{repo_clause} Start with repo, date, source, session, tag, topic, and entity filters. "
            "Only widen to cross-project search if the first scoped query is insufficient. "
            f"Question to answer: {question}"
        )

    return mcp


def build_memory_status(service: MemoryService) -> dict[str, Any]:
    return {
        "server": "work-memory",
        "db_path": str(service.storage.config.db_path),
        "archive_path": str(service.storage.config.archive_path),
        "initialized": True,
    }


def search_memory_payload(
    service: MemoryService,
    *,
    query: str | None = None,
    repo_names: list[str] | None = None,
    repo_paths: list[str] | None = None,
    session_ids: list[str] | None = None,
    branch: str | None = None,
    source: str | None = None,
    tags: list[str] | None = None,
    entities: list[str] | None = None,
    topics: list[str] | None = None,
    files: list[str] | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int = 20,
) -> dict[str, Any]:
    results = service.search(
        SearchQuery(
            text=query,
            repo_names=repo_names or [],
            repo_paths=repo_paths or [],
            session_ids=session_ids or [],
            branch=branch,
            source=source,
            tags=tags or [],
            entities=entities or [],
            topics=topics or [],
            files=files or [],
            date_from=date_from,
            date_to=date_to,
            limit=limit,
        )
    )
    return {"count": len(results), "results": [asdict(result) for result in results]}


def recall_project_payload(
    service: MemoryService,
    *,
    repo_name: str | None = None,
    repo_path: str | None = None,
    query: str | None = None,
    branch: str | None = None,
    session_id: str | None = None,
    source: str | None = None,
    tags: list[str] | None = None,
    entities: list[str] | None = None,
    topics: list[str] | None = None,
    files: list[str] | None = None,
    limit: int = 20,
) -> dict[str, Any]:
    results = service.recall_project(
        repo_name=repo_name,
        repo_path=repo_path,
        query=query,
        branch=branch,
        session_id=session_id,
        source=source,
        tags=tags,
        entities=entities,
        topics=topics,
        files=files,
        limit=limit,
    )
    return {"count": len(results), "results": [asdict(result) for result in results]}


def recall_cross_project_payload(
    service: MemoryService,
    *,
    query: str | None = None,
    repo_names: list[str] | None = None,
    repo_paths: list[str] | None = None,
    branch: str | None = None,
    source: str | None = None,
    tags: list[str] | None = None,
    entities: list[str] | None = None,
    topics: list[str] | None = None,
    files: list[str] | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int = 20,
) -> dict[str, Any]:
    results = service.recall_cross_project(
        query=query,
        repo_names=repo_names,
        repo_paths=repo_paths,
        branch=branch,
        source=source,
        tags=tags,
        entities=entities,
        topics=topics,
        files=files,
        date_from=date_from,
        date_to=date_to,
        limit=limit,
    )
    return {"count": len(results), "results": [asdict(result) for result in results]}


def summarize_topic_payload(service: MemoryService, *, topic: str, limit: int = 10) -> dict[str, Any]:
    return service.summarize_topic(topic, limit=limit)


def recursive_recall_payload(
    service: MemoryService,
    *,
    query: str | None = None,
    repo_names: list[str] | None = None,
    repo_paths: list[str] | None = None,
    session_ids: list[str] | None = None,
    branch: str | None = None,
    source: str | None = None,
    tags: list[str] | None = None,
    entities: list[str] | None = None,
    topics: list[str] | None = None,
    files: list[str] | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int = 20,
    max_depth: int = 2,
    branch_limit: int = 3,
) -> dict[str, Any]:
    result = service.recursive_recall(
        SearchQuery(
            text=query,
            repo_names=repo_names or [],
            repo_paths=repo_paths or [],
            session_ids=session_ids or [],
            branch=branch,
            source=source,
            tags=tags or [],
            entities=entities or [],
            topics=topics or [],
            files=files or [],
            date_from=date_from,
            date_to=date_to,
            limit=limit,
        ),
        max_depth=max_depth,
        branch_limit=branch_limit,
    )
    return result.to_dict()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="work-memory-mcp")
    parser.add_argument("--root", type=Path, default=None, help="Optional project root override for storage")
    parser.add_argument(
        "--transport",
        choices=["stdio", "streamable-http"],
        default="stdio",
        help="MCP transport to serve",
    )
    parser.add_argument("--host", default="127.0.0.1", help="Host for streamable-http transport")
    parser.add_argument("--port", type=int, default=8000, help="Port for streamable-http transport")
    parser.add_argument(
        "--mount-path",
        default="/mcp",
        help="Mount path for streamable-http transport",
    )
    parser.add_argument(
        "--json-response",
        action="store_true",
        help="Enable JSON responses for streamable-http transport",
    )
    parser.add_argument(
        "--stateful-http",
        action="store_true",
        help="Use stateful HTTP sessions instead of stateless mode",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    server = create_mcp_server(
        args.root,
        host=args.host,
        port=args.port,
        json_response=args.json_response,
        stateless_http=not args.stateful_http,
        mount_path=args.mount_path,
    )
    if args.transport == "stdio":
        server.run(transport="stdio")
        return
    server.run(transport="streamable-http")


if __name__ == "__main__":
    main()