from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

from .extractor import normalize_values
from .service import MemoryService


@dataclass(slots=True)
class SourceCandidate:
    kind: str
    path: str
    repo_name: str
    repo_path: str
    session_id: str
    source: str


@dataclass(slots=True)
class ImportSummary:
    imported: int
    skipped: int
    sources: list[str]


def discover_vscode_copilot_sources(limit: int = 200) -> list[SourceCandidate]:
    workspace_storage = _workspace_storage_root()
    if workspace_storage is None or not workspace_storage.exists():
        return []

    candidates: list[SourceCandidate] = []
    for workspace_dir in sorted(workspace_storage.iterdir()):
        copilot_dir = workspace_dir / "GitHub.copilot-chat"
        if not copilot_dir.exists():
            continue
        repo_name, repo_path = _infer_repo_metadata(workspace_dir, workspace_dir.name)
        resources_dir = copilot_dir / "chat-session-resources"
        if not resources_dir.exists():
            continue
        for session_dir in sorted(resources_dir.iterdir()):
            if not session_dir.is_dir():
                continue
            for content_file in session_dir.rglob("content.txt"):
                candidates.append(
                    SourceCandidate(
                        kind="vscode-copilot-content",
                        path=str(content_file),
                        repo_name=repo_name,
                        repo_path=repo_path,
                        session_id=session_dir.name,
                        source="vscode-copilot-chat",
                    )
                )
                if len(candidates) >= limit:
                    return candidates
    return candidates


def discover_vscode_chat_session_sources(limit: int = 200) -> list[SourceCandidate]:
    workspace_storage = _workspace_storage_root()
    if workspace_storage is None or not workspace_storage.exists():
        return []

    candidates: list[SourceCandidate] = []
    for workspace_dir in sorted(workspace_storage.iterdir()):
        chat_sessions_dir = workspace_dir / "chatSessions"
        if not chat_sessions_dir.exists():
            continue
        repo_name, repo_path = _infer_repo_metadata(workspace_dir, workspace_dir.name)
        for session_file in sorted(chat_sessions_dir.glob("*.jsonl")):
            session_id = session_file.stem
            candidates.append(
                SourceCandidate(
                    kind="vscode-chat-session",
                    path=str(session_file),
                    repo_name=repo_name,
                    repo_path=repo_path,
                    session_id=session_id,
                    source="vscode-chat-session",
                )
            )
            if len(candidates) >= limit:
                return candidates
    return candidates


def discover_vscode_sources(limit: int = 200) -> list[SourceCandidate]:
    combined = discover_vscode_chat_session_sources(limit=limit)
    if len(combined) < limit:
        combined.extend(discover_vscode_copilot_sources(limit=limit - len(combined)))
    return combined[:limit]


def import_vscode_copilot_sources(service: MemoryService, limit: int = 200) -> ImportSummary:
    imported = 0
    skipped = 0
    sources: list[str] = []
    for candidate in discover_vscode_copilot_sources(limit=limit):
        path = Path(candidate.path)
        external_ref = f"{candidate.source}:{candidate.path}"
        if service.has_external_ref(external_ref):
            skipped += 1
            continue
        if not path.exists():
            skipped += 1
            continue
        text = path.read_text(encoding="utf-8", errors="ignore").strip()
        if not text:
            skipped += 1
            continue
        event_id = service.store_note(
            repo_name=candidate.repo_name,
            repo_path=candidate.repo_path,
            branch="unknown",
            session_id=candidate.session_id,
            source=candidate.source,
            title=f"imported:{path.parent.name}",
            text=text,
            tags=["import", "copilot-chat", "chat-history"],
            topics=["ai", "memory"],
            files=[candidate.path],
            external_ref=external_ref,
        )
        imported += 1
        sources.append(candidate.path)
    return ImportSummary(imported=imported, skipped=skipped, sources=sources)


def import_vscode_chat_session_sources(service: MemoryService, limit: int = 200) -> ImportSummary:
    imported = 0
    skipped = 0
    sources: list[str] = []
    for candidate in discover_vscode_chat_session_sources(limit=limit):
        path = Path(candidate.path)
        if not path.exists():
            skipped += 1
            continue
        imported_from_file = _import_vscode_chat_session_file(
            service,
            path=path,
            repo_name=candidate.repo_name,
            repo_path=candidate.repo_path,
            session_id=candidate.session_id,
            source=candidate.source,
        )
        if imported_from_file:
            imported += imported_from_file
            sources.append(candidate.path)
        else:
            skipped += 1
    return ImportSummary(imported=imported, skipped=skipped, sources=sources)


def import_path(
    service: MemoryService,
    *,
    source_path: Path,
    repo_name: str,
    repo_path: str,
    branch: str,
    session_id: str,
    source: str,
    format_name: str = "auto",
) -> ImportSummary:
    imported = 0
    skipped = 0
    sources: list[str] = []
    paths = [source_path]
    if source_path.is_dir():
        paths = sorted(path for path in source_path.rglob("*") if path.is_file())

    for path in paths:
        file_format = _detect_format(path, format_name)
        imported_from_file = 0
        if file_format == "vscode-chat-session":
            imported_from_file = _import_vscode_chat_session_file(
                service,
                path=path,
                repo_name=repo_name,
                repo_path=repo_path,
                session_id=session_id,
                source=source,
                branch=branch,
            )
        elif file_format == "jsonl":
            imported_from_file = _import_jsonl_file(
                service,
                path=path,
                repo_name=repo_name,
                repo_path=repo_path,
                branch=branch,
                session_id=session_id,
                source=source,
            )
        elif file_format == "json":
            imported_from_file = _import_json_file(
                service,
                path=path,
                repo_name=repo_name,
                repo_path=repo_path,
                branch=branch,
                session_id=session_id,
                source=source,
            )
        else:
            text = path.read_text(encoding="utf-8", errors="ignore").strip()
            if text:
                external_ref = f"{source}:{path}"
                if service.has_external_ref(external_ref):
                    skipped += 1
                    continue
                service.store_note(
                    repo_name=repo_name,
                    repo_path=repo_path,
                    branch=branch,
                    session_id=session_id,
                    source=source,
                    title=f"imported:{path.name}",
                    text=text,
                    tags=["import", "text"],
                    topics=["memory"],
                    files=[str(path)],
                    external_ref=external_ref,
                )
                imported_from_file = 1
        if imported_from_file:
            imported += imported_from_file
            sources.append(str(path))
        else:
            skipped += 1
    return ImportSummary(imported=imported, skipped=skipped, sources=sources)


def _import_jsonl_file(
    service: MemoryService,
    *,
    path: Path,
    repo_name: str,
    repo_path: str,
    branch: str,
    session_id: str,
    source: str,
) -> int:
    imported = 0
    for index, line in enumerate(path.read_text(encoding="utf-8", errors="ignore").splitlines()):
        if not line.strip():
            continue
        payload = json.loads(line)
        external_ref = f"{source}:{path}:{index + 1}"
        if service.has_external_ref(external_ref):
            continue
        imported += _import_payload(
            service,
            payload=payload,
            repo_name=repo_name,
            repo_path=repo_path,
            branch=branch,
            session_id=session_id,
            source=source,
            external_ref=external_ref,
            file_path=str(path),
        )
    return imported


def _import_json_file(
    service: MemoryService,
    *,
    path: Path,
    repo_name: str,
    repo_path: str,
    branch: str,
    session_id: str,
    source: str,
) -> int:
    payload = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    items = _flatten_payload(payload)
    imported = 0
    for index, item in enumerate(items):
        external_ref = f"{source}:{path}:{index + 1}"
        if service.has_external_ref(external_ref):
            continue
        imported += _import_payload(
            service,
            payload=item,
            repo_name=repo_name,
            repo_path=repo_path,
            branch=branch,
            session_id=session_id,
            source=source,
            external_ref=external_ref,
            file_path=str(path),
        )
    return imported


def _import_payload(
    service: MemoryService,
    *,
    payload: dict[str, Any],
    repo_name: str,
    repo_path: str,
    branch: str,
    session_id: str,
    source: str,
    external_ref: str,
    file_path: str,
) -> int:
    role = _extract_role(payload)
    text = _extract_text(payload)
    timestamp = _extract_timestamp(payload)
    payload_repo_name = payload.get("repo_name") or repo_name
    payload_repo_path = payload.get("repo_path") or repo_path
    payload_branch = payload.get("branch") or branch
    payload_session_id = payload.get("session_id") or session_id
    tags = normalize_values([*(payload.get("tags") or []), "import"])
    entities = payload.get("entities") or []
    topics = payload.get("topics") or []
    files = normalize_values([file_path, *(payload.get("files") or [])])
    commit_refs = payload.get("commit_refs") or []

    if payload.get("event_type") == "command" or payload.get("command"):
        command_text = str(payload.get("command_text") or payload.get("command") or "").strip()
        if not command_text:
            return 0
        service.store_command(
            repo_name=payload_repo_name,
            repo_path=payload_repo_path,
            branch=payload_branch,
            session_id=payload_session_id,
            source=source,
            command_text=command_text,
            cwd=payload.get("cwd"),
            exit_code=payload.get("exit_code"),
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            commit_refs=commit_refs,
            timestamp=timestamp,
            external_ref=external_ref,
        )
        return 1

    if role and text:
        service.store_turn(
            repo_name=payload_repo_name,
            repo_path=payload_repo_path,
            branch=payload_branch,
            session_id=payload_session_id,
            role=role,
            source=source,
            text=text,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            commit_refs=commit_refs,
            timestamp=timestamp,
            external_ref=external_ref,
        )
        return 1

    if text:
        service.store_note(
            repo_name=payload_repo_name,
            repo_path=payload_repo_path,
            branch=payload_branch,
            session_id=payload_session_id,
            source=source,
            title=str(payload.get("title") or payload.get("type") or "imported-record"),
            text=text,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            commit_refs=commit_refs,
            timestamp=timestamp,
            external_ref=external_ref,
        )
        return 1

    prompt = payload.get("prompt")
    response = payload.get("response")
    imported = 0
    if isinstance(prompt, str) and prompt.strip():
        service.store_turn(
            repo_name=payload_repo_name,
            repo_path=payload_repo_path,
            branch=payload_branch,
            session_id=payload_session_id,
            role="user",
            source=source,
            text=prompt,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            commit_refs=commit_refs,
            timestamp=timestamp,
            external_ref=f"{external_ref}:prompt",
        )
        imported += 1
    if isinstance(response, str) and response.strip():
        service.store_turn(
            repo_name=payload_repo_name,
            repo_path=payload_repo_path,
            branch=payload_branch,
            session_id=payload_session_id,
            role="assistant",
            source=source,
            text=response,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            commit_refs=commit_refs,
            timestamp=timestamp,
            external_ref=f"{external_ref}:response",
        )
        imported += 1
    return imported


def _flatten_payload(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for entry in payload for item in _flatten_payload(entry)]
    if isinstance(payload, dict):
        if any(key in payload for key in ("role", "text", "message", "content", "prompt", "response", "command")):
            return [payload]
        for key in ("messages", "turns", "items", "events", "conversation"):
            value = payload.get(key)
            if isinstance(value, list):
                return [item for entry in value for item in _flatten_payload(entry)]
        return [payload]
    return []


def _extract_text(payload: dict[str, Any]) -> str:
    for key in ("text", "message", "content", "body", "value"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _extract_role(payload: dict[str, Any]) -> str | None:
    role = payload.get("role") or payload.get("speaker") or payload.get("author")
    if not isinstance(role, str):
        return None
    normalized = role.strip().casefold()
    if normalized in {"user", "assistant", "system"}:
        return normalized
    return None


def _extract_timestamp(payload: dict[str, Any]) -> str | None:
    for key in ("timestamp", "created_at", "createdAt", "time"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _detect_format(path: Path, format_name: str) -> str:
    if format_name != "auto":
        return format_name
    if _looks_like_vscode_chat_session(path):
        return "vscode-chat-session"
    if path.suffix.lower() == ".jsonl":
        return "jsonl"
    if path.suffix.lower() == ".json":
        return "json"
    return "text"


def _workspace_storage_root() -> Path | None:
    app_data = os.environ.get("APPDATA")
    if not app_data:
        return None
    return Path(app_data) / "Code" / "User" / "workspaceStorage"


def _infer_repo_metadata(workspace_dir: Path, workspace_id: str) -> tuple[str, str]:
    workspace_json_path = workspace_dir / "workspace.json"
    if workspace_json_path.exists():
        try:
            payload = json.loads(workspace_json_path.read_text(encoding="utf-8", errors="ignore"))
            folder_uri = payload.get("folder")
            if isinstance(folder_uri, str):
                folder_path = _uri_to_path(folder_uri)
                if folder_path is not None:
                    return folder_path.name or f"workspace-{workspace_id[:8]}", str(folder_path)
            folders = payload.get("folders")
            if isinstance(folders, list):
                paths = []
                for entry in folders:
                    if isinstance(entry, dict) and isinstance(entry.get("path"), str):
                        paths.append(Path(entry["path"]))
                    elif isinstance(entry, dict) and isinstance(entry.get("uri"), str):
                        parsed = _uri_to_path(entry["uri"])
                        if parsed is not None:
                            paths.append(parsed)
                if paths:
                    common_path = Path(os.path.commonpath([str(path) for path in paths]))
                    return common_path.name or f"workspace-{workspace_id[:8]}", str(common_path)
        except (OSError, ValueError, json.JSONDecodeError):
            pass

    copilot_dir = workspace_dir / "GitHub.copilot-chat"
    workspace_chunks_path = copilot_dir / "workspace-chunks.json"
    if workspace_chunks_path.exists():
        try:
            payload = json.loads(workspace_chunks_path.read_text(encoding="utf-8", errors="ignore"))
            entries = payload.get("entries") or {}
            paths = [
                _uri_to_path(value)
                for value in entries.keys()
                if isinstance(value, str) and value.startswith("file:///")
            ]
            file_paths = [path for path in paths if path is not None]
            if file_paths:
                common_path = Path(os.path.commonpath([str(path) for path in file_paths]))
                return common_path.name or f"workspace-{workspace_id[:8]}", str(common_path)
        except (OSError, ValueError, json.JSONDecodeError):
            pass
    return f"workspace-{workspace_id[:8]}", f"vscode-workspace://{workspace_id}"


def _uri_to_path(uri: str) -> Path | None:
    parsed = urlparse(uri)
    if parsed.scheme != "file":
        return None
    path = unquote(parsed.path)
    if path.startswith("/") and len(path) > 2 and path[2] == ":":
        path = path[1:]
    return Path(path)


def _looks_like_vscode_chat_session(path: Path) -> bool:
    if path.suffix.lower() not in {".json", ".jsonl"}:
        return False
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            first_line = handle.readline().strip()
    except OSError:
        return False
    if not first_line:
        return False
    try:
        payload = json.loads(first_line)
    except json.JSONDecodeError:
        return False
    return isinstance(payload, dict) and "kind" in payload and "v" in payload


def _import_vscode_chat_session_file(
    service: MemoryService,
    *,
    path: Path,
    repo_name: str,
    repo_path: str,
    session_id: str,
    source: str,
    branch: str = "unknown",
) -> int:
    requests = _load_vscode_chat_session_requests(path)
    imported = 0
    for request in requests:
        request_id = request.get("requestId")
        if not isinstance(request_id, str) or not request_id:
            continue
        timestamp = _from_epoch_millis(request.get("timestamp"))
        files = _extract_request_files(request)
        tags = ["import", "vscode-chat", "chat-history"]
        model_id = request.get("modelId")
        if isinstance(model_id, str) and model_id:
            tags.append(model_id.split("/")[-1])

        user_text = _extract_request_message_text(request)
        if user_text:
            user_ref = f"{source}:{path}:{request_id}:user"
            if not service.has_external_ref(user_ref):
                service.store_turn(
                    repo_name=repo_name,
                    repo_path=repo_path,
                    branch=branch,
                    session_id=session_id,
                    role="user",
                    source=source,
                    text=user_text,
                    tags=tags,
                    topics=["ai", "memory"],
                    files=files,
                    timestamp=timestamp,
                    external_ref=user_ref,
                )
                imported += 1

        assistant_text = _extract_assistant_response_text(request)
        if assistant_text:
            assistant_ref = f"{source}:{path}:{request_id}:assistant"
            if not service.has_external_ref(assistant_ref):
                service.store_turn(
                    repo_name=repo_name,
                    repo_path=repo_path,
                    branch=branch,
                    session_id=session_id,
                    role="assistant",
                    source=source,
                    text=assistant_text,
                    tags=tags,
                    topics=["ai", "memory"],
                    files=files,
                    timestamp=timestamp,
                    external_ref=assistant_ref,
                )
                imported += 1
    return imported


def _load_vscode_chat_session_requests(path: Path) -> list[dict[str, Any]]:
    if path.suffix.lower() == ".json":
        payload = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
        requests = payload.get("requests")
        if isinstance(requests, list):
            return [item for item in requests if isinstance(item, dict)]
        return []

    state: dict[str, Any] = {}
    with path.open("r", encoding="utf-8", errors="ignore") as handle:
        for line in handle:
            raw = line.strip()
            if not raw:
                continue
            entry = json.loads(raw)
            kind = entry.get("kind")
            key_path = entry.get("k")
            value = entry.get("v")
            if kind == 0 and isinstance(value, dict):
                state = value
            elif kind in {1, 2} and isinstance(key_path, list):
                _apply_session_patch(state, key_path, value, append=(kind == 2))
    requests = state.get("requests") or []
    return [item for item in requests if isinstance(item, dict)]


def _apply_session_patch(state: dict[str, Any], key_path: list[Any], value: Any, *, append: bool) -> None:
    target: Any = state
    for index, segment in enumerate(key_path[:-1]):
        if isinstance(segment, int):
            if not isinstance(target, list):
                return
            while len(target) <= segment:
                target.append({})
            target = target[segment]
        else:
            if not isinstance(target, dict):
                return
            next_segment = key_path[index + 1]
            if segment not in target:
                target[segment] = [] if isinstance(next_segment, int) else {}
            target = target[segment]

    last_key = key_path[-1]
    if isinstance(last_key, int):
        if not isinstance(target, list):
            return
        while len(target) <= last_key:
            target.append(None)
        if append and isinstance(value, list):
            if target[last_key] is None:
                target[last_key] = []
            if isinstance(target[last_key], list):
                target[last_key].extend(value)
        else:
            target[last_key] = value
        return

    if not isinstance(target, dict):
        return
    if append:
        target.setdefault(last_key, [])
        if isinstance(target[last_key], list) and isinstance(value, list):
            target[last_key].extend(value)
        else:
            target[last_key] = value
    else:
        target[last_key] = value


def _extract_request_message_text(request: dict[str, Any]) -> str:
    message = request.get("message")
    if isinstance(message, dict):
        text = message.get("text")
        if isinstance(text, str):
            return text.strip()
    return ""


def _extract_assistant_response_text(request: dict[str, Any]) -> str:
    chunks: list[str] = []
    for item in request.get("response") or []:
        if not isinstance(item, dict):
            continue
        kind = item.get("kind")
        value = item.get("value")
        if kind in {None, "markdownContent", "markdownV2"} and isinstance(value, str) and value.strip():
            chunks.append(value.strip())
    return "\n\n".join(chunks)


def _extract_request_files(request: dict[str, Any]) -> list[str]:
    files: list[str] = []
    for item in request.get("response") or []:
        if not isinstance(item, dict):
            continue
        base_uri = item.get("baseUri")
        if isinstance(base_uri, dict):
            path = base_uri.get("path")
            if isinstance(path, str) and path:
                files.append(path.lstrip("/"))
        uris = item.get("uris")
        if isinstance(uris, dict):
            for uri in uris.keys():
                parsed = _uri_to_path(uri)
                if parsed is not None:
                    files.append(str(parsed))
        invocation = item.get("invocationMessage")
        if isinstance(invocation, dict):
            uri_map = invocation.get("uris")
            if isinstance(uri_map, dict):
                for uri in uri_map.keys():
                    parsed = _uri_to_path(uri)
                    if parsed is not None:
                        files.append(str(parsed))
    return normalize_values(files)


def _from_epoch_millis(value: Any) -> str | None:
    if not isinstance(value, int):
        return None
    return datetime.fromtimestamp(value / 1000, tz=timezone.utc).replace(microsecond=0).isoformat()