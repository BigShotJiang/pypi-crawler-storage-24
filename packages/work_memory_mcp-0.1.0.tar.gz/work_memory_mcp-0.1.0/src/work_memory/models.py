from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal
from uuid import uuid4


EventKind = Literal["turn", "note", "command"]
Role = Literal["user", "assistant", "system"]


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


@dataclass(slots=True)
class StorageConfig:
    db_path: Path
    archive_path: Path


@dataclass(slots=True)
class EventRecord:
    repo_name: str
    repo_path: str
    branch: str
    session_id: str
    source: str
    event_type: EventKind
    timestamp: str = field(default_factory=utc_now)
    event_id: str = field(default_factory=lambda: str(uuid4()))
    role: Role | None = None
    text: str = ""
    title: str | None = None
    command_text: str | None = None
    cwd: str | None = None
    exit_code: int | None = None
    external_ref: str | None = None
    tags: list[str] = field(default_factory=list)
    entities: list[str] = field(default_factory=list)
    topics: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)
    commit_refs: list[str] = field(default_factory=list)


@dataclass(slots=True)
class SearchQuery:
    text: str | None = None
    repo_names: list[str] = field(default_factory=list)
    repo_paths: list[str] = field(default_factory=list)
    session_ids: list[str] = field(default_factory=list)
    branch: str | None = None
    source: str | None = None
    tags: list[str] = field(default_factory=list)
    entities: list[str] = field(default_factory=list)
    topics: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)
    date_from: str | None = None
    date_to: str | None = None
    limit: int = 20


@dataclass(slots=True)
class SearchResult:
    event_id: str
    event_type: str
    repo_name: str
    repo_path: str
    branch: str
    session_id: str
    source: str
    timestamp: str
    role: str | None
    title: str | None
    text: str
    command_text: str | None
    cwd: str | None
    exit_code: int | None
    external_ref: str | None
    tags: list[str]
    entities: list[str]
    topics: list[str]
    files: list[str]
    commit_refs: list[str]


@dataclass(slots=True)
class RecursiveRecallIteration:
    prompt: dict[str, Any]
    response: str
    filters: dict[str, Any]
    result_count: int
    sample_event_ids: list[str] = field(default_factory=list)
    branch_kind: str | None = None
    branch_values: list[str] = field(default_factory=list)
    subcalls: list["RecursiveRecallResult"] = field(default_factory=list)
    final_answer: str | None = None
    iteration_time: float | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "prompt": self.prompt,
            "response": self.response,
            "filters": self.filters,
            "result_count": self.result_count,
            "sample_event_ids": list(self.sample_event_ids),
            "branch_kind": self.branch_kind,
            "branch_values": list(self.branch_values),
            "subcalls": [subcall.to_dict() for subcall in self.subcalls],
            "final_answer": self.final_answer,
            "iteration_time": self.iteration_time,
        }
        return payload


@dataclass(slots=True)
class RecursiveRecallResult:
    prompt: dict[str, Any]
    response: str
    results: list[SearchResult]
    execution_time: float
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "prompt": self.prompt,
            "response": self.response,
            "results": [asdict(result) for result in self.results],
            "execution_time": self.execution_time,
        }
        if self.metadata is not None:
            payload["metadata"] = self.metadata
        return payload
