from __future__ import annotations

import re
from collections.abc import Iterable


TOPIC_PATTERNS: dict[str, tuple[str, ...]] = {
    "auth": ("auth", "oauth", "login", "sso", "token", "jwt", "rbac"),
    "deployment": ("deploy", "deployment", "release", "rollout", "helm", "kubernetes", "docker"),
    "memory": ("memory", "recall", "history", "context", "session", "retrieval"),
    "ai": ("llm", "model", "embedding", "agent", "ai", "prompt"),
    "discord": ("discord", "thread", "guild", "channel", "message"),
    "osint": ("osint", "investigation", "intel", "recon", "threat"),
    "architecture": ("architecture", "design", "schema", "boundary", "interface"),
    "infra": ("infra", "infrastructure", "terraform", "aws", "azure", "gcp", "nginx"),
}

TECH_TERMS = {
    "Python",
    "SQLite",
    "MongoDB",
    "PostgreSQL",
    "MySQL",
    "Discord",
    "NVDA",
    "Docker",
    "Kubernetes",
    "Terraform",
    "FastAPI",
    "Typer",
    "pytest",
    "MCP",
    "GitHub",
    "OAuth",
    "JWT",
    "Redis",
}

SERVICE_TERMS = {
    "AWS",
    "Azure",
    "GCP",
    "GitHub",
    "Discord",
    "MongoDB",
    "SQLite",
    "Kubernetes",
}

TICKER_RE = re.compile(r"\b[A-Z]{2,5}\b")
WORD_RE = re.compile(r"[A-Za-z0-9_./:-]+")


def normalize_values(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    normalized: list[str] = []
    for value in values:
        item = value.strip()
        if not item:
            continue
        key = item.casefold()
        if key in seen:
            continue
        seen.add(key)
        normalized.append(item)
    return normalized


def extract_topics(text: str, explicit: Iterable[str] | None = None) -> list[str]:
    lowered = text.casefold()
    topics = list(explicit or [])
    for topic, patterns in TOPIC_PATTERNS.items():
        if any(pattern in lowered for pattern in patterns):
            topics.append(topic)
    return normalize_values(topics)


def extract_entities(text: str, explicit: Iterable[str] | None = None) -> list[str]:
    entities = list(explicit or [])
    words = set(WORD_RE.findall(text))
    for word in words:
        cleaned = word.strip(".,;:()[]{}\"'")
        if cleaned in TECH_TERMS or cleaned in SERVICE_TERMS:
            entities.append(cleaned)
    entities.extend(sorted(TICKER_RE.findall(text)))
    return normalize_values(entities)


def extract_tags(text: str, explicit: Iterable[str] | None = None) -> list[str]:
    tags = list(explicit or [])
    lowered = text.casefold()
    for topic, patterns in TOPIC_PATTERNS.items():
        if any(pattern in lowered for pattern in patterns):
            tags.append(topic)
    return normalize_values(tags)


def enrich_metadata(
    text: str,
    *,
    tags: Iterable[str] | None = None,
    entities: Iterable[str] | None = None,
    topics: Iterable[str] | None = None,
) -> tuple[list[str], list[str], list[str]]:
    merged_tags = extract_tags(text, tags)
    merged_entities = extract_entities(text, entities)
    explicit_topics = list(topics or []) + list(tags or [])
    merged_topics = extract_topics(text, explicit_topics)
    return merged_tags, merged_entities, merged_topics
