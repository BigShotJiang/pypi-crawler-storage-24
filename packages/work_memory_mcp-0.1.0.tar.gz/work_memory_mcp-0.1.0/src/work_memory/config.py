from __future__ import annotations

import os
from pathlib import Path


def default_data_dir(root: Path | None = None) -> Path:
    if root is not None:
        return root / "data"

    explicit_home = os.environ.get("WORK_MEMORY_HOME")
    if explicit_home:
        return Path(explicit_home)

    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        return Path(local_app_data) / "work-memory"

    return Path.home() / ".work-memory"