from __future__ import annotations

from pathlib import Path

from .config import default_data_dir
from .extractor import enrich_metadata
from .models import EventRecord, SearchQuery, StorageConfig, utc_now
from .recursive_recall import RecursiveRecallEngine, RecursiveRecallLogger
from .retrieval import Retriever
from .storage import Storage


class MemoryService:
    def __init__(self, db_path: Path, archive_path: Path) -> None:
        self.storage = Storage(StorageConfig(db_path=db_path, archive_path=archive_path))
        self.retriever = Retriever(self.storage)
        self.recursive_retriever = RecursiveRecallEngine(self.retriever)

    def initialize(self) -> None:
        self.storage.initialize()

    def store_turn(
        self,
        *,
        repo_name: str,
        repo_path: str,
        branch: str,
        session_id: str,
        role: str,
        source: str,
        text: str,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        commit_refs: list[str] | None = None,
        timestamp: str | None = None,
        external_ref: str | None = None,
    ) -> str:
        merged_tags, merged_entities, merged_topics = enrich_metadata(
            text,
            tags=tags,
            entities=entities,
            topics=topics,
        )
        record = EventRecord(
            repo_name=repo_name,
            repo_path=repo_path,
            branch=branch,
            session_id=session_id,
            source=source,
            event_type="turn",
            role=role,
            text=text,
            timestamp=timestamp or utc_now(),
            external_ref=external_ref,
            tags=merged_tags,
            entities=merged_entities,
            topics=merged_topics,
            files=files or [],
            commit_refs=commit_refs or [],
        )
        return self.storage.store_event(record)

    def store_note(
        self,
        *,
        repo_name: str,
        repo_path: str,
        branch: str,
        session_id: str,
        source: str,
        title: str,
        text: str,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        commit_refs: list[str] | None = None,
        timestamp: str | None = None,
        external_ref: str | None = None,
    ) -> str:
        merged_tags, merged_entities, merged_topics = enrich_metadata(
            f"{title} {text}",
            tags=tags,
            entities=entities,
            topics=topics,
        )
        record = EventRecord(
            repo_name=repo_name,
            repo_path=repo_path,
            branch=branch,
            session_id=session_id,
            source=source,
            event_type="note",
            title=title,
            text=text,
            timestamp=timestamp or utc_now(),
            external_ref=external_ref,
            tags=merged_tags,
            entities=merged_entities,
            topics=merged_topics,
            files=files or [],
            commit_refs=commit_refs or [],
        )
        return self.storage.store_event(record)

    def store_command(
        self,
        *,
        repo_name: str,
        repo_path: str,
        branch: str,
        session_id: str,
        source: str,
        command_text: str,
        cwd: str | None = None,
        exit_code: int | None = None,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        commit_refs: list[str] | None = None,
        timestamp: str | None = None,
        external_ref: str | None = None,
    ) -> str:
        merged_tags, merged_entities, merged_topics = enrich_metadata(
            command_text,
            tags=tags,
            entities=entities,
            topics=topics,
        )
        record = EventRecord(
            repo_name=repo_name,
            repo_path=repo_path,
            branch=branch,
            session_id=session_id,
            source=source,
            event_type="command",
            text=command_text,
            command_text=command_text,
            cwd=cwd,
            exit_code=exit_code,
            timestamp=timestamp or utc_now(),
            external_ref=external_ref,
            tags=merged_tags,
            entities=merged_entities,
            topics=merged_topics,
            files=files or [],
            commit_refs=commit_refs or [],
        )
        return self.storage.store_event(record)

    def search(self, query: SearchQuery):
        return self.retriever.search(query)

    def has_external_ref(self, external_ref: str) -> bool:
        return self.storage.has_external_ref(external_ref)

    def recall_project(
        self,
        *,
        repo_name: str | None = None,
        repo_path: str | None = None,
        query: str | None = None,
        branch: str | None = None,
        session_id: str | None = None,
        source: str | None = None,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        limit: int = 20,
    ):
        return self.retriever.recall_project(
            repo_name=repo_name,
            repo_path=repo_path,
            query=query,
            branch=branch,
            session_id=session_id,
            source=source,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            limit=limit,
        )

    def recall_cross_project(
        self,
        *,
        query: str | None = None,
        repo_names: list[str] | None = None,
        repo_paths: list[str] | None = None,
        branch: str | None = None,
        source: str | None = None,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        limit: int = 20,
    ):
        return self.retriever.recall_cross_project(
            query=query,
            repo_names=repo_names,
            repo_paths=repo_paths,
            branch=branch,
            source=source,
            tags=tags,
            entities=entities,
            topics=topics,
            files=files,
            date_from=date_from,
            date_to=date_to,
            limit=limit,
        )

    def summarize_topic(self, topic: str, limit: int = 10):
        return self.retriever.summarize_topic(topic, limit=limit)

    def recursive_recall(
        self,
        query: SearchQuery,
        *,
        max_depth: int = 2,
        branch_limit: int = 3,
        log_dir: str | None = None,
    ):
        logger = RecursiveRecallLogger(log_dir=log_dir) if log_dir else None
        return self.recursive_retriever.recall(
            query,
            max_depth=max_depth,
            branch_limit=branch_limit,
            logger=logger,
        )


def default_service(root: Path | None = None) -> MemoryService:
    data_dir = default_data_dir(root)
    return MemoryService(
        db_path=data_dir / "work_memory.db",
        archive_path=data_dir / "raw_events.jsonl",
    )
