from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path

from .ingest import (
    discover_vscode_sources,
    import_path,
    import_vscode_chat_session_sources,
    import_vscode_copilot_sources,
)
from .models import SearchQuery
from .service import default_service


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    handler = COMMAND_HANDLERS[args.command]
    handler(args)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="work-memory")
    parser.add_argument(
        "--root",
        type=Path,
        default=None,
        help="Override the shared machine-level storage location with a project root",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("init", help="Initialize SQLite and JSONL storage")

    turn = subparsers.add_parser("store-turn", help="Store a conversation turn")
    _add_common_store_args(turn)
    turn.add_argument("--role", required=True, choices=["user", "assistant", "system"])
    turn.add_argument("--text", required=True)

    note = subparsers.add_parser("store-note", help="Store a manual note or handoff")
    _add_common_store_args(note)
    note.add_argument("--title", required=True)
    note.add_argument("--text", required=True)

    command = subparsers.add_parser("store-command", help="Store a command invocation")
    _add_common_store_args(command)
    command.add_argument("--command", required=True, dest="command_text")
    command.add_argument("--cwd")
    command.add_argument("--exit-code", type=int)

    search = subparsers.add_parser("search", help="Search across events with filters")
    _add_search_args(search)

    recall_project = subparsers.add_parser("recall-project", help="Recall within a single project")
    _add_search_args(recall_project)

    recall_cross = subparsers.add_parser(
        "recall-cross-project",
        help="Recall across projects with explicit filters",
    )
    _add_search_args(recall_cross)

    recursive_recall = subparsers.add_parser(
        "recursive-recall",
        help="Run an RLM-inspired recursive recall plan over memory",
    )
    _add_search_args(recursive_recall)
    recursive_recall.add_argument("--max-depth", type=int, default=2)
    recursive_recall.add_argument("--branch-limit", type=int, default=3)
    recursive_recall.add_argument("--log-dir")

    summarize = subparsers.add_parser("summarize-topic", help="Summarize a topic across memory")
    summarize.add_argument("--topic", required=True)
    summarize.add_argument("--limit", type=int, default=10)

    discover = subparsers.add_parser("discover-sources", help="Discover likely local chat log sources")
    discover.add_argument("--limit", type=int, default=50)

    import_file_parser = subparsers.add_parser("import-path", help="Import JSON, JSONL, or text files into memory")
    import_file_parser.add_argument("--path", required=True, type=Path)
    import_file_parser.add_argument("--repo-name", required=True)
    import_file_parser.add_argument("--repo-path", required=True)
    import_file_parser.add_argument("--branch", default="import")
    import_file_parser.add_argument("--session-id", required=True)
    import_file_parser.add_argument("--source", default="import-file")
    import_file_parser.add_argument(
        "--format",
        choices=["auto", "json", "jsonl", "text", "vscode-chat-session"],
        default="auto",
    )

    import_copilot = subparsers.add_parser(
        "import-vscode-copilot",
        help="Import discovered VS Code GitHub Copilot Chat resources into memory",
    )
    import_copilot.add_argument("--limit", type=int, default=200)

    import_sessions = subparsers.add_parser(
        "import-vscode-sessions",
        help="Import structured VS Code chat session files into memory as user and assistant turns",
    )
    import_sessions.add_argument("--limit", type=int, default=200)

    return parser


def _add_common_store_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--repo-name", required=True)
    parser.add_argument("--repo-path", required=True)
    parser.add_argument("--branch", required=True)
    parser.add_argument("--session-id", required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--timestamp")
    parser.add_argument("--tag", action="append", default=[])
    parser.add_argument("--entity", action="append", default=[])
    parser.add_argument("--topic", action="append", default=[])
    parser.add_argument("--file", action="append", default=[])
    parser.add_argument("--commit-ref", action="append", default=[])


def _add_search_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--query")
    parser.add_argument("--repo-name", action="append", default=[])
    parser.add_argument("--repo-path", action="append", default=[])
    parser.add_argument("--session-id", action="append", default=[])
    parser.add_argument("--branch")
    parser.add_argument("--source")
    parser.add_argument("--tag", action="append", default=[])
    parser.add_argument("--entity", action="append", default=[])
    parser.add_argument("--topic", action="append", default=[])
    parser.add_argument("--file", action="append", default=[])
    parser.add_argument("--date-from")
    parser.add_argument("--date-to")
    parser.add_argument("--limit", type=int, default=20)


def _service(root: Path):
    service = default_service(root)
    service.initialize()
    return service


def handle_init(args: argparse.Namespace) -> None:
    service = default_service(args.root)
    service.initialize()
    print(json.dumps({
        "status": "initialized",
        "db_path": str(service.storage.config.db_path),
        "archive_path": str(service.storage.config.archive_path),
    }, indent=2))


def handle_store_turn(args: argparse.Namespace) -> None:
    service = _service(args.root)
    event_id = service.store_turn(
        repo_name=args.repo_name,
        repo_path=args.repo_path,
        branch=args.branch,
        session_id=args.session_id,
        role=args.role,
        source=args.source,
        text=args.text,
        tags=args.tag,
        entities=args.entity,
        topics=args.topic,
        files=args.file,
        commit_refs=args.commit_ref,
        timestamp=args.timestamp,
    )
    print(json.dumps({"stored": event_id, "type": "turn"}, indent=2))


def handle_store_note(args: argparse.Namespace) -> None:
    service = _service(args.root)
    event_id = service.store_note(
        repo_name=args.repo_name,
        repo_path=args.repo_path,
        branch=args.branch,
        session_id=args.session_id,
        source=args.source,
        title=args.title,
        text=args.text,
        tags=args.tag,
        entities=args.entity,
        topics=args.topic,
        files=args.file,
        commit_refs=args.commit_ref,
        timestamp=args.timestamp,
    )
    print(json.dumps({"stored": event_id, "type": "note"}, indent=2))


def handle_store_command(args: argparse.Namespace) -> None:
    service = _service(args.root)
    event_id = service.store_command(
        repo_name=args.repo_name,
        repo_path=args.repo_path,
        branch=args.branch,
        session_id=args.session_id,
        source=args.source,
        command_text=args.command_text,
        cwd=args.cwd,
        exit_code=args.exit_code,
        tags=args.tag,
        entities=args.entity,
        topics=args.topic,
        files=args.file,
        commit_refs=args.commit_ref,
        timestamp=args.timestamp,
    )
    print(json.dumps({"stored": event_id, "type": "command"}, indent=2))


def handle_search(args: argparse.Namespace) -> None:
    service = _service(args.root)
    results = service.search(
        SearchQuery(
            text=args.query,
            repo_names=args.repo_name,
            repo_paths=args.repo_path,
            session_ids=args.session_id,
            branch=args.branch,
            source=args.source,
            tags=args.tag,
            entities=args.entity,
            topics=args.topic,
            files=args.file,
            date_from=args.date_from,
            date_to=args.date_to,
            limit=args.limit,
        )
    )
    print(json.dumps([asdict(result) for result in results], indent=2))


def handle_recall_project(args: argparse.Namespace) -> None:
    service = _service(args.root)
    repo_name = args.repo_name[0] if args.repo_name else None
    repo_path = args.repo_path[0] if args.repo_path else None
    results = service.recall_project(
        repo_name=repo_name,
        repo_path=repo_path,
        query=args.query,
        branch=args.branch,
        session_id=args.session_id[0] if args.session_id else None,
        source=args.source,
        tags=args.tag,
        entities=args.entity,
        topics=args.topic,
        files=args.file,
        limit=args.limit,
    )
    print(json.dumps([asdict(result) for result in results], indent=2))


def handle_recall_cross_project(args: argparse.Namespace) -> None:
    service = _service(args.root)
    results = service.recall_cross_project(
        query=args.query,
        repo_names=args.repo_name,
        repo_paths=args.repo_path,
        branch=args.branch,
        source=args.source,
        tags=args.tag,
        entities=args.entity,
        topics=args.topic,
        files=args.file,
        date_from=args.date_from,
        date_to=args.date_to,
        limit=args.limit,
    )
    print(json.dumps([asdict(result) for result in results], indent=2))


def handle_summarize_topic(args: argparse.Namespace) -> None:
    service = _service(args.root)
    print(json.dumps(service.summarize_topic(args.topic, limit=args.limit), indent=2))


def handle_recursive_recall(args: argparse.Namespace) -> None:
    service = _service(args.root)
    result = service.recursive_recall(
        SearchQuery(
            text=args.query,
            repo_names=args.repo_name,
            repo_paths=args.repo_path,
            session_ids=args.session_id,
            branch=args.branch,
            source=args.source,
            tags=args.tag,
            entities=args.entity,
            topics=args.topic,
            files=args.file,
            date_from=args.date_from,
            date_to=args.date_to,
            limit=args.limit,
        ),
        max_depth=args.max_depth,
        branch_limit=args.branch_limit,
        log_dir=args.log_dir,
    )
    print(json.dumps(result.to_dict(), indent=2))


def handle_discover_sources(args: argparse.Namespace) -> None:
    candidates = discover_vscode_sources(limit=args.limit)
    print(json.dumps([asdict(candidate) for candidate in candidates], indent=2))


def handle_import_path(args: argparse.Namespace) -> None:
    service = _service(args.root)
    summary = import_path(
        service,
        source_path=args.path,
        repo_name=args.repo_name,
        repo_path=args.repo_path,
        branch=args.branch,
        session_id=args.session_id,
        source=args.source,
        format_name=args.format,
    )
    print(json.dumps(asdict(summary), indent=2))


def handle_import_vscode_copilot(args: argparse.Namespace) -> None:
    service = _service(args.root)
    summary = import_vscode_copilot_sources(service, limit=args.limit)
    print(json.dumps(asdict(summary), indent=2))


def handle_import_vscode_sessions(args: argparse.Namespace) -> None:
    service = _service(args.root)
    summary = import_vscode_chat_session_sources(service, limit=args.limit)
    print(json.dumps(asdict(summary), indent=2))


COMMAND_HANDLERS = {
    "init": handle_init,
    "store-turn": handle_store_turn,
    "store-note": handle_store_note,
    "store-command": handle_store_command,
    "search": handle_search,
    "recall-project": handle_recall_project,
    "recall-cross-project": handle_recall_cross_project,
    "recursive-recall": handle_recursive_recall,
    "summarize-topic": handle_summarize_topic,
    "discover-sources": handle_discover_sources,
    "import-path": handle_import_path,
    "import-vscode-copilot": handle_import_vscode_copilot,
    "import-vscode-sessions": handle_import_vscode_sessions,
}


if __name__ == "__main__":
    main()
