from __future__ import annotations

from .models import SearchQuery
from .storage import Storage


class Retriever:
    def __init__(self, storage: Storage) -> None:
        self.storage = storage

    def search(self, query: SearchQuery):
        return self.storage.search(query)

    def recall_project(
        self,
        *,
        repo_name: str | None = None,
        repo_path: str | None = None,
        query: str | None = None,
        branch: str | None = None,
        session_id: str | None = None,
        source: str | None = None,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        limit: int = 20,
    ):
        return self.storage.search(
            SearchQuery(
                text=query,
                repo_names=[repo_name] if repo_name else [],
                repo_paths=[repo_path] if repo_path else [],
                session_ids=[session_id] if session_id else [],
                branch=branch,
                source=source,
                tags=tags or [],
                entities=entities or [],
                topics=topics or [],
                files=files or [],
                limit=limit,
            )
        )

    def recall_cross_project(
        self,
        *,
        query: str | None = None,
        repo_names: list[str] | None = None,
        repo_paths: list[str] | None = None,
        branch: str | None = None,
        source: str | None = None,
        tags: list[str] | None = None,
        entities: list[str] | None = None,
        topics: list[str] | None = None,
        files: list[str] | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        limit: int = 20,
    ):
        return self.storage.search(
            SearchQuery(
                text=query,
                repo_names=repo_names or [],
                repo_paths=repo_paths or [],
                branch=branch,
                source=source,
                tags=tags or [],
                entities=entities or [],
                topics=topics or [],
                files=files or [],
                date_from=date_from,
                date_to=date_to,
                limit=limit,
            )
        )

    def summarize_topic(self, topic: str, limit: int = 10):
        return self.storage.summarize_topic(topic, limit=limit)
