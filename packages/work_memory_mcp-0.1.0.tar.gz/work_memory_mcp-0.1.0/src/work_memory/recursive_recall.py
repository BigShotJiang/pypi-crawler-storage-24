from __future__ import annotations

import json
import os
import time
import uuid
from collections import Counter
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .models import RecursiveRecallIteration, RecursiveRecallResult, SearchQuery, SearchResult
from .retrieval import Retriever


class RecursiveRecallLogger:
    def __init__(self, log_dir: str | None = None, file_name: str = "recursive-recall"):
        self._save_to_disk = log_dir is not None
        self.log_dir = log_dir
        self.log_file_path: str | None = None
        if self._save_to_disk and log_dir:
            os.makedirs(log_dir, exist_ok=True)
            timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H-%M-%S")
            run_id = str(uuid.uuid4())[:8]
            self.log_file_path = os.path.join(log_dir, f"{file_name}_{timestamp}_{run_id}.jsonl")

        self._run_metadata: dict[str, Any] | None = None
        self._iterations: list[dict[str, Any]] = []
        self._iteration_count = 0

    def log_metadata(self, metadata: dict[str, Any]) -> None:
        self._run_metadata = metadata
        if self._save_to_disk and self.log_file_path:
            entry = {"type": "metadata", "timestamp": datetime.now(timezone.utc).isoformat(), **metadata}
            with open(self.log_file_path, "a", encoding="utf-8") as handle:
                json.dump(entry, handle)
                handle.write("\n")

    def log(self, iteration: RecursiveRecallIteration) -> None:
        self._iteration_count += 1
        entry = {
            "type": "iteration",
            "iteration": self._iteration_count,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **iteration.to_dict(),
        }
        self._iterations.append(entry)
        if self._save_to_disk and self.log_file_path:
            with open(self.log_file_path, "a", encoding="utf-8") as handle:
                json.dump(entry, handle)
                handle.write("\n")

    def clear_iterations(self) -> None:
        self._iterations = []
        self._iteration_count = 0

    def get_trajectory(self) -> dict[str, Any] | None:
        if self._run_metadata is None:
            return None
        return {
            "run_metadata": self._run_metadata,
            "iterations": list(self._iterations),
        }


class RecursiveRecallEngine:
    def __init__(self, retriever: Retriever) -> None:
        self.retriever = retriever

    def recall(
        self,
        query: SearchQuery,
        *,
        max_depth: int = 2,
        branch_limit: int = 3,
        logger: RecursiveRecallLogger | None = None,
    ) -> RecursiveRecallResult:
        if logger:
            logger.clear_iterations()
            logger.log_metadata(
                {
                    "strategy": "recursive-memory-recall",
                    "max_depth": max_depth,
                    "branch_limit": branch_limit,
                    "root_query": self._query_to_prompt(query),
                }
            )
        return self._recall(
            query,
            depth=0,
            max_depth=max_depth,
            branch_limit=branch_limit,
            logger=logger,
        )

    def _recall(
        self,
        query: SearchQuery,
        *,
        depth: int,
        max_depth: int,
        branch_limit: int,
        logger: RecursiveRecallLogger | None,
    ) -> RecursiveRecallResult:
        started = time.perf_counter()
        results = self.retriever.search(query)
        branch_kind, branch_values = self._choose_branch(query, results, branch_limit=branch_limit, depth=depth, max_depth=max_depth)
        subcalls: list[RecursiveRecallResult] = []

        if branch_kind is not None:
            for value in branch_values:
                narrowed_query = self._narrow_query(query, branch_kind, value)
                subcalls.append(
                    self._recall(
                        narrowed_query,
                        depth=depth + 1,
                        max_depth=max_depth,
                        branch_limit=branch_limit,
                        logger=None,
                    )
                )

        response = self._build_response(results, branch_kind=branch_kind, branch_values=branch_values, subcalls=subcalls, depth=depth)
        iteration_time = time.perf_counter() - started
        iteration = RecursiveRecallIteration(
            prompt={"depth": depth, **self._query_to_prompt(query)},
            response=response,
            filters=self._query_to_prompt(query),
            result_count=len(results),
            sample_event_ids=[result.event_id for result in results[:5]],
            branch_kind=branch_kind,
            branch_values=branch_values,
            subcalls=subcalls,
            final_answer=response,
            iteration_time=iteration_time,
        )
        metadata = {
            "run_metadata": {
                "strategy": "recursive-memory-recall",
                "depth": depth,
                "max_depth": max_depth,
                "branch_limit": branch_limit,
            },
            "iterations": [iteration.to_dict()],
        }
        if logger and depth == 0:
            logger.log(iteration)
            metadata = logger.get_trajectory()
        return RecursiveRecallResult(
            prompt={"depth": depth, **self._query_to_prompt(query)},
            response=response,
            results=results,
            execution_time=iteration_time,
            metadata=metadata,
        )

    def _choose_branch(
        self,
        query: SearchQuery,
        results: list[SearchResult],
        *,
        branch_limit: int,
        depth: int,
        max_depth: int,
    ) -> tuple[str | None, list[str]]:
        if depth >= max_depth or len(results) <= 1:
            return None, []

        if not query.repo_names and not query.repo_paths:
            repo_counts = Counter(result.repo_name for result in results)
            if len(repo_counts) > 1:
                return "repo_name", [name for name, _ in repo_counts.most_common(branch_limit)]

        if not query.session_ids:
            session_counts = Counter(result.session_id for result in results)
            if len(session_counts) > 1:
                return "session_id", [session_id for session_id, _ in session_counts.most_common(branch_limit)]

        if not query.topics:
            topic_counts = Counter(topic for result in results for topic in result.topics)
            if len(topic_counts) > 1:
                return "topic", [topic for topic, _ in topic_counts.most_common(branch_limit)]

        return None, []

    def _narrow_query(self, query: SearchQuery, branch_kind: str, value: str) -> SearchQuery:
        narrowed = SearchQuery(**asdict(query))
        if branch_kind == "repo_name":
            narrowed.repo_names = [value]
        elif branch_kind == "session_id":
            narrowed.session_ids = [value]
        elif branch_kind == "topic":
            narrowed.topics = [value]
        return narrowed

    def _query_to_prompt(self, query: SearchQuery) -> dict[str, Any]:
        return {
            "text": query.text,
            "repo_names": list(query.repo_names),
            "repo_paths": list(query.repo_paths),
            "session_ids": list(query.session_ids),
            "branch": query.branch,
            "source": query.source,
            "tags": list(query.tags),
            "entities": list(query.entities),
            "topics": list(query.topics),
            "files": list(query.files),
            "date_from": query.date_from,
            "date_to": query.date_to,
            "limit": query.limit,
        }

    def _build_response(
        self,
        results: list[SearchResult],
        *,
        branch_kind: str | None,
        branch_values: list[str],
        subcalls: list[RecursiveRecallResult],
        depth: int,
    ) -> str:
        if not results:
            return f"Depth {depth}: no matching memory found."

        repo_count = len({result.repo_name for result in results})
        session_count = len({result.session_id for result in results})
        headline = f"Depth {depth}: found {len(results)} matches across {repo_count} repos and {session_count} sessions."

        if branch_kind and subcalls:
            branch_text = f" Decomposed by {branch_kind}: {', '.join(branch_values)}."
            child_lines = [subcall.response for subcall in subcalls]
            return headline + branch_text + " " + " ".join(child_lines)

        highlights = "; ".join(self._format_highlight(result) for result in results[:3])
        return f"{headline} Top matches: {highlights}"

    def _format_highlight(self, result: SearchResult) -> str:
        text = result.text or result.command_text or ""
        normalized = text.replace("\n", " ").strip()
        if len(normalized) > 96:
            normalized = normalized[:93] + "..."
        return f"[{result.repo_name}/{result.session_id}] {normalized}"