from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from .config import default_data_dir


def create_backup(destination: Path, *, source_home: Path | None = None) -> Path:
    source_root = source_home or default_data_dir()
    db_path = source_root / "work_memory.db"
    archive_path = source_root / "raw_events.jsonl"
    timestamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    destination.mkdir(parents=True, exist_ok=True)
    backup_path = destination / f"work-memory-backup-{timestamp}.zip"

    manifest = {
        "created_at": datetime.now(UTC).isoformat(),
        "source_home": str(source_root),
        "files": {
            "work_memory.db": db_path.exists(),
            "raw_events.jsonl": archive_path.exists(),
        },
    }

    with ZipFile(backup_path, "w", compression=ZIP_DEFLATED) as archive:
        archive.writestr("backup_manifest.json", json.dumps(manifest, indent=2) + "\n")
        if db_path.exists():
            archive.write(db_path, arcname="work_memory.db")
        if archive_path.exists():
            archive.write(archive_path, arcname="raw_events.jsonl")
    return backup_path


def ensure_safe_to_restore(destination_home: Path, force: bool) -> None:
    existing_files = [destination_home / "work_memory.db", destination_home / "raw_events.jsonl"]
    conflicts = [path for path in existing_files if path.exists()]
    if conflicts and not force:
        joined = ", ".join(str(path) for path in conflicts)
        raise SystemExit(f"Refusing to overwrite existing files without --force: {joined}")


def restore_backup(backup: Path, *, destination_home: Path | None = None, force: bool = False) -> Path:
    destination_root = destination_home or default_data_dir()
    destination_root.mkdir(parents=True, exist_ok=True)
    ensure_safe_to_restore(destination_root, force)

    with ZipFile(backup, "r") as archive:
        for name in ["work_memory.db", "raw_events.jsonl"]:
            if name in archive.namelist():
                archive.extract(name, path=destination_root)
    return destination_root


def build_backup_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Create a portable backup of the local Work Memory store.")
    parser.add_argument("--destination", type=Path, required=True, help="Directory where the backup zip will be written")
    parser.add_argument("--source-home", type=Path, default=None, help="Optional override for the Work Memory home directory")
    return parser


def build_restore_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Restore a Work Memory backup zip onto this machine.")
    parser.add_argument("--backup", type=Path, required=True, help="Backup zip created by work-memory-backup")
    parser.add_argument("--destination-home", type=Path, default=None, help="Optional override for the Work Memory home directory")
    parser.add_argument("--force", action="store_true", help="Overwrite existing database and archive files")
    return parser


def backup_main() -> None:
    args = build_backup_parser().parse_args()
    print(create_backup(args.destination, source_home=args.source_home))


def restore_main() -> None:
    args = build_restore_parser().parse_args()
    print(restore_backup(args.backup, destination_home=args.destination_home, force=args.force))
