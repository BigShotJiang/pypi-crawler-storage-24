from __future__ import annotations

import json
from pathlib import Path

from work_memory.config import default_data_dir
from work_memory.ingest import (
    discover_vscode_chat_session_sources,
    discover_vscode_copilot_sources,
    import_vscode_chat_session_sources,
    import_vscode_copilot_sources,
)
from work_memory.models import SearchQuery
from work_memory.service import MemoryService


def test_store_and_recall_project(tmp_path):
    service = MemoryService(
        db_path=tmp_path / "work_memory.db",
        archive_path=tmp_path / "raw_events.jsonl",
    )
    service.initialize()

    service.store_turn(
        repo_name="repo-a",
        repo_path="C:/code/repo-a",
        branch="main",
        session_id="repo-a-1",
        role="user",
        source="cli",
        text="How did we handle auth deployment memory?",
        tags=["decision"],
        files=["src/auth.py"],
        commit_refs=["abc1234"],
        timestamp="2026-03-05T09:00:00+00:00",
    )
    service.store_note(
        repo_name="repo-a",
        repo_path="C:/code/repo-a",
        branch="main",
        session_id="repo-a-1",
        source="manual",
        title="handoff",
        text="Discord thread resolved the auth token shape.",
        tags=["handoff"],
        timestamp="2026-03-05T09:05:00+00:00",
    )

    results = service.recall_project(repo_name="repo-a", query="Discord", topics=["auth"])

    assert len(results) == 1
    assert results[0].event_type == "note"
    assert "auth" in results[0].topics


def test_cross_project_filters_and_archive(tmp_path):
    service = MemoryService(
        db_path=tmp_path / "work_memory.db",
        archive_path=tmp_path / "raw_events.jsonl",
    )
    service.initialize()

    service.store_turn(
        repo_name="repo-a",
        repo_path="C:/code/repo-a",
        branch="main",
        session_id="repo-a-1",
        role="assistant",
        source="cli",
        text="NVDA work relied on MongoDB and Discord threads.",
        tags=["memory"],
        timestamp="2026-03-01T08:00:00+00:00",
    )
    service.store_command(
        repo_name="repo-b",
        repo_path="C:/code/repo-b",
        branch="feature/memory",
        session_id="repo-b-1",
        source="terminal",
        command_text="pytest -q tests/test_memory.py",
        cwd="C:/code/repo-b",
        exit_code=0,
        tags=["testing"],
        files=["tests/test_memory.py"],
        timestamp="2026-03-02T08:00:00+00:00",
    )

    results = service.recall_cross_project(
        query="MongoDB",
        entities=["MongoDB"],
        repo_names=["repo-a"],
    )
    assert len(results) == 1
    assert results[0].repo_name == "repo-a"

    archive_lines = (tmp_path / "raw_events.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(archive_lines) == 2
    first_record = json.loads(archive_lines[0])
    assert first_record["repo_name"] == "repo-a"
    assert "MongoDB" in first_record["entities"]


def test_search_metadata_first_with_file_filter(tmp_path):
    service = MemoryService(
        db_path=tmp_path / "work_memory.db",
        archive_path=tmp_path / "raw_events.jsonl",
    )
    service.initialize()

    service.store_note(
        repo_name="repo-a",
        repo_path="C:/code/repo-a",
        branch="main",
        session_id="repo-a-2",
        source="manual",
        title="architecture",
        text="We kept SQLite and JSONL instead of a vector database.",
        tags=["architecture"],
        files=["docs/architecture.md"],
        timestamp="2026-03-03T08:00:00+00:00",
    )
    service.store_note(
        repo_name="repo-b",
        repo_path="C:/code/repo-b",
        branch="main",
        session_id="repo-b-2",
        source="manual",
        title="other",
        text="Unrelated note about deployment.",
        tags=["deployment"],
        files=["docs/deploy.md"],
        timestamp="2026-03-04T08:00:00+00:00",
    )

    results = service.search(
        SearchQuery(
            text="SQLite",
            files=["docs/architecture.md"],
            limit=5,
        )
    )

    assert len(results) == 1
    assert results[0].repo_name == "repo-a"
    assert results[0].files == ["docs/architecture.md"]


def test_default_data_dir_prefers_machine_level(monkeypatch, tmp_path):
    machine_home = tmp_path / "machine-home"
    monkeypatch.setenv("LOCALAPPDATA", str(machine_home))
    monkeypatch.delenv("WORK_MEMORY_HOME", raising=False)

    assert default_data_dir() == machine_home / "work-memory"


def test_import_vscode_copilot_sources_is_idempotent(monkeypatch, tmp_path):
    app_data = tmp_path / "AppData" / "Roaming"
    workspace_root = app_data / "Code" / "User" / "workspaceStorage" / "abc123workspace"
    copilot_dir = workspace_root / "GitHub.copilot-chat"
    session_dir = copilot_dir / "chat-session-resources" / "session-1" / "call-1"
    session_dir.mkdir(parents=True)
    (session_dir / "content.txt").write_text("Discussed MongoDB memory import design.", encoding="utf-8")
    (copilot_dir / "workspace-chunks.json").write_text(
        json.dumps(
            {
                "version": "1.0.0",
                "entries": {
                    "file:///c%3A/Project/sample-repo/src/app.py": {"hash": "abc"},
                    "file:///c%3A/Project/sample-repo/README.md": {"hash": "def"}
                }
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv("APPDATA", str(app_data))

    service = MemoryService(
        db_path=tmp_path / "work_memory.db",
        archive_path=tmp_path / "raw_events.jsonl",
    )
    service.initialize()

    candidates = discover_vscode_copilot_sources(limit=10)
    assert len(candidates) == 1
    assert candidates[0].repo_name == "sample-repo"
    assert candidates[0].repo_path == str(Path("c:/Project/sample-repo"))

    first_import = import_vscode_copilot_sources(service, limit=10)
    second_import = import_vscode_copilot_sources(service, limit=10)

    assert first_import.imported == 1
    assert second_import.imported == 0
    assert second_import.skipped == 1

    results = service.recall_project(repo_name="sample-repo", query="MongoDB")
    assert len(results) == 1
    assert results[0].source == "vscode-copilot-chat"
    assert results[0].external_ref is not None


def test_import_vscode_chat_sessions_reconstructs_turns(monkeypatch, tmp_path):
    app_data = tmp_path / "AppData" / "Roaming"
    workspace_root = app_data / "Code" / "User" / "workspaceStorage" / "workspace123"
    chat_sessions_dir = workspace_root / "chatSessions"
    chat_sessions_dir.mkdir(parents=True)
    (workspace_root / "workspace.json").write_text(
        json.dumps({"folder": "file:///c%3A/Project/Thinkpackdiscord"}),
        encoding="utf-8",
    )
    session_file = chat_sessions_dir / "session-1.jsonl"
    session_file.write_text(
        "\n".join(
            [
                json.dumps(
                    {
                        "kind": 0,
                        "v": {
                            "version": 3,
                            "sessionId": "session-1",
                            "requests": [],
                            "inputState": {"inputText": ""},
                        },
                    }
                ),
                json.dumps(
                    {
                        "kind": 2,
                        "k": ["requests"],
                        "v": [
                            {
                                "requestId": "request-1",
                                "timestamp": 1770861172144,
                                "modelId": "copilot/claude-opus-4.5",
                                "message": {"text": "Why is the Discord bot timing out?"},
                                "response": [
                                    {
                                        "value": "I will inspect the local project and cloud logs first.",
                                        "baseUri": {"path": "/c:/Project/Thinkpackdiscord/", "scheme": "file"},
                                    },
                                    {
                                        "kind": "toolInvocationSerialized",
                                        "invocationMessage": {
                                            "value": "Reading file",
                                            "uris": {
                                                "file:///c%3A/Project/Thinkpackdiscord/utils/scheduler.py": {
                                                    "path": "/c:/Project/Thinkpackdiscord/utils/scheduler.py",
                                                    "scheme": "file"
                                                }
                                            }
                                        }
                                    }
                                ],
                            }
                        ],
                    }
                ),
            ]
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv("APPDATA", str(app_data))

    service = MemoryService(
        db_path=tmp_path / "work_memory.db",
        archive_path=tmp_path / "raw_events.jsonl",
    )
    service.initialize()

    candidates = discover_vscode_chat_session_sources(limit=10)
    assert len(candidates) == 1
    assert candidates[0].repo_name == "Thinkpackdiscord"
    assert candidates[0].repo_path == str(Path("c:/Project/Thinkpackdiscord"))

    summary = import_vscode_chat_session_sources(service, limit=10)
    assert summary.imported == 2

    results = service.recall_project(repo_name="Thinkpackdiscord", limit=10)
    assert len(results) == 2
    roles = sorted(result.role for result in results)
    assert roles == ["assistant", "user"]
    assistant = next(result for result in results if result.role == "assistant")
    assert any("scheduler.py" in path for path in assistant.files)
    assert assistant.external_ref is not None
