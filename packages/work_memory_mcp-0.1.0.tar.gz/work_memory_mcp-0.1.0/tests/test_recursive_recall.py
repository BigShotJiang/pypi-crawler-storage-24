from __future__ import annotations

import json
from pathlib import Path

from work_memory.models import SearchQuery
from work_memory.service import MemoryService


def test_recursive_recall_builds_nested_metadata(tmp_path: Path) -> None:
    service = MemoryService(
        db_path=tmp_path / "work_memory.db",
        archive_path=tmp_path / "raw_events.jsonl",
    )
    service.initialize()

    service.store_note(
        repo_name="repo-a",
        repo_path="C:/code/repo-a",
        branch="main",
        session_id="session-a1",
        source="manual",
        title="discord-handoff",
        text="Discord auth rollout for repo-a needed a scheduler patch.",
        tags=["auth", "discord"],
    )
    service.store_note(
        repo_name="repo-b",
        repo_path="C:/code/repo-b",
        branch="main",
        session_id="session-b1",
        source="manual",
        title="discord-handoff",
        text="Discord deploy notes for repo-b mentioned a retry queue.",
        tags=["deployment", "discord"],
    )

    result = service.recursive_recall(
        SearchQuery(text="Discord", limit=10),
        max_depth=2,
        branch_limit=2,
    )

    assert result.metadata is not None
    assert result.metadata["run_metadata"]["strategy"] == "recursive-memory-recall"
    assert len(result.metadata["iterations"]) == 1
    iteration = result.metadata["iterations"][0]
    assert iteration["branch_kind"] == "repo_name"
    assert len(iteration["subcalls"]) == 2


def test_recursive_recall_logs_jsonl(tmp_path: Path) -> None:
    service = MemoryService(
        db_path=tmp_path / "work_memory.db",
        archive_path=tmp_path / "raw_events.jsonl",
    )
    service.initialize()
    service.store_note(
        repo_name="repo-a",
        repo_path="C:/code/repo-a",
        branch="main",
        session_id="session-a1",
        source="manual",
        title="memory",
        text="SQLite memory retrieval was enough for the first pass.",
        tags=["memory"],
    )

    log_dir = tmp_path / "logs"
    result = service.recursive_recall(
        SearchQuery(text="SQLite", limit=5),
        max_depth=1,
        branch_limit=2,
        log_dir=str(log_dir),
    )

    assert result.metadata is not None
    log_files = list(log_dir.glob("recursive-recall_*.jsonl"))
    assert len(log_files) == 1
    lines = log_files[0].read_text(encoding="utf-8").splitlines()
    assert len(lines) == 2
    metadata_entry = json.loads(lines[0])
    iteration_entry = json.loads(lines[1])
    assert metadata_entry["type"] == "metadata"
    assert iteration_entry["type"] == "iteration"