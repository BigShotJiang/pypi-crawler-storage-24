from __future__ import annotations

from pathlib import Path

from work_memory.backup import create_backup, restore_backup
from work_memory.service import MemoryService


def test_backup_and_restore_round_trip(tmp_path: Path) -> None:
    source_home = tmp_path / "source-home"
    destination = tmp_path / "backup-destination"
    restore_home = tmp_path / "restore-home"

    service = MemoryService(
        db_path=source_home / "work_memory.db",
        archive_path=source_home / "raw_events.jsonl",
    )
    service.initialize()
    service.store_note(
        repo_name="repo-a",
        repo_path="C:/code/repo-a",
        branch="main",
        session_id="session-1",
        source="manual",
        title="handoff",
        text="Discord thread resolved the blocker.",
        tags=["discord"],
    )

    backup_path = create_backup(destination, source_home=source_home)
    restored_path = restore_backup(backup_path, destination_home=restore_home)

    assert backup_path.exists()
    assert restored_path == restore_home
    assert (restore_home / "work_memory.db").exists()
    assert (restore_home / "raw_events.jsonl").exists()
