from __future__ import annotations

import asyncio
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from work_memory.mcp_server import (
    build_memory_status,
    recall_project_payload,
    recursive_recall_payload,
    search_memory_payload,
)
from work_memory.service import MemoryService, default_service


def test_mcp_helper_payloads(tmp_path):
    service = MemoryService(
        db_path=tmp_path / "work_memory.db",
        archive_path=tmp_path / "raw_events.jsonl",
    )
    service.initialize()
    service.store_note(
        repo_name="repo-a",
        repo_path="C:/code/repo-a",
        branch="main",
        session_id="session-1",
        source="manual",
        title="decision",
        text="We kept SQLite and MCP as the interface boundary.",
        tags=["architecture", "memory"],
    )

    status = build_memory_status(service)
    assert status["initialized"] is True

    search_payload = search_memory_payload(service, query="SQLite", repo_names=["repo-a"], limit=5)
    assert search_payload["count"] == 1
    assert search_payload["results"][0]["repo_name"] == "repo-a"

    recall_payload = recall_project_payload(service, repo_name="repo-a", query="MCP", limit=5)
    assert recall_payload["count"] == 1
    assert recall_payload["results"][0]["event_type"] == "note"

    recursive_payload = recursive_recall_payload(service, query="SQLite", repo_names=["repo-a"], limit=5)
    assert recursive_payload["metadata"]["run_metadata"]["strategy"] == "recursive-memory-recall"


def test_mcp_stdio_server_smoke(tmp_path):
    service = default_service(tmp_path)
    service.initialize()
    service.store_note(
        repo_name="repo-a",
        repo_path="C:/code/repo-a",
        branch="main",
        session_id="session-1",
        source="manual",
        title="handoff",
        text="Discord thread resolved the auth migration blocker.",
        tags=["auth", "discord"],
    )

    async def run_client() -> None:
        server = StdioServerParameters(
            command=sys.executable,
            args=["-m", "work_memory.mcp_server", "--transport", "stdio", "--root", str(tmp_path)],
        )
        async with stdio_client(server) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                tools = await session.list_tools()
                tool_names = {tool.name for tool in tools.tools}
                assert "search_memory" in tool_names
                assert "recall_project_memory" in tool_names

                result = await session.call_tool(
                    "recall_project_memory",
                    {"repo_name": "repo-a", "query": "Discord", "limit": 5},
                )
                structured = getattr(result, "structured_content", None)
                if structured is None:
                    structured = getattr(result, "structuredContent", None)
                assert structured is not None
                assert structured["count"] == 1
                assert structured["results"][0]["repo_name"] == "repo-a"

    asyncio.run(run_client())