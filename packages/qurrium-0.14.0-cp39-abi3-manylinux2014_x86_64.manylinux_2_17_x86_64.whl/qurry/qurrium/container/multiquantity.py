"""QuantityContainer (:mod:`qurry.qurrium.container.multiquantity`)

The container for quantities of analysis for multimanager.
"""

from typing import Union, Literal, Any, TypeVar
from collections.abc import Hashable
from pathlib import Path

from ...tools import qurry_progressbar
from ...capsule.mori import TagList

TagListKeyable = TypeVar("TagListKeyable", bound=Hashable)


class QuantityContainer(dict[str, TagList[TagListKeyable, dict[str, Any]]]):
    """The container for quantities of analysis for
    :class:`~qurry.qurrium.multimanager.multimanager.MultiManager`."""

    __name__ = "QuantityContainer"

    def remove(self, name: str) -> TagList[TagListKeyable, dict[str, Any]]:
        """Removes the analysis.

        Args:
            name (str): The name of the analysis.
        """
        remain = self.pop(name)

        return remain

    def read(
        self,
        key: str,
        name: str,
        save_location: Union[str, Path],
        version: Literal["v5", "v7"] = "v7",
    ):
        """Reads the analysis.

        Args:
            key (str): The key of the analysis.
            name (Optional[str], optional): The name of the analysis. Defaults to None.
            taglist_name (str): The name of the taglist.
            save_location (Union[str, Path]): The save location of the analysis.
            version (Literal["v5", "v7"], optional): The version of the analysis. Defaults to "v7".
        """
        assert version in ["v5", "v7"], "version must be 'v5' or 'v7'"
        taglist_name = "quantity" if version == "v7" else "tagMapQuantity"

        self[key] = TagList.read(
            filename=f"{name}.{taglist_name}.json",
            taglist_name=taglist_name,
            save_location=save_location,
        )

    def write(self, save_location: Union[str, Path]) -> dict[str, str]:
        """Writes the analysis to files.

        Args:
            save_location (Union[str, Path]): The save location of the analysis.

        Returns:
            dict[str, str]: The path of the files.
        """

        quantity_output = {}
        if len(self) == 0:
            print("| No quantity to export.")
            return quantity_output

        quantity_progress = qurry_progressbar(
            self.items(), desc="exporting quantity", bar_format="qurry-barless"
        )

        for i, (k, v) in enumerate(quantity_progress):
            quantity_progress.set_description_str(f"exporting quantity: {k}")
            filename = v.export(save_location=save_location, taglist_name="quantity", name=f"{k}")
            quantity_output[k] = str(filename)

            if i == len(self) - 1:
                quantity_progress.set_description_str("exported quantity complete")

        return quantity_output

    def __repr__(self):
        return f"{self.__name__}({super().__repr__()}, num={len(self)})"

    def _repr_oneline(self):
        return f"{self.__name__}(" + "{...}" + f", num={len(self)}"

    def _repr_pretty_(self, p, cycle):
        if cycle:
            p.text(f"{self.__name__}(" + "{...}" + f", num={len(self)})")
        else:
            original_repr = super().__repr__()
            original_repr_split = original_repr[1:-1].split(", ")
            length = len(original_repr_split)
            with p.group(2, f"{self.__name__}(" + "{", "})"):
                for i, item in enumerate(original_repr_split):
                    p.breakable()
                    p.text(item)
                    if i < length - 1:
                        p.text(",")
