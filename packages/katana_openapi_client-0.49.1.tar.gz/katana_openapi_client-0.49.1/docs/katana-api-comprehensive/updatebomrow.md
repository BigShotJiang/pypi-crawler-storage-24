# Update a BOM row

**PATCH** `https://api.katanamrp.com/v1/bom_rows/{id}`

## API Specification Details

**Summary:** Update a BOM row **Description:** Updates the specified BOM row by setting
the values of the parameters passed. Any parameters not provided will be left unchanged.

### Parameters

- **id** (path) *required*: BOM row ID

### Request Schema

```json
{
  "type": "object",
  "additionalProperties": false,
  "properties": {
    "ingredient_variant_id": {
      "type": "integer",
      "description": "Ingredient variant ID",
      "maximum": 2147483647
    },
    "quantity": {
      "type": "number",
      "minimum": 0,
      "maximum": 100000000000000000,
      "description": "Ingredient quantity",
      "nullable": true
    },
    "notes": {
      "type": "string",
      "description": "Notes about BOM row",
      "nullable": true,
      "maxLength": 255
    }
  }
}
```

### Response Examples

#### 200 Response

BOM row updated

```json
{
  "id": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
  "product_item_id": 1,
  "product_variant_id": 1,
  "ingredient_variant_id": 1,
  "quantity": 1,
  "notes": "Important BOM row",
  "rank": 10000,
  "created_at": "2021-06-22T10:00:00.000Z",
  "updated_at": "2021-06-22T10:00:00.000Z"
}
```

#### 401 Response

Make sure you've entered your API token correctly.

```json
{
  "statusCode": 401,
  "name": "UnauthorizedError",
  "message": "Unauthorized"
}
```

#### 422 Response

Check the details property for a specific error message.

```json
{
  "statusCode": 422,
  "name": "UnprocessableEntityError",
  "message": "The request body is invalid.
  See error object `details` property for more info.",
  "code": "VALIDATION_FAILED",
  "details": [
    {
      "path": ".name",
      "code": "maxLength",
      "message": "should NOT be longer than 10 characters",
      "info": {
        "limit": 10
      }
    }
  ]
}
```

#### 429 Response

The rate limit has been reached. Please try again later.

```json
{
  "statusCode": 429,
  "name": "TooManyRequests",
  "message": "Too Many Requests"
}
```

#### 500 Response

The server encountered an error. If this persists, please contact support

```json
{
  "statusCode": 500,
  "name": "InternalServerError",
  "message": "Internal Server Error"
}
```
