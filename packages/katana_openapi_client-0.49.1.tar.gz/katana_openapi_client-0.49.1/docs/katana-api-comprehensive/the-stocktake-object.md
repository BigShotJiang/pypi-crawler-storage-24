# The stocktake object
