# The material object
