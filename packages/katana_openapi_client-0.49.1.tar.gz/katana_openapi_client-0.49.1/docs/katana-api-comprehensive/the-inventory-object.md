# The inventory object
