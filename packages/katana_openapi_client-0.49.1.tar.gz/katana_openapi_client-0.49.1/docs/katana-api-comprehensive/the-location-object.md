# The location object
