"""
NeverMissRoad Python SDK
=========================
Official Python client for the NeverMissRoad Address Intelligence & Tracking API.

Installation:
    pip install nevermissroad

Quick Start:
    from nevermissroad import NeverMissRoad

    nmr = NeverMissRoad("nmr_your_api_key")

    # Autocomplete
    results = nmr.autocomplete("Allen Avenue")

    # Geocode
    location = nmr.geocode("15 Broad Street, Lagos Island")

    # Batch geocode 1000 addresses
    results = nmr.batch_geocode(["Allen Avenue Ikeja", "Obalende Lagos"])

    # Reverse geocode
    address = nmr.reverse(6.45, 3.40)

    # Real-time tracking
    nmr.broadcast("rider_001", lat=6.52, lng=3.38, speed=25)
    nearby = nmr.nearby(lat=6.52, lng=3.38, radius=3000)
    eta = nmr.eta(origin=(6.45, 3.40), destination=(6.60, 3.34))

    # Trip management
    trip = nmr.trip_start("rider_001", pickup="Broad Street Lagos", dropoff="Allen Avenue Ikeja")
    nmr.trip_update(trip["trip_id"], lat=6.50, lng=3.37)
    result = nmr.trip_complete(trip["trip_id"])

License: MIT
"""

__version__ = "1.0.0"
__author__ = "NeverMissRoad by Kwik"

import json
import urllib.request
import urllib.parse
import urllib.error


class NeverMissRoadError(Exception):
    """Base exception for NeverMissRoad SDK."""
    def __init__(self, message, status_code=None, response=None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class AuthenticationError(NeverMissRoadError):
    pass


class RateLimitError(NeverMissRoadError):
    pass


class NotFoundError(NeverMissRoadError):
    pass


class NeverMissRoad:
    """
    NeverMissRoad API Client.

    Args:
        api_key (str): Your NeverMissRoad API key (starts with 'nmr_')
        base_url (str): API base URL (default: https://nevermissroad.com/api/v1)
        timeout (int): Request timeout in seconds (default: 30)
    """

    def __init__(self, api_key, base_url="https://nevermissroad.com/api/v1", timeout=30):
        if not api_key:
            raise AuthenticationError("API key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _request(self, method, path, params=None, body=None):
        """Make an HTTP request to the API."""
        url = f"{self.base_url}{path}"

        if params:
            url += "?" + urllib.parse.urlencode(params)

        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": f"nevermissroad-python/{__version__}",
            "Origin": "https://nevermissroad.com",
        }

        data = None
        if body:
            data = json.dumps(body).encode("utf-8")

        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                response_data = json.loads(resp.read().decode("utf-8"))

                if response_data.get("status") == "error":
                    raise NeverMissRoadError(
                        response_data.get("error", "Unknown error"),
                        status_code=resp.status,
                        response=response_data,
                    )

                return response_data.get("data", response_data)

        except urllib.error.HTTPError as e:
            body_text = e.read().decode("utf-8") if e.fp else ""
            try:
                error_data = json.loads(body_text)
                msg = error_data.get("error", str(e))
            except Exception:
                msg = body_text or str(e)

            if e.code == 401:
                raise AuthenticationError(msg, status_code=401)
            elif e.code == 429:
                raise RateLimitError(msg, status_code=429)
            elif e.code == 404:
                raise NotFoundError(msg, status_code=404)
            else:
                raise NeverMissRoadError(msg, status_code=e.code)

        except urllib.error.URLError as e:
            raise NeverMissRoadError(f"Connection error: {e.reason}")

    def _get(self, path, params=None):
        return self._request("GET", path, params=params)

    def _post(self, path, body=None):
        return self._request("POST", path, body=body)

    def _put(self, path, body=None):
        return self._request("PUT", path, body=body)

    # ══════════════════════════════════════════════════
    # ADDRESS INTELLIGENCE
    # ══════════════════════════════════════════════════

    def autocomplete(self, query, limit=5, country=None, type=None, lat=None, lng=None):
        """
        Address autocomplete with instant suggestions.

        Args:
            query (str): Search text (min 2 chars)
            limit (int): Max results (1-20, default 5)
            country (int): Filter by country_id
            type (str): Filter by address_type
            lat (float): Bias results near this latitude
            lng (float): Bias results near this longitude

        Returns:
            dict: {"query", "suggestions": [...], "count"}

        Example:
            results = nmr.autocomplete("Allen Avenue", limit=5)
            for s in results["suggestions"]:
                print(f"{s['text']} → {s['lat']}, {s['lng']}")
        """
        params = {"q": query, "limit": limit}
        if country:
            params["country"] = country
        if type:
            params["type"] = type
        if lat is not None:
            params["lat"] = lat
        if lng is not None:
            params["lng"] = lng
        return self._get("/autocomplete", params)

    def geocode(self, address, country=None):
        """
        Forward geocode a single address.

        Args:
            address (str): Address to geocode
            country (str): Country filter (ISO code, e.g. "NG")

        Returns:
            dict: First match with lat, lng, confidence

        Example:
            result = nmr.geocode("15 Broad Street, Lagos Island")
            print(f"Location: {result['lat']}, {result['lng']}")
        """
        body = {"addresses": [address]}
        if country:
            body["country"] = country
        result = self._post("/batch/geocode", body)
        if result.get("results") and result["results"][0].get("status") == "resolved":
            return result["results"][0]
        raise NotFoundError(f"Could not geocode: {address}")

    def batch_geocode(self, addresses, country=None):
        """
        Batch geocode up to 1000 addresses.

        Args:
            addresses (list): List of address strings
            country (str): Country filter (ISO code)

        Returns:
            dict: {"results": [...], "resolved", "failed", "resolution_rate"}

        Example:
            results = nmr.batch_geocode([
                "Allen Avenue Ikeja",
                "Broad Street Lagos",
                "Obalende Lagos"
            ])
            for r in results["results"]:
                if r["status"] == "resolved":
                    print(f"{r['input']} → {r['lat']}, {r['lng']} ({r['confidence']})")
        """
        body = {"addresses": addresses}
        if country:
            body["country"] = country
        return self._post("/batch/geocode", body)

    def reverse(self, lat, lng, radius=500):
        """
        Reverse geocode coordinates to address.

        Args:
            lat (float): Latitude
            lng (float): Longitude
            radius (int): Search radius in meters (default 500)

        Returns:
            list: Nearest addresses sorted by distance
        """
        return self._get("/reverse-geocode", {"lat": lat, "lng": lng, "radius": radius})

    def batch_reverse(self, coordinates, radius=500):
        """
        Batch reverse geocode up to 1000 coordinate pairs.

        Args:
            coordinates (list): List of {"lat", "lng"} dicts
            radius (int): Search radius in meters

        Returns:
            dict: {"results": [...], "resolved", "failed", "resolution_rate"}
        """
        return self._post("/batch/reverse", {"coordinates": coordinates, "radius": radius})

    def validate(self, address, lat=None, lng=None):
        """
        Validate an address against the database.

        Args:
            address (str): Address to validate
            lat (float): Known latitude (boosts confidence)
            lng (float): Known longitude

        Returns:
            dict: {"valid", "confidence", "matched_address", ...}
        """
        params = {"q": address}
        if lat is not None:
            params["lat"] = lat
        if lng is not None:
            params["lng"] = lng
        return self._get("/address/validate", params)

    def search(self, query, limit=10):
        """
        Search addresses.

        Args:
            query (str): Search query
            limit (int): Max results

        Returns:
            list: Matching addresses
        """
        return self._get("/addresses", {"search": query, "limit": limit})

    # ══════════════════════════════════════════════════
    # REAL-TIME TRACKING
    # ══════════════════════════════════════════════════

    def broadcast(self, entity_id, lat, lng, heading=None, speed=None,
                  entity_type="motorcycle", status="available", trip_id=None, metadata=None):
        """
        Broadcast current GPS position.

        Args:
            entity_id (str): Unique rider/vehicle ID
            lat (float): Latitude
            lng (float): Longitude
            heading (float): Direction in degrees
            speed (float): Speed in km/h
            entity_type (str): rider|motorcycle|car|truck|bicycle
            status (str): available|busy|offline
            trip_id (str): Active trip ID
            metadata (dict): Custom data

        Returns:
            dict: Position confirmation with reverse-geocoded street context
        """
        body = {
            "entity_id": entity_id,
            "lat": lat, "lng": lng,
            "entity_type": entity_type,
            "status": status,
        }
        if heading is not None:
            body["heading"] = heading
        if speed is not None:
            body["speed"] = speed
        if trip_id:
            body["trip_id"] = trip_id
        if metadata:
            body["metadata"] = metadata
        return self._post("/tracking/broadcast", body)

    def position(self, entity_id):
        """
        Get live position of an entity.

        Args:
            entity_id (str): Entity ID

        Returns:
            dict: Current position with street context
        """
        return self._get(f"/tracking/position/{entity_id}")

    def nearby(self, lat, lng, radius=2000, entity_type=None, status="available", limit=20):
        """
        Find nearby active entities.

        Args:
            lat (float): Search center latitude
            lng (float): Search center longitude
            radius (float): Radius in meters (default 2000)
            entity_type (str): Filter by type
            status (str): Filter by status
            limit (int): Max results

        Returns:
            dict: {"center", "entities": [...], "count"}
        """
        params = {"lat": lat, "lng": lng, "radius": radius, "limit": limit}
        if entity_type:
            params["type"] = entity_type
        if status:
            params["status"] = status
        return self._get("/tracking/nearby", params)

    def locate(self, address=None, lat=None, lng=None, radius=3000,
               entity_type=None, limit=10):
        """
        Combined: geocode address + find nearby riders.

        Args:
            address (str): Address to geocode (or use lat/lng)
            lat (float): Latitude
            lng (float): Longitude
            radius (float): Search radius in meters
            entity_type (str): Filter entity type
            limit (int): Max nearby results

        Returns:
            dict: {"resolved_location", "nearby_riders", "closest_eta"}
        """
        body = {"radius": radius, "limit": limit}
        if address:
            body["address"] = address
        if lat is not None:
            body["lat"] = lat
        if lng is not None:
            body["lng"] = lng
        if entity_type:
            body["entity_type"] = entity_type
        return self._post("/tracking/locate", body)

    def eta(self, origin, destination, mode="motorcycle"):
        """
        Calculate ETA between two points.

        Args:
            origin: (lat, lng) tuple or {"lat", "lng"} dict or address string
            destination: (lat, lng) tuple or {"lat", "lng"} dict or address string
            mode (str): driving|motorcycle|bicycle|walking

        Returns:
            dict: {"estimated_duration_seconds", "osrm", ...}
        """
        def _resolve(loc):
            if isinstance(loc, tuple):
                return {"lat": loc[0], "lng": loc[1]}
            elif isinstance(loc, str):
                return {"address": loc}
            return loc

        return self._post("/tracking/eta", {
            "origin": _resolve(origin),
            "destination": _resolve(destination),
            "mode": mode,
        })

    def route(self, waypoints, mode="driving"):
        """
        Get route with turn-by-turn directions.

        Args:
            waypoints: List of (lat, lng) tuples, {"lat", "lng"} dicts, or address strings
            mode (str): driving|motorcycle|bicycle|walking

        Returns:
            dict: {"distance_m", "duration_seconds", "geometry", "legs"}
        """
        wps = []
        for wp in waypoints:
            if isinstance(wp, tuple):
                wps.append({"lat": wp[0], "lng": wp[1]})
            elif isinstance(wp, str):
                wps.append({"address": wp})
            else:
                wps.append(wp)
        return self._post("/tracking/route", {"waypoints": wps, "mode": mode})

    # ══════════════════════════════════════════════════
    # TRIP MANAGEMENT
    # ══════════════════════════════════════════════════

    def trip_start(self, rider_id, pickup, dropoff, customer_id=None, mode="motorcycle"):
        """
        Start a new trip.

        Args:
            rider_id (str): Rider ID
            pickup: Address string, (lat, lng) tuple, or {"lat", "lng"} dict
            dropoff: Address string, (lat, lng) tuple, or {"lat", "lng"} dict
            customer_id (str): Customer ID
            mode (str): Transport mode

        Returns:
            dict: {"trip_id", "pickup", "dropoff", "route"}
        """
        def _resolve(loc):
            if isinstance(loc, str):
                return {"address": loc}
            elif isinstance(loc, tuple):
                return {"lat": loc[0], "lng": loc[1]}
            return loc

        body = {
            "rider_id": rider_id,
            "pickup": _resolve(pickup),
            "dropoff": _resolve(dropoff),
            "mode": mode,
        }
        if customer_id:
            body["customer_id"] = customer_id
        return self._post("/tracking/trip/start", body)

    def trip_update(self, trip_id, lat, lng, speed=None, heading=None):
        """Update trip with current position."""
        body = {"lat": lat, "lng": lng}
        if speed is not None:
            body["speed"] = speed
        if heading is not None:
            body["heading"] = heading
        return self._put(f"/tracking/trip/{trip_id}/update", body)

    def trip_complete(self, trip_id):
        """Complete a trip."""
        return self._put(f"/tracking/trip/{trip_id}/complete")

    def trip_get(self, trip_id):
        """Get trip details."""
        return self._get(f"/tracking/trip/{trip_id}")

    # ══════════════════════════════════════════════════
    # GEOFENCING
    # ══════════════════════════════════════════════════

    def geofence_check(self, lat, lng, fence_lat, fence_lng, fence_radius=500):
        """Check if point is inside a geofence."""
        return self._get("/tracking/geofence/check", {
            "lat": lat, "lng": lng,
            "fence_lat": fence_lat, "fence_lng": fence_lng,
            "fence_radius": fence_radius,
        })

    # ══════════════════════════════════════════════════
    # BILLING & ACCOUNT
    # ══════════════════════════════════════════════════

    def usage(self):
        """Get current usage and billing summary."""
        return self._get("/billing/usage")

    def account(self):
        """Get account details."""
        return self._get("/billing/account")

    def tracking_status(self):
        """Get tracking system status (no auth required)."""
        return self._get("/tracking/status")

    # ══════════════════════════════════════════════════
    # STATS (PUBLIC)
    # ══════════════════════════════════════════════════

    def stats(self):
        """Get platform statistics (no auth required)."""
        return self._get("/stats")
