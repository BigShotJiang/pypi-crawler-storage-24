"""vault-mcp — Markdown + SQLite knowledge store with bidirectional wikilinks."""

from vault_mcp.store import MarkdownVault
from vault_mcp.tools import create_vault_tools

__all__ = ["MarkdownVault", "create_vault_tools"]
