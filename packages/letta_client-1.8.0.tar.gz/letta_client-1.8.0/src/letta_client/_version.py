# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "letta_client"
__version__ = "1.8.0"  # x-release-please-version
