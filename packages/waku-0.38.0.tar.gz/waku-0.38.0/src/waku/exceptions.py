class WakuError(Exception):
    pass
