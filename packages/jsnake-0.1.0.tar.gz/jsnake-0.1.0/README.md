# 🐍 CLI Snake (Enterprise Grade)

A professional, high-performance terminal UI representation of the classic Snake game, built using the modern Python ecosystem.

## 🏗 Industrial Stack Choice

To build a professional tool in Python, we've moved beyond simple logic and embraced a modern, robust architecture:

1.  **[Textual](https://textual.textualize.io/)**: The industry standard for high-performance terminal interfaces (TUIs). It uses asyncio for smooth, non-blocking input and rendering.
2.  **[Rich](https://rich.readthedocs.io/)**: Provides the aesthetics (colors, gradients, layouts) that make modern CLI tools feel premium.
3.  **Modular Architecture**: Separated the game engine (state management) from the UI (rendering), making it easily testable and maintainable.
4.  **Static Type Hinting (`Mypy`)**: In professional projects, we use strict type-hinting to prevent bugs before the code even runs.
5.  **Modern Build System (`pyproject.toml`)**: Standardized packaging and dependency management.

## 🛸 Professional Deployment

### Local Terminal Installation
To play the game from any location in your terminal without manual `venv` activation:
```bash
# From the project root
pip install .
```
Now, simply run `snake`.

## 🛸 Industrial CI/CD
The project is configured for automated quality control via **GitHub Actions**. On every commit, the following are verified:
- **Ruff**: Linting & Style enforcement.
- **Mypy**: Strict static type checking.
- **Pytest**: Core engine logic validation.

See [Deployment Guide](C:/Users/Jithi/.gemini/antigravity/brain/c0356a23-e4fd-4c02-b9b2-727abf982d78/deployment_guide.md) for the `.github/workflows/ci.yml` configuration.
