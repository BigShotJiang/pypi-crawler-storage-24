import sys

from .tui import SnakeApp


def main() -> int:
    """The main entry point for the CLI snake game."""
    try:
        app = SnakeApp()
        app.run()
        return 0
    except KeyboardInterrupt:
        return 0
    except Exception as e:
        print(f"Error running CLI Snake: {e}", file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main())
