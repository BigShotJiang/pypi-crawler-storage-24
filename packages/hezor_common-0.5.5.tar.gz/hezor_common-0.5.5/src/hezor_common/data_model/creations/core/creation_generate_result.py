"""Creation generation result model."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from hezor_common.data_model.creations.core.chapter_generate_result import (
    ChapterGenerateResult,
)
from hezor_common.data_model.creations.core.creation_model import (
    Author,
    Contributor,
    CreationMeta,
    CreationModel,
    CreationSummary,
)
from hezor_common.data_model.creations.core.creation_params import CreationParams


class CreationGenerateResult(BaseModel):
    """Creation generation result.

    Attributes
    ----------
    original_query : str
        原始查询字符串
    creation : CreationModel
        解析的 creation 模型对象
    params : CreationParams
        生成参数（subject, period, data_coverage）
    chapter_results : list[ChapterGenerateResult]
        所有子 chapter 的生成结果列表
    summary : str
        生成的作品摘要内容
    title : str
        完整标题，格式：{subject} {creation.meta.name} {period}
    data_coverage : str
        数据周期文本
    full_content : str
        完整的 creation 内容（不含 prefix 和 postfix）
    creation_id : str
        生成的唯一 ID（使用 snowflake）其实是 report_id
    prefix : str
        MDX 文件前置内容（frontmatter）
    postfix : str
        MDX 文件后置内容（报告生成信息）
    file_path : str
        保存的文件路径

    Examples
    --------
    >>> result = CreationGenerateResult(
    ...     creation=creation_obj,
    ...     params=params_obj,
    ...     chapter_results=[chapter_result1, chapter_result2],
    ...     summary="本报告深入分析了...",
    ...     title="鮨大山 单店盈利模型 2025 年 12 月",
    ...     data_coverage="202512-202512",
    ...     full_content="# 鮨大山 单店盈利模型 2025 年 12 月\n\n...",
    ...     creation_id="abc123",
    ...     prefix="---\ntitle: ...\n---\n",
    ...     postfix="\n[报告生成日期：2026-01-05]\n",
    ...     file_path="website/src/content/reports/abc123.mdx"
    ... )
    """

    original_query: str = Field(..., description="原始查询字符串")
    model_config = ConfigDict(frozen=False, extra="forbid")

    creation: CreationModel = Field(..., description="解析的 creation 模型对象")
    params: CreationParams = Field(..., description="生成参数")
    chapter_results: list[ChapterGenerateResult] = Field(
        ..., description="所有子 chapter 的生成结果列表"
    )
    summary: str = Field(..., description="生成的作品摘要内容")
    title: str = Field(..., description="完整标题，格式：{subject} {creation.meta.name} {period}")
    data_coverage: str = Field(..., description="数据周期文本")
    full_content: str = Field(..., description="完整的 creation 内容（不含 prefix 和 postfix）")
    creation_id: str = Field(..., description="生成的唯一 ID")
    prefix: str = Field(..., description="MDX 文件前置内容（frontmatter）")
    postfix: str = Field(..., description="MDX 文件后置内容")
    file_path: str = Field(..., description="保存的文件路径")


class CreationGenerateResultV2(BaseModel):
    """Creation 生成结果（简化版）。

    将 ``CreationGenerateResult`` 中嵌套的字段扁平化，
    仅保留 ``publish_creation_report`` 处理路径上实际
    使用的字段，大幅减少 HTTP 传输体积和结构复杂度。

    Attributes
    ----------
    creation_id : str
        报告唯一 ID（即 report_id）
    title : str
        完整标题，格式：{subject} {creation_name} {period}
    full_content : str
        完整 Markdown 内容（不含 prefix/postfix）
    summary : str
        报告摘要，默认 ``""``
    subject : str
        报告主体，如 ``"鮨大山"``
    period : str
        报告周期，如 ``"2025 年 12 月"``，默认 ``""``
    data_coverage : str
        数据周期，格式 yyyyMMdd-yyyyMMdd 或 yyyyMM-yyyyMM，
        默认 ``""``
    subject_code : str or None
        主体编码，如 ``"yidashan"``。为 None 时自动
        使用 subject 的 MD5 值。
    creation_name : str
        Creation 模型名称，如 ``"单店盈利模型"``，默认
        ``""``
    creation_description : str
        Creation 模型描述
    author_name : str
        作者名称
    contributors : list[str]
        贡献者名称列表
    domain : str or None
        所属领域，如 ``"food_beverage"``
    path : str or None
        创建路径，如 ``"food_beverage/single_store_profit_model"``
    slug : str
        创建标识名，如 ``"single_store_profit_model"``（必填）
    chapter_count : int
        章节数量
    original_query : str
        原始查询字符串
    file_path : str
        保存的文件路径
    prefix : str
        MDX 前置内容（frontmatter）
    postfix : str
        MDX 后置内容（报告生成信息）
    creation_model_json : str or None
        完整 CreationModel 的 JSON 序列化，用于需要完整
        模型结构的场景（如知识库元数据存储）。如未提供，
        将在转换时自动构建最小化的 CreationModel。

    Examples
    --------
    >>> result = CreationGenerateResultV2(
    ...     creation_id="rpt_TyDyhKtse3o",
    ...     title="鮨大山 单店盈利模型 2025 年 12 月",
    ...     full_content="# 鮨大山 单店盈利模型 2025 年 12 月\\n\\n"
    ...         "## 营收分析\\n\\n本月营收整体表现良好...",
    ...     summary="本报告对鮨大山的经营状况进行了深入分析...",
    ...     subject="鮨大山",
    ...     period="2025 年 12 月",
    ...     data_coverage="202512-202512",
    ...     subject_code="yidashan",
    ...     slug="single_store_profit_model",
    ...     creation_name="单店盈利模型",
    ...     creation_description="单店盈利分析模型",
    ...     author_name="Hezor AI",
    ...     contributors=["张三", "李四"],
    ...     domain="food_beverage",
    ...     path="food_beverage/single_store_profit_model",
    ...     chapter_count=3,
    ...     original_query="生成鮨大山2025年12月单店盈利模型报告",
    ...     file_path="reports/rpt_TyDyhKtse3o.mdx",
    ...     prefix="---\\ntitle: 鮨大山 单店盈利模型\\n---\\n",
    ...     postfix="\\n---\\n报告生成日期：2025-12-31\\n",
    ... )
    >>> generate_result = result.to_generate_result()
    >>> generate_result.creation_id
    'rpt_TyDyhKtse3o'
    """

    model_config = ConfigDict(frozen=False, extra="forbid")

    # --- 核心标识 ---
    creation_id: str = Field(..., description="报告唯一 ID（即 report_id）")
    title: str = Field(
        ...,
        description="完整标题，格式：{subject} {creation_name} {period}",
    )

    # --- 内容 ---
    full_content: str = Field(
        ...,
        description="完整 Markdown 内容（不含 prefix/postfix）",
    )
    summary: str = Field(default="", description="报告摘要")

    # --- 主体和周期（扁平化自 CreationParams）---
    subject: str = Field(..., description="报告主体，如 '鮨大山'")
    period: str = Field(default="", description="报告周期，如 '2025 年 12 月'")
    data_coverage: str = Field(
        default="",
        description="数据周期，格式 yyyyMMdd-yyyyMMdd 或 yyyyMM-yyyyMM",
    )
    subject_code: str | None = Field(
        default=None,
        description="主体编码，为 None 时自动使用 subject 的 MD5 值",
    )

    # --- Creation 模型元信息（扁平化自 CreationModel.meta）---
    creation_name: str = Field(
        default="",
        description="Creation 模型名称，如 '单店盈利模型'",
    )
    creation_description: str = Field(
        default="",
        description="Creation 模型描述",
    )
    author_name: str = Field(
        default="",
        description="作者名称",
    )
    contributors: list[str] = Field(
        default_factory=list,
        description="贡献者名称列表",
    )
    domain: str | None = Field(
        default=None,
        description="所属领域，如 'food_beverage'",
    )
    path: str | None = Field(
        default=None,
        description="创建路径，如 'food_beverage/single_store_profit_model'",
    )
    slug: str = Field(
        ...,
        description="创建标识名，如 'single_store_profit_model'",
    )

    # --- 统计 ---
    chapter_count: int = Field(
        default=0,
        ge=0,
        description="章节数量",
    )

    # --- 可选元数据（用于完整性存储）---
    original_query: str = Field(
        default="",
        description="原始查询字符串",
    )
    file_path: str = Field(
        default="",
        description="保存的文件路径",
    )
    prefix: str = Field(
        default="",
        description="MDX 前置内容（frontmatter）",
    )
    postfix: str = Field(
        default="",
        description="MDX 后置内容（报告生成信息）",
    )
    creation_model_json: str | None = Field(
        default=None,
        description=(
            "完整 CreationModel 的 JSON 序列化。如未提供，转换时自动构建最小化 CreationModel。"
        ),
    )

    def to_generate_result(self) -> CreationGenerateResult:
        """转换为完整的 ``CreationGenerateResult``。

        从扁平化字段重建嵌套的 ``CreationModel``、``CreationParams``
        等结构，以复用现有 Pipeline 处理逻辑。

        Returns
        -------
        CreationGenerateResult
            完整的生成结果，可直接传入 Pipeline。

        Notes
        -----
        如果提供了 ``creation_model_json``，将优先使用它来
        恢复完整的 ``CreationModel``；否则根据扁平化字段
        构建最小可用的 ``CreationModel``。

        ``chapter_results`` 会设置为空列表，因为简化版
        不携带章节详情。Pipeline 中通过 ``len(chapter_results)``
        获取章节数的场景会退化为 0，但 ``chapter_count`` 已通过
        S3 metadata 等路径传递。
        """
        # 1. 恢复 CreationModel
        if self.creation_model_json:
            creation = CreationModel.model_validate_json(self.creation_model_json)
        else:
            creation = CreationModel(
                meta=CreationMeta(
                    name=self.creation_name,
                    description=self.creation_description,
                    author=Author(name=self.author_name),
                    contributors=[Contributor(name=name) for name in self.contributors],
                    path=self.path,
                    domain=self.domain,
                    slug=self.slug,
                ),
                summary=CreationSummary(content=self.summary),
                chapters=[],
            )

        # 2. 恢复 CreationParams
        params = CreationParams(
            subject=self.subject,
            period=self.period,
            data_coverage=self.data_coverage,
            subject_code=self.subject_code,
        )

        # 3. 构建 CreationGenerateResult
        return CreationGenerateResult(
            original_query=self.original_query,
            creation=creation,
            params=params,
            chapter_results=[],
            summary=self.summary,
            title=self.title,
            data_coverage=self.data_coverage,
            full_content=self.full_content,
            creation_id=self.creation_id,
            prefix=self.prefix,
            postfix=self.postfix,
            file_path=self.file_path,
        )

    @classmethod
    def from_generate_result(
        cls,
        result: CreationGenerateResult,
    ) -> CreationGenerateResultV2:
        """从 ``CreationGenerateResult`` 创建简化版结果。

        Parameters
        ----------
        result : CreationGenerateResult
            完整的生成结果。

        Returns
        -------
        CreationGenerateResultV2
            简化版结果。

        Examples
        --------
        >>> from hezor_common.data_model.creations import (
        ...     CreationGenerateResult,
        ... )
        >>> full_result = CreationGenerateResult(...)
        >>> simplified = CreationGenerateResultV2.from_generate_result(
        ...     full_result
        ... )
        """
        creation_meta = result.creation.meta if result.creation else None

        return cls(
            creation_id=result.creation_id,
            title=result.title,
            full_content=result.full_content,
            summary=result.summary,
            subject=result.params.subject,
            period=result.params.period,
            data_coverage=result.params.data_coverage,
            subject_code=result.params.subject_code,
            creation_name=creation_meta.name if creation_meta else "",
            creation_description=(creation_meta.description if creation_meta else ""),
            author_name=(
                creation_meta.author.name if creation_meta and creation_meta.author else ""
            ),
            contributors=([c.name for c in creation_meta.contributors] if creation_meta else []),
            domain=creation_meta.domain if creation_meta else None,
            path=creation_meta.path if creation_meta else None,
            slug=creation_meta.slug or "" if creation_meta else "",
            chapter_count=len(result.chapter_results),
            original_query=result.original_query,
            file_path=result.file_path,
            prefix=result.prefix,
            postfix=result.postfix,
            creation_model_json=(result.creation.model_dump_json() if result.creation else None),
        )
