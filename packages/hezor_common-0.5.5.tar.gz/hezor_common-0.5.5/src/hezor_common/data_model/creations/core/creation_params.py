"""Creation generation parameters model."""

import hashlib

from pydantic import BaseModel, Field, model_validator


class CreationParams(BaseModel):
    """Creation generation parameters extracted from query.

    Attributes
    ----------
    subject : str
        主体，如"鮨大山"、"XX品牌"
    period : str
        报告周期，如"2025 年 3 月"、"2025 年第3期"
    data_coverage : str
        使用数据周期，格式 yyyyMMdd-yyyyMMdd 或 yyyyMM-yyyyMM
        例如：20251201-20251231 或 202512-202512
    subject_code : str | None
        报告主体编码，如"yidashan"、"wd0000001"
        如果未提供，将自动使用 subject 的 MD5 值

    Examples
    --------
    >>> params = CreationParams(
    ...     subject="鮨大山",
    ...     period="2025 年 12 月",
    ...     data_coverage="202512-202512",
    ...     subject_code="yidashan",
    ... )
    >>> # subject_code can be omitted, will auto-generate from subject
    >>> params_auto = CreationParams(
    ...     subject="鮨大山",
    ...     period="2025 年 12 月",
    ...     data_coverage="202512-202512",
    ... )
    >>> params_auto.subject_code  # MD5 hash of "鮨大山"
    """

    subject: str = Field(..., description="主体，如'鮨大山'")
    period: str = Field(..., description="报告周期，如'2025 年 12 月'")
    data_coverage: str = Field(
        ..., description="使用数据周期，格式 yyyyMMdd-yyyyMMdd 或 yyyyMM-yyyyMM"
    )
    subject_code: str | None = Field(
        default=None,
        description="报告主体编码，支持单主体（如 'yidashan'）或多级主体（主体/子主体格式，如 'yidashan/market_dept'）。若未提供，自动使用 subject 的 MD5 值",
    )

    @model_validator(mode="after")
    def set_subject_code_default(self) -> "CreationParams":
        """Set subject_code to MD5 of subject if not provided."""
        if self.subject_code is None:
            self.subject_code = hashlib.md5(self.subject.encode("utf-8")).hexdigest()
        return self
