"""Webhook 通用模型。

提供通用泛型信封模型 ``WebhookRequest[PayloadT]`` 和
``WebhookResponse[DataT]``，适用于所有 Webhook 功能。
"""

from hezor_common.data_model.webhook.action_help import (
    WebhookActionHelp,
    WebhookActionUsage,
)
from hezor_common.data_model.webhook.envelope import (
    DataT,
    PayloadT,
    WebhookRequest,
    WebhookResponse,
)

__all__ = [
    "DataT",
    "PayloadT",
    "WebhookActionHelp",
    "WebhookActionUsage",
    "WebhookRequest",
    "WebhookResponse",
]
