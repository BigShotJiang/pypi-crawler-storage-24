"""Hezor2 SDK 环境配置加载模块。

提供基于 Pydantic 的环境变量自动加载功能。
"""

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Hezor2EnvConfig(BaseSettings):
    """Hezor2 SDK 环境配置。

    自动从 .env 文件加载环境变量。

    Attributes
    ----------
    hezor2_api_base_url : str
        Hezor2 API 基础 URL
    hezor2_api_key : str
        Hezor2 API Key
    hezor2_header_pk_filepath : str
        请求头私钥文件路径
    hezor2_header_pk_password : str
        请求头私钥密码
    hezor2_app_name : str
        应用名称，通过 X-APP-NAME 头传递给服务端
    """

    model_config = SettingsConfigDict(
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    hezor2_api_base_url: str = Field(
        default="http://localhost:8000",
        description="Hezor2 API 基础 URL",
    )

    hezor2_api_key: str = Field(
        default="test-api-key",
        description="Hezor2 API Key",
    )

    hezor2_header_pk_filepath: str = Field(
        default="",
        description="请求头私钥文件路径",
    )

    hezor2_header_pk_password: str = Field(
        default="",
        description="请求头私钥密码",
    )

    hezor2_app_name: str = Field(
        default="",
        description="应用名称，通过 X-APP-NAME 头传递给服务端",
    )


def load_env(env_file: str | Path | None = None) -> Hezor2EnvConfig:
    """加载环境配置。

    从环境变量中读取 Hezor2 SDK 配置。作为第三方库，本函数只读取环境变量，
    不会修改全局环境变量。用户应该在自己的应用层设置环境变量。

    Parameters
    ----------
    env_file : str | Path | None, optional
        .env 文件路径，默认为 None（仅从环境变量读取）
        注意：env_file 参数主要用于示例代码和测试场景

    Returns
    -------
    Hezor2EnvConfig
        从环境变量读取的配置实例

    Examples
    --------
    >>> # 从环境变量读取配置
    >>> from hezor_common.transfer.hezor2_sdk.env_config import load_env
    >>> config = load_env()
    >>> print(config.hezor2_api_base_url)
    'http://localhost:8000'

    >>> # 在示例代码中从 .env 文件读取
    >>> config = load_env(".env")
    >>> print(config.hezor2_api_key)
    """
    # 如果指定了 env_file，动态创建配置类
    if env_file:
        from pydantic_settings import SettingsConfigDict

        config_dict = SettingsConfigDict(
            env_file=env_file,
            env_file_encoding="utf-8",
            case_sensitive=False,
            extra="ignore",
        )

        class _Hezor2EnvConfigWithFile(Hezor2EnvConfig):
            model_config = config_dict

        return _Hezor2EnvConfigWithFile()

    return Hezor2EnvConfig()


__all__ = ["Hezor2EnvConfig", "load_env"]
