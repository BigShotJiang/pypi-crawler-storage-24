"""Hezor2 SDK - 统一的 SDK 接口。

提供便捷的上下文管理器接口，集成所有 Hezor2 API 功能。
"""

import logging
from pathlib import Path

import httpx

from hezor_common.data_model.creations.core import (
    CreationGenerateResult,
    CreationGenerateResultV2,
)
from hezor_common.data_model.creations.execution.webhook import (
    PublishCreationResponseData,
    ReportMetadata,
)
from hezor_common.data_model.searching import DataRetrieveResult, KnowledgeSearchResult
from hezor_common.data_model.webhook import WebhookActionHelp
from hezor_common.transfer.base_sdk import MetaInfo
from hezor_common.transfer.hezor2_sdk.base.constants import (
    DEFAULT_API_BASE_URL,
    DEFAULT_API_KEY,
)
from hezor_common.transfer.hezor2_sdk.base.hezor2_api_client import (
    Hezor2APIClient,
)

logger = logging.getLogger(__name__)


class Hezor2SDK:
    """Hezor2 SDK 统一接口。

    提供便捷的上下文管理器接口，集成创建报告发布等功能。

    Parameters
    ----------
    base_url : str
        API 基础 URL，默认使用 DEFAULT_API_BASE_URL
    timeout : float
        请求超时时间（秒）
    api_key : str | None
        API 密钥，用于认证
    meta_info : MetaInfo | None
        元信息对象，用于签名认证
    private_key_path : str | Path | None
        私钥文件路径，用于签名认证（与 meta_info 配合使用）
    password : bytes | None
        私钥密码
    meta_info_expires_in : int
        MetaInfo JWT token 过期时间（秒）

    Examples
    --------
    >>> # 基本使用
    >>> async with Hezor2SDK() as sdk:
    ...     result = await sdk.publish_creation_report(
    ...         creation_result=creation_result,
    ...         task_id="monthly_report",
    ...         execution_id="exec_2026_01_27_001"
    ...     )

    >>> # 使用认证
    >>> async with Hezor2SDK(api_key="your-key") as sdk:
    ...     result = await sdk.publish_creation_report(...)
    """

    def __init__(
        self,
        base_url: str = DEFAULT_API_BASE_URL,
        timeout: float = 120.0,
        api_key: str | None = DEFAULT_API_KEY,
        meta_info: MetaInfo | None = None,
        private_key_path: str | Path | None = None,
        password: bytes | None = None,
        meta_info_expires_in: int = 3600,
        app_name: str | None = None,
    ):
        """初始化 Hezor2 SDK。

        Parameters
        ----------
        base_url : str
            API 基础 URL
        timeout : float
            请求超时时间（秒）
        api_key : str | None
            API 密钥
        meta_info : MetaInfo | None
            元信息对象
        private_key_path : str | Path | None
            私钥文件路径
        password : bytes | None
            私钥密码
        meta_info_expires_in : int
            MetaInfo JWT token 过期时间（秒）
        app_name : str | None
            应用名称，通过 X-APP-NAME 头传递给服务端
        """
        self._client = Hezor2APIClient(
            base_url=base_url,
            timeout=timeout,
            api_key=api_key,
            meta_info=meta_info,
            private_key_path=private_key_path,
            password=password,
            meta_info_expires_in=meta_info_expires_in,
            app_name=app_name,
        )

    async def __aenter__(self) -> "Hezor2SDK":
        """进入异步上下文管理器。

        Returns
        -------
        Hezor2SDK
            SDK 实例
        """
        await self._client.__aenter__()
        logger.debug("Hezor2SDK context manager entered")
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """退出异步上下文管理器。

        Parameters
        ----------
        exc_type : type | None
            异常类型
        exc_val : Exception | None
            异常值
        exc_tb : TracebackType | None
            异常 traceback
        """
        await self._client.__aexit__(exc_type, exc_val, exc_tb)
        logger.debug("Hezor2SDK context manager exited")

    async def generate_report_id(
        self,
        count: int = 1,
    ) -> list[str]:
        """生成唯一报告 ID。

        Parameters
        ----------
        count : int
            需要生成的 ID 数量（the default is 1）。

        Returns
        -------
        list[str]
            生成的报告 ID 列表，带 ``rpt_`` 前缀。

        Raises
        ------
        httpx.HTTPError
            如果 HTTP 请求失败。

        Examples
        --------
        >>> async with Hezor2SDK() as sdk:
        ...     ids = await sdk.generate_report_id(count=3)
        ...     print(ids)
        ['rpt_xxx', 'rpt_yyy', 'rpt_zzz']
        """
        return await self._client.generate_report_id(count=count)

    async def publish_creation_report(
        self,
        creation_result: CreationGenerateResult | CreationGenerateResultV2,
        task_id: str | None = None,
        execution_id: str | None = None,
    ) -> PublishCreationResponseData:
        """发布创建报告到 Hezor2。

        推荐传入 ``CreationGenerateResultV2``（扁平化结构），
        SDK 会自动使用 ``publish_creation_report_v2`` action。
        传入 ``CreationGenerateResult`` 仍然可用，但该路径
        将在未来版本中废弃。

        Parameters
        ----------
        creation_result : CreationGenerateResult or CreationGenerateResultV2
            生成的创建结果。推荐使用
            ``CreationGenerateResultV2``。
        task_id : str or None
            任务 ID。为 None 时服务端自动生成。
        execution_id : str or None
            执行 ID。为 None 时服务端自动生成。

        Returns
        -------
        PublishCreationResponseData
            包含 ``report_id``, ``task_id``,
            ``execution_id``。

        Raises
        ------
        httpx.HTTPError
            如果 HTTP 请求失败。

        Examples
        --------
        推荐用法（V2）：

        >>> result = CreationGenerateResultV2(
        ...     creation_id="rpt_xxx",
        ...     title="鮨大山 单店盈利模型",
        ...     full_content="# 报告内容...",
        ...     subject="鮨大山",
        ...     slug="single_store_profit_model",
        ... )
        >>> async with Hezor2SDK() as sdk:
        ...     response = await sdk.publish_creation_report(
        ...         creation_result=result,
        ...         task_id="monthly_report",
        ...     )
        ...     print(response.report_id)

        从字典或外部数据构建时，使用 ``model_validate``：

        >>> data = {"creation_id": "rpt_xxx", ...}
        >>> result = CreationGenerateResultV2.model_validate(data)

        旧用法（将废弃）：

        >>> async with Hezor2SDK() as sdk:
        ...     response = await sdk.publish_creation_report(
        ...         creation_result=CreationGenerateResult(...),
        ...     )
        """
        return await self._client.publish_creation_report(
            payload=creation_result,
            task_id=task_id,
            execution_id=execution_id,
        )

    async def get_report_status(
        self,
        creation_id: str,
        report_id: str,
    ) -> ReportMetadata:
        """查询报告状态。

        Parameters
        ----------
        creation_id : str
            Creation ID。
        report_id : str
            Report ID。

        Returns
        -------
        ReportMetadata
            报告元数据。

        Raises
        ------
        httpx.HTTPError
            如果 HTTP 请求失败。

        Examples
        --------
        >>> async with Hezor2SDK() as sdk:
        ...     resp = await sdk.get_report_status(
        ...         creation_id="crt_xxx",
        ...         report_id="rpt_xxx",
        ...     )
        ...     print(resp.report_title)
        """
        return await self._client.get_report_status(
            creation_id=creation_id,
            report_id=report_id,
        )

    async def health_check(self) -> tuple[bool, dict]:
        """执行健康检查。

        调用 GET /health 端点检查 Hezor2 服务状态。

        Returns
        -------
        tuple[bool, dict]
            - bool: 健康检查是否通过（基于 response.status == "healthy"）
            - dict: 原始健康检查响应数据

        Raises
        ------
        httpx.HTTPError
            如果 HTTP 请求失败

        Examples
        --------
        >>> async with Hezor2SDK() as sdk:
        ...     is_healthy, health_data = await sdk.health_check()
        ...     if is_healthy:
        ...         print("Service is healthy")
        ...     print(f"Details: {health_data}")
        """
        try:
            return await self._client.health_check()
        except httpx.HTTPError:
            # HTTP 请求失败，服务不健康
            return False, {"error": "HTTP request failed"}

    async def webhook_help(self, action: str) -> WebhookActionHelp:
        """查询 Webhook action 的接口文档。

        获取指定 action 的文档信息，包括 payload schema、
        response data schema 和用法示例。

        Parameters
        ----------
        action : str
            要查询的 action 名称，如
            ``"generate_report_id"``、
            ``"publish_creation_report"``、
            ``"get_report_status"``。

        Returns
        -------
        WebhookActionHelp
            包含 action 描述、用法、payload schema
            和 response data schema 的文档信息。

        Raises
        ------
        httpx.HTTPError
            如果 HTTP 请求失败。

        Examples
        --------
        >>> async with Hezor2SDK() as sdk:
        ...     info = await sdk.webhook_help(
        ...         "generate_report_id"
        ...     )
        ...     print(info.action)
        'generate_report_id'
        """
        return await self._client.webhook_help(action)

    async def knowledge_retrieve(
        self,
        query: str,
        *,
        top_k: int = 3,
        score_threshold: float = 0.5,
    ) -> KnowledgeSearchResult:
        """调用 ``knowledge_retrieve`` webhook 并返回结构化结果。

        Parameters
        ----------
        query : str
            检索查询。
        top_k : int
            每个集合返回数量上限。
        score_threshold : float
            相似度阈值。

        Returns
        -------
        KnowledgeSearchResult
            综合知识检索结果。

        Raises
        ------
        httpx.HTTPError
            如果 HTTP 请求失败。
        """
        return await self._client.knowledge_retrieve(
            query=query,
            top_k=top_k,
            score_threshold=score_threshold,
        )

    async def data_retrieve(
        self,
        query: str,
        *,
        top_k: int = 1,
    ) -> DataRetrieveResult:
        """调用 ``data_retrieve`` webhook 并返回结构化结果。

        Parameters
        ----------
        query : str
            数据查询语句。
        top_k : int
            工具搜索返回的最大数量，默认为 1。

        Returns
        -------
        DataRetrieveResult
            各工具执行结果映射，包含 ``query`` 和 ``results``。

        Raises
        ------
        httpx.HTTPError
            如果 HTTP 请求失败。
        """
        return await self._client.data_retrieve(
            query=query,
            top_k=top_k,
        )


__all__ = ["Hezor2SDK"]
