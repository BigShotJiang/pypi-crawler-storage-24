"""Hezor2 SDK 常量定义。

定义 Hezor2 SDK 使用的默认值和常量。
"""

from hezor_common.transfer.hezor2_sdk.env_config import Hezor2EnvConfig

# 从环境变量加载配置（单一数据源）
_config = Hezor2EnvConfig()

DEFAULT_API_BASE_URL = _config.hezor2_api_base_url
DEFAULT_API_KEY = _config.hezor2_api_key

DEFAULT_HEADER_PK_FILEPATH: str | None = _config.hezor2_header_pk_filepath or None
DEFAULT_HEADER_PK_PASSWORD: str | None = _config.hezor2_header_pk_password or None

__all__ = [
    "DEFAULT_API_BASE_URL",
    "DEFAULT_API_KEY",
    "DEFAULT_HEADER_PK_FILEPATH",
    "DEFAULT_HEADER_PK_PASSWORD",
]
