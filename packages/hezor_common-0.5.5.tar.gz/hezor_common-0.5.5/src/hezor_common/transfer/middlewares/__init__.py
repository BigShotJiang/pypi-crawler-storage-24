"""Middlewares for FastAPI applications.

This module provides middleware components for credential extraction,
validation, and other common HTTP concerns.
"""

from hezor_common.transfer.middlewares.constants import (
    REQ_HEADER_APP_NAME_KEY,
    REQ_HEADER_META_INFO_KEY,
)
from hezor_common.transfer.middlewares.credential_middleware import CredentialMiddleware
from hezor_common.transfer.middlewares.meta_info_decoder import decode_meta_info
from hezor_common.transfer.middlewares.require_api_key import RequireAPIKey, require_api_key
from hezor_common.transfer.middlewares.require_credentials import (
    GetCredentials,
    RequireCredentials,
    get_credentials,
    require_credentials,
)
from hezor_common.transfer.middlewares.require_meta_info import (
    GetMetaInfo,
    RequireMetaInfo,
    get_meta_info,
    require_meta_info,
)

__all__ = [
    "CredentialMiddleware",
    "REQ_HEADER_APP_NAME_KEY",
    "REQ_HEADER_META_INFO_KEY",
    "decode_meta_info",
    "RequireAPIKey",
    "require_api_key",
    "RequireMetaInfo",
    "require_meta_info",
    "GetMetaInfo",
    "get_meta_info",
    "RequireCredentials",
    "require_credentials",
    "GetCredentials",
    "get_credentials",
]
