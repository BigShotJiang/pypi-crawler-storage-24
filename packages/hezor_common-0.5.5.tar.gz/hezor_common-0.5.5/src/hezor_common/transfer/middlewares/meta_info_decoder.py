"""MetaInfo JWT 解密工具。

提供统一的 MetaInfo JWT 解密函数，确保 CredentialMiddleware
和业务层 get_meta_info 使用一致的解密逻辑。
"""

import logging

from hezor_common.security.jwt import decode_jwt_with_pem
from hezor_common.transfer.base_sdk.meta_info import MetaInfo

logger = logging.getLogger(__name__)


def decode_meta_info(
    token: str,
    public_key_pem: str | bytes,
    *,
    verify: bool = True,
) -> MetaInfo:
    """使用公钥解密 MetaInfo JWT token。

    Parameters
    ----------
    token : str
        X-META-INFO Header 中的 JWT token
    public_key_pem : str | bytes
        PEM 格式的公钥内容
    verify : bool, optional
        是否验证 JWT 签名（default: True）

    Returns
    -------
    MetaInfo
        解密后的 MetaInfo 对象

    Raises
    ------
    Exception
        JWT 解密或 MetaInfo 验证失败时抛出

    Examples
    --------
    >>> meta = decode_meta_info(token, public_key_pem)
    >>> print(meta.subject)
    'user_123'
    """
    public_key_bytes = (
        public_key_pem.encode("utf-8") if isinstance(public_key_pem, str) else public_key_pem
    )
    payload = decode_jwt_with_pem(public_key_bytes, token, verify=verify)
    return MetaInfo.model_validate(payload)
