"""Knowledge Graph SDK 环境配置加载模块。

提供基于 Pydantic 的环境变量自动加载功能。
"""

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class KnowledgeGraphEnvConfig(BaseSettings):
    """Knowledge Graph SDK 环境配置。

    自动从 .env 文件加载环境变量。

    Attributes
    ----------
    knowledge_graph_api_base_url : str
        Knowledge Graph API 基础 URL
    knowledge_graph_api_key : str
        Knowledge Graph API Key
    knowledge_graph_header_pk_filepath : str
        请求头私钥文件路径
    knowledge_graph_header_pk_password : str
        请求头私钥密码
    """

    model_config = SettingsConfigDict(
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    knowledge_graph_api_base_url: str = Field(
        default="http://localhost:8000",
        description="Knowledge Graph API 基础 URL",
    )

    knowledge_graph_api_key: str = Field(
        default="test-api-key",
        description="Knowledge Graph API Key",
    )

    knowledge_graph_header_pk_filepath: str = Field(
        default="",
        description="请求头私钥文件路径",
    )

    knowledge_graph_header_pk_password: str = Field(
        default="",
        description="请求头私钥密码",
    )


def load_env(env_file: str | Path | None = None) -> KnowledgeGraphEnvConfig:
    """加载环境配置。

    从环境变量中读取 Knowledge Graph SDK 配置。作为第三方库，本函数只读取环境变量，
    不会修改全局环境变量。用户应该在自己的应用层设置环境变量。

    Parameters
    ----------
    env_file : str | Path | None, optional
        .env 文件路径，默认为 None（仅从环境变量读取）
        注意：env_file 参数主要用于示例代码和测试场景

    Returns
    -------
    KnowledgeGraphEnvConfig
        从环境变量读取的配置实例

    Examples
    --------
    >>> # 从环境变量读取配置
    >>> from hezor_common.transfer.knowledge_graph_sdk.env_config import load_env
    >>> config = load_env()
    >>> print(config.knowledge_graph_api_base_url)
    'http://localhost:8000'

    >>> # 在示例代码中从 .env 文件读取
    >>> config = load_env(".env")
    >>> print(config.knowledge_graph_api_key)
    """
    # 如果指定了 env_file，动态创建配置类
    if env_file:
        from pydantic_settings import SettingsConfigDict

        config_dict = SettingsConfigDict(
            env_file=env_file,
            env_file_encoding="utf-8",
            case_sensitive=False,
            extra="ignore",
        )

        class _KnowledgeGraphEnvConfigWithFile(KnowledgeGraphEnvConfig):
            model_config = config_dict

        return _KnowledgeGraphEnvConfigWithFile()

    # 仅从环境变量读取
    return KnowledgeGraphEnvConfig()
