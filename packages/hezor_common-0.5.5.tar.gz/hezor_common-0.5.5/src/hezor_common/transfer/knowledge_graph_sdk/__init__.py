"""Knowledge Graph SDK for Knowledge Graph API access."""

from hezor_common.data_model.searching import (
    VectorSearchRequest,
    VectorSearchResponse,
)
from hezor_common.transfer.base_sdk import MetaInfo
from hezor_common.transfer.knowledge_graph_sdk.base.knowledge_graph_api_client import (
    KnowledgeGraphAPIClient,
)
from hezor_common.transfer.knowledge_graph_sdk.env_config import (
    KnowledgeGraphEnvConfig,
    load_env,
)
from hezor_common.transfer.knowledge_graph_sdk.sdk import KnowledgeGraphSDK
from hezor_common.transfer.knowledge_graph_sdk.vector_search import (
    vector_search,
)

__all__ = [
    # SDK class
    "KnowledgeGraphSDK",
    # Meta info
    "MetaInfo",
    # Client class
    "KnowledgeGraphAPIClient",
    # Environment config
    "KnowledgeGraphEnvConfig",
    "load_env",
    # Data models
    "VectorSearchRequest",
    "VectorSearchResponse",
    # Convenience functions
    "vector_search",
]
