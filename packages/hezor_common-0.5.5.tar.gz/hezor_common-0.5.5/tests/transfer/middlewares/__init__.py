"""Tests for transfer middlewares module."""
