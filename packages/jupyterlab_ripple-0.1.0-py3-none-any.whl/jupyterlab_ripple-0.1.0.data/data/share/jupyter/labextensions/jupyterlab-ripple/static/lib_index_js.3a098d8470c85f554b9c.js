"use strict";
(self["webpackChunkjupyterlab_ripple"] = self["webpackChunkjupyterlab_ripple"] || []).push([["lib_index_js"],{

/***/ "./lib/analyzer.js"
/*!*************************!*\
  !*** ./lib/analyzer.js ***!
  \*************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   analyzeCell: () => (/* binding */ analyzeCell)
/* harmony export */ });
// Copyright (c) Orange Bricks
// Distributed under the terms of the MIT License.
/**
 * Python code snippet that performs AST analysis on a cell's source.
 * Sent as a silent execution request to the kernel.
 *
 * The snippet:
 * 1. Decodes the cell source from base64 (safe embedding of arbitrary code)
 * 2. Strips IPython magic commands (%, !, %%) and replaces with `pass`
 * 3. Parses the cleaned source with ast.parse()
 * 4. Walks the AST to collect definitions (assignments, function/class defs, imports)
 *    and references (variable loads)
 * 5. Removes self-defined variables and builtins from references
 * 6. Prints a JSON result: {"defs": [...], "refs": [...]}
 */
function buildAnalysisCode(cellSource) {
    // Use base64 encoding to safely embed arbitrary cell source in Python.
    const encoded = btoa(unescape(encodeURIComponent(cellSource)));
    return `
import ast as _ast, json as _json, base64 as _b64
try:
    _source = _b64.b64decode("${encoded}").decode("utf-8")
    # Strip magic commands: lines starting with %, !, or %%
    _lines = _source.split('\\n')
    _cleaned = []
    _in_cell_magic = False
    for _line in _lines:
        _stripped = _line.lstrip()
        if _in_cell_magic:
            _cleaned.append('pass')
            continue
        if _stripped.startswith('%%'):
            _in_cell_magic = True
            _cleaned.append('pass')
        elif _stripped.startswith('%') or _stripped.startswith('!'):
            _cleaned.append('pass')
        else:
            _cleaned.append(_line)
    _source = '\\n'.join(_cleaned)
    _tree = _ast.parse(_source)
    _defs = set()
    _refs = set()
    for _node in _ast.walk(_tree):
        if isinstance(_node, (_ast.FunctionDef, _ast.AsyncFunctionDef, _ast.ClassDef)):
            _defs.add(_node.name)
        elif isinstance(_node, _ast.Name):
            if isinstance(_node.ctx, _ast.Store):
                _defs.add(_node.id)
            elif isinstance(_node.ctx, (_ast.Load, _ast.Del)):
                _refs.add(_node.id)
        elif isinstance(_node, _ast.Import):
            for _alias in _node.names:
                _defs.add(_alias.asname or _alias.name.split('.')[0])
        elif isinstance(_node, _ast.ImportFrom):
            for _alias in _node.names:
                if _alias.name != '*':
                    _defs.add(_alias.asname or _alias.name)
        elif isinstance(_node, (_ast.For, _ast.comprehension)):
            pass  # handled by Name(Store) on target
        elif isinstance(_node, _ast.Global):
            for _n in _node.names:
                _refs.add(_n)
    # In Python 3, comprehension iteration variables are scoped locally
    # and do not leak into the cell namespace. Remove them from _defs
    # unless they are also assigned at the top level.
    _comp_targets = set()
    for _node in _ast.walk(_tree):
        if isinstance(_node, _ast.comprehension):
            if isinstance(_node.target, _ast.Name):
                _comp_targets.add(_node.target.id)
            elif isinstance(_node.target, _ast.Tuple):
                for _elt in _ast.walk(_node.target):
                    if isinstance(_elt, _ast.Name):
                        _comp_targets.add(_elt.id)
    _top_defs = set()
    for _node in _ast.iter_child_nodes(_tree):
        if isinstance(_node, _ast.Assign):
            for _tgt_node in _node.targets:
                for _tgt in _ast.walk(_tgt_node):
                    if isinstance(_tgt, _ast.Name):
                        _top_defs.add(_tgt.id)
        elif isinstance(_node, (_ast.AnnAssign, _ast.AugAssign)):
            if _node.target:
                for _tgt in _ast.walk(_node.target):
                    if isinstance(_tgt, _ast.Name):
                        _top_defs.add(_tgt.id)
        elif isinstance(_node, (_ast.FunctionDef, _ast.AsyncFunctionDef, _ast.ClassDef)):
            _top_defs.add(_node.name)
        elif isinstance(_node, _ast.Import):
            for _alias in _node.names:
                _top_defs.add(_alias.asname or _alias.name.split('.')[0])
        elif isinstance(_node, _ast.ImportFrom):
            for _alias in _node.names:
                if _alias.name != '*':
                    _top_defs.add(_alias.asname or _alias.name)
        elif isinstance(_node, _ast.For):
            for _tgt in _ast.walk(_node.target):
                if isinstance(_tgt, _ast.Name):
                    _top_defs.add(_tgt.id)
    _defs -= (_comp_targets - _top_defs)
    _refs -= (_comp_targets - _top_defs)
    # Remove self-defined refs and builtins
    import builtins as _builtins
    _refs -= _defs
    _refs -= set(dir(_builtins))
    # Remove underscore-prefixed (cell-local) variables
    _defs = {_d for _d in _defs if not _d.startswith('_')}
    _refs = {_r for _r in _refs if not _r.startswith('_')}
    print(_json.dumps({"defs": sorted(_defs), "refs": sorted(_refs)}))
except Exception as _e:
    print(_json.dumps({"defs": [], "refs": [], "error": str(_e)}))
`.trim();
}
/**
 * Analyze a cell's source code by sending a silent execution request to the kernel.
 *
 * @param source - The cell's source code.
 * @param kernel - The kernel connection to use.
 * @returns The analysis result with defined and referenced variables.
 */
async function analyzeCell(source, kernel) {
    const code = buildAnalysisCode(source);
    return new Promise(resolve => {
        const future = kernel.requestExecute({
            code,
            silent: true,
            store_history: false
        });
        let stdout = '';
        future.onIOPub = (msg) => {
            if (msg.header.msg_type === 'stream') {
                const content = msg.content;
                if (content.name === 'stdout') {
                    stdout += content.text;
                }
            }
        };
        future.done
            .then(() => {
            var _a, _b;
            const trimmed = stdout.trim();
            if (!trimmed) {
                resolve({ defs: [], refs: [] });
                return;
            }
            try {
                const parsed = JSON.parse(trimmed);
                resolve({
                    defs: (_a = parsed.defs) !== null && _a !== void 0 ? _a : [],
                    refs: (_b = parsed.refs) !== null && _b !== void 0 ? _b : []
                });
            }
            catch (_c) {
                console.warn('Ripple: Failed to parse AST analysis result:', trimmed);
                resolve({ defs: [], refs: [] });
            }
        })
            .catch((err) => {
            console.warn('Ripple: AST analysis failed', err);
            resolve({ defs: [], refs: [] });
        });
    });
}


/***/ },

/***/ "./lib/dag.js"
/*!********************!*\
  !*** ./lib/dag.js ***!
  \********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   buildGraph: () => (/* binding */ buildGraph),
/* harmony export */   detectCycles: () => (/* binding */ detectCycles),
/* harmony export */   findConflicts: () => (/* binding */ findConflicts),
/* harmony export */   getDownstreamCells: () => (/* binding */ getDownstreamCells),
/* harmony export */   hashSource: () => (/* binding */ hashSource)
/* harmony export */ });
// Copyright (c) Orange Bricks
// Distributed under the terms of the MIT License.
/**
 * Build a dependency graph from cell analyses.
 *
 * @param analyses - Array of cell analyses.
 * @param cellOrder - Array of cell IDs in notebook order (used as tiebreaker).
 * @returns The dependency graph.
 */
function buildGraph(analyses, cellOrder) {
    const cells = new Map();
    const variableOwner = new Map();
    const downstreamEdges = new Map();
    const upstreamEdges = new Map();
    // Populate cells map and variable ownership.
    // Process in notebook order so later cells override earlier ones for
    // variable ownership (last-definition-wins).
    for (const cellId of cellOrder) {
        const analysis = analyses.find(a => a.cellId === cellId);
        if (!analysis) {
            continue;
        }
        cells.set(cellId, analysis);
        downstreamEdges.set(cellId, new Set());
        upstreamEdges.set(cellId, new Set());
        for (const varName of analysis.defines) {
            variableOwner.set(varName, cellId);
        }
    }
    // Build edges based on variable references.
    for (const [cellId, analysis] of cells) {
        for (const ref of analysis.references) {
            const ownerCellId = variableOwner.get(ref);
            if (ownerCellId && ownerCellId !== cellId) {
                // cellId depends on ownerCellId
                downstreamEdges.get(ownerCellId).add(cellId);
                upstreamEdges.get(cellId).add(ownerCellId);
            }
        }
    }
    return { cells, variableOwner, downstreamEdges, upstreamEdges };
}
/**
 * Get all transitive downstream dependents of a cell in topological order.
 *
 * Uses Kahn's algorithm on the subgraph of reachable nodes.
 *
 * @param cellId - The cell that was executed.
 * @param graph - The dependency graph.
 * @returns Array of cell IDs in execution order (excludes the trigger cell).
 */
function getDownstreamCells(cellId, graph) {
    var _a, _b, _c, _d;
    // First, find all reachable downstream cells via BFS.
    const reachable = new Set();
    const queue = [cellId];
    while (queue.length > 0) {
        const current = queue.shift();
        const downstream = graph.downstreamEdges.get(current);
        if (downstream) {
            for (const dep of downstream) {
                if (!reachable.has(dep)) {
                    reachable.add(dep);
                    queue.push(dep);
                }
            }
        }
    }
    if (reachable.size === 0) {
        return [];
    }
    // Build in-degree counts for the reachable subgraph.
    const inDegree = new Map();
    for (const nodeId of reachable) {
        inDegree.set(nodeId, 0);
    }
    for (const nodeId of reachable) {
        const downstream = graph.downstreamEdges.get(nodeId);
        if (downstream) {
            for (const dep of downstream) {
                if (reachable.has(dep)) {
                    inDegree.set(dep, ((_a = inDegree.get(dep)) !== null && _a !== void 0 ? _a : 0) + 1);
                }
            }
        }
    }
    // Also count edges from the trigger cell into the reachable set.
    const triggerDownstream = graph.downstreamEdges.get(cellId);
    if (triggerDownstream) {
        for (const dep of triggerDownstream) {
            if (reachable.has(dep)) {
                inDegree.set(dep, ((_b = inDegree.get(dep)) !== null && _b !== void 0 ? _b : 0) + 1);
            }
        }
    }
    // Kahn's algorithm: process nodes with in-degree 0.
    const sorted = [];
    const kahnQueue = [];
    // Start with reachable nodes whose only upstream within the subgraph
    // is the trigger cell (in-degree from reachable nodes is 0 after removing trigger edges).
    // We need to recompute: in-degree considering only edges within reachable set.
    const subgraphInDegree = new Map();
    for (const nodeId of reachable) {
        subgraphInDegree.set(nodeId, 0);
    }
    for (const nodeId of reachable) {
        const upstream = graph.upstreamEdges.get(nodeId);
        if (upstream) {
            for (const dep of upstream) {
                if (reachable.has(dep)) {
                    subgraphInDegree.set(nodeId, ((_c = subgraphInDegree.get(nodeId)) !== null && _c !== void 0 ? _c : 0) + 1);
                }
            }
        }
    }
    for (const [nodeId, degree] of subgraphInDegree) {
        if (degree === 0) {
            kahnQueue.push(nodeId);
        }
    }
    while (kahnQueue.length > 0) {
        const current = kahnQueue.shift();
        sorted.push(current);
        const downstream = graph.downstreamEdges.get(current);
        if (downstream) {
            for (const dep of downstream) {
                if (reachable.has(dep)) {
                    const newDegree = ((_d = subgraphInDegree.get(dep)) !== null && _d !== void 0 ? _d : 1) - 1;
                    subgraphInDegree.set(dep, newDegree);
                    if (newDegree === 0) {
                        kahnQueue.push(dep);
                    }
                }
            }
        }
    }
    return sorted;
}
/**
 * Detect cycles in the dependency graph using Tarjan's SCC algorithm.
 *
 * @param graph - The dependency graph.
 * @returns Array of strongly connected components with more than one node.
 *          Each SCC is an array of cell IDs.
 */
function detectCycles(graph) {
    let index = 0;
    const stack = [];
    const onStack = new Set();
    const indices = new Map();
    const lowlinks = new Map();
    const sccs = [];
    function strongConnect(v) {
        indices.set(v, index);
        lowlinks.set(v, index);
        index++;
        stack.push(v);
        onStack.add(v);
        const downstream = graph.downstreamEdges.get(v);
        if (downstream) {
            for (const w of downstream) {
                if (!indices.has(w)) {
                    strongConnect(w);
                    lowlinks.set(v, Math.min(lowlinks.get(v), lowlinks.get(w)));
                }
                else if (onStack.has(w)) {
                    lowlinks.set(v, Math.min(lowlinks.get(v), indices.get(w)));
                }
            }
        }
        if (lowlinks.get(v) === indices.get(v)) {
            const scc = [];
            let w;
            do {
                w = stack.pop();
                onStack.delete(w);
                scc.push(w);
            } while (w !== v);
            if (scc.length > 1) {
                sccs.push(scc);
            }
        }
    }
    for (const cellId of graph.cells.keys()) {
        if (!indices.has(cellId)) {
            strongConnect(cellId);
        }
    }
    return sccs;
}
/**
 * Find variables defined in multiple cells.
 *
 * @param analyses - Array of cell analyses.
 * @returns Array of variable conflicts.
 */
function findConflicts(analyses) {
    const varToCells = new Map();
    for (const analysis of analyses) {
        for (const varName of analysis.defines) {
            const existing = varToCells.get(varName);
            if (existing) {
                existing.push(analysis.cellId);
            }
            else {
                varToCells.set(varName, [analysis.cellId]);
            }
        }
    }
    const conflicts = [];
    for (const [variable, cellIds] of varToCells) {
        if (cellIds.length > 1) {
            conflicts.push({ variable, cellIds });
        }
    }
    return conflicts;
}
/**
 * Simple string hash function for cache keys.
 */
function hashSource(source) {
    let hash = 0;
    for (let i = 0; i < source.length; i++) {
        const char = source.charCodeAt(i);
        hash = ((hash << 5) - hash + char) | 0;
    }
    return hash.toString(36);
}


/***/ },

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _reactiveCellExecutor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./reactiveCellExecutor */ "./lib/reactiveCellExecutor.js");
/* harmony import */ var _reactiveState__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./reactiveState */ "./lib/reactiveState.js");
/* harmony import */ var _ui_dependencyIndicators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ui/dependencyIndicators */ "./lib/ui/dependencyIndicators.js");
/* harmony import */ var _ui_toggleButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ui/toggleButton */ "./lib/ui/toggleButton.js");
// Copyright (c) Orange Bricks
// Distributed under the terms of the MIT License.







/**
 * Shared state manager singleton.
 */
const stateManager = new _reactiveState__WEBPACK_IMPORTED_MODULE_4__.ReactiveStateManager();
/**
 * Plugin A: Provides the reactive cell executor.
 *
 * This replaces the default @jupyterlab/notebook-extension:cell-executor plugin.
 */
const executorPlugin = {
    id: 'jupyterlab-ripple:executor',
    description: 'Provides a reactive notebook cell executor that automatically ' +
        're-executes downstream dependent cells.',
    autoStart: true,
    provides: _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookCellExecutor,
    activate: () => {
        console.warn('Ripple: Activated reactive cell executor.');
        const executor = new _reactiveCellExecutor__WEBPACK_IMPORTED_MODULE_3__.ReactiveCellExecutor(stateManager);
        return Object.freeze({
            runCell: executor.runCell.bind(executor)
        });
    }
};
/**
 * Plugin B: Sets up the UI (toolbar buttons, dependency indicators).
 *
 * Wires the ReactiveStateManager to actual notebook panels via INotebookTracker.
 */
const uiPlugin = {
    id: 'jupyterlab-ripple:ui',
    description: 'Provides the Ripple reactive notebook UI: toggle button and dependency indicators.',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    optional: [_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__.ITranslator, _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__.ISettingRegistry],
    activate: (app, tracker, translator, settingRegistry) => {
        let enabledByDefault = true;
        if (settingRegistry) {
            void settingRegistry
                .load('jupyterlab-ripple:executor')
                .then(settings => {
                enabledByDefault = settings.get('enabled').composite;
                settings.changed.connect(() => {
                    enabledByDefault = settings.get('enabled').composite;
                });
            })
                .catch(() => {
                console.warn('Ripple: Could not load settings, using defaults.');
            });
        }
        stateManager.setEnabledDefault(() => enabledByDefault);
        (0,_ui_toggleButton__WEBPACK_IMPORTED_MODULE_6__.registerToggleCommand)(app, tracker, stateManager, translator !== null && translator !== void 0 ? translator : undefined);
        tracker.widgetAdded.connect((_sender, panel) => {
            setupNotebookPanel(app, panel);
        });
        tracker.forEach((panel) => {
            setupNotebookPanel(app, panel);
        });
        console.warn('Ripple: UI plugin activated.');
    }
};
/**
 * Set up reactive features for a single notebook panel.
 */
function setupNotebookPanel(app, panel) {
    // Create the reactive state for this notebook first (needed by toolbar widget).
    const state = stateManager.getOrCreateState(panel);
    // Add the toolbar toggle widget, wired to this panel's state.
    (0,_ui_toggleButton__WEBPACK_IMPORTED_MODULE_6__.addToolbarButton)(panel, app, state);
    // Update indicators whenever the reactive state changes.
    state.stateChanged.connect(() => {
        (0,_ui_dependencyIndicators__WEBPACK_IMPORTED_MODULE_5__.updateDependencyIndicators)(panel, state);
    });
    // Clean up when the panel is disposed.
    panel.disposed.connect(() => {
        (0,_ui_dependencyIndicators__WEBPACK_IMPORTED_MODULE_5__.clearDependencyIndicators)(panel);
    });
}
/**
 * Export all plugins.
 */
const plugins = [executorPlugin, uiPlugin];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugins);


/***/ },

/***/ "./lib/reactiveCellExecutor.js"
/*!*************************************!*\
  !*** ./lib/reactiveCellExecutor.js ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReactiveCellExecutor: () => (/* binding */ ReactiveCellExecutor)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
// Copyright (c) Orange Bricks
// Distributed under the terms of the MIT License.

/**
 * A reactive cell executor that wraps the default executor.
 *
 * After executing a cell, if reactivity is enabled for its notebook,
 * it automatically re-executes all downstream dependent cells in
 * topological order.
 */
class ReactiveCellExecutor {
    constructor(stateManager) {
        this._stateManager = stateManager;
    }
    /**
     * Execute a cell, then propagate to downstream dependents if reactive mode is on.
     */
    async runCell(options) {
        const state = this._stateManager.getStateByModel(options.notebook);
        const leaveRunCell = state === null || state === void 0 ? void 0 : state.enterRunCell();
        try {
            // Step 1: Run the cell using the default executor.
            const success = await (0,_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.runCell)(options);
            if (!success) {
                return false;
            }
            // Step 2: Check if reactivity is enabled for this notebook.
            if (!state || !state.enabled) {
                return true;
            }
            // Skip propagation during batch execution (e.g. Run All Cells).
            if (state.isRunningBatch) {
                const cellId = options.cell.model.sharedModel.getId();
                state.markExecuted(cellId);
                state.clearStale(cellId);
                return true;
            }
            // Step 3: Re-analyze the executed cell.
            const cellId = options.cell.model.sharedModel.getId();
            state.markExecuted(cellId);
            const source = options.cell.model.sharedModel.getSource();
            if (source.trim() && options.cell.model.type === 'code') {
                await state.analyzeSingleCell(cellId, source);
            }
            // Clear stale status of the executed cell.
            state.clearStale(cellId);
            // Step 4: Get downstream cells in topological order.
            const allDownstreamIds = state.getDownstreamExecutionOrder(cellId);
            // Only re-execute cells that (a) have been run before AND (b) have
            // all their upstream dependencies satisfied.
            const downstreamIds = allDownstreamIds.filter(id => state.hasBeenExecuted(id) && state.allUpstreamExecuted(id));
            if (downstreamIds.length === 0) {
                return true;
            }
            // Step 5: Execute each downstream cell sequentially.
            const panel = state.panel;
            for (const downstreamId of downstreamIds) {
                const downstreamCell = this._stateManager.findCellWidget(panel, downstreamId);
                if (downstreamCell && downstreamCell.model.type === 'code') {
                    const downstreamOptions = {
                        cell: downstreamCell,
                        notebook: options.notebook,
                        notebookConfig: options.notebookConfig,
                        onCellExecuted: options.onCellExecuted,
                        onCellExecutionScheduled: options.onCellExecutionScheduled,
                        sessionContext: options.sessionContext,
                        sessionDialogs: options.sessionDialogs,
                        translator: options.translator
                    };
                    const downstreamSuccess = await (0,_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.runCell)(downstreamOptions);
                    state.clearStale(downstreamId);
                    state.markExecuted(downstreamId);
                    if (!downstreamSuccess) {
                        console.warn(`Ripple: Stopping propagation due to error in cell ${downstreamId}`);
                        break;
                    }
                }
            }
            return true;
        }
        finally {
            leaveRunCell === null || leaveRunCell === void 0 ? void 0 : leaveRunCell();
        }
    }
}


/***/ },

/***/ "./lib/reactiveState.js"
/*!******************************!*\
  !*** ./lib/reactiveState.js ***!
  \******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReactiveNotebookState: () => (/* binding */ ReactiveNotebookState),
/* harmony export */   ReactiveStateManager: () => (/* binding */ ReactiveStateManager)
/* harmony export */ });
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _analyzer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./analyzer */ "./lib/analyzer.js");
/* harmony import */ var _dag__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dag */ "./lib/dag.js");
// Copyright (c) Orange Bricks
// Distributed under the terms of the MIT License.



/**
 * Per-notebook reactive state.
 */
class ReactiveNotebookState {
    constructor(panel, enabledByDefault = true) {
        this._wasBatch = false;
        this._conflicts = [];
        this._stateChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal(this);
        this._panel = panel;
        this._analysisCache = new Map();
        this._graph = null;
        this._enabled = enabledByDefault;
        this._staleCells = new Set();
        this._executedCells = new Set();
        this._cycleCells = new Set();
        this._conflictCells = new Set();
        this._debounceTimers = new Map();
        this._activeRunCells = 0;
        this._connectCellListeners();
        this._connectKernelListeners();
        if (this._enabled) {
            void this._scheduleInitialBuild();
        }
    }
    /**
     * Schedule the initial graph build for when the kernel first becomes idle.
     * This avoids racing with Run All or other user-initiated executions that
     * happen immediately after opening the notebook.
     *
     * If a cell execution starts before the kernel goes idle (e.g. the user
     * clicks Run All while the kernel is still starting), the build is skipped
     * -- the normal per-cell analysis in runCell will populate the graph
     * incrementally instead.
     */
    async _scheduleInitialBuild() {
        try {
            const ctx = this._panel.context;
            await ctx.ready;
            await ctx.sessionContext.ready;
            if (!this._enabled || this._activeRunCells > 0) {
                return;
            }
            await this._waitForKernelIdle();
            if (!this._enabled || this._activeRunCells > 0 || this._wasBatch) {
                return;
            }
            await this.rebuildAll();
            this._stateChanged.emit(void 0);
        }
        catch (_a) {
            // Kernel unavailable or panel disposed -- silently skip.
        }
    }
    /**
     * Return a promise that resolves once the kernel status reaches 'idle'.
     */
    _waitForKernelIdle() {
        var _a;
        const sessionContext = this._panel.context.sessionContext;
        const kernel = (_a = sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel;
        if ((kernel === null || kernel === void 0 ? void 0 : kernel.status) === 'idle') {
            return Promise.resolve();
        }
        return new Promise(resolve => {
            const onStatus = (_sender, status) => {
                if (status === 'idle') {
                    sessionContext.statusChanged.disconnect(onStatus);
                    resolve();
                }
            };
            sessionContext.statusChanged.connect(onStatus);
        });
    }
    /**
     * Whether reactivity is enabled for this notebook.
     */
    get enabled() {
        return this._enabled;
    }
    /**
     * Signal emitted when the reactive state changes (enabled/disabled, graph rebuilt).
     */
    get stateChanged() {
        return this._stateChanged;
    }
    /**
     * The current dependency graph, or null if not yet built.
     */
    get graph() {
        return this._graph;
    }
    /**
     * Set of cell IDs that are stale (need re-execution).
     */
    get staleCells() {
        return this._staleCells;
    }
    /**
     * Set of cell IDs involved in dependency cycles.
     */
    get cycleCells() {
        return this._cycleCells;
    }
    /**
     * Set of cell IDs with variable definition conflicts.
     */
    get conflictCells() {
        return this._conflictCells;
    }
    /**
     * Current variable conflicts.
     */
    get conflicts() {
        return this._conflicts;
    }
    /**
     * The notebook panel this state is associated with.
     */
    get panel() {
        return this._panel;
    }
    /**
     * Whether the current group of runCell calls is a batch (e.g. Run All).
     * Once two or more calls overlap, every call in the group is considered
     * part of the batch -- including the last one to finish.
     */
    get isRunningBatch() {
        return this._wasBatch;
    }
    /**
     * Increment the active runCell counter. Returns a disposer function.
     */
    enterRunCell() {
        this._activeRunCells++;
        if (this._activeRunCells > 1) {
            this._wasBatch = true;
        }
        return () => {
            this._activeRunCells--;
            if (this._activeRunCells === 0) {
                this._wasBatch = false;
            }
        };
    }
    /**
     * Toggle reactivity on/off.
     */
    async toggle() {
        this._enabled = !this._enabled;
        if (this._enabled) {
            await this.rebuildAll();
        }
        else {
            this._graph = null;
            this._staleCells.clear();
            this._executedCells.clear();
            this._cycleCells.clear();
            this._conflictCells.clear();
            this._conflicts = [];
        }
        this._stateChanged.emit(void 0);
    }
    /**
     * Analyze a single cell and update the graph.
     */
    async analyzeSingleCell(cellId, source) {
        const kernel = this._getKernel();
        if (!kernel) {
            return;
        }
        const srcHash = (0,_dag__WEBPACK_IMPORTED_MODULE_2__.hashSource)(source);
        // Check cache.
        const cached = this._analysisCache.get(cellId);
        if (cached && cached.sourceHash === srcHash) {
            return;
        }
        const result = await (0,_analyzer__WEBPACK_IMPORTED_MODULE_1__.analyzeCell)(source, kernel);
        const analysis = {
            cellId,
            defines: new Set(result.defs),
            references: new Set(result.refs),
            sourceHash: srcHash
        };
        this._analysisCache.set(cellId, analysis);
        this._rebuildGraphFromCache();
    }
    /**
     * Re-analyze all cells and rebuild the graph.
     */
    async rebuildAll() {
        const kernel = this._getKernel();
        if (!kernel) {
            return;
        }
        const notebook = this._panel.content;
        const cells = notebook.widgets;
        this._analysisCache.clear();
        const promises = [];
        for (const cell of cells) {
            if (cell.model.type === 'code') {
                const cellId = cell.model.sharedModel.getId();
                const source = cell.model.sharedModel.getSource();
                if (source.trim()) {
                    promises.push(this.analyzeSingleCell(cellId, source));
                }
            }
        }
        await Promise.all(promises);
        this._rebuildGraphFromCache();
        this._stateChanged.emit(void 0);
    }
    /**
     * Get the topologically-sorted downstream cells that need re-execution.
     */
    getDownstreamExecutionOrder(cellId) {
        if (!this._graph) {
            return [];
        }
        const downstream = (0,_dag__WEBPACK_IMPORTED_MODULE_2__.getDownstreamCells)(cellId, this._graph);
        // Filter out cells that are in a cycle.
        return downstream.filter(id => !this._cycleCells.has(id));
    }
    /**
     * Remove a cell from the analysis cache and rebuild the graph.
     */
    removeCell(cellId) {
        this._analysisCache.delete(cellId);
        this._staleCells.delete(cellId);
        if (this._enabled) {
            this._rebuildGraphFromCache();
            this._stateChanged.emit(void 0);
        }
    }
    /**
     * Mark downstream cells of the given cell as stale.
     * Only cells that have been executed at least once are marked --
     * a cell that has never run cannot be "out of date".
     */
    markDownstreamStale(cellId) {
        if (!this._graph) {
            return;
        }
        const downstream = (0,_dag__WEBPACK_IMPORTED_MODULE_2__.getDownstreamCells)(cellId, this._graph);
        for (const id of downstream) {
            if (this._executedCells.has(id)) {
                this._staleCells.add(id);
            }
        }
        this._stateChanged.emit(void 0);
    }
    /**
     * Clear the stale status of a cell.
     */
    clearStale(cellId) {
        this._staleCells.delete(cellId);
    }
    /**
     * Record that a cell has been executed at least once in this session.
     */
    markExecuted(cellId) {
        this._executedCells.add(cellId);
    }
    /**
     * Whether a cell has been executed at least once in this session.
     */
    hasBeenExecuted(cellId) {
        return this._executedCells.has(cellId);
    }
    /**
     * Whether all upstream dependencies of a cell have been executed.
     */
    allUpstreamExecuted(cellId) {
        if (!this._graph) {
            return false;
        }
        const upstream = this._graph.upstreamEdges.get(cellId);
        if (!upstream || upstream.size === 0) {
            return true;
        }
        for (const depId of upstream) {
            if (!this._executedCells.has(depId)) {
                return false;
            }
        }
        return true;
    }
    /**
     * Dispose of this state.
     */
    dispose() {
        for (const timer of this._debounceTimers.values()) {
            clearTimeout(timer);
        }
        this._debounceTimers.clear();
        this._executedCells.clear();
        this._disconnectKernelListeners();
        _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal.clearData(this);
    }
    /**
     * Connect to kernel status changes to detect restarts.
     */
    _connectKernelListeners() {
        const sessionContext = this._panel.context.sessionContext;
        sessionContext.statusChanged.connect(this._onKernelStatus, this);
        sessionContext.kernelChanged.connect(this._onKernelChanged, this);
    }
    /**
     * Disconnect kernel listeners.
     */
    _disconnectKernelListeners() {
        const sessionContext = this._panel.context.sessionContext;
        sessionContext.statusChanged.disconnect(this._onKernelStatus, this);
        sessionContext.kernelChanged.disconnect(this._onKernelChanged, this);
    }
    /**
     * Clear execution tracking when the kernel restarts.
     */
    _onKernelStatus(_sender, status) {
        if (status === 'restarting' || status === 'autorestarting') {
            this._executedCells.clear();
            this._staleCells.clear();
            this._stateChanged.emit(void 0);
        }
    }
    /**
     * Clear execution tracking when the kernel changes.
     */
    _onKernelChanged() {
        this._executedCells.clear();
        this._staleCells.clear();
        this._analysisCache.clear();
        this._graph = null;
        this._stateChanged.emit(void 0);
    }
    /**
     * Connect content change listeners for all cells.
     */
    _connectCellListeners() {
        const notebook = this._panel.content;
        for (const cell of notebook.widgets) {
            this._connectCellContentListener(cell);
        }
        // Listen for new cells being added.
        if (notebook.model) {
            notebook.model.cells.changed.connect(this._onCellsChanged, this);
        }
    }
    /**
     * Connect a content change listener for a single cell.
     */
    _connectCellContentListener(cell) {
        cell.model.contentChanged.connect(this._onCellContentChanged, this);
    }
    /**
     * Handle cell content changes with debouncing.
     */
    _onCellContentChanged(cellModel) {
        if (!this._enabled) {
            return;
        }
        const cellId = cellModel.sharedModel.getId();
        // Debounce analysis: wait 500ms after last keystroke.
        const existing = this._debounceTimers.get(cellId);
        if (existing) {
            clearTimeout(existing);
        }
        this._debounceTimers.set(cellId, window.setTimeout(() => {
            this._debounceTimers.delete(cellId);
            const source = cellModel.sharedModel.getSource();
            if (source.trim() && cellModel.type === 'code') {
                const cached = this._analysisCache.get(cellId);
                if (cached && cached.sourceHash === (0,_dag__WEBPACK_IMPORTED_MODULE_2__.hashSource)(source)) {
                    return;
                }
                void this.analyzeSingleCell(cellId, source).then(() => {
                    this.markDownstreamStale(cellId);
                });
            }
        }, 500));
    }
    /**
     * Handle cells being added or removed.
     */
    _onCellsChanged() {
        if (!this._enabled) {
            return;
        }
        // Re-connect listeners for all cells.
        const notebook = this._panel.content;
        for (const cell of notebook.widgets) {
            // Disconnect first to avoid duplicates, then reconnect.
            cell.model.contentChanged.disconnect(this._onCellContentChanged, this);
            this._connectCellContentListener(cell);
        }
        // Rebuild the graph since cell list changed.
        void this.rebuildAll();
    }
    /**
     * Rebuild the graph from the analysis cache.
     */
    _rebuildGraphFromCache() {
        const analyses = Array.from(this._analysisCache.values());
        const cellOrder = this._getCellOrder();
        this._graph = (0,_dag__WEBPACK_IMPORTED_MODULE_2__.buildGraph)(analyses, cellOrder);
        // Detect cycles.
        const cycles = (0,_dag__WEBPACK_IMPORTED_MODULE_2__.detectCycles)(this._graph);
        this._cycleCells.clear();
        for (const cycle of cycles) {
            for (const cellId of cycle) {
                this._cycleCells.add(cellId);
            }
        }
        // Detect conflicts.
        this._conflicts = (0,_dag__WEBPACK_IMPORTED_MODULE_2__.findConflicts)(analyses);
        this._conflictCells.clear();
        for (const conflict of this._conflicts) {
            for (const cellId of conflict.cellIds) {
                this._conflictCells.add(cellId);
            }
        }
    }
    /**
     * Get the cell order from the notebook.
     */
    _getCellOrder() {
        const notebook = this._panel.content;
        const order = [];
        for (const cell of notebook.widgets) {
            if (cell.model.type === 'code') {
                order.push(cell.model.sharedModel.getId());
            }
        }
        return order;
    }
    /**
     * Get the kernel connection, if available.
     */
    _getKernel() {
        var _a, _b;
        return (_b = (_a = this._panel.context.sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel) !== null && _b !== void 0 ? _b : null;
    }
}
/**
 * Manages reactive state across all open notebooks.
 */
class ReactiveStateManager {
    constructor() {
        this._states = new Map();
        this._enabledDefault = () => true;
    }
    /**
     * Set a callback that returns the current default for the enabled setting.
     */
    setEnabledDefault(getter) {
        this._enabledDefault = getter;
    }
    /**
     * Get or create the reactive state for a notebook panel.
     */
    getOrCreateState(panel) {
        let state = this._states.get(panel);
        if (!state) {
            state = new ReactiveNotebookState(panel, this._enabledDefault());
            this._states.set(panel, state);
            // Clean up when the panel is disposed.
            panel.disposed.connect(() => {
                const s = this._states.get(panel);
                if (s) {
                    s.dispose();
                    this._states.delete(panel);
                }
            });
        }
        return state;
    }
    /**
     * Get the reactive state for a notebook model, if it exists.
     */
    getStateByModel(model) {
        for (const [panel, state] of this._states) {
            if (panel.context.model === model) {
                return state;
            }
        }
        return null;
    }
    /**
     * Find a Cell widget by its ID in a notebook panel.
     */
    findCellWidget(panel, cellId) {
        for (const cell of panel.content.widgets) {
            if (cell.model.sharedModel.getId() === cellId) {
                return cell;
            }
        }
        return null;
    }
}


/***/ },

/***/ "./lib/ui/dependencyIndicators.js"
/*!****************************************!*\
  !*** ./lib/ui/dependencyIndicators.js ***!
  \****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   clearDependencyIndicators: () => (/* binding */ clearDependencyIndicators),
/* harmony export */   updateDependencyIndicators: () => (/* binding */ updateDependencyIndicators)
/* harmony export */ });
// Copyright (c) Orange Bricks
// Distributed under the terms of the MIT License.
/**
 * CSS class names for dependency indicators.
 */
const UPSTREAM_CLASS = 'jp-reactive-upstream';
const DOWNSTREAM_CLASS = 'jp-reactive-downstream';
const STALE_CLASS = 'jp-reactive-stale';
const CONFLICT_CLASS = 'jp-reactive-conflict';
const CYCLE_CLASS = 'jp-reactive-cycle';
const REACTIVE_ENABLED_CLASS = 'jp-reactive-enabled';
/**
 * All reactive CSS classes for easy removal.
 */
const ALL_CLASSES = [
    UPSTREAM_CLASS,
    DOWNSTREAM_CLASS,
    STALE_CLASS,
    CONFLICT_CLASS,
    CYCLE_CLASS
];
/**
 * Update dependency indicators on all cells in a notebook.
 *
 * This reads the current graph from the reactive state and applies
 * appropriate CSS classes to each cell widget.
 */
function updateDependencyIndicators(panel, state) {
    const notebook = panel.content;
    const graph = state.graph;
    // Toggle the notebook-level class.
    if (state.enabled) {
        notebook.node.classList.add(REACTIVE_ENABLED_CLASS);
    }
    else {
        notebook.node.classList.remove(REACTIVE_ENABLED_CLASS);
    }
    for (const cell of notebook.widgets) {
        // Clear all reactive classes first.
        for (const cls of ALL_CLASSES) {
            cell.node.classList.remove(cls);
        }
        // Remove tooltip.
        cell.node.removeAttribute('title');
        if (!state.enabled || !graph || cell.model.type !== 'code') {
            continue;
        }
        const cellId = cell.model.sharedModel.getId();
        const analysis = graph.cells.get(cellId);
        if (!analysis) {
            continue;
        }
        // Check if this cell has downstream dependents (upstream provider).
        const downstream = graph.downstreamEdges.get(cellId);
        if (downstream && downstream.size > 0) {
            cell.node.classList.add(UPSTREAM_CLASS);
        }
        // Check if this cell depends on other cells (downstream consumer).
        const upstream = graph.upstreamEdges.get(cellId);
        if (upstream && upstream.size > 0) {
            cell.node.classList.add(DOWNSTREAM_CLASS);
        }
        // Check if this cell is stale.
        if (state.staleCells.has(cellId)) {
            cell.node.classList.add(STALE_CLASS);
        }
        // Check if this cell has variable conflicts.
        if (state.conflictCells.has(cellId)) {
            cell.node.classList.add(CONFLICT_CLASS);
        }
        // Check if this cell is in a dependency cycle.
        if (state.cycleCells.has(cellId)) {
            cell.node.classList.add(CYCLE_CLASS);
        }
        // Build tooltip.
        const tooltip = buildTooltip(cell, analysis, graph, state);
        if (tooltip) {
            cell.node.title = tooltip;
        }
    }
}
/**
 * Clear all dependency indicators from a notebook.
 */
function clearDependencyIndicators(panel) {
    const notebook = panel.content;
    notebook.node.classList.remove(REACTIVE_ENABLED_CLASS);
    for (const cell of notebook.widgets) {
        for (const cls of ALL_CLASSES) {
            cell.node.classList.remove(cls);
        }
        cell.node.removeAttribute('title');
    }
}
/**
 * Build a tooltip string for a cell.
 */
function buildTooltip(_cell, analysis, graph, state) {
    const parts = [];
    const cellId = _cell.model.sharedModel.getId();
    if (analysis.defines.size > 0) {
        parts.push(`Defines: ${[...analysis.defines].join(', ')}`);
    }
    if (analysis.references.size > 0) {
        parts.push(`References: ${[...analysis.references].join(', ')}`);
    }
    const downstream = graph.downstreamEdges.get(cellId);
    if (downstream && downstream.size > 0) {
        parts.push(`${downstream.size} dependent cell(s)`);
    }
    const upstream = graph.upstreamEdges.get(cellId);
    if (upstream && upstream.size > 0) {
        parts.push(`Depends on ${upstream.size} cell(s)`);
    }
    if (state.staleCells.has(cellId)) {
        parts.push('\u26A0 Stale: upstream changed, needs re-execution');
    }
    if (state.conflictCells.has(cellId)) {
        const conflictVars = state.conflicts
            .filter(c => c.cellIds.includes(cellId))
            .map(c => c.variable);
        parts.push(`\u26A0 Conflict: "${conflictVars.join('", "')}" defined in multiple cells`);
    }
    if (state.cycleCells.has(cellId)) {
        parts.push('\u26A0 Cycle: this cell is part of a dependency cycle');
    }
    return parts.join('\n');
}


/***/ },

/***/ "./lib/ui/toggleButton.js"
/*!********************************!*\
  !*** ./lib/ui/toggleButton.js ***!
  \********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TOGGLE_COMMAND: () => (/* binding */ TOGGLE_COMMAND),
/* harmony export */   addToolbarButton: () => (/* binding */ addToolbarButton),
/* harmony export */   registerToggleCommand: () => (/* binding */ registerToggleCommand)
/* harmony export */ });
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);
// Copyright (c) Orange Bricks
// Distributed under the terms of the MIT License.


/**
 * Command ID for toggling reactivity.
 */
const TOGGLE_COMMAND = 'ripple:toggle';
/**
 * Register the toggle command and add a toolbar button to notebooks.
 */
function registerToggleCommand(app, tracker, stateManager, translator) {
    const trans = (translator !== null && translator !== void 0 ? translator : _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_0__.nullTranslator).load('jupyterlab');
    app.commands.addCommand(TOGGLE_COMMAND, {
        label: trans.__('Toggle Reactive Mode'),
        caption: trans.__('Enable/disable automatic re-execution of dependent cells'),
        isToggled: () => {
            const panel = tracker.currentWidget;
            if (!panel) {
                return false;
            }
            const state = stateManager.getOrCreateState(panel);
            return state.enabled;
        },
        isEnabled: () => {
            return tracker.currentWidget !== null;
        },
        execute: async () => {
            const panel = tracker.currentWidget;
            if (!panel) {
                return;
            }
            const state = stateManager.getOrCreateState(panel);
            await state.toggle();
        }
    });
}
/**
 * Add the reactive toggle widget to a notebook panel's toolbar, to the right
 * of the spacer (i.e. next to the kernel name indicator).
 */
function addToolbarButton(panel, app, state) {
    const widget = new ReactiveToggleWidget(app, state);
    // Insert before kernelName so it sits just to the left of the kernel name.
    panel.toolbar.insertBefore('kernelName', 'reactiveToggle', widget);
}
/**
 * A compact button with a visual checkbox indicator that reflects and toggles
 * reactive mode. Using a single <button> avoids the native <input> double-click
 * issue where clicking the checkbox directly could desync visual state.
 */
class ReactiveToggleWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Widget {
    constructor(app, state) {
        super();
        this._app = app;
        this._state = state;
        this.addClass('jp-reactive-toggle-widget');
        this._button = document.createElement('button');
        this._button.className = 'jp-reactive-toggle-btn';
        this._button.title = 'Toggle reactive auto-execution of dependent cells';
        this._button.type = 'button';
        // Visual-only checkbox: pointer-events none so the button handles all clicks.
        this._checkbox = document.createElement('input');
        this._checkbox.type = 'checkbox';
        this._checkbox.className = 'jp-reactive-checkbox';
        this._checkbox.tabIndex = -1;
        this._checkbox.checked = state.enabled;
        const text = document.createElement('span');
        text.className = 'jp-reactive-text';
        text.textContent = 'Reactive';
        this._button.appendChild(this._checkbox);
        this._button.appendChild(text);
        this.node.appendChild(this._button);
        this._button.addEventListener('click', () => {
            void this._app.commands.execute(TOGGLE_COMMAND);
        });
        state.stateChanged.connect(this._onStateChanged, this);
    }
    dispose() {
        this._state.stateChanged.disconnect(this._onStateChanged, this);
        super.dispose();
    }
    _onStateChanged() {
        this._checkbox.checked = this._state.enabled;
    }
}


/***/ }

}]);
//# sourceMappingURL=lib_index_js.3a098d8470c85f554b9c.js.map