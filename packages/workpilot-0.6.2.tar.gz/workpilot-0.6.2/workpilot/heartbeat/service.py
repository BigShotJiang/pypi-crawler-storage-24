"""
Heartbeat service — proactive periodic checks that fire callbacks.

Register named checks with an interval and a callable.  The service runs
each check on its own schedule and invokes a callback when the check
function returns a truthy value (i.e. the condition is met).
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from loguru import logger

# ---------------------------------------------------------------------------
# Internal check representation
# ---------------------------------------------------------------------------

CheckFn = Callable[[], Awaitable[Any]]
"""Async callable that inspects some condition.  Return truthy to trigger."""

CallbackFn = Callable[[str, Any], Awaitable[None]]
"""Async callback invoked when a check fires: (check_name, result)."""


@dataclass
class _HeartbeatCheck:
    """Internal bookkeeping for a registered check."""

    name: str
    interval_seconds: int
    check_fn: CheckFn
    callback: CallbackFn | None = None
    _task: asyncio.Task[None] | None = field(default=None, repr=False)


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


class HeartbeatService:
    """Run periodic health/condition checks and fire callbacks.

    Usage::

        hb = HeartbeatService(config={})

        async def my_check():
            return some_condition_met()

        async def on_trigger(name, result):
            print(f"Check {name} fired with {result}")

        hb.register_check("inbox", interval_seconds=60, check_fn=my_check, callback=on_trigger)
        await hb.start()
        ...
        await hb.stop()
    """

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self._config = config or {}
        self._checks: dict[str, _HeartbeatCheck] = {}
        self._running = False
        self._default_callback: CallbackFn | None = None

    # ── registration ─────────────────────────────────────────────────────

    def register_check(
        self,
        name: str,
        interval_seconds: int,
        check_fn: CheckFn,
        callback: CallbackFn | None = None,
    ) -> None:
        """Register a named periodic check.

        Parameters
        ----------
        name:
            Unique identifier for this check.
        interval_seconds:
            How often (in seconds) to run the check.
        check_fn:
            Async callable that returns a truthy value when the condition
            is met.
        callback:
            Optional async callback ``(name, result)`` invoked when
            *check_fn* returns truthy.  Falls back to the default callback
            set on the service.
        """
        if interval_seconds <= 0:
            raise ValueError(f"interval_seconds must be positive, got {interval_seconds}")

        self._checks[name] = _HeartbeatCheck(
            name=name,
            interval_seconds=interval_seconds,
            check_fn=check_fn,
            callback=callback,
        )
        logger.info(
            "Registered heartbeat check '{}' (every {}s)",
            name,
            interval_seconds,
        )

        # If already running, start the check loop immediately
        if self._running:
            check = self._checks[name]
            check._task = asyncio.create_task(
                self._run_check_loop(check),
                name=f"heartbeat-{name}",
            )

    def set_default_callback(self, callback: CallbackFn) -> None:
        """Set a fallback callback for checks that have no explicit one."""
        self._default_callback = callback

    def unregister_check(self, name: str) -> None:
        """Remove a check by name and cancel its loop if running."""
        check = self._checks.pop(name, None)
        if check is not None and check._task is not None:
            check._task.cancel()
            logger.info("Unregistered heartbeat check '{}'", name)

    # ── lifecycle ────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start all registered check loops."""
        if self._running:
            logger.warning("Heartbeat service already running")
            return

        self._running = True

        for check in self._checks.values():
            check._task = asyncio.create_task(
                self._run_check_loop(check),
                name=f"heartbeat-{check.name}",
            )

        logger.info(
            "Heartbeat service started with {} check(s)",
            len(self._checks),
        )

    async def stop(self) -> None:
        """Cancel all running check loops and wait for them to finish."""
        if not self._running:
            return

        self._running = False

        tasks: list[asyncio.Task[None]] = []
        for check in self._checks.values():
            if check._task is not None:
                check._task.cancel()
                tasks.append(check._task)
                check._task = None

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        logger.info("Heartbeat service stopped")

    # ── internals ────────────────────────────────────────────────────────

    async def _run_check_loop(self, check: _HeartbeatCheck) -> None:
        """Run a single check in a loop until cancelled."""
        logger.debug(
            "Heartbeat loop started for '{}' (every {}s)",
            check.name,
            check.interval_seconds,
        )
        try:
            while self._running:
                await asyncio.sleep(check.interval_seconds)
                if not self._running:
                    break
                try:
                    result = await check.check_fn()
                except Exception as exc:
                    logger.error("Heartbeat check '{}' raised: {}", check.name, exc)
                    continue

                if result:
                    logger.info("Heartbeat check '{}' triggered (result={})", check.name, result)
                    callback = check.callback or self._default_callback
                    if callback is not None:
                        try:
                            await callback(check.name, result)
                        except Exception as exc:
                            logger.error(
                                "Heartbeat callback for '{}' raised: {}",
                                check.name,
                                exc,
                            )
        except asyncio.CancelledError:
            logger.debug("Heartbeat loop for '{}' cancelled", check.name)
