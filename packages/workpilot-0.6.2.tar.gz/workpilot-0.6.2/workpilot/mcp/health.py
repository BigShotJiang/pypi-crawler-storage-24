"""MCP health monitor — periodic ping and auto-reconnect with backoff."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from loguru import logger

from workpilot.mcp.types import ConnectionState

if TYPE_CHECKING:
    from workpilot.mcp.manager import MCPManager


class MCPHealthMonitor:
    """Monitors MCP server connections and auto-reconnects on failure."""

    def __init__(
        self,
        manager: MCPManager,
        *,
        default_interval: int = 60,
        agency_interval: int = 120,
        max_reconnect_attempts: int = 5,
        backoff_base: float = 2.0,
        ping_timeout: float = 10.0,
    ) -> None:
        self._manager = manager
        self._default_interval = default_interval
        self._agency_interval = agency_interval
        self._max_reconnect_attempts = max_reconnect_attempts
        self._backoff_base = backoff_base
        self._ping_timeout = ping_timeout
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._reconnect_attempts: dict[str, int] = {}

    async def start_monitoring(self, name: str) -> None:
        """Start health monitoring for a connected server."""
        existing = self._tasks.get(name)
        if existing is not None and not existing.done():
            return
        # Clean up stale (done/failed) task before restarting
        self._tasks.pop(name, None)
        self._reconnect_attempts[name] = 0
        task = asyncio.create_task(self._monitor_loop(name))
        self._tasks[name] = task
        logger.debug(f"Health monitor started for '{name}'")

    def stop_monitoring(self, name: str) -> None:
        """Stop health monitoring for a server."""
        task = self._tasks.pop(name, None)
        if task and not task.done():
            task.cancel()
        self._reconnect_attempts.pop(name, None)

    def stop_all(self) -> None:
        """Stop all health monitors."""
        for name in list(self._tasks):
            self.stop_monitoring(name)

    async def check_server(self, name: str) -> bool:
        """Ping a server. Returns True if healthy."""
        client = self._manager._clients.get(name)
        if client is None or not client.is_connected:
            return False
        try:
            await asyncio.wait_for(client.list_tools(), timeout=self._ping_timeout)
            return True
        except Exception:
            return False

    async def _monitor_loop(self, name: str) -> None:
        """Background loop: periodically check server health."""
        config = self._manager._configs.get(name)
        interval = (
            self._agency_interval if (config and config.is_agency) else self._default_interval
        )

        try:
            while True:
                await asyncio.sleep(interval)

                if self._manager._states.get(name) != ConnectionState.CONNECTED:
                    break

                healthy = await self.check_server(name)
                if healthy:
                    self._reconnect_attempts[name] = 0
                    continue

                # Server failed — attempt reconnect
                logger.warning(f"MCP health check failed for '{name}', attempting reconnect")
                self._manager._states[name] = ConnectionState.RECONNECTING
                success = await self._reconnect(name)
                if not success:
                    self._manager._states[name] = ConnectionState.FAILED
                    logger.error(
                        f"MCP server '{name}' failed after {self._max_reconnect_attempts} reconnect attempts"
                    )
                    break
        except asyncio.CancelledError:
            pass

    async def _reconnect(self, name: str) -> bool:
        """Attempt reconnection with exponential backoff."""
        for attempt in range(self._max_reconnect_attempts):
            delay = self._backoff_base**attempt
            logger.info(
                f"MCP reconnect '{name}': attempt {attempt + 1}/{self._max_reconnect_attempts}, waiting {delay:.1f}s"
            )
            await asyncio.sleep(delay)

            try:
                await self._manager.connect_server(name, force=True)
                if self._manager._states.get(name) == ConnectionState.CONNECTED:
                    logger.info(f"MCP server '{name}' reconnected (attempt {attempt + 1})")
                    self._reconnect_attempts[name] = 0
                    return True
            except Exception as exc:
                logger.warning(f"MCP reconnect '{name}' attempt {attempt + 1} failed: {exc}")

        return False
