"""
MCP tool adapter — wraps external MCP tool descriptors as Tool ABC instances.

Each MCPToolAdapter adapts an MCP tool descriptor (from ``MCPClient.list_tools()``)
into a ``Tool`` that can be registered in the agent's ``ToolRegistry`` and used
by the LLM for function calling.

MCP tools are untrusted by default (``approval: "auto"``).
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from typing import Any

from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.agent.tools.registry import PROTECTED_TOOLS, ToolRegistry
from workpilot.mcp.client import MCPClient


class MCPToolAdapter(Tool):
    """Adapts an MCP tool descriptor into the WorkPilot Tool ABC.

    Args:
        descriptor: MCP tool descriptor dict with ``name``, ``description``,
            and ``inputSchema`` keys (as returned by ``MCPClient.list_tools()``).
        mcp_client: The connected ``MCPClient`` used to invoke the tool.
        approval: Approval level for this tool (default ``"auto"``).
        server_name: Server namespace prefix. If set, the tool is registered
            as ``MCP_{server_name}_{tool_name}`` and described with ``[MCP:{server_name}]``.
        timeout: Per-server timeout override (seconds).
        risk_level: Per-server risk level override.
    """

    def __init__(
        self,
        descriptor: dict[str, Any],
        mcp_client: MCPClient,
        approval: str = "auto",
        *,
        server_name: str | None = None,
        timeout: int = 30,
        risk_level: str = "medium",
        streaming: bool = False,
    ) -> None:
        self._descriptor = descriptor
        self._mcp_client = mcp_client
        self._raw_tool_name: str = descriptor.get("name", "")
        self._server_name = server_name
        self._tool_name: str = (
            f"MCP_{server_name}_{self._raw_tool_name}" if server_name else self._raw_tool_name
        )
        raw_desc: str = descriptor.get("description", "")
        self._tool_description: str = f"[MCP:{server_name}] {raw_desc}" if server_name else raw_desc
        self._approval: str = approval
        self._timeout: int = timeout
        self._risk_level: str = risk_level
        self._streaming: bool = streaming
        self._input_schema: dict[str, Any] = descriptor.get(
            "inputSchema",
            {
                "type": "object",
                "properties": {},
            },
        )

    @property
    def name(self) -> str:
        return self._tool_name

    @property
    def description(self) -> str:
        return self._tool_description

    @property
    def parameters(self) -> dict[str, Any]:
        return self._input_schema

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(
            risk_level=self._risk_level,
            isolation="process",
            category="mcp",
            approval=self._approval,
            timeout=self._timeout,
            streaming=self._streaming,
        )

    def validate(self, args: dict[str, Any]) -> list[str]:
        """Basic validation — check required fields from input schema."""
        errors: list[str] = []
        required = self._input_schema.get("required", [])
        for field in required:
            if field not in args:
                errors.append(f"Missing required parameter: {field}")
        return errors

    async def execute(self, **kwargs: Any) -> str:
        """Execute the tool via the MCP client."""
        if not self._mcp_client.is_connected:
            return f"MCP server '{self._mcp_client.name}' is disconnected. Tool unavailable."
        try:
            # Use raw (un-prefixed) name for the actual MCP call
            return await self._mcp_client.call_tool(self._raw_tool_name, kwargs)
        except ConnectionError as exc:
            logger.warning(f"MCP tool '{self._tool_name}' connection lost: {exc}")
            try:
                await self._mcp_client.disconnect()
            except Exception:
                pass
            return (
                f"MCP tool '{self._tool_name}' failed: {exc}. "
                f"The MCP server '{self._mcp_client.name}' has been disconnected."
            )
        except (RuntimeError, TimeoutError) as exc:
            logger.warning(f"MCP tool '{self._tool_name}' execution failed: {exc}")
            return f"MCP tool '{self._tool_name}' failed: {exc}."

    async def execute_streaming(self, **kwargs: Any) -> AsyncGenerator[str, None]:
        """Stream tool results. Falls back to single-chunk if server doesn't support streaming."""
        if not self._mcp_client.is_connected:
            yield f"MCP server '{self._mcp_client.name}' is disconnected. Tool unavailable."
            return
        try:
            async for chunk in self._mcp_client.call_tool_streaming(self._raw_tool_name, kwargs):
                yield chunk
        except (ConnectionError, RuntimeError, TimeoutError) as exc:
            yield f"MCP tool '{self._tool_name}' failed: {exc}."


AGENCY_DEFAULTS: dict[str, int | str] = {
    "timeout": 120,
    "risk_level": "medium",
    "approval": "auto",
}

STANDARD_DEFAULTS: dict[str, int | str] = {
    "timeout": 60,
    "risk_level": "medium",
    "approval": "auto",
}

_APPROVAL_SEVERITY = {"never": 0, "auto": 1, "always": 2}


def resolve_approval(server_approval: str | None, security_profile: str | None) -> str:
    """Resolve effective approval — server config can only tighten, never relax."""
    profile_approval = {
        "open": "never",
        "standard": "auto",
        "controlled": "auto",
        "restricted": "always",
    }.get(security_profile or "standard", "auto")

    if server_approval is None:
        return profile_approval

    if _APPROVAL_SEVERITY.get(server_approval, 1) >= _APPROVAL_SEVERITY[profile_approval]:
        return server_approval
    return profile_approval


def _resolve_server_config(
    server_config: Any | None,
    security_profile: str | None,
) -> tuple[str, int, str]:
    """Resolve (approval, timeout, risk_level) from server config + profile."""
    if server_config is not None and hasattr(server_config, "is_agency"):
        defaults = AGENCY_DEFAULTS if server_config.is_agency else STANDARD_DEFAULTS
        timeout = int(server_config.timeout or defaults["timeout"])
        risk_level = str(server_config.risk_level or defaults["risk_level"])
        approval = resolve_approval(server_config.approval, security_profile)
    else:
        timeout = int(STANDARD_DEFAULTS["timeout"])
        risk_level = str(STANDARD_DEFAULTS["risk_level"])
        approval = resolve_approval(None, security_profile)
    return approval, timeout, risk_level


async def register_mcp_tools(
    registry: ToolRegistry,
    mcp_client: MCPClient,
    *,
    security_profile: str | None = None,
    server_name: str | None = None,
    server_config: Any | None = None,
) -> list[str]:
    """Discover tools from an MCP server and register them in the ToolRegistry.

    When *server_name* is provided, tools are registered with namespace prefix
    (e.g. ``MCP_icm_get_incident``). Without it, tools keep their original names
    (backward-compatible).

    Args:
        registry: The agent's tool registry.
        mcp_client: A connected ``MCPClient``.
        security_profile: Security profile name for approval resolution.
        server_name: Namespace prefix for tool names (e.g. ``"icm"``).
        server_config: ``MCPServerConfig`` for per-server overrides.

    Returns:
        List of registered tool names (namespaced if server_name provided).
    """
    approval, timeout, risk_level = _resolve_server_config(server_config, security_profile)

    try:
        descriptors = await mcp_client.list_tools()
    except Exception as exc:
        logger.warning(f"MCP server '{mcp_client.name}': failed to list tools: {exc}")
        return []

    registered: list[str] = []
    for descriptor in descriptors:
        raw_name = descriptor.get("name", "")
        if not raw_name:
            logger.warning(f"MCP server '{mcp_client.name}': skipping tool with empty name")
            continue

        # Compute the name that will be registered
        reg_name = f"MCP_{server_name}_{raw_name}" if server_name else raw_name

        # Anti-shadowing: only relevant for un-namespaced tools
        if not server_name and raw_name in PROTECTED_TOOLS:
            logger.warning(
                f"MCP server '{mcp_client.name}': skipping tool '{raw_name}' "
                f"— name conflicts with protected built-in tool"
            )
            continue

        if registry.get(reg_name) is not None:
            logger.warning(
                f"MCP server '{mcp_client.name}': skipping tool '{reg_name}' "
                f"— namespace collision with already-registered tool"
            )
            continue

        adapter = MCPToolAdapter(
            descriptor,
            mcp_client,
            approval=approval,
            server_name=server_name,
            timeout=timeout,
            risk_level=risk_level,
        )
        try:
            registry.register(adapter)
            registered.append(reg_name)
        except ValueError as exc:
            logger.warning(
                f"MCP server '{mcp_client.name}': failed to register tool '{reg_name}': {exc}"
            )

    logger.info(
        f"MCP server '{mcp_client.name}': registered {len(registered)}/{len(descriptors)} tools"
    )
    return registered
