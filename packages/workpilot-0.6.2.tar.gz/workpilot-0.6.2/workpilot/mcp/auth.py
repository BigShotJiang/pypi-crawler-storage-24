"""MCP auth — Agency CLI detection, auth status check, HTTP auth resolution."""

from __future__ import annotations

import os
import shutil
from typing import TYPE_CHECKING

import httpx
from loguru import logger

if TYPE_CHECKING:
    from workpilot.config.schema import MCPAuthConfig, MCPServerConfig, ProvidersConfig


async def pre_connect_agency_check() -> tuple[bool, str]:
    """Check Agency CLI availability.

    Returns (ok, message). Called automatically when connecting
    any server where ``config.is_agency`` is True.

    Note: Agency CLI does not expose an auth status subcommand.
    EntraID auth is handled interactively by Agency when the MCP
    server is first used.
    """
    agency_bin = shutil.which("agency")
    if not agency_bin:
        return False, (
            "Agency CLI not found. Install via:\n"
            "  workpilot mcp add-agency\n"
            'Or manually: iex "& { $(irm aka.ms/InstallTool.ps1)} agency"'
        )
    return True, f"Agency CLI found: {agency_bin}"


async def resolve_auth_headers(
    config: MCPServerConfig,
    providers: ProvidersConfig | None = None,
) -> dict[str, str]:
    """Resolve auth headers for HTTP transport.

    Stdio servers (including Agency) handle auth internally — returns empty dict.

    Args:
        config: MCP server config.
        providers: Provider config, required when auth.type == 'github_copilot'.

    Returns:
        Dict of HTTP headers to pass to the transport.

    Raises:
        RuntimeError: If auth.type is 'github_copilot' and no token is available.
            Unlike bearer/oauth (which fall back to empty headers), github_copilot
            requires a valid token — the MCP server will be skipped on failure.
    """
    # Stdio transport — auth handled by subprocess
    if config.command is not None:
        return {}

    match config.auth.type:
        case "none":
            return {}
        case "bearer":
            token = _resolve_bearer_token(config.auth)
            if token:
                return {"Authorization": f"Bearer {token}"}
            logger.warning("MCP auth: bearer token not found (check token or token_env)")
            return {}
        case "github_copilot":
            token = _resolve_github_copilot_token(config.auth, providers)
            if token:
                return {"Authorization": f"Bearer {token}"}
            raise RuntimeError(
                "github_copilot auth requires a token — "
                "set providers.github_copilot.token or GITHUB_TOKEN"
            )
        case "oauth":
            token = await _oauth_client_credentials(config.auth)
            if token:
                return {"Authorization": f"Bearer {token}"}
            logger.warning("MCP auth: OAuth token exchange failed")
            return {}
        case _:
            logger.warning(f"MCP auth: unknown type '{config.auth.type}'")
            return {}


def _resolve_bearer_token(auth: MCPAuthConfig) -> str | None:
    """Resolve bearer token from config or environment."""
    if auth.token is not None:
        return auth.token.get_secret_value()
    if auth.token_env:
        return os.environ.get(auth.token_env)
    return None


def _resolve_github_copilot_token(
    auth: MCPAuthConfig,
    providers: ProvidersConfig | None,
) -> str | None:
    """Resolve GitHub OAuth token for the github_copilot auth type.

    Priority:
      1. providers.github_copilot.token (config file)
      2. auth.token_env / auth.token (explicit override on the MCP entry)
      3. GITHUB_TOKEN environment variable
    """
    if providers is not None:
        token_secret = providers.github_copilot.token
        if token_secret is not None:
            value: str = token_secret.get_secret_value()
            if value:
                return value
    # Fallback: explicit override on the MCP entry, then env
    return _resolve_bearer_token(auth) or os.environ.get("GITHUB_TOKEN")


async def _oauth_client_credentials(auth: MCPAuthConfig) -> str | None:
    """Exchange client credentials for an OAuth2 access token.

    Uses the standard OAuth2 client_credentials grant type.
    Requires ``client_id``, ``client_secret``, and at least one scope.
    Token endpoint is always ``https://login.microsoftonline.com/common/oauth2/v2.0/token``.
    """
    if not auth.client_id or not auth.client_secret:
        logger.warning("MCP OAuth: client_id and client_secret are required")
        return None

    scopes = auth.scopes or []
    scope_str = " ".join(scopes) if scopes else ""

    # Default Azure AD token endpoint (common tenant)
    token_url = "https://login.microsoftonline.com/common/oauth2/v2.0/token"

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": auth.client_id,
                    "client_secret": auth.client_secret.get_secret_value(),
                    "scope": scope_str,
                },
            )
            response.raise_for_status()
            data = response.json()
            access_token: str | None = data.get("access_token")
            if access_token:
                logger.debug("MCP OAuth: token obtained successfully")
            return access_token
    except httpx.HTTPError as exc:
        logger.warning(f"MCP OAuth token exchange failed: {exc}")
        return None
    except Exception as exc:
        logger.warning(f"MCP OAuth unexpected error: {exc}")
        return None
