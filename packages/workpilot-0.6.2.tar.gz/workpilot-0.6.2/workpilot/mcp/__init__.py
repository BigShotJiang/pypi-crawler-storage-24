"""
MCP (Model Context Protocol) integration for WorkPilot.

Provides client and server implementations for MCP, enabling WorkPilot to:
- **Client**: connect to external MCP servers and use their tools
- **Server**: expose WorkPilot tools to external MCP clients

Both transports (stdio subprocess and HTTP/SSE) are supported via
the pluggable transport layer in ``workpilot.mcp.transport``.
"""

from workpilot.mcp.adapter import MCPToolAdapter, register_mcp_tools, resolve_approval
from workpilot.mcp.client import MCPClient
from workpilot.mcp.health import MCPHealthMonitor
from workpilot.mcp.manager import MCPManager
from workpilot.mcp.types import ConnectionState, MCPCapabilities, ServerInfo

__all__ = [
    "ConnectionState",
    "MCPCapabilities",
    "MCPClient",
    "MCPHealthMonitor",
    "MCPManager",
    "MCPToolAdapter",
    "ServerInfo",
    "register_mcp_tools",
    "resolve_approval",
]
