"""
Entra ID (Azure AD) OAuth 2.0 authentication for Microsoft Graph.

Supports three authentication flows:
- Client credentials (service-to-service, no user context)
- Device code (interactive, user-delegated)
- Managed identity (Azure-hosted workloads)

Uses the ``msal`` library (imported lazily so the package remains
optional at install time).
"""

from __future__ import annotations

import time
from typing import Any

from loguru import logger

from workpilot.config.schema import GraphAuthConfig


class GraphAuthError(Exception):
    """Raised when Graph authentication fails."""


class GraphAuth:
    """Manages OAuth 2.0 tokens for the Microsoft Graph API."""

    def __init__(self, config: GraphAuthConfig) -> None:
        self._config = config
        self._token: str = ""
        self._token_expires: float = 0

    # ── public interface ────────────────────────────────────────────────

    @property
    def is_authenticated(self) -> bool:
        """Return *True* if a valid (non-expired) token is cached."""
        return bool(self._token) and time.time() < self._token_expires - 30

    async def get_token(self) -> str:
        """Return a valid access token, refreshing if necessary."""
        if self.is_authenticated:
            return self._token

        if self._config.use_managed_identity:
            return await self._acquire_managed_identity()
        if self._config.use_device_code:
            return await self._acquire_device_code()
        return await self._acquire_client_credentials()

    # ── private flows ───────────────────────────────────────────────────

    async def _acquire_client_credentials(self) -> str:
        """Client credentials flow (application-only, no user context)."""
        msal = _import_msal()

        client_id = self._config.client_id
        client_secret = self._config.client_secret
        tenant_id = self._config.tenant_id

        if not client_id or not client_secret or not tenant_id:
            raise GraphAuthError(
                "client_id, client_secret, and tenant_id are required "
                "for the client credentials flow"
            )

        app = msal.ConfidentialClientApplication(
            client_id=client_id.get_secret_value(),
            client_credential=client_secret.get_secret_value(),
            authority=f"https://login.microsoftonline.com/{tenant_id}",
        )

        # Client credentials flow always uses .default scope
        result: dict[str, Any] | None = app.acquire_token_for_client(
            scopes=["https://graph.microsoft.com/.default"],
        )

        return self._handle_msal_result(result, "client_credentials")

    async def _acquire_device_code(self) -> str:
        """Device code flow (interactive, user-delegated permissions)."""
        msal = _import_msal()

        client_id = self._config.client_id
        tenant_id = self._config.tenant_id

        if not client_id or not tenant_id:
            raise GraphAuthError("client_id and tenant_id are required for the device code flow")

        app = msal.PublicClientApplication(
            client_id=client_id.get_secret_value(),
            authority=f"https://login.microsoftonline.com/{tenant_id}",
        )

        scopes = self._config.scopes

        # Try cached accounts first
        accounts = app.get_accounts()
        if accounts:
            result = app.acquire_token_silent(scopes, account=accounts[0])
            if result and "access_token" in result:
                return self._handle_msal_result(result, "device_code_silent")

        # Initiate device code flow
        flow = app.initiate_device_flow(scopes=scopes)
        if "user_code" not in flow:
            raise GraphAuthError(
                f"Failed to initiate device code flow: {flow.get('error_description', 'unknown error')}"
            )

        logger.info(
            "Device code auth: visit {url} and enter code {code}",
            url=flow["verification_uri"],
            code=flow["user_code"],
        )

        result = app.acquire_token_by_device_flow(flow)
        return self._handle_msal_result(result, "device_code")

    async def _acquire_managed_identity(self) -> str:
        """Managed identity flow (Azure-hosted workloads only)."""
        msal = _import_msal()

        app = msal.ManagedIdentityClient(
            msal.UserAssignedManagedIdentity(client_id=self._config.client_id.get_secret_value())
            if self._config.client_id
            else msal.SystemAssignedManagedIdentity(),
        )

        result = app.acquire_token_for_client(
            resource="https://graph.microsoft.com",
        )
        return self._handle_msal_result(result, "managed_identity")

    # ── helpers ─────────────────────────────────────────────────────────

    def _handle_msal_result(
        self,
        result: dict[str, Any] | None,
        flow_name: str,
    ) -> str:
        """Extract the access token from an MSAL result or raise."""
        if not result or "access_token" not in result:
            error = (result or {}).get("error_description", "unknown error")
            raise GraphAuthError(f"{flow_name} flow failed: {error}")

        self._token = result["access_token"]
        self._token_expires = time.time() + result.get("expires_in", 3600)
        logger.debug("Graph token acquired via {} flow", flow_name)
        return self._token


def _import_msal() -> Any:
    """Lazily import ``msal``, raising a friendly error if missing."""
    try:
        import msal  # type: ignore[import-untyped]

        return msal
    except ImportError:
        raise ImportError(
            "The 'msal' package is required for Microsoft Graph auth. "
            "Install it with: pip install msal"
        ) from None
