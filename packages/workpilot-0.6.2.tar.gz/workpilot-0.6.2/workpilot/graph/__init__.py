"""
Microsoft Graph integration layer — Entra ID auth, mail, Teams.

Provides a unified Graph API client with OAuth 2.0 authentication
and typed wrappers for mail and Teams operations.
"""

from __future__ import annotations

from workpilot.graph.auth import GraphAuth
from workpilot.graph.client import GraphClient
from workpilot.graph.mail import MailClient
from workpilot.graph.teams import TeamsGraphClient

__all__ = [
    "GraphAuth",
    "GraphClient",
    "MailClient",
    "TeamsGraphClient",
]
