"""
Base Microsoft Graph API client — thin async wrapper around httpx.

All Graph domain clients (mail, teams, etc.) compose over this class
to make authenticated requests against ``https://graph.microsoft.com/v1.0``.
"""

from __future__ import annotations

from typing import Any

import httpx
from loguru import logger

from workpilot.graph.auth import GraphAuth

GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"


class GraphAPIError(Exception):
    """Raised when the Graph API returns an error response."""

    def __init__(self, status_code: int, message: str, error_code: str | None = None) -> None:
        self.status_code = status_code
        self.error_code = error_code
        super().__init__(f"Graph API {status_code}: {message}")


class GraphClient:
    """Low-level async client for the Microsoft Graph REST API."""

    def __init__(
        self,
        auth: GraphAuth,
        *,
        base_url: str = GRAPH_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        self._auth = auth
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

    # ── HTTP verbs ──────────────────────────────────────────────────────

    async def get(
        self,
        endpoint: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send an authenticated GET request."""
        return await self._request("GET", endpoint, params=params)

    async def post(
        self,
        endpoint: str,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        """Send an authenticated POST request."""
        return await self._request("POST", endpoint, json_body=data)

    async def patch(
        self,
        endpoint: str,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        """Send an authenticated PATCH request."""
        return await self._request("PATCH", endpoint, json_body=data)

    async def delete(self, endpoint: str) -> None:
        """Send an authenticated DELETE request."""
        await self._request("DELETE", endpoint, expect_body=False)

    # ── internal ────────────────────────────────────────────────────────

    async def _request(
        self,
        method: str,
        endpoint: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        expect_body: bool = True,
    ) -> dict[str, Any]:
        """Build, send, and handle a Graph API request."""
        token = await self._auth.get_token()
        url = f"{self._base_url}/{endpoint.lstrip('/')}"

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                json=json_body,
            )

        if not resp.is_success:
            await self._raise_for_status(resp)

        if not expect_body or resp.status_code == 204:
            return {}

        return resp.json()  # type: ignore[no-any-return]

    @staticmethod
    async def _raise_for_status(resp: httpx.Response) -> None:
        """Parse Graph error payload and raise ``GraphAPIError``."""
        try:
            body = resp.json()
            error = body.get("error", {})
            message = error.get("message", resp.text)
            code = error.get("code")
        except Exception:
            message = resp.text
            code = None

        logger.error(
            "Graph API error {status}: {msg}",
            status=resp.status_code,
            msg=message,
        )
        raise GraphAPIError(resp.status_code, message, code)
