"""
Shell execution tool — sandboxed command runner with deny-pattern guards,
workspace restriction, output truncation, and timeout enforcement.
"""

from __future__ import annotations

import asyncio
import os
import platform
import shutil
from typing import Any

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.security.sandbox import CommandDeniedError, Sandbox

_IS_WINDOWS = platform.system() == "Windows"

# Shell executable resolution for each mode
_SHELL_EXECUTABLES: dict[str, list[str]] = {
    "bash": ["bash"],
    "cmd": ["cmd.exe"],
    "powershell": ["pwsh", "powershell"],
}


def _resolve_shell(mode: str) -> tuple[str | None, list[str]]:
    """Resolve shell executable and prefix args.

    Returns (executable, prefix_args). executable=None means use default
    (asyncio.create_subprocess_shell).

    Supports named modes (auto/bash/cmd/powershell) and arbitrary paths.
    """
    if mode == "auto":
        return None, []

    # Named modes
    candidates = _SHELL_EXECUTABLES.get(mode)
    if candidates:
        for candidate in candidates:
            path = shutil.which(candidate)
            if path:
                if mode == "cmd":
                    return path, ["/c"]
                if mode == "powershell":
                    return path, ["-NoProfile", "-Command"]
                return path, ["-c"]
        return None, []  # fallback to default

    # Arbitrary path (e.g. "/usr/bin/zsh", "C:\\cygwin\\bin\\sh.exe")
    resolved = shutil.which(mode)
    if resolved:
        return resolved, ["-c"]

    return None, []  # fallback to default


class ShellTool(Tool):
    """Execute shell commands within the workspace sandbox."""

    _MAX_BACKGROUND = 3

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox
        self._background: dict[int, asyncio.subprocess.Process] = {}  # pid → proc

    async def kill_all_background(self) -> int:
        """Kill all background processes. Called on E-stop or session end.

        Returns number of processes killed.
        """
        killed = 0
        for _pid, proc in list(self._background.items()):
            if proc.returncode is None:
                try:
                    proc.kill()
                    await asyncio.wait_for(proc.wait(), timeout=3)
                    killed += 1
                except (OSError, TimeoutError):
                    pass
        self._background.clear()
        return killed

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="medium", approval="auto", timeout=600, streaming=True)

    @property
    def name(self) -> str:
        return "shell"

    @property
    def description(self) -> str:
        return "Execute a shell command."

    @property
    def parameters(self) -> dict[str, Any]:
        default_shell = "cmd" if _IS_WINDOWS else "bash"
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The command to execute.",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds. 0 = background (return immediately). Default: 600.",
                },
                "directory": {
                    "type": "string",
                    "description": "Working directory (relative to workspace). Default: workspace root.",
                },
                "shell": {
                    "type": "string",
                    "description": f"Shell to use: auto (default, OS default = {default_shell}), bash, cmd, powershell, or a path.",
                },
            },
            "required": ["command"],
        }

    async def execute(self, **kwargs: Any) -> str:
        command: str = kwargs["command"]
        max_timeout = self.metadata.timeout  # 600s from ToolMetadata
        raw_timeout = kwargs.get("timeout")
        background = raw_timeout == 0
        timeout: float | None = (
            None
            if raw_timeout is None
            else (None if background else min(max(int(raw_timeout), 1), max_timeout))
        )
        if timeout is None and not background:
            timeout = max_timeout
        directory: str = kwargs.get("directory", "")
        shell_mode: str = kwargs.get("shell", "auto")

        # Security check
        try:
            self._sandbox.check_command(command)
        except CommandDeniedError as exc:
            return f"BLOCKED: {exc}"

        # Resolve working directory
        if directory:
            cwd = (self._sandbox.workspace / directory).resolve()
            # Ensure it's within workspace
            try:
                cwd.relative_to(self._sandbox.workspace)
            except ValueError:
                return f"BLOCKED: directory '{directory}' is outside workspace"
            if not cwd.is_dir():
                return f"Error: directory '{directory}' does not exist"
        else:
            cwd = self._sandbox.workspace

        # Resolve shell executable
        shell_exe, shell_args = _resolve_shell(shell_mode)

        try:
            if shell_exe:
                proc = await asyncio.create_subprocess_exec(
                    shell_exe,
                    *shell_args,
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(cwd),
                    env={**os.environ},
                )
            else:
                proc = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(cwd),
                    env={**os.environ},
                )

            # Background mode: return immediately with PID
            if background:
                # Clean up finished background processes
                self._background = {
                    pid: p for pid, p in self._background.items() if p.returncode is None
                }
                if len(self._background) >= self._MAX_BACKGROUND:
                    return (
                        f"Error: max {self._MAX_BACKGROUND} background processes. "
                        f"Running: {', '.join(str(p) for p in self._background.keys())}"
                    )
                pid = proc.pid
                self._background[pid] = proc
                stop_cmd = f"taskkill /PID {pid} /F" if _IS_WINDOWS else f"kill {pid}"
                return (
                    f"Background process started: PID {pid}\n"
                    f"Command: {command}\n"
                    f"Use shell(command='{stop_cmd}') to stop."
                )

            # Stream stdout line-by-line when progress callback is available
            if self._progress and proc.stdout:
                stdout_lines: list[str] = []
                try:

                    async def _read_stdout() -> None:
                        assert proc.stdout is not None
                        while True:
                            line = await proc.stdout.readline()
                            if not line:
                                break
                            decoded = line.decode("utf-8", errors="replace")
                            stdout_lines.append(decoded)
                            if self._progress:
                                await self._progress(decoded)

                    async def _read_stderr() -> bytes:
                        assert proc.stderr is not None
                        return await proc.stderr.read()

                    stderr_bytes, _ = await asyncio.wait_for(
                        asyncio.gather(_read_stderr(), _read_stdout()),
                        timeout=timeout,
                    )
                except TimeoutError:
                    proc.kill()
                    await proc.wait()
                    return f"Command timed out after {timeout}s"

                await proc.wait()
                stdout_text = "".join(stdout_lines)
                stderr_text = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""
            else:
                # Non-streaming path
                try:
                    stdout_raw, stderr_raw = await asyncio.wait_for(
                        proc.communicate(),
                        timeout=timeout,
                    )
                except TimeoutError:
                    proc.kill()
                    await proc.wait()
                    return f"Command timed out after {timeout}s"
                stdout_text = stdout_raw.decode("utf-8", errors="replace") if stdout_raw else ""
                stderr_text = stderr_raw.decode("utf-8", errors="replace") if stderr_raw else ""

            output_parts: list[str] = []
            if stdout_text:
                output_parts.append(stdout_text)
            if stderr_text:
                output_parts.append(stderr_text)

            output = "\n".join(output_parts).strip() or "(no output)"

            # Truncate
            max_chars = self._sandbox.max_output_chars
            if len(output) > max_chars:
                output = output[:max_chars] + "\n...(truncated)"

            if proc.returncode != 0:
                output = f"Exit code {proc.returncode}\n{output}"

            return output

        except Exception as exc:
            return f"Shell error: {exc}"
