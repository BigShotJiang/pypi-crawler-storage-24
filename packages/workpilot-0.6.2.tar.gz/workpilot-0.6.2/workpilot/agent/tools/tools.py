"""
Tools — unified tool discovery, inspection, and management.

Merges built-in tool activation (formerly tool_info) and MCP server
management (formerly mcp_connect) into a single entry point:

    tools()                                              → list all
    tools(name="browser")                                → inspect + enable built-in tool
    tools(name="git", action="disable")                  → disable built-in tool
    tools(name="MCP_icm")                                → connect MCP server
    tools(name="MCP_icm", action="describe")             → full MCP capabilities
    tools(name="MCP_icm", action="describe", query="incident") → filtered
    tools(name="MCP_icm", action="disable")              → disconnect MCP server
    tools(name="MCP_icm", action="status")               → server status
    tools(name="MCP_icm", action="resources", query="...") → read resource
    tools(name="MCP_icm", action="prompts", query="...", arguments={...}) → render prompt
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from workpilot.agent.tools.base import Tool, ToolMetadata

if TYPE_CHECKING:
    from workpilot.agent.tools.registry import ToolRegistry
    from workpilot.mcp.manager import MCPManager

_MCP_PREFIX = "MCP_"


class ToolsTool(Tool):
    """Unified tool discovery and management for built-in tools and MCP servers."""

    def __init__(
        self,
        registry: ToolRegistry,
        mcp_manager: MCPManager | None = None,
    ) -> None:
        self._registry = registry
        self._mcp = mcp_manager

    @property
    def name(self) -> str:
        return "tools"

    @property
    def description(self) -> str:
        return (
            "Discover and enable tools. Inspect details, parameters, and MCP server capabilities."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": (
                        "Tool name or MCP server (prefix MCP_, e.g. 'MCP_icm'). Omit to list all."
                    ),
                },
                "action": {
                    "type": "string",
                    "enum": [
                        "enable",
                        "disable",
                        "describe",
                        "status",
                        "resources",
                        "prompts",
                    ],
                    "description": (
                        "enable (default) = inspect/activate tool or connect MCP server; "
                        "disable = deactivate tool or disconnect MCP server; "
                        "describe = show full details (built-in: params; "
                        "MCP: tools + resources + prompts); "
                        "status = MCP server state; "
                        "resources = read an MCP resource by URI; "
                        "prompts = render an MCP prompt."
                    ),
                },
                "query": {
                    "type": "string",
                    "description": (
                        "Filter keyword (describe), resource URI (resources), "
                        "or prompt name (prompts)."
                    ),
                },
                "arguments": {
                    "type": "object",
                    "description": "Prompt arguments (prompts action only).",
                },
            },
            "required": [],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="low", approval="never", category="builtin")

    async def execute(self, **kwargs: Any) -> str:
        name = kwargs.get("name", "").strip()
        action = kwargs.get("action", "").strip() or "enable"
        query = kwargs.get("query", "").strip()
        arguments = kwargs.get("arguments") or {}

        # No name → list all
        if not name:
            return self._list_all()

        # MCP server path
        if name.startswith(_MCP_PREFIX):
            server = name[len(_MCP_PREFIX) :]
            return await self._handle_mcp(server, action, query, arguments)

        # Built-in tool path
        return await self._handle_builtin(name, action)

    # ── Built-in tool handling ─────────────────────────────────────────

    async def _handle_builtin(self, tool_name: str, action: str) -> str:
        tool = self._registry.get(tool_name)
        if tool is None:
            available = [t.name for t in self._registry.list_tools()]
            return f"Unknown tool '{tool_name}'. Available: {', '.join(available)}"

        if action == "disable":
            ok = self._registry.deactivate(tool_name)
            if ok:
                return f"Disabled '{tool_name}'. Use tools(name='{tool_name}') to re-enable."
            return f"Cannot disable '{tool_name}' — core tools are always active."

        # enable or describe → inspect + activate
        activated = self._registry.activate(tool_name)
        parts = []
        if activated:
            parts.append(f"Enabled '{tool_name}' — now available for function calling.\n")

        parts.extend(
            [
                f"Tool: {tool.name}",
                f"Description: {tool.description}",
                f"Risk: {tool.metadata.risk_level}",
                f"Approval: {tool.metadata.approval}",
                "",
                "Parameters:",
                json.dumps(tool.parameters, indent=2),
            ]
        )
        return "\n".join(parts)

    # ── MCP server handling ────────────────────────────────────────────

    async def _handle_mcp(
        self, server: str, action: str, query: str, arguments: dict[str, Any]
    ) -> str:
        if self._mcp is None:
            return "MCP is not configured."

        match action:
            case "enable":
                result = await self._mcp.connect_server(server)
                # Activate any MCP tools that were registered during connect/describe
                for t in self._registry.list_tools():
                    if t.name.startswith(f"MCP_{server}_"):
                        self._registry.activate(t.name)
                return result
            case "disable":
                await self._mcp.disconnect_server(server)
                return f"Disconnected from MCP server '{server}'."
            case "describe":
                result = await self._mcp.describe_server(server, keyword=query or None)
                # Activate registered MCP tools
                for t in self._registry.list_tools():
                    if t.name.startswith(f"MCP_{server}_"):
                        self._registry.activate(t.name)
                return result
            case "status":
                return self._format_mcp_status(server)
            case "resources":
                if not query:
                    return await self._mcp.describe_server(server)
                return await self._mcp.read_resource(server, query)
            case "prompts":
                if not query:
                    return await self._mcp.describe_server(server)
                return await self._mcp.get_prompt(server, query, arguments)
            case _:
                return (
                    f"Unknown action '{action}'. "
                    "Use: enable, disable, describe, status, resources, prompts."
                )

    def _format_mcp_status(self, server: str) -> str:
        info = self._mcp.get_server_status(server)  # type: ignore[union-attr]
        if info is None:
            return f"Unknown MCP server '{server}'."
        parts = [
            f"Server: {info.name}",
            f"State: {info.state.value}",
            f"Agency: {'yes' if info.is_agency else 'no'}",
            f"Tools registered: {info.tool_count}",
        ]
        if info.protocol_version:
            parts.append(f"Protocol: {info.protocol_version}")
        if info.error:
            parts.append(f"Error: {info.error}")
        return "\n".join(parts)

    # ── List all ───────────────────────────────────────────────────────

    def _list_all(self) -> str:
        lines: list[str] = []
        active_names = {t.name for t in self._registry.get_active_tools()}

        # Built-in tools (exclude MCP tools — shown under MCP servers section)
        builtin_tools = [t for t in self._registry.list_tools() if t.metadata.category != "mcp"]
        if builtin_tools:
            lines.append("Built-in tools:")
            for t in builtin_tools:
                brief = t.description.split(".")[0]
                status = "[active]" if t.name in active_names else "[inactive]"
                lines.append(f"  {t.name:20s} {status:10s} — {brief}")

        # MCP servers with status
        if self._mcp:
            servers = self._mcp.list_servers()
            mcp_lines: list[str] = []
            for s in servers:
                if not s.enabled:
                    continue
                state = s.state.value  # idle, connected, connecting, etc.
                desc = s.description or ""
                tools_info = f" ({s.tool_count} tools)" if s.tool_count > 0 else ""
                mcp_lines.append(f"  {_MCP_PREFIX}{s.name:16s} [{state}]{tools_info:14s} — {desc}")
            if mcp_lines:
                lines.append("")
                lines.append("MCP servers:")
                lines.extend(mcp_lines)

        if not lines:
            return "No tools registered."

        lines.append("")
        lines.append("Use tools(name='<name>') to enable a tool or connect an MCP server.")
        return "\n".join(lines)
