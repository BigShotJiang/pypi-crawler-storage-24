"""
File system tools — read, write, edit, list, search with workspace sandboxing.

All paths are resolved through the Sandbox to prevent path traversal.
"""

from __future__ import annotations

import difflib
import re
from pathlib import Path
from typing import Any

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.security.sandbox import PathDeniedError, Sandbox


class ReadFileTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="low", approval="never")

    @property
    def name(self) -> str:
        return "read_file"

    @property
    def description(self) -> str:
        return "Read file contents. Supports offset and limit for partial reads."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path relative to workspace"},
                "offset": {"type": "integer", "description": "Start line (1-based)"},
                "limit": {"type": "integer", "description": "Max lines to return"},
            },
            "required": ["path"],
        }

    async def execute(self, **kwargs: Any) -> str:
        try:
            resolved = self._sandbox.resolve_path(kwargs["path"])
            content = resolved.read_text(encoding="utf-8")
            if kwargs.get("offset") or kwargs.get("limit"):
                lines = content.splitlines(keepends=True)
                start = max(0, (kwargs.get("offset", 1) or 1) - 1)
                end = start + (kwargs.get("limit") or len(lines))
                content = "".join(lines[start:end])
            return content
        except PathDeniedError as exc:
            return f"BLOCKED: {exc}"
        except FileNotFoundError:
            return f"File not found: {kwargs['path']}"
        except Exception as exc:
            return f"Error reading file: {exc}"


class WriteFileTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="medium", approval="never")

    @property
    def name(self) -> str:
        return "write_file"

    @property
    def description(self) -> str:
        return "Write content to a file. Creates parent directories if needed."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path relative to workspace"},
                "content": {"type": "string", "description": "Content to write"},
            },
            "required": ["path", "content"],
        }

    async def execute(self, **kwargs: Any) -> str:
        try:
            resolved = self._sandbox.resolve_path(kwargs["path"])
            content = kwargs["content"]
            self._sandbox.check_file_size(content)
            resolved.parent.mkdir(parents=True, exist_ok=True)
            resolved.write_text(content, encoding="utf-8")
            return f"Written: {kwargs['path']}"
        except PathDeniedError as exc:
            return f"BLOCKED: {exc}"
        except Exception as exc:
            return f"Error writing file: {exc}"


class EditFileTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="medium", approval="never")

    @property
    def name(self) -> str:
        return "edit_file"

    @property
    def description(self) -> str:
        return "Edit a file by replacing an exact string match. Returns a unified diff."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path"},
                "old_string": {"type": "string", "description": "Exact text to find"},
                "new_string": {"type": "string", "description": "Replacement text"},
            },
            "required": ["path", "old_string", "new_string"],
        }

    async def execute(self, **kwargs: Any) -> str:
        try:
            resolved = self._sandbox.resolve_path(kwargs["path"])
            content = resolved.read_text(encoding="utf-8")
            old = kwargs["old_string"]
            new = kwargs["new_string"]

            if old not in content:
                return self._fuzzy_hint(content, old, kwargs["path"])

            count = content.count(old)
            if count > 1:
                return (
                    f"Error: old_string has {count} matches — "
                    f"provide more context to make it unique"
                )

            updated = content.replace(old, new, 1)
            self._sandbox.check_file_size(updated)
            resolved.write_text(updated, encoding="utf-8")

            # Show diff
            diff = difflib.unified_diff(
                content.splitlines(keepends=True),
                updated.splitlines(keepends=True),
                fromfile=f"a/{kwargs['path']}",
                tofile=f"b/{kwargs['path']}",
                n=3,
            )
            return "".join(diff) or f"Edited: {kwargs['path']}"
        except PathDeniedError as exc:
            return f"BLOCKED: {exc}"
        except Exception as exc:
            return f"Error editing file: {exc}"

    @staticmethod
    def _fuzzy_hint(content: str, old_string: str, path: str) -> str:
        """When old_string is not found, find the closest match and show a diff hint."""
        lines = content.splitlines(keepends=True)
        old_lines = old_string.splitlines(keepends=True)
        old_len = len(old_lines)

        # Skip fuzzy matching for large content to avoid O(n²) SequenceMatcher cost
        if len(lines) > 40_000 or old_len > 1024 or len(content) > 2_000_000:
            return f"Error: old_string not found in {path}."

        best_ratio = 0.0
        best_start = 0

        # Slide a window of old_len lines across the file
        for i in range(max(1, len(lines) - old_len + 1)):
            candidate = lines[i : i + old_len]
            ratio = difflib.SequenceMatcher(None, "".join(candidate), old_string).ratio()
            if ratio > best_ratio:
                best_ratio = ratio
                best_start = i

        if best_ratio < 0.4:
            return f"Error: old_string not found in {path}. No similar content found."

        best_match = "".join(lines[best_start : best_start + old_len])
        diff_lines = list(
            difflib.unified_diff(
                old_string.splitlines(keepends=True),
                best_match.splitlines(keepends=True),
                fromfile="old_string (provided)",
                tofile=f"actual content (line {best_start + 1})",
                n=3,
            )
        )
        diff_text = "".join(diff_lines[:30])  # Cap output to avoid token bloat
        return (
            f"Error: old_string not found in {path}.\n"
            f"Best match ({best_ratio:.0%} similar) at line {best_start + 1}:\n"
            f"{diff_text}"
        )


class ListDirTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="low", approval="never")

    @property
    def name(self) -> str:
        return "list_dir"

    @property
    def description(self) -> str:
        return "List directory contents. Supports recursive listing."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Directory path (default: workspace root)",
                },
                "recursive": {"type": "boolean", "description": "List recursively"},
            },
        }

    async def execute(self, **kwargs: Any) -> str:
        try:
            path_str = kwargs.get("path", ".")
            resolved = self._sandbox.resolve_path(path_str)
            if not resolved.is_dir():
                return f"Not a directory: {path_str}"

            entries: list[str] = []
            if kwargs.get("recursive"):
                for p in sorted(resolved.rglob("*")):
                    rel = p.relative_to(resolved)
                    suffix = "/" if p.is_dir() else ""
                    entries.append(f"{rel}{suffix}")
            else:
                for p in sorted(resolved.iterdir()):
                    suffix = "/" if p.is_dir() else ""
                    entries.append(f"{p.name}{suffix}")

            return "\n".join(entries[:500]) if entries else "(empty directory)"
        except PathDeniedError as exc:
            return f"BLOCKED: {exc}"
        except Exception as exc:
            return f"Error listing directory: {exc}"


class SearchFilesTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="low", approval="never")

    @property
    def name(self) -> str:
        return "search_files"

    @property
    def description(self) -> str:
        return (
            "Search files by content (regex) or file name (glob). Returns matching lines or paths."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regex pattern (content mode) or glob pattern (name mode)",
                },
                "mode": {
                    "type": "string",
                    "enum": ["content", "name"],
                    "description": "Search mode: 'content' for regex in file contents, "
                    "'name' for glob on file names (default: content)",
                },
                "path": {
                    "type": "string",
                    "description": "Search root directory (default: workspace root)",
                },
                "file_pattern": {
                    "type": "string",
                    "description": "Glob filter for files to search, e.g. '*.py' (content mode only)",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return (default: 50)",
                },
            },
            "required": ["pattern"],
        }

    async def execute(self, **kwargs: Any) -> str:
        try:
            pattern = kwargs["pattern"]
            mode = kwargs.get("mode", "content")
            path_str = kwargs.get("path", ".")
            file_pattern = kwargs.get("file_pattern")
            max_results = kwargs.get("max_results", 50)

            # Validate mode
            if mode not in ("content", "name"):
                return "Error: mode must be 'content' or 'name'"

            # Clamp max_results to safe bounds
            max_results = min(max(1, max_results), 500)

            resolved = self._sandbox.resolve_path(path_str)
            if not resolved.is_dir():
                return f"Not a directory: {path_str}"

            if mode == "name":
                return self._search_by_name(resolved, pattern, max_results)
            return self._search_by_content(resolved, pattern, file_pattern, max_results)
        except PathDeniedError as exc:
            return f"BLOCKED: {exc}"
        except re.error as exc:
            return f"Invalid regex pattern: {exc}"
        except Exception as exc:
            return f"Error searching files: {exc}"

    def _search_by_name(self, root: Path, pattern: str, max_results: int) -> str:
        """Search for files by glob pattern."""
        matches: list[str] = []
        for p in sorted(root.rglob(pattern)):
            if p.is_file():
                # Validate each path via sandbox to prevent symlink escape
                try:
                    self._sandbox.resolve_path(str(p))
                except PathDeniedError:
                    continue
                try:
                    rel = p.relative_to(root)
                except ValueError:
                    rel = p
                matches.append(str(rel))
                if len(matches) >= max_results:
                    break

        if not matches:
            return f"No files matching '{pattern}'"
        header = f"Found {len(matches)} file(s) matching '{pattern}':\n"
        return header + "\n".join(matches)

    def _search_by_content(
        self, root: Path, pattern: str, file_pattern: str | None, max_results: int
    ) -> str:
        """Search file contents by regex pattern."""
        compiled = re.compile(pattern)
        file_glob = file_pattern or "*"
        results: list[str] = []

        for filepath in sorted(root.rglob(file_glob)):
            if not filepath.is_file():
                continue
            # Validate each path via sandbox to prevent symlink escape
            try:
                self._sandbox.resolve_path(str(filepath))
            except PathDeniedError:
                continue
            # Skip files larger than 5 MB to prevent OOM
            try:
                if filepath.stat().st_size > 5_000_000:
                    continue
            except OSError:
                continue
            try:
                lines = filepath.read_text(encoding="utf-8").splitlines()
            except (UnicodeDecodeError, PermissionError, OSError):
                continue

            try:
                rel = filepath.relative_to(root)
            except ValueError:
                rel = filepath

            for i, line in enumerate(lines):
                if compiled.search(line):
                    # Gather context: 1 line before and after
                    context_lines: list[str] = []
                    for offset in range(max(0, i - 1), min(len(lines), i + 2)):
                        prefix = ">" if offset == i else " "
                        context_lines.append(f"  {prefix} {offset + 1}: {lines[offset]}")
                    results.append(f"{rel}:{i + 1}\n" + "\n".join(context_lines))
                    if len(results) >= max_results:
                        break
            if len(results) >= max_results:
                break

        if not results:
            return f"No matches for pattern '{pattern}'"
        header = f"Found {len(results)} match(es) for '{pattern}':\n\n"
        return header + "\n\n".join(results)
