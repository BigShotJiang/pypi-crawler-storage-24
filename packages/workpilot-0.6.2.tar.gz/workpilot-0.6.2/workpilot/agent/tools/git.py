"""
Git tool — version control operations within the workspace.
"""

from __future__ import annotations

import asyncio
from typing import Any

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.security.sandbox import Sandbox


class GitTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="medium", approval="auto", tier="standard")

    @property
    def name(self) -> str:
        return "git"

    @property
    def description(self) -> str:
        return "Run a git command."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "args": {
                    "type": "string",
                    "description": (
                        "Git subcommand and arguments. "
                        "Common: status, diff, log, add, commit, branch, checkout, "
                        "merge, rebase, stash, tag, remote, fetch, pull, push. "
                        "Blocked: push --force, reset --hard, clean -f. "
                        "Example: 'log -5 --oneline'"
                    ),
                },
            },
            "required": ["args"],
        }

    _BLOCKED_SUBCOMMANDS = frozenset(
        {
            "push --force",
            "push -f",
            "reset --hard",
            "clean -f",
            "clean -fd",
        }
    )

    async def execute(self, **kwargs: Any) -> str:
        args_str: str = kwargs["args"]

        # Block dangerous git commands
        args_lower = args_str.lower().strip()
        for blocked in self._BLOCKED_SUBCOMMANDS:
            if args_lower.startswith(blocked):
                return f"BLOCKED: 'git {blocked}' is not allowed for safety"

        try:
            proc = await asyncio.create_subprocess_exec(
                "git",
                *args_str.split(),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self._sandbox.workspace),
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
            output_parts = []
            if stdout:
                output_parts.append(stdout.decode("utf-8", errors="replace"))
            if stderr:
                output_parts.append(stderr.decode("utf-8", errors="replace"))
            output = "\n".join(output_parts).strip() or "(no output)"
            if proc.returncode != 0:
                output = f"Exit code {proc.returncode}\n{output}"
            return output
        except TimeoutError:
            return "Git command timed out"
        except Exception as exc:
            return f"Git error: {exc}"
