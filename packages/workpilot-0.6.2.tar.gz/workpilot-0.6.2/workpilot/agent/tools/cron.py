"""
CronTool — lets the agent manage scheduled jobs at runtime.

The agent can list, add, remove, enable, and disable jobs.
Dynamic jobs persist to .workpilot/cron/jobs.json.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from workpilot.agent.tools.base import Tool, ToolMetadata

if TYPE_CHECKING:
    from workpilot.cron.service import SchedulerService


class CronTool(Tool):
    """Agent-facing tool for managing scheduled jobs (nanobot CronTool pattern)."""

    def __init__(self, scheduler: SchedulerService) -> None:
        self._scheduler = scheduler

    @property
    def name(self) -> str:
        return "cron"

    @property
    def description(self) -> str:
        return "Manage scheduled jobs and reminders. Always set notify_channels=['*']."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "add", "remove", "enable", "disable", "describe"],
                    "description": (
                        "list = show all; add = create; remove = delete; "
                        "enable/disable = toggle; describe = show details."
                    ),
                },
                "job_id": {
                    "type": "string",
                    "description": "Job ID (required for remove/enable/disable/describe).",
                },
                "schedule": {
                    "type": "string",
                    "description": (
                        "'at:+60' = delay 60s; 'at:2026-03-04T15:00:00' = specific time; "
                        "'at' = immediate; 3600 = repeat every 3600s; "
                        "'0 9 * * *' = cron. Required for add."
                    ),
                },
                "prompt": {
                    "type": "string",
                    "description": "Task for the agent to execute. Required for add.",
                },
                "notify_channels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Result delivery channels. ['*'] = all active channels.",
                },
            },
            "required": ["action"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="low", approval="auto", tier="standard")

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")

        if action == "list":
            jobs = self._scheduler.list_jobs()
            if not jobs:
                return "No scheduled jobs."
            lines = ["Scheduled jobs:"]
            for j in jobs:
                status = "enabled" if j["enabled"] else "DISABLED"
                next_run = j.get("next_run") or "N/A"
                lines.append(
                    f"  {j['name']}: {j['trigger_type']} ({j['schedule']}) "
                    f"agent={j['agent']} [{status}] next={next_run}"
                )
            return "\n".join(lines)

        elif action == "add":
            schedule = kwargs.get("schedule")
            prompt = kwargs.get("prompt")
            if not schedule or not prompt:
                return "Error: 'schedule' and 'prompt' are required for add."
            import uuid as _uuid

            job_id = kwargs.get("job_id") or f"agent-{_uuid.uuid4().hex[:8]}"
            notify_channels = kwargs.get("notify_channels") or ["*"]
            try:
                self._scheduler.add_job(
                    name=job_id,
                    schedule=schedule,
                    prompt=prompt,
                    notify_channels=notify_channels,
                    dynamic=True,
                )
            except ValueError as exc:
                return f"Error: {exc}"
            return f"Job '{job_id}' added (schedule={schedule})."

        elif action == "remove":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for remove."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.remove_job(job_id)
            return f"Job '{job_id}' removed."

        elif action == "enable":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for enable."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.enable(job_id)
            return f"Job '{job_id}' enabled."

        elif action == "disable":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for disable."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.disable(job_id)
            return f"Job '{job_id}' disabled."

        elif action == "describe":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for describe."
            jobs_by_name = {j["name"]: j for j in self._scheduler.list_jobs()}
            job = jobs_by_name.get(job_id)
            if not job:
                return f"Error: job '{job_id}' not found."
            return (
                f"Job: {job['name']}\n"
                f"Schedule: {job['trigger_type']} ({job['schedule']})\n"
                f"Agent: {job['agent']}\n"
                f"Status: {'enabled' if job['enabled'] else 'DISABLED'}\n"
                f"Next run: {job.get('next_run') or 'N/A'}\n"
                f"Failures: {job['failure_count']}"
            )

        return f"Unknown action: {action}"
