"""
Cross-channel notification tool — send messages to any active channel
via the async message bus.

The tool publishes an OutboundMessage to the MessageBus, which routes it
to the appropriate channel handler. Use '*' to broadcast to all channels.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.bus.events import OutboundMessage
from workpilot.bus.queue import MessageBus


class NotifyTool(Tool):
    """Send notifications to active channels through the message bus."""

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="low", approval="never", timeout=30)

    def __init__(
        self,
        bus: MessageBus,
        active_channels_fn: Callable[[], list[str]] | None = None,
    ) -> None:
        self._bus = bus
        self._active_channels_fn = active_channels_fn or (lambda: ["cli"])

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "notify"

    @property
    def description(self) -> str:
        return "Push a notification to the user via their active channel."

    @property
    def parameters(self) -> dict[str, Any]:
        channels = self._active_channels_fn()
        return {
            "type": "object",
            "properties": {
                "channel": {
                    "type": "string",
                    "description": f"Active: {', '.join(channels)}. Use '*' for all.",
                },
                "content": {
                    "type": "string",
                    "description": "Message content.",
                },
            },
            "required": ["channel", "content"],
        }

    async def execute(self, **kwargs: Any) -> str:
        channel: str = kwargs["channel"]
        content: str = kwargs["content"]
        # Registry injects _channel/_channel_id from the current conversation
        current_channel: str = kwargs.get("_channel", "")
        current_channel_id: str = kwargs.get("_channel_id", "")

        if not content.strip():
            return "Error: message content cannot be empty."

        # Broadcast to all active channels
        if channel == "*":
            targets = self._active_channels_fn()
            if not targets:
                return "Error: no active channels."
            results: list[str] = []
            for ch in targets:
                try:
                    # Use real channel_id if notifying the current conversation's channel
                    cid = current_channel_id if ch == current_channel and current_channel_id else ch
                    await self._bus.publish_outbound(
                        OutboundMessage(channel=ch, channel_id=cid, content=content)
                    )
                    results.append(ch)
                except Exception as exc:
                    logger.error(f"Failed to notify '{ch}': {exc}")
            return f"Notified {len(results)} channels: {', '.join(results)}"

        # Single channel
        cid = current_channel_id if channel == current_channel and current_channel_id else channel
        try:
            await self._bus.publish_outbound(
                OutboundMessage(channel=channel, channel_id=cid, content=content)
            )
            return f"Notified {channel}"
        except Exception as exc:
            logger.error(f"Failed to notify '{channel}': {exc}")
            return f"Error sending to {channel}: {exc}"
