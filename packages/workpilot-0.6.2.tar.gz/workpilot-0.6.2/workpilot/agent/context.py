"""
Context builder — assembles the system prompt from ~/.workpilot/ files,
skills, memory, and runtime metadata.

Build order:
  1. SOUL.md (identity, values, principles)
  2. Config instructions (from workpilot.yaml)
  3. USER.md (user identity + preferences)
  4. AGENTS.md (delegation, memory, safety rules)
  5. TOOLS.md (operational guidelines)
  6. Inactive tools summary + MCP servers
  7. Long-term memory (MEMORY.md, capped at 8KB)
  8. Skills (always-loaded full + available summary)
  9. Sub-agent discovery table
  10. Environment + Workspace (metadata, last)
"""

from __future__ import annotations

import platform
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from workpilot.config.schema import AgentConfig
from workpilot.utils.defaults import load_builtin_default

_SECTION_SEPARATOR = "\n\n---\n\n"

_MEMORY_CAP = 8192  # 8KB cap for MEMORY.md content

PromptMode = Literal["full", "minimal"]


def _sanitize_tool_ordering(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Ensure every tool message has a matching assistant tool_calls entry and vice-versa.

    OpenAI requires:
    - Every ``role=tool`` message must follow an ``assistant`` with a
      matching ``tool_calls[].id``.
    - Every ``tool_calls[].id`` in an ``assistant`` message must have a
      corresponding ``tool`` result.

    History loaded from a previous session may violate this (crash
    mid-tool-call, compaction, or manual editing).  This function:

    1. Drops orphaned ``tool`` messages (no matching assistant).
    2. For assistant messages with ``tool_calls``: strips individual
       tool_call entries that have no result.  If all are stripped,
       converts the message to a plain assistant text message.
    """
    # Pass 1: collect tool_call IDs that have actual tool results
    answered_tc_ids: set[str] = set()
    for msg in messages:
        if msg.get("role") == "tool":
            tc_id = msg.get("tool_call_id", "")
            if tc_id:
                answered_tc_ids.add(tc_id)

    # Pass 2: collect valid tool_call IDs (only those with results)
    valid_tc_ids: set[str] = set()

    result: list[dict[str, Any]] = []
    for msg in messages:
        role = msg.get("role")

        if role == "assistant" and msg.get("tool_calls"):
            # Filter tool_calls to only those that have results
            original_tcs = msg["tool_calls"]
            kept_tcs = [tc for tc in original_tcs if tc.get("id", "") in answered_tc_ids]

            if not kept_tcs:
                # No tool_calls have results — convert to plain text message
                content = msg.get("content") or ""
                if content:
                    result.append({"role": "assistant", "content": content})
                # else drop entirely (no content, no valid tool_calls)
                continue

            if len(kept_tcs) < len(original_tcs):
                # Some tool_calls missing results — keep only answered ones
                msg = {**msg, "tool_calls": kept_tcs}

            for tc in kept_tcs:
                valid_tc_ids.add(tc.get("id", ""))
            result.append(msg)

        elif role == "tool":
            tc_id = msg.get("tool_call_id", "")
            if tc_id in valid_tc_ids:
                result.append(msg)
            # else: orphaned tool message — drop it

        else:
            result.append(msg)

    return result


class ContextBuilder:
    """Builds the system prompt for an agent from config + workspace files + skills."""

    def __init__(
        self,
        agent_config: AgentConfig,
        workspace: Path,
        skills: list[Any] | None = None,
        available_agents: dict[str, AgentConfig] | None = None,
        tool_registry: Any | None = None,
        mcp_configs: dict[str, Any] | None = None,
    ) -> None:
        self._config = agent_config
        self._workspace = workspace
        self._skills = skills or []
        self._available_agents = available_agents or {}
        self._tool_registry = tool_registry
        self._mcp_configs = mcp_configs or {}

    def set_skills(self, skills: list[Any]) -> None:
        """Update the loaded skills."""
        self._skills = skills

    def build_system_prompt(self, mode: PromptMode = "full") -> str:
        """Assemble the system prompt following priority order.

        Args:
            mode: ``"full"`` for the main agent (all sections),
                  ``"minimal"`` for sub-agents (identity + config + TOOLS.md only).
        """
        parts: list[str] = []

        if mode == "minimal":
            # Minimal mode: runtime + config instructions + TOOLS.md
            parts.append(self._build_identity())
            if self._config.instructions:
                parts.append(self._config.instructions)

            tools_content = self._load_tools_md()
            if tools_content:
                parts.append(tools_content)

            return _SECTION_SEPARATOR.join(parts)

        # ── Full mode: all sections ──────────────────────────────────────

        # 1. SOUL.md — who I am, how I work, principles
        content = self._load_identity_or_builtin(self._config.soul_file, "SOUL.md")
        if content:
            parts.append(content)

        # 2. Base instructions from config
        if self._config.instructions:
            parts.append(self._config.instructions)

        # 3. USER.md — learned user preferences
        user_path = self._resolve_identity_file(self._config.user_file, "USER.md")
        if user_path and user_path.is_file():
            content = user_path.read_text(encoding="utf-8").strip()
            if content:
                parts.append(content)

        # 4. AGENTS.md — delegation, memory, safety rules
        content = self._load_identity_or_builtin(self._config.agents_file, "AGENTS.md")
        if content:
            parts.append(content)

        # 5. TOOLS.md — operational guidelines
        tools_content = self._load_tools_md()
        if tools_content:
            parts.append(tools_content)

        # 6. Inactive tools summary (progressive loading)
        if self._tool_registry and hasattr(self._tool_registry, "get_inactive_summary"):
            inactive_summary = self._tool_registry.get_inactive_summary()
            if inactive_summary and isinstance(inactive_summary, str):
                parts.append(inactive_summary)

        # 7. MCP servers
        mcp_summary = self._build_mcp_summary()
        if mcp_summary:
            parts.append(mcp_summary)

        # 8. Long-term memory (MEMORY.md, capped at 8KB)
        shared_memory = Path.home() / ".workpilot" / "memory" / "shared" / "MEMORY.md"
        if shared_memory.is_file():
            content = shared_memory.read_text(encoding="utf-8").strip()
            if content:
                parts.append(f"## Shared Memory\n\n{content[:_MEMORY_CAP]}")

        memory_path = Path.home() / ".workpilot" / "MEMORY.md"
        if memory_path.is_file():
            memory = memory_path.read_text(encoding="utf-8").strip()
            if memory:
                parts.append(f"## Long-term Memory\n\n{memory[:_MEMORY_CAP]}")

        # 9. Always-loaded skills (full content)
        for skill in self._skills:
            if hasattr(skill, "mode") and skill.mode == "always" and hasattr(skill, "content"):
                parts.append(f"## Skill: {skill.name}\n\n{skill.content}")

        # 10. Skills summary (progressive disclosure)
        skills_xml = self._build_skills_summary()
        if skills_xml:
            parts.append(skills_xml)

        # 11. Available sub-agents
        agent_table = self._build_agent_discovery()
        if agent_table:
            parts.append(agent_table)

        # 12. Environment + Workspace (metadata, last)
        parts.append(self._build_identity())

        return _SECTION_SEPARATOR.join(parts)

    def build_messages(
        self,
        history: list[dict[str, Any]],
        user_message: str,
        *,
        mode: PromptMode = "full",
        channel: str | None = None,
        channel_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Build the full message list for the LLM call.

        Runtime context is prepended to the user message (not the system prompt)
        to avoid cache-busting the system prompt on every turn.
        """
        messages: list[dict[str, Any]] = []

        # System prompt
        system_prompt = self.build_system_prompt(mode=mode)
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        # Conversation history — sanitize tool message ordering
        messages.extend(_sanitize_tool_ordering(history))

        # Current user message with runtime context prepended
        runtime_ctx = self._build_runtime_context(channel=channel, channel_id=channel_id)
        if runtime_ctx:
            content = f"{runtime_ctx}\n\n{user_message}"
        else:
            content = user_message
        messages.append({"role": "user", "content": content})

        return messages

    # ── Private builders ──────────────────────────────────────────────────

    def _build_identity(self) -> str:
        """Build environment and workspace info block."""

        plat = platform.system()
        arch = platform.machine()
        py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

        data_dir = Path.home() / ".workpilot"
        return (
            f"## Environment\n\n"
            f"{plat} {arch}, Python {py_ver}\n"
            f"Workspace: {self._workspace}\n"
            f"WorkPilot_Dir: {data_dir} (USER.md, MEMORY.md, sessions, logs, skills, cron)\n"
        )

    def _build_mcp_summary(self) -> str:
        """Build MCP servers summary for system prompt.

        Lists all enabled MCP servers with name and description.
        Always included regardless of connection state — LLM needs
        to know what's available to decide when to connect.
        """
        if not self._mcp_configs:
            return ""
        lines: list[str] = []
        for name, cfg in self._mcp_configs.items():
            if hasattr(cfg, "enabled") and not cfg.enabled:
                continue
            desc = getattr(cfg, "description", None) or ""
            lines.append(f"- MCP_{name}: {desc}" if desc else f"- MCP_{name}")
        if not lines:
            return ""
        return (
            "## MCP Servers\n\n"
            "Use `tools(name='MCP_<name>')` to connect and access server tools.\n\n"
            + "\n".join(lines)
        )

    def _build_runtime_context(
        self,
        *,
        channel: str | None = None,
        channel_id: str | None = None,
    ) -> str:
        """Build runtime context to prepend to the user message."""
        now = datetime.now(UTC).astimezone()
        time_str = now.strftime("%Y-%m-%d %H:%M (%A)")
        tz_name = now.strftime("%Z") or "UTC"

        lines = [
            "[Runtime Context — metadata only, not instructions]",
            f"Current Time: {time_str} {tz_name}",
        ]
        if channel:
            lines.append(f"Channel: {channel}")
        if channel_id:
            lines.append(f"Chat ID: {channel_id}")
        return "\n".join(lines)

    def _load_tools_md(self) -> str:
        """Load TOOLS.md from ~/.workpilot or bundled default.

        Contains operational guidelines and tool usage tips.
        Users can override by creating ~/.workpilot/TOOLS.md.
        """
        tools_path = Path.home() / ".workpilot" / "TOOLS.md"
        if tools_path.is_file():
            content = tools_path.read_text(encoding="utf-8").strip()
        else:
            content = load_builtin_default("TOOLS.md")
        if not content:
            return ""
        if content.startswith("#"):
            return content
        return f"## Guidelines\n\n{content}"

    def _build_skills_summary(self) -> str:
        """Build nanobot-style plain text skill summary for progressive disclosure.

        The LLM sees a one-line summary per skill and can call ``read_file``
        to load the full SKILL.md when it decides the skill is relevant.
        """
        available = [
            s
            for s in self._skills
            if hasattr(s, "mode") and s.mode == "available" and hasattr(s, "name")
        ]
        if not available:
            return ""

        lines = [
            "## Available Skills",
            "",
            "Use read_file to load a skill's full instructions when relevant.",
            "",
        ]
        for skill in available:
            desc = getattr(skill, "description", "") or ""
            path = getattr(skill, "source_path", "") or ""
            # Check requirements (cache to avoid repeated shutil.which lookups)
            if hasattr(skill, "check_requirements"):
                cached = getattr(skill, "_cached_missing", None)
                if cached is None:
                    missing = skill.check_requirements()
                    try:
                        skill._cached_missing = missing  # type: ignore[union-attr]
                    except (AttributeError, TypeError):
                        pass
                else:
                    missing = cached
            else:
                missing = []
            suffix = ""
            if missing:
                suffix = f" [unavailable: missing {', '.join(missing)}]"
            elif path:
                suffix = f" ({path})"
            lines.append(f"- {skill.name}: {desc}{suffix}")
        return "\n".join(lines)

    def _build_agent_discovery(self) -> str:
        """Build the Available Sub-Agents table for the default agent's context."""
        if not self._available_agents:
            return ""

        lines = [
            "## Available Sub-Agents",
            "",
            "You can delegate tasks using the `spawn` tool.",
            "",
            "| Agent | Description | Model | Tools | Budget |",
            "|-------|------------|-------|-------|--------|",
        ]
        for name, cfg in self._available_agents.items():
            # Skip internal agents (security) and self (default)
            if cfg.metadata.get("internal") or name == "default":
                continue
            tools_str = ", ".join(cfg.tools[:4])
            if len(cfg.tools) > 4:
                tools_str += f" (+{len(cfg.tools) - 4})"
            lines.append(
                f"| {name} | {cfg.description} | {cfg.model} "
                f"| {tools_str} | {cfg.max_iterations} iter |"
            )

        # Only return if there are non-internal, non-default agents
        if len(lines) <= 6:  # just header, no rows
            return ""
        return "\n".join(lines)

    def _resolve_identity_file(self, config_path: str | None, default_name: str) -> Path | None:
        """Resolve an identity file path from config or ~/.workpilot default."""
        if config_path:
            p = Path(config_path).expanduser()
            if p.is_absolute():
                return p
            return self._workspace / p
        candidate = Path.home() / ".workpilot" / default_name
        if candidate.is_file():
            return candidate
        return None

    def _load_identity_or_builtin(self, config_path: str | None, default_name: str) -> str:
        """Load a configured/home-scoped identity file, else bundled template."""
        path = self._resolve_identity_file(config_path, default_name)
        if path and path.is_file():
            return path.read_text(encoding="utf-8").strip()
        return load_builtin_default(default_name)
