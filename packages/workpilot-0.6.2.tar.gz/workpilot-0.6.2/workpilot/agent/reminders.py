"""
System reminders — periodic context reinforcement during the agent loop.

Injects condensed system reminders into the conversation at key points:
- Every N tool calls (configurable via ``reminder_interval``)
- After context compaction (re-reads MEMORY.md from disk)
- After sub-agent (spawn) results arrive

The reminder content is a condensed version of core identity + current task
focus, keeping the LLM grounded during long-running agentic sessions.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from loguru import logger

_MEMORY_CAP = 8192  # Match context.py cap


def build_periodic_reminder(agent_name: str, user_task: str) -> dict[str, Any]:
    """Build a periodic system reminder message.

    Contains a condensed identity block and the current task focus
    to keep the LLM grounded during long tool-call chains.

    Args:
        agent_name: The agent's configured name.
        user_task: The original user request (first ~200 chars).

    Returns:
        A system message dict ready to append to the conversation.
    """
    task_preview = user_task[:200] + ("..." if len(user_task) > 200 else "")
    content = (
        "[System Reminder]\n"
        f"You are {agent_name}, an enterprise AI assistant.\n"
        "Stay focused on the current task. Avoid repeating tool calls. "
        "If stuck, summarize progress and ask for clarification.\n"
        f"Current task: {task_preview}"
    )
    return {"role": "system", "content": content}


def build_post_compaction_reminder(
    agent_name: str,
    workspace: Path,
    user_task: str,
) -> list[dict[str, Any]]:
    """Build reminder messages to inject after context compaction.

    Re-reads MEMORY.md from disk (since compaction may have discarded
    the original memory content from the conversation) and includes
    a task-focus reminder.

    Args:
        agent_name: The agent's configured name.
        workspace: Path to the workspace root.
        user_task: The original user request (first ~200 chars).

    Returns:
        A list of system message dicts containing at least a task-focus
        reminder, and optionally one or more memory reload messages if
        MEMORY.md files exist.
    """
    messages: list[dict[str, Any]] = []

    # Re-read shared memory first (matches ContextBuilder order: shared before agent)
    shared_memory = Path.home() / ".workpilot" / "memory" / "shared" / "MEMORY.md"
    if shared_memory.is_file():
        try:
            content = shared_memory.read_text(encoding="utf-8").strip()
            if content:
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            f"[Post-Compaction Shared Memory Reload]\n{content[:_MEMORY_CAP]}"
                        ),
                    }
                )
        except OSError:
            pass

    # Then re-read agent-specific MEMORY.md
    memory_path = Path.home() / ".workpilot" / "MEMORY.md"
    if memory_path.is_file():
        try:
            memory = memory_path.read_text(encoding="utf-8").strip()
            if memory:
                messages.append(
                    {
                        "role": "system",
                        "content": (f"[Post-Compaction Memory Reload]\n{memory[:_MEMORY_CAP]}"),
                    }
                )
                logger.debug("Re-read MEMORY.md after compaction ({} chars)", len(memory))
        except OSError as exc:
            logger.warning("Failed to re-read MEMORY.md after compaction: {}", exc)

    # Task focus reminder
    task_preview = user_task[:200] + ("..." if len(user_task) > 200 else "")
    messages.append(
        {
            "role": "system",
            "content": (
                "[Post-Compaction Reminder]\n"
                f"You are {agent_name}. Context was compacted to save space.\n"
                f"Current task: {task_preview}\n"
                "Continue where you left off. Key context has been preserved above."
            ),
        }
    )

    return messages


def build_post_spawn_reminder(
    agent_name: str,
    user_task: str,
    child_agent_name: str,
) -> dict[str, Any]:
    """Build a reminder to inject after sub-agent results arrive.

    Reminds the parent agent about its own task after processing
    delegated sub-agent output.

    Args:
        agent_name: The parent agent's configured name.
        user_task: The original user request (first ~200 chars).
        child_agent_name: Name of the sub-agent that just returned.

    Returns:
        A system message dict.
    """
    task_preview = user_task[:200] + ("..." if len(user_task) > 200 else "")
    return {
        "role": "system",
        "content": (
            "[Sub-Agent Complete]\n"
            f"Sub-agent '{child_agent_name}' has returned its results above.\n"
            f"You are {agent_name}. Integrate the sub-agent results and "
            f"continue with your task: {task_preview}"
        ),
    }


class ReminderTracker:
    """Tracks tool-call count and determines when to inject reminders.

    Usage in the agent loop::

        tracker = ReminderTracker(interval=10, agent_name="WorkPilot", user_task="...")
        # After each batch of tool calls:
        tracker.record_tool_calls(len(tool_calls))
        if tracker.should_inject():
            messages.append(tracker.build_reminder())
    """

    def __init__(
        self,
        *,
        interval: int,
        agent_name: str,
        user_task: str,
        workspace: Path,
    ) -> None:
        self._interval = interval
        self._agent_name = agent_name
        self._user_task = user_task
        self._workspace = workspace
        self._tool_call_count: int = 0
        self._last_reminder_at: int = 0

    @property
    def tool_call_count(self) -> int:
        """Total tool calls recorded so far."""
        return self._tool_call_count

    def record_tool_calls(self, count: int) -> None:
        """Record that ``count`` tool calls were executed."""
        self._tool_call_count += count

    def should_inject(self) -> bool:
        """Return True if a periodic reminder should be injected now."""
        if self._interval <= 0:
            return False
        calls_since = self._tool_call_count - self._last_reminder_at
        return calls_since >= self._interval

    def build_reminder(self) -> dict[str, Any]:
        """Build and return a periodic reminder, updating internal state."""
        self._last_reminder_at = self._tool_call_count
        logger.debug(
            "Injecting periodic reminder at tool-call count {}",
            self._tool_call_count,
        )
        return build_periodic_reminder(self._agent_name, self._user_task)

    def build_post_compaction_reminders(self) -> list[dict[str, Any]]:
        """Build reminders to inject after context compaction."""
        self._last_reminder_at = self._tool_call_count
        return build_post_compaction_reminder(
            self._agent_name,
            self._workspace,
            self._user_task,
        )

    def build_post_spawn_reminder(self, child_agent_name: str) -> dict[str, Any]:
        """Build a reminder after a sub-agent returns results."""
        return build_post_spawn_reminder(
            self._agent_name,
            self._user_task,
            child_agent_name,
        )
