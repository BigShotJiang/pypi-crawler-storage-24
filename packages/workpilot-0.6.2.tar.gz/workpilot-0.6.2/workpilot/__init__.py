"""WorkPilot — Enterprise AI assistant with Microsoft ecosystem integration."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("workpilot")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
