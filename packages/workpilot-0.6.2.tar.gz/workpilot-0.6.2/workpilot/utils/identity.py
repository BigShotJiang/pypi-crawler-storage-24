"""
User identity persistence — writes Entra ID claims to USER.md.

Called after any successful Entra ID authentication (cloud channel,
local WebSocket with Entra JWT, device code flow).  The ## Identity
block is updated in-place; all other USER.md content is preserved.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from loguru import logger

_IDENTITY_HEADER = "## Identity"
_IDENTITY_RE = re.compile(
    r"^## Identity\r?\n(?:- [^\r\n]*\r?\n)*",
    re.MULTILINE,
)

# Max length for any single claim value (characters) to limit prompt bloat.
_MAX_CLAIM_LEN = 120


def _sanitize(value: str) -> str:
    """Strip control characters and enforce a length limit.

    Prevents prompt injection via display names or UPNs that contain
    newlines or other control characters.
    """
    # Replace all control characters (including \\r, \\n, \\t, etc.) with space
    sanitized = re.sub(r"[\x00-\x1f\x7f]", " ", value).strip()
    return sanitized[:_MAX_CLAIM_LEN]


def _resolve_user_md(user_file: str | None) -> Path:
    """Resolve USER.md path. Default: ~/.workpilot/USER.md."""
    if user_file:
        p = Path(user_file).expanduser()
        if p.is_absolute():
            return p
        return Path.home() / ".workpilot" / p
    return Path.home() / ".workpilot" / "USER.md"


def save_identity(
    claims: dict[str, Any],
    workspace: Path,
    user_file: str | None = None,
) -> None:
    """Write Entra ID claims into the ## Identity block of USER.md.

    Parameters
    ----------
    claims:
        Decoded id_token claims from Entra ID.
    workspace:
        Agent workspace directory (unused when writing to default path).
    user_file:
        Optional override path from AgentConfig.user_file.  When set,
        identity is written there instead of ~/.workpilot/USER.md.

    Default path: ``~/.workpilot/USER.md``.
    Creates the file if it doesn't exist.  Replaces the ## Identity block
    if present, otherwise prepends it.  All other content is preserved.
    Uses atomic rename + restrictive permissions on POSIX.
    Silently skips if no usable claims are found.
    """
    name = _sanitize(claims.get("name") or "")
    email = _sanitize(claims.get("preferred_username") or "")
    oid = _sanitize(claims.get("oid") or "")
    tid = _sanitize(claims.get("tid") or "")

    if not any([name, email, oid]):
        return  # nothing useful to write

    # Derive organization from email domain
    org = ""
    if email and "@" in email:
        org = email.split("@", 1)[1]

    lines = [_IDENTITY_HEADER]
    if name:
        lines.append(f"- Name: {name}")
    if email:
        lines.append(f"- Email: {email}")
    if org:
        lines.append(f"- Organization: {org}")
    if oid:
        lines.append(f"- OID: {oid}")
    if tid:
        lines.append(f"- Tenant: {tid}")
    block = "\n".join(lines) + "\n"

    user_md = _resolve_user_md(user_file)
    user_md.parent.mkdir(parents=True, exist_ok=True)

    try:
        existing = user_md.read_text(encoding="utf-8") if user_md.exists() else ""

        if _IDENTITY_RE.search(existing):
            updated = _IDENTITY_RE.sub(block, existing, count=1)
        elif existing.strip():
            updated = block + "\n" + existing
        else:
            updated = "# User\n\n" + block

        # Atomic write: write to .tmp then rename (same pattern as MSAL cache)
        tmp = user_md.with_suffix(".tmp")
        tmp.write_text(updated, encoding="utf-8")
        try:
            # Restrict permissions on POSIX — USER.md contains PII
            if os.name == "posix":
                tmp.chmod(0o600)
        except (NotImplementedError, OSError):
            pass
        tmp.replace(user_md)

        logger.debug("Identity saved to USER.md (name={}, oid={})", name or "—", oid or "—")
    except Exception as exc:
        logger.warning("Failed to save identity to USER.md: {}", exc)
