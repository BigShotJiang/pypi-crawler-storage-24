"""Bundled defaults loader.

Loads packaged default files (identity, config) via importlib.resources.
Works both from source checkouts and pip-installed wheels.
"""

from __future__ import annotations

from importlib.resources import files

_DEFAULT_NAMES = {
    "SOUL.md",
    "AGENTS.md",
    "TOOLS.md",
    "HEARTBEAT.md",
    "SECURITY.md",  # bundled only — not user-overridable
    "USER.md",
    "MEMORY.md",
}


def load_builtin_default(name: str) -> str:
    """Return bundled default content for a known file name.

    Raises:
        ValueError: if the name is not in the allowlist.
        FileNotFoundError: if packaged data is missing.
    """
    if name not in _DEFAULT_NAMES:
        raise ValueError(f"Unsupported default: {name}")
    resource = files("workpilot.defaults").joinpath(name)
    return resource.read_text(encoding="utf-8").strip()
