"""
Session manager — JSONL-based conversation persistence with in-memory cache.

Sessions are keyed by (channel, sender_id). Each session stores the
conversation history as append-only JSONL for crash safety.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any


class SessionManager:
    """Manages conversation sessions with optional JSONL persistence."""

    def __init__(self, data_dir: Path | None = None) -> None:
        self._data_dir = data_dir
        if self._data_dir:
            self._data_dir.mkdir(parents=True, exist_ok=True)
        self._sessions: dict[str, list[dict[str, Any]]] = {}

    def list_sessions(self) -> list[dict[str, Any]]:
        """List all known sessions with metadata.

        Returns in-memory sessions first, then loads any on-disk sessions
        not yet cached.
        """
        # Load all on-disk sessions into memory
        if self._data_dir and self._data_dir.exists():
            for path in self._data_dir.glob("*.jsonl"):
                sid = path.stem.replace("_", ":")
                if sid not in self._sessions:
                    self._sessions[sid] = self._load_from_disk(sid)

        return [
            {"session_id": sid, "message_count": len(msgs)}
            for sid, msgs in self._sessions.items()
            if msgs  # skip empty sessions
        ]

    def get_or_create_id(self, channel: str, sender_id: str) -> str:
        """Get a deterministic session ID for a channel+sender pair."""
        key = f"{channel}:{sender_id}"
        return key

    # Roles accepted by LLM APIs — any other roles are UI-only metadata
    _LLM_ROLES: frozenset[str] = frozenset({"user", "assistant", "system", "tool"})

    def get_messages(self, session_id: str, llm_only: bool = False) -> list[dict[str, Any]]:
        """Get conversation history for a session.

        Parameters
        ----------
        llm_only:
            If True, filter out non-LLM roles (e.g. ``approval_request``)
            that are stored for UI purposes but rejected by the LLM API.
        """
        if session_id not in self._sessions:
            self._sessions[session_id] = self._load_from_disk(session_id)
        msgs = self._sessions[session_id]
        if llm_only:
            return [m for m in msgs if m.get("role") in self._LLM_ROLES]
        return msgs

    def add_message(self, session_id: str, message: dict[str, Any]) -> None:
        """Append a message to the session history."""
        if session_id not in self._sessions:
            self._sessions[session_id] = self._load_from_disk(session_id)
        self._sessions[session_id].append(message)
        self._persist(session_id, message)

    def clear(self, session_id: str) -> None:
        """Clear a session's history."""
        self._sessions[session_id] = []
        if self._data_dir:
            path = self._session_path(session_id)
            if path.exists():
                path.unlink()

    def trim(self, session_id: str, keep_last: int) -> list[dict[str, Any]]:
        """
        Trim session to keep only the last N messages.
        Returns the trimmed (removed) messages for memory consolidation.

        The split point is adjusted so tool-call groups (assistant with
        tool_calls + tool results) are never broken apart.
        """
        messages = self.get_messages(session_id)
        if len(messages) <= keep_last:
            return []

        # Find safe split point that doesn't break tool-call groups
        idx = len(messages) - keep_last
        while idx > 0 and messages[idx].get("role") == "tool":
            idx -= 1

        trimmed = messages[:idx]
        self._sessions[session_id] = messages[idx:]

        # Rewrite JSONL
        if self._data_dir:
            path = self._session_path(session_id)
            with path.open("w", encoding="utf-8") as f:
                for msg in self._sessions[session_id]:
                    f.write(json.dumps(msg, default=str, ensure_ascii=False) + "\n")

        return trimmed

    def fork(self, session_id: str) -> str:
        """Create a linked empty branch for sub-agents.

        The forked session has empty history but is linked to the parent
        for tracking purposes.
        """
        fork_id = f"{session_id}:fork:{uuid.uuid4().hex[:8]}"
        self._sessions[fork_id] = []
        return fork_id

    def generate_id(self) -> str:
        return str(uuid.uuid4())

    def _session_path(self, session_id: str) -> Path:
        safe_id = session_id.replace(":", "_").replace("/", "_")
        return self._data_dir / f"{safe_id}.jsonl" if self._data_dir else Path("/dev/null")

    def _load_from_disk(self, session_id: str) -> list[dict[str, Any]]:
        if not self._data_dir:
            return []
        path = self._session_path(session_id)
        if not path.exists():
            return []
        messages: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    messages.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return messages

    def _persist(self, session_id: str, message: dict[str, Any]) -> None:
        if not self._data_dir:
            return
        path = self._session_path(session_id)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(message, default=str, ensure_ascii=False) + "\n")
