"""Security CLI subcommands — workpilot security audit|credentials|roles|allowlist|status|estop|reset + secrets set|remove|test."""

from __future__ import annotations

import os
from pathlib import Path

import typer
from rich.panel import Panel
from rich.table import Table

from workpilot.cli.commands import (
    _get_runtime,
    _load_config_safe,
    console,
    secrets_app,
    security_app,
)

# ═══════════════════════════════════════════════════════════════════════════
# security sub-commands
# ═══════════════════════════════════════════════════════════════════════════


@security_app.command("audit")
def security_audit(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show security audit configuration and recent events."""
    cfg = _load_config_safe(config)

    console.print(Panel("[bold]Security Audit[/bold]", title="Audit", border_style="blue"))

    table = Table(title="Audit Configuration")
    table.add_column("Setting", style="bold")
    table.add_column("Value")

    table.add_row(
        "Enabled", "[green]yes[/green]" if cfg.security.audit.enabled else "[red]no[/red]"
    )
    table.add_row(
        "Redact secrets",
        "[green]yes[/green]" if cfg.security.audit.redact_secrets else "[red]no[/red]",
    )
    table.add_row("Log file", cfg.security.audit.log_file or "[dim]stderr (default)[/dim]")

    console.print(table)

    # Show recent audit entries if a log file is configured
    audit_file = cfg.security.audit.log_file
    if audit_file:
        audit_path = Path(audit_file)
        if audit_path.exists():
            import json

            all_lines = audit_path.read_text(encoding="utf-8").splitlines()
            recent = all_lines[-10:]
            console.print(f"\n[bold]Recent audit events[/bold] (last {len(recent)}):")
            for line in recent:
                try:
                    entry = json.loads(line)
                    event = entry.get("event", "unknown")
                    ts = entry.get("ts", "")
                    console.print(f"  [{ts}] {event}")
                except json.JSONDecodeError:
                    continue
        else:
            console.print(f"\n[dim]Audit log file does not exist yet: {audit_path}[/dim]")

    # Sandbox summary
    console.print("\n[bold]Sandbox[/bold]")
    console.print(f"  Shell deny patterns:    {len(cfg.tools.shell.deny_patterns)}")
    console.print(f"  Shell timeout:          {cfg.tools.shell.timeout}s")
    console.print(f"  File size limit:        {cfg.tools.filesystem.max_file_size_bytes:,} bytes")
    console.print(f"  Workspace restriction:  {cfg.tools.filesystem.restrict_to_workspace}")
    console.print(f"  Denied paths:           {len(cfg.tools.filesystem.deny_paths)}")


@security_app.command("credentials")
def security_credentials(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show credential provider status (never shows actual values)."""
    _load_config_safe(config)

    console.print(Panel("[bold]Credential Status[/bold]", border_style="blue"))

    table = Table(title="Credentials")
    table.add_column("Credential", style="bold")
    table.add_column("Source")
    table.add_column("Status")

    creds_to_check = [
        ("GITHUB_TOKEN", "GitHub Copilot"),
        ("OPENAI_API_KEY", "OpenAI"),
        ("AZURE_API_KEY", "Azure (OpenAI / AI Foundry)"),
        ("AZURE_OPENAI_API_KEY", "Azure OpenAI (legacy)"),
        ("AZURE_AI_FOUNDRY_API_KEY", "Azure AI Foundry (legacy)"),
    ]

    for env_var, purpose in creds_to_check:
        val = os.environ.get(env_var, "")
        if val:
            table.add_row(env_var, purpose, "[green]set[/green]")
        else:
            table.add_row(env_var, purpose, "[dim]not set[/dim]")

    console.print(table)

    console.print("\n  Provider: [bold]env[/bold]")


@security_app.command("roles")
def security_roles(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show configured RBAC roles."""
    cfg = _load_config_safe(config)

    console.print(Panel("[bold]RBAC Roles[/bold]", border_style="blue"))

    if not cfg.security.roles:
        console.print("[dim]No custom RBAC roles defined.[/dim]")
        console.print(f"  Default role: [bold]{cfg.security.default_role}[/bold]")
        console.print(f"  Require auth: {cfg.security.require_auth}")
        return

    table = Table(title="Roles")
    table.add_column("Role", style="bold")
    table.add_column("Allowed Tools")
    table.add_column("Denied Tools")
    table.add_column("Channels")
    table.add_column("Max Iter")

    for role_name, role in cfg.security.roles.items():
        is_default = " *" if role_name == cfg.security.default_role else ""
        table.add_row(
            role_name + is_default,
            ", ".join(role.allowed_tools),
            ", ".join(role.denied_tools) or "[dim]none[/dim]",
            ", ".join(role.allowed_channels),
            str(role.max_iterations),
        )

    console.print(table)
    console.print(f"\n  Default role: [bold]{cfg.security.default_role}[/bold]")
    console.print(f"  Require auth: {cfg.security.require_auth}")

    # Show security profile autonomy defaults
    try:
        from workpilot.security.rbac import PolicyEngine

        engine = PolicyEngine(cfg.security)
        profile_defaults = engine.PROFILE_DEFAULTS.get(cfg.security.profile, {})
        if profile_defaults:
            console.print(
                f"\n[bold]Profile '{cfg.security.profile.value}' autonomy defaults:[/bold]"
            )
            for category, level in profile_defaults.items():
                level_str = {0: "forbidden", 1: "approval", 2: "notify", 3: "autonomous"}.get(
                    level.value, str(level.value)
                )
                console.print(f"  {category:12s} -> {level_str}")
    except Exception:
        pass


@security_app.command("allowlist")
def security_allowlist(
    action: str = typer.Argument("list", help="Action: list, add, remove"),
    tool_name: str = typer.Option("", "--tool", "-t", help="Tool name (for add)"),
    pattern: str = typer.Option("", "--pattern", "-p", help="Arg regex pattern (for add)"),
    index: int = typer.Option(-1, "--index", "-i", help="Entry index (for remove)"),
    note: str = typer.Option("", "--note", "-n", help="Note (for add)"),
) -> None:
    """Manage the per-user tool approval allowlist."""
    from workpilot.security.allowlist import AllowlistManager

    mgr = AllowlistManager()

    if action == "list":
        entries = mgr.list_entries()
        if not entries:
            console.print("[dim]No allowlist entries.[/dim]")
            return
        table = Table(title="Tool Approval Allowlist")
        table.add_column("#", style="dim")
        table.add_column("Tool", style="bold")
        table.add_column("Arg Pattern")
        table.add_column("Added By")
        table.add_column("Note")
        for i, entry in enumerate(entries):
            table.add_row(
                str(i),
                entry.tool_name,
                entry.arg_pattern or "[dim]*[/dim]",
                entry.added_by or "[dim]unknown[/dim]",
                entry.note or "",
            )
        console.print(table)

    elif action == "add":
        if not tool_name:
            console.print("[red]--tool is required for add[/red]")
            raise typer.Exit(1)
        entry = mgr.add(
            tool_name,
            arg_pattern=pattern or None,
            added_by="cli",
            note=note,
        )
        console.print(f"[green]Added:[/green] {entry.tool_name} (pattern={entry.arg_pattern})")

    elif action == "remove":
        if index < 0:
            console.print("[red]--index is required for remove[/red]")
            raise typer.Exit(1)
        try:
            entry = mgr.remove(index)
            console.print(f"[green]Removed:[/green] {entry.tool_name}")
        except IndexError:
            console.print(f"[red]Index {index} out of range[/red]")
            raise typer.Exit(1)

    else:
        console.print(f"[red]Unknown action: {action}. Use list, add, or remove.[/red]")
        raise typer.Exit(1)


@security_app.command("status")
def security_status(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show security profile and E-stop state."""
    cfg = _load_config_safe(config)
    s = cfg.security

    table = Table(title="Security Status")
    table.add_column("Setting", style="bold")
    table.add_column("Value")
    table.add_row("Profile", s.profile.value)
    table.add_row("Audit enabled", "[green]yes[/green]" if s.audit.enabled else "[red]no[/red]")
    table.add_row(
        "Redact secrets", "[green]yes[/green]" if s.audit.redact_secrets else "[red]no[/red]"
    )
    table.add_row("E-stop on leak", "[green]yes[/green]" if s.estop.trigger_on_leak else "no")
    table.add_row("Require auth", "[green]yes[/green]" if s.require_auth else "no")
    console.print(table)
    console.print("\n[dim]To trigger E-stop: workpilot security estop[/dim]")


@security_app.command("estop")
def security_estop(
    reason: str = typer.Option("manual", "--reason", "-r", help="Reason for E-stop"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Trigger emergency stop — halts all agent activity."""
    if not yes:
        typer.confirm("[red]Trigger emergency stop?[/red] All tasks will be halted.", abort=True)
    rt = _get_runtime(config)
    rt.estop.trigger(reason, actor="cli-user")
    console.print(f"[red bold]E-stop triggered:[/red bold] {reason}")
    console.print("Run [cyan]workpilot security reset[/cyan] to resume.")


@security_app.command("reset")
def security_reset(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Reset E-stop and resume normal operation."""
    if not yes:
        typer.confirm("Reset E-stop and resume agent activity?", abort=True)
    rt = _get_runtime(config)
    rt.estop.reset(actor="cli-user")
    console.print("[green]E-stop reset. Agent activity resumed.[/green]")


# ═══════════════════════════════════════════════════════════════════════════
# secrets sub-commands (set, remove, test)
# ═══════════════════════════════════════════════════════════════════════════


@secrets_app.command("set")
def secrets_set(
    name: str = typer.Argument(..., help="Secret name (e.g. GITHUB_TOKEN)"),
    from_env: str | None = typer.Option(None, "--from-env", help="Copy value from env var"),
) -> None:
    """Set a secret in the local credential store."""
    try:
        import keyring  # type: ignore[import]
    except ImportError:
        console.print("[red]keyring not installed.[/red] Run: pip install keyring")
        raise typer.Exit(1)

    if from_env:
        value = os.environ.get(from_env)
        if not value:
            console.print(f"[red]Env var not set:[/red] {from_env}")
            raise typer.Exit(1)
        console.print(f"Copying {from_env} → credential store as {name}")
    else:
        import getpass

        value = getpass.getpass(f"Enter value for {name}: ")
        if not value:
            console.print("[red]Value cannot be empty.[/red]")
            raise typer.Exit(1)

    keyring.set_password("workpilot", name, value)
    console.print(f"[green]Secret stored:[/green] {name}")


@secrets_app.command("remove")
def secrets_remove(
    name: str = typer.Argument(..., help="Secret name to remove"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Remove a secret from the local credential store."""
    try:
        import keyring  # type: ignore[import]
    except ImportError:
        console.print("[red]keyring not installed.[/red] Run: pip install keyring")
        raise typer.Exit(1)

    if not yes:
        typer.confirm(f"Remove secret '{name}'?", abort=True)
    try:
        keyring.delete_password("workpilot", name)
        console.print(f"[green]Removed:[/green] {name}")
    except keyring.errors.PasswordDeleteError:
        console.print(f"[red]Secret not found:[/red] {name}")
        raise typer.Exit(1)


@secrets_app.command("test")
def secrets_test(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Test configured secrets by making minimal API calls."""
    cfg = _load_config_safe(config)

    results: list[tuple[str, str, str]] = []

    # GitHub token
    gh_token = (
        cfg.providers.github_copilot.token.get_secret_value()
        if cfg.providers.github_copilot.token
        else os.environ.get("GITHUB_TOKEN", "")
    )
    if gh_token:
        try:
            import urllib.request

            req = urllib.request.Request(
                "https://api.github.com/user",
                headers={"Authorization": f"Bearer {gh_token}", "User-Agent": "WorkPilot"},
            )
            with urllib.request.urlopen(req, timeout=5) as r:  # noqa: S310
                import json as _json

                user = _json.loads(r.read())["login"]
            results.append(("GITHUB_TOKEN", "[green]valid[/green]", f"@{user}"))
        except Exception as exc:
            results.append(("GITHUB_TOKEN", "[red]invalid[/red]", str(exc)[:60]))
    else:
        results.append(("GITHUB_TOKEN", "[dim]not set[/dim]", ""))

    # OpenAI
    oai_key = (
        cfg.providers.openai.api_key.get_secret_value()
        if cfg.providers.openai.api_key
        else os.environ.get("OPENAI_API_KEY", "")
    )
    if oai_key:
        try:
            import urllib.request

            req = urllib.request.Request(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {oai_key}"},
            )
            with urllib.request.urlopen(req, timeout=5) as r:  # noqa: S310
                pass
            results.append(("OPENAI_API_KEY", "[green]valid[/green]", ""))
        except Exception as exc:
            results.append(("OPENAI_API_KEY", "[red]invalid[/red]", str(exc)[:60]))
    else:
        results.append(("OPENAI_API_KEY", "[dim]not set[/dim]", ""))

    table = Table(title="Secrets Test")
    table.add_column("Secret", style="bold")
    table.add_column("Status")
    table.add_column("Info")
    for sname, status, info in results:
        table.add_row(sname, status, info)
    console.print(table)
