"""Cron CLI subcommands — workpilot cron list|add|remove|enable|disable|status|history."""

from __future__ import annotations

import typer
import yaml
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    console,
    cron_app,
)
from workpilot.cli.commands import (
    resolve_config_path as _resolve_config_path,
)
from workpilot.cli.commands import (
    resolve_local_config_path as _resolve_local_config_path,
)


@cron_app.command("list")
def cron_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List configured cron jobs."""
    cfg = _load_config_safe(config)

    if not cfg.cron.enabled:
        console.print("[dim]Cron service is disabled.[/dim]")
        console.print("  Set [bold]cron.enabled: true[/bold] in workpilot.yaml")
        return

    jobs = cfg.cron.jobs
    if not jobs:
        console.print("[dim]No cron jobs configured.[/dim]")
        return

    table = Table(title="Cron Jobs")
    table.add_column("Name", style="bold")
    table.add_column("Schedule")
    table.add_column("Agent")
    table.add_column("Prompt")
    table.add_column("Enabled")

    for name, job in jobs.items():
        prompt_preview = job.prompt[:50] + "..." if len(job.prompt) > 50 else job.prompt
        table.add_row(
            name,
            str(job.schedule),
            job.agent,
            prompt_preview,
            "[green]yes[/green]" if job.enabled else "[red]no[/red]",
        )

    console.print(table)


@cron_app.command("add")
def cron_add(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add a cron job interactively (writes to workpilot.local.yaml)."""
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    name: str = typer.prompt("Job name")
    schedule: str = typer.prompt("Cron schedule (e.g. '0 9 * * 1-5' for weekdays at 9am)")
    agent_name: str = typer.prompt("Agent name", default="default")
    prompt: str = typer.prompt("Prompt")

    # Read local override to update (never touch the base workpilot.yaml)
    local_raw = (
        yaml.safe_load(local_path.read_text(encoding="utf-8")) if local_path.is_file() else {}
    )
    local_raw = local_raw or {}
    cron_section = local_raw.setdefault("cron", {})
    cron_section["enabled"] = True
    jobs_section = cron_section.setdefault("jobs", {})
    jobs_section[name] = {
        "schedule": schedule,
        "agent": agent_name,
        "prompt": prompt,
        "enabled": True,
    }

    local_path.write_text(
        yaml.dump(local_raw, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(f"[green]Cron job '{name}' added to {local_path}[/green]")


@cron_app.command("remove")
def cron_remove(
    job_id: str = typer.Argument(..., help="Job name to remove"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Remove a cron job from config."""
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    # Check existence against merged config
    merged_cfg = _load_config_safe(str(config_path.parent))
    if job_id not in merged_cfg.cron.jobs:
        console.print(f"[red]Job not found:[/red] {job_id}")
        raise typer.Exit(1)

    if not yes:
        typer.confirm(f"Remove job '{job_id}'?", abort=True)

    removed_from: list[str] = []

    # Remove from local override if present
    if local_path.is_file():
        local_raw = yaml.safe_load(local_path.read_text(encoding="utf-8")) or {}
        local_jobs = local_raw.get("cron", {}).get("jobs", {})
        if job_id in local_jobs:
            del local_jobs[job_id]
            local_path.write_text(
                yaml.dump(local_raw, default_flow_style=False, sort_keys=False),
                encoding="utf-8",
            )
            removed_from.append(str(local_path))

    # Remove from base config if present
    if config_path.is_file():
        base_raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        base_jobs = base_raw.get("cron", {}).get("jobs", {})
        if job_id in base_jobs:
            del base_jobs[job_id]
            config_path.write_text(
                yaml.dump(base_raw, default_flow_style=False, sort_keys=False),
                encoding="utf-8",
            )
            removed_from.append(str(config_path))

    if removed_from:
        console.print(f"[green]Removed job '{job_id}' from {', '.join(removed_from)}[/green]")
    else:
        console.print(
            f"[yellow]Job '{job_id}' exists in merged config but was not found "
            f"in any editable file (may be inherited via extends: or bundled defaults).[/yellow]"
        )


@cron_app.command("enable")
def cron_enable(
    job_id: str = typer.Argument(..., help="Job name to enable"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Enable a disabled cron job (writes to workpilot.local.yaml)."""
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    merged_cfg = _load_config_safe(str(config_path.parent))
    if job_id not in merged_cfg.cron.jobs:
        console.print(f"[red]Job not found:[/red] {job_id}")
        raise typer.Exit(1)

    local_raw = (
        yaml.safe_load(local_path.read_text(encoding="utf-8")) if local_path.is_file() else {}
    )
    local_raw = local_raw or {}
    local_raw.setdefault("cron", {}).setdefault("jobs", {}).setdefault(job_id, {})["enabled"] = True
    local_path.write_text(
        yaml.dump(local_raw, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(f"[green]Enabled job:[/green] {job_id}")


@cron_app.command("disable")
def cron_disable(
    job_id: str = typer.Argument(..., help="Job name to disable"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Disable a cron job without removing it (writes to workpilot.local.yaml)."""
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    merged_cfg = _load_config_safe(str(config_path.parent))
    if job_id not in merged_cfg.cron.jobs:
        console.print(f"[red]Job not found:[/red] {job_id}")
        raise typer.Exit(1)

    local_raw = (
        yaml.safe_load(local_path.read_text(encoding="utf-8")) if local_path.is_file() else {}
    )
    local_raw = local_raw or {}
    local_raw.setdefault("cron", {}).setdefault("jobs", {}).setdefault(job_id, {})["enabled"] = (
        False
    )
    local_path.write_text(
        yaml.dump(local_raw, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(f"[yellow]Disabled job:[/yellow] {job_id}")


@cron_app.command("status")
def cron_status(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show scheduler health and job counts."""
    cfg = _load_config_safe(config)
    enabled = cfg.cron.enabled
    jobs = cfg.cron.jobs
    enabled_count = sum(1 for j in jobs.values() if getattr(j, "enabled", True))

    table = Table(title="Cron Status")
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Enabled", "[green]yes[/green]" if enabled else "[red]no[/red]")
    table.add_row("Total jobs", str(len(jobs)))
    table.add_row("Enabled jobs", str(enabled_count))
    table.add_row("Disabled jobs", str(len(jobs) - enabled_count))
    console.print(table)


@cron_app.command("history")
def cron_history(
    job_id: str | None = typer.Argument(None, help="Job name (omit for all jobs)"),
    lines: int = typer.Option(20, "--lines", "-n", help="Max entries to show per job"),
) -> None:
    """Show execution history for cron jobs."""
    import json as _json

    from workpilot.utils.helpers import get_data_dir

    runs_dir = get_data_dir() / "cron" / "runs"
    if not runs_dir.exists():
        console.print("[dim]No cron run history found.[/dim]")
        return

    files = sorted(runs_dir.glob("*.jsonl"))
    if job_id:
        safe = job_id.replace("/", "_").replace(":", "_")
        files = [f for f in files if f.stem == safe or f.stem == job_id]
        if not files:
            console.print(f"[red]No history for job:[/red] {job_id}")
            return

    for path in files:
        records = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                try:
                    records.append(_json.loads(line))
                except Exception:
                    pass
        records = records[-lines:]
        if not records:
            continue

        table = Table(title=f"Job: {path.stem}")
        table.add_column("Run ID", style="dim")
        table.add_column("Started")
        table.add_column("Status")
        table.add_column("Duration")
        table.add_column("Result preview")
        for r in records:
            status = r.get("status", "?")
            colour = "green" if status == "success" else "red"
            table.add_row(
                r.get("run_id", "?")[:12],
                r.get("triggered_at", "?")[:19],
                f"[{colour}]{status}[/{colour}]",
                f"{r.get('duration_s', 0):.1f}s",
                (r.get("result_preview") or r.get("error", ""))[:60],
            )
        console.print(table)
