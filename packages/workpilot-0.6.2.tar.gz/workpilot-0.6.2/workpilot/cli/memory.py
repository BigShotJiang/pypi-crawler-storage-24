"""Memory CLI subcommands — workpilot memory show|search|clear|stats."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    console,
    memory_app,
)


@memory_app.command("show")
def memory_show(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show current MEMORY.md content."""
    from workpilot.agent.memory import MemoryStore

    cfg = _load_config_safe(config)
    workspace = Path(cfg.agents.default.workspace).resolve()
    store = MemoryStore(workspace)
    content = store.read_shared()
    if not content.strip():
        console.print("[dim]MEMORY.md is empty.[/dim]")
    else:
        from rich.markdown import Markdown

        console.print(Markdown(content))


@memory_app.command("search")
def memory_search(
    query: str = typer.Argument(..., help="Search query"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Search session history for a query string."""
    import json as _json

    from workpilot.utils.helpers import get_sessions_dir

    _load_config_safe(config)
    sessions_dir = get_sessions_dir()
    hits: list[tuple[str, str, str]] = []

    for path in sorted(sessions_dir.glob("*.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                msg = _json.loads(line)
            except Exception:  # noqa: S112
                continue
            content = msg.get("content") or ""
            if isinstance(content, list):
                content = " ".join(p.get("text", "") for p in content if isinstance(p, dict))
            if query.lower() in content.lower():
                snippet = content[:120].replace("\n", " ")
                hits.append((path.stem, msg.get("role", "?"), snippet))

    if not hits:
        console.print(f"[dim]No results for '{query}'.[/dim]")
        return

    table = Table(title=f"Search: {query}")
    table.add_column("Session", style="dim")
    table.add_column("Role")
    table.add_column("Snippet")
    for sid, role, snippet in hits[:50]:
        table.add_row(sid, role, snippet)
    console.print(table)
    if len(hits) > 50:
        console.print(f"[dim]... and {len(hits) - 50} more results.[/dim]")


@memory_app.command("clear")
def memory_clear(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Clear MEMORY.md facts (does not delete session history)."""
    from workpilot.agent.memory import MemoryStore

    cfg = _load_config_safe(config)
    workspace = Path(cfg.agents.default.workspace).resolve()

    if not yes:
        typer.confirm("Clear all facts in MEMORY.md?", abort=True)

    store = MemoryStore(workspace)
    store.write_shared("")
    console.print("[green]MEMORY.md cleared.[/green]")


@memory_app.command("stats")
def memory_stats(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show memory statistics."""
    from workpilot.agent.memory import MemoryStore
    from workpilot.utils.helpers import get_sessions_dir

    cfg = _load_config_safe(config)
    workspace = Path(cfg.agents.default.workspace).resolve()
    store = MemoryStore(workspace)

    mem_content = store.read_shared()
    mem_bytes = len(mem_content.encode())
    mem_lines = len([line for line in mem_content.splitlines() if line.strip()])

    sessions_dir = get_sessions_dir()
    session_files = list(sessions_dir.glob("*.jsonl"))
    total_session_bytes = sum(p.stat().st_size for p in session_files)

    table = Table(title="Memory Stats")
    table.add_column("Item", style="bold")
    table.add_column("Value")
    table.add_row("MEMORY.md size", f"{mem_bytes:,} bytes ({mem_bytes * 100 // 8192}% of 8KB cap)")
    table.add_row("MEMORY.md lines", str(mem_lines))
    table.add_row("Session files", str(len(session_files)))
    table.add_row("Session total size", f"{total_session_bytes / 1024:.1f} KB")
    console.print(table)
