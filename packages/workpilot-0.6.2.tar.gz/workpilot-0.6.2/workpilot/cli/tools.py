"""Tools CLI subcommands — workpilot tools list|info."""

from __future__ import annotations

import typer
from rich.panel import Panel
from rich.table import Table

from workpilot.cli.commands import (
    _get_runtime,
    _load_config_safe,
    console,
    tools_app,
)


@tools_app.command("list")
def tools_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """List all available tools (built-in + MCP)."""
    cfg = _load_config_safe(config, profile)

    table = Table(title="Built-in Tools")
    table.add_column("Tool", style="bold")
    table.add_column("Description")
    table.add_column("Risk")

    # Load risk levels from RBAC module
    try:
        from workpilot.security.rbac import TOOL_CATEGORIES
    except ImportError:
        TOOL_CATEGORIES = {}

    builtin_tools = [
        ("shell", "Execute shell commands"),
        ("read_file", "Read file contents"),
        ("write_file", "Write or create files"),
        ("edit_file", "Edit files with search/replace"),
        ("list_dir", "List directory contents"),
        ("git", "Git operations"),
        ("http_request", "Make HTTP requests"),
        ("browser", "Browser automation (Playwright)"),
        ("send_message", "Send messages via channels"),
        ("spawn_agent", "Spawn sub-agent"),
    ]

    for tool_name, description in builtin_tools:
        risk = TOOL_CATEGORIES.get(tool_name, "medium")
        risk_str = str(risk.value) if hasattr(risk, "value") else str(risk)
        risk_display = {
            "low": "[green]low[/green]",
            "medium": "[yellow]medium[/yellow]",
            "high": "[red]high[/red]",
            "critical": "[bold red]critical[/bold red]",
        }.get(risk_str, risk_str)
        table.add_row(tool_name, description, risk_display)

    console.print(table)

    # MCP tools
    mcp_servers = cfg.tools.mcp_servers
    if mcp_servers:
        mcp_table = Table(title="MCP Servers")
        mcp_table.add_column("Name", style="bold")
        mcp_table.add_column("Transport")
        mcp_table.add_column("Command / URL")

        for name, srv in mcp_servers.items():
            if srv.command:
                cmd_display = f"{srv.command} {' '.join(srv.args)}"
                mcp_table.add_row(name, "stdio", cmd_display)
            elif srv.url:
                mcp_table.add_row(name, "http", srv.url)
            else:
                mcp_table.add_row(name, "[dim]unknown[/dim]", "")

        console.print(mcp_table)
    else:
        console.print("\n[dim]No MCP servers configured.[/dim]")


@tools_app.command("info")
def tools_info(
    name: str = typer.Argument(..., help="Tool name"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show detailed info for a specific tool."""
    import json as _json

    rt = _get_runtime(config)
    tool = rt.tool_registry.get(name)
    if tool is None:
        console.print(f"[red]Tool not found:[/red] {name}")
        raise typer.Exit(1)

    console.print(Panel(f"[bold]{tool.name}[/bold]", border_style="blue"))
    console.print(f"[bold]Description:[/bold] {tool.description}\n")

    m = tool.metadata
    table = Table(title="Metadata")
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Risk level", m.risk_level)
    table.add_row("Approval", m.approval)
    table.add_row("Timeout", f"{m.timeout}s")
    table.add_row("Streaming", str(m.streaming))
    table.add_row("Category", m.category)
    console.print(table)

    console.print("\n[bold]Parameters (JSON Schema):[/bold]")
    console.print(_json.dumps(tool.parameters, indent=2))
