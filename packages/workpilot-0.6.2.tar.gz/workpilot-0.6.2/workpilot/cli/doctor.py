"""workpilot doctor — health diagnostics command."""

from __future__ import annotations

import os
import sys

import typer
from rich.panel import Panel

from workpilot.config.loader import load_config
from workpilot.config.schema import AppConfig


def doctor(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Run health diagnostics and report issues."""
    from workpilot.cli.commands import console

    console.print(Panel("[bold]WorkPilot Doctor[/bold]", title="Diagnostics", border_style="blue"))
    issues: list[str] = []
    warnings: list[str] = []

    # 1. Python version
    py_version = sys.version_info
    if py_version >= (3, 11):
        console.print(
            f"  [green]PASS[/green]  Python {py_version.major}.{py_version.minor}.{py_version.micro}"
        )
    else:
        msg = f"Python >= 3.11 required, found {py_version.major}.{py_version.minor}"
        console.print(f"  [red]FAIL[/red]  {msg}")
        issues.append(msg)

    # 2. Config validity
    try:
        cfg = load_config(config, profile)
        console.print("  [green]PASS[/green]  Configuration valid")
    except Exception as exc:
        msg = f"Config error: {exc}"
        console.print(f"  [red]FAIL[/red]  {msg}")
        issues.append(msg)
        # Cannot continue most checks without config
        _doctor_summary(issues, warnings)
        return

    # 3. LLM provider connectivity
    _doctor_check_provider(cfg, issues, warnings)

    # 4. Required packages
    _doctor_check_packages(cfg, issues, warnings)

    # 5. Tool availability
    _doctor_check_tools(cfg, issues, warnings)

    # 6. Credentials
    _doctor_check_credentials(cfg, issues, warnings)

    _doctor_summary(issues, warnings)


def _doctor_check_provider(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check whether the LLM provider keys are set."""
    from workpilot.cli.commands import console

    github_token = os.environ.get("GITHUB_TOKEN", "") or (
        cfg.providers.github_copilot.token.get_secret_value()
        if cfg.providers.github_copilot.token
        else ""
    )
    openai_key = (
        cfg.providers.openai.api_key.get_secret_value() if cfg.providers.openai.api_key else ""
    ) or os.environ.get("OPENAI_API_KEY", "")
    azure_key = (
        os.environ.get("AZURE_API_KEY")
        or os.environ.get("AZURE_OPENAI_API_KEY")
        or os.environ.get("AZURE_AI_FOUNDRY_API_KEY")
        or ""
    )

    has_key = any(k and not k.startswith("${") for k in [github_token, openai_key, azure_key])

    if has_key:
        console.print("  [green]PASS[/green]  LLM provider API key found")
    else:
        msg = (
            "No LLM API key found "
            "(set GITHUB_TOKEN, OPENAI_API_KEY, AZURE_API_KEY, or AZURE_AI_FOUNDRY_API_KEY)"
        )
        console.print(f"  [yellow]WARN[/yellow]  {msg}")
        warnings.append(msg)


def _doctor_check_packages(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check optional dependency packages."""
    from workpilot.cli.commands import console

    optional_deps: list[tuple[str, str, bool]] = [
        ("fastapi", "gateway server", cfg.channels.web.enabled),
        ("uvicorn", "gateway server", cfg.channels.web.enabled),
        ("apscheduler", "cron service", cfg.cron.enabled),
        ("playwright", "browser tool", cfg.tools.browser.enabled),
    ]
    for pkg, purpose, needed in optional_deps:
        try:
            __import__(pkg)
            console.print(f"  [green]PASS[/green]  {pkg} installed")
        except ImportError:
            if needed:
                msg = f"{pkg} not installed (required for {purpose}): pip install {pkg}"
                console.print(f"  [red]FAIL[/red]  {msg}")
                issues.append(msg)
            else:
                console.print(f"  [dim]SKIP[/dim]  {pkg} (not needed — {purpose} disabled)")


def _doctor_check_tools(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check that configured tools are known."""
    from workpilot.agent.tools.registry import PROTECTED_TOOLS
    from workpilot.cli.commands import console

    agent_tools = set(cfg.agents.default.tools)
    for _name, ag in cfg.agents.agents.items():
        agent_tools.update(ag.tools)

    unknown = agent_tools - PROTECTED_TOOLS
    if unknown:
        msg = f"Unknown tools referenced in agent config: {', '.join(sorted(unknown))}"
        console.print(f"  [yellow]WARN[/yellow]  {msg}")
        warnings.append(msg)
    else:
        console.print(
            f"  [green]PASS[/green]  All configured tools are valid ({len(agent_tools)} tools)"
        )


def _doctor_check_credentials(_cfg: AppConfig, _issues: list[str], _warnings: list[str]) -> None:
    """Check credential provider setup."""
    from workpilot.cli.commands import console

    console.print("  [green]PASS[/green]  Credential provider: env")


def _doctor_summary(issues: list[str], warnings: list[str]) -> None:
    """Print the doctor summary."""
    from workpilot.cli.commands import console

    console.print()
    if not issues and not warnings:
        console.print(Panel("[green]All checks passed![/green]", border_style="green"))
    elif not issues:
        console.print(
            Panel(
                f"[yellow]{len(warnings)} warning(s)[/yellow], 0 errors",
                border_style="yellow",
            )
        )
    else:
        console.print(
            Panel(
                f"[red]{len(issues)} error(s)[/red], [yellow]{len(warnings)} warning(s)[/yellow]",
                border_style="red",
            )
        )
