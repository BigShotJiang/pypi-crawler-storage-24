"""Skills CLI subcommands — workpilot skills list|show."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.panel import Panel
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    console,
    skills_app,
)


@skills_app.command("list")
def skills_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List all loaded skills (bundled + workspace)."""
    try:
        from workpilot.skills.loader import SkillLoader
    except ImportError:
        console.print("[red]Skills module not available.[/red]")
        raise typer.Exit(1)

    cfg = _load_config_safe(config)
    workspace = Path(cfg.agents.default.workspace).resolve()
    loader = SkillLoader(workspace)
    skills = loader.load_all()

    if not skills:
        console.print("[dim]No skills loaded.[/dim]")
        return

    table = Table(title="Skills")
    table.add_column("Name", style="bold")
    table.add_column("Mode")
    table.add_column("Triggers")
    table.add_column("Description")

    for skill in skills:
        mode_display = (
            "[green]always[/green]" if skill.mode == "always" else "[cyan]available[/cyan]"
        )
        triggers_str = ", ".join(skill.triggers) if skill.triggers else "[dim]none[/dim]"
        desc = skill.description[:60] + "..." if len(skill.description) > 60 else skill.description
        table.add_row(skill.name, mode_display, triggers_str, desc)

    console.print(table)


@skills_app.command("show")
def skills_show(
    name: str = typer.Argument(..., help="Skill name"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show the full definition of a skill."""
    from rich.markdown import Markdown

    from workpilot.skills.loader import SkillLoader

    cfg = _load_config_safe(config)
    workspace = Path(cfg.agents.default.workspace).resolve()
    loader = SkillLoader(workspace)
    skills = loader.load_all()

    skill = next((s for s in skills if s.name == name), None)
    if skill is None:
        console.print(f"[red]Skill not found:[/red] {name}")
        console.print("Run [cyan]workpilot skills list[/cyan] to see available skills.")
        raise typer.Exit(1)

    console.print(Panel(f"[bold]{skill.name}[/bold]", border_style="green"))
    console.print(f"[dim]{skill.source_path or ''}[/dim]\n")
    console.print(Markdown(skill.content))
