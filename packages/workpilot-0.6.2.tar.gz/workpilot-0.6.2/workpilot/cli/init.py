"""Init CLI command — workpilot init."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import typer
from rich.panel import Panel

from workpilot.cli.commands import (
    app,
    console,
)


def _show_environment(shutil: Any) -> None:
    """Detect and display installed tools during init."""
    import platform

    tools = ["git", "gh", "node", "az", "agency", "claude"]

    detected: list[str] = []
    for name in tools:
        if shutil.which(name):
            detected.append(f"[green]{name}[/green]")

    plat = f"{platform.system()} {platform.machine()}"
    console.print(f"[bold]Environment:[/bold] {plat}\n[bold]Tools:[/bold] {', '.join(detected)}\n")


@app.command()
def init(
    directory: str | None = typer.Option(
        None, "--dir", "-d", help="Target directory (default: ~/.workpilot)"
    ),
    name: str | None = typer.Option(
        None, "--name", "-n", help="Project name (sets top-level 'name' in config)"
    ),
    quick: bool = typer.Option(False, "--quick", "-q", help="Accept all defaults, no prompts"),
) -> None:
    """Create or update the local config override (workpilot.local.yaml).

    By default this writes to ``~/.workpilot/workpilot.local.yaml``.
    Safe to run multiple times — existing values are shown as defaults
    so you only change what you want. Use --quick to accept all defaults.
    """
    import shutil

    import yaml

    dir_path = (Path.home() / ".workpilot") if directory is None else Path(directory).resolve()
    dir_path.mkdir(parents=True, exist_ok=True)

    local_path = dir_path / "workpilot.local.yaml"

    # Load existing config to use as defaults
    existing: dict = {}
    is_update = local_path.exists()
    if is_update:
        try:
            loaded = yaml.safe_load(local_path.read_text(encoding="utf-8"))
            existing = loaded if isinstance(loaded, dict) else {}
        except Exception:
            existing = {}

    # ── Environment detection ─────────────────────────────────────────
    _show_environment(shutil)

    if quick:
        console.print("[dim]--quick mode: accepting all defaults[/dim]\n")
    else:
        action = "Update" if is_update else "Create"
        console.print(
            Panel(
                f"[bold]WorkPilot Setup[/bold]\n\n"
                f"{'Updating' if is_update else 'Creating'} [cyan]{local_path}[/cyan]\n"
                "Press Enter to keep the current value shown in brackets.",
                title=f"{action} workpilot.local.yaml",
                border_style="blue",
            )
        )

    # ── GitHub token ──────────────────────────────────────────────────────
    current_token: str = (existing.get("providers") or {}).get("github_copilot", {}).get(
        "token", ""
    ) or ""
    if current_token.startswith("${"):
        current_token = ""

    github_token: str | None = None
    if quick:
        github_token = current_token or os.environ.get("GITHUB_TOKEN") or "${GITHUB_TOKEN}"
    elif current_token:
        console.print(f"GitHub token: [dim]{current_token[:8]}...[/dim] (already set)")
        if typer.confirm("Re-authenticate with GitHub?", default=False):
            from workpilot.security.github_auth import github_device_login

            try:
                github_token = github_device_login(console=console)
            except Exception as exc:
                console.print(f"[yellow]GitHub sign-in failed:[/yellow] {exc}")
        else:
            github_token = current_token
    else:
        if typer.confirm("Sign in with GitHub? (configures Copilot)", default=True):
            from workpilot.security.github_auth import github_device_login

            try:
                github_token = github_device_login(console=console)
            except Exception as exc:
                console.print(f"[yellow]GitHub sign-in failed:[/yellow] {exc}")
                console.print("You can set GITHUB_TOKEN in your environment instead.\n")

    # ── Model ─────────────────────────────────────────────────────────────
    current_model: str = (existing.get("agents") or {}).get("default", {}).get(
        "model", "auto"
    ) or "auto"
    model: str = current_model if quick else typer.prompt("Default model", default=current_model)

    # ── Security profile ──────────────────────────────────────────────────
    current_profile: str = (existing.get("security") or {}).get("profile", "standard") or "standard"
    security_profile: str = (
        current_profile
        if quick
        else typer.prompt(
            "Security profile (open/standard/controlled/restricted)",
            default=current_profile,
        )
    )

    # ── Web channel (gateway) ─────────────────────────────────────────────
    current_gw: dict = (existing.get("channels") or {}).get("web") or existing.get("gateway") or {}
    current_gw_enabled: bool = bool(current_gw.get("enabled", True))
    enable_gateway: bool = (
        current_gw_enabled
        if quick
        else typer.confirm("Enable local web UI?", default=current_gw_enabled)
    )

    # ── Cloud channel (Teams, Web Chat) ────────────────────────────────
    current_cloud: dict = (existing.get("channels") or {}).get("cloud") or {}
    current_cloud_enabled: bool = bool(current_cloud.get("enabled", True))
    enable_cloud: bool = (
        current_cloud_enabled
        if quick
        else typer.confirm(
            "Enable cloud connection? (Teams, Web Chat)", default=current_cloud_enabled
        )
    )

    # ── Build config (deep-merge: preserve existing keys, update changed ones) ──
    local_config: dict = dict(existing)  # start from existing

    if name:
        local_config["name"] = name

    local_config.setdefault("providers", {}).setdefault("github_copilot", {})
    local_config["providers"]["github_copilot"]["token"] = github_token or "${GITHUB_TOKEN}"

    local_config.setdefault("agents", {}).setdefault("default", {})
    local_config["agents"]["default"]["model"] = model

    local_config.setdefault("security", {})
    local_config["security"]["profile"] = security_profile

    local_config.setdefault("logging", {"level": "INFO", "format": "pretty"})

    gw = local_config.setdefault("channels", {}).setdefault("web", {})
    gw["enabled"] = enable_gateway
    if enable_gateway:
        gw.setdefault("host", "localhost")
        gw.setdefault("port", current_gw.get("port", 3003))

    cloud = local_config.setdefault("channels", {}).setdefault("cloud", {})
    cloud["enabled"] = enable_cloud

    # ── Agency MCP servers ─────────────────────────────────────────────
    # Reuse _run_add_agency (same logic as `workpilot mcp add-agency`).
    # It handles: install Agency CLI, discover servers, filter already-configured,
    # interactive selection (or select_all), auth testing, and returns added dict.
    install_mcp = quick or typer.confirm(
        "Install Agency MCP servers? (ICM, ADO, EngHub, Kusto, ...)",
        default=True,
    )
    if install_mcp:
        console.print()
        from workpilot.cli.mcp import _run_add_agency

        added = _run_add_agency(
            config_path=dir_path / "workpilot.yaml",
            select_all=quick,
            skip_test=quick,
            raise_on_failure=False,
        )
        if added:
            mcp_section = local_config.setdefault("tools", {}).setdefault("mcp_servers", {})
            mcp_section.update(added)

    header = (
        "# WorkPilot local config override\n"
        "# This file is gitignored — use it for API keys, model preferences,\n"
        "# and local settings that should not be committed.\n"
        "# Values here are deep-merged on top of workpilot.yaml.\n"
        "\n"
    )
    local_path.write_text(
        header + yaml.dump(local_config, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )

    verb = "Updated" if is_update else "Created"
    console.print(f"[green]{verb}:[/green] {local_path}")

    # Show directory structure and customizable files
    console.print(
        Panel(
            f"[bold]~/.workpilot/ files:[/bold]\n"
            f"  workpilot.local.yaml   — your config (just {'updated' if is_update else 'created'})\n"
            f"  SOUL.md                — agent identity & customize\n"
            f"  AGENTS.md              — delegation, safety rules\n"
            f"  TOOLS.md               — operational guidelines\n"
            f"  USER.md                — auto-filled + manual edits\n"
            f"  HEARTBEAT.md           — periodic maintenance tasks\n"
            f"  MEMORY.md              — long-term memory (auto-managed)\n"
            f"\n"
            f"  All files use bundled defaults. Create a file in ~/.workpilot/ to override.\n"
            f"\n"
            f"[bold]Next steps:[/bold]\n"
            f"  workpilot chat         — start chatting\n"
            f"  workpilot s            — start the server\n"
            f"  workpilot doctor       — verify setup",
            title="Setup Complete",
            border_style="green",
        )
    )


# Backward-compat alias (hidden, not in help)
app.command("onboard", hidden=True)(init)
