"""Update CLI command — workpilot update.

Detects install mode automatically:
  - Git (editable install)  → git pull + pip install -e ".[all]"
  - PyPI (regular install)  → pip install --upgrade workpilot
"""

from __future__ import annotations

import subprocess
import sys
import sysconfig
from pathlib import Path

import typer

from workpilot import __version__
from workpilot.cli.commands import app, console


def _rename_exe_for_update() -> Path | None:
    """On Windows, rename workpilot.exe → workpilot.exe.old before pip runs.

    Windows allows renaming a running executable but not overwriting it.
    Returns the .old Path on success, None if skipped or rename failed.
    Cleans up any leftover .old from a previous update.
    """
    if sys.platform != "win32":
        return None
    scripts_dir_str = sysconfig.get_path("scripts")
    if not scripts_dir_str:
        return None
    scripts_dir = Path(scripts_dir_str)
    exe = scripts_dir / "workpilot.exe"
    if not exe.exists():
        return None
    old_exe = exe.with_name(exe.name + ".old")
    if old_exe.exists():
        try:
            old_exe.unlink()
        except OSError:
            pass
    try:
        exe.rename(old_exe)
        return old_exe
    except OSError as e:
        console.print(f"[yellow]Could not rename exe ({e}); trying anyway...[/yellow]")
        return None


def _restore_or_cleanup_exe(old_exe: Path | None, success: bool) -> None:
    """After pip install: delete .old on success, restore it on failure."""
    if old_exe is None:
        return
    if success:
        try:
            old_exe.unlink()
        except OSError:
            pass  # cleaned up on next update
    else:
        if old_exe.exists() and not (old_exe.parent / "workpilot.exe").exists():
            try:
                old_exe.rename(old_exe.with_name("workpilot.exe"))
            except OSError:
                pass


def _is_git_install() -> Path | None:
    """Return the repo root if workpilot is an editable git install, else None."""
    pkg_dir = Path(__file__).resolve().parent.parent  # workpilot/
    repo_root = pkg_dir.parent
    if (repo_root / ".git").exists():
        return repo_root
    return None


def _run(
    cmd: list[str], cwd: Path | str | None = None, timeout: int = 120
) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
    except subprocess.TimeoutExpired:
        console.print(f"[red]Command timed out ({timeout}s):[/red] {' '.join(cmd)}")
        raise typer.Exit(1)
    except FileNotFoundError:
        console.print(f"[red]Command not found:[/red] {cmd[0]}")
        raise typer.Exit(1)


def _git_update(repo: Path, check_only: bool) -> bool:
    """Update from git: fetch, compare, pull, reinstall deps.

    Returns True if an update was performed.
    """
    # Check for dirty working tree
    status_result = _run(["git", "status", "--porcelain"], cwd=repo)
    if status_result.returncode != 0:
        console.print(f"[red]git status failed:[/red]\n{status_result.stderr.strip()}")
        raise typer.Exit(1)
    if status_result.stdout.strip():
        console.print(
            "[yellow]Working tree has uncommitted changes.[/yellow]\n"
            "  Commit or stash them before updating."
        )
        raise typer.Exit(1)

    # Fetch latest
    result = _run(["git", "fetch"], cwd=repo)
    if result.returncode != 0:
        console.print(f"[red]git fetch failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)

    # Check for upstream changes
    local_result = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    if local_result.returncode != 0:
        console.print(f"[red]git rev-parse HEAD failed:[/red]\n{local_result.stderr.strip()}")
        raise typer.Exit(1)
    local = local_result.stdout.strip()

    remote_result = _run(["git", "rev-parse", "@{u}"], cwd=repo)
    if remote_result.returncode != 0:
        console.print(
            "[red]No upstream tracking branch set.[/red]\n"
            "  Set one with: [bold]git branch --set-upstream-to origin/<branch>[/bold]"
        )
        raise typer.Exit(1)
    remote = remote_result.stdout.strip()

    if local == remote:
        console.print("[green]Already up to date![/green]  (no new commits)")
        return False

    # Detect ahead/behind/diverged state
    count_result = _run(["git", "rev-list", "--left-right", "--count", "HEAD...@{u}"], cwd=repo)
    if count_result.returncode != 0:
        console.print(f"[red]git rev-list failed:[/red]\n{count_result.stderr.strip()}")
        raise typer.Exit(1)
    parts = count_result.stdout.strip().split()
    if len(parts) != 2:
        console.print(f"[red]Unexpected git rev-list output:[/red] {count_result.stdout.strip()}")
        raise typer.Exit(1)
    ahead, behind = int(parts[0]), int(parts[1])

    if behind == 0 and ahead > 0:
        console.print(
            f"[yellow]Local branch is {ahead} commit(s) ahead of upstream.[/yellow]\n"
            "  Nothing to pull. Push your changes or reset to upstream."
        )
        return False

    if ahead > 0 and behind > 0:
        console.print(
            f"[yellow]Branch has diverged:[/yellow] {ahead} ahead, {behind} behind.\n"
            "  Resolve manually (rebase or merge) before updating."
        )
        raise typer.Exit(1)

    # Show what's new (behind > 0, ahead == 0)
    log_result = _run(["git", "log", "--oneline", f"{local}..{remote}"], cwd=repo)
    new_commits = log_result.stdout.strip()
    commit_count = len(new_commits.splitlines()) if new_commits else 0
    console.print(f"[cyan]{commit_count}[/cyan] new commit(s) available:")
    for line in new_commits.splitlines()[:10]:
        console.print(f"  {line}")
    if commit_count > 10:
        console.print(f"  [dim]... and {commit_count - 10} more[/dim]")

    if check_only:
        console.print("\n  Run [bold]workpilot update[/bold] to pull and install.")
        return False

    # Pull
    console.print("\n[dim]Pulling...[/dim]")
    result = _run(["git", "pull"], cwd=repo)
    if result.returncode != 0:
        console.print(f"[red]git pull failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)
    console.print("[green]Pull complete.[/green]")

    # For editable installs, Python sources are used directly from the repo —
    # git pull alone is sufficient for pure code changes.  Only re-run pip if
    # pyproject.toml changed in the pulled commits (new deps or entry points).
    toml_changed_result = _run(
        ["git", "diff", "--name-only", f"{local}..{remote}", "--", "pyproject.toml"],
        cwd=repo,
    )
    # If the diff command fails (e.g. SHA no longer resolvable), err on the
    # side of caution and assume pyproject.toml may have changed.
    if toml_changed_result.returncode != 0:
        needs_pip = True
    else:
        needs_pip = bool(toml_changed_result.stdout.strip())

    if needs_pip:
        console.print("[dim]pyproject.toml changed — reinstalling dependencies...[/dim]")
        old_exe = _rename_exe_for_update()
        pip_result: subprocess.CompletedProcess[str] | None = None
        try:
            pip_result = _run(
                [sys.executable, "-m", "pip", "install", "-e", ".[all]"],
                cwd=repo,
                timeout=300,
            )
        finally:
            # Always restore exe if pip didn't run or failed (_run may raise typer.Exit)
            _restore_or_cleanup_exe(old_exe, pip_result is not None and pip_result.returncode == 0)
        if pip_result.returncode != 0:
            console.print(f"[red]pip install failed:[/red]\n{pip_result.stderr.strip()}")
            raise typer.Exit(1)
        console.print("[green]Dependencies updated![/green]")

    return True


def _pypi_update(check_only: bool) -> bool:
    """Update from PyPI: check latest version, pip install --upgrade.

    Returns True if an update was performed.
    """
    console.print("[dim]Checking PyPI...[/dim]")

    latest: str | None = None
    try:
        import httpx

        resp = httpx.get("https://pypi.org/pypi/workpilot/json", timeout=10)
        resp.raise_for_status()
        latest = resp.json()["info"]["version"]
    except Exception:
        try:
            result = _run(
                [sys.executable, "-m", "pip", "index", "versions", "workpilot"],
                timeout=30,
            )
            if result.returncode == 0:
                import re

                lines = [ln.strip() for ln in result.stdout.splitlines() if ln.strip()]
                if lines:
                    m = re.search(r"\(([^)]+)\)", lines[0])
                    latest = m.group(1).split(",")[0].strip() if m else None
        except Exception:
            pass

    if latest is None:
        console.print(
            "[yellow]Could not check for updates.[/yellow]\n"
            "  Update manually: [bold]pip install --upgrade workpilot[/bold]"
        )
        raise typer.Exit(1)

    def _parse_version(v: str) -> tuple[int, ...]:
        """Parse version string to comparable tuple (e.g. '0.6.0' → (0, 6, 0))."""
        import re

        return tuple(int(x) for x in re.findall(r"\d+", v))

    if _parse_version(__version__) >= _parse_version(latest):
        console.print(f"[green]Already up to date![/green]  (latest: v{latest})")
        return False

    console.print(f"New version available: [cyan]v{latest}[/cyan]")

    if check_only:
        console.print("  Run [bold]workpilot update[/bold] to install it.")
        return False

    console.print("[dim]Upgrading...[/dim]")

    old_exe = _rename_exe_for_update()
    pip_result: subprocess.CompletedProcess[str] | None = None
    try:
        pip_result = _run(
            [sys.executable, "-m", "pip", "install", "--upgrade", f"workpilot=={latest}"],
            timeout=120,
        )
    finally:
        # Always restore exe if pip didn't run or failed (_run may raise typer.Exit)
        _restore_or_cleanup_exe(old_exe, pip_result is not None and pip_result.returncode == 0)

    if pip_result.returncode == 0:
        console.print(f"[green]Updated to v{latest}![/green]")
        return True
    else:
        console.print(f"[red]Update failed:[/red]\n{pip_result.stderr.strip()}")
        raise typer.Exit(1)


@app.command(name="update")
def update(
    check: bool = typer.Option(False, "--check", help="Only check for updates, don't install"),
) -> None:
    """Update WorkPilot to the latest version."""
    console.print(f"Current version: [bold]v{__version__}[/bold]")

    repo = _is_git_install()
    if repo:
        console.print(f"Install mode:    [cyan]git[/cyan]  ({repo})")
        updated = _git_update(repo, check)
    else:
        console.print("Install mode:    [cyan]PyPI[/cyan]")
        updated = _pypi_update(check)

    # Remind to restart if gateway is running and we actually updated
    if updated:
        from workpilot.cli.commands import _check_gateway_running

        running = _check_gateway_running()
        if running:
            pid, port = running
            console.print(
                f"\n[yellow]Gateway is running (PID {pid}, port {port}).[/yellow]\n"
                "  Restart it to use the new version."
            )


# "upgrade" is a hidden alias — keeps the same convention as other aliases in commands.py
app.command("upgrade", hidden=True)(update)
