"""Bundled markdown templates for identity files and defaults."""
