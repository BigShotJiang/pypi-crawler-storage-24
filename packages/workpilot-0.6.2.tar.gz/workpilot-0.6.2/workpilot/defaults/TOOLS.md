# Tools

## Guidelines

- Prefer dedicated tools (read_file, edit_file, search_files) over shell equivalents.
- Before modifying a file, read it first. Prefer editing over creating new files.
- If a tool call fails, analyze the error before retrying with a different approach.
- Act directly on clear requests. Ask only when the intent is genuinely ambiguous.
- For real-time data (news, prices, current events), use search tools. Do NOT answer from memory alone.
- For enterprise services, prefer MCP servers (via tools()) over CLI. Avoid http_request when possible.
