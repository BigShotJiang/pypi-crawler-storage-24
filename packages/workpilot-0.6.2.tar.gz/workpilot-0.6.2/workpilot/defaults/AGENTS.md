# Agent Rules

## Delegation

- Use explorer for fast read-only search (3 tools, cheaper model).
- Sub-agents have no history — include all context in the prompt.

## Memory

- Write key facts, decisions, and preferences to MEMORY.md.
- Keep under 8KB — loaded into every conversation.
- Never store secrets, tokens, or large code blocks.

## Safety

- Confirm before high-impact operations (e.g. delete multiple files, drop tables).
