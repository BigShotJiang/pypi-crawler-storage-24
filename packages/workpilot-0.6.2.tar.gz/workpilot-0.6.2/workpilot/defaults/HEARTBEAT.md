# Heartbeat

Check the following. Reply HEARTBEAT_OK if nothing to report.
If action is needed, fix it and notify the user via notify(channel='*').

## System
- Is {WorkPilot_Dir}/MEMORY.md over 6KB? If so, summarize and trim older entries.
- Are there session files older than 30 days in {WorkPilot_Dir}/sessions/? If so, report count.
- Check for WorkPilot updates once per day: pip index versions workpilot

## Security
- Scan {WorkPilot_Dir}/MEMORY.md for accidentally stored secrets (API keys, tokens, passwords). Remove if found.

## User Profile
- Scan workspace for languages and frameworks, update {WorkPilot_Dir}/USER.md ## Tech Stack if changed.
- Review recent conversations, infer user's role language/style and preferences, update {WorkPilot_Dir}/USER.md ## Preferences.

## Skills
Check `{WorkPilot_Dir}/skills/.last_updated` — skip this entire section if it was written within the last 6 hours.

Scan sessions in `{WorkPilot_Dir}/sessions/` and identify repeated tasks, workflows, or patterns
that would benefit from a reusable skill.

**Creating new skills:**
- Direct create if either condition is met:
  - 2+ similar operations in the last 36 hours (scan recent sessions only), OR
  - 4+ similar operations across all available session history
- Otherwise: save draft to `{WorkPilot_Dir}/skill-draft/<name>.md`, notify user to review.
- Create `{WorkPilot_Dir}/skills/<name>.md` using SKILL.md format
  (YAML frontmatter with name, description, activation keywords; body with step-by-step instructions).
- Do not create skills for trivial or one-off tasks regardless of frequency.

**Modifying existing skills:**
- For each skill in `{WorkPilot_Dir}/skills/`, cross-check its instructions against recent session operations:
  - Are any referenced paths, commands, or steps broken or no longer valid?
  - Does the session show a simpler or more effective approach than what the skill describes?
- If inconsistencies are found and you are confident in the improvement:
  - Save the proposed update to `{WorkPilot_Dir}/skill-draft/<name>.md`.
  - Notify the user via notify(channel='*') with a clear diff summary and ask for confirmation.
  - Do NOT overwrite the live skill — wait for user approval.
- If the signal is ambiguous or only seen once, skip — do not generate a pending update.

After completing this section (regardless of whether any changes were made), write the current
timestamp to `{WorkPilot_Dir}/skills/.last_updated`.
If any changes were made, notify the user via notify(channel='*') listing what was created and what is pending review.
