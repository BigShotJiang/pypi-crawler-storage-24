"""
Outlook channel — send emails via Microsoft Graph API.
"""

from __future__ import annotations

from typing import Any

import httpx
from loguru import logger

from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel


class OutlookChannel(BaseChannel):
    """Outlook email via MS Graph API."""

    def __init__(
        self,
        bus: MessageBus,
        *,
        client_id: str,
        client_secret: str,
        tenant_id: str,
        user_email: str | None = None,
        allow_from: list[str] | None = None,
    ) -> None:
        super().__init__(bus, allow_from)
        self._client_id = client_id
        self._client_secret = client_secret
        self._tenant_id = tenant_id
        self._user_email = user_email or "me"
        self._token: str = ""
        self._token_expires: float = 0

    @property
    def name(self) -> str:
        return "outlook"

    async def start(self) -> None:
        logger.info("Outlook channel started")

    async def stop(self) -> None:
        self._token = ""

    async def _get_token(self) -> str:
        import time

        if self._token and time.time() < self._token_expires - 60:
            return self._token

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"https://login.microsoftonline.com/{self._tenant_id}/oauth2/v2.0/token",
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                    "scope": "https://graph.microsoft.com/.default",
                },
            )
            resp.raise_for_status()
            data = resp.json()
            self._token = data["access_token"]
            self._token_expires = time.time() + data["expires_in"]
            return self._token

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        token = await self._get_token()
        to_addrs = kwargs.get("to", [channel_id])
        if isinstance(to_addrs, str):
            to_addrs = [to_addrs]

        mail = {
            "message": {
                "subject": kwargs.get("subject", "WorkPilot Notification"),
                "body": {
                    "contentType": "HTML" if kwargs.get("html") else "Text",
                    "content": content,
                },
                "toRecipients": [{"emailAddress": {"address": addr}} for addr in to_addrs],
            },
            "saveToSentItems": True,
        }

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"https://graph.microsoft.com/v1.0/users/{self._user_email}/sendMail",
                json=mail,
                headers={"Authorization": f"Bearer {token}"},
            )
            if not resp.is_success:
                logger.error(f"Outlook send failed: {resp.status_code} {resp.text}")
