"""
Microsoft Teams channel — Bot Framework REST API integration.
"""

from __future__ import annotations

from typing import Any

import httpx
from loguru import logger

from workpilot.bus.events import EventType
from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel


class TeamsChannel(BaseChannel):
    """MS Teams via Bot Framework REST API."""

    def __init__(
        self,
        bus: MessageBus,
        *,
        app_id: str,
        app_password: str,
        tenant_id: str | None = None,
        allow_from: list[str] | None = None,
    ) -> None:
        super().__init__(bus, allow_from)
        self._app_id = app_id
        self._app_password = app_password
        self._tenant_id = tenant_id
        self._token: str = ""
        self._token_expires: float = 0
        self._http: httpx.AsyncClient | None = None

    @property
    def name(self) -> str:
        return "teams"

    def _get_http(self) -> httpx.AsyncClient:
        """Return a shared httpx client, creating it lazily."""
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient()
        return self._http

    async def start(self) -> None:
        logger.info("Teams channel started")

    async def stop(self) -> None:
        self._token = ""
        if self._http and not self._http.is_closed:
            await self._http.aclose()
            self._http = None

    async def _get_token(self) -> str:
        import time

        if self._token and time.time() < self._token_expires - 60:
            return self._token

        url = (
            f"https://login.microsoftonline.com/{self._tenant_id}/oauth2/v2.0/token"
            if self._tenant_id
            else "https://login.microsoftonline.com/botframework.com/oauth2/v2.0/token"
        )
        client = self._get_http()
        resp = await client.post(
            url,
            data={
                "grant_type": "client_credentials",
                "client_id": self._app_id,
                "client_secret": self._app_password,
                "scope": "https://api.botframework.com/.default",
            },
        )
        resp.raise_for_status()
        data = resp.json()
        self._token = data["access_token"]
        self._token_expires = time.time() + data["expires_in"]
        return self._token

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        token = await self._get_token()
        service_url = kwargs.get("service_url", "https://smba.trafficmanager.net/teams/")

        # Support structured attachments (e.g. Adaptive Card)
        attachments = kwargs.get("attachments")
        if attachments:
            activity = {"type": "message", "attachments": attachments}
        else:
            activity = {"type": "message", "text": content}

        if kwargs.get("reply_to_id"):
            activity["replyToId"] = kwargs["reply_to_id"]

        client = self._get_http()
        resp = await client.post(
            f"{service_url}v3/conversations/{channel_id}/activities",
            json=activity,
            headers={"Authorization": f"Bearer {token}"},
        )
        if not resp.is_success:
            logger.error(f"Teams send failed: {resp.status_code} {resp.text}")

    async def send_typing(self, channel_id: str, **kwargs: Any) -> None:
        """Send a typing indicator via Bot Framework."""
        token = await self._get_token()
        service_url = kwargs.get("service_url", "https://smba.trafficmanager.net/teams/")
        activity = {"type": "typing"}

        client = self._get_http()
        resp = await client.post(
            f"{service_url}v3/conversations/{channel_id}/activities",
            json=activity,
            headers={"Authorization": f"Bearer {token}"},
        )
        if not resp.is_success:
            logger.debug(f"Teams typing indicator failed: {resp.status_code}")

    async def process_activity(self, activity: dict[str, Any]) -> None:
        """Process an incoming Bot Framework activity (call from webhook).

        Handles both regular messages and ``invoke`` activities from Adaptive
        Card button clicks (used for approval responses).
        """
        activity_type = activity.get("type")
        sender = activity.get("from", {})
        conversation = activity.get("conversation", {})

        if activity_type == "invoke":
            # Adaptive Card Action.Submit — resolve approval directly
            # (bypasses inbound queue to avoid deadlock with blocked agent loop)
            value = activity.get("value", {})
            approval_action = value.get("approval_action")
            request_id = value.get("approval_request_id", "")
            if approval_action and request_id:
                resolver = sender.get("aadObjectId", sender.get("id", "unknown"))
                self._bus.events.emit(
                    EventType.APPROVAL_RESOLVED,
                    {
                        "request_id": request_id,
                        "action": approval_action,
                        "resolver": resolver,
                    },
                )
            return

        if activity_type != "message":
            return

        await self._handle_message(
            channel_id=conversation.get("id", ""),
            sender_id=sender.get("aadObjectId", sender.get("id", "")),
            sender_name=sender.get("name", ""),
            content=activity.get("text", ""),
            thread_id=conversation.get("id"),
            metadata={
                "service_url": activity.get("serviceUrl"),
                "activity_id": activity.get("id"),
            },
        )
