"""
Built-in hook handlers — the 8 safety handlers always registered.

on_message_received:
  - InjectionScanner (priority 10)

pre_tool_use:
  - EStopGate (priority 1)
  - PolicyGate (priority 10)
  - ApprovalGate (priority 20) — allowlist check, classifier, human-in-the-loop

post_tool_use:
  - LeakScanner (priority 10)
  - Redactor (priority 20)
  - Auditor (priority 30)

on_message_sent:
  - OutboundLeakScanner (priority 10)
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.hooks.manager import (
    HookManager,
    HookResult,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
)
from workpilot.security.leak import detect_credentials, redact_credentials
from workpilot.security.sanitizer import Sanitizer

if TYPE_CHECKING:
    from workpilot.bus.queue import EventBus
    from workpilot.channels.manager import ChannelManager
    from workpilot.security.allowlist import AllowlistManager
    from workpilot.security.approval import ApprovalManager
    from workpilot.security.audit import AuditLogger
    from workpilot.security.classifier import SecurityClassifier
    from workpilot.security.rbac import PolicyEngine


# ── on_message_received handlers ─────────────────────────────────────────────


class InjectionScanner:
    """Detect prompt injection patterns in inbound messages."""

    def __init__(self, *, block: bool = False) -> None:
        self._block = block

    async def __call__(self, ctx: MessageHookContext) -> HookResult:
        findings = Sanitizer.check_prompt_injection(ctx.content)
        if findings:
            logger.warning(
                "Injection patterns detected from {}: {}",
                ctx.sender_id or "unknown",
                findings,
            )
            if self._block:
                return HookResult.reject(f"Prompt injection detected: {findings[0]}")
        return HookResult.allow()


# ── pre_tool_use handlers ────────────────────────────────────────────────────


class EStopGate:
    """Reject all tool calls when E-stop is active."""

    def __init__(self, estop: object | None = None) -> None:
        self._estop = estop

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if self._estop is not None and getattr(self._estop, "is_halted", False):
            return HookResult.reject("E-stop is active — all tool execution halted")
        return HookResult.allow()


class PolicyGate:
    """Check RBAC permissions before tool execution."""

    def __init__(self, policy_engine: PolicyEngine | None = None) -> None:
        self._engine = policy_engine

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if self._engine is None:
            return HookResult.allow()
        # check_permission returns (allowed: bool, level: AutonomyLevel)
        # operation defaults to "write" for tools that modify state
        operation = (
            "read" if ctx.tool_name in ("read_file", "list_dir", "search_files") else "write"
        )
        allowed, _level = self._engine.check_permission(
            ctx.tool_name, operation, agent_name=ctx.agent_name
        )
        if not allowed:
            return HookResult.reject(
                f"Tool '{ctx.tool_name}' denied by policy for agent '{ctx.agent_name}'"
            )
        return HookResult.allow()


class ApprovalGate:
    """Security Agent approval gate for tool calls with human-in-the-loop.

    Flow:
    1. No classifier → allow (backward compat)
    2. Allowlist check → allow (skip LLM call entirely)
    3. Classifier with user_message context → allow/deny/escalate
    4. On escalate: determine timeout from risk level, request approval,
       send prompt to channel, await resolution.

    CLI special case: uses ``run_in_executor`` for inline ``input()`` prompt
    (y/n/always). "always" adds the tool to the allowlist.
    """

    def __init__(
        self,
        classifier: SecurityClassifier | None = None,
        *,
        approval_manager: ApprovalManager | None = None,
        allowlist: AllowlistManager | None = None,
        bus: EventBus | None = None,
        channel_manager: ChannelManager | None = None,
        session_manager: Any = None,
        auto_approve_timeout: int = 180,
    ) -> None:
        self._classifier = classifier
        self._approval_manager = approval_manager
        self._allowlist = allowlist
        self._bus = bus
        self._channel_manager = channel_manager
        self._session_manager = session_manager
        self._auto_approve_timeout = auto_approve_timeout

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        # 1. No classifier wired -> allow all (backward compat)
        if not self._classifier:
            return HookResult.allow()

        # 2. Allowlist check — skip classifier entirely
        if self._allowlist and self._allowlist.check(ctx.tool_name, ctx.args):
            logger.debug("Allowlist hit for tool '{}' — skipping classifier", ctx.tool_name)
            return HookResult.allow()

        # 3. Classify with user message context
        context: dict[str, Any] = {}
        if ctx.user_message:
            context["user_message"] = ctx.user_message

        result = await self._classifier.classify(
            ctx.tool_name, ctx.args, context=context or None, tool_risk=ctx.tool_risk
        )

        if result.decision == "allow":
            return HookResult.allow()
        if result.decision == "deny":
            return HookResult.reject(f"[{result.risk}] {result.reason}")

        # 4. Escalate — route to human approval
        if not self._approval_manager:
            # No approval manager wired — reject for safety (pre-v0.2 compat)
            return HookResult.reject(f"Escalated for review: {result.reason}")

        # Determine timeout based on risk level
        risk = result.risk
        if risk in ("low", "medium"):
            auto_timeout: int | None = self._auto_approve_timeout
        else:
            # high / critical — wait indefinitely (None = use config.timeout_seconds)
            auto_timeout = None

        # Create approval request
        request = await self._approval_manager.request_approval(
            tool_name=ctx.tool_name,
            args=ctx.args,
            agent_name=ctx.agent_name,
            channel=ctx.channel or "cli",
            channel_id=ctx.channel_id or "",
            risk=risk,
            reason=result.reason,
        )

        # Persist approval_request to session so history shows the card
        if self._session_manager and ctx.session_id:
            import json as _json

            self._session_manager.add_message(
                ctx.session_id,
                {
                    "role": "approval_request",
                    "content": _json.dumps(
                        {
                            "request_id": request.id,
                            "tool_name": ctx.tool_name,
                            "args": {k: str(v)[:200] for k, v in list(ctx.args.items())[:10]},
                            "risk": risk,
                            "reason": result.reason,
                            "status": "pending",
                        }
                    ),
                },
            )

        # Emit APPROVAL_REQUESTED event
        if self._bus:
            from workpilot.bus.events import EventType

            self._bus.emit(
                EventType.APPROVAL_REQUESTED,
                {
                    "request_id": request.id,
                    "tool_name": ctx.tool_name,
                    "risk": risk,
                    "reason": result.reason,
                },
            )

        # 5. Send approval prompt to channel
        channel_name = ctx.channel or "cli"
        if channel_name == "cli":
            # CLI special case: inline input() prompt
            return await self._cli_prompt(ctx, request, result, auto_timeout)

        # Non-CLI channels: send structured approval prompt
        await self._send_approval_prompt(ctx, request, result, auto_timeout)

        # 6. Wait for resolution
        resolved = await self._approval_manager.wait_for_resolution(
            request.id, auto_approve_timeout=auto_timeout
        )

        # 7. Emit resolution event
        if self._bus:
            from workpilot.bus.events import EventType

            approved = resolved.status.value == "approved"
            self._bus.emit(
                EventType.TOOL_APPROVED if approved else EventType.TOOL_DENIED,
                {
                    "request_id": request.id,
                    "tool_name": ctx.tool_name,
                    "resolver": resolved.resolver,
                },
            )

        from workpilot.security.approval import ApprovalStatus

        approved = resolved.status == ApprovalStatus.APPROVED
        logger.info(
            "APPROVAL_DECISION tool={} decision={} resolver={} risk={} request_id={}",
            ctx.tool_name,
            "approved" if approved else "denied",
            resolved.resolver or "timeout",
            result.risk,
            request.id,
        )

        if approved:
            return HookResult.allow()
        return HookResult.reject(
            f"Tool '{ctx.tool_name}' {resolved.status.value} by {resolved.resolver or 'timeout'}"
        )

    async def _cli_prompt(
        self, ctx: PreToolHookContext, request: Any, classify_result: Any, auto_timeout: int | None
    ) -> HookResult:
        """Inline CLI approval prompt — rich display with optional countdown."""
        assert self._approval_manager is not None

        risk = classify_result.risk
        risk_colour = {
            "low": "\033[32m",
            "medium": "\033[33m",
            "high": "\033[31m",
            "critical": "\033[35m",
        }.get(risk, "\033[0m")
        reset = "\033[0m"

        args_lines = "\n".join(f"    {k} = {v!r}" for k, v in list(ctx.args.items())[:8])
        timeout_line = (
            f"  Auto-approving in {auto_timeout}s if no response.\n"
            if auto_timeout is not None
            else "  No auto-approve — waiting for your decision.\n"
        )
        banner = (
            f"\n\033[1m⚠  Approval Required\033[0m  [id: {request.id[:12]}]\n"
            f"  Tool:   \033[1m{ctx.tool_name}\033[0m\n"
            f"  Risk:   {risk_colour}{risk}{reset}\n"
            f"  Reason: {classify_result.reason}\n"
            f"  Args:\n{args_lines}\n"
            f"{timeout_line}"
            f"\n  [y]es  [n]o  [a]lways  › "
        )

        def _read() -> str:
            try:
                return input(banner).strip().lower()
            except (EOFError, KeyboardInterrupt):
                return "n"

        if auto_timeout is not None:
            loop = asyncio.get_running_loop()
            try:
                answer = await asyncio.wait_for(
                    loop.run_in_executor(None, _read), timeout=auto_timeout
                )
            except TimeoutError:
                print(f"\n  [auto-approved after {auto_timeout}s timeout]")
                answer = "y"
        else:
            loop = asyncio.get_running_loop()
            answer = await loop.run_in_executor(None, _read)

        approved = answer in ("y", "yes", "always", "a")
        self._approval_manager.resolve(request.id, approved=approved, resolver="cli-user")
        logger.info(
            "APPROVAL_DECISION tool={} decision={} resolver=cli-user risk={} request_id={}",
            ctx.tool_name,
            "approved" if approved else "denied",
            risk,
            request.id,
        )
        if approved:
            if answer in ("always", "a") and self._allowlist:
                self._allowlist.add(
                    ctx.tool_name, added_by="cli-user", note="Added via CLI 'always' prompt"
                )
            return HookResult.allow()
        return HookResult.reject(f"Tool '{ctx.tool_name}' denied by user")

    async def _send_approval_prompt(
        self,
        ctx: PreToolHookContext,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None,
    ) -> None:
        """Send an approval prompt to a non-CLI channel."""
        from workpilot.security.approval_format import get_approval_formatter

        formatter = get_approval_formatter(ctx.channel or "cloud")
        content = formatter.format_request(request, classify_result, auto_timeout)

        if self._channel_manager:
            channel = self._channel_manager.get(ctx.channel or "")
            if channel:
                try:
                    if isinstance(content, dict):
                        attachments = content.get("attachments")
                        if attachments:
                            # Direct Teams channel (not via cloud relay): pass Adaptive Card.
                            # For Teams via cloud relay, ctx.channel='cloud' and the C# gateway
                            # builds the Adaptive Card from the approval_request JSON.
                            await channel.send(
                                ctx.channel_id, "", attachments=attachments, **ctx.metadata
                            )
                        else:
                            # Cloud/Web: JSON-encode structured approval request.
                            # keep_context=True prevents the gateway from deleting
                            # the reply context so the tool result can be delivered.
                            import json as _json

                            await channel.send(
                                ctx.channel_id,
                                _json.dumps(content),
                                keep_context=True,
                                **ctx.metadata,
                            )
                    else:
                        # Formatter returned plain text (e.g. CLIApprovalFormatter on non-CLI path)
                        await channel.send(ctx.channel_id, str(content), **ctx.metadata)
                except Exception as exc:
                    logger.error("Failed to send approval prompt: {}", exc)


# ── post_tool_use handlers ───────────────────────────────────────────────────


class LeakScanner:
    """Scan tool output for credential patterns and env-var values."""

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        # Pattern-based detection (JWT, AWS, GitHub PAT, etc.)
        findings = detect_credentials(ctx.result)
        if findings:
            types = ", ".join(sorted({t for t, _ in findings}))
            logger.warning(
                "Credential patterns detected in '{}' output: {}",
                ctx.tool_name,
                types,
            )

        # Env-var value detection (existing)
        redacted = Sanitizer.redact_env_values(ctx.result)
        if redacted != ctx.result:
            logger.warning("Env var leak detected in '{}' output", ctx.tool_name)

        return HookResult.allow()


class Redactor:
    """Replace detected secrets in tool output.

    Env-var values are replaced with ``[REDACTED]``.
    Credential patterns are replaced with ``[REDACTED:{type}]``
    (e.g. ``[REDACTED:JWT]``, ``[REDACTED:AWS Access Key]``).
    """

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        # Pattern-based redaction first, then env-var redaction
        cleaned = redact_credentials(ctx.result)
        cleaned = Sanitizer.redact_env_values(cleaned)
        if cleaned != ctx.result:
            ctx.result = cleaned
        return HookResult.allow(data=ctx)


class Auditor:
    """Log every tool call to the audit trail."""

    def __init__(self, audit_logger: AuditLogger | None = None) -> None:
        self._audit = audit_logger

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        if self._audit is not None:
            self._audit.log_tool(
                tool=ctx.tool_name,
                actor=ctx.agent_name,
                args=ctx.args,
                result=ctx.result[:200] if ctx.result else "",
                is_error=not ctx.success,
                session_id=ctx.session_id,
                duration_ms=ctx.duration_ms,
            )
        return HookResult.allow()


# ── on_message_sent handlers ────────────────────────────────────────────────


class OutboundLeakScanner:
    """Scan outbound responses for credential leaks."""

    async def __call__(self, ctx: MessageHookContext) -> HookResult:
        cleaned = redact_credentials(ctx.content)
        cleaned = Sanitizer.redact_env_values(cleaned)
        if cleaned != ctx.content:
            logger.warning("Leak detected in outbound message to {}", ctx.channel)
            ctx.content = cleaned
        return HookResult.allow(data=ctx)


# ── Registration helper ──────────────────────────────────────────────────────


def register_builtin_handlers(
    hook_manager: HookManager,
    *,
    estop: object | None = None,
    policy_engine: PolicyEngine | None = None,
    audit_logger: AuditLogger | None = None,
    classifier: SecurityClassifier | None = None,
    approval_manager: ApprovalManager | None = None,
    allowlist: AllowlistManager | None = None,
    bus: EventBus | None = None,
    channel_manager: ChannelManager | None = None,
    session_manager: Any = None,
    auto_approve_timeout: int = 180,
    block_injections: bool = False,
) -> None:
    """Register all built-in handlers onto a HookManager.

    Args:
        hook_manager: HookManager instance.
        estop: EStop instance (optional).
        policy_engine: PolicyEngine instance (optional).
        audit_logger: AuditLogger instance (optional).
        classifier: SecurityClassifier for the ApprovalGate (optional).
        approval_manager: ApprovalManager for human-in-the-loop (optional).
        allowlist: AllowlistManager for per-user tool allowlist (optional).
        bus: EventBus for emitting approval events (optional).
        channel_manager: ChannelManager for sending approval prompts (optional).
        auto_approve_timeout: Seconds before auto-approving low-risk escalations.
        block_injections: If True, reject messages with injection patterns.
    """
    mgr = hook_manager

    # on_message_received
    mgr.register("on_message_received", InjectionScanner(block=block_injections), priority=10)

    # pre_tool_use
    mgr.register("pre_tool_use", EStopGate(estop), priority=1)
    mgr.register("pre_tool_use", PolicyGate(policy_engine), priority=10)
    mgr.register(
        "pre_tool_use",
        ApprovalGate(
            classifier,
            approval_manager=approval_manager,
            allowlist=allowlist,
            bus=bus,
            channel_manager=channel_manager,
            session_manager=session_manager,
            auto_approve_timeout=auto_approve_timeout,
        ),
        priority=20,
    )

    # post_tool_use
    mgr.register("post_tool_use", LeakScanner(), priority=10)
    mgr.register("post_tool_use", Redactor(), priority=20)
    mgr.register("post_tool_use", Auditor(audit_logger), priority=30)

    # on_message_sent
    mgr.register("on_message_sent", OutboundLeakScanner(), priority=10)
