"""Skills subsystem — load and match markdown-based prompt skills."""

from workpilot.skills.loader import SkillLoader

__all__ = ["SkillLoader"]
