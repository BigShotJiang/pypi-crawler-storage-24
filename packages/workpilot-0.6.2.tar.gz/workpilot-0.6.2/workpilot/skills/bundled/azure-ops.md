---
name: azure-ops
description: Azure resource management via az CLI — groups, VMs, storage, deployments, monitoring
metadata:
  workpilot:
    activation:
      keywords: [azure, az, resource group, vm, storage, deployment, app service, aks, monitor]
    requires:
      bins: [az]
    always: false
---
## Azure CLI Operations

Use the `shell` tool with `az` CLI commands.

**Before running az commands**, verify authentication by running `az account show`. If it fails, prompt the user to run `az login`.

### Account & Subscription
```
az account show -o json
az account list -o json
az account set --subscription "{NAME_OR_ID}"
```

### Resource Groups
```
az group list -o json
az group show --name {NAME} -o json
az group create --name {NAME} --location {LOCATION} -o json
az group delete --name {NAME} --yes
```

### Virtual Machines
```
az vm list -o json
az vm show --resource-group {RG} --name {VM} -o json
az vm create --resource-group {RG} --name {VM} --image Ubuntu2204 --admin-username azureuser --generate-ssh-keys -o json
az vm start --resource-group {RG} --name {VM}
az vm stop --resource-group {RG} --name {VM}
az vm deallocate --resource-group {RG} --name {VM}
```

### App Service / Web Apps
```
az webapp list -o json
az webapp show --resource-group {RG} --name {APP} -o json
az webapp create --resource-group {RG} --plan {PLAN} --name {APP} --runtime "PYTHON:3.12" -o json
az webapp deploy --resource-group {RG} --name {APP} --src-path {ZIP} --type zip
az webapp log tail --resource-group {RG} --name {APP}
```

### Storage
```
az storage account list -o json
az storage account show --name {ACCOUNT} -o json
az storage account create --name {ACCOUNT} --resource-group {RG} --sku Standard_LRS -o json
az storage blob list --account-name {ACCOUNT} --container-name {CONTAINER} -o json
```

### AKS (Kubernetes)
```
az aks list -o json
az aks show --resource-group {RG} --name {CLUSTER} -o json
az aks get-credentials --resource-group {RG} --name {CLUSTER}
```

### Deployments
```
az deployment group list --resource-group {RG} -o json
az deployment group create --resource-group {RG} --template-file {FILE} --parameters {PARAMS} -o json
```

### Monitor & Logs
```
az monitor activity-log list --resource-group {RG} -o json
az monitor metrics list --resource {RESOURCE_ID} --metric "Percentage CPU" -o json
```

### Guidelines
- Always use `-o json` for structured output
- Use `--query` (JMESPath) to filter large results: `--query "[].{name:name, location:location}"`
- Read operations (list, show, get) are low-risk
- Write operations (create, update, delete, start, stop) are medium-risk — confirm with user
- Dangerous operations (group delete, vm delete) are high-risk — always confirm
- Avoid `az ad`, `az role`, `az policy`, `az lock` unless explicitly requested (security-sensitive)
- The az CLI must be installed and authenticated: `az login`
