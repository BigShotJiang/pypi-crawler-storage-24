---
name: teams-message
description: Send Microsoft Teams chat or channel messages using MCP_teams.
metadata:
  workpilot:
    activation:
      keywords: [teams, send teams message, post to teams, teams chat, teams channel]
    always: false
---

# Teams Message

Use this skill when the user wants to send a Microsoft Teams message to a person, chat, or channel.

## Defaults

- Default to being helpful and drafting the message directly.
- Preserve the user's wording unless they ask for editing.
- Confirm only before the actual send when the target or content is ambiguous.

## Send to a person

1. The default UPN is email (such as ALIAS@microsoft.com).
2. Resolve `chatId` with `MCP_teams_CreateChat` with user UPN and target UPN.
   - If the email is unknown, `MCP_teams_SearchMessages` can be used to find the `chatId` — but this is discouraged as it is prone to timeouts.
3. Send with `MCP_teams_PostMessage`.

## Send to a channel

1. Resolve the real `teamId` with `MCP_teams_ListTeams`.
2. Resolve the real `channelId` with `MCP_teams_ListChannels` if needed.
3. If no channel is specified:
   - prefer `General`
   - otherwise prefer a channel matching the Team name
   - otherwise ask the user
4. Send with `MCP_teams_PostChannelMessage`.
5. Never guess `teamId` or `channelId`.

## Content types

Prefer `html` over `text` — it supports rich formatting (bold, italic, lists, links, tables) and renders better in Teams.

Use `text` only when the user explicitly requests plain text, or the message is trivially short (one sentence, no formatting needed).

Supported:
- `html` (preferred)
- `text`

Not supported:
- `markdown` (Teams does not render markdown; convert to HTML instead)

## Signature

Use the user's preferred signature when known. If no user preference is specified, use these defaults.

For `text` messages:

```text
— via WorkPilot 🪄
```

For `html` messages:

```html
<p><em><small><sub><span style="color:#8A8A8A;">— via WorkPilot 🪄</span></sub></small></em></p>
```

## Safety

- Confirm and highlight when sending a message to another org; ask the user to clearly approve it.
- If the target is ambiguous, ask first.
