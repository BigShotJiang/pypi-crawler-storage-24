"""
Channel-specific approval prompt formatters.

Each formatter renders an approval request for a specific channel type:
- CLI:   rich text prompt
- Teams: Adaptive Card JSON with Approve/Deny/Always buttons
- Cloud: structured JSON for web chat clients
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any


class ApprovalFormatter(ABC):
    """Abstract base for channel-specific approval formatters."""

    @abstractmethod
    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
    ) -> str | dict[str, Any]:
        """Format an approval request for display.

        Parameters
        ----------
        request:
            The ``ApprovalRequest`` object.
        classify_result:
            The ``ClassifyResult`` from the Security Classifier.
        auto_timeout:
            Seconds until auto-approve (``None`` = wait indefinitely).

        Returns
        -------
        str | dict
            Formatted content: plain text for CLI, dict for structured channels.
        """


class CLIApprovalFormatter(ApprovalFormatter):
    """Rich text prompt for CLI."""

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
    ) -> str:
        args_summary = ", ".join(f"{k}={v!r}" for k, v in list(request.args.items())[:5])
        timeout_info = (
            f"\n  Auto-approving in {auto_timeout}s if no response."
            if auto_timeout is not None
            else "\n  Waiting for approval (no auto-approve)."
        )
        return (
            f"\n[Approval Required] Tool: {request.tool_name}({args_summary})\n"
            f"  Risk: {classify_result.risk} | Reason: {classify_result.reason}"
            f"{timeout_info}\n"
            f"  Request ID: {request.id}\n"
            f"  Reply: yes/no/always  "
            f"(or /approve {request.id} | /deny {request.id} | /always {request.id})"
        )


class TeamsApprovalFormatter(ApprovalFormatter):
    """Adaptive Card JSON for Microsoft Teams."""

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
    ) -> dict[str, Any]:
        args_summary = json.dumps(request.args, default=str, indent=2)[:500]
        timeout_text = (
            f"Auto-approving in {auto_timeout}s if no response."
            if auto_timeout is not None
            else "Waiting for your decision."
        )

        return {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": {
                        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                        "type": "AdaptiveCard",
                        "version": "1.4",
                        "body": [
                            {
                                "type": "TextBlock",
                                "text": "Tool Approval Required",
                                "weight": "Bolder",
                                "size": "Medium",
                            },
                            {
                                "type": "FactSet",
                                "facts": [
                                    {"title": "Tool", "value": request.tool_name},
                                    {"title": "Risk", "value": classify_result.risk},
                                    {"title": "Reason", "value": classify_result.reason},
                                    {"title": "Request ID", "value": request.id[:12] + "..."},
                                ],
                            },
                            {
                                "type": "TextBlock",
                                "text": f"Arguments:\n```\n{args_summary}\n```",
                                "wrap": True,
                                "fontType": "Monospace",
                                "size": "Small",
                            },
                            {
                                "type": "TextBlock",
                                "text": timeout_text,
                                "isSubtle": True,
                                "wrap": True,
                            },
                            {
                                "type": "TextBlock",
                                "text": "Or reply **yes** / **no** / **always** if buttons are unavailable.",
                                "isSubtle": True,
                                "size": "Small",
                                "wrap": True,
                            },
                        ],
                        "actions": [
                            {
                                "type": "Action.Submit",
                                "title": "Approve",
                                "data": {
                                    "approval_action": "approve",
                                    "approval_request_id": request.id,
                                },
                            },
                            {
                                "type": "Action.Submit",
                                "title": "Deny",
                                "data": {
                                    "approval_action": "deny",
                                    "approval_request_id": request.id,
                                },
                            },
                            {
                                "type": "Action.Submit",
                                "title": "Always Allow",
                                "data": {
                                    "approval_action": "always",
                                    "approval_request_id": request.id,
                                },
                            },
                        ],
                    },
                }
            ],
        }


class CloudApprovalFormatter(ApprovalFormatter):
    """Structured JSON for Cloud/Web Chat clients.

    The rendered payload is sent as a WebSocket frame and causes the
    web chat UI to display an inline approve/deny card.
    """

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
    ) -> dict[str, Any]:
        args_summary = {k: str(v)[:200] for k, v in list(request.args.items())[:10]}
        return {
            "type": "approval_request",
            "request_id": request.id,
            "tool_name": request.tool_name,
            "args": args_summary,
            "risk": classify_result.risk,
            "reason": classify_result.reason,
            "agent_name": request.agent_name,
            "auto_timeout": auto_timeout,
        }


def get_approval_formatter(channel_name: str) -> ApprovalFormatter:
    """Factory — return the appropriate formatter for a channel."""
    if channel_name == "cli":
        return CLIApprovalFormatter()
    if channel_name == "teams":
        return TeamsApprovalFormatter()
    return CloudApprovalFormatter()
