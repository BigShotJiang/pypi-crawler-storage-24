"""
E-Stop — global emergency halt mechanism.

When triggered, all agent loops exit, tool registry rejects calls,
gateway returns 503. Stays halted until explicit reset by authorized actor.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from workpilot.bus.queue import EventBus
    from workpilot.security.audit import AuditLogger

from workpilot.bus.events import EventType


class EStopError(Exception):
    """Raised when an operation is attempted while E-stop is active."""


class EStop:
    """Global halt mechanism for WorkPilot.

    Triggers: manual (CLI/API) or automatic (leak detection).
    Behavior: halted flag → all loops exit → tools reject → audit logs.
    """

    def __init__(
        self,
        events: EventBus | None = None,
        audit: AuditLogger | None = None,
    ) -> None:
        self._halted = False
        self._reason: str = ""
        self._actor: str = ""
        self._triggered_at: datetime | None = None
        self._events = events
        self._audit = audit

    @property
    def is_halted(self) -> bool:
        return self._halted

    @property
    def reason(self) -> str:
        return self._reason

    def trigger(self, reason: str, *, actor: str = "system") -> None:
        """Activate E-stop. All agent loops should exit."""
        if self._halted:
            return  # already halted
        self._halted = True
        self._reason = reason
        self._actor = actor
        self._triggered_at = datetime.now(UTC)
        logger.critical("E-STOP TRIGGERED by {}: {}", actor, reason)

        if self._audit:
            self._audit.log_security(
                event="estop_triggered",
                severity="critical",
                details={"reason": reason, "actor": actor},
            )
        if self._events:
            self._events.emit(
                EventType.SECURITY_ESTOP,
                {
                    "action": "trigger",
                    "reason": reason,
                    "actor": actor,
                },
            )

    def reset(self, *, actor: str) -> None:
        """Clear E-stop. Requires explicit actor for audit trail."""
        if not self._halted:
            return
        logger.warning("E-STOP RESET by {}", actor)
        self._halted = False
        prev_reason = self._reason
        self._reason = ""
        self._actor = ""
        self._triggered_at = None

        if self._audit:
            self._audit.log_security(
                event="estop_reset",
                severity="warning",
                details={"actor": actor, "previous_reason": prev_reason},
            )
        if self._events:
            self._events.emit(
                EventType.SECURITY_ESTOP,
                {
                    "action": "reset",
                    "actor": actor,
                },
            )

    def check(self) -> None:
        """Raise EStopError if halted. Call before any tool execution."""
        if self._halted:
            raise EStopError(f"E-stop active: {self._reason}")

    def status(self) -> dict[str, Any]:
        """Return current E-stop status for health checks / API."""
        return {
            "halted": self._halted,
            "reason": self._reason,
            "actor": self._actor,
            "triggered_at": self._triggered_at.isoformat() if self._triggered_at else None,
        }
