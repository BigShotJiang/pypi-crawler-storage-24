"""
Per-user allowlist — skip approval prompts for known-safe tool+arg patterns.

Stores entries in ``~/.workpilot/allowlist.json`` and keeps an in-memory copy
for fast lookups.  Auto-persists on add/remove.
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from workpilot.utils.helpers import get_data_dir


@dataclass
class AllowlistEntry:
    """A single allowlist rule.

    Attributes
    ----------
    tool_name:
        Exact tool name to match (e.g. ``"shell"``).
    arg_pattern:
        Optional regex applied against JSON-serialised args.
        ``None`` means any args for *tool_name* are allowed.
    added_by:
        Identity of the user who created this entry.
    added_at:
        ISO-8601 timestamp of creation.
    note:
        Human-readable note explaining why this entry exists.
    """

    tool_name: str
    arg_pattern: str | None = None
    added_by: str = ""
    added_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    note: str = ""

    def matches(self, tool_name: str, args: dict[str, Any]) -> bool:
        """Return ``True`` if this entry matches the given tool call.

        Matching rules:
        - Tool name must be an exact match.
        - If ``arg_pattern`` is set, the regex must match against the
          JSON-serialised args string.
        - If ``arg_pattern`` is ``None``, any args match.
        """
        if self.tool_name != tool_name:
            return False
        if self.arg_pattern is None:
            return True
        try:
            args_json = json.dumps(args, sort_keys=True, default=str)
            return bool(re.search(self.arg_pattern, args_json))
        except re.error:
            logger.warning("Invalid allowlist regex: {}", self.arg_pattern)
            return False


class AllowlistManager:
    """Manages the per-user tool allowlist.

    Parameters
    ----------
    path:
        Path to the JSON file.  Defaults to ``~/.workpilot/allowlist.json``.
    """

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or (get_data_dir() / "allowlist.json")
        self._entries: list[AllowlistEntry] = []
        self._load()

    # ── Public API ────────────────────────────────────────────────────────

    def check(self, tool_name: str, args: dict[str, Any]) -> bool:
        """Return ``True`` if any entry matches the tool call."""
        return any(entry.matches(tool_name, args) for entry in self._entries)

    def add(
        self,
        tool_name: str,
        *,
        arg_pattern: str | None = None,
        added_by: str = "",
        note: str = "",
    ) -> AllowlistEntry:
        """Add a new allowlist entry and persist to disk."""
        entry = AllowlistEntry(
            tool_name=tool_name,
            arg_pattern=arg_pattern,
            added_by=added_by,
            note=note,
        )
        self._entries.append(entry)
        self._save()
        logger.info("Allowlist entry added: tool={} pattern={}", tool_name, arg_pattern)
        return entry

    def remove(self, index: int) -> AllowlistEntry:
        """Remove an entry by index and persist.

        Raises
        ------
        IndexError
            If *index* is out of range.
        """
        entry = self._entries.pop(index)
        self._save()
        logger.info("Allowlist entry removed: tool={}", entry.tool_name)
        return entry

    def list_entries(self) -> list[AllowlistEntry]:
        """Return a copy of the current entries."""
        return list(self._entries)

    # ── Persistence ───────────────────────────────────────────────────────

    def _load(self) -> None:
        if not self._path.exists():
            self._entries = []
            return
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
            self._entries = [AllowlistEntry(**item) for item in data]
            logger.debug("Loaded {} allowlist entries from {}", len(self._entries), self._path)
        except Exception as exc:
            logger.warning("Failed to load allowlist from {}: {}", self._path, exc)
            self._entries = []

    def _save(self) -> None:
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            data = [asdict(entry) for entry in self._entries]
            self._path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception as exc:
            logger.error("Failed to save allowlist to {}: {}", self._path, exc)
