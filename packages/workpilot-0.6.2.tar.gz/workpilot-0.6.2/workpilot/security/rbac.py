"""
Policy-Based Access Control — maps security profiles to autonomy levels.

Each security profile (open, standard, controlled, restricted) defines default
autonomy levels per operation category.  The PolicyEngine resolves the effective
autonomy level for any (tool, operation, agent) triple by checking:

  1. Agent-specific overrides
  2. Tool-specific overrides
  3. Profile defaults (mapped via operation category)
"""

from __future__ import annotations

from typing import Any

from loguru import logger

from workpilot.config.schema import (
    AutonomyLevel,
    RiskLevel,
    SecurityConfig,
    SecurityProfile,
)

# ── Constants ───────────────────────────────────────────────────────────────


TOOL_CATEGORIES: dict[str, RiskLevel] = {
    "read_file": RiskLevel.LOW,
    "list_dir": RiskLevel.LOW,
    "write_file": RiskLevel.MEDIUM,
    "edit_file": RiskLevel.MEDIUM,
    "shell": RiskLevel.HIGH,
    "git": RiskLevel.MEDIUM,
    "http_request": RiskLevel.MEDIUM,
    "browser": RiskLevel.HIGH,
    "spawn_agent": RiskLevel.CRITICAL,
}
"""Default risk classification for each built-in tool."""


OPERATION_CATEGORIES: dict[str, str] = {
    # Read operations
    "read": "read",
    "list": "read",
    "search": "read",
    "status": "read",
    "diff": "read",
    "log": "read",
    "get": "read",
    # Write operations
    "write": "write",
    "edit": "write",
    "create": "write",
    "delete": "write",
    "move": "write",
    "rename": "write",
    "commit": "write",
    # External operations
    "push": "external",
    "pull_request": "external",
    "send": "external",
    "http": "external",
    "fetch": "external",
    "browse": "external",
    "email": "external",
    # Dangerous operations
    "force_push": "dangerous",
    "reset_hard": "dangerous",
    "rm_rf": "dangerous",
    "format": "dangerous",
    "shutdown": "dangerous",
    "spawn": "dangerous",
}
"""Maps fine-grained operation names to one of four categories."""


# ── PolicyEngine ────────────────────────────────────────────────────────────


class PolicyEngine:
    """Resolves the effective autonomy level for tool operations.

    Resolution order:
        1. Per-agent overrides  (``security.overrides.agents``)
        2. Per-tool overrides   (``security.overrides.tools``)
        3. Profile defaults     (``PROFILE_DEFAULTS[profile][category]``)
    """

    PROFILE_DEFAULTS: dict[SecurityProfile, dict[str, AutonomyLevel]] = {
        # open — everything autonomous except obviously destructive
        SecurityProfile.OPEN: {
            "read": AutonomyLevel.AUTONOMOUS,
            "write": AutonomyLevel.AUTONOMOUS,
            "external": AutonomyLevel.AUTONOMOUS,
            "dangerous": AutonomyLevel.FORBIDDEN,
        },
        # standard — read freely, write/commit with notify, external needs approval
        SecurityProfile.STANDARD: {
            "read": AutonomyLevel.AUTONOMOUS,
            "write": AutonomyLevel.NOTIFY,
            "external": AutonomyLevel.APPROVAL,
            "dangerous": AutonomyLevel.FORBIDDEN,
        },
        # controlled — read freely, write notifies, everything outbound asks
        SecurityProfile.CONTROLLED: {
            "read": AutonomyLevel.AUTONOMOUS,
            "write": AutonomyLevel.NOTIFY,
            "external": AutonomyLevel.APPROVAL,
            "dangerous": AutonomyLevel.FORBIDDEN,
        },
        # restricted — reads notify, everything else requires approval
        SecurityProfile.RESTRICTED: {
            "read": AutonomyLevel.NOTIFY,
            "write": AutonomyLevel.APPROVAL,
            "external": AutonomyLevel.APPROVAL,
            "dangerous": AutonomyLevel.FORBIDDEN,
        },
    }
    """Default autonomy levels for each (profile, category) pair."""

    def __init__(self, config: SecurityConfig) -> None:
        self._config = config
        self._profile = config.profile
        self._overrides = config.overrides
        logger.debug(
            "PolicyEngine initialised — profile={}, tool_overrides={}, agent_overrides={}",
            self._profile.value,
            len(self._overrides.tools),
            len(self._overrides.agents),
        )

    # ── Public API ──────────────────────────────────────────────────────

    def get_autonomy_level(
        self,
        tool_name: str,
        operation: str,
        agent_name: str | None = None,
    ) -> AutonomyLevel:
        """Return the effective autonomy level for a tool operation.

        Parameters
        ----------
        tool_name:
            Registered tool name (e.g. ``"shell"``, ``"git"``).
        operation:
            Operation label (e.g. ``"read"``, ``"push"``, ``"rm_rf"``).
        agent_name:
            Optional agent identity for per-agent overrides.

        Returns
        -------
        AutonomyLevel
            The resolved autonomy level (0-3).
        """
        # 1. Agent-specific override
        if agent_name and agent_name in self._overrides.agents:
            agent_cfg = self._overrides.agents[agent_name]
            if tool_name in agent_cfg:
                level = int(agent_cfg[tool_name])
                logger.trace(
                    "Autonomy resolved via agent override: agent={} tool={} level={}",
                    agent_name,
                    tool_name,
                    level,
                )
                return AutonomyLevel(level)

        # 2. Tool-specific override
        if tool_name in self._overrides.tools:
            level = self._overrides.tools[tool_name]
            logger.trace(
                "Autonomy resolved via tool override: tool={} level={}",
                tool_name,
                level,
            )
            return AutonomyLevel(level)

        # 3. Profile default via operation category
        category = self._classify_operation(operation)
        profile_defaults = self.PROFILE_DEFAULTS[self._profile]
        resolved = profile_defaults.get(category, AutonomyLevel.APPROVAL)
        logger.trace(
            "Autonomy resolved via profile default: profile={} category={} level={}",
            self._profile.value,
            category,
            resolved.value,
        )
        return resolved

    def check_permission(
        self,
        tool_name: str,
        operation: str,
        agent_name: str | None = None,
    ) -> tuple[bool, AutonomyLevel]:
        """Check whether a tool operation is permitted.

        Returns
        -------
        tuple[bool, AutonomyLevel]
            ``(allowed, level)`` — ``allowed`` is ``False`` only when the
            level is ``FORBIDDEN``.
        """
        level = self.get_autonomy_level(tool_name, operation, agent_name)
        allowed = level != AutonomyLevel.FORBIDDEN
        if not allowed:
            logger.warning(
                "Permission denied: tool={} operation={} agent={}",
                tool_name,
                operation,
                agent_name or "(default)",
            )
        return allowed, level

    def classify_risk(self, tool_name: str, args: dict[str, Any]) -> RiskLevel:
        """Classify the risk level of a specific tool invocation.

        Heuristics (in priority order):
          - Known dangerous arg patterns   → CRITICAL
          - Tool's default risk from TOOL_CATEGORIES
          - Fallback to MEDIUM

        Parameters
        ----------
        tool_name:
            Registered tool name.
        args:
            Tool call arguments.

        Returns
        -------
        RiskLevel
        """
        # Check for critical argument patterns
        if self._has_dangerous_args(tool_name, args):
            logger.debug(
                "Risk classified as CRITICAL for tool={} due to dangerous args",
                tool_name,
            )
            return RiskLevel.CRITICAL

        # Fall back to static tool category
        default_risk = TOOL_CATEGORIES.get(tool_name, RiskLevel.MEDIUM)
        logger.trace(
            "Risk classified as {} for tool={}",
            default_risk.value,
            tool_name,
        )
        return default_risk

    # ── Internals ───────────────────────────────────────────────────────

    @staticmethod
    def _classify_operation(operation: str) -> str:
        """Map an operation label to its category (read/write/external/dangerous)."""
        return OPERATION_CATEGORIES.get(operation, "write")

    @staticmethod
    def _has_dangerous_args(tool_name: str, args: dict[str, Any]) -> bool:
        """Return *True* if the args contain obviously dangerous patterns."""
        if tool_name == "shell":
            command = str(args.get("command", ""))
            dangerous_patterns = [
                "rm -rf /",
                "mkfs",
                ":(){",
                "dd if=/dev/",
                "shutdown",
                "reboot",
                "> /dev/sd",
            ]
            return any(pat in command for pat in dangerous_patterns)

        if tool_name == "git":
            op = str(args.get("operation", ""))
            if op in ("force_push", "reset_hard"):
                return True
            flags = str(args.get("flags", ""))
            if "--force" in flags or "--hard" in flags:
                return True

        if tool_name == "write_file":
            path = str(args.get("path", ""))
            sensitive = ("/etc/", ".ssh/", ".gnupg/", ".aws/")
            return any(s in path for s in sensitive)

        return False
