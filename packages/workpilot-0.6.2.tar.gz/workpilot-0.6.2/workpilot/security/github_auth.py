"""
GitHub OAuth Device Code Flow — interactive sign-in for GitHub Copilot.

Uses the same client ID as VS Code / Copilot editor plugins so the
resulting token has access to the Copilot API.  Configurable via the
``GITHUB_OAUTH_CLIENT_ID`` environment variable.
"""

from __future__ import annotations

import os
import time

import httpx
from loguru import logger
from rich.console import Console

# Well-known client ID used by VS Code GitHub Copilot / copilot.vim
DEFAULT_CLIENT_ID = "Iv1.b507a08c87ecfe98"

_DEVICE_CODE_URL = "https://github.com/login/device/code"
_TOKEN_URL = "https://github.com/login/oauth/access_token"
_SCOPE = "read:user"

_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"


_COPILOT_TOKEN_URL = "https://api.github.com/copilot_internal/v2/token"
_COPILOT_API_BASE_DEFAULT = "https://api.individual.githubcopilot.com"

# GitHub validates these headers — requests without them get 403.
# Values aligned with OpenClaw / pi-mono (vscode/1.107.0).
_COPILOT_HEADERS = {
    "Editor-Version": "vscode/1.107.0",
    "Editor-Plugin-Version": "copilot-chat/0.35.0",
    "User-Agent": "GitHubCopilotChat/0.35.0",
    "Copilot-Integration-Id": "vscode-chat",
    "Openai-Intent": "conversation-edits",
    "Accept": "application/json",
}


class GitHubAuthError(Exception):
    """Raised when GitHub device code authentication fails."""


# ── Copilot token exchange ───────────────────────────────────────────────────

# Cached Copilot session token (short-lived, ~30 min).
_copilot_token: str = ""
_copilot_token_expires: float = 0
_copilot_api_base: str = _COPILOT_API_BASE_DEFAULT


def _derive_api_base(token: str) -> str:
    """Extract the API base URL from the Copilot session token.

    The token contains ``proxy-ep=proxy.individual.githubcopilot.com``.
    Replace ``proxy.`` with ``api.`` to get the completions endpoint.
    """
    import re

    match = re.search(r"(?:^|;)\s*proxy-ep=([^;\s]+)", token)
    if not match:
        return _COPILOT_API_BASE_DEFAULT
    proxy_ep = match.group(1).strip()
    host = re.sub(r"^https?://", "", proxy_ep)
    host = re.sub(r"^proxy\.", "api.", host, flags=re.IGNORECASE)
    return f"https://{host}"


def get_copilot_token(github_token: str) -> str:
    """Exchange a GitHub OAuth token for a short-lived Copilot API token.

    The result is cached in-memory until it expires (5-minute safety margin).
    """
    global _copilot_token, _copilot_token_expires, _copilot_api_base  # noqa: PLW0603

    if _copilot_token and time.time() < _copilot_token_expires - 300:
        return _copilot_token

    with httpx.Client(timeout=30) as http:
        resp = http.get(
            _COPILOT_TOKEN_URL,
            headers={
                **_COPILOT_HEADERS,
                "Authorization": f"Bearer {github_token}",
            },
        )
        resp.raise_for_status()
        data = resp.json()

    _copilot_token = data["token"]
    _copilot_api_base = _derive_api_base(_copilot_token)

    # Normalise expires_at — may be seconds or milliseconds
    expires_at = data.get("expires_at", time.time() + 1800)
    if isinstance(expires_at, str):
        from datetime import datetime

        expires_at = datetime.fromisoformat(expires_at.replace("Z", "+00:00")).timestamp()
    elif isinstance(expires_at, (int, float)) and expires_at > 10_000_000_000:
        expires_at = expires_at / 1000  # milliseconds → seconds
    _copilot_token_expires = float(expires_at)

    logger.debug(
        "Copilot session token acquired (base={}, expires in {}s)",
        _copilot_api_base,
        int(_copilot_token_expires - time.time()),
    )
    return _copilot_token


def get_copilot_api_base() -> str:
    """Return the Copilot API base URL (derived from the last token exchange)."""
    return _copilot_api_base


def github_device_login(
    client_id: str | None = None,
    console: Console | None = None,
) -> str:
    """Run the GitHub OAuth Device Code Flow and return an access token.

    Parameters
    ----------
    client_id:
        GitHub OAuth App client ID.  Defaults to the VS Code Copilot
        client ID, overridable via ``GITHUB_OAUTH_CLIENT_ID`` env var.
    console:
        Rich console for user-facing output.  A default is created if
        not provided.

    Returns
    -------
    str
        The OAuth access token.

    Raises
    ------
    GitHubAuthError
        If the flow fails, is denied, or times out.
    """
    if client_id is None:
        client_id = os.environ.get("GITHUB_OAUTH_CLIENT_ID", DEFAULT_CLIENT_ID)
    if console is None:
        console = Console()

    headers = {**_COPILOT_HEADERS}

    # Step 1 — request a device code
    with httpx.Client(timeout=30) as http:
        resp = http.post(
            _DEVICE_CODE_URL,
            data={"client_id": client_id, "scope": _SCOPE},
            headers=headers,
        )
        resp.raise_for_status()
        data = resp.json()

    device_code: str = data.get("device_code", "")
    user_code: str = data.get("user_code", "")
    verification_uri: str = data.get("verification_uri", "https://github.com/login/device")
    expires_in: int = data.get("expires_in", 900)
    interval: int = data.get("interval", 5)

    if not device_code or not user_code:
        raise GitHubAuthError(f"Failed to initiate device code flow: {data}")

    # Step 2 — show the user code
    console.print()
    console.print(f"  [bold]Open:[/bold]  [cyan]{verification_uri}[/cyan]")
    console.print(f"  [bold]Code:[/bold]  [yellow bold]{user_code}[/yellow bold]")
    console.print()
    console.print("  Waiting for authorization…", style="dim")

    logger.debug("GitHub device code flow started (expires in {}s)", expires_in)

    # Step 3 — poll for the token
    deadline = time.monotonic() + expires_in

    with httpx.Client(timeout=30) as http:
        while time.monotonic() < deadline:
            time.sleep(interval)

            resp = http.post(
                _TOKEN_URL,
                data={
                    "client_id": client_id,
                    "device_code": device_code,
                    "grant_type": _GRANT_TYPE,
                },
                headers=headers,
            )
            resp.raise_for_status()
            token_data = resp.json()

            error = token_data.get("error")

            if error is None:
                # Success
                access_token: str = token_data["access_token"]
                logger.info("GitHub authentication successful")
                console.print("  [green bold]Signed in to GitHub![/green bold]")
                return access_token

            if error == "authorization_pending":
                continue

            if error == "slow_down":
                interval = token_data.get("interval", interval + 5)
                continue

            # Terminal errors
            description = token_data.get("error_description", error)
            raise GitHubAuthError(f"GitHub auth failed: {description}")

    raise GitHubAuthError("Device code expired — please try again")
