---
name: noticias-do-dia
description: Pesquisa e resume as principais notícias de hoje, do Brasil e do Mundo.
---

# Notícias do Dia

Gere um briefing jornalístico com as principais notícias de hoje.

> Esta skill não utiliza scripts. O trabalho é feito pelo agente, usando suas ferramentas e seguindo o fluxo de trabalho abaixo.

## Fluxo de Trabalho

1.  **Mapeamento de Manchetes**: Obtenha o conteúdo de texto dos seguintes portais para ler as manchetes do dia:
    - `https://www.metropoles.com`
    - `https://g1.globo.com`
2.  **Aprofundamento**: Apenas para as notícias mais relevantes, siga os links das matérias e faça fetch do conteúdo completo para obter contexto, detalhes e desdobramentos.
3.  **Triagem e Organização**: Consolide as informações obtidas, organizando-as por categorias.
4.  **Consolidação Final**: Prepare o resumo jornalístico enriquecido e validado.

## Formato do Resumo

Apresente o resultado em seções, definidas de acordo com a temática das notícias, no seguinte formato:

```markdown
**Título da Seção 1**
Um parágrafo curto (2-4 frases) com o contexto essencial e o impacto do(s) fato(s).

**Título da Seção 2**
Um parágrafo curto (2-4 frases) com o contexto essencial e o impacto do(s) fato(s).

<!-- E assim por diante, para cada temática... -->

**Destaque do Dia**
Um parágrafo curto (2-4 frases) destacando o acontecimento mais significativo entre todos os pesquisados.
```

> Não incua texto que fuja do template: por exemplo, comentários de introdução e de conclusão.