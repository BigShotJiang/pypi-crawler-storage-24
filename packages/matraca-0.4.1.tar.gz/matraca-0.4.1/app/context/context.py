from app.context.state import State
from app.settings import (
    Contacts,
    Paths,
    Prompt,
    Settings,
)


class Context:
    def __init__(
        self,
        paths: Paths,
        settings: Settings,
        contacts: Contacts,
        prompt: Prompt,
    ) -> None:
        self.paths = paths

        self.settings = State(settings)
        self.contacts = State(contacts)
        self.prompt = State(prompt)

        self.models = self.settings.derive(lambda s: s.models)
        self.tools = self.settings.derive(lambda s: s.tools)
        self.channels = self.settings.derive(lambda s: s.channels)
        self.messages = self.settings.derive(lambda s: s.messages)
        self.telegram_contacts = self.contacts.derive(lambda c: c.telegram_contacts)
        self.whatsapp_contacts = self.contacts.derive(lambda c: c.whatsapp_contacts)
