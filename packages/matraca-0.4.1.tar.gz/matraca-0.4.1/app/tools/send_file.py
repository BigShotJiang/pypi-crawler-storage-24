from pathlib import Path

from pydantic_ai import Agent, RunContext
from pydantic_ai_backends import LocalBackend

from app.agent.deps import Deps


def configure_send_file_tool(agent: Agent[Deps, str]) -> Agent[Deps, str]:
    @agent.tool
    async def send_file(ctx: RunContext[Deps], path: str) -> str:
        """Send a file from the workspace to the user.

        Args:
            path: Path relative to the workspace root (e.g. "uploads/report.pdf")
        """
        backend = ctx.deps.backend
        if not isinstance(backend, LocalBackend):
            return "Backend não suporta leitura de arquivos"
        data = backend._read_bytes(path)
        if not data:
            return f"Arquivo não encontrado ou sem permissão: {path}"
        callback = ctx.deps.send_file
        if callback is None:
            return "[send_file não disponível neste canal]"
        filename = Path(path).name
        await callback(filename, data)
        return f"Arquivo enviado: {filename}"

    return agent
