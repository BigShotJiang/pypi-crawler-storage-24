from pathlib import Path

from pydantic import BaseModel, Field


class Prompt(BaseModel):
    content: str = Field(default="")

    @classmethod
    def load(cls, path: Path) -> "Prompt":
        return cls(content=path.read_text(encoding="utf-8"))

    @classmethod
    def ensure(cls, path: Path) -> "Prompt":
        if not path.exists():
            prompt_source = Path(__file__).resolve().parent.parent / "agent" / "prompt.md"
            prompt_text = prompt_source.read_text(encoding="utf-8")
            path.write_text(prompt_text, encoding="utf-8")
        return cls.load(path)
