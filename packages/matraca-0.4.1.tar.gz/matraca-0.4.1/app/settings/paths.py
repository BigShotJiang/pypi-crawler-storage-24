from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class Paths:
    base_dir: Path = field(default_factory=lambda: Path.home() / ".matraca")

    @property
    def settings_path(self) -> Path:
        return self.base_dir / "config.json"

    @property
    def contacts_path(self) -> Path:
        return self.base_dir / "contacts.json"

    @property
    def skills_path(self) -> Path:
        return self.base_dir / "skills"

    @property
    def prompt_path(self) -> Path:
        return self.base_dir / "prompt.md"

    @property
    def saved_requests_directory(self) -> Path:
        return self.base_dir / "requests"

    def user_workspace(self, user_id: str | int) -> Path:
        workspace = self.base_dir / str(user_id)
        workspace.mkdir(parents=True, exist_ok=True)
        return workspace

    def user_skills_path(self, user_id: str | int) -> Path:
        skills_dir = self.user_workspace(user_id) / "skills"
        skills_dir.mkdir(parents=True, exist_ok=True)
        return skills_dir

    def user_history_path(self, user_id: str | int) -> Path:
        return self.user_workspace(user_id) / "history.json"
