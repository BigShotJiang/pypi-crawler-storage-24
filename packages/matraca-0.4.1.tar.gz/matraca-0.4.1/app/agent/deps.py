from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path

from pydantic_ai_backends import LocalBackend


@dataclass
class Deps:
    backend: LocalBackend
    workspace_dir: Path = field(default_factory=lambda: Path("."))
    skills_dir: Path = field(default_factory=lambda: Path("skills"))
    ask_user: Callable[[str, list[dict[str, str]]], Awaitable[str]] | None = field(
        default=None, repr=False
    )
    send_file: Callable[[str, bytes], Awaitable[None]] | None = field(default=None, repr=False)
