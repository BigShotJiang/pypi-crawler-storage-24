import re


def normalize_newlines(text: str) -> str:
    normalized = text.replace("\\r\\n", "\n").replace("\\r", "\n")
    return re.sub(r"\r\n?", "\n", normalized)


def markdown_to_whatsapp_text(markdown_text: str) -> str:
    if not markdown_text:
        return ""

    text = normalize_newlines(markdown_text)
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"^>\s*", "", text, flags=re.MULTILINE)
    text = re.sub(r"\*\*(.+?)\*\*", r"*\1*", text)
    text = re.sub(r"__(.+?)__", r"*\1*", text)
    text = re.sub(r"~~(.+?)~~", r"~\1~", text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1 (\2)", text)
    return text
