"""Unit tests for the CitationEnrichment fixer."""

from __future__ import annotations

import json

import pytest

from synix.build.fixers import (
    CitationEnrichment,
    FixContext,
)
from synix.build.snapshot_view import SnapshotArtifactCache
from synix.build.validators import Violation
from synix.core.models import Artifact, Pipeline
from tests.helpers.snapshot_factory import create_test_snapshot

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def build_dir(tmp_path):
    d = tmp_path / "build"
    d.mkdir()
    return d


def _make_artifact(aid, atype="episode", content="test content", **meta):
    return Artifact(
        label=aid,
        artifact_type=atype,
        content=content,
        metadata=meta,
    )


# ---------------------------------------------------------------------------
# Mock LLM
# ---------------------------------------------------------------------------


class _MockResponse:
    def __init__(self, content):
        self.content = content


class _MockLLMClient:
    def __init__(self, response_text):
        self.response_text = response_text
        self.calls = []

    def complete(self, messages, artifact_desc="", **kwargs):
        self.calls.append(messages)
        if isinstance(self.response_text, Exception):
            raise self.response_text
        return _MockResponse(self.response_text)


class _MockSearchResult:
    def __init__(self, label, content):
        self.label = label
        self.content = content


class _MockSearchIndex:
    def __init__(self, results=None):
        self._results = results or []
        self.queries = []

    def query(self, q, **kwargs):
        self.queries.append(q)
        return self._results


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _make_violation(label="core-1"):
    return Violation(
        violation_type="ungrounded_claim",
        severity="warning",
        message="Ungrounded claim: expert in quantum computing",
        label=label,
        field="content",
        metadata={
            "claim": "expert in quantum computing",
            "suggestion": "Link to conversation about computing background",
            "artifact_id": "hash1",
        },
        violation_id="vid-citation-1",
    )


# ---------------------------------------------------------------------------
# CitationEnrichment fixer tests
# ---------------------------------------------------------------------------


class TestCitationEnrichmentFixer:
    def _store_with(self, build_dir, art):
        """Create a snapshot store containing a single artifact."""
        layer = art.metadata.get("layer_name", "core")
        synix_dir = create_test_snapshot(build_dir, {layer: [art]})
        return SnapshotArtifactCache(synix_dir)

    def test_resolved_adds_citation(self, build_dir):
        """Fixer resolves ungrounded claim by adding citation."""
        art = _make_artifact(
            "core-1",
            "core_memory",
            "Mark is an expert in quantum computing.",
            layer_name="core",
            layer_level=3,
        )
        store = self._store_with(build_dir, art)

        new_content = "Mark is an expert in quantum computing [ep-42](synix://ep-42)."
        response = json.dumps(
            {
                "status": "resolved",
                "action": "add_citation",
                "content": new_content,
                "explanation": "Added citation to source conversation",
            }
        )
        mock_llm = _MockLLMClient(response)
        mock_search = _MockSearchIndex([_MockSearchResult("ep-42", "User discussed quantum computing background")])

        ctx = FixContext(store, Pipeline("test"), search_index=mock_search, llm_client=mock_llm)

        fixer = CitationEnrichment()
        action = fixer.fix(_make_violation(), ctx)

        assert action.action == "rewrite"
        assert "synix://" in action.new_content
        assert action.new_artifact_id.startswith("sha256:")
        assert action.interactive is True
        assert action.evidence_source_ids == ["ep-42"]
        assert action.llm_explanation == "Added citation to source conversation"

    def test_unresolved_when_llm_cannot_find_source(self, build_dir):
        """Fixer marks unresolved when LLM can't find a source."""
        art = _make_artifact(
            "core-1",
            "core_memory",
            "Mark is an expert in quantum computing.",
            layer_name="core",
            layer_level=3,
        )
        store = self._store_with(build_dir, art)

        response = json.dumps(
            {
                "status": "unresolved",
                "content": "",
                "explanation": "No source evidence found for this claim",
            }
        )
        mock_llm = _MockLLMClient(response)

        ctx = FixContext(store, Pipeline("test"), llm_client=mock_llm)

        fixer = CitationEnrichment()
        action = fixer.fix(_make_violation(), ctx)

        assert action.action == "unresolved"
        assert action.new_content == ""
        assert "No source evidence" in action.llm_explanation

    def test_missing_artifact_skip(self, build_dir):
        """Fixer skips when artifact is not found in store."""
        synix_dir = create_test_snapshot(build_dir, {})
        store = SnapshotArtifactCache(synix_dir)
        ctx = FixContext(store, Pipeline("test"))

        fixer = CitationEnrichment()
        action = fixer.fix(_make_violation("nonexistent"), ctx)

        assert action.action == "skip"
        assert "not found" in action.description.lower()

    def test_no_llm_client_skip(self, build_dir):
        """Fixer skips when no LLM client is available."""
        art = _make_artifact("core-1", "core_memory", "Some content.", layer_name="core", layer_level=3)
        store = self._store_with(build_dir, art)

        ctx = FixContext(store, Pipeline("test"), llm_client=None)

        fixer = CitationEnrichment()
        action = fixer.fix(_make_violation(), ctx)

        assert action.action == "skip"
        assert "no llm client" in action.description.lower()

    def test_llm_error_skip(self, build_dir):
        """Fixer skips when LLM raises an exception."""
        art = _make_artifact("core-1", "core_memory", "Some content.", layer_name="core", layer_level=3)
        store = self._store_with(build_dir, art)

        mock_llm = _MockLLMClient(RuntimeError("API error"))

        ctx = FixContext(store, Pipeline("test"), llm_client=mock_llm)

        fixer = CitationEnrichment()
        action = fixer.fix(_make_violation(), ctx)

        assert action.action == "skip"
        assert "LLM error" in action.description

    def test_invalid_json_response_unresolved(self, build_dir):
        """Fixer returns unresolved when LLM response is not valid JSON."""
        art = _make_artifact("core-1", "core_memory", "Some content.", layer_name="core", layer_level=3)
        store = self._store_with(build_dir, art)

        mock_llm = _MockLLMClient("not json at all")

        ctx = FixContext(store, Pipeline("test"), llm_client=mock_llm)

        fixer = CitationEnrichment()
        action = fixer.fix(_make_violation(), ctx)

        assert action.action == "unresolved"
        assert "parse" in action.description.lower()

    def test_missing_prompt_file_skip(self, build_dir, tmp_path):
        """Fixer skips when prompt file is missing."""
        import synix.build.fixers as fmod

        art = _make_artifact("core-1", "core_memory", "Some content.", layer_name="core", layer_level=3)
        store = self._store_with(build_dir, art)

        mock_llm = _MockLLMClient('{"status": "resolved", "content": "x", "explanation": "y"}')

        ctx = FixContext(store, Pipeline("test"), llm_client=mock_llm)

        # Point prompts to non-existent directory
        orig_file = fmod.__file__
        fmod.__file__ = str(tmp_path / "fake" / "fixers.py")
        try:
            fixer = CitationEnrichment()
            action = fixer.fix(_make_violation(), ctx)
            assert action.action == "skip"
            assert "prompt" in action.description.lower() or "not found" in action.description.lower()
        finally:
            fmod.__file__ = orig_file

    def test_instantiation(self):
        fixer = CitationEnrichment()
        assert isinstance(fixer, CitationEnrichment)
        assert fixer.interactive is True
        assert "ungrounded_claim" in fixer.handles_violation_types

    def test_can_handle_matches(self):
        fixer = CitationEnrichment()
        v_match = Violation("ungrounded_claim", "warning", "msg", "a", "content")
        v_no_match = Violation("semantic_conflict", "error", "msg", "a", "content")
        assert fixer.can_handle(v_match) is True
        assert fixer.can_handle(v_no_match) is False
