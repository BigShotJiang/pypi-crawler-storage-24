"""Framework and stdlib integrations."""
