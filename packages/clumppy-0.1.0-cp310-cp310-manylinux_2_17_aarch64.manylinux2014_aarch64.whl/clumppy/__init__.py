from .clumppy import *

__doc__ = clumppy.__doc__
if hasattr(clumppy, "__all__"):
    __all__ = clumppy.__all__