# finlint-audit

Financial data integrity assertions engine. Part of [finlint](https://github.com/kanso-finance/finlint).

## Quick Start

```python
from finlint_audit import (
    assert_net_worth,
    AssertionContext,
    Account,
    AccountType,
)
from decimal import Decimal

ctx = AssertionContext(
    accounts=[
        Account(id="1", type=AccountType.DEPOSITORY, balance_current=Decimal("10000")),
        Account(id="2", type=AccountType.CREDIT, balance_current=Decimal("2500")),
    ],
    holdings=[],
    liabilities=[],
    snapshots=[],
    transactions=[],
)
result = assert_net_worth(ctx)
print(result.status)  # "pass"
print(result.metadata["net_worth"])  # "7500"
```

## CLI

```bash
pip install finlint-audit[all]
finlint-audit --config finlint.yaml
finlint-audit --config finlint.yaml --format json
finlint-audit --config finlint.yaml --dry-run
```

## Built-in Assertions

| ID | Name | What it checks |
|----|------|---------------|
| `nw-001` | Net Worth Equation | assets + investments - liabilities = net_worth |
| `sign-001` | Sign Correctness | Liabilities non-negative; no credit in asset totals |
| `overlap-001` | Overlap Detection | No duplicate accounts across users |
| `snap-001` | Snapshot Consistency | At most 1 snapshot/account/day; no gaps > N days |
| `drift-001` | Balance Drift | Latest snapshot ≈ current balance |

## License

Apache-2.0
