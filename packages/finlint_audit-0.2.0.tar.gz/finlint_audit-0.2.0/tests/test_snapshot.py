"""TDD tests for snapshot consistency assertion (snap-001)."""

from datetime import datetime
from decimal import Decimal

import pytest

from finlint_audit.assertions.snapshot import assert_snapshot_consistency

from tests.helpers import make_ctx as _ctx, make_snapshot as _snap


class TestSnapshotConsistency:
    def test_one_per_day_passes(self) -> None:
        result = assert_snapshot_consistency(
            _ctx(
                snapshots=[
                    _snap("s1", "a1", 100, "2026-03-13T12:00:00"),
                    _snap("s2", "a1", 100, "2026-03-14T12:00:00"),
                    _snap("s3", "a1", 100, "2026-03-15T12:00:00"),
                ]
            )
        )
        assert result.status == "pass"
        assert result.assertion_id == "snap-001"

    def test_duplicate_same_day_fails(self) -> None:
        result = assert_snapshot_consistency(
            _ctx(
                snapshots=[
                    _snap("s1", "a1", 100, "2026-03-15T08:00:00"),
                    _snap("s2", "a1", 200, "2026-03-15T20:00:00"),
                ]
            )
        )
        assert result.status == "fail"
        assert len(result.evidence) >= 1

    def test_gap_exceeds_max(self) -> None:
        result = assert_snapshot_consistency(
            _ctx(
                snapshots=[
                    _snap("s1", "a1", 100, "2026-03-01T12:00:00"),
                    _snap("s2", "a1", 100, "2026-03-09T12:00:00"),
                ],
                params={"max_gap_days": 7},
            )
        )
        assert result.status == "fail"
        assert "gap" in result.message.lower() or any(
            "gap" in e.actual.lower() for e in result.evidence
        )

    def test_gap_at_boundary_passes(self) -> None:
        result = assert_snapshot_consistency(
            _ctx(
                snapshots=[
                    _snap("s1", "a1", 100, "2026-03-01T12:00:00"),
                    _snap("s2", "a1", 100, "2026-03-08T12:00:00"),
                ],
                params={"max_gap_days": 7},
            )
        )
        assert result.status == "pass"

    def test_no_snapshots_passes(self) -> None:
        result = assert_snapshot_consistency(_ctx())
        assert result.status == "pass"

    def test_single_snapshot_passes(self) -> None:
        result = assert_snapshot_consistency(
            _ctx(
                snapshots=[_snap("s1", "a1", 100, "2026-03-15T12:00:00")]
            )
        )
        assert result.status == "pass"

    def test_mixed_accounts(self) -> None:
        """One clean account, one with gap."""
        result = assert_snapshot_consistency(
            _ctx(
                snapshots=[
                    # a1: clean (daily)
                    _snap("s1", "a1", 100, "2026-03-14T12:00:00"),
                    _snap("s2", "a1", 100, "2026-03-15T12:00:00"),
                    # a2: gap of 10 days
                    _snap("s3", "a2", 200, "2026-03-01T12:00:00"),
                    _snap("s4", "a2", 200, "2026-03-11T12:00:00"),
                ],
                params={"max_gap_days": 7},
            )
        )
        assert result.status == "fail"
        # Evidence only for a2
        assert any("a2" in e.field for e in result.evidence)

    def test_default_max_gap_days(self) -> None:
        """Without params, max_gap_days defaults to 7."""
        result = assert_snapshot_consistency(
            _ctx(
                snapshots=[
                    _snap("s1", "a1", 100, "2026-03-01T12:00:00"),
                    _snap("s2", "a1", 100, "2026-03-09T12:00:00"),
                ],
            )
        )
        assert result.status == "fail"
