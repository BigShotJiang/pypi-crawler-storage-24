"""TDD tests for finlint_audit data models.

Tests written first — models.py does not exist yet.
"""

from datetime import date, datetime
from decimal import Decimal

import pytest

from finlint_audit.models import (
    Account,
    AccountType,
    Holding,
    Liability,
    Snapshot,
    Transaction,
)


class TestAccountType:
    """Blackbox: AccountType enum accepts/rejects correct values."""

    @pytest.mark.parametrize(
        "value",
        ["depository", "credit", "investment", "loan", "other"],
    )
    def test_valid_types(self, value: str) -> None:
        assert AccountType(value) == value

    def test_rejects_invalid_type(self) -> None:
        with pytest.raises(ValueError):
            AccountType("savings")

    def test_rejects_uppercase(self) -> None:
        with pytest.raises(ValueError):
            AccountType("DEPOSITORY")


class TestAccount:
    """Blackbox + whitebox tests for Account dataclass."""

    def test_all_required_fields(self) -> None:
        acct = Account(
            id="acct-1",
            type=AccountType.DEPOSITORY,
            balance_current=Decimal("10000.00"),
        )
        assert acct.id == "acct-1"
        assert acct.type == AccountType.DEPOSITORY
        assert acct.balance_current == Decimal("10000.00")

    def test_defaults(self) -> None:
        acct = Account(
            id="acct-2",
            type=AccountType.CREDIT,
            balance_current=Decimal("500"),
        )
        assert acct.name == ""
        assert acct.mask is None
        assert acct.institution_id is None
        assert acct.institution_name is None
        assert acct.subtype is None
        assert acct.currency == "USD"
        assert acct.is_active is True
        assert acct.exclude_from_net_worth is False
        assert acct.user_id is None

    def test_balance_is_decimal_not_float(self) -> None:
        acct = Account(
            id="acct-3",
            type=AccountType.DEPOSITORY,
            balance_current=Decimal("100.00"),
        )
        assert isinstance(acct.balance_current, Decimal)

    def test_full_construction(self) -> None:
        acct = Account(
            id="acct-4",
            type=AccountType.INVESTMENT,
            balance_current=Decimal("50000.00"),
            name="Fidelity Brokerage",
            mask="8832",
            institution_id="ins_123",
            institution_name="Fidelity",
            subtype="brokerage",
            currency="EUR",
            is_active=True,
            exclude_from_net_worth=False,
            user_id="user-1",
        )
        assert acct.name == "Fidelity Brokerage"
        assert acct.mask == "8832"
        assert acct.currency == "EUR"
        assert acct.user_id == "user-1"

    def test_negative_balance(self) -> None:
        """Overdrafts / credits can have negative balances in raw data."""
        acct = Account(
            id="acct-5",
            type=AccountType.DEPOSITORY,
            balance_current=Decimal("-200.00"),
        )
        assert acct.balance_current == Decimal("-200.00")

    def test_zero_balance(self) -> None:
        acct = Account(
            id="acct-6",
            type=AccountType.DEPOSITORY,
            balance_current=Decimal("0"),
        )
        assert acct.balance_current == Decimal("0")


class TestHolding:
    def test_required_fields(self) -> None:
        h = Holding(
            id="h-1",
            account_id="acct-1",
            institution_value=Decimal("25000.00"),
        )
        assert h.id == "h-1"
        assert h.account_id == "acct-1"
        assert h.institution_value == Decimal("25000.00")

    def test_defaults(self) -> None:
        h = Holding(
            id="h-2",
            account_id="acct-1",
            institution_value=Decimal("0"),
        )
        assert h.ticker is None
        assert h.quantity == Decimal("0")
        assert h.cost_basis is None

    def test_zero_quantity_zero_value(self) -> None:
        h = Holding(
            id="h-3",
            account_id="acct-1",
            institution_value=Decimal("0"),
            quantity=Decimal("0"),
        )
        assert h.institution_value == Decimal("0")
        assert h.quantity == Decimal("0")


class TestLiability:
    def test_required_fields(self) -> None:
        li = Liability(
            id="li-1",
            account_id="acct-1",
            type="credit",
        )
        assert li.type == "credit"

    def test_all_none_optionals(self) -> None:
        li = Liability(
            id="li-2",
            account_id="acct-1",
            type="student",
        )
        assert li.last_statement_balance is None
        assert li.current_balance is None
        assert li.origination_principal is None

    def test_full_construction(self) -> None:
        li = Liability(
            id="li-3",
            account_id="acct-1",
            type="mortgage",
            last_statement_balance=Decimal("250000.00"),
            current_balance=Decimal("248500.00"),
            origination_principal=Decimal("300000.00"),
        )
        assert li.last_statement_balance == Decimal("250000.00")


class TestSnapshot:
    def test_required_fields(self) -> None:
        s = Snapshot(
            id="snap-1",
            account_id="acct-1",
            balance=Decimal("10000.00"),
            captured_at=datetime(2026, 3, 15, 12, 0, 0),
        )
        assert s.balance == Decimal("10000.00")
        assert s.source is None

    def test_ordering_by_captured_at(self) -> None:
        s1 = Snapshot(
            id="snap-1",
            account_id="acct-1",
            balance=Decimal("10000"),
            captured_at=datetime(2026, 3, 14),
        )
        s2 = Snapshot(
            id="snap-2",
            account_id="acct-1",
            balance=Decimal("10100"),
            captured_at=datetime(2026, 3, 15),
        )
        sorted_snaps = sorted([s2, s1], key=lambda s: s.captured_at)
        assert sorted_snaps[0].id == "snap-1"
        assert sorted_snaps[1].id == "snap-2"


class TestTransaction:
    def test_required_fields(self) -> None:
        t = Transaction(
            id="txn-1",
            account_id="acct-1",
            amount=Decimal("42.50"),
            date=date(2026, 3, 15),
        )
        assert t.amount == Decimal("42.50")
        assert t.pending is False
        assert t.name == ""

    def test_negative_amount(self) -> None:
        """Credits are negative in Plaid convention."""
        t = Transaction(
            id="txn-2",
            account_id="acct-1",
            amount=Decimal("-100.00"),
            date=date(2026, 3, 15),
        )
        assert t.amount == Decimal("-100.00")
