"""TDD tests for the assertion runner."""

from decimal import Decimal

import pytest

from finlint_audit.adapters.memory import MemoryAdapter
from finlint_audit.runner import AuditRunner

from tests.helpers import make_account as _acct


class TestRunner:
    def test_executes_all_enabled(self) -> None:
        adapter = MemoryAdapter(
            accounts=[_acct("a1", "depository", 1000)]
        )
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        assert len(results) >= 8  # all 8 built-in assertions
        assert all(r.status in ("pass", "warn", "skip") for r in results)

    def test_skips_disabled(self) -> None:
        adapter = MemoryAdapter(
            accounts=[_acct("a1", "depository", 1000)]
        )
        runner = AuditRunner(
            adapter=adapter,
            disabled={"overlap-001"},
        )
        results = runner.run()
        ids = [r.assertion_id for r in results]
        assert "overlap-001" not in ids
        assert len(results) >= 7

    def test_empty_data_no_crash(self) -> None:
        adapter = MemoryAdapter()
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        assert len(results) >= 8
        assert all(r.status in ("pass", "warn", "skip") for r in results)

    def test_deterministic_order(self) -> None:
        adapter = MemoryAdapter()
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        ids = [r.assertion_id for r in results]
        assert ids == ["nw-001", "sign-001", "overlap-001", "snap-001", "drift-001", "txn-001", "txn-002", "txn-003"]

    def test_params_propagated(self) -> None:
        adapter = MemoryAdapter(
            accounts=[_acct("a1", "depository", 1000)]
        )
        runner = AuditRunner(
            adapter=adapter,
            params={"nw-001": {"tolerance": "0.05"}},
        )
        results = runner.run()
        nw = next(r for r in results if r.assertion_id == "nw-001")
        assert nw.status == "pass"

    def test_mixed_results(self) -> None:
        """Create scenario with pass + fail."""
        adapter = MemoryAdapter(
            accounts=[
                _acct("a1", "depository", 1000),
                _acct("a2", "credit", -500),  # sign fail
            ]
        )
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["sign-001"] == "fail"
        assert statuses["nw-001"] == "pass"

    def test_only_filter(self) -> None:
        adapter = MemoryAdapter()
        runner = AuditRunner(
            adapter=adapter,
            only={"nw-001", "sign-001"},
        )
        results = runner.run()
        ids = [r.assertion_id for r in results]
        assert ids == ["nw-001", "sign-001"]
