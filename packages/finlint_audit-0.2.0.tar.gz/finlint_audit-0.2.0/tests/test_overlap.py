"""TDD tests for overlap detection assertion (overlap-001)."""

from decimal import Decimal

import pytest

from finlint_audit.assertions.overlap import assert_overlap_detection

from tests.helpers import make_ctx as _ctx, make_account as _acct


# ── Blackbox tests ──────────────────────────────────────────────────


class TestOverlapBlackbox:
    def test_no_overlaps(self) -> None:
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        user_id="u1",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                    _acct(
                        "a2",
                        "depository",
                        user_id="u2",
                        institution_id="ins-bofa",
                        subtype="checking",
                        mask="1234",
                    ),
                    _acct(
                        "a3",
                        "investment",
                        user_id="u1",
                        institution_id="ins-fidelity",
                        subtype="brokerage",
                        mask="8832",
                    ),
                ]
            )
        )
        assert result.status == "pass"
        assert result.assertion_id == "overlap-001"

    def test_exact_duplicate_different_users(self) -> None:
        """Same institution+type+subtype+mask across users = 95% confidence."""
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        user_id="u1",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                    _acct(
                        "a2",
                        "depository",
                        user_id="u2",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                ]
            )
        )
        assert result.status == "fail"
        assert len(result.evidence) >= 1
        assert "95%" in result.evidence[0].actual

    def test_same_fingerprint_null_mask(self) -> None:
        """Same institution+type+subtype, null masks = 70% confidence."""
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        user_id="u1",
                        institution_id="ins-chase",
                        subtype="checking",
                    ),
                    _acct(
                        "a2",
                        "depository",
                        user_id="u2",
                        institution_id="ins-chase",
                        subtype="checking",
                    ),
                ]
            )
        )
        assert result.status == "fail"
        assert "70%" in result.evidence[0].actual

    def test_different_masks_no_overlap(self) -> None:
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        user_id="u1",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                    _acct(
                        "a2",
                        "depository",
                        user_id="u2",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="9999",
                    ),
                ]
            )
        )
        assert result.status == "pass"

    def test_same_user_no_overlap(self) -> None:
        """Overlap only applies across different users."""
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        user_id="u1",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                    _acct(
                        "a2",
                        "depository",
                        user_id="u1",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                ]
            )
        )
        assert result.status == "pass"

    def test_single_user_dataset(self) -> None:
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct("a1", "depository", user_id="u1"),
                    _acct("a2", "credit", user_id="u1"),
                ]
            )
        )
        assert result.status == "pass"

    def test_excluded_account_in_overlap_pair(self) -> None:
        """If one account is excluded from net worth, skip the overlap."""
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        user_id="u1",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                    _acct(
                        "a1b",
                        "depository",
                        user_id="u2",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                        exclude_from_net_worth=True,
                    ),
                ]
            )
        )
        assert result.status == "pass"

    def test_empty_dataset(self) -> None:
        result = assert_overlap_detection(_ctx())
        assert result.status == "pass"

    def test_three_way_overlap(self) -> None:
        """3 accounts from 3 users, same fingerprint = multiple pairs."""
        base = dict(
            institution_id="ins-chase",
            subtype="checking",
            mask="4521",
        )
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct("a1", "depository", user_id="u1", **base),
                    _acct("a2", "depository", user_id="u2", **base),
                    _acct("a3", "depository", user_id="u3", **base),
                ]
            )
        )
        assert result.status == "fail"
        # 3 users = 3 pairs: (u1,u2), (u1,u3), (u2,u3)
        assert len(result.evidence) == 3


# ── Whitebox tests ──────────────────────────────────────────────────


class TestOverlapWhitebox:
    def test_institution_name_fallback(self) -> None:
        """When institution_id is None, use institution_name."""
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        user_id="u1",
                        institution_name="Chase",
                        subtype="checking",
                        mask="4521",
                    ),
                    _acct(
                        "a2",
                        "depository",
                        user_id="u2",
                        institution_name="Chase",
                        subtype="checking",
                        mask="4521",
                    ),
                ]
            )
        )
        assert result.status == "fail"

    def test_case_insensitive_type(self) -> None:
        """Type comparison should be case-insensitive at subtype level."""
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        user_id="u1",
                        institution_id="ins-chase",
                        subtype="Checking",
                        mask="4521",
                    ),
                    _acct(
                        "a2",
                        "depository",
                        user_id="u2",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                ]
            )
        )
        assert result.status == "fail"

    def test_mask_empty_string_treated_as_null(self) -> None:
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        user_id="u1",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="",
                    ),
                    _acct(
                        "a2",
                        "depository",
                        user_id="u2",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="",
                    ),
                ]
            )
        )
        assert result.status == "fail"
        assert "70%" in result.evidence[0].actual

    def test_inactive_accounts_skipped(self) -> None:
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        user_id="u1",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                        is_active=False,
                    ),
                    _acct(
                        "a2",
                        "depository",
                        user_id="u2",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                ]
            )
        )
        assert result.status == "pass"

    def test_no_user_id_skips_overlap(self) -> None:
        """If user_id is None, can't determine cross-user overlap."""
        result = assert_overlap_detection(
            _ctx(
                accounts=[
                    _acct(
                        "a1",
                        "depository",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                    _acct(
                        "a2",
                        "depository",
                        institution_id="ins-chase",
                        subtype="checking",
                        mask="4521",
                    ),
                ]
            )
        )
        # Both user_id=None, can't determine cross-user
        assert result.status == "pass"
