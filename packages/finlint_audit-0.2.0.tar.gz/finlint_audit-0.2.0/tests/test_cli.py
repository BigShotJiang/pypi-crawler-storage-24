"""TDD tests for finlint-audit CLI."""

import json
import os
import textwrap

import pytest

from finlint_audit.cli import format_results, format_results_json, format_results_github


# We test the formatting functions directly and CLI via subprocess/click testing
from finlint_audit.models import Evidence
from finlint_audit.result import AssertionResult


def _pass_result(assertion_id="nw-001", name="Net Worth Equation"):
    return AssertionResult(
        assertion_id=assertion_id,
        name=name,
        status="pass",
        message="All good",
        evidence=[],
        metadata={},
    )


def _fail_result(assertion_id="sign-001", name="Sign Correctness"):
    return AssertionResult(
        assertion_id=assertion_id,
        name=name,
        status="fail",
        message="1 issue found",
        evidence=[
            Evidence(
                field="account.id=abc",
                expected="positive balance",
                actual="balance = -500",
            )
        ],
        metadata={},
    )


class TestTextFormatter:
    def test_pass_output(self) -> None:
        text = format_results([_pass_result()])
        assert "✓" in text or "PASS" in text.upper()
        assert "nw-001" in text

    def test_fail_output(self) -> None:
        text = format_results([_fail_result()])
        assert "✗" in text or "FAIL" in text.upper()
        assert "sign-001" in text
        assert "abc" in text

    def test_summary_line(self) -> None:
        text = format_results([_pass_result(), _fail_result()])
        assert "1 passed" in text
        assert "1 failed" in text

    def test_all_pass_summary(self) -> None:
        text = format_results([_pass_result(), _pass_result("snap-001", "Snapshot")])
        assert "2 passed" in text
        assert "failed" not in text.lower() or "0 failed" in text


class TestJsonFormatter:
    def test_valid_json(self) -> None:
        output = format_results_json([_pass_result()])
        data = json.loads(output)
        assert isinstance(data, dict)
        assert "results" in data

    def test_contains_fields(self) -> None:
        output = format_results_json([_fail_result()])
        data = json.loads(output)
        r = data["results"][0]
        assert r["assertion_id"] == "sign-001"
        assert r["status"] == "fail"
        assert len(r["evidence"]) == 1

    def test_summary_in_json(self) -> None:
        output = format_results_json([_pass_result(), _fail_result()])
        data = json.loads(output)
        assert data["summary"]["passed"] == 1
        assert data["summary"]["failed"] == 1


class TestGitHubActionsFormatter:
    def test_error_annotation(self) -> None:
        text = format_results_github([_fail_result()])
        assert "::error::" in text

    def test_no_annotation_on_pass(self) -> None:
        text = format_results_github([_pass_result()])
        assert "::error::" not in text


class TestExitCode:
    def test_all_pass_returns_zero(self) -> None:
        from finlint_audit.cli import compute_exit_code

        assert compute_exit_code([_pass_result()]) == 0

    def test_any_fail_returns_one(self) -> None:
        from finlint_audit.cli import compute_exit_code

        assert compute_exit_code([_pass_result(), _fail_result()]) == 1

    def test_warn_only_returns_zero(self) -> None:
        from finlint_audit.cli import compute_exit_code

        warn = AssertionResult(
            assertion_id="drift-001",
            name="Drift",
            status="warn",
            message="warning",
            evidence=[],
            metadata={},
        )
        assert compute_exit_code([warn]) == 0
