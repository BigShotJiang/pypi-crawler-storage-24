"""TDD tests for SQL adapter query generation."""

from decimal import Decimal

import pytest

from finlint_audit.adapters.sql import SqlAdapter, generate_select
from finlint_audit.config import MappingConfig


class TestGenerateSelect:
    def test_simple_accounts_query(self) -> None:
        mapping = MappingConfig(
            table="accounts",
            columns={"id": "id", "type": "type", "balance_current": "balance"},
        )
        sql = generate_select(mapping)
        assert "SELECT" in sql
        assert "accounts" in sql
        assert "id" in sql
        assert "balance" in sql

    def test_join_clause(self) -> None:
        mapping = MappingConfig(
            table="holdings",
            columns={
                "id": "id",
                "account_id": "account_id",
                "institution_value": "institution_value",
                "ticker": "securities.ticker_symbol",
            },
            joins=[{"table": "securities", "on": "holdings.security_id = securities.id"}],
        )
        sql = generate_select(mapping)
        assert "JOIN" in sql
        assert "securities" in sql
        assert "holdings.security_id = securities.id" in sql

    def test_filter_clause(self) -> None:
        mapping = MappingConfig(
            table="accounts",
            columns={"id": "id", "type": "type", "balance_current": "balance"},
            filter="is_active = true",
        )
        sql = generate_select(mapping)
        assert "WHERE" in sql
        assert "is_active = true" in sql

    def test_column_aliasing(self) -> None:
        mapping = MappingConfig(
            table="accounts",
            columns={"id": "account_id", "type": "account_type"},
        )
        sql = generate_select(mapping)
        # Should alias: account_id AS id, account_type AS type
        assert "AS" in sql

    def test_maps_row_to_account(self) -> None:
        from finlint_audit.models import Account, AccountType

        row = {
            "id": "abc-123",
            "type": "depository",
            "balance_current": "10000.50",
            "name": "Chase Checking",
            "mask": "4521",
            "institution_id": None,
            "institution_name": None,
            "subtype": None,
            "currency": None,
            "is_active": True,
            "exclude_from_net_worth": False,
            "user_id": "user-1",
        }
        acct = SqlAdapter._row_to_account(row)
        assert acct.id == "abc-123"
        assert acct.type == AccountType.DEPOSITORY
        assert acct.balance_current == Decimal("10000.50")
        assert acct.name == "Chase Checking"
        assert acct.is_active is True

    def test_handles_null_columns(self) -> None:
        row = {
            "id": "abc",
            "type": "credit",
            "balance_current": "500",
            "name": None,
            "mask": None,
        }
        acct = SqlAdapter._row_to_account(row)
        assert acct.mask is None
        assert acct.name == ""

    def test_decimal_conversion_from_string(self) -> None:
        row = {
            "id": "abc",
            "type": "depository",
            "balance_current": "10000.50",
        }
        acct = SqlAdapter._row_to_account(row)
        assert isinstance(acct.balance_current, Decimal)
        assert acct.balance_current == Decimal("10000.50")
