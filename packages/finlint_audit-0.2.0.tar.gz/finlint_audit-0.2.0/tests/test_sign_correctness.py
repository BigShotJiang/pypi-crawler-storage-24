"""TDD tests for sign correctness assertion (sign-001)."""

from decimal import Decimal

import pytest

from finlint_audit.assertions.sign_correctness import assert_sign_correctness

from tests.helpers import make_ctx as _ctx, make_account as _acct


# ── Blackbox tests ──────────────────────────────────────────────────


class TestSignCorrectnessBlackbox:
    def test_all_positive_balances(self) -> None:
        result = assert_sign_correctness(
            _ctx(
                accounts=[
                    _acct("a1", "depository", 5000),
                    _acct("a2", "credit", 2000),
                    _acct("a3", "loan", 10000),
                ]
            )
        )
        assert result.status == "pass"
        assert result.assertion_id == "sign-001"

    def test_negative_liability_balance(self) -> None:
        result = assert_sign_correctness(
            _ctx(accounts=[_acct("a1", "credit", -500)])
        )
        assert result.status == "fail"
        assert len(result.evidence) == 1
        assert "a1" in result.evidence[0].field

    def test_negative_asset_balance(self) -> None:
        """Overdraft on depository — should warn."""
        result = assert_sign_correctness(
            _ctx(accounts=[_acct("a1", "depository", -200)])
        )
        assert result.status == "warn"
        assert len(result.evidence) == 1

    def test_zero_balances_pass(self) -> None:
        result = assert_sign_correctness(
            _ctx(
                accounts=[
                    _acct("a1", "depository", 0),
                    _acct("a2", "credit", 0),
                    _acct("a3", "loan", 0),
                ]
            )
        )
        assert result.status == "pass"

    def test_mixed_some_wrong(self) -> None:
        result = assert_sign_correctness(
            _ctx(
                accounts=[
                    _acct("a1", "credit", 500),
                    _acct("a2", "loan", -300),
                ]
            )
        )
        assert result.status == "fail"
        assert len(result.evidence) == 1
        assert "a2" in result.evidence[0].field

    def test_empty_dataset(self) -> None:
        result = assert_sign_correctness(_ctx())
        assert result.status == "pass"

    def test_only_investment_accounts(self) -> None:
        result = assert_sign_correctness(
            _ctx(accounts=[_acct("a1", "investment", 50000)])
        )
        assert result.status == "pass"

    def test_multiple_failures(self) -> None:
        result = assert_sign_correctness(
            _ctx(
                accounts=[
                    _acct("a1", "credit", -100),
                    _acct("a2", "loan", -200),
                ]
            )
        )
        assert result.status == "fail"
        assert len(result.evidence) == 2


# ── Whitebox tests ──────────────────────────────────────────────────


class TestSignCorrectnessWhitebox:
    def test_other_type_treated_as_asset(self) -> None:
        """AccountType.OTHER is an asset, not a liability."""
        result = assert_sign_correctness(
            _ctx(accounts=[_acct("a1", "other", 1000)])
        )
        assert result.status == "pass"

    def test_excluded_accounts_still_checked(self) -> None:
        """Sign correctness matters even for excluded accounts (data hygiene)."""
        result = assert_sign_correctness(
            _ctx(
                accounts=[
                    _acct("a1", "credit", -500, exclude_from_net_worth=True)
                ]
            )
        )
        assert result.status == "fail"

    def test_inactive_accounts_skipped(self) -> None:
        result = assert_sign_correctness(
            _ctx(accounts=[_acct("a1", "credit", -500, is_active=False)])
        )
        assert result.status == "pass"

    def test_fail_takes_precedence_over_warn(self) -> None:
        """If both warn (negative asset) and fail (negative liability), status=fail."""
        result = assert_sign_correctness(
            _ctx(
                accounts=[
                    _acct("a1", "depository", -100),
                    _acct("a2", "credit", -200),
                ]
            )
        )
        assert result.status == "fail"
