"""TDD tests for YAML config parser."""

import os
import textwrap

import pytest

from finlint_audit.config import AuditConfig, parse_config


_MINIMAL_YAML = textwrap.dedent("""\
    version: "1"

    database:
      type: sqlite
      connection: "test.db"

    mapping:
      accounts:
        table: accounts
        columns:
          id: id
          type: type
          balance_current: balance

    assertions:
      net-worth-equation:
        enabled: true
""")

_FULL_YAML = textwrap.dedent("""\
    version: "1"

    database:
      type: postgres
      connection: "${DATABASE_URL}"

    mapping:
      accounts:
        table: financial_accounts
        columns:
          id: id
          type: type
          balance_current: balance_current
          name: name
          mask: mask
          institution_id: institution_name
          is_active: is_active
          exclude_from_net_worth: exclude_from_net_worth
          user_id: user_id
        filter: "is_active = true"

      holdings:
        table: holdings
        columns:
          id: id
          account_id: account_id
          institution_value: institution_value
          ticker: "securities.ticker_symbol"
        joins:
          - table: securities
            on: "holdings.security_id = securities.id"

      liabilities:
        table: liabilities
        columns:
          id: id
          account_id: account_id
          type: type
          last_statement_balance: last_statement_balance

      snapshots:
        table: account_balance_snapshots
        columns:
          id: id
          account_id: account_id
          balance: balance_current
          captured_at: captured_at
          source: source

    assertions:
      net-worth-equation:
        enabled: true
        params:
          tolerance: "0.02"
      sign-correctness:
        enabled: true
      overlap-detection:
        enabled: true
      snapshot-consistency:
        enabled: true
        params:
          max_gap_days: 7
      balance-drift:
        enabled: true
        params:
          tolerance: "1.00"

    output:
      format: text
""")


class TestConfigParser:
    def test_minimal_config(self) -> None:
        cfg = parse_config(_MINIMAL_YAML)
        assert isinstance(cfg, AuditConfig)
        assert cfg.database.type == "sqlite"
        assert cfg.database.connection == "test.db"
        assert "accounts" in cfg.mapping
        assert cfg.mapping["accounts"].table == "accounts"

    def test_env_var_expansion(self, monkeypatch) -> None:
        monkeypatch.setenv("DATABASE_URL", "postgresql://localhost/test")
        cfg = parse_config(_FULL_YAML)
        assert cfg.database.connection == "postgresql://localhost/test"

    def test_missing_env_var_raises(self, monkeypatch) -> None:
        monkeypatch.delenv("DATABASE_URL", raising=False)
        with pytest.raises(ValueError, match="DATABASE_URL"):
            parse_config(_FULL_YAML)

    def test_invalid_yaml(self) -> None:
        with pytest.raises(ValueError, match="[Pp]arse"):
            parse_config(":::invalid yaml{{{}}")

    def test_missing_accounts_mapping(self) -> None:
        yaml = textwrap.dedent("""\
            version: "1"
            database:
              type: sqlite
              connection: "test.db"
            mapping: {}
            assertions: {}
        """)
        with pytest.raises(ValueError, match="accounts"):
            parse_config(yaml)

    def test_extra_keys_ignored(self) -> None:
        yaml = _MINIMAL_YAML + "\ncustom_field: hello\n"
        cfg = parse_config(yaml)
        assert cfg.database.type == "sqlite"

    def test_default_assertion_params(self) -> None:
        cfg = parse_config(_MINIMAL_YAML)
        # net-worth-equation enabled but no params
        assert cfg.assertions["net-worth-equation"].enabled is True
        assert cfg.assertions["net-worth-equation"].params == {}

    def test_filter_clause(self, monkeypatch) -> None:
        monkeypatch.setenv("DATABASE_URL", "postgresql://localhost/test")
        cfg = parse_config(_FULL_YAML)
        assert cfg.mapping["accounts"].filter == "is_active = true"

    def test_join_config(self, monkeypatch) -> None:
        monkeypatch.setenv("DATABASE_URL", "postgresql://localhost/test")
        cfg = parse_config(_FULL_YAML)
        holdings = cfg.mapping["holdings"]
        assert len(holdings.joins) == 1
        assert holdings.joins[0]["table"] == "securities"

    def test_unsupported_version_raises(self) -> None:
        yaml = textwrap.dedent("""\
            version: "2"
            database:
              type: sqlite
              connection: "test.db"
            mapping:
              accounts:
                table: accounts
                columns:
                  id: id
            assertions: {}
        """)
        with pytest.raises(ValueError, match="Unsupported config version"):
            parse_config(yaml)

    def test_version_1_accepted(self) -> None:
        cfg = parse_config(_MINIMAL_YAML)
        assert cfg.database.type == "sqlite"

    def test_no_version_accepted(self) -> None:
        """Config without version field should work (forward compat)."""
        yaml = textwrap.dedent("""\
            database:
              type: sqlite
              connection: "test.db"
            mapping:
              accounts:
                table: accounts
                columns:
                  id: id
            assertions: {}
        """)
        cfg = parse_config(yaml)
        assert cfg.database.type == "sqlite"

    def test_null_assertion_config(self) -> None:
        """YAML null value for assertion config should not crash."""
        yaml = textwrap.dedent("""\
            version: "1"
            database:
              type: sqlite
              connection: "test.db"
            mapping:
              accounts:
                table: accounts
                columns:
                  id: id
            assertions:
              net-worth-equation: ~
        """)
        cfg = parse_config(yaml)
        assert cfg.assertions["net-worth-equation"].enabled is True

    def test_non_mapping_root_raises(self) -> None:
        with pytest.raises(ValueError, match="YAML root must be a mapping"):
            parse_config("- list item")
