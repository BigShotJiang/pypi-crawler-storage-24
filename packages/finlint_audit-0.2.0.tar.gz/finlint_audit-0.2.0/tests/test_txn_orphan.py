"""Tests for txn-002: Orphan Transaction Detection."""

from __future__ import annotations

from finlint_audit.assertions.txn_orphan import assert_txn_orphan

from .helpers import make_ctx, make_transaction, make_account

# Aliases
_ctx = make_ctx
_txn = make_transaction
_acct = make_account


# ===========================================================================
# Blackbox tests — correct outputs for known inputs
# ===========================================================================


class TestOrphanBlackbox:
    def test_empty_transactions(self) -> None:
        result = assert_txn_orphan(_ctx())
        assert result.status == "pass"
        assert result.assertion_id == "txn-002"

    def test_all_valid_references(self) -> None:
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository"), _acct("a2", "credit")],
            transactions=[
                _txn("t1", "a1", "50.00", "2026-03-01"),
                _txn("t2", "a2", "100.00", "2026-03-02"),
            ],
        ))
        assert result.status == "pass"

    def test_single_orphan(self) -> None:
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository")],
            transactions=[
                _txn("t1", "missing-acct", "50.00", "2026-03-01"),
            ],
        ))
        assert result.status == "fail"
        assert len(result.evidence) == 1

    def test_multiple_orphans_same_missing_account(self) -> None:
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository")],
            transactions=[
                _txn("t1", "deleted-acct", "50.00", "2026-03-01"),
                _txn("t2", "deleted-acct", "100.00", "2026-03-02"),
                _txn("t3", "deleted-acct", "75.00", "2026-03-03"),
            ],
        ))
        assert result.status == "fail"
        # Grouped by account — 1 evidence item
        assert len(result.evidence) == 1
        assert "3 transaction(s)" in result.evidence[0].actual

    def test_multiple_orphans_different_accounts(self) -> None:
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository")],
            transactions=[
                _txn("t1", "missing1", "50.00", "2026-03-01"),
                _txn("t2", "missing2", "100.00", "2026-03-02"),
                _txn("t3", "missing2", "75.00", "2026-03-03"),
            ],
        ))
        assert result.status == "fail"
        assert len(result.evidence) == 2

    def test_mix_valid_and_orphan(self) -> None:
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository"), _acct("a2", "credit")],
            transactions=[
                _txn("t1", "a1", "50.00", "2026-03-01"),
                _txn("t2", "a2", "100.00", "2026-03-02"),
                _txn("t3", "a1", "75.00", "2026-03-03"),
                _txn("t4", "a2", "25.00", "2026-03-04"),
                _txn("t5", "a1", "200.00", "2026-03-05"),
                # Orphans
                _txn("t6", "missing1", "50.00", "2026-03-01"),
                _txn("t7", "missing2", "100.00", "2026-03-02"),
            ],
        ))
        assert result.status == "fail"
        assert len(result.evidence) == 2

    def test_inactive_account_still_exists(self) -> None:
        """Account with is_active=False still exists in ctx.accounts —
        transactions referencing it are NOT orphans."""
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository", is_active=False)],
            transactions=[
                _txn("t1", "a1", "50.00", "2026-03-01"),
            ],
        ))
        assert result.status == "pass"

    def test_excluded_account_still_exists(self) -> None:
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository", exclude_from_net_worth=True)],
            transactions=[
                _txn("t1", "a1", "50.00", "2026-03-01"),
            ],
        ))
        assert result.status == "pass"

    def test_single_transaction_single_account(self) -> None:
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository")],
            transactions=[_txn("t1", "a1", "50.00", "2026-03-01")],
        ))
        assert result.status == "pass"


# ===========================================================================
# Whitebox tests — internal branch coverage
# ===========================================================================


class TestOrphanWhitebox:
    def test_no_accounts_loaded(self) -> None:
        """No accounts loaded → warn (data may be incomplete)."""
        result = assert_txn_orphan(_ctx(
            transactions=[
                _txn("t1", "a1", "50.00", "2026-03-01"),
                _txn("t2", "a2", "100.00", "2026-03-02"),
            ],
        ))
        assert result.status == "warn"

    def test_account_ids_case_sensitive(self) -> None:
        """IDs are exact — 'ABC' != 'abc'."""
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("abc", "depository")],
            transactions=[_txn("t1", "ABC", "50.00", "2026-03-01")],
        ))
        assert result.status == "fail"

    def test_account_set_built_correctly(self) -> None:
        """All 10 account IDs recognized."""
        accts = [_acct(f"a{i}", "depository") for i in range(10)]
        txns = [_txn(f"t{i}", f"a{i}", "50.00", "2026-03-01") for i in range(10)]
        result = assert_txn_orphan(_ctx(accounts=accts, transactions=txns))
        assert result.status == "pass"

    def test_metadata_orphan_count(self) -> None:
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository")],
            transactions=[
                _txn("t1", "missing1", "50.00", "2026-03-01"),
                _txn("t2", "missing1", "100.00", "2026-03-02"),
                _txn("t3", "missing2", "75.00", "2026-03-03"),
            ],
        ))
        assert result.metadata["orphan_count"] == "3"

    def test_metadata_orphan_account_ids(self) -> None:
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository")],
            transactions=[
                _txn("t1", "missing1", "50.00", "2026-03-01"),
                _txn("t2", "missing2", "100.00", "2026-03-02"),
            ],
        ))
        ids = result.metadata["orphan_account_ids"]
        assert "missing1" in ids
        assert "missing2" in ids

    def test_evidence_field_contains_account_id(self) -> None:
        result = assert_txn_orphan(_ctx(
            accounts=[_acct("a1", "depository")],
            transactions=[_txn("t1", "deleted-99", "50.00", "2026-03-01")],
        ))
        assert "deleted-99" in result.evidence[0].field
