"""Tests for txn-003: Pending Transaction Staleness."""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from finlint_audit.assertions.txn_pending_staleness import assert_txn_pending_staleness

from .helpers import make_ctx, make_transaction

# Aliases
_ctx = make_ctx
_txn = make_transaction

# Fixed reference point for deterministic tests
_NOW = datetime(2026, 3, 16, 12, 0, 0, tzinfo=timezone.utc)
_TODAY = _NOW.date()


# ===========================================================================
# Blackbox tests — correct outputs for known inputs
# ===========================================================================


class TestPendingStalenessBlackbox:
    def test_empty_transactions(self) -> None:
        result = assert_txn_pending_staleness(_ctx())
        assert result.status == "pass"
        assert result.assertion_id == "txn-003"

    def test_no_pending_transactions(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", pending=False),
            _txn("t2", "a1", "100.00", "2026-03-02", pending=False),
            _txn("t3", "a2", "75.00", "2026-03-03", pending=False),
        ]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.status == "pass"

    def test_fresh_pending(self) -> None:
        yesterday = _TODAY - timedelta(days=1)
        txns = [
            _txn("t1", "a1", "50.00", yesterday.isoformat(), pending=True),
        ]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.status == "pass"

    def test_stale_pending(self) -> None:
        old_date = _TODAY - timedelta(days=20)
        txns = [
            _txn("t1", "a1", "50.00", old_date.isoformat(), pending=True),
        ]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.status == "warn"
        assert len(result.evidence) == 1

    def test_multiple_stale_pending(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", (_TODAY - timedelta(days=20)).isoformat(), pending=True),
            _txn("t2", "a1", "100.00", (_TODAY - timedelta(days=25)).isoformat(), pending=True),
            _txn("t3", "a2", "75.00", (_TODAY - timedelta(days=30)).isoformat(), pending=True),
        ]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.status == "warn"
        assert len(result.evidence) == 3

    def test_mix_fresh_and_stale(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", (_TODAY - timedelta(days=1)).isoformat(), pending=True),
            _txn("t2", "a1", "100.00", (_TODAY - timedelta(days=3)).isoformat(), pending=True),
            _txn("t3", "a1", "75.00", (_TODAY - timedelta(days=20)).isoformat(), pending=True),
        ]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.status == "warn"
        assert len(result.evidence) == 1

    def test_all_pending_all_fresh(self) -> None:
        txns = [
            _txn(f"t{i}", "a1", "50.00", (_TODAY - timedelta(days=i)).isoformat(), pending=True)
            for i in range(1, 6)
        ]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.status == "pass"

    def test_settled_old_transaction(self) -> None:
        """Settled transactions are not checked regardless of age."""
        txns = [
            _txn("t1", "a1", "50.00", (_TODAY - timedelta(days=60)).isoformat(), pending=False),
        ]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.status == "pass"


# ===========================================================================
# Whitebox tests — internal branch coverage
# ===========================================================================


class TestPendingStalenessWhitebox:
    def test_exactly_at_boundary_14_days(self) -> None:
        """14 days old with default stale_days=14 → pass (boundary inclusive: <= stale_days)."""
        boundary_date = _TODAY - timedelta(days=14)
        txns = [_txn("t1", "a1", "50.00", boundary_date.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.status == "pass"

    def test_one_past_boundary_15_days(self) -> None:
        """15 days old → warn (> stale_days)."""
        past_date = _TODAY - timedelta(days=15)
        txns = [_txn("t1", "a1", "50.00", past_date.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.status == "warn"

    def test_custom_stale_days_7(self) -> None:
        old_date = _TODAY - timedelta(days=10)
        txns = [_txn("t1", "a1", "50.00", old_date.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(
            _ctx(transactions=txns, now=_NOW, params={"stale_days": 7})
        )
        assert result.status == "warn"

    def test_custom_stale_days_30(self) -> None:
        old_date = _TODAY - timedelta(days=20)
        txns = [_txn("t1", "a1", "50.00", old_date.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(
            _ctx(transactions=txns, now=_NOW, params={"stale_days": 30})
        )
        assert result.status == "pass"

    def test_stale_days_zero(self) -> None:
        """stale_days=0 means every pending is 'stale'."""
        txns = [_txn("t1", "a1", "50.00", _TODAY.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(
            _ctx(transactions=txns, now=_NOW, params={"stale_days": 0})
        )
        # age=0, 0 > 0 is False, so pass
        assert result.status == "pass"

    def test_stale_days_zero_yesterday(self) -> None:
        """stale_days=0, yesterday's pending → warn."""
        yesterday = _TODAY - timedelta(days=1)
        txns = [_txn("t1", "a1", "50.00", yesterday.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(
            _ctx(transactions=txns, now=_NOW, params={"stale_days": 0})
        )
        assert result.status == "warn"

    def test_stale_days_1_today(self) -> None:
        """stale_days=1, pending from today → pass (0 days old)."""
        txns = [_txn("t1", "a1", "50.00", _TODAY.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(
            _ctx(transactions=txns, now=_NOW, params={"stale_days": 1})
        )
        assert result.status == "pass"

    def test_injected_now_determinism(self) -> None:
        """Fixed ctx.now produces deterministic results."""
        fixed_now = datetime(2026, 6, 1, 12, 0, 0, tzinfo=timezone.utc)
        txns = [
            _txn("t1", "a1", "50.00", "2026-05-10", pending=True),  # 22 days old
        ]
        result = assert_txn_pending_staleness(
            _ctx(transactions=txns, now=fixed_now)
        )
        assert result.status == "warn"

    def test_future_dated_pending(self) -> None:
        """Pending with future date → negative age = fresh."""
        tomorrow = _TODAY + timedelta(days=1)
        txns = [_txn("t1", "a1", "50.00", tomorrow.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.status == "pass"

    def test_metadata_stale_count(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", (_TODAY - timedelta(days=20)).isoformat(), pending=True),
            _txn("t2", "a1", "100.00", (_TODAY - timedelta(days=25)).isoformat(), pending=True),
            _txn("t3", "a2", "75.00", (_TODAY - timedelta(days=30)).isoformat(), pending=True),
        ]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert result.metadata["stale_pending_count"] == "3"

    def test_evidence_contains_txn_date(self) -> None:
        old_date = _TODAY - timedelta(days=20)
        txns = [_txn("t1", "a1", "50.00", old_date.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert old_date.isoformat() in result.evidence[0].field

    def test_invalid_stale_days_skips(self) -> None:
        """Non-numeric stale_days gracefully skips."""
        txns = [_txn("t1", "a1", "50.00", _TODAY.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(
            _ctx(transactions=txns, now=_NOW, params={"stale_days": "abc"})
        )
        assert result.status == "skip"

    def test_evidence_contains_threshold(self) -> None:
        old_date = _TODAY - timedelta(days=20)
        txns = [_txn("t1", "a1", "50.00", old_date.isoformat(), pending=True)]
        result = assert_txn_pending_staleness(_ctx(transactions=txns, now=_NOW))
        assert "14" in result.evidence[0].expected
