"""TDD tests for assertion result models."""

from decimal import Decimal

import pytest

from finlint_audit.models import Account, AccountType
from finlint_audit.result import AssertionContext, AssertionResult, Evidence


class TestEvidence:
    def test_construction(self) -> None:
        e = Evidence(
            field="account.id=abc123",
            expected="balance >= 0",
            actual="balance = -500.00",
        )
        assert e.field == "account.id=abc123"
        assert e.expected == "balance >= 0"
        assert e.actual == "balance = -500.00"

    def test_fields_are_strings(self) -> None:
        """Evidence fields should be human-readable strings, not raw Decimals."""
        e = Evidence(
            field="account.id=x",
            expected="10000.00",
            actual="9999.50",
        )
        assert isinstance(e.expected, str)
        assert isinstance(e.actual, str)


class TestAssertionResult:
    def test_pass_status(self) -> None:
        r = AssertionResult(
            assertion_id="nw-001",
            name="Net Worth Equation",
            status="pass",
            message="Net worth = $142,500.00",
            evidence=[],
            metadata={"net_worth": "142500.00"},
        )
        assert r.status == "pass"
        assert r.evidence == []

    def test_fail_with_evidence(self) -> None:
        ev = Evidence(
            field="account.id=abc",
            expected="positive balance",
            actual="balance = -500",
        )
        r = AssertionResult(
            assertion_id="sign-001",
            name="Sign Correctness",
            status="fail",
            message="1 liability has negative balance",
            evidence=[ev],
            metadata={},
        )
        assert r.status == "fail"
        assert len(r.evidence) == 1
        assert r.evidence[0].field == "account.id=abc"

    def test_warn_status(self) -> None:
        r = AssertionResult(
            assertion_id="drift-001",
            name="Balance Drift",
            status="warn",
            message="2 accounts have no snapshots",
            evidence=[],
            metadata={},
        )
        assert r.status == "warn"

    def test_skip_status(self) -> None:
        r = AssertionResult(
            assertion_id="snap-001",
            name="Snapshot Consistency",
            status="skip",
            message="No snapshot data available",
            evidence=[],
            metadata={},
        )
        assert r.status == "skip"


class TestAssertionContext:
    def test_empty_lists(self) -> None:
        ctx = AssertionContext(
            accounts=[],
            holdings=[],
            liabilities=[],
            snapshots=[],
            transactions=[],
        )
        assert ctx.accounts == []
        assert ctx.params == {}

    def test_params_default_empty_dict(self) -> None:
        ctx = AssertionContext(
            accounts=[],
            holdings=[],
            liabilities=[],
            snapshots=[],
            transactions=[],
        )
        assert ctx.params == {}
        # No KeyError when accessing
        assert ctx.params.get("tolerance") is None

    def test_with_params(self) -> None:
        ctx = AssertionContext(
            accounts=[],
            holdings=[],
            liabilities=[],
            snapshots=[],
            transactions=[],
            params={"tolerance": "0.02"},
        )
        assert ctx.params["tolerance"] == "0.02"

    def test_with_data(self) -> None:
        acct = Account(
            id="acct-1",
            type=AccountType.DEPOSITORY,
            balance_current=Decimal("10000"),
        )
        ctx = AssertionContext(
            accounts=[acct],
            holdings=[],
            liabilities=[],
            snapshots=[],
            transactions=[],
        )
        assert len(ctx.accounts) == 1
        assert ctx.accounts[0].id == "acct-1"
