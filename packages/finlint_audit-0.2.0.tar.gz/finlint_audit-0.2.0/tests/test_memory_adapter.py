"""TDD tests for in-memory data adapter."""

from decimal import Decimal

from finlint_audit.adapters.memory import MemoryAdapter
from finlint_audit.adapters.base import DataAdapter
from finlint_audit.models import Account, AccountType


class TestMemoryAdapter:
    def test_returns_provided_accounts(self) -> None:
        acct = Account(
            id="a1",
            type=AccountType.DEPOSITORY,
            balance_current=Decimal("1000"),
        )
        adapter = MemoryAdapter(accounts=[acct])
        assert adapter.load_accounts() == [acct]

    def test_empty_by_default(self) -> None:
        adapter = MemoryAdapter()
        assert adapter.load_accounts() == []
        assert adapter.load_holdings() == []
        assert adapter.load_liabilities() == []
        assert adapter.load_snapshots() == []
        assert adapter.load_transactions() == []

    def test_conforms_to_protocol(self) -> None:
        adapter = MemoryAdapter()
        assert isinstance(adapter, DataAdapter)
