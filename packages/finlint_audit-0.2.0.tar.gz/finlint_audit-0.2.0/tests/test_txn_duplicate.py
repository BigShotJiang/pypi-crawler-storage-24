"""Tests for txn-001: Duplicate Transaction Detection."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

from finlint_audit.assertions.txn_duplicate import assert_txn_duplicate

from .helpers import make_ctx, make_transaction, make_account

# Aliases
_ctx = make_ctx
_txn = make_transaction
_acct = make_account


# ===========================================================================
# Blackbox tests — correct outputs for known inputs
# ===========================================================================


class TestDuplicateBlackbox:
    def test_empty_dataset(self) -> None:
        result = assert_txn_duplicate(_ctx())
        assert result.status == "pass"
        assert result.assertion_id == "txn-001"

    def test_all_unique(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a2", "100.00", "2026-03-02", name="Grocery"),
            _txn("t3", "a1", "75.00", "2026-03-03", name="Gas"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_single_transaction(self) -> None:
        result = assert_txn_duplicate(
            _ctx(transactions=[_txn("t1", "a1", "50.00", "2026-03-01")])
        )
        assert result.status == "pass"

    def test_exact_duplicate_pair(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "50.00", "2026-03-01", name="Coffee"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "fail"
        assert len(result.evidence) == 1

    def test_triple_duplicate(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t3", "a1", "50.00", "2026-03-01", name="Coffee"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "fail"
        assert "3" in result.evidence[0].actual

    def test_multiple_duplicate_groups(self) -> None:
        txns = [
            # Group 1: duplicate pair
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "50.00", "2026-03-01", name="Coffee"),
            # Group 2: duplicate pair
            _txn("t3", "a2", "100.00", "2026-03-02", name="Grocery"),
            _txn("t4", "a2", "100.00", "2026-03-02", name="Grocery"),
            # Unique
            _txn("t5", "a1", "75.00", "2026-03-03", name="Gas"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "fail"
        assert len(result.evidence) == 2

    def test_same_amount_date_different_name(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "50.00", "2026-03-01", name="Tea"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_same_amount_date_name_different_account(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a2", "50.00", "2026-03-01", name="Coffee"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_same_everything_except_amount(self) -> None:
        txns = [
            _txn("t1", "a1", "10.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "20.00", "2026-03-01", name="Coffee"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_negative_amounts_refunds(self) -> None:
        txns = [
            _txn("t1", "a1", "-50.00", "2026-03-01", name="Refund"),
            _txn("t2", "a1", "-50.00", "2026-03-01", name="Refund"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "fail"

    def test_zero_amount_transactions(self) -> None:
        txns = [
            _txn("t1", "a1", "0", "2026-03-01", name="Auth Hold"),
            _txn("t2", "a1", "0", "2026-03-01", name="Auth Hold"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "fail"

    def test_very_large_amounts(self) -> None:
        txns = [
            _txn("t1", "a1", "9999999999.99", "2026-03-01", name="Wire"),
            _txn("t2", "a1", "9999999999.99", "2026-03-01", name="Wire"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "fail"


# ===========================================================================
# Whitebox tests — internal branch coverage
# ===========================================================================


class TestDuplicateWhitebox:
    def test_pending_vs_settled_same_fields(self) -> None:
        """pending is not in default match_fields, so pending+settled with
        same account/amount/date/name are duplicates."""
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee", pending=True),
            _txn("t2", "a1", "50.00", "2026-03-01", name="Coffee", pending=False),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "fail"

    def test_custom_match_fields_amount_date(self) -> None:
        """Looser matching with only amount+date catches more."""
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a2", "50.00", "2026-03-01", name="Tea"),
        ]
        result = assert_txn_duplicate(
            _ctx(transactions=txns, params={"match_fields": "amount,date"})
        )
        assert result.status == "fail"

    def test_custom_match_fields_account_only(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "100.00", "2026-03-02", name="Tea"),
        ]
        result = assert_txn_duplicate(
            _ctx(transactions=txns, params={"match_fields": "account_id"})
        )
        assert result.status == "fail"

    def test_invalid_match_field_name(self) -> None:
        txns = [_txn("t1", "a1", "50.00", "2026-03-01")]
        result = assert_txn_duplicate(
            _ctx(transactions=txns, params={"match_fields": "nonexistent"})
        )
        assert result.status == "skip"

    def test_id_rejected_as_match_field(self) -> None:
        """id is excluded from valid match fields — grouping by id is useless."""
        txns = [_txn("t1", "a1", "50.00", "2026-03-01")]
        result = assert_txn_duplicate(
            _ctx(transactions=txns, params={"match_fields": "id"})
        )
        assert result.status == "skip"

    def test_pending_rejected_as_match_field(self) -> None:
        """pending is excluded from valid match fields."""
        txns = [_txn("t1", "a1", "50.00", "2026-03-01")]
        result = assert_txn_duplicate(
            _ctx(transactions=txns, params={"match_fields": "pending"})
        )
        assert result.status == "skip"

    def test_empty_match_fields_string(self) -> None:
        txns = [_txn("t1", "a1", "50.00", "2026-03-01")]
        result = assert_txn_duplicate(
            _ctx(transactions=txns, params={"match_fields": ""})
        )
        assert result.status == "skip"

    def test_decimal_precision_grouping(self) -> None:
        """$10.10 matches $10.10 — Decimal equality works."""
        txns = [
            _txn("t1", "a1", "10.10", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "10.10", "2026-03-01", name="Coffee"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "fail"

    def test_whitespace_in_name_exact_match(self) -> None:
        """Exact string match — trailing whitespace makes them different."""
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee "),
            _txn("t2", "a1", "50.00", "2026-03-01", name="Coffee"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.status == "pass"

    def test_metadata_duplicate_group_count(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t3", "a2", "100.00", "2026-03-02", name="Grocery"),
            _txn("t4", "a2", "100.00", "2026-03-02", name="Grocery"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.metadata["duplicate_group_count"] == "2"

    def test_metadata_total_duplicates(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t3", "a1", "50.00", "2026-03-01", name="Coffee"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.metadata["total_duplicates"] == "3"

    def test_evidence_field_format(self) -> None:
        txns = [
            _txn("t1", "a1", "50.00", "2026-03-01", name="Coffee"),
            _txn("t2", "a1", "50.00", "2026-03-01", name="Coffee"),
        ]
        result = assert_txn_duplicate(_ctx(transactions=txns))
        assert result.evidence[0].field == "account_id=a1"
        assert "unique" in result.evidence[0].expected
        assert "2 duplicates" in result.evidence[0].actual
