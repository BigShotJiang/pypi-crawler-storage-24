"""Integration tests for transaction assertions with the full pipeline.

Verifies config → adapter → assertion → runner → results flow.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from finlint_audit.adapters.memory import MemoryAdapter
from finlint_audit.cli import compute_exit_code, format_results, format_results_json
from finlint_audit.runner import AuditRunner

from .helpers import make_account, make_snapshot, make_transaction

_acct = make_account
_txn = make_transaction
_snap = make_snapshot

_NOW = datetime(2026, 3, 16, 12, 0, 0, tzinfo=timezone.utc)


def _clean_adapter():
    """Adapter with clean data — all assertions should pass."""
    return MemoryAdapter(
        accounts=[
            _acct("a1", "depository", 15000),
            _acct("a2", "investment", 0),
            _acct("a3", "credit", 2500),
        ],
        holdings=[],
        snapshots=[
            _snap("s1", "a1", 15000, _NOW - timedelta(days=1)),
            _snap("s2", "a2", 0, _NOW - timedelta(days=1)),
            _snap("s3", "a3", 2500, _NOW - timedelta(days=1)),
        ],
        transactions=[
            _txn("t1", "a1", "50.00", "2026-03-10", name="Coffee"),
            _txn("t2", "a1", "120.00", "2026-03-11", name="Grocery"),
            _txn("t3", "a3", "45.99", "2026-03-12", name="Gas"),
        ],
    )


def _dirty_adapter():
    """Adapter with transaction issues — txn assertions should fail/warn."""
    return MemoryAdapter(
        accounts=[
            _acct("a1", "depository", 15000),
            _acct("a2", "credit", 2500),
        ],
        holdings=[],
        snapshots=[
            _snap("s1", "a1", 15000, _NOW - timedelta(days=1)),
            _snap("s2", "a2", 2500, _NOW - timedelta(days=1)),
        ],
        transactions=[
            # Duplicate pair
            _txn("t1", "a1", "50.00", "2026-03-10", name="Coffee"),
            _txn("t2", "a1", "50.00", "2026-03-10", name="Coffee"),
            # Orphan
            _txn("t3", "deleted-acct", "75.00", "2026-03-11", name="Grocery"),
            # Stale pending (30 days old)
            _txn("t4", "a1", "25.00", "2026-02-14", pending=True),
            # Valid
            _txn("t5", "a1", "100.00", "2026-03-12", name="Restaurant"),
        ],
    )


class TestRunnerWithTransactions:
    def test_executes_all_8_assertions(self) -> None:
        runner = AuditRunner(adapter=_clean_adapter())
        results = runner.run()
        assert len(results) >= 8
        ids = [r.assertion_id for r in results]
        assert "txn-001" in ids
        assert "txn-002" in ids
        assert "txn-003" in ids

    def test_only_filter_txn_001(self) -> None:
        runner = AuditRunner(adapter=_clean_adapter(), only={"txn-001"})
        results = runner.run()
        assert len(results) == 1
        assert results[0].assertion_id == "txn-001"

    def test_disabled_txn_assertions(self) -> None:
        runner = AuditRunner(
            adapter=_clean_adapter(),
            disabled={"txn-001", "txn-002", "txn-003"},
        )
        results = runner.run()
        ids = [r.assertion_id for r in results]
        assert "txn-001" not in ids
        assert "txn-002" not in ids
        assert "txn-003" not in ids
        assert len(results) >= 5

    def test_params_propagated(self) -> None:
        runner = AuditRunner(
            adapter=_clean_adapter(),
            params={"txn-003": {"stale_days": 7}},
            only={"txn-003"},
        )
        results = runner.run()
        assert len(results) == 1
        assert results[0].status == "pass"

    def test_memory_adapter_loads_transactions(self) -> None:
        adapter = _clean_adapter()
        txns = adapter.load_transactions()
        assert len(txns) == 3
        assert all(hasattr(t, "account_id") for t in txns)

    def test_mixed_results_existing_pass_txn_fail(self) -> None:
        runner = AuditRunner(adapter=_dirty_adapter())
        results = runner.run()
        assert len(results) >= 8
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["txn-001"] == "fail"
        assert statuses["txn-002"] == "fail"
        assert statuses["txn-003"] == "warn"
        # Original assertions should still pass
        assert statuses["nw-001"] == "pass"

    def test_empty_transactions_others_unaffected(self) -> None:
        adapter = MemoryAdapter(
            accounts=[_acct("a1", "depository", 10000)],
            snapshots=[_snap("s1", "a1", 10000, _NOW - timedelta(days=1))],
        )
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        statuses = {r.assertion_id: r.status for r in results}
        assert statuses["txn-001"] == "pass"
        assert statuses["txn-002"] == "pass"
        assert statuses["txn-003"] == "pass"

    def test_transactions_no_other_data(self) -> None:
        adapter = MemoryAdapter(
            transactions=[_txn("t1", "a1", "50.00", "2026-03-10")],
        )
        runner = AuditRunner(adapter=adapter)
        results = runner.run()
        # Should not crash
        assert len(results) >= 8
        statuses = {r.assertion_id: r.status for r in results}
        # txn-002 should warn (no accounts loaded)
        assert statuses["txn-002"] == "warn"


class TestPipelineOutput:
    def test_text_output_includes_txn_results(self) -> None:
        runner = AuditRunner(adapter=_dirty_adapter())
        results = runner.run()
        text = format_results(results)
        assert "txn-001" in text
        assert "txn-002" in text
        assert "txn-003" in text
        assert "Results:" in text

    def test_json_output_includes_txn_ids(self) -> None:
        runner = AuditRunner(adapter=_dirty_adapter())
        results = runner.run()
        output = format_results_json(results)
        data = json.loads(output)
        ids = [r["assertion_id"] for r in data["results"]]
        assert "txn-001" in ids
        assert "txn-002" in ids
        assert "txn-003" in ids

    def test_exit_code_1_when_txn_fails(self) -> None:
        runner = AuditRunner(adapter=_dirty_adapter())
        results = runner.run()
        assert compute_exit_code(results) == 1

    def test_exit_code_0_when_only_txn_pass(self) -> None:
        runner = AuditRunner(
            adapter=_clean_adapter(),
            only={"txn-001", "txn-002", "txn-003"},
        )
        results = runner.run()
        assert compute_exit_code(results) == 0
