"""TDD tests for balance drift assertion (drift-001)."""

from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest

from finlint_audit.assertions.balance_drift import assert_balance_drift

from tests.helpers import make_ctx as _ctx, make_account as _acct, make_snapshot as _snap


class TestBalanceDrift:
    def test_exact_match(self) -> None:
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000)],
                snapshots=[_snap("s1", "a1", 10000, "2026-03-15T12:00:00")],
                params={"tolerance": "1.00"},
            )
        )
        assert result.status == "pass"
        assert result.assertion_id == "drift-001"

    def test_drift_within_tolerance(self) -> None:
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000)],
                snapshots=[_snap("s1", "a1", "10000.50", "2026-03-15T12:00:00")],
                params={"tolerance": "1.00"},
            )
        )
        assert result.status == "pass"

    def test_drift_exceeds_tolerance(self) -> None:
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000)],
                snapshots=[_snap("s1", "a1", 10005, "2026-03-15T12:00:00")],
                params={"tolerance": "1.00"},
            )
        )
        assert result.status == "fail"
        assert len(result.evidence) == 1

    def test_no_snapshots_for_account(self) -> None:
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000)],
                snapshots=[],
                params={"tolerance": "1.00"},
            )
        )
        assert result.status == "warn"

    def test_stale_snapshot(self) -> None:
        """Snapshot older than 7 days is considered stale."""
        old = datetime(2026, 3, 1, 12, 0, 0)
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000)],
                snapshots=[_snap("s1", "a1", 10000, old)],
                params={"tolerance": "1.00", "stale_days": 7},
            )
        )
        assert result.status == "warn"

    def test_multiple_snapshots_uses_latest(self) -> None:
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000)],
                snapshots=[
                    _snap("s1", "a1", 5000, "2026-03-13T12:00:00"),
                    _snap("s2", "a1", 10000, "2026-03-15T12:00:00"),
                    _snap("s3", "a1", 7000, "2026-03-14T12:00:00"),
                ],
                params={"tolerance": "1.00"},
            )
        )
        assert result.status == "pass"

    def test_negative_balance_drift(self) -> None:
        """Credit card balance change should still check absolute difference."""
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "credit", 2000)],
                snapshots=[_snap("s1", "a1", 2005, "2026-03-15T12:00:00")],
                params={"tolerance": "1.00"},
            )
        )
        assert result.status == "fail"

    def test_inactive_accounts_skipped(self) -> None:
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000, is_active=False)],
                snapshots=[_snap("s1", "a1", 5000, "2026-03-15T12:00:00")],
                params={"tolerance": "1.00"},
            )
        )
        assert result.status == "pass"

    def test_default_tolerance(self) -> None:
        """Without params, tolerance defaults to $1.00."""
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000)],
                snapshots=[_snap("s1", "a1", 10002, "2026-03-15T12:00:00")],
            )
        )
        assert result.status == "fail"

    def test_timezone_aware_snapshots(self) -> None:
        """Timezone-aware snapshots should not crash (the original bug)."""
        now = datetime(2026, 3, 16, 12, 0, 0, tzinfo=timezone.utc)
        snap_time = datetime(2026, 3, 15, 12, 0, 0, tzinfo=timezone.utc)
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000)],
                snapshots=[_snap("s1", "a1", 10000, snap_time)],
                params={"tolerance": "1.00"},
                now=now,
            )
        )
        assert result.status == "pass"

    def test_deterministic_with_injected_now(self) -> None:
        """Injecting `now` makes the assertion deterministic."""
        now = datetime(2026, 3, 16, 12, 0, 0)
        snap_time = datetime(2026, 3, 15, 12, 0, 0)
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000)],
                snapshots=[_snap("s1", "a1", 10000, snap_time)],
                params={"tolerance": "1.00", "stale_days": 7},
                now=now,
            )
        )
        assert result.status == "pass"
        assert result.metadata["fail_count"] == 0

    def test_stale_with_injected_now(self) -> None:
        """Injecting `now` 10 days after snapshot should trigger staleness warning."""
        now = datetime(2026, 3, 25, 12, 0, 0)
        snap_time = datetime(2026, 3, 15, 12, 0, 0)
        result = assert_balance_drift(
            _ctx(
                accounts=[_acct("a1", "depository", 10000)],
                snapshots=[_snap("s1", "a1", 10000, snap_time)],
                params={"tolerance": "1.00", "stale_days": 7},
                now=now,
            )
        )
        assert result.status == "warn"
