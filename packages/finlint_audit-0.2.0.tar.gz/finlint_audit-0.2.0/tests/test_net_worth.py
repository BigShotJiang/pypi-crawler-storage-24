"""TDD tests for net worth equation assertion (nw-001).

Tests written first — net_worth.py does not exist yet.
"""

from decimal import Decimal

import pytest

from finlint_audit.assertions.net_worth import assert_net_worth
from finlint_audit.models import Liability

from tests.helpers import make_ctx as _ctx, make_account as _acct, make_holding as _holding


def _liability(id, account_id, type, **kwargs) -> Liability:
    decimal_fields = [
        "last_statement_balance",
        "current_balance",
        "origination_principal",
    ]
    for f in decimal_fields:
        if f in kwargs and kwargs[f] is not None:
            kwargs[f] = Decimal(str(kwargs[f]))
    return Liability(id=id, account_id=account_id, type=type, **kwargs)


# ── Blackbox tests ──────────────────────────────────────────────────


class TestNetWorthBlackbox:
    def test_single_checking(self) -> None:
        result = assert_net_worth(
            _ctx(accounts=[_acct("a1", "depository", 10000)])
        )
        assert result.status == "pass"
        assert result.assertion_id == "nw-001"
        assert Decimal(result.metadata["net_worth"]) == Decimal("10000")

    def test_checking_plus_credit(self) -> None:
        result = assert_net_worth(
            _ctx(
                accounts=[
                    _acct("a1", "depository", 10000),
                    _acct("a2", "credit", 2500),
                ],
            )
        )
        assert result.status == "pass"
        assert Decimal(result.metadata["net_worth"]) == Decimal("7500")

    def test_investment_holdings(self) -> None:
        result = assert_net_worth(
            _ctx(
                accounts=[_acct("a1", "investment", 0)],
                holdings=[_holding("h1", "a1", 50000)],
            )
        )
        assert result.status == "pass"
        assert Decimal(result.metadata["total_investments"]) == Decimal("50000")
        assert Decimal(result.metadata["net_worth"]) == Decimal("50000")

    def test_mixed_portfolio(self) -> None:
        result = assert_net_worth(
            _ctx(
                accounts=[
                    _acct("a1", "depository", 15000),
                    _acct("a2", "depository", 5000),
                    _acct("a3", "investment", 0),
                    _acct("a4", "credit", 3000),
                    _acct("a5", "loan", 20000),
                ],
                holdings=[
                    _holding("h1", "a3", 30000),
                    _holding("h2", "a3", 20000),
                ],
            )
        )
        assert result.status == "pass"
        # assets: 15000 + 5000 = 20000
        # investments: 30000 + 20000 = 50000
        # liabilities: 3000 + 20000 = 23000
        # net_worth: 20000 + 50000 - 23000 = 47000
        assert Decimal(result.metadata["net_worth"]) == Decimal("47000")

    def test_excluded_account_skipped(self) -> None:
        result = assert_net_worth(
            _ctx(
                accounts=[
                    _acct("a1", "depository", 10000, exclude_from_net_worth=True),
                    _acct("a2", "depository", 5000),
                ],
            )
        )
        assert result.status == "pass"
        assert Decimal(result.metadata["net_worth"]) == Decimal("5000")

    def test_inactive_accounts_skipped(self) -> None:
        result = assert_net_worth(
            _ctx(
                accounts=[_acct("a1", "depository", 10000, is_active=False)],
            )
        )
        assert result.status == "pass"
        assert Decimal(result.metadata["net_worth"]) == Decimal("0")

    def test_all_liabilities(self) -> None:
        result = assert_net_worth(
            _ctx(
                accounts=[
                    _acct("a1", "credit", 5000),
                    _acct("a2", "loan", 10000),
                ],
            )
        )
        assert result.status == "pass"
        assert Decimal(result.metadata["net_worth"]) == Decimal("-15000")

    def test_empty_dataset(self) -> None:
        result = assert_net_worth(_ctx())
        assert result.status == "pass"
        assert Decimal(result.metadata["net_worth"]) == Decimal("0")

    def test_zero_balances(self) -> None:
        result = assert_net_worth(
            _ctx(
                accounts=[
                    _acct("a1", "depository", 0),
                    _acct("a2", "credit", 0),
                ],
            )
        )
        assert result.status == "pass"
        assert Decimal(result.metadata["net_worth"]) == Decimal("0")

    def test_tolerance_boundary_pass(self) -> None:
        """Drift of $0.01 with tolerance $0.02 should pass."""
        # One checking + one credit, holdings empty.
        # We'll create a scenario where the internal sums are consistent.
        result = assert_net_worth(
            _ctx(
                accounts=[_acct("a1", "depository", "100.01")],
                params={"tolerance": "0.02"},
            )
        )
        assert result.status == "pass"

    def test_other_type_treated_as_asset(self) -> None:
        result = assert_net_worth(
            _ctx(accounts=[_acct("a1", "other", 3000)])
        )
        assert result.status == "pass"
        assert Decimal(result.metadata["total_assets"]) == Decimal("3000")

    def test_large_numbers(self) -> None:
        result = assert_net_worth(
            _ctx(
                accounts=[
                    _acct("a1", "depository", "9999999999.99"),
                    _acct("a2", "loan", "5000000000.00"),
                ],
            )
        )
        assert result.status == "pass"
        assert Decimal(result.metadata["net_worth"]) == Decimal("4999999999.99")


# ── Whitebox tests ──────────────────────────────────────────────────


class TestNetWorthWhitebox:
    def test_liability_fallback_to_account_balance(self) -> None:
        """When no Liability record exists, uses account.balance_current."""
        result = assert_net_worth(
            _ctx(accounts=[_acct("a1", "credit", 2500)])
        )
        assert Decimal(result.metadata["total_liabilities"]) == Decimal("2500")

    def test_liability_uses_last_statement_balance(self) -> None:
        """When Liability record has last_statement_balance, prefer it."""
        result = assert_net_worth(
            _ctx(
                accounts=[_acct("a1", "credit", 2000)],
                liabilities=[
                    _liability(
                        "li1",
                        "a1",
                        "credit",
                        last_statement_balance=2500,
                    )
                ],
            )
        )
        # Should use max(account-based=2000, liability-table=2500) = 2500
        assert Decimal(result.metadata["total_liabilities"]) == Decimal("2500")

    def test_liability_uses_current_balance_fallback(self) -> None:
        """When no last_statement_balance, uses current_balance."""
        result = assert_net_worth(
            _ctx(
                accounts=[_acct("a1", "credit", 1000)],
                liabilities=[
                    _liability(
                        "li1",
                        "a1",
                        "credit",
                        current_balance=1800,
                    )
                ],
            )
        )
        assert Decimal(result.metadata["total_liabilities"]) == Decimal("1800")

    def test_liability_origination_principal_fallback(self) -> None:
        """Loans: use origination_principal as last fallback."""
        result = assert_net_worth(
            _ctx(
                accounts=[_acct("a1", "loan", 0)],
                liabilities=[
                    _liability(
                        "li1",
                        "a1",
                        "mortgage",
                        origination_principal=300000,
                    )
                ],
            )
        )
        assert Decimal(result.metadata["total_liabilities"]) == Decimal("300000")

    def test_holdings_for_non_investment_ignored(self) -> None:
        """Holdings linked to depository accounts are ignored."""
        result = assert_net_worth(
            _ctx(
                accounts=[_acct("a1", "depository", 5000)],
                holdings=[_holding("h1", "a1", 99999)],
            )
        )
        # Holdings for non-investment account should not count
        assert Decimal(result.metadata["total_investments"]) == Decimal("0")
        assert Decimal(result.metadata["net_worth"]) == Decimal("5000")

    def test_multiple_holdings_summed(self) -> None:
        result = assert_net_worth(
            _ctx(
                accounts=[_acct("a1", "investment", 0)],
                holdings=[
                    _holding("h1", "a1", 10000),
                    _holding("h2", "a1", 15000),
                    _holding("h3", "a1", 5000),
                ],
            )
        )
        assert Decimal(result.metadata["total_investments"]) == Decimal("30000")

    def test_decimal_precision_no_ieee754_drift(self) -> None:
        """0.1 + 0.2 + 0.3 should equal 0.6 exactly."""
        result = assert_net_worth(
            _ctx(
                accounts=[
                    _acct("a1", "depository", "0.1"),
                    _acct("a2", "depository", "0.2"),
                    _acct("a3", "depository", "0.3"),
                ],
            )
        )
        assert Decimal(result.metadata["net_worth"]) == Decimal("0.6")

    def test_investment_account_balance_not_double_counted(self) -> None:
        """Investment account balance_current should NOT be added to assets."""
        result = assert_net_worth(
            _ctx(
                accounts=[_acct("a1", "investment", 50000)],
                holdings=[_holding("h1", "a1", 50000)],
            )
        )
        # Only holdings count, not the account balance
        assert Decimal(result.metadata["total_assets"]) == Decimal("0")
        assert Decimal(result.metadata["total_investments"]) == Decimal("50000")
        assert Decimal(result.metadata["net_worth"]) == Decimal("50000")

    def test_max_of_account_vs_liability_table(self) -> None:
        """Uses max of account-based and liability-table totals."""
        result = assert_net_worth(
            _ctx(
                accounts=[
                    _acct("a1", "credit", 5000),  # account says 5000
                    _acct("a2", "credit", 3000),  # account says 3000
                ],
                liabilities=[
                    _liability(
                        "li1", "a1", "credit", last_statement_balance=4000
                    ),
                    _liability(
                        "li2", "a2", "credit", last_statement_balance=4000
                    ),
                ],
            )
        )
        # Account-based: 5000 + 3000 = 8000
        # Liability-table: 4000 + 4000 = 8000
        # max(8000, 8000) = 8000
        assert Decimal(result.metadata["total_liabilities"]) == Decimal("8000")

    def test_liability_zero_balance_not_skipped(self) -> None:
        """Decimal('0') is falsy in Python — ensure it's not skipped in fallback chain."""
        result = assert_net_worth(
            _ctx(
                accounts=[_acct("a1", "credit", 0)],
                liabilities=[
                    _liability(
                        "li1", "a1", "credit",
                        last_statement_balance=0,
                        current_balance=5000,
                    )
                ],
            )
        )
        # Should use last_statement_balance=0 (not fall through to current_balance=5000)
        assert Decimal(result.metadata["total_liabilities"]) == Decimal("0")
