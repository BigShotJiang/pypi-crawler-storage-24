"""Assertion runner — orchestrates adapter → context → assertions → results."""

from __future__ import annotations

from typing import Callable

from finlint_audit.adapters.base import DataAdapter
from finlint_audit.assertions.balance_drift import assert_balance_drift
from finlint_audit.assertions.net_worth import assert_net_worth
from finlint_audit.assertions.overlap import assert_overlap_detection
from finlint_audit.assertions.sign_correctness import assert_sign_correctness
from finlint_audit.assertions.snapshot import assert_snapshot_consistency
from finlint_audit.assertions.txn_duplicate import assert_txn_duplicate
from finlint_audit.assertions.txn_orphan import assert_txn_orphan
from finlint_audit.assertions.txn_pending_staleness import assert_txn_pending_staleness
from finlint_audit.result import AssertionContext, AssertionResult

# Ordered list of built-in assertions
BUILTIN_ASSERTIONS: list[tuple[str, Callable[[AssertionContext], AssertionResult]]] = [
    ("nw-001", assert_net_worth),
    ("sign-001", assert_sign_correctness),
    ("overlap-001", assert_overlap_detection),
    ("snap-001", assert_snapshot_consistency),
    ("drift-001", assert_balance_drift),
    ("txn-001", assert_txn_duplicate),
    ("txn-002", assert_txn_orphan),
    ("txn-003", assert_txn_pending_staleness),
]


class AuditRunner:
    def __init__(
        self,
        adapter: DataAdapter,
        disabled: set[str] | None = None,
        only: set[str] | None = None,
        params: dict[str, dict] | None = None,
    ) -> None:
        self.adapter = adapter
        self.disabled = disabled or set()
        self.only = only
        self.params = params or {}

    def run(self) -> list[AssertionResult]:
        # Load all data once
        ctx_base = AssertionContext(
            accounts=self.adapter.load_accounts(),
            holdings=self.adapter.load_holdings(),
            liabilities=self.adapter.load_liabilities(),
            snapshots=self.adapter.load_snapshots(),
            transactions=self.adapter.load_transactions(),
        )

        results: list[AssertionResult] = []
        for assertion_id, fn in BUILTIN_ASSERTIONS:
            if assertion_id in self.disabled:
                continue
            if self.only and assertion_id not in self.only:
                continue

            # Build context with assertion-specific params
            ctx = AssertionContext(
                accounts=ctx_base.accounts,
                holdings=ctx_base.holdings,
                liabilities=ctx_base.liabilities,
                snapshots=ctx_base.snapshots,
                transactions=ctx_base.transactions,
                params=self.params.get(assertion_id, {}),
            )
            try:
                results.append(fn(ctx))
            except Exception as exc:
                results.append(AssertionResult(
                    assertion_id=assertion_id,
                    name=assertion_id,
                    status="fail",
                    message=f"Assertion raised an error: {exc}",
                    evidence=[],
                    metadata={"error": str(exc)},
                ))

        return results
