"""YAML config parser with env var expansion."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any

import yaml


@dataclass
class DatabaseConfig:
    type: str
    connection: str


@dataclass
class MappingConfig:
    table: str
    columns: dict[str, str]
    filter: str | None = None
    joins: list[dict[str, str]] = field(default_factory=list)


@dataclass
class AssertionConfig:
    enabled: bool = True
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class AuditConfig:
    database: DatabaseConfig
    mapping: dict[str, MappingConfig]
    assertions: dict[str, AssertionConfig]
    output_format: str = "text"


_ENV_PATTERN = re.compile(r"\$\{(\w+)\}")


def _expand_env(value: str) -> str:
    """Expand ${VAR} references in a string."""

    def _replace(m: re.Match) -> str:
        name = m.group(1)
        val = os.environ.get(name)
        if val is None:
            raise ValueError(
                f"Environment variable '{name}' is not set"
            )
        return val

    return _ENV_PATTERN.sub(_replace, value)


def parse_config(yaml_str: str) -> AuditConfig:
    """Parse YAML config string into AuditConfig."""
    try:
        raw = yaml.safe_load(yaml_str)
    except yaml.YAMLError as e:
        raise ValueError(f"Parse error in YAML config: {e}") from e

    if not isinstance(raw, dict):
        raise ValueError("Parse error: YAML root must be a mapping")

    # Version check
    version = raw.get("version")
    if version is not None and str(version) != "1":
        raise ValueError(
            f"Unsupported config version '{version}'. Only version '1' is supported."
        )

    # Database
    db_raw = raw.get("database", {})
    connection = _expand_env(str(db_raw.get("connection", "")))
    database = DatabaseConfig(
        type=str(db_raw.get("type", "sqlite")),
        connection=connection,
    )

    # Mappings
    mapping_raw = raw.get("mapping", {})
    if "accounts" not in mapping_raw:
        raise ValueError("Config must include 'mapping.accounts'")

    mapping: dict[str, MappingConfig] = {}
    for name, m in mapping_raw.items():
        mapping[name] = MappingConfig(
            table=m.get("table", name),
            columns=m.get("columns", {}),
            filter=m.get("filter"),
            joins=m.get("joins", []),
        )

    # Assertions
    assertions_raw = raw.get("assertions", {})
    assertions: dict[str, AssertionConfig] = {}
    for name, a in assertions_raw.items():
        if a is None:
            a = {}
        assertions[name] = AssertionConfig(
            enabled=a.get("enabled", True),
            params=a.get("params", {}),
        )

    # Output
    output_raw = raw.get("output", {})
    output_format = output_raw.get("format", "text") if output_raw else "text"

    return AuditConfig(
        database=database,
        mapping=mapping,
        assertions=assertions,
        output_format=output_format,
    )
