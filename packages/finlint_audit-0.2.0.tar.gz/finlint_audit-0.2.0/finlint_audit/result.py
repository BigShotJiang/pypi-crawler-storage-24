"""Assertion result and context models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal

from finlint_audit.models import (
    Account,
    Evidence,
    Holding,
    Liability,
    Snapshot,
    Transaction,
)


@dataclass
class AssertionResult:
    assertion_id: str
    name: str
    status: Literal["pass", "warn", "fail", "skip"]
    message: str
    evidence: list[Evidence]
    metadata: dict


@dataclass
class AssertionContext:
    accounts: list[Account]
    holdings: list[Holding]
    liabilities: list[Liability]
    snapshots: list[Snapshot]
    transactions: list[Transaction]
    params: dict = field(default_factory=dict)
    now: datetime | None = None
