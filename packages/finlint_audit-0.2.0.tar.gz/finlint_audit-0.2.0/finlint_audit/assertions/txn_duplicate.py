"""Duplicate Transaction Detection assertion (txn-001).

Groups transactions by configurable match fields and flags groups with >1 member.
Catches sync retries that insert the same transaction twice with different UUIDs.
"""

from __future__ import annotations

from collections import defaultdict

from finlint_audit.models import Evidence, Transaction
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_MATCH_FIELDS = "account_id,amount,date,name"
_VALID_FIELDS = frozenset(Transaction.__dataclass_fields__.keys()) - {"id", "pending"}


def assert_txn_duplicate(ctx: AssertionContext) -> AssertionResult:
    raw_fields = ctx.params.get("match_fields", _DEFAULT_MATCH_FIELDS)
    if not raw_fields or not raw_fields.strip():
        return AssertionResult(
            assertion_id="txn-001",
            name="Duplicate Detection",
            status="skip",
            message="No match_fields configured — skipping",
            evidence=[],
            metadata={},
        )

    match_fields = [f.strip() for f in raw_fields.split(",") if f.strip()]

    # Validate fields
    invalid = [f for f in match_fields if f not in _VALID_FIELDS]
    if invalid:
        return AssertionResult(
            assertion_id="txn-001",
            name="Duplicate Detection",
            status="skip",
            message=f"Invalid match field(s): {', '.join(invalid)}",
            evidence=[],
            metadata={},
        )

    if not ctx.transactions:
        return AssertionResult(
            assertion_id="txn-001",
            name="Duplicate Detection",
            status="pass",
            message="No transactions to check",
            evidence=[],
            metadata={"duplicate_group_count": "0", "total_duplicates": "0"},
        )

    # Group by match key
    groups: dict[tuple, list[Transaction]] = defaultdict(list)
    for txn in ctx.transactions:
        key = tuple(getattr(txn, f) for f in match_fields)
        groups[key].append(txn)

    # Find duplicates
    evidence: list[Evidence] = []
    total_duplicates = 0
    for key, txns in groups.items():
        if len(txns) > 1:
            total_duplicates += len(txns)
            key_desc = ", ".join(
                f"{f}={getattr(txns[0], f)}" for f in match_fields
            )
            evidence.append(
                Evidence(
                    field=f"account_id={txns[0].account_id}",
                    expected=f"unique by ({', '.join(match_fields)})",
                    actual=f"{len(txns)} duplicates: {key_desc}",
                )
            )

    duplicate_group_count = len(evidence)

    if evidence:
        return AssertionResult(
            assertion_id="txn-001",
            name="Duplicate Detection",
            status="fail",
            message=f"{duplicate_group_count} duplicate group(s) found ({total_duplicates} transactions)",
            evidence=evidence,
            metadata={
                "duplicate_group_count": str(duplicate_group_count),
                "total_duplicates": str(total_duplicates),
            },
        )

    return AssertionResult(
        assertion_id="txn-001",
        name="Duplicate Detection",
        status="pass",
        message=f"All {len(ctx.transactions)} transaction(s) are unique",
        evidence=[],
        metadata={"duplicate_group_count": "0", "total_duplicates": "0"},
    )
