"""Overlap Detection assertion (overlap-001).

Detects duplicate accounts across users in a household by fingerprinting
on (institution, type, subtype, mask).

Confidence tiers:
- 95%: Both masks non-null and match
- 70%: One or both masks null/empty (can't confirm or deny)
- Skip: Masks differ (not a duplicate)
"""

from __future__ import annotations

from collections import defaultdict
from itertools import combinations

from finlint_audit.models import Account, Evidence
from finlint_audit.result import AssertionContext, AssertionResult


def _normalize_mask(mask: str | None) -> str | None:
    """Normalize mask: strip whitespace, treat empty as None."""
    if mask is None:
        return None
    mask = mask.strip()
    return mask if mask else None


def _fingerprint(a: Account) -> tuple[str, str, str]:
    """(institution, type, subtype) fingerprint for grouping."""
    institution = a.institution_id or a.institution_name or ""
    subtype = (a.subtype or "").lower()
    return (institution.lower(), a.type.value.lower(), subtype)


def assert_overlap_detection(ctx: AssertionContext) -> AssertionResult:
    # Only active accounts with user_id
    active = [a for a in ctx.accounts if a.is_active and a.user_id]

    # Group by fingerprint
    groups: dict[tuple, list[Account]] = defaultdict(list)
    for a in active:
        groups[_fingerprint(a)].append(a)

    evidence: list[Evidence] = []

    for fp, accounts in groups.items():
        if len(accounts) < 2:
            continue

        # Check all cross-user pairs
        for a1, a2 in combinations(accounts, 2):
            if a1.user_id == a2.user_id:
                continue

            # Skip if either is excluded from net worth (already resolved)
            if a1.exclude_from_net_worth or a2.exclude_from_net_worth:
                continue

            mask1 = _normalize_mask(a1.mask)
            mask2 = _normalize_mask(a2.mask)

            if mask1 is not None and mask2 is not None:
                if mask1 == mask2:
                    confidence = "95%"
                else:
                    continue  # Masks differ = not a duplicate
            else:
                confidence = "70%"

            evidence.append(
                Evidence(
                    field=f"accounts ({a1.id}, {a2.id})",
                    expected="unique accounts across users",
                    actual=f"potential duplicate (confidence: {confidence})",
                )
            )

    if evidence:
        return AssertionResult(
            assertion_id="overlap-001",
            name="Overlap Detection",
            status="fail",
            message=f"{len(evidence)} potential duplicate(s) found",
            evidence=evidence,
            metadata={"overlap_count": len(evidence)},
        )

    return AssertionResult(
        assertion_id="overlap-001",
        name="Overlap Detection",
        status="pass",
        message="No duplicate accounts detected",
        evidence=[],
        metadata={"overlap_count": 0},
    )
