"""Orphan Transaction Detection assertion (txn-002).

Every transaction's account_id must exist in ctx.accounts. Orphans indicate
broken FKs or deleted accounts without cascade.

Important: If the config filters accounts by `is_active = true`, transactions
for inactive accounts will appear orphaned. Document this as a known limitation.
"""

from __future__ import annotations

from collections import defaultdict

from finlint_audit.models import Evidence
from finlint_audit.result import AssertionContext, AssertionResult


def assert_txn_orphan(ctx: AssertionContext) -> AssertionResult:
    if not ctx.transactions:
        return AssertionResult(
            assertion_id="txn-002",
            name="Orphan Transactions",
            status="pass",
            message="No transactions to check",
            evidence=[],
            metadata={"orphan_count": "0", "orphan_account_ids": ""},
        )

    if not ctx.accounts:
        return AssertionResult(
            assertion_id="txn-002",
            name="Orphan Transactions",
            status="warn",
            message="No accounts loaded — cannot verify transaction references",
            evidence=[],
            metadata={"orphan_count": "0", "orphan_account_ids": ""},
        )

    account_ids = {a.id for a in ctx.accounts}

    # Group orphan transactions by missing account_id
    orphans_by_account: dict[str, int] = defaultdict(int)
    for txn in ctx.transactions:
        if txn.account_id not in account_ids:
            orphans_by_account[txn.account_id] += 1

    if not orphans_by_account:
        return AssertionResult(
            assertion_id="txn-002",
            name="Orphan Transactions",
            status="pass",
            message=f"All {len(ctx.transactions)} transaction(s) reference valid accounts",
            evidence=[],
            metadata={"orphan_count": "0", "orphan_account_ids": ""},
        )

    total_orphans = sum(orphans_by_account.values())
    evidence = [
        Evidence(
            field=f"account_id={acct_id}",
            expected="account exists in accounts table",
            actual=f"{count} transaction(s) reference missing account",
        )
        for acct_id, count in sorted(orphans_by_account.items())
    ]

    orphan_account_list = ",".join(sorted(orphans_by_account.keys()))

    return AssertionResult(
        assertion_id="txn-002",
        name="Orphan Transactions",
        status="fail",
        message=f"{total_orphans} transaction(s) reference {len(orphans_by_account)} missing account(s)",
        evidence=evidence,
        metadata={
            "orphan_count": str(total_orphans),
            "orphan_account_ids": orphan_account_list,
        },
    )
