"""Sign Correctness assertion (sign-001).

Verifies:
- Liability accounts (credit, loan) have non-negative balances.
- Asset accounts (depository, investment, other) with negative balances get a warning.
"""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.models import AccountType, Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_ZERO = Decimal("0")
_LIABILITY_TYPES = {AccountType.CREDIT, AccountType.LOAN}


def assert_sign_correctness(ctx: AssertionContext) -> AssertionResult:
    active = [a for a in ctx.accounts if a.is_active]

    fails: list[Evidence] = []
    warns: list[Evidence] = []

    for a in active:
        if a.balance_current < _ZERO:
            if a.type in _LIABILITY_TYPES:
                fails.append(
                    Evidence(
                        field=f"account.id={a.id}",
                        expected=f"{a.type.value} balance >= 0",
                        actual=f"balance = {a.balance_current}",
                    )
                )
            else:
                warns.append(
                    Evidence(
                        field=f"account.id={a.id}",
                        expected=f"{a.type.value} balance >= 0",
                        actual=f"balance = {a.balance_current}",
                    )
                )

    if fails:
        return AssertionResult(
            assertion_id="sign-001",
            name="Sign Correctness",
            status="fail",
            message=f"{len(fails)} liability account(s) have negative balance",
            evidence=fails + warns,
            metadata={"fail_count": len(fails), "warn_count": len(warns)},
        )

    if warns:
        return AssertionResult(
            assertion_id="sign-001",
            name="Sign Correctness",
            status="warn",
            message=f"{len(warns)} asset account(s) have negative balance (overdraft?)",
            evidence=warns,
            metadata={"fail_count": 0, "warn_count": len(warns)},
        )

    return AssertionResult(
        assertion_id="sign-001",
        name="Sign Correctness",
        status="pass",
        message=f"All {len(active)} account(s) have correct sign",
        evidence=[],
        metadata={"fail_count": 0, "warn_count": 0},
    )
