"""Pending Transaction Staleness assertion (txn-003).

Flags pending transactions older than stale_days. In Plaid's model, pending
transactions should settle within days. A multi-week-old pending transaction
is stale data that distorts reports.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from finlint_audit.models import Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_STALE_DAYS = 14


def assert_txn_pending_staleness(ctx: AssertionContext) -> AssertionResult:
    try:
        stale_days = int(ctx.params.get("stale_days", _DEFAULT_STALE_DAYS))
    except (ValueError, TypeError):
        return AssertionResult(
            assertion_id="txn-003",
            name="Pending Staleness",
            status="skip",
            message="Invalid stale_days param — must be integer",
            evidence=[],
            metadata={},
        )

    pending = [t for t in ctx.transactions if t.pending]

    if not pending:
        return AssertionResult(
            assertion_id="txn-003",
            name="Pending Staleness",
            status="pass",
            message="No pending transactions to check",
            evidence=[],
            metadata={"stale_pending_count": "0"},
        )

    # Determine "today" for age calculation
    if ctx.now is not None:
        today = ctx.now.date() if isinstance(ctx.now, datetime) else ctx.now
    else:
        today = date.today()

    evidence: list[Evidence] = []
    for txn in pending:
        age_days = (today - txn.date).days
        if age_days > stale_days:
            evidence.append(
                Evidence(
                    field=f"transaction.id={txn.id} date={txn.date.isoformat()}",
                    expected=f"pending <= {stale_days} days",
                    actual=f"pending for {age_days} days (account_id={txn.account_id})",
                )
            )

    if evidence:
        return AssertionResult(
            assertion_id="txn-003",
            name="Pending Staleness",
            status="warn",
            message=f"{len(evidence)} pending transaction(s) older than {stale_days} days",
            evidence=evidence,
            metadata={"stale_pending_count": str(len(evidence))},
        )

    return AssertionResult(
        assertion_id="txn-003",
        name="Pending Staleness",
        status="pass",
        message=f"All {len(pending)} pending transaction(s) within {stale_days}-day window",
        evidence=[],
        metadata={"stale_pending_count": "0"},
    )
