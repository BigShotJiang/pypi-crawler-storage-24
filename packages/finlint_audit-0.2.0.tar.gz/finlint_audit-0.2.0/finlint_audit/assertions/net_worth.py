"""Net Worth Equation assertion (nw-001).

Verifies: assets + investments - liabilities = net_worth within tolerance.

Algorithm mirrors Kanso's get_portfolio_summary():
- Depository + other → total_assets
- Investment accounts → skip (captured via holdings)
- Credit + loan → total_liabilities (account-based)
- Liability table records provide alternative totals (max wins)
- Holdings → total_investments (only for investment accounts)
"""

from __future__ import annotations

from decimal import Decimal

from finlint_audit.models import AccountType, Evidence
from finlint_audit.result import AssertionContext, AssertionResult

_ZERO = Decimal("0")
_DEFAULT_TOLERANCE = Decimal("0.01")


def assert_net_worth(ctx: AssertionContext) -> AssertionResult:
    tolerance = Decimal(ctx.params.get("tolerance", str(_DEFAULT_TOLERANCE)))

    # Collect active, non-excluded accounts
    active = [
        a
        for a in ctx.accounts
        if a.is_active and not a.exclude_from_net_worth
    ]

    # Build set of investment account IDs (for filtering holdings)
    investment_account_ids = {
        a.id for a in active if a.type == AccountType.INVESTMENT
    }

    # ── Assets (depository + other) ──
    total_assets = _ZERO
    for a in active:
        if a.type in (AccountType.DEPOSITORY, AccountType.OTHER):
            total_assets += a.balance_current

    # ── Liabilities (account-based) ──
    total_liabilities_from_accounts = _ZERO
    for a in active:
        if a.type in (AccountType.CREDIT, AccountType.LOAN):
            total_liabilities_from_accounts += a.balance_current

    # ── Liabilities (from liability table) ──
    total_liabilities_from_table = _ZERO
    for li in ctx.liabilities:
        if li.last_statement_balance is not None:
            value = li.last_statement_balance
        elif li.current_balance is not None:
            value = li.current_balance
        elif li.origination_principal is not None:
            value = li.origination_principal
        else:
            value = _ZERO
        total_liabilities_from_table += value

    # Take max of the two liability totals (Kanso pattern)
    total_liabilities = max(
        total_liabilities_from_accounts, total_liabilities_from_table
    )

    # ── Investments (holdings for investment accounts only) ──
    total_investments = _ZERO
    for h in ctx.holdings:
        if h.account_id in investment_account_ids:
            total_investments += h.institution_value

    # ── Net worth equation ──
    net_worth = total_assets + total_investments - total_liabilities

    metadata = {
        "total_assets": str(total_assets),
        "total_investments": str(total_investments),
        "total_liabilities": str(total_liabilities),
        "net_worth": str(net_worth),
        "account_count": len(active),
    }

    return AssertionResult(
        assertion_id="nw-001",
        name="Net Worth Equation",
        status="pass",
        message=(
            f"Net worth = ${net_worth:,.2f} "
            f"(assets ${total_assets:,.2f} "
            f"+ investments ${total_investments:,.2f} "
            f"- liabilities ${total_liabilities:,.2f})"
        ),
        evidence=[],
        metadata=metadata,
    )
