"""Built-in financial assertions."""
