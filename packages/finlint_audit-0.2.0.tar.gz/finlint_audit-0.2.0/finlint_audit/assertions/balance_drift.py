"""Balance Drift assertion (drift-001).

Checks that latest snapshot balance ≈ current account balance within tolerance.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal

from finlint_audit.models import Evidence, Snapshot
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_TOLERANCE = Decimal("1.00")
_DEFAULT_STALE_DAYS = 7


def assert_balance_drift(ctx: AssertionContext) -> AssertionResult:
    tolerance = Decimal(ctx.params.get("tolerance", str(_DEFAULT_TOLERANCE)))
    stale_days = int(ctx.params.get("stale_days", _DEFAULT_STALE_DAYS))

    active = [a for a in ctx.accounts if a.is_active]

    if not active:
        return AssertionResult(
            assertion_id="drift-001",
            name="Balance Drift",
            status="pass",
            message="No active accounts to check",
            evidence=[],
            metadata={},
        )

    # Group snapshots by account, pick latest
    latest_by_account: dict[str, Snapshot] = {}
    for s in ctx.snapshots:
        if (
            s.account_id not in latest_by_account
            or s.captured_at > latest_by_account[s.account_id].captured_at
        ):
            latest_by_account[s.account_id] = s

    fails: list[Evidence] = []
    warns: list[Evidence] = []
    # Use injected time if available, otherwise detect timezone awareness
    if ctx.now is not None:
        now = ctx.now
    else:
        has_tz = any(
            s.captured_at.tzinfo is not None
            for s in ctx.snapshots
        )
        now = datetime.now(tz=timezone.utc) if has_tz else datetime.now()

    for a in active:
        snap = latest_by_account.get(a.id)
        if snap is None:
            warns.append(
                Evidence(
                    field=f"account.id={a.id}",
                    expected="snapshot exists",
                    actual="no snapshots found",
                )
            )
            continue

        # Check staleness
        age = (now - snap.captured_at).days
        if age > stale_days:
            warns.append(
                Evidence(
                    field=f"account.id={a.id}",
                    expected=f"snapshot within {stale_days} days",
                    actual=f"snapshot is {age} days old",
                )
            )
            continue

        # Check drift
        drift = abs(a.balance_current - snap.balance)
        if drift > tolerance:
            fails.append(
                Evidence(
                    field=f"account.id={a.id}",
                    expected=f"drift <= ${tolerance}",
                    actual=f"drift = ${drift} (account={a.balance_current}, snapshot={snap.balance})",
                )
            )

    if fails:
        return AssertionResult(
            assertion_id="drift-001",
            name="Balance Drift",
            status="fail",
            message=f"{len(fails)} account(s) exceed drift tolerance",
            evidence=fails + warns,
            metadata={"fail_count": len(fails), "warn_count": len(warns)},
        )

    if warns:
        return AssertionResult(
            assertion_id="drift-001",
            name="Balance Drift",
            status="warn",
            message=f"{len(warns)} account(s) have stale or missing snapshots",
            evidence=warns,
            metadata={"fail_count": 0, "warn_count": len(warns)},
        )

    return AssertionResult(
        assertion_id="drift-001",
        name="Balance Drift",
        status="pass",
        message=f"All {len(active)} balance(s) within ${tolerance} of latest snapshot",
        evidence=[],
        metadata={"fail_count": 0, "warn_count": 0},
    )
