"""Snapshot Consistency assertion (snap-001).

Checks:
- At most 1 snapshot per account per day (dedup)
- No gaps > max_gap_days between consecutive snapshots per account
"""

from __future__ import annotations

from collections import defaultdict

from finlint_audit.models import Evidence, Snapshot
from finlint_audit.result import AssertionContext, AssertionResult

_DEFAULT_MAX_GAP_DAYS = 7


def assert_snapshot_consistency(ctx: AssertionContext) -> AssertionResult:
    max_gap_days = int(ctx.params.get("max_gap_days", _DEFAULT_MAX_GAP_DAYS))

    if not ctx.snapshots:
        return AssertionResult(
            assertion_id="snap-001",
            name="Snapshot Consistency",
            status="pass",
            message="No snapshot data to check",
            evidence=[],
            metadata={},
        )

    # Group snapshots by account
    by_account: dict[str, list[Snapshot]] = defaultdict(list)
    for s in ctx.snapshots:
        by_account[s.account_id].append(s)

    evidence: list[Evidence] = []

    for account_id, snaps in by_account.items():
        # Sort by captured_at
        snaps.sort(key=lambda s: s.captured_at)

        # Check for duplicates on same day
        seen_dates: dict[str, int] = {}
        for s in snaps:
            day = s.captured_at.strftime("%Y-%m-%d")
            seen_dates[day] = seen_dates.get(day, 0) + 1

        for day, count in seen_dates.items():
            if count > 1:
                evidence.append(
                    Evidence(
                        field=f"account_id={account_id}",
                        expected=f"at most 1 snapshot per day",
                        actual=f"{count} snapshots on {day}",
                    )
                )

        # Check for gaps
        if len(snaps) >= 2:
            for i in range(1, len(snaps)):
                gap = (snaps[i].captured_at - snaps[i - 1].captured_at).days
                if gap > max_gap_days:
                    d1 = snaps[i - 1].captured_at.strftime("%Y-%m-%d")
                    d2 = snaps[i].captured_at.strftime("%Y-%m-%d")
                    evidence.append(
                        Evidence(
                            field=f"account_id={account_id}",
                            expected=f"gap <= {max_gap_days} days",
                            actual=f"gap of {gap} days ({d1} to {d2})",
                        )
                    )

    if evidence:
        return AssertionResult(
            assertion_id="snap-001",
            name="Snapshot Consistency",
            status="fail",
            message=f"{len(evidence)} snapshot issue(s) found",
            evidence=evidence,
            metadata={"issue_count": len(evidence)},
        )

    return AssertionResult(
        assertion_id="snap-001",
        name="Snapshot Consistency",
        status="pass",
        message=f"All snapshots consistent across {len(by_account)} account(s)",
        evidence=[],
        metadata={"account_count": len(by_account)},
    )
