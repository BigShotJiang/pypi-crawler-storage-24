"""SQL data adapter — generates queries from config, maps rows to models.

Trust boundary: The YAML config file is operator-authored (same privilege
level as database credentials). Table/column names are validated against
an allowlist pattern to prevent accidental injection. The ``filter`` and
``joins[].on`` fields are SQL fragments and must be treated as trusted input.
"""

from __future__ import annotations

import re
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any

from finlint_audit.adapters.base import DataAdapter
from finlint_audit.config import AuditConfig, MappingConfig
from finlint_audit.models import (
    Account,
    AccountType,
    Holding,
    Liability,
    Snapshot,
    Transaction,
)

_IDENTIFIER_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_.]*$")


def _validate_identifier(name: str, context: str) -> None:
    """Validate a SQL identifier (table or column name)."""
    if not _IDENTIFIER_RE.match(name):
        raise ValueError(
            f"Invalid SQL identifier in {context}: {name!r}. "
            "Only alphanumeric characters, underscores, and dots are allowed."
        )


def generate_select(mapping: MappingConfig) -> str:
    """Generate a SELECT statement from mapping config."""
    _validate_identifier(mapping.table, "table name")

    # Build column list with aliases
    cols = []
    for model_field, db_col in mapping.columns.items():
        _validate_identifier(model_field, "column alias")
        _validate_identifier(db_col, "column name")
        if db_col == model_field:
            cols.append(db_col)
        else:
            cols.append(f"{db_col} AS {model_field}")

    sql = f"SELECT {', '.join(cols)} FROM {mapping.table}"

    # Add JOINs (on clause is a trusted SQL fragment from config)
    for join in mapping.joins:
        _validate_identifier(join["table"], "join table name")
        sql += f" JOIN {join['table']} ON {join['on']}"

    # Add WHERE (filter is a trusted SQL fragment from config)
    if mapping.filter:
        sql += f" WHERE {mapping.filter}"

    return sql


def _to_decimal(value: Any) -> Decimal:
    """Convert value to Decimal safely."""
    if value is None:
        return Decimal("0")
    if isinstance(value, Decimal):
        return value
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError):
        return Decimal("0")


def _to_decimal_or_none(value: Any) -> Decimal | None:
    if value is None:
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError):
        return None


class SqlAdapter:
    """SQL adapter that loads data using SQLAlchemy (or generates dry-run SQL)."""

    def __init__(self, config: AuditConfig, engine: Any = None) -> None:
        self.config = config
        self.engine = engine

    def get_queries(self) -> dict[str, str]:
        """Return generated SQL queries (for dry-run mode)."""
        queries = {}
        for name, mapping in self.config.mapping.items():
            queries[name] = generate_select(mapping)
        return queries

    @staticmethod
    def _row_to_account(row: dict) -> Account:
        # Normalize type to AccountType enum
        raw_type = str(row.get("type", "other")).lower()
        try:
            acct_type = AccountType(raw_type)
        except ValueError:
            acct_type = AccountType.OTHER

        return Account(
            id=str(row["id"]),
            type=acct_type,
            balance_current=_to_decimal(row.get("balance_current")),
            name=str(row.get("name") or ""),
            mask=row.get("mask"),
            institution_id=row.get("institution_id"),
            institution_name=row.get("institution_name"),
            subtype=row.get("subtype"),
            currency=str(row.get("currency") or "USD"),
            is_active=bool(row.get("is_active", True)),
            exclude_from_net_worth=bool(row.get("exclude_from_net_worth", False)),
            user_id=row.get("user_id"),
        )

    @staticmethod
    def _row_to_holding(row: dict) -> Holding:
        return Holding(
            id=str(row["id"]),
            account_id=str(row["account_id"]),
            institution_value=_to_decimal(row.get("institution_value")),
            ticker=row.get("ticker"),
            quantity=_to_decimal(row.get("quantity", "0")),
            cost_basis=_to_decimal_or_none(row.get("cost_basis")),
        )

    @staticmethod
    def _row_to_liability(row: dict) -> Liability:
        return Liability(
            id=str(row["id"]),
            account_id=str(row["account_id"]),
            type=str(row.get("type", "")),
            last_statement_balance=_to_decimal_or_none(row.get("last_statement_balance")),
            current_balance=_to_decimal_or_none(row.get("current_balance")),
            origination_principal=_to_decimal_or_none(row.get("origination_principal")),
        )

    @staticmethod
    def _row_to_snapshot(row: dict) -> Snapshot:
        captured_at = row.get("captured_at")
        if isinstance(captured_at, str):
            # Python 3.9/3.10 fromisoformat doesn't handle "Z" suffix
            if captured_at.endswith("Z"):
                captured_at = captured_at[:-1] + "+00:00"
            captured_at = datetime.fromisoformat(captured_at)
        return Snapshot(
            id=str(row["id"]),
            account_id=str(row["account_id"]),
            balance=_to_decimal(row.get("balance")),
            captured_at=captured_at,
            source=row.get("source"),
        )

    @staticmethod
    def _row_to_transaction(row: dict) -> Transaction:
        from datetime import date as date_type

        d = row.get("date")
        if isinstance(d, str):
            d = date_type.fromisoformat(d)
        return Transaction(
            id=str(row["id"]),
            account_id=str(row["account_id"]),
            amount=_to_decimal(row.get("amount")),
            date=d,
            pending=bool(row.get("pending", False)),
            name=str(row.get("name") or ""),
        )

    def _execute_query(self, table_name: str) -> list[dict]:
        """Execute a query and return rows as dicts."""
        if self.engine is None:
            return []
        mapping = self.config.mapping.get(table_name)
        if not mapping:
            return []

        sql = generate_select(mapping)

        try:
            from sqlalchemy import text

            with self.engine.connect() as conn:
                result = conn.execute(text(sql))
                return [dict(row._mapping) for row in result]
        except ImportError:
            return []

    def load_accounts(self) -> list[Account]:
        return [self._row_to_account(r) for r in self._execute_query("accounts")]

    def load_holdings(self) -> list[Holding]:
        return [self._row_to_holding(r) for r in self._execute_query("holdings")]

    def load_liabilities(self) -> list[Liability]:
        return [self._row_to_liability(r) for r in self._execute_query("liabilities")]

    def load_snapshots(self) -> list[Snapshot]:
        return [self._row_to_snapshot(r) for r in self._execute_query("snapshots")]

    def load_transactions(self) -> list[Transaction]:
        return [self._row_to_transaction(r) for r in self._execute_query("transactions")]
