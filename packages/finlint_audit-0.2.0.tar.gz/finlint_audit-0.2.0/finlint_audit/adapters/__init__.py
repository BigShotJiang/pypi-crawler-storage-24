"""Data adapters for loading financial data."""
