"""In-memory data adapter for testing."""

from __future__ import annotations

from dataclasses import dataclass, field

from finlint_audit.models import Account, Holding, Liability, Snapshot, Transaction


@dataclass
class MemoryAdapter:
    accounts: list[Account] = field(default_factory=list)
    holdings: list[Holding] = field(default_factory=list)
    liabilities: list[Liability] = field(default_factory=list)
    snapshots: list[Snapshot] = field(default_factory=list)
    transactions: list[Transaction] = field(default_factory=list)

    def load_accounts(self) -> list[Account]:
        return self.accounts

    def load_holdings(self) -> list[Holding]:
        return self.holdings

    def load_liabilities(self) -> list[Liability]:
        return self.liabilities

    def load_snapshots(self) -> list[Snapshot]:
        return self.snapshots

    def load_transactions(self) -> list[Transaction]:
        return self.transactions
