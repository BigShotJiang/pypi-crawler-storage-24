"""CLI for finlint-audit: `finlint-audit` command."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from finlint_audit.result import AssertionResult


def format_results(results: list[AssertionResult]) -> str:
    """Format results as human-readable text."""
    lines = []
    for r in results:
        icon = "✓" if r.status == "pass" else "⚠" if r.status == "warn" else "✗"
        lines.append(f"{icon} {r.assertion_id:<24} {r.message}")
        for e in r.evidence:
            lines.append(f"    {e.field}: expected {e.expected}, got {e.actual}")

    passed = sum(1 for r in results if r.status == "pass")
    failed = sum(1 for r in results if r.status == "fail")
    warned = sum(1 for r in results if r.status == "warn")

    lines.append("")
    parts = [f"{passed} passed"]
    if failed:
        parts.append(f"{failed} failed")
    if warned:
        parts.append(f"{warned} warnings")
    lines.append(f"Results: {', '.join(parts)}")

    return "\n".join(lines)


def format_results_json(results: list[AssertionResult]) -> str:
    """Format results as JSON."""
    data = {
        "results": [
            {
                "assertion_id": r.assertion_id,
                "name": r.name,
                "status": r.status,
                "message": r.message,
                "evidence": [
                    {"field": e.field, "expected": e.expected, "actual": e.actual}
                    for e in r.evidence
                ],
                "metadata": r.metadata,
            }
            for r in results
        ],
        "summary": {
            "passed": sum(1 for r in results if r.status == "pass"),
            "failed": sum(1 for r in results if r.status == "fail"),
            "warned": sum(1 for r in results if r.status == "warn"),
            "total": len(results),
        },
    }
    return json.dumps(data, indent=2)


def format_results_github(results: list[AssertionResult]) -> str:
    """Format results as GitHub Actions annotations."""
    lines = []
    for r in results:
        if r.status == "fail":
            lines.append(f"::error title={r.assertion_id}::{r.message}")
            for e in r.evidence:
                lines.append(f"::error::{e.field}: {e.actual}")
        elif r.status == "warn":
            lines.append(f"::warning title={r.assertion_id}::{r.message}")
    return "\n".join(lines)


def compute_exit_code(results: list[AssertionResult]) -> int:
    """Return 1 if any assertion failed, 0 otherwise."""
    return 1 if any(r.status == "fail" for r in results) else 0


def main(args: list[str] | None = None) -> None:
    """CLI entry point."""
    try:
        import click
    except ImportError:
        print("finlint-audit CLI requires 'click'. Install with: pip install finlint-audit[cli]")
        sys.exit(1)

    @click.command()
    @click.option("--config", "-c", required=True, type=click.Path(exists=True), help="Path to finlint.yaml")
    @click.option("--format", "fmt", default="text", type=click.Choice(["text", "json", "github-actions"]))
    @click.option("--dry-run", is_flag=True, help="Show SQL queries without executing")
    @click.option("--only", help="Comma-separated list of assertion IDs to run")
    def cli(config: str, fmt: str, dry_run: bool, only: str | None) -> None:
        from finlint_audit.config import parse_config
        from finlint_audit.adapters.sql import SqlAdapter

        config_path = Path(config)
        cfg = parse_config(config_path.read_text())

        if dry_run:
            adapter = SqlAdapter(cfg)
            for name, sql in adapter.get_queries().items():
                click.echo(f"-- {name}")
                click.echo(sql)
                click.echo()
            return

        # Create engine
        try:
            from sqlalchemy import create_engine
        except ImportError:
            click.echo("SQL adapter requires 'sqlalchemy'. Install with: pip install finlint-audit[sql]")
            sys.exit(1)

        try:
            engine = create_engine(cfg.database.connection)
        except Exception:
            click.echo("Failed to connect to database. Check your connection string in the config file.")
            sys.exit(1)

        adapter = SqlAdapter(cfg, engine=engine)

        # Determine which assertions to run
        only_set = set(only.split(",")) if only else None
        disabled = set()
        for name, acfg in cfg.assertions.items():
            if not acfg.enabled:
                # Map config name to assertion ID
                disabled.add(_config_name_to_id(name))

        params = {}
        for name, acfg in cfg.assertions.items():
            if acfg.params:
                params[_config_name_to_id(name)] = acfg.params

        from finlint_audit.runner import AuditRunner

        runner = AuditRunner(
            adapter=adapter,
            disabled=disabled,
            only=only_set,
            params=params,
        )
        results = runner.run()

        formatters = {
            "text": format_results,
            "json": format_results_json,
            "github-actions": format_results_github,
        }
        click.echo(formatters[fmt](results))
        sys.exit(compute_exit_code(results))

    cli(args)


_NAME_TO_ID = {
    "net-worth-equation": "nw-001",
    "sign-correctness": "sign-001",
    "overlap-detection": "overlap-001",
    "snapshot-consistency": "snap-001",
    "balance-drift": "drift-001",
    "txn-duplicate-detection": "txn-001",
    "txn-orphan-detection": "txn-002",
    "txn-pending-staleness": "txn-003",
}


def _config_name_to_id(name: str) -> str:
    return _NAME_TO_ID.get(name, name)


if __name__ == "__main__":
    main()
