"""Pure data models for finlint-audit. No dependencies, no I/O."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from enum import Enum


class AccountType(str, Enum):
    DEPOSITORY = "depository"
    CREDIT = "credit"
    INVESTMENT = "investment"
    LOAN = "loan"
    OTHER = "other"


@dataclass
class Account:
    id: str
    type: AccountType
    balance_current: Decimal
    name: str = ""
    mask: str | None = None
    institution_id: str | None = None
    institution_name: str | None = None
    subtype: str | None = None
    currency: str = "USD"
    is_active: bool = True
    exclude_from_net_worth: bool = False
    user_id: str | None = None


@dataclass
class Holding:
    id: str
    account_id: str
    institution_value: Decimal
    ticker: str | None = None
    quantity: Decimal = field(default_factory=lambda: Decimal("0"))
    cost_basis: Decimal | None = None


@dataclass
class Liability:
    id: str
    account_id: str
    type: str
    last_statement_balance: Decimal | None = None
    current_balance: Decimal | None = None
    origination_principal: Decimal | None = None


@dataclass
class Snapshot:
    id: str
    account_id: str
    balance: Decimal
    captured_at: datetime
    source: str | None = None


@dataclass
class Transaction:
    id: str
    account_id: str
    amount: Decimal
    date: date
    pending: bool = False
    name: str = ""


@dataclass
class Evidence:
    field: str
    expected: str
    actual: str
