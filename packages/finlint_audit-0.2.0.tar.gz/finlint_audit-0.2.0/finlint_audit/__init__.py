"""FinLint Audit — Financial data integrity assertions engine."""

__version__ = "0.2.0"

from finlint_audit.adapters.memory import MemoryAdapter
from finlint_audit.assertions.balance_drift import assert_balance_drift
from finlint_audit.assertions.net_worth import assert_net_worth
from finlint_audit.assertions.overlap import assert_overlap_detection
from finlint_audit.assertions.sign_correctness import assert_sign_correctness
from finlint_audit.assertions.snapshot import assert_snapshot_consistency
from finlint_audit.assertions.txn_duplicate import assert_txn_duplicate
from finlint_audit.assertions.txn_orphan import assert_txn_orphan
from finlint_audit.assertions.txn_pending_staleness import assert_txn_pending_staleness
from finlint_audit.models import (
    Account,
    AccountType,
    Evidence,
    Holding,
    Liability,
    Snapshot,
    Transaction,
)
from finlint_audit.result import AssertionContext, AssertionResult
from finlint_audit.runner import AuditRunner

__all__ = [
    "Account",
    "AccountType",
    "AssertionContext",
    "AssertionResult",
    "AuditRunner",
    "Evidence",
    "Holding",
    "Liability",
    "MemoryAdapter",
    "Snapshot",
    "Transaction",
    "assert_balance_drift",
    "assert_net_worth",
    "assert_overlap_detection",
    "assert_sign_correctness",
    "assert_snapshot_consistency",
    "assert_txn_duplicate",
    "assert_txn_orphan",
    "assert_txn_pending_staleness",
]
