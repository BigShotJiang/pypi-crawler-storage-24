#!/usr/bin/env python3
"""
MPECSS: MacMPEC Benchmark Runner
=================================
Runs the 191 problems from the MacMPEC suite.
Supports parallel execution via --workers.

Usage (after pip install mpecss):
    mpecss-macmpec --workers 4

Usage (from project root, dev mode):
    python scripts/run_macmpec_benchmark.py --workers 4
"""
import os
import sys


def main():
    """
    CLI entry point for the MacMPEC benchmark runner.
    Registered in pyproject.toml as:
        mpecss-macmpec = "scripts.run_macmpec_benchmark:main"
    """
    try:
        from mpecss.helpers.loaders.macmpec_loader import load_macmpec
        from mpecss.helpers.benchmark_utils import run_benchmark_main
    except ImportError as e:
        print(f"[ERROR] Could not import mpecss: {e}")
        print("Make sure mpecss is installed: pip install mpecss")
        sys.exit(1)

    # Use current working directory as the base so the command works both:
    #   - After `pip install mpecss` (user runs from their project dir)
    #   - During local development (run from project root)
    default_path = os.path.join(os.getcwd(), "benchmarks", "macmpec", "macmpec-json")

    run_benchmark_main(
        loader_fn=load_macmpec,
        dataset_tag="macmpec",
        default_path=default_path,
    )


if __name__ == "__main__":
    main()

