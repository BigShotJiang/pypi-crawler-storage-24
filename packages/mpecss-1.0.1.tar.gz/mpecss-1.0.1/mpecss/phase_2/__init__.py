# Phase 2: Main solver loop
