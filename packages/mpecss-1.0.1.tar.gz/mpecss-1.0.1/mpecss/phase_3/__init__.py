# Phase 3: BNLP polishing and B-stationarity
