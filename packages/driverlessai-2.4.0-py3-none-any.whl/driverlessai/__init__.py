#!/usr/bin/env python
# Copyright 2020 H2O.ai; Proprietary License;  -*- encoding: utf-8 -*-

import sys
import warnings

from driverlessai import token_providers
from driverlessai.__about__ import __build_info__, __version__
from driverlessai._core import Client, is_server_up
from driverlessai._mli_plot import MLIExplainerId

# Deprecation warning for Python 3.8
if sys.version_info[:2] == (3, 8):
    warnings.warn(
        "Python 3.8 support is deprecated and will be removed in a future release. "
        "Please upgrade to Python 3.9 or later.",
        FutureWarning,
        stacklevel=2,
    )

__all__ = [
    "__version__",
    "__build_info__",
    "Client",
    "is_server_up",
    "token_providers",
    "MLIExplainerId",
]
