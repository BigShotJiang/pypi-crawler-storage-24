# ChipsAI MCP Server

Server MCP per gestire chatbot su ai.chipsbuilder.com.

## Struttura
- `server.py` — Server FastMCP (uv run --script)
- GitHub: fgasparetto/chipsai-mcp

## Tool disponibili
Chatbot CRUD, conversations, chat, widget history, user plan, AI models, document upload, analytics.

## Esecuzione
```bash
uv run --script server.py
```

## Env vars
- `CHIPSAI_API_URL` — Base URL (https://ai.chipsbuilder.com)
- `CHIPSAI_USERNAME` — Platform username
- `CHIPSAI_PASSWORD` — Platform password
