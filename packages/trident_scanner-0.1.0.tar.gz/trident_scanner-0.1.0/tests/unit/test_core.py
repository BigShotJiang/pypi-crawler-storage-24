"""Tests for core modules — templates, policy, compliance, fix suggestions."""

from __future__ import annotations

import pytest

from trident.core.compliance import generate_compliance_report, map_vulnerability
from trident.core.fix_suggestions import enrich_vulnerability
from trident.core.models import ScanResult, ScanTarget, Severity, Vulnerability
from trident.core.policy import Policy, load_policy_from_string
from trident.core.templates import TemplateCheck, TemplateRegistry


# --- Template Engine ---

def test_template_check_word_matcher():
    data = {
        "id": "test-1",
        "name": "Test Check",
        "severity": "high",
        "request": {"method": "GET", "path": "/test"},
        "matchers": [
            {"type": "word", "words": ["[core]"], "part": "body"},
            {"type": "status", "status": [200]},
        ],
        "matchers_condition": "and",
    }
    check = TemplateCheck(data)
    assert check.matches(200, {}, "[core]\nrepositoryformatversion = 0")
    assert not check.matches(404, {}, "[core]")
    assert not check.matches(200, {}, "no match here")


def test_template_check_regex_matcher():
    data = {
        "id": "test-2",
        "name": "Regex Check",
        "severity": "medium",
        "request": {"method": "GET", "path": "/"},
        "matchers": [
            {"type": "regex", "regex": [r"DB_\w+="], "part": "body"},
        ],
    }
    check = TemplateCheck(data)
    assert check.matches(200, {}, "DB_HOST=localhost\nDB_PASS=secret")
    assert not check.matches(200, {}, "nothing here")


def test_template_check_header_matcher():
    data = {
        "id": "test-3",
        "name": "Header Check",
        "severity": "info",
        "request": {"method": "GET", "path": "/"},
        "matchers": [
            {"type": "header", "name": "x-powered-by"},
        ],
    }
    check = TemplateCheck(data)
    assert check.matches(200, {"x-powered-by": "Express"}, "")
    assert not check.matches(200, {}, "")


def test_template_check_negative_matcher():
    data = {
        "id": "test-4",
        "name": "Negative Check",
        "severity": "medium",
        "request": {"method": "GET", "path": "/"},
        "matchers": [
            {"type": "header", "name": "strict-transport-security", "absent": True},
        ],
    }
    check = TemplateCheck(data)
    assert check.matches(200, {}, "")
    assert not check.matches(200, {"strict-transport-security": "max-age=31536000"}, "")


def test_template_registry_load_from_string():
    yaml_content = """
id: test-inline
name: Inline Test
severity: low
request:
  method: GET
  path: /test
matchers:
  - type: status
    status: [200]
"""
    registry = TemplateRegistry()
    template = registry.load_from_string(yaml_content)
    assert template.id == "test-inline"
    assert template.severity == Severity.LOW
    assert len(registry.templates) == 1


# --- Policy Engine ---

def test_policy_max_severity():
    policy = load_policy_from_string("""
name: Test Policy
rules:
  - name: no-critical
    type: max_severity
    max: high
""")
    result = ScanResult(
        id="test",
        target=ScanTarget(url="http://test.local"),
        vulnerabilities=[
            Vulnerability(id="v1", title="Critical Bug", description="Bad",
                         severity=Severity.CRITICAL, scanner="test", url="http://test.local"),
        ],
    )
    violations = policy.evaluate(result)
    assert len(violations) == 1
    assert "Critical Bug" in violations[0].message


def test_policy_max_severity_passes():
    policy = load_policy_from_string("""
name: Test Policy
rules:
  - name: no-critical
    type: max_severity
    max: high
""")
    result = ScanResult(
        id="test",
        target=ScanTarget(url="http://test.local"),
        vulnerabilities=[
            Vulnerability(id="v1", title="Medium Bug", description="OK",
                         severity=Severity.MEDIUM, scanner="test", url="http://test.local"),
        ],
    )
    violations = policy.evaluate(result)
    assert len(violations) == 0


def test_policy_max_count():
    policy = load_policy_from_string("""
name: Test Policy
rules:
  - name: max-highs
    type: max_count
    severity: high
    max: 1
""")
    result = ScanResult(
        id="test",
        target=ScanTarget(url="http://test.local"),
        vulnerabilities=[
            Vulnerability(id="v1", title="Bug 1", description="",
                         severity=Severity.HIGH, scanner="test", url="http://test.local"),
            Vulnerability(id="v2", title="Bug 2", description="",
                         severity=Severity.HIGH, scanner="test", url="http://test.local"),
        ],
    )
    violations = policy.evaluate(result)
    assert len(violations) == 1


def test_policy_required_scanner():
    policy = load_policy_from_string("""
name: Test Policy
rules:
  - name: must-run
    type: required_scanner
    scanners: [headers, tls, secrets]
""")
    result = ScanResult(
        id="test",
        target=ScanTarget(url="http://test.local"),
        scanners_run=["headers", "tls"],
    )
    violations = policy.evaluate(result)
    assert len(violations) == 1
    assert "secrets" in violations[0].message


def test_policy_forbidden_finding():
    policy = load_policy_from_string("""
name: Test Policy
rules:
  - name: no-secrets
    type: forbidden_finding
    titles: ["Secret Detected"]
""")
    result = ScanResult(
        id="test",
        target=ScanTarget(url="http://test.local"),
        vulnerabilities=[
            Vulnerability(id="v1", title="Secret Detected: AWS Key", description="",
                         severity=Severity.CRITICAL, scanner="secrets", url="http://test.local"),
        ],
    )
    violations = policy.evaluate(result)
    assert len(violations) == 1


# --- Compliance Mapping ---

def test_compliance_maps_hsts():
    vuln = Vulnerability(
        id="v1", title="Missing Strict-Transport-Security Header",
        description="", severity=Severity.HIGH, scanner="headers",
        url="http://test.local",
    )
    mappings = map_vulnerability(vuln)
    assert "owasp-top10-2025" in mappings
    assert "pci-dss-4" in mappings


def test_compliance_report_structure():
    result = ScanResult(
        id="test",
        target=ScanTarget(url="http://test.local"),
        vulnerabilities=[
            Vulnerability(id="v1", title="SQL Injection in 'id'",
                         description="", severity=Severity.CRITICAL,
                         scanner="sqli", url="http://test.local"),
        ],
    )
    report = generate_compliance_report(result)
    assert "frameworks" in report
    owasp = report["frameworks"]["owasp-top10-2025"]
    assert owasp["fail_count"] > 0
    assert owasp["compliance_pct"] < 100


# --- Fix Suggestions ---

def test_fix_suggestions_adds_snippets():
    vuln = Vulnerability(
        id="v1", title="Missing Strict-Transport-Security Header",
        description="", severity=Severity.HIGH, scanner="headers",
        url="http://test.local", remediation="Add HSTS header.",
    )
    enriched = enrich_vulnerability(vuln)
    assert "fix_snippets" in enriched.metadata
    assert "nginx" in enriched.metadata["fix_snippets"]
    assert "django" in enriched.metadata["fix_snippets"]


def test_fix_suggestions_no_crash_on_unknown():
    vuln = Vulnerability(
        id="v1", title="Some Unknown Finding",
        description="", severity=Severity.LOW, scanner="custom",
        url="http://test.local",
    )
    enriched = enrich_vulnerability(vuln)
    assert "fix_snippets" not in enriched.metadata
