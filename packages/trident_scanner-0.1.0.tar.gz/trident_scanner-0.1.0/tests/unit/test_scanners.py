"""Tests for scanner modules."""

from __future__ import annotations

import httpx
import pytest

from trident.core.models import ScanTarget, Severity
from trident.scanners.headers import HeadersScanner
from trident.scanners.tls import TLSScanner
from trident.scanners.xss import XSSScanner
from trident.scanners.secrets import SecretScanner
from trident.scanners.cors import CORSScanner
from trident.scanners.cookies import CookieScanner
from trident.scanners.info_disclosure import InfoDisclosureScanner
from tests.conftest import make_transport, CLEAN_HTML, SECRETS_HTML


# --- Headers Scanner ---

@pytest.mark.asyncio
async def test_headers_scanner_finds_missing_headers(vuln_client, clean_target):
    scanner = HeadersScanner(vuln_client, clean_target)
    vulns = await scanner.scan(["http://test.local/"])
    titles = {v.title for v in vulns}
    assert "Missing Strict-Transport-Security Header" in titles
    assert "Missing Content-Security-Policy Header" in titles
    assert "Missing X-Frame-Options Header" in titles


@pytest.mark.asyncio
async def test_headers_scanner_clean_on_secure_headers(clean_client, clean_target):
    scanner = HeadersScanner(clean_client, clean_target)
    vulns = await scanner.scan(["http://test.local/"])
    # Should not report missing headers (they're all present)
    missing_titles = [v.title for v in vulns if v.title.startswith("Missing")]
    assert len(missing_titles) == 0


# --- TLS Scanner ---

@pytest.mark.asyncio
async def test_tls_scanner_flags_http():
    target = ScanTarget(url="http://insecure.local")
    client = httpx.AsyncClient(transport=make_transport({}))
    scanner = TLSScanner(client, target)
    vulns = await scanner.scan([])
    assert any("HTTPS" in v.title for v in vulns)


@pytest.mark.asyncio
async def test_tls_scanner_no_flag_on_https():
    target = ScanTarget(url="https://secure.local")
    client = httpx.AsyncClient(transport=make_transport({}))
    scanner = TLSScanner(client, target)
    # Will fail to connect (mock), but should not flag "not using HTTPS"
    vulns = await scanner.scan([])
    assert not any("Not Using HTTPS" in v.title for v in vulns)


# --- XSS Scanner ---

@pytest.mark.asyncio
async def test_xss_passive_no_false_positive_on_short_params():
    """Regression test: short param values should not trigger XSS findings."""
    routes = {
        ("GET", "/search"): (200, {"content-type": "text/html"},
            f"<html><body><p>Results for: tRd3nt_r3fl3ct_t35t</p><p>5 items</p></body></html>"),
    }
    # The probe should be reflected but NOT in a dangerous context
    client = httpx.AsyncClient(transport=make_transport(routes))
    target = ScanTarget(url="http://test.local")
    scanner = XSSScanner(client, target)
    vulns = await scanner.scan(["http://test.local/search?q=hello"])
    # Should find reflection but at LOW severity (not dangerous context)
    high_vulns = [v for v in vulns if v.severity in (Severity.HIGH, Severity.CRITICAL)]
    assert len(high_vulns) == 0


@pytest.mark.asyncio
async def test_xss_passive_detects_dangerous_reflection():
    """XSS scanner should flag reflection inside tag attributes."""
    from tests.conftest import make_transport
    probe = "tRd3nt_r3fl3ct_t35t"
    routes = {
        ("GET", "/search"): (200, {"content-type": "text/html"},
            f'<html><body><input value="{probe}"></body></html>'),
    }
    client = httpx.AsyncClient(transport=make_transport(routes))
    target = ScanTarget(url="http://test.local")
    scanner = XSSScanner(client, target)
    vulns = await scanner.scan(["http://test.local/search?q=hello"])
    dangerous = [v for v in vulns if "Dangerous Context" in v.title]
    assert len(dangerous) >= 1


# --- Secrets Scanner ---

@pytest.mark.asyncio
async def test_secrets_scanner_finds_api_keys():
    routes = {
        ("GET", "/"): (200, {"content-type": "text/html"}, SECRETS_HTML),
    }
    client = httpx.AsyncClient(transport=make_transport(routes))
    target = ScanTarget(url="http://test.local")
    scanner = SecretScanner(client, target)
    vulns = await scanner.scan(["http://test.local/"])
    titles = {v.title for v in vulns}
    assert any("Google API Key" in t for t in titles)
    assert any("Database Connection String" in t for t in titles)


@pytest.mark.asyncio
async def test_secrets_scanner_clean_on_no_secrets(clean_client, clean_target):
    scanner = SecretScanner(clean_client, clean_target)
    vulns = await scanner.scan(["http://test.local/"])
    assert len(vulns) == 0


# --- CORS Scanner ---

@pytest.mark.asyncio
async def test_cors_scanner_flags_reflected_origin():
    def handler(request):
        origin = request.headers.get("origin", "")
        return httpx.Response(200, headers={
            "content-type": "text/html",
            "access-control-allow-origin": origin,
            "access-control-allow-credentials": "true",
        }, text="ok")

    routes = {("GET", "/"): handler}
    # Register handler for all methods
    transport = make_transport({})

    # Custom transport that reflects origin
    def custom_handler(request):
        origin = request.headers.get("origin", "")
        return httpx.Response(200, headers={
            "access-control-allow-origin": origin,
            "access-control-allow-credentials": "true",
        }, text="ok")

    client = httpx.AsyncClient(transport=httpx.MockTransport(custom_handler))
    target = ScanTarget(url="http://test.local")
    scanner = CORSScanner(client, target)
    vulns = await scanner.scan(["http://test.local/"])
    assert any("Arbitrary Origin" in v.title for v in vulns)


@pytest.mark.asyncio
async def test_cors_scanner_clean_on_no_cors():
    routes = {
        ("GET", "/"): (200, {"content-type": "text/html"}, CLEAN_HTML),
    }
    client = httpx.AsyncClient(transport=make_transport(routes))
    target = ScanTarget(url="http://test.local")
    scanner = CORSScanner(client, target)
    vulns = await scanner.scan(["http://test.local/"])
    assert len(vulns) == 0


# --- Cookie Scanner ---

@pytest.mark.asyncio
async def test_cookie_scanner_flags_insecure_cookies():
    routes = {
        ("GET", "/"): (200, {
            "content-type": "text/html",
            "set-cookie": "session_id=abc123; Path=/",
        }, CLEAN_HTML),
    }
    client = httpx.AsyncClient(transport=make_transport(routes))
    target = ScanTarget(url="http://test.local")
    scanner = CookieScanner(client, target)
    vulns = await scanner.scan(["http://test.local/"])
    titles = {v.title for v in vulns}
    assert any("Secure" in t for t in titles)
    assert any("HttpOnly" in t for t in titles)


# --- Info Disclosure Scanner ---

@pytest.mark.asyncio
async def test_info_disclosure_clean_on_safe_page(clean_client, clean_target):
    scanner = InfoDisclosureScanner(clean_client, clean_target)
    vulns = await scanner.scan(["http://test.local/"])
    assert len(vulns) == 0


@pytest.mark.asyncio
async def test_info_disclosure_finds_stack_trace():
    html = "<html><body>Traceback (most recent call last):\n  File 'app.py'</body></html>"
    routes = {("GET", "/"): (200, {"content-type": "text/html"}, html)}
    client = httpx.AsyncClient(transport=make_transport(routes))
    target = ScanTarget(url="http://test.local")
    scanner = InfoDisclosureScanner(client, target)
    vulns = await scanner.scan(["http://test.local/"])
    assert any("stack trace" in v.title.lower() for v in vulns)
