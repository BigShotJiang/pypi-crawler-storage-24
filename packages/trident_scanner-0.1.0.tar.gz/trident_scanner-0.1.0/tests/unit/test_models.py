"""Tests for core data models."""

from trident.core.models import ScanResult, ScanTarget, Severity, Vulnerability


def test_vulnerability_creation():
    vuln = Vulnerability(
        id="test123",
        title="Test Vuln",
        description="A test vulnerability",
        severity=Severity.HIGH,
        scanner="test",
        url="https://example.com",
    )
    assert vuln.severity == Severity.HIGH
    assert vuln.evidence is None
    assert vuln.references == []


def test_scan_target_defaults():
    target = ScanTarget(url="https://example.com")
    assert target.max_depth == 3
    assert target.max_pages == 100
    assert target.rate_limit == 10.0
    assert target.active_mode is False


def test_scan_result_summary():
    result = ScanResult(
        id="scan1",
        target=ScanTarget(url="https://example.com"),
        vulnerabilities=[
            Vulnerability(
                id="v1", title="V1", description="D1",
                severity=Severity.CRITICAL, scanner="test", url="https://example.com",
            ),
            Vulnerability(
                id="v2", title="V2", description="D2",
                severity=Severity.HIGH, scanner="test", url="https://example.com",
            ),
            Vulnerability(
                id="v3", title="V3", description="D3",
                severity=Severity.HIGH, scanner="test", url="https://example.com",
            ),
        ],
    )
    summary = result.summary
    assert summary["critical"] == 1
    assert summary["high"] == 2
    assert summary["medium"] == 0
