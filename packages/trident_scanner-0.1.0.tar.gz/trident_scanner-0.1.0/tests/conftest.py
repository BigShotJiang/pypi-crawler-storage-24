"""Shared test fixtures — mock HTTP server for scanner testing."""

from __future__ import annotations

import asyncio
from typing import Any

import httpx
import pytest

from trident.core.models import ScanTarget


# --- Mock responses for testing ---

CLEAN_HTML = """<!DOCTYPE html><html><head><title>Clean Page</title></head>
<body><h1>Hello</h1><p>Safe content.</p></body></html>"""

VULN_HEADERS_HTML = CLEAN_HTML  # Content doesn't matter, headers do

XSS_REFLECTED_HTML = """<!DOCTYPE html><html><head><title>Search</title></head>
<body><h1>Search Results</h1><p>Results for: {query}</p></body></html>"""

SQLI_ERROR_HTML = """<!DOCTYPE html><html><body>
<p>Error: you have an error in your sql syntax near '' at line 1</p>
</body></html>"""

FORM_HTML = """<!DOCTYPE html><html><body>
<form method="POST" action="/submit">
<input type="text" name="username" />
<input type="password" name="password" />
<input type="submit" />
</form></body></html>"""

SECRETS_HTML = """<!DOCTYPE html><html><body>
<script>
const config = {
    apiKey: "AIzaSyA1234567890abcdefghijklmnopqrstuv",
    dbUrl: "mongodb://admin:password123@db.example.com:27017/prod",
};
</script></body></html>"""

GRAPHQL_INTROSPECTION_RESPONSE = {
    "data": {
        "__schema": {
            "types": [{"name": "Query", "kind": "OBJECT"}, {"name": "User", "kind": "OBJECT"}],
            "queryType": {"name": "Query"},
            "mutationType": {"name": "Mutation"},
        }
    }
}


def make_transport(routes: dict[str, Any]) -> httpx.MockTransport:
    """Create a mock transport from a route dict.

    Routes map (method, path) tuples to (status, headers, body) tuples.
    """

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        method = request.method.upper()

        # Check exact match first
        key = (method, path)
        if key in routes:
            status, headers, body = routes[key]
            return httpx.Response(status, headers=headers, text=body if isinstance(body, str) else None, json=body if isinstance(body, dict) or isinstance(body, list) else None)

        # Check wildcard method
        key = ("*", path)
        if key in routes:
            status, headers, body = routes[key]
            return httpx.Response(status, headers=headers, text=body if isinstance(body, str) else None, json=body if isinstance(body, dict) or isinstance(body, list) else None)

        # Check callable routes
        for (rm, rp), value in routes.items():
            if callable(value) and (rm == "*" or rm == method):
                if path == rp or (rp.endswith("*") and path.startswith(rp[:-1])):
                    return value(request)

        return httpx.Response(404, text="Not Found")

    return httpx.MockTransport(handler)


@pytest.fixture
def clean_target() -> ScanTarget:
    return ScanTarget(url="http://test.local")


@pytest.fixture
def active_target() -> ScanTarget:
    return ScanTarget(url="http://test.local", active_mode=True)


@pytest.fixture
def clean_client() -> httpx.AsyncClient:
    """Client that returns clean responses with proper security headers."""
    routes = {
        ("GET", "/"): (
            200,
            {
                "content-type": "text/html",
                "strict-transport-security": "max-age=31536000",
                "content-security-policy": "default-src 'self'",
                "x-frame-options": "DENY",
                "x-content-type-options": "nosniff",
                "referrer-policy": "strict-origin-when-cross-origin",
                "permissions-policy": "camera=()",
            },
            CLEAN_HTML,
        ),
    }
    return httpx.AsyncClient(transport=make_transport(routes))


@pytest.fixture
def vuln_client() -> httpx.AsyncClient:
    """Client that returns responses with missing security headers."""
    routes = {
        ("GET", "/"): (
            200,
            {"content-type": "text/html"},
            VULN_HEADERS_HTML,
        ),
    }
    return httpx.AsyncClient(transport=make_transport(routes))
