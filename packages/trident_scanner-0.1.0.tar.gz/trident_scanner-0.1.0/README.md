# 🔱 Trident

**Automated web application security scanner with compliance mapping, policy gates, and CI/CD integration.**

Trident scans websites for vulnerabilities aligned with OWASP Top 10 2025, OWASP API Security Top 10, and maps findings to PCI DSS 4.0, SOC 2, and NIST CSF — out of the box.

```bash
pip install trident-scanner
trident scan https://your-app.com
```

## Why Trident?

Most security scanners dump findings. Trident tells you **what to fix, how to fix it, and which compliance frameworks are affected** — with framework-specific code snippets for nginx, Apache, Express, Django, Rails, and more.

| Feature | Trident | ZAP | Nuclei | Nikto |
|---|---|---|---|---|
| Compliance mapping (PCI DSS, SOC 2, NIST) | Yes | No | No | No |
| Policy-as-code CI gates | Yes | Manual | No | No |
| Fix suggestions with code snippets | Yes | No | No | No |
| SARIF for GitHub Code Scanning | Yes | Plugin | No | No |
| SBOM generation | Yes | No | No | No |
| SPA crawling (Playwright) | Yes | Yes | N/A | No |
| Community YAML templates | Yes | N/A | Yes | N/A |
| Web dashboard | Yes | Yes | Cloud | No |

## Quick Start

```bash
# Install
pip install trident-scanner

# Basic scan (passive — safe for any target)
trident scan https://example.com

# Active mode (sends test payloads — use on targets you own)
trident scan https://example.com --active

# Scan a React/Vue/Angular SPA
trident scan https://spa-app.com --js-crawl

# Generate all report formats
trident scan https://example.com \
  -o results.json \
  --html report.html \
  --sarif results.sarif \
  --compliance compliance.json

# Check against a security policy (CI/CD gate)
trident scan https://example.com -o results.json --policy policy.yaml

# Start the web dashboard
trident serve

# Continuous monitoring with Slack alerts
trident monitor https://example.com --interval 30 --webhook https://hooks.slack.com/...
```

## 19 Security Scanners

| Scanner | What It Checks |
|---|---|
| `headers` | Missing security headers (HSTS, CSP, X-Frame-Options, etc.) |
| `tls` | HTTPS enforcement, weak protocols, certificate expiry |
| `xss` | Reflected XSS in GET params and POST forms (passive + active) |
| `sqli` | SQL injection via error-based detection |
| `cors` | CORS misconfigurations (origin reflection, null origin, wildcard) |
| `csrf` | Missing CSRF tokens on state-changing forms |
| `open-redirect` | Open redirect via common redirect parameters |
| `dir-enum` | Sensitive files and directories (.git, .env, backups, admin panels) |
| `cookies` | Cookie security (Secure, HttpOnly, SameSite attributes) |
| `info-disclosure` | Leaked secrets, stack traces, debug mode in HTML |
| `ssrf` | Server-Side Request Forgery via URL parameters |
| `tech-fingerprint` | Technology detection (CMS, frameworks, libraries, CDN) |
| `http-methods` | Dangerous HTTP methods (PUT, DELETE, TRACE) |
| `subdomain-enum` | DNS enumeration of 70+ common subdomains |
| `graphql` | GraphQL introspection, batching, alias DoS, field suggestions |
| `api-security` | OWASP API Top 10 (BOLA, auth, rate limiting, spec exposure) |
| `secrets` | API keys, tokens, credentials in responses and JS files |
| `js-libs` | Outdated JavaScript libraries with known CVEs |
| `templates` | Community YAML vulnerability templates |

## Compliance Mapping

Every finding is automatically mapped to:

- **OWASP Top 10 2025**
- **OWASP API Security Top 10 2023**
- **PCI DSS 4.0**
- **SOC 2 Trust Services Criteria**
- **NIST Cybersecurity Framework**

```bash
trident scan https://example.com --compliance report.json
```

Output includes compliance percentage per framework:
```
OWASP Top 10 2025: 70.0% compliant
PCI DSS 4.0: 87.5% compliant
SOC 2: 83.3% compliant
```

## Policy-as-Code

Define security policies in YAML and use them as CI/CD gates:

```yaml
# policy.yaml
name: Production Security Policy
rules:
  - name: no-critical-findings
    type: max_severity
    max: high

  - name: max-high-findings
    type: max_count
    severity: high
    max: 3

  - name: required-scanners
    type: required_scanner
    scanners: [headers, tls, xss, sqli, secrets]

  - name: no-leaked-secrets
    type: forbidden_finding
    titles: ["Secret Detected", "AWS Access Key"]
```

```bash
# Exits with code 1 on violations — perfect for CI
trident scan https://app.com -o results.json --policy policy.yaml
```

## Community Templates

Add custom vulnerability checks as YAML files — no code needed:

```yaml
# templates/my-check.yaml
id: exposed-admin-panel
name: "Admin Panel Exposed"
severity: high
author: your-name
tags: [exposure, admin]
remediation: "Restrict admin panel access by IP or require VPN."

request:
  method: GET
  path: /admin/login

matchers:
  - type: word
    words: ["Admin Login", "Sign In"]
    condition: or
  - type: status
    status: [200]
matchers_condition: and
```

Drop `.yaml` files in `./templates/` or `~/.trident/templates/` and they're automatically loaded.

## GitHub Actions

```yaml
# .github/workflows/security.yml
name: Security Scan
on: [push]
jobs:
  scan:
    uses: your-org/trident/.github/workflows/trident-scan.yaml@main
    with:
      target_url: https://staging.your-app.com
      fail_on_severity: high
```

Findings appear in the GitHub Security tab via SARIF upload.

## Web Dashboard

```bash
trident serve
# Open http://127.0.0.1:8000
```

Dark-themed dashboard with:
- Scan configuration (URL, scanners, active mode)
- Live progress tracking
- Severity breakdown and compliance posture
- Expandable vulnerability details
- HTML/JSON/SARIF report downloads

## Output Formats

| Format | Flag | Use Case |
|---|---|---|
| Console | (default) | Human-readable terminal output |
| JSON | `-o results.json` | Machine processing, CI/CD |
| HTML | `--html report.html` | Stakeholder sharing |
| SARIF | `--sarif results.sarif` | GitHub Code Scanning |
| CycloneDX SBOM | `--sbom sbom.json` | Supply chain compliance |
| Compliance | `--compliance report.json` | Audit evidence |

## Architecture

```
src/trident/
├── cli/          # Typer CLI (scan, serve, monitor, policy-check)
├── core/         # Engine, models, templates, policy, compliance, SBOM
├── crawlers/     # HTML crawler + Playwright JS crawler
├── scanners/     # 19 plugin scanners + YAML template engine
├── reporters/    # Console, JSON, HTML, SARIF output
├── api/          # FastAPI dashboard + REST API
└── templates/    # Built-in YAML vulnerability templates
```

Adding a new scanner:

```python
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

@register_scanner
class MyScanner(BaseScanner):
    name = "my-scanner"
    description = "Checks for something specific"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        # Your detection logic here
        return []
```

## Development

```bash
git clone https://github.com/your-org/trident.git
cd trident
pip install -e ".[dev,api]"
pytest
```

## License

MIT
