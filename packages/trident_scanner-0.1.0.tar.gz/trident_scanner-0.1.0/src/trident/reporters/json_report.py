"""JSON reporter — saves scan results to a JSON file."""

from __future__ import annotations

import json
from pathlib import Path

from trident.core.models import ScanResult


def save_json_report(result: ScanResult, output_path: str) -> None:
    """Save scan result as a JSON file."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    data = result.model_dump(mode="json")
    path.write_text(json.dumps(data, indent=2, default=str))


def load_json_report(path: str) -> ScanResult:
    """Load a scan result from a JSON file."""
    data = json.loads(Path(path).read_text())
    return ScanResult.model_validate(data)
