"""Console reporter — pretty-prints scan results."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from trident.core.models import ScanResult, Severity

console = Console()

SEVERITY_COLORS = {
    Severity.CRITICAL: "bold red",
    Severity.HIGH: "red",
    Severity.MEDIUM: "yellow",
    Severity.LOW: "blue",
    Severity.INFO: "dim",
}


def print_report(result: ScanResult) -> None:
    """Print a formatted scan report to the console."""
    console.print()

    # Summary panel
    summary = result.summary
    duration = result.duration_seconds
    duration_str = f"{duration:.1f}s" if duration else "N/A"

    summary_text = (
        f"[bold]Scan ID:[/] {result.id}\n"
        f"[bold]Target:[/] {result.target.url}\n"
        f"[bold]Status:[/] {result.status.value}\n"
        f"[bold]Duration:[/] {duration_str}\n"
        f"[bold]URLs Scanned:[/] {result.urls_scanned}\n"
        f"[bold]Scanners Run:[/] {', '.join(result.scanners_run)}\n"
        f"\n"
        f"[bold red]Critical:[/] {summary.get('critical', 0)}  "
        f"[red]High:[/] {summary.get('high', 0)}  "
        f"[yellow]Medium:[/] {summary.get('medium', 0)}  "
        f"[blue]Low:[/] {summary.get('low', 0)}  "
        f"[dim]Info:[/] {summary.get('info', 0)}"
    )

    console.print(Panel(summary_text, title="[bold]Scan Summary[/]", border_style="blue"))

    if not result.vulnerabilities:
        console.print("\n[bold green]No vulnerabilities found![/]\n")
        return

    # Vulnerabilities table
    table = Table(title="Vulnerabilities Found", show_lines=True)
    table.add_column("Severity", width=10)
    table.add_column("Title", width=40)
    table.add_column("URL", width=50)
    table.add_column("Scanner", width=10)

    # Sort by severity
    severity_order = {
        Severity.CRITICAL: 0,
        Severity.HIGH: 1,
        Severity.MEDIUM: 2,
        Severity.LOW: 3,
        Severity.INFO: 4,
    }

    sorted_vulns = sorted(
        result.vulnerabilities,
        key=lambda v: severity_order.get(v.severity, 99),
    )

    for vuln in sorted_vulns:
        color = SEVERITY_COLORS.get(vuln.severity, "white")
        table.add_row(
            f"[{color}]{vuln.severity.value.upper()}[/{color}]",
            vuln.title,
            vuln.url[:50],
            vuln.scanner,
        )

    console.print(table)

    # Detailed findings
    console.print("\n[bold]Detailed Findings:[/]\n")
    for i, vuln in enumerate(sorted_vulns, 1):
        color = SEVERITY_COLORS.get(vuln.severity, "white")
        detail = (
            f"[bold]Description:[/] {vuln.description}\n"
        )
        if vuln.evidence:
            detail += f"[bold]Evidence:[/] {vuln.evidence}\n"
        if vuln.remediation:
            detail += f"[bold]Remediation:[/] {vuln.remediation}\n"
        if vuln.references:
            detail += f"[bold]References:[/] {', '.join(vuln.references)}"

        console.print(
            Panel(
                detail,
                title=f"[{color}][{vuln.severity.value.upper()}] {vuln.title}[/{color}]",
                border_style=color.replace("bold ", ""),
            )
        )

    if result.errors:
        console.print("\n[bold red]Errors:[/]")
        for error in result.errors:
            console.print(f"  [red]•[/] {error}")
