"""SARIF reporter — generates SARIF 2.1.0 output for GitHub Code Scanning."""

from __future__ import annotations

import json
from pathlib import Path

from trident.core.models import ScanResult, Severity

SARIF_SEVERITY_MAP = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "note",
}

SARIF_LEVEL_MAP = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "none",
}


def generate_sarif(result: ScanResult) -> dict:
    """Generate a SARIF 2.1.0 report from scan results."""
    rules = []
    results = []
    rule_ids: dict[str, int] = {}

    for vuln in result.vulnerabilities:
        # Create rule if not exists
        rule_key = f"{vuln.scanner}/{vuln.title}"
        if rule_key not in rule_ids:
            rule_index = len(rules)
            rule_ids[rule_key] = rule_index
            rules.append({
                "id": f"trident/{vuln.scanner}/{vuln.id}",
                "name": vuln.title.replace(" ", ""),
                "shortDescription": {"text": vuln.title},
                "fullDescription": {"text": vuln.description},
                "defaultConfiguration": {
                    "level": SARIF_LEVEL_MAP.get(vuln.severity, "note"),
                },
                "helpUri": vuln.references[0] if vuln.references else "",
                "help": {
                    "text": vuln.remediation or "No remediation available.",
                    "markdown": f"**Remediation:** {vuln.remediation or 'N/A'}\n\n"
                                + (f"**Evidence:** `{vuln.evidence}`\n\n" if vuln.evidence else "")
                                + ("**References:**\n" + "\n".join(f"- {r}" for r in vuln.references) if vuln.references else ""),
                },
                "properties": {
                    "tags": [vuln.scanner, vuln.severity.value],
                    "security-severity": _severity_score(vuln.severity),
                },
            })

        # Create result
        results.append({
            "ruleId": f"trident/{vuln.scanner}/{vuln.id}",
            "ruleIndex": rule_ids[rule_key],
            "level": SARIF_LEVEL_MAP.get(vuln.severity, "note"),
            "message": {
                "text": f"{vuln.title}: {vuln.description}",
            },
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": vuln.url,
                            "uriBaseId": "%SRCROOT%",
                        },
                    },
                }
            ],
            "properties": {
                "severity": vuln.severity.value,
                "scanner": vuln.scanner,
                **({"evidence": vuln.evidence} if vuln.evidence else {}),
            },
        })

    sarif = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "Trident",
                        "version": "0.1.0",
                        "informationUri": "https://github.com/trident-security/trident",
                        "rules": rules,
                    },
                },
                "results": results,
                "invocations": [
                    {
                        "executionSuccessful": result.status.value == "completed",
                        "toolExecutionNotifications": [
                            {"message": {"text": err}} for err in result.errors
                        ],
                    }
                ],
            }
        ],
    }

    return sarif


def save_sarif_report(result: ScanResult, output_path: str) -> None:
    """Save scan result as a SARIF file."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    sarif = generate_sarif(result)
    path.write_text(json.dumps(sarif, indent=2))


def _severity_score(severity: Severity) -> str:
    """Map severity to SARIF security-severity score."""
    scores = {
        Severity.CRITICAL: "9.5",
        Severity.HIGH: "8.0",
        Severity.MEDIUM: "5.5",
        Severity.LOW: "3.0",
        Severity.INFO: "1.0",
    }
    return scores.get(severity, "1.0")
