"""HTML reporter — generates a standalone shareable HTML report."""

from __future__ import annotations

from pathlib import Path

from jinja2 import Template

from trident.core.models import ScanResult, Severity

SEVERITY_ORDER = {
    Severity.CRITICAL: 0, Severity.HIGH: 1, Severity.MEDIUM: 2,
    Severity.LOW: 3, Severity.INFO: 4,
}

HTML_TEMPLATE = Template("""\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trident Security Report — {{ target_url }}</title>
<style>
  :root { --bg: #0f172a; --surface: #1e293b; --border: #334155; --text: #e2e8f0; --muted: #94a3b8; --critical: #ef4444; --high: #f97316; --medium: #eab308; --low: #3b82f6; --info: #6b7280; }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); line-height: 1.6; }
  .container { max-width: 960px; margin: 0 auto; padding: 2rem; }
  header { text-align: center; padding: 3rem 0 2rem; border-bottom: 1px solid var(--border); margin-bottom: 2rem; }
  header h1 { font-size: 1.8rem; font-weight: 700; letter-spacing: -0.02em; }
  header .subtitle { color: var(--muted); margin-top: 0.5rem; font-size: 0.9rem; }
  .meta-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .meta-card { background: var(--surface); border: 1px solid var(--border); border-radius: 0.75rem; padding: 1rem; }
  .meta-card .label { font-size: 0.75rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; }
  .meta-card .value { font-size: 1.1rem; font-weight: 600; margin-top: 0.25rem; }
  .summary-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 0.75rem; margin-bottom: 2rem; }
  .sev-card { text-align: center; border-radius: 0.75rem; padding: 1.25rem 0.5rem; border: 1px solid var(--border); background: var(--surface); }
  .sev-card .count { font-size: 2rem; font-weight: 800; }
  .sev-card .sev-label { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.08em; color: var(--muted); margin-top: 0.25rem; }
  .sev-critical .count { color: var(--critical); }
  .sev-high .count { color: var(--high); }
  .sev-medium .count { color: var(--medium); }
  .sev-low .count { color: var(--low); }
  .sev-info .count { color: var(--info); }
  h2 { font-size: 1.2rem; margin: 2rem 0 1rem; padding-bottom: 0.5rem; border-bottom: 1px solid var(--border); }
  .finding { background: var(--surface); border: 1px solid var(--border); border-radius: 0.75rem; margin-bottom: 1rem; overflow: hidden; }
  .finding-header { padding: 1rem 1.25rem; display: flex; align-items: center; gap: 0.75rem; }
  .badge { display: inline-block; font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; padding: 0.2rem 0.6rem; border-radius: 9999px; white-space: nowrap; }
  .badge-critical { background: rgba(239,68,68,0.15); color: var(--critical); border: 1px solid rgba(239,68,68,0.3); }
  .badge-high { background: rgba(249,115,22,0.15); color: var(--high); border: 1px solid rgba(249,115,22,0.3); }
  .badge-medium { background: rgba(234,179,8,0.15); color: var(--medium); border: 1px solid rgba(234,179,8,0.3); }
  .badge-low { background: rgba(59,130,246,0.15); color: var(--low); border: 1px solid rgba(59,130,246,0.3); }
  .badge-info { background: rgba(107,114,128,0.15); color: var(--info); border: 1px solid rgba(107,114,128,0.3); }
  .finding-title { font-weight: 600; font-size: 0.95rem; }
  .finding-scanner { margin-left: auto; font-size: 0.75rem; color: var(--muted); }
  .finding-body { padding: 0 1.25rem 1.25rem; font-size: 0.85rem; }
  .finding-body dt { color: var(--muted); font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 0.75rem; }
  .finding-body dd { margin-top: 0.25rem; }
  .finding-body code { background: rgba(0,0,0,0.3); padding: 0.15rem 0.4rem; border-radius: 0.25rem; font-size: 0.8rem; color: #fbbf24; word-break: break-all; }
  .finding-body a { color: #60a5fa; text-decoration: none; }
  .finding-body a:hover { text-decoration: underline; }
  .remediation { color: #4ade80; }
  .url-text { color: var(--muted); font-size: 0.8rem; word-break: break-all; }
  footer { text-align: center; padding: 3rem 0 2rem; color: var(--muted); font-size: 0.75rem; border-top: 1px solid var(--border); margin-top: 3rem; }
  .clean-msg { text-align: center; padding: 3rem; color: #4ade80; font-size: 1.1rem; }
  @media print { body { background: #fff; color: #111; } .container { max-width: 100%; } .finding, .meta-card, .sev-card { border-color: #ddd; background: #f9f9f9; } }
  @media (max-width: 640px) { .summary-grid { grid-template-columns: repeat(3, 1fr); } .meta-grid { grid-template-columns: 1fr 1fr; } }
</style>
</head>
<body>
<div class="container">
  <header>
    <h1>&#x1F531; Trident Security Report</h1>
    <div class="subtitle">{{ target_url }} &mdash; {{ scan_date }}</div>
  </header>

  <div class="meta-grid">
    <div class="meta-card"><div class="label">Scan ID</div><div class="value">{{ scan_id }}</div></div>
    <div class="meta-card"><div class="label">Status</div><div class="value">{{ status }}</div></div>
    <div class="meta-card"><div class="label">Duration</div><div class="value">{{ duration }}</div></div>
    <div class="meta-card"><div class="label">URLs Scanned</div><div class="value">{{ urls_scanned }}</div></div>
    <div class="meta-card"><div class="label">Scanners Run</div><div class="value">{{ scanners_count }}</div></div>
    <div class="meta-card"><div class="label">Total Findings</div><div class="value">{{ total_findings }}</div></div>
  </div>

  <div class="summary-grid">
    <div class="sev-card sev-critical"><div class="count">{{ counts.critical }}</div><div class="sev-label">Critical</div></div>
    <div class="sev-card sev-high"><div class="count">{{ counts.high }}</div><div class="sev-label">High</div></div>
    <div class="sev-card sev-medium"><div class="count">{{ counts.medium }}</div><div class="sev-label">Medium</div></div>
    <div class="sev-card sev-low"><div class="count">{{ counts.low }}</div><div class="sev-label">Low</div></div>
    <div class="sev-card sev-info"><div class="count">{{ counts.info }}</div><div class="sev-label">Info</div></div>
  </div>

  <h2>Findings</h2>
  {% if vulns %}
  {% for v in vulns %}
  <div class="finding">
    <div class="finding-header">
      <span class="badge badge-{{ v.severity.value }}">{{ v.severity.value }}</span>
      <span class="finding-title">{{ v.title }}</span>
      <span class="finding-scanner">{{ v.scanner }}</span>
    </div>
    <div class="finding-body">
      <div class="url-text">{{ v.url }}</div>
      <dl>
        <dt>Description</dt>
        <dd>{{ v.description }}</dd>
        {% if v.evidence %}
        <dt>Evidence</dt>
        <dd><code>{{ v.evidence }}</code></dd>
        {% endif %}
        {% if v.remediation %}
        <dt>Remediation</dt>
        <dd class="remediation">{{ v.remediation }}</dd>
        {% endif %}
        {% if v.references %}
        <dt>References</dt>
        <dd>{% for ref in v.references %}<a href="{{ ref }}" target="_blank">{{ ref }}</a>{% if not loop.last %}, {% endif %}{% endfor %}</dd>
        {% endif %}
      </dl>
    </div>
  </div>
  {% endfor %}
  {% else %}
  <div class="clean-msg">&#x2705; No vulnerabilities found &mdash; target looks clean!</div>
  {% endif %}

  <footer>
    Generated by Trident v0.1.0 &mdash; Automated Web Security Scanner
  </footer>
</div>
</body>
</html>
""")


def generate_html_report(result: ScanResult) -> str:
    """Generate HTML report string."""
    duration = f"{result.duration_seconds:.1f}s" if result.duration_seconds else "N/A"
    scan_date = result.started_at.strftime("%Y-%m-%d %H:%M UTC") if result.started_at else "N/A"
    sorted_vulns = sorted(result.vulnerabilities, key=lambda v: SEVERITY_ORDER.get(v.severity, 99))

    return HTML_TEMPLATE.render(
        target_url=result.target.url,
        scan_id=result.id,
        status=result.status.value,
        duration=duration,
        scan_date=scan_date,
        urls_scanned=result.urls_scanned,
        scanners_count=len(result.scanners_run),
        total_findings=len(result.vulnerabilities),
        counts=result.summary,
        vulns=sorted_vulns,
    )


def save_html_report(result: ScanResult, output_path: str) -> None:
    """Generate and save a standalone HTML report."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(generate_html_report(result))
