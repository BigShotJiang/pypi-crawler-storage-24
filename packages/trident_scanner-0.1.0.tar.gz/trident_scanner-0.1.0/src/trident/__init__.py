"""Trident — Automated web application security scanner."""

__version__ = "0.1.0"
