"""Template-based scanner — runs community YAML vulnerability checks."""

from __future__ import annotations

import asyncio
import uuid
from pathlib import Path
from urllib.parse import urljoin

from trident.core.models import Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.core.templates import TemplateRegistry
from trident.scanners import register_scanner

# User/community template directories (checked in order)
_USER_TEMPLATE_DIRS = [
    Path.cwd() / "templates",        # ./templates in working dir
    Path.home() / ".trident" / "templates",  # ~/.trident/templates
]


@register_scanner
class TemplateScanner(BaseScanner):
    name = "templates"
    description = "Runs community YAML vulnerability templates (CVEs, misconfigs, exposures)"

    async def setup(self) -> None:
        self.registry = TemplateRegistry()
        # Load built-in templates (always available, packaged with trident)
        builtin = Path(__file__).parent.parent / "templates"
        self.registry.load_directory(builtin)
        # Load user/community templates from known locations
        for template_dir in _USER_TEMPLATE_DIRS:
            self.registry.load_directory(template_dir)

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        if not self.registry.templates:
            return []

        vulns: list[Vulnerability] = []
        semaphore = asyncio.Semaphore(5)

        async def run_template(template, base_url: str) -> Vulnerability | None:
            url = urljoin(base_url.rstrip("/"), template.path)
            async with semaphore:
                try:
                    kwargs: dict = {
                        "method": template.method,
                        "url": url,
                        "headers": template.headers,
                        "follow_redirects": template.follow_redirects,
                    }
                    if template.body:
                        kwargs["content"] = template.body

                    response = await self.client.request(**kwargs)
                except Exception:
                    return None

            headers_dict = {k.lower(): v for k, v in response.headers.items()}
            if template.matches(response.status_code, headers_dict, response.text):
                evidence = f"HTTP {response.status_code}, matched template {template.id}"
                return template.to_vulnerability(url, evidence)
            return None

        base_url = self.target.url

        tasks = [run_template(t, base_url) for t in self.registry.templates]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, Vulnerability):
                vulns.append(result)

        return vulns
