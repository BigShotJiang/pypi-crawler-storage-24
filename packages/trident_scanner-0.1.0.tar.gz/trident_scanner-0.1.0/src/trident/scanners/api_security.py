"""API security scanner — OWASP API Security Top 10 checks."""

from __future__ import annotations

import json
import re
import uuid
from urllib.parse import urljoin, urlparse

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# Common API paths to discover
API_PATHS = [
    "/api", "/api/v1", "/api/v2", "/api/v3",
    "/rest", "/rest/v1", "/rest/v2",
    "/v1", "/v2", "/v3",
    "/swagger.json", "/swagger/v1/swagger.json",
    "/openapi.json", "/openapi.yaml",
    "/api-docs", "/api-docs.json",
    "/docs", "/redoc",
    "/.well-known/openapi",
]

# Sensitive API endpoints to probe
SENSITIVE_ENDPOINTS = [
    ("/api/users", "User listing endpoint"),
    ("/api/v1/users", "User listing endpoint"),
    ("/api/admin", "Admin API endpoint"),
    ("/api/v1/admin", "Admin API endpoint"),
    ("/api/config", "Configuration endpoint"),
    ("/api/v1/config", "Configuration endpoint"),
    ("/api/debug", "Debug endpoint"),
    ("/api/health", "Health check endpoint"),
    ("/api/metrics", "Metrics endpoint"),
    ("/api/env", "Environment endpoint"),
    ("/api/internal", "Internal API endpoint"),
    ("/api/v1/internal", "Internal API endpoint"),
]


@register_scanner
class APISecurityScanner(BaseScanner):
    name = "api-security"
    description = "OWASP API Security Top 10 checks (BOLA, auth, rate limiting, spec exposure)"
    requires_serial = True

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []

        base = self.target.url.rstrip("/")

        # 1. API spec exposure
        vulns.extend(await self._check_spec_exposure(base))

        # 2. Unauthenticated API access
        vulns.extend(await self._check_unauth_access(base))

        # 3. Rate limiting
        if self.target.active_mode:
            vulns.extend(await self._check_rate_limiting(base))

        # 4. Verbose error responses
        vulns.extend(await self._check_verbose_errors(base))

        # 5. BOLA indicators (object ID patterns)
        vulns.extend(await self._check_bola_indicators(urls))

        # 6. Mass assignment indicators
        vulns.extend(await self._check_mass_assignment_indicators(base))

        return vulns

    async def _check_spec_exposure(self, base: str) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        spec_paths = [
            "/swagger.json", "/swagger/v1/swagger.json", "/swagger-ui.html",
            "/openapi.json", "/openapi.yaml", "/api-docs", "/api-docs.json",
            "/docs", "/redoc", "/.well-known/openapi",
        ]
        for path in spec_paths:
            url = urljoin(base, path)
            try:
                resp = await self.client.get(url)
                if resp.status_code == 200 and len(resp.content) > 50:
                    content_type = resp.headers.get("content-type", "")
                    text = resp.text[:500]
                    is_spec = (
                        "swagger" in text.lower()
                        or "openapi" in text.lower()
                        or '"paths"' in text
                        or '"info"' in text
                    )
                    is_ui = "swagger-ui" in text.lower() or "redoc" in text.lower()

                    if is_spec or is_ui:
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title=f"API Specification Exposed: {path}",
                                description=(
                                    f"{'API documentation UI' if is_ui else 'API specification file'} "
                                    f"is publicly accessible. This reveals all endpoints, parameters, "
                                    f"and data models to potential attackers."
                                ),
                                severity=Severity.MEDIUM if is_spec else Severity.LOW,
                                scanner=self.name,
                                url=url,
                                evidence=f"HTTP 200, {len(resp.content)} bytes",
                                remediation=(
                                    "Restrict API documentation to authenticated users or internal networks. "
                                    "Remove spec files from production deployments."
                                ),
                                references=[
                                    "https://owasp.org/API-Security/editions/2023/en/0xa9-improper-inventory-management/",
                                ],
                            )
                        )
            except Exception:
                continue
        return vulns

    async def _check_unauth_access(self, base: str) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        for path, desc in SENSITIVE_ENDPOINTS:
            url = urljoin(base, path)
            try:
                resp = await self.client.get(url)
                if resp.status_code == 200:
                    try:
                        data = resp.json()
                        # Check if it returns meaningful data
                        if isinstance(data, (list, dict)) and len(str(data)) > 20:
                            vulns.append(
                                Vulnerability(
                                    id=uuid.uuid4().hex[:12],
                                    title=f"Unauthenticated API Access: {path}",
                                    description=(
                                        f"{desc} at {path} is accessible without authentication "
                                        f"and returns data."
                                    ),
                                    severity=Severity.HIGH,
                                    scanner=self.name,
                                    url=url,
                                    evidence=f"HTTP 200, returns {type(data).__name__} with data",
                                    remediation=(
                                        "Require authentication for all API endpoints. "
                                        "Implement proper access control checks."
                                    ),
                                    references=[
                                        "https://owasp.org/API-Security/editions/2023/en/0xa2-broken-authentication/",
                                    ],
                                )
                            )
                    except (json.JSONDecodeError, ValueError):
                        continue
            except Exception:
                continue
        return vulns

    async def _check_rate_limiting(self, base: str) -> list[Vulnerability]:
        """Send rapid requests to check for rate limiting."""
        vulns: list[Vulnerability] = []

        # Find an API endpoint
        test_url = None
        for path in ["/api", "/api/v1", "/api/health", "/"]:
            url = urljoin(base, path)
            try:
                resp = await self.client.get(url)
                if resp.status_code in (200, 401, 403, 404):
                    test_url = url
                    break
            except Exception:
                continue

        if not test_url:
            return vulns

        # Send 20 rapid requests
        success_count = 0
        for _ in range(20):
            try:
                resp = await self.client.get(test_url)
                if resp.status_code not in (429, 503):
                    success_count += 1
            except Exception:
                break

        if success_count >= 20:
            # Check response headers for rate limit info
            try:
                resp = await self.client.get(test_url)
                has_rate_headers = any(
                    h in resp.headers
                    for h in ["x-ratelimit-limit", "x-rate-limit-limit",
                              "ratelimit-limit", "retry-after",
                              "x-ratelimit-remaining"]
                )
            except Exception:
                has_rate_headers = False

            if not has_rate_headers:
                vulns.append(
                    Vulnerability(
                        id=uuid.uuid4().hex[:12],
                        title="No API Rate Limiting Detected",
                        description=(
                            "The API does not appear to enforce rate limiting. "
                            "20 rapid requests were all accepted without throttling "
                            "or rate limit headers."
                        ),
                        severity=Severity.MEDIUM,
                        scanner=self.name,
                        url=test_url,
                        evidence=f"{success_count}/20 requests accepted, no rate limit headers",
                        remediation=(
                            "Implement rate limiting on all API endpoints. "
                            "Use headers like X-RateLimit-Limit and X-RateLimit-Remaining. "
                            "Return HTTP 429 when limits are exceeded."
                        ),
                        references=[
                            "https://owasp.org/API-Security/editions/2023/en/0xa4-unrestricted-resource-consumption/",
                        ],
                    )
                )

        return vulns

    async def _check_verbose_errors(self, base: str) -> list[Vulnerability]:
        """Send malformed requests to check for verbose error messages."""
        vulns: list[Vulnerability] = []

        test_urls = [
            urljoin(base, "/api/v1/users/999999999"),
            urljoin(base, "/api/nonexistent_endpoint_xyz"),
            urljoin(base, "/api/v1/../../../etc/passwd"),
        ]

        for url in test_urls:
            try:
                resp = await self.client.get(url)
                body = resp.text

                # Check for verbose error patterns
                verbose_patterns = [
                    (r"stack\s*trace", "Stack trace in error response"),
                    (r"at\s+\w+\.\w+\(", "Code-level error details exposed"),
                    (r"(?:sql|database|query)\s*(?:error|exception)", "Database error details exposed"),
                    (r"internal server error.*(?:file|path|line)", "Internal path information in errors"),
                ]

                for pattern, desc in verbose_patterns:
                    if re.search(pattern, body, re.IGNORECASE):
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title=f"Verbose API Error: {desc}",
                                description=(
                                    f"The API returns detailed error information that reveals "
                                    f"internal implementation details."
                                ),
                                severity=Severity.MEDIUM,
                                scanner=self.name,
                                url=url,
                                evidence=body[:200],
                                remediation=(
                                    "Return generic error messages in production. "
                                    "Log detailed errors server-side only. "
                                    "Use structured error responses with error codes."
                                ),
                                references=[
                                    "https://cwe.mitre.org/data/definitions/209.html",
                                ],
                            )
                        )
                        return vulns  # One finding is enough
            except Exception:
                continue
        return vulns

    async def _check_bola_indicators(self, urls: list[str]) -> list[Vulnerability]:
        """Check for sequential/predictable IDs in API URLs that indicate BOLA risk."""
        vulns: list[Vulnerability] = []
        id_pattern = re.compile(r'/(?:api|rest|v\d)/\w+/(\d{1,10})(?:[/?]|$)')
        found_endpoints: set[str] = set()

        for url in urls:
            match = id_pattern.search(url)
            if match:
                endpoint_base = url[:match.start(1)]
                if endpoint_base not in found_endpoints:
                    found_endpoints.add(endpoint_base)
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title="Potential BOLA: Sequential Object IDs in API",
                            description=(
                                f"API endpoint uses sequential numeric IDs ({match.group(1)}). "
                                f"This pattern is the #1 indicator of Broken Object Level "
                                f"Authorization (BOLA/IDOR) vulnerabilities."
                            ),
                            severity=Severity.LOW,
                            scanner=self.name,
                            url=url,
                            evidence=f"Sequential ID: {match.group(1)} at {endpoint_base}",
                            remediation=(
                                "Use UUIDs instead of sequential IDs. "
                                "Implement object-level authorization checks on every request. "
                                "Verify the authenticated user has access to the requested object."
                            ),
                            references=[
                                "https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/",
                            ],
                        )
                    )

        return vulns

    async def _check_mass_assignment_indicators(self, base: str) -> list[Vulnerability]:
        """Check if API endpoints accept unexpected fields."""
        vulns: list[Vulnerability] = []

        if not self.target.active_mode:
            return vulns

        # Try common API endpoints with extra fields
        test_endpoints = ["/api/users", "/api/v1/users", "/api/account", "/api/v1/account"]

        for path in test_endpoints:
            url = urljoin(base, path)
            try:
                resp = await self.client.post(
                    url,
                    json={"role": "admin", "is_admin": True, "_internal": True},
                    headers={"Content-Type": "application/json"},
                )
                if resp.status_code in (200, 201, 422):
                    try:
                        data = resp.json()
                        data_str = json.dumps(data)
                        if any(field in data_str for field in ['"role"', '"is_admin"', '"_internal"']):
                            vulns.append(
                                Vulnerability(
                                    id=uuid.uuid4().hex[:12],
                                    title="Potential Mass Assignment Vulnerability",
                                    description=(
                                        f"API endpoint {path} appears to accept and reflect "
                                        f"unexpected fields (role, is_admin). This may allow "
                                        f"privilege escalation."
                                    ),
                                    severity=Severity.HIGH,
                                    scanner=self.name,
                                    url=url,
                                    evidence=f"Injected fields reflected in response",
                                    remediation=(
                                        "Use explicit allowlists for accepted fields. "
                                        "Never bind request data directly to models. "
                                        "Use DTOs/schemas to validate input."
                                    ),
                                    references=[
                                        "https://owasp.org/API-Security/editions/2023/en/0xa3-broken-object-property-level-authorization/",
                                    ],
                                )
                            )
                            return vulns
                    except (json.JSONDecodeError, ValueError):
                        continue
            except Exception:
                continue
        return vulns
