"""TLS/SSL configuration scanner."""

from __future__ import annotations

import ssl
import uuid
from urllib.parse import urlparse

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner


@register_scanner
class TLSScanner(BaseScanner):
    name = "tls"
    description = "Checks TLS/SSL configuration for weaknesses"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        parsed = urlparse(self.target.url)

        if parsed.scheme != "https":
            vulns.append(
                Vulnerability(
                    id=uuid.uuid4().hex[:12],
                    title="Site Not Using HTTPS",
                    description="The target URL uses HTTP instead of HTTPS. All traffic is unencrypted.",
                    severity=Severity.HIGH,
                    scanner=self.name,
                    url=self.target.url,
                    remediation="Migrate the site to HTTPS and redirect all HTTP traffic.",
                    references=["https://cwe.mitre.org/data/definitions/319.html"],
                )
            )
            return vulns

        hostname = parsed.hostname
        port = parsed.port or 443

        if not hostname:
            return vulns

        # Check certificate and protocol support
        try:
            context = ssl.create_default_context()
            with context.wrap_socket(
                __import__("socket").create_connection((hostname, port), timeout=10),
                server_hostname=hostname,
            ) as sock:
                cert = sock.getpeercert()
                protocol = sock.version()

                # Check for weak protocols
                if protocol and protocol in ("TLSv1", "TLSv1.1"):
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Weak TLS Protocol: {protocol}",
                            description=f"Server supports {protocol} which is deprecated and insecure.",
                            severity=Severity.HIGH,
                            scanner=self.name,
                            url=self.target.url,
                            evidence=f"Protocol: {protocol}",
                            remediation="Disable TLSv1.0 and TLSv1.1. Only support TLSv1.2 and TLSv1.3.",
                            references=["https://cwe.mitre.org/data/definitions/326.html"],
                        )
                    )

                # Check certificate expiry
                if cert:
                    import datetime

                    not_after = ssl.cert_time_to_seconds(cert.get("notAfter", ""))
                    now = datetime.datetime.now(datetime.timezone.utc).timestamp()
                    days_remaining = (not_after - now) / 86400

                    if days_remaining < 0:
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title="Expired TLS Certificate",
                                description="The TLS certificate has expired.",
                                severity=Severity.CRITICAL,
                                scanner=self.name,
                                url=self.target.url,
                                evidence=f"Expired: {cert.get('notAfter', 'unknown')}",
                                remediation="Renew the TLS certificate immediately.",
                                references=["https://cwe.mitre.org/data/definitions/295.html"],
                            )
                        )
                    elif days_remaining < 30:
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title="TLS Certificate Expiring Soon",
                                description=f"Certificate expires in {int(days_remaining)} days.",
                                severity=Severity.MEDIUM,
                                scanner=self.name,
                                url=self.target.url,
                                evidence=f"Expires: {cert.get('notAfter', 'unknown')}",
                                remediation="Renew the TLS certificate before it expires.",
                                references=["https://cwe.mitre.org/data/definitions/295.html"],
                            )
                        )

        except ssl.SSLCertVerificationError as e:
            vulns.append(
                Vulnerability(
                    id=uuid.uuid4().hex[:12],
                    title="TLS Certificate Verification Failed",
                    description=f"Certificate verification failed: {e}",
                    severity=Severity.CRITICAL,
                    scanner=self.name,
                    url=self.target.url,
                    evidence=str(e),
                    remediation="Fix TLS certificate issues (self-signed, wrong hostname, or untrusted CA).",
                    references=["https://cwe.mitre.org/data/definitions/295.html"],
                )
            )
        except Exception:
            # Connection failed — not a TLS-specific issue
            pass

        return vulns
