"""Cross-Site Scripting (XSS) scanner."""

from __future__ import annotations

import re
import uuid
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from bs4 import BeautifulSoup

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# Payloads for reflected XSS detection — benign canaries, not real exploits
XSS_CANARIES = [
    '<trident_xss_test">',
    "javascript:trident_test",
    '"><img src=x onerror=trident_test>',
    "'-trident_test-'",
    "<script>trident_test</script>",
]

# Unique probe string unlikely to appear naturally
REFLECTION_PROBE = "tRd3nt_r3fl3ct_t35t"

# Patterns that confirm dangerous reflection contexts
DANGEROUS_REFLECTION_PATTERNS = [
    # Inside a tag attribute value (unquoted or breaking out)
    re.compile(r'(?:value|href|src|action|on\w+)\s*=\s*["\']?[^"\']*' + REFLECTION_PROBE, re.I),
    # Inside a <script> block
    re.compile(r'<script[^>]*>[^<]*' + REFLECTION_PROBE, re.I),
    # Inside an HTML comment
    re.compile(r'<!--[^>]*' + REFLECTION_PROBE, re.I),
    # Unencoded in tag context (between < and >)
    re.compile(r'<[^>]*' + REFLECTION_PROBE + r'[^>]*>', re.I),
]


@register_scanner
class XSSScanner(BaseScanner):
    name = "xss"
    description = "Detects reflected Cross-Site Scripting vulnerabilities"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []

        if not self.target.active_mode:
            vulns.extend(await self._passive_scan(urls))
        else:
            vulns.extend(await self._active_scan(urls))

        return vulns

    async def _passive_scan(self, urls: list[str]) -> list[Vulnerability]:
        """Check for XSS-prone reflection using a unique probe string."""
        vulns: list[Vulnerability] = []
        tested: set[str] = set()

        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query)

            if not params:
                continue

            for param_name in params:
                test_key = f"{parsed.netloc}{parsed.path}:{param_name}"
                if test_key in tested:
                    continue
                tested.add(test_key)

                # Inject a unique probe to check for reflection
                test_params = dict(params)
                test_params[param_name] = [REFLECTION_PROBE]
                new_query = urlencode(test_params, doseq=True)
                test_url = urlunparse(parsed._replace(query=new_query))

                try:
                    response = await self.client.get(test_url)
                except Exception:
                    continue

                if REFLECTION_PROBE not in response.text:
                    continue

                content_type = response.headers.get("content-type", "")
                if "text/html" not in content_type:
                    continue

                # Check if the reflection is in a dangerous context
                in_dangerous_context = any(
                    p.search(response.text) for p in DANGEROUS_REFLECTION_PATTERNS
                )

                has_csp = "content-security-policy" in {
                    k.lower() for k in response.headers.keys()
                }

                if in_dangerous_context:
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Reflected XSS: '{param_name}' in Dangerous Context",
                            description=(
                                f"Parameter '{param_name}' is reflected in a dangerous HTML context "
                                f"(inside a tag attribute, script block, or unencoded in HTML). "
                                f"Enable active mode to confirm exploitability."
                            ),
                            severity=Severity.HIGH if not has_csp else Severity.MEDIUM,
                            scanner=self.name,
                            url=url,
                            evidence=f"Probe '{REFLECTION_PROBE}' reflected in dangerous context",
                            remediation=(
                                "Encode all user input with context-aware output encoding. "
                                "Use Content-Security-Policy to mitigate impact."
                            ),
                            references=[
                                "https://cwe.mitre.org/data/definitions/79.html",
                                "https://owasp.org/www-community/attacks/xss/",
                            ],
                        )
                    )
                elif not has_csp:
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Potential Reflected XSS in '{param_name}'",
                            description=(
                                f"Parameter '{param_name}' value is reflected in the HTML response "
                                f"without CSP protection. The reflection appears to be encoded but "
                                f"enable active mode to confirm."
                            ),
                            severity=Severity.LOW,
                            scanner=self.name,
                            url=url,
                            evidence=f"Probe '{REFLECTION_PROBE}' reflected (possibly encoded)",
                            remediation=(
                                "Verify output encoding is applied consistently. "
                                "Implement Content-Security-Policy header."
                            ),
                            references=[
                                "https://cwe.mitre.org/data/definitions/79.html",
                            ],
                        )
                    )

        return vulns

    async def _active_scan(self, urls: list[str]) -> list[Vulnerability]:
        """Inject canary payloads to confirm reflected XSS in GET and POST params."""
        vulns: list[Vulnerability] = []

        # Test GET parameters
        vulns.extend(await self._test_get_params(urls))

        # Test POST forms
        vulns.extend(await self._test_post_forms(urls))

        return vulns

    async def _test_get_params(self, urls: list[str]) -> list[Vulnerability]:
        """Test GET query parameters for reflected XSS."""
        vulns: list[Vulnerability] = []
        tested: set[str] = set()

        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query)
            if not params:
                continue

            for param_name in params:
                test_key = f"GET:{parsed.netloc}{parsed.path}:{param_name}"
                if test_key in tested:
                    continue
                tested.add(test_key)

                for canary in XSS_CANARIES:
                    test_params = dict(params)
                    test_params[param_name] = [canary]
                    new_query = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=new_query))

                    try:
                        response = await self.client.get(test_url)
                    except Exception:
                        continue

                    if canary in response.text:
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title=f"Confirmed Reflected XSS in GET '{param_name}'",
                                description=(
                                    f"GET parameter '{param_name}' reflects unescaped input "
                                    f"in the HTML response."
                                ),
                                severity=Severity.HIGH,
                                scanner=self.name,
                                url=url,
                                evidence=f"Payload: {canary}",
                                remediation=(
                                    "Sanitize and encode all user input. Use context-aware "
                                    "output encoding. Implement CSP with script-src restrictions."
                                ),
                                references=[
                                    "https://cwe.mitre.org/data/definitions/79.html",
                                    "https://owasp.org/www-community/attacks/xss/",
                                ],
                            )
                        )
                        break  # One confirmed finding per param
        return vulns

    async def _test_post_forms(self, urls: list[str]) -> list[Vulnerability]:
        """Test POST form inputs for reflected XSS."""
        vulns: list[Vulnerability] = []
        tested_forms: set[str] = set()

        for url in urls[:15]:
            try:
                response = await self.client.get(url)
            except Exception:
                continue

            if "text/html" not in response.headers.get("content-type", ""):
                continue

            soup = BeautifulSoup(response.text, "lxml")
            forms = soup.find_all("form")

            for form in forms:
                method = (form.get("method", "get")).lower()
                action = form.get("action", url)
                if not action.startswith("http"):
                    from urllib.parse import urljoin
                    action = urljoin(url, action)

                # Get text/hidden inputs
                inputs = form.find_all("input")
                text_inputs = [
                    inp for inp in inputs
                    if inp.get("type", "text").lower() in ("text", "search", "email", "url", "tel", "hidden")
                    and inp.get("name")
                ]

                if not text_inputs:
                    continue

                form_key = f"{method}:{action}:{','.join(i.get('name','') for i in text_inputs)}"
                if form_key in tested_forms:
                    continue
                tested_forms.add(form_key)

                for canary in XSS_CANARIES[:2]:  # Test fewer canaries for forms
                    form_data = {}
                    for inp in text_inputs:
                        name = inp.get("name", "")
                        form_data[name] = inp.get("value", canary)

                    # Inject canary into each text input one at a time
                    for target_input in text_inputs:
                        if target_input.get("type", "text").lower() == "hidden":
                            continue

                        test_data = dict(form_data)
                        target_name = target_input.get("name", "")
                        test_data[target_name] = canary

                        try:
                            if method == "post":
                                resp = await self.client.post(action, data=test_data)
                            else:
                                resp = await self.client.get(action, params=test_data)
                        except Exception:
                            continue

                        if canary in resp.text:
                            vulns.append(
                                Vulnerability(
                                    id=uuid.uuid4().hex[:12],
                                    title=f"Confirmed Reflected XSS in {method.upper()} Form '{target_name}'",
                                    description=(
                                        f"Form input '{target_name}' (action: {action}) reflects "
                                        f"unescaped payload in the response."
                                    ),
                                    severity=Severity.HIGH,
                                    scanner=self.name,
                                    url=url,
                                    evidence=f"Method: {method.upper()}, Input: {target_name}, Payload: {canary}",
                                    remediation=(
                                        "Sanitize and encode all form input before rendering. "
                                        "Use parameterized templates. Implement CSP."
                                    ),
                                    references=[
                                        "https://cwe.mitre.org/data/definitions/79.html",
                                    ],
                                )
                            )
                            return vulns  # One confirmed form XSS is enough

        return vulns
