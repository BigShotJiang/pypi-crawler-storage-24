"""Subdomain enumeration scanner via DNS brute-force."""

from __future__ import annotations

import asyncio
import uuid
from urllib.parse import urlparse

import dns.asyncresolver
import dns.exception

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# Common subdomains to check
COMMON_SUBDOMAINS = [
    "www", "mail", "ftp", "webmail", "smtp", "pop", "ns1", "ns2",
    "admin", "portal", "api", "dev", "staging", "stage", "test",
    "beta", "demo", "app", "m", "mobile", "cdn", "static", "assets",
    "media", "img", "images", "docs", "wiki", "blog", "forum",
    "shop", "store", "secure", "vpn", "remote", "gateway",
    "git", "gitlab", "jenkins", "ci", "jira", "confluence",
    "grafana", "kibana", "prometheus", "monitor", "status",
    "auth", "login", "sso", "oauth", "id", "accounts",
    "db", "database", "mysql", "postgres", "redis", "mongo",
    "internal", "intranet", "corp", "office", "exchange",
    "backup", "bak", "old", "legacy", "archive",
    "s3", "storage", "files", "upload", "downloads",
    "chat", "slack", "teams", "meet",
]


@register_scanner
class SubdomainEnumScanner(BaseScanner):
    name = "subdomain-enum"
    description = "Discovers subdomains via DNS enumeration"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []

        parsed = urlparse(self.target.url)
        domain = parsed.hostname
        if not domain:
            return vulns

        # Skip if it's an IP address
        if domain.replace(".", "").isdigit():
            return vulns

        # Get base domain (handle www.example.com → example.com)
        parts = domain.split(".")
        if len(parts) > 2 and parts[0] == "www":
            base_domain = ".".join(parts[1:])
        elif len(parts) >= 2:
            base_domain = domain
        else:
            return vulns

        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = 3
        resolver.lifetime = 5

        semaphore = asyncio.Semaphore(20)
        found_subdomains: list[tuple[str, list[str]]] = []

        async def check_subdomain(sub: str) -> None:
            fqdn = f"{sub}.{base_domain}"
            async with semaphore:
                try:
                    answers = await resolver.resolve(fqdn, "A")
                    ips = [str(rdata) for rdata in answers]
                    found_subdomains.append((fqdn, ips))
                except (dns.exception.DNSException, asyncio.TimeoutError):
                    pass

        tasks = [check_subdomain(sub) for sub in COMMON_SUBDOMAINS]
        await asyncio.gather(*tasks, return_exceptions=True)

        if found_subdomains:
            # Build a summary of all found subdomains
            sub_list = "\n".join(
                f"  {fqdn} → {', '.join(ips)}" for fqdn, ips in sorted(found_subdomains)
            )

            vulns.append(
                Vulnerability(
                    id=uuid.uuid4().hex[:12],
                    title=f"Discovered {len(found_subdomains)} Subdomains",
                    description=(
                        f"DNS enumeration found {len(found_subdomains)} subdomains for {base_domain}. "
                        f"Each subdomain expands the attack surface and should be assessed."
                    ),
                    severity=Severity.INFO,
                    scanner=self.name,
                    url=self.target.url,
                    evidence=sub_list,
                    remediation=(
                        "Review all subdomains for exposure. Remove DNS entries for "
                        "decommissioned services. Ensure all subdomains follow security policies."
                    ),
                    references=["https://cwe.mitre.org/data/definitions/200.html"],
                )
            )

            # Flag potentially risky subdomains
            risky = {
                "admin", "staging", "stage", "test", "dev", "beta", "demo",
                "internal", "intranet", "jenkins", "git", "gitlab", "jira",
                "grafana", "kibana", "db", "database", "backup", "old", "legacy",
            }

            for fqdn, ips in found_subdomains:
                sub = fqdn.split(".")[0]
                if sub in risky:
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Sensitive Subdomain: {fqdn}",
                            description=(
                                f"Subdomain '{fqdn}' suggests a development, admin, or internal "
                                f"service that may not be properly secured."
                            ),
                            severity=Severity.LOW,
                            scanner=self.name,
                            url=f"http://{fqdn}",
                            evidence=f"{fqdn} → {', '.join(ips)}",
                            remediation=(
                                "Ensure this subdomain is not publicly accessible or is "
                                "properly secured with authentication and access controls."
                            ),
                            references=["https://cwe.mitre.org/data/definitions/200.html"],
                        )
                    )

        return vulns
