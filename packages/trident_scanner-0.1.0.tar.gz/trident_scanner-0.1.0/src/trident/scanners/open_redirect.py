"""Open redirect scanner."""

from __future__ import annotations

import uuid
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

REDIRECT_PARAMS = {
    "url", "redirect", "redirect_url", "redirect_uri", "next", "return",
    "return_url", "returnto", "return_to", "goto", "dest", "destination",
    "redir", "redirect_to", "out", "continue", "target", "link", "forward",
    "callback", "cb", "ref", "to",
}

REDIRECT_PAYLOAD = "https://evil-attacker.com/phish"


@register_scanner
class OpenRedirectScanner(BaseScanner):
    name = "open-redirect"
    description = "Detects open redirect vulnerabilities via common redirect parameters"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []

        if not self.target.active_mode:
            # Passive: flag URLs with redirect-like params
            vulns.extend(self._passive_scan(urls))
        else:
            # Active: inject redirect payloads
            vulns.extend(await self._active_scan(urls))

        return vulns

    def _passive_scan(self, urls: list[str]) -> list[Vulnerability]:
        """Flag URLs that have known redirect parameter names."""
        vulns: list[Vulnerability] = []
        found_params: set[str] = set()

        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query)

            for param_name in params:
                if param_name.lower() in REDIRECT_PARAMS and param_name not in found_params:
                    found_params.add(param_name)
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Potential Open Redirect via '{param_name}'",
                            description=(
                                f"URL contains parameter '{param_name}' which is commonly used for "
                                f"redirects. Enable active mode to confirm if it's exploitable."
                            ),
                            severity=Severity.LOW,
                            scanner=self.name,
                            url=url,
                            evidence=f"Redirect-like parameter: {param_name}",
                            remediation=(
                                "Validate redirect URLs against a whitelist of allowed domains. "
                                "Use relative paths instead of absolute URLs for internal redirects."
                            ),
                            references=[
                                "https://cwe.mitre.org/data/definitions/601.html",
                                "https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/11-Client-side_Testing/04-Testing_for_Client-side_URL_Redirect",
                            ],
                        )
                    )

        return vulns

    async def _active_scan(self, urls: list[str]) -> list[Vulnerability]:
        """Inject redirect payloads and check if the server redirects."""
        vulns: list[Vulnerability] = []
        tested: set[str] = set()

        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query)

            for param_name in params:
                if param_name.lower() not in REDIRECT_PARAMS:
                    continue

                test_key = f"{parsed.netloc}{parsed.path}:{param_name}"
                if test_key in tested:
                    continue
                tested.add(test_key)

                test_params = dict(params)
                test_params[param_name] = [REDIRECT_PAYLOAD]
                new_query = urlencode(test_params, doseq=True)
                test_url = urlunparse(parsed._replace(query=new_query))

                try:
                    response = await self.client.get(
                        test_url, follow_redirects=False
                    )
                except Exception:
                    continue

                location = response.headers.get("location", "")
                if response.status_code in (301, 302, 303, 307, 308):
                    if "evil-attacker.com" in location:
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title=f"Confirmed Open Redirect via '{param_name}'",
                                description=(
                                    f"Parameter '{param_name}' redirects to an attacker-controlled "
                                    f"domain without validation. This can be used for phishing."
                                ),
                                severity=Severity.MEDIUM,
                                scanner=self.name,
                                url=url,
                                evidence=f"Payload: {REDIRECT_PAYLOAD} → Location: {location}",
                                remediation=(
                                    "Validate redirect targets against a whitelist. "
                                    "Reject absolute URLs pointing to external domains."
                                ),
                                references=[
                                    "https://cwe.mitre.org/data/definitions/601.html",
                                ],
                            )
                        )

        return vulns
