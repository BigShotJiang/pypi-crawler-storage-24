"""Information disclosure scanner."""

from __future__ import annotations

import re
import uuid

from bs4 import BeautifulSoup

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# Patterns that indicate leaked sensitive info in HTML
SENSITIVE_PATTERNS = [
    (
        re.compile(r"(?:password|passwd|pwd)\s*[:=]\s*['\"]?[\w!@#$%^&*]{3,}", re.IGNORECASE),
        "Hardcoded password detected in HTML",
        Severity.CRITICAL,
    ),
    (
        re.compile(r"(?:api[_-]?key|apikey)\s*[:=]\s*['\"]?[\w\-]{16,}", re.IGNORECASE),
        "API key detected in HTML",
        Severity.HIGH,
    ),
    (
        re.compile(r"(?:secret[_-]?key|secret)\s*[:=]\s*['\"]?[\w\-]{16,}", re.IGNORECASE),
        "Secret key detected in HTML",
        Severity.HIGH,
    ),
    (
        re.compile(r"(?:aws[_-]?access[_-]?key[_-]?id)\s*[:=]\s*['\"]?AK[A-Z0-9]{18}", re.IGNORECASE),
        "AWS access key detected in HTML",
        Severity.CRITICAL,
    ),
    (
        re.compile(r"(?:private[_-]?key|PRIVATE KEY)", re.IGNORECASE),
        "Private key reference detected in HTML",
        Severity.CRITICAL,
    ),
    (
        re.compile(r"(?:jdbc|mysql|postgres(?:ql)?|mongodb)://[^\s<\"']+", re.IGNORECASE),
        "Database connection string detected in HTML",
        Severity.CRITICAL,
    ),
    (
        re.compile(r"<!--[\s\S]*?(?:TODO|FIXME|HACK|BUG|XXX)[\s\S]*?-->", re.IGNORECASE),
        "Developer comment with TODO/FIXME found in HTML",
        Severity.INFO,
    ),
    (
        re.compile(r"<!--[\s\S]*?(?:password|secret|token|key|credential)[\s\S]*?-->", re.IGNORECASE),
        "HTML comment mentioning sensitive terms",
        Severity.MEDIUM,
    ),
]

# Stack trace / error patterns
ERROR_PATTERNS = [
    (
        re.compile(r"Traceback \(most recent call last\)", re.IGNORECASE),
        "Python stack trace exposed",
        Severity.MEDIUM,
    ),
    (
        re.compile(r"at\s+[\w.]+\([\w]+\.java:\d+\)", re.IGNORECASE),
        "Java stack trace exposed",
        Severity.MEDIUM,
    ),
    (
        re.compile(r"(?:Fatal error|Warning):\s+.*\bin\b\s+[\w/\\]+\.php\s+on line\s+\d+", re.IGNORECASE),
        "PHP error with file path exposed",
        Severity.MEDIUM,
    ),
    (
        re.compile(r"Microsoft OLE DB Provider|ADODB\.|System\.Data\.SqlClient", re.IGNORECASE),
        "ASP.NET/MSSQL error exposed",
        Severity.MEDIUM,
    ),
    (
        re.compile(r"(?:DEBUG|DEVELOPMENT)\s*(?:MODE|=\s*(?:true|1|on))", re.IGNORECASE),
        "Debug/development mode indicator",
        Severity.MEDIUM,
    ),
]

# Sensitive info in meta tags or inline scripts
META_PATTERNS = [
    (
        re.compile(r"<meta[^>]*name=['\"]?generator['\"]?[^>]*content=['\"]?([^'\"]+)", re.IGNORECASE),
        "Generator meta tag reveals technology",
        Severity.INFO,
    ),
]


@register_scanner
class InfoDisclosureScanner(BaseScanner):
    name = "info-disclosure"
    description = "Detects information disclosure in HTML responses (secrets, errors, stack traces)"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        seen: set[str] = set()

        for url in urls[:20]:
            try:
                response = await self.client.get(url)
            except Exception:
                continue

            if "text/html" not in response.headers.get("content-type", ""):
                continue

            body = response.text

            # Check for sensitive data patterns
            for pattern, title, severity in SENSITIVE_PATTERNS:
                match = pattern.search(body)
                if match:
                    dedup_key = f"{title}:{url}"
                    if dedup_key not in seen:
                        seen.add(dedup_key)
                        evidence = match.group(0)[:100]
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title=title,
                                description=f"Sensitive information found in the HTML response at {url}.",
                                severity=severity,
                                scanner=self.name,
                                url=url,
                                evidence=evidence,
                                remediation=(
                                    "Remove sensitive data from HTML responses. "
                                    "Never expose credentials, keys, or internal details in client-facing pages."
                                ),
                                references=["https://cwe.mitre.org/data/definitions/200.html"],
                            )
                        )

            # Check error patterns
            for pattern, title, severity in ERROR_PATTERNS:
                match = pattern.search(body)
                if match:
                    dedup_key = f"{title}:{url}"
                    if dedup_key not in seen:
                        seen.add(dedup_key)
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title=title,
                                description=(
                                    f"Error information or stack trace found at {url}. "
                                    f"This reveals internal application details to attackers."
                                ),
                                severity=severity,
                                scanner=self.name,
                                url=url,
                                evidence=match.group(0)[:150],
                                remediation=(
                                    "Disable debug mode in production. Use custom error pages. "
                                    "Never expose stack traces or internal paths to users."
                                ),
                                references=["https://cwe.mitre.org/data/definitions/209.html"],
                            )
                        )

            # Check meta tags
            for pattern, title, severity in META_PATTERNS:
                match = pattern.search(body)
                if match:
                    dedup_key = f"{title}:{url}"
                    if dedup_key not in seen:
                        seen.add(dedup_key)
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title=title,
                                description=f"Technology information disclosed via meta tag at {url}.",
                                severity=severity,
                                scanner=self.name,
                                url=url,
                                evidence=match.group(0)[:100],
                                remediation="Remove generator and version meta tags from production HTML.",
                                references=["https://cwe.mitre.org/data/definitions/200.html"],
                            )
                        )

        return vulns
