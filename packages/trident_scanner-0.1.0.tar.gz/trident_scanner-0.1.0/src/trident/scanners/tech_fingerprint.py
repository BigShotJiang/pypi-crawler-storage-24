"""Technology fingerprinting scanner."""

from __future__ import annotations

import re
import uuid

from bs4 import BeautifulSoup

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# Header-based technology detection
HEADER_FINGERPRINTS: list[tuple[str, str, re.Pattern[str]]] = [
    ("X-Powered-By", "Technology", re.compile(r"(.+)")),
    ("Server", "Web Server", re.compile(r"(.+)")),
    ("X-AspNet-Version", "ASP.NET", re.compile(r"(.+)")),
    ("X-AspNetMvc-Version", "ASP.NET MVC", re.compile(r"(.+)")),
    ("X-Drupal-Cache", "Drupal", re.compile(r"(.+)")),
    ("X-Generator", "CMS", re.compile(r"(.+)")),
    ("X-Shopify-Stage", "Shopify", re.compile(r"(.+)")),
    ("X-Varnish", "Varnish Cache", re.compile(r"(.+)")),
    ("Via", "Proxy/CDN", re.compile(r".*(cloudfront|akamai|fastly|cloudflare|varnish).*", re.I)),
    ("CF-RAY", "Cloudflare", re.compile(r"(.+)")),
    ("X-Cache", "CDN Cache", re.compile(r"(.+)")),
]

# HTML-based technology detection
HTML_FINGERPRINTS: list[tuple[str, re.Pattern[str], str]] = [
    ("WordPress", re.compile(r'/wp-content/|/wp-includes/|wp-json', re.I), "CMS"),
    ("Drupal", re.compile(r'Drupal\.settings|/sites/default/files', re.I), "CMS"),
    ("Joomla", re.compile(r'/media/jui/|/templates/|com_content', re.I), "CMS"),
    ("React", re.compile(r'react\.production\.min\.js|__NEXT_DATA__|_next/static|reactroot', re.I), "Frontend Framework"),
    ("Next.js", re.compile(r'__NEXT_DATA__|_next/static', re.I), "Frontend Framework"),
    ("Vue.js", re.compile(r'vue\.min\.js|vue\.runtime|v-cloak|nuxt', re.I), "Frontend Framework"),
    ("Angular", re.compile(r'ng-version|angular\.min\.js|ng-app', re.I), "Frontend Framework"),
    ("jQuery", re.compile(r'jquery[.-][\d.]+\.(?:min\.)?js', re.I), "JavaScript Library"),
    ("Bootstrap", re.compile(r'bootstrap[.-][\d.]+\.(?:min\.)?(?:css|js)', re.I), "CSS Framework"),
    ("Tailwind CSS", re.compile(r'tailwindcss|tailwind\.min\.css', re.I), "CSS Framework"),
    ("Google Analytics", re.compile(r'google-analytics\.com/|gtag/js\?id=|googletagmanager\.com', re.I), "Analytics"),
    ("Google Tag Manager", re.compile(r'googletagmanager\.com/gtm', re.I), "Analytics"),
    ("reCAPTCHA", re.compile(r'google\.com/recaptcha|recaptcha/api', re.I), "Security"),
    ("Stripe", re.compile(r'js\.stripe\.com', re.I), "Payment"),
    ("Laravel", re.compile(r'laravel_session|csrf-token.*content', re.I), "Backend Framework"),
    ("Django", re.compile(r'csrfmiddlewaretoken|__admin_media_prefix__', re.I), "Backend Framework"),
    ("Ruby on Rails", re.compile(r'csrf-token.*authenticity_token|turbolinks', re.I), "Backend Framework"),
    ("ASP.NET", re.compile(r'__VIEWSTATE|__EVENTVALIDATION|aspnetForm', re.I), "Backend Framework"),
    ("Spring", re.compile(r'_csrf.*org\.springframework', re.I), "Backend Framework"),
]

# Cookie-based detection
COOKIE_FINGERPRINTS: list[tuple[str, re.Pattern[str]]] = [
    ("PHP (PHPSESSID)", re.compile(r"PHPSESSID", re.I)),
    ("ASP.NET (ASP.NET_SessionId)", re.compile(r"ASP\.NET_SessionId", re.I)),
    ("Java (JSESSIONID)", re.compile(r"JSESSIONID", re.I)),
    ("Django (csrftoken)", re.compile(r"csrftoken", re.I)),
    ("Laravel (laravel_session)", re.compile(r"laravel_session", re.I)),
    ("Rails (_session_id)", re.compile(r"_.*_session", re.I)),
    ("Express (connect.sid)", re.compile(r"connect\.sid", re.I)),
    ("Cloudflare (__cfduid)", re.compile(r"__cf", re.I)),
]


@register_scanner
class TechFingerprintScanner(BaseScanner):
    name = "tech-fingerprint"
    description = "Identifies technologies, frameworks, and libraries used by the target"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        detected: set[str] = set()

        url = self.target.url
        try:
            response = await self.client.get(url)
        except Exception:
            return vulns

        # Header-based detection
        for header_name, tech_type, pattern in HEADER_FINGERPRINTS:
            value = response.headers.get(header_name, "")
            if value:
                match = pattern.search(value)
                if match:
                    tech = f"{tech_type}: {value}"
                    if tech not in detected:
                        detected.add(tech)
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title=f"Technology Detected: {tech_type}",
                                description=f"The '{header_name}' header reveals: {value}",
                                severity=Severity.INFO,
                                scanner=self.name,
                                url=url,
                                evidence=f"{header_name}: {value}",
                                remediation=f"Consider removing or obscuring the '{header_name}' header.",
                                references=["https://cwe.mitre.org/data/definitions/200.html"],
                            )
                        )

        # HTML-based detection
        body = response.text
        for tech_name, pattern, tech_type in HTML_FINGERPRINTS:
            if pattern.search(body) and tech_name not in detected:
                detected.add(tech_name)
                vulns.append(
                    Vulnerability(
                        id=uuid.uuid4().hex[:12],
                        title=f"Technology Detected: {tech_name}",
                        description=f"{tech_type} '{tech_name}' detected in HTML/JavaScript sources.",
                        severity=Severity.INFO,
                        scanner=self.name,
                        url=url,
                        evidence=f"Pattern match for {tech_name}",
                        remediation="Technology disclosure is informational. Review if versions are exposed.",
                        references=[],
                    )
                )

        # Meta generator tag
        soup = BeautifulSoup(body, "lxml")
        gen = soup.find("meta", attrs={"name": "generator"})
        if gen and gen.get("content"):
            content = gen["content"]
            if content not in detected:
                detected.add(content)
                vulns.append(
                    Vulnerability(
                        id=uuid.uuid4().hex[:12],
                        title=f"Generator Meta Tag: {content}",
                        description=f"Meta generator tag reveals: {content}",
                        severity=Severity.INFO,
                        scanner=self.name,
                        url=url,
                        evidence=f'<meta name="generator" content="{content}">',
                        remediation="Remove the generator meta tag from production HTML.",
                        references=["https://cwe.mitre.org/data/definitions/200.html"],
                    )
                )

        # Cookie-based detection
        raw_headers = response.headers.multi_items() if hasattr(
            response.headers, "multi_items"
        ) else list(response.headers.items())

        cookie_names = [
            v.split("=")[0].strip()
            for k, v in raw_headers
            if k.lower() == "set-cookie"
        ]
        all_cookies = " ".join(cookie_names)

        for tech_name, pattern in COOKIE_FINGERPRINTS:
            if pattern.search(all_cookies) and tech_name not in detected:
                detected.add(tech_name)
                vulns.append(
                    Vulnerability(
                        id=uuid.uuid4().hex[:12],
                        title=f"Technology Detected: {tech_name}",
                        description=f"Cookie name pattern reveals {tech_name}.",
                        severity=Severity.INFO,
                        scanner=self.name,
                        url=url,
                        evidence=f"Cookie pattern: {pattern.pattern}",
                        remediation="Rename session cookies to generic names to reduce fingerprinting.",
                        references=["https://cwe.mitre.org/data/definitions/200.html"],
                    )
                )

        return vulns
