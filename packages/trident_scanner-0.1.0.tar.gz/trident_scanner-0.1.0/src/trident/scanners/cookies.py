"""Cookie security scanner."""

from __future__ import annotations

import uuid

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner


@register_scanner
class CookieScanner(BaseScanner):
    name = "cookies"
    description = "Checks cookie security attributes (Secure, HttpOnly, SameSite)"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        checked_cookies: set[str] = set()

        urls_to_check = urls[:10]

        for url in urls_to_check:
            try:
                response = await self.client.get(url)
            except Exception:
                continue

            raw_headers = response.headers.multi_items() if hasattr(
                response.headers, "multi_items"
            ) else list(response.headers.items())

            for header_name, header_value in raw_headers:
                if header_name.lower() != "set-cookie":
                    continue

                cookie_name = header_value.split("=")[0].strip()
                if cookie_name in checked_cookies:
                    continue
                checked_cookies.add(cookie_name)

                lower_val = header_value.lower()

                # Check Secure flag
                if "secure" not in lower_val:
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Cookie '{cookie_name}' Missing Secure Flag",
                            description=(
                                f"Cookie '{cookie_name}' is not marked Secure. "
                                f"It will be sent over unencrypted HTTP connections."
                            ),
                            severity=Severity.MEDIUM,
                            scanner=self.name,
                            url=url,
                            evidence=f"Set-Cookie: {header_value[:100]}",
                            remediation="Add the Secure attribute to all cookies.",
                            references=["https://cwe.mitre.org/data/definitions/614.html"],
                        )
                    )

                # Check HttpOnly flag
                if "httponly" not in lower_val:
                    is_session = any(
                        kw in cookie_name.lower()
                        for kw in ("session", "sess", "sid", "token", "auth", "jwt")
                    )
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Cookie '{cookie_name}' Missing HttpOnly Flag",
                            description=(
                                f"Cookie '{cookie_name}' is not marked HttpOnly. "
                                f"JavaScript can access it, enabling theft via XSS."
                            ),
                            severity=Severity.HIGH if is_session else Severity.LOW,
                            scanner=self.name,
                            url=url,
                            evidence=f"Set-Cookie: {header_value[:100]}",
                            remediation="Add the HttpOnly attribute, especially for session cookies.",
                            references=["https://cwe.mitre.org/data/definitions/1004.html"],
                        )
                    )

                # Check SameSite
                if "samesite" not in lower_val:
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Cookie '{cookie_name}' Missing SameSite Attribute",
                            description=(
                                f"Cookie '{cookie_name}' has no SameSite attribute. "
                                f"It may be sent in cross-site requests, enabling CSRF."
                            ),
                            severity=Severity.LOW,
                            scanner=self.name,
                            url=url,
                            evidence=f"Set-Cookie: {header_value[:100]}",
                            remediation="Set SameSite=Lax or SameSite=Strict on all cookies.",
                            references=["https://cwe.mitre.org/data/definitions/1275.html"],
                        )
                    )

                # Check SameSite=None without Secure
                if "samesite=none" in lower_val and "secure" not in lower_val:
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Cookie '{cookie_name}' SameSite=None Without Secure",
                            description=(
                                f"Cookie '{cookie_name}' has SameSite=None but no Secure flag. "
                                f"Browsers will reject this cookie."
                            ),
                            severity=Severity.MEDIUM,
                            scanner=self.name,
                            url=url,
                            evidence=f"Set-Cookie: {header_value[:100]}",
                            remediation="SameSite=None requires the Secure attribute.",
                            references=["https://cwe.mitre.org/data/definitions/614.html"],
                        )
                    )

        return vulns
