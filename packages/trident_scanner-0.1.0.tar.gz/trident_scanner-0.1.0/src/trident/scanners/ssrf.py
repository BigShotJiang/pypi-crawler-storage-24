"""Server-Side Request Forgery (SSRF) scanner."""

from __future__ import annotations

import uuid
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# Parameters commonly used for SSRF
SSRF_PARAMS = {
    "url", "uri", "path", "src", "source", "href", "link", "file", "filename",
    "page", "feed", "host", "site", "proxy", "callback", "api", "endpoint",
    "fetch", "load", "image", "img", "icon", "preview", "pdf", "resource",
}

# Payloads targeting internal services
SSRF_PAYLOADS = [
    ("http://127.0.0.1/", "localhost"),
    ("http://localhost/", "localhost"),
    ("http://[::1]/", "IPv6 localhost"),
    ("http://169.254.169.254/latest/meta-data/", "AWS metadata"),
    ("http://metadata.google.internal/", "GCP metadata"),
    ("http://100.100.100.200/latest/meta-data/", "Alibaba metadata"),
]

# Response patterns indicating SSRF success
SSRF_INDICATORS = [
    "ami-id",           # AWS metadata
    "instance-id",      # AWS metadata
    "local-hostname",   # AWS metadata
    "computeMetadata",  # GCP metadata
    "access-key",       # Cloud metadata
    "127.0.0.1",        # Localhost response leak
    "root:x:0:0",       # /etc/passwd
]


@register_scanner
class SSRFScanner(BaseScanner):
    name = "ssrf"
    description = "Detects Server-Side Request Forgery via URL parameter injection"
    requires_serial = True

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []

        if not self.target.active_mode:
            # Passive: flag URLs with SSRF-prone params
            vulns.extend(self._passive_scan(urls))
        else:
            vulns.extend(await self._active_scan(urls))

        return vulns

    def _passive_scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        found_params: set[str] = set()

        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query)

            for param_name in params:
                if param_name.lower() in SSRF_PARAMS and param_name not in found_params:
                    found_params.add(param_name)

                    # Check if the value looks like a URL
                    for val in params[param_name]:
                        if val.startswith(("http://", "https://", "//")):
                            vulns.append(
                                Vulnerability(
                                    id=uuid.uuid4().hex[:12],
                                    title=f"Potential SSRF via '{param_name}'",
                                    description=(
                                        f"Parameter '{param_name}' accepts URL values, which may allow "
                                        f"server-side request forgery. Enable active mode to test."
                                    ),
                                    severity=Severity.MEDIUM,
                                    scanner=self.name,
                                    url=url,
                                    evidence=f"Parameter '{param_name}' contains URL: {val[:80]}",
                                    remediation=(
                                        "Validate and whitelist allowed URLs/domains. "
                                        "Block requests to internal/private IP ranges. "
                                        "Use an allowlist instead of a blocklist."
                                    ),
                                    references=[
                                        "https://cwe.mitre.org/data/definitions/918.html",
                                        "https://owasp.org/www-community/attacks/Server_Side_Request_Forgery",
                                    ],
                                )
                            )
                            break

        return vulns

    async def _active_scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        tested: set[str] = set()

        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query)

            for param_name in params:
                if param_name.lower() not in SSRF_PARAMS:
                    continue

                test_key = f"{parsed.netloc}{parsed.path}:{param_name}"
                if test_key in tested:
                    continue
                tested.add(test_key)

                for payload, label in SSRF_PAYLOADS:
                    test_params = dict(params)
                    test_params[param_name] = [payload]
                    new_query = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=new_query))

                    try:
                        response = await self.client.get(test_url)
                    except Exception:
                        continue

                    body = response.text.lower()
                    for indicator in SSRF_INDICATORS:
                        if indicator.lower() in body:
                            vulns.append(
                                Vulnerability(
                                    id=uuid.uuid4().hex[:12],
                                    title=f"SSRF Confirmed via '{param_name}' ({label})",
                                    description=(
                                        f"Parameter '{param_name}' is vulnerable to SSRF. "
                                        f"The server fetched an internal resource ({label}) "
                                        f"and returned indicative content."
                                    ),
                                    severity=Severity.CRITICAL,
                                    scanner=self.name,
                                    url=url,
                                    evidence=f"Payload: {payload} | Indicator: {indicator}",
                                    remediation=(
                                        "Block requests to internal/private IPs and cloud metadata endpoints. "
                                        "Whitelist allowed external domains. Use network-level egress filtering."
                                    ),
                                    references=[
                                        "https://cwe.mitre.org/data/definitions/918.html",
                                    ],
                                )
                            )
                            return vulns  # Critical — stop immediately

        return vulns
