"""CORS misconfiguration scanner."""

from __future__ import annotations

import uuid

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner


@register_scanner
class CORSScanner(BaseScanner):
    name = "cors"
    description = "Detects Cross-Origin Resource Sharing misconfigurations"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        checked: set[str] = set()

        urls_to_check = urls[:10]

        for url in urls_to_check:
            if url in checked:
                continue
            checked.add(url)

            # Test 1: Reflect arbitrary origin
            try:
                response = await self.client.get(
                    url, headers={"Origin": "https://evil-attacker.com"}
                )
            except Exception:
                continue

            acao = response.headers.get("access-control-allow-origin", "")
            acac = response.headers.get("access-control-allow-credentials", "")

            if acao == "https://evil-attacker.com":
                severity = Severity.HIGH if acac.lower() == "true" else Severity.MEDIUM
                vulns.append(
                    Vulnerability(
                        id=uuid.uuid4().hex[:12],
                        title="CORS: Arbitrary Origin Reflected",
                        description=(
                            "The server reflects any Origin header in Access-Control-Allow-Origin. "
                            + ("Combined with Allow-Credentials: true, this allows credential theft."
                               if acac.lower() == "true"
                               else "An attacker's site can read responses cross-origin.")
                        ),
                        severity=severity,
                        scanner=self.name,
                        url=url,
                        evidence=f"Origin: https://evil-attacker.com → ACAO: {acao}, ACAC: {acac}",
                        remediation=(
                            "Whitelist specific trusted origins instead of reflecting the Origin header. "
                            "Never combine a reflected origin with Access-Control-Allow-Credentials: true."
                        ),
                        references=[
                            "https://cwe.mitre.org/data/definitions/942.html",
                            "https://owasp.org/www-community/attacks/CORS_OriginHeaderScrutiny",
                        ],
                    )
                )
                continue

            # Test 2: Wildcard with credentials
            if acao == "*" and acac.lower() == "true":
                vulns.append(
                    Vulnerability(
                        id=uuid.uuid4().hex[:12],
                        title="CORS: Wildcard Origin with Credentials",
                        description=(
                            "The server sets Access-Control-Allow-Origin: * with "
                            "Access-Control-Allow-Credentials: true. While browsers block this, "
                            "it indicates a misconfigured CORS policy."
                        ),
                        severity=Severity.MEDIUM,
                        scanner=self.name,
                        url=url,
                        evidence=f"ACAO: {acao}, ACAC: {acac}",
                        remediation="Use specific origins instead of wildcard when credentials are needed.",
                        references=["https://cwe.mitre.org/data/definitions/942.html"],
                    )
                )
                continue

            # Test 3: Null origin accepted
            try:
                response = await self.client.get(url, headers={"Origin": "null"})
            except Exception:
                continue

            acao = response.headers.get("access-control-allow-origin", "")
            if acao == "null":
                vulns.append(
                    Vulnerability(
                        id=uuid.uuid4().hex[:12],
                        title="CORS: Null Origin Accepted",
                        description=(
                            "The server accepts 'null' as a valid origin. Sandboxed iframes and "
                            "redirects send Origin: null, allowing potential bypass."
                        ),
                        severity=Severity.MEDIUM,
                        scanner=self.name,
                        url=url,
                        evidence=f"Origin: null → ACAO: {acao}",
                        remediation="Do not whitelist 'null' as a valid origin.",
                        references=["https://cwe.mitre.org/data/definitions/942.html"],
                    )
                )

        return vulns
