"""SQL Injection scanner."""

from __future__ import annotations

import re
import uuid
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# SQL error patterns that indicate injection vulnerability
SQL_ERROR_PATTERNS = [
    re.compile(r"you have an error in your sql syntax", re.IGNORECASE),
    re.compile(r"warning.*mysql_", re.IGNORECASE),
    re.compile(r"unclosed quotation mark", re.IGNORECASE),
    re.compile(r"microsoft ole db provider for sql server", re.IGNORECASE),
    re.compile(r"postgresql.*error", re.IGNORECASE),
    re.compile(r"sqlite3\.OperationalError", re.IGNORECASE),
    re.compile(r"ORA-\d{5}", re.IGNORECASE),
    re.compile(r"pg_query\(\)", re.IGNORECASE),
    re.compile(r"unterminated quoted string", re.IGNORECASE),
    re.compile(r"syntax error at or near", re.IGNORECASE),
    re.compile(r"quoted string not properly terminated", re.IGNORECASE),
    re.compile(r"SQL syntax.*MySQL", re.IGNORECASE),
    re.compile(r"valid MySQL result", re.IGNORECASE),
    re.compile(r"MySqlClient\.", re.IGNORECASE),
    re.compile(r"com\.mysql\.jdbc", re.IGNORECASE),
]

# Payloads designed to trigger SQL errors without causing damage
SQLI_PROBES = [
    "'",
    "''",
    "' OR '1'='1",
    "1' ORDER BY 1--",
    "1 AND 1=1",
    "' AND ''='",
    "1; SELECT 1",
]


@register_scanner
class SQLiScanner(BaseScanner):
    name = "sqli"
    description = "Detects SQL Injection vulnerabilities via error-based detection"
    requires_serial = True

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []

        if not self.target.active_mode:
            return vulns  # SQLi detection requires active probing

        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query)

            if not params:
                continue

            for param_name in params:
                # Get baseline response
                try:
                    baseline = await self.client.get(url)
                except Exception:
                    continue

                for probe in SQLI_PROBES:
                    test_params = dict(params)
                    test_params[param_name] = [probe]
                    new_query = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=new_query))

                    try:
                        response = await self.client.get(test_url)
                    except Exception:
                        continue

                    # Check for SQL error messages in response
                    for pattern in SQL_ERROR_PATTERNS:
                        if pattern.search(response.text) and not pattern.search(baseline.text):
                            vulns.append(
                                Vulnerability(
                                    id=uuid.uuid4().hex[:12],
                                    title=f"SQL Injection in '{param_name}'",
                                    description=(
                                        f"Parameter '{param_name}' appears vulnerable to SQL injection. "
                                        f"A SQL error message was returned when injecting a probe payload."
                                    ),
                                    severity=Severity.CRITICAL,
                                    scanner=self.name,
                                    url=url,
                                    evidence=f"Payload: {probe} | Error pattern: {pattern.pattern}",
                                    remediation=(
                                        "Use parameterized queries / prepared statements. "
                                        "Never concatenate user input into SQL strings. "
                                        "Implement input validation and WAF rules."
                                    ),
                                    references=[
                                        "https://cwe.mitre.org/data/definitions/89.html",
                                        "https://owasp.org/www-community/attacks/SQL_Injection",
                                    ],
                                )
                            )
                            # Found SQLi for this param, stop probing it
                            break
                    else:
                        continue
                    break  # Break outer probe loop too

        return vulns
