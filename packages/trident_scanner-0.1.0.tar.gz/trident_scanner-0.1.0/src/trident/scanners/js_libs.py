"""JavaScript library vulnerability scanner — detects outdated frontend libraries."""

from __future__ import annotations

import re
import uuid
from urllib.parse import urljoin

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# Known vulnerable library versions (pattern → min safe version, CVE info)
VULNERABLE_LIBS: list[tuple[str, re.Pattern[str], str, str, Severity, str]] = [
    (
        "jQuery",
        re.compile(r"jquery[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I),
        "3.5.0",
        "jQuery < 3.5.0 is vulnerable to XSS (CVE-2020-11023, CVE-2020-11022)",
        Severity.MEDIUM,
        "https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2020-11023",
    ),
    (
        "Angular.js",
        re.compile(r"angular[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I),
        "1.8.0",
        "AngularJS 1.x is end-of-life and has known XSS vulnerabilities",
        Severity.HIGH,
        "https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-25869",
    ),
    (
        "Bootstrap",
        re.compile(r"bootstrap[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I),
        "3.4.1",
        "Bootstrap < 3.4.1 is vulnerable to XSS via data attributes",
        Severity.MEDIUM,
        "https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2019-8331",
    ),
    (
        "Lodash",
        re.compile(r"lodash[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I),
        "4.17.21",
        "Lodash < 4.17.21 has prototype pollution vulnerabilities",
        Severity.HIGH,
        "https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-23337",
    ),
    (
        "Moment.js",
        re.compile(r"moment[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I),
        "2.29.4",
        "Moment.js < 2.29.4 has ReDoS vulnerability; project is now deprecated",
        Severity.LOW,
        "https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-31129",
    ),
    (
        "Vue.js",
        re.compile(r"vue[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I),
        "2.7.0",
        "Vue.js < 2.7.0 has XSS vulnerabilities in certain template expressions",
        Severity.MEDIUM,
        "https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2024-6783",
    ),
    (
        "React",
        re.compile(r"react[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I),
        "16.13.0",
        "React < 16.13.0 has potential XSS via dangerouslySetInnerHTML edge cases",
        Severity.LOW,
        "https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2020-7919",
    ),
    (
        "DOMPurify",
        re.compile(r"dompurify[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I),
        "2.4.0",
        "DOMPurify < 2.4.0 has mXSS bypass vulnerabilities",
        Severity.HIGH,
        "https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-25890",
    ),
]


def _version_lt(v1: str, v2: str) -> bool:
    """Compare version strings. Returns True if v1 < v2."""
    try:
        parts1 = [int(x) for x in v1.split(".")]
        parts2 = [int(x) for x in v2.split(".")]
        for a, b in zip(parts1, parts2):
            if a < b:
                return True
            if a > b:
                return False
        return len(parts1) < len(parts2)
    except (ValueError, AttributeError):
        return False


@register_scanner
class JSLibScanner(BaseScanner):
    name = "js-libs"
    description = "Detects outdated JavaScript libraries with known CVEs"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        seen: set[str] = set()

        # Collect all text to scan (HTML pages + JS files)
        all_text: list[tuple[str, str]] = []

        for url in urls[:10]:
            try:
                resp = await self.client.get(url)
            except Exception:
                continue

            all_text.append((url, resp.text))

            # Extract JS file URLs
            js_urls = re.findall(
                r'(?:src|href)\s*=\s*["\']([^"\']*\.js(?:\?[^"\']*)?)["\']',
                resp.text,
            )
            for js_url in js_urls[:20]:
                if js_url.startswith("//"):
                    js_url = "https:" + js_url
                elif not js_url.startswith("http"):
                    js_url = urljoin(url, js_url)

                try:
                    js_resp = await self.client.get(js_url)
                    # Only scan first 5KB for version strings (they're in headers/comments)
                    all_text.append((js_url, js_resp.text[:5000]))
                except Exception:
                    continue

        # Scan all collected text for vulnerable library versions
        for source_url, text in all_text:
            for lib_name, pattern, safe_version, description, severity, cve_url in VULNERABLE_LIBS:
                for match in pattern.finditer(text):
                    version = match.group(1)
                    dedup = f"{lib_name}:{version}"
                    if dedup in seen:
                        continue

                    if _version_lt(version, safe_version):
                        seen.add(dedup)
                        vulns.append(
                            Vulnerability(
                                id=uuid.uuid4().hex[:12],
                                title=f"Vulnerable {lib_name} v{version}",
                                description=description,
                                severity=severity,
                                scanner=self.name,
                                url=source_url,
                                evidence=f"{lib_name} {version} (safe: >= {safe_version})",
                                remediation=f"Update {lib_name} to version {safe_version} or later.",
                                references=[cve_url],
                            )
                        )

        return vulns
