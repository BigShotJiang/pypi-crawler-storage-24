"""Directory and sensitive file enumeration scanner."""

from __future__ import annotations

import asyncio
import uuid
from urllib.parse import urljoin

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# Common sensitive paths to probe
SENSITIVE_PATHS = [
    # Version control
    ("/.git/HEAD", "Git repository exposed", Severity.CRITICAL),
    ("/.svn/entries", "SVN repository exposed", Severity.CRITICAL),
    ("/.hg/store", "Mercurial repository exposed", Severity.CRITICAL),
    # Configuration files
    ("/.env", "Environment file exposed (may contain secrets)", Severity.CRITICAL),
    ("/.env.local", "Local environment file exposed", Severity.CRITICAL),
    ("/.env.production", "Production environment file exposed", Severity.CRITICAL),
    ("/config.yml", "Configuration file exposed", Severity.HIGH),
    ("/config.yaml", "Configuration file exposed", Severity.HIGH),
    ("/config.json", "Configuration file exposed", Severity.HIGH),
    ("/wp-config.php.bak", "WordPress config backup exposed", Severity.CRITICAL),
    # Backups
    ("/backup.sql", "SQL backup file exposed", Severity.CRITICAL),
    ("/database.sql", "SQL dump exposed", Severity.CRITICAL),
    ("/db.sql", "SQL dump exposed", Severity.CRITICAL),
    ("/backup.zip", "Backup archive exposed", Severity.HIGH),
    ("/backup.tar.gz", "Backup archive exposed", Severity.HIGH),
    # Debug / admin
    ("/debug", "Debug endpoint exposed", Severity.MEDIUM),
    ("/server-status", "Apache server-status exposed", Severity.MEDIUM),
    ("/server-info", "Apache server-info exposed", Severity.MEDIUM),
    ("/phpinfo.php", "PHP info page exposed", Severity.MEDIUM),
    ("/info.php", "PHP info page exposed", Severity.MEDIUM),
    ("/elmah.axd", "ELMAH error log exposed", Severity.HIGH),
    ("/trace.axd", "ASP.NET trace exposed", Severity.HIGH),
    # API docs
    ("/swagger.json", "Swagger API spec exposed", Severity.LOW),
    ("/openapi.json", "OpenAPI spec exposed", Severity.LOW),
    ("/api-docs", "API documentation exposed", Severity.LOW),
    ("/graphql", "GraphQL endpoint (may allow introspection)", Severity.LOW),
    # Admin panels
    ("/admin", "Admin panel found", Severity.INFO),
    ("/administrator", "Admin panel found", Severity.INFO),
    ("/wp-admin", "WordPress admin found", Severity.INFO),
    ("/wp-login.php", "WordPress login found", Severity.INFO),
    # Package files
    ("/package.json", "Node.js package manifest exposed", Severity.LOW),
    ("/composer.json", "PHP Composer manifest exposed", Severity.LOW),
    ("/Gemfile", "Ruby Gemfile exposed", Severity.LOW),
    ("/requirements.txt", "Python requirements exposed", Severity.LOW),
    # Other
    ("/robots.txt", "Robots.txt found (may reveal hidden paths)", Severity.INFO),
    ("/sitemap.xml", "Sitemap found", Severity.INFO),
    ("/.well-known/security.txt", "Security policy found", Severity.INFO),
    ("/.DS_Store", "macOS metadata file exposed", Severity.LOW),
    ("/crossdomain.xml", "Flash crossdomain policy found", Severity.LOW),
    ("/clientaccesspolicy.xml", "Silverlight access policy found", Severity.LOW),
]


@register_scanner
class DirectoryEnumScanner(BaseScanner):
    name = "dir-enum"
    description = "Enumerates sensitive files and directories"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        base_url = self.target.url.rstrip("/")

        semaphore = asyncio.Semaphore(5)

        async def check_path(path: str, desc: str, severity: Severity) -> Vulnerability | None:
            url = urljoin(base_url, path)
            async with semaphore:
                try:
                    response = await self.client.get(url, follow_redirects=False)
                except Exception:
                    return None

            if response.status_code == 200:
                # Verify it's not a custom 404
                content_length = len(response.content)
                if content_length < 5:
                    return None

                return Vulnerability(
                    id=uuid.uuid4().hex[:12],
                    title=f"Sensitive Path: {path}",
                    description=desc,
                    severity=severity,
                    scanner=self.name,
                    url=url,
                    evidence=f"HTTP {response.status_code}, {content_length} bytes",
                    remediation=(
                        "Remove or restrict access to this path. "
                        "Use .htaccess, nginx rules, or firewall to block sensitive files."
                    ),
                    references=["https://cwe.mitre.org/data/definitions/538.html"],
                )
            return None

        tasks = [check_path(path, desc, sev) for path, desc, sev in SENSITIVE_PATHS]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, Vulnerability):
                vulns.append(result)

        return vulns
