"""Security headers scanner."""

from __future__ import annotations

import uuid

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# Headers that should be present for security
EXPECTED_HEADERS = {
    "Strict-Transport-Security": {
        "severity": Severity.HIGH,
        "description": "Missing HSTS header. The site does not enforce HTTPS connections.",
        "remediation": "Add 'Strict-Transport-Security: max-age=31536000; includeSubDomains' header.",
        "references": ["https://cwe.mitre.org/data/definitions/319.html"],
    },
    "Content-Security-Policy": {
        "severity": Severity.MEDIUM,
        "description": "Missing Content-Security-Policy header. The site is more vulnerable to XSS attacks.",
        "remediation": "Implement a Content-Security-Policy header with appropriate directives.",
        "references": ["https://cwe.mitre.org/data/definitions/79.html"],
    },
    "X-Content-Type-Options": {
        "severity": Severity.LOW,
        "description": "Missing X-Content-Type-Options header. Browser may MIME-sniff responses.",
        "remediation": "Add 'X-Content-Type-Options: nosniff' header.",
        "references": ["https://cwe.mitre.org/data/definitions/16.html"],
    },
    "X-Frame-Options": {
        "severity": Severity.MEDIUM,
        "description": "Missing X-Frame-Options header. The site may be vulnerable to clickjacking.",
        "remediation": "Add 'X-Frame-Options: DENY' or 'X-Frame-Options: SAMEORIGIN' header.",
        "references": ["https://cwe.mitre.org/data/definitions/1021.html"],
    },
    "Referrer-Policy": {
        "severity": Severity.LOW,
        "description": "Missing Referrer-Policy header. Referrer information may leak to third parties.",
        "remediation": "Add 'Referrer-Policy: strict-origin-when-cross-origin' header.",
        "references": ["https://cwe.mitre.org/data/definitions/200.html"],
    },
    "Permissions-Policy": {
        "severity": Severity.LOW,
        "description": "Missing Permissions-Policy header. Browser features are not restricted.",
        "remediation": "Add a Permissions-Policy header to restrict unnecessary browser features.",
        "references": [],
    },
}

# Headers that should NOT be present (information disclosure)
UNWANTED_HEADERS = {
    "Server": {
        "severity": Severity.INFO,
        "description": "Server header reveals web server software and version.",
        "remediation": "Remove or genericize the Server header to prevent information disclosure.",
    },
    "X-Powered-By": {
        "severity": Severity.LOW,
        "description": "X-Powered-By header reveals technology stack.",
        "remediation": "Remove the X-Powered-By header.",
    },
    "X-AspNet-Version": {
        "severity": Severity.LOW,
        "description": "X-AspNet-Version header reveals ASP.NET version.",
        "remediation": "Remove the X-AspNet-Version header.",
    },
}


@register_scanner
class HeadersScanner(BaseScanner):
    name = "headers"
    description = "Checks for missing or insecure HTTP security headers"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []

        # Only need to check the main URL and a few pages
        urls_to_check = urls[:5]

        for url in urls_to_check:
            try:
                response = await self.client.get(url)
            except Exception:
                continue

            headers = response.headers

            # Check for missing security headers
            for header_name, info in EXPECTED_HEADERS.items():
                if header_name.lower() not in {k.lower() for k in headers.keys()}:
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Missing {header_name} Header",
                            description=info["description"],
                            severity=info["severity"],
                            scanner=self.name,
                            url=url,
                            remediation=info["remediation"],
                            references=info.get("references", []),
                        )
                    )

            # Check for unwanted headers
            for header_name, info in UNWANTED_HEADERS.items():
                if header_name.lower() in {k.lower() for k in headers.keys()}:
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Information Disclosure: {header_name}",
                            description=info["description"],
                            severity=info["severity"],
                            scanner=self.name,
                            url=url,
                            evidence=f"{header_name}: {headers.get(header_name, '')}",
                            remediation=info["remediation"],
                        )
                    )

            # Only report once per finding type — dedup across URLs
            break

        return vulns
