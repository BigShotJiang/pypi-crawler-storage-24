"""GraphQL security scanner."""

from __future__ import annotations

import json
import uuid
from urllib.parse import urljoin

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

GRAPHQL_PATHS = ["/graphql", "/graphiql", "/gql", "/query", "/api/graphql", "/v1/graphql"]

INTROSPECTION_QUERY = """
query IntrospectionQuery {
  __schema {
    types { name kind }
    queryType { name }
    mutationType { name }
  }
}
"""

# Field suggestion probe — triggers suggestions that reveal schema
FIELD_SUGGESTION_QUERY = """
query { __typ }
"""

# Batching attack probe
BATCH_QUERY = [
    {"query": "query { __typename }"},
    {"query": "query { __typename }"},
    {"query": "query { __typename }"},
]

# Alias-based DoS probe
ALIAS_QUERY = """
query {
  %s
}
""" % "\n  ".join(f"a{i}: __typename" for i in range(50))

# Directive overloading probe
DIRECTIVE_QUERY = "query { __typename " + "@aa " * 50 + "}"


@register_scanner
class GraphQLScanner(BaseScanner):
    name = "graphql"
    description = "Detects GraphQL misconfigurations (introspection, batching, DoS vectors)"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []

        # Find GraphQL endpoint
        endpoint = await self._find_endpoint()
        if not endpoint:
            return vulns

        vulns.append(
            Vulnerability(
                id=uuid.uuid4().hex[:12],
                title="GraphQL Endpoint Discovered",
                description=f"GraphQL endpoint found at {endpoint}.",
                severity=Severity.INFO,
                scanner=self.name,
                url=endpoint,
                remediation="Ensure GraphQL endpoint is properly secured with authentication and rate limiting.",
                references=["https://owasp.org/API-Security/"],
            )
        )

        # Test introspection
        vuln = await self._test_introspection(endpoint)
        if vuln:
            vulns.append(vuln)

        # Test batching
        vuln = await self._test_batching(endpoint)
        if vuln:
            vulns.append(vuln)

        # Test alias-based resource exhaustion
        if self.target.active_mode:
            vuln = await self._test_alias_overloading(endpoint)
            if vuln:
                vulns.append(vuln)

        # Test field suggestions (schema leakage)
        vuln = await self._test_field_suggestions(endpoint)
        if vuln:
            vulns.append(vuln)

        return vulns

    async def _find_endpoint(self) -> str | None:
        """Probe common GraphQL paths."""
        for path in GRAPHQL_PATHS:
            url = urljoin(self.target.url.rstrip("/"), path)
            try:
                response = await self.client.post(
                    url,
                    json={"query": "{ __typename }"},
                    headers={"Content-Type": "application/json"},
                )
                if response.status_code == 200:
                    try:
                        data = response.json()
                        if "data" in data or "errors" in data:
                            return url
                    except (json.JSONDecodeError, ValueError):
                        continue
            except Exception:
                continue
        return None

    async def _test_introspection(self, endpoint: str) -> Vulnerability | None:
        try:
            response = await self.client.post(
                endpoint,
                json={"query": INTROSPECTION_QUERY},
                headers={"Content-Type": "application/json"},
            )
            data = response.json()

            if "data" in data and data["data"].get("__schema"):
                schema = data["data"]["__schema"]
                type_count = len(schema.get("types", []))
                has_mutations = schema.get("mutationType") is not None

                return Vulnerability(
                    id=uuid.uuid4().hex[:12],
                    title="GraphQL Introspection Enabled",
                    description=(
                        f"Full schema introspection is enabled, exposing {type_count} types"
                        f"{' including mutations' if has_mutations else ''}. "
                        f"Attackers can map the entire API surface."
                    ),
                    severity=Severity.MEDIUM,
                    scanner=self.name,
                    url=endpoint,
                    evidence=f"{type_count} types exposed, mutations: {has_mutations}",
                    remediation=(
                        "Disable introspection in production. In Apollo Server: "
                        "introspection: process.env.NODE_ENV !== 'production'. "
                        "Consider using persisted queries."
                    ),
                    references=[
                        "https://cwe.mitre.org/data/definitions/200.html",
                        "https://owasp.org/API-Security/editions/2023/en/0xa3-broken-object-property-level-authorization/",
                    ],
                )
        except Exception:
            pass
        return None

    async def _test_batching(self, endpoint: str) -> Vulnerability | None:
        try:
            response = await self.client.post(
                endpoint,
                json=BATCH_QUERY,
                headers={"Content-Type": "application/json"},
            )
            data = response.json()

            if isinstance(data, list) and len(data) >= 3:
                return Vulnerability(
                    id=uuid.uuid4().hex[:12],
                    title="GraphQL Batching Enabled",
                    description=(
                        "The GraphQL endpoint accepts batched queries. Attackers can bypass "
                        "rate limiting by bundling many operations into a single request, "
                        "enabling brute-force attacks and resource exhaustion."
                    ),
                    severity=Severity.MEDIUM,
                    scanner=self.name,
                    url=endpoint,
                    evidence=f"Batch of 3 queries returned {len(data)} responses",
                    remediation=(
                        "Limit batch query size or disable batching entirely. "
                        "Implement query cost analysis and depth limiting."
                    ),
                    references=["https://cwe.mitre.org/data/definitions/770.html"],
                )
        except Exception:
            pass
        return None

    async def _test_alias_overloading(self, endpoint: str) -> Vulnerability | None:
        try:
            response = await self.client.post(
                endpoint,
                json={"query": ALIAS_QUERY},
                headers={"Content-Type": "application/json"},
            )
            data = response.json()

            if "data" in data and len(data["data"]) >= 40:
                return Vulnerability(
                    id=uuid.uuid4().hex[:12],
                    title="GraphQL Alias-Based Resource Exhaustion",
                    description=(
                        "The server processes queries with many aliases without limits. "
                        "An attacker can use aliases to multiply query execution, "
                        "causing denial of service."
                    ),
                    severity=Severity.MEDIUM,
                    scanner=self.name,
                    url=endpoint,
                    evidence=f"50 aliases returned {len(data['data'])} results",
                    remediation="Implement query complexity analysis and alias limits.",
                    references=["https://cwe.mitre.org/data/definitions/400.html"],
                )
        except Exception:
            pass
        return None

    async def _test_field_suggestions(self, endpoint: str) -> Vulnerability | None:
        try:
            response = await self.client.post(
                endpoint,
                json={"query": FIELD_SUGGESTION_QUERY},
                headers={"Content-Type": "application/json"},
            )
            data = response.json()

            if "errors" in data:
                error_text = json.dumps(data["errors"])
                if "did you mean" in error_text.lower() or "suggestion" in error_text.lower():
                    return Vulnerability(
                        id=uuid.uuid4().hex[:12],
                        title="GraphQL Field Suggestions Enabled",
                        description=(
                            "The server provides field name suggestions in error messages, "
                            "allowing attackers to enumerate the schema even with "
                            "introspection disabled."
                        ),
                        severity=Severity.LOW,
                        scanner=self.name,
                        url=endpoint,
                        evidence=error_text[:200],
                        remediation=(
                            "Disable field suggestions in production. In Apollo: "
                            "set includeStacktraceInErrorResponses: false and use "
                            "a custom error formatter."
                        ),
                        references=["https://cwe.mitre.org/data/definitions/200.html"],
                    )
        except Exception:
            pass
        return None
