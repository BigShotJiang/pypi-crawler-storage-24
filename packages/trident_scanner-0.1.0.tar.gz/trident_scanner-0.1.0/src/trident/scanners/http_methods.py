"""HTTP methods scanner — detects dangerous allowed methods."""

from __future__ import annotations

import asyncio
import uuid

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

DANGEROUS_METHODS = {
    "PUT": ("Allows uploading/replacing files on the server", Severity.HIGH),
    "DELETE": ("Allows deleting resources on the server", Severity.HIGH),
    "TRACE": ("Enables Cross-Site Tracing (XST) attacks", Severity.MEDIUM),
    "CONNECT": ("May allow using the server as a proxy", Severity.MEDIUM),
    "PATCH": ("Allows partial modification of resources", Severity.LOW),
}


@register_scanner
class HTTPMethodsScanner(BaseScanner):
    name = "http-methods"
    description = "Detects dangerous HTTP methods (PUT, DELETE, TRACE) allowed by the server"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []

        urls_to_check = [self.target.url] + urls[:4]
        checked: set[str] = set()

        for url in urls_to_check:
            if url in checked:
                continue
            checked.add(url)

            # Try OPTIONS request first
            try:
                response = await self.client.options(url)
                allow_header = response.headers.get("allow", "")
                if allow_header:
                    methods = {m.strip().upper() for m in allow_header.split(",")}
                    for method, (desc, severity) in DANGEROUS_METHODS.items():
                        if method in methods:
                            vulns.append(
                                Vulnerability(
                                    id=uuid.uuid4().hex[:12],
                                    title=f"Dangerous HTTP Method Allowed: {method}",
                                    description=f"The server allows {method} requests. {desc}.",
                                    severity=severity,
                                    scanner=self.name,
                                    url=url,
                                    evidence=f"Allow: {allow_header}",
                                    remediation=f"Disable the {method} method unless explicitly needed.",
                                    references=["https://cwe.mitre.org/data/definitions/16.html"],
                                )
                            )
                    # Only report from the first URL that responds with Allow
                    if allow_header:
                        break
            except Exception:
                continue

            # If no Allow header, probe TRACE directly
            try:
                response = await self.client.request("TRACE", url)
                if response.status_code == 200 and "TRACE" in response.text.upper():
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title="TRACE Method Enabled",
                            description=(
                                "The server responds to TRACE requests. This can enable "
                                "Cross-Site Tracing (XST) attacks to steal credentials."
                            ),
                            severity=Severity.MEDIUM,
                            scanner=self.name,
                            url=url,
                            evidence=f"TRACE response: HTTP {response.status_code}",
                            remediation="Disable the TRACE method in your web server configuration.",
                            references=[
                                "https://cwe.mitre.org/data/definitions/16.html",
                                "https://owasp.org/www-community/attacks/Cross_Site_Tracing",
                            ],
                        )
                    )
                    break
            except Exception:
                continue

        return vulns
