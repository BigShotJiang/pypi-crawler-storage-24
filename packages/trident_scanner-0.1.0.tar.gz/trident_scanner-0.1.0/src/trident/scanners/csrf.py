"""CSRF (Cross-Site Request Forgery) scanner."""

from __future__ import annotations

import uuid

from bs4 import BeautifulSoup

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

CSRF_TOKEN_NAMES = {
    "csrf_token", "csrftoken", "csrf", "_csrf", "csrfmiddlewaretoken",
    "authenticity_token", "__requestverificationtoken", "antiforgery",
    "_token", "token", "xsrf_token", "_xsrf",
}

STATE_CHANGING_METHODS = {"post", "put", "delete", "patch"}


@register_scanner
class CSRFScanner(BaseScanner):
    name = "csrf"
    description = "Detects missing CSRF protections on forms"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        forms_checked: set[str] = set()

        for url in urls:
            try:
                response = await self.client.get(url)
            except Exception:
                continue

            if "text/html" not in response.headers.get("content-type", ""):
                continue

            soup = BeautifulSoup(response.text, "lxml")
            forms = soup.find_all("form")

            for form in forms:
                method = (form.get("method", "get")).lower()
                action = form.get("action", url)

                if method not in STATE_CHANGING_METHODS:
                    continue

                form_id = f"{method}:{action}"
                if form_id in forms_checked:
                    continue
                forms_checked.add(form_id)

                # Check for CSRF token in form fields
                has_token = False
                inputs = form.find_all("input", attrs={"type": "hidden"})
                for inp in inputs:
                    name = (inp.get("name", "") or "").lower()
                    if name in CSRF_TOKEN_NAMES or "csrf" in name or "xsrf" in name:
                        has_token = True
                        break

                if has_token:
                    continue

                # Check for SameSite cookie or custom header patterns
                has_samesite = False
                set_cookies = response.headers.get_list("set-cookie") if hasattr(
                    response.headers, "get_list"
                ) else [response.headers.get("set-cookie", "")]
                for cookie_header in set_cookies:
                    if cookie_header and "samesite" in cookie_header.lower():
                        has_samesite = True
                        break

                if has_samesite:
                    continue

                vulns.append(
                    Vulnerability(
                        id=uuid.uuid4().hex[:12],
                        title=f"Missing CSRF Protection on {method.upper()} Form",
                        description=(
                            f"A form with method '{method.upper()}' at {url} (action: {action}) "
                            f"does not include a CSRF token. This may allow attackers to forge "
                            f"requests on behalf of authenticated users."
                        ),
                        severity=Severity.MEDIUM,
                        scanner=self.name,
                        url=url,
                        evidence=f"Form method={method.upper()} action={action} — no CSRF token found",
                        remediation=(
                            "Add a CSRF token to all state-changing forms. "
                            "Use SameSite cookie attribute as defense-in-depth. "
                            "Consider using the Synchronizer Token Pattern or Double Submit Cookie."
                        ),
                        references=[
                            "https://cwe.mitre.org/data/definitions/352.html",
                            "https://owasp.org/www-community/attacks/csrf",
                        ],
                    )
                )

        return vulns
