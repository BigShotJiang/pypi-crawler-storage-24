"""Secret detection scanner — finds leaked credentials in responses and JS files."""

from __future__ import annotations

import re
import uuid

from trident.core.models import Severity, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.scanners import register_scanner

# High-confidence secret patterns with named groups
SECRET_PATTERNS: list[tuple[str, re.Pattern[str], Severity, str]] = [
    # AWS
    (
        "AWS Access Key",
        re.compile(r"(?:^|['\"\s=:])(?P<secret>AKIA[0-9A-Z]{16})(?:['\"\s]|$)"),
        Severity.CRITICAL,
        "Rotate the AWS access key immediately and remove from source code.",
    ),
    (
        "AWS Secret Key",
        re.compile(r"(?:aws_secret_access_key|secret_key)\s*[:=]\s*['\"]?(?P<secret>[A-Za-z0-9/+=]{40})['\"]?", re.I),
        Severity.CRITICAL,
        "Rotate the AWS secret key immediately.",
    ),
    # Google
    (
        "Google API Key",
        re.compile(r"(?:^|['\"\s=:])(?P<secret>AIza[0-9A-Za-z\-_]{35})(?:['\"\s]|$)"),
        Severity.HIGH,
        "Restrict the API key to specific IPs/referrers or rotate it.",
    ),
    (
        "Google OAuth Client Secret",
        re.compile(r"(?:client_secret)\s*[:=]\s*['\"]?(?P<secret>GOCSPX-[A-Za-z0-9_-]{28})['\"]?"),
        Severity.CRITICAL,
        "Rotate the OAuth client secret immediately.",
    ),
    # GitHub
    (
        "GitHub Token",
        re.compile(r"(?:^|['\"\s=:])(?P<secret>gh[pousr]_[A-Za-z0-9_]{36,255})(?:['\"\s]|$)"),
        Severity.CRITICAL,
        "Revoke the GitHub token immediately at github.com/settings/tokens.",
    ),
    # Stripe
    (
        "Stripe Secret Key",
        re.compile(r"(?:^|['\"\s=:])(?P<secret>sk_live_[0-9a-zA-Z]{24,99})(?:['\"\s]|$)"),
        Severity.CRITICAL,
        "Rotate the Stripe secret key in your Stripe dashboard immediately.",
    ),
    (
        "Stripe Publishable Key",
        re.compile(r"(?:^|['\"\s=:])(?P<secret>pk_live_[0-9a-zA-Z]{24,99})(?:['\"\s]|$)"),
        Severity.LOW,
        "Publishable keys are public but verify this is intentional.",
    ),
    # Slack
    (
        "Slack Token",
        re.compile(r"(?:^|['\"\s=:])(?P<secret>xox[baprs]-[0-9a-zA-Z-]{10,250})(?:['\"\s]|$)"),
        Severity.CRITICAL,
        "Revoke the Slack token at api.slack.com/apps.",
    ),
    (
        "Slack Webhook",
        re.compile(r"(?P<secret>https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[a-zA-Z0-9]+)"),
        Severity.HIGH,
        "Rotate the Slack webhook URL.",
    ),
    # Generic patterns
    (
        "Private Key",
        re.compile(r"(?P<secret>-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----)"),
        Severity.CRITICAL,
        "Remove private key from client-facing responses immediately.",
    ),
    (
        "JWT Token",
        re.compile(r"(?:^|['\"\s=:])(?P<secret>eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})"),
        Severity.MEDIUM,
        "Verify this JWT is not a long-lived service token exposed to clients.",
    ),
    (
        "Generic API Key",
        re.compile(r"(?:api[_-]?key|apikey|api[_-]?secret)\s*[:=]\s*['\"]?(?P<secret>[A-Za-z0-9_\-]{20,64})['\"]?", re.I),
        Severity.HIGH,
        "Rotate the API key and use environment variables instead.",
    ),
    (
        "Database Connection String",
        re.compile(r"(?P<secret>(?:mongodb|postgres|mysql|redis|amqp)://[^\s<>'\"]{10,})"),
        Severity.CRITICAL,
        "Remove database connection strings from client-facing code. Use environment variables.",
    ),
    (
        "Password in URL",
        re.compile(r"(?P<secret>https?://[^:]+:[^@]+@[^\s<>'\"]+)"),
        Severity.HIGH,
        "Remove credentials from URLs. Use environment variables or secret managers.",
    ),
    # Twilio
    (
        "Twilio API Key",
        re.compile(r"(?:^|['\"\s=:])(?P<secret>SK[0-9a-fA-F]{32})(?:['\"\s]|$)"),
        Severity.HIGH,
        "Rotate the Twilio API key.",
    ),
    # SendGrid
    (
        "SendGrid API Key",
        re.compile(r"(?:^|['\"\s=:])(?P<secret>SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43})(?:['\"\s]|$)"),
        Severity.CRITICAL,
        "Rotate the SendGrid API key.",
    ),
    # Mailgun
    (
        "Mailgun API Key",
        re.compile(r"(?:^|['\"\s=:])(?P<secret>key-[0-9a-zA-Z]{32})(?:['\"\s]|$)"),
        Severity.HIGH,
        "Rotate the Mailgun API key.",
    ),
    # Heroku
    (
        "Heroku API Key",
        re.compile(r"(?:heroku.*api[_-]?key)\s*[:=]\s*['\"]?(?P<secret>[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})['\"]?", re.I),
        Severity.HIGH,
        "Rotate the Heroku API key.",
    ),
]

# Entropy-based detection for high-entropy strings that look like secrets
HIGH_ENTROPY_CONTEXTS = re.compile(
    r"(?:secret|password|passwd|pwd|token|auth|credential|key|apikey|api_key)"
    r"\s*[:=]\s*['\"]([A-Za-z0-9+/=_\-]{16,})['\"]",
    re.IGNORECASE,
)


@register_scanner
class SecretScanner(BaseScanner):
    name = "secrets"
    description = "Detects leaked API keys, tokens, and credentials in responses and JS files"

    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        vulns: list[Vulnerability] = []
        seen_secrets: set[str] = set()

        # Scan HTML pages and JS files
        urls_to_scan = []
        for url in urls:
            urls_to_scan.append(url)

        # Also discover and scan JS files
        for url in urls[:5]:
            try:
                resp = await self.client.get(url)
                js_urls = re.findall(r'(?:src|href)\s*=\s*["\']([^"\']*\.js(?:\?[^"\']*)?)["\']', resp.text)
                for js_url in js_urls:
                    if js_url.startswith("//"):
                        js_url = "https:" + js_url
                    elif js_url.startswith("/"):
                        from urllib.parse import urljoin
                        js_url = urljoin(url, js_url)
                    elif not js_url.startswith("http"):
                        from urllib.parse import urljoin
                        js_url = urljoin(url, js_url)
                    urls_to_scan.append(js_url)
            except Exception:
                continue

        for url in urls_to_scan:
            try:
                resp = await self.client.get(url)
            except Exception:
                continue

            text = resp.text

            # Pattern-based detection
            for name, pattern, severity, remediation in SECRET_PATTERNS:
                for match in pattern.finditer(text):
                    secret = match.group("secret")
                    # Deduplicate
                    secret_key = f"{name}:{secret[:20]}"
                    if secret_key in seen_secrets:
                        continue
                    seen_secrets.add(secret_key)

                    # Mask the secret for evidence
                    masked = secret[:6] + "..." + secret[-4:] if len(secret) > 12 else secret[:4] + "..."

                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title=f"Secret Detected: {name}",
                            description=f"A {name} was found exposed in a client-facing response.",
                            severity=severity,
                            scanner=self.name,
                            url=url,
                            evidence=f"{name}: {masked}",
                            remediation=remediation,
                            references=["https://cwe.mitre.org/data/definitions/798.html"],
                        )
                    )

            # Entropy-based detection for secrets in known contexts
            for match in HIGH_ENTROPY_CONTEXTS.finditer(text):
                value = match.group(1)
                secret_key = f"entropy:{value[:20]}"
                if secret_key in seen_secrets:
                    continue

                # Calculate Shannon entropy
                entropy = self._shannon_entropy(value)
                if entropy > 4.0 and len(value) >= 20:
                    seen_secrets.add(secret_key)
                    masked = value[:6] + "..." + value[-4:]
                    vulns.append(
                        Vulnerability(
                            id=uuid.uuid4().hex[:12],
                            title="High-Entropy Secret in Sensitive Context",
                            description=(
                                f"A high-entropy string (entropy: {entropy:.1f}) was found "
                                f"in a secret/password/token context."
                            ),
                            severity=Severity.HIGH,
                            scanner=self.name,
                            url=url,
                            evidence=f"Value: {masked} (entropy: {entropy:.1f})",
                            remediation="Move secrets to environment variables or a secret manager.",
                            references=["https://cwe.mitre.org/data/definitions/798.html"],
                        )
                    )

        return vulns

    @staticmethod
    def _shannon_entropy(data: str) -> float:
        """Calculate Shannon entropy of a string."""
        import math
        from collections import Counter

        if not data:
            return 0.0
        counter = Counter(data)
        length = len(data)
        return -sum(
            (count / length) * math.log2(count / length)
            for count in counter.values()
        )
