"""Scanner module registry."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from trident.core.scanner_base import BaseScanner

# Registry of all available scanners
_SCANNER_REGISTRY: dict[str, type[BaseScanner]] = {}


def register_scanner(cls: type[BaseScanner]) -> type[BaseScanner]:
    """Decorator to register a scanner class."""
    _SCANNER_REGISTRY[cls.name] = cls
    return cls


def get_all_scanners(names: list[str] | None = None) -> list[type[BaseScanner]]:
    """Get scanner classes, optionally filtered by name."""
    # Trigger imports so decorators run
    from trident.scanners import (  # noqa: F401
        headers, tls, xss, sqli, cors, csrf,
        open_redirect, directory_enum, cookies, info_disclosure,
        ssrf, tech_fingerprint, http_methods, subdomain_enum,
        graphql, api_security, secrets, js_libs, template_scanner,
    )

    if names is None:
        return list(_SCANNER_REGISTRY.values())
    return [_SCANNER_REGISTRY[n] for n in names if n in _SCANNER_REGISTRY]
