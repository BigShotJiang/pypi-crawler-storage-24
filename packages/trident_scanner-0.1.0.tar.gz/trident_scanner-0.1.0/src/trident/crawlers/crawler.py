"""Async web crawler for URL discovery."""

from __future__ import annotations

import asyncio
import re
import time
from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

from trident.core.models import ScanTarget


class TokenBucketRateLimiter:
    """Token bucket rate limiter for actual requests-per-second control."""

    def __init__(self, rate: float) -> None:
        self.rate = rate
        self.tokens = rate
        self.max_tokens = rate
        self.last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_refill
            self.tokens = min(self.max_tokens, self.tokens + elapsed * self.rate)
            self.last_refill = now

            if self.tokens < 1:
                wait_time = (1 - self.tokens) / self.rate
                await asyncio.sleep(wait_time)
                self.tokens = 0
            else:
                self.tokens -= 1


class Crawler:
    """Discovers URLs on a target by crawling pages and extracting links."""

    def __init__(self, client: httpx.AsyncClient, target: ScanTarget) -> None:
        self.client = client
        self.target = target
        self.visited: set[str] = set()
        self.discovered: set[str] = set()
        self._rate_limiter = TokenBucketRateLimiter(target.rate_limit)
        self._semaphore = asyncio.Semaphore(10)  # max concurrent requests

    async def crawl(self) -> list[str]:
        """Crawl the target and return all discovered URLs."""
        self.discovered.add(self.target.url)
        await self._crawl_url(self.target.url, depth=0)
        return sorted(self.discovered)

    async def _crawl_url(self, url: str, depth: int) -> None:
        if depth > self.target.max_depth:
            return
        if url in self.visited:
            return
        if len(self.discovered) >= self.target.max_pages:
            return
        if self._is_excluded(url):
            return

        self.visited.add(url)

        async with self._semaphore:
            await self._rate_limiter.acquire()
            try:
                response = await self.client.get(url)
            except httpx.HTTPError:
                return

        if "text/html" not in response.headers.get("content-type", ""):
            return

        links = self._extract_links(response.text, url)

        tasks = []
        for link in links:
            if link not in self.visited and self._is_in_scope(link):
                self.discovered.add(link)
                if len(self.discovered) < self.target.max_pages:
                    tasks.append(self._crawl_url(link, depth + 1))

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    def _extract_links(self, html: str, base_url: str) -> set[str]:
        """Extract and normalize links from HTML."""
        links: set[str] = set()
        soup = BeautifulSoup(html, "lxml")

        for tag in soup.find_all(["a", "form", "script", "link", "iframe"]):
            href = tag.get("href") or tag.get("src") or tag.get("action")
            if not href:
                continue

            absolute = urljoin(base_url, href)
            parsed = urlparse(absolute)
            clean = parsed._replace(fragment="").geturl()
            links.add(clean)

        return links

    def _is_in_scope(self, url: str) -> bool:
        """Check if URL belongs to the same domain as the target."""
        target_domain = urlparse(self.target.url).netloc
        url_domain = urlparse(url).netloc
        return url_domain == target_domain

    def _is_excluded(self, url: str) -> bool:
        """Check if URL matches any exclusion pattern."""
        for pattern in self.target.exclude_patterns:
            if re.search(pattern, url):
                return True
        return False
