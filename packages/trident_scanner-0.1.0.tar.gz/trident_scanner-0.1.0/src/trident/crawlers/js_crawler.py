"""JavaScript-aware crawler using Playwright for SPA support."""

from __future__ import annotations

import asyncio
import re
from urllib.parse import urljoin, urlparse

from trident.core.models import ScanTarget


class JSCrawler:
    """Crawls JavaScript-rendered pages using a headless browser.

    Requires: pip install playwright && playwright install chromium
    """

    def __init__(self, target: ScanTarget) -> None:
        self.target = target
        self.visited: set[str] = set()
        self.discovered: set[str] = set()

    async def crawl(self) -> list[str]:
        """Crawl the target using a headless browser."""
        try:
            from playwright.async_api import async_playwright
        except ImportError:
            raise RuntimeError(
                "Playwright is required for JS crawling. Install it with:\n"
                "  pip install playwright && playwright install chromium"
            )

        self.discovered.add(self.target.url)

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(
                user_agent="Mozilla/5.0 (Trident Security Scanner)",
                ignore_https_errors=True,
            )

            # Set auth cookies/headers if provided
            if self.target.cookies:
                cookies = []
                parsed = urlparse(self.target.url)
                for name, value in self.target.cookies.items():
                    cookies.append({
                        "name": name,
                        "value": value,
                        "domain": parsed.hostname or "",
                        "path": "/",
                    })
                await context.add_cookies(cookies)

            try:
                await self._crawl_page(context, self.target.url, depth=0)
            finally:
                await browser.close()

        return sorted(self.discovered)

    async def _crawl_page(self, context, url: str, depth: int) -> None:
        if depth > self.target.max_depth:
            return
        if url in self.visited:
            return
        if len(self.discovered) >= self.target.max_pages:
            return
        if self._is_excluded(url):
            return

        self.visited.add(url)

        page = await context.new_page()
        try:
            response = await page.goto(url, wait_until="networkidle", timeout=15000)
            if not response:
                return

            # Wait for dynamic content
            await page.wait_for_timeout(1000)

            # Extract links from rendered DOM
            links = await page.evaluate("""() => {
                const links = new Set();
                // Standard links
                document.querySelectorAll('a[href]').forEach(a => links.add(a.href));
                // Form actions
                document.querySelectorAll('form[action]').forEach(f => links.add(f.action));
                // Buttons with data-href or onclick navigation
                document.querySelectorAll('[data-href]').forEach(el => links.add(el.dataset.href));
                // Router links (React/Vue/Angular)
                document.querySelectorAll('[routerlink], [to]').forEach(el => {
                    const val = el.getAttribute('routerlink') || el.getAttribute('to');
                    if (val) links.add(new URL(val, window.location.href).href);
                });
                return [...links];
            }""")

            # Also extract from page content (API calls in JS)
            content = await page.content()
            api_patterns = re.findall(
                r'(?:fetch|axios\.get|axios\.post|\.ajax)\s*\(\s*[\'"]([^\'"]+)[\'"]',
                content,
            )
            for api_path in api_patterns:
                if api_path.startswith("/"):
                    links.append(urljoin(url, api_path))

            tasks = []
            for link in links:
                if not isinstance(link, str):
                    continue
                # Normalize
                parsed = urlparse(link)
                clean = parsed._replace(fragment="").geturl()

                if clean not in self.visited and self._is_in_scope(clean):
                    self.discovered.add(clean)
                    if len(self.discovered) < self.target.max_pages:
                        tasks.append(self._crawl_page(context, clean, depth + 1))

            for task in tasks:
                await task

        except Exception:
            pass
        finally:
            await page.close()

    def _is_in_scope(self, url: str) -> bool:
        target_domain = urlparse(self.target.url).netloc
        url_domain = urlparse(url).netloc
        return url_domain == target_domain

    def _is_excluded(self, url: str) -> bool:
        for pattern in self.target.exclude_patterns:
            if re.search(pattern, url):
                return True
        return False
