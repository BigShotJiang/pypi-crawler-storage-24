"""Scan engine — orchestrates crawling and scanning."""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from typing import Any, Callable

import httpx
from rich.console import Console

from trident.core.models import ScanResult, ScanStatus, ScanTarget, Vulnerability
from trident.core.scanner_base import BaseScanner
from trident.crawlers.crawler import Crawler
from trident.crawlers.js_crawler import JSCrawler
from trident.scanners import get_all_scanners

console = Console()


class ScanRunner:
    """Core scan logic shared by CLI engine and API scan manager."""

    @staticmethod
    async def execute(
        client: httpx.AsyncClient,
        target: ScanTarget,
        scanner_names: list[str] | None,
        result: ScanResult,
        on_scanner_start: Callable[[str], Any] | None = None,
        on_scanner_done: Callable[[str, list[Vulnerability]], Any] | None = None,
        on_error: Callable[[str, Exception], Any] | None = None,
    ) -> None:
        """Run the full crawl → scan pipeline."""
        result.status = ScanStatus.RUNNING
        result.started_at = datetime.now(timezone.utc)

        try:
            # Phase 1: Crawl
            if on_scanner_start:
                on_scanner_start("crawler")

            if target.js_crawl:
                js_crawler = JSCrawler(target)
                urls = await js_crawler.crawl()
            else:
                crawler = Crawler(client, target)
                urls = await crawler.crawl()
            result.urls_scanned = len(urls)

            # Phase 2: Scan
            scanner_classes = get_all_scanners(scanner_names)

            # Split into parallel-safe and serial batches based on scanner attribute
            parallel_batch = [
                cls for cls in scanner_classes
                if not (cls.requires_serial and target.active_mode)
            ]
            serial_batch = [
                cls for cls in scanner_classes
                if cls.requires_serial and target.active_mode
            ]

            all_vulns: list[Vulnerability] = []

            # Run parallel batch
            if parallel_batch:
                semaphore = asyncio.Semaphore(6)

                async def run_one(cls: type[BaseScanner]) -> list[Vulnerability]:
                    async with semaphore:
                        return await ScanRunner._run_scanner(
                            client, cls, target, urls, result,
                            on_scanner_start, on_scanner_done, on_error,
                        )

                tasks = [run_one(cls) for cls in parallel_batch]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                for r in results:
                    if isinstance(r, list):
                        all_vulns.extend(r)

            # Run serial batch
            for cls in serial_batch:
                vulns = await ScanRunner._run_scanner(
                    client, cls, target, urls, result,
                    on_scanner_start, on_scanner_done, on_error,
                )
                all_vulns.extend(vulns)

            result.vulnerabilities = all_vulns
            result.status = ScanStatus.COMPLETED

        except asyncio.CancelledError:
            result.status = ScanStatus.CANCELLED
        except Exception as e:
            result.status = ScanStatus.FAILED
            result.errors.append(str(e))
        finally:
            result.completed_at = datetime.now(timezone.utc)

    @staticmethod
    async def _run_scanner(
        client: httpx.AsyncClient,
        scanner_cls: type[BaseScanner],
        target: ScanTarget,
        urls: list[str],
        result: ScanResult,
        on_scanner_start: Callable[[str], Any] | None,
        on_scanner_done: Callable[[str, list[Vulnerability]], Any] | None,
        on_error: Callable[[str, Exception], Any] | None,
    ) -> list[Vulnerability]:
        scanner = scanner_cls(client, target)
        if on_scanner_start:
            on_scanner_start(scanner.name)

        await scanner.setup()
        try:
            vulns = await scanner.scan(urls)
            result.scanners_run.append(scanner.name)
            if on_scanner_done:
                on_scanner_done(scanner.name, vulns)
            return vulns
        except Exception as e:
            result.errors.append(f"Scanner {scanner.name} failed: {e}")
            if on_error:
                on_error(scanner.name, e)
            return []
        finally:
            await scanner.teardown()


class ScanEngine:
    """CLI-oriented scan engine with rich console output."""

    def __init__(self, target: ScanTarget, scanners: list[str] | None = None) -> None:
        self.target = target
        self.scanner_names = scanners
        self.result = ScanResult(id=uuid.uuid4().hex[:12], target=target)

    async def run(self) -> ScanResult:
        limits = httpx.Limits(max_connections=30, max_keepalive_connections=15)
        timeout = httpx.Timeout(30.0, connect=10.0)

        console.print(f"\n[bold blue]Phase 1:[/] Crawling {self.target.url}")

        async with httpx.AsyncClient(
            limits=limits, timeout=timeout, follow_redirects=True,
            headers=self.target.headers, cookies=self.target.cookies,
            http2=True, verify=True,
        ) as client:
            await ScanRunner.execute(
                client, self.target, self.scanner_names, self.result,
                on_scanner_start=self._on_start,
                on_scanner_done=self._on_done,
                on_error=self._on_error,
            )

        if self.result.status == ScanStatus.COMPLETED:
            console.print(f"  Discovered [cyan]{self.result.urls_scanned}[/] URLs\n")
        elif self.result.status == ScanStatus.FAILED:
            console.print(f"\n[bold red]Scan failed[/]")

        return self.result

    def _on_start(self, name: str) -> None:
        if name != "crawler":
            console.print(f"  Running [yellow]{name}[/]...")

    def _on_done(self, name: str, vulns: list[Vulnerability]) -> None:
        if vulns:
            console.print(f"    Found [red]{len(vulns)}[/] issue(s)")
        else:
            console.print(f"    [green]Clean[/]")

    def _on_error(self, name: str, error: Exception) -> None:
        console.print(f"    [red]Error:[/] {error}")
