"""Fix suggestion engine — generates actionable remediation with config/code snippets."""

from __future__ import annotations

from trident.core.models import Vulnerability

# Maps vulnerability titles/scanners to framework-specific fix snippets
FIX_SNIPPETS: dict[str, dict[str, str]] = {
    "Missing Strict-Transport-Security Header": {
        "nginx": 'add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;',
        "apache": "Header always set Strict-Transport-Security \"max-age=31536000; includeSubDomains; preload\"",
        "express": "app.use(helmet.hsts({ maxAge: 31536000, includeSubDomains: true, preload: true }));",
        "django": "SECURE_HSTS_SECONDS = 31536000\nSECURE_HSTS_INCLUDE_SUBDOMAINS = True\nSECURE_HSTS_PRELOAD = True",
        "rails": "config.force_ssl = true  # in config/environments/production.rb",
        "cloudflare": "Enable HSTS in SSL/TLS > Edge Certificates > HTTP Strict Transport Security",
    },
    "Missing Content-Security-Policy Header": {
        "nginx": "add_header Content-Security-Policy \"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self';\" always;",
        "apache": 'Header always set Content-Security-Policy "default-src \'self\'; script-src \'self\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data:; font-src \'self\';"',
        "express": "app.use(helmet.contentSecurityPolicy({ directives: { defaultSrc: [\"'self'\"], scriptSrc: [\"'self'\"], styleSrc: [\"'self'\", \"'unsafe-inline'\"] } }));",
        "django": 'CSP_DEFAULT_SRC = ("\'self\'",)  # django-csp package',
        "next.js": "// next.config.js\nconst securityHeaders = [{ key: 'Content-Security-Policy', value: \"default-src 'self'\" }];",
    },
    "Missing X-Frame-Options Header": {
        "nginx": 'add_header X-Frame-Options "DENY" always;',
        "apache": 'Header always set X-Frame-Options "DENY"',
        "express": "app.use(helmet.frameguard({ action: 'deny' }));",
        "django": "X_FRAME_OPTIONS = 'DENY'  # in settings.py (enabled by default)",
        "rails": "config.action_dispatch.default_headers['X-Frame-Options'] = 'DENY'",
    },
    "Missing X-Content-Type-Options Header": {
        "nginx": 'add_header X-Content-Type-Options "nosniff" always;',
        "apache": 'Header always set X-Content-Type-Options "nosniff"',
        "express": "app.use(helmet.noSniff());",
        "django": "SECURE_CONTENT_TYPE_NOSNIFF = True  # in settings.py (enabled by default)",
    },
    "Missing Referrer-Policy Header": {
        "nginx": 'add_header Referrer-Policy "strict-origin-when-cross-origin" always;',
        "apache": 'Header always set Referrer-Policy "strict-origin-when-cross-origin"',
        "express": "app.use(helmet.referrerPolicy({ policy: 'strict-origin-when-cross-origin' }));",
        "django": "SECURE_REFERRER_POLICY = 'strict-origin-when-cross-origin'",
    },
    "Missing Permissions-Policy Header": {
        "nginx": 'add_header Permissions-Policy "camera=(), microphone=(), geolocation=(), payment=()" always;',
        "apache": 'Header always set Permissions-Policy "camera=(), microphone=(), geolocation=(), payment=()"',
        "express": 'app.use(helmet.permittedCrossDomainPolicies());\napp.use((req, res, next) => { res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()"); next(); });',
    },
    "Site Not Using HTTPS": {
        "nginx": "server {\n    listen 80;\n    return 301 https://$host$request_uri;\n}",
        "apache": "RewriteEngine On\nRewriteCond %{HTTPS} off\nRewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]",
        "cloudflare": "Enable 'Always Use HTTPS' in SSL/TLS > Edge Certificates",
        "letsencrypt": "sudo certbot --nginx  # or --apache for Apache",
    },
    "GraphQL Introspection Enabled": {
        "apollo": "const server = new ApolloServer({\n  typeDefs,\n  resolvers,\n  introspection: process.env.NODE_ENV !== 'production',\n});",
        "graphql-yoga": "createYoga({ graphiql: false, maskedErrors: true })",
        "django-graphene": "GRAPHENE = { 'MIDDLEWARE': ['graphql_jwt.middleware.JSONWebTokenMiddleware'] }",
    },
    "No API Rate Limiting Detected": {
        "nginx": "limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;\n\nlocation /api/ {\n    limit_req zone=api burst=20 nodelay;\n}",
        "express": "const rateLimit = require('express-rate-limit');\napp.use('/api/', rateLimit({ windowMs: 15*60*1000, max: 100, standardHeaders: true }));",
        "django": "REST_FRAMEWORK = { 'DEFAULT_THROTTLE_RATES': { 'anon': '100/hour', 'user': '1000/hour' } }",
        "fastapi": "from slowapi import Limiter\nlimiter = Limiter(key_func=get_remote_address)\napp.state.limiter = limiter",
    },
    "Cookie Missing Secure Flag": {
        "express": "app.use(session({ cookie: { secure: true, httpOnly: true, sameSite: 'strict' } }));",
        "django": "SESSION_COOKIE_SECURE = True\nCSRF_COOKIE_SECURE = True",
        "rails": "Rails.application.config.session_store :cookie_store, secure: Rails.env.production?",
        "php": "session.cookie_secure = 1  # in php.ini\nini_set('session.cookie_secure', 1);",
    },
}

# Compliance mapping
COMPLIANCE_MAP: dict[str, list[str]] = {
    "Missing Strict-Transport-Security Header": ["PCI DSS 4.0 §4.2.1", "OWASP A05:2025", "CWE-319"],
    "Missing Content-Security-Policy Header": ["OWASP A03:2025", "CWE-79", "NIST SP 800-53 SC-28"],
    "Missing X-Frame-Options Header": ["OWASP A05:2025", "CWE-1021", "PCI DSS 4.0 §6.2"],
    "Site Not Using HTTPS": ["PCI DSS 4.0 §4.2.1", "OWASP A02:2025", "CWE-319", "GDPR Art. 32"],
    "SQL Injection": ["OWASP A03:2025", "CWE-89", "PCI DSS 4.0 §6.2.4", "NIST SP 800-53 SI-10"],
    "Confirmed Reflected XSS": ["OWASP A03:2025", "CWE-79", "PCI DSS 4.0 §6.2.4"],
    "CORS: Arbitrary Origin Reflected": ["OWASP A01:2025", "CWE-942"],
    "Missing CSRF Protection": ["OWASP A01:2025", "CWE-352", "PCI DSS 4.0 §6.2.4"],
    "GraphQL Introspection Enabled": ["OWASP API9:2023", "CWE-200"],
    "Unauthenticated API Access": ["OWASP API2:2023", "CWE-306", "PCI DSS 4.0 §7.2"],
    "No API Rate Limiting Detected": ["OWASP API4:2023", "CWE-770"],
    "Secret Detected": ["CWE-798", "OWASP A02:2025", "PCI DSS 4.0 §3.4", "SOC 2 CC6.1"],
    "Potential BOLA": ["OWASP API1:2023", "CWE-639"],
}


def enrich_vulnerability(vuln: Vulnerability) -> Vulnerability:
    """Enrich a vulnerability with fix snippets and compliance mappings."""
    # Add fix snippets
    for title_key, snippets in FIX_SNIPPETS.items():
        if title_key.lower() in vuln.title.lower():
            fix_text = "\n\n".join(
                f"# {framework}\n{code}" for framework, code in snippets.items()
            )
            vuln.metadata["fix_snippets"] = snippets
            if vuln.remediation:
                vuln.remediation += f"\n\nFix examples:\n{fix_text}"
            else:
                vuln.remediation = fix_text
            break

    # Add compliance mappings
    for title_key, mappings in COMPLIANCE_MAP.items():
        if title_key.lower() in vuln.title.lower():
            vuln.metadata["compliance"] = mappings
            if vuln.references:
                vuln.references.extend(mappings)
            else:
                vuln.references = mappings
            break

    return vuln


def enrich_results(vulns: list[Vulnerability]) -> list[Vulnerability]:
    """Enrich all vulnerabilities in a scan result."""
    return [enrich_vulnerability(v) for v in vulns]
