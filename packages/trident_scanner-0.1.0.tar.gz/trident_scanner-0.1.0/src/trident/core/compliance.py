"""Compliance mapping engine — maps findings to security frameworks."""

from __future__ import annotations

from typing import Any

from trident.core.models import ScanResult, Severity, Vulnerability

# Framework definitions
FRAMEWORKS: dict[str, dict[str, Any]] = {
    "owasp-top10-2025": {
        "name": "OWASP Top 10 2025",
        "version": "2025",
        "controls": {
            "A01": "Broken Access Control",
            "A02": "Security Misconfiguration",
            "A03": "Software Supply Chain Failures",
            "A04": "Cryptographic Failures",
            "A05": "Injection",
            "A06": "Insecure Design",
            "A07": "Authentication Failures",
            "A08": "Software or Data Integrity Failures",
            "A09": "Security Logging and Alerting Failures",
            "A10": "Mishandling of Exceptional Conditions",
        },
    },
    "owasp-api-2023": {
        "name": "OWASP API Security Top 10 2023",
        "version": "2023",
        "controls": {
            "API1": "Broken Object Level Authorization",
            "API2": "Broken Authentication",
            "API3": "Broken Object Property Level Authorization",
            "API4": "Unrestricted Resource Consumption",
            "API5": "Broken Function Level Authorization",
            "API6": "Unrestricted Access to Sensitive Business Flows",
            "API7": "Server Side Request Forgery",
            "API8": "Security Misconfiguration",
            "API9": "Improper Inventory Management",
            "API10": "Unsafe Consumption of APIs",
        },
    },
    "pci-dss-4": {
        "name": "PCI DSS 4.0",
        "version": "4.0",
        "controls": {
            "3.4": "Protect stored account data",
            "4.2.1": "Strong cryptography for transmission",
            "6.2": "Develop software securely",
            "6.2.4": "Software engineering techniques for vulnerability prevention",
            "6.3": "Identify and manage security vulnerabilities",
            "7.2": "Access control for system components",
            "8.3": "Strong authentication for users and administrators",
            "11.3": "External and internal vulnerabilities tested regularly",
        },
    },
    "soc2": {
        "name": "SOC 2 Trust Services Criteria",
        "version": "2017",
        "controls": {
            "CC6.1": "Logical and physical access controls",
            "CC6.6": "Security for system boundaries",
            "CC6.7": "Restrict data movement",
            "CC7.1": "Detect and monitor security events",
            "CC7.2": "Monitor system components for anomalies",
            "CC8.1": "Change management",
        },
    },
    "nist-csf": {
        "name": "NIST Cybersecurity Framework",
        "version": "2.0",
        "controls": {
            "PR.AC": "Access Control",
            "PR.DS": "Data Security",
            "PR.IP": "Information Protection",
            "PR.PT": "Protective Technology",
            "DE.CM": "Continuous Monitoring",
            "DE.DP": "Detection Processes",
        },
    },
}

# Maps scanner findings to framework controls
FINDING_TO_FRAMEWORK: dict[str, dict[str, list[str]]] = {
    # Headers scanner
    "missing strict-transport-security": {
        "owasp-top10-2025": ["A04"],
        "pci-dss-4": ["4.2.1"],
        "nist-csf": ["PR.DS"],
    },
    "missing content-security-policy": {
        "owasp-top10-2025": ["A05"],
        "nist-csf": ["PR.PT"],
    },
    "missing x-frame-options": {
        "owasp-top10-2025": ["A01"],
        "nist-csf": ["PR.PT"],
    },
    "site not using https": {
        "owasp-top10-2025": ["A04"],
        "pci-dss-4": ["4.2.1"],
        "nist-csf": ["PR.DS"],
        "soc2": ["CC6.6"],
    },
    # XSS
    "xss": {
        "owasp-top10-2025": ["A05"],
        "pci-dss-4": ["6.2.4"],
        "nist-csf": ["PR.PT"],
    },
    # SQLi
    "sql injection": {
        "owasp-top10-2025": ["A05"],
        "pci-dss-4": ["6.2.4"],
        "nist-csf": ["PR.PT"],
    },
    # CORS
    "cors": {
        "owasp-top10-2025": ["A01"],
        "nist-csf": ["PR.AC"],
    },
    # CSRF
    "csrf": {
        "owasp-top10-2025": ["A01"],
        "pci-dss-4": ["6.2.4"],
    },
    # Secrets
    "secret detected": {
        "owasp-top10-2025": ["A04"],
        "pci-dss-4": ["3.4"],
        "soc2": ["CC6.1"],
        "nist-csf": ["PR.DS"],
    },
    # API Security
    "unauthenticated api": {
        "owasp-api-2023": ["API2"],
        "pci-dss-4": ["7.2"],
        "soc2": ["CC6.1"],
    },
    "bola": {
        "owasp-api-2023": ["API1"],
        "pci-dss-4": ["7.2"],
    },
    "rate limiting": {
        "owasp-api-2023": ["API4"],
    },
    "api specification exposed": {
        "owasp-api-2023": ["API9"],
    },
    "mass assignment": {
        "owasp-api-2023": ["API3"],
    },
    # GraphQL
    "graphql introspection": {
        "owasp-api-2023": ["API9", "API8"],
    },
    # SSRF
    "ssrf": {
        "owasp-top10-2025": ["A01"],
        "owasp-api-2023": ["API7"],
    },
    # TLS
    "tls": {
        "owasp-top10-2025": ["A04"],
        "pci-dss-4": ["4.2.1"],
    },
    # Cookies
    "cookie": {
        "owasp-top10-2025": ["A02"],
        "nist-csf": ["PR.AC"],
    },
    # Open redirect
    "open redirect": {
        "owasp-top10-2025": ["A01"],
    },
    # Supply chain / JS libs
    "vulnerable": {
        "owasp-top10-2025": ["A03"],
        "pci-dss-4": ["6.3"],
    },
    # Info disclosure
    "information disclosure": {
        "owasp-top10-2025": ["A02"],
        "nist-csf": ["PR.IP"],
    },
}


def map_vulnerability(vuln: Vulnerability) -> dict[str, list[dict[str, str]]]:
    """Map a single vulnerability to compliance framework controls."""
    mappings: dict[str, list[dict[str, str]]] = {}
    title_lower = vuln.title.lower()

    for keyword, frameworks in FINDING_TO_FRAMEWORK.items():
        if keyword in title_lower:
            for framework_id, control_ids in frameworks.items():
                if framework_id not in FRAMEWORKS:
                    continue
                framework = FRAMEWORKS[framework_id]
                controls = []
                for cid in control_ids:
                    control_name = framework["controls"].get(cid, "Unknown")
                    controls.append({
                        "id": cid,
                        "name": control_name,
                        "framework": framework["name"],
                    })
                if controls:
                    mappings[framework_id] = controls

    return mappings


def generate_compliance_report(result: ScanResult) -> dict[str, Any]:
    """Generate a compliance report mapping all findings to frameworks."""
    report: dict[str, Any] = {
        "target": result.target.url,
        "scan_id": result.id,
        "frameworks": {},
    }

    # Build per-framework view
    for framework_id, framework in FRAMEWORKS.items():
        framework_report: dict[str, Any] = {
            "name": framework["name"],
            "version": framework["version"],
            "controls": {},
            "pass_count": 0,
            "fail_count": 0,
        }

        # Initialize all controls as passing
        for cid, cname in framework["controls"].items():
            framework_report["controls"][cid] = {
                "name": cname,
                "status": "pass",
                "findings": [],
            }

        # Map findings to controls
        for vuln in result.vulnerabilities:
            mappings = map_vulnerability(vuln)
            if framework_id in mappings:
                for control in mappings[framework_id]:
                    cid = control["id"]
                    if cid in framework_report["controls"]:
                        framework_report["controls"][cid]["status"] = "fail"
                        framework_report["controls"][cid]["findings"].append({
                            "title": vuln.title,
                            "severity": vuln.severity.value,
                            "url": vuln.url,
                        })

        # Count pass/fail
        for ctrl in framework_report["controls"].values():
            if ctrl["status"] == "pass":
                framework_report["pass_count"] += 1
            else:
                framework_report["fail_count"] += 1

        total = framework_report["pass_count"] + framework_report["fail_count"]
        framework_report["compliance_pct"] = (
            round(framework_report["pass_count"] / total * 100, 1)
            if total > 0 else 100.0
        )

        report["frameworks"][framework_id] = framework_report

    return report
