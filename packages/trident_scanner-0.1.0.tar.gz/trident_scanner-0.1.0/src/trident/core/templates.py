"""YAML template engine for community-contributed vulnerability checks."""

from __future__ import annotations

import re
import uuid
from pathlib import Path
from typing import Any

import yaml

from trident.core.models import Severity, Vulnerability


class TemplateCheck:
    """A single vulnerability check loaded from a YAML template."""

    def __init__(self, data: dict[str, Any]) -> None:
        self.id: str = data["id"]
        self.name: str = data["name"]
        self.description: str = data.get("description", "")
        self.severity: Severity = Severity(data.get("severity", "info"))
        self.tags: list[str] = data.get("tags", [])
        self.author: str = data.get("author", "unknown")
        self.references: list[str] = data.get("references", [])
        self.remediation: str = data.get("remediation", "")

        # Request specification
        req = data.get("request", {})
        self.method: str = req.get("method", "GET").upper()
        self.path: str = req.get("path", "/")
        self.headers: dict[str, str] = req.get("headers", {})
        self.body: str | None = req.get("body")
        self.follow_redirects: bool = req.get("follow_redirects", True)

        # Matchers
        self.matchers: list[dict[str, Any]] = data.get("matchers", [])
        self.matchers_condition: str = data.get("matchers_condition", "and")

    def matches(self, status_code: int, headers: dict[str, str], body: str) -> bool:
        """Check if a response matches all/any matchers."""
        if not self.matchers:
            return False

        results = []
        for matcher in self.matchers:
            match_type = matcher.get("type", "word")
            negative = matcher.get("negative", False)
            matched = False

            if match_type == "status":
                codes = matcher.get("status", [])
                matched = status_code in codes

            elif match_type == "word":
                words = matcher.get("words", [])
                part = matcher.get("part", "body")
                text = body if part == "body" else "\n".join(f"{k}: {v}" for k, v in headers.items())
                condition = matcher.get("condition", "and")
                if condition == "and":
                    matched = all(w in text for w in words)
                else:
                    matched = any(w in text for w in words)

            elif match_type == "regex":
                patterns = matcher.get("regex", [])
                part = matcher.get("part", "body")
                text = body if part == "body" else "\n".join(f"{k}: {v}" for k, v in headers.items())
                condition = matcher.get("condition", "and")
                if condition == "and":
                    matched = all(re.search(p, text, re.IGNORECASE) for p in patterns)
                else:
                    matched = any(re.search(p, text, re.IGNORECASE) for p in patterns)

            elif match_type == "header":
                header_name = matcher.get("name", "").lower()
                expected = matcher.get("value")
                absent = matcher.get("absent", False)
                header_val = headers.get(header_name)

                if absent:
                    matched = header_val is None
                elif expected is None:
                    matched = header_val is not None
                else:
                    matched = header_val is not None and expected.lower() in header_val.lower()

            if negative:
                matched = not matched
            results.append(matched)

        if self.matchers_condition == "and":
            return all(results)
        return any(results)

    def to_vulnerability(self, url: str, evidence: str = "") -> Vulnerability:
        return Vulnerability(
            id=uuid.uuid4().hex[:12],
            title=self.name,
            description=self.description,
            severity=self.severity,
            scanner="template",
            url=url,
            evidence=evidence or f"Template: {self.id}",
            remediation=self.remediation,
            references=self.references,
            metadata={"template_id": self.id, "author": self.author, "tags": self.tags},
        )


class TemplateRegistry:
    """Manages loading and organizing vulnerability templates."""

    def __init__(self) -> None:
        self.templates: list[TemplateCheck] = []

    def load_directory(self, path: str | Path) -> int:
        """Load all YAML templates from a directory. Returns count loaded."""
        path = Path(path)
        if not path.exists():
            return 0

        count = 0
        for yaml_file in sorted(path.rglob("*.yaml")):
            try:
                self.load_file(yaml_file)
                count += 1
            except Exception:
                continue
        return count

    def load_file(self, path: str | Path) -> TemplateCheck:
        """Load a single template file."""
        with open(path) as f:
            data = yaml.safe_load(f)

        if not data or "id" not in data:
            raise ValueError(f"Invalid template: {path}")

        template = TemplateCheck(data)
        self.templates.append(template)
        return template

    def load_from_string(self, content: str) -> TemplateCheck:
        """Load a template from a YAML string."""
        data = yaml.safe_load(content)
        if not data or "id" not in data:
            raise ValueError("Invalid template content")
        template = TemplateCheck(data)
        self.templates.append(template)
        return template

    def get_by_tags(self, tags: list[str]) -> list[TemplateCheck]:
        """Filter templates by tags."""
        return [t for t in self.templates if any(tag in t.tags for tag in tags)]

    def get_by_severity(self, severity: Severity) -> list[TemplateCheck]:
        """Filter templates by severity."""
        return [t for t in self.templates if t.severity == severity]
