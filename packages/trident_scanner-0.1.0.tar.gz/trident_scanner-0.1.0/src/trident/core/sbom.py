"""SBOM generator — builds Software Bill of Materials from crawled assets."""

from __future__ import annotations

import json
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

import httpx


class SBOMGenerator:
    """Generates CycloneDX-format SBOM from crawled web assets."""

    def __init__(self) -> None:
        self.components: list[dict[str, Any]] = []
        self._seen: set[str] = set()

    async def analyze(self, client: httpx.AsyncClient, urls: list[str]) -> None:
        """Analyze URLs for JS/CSS library detection."""
        all_text: list[tuple[str, str]] = []

        for url in urls[:15]:
            try:
                resp = await client.get(url)
                all_text.append((url, resp.text))

                # Extract and fetch JS/CSS files
                asset_urls = re.findall(
                    r'(?:src|href)\s*=\s*["\']([^"\']*\.(?:js|css)(?:\?[^"\']*)?)["\']',
                    resp.text,
                )
                for asset_url in asset_urls[:30]:
                    if asset_url.startswith("//"):
                        asset_url = "https:" + asset_url
                    elif not asset_url.startswith("http"):
                        asset_url = urljoin(url, asset_url)

                    try:
                        asset_resp = await client.get(asset_url)
                        all_text.append((asset_url, asset_resp.text[:3000]))
                    except Exception:
                        continue
            except Exception:
                continue

        # Detect libraries
        for source_url, text in all_text:
            self._detect_libraries(source_url, text)

    def _detect_libraries(self, url: str, text: str) -> None:
        """Detect JS/CSS libraries from content."""
        patterns: list[tuple[str, re.Pattern[str], str]] = [
            ("jquery", re.compile(r"jquery[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("react", re.compile(r"react[.\-](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("react-dom", re.compile(r"react-dom[.\-](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("vue", re.compile(r"vue[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("angular", re.compile(r"angular[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("bootstrap", re.compile(r"bootstrap[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "css"),
            ("lodash", re.compile(r"lodash[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("moment", re.compile(r"moment[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("axios", re.compile(r"axios[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("d3", re.compile(r"d3[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("tailwindcss", re.compile(r"tailwindcss[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "css"),
            ("font-awesome", re.compile(r"font-awesome[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "css"),
            ("three", re.compile(r"three[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("socket.io", re.compile(r"socket\.io[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
            ("chart.js", re.compile(r"chart\.js[.\-/](?:v)?(\d+\.\d+\.\d+)", re.I), "javascript"),
        ]

        for lib_name, pattern, lib_type in patterns:
            match = pattern.search(text)
            if match:
                version = match.group(1)
                key = f"{lib_name}@{version}"
                if key not in self._seen:
                    self._seen.add(key)
                    self.components.append({
                        "type": "library",
                        "name": lib_name,
                        "version": version,
                        "purl": f"pkg:npm/{lib_name}@{version}",
                        "source_url": url,
                        "lib_type": lib_type,
                    })

    def to_cyclonedx(self, target_url: str) -> dict[str, Any]:
        """Generate CycloneDX 1.5 format SBOM."""
        return {
            "bomFormat": "CycloneDX",
            "specVersion": "1.5",
            "serialNumber": f"urn:uuid:{uuid.uuid4()}",
            "version": 1,
            "metadata": {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "tools": [{"name": "Trident", "version": "0.1.0"}],
                "component": {
                    "type": "application",
                    "name": target_url,
                    "bom-ref": "target",
                },
            },
            "components": [
                {
                    "type": comp["type"],
                    "name": comp["name"],
                    "version": comp["version"],
                    "purl": comp["purl"],
                    "bom-ref": f"{comp['name']}@{comp['version']}",
                    "properties": [
                        {"name": "source_url", "value": comp["source_url"]},
                        {"name": "lib_type", "value": comp["lib_type"]},
                    ],
                }
                for comp in self.components
            ],
        }

    def save(self, target_url: str, output_path: str) -> None:
        """Save SBOM to file."""
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        sbom = self.to_cyclonedx(target_url)
        path.write_text(json.dumps(sbom, indent=2))
