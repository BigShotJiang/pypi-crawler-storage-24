"""Notification system — sends alerts via webhooks on scan events."""

from __future__ import annotations

import json
from typing import Any

import httpx

from trident.core.models import ScanResult, Severity


async def send_webhook(
    webhook_url: str,
    result: ScanResult,
    regressions: list[dict[str, Any]] | None = None,
) -> bool:
    """Send scan results to a webhook (Slack, Discord, Teams, or generic)."""
    if "hooks.slack.com" in webhook_url:
        payload = _format_slack(result, regressions)
    elif "discord.com/api/webhooks" in webhook_url:
        payload = _format_discord(result, regressions)
    else:
        payload = _format_generic(result, regressions)

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(webhook_url, json=payload)
            return resp.status_code in (200, 201, 204)
    except Exception:
        return False


def _format_slack(
    result: ScanResult,
    regressions: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Format as Slack Block Kit message."""
    summary = result.summary
    total = sum(summary.values())
    sev_line = (
        f":red_circle: {summary.get('critical', 0)} Critical  "
        f":orange_circle: {summary.get('high', 0)} High  "
        f":yellow_circle: {summary.get('medium', 0)} Medium  "
        f":blue_circle: {summary.get('low', 0)} Low"
    )

    duration = f"{result.duration_seconds:.1f}s" if result.duration_seconds else "N/A"
    status_emoji = ":white_check_mark:" if total == 0 else ":warning:" if summary.get("critical", 0) == 0 else ":rotating_light:"

    blocks: list[dict[str, Any]] = [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": f"Trident Scan: {result.target.url}"},
        },
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": (
                    f"{status_emoji} *{result.status.value.upper()}* | {total} findings | "
                    f"{result.urls_scanned} URLs | {duration}\n{sev_line}"
                ),
            },
        },
    ]

    # Top findings
    critical_high = [
        v for v in result.vulnerabilities
        if v.severity in (Severity.CRITICAL, Severity.HIGH)
    ]
    if critical_high:
        findings_text = "\n".join(
            f"• `[{v.severity.value.upper()}]` {v.title}" for v in critical_high[:5]
        )
        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"*Top Findings:*\n{findings_text}"},
        })

    # Regressions
    if regressions:
        reg_text = "\n".join(
            f"• :new: `[{r.get('severity', 'unknown').upper()}]` {r['title']}"
            for r in regressions[:5]
        )
        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"*New Regressions:*\n{reg_text}"},
        })

    return {"blocks": blocks}


def _format_discord(
    result: ScanResult,
    regressions: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Format as Discord embed."""
    summary = result.summary
    total = sum(summary.values())
    color = 0xFF0000 if summary.get("critical", 0) > 0 else 0xFF8C00 if summary.get("high", 0) > 0 else 0x00FF00

    fields = [
        {"name": "Status", "value": result.status.value, "inline": True},
        {"name": "Findings", "value": str(total), "inline": True},
        {"name": "URLs", "value": str(result.urls_scanned), "inline": True},
        {
            "name": "Severity Breakdown",
            "value": (
                f"Critical: {summary.get('critical', 0)} | "
                f"High: {summary.get('high', 0)} | "
                f"Medium: {summary.get('medium', 0)} | "
                f"Low: {summary.get('low', 0)}"
            ),
            "inline": False,
        },
    ]

    if regressions:
        reg_text = "\n".join(f"- [{r.get('severity', '?')}] {r['title']}" for r in regressions[:5])
        fields.append({"name": "New Regressions", "value": reg_text, "inline": False})

    return {
        "embeds": [
            {
                "title": f"Trident Scan: {result.target.url}",
                "color": color,
                "fields": fields,
                "footer": {"text": "Trident Security Scanner"},
            }
        ]
    }


def _format_generic(
    result: ScanResult,
    regressions: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Generic JSON webhook payload."""
    return {
        "event": "scan_completed",
        "scan_id": result.id,
        "target": result.target.url,
        "status": result.status.value,
        "summary": result.summary,
        "total_findings": len(result.vulnerabilities),
        "urls_scanned": result.urls_scanned,
        "duration_seconds": result.duration_seconds,
        "critical_findings": [
            {"title": v.title, "severity": v.severity.value, "url": v.url}
            for v in result.vulnerabilities
            if v.severity in (Severity.CRITICAL, Severity.HIGH)
        ],
        "regressions": regressions or [],
    }
