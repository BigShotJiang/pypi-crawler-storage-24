"""Continuous monitoring — scheduled recurring scans with regression detection."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from trident.core.engine import ScanEngine
from trident.core.models import ScanResult, ScanStatus, ScanTarget, Severity


class ScanScheduler:
    """Manages scheduled recurring scans with baseline comparison."""

    def __init__(self, storage_dir: str = ".trident") -> None:
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self._running = False

    async def run_once(self, target: ScanTarget, scanners: list[str] | None = None) -> ScanResult:
        """Run a single scan and store the result."""
        engine = ScanEngine(target, scanners)
        result = await engine.run()

        # Store result
        self._save_result(result)
        return result

    async def run_scheduled(
        self,
        target: ScanTarget,
        interval_minutes: int = 60,
        scanners: list[str] | None = None,
        on_result: Any = None,
        on_regression: Any = None,
    ) -> None:
        """Run scans on a recurring schedule."""
        self._running = True

        while self._running:
            result = await self.run_once(target, scanners)

            # Check for regressions
            regressions = self.detect_regressions(result)

            if on_result:
                await on_result(result)

            if regressions and on_regression:
                await on_regression(result, regressions)

            await asyncio.sleep(interval_minutes * 60)

    def stop(self) -> None:
        self._running = False

    def detect_regressions(self, current: ScanResult) -> list[dict[str, Any]]:
        """Compare current scan with the previous baseline to find regressions."""
        baseline = self._load_latest_baseline(current.target.url)
        if not baseline:
            return []

        regressions: list[dict[str, Any]] = []

        # Find new vulnerabilities not in baseline
        baseline_titles = {v.title for v in baseline.vulnerabilities}
        for vuln in current.vulnerabilities:
            if vuln.title not in baseline_titles:
                regressions.append({
                    "type": "new_vulnerability",
                    "title": vuln.title,
                    "severity": vuln.severity.value,
                    "url": vuln.url,
                })

        # Find severity escalations
        baseline_severity = {v.title: v.severity for v in baseline.vulnerabilities}
        severity_order = {
            Severity.INFO: 0, Severity.LOW: 1, Severity.MEDIUM: 2,
            Severity.HIGH: 3, Severity.CRITICAL: 4,
        }
        for vuln in current.vulnerabilities:
            if vuln.title in baseline_severity:
                old_sev = severity_order.get(baseline_severity[vuln.title], 0)
                new_sev = severity_order.get(vuln.severity, 0)
                if new_sev > old_sev:
                    regressions.append({
                        "type": "severity_escalation",
                        "title": vuln.title,
                        "old_severity": baseline_severity[vuln.title].value,
                        "new_severity": vuln.severity.value,
                    })

        return regressions

    def _save_result(self, result: ScanResult) -> None:
        domain = result.target.url.replace("://", "_").replace("/", "_")[:50]
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        filename = f"{domain}_{timestamp}.json"
        filepath = self.storage_dir / filename

        data = result.model_dump(mode="json")
        filepath.write_text(json.dumps(data, indent=2, default=str))

    def _load_latest_baseline(self, target_url: str) -> ScanResult | None:
        domain = target_url.replace("://", "_").replace("/", "_")[:50]
        files = sorted(self.storage_dir.glob(f"{domain}_*.json"), reverse=True)

        # Skip the most recent (current scan), load the one before
        for f in files[1:]:
            try:
                data = json.loads(f.read_text())
                return ScanResult.model_validate(data)
            except Exception:
                continue
        return None

    def get_history(self, target_url: str, limit: int = 20) -> list[dict[str, Any]]:
        """Get scan history for a target."""
        domain = target_url.replace("://", "_").replace("/", "_")[:50]
        files = sorted(self.storage_dir.glob(f"{domain}_*.json"), reverse=True)

        history: list[dict[str, Any]] = []
        for f in files[:limit]:
            try:
                data = json.loads(f.read_text())
                history.append({
                    "id": data.get("id"),
                    "status": data.get("status"),
                    "started_at": data.get("started_at"),
                    "vulnerability_count": len(data.get("vulnerabilities", [])),
                    "summary": data.get("summary", {}),
                })
            except Exception:
                continue
        return history
