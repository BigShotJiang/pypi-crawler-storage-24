"""Base class for all scanner modules."""

from __future__ import annotations

import abc
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import httpx

    from trident.core.models import ScanTarget, Vulnerability


class BaseScanner(abc.ABC):
    """Abstract base class that all scanner plugins must implement."""

    name: str = "base"
    description: str = ""
    requires_serial: bool = False  # Set True for active scanners that send probing payloads

    def __init__(self, client: httpx.AsyncClient, target: ScanTarget) -> None:
        self.client = client
        self.target = target
        self.findings: list[Vulnerability] = []

    @abc.abstractmethod
    async def scan(self, urls: list[str]) -> list[Vulnerability]:
        """Run the scanner against discovered URLs."""
        ...

    async def setup(self) -> None:
        """Optional setup hook called before scanning begins."""

    async def teardown(self) -> None:
        """Optional teardown hook called after scanning completes."""
