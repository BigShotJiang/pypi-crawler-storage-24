"""Policy-as-code engine — define security policies in YAML, fail CI if violated."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from trident.core.models import ScanResult, Severity


class PolicyViolation:
    """A single policy violation."""

    def __init__(self, rule: str, message: str, severity: str = "error") -> None:
        self.rule = rule
        self.message = message
        self.severity = severity  # error, warning

    def __repr__(self) -> str:
        return f"[{self.severity.upper()}] {self.rule}: {self.message}"


class Policy:
    """Security policy loaded from YAML."""

    def __init__(self, data: dict[str, Any]) -> None:
        self.name: str = data.get("name", "Unnamed Policy")
        self.description: str = data.get("description", "")
        self.rules: list[dict[str, Any]] = data.get("rules", [])

    def evaluate(self, result: ScanResult) -> list[PolicyViolation]:
        """Evaluate scan results against all policy rules."""
        violations: list[PolicyViolation] = []

        for rule in self.rules:
            rule_name = rule.get("name", "unnamed")
            rule_type = rule.get("type", "")

            if rule_type == "max_severity":
                violations.extend(self._check_max_severity(rule, result))
            elif rule_type == "max_count":
                violations.extend(self._check_max_count(rule, result))
            elif rule_type == "required_scanner":
                violations.extend(self._check_required_scanner(rule, result))
            elif rule_type == "forbidden_finding":
                violations.extend(self._check_forbidden_finding(rule, result))

        return violations

    def _check_max_severity(
        self, rule: dict[str, Any], result: ScanResult
    ) -> list[PolicyViolation]:
        """Fail if any finding exceeds the maximum allowed severity."""
        max_allowed = Severity(rule.get("max", "medium"))
        severity_order = {
            Severity.INFO: 0, Severity.LOW: 1, Severity.MEDIUM: 2,
            Severity.HIGH: 3, Severity.CRITICAL: 4,
        }
        max_level = severity_order[max_allowed]

        violations = []
        for vuln in result.vulnerabilities:
            if severity_order.get(vuln.severity, 0) > max_level:
                violations.append(
                    PolicyViolation(
                        rule=rule.get("name", "max_severity"),
                        message=(
                            f"Finding '{vuln.title}' has severity {vuln.severity.value} "
                            f"which exceeds maximum allowed {max_allowed.value}"
                        ),
                    )
                )
        return violations

    def _check_max_count(
        self, rule: dict[str, Any], result: ScanResult
    ) -> list[PolicyViolation]:
        """Fail if total findings exceed a threshold."""
        max_count = rule.get("max", 0)
        severity_filter = rule.get("severity")

        if severity_filter:
            sev = Severity(severity_filter)
            count = sum(1 for v in result.vulnerabilities if v.severity == sev)
            label = f"{severity_filter} findings"
        else:
            count = len(result.vulnerabilities)
            label = "total findings"

        if count > max_count:
            return [
                PolicyViolation(
                    rule=rule.get("name", "max_count"),
                    message=f"{count} {label} exceeds maximum of {max_count}",
                )
            ]
        return []

    def _check_required_scanner(
        self, rule: dict[str, Any], result: ScanResult
    ) -> list[PolicyViolation]:
        """Fail if a required scanner was not run."""
        required = rule.get("scanners", [])
        missing = [s for s in required if s not in result.scanners_run]
        if missing:
            return [
                PolicyViolation(
                    rule=rule.get("name", "required_scanner"),
                    message=f"Required scanners not run: {', '.join(missing)}",
                )
            ]
        return []

    def _check_forbidden_finding(
        self, rule: dict[str, Any], result: ScanResult
    ) -> list[PolicyViolation]:
        """Fail if a specific finding type is present."""
        forbidden = rule.get("titles", [])
        violations = []
        for vuln in result.vulnerabilities:
            for title in forbidden:
                if title.lower() in vuln.title.lower():
                    violations.append(
                        PolicyViolation(
                            rule=rule.get("name", "forbidden_finding"),
                            message=f"Forbidden finding detected: {vuln.title}",
                        )
                    )
        return violations

    @property
    def passed(self) -> bool:
        """Convenience — not meaningful without a result, use evaluate()."""
        return True


def load_policy(path: str | Path) -> Policy:
    """Load a policy from a YAML file."""
    with open(path) as f:
        data = yaml.safe_load(f)
    return Policy(data or {})


def load_policy_from_string(content: str) -> Policy:
    """Load a policy from a YAML string."""
    data = yaml.safe_load(content)
    return Policy(data or {})
