"""Core data models for Trident scan results."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, HttpUrl


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ScanStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Vulnerability(BaseModel):
    """A single vulnerability finding."""

    id: str = Field(description="Unique identifier for this finding")
    title: str
    description: str
    severity: Severity
    scanner: str = Field(description="Scanner module that found this")
    url: str = Field(description="Affected URL")
    evidence: str | None = Field(default=None, description="Proof / payload used")
    remediation: str | None = Field(default=None, description="How to fix")
    references: list[str] = Field(default_factory=list, description="CWE/OWASP links")
    metadata: dict[str, Any] = Field(default_factory=dict)


class ScanTarget(BaseModel):
    """Target configuration for a scan."""

    url: str
    max_depth: int = Field(default=3, ge=1, le=10)
    max_pages: int = Field(default=100, ge=1, le=10000)
    rate_limit: float = Field(default=10.0, description="Max requests per second")
    headers: dict[str, str] = Field(default_factory=dict)
    cookies: dict[str, str] = Field(default_factory=dict)
    auth_token: str | None = None
    exclude_patterns: list[str] = Field(default_factory=list)
    active_mode: bool = Field(
        default=False,
        description="Enable active/intrusive testing (SQLi payloads, etc.)",
    )
    js_crawl: bool = Field(
        default=False,
        description="Use headless browser for SPA crawling",
    )


class ScanResult(BaseModel):
    """Complete result of a scan run."""

    id: str
    target: ScanTarget
    status: ScanStatus = ScanStatus.PENDING
    started_at: datetime | None = None
    completed_at: datetime | None = None
    vulnerabilities: list[Vulnerability] = Field(default_factory=list)
    urls_scanned: int = 0
    scanners_run: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)

    @property
    def duration_seconds(self) -> float | None:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    @property
    def summary(self) -> dict[str, int]:
        counts: dict[str, int] = {s.value: 0 for s in Severity}
        for vuln in self.vulnerabilities:
            counts[vuln.severity.value] += 1
        return counts
