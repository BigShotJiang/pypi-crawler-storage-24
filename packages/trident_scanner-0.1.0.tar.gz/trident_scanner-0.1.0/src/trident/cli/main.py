"""Trident CLI — the main entry point."""

from __future__ import annotations

import asyncio
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from trident import __version__
from trident.core.engine import ScanEngine
from trident.core.models import ScanTarget, Severity
from trident.reporters.console import print_report
from trident.reporters.json_report import save_json_report

app = typer.Typer(
    name="trident",
    help="Automated web application security scanner.",
    no_args_is_help=True,
)
console = Console()

BANNER = r"""
  ████████╗██████╗ ██╗██████╗ ███████╗███╗   ██╗████████╗
  ╚══██╔══╝██╔══██╗██║██╔══██╗██╔════╝████╗  ██║╚══██╔══╝
     ██║   ██████╔╝██║██║  ██║█████╗  ██╔██╗ ██║   ██║
     ██║   ██╔══██╗██║██║  ██║██╔══╝  ██║╚██╗██║   ██║
     ██║   ██║  ██║██║██████╔╝███████╗██║ ╚████║   ██║
     ╚═╝   ╚═╝  ╚═╝╚═╝╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝
"""


@app.command()
def scan(
    url: Annotated[str, typer.Argument(help="Target URL to scan")],
    active: Annotated[
        bool, typer.Option("--active", "-a", help="Enable active/intrusive scanning")
    ] = False,
    depth: Annotated[
        int, typer.Option("--depth", "-d", help="Maximum crawl depth")
    ] = 3,
    max_pages: Annotated[
        int, typer.Option("--max-pages", "-p", help="Maximum pages to crawl")
    ] = 100,
    rate_limit: Annotated[
        float, typer.Option("--rate-limit", "-r", help="Max requests per second")
    ] = 10.0,
    js_crawl: Annotated[
        bool, typer.Option("--js-crawl", help="Use headless browser for SPA crawling (requires playwright)"),
    ] = False,
    scanners: Annotated[
        Optional[str],
        typer.Option("--scanners", "-s", help="Comma-separated scanner names"),
    ] = None,
    output: Annotated[
        Optional[str],
        typer.Option("--output", "-o", help="Output JSON report to file"),
    ] = None,
    html: Annotated[
        Optional[str],
        typer.Option("--html", help="Output HTML report to file"),
    ] = None,
    sarif: Annotated[
        Optional[str],
        typer.Option("--sarif", help="Output SARIF report for GitHub Code Scanning"),
    ] = None,
    sbom: Annotated[
        Optional[str],
        typer.Option("--sbom", help="Output CycloneDX SBOM to file"),
    ] = None,
    compliance: Annotated[
        Optional[str],
        typer.Option("--compliance", help="Output compliance mapping report to file"),
    ] = None,
    policy: Annotated[
        Optional[str],
        typer.Option("--policy", help="Policy YAML file — exit non-zero on violations"),
    ] = None,
    header: Annotated[
        Optional[list[str]],
        typer.Option("--header", "-H", help="Custom header (Name: Value)"),
    ] = None,
    cookie: Annotated[
        Optional[str],
        typer.Option("--cookie", "-c", help="Cookie string (name=value; name2=value2)"),
    ] = None,
    auth_token: Annotated[
        Optional[str],
        typer.Option("--auth", help="Bearer token for authentication"),
    ] = None,
) -> None:
    """Scan a target URL for security vulnerabilities."""
    console.print(BANNER, style="bold cyan")
    console.print(
        Panel(f"Trident v{__version__} — Web Security Scanner", style="bold blue")
    )

    # Parse headers
    custom_headers: dict[str, str] = {}
    if header:
        for h in header:
            if ":" in h:
                name, value = h.split(":", 1)
                custom_headers[name.strip()] = value.strip()

    if auth_token:
        custom_headers["Authorization"] = f"Bearer {auth_token}"

    # Parse cookies
    cookies: dict[str, str] = {}
    if cookie:
        for pair in cookie.split(";"):
            if "=" in pair:
                name, value = pair.split("=", 1)
                cookies[name.strip()] = value.strip()

    # Build target
    target = ScanTarget(
        url=url,
        max_depth=depth,
        max_pages=max_pages,
        rate_limit=rate_limit,
        headers=custom_headers,
        cookies=cookies,
        auth_token=auth_token,
        active_mode=active,
        js_crawl=js_crawl,
    )

    # Parse scanner names
    scanner_list = [s.strip() for s in scanners.split(",")] if scanners else None

    if active:
        console.print(
            "\n[bold yellow]⚠ Active mode enabled — intrusive payloads will be sent[/]\n"
        )

    # Run the scan
    engine = ScanEngine(target, scanner_list)
    result = asyncio.run(engine.run())

    # Enrich with fix suggestions
    from trident.core.fix_suggestions import enrich_results
    result.vulnerabilities = enrich_results(result.vulnerabilities)

    # Print results
    print_report(result)

    # Save reports
    if output:
        save_json_report(result, output)
        console.print(f"\n[green]JSON report saved to {output}[/]")

    if html:
        from trident.reporters.html_report import save_html_report
        save_html_report(result, html)
        console.print(f"[green]HTML report saved to {html}[/]")

    if sarif:
        from trident.reporters.sarif_report import save_sarif_report
        save_sarif_report(result, sarif)
        console.print(f"[green]SARIF report saved to {sarif}[/]")

    if sbom:
        console.print("[dim]Generating SBOM...[/]")
        import httpx as _httpx
        from trident.core.sbom import SBOMGenerator

        async def _gen_sbom() -> None:
            sbom_gen = SBOMGenerator()
            async with _httpx.AsyncClient(timeout=30.0, follow_redirects=True) as c:
                await sbom_gen.analyze(c, [target.url])
            sbom_gen.save(target.url, sbom)

        asyncio.run(_gen_sbom())
        console.print(f"[green]SBOM saved to {sbom}[/]")

    if compliance:
        import json as _json
        from trident.core.compliance import generate_compliance_report
        report = generate_compliance_report(result)
        from pathlib import Path
        Path(compliance).write_text(_json.dumps(report, indent=2))
        console.print(f"[green]Compliance report saved to {compliance}[/]")

        # Print compliance summary
        for fw_id, fw in report["frameworks"].items():
            pct = fw["compliance_pct"]
            color = "green" if pct >= 80 else "yellow" if pct >= 60 else "red"
            console.print(f"  [{color}]{fw['name']}: {pct}% compliant[/{color}]")

    if policy:
        from trident.core.policy import load_policy
        pol = load_policy(policy)
        violations = pol.evaluate(result)
        if violations:
            console.print(f"\n[bold red]Policy violations ({len(violations)}):[/]")
            for v in violations:
                console.print(f"  [red]✗[/] {v}")
            raise typer.Exit(code=1)
        else:
            console.print("\n[bold green]✓ All policy checks passed[/]")


@app.command()
def list_scanners() -> None:
    """List all available scanner modules."""
    from trident.scanners import get_all_scanners

    console.print(BANNER, style="bold cyan")

    table = Table(title="Available Scanners")
    table.add_column("Name", style="cyan")
    table.add_column("Description")

    for scanner_cls in get_all_scanners():
        table.add_row(scanner_cls.name, scanner_cls.description)

    console.print(table)


@app.command()
def serve(
    host: Annotated[str, typer.Option("--host", "-h", help="Bind host")] = "127.0.0.1",
    port: Annotated[int, typer.Option("--port", "-p", help="Bind port")] = 8000,
) -> None:
    """Start the web dashboard."""
    import uvicorn

    from trident.api.app import create_app

    console.print(BANNER, style="bold cyan")
    console.print(
        Panel(
            f"Dashboard running at [bold cyan]http://{host}:{port}[/]\n"
            f"Press [bold]Ctrl+C[/] to stop.",
            title="[bold]Trident Web Dashboard[/]",
            style="blue",
        )
    )
    uvicorn.run(create_app(), host=host, port=port, log_level="warning")


@app.command()
def monitor(
    url: Annotated[str, typer.Argument(help="Target URL to monitor")],
    interval: Annotated[
        int, typer.Option("--interval", "-i", help="Scan interval in minutes")
    ] = 60,
    webhook: Annotated[
        Optional[str],
        typer.Option("--webhook", "-w", help="Webhook URL for notifications (Slack, Discord, or generic)"),
    ] = None,
    scanners: Annotated[
        Optional[str],
        typer.Option("--scanners", "-s", help="Comma-separated scanner names"),
    ] = None,
    storage: Annotated[
        str, typer.Option("--storage", help="Directory to store scan history"),
    ] = ".trident",
) -> None:
    """Continuously monitor a target for security regressions."""
    from trident.core.scheduler import ScanScheduler
    from trident.core.fix_suggestions import enrich_results

    console.print(BANNER, style="bold cyan")
    console.print(
        Panel(
            f"Monitoring [bold cyan]{url}[/] every [bold]{interval}[/] minutes\n"
            + (f"Webhook: {webhook}\n" if webhook else "")
            + f"Press [bold]Ctrl+C[/] to stop.",
            title="[bold]Continuous Monitoring[/]",
            style="blue",
        )
    )

    target = ScanTarget(url=url)
    scanner_list = [s.strip() for s in scanners.split(",")] if scanners else None
    scheduler = ScanScheduler(storage)

    async def on_result(result: ScanResult) -> None:
        result.vulnerabilities = enrich_results(result.vulnerabilities)
        summary = result.summary
        total = sum(summary.values())
        console.print(
            f"\n[bold]Scan {result.id}[/] completed: "
            f"[red]{summary.get('critical', 0)}C[/] "
            f"[red]{summary.get('high', 0)}H[/] "
            f"[yellow]{summary.get('medium', 0)}M[/] "
            f"[blue]{summary.get('low', 0)}L[/] "
            f"({total} total)"
        )

    async def on_regression(result: ScanResult, regressions: list) -> None:
        console.print(f"\n[bold red]⚠ {len(regressions)} regression(s) detected![/]")
        for r in regressions:
            console.print(f"  [red]NEW[/] [{r.get('severity', '?')}] {r['title']}")

        if webhook:
            from trident.core.notifications import send_webhook
            success = await send_webhook(webhook, result, regressions)
            if success:
                console.print("  [green]Webhook notification sent[/]")
            else:
                console.print("  [red]Webhook notification failed[/]")

    try:
        asyncio.run(
            scheduler.run_scheduled(
                target,
                interval_minutes=interval,
                scanners=scanner_list,
                on_result=on_result,
                on_regression=on_regression,
            )
        )
    except KeyboardInterrupt:
        console.print("\n[dim]Monitoring stopped.[/]")


@app.command()
def policy_check(
    results_file: Annotated[str, typer.Argument(help="Path to scan results JSON file")],
    policy_file: Annotated[
        str, typer.Option("--policy", "-p", help="Path to policy YAML file"),
    ] = "policy.yaml",
) -> None:
    """Check scan results against a security policy."""
    import json as _json

    from trident.core.models import ScanResult
    from trident.core.policy import load_policy

    console.print(BANNER, style="bold cyan")

    data = _json.loads(open(results_file).read())
    result = ScanResult.model_validate(data)
    pol = load_policy(policy_file)

    console.print(f"[bold]Policy:[/] {pol.name}")
    console.print(f"[bold]Target:[/] {result.target.url}")
    console.print(f"[bold]Findings:[/] {len(result.vulnerabilities)}\n")

    violations = pol.evaluate(result)
    if violations:
        console.print(f"[bold red]✗ {len(violations)} policy violation(s):[/]")
        for v in violations:
            console.print(f"  [red]✗[/] {v}")
        raise typer.Exit(code=1)
    else:
        console.print("[bold green]✓ All policy checks passed[/]")


@app.command()
def version() -> None:
    """Show Trident version."""
    console.print(f"Trident v{__version__}")


if __name__ == "__main__":
    app()
