"""API request/response models."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from trident.core.models import ScanStatus


class ScanRequest(BaseModel):
    url: str
    scanners: list[str] | None = None
    active_mode: bool = False
    max_depth: int = Field(default=3, ge=1, le=10)
    max_pages: int = Field(default=100, ge=1, le=10000)
    rate_limit: float = Field(default=10.0, ge=1.0, le=100.0)


class ScanProgress(BaseModel):
    scan_id: str
    status: ScanStatus
    current_scanner: str | None = None
    scanners_completed: list[str] = Field(default_factory=list)
    scanners_total: int = 0
    urls_scanned: int = 0
    vulnerabilities_found: int = 0


class ScannerInfo(BaseModel):
    name: str
    description: str


class ScanSummaryResponse(BaseModel):
    id: str
    target_url: str
    status: ScanStatus
    started_at: datetime | None = None
    completed_at: datetime | None = None
    vulnerability_count: int = 0
    summary: dict[str, int] = Field(default_factory=dict)
