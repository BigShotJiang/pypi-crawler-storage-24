"""API routes."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse

from trident.api.models import ScannerInfo, ScanProgress, ScanRequest, ScanSummaryResponse
from trident.api.scan_manager import ScanManager
from trident.reporters.html_report import generate_html_report
from trident.scanners import get_all_scanners

router = APIRouter(prefix="/api")
manager = ScanManager()


@router.post("/scans")
async def start_scan(request: ScanRequest) -> dict[str, str]:
    scan_id = manager.start_scan(request)
    return {"scan_id": scan_id}


@router.get("/scans")
async def list_scans() -> list[ScanSummaryResponse]:
    results = manager.list_scans()
    return [
        ScanSummaryResponse(
            id=r.id,
            target_url=r.target.url,
            status=r.status,
            started_at=r.started_at,
            completed_at=r.completed_at,
            vulnerability_count=len(r.vulnerabilities),
            summary=r.summary,
        )
        for r in results
    ]


@router.get("/scans/{scan_id}")
async def get_scan(scan_id: str) -> dict:
    result = manager.get_result(scan_id)
    if not result:
        raise HTTPException(status_code=404, detail="Scan not found")
    return result.model_dump(mode="json")


@router.get("/scans/{scan_id}/progress")
async def get_progress(scan_id: str) -> ScanProgress:
    progress = manager.get_progress(scan_id)
    if not progress:
        raise HTTPException(status_code=404, detail="Scan not found")
    return progress


@router.delete("/scans/{scan_id}")
async def cancel_scan(scan_id: str) -> dict[str, str]:
    if manager.cancel_scan(scan_id):
        return {"status": "cancelled"}
    raise HTTPException(status_code=404, detail="Scan not found or already completed")


@router.get("/scans/{scan_id}/report")
async def get_html_report(scan_id: str) -> HTMLResponse:
    result = manager.get_result(scan_id)
    if not result:
        raise HTTPException(status_code=404, detail="Scan not found")
    html = generate_html_report(result)
    return HTMLResponse(content=html)


@router.get("/scans/{scan_id}/compliance")
async def get_compliance(scan_id: str) -> dict:
    result = manager.get_result(scan_id)
    if not result:
        raise HTTPException(status_code=404, detail="Scan not found")
    from trident.core.compliance import generate_compliance_report
    return generate_compliance_report(result)


@router.get("/scans/{scan_id}/sarif")
async def get_sarif(scan_id: str) -> dict:
    result = manager.get_result(scan_id)
    if not result:
        raise HTTPException(status_code=404, detail="Scan not found")
    from trident.reporters.sarif_report import generate_sarif
    return generate_sarif(result)


@router.get("/scanners")
async def list_scanners() -> list[ScannerInfo]:
    scanner_classes = get_all_scanners()
    return [
        ScannerInfo(name=cls.name, description=cls.description)
        for cls in scanner_classes
    ]
