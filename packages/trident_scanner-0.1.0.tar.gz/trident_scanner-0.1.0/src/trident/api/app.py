"""FastAPI application factory."""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from trident.api.routes import router


def create_app() -> FastAPI:
    app = FastAPI(title="Trident Security Scanner", version="0.1.0")
    app.include_router(router)

    # Serve static dashboard — must be mounted AFTER API routes
    static_dir = Path(__file__).parent / "static"
    static_dir.mkdir(exist_ok=True)
    app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")

    return app


app = create_app()
