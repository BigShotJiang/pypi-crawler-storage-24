"""Scan manager — orchestrates scans for the API layer."""

from __future__ import annotations

import asyncio
import uuid

import httpx

from trident.api.models import ScanProgress
from trident.api.models import ScanRequest
from trident.core.engine import ScanRunner
from trident.core.models import ScanResult, ScanStatus, ScanTarget, Vulnerability
from trident.scanners import get_all_scanners


class ScanManager:
    """Manages scan lifecycle for the API."""

    def __init__(self) -> None:
        self._results: dict[str, ScanResult] = {}
        self._progress: dict[str, ScanProgress] = {}
        self._tasks: dict[str, asyncio.Task[None]] = {}

    def start_scan(self, request: ScanRequest) -> str:
        scan_id = uuid.uuid4().hex[:12]

        target = ScanTarget(
            url=request.url,
            max_depth=request.max_depth,
            max_pages=request.max_pages,
            rate_limit=request.rate_limit,
            active_mode=request.active_mode,
        )

        result = ScanResult(id=scan_id, target=target)
        self._results[scan_id] = result

        scanner_classes = get_all_scanners(request.scanners)
        self._progress[scan_id] = ScanProgress(
            scan_id=scan_id,
            status=ScanStatus.PENDING,
            scanners_total=len(scanner_classes),
        )

        task = asyncio.create_task(self._run_scan(scan_id, target, request.scanners))
        self._tasks[scan_id] = task
        return scan_id

    async def _run_scan(self, scan_id: str, target: ScanTarget, scanner_names: list[str] | None) -> None:
        result = self._results[scan_id]
        progress = self._progress[scan_id]
        progress.status = ScanStatus.RUNNING

        limits = httpx.Limits(max_connections=30, max_keepalive_connections=15)
        timeout = httpx.Timeout(30.0, connect=10.0)

        async with httpx.AsyncClient(
            limits=limits, timeout=timeout, follow_redirects=True,
            headers=target.headers, cookies=target.cookies,
            http2=True, verify=True,
        ) as client:
            def on_start(name: str) -> None:
                progress.current_scanner = name

            def on_done(name: str, vulns: list[Vulnerability]) -> None:
                progress.scanners_completed.append(name)
                progress.vulnerabilities_found = len(result.vulnerabilities) + len(vulns)
                progress.urls_scanned = result.urls_scanned

            def on_error(name: str, error: Exception) -> None:
                pass  # Errors captured in result by ScanRunner

            await ScanRunner.execute(
                client, target, scanner_names, result,
                on_scanner_start=on_start,
                on_scanner_done=on_done,
                on_error=on_error,
            )

        progress.status = result.status
        progress.current_scanner = None

    def get_result(self, scan_id: str) -> ScanResult | None:
        return self._results.get(scan_id)

    def get_progress(self, scan_id: str) -> ScanProgress | None:
        return self._progress.get(scan_id)

    def list_scans(self) -> list[ScanResult]:
        return list(self._results.values())

    def cancel_scan(self, scan_id: str) -> bool:
        task = self._tasks.get(scan_id)
        if task and not task.done():
            task.cancel()
            return True
        return False
