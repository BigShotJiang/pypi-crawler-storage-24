from .verysmolcode import *

__doc__ = verysmolcode.__doc__
if hasattr(verysmolcode, "__all__"):
    __all__ = verysmolcode.__all__