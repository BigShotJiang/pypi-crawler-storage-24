"""Context compression pipeline for ContextLayer SDK.

Implements a research-backed compression method using:
- Sentence embeddings (all-MiniLM-L6-v2) for relevance filtering & deduplication
- TextRank for importance scoring
- TF-IDF + entity density for information density scoring
- Regex-based aggressive pruning for filler removal

All heavy dependencies (sentence-transformers, numpy) are lazy-loaded.
Install with: pip install layer-context[compression]
"""

import os
import re
import math
import logging
import warnings
from collections import Counter
from typing import List, Optional, Tuple


# ---------------------------------------------------------------------------
# Suppress noisy warnings from HuggingFace / transformers / tokenizers
# ---------------------------------------------------------------------------

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")
os.environ.setdefault("SAFETENSORS_FAST_GPU", "1")

# Suppress specific loggers
for _logger_name in (
    "sentence_transformers",
    "transformers",
    "huggingface_hub",
    "huggingface_hub.utils",
    "tokenizers",
    "safetensors",
):
    logging.getLogger(_logger_name).setLevel(logging.ERROR)


# ---------------------------------------------------------------------------
# Lazy imports
# ---------------------------------------------------------------------------

def _import_numpy():
    try:
        import numpy as np
        return np
    except ImportError:
        raise ImportError(
            "Context compression requires numpy. "
            "Install it with: pip install layer-context[compression]"
        )


def _import_sentence_transformers():
    try:
        # Suppress FutureWarning and other warnings during import
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            from sentence_transformers import SentenceTransformer
        return SentenceTransformer
    except ImportError:
        raise ImportError(
            "Context compression requires sentence-transformers. "
            "Install it with: pip install layer-context[compression]"
        )


# Singleton model cache
_model_cache = {}

_DEFAULT_MODEL = "all-MiniLM-L6-v2"


def _get_model(model_name: str = _DEFAULT_MODEL):
    if model_name not in _model_cache:
        SentenceTransformer = _import_sentence_transformers()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            # Suppress the BertModel LOAD REPORT and unauthenticated warnings
            logging.disable(logging.WARNING)
            try:
                import torch
                device = "cuda" if torch.cuda.is_available() else "cpu"
                _model_cache[model_name] = SentenceTransformer(model_name, device=device)
            finally:
                logging.disable(logging.NOTSET)
    return _model_cache[model_name]


# ---------------------------------------------------------------------------
# Public: preload / download helpers
# ---------------------------------------------------------------------------

def preload(model_name: str = _DEFAULT_MODEL):
    """Pre-load the embedding model into memory.

    Call this once at application startup to avoid latency on the first
    ``get_compressed_context()`` call::

        from layer_context.compression import preload
        preload()  # downloads model if needed, then loads into RAM

    The model (~80 MB) is downloaded from Hugging Face Hub on the very first
    invocation and cached on disk afterwards.  Subsequent calls are instant.
    """
    _get_model(model_name)


def download_model(model_name: str = _DEFAULT_MODEL):
    """Download the embedding model to the local cache without loading it.

    Useful in CI / Docker builds where you want the model baked into the
    image but don't need it in memory yet::

        layer-context-download          # CLI command (installed with the package)
        # — or —
        from layer_context.compression import download_model
        download_model()
    """
    SentenceTransformer = _import_sentence_transformers()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        SentenceTransformer(model_name)
    print(f"✓ Model '{model_name}' downloaded and cached successfully.")


def _cli_download():
    """Entry point for the ``layer-context-download`` console script."""
    import argparse
    parser = argparse.ArgumentParser(
        description="Download the embedding model used by layer-context compression."
    )
    parser.add_argument(
        "--model",
        default=_DEFAULT_MODEL,
        help=f"Model name (default: {_DEFAULT_MODEL})",
    )
    args = parser.parse_args()
    download_model(args.model)


# ---------------------------------------------------------------------------
# Sentence splitting
# ---------------------------------------------------------------------------

_SENTENCE_RE = re.compile(r'(?<=[.!?])\s+(?=[A-Z])')


def _split_sentences(text: str) -> List[str]:
    """Split text into sentences, preserving newline-delimited lines."""
    lines = text.strip().split("\n")
    sentences = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        parts = _SENTENCE_RE.split(line)
        for p in parts:
            p = p.strip()
            if p:
                sentences.append(p)
    return sentences


# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------

def _estimate_tokens(text: str) -> int:
    """Rough token count: ~4 chars per token (GPT-style heuristic)."""
    return max(1, len(text) // 4)


# ---------------------------------------------------------------------------
# Information Density Scorer (TF-IDF + entity density)
# ---------------------------------------------------------------------------

class InformationDensityScorer:
    """Score sentences by information density using TF-IDF and specificity."""

    def __init__(self, sentences: List[str]):
        self._sentences = sentences
        self._word_lists = [self._tokenize(s) for s in sentences]
        self._idf = self._compute_idf()

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        return re.findall(r'\b[a-zA-Z0-9]+\b', text.lower())

    def _compute_idf(self):
        n = len(self._sentences)
        if n == 0:
            return {}
        df = Counter()
        for words in self._word_lists:
            for w in set(words):
                df[w] += 1
        return {w: math.log(n / count) for w, count in df.items()}

    def score(self, idx: int) -> float:
        """Return density score for sentence at index."""
        words = self._word_lists[idx]
        if not words:
            return 0.0

        # TF-IDF component
        tf = Counter(words)
        tfidf_score = sum(
            (tf[w] / len(words)) * self._idf.get(w, 0.0)
            for w in tf
        )

        # Entity / specificity: ratio of capitalized or numeric tokens
        raw_words = re.findall(r'\b\S+\b', self._sentences[idx])
        specific = sum(
            1 for w in raw_words
            if w[0].isupper() or any(c.isdigit() for c in w)
        )
        specificity = specific / max(len(raw_words), 1)

        return tfidf_score + specificity * 0.5


# ---------------------------------------------------------------------------
# Aggressive Pruning (regex-based filler removal)
# ---------------------------------------------------------------------------

_FILLER_PATTERNS = [
    r'\b(basically|essentially|actually|generally speaking|in general)\b',
    r'\b(it is worth noting that|it should be noted that)\b',
    r'\b(as a matter of fact|in other words|that is to say)\b',
    r'\b(kind of|sort of|more or less|to some extent)\b',
    r'\b(very|really|quite|rather|fairly|pretty much)\b',
    r'\b(I think|I believe|I feel|in my opinion)\b',
    r'\b(for example|for instance|e\.g\.|such as)\s+[^.]*(?=[.!?]|$)',
]

_FILLER_RE = [re.compile(p, re.IGNORECASE) for p in _FILLER_PATTERNS]


def _aggressive_prune(text: str) -> str:
    """Remove filler words, hedge phrases, and example clauses."""
    result = text
    for pattern in _FILLER_RE:
        result = pattern.sub('', result)
    # Clean up extra whitespace
    result = re.sub(r'\s{2,}', ' ', result).strip()
    # Remove trailing/leading punctuation artifacts
    result = re.sub(r'^\s*[,;]\s*', '', result)
    result = re.sub(r'\s*[,;]\s*$', '', result)
    return result


# ---------------------------------------------------------------------------
# TextRank
# ---------------------------------------------------------------------------

def _textrank_scores(similarity_matrix, damping: float = 0.85, iterations: int = 30):
    """Compute TextRank scores from a similarity matrix."""
    np = _import_numpy()
    n = similarity_matrix.shape[0]
    if n == 0:
        return np.array([])
    if n == 1:
        return np.array([1.0])

    # Normalize rows
    row_sums = similarity_matrix.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1.0
    norm_matrix = similarity_matrix / row_sums

    scores = np.ones(n) / n
    for _ in range(iterations):
        new_scores = (1 - damping) / n + damping * norm_matrix.T @ scores
        if np.allclose(scores, new_scores, atol=1e-6):
            break
        scores = new_scores

    return scores


# ---------------------------------------------------------------------------
# Main compression function
# ---------------------------------------------------------------------------

def compress_context(
    text: str,
    query: str,
    target_tokens: Optional[int] = None,
    relevance_threshold: float = 0.3,
    dedup_threshold: float = 0.85,
    aggressive_pruning: bool = False,
) -> str:
    """Compress context text using a multi-stage pipeline.

    Args:
        text: Raw context string to compress.
        query: Topic/question to score relevance against.
        target_tokens: Max token budget. Defaults to ~50% of original.
        relevance_threshold: Min cosine similarity to query to keep a sentence.
        dedup_threshold: Similarity above which sentences are deduplicated.
        aggressive_pruning: If True, strip filler words and verbose phrases.

    Returns:
        Compressed context string with sentences in original order.
    """
    np = _import_numpy()

    if not text or not text.strip():
        return ""
    if not query or not query.strip():
        return text

    # 1. Split into sentences
    sentences = _split_sentences(text)
    if not sentences:
        return ""

    original_tokens = _estimate_tokens(text)
    if target_tokens is None:
        target_tokens = max(1, original_tokens // 2)

    # 2. Encode sentences + query (suppress warnings during inference)
    model = _get_model()
    all_texts = sentences + [query]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        embeddings = model.encode(all_texts, convert_to_numpy=True, show_progress_bar=False)
    sent_embeddings = embeddings[:-1]
    query_embedding = embeddings[-1:]

    # 3. Relevance filter (cosine similarity to query)
    norms_s = np.linalg.norm(sent_embeddings, axis=1, keepdims=True)
    norms_s[norms_s == 0] = 1.0
    norms_q = np.linalg.norm(query_embedding, axis=1, keepdims=True)
    norms_q[norms_q == 0] = 1.0

    cosine_to_query = (sent_embeddings @ query_embedding.T).flatten() / (
        norms_s.flatten() * norms_q.flatten()
    )

    relevant_indices = [
        i for i, sim in enumerate(cosine_to_query) if sim >= relevance_threshold
    ]

    if not relevant_indices:
        # If nothing passes threshold, keep the top 3 most relevant
        top_k = min(3, len(sentences))
        relevant_indices = list(np.argsort(cosine_to_query)[-top_k:])

    # 4. Semantic deduplication
    rel_embeddings = sent_embeddings[relevant_indices]
    norms_r = np.linalg.norm(rel_embeddings, axis=1, keepdims=True)
    norms_r[norms_r == 0] = 1.0
    normed = rel_embeddings / norms_r
    sim_matrix = normed @ normed.T

    kept_mask = [True] * len(relevant_indices)
    for i in range(len(relevant_indices)):
        if not kept_mask[i]:
            continue
        for j in range(i + 1, len(relevant_indices)):
            if not kept_mask[j]:
                continue
            if sim_matrix[i, j] >= dedup_threshold:
                # Keep the one with higher query relevance
                qi = cosine_to_query[relevant_indices[i]]
                qj = cosine_to_query[relevant_indices[j]]
                if qi >= qj:
                    kept_mask[j] = False
                else:
                    kept_mask[i] = False
                    break

    deduped_indices = [
        relevant_indices[i] for i in range(len(relevant_indices)) if kept_mask[i]
    ]

    if not deduped_indices:
        deduped_indices = relevant_indices[:1]

    # 5. Score via TextRank + information density + query relevance
    dedup_embeddings = sent_embeddings[deduped_indices]
    norms_d = np.linalg.norm(dedup_embeddings, axis=1, keepdims=True)
    norms_d[norms_d == 0] = 1.0
    normed_d = dedup_embeddings / norms_d
    textrank_sim = normed_d @ normed_d.T
    np.fill_diagonal(textrank_sim, 0)

    tr_scores = _textrank_scores(textrank_sim)

    density_scorer = InformationDensityScorer(
        [sentences[i] for i in deduped_indices]
    )

    # Normalize scores
    tr_max = tr_scores.max() if tr_scores.max() > 0 else 1.0
    query_relevances = np.array([cosine_to_query[i] for i in deduped_indices])
    qr_max = query_relevances.max() if query_relevances.max() > 0 else 1.0

    combined_scores = []
    for k, idx in enumerate(deduped_indices):
        density = density_scorer.score(k)
        combined = (
            0.4 * (tr_scores[k] / tr_max)
            + 0.35 * (query_relevances[k] / qr_max)
            + 0.25 * min(density, 1.0)
        )
        combined_scores.append((idx, combined))

    # 6. Select top sentences within token budget
    combined_scores.sort(key=lambda x: x[1], reverse=True)

    selected = []
    token_count = 0
    for idx, score in combined_scores:
        sent = sentences[idx]
        sent_tokens = _estimate_tokens(sent)
        if token_count + sent_tokens <= target_tokens:
            selected.append(idx)
            token_count += sent_tokens
        if token_count >= target_tokens:
            break

    if not selected:
        # Always include at least the top sentence
        selected = [combined_scores[0][0]]

    # 7. Reorder by original position
    selected.sort()

    # 8. Apply aggressive pruning if requested
    result_sentences = [sentences[i] for i in selected]
    if aggressive_pruning:
        result_sentences = [_aggressive_prune(s) for s in result_sentences]
        result_sentences = [s for s in result_sentences if s]

    return "\n".join(result_sentences)
