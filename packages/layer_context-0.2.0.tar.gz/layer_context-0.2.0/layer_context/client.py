"""ContextLayer Python SDK client."""

import requests
import hashlib
import base64
import os
import re
from typing import Optional, List, Dict, Any

from cryptography.fernet import Fernet


def _derive_fernet_key(passphrase: str) -> bytes:
    """Derive a Fernet-compatible key from a passphrase using SHA-256."""
    digest = hashlib.sha256(passphrase.encode("utf-8")).digest()
    return base64.urlsafe_b64encode(digest)


class CLError(Exception):
    """Base exception for ContextLayer SDK errors."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class Block:
    """Handle for interacting with a specific block."""

    def __init__(self, client: "CL", name: str):
        self._client = client
        self.name = name

    def append(self, content: str, version: int = 1) -> Dict[str, Any]:
        """Append content to this block version."""
        return self._client._post(
            f"/blocks/{self.name}/append",
            {"content": self._client._encrypt(content), "version": version},
        )

    def update(self, content: str, version: int = 1) -> Dict[str, Any]:
        """Replace all context in this block version."""
        return self._client._post(
            f"/blocks/{self.name}/update",
            {"content": self._client._encrypt(content), "version": version},
        )

    def delete(self, content: str, version: int = 1) -> Dict[str, Any]:
        """Delete matching content from this block version."""
        return self._client._post(
            f"/blocks/{self.name}/delete",
            {"content": self._client._encrypt(content), "version": version},
        )

    def get_context(self, version: int = 1) -> str:
        """Get compiled context string for this block version."""
        data = self._client._get(
            f"/blocks/{self.name}/context", params={"version": version}
        )
        raw = data.get("context", "")
        return self._client._decrypt(raw) if raw else ""

    def get_history(self, version: int = 1) -> List[Dict[str, Any]]:
        """Get entry history for this block version."""
        return self._client._get(
            f"/blocks/{self.name}/history", params={"version": version}
        )

    def create_version(self) -> Dict[str, Any]:
        """Create a new version of this block."""
        return self._client._post(f"/blocks/{self.name}/versions", {})

    def get_compressed_context(
        self,
        query: str,
        version: int = 1,
        target_tokens: Optional[int] = None,
        relevance_threshold: float = 0.3,
        dedup_threshold: float = 0.85,
        aggressive_pruning: bool = False,
    ) -> str:
        """Get compressed context optimized for a given query.

        Uses a local compression pipeline (sentence embeddings, TextRank,
        TF-IDF) to reduce context size while preserving relevance.

        Requires: pip install layer-context[compression]

        Args:
            query: Topic/question to optimize relevance for (required).
            version: Block version to compress (default 1).
            target_tokens: Max token budget. Defaults to ~50% of original.
            relevance_threshold: Min cosine similarity to keep a sentence (default 0.3).
            dedup_threshold: Similarity above which sentences are deduplicated (default 0.85).
            aggressive_pruning: Strip filler words and verbose phrases (default False).

        Returns:
            Compressed context string.
        """
        from .compression import compress_context

        raw = self.get_context(version)
        if not raw:
            return ""
        return compress_context(
            text=raw,
            query=query,
            target_tokens=target_tokens,
            relevance_threshold=relevance_threshold,
            dedup_threshold=dedup_threshold,
            aggressive_pruning=aggressive_pruning,
        )

    def __repr__(self) -> str:
        return f"Block(name={self.name!r})"


BLOCK_NAME_RE = re.compile(r"^[a-zA-Z0-9_.\-]+$")


class CL:
    """ContextLayer SDK client.

    Usage::

        from layer_context import CL

        cl = CL(api_key="cl_sk_your_key_here")
        cl.create_block("support_faq")
        block = cl.block("support_faq")
        block.append("How do I reset my password? Go to settings > security.")
        print(block.get_context())
    """

    DEFAULT_BASE_URL = "https://btzlqtczxsjbzuvtwamc.supabase.co/functions/v1/context-api"

    def __init__(self, api_key: str, base_url: Optional[str] = None):
        if not api_key:
            raise CLError("API key is required")
        self._api_key = api_key
        self._base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            }
        )

        # Encryption is always enabled, derived from the API key
        self._fernet = Fernet(_derive_fernet_key(api_key))

    # ── Encryption helpers ────────────────────────────────

    def _encrypt(self, plaintext: str) -> str:
        """Encrypt content before sending to server."""
        return self._fernet.encrypt(plaintext.encode("utf-8")).decode("utf-8")

    def _decrypt(self, ciphertext: str) -> str:
        """Decrypt content received from server."""
        try:
            return self._fernet.decrypt(ciphertext.encode("utf-8")).decode("utf-8")
        except Exception:
            # If decryption fails, content may not be encrypted - return raw
            return ciphertext

    # ── HTTP helpers ──────────────────────────────────────

    def _get(self, path: str, params: Optional[Dict] = None) -> Any:
        url = f"{self._base_url}{path}"
        resp = self._session.get(url, params=params)
        return self._handle_response(resp)

    def _post(self, path: str, body: Dict) -> Any:
        url = f"{self._base_url}{path}"
        resp = self._session.post(url, json=body)
        return self._handle_response(resp)

    def _delete_request(self, path: str) -> Any:
        url = f"{self._base_url}{path}"
        resp = self._session.delete(url)
        return self._handle_response(resp)

    @staticmethod
    def _handle_response(resp: requests.Response) -> Any:
        try:
            data = resp.json()
        except ValueError:
            raise CLError(f"Invalid response from server: {resp.text}", resp.status_code)

        if not resp.ok:
            msg = data.get("error", "Unknown error") if isinstance(data, dict) else str(data)
            raise CLError(msg, resp.status_code)

        return data

    # ── Validation helpers ────────────────────────────────

    @staticmethod
    def _validate_block_name(name: str) -> str:
        if not isinstance(name, str) or not name.strip():
            raise CLError("Block name is required and cannot be empty.")
        name = name.strip()
        if len(name) > 100:
            raise CLError("Block name must be 100 characters or fewer.")
        if " " in name:
            raise CLError(
                f"Block name '{name}' contains spaces. "
                "Use underscores, dashes, or dots instead (e.g., 'my_block')."
            )
        if not BLOCK_NAME_RE.match(name):
            raise CLError(
                f"Block name '{name}' contains invalid characters. "
                "Only letters, numbers, underscores, dashes, and dots are allowed."
            )
        return name

    @staticmethod
    def _validate_content(content: str) -> str:
        if not isinstance(content, str) or not content:
            raise CLError("Content is required and cannot be empty.")
        if len(content) > 100_000:
            raise CLError("Content exceeds the 100KB size limit.")
        return content

    @staticmethod
    def _validate_version(version: int) -> int:
        if not isinstance(version, int) or version < 1 or version > 10_000:
            raise CLError("Version must be an integer between 1 and 10,000.")
        return version

    # ── Block operations ──────────────────────────────────

    def create_block(self, name: str) -> Dict[str, Any]:
        """Create a new block in the project."""
        name = self._validate_block_name(name)
        return self._post("/blocks", {"name": name})

    def delete_block(self, name: str) -> Dict[str, Any]:
        """Delete a block and all its versions and entries."""
        name = self._validate_block_name(name)
        return self._delete_request(f"/blocks/{name}")

    def block(self, name: str) -> Block:
        """Get a handle for an existing block."""
        return Block(self, name)

    def list_blocks(self) -> List[Dict[str, Any]]:
        """List all blocks in the project."""
        return self._get("/blocks")

    # ── Convenience shortcuts (flat API) ──────────────────

    def append(self, block_name: str, content: str, version: int = 1) -> Dict[str, Any]:
        """Append content to a block."""
        self._validate_content(content)
        self._validate_version(version)
        return self.block(block_name).append(content, version)

    def update(self, block_name: str, content: str, version: int = 1) -> Dict[str, Any]:
        """Replace all context in a block."""
        self._validate_content(content)
        self._validate_version(version)
        return self.block(block_name).update(content, version)

    def delete(self, block_name: str, content: str, version: int = 1) -> Dict[str, Any]:
        """Delete matching content from a block."""
        self._validate_content(content)
        self._validate_version(version)
        return self.block(block_name).delete(content, version)

    def get(self, block_name: str, version: int = 1) -> str:
        """Get compiled context for a block."""
        self._validate_version(version)
        return self.block(block_name).get_context(version)

    def history(self, block_name: str, version: int = 1) -> List[Dict[str, Any]]:
        """Get entry history for a block."""
        self._validate_version(version)
        return self.block(block_name).get_history(version)

    def create_version(self, block_name: str) -> Dict[str, Any]:
        """Create a new version of a block."""
        return self.block(block_name).create_version()

    def get_compressed(
        self,
        block_name: str,
        query: str,
        version: int = 1,
        target_tokens: Optional[int] = None,
        relevance_threshold: float = 0.3,
        dedup_threshold: float = 0.85,
        aggressive_pruning: bool = False,
    ) -> str:
        """Get compressed context for a block (convenience shortcut).

        See Block.get_compressed_context() for full documentation.
        """
        return self.block(block_name).get_compressed_context(
            query=query,
            version=version,
            target_tokens=target_tokens,
            relevance_threshold=relevance_threshold,
            dedup_threshold=dedup_threshold,
            aggressive_pruning=aggressive_pruning,
        )

    def compress_prompt(self, prompt: str, rate: float = 40.0) -> str:
        """Compress a prompt by a given percentage while preserving meaning.

        This method compresses the raw prompt text at token level,
        removing redundant tokens while keeping the semantic meaning intact.
        No context blocks are involved - this operates directly on any string.

        Args:
            prompt: The input prompt string to compress.
            rate: Compression rate as a percentage (0-100). Default is 40%.
                  A rate of 40 means remove ~40% of tokens, keeping ~60%.

        Returns:
            The compressed prompt string.

        Example::

            cl = CL(api_key="cl_sk_...")
            compressed = cl.compress_prompt(
                "You are a helpful AI assistant that always responds politely...",
                rate=50,
            )
        """
        from .prompt_compression import compress_prompt
        return compress_prompt(prompt, rate)
