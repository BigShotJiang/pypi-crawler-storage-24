"""Prompt compression for ContextLayer SDK.

Uses token-level compression to reduce prompt size while preserving
meaning and accuracy. All processing runs locally on your machine.
"""

import os
import sys
import warnings
import logging

# Suppress all noisy output from dependencies
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")
os.environ.setdefault("SAFETENSORS_FAST_GPU", "1")

for _logger_name in (
    "llmlingua",
    "transformers",
    "huggingface_hub",
    "huggingface_hub.utils",
    "tokenizers",
    "torch",
    "sentence_transformers",
    "safetensors",
):
    logging.getLogger(_logger_name).setLevel(logging.CRITICAL)


# Singleton compressor cache
_compressor_cache = {}

_DEFAULT_MODEL = "microsoft/llmlingua-2-bert-base-multilingual-cased-meetingbank"


def _get_compressor(model_name: str = _DEFAULT_MODEL):
    """Lazily load and cache the prompt compressor."""
    if model_name not in _compressor_cache:
        # Suppress all output during model loading
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            old_stderr = sys.stderr
            sys.stderr = open(os.devnull, "w")
            logging.disable(logging.WARNING)
            try:
                from llmlingua import PromptCompressor
                import torch
                device = "cuda" if torch.cuda.is_available() else "cpu"
                _compressor_cache[model_name] = PromptCompressor(
                    model_name=model_name,
                    use_llmlingua2=True,
                    device_map=device
                )
            finally:
                logging.disable(logging.NOTSET)
                sys.stderr.close()
                sys.stderr = old_stderr
    return _compressor_cache[model_name]


def compress_prompt(prompt: str, rate: float = 40.0) -> str:
    """Compress a prompt by a given percentage while preserving meaning.

    Args:
        prompt: The input prompt string to compress.
        rate: Compression rate as a percentage (0-100). Default is 40%.
              A rate of 40 means remove ~40% of tokens, keeping ~60%.

    Returns:
        The compressed prompt string.
    """
    if not prompt or not prompt.strip():
        return prompt

    # Clamp rate to valid range
    rate = max(0.0, min(100.0, float(rate)))

    if rate == 0:
        return prompt

    # LLMLingua's `rate` = ratio of tokens to KEEP
    keep_ratio = 1.0 - (rate / 100.0)
    # Ensure we keep at least some tokens
    keep_ratio = max(0.05, keep_ratio)

    compressor = _get_compressor()

    # Suppress all output during compression
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = open(os.devnull, "w")
        sys.stderr = open(os.devnull, "w")
        try:
            result = compressor.compress_prompt(
                prompt,
                rate=keep_ratio,
                force_tokens=["\n", ".", "?", "!", ",", "'", '"'],
            )
        finally:
            sys.stdout.close()
            sys.stderr.close()
            sys.stdout = old_stdout
            sys.stderr = old_stderr

    return result.get("compressed_prompt", prompt)
