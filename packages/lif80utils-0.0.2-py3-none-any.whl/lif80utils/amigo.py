#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import gpib
import time # sleep

class Amigo:
    """This class implements the amigo command set."""

    # https://linux-gpib.sourceforge.io/doc_html/reference-function-ibeot.html
    # If send_eoi is non-zero, then the EOI line will be asserted with
    # the last byte sent by calls to ibwrt() and related functions.
    EOT = 1

    # https://linux-gpib.sourceforge.io/doc_html/reference-function-ibeos.html
    # The least significant 8 bits of eosmode specify the eos character. You may
    # also bitwise-or one or more of the following bits to set the eos mode:
    REOS = 0x400 # Enable termination of reads when eos character is received.
    XEOS = 0x800 # Assert the EOI line whenever the eos character is sent during writes.
    BIN = 0x1000 # Match eos character using all 8 bits (instead of only looking at the 7 least significant bits).

    def __init__ ( self, board, pad):
        self.ppmask = 0x80 >> pad

        self.con_00 = gpib.dev( board, pad, 0x60 + 0x00, gpib.T1s,   0) # Receive Data
        self.con_08 = gpib.dev( board, pad, 0x60 + 0x08, gpib.T10s, self.EOT) # Unbuffered
        self.con_09 = gpib.dev( board, pad, 0x60 + 0x09, gpib.T10s, self.EOT) # Buffered Write
        self.con_0A = gpib.dev( board, pad, 0x60 + 0x0A, gpib.T1s, self.EOT) # Buffered Read
        self.con_0C = gpib.dev( board, pad, 0x60 + 0x0C, gpib.T10s, self.EOT) # REQU PHY, FORMAT
        self.con_10 = gpib.dev( board, pad, 0x60 + 0x10, gpib.T1s, self.EOT) # DSJ (Device Specified Jump)
        self.con_1E = gpib.dev( board, pad, 0x60 + 0x1E, gpib.T1s, self.EOT) # Write/Read Loopback

        self.con_1F = gpib.dev( board, pad, 0x60 + 0x1F, gpib.T1s, self.EOT,    0) # Write/Read Loopback # 10011

    def __del__(self):
        self.end( )

        gpib.close( self.con_00)
        gpib.close( self.con_08)
        gpib.close( self.con_09)
        gpib.close( self.con_0A)
        gpib.close( self.con_0C)
        gpib.close( self.con_10)
        gpib.close( self.con_1E)
        gpib.close( self.con_1F)

    def dsj ( self):
        return gpib.read( self.con_10, 1)

    # Request Status
    def request_status ( self, unit = 0):
        gpib.write \
            ( self.con_08
            ,   b'\x03'
              + unit    .to_bytes( 1, 'big')
            )

        dsj = self.dsj( )

        if b'\x00' != dsj:
            print( f"{dsj} REQUEST STATUS")
            return

        return gpib.read( self.con_08, 4)

    # Read Self-Test
    def read_self_test ( self):
        return gpib.read( self.con_1F, 2)

    # Write Loopback
    def write_loopback ( self, data):
        gpib.write( self.con_1E, data)

    # Read Loopback
    def read_loopback ( self):
        return gpib.read( self.con_1E, 255)

    # Seek
    def seek ( self, unit = 0, cylinder = 0, head = 0, sector = 0):
        # Seek can need more then 1s timeout.
        gpib.write \
            ( self.con_08
            ,   b'\x02'
              + unit    .to_bytes( 1, 'big')
              + cylinder.to_bytes( 2, 'big')
              + head    .to_bytes( 1, 'big')
              + sector  .to_bytes( 1, 'big')
            )

        dsj = self.dsj( )

        if b'\x00' != dsj:
            print( f"{dsj} SEEK")

        return dsj

    # Buffered Read
    def buffered_read ( self, unit = 0):
        gpib.write \
            ( self.con_0A
            ,   b'\x05'
              + unit    .to_bytes( 1, 'big')
            )

        dsj = self.dsj( )

        if b'\x00' != dsj:
            print( f"{dsj} READ")

        return dsj

    #
    def receive ( self, size = 256):
        res = gpib.read( self.con_00, size)
        return res

    # Request (Logical) Disc Address
    def request_logical ( self):
        gpib.write \
            ( self.con_08
            ,   b'\x14\x00'
            )

        dsj = self.dsj( )

        if b'\x00' != dsj:
            print( f"{dsj} REQU LOG")
            return

        return gpib.read( self.con_08, 4)

    # Request (Physical) Disc Address
    def request_physical ( self):
        gpib.write \
            ( self.con_0C
            ,   b'\x14\x00'
            )

        dsj = self.dsj( )

        if b'\x00' != dsj:
            print( f"{dsj} REQU PHY")
            return

        return gpib.read( self.con_08, 4)

    # End
    def end ( self):
        gpib.write \
            ( self.con_08
            ,   b'\x15\x00'
            )

        dsj = self.dsj( )

        if b'\x00' != dsj:
            print( f"{dsj} END")

        return

    # Buffered Write
    def buffered_write ( self, unit = 0):
        gpib.write \
            ( self.con_09
            ,   b'\x08'
              + unit    .to_bytes( 1, 'big')
            )

        dsj = self.dsj( )

        if b'\x00' != dsj:
            print( f"{dsj} WRITE")

        return dsj

    #
    def send ( self, buf):
        gpib.write \
            ( self.con_00
            , buf
            )

        dsj = self.dsj( )

        if b'\x00' != dsj:
            print( f"{dsj} send")

        return dsj

    # Format
    def request_format ( self, unit, option, interleave, databyte):
        gpib.write \
            ( self.con_0C
            ,   b'\x18'
              + unit    .to_bytes( 1, 'big')
              + option  .to_bytes( 1, 'big')
              + interleave.to_bytes( 1, 'big')
              + databyte.to_bytes( 1, 'big')
            )

        # Formatting needs around 18 sec on my 9121D and around 90 sec on my 9123D.
        # (The manual states that the 9123D is doing verification as well)
        # time.sleep( 18)

        # DSJ (QSTAT) will timeout regardless of the timeout settings.
        # Added my own ibrpp call to python.
        # TODO: Check if I made a mistake with timout or wait.

        # Parallel poll is used as an additional means of communication between the 9121D/S and the
        # Bus Controller. If the 9121D/S is ready to accept the next part of a command sequence, it will
        # respond to the parallel poll conducted by the Bus Controller.

        # Execution
        # Reporting
        while True:
            # ppres = gpib.parallel_poll( 0) # board
            ppres = gpib.parallel_poll( self.con_0C) # device
            print( f"{ppres:08b} {ppres:02x} {self.ppmask:02x}")
            if self.ppmask & ppres:
                break
            time.sleep( 1)

        dsj = self.dsj( )

        if b'\x00' != dsj:
            print( f"{dsj} REQUEST FORMAT")

        return


    # Initiate Selftest
    def initiate_selftest ( self):
        gpib.write \
            ( self.con_1F
            ,   b'\x00' # Ignored by the 9121D/S
                b'\x00' # 0000W000, 0 = no format test, 1 = format test
            #     b'\x08' # 0000W000, 0 = no format test, 1 = format test
            )

        time.sleep( 8)

        # Execution
        # Reporting
        while True:
            # ppres = gpib.parallel_poll( 0) # board
            ppres = gpib.parallel_poll( self.con_1F) # device
            print( f"{ppres:08b} {ppres:02x} {self.ppmask:02x}")
            if self.ppmask & ppres:
                break
            time.sleep( 1)




        dsj = self.dsj( )

        if b'\x00' != dsj:
            print( f"{dsj} INITIATE SELFTEST")

        return
