#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys
import argparse
import os   # path
import stat # S_ISBLK
import time

from . import encfocal
from .lif import LifVolume
from .target import Target

def main ( ) -> int:
    # Parse the command line arguments.
    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Initialize a storage media'
        )

    parser.add_argument( "destination", nargs='?', default="")

    # codepage: 'ascii', 'cp1252', 'utf-8', 'focal'
    parser.add_argument( "-c", "--codepage", help="codepage", default="focal")
    parser.add_argument( "-m", "--mass-storage", help="MASS STORAGE IS", default=os.getenv( 'MASS_STORAGE', ":."))

    # ExtendedMassStorageROM-OwnersManual-80Series-00085-91066-18pages-Apr85.pdf
    # | HP-85B    | 5
    # | HP-86A/B  | 5
    # | HP-87A/XM | 6
    parser.add_argument( "-i", "--interleave", help="interleave factor", type=int, default=4)
    parser.add_argument( "-f", "--format", help="format option", type=int, default=0)
    parser.add_argument( "-d", "--directory-size", help="number of records be used for the file directory", type=int, default=14)
    parser.add_argument( "-l", "--label", help="volume label", type=str, default="HPLIF")

    # Appendix A
    # HP Flexible Disc Drive Command Set
    # 9121D/S
    # The data byte must never be OF5H, OF6H, or OF7H.
    parser.register( 'type', 'hex', lambda s: int( s, 16))
    parser.add_argument( "-b", "--databyte", help="data byte must never be OxF5, OxF6, or OxF7 (default: 0x%(default)02X)", type='hex', default=0xDB)
    # 9123D/S 270336
    # 9121D/S 286720 with two spare tracks
    parser.add_argument( "-s", "--size", help="size of the image in bytes", type=int, default=270336)

    parser.add_argument( "-q", "--quick", help="only rewrite the directory", action="store_true")

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-x", "--extended", help="extended mode", action="store_true")

    args = parser.parse_args( )

    # init only writes to a target.
    target = Target( args.destination, args)

    # The HP85 is ignoring a file name and format anyway.
    # INITIALIZE "TEST", "TEST:D700"

    # if target.file_name_dec:
    #     print( "Error 67 : FILE NAME")
    #     return -1

    if not target.image:
        print( "Error 126 : MSUS")
        return -1

    # Start timer
    start_time = time.time( )

    # It seems to make no difference what type is used. The result is always the same.

    # 9133_9134_9135_9121_9122_ServiceDocumentation_509pages_1985.pdf
    # Page A-36 (467)
    # Fixed as 2
    # The data byte must never be 0xF5, 0xF6, 0xF7

    # amigo-command-set-ocr.pdf
    # A-50 (50)
    # 2 - HP
    # 8 - IBM

    # Interleave 4 is best, next is 5. Of course that depends on the whole hardware chain.

    # Format the medium.
    if not args.quick:
        target.request_format( )

    # return 0

    raw_target = target.get_raw_file( )

    # Write the Volume Sector.
    raw_target.seek( 0, 0) # TODO: Needed for phys disc?

    vol_label = f"{args.label:6}".encode( args.codepage)
    no_dir_sectors = args.directory_size

    vol = LifVolume \
        ( b'\x80\x00\x48\x50\x4c\x49\x46\x20\x00\x00\x00\x02\x10\x00\x00\x00' \
          b'\x00\x00\x00\x0f\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        + b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' * 14
        )

    vol.writeable( )
    vol.vol_label( vol_label)
    vol.no_dir_sectors( no_dir_sectors)
    vol.readonly( )

    raw_target.write( vol.volume_sector)

    raw_target.write \
        ( b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' * 16
        )

    # Write the Directory Sectors.
    for _ in range( no_dir_sectors):
        raw_target.write \
            ( b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\x00\x00\x00\x00'
            b'\x00\x00\xff\x7f\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' * 8
            )

    # End timer
    end_time = time.time( )

    if args.verbose:
        print( f"Elapsed time: {end_time - start_time}")

    return 0
