#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys

def decode_0001 ( infile, codepage = 'focal', verbose = False):

# MAIN.. .................
# 4D 41 49 4E 00 00 20 1B 06 00 00 00 00 00 00 00 00 00 00 00 00 80 00 00

# HP 85 Assembler ROM source code internal format
# https://groups.io/g/hpseries80/wiki/20863
# MAIN NUL NUL    Program name
    program_name = infile.read( 6)
# 20              Program type (MAIN, BASIC, ALLOCATED)
    program_type = int.from_bytes( infile.read( 1), byteorder='little')
# 1B 06       Program length (061B = 1563 bytes total)
    program_length = int.from_bytes( infile.read( 2), byteorder='little')
# 00...       12 decimal bytes of NUL (unused)
    infile.read( 12)
# 80          Security bits
    security_bits = int.from_bytes( infile.read( 1), byteorder='little')
# 00 00       No security code
    security_code = infile.read( 2)

    if verbose:
        print( f"Program name {program_name} type {program_type:x} length {program_length} Security bits {security_bits:x} code {security_code}")

    program_length = program_length - 24
    length = 24

    while True:
# 01 00 | 1E | FE | 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A 2A | 0E
# 01 00       BCD line# = 0001 = 1
        line_number = int( infile.read( 2)[::-1].hex( ))
# 1E          len of this line of 'code'
        line_length = int.from_bytes( infile.read( 1), byteorder='little')

        line = infile.read( line_length)

        if verbose:
            print( f"line {line_number} {line_length:x} {line}")

        # Check and remove the EOL token.
        eol = line[-1:]
        line = line[:-1]

        if verbose:
            print( f"line {line} EOL {eol}")

        if b'\x0e' != eol:
            print( f"EOL {eol}")
            # TODO: Error

        # program_length = program_length - line_length - 3
        program_length -= line_length + 3
        length += line_length + 3

# FE          Assembler ROM's COMMENT 'token'
# 2A 2A...    ASCII comment (line of *'s) term'd by 0E
# 0E          octal 16, END-OF-LINE token

# 20 00 | 0C | 47 4C 4F | FF | 47 4C 4F 42 41 4C 20 | 0E
# FF          Assembler ROM's LABEL 'token'
# ..GLOÿGLOBAL.

        label = ""
        comment = ""
        opcode = ""
        arguments = ""

        # Find a comment.
        comment_pos = line.find( b'\xFE')

        # Found a comment.
        if 0 <= comment_pos:
            comment = f"{line[comment_pos+1:].decode( codepage)}"
            line = line[:comment_pos]

        if verbose:
            print( f"comment {comment} line {line}")

        # Found a comment only line.
        if 0 == comment_pos:
        # if not line:
            yield f"{line_number} !{comment}\n"
            continue

        # There is a label.
        if 0xFF == line[0]:
            label = line[1:7].decode( codepage)
            line = line[7:]

            if verbose:
                print( f"label {label} line {line}")

        # Opcode.
        if True:
            opcode = line[0:3].decode( codepage)
            line = line[3:]

            if verbose:
                print( f"opcode {opcode} line {line}")

        # Find another label.
        label_pos = line.find( b'\xFF')

        # Found another label.
        if 0 <= label_pos:
            line = line[:label_pos] + line[label_pos + 1:]

        if verbose:
            print( f"line {line}")

        if line:
            arguments = line.decode( codepage)
            line = ""

        # TODO: Maybe conflict with DEF <label>
        if "DR" == arguments[0:2]:
            arguments = arguments[:1] + " " + arguments[1:]
        else:
            arguments = " " + arguments

        # After being parsed, a comment which has been entered immediately following the
        # other elements of the line begins in column 33;
        line = f"{line_number} {label:6s} {opcode:3s}{arguments}"

        if comment:
            yield f"{line:32s}!{comment}\n"
        else:
            yield f"{line}\n"

# Another 5 bytes in the file.
# 99 A9 02 19 0E
# Constant, same also for all PGM files.
# Rest of block filled with garbage.

# https://groups.io/g/hpseries80/wiki/1893
# HP 85 System ROMs [Memory Layout (and Tokens and Allocation and...)]
# 231 251 002 031 016             (A999 len=2 STOP EOL)

# HP LIF/assets/attachments/parse_hp85.c.txt
# case 0031:
#     printf("<\\031 END>\n");
#     break;

# This is simple the tokenized END statement from Basic.
# Probably it is also used by the editor to detect the end of the program.

# https://archived.hpcalc.org/greendyk/hp85/83.html
# The END statement should be the highest numbered statement in a program. It
# not only tells the computer where a program ends, but also terminates program
# execution. (You may also use the STOP statement; on the HP-85 both END and
# STOP perform exactly the same function. END is provided on the HP-85 for
# compatibility with other BASIC systems.)

        # print( f"{program_length} {length}")

        if 5 == program_length:
            break

