#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import os   # path

def split ( file_spec: str, args):
    # If there is no file specifier or the file specifier is empty use MASS STORAGE IS.
    # Solves "AttributeError: 'NoneType' object has no attribute 'partition'"
    if not file_spec:
        file_spec = args.mass_storage

    # Split the file specifier into file name and lifpath.
    file_name_dec, _, image = file_spec.partition( ':')

    if args.verbose:
        print( f">{file_name_dec}< >{image}<")

    # No MSUS specified.
    # There are two possibilites:

    # - Try if can make sense out of a Linux path (experimental).
    if args.extended:
        if not image:
            if os.path.isdir( file_name_dec):
                image = file_name_dec
                file_name_dec = ""
            # If it is not a dir it must be a filename.
            else:
                image = os.path.dirname( file_name_dec)
                file_name_dec = os.path.basename( file_name_dec)

    # - Use MASS STORAGE IS which will leave us with the file specifiers syntax.
    if not image:
        image = args.mass_storage[1:]

    if args.verbose:
        print( f">{file_name_dec}< >{image}<")

    return file_name_dec, _, image
