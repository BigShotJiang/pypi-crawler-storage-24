#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys
import argparse
import os

from . import encfocal

from .decode_0001 import decode_0001
from .decode_E010 import decode_E010

def main ( ) -> int:

    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Convert a LIF file into a plain text file, supported file types are 0001 (85ASM) and E010 (DTA8x)'
        )

    parser.add_argument( "source")

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-x", "--extended", help="extended mode", action="store_true")
    parser.add_argument( "-c", "--codepage", help="codepage", default="focal")

    args = parser.parse_args( )

    with open( args.source, "rb") as source:

        filepath = args.source
        filename = os.path.basename( filepath)
        basename, _, extension = filename.partition( '.')

        if extension not in [ "0001", "E010"]:
            print( "Unknown file type")
            return -1

        decode = eval( f"decode_{extension}")

        for line in decode( source, codepage = args.codepage, verbose = args.verbose):
            print( line, end='')


    return 0
