#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys
import argparse
import os

from .source import Source

def main ( ) -> int:
    # Parse the command line arguments.
    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Lists the file directory of a storage media'
        )

    # Optional with MASS STORAGE IS set.
    parser.add_argument( "source", nargs='?', help=":lifpath")

    # codepage: 'ascii', 'cp1252', 'utf-8', 'focal'
    parser.add_argument( "-c", "--codepage", help="codepage", default="focal")
    parser.add_argument( "-m", "--mass-storage", help="MASS STORAGE IS", default=os.getenv( 'MASS_STORAGE', ":."))

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-x", "--extended", help="extended mode", action="store_true")

    args = parser.parse_args( )

    # cat reads only from a source.
    source = Source( args.source, args)
    source.open( )

    # cat does not take a file name.
    if source.file_name_dec:
        print( "Error 126 : MSUS")
        return -1

    # Print volume label and header.
    print( f"[ Volume ]: {source.get_volume_label( )}")

    if args.extended:
        print( "Name        Type  Bytes   Recs  Start   Size  BSize  YYMMDDHHmmSS")
    else:
        print( "Name        Type  Bytes   Recs")

    # Walk through the directory and print the file information.
    for d in source.get_dir_entries( ):
        if args.extended:
            print( f"{d.file_name( ).decode( args.codepage):10}  {d.file_type( ):04X}  {d.bytes_per_record( ):5}  {d.file_length( ):5}  {d.file_start( ):5}  {d.bytes_per_file( ):5}  {d.bytes_per_record( ) * d.file_length( ):5}  {d.creation_date( )}")
        else:
            if 0x0000 == d.file_type( ):
                file_name = ""
            else:
                file_name = d.file_name( ).decode( args.codepage)

            print( f"{file_name:10}  {d.file_type_str( )}  {d.bytes_per_record( ):5}  {d.file_length( ):5}")

    return 0
