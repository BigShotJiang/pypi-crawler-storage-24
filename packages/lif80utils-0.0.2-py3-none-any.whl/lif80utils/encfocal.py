#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

from . import focal
import codecs

def search_function ( encoding):
    if encoding == 'focal':
        return focal.getregentry( )
    return None

def combined_decoder ( unicode_error):
    data = unicode_error.object[unicode_error.start:unicode_error.end]

    # 0x02	0x0078+0x0305	# LATIN SMALL LETTER X WITH COMBINING OVERLINE	#  ̅x	HP
    if   b'\x02' == data: new_char = u"\u0305\u0078"
    # 0x03	0x0274+0x0305	# LATIN LETTER SMALL CAPITAL N WITH COMBINING OVERLINE	#  ̅ɴ	HP
    elif b'\x03' == data: new_char = u"\u0305\u0274"
    # 0x07	0x006E+0x0305	# LATIN SMALL LETTER N WITH COMBINING OVERLINE	#  ̅n	HP
    elif b'\x07' == data: new_char = u"\u0305\u006E"
    else:                 new_char = u"~"

    return new_char, unicode_error.start + 1

# Register the search_function in the Python codec registry
codecs.register( search_function)
codecs.register_error( 'combined', combined_decoder)
