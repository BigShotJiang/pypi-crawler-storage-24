#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys  # exit, buffer
import argparse
import os   # path
import stat # S_ISBLK
import time

from .source import Source
from .target import Target

def main ( ) -> int:
    # Parse the command line arguments.
    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Hex or binary dump of a storage media'
        )

    parser.add_argument( "source", nargs='?', help=":lifpath")
    parser.add_argument( "destination", nargs='?', help=":lifpath")

    # codepage: 'ascii', 'cp1252', 'utf-8', 'focal'
    parser.add_argument( "-c", "--codepage", help="codepage", default="focal")
    parser.add_argument( "-m", "--mass-storage", help="MASS STORAGE IS", default=os.getenv( 'MASS_STORAGE', ":."))

    parser.add_argument( "-b", "--binary", help="dump a binary image", action="store_true")

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-x", "--extended", help="extended mode", action="store_true")

    args = parser.parse_args( )

    # Instantiate source and target
    source = Source( args.source, args)

    if source.file_name_dec:
        print( "Error 67 : FILE NAME")
        return -1

    if not source.image:
        print( "Error 126 : MSUS")
        return -1

    raw_source = source.vol.file

    if args.destination:
        target = Target( args.destination, args)
        raw_target = target.get_raw_file( )
    else:
        raw_target = sys.stdout.buffer

    # Dump!
    raw_source.seek( 0)

    # TODO: In this case this is probably more likely the buffer size.
    # TODO: Does it matter?
    SECTOR_SIZE = 256
    addr = 0

    # Start timer.
    start_time = time.time( )

    # The 9121 will stuck without returning an error.
    # while True:
    for n in range( 1120):
        # try:
            if args.verbose:
                print( f"SEC {n:04}")

                # log = raw_source.amigo.request_logical( )
                # print( f"LOG C {int.from_bytes( log[0:2], byteorder='big'):02} H {log[2]} S {log[3]:02}")
                raw_source.tell( )

                phy = raw_source.amigo.request_physical( )
                print( f"PHY C {int.from_bytes( phy[0:2], byteorder='big'):02} H {phy[2]} S {phy[3]:02}")

            res = raw_source.read( SECTOR_SIZE)

            if args.verbose:
                print( f"requested {SECTOR_SIZE} received {len( res)}")

            if SECTOR_SIZE == len( res):
                if args.binary:
                    raw_target.write( res)
                else:
                    for n in range( 0, 256, 16):
                        row = res[n:n+16]
                        print( f"{addr:06x}: {row[0x00]:02x} {row[0x01]:02x} {row[0x02]:02x} {row[0x03]:02x} {row[0x04]:02x} {row[0x05]:02x} {row[0x06]:02x} {row[0x07]:02x} {row[0x08]:02x} {row[0x09]:02x} {row[0x0A]:02x} {row[0x0B]:02x} {row[0x0C]:02x} {row[0x0D]:02x} {row[0x0E]:02x} {row[0x0F]:02x}  {''.join([chr(i) if 32 <= i < 127 else '.' for i in row])}")
                        addr = addr + 16
            else:
                # print( f"{len( res)}")
                break

        # except:
        #     print( "Oops!")
        #     return -1
        # except Exception as inst:
        #     print(type(inst))    # the exception type
        #     print(inst.args)     # arguments stored in .args
        #     print(inst)          # __str__ allows args to be printed directly,
        #                          # but may be overridden in exception subclasses
        #     return -1

    # End timer
    end_time = time.time( )

    if args.verbose:
        # The elapsed time also includes the seek time needed for the initial positioning of the head to the first sector.
        print( f"Elapsed time: {end_time - start_time}")

    return 0

