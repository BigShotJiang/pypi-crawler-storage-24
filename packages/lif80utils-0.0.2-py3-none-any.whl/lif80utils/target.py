#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys  # exit
import os   # path
import stat # S_ISBLK

from . import encfocal
from . lif import LifImage, LifDirectory

#
#
#

class TargetLif:
    def __init__ ( self, file, file_name_dec, image, args):
        if args.verbose:
            print( f"{self.__init__.__qualname__}")

        self.args = args
        self.image = image
        self.file_name_dec = file_name_dec
        self.file_name = f"{file_name_dec:10}".encode( args.codepage)

        self.vol = LifImage( file, verbose = args.verbose)

        self.dir_seek = 0xFFFF
        self.dir_entry = None

    def open ( self):
        self.vol.read_volume_sector( )

    def get_raw_file ( self):
        return self.vol.file

    def fix_from ( self, source):

        return

    def find_dir_entry ( self):
        if self.args.verbose:
            print( f"{self.find_dir_entry.__qualname__}")

        # Set the pointer to the directory start
        self.vol.dir_entry_start( )

        for _ in range( self.vol.no_dir_entries( )):
            d = LifDirectory( self.vol.dir_entry_next( ))

            if self.args.verbose:
                print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            # Skip purged entries.
            if d.is_purged( ):
                continue

            # File name not found.
            if d.is_avail( ):
                break

            # The target file exists.
            if self.file_name == d.file_name( ):
                self.dir_entry = d
                return True

        return False

    def find_free_spot ( self, file_size):
        if self.args.verbose:
            print( f"{self.find_free_spot.__qualname__}")

        quotient, remainder = divmod( file_size, self.vol.SECTOR_SIZE)
        file_length = quotient + bool( remainder)
        file_start = 16

        # Set the pointer to the directory start
        self.vol.dir_entry_start( )

        for _ in range( self.vol.no_dir_entries( )):
            seek = self.vol.file.tell( )
            d = LifDirectory( self.vol.dir_entry_next( ))

            if self.args.verbose:
                print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            # Take the first purged big enough.
            # The no of recs will not be touched.
            # But what will happen with E010? Terrible things!
            if d.is_purged( ):
                if d.file_length( ) >= file_length:
                    self.dir_seek = seek
                    self.dir_entry = d
                    return True

            # Or the next available.
            if d.is_avail( ):
                d.writeable( )
                d.file_start( file_start)
                d.file_length( file_length)
                d.readonly( )

                if self.args.verbose:
                    print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

                self.dir_seek = seek
                self.dir_entry = d
                return True

            # Keep track of the used sectors
            # TODO: Check if there is enough space remaining in the volume.
            if file_start < d.file_start( ) + d.file_length( ):
                file_start = d.file_start( ) + d.file_length( )

        return False

    def purge ( self):
        if self.args.verbose:
            print( f"{self.purge.__qualname__}")

        # The target file exists.
        if self.find_dir_entry( ):
            seek = self.dir_seek
            d = self.dir_entry

            # Write dir entry.
            d.writeable( )

            # TODO: Use 0xFFFF as file type if this is the last file?
            d.file_type( 0x0000)

            d.readonly( )

            if self.args.verbose:
                print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            self.vol.dir_entry_write( d.dir_entry)

            return True

        return False

    def rename ( self, new_file_name):
        if self.args.verbose:
            print( f"{self.purge.__qualname__}")

        # The target file exists.
        if self.find_dir_entry( ):
            seek = self.dir_seek
            d = self.dir_entry

            # Write dir entry.
            d.writeable( )

            d.file_name( f"{new_file_name:10}".encode( self.args.codepage))

            d.readonly( )

            if self.args.verbose:
                print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            self.vol.dir_entry_write( d.dir_entry)

            return True

        return False

    def write_file ( self, source):
        if self.args.verbose:
            print( f"{self.write_file.__qualname__}")

        d = self.dir_entry
        d.writeable( )
        d.file_name( self.file_name)
        d.file_type( source.dir_entry.file_type( ))
        d.bytes_per_file( source.dir_entry.bytes_per_file( ))
        d.bytes_per_record( source.dir_entry.bytes_per_record( ))

        if self.args.extended:
            d.creation_date( source.dir_entry.creation_date( ))

        d.fix( )
        d.readonly( )

        if self.args.verbose:
            print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

        self.vol.dir_entry_write( d.dir_entry)

        data = source.read_file( )
        self.vol.file.seek( self.vol.SECTOR_SIZE * d.file_start( ), 0)
        self.vol.file.write( data)

        # TODO: Fill unused blocks with 0xFF.
        if 0 == source.dir_entry.bytes_per_file( ): # E010
            if self.args.verbose:
                print( f">{d.file_length( ):2} {source.dir_entry.file_length( ):2}")

            unused_blocks = d.file_length( ) - source.dir_entry.file_length( )

            self.vol.file.write( b'\xFF' * (unused_blocks * self.vol.SECTOR_SIZE))

        return

    def request_format ( self) -> int:
        if self.args.verbose:
            print( f"{self.request_format.__qualname__}")

        self.vol.file.amigo.request_format \
            ( unit = self.vol.file.unit
            , option = 0x82
            , interleave = self.args.interleave
            , databyte = self.args.databyte
            )

        return 0

#
#
#

class TargetLinux:
    def __init__ ( self, file_name_dec, image, args):
        if args.verbose:
            print( f"{self.__init__.__qualname__}")

        self.args = args
        self.image = image
        self.file_name_dec = file_name_dec
        self.raw_file = None

    def open ( self):

        return

    def get_raw_file ( self):
        if self.args.verbose:
            print( f"{self.get_raw_file.__qualname__}")

        if not self.raw_file:
            outpath = os.path.join( self.image, self.file_name_dec)
            self.raw_file = open( outpath, "wb")

        return self.raw_file

    def fix_from ( self, source):
        if self.args.verbose:
            print( f"{self.fix_from.__qualname__}")

        filename = self.file_name_dec.rstrip( )

        if self.args.extended:
            if not filename:
                filename = source.file_name_dec.rstrip( )

        basename, _, extension = filename.partition( '.')

        if not extension:
            extension = f"{source.dir_entry.file_type( ):04X}"

        self.file_name_dec = f"{basename}.{extension}"

        return

    def find_dir_entry ( self):
        if self.args.verbose:
            print( f"{self.find_dir_entry.__qualname__}")

        outpath = os.path.join( self.image, self.file_name_dec)

        if os.path.exists( outpath):
            return True

        return False


    def find_free_spot ( self, file_size):
        if self.args.verbose:
            print( f"{self.find_free_spot.__qualname__}")

        return True


    def write_file ( self, source):
        if self.args.verbose:
            print( f"{self.write_file.__qualname__}")

        with self.get_raw_file( ) as outfile:
            outfile.write( source.read_file( ))

        # "Close" the file.
        self.raw_file = None

        return

    def rename ( self, new_file_name):
        if self.args.verbose:
            print( f"{self.purge.__qualname__}")

        sys.exit( "Linux directory is not supported.")

        return False

    def purge ( self):
        if self.args.verbose:
            print( f"{self.purge.__qualname__}")

        outpath = os.path.join( self.image, self.file_name_dec)

        if os.path.exists( outpath):
            os.remove( outpath)
            return True

        return False

    def request_format ( self) -> int:
        if self.args.verbose:
            print( f"{self.request_format.__qualname__}")

        raw_target = self.get_raw_file( )

        raw_target.write( bytes( [self.args.databyte]) * self.args.size)
        raw_target.seek( 0, 0) # TODO: Like phys disc?

        return 0

#
#
#

def Target ( _lifpath: str, args):
    """Factory Method"""

    from . import lifpath
    file_name_dec, _, image = lifpath.split( _lifpath, args)

    # |         | linux device    | ":/dev/floppy" |
    if os.path.exists( image) and stat.S_ISBLK( os.stat( image).st_mode):
        if args.verbose:
            print( "Target is Linux device")

        print( "not implemented")
        sys.exit( -1)

        return None

    # |         | linux directory | ":directory/"  |
    if os.path.isdir( image):
        if args.verbose:
            print( "Target is Linux directory")

        return TargetLinux( file_name_dec, image, args)

    # |         | image file      | ":image"       | n/a
    if os.path.isfile( image):
        if args.verbose:
            print( "Target is LIF image file")

        file = open( image, "r+b")
        return TargetLif( file, file_name_dec, image, args)

    # |         | gpib device     | ":Dnnn"        |
    from . import msus
    file = msus.open( image, args.verbose)

    if file:
        if args.verbose:
            print( "Target is GPIB device")

        return TargetLif( file, file_name_dec, image, args)

    return None
