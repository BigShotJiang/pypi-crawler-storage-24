"""Default provider for string-model backends (OpenAI, Anthropic, Google GLA, etc.).

These providers use pydantic-ai's built-in ``"provider:model"`` string syntax
and don't require any special credential handling.
"""

from __future__ import annotations

from typing import List

from pydantic_ai import Agent

from ..config import LLMAgentConfig
from ..models import RiskAssessment
from .base import BaseLLMProvider


class DefaultProvider(BaseLLMProvider):
    """Provider for OpenAI, Anthropic (direct), Google GLA, and similar backends.

    These providers authenticate via environment variables that pydantic-ai
    reads automatically (``OPENAI_API_KEY``, ``ANTHROPIC_API_KEY``,
    ``GEMINI_API_KEY``, etc.).
    """

    def __init__(self, config: LLMAgentConfig) -> None:
        super().__init__(config)

    def build_agent(self) -> Agent[None, List[RiskAssessment]]:
        model_name = f"{self.config.provider}:{self.config.model}"
        return Agent(
            model_name,
            system_prompt=self.config.system_prompt,
            output_type=List[RiskAssessment],
        )

