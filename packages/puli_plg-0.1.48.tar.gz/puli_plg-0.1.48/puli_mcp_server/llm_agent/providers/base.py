"""Base class for LLM providers."""

from __future__ import annotations

import abc
from typing import TYPE_CHECKING, List

from pydantic_ai import Agent

if TYPE_CHECKING:
    from ..config import LLMAgentConfig
    from ..models import RiskAssessment


class BaseLLMProvider(abc.ABC):
    """Interface that every LLM provider must implement.

    Each provider knows how to:
      1. Build a pydantic-ai ``Agent`` for its backend.
      2. Decide whether the agent needs rebuilding (e.g. token refresh).
    """

    def __init__(self, config: LLMAgentConfig) -> None:
        self.config = config

    @abc.abstractmethod
    def build_agent(self) -> Agent[None, List[RiskAssessment]]:
        """Construct a pydantic-ai Agent configured for this provider."""

    def needs_rebuild(self) -> bool:
        """Return ``True`` if the agent must be rebuilt before the next query.

        The default implementation returns ``False`` (agent is reusable).
        Override in providers that use short-lived credentials.
        """
        return False

