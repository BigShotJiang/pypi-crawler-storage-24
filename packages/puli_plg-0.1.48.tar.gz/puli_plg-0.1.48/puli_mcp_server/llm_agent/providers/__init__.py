"""LLM provider implementations.

Use :func:`create_provider` to get the right provider for a given config.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from ..config import LLMAgentConfig
from .base import BaseLLMProvider
from .default import DefaultProvider
from .vertex_anthropic import VertexAnthropicProvider
from .vertex_gemini import VertexGeminiProvider

if TYPE_CHECKING:
    from puli_mcp_server.vertex_token_manager import VertexTokenManager

__all__ = [
    "BaseLLMProvider",
    "DefaultProvider",
    "VertexGeminiProvider",
    "VertexAnthropicProvider",
    "create_provider",
]


def create_provider(
    config: LLMAgentConfig,
    vertex_token_manager: Optional[VertexTokenManager] = None,
) -> BaseLLMProvider:
    """Factory: return the appropriate provider for the given config.

    Args:
        config: LLM agent configuration (includes provider name, model, etc.).
        vertex_token_manager: Optional SA token manager for Vertex AI providers.

    Returns:
        A concrete ``BaseLLMProvider`` instance.

    Raises:
        ValueError: If the provider name is not recognized.
    """
    if config.provider == "google-vertex":
        return VertexGeminiProvider(config, vertex_token_manager)

    if config.provider == "google-vertex-anthropic":
        return VertexAnthropicProvider(config, vertex_token_manager)

    # All other providers (openai, anthropic, google-gla, etc.)
    return DefaultProvider(config)

