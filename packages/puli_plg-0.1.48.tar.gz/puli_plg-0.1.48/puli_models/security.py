"""Security issues/weaknesses collection models (CWEs, vulnerabilities, etc.)."""

from dataclasses import dataclass, field
from typing import List


@dataclass
class Security:
    """Represents a security issue record in the VDB collection."""

    id: str
    vector: List[float]
    category: str
    description: str
    cause: str
    detection: str = ""
    mitigation: str = ""
    tags: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "Security":
        """Create a Security from a dictionary."""
        return cls(
            id=data.get("id"),
            vector=list(data.get("vector", [])),
            category=data.get("category", ""),
            description=data.get("description", ""),
            cause=data.get("cause", ""),
            detection=data.get("detection", ""),
            mitigation=data.get("mitigation", ""),
            tags=list(data.get("tags", [])),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for insertion."""
        return {
            "id": self.id,
            "vector": self.vector,
            "category": self.category,
            "description": self.description,
            "cause": self.cause,
            "detection": self.detection,
            "mitigation": self.mitigation,
            "tags": self.tags,
        }


@dataclass
class SecurityQueryResult:
    """Represents a lightweight security issue record for search/query results."""

    id: str
    category: str
    description: str
    cause: str
    detection: str = ""
    mitigation: str = ""
    tags: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "SecurityQueryResult":
        """Create a QueryResult from a dictionary."""
        return cls(
            id=data.get("id"),
            category=data.get("category", ""),
            description=data.get("description", ""),
            cause=data.get("cause", ""),
            detection=data.get("detection", ""),
            mitigation=data.get("mitigation", ""),
            tags=list(data.get("tags", [])),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "category": self.category,
            "description": self.description,
            "cause": self.cause,
            "detection": self.detection,
            "mitigation": self.mitigation,
            "tags": self.tags,
        }

    def to_prompt_str(self) -> str:
        """Returns a string representation for prompts."""
        return (
            f"Security Issue: {self.id}\n"
            f"Category: {self.category}\n"
            f"Description: {self.description}\n"
            f"Cause: {self.cause}\n"
            f"Detection: {self.detection}\n"
            f"Mitigation: {self.mitigation}\n"
        )

