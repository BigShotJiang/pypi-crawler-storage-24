"""Regulatory compliance collection models (GDPR, HIPAA, SOC2, etc.)."""

from dataclasses import dataclass, field
from typing import List


@dataclass
class Regulation:
    """Represents a regulation record in the VDB collection."""

    id: str
    vector: List[float]
    regulation_id: str
    jurisdiction: str
    description: str
    pattern: str
    signals: List[str] = field(default_factory=list)
    example_fix: str = ""
    penalty: str = ""
    tags: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "Regulation":
        """Create a Regulation from a dictionary."""
        return cls(
            id=data.get("id"),
            vector=list(data.get("vector", [])),
            regulation_id=data.get("regulation_id", ""),
            jurisdiction=data.get("jurisdiction", ""),
            description=data.get("description", ""),
            pattern=data.get("pattern", ""),
            signals=list(data.get("signals", [])),
            example_fix=data.get("example_fix", ""),
            penalty=data.get("penalty", ""),
            tags=list(data.get("tags", [])),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for insertion."""
        return {
            "id": self.id,
            "vector": self.vector,
            "regulation_id": self.regulation_id,
            "jurisdiction": self.jurisdiction,
            "description": self.description,
            "pattern": self.pattern,
            "signals": self.signals,
            "example_fix": self.example_fix,
            "penalty": self.penalty,
            "tags": self.tags,
        }


@dataclass
class RegulationQueryResult:
    """Represents a lightweight regulation record for search/query results."""

    id: str
    regulation_id: str
    jurisdiction: str
    description: str
    pattern: str
    signals: List[str] = field(default_factory=list)
    example_fix: str = ""
    penalty: str = ""
    tags: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "RegulationQueryResult":
        """Create a QueryResult from a dictionary."""
        return cls(
            id=data.get("id"),
            regulation_id=data.get("regulation_id", ""),
            jurisdiction=data.get("jurisdiction", ""),
            description=data.get("description", ""),
            pattern=data.get("pattern", ""),
            signals=list(data.get("signals", [])),
            example_fix=data.get("example_fix", ""),
            penalty=data.get("penalty", ""),
            tags=list(data.get("tags", [])),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "regulation_id": self.regulation_id,
            "jurisdiction": self.jurisdiction,
            "description": self.description,
            "pattern": self.pattern,
            "signals": self.signals,
            "example_fix": self.example_fix,
            "penalty": self.penalty,
            "tags": self.tags,
        }

    def to_prompt_str(self) -> str:
        """Returns a string representation for prompts."""
        return (
            f"Regulation: {self.id}\n"
            f"Regulation ID: {self.regulation_id}\n"
            f"Jurisdiction: {self.jurisdiction}\n"
            f"Description: {self.description}\n"
            f"Pattern: {self.pattern}\n"
            f"Signals: {', '.join(self.signals)}\n"
            f"Example Fix: {self.example_fix}\n"
            f"Penalty: {self.penalty}\n"
        )

