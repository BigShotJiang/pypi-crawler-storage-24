from dataclasses import dataclass, field
from typing import List


@dataclass
class BestPractice:
    """Represents a best practice record in the VDB collection."""

    id: str
    vector: List[float]
    framework: str
    category: str
    name: str
    description: str
    problem: str
    why_it_fails: str
    solution: str
    tags: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "BestPractice":
        """Create a BestPractice from a dictionary."""
        return cls(
            id=data.get("id"),
            vector=list(data.get("vector", [])),
            framework=data.get("framework", ""),
            category=data.get("category", ""),
            name=data.get("name", ""),
            description=data.get("description", ""),
            problem=data.get("problem", ""),
            why_it_fails=data.get("why_it_fails", ""),
            solution=data.get("solution", ""),
            tags=list(data.get("tags", [])),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for insertion."""
        return {
            "id": self.id,
            "vector": self.vector,
            "framework": self.framework,
            "category": self.category,
            "name": self.name,
            "description": self.description,
            "problem": self.problem,
            "why_it_fails": self.why_it_fails,
            "solution": self.solution,
            "tags": self.tags,
        }


@dataclass
class BestPracticeQueryResult:
    """Represents a lightweight best practice record for search/query results."""

    id: str
    framework: str
    category: str
    name: str
    description: str
    problem: str
    why_it_fails: str
    solution: str
    tags: List[str] = field(default_factory=list)
    distance: float = 0.0  # Similarity score from search

    @classmethod
    def from_dict(cls, data: dict) -> "BestPracticeQueryResult":
        """Create a QueryResult from a dictionary."""
        return cls(
            id=data.get("id"),
            framework=data.get("framework", ""),
            category=data.get("category", ""),
            name=data.get("name", ""),
            description=data.get("description", ""),
            problem=data.get("problem", ""),
            why_it_fails=data.get("why_it_fails", ""),
            solution=data.get("solution", ""),
            tags=list(data.get("tags", [])),
            distance=data.get("distance", 0.0),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "framework": self.framework,
            "category": self.category,
            "name": self.name,
            "description": self.description,
            "problem": self.problem,
            "why_it_fails": self.why_it_fails,
            "solution": self.solution,
            "tags": self.tags,
        }

    def to_prompt_str(self) -> str:
        """Returns a string representation for LLM prompts."""
        return (
            f"Best Practice: {self.name}\n"
            f"Framework: {self.framework} | Category: {self.category}\n"
            f"Problem: {self.problem}\n"
            f"Why it fails: {self.why_it_fails}\n"
            f"Solution: {self.solution}\n"
        )

