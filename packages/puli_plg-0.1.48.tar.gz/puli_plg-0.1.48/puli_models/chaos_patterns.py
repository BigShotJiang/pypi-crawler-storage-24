from dataclasses import dataclass
from typing import List


@dataclass
class ChaosPattern:
    """Represents a chaos pattern record in the Zilliz collection."""

    id: str
    vector: List[float]
    name: str
    category: str
    description: str
    cause: str
    symptoms: str
    technology: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "ChaosPattern":
        """Create a ChaosPattern from a dictionary."""
        return cls(
            id=data.get("id"),
            vector=list(data.get("vector", [])),
            name=data.get("name"),
            category=data.get("category"),
            description=data.get("description"),
            cause=data.get("cause"),
            symptoms=data.get("symptoms"),
            technology=data.get("technology"),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for insertion."""
        return {
            "id": self.id,
            "vector": self.vector,
            "name": self.name,
            "category": self.category,
            "description": self.description,
            "cause": self.cause,
            "symptoms": self.symptoms,
            "technology": self.technology,
        }


@dataclass
class ChaosPatternQueryResult:
    """Represents a lightweight chaos pattern record for search/query results."""

    name: str
    category: str
    description: str
    cause: str
    symptoms: str
    technology: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "ChaosPatternQueryResult":
        """Create a ChaosPatternQueryResult from a dictionary."""
        return cls(
            name=data.get("name"),
            category=data.get("category"),
            description=data.get("description"),
            cause=data.get("cause"),
            symptoms=data.get("symptoms"),
            technology=data.get("technology"),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "name": self.name,
            "category": self.category,
            "description": self.description,
            "cause": self.cause,
            "symptoms": self.symptoms,
            "technology": self.technology,
        }

    def to_prompt_str(self) -> str:
        """Returns a string representation of the chaos pattern query result."""
        prompt = f"Title: {self.name}\n" \
            + f"Category: {self.category}\n" \
            + f"Description: {self.description}\n" \
            + f"Root Causes: {self.cause}\n" \
            + f"Common Symptoms: {self.symptoms}\n"
        if self.technology:
            prompt += f"Technology: {self.technology}\n"
        return prompt