"""Domain indicators collection models for detecting business domains in code."""

from dataclasses import dataclass, field
from typing import List


@dataclass
class DomainIndicator:
    """Represents a domain indicator record in the VDB collection."""

    id: str
    vector: List[float]
    name: str
    variables: List[str] = field(default_factory=list)
    functions: List[str] = field(default_factory=list)
    database_fields: List[str] = field(default_factory=list)
    libraries: List[str] = field(default_factory=list)
    file_paths: List[str] = field(default_factory=list)
    api_patterns: List[str] = field(default_factory=list)
    integrations: List[str] = field(default_factory=list)
    common_patterns: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "DomainIndicator":
        """Create a DomainIndicator from a dictionary."""
        return cls(
            id=data.get("id"),
            vector=list(data.get("vector", [])),
            name=data.get("name", ""),
            variables=list(data.get("variables", [])),
            functions=list(data.get("functions", [])),
            database_fields=list(data.get("database_fields", [])),
            libraries=list(data.get("libraries", [])),
            file_paths=list(data.get("file_paths", [])),
            api_patterns=list(data.get("api_patterns", [])),
            integrations=list(data.get("integrations", [])),
            common_patterns=list(data.get("common_patterns", [])),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for insertion."""
        return {
            "id": self.id,
            "vector": self.vector,
            "name": self.name,
            "variables": self.variables,
            "functions": self.functions,
            "database_fields": self.database_fields,
            "libraries": self.libraries,
            "file_paths": self.file_paths,
            "api_patterns": self.api_patterns,
            "integrations": self.integrations,
            "common_patterns": self.common_patterns,
        }


@dataclass
class DomainIndicatorQueryResult:
    """Represents a lightweight domain indicator record for search/query results."""

    id: str
    name: str
    variables: List[str] = field(default_factory=list)
    functions: List[str] = field(default_factory=list)
    database_fields: List[str] = field(default_factory=list)
    libraries: List[str] = field(default_factory=list)
    file_paths: List[str] = field(default_factory=list)
    api_patterns: List[str] = field(default_factory=list)
    integrations: List[str] = field(default_factory=list)
    common_patterns: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "DomainIndicatorQueryResult":
        """Create a QueryResult from a dictionary."""
        return cls(
            id=data.get("id"),
            name=data.get("name", ""),
            variables=list(data.get("variables", [])),
            functions=list(data.get("functions", [])),
            database_fields=list(data.get("database_fields", [])),
            libraries=list(data.get("libraries", [])),
            file_paths=list(data.get("file_paths", [])),
            api_patterns=list(data.get("api_patterns", [])),
            integrations=list(data.get("integrations", [])),
            common_patterns=list(data.get("common_patterns", [])),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "name": self.name,
            "variables": self.variables,
            "functions": self.functions,
            "database_fields": self.database_fields,
            "libraries": self.libraries,
            "file_paths": self.file_paths,
            "api_patterns": self.api_patterns,
            "integrations": self.integrations,
            "common_patterns": self.common_patterns,
        }

    def to_prompt_str(self) -> str:
        """Returns a string representation for prompts."""
        return (
            f"Domain: {self.name} ({self.id})\n"
            f"Variables: {', '.join(self.variables)}\n"
            f"Functions: {', '.join(self.functions)}\n"
            f"Database Fields: {', '.join(self.database_fields)}\n"
            f"Libraries: {', '.join(self.libraries)}\n"
            f"File Paths: {', '.join(self.file_paths)}\n"
            f"API Patterns: {', '.join(self.api_patterns)}\n"
            f"Integrations: {', '.join(self.integrations)}\n"
            f"Common Patterns: {', '.join(self.common_patterns)}\n"
        )

