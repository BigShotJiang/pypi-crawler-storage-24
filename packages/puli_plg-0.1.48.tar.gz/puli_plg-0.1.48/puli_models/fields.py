"""Provider-agnostic field type system for collection definitions.

Uses only stdlib types (no external dependencies) so it can live in puli-models.
Provider-specific code (pymilvus DataType, Vertex JSON schemas) maps FROM these
abstract types in their own packages.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class FieldType(Enum):
    """Abstract field types that map to provider-specific types."""
    VARCHAR = "varchar"
    INT16 = "int16"
    INT32 = "int32"
    FLOAT = "float"
    FLOAT_VECTOR = "float_vector"
    ARRAY_VARCHAR = "array_varchar"


@dataclass
class FieldDefinition:
    """Abstract definition of a single collection field.

    Captures enough metadata to generate:
    - Zilliz/Milvus schemas (DataType, max_length, etc.)
    - Vertex AI schemas (JSON type, text_searchable)
    - JSON validation schemas for the crawler
    """
    name: str
    field_type: FieldType

    # VDB schema attributes
    max_length: Optional[int] = None        # For VARCHAR fields
    max_capacity: Optional[int] = None      # For ARRAY fields
    is_primary: bool = False
    nullable: bool = False
    text_searchable: bool = False           # Vertex hybrid search content field

    # Whether this field exists in the VDB schema.
    # Fields with store_in_vdb=False only appear in JSON validation (e.g., trigger_keywords
    # which gets merged into tags by the model's from_dict).
    store_in_vdb: bool = True

    # JSON schema generation attributes (for crawler response validation)
    json_min_length: Optional[int] = None
    json_minimum: Optional[int] = None
    json_maximum: Optional[int] = None
    json_pattern: Optional[str] = None
    json_min_items: Optional[int] = None
    json_required: bool = True
    json_description: Optional[str] = None
