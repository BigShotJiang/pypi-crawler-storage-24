# optional: HID events aggregator
