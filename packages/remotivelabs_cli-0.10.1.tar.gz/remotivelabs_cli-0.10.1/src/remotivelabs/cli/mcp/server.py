from enum import Enum

import typer
from mcp.server.fastmcp import FastMCP

from remotivelabs.cli.typer_ext import typer_utils
from remotivelabs.cli.utils.console import print_hint

from .instructions import TOPOLOGY_INSTRUCTIONS
from .prompts.topology import register_prompts
from .tools.topology import register_tools

app = typer_utils.create_typer(
    help="""
MCP server for topology designed to be used with cursor, vscode, intellij etc.
"""
)


class TransportType(str, Enum):
    stdio = "stdio"
    http = "http"


@app.command(name="start")
def main(
    transport: TransportType = typer.Option(default=TransportType.stdio, help="MCP transport protocol to use"),
) -> None:
    if transport is not TransportType.stdio:
        print_hint("Only transport stdio is supported so far")
        raise typer.Exit(1)
    mcp = FastMCP(
        name="remotive-topology-mcp",
        instructions=TOPOLOGY_INSTRUCTIONS,
    )

    register_tools(mcp)
    register_prompts(mcp)

    try:
        mcp.run()
    except KeyboardInterrupt:
        # Graceful shutdown on Ctrl+C
        pass
