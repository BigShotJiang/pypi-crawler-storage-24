"""Signal search query parser."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

# Single source of truth for all searchable/filterable fields.
# Columns must match the FTS table definition in sqlite/schema.py exactly.
# Format: (db_column, camel_alias_or_None, in_fts)
_FIELDS: list[tuple[str, str | None, bool]] = [
    ("name", "signalName", True),
    ("frame_name", "frameName", True),
    ("frame_id", "frameId", True),
    ("namespace", None, True),
    ("channel", None, True),
    ("description", None, True),
    ("frame_description", "frameDescription", True),
    ("unit", None, True),
    ("senders", None, True),
    ("receivers", None, True),
    ("named_values", "namedValues", True),
    ("file_path", "filePath", False),  # raw WHERE only, not in FTS
]

_FTS_COLUMNS: frozenset[str] = frozenset(col for col, _, fts in _FIELDS if fts)
_RAW_FILTER_FIELDS: frozenset[str] = frozenset(col for col, _, fts in _FIELDS if not fts)
_CAMEL_FIELD_NAMES: dict[str, str] = {col: camel for col, camel, _ in _FIELDS if camel}
_FTS_FIELD_NAMES: dict[str, str] = {camel: col for col, camel, _ in _FIELDS if camel}

# Map accepted _f_<name> suffixes to DB column names.
# Covers: identity (col → col), camelCase aliases, and extra snake_case convenience aliases.
_FILTER_FIELD_MAP: dict[str, str] = (
    {col: col for col, _, _ in _FIELDS} | {camel: col for col, camel, _ in _FIELDS if camel} | {"signal_name": "name"}
)


def resolve_filter_field(name: str) -> str | None:
    """Resolve a ``_f_<name>`` suffix to a DB column name. Returns None if unknown."""
    return _FILTER_FIELD_MAP.get(name)


class Operator(str, Enum):
    AND = "and"
    OR = "or"


@dataclass(frozen=True)
class ParsedTerm:
    value: str
    fields: frozenset[str]  # DB column names; empty frozenset = search all FTS columns


@dataclass(frozen=True)
class ParsedQuery:
    terms: list[ParsedTerm]
    active_term: ParsedTerm | None = None


def _resolve_fields(prefix: str) -> frozenset[str]:
    """Resolve a field prefix like 'name,description' or 'signal_name' to DB column names."""
    cols = [_FILTER_FIELD_MAP.get(c.strip(), c.strip()) for c in prefix.split(",") if c.strip()]
    return frozenset(c for c in cols if c in _FTS_COLUMNS or c in _RAW_FILTER_FIELDS)


def _parse_token(token: str) -> ParsedTerm | None:
    """Parse one query token into a ParsedTerm. Returns None for empty tokens."""
    sanitized = token.replace('"', "")
    if not sanitized:
        return None

    if ":" in sanitized:
        prefix, _, value = sanitized.partition(":")
        if value:
            fields = _resolve_fields(prefix)
            if fields:
                return ParsedTerm(value=value, fields=fields)
        # Unknown field prefix or empty value — treat as plain term
        return ParsedTerm(value=sanitized, fields=frozenset())

    return ParsedTerm(value=sanitized, fields=frozenset())


class Query:
    """Parsed search query. Create via ``Query.parse(s)``."""

    def __init__(self, parsed: ParsedQuery) -> None:
        self._parsed = parsed

    @staticmethod
    def parse(s: str) -> "Query":
        terms: list[ParsedTerm] = []
        for token in s.strip().split():
            if token == "OR":
                continue  # OR is a separate parameter; silently strip from query string
            term = _parse_token(token)
            if term is not None:
                terms.append(term)
        return Query(ParsedQuery(terms=terms, active_term=terms[-1] if terms else None))

    @property
    def parsed(self) -> ParsedQuery:
        return self._parsed
