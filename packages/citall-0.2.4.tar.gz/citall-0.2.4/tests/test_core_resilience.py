from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import torch

from citall import CitallExplorer, pca3d_explorer
from citall.types import EmbeddingDataset


class TestCoreResilience(unittest.TestCase):
    def test_duplicate_ids_are_disambiguated(self) -> None:
        vectors = torch.randn(3, 4)
        rows = [
            {"id": "same", "filename": "a.jpg"},
            {"id": "same", "filename": "b.jpg"},
            {"id": "other", "filename": "c.jpg"},
        ]
        payload = {"embeddings": vectors, "rows": rows}

        explorer = CitallExplorer.from_files(vectors_pt=payload)

        self.assertEqual(len(explorer.dataset.ids), 3)
        self.assertEqual(len(set(explorer.dataset.ids)), 3)
        self.assertIn("same", explorer.dataset.ids)
        self.assertIn("same#2", explorer.dataset.ids)
        self.assertEqual(len(explorer.dataset.metadata_by_id), 3)

    def test_constant_vectors_have_finite_ratio(self) -> None:
        vectors = torch.ones(8, 5)
        ids = [str(i) for i in range(8)]
        dataset = EmbeddingDataset(
            vectors=vectors,
            ids=ids,
            metadata_by_id={},
            image_paths_by_id={},
        )

        explorer = CitallExplorer(dataset)
        ratio = explorer.compute_pca().explained_variance_ratio

        self.assertEqual(ratio, [0.0, 0.0, 0.0])

    def test_api_smoke(self) -> None:
        n, d = 10, 6
        embeddings = torch.randn(n, d)
        rows = [
            {
                "object_id": f"obj_{i % 4}",
                "filename": f"img_{i}.jpg",
                "label": "a" if i % 2 == 0 else "b",
            }
            for i in range(n)
        ]

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            metadata_path = tmp_path / "meta.jsonl"
            with metadata_path.open("w", encoding="utf-8") as f:
                for i in range(4):
                    f.write('{"object_id":"obj_%d","title":"row_%d"}\n' % (i, i))

            out1, summary1 = pca3d_explorer(
                vectors_pt={"embeddings": embeddings, "rows": rows},
                metadata_path=metadata_path,
                metadata_key=["object_id"],
                rows_key=["object_id"],
                output_html=tmp_path / "out1.html",
                return_summary=True,
            )

            self.assertTrue(Path(out1).exists())
            self.assertEqual(summary1["num_points"], n)


if __name__ == "__main__":
    unittest.main()
