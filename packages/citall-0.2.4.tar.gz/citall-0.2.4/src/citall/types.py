from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch


@dataclass
class EmbeddingDataset:
    vectors: torch.Tensor
    ids: list[str]
    metadata_by_id: dict[str, dict[str, Any]]
    image_paths_by_id: dict[str, list[str]]
    diagnostics: dict[str, Any] | None = None


@dataclass
class PCAResult:
    coords_3d: torch.Tensor
    explained_variance_ratio: list[float]
