from citall import __version__


def main() -> None:
    print(f"citall {__version__}")
