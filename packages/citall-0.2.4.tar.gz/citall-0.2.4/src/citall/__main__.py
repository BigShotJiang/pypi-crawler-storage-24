from citall._cli import main

main()
