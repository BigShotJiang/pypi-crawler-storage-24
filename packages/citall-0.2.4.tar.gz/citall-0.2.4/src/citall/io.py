from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Iterable, List, Tuple, Union

import torch


KeySpec = Union[str, List[str], Tuple[str, ...]]


def _normalize_id(value: Any) -> str:
    return str(value)


def _normalize_key_spec(key: KeySpec | None) -> list[str]:
    if key is None:
        return []
    if isinstance(key, str):
        if "|" in key:
            return [part.strip() for part in key.split("|") if part.strip()]
        key = key.strip()
        return [key] if key else []
    return [str(part).strip() for part in key if str(part).strip()]


def _extract_first_value(row: dict[str, Any], keys: Iterable[str]) -> Any:
    for key in keys:
        if key in row:
            value = row[key]
            if value is not None and str(value).strip() != "":
                return value
    return None


def _build_join_key(
    row: dict[str, Any],
    keys: list[str],
) -> tuple[str, ...] | None:
    if not keys:
        return None
    parts: list[str] = []
    for key in keys:
        value = row.get(key)
        if value is None or str(value).strip() == "":
            return None
        parts.append(_normalize_id(value))
    return tuple(parts)


def load_vectors(
    pt_path: str | Path | dict[str, Any],
) -> tuple[torch.Tensor, list[str], list[dict[str, Any]] | None]:
    """Load vectors (and optional ids) from a .pt file or dict payload.

    Supported payloads:
    - Tensor: shape (N, D), ids become ["0", "1", ...]
    - Dict with a "rows" list (raw payload): ids derived from row["uid"] or row["id"] or index
    - Dict with vectors and ids keys
    """
    if isinstance(pt_path, dict):
        payload = pt_path
    else:
        pt_path = Path(pt_path)
        payload = torch.load(pt_path, map_location="cpu")

    if isinstance(payload, torch.Tensor):
        vectors = payload
        ids = [str(i) for i in range(vectors.shape[0])]
        return vectors, ids, None

    if not isinstance(payload, dict):
        raise ValueError(
            "Unsupported .pt payload. Expected a Tensor or a dict containing vectors."
        )

    # Auto-detect raw payload: {embeddings/vectors, rows}
    if "rows" in payload and isinstance(payload["rows"], list):
        return _load_vectors_from_raw(payload)

    possible_vector_keys = ["vectors", "embeddings", "tensor", "data"]
    chosen_vector_key = next((k for k in possible_vector_keys if k in payload), None)

    if chosen_vector_key is None:
        raise ValueError(
            "Could not find vectors in dict payload. Store vectors under one of: "
            "vectors, embeddings, tensor, data."
        )

    vectors = payload[chosen_vector_key]
    if not isinstance(vectors, torch.Tensor):
        raise ValueError(f"Value at key '{chosen_vector_key}' is not a torch.Tensor.")

    possible_id_keys = ["ids", "keys", "labels", "names"]
    chosen_id_key = next((k for k in possible_id_keys if k in payload), None)

    if chosen_id_key is None:
        ids = [str(i) for i in range(vectors.shape[0])]
    else:
        raw_ids = payload[chosen_id_key]
        if not isinstance(raw_ids, (list, tuple)):
            raise ValueError(f"Value at key '{chosen_id_key}' must be a list or tuple.")
        ids = [_normalize_id(x) for x in raw_ids]

    if vectors.ndim != 2:
        raise ValueError(f"Expected vectors shape (N, D), got {tuple(vectors.shape)}")
    if vectors.shape[0] != len(ids):
        raise ValueError(
            f"Vector row count ({vectors.shape[0]}) does not match ids count ({len(ids)})."
        )

    return vectors, ids, None


def _load_vectors_from_raw(
    payload: dict[str, Any],
) -> tuple[torch.Tensor, list[str], list[dict[str, Any]]]:
    possible_vector_keys = ["embeddings", "vectors", "tensor", "data"]
    chosen_vector_key = next((k for k in possible_vector_keys if k in payload), None)

    if chosen_vector_key is None:
        raise ValueError(
            "Could not find embeddings in payload. Include one of: embeddings, vectors, tensor, data."
        )

    vectors = payload[chosen_vector_key]
    if not isinstance(vectors, torch.Tensor):
        raise ValueError(f"Value at key '{chosen_vector_key}' is not a torch.Tensor.")

    raw_rows = payload["rows"]
    if not all(isinstance(x, dict) for x in raw_rows):
        raise ValueError("Raw payload mode requires 'rows' as a list of objects.")
    rows = [dict(row) for row in raw_rows]

    if vectors.ndim != 2:
        raise ValueError(f"Expected vectors shape (N, D), got {tuple(vectors.shape)}")
    if vectors.shape[0] != len(rows):
        raise ValueError(
            f"Vector row count ({vectors.shape[0]}) does not match rows count ({len(rows)})."
        )

    ids = [_normalize_id(row.get("uid") or row.get("id") or i) for i, row in enumerate(rows)]
    return vectors, ids, rows


def load_metadata_records(metadata_path: str | Path) -> list[dict[str, Any]]:
    """Load metadata from .json (object or list) or .jsonl."""
    metadata_path = Path(metadata_path)
    suffix = metadata_path.suffix.lower()

    if suffix == ".jsonl":
        records: list[dict[str, Any]] = []
        with metadata_path.open("r", encoding="utf-8") as f:
            for line_number, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                item = json.loads(line)
                if not isinstance(item, dict):
                    raise ValueError(
                        f"Expected object per line in jsonl, got {type(item)} at line {line_number}."
                    )
                records.append(item)
        return records

    if suffix == ".json":
        with metadata_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            if not all(isinstance(x, dict) for x in data):
                raise ValueError("JSON list metadata must contain objects.")
            return data
        if isinstance(data, dict):
            if all(isinstance(v, dict) for v in data.values()):
                normalized: list[dict[str, Any]] = []
                for k, v in data.items():
                    row = dict(v)
                    row.setdefault("id", k)
                    normalized.append(row)
                return normalized
            return [data]
        raise ValueError("Unsupported JSON metadata format.")

    raise ValueError("Metadata file must have .json or .jsonl extension.")


def join_vectors_with_metadata(
    vectors: torch.Tensor,
    ids: list[str],
    rows: list[dict[str, Any]] | None,
    metadata_records: list[dict[str, Any]] | None,
    metadata_key: KeySpec | None,
    rows_key: KeySpec | None,
) -> tuple[
    torch.Tensor,
    list[str],
    list[dict[str, Any]] | None,
    dict[str, dict[str, Any]],
    dict[str, Any],
]:
    diagnostics: dict[str, Any] = {
        "vector_count": len(ids),
        "metadata_count": len(metadata_records or []),
        "matched_vectors": 0,
        "unmatched_vectors": 0,
        "duplicate_metadata_keys": 0,
        "duplicate_vector_keys": 0,
        "sample_mismatches": [],
    }

    if metadata_records is None:
        return vectors, ids, rows, {}, diagnostics

    metadata_rows = [dict(row) for row in metadata_records]

    auto_default = False
    if metadata_key is None and rows is not None:
        rows_have_object_id = any("object_id" in row for row in rows)
        metadata_have_object_id = any("object_id" in row for row in metadata_rows)
        if rows_have_object_id and metadata_have_object_id:
            metadata_key = ["object_id"]
            rows_key = ["object_id"]
            auto_default = True

    metadata_keys = _normalize_key_spec(metadata_key)
    row_keys = _normalize_key_spec(rows_key)

    if metadata_rows and not metadata_keys:
        raise ValueError("metadata_key is required when metadata is provided.")

    if metadata_rows and not row_keys:
        row_keys = ["id"]

    metadata_index: dict[tuple[str, ...], list[dict[str, Any]]] = {}
    for row in metadata_rows:
        key = _build_join_key(row, metadata_keys)
        if key is None:
            continue
        metadata_index.setdefault(key, []).append(row)

    duplicate_metadata = sum(1 for rows_list in metadata_index.values() if len(rows_list) > 1)
    diagnostics["duplicate_metadata_keys"] = duplicate_metadata

    vector_key_counts: dict[tuple[str, ...], int] = {}
    output_vectors: list[torch.Tensor] = []
    output_ids: list[str] = []
    output_rows: list[dict[str, Any]] | None = [] if rows is not None else None
    metadata_by_id: dict[str, dict[str, Any]] = {}
    emitted_id_counts: dict[str, int] = {}

    def _make_unique_output_id(base_id: str) -> str:
        count = emitted_id_counts.get(base_id, 0) + 1
        emitted_id_counts[base_id] = count
        if count == 1 and base_id not in metadata_by_id:
            return base_id
        return f"{base_id}#{count}"

    for index, item_id in enumerate(ids):
        row = dict(rows[index]) if rows is not None else {"id": item_id}
        row.setdefault("id", item_id)

        if row_keys == ["id"]:
            join_key = (_normalize_id(item_id),)
        else:
            join_key = _build_join_key(row, row_keys)

        if join_key is not None:
            vector_key_counts[join_key] = vector_key_counts.get(join_key, 0) + 1
        candidates = metadata_index.get(join_key or ("<missing>",), []) if join_key else []

        chosen_candidates = candidates
        if len(candidates) > 1 and "filename" in row:
            filename = str(row.get("filename"))
            file_matches = [m for m in candidates if str(m.get("filename", "")) == filename]
            if len(file_matches) == 1:
                chosen_candidates = file_matches

        if not chosen_candidates:
            diagnostics["unmatched_vectors"] += 1
            if len(diagnostics["sample_mismatches"]) < 5:
                diagnostics["sample_mismatches"].append(
                    {"id": item_id, "row_key": list(join_key) if join_key else None}
                )
            out_id = _make_unique_output_id(item_id)
            output_vectors.append(vectors[index])
            output_ids.append(out_id)
            if output_rows is not None:
                output_rows.append(row)
            continue

        if len(chosen_candidates) > 1:
            chosen_candidates = [chosen_candidates[0]]

        for match_idx, metadata_row in enumerate(chosen_candidates):
            candidate_id = item_id
            if len(chosen_candidates) > 1:
                candidate_id = f"{item_id}#{match_idx + 1}"

            out_id = _make_unique_output_id(candidate_id)

            output_vectors.append(vectors[index])
            output_ids.append(out_id)
            metadata_by_id[out_id] = dict(metadata_row)
            if output_rows is not None:
                output_rows.append(row)

        diagnostics["matched_vectors"] += 1

    diagnostics["duplicate_vector_keys"] = sum(1 for c in vector_key_counts.values() if c > 1)
    diagnostics["auto_join_used"] = auto_default

    if not output_vectors:
        raise ValueError("No vectors remain after metadata matching.")

    stacked_vectors = torch.stack(output_vectors, dim=0)
    return stacked_vectors, output_ids, output_rows, metadata_by_id, diagnostics


def resolve_image_paths(
    ids: list[str],
    images_dir: str | Path | None,
    metadata_by_id: dict[str, dict[str, Any]] | None = None,
    rows_by_id: dict[str, dict[str, Any]] | None = None,
    image_dir_key: str | None = None,
    max_images_per_embedding: int | None = None,
    exts: tuple[str, ...] = (".png", ".jpg", ".jpeg", ".webp", ".gif"),
) -> tuple[dict[str, list[str]], dict[str, Any]]:
    """Resolve image paths for ids.

    Resolution order per id:
    1) image_dir_key: metadata/row field pointing to a folder of images
    2) images_dir/id: fallback (single file or directory of many images)
    """
    base_images_dir: Path | None = None
    if images_dir is not None:
        base_images_dir = Path(images_dir)
        if not base_images_dir.exists() or not base_images_dir.is_dir():
            raise ValueError(
                f"Images directory does not exist or is not a directory: {base_images_dir}"
            )

    if max_images_per_embedding is not None and max_images_per_embedding < 1:
        raise ValueError("max_images_per_embedding must be >= 1 when provided.")

    if base_images_dir is None and image_dir_key is None:
        return {}, {"missing_images": 0, "image_source": None}

    def _collect_images_from_dir(dir_path: Path) -> list[Path]:
        if not dir_path.exists() or not dir_path.is_dir():
            return []
        images = [
            path
            for path in sorted(dir_path.iterdir())
            if path.is_file() and path.suffix.lower() in exts
        ]
        if max_images_per_embedding is not None:
            return images[:max_images_per_embedding]
        return images

    resolved: dict[str, list[str]] = {}
    missing_images = 0

    for item_id in ids:
        metadata = (metadata_by_id or {}).get(item_id, {})
        row_data = (rows_by_id or {}).get(item_id, {})

        if image_dir_key:
            raw_dir_value = metadata.get(image_dir_key) or row_data.get(image_dir_key)
            if raw_dir_value is not None and str(raw_dir_value).strip():
                dir_candidate = Path(str(raw_dir_value).strip())
                if not dir_candidate.is_absolute() and base_images_dir is not None:
                    dir_candidate = base_images_dir / dir_candidate
                dir_images = _collect_images_from_dir(dir_candidate)
                if dir_images:
                    resolved[item_id] = [str(path.resolve()) for path in dir_images]
                    continue

        if base_images_dir is None:
            missing_images += 1
            continue

        candidate = base_images_dir / item_id
        if candidate.exists() and candidate.is_file():
            resolved[item_id] = [str(candidate.resolve())]
            continue
        if candidate.exists() and candidate.is_dir():
            dir_images = _collect_images_from_dir(candidate)
            if dir_images:
                resolved[item_id] = [str(path.resolve()) for path in dir_images]
            continue

        for ext in exts:
            candidate = base_images_dir / f"{item_id}{ext}"
            if candidate.exists() and candidate.is_file():
                resolved[item_id] = [str(candidate.resolve())]
                break

        if item_id not in resolved:
            filename = row_data.get("filename") or metadata.get("filename")
            if filename:
                candidate = base_images_dir / str(filename)
                if candidate.exists() and candidate.is_file():
                    resolved[item_id] = [str(candidate.resolve())]
                    continue
            missing_images += 1

    return resolved, {
        "missing_images": missing_images,
        "images_resolved": len(resolved),
        "image_source": "image_dir_key" if image_dir_key else "images_dir",
    }
