from __future__ import annotations

import tempfile
import webbrowser
from pathlib import Path
from typing import Any

import torch

from .io import (
    KeySpec,
    join_vectors_with_metadata,
    load_metadata_records,
    load_vectors,
    resolve_image_paths,
)
from .plotting import create_3d_figure, save_interactive_html
from .types import EmbeddingDataset, PCAResult


class CitallExplorer:
    """High-level API to build interactive 3D PCA visualizations."""

    def __init__(self, dataset: EmbeddingDataset):
        self.dataset = dataset
        self.pca_result: PCAResult | None = None

    @classmethod
    def from_files(
        cls,
        vectors_pt: str | Path | dict[str, Any],
        metadata_path: str | Path | None = None,
        metadata_key: KeySpec | None = None,
        rows_key: KeySpec | None = None,
        images_dir: str | Path | None = None,
        image_dir_key: str | None = None,
        max_images_per_embedding: int | None = 6,
    ) -> "CitallExplorer":
        vectors, ids, rows = load_vectors(vectors_pt)

        metadata_records: list[dict[str, Any]] | None = None
        if metadata_path is not None:
            metadata_records = load_metadata_records(metadata_path)

        vectors, ids, rows, metadata_by_id, join_diagnostics = join_vectors_with_metadata(
            vectors=vectors,
            ids=ids,
            rows=rows,
            metadata_records=metadata_records,
            metadata_key=metadata_key,
            rows_key=rows_key,
        )

        if len(set(ids)) != len(ids):
            seen_counts: dict[str, int] = {}
            used_ids: set[str] = set()
            original_ids: list[str] = []
            unique_ids: list[str] = []

            for item_id in ids:
                seen_counts[item_id] = seen_counts.get(item_id, 0) + 1
                suffix = seen_counts[item_id]
                candidate = item_id if suffix == 1 and item_id not in used_ids else f"{item_id}#{suffix}"
                while candidate in used_ids:
                    suffix += 1
                    candidate = f"{item_id}#{suffix}"
                used_ids.add(candidate)
                original_ids.append(item_id)
                unique_ids.append(candidate)

            remapped_metadata_by_id: dict[str, dict[str, Any]] = {}
            for new_id, old_id in zip(unique_ids, original_ids):
                if new_id in metadata_by_id:
                    remapped_metadata_by_id[new_id] = dict(metadata_by_id[new_id])
                elif old_id in metadata_by_id:
                    remapped_metadata_by_id[new_id] = dict(metadata_by_id[old_id])

            ids = unique_ids
            metadata_by_id = remapped_metadata_by_id

        rows_by_id = {}
        if rows is not None:
            rows_by_id = {item_id: row for item_id, row in zip(ids, rows)}

        image_paths_by_id, image_diagnostics = resolve_image_paths(
            ids,
            images_dir=images_dir,
            metadata_by_id=metadata_by_id,
            rows_by_id=rows_by_id,
            image_dir_key=image_dir_key,
            max_images_per_embedding=max_images_per_embedding,
        )

        for item_id in ids:
            row = rows_by_id.get(item_id, {})
            enriched = dict(metadata_by_id.get(item_id, {}))
            enriched.setdefault("uid", item_id)

            filename = row.get("filename") or enriched.get("filename")
            if filename is None:
                resolved_paths = image_paths_by_id.get(item_id)
                image_path = (
                    (resolved_paths[0] if resolved_paths else None) or enriched.get("image_path")
                )
                if image_path:
                    filename = Path(str(image_path)).name
            if filename is not None:
                enriched["filename"] = str(filename)

            if item_id in image_paths_by_id:
                enriched["image_path"] = image_paths_by_id[item_id][0]
                enriched["image_paths"] = list(image_paths_by_id[item_id])

            metadata_by_id[item_id] = enriched

        diagnostics: dict[str, Any] = {}
        diagnostics.update(join_diagnostics)
        diagnostics.update(image_diagnostics)
        diagnostics["matched_metadata_rows"] = sum(1 for item_id in ids if item_id in metadata_by_id)
        diagnostics["images_matched"] = sum(1 for item_id in ids if item_id in image_paths_by_id)
        diagnostics["vectors_after_join"] = len(ids)

        dataset = EmbeddingDataset(
            vectors=vectors,
            ids=ids,
            metadata_by_id=metadata_by_id,
            image_paths_by_id=image_paths_by_id,
            diagnostics=diagnostics,
        )
        return cls(dataset)

    def compute_pca(self, n_components: int = 3) -> PCAResult:
        if n_components != 3:
            raise ValueError("This method currently supports n_components=3 only.")

        def _safe_ratio(explained: torch.Tensor) -> list[float]:
            total = explained.sum()
            if total.item() <= 0.0 or not torch.isfinite(total):
                return [0.0] * n_components
            return (explained[:n_components] / total).tolist()

        x = self.dataset.vectors
        if not torch.is_floating_point(x):
            x = x.float()
        x = x.to(dtype=torch.float32)

        if x.ndim != 2:
            raise ValueError(f"Expected vectors shape (N, D), got {tuple(x.shape)}")
        if x.shape[0] < 3:
            raise ValueError("At least 3 samples are required for a meaningful 3D PCA.")
        if x.shape[1] < 3:
            raise ValueError("At least 3 features are required for a meaningful 3D PCA.")

        x_centered = x - x.mean(dim=0, keepdim=True)
        min_dim = min(x_centered.shape)
        q = min(max(n_components + 2, 5), min_dim)

        try:
            _, s, v = torch.pca_lowrank(x_centered, q=q, center=False)
            components = v[:, :n_components]
            coords = x_centered @ components
            explained = (s ** 2) / max(x_centered.shape[0] - 1, 1)
            ratio = _safe_ratio(explained)
        except RuntimeError:
            # Fallback for edge cases where low-rank PCA fails.
            u, s, _ = torch.linalg.svd(x_centered, full_matrices=False)
            coords = u[:, :n_components] * s[:n_components]
            explained = (s ** 2) / max(x_centered.shape[0] - 1, 1)
            ratio = _safe_ratio(explained)

        self.pca_result = PCAResult(coords_3d=coords, explained_variance_ratio=ratio)
        return self.pca_result

    def create_figure(
        self,
        hover_fields: list[str] | None = None,
        click_fields: list[str] | None = None,
        color_by: str | None = None,
    ):
        if self.pca_result is None:
            self.compute_pca(n_components=3)

        assert self.pca_result is not None
        return create_3d_figure(
            coords_3d=self.pca_result.coords_3d,
            ids=self.dataset.ids,
            metadata_by_id=self.dataset.metadata_by_id,
            image_paths_by_id=self.dataset.image_paths_by_id,
            explained_variance_ratio=self.pca_result.explained_variance_ratio,
            title="citall: PCA 3D Explorer",
            hover_fields=hover_fields,
            click_fields=click_fields,
            point_size=5,
            color_by=color_by,
            legend_title=None,
        )

    def save_html(
        self,
        output_html: str | Path,
        hover_fields: list[str] | None = None,
        click_fields: list[str] | None = None,
        color_by: str | None = None,
    ) -> Path:
        fig, payloads = self.create_figure(
            hover_fields=hover_fields,
            click_fields=click_fields,
            color_by=color_by,
        )
        output_html = Path(output_html)
        save_interactive_html(fig=fig, payloads=payloads, output_html=output_html)
        return output_html

    def summary(self) -> dict[str, Any]:
        ratio = self.pca_result.explained_variance_ratio if self.pca_result else None
        diagnostics = self.dataset.diagnostics or {}
        return {
            "num_points": len(self.dataset.ids),
            "vector_shape": tuple(self.dataset.vectors.shape),
            "metadata_rows_matched": sum(
                1 for item_id in self.dataset.ids if item_id in self.dataset.metadata_by_id
            ),
            "images_matched": sum(
                1 for item_id in self.dataset.ids if item_id in self.dataset.image_paths_by_id
            ),
            "matched_vectors": diagnostics.get("matched_vectors"),
            "unmatched_vectors": diagnostics.get("unmatched_vectors"),
            "duplicate_metadata_keys": diagnostics.get("duplicate_metadata_keys"),
            "duplicate_vector_keys": diagnostics.get("duplicate_vector_keys"),
            "missing_images": diagnostics.get("missing_images"),
            "sample_mismatches": diagnostics.get("sample_mismatches"),
            "pca_explained_variance_ratio": ratio,
        }


def pca3d_explorer(
    vectors_pt: str | Path | dict[str, Any],
    metadata_path: str | Path | None = None,
    metadata_key: KeySpec | None = None,
    rows_key: KeySpec | None = None,
    images_dir: str | Path | None = None,
    image_dir_key: str | None = None,
    max_images_per_embedding: int | None = 6,
    hover_fields: list[str] | None = None,
    click_fields: list[str] | None = None,
    color_by: str | None = None,
    output_html: str | Path | None = None,
    open_browser: bool = False,
    return_summary: bool = False,
) -> Path | tuple[Path, dict[str, Any]]:
    """Generate an interactive 3D PCA HTML visualization from embeddings.

    Args:
        vectors_pt: Path to a .pt file, or a dict payload containing vectors.
        metadata_path: Path to a .json or .jsonl metadata file.
        metadata_key: Field in the metadata used to match embedding ids.
        rows_key: Field in the embedding rows used to match metadata entries.
        images_dir: Directory of images named by embedding id.
        image_dir_key: Metadata field pointing to a per-embedding image folder.
        max_images_per_embedding: Maximum images loaded per embedding (default 6).
        hover_fields: Metadata fields shown on hover.
        click_fields: Metadata fields shown in the click side panel.
        color_by: Metadata field used to color points (numeric or categorical).
        output_html: Output path for the HTML file (default: citall_plot.html).
        open_browser: Open the result in the default browser after saving.
        return_summary: If True, return (path, summary_dict) instead of just path.
    """
    explorer = CitallExplorer.from_files(
        vectors_pt=vectors_pt,
        metadata_path=metadata_path,
        metadata_key=metadata_key,
        rows_key=rows_key,
        images_dir=images_dir,
        image_dir_key=image_dir_key,
        max_images_per_embedding=max_images_per_embedding,
    )
    explorer.compute_pca(n_components=3)

    if output_html is None:
        if open_browser:
            with tempfile.NamedTemporaryFile(
                prefix="citall_",
                suffix=".html",
                delete=False,
            ) as tmp_file:
                output_html = tmp_file.name
        else:
            output_html = Path("citall_plot.html")

    output = explorer.save_html(
        output_html=output_html,
        hover_fields=hover_fields,
        click_fields=click_fields,
        color_by=color_by,
    )

    if open_browser:
        webbrowser.open(output.resolve().as_uri())

    if return_summary:
        return output, explorer.summary()
    return output
