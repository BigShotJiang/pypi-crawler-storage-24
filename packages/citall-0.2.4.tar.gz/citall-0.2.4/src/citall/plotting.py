from __future__ import annotations

import json
import math
import re
from html import escape
from pathlib import Path
from typing import Any

import plotly.graph_objects as go
import plotly.io as pio
import torch


def _coerce_finite_float(value: Any) -> float | None:
  if value is None or isinstance(value, bool):
    return None
  if isinstance(value, (int, float)):
    candidate = float(value)
    return candidate if math.isfinite(candidate) else None
  text = str(value).strip()
  if not text:
    return None
  try:
    candidate = float(text)
  except ValueError:
    return None
  return candidate if math.isfinite(candidate) else None


def _natural_sort_key(text: str) -> tuple[tuple[int, float | str], ...]:
    parts = re.split(r"(\d+(?:\.\d+)?)", text.strip().lower())
    key: list[tuple[int, float | str]] = []
    for part in parts:
        if not part:
            continue
        numeric = _coerce_finite_float(part)
        if numeric is not None:
            key.append((0, numeric))
        else:
            key.append((1, part))
    return tuple(key)


def _string_level_sort_key(label: str) -> tuple[int, int, tuple[tuple[int, float | str], ...]]:
    normalized = " ".join(label.strip().lower().replace("_", " ").replace("-", " ").split())
    semantic_rank = {
        "very low": 0,
        "low": 1,
        "medium low": 2,
        "medium": 3,
        "mid": 3,
        "medium high": 4,
        "high": 5,
        "very high": 6,
    }.get(normalized)

    if semantic_rank is None:
        return (1, 0, _natural_sort_key(label))
    return (0, semantic_rank, _natural_sort_key(label))


def _ordered_string_levels(values: list[str]) -> list[str]:
    unique_values = sorted(set(values), key=_string_level_sort_key)
    return unique_values


def _build_hover_text(
    item_id: str,
    metadata: dict[str, Any] | None,
    hover_fields: list[str] | None,
) -> str:
    rows = [f"id: {item_id}"]
    if metadata:
        if hover_fields:
            for key in hover_fields:
                if key in metadata:
                    rows.append(f"{key}: {metadata[key]}")
        else:
            for key, value in metadata.items():
                if key == "id":
                    continue
                rows.append(f"{key}: {value}")
                if len(rows) >= 7:
                    break
    return "<br>".join(escape(str(x)) for x in rows)


def _select_click_metadata(
    metadata: dict[str, Any] | None,
    click_fields: list[str] | None,
) -> dict[str, Any]:
    if not metadata:
        return {}
    if not click_fields:
        return dict(metadata)
    return {key: metadata[key] for key in click_fields if key in metadata}


def create_3d_figure(
    coords_3d: torch.Tensor,
    ids: list[str],
    metadata_by_id: dict[str, dict[str, Any]],
    image_paths_by_id: dict[str, list[str]],
    explained_variance_ratio: list[float],
    title: str,
    hover_fields: list[str] | None,
    click_fields: list[str] | None,
    point_size: int,
    color_by: str | None,
    legend_title: str | None,
) -> tuple[go.Figure, list[dict[str, Any]]]:
    if coords_3d.ndim != 2 or coords_3d.shape[1] != 3:
        raise ValueError(f"Expected PCA coordinates shape (N, 3), got {tuple(coords_3d.shape)}")

    coords_np = coords_3d.detach().cpu().numpy()

    hover_text = []
    payloads: list[dict[str, Any]] = []
    groups: list[str] = []
    raw_color_values: list[Any | None] = []
    color_values: list[float | None] = []
    saw_non_numeric_color = False
    for idx, item_id in enumerate(ids):
        metadata = metadata_by_id.get(item_id)
        image_paths = image_paths_by_id.get(item_id) or []

        raw_color_value = (metadata or {}).get(color_by) if color_by else None
        numeric_color = _coerce_finite_float(raw_color_value) if color_by else None
        if color_by and raw_color_value is not None and numeric_color is None:
            saw_non_numeric_color = True

        if color_by:
            group_value = raw_color_value if raw_color_value is not None else "<missing>"
            group = str(group_value)
        else:
            group = "All points"

        hover_text.append(
            _build_hover_text(item_id=item_id, metadata=metadata, hover_fields=hover_fields)
        )
        groups.append(group)
        raw_color_values.append(raw_color_value)
        color_values.append(numeric_color)
        payloads.append(
            {
                "id": item_id,
                "index": idx,
                "group": group,
                "metadata": _select_click_metadata(metadata, click_fields),
                "image_path": image_paths[0] if image_paths else None,
                "image_paths": image_paths,
            }
        )

    ratio_pct = [x * 100.0 for x in explained_variance_ratio]
    axis_titles = [
        f"PC1 ({ratio_pct[0]:.2f}%)" if len(ratio_pct) > 0 else "PC1",
        f"PC2 ({ratio_pct[1]:.2f}%)" if len(ratio_pct) > 1 else "PC2",
        f"PC3 ({ratio_pct[2]:.2f}%)" if len(ratio_pct) > 2 else "PC3",
    ]

    traces: list[go.Scatter3d] = []
    # Use a continuous gradient whenever at least one numeric color value exists.
    # Missing or non-numeric values are rendered in a separate neutral trace.
    can_use_gradient = bool(color_by) and any(value is not None for value in color_values)
    can_use_string_gradient = bool(color_by) and not can_use_gradient and any(
      value is not None for value in raw_color_values
    )

    if can_use_gradient:
        numeric_idxs = [idx for idx, value in enumerate(color_values) if value is not None]
        missing_idxs = [idx for idx, value in enumerate(color_values) if value is None]

        traces.append(
            go.Scatter3d(
                x=coords_np[numeric_idxs, 0],
                y=coords_np[numeric_idxs, 1],
                z=coords_np[numeric_idxs, 2],
                mode="markers",
                text=[hover_text[i] for i in numeric_idxs],
                customdata=numeric_idxs,
                hovertemplate="%{text}<extra></extra>",
                name=color_by,
                showlegend=False,
                marker={
                    "size": point_size,
                    "opacity": 0.9,
                    "color": [color_values[i] for i in numeric_idxs],
                    "colorscale": "Viridis",
                    "reversescale": True,
                    "colorbar": {"title": {"text": legend_title or color_by}},
                },
            )
        )

        if missing_idxs:
          missing_label = "<missing/non-numeric>" if saw_non_numeric_color else "<missing>"
          traces.append(
            go.Scatter3d(
              x=coords_np[missing_idxs, 0],
              y=coords_np[missing_idxs, 1],
              z=coords_np[missing_idxs, 2],
              mode="markers",
              text=[hover_text[i] for i in missing_idxs],
              customdata=missing_idxs,
              hovertemplate="%{text}<extra></extra>",
              name=missing_label,
              legendgroup=missing_label,
              showlegend=True,
              marker={"size": point_size, "opacity": 0.86, "color": "#B0B7C3"},
            )
          )
    elif can_use_string_gradient:
      labeled_values = [str(value) for value in raw_color_values if value is not None]
      ordered_levels = _ordered_string_levels(labeled_values)
      level_to_rank = {level: idx for idx, level in enumerate(ordered_levels)}

      labeled_idxs: list[int] = []
      labeled_ranks: list[float] = []
      missing_idxs: list[int] = []
      for idx, raw_value in enumerate(raw_color_values):
        if raw_value is None:
          missing_idxs.append(idx)
          continue
        label = str(raw_value)
        labeled_idxs.append(idx)
        labeled_ranks.append(float(level_to_rank[label]))

      traces.append(
        go.Scatter3d(
          x=coords_np[labeled_idxs, 0],
          y=coords_np[labeled_idxs, 1],
          z=coords_np[labeled_idxs, 2],
          mode="markers",
          text=[hover_text[i] for i in labeled_idxs],
          customdata=labeled_idxs,
          hovertemplate="%{text}<extra></extra>",
          name=color_by,
          showlegend=False,
          marker={
            "size": point_size,
            "opacity": 0.9,
            "color": labeled_ranks,
            "colorscale": "Viridis",
            "reversescale": True,
            "colorbar": {
              "title": {"text": legend_title or color_by},
              "tickmode": "array",
              "tickvals": list(range(len(ordered_levels))),
              "ticktext": ordered_levels,
            },
          },
        )
      )

      if missing_idxs:
        traces.append(
          go.Scatter3d(
            x=coords_np[missing_idxs, 0],
            y=coords_np[missing_idxs, 1],
            z=coords_np[missing_idxs, 2],
            mode="markers",
            text=[hover_text[i] for i in missing_idxs],
            customdata=missing_idxs,
            hovertemplate="%{text}<extra></extra>",
            name="<missing>",
            legendgroup="<missing>",
            showlegend=True,
            marker={"size": point_size, "opacity": 0.86, "color": "#B0B7C3"},
          )
        )
    else:
        grouped_indices: dict[str, list[int]] = {}
        for idx, group in enumerate(groups):
            if group not in grouped_indices:
                grouped_indices[group] = []
            grouped_indices[group].append(idx)

        for group_name, idxs in grouped_indices.items():
            traces.append(
                go.Scatter3d(
                    x=coords_np[idxs, 0],
                    y=coords_np[idxs, 1],
                    z=coords_np[idxs, 2],
                    mode="markers",
                    text=[hover_text[i] for i in idxs],
                    customdata=idxs,
                    hovertemplate="%{text}<extra></extra>",
                    name=group_name,
                    legendgroup=group_name,
                    showlegend=bool(color_by),
                    marker={"size": point_size, "opacity": 0.86},
                )
            )

    fig = go.Figure(data=traces)

    fig.update_layout(
        title=title,
        template="plotly_white",
        margin={"l": 8, "r": 8, "b": 8, "t": 42},
        scene={
            "xaxis": {"title": axis_titles[0]},
            "yaxis": {"title": axis_titles[1]},
            "zaxis": {"title": axis_titles[2]},
        },
        legend={
            "title": {
                "text": (legend_title or color_by or "Group") if not can_use_gradient else "Group"
            },
        },
        height=760,
    )

    return fig, payloads


def save_interactive_html(
    fig: go.Figure,
    payloads: list[dict[str, Any]],
    output_html: str | Path,
) -> None:
    output_html = Path(output_html)

    plot_div = pio.to_html(
        fig,
        include_plotlyjs="cdn",
        full_html=False,
        div_id="citall_plot",
    )

    payloads_json = json.dumps(payloads)

    html = f"""<!doctype html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <title>citall explorer</title>
  <style>
    :root {{
      --bg: #f4f6f7;
      --panel: #ffffff;
      --ink: #1d2433;
      --muted: #5f697d;
      --accent: #0d8a74;
      --line: #d7dde5;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      background: radial-gradient(circle at 10% 10%, #ffffff 0%, var(--bg) 50%, #e9eef4 100%);
      color: var(--ink);
      font: 14px/1.45 "Avenir Next", "Segoe UI", sans-serif;
    }}
    .wrap {{
      display: grid;
      grid-template-columns: minmax(0, 2fr) minmax(280px, 1fr);
      gap: 16px;
      padding: 16px;
      min-height: 100vh;
    }}
    .plot-panel, .info-panel {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 16px;
      box-shadow: 0 10px 28px rgba(27, 43, 57, 0.08);
      overflow: hidden;
    }}
    .plot-panel {{ padding: 6px; }}
    .info-panel {{
      padding: 14px;
      display: grid;
      align-content: start;
      gap: 10px;
    }}
    .label {{
      color: var(--muted);
      text-transform: uppercase;
      font-size: 11px;
      letter-spacing: 0.08em;
      margin: 0;
    }}
    .value {{ margin: 0; word-break: break-word; }}
    .meta {{
      display: grid;
      gap: 8px;
      max-height: 40vh;
      overflow: auto;
      border-top: 1px solid var(--line);
      padding-top: 10px;
    }}
    .meta-row {{
      border-bottom: 1px dashed var(--line);
      padding-bottom: 6px;
    }}
    .gallery-head {{
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      gap: 8px;
      border-top: 1px solid var(--line);
      padding-top: 10px;
      margin-top: 4px;
    }}
    .gallery-tools {{
      display: flex;
      gap: 8px;
      align-items: center;
    }}
    .gallery-count {{
      margin: 0;
      color: var(--muted);
      font-size: 12px;
    }}
    .gallery-select {{
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 2px 8px;
      font: inherit;
      color: var(--ink);
      background: #fff;
    }}
    .image-grid {{
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }}
    .preview {{
      width: 100%;
      max-height: 180px;
      object-fit: contain;
      border: 1px solid var(--line);
      border-radius: 10px;
      background: #f7f9fb;
      display: block;
    }}
    @media (max-width: 1024px) {{
      .wrap {{ grid-template-columns: 1fr; }}
      .info-panel {{ order: -1; }}
    }}
  </style>
</head>
<body>
  <div class=\"wrap\">
    <section class=\"plot-panel\">{plot_div}</section>
    <aside class=\"info-panel\">
      <p class=\"label\">Selected point</p>
      <h2 id=\"point-id\" class=\"value\">none</h2>
      <p id=\"point-index\" class=\"value\">Click a point to inspect metadata.</p>
      <div class="gallery-head">
        <p class="label">Images</p>
            <div class="gallery-tools">
              <label class="label" for="point-image-limit">Show</label>
              <select id="point-image-limit" class="gallery-select">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="4">4</option>
                <option value="6" selected>6</option>
                <option value="8">8</option>
                <option value="12">12</option>
                <option value="all">all</option>
              </select>
              <p id="point-image-count" class="gallery-count"></p>
            </div>
      </div>
      <div id="point-images" class="image-grid"></div>
      <div id=\"point-meta\" class=\"meta\"></div>
    </aside>
  </div>

  <script>
    const payloads = {payloads_json};
    const plot = document.getElementById('citall_plot');
    const pointId = document.getElementById('point-id');
    const pointIndex = document.getElementById('point-index');
    const pointImages = document.getElementById('point-images');
    const pointImageCount = document.getElementById('point-image-count');
    const pointImageLimit = document.getElementById('point-image-limit');
    const pointMeta = document.getElementById('point-meta');
    let currentImagePaths = [];

    function clearMeta() {{
      while (pointMeta.firstChild) pointMeta.removeChild(pointMeta.firstChild);
    }}

    function renderMeta(metadata) {{
      clearMeta();
      const entries = Object.entries(metadata || {{}});
      if (!entries.length) {{
        const empty = document.createElement('p');
        empty.className = 'value';
        empty.textContent = 'No metadata available for this point.';
        pointMeta.appendChild(empty);
        return;
      }}
      for (const [key, value] of entries) {{
        const row = document.createElement('div');
        row.className = 'meta-row';

        const label = document.createElement('p');
        label.className = 'label';
        label.textContent = key;

        const val = document.createElement('p');
        val.className = 'value';
        val.textContent = typeof value === 'string' ? value : JSON.stringify(value);

        row.appendChild(label);
        row.appendChild(val);
        pointMeta.appendChild(row);
      }}
    }}

    function clearImages() {{
      while (pointImages.firstChild) pointImages.removeChild(pointImages.firstChild);
    }}

    function getImageLimit() {{
      if (!pointImageLimit) return 6;
      const value = pointImageLimit.value;
      if (value === 'all') return Number.POSITIVE_INFINITY;
      const numeric = Number(value);
      return Number.isFinite(numeric) && numeric > 0 ? numeric : 6;
    }}

    function renderImages(imagePaths) {{
      clearImages();
      const paths = Array.isArray(imagePaths) ? imagePaths : [];
      const limit = getImageLimit();
      const visiblePaths = limit === Number.POSITIVE_INFINITY ? paths : paths.slice(0, limit);
      pointImageCount.textContent = paths.length
        ? `${{visiblePaths.length}} / ${{paths.length}} image(s)`
        : 'No images';
      if (!paths.length) return;

      for (const src of visiblePaths) {{
        const img = document.createElement('img');
        img.className = 'preview';
        img.alt = 'preview';
        img.src = src;
        pointImages.appendChild(img);
      }}
    }}

    function renderPoint(pointIndexValue) {{
      const payload = payloads[pointIndexValue];
      if (!payload) return;

      pointId.textContent = payload.id ?? 'unknown';
      pointIndex.textContent = `index: ${{payload.index}}`;
      renderMeta(payload.metadata || {{}});
      currentImagePaths = payload.image_paths || (payload.image_path ? [payload.image_path] : []);
      renderImages(currentImagePaths);
    }}

    if (pointImageLimit) {{
      pointImageLimit.addEventListener('change', function() {{
        renderImages(currentImagePaths);
      }});
    }}

    if (plot && plot.on) {{
      plot.on('plotly_click', function(eventData) {{
        if (!eventData || !eventData.points || !eventData.points.length) return;
        const point = eventData.points[0];
        let idx = point.customdata;
        if (Array.isArray(idx)) idx = idx[0];
        if (typeof idx !== 'number') idx = point.pointIndex;
        renderPoint(idx);
      }});
    }}
  </script>
</body>
</html>
"""

    output_html.parent.mkdir(parents=True, exist_ok=True)
    output_html.write_text(html, encoding="utf-8")
