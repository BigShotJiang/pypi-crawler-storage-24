Copyright (c) 2026 Sika Security. All Rights Reserved.

This software and associated documentation files (the "Software") are the 
proprietary property of Sika Security. 

Unauthorized copying, distribution, modification, or use of this Software, 
via any medium, is strictly prohibited. This Software is confidential and 
proprietary to Sika Security.

For licensing inquiries, please contact: info@sikasecurity.com
