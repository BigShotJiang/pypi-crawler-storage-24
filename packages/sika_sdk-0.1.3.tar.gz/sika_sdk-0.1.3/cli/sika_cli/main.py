"""Sika CLI entry point."""

from __future__ import annotations

import typer

from sika import __version__
from sika_cli.commands.auth import auth_app
from sika_cli.commands.recon import recon_app

app = typer.Typer(
    name="sika",
    help="Sika Security CLI — scan, analyze, and secure.",
    no_args_is_help=True,
)

app.add_typer(auth_app)
app.add_typer(recon_app)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"sika {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    version: bool | None = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON.",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Minimal output.",
    ),
    no_color: bool = typer.Option(
        False,
        "--no-color",
        help="Disable colour output.",
    ),
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="Named credential profile.",
    ),
    environment: str = typer.Option(
        "production",
        "--env",
        help="API environment (production or dev).",
    ),
) -> None:
    """Sika Security CLI."""
    obj = ctx.ensure_object(dict)
    obj["json"] = json_output
    obj["quiet"] = quiet
    obj["no_color"] = no_color
    obj["profile"] = profile
    obj["environment"] = environment
