"""Rich output helpers for the Sika CLI.

Provides console creation, JSON output, and status styling used
across all CLI commands.  All colors are derived from the Sika brand
palette (see ``docs/brand-reference.md`` in sika-core-platform).
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from rich.console import Console
from rich.theme import Theme

if TYPE_CHECKING:
    import typer

    from sika.recon.models import ScanStatus

# ---------------------------------------------------------------------------
# Brand theme
# ---------------------------------------------------------------------------

SIKA_THEME = Theme({
    "brand": "#1473e6",             # Brand blue bright
    "brand.dark": "#064da3",        # Brand blue dark
    "heading": "bold #064da3",      # Section headings
    "error": "#c10e34",             # Brand red — errors, destructive
    "success": "#10b981",           # Positive confirmations
    "warning": "#f59e0b",           # Caution / in-progress
    "info": "#3b82f6",              # Informational notices
    "muted": "#6d6d6d",             # Secondary text
    "teal": "#00816e",              # Secondary accent
})

# ---------------------------------------------------------------------------
# Console
# ---------------------------------------------------------------------------


def get_console(ctx: typer.Context) -> Console:
    """Return a Rich console respecting ``--no-color``.

    Args:
        ctx: Typer context carrying global options in ``ctx.obj``.
    """
    obj: dict[str, Any] = ctx.ensure_object(dict)
    return Console(no_color=obj.get("no_color", False), theme=SIKA_THEME)


def get_error_console(ctx: typer.Context) -> Console:
    """Return a Rich console for stderr output.

    Args:
        ctx: Typer context carrying global options in ``ctx.obj``.
    """
    obj: dict[str, Any] = ctx.ensure_object(dict)
    return Console(
        stderr=True, no_color=obj.get("no_color", False), theme=SIKA_THEME
    )


# ---------------------------------------------------------------------------
# JSON output
# ---------------------------------------------------------------------------


def print_json(data: Any) -> None:
    """Print *data* as formatted JSON to stdout.

    Args:
        data: Any JSON-serialisable value (dict, list, str, etc.).
    """
    print(json.dumps(data, indent=2, default=str))


# ---------------------------------------------------------------------------
# Status styling
# ---------------------------------------------------------------------------

_STATUS_COLOURS: dict[str, str] = {
    "submitted": "info",
    "discovering": "warning",
    "resolving": "warning",
    "attributing": "warning",
    "analyzing_history": "warning",
    "analyzing_bgp": "warning",
    "expanding_asns": "warning",
    "analyzing_peering": "warning",
    "detecting_scrubbing": "warning",
    "analyzing_customers": "warning",
    "scoring_resilience": "warning",
    "completed": "success",
    "failed": "error",
}


def status_style(status: ScanStatus | str) -> str:
    """Return a Rich markup string for a scan status.

    Args:
        status: A :class:`~sika.recon.models.ScanStatus` or plain string.

    Returns:
        A Rich-styled string like ``[green]completed[/green]``.
    """
    value = str(status)
    colour = _STATUS_COLOURS.get(value, "white")
    return f"[{colour}]{value}[/{colour}]"
