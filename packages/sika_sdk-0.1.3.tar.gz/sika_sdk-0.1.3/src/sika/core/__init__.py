"""Sika Core Platform client (future)."""
