"""Health check for the Recon API.

Provides a standalone function to query the Recon service health endpoint.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from sika.recon.models import HealthStatus

if TYPE_CHECKING:
    from sika._http import SikaHTTPClient

_HEALTH_PATH = "/recon/v1/health"


def health(http: SikaHTTPClient) -> HealthStatus:
    """Check Recon service health.

    Args:
        http: The SDK HTTP client for making API requests.

    Returns:
        A :class:`~sika.recon.models.HealthStatus` with service status,
        individual check results, version, and timestamp.

    Raises:
        AuthenticationError: If not authenticated (401).
        ServerError: If the service is unhealthy (5xx).
    """
    data = http.get(_HEALTH_PATH)
    return HealthStatus.model_validate(data)
