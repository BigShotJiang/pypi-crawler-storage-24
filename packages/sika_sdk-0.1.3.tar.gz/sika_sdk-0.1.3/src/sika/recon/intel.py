"""Intel resource for the Recon API.

Provides threat intelligence database operations via :class:`IntelResource`.
These endpoints are typically restricted to sysadmin users.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from sika.recon.models import IntelStatus

if TYPE_CHECKING:
    from sika._http import SikaHTTPClient

_INTEL_PATH = "/recon/v1/intel"


class IntelResource:
    """Client for Recon threat intelligence operations.

    Accessed via ``client.recon.intel``. Provides methods to check and
    trigger updates of the threat intelligence database.

    Args:
        http: The SDK HTTP client for making API requests.
    """

    def __init__(self, http: SikaHTTPClient) -> None:
        self._http = http

    def status(self) -> IntelStatus:
        """Get the current intel database status.

        Returns the last update time, version, and size of the threat
        intelligence database.

        Returns:
            An :class:`~sika.recon.models.IntelStatus` with current
            database metadata.

        Raises:
            AuthenticationError: If not authenticated (401).
            ForbiddenError: If not authorized for this operation (403).
        """
        data = self._http.get(f"{_INTEL_PATH}/status")
        return IntelStatus.model_validate(data)

    def update(self) -> IntelStatus:
        """Trigger an intel database refresh.

        Initiates an update of the threat intelligence database and
        returns the updated status.

        Returns:
            An :class:`~sika.recon.models.IntelStatus` reflecting the
            new database state.

        Raises:
            AuthenticationError: If not authenticated (401).
            ForbiddenError: If not authorized for this operation (403).
        """
        data = self._http.post(f"{_INTEL_PATH}/update")
        return IntelStatus.model_validate(data)
