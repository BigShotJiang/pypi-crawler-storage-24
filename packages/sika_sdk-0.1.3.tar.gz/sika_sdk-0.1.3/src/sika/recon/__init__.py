"""Sika Recon product client.

Provides :class:`ReconClient` as the entry point for all Recon API
operations. Accessed via ``client.recon`` on a :class:`~sika.SikaClient`
instance.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from sika.recon.health import health as _health
from sika.recon.intel import IntelResource
from sika.recon.scans import ScansResource

if TYPE_CHECKING:
    from sika._http import SikaHTTPClient
    from sika.recon.models import HealthStatus


class ReconClient:
    """Client for the Recon product API.

    Accessed as ``client.recon`` on a :class:`~sika.SikaClient` instance.
    Product resources are available as attributes.

    Attributes:
        scans: Operations on recon scans (create, get, list, delete,
            report, wait).
        intel: Operations on threat intelligence data (status, update).

    Args:
        http: The SDK HTTP client for making API requests.
    """

    def __init__(self, http: SikaHTTPClient) -> None:
        self._http = http
        self.scans = ScansResource(http)
        self.intel = IntelResource(http)

    def health(self) -> HealthStatus:
        """Check Recon service health.

        Returns:
            A :class:`~sika.recon.models.HealthStatus` with service
            status, individual check results, version, and timestamp.

        Raises:
            AuthenticationError: If not authenticated (401).
            ServerError: If the service is unhealthy (5xx).
        """
        return _health(self._http)
