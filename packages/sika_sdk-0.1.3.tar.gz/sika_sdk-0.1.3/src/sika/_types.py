"""Shared type definitions for the Sika SDK."""
