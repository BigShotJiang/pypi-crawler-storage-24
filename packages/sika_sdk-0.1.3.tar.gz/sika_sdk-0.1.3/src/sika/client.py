"""Sika SDK client — top-level entry point."""

from __future__ import annotations

from typing import TYPE_CHECKING

from sika._http import BASE_URLS, SikaHTTPClient
from sika.auth import resolve_api_key
from sika.recon import ReconClient

if TYPE_CHECKING:
    from pathlib import Path


class SikaClient:
    """Client for the Sika Security platform APIs.

    The ``SikaClient`` is the main entry point for all SDK operations.
    Product-specific clients are accessed as attributes (e.g.
    ``client.recon``).

    Credentials are resolved in priority order:

    1. ``api_key`` constructor parameter.
    2. ``SIKA_API_KEY`` environment variable.
    3. ``~/.sika/credentials`` file (TOML format).

    If no credentials are found, the client is still created but API
    calls will fail with :class:`~sika.AuthenticationError`.

    Args:
        api_key: API key for authentication. If not provided, the SDK
            resolves credentials from environment variables and the
            credential file.
        environment: API environment to use. Either ``"production"``
            (default) or ``"dev"``.
        profile: Named profile to use from the credential file.
            Defaults to the ``[default]`` section.
        credentials_path: Override path to the credential file.
            Defaults to ``~/.sika/credentials``.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        environment: str = "production",
        profile: str | None = None,
        credentials_path: Path | None = None,
    ) -> None:
        self._api_key = resolve_api_key(
            api_key,
            profile=profile,
            credentials_path=credentials_path,
        )
        self._environment = environment

        base_url = BASE_URLS.get(environment, BASE_URLS["production"])
        self._http = SikaHTTPClient(
            base_url=base_url,
            api_key=self._api_key or "",
        )

        self.recon = ReconClient(self._http)

    @property
    def api_key(self) -> str | None:
        """The resolved API key, or ``None`` if no credentials were found."""
        return self._api_key

    @property
    def environment(self) -> str:
        """The API environment this client is configured for."""
        return self._environment
