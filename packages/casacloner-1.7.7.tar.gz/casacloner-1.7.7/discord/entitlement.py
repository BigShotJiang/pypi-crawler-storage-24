# -*- coding: utf-8 -*-

"""
The MIT License (MIT)

Copyright (c) 2015-present Noritem

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
"""

from .mixins import Hashable
from .utils import parse_time
from .enums import EntitlementType, try_enum

__all__ = (
    'Entitlement',
)


class Entitlement(Hashable):
    """Represents a Discord entitlement.

    Attributes
    ----------
    id: :class:`int`
        The entitlement's ID.
    sku_id: :class:`int`
        The ID of the SKU.
    application_id: :class:`int`
        The ID of the parent application.
    user_id: Optional[:class:`int`]
        The user ID granted access.
    type: :class:`EntitlementType`
        The type of entitlement.
    deleted: :class:`bool`
        Whether the entitlement was deleted.
    starts_at: Optional[:class:`datetime.datetime`]
        When the entitlement is valid from.
    ends_at: Optional[:class:`datetime.datetime`]
        When the entitlement is no longer valid.
    guild_id: Optional[:class:`int`]
        The guild ID granted access.
    consumed: :class:`bool`
        Whether the consumable entitlement has been consumed.
    """

    __slots__ = (
        '_state', 'id', 'sku_id', 'application_id', 'user_id',
        'type', 'deleted', 'starts_at', 'ends_at', 'guild_id', 'consumed',
    )

    def __init__(self, *, state=None, data):
        self._state = state
        self.id = int(data['id'])
        self.sku_id = int(data['sku_id'])
        self.application_id = int(data['application_id'])
        user_id = data.get('user_id')
        self.user_id = int(user_id) if user_id else None
        self.type = try_enum(EntitlementType, data.get('type', 1))
        self.deleted = data.get('deleted', False)
        self.starts_at = parse_time(data.get('starts_at'))
        self.ends_at = parse_time(data.get('ends_at'))
        guild_id = data.get('guild_id')
        self.guild_id = int(guild_id) if guild_id else None
        self.consumed = data.get('consumed', False)

    def __repr__(self):
        return '<Entitlement id={0.id} sku_id={0.sku_id} type={0.type!r}>'.format(self)

    @property
    def is_active(self):
        """:class:`bool`: Whether this entitlement is currently active (not deleted and not ended)."""
        return not self.deleted

    async def consume(self):
        """|coro|

        Marks a consumable entitlement as consumed.
        """
        if self._state:
            await self._state.http.consume_entitlement(self.application_id, self.id)
            self.consumed = True
