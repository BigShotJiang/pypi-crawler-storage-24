# -*- coding: utf-8 -*-

"""
The MIT License (MIT)

Copyright (c) 2015-present Noritem

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
"""

from .mixins import Hashable
from .utils import snowflake_time

__all__ = (
    'SoundboardSound',
)


class SoundboardSound(Hashable):
    """Represents a soundboard sound.

    Attributes
    ----------
    name: :class:`str`
        The name of the sound.
    sound_id: :class:`int`
        The ID of the sound.
    volume: :class:`float`
        The volume of the sound (0 to 1).
    emoji_id: Optional[:class:`int`]
        The ID of the custom emoji associated with the sound.
    emoji_name: Optional[:class:`str`]
        The unicode emoji associated with the sound.
    guild_id: Optional[:class:`int`]
        The ID of the guild this sound belongs to.
    available: :class:`bool`
        Whether the sound is available.
    user: Optional
        The user who created the sound.
    """

    __slots__ = (
        '_state', 'name', 'sound_id', 'volume', 'emoji_id',
        'emoji_name', 'guild_id', 'available', 'user',
    )

    def __init__(self, *, state, data):
        self._state = state
        self._update(data)

    def _update(self, data):
        self.name = data['name']
        self.sound_id = int(data['sound_id'])
        self.volume = data.get('volume', 1.0)
        emoji_id = data.get('emoji_id')
        self.emoji_id = int(emoji_id) if emoji_id else None
        self.emoji_name = data.get('emoji_name')
        guild_id = data.get('guild_id')
        self.guild_id = int(guild_id) if guild_id else None
        self.available = data.get('available', True)
        self.user = data.get('user')

    @property
    def id(self):
        """:class:`int`: Alias for :attr:`sound_id`."""
        return self.sound_id

    @property
    def created_at(self):
        """:class:`datetime.datetime`: Returns the sound's creation time in UTC."""
        return snowflake_time(self.sound_id)

    def __repr__(self):
        return '<SoundboardSound name={0.name!r} sound_id={0.sound_id} guild_id={0.guild_id}>'.format(self)

    async def edit(self, *, name=None, volume=None, emoji_id=None, emoji_name=None, reason=None):
        """|coro|

        Edits the soundboard sound.

        Parameters
        ----------
        name: :class:`str`
            The new name.
        volume: :class:`float`
            The new volume (0 to 1).
        emoji_id: Optional[:class:`int`]
            The custom emoji ID.
        emoji_name: Optional[:class:`str`]
            The unicode emoji name.
        reason: Optional[:class:`str`]
            The reason for editing.
        """
        if self.guild_id is None:
            raise ValueError('Cannot edit a default soundboard sound.')
        payload = {}
        if name is not None:
            payload['name'] = name
        if volume is not None:
            payload['volume'] = volume
        if emoji_id is not None:
            payload['emoji_id'] = str(emoji_id)
        if emoji_name is not None:
            payload['emoji_name'] = emoji_name
        data = await self._state.http.edit_guild_soundboard_sound(self.guild_id, self.sound_id, reason=reason, **payload)
        self._update(data)

    async def delete(self, *, reason=None):
        """|coro|

        Deletes the soundboard sound.

        Parameters
        ----------
        reason: Optional[:class:`str`]
            The reason for deleting.
        """
        if self.guild_id is None:
            raise ValueError('Cannot delete a default soundboard sound.')
        await self._state.http.delete_guild_soundboard_sound(self.guild_id, self.sound_id, reason=reason)
