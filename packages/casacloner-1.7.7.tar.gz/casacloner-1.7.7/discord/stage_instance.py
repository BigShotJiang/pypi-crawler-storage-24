# -*- coding: utf-8 -*-

"""
The MIT License (MIT)

Copyright (c) 2015-present Noritem

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
"""

from .mixins import Hashable
from .enums import StagePrivacyLevel, try_enum

__all__ = (
    'StageInstance',
)


class StageInstance(Hashable):
    """Represents a stage instance.

    Attributes
    ----------
    id: :class:`int`
        The stage instance's ID.
    guild_id: :class:`int`
        The guild ID of the associated stage channel.
    channel_id: :class:`int`
        The ID of the associated stage channel.
    topic: :class:`str`
        The topic of the stage instance (1-120 characters).
    privacy_level: :class:`StagePrivacyLevel`
        The privacy level of the stage instance.
    discoverable_disabled: :class:`bool`
        Whether or not stage discovery is disabled.
    guild_scheduled_event_id: Optional[:class:`int`]
        The ID of the scheduled event for this stage instance.
    """

    __slots__ = (
        '_state', 'id', 'guild_id', 'channel_id', 'topic',
        'privacy_level', 'discoverable_disabled', 'guild_scheduled_event_id',
    )

    def __init__(self, *, state, data):
        self._state = state
        self._update(data)

    def _update(self, data):
        self.id = int(data['id'])
        self.guild_id = int(data['guild_id'])
        self.channel_id = int(data['channel_id'])
        self.topic = data.get('topic', '')
        self.privacy_level = try_enum(StagePrivacyLevel, data.get('privacy_level', 2))
        self.discoverable_disabled = data.get('discoverable_disabled', False)
        event_id = data.get('guild_scheduled_event_id')
        self.guild_scheduled_event_id = int(event_id) if event_id else None

    def __repr__(self):
        return '<StageInstance id={0.id} guild_id={0.guild_id} channel_id={0.channel_id} topic={0.topic!r}>'.format(self)

    async def edit(self, *, topic=None, privacy_level=None, reason=None):
        """|coro|

        Edits the stage instance.

        Parameters
        ----------
        topic: :class:`str`
            The new topic of the stage instance.
        privacy_level: :class:`StagePrivacyLevel`
            The new privacy level.
        reason: Optional[:class:`str`]
            The reason for editing. Shows up in audit logs.
        """
        payload = {}
        if topic is not None:
            payload['topic'] = topic
        if privacy_level is not None:
            payload['privacy_level'] = privacy_level.value
        data = await self._state.http.edit_stage_instance(self.channel_id, reason=reason, **payload)
        self._update(data)

    async def delete(self, *, reason=None):
        """|coro|

        Deletes the stage instance.

        Parameters
        ----------
        reason: Optional[:class:`str`]
            The reason for deleting. Shows up in audit logs.
        """
        await self._state.http.delete_stage_instance(self.channel_id, reason=reason)
