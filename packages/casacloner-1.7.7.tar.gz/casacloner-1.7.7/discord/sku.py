# -*- coding: utf-8 -*-

"""
The MIT License (MIT)

Copyright (c) 2015-present Noritem

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
"""

from .mixins import Hashable
from .enums import SKUType, try_enum

__all__ = (
    'SKU',
)


class SKU(Hashable):
    """Represents a Discord SKU (stock-keeping unit).

    Attributes
    ----------
    id: :class:`int`
        The SKU's ID.
    type: :class:`SKUType`
        The type of SKU.
    application_id: :class:`int`
        The ID of the parent application.
    name: :class:`str`
        The customer-facing name.
    slug: :class:`str`
        System-generated URL slug.
    flags: :class:`int`
        The SKU flags as a bitfield.
    """

    __slots__ = ('id', 'type', 'application_id', 'name', 'slug', 'flags')

    def __init__(self, data):
        self.id = int(data['id'])
        self.type = try_enum(SKUType, data.get('type', 5))
        self.application_id = int(data['application_id'])
        self.name = data.get('name', '')
        self.slug = data.get('slug', '')
        self.flags = data.get('flags', 0)

    def __repr__(self):
        return '<SKU id={0.id} name={0.name!r} type={0.type!r}>'.format(self)

    @property
    def is_available(self):
        """:class:`bool`: Whether the SKU is available for purchase."""
        return bool(self.flags & (1 << 2))

    @property
    def is_guild_subscription(self):
        """:class:`bool`: Whether this is a guild subscription SKU."""
        return bool(self.flags & (1 << 7))

    @property
    def is_user_subscription(self):
        """:class:`bool`: Whether this is a user subscription SKU."""
        return bool(self.flags & (1 << 8))
