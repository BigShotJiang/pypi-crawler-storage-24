"""
FlaxKV2 核心模块
"""

from flaxkv2.core.raw_lmdb_dict import RawLmdbDict
from flaxkv2.core.cached_lmdb_dict import CachedLmdbDict

__all__ = ["RawLmdbDict", "CachedLmdbDict"]

# 注意: LevelDBDict 已弃用，不再从 core 模块导出
# 强烈建议迁移到 RawLmdbDict（基于 LMDB）