"""
QuarterBit AXIOM - Memory-Efficient Training
=============================================

Usage:
    from quarterbit import axiom

    results = axiom(
        model='gpt2-large',
        train_loader=train_loader,
        val_loader=val_loader,
        steps=1000,
    )

70% better validation improvement, 2x less memory than FP16+AdamW.

License: Free account required at https://quarterbit.dev
"""

__version__ = "25.0.0"
__author__ = "Clouthier Simulation Labs"

# License check on import
from .license import check_license, LicenseError

_LICENSE_VALID = False
try:
    check_license(silent=True)
    _LICENSE_VALID = True
except LicenseError:
    import sys
    print("\n" + "="*60)
    print("QuarterBit requires a free account.")
    print("")
    print("Sign up (free): https://quarterbit.dev")
    print("Then run:       quarterbit login")
    print("="*60 + "\n")

# Check PyTorch
try:
    import torch as _torch
    _HAS_TORCH = True
    if not _torch.cuda.is_available():
        import warnings
        warnings.warn(
            "QuarterBit: CUDA not available. GPU required for full performance.",
            RuntimeWarning
        )
except ImportError:
    _HAS_TORCH = False
    import warnings
    warnings.warn(
        "QuarterBit: PyTorch not found. Install from https://pytorch.org/get-started/locally/",
        ImportWarning
    )

# Main exports (requires PyTorch AND license)
if _HAS_TORCH and _LICENSE_VALID:
    from .axiom import axiom

    __all__ = [
        "axiom",
        "__version__",
    ]
elif _HAS_TORCH and not _LICENSE_VALID:
    def _license_required_func(*args, **kwargs):
        raise LicenseError(
            "License required. Sign up free at quarterbit.dev then run: quarterbit login"
        )

    axiom = _license_required_func

    __all__ = [
        "axiom",
        "__version__",
    ]
else:
    __all__ = ["__version__"]
