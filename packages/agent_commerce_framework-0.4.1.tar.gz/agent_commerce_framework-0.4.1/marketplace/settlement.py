"""
Settlement engine — calculates and records provider payouts.
Aggregates usage records into settlement batches.
Supports USDC payouts via WalletManager.
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from .db import Database

logger = logging.getLogger("settlement")


class SettlementError(Exception):
    """Settlement processing errors."""


class SettlementEngine:
    """
    Processes provider payouts by aggregating usage records.

    Flow:
    1. Query usage records for a period
    2. Calculate total revenue per provider
    3. Subtract platform fee (dynamic via CommissionEngine, or fixed fallback)
    4. Create settlement record
    """

    def __init__(
        self,
        db: Database,
        platform_fee_pct: Decimal = Decimal("0.10"),
        wallet_manager: Optional["WalletManager"] = None,
        commission_engine: Optional["CommissionEngine"] = None,
    ):
        self.db = db
        self.platform_fee_pct = platform_fee_pct
        self.wallet = wallet_manager
        self.commission_engine = commission_engine

    def calculate_settlement(
        self,
        provider_id: str,
        period_start: str,
        period_end: str,
    ) -> dict:
        """
        Calculate settlement for a provider in a given period.

        Returns a settlement summary dict (not yet persisted).
        """
        if not provider_id:
            raise SettlementError("provider_id is required")

        with self.db.connect() as conn:
            row = conn.execute(
                """SELECT
                       COUNT(*) as call_count,
                       COALESCE(SUM(amount_usd), 0) as total_revenue
                   FROM usage_records
                   WHERE provider_id = ?
                     AND timestamp >= ?
                     AND timestamp < ?
                     AND status_code < 500""",
                (provider_id, period_start, period_end),
            ).fetchone()

        total = Decimal(str(row["total_revenue"]))

        # Use dynamic commission rate if engine is available
        if self.commission_engine is not None:
            fee_pct = self.commission_engine.get_commission_rate(provider_id)
        else:
            fee_pct = self.platform_fee_pct

        platform_fee = total * fee_pct
        net_amount = total - platform_fee

        return {
            "provider_id": provider_id,
            "period_start": period_start,
            "period_end": period_end,
            "call_count": row["call_count"],
            "total_amount": total,
            "platform_fee": platform_fee,
            "net_amount": net_amount,
        }

    def create_settlement(
        self,
        provider_id: str,
        period_start: str,
        period_end: str,
    ) -> dict:
        """
        Calculate and persist a settlement record.

        Returns the created settlement with ID.
        """
        summary = self.calculate_settlement(
            provider_id, period_start, period_end
        )

        settlement_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()

        with self.db.connect() as conn:
            conn.execute(
                """INSERT INTO settlements
                   (id, provider_id, period_start, period_end,
                    total_amount, platform_fee, net_amount, status)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    settlement_id,
                    provider_id,
                    period_start,
                    period_end,
                    float(summary["total_amount"]),
                    float(summary["platform_fee"]),
                    float(summary["net_amount"]),
                    "pending",
                ),
            )

        return {
            "id": settlement_id,
            **summary,
            "status": "pending",
        }

    def list_settlements(
        self,
        provider_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """List settlement records with optional filters."""
        conditions = []
        params: list = []

        if provider_id:
            conditions.append("provider_id = ?")
            params.append(provider_id)
        if status:
            conditions.append("status = ?")
            params.append(status)

        where = " AND ".join(conditions) if conditions else "1=1"
        params.append(limit)

        with self.db.connect() as conn:
            rows = conn.execute(
                f"""SELECT * FROM settlements
                    WHERE {where}
                    ORDER BY period_end DESC
                    LIMIT ?""",
                params,
            ).fetchall()

        return [
            {
                "id": r["id"],
                "provider_id": r["provider_id"],
                "period_start": r["period_start"],
                "period_end": r["period_end"],
                "total_amount": Decimal(str(r["total_amount"])),
                "platform_fee": Decimal(str(r["platform_fee"])),
                "net_amount": Decimal(str(r["net_amount"])),
                "status": r["status"],
                "payment_tx": r["payment_tx"],
            }
            for r in rows
        ]

    def mark_paid(self, settlement_id: str, payment_tx: str) -> bool:
        """Mark a settlement as paid with transaction hash."""
        with self.db.connect() as conn:
            cursor = conn.execute(
                """UPDATE settlements
                   SET status = 'completed', payment_tx = ?
                   WHERE id = ? AND status = 'pending'""",
                (payment_tx, settlement_id),
            )
            return cursor.rowcount > 0

    async def execute_payout(
        self,
        settlement_id: str,
        provider_wallet: str,
    ) -> dict:
        """
        Execute USDC payout for a pending settlement.

        Uses WalletManager to send USDC to the provider's wallet.
        Returns result dict with status and optional tx hash.
        """
        if not self.wallet or not self.wallet.is_ready:
            return {
                "settlement_id": settlement_id,
                "status": "skipped",
                "reason": "Wallet not configured",
            }

        # Get settlement details
        settlements = self.list_settlements(status="pending")
        target = None
        for s in settlements:
            if s["id"] == settlement_id:
                target = s
                break

        if not target:
            raise SettlementError(f"Settlement {settlement_id} not found or not pending")

        if target["net_amount"] <= 0:
            return {
                "settlement_id": settlement_id,
                "status": "skipped",
                "reason": "Zero amount",
            }

        # Verify wallet matches provider's registered address
        provider_record = self.db.get_agent(target["provider_id"])
        if provider_record:
            registered_wallet = provider_record.get("wallet_address")
            if registered_wallet and registered_wallet != provider_wallet:
                raise SettlementError(
                    "provider_wallet does not match registered wallet address"
                )

        # Mark processing
        with self.db.connect() as conn:
            conn.execute(
                "UPDATE settlements SET status = 'processing' WHERE id = ?",
                (settlement_id,),
            )

        # Execute transfer
        tx_hash = await self.wallet.transfer_usdc(
            to_address=provider_wallet,
            amount=target["net_amount"],
        )

        if tx_hash:
            self.mark_paid(settlement_id, tx_hash)
            logger.info(
                "Payout complete: %s USDC → %s (tx: %s)",
                target["net_amount"], provider_wallet, tx_hash,
            )
            return {
                "settlement_id": settlement_id,
                "status": "completed",
                "tx_hash": tx_hash,
                "amount": str(target["net_amount"]),
            }

        # Transfer failed — revert to pending
        with self.db.connect() as conn:
            conn.execute(
                "UPDATE settlements SET status = 'failed' WHERE id = ?",
                (settlement_id,),
            )
        logger.error("Payout failed for settlement %s", settlement_id)
        return {
            "settlement_id": settlement_id,
            "status": "failed",
            "reason": "USDC transfer failed",
        }
