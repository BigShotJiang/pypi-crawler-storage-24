"""
Payment Proxy — Routes requests through marketplace with automatic payment.
Core innovation: buyers don't need x402 SDK, marketplace handles payment.
"""
from __future__ import annotations

import time
import uuid
import logging
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

import asyncio
import ipaddress
import os
import socket
from urllib.parse import urlparse

import httpx

from .db import Database
from .models import UsageRecord
from .payment import extract_payment_tx

logger = logging.getLogger("proxy")

# Internal hosts allowed to bypass SSRF protection (platform-owned services)
_INTERNAL_ALLOWED = set(
    h.strip() for h in os.environ.get("ACF_INTERNAL_HOSTS", "").split(",")
) - {""}


class ProxyError(Exception):
    """Payment proxy errors."""


class PaymentProxy:
    """
    Proxies requests to service providers with payment handling.

    Flow:
    1. Buyer sends request to marketplace proxy
    2. Proxy looks up service pricing
    3. Proxy selects payment provider via PaymentRouter (if available)
    4. Proxy forwards request to provider
    5. Proxy records usage + payment
    6. Returns provider response to buyer
    """

    def __init__(
        self,
        db: Database,
        platform_fee_pct: Decimal = Decimal("0.10"),
        timeout_seconds: int = 30,
        payment_router: object | None = None,
        webhook_manager: object | None = None,
    ):
        self.db = db
        self.platform_fee_pct = platform_fee_pct
        self.timeout = timeout_seconds
        self._payment_router = payment_router
        self._webhook_manager = webhook_manager

    async def forward_request(
        self,
        service: dict,
        buyer_id: str,
        method: str,
        path: str,
        headers: dict | None = None,
        body: bytes | None = None,
        query_params: dict | None = None,
        request_headers: dict | None = None,
        x402_paid: bool = False,
    ) -> ProxyResult:
        """
        Forward a request to a service provider.

        Returns ProxyResult with response data and billing info.
        """
        if service.get("status") != "active":
            raise ProxyError("Service is not active")

        endpoint = service["endpoint"].rstrip("/")
        target_url = f"{endpoint}{path}" if path else endpoint

        # Runtime SSRF protection — resolve hostname and block private IPs
        try:
            parsed = urlparse(target_url)
            if parsed.hostname and parsed.hostname not in _INTERNAL_ALLOWED:
                try:
                    addrs = socket.getaddrinfo(parsed.hostname, None)
                except socket.gaierror:
                    # DNS resolution failed — will be caught by httpx later
                    addrs = []
                for addr_info in addrs:
                    try:
                        resolved_ip = ipaddress.ip_address(addr_info[4][0])
                        if (
                            resolved_ip.is_private
                            or resolved_ip.is_loopback
                            or resolved_ip.is_link_local
                            or resolved_ip.is_reserved
                        ):
                            raise ProxyError(
                                "Service endpoint resolves to a private address"
                            )
                    except ValueError:
                        pass  # Non-IP address format, let httpx handle
        except ProxyError:
            raise

        price = Decimal(str(service.get("price_per_call", 0)))
        provider_id = service["provider_id"]
        service_id = service["id"]

        # Check free tier with exclusive transaction to prevent TOCTOU race
        free_calls = service.get("free_tier_calls", 0)
        is_free_tier = False
        if free_calls > 0:
            with self.db.connect() as conn:
                conn.execute("BEGIN EXCLUSIVE")
                try:
                    row = conn.execute(
                        """SELECT COUNT(*) as cnt FROM usage_records
                           WHERE service_id = ? AND buyer_id = ?""",
                        (service_id, buyer_id),
                    ).fetchone()
                    current_count = row["cnt"] if row else 0
                    if current_count < free_calls:
                        price = Decimal("0")
                        is_free_tier = True
                    conn.execute("COMMIT")
                except Exception:
                    conn.execute("ROLLBACK")
                    raise

        # Generate record_id early so it can be used as order_id for payments
        record_id = str(uuid.uuid4())

        # For paid calls: handle payment based on method
        payment_id = None
        payment_method = service.get("payment_method", "x402")
        if price > 0:
            if x402_paid:
                # x402 middleware already verified crypto payment — skip balance deduction
                # Require valid transaction hash as proof of payment
                tx_hash = extract_payment_tx(dict(headers or {}))
                if not tx_hash or len(tx_hash) < 10:
                    # No valid tx hash — fall back to balance deduction
                    logger.warning(
                        "x402_paid=True but no valid tx hash for service %s, falling back to balance",
                        service_id,
                    )
                    if not self.db.deduct_balance(buyer_id, price):
                        raise ProxyError(
                            f"Insufficient balance. Required: ${price} USDC. "
                            f"Deposit funds via POST /api/v1/deposits"
                        )
                    payment_id = f"balance:{record_id}"
                else:
                    payment_id = tx_hash
                    payment_method = "x402"
                    logger.info(
                        "x402 payment verified: $%s from %s for service %s (tx: %s)",
                        price, buyer_id, service_id, tx_hash[:16],
                    )
            else:
                # Deduct from buyer's pre-paid balance
                if not self.db.deduct_balance(buyer_id, price):
                    raise ProxyError(
                        f"Insufficient balance. Required: ${price} USDC. "
                        f"Deposit funds via POST /api/v1/deposits"
                    )
                payment_id = f"balance:{record_id}"
                logger.info(
                    "Balance deducted: $%s from %s for service %s",
                    price, buyer_id, service_id,
                )

        start_time = time.monotonic()
        status_code = 0
        response_body = b""
        response_headers = {}
        error_msg = None

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                # Build request
                req_headers = dict(headers or {})
                # Remove hop-by-hop headers
                for h in ("host", "connection", "transfer-encoding",
                          "authorization", "cookie", "x-api-key"):
                    req_headers.pop(h, None)

                response = await client.request(
                    method=method.upper(),
                    url=target_url,
                    headers=req_headers,
                    content=body,
                    params=query_params,
                )

                status_code = response.status_code
                response_body = response.content
                response_headers = dict(response.headers)

        except httpx.TimeoutException:
            status_code = 504
            error_msg = "Provider timeout"
        except httpx.ConnectError:
            status_code = 502
            error_msg = "Provider unreachable"
        except Exception as e:
            status_code = 500
            error_msg = "Proxy error: an internal error occurred"
            logger.error("Proxy forward error: %s", e)

        elapsed_ms = int((time.monotonic() - start_time) * 1000)

        # Record usage (record_id generated earlier for payment order_id)
        now = datetime.now(timezone.utc).isoformat()

        usage_record = {
            "id": record_id,
            "buyer_id": buyer_id,
            "service_id": service_id,
            "provider_id": provider_id,
            "timestamp": now,
            "latency_ms": elapsed_ms,
            "status_code": status_code,
            "amount_usd": float(price) if status_code < 500 else 0,
            "payment_method": payment_method,
            "payment_tx": payment_id or extract_payment_tx(request_headers or {}),
        }
        self.db.insert_usage(usage_record)

        # Dispatch webhook event (fire-and-forget with error logging)
        if self._webhook_manager is not None and status_code < 500:
            try:
                def _on_webhook_done(task):
                    if task.exception():
                        logger.warning(
                            "Webhook dispatch error: %s", task.exception()
                        )

                wh_task = asyncio.ensure_future(
                    self._webhook_manager.dispatch("service.called", {
                        "usage_id": record_id,
                        "service_id": service_id,
                        "buyer_id": buyer_id,
                        "provider_id": provider_id,
                        "amount_usd": float(price),
                        "payment_method": payment_method,
                        "status_code": status_code,
                        "latency_ms": elapsed_ms,
                    })
                )
                wh_task.add_done_callback(_on_webhook_done)
            except Exception as e:
                logger.warning("Webhook dispatch failed: %s", e)

        # Calculate splits
        platform_fee = price * self.platform_fee_pct
        provider_amount = price - platform_fee

        return ProxyResult(
            status_code=status_code,
            body=response_body,
            headers=response_headers,
            latency_ms=elapsed_ms,
            billing=BillingInfo(
                amount=price,
                platform_fee=platform_fee,
                provider_amount=provider_amount,
                usage_id=record_id,
                free_tier=is_free_tier,
            ),
            error=error_msg,
        )


class ProxyResult:
    """Result of a proxied request."""

    __slots__ = ("status_code", "body", "headers", "latency_ms", "billing", "error")

    def __init__(
        self,
        status_code: int,
        body: bytes,
        headers: dict,
        latency_ms: int,
        billing: "BillingInfo",
        error: Optional[str],
    ):
        self.status_code = status_code
        self.body = body
        self.headers = headers
        self.latency_ms = latency_ms
        self.billing = billing
        self.error = error

    @property
    def success(self) -> bool:
        return self.status_code < 400


class BillingInfo:
    """Billing information for a proxied request."""

    __slots__ = ("amount", "platform_fee", "provider_amount", "usage_id", "free_tier")

    def __init__(
        self,
        amount: Decimal,
        platform_fee: Decimal,
        provider_amount: Decimal,
        usage_id: str,
        free_tier: bool = False,
    ):
        self.amount = amount
        self.platform_fee = platform_fee
        self.provider_amount = provider_amount
        self.usage_id = usage_id
        self.free_tier = free_tier
