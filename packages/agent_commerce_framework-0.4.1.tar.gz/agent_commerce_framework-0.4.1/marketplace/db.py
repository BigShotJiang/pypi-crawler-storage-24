"""
Database operations for Agent Commerce Framework.
Uses SQLite for development, can swap to PostgreSQL for production.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Generator


_DEFAULT_DB = Path(__file__).parent.parent / "data" / "marketplace.db"

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS services (
    id TEXT PRIMARY KEY,
    provider_id TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    endpoint TEXT NOT NULL,
    price_per_call REAL NOT NULL,
    currency TEXT DEFAULT 'USDC',
    payment_method TEXT DEFAULT 'x402',
    free_tier_calls INTEGER DEFAULT 0,
    status TEXT DEFAULT 'active',
    category TEXT DEFAULT '',
    tags TEXT DEFAULT '[]',
    metadata TEXT DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS api_keys (
    key_id TEXT PRIMARY KEY,
    hashed_secret TEXT NOT NULL,
    owner_id TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'buyer',
    rate_limit INTEGER DEFAULT 60,
    wallet_address TEXT,
    created_at TEXT NOT NULL,
    expires_at TEXT
);

CREATE TABLE IF NOT EXISTS usage_records (
    id TEXT PRIMARY KEY,
    buyer_id TEXT NOT NULL,
    service_id TEXT NOT NULL,
    provider_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    latency_ms INTEGER DEFAULT 0,
    status_code INTEGER DEFAULT 200,
    amount_usd REAL DEFAULT 0,
    payment_method TEXT DEFAULT 'x402',
    payment_tx TEXT
);

CREATE TABLE IF NOT EXISTS settlements (
    id TEXT PRIMARY KEY,
    provider_id TEXT NOT NULL,
    period_start TEXT,
    period_end TEXT,
    total_amount REAL DEFAULT 0,
    platform_fee REAL DEFAULT 0,
    net_amount REAL DEFAULT 0,
    payment_tx TEXT,
    status TEXT DEFAULT 'pending'
);

CREATE INDEX IF NOT EXISTS idx_usage_buyer
    ON usage_records(buyer_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_usage_service
    ON usage_records(service_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_services_status
    ON services(status, category);
CREATE INDEX IF NOT EXISTS idx_keys_owner
    ON api_keys(owner_id);

-- Agent Identity
CREATE TABLE IF NOT EXISTS agent_identities (
    agent_id TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    owner_id TEXT NOT NULL,
    identity_type TEXT DEFAULT 'api_key_only',
    capabilities TEXT DEFAULT '[]',
    wallet_address TEXT,
    verified INTEGER DEFAULT 0,
    reputation_score REAL DEFAULT 0.0,
    status TEXT DEFAULT 'active',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    metadata TEXT DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_agents_owner
    ON agent_identities(owner_id);
CREATE INDEX IF NOT EXISTS idx_agents_status
    ON agent_identities(status);

-- Reputation Records
CREATE TABLE IF NOT EXISTS reputation_records (
    id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    service_id TEXT NOT NULL,
    overall_score REAL DEFAULT 0.0,
    latency_score REAL DEFAULT 0.0,
    reliability_score REAL DEFAULT 0.0,
    response_quality REAL DEFAULT 0.0,
    call_count INTEGER DEFAULT 0,
    period TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_reputation_agent
    ON reputation_records(agent_id, period);
CREATE INDEX IF NOT EXISTS idx_reputation_service
    ON reputation_records(service_id, period);

-- Teams
CREATE TABLE IF NOT EXISTS teams (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    owner_id TEXT NOT NULL,
    description TEXT DEFAULT '',
    config TEXT DEFAULT '{}',
    status TEXT DEFAULT 'active',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_teams_owner
    ON teams(owner_id);

-- Team Members
CREATE TABLE IF NOT EXISTS team_members (
    id TEXT PRIMARY KEY,
    team_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    role TEXT DEFAULT 'worker',
    skills TEXT DEFAULT '[]',
    joined_at TEXT NOT NULL,
    UNIQUE(team_id, agent_id)
);

CREATE INDEX IF NOT EXISTS idx_members_team
    ON team_members(team_id);
CREATE INDEX IF NOT EXISTS idx_members_agent
    ON team_members(agent_id);

-- Routing Rules
CREATE TABLE IF NOT EXISTS routing_rules (
    id TEXT PRIMARY KEY,
    team_id TEXT NOT NULL,
    name TEXT NOT NULL,
    keywords TEXT DEFAULT '[]',
    target_agent_id TEXT NOT NULL,
    priority INTEGER DEFAULT 0,
    enabled INTEGER DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_routing_team
    ON routing_rules(team_id, priority);

-- Quality Gates
CREATE TABLE IF NOT EXISTS quality_gates (
    id TEXT PRIMARY KEY,
    team_id TEXT NOT NULL,
    gate_type TEXT NOT NULL,
    threshold REAL NOT NULL,
    gate_order INTEGER DEFAULT 0,
    config TEXT DEFAULT '{}',
    enabled INTEGER DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_gates_team
    ON quality_gates(team_id, gate_order);

-- Webhooks
CREATE TABLE IF NOT EXISTS webhooks (
    id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL,
    url TEXT NOT NULL,
    events TEXT DEFAULT '[]',
    secret TEXT NOT NULL,
    active INTEGER DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_webhooks_owner
    ON webhooks(owner_id);

-- Buyer Balances (pre-paid credit system)
CREATE TABLE IF NOT EXISTS balances (
    buyer_id TEXT PRIMARY KEY,
    balance REAL NOT NULL DEFAULT 0,
    total_deposited REAL NOT NULL DEFAULT 0,
    total_spent REAL NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
);

-- Deposit records (IPN-confirmed only)
CREATE TABLE IF NOT EXISTS deposits (
    id TEXT PRIMARY KEY,
    buyer_id TEXT NOT NULL,
    amount REAL NOT NULL,
    currency TEXT DEFAULT 'USDC',
    payment_provider TEXT NOT NULL,
    payment_id TEXT,
    payment_status TEXT DEFAULT 'pending',
    confirmed_at TEXT,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_deposits_buyer
    ON deposits(buyer_id, payment_status);
CREATE INDEX IF NOT EXISTS idx_deposits_payment
    ON deposits(payment_id);

-- Founding Sellers (first 50 permanent badges)
CREATE TABLE IF NOT EXISTS founding_sellers (
    id TEXT PRIMARY KEY,
    provider_id TEXT NOT NULL UNIQUE,
    sequence_number INTEGER NOT NULL UNIQUE,
    badge_tier TEXT DEFAULT 'founding',
    commission_rate REAL DEFAULT 0.08,
    awarded_at TEXT NOT NULL,
    metadata TEXT DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_founding_provider
    ON founding_sellers(provider_id);
CREATE INDEX IF NOT EXISTS idx_founding_sequence
    ON founding_sellers(sequence_number);

-- Email subscribers (download gate)
CREATE TABLE IF NOT EXISTS subscribers (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    source TEXT DEFAULT 'starter-kit',
    subscribed_at TEXT NOT NULL,
    confirmed BOOLEAN DEFAULT 0,
    drip_stage INTEGER DEFAULT 0,
    drip_next_at TEXT,
    unsubscribed BOOLEAN DEFAULT 0,
    metadata TEXT DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_subscribers_email
    ON subscribers(email);
CREATE INDEX IF NOT EXISTS idx_subscribers_drip
    ON subscribers(drip_next_at, unsubscribed);
"""


class Database:
    """SQLite database wrapper with context manager support."""

    def __init__(self, db_path: str | Path | None = None):
        self.db_path = Path(db_path) if db_path else _DEFAULT_DB
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _init_schema(self) -> None:
        with self.connect() as conn:
            conn.executescript(SCHEMA_SQL)

    @contextmanager
    def connect(self) -> Generator[sqlite3.Connection, None, None]:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    # --- Service operations ---

    def insert_service(self, service: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO services
                   (id, provider_id, name, description, endpoint,
                    price_per_call, currency, payment_method, free_tier_calls,
                    status, category, tags, metadata, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    service["id"],
                    service["provider_id"],
                    service["name"],
                    service.get("description", ""),
                    service["endpoint"],
                    float(service["price_per_call"]),
                    service.get("currency", "USDC"),
                    service.get("payment_method", "x402"),
                    service.get("free_tier_calls", 0),
                    service.get("status", "active"),
                    service.get("category", ""),
                    json.dumps(service.get("tags", [])),
                    json.dumps(service.get("metadata", {})),
                    service["created_at"],
                    service["updated_at"],
                ),
            )

    def get_service(self, service_id: str) -> dict | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM services WHERE id = ?", (service_id,)
            ).fetchone()
            if not row:
                return None
            return self._row_to_service(row)

    def list_services(
        self,
        status: str = "active",
        category: str | None = None,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict]:
        conditions = ["status = ?"]
        params: list = [status]

        if category:
            conditions.append("category = ?")
            params.append(category)

        if query:
            conditions.append("(name LIKE ? OR description LIKE ?)")
            like = f"%{query}%"
            params.extend([like, like])

        where = " AND ".join(conditions)
        params.extend([limit, offset])

        with self.connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM services WHERE {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
                params,
            ).fetchall()
            return [self._row_to_service(r) for r in rows]

    def update_service(self, service_id: str, updates: dict) -> bool:
        allowed = {"name", "description", "endpoint", "price_per_call",
                    "currency", "payment_method", "status", "category",
                    "tags", "metadata", "updated_at"}
        filtered = {k: v for k, v in updates.items() if k in allowed}
        if not filtered:
            return False

        if "tags" in filtered:
            filtered["tags"] = json.dumps(filtered["tags"])
        if "metadata" in filtered:
            filtered["metadata"] = json.dumps(filtered["metadata"])
        if "price_per_call" in filtered:
            filtered["price_per_call"] = float(filtered["price_per_call"])

        set_clause = ", ".join(f"{k} = ?" for k in filtered)
        values = list(filtered.values()) + [service_id]

        with self.connect() as conn:
            cursor = conn.execute(
                f"UPDATE services SET {set_clause} WHERE id = ?", values
            )
            return cursor.rowcount > 0

    def delete_service(self, service_id: str) -> bool:
        return self.update_service(service_id, {"status": "removed"})

    # --- Usage operations ---

    def insert_usage(self, record: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO usage_records
                   (id, buyer_id, service_id, provider_id, timestamp,
                    latency_ms, status_code, amount_usd, payment_method, payment_tx)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    record["id"],
                    record["buyer_id"],
                    record["service_id"],
                    record["provider_id"],
                    record["timestamp"],
                    record.get("latency_ms", 0),
                    record.get("status_code", 200),
                    float(record.get("amount_usd", 0)),
                    record.get("payment_method", "x402"),
                    record.get("payment_tx"),
                ),
            )

    def get_usage_stats(
        self, service_id: str | None = None, buyer_id: str | None = None
    ) -> dict:
        conditions = []
        params: list = []

        if service_id:
            conditions.append("service_id = ?")
            params.append(service_id)
        if buyer_id:
            conditions.append("buyer_id = ?")
            params.append(buyer_id)

        where = " AND ".join(conditions) if conditions else "1=1"

        with self.connect() as conn:
            row = conn.execute(
                f"""SELECT COUNT(*) as total_calls,
                           SUM(amount_usd) as total_revenue,
                           AVG(latency_ms) as avg_latency
                    FROM usage_records WHERE {where}""",
                params,
            ).fetchone()
            return {
                "total_calls": row["total_calls"] or 0,
                "total_revenue": Decimal(str(row["total_revenue"] or 0)),
                "avg_latency_ms": round(row["avg_latency"] or 0, 1),
            }

    # --- API Key operations ---

    def insert_api_key(self, key: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO api_keys
                   (key_id, hashed_secret, owner_id, role,
                    rate_limit, wallet_address, created_at, expires_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    key["key_id"],
                    key["hashed_secret"],
                    key["owner_id"],
                    key.get("role", "buyer"),
                    key.get("rate_limit", 60),
                    key.get("wallet_address"),
                    key["created_at"],
                    key.get("expires_at"),
                ),
            )

    def get_api_key(self, key_id: str) -> dict | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM api_keys WHERE key_id = ?", (key_id,)
            ).fetchone()
            return dict(row) if row else None

    # --- Agent Identity operations ---

    def insert_agent(self, agent: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO agent_identities
                   (agent_id, display_name, owner_id, identity_type,
                    capabilities, wallet_address, verified, reputation_score,
                    status, created_at, updated_at, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    agent["agent_id"],
                    agent["display_name"],
                    agent["owner_id"],
                    agent.get("identity_type", "api_key_only"),
                    json.dumps(agent.get("capabilities", [])),
                    agent.get("wallet_address"),
                    1 if agent.get("verified") else 0,
                    agent.get("reputation_score", 0.0),
                    agent.get("status", "active"),
                    agent["created_at"],
                    agent["updated_at"],
                    json.dumps(agent.get("metadata", {})),
                ),
            )

    def get_agent(self, agent_id: str) -> dict | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM agent_identities WHERE agent_id = ?", (agent_id,)
            ).fetchone()
            if not row:
                return None
            return self._row_to_agent(row)

    def list_agents(
        self,
        owner_id: str | None = None,
        status: str = "active",
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict]:
        conditions = ["status = ?"]
        params: list = [status]
        if owner_id:
            conditions.append("owner_id = ?")
            params.append(owner_id)
        where = " AND ".join(conditions)
        params.extend([limit, offset])
        with self.connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM agent_identities WHERE {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
                params,
            ).fetchall()
            return [self._row_to_agent(r) for r in rows]

    def update_agent(self, agent_id: str, updates: dict) -> bool:
        allowed = {
            "display_name", "identity_type", "capabilities",
            "wallet_address", "verified", "reputation_score",
            "status", "updated_at", "metadata",
        }
        filtered = {k: v for k, v in updates.items() if k in allowed}
        if not filtered:
            return False
        if "capabilities" in filtered:
            filtered["capabilities"] = json.dumps(filtered["capabilities"])
        if "metadata" in filtered:
            filtered["metadata"] = json.dumps(filtered["metadata"])
        if "verified" in filtered:
            filtered["verified"] = 1 if filtered["verified"] else 0
        set_clause = ", ".join(f"{k} = ?" for k in filtered)
        values = list(filtered.values()) + [agent_id]
        with self.connect() as conn:
            cursor = conn.execute(
                f"UPDATE agent_identities SET {set_clause} WHERE agent_id = ?", values
            )
            return cursor.rowcount > 0

    def delete_agent(self, agent_id: str) -> bool:
        return self.update_agent(agent_id, {"status": "deactivated"})

    def search_agents(
        self, query: str, limit: int = 20
    ) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                """SELECT * FROM agent_identities
                   WHERE status = 'active'
                     AND (display_name LIKE ? OR agent_id LIKE ?)
                   ORDER BY reputation_score DESC
                   LIMIT ?""",
                (f"%{query}%", f"%{query}%", limit),
            ).fetchall()
            return [self._row_to_agent(r) for r in rows]

    # --- Reputation operations ---

    def insert_reputation(self, record: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO reputation_records
                   (id, agent_id, service_id, overall_score, latency_score,
                    reliability_score, response_quality, call_count, period, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    record["id"],
                    record["agent_id"],
                    record["service_id"],
                    record.get("overall_score", 0.0),
                    record.get("latency_score", 0.0),
                    record.get("reliability_score", 0.0),
                    record.get("response_quality", 0.0),
                    record.get("call_count", 0),
                    record["period"],
                    record["created_at"],
                ),
            )

    def get_reputation(
        self, agent_id: str, period: str = "all-time"
    ) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                """SELECT * FROM reputation_records
                   WHERE agent_id = ? AND period = ?
                   ORDER BY overall_score DESC""",
                (agent_id, period),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_service_reputation(
        self, service_id: str, period: str = "all-time"
    ) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                """SELECT * FROM reputation_records
                   WHERE service_id = ? AND period = ?
                   ORDER BY overall_score DESC""",
                (service_id, period),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_usage_for_reputation(
        self, provider_id: str, service_id: str | None = None,
        period_start: str | None = None, period_end: str | None = None,
    ) -> dict:
        """Aggregate usage stats for reputation calculation."""
        conditions = ["provider_id = ?"]
        params: list = [provider_id]
        if service_id:
            conditions.append("service_id = ?")
            params.append(service_id)
        if period_start:
            conditions.append("timestamp >= ?")
            params.append(period_start)
        if period_end:
            conditions.append("timestamp <= ?")
            params.append(period_end)
        where = " AND ".join(conditions)
        with self.connect() as conn:
            row = conn.execute(
                f"""SELECT COUNT(*) as total_calls,
                           AVG(latency_ms) as avg_latency,
                           SUM(CASE WHEN status_code >= 500 THEN 1 ELSE 0 END) as error_count,
                           SUM(CASE WHEN status_code < 400 THEN 1 ELSE 0 END) as success_count
                    FROM usage_records WHERE {where}""",
                params,
            ).fetchone()
            total = row["total_calls"] or 0
            return {
                "total_calls": total,
                "avg_latency": round(row["avg_latency"] or 0, 1),
                "error_count": row["error_count"] or 0,
                "success_count": row["success_count"] or 0,
                "error_rate": round((row["error_count"] or 0) / total * 100, 2) if total > 0 else 0.0,
                "success_rate": round((row["success_count"] or 0) / total * 100, 2) if total > 0 else 0.0,
            }

    # --- Team operations ---

    def insert_team(self, team: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO teams
                   (id, name, owner_id, description, config, status, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    team["id"],
                    team["name"],
                    team["owner_id"],
                    team.get("description", ""),
                    json.dumps(team.get("config", {})),
                    team.get("status", "active"),
                    team["created_at"],
                    team["updated_at"],
                ),
            )

    def get_team(self, team_id: str) -> dict | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM teams WHERE id = ?", (team_id,)
            ).fetchone()
            if not row:
                return None
            d = dict(row)
            d["config"] = json.loads(d.get("config", "{}"))
            return d

    def list_teams(
        self, owner_id: str | None = None, limit: int = 50
    ) -> list[dict]:
        if owner_id:
            sql = "SELECT * FROM teams WHERE owner_id = ? AND status = 'active' ORDER BY created_at DESC LIMIT ?"
            params = [owner_id, limit]
        else:
            sql = "SELECT * FROM teams WHERE status = 'active' ORDER BY created_at DESC LIMIT ?"
            params = [limit]
        with self.connect() as conn:
            rows = conn.execute(sql, params).fetchall()
            result = []
            for r in rows:
                d = dict(r)
                d["config"] = json.loads(d.get("config", "{}"))
                result.append(d)
            return result

    def update_team(self, team_id: str, updates: dict) -> bool:
        allowed = {"name", "description", "config", "status", "updated_at"}
        filtered = {k: v for k, v in updates.items() if k in allowed}
        if not filtered:
            return False
        if "config" in filtered:
            filtered["config"] = json.dumps(filtered["config"])
        set_clause = ", ".join(f"{k} = ?" for k in filtered)
        values = list(filtered.values()) + [team_id]
        with self.connect() as conn:
            cursor = conn.execute(
                f"UPDATE teams SET {set_clause} WHERE id = ?", values
            )
            return cursor.rowcount > 0

    def delete_team(self, team_id: str) -> bool:
        return self.update_team(team_id, {"status": "archived"})

    # --- Team Members ---

    def insert_team_member(self, member: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO team_members
                   (id, team_id, agent_id, role, skills, joined_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    member["id"],
                    member["team_id"],
                    member["agent_id"],
                    member.get("role", "worker"),
                    json.dumps(member.get("skills", [])),
                    member["joined_at"],
                ),
            )

    def get_team_members(self, team_id: str) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM team_members WHERE team_id = ?", (team_id,)
            ).fetchall()
            result = []
            for r in rows:
                d = dict(r)
                d["skills"] = json.loads(d.get("skills", "[]"))
                result.append(d)
            return result

    def remove_team_member(self, team_id: str, agent_id: str) -> bool:
        with self.connect() as conn:
            cursor = conn.execute(
                "DELETE FROM team_members WHERE team_id = ? AND agent_id = ?",
                (team_id, agent_id),
            )
            return cursor.rowcount > 0

    # --- Routing Rules ---

    def insert_routing_rule(self, rule: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO routing_rules
                   (id, team_id, name, keywords, target_agent_id, priority, enabled, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    rule["id"],
                    rule["team_id"],
                    rule["name"],
                    json.dumps(rule.get("keywords", [])),
                    rule["target_agent_id"],
                    rule.get("priority", 0),
                    1 if rule.get("enabled", True) else 0,
                    rule["created_at"],
                ),
            )

    def get_routing_rules(self, team_id: str) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM routing_rules WHERE team_id = ? AND enabled = 1 ORDER BY priority DESC",
                (team_id,),
            ).fetchall()
            result = []
            for r in rows:
                d = dict(r)
                d["keywords"] = json.loads(d.get("keywords", "[]"))
                d["enabled"] = bool(d.get("enabled", 1))
                result.append(d)
            return result

    def delete_routing_rule(self, rule_id: str, team_id: str) -> bool:
        """Delete a routing rule, scoped to team_id to prevent cross-team deletion."""
        with self.connect() as conn:
            cursor = conn.execute(
                "DELETE FROM routing_rules WHERE id = ? AND team_id = ?",
                (rule_id, team_id),
            )
            return cursor.rowcount > 0

    # --- Quality Gates ---

    def insert_quality_gate(self, gate: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO quality_gates
                   (id, team_id, gate_type, threshold, gate_order, config, enabled, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    gate["id"],
                    gate["team_id"],
                    gate["gate_type"],
                    gate["threshold"],
                    gate.get("gate_order", 0),
                    json.dumps(gate.get("config", {})),
                    1 if gate.get("enabled", True) else 0,
                    gate["created_at"],
                ),
            )

    def get_quality_gates(self, team_id: str) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM quality_gates WHERE team_id = ? AND enabled = 1 ORDER BY gate_order",
                (team_id,),
            ).fetchall()
            result = []
            for r in rows:
                d = dict(r)
                d["config"] = json.loads(d.get("config", "{}"))
                d["enabled"] = bool(d.get("enabled", 1))
                result.append(d)
            return result

    def delete_quality_gate(self, gate_id: str, team_id: str) -> bool:
        """Delete a quality gate, scoped to team_id to prevent cross-team deletion."""
        with self.connect() as conn:
            cursor = conn.execute(
                "DELETE FROM quality_gates WHERE id = ? AND team_id = ?",
                (gate_id, team_id),
            )
            return cursor.rowcount > 0

    # --- Webhook operations ---

    def insert_webhook(self, webhook: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO webhooks
                   (id, owner_id, url, events, secret, active, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    webhook["id"],
                    webhook["owner_id"],
                    webhook["url"],
                    json.dumps(webhook.get("events", [])),
                    webhook["secret"],
                    1 if webhook.get("active", True) else 0,
                    webhook["created_at"],
                ),
            )

    def get_webhook(self, webhook_id: str) -> dict | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM webhooks WHERE id = ?", (webhook_id,)
            ).fetchone()
            if not row:
                return None
            return self._row_to_webhook(row)

    def list_webhooks(self, owner_id: str) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM webhooks WHERE owner_id = ? ORDER BY created_at DESC",
                (owner_id,),
            ).fetchall()
            return [self._row_to_webhook(r) for r in rows]

    def delete_webhook(self, webhook_id: str, owner_id: str) -> bool:
        """Delete a webhook, scoped to owner_id to prevent cross-owner deletion."""
        with self.connect() as conn:
            cursor = conn.execute(
                "DELETE FROM webhooks WHERE id = ? AND owner_id = ?",
                (webhook_id, owner_id),
            )
            return cursor.rowcount > 0

    def list_webhooks_for_event(self, event: str) -> list[dict]:
        """List all active webhooks subscribed to a given event."""
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM webhooks WHERE active = 1",
            ).fetchall()
            results = []
            for r in rows:
                wh = self._row_to_webhook(r)
                if event in wh["events"]:
                    results.append(wh)
            return results

    # --- Helpers ---

    @staticmethod
    def _row_to_agent(row: sqlite3.Row) -> dict:
        d = dict(row)
        d["capabilities"] = json.loads(d.get("capabilities", "[]"))
        d["metadata"] = json.loads(d.get("metadata", "{}"))
        d["verified"] = bool(d.get("verified", 0))
        return d

    # --- Founding Seller operations ---

    def get_founding_seller(self, provider_id: str) -> dict | None:
        """Get founding seller record by provider ID."""
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM founding_sellers WHERE provider_id = ?",
                (provider_id,),
            ).fetchone()
            if not row:
                return None
            d = dict(row)
            d["metadata"] = json.loads(d.get("metadata", "{}"))
            return d

    def count_founding_sellers(self) -> int:
        """Count current founding sellers."""
        with self.connect() as conn:
            row = conn.execute(
                "SELECT COUNT(*) as cnt FROM founding_sellers",
            ).fetchone()
            return row["cnt"] if row else 0

    def award_founding_seller(self, record: dict) -> bool:
        """Award founding seller badge. Returns False if limit reached or already awarded."""
        with self.connect() as conn:
            conn.execute("BEGIN EXCLUSIVE")
            try:
                # Check if already a founding seller
                existing = conn.execute(
                    "SELECT id FROM founding_sellers WHERE provider_id = ?",
                    (record["provider_id"],),
                ).fetchone()
                if existing:
                    conn.execute("ROLLBACK")
                    return False

                # Check limit (50)
                count = conn.execute(
                    "SELECT COUNT(*) as cnt FROM founding_sellers",
                ).fetchone()
                if (count["cnt"] or 0) >= 50:
                    conn.execute("ROLLBACK")
                    return False

                # Assign next sequence number
                max_seq = conn.execute(
                    "SELECT MAX(sequence_number) as mx FROM founding_sellers",
                ).fetchone()
                next_seq = (max_seq["mx"] or 0) + 1

                conn.execute(
                    """INSERT INTO founding_sellers
                       (id, provider_id, sequence_number, badge_tier,
                        commission_rate, awarded_at, metadata)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        record["id"],
                        record["provider_id"],
                        next_seq,
                        record.get("badge_tier", "founding"),
                        record.get("commission_rate", 0.08),
                        record["awarded_at"],
                        json.dumps(record.get("metadata", {})),
                    ),
                )
                conn.execute("COMMIT")
                return True
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def list_founding_sellers(self) -> list[dict]:
        """List all founding sellers ordered by sequence number."""
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM founding_sellers ORDER BY sequence_number",
            ).fetchall()
            result = []
            for r in rows:
                d = dict(r)
                d["metadata"] = json.loads(d.get("metadata", "{}"))
                result.append(d)
            return result

    # --- Balance operations (pre-paid credit system) ---

    def get_balance(self, buyer_id: str) -> Decimal:
        """Get buyer's current balance. Returns 0 if no record."""
        with self.connect() as conn:
            row = conn.execute(
                "SELECT balance FROM balances WHERE buyer_id = ?",
                (buyer_id,),
            ).fetchone()
            return Decimal(str(row["balance"])) if row else Decimal("0")

    def deduct_balance(self, buyer_id: str, amount: Decimal) -> bool:
        """Atomically deduct from buyer balance. Returns False if insufficient."""
        with self.connect() as conn:
            conn.execute("BEGIN EXCLUSIVE")
            try:
                row = conn.execute(
                    "SELECT balance, total_spent FROM balances WHERE buyer_id = ?",
                    (buyer_id,),
                ).fetchone()
                current = Decimal(str(row["balance"])) if row else Decimal("0")
                if current < amount:
                    conn.execute("ROLLBACK")
                    return False
                new_balance = float(current - amount)
                new_spent = float(Decimal(str(row["total_spent"])) + amount) if row else float(amount)
                now = datetime.now(timezone.utc).isoformat()
                if row:
                    conn.execute(
                        "UPDATE balances SET balance = ?, total_spent = ?, updated_at = ? WHERE buyer_id = ?",
                        (new_balance, new_spent, now, buyer_id),
                    )
                else:
                    conn.execute(
                        "INSERT INTO balances (buyer_id, balance, total_deposited, total_spent, updated_at) VALUES (?, ?, 0, ?, ?)",
                        (buyer_id, new_balance, float(amount), now),
                    )
                conn.execute("COMMIT")
                return True
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def credit_balance(self, buyer_id: str, amount: Decimal) -> Decimal:
        """Add funds to buyer balance. Returns new balance."""
        with self.connect() as conn:
            conn.execute("BEGIN EXCLUSIVE")
            try:
                row = conn.execute(
                    "SELECT balance, total_deposited FROM balances WHERE buyer_id = ?",
                    (buyer_id,),
                ).fetchone()
                now = datetime.now(timezone.utc).isoformat()
                if row:
                    new_bal = float(Decimal(str(row["balance"])) + amount)
                    new_dep = float(Decimal(str(row["total_deposited"])) + amount)
                    conn.execute(
                        "UPDATE balances SET balance = ?, total_deposited = ?, updated_at = ? WHERE buyer_id = ?",
                        (new_bal, new_dep, now, buyer_id),
                    )
                else:
                    new_bal = float(amount)
                    conn.execute(
                        "INSERT INTO balances (buyer_id, balance, total_deposited, total_spent, updated_at) VALUES (?, ?, ?, 0, ?)",
                        (buyer_id, new_bal, new_bal, now),
                    )
                conn.execute("COMMIT")
                return Decimal(str(new_bal))
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def insert_deposit(self, deposit: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO deposits
                   (id, buyer_id, amount, currency, payment_provider,
                    payment_id, payment_status, confirmed_at, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    deposit["id"],
                    deposit["buyer_id"],
                    float(deposit["amount"]),
                    deposit.get("currency", "USDC"),
                    deposit["payment_provider"],
                    deposit.get("payment_id"),
                    deposit.get("payment_status", "pending"),
                    deposit.get("confirmed_at"),
                    deposit["created_at"],
                ),
            )

    def confirm_deposit(self, payment_id: str) -> dict | None:
        """Mark deposit as confirmed and credit buyer balance. Returns deposit or None."""
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM deposits WHERE payment_id = ? AND payment_status = 'pending'",
                (payment_id,),
            ).fetchone()
            if not row:
                return None
            deposit = dict(row)
            now = datetime.now(timezone.utc).isoformat()
            conn.execute(
                "UPDATE deposits SET payment_status = 'confirmed', confirmed_at = ? WHERE id = ?",
                (now, deposit["id"]),
            )
            return deposit

    # --- Subscribers (email gate) ---

    def insert_subscriber(self, subscriber: dict) -> bool:
        """Insert a new subscriber. Returns True if new, False if email exists."""
        with self.connect() as conn:
            try:
                conn.execute(
                    """INSERT INTO subscribers
                       (id, email, source, subscribed_at, confirmed, drip_stage, drip_next_at, metadata)
                       VALUES (:id, :email, :source, :subscribed_at, :confirmed,
                               :drip_stage, :drip_next_at, :metadata)""",
                    subscriber,
                )
                return True
            except sqlite3.IntegrityError:
                return False

    def get_subscriber(self, email: str) -> dict | None:
        """Get subscriber by email."""
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM subscribers WHERE email = ?", (email,),
            ).fetchone()
            return dict(row) if row else None

    def list_subscribers_for_drip(self, before: str) -> list[dict]:
        """List subscribers due for next drip email."""
        with self.connect() as conn:
            rows = conn.execute(
                """SELECT * FROM subscribers
                   WHERE unsubscribed = 0 AND drip_next_at IS NOT NULL
                   AND drip_next_at <= ? ORDER BY drip_next_at""",
                (before,),
            ).fetchall()
            return [dict(r) for r in rows]

    def advance_drip(self, subscriber_id: str, new_stage: int, next_at: str | None) -> None:
        """Advance subscriber to next drip stage."""
        with self.connect() as conn:
            conn.execute(
                "UPDATE subscribers SET drip_stage = ?, drip_next_at = ? WHERE id = ?",
                (new_stage, next_at, subscriber_id),
            )

    def unsubscribe(self, email: str) -> bool:
        """Mark subscriber as unsubscribed. Returns True if found."""
        with self.connect() as conn:
            cur = conn.execute(
                "UPDATE subscribers SET unsubscribed = 1 WHERE email = ?",
                (email,),
            )
            return cur.rowcount > 0

    def count_subscribers(self) -> int:
        """Count active (non-unsubscribed) subscribers."""
        with self.connect() as conn:
            row = conn.execute(
                "SELECT COUNT(*) as cnt FROM subscribers WHERE unsubscribed = 0",
            ).fetchone()
            return row["cnt"] if row else 0

    @staticmethod
    def _row_to_service(row: sqlite3.Row) -> dict:
        d = dict(row)
        d["tags"] = json.loads(d.get("tags", "[]"))
        d["metadata"] = json.loads(d.get("metadata", "{}"))
        return d

    @staticmethod
    def _row_to_webhook(row: sqlite3.Row) -> dict:
        d = dict(row)
        d["events"] = json.loads(d.get("events", "[]"))
        d["active"] = bool(d.get("active", 1))
        return d
