"""
Audit logging for security-relevant events in Agent Commerce Framework.
Lightweight SQLite-based audit trail for authentication, key management,
admin actions, and settlement events.
"""
from __future__ import annotations

import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Generator

_DEFAULT_DB = Path(__file__).parent.parent / "data" / "marketplace.db"

AUDIT_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    target TEXT NOT NULL DEFAULT '',
    details TEXT NOT NULL DEFAULT '',
    ip_address TEXT NOT NULL DEFAULT '',
    timestamp TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_event_type
    ON audit_log(event_type);
CREATE INDEX IF NOT EXISTS idx_audit_actor
    ON audit_log(actor);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp
    ON audit_log(timestamp);
"""

VALID_EVENT_TYPES = frozenset({
    "auth_failure",
    "auth_success",
    "key_created",
    "key_revoked",
    "admin_action",
    "service_registered",
    "service_deleted",
    "settlement_executed",
    "config_changed",
})


class AuditLogger:
    """SQLite-backed audit logger for security events.

    Auto-creates the audit_log table on initialization, following the
    same pattern as the main Database class.
    """

    def __init__(self, db_path: str | Path | None = None):
        self.db_path = Path(db_path) if db_path else _DEFAULT_DB
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(AUDIT_SCHEMA_SQL)

    @contextmanager
    def _connect(self) -> Generator[sqlite3.Connection, None, None]:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def log_event(
        self,
        event_type: str,
        actor: str,
        target: str = "",
        details: str = "",
        ip_address: str = "",
    ) -> int:
        """Write an audit entry. Returns the row id of the inserted record.

        Raises ValueError if event_type is not in the allowed set.
        """
        if event_type not in VALID_EVENT_TYPES:
            raise ValueError(
                f"Invalid event_type '{event_type}'. "
                f"Must be one of: {sorted(VALID_EVENT_TYPES)}"
            )
        if not actor:
            raise ValueError("actor is required")

        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            cursor = conn.execute(
                """INSERT INTO audit_log
                   (event_type, actor, target, details, ip_address, timestamp)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (event_type, actor, target, details, ip_address, now),
            )
            return cursor.lastrowid  # type: ignore[return-value]

    def get_events(
        self,
        event_type: str | None = None,
        actor: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict]:
        """Query audit events with optional filters.

        Returns list of event dicts ordered by timestamp descending.
        """
        conditions: list[str] = []
        params: list = []

        if event_type is not None:
            conditions.append("event_type = ?")
            params.append(event_type)
        if actor is not None:
            conditions.append("actor = ?")
            params.append(actor)

        where = " AND ".join(conditions) if conditions else "1=1"
        params.extend([limit, offset])

        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM audit_log WHERE {where} "
                f"ORDER BY timestamp DESC LIMIT ? OFFSET ?",
                params,
            ).fetchall()
            return [dict(r) for r in rows]

    def get_recent(self, hours: int = 24) -> list[dict]:
        """Get audit events from the last N hours."""
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM audit_log WHERE timestamp >= ? "
                "ORDER BY timestamp DESC",
                (cutoff,),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_summary(self, hours: int = 24) -> dict[str, int]:
        """Get event counts grouped by event_type for the last N hours."""
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT event_type, COUNT(*) as count "
                "FROM audit_log WHERE timestamp >= ? "
                "GROUP BY event_type ORDER BY count DESC",
                (cutoff,),
            ).fetchall()
            return {row["event_type"]: row["count"] for row in rows}
