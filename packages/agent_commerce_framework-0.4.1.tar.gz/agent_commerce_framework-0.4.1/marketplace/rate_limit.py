"""
Simple in-memory rate limiter for API endpoints.
"""
from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field


@dataclass
class _Bucket:
    tokens: float = 0.0
    last_refill: float = field(default_factory=time.monotonic)


class RateLimiter:
    """Token-bucket rate limiter keyed by client identifier."""

    def __init__(
        self,
        rate: int = 60,
        per: float = 60.0,
        burst: int | None = None,
    ):
        self.rate = rate
        self.per = per
        self.burst = burst if burst is not None else rate
        self._buckets: dict[str, _Bucket] = defaultdict(
            lambda: _Bucket(tokens=self.burst, last_refill=time.monotonic())
        )

    def allow(self, key: str) -> bool:
        """Return True if the request is allowed, False if rate limited."""
        bucket = self._buckets[key]
        now = time.monotonic()
        elapsed = now - bucket.last_refill
        bucket.last_refill = now

        # Refill tokens
        bucket.tokens = min(
            self.burst,
            bucket.tokens + elapsed * (self.rate / self.per),
        )

        if bucket.tokens >= 1.0:
            bucket.tokens -= 1.0
            return True
        return False

    def reset(self) -> None:
        """Clear all buckets (useful for test isolation)."""
        self._buckets.clear()

    def cleanup(self, max_age: float = 3600.0) -> int:
        """Remove stale buckets older than max_age seconds. Returns count removed."""
        now = time.monotonic()
        stale = [
            k for k, v in self._buckets.items()
            if (now - v.last_refill) > max_age
        ]
        for k in stale:
            del self._buckets[k]
        return len(stale)
