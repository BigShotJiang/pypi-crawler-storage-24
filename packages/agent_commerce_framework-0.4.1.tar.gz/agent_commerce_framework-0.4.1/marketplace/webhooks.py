"""
Webhook notification system for Agent Commerce Framework.
Dispatches event notifications to subscriber endpoints with HMAC-SHA256 signatures.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import ipaddress
import json
import logging
import os
import socket
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse

import httpx

from .db import Database

logger = logging.getLogger("webhooks")

# Internal hosts allowed to bypass SSRF protection (platform-owned services)
_INTERNAL_ALLOWED = set(
    h.strip() for h in os.environ.get("ACF_INTERNAL_HOSTS", "").split(",")
) - {""}


ALLOWED_EVENTS = frozenset({
    "service.called",
    "payment.completed",
    "reputation.updated",
    "settlement.completed",
})

MAX_WEBHOOKS_PER_OWNER = 20
MAX_RETRIES = 3
INITIAL_BACKOFF_SECONDS = 1.0


class WebhookError(Exception):
    """Webhook operation errors."""


@dataclass(frozen=True)
class WebhookSubscription:
    """Immutable webhook subscription."""
    id: str = ""
    owner_id: str = ""
    url: str = ""
    events: tuple[str, ...] = ()
    secret: str = ""
    active: bool = True
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(frozen=True)
class WebhookDeliveryResult:
    """Result of a single webhook delivery attempt."""
    webhook_id: str = ""
    url: str = ""
    event: str = ""
    success: bool = False
    status_code: int = 0
    attempts: int = 0
    error: Optional[str] = None


class WebhookManager:
    """
    Manages webhook subscriptions and event dispatching.

    Supports:
    - CRUD for webhook subscriptions
    - HMAC-SHA256 signed payloads
    - Async dispatch with retry and exponential backoff
    """

    def __init__(self, db: Database):
        self.db = db

    def subscribe(
        self,
        owner_id: str,
        url: str,
        events: list[str],
        secret: str,
    ) -> WebhookSubscription:
        """
        Create a new webhook subscription.

        Validates URL (must be https://), events (must be from allowed set),
        and enforces per-owner webhook limit.
        """
        if not owner_id or not owner_id.strip():
            raise WebhookError("owner_id is required")
        owner_id = owner_id.strip()

        if not url or not url.strip():
            raise WebhookError("URL is required")
        url = url.strip()
        if not url.startswith("https://"):
            raise WebhookError("Webhook URL must use HTTPS (https://)")

        if not events:
            raise WebhookError("At least one event is required")
        invalid = set(events) - ALLOWED_EVENTS
        if invalid:
            raise WebhookError(
                f"Invalid events: {invalid}. Allowed: {sorted(ALLOWED_EVENTS)}"
            )

        if not secret or not secret.strip():
            raise WebhookError("Secret is required for HMAC signing")
        secret = secret.strip()

        # Check per-owner limit
        existing = self.db.list_webhooks(owner_id)
        if len(existing) >= MAX_WEBHOOKS_PER_OWNER:
            raise WebhookError(
                f"Maximum {MAX_WEBHOOKS_PER_OWNER} webhooks per owner"
            )

        now = datetime.now(timezone.utc)
        webhook = WebhookSubscription(
            id=str(uuid.uuid4()),
            owner_id=owner_id,
            url=url,
            events=tuple(sorted(set(events))),
            secret=secret,
            active=True,
            created_at=now,
        )

        self.db.insert_webhook({
            "id": webhook.id,
            "owner_id": webhook.owner_id,
            "url": webhook.url,
            "events": list(webhook.events),
            "secret": webhook.secret,
            "active": webhook.active,
            "created_at": webhook.created_at.isoformat(),
        })

        return webhook

    def unsubscribe(self, webhook_id: str, owner_id: str) -> bool:
        """
        Delete a webhook subscription.
        Owner-scoped: only the owner can delete their webhooks.
        """
        return self.db.delete_webhook(webhook_id, owner_id)

    def list_subscriptions(self, owner_id: str) -> list[WebhookSubscription]:
        """List all webhooks owned by the given owner."""
        rows = self.db.list_webhooks(owner_id)
        return [self._from_db(r) for r in rows]

    async def dispatch(
        self,
        event: str,
        payload: dict,
    ) -> list[WebhookDeliveryResult]:
        """
        Dispatch an event to all subscribed webhooks.

        Sends async POST requests with HMAC-SHA256 signature.
        Retries up to MAX_RETRIES times with exponential backoff on failure.
        """
        if event not in ALLOWED_EVENTS:
            logger.warning("Attempted to dispatch unknown event: %s", event)
            return []

        subscribers = self.db.list_webhooks_for_event(event)
        if not subscribers:
            return []

        tasks = [
            self._deliver(sub, event, payload)
            for sub in subscribers
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        delivery_results = []
        for r in results:
            if isinstance(r, Exception):
                logger.error("Webhook delivery exception: %s", r)
            else:
                delivery_results.append(r)

        return delivery_results

    @staticmethod
    def _check_ssrf(url: str) -> None:
        """Block webhook delivery to private/internal IPs (SSRF protection)."""
        parsed = urlparse(url)
        hostname = parsed.hostname
        if not hostname:
            raise WebhookError("Invalid webhook URL")
        if hostname in _INTERNAL_ALLOWED:
            return
        try:
            addrs = socket.getaddrinfo(hostname, None)
        except socket.gaierror:
            raise WebhookError(f"DNS resolution failed for {hostname}")
        for addr_info in addrs:
            try:
                resolved_ip = ipaddress.ip_address(addr_info[4][0])
                if (
                    resolved_ip.is_private
                    or resolved_ip.is_loopback
                    or resolved_ip.is_link_local
                    or resolved_ip.is_reserved
                ):
                    raise WebhookError("Webhook URL resolves to a private address")
            except ValueError:
                pass  # Non-IP address format, skip

    async def _deliver(
        self,
        webhook: dict,
        event: str,
        payload: dict,
    ) -> WebhookDeliveryResult:
        """Deliver a single webhook with retry logic and SSRF protection."""
        # SSRF check: block delivery to private/internal IPs
        try:
            self._check_ssrf(webhook["url"])
        except WebhookError as e:
            logger.warning("SSRF blocked webhook %s: %s", webhook["id"], e)
            return WebhookDeliveryResult(
                webhook_id=webhook["id"],
                url=webhook["url"],
                event=event,
                success=False,
                status_code=0,
                attempts=0,
                error=f"SSRF blocked: {e}",
            )

        body = json.dumps({
            "event": event,
            "payload": payload,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "webhook_id": webhook["id"],
        }, default=str)

        signature = hmac.new(
            webhook["secret"].encode("utf-8"),
            body.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        # Use consistent header name (X-ACF-Signature is the canonical name)
        headers = {
            "Content-Type": "application/json",
            "X-ACF-Signature": signature,
            "X-ACF-Event": event,
        }

        last_error: Optional[str] = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                async with httpx.AsyncClient(timeout=10.0) as client:
                    response = await client.post(
                        webhook["url"],
                        content=body,
                        headers=headers,
                    )
                    if response.status_code < 300:
                        logger.info(
                            "Webhook delivered: %s -> %s (attempt %d)",
                            event, webhook["url"], attempt,
                        )
                        return WebhookDeliveryResult(
                            webhook_id=webhook["id"],
                            url=webhook["url"],
                            event=event,
                            success=True,
                            status_code=response.status_code,
                            attempts=attempt,
                        )
                    last_error = f"HTTP {response.status_code}"
                    logger.warning(
                        "Webhook delivery failed: %s -> %s (attempt %d, %s)",
                        event, webhook["url"], attempt, last_error,
                    )
            except httpx.HTTPError as e:
                last_error = str(e)
                logger.warning(
                    "Webhook delivery error: %s -> %s (attempt %d, %s)",
                    event, webhook["url"], attempt, last_error,
                )

            # Exponential backoff before retry
            if attempt < MAX_RETRIES:
                backoff = INITIAL_BACKOFF_SECONDS * (2 ** (attempt - 1))
                await asyncio.sleep(backoff)

        return WebhookDeliveryResult(
            webhook_id=webhook["id"],
            url=webhook["url"],
            event=event,
            success=False,
            status_code=0,
            attempts=MAX_RETRIES,
            error=last_error,
        )

    @staticmethod
    def _from_db(row: dict) -> WebhookSubscription:
        return WebhookSubscription(
            id=row["id"],
            owner_id=row["owner_id"],
            url=row["url"],
            events=tuple(row.get("events", [])),
            secret=row["secret"],
            active=row.get("active", True),
            created_at=datetime.fromisoformat(row["created_at"]),
        )
