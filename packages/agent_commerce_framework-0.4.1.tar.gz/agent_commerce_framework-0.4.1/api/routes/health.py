"""Health check, landing page, and SEO endpoints."""
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates

from marketplace.i18n import SUPPORTED_LOCALES

router = APIRouter()

_TEMPLATES_DIR = Path(__file__).resolve().parent.parent.parent / "templates"
_templates = Jinja2Templates(directory=str(_TEMPLATES_DIR))


def _i18n_ctx(request: Request) -> dict:
    """Build i18n template context from request state (set by middleware)."""
    return {
        "t": getattr(request.state, "t", lambda k: k),
        "locale": getattr(request.state, "locale", "en"),
        "supported_locales": SUPPORTED_LOCALES,
    }

_BASE_URL = "https://agentictrade.io"


# ── SEO Infrastructure (Phase 0) ──────────────────────────────────


@router.get("/robots.txt", response_class=PlainTextResponse)
async def robots_txt():
    """Serve robots.txt — allow public pages, block dashboard and API."""
    return (
        "User-agent: *\n"
        "Allow: /\n"
        "Allow: /marketplace\n"
        "Allow: /api-docs\n"
        "Allow: /starter-kit\n"
        "Allow: /pricing\n"
        "Allow: /providers\n"
        "Allow: /about\n"
        "Disallow: /dashboard/\n"
        "Disallow: /api/\n"
        "Disallow: /docs\n"
        "Disallow: /checkout/\n"
        "\n"
        f"Sitemap: {_BASE_URL}/sitemap.xml\n"
    )


@router.get("/sitemap.xml", response_class=Response)
async def sitemap_xml():
    """Auto-generate sitemap with all public pages."""
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    pages = [
        {"loc": "/", "priority": "1.0", "changefreq": "weekly"},
        {"loc": "/marketplace", "priority": "0.9", "changefreq": "daily"},
        {"loc": "/api-docs", "priority": "0.8", "changefreq": "weekly"},
        {"loc": "/pricing", "priority": "0.8", "changefreq": "monthly"},
        {"loc": "/providers", "priority": "0.8", "changefreq": "monthly"},
        {"loc": "/about", "priority": "0.6", "changefreq": "monthly"},
        {"loc": "/starter-kit", "priority": "0.7", "changefreq": "monthly"},
    ]

    urls = []
    for page in pages:
        urls.append(
            f"  <url>\n"
            f"    <loc>{_BASE_URL}{page['loc']}</loc>\n"
            f"    <lastmod>{today}</lastmod>\n"
            f"    <changefreq>{page['changefreq']}</changefreq>\n"
            f"    <priority>{page['priority']}</priority>\n"
            f"  </url>"
        )

    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        + "\n".join(urls)
        + "\n</urlset>\n"
    )

    return Response(content=xml, media_type="application/xml")


@router.get("/.well-known/llms.txt", response_class=PlainTextResponse)
async def llms_txt():
    """GEO: Tell LLMs what AgenticTrade is."""
    return (
        "# AgenticTrade\n"
        "\n"
        "## What is AgenticTrade?\n"
        "AgenticTrade is an API marketplace where AI agents discover, call, and pay for\n"
        "services autonomously. Unlike traditional API marketplaces built for human\n"
        "developers, AgenticTrade enables agent-to-agent commerce with automated billing.\n"
        "\n"
        "## Key Concepts\n"
        "- MCP Tool Descriptor: machine-readable API description following the Model\n"
        "  Context Protocol. Agents read it to understand what an API does, its parameters,\n"
        "  and its pricing — without human documentation.\n"
        "- Proxy Key: a credential that routes requests through AgenticTrade infrastructure.\n"
        "  The provider's real API key is never exposed to consuming agents.\n"
        "- x402: an HTTP-native payment protocol. Agents pay per API call in USDC on Base\n"
        "  (Ethereum L2). No invoices, no subscriptions — pure per-call micropayments.\n"
        "\n"
        "## For Providers\n"
        "List your API on AgenticTrade. AI agents worldwide discover it via MCP registry,\n"
        "call it through Proxy Keys, and pay you automatically in USDC/USDT or fiat.\n"
        "Commission: 0% month 1, 5% months 2-6, 10% after.\n"
        "\n"
        "## For Agent Builders\n"
        "Integrate any marketplace API in minutes. Your agent discovers services, uses\n"
        "Proxy Keys for auth, and pays from a pre-funded wallet. No hardcoded API keys.\n"
        "\n"
        "## Facts\n"
        "- Payment methods: USDC on Base (x402), 200+ cryptocurrencies (NOWPayments),\n"
        "  fiat via Stripe Agent Checkout Protocol\n"
        "- Platform commission: 0% (month 1) -> 5% (months 2-6) -> 10% (month 7+)\n"
        "- Tech stack: Python (FastAPI), SQLite, Docker\n"
        "- Website: https://agentictrade.io\n"
        "- Built by: JudyAI Lab (https://judyailab.com)\n"
    )


@router.get("/favicon.ico")
async def favicon():
    """Redirect to static favicon."""
    return RedirectResponse(url="/static/img/favicon.ico", status_code=301)


# ── Public Pages ──────────────────────────────────────────────────


@router.get("/", response_class=HTMLResponse)
async def landing(request: Request):
    """Serve the marketing landing page."""
    db = request.app.state.db

    with db.connect() as conn:
        svc_count = conn.execute(
            "SELECT COUNT(*) as cnt FROM services WHERE status = 'active'"
        ).fetchone()["cnt"]
        total_calls = conn.execute(
            "SELECT COUNT(*) as cnt FROM usage_records"
        ).fetchone()["cnt"]
        agent_count = conn.execute(
            "SELECT COUNT(*) as cnt FROM agent_identities"
        ).fetchone()["cnt"]

    return _templates.TemplateResponse("public/landing.html", {
        "request": request,
        "service_count": svc_count,
        "total_calls": total_calls,
        "agent_count": agent_count,
        **_i18n_ctx(request),
    })


@router.get("/marketplace", response_class=HTMLResponse)
async def marketplace(request: Request):
    """Serve the marketplace browser (formerly the landing page)."""
    db = request.app.state.db

    with db.connect() as conn:
        svc_rows = conn.execute(
            "SELECT name, description, price_per_call, free_tier_calls "
            "FROM services WHERE status = 'active' ORDER BY created_at"
        ).fetchall()
        total_calls = conn.execute(
            "SELECT COUNT(*) as cnt FROM usage_records"
        ).fetchone()["cnt"]
        agent_count = conn.execute(
            "SELECT COUNT(*) as cnt FROM agent_identities"
        ).fetchone()["cnt"]

    services = [dict(r) for r in svc_rows]

    return _templates.TemplateResponse("marketplace.html", {
        "request": request,
        "service_count": len(services),
        "total_calls": total_calls,
        "agent_count": agent_count,
        "services": services,
        **_i18n_ctx(request),
    })


@router.get("/pricing", response_class=HTMLResponse)
async def pricing(request: Request):
    """Serve the pricing page."""
    db = request.app.state.db

    with db.connect() as conn:
        svc_rows = conn.execute(
            "SELECT name, description, price_per_call, free_tier_calls "
            "FROM services WHERE status = 'active' ORDER BY price_per_call ASC"
        ).fetchall()

    services = [dict(r) for r in svc_rows]

    return _templates.TemplateResponse("public/pricing.html", {
        "request": request,
        "services": services,
        **_i18n_ctx(request),
    })


@router.get("/providers", response_class=HTMLResponse)
async def providers(request: Request):
    """Serve the For Providers page."""
    return _templates.TemplateResponse("public/providers.html", {
        "request": request,
        **_i18n_ctx(request),
    })


@router.get("/about", response_class=HTMLResponse)
async def about(request: Request):
    """Serve the About page."""
    return _templates.TemplateResponse("public/about.html", {
        "request": request,
        **_i18n_ctx(request),
    })


@router.get("/starter-kit", response_class=HTMLResponse)
async def starter_kit_page(request: Request):
    """Serve the Starter Kit product/sales page."""
    return _templates.TemplateResponse("starter-kit-product.html", {
        "request": request,
        **_i18n_ctx(request),
    })


@router.get("/checkout/success", response_class=HTMLResponse)
async def checkout_success(
    request: Request,
    session_id: str = "",
    payment_id: str = "",
    provider: str = "",
):
    """Post-purchase thank you page."""
    return _templates.TemplateResponse("checkout-success.html", {
        "request": request,
        "session_id": session_id,
        "payment_id": payment_id,
        "provider": provider,
    })


@router.get("/api-docs", response_class=HTMLResponse)
async def api_docs(request: Request):
    """Serve the public API documentation page with live service data."""
    db = request.app.state.db

    with db.connect() as conn:
        svc_rows = conn.execute(
            "SELECT id, name, description, price_per_call, free_tier_calls "
            "FROM services WHERE status = 'active' ORDER BY price_per_call ASC"
        ).fetchall()

    services = [dict(r) for r in svc_rows]

    demo_id = scanner_id = backtest_id = ""
    for svc in services:
        name_lower = svc["name"].lower()
        if "demo" in name_lower:
            demo_id = svc["id"]
        elif "scanner" in name_lower:
            scanner_id = svc["id"]
        elif "backtest" in name_lower:
            backtest_id = svc["id"]

    return _templates.TemplateResponse("api-docs.html", {
        "request": request,
        "services": services,
        "demo_service_id": demo_id,
        "scanner_service_id": scanner_id,
        "backtest_service_id": backtest_id,
        **_i18n_ctx(request),
    })


@router.get("/health")
async def health():
    return {
        "status": "ok",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
