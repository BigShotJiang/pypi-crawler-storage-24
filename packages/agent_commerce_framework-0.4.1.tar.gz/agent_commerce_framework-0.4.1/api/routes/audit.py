"""
Audit log API routes — view security audit events.
All endpoints require admin authentication via require_admin.
"""
from __future__ import annotations

from fastapi import APIRouter, Query, Request

from api.deps import require_admin

router = APIRouter(tags=["admin"])


@router.get("/admin/audit")
async def list_audit_events(
    request: Request,
    event_type: str | None = Query(default=None),
    actor: str | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
):
    """List audit log events with optional filters (admin only)."""
    require_admin(request)
    audit = request.app.state.audit

    events = audit.get_events(
        event_type=event_type,
        actor=actor,
        limit=limit,
        offset=offset,
    )
    return {"events": events, "count": len(events)}


@router.get("/admin/audit/summary")
async def audit_summary(
    request: Request,
    hours: int = Query(default=24, ge=1, le=720),
):
    """Event counts by type for the last N hours (admin only)."""
    require_admin(request)
    audit = request.app.state.audit

    summary = audit.get_summary(hours=hours)
    return {"hours": hours, "summary": summary}
