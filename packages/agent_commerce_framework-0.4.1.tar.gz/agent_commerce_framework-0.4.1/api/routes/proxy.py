"""
Proxy API routes — the core payment proxy endpoint.
Buyers call the marketplace, marketplace handles payment + forwarding.
"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, Response

from marketplace.auth import APIKeyManager, AuthError
from marketplace.proxy import PaymentProxy, ProxyError

router = APIRouter(tags=["proxy"])


def _get_auth(request: Request) -> tuple[APIKeyManager, str, dict]:
    """Extract and validate API key from request headers."""
    auth_header = request.headers.get("authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing API key")

    token = auth_header[7:]  # Strip "Bearer "
    parts = token.split(":", 1)
    if len(parts) != 2:
        raise HTTPException(
            status_code=401,
            detail="Invalid key format. Use key_id:secret",
        )

    key_id, secret = parts
    key_mgr: APIKeyManager = request.app.state.auth
    try:
        key_record = key_mgr.validate(key_id, secret)
    except AuthError as e:
        raise HTTPException(status_code=401, detail=str(e))

    # Rate limit check
    limit = key_record.get("rate_limit", 60)
    if not key_mgr.check_rate_limit(key_id, limit):
        raise HTTPException(status_code=429, detail="Rate limit exceeded")

    return key_mgr, key_record["owner_id"], key_record


@router.api_route(
    "/proxy/{service_id}/{path:path}",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
)
async def proxy_request(
    service_id: str,
    path: str,
    request: Request,
):
    """
    Proxy a request to a service provider with automatic payment.

    Usage:
        POST /api/v1/proxy/{service_id}/scan
        Authorization: Bearer {key_id}:{secret}

    The marketplace:
    1. Validates your API key
    2. Looks up the service
    3. Forwards your request to the provider
    4. Records usage + handles payment
    5. Returns the provider's response
    """
    _, buyer_id, key_record = _get_auth(request)

    # Look up service
    registry = request.app.state.registry
    service = registry.get(service_id)
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")

    # Convert ServiceListing to dict for proxy
    service_dict = {
        "id": service.id,
        "provider_id": service.provider_id,
        "endpoint": service.endpoint,
        "price_per_call": str(service.pricing.price_per_call),
        "payment_method": service.pricing.payment_method,
        "free_tier_calls": service.pricing.free_tier_calls,
        "status": service.status,
    }

    # Read request body
    body = await request.body()

    # Detect if x402 middleware already verified payment for this request
    x402_paid = hasattr(request.state, "payment_payload") and request.state.payment_payload is not None

    # Forward through proxy
    proxy: PaymentProxy = request.app.state.proxy
    try:
        result = proxy_result = await proxy.forward_request(
            service=service_dict,
            buyer_id=buyer_id,
            method=request.method,
            path=f"/{path}" if path else "",
            headers=dict(request.headers),
            body=body if body else None,
            query_params=dict(request.query_params),
            x402_paid=x402_paid,
        )
    except ProxyError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # Build response with billing headers
    response_headers = {
        "X-ACF-Usage-Id": result.billing.usage_id,
        "X-ACF-Amount": str(result.billing.amount),
        "X-ACF-Free-Tier": str(result.billing.free_tier).lower(),
        "X-ACF-Latency-Ms": str(result.latency_ms),
    }

    # Filter provider response headers (remove hop-by-hop)
    skip_headers = {
        "transfer-encoding", "connection", "keep-alive",
        "proxy-authenticate", "proxy-authorization", "te",
        "trailer", "upgrade",
    }
    for key, value in result.headers.items():
        if key.lower() not in skip_headers:
            response_headers[key] = value

    content_type = result.headers.get("content-type", "application/octet-stream")

    return Response(
        content=result.body,
        status_code=result.status_code,
        headers=response_headers,
        media_type=content_type,
    )


@router.get("/usage/me")
async def my_usage(request: Request):
    """Get usage statistics for the authenticated buyer."""
    _, buyer_id, _ = _get_auth(request)

    db = request.app.state.db
    stats = db.get_usage_stats(buyer_id=buyer_id)

    return {
        "buyer_id": buyer_id,
        "total_calls": stats["total_calls"],
        "total_spent_usd": str(stats["total_revenue"]),
        "avg_latency_ms": stats["avg_latency_ms"],
    }
