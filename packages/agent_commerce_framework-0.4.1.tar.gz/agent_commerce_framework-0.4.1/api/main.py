"""
Agent Commerce Framework — API Server
FastAPI application with x402 payment support, agent identity,
reputation engine, enhanced discovery, and team management.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from decimal import Decimal

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from marketplace.db import Database
from marketplace.registry import ServiceRegistry
from marketplace.auth import APIKeyManager
from marketplace.proxy import PaymentProxy
from marketplace.commission import CommissionEngine
from marketplace.settlement import SettlementEngine
from marketplace.payment import PaymentConfig, setup_x402_middleware
from marketplace.wallet import WalletConfig, WalletManager
from marketplace.identity import IdentityManager
from marketplace.reputation import ReputationEngine
from marketplace.discovery import DiscoveryEngine
from marketplace.rate_limit import RateLimiter
from marketplace.webhooks import WebhookManager
from marketplace.audit import AuditLogger
from marketplace.i18n import detect_locale, make_translator, SUPPORTED_LOCALES
from marketplace.provider_auth import ensure_provider_accounts_table
from payments.x402_provider import X402Provider
from payments.nowpayments_provider import NOWPaymentsProvider
from payments.stripe_acp import StripeACPProvider
from payments.agentkit_provider import AgentKitProvider
from payments.router import PaymentRouter
from .routes import services, health, proxy
from .routes import auth as auth_routes
from .routes import settlement as settlement_routes
from .routes import identity as identity_routes
from .routes import reputation as reputation_routes
from .routes import discovery as discovery_routes
from .routes import teams as team_routes
from .routes import webhooks as webhook_routes
from .routes import admin as admin_routes
from .routes import audit as audit_routes
from .routes import dashboard as dashboard_routes
from .routes import billing as billing_routes
from .routes import provider as provider_routes
from .routes import email as email_routes
from .routes import referral as referral_routes
from .routes import portal as portal_routes

logger = logging.getLogger("acf")

# --- App ---

app = FastAPI(
    title="Agent Commerce Framework",
    description="Agent-to-Agent Marketplace with identity, reputation, team management, and crypto payments",
    version="0.6.0",
)

_cors_env = os.environ.get("CORS_ORIGINS", "")
if not _cors_env or _cors_env == "*":
    logger.warning(
        "CORS_ORIGINS not set or wildcard — restricting to localhost only. "
        "Set CORS_ORIGINS explicitly for production."
    )
    _cors_origins = ["http://localhost:3000"]
    _cors_all = False
else:
    _cors_origins = [o.strip() for o in _cors_env.split(",") if o.strip()]
    _cors_all = False

app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Shared state ---

db = Database(os.environ.get("DATABASE_PATH"))
registry = ServiceRegistry(db)
key_manager = APIKeyManager(db)

platform_fee = Decimal(os.environ.get("PLATFORM_FEE_PCT", "0.10"))

# Wallet for settlements (created early so AgentKit provider can use it)
wallet_config = WalletConfig.from_env()
wallet_manager = WalletManager(wallet_config)

# Build payment router with available providers
_payment_providers: dict[str, object] = {}
try:
    _x402 = X402Provider()
    if _x402.config.enabled:
        _payment_providers["x402"] = _x402
        logger.info("x402 payment provider registered")
except Exception:
    logger.info("x402 provider not configured")

if os.environ.get("NOWPAYMENTS_API_KEY"):
    try:
        _nowpay = NOWPaymentsProvider()
        _payment_providers["nowpayments"] = _nowpay
        logger.info("NOWPayments provider registered")
    except Exception:
        logger.info("NOWPayments provider not configured")

if os.environ.get("STRIPE_SECRET_KEY"):
    try:
        _stripe = StripeACPProvider()
        _payment_providers["stripe"] = _stripe
        logger.info("Stripe ACP provider registered")
    except Exception:
        logger.info("Stripe ACP provider not configured")

if wallet_manager.is_ready:
    try:
        _agentkit = AgentKitProvider(wallet_manager=wallet_manager)
        _payment_providers["agentkit"] = _agentkit
        logger.info("AgentKit payment provider registered")
    except Exception:
        logger.info("AgentKit provider not configured")

payment_router_obj = PaymentRouter(_payment_providers) if _payment_providers else None

# Webhook manager (created before proxy so proxy can dispatch events)
webhook_manager = WebhookManager(db)

# Audit logger for security events
audit_logger = AuditLogger(os.environ.get("DATABASE_PATH"))

payment_proxy = PaymentProxy(
    db,
    platform_fee_pct=platform_fee,
    payment_router=payment_router_obj,
    webhook_manager=webhook_manager,
)

# Provider Growth Program commission engine
commission_engine = CommissionEngine(db)

settlement_engine = SettlementEngine(
    db, platform_fee_pct=platform_fee, wallet_manager=wallet_manager,
    commission_engine=commission_engine,
)

# New modules
identity_manager = IdentityManager(db)
reputation_engine = ReputationEngine(db)
discovery_engine = DiscoveryEngine(db, registry)

# Rate limiter: 60 requests per minute per client
rate_limiter = RateLimiter(rate=60, per=60.0, burst=120)

# x402 payment config — must be set up before app starts (Starlette requirement)
payment_config = PaymentConfig.from_env()
if payment_config.enabled:
    _active_services = db.list_services(status="active")
    _x402_ok = setup_x402_middleware(app, payment_config, _active_services)
    if _x402_ok:
        logger.info("x402 payment middleware active")
    else:
        logger.info("x402 middleware not attached (no eligible services)")
else:
    logger.info("Running without x402 payments (WALLET_ADDRESS not set)")


@app.on_event("startup")
async def startup():
    """Initialize database, shared state, and x402 middleware."""
    app.state.db = db
    app.state.registry = registry
    app.state.auth = key_manager
    app.state.proxy = payment_proxy
    app.state.settlement = settlement_engine
    app.state.wallet = wallet_manager
    app.state.payment_config = payment_config
    app.state.identity = identity_manager
    app.state.reputation = reputation_engine
    app.state.discovery = discovery_engine
    app.state.rate_limiter = rate_limiter
    app.state.payment_router = payment_router_obj
    app.state.webhooks = webhook_manager
    app.state.commission_engine = commission_engine
    app.state.audit = audit_logger

    # Ensure provider portal tables exist
    ensure_provider_accounts_table(db)

    # x402 middleware is set up at module level (before app starts)
    # to comply with Starlette's restriction on adding middleware after startup

    # Log wallet status
    if wallet_manager.is_ready:
        logger.info("CDP wallet ready for settlements")
    else:
        logger.info("CDP wallet not configured — settlements logged only")


# --- Rate limiting middleware ---

@app.middleware("http")
async def i18n_middleware(request: Request, call_next):
    """Detect locale and attach translator to request state."""
    query_lang = request.query_params.get("lang")
    cookie_lang = request.cookies.get("lang")
    accept_lang = request.headers.get("accept-language")
    locale = detect_locale(query_lang, cookie_lang, accept_lang)
    request.state.locale = locale
    request.state.t = make_translator(locale)
    request.state.supported_locales = SUPPORTED_LOCALES
    response = await call_next(request)
    if query_lang and query_lang.lower() in SUPPORTED_LOCALES:
        response.set_cookie("lang", locale, max_age=365 * 24 * 3600, samesite="lax")
    return response


@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    """Add security headers to all responses."""
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains; preload"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline' https://rsms.me; "
        "font-src 'self' https://rsms.me; "
        "img-src 'self' data:; "
        "connect-src 'self'; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self'"
    )
    return response


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    """Apply rate limiting based on client IP with proper headers."""
    client_ip = request.client.host if request.client else "unknown"
    if not rate_limiter.allow(client_ip):
        return JSONResponse(
            status_code=429,
            content={"detail": "Rate limit exceeded. Try again later."},
            headers={"Retry-After": "60"},
        )
    return await call_next(request)


# --- Global exception handler ---

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Catch unhandled exceptions — return generic 500, log details."""
    import traceback
    logger.error("Unhandled exception: %s\n%s", exc, traceback.format_exc())
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error"},
    )


# --- Mount routes ---

app.include_router(health.router)
app.include_router(services.router, prefix="/api/v1")
app.include_router(proxy.router, prefix="/api/v1")
app.include_router(auth_routes.router, prefix="/api/v1")
app.include_router(settlement_routes.router, prefix="/api/v1")
app.include_router(identity_routes.router, prefix="/api/v1")
app.include_router(reputation_routes.router, prefix="/api/v1")
app.include_router(discovery_routes.router, prefix="/api/v1")
app.include_router(team_routes.router, prefix="/api/v1")
app.include_router(webhook_routes.router, prefix="/api/v1")
app.include_router(admin_routes.router, prefix="/api/v1")
app.include_router(audit_routes.router, prefix="/api/v1")
app.include_router(provider_routes.router, prefix="/api/v1")
app.include_router(dashboard_routes.router)
app.include_router(billing_routes.router)
app.include_router(email_routes.router)
app.include_router(referral_routes.router, prefix="/api/v1")
app.include_router(portal_routes.router)

# --- Static files ---
_static_dir = Path(__file__).resolve().parent.parent / "static"
if _static_dir.is_dir():
    app.mount("/static", StaticFiles(directory=str(_static_dir)), name="static")
