"""Tests for AgentKit payment provider."""
from __future__ import annotations

import pytest
from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock

from payments.agentkit_provider import AgentKitProvider
from payments.base import PaymentProviderError, PaymentStatus


class TestAgentKitProviderProperties:
    """Test provider metadata."""

    def test_provider_name(self):
        provider = AgentKitProvider(wallet_manager=None)
        assert provider.provider_name == "agentkit"

    def test_supported_currencies(self):
        provider = AgentKitProvider(wallet_manager=None)
        assert provider.supported_currencies == ["USDC"]

    def test_wallet_address_none_without_manager(self):
        provider = AgentKitProvider(wallet_manager=None)
        assert provider.wallet_address is None

    def test_wallet_address_from_manager(self):
        mock_wallet = MagicMock()
        mock_wallet.address = "0xABC123"
        mock_wallet.is_ready = True
        provider = AgentKitProvider(wallet_manager=mock_wallet)
        assert provider.wallet_address == "0xABC123"


class TestAgentKitCreatePayment:
    """Test payment creation."""

    @pytest.mark.asyncio
    async def test_rejects_unsupported_currency(self):
        provider = AgentKitProvider(wallet_manager=None)
        with pytest.raises(PaymentProviderError, match="only supports"):
            await provider.create_payment(
                Decimal("1.0"), "ETH", {"to_address": "0x123"}
            )

    @pytest.mark.asyncio
    async def test_rejects_zero_amount(self):
        provider = AgentKitProvider(wallet_manager=None)
        with pytest.raises(PaymentProviderError, match="positive"):
            await provider.create_payment(
                Decimal("0"), "USDC", {"to_address": "0x123"}
            )

    @pytest.mark.asyncio
    async def test_rejects_negative_amount(self):
        provider = AgentKitProvider(wallet_manager=None)
        with pytest.raises(PaymentProviderError, match="positive"):
            await provider.create_payment(
                Decimal("-5"), "USDC", {"to_address": "0x123"}
            )

    @pytest.mark.asyncio
    async def test_rejects_missing_to_address(self):
        mock_wallet = MagicMock()
        mock_wallet.is_ready = True
        provider = AgentKitProvider(wallet_manager=mock_wallet)
        with pytest.raises(PaymentProviderError, match="to_address"):
            await provider.create_payment(
                Decimal("1.0"), "USDC", {"description": "test"}
            )

    @pytest.mark.asyncio
    async def test_rejects_when_wallet_not_ready(self):
        mock_wallet = MagicMock()
        mock_wallet.is_ready = False
        provider = AgentKitProvider(wallet_manager=mock_wallet)
        with pytest.raises(PaymentProviderError, match="not configured"):
            await provider.create_payment(
                Decimal("1.0"), "USDC", {"to_address": "0x123"}
            )

    @pytest.mark.asyncio
    async def test_successful_transfer(self):
        mock_wallet = MagicMock()
        mock_wallet.is_ready = True
        mock_wallet.address = "0xSENDER"
        mock_wallet.config = MagicMock()
        mock_wallet.config.cdp_network = "base-sepolia"
        mock_wallet.transfer_usdc = AsyncMock(return_value="0xTX_HASH_123")

        provider = AgentKitProvider(wallet_manager=mock_wallet)
        result = await provider.create_payment(
            Decimal("5.50"),
            "USDC",
            {"to_address": "0xRECEIVER", "agent_id": "agent-001"},
        )

        assert result.status == PaymentStatus.completed
        assert result.payment_id.startswith("agentkit_")
        assert result.amount == Decimal("5.50")
        assert result.currency == "USDC"
        assert result.metadata["tx_hash"] == "0xTX_HASH_123"
        assert result.metadata["to_address"] == "0xRECEIVER"
        assert result.metadata["from_address"] == "0xSENDER"
        assert result.metadata["agent_id"] == "agent-001"

        mock_wallet.transfer_usdc.assert_awaited_once_with(
            to_address="0xRECEIVER",
            amount=Decimal("5.50"),
        )

    @pytest.mark.asyncio
    async def test_failed_transfer(self):
        mock_wallet = MagicMock()
        mock_wallet.is_ready = True
        mock_wallet.address = "0xSENDER"
        mock_wallet.config = MagicMock()
        mock_wallet.config.cdp_network = "base-sepolia"
        mock_wallet.transfer_usdc = AsyncMock(return_value=None)

        provider = AgentKitProvider(wallet_manager=mock_wallet)
        result = await provider.create_payment(
            Decimal("100.0"),
            "USDC",
            {"to_address": "0xRECEIVER"},
        )

        assert result.status == PaymentStatus.failed
        assert result.payment_id.startswith("agentkit_")
        assert "reason" in result.metadata

    @pytest.mark.asyncio
    async def test_currency_case_insensitive(self):
        mock_wallet = MagicMock()
        mock_wallet.is_ready = True
        mock_wallet.address = "0xSENDER"
        mock_wallet.config = MagicMock()
        mock_wallet.config.cdp_network = "base-sepolia"
        mock_wallet.transfer_usdc = AsyncMock(return_value="0xTX")

        provider = AgentKitProvider(wallet_manager=mock_wallet)
        result = await provider.create_payment(
            Decimal("1.0"), "usdc", {"to_address": "0x123"}
        )
        assert result.currency == "USDC"


class TestAgentKitVerifyPayment:
    """Test payment verification."""

    @pytest.mark.asyncio
    async def test_rejects_empty_id(self):
        provider = AgentKitProvider(wallet_manager=None)
        with pytest.raises(PaymentProviderError, match="required"):
            await provider.verify_payment("")

    @pytest.mark.asyncio
    async def test_rejects_invalid_prefix(self):
        provider = AgentKitProvider(wallet_manager=None)
        with pytest.raises(PaymentProviderError, match="Invalid"):
            await provider.verify_payment("stripe_acp_123")

    @pytest.mark.asyncio
    async def test_returns_completed_for_valid_id(self):
        provider = AgentKitProvider(wallet_manager=None)
        status = await provider.verify_payment("agentkit_abc123def456")
        assert status == PaymentStatus.completed


class TestAgentKitGetPayment:
    """Test payment retrieval."""

    @pytest.mark.asyncio
    async def test_rejects_empty_id(self):
        provider = AgentKitProvider(wallet_manager=None)
        with pytest.raises(PaymentProviderError, match="required"):
            await provider.get_payment("")

    @pytest.mark.asyncio
    async def test_returns_details(self):
        mock_wallet = MagicMock()
        mock_wallet.address = "0xWALLET"
        mock_wallet.is_ready = True
        mock_wallet.config = MagicMock()
        mock_wallet.config.cdp_network = "base-mainnet"

        provider = AgentKitProvider(wallet_manager=mock_wallet)
        details = await provider.get_payment("agentkit_test123")

        assert details["payment_id"] == "agentkit_test123"
        assert details["provider"] == "agentkit"
        assert details["wallet_address"] == "0xWALLET"
        assert details["network"] == "base-mainnet"
        assert details["wallet_ready"] is True


class TestAgentKitCreateAgentWallet:
    """Test agent wallet creation."""

    @pytest.mark.asyncio
    async def test_returns_none_without_wallet(self):
        provider = AgentKitProvider(wallet_manager=None)
        result = await provider.create_agent_wallet("agent-001")
        assert result is None

    @pytest.mark.asyncio
    async def test_delegates_to_wallet_manager(self):
        mock_wallet = MagicMock()
        mock_wallet.is_ready = True
        mock_wallet.create_agent_wallet = AsyncMock(return_value="0xNEW_WALLET")

        provider = AgentKitProvider(wallet_manager=mock_wallet)
        result = await provider.create_agent_wallet("agent-001")

        assert result == "0xNEW_WALLET"
        mock_wallet.create_agent_wallet.assert_awaited_once_with("agent-001")
