"""Tests for rate limiter module."""
from __future__ import annotations

import time

import pytest

from marketplace.rate_limit import RateLimiter


class TestRateLimiter:
    def test_allows_within_limit(self):
        limiter = RateLimiter(rate=10, per=60.0)
        for _ in range(10):
            assert limiter.allow("client-1")

    def test_blocks_over_limit(self):
        limiter = RateLimiter(rate=3, per=60.0, burst=3)
        assert limiter.allow("client-1")
        assert limiter.allow("client-1")
        assert limiter.allow("client-1")
        assert not limiter.allow("client-1")

    def test_separate_clients(self):
        limiter = RateLimiter(rate=2, per=60.0, burst=2)
        assert limiter.allow("client-1")
        assert limiter.allow("client-1")
        assert not limiter.allow("client-1")
        # Different client should still be allowed
        assert limiter.allow("client-2")

    def test_burst_allows_more(self):
        limiter = RateLimiter(rate=5, per=60.0, burst=10)
        for _ in range(10):
            assert limiter.allow("client-1")
        assert not limiter.allow("client-1")

    def test_refills_over_time(self):
        limiter = RateLimiter(rate=100, per=1.0, burst=1)
        assert limiter.allow("client-1")
        assert not limiter.allow("client-1")
        time.sleep(0.02)  # Enough for ~2 tokens at 100/sec
        assert limiter.allow("client-1")

    def test_cleanup_removes_stale(self):
        limiter = RateLimiter(rate=10, per=60.0)
        limiter.allow("old-client")
        # Manually age the bucket
        limiter._buckets["old-client"].last_refill = time.monotonic() - 7200
        removed = limiter.cleanup(max_age=3600)
        assert removed == 1
        assert "old-client" not in limiter._buckets

    def test_cleanup_keeps_active(self):
        limiter = RateLimiter(rate=10, per=60.0)
        limiter.allow("active-client")
        removed = limiter.cleanup(max_age=3600)
        assert removed == 0
        assert "active-client" in limiter._buckets

    def test_default_burst_equals_rate(self):
        limiter = RateLimiter(rate=50, per=60.0)
        assert limiter.burst == 50

    def test_empty_string_key(self):
        limiter = RateLimiter(rate=5, per=60.0)
        assert limiter.allow("")
