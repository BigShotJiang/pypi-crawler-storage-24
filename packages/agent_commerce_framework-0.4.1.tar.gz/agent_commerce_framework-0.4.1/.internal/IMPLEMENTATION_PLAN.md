# AgenticTrade Platform — 實作計劃

## Context

AgenticTrade 是一個託管式 AI Agent 服務交易平台（agentictrade.io）。核心收入來自 10% 平台佣金。

**Judy 指示（2026-03-20）**：平台技術不對外販售，我們自己運營平台。Starter Kit 免費提供，驅動開發者採用率。

現有基礎：`/home/ubuntu/projects/agent-commerce-framework/`（v0.6.0，80+ endpoints，691 tests），已有 Service Registry、API Key Auth、Payment Proxy、x402/NOWPayments/Stripe ACP 多軌支付、Identity、Reputation、Discovery、Teams、Webhooks、MCP Bridge。

策略：A→B→C 路線（A: 平台運營+10%佣金 → B: 用平台賣 CoinSifter API → C: MCP Commerce Builder）

---

## 架構概覽

在現有框架上**擴建**，不重寫。新增 4 個模組：

```
agent-commerce-framework/
├── marketplace/          # EXISTING — 擴展 identity + reputation + discovery
│   ├── models.py         # +AgentIdentity, ReputationRecord, ServiceSLA
│   ├── db.py             # +6 new tables
│   ├── identity.py       # NEW: Agent 身份驗證 (KYA JWT / DID+VC)
│   ├── reputation.py     # NEW: 自動聲譽評分（from usage data）
│   └── discovery.py      # NEW: 增強搜尋 + 推薦
├── teamwork/             # NEW — 團隊管理（產品化 OpenClaw 模式）
│   ├── agent_config.py   # Agent 定義 schema (productized openclaw.json)
│   ├── task_router.py    # YAML 任務路由 (productized linear_dispatcher)
│   ├── quality_gates.py  # 品質閘門 pipeline
│   ├── orchestrator.py   # 任務生命週期管理
│   └── templates.py      # 預設團隊範本
├── payments/             # NEW — 多軌支付抽象層 (Phase 2)
│   ├── base.py           # PaymentProvider ABC
│   ├── x402_provider.py  # 包裝現有 payment.py
│   ├── stripe_acp.py     # Stripe Agent Checkout Protocol
│   ├── dodo_provider.py  # Dodo Payments (法幣 MoR)
│   └── router.py         # 路由到正確 provider
├── mcp_bridge/           # NEW — MCP 整合 (Phase 2)
│   ├── server.py         # MCP server 暴露 marketplace tools
│   └── discovery.py      # MCP-compatible service manifest
├── api/routes/           # EXISTING — 新增路由
│   ├── identity.py       # NEW: Agent 身份 CRUD
│   ├── reputation.py     # NEW: 聲譽查詢
│   ├── teams.py          # NEW: 團隊管理 API
│   ├── discovery.py      # NEW: 增強搜尋
│   └── webhooks.py       # NEW: Webhook 管理 (Phase 2)
└── tests/                # 目標 160+ 測試
```

---

## 新增資料模型 (models.py)

### frozen dataclass

- **AgentIdentity**: agent_id, display_name, owner_id, identity_type(kya_jwt/did_vc/api_key_only), capabilities, wallet_address, verified, reputation_score, status, created_at, updated_at, metadata
- **ReputationRecord**: id, agent_id, service_id, overall_score, latency_score, reliability_score, response_quality, call_count, period, created_at
- **ServiceSLA**: service_id, max_latency_ms, min_uptime_pct, max_error_rate_pct, guaranteed_throughput

### db.py 新增 6 張表

- `agent_identities` — Agent 身份資料
- `reputation_records` — 每 service/每期間的聲譽記錄
- `teams` — 團隊定義 + config JSON
- `team_members` — 團隊成員（agent_id, role, skills）
- `routing_rules` — 任務路由規則（keywords, target_agent, priority）
- `quality_gates` — 品質閘門配置（gate_type, threshold, order）

---

## 新增 API Endpoints

| Module | Endpoints | 數量 |
|--------|-----------|------|
| Agent Identity | CRUD agents, verify, search | 5 |
| Reputation | agent/service reputation, leaderboard | 3 |
| Team Management | teams CRUD, members, routing rules, quality gates, templates | 12 |
| Enhanced Discovery | search+filters, categories, trending, recommendations | 4 |
| Webhooks | subscribe, list, delete (Phase 2) | 3 |
| **Total new** | | **~27** |

---

## 關鍵設計決策

1. **擴展不重寫** — 現有 92 測試全部保留，新模組插入不替換
2. **teamwork/ 獨立 package** — 與 marketplace 透過 agent_id 連結，無程式碼依賴；可單獨使用
3. **PaymentProvider ABC** — x402 包裝進介面，Stripe/Dodo 實作同介面，proxy 呼叫 router 選 provider
4. **聲譽 = 自動計算** — 從 usage_records 算 latency/uptime/error_rate，不是用戶評分，防造假
5. **MCP 是橋接層** — REST API 主通道，MCP 額外發現/呼叫管道
6. **SQLite dev / PostgreSQL prod** — 現有 Database class 已隔離 SQL，加 DATABASE_URL 切換

---

## 分階段實作

### Phase 1: Platform Core（Week 1-2）— 核心功能

**Week 1: Core Extensions**
1. `marketplace/identity.py` + `api/routes/identity.py` — AgentIdentity CRUD ✅ models done
2. `marketplace/reputation.py` + `api/routes/reputation.py` — 自動聲譽引擎
3. `marketplace/discovery.py` + `api/routes/discovery.py` — 增強搜尋
4. 擴展 `auth.py` 連結 API Key ↔ Agent Identity
5. 新增 `agent_identities` + `reputation_records` tables
6. 40+ 新測試

**Week 2: Team Management + Polish**
1. `teamwork/` 模組完整實作（agent_config, task_router, quality_gates, orchestrator）
2. `api/routes/teams.py` — 團隊 API
3. 3 個團隊範本 (solo/small_team/enterprise) + 3 個服務範本
4. docker-compose.yml 加 PostgreSQL
5. README 改寫為產品文件
6. 30+ 新測試

### Phase 2: Multi-Payment + MCP（Week 3-4）
1. `payments/` 多軌支付（x402 wrapper + Stripe ACP + Dodo）
2. `mcp_bridge/` MCP 整合
3. `api/routes/webhooks.py` Webhook 系統
4. 40+ 新測試

### Phase 3: Dashboard + Polish（Week 5-6）
1. Admin Dashboard
2. 交易分析 / 品質監控 UI
3. i18n（EN/ZH-TW/KO）
4. 安全審計 + QA Pipeline

### Phase 4: Advanced（Week 7+）
1. KYA JWT 真驗證（等 Skyfire SDK）
2. DID+VC 驗證
3. Agent 協商協議
4. 訂閱制定價

---

## 執行順序（Phase 1）

1. ✅ 擴展 `models.py` — 加 3 個 frozen dataclass
2. ✅ 擴展 `db.py` — 加 6 張表 + indexes + CRUD methods
3. ✅ 建 `marketplace/identity.py` + `api/routes/identity.py` + 30 tests
4. ✅ 建 `marketplace/reputation.py` + `api/routes/reputation.py` + 15 tests
5. ✅ 建 `marketplace/discovery.py` + `api/routes/discovery.py` + 16 tests
6. ✅ 建 `teamwork/` package（agent_config, task_router, quality_gates, orchestrator, templates）+ 37 tests
7. ✅ 建 `api/routes/teams.py` — 團隊 CRUD + members + rules + gates + templates
8. ✅ 擴展 `api/main.py` mount 4 新 routers + init 新 modules
9. ✅ 範本（3 team + 3 service templates，內建 teamwork/templates.py）
10. ✅ docker-compose.yml (PostgreSQL 16) + README 產品文件
11. ✅ 266 tests ALL PASSED（目標 160+，實際 266，含 61 支付測試）
12. ✅ security-reviewer + code-reviewer 完成
13. ✅ 安全修復: 2 CRITICAL + 6 HIGH 全部修復（2026-03-19）
14. ✅ Phase 2 支付: payments/ 模組完成 (base + x402 + NOWPayments + router)

## Phase 2 進度

1. ✅ payments/base.py — PaymentProvider ABC + PaymentStatus + PaymentResult
2. ✅ payments/x402_provider.py — 包裝現有 x402
3. ✅ payments/nowpayments_provider.py — NOWPayments REST API
4. ✅ payments/router.py — PaymentRouter 路由
5. ✅ marketplace/rate_limit.py — Token bucket rate limiter
6. ✅ payments/stripe_acp.py — Stripe ACP（完整實作+30 tests, 2026-03-19）
7. ⏸ payments/dodo_provider.py — Dodo Payments（等審核，MVP 不需要）
8. ✅ 整合 proxy.py 使用 PaymentRouter（lines 135-154）
9. ✅ mcp_bridge/ MCP 整合（server.py + discovery.py）
10. ✅ api/routes/webhooks.py + marketplace/webhooks.py

## Phase 2 完成！（2026-03-19）
- 498 tests ALL PASSED
- Stripe ACP 全部整合進 main.py（auto-register when STRIPE_SECRET_KEY set）
- PaymentRouter 已連入 proxy.py forward_request()
- MCP Bridge server + discovery 完成
- Webhooks 系統（subscribe/dispatch/list/delete）完成

## Phase 3 待做（Platform Launch）
1. ✅ Starter Kit 完成（免費 SDK+模板+指南，客戶端定位）— MIM-325
2. ✅ Dashboard UI 完成（5 頁面 + 58 測試）— MIM-332
3. ✅ Provider 自助上架流程（7 端點 + onboarding tracker + 19 測試）
4. ⬜ 第三方服務招募（目標 10+ 供應商，Q2 2026）
5. ✅ Platform analytics（趨勢分析/Top 服務/買家指標 + 14 測試）
6. ✅ Provider Growth Program 實作（佣金分級系統）
7. ⬜ i18n（EN/ZH-TW/KO）
8. ✅ 最終安全審計（2026-03-21, 10 issues fixed, 775 tests）

## Phase 3 進度

6. ✅ marketplace/commission.py — CommissionEngine（動態佣金計算，支援自訂 tiers）
   - CommissionTier frozen dataclass（month_start, month_end, rate）
   - DEFAULT_TIERS: M1=0%, M2-3=5%, M4+=10%（PRODUCT_SPEC）
   - get_commission_rate() 根據 provider 首次上架日期自動計算
   - get_provider_commission_info() 完整佣金資訊（含下一階段日期和費率）
   - settlement.py 整合 — SettlementEngine 支援 commission_engine 參數，動態費率
   - api/routes/admin.py 新增 GET /admin/providers/{id}/commission
   - api/main.py 初始化 CommissionEngine + 注入 settlement + app.state
   - 25 新測試全過（649 total）

7. ✅ api/routes/provider.py — Provider 自助上架 API（7 端點）
   - GET /provider/dashboard — 服務數/呼叫數/營收/結算總覽
   - GET /provider/services — 列出自己的服務含使用統計
   - GET /provider/services/{id}/analytics — 單服務詳細分析（每日、成功率、買家數）
   - GET /provider/earnings — 收入摘要 + 結算記錄
   - GET /provider/keys — 列出/管理 API 金鑰
   - DELETE /provider/keys/{id} — 撤銷金鑰
   - POST /provider/services/{id}/test — 測試端點連線
   - GET /provider/onboarding — 上架進度追蹤（5 步驟）
   - 19 新測試全過（668 total）

8. ✅ admin analytics 3 新端點
   - GET /admin/analytics/trends — 每日/每週/每月趨勢（營收/呼叫/買家/成功率）
   - GET /admin/analytics/top-services — Top 服務排名（營收/呼叫/延遲）
   - GET /admin/analytics/buyers — 買家指標（活躍/回頭客/Top 消費者）
   - 14 新測試全過（682 total）

9. ✅ SDK Provider 自助方法（sdk/client.py）
   - provider_dashboard() / provider_services() / service_analytics()
   - provider_earnings() / provider_keys() / revoke_provider_key()
   - test_service() / provider_onboarding()
   - 9 新測試全過（691 total）

10. ✅ docs/PRODUCT_SPEC.md — 英文版產品規格書（公開版，去除內部路徑）
11. 🔄 docs/zh-TW/PRODUCT_SPEC.md — 繁中翻譯（莉莉進行中）
12. 🔄 供應商招募（米米調研完成，18 家候選，Tier 1: Bitquery/Covalent/Flipside/Cloudmersive/Deepgram）

13. ✅ x402 支付整合（2026-03-21）
    - x402 wallet 已建立（Base Sepolia testnet, address: 0x634378...aEF2）
    - x402 middleware 與 proxy 雙向整合完成（request.state.payment_payload 偵測）
    - x402 已付時跳過餘額扣除，記錄 tx hash
    - middleware 初始化移至 module level（修復 Starlette crash）
    - 739 測試全部通過

14. ✅ x402 生產準備
    - acf_service_health_cron.py 已部署（每小時 cron，5/6 services reachable）
    - platform_consumer.py 已部署（3x/day cron，平台主動消費）

16. ✅ Security Audit（2026-03-21）— 5 CRITICAL + 1 HIGH + 3 MEDIUM + 1 LOW 修復
    - CRIT-01: POST /deposits 加入 auth + owner_id 檢查
    - CRIT-02: x402 payment 需有效 tx hash (len≥10)，否則 fallback 到餘額扣除
    - CRIT-03: Admin credit 改用 hmac.compare_digest + amount 驗證 (0 < amount ≤ 10000)
    - CRIT-04: buyer→provider 權限提升封堵（role check 加固）
    - CRIT-05: Dashboard 改用 session cookie 認證（API key 不再出現在 URL）
    - HIGH-05: Unsubscribe 端點加入 HMAC token 驗證
    - MED: 服務價格驗證 + buyer_id 隱私 + admin subscribers timing-safe
    - LOW-05: Webhook SSRF 檢查所有 DNS 結果
    - IPN rate limiting: 30 req/min/IP 跨 NowPayments/Stripe/Dodo
    - 775 tests ALL PASSED

15. ✅ Milestone Tracker（2026-03-21）
    - marketplace/milestones.py — $50/$200/$500 三階段里程碑
    - Active Seller ($50) → badge, Growth Partner ($200) → 8% commission, Power Seller ($500) → $25 cashback
    - Commission engine 整合 — tier_upgrade milestone 自動降佣
    - Provider API: GET /provider/milestones（自動頒發+顯示進度）
    - Admin API: GET /admin/providers/{id}/milestones
    - 19 tests pass（758 total）
    - 生產切換到 Base mainnet (eip155:8453)
    - CDP wallet 設定（settlement USDC 轉帳）
    - Resend domain verification（等 Judy DNS 設定）

### Provider Growth Program v4（Judy 2026-03-22 核准）

**品質等級制（取代累計銷售額降佣）**：
| 等級 | 佣金 | 條件 |
|------|------|------|
| 🟢 Standard | **10%** | 預設，上架就是 |
| ⭐ Verified Agent | **8%** | API 穩定 ≥99% + 回應 <2s + 連續 30 天在線 |
| 👑 Premium Agent | **6%** | 穩定 ≥99.5% + 回應 <500ms + 連續 90 天在線 + 評分 ≥4.5 |

**新手免費期**：前 3 個月 0%（不分等級）

**Buyer 端優惠**：
- 新註冊：$5 免費額度
- 首次充值：25% bonus（充 $20 得 $25）

**推薦制度（持續分潤）**：
- 推薦開店：推薦人永久拿平台收入的 20%（平台抽 10%→推薦人拿 2%，平台留 8%）
- 推薦買 Builder：推薦人拿 $30（15%），朋友享 $20 折扣
- 防作弊：被推薦人需上架服務 + 通過健康檢查 + 首筆 $10+ 收入才啟動
- Founding Seller：前 50 名永久徽章 + 佣金上限 8%

**實作需求**：
- `marketplace/commission.py` — 品質等級計算引擎（根據 health_monitor 數據自動判定）
- `marketplace/referral.py` — 推薦碼生成 + 追蹤 + 分潤計算
- `api/routes/admin.py` — 品質等級管理 + 推薦追蹤 API
- `settlement.py` 擴展 — 支援品質等級動態佣金 + 推薦分潤自動扣除
- Dashboard 新增 Provider Growth 儀表板（品質等級/推薦追蹤/分潤報表）
- 預估成本：最差情況平台淨賺 3.8%（Premium + 有推薦人），穩定正利潤

---

## 驗證計劃

1. **單元測試**: `pytest tests/ -v` — 目標 160+ pass, 80%+ coverage
2. **整合測試**: Full flow — register agent → register service → discover → proxy call → check reputation → settle
3. **手動驗證**:
   - `uvicorn api.main:app --port 8000` 啟動
   - `curl /api/v1/agents` 建立 Agent Identity
   - `curl /api/v1/teams` 建立團隊 + 路由規則
   - `curl /api/v1/proxy/{service_id}/scan` 呼叫服務
   - `curl /api/v1/agents/{id}/reputation` 查看聲譽
4. **Docker**: `docker compose up --build` 一鍵啟動驗證
5. **安全**: security-reviewer agent 掃描
6. **QA**: 小月 QA >= 8.5

---

## Phase 5: Retention v2 + Builder Launch (2026-03-21 新增)

> **背景：** v1 留存策略建立在「有買家流量」假設上，但市場太早期，賣家達不到銷售里程碑，返現和降佣形同虛設。v2 從零重新設計，核心邏輯：**即使還沒賣出去，平台就有價值。**

### 5.1 留存系統 v2 — 三支柱設計

**v1→v2→v4 核心轉變：**
- v1：賣越多 → 獎勵越多 → 留下來（沒銷售 = 整個系統失效）
- v2：工具價值 + 信譽累積 + 先行者紅利 → 不依賴銷售額留人
- v4：品質決定佣金 + 推薦持續分潤 → 自己能控制的指標決定費率（Judy 2026-03-22 核准）

#### 支柱 1: 工具價值（Builder 持續進化）
| 機制 | 說明 | 成本 |
|------|------|------|
| 終身免費更新 | 買 Builder 永久收到新模板、新支付整合、新功能 | $0 |
| 月度模板投放 | 每月新增 1 個產業模板（金融/醫療/電商/社群） | $0 |
| 早鳥專屬模板 | 前 100 名 Builder 購買者獲得 3 個獨家高級模板 | $0 |
| Builder Owners 社群 | TG/Discord 私人頻道，直接跟開發團隊對話 | $0 |

#### 支柱 2: 服務品質養成
| 機制 | 說明 |
|------|------|
| 免費健康檢查 | 平台自動測試 API（回應時間/錯誤率/可用性），每週報告 |
| 品質分數累積 | 即使沒有交易，可用性也在累積信譽分數（離開就歸零） |
| AI 審核回饋 | 上架前 AI 審核 API 設計，給具體改善建議 |
| 效能排名（內部） | 遊戲化，不公開但自己看得到 |

#### 支柱 3: 先行者紅利
| 機制 | 說明 |
|------|------|
| 上架序號 | 公開顯示「#007 — 第 7 個上架的服務」 |
| Founding Seller 徽章 | 前 50 名永久徽章 + 佣金 cap 8%（vs 標準 10%） |
| 類目佔位 | 先上架佔類目首位，後來者靠銷量才能超越 |
| 免費首頁曝光 | 建設期所有服務輪流上首頁 |

#### 平台主動消費（v2 關鍵創新）
- 平台 Agent 定期調用上架服務，產生真實使用數據
- 前 20 個服務每月至少 100 次調用
- 賣家看到「本月 API 被調用 127 次」→ 有動力維護
- 估計成本：$0（只用免費 tier）~ $1,500/月（50 免費+50 付費）

### 5.2 留存三階段時程

**第一階段：建設期（Month 0-6）**
- 健康檢查 + 品質分數累積 → 離開就歸零的沉沒成本
- 平台 Agent 消費 → 即使沒真實買家也有使用數據
- Builder 月度更新 + 社群 → 持續有價值
- Founding Seller 徽章 + 類目佔位 → 先行者優勢

**第二階段：萌芽期（Month 6-12）**
- 首筆真實交易慶祝 + 零抽成首筆
- 交叉推廣引擎（服務間互相導流）
- 品質等級自動判定生效：Verified 8% / Premium 6%（取代累計銷售額降佣）

**第三階段：成長期（Month 12+）**
- 網路效應啟動
- 品質等級制穩定運作（Standard 10% / Verified 8% / Premium 6%）
- 推薦飛輪：推薦人持續拿平台收入 20%，主動拉新賣家
- Founding Seller（前 50 名）永久徽章 + 佣金上限 8%

### 5.3 留存 v2 實作清單

| # | 項目 | 優先序 | 負責 | 時程 | 狀態 |
|---|------|--------|------|------|------|
| 1 | Founding Seller 徽章 + 上架序號 + 佣金 cap 8% | P0 | J | Day 1 | ✅ Done（MIM-358, 10 tests） |
| 2 | Builder 終身更新承諾（行銷文案） | P0 | 米米 | Day 1 | ⬜ |
| 3 | Builder Owners 社群（TG/Discord） | P0 | J | Week 1 | ⬜ |
| 4 | `marketplace/health_monitor.py` 健康檢查系統 | P1 | J | Week 2-4 | ✅ Done（309 行，自動 DB） |
| 5 | 信譽分數儀表板（賣家可見） | P1 | 阿達 | Week 2-4 | ⬜ |
| 6 | 簡化版里程碑追蹤（$50/$200/$500） | P2 | J | Week 4-8 | ✅ Done（19 tests） |
| 7 | 平台 Agent 測試消費系統 | P2 | J | Week 4-8 | ✅ Done（9 tests + cron 3x/day） |
| 8 | 交叉推廣引擎 | P3 | J | Week 8-12 | ⬜ |
| 9 | 月度 Builder 模板投放 | P3 | J/莉莉 | 持續 | ⬜ |

### 5.4 Builder Launch 計劃

#### 本週必做（上線 blockers）

| # | 行動 | 負責 | 前置 | 狀態 |
|---|------|------|------|------|
| 1 | Builder 發布到 PyPI（`pip install mcp-commerce`） | J | — | ✅ Build 成功（1.0.0），等 Judy PyPI 帳號+Token |
| 2 | x402 錢包設定 + Base Sepolia 測試 | J | 需建 Base 錢包 | ✅ Done（wallet+middleware+proxy 整合，739 tests pass） |
| 3 | Founding Seller 徽章系統 | J | — | ✅ Done |
| 4 | systemd 服務整理（port 衝突修復） | 阿達 | — | 🔄 MIM-357 |
| 5 | Blog 3 篇發布 | **Judy** | Gate-4 審核 | ⏳ 等 Judy |
| 6 | Resend 新 API Key 分享 | **Judy** | — | ⏳ 等 Judy |

#### 下週做

| # | 行動 | 負責 | 狀態 |
|---|------|------|------|
| 7 | API 健康檢查上線 + 品質分數 | J | ⬜ |
| 8 | 信譽分數 MVP 儀表板 | 阿達 | ⬜ |
| 9 | Builder Owners 社群建立 | J | ⬜ |
| 10 | IR Deck / PRODUCT_SPEC 三語同步 | 莉莉 | 🔄 |
| 11 | X Thread 更新 + 發布準備 | 米米 | ⬜ |

#### 上線後持續

| # | 行動 | 負責 | 時程 |
|---|------|------|------|
| 12 | Product Hunt Launch | J+米米 | Q2 2026 |
| 13 | SDK 發布 PyPI | J | 上線後 1 天 |
| 14 | AgentKit/CDP 整合（Agent 自動錢包） | J | 3-5 天 |
| 15 | 每月 Builder 新模板 | J/莉莉 | 持續 |
| 16 | 里程碑獎勵系統 | J | Month 2 |
| 17 | 平台 Agent 測試消費 | J | Month 2 |
| 18 | 內容行銷（Blog 每週 1-2 篇） | 米米+J | 持續 |

### 5.5 營收雙引擎

| 引擎 | 定位 | 目標 |
|------|------|------|
| Builder $199 銷售 | 近期可控營收 | 2026 目標：$2K-16K |
| 平台 10% 抽成 | 長期成長（市場成熟後） | 2026 目標：$0-12K |
| CoinSifter API | 自有產品營收 | 2026 目標：$600-6K |
| **合計** | | **2026: $2.8K-34K** |

損益平衡：每月賣 8 套 Builder = 覆蓋全部留存計畫成本

### 5.6 文件同步清單

| # | 文件 | 更新內容 | 負責 | 狀態 |
|---|------|----------|------|------|
| 1 | IR_DECK.md | 雙引擎營收 + 修正預測 | J | ✅ Done |
| 2 | IR_DECK_zh-TW.md | 同步 EN 版更新 | 莉莉 | ⬜ |
| 3 | PRODUCT_SPEC.md | Builder 營收 + 留存 | J | ✅ Done |
| 4 | PRODUCT_SPEC zh-TW | 同步 EN 版 | 莉莉 | 🔄 |
| 5 | PRODUCT_SPEC ko | 同步 EN 版 | 莉莉 | ⬜ |
| 6 | MARKETING_PLAN.md | v2.0 | J | ✅ Done |
| 7 | X threads | 加入 Builder 角度 | 米米 | ⬜ |
| 8 | 留存策略 v2 | agentictrade_retention_v2.md | J | ✅ Done |
