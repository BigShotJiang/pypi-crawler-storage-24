# Security Audit: Rate Limiting & Input Validation
**Project:** Agent Commerce Framework
**Date:** 2026-03-19
**Auditor:** Security Reviewer Agent
**Scope:** `marketplace/rate_limit.py`, `api/main.py`, `api/routes/*.py`, `marketplace/proxy.py`, `marketplace/webhooks.py`, `marketplace/registry.py`, `marketplace/auth.py`

---

## Executive Summary

| Category | Status | Critical | High | Medium | Low |
|---|---|---|---|---|---|
| Rate Limiting | PARTIAL | 0 | 2 | 2 | 1 |
| Input Validation | PARTIAL | 0 | 3 | 4 | 2 |
| **Total** | **NEEDS WORK** | **0** | **5** | **6** | **3** |

No CRITICAL vulnerabilities found. Five HIGH severity issues require remediation before production deployment.

---

## Part 1: Rate Limiting Audit

### 1.1 Architecture Overview

The system has **two distinct rate limiting layers**:

1. **Global IP-based middleware** — `api/main.py` line 168-177
   Applies to all requests. Token bucket, 60 req/min rate, 120 burst, keyed by client IP.

2. **Per-API-key rate limiter** — `marketplace/auth.py` `check_rate_limit()`
   Sliding window (60-second), keyed by `key_id`. Only applied on the `/proxy/*` and `/usage/me` endpoints via `proxy.py`'s `_get_auth()`.

### 1.2 Rate Limiting Coverage Per Endpoint

| Endpoint | Method | Global IP Limit | Per-Key Limit | Auth Required |
|---|---|---|---|---|
| `GET /` | health.py | YES | NO | NO |
| `GET /health` | health.py | YES | NO | NO |
| `POST /api/v1/services` | services.py | YES | NO | YES (provider) |
| `GET /api/v1/services` | services.py | YES | NO | NO |
| `GET /api/v1/services/{id}` | services.py | YES | NO | NO |
| `PATCH /api/v1/services/{id}` | services.py | YES | NO | YES (provider) |
| `DELETE /api/v1/services/{id}` | services.py | YES | NO | YES (provider) |
| `POST /api/v1/keys` | auth.py | YES | NO | PARTIAL (buyer=no auth) |
| `POST /api/v1/keys/validate` | auth.py | YES | NO | NO |
| `ANY /api/v1/proxy/{id}/{path}` | proxy.py | YES | YES | YES |
| `GET /api/v1/usage/me` | proxy.py | YES | YES | YES |
| `GET /api/v1/discover` | discovery.py | YES | NO | NO |
| `GET /api/v1/discover/categories` | discovery.py | YES | NO | NO |
| `GET /api/v1/discover/trending` | discovery.py | YES | NO | NO |
| `GET /api/v1/discover/recommendations/{agent_id}` | discovery.py | YES | NO | NO |
| `GET /api/v1/agents/{id}/reputation` | reputation.py | YES | NO | NO |
| `GET /api/v1/services/{id}/reputation` | reputation.py | YES | NO | NO |
| `GET /api/v1/reputation/leaderboard` | reputation.py | YES | NO | NO |
| `POST /api/v1/agents` | identity.py | YES | NO | YES |
| `GET /api/v1/agents` | identity.py | YES | NO | NO |
| `GET /api/v1/agents/search` | identity.py | YES | NO | NO |
| `GET /api/v1/agents/{id}` | identity.py | YES | NO | NO |
| `PATCH /api/v1/agents/{id}` | identity.py | YES | NO | YES |
| `DELETE /api/v1/agents/{id}` | identity.py | YES | NO | YES |
| `POST /api/v1/agents/{id}/verify` | identity.py | YES | NO | YES (admin) |
| `POST /api/v1/teams` | teams.py | YES | NO | YES |
| `GET /api/v1/teams` | teams.py | YES | NO | PARTIAL (graceful) |
| `GET /api/v1/teams/{id}` | teams.py | YES | NO | NO |
| `PATCH /api/v1/teams/{id}` | teams.py | YES | NO | YES |
| `DELETE /api/v1/teams/{id}` | teams.py | YES | NO | YES |
| `POST /api/v1/teams/{id}/members` | teams.py | YES | NO | YES |
| `GET /api/v1/teams/{id}/members` | teams.py | YES | NO | NO |
| `DELETE /api/v1/teams/{id}/members/{agent_id}` | teams.py | YES | NO | YES |
| `POST /api/v1/teams/{id}/rules` | teams.py | YES | NO | YES |
| `GET /api/v1/teams/{id}/rules` | teams.py | YES | NO | NO |
| `DELETE /api/v1/teams/{id}/rules/{rule_id}` | teams.py | YES | NO | YES |
| `POST /api/v1/teams/{id}/gates` | teams.py | YES | NO | YES |
| `GET /api/v1/teams/{id}/gates` | teams.py | YES | NO | NO |
| `DELETE /api/v1/teams/{id}/gates/{gate_id}` | teams.py | YES | NO | YES |
| `GET /api/v1/templates/teams` | teams.py | YES | NO | NO |
| `GET /api/v1/templates/services` | teams.py | YES | NO | NO |
| `POST /api/v1/webhooks` | webhooks.py | YES | NO | YES |
| `GET /api/v1/webhooks` | webhooks.py | YES | NO | YES |
| `DELETE /api/v1/webhooks/{id}` | webhooks.py | YES | NO | YES |
| `POST /api/v1/settlements` | settlement.py | YES | NO | YES (admin) |
| `GET /api/v1/settlements` | settlement.py | YES | NO | YES |
| `PATCH /api/v1/settlements/{id}/pay` | settlement.py | YES | NO | YES (admin) |
| `GET /api/v1/admin/stats` | admin.py | YES | NO | YES (admin) |
| `GET /api/v1/admin/usage/daily` | admin.py | YES | NO | YES (admin) |
| `GET /api/v1/admin/providers/ranking` | admin.py | YES | NO | YES (admin) |
| `GET /api/v1/admin/services/health` | admin.py | YES | NO | YES (admin) |
| `GET /api/v1/admin/payments/summary` | admin.py | YES | NO | YES (admin) |
| `GET /dashboard/` | dashboard.py | YES | NO | YES (admin via query) |
| `GET /dashboard/services` | dashboard.py | YES | NO | YES (admin via query) |
| `GET /dashboard/agents` | dashboard.py | YES | NO | YES (admin via query) |
| `GET /dashboard/transactions` | dashboard.py | YES | NO | YES (admin via query) |
| `GET /dashboard/quality` | dashboard.py | YES | NO | YES (admin via query) |
| `GET /admin/dashboard` | dashboard.py | YES | NO | YES (admin via query) |

### 1.3 Rate Limiting Findings

---

#### RL-001 [HIGH] — IP Spoofing via X-Forwarded-For Header

**File:** `api/main.py` lines 169-177
**Severity:** HIGH

The global IP-based rate limiter reads the client IP from `request.client.host`, which is the raw TCP connection IP. This is correct behavior for a direct server. However, if the app is deployed behind a reverse proxy (nginx, AWS ALB, Cloudflare) without `X-Forwarded-For` trust configuration, the rate limiter will key on the proxy's internal IP, making the global limit effectively shared across all clients.

Conversely, if Uvicorn is configured with `--proxy-headers` (common in containerized deployments), the rate limiter will then trust `X-Forwarded-For`, which can be spoofed by clients to bypass rate limiting.

```python
# api/main.py line 171 — current
client_ip = request.client.host if request.client else "unknown"
```

**Risk:** A malicious client behind a proxy can rotate `X-Forwarded-For` values to bypass the 60 req/min limit entirely.

**Fix:** Use Starlette's `ProxyHeadersMiddleware` with a trusted proxy list, and document the deployment requirements clearly.

```python
# Recommended: add to app setup if deployed behind trusted proxy
from starlette.middleware.trustedhost import TrustedHostMiddleware
# OR configure uvicorn with --forwarded-allow-ips only for known proxies
```

---

#### RL-002 [HIGH] — No Rate Limiting on Key Creation Endpoint (Account Enumeration/DoS)

**File:** `api/routes/auth.py` lines 31-82
**Severity:** HIGH

The `POST /api/v1/keys` endpoint has only the global IP rate limit (60/min). Buyer keys require no authentication. An attacker can create unlimited buyer-role keys from a single IP at 60/min, which enables:
- API key database bloat (DoS on storage)
- Enumeration of owner_id values accepted by the system
- Creation of keys for arbitrary `owner_id` strings they do not own

The `owner_id` field is accepted directly from the request body with no validation that the caller controls that owner ID.

```python
# auth.py lines 16-20 — no owner verification for buyer role
class CreateKeyRequest(BaseModel):
    owner_id: str   # Caller can set ANY owner_id string
    role: str = "buyer"
    rate_limit: int = 60
```

**Fix:**
1. Apply a tighter, separate rate limit on key creation (e.g., 5/min per IP).
2. Validate that the `rate_limit` field is capped at a reasonable maximum (currently it is stored directly from user input without bounds checking).

---

#### RL-003 [MEDIUM] — No Rate Limit Headers Returned

**File:** `api/main.py` lines 172-177
**Severity:** MEDIUM

The 429 response from the global rate limiter does not include `X-RateLimit-Limit`, `X-RateLimit-Remaining`, or `Retry-After` headers. This violates RFC 6585 and makes it impossible for clients to implement compliant backoff strategies.

```python
# Current 429 response — no headers
return JSONResponse(
    status_code=429,
    content={"detail": "Rate limit exceeded. Try again later."},
)
```

**Fix:**

```python
return JSONResponse(
    status_code=429,
    content={"detail": "Rate limit exceeded. Try again later."},
    headers={
        "Retry-After": "60",
        "X-RateLimit-Limit": str(rate_limiter.rate),
        "X-RateLimit-Window": str(int(rate_limiter.per)),
    },
)
```

---

#### RL-004 [MEDIUM] — In-Memory Rate Limiter State Not Shared Across Workers

**File:** `marketplace/rate_limit.py` and `marketplace/auth.py`
**Severity:** MEDIUM

Both rate limiters use in-memory state (`_buckets` dict and `_rate_windows` dict). If the application runs with multiple Uvicorn workers (`--workers N`) or across multiple container instances, each worker maintains independent state. A client can bypass rate limits by making requests that round-robin across workers.

**Fix:** For multi-worker deployments, replace in-memory stores with Redis-backed rate limiting (e.g., `redis-py` with sliding window scripts).

---

#### RL-005 [LOW] — Burst Limit Set to 2x Rate Limit

**File:** `api/main.py` line 125
**Severity:** LOW

```python
rate_limiter = RateLimiter(rate=60, per=60.0, burst=120)
```

The burst is set to 120 requests while the sustained rate is 60/min. This allows a client to make 120 requests instantly before being limited. For a marketplace with payment handling, this burst may allow a client to overwhelm provider services before billing kicks in.

**Recommendation:** Reduce burst to match rate (60) or align burst policy with business requirements.

---

#### RL-006 [LOW] — Missing Cleanup Cron for In-Memory Rate Limiter

**File:** `marketplace/rate_limit.py` lines 51-60
**Severity:** LOW

The `RateLimiter` has a `cleanup()` method but it is never called. The `_buckets` dict grows unbounded in long-running servers serving many unique IPs. Over days or weeks this causes memory creep.

**Fix:** Call `rate_limiter.cleanup()` periodically, e.g., via a background task at startup:

```python
@app.on_event("startup")
async def start_cleanup_task():
    async def cleanup_loop():
        while True:
            await asyncio.sleep(3600)
            removed = rate_limiter.cleanup(max_age=3600)
            logger.info("Rate limiter cleanup: removed %d stale buckets", removed)
    asyncio.create_task(cleanup_loop())
```

---

### 1.4 Rate Limiting Test Coverage Assessment

**File:** `tests/test_rate_limit.py`

The test file covers the `RateLimiter` class unit behavior well:
- Allows within limit (pass)
- Blocks over limit (pass)
- Separate clients isolated (pass)
- Burst behavior (pass)
- Token refill over time (pass)
- Cleanup of stale buckets (pass)

**Gaps:**
- No tests for the HTTP middleware behavior (integration test)
- No tests for the per-API-key rate limiter in `auth.py`
- No tests for rate limit bypass via header manipulation
- No tests for the 429 response format

---

## Part 2: Input Validation Audit

### 2.1 Per-Endpoint Validation Matrix

| Endpoint | Body Validation | Path Param Validation | Query Param Validation | Issues |
|---|---|---|---|---|
| `POST /api/v1/services` | YES (Pydantic + endpoint validator) | N/A | N/A | See IV-001, IV-002 |
| `GET /api/v1/services` | N/A | N/A | PARTIAL | See IV-003 |
| `GET /api/v1/services/{id}` | N/A | NO | N/A | See IV-004 |
| `PATCH /api/v1/services/{id}` | YES (Pydantic, partial) | NO | N/A | See IV-001, IV-004 |
| `DELETE /api/v1/services/{id}` | N/A | NO | N/A | See IV-004 |
| `POST /api/v1/keys` | YES (Pydantic) | N/A | N/A | See IV-005, IV-006 |
| `POST /api/v1/keys/validate` | YES (Pydantic) | N/A | N/A | OK |
| `ANY /api/v1/proxy/{id}/{path}` | N/A (raw bytes forwarded) | NO | N/A | See IV-007 |
| `GET /api/v1/discover` | N/A | N/A | PARTIAL | See IV-008 |
| `GET /api/v1/discover/trending` | N/A | N/A | PARTIAL | See IV-009 |
| `GET /api/v1/discover/recommendations/{id}` | N/A | NO | PARTIAL | See IV-004, IV-009 |
| `GET /api/v1/agents/{id}/reputation` | N/A | NO | YES (period validated) | See IV-004 |
| `GET /api/v1/services/{id}/reputation` | N/A | NO | YES (period validated) | See IV-004 |
| `GET /api/v1/reputation/leaderboard` | N/A | N/A | YES (clamped) | OK |
| `POST /api/v1/agents` | YES (Pydantic) | N/A | N/A | See IV-010 |
| `GET /api/v1/agents` | N/A | N/A | PARTIAL | OK |
| `GET /api/v1/agents/search` | N/A | N/A | PARTIAL | See IV-009 |
| `GET /api/v1/agents/{id}` | N/A | NO | N/A | See IV-004 |
| `PATCH /api/v1/agents/{id}` | YES (Pydantic, partial) | NO | N/A | See IV-004, IV-010 |
| `DELETE /api/v1/agents/{id}` | N/A | NO | N/A | See IV-004 |
| `POST /api/v1/agents/{id}/verify` | N/A | NO | N/A | See IV-004 |
| `POST /api/v1/teams` | YES (Pydantic + manual checks) | N/A | N/A | See IV-011 |
| `GET /api/v1/teams` | N/A | N/A | PARTIAL | OK |
| `GET /api/v1/teams/{id}` | N/A | NO | N/A | See IV-004 |
| `POST /api/v1/teams/{id}/members` | YES (Pydantic + role check) | NO | N/A | See IV-004 |
| `POST /api/v1/teams/{id}/rules` | YES (Pydantic) | NO | N/A | See IV-004, IV-012 |
| `POST /api/v1/teams/{id}/gates` | YES (Pydantic + manual checks) | NO | N/A | See IV-004 |
| `POST /api/v1/webhooks` | YES (Pydantic, url validated in service) | N/A | N/A | See IV-013 |
| `DELETE /api/v1/webhooks/{id}` | N/A | NO | N/A | See IV-004 |
| `POST /api/v1/settlements` | YES (Pydantic) | N/A | N/A | See IV-014 |
| `GET /api/v1/settlements` | N/A | N/A | PARTIAL | OK |
| `PATCH /api/v1/settlements/{id}/pay` | YES (Pydantic) | NO | N/A | See IV-004, IV-015 |
| `GET /api/v1/admin/usage/daily` | N/A | N/A | YES (Query ge/le) | OK |
| `GET /api/v1/admin/providers/ranking` | N/A | N/A | PARTIAL | See IV-016 |
| `GET /dashboard/transactions` | N/A | N/A | PARTIAL | See IV-017 |

---

### 2.2 Input Validation Findings

---

#### IV-001 [HIGH] — No Length Limits on Free-Form String Fields in Service Registration

**File:** `api/routes/services.py` lines 18-27 and `marketplace/registry.py`
**Severity:** HIGH

The `RegisterServiceRequest` and `UpdateServiceRequest` Pydantic models accept unlimited-length strings for `name`, `description`, `category`, and `tags`. No `max_length` constraints are defined. A malicious provider could submit:
- `name` or `description` with megabytes of data, causing DB write amplification
- Thousands of tags entries in the `tags` list
- Extremely long category strings

```python
# services.py — no length limits
class RegisterServiceRequest(BaseModel):
    name: str                 # No max_length
    description: str = ""    # No max_length
    endpoint: str
    price_per_call: str
    category: str = ""       # No max_length
    tags: list[str] = []     # No max items, no item max_length
```

**Fix:**

```python
from pydantic import Field

class RegisterServiceRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: str = Field("", max_length=2000)
    endpoint: str = Field(..., max_length=500)
    price_per_call: str = Field(..., max_length=20)
    category: str = Field("", max_length=100)
    tags: list[str] = Field([], max_length=20)  # max 20 tags
```

Apply the same to `UpdateServiceRequest`, `RegisterAgentRequest`, `UpdateAgentRequest`, `CreateTeamRequest`.

---

#### IV-002 [HIGH] — No Maximum Request Body Size Configured

**File:** `api/main.py`
**Severity:** HIGH

FastAPI/Starlette has no default maximum request body size. There is no `ContentSizeLimitMiddleware` or equivalent. A client can POST an arbitrarily large body to any endpoint that reads the request body (`/proxy/*`, `/services`, etc.), causing:
- Memory exhaustion (OOM) on the server
- Slowloris-style resource exhaustion

The proxy endpoint (`proxy.py` line 87) reads the entire body into memory:
```python
body = await request.body()  # No size limit
```

**Fix:** Add `ContentSizeLimitMiddleware` or configure at the reverse proxy level:

```python
# Option A: Middleware (requires starlette-content-size-limit or custom)
from starlette.middleware.base import BaseHTTPMiddleware

class MaxBodySizeMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, max_bytes: int = 10 * 1024 * 1024):  # 10 MB
        super().__init__(app)
        self.max_bytes = max_bytes

    async def dispatch(self, request, call_next):
        if request.headers.get("content-length"):
            if int(request.headers["content-length"]) > self.max_bytes:
                return JSONResponse(
                    status_code=413,
                    content={"detail": "Request body too large"},
                )
        return await call_next(request)

app.add_middleware(MaxBodySizeMiddleware, max_bytes=10_000_000)
```

---

#### IV-003 [MEDIUM] — No Bounds on Query Parameters in Public List Endpoints

**File:** `api/routes/services.py` lines 72-95
**Severity:** MEDIUM

The `GET /api/v1/services` endpoint accepts `limit` and `offset` from query strings without validation at the route level:

```python
# services.py lines 73-80
async def list_services(
    request: Request,
    query: Optional[str] = None,
    category: Optional[str] = None,
    status: str = "active",
    limit: int = 50,    # No ge/le constraint
    offset: int = 0,    # No ge/le constraint
):
```

The underlying `registry.search()` clamps limit at 100, but a caller can still request `limit=99999`, forcing the clamping logic to run and masking the fact that offset can be arbitrarily large (negative offsets are handled by `max(offset, 0)`). The `query` and `category` strings have no length limits. The `status` field accepts any string value with no validation against an allowed set.

**Fix:**

```python
from fastapi import Query

async def list_services(
    request: Request,
    query: Optional[str] = Query(None, max_length=200),
    category: Optional[str] = Query(None, max_length=100),
    status: str = Query("active", pattern="^(active|paused|all)$"),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
```

Same pattern applies to `GET /api/v1/discover`, `GET /api/v1/agents`, `GET /api/v1/agents/search`.

---

#### IV-004 [MEDIUM] — Path Parameters Accepted as Raw Strings (No Format Validation)

**File:** All route files using `{service_id}`, `{agent_id}`, `{team_id}`, `{webhook_id}`, `{rule_id}`, `{gate_id}`, `{settlement_id}`
**Severity:** MEDIUM

All path parameters that represent database UUIDs are declared as `str` with no format validation. A caller can pass values like:
- `../../etc/passwd` (path traversal attempt)
- SQL fragment characters (though parameterized queries prevent injection, the value is still passed to DB queries and logged)
- Extremely long strings consuming memory

```python
# Repeated pattern across many routes
async def get_service(service_id: str, request: Request):  # Any string accepted
```

**Fix:** Use a UUID validator in the path:

```python
import uuid
from fastapi import Path

async def get_service(
    service_id: str = Path(..., pattern=r"^[0-9a-f-]{36}$"),
    request: Request = None,
):
```

Or use FastAPI's `uuid.UUID` type annotation (auto-validated):

```python
from uuid import UUID

async def get_service(service_id: UUID, request: Request):
    service_id_str = str(service_id)  # Convert to string for DB
```

---

#### IV-005 [MEDIUM] — `rate_limit` Field Accepted from Untrusted Input with No Upper Bound

**File:** `api/routes/auth.py` lines 16-20
**Severity:** MEDIUM

The `CreateKeyRequest` model accepts a `rate_limit` field directly from the user with no maximum bound:

```python
class CreateKeyRequest(BaseModel):
    owner_id: str
    role: str = "buyer"
    rate_limit: int = 60    # User can set rate_limit=999999
```

This value is stored in the database and then used in `proxy.py`'s `_get_auth()` to call `key_mgr.check_rate_limit(key_id, limit)`. A buyer creating their own key could set `rate_limit=999999` to effectively disable per-key rate limiting for themselves.

**Fix:**

```python
class CreateKeyRequest(BaseModel):
    owner_id: str = Field(..., min_length=1, max_length=200)
    role: str = Field("buyer", pattern="^(buyer|provider|admin)$")
    rate_limit: int = Field(60, ge=1, le=1000)  # Cap at 1000
    wallet_address: Optional[str] = Field(None, max_length=100)
```

---

#### IV-006 [LOW] — `owner_id` in Key Creation Not Validated for Format or Ownership

**File:** `api/routes/auth.py` line 17
**Severity:** LOW

Buyer keys can be created with any `owner_id` string by an unauthenticated caller. This means any caller can claim to be any owner ID:

```python
# Unauthenticated buyer can set any owner_id
POST /api/v1/keys
{"owner_id": "admin_user_123", "role": "buyer"}
```

While this does not grant the caller admin privileges, it allows confusion in usage analytics (false buyer IDs), and resource attribution abuse.

**Recommendation:** For buyer key creation, either require authentication or generate the `owner_id` server-side rather than accepting it from the client.

---

#### IV-007 [HIGH] — Proxy Path Parameter Allows Path Traversal Sequences

**File:** `api/routes/proxy.py` lines 44-48, 96
**Severity:** HIGH

The proxy endpoint accepts an arbitrary `path` variable and concatenates it directly with the service endpoint URL:

```python
# proxy.py line 96
result = await proxy.forward_request(
    ...
    path=f"/{path}" if path else "",
    ...
)
```

In `proxy.py` (marketplace layer), the target URL is built as:
```python
# marketplace/proxy.py line 85
target_url = f"{endpoint}{path}" if path else endpoint
```

A caller could supply a path containing `../` sequences or query string injection such as:
- `service_id/../../different_path`
- `../../../admin` (if the endpoint has a path component)
- `resource?injected=param` (query string injection via path segment)

The SSRF protection correctly blocks private IPs at the DNS level but does not normalize or sanitize the path component before forwarding.

**Fix:** Normalize and validate the path before forwarding:

```python
import posixpath
from urllib.parse import quote, urlparse

def _sanitize_proxy_path(raw_path: str) -> str:
    """Normalize path to prevent traversal. Returns cleaned path."""
    # Normalize traversal sequences
    normalized = posixpath.normpath("/" + raw_path)
    # Re-encode any special characters, preserving path separators
    # Reject paths that still escape the root after normalization
    if not normalized.startswith("/"):
        raise ValueError("Invalid proxy path")
    return normalized
```

---

#### IV-008 [LOW] — Unvalidated `sort_by` Parameter in Discovery

**File:** `api/routes/discovery.py` lines 23-24
**Severity:** LOW

The `sort_by` query parameter is passed directly to `discovery.search()` with no whitelist validation at the route level:

```python
# discovery.py line 24
sort_by: str = "created_at",
```

If `discovery.search()` builds a SQL ORDER BY clause from this value without an explicit allowlist, this could be an ORDER BY injection vector. Even if the discovery engine validates it internally, the validation should be present at the route boundary too.

**Fix:**

```python
sort_by: str = Query("created_at", pattern="^(created_at|price|name)$"),
```

---

#### IV-009 [LOW] — Unbounded `limit` in Several Public Endpoints

**File:** `api/routes/discovery.py` line 79, `api/routes/identity.py` line 76
**Severity:** LOW

`GET /discover/trending` accepts `limit: int = 10` with no upper bound at the route. The discovery engine may or may not clamp this. Similarly `GET /agents/search` accepts `limit: int = 20` with only a client-visible clamp via `min/max`.

These are low-severity since the clamping is present at the handler level, but it should be enforced at the parameter declaration level for clarity and defense-in-depth.

---

#### IV-010 [MEDIUM] — No Validation on `metadata` and `capabilities` Free-Form Fields in Agent Registration

**File:** `api/routes/identity.py` lines 18-24
**Severity:** MEDIUM

The `RegisterAgentRequest` accepts:
- `metadata: dict = {}` — unbounded dict with no schema validation, no size limit
- `capabilities: list[str] = []` — unbounded list, no item count limit, no item length limit

```python
class RegisterAgentRequest(BaseModel):
    display_name: str          # No max_length
    identity_type: str = "api_key_only"   # No whitelist enforcement in model
    capabilities: list[str] = []          # Unbounded
    wallet_address: Optional[str] = None  # No format validation
    metadata: dict = {}                   # Unbounded, untyped
```

**Fix:**

```python
ALLOWED_IDENTITY_TYPES = {"api_key_only", "did", "vc"}

class RegisterAgentRequest(BaseModel):
    display_name: str = Field(..., min_length=1, max_length=200)
    identity_type: str = Field("api_key_only", pattern="^(api_key_only|did|vc)$")
    capabilities: list[str] = Field([], max_length=50)
    wallet_address: Optional[str] = Field(None, max_length=100, pattern=r"^0x[0-9a-fA-F]{40}$|^$")
    metadata: dict = Field(default_factory=dict)  # Add JSON size check in validator
```

---

#### IV-011 [LOW] — `config` Free-Form Dict in Team Creation Has No Schema

**File:** `api/routes/teams.py` lines 24-27
**Severity:** LOW

`CreateTeamRequest` and `UpdateTeamRequest` accept `config: dict = {}` with no size limit or key/value constraints. This dict is stored directly in the database.

---

#### IV-012 [MEDIUM] — Routing Rule `keywords` and `target_agent_id` Have No Validation

**File:** `api/routes/teams.py` lines 42-47
**Severity:** MEDIUM

`AddRoutingRuleRequest` has no constraints on `keywords` list size, individual keyword length, or `target_agent_id` format. The `priority` field has no min/max bounds.

```python
class AddRoutingRuleRequest(BaseModel):
    name: str                 # No max_length
    keywords: list[str]       # No max count, no item max_length
    target_agent_id: str      # Should be validated as UUID or agent ID format
    priority: int = 0         # No bounds
```

**Fix:**

```python
class AddRoutingRuleRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    keywords: list[str] = Field(..., min_length=1, max_length=50)
    target_agent_id: str = Field(..., pattern=r"^[0-9a-f-]{36}$")
    priority: int = Field(0, ge=0, le=1000)
```

---

#### IV-013 [MEDIUM] — Webhook URL SSRF: HTTPS-Only Check Insufficient, No Private IP Check at Registration

**File:** `marketplace/webhooks.py` lines 94-98
**Severity:** MEDIUM

The webhook `subscribe()` method validates that the URL starts with `https://`, which is good. However, it does **not** perform DNS resolution to check if the hostname resolves to a private/internal IP. This creates an SSRF vector:

```
# Attacker registers a webhook pointing to:
https://metadata.google.internal/computeMetadata/v1/
https://169.254.169.254/latest/meta-data/
# OR a custom domain that resolves to 10.0.0.1
```

When the webhook is dispatched, the `_deliver()` method makes an outbound `httpx.AsyncClient.post()` to the attacker's URL, potentially reaching internal services.

Note that the registry service endpoint validation (`registry.py` `_validate_endpoint`) blocks known metadata IPs and private ranges at registration time. The same protection is missing in the webhook manager.

**Fix:** Add the same DNS-resolution SSRF check used in `marketplace/proxy.py` to `webhooks.py`'s `subscribe()` method:

```python
import ipaddress
import socket
from urllib.parse import urlparse

def _validate_webhook_url(url: str) -> None:
    """Validate webhook URL: HTTPS only, no private IP destinations."""
    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise WebhookError("Webhook URL must use HTTPS")

    blocked_hostnames = {
        "localhost", "127.0.0.1", "0.0.0.0", "::1",
        "metadata.google.internal", "169.254.169.254",
    }
    hostname = parsed.hostname or ""
    if hostname in blocked_hostnames:
        raise WebhookError("Webhook URL cannot point to a private address")

    try:
        addrs = socket.getaddrinfo(hostname, None)
        for addr in addrs:
            ip = ipaddress.ip_address(addr[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                raise WebhookError("Webhook URL cannot point to a private address")
    except socket.gaierror:
        pass  # Let httpx handle DNS failure at delivery time
```

---

#### IV-014 [MEDIUM] — Settlement `period_start` / `period_end` Accept Arbitrary Strings

**File:** `api/routes/settlement.py` lines 17-20
**Severity:** MEDIUM

```python
class CreateSettlementRequest(BaseModel):
    provider_id: str
    period_start: str  # ISO 8601 — comment says so, model doesn't enforce it
    period_end: str
```

The `period_start` and `period_end` fields are passed to the settlement engine as raw strings. If the settlement engine uses these values in SQL queries (e.g., `WHERE timestamp BETWEEN period_start AND period_end`), malformed or crafted values could cause unexpected behavior. At minimum, they should be validated as ISO 8601 datetime strings.

**Fix:**

```python
from pydantic import field_validator
from datetime import datetime

class CreateSettlementRequest(BaseModel):
    provider_id: str = Field(..., min_length=1, max_length=200)
    period_start: str
    period_end: str

    @field_validator("period_start", "period_end")
    @classmethod
    def must_be_iso8601(cls, v: str) -> str:
        try:
            datetime.fromisoformat(v)
        except ValueError:
            raise ValueError("Must be ISO 8601 datetime string")
        return v
```

---

#### IV-015 [LOW] — `payment_tx` in MarkPaidRequest Has No Format Validation

**File:** `api/routes/settlement.py` lines 22-23
**Severity:** LOW

```python
class MarkPaidRequest(BaseModel):
    payment_tx: str  # No max_length, no format check
```

The `payment_tx` field is stored in the database as a transaction reference. It should have at least a maximum length constraint to prevent oversized strings being stored.

---

#### IV-016 [MEDIUM] — SQL Injection Risk in Admin Provider Ranking via `period` Parameter

**File:** `api/routes/admin.py` lines 118-124
**Severity:** MEDIUM

The `period` query parameter in `GET /api/v1/admin/providers/ranking` is partially validated but in an insecure way:

```python
# admin.py lines 118-124
if period != "all-time":
    period_filter = "WHERE DATE(u.timestamp) >= DATE('now', ? || ' days')"
    try:
        period_days = int(period)  # Attempts int conversion
    except ValueError:
        period_days = 30           # Falls back silently
    params.append(str(-period_days))
```

The string `period` itself is not validated. While the parameterized `?` binding prevents direct SQL injection in the filter clause, the `int(period)` conversion silently falls back to 30 on any non-numeric input, potentially misleading the admin. A period value like `"30; DROP TABLE"` would be caught by `int()` and fall back silently, but this behavior is confusing and masks invalid input.

More importantly, the `period` value is placed directly into the response JSON (`"period": period`) without sanitization. If this value were ever included in an HTML template context, it would be an XSS vector.

**Fix:** Validate the `period` parameter strictly:

```python
period: str = Query(
    "all-time",
    pattern=r"^(all-time|\d{1,5})$",
    description="'all-time' or number of days as integer string",
)
```

---

#### IV-017 [LOW] — Dashboard Transaction Filter Parameters Not Validated for Format

**File:** `api/routes/dashboard.py` lines 144-149
**Severity:** LOW

The `date_from` and `date_to` query parameters are accepted as bare strings with no format validation:

```python
date_from: str = Query("", description="Filter from date (YYYY-MM-DD)"),
date_to: str = Query("", description="Filter to date (YYYY-MM-DD)"),
```

These are passed to `query_transactions_filtered()` which uses them directly in SQL `DATE(timestamp) >= ?` clauses. Malformed values (not a date) would cause SQLite to return wrong results silently (SQLite's date functions return NULL for invalid date strings). This is a data integrity issue rather than an injection risk (the query is parameterized).

**Fix:**

```python
date_from: str = Query("", pattern=r"^(\d{4}-\d{2}-\d{2})?$"),
date_to: str = Query("", pattern=r"^(\d{4}-\d{2}-\d{2})?$"),
```

---

## Part 3: CORS Configuration

**File:** `api/main.py` lines 54-63
**Severity:** MEDIUM (conditional)

```python
_cors_raw = os.environ.get("CORS_ORIGINS", "*").split(",")
_cors_all = _cors_raw == ["*"] or _cors_raw == [""]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if _cors_all else _cors_raw,
    allow_credentials=not _cors_all,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

The default value of `CORS_ORIGINS` is `"*"` (wildcard). If this variable is not explicitly set in production, the API will serve CORS headers allowing any origin to make cross-origin requests. For a marketplace API handling payments and API keys, this is a significant exposure.

The code correctly disables `allow_credentials` when using wildcard origins (browsers block `*` + credentials), but `allow_methods=["*"]` and `allow_headers=["*"]` remain permissive in all cases.

**Recommendation:** Change the default to an empty/restricted set and require explicit configuration:

```python
_cors_raw = os.environ.get("CORS_ORIGINS", "").split(",")
_cors_origins = [o.strip() for o in _cors_raw if o.strip()]
# Fail fast if no CORS origins configured in production
```

---

## Part 4: Dashboard API Key in Query Parameter

**File:** `api/routes/dashboard.py` lines 43-60
**Severity:** MEDIUM

Admin API keys are passed as query parameters (`?key=key_id:secret`) for the dashboard:

```python
key: str = Query("", description="Admin API key in key_id:secret format"),
```

Query parameters are:
1. Logged in access logs (web server, reverse proxy, load balancer)
2. Stored in browser history
3. Included in `Referer` headers for outbound links

This means admin API keys will appear in plain text in server logs.

**Recommendation:** Either use session-based auth for the dashboard (cookie with HTTPS-only flag), or accept the key via `Authorization` header and redirect to a session cookie after validation.

---

## Summary of Findings

### HIGH Severity (Must Fix Before Production)

| ID | Location | Issue |
|---|---|---|
| RL-001 | `api/main.py` | IP rate limiting bypassable via X-Forwarded-For manipulation in proxy deployments |
| RL-002 | `api/routes/auth.py` | No rate limit on key creation, unlimited buyer keys with arbitrary owner_id |
| IV-001 | `api/routes/services.py` | No string length limits on service registration fields |
| IV-002 | `api/main.py` | No maximum request body size configured (OOM/DoS vector) |
| IV-007 | `api/routes/proxy.py` | Path traversal sequences not normalized before proxy forwarding |

### MEDIUM Severity (Fix Before Production)

| ID | Location | Issue |
|---|---|---|
| RL-003 | `api/main.py` | No X-RateLimit-* headers on 429 responses |
| RL-004 | `marketplace/rate_limit.py` | In-memory state not shared across workers |
| IV-003 | `api/routes/services.py` | No bounds on public list endpoint query parameters |
| IV-004 | Multiple routes | Path parameters not validated as UUID format |
| IV-005 | `api/routes/auth.py` | `rate_limit` field has no maximum bound |
| IV-010 | `api/routes/identity.py` | No validation on `metadata` and `capabilities` fields |
| IV-012 | `api/routes/teams.py` | Routing rule fields have no length/count limits |
| IV-013 | `marketplace/webhooks.py` | Webhook URL SSRF: no private IP DNS check at registration |
| IV-014 | `api/routes/settlement.py` | `period_start`/`period_end` not validated as ISO 8601 |
| IV-016 | `api/routes/admin.py` | `period` parameter silent fallback masks invalid input |
| CORS | `api/main.py` | CORS default is wildcard `*` |
| DASH | `api/routes/dashboard.py` | Admin API key exposed in query parameter (logged) |

### LOW Severity (Address in Follow-up)

| ID | Location | Issue |
|---|---|---|
| RL-005 | `api/main.py` | Burst limit set to 2x sustained rate |
| RL-006 | `marketplace/rate_limit.py` | Cleanup method never called, memory creep |
| IV-006 | `api/routes/auth.py` | `owner_id` not validated for format or ownership |
| IV-008 | `api/routes/discovery.py` | `sort_by` not whitelisted at route level |
| IV-009 | Multiple routes | `limit` not bounded via Query annotation in some endpoints |
| IV-011 | `api/routes/teams.py` | `config` dict has no size constraints |
| IV-015 | `api/routes/settlement.py` | `payment_tx` has no format validation |
| IV-017 | `api/routes/dashboard.py` | `date_from`/`date_to` not validated as YYYY-MM-DD |

---

## Positive Security Findings (Well Implemented)

The following areas are implemented correctly and should be preserved:

1. **SSRF protection in proxy** — `marketplace/proxy.py` resolves DNS and blocks private IPs at runtime. Solid layered defense.
2. **SSRF protection in service registration** — `marketplace/registry.py` blocks known private hostnames and IP ranges at write time.
3. **Parameterized SQL queries** — All database queries reviewed use parameterized `?` placeholders. No string concatenation SQL found in query logic.
4. **Webhook HMAC-SHA256 signing** — `marketplace/webhooks.py` signs all outbound webhook payloads. Implementation is correct.
5. **API secret hashing** — `marketplace/auth.py` stores only SHA-256 hashes of API secrets, never plain text.
6. **Constant-time comparison** — `auth.py` uses `secrets.compare_digest()` for secret validation, preventing timing attacks.
7. **Reputation period validation** — `reputation.py` validates the `period` parameter with an explicit regex, not just type checking.
8. **Webhook event allowlist** — `marketplace/webhooks.py` enforces `ALLOWED_EVENTS` frozenset; unknown events are rejected.
9. **Role-based access control** — Admin and provider roles are enforced consistently via `require_admin()` and `require_provider()` in `api/deps.py`.
10. **Owner-scoped data access** — Settlement, webhook, and team operations are all scoped to the authenticated owner_id.
