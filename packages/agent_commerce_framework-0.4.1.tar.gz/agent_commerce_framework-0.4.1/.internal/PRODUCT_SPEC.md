# AgenticTrade — Product Spec
> MIM-299 | Revenue: 10% platform commission | Status: Live (agentictrade.io)

## Product Vision

**AgenticTrade 是一個託管式 AI Agent 服務交易平台**，讓 AI Agent 在 agentictrade.io 上自動發現、付費、消費彼此的服務。平台內建 x402 穩定幣支付、多軌法幣支付、服務註冊/發現、使用量追蹤、聲譽系統、和自動分潤。

**商業模式**：平台運營（非賣框架）
- 核心收入：每筆交易 10% 平台佣金
- 開發者引流：免費 Starter Kit（SDK + 模板 + 13 章指南）
- 平台技術：內部資產，不對外販售
- Judy 指示（2026-03-20）：平台技術不賣出去，我們自己做平台

## Market Context（2026-03-18）

### 競品分析

| 平台 | 類型 | 真實交易量 | 狀態 |
|------|------|-----------|------|
| x402 Bazaar (Coinbase) | Agent marketplace | ~$1.6M/mo organic（81% 刷量過濾後） | 運營中但早期 |
| ACP (OpenAI+Stripe) | Agent checkout | ChatGPT 內建 | 生產環境（法幣） |
| Olas/Mech Marketplace | Agent services | 700K tx/mo | 鏈上運營 |
| Nevermined | Infrastructure layer | N/A | SDK |
| ClawMart | Agent marketplace | 極小 | Hackathon 級 |

**市場現況**：95% narrative, 5% real usage。x402 有真實 SDK 但有機量很小（$1.6M/mo）。先行者機會。
**x402 真實用戶**：Firecrawl（web scraping）、Browserbase（browser sessions）、Freepik（AI 圖片）。

### 差異化

1. **託管式平台**：開發者不需要自己架市集，直接在 agentictrade.io 上架服務
2. **自帶種子商品**：CoinSifter API 作為第一個真實可用的付費服務
3. **多軌支付**：x402 穩定幣 + NOWPayments (300+ crypto) + Stripe ACP + Dodo 法幣
4. **最低費率**：10% 佣金 vs RapidAPI 25% / App Store 30%
5. **免費 Starter Kit**：SDK + 模板 + 指南，零門檻上手

## Target Audience

1. **API 服務提供者** — 有 AI/Data API，想靠 Agent 流量變現（在我們平台上架）
2. **AI Agent 開發者** — 需要發現、付費、使用第三方 API 的能力
3. **AI Startup CTOs** — 想讓自家 Agent 消費外部服務（用我們 SDK）
4. **企業 R&D** — 試驗 Agent-to-Agent commerce（用我們平台作測試環境）

## Product Components

### 1. Framework Core（開源骨架 + 商業擴展）

```
agent-commerce-framework/
├── marketplace/          # 市集核心
│   ├── registry.py       # 服務註冊中心
│   ├── discovery.py      # 服務搜尋/推薦
│   ├── payment.py        # x402 + Stripe 雙軌支付
│   ├── metering.py       # 用量追蹤 + 計費
│   └── settlement.py     # 分潤結算
├── api/                  # REST API
│   ├── routes/           # FastAPI routes
│   ├── auth.py           # API Key + Agent 身份認證
│   └── middleware.py     # Rate limit + logging
├── dashboard/            # 管理後台（React/Next.js）
│   ├── analytics/        # 交易分析
│   ├── services/         # 服務管理
│   └── settings/         # 平台設定
├── templates/            # 服務模板
│   ├── ai-api/           # AI API 服務模板
│   ├── data-feed/        # 數據服務模板
│   └── agent-tool/       # Agent 工具模板
├── docker-compose.yml    # 一鍵部署
├── .env.example
└── README.md
```

### 2. Pre-built Service Templates

| 模板 | 說明 | 預設定價 |
|------|------|---------|
| AI API Service | 包裝任何 AI 模型為付費 API | $0.005/call |
| Data Feed | 即時數據訂閱服務 | $0.002/call |
| Agent Tool | Agent 可用的工具服務 | $0.01/call |
| Batch Processing | 大量處理任務服務 | $0.05/job |

### 3. CoinSifter API（種子商品 Demo）

把 CoinSifter 的加密貨幣篩選功能包裝成 x402 付費 API，作為市集的第一個真實商品：

- `GET /api/scan` — 加密貨幣技術面掃描（$0.01/call）
- `GET /api/signals` — 交易信號（$0.02/call）
- `GET /api/report/{symbol}` — 個幣報告（$0.05/call）

### 4. 管理者後台

- 即時交易量/收入儀表板
- 服務品質監控（延遲、錯誤率、uptime）
- 分潤管理（自動 USDC 結算）
- Agent 註冊/審核管理

## Technical Architecture

```
┌─────────────────────────────────────────┐
│            Dashboard (Next.js)           │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│          API Gateway (FastAPI)           │
│  ┌──────────┬──────────┬──────────┐     │
│  │  Auth    │  Rate    │  x402    │     │
│  │  Layer   │  Limit   │  Payment │     │
│  └──────────┴──────────┴──────────┘     │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│         Marketplace Engine               │
│  ┌──────────┬──────────┬──────────┐     │
│  │ Registry │ Discovery│ Metering │     │
│  └──────────┴──────────┴──────────┘     │
│  ┌──────────┬──────────┐                │
│  │ Payment  │Settlement│                │
│  │ (x402+   │ (USDC    │                │
│  │  Stripe) │  split)  │                │
│  └──────────┴──────────┘                │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│        Service Providers (Agents)        │
│  ┌────────┐ ┌────────┐ ┌────────┐      │
│  │CoinSift│ │Custom  │ │Custom  │      │
│  │er API  │ │Agent 1 │ │Agent 2 │      │
│  └────────┘ └────────┘ └────────┘      │
└─────────────────────────────────────────┘
```

## Revenue Model

| 收入來源 | 定價 | 說明 |
|----------|------|------|
| **平台佣金** | 10% per call | 每筆 API 交易抽 10%（業界基準 20-30%） |
| **Premium Tier**（規劃中） | $49-199/mo | 高用量折扣、優先排序、分析報表 |
| **Enterprise SLA**（規劃中） | Custom | SLA 保證、專屬支援、客製化整合 |

**Starter Kit = 免費**（驅動平台採用率）

**費率基準**：
- RapidAPI: 25% | Apple: 30% | AWS: 3-5%（靠基建賺錢，非同級競品） | x402: $0
- 我們 10% = 比 RapidAPI 便宜 60%，但提供完整商業堆疊

### Provider 成長計劃（Launch Promotion）

| 期間 | 佣金 | 目的 |
|------|------|------|
| 第 1 個月 | **0%**（免費） | 零風險上手，讓 provider 看到真實流量 |
| 第 2-3 個月 | **5%**（半價） | 養成習慣，provider 已有持續收入 |
| 第 4 個月起 | **10%**（標準） | provider 已有黏性和數據依賴 |

**Buyer 端優惠**：
- 新註冊：$5 免費額度
- 首次充值：25% bonus（充 $20 得 $25）

**裂變機制**：
- 推薦計劃：provider → provider，雙方各減 2% 佣金一個月
- Early Adopter Badge：前 50 名 provider 永久標章（聲譽加分）
- 保量承諾：前 10 名 provider 保證每月最低 1,000 API calls

**預估成本**：~$500（前 3 個月 10 個 provider 的放棄佣金），極高 ROI

## Development Plan

### Phase 1: Core Framework (Week 1-2)
- [ ] 服務 Registry + Discovery（Python）
- [ ] x402 支付整合（賣方 middleware）
- [ ] API Gateway (FastAPI)
- [ ] 基本認證 (API Key)
- [ ] Docker Compose 部署

### Phase 2: CoinSifter API Demo (Week 2-3)
- [ ] 包裝 CoinSifter 核心功能為 API
- [ ] x402 計費 middleware
- [ ] API 文件 + 使用範例

### Phase 3: Dashboard + Settlement (Week 3-4)
- [ ] 管理後台 (Next.js)
- [ ] 交易分析報表
- [ ] USDC 分潤自動結算
- [ ] 服務品質監控

### Phase 4: Polish + QA (Week 4-5)
- [ ] 完整文件（中/英/韓）
- [ ] Expert Review
- [ ] QA Pipeline (≥8.5)
- [ ] Windows 測試（主要平台）
- [ ] Judy Review

## Risk Assessment

| 風險 | 嚴重度 | 減緩 |
|------|--------|------|
| x402 SDK 不穩定 | 中 | 雙軌支付（Stripe 備選） |
| 市場太早期 | 中 | 教育+工具捆綁（MIM-297→299 升級路徑） |
| 競品快速出現 | 低 | 先行者+真實種子商品（CoinSifter）|
| 技術複雜度高 | 中 | 分階段交付，Phase 1 先出 MVP |

## Success Metrics

- **開發者採用**: Starter Kit 下載 ≥ 100（首月）
- **服務供應商**: ≥ 10 個第三方服務上架（Q2 2026）
- **交易量**: ≥ 1,000 API calls/day（Q3 2026）
- **平台收入**: ≥ $4,500/month（10 services × 1K calls/day × $1.50 avg × 10%）
- **CoinSifter API**: ≥ 100 次真實付費 call（驗證需求）
