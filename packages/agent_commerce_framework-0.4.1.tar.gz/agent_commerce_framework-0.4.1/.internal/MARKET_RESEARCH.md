# AgenticTrade — Market Research (Updated 2026-03-20)

> 策略方向：託管式平台（非販售框架），10% 佣金，免費 Starter Kit

## Key Findings

### Market Size
- Agentic AI: $9.14B (2026) → $52.6B (2030)
- Agentic Commerce: ~$800M (2026) → $5.2B (2033, 32.5% CAGR)
- x402 organic volume: ~$1.6M/month (not $24M — 81% was wash trades)
- x402 total transactions: 120M+ ($41M+ value transferred)

### Direct Competitors
| Platform | Type | Status | Threat Level |
|----------|------|--------|-------------|
| Olas Mech | Agent marketplace | Live, 10M+ tx | Medium (crypto-only) |
| Nevermined | Payment infra | Live | Low (infra, not marketplace) |
| Agentic (archived) | API marketplace | DEAD Feb 2026 | None (validates risk) |

### Protocol Landscape
- **x402** (Coinbase+Cloudflare): Live, crypto micropayments, Apache 2.0
- **ACP** (OpenAI+Stripe): Production in ChatGPT, traditional e-commerce
- **UCP** (Google+Shopify): Spec public, enormous coalition, pre-rollout
- **AP2** (Google): Spec public, no production yet

### Commission Fee Benchmarks (2026-03-20 調查)

| Platform | Take Rate | Category |
|----------|-----------|----------|
| Apple App Store | 30% (15% for <$1M) | App marketplace |
| Google Play | 30% (15% for subs) | App marketplace |
| RapidAPI | 25% | API marketplace |
| Gumroad Discover | 30% | Creator marketplace |
| Gumroad Direct | 10% + $0.50 | Creator sales |
| Lemon Squeezy | 5-18% | MoR platform |
| AWS Marketplace | 3-5% | Cloud API |
| x402 Protocol | $0 (gas only) | Payment protocol |
| **AgenticTrade** | **10%** | **Agent commerce** |

### Our Positioning
**AgenticTrade = 託管式 AI Agent 服務交易平台**（不賣框架原始碼）

核心競爭力：
- **完整商業堆疊**：Discovery + Payment + Reputation（x402 只有支付）
- **最低費率**：10% vs RapidAPI 25% / App Store 30%
- **多軌支付**：x402 USDC + NOWPayments 300+ crypto + Stripe ACP + Dodo 法幣
- **Agent-native**：為 Agent-to-Agent 設計，不是 Human-to-API
- **MCP Bridge**：Claude/GPT Agent 原生發現服務

**平台技術 = 內部資產**（Judy 2026-03-20 指示：不對外販售）

### Launch Promotion Strategy（Judy 2026-03-20 核准）

**Provider Growth Program — 佣金遞進**：
| 期間 | 佣金 | 目的 |
|------|------|------|
| 第 1 個月 | 0% | 零風險上手 |
| 第 2-3 個月 | 5% | 養成習慣 |
| 第 4 個月起 | 10% | 標準費率 |

**Buyer 優惠**：$5 免費額度 + 首充 25% bonus

**裂變**：推薦減 2% 佣金 / Early Adopter Badge / 前 10 名保量 1K calls/mo

**行銷定位**：
- vs RapidAPI：「便宜 60%，專為 Agent 設計」
- vs App Store：「10% vs 30%，零審核延遲」
- vs x402 原生：「不只支付，完整商業堆疊（Discovery + Reputation + Settlement）」
- 關鍵訊息：**「Agent 市集手續費最低，首月免費」**

**預估成本**：~$500（3 個月 10 provider 放棄佣金）

### Risk Signals
- "Agentic" project (transitive-bullshit/agentic) archived Feb 2026 — pure middleware marketplace faces chicken-and-egg
- x402 real volume is tiny ($1.6M/month organic)
- 90%+ current buyers are developers, not autonomous agents

### Pricing Validation
- Per-call API pricing: $0.01-$0.10/operation is standard
- Platform fee: 1-2% (Nevermined) to 10% is market range
- Our 10% default is within range

### Recommended Positioning
- Target API providers wanting agent traffic monetization (在平台上架服務)
- Target AI agent developers needing third-party API discovery + payment (用平台 SDK)
- **「Agent 市集手續費最低，首月免費」** — 核心行銷訊息
- 10% 平台佣金 = 比 RapidAPI 便宜 60%，提供完整商業堆疊
- 多軌支付（x402 + Stripe ACP + NOWPayments + Dodo）降低進入門檻
- Provider Growth Program（首月 0%→半價→標準）解決冷啟動問題

## Sources
- x402 Foundation: https://www.x402.org/
- Coinbase x402 GitHub: https://github.com/coinbase/x402
- ACP Spec: https://github.com/agentic-commerce-protocol/
- UCP: https://ucp.dev/
- Olas Mech: https://olas.network/mech-marketplace
- Nevermined: https://nevermined.ai/
- Wash trade analysis: ~$1.6M organic (Allium Labs + OnchainLu)
