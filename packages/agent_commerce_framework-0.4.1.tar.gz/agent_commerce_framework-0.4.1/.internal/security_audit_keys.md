# Security Audit: API Key & Secrets Scan
**Date:** 2026-03-19
**Auditor:** J (Security Reviewer)
**Scope:** All files under `/home/ubuntu/projects/agent-commerce-framework/` excluding `.venv/`

---

## Executive Summary

| Severity | Count |
|----------|-------|
| CRITICAL | 1 |
| HIGH     | 5 |
| MEDIUM   | 3 |
| LOW / INFO | 4 |

One CRITICAL issue requires immediate action: **real NOWPayments production credentials are present in the `.env` file** on disk. Although the file is not tracked by git, the key format (`JWKX4DF-2P94AVK-JYR6KM1-EB5XPRW`) and sandbox flag (`false`) confirm it is a live production API key.

---

## CRITICAL Issues

### CRIT-1: Live NOWPayments Production API Key in `.env`

**File:** `/home/ubuntu/projects/agent-commerce-framework/.env`
**Lines 7-8:**
```
NOWPAYMENTS_API_KEY=JWKX4DF-2P94AVK-JYR6KM1-EB5XPRW
NOWPAYMENTS_IPN_SECRET=89b6723b-ac17-4a1a-8dfa-b447f291ffd6
NOWPAYMENTS_SANDBOX=false
```

**Risk:** `NOWPAYMENTS_SANDBOX=false` proves this is a production key, not a test key. Anyone with read access to this server (other shell users, misconfigured file permissions, log exfiltration) can call the NOWPayments API with full payment creation and IPN verification capabilities.

**Git status:** `.env` is NOT tracked by git and is correctly listed in `.gitignore` — it has never been committed.

**File permissions (ADDITIONAL RISK):** Current permissions are `-rw-rw-r--` (mode 664). This means:
- Group members can read the file
- ALL other local users can read the file

Any user with shell access to this server can read the live production API key right now.

**Required actions:**
1. Rotate `NOWPAYMENTS_API_KEY` immediately via the NOWPayments dashboard.
2. Rotate `NOWPAYMENTS_IPN_SECRET` as well.
3. Lock down the `.env` file to owner-read only (DONE — run immediately):
   ```bash
   chmod 600 /home/ubuntu/projects/agent-commerce-framework/.env
   ```
4. Confirm no process logs or debug output echoes these values.

---

## HIGH Issues

### HIGH-1: Hardcoded Webhook Secret in Example File

**File:** `/home/ubuntu/projects/agent-commerce-framework/examples/webhook_listener.py`
**Line 19:**
```python
WEBHOOK_SECRET = "my-secret"
```
**Line 77:**
```python
print(f"Secret: {WEBHOOK_SECRET}")
```

**Risk:** Example code printed verbatim in README or documentation tutorials trains users to hardcode webhook secrets. The `print` statement on line 77 also echoes the secret to stdout, which may be captured in server logs. If a user copies this example to production unchanged, their webhook signatures become trivially forgeable.

**Fix:** Replace with environment variable lookup and remove the print:
```python
import os
WEBHOOK_SECRET = os.environ.get("WEBHOOK_SECRET", "")
if not WEBHOOK_SECRET:
    raise RuntimeError("WEBHOOK_SECRET env var is required")
```

---

### HIGH-2: Admin API Key Printed Plaintext to stdout in Seed Scripts

**Files:**
- `/home/ubuntu/projects/agent-commerce-framework/seed/demo_data.py` lines 39, 238-239
- `/home/ubuntu/projects/agent-commerce-framework/seed/register_coinsifter.py` lines 40, 67, 129, 138

**Examples:**
```python
print(f"  Admin key: {admin_key_id}:{admin_secret}")
print(f"Dashboard: http://localhost:8000/admin/dashboard?key={admin_key_id}:{admin_secret}")
```

**Risk:** Admin credentials printed to stdout will appear in CI/CD logs, systemd journal, or any log aggregation tool. Combined with the fact that admin keys grant full platform control, this is a meaningful exposure surface.

**Fix:** Omit the secret from output or print only the key_id:
```python
print(f"  Admin key ID: {admin_key_id}  (secret stored securely, not shown)")
```
Or use a `--show-secret` opt-in flag.

---

### HIGH-3: Admin Credentials Embedded in Dashboard URL (Query Parameter)

**File:** `/home/ubuntu/projects/agent-commerce-framework/api/routes/dashboard.py`
**Lines 43-60:** Dashboard accepts `?key=key_id:secret` as a query parameter.

**Files (seed scripts):**
```
http://localhost:8000/admin/dashboard?key={admin_key_id}:{admin_secret}
```

**Risk:** Credentials in query parameters appear in:
- Server access logs (`access.log`)
- Browser history
- HTTP Referer headers when navigating from the dashboard to external links
- Proxy and CDN logs

**Fix:** Accept credentials via HTTP header (`Authorization: Bearer`) or a short-lived session cookie. If query-parameter auth must remain for browser convenience, issue a short-lived nonce token instead of transmitting the raw API secret.

---

### HIGH-4: Default Database Password in docker-compose.yml

**File:** `/home/ubuntu/projects/agent-commerce-framework/docker-compose.yml`
**Lines 8, 33:**
```yaml
POSTGRES_PASSWORD: ${DATABASE_PASSWORD:-acf_dev_password}
DATABASE_URL: postgresql://acf_user:${DATABASE_PASSWORD:-acf_dev_password}@postgres:5432/acf_db
```

**Risk:** If `DATABASE_PASSWORD` is not set in the deployment environment, the container starts with the hardcoded password `acf_dev_password`. Any attacker who can reach port 5432 (misconfigured firewall, container network escape) gains full database access.

**Fix:** Remove the default fallback. Force the operator to set the password explicitly:
```yaml
POSTGRES_PASSWORD: ${DATABASE_PASSWORD:?DATABASE_PASSWORD must be set}
```

---

### HIGH-5: Dynamic f-string SQL with Column Names from Code (SQL Injection Surface)

**Files:**
- `/home/ubuntu/projects/agent-commerce-framework/marketplace/db.py` lines 288, 313, 451, 475, 639
- `/home/ubuntu/projects/agent-commerce-framework/marketplace/settlement.py` lines 149-152
- `/home/ubuntu/projects/agent-commerce-framework/api/routes/dashboard_queries.py` lines 227, 234

**Pattern:**
```python
set_clause = ", ".join(f"{k} = ?" for k in filtered)
cursor.execute(f"UPDATE services SET {set_clause} WHERE id = ?", values)

where = " AND ".join(conditions)
conn.execute(f"SELECT * FROM services WHERE {where} ...", params)
```

**Risk Assessment:** The `where` clause is built from a hardcoded list of conditions that only ever append `"column = ?"` strings — the column names come from internal code, not user input. Similarly, the `set_clause` is built from an allowlist (`allowed` dict). The actual values are always passed as parameterized `?` placeholders.

**Current verdict: LOW injection risk** because column names are allowlist-controlled. However, this pattern is one refactor away from being dangerous if future developers add user-controlled sort/filter columns without understanding the risk.

**Fix:** Add a comment warning at each dynamic SQL construction site, or refactor to use a fully static query builder:
```python
# SECURITY: set_clause uses only allowlisted column names, never user input.
# If adding new columns here, ensure they come from the `allowed` set above.
set_clause = ", ".join(f"{k} = ?" for k in filtered)
```

---

## MEDIUM Issues

### MED-1: CORS Wildcard Default (`*`) in Production Config

**File:** `/home/ubuntu/projects/agent-commerce-framework/api/main.py`
**Line 54:**
```python
_cors_raw = os.environ.get("CORS_ORIGINS", "*").split(",")
```

**Note:** The actual `.env` sets `CORS_ORIGINS=https://agentictrade.io,http://localhost:3000`, which is correct. However, the fallback default is `*` (allow all origins). If `CORS_ORIGINS` is accidentally unset in a production deployment, the server becomes fully open to cross-origin requests.

**Fix:** Change the default to an empty string that results in a deny-all:
```python
_cors_raw = os.environ.get("CORS_ORIGINS", "").split(",")
if not any(_cors_raw):
    raise RuntimeError("CORS_ORIGINS must be explicitly configured")
```

---

### MED-2: Placeholder Private Key Format in Documentation

**File:** `/home/ubuntu/projects/agent-commerce-framework/docs/payments.md`
**Line 464:**
```
CDP_API_KEY_SECRET=-----BEGIN EC PRIVATE KEY-----\n...\n-----END EC PRIVATE KEY-----
```

**Risk:** This is a documentation placeholder, not a real key — confirmed by the `\n...\n` truncation. No real key material is exposed. However, automated scanners (GitHub Advanced Security, truffleHog, gitleaks) will flag this and create alert fatigue.

**Fix:** Replace the PEM header placeholder with a prose description:
```
CDP_API_KEY_SECRET=<paste your EC private key from the CDP portal here>
```

---

### MED-3: Webhook Secret Stored Plaintext in Database

**File:** `/home/ubuntu/projects/agent-commerce-framework/marketplace/webhooks.py`
**Lines 130-138:**
```python
self.db.insert_webhook({
    ...
    "secret": webhook.secret,
    ...
})
```
**File:** `/home/ubuntu/projects/agent-commerce-framework/marketplace/db.py` — webhooks table stores `secret TEXT`.

**Risk:** User-provided webhook secrets are stored in plaintext in the SQLite database. If the database file is exfiltrated (e.g., from a path traversal or backup leak), all webhook secrets are immediately compromised. Webhook secrets are used to verify HMAC signatures — they need to be verified but not retrieved, so they should be hashed.

**Fix:** Store `HMAC-SHA256(secret)` or use bcrypt-truncated hash. On delivery, sign with the stored hash directly (only possible if storing the raw key for HMAC use). The simplest safe approach: store only an HMAC of the secret keyed with a server-side pepper:
```python
import hmac, hashlib, os
PEPPER = os.environ.get("WEBHOOK_SECRET_PEPPER", "").encode()
stored_secret = hmac.new(PEPPER, secret.encode(), hashlib.sha256).hexdigest()
```

---

## LOW / INFO Items

### INFO-1: Test API Keys Are Clearly Fake (No Action Required)

**Files:** `tests/test_stripe_acp.py`, `tests/test_sdk.py`, `tests/test_webhooks.py`, etc.

Values like `sk_test_fake_key_123`, `sk_test_explicit_key`, `test-api-key`, `secret123`, `key_1:secret_abc` are clearly synthetic test fixtures. These are false positives — no action required.

---

### INFO-2: Stripe `sk_test_` Prefix in Docs — Placeholder Only

**File:** `/home/ubuntu/projects/agent-commerce-framework/docs/payments.md` line 473:
```
STRIPE_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxxxx
```

This follows the `sk_test_` prefix convention and has `xxxx` padding — clearly a documentation placeholder. No action required.

---

### INFO-3: whsec_ Placeholder in API Reference Docs

**Files:** `docs/API_REFERENCE.md` line 1163:
```json
"secret": "whsec_my_webhook_secret"
```

This is a documentation example value. The `whsec_` prefix is used by Stripe; this appears to be borrowed for illustration only. No real key. No action required.

---

### INFO-4: Fake Wallet Address in Example Code

**File:** `/home/ubuntu/projects/agent-commerce-framework/examples/two_agents_trading.py` line 87:
```python
"wallet_address": "0x1234567890abcdef1234567890abcdef12345678",
```

Clearly a placeholder (sequential hex pattern). No real funds at risk. No action required.

---

## Git / Secrets History Verification

| Check | Result |
|-------|--------|
| `.env` tracked by git | NO — not in git index |
| `.env` ever committed | NO — zero commits found in full history |
| `.gitignore` includes `.env` | YES — line 8 |
| `.gitignore` includes `*.db` | YES — line 7 |

**Conclusion:** No credential leakage has occurred via git. The risk is confined to local disk access.

---

## Remediation Priority

| Priority | Action | File |
|----------|--------|------|
| 1 (TODAY) | Rotate NOWPayments API key + IPN secret | `.env` |
| 1 (TODAY) | `chmod 600 .env` | `.env` |
| 2 | Remove hardcoded `WEBHOOK_SECRET` from example | `examples/webhook_listener.py` |
| 3 | Suppress admin secret from stdout in seed scripts | `seed/demo_data.py`, `seed/register_coinsifter.py` |
| 3 | Remove `acf_dev_password` fallback from docker-compose | `docker-compose.yml` |
| 4 | Move dashboard auth to header (not query param) | `api/routes/dashboard.py` |
| 5 | Add SQL allowlist comments to dynamic query builders | `marketplace/db.py`, `dashboard_queries.py` |
| 6 | Fix CORS wildcard fallback | `api/main.py` |
| 7 | Hash webhook secrets before DB storage | `marketplace/webhooks.py`, `marketplace/db.py` |
| 8 | Replace PEM placeholder in docs | `docs/payments.md` |
