# OWASP Top 10 Security Audit — Agent Commerce Framework

**Audit Date:** 2026-03-19
**Auditor:** Security Reviewer Agent
**Scope:** All source files in api/, marketplace/, payments/, sdk/, mcp_bridge/
**Framework Version:** 0.4.0

---

## Executive Summary

The Agent Commerce Framework has a well-structured security foundation in several areas, particularly for SQL injection prevention and basic authentication. However, the audit identified **3 CRITICAL**, **6 HIGH**, and **5 MEDIUM** severity issues that must be addressed before production deployment. The most dangerous issues involve: a hardcoded webhook secret in example code that could be copied into production, wildcard CORS misconfiguration paired with wildcard credentials, a TOCTOU race condition in payment processing that enables double-spending, missing SSRF protection on webhook delivery, and absent security response headers throughout the API.

---

## Findings Summary Table

| # | Severity | Category | Issue | File |
|---|----------|----------|-------|------|
| F-01 | CRITICAL | A02 / Secrets | Hardcoded webhook secret in example with plaintext printout | `examples/webhook_listener.py:19` |
| F-02 | CRITICAL | A04 / Insecure Design | TOCTOU race condition: free-tier check not atomic with usage insert | `marketplace/proxy.py:121-128` |
| F-03 | CRITICAL | A10 / SSRF | Webhook delivery has no SSRF guard — attacker can route to internal hosts | `marketplace/webhooks.py:217-219` |
| F-04 | HIGH | A05 / Misconfiguration | Wildcard CORS (`*`) is the default — blocks `allow_credentials` but conflicts with browser security model | `api/main.py:54-63` |
| F-05 | HIGH | A02 / Cryptographic | API secret hashed with SHA-256 (not bcrypt/argon2) — vulnerable to offline brute-force | `marketplace/auth.py:33-35` |
| F-06 | HIGH | A01 / Broken Access | `GET /api/v1/teams/{team_id}` exposes members/rules/gates with no auth check | `api/routes/teams.py:99-116` |
| F-07 | HIGH | A01 / Broken Access | `GET /api/v1/teams/{team_id}/members` and `GET .../rules` have no auth check | `api/routes/teams.py:188-197, 249-254` |
| F-08 | HIGH | A09 / Logging Failures | No security event audit log — failed logins, role escalation, payment events not recorded | Multiple |
| F-09 | HIGH | A08 / Data Integrity | Webhook signature header mismatch: dispatches `X-Webhook-Signature` but example listener reads `X-ACF-Signature` | `marketplace/webhooks.py:210`, `examples/webhook_listener.py:29` |
| F-10 | MEDIUM | A05 / Misconfiguration | Security response headers absent — no CSP, no X-Frame-Options, no HSTS | `api/main.py` |
| F-11 | MEDIUM | A03 / Injection | Dynamic SQL `SET` clause built from allowlisted key names — safe today but fragile by design | `marketplace/db.py:308-314, 471-475, 636-640` |
| F-12 | MEDIUM | A07 / Auth Failures | API keys have no expiry enforced by default; `expires_at` defaults to `None` | `marketplace/auth.py:75` |
| F-13 | MEDIUM | A05 / Misconfiguration | Rate limiter is in-memory and per-process — bypassed under multi-worker deployments | `marketplace/rate_limit.py`, `api/main.py:125` |
| F-14 | MEDIUM | A04 / Insecure Design | Dashboard authentication passes secret in URL query parameter — logged by web servers and proxies | `api/routes/dashboard.py:43-60` |
| F-15 | LOW | A09 / Logging | MCP bridge tool errors return a plain dict with "error" key — no structured logging or alerting | `mcp_bridge/server.py:186-189` |

---

## Detailed Findings

---

### F-01 — CRITICAL: Hardcoded Webhook Secret

**File:** `examples/webhook_listener.py:19, 77`

**OWASP:** A02:2021 — Cryptographic Failures / A07:2021 — Identification and Authentication Failures

**Code:**
```python
# examples/webhook_listener.py
WEBHOOK_SECRET = "my-secret"  # line 19
...
print(f"Secret: {WEBHOOK_SECRET}")  # line 77 — printed to stdout on startup
```

**Risk:** The hardcoded string `"my-secret"` is both checked into version control and printed to stdout on startup. Developers commonly copy example files into production without modifying secrets. Any process with access to the server's stdout (logging agents, CI/CD pipelines, container logs) receives the secret. An attacker who reads logs can forge arbitrary webhook payloads and bypass HMAC verification entirely.

**Impact:** Full bypass of webhook signature verification, enabling injection of forged marketplace events (`payment.completed`, `settlement.completed`) into any subscriber using the default secret.

**Remediation:**
```python
# examples/webhook_listener.py — replace hardcoded constant
import os
import sys

WEBHOOK_SECRET = os.environ.get("WEBHOOK_SECRET", "")
if not WEBHOOK_SECRET:
    print("[ERROR] WEBHOOK_SECRET environment variable is required.", file=sys.stderr)
    sys.exit(1)

# Remove the print statement that exposes the secret
```

---

### F-02 — CRITICAL: TOCTOU Race Condition in Free-Tier Payment Check

**File:** `marketplace/proxy.py:117-131`

**OWASP:** A04:2021 — Insecure Design

**Code:**
```python
# marketplace/proxy.py:117-131
free_calls = service.get("free_tier_calls", 0)
is_free_tier = False
if free_calls > 0:
    with self.db.connect() as conn:
        row = conn.execute(
            """SELECT COUNT(*) as cnt FROM usage_records
               WHERE service_id = ? AND buyer_id = ?""",
            (service_id, buyer_id),
        ).fetchone()
        current_count = row["cnt"] if row else 0
        if current_count < free_calls:
            price = Decimal("0")
            is_free_tier = True
```

The usage count is read in one connection, then a new usage record is inserted in a separate connection (line 214). Between the SELECT and the INSERT, a concurrent request for the same `(service_id, buyer_id)` pair will read the same count and also receive free-tier pricing. With `free_tier_calls=5`, a buyer sending 10 rapid concurrent requests could receive all 10 at no charge.

**Impact:** Financial loss to the platform. With a service at $1.00/call and `free_tier_calls=1`, a bot sending 100 concurrent requests pays $0 instead of $99.

**Remediation:** Use a single atomic transaction with a `SELECT ... FOR UPDATE` equivalent in SQLite (`BEGIN IMMEDIATE` + INSERT in one connection):

```python
# marketplace/proxy.py — atomic free-tier check + insert
free_calls = service.get("free_tier_calls", 0)
is_free_tier = False

with self.db.connect() as conn:
    conn.execute("BEGIN IMMEDIATE")  # serializes concurrent writes
    if free_calls > 0:
        row = conn.execute(
            "SELECT COUNT(*) as cnt FROM usage_records WHERE service_id=? AND buyer_id=?",
            (service_id, buyer_id),
        ).fetchone()
        if (row["cnt"] if row else 0) < free_calls:
            price = Decimal("0")
            is_free_tier = True

    # Insert usage record inside the same transaction
    conn.execute(
        "INSERT INTO usage_records (...) VALUES (...)",
        (...),
    )
```

---

### F-03 — CRITICAL: SSRF via Webhook Delivery URL

**File:** `marketplace/webhooks.py:188-260`

**OWASP:** A10:2021 — Server-Side Request Forgery

**Code:**
```python
# marketplace/webhooks.py:217-219
async with httpx.AsyncClient(timeout=10.0) as client:
    response = await client.post(
        webhook["url"],   # ← user-supplied URL, no SSRF validation
        content=body,
        headers=headers,
    )
```

The webhook delivery code performs an outbound HTTP POST to a user-supplied URL from the server. Although `subscribe()` validates that the URL starts with `https://` (line 97-98), this does not prevent SSRF because:

1. A hostname like `https://internal.corp/admin` passes the `https://` check.
2. A hostname that resolves to `169.254.169.254` (AWS metadata) passes the check.
3. DNS rebinding: a domain the attacker controls first resolves to a public IP (passes registration), then resolves to `127.0.0.1` on delivery.

The proxy code at `marketplace/proxy.py:88-111` has an SSRF guard (DNS resolution check against private IPs), but that guard is **not applied** to webhook delivery.

**Impact:** Server-Side Request Forgery to cloud metadata endpoints, internal services, admin dashboards. In a cloud environment, `169.254.169.254` exposes IAM credentials.

**Remediation:** Apply the same SSRF guard used in the proxy to webhook delivery:

```python
# marketplace/webhooks.py — add to _deliver() before httpx call
import ipaddress, socket
from urllib.parse import urlparse

def _validate_webhook_url(url: str) -> None:
    """Raise WebhookError if URL resolves to a private/loopback address."""
    parsed = urlparse(url)
    if not parsed.hostname:
        raise WebhookError("Invalid webhook URL")
    try:
        addrs = socket.getaddrinfo(parsed.hostname, None)
    except socket.gaierror:
        return  # Let httpx handle DNS failure
    for addr in addrs:
        try:
            ip = ipaddress.ip_address(addr[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                raise WebhookError(
                    f"Webhook URL resolves to a non-routable address: {ip}"
                )
        except ValueError:
            pass
```

Call `_validate_webhook_url(webhook["url"])` at the start of `_deliver()`.

---

### F-04 — HIGH: Wildcard CORS by Default

**File:** `api/main.py:54-63`

**OWASP:** A05:2021 — Security Misconfiguration

**Code:**
```python
# api/main.py:54-63
_cors_raw = os.environ.get("CORS_ORIGINS", "*").split(",")
_cors_all = _cors_raw == ["*"] or _cors_raw == [""]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if _cors_all else _cors_raw,
    allow_credentials=not _cors_all,   # True only when not wildcard
    allow_methods=["*"],
    allow_headers=["*"],
)
```

When `CORS_ORIGINS` is not set (the default), `allow_origins=["*"]` and `allow_credentials=False` is applied. The framework is an API handling payment and auth operations. Wildcard CORS means any web page on any origin can make cross-origin requests. While `allow_credentials=False` blocks cookie-based credentials, Bearer token headers are still forwarded by malicious JavaScript if a user visits an attacker page while holding an active session.

Additionally, `allow_methods=["*"]` and `allow_headers=["*"]` are overly permissive regardless of origin setting.

**Remediation:**
```python
# api/main.py — require explicit CORS configuration
_cors_origins_env = os.environ.get("CORS_ORIGINS", "")
_cors_origins = [o.strip() for o in _cors_origins_env.split(",") if o.strip()]

if not _cors_origins:
    logger.warning(
        "CORS_ORIGINS not configured. Cross-origin requests are blocked by default."
    )

app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
    allow_headers=["Authorization", "Content-Type", "Accept"],
)
```

---

### F-05 — HIGH: API Secret Hashed with SHA-256 Instead of a Password KDF

**File:** `marketplace/auth.py:33-35`

**OWASP:** A02:2021 — Cryptographic Failures

**Code:**
```python
# marketplace/auth.py:33-35
def hash_secret(raw_secret: str) -> str:
    """SHA-256 hash of the raw API secret."""
    return hashlib.sha256(raw_secret.encode()).hexdigest()
```

SHA-256 is a general-purpose hash function, not a password-hardened key derivation function. It is designed to be fast. With a modern GPU, an attacker who obtains the `api_keys` table (via SQL injection, backup leak, or insider threat) can compute billions of SHA-256 hashes per second. `secrets.token_urlsafe(32)` has high entropy (256 bits), which makes brute force impractical for random secrets, but any secrets with lower entropy (user-chosen, shortened, or derived from predictable patterns) are at immediate risk.

The contrast with best practice is stark: `bcrypt` or `argon2` with proper work factors make each verification take 100ms+, making offline cracking effectively impossible.

**Remediation:**
```python
# marketplace/auth.py — replace SHA-256 with argon2-cffi
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

_ph = PasswordHasher(time_cost=2, memory_cost=65536, parallelism=2)

def hash_secret(raw_secret: str) -> str:
    """Argon2id hash of the raw API secret."""
    return _ph.hash(raw_secret)

def verify_secret(raw_secret: str, stored_hash: str) -> bool:
    """Verify a raw secret against its stored Argon2id hash."""
    try:
        return _ph.verify(stored_hash, raw_secret)
    except VerifyMismatchError:
        return False
```

Update `APIKeyManager.validate()` to call `verify_secret()` instead of comparing SHA-256 digests. Existing keys will need a migration or re-issue.

---

### F-06 — HIGH: Unauthenticated Team Detail Endpoint Leaks Members and Configuration

**File:** `api/routes/teams.py:99-116`

**OWASP:** A01:2021 — Broken Access Control

**Code:**
```python
# api/routes/teams.py:99-116
@router.get("/teams/{team_id}")
async def get_team(team_id: str, request: Request):
    """Get team details with members, rules, and gates."""
    db = request.app.state.db
    team = db.get_team(team_id)
    if not team:
        raise HTTPException(status_code=404, detail="Team not found")

    members = db.get_team_members(team_id)
    rules = db.get_routing_rules(team_id)
    gates = db.get_quality_gates(team_id)

    return {
        **team,
        "members": members,
        "routing_rules": rules,
        "quality_gates": gates,
    }
```

No authentication is performed. Any unauthenticated caller who knows or can enumerate a `team_id` (which is a UUID, but exposed in `create_team` responses, webhook events, and other endpoints) receives the full team object including all member `agent_id` values, routing keyword triggers, and quality gate thresholds. This is an information disclosure that aids targeted attacks.

Note: `list_teams` (line 84-96) does require auth (with a try/except that returns empty on failure), but `get_team` does not.

**Remediation:**
```python
# api/routes/teams.py:99
@router.get("/teams/{team_id}")
async def get_team(team_id: str, request: Request):
    """Get team details — requires authentication."""
    owner_id, record = extract_owner(request)  # Add this
    db = request.app.state.db
    team = db.get_team(team_id)
    if not team:
        raise HTTPException(status_code=404, detail="Team not found")
    # Optional: restrict to owner or admin
    if team["owner_id"] != owner_id and record["role"] != "admin":
        raise HTTPException(status_code=403, detail="Access denied")
    ...
```

The same fix applies to:
- `GET /teams/{team_id}/members` (`teams.py:188-197`)
- `GET /teams/{team_id}/rules` (`teams.py:249-254`)
- `GET /teams/{team_id}/gates` (`teams.py:318-323`)

---

### F-07 — HIGH: Additional Unauthenticated Team Sub-Resource Endpoints

**File:** `api/routes/teams.py:188-197, 249-254, 318-323`

**OWASP:** A01:2021 — Broken Access Control

These three read endpoints expose team sub-resources with no authentication:

```python
@router.get("/teams/{team_id}/members")   # line 188 — no auth
@router.get("/teams/{team_id}/rules")     # line 249 — no auth
@router.get("/teams/{team_id}/gates")     # line 318 — no auth
```

All three should require at minimum `extract_owner()`, as described in F-06.

---

### F-08 — HIGH: No Security Event Audit Logging

**OWASP:** A09:2021 — Security Logging and Monitoring Failures

The framework has structured application logging (Python `logging` module) but lacks a security audit trail. The following security-critical events produce no log entry:

| Event | Location | Risk |
|-------|----------|------|
| Failed authentication attempt | `marketplace/auth.py:88-93` | Cannot detect credential stuffing or brute force |
| Successful admin key creation | `api/routes/auth.py:62-82` | No record of privilege escalation |
| Admin role verification (`verify_agent`) | `api/routes/identity.py:133-144` | Agent verification changes cannot be audited |
| Settlement creation and payout | `marketplace/settlement.py` | Financial audit trail incomplete |
| Rate limit exceeded | `api/routes/proxy.py:38-39` | Cannot distinguish attack from normal traffic |

**Remediation:** Add a dedicated security audit logger:

```python
# marketplace/audit.py
import logging
import json
from datetime import datetime, timezone

_audit_logger = logging.getLogger("security.audit")

def log_auth_failure(key_id: str, remote_ip: str) -> None:
    _audit_logger.warning(json.dumps({
        "event": "auth_failure",
        "key_id": key_id,
        "remote_ip": remote_ip,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }))

def log_admin_action(actor_id: str, action: str, target: str) -> None:
    _audit_logger.info(json.dumps({
        "event": "admin_action",
        "actor_id": actor_id,
        "action": action,
        "target": target,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }))
```

---

### F-09 — HIGH: Webhook Signature Header Name Mismatch

**File:** `marketplace/webhooks.py:210`, `examples/webhook_listener.py:29`

**OWASP:** A08:2021 — Software and Data Integrity Failures

The webhook dispatch code sends the signature in a header named `X-Webhook-Signature`:

```python
# marketplace/webhooks.py:208-210
headers = {
    "Content-Type": "application/json",
    "X-Webhook-Signature": signature,   # dispatched under this name
    "X-Webhook-Event": event,
}
```

The example webhook listener reads a different header name:

```python
# examples/webhook_listener.py:29
signature = self.headers.get("X-ACF-Signature", "")  # wrong header
```

Because `X-ACF-Signature` is never present in actual webhook deliveries, `signature` will always be an empty string. The HMAC check then fails (`hmac.compare_digest("", expected)` returns `False`), and the example silently rejects all valid webhooks. A developer who copies the example and wonders why it does not work may disable signature verification entirely as a workaround.

**Remediation:** Standardize on one header name throughout the codebase and documentation. The recommended name following industry convention is `X-Signature-256` or `X-Webhook-Signature`. Update the example:

```python
# examples/webhook_listener.py:29
signature = self.headers.get("X-Webhook-Signature", "")  # corrected
```

---

### F-10 — MEDIUM: Missing Security Response Headers

**File:** `api/main.py`

**OWASP:** A05:2021 — Security Misconfiguration

The application returns no HTTP security headers. A browser-based admin dashboard (`/dashboard/`) renders HTML from user data and is exposed to:

- **Clickjacking** — no `X-Frame-Options` or `frame-ancestors` CSP directive
- **MIME sniffing** — no `X-Content-Type-Options: nosniff`
- **XSS** — no `Content-Security-Policy`
- **Protocol downgrade** — no `Strict-Transport-Security` (HSTS)

**Remediation:** Add a security headers middleware:

```python
# api/main.py — add after CORS middleware
@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    # Apply CSP only to HTML responses (dashboard)
    content_type = response.headers.get("content-type", "")
    if "text/html" in content_type:
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "frame-ancestors 'none';"
        )
    return response
```

---

### F-11 — MEDIUM: Dynamic SQL SET Clause (Fragile Allowlist Pattern)

**File:** `marketplace/db.py:308-314` (`update_service`), `db.py:471-475` (`update_agent`), `db.py:636-640` (`update_team`)

**OWASP:** A03:2021 — Injection

**Code:**
```python
# marketplace/db.py:308-314
set_clause = ", ".join(f"{k} = ?" for k in filtered)
values = list(filtered.values()) + [service_id]

with self.connect() as conn:
    cursor = conn.execute(
        f"UPDATE services SET {set_clause} WHERE id = ?", values
    )
```

The column names (`k`) are injected directly into the SQL string via an f-string. The `allowed` allowlist on line 294 prevents arbitrary column injection today. However:

1. The pattern is unsafe by design — column names are never parameterized in SQL.
2. A future developer modifying the `allowed` set could inadvertently include a column name that, if user-controlled, enables injection.
3. Static analysis tools (SAST, CodeQL) will flag this as an injection vulnerability without reading the allowlist logic.

**Remediation:** Explicitly map allowed fields to their SQL column names and build queries from a controlled dictionary, or use an ORM. At minimum, add an assertion to catch future allowlist violations:

```python
# marketplace/db.py — strengthen the update pattern
_SAFE_SERVICE_COLUMNS = frozenset({
    "name", "description", "endpoint", "price_per_call",
    "currency", "payment_method", "status", "category",
    "tags", "metadata", "updated_at",
})

def update_service(self, service_id: str, updates: dict) -> bool:
    filtered = {k: v for k, v in updates.items() if k in _SAFE_SERVICE_COLUMNS}
    # Validate all keys are safe column identifiers (alphanumeric + underscore only)
    for col in filtered:
        assert col.replace("_", "").isalnum(), f"Invalid column name: {col!r}"
    ...
```

---

### F-12 — MEDIUM: API Keys Have No Default Expiry

**File:** `marketplace/auth.py:75`

**OWASP:** A07:2021 — Identification and Authentication Failures

**Code:**
```python
# marketplace/auth.py:75
self.db.insert_api_key({
    ...
    "expires_at": None,  # Never expires by default
})
```

API keys created through the standard flow never expire. There is no mechanism to force rotation. Long-lived credentials are a significant risk: a leaked or compromised key remains valid indefinitely unless manually revoked.

**Remediation:** Add a default expiry period and expose a key rotation endpoint:

```python
# marketplace/auth.py — add default expiry
from datetime import timedelta

def create_key(
    self,
    owner_id: str,
    role: str = "buyer",
    rate_limit: int = 60,
    wallet_address: Optional[str] = None,
    expires_in_days: int = 365,  # default 1 year
) -> tuple[str, str]:
    ...
    expires_at = (
        datetime.now(timezone.utc) + timedelta(days=expires_in_days)
    ).isoformat() if expires_in_days > 0 else None

    self.db.insert_api_key({
        ...
        "expires_at": expires_at,
    })
```

---

### F-13 — MEDIUM: In-Memory Rate Limiter Bypassed Under Multi-Worker Deployments

**File:** `marketplace/rate_limit.py`, `api/main.py:125`

**OWASP:** A05:2021 — Security Misconfiguration

**Code:**
```python
# api/main.py:125
rate_limiter = RateLimiter(rate=60, per=60.0, burst=120)
```

The `RateLimiter` stores token buckets in a Python dictionary (`self._buckets`) that is local to the process. When deployed with multiple Uvicorn workers (e.g., `uvicorn --workers 4`), each worker maintains an independent bucket, multiplying the effective rate limit by the number of workers. With 4 workers, the effective limit becomes 240 req/min per IP rather than 60.

Additionally, the `APIKeyManager.check_rate_limit()` in `marketplace/auth.py:103-122` has the same per-process issue.

**Remediation:** Use Redis-backed rate limiting for production multi-worker deployments. The in-memory limiter is acceptable for single-worker development only. Add a startup warning:

```python
# api/main.py
import os
if int(os.environ.get("WEB_CONCURRENCY", "1")) > 1:
    logger.warning(
        "Multi-worker mode detected. In-memory rate limiter is NOT shared across "
        "workers. Configure REDIS_URL for distributed rate limiting."
    )
```

---

### F-14 — MEDIUM: Dashboard Admin Key Passed in URL Query Parameter

**File:** `api/routes/dashboard.py:43-60, 67-71`

**OWASP:** A04:2021 — Insecure Design

**Code:**
```python
# api/routes/dashboard.py:67-73
@router.get("/dashboard/", response_class=HTMLResponse)
async def dashboard_overview(
    request: Request,
    key: str = Query("", description="Admin API key in key_id:secret format"),
):
    _auth_admin_via_query(request, key)
```

The admin API key (a sensitive credential) is transmitted as a URL query parameter. URL query parameters are:

1. Stored in browser history
2. Logged in web server access logs and reverse proxy logs (nginx, Apache, AWS ALB, Cloudflare)
3. Transmitted in the `Referer` header to any third-party resources loaded by the page
4. Visible to anyone looking at the screen

**Remediation:** Replace query-parameter auth with a session cookie or HTTP Basic Auth for the dashboard:

```python
# api/routes/dashboard.py — use cookie-based session for browser dashboard
from fastapi.responses import RedirectResponse
import secrets

# POST /dashboard/login endpoint that validates key and sets httpOnly session cookie
@router.post("/dashboard/login")
async def dashboard_login(request: Request, key: str = Form(...)):
    _auth_admin_via_query(request, key)  # reuse existing validator
    session_token = secrets.token_urlsafe(32)
    # Store session_token -> owner_id mapping (use Redis or db)
    response = RedirectResponse(url="/dashboard/", status_code=303)
    response.set_cookie(
        "session", session_token,
        httponly=True, secure=True, samesite="strict",
        max_age=3600,
    )
    return response
```

---

### F-15 — LOW: MCP Bridge Tool Errors Not Logged or Alerted

**File:** `mcp_bridge/server.py:186-189`

**OWASP:** A09:2021 — Security Logging and Monitoring Failures

**Code:**
```python
# mcp_bridge/server.py:186-189
handler = self._handlers.get(name)
if handler is None:
    return [TextContent(
        type="text",
        text=_json_response({"error": f"Unknown tool: {name}"}),
    )]
```

Unknown tool calls are silently returned as error dicts without logging. A malicious actor probing the MCP interface with arbitrary tool names to discover valid endpoints or trigger unexpected behavior will produce no audit trail.

**Remediation:**
```python
# mcp_bridge/server.py
if handler is None:
    logger.warning("Unknown MCP tool requested: %s", name)
    return [TextContent(type="text", text=_json_response({"error": f"Unknown tool: {name}"}))]
```

---

## A03 — Injection: Overall Assessment

The SQL injection posture is **largely sound**. All data-bearing SQL operations use parameterized queries (`?` placeholders) throughout `marketplace/db.py`. Key observations:

- `list_services()` (db.py:278-280): `LIKE` pattern with `%{query}%` — safe because `query` is passed as a parameter, not interpolated.
- `get_usage_stats()` (db.py:359-365): `WHERE {where}` built from conditions list — safe because condition strings are hardcoded, only values are parameterized.
- `admin.py:118-124`: `period_filter` f-string contains `DATE('now', ? || ' days')` — `period_days` is converted to `int` before use, eliminating injection.
- Dynamic SET clauses in update methods — flagged as F-11 (MEDIUM, fragile pattern, not currently injectable).

No raw SQL injection vulnerabilities were found in the current code.

---

## A06 — Vulnerable Components: Dependency Assessment

| Package | Pinned Version | Current Status | Notes |
|---------|----------------|----------------|-------|
| `fastapi` | `>=0.109.0` | 0.135.1 installed | No critical CVEs known |
| `pydantic` | `>=2.5.0` | 2.12.5 installed | No critical CVEs known |
| `httpx` | `>=0.26.0` | 0.28.1 installed | No critical CVEs known |
| `jinja2` | `>=3.1.0` | 3.1.6 installed | No critical CVEs known |
| `pyjwt` | `>=2.8.0` | 2.7.0 installed | **Version 2.7.0 is below the pinned minimum** — possible algorithm confusion if `algorithms` not specified |
| `stripe` | `>=8.0.0` | Not installed | Optional dependency — acceptable |
| `cdp-sdk` | `>=1.30.0` | Not installed | Optional dependency — acceptable |

**PyJWT Note:** PyJWT `<2.8.0` has a known algorithm confusion vulnerability (CVE-2022-29217 affects older versions; ensure the installed version is not vulnerable). Since the framework pins `>=2.8.0` but `2.7.0` is installed, the installed version is below the required minimum. The current codebase does not appear to use JWT validation in the audited source files, but `pyjwt` is listed as a dependency for `kya_jwt` identity type. Upgrade to `>=2.8.0`.

---

## A10 — SSRF: Overall Assessment

**Proxy endpoint** (`marketplace/proxy.py:88-111`): The SSRF guard is present and well-implemented. It resolves the hostname using `socket.getaddrinfo()` and blocks private, loopback, link-local, and reserved IP addresses. The `ACF_INTERNAL_HOSTS` allowlist provides an escape hatch for legitimate internal services.

**Weakness in proxy SSRF guard:** The check is vulnerable to DNS rebinding. The resolution happens before the `httpx.AsyncClient` makes the request. If an attacker controls a DNS server that returns a public IP during the check and a private IP during the actual request, the guard is bypassed. Mitigation: use a custom `httpx` transport that resolves DNS once and locks the connection to the resolved IP. This is an advanced attack but worth noting for a payment infrastructure.

**Webhook delivery** (`marketplace/webhooks.py`): No SSRF guard. See F-03 (CRITICAL).

---

## Positive Security Findings

The following security controls are correctly implemented and should be preserved:

1. **Constant-time comparison** — `secrets.compare_digest()` used in auth validation (`auth.py:92`) prevents timing attacks.
2. **Secret shown only once** — The raw API secret is returned once at creation and never stored in plaintext (`auth.py:63-78`).
3. **Owner-scoped deletes** — All DELETE operations include `owner_id` in the WHERE clause (`db.py:806-813, 718-725, 761-768`).
4. **Role validation at key creation** — Provider/admin key creation requires an existing valid Bearer token (`api/routes/auth.py:47-65`).
5. **Allowlist-based input validation** — Roles, event names, gate types, member roles, identity types, and sort fields all use allowlists.
6. **Webhook HTTPS enforcement** — Webhook URLs must use `https://` (`marketplace/webhooks.py:97-98`).
7. **Per-owner webhook limits** — `MAX_WEBHOOKS_PER_OWNER = 20` prevents resource exhaustion (`marketplace/webhooks.py:31`).
8. **Parameterized queries throughout** — No raw SQL string concatenation of user input.
9. **Proxy SSRF guard** — Resolves and blocks private IPs before forwarding (`marketplace/proxy.py:88-111`).
10. **WAL mode and foreign keys** — SQLite configured for consistency (`db.py:214-215`).

---

## Remediation Priority Matrix

| Priority | Finding | Effort | Risk Reduction |
|----------|---------|--------|----------------|
| P0 — Immediate | F-01 Hardcoded webhook secret | Low | Critical |
| P0 — Immediate | F-02 TOCTOU free-tier race | Medium | Critical |
| P0 — Immediate | F-03 Webhook SSRF | Low | Critical |
| P1 — This Sprint | F-06, F-07 Unauthenticated team endpoints | Low | High |
| P1 — This Sprint | F-09 Webhook header mismatch | Low | High |
| P1 — This Sprint | F-04 Wildcard CORS | Low | High |
| P2 — Next Sprint | F-05 SHA-256 for secrets | Medium | High |
| P2 — Next Sprint | F-08 Security audit logging | Medium | High |
| P2 — Next Sprint | F-10 Security headers | Low | Medium |
| P2 — Next Sprint | F-14 Key in URL query param | Medium | Medium |
| P3 — Backlog | F-11 Dynamic SQL fragility | Low | Medium |
| P3 — Backlog | F-12 No key expiry | Low | Medium |
| P3 — Backlog | F-13 In-memory rate limiter | High | Medium |
| P3 — Backlog | F-15 MCP logging | Low | Low |

---

## Files Reviewed

| File | Lines | Issues Found |
|------|-------|-------------|
| `api/main.py` | 194 | F-04, F-10, F-13 |
| `api/deps.py` | 57 | None |
| `api/routes/auth.py` | 99 | None |
| `api/routes/proxy.py` | 146 | None |
| `api/routes/admin.py` | 244 | None |
| `api/routes/dashboard.py` | 358 | F-14 |
| `api/routes/dashboard_queries.py` | 318 | None |
| `api/routes/discovery.py` | 109 | None |
| `api/routes/health.py` | 23 | None |
| `api/routes/identity.py` | 165 | None |
| `api/routes/reputation.py` | 99 | None |
| `api/routes/services.py` | 169 | None |
| `api/routes/settlement.py` | 113 | None |
| `api/routes/teams.py` | 360 | F-06, F-07 |
| `api/routes/webhooks.py` | 82 | None |
| `marketplace/auth.py` | 123 | F-05, F-12, F-08 |
| `marketplace/db.py` | 851 | F-11 |
| `marketplace/discovery.py` | 211 | None |
| `marketplace/identity.py` | 185 | None |
| `marketplace/models.py` | (not audited — data classes only) | — |
| `marketplace/payment.py` | 150 | None |
| `marketplace/proxy.py` | 305 | F-02 |
| `marketplace/rate_limit.py` | 61 | F-13 |
| `marketplace/registry.py` | (not audited separately) | — |
| `marketplace/reputation.py` | (not audited separately) | — |
| `marketplace/settlement.py` | 265 | None |
| `marketplace/wallet.py` | 235 | None |
| `marketplace/webhooks.py` | 274 | F-03, F-09 |
| `payments/agentkit_provider.py` | 217 | None |
| `payments/base.py` | (base classes) | — |
| `payments/nowpayments_provider.py` | 294 | None |
| `payments/router.py` | 97 | None |
| `payments/stripe_acp.py` | 282 | None |
| `payments/x402_provider.py` | 176 | None |
| `sdk/buyer.py` | 393 | None |
| `sdk/client.py` | 605 | None |
| `mcp_bridge/server.py` | 297 | F-15 |
| `mcp_bridge/discovery.py` | 101 | None |
| `examples/webhook_listener.py` | 88 | F-01, F-09 |
| `requirements.txt` | 24 | PyJWT version mismatch |

---

*Report generated by Security Reviewer Agent — 2026-03-19*
