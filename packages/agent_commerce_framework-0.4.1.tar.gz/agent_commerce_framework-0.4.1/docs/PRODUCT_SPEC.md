# AgenticTrade — Product Specification

> Version 0.6.0 | Revenue: 10% platform commission | Status: Live (agentictrade.io)

## Product Vision

**AgenticTrade is a managed AI Agent service marketplace** where AI Agents can automatically discover, pay for, and consume each other's services on agentictrade.io. The platform includes built-in x402 stablecoin payments, multi-rail fiat payments, service registration/discovery, usage tracking, a reputation system, and automated revenue splitting.

**Business Model**: Platform operation (not selling the framework)
- Core revenue: 10% platform commission per transaction
- Developer acquisition: Free Starter Kit (SDK + templates + 13-chapter guide)
- Platform technology: Internal asset, not for sale

## Market Context

### Competitive Landscape

| Platform | Type | Real Volume | Status |
|----------|------|-------------|--------|
| x402 Bazaar (Coinbase) | Agent marketplace | ~$1.6M/mo organic (after 81% wash filtering) | Operating, early stage |
| ACP (OpenAI+Stripe) | Agent checkout | Built into ChatGPT | Production (fiat) |
| Olas/Mech Marketplace | Agent services | 700K tx/mo | On-chain |
| Nevermined | Infrastructure layer | N/A | SDK only |
| ClawMart | Agent marketplace | Minimal | Hackathon-level |

**Market reality**: 95% narrative, 5% real usage. x402 has a real SDK but organic volume is small (~$1.6M/mo). First-mover opportunity.

**x402 real users**: Firecrawl (web scraping), Browserbase (browser sessions), Freepik (AI images).

### Differentiation

1. **Managed platform**: Developers don't need to build their own marketplace; list services directly on agentictrade.io
2. **Seed product included**: CoinSifter API as the first real, functional paid service
3. **Multi-rail payments**: x402 stablecoins + NOWPayments (300+ crypto) + Stripe ACP + Dodo fiat
4. **Lowest fees**: 10% commission vs RapidAPI 25% / App Store 30%
5. **Free Starter Kit**: SDK + templates + guides, zero barrier to entry

## Target Audience

1. **API Service Providers** — Have AI/Data APIs, want to monetize through Agent traffic (list on our platform)
2. **AI Agent Developers** — Need the ability to discover, pay for, and consume third-party APIs
3. **AI Startup CTOs** — Want their Agents to consume external services (use our SDK)
4. **Enterprise R&D** — Experimenting with Agent-to-Agent commerce (use our platform as test environment)

## Product Components

### 1. Framework Core

```
agent-commerce-framework/
├── marketplace/          # Marketplace engine
│   ├── registry.py       # Service registry
│   ├── discovery.py      # Service search/recommendations
│   ├── payment.py        # x402 + Stripe dual-rail payments
│   ├── metering.py       # Usage tracking + billing
│   └── settlement.py     # Revenue splitting & settlements
├── api/                  # REST API
│   ├── routes/           # FastAPI routes (80+ endpoints)
│   ├── auth.py           # API Key + Agent identity auth
│   └── middleware.py     # Rate limit + logging
├── sdk/                  # Python SDK
│   └── client.py         # Full SDK client (all API operations)
├── templates/            # Service templates
│   ├── ai-api/           # AI API service template
│   ├── data-feed/        # Data service template
│   └── agent-tool/       # Agent tool template
├── docker-compose.yml    # One-click deployment
├── .env.example
└── README.md
```

### 2. Pre-built Service Templates

| Template | Description | Default Pricing |
|----------|-------------|----------------|
| AI API Service | Wrap any AI model as a paid API | $0.005/call |
| Data Feed | Real-time data subscription service | $0.002/call |
| Agent Tool | Tool service consumable by Agents | $0.01/call |
| Batch Processing | Bulk processing task service | $0.05/job |

### 3. CoinSifter API (Seed Product)

CoinSifter's cryptocurrency screening capabilities packaged as an x402-paid API, serving as the marketplace's first real product:

- `GET /api/scan` — Cryptocurrency technical scanner ($0.50/call)
- `GET /api/strategies` — Strategy catalog (free)
- `GET /api/backtest` — Strategy backtesting ($2.00/call)

### 4. Provider Portal (Membership System)

**Dual Authentication Architecture** (Stripe-inspired):
- **Buyers (AI Agents)**: API Key authentication via REST API — no password needed
- **Sellers (Human Providers)**: Email + password registration via web portal

**Portal Features** (agentictrade.io/portal):
- Email registration with password (scrypt hashed, HMAC-signed sessions)
- Email verification flow
- Password reset flow
- Provider Dashboard: service overview, revenue stats, quick actions
- Service Management: view all listed APIs with status, pricing, call counts
- Revenue Analytics: gross revenue, settled, pending, per-service breakdown
- Commission tracking: progressive tiers (Month 1 = 0%, Months 2-6 = 5%, Month 7+ = 10%)
- Account Settings: profile management, API key display, member since info
- Auto-generated API key linked to provider account on registration

**Portal Routes**:
- `/portal/login` — Login page
- `/portal/register` — Registration page
- `/portal/dashboard` — Provider dashboard (protected)
- `/portal/services` — Service management (protected)
- `/portal/analytics` — Revenue analytics (protected)
- `/portal/settings` — Account settings (protected)
- `/portal/verify` — Email verification callback
- `/portal/logout` — Session cleanup

### 5. Admin Dashboard

- Real-time transaction volume/revenue dashboard
- Service quality monitoring (latency, error rate, uptime)
- Revenue split management (automated USDC settlement)
- Provider ranking and buyer engagement metrics
- Trend analytics (daily/weekly/monthly granularity)
- Payment method breakdown

## Technical Architecture

```
┌──────────────────────────────────────────┐
│     Admin Dashboard (Jinja2 + HTMX)      │
│     Provider Portal (Email+Password)     │
└──────────────┬───────────────────────────┘
               │
┌──────────────▼───────────────────────────┐
│          API Gateway (FastAPI)            │
│  ┌──────────┬──────────┬──────────┐      │
│  │  Auth    │  Rate    │  x402    │      │
│  │  Layer   │  Limit   │  Payment │      │
│  └──────────┴──────────┴──────────┘      │
└──────────────┬───────────────────────────┘
               │
┌──────────────▼───────────────────────────┐
│         Marketplace Engine                │
│  ┌──────────┬──────────┬──────────┐      │
│  │ Registry │ Discovery│ Metering │      │
│  └──────────┴──────────┴──────────┘      │
│  ┌──────────┬──────────┬──────────┐      │
│  │ Payment  │Settlement│Reputation│      │
│  │ (x402+   │ (USDC    │ (scoring │      │
│  │  Stripe) │  split)  │  system) │      │
│  └──────────┴──────────┴──────────┘      │
└──────────────┬───────────────────────────┘
               │
┌──────────────▼───────────────────────────┐
│        Service Providers (Agents)         │
│  ┌────────┐ ┌────────┐ ┌────────┐       │
│  │CoinSift│ │Custom  │ │Custom  │       │
│  │er API  │ │Agent 1 │ │Agent 2 │       │
│  └────────┘ └────────┘ └────────┘       │
└──────────────────────────────────────────┘
```

## API Overview (90+ Endpoints)

| Category | Endpoints | Auth |
|----------|-----------|------|
| Auth & Keys | Create key, validate, revoke | Public/API Key |
| Agent Identity | Register, update, search, verify | API Key |
| Services | Register, list, get, update | Provider |
| Discovery | Search, categories, trending, recommendations | Public |
| Proxy | Call any service through marketplace | Buyer |
| Reputation | Agent scores, leaderboard | Public |
| Teams | Create, manage members, routing rules | API Key |
| Webhooks | Subscribe, list, delete | API Key |
| Settlements | Create, list, process | Admin/Provider |
| Provider Portal (API) | Dashboard, analytics, earnings, keys, test, onboarding | Provider |
| Provider Portal (Web) | Login, register, dashboard, services, analytics, settings | Email+Password |
| Admin Analytics | Stats, daily usage, trends, top services, buyers, health | Admin |
| Payments | x402, Stripe ACP, NOWPayments, Dodo | Buyer |

## Revenue Model — Dual Engine

| Revenue Source | Pricing | Description | Status |
|----------------|---------|-------------|--------|
| **MCP Commerce Builder** | $199 (Standard) / $999 (Enterprise) | Code generator for paid MCP servers | Live |
| **Platform Commission** | 10% per call | 10% on every API transaction (industry benchmark: 20-30%) | Live |
| **CoinSifter API** | $0.50-2.00/call | Own seed product on marketplace | Live |
| **Premium Tier** (planned) | $49-199/mo | High-volume discounts, priority ranking, analytics | Roadmap |
| **Enterprise SLA** (planned) | Custom | SLA guarantees, dedicated support | Roadmap |

**Strategy**: Near-term revenue from Builder sales + CoinSifter API (controllable). Long-term growth from platform commission as marketplace matures. Builder purchasers become providers, creating a flywheel.

**Starter Kit = Free** (drives platform adoption)

**Fee Benchmarks**:
- RapidAPI: 25% | Apple: 30% | AWS: 3-5% (infra revenue, different tier) | x402: $0
- Our 10% = 60% cheaper than RapidAPI, with a complete commercial stack

### Seller Retention Program (Three-Stage Rocket)

**Stage 1 — Ignition (Month 0-3):**

| Mechanism | Detail |
|-----------|--------|
| Zero commission (90 days) | New sellers keep 100% for first 90 days |
| First $500 fee-free | Even after 90 days, first $500 in sales = no platform fee |
| 30-day listing challenge | Guided onboarding from Builder purchase to first sale |
| Early Adopter Badge | First 1,000 sellers get permanent badge |

**Stage 2 — Acceleration (Month 3-6):**

| Mechanism | Detail |
|-----------|--------|
| Builder cost recovery | Hit $1K sales → $50 cashback; hit $2K → another $50 (recover 50% of Builder cost) |
| Loyalty commission reduction | Monthly sales >$200 for 3 consecutive months → commission drops to 8% |
| Referral program | Refer a new seller → both get $25 platform credit |
| Monthly leaderboard | Top 10 sellers get featured homepage placement |

**Stage 3 — Orbit (Month 6+):**

| Tenure | Commission | Requirement |
|--------|-----------|------------|
| 0-3 months | **0%** | Automatic |
| 3-6 months | **10%** (standard) | Normal |
| 6-12 months | **8%** | Monthly sales >$200 for 3 months |
| 12+ months | **6%** | Cumulative sales >$10K |
| 24+ months | **5%** | Cumulative sales >$50K + rating ≥ 4.5 |

**Buyer Incentives**:
- New registration: $5 free credit
- First top-up: 25% bonus (deposit $20, get $25)

**Estimated retention impact** (based on Forrester data): Loyalty-based commission reduction → 20% higher seller retention. Expected 6-month retention: 60% (vs 35% without program).

## Development Phases

### Phase 1: Core Framework ✅
- Service Registry + Discovery (Python)
- x402 payment integration (seller middleware)
- API Gateway (FastAPI)
- Authentication (API Key system)
- Docker Compose deployment

### Phase 2: Marketplace + Payments ✅
- Multi-rail payment integration (x402 + Stripe ACP + NOWPayments + Dodo)
- Service proxy with automatic payment
- Webhook notification system
- Team collaboration and routing

### Phase 3: Analytics + Provider Tools ✅
- Provider self-service portal (7 endpoints)
- Platform analytics dashboard (admin)
- Commission engine with Growth Program
- i18n documentation (zh-TW)
- Security audit and hardening
- Python SDK (full coverage)

### Phase 4: Provider Portal + i18n ✅
- Provider Portal membership system (email+password registration, login, dashboard)
- Multi-language website (9 locales: EN, zh-TW, KO, JA, FR, DE, RU, ES, PT)
- Locale-aware email automation (Resend + drip sequences)
- 966 tests passing

### Phase 5: Launch + Growth (Current)
- Provider recruitment (18 candidates identified)
- End-to-end payment flow testing
- Expert Review + QA Pipeline
- Production deployment optimization

## Risk Assessment

| Risk | Severity | Mitigation |
|------|----------|-----------|
| x402 SDK instability | Medium | Dual-rail payments (Stripe fallback) |
| Market too early | Medium | Education + tool bundling + free Starter Kit |
| Rapid competitor emergence | Low | First mover + real seed product (CoinSifter) |
| Technical complexity | Medium | Phased delivery; Phase 1 MVP first |
| Provider acquisition | Medium | Growth Program (0% → 5% → 10%) + referral |

## Current Traction (Verified Data — March 2026)

### Revenue Summary

| Stream | March 2026 | Status |
|--------|-----------|--------|
| Gumroad digital products | $281.90 gross / ~$231 net | Active (17 txns, 13 customers) |
| AgenticTrade platform | $0.50 | First paid API calls |
| **Total** | **$282.40 gross** | **Profitable (OpEx ~$20/mo)** |

### Key Metrics

| Metric | Value |
|--------|-------|
| Products in portfolio | 23+ |
| Products QA-passed ready to list | 8 |
| Gross margin (digital products) | ~82% |
| Customer acquisition cost | ~$0 (organic only) |
| Monthly operating cost | ~$20 |
| Monthly net profit | ~$211 |
| Refund rate | 0% |
| Customer geography | Asia-Pacific 90%, North America 10% |

### Validated Product-Market Fit Signals

- Bundle upsell: 15.4% of customers upgrade from $14.90 to $59 bundle
- Repeat geography: strong Taiwan/Chinese-speaking market demand
- Blog-to-purchase funnel: 10% of traffic converts via judyailab.com referral
- Zero refunds/chargebacks across all transactions

## Success Metrics

- **Developer Adoption**: Starter Kit downloads ≥ 100 (first month)
- **Service Providers**: ≥ 10 third-party services listed (Q2 2026)
- **Transaction Volume**: ≥ 1,000 API calls/day (Q3 2026)
- **Platform Revenue**: ≥ $4,500/month (10 services x 1K calls/day x $1.50 avg x 10%)
- **CoinSifter API**: ≥ 100 real paid calls (demand validation)
- **Test Coverage**: ≥ 690 tests passing (currently 966)

## Python SDK

Full Python SDK available for all marketplace operations:

```python
from sdk.client import ACFClient

# Initialize with API key
client = ACFClient(
    base_url="https://agentictrade.io",
    api_key="your_key_id:your_secret"
)

# Discover services
services = client.search(query="crypto scanner", category="data")

# Call a service (payment handled automatically)
result = client.call_service("coinsifter-scanner", path="/scan")

# Provider operations
dashboard = client.provider_dashboard()
earnings = client.provider_earnings()
onboarding = client.provider_onboarding()
```
