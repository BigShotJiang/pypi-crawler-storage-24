---
title: "AgenticTrade Provider Onboarding Guide"
description: "The complete developer guide to listing, configuring, and monetizing your AI API on AgenticTrade — from signup to first automated payment."
date: 2026-03-21
tags: ["agentictrade", "api", "developers", "onboarding", "provider"]
categories: ["Developer Guide"]
---

# AgenticTrade Provider Onboarding Guide

Welcome to AgenticTrade. This guide walks you through the entire provider journey — from creating your account to receiving your first automated micro-payment from an AI agent. Estimated time: **20–30 minutes**. No prior blockchain experience required.

## What You're Building Toward

AgenticTrade is a marketplace where AI agents discover, authenticate, and pay for APIs automatically. As a provider, you list your API once. From that point, any compatible agent can find it, call it, and pay for it — without you sending a single invoice or chasing a single payment.

The platform sits between your API and the agent. It handles discovery (via MCP Tool Descriptors), billing (micro-denomination settlements in USDC/USDT or fiat), authentication (proxy keys), and reputation (transaction history + ratings).

## Step 1: Create Your Provider Account

Start at [agentictrade.io](https://agentictrade.io) and sign up as a provider. You'll need:

- A valid email address
- A crypto wallet (MetaMask, Coinbase Wallet, or any EVM-compatible wallet) for receiving settlements
- Basic business information (name, website, category)

Once registered, you'll receive a **Vendor API Key** from your dashboard. This key authenticates all your provider-side API calls. Keep it secret — it has permissions to create proxy keys, publish descriptors, and manage your service listing.

```
# Your Vendor API Key looks like:
atx_vendor_7f8a9b2c3d4e5f6...
```

Store it as an environment variable:

```bash
export AGENTICTRADE_VENDOR_KEY="atx_vendor_your_key_here"
```

## Step 2: Register Your API Service

Before anything else, the platform needs to know what you're selling. You register your API by calling the service registry endpoint:

```bash
curl -X POST https://api.agentictrade.io/v1/services \
  -H "Authorization: Bearer $AGENTICTRADE_VENDOR_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Your API Name",
    "slug": "your-api-slug",
    "description": "What your API does and who it's for.",
    "base_url": "https://api.yourdomain.com/v1",
    "protocol": "rest",
    "auth_type": "bearer",
    "category": ["data", "ml", "utility"],
    "pricing_model": "per_call",
    "price_usd": 0.001,
    "mcp_enabled": true,
    "tags": ["relevant", "keywords"]
  }'
```

The response gives you a `service_id` and confirms your commission tier. New providers automatically receive **Month 1 at 0% commission** — you keep 100% of revenue with no conditions.

### Key Registration Fields

| Field | Notes |
|-------|-------|
| `slug` | Unique identifier used in URLs and API calls. Set once, cannot change. |
| `base_url` | Your actual API endpoint. AgenticTrade proxies calls through here. |
| `pricing_model` | `per_call`, `per_token`, `subscription`, or `tiered`. Most providers start with `per_call`. |
| `price_usd` | Per-call price in USD. You can set per-tool prices in the MCP descriptor for more granularity. |
| `mcp_enabled` | Set to `true` to enable MCP Tool Descriptor publishing. |

## Step 3: Issue a Proxy API Key

Never give agents your raw API key. Instead, create a **proxy key** through AgenticTrade. Proxy keys route through the platform's billing layer, which meters usage, enforces rate limits, and charges the calling agent's wallet — all without touching your existing authentication system.

```bash
curl -X POST https://api.agentictrade.io/v1/services/YOUR_SERVICE_ID/keys \
  -H "Authorization: Bearer $AGENTICTRADE_VENDOR_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Production Agent Key",
    "scope": ["read", "execute"],
    "rate_limit": 1000,
    "rate_limit_window": "minute"
  }'
```

The response contains your `proxy_key`. Give this to agents — it's the only credential they'll need. You can issue multiple proxy keys for different agents or use cases, and revoke them individually without affecting others.

### Proxy Key Structure

```
atx_pk_prod_K8mNpQrStUvWxYz1234567890
 ^^^^ ^^ ^^^^^^
 │    │   └─ Unique key identifier
 │    └─ Environment (prod/staging)
 └─ Prefix (indicates AgenticTrade proxy key)
```

## Step 4: Publish Your MCP Tool Descriptor

The MCP Tool Descriptor is what makes your API **discoverable by AI agents**. It's a JSON schema that describes every tool your API exposes — its name, parameters, return type, and per-call cost. When you publish it, it enters the AgenticTrade MCP registry.

Agents built on MCP-compatible frameworks (LangChain, CrewAI, AutoGPT, and others) can auto-discover your tools, parse the schema, and start calling them without any manual integration on your end.

```bash
curl -X PUT https://api.agentictrade.io/v1/mcp/YOUR_SERVICE_ID/descriptor \
  -H "Authorization: Bearer $AGENTICTRADE_VENDOR_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "schema_version": "1.0",
    "name": "your_api_slug",
    "description": "What capability your API provides to agents.",
    "category": "data",
    "tools": [
      {
        "name": "tool_name",
        "description": "What this specific tool does.",
        "input_schema": {
          "type": "object",
          "properties": {
            "param_name": {
              "type": "string",
              "description": "What this parameter controls."
            }
          },
          "required": ["param_name"]
        },
        "pricing": {
          "cost_usd": 0.001,
          "unit": "per_call"
        }
      }
    ],
    "auth": {
      "type": "bearer",
      "proxy_key_hint": "Use your AgenticTrade proxy key as the Bearer token."
    },
    "rate_limits": {
      "requests_per_minute": 1000
    }
  }'
```

### Descriptor Best Practices

- **Be specific in descriptions.** Agents use tool descriptions to decide whether to call your API. Vague descriptions get filtered out by quality-gated discovery.
- **Set per-tool pricing.** If your API has multiple endpoints with different compute costs, price each tool individually rather than averaging.
- **Use real examples.** Add `examples` arrays to parameters when possible — agents learn better from concrete input/output pairs.
- **Publish incrementally.** Start with your 2–3 most useful tools. You can add more later without changing your service registration.

## Step 5: Test the Full Call Flow

Before going live, verify the complete flow end-to-end. Use the AgenticTrade dashboard to simulate an agent call:

```bash
# 1. Agent fetches your descriptor
curl https://api.agentictrade.io/v1/mcp/your-api-slug/descriptor.json

# 2. Agent calls through the proxy (uses an agent wallet key, not your vendor key)
curl -X POST https://api.agentictrade.io/v1/call \
  -H "Authorization: Bearer AGENT_WALLET_KEY" \
  -H "X-Service: your-api-slug" \
  -H "Content-Type: application/json" \
  -d '{
    "tool": "tool_name",
    "params": { "param_name": "test_value" }
  }'
```

Your API receives a standard call at `base_url`. The proxy layer adds metering and billing transparently. Check your provider dashboard — you should see the call logged with its cost within 15 minutes.

## Step 6: Understand How You Get Paid

AgenticTrade settles revenue to your connected wallet on a **T+1 rolling basis** — meaning yesterday's call revenue lands in your wallet today. Settlement runs automatically; no invoice generation required.

| Phase | Months | Commission | You Receive |
|-------|--------|------------|-------------|
| Launch Month | Month 1 | **0%** | 100% |
| Growth Phase | Months 2–6 | **5%** | 95% |
| Standard | Month 7+ | **10%** | 90% |

You can receive settlements in USDC, USDT, or fiat (via Stripe integration). Minimum payout threshold is $10 equivalent. Your dashboard shows per-agent call breakdowns, revenue trends, and reputation scores.

## Step 7: Monitor and Optimize

Once live, your provider dashboard is your command center:

- **Call logs**: Every agent call, timestamp, cost, and agent wallet ID
- **Revenue dashboard**: Daily/weekly/monthly revenue with trend charts
- **Reputation score**: Automatically calculated from latency, reliability, and response quality metrics
- **Rate limit monitoring**: See which agents are hitting limits and adjust thresholds

Higher reputation scores improve discovery ranking. Maintain low latency and high reliability to maximize your discoverability in quality-gated agent frameworks.

## Commission Comparison

Here's why this matters financially. At typical AI API margins:

| Monthly Revenue | RapidAPI (25%) | AgenticTrade (10%) | Annual Savings |
|-----------------|---------------|--------------------|-----------------|
| $5,000 | $15,000/yr | $6,000/yr | **$9,000** |
| $20,000 | $60,000/yr | $24,000/yr | **$36,000** |
| $50,000 | $150,000/yr | $60,000/yr | **$90,000** |

The first six months are even better: 0% then 5% commission. There's no reason not to list.

## Ready to Go Live?

Sign up at [agentictrade.io](https://agentictrade.io) — free to list, first month at 0% commission. Your MCP descriptor can be live in under 10 minutes. Then let the agents find you.

---

*Questions? Check the [API documentation](https://docs.agentictrade.io) or email support@agentictrade.io.*
