---
title: "AgenticTrade 제공자 온보딩 가이드"
description: "AgenticTrade에서 AI API를 등록, 구성, 수익화하는 완전한 개발자 가이드 — 가입부터 첫 자동 결제까지."
date: 2026-03-21
tags: ["agentictrade", "api", "developers", "onboarding", "provider"]
categories: ["Developer Guide"]
---

# AgenticTrade 제공자 온보딩 가이드

AgenticTrade에 오신 것을 환영합니다. 이 가이드는 계정 생성부터 AI Agent로부터 첫 자동 마이크로 페이먼트를 수령하기까지의 전체 제공자 여정을 안내합니다. 예상 소요 시간: **20~30분**. 블록체인 경험은 필요하지 않습니다.

## 목표

AgenticTrade는 AI Agent가 API를 자동으로 검색, 인증, 결제하는 마켓플레이스입니다. 제공자로서 API를 한 번 등록하면, 호환되는 모든 Agent가 이를 찾아 호출하고 결제할 수 있습니다 — 인보이스를 보내거나 결제를 추심할 필요가 없습니다.

플랫폼은 API와 Agent 사이에 위치합니다. 검색 (MCP Tool Descriptor), 과금 (USDC/USDT 또는 법정화폐 마이크로 정산), 인증 (프록시 키), 평판 (거래 이력 + 평점)을 처리합니다.

## 1단계: 제공자 계정 생성

[agentictrade.io](https://agentictrade.io)에서 제공자로 가입하세요. 필요한 것:

- 유효한 이메일 주소
- 암호화폐 지갑 (MetaMask, Coinbase Wallet 또는 모든 EVM 호환 지갑) — 정산금 수령용
- 기본 비즈니스 정보 (이름, 웹사이트, 카테고리)

등록이 완료되면 대시보드에서 **Vendor API Key**를 받게 됩니다. 이 키는 모든 제공자 측 API 호출을 인증합니다. 비밀로 유지하세요 — 프록시 키 생성, 디스크립터 게시, 서비스 리스팅 관리 권한이 있습니다.

```
# Vendor API Key 형식:
atx_vendor_7f8a9b2c3d4e5f6...
```

환경 변수로 저장하세요:

```bash
export AGENTICTRADE_VENDOR_KEY="atx_vendor_your_key_here"
```

## 2단계: API 서비스 등록

먼저 플랫폼에 판매할 서비스를 알려야 합니다. 서비스 레지스트리 엔드포인트를 호출하여 API를 등록합니다:

```bash
curl -X POST https://api.agentictrade.io/v1/services \
  -H "Authorization: Bearer $AGENTICTRADE_VENDOR_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Your API Name",
    "slug": "your-api-slug",
    "description": "API의 기능과 대상 사용자 설명.",
    "base_url": "https://api.yourdomain.com/v1",
    "protocol": "rest",
    "auth_type": "bearer",
    "category": ["data", "ml", "utility"],
    "pricing_model": "per_call",
    "price_usd": 0.001,
    "mcp_enabled": true,
    "tags": ["relevant", "keywords"]
  }'
```

응답에서 `service_id`와 수수료 등급 확인을 받게 됩니다. 신규 제공자는 자동으로 **1개월차 0% 수수료**가 적용됩니다 — 조건 없이 수익의 100%를 가져갑니다.

### 주요 등록 필드

| 필드 | 설명 |
|------|------|
| `slug` | URL 및 API 호출에 사용되는 고유 식별자. 한 번 설정하면 변경 불가. |
| `base_url` | 실제 API 엔드포인트. AgenticTrade가 이 URL을 통해 호출을 프록시합니다. |
| `pricing_model` | `per_call`, `per_token`, `subscription` 또는 `tiered`. 대부분의 제공자는 `per_call`로 시작합니다. |
| `price_usd` | USD 기준 호출당 가격. MCP 디스크립터에서 도구별 가격을 더 세밀하게 설정할 수 있습니다. |
| `mcp_enabled` | `true`로 설정하면 MCP Tool Descriptor 게시가 활성화됩니다. |

## 3단계: 프록시 API 키 발급

Agent에게 원본 API 키를 절대 제공하지 마세요. 대신 AgenticTrade를 통해 **프록시 키**를 생성하세요. 프록시 키는 플랫폼의 과금 레이어를 통해 라우팅되어, 기존 인증 시스템을 건드리지 않고 사용량 측정, 속도 제한 적용, 호출 Agent 지갑 청구를 처리합니다.

```bash
curl -X POST https://api.agentictrade.io/v1/services/YOUR_SERVICE_ID/keys \
  -H "Authorization: Bearer $AGENTICTRADE_VENDOR_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Production Agent Key",
    "scope": ["read", "execute"],
    "rate_limit": 1000,
    "rate_limit_window": "minute"
  }'
```

응답에 `proxy_key`가 포함됩니다. 이것을 Agent에게 제공하세요 — 필요한 유일한 자격 증명입니다. 다양한 Agent나 용도별로 여러 프록시 키를 발급하고, 다른 키에 영향 없이 개별적으로 폐기할 수 있습니다.

### 프록시 키 구조

```
atx_pk_prod_K8mNpQrStUvWxYz1234567890
 ^^^^ ^^ ^^^^^^
 │    │   └─ 고유 키 식별자
 │    └─ 환경 (prod/staging)
 └─ 접두사 (AgenticTrade 프록시 키임을 표시)
```

## 4단계: MCP Tool Descriptor 게시

MCP Tool Descriptor는 API를 **AI Agent가 검색 가능하게** 만드는 요소입니다. API가 제공하는 모든 도구 — 이름, 파라미터, 반환 타입, 호출당 비용을 설명하는 JSON 스키마입니다. 게시하면 AgenticTrade MCP 레지스트리에 등록됩니다.

MCP 호환 프레임워크 (LangChain, CrewAI, AutoGPT 등)로 구축된 Agent는 도구를 자동으로 검색하고, 스키마를 파싱하여, 수동 통합 없이 호출을 시작할 수 있습니다.

```bash
curl -X PUT https://api.agentictrade.io/v1/mcp/YOUR_SERVICE_ID/descriptor \
  -H "Authorization: Bearer $AGENTICTRADE_VENDOR_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "schema_version": "1.0",
    "name": "your_api_slug",
    "description": "API가 Agent에게 제공하는 기능 설명.",
    "category": "data",
    "tools": [
      {
        "name": "tool_name",
        "description": "이 특정 도구의 기능 설명.",
        "input_schema": {
          "type": "object",
          "properties": {
            "param_name": {
              "type": "string",
              "description": "이 파라미터가 제어하는 내용."
            }
          },
          "required": ["param_name"]
        },
        "pricing": {
          "cost_usd": 0.001,
          "unit": "per_call"
        }
      }
    ],
    "auth": {
      "type": "bearer",
      "proxy_key_hint": "AgenticTrade 프록시 키를 Bearer 토큰으로 사용하세요."
    },
    "rate_limits": {
      "requests_per_minute": 1000
    }
  }'
```

### Descriptor 작성 모범 사례

- **설명을 구체적으로 작성하세요.** Agent는 도구 설명을 기반으로 API 호출 여부를 결정합니다. 모호한 설명은 품질 게이트 검색에서 필터링됩니다.
- **도구별 가격을 설정하세요.** API에 컴퓨팅 비용이 다른 여러 엔드포인트가 있다면, 평균이 아닌 각 도구의 개별 가격을 설정하세요.
- **실제 예시를 사용하세요.** 가능한 경우 파라미터에 `examples` 배열을 추가하세요 — Agent는 구체적인 입출력 쌍에서 더 잘 학습합니다.
- **점진적으로 게시하세요.** 가장 유용한 2~3개 도구부터 시작하세요. 서비스 등록을 변경하지 않고도 나중에 추가할 수 있습니다.

## 5단계: 전체 호출 플로우 테스트

라이브 전에 엔드투엔드 전체 플로우를 검증하세요. AgenticTrade 대시보드를 사용하여 Agent 호출을 시뮬레이션합니다:

```bash
# 1. Agent가 디스크립터를 가져옴
curl https://api.agentictrade.io/v1/mcp/your-api-slug/descriptor.json

# 2. Agent가 프록시를 통해 호출 (vendor key가 아닌 agent wallet key 사용)
curl -X POST https://api.agentictrade.io/v1/call \
  -H "Authorization: Bearer AGENT_WALLET_KEY" \
  -H "X-Service: your-api-slug" \
  -H "Content-Type: application/json" \
  -d '{
    "tool": "tool_name",
    "params": { "param_name": "test_value" }
  }'
```

API는 `base_url`에서 표준 호출을 수신합니다. 프록시 레이어가 투명하게 측정 및 과금을 추가합니다. 제공자 대시보드를 확인하세요 — 15분 이내에 비용과 함께 호출 로그가 표시될 것입니다.

## 6단계: 결제 수령 방법 이해

AgenticTrade는 **T+1 롤링 기준**으로 수익을 정산합니다 — 어제의 호출 수익이 오늘 지갑에 입금됩니다. 정산은 자동으로 실행됩니다; 인보이스 생성이 필요 없습니다.

| 단계 | 기간 | 수수료 | 수령액 |
|------|------|--------|--------|
| 런칭 월 | 1개월차 | **0%** | 100% |
| 성장 단계 | 2~6개월차 | **5%** | 95% |
| Standard | 7개월차+ | **10%** | 90% |

USDC, USDT 또는 법정화폐 (Stripe 통합)로 정산을 수령할 수 있습니다. 최소 지급 기준은 $10 상당입니다. 대시보드에서 Agent별 호출 내역, 수익 트렌드, 평판 점수를 확인할 수 있습니다.

## 7단계: 모니터링 및 최적화

라이브 이후 제공자 대시보드가 커맨드 센터입니다:

- **호출 로그**: 모든 Agent 호출, 타임스탬프, 비용, Agent 지갑 ID
- **수익 대시보드**: 일간/주간/월간 수익 및 트렌드 차트
- **평판 점수**: 지연시간, 안정성, 응답 품질 지표에서 자동 산출
- **속도 제한 모니터링**: 어떤 Agent가 제한에 도달하는지 확인하고 임계값 조정

높은 평판 점수는 검색 순위를 향상시킵니다. 낮은 지연시간과 높은 안정성을 유지하여 품질 게이트 Agent 프레임워크에서의 검색 가능성을 극대화하세요.

## 수수료 비교

재정적으로 왜 이것이 중요한지 살펴보세요. 일반적인 AI API 마진 기준:

| 월 매출 | RapidAPI (25%) | AgenticTrade (10%) | 연간 절감액 |
|---------|---------------|--------------------|------------|
| $5,000 | $15,000/년 | $6,000/년 | **$9,000** |
| $20,000 | $60,000/년 | $24,000/년 | **$36,000** |
| $50,000 | $150,000/년 | $60,000/년 | **$90,000** |

첫 6개월은 더 유리합니다: 0% 이후 5% 수수료. 등록하지 않을 이유가 없습니다.

## 바로 시작하기

[agentictrade.io](https://agentictrade.io)에서 가입하세요 — 등록 무료, 첫 달 0% 수수료. MCP 디스크립터를 10분 이내에 라이브할 수 있습니다. 그런 다음 Agent가 찾아오도록 하세요.

---

*문의사항이 있으시면 [API 문서](https://docs.agentictrade.io)를 확인하거나 support@agentictrade.io로 이메일을 보내주세요.*
