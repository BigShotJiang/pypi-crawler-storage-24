"""
AgentKit Payment Provider — direct agent-to-agent USDC transfers.

Uses CDP SDK v2 (EvmServerAccount) for instant USDC settlements
without x402 middleware overhead. Best for direct agent-to-agent payments
where both parties are registered in the marketplace.

Requires: pip install cdp-sdk>=1.30
"""
from __future__ import annotations

import logging
import uuid
from decimal import Decimal
from typing import Optional

from .base import (
    PaymentProvider,
    PaymentProviderError,
    PaymentResult,
    PaymentStatus,
)

logger = logging.getLogger("payments.agentkit")


class AgentKitProvider(PaymentProvider):
    """
    PaymentProvider for direct agent-to-agent USDC transfers via CDP SDK.

    Unlike x402 (middleware-driven) or Stripe ACP (fiat checkout),
    this provider executes immediate on-chain USDC transfers from the
    marketplace settlement wallet to a target address.

    Use cases:
    - Direct agent-to-agent payments within the marketplace
    - Bulk settlement payouts
    - Programmatic transfers from agent wallets
    """

    _SUPPORTED_CURRENCIES = ["USDC"]

    def __init__(self, wallet_manager: Optional["WalletManager"] = None):
        """
        Initialize with a WalletManager instance.

        Args:
            wallet_manager: WalletManager from marketplace.wallet.
                           If None, provider operates in dry-run mode.
        """
        self._wallet = wallet_manager
        if wallet_manager is None or not wallet_manager.is_ready:
            logger.warning("AgentKit provider initialized without active wallet")

    @property
    def provider_name(self) -> str:
        return "agentkit"

    @property
    def supported_currencies(self) -> list[str]:
        return list(self._SUPPORTED_CURRENCIES)

    @property
    def wallet_address(self) -> Optional[str]:
        """Get the settlement wallet address."""
        if self._wallet is None:
            return None
        return self._wallet.address

    async def create_payment(
        self,
        amount: Decimal,
        currency: str,
        metadata: dict,
    ) -> PaymentResult:
        """
        Create and execute a direct USDC transfer.

        Unlike x402 which creates a payment intent, this immediately
        executes the on-chain transfer. The returned PaymentResult
        will have status=completed if the transfer succeeds.

        Args:
            amount: USDC amount to transfer.
            currency: Must be "USDC".
            metadata: Must include "to_address" (recipient wallet).
                      Optional: "agent_id", "service_id", "description".

        Returns:
            PaymentResult with tx hash in metadata on success.

        Raises:
            PaymentProviderError: On validation or transfer failure.
        """
        currency_upper = currency.upper()
        if currency_upper not in self._SUPPORTED_CURRENCIES:
            raise PaymentProviderError(
                f"AgentKit only supports {self._SUPPORTED_CURRENCIES}, got '{currency}'"
            )

        if amount <= 0:
            raise PaymentProviderError(f"Amount must be positive, got {amount}")

        to_address = metadata.get("to_address")
        if not to_address:
            raise PaymentProviderError("metadata must include 'to_address'")

        if self._wallet is None or not self._wallet.is_ready:
            raise PaymentProviderError(
                "CDP wallet not configured. Set CDP_API_KEY_ID and CDP_API_KEY_SECRET."
            )

        payment_id = f"agentkit_{uuid.uuid4().hex[:16]}"

        tx_hash = await self._wallet.transfer_usdc(
            to_address=to_address,
            amount=amount,
        )

        if tx_hash:
            return PaymentResult(
                payment_id=payment_id,
                status=PaymentStatus.completed,
                amount=amount,
                currency=currency_upper,
                checkout_url=None,
                metadata={
                    "tx_hash": tx_hash,
                    "to_address": to_address,
                    "network": self._wallet.config.cdp_network,
                    "from_address": self._wallet.address or "",
                    **{k: v for k, v in metadata.items() if k != "to_address"},
                },
            )

        return PaymentResult(
            payment_id=payment_id,
            status=PaymentStatus.failed,
            amount=amount,
            currency=currency_upper,
            checkout_url=None,
            metadata={
                "to_address": to_address,
                "reason": "USDC transfer failed — check logs",
                **{k: v for k, v in metadata.items() if k != "to_address"},
            },
        )

    async def verify_payment(self, payment_id: str) -> PaymentStatus:
        """
        Verify an AgentKit payment.

        AgentKit payments are instant (completed or failed at creation time).
        This method returns completed for any valid payment ID, since
        the transfer was already executed during create_payment.

        Args:
            payment_id: The agentkit_ prefixed payment ID.

        Returns:
            PaymentStatus.completed for executed transfers.

        Raises:
            PaymentProviderError: If payment_id is empty.
        """
        if not payment_id:
            raise PaymentProviderError("payment_id is required")

        if not payment_id.startswith("agentkit_"):
            raise PaymentProviderError(
                f"Invalid AgentKit payment ID format: {payment_id}"
            )

        # AgentKit transfers are synchronous — if we have a payment_id,
        # the transfer was already attempted during create_payment.
        return PaymentStatus.completed

    async def get_payment(self, payment_id: str) -> dict:
        """
        Get AgentKit payment details.

        Args:
            payment_id: The agentkit_ prefixed payment ID.

        Returns:
            Dict with payment and wallet details.

        Raises:
            PaymentProviderError: If payment_id is empty.
        """
        if not payment_id:
            raise PaymentProviderError("payment_id is required")

        return {
            "payment_id": payment_id,
            "provider": self.provider_name,
            "wallet_address": self._wallet.address if self._wallet else None,
            "network": self._wallet.config.cdp_network if self._wallet else None,
            "wallet_ready": self._wallet.is_ready if self._wallet else False,
        }

    async def create_agent_wallet(self, agent_id: str) -> Optional[str]:
        """
        Create a wallet for a new agent.

        Convenience method that delegates to WalletManager.

        Args:
            agent_id: Unique identifier for the agent.

        Returns:
            Wallet address string, or None if CDP is not configured.
        """
        if self._wallet is None:
            return None
        return await self._wallet.create_agent_wallet(agent_id)
