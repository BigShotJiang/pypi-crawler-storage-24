"""Pipeline orchestration for PolicyFoundry."""
