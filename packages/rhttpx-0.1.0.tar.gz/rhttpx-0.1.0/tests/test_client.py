import pytest
import respx
import httpx
from rhttpx import (
    RetryingClient,
    AsyncRetryingClient,
    get,
    close,
    aget,
    aclose,
)

TEST_URL = "https://api.example.com/data"

@respx.mock
def test_sync_success():
    """Test that a successful synchronous request returns immediately without retries."""
    respx.get(TEST_URL).respond(status_code=200, json={"status": "ok"})

    client = RetryingClient(max_attempts=3, initial_delay=0.01)
    response = client.get(TEST_URL)

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
    assert respx.calls.call_count == 1

@respx.mock
def test_sync_retry_on_5xx_then_success():
    """Test that the client retries on 5xx errors and succeeds when a 200 is returned."""
    route = respx.get(TEST_URL).mock(side_effect=[
        httpx.Response(500),
        httpx.Response(503),
        httpx.Response(200, json={"success": True})
    ])

    client = RetryingClient(max_attempts=4, initial_delay=0.01)
    response = client.get(TEST_URL)

    assert response.status_code == 200
    assert route.call_count == 3

@pytest.mark.asyncio
@respx.mock
async def test_async_retry_on_network_error():
    """Test that the async client retries on network-level exceptions."""
    route = respx.get(TEST_URL).mock(side_effect=[
        httpx.NetworkError("Connection reset"),
        httpx.ReadTimeout("Read timed out"),
        httpx.Response(200)
    ])

    async with AsyncRetryingClient(max_attempts=3, initial_delay=0.01) as client:
        response = await client.get(TEST_URL)

    assert response.status_code == 200
    assert route.call_count == 3

@respx.mock
def test_sync_exceed_max_attempts():
    """Test that httpx.HTTPStatusError is raised after max_attempts is reached."""
    route = respx.get(TEST_URL).respond(status_code=502)

    client = RetryingClient(max_attempts=3, initial_delay=0.01)

    with pytest.raises(httpx.HTTPStatusError) as exc_info:
        client.get(TEST_URL)

    assert exc_info.value.response.status_code == 502
    assert route.call_count == 3

@respx.mock
def test_global_sync_client_lifecycle():
    """Test the global sync client initialization and explicit closure."""
    route = respx.get(TEST_URL).respond(status_code=200)

    # First call initializes the client
    response1 = get(TEST_URL, max_attempts=2, initial_delay=0.01)
    assert response1.status_code == 200

    close()

    # Second call should seamlessly create a new client
    response2 = get(TEST_URL, max_attempts=2, initial_delay=0.01)
    assert response2.status_code == 200

    close()
    assert route.call_count == 2

@pytest.mark.asyncio
@respx.mock
async def test_global_async_client_lifecycle():
    """Test the global async client initialization and explicit aclosure."""
    route = respx.get(TEST_URL).respond(status_code=200)

    response1 = await aget(TEST_URL, max_attempts=2, initial_delay=0.01)
    assert response1.status_code == 200

    await aclose()

    response2 = await aget(TEST_URL, max_attempts=2, initial_delay=0.01)
    assert response2.status_code == 200

    await aclose()
    assert route.call_count == 2
