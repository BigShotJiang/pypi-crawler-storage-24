"""
rhttpx = httpx + tenacity

Now timeouts and 5xx are not an issue anymore, the module will retry the request for you
"""

import httpx
import asyncio
import threading
import logging
import atexit
from tenacity import (
    Retrying,
    AsyncRetrying,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception,
    before_sleep_log,
)
from typing import Any, Optional

# Default configuration for retries and timeouts
DEFAULT_MAX_ATTEMPTS = 10
DEFAULT_BACKOFF_FACTOR = 1.5
DEFAULT_INITIAL_DELAY = 1.0
DEFAULT_TIMEOUT = 10.0

# Module-level logger configuration
logger = logging.getLogger('rhttpx')
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
logger.setLevel(logging.WARNING)

def _is_retryable_exception(exc: BaseException) -> bool:
    """Evaluates if the exception should trigger a retry attempt."""
    if isinstance(exc, (httpx.TimeoutException, httpx.NetworkError)):
        return True
    if isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code >= 500:
        return True
    return False

class RetryingClient:
    """
    Synchronous HTTP client wrapper for httpx.Client with automatic retries.
    Uses composition to manage internal httpx.Client instance.
    """
    def __init__(self, **kwargs: Any) -> None:
        self.max_attempts = kwargs.pop("max_attempts", DEFAULT_MAX_ATTEMPTS)
        self.backoff_factor = kwargs.pop("backoff_factor", DEFAULT_BACKOFF_FACTOR)
        self.initial_delay = kwargs.pop("initial_delay", DEFAULT_INITIAL_DELAY)

        if "timeout" not in kwargs:
            kwargs["timeout"] = DEFAULT_TIMEOUT

        self.client = httpx.Client(**kwargs)
        logger.debug("Synchronous RetryingClient initialized.")

    def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """Executes a request with retry logic configured dynamically."""
        m_attempts = kwargs.pop("max_attempts", self.max_attempts)
        b_factor = kwargs.pop("backoff_factor", self.backoff_factor)
        i_delay = kwargs.pop("initial_delay", self.initial_delay)

        retryer = Retrying(
            stop=stop_after_attempt(m_attempts),
            wait=wait_exponential(multiplier=i_delay, exp_base=b_factor),
            retry=retry_if_exception(_is_retryable_exception),
            before_sleep=before_sleep_log(logger, logging.INFO),
            reraise=True
        )

        for attempt in retryer:
            with attempt:
                response = self.client.request(method, url, **kwargs)
                if response.status_code >= 500:
                    response.raise_for_status()
                return response

        # Fallback to satisfy type checkers; Retrying with reraise=True will raise before this.
        raise RuntimeError("Retry loop exited unexpectedly")

    def get(self, url: str, **kwargs: Any) -> httpx.Response: return self.request("GET", url, **kwargs)
    def post(self, url: str, **kwargs: Any) -> httpx.Response: return self.request("POST", url, **kwargs)
    def put(self, url: str, **kwargs: Any) -> httpx.Response: return self.request("PUT", url, **kwargs)
    def delete(self, url: str, **kwargs: Any) -> httpx.Response: return self.request("DELETE", url, **kwargs)
    def patch(self, url: str, **kwargs: Any) -> httpx.Response: return self.request("PATCH", url, **kwargs)

    def __enter__(self) -> 'RetryingClient':
        self.client.__enter__()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.client.__exit__(exc_type, exc_val, exc_tb)

    def close(self) -> None:
        self.client.close()
        logger.debug("Synchronous RetryingClient closed.")


class AsyncRetryingClient:
    """
    Asynchronous HTTP client wrapper for httpx.AsyncClient with automatic retries.
    """
    def __init__(self, **kwargs: Any) -> None:
        self.max_attempts = kwargs.pop("max_attempts", DEFAULT_MAX_ATTEMPTS)
        self.backoff_factor = kwargs.pop("backoff_factor", DEFAULT_BACKOFF_FACTOR)
        self.initial_delay = kwargs.pop("initial_delay", DEFAULT_INITIAL_DELAY)

        if "timeout" not in kwargs:
            kwargs["timeout"] = DEFAULT_TIMEOUT

        self.client = httpx.AsyncClient(**kwargs)
        logger.debug("Asynchronous RetryingClient initialized.")

    async def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """Executes an async request with retry logic configured dynamically."""
        m_attempts = kwargs.pop("max_attempts", self.max_attempts)
        b_factor = kwargs.pop("backoff_factor", self.backoff_factor)
        i_delay = kwargs.pop("initial_delay", self.initial_delay)

        retryer = AsyncRetrying(
            stop=stop_after_attempt(m_attempts),
            wait=wait_exponential(multiplier=i_delay, exp_base=b_factor),
            retry=retry_if_exception(_is_retryable_exception),
            before_sleep=before_sleep_log(logger, logging.INFO),
            reraise=True
        )

        async for attempt in retryer:
            with attempt:
                response = await self.client.request(method, url, **kwargs)
                if response.status_code >= 500:
                    response.raise_for_status()
                return response

        raise RuntimeError("Async retry loop exited unexpectedly")

    async def get(self, url: str, **kwargs: Any) -> httpx.Response: return await self.request("GET", url, **kwargs)
    async def post(self, url: str, **kwargs: Any) -> httpx.Response: return await self.request("POST", url, **kwargs)
    async def put(self, url: str, **kwargs: Any) -> httpx.Response: return await self.request("PUT", url, **kwargs)
    async def delete(self, url: str, **kwargs: Any) -> httpx.Response: return await self.request("DELETE", url, **kwargs)
    async def patch(self, url: str, **kwargs: Any) -> httpx.Response: return await self.request("PATCH", url, **kwargs)

    async def __aenter__(self) -> 'AsyncRetryingClient':
        await self.client.__aenter__()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.client.__aexit__(exc_type, exc_val, exc_tb)

    async def aclose(self) -> None:
        await self.client.aclose()
        logger.debug("Asynchronous RetryingClient closed.")

# --- Internal Lifecycle Management ---

_sync_client: Optional[RetryingClient] = None
_async_client: Optional[AsyncRetryingClient] = None
_instance_lock = threading.Lock()

def _cleanup_sync() -> None:
    """Module exit handler for sync resources."""
    global _sync_client
    if _sync_client:
        _sync_client.close()
        _sync_client = None

atexit.register(_cleanup_sync)

def _get_sync_default() -> RetryingClient:
    """Lazy-loads the global synchronous persistent client."""
    global _sync_client
    if _sync_client is None or _sync_client.client.is_closed:
        with _instance_lock:
            if _sync_client is None or _sync_client.client.is_closed:
                _sync_client = RetryingClient()
                logger.info("Global persistent sync client created.")
    return _sync_client

async def _get_async_default() -> AsyncRetryingClient:
    """Lazy-loads the global asynchronous persistent client."""
    global _async_client
    if _async_client is None or _async_client.client.is_closed:
        with _instance_lock:
            if _async_client is None or _async_client.client.is_closed:
                _async_client = AsyncRetryingClient()
                logger.info("Global persistent async client created.")
    return _async_client

async def aclose() -> None:
    """Explicitly close the global async client to release resources."""
    global _async_client
    if _async_client:
        await _async_client.aclose()
        _async_client = None

def close() -> None:
    """Explicitly close the global sync client to release resources."""
    global _sync_client
    if _sync_client:
        _sync_client.close()
        _sync_client = None

# --- Public API (Sync and Async Parity) ---

def request(method: str, url: str, **kwargs: Any) -> httpx.Response:
    return _get_sync_default().request(method, url, **kwargs)

def get(url: str, **kwargs: Any) -> httpx.Response: return request("GET", url, **kwargs)
def post(url: str, **kwargs: Any) -> httpx.Response: return request("POST", url, **kwargs)
def put(url: str, **kwargs: Any) -> httpx.Response: return request("PUT", url, **kwargs)
def delete(url: str, **kwargs: Any) -> httpx.Response: return request("DELETE", url, **kwargs)
def patch(url: str, **kwargs: Any) -> httpx.Response: return request("PATCH", url, **kwargs)

async def arequest(method: str, url: str, **kwargs: Any) -> httpx.Response:
    client = await _get_async_default()
    return await client.request(method, url, **kwargs)

async def aget(url: str, **kwargs: Any) -> httpx.Response: return await arequest("GET", url, **kwargs)
async def apost(url: str, **kwargs: Any) -> httpx.Response: return await arequest("POST", url, **kwargs)
async def aput(url: str, **kwargs: Any) -> httpx.Response: return await arequest("PUT", url, **kwargs)
async def adelete(url: str, **kwargs: Any) -> httpx.Response: return await arequest("DELETE", url, **kwargs)
async def apatch(url: str, **kwargs: Any) -> httpx.Response: return await arequest("PATCH", url, **kwargs)
