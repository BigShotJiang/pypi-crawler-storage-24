"""
rhttpx - Retrying HTTPX Client Package.
Provides synchronous and asynchronous HTTP clients with exponential backoff retries.
"""

import importlib.metadata

_metadata = importlib.metadata.metadata("rhttpx")
__version__ = _metadata["Version"]
__author__ = _metadata["Author-email"]
__license__ = _metadata["License"]

from .client import (
    RetryingClient,
    AsyncRetryingClient,
    request,
    get,
    post,
    put,
    delete,
    patch,
    arequest,
    aget,
    apost,
    aput,
    adelete,
    apatch,
    close,
    aclose,
)

__all__ = [
    "RetryingClient",
    "AsyncRetryingClient",
    "request",
    "get",
    "post",
    "put",
    "delete",
    "patch",
    "arequest",
    "aget",
    "apost",
    "aput",
    "adelete",
    "apatch",
    "close",
    "aclose",
]
