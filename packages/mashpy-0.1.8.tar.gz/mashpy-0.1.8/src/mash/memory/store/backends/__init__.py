"""Memory store backend implementations."""
