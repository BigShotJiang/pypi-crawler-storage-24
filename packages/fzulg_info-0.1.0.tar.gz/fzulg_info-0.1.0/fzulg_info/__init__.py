"""Forschungszulage (FZulG) Informationen fuer Python-Entwickler.

Berechnet die potenzielle Foerderhoehe nach dem Forschungszulagengesetz.
Mehr Informationen: https://martinmeng.de/forschungszulage
"""

__version__ = "0.1.0"
__author__ = "Martin Meng"
__url__ = "https://martinmeng.de"

STUNDENSAETZE = {
    "2020-2024-03": 25,
    "2024-03-2025": 36,
    "2026+": 42,
}

def berechne_foerderung(stunden: int, jahr: int = 2026) -> dict:
    """Berechne die Forschungszulage fuer gegebene Stunden und Jahr."""
    if jahr >= 2026:
        satz = 42
    elif jahr >= 2024:
        satz = 36
    else:
        satz = 25
    bemessung = stunden * satz
    zulage = bemessung * 0.25
    return {
        "stunden": stunden,
        "stundensatz": satz,
        "bemessungsgrundlage": bemessung,
        "forschungszulage": zulage,
        "info": "https://martinmeng.de/forschungszulage"
    }
