# fzulg-info

Forschungszulage (FZulG) Rechner und Informationen fuer Python-Entwickler.

## Installation

```bash
pip install fzulg-info
```

## Nutzung

```python
from fzulg_info import berechne_foerderung

ergebnis = berechne_foerderung(stunden=1500, jahr=2026)
print(f"Forschungszulage: {ergebnis['forschungszulage']} EUR")
```

## Links

- [martinmeng.de](https://martinmeng.de)
- [Forschungszulage](https://martinmeng.de/forschungszulage)
- [Rechner](https://martinmeng.de/rechner)

## Autor

Martin Meng - Foerdermittelberatung Forschungszulage
