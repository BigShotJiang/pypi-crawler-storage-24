# CodeCortex AI

**Autonomous coding agent for the terminal** — powered by LLMs.

## Installation

```bash
pip install codecortex-ai
```

## Quick Start

```bash
codecortex
```

On first run, you'll be prompted for:
- **API Key** (required) — your OpenAI, OpenRouter, or any compatible provider key
- **Base URL** (optional) — leave blank for OpenAI, or enter a custom endpoint

Configuration is saved to `~/.codecortex/config.json`.

## Usage

```bash
# Interactive mode
codecortex

# Single prompt
codecortex "refactor this function to use async/await"

# Specify working directory
codecortex --cwd ./my-project

# Reset saved config
codecortex --reset
```

## Supported Providers

Any OpenAI-compatible API works:
- **OpenAI** — leave Base URL empty (default)
- **OpenRouter** — `https://openrouter.ai/api/v1`
- **Anthropic via proxy** — any compatible endpoint
- **Local models** (Ollama, LM Studio) — `http://localhost:11434/v1`

## Commands

Inside the interactive session:

| Command      | Description                    |
|-------------|--------------------------------|
| `/help`     | Show help                      |
| `/config`   | Show current configuration     |
| `/model`    | View or change model           |
| `/approval` | View or change approval policy |
| `/tools`    | List available tools           |
| `/mcp`      | List MCP servers               |
| `/stats`    | Show session statistics        |
| `/save`     | Save current session           |
| `/sessions` | List saved sessions            |
| `/resume`   | Resume a saved session         |
| `/clear`    | Clear conversation             |
| `/exit`     | Quit                           |

## License

MIT
