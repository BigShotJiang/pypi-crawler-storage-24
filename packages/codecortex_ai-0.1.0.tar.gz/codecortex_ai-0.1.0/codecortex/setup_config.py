"""
First-run configuration manager for CodeCortex AI.

Saves config to ~/.codecortex/config.json.
Supports API_KEY (required) and BASE_URL (optional).
"""

import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".codecortex"
CONFIG_FILE = CONFIG_DIR / "config.json"


def load_or_setup() -> dict:
    """Load existing config or run interactive first-time setup.

    Returns a dict with at least 'API_KEY'. 'BASE_URL' may be present
    if the user provided one, otherwise it won't be set (letting the
    OpenAI SDK default to https://api.openai.com/v1).
    """

    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)

    # ── First-run interactive setup ──────────────────────────────
    print()
    print("╭──────────────────────────────────────────────╮")
    print("│       Welcome to CodeCortex AI               │")
    print("│       First-time setup                       │")
    print("╰──────────────────────────────────────────────╯")
    print()

    api_key = input("  Enter API Key: ").strip()
    while not api_key:
        print("  ⚠  API key is required.")
        api_key = input("  Enter API Key: ").strip()

    print()
    print("  Base URL is optional.")
    print("  • Leave empty for OpenAI (default: https://api.openai.com/v1)")
    print("  • For OpenRouter: https://openrouter.ai/api/v1")
    print("  • For any OpenAI-compatible provider, enter its URL")
    print()
    base_url = input("  Enter Base URL (or press Enter to skip): ").strip()

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    config: dict = {"API_KEY": api_key}
    if base_url:
        config["BASE_URL"] = base_url

    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

    print()
    print(f"  ✅ Configuration saved to {CONFIG_FILE}")
    print()

    return config


def reset_config() -> None:
    """Delete the saved config so next run triggers setup again."""
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
        print(f"  Config removed: {CONFIG_FILE}")
    else:
        print("  No config file found.")
