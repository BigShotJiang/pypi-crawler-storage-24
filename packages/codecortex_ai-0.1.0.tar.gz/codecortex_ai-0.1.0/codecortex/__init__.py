"""CodeCortex AI — autonomous coding agent for the terminal."""

__version__ = "0.1.0"
