from codecortex.tools.builtin.edit_file import EditTool
from codecortex.tools.builtin.glob import GlobTool
from codecortex.tools.builtin.grep import GrepTool
from codecortex.tools.builtin.list_dir import ListDirTool
from codecortex.tools.builtin.memory import MemoryTool
from codecortex.tools.builtin.read_file import ReadFileTool
from codecortex.tools.builtin.shell import ShellTool
from codecortex.tools.builtin.todo import TodosTool
from codecortex.tools.builtin.web_fetch import WebFetchTool
from codecortex.tools.builtin.web_search import WebSearchTool
from codecortex.tools.builtin.write_file import WriteFileTool

__all__ = [
    "ReadFileTool",
    "WriteFileTool",
    "EditTool",
    "ShellTool",
    "ListDirTool",
    "GrepTool",
    "GlobTool",
    "WebSearchTool",
    "WebFetchTool",
    "TodosTool",
    "MemoryTool",
]


def get_all_builtin_tools() -> list[type]:
    return [
        ReadFileTool,
        WriteFileTool,
        EditTool,
        ShellTool,
        ListDirTool,
        GrepTool,
        GlobTool,
        WebSearchTool,
        WebFetchTool,
        TodosTool,
        MemoryTool,
    ]
