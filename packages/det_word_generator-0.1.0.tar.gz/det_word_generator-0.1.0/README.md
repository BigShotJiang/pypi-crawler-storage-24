# Det Word Generator

A deterministic word list generator for generating english word sequences with predefined configs.

## TODO

- Expose word list variable to the generate_word_list
- Expose sequence and branch configs in generate_word_list
- Make internal functions not exported
