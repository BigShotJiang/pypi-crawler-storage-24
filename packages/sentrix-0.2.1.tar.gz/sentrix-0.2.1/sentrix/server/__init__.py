"""sentrix.server — FastAPI dashboard."""
