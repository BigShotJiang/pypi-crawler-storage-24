import asyncio
import io
import logging
import os
import re
import shutil
import signal
import tarfile
import uuid
from contextlib import suppress
from pathlib import Path

import aiofiles

from .ssh_utils import (
    parse_ssh_url,
    ssh_git_env_context,
)
from .utils import format_url, get_https_git_config_args

LOGGER = logging.getLogger(__name__)

COMMIT_SHA_PATTERN = re.compile(r"^[0-9a-fA-F]{7,40}\Z")


def _is_commit_sha(ref: str) -> bool:
    return bool(COMMIT_SHA_PATTERN.fullmatch(ref))


def _ref_for_fetch(ref: str) -> str:
    if ref.startswith("origin/"):
        return ref.removeprefix("origin/")
    return ref


def _show_spec_for_ref(path: str) -> str:
    return f"FETCH_HEAD:{path}"


async def _run_git(
    env: dict[str, str],
    config_args: list[str],
    args: list[str],
    *,
    cwd: str | None = None,
) -> tuple[bytes, bytes, int]:
    full = ["git", *config_args, *args]
    try:
        proc = await asyncio.create_subprocess_exec(
            *full,
            stderr=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stdin=asyncio.subprocess.DEVNULL,
            cwd=cwd,
            env=env,
        )
    except OSError as exc:
        return b"", str(exc).encode(), -1

    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30.0)
    except asyncio.exceptions.TimeoutError:
        with suppress(ProcessLookupError):
            os.kill(proc.pid, signal.SIGKILL)

        return b"", b"git command timed out", -1

    return stdout, stderr, proc.returncode if proc.returncode is not None else -1


class _GitResult:
    __slots__ = ("_error", "_stdout")

    def __init__(
        self,
        error: str | None = None,
        stdout: bytes | None = None,
    ) -> None:
        self._error = error
        self._stdout = stdout

    @property
    def is_ok(self) -> bool:
        return self._error is None

    @property
    def error(self) -> str | None:
        return self._error

    @property
    def stdout(self) -> bytes | None:
        return self._stdout

    @classmethod
    async def from_git(
        cls,
        env: dict[str, str],
        config_args: list[str],
        args: list[str],
        *,
        cwd: str | None = None,
    ) -> "_GitResult":
        stdout, stderr, code = await _run_git(env, config_args, args, cwd=cwd)
        if code != 0:
            return cls(stderr.decode("utf-8"))
        return cls(stdout=stdout)

    async def and_then(
        self,
        env: dict[str, str],
        config_args: list[str],
        args: list[str],
        *,
        cwd: str | None = None,
    ) -> "_GitResult":
        if not self.is_ok:
            return self
        return await _GitResult.from_git(env, config_args, args, cwd=cwd)


async def _run_git_sequence(
    env: dict[str, str],
    config_args: list[str],
    steps: list[tuple[list[str], str | None]],
) -> _GitResult:
    result = await _GitResult.from_git(env, config_args, steps[0][0], cwd=steps[0][1])
    for args, cwd in steps[1:]:
        result = await result.and_then(env, config_args, args, cwd=cwd)
    return result


async def _show_via_fetch_show(  # noqa: PLR0913
    env: dict[str, str],
    config_args: list[str],
    repo_url: str,
    ref_fetch: str,
    show_spec: str,
    work_dir: str,
) -> tuple[bytes | None, str | None]:
    fetch_args = ["fetch"]
    if not _is_commit_sha(ref_fetch):
        fetch_args.extend(["--depth", "1"])
    fetch_args.extend(["origin", ref_fetch])

    steps: list[tuple[list[str], str | None]] = [
        (["init"], work_dir),
        (["remote", "add", "origin", repo_url], work_dir),
        (fetch_args, work_dir),
        (["show", show_spec], work_dir),
    ]
    result = await _run_git_sequence(env, config_args, steps)
    if not result.is_ok:
        return None, result.error
    return result.stdout, None


async def _show_via_archive_remote(
    env: dict[str, str],
    config_args: list[str],
    repo_url: str,
    ref_fetch: str,
    path: str,
) -> tuple[bytes | None, str | None]:
    stdout, stderr, code = await _run_git(
        env,
        config_args,
        ["archive", f"--remote={repo_url}", ref_fetch, "--", path],
        cwd=None,
    )
    if code != 0:
        return None, stderr.decode("utf-8")
    if len(stdout) == 0:
        return None, "git archive produced empty output"
    try:
        with tarfile.open(fileobj=io.BytesIO(stdout), mode="r:") as tar:
            for member in tar:
                if (
                    member.isfile()
                    and (extracted := tar.extractfile(member))
                    and extracted is not None
                ):
                    return extracted.read(), None
            return None, "no file in archive"
    except (tarfile.TarError, OSError) as exc:
        return None, str(exc)


def _path_contained_in(base: Path, candidate: Path) -> bool:
    try:
        return candidate.resolve().is_relative_to(base.resolve())
    except (ValueError, OSError):
        return False


def _sparse_checkout_directory(path: str) -> str:
    """Directory to pass to sparse-checkout set in cone mode.

    Cone mode only accepts directories and includes all files under them.
    For a file path like src/main.py we must set the parent directory (src)
    so the file is actually checked out.
    """
    parent = Path(path).parent
    return "." if not parent.parts else str(parent)


async def _show_via_sparse_checkout(  # noqa: PLR0913
    env: dict[str, str],
    config_args: list[str],
    repo_url: str,
    ref_fetch: str,
    path: str,
    temp_dir: str,
) -> tuple[bytes | None, str | None]:
    sparse_dir = f"{temp_dir}/{uuid.uuid4()}"
    sparse_dir_path = _sparse_checkout_directory(path)

    fetch_args = ["fetch"]
    if not _is_commit_sha(ref_fetch):
        fetch_args.extend(["--depth", "1"])
    fetch_args.extend(["origin", ref_fetch])

    steps: list[tuple[list[str], str | None]] = [
        (
            [
                "clone",
                "--no-checkout",
                "--depth",
                "1",
                repo_url,
                Path(sparse_dir).name,
            ],
            temp_dir,
        ),
        (fetch_args, sparse_dir),
        (["sparse-checkout", "init", "--cone"], sparse_dir),
        (["sparse-checkout", "set", sparse_dir_path], sparse_dir),
        (["checkout", "FETCH_HEAD"], sparse_dir),
    ]
    try:
        result = await _run_git_sequence(env, config_args, steps)
        if not result.is_ok:
            return None, result.error

        base = Path(sparse_dir)
        file_path = base / path
        if not _path_contained_in(base, file_path):
            return None, "path escapes repository"
        try:
            async with aiofiles.open(file_path, "rb") as f:
                return await f.read(), None
        except OSError as exc:
            return None, str(exc)
    finally:
        shutil.rmtree(sparse_dir, ignore_errors=True)


async def _try_show_strategies(  # noqa: PLR0913
    env: dict[str, str],
    config_args: list[str],
    repo_url: str,
    ref_fetch: str,
    show_spec: str,
    path: str,
    work_dir: str,
    temp_dir: str,
) -> tuple[bytes | None, str | None]:
    content, err = await _show_via_fetch_show(
        env,
        config_args,
        repo_url,
        ref_fetch,
        show_spec,
        work_dir,
    )
    if content is not None:
        return content, None
    last_error = err or "fetch+show failed"
    LOGGER.debug(
        "show_file fallback: fetch+show failed, trying archive --remote",
        extra={"extra": {"error": last_error}},
    )

    content, err = await _show_via_archive_remote(
        env,
        config_args,
        repo_url,
        ref_fetch,
        path,
    )
    if content is not None:
        return content, None
    last_error = err or "archive --remote failed"
    LOGGER.debug(
        "show_file fallback: archive --remote failed, trying sparse-checkout",
        extra={"extra": {"error": last_error}},
    )

    content, err = await _show_via_sparse_checkout(
        env,
        config_args,
        repo_url,
        ref_fetch,
        path,
        temp_dir,
    )
    if content is not None:
        return content, None
    return None, err or "sparse-checkout failed"


async def show_file_at_ref_ssh(
    repo_url: str,
    ref: str,
    path: str,
    temp_dir: str,
    *,
    credential_key: str,
) -> tuple[bytes | None, str | None]:
    ref_fetch = _ref_for_fetch(ref)
    show_spec = _show_spec_for_ref(path)
    work_dir = f"{temp_dir}/{uuid.uuid4()}"
    Path(work_dir).mkdir(parents=True, exist_ok=True)  # noqa: ASYNC240
    repo_url_parsed = parse_ssh_url(repo_url)
    config_args: list[str] = []

    try:
        with ssh_git_env_context(temp_dir, credential_key) as env:
            return await _try_show_strategies(
                env,
                config_args,
                repo_url_parsed,
                ref_fetch,
                show_spec,
                path,
                work_dir,
                temp_dir,
            )
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


async def show_file_at_ref_https(  # noqa: PLR0913
    repo_url: str,
    ref: str,
    path: str,
    temp_dir: str,
    *,
    user: str | None = None,
    password: str | None = None,
    token: str | None = None,
    provider: str | None = None,
    is_pat: bool = False,
    follow_redirects: bool = False,
) -> tuple[bytes | None, str | None]:
    ref_fetch = _ref_for_fetch(ref)
    show_spec = _show_spec_for_ref(path)
    work_dir = f"{temp_dir}/{uuid.uuid4()}"
    Path(work_dir).mkdir(parents=True, exist_ok=True)  # noqa: ASYNC240

    url = format_url(
        repo_url=repo_url,
        user=user,
        password=password,
        token=token,
        provider=provider,
        is_pat=is_pat,
    )
    config_args = get_https_git_config_args(
        follow_redirects=follow_redirects,
        is_pat=is_pat,
        token=token,
        disable_credential_prompt=token is not None or password is not None,
    )
    env = os.environ.copy()
    if token is not None or password is not None:
        env["GIT_TERMINAL_PROMPT"] = "0"

    try:
        return await _try_show_strategies(
            env,
            config_args,
            url,
            ref_fetch,
            show_spec,
            path,
            work_dir,
            temp_dir,
        )
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


async def show_file_at_ref(  # noqa: PLR0913
    repo_url: str,
    ref: str,
    path: str,
    temp_dir: str,
    *,
    credential_key: str | None = None,
    user: str | None = None,
    password: str | None = None,
    token: str | None = None,
    provider: str | None = None,
    is_pat: bool = False,
    follow_redirects: bool = False,
) -> tuple[bytes | None, str | None]:
    if credential_key:
        return await show_file_at_ref_ssh(
            repo_url,
            ref,
            path,
            temp_dir,
            credential_key=credential_key,
        )
    return await show_file_at_ref_https(
        repo_url,
        ref,
        path,
        temp_dir,
        user=user,
        password=password,
        token=token,
        provider=provider,
        is_pat=is_pat,
        follow_redirects=follow_redirects,
    )
