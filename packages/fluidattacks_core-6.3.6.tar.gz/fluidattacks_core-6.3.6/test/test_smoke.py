# ruff: noqa: F401, PLC0415
import ast
import importlib
import inspect
import sys
import tempfile
from pathlib import Path

import pytest


def test_import_base_package() -> None:
    import fluidattacks_core


def test_import_filesystem_module() -> None:
    from fluidattacks_core.filesystem import Language, find_projects


def test_import_semver_module() -> None:
    from fluidattacks_core.semver.match_versions import normalize


def test_filesystem_language_enum() -> None:
    from fluidattacks_core.filesystem import Language

    assert Language.Python.value == "Python"
    assert Language.Java.value == "Java"
    assert Language.JavaScript.value == "JavaScript"
    assert Language.TypeScript.value == "TypeScript"
    assert Language.Go.value == "golang"


def test_semver_normalize() -> None:
    from fluidattacks_core.semver.match_versions import normalize

    parts, pre_release = normalize("1.2.3")
    assert parts == ["1", "2", "3"]
    assert pre_release is None


def test_filesystem_find_projects() -> None:
    from fluidattacks_core.filesystem import find_projects

    with tempfile.TemporaryDirectory() as tmp:
        results = find_projects(tmp)
        assert len(results) >= 1
        root_path, root_lang, _ = results[0]
        assert root_path == Path(tmp).resolve()
        assert root_lang == "root"


def test_import_http_module() -> None:
    pytest.importorskip("aiohttp")
    from fluidattacks_core.http import request


def test_import_git_module() -> None:
    pytest.importorskip("git")
    from fluidattacks_core.git import clone


def test_import_logging_module() -> None:
    pytest.importorskip("simplejson")
    pytest.importorskip("pythonjsonlogger")
    from fluidattacks_core.logging import init_logging


def test_import_sarif_module() -> None:
    pytest.importorskip("pydantic")
    from fluidattacks_core.sarif import Artifact


def test_import_aio_module() -> None:
    pytest.importorskip("uvloop")
    from fluidattacks_core.aio import run


def test_import_serializers_module() -> None:
    pytest.importorskip("tree_sitter")
    pytest.importorskip("more_itertools")
    from fluidattacks_core.serializers.snippet import make_snippet


def test_git_requires_http() -> None:
    source = inspect.getsource(
        __import__("fluidattacks_core.git.https_utils", fromlist=["https_utils"])
    )
    tree = ast.parse(source)
    imported_modules = {
        node.module for node in ast.walk(tree) if isinstance(node, ast.ImportFrom) and node.module
    }
    assert "fluidattacks_core.http.client" in imported_modules


@pytest.mark.parametrize(
    ("fa_module", "blocked_dep"),
    [
        ("fluidattacks_core.aio", "uvloop"),
        ("fluidattacks_core.git", "fluidattacks_core.http"),
        ("fluidattacks_core.git", "git"),
        ("fluidattacks_core.http", "aiohttp"),
        ("fluidattacks_core.sarif", "pydantic"),
    ],
)
def test_module_raises_without_dependency(fa_module: str, blocked_dep: str) -> None:
    """Verify importing *fa_module* raises ModuleNotFoundError when *blocked_dep* is missing.

    Evicts both module trees from sys.modules, sets the dependency to None
    (Python's sentinel for a blocked import), then asserts the import fails.
    """
    saved = {}
    prefixes = (fa_module + ".", blocked_dep + ".")
    for key in list(sys.modules):
        if key in (fa_module, blocked_dep) or key.startswith(prefixes):
            saved[key] = sys.modules.pop(key)
    sys.modules[blocked_dep] = None  # type: ignore[assignment]
    try:
        with pytest.raises(ModuleNotFoundError):
            importlib.import_module(fa_module)
    finally:
        sys.modules.pop(blocked_dep, None)
        sys.modules.update(saved)
