from pyxform import constants as const
from pyxform.errors import ErrorCode, PyXFormError


def validate_question_group_repeat_name(
    name: str | None,
    seen_names: set[str],
    seen_names_lower: set[str],
    warnings: list[str],
    row_number: int | None = None,
    check_reserved: bool = True,
):
    """
    Warn about duplicate or problematic names on the survey sheet.

    May append the name to `seen_names` and `seen_names_lower`. May append to `warnings`.

    :param name: Question or group name.
    :param seen_names: Names already processed in the sheet.
    :param seen_names_lower: Same as seen_names but lower case.
    :param warnings: Warnings list.
    :param row_number: Current sheet row number.
    :param check_reserved: If True, check the name against any reserved names. When
      checking names in the context of SurveyElement processing, it's difficult to
      differentiate user-specified names from names added by pyxform.
    """
    if not name:
        return

    if check_reserved and not seen_names >= const.RESERVED_NAMES_SURVEY_SHEET:
        seen_names.update(const.RESERVED_NAMES_SURVEY_SHEET)

    if name in seen_names:
        if name == const.META:
            raise PyXFormError(ErrorCode.NAMES_005.value.format(row=row_number))
        else:
            raise PyXFormError(
                ErrorCode.NAMES_001.value.format(row=row_number, value=name)
            )
    seen_names.add(name)

    question_name_lower = name.lower()
    if question_name_lower in seen_names_lower:
        # No case-insensitive warning for 'meta' since it's not an exported data table.
        warnings.append(ErrorCode.NAMES_002.value.format(row=row_number, value=name))
    seen_names_lower.add(question_name_lower)


def validate_repeat_name(
    name: str | None,
    control_type: str,
    instance_element_name: str,
    seen_names: set[str],
    row_number: int | None = None,
):
    """
    Warn about duplicate or problematic names.

    May appends the name to `seen_names` and `neen_names_lower`. May append to `warnings`.
    These checks are additional to the above in validate_survey_sheet_name so does not
    re-check reserved names etc.

    :param row_number: Current sheet row number.
    :param name: Question or group name.
    :param control_type: E.g. group, repeat, or loop.
    :param instance_element_name: Name of the main survey instance element.
    :param seen_names: Names already processed in the sheet.
    """
    if control_type == const.REPEAT:
        if name == instance_element_name:
            raise PyXFormError(
                ErrorCode.NAMES_003.value.format(row=row_number, value=name)
            )
        elif name in seen_names:
            raise PyXFormError(
                ErrorCode.NAMES_004.value.format(row=row_number, value=name)
            )
        seen_names.add(name)
