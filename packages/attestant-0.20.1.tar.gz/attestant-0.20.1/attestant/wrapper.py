"""
Internal helpers for attestant.upload().

Handles local prediction, data serialization, HTTP transport, and
provenance upload. Not part of the public API.
"""

import hashlib
import logging
import json
import pickle
import urllib.parse
import urllib.request
import urllib.error
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Provenance Registry — global singleton tracking source DataFrames
# ---------------------------------------------------------------------------

class _ProvenanceRegistry:
    """Global registry tracking source DataFrames for pipeline lineage.

    When users call ``attestant.source(df, "table_name")``, the DataFrame's
    columns and raw values are captured here. On the next ``upload()`` call,
    the registry provides:
    - Column-to-source mapping (e.g. ``income`` -> ``applications.income``)
    - Serialized snapshots of source tables for full raw data reconstruction
    - Column provenance resolution (source, derived, or unknown)
    """

    def __init__(self) -> None:
        self._sources: Dict[str, str] = {}               # {col_name: "table.col"}
        self._source_columns: Dict[str, List[str]] = {}  # {table_name: [col_names]}
        self._source_refs: Dict[str, Any] = {}            # {table_name: weakref or id}
        self._source_dtypes: Dict[str, Dict[str, str]] = {}  # {table_name: {col: dtype}}

    def register(self, df: Any, table_name: str) -> Any:
        """Register a DataFrame as a source table.

        Only captures column names and dtypes at registration time —
        NOT the full data. Raw cell values are captured later during
        upload() for only the columns that actually appear in the model input.
        """
        try:
            cols = list(df.columns)
        except AttributeError:
            logger.debug("ProvenanceRegistry: df has no .columns, skipping")
            return df

        for col in cols:
            self._sources[col] = "%s.%s" % (table_name, col)
        self._source_columns[table_name] = cols
        self._source_dtypes[table_name] = {str(c): str(df[c].dtype) for c in cols}
        return df

    def resolve(self, df: Any) -> Dict[str, str]:
        """Resolve provenance for every column in a DataFrame.

        Returns
        -------
        dict
            Mapping of ``{col_name: "table.col"}`` for known sources,
            ``"derived"`` for columns not matching any registered source.
        """
        result: Dict[str, str] = {}
        try:
            cols = list(df.columns)
        except AttributeError:
            return result
        for col in cols:
            if col in self._sources:
                result[col] = self._sources[col]
            else:
                result[col] = "derived"
        return result

    def build_source_snapshots(self, final_df: Any) -> Dict[str, Any]:
        """Build source snapshots containing ONLY columns used in the final DataFrame.

        Instead of capturing entire source tables, this extracts just the
        columns from the final model input and groups them by source table.
        The server gets the actual cell values that were used — nothing more.
        """
        try:
            final_cols = set(final_df.columns)
        except AttributeError:
            return {}

        # Group final columns by source table
        table_cols: Dict[str, list] = {}
        for col in final_cols:
            src = self._sources.get(col)
            if src and "." in src:
                table = src.rsplit(".", 1)[0]
                if table not in table_cols:
                    table_cols[table] = []
                table_cols[table].append(col)

        # Serialize only the used columns per source table
        snapshots = {}
        for table, cols in table_cols.items():
            try:
                import pandas as pd
                if isinstance(final_df, pd.DataFrame):
                    subset = final_df[[c for c in cols if c in final_df.columns]]
                    snapshots[table] = _serialize(subset)
            except Exception:
                pass
        return snapshots

    def get_source_mapping(self) -> Dict[str, str]:
        """Return the full column -> table.col mapping."""
        return self._sources.copy()

    def get_source_metadata(self) -> Dict[str, Dict[str, str]]:
        """Return source table metadata (columns + dtypes)."""
        return self._source_dtypes.copy()

    def clear(self) -> None:
        """Reset the registry (between pipeline runs)."""
        self._sources.clear()
        self._source_columns.clear()
        self._source_dtypes.clear()


_registry = _ProvenanceRegistry()


def _compute_model_hash(model) -> Optional[str]:
    try:
        return hashlib.sha256(pickle.dumps(model)).hexdigest()[:16]
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

def _sanitize_value(v):
    import math
    try:
        if isinstance(v, float) and not math.isfinite(v):
            return None
    except Exception:
        pass
    return v


def _sanitize_rows(rows):
    return [[_sanitize_value(v) for v in row] for row in rows]


def _sanitize_list(lst):
    return [_sanitize_value(v) for v in lst]


def _serialize(arr) -> Optional[dict]:
    if arr is None:
        return None
    try:
        import pandas as pd
        import numpy as np

        if isinstance(arr, pd.DataFrame):
            split = arr.to_dict(orient="split")
            split["data"] = _sanitize_rows(split["data"])
            return {"type": "dataframe", "data": split}
        if isinstance(arr, pd.Series):
            return {"type": "series", "data": _sanitize_list(arr.tolist())}
        if isinstance(arr, np.ndarray):
            return {"type": "ndarray", "data": _sanitize_list(arr.tolist())}
        try:
            import scipy.sparse as sp
            if sp.issparse(arr):
                return {"type": "ndarray", "data": arr.toarray().tolist()}
        except ImportError:
            pass
        return {"type": "list", "data": [
            v.item() if hasattr(v, "item") else v for v in arr
        ]}
    except Exception as e:
        logger.warning(f"[attestant] Could not serialize {type(arr).__name__}: {e}")
        return None


def _resolve_protected(X, protected_df, protected_columns) -> Optional[Any]:
    if protected_df is not None:
        try:
            import pandas as pd
            if isinstance(protected_df, dict):
                return pd.DataFrame([protected_df])
        except ImportError:
            pass
        return protected_df

    if protected_columns:
        try:
            import pandas as pd
            if isinstance(X, pd.DataFrame):
                cols = [c for c in protected_columns if c in X.columns]
                if cols:
                    return X[cols]
        except ImportError:
            pass

    return None


def _run_local_predict(model, X):
    import numpy as np

    # 1. prefer predict_proba for richer fairness analysis
    if hasattr(model, "predict_proba"):
        try:
            proba = model.predict_proba(X)
            arr = np.asarray(proba, dtype=float)
            return arr[:, -1] if arr.ndim == 2 else arr.flatten()
        except Exception:
            pass

    # 2. sklearn-compatible predict
    if hasattr(model, "predict"):
        try:
            return np.asarray(model.predict(X), dtype=float).flatten()
        except Exception:
            pass

    # 3. PyTorch nn.Module
    try:
        import torch
        raw = X.values if hasattr(X, "values") else np.asarray(X)
        t = torch.tensor(raw, dtype=torch.float32)
        with torch.no_grad():
            out = model(t)
        arr = out.detach().cpu().numpy().flatten()
        return arr.astype(float)
    except Exception:
        pass

    # 4. TensorFlow / Keras (model.predict returns ndarray)
    try:
        result = model.predict(X)
        return np.asarray(result, dtype=float).flatten()
    except Exception:
        pass

    # 5. ONNX Runtime InferenceSession
    try:
        raw = X.values if hasattr(X, "values") else np.asarray(X, dtype=np.float32)
        input_name = model.get_inputs()[0].name
        result = model.run(None, {input_name: raw.astype(np.float32)})
        return np.asarray(result[0], dtype=float).flatten()
    except Exception:
        pass

    # 6. Bare callable
    if callable(model):
        try:
            return np.asarray(model(X), dtype=float).flatten()
        except Exception:
            pass

    raise RuntimeError(
        "Cannot generate predictions from %s. "
        "Pass predictions= directly to attestant.upload() instead."
        % type(model).__name__
    )


def _resolve_inputs(train_df, test_df, label_column, X_train, y_train, X_test, y_test, protected_columns):
    try:
        import pandas as pd
        import numpy as np
        has_pandas = True
    except ImportError:
        has_pandas = False

    protected_df = None

    # --- DataFrame mode ---
    if test_df is not None:
        if label_column is None:
            raise ValueError(
                "label_column is required when passing test_df. "
                "Example: validate(model=clf, test_df=df, label_column='approved', ...)"
            )
        if not has_pandas:
            raise ImportError("pandas is required when using train_df/test_df mode")

        if not isinstance(test_df, pd.DataFrame):
            test_df = pd.DataFrame(test_df)

        y_test = test_df[label_column].values

        prot_in_test = [c for c in protected_columns if c in test_df.columns]
        if prot_in_test:
            protected_df = test_df[prot_in_test].reset_index(drop=True)

        drop_cols = [label_column] + prot_in_test
        X_test = test_df.drop(
            columns=[c for c in drop_cols if c in test_df.columns]
        ).reset_index(drop=True)

        if train_df is not None:
            if not isinstance(train_df, pd.DataFrame):
                train_df = pd.DataFrame(train_df)
            y_train = train_df[label_column].values
            prot_in_train = [c for c in protected_columns if c in train_df.columns]
            X_train = train_df.drop(
                columns=[c for c in [label_column] + prot_in_train if c in train_df.columns]
            ).reset_index(drop=True)

    # --- Array mode ---
    elif X_test is not None:
        if has_pandas and isinstance(X_test, pd.DataFrame):
            prot_in_X = [c for c in protected_columns if c in X_test.columns]
            if prot_in_X:
                protected_df = X_test[prot_in_X].reset_index(drop=True)
                X_test = X_test.drop(columns=prot_in_X).reset_index(drop=True)
            if X_train is not None and isinstance(X_train, pd.DataFrame):
                prot_in_train = [c for c in protected_columns if c in X_train.columns]
                if prot_in_train:
                    X_train = X_train.drop(columns=prot_in_train).reset_index(drop=True)
    else:
        raise ValueError(
            "No data provided. Pass either test_df= (DataFrame mode) "
            "or X_test= (array mode)."
        )

    return X_train, y_train, X_test, y_test, protected_df


def _post_json(url: str, api_key: str, payload, timeout: int = 120) -> dict:
    body = json.dumps(payload, default=str).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "attestant-python-client/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_text = e.read().decode("utf-8", errors="replace")[:400]
        raise RuntimeError(f"HTTP {e.code} from {url}: {error_text}") from e


def _patch_json(url: str, api_key: str, payload: dict, timeout: int = 30) -> dict:
    body = json.dumps(payload, default=str).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        method="PATCH",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "attestant-python-client/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_text = e.read().decode("utf-8", errors="replace")[:200]
        raise RuntimeError(f"HTTP {e.code} (PATCH) from {url}: {error_text}") from e


def _h32(*parts: str) -> int:
    h = hashlib.md5("|".join(str(p) for p in parts).encode()).hexdigest()
    return int(h[:8], 16)  # first 32 bits of MD5


def _rh(row_dict: dict) -> str:
    try:
        canonical = json.dumps(row_dict, sort_keys=True, default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()
    except Exception:
        return ""


def _cn(X, fallback_prefix: str = "feature") -> List[str]:
    try:
        import pandas as pd
        if isinstance(X, pd.DataFrame):
            return [str(c) for c in X.columns]
    except ImportError:
        pass
    try:
        import numpy as np
        arr = np.asarray(X)
        n = arr.shape[1] if arr.ndim == 2 else 1
        return [f"{fallback_prefix}_{j}" for j in range(n)]
    except Exception:
        return [fallback_prefix]


def _rc(X) -> int:
    try:
        return len(X)
    except TypeError:
        try:
            import numpy as np
            return np.asarray(X).shape[0]
        except Exception:
            return 0


def _gs(val) -> tuple:
    try:
        import numpy as np
        if isinstance(val, (bool,)):
            return (float(val), None)
        if isinstance(val, (int, float, np.integer, np.floating)):
            v = float(val)
            return (None if (v != v) else v, None)  # NaN → None
    except ImportError:
        if isinstance(val, (bool, int, float)):
            return (float(val), None)
    return (None, str(val)[:255] if val is not None else None)


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

def _trd(X, cols: List[str]) -> List[dict]:
    try:
        import pandas as pd
        if isinstance(X, pd.DataFrame):
            return [
                {col: row[col] if col in row.index else None
                 for col in cols}
                for _, row in X.iterrows()
            ]
        if isinstance(X, pd.Series):
            return [{cols[0]: v} for v in X]
    except ImportError:
        pass
    try:
        import numpy as np
        arr = np.asarray(X, dtype=object)
        if arr.ndim == 1:
            arr = arr.reshape(-1, 1)
        return [
            {cols[j]: arr[i, j] for j in range(min(len(cols), arr.shape[1]))}
            for i in range(arr.shape[0])
        ]
    except Exception:
        pass
    try:
        return [{cols[j]: row[j] for j in range(min(len(cols), len(row)))}
                for row in X]
    except Exception:
        return []


def _fo(outputs, n: int) -> List:
    if outputs is None:
        return [None] * n
    try:
        import numpy as np
        arr = np.asarray(outputs)
        if arr.ndim == 2:
            arr = arr[:, -1]
        return arr.tolist()
    except Exception:
        pass
    try:
        return list(outputs)
    except TypeError:
        return [outputs] + [None] * (n - 1)


def _sync_prov(
    X,
    y,
    protected_data,
    protected_columns: List[str],
    model_name: str,
    model_version: str,
    api_key: str,
    service_url: str,
    model_id: str = "",
) -> None:
    service_url = service_url.rstrip("/")
    feature_cols = _cn(X)
    protected_cols = (
        _cn(protected_data, "protected") if protected_data is not None else []
    )
    all_source_cols = feature_cols + [c for c in protected_cols if c not in feature_cols]

    try:
        resp = _post_json(
            f"{service_url}/v1/pipelines",
            api_key,
            {
                "pipeline_name": f"{model_name}_v{model_version}",
                "config": {
                    "model_name":    model_name,
                    "model_version": model_version,
                    "model_id":      model_id,
                },
            },
        )
        pipeline_id = int(resp["pipeline_id"])
    except Exception as e:
        logger.error("[attestant] validate() provenance: pipeline creation failed: %s", e)
        return

    PAGE = 100
    val_fp = _h32("validation", model_name, model_version)
    nodes: List[dict] = []

    for col in all_source_cols:
        is_prot = col in protected_cols or col in protected_columns
        fp = _h32("source", model_name, col)
        nodes.append({
            "fingerprint":  fp,
            "node_type":    "source",
            "operation":    "source_protected" if is_prot else "source_feature",
            "table_name":   model_name,
            "column_name":  col,
            "pair_id":      fp,
            "is_protected": is_prot,
            "pipeline_id":  pipeline_id,
        })
        try:
            _post_json(
                f"{service_url}/v1/sources", api_key,
                {"pair_id": fp, "table_name": model_name,
                 "column_name": col, "is_protected": is_prot},
            )
        except Exception:
            pass

    nodes.append({
        "fingerprint":  val_fp,
        "node_type":    "computation",
        "operation":    "model_validate",
        "table_name":   model_name,
        "column_name":  "output",
        "is_protected": False,
        "pipeline_id":  pipeline_id,
        "metadata":     {"model_version": model_version, "model_id": model_id},
    })
    for offset in range(0, len(nodes), PAGE):
        try:
            _post_json(f"{service_url}/v1/nodes", api_key, nodes[offset:offset + PAGE])
        except Exception as e:
            logger.warning("[attestant] validate() provenance: node batch failed: %s", e)

    edges = [
        {"parent_h32": _h32("source", model_name, col),
         "child_h32":  val_fp}
        for col in all_source_cols
    ]
    for offset in range(0, len(edges), PAGE):
        try:
            _post_json(f"{service_url}/v1/edges", api_key, edges[offset:offset + PAGE])
        except Exception as e:
            logger.warning("[attestant] validate() provenance: edge batch failed: %s", e)

    # 4. Per-row results (one record per row — label + input hash)
    n = _rc(X)
    if n == 0:
        return

    x_rows    = _trd(X, feature_cols)
    prot_rows = (_trd(protected_data, protected_cols)
                 if protected_data is not None else [])
    out_list  = _fo(y, n)

    results = []
    for i in range(n):
        row_data    = x_rows[i] if i < len(x_rows) else {}
        out_val     = out_list[i] if i < len(out_list) else None
        num_val, _  = _gs(out_val)
        results.append({
            "row_key":      f"{model_name}_{pipeline_id}_model_validate_{i}",
            "output_name":  "model_validate",
            "fingerprint":  val_fp,
            "output_value": num_val,
            "input_hash":   _rh(row_data),
        })
    try:
        _post_json(
            f"{service_url}/v1/results", api_key,
            {"pipeline_id": pipeline_id, "results": results},
        )
    except Exception as e:
        logger.error("[attestant] validate() provenance: results upload failed: %s", e)

    # 5. Cell-level values (every column, every row, including protected attrs)
    values: List[dict] = []
    for i in range(n):
        row  = x_rows[i] if i < len(x_rows) else {}
        prow = prot_rows[i] if i < len(prot_rows) else {}

        for col in feature_cols:
            num_v, txt_v = _gs(row.get(col))
            values.append({
                "pipeline_id":    pipeline_id,
                "row_index":      i,
                "fingerprint":    _h32("source", model_name, col),
                "node_operation": "source_feature",
                "column_name":    col,
                "value":          num_v,
                "text_value":     txt_v,
            })
        for col in protected_cols:
            num_v, txt_v = _gs(prow.get(col))
            values.append({
                "pipeline_id":    pipeline_id,
                "row_index":      i,
                "fingerprint":    _h32("source", model_name, col),
                "node_operation": "source_protected",
                "column_name":    col,
                "value":          num_v,
                "text_value":     txt_v,
            })

        out_val = out_list[i] if i < len(out_list) else None
        num_v, txt_v = _gs(out_val)
        values.append({
            "pipeline_id":    pipeline_id,
            "row_index":      i,
            "fingerprint":    val_fp,
            "node_operation": "model_validate",
            "column_name":    "output",
            "value":          num_v,
            "text_value":     txt_v,
        })

    PAGE_V = 500
    for offset in range(0, len(values), PAGE_V):
        try:
            _post_json(f"{service_url}/v1/values", api_key, values[offset:offset + PAGE_V])
        except Exception as e:
            logger.error("[attestant] validate() provenance: values batch failed: %s", e)

    try:
        _patch_json(
            f"{service_url}/v1/pipelines/{pipeline_id}", api_key,
            {"status": "validation_complete"},
        )
    except Exception:
        pass