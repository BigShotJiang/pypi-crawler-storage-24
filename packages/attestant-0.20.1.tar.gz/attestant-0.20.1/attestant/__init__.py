"""
Attestant: Upload model data for compliance analysis.

All compliance checks, fair lending analysis, and report generation
happen in the Attestant dashboard after upload.

Quick start::

    import attestant
    attestant.configure(api_key="pvt_live_...")

    # Tag source DataFrames (optional but recommended)
    apps = attestant.source(pd.read_sql("SELECT * FROM applications", conn), "applications")
    bureau = attestant.source(pd.read_csv("bureau.csv"), "bureau")

    # Normal pandas operations
    merged = apps.merge(bureau, on="ssn")
    features = merged.drop(columns=["ssn"])

    # Upload
    attestant.upload(model=clf, X_test=features, y_test=y, protected_columns=["race", "sex", "age"])

Dashboard: https://getattestant.com/client/
"""

import logging
import os
import time
import json
import urllib.request
import urllib.error
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

__version__ = "0.20.1"

__all__ = [
    "__version__",
    "configure",
    "source",
    "upload",
    "status",
    "UploadResult",
    "StatusInfo",
]


@dataclass
class UploadResult:
    """Result from ``attestant.upload()``.

    Confirms your model data was uploaded successfully.
    View compliance results in the dashboard.
    """
    dashboard_url: str
    model_id: str = ""

    def __repr__(self) -> str:
        return "UploadResult(dashboard_url=%r)" % self.dashboard_url


@dataclass
class StatusInfo:
    """Result from ``attestant.status()``."""
    connected: bool
    version: str = ""
    latency_ms: float = 0.0
    error: str = ""

    def __bool__(self) -> bool:
        return self.connected

    def __repr__(self) -> str:
        if self.connected:
            return "StatusInfo(connected=True, latency_ms=%.0f)" % self.latency_ms
        return "StatusInfo(connected=False, error=%r)" % self.error


_API_KEY: Optional[str] = None
_SERVICE_URL: str = os.environ.get("ATTESTANT_SERVICE_URL", "https://getattestant.com")
_logger = logging.getLogger(__name__)


def configure(
    api_key: Optional[str] = None,
    service_url: Optional[str] = None,
) -> None:
    """
    Configure Attestant with your API key.

    Parameters
    ----------
    api_key : str, optional
        Your API key (from the dashboard). If omitted, uses ``ATTESTANT_API_KEY``.
    service_url : str, optional
        Override the service URL. Defaults to ``https://getattestant.com``.
    """
    global _API_KEY, _SERVICE_URL

    resolved = api_key or os.environ.get("ATTESTANT_API_KEY")
    if not resolved:
        raise ValueError("No API key. Pass api_key=... or set ATTESTANT_API_KEY.")

    _API_KEY = resolved
    _SERVICE_URL = (
        service_url
        or os.environ.get("ATTESTANT_SERVICE_URL")
        or _SERVICE_URL
    ).rstrip("/")

    if not _SERVICE_URL.startswith("https://"):
        _is_local = (
            _SERVICE_URL.startswith("http://localhost")
            or _SERVICE_URL.startswith("http://127.0.0.1")
        )
        if not _is_local:
            raise ValueError(
                "Attestant requires HTTPS. Got: %s. "
                "Set service_url to an https:// URL." % _SERVICE_URL
            )
        _logger.warning(
            "Using insecure HTTP for local development: %s", _SERVICE_URL
        )

    os.environ["ATTESTANT_API_KEY"] = _API_KEY
    os.environ["ATTESTANT_SERVICE_URL"] = _SERVICE_URL


def source(df: Any, table_name: str) -> Any:
    """Tag a DataFrame as coming from a source table.

    Call this when loading data from a database, file, or API.
    Attestant captures the raw values and column names at this point
    so the full data pipeline can be reconstructed later.

    Parameters
    ----------
    df : DataFrame
        The source data.
    table_name : str
        Name of the source table/file (e.g. ``"applications"``,
        ``"bureau_pulls"``).

    Returns
    -------
    DataFrame
        The same DataFrame, unchanged. Your code continues as normal.

    Example::

        apps = attestant.source(pd.read_sql("SELECT * FROM applications", conn), "applications")
        bureau = attestant.source(pd.read_csv("bureau.csv"), "bureau")
        # Now do normal pandas operations...
    """
    from .wrapper import _registry
    _registry.register(df, table_name)
    return df


def upload(
    model: Any = None,
    *,
    train_df: Any = None,
    test_df: Any = None,
    label_column: Optional[str] = None,
    X_train: Any = None,
    y_train: Any = None,
    X_test: Any = None,
    y_test: Any = None,
    protected_columns: List[str],
    age_column: Optional[str] = None,
    age_format: Optional[str] = None,
    predictions: Any = None,
    model_name: str = "model",
    model_version: str = "1.0.0",
    protected_column_types: Optional[Dict[str, str]] = None,
    compliance_profile: Optional[str] = None,
    di_threshold: Optional[float] = None,
    regulations: Optional[List[str]] = None,
    data_sources: Optional[Dict[str, str]] = None,
    pipeline_steps: Optional[List[Dict[str, Any]]] = None,
    **metadata,
) -> UploadResult:
    """
    Upload model data to Attestant.

    Predictions run locally. Only the prediction array and test data
    are sent. The model object never leaves your environment.

    View compliance results in the dashboard after upload.

    Parameters
    ----------
    model : Any
        Any trained model — scikit-learn, XGBoost, LightGBM, CatBoost,
        PyTorch, TensorFlow, ONNX, or any callable with a predict() method.
    test_df : DataFrame, optional
        Holdout data (features + label + protected attributes).
    label_column : str, optional
        Target column name when using test_df.
    X_test : array-like, optional
        Evaluation features.
    y_test : array-like, optional
        Ground-truth labels.
    protected_columns : list of str
        Protected attribute columns (e.g. ``["race", "sex", "age"]``).
    age_column : str or None
        Column holding applicant age, or None if not collected.
    age_format : str or None
        Format of the age column: ``"years"``, ``"months"``, ``"days"``,
        ``"dob"``, or ``"birth_year"``.
    model_name : str
        Display name in the dashboard.
    model_version : str
        Version string (default ``"1.0.0"``).
    data_sources : dict, optional
        Map column names to their source table/dataset. Enables full
        lineage tracking across the data pipeline. Example::

            data_sources={
                "income": "applications.annual_income",
                "credit_score": "bureau_pulls.fico_score",
                "debt_ratio": "derived.dti_ratio",
                "race": "hmda_demographics.race",
                "age": "applications.applicant_age",
            }

        Format: ``{"column_name": "table.column"}`` or
        ``{"column_name": "database.schema.table.column"}``.
        If omitted, all columns are attributed to a single source.

    pipeline_steps : list of dict, optional
        Describe the data transformations that produced the final dataset.
        Each step is a dict with ``name``, ``inputs``, ``outputs``, and
        optional ``operation`` and ``sql`` fields. Example::

            pipeline_steps=[
                {
                    "name": "join_bureau",
                    "operation": "left_join",
                    "inputs": ["applications", "bureau_pulls"],
                    "outputs": ["joined_data"],
                    "sql": "SELECT a.*, b.fico_score FROM applications a LEFT JOIN bureau_pulls b ON a.ssn = b.ssn",
                },
                {
                    "name": "compute_dti",
                    "operation": "feature_engineering",
                    "inputs": ["joined_data"],
                    "outputs": ["final_features"],
                },
            ]

        The server reconstructs the full DAG from these steps,
        showing exactly which tables and columns fed into the model.

    Returns
    -------
    UploadResult
        Dashboard URL where results can be viewed.
    """
    if not _API_KEY:
        raise ValueError("Call attestant.configure(api_key=...) first.")

    if age_column and age_format:
        fmt_map = {
            "years": "age_years",
            "months": "age_months",
            "days": "age_days",
            "dob": "dob",
            "birth_year": "birth_year",
        }
        if age_format not in fmt_map:
            raise ValueError(
                "age_format must be one of: %s (got %r)"
                % (", ".join(sorted(fmt_map)), age_format)
            )
        protected_column_types = dict(protected_column_types or {})
        protected_column_types[age_column] = fmt_map[age_format]

    from .wrapper import _resolve_inputs, _run_local_predict, _serialize, _post_json

    X_train_r, y_train_r, X_test_r, y_test_r, protected_df = _resolve_inputs(
        train_df=train_df, test_df=test_df, label_column=label_column,
        X_train=X_train, y_train=y_train, X_test=X_test, y_test=y_test,
        protected_columns=protected_columns,
    )

    if predictions is None:
        if model is None:
            raise ValueError("Either model= or predictions= must be provided.")
        predictions = _run_local_predict(model, X_test_r)

    from .wrapper import _compute_model_hash
    import numpy as _np

    model_hash = _compute_model_hash(model) if model is not None else None

    payload: Dict[str, Any] = {
        "model_name": model_name,
        "model_version": model_version,
        "X_test": _serialize(X_test_r),
        "y_test": _serialize(y_test_r),
        "predictions": _serialize(_np.asarray(predictions)),
        "protected_data": _serialize(protected_df),
        "protected_columns": list(protected_columns),
        "metadata": metadata,
    }
    if model_hash is not None:
        payload["model_hash"] = model_hash
    if model is not None and hasattr(model, "feature_importances_"):
        try:
            payload["feature_importances"] = [float(v) for v in model.feature_importances_]
        except Exception:
            pass
    try:
        import pandas as _pd
        if isinstance(X_test_r, _pd.DataFrame):
            payload["feature_columns"] = sorted(list(X_test_r.columns))
    except Exception:
        pass
    if age_column is not None and not protected_column_types:
        protected_column_types = {age_column: "age_years"}
    if protected_column_types:
        payload["protected_column_types"] = protected_column_types
    if X_train_r is not None:
        payload["X_train"] = _serialize(X_train_r)
    if y_train_r is not None:
        payload["y_train"] = _serialize(y_train_r)
    if compliance_profile is not None:
        payload["compliance_profile"] = compliance_profile
    if di_threshold is not None:
        payload["di_threshold"] = di_threshold
    if regulations is not None:
        payload["regulations"] = regulations
    if data_sources:
        payload["data_sources"] = data_sources
    if pipeline_steps:
        payload["pipeline_steps"] = pipeline_steps

    # Include source provenance from attestant.source() registrations
    from .wrapper import _registry
    source_mapping = _registry.get_source_mapping()
    source_snapshots = _registry.build_source_snapshots(X_test_r)
    try:
        column_provenance = _registry.resolve(X_test_r) if hasattr(X_test_r, 'columns') else {}
    except Exception:
        column_provenance = {}
    if source_mapping:
        payload["source_mapping"] = source_mapping
    if source_snapshots:
        payload["source_snapshots"] = source_snapshots
    if column_provenance:
        payload["column_provenance"] = column_provenance

    url = "%s/v1/upload" % _SERVICE_URL
    try:
        resp: Dict[str, Any] = _post_json(url, _API_KEY, payload)
    except urllib.error.URLError as e:
        raise ConnectionError(
            "Could not reach Attestant at %s: %s" % (_SERVICE_URL, e)
        ) from e

    dashboard_url = resp.get(
        "dashboard_url", "%s/client/models/%s" % (_SERVICE_URL, model_name)
    )
    model_id = resp.get("model_id", "")

    try:
        from .wrapper import _sync_prov
        _sync_prov(
            X=X_test_r, y=y_test_r, protected_data=protected_df,
            protected_columns=list(protected_columns),
            model_name=model_name, model_version=model_version,
            api_key=_API_KEY, service_url=_SERVICE_URL, model_id=model_id,
        )
    except Exception as e:
        _logger.debug("[attestant] provenance upload: %s", e)

    # Clear the provenance registry after upload so the next pipeline
    # run starts fresh (no stale source registrations leak across runs).
    _registry.clear()

    return UploadResult(dashboard_url=dashboard_url, model_id=model_id)


def status() -> StatusInfo:
    """Check connectivity to Attestant."""
    url = "%s/v1/health" % _SERVICE_URL
    start = time.monotonic()
    try:
        req = urllib.request.Request(
            url, method="GET",
            headers={"User-Agent": "attestant-python/%s" % __version__},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        ms = (time.monotonic() - start) * 1000
        return StatusInfo(connected=True, version=data.get("version", ""), latency_ms=round(ms, 1))
    except Exception as e:
        ms = (time.monotonic() - start) * 1000
        return StatusInfo(connected=False, latency_ms=round(ms, 1), error=str(e))
