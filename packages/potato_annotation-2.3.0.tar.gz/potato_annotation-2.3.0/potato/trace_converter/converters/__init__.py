"""
Trace format converters.
"""
