"""
Web Agent Recording API Routes

Provides endpoints for the web agent creation mode:
- Session management (start/end recording sessions)
- Step saving (capture individual interaction steps)
- Screenshot capture and storage
"""

import json
import logging
import os
import time
import uuid
from typing import Dict, Any

from flask import Blueprint, request, jsonify, current_app

logger = logging.getLogger(__name__)

web_agent_bp = Blueprint('web_agent', __name__)

# In-memory session storage (per-process)
_sessions: Dict[str, Dict[str, Any]] = {}


@web_agent_bp.route('/api/web_agent/start_session', methods=['POST'])
def start_session():
    """Initialize a new web agent recording session."""
    data = request.get_json(silent=True) or {}
    url = data.get('url', '')

    session_id = str(uuid.uuid4())[:8]
    _sessions[session_id] = {
        'id': session_id,
        'start_url': url,
        'start_time': time.time(),
        'steps': [],
        'screenshots_dir': None,
    }

    # Create screenshots directory
    task_dir = current_app.config.get('task_dir', '.')
    screenshots_dir = os.path.join(task_dir, 'recordings', session_id, 'screenshots')
    os.makedirs(screenshots_dir, exist_ok=True)
    _sessions[session_id]['screenshots_dir'] = screenshots_dir

    logger.info(f"Started recording session {session_id} for {url}")

    return jsonify({
        'session_id': session_id,
        'status': 'recording',
    })


@web_agent_bp.route('/api/web_agent/save_step', methods=['POST'])
def save_step():
    """Save a recorded interaction step."""
    data = request.get_json(silent=True) or {}
    session_id = data.get('session_id', '')
    step = data.get('step', {})

    session = _sessions.get(session_id)
    if not session:
        return jsonify({'error': 'Unknown session'}), 404

    session['steps'].append(step)

    return jsonify({
        'status': 'ok',
        'step_count': len(session['steps']),
    })


@web_agent_bp.route('/api/web_agent/save_screenshot', methods=['POST'])
def save_screenshot():
    """Upload a screenshot for a recording step."""
    session_id = request.form.get('session_id', request.args.get('session_id', ''))
    step_index = request.form.get('step_index', request.args.get('step_index', '0'))

    session = _sessions.get(session_id)
    if not session:
        return jsonify({'error': 'Unknown session'}), 404

    screenshots_dir = session.get('screenshots_dir', '')
    if not screenshots_dir:
        return jsonify({'error': 'No screenshots directory'}), 500

    # Handle file upload
    if 'screenshot' in request.files:
        file = request.files['screenshot']
        filename = f'step_{int(step_index):03d}.png'
        filepath = os.path.join(screenshots_dir, filename)
        file.save(filepath)
        rel_path = os.path.relpath(filepath, current_app.config.get('task_dir', '.'))
        return jsonify({'screenshot_url': rel_path, 'status': 'ok'})

    # Handle base64 data
    data = request.get_json(silent=True) or {}
    b64_data = data.get('screenshot_data', '')
    if b64_data:
        import base64
        filename = f'step_{int(step_index):03d}.png'
        filepath = os.path.join(screenshots_dir, filename)
        with open(filepath, 'wb') as f:
            f.write(base64.b64decode(b64_data))
        rel_path = os.path.relpath(filepath, current_app.config.get('task_dir', '.'))
        return jsonify({'screenshot_url': rel_path, 'status': 'ok'})

    return jsonify({'error': 'No screenshot data'}), 400


@web_agent_bp.route('/api/web_agent/end_session', methods=['POST'])
def end_session():
    """Finalize a recording session and save trace data."""
    data = request.get_json(silent=True) or {}
    session_id = data.get('session_id', '')
    final_steps = data.get('steps', None)

    session = _sessions.get(session_id)
    if not session:
        return jsonify({'error': 'Unknown session'}), 404

    # Use provided steps or session's accumulated steps
    steps = final_steps if final_steps is not None else session['steps']

    # Build trace data
    trace = {
        'id': f'recording_{session_id}',
        'task_description': data.get('task_description', ''),
        'site': session.get('start_url', ''),
        'steps': steps,
    }

    # Save to file
    task_dir = current_app.config.get('task_dir', '.')
    recordings_dir = os.path.join(task_dir, 'recordings', session_id)
    os.makedirs(recordings_dir, exist_ok=True)
    trace_path = os.path.join(recordings_dir, 'trace.json')

    with open(trace_path, 'w') as f:
        json.dump(trace, f, indent=2)

    # Clean up session
    del _sessions[session_id]

    logger.info(f"Ended recording session {session_id}, saved {len(steps)} steps")

    return jsonify({
        'status': 'saved',
        'trace_path': trace_path,
        'step_count': len(steps),
    })
