# peasy-convert

[![PyPI](https://img.shields.io/pypi/v/peasy-convert)](https://pypi.org/project/peasy-convert/)
[![Python](https://img.shields.io/pypi/pyversions/peasy-convert)](https://pypi.org/project/peasy-convert/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

Unified CLI for all Peasy developer tools. One `peasy` command that delegates to 8 specialized tool suites -- PDF manipulation, image processing, text analysis, CSS generation, file compression, document conversion, audio processing, and video editing. Install only the extras you need, or grab everything with `peasy-convert[all]`.

Built from [Peasy Tools](https://peasytools.com), the open-source developer tools platform with 200+ free browser-based utilities across 15 categories. Every CLI command mirrors a tool available at [peasytools.com](https://peasytools.com) -- use the web UI for quick one-off tasks, or the CLI for scripting and automation.

> **Try the interactive tools at [peasytools.com](https://peasytools.com)** -- [PDF Tools](https://peasypdf.com), [Image Tools](https://peasyimage.com), [Text Tools](https://peasytext.com), [CSS Tools](https://peasycss.com), [Compress Tools](https://peasytools.com), [Audio Tools](https://peasyaudio.com), [Video Tools](https://peasyvideo.com)

<p align="center">
  <img src="demo.gif" alt="peasy-convert demo — unified CLI with help and info commands" width="800">
</p>

## Table of Contents

- [Install](#install)
- [Quick Start](#quick-start)
- [How It Works](#how-it-works)
- [Available Tool Suites](#available-tool-suites)
  - [PDF Tools](#pdf-tools)
  - [Image Tools](#image-tools)
  - [Text Tools](#text-tools)
  - [CSS Tools](#css-tools)
  - [Compress Tools](#compress-tools)
  - [Document Tools](#document-tools)
  - [Audio Tools](#audio-tools)
  - [Video Tools](#video-tools)
- [Info Command](#info-command)
- [Command Reference](#command-reference)
- [Peasy Developer Tools](#peasy-developer-tools)
- [License](#license)

## Install

```bash
# Install with all 8 tool suites
pip install "peasy-convert[all]"

# Install specific tool suites only
pip install "peasy-convert[pdf]"        # PDF merge, split, compress, encrypt, rotate
pip install "peasy-convert[image]"      # Image resize, crop, convert, filter, watermark
pip install "peasy-convert[text]"       # Text case, slug, count, hash, encode, extract
pip install "peasy-convert[css]"        # CSS gradient, shadow, flexbox, grid, glass
pip install "peasy-convert[compress]"   # ZIP, TAR, gzip, bz2, lzma archive tools
pip install "peasy-convert[document]"   # Markdown, HTML, CSV, JSON conversion
pip install "peasy-convert[audio]"      # Audio convert, trim, merge, normalize, fade
pip install "peasy-convert[video]"      # Video trim, resize, extract audio, GIF

# Mix and match
pip install "peasy-convert[pdf,image,text]"
```

## Quick Start

```bash
# PDF operations — merge, split, compress, encrypt
peasy pdf merge report1.pdf report2.pdf -o combined.pdf
peasy pdf split document.pdf --ranges 1-5 -o section.pdf
peasy pdf compress large.pdf -o smaller.pdf
peasy pdf encrypt doc.pdf --password secret -o protected.pdf

# Image operations — resize, crop, convert, filter
peasy image resize photo.png --width 800 -o thumb.png
peasy image convert photo.png webp -o photo.webp
peasy image grayscale color.jpg -o bw.jpg
peasy image watermark photo.png "Copyright 2026" -o marked.png

# Text operations — case, encode, extract, analyze
peasy text case "hello world" --target upper
peasy text slug "Hello World! 2026"
peasy text count "Lorem ipsum dolor sit amet"
peasy text base64 encode "Hello World"

# CSS generation — gradient, shadow, layout, effects
peasy css gradient "#ff6b35" "#f7c948" "#2ec4b6"
peasy css shadow --y 4px --blur 12px --color "rgba(0,0,0,0.15)"
peasy css flexbox --justify center --align center --gap 1rem

# Compression — ZIP, TAR, gzip, bz2, lzma
peasy compress zip-create file1.txt file2.txt -o archive.zip
peasy compress gzip largefile.log -o compressed.log.gz
peasy compress tar-create src/ tests/ -o project.tar

# Document conversion — Markdown, HTML, CSV, JSON
peasy document md-to-html README.md -o output.html
peasy document csv-to-json data.csv -o data.json
peasy document html-to-markdown page.html -o page.md

# Audio processing — convert, trim, merge, normalize
peasy audio convert song.wav --format mp3 -o song.mp3
peasy audio trim podcast.mp3 --start 5000 --end 60000 -o clip.mp3
peasy audio normalize recording.mp3 --target-dbfs -20 -o normalized.mp3

# Video editing — trim, resize, GIF, extract audio
peasy video trim input.mp4 -o clip.mp4 --start 10 --end 30
peasy video resize input.mp4 -o small.mp4 --width 720
peasy video to-gif input.mp4 -o preview.gif --fps 10 --width 480
peasy video extract-audio video.mp4 -o audio.mp3
```

## How It Works

`peasy-convert` is the unified entry point for the Peasy CLI ecosystem. It uses [Typer](https://typer.tiangolo.com/) to mount sub-commands from each installed package at runtime:

```
peasy <suite> <command> [options]
  |       |        |
  |       |        +-- Specific operation (merge, resize, case, gradient, ...)
  |       +----------- Tool suite (pdf, image, text, css, compress, document, audio, video)
  +------------------- Single CLI entry point
```

Each tool suite is a standalone PyPI package with its own engine and CLI. When you install an extra like `peasy-convert[pdf]`, it pulls in `peasy-pdf` which registers its commands under `peasy pdf`. If a suite is not installed, its subcommand simply does not appear -- no errors, no bloat.

```python
# Under the hood — peasy-convert/cli.py
def _register_pdf() -> None:
    try:
        from peasy_pdf.cli import app as pdf_app
        app.add_typer(pdf_app, name="pdf", help="PDF tools")
    except ImportError:
        pass  # Not installed — skip silently
```

This architecture means you only install the dependencies you need. `peasy-convert[text]` pulls in zero heavy dependencies. `peasy-convert[pdf]` adds only `pypdf`. `peasy-convert[image]` adds `Pillow`. Pick what you need.

## Available Tool Suites

### PDF Tools

Install: `pip install "peasy-convert[pdf]"`

Powered by [peasy-pdf](https://pypi.org/project/peasy-pdf/) -- PDF manipulation with pypdf. 17 commands covering merging, splitting, page manipulation, text extraction, metadata, encryption, and compression.

| Command | Description |
|---------|-------------|
| `peasy pdf merge` | Merge multiple PDFs into one |
| `peasy pdf split` | Split PDF by page ranges or every N pages |
| `peasy pdf rotate` | Rotate pages by 90, 180, or 270 degrees |
| `peasy pdf reorder` | Reorder pages (e.g. `--order 3,1,2`) |
| `peasy pdf reverse` | Reverse the page order |
| `peasy pdf delete` | Delete specific pages |
| `peasy pdf extract` | Extract specific pages into a new PDF |
| `peasy pdf compress` | Reduce PDF file size |
| `peasy pdf resize` | Resize pages to A3, A4, A5, Letter, Legal, Tabloid |
| `peasy pdf crop` | Crop pages by removing margins |
| `peasy pdf flatten` | Flatten form fields (make non-editable) |
| `peasy pdf text` | Extract text content from pages |
| `peasy pdf info` | Show page count, size, encryption status, metadata |
| `peasy pdf metadata` | Get, set, or strip PDF metadata |
| `peasy pdf encrypt` | Password-protect a PDF |
| `peasy pdf decrypt` | Remove password protection |

```bash
# Merge quarterly reports into one annual PDF
peasy pdf merge Q1.pdf Q2.pdf Q3.pdf Q4.pdf -o annual-report.pdf

# Extract pages 5-10 and compress the result
peasy pdf extract full.pdf --pages 5-10 -o section.pdf
peasy pdf compress section.pdf -o section-small.pdf

# Encrypt with user and owner passwords
peasy pdf encrypt doc.pdf --password reader123 --owner admin456 -o secure.pdf
```

Learn more: [PeasyPDF Tools](https://peasypdf.com) · [peasy-pdf on PyPI](https://pypi.org/project/peasy-pdf/)

### Image Tools

Install: `pip install "peasy-convert[image]"`

Powered by [peasy-image](https://pypi.org/project/peasy-image/) -- image processing with Pillow. 14 commands for resizing, cropping, format conversion, filters, watermarks, and metadata stripping.

| Command | Description |
|---------|-------------|
| `peasy image resize` | Resize with aspect ratio preservation |
| `peasy image crop` | Crop to a bounding box |
| `peasy image rotate` | Rotate by any angle with configurable fill |
| `peasy image flip` | Flip horizontal, vertical, or both |
| `peasy image compress` | Reduce file size with quality control |
| `peasy image convert` | Convert between PNG, JPEG, WebP, GIF, BMP, TIFF |
| `peasy image grayscale` | Convert to grayscale |
| `peasy image blur` | Apply Gaussian blur |
| `peasy image sharpen` | Sharpen with adjustable factor |
| `peasy image watermark` | Add text watermark with position, opacity, color |
| `peasy image thumbnail` | Create square thumbnails |
| `peasy image border` | Add a colored border |
| `peasy image strip` | Remove EXIF metadata |
| `peasy image info` | Show dimensions, format, mode, EXIF, alpha channel |

```bash
# Resize a photo to 800px wide, maintaining aspect ratio
peasy image resize photo.jpg --width 800 -o photo-800.jpg

# Convert PNG to WebP for web optimization
peasy image convert screenshot.png webp -o screenshot.webp

# Add a watermark to a batch of images
for img in photos/*.jpg; do
  peasy image watermark "$img" "Copyright 2026" --opacity 100 -o "watermarked/$(basename $img)"
done
```

Learn more: [PeasyImage Tools](https://peasyimage.com) · [peasy-image on PyPI](https://pypi.org/project/peasy-image/)

### Text Tools

Install: `pip install "peasy-convert[text]"`

Powered by [peasytext](https://pypi.org/project/peasytext/) -- text analysis and transformation. 13 commands for case conversion, encoding, hashing, extraction, and formatting. All commands accept text as an argument or via stdin pipe.

| Command | Description |
|---------|-------------|
| `peasy text case` | Convert between upper, lower, title, camel, snake, kebab, pascal |
| `peasy text slug` | Generate URL-friendly slugs |
| `peasy text count` | Count characters, words, sentences, paragraphs, reading time |
| `peasy text sort` | Sort lines (alpha, length, numeric, reverse, shuffle) |
| `peasy text base64` | Base64 encode or decode |
| `peasy text url` | URL encode or decode |
| `peasy text html` | HTML entity encode or decode |
| `peasy text dedupe` | Remove duplicate lines |
| `peasy text extract` | Extract emails, URLs, phones, IPs, hashtags, mentions |
| `peasy text lorem` | Generate Lorem Ipsum placeholder text |
| `peasy text reverse` | Reverse by characters, words, or lines |
| `peasy text json` | Format, minify, or validate JSON |

```bash
# Convert variable names between coding conventions
peasy text case "getUserName" --target snake    # get_user_name
peasy text case "get_user_name" --target pascal # GetUserName

# Generate a URL slug from a blog title
peasy text slug "How to Build a REST API in 2026"  # how-to-build-a-rest-api-in-2026

# Extract all email addresses from a document
cat contacts.txt | peasy text extract emails

# Count words and estimate reading time
cat article.md | peasy text count
```

Learn more: [PeasyText Tools](https://peasytext.com) · [peasytext on PyPI](https://pypi.org/project/peasytext/)

### CSS Tools

Install: `pip install "peasy-convert[css]"`

Powered by [peasy-css](https://pypi.org/project/peasy-css/) -- CSS code generation with zero dependencies. 7 generators for gradients, shadows, layouts, and modern CSS effects. All output is syntax-highlighted in the terminal.

| Command | Description |
|---------|-------------|
| `peasy css gradient` | Linear, radial, or conic gradient with multiple color stops |
| `peasy css shadow` | Box shadow with offset, blur, spread, color, inset |
| `peasy css flexbox` | Flexbox layout with direction, wrap, justify, align, gap |
| `peasy css grid` | CSS Grid with columns, rows, gap |
| `peasy css border-radius` | Per-corner border radius |
| `peasy css glass` | Glassmorphism effect with backdrop blur |
| `peasy css clamp` | Fluid typography with `clamp()` for responsive font sizing |

```bash
# Generate a sunset gradient
peasy css gradient "#ff6b35" "#f7c948" "#2ec4b6" --direction "to bottom right"

# Create a neumorphic shadow
peasy css shadow --y 4px --blur 12px --color "rgba(0,0,0,0.15)" --selector ".card"

# Build a responsive grid layout
peasy css grid --columns "repeat(auto-fill, minmax(300px, 1fr))" --gap 2rem

# Generate fluid typography for headings
peasy css clamp --min 1.5rem --preferred 4vw --max 3rem --selector h1
```

Learn more: [PeasyCSS Generators](https://peasycss.com) · [peasy-css on PyPI](https://pypi.org/project/peasy-css/)

### Compress Tools

Install: `pip install "peasy-convert[compress]"`

Powered by [peasy-compress](https://pypi.org/project/peasy-compress/) -- archive and compression using only Python stdlib. Zero dependencies. 12 commands for ZIP, TAR, gzip, bz2, and lzma operations.

| Command | Description |
|---------|-------------|
| `peasy compress zip-create` | Create a ZIP archive from files |
| `peasy compress zip-extract` | Extract all files from a ZIP |
| `peasy compress zip-list` | List ZIP archive contents with sizes |
| `peasy compress tar-create` | Create a TAR archive (plain, gz, bz2, xz) |
| `peasy compress tar-extract` | Extract files from a TAR archive |
| `peasy compress tar-list` | List TAR archive contents |
| `peasy compress gzip` | Compress a file with gzip |
| `peasy compress gunzip` | Decompress a gzip file |
| `peasy compress bz2` | Compress a file with bz2 |
| `peasy compress bunzip2` | Decompress a bz2 file |
| `peasy compress xz` | Compress a file with lzma/xz |
| `peasy compress unxz` | Decompress an xz file |

```bash
# Create a ZIP archive of project files
peasy compress zip-create src/main.py src/utils.py README.md -o project.zip

# Compress a log file with gzip (level 9 = max compression)
peasy compress gzip access.log -o access.log.gz --level 9

# Create a compressed TAR archive
peasy compress tar-create *.py --compression gz -o scripts.tar.gz

# List contents of an archive without extracting
peasy compress zip-list project.zip
```

Learn more: [peasy-compress on PyPI](https://pypi.org/project/peasy-compress/)

### Document Tools

Install: `pip install "peasy-convert[document]"`

Powered by [peasy-document](https://pypi.org/project/peasy-document/) -- document format conversion between Markdown, HTML, CSV, and JSON. 6 conversion commands with stdin/stdout support.

| Command | Description |
|---------|-------------|
| `peasy document md-to-html` | Convert Markdown to HTML |
| `peasy document html-to-text` | Strip HTML tags, extract plain text |
| `peasy document html-to-markdown` | Convert HTML to Markdown |
| `peasy document csv-to-json` | Convert CSV to JSON array |
| `peasy document json-to-csv` | Convert JSON array of objects to CSV |
| `peasy document csv-to-markdown` | Convert CSV to a Markdown table |

```bash
# Convert a README to HTML for web publishing
peasy document md-to-html README.md -o index.html

# Convert CSV data to JSON for API consumption
peasy document csv-to-json users.csv -o users.json

# Generate a Markdown table from CSV data
peasy document csv-to-markdown metrics.csv -o metrics-table.md

# Strip HTML to plain text for indexing
peasy document html-to-text page.html -o content.txt
```

Learn more: [peasy-document on PyPI](https://pypi.org/project/peasy-document/)

### Audio Tools

Install: `pip install "peasy-convert[audio]"`

Powered by [peasy-audio](https://pypi.org/project/peasy-audio/) -- audio processing with pydub. Requires FFmpeg on your system. 9 commands for format conversion, trimming, merging, normalization, and effects.

| Command | Description |
|---------|-------------|
| `peasy audio convert` | Convert between MP3, WAV, OGG, FLAC, AAC |
| `peasy audio trim` | Trim to a time range (start/end in milliseconds) |
| `peasy audio merge` | Merge multiple audio files into one |
| `peasy audio normalize` | Normalize volume to a target dBFS level |
| `peasy audio volume` | Adjust volume by a specified number of decibels |
| `peasy audio fade` | Apply fade-in and/or fade-out effects |
| `peasy audio reverse` | Reverse audio playback |
| `peasy audio speed` | Change playback speed |
| `peasy audio info` | Show duration, channels, sample rate, bitrate, file size |

```bash
# Convert WAV to MP3 at 192kbps
peasy audio convert recording.wav --format mp3 --bitrate 192k -o recording.mp3

# Trim a podcast to the first 60 seconds
peasy audio trim episode.mp3 --start 0 --end 60000 -o intro.mp3

# Normalize volume and add fade effects
peasy audio normalize raw.mp3 --target-dbfs -20 -o normalized.mp3
peasy audio fade normalized.mp3 --fade-in 2000 --fade-out 3000 -o final.mp3

# Merge multiple clips into one file
peasy audio merge intro.mp3 main.mp3 outro.mp3 -o full-episode.mp3
```

Learn more: [PeasyAudio Tools](https://peasyaudio.com) · [peasy-audio on PyPI](https://pypi.org/project/peasy-audio/)

### Video Tools

Install: `pip install "peasy-convert[video]"`

Powered by [peasy-video](https://pypi.org/project/peasy-video/) -- video processing with moviepy. Requires FFmpeg on your system. 8 commands for trimming, resizing, audio extraction, GIF conversion, and concatenation.

| Command | Description |
|---------|-------------|
| `peasy video info` | Show duration, resolution, FPS, audio, frame count, file size |
| `peasy video trim` | Trim to a time range (start/end in seconds) |
| `peasy video resize` | Resize with aspect ratio preservation |
| `peasy video extract-audio` | Extract audio track as MP3, WAV, OGG, or AAC |
| `peasy video thumbnail` | Capture a single frame as PNG |
| `peasy video speed` | Change playback speed |
| `peasy video to-gif` | Convert video to animated GIF |
| `peasy video concat` | Concatenate multiple videos |

```bash
# Trim a screencast to the relevant portion
peasy video trim recording.mp4 -o clip.mp4 --start 15 --end 120

# Create a GIF preview for a README
peasy video to-gif demo.mp4 -o demo.gif --fps 12 --width 800

# Extract audio from a video lecture
peasy video extract-audio lecture.mp4 -o lecture.mp3 --format mp3

# Concatenate day 1 and day 2 footage
peasy video concat day1.mp4 day2.mp4 -o full.mp4
```

Learn more: [PeasyVideo Tools](https://peasyvideo.com) · [peasy-video on PyPI](https://pypi.org/project/peasy-video/)

## Info Command

Check which tool suites are installed and their versions:

```bash
peasy info
```

Output:

```
Peasy Convert — Installed packages:

  peasy-convert  0.1.0
  peasy-pdf      0.1.0
  peasy-image    0.1.0
  peasytext      0.1.0
  peasy-css      0.1.0

Install extras: pip install 'peasy-convert[all]'
```

Uninstalled packages show `(not installed)` so you can see exactly what is available.

## Command Reference

Complete list of all 86 commands across 8 tool suites:

| Suite | Commands | Dependencies |
|-------|----------|--------------|
| `peasy pdf` | merge, split, rotate, reorder, reverse, delete, extract, compress, resize, crop, flatten, text, info, metadata, encrypt, decrypt | pypdf |
| `peasy image` | resize, crop, rotate, flip, compress, convert, grayscale, blur, sharpen, watermark, thumbnail, border, strip, info | Pillow |
| `peasy text` | case, slug, count, sort, base64, url, html, dedupe, extract, lorem, reverse, json | (none) |
| `peasy css` | gradient, shadow, flexbox, grid, border-radius, glass, clamp | (none) |
| `peasy compress` | zip-create, zip-extract, zip-list, tar-create, tar-extract, tar-list, gzip, gunzip, bz2, bunzip2, xz, unxz | (none) |
| `peasy document` | md-to-html, html-to-text, html-to-markdown, csv-to-json, json-to-csv, csv-to-markdown | markdown |
| `peasy audio` | convert, trim, merge, normalize, volume, fade, reverse, speed, info | pydub, FFmpeg |
| `peasy video` | info, trim, resize, extract-audio, thumbnail, speed, to-gif, concat | moviepy, FFmpeg |

## Peasy Developer Tools

| Package | PyPI | npm | Description |
|---------|------|-----|-------------|
| peasytext | [PyPI](https://pypi.org/project/peasytext/) | [npm](https://www.npmjs.com/package/peasytext) | Text analysis -- case, encoding, hashing, diff -- [peasytext.com](https://peasytext.com) |
| peasy-pdf | [PyPI](https://pypi.org/project/peasy-pdf/) | [npm](https://www.npmjs.com/package/peasy-pdf) | PDF processing -- merge, split, compress, rotate -- [peasypdf.com](https://peasypdf.com) |
| peasy-image | [PyPI](https://pypi.org/project/peasy-image/) | [npm](https://www.npmjs.com/package/peasy-image) | Image ops -- resize, crop, convert, filter -- [peasyimage.com](https://peasyimage.com) |
| peasy-css | [PyPI](https://pypi.org/project/peasy-css/) | [npm](https://www.npmjs.com/package/peasy-css) | CSS generation -- gradients, shadows, flexbox, grid -- [peasycss.com](https://peasycss.com) |
| peasy-compress | [PyPI](https://pypi.org/project/peasy-compress/) | [npm](https://www.npmjs.com/package/peasy-compress) | Archive & compression -- ZIP, TAR, gzip, bz2, lzma -- [peasytools.com](https://peasytools.com) |
| peasy-document | [PyPI](https://pypi.org/project/peasy-document/) | [npm](https://www.npmjs.com/package/peasy-document) | Document conversion -- Markdown, HTML, CSV, JSON -- [peasytools.com](https://peasytools.com) |
| peasy-audio | [PyPI](https://pypi.org/project/peasy-audio/) | -- | Audio processing -- convert, trim, merge, normalize -- [peasyaudio.com](https://peasyaudio.com) |
| peasy-video | [PyPI](https://pypi.org/project/peasy-video/) | -- | Video editing -- trim, resize, GIF, extract audio -- [peasyvideo.com](https://peasyvideo.com) |
| **peasy-convert** | **[PyPI](https://pypi.org/project/peasy-convert/)** | -- | **Unified CLI -- all 8 tool suites in one `peasy` command** |
| peasy-mcp | [PyPI](https://pypi.org/project/peasy-mcp/) | -- | Unified MCP server for AI assistants (Claude, Cursor, Windsurf) |

Part of the [Peasy](https://peasytools.com) developer tools ecosystem -- 200+ free tools across 15 categories.

## License

MIT
