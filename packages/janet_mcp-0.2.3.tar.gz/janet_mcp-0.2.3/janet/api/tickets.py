"""Ticket API methods."""

from typing import List, Dict, Optional

from janet.api.client import APIClient
from janet.config.manager import ConfigManager


class TicketAPI(APIClient):
    """API methods for ticket management."""

    def __init__(self, config_manager: ConfigManager):
        """
        Initialize ticket API.

        Args:
            config_manager: Configuration manager instance
        """
        super().__init__(config_manager)

    def list_tickets(
        self,
        project_id: str,
        limit: int = 1000,
        offset: int = 0,
        show_resolved: bool = True,
        statuses: Optional[List[str]] = None,
        assignees: Optional[List[str]] = None,
        keyword: Optional[str] = None,
        priorities: Optional[List[str]] = None,
        issue_types: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        order_by: Optional[str] = None,
        created_after: Optional[str] = None,
        created_before: Optional[str] = None,
        updated_after: Optional[str] = None,
        updated_before: Optional[str] = None,
        due_before: Optional[str] = None,
        due_after: Optional[str] = None,
        in_status_for_days: Optional[int] = None,
    ) -> Dict:
        """
        List tickets for a project.

        Args:
            project_id: Project ID
            limit: Maximum tickets to return
            offset: Pagination offset
            show_resolved: Include resolved tickets older than 7 days
            statuses: Filter to only these status values
            assignees: Filter to tickets assigned to these emails
            keyword: Search text across title, description, comments
            priorities: Filter to these priority values
            issue_types: Filter to these issue types
            tags: Filter to tickets with these tags
            order_by: Sort order (created, last_updated, status, priority, due_date)

        Returns:
            Dictionary with tickets and metadata

        Raises:
            NetworkError: If API request fails
        """
        endpoint = f"/api/v1/projects/{project_id}/tickets/list"

        data: Dict = {
            "limit": limit,
            "offset": offset,
            "show_resolved_over_7_days": show_resolved,
        }
        if statuses:
            data["statuses"] = statuses
        if assignees:
            data["assignees"] = assignees
        if keyword:
            data["keyword"] = keyword
        if priorities:
            data["priorities"] = priorities
        if issue_types:
            data["issue_types"] = issue_types
        if tags:
            data["tags"] = tags
        if order_by:
            data["order_by"] = order_by
        if created_after:
            data["created_after"] = created_after
        if created_before:
            data["created_before"] = created_before
        if updated_after:
            data["updated_after"] = updated_after
        if updated_before:
            data["updated_before"] = updated_before
        if due_before:
            data["due_before"] = due_before
        if due_after:
            data["due_after"] = due_after
        if in_status_for_days:
            data["in_status_for_days"] = in_status_for_days

        response = self.post(endpoint, data=data, include_org=True)

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to list tickets"))

        return response

    def semantic_search(self, project_id: str, query: str, limit: int = 20) -> List[Dict]:
        """
        Semantic/conceptual search for tickets using Pinecone + LLM re-ranking.

        Args:
            project_id: Project UUID to scope the search
            query: Natural language search query
            limit: Max results to return

        Returns:
            List of ticket dictionaries ordered by relevance

        Raises:
            NetworkError: If API request fails
        """
        response = self.post(
            f"/api/v1/projects/{project_id}/tickets/semantic-search",
            data={"query": query, "limit": limit},
            include_org=True,
        )
        if not response.get("success"):
            raise Exception(response.get("error", "Semantic search failed"))
        return response.get("tickets", [])

    def get_ticket_by_key(self, project_key: str, ticket_num: int) -> Dict:
        """Get a ticket by its human-readable key (e.g. HL, 64).

        Returns dict with: ticket (full details), project_id, project_key, ticket_identifier.
        """
        response = self.get(
            f"/api/v1/tickets/by-key/{project_key}/{ticket_num}",
            include_org=True,
        )
        if not response.get("success"):
            raise Exception(response.get("error", "Ticket not found"))
        return response

    def get_ticket(self, ticket_id: str) -> Dict:
        """
        Get full ticket details.

        Args:
            ticket_id: Ticket ID

        Returns:
            Ticket dictionary with all fields

        Raises:
            NetworkError: If API request fails
        """
        response = self.get(f"/api/v1/tickets/{ticket_id}", include_org=True)

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to fetch ticket"))

        return response.get("ticket", {})

    def cli_batch_fetch(self, ticket_ids: List[str]) -> List[Dict]:
        """
        Fetch multiple tickets using CLI unlimited endpoint - NO 500 LIMIT.

        Args:
            ticket_ids: List of ticket IDs (unlimited)

        Returns:
            List of ticket dictionaries

        Raises:
            NetworkError: If API request fails
        """
        if not ticket_ids:
            return []

        data = {"ticket_ids": ticket_ids}
        response = self.post("/api/v1/cli/tickets/batch", data=data, include_org=True)

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to batch fetch tickets"))

        return response.get("tickets", [])

    def batch_fetch(self, ticket_ids: List[str]) -> List[Dict]:
        """
        Fetch multiple tickets in one request.

        Args:
            ticket_ids: List of ticket IDs

        Returns:
            List of ticket dictionaries

        Raises:
            NetworkError: If API request fails
        """
        if not ticket_ids:
            return []

        data = {"ticket_ids": ticket_ids}
        response = self.post("/api/v1/tickets/batch", data=data, include_org=True)

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to batch fetch tickets"))

        return response.get("tickets", [])

    def sync_all_tickets(self, project_id: str) -> Dict:
        """
        Get ALL tickets for a project using the CLI sync endpoint - NO LIMIT.

        Uses dedicated CLI endpoint that returns all tickets in one call.

        Args:
            project_id: Project ID

        Returns:
            Dictionary with ALL tickets (no pagination)

        Raises:
            NetworkError: If API request fails
        """
        endpoint = f"/api/v1/cli/projects/{project_id}/tickets/sync"

        data = {
            "show_resolved_over_7_days": True,
        }

        response = self.post(endpoint, data=data, include_org=True)

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to sync tickets"))

        return response

    def get_ticket_attachments(self, ticket_id: str) -> Dict:
        """
        Get attachments for a ticket.

        Args:
            ticket_id: Ticket ID

        Returns:
            Dictionary with direct and indirect attachments

        Raises:
            NetworkError: If API request fails
        """
        response = self.get(
            f"/api/v1/attachments/record/ticket/{ticket_id}", include_org=True
        )

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to fetch attachments"))

        return {
            "direct_attachments": response.get("direct_attachments", []),
            "indirect_attachments": response.get("indirect_attachments", []),
        }

    def batch_fetch_attachments(self, ticket_ids: List[str]) -> Dict[str, Dict]:
        """
        Batch fetch attachments for multiple tickets in one request.

        Args:
            ticket_ids: List of ticket IDs

        Returns:
            Dictionary mapping ticket_id to attachments dict

        Raises:
            NetworkError: If API request fails
        """
        if not ticket_ids:
            return {}

        response = self.post(
            "/api/v1/attachments/batch/tickets",
            data={"ticket_ids": ticket_ids},
            include_org=True,
        )

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to batch fetch attachments"))

        return response.get("attachments_by_ticket", {})

    def create_ticket(
        self,
        project_id: str,
        title: str,
        description: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        issue_type: Optional[str] = None,
        assignees: Optional[List[str]] = None,
        labels: Optional[List[str]] = None,
    ) -> Dict:
        """
        Create a new ticket.

        Args:
            project_id: Project ID to create ticket in
            title: Ticket title (required)
            description: Ticket description
            status: Status (e.g., "To Do", "In Progress")
            priority: Priority (Low, Medium, High, Critical)
            issue_type: Type (Task, Bug, Story, Epic)
            assignees: List of assignee emails
            labels: List of label strings

        Returns:
            Dictionary with created ticket details including ticket_key

        Raises:
            NetworkError: If API request fails
        """
        payload: Dict = {
            "project_id": project_id,
            "title": title,
        }

        if description:
            payload["description"] = description
        if status:
            payload["status"] = status
        if priority:
            payload["priority"] = priority
        if issue_type:
            payload["issue_type"] = issue_type
        if assignees:
            payload["assignees"] = assignees
        if labels:
            payload["labels"] = labels

        response = self.post("/api/v1/tickets", data=payload, include_org=True)

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to create ticket"))

        return response

    def update_ticket(
        self,
        ticket_id: str,
        title: Optional[str] = None,
        description: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        issue_type: Optional[str] = None,
        assignees: Optional[List[str]] = None,
        labels: Optional[List[str]] = None,
        due_date: Optional[str] = None,
    ) -> Dict:
        """
        Update an existing ticket.

        Args:
            ticket_id: Ticket ID (UUID) to update
            title: New ticket title
            description: New ticket description
            status: New status (e.g., "To Do", "In Progress", "Done")
            priority: New priority (Low, Medium, High, Critical)
            issue_type: New type (Task, Bug, Story, Epic)
            assignees: New list of assignee emails (replaces existing)
            labels: New list of labels (replaces existing)
            due_date: New due date (ISO format)

        Returns:
            Dictionary with update result

        Raises:
            NetworkError: If API request fails
        """
        payload: Dict = {}

        if title is not None:
            payload["title"] = title
        if description is not None:
            payload["description"] = description
        if status is not None:
            payload["status"] = status
        if priority is not None:
            payload["priority"] = priority
        if issue_type is not None:
            payload["issue_type"] = issue_type
        if assignees is not None:
            payload["assignees"] = assignees
        if labels is not None:
            payload["labels"] = labels
        if due_date is not None:
            payload["due_date"] = due_date

        if not payload:
            raise Exception("No fields to update")

        response = self.put(f"/api/v1/tickets/{ticket_id}", data=payload, include_org=True)

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to update ticket"))

        return response

    def get_positions(self, project_id: str, status: Optional[str] = None) -> List[Dict]:
        """Get ticket IDs and positions for a project (lightweight, no cap).

        Args:
            project_id: Project ID
            status: Optional status filter

        Returns:
            List of {ticket_id, ticket_key, status, position}
        """
        endpoint = f"/api/v1/projects/{project_id}/positions"
        if status:
            endpoint += f"?status={status}"
        response = self.get(endpoint, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to get positions"))
        return response.get("positions", [])

    def sort_column(self, project_id: str, status: str, sort_by: str = "priority", reverse: bool = False) -> Dict:
        """Sort all tickets in a status column by a field, server-side."""
        payload = {"status": status, "sort_by": sort_by, "reverse": reverse}
        response = self.post(f"/api/v1/projects/{project_id}/positions/sort", data=payload, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to sort column"))
        return response

    def set_position(self, ticket_id: str, position: str, status: str) -> Dict:
        """Set explicit position for a ticket in a status column."""
        payload = {"position": position, "new_status": status}
        response = self.put(f"/api/v1/tickets/{ticket_id}/position", data=payload, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to set ticket position"))
        return response

    def bulk_set_positions(self, tickets: List[Dict]) -> Dict:
        """Set positions for multiple tickets in one request.

        Args:
            tickets: List of dicts with ticket_id, position, status
        """
        payload = {"tickets": tickets}
        response = self.put("/api/v1/tickets/positions/bulk", data=payload, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to bulk update positions"))
        return response

    def move_to_top(self, ticket_id: str, status: str) -> Dict:
        """Move a ticket to the top of a status column."""
        payload = {"status": status}
        response = self.put(f"/api/v1/tickets/{ticket_id}/position/top", data=payload, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to move ticket to top"))
        return response

    def get_ticket_comments(self, ticket_id: str) -> List[Dict]:
        """
        Get comments for a ticket.

        Args:
            ticket_id: Ticket ID (UUID)

        Returns:
            List of comment dictionaries

        Raises:
            NetworkError: If API request fails
        """
        ticket = self.get_ticket(ticket_id)
        return ticket.get("comments", [])

    def add_comment(self, ticket_id: str, comment: str) -> Dict:
        """
        Add a comment to a ticket.

        Args:
            ticket_id: Ticket ID (UUID)
            comment: Comment text

        Returns:
            Dictionary with update result

        Raises:
            NetworkError: If API request fails
        """
        response = self.put(
            f"/api/v1/tickets/{ticket_id}",
            data={"comment": comment},
            include_org=True,
        )

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to add comment"))

        return response

    def edit_comment(self, ticket_id: str, comment_id: str, content: str) -> Dict:
        """
        Edit an existing comment.

        Args:
            ticket_id: Ticket ID (UUID)
            comment_id: Comment ID (UUID)
            content: New comment text

        Returns:
            Dictionary with update result

        Raises:
            NetworkError: If API request fails
        """
        response = self.put(
            f"/api/v1/tickets/{ticket_id}",
            data={"editComment": {"id": comment_id, "content": content}},
            include_org=True,
        )

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to edit comment"))

        return response

    def delete_comment(self, ticket_id: str, comment_id: str) -> Dict:
        """
        Delete a comment (soft delete).

        Args:
            ticket_id: Ticket ID (UUID)
            comment_id: Comment ID (UUID)

        Returns:
            Dictionary with update result

        Raises:
            NetworkError: If API request fails
        """
        response = self.put(
            f"/api/v1/tickets/{ticket_id}",
            data={"deleteComment": comment_id},
            include_org=True,
        )

        if not response.get("success"):
            raise Exception(response.get("error", "Failed to delete comment"))

        return response

    def delete_ticket(self, ticket_id: str) -> Dict:
        """Soft-delete a ticket. Child tasks are permanently hard-deleted."""
        return self.delete(f"/api/v1/tickets/{ticket_id}", include_org=True)

    def restore_ticket(self, ticket_id: str) -> Dict:
        """Restore a soft-deleted ticket."""
        return self.post(f"/api/v1/tickets/{ticket_id}/restore", include_org=True)

    def get_deleted_ticket_by_key(self, project_key: str, ticket_num: int) -> Dict:
        """Look up a soft-deleted ticket by its project key and number."""
        return self.get(
            f"/api/v1/tickets/deleted/by-key",
            params={"project_key": project_key.upper(), "ticket_num": str(ticket_num)},
            include_org=True,
        )
