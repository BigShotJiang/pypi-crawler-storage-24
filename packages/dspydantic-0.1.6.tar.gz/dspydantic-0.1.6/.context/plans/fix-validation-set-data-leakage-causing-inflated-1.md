# Fix: Validation set data leakage causing inflated 100% metrics

## Context

When testing dspydantic optimization, metrics stay at 100% while baseline is 89%. Investigation revealed two validation set bugs that cause data leakage — the DSPy optimizer trains and validates on the same data, producing artificially inflated scores.

## Bug 1: `_optimize_single_field` always leaks validation data (CRITICAL)

**File**: `src/dspydantic/optimizer.py`, lines 1046-1048

```python
split_idx = len(train_examples)
train_single = train_single[:split_idx]  # len is now exactly split_idx
val_single = val_single[split_idx:] if split_idx < len(train_single) else train_single
#                                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ ALWAYS False
# Result: val_single = train_single ALWAYS
```

After slicing `train_single` to `split_idx` length, the condition `split_idx < len(train_single)` is always False (equal, never less). So `val_single = train_single` — DSPy's `optimizer.compile(trainset=..., valset=...)` gets identical data for both.

**Fix**: Replace double `_prepare_dspy_examples` call + broken split with single call + correct split:

```python
all_single = self._prepare_dspy_examples(
    descriptions_override=single_field_descriptions,
)
split_idx = len(train_examples)
train_single = all_single[:split_idx]
val_single = all_single[split_idx:] if split_idx < len(all_single) else all_single
```

Key change: check against `len(all_single)` (original full length) instead of `len(train_single)` (already-sliced length).

## Bug 2: Non-sequential split edge case with few examples

**File**: `src/dspydantic/optimizer.py`, line 1706

```python
val_examples = trainset[split_idx:] if split_idx < len(trainset) else trainset
```

With 1 example, `split_idx = 1 = len(trainset)`, condition is False, `val_examples = trainset` — data leak. Add a warning when this happens.

**Fix**: Add `import warnings` and warn when validation falls back to training data:

```python
val_examples = trainset[split_idx:]
if not val_examples:
    warnings.warn(
        f"Not enough examples to create a separate validation set "
        f"({len(trainset)} examples with train_split={self.train_split}). "
        f"Using training set for validation — scores may be inflated.",
        UserWarning,
        stacklevel=2,
    )
    val_examples = trainset
```

## Files to modify

1. `src/dspydantic/optimizer.py` — Fix lines 1040-1048 and line 1706
2. `tests/unit/test_optimizer_validation_split.py` — New test file

## Verification

1. `pytest tests/unit/test_optimizer_validation_split.py -v` — new tests pass
2. `pytest tests/unit/ -v` — no regressions
3. Manual: re-run the user's optimization scenario — baseline and optimized scores should now diverge realistically
