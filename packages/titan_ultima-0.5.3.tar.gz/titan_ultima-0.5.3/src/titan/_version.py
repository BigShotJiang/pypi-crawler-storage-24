"""Titan package version (single source of truth)."""

__all__ = ["TITAN_VERSION", "__version__"]

__version__ = "0.5.3"
TITAN_VERSION = __version__
