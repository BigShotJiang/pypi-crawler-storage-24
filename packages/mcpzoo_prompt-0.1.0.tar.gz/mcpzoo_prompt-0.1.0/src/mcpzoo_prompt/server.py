import json
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("prompt")

@mcp.tool()
def gen_prompt(task: str, context: str = "", format_req: str = "", tone: str = "professional") -> str:
    """根据场景生成结构化的 AI 提示词框架。"""
    prompt = f"我要你扮演一个专业的助手，帮我完成【{task}】的任务。\n\n"
    if context:
        prompt += f"## 背景信息：\n{context}\n\n"
    if format_req:
        prompt += f"## 输出格式要求：\n{format_req}\n\n"
        
    prompt += f"## 语气要求：\n请保持 {tone} 的语气。\n\n"
    prompt += "## 具体指令：\n请根据上述要求，一步步思考并给出你的结果。"
    
    return prompt

def main():
    mcp.run()

if __name__ == "__main__":
    main()
