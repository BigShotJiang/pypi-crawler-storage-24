# mcpzoo-prompt

> 提示词模板 — 根据场景生成结构化的 AI 提示词

## Installation

```bash
uvx mcpzoo-prompt
```

## uvx JSON

```json
{
  "mcpServers": {
    "prompt": {
      "args": ["mcpzoo-prompt"],
      "command": "uvx"
    }
  }
}
```
