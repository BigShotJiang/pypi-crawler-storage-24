"""callycam GUI (Dear PyGui)."""
