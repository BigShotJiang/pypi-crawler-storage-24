from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


class ExportManager:
    """
    Export Antaris Agent data to a portable format.

    Methods:
      export_full(output_dir)      -- everything: identity + config + memories
      export_memories(output_file) -- memories as JSONL
      export_identity(output_dir)  -- just the MD files
    """

    IDENTITY_FILES = [
        "SOUL.md",
        "AGENTS.md",
        "MEMORY.md",
        "TOOLS.md",
        "USER.md",
        "HEARTBEAT.md",
        "IDENTITY.md",
    ]

    def __init__(
        self,
        source_dir: Optional[str] = None,
        memory_store: Optional[str] = None,
    ):
        from pathlib import Path as P
        self.source_dir = P(source_dir or P.home() / ".antarisbot")
        self.memory_store = P(memory_store or self.source_dir / "memory")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def export_full(self, output_dir: str) -> dict:
        """
        Export everything: identity files, config, memories, and learned data.

        Returns a summary dict with counts.
        """
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        summary: dict = {}

        # Identity files
        identity_count = self._export_identity_files(out)
        summary["identity_files"] = identity_count

        # Config files
        config_count = self._export_config_files(out)
        summary["config_files"] = config_count

        # Memory directory (raw shards + daily logs)
        mem_count = self._export_memory_dir(out)
        summary["memory_files"] = mem_count

        # Exports and teachings
        for subdir in ("exports", "teachings", "profiles", "shortcuts", "proactive"):
            src = self.source_dir / subdir
            if src.exists():
                dest = out / subdir
                shutil.copytree(str(src), str(dest), dirs_exist_ok=True)
                count = len(list(dest.rglob("*")))
                summary[subdir] = count

        # Write export manifest
        manifest = {
            "exported_at": datetime.now(tz=timezone.utc).isoformat(),
            "source": str(self.source_dir),
            "format": "antaris-export-v1",
            "summary": summary,
        }
        (out / "manifest.json").write_text(json.dumps(manifest, indent=2))

        return summary

    def export_memories(self, output_file: str) -> int:
        """
        Export all memories as JSONL (one JSON object per line).

        Returns count of exported entries.
        """
        out = Path(output_file)
        out.parent.mkdir(parents=True, exist_ok=True)

        entries: list[dict] = []

        # Try MemorySystem export first
        entries = self._collect_memories_from_store()

        # Fallback: read daily log .md files
        if not entries:
            entries = self._collect_memories_from_logs()

        with out.open("w") as f:
            for entry in entries:
                f.write(json.dumps(entry, default=str) + "\n")

        return len(entries)

    def export_identity(self, output_dir: str) -> int:
        """
        Export identity markdown files only.

        Returns count of files exported.
        """
        out = Path(output_dir)
        return self._export_identity_files(out)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _export_identity_files(self, out: Path) -> int:
        """Copy identity .md files to output dir. Returns count."""
        count = 0
        for name in self.IDENTITY_FILES:
            src = self.source_dir / name
            if src.exists():
                out.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(src), str(out / name))
                count += 1
        return count

    def _export_config_files(self, out: Path) -> int:
        """Copy config files to output dir. Returns count."""
        count = 0
        config_files = ["config.json", "context.json", "router/config.json"]
        for rel in config_files:
            src = self.source_dir / rel
            if src.exists():
                dest = out / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(src), str(dest))
                count += 1
        return count

    def _export_memory_dir(self, out: Path) -> int:
        """Copy memory directory contents. Returns file count."""
        src = self.memory_store
        if not src.exists():
            return 0
        dest = out / "memory"
        shutil.copytree(str(src), str(dest), dirs_exist_ok=True)
        return len([f for f in dest.rglob("*") if f.is_file()])

    def _collect_memories_from_store(self) -> list[dict]:
        """Collect memories using MemorySystem if available."""
        entries: list[dict] = []
        if not self.memory_store.exists():
            return entries

        try:
            from parsica_memory import MemorySystem
        except ImportError:
            return entries

        for user_dir in sorted(self.memory_store.iterdir()):
            if not user_dir.is_dir():
                continue
            user_id = user_dir.name
            try:
                ms = MemorySystem(workspace=str(user_dir))
                ms.load()
                results = ms.search("", limit=100_000)
                for r in results:
                    entries.append({
                        "user_id": user_id,
                        "content": getattr(r, "content", ""),
                        "source": getattr(r, "source", ""),
                        "category": getattr(r, "category", ""),
                        "relevance": getattr(r, "relevance", 0.0),
                        "timestamp": getattr(r, "timestamp", None),
                    })
            except Exception:
                continue

        return entries

    def _collect_memories_from_logs(self) -> list[dict]:
        """Collect memories from daily log .md files."""
        entries: list[dict] = []
        for md_file in sorted(self.memory_store.rglob("*.md")):
            content = md_file.read_text().strip()
            if content:
                entries.append({
                    "user_id": md_file.parent.name,
                    "content": content,
                    "source": "daily-log",
                    "category": "episodic",
                    "file": md_file.name,
                })
        return entries
