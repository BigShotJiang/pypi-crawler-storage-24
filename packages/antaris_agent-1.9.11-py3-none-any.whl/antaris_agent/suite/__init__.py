"""
antaris_agent.suite — Bundled suite packages for Antaris Agent.

- parsica_memory              (bundled, v2.7.0) — sole memory implementation
- antaris_agent.suite.guard   (antaris-guard v5.0.1)
- antaris_agent.suite.router  (antaris-router v5.0.1)
- antaris_agent.suite.context (antaris-context v5.0.1)
- antaris_agent.suite.pipeline (antaris-pipeline v5.0.1)

parsica_memory is the single source of truth for memory.
Import from parsica_memory directly.
"""

__version__ = "5.0.1"  # Must match component versions
