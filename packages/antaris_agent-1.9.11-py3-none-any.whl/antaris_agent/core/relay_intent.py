"""
antaris_agent.core.relay_intent
================================
Lightweight relay-intent detector for conversational framing.

Detects when a user is asking the agent to pass something along to a third
party ("tell Laina thanks", "let Jason know I'm good") and distinguishes that
from the case where the user explicitly wants a composed direct message
("write a message to Laina", "draft what I should send Chemist").

Output
------
RelayIntent dataclass:
    detected      bool   — True if a relay pattern was found
    mode          str    — "acknowledge" | "compose" | "none"
    target        str    — extracted third-party name (or "" if not found)
    content       str    — the relayed content / subject (or "" if not found)

Modes
-----
"acknowledge"  (Mode A) — default: agent stays in current-speaker frame.
                           e.g. "Tell Laina I said thanks" →
                           agent replies: "Got it, I'll let Laina know."

"compose"      (Mode B) — user explicitly wants a draft message to the third party.
                           e.g. "Write a message to Laina" →
                           agent composes a direct-address message.

"none"         — no relay intent detected; normal processing.

Design
------
Intentionally heuristic and dependency-free.  No NLP libraries required.
All detection is regex + keyword matching — fast, deterministic, zero latency.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

# ---------------------------------------------------------------------------
# Patterns: Mode A — acknowledgment / relay ("stay in current-speaker frame")
# ---------------------------------------------------------------------------

# "tell X ..." / "let X know ..." / "say X to ..." / "pass along to X ..."
_ACKNOWLEDGE_PATTERNS: list[re.Pattern] = [
    re.compile(
        r"^(?:please\s+)?(?:tell|ask|let|inform|notify|remind|message|ping)\s+"
        r"(?P<target>[A-Za-z][A-Za-z0-9_\-']{0,30})"
        r"(?:\s+(?:that|to|about|i said|i'm|I'm))?"
        r"(?P<rest>.*)",
        re.IGNORECASE,
    ),
    re.compile(
        r"^(?:please\s+)?(?:pass\s+(?:this|that|it|along|the\s+\w+)?\s*(?:along\s+)?to|forward\s+(?:this\s+)?to)\s+"
        r"(?P<target>[A-Za-z][A-Za-z0-9_\-']{0,30})"
        r"(?P<rest>.*)",
        re.IGNORECASE,
    ),
    re.compile(
        r"^(?:please\s+)?let\s+(?P<target>[A-Za-z][A-Za-z0-9_\-']{0,30})\s+know"
        r"(?P<rest>.*)",
        re.IGNORECASE,
    ),
    re.compile(
        r"^(?:please\s+)?(?:say|send|relay|convey)\s+(?:my\s+)?(?:thanks|regards|hello|hi|greetings|apologies|sorry)\s+to\s+"
        r"(?P<target>[A-Za-z][A-Za-z0-9_\-']{0,30})"
        r"(?P<rest>.*)",
        re.IGNORECASE,
    ),
    re.compile(
        r"(?:^|,\s*)(?:tell|let|inform|notify|ping)\s+(?P<target>[A-Za-z][A-Za-z0-9_\-']{0,30})\s+"
        r"(?:that\s+)?(?:i|we)\s+(?P<rest>.{4,})",
        re.IGNORECASE,
    ),
]

# ---------------------------------------------------------------------------
# Patterns: Mode B — compose / draft ("write a direct message to third party")
# ---------------------------------------------------------------------------

_COMPOSE_PATTERNS: list[re.Pattern] = [
    re.compile(
        r"^(?:please\s+)?(?:write|draft|compose|create|generate|make)\s+(?:a\s+)?(?:message|reply|response|note|dm|text)\s+"
        r"(?:to|for)\s+(?P<target>[A-Za-z][A-Za-z0-9_\-']{0,30})"
        r"(?P<rest>.*)",
        re.IGNORECASE,
    ),
    re.compile(
        r"^(?:how\s+(?:should|do)\s+i\s+(?:reply|respond|answer|say)\s+to)\s+"
        r"(?P<target>[A-Za-z][A-Za-z0-9_\-']{0,30})"
        r"(?P<rest>.*)",
        re.IGNORECASE,
    ),
    re.compile(
        r"^(?:what\s+should\s+i\s+(?:tell|say|write|send)\s+(?:to\s+)?)"
        r"(?P<target>[A-Za-z][A-Za-z0-9_\-']{0,30})"
        r"(?P<rest>.*)",
        re.IGNORECASE,
    ),
    re.compile(
        r"^(?:please\s+)?(?:draft|write)\s+what\s+(?:i\s+)?(?:should\s+(?:say|tell|send)|would\s+say)\s+"
        r"(?:to\s+)?(?P<target>[A-Za-z][A-Za-z0-9_\-']{0,30})"
        r"(?P<rest>.*)",
        re.IGNORECASE,
    ),
    # "Draft a message to tell Laina thanks" — to + verb + name
    re.compile(
        r"^(?:please\s+)?(?:write|draft|compose|create|generate|make)\s+(?:a\s+)?(?:message|reply|response|note|dm|text)\s+"
        r"(?:to\s+)?(?:tell|let|inform|ask|say to)\s+"
        r"(?P<target>[A-Za-z][A-Za-z0-9_\-']{0,30})"
        r"(?P<rest>.*)",
        re.IGNORECASE,
    ),
]

# ---------------------------------------------------------------------------
# Stop-words: common words that look like names but are not
# (prevents "tell me more", "let me know" false positives)
# ---------------------------------------------------------------------------

_NOT_A_NAME: frozenset[str] = frozenset({
    "me", "us", "them", "you", "him", "her", "it", "the", "a", "an",
    "that", "this", "my", "your", "their", "our", "his", "its",
    "everyone", "anyone", "someone", "no one", "nobody", "somebody",
    "all", "each", "every", "both", "either", "neither",
    "more", "less", "much", "many", "few", "some", "any",
    "what", "when", "where", "how", "why", "who", "which",
    # Relay verbs — can appear after "to" but are not names
    "tell", "let", "ask", "say", "inform", "notify", "ping", "remind",
    "pass", "send", "relay", "forward", "message", "write", "draft",
})


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

@dataclass
class RelayIntent:
    """Result of relay-intent detection."""
    detected: bool = False
    mode: str = "none"          # "acknowledge" | "compose" | "none"
    target: str = ""            # Third-party name
    content: str = ""           # Subject / relayed content


def detect_relay_intent(text: str) -> RelayIntent:
    """
    Analyse *text* for relay-intent patterns.

    Returns a :class:`RelayIntent` describing what was found.
    Runs in O(n·p) where n = text length, p = number of patterns (small constant).
    """
    stripped = text.strip()
    if not stripped:
        return RelayIntent()

    # Mode B takes priority — if the user explicitly wants a draft, honour that.
    for pat in _COMPOSE_PATTERNS:
        m = pat.search(stripped)
        if m:
            target = _clean_target(m.group("target"))
            if not target:
                continue
            rest = m.group("rest").strip() if "rest" in pat.groupindex else ""
            return RelayIntent(
                detected=True,
                mode="compose",
                target=target,
                content=_clean_content(rest),
            )

    # Mode A — acknowledgment relay
    for pat in _ACKNOWLEDGE_PATTERNS:
        m = pat.search(stripped)
        if m:
            target = _clean_target(m.group("target"))
            if not target:
                continue
            rest = m.group("rest").strip() if "rest" in pat.groupindex else ""
            return RelayIntent(
                detected=True,
                mode="acknowledge",
                target=target,
                content=_clean_content(rest),
            )

    return RelayIntent()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _clean_target(raw: str) -> str:
    """Normalise a captured target name; return '' if it looks like a stop-word."""
    cleaned = raw.strip().strip(".,;:!?\"'").strip()
    if cleaned.lower() in _NOT_A_NAME:
        return ""
    if len(cleaned) < 2:
        return ""
    return cleaned.capitalize()


def _clean_content(raw: str) -> str:
    """Strip leading connectors from captured content."""
    raw = raw.strip()
    # Remove leading conjunctions / prepositions left over from the pattern
    raw = re.sub(r"^(?:that|about|to|and|but|,)\s+", "", raw, flags=re.IGNORECASE)
    return raw.strip()


# ---------------------------------------------------------------------------
# System-prompt injection helper
# ---------------------------------------------------------------------------

def build_relay_context_block(intent: RelayIntent) -> str:
    """
    Return a short system-prompt block that tells the LLM what was detected.
    Only called when intent.detected is True.
    """
    if not intent.detected:
        return ""

    if intent.mode == "acknowledge":
        target_str = f" to {intent.target}" if intent.target else ""
        content_str = f': "{intent.content}"' if intent.content else ""
        return (
            f"## Relay intent detected (Mode A — acknowledgment)\n"
            f"The user wants to relay a message{target_str}{content_str}. "
            f"Stay addressed to the current speaker. "
            f"Confirm you'll pass it along (e.g. 'Got it, I'll let {intent.target or 'them'} know.'). "
            f"Do NOT switch to writing directly to {intent.target or 'the third party'}."
        )
    elif intent.mode == "compose":
        target_str = f"to {intent.target}" if intent.target else "to the third party"
        return (
            f"## Relay intent detected (Mode B — compose)\n"
            f"The user explicitly wants you to compose/draft a direct message {target_str}. "
            f"Write the message as if addressed directly to {intent.target or 'them'}."
        )
    return ""
