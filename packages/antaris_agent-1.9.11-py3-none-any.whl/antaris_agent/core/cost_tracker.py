"""
Antaris Agent Cost Tracker — per-conversation token usage and cost logging.

Tracks input_tokens, output_tokens, cost_usd, and message_count per user
and per channel. Persists to JSON automatically every N calls.
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_DEFAULT_SAVE_INTERVAL = 10


class CostTracker:
    """
    Track per-user and per-channel LLM token usage and cost.

    Usage:
        tracker = CostTracker(save_path=Path(...), save_interval=10)
        tracker.record(user_id, channel_id, input_tokens, output_tokens, cost_usd)
        stats = tracker.get_user_stats(user_id)
        tracker.save()
    """

    def __init__(
        self,
        save_path: Optional[Path] = None,
        save_interval: int = _DEFAULT_SAVE_INTERVAL,
        enabled: bool = True,
    ):
        self.save_path = Path(save_path) if save_path else None
        self.save_interval = max(1, save_interval)
        self.enabled = enabled

        # {user_id: {input_tokens, output_tokens, cost_usd, message_count}}
        self._users: dict[str, dict] = {}
        # {channel_id: {input_tokens, output_tokens, cost_usd, message_count}}
        self._channels: dict[str, dict] = {}
        # Global totals
        self._global: dict = {
            "input_tokens": 0,
            "output_tokens": 0,
            "cost_usd": 0.0,
            "message_count": 0,
        }
        # Auto-save counter
        self._calls_since_save: int = 0
        # Timestamp of last save
        self._last_saved: float = 0.0

        # Load from disk if path given and file exists
        if self.save_path and self.save_path.exists():
            self.load(self.save_path)

    # ── Core API ──────────────────────────────────────────────────────────

    def record(
        self,
        user_id: str,
        channel_id: str,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
    ) -> None:
        """Record a single LLM call's token usage and cost."""
        if not self.enabled:
            return
        try:
            # Coerce types defensively
            input_tokens = int(input_tokens or 0)
            output_tokens = int(output_tokens or 0)
            cost_usd = float(cost_usd or 0.0)
            user_id = str(user_id or "unknown")
            channel_id = str(channel_id or "unknown")

            # Per-user
            if user_id not in self._users:
                self._users[user_id] = {
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cost_usd": 0.0,
                    "message_count": 0,
                }
            u = self._users[user_id]
            u["input_tokens"] += input_tokens
            u["output_tokens"] += output_tokens
            u["cost_usd"] += cost_usd
            u["message_count"] += 1

            # Per-channel
            if channel_id not in self._channels:
                self._channels[channel_id] = {
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cost_usd": 0.0,
                    "message_count": 0,
                }
            c = self._channels[channel_id]
            c["input_tokens"] += input_tokens
            c["output_tokens"] += output_tokens
            c["cost_usd"] += cost_usd
            c["message_count"] += 1

            # Global
            self._global["input_tokens"] += input_tokens
            self._global["output_tokens"] += output_tokens
            self._global["cost_usd"] += cost_usd
            self._global["message_count"] += 1

            # Auto-save
            self._calls_since_save += 1
            if self._calls_since_save >= self.save_interval and self.save_path:
                self.save(self.save_path)
                self._calls_since_save = 0

        except Exception as e:
            logger.warning("CostTracker.record() failed silently: %s", e)

    def get_user_stats(self, user_id: str) -> dict:
        """Return token totals for a specific user. Returns zeroed dict if unseen."""
        try:
            base = self._users.get(str(user_id), {})
            return {
                "input_tokens": base.get("input_tokens", 0),
                "output_tokens": base.get("output_tokens", 0),
                "total_tokens": base.get("input_tokens", 0) + base.get("output_tokens", 0),
                "cost_usd": base.get("cost_usd", 0.0),
                "message_count": base.get("message_count", 0),
            }
        except Exception as e:
            logger.warning("CostTracker.get_user_stats() failed: %s", e)
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0, "cost_usd": 0.0, "message_count": 0}

    def get_channel_stats(self, channel_id: str) -> dict:
        """Return token totals for a specific channel. Returns zeroed dict if unseen."""
        try:
            base = self._channels.get(str(channel_id), {})
            return {
                "input_tokens": base.get("input_tokens", 0),
                "output_tokens": base.get("output_tokens", 0),
                "total_tokens": base.get("input_tokens", 0) + base.get("output_tokens", 0),
                "cost_usd": base.get("cost_usd", 0.0),
                "message_count": base.get("message_count", 0),
            }
        except Exception as e:
            logger.warning("CostTracker.get_channel_stats() failed: %s", e)
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0, "cost_usd": 0.0, "message_count": 0}

    def get_summary(self) -> dict:
        """Return global totals plus per-user and per-channel breakdowns."""
        try:
            return {
                "global": {
                    "input_tokens": self._global["input_tokens"],
                    "output_tokens": self._global["output_tokens"],
                    "total_tokens": self._global["input_tokens"] + self._global["output_tokens"],
                    "cost_usd": self._global["cost_usd"],
                    "message_count": self._global["message_count"],
                },
                "users": {
                    uid: {
                        **stats,
                        "total_tokens": stats["input_tokens"] + stats["output_tokens"],
                    }
                    for uid, stats in self._users.items()
                },
                "channels": {
                    cid: {
                        **stats,
                        "total_tokens": stats["input_tokens"] + stats["output_tokens"],
                    }
                    for cid, stats in self._channels.items()
                },
            }
        except Exception as e:
            logger.warning("CostTracker.get_summary() failed: %s", e)
            return {"global": {}, "users": {}, "channels": {}}

    # ── Persistence ───────────────────────────────────────────────────────

    def save(self, path: Optional[Path] = None) -> bool:
        """Persist current data to JSON. Returns True on success."""
        target = Path(path) if path else self.save_path
        if not target:
            return False
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "version": 1,
                "saved_at": time.time(),
                "global": dict(self._global),
                "users": {uid: dict(s) for uid, s in self._users.items()},
                "channels": {cid: dict(s) for cid, s in self._channels.items()},
            }
            tmp = target.parent / (target.name + ".tmp")
            with open(tmp, "w") as f:
                json.dump(payload, f, indent=2)
            tmp.replace(target)
            self._last_saved = time.time()
            logger.debug("CostTracker saved to %s", target)
            return True
        except Exception as e:
            logger.warning("CostTracker.save() failed: %s", e)
            return False

    def load(self, path: Optional[Path] = None) -> bool:
        """Load data from JSON. Returns True on success."""
        target = Path(path) if path else self.save_path
        if not target or not target.exists():
            return False
        try:
            with open(target) as f:
                payload = json.load(f)
            self._global = payload.get("global", self._global)
            # Ensure global has all keys
            for key in ("input_tokens", "output_tokens", "cost_usd", "message_count"):
                self._global.setdefault(key, 0)
            self._users = payload.get("users", {})
            self._channels = payload.get("channels", {})
            logger.debug(
                "CostTracker loaded from %s (%d users, %d channels)",
                target, len(self._users), len(self._channels),
            )
            return True
        except Exception as e:
            logger.warning("CostTracker.load() failed: %s", e)
            return False

    # ── Formatting helpers ────────────────────────────────────────────────

    def format_user_stats(self, user_id: str) -> str:
        """Return a human-readable stats block for a user."""
        try:
            stats = self.get_user_stats(user_id)
            if stats["message_count"] == 0:
                return f"No cost data recorded for user `{user_id}` yet."
            cost_cents = stats["cost_usd"] * 100
            return (
                f"**💰 Your Cost Stats**\n"
                f"Messages: {stats['message_count']:,}\n"
                f"Tokens in: {stats['input_tokens']:,}\n"
                f"Tokens out: {stats['output_tokens']:,}\n"
                f"Total tokens: {stats['total_tokens']:,}\n"
                f"Est. cost: ${stats['cost_usd']:.4f} ({cost_cents:.2f}¢)"
            )
        except Exception as e:
            logger.warning("CostTracker.format_user_stats() failed: %s", e)
            return "Could not retrieve cost stats."

    def format_global_summary(self) -> str:
        """Return a human-readable global summary."""
        try:
            summary = self.get_summary()
            g = summary["global"]
            if g.get("message_count", 0) == 0:
                return "No cost data recorded yet."

            lines = [
                "**📊 Global Cost Summary**",
                f"Total messages: {g['message_count']:,}",
                f"Total tokens: {g['total_tokens']:,}  (in: {g['input_tokens']:,} / out: {g['output_tokens']:,})",
                f"Total cost: ${g['cost_usd']:.4f}",
                "",
            ]

            # Top users by cost
            users = summary["users"]
            if users:
                sorted_users = sorted(users.items(), key=lambda x: x[1].get("cost_usd", 0), reverse=True)
                lines.append("**Top users by cost:**")
                for uid, s in sorted_users[:10]:
                    lines.append(
                        f"  `{uid}` — {s['message_count']} msgs, "
                        f"{s['input_tokens'] + s['output_tokens']:,} tokens, "
                        f"${s['cost_usd']:.4f}"
                    )

            # Top channels by cost
            channels = summary["channels"]
            if channels:
                sorted_ch = sorted(channels.items(), key=lambda x: x[1].get("cost_usd", 0), reverse=True)
                lines.append("")
                lines.append("**Top channels by cost:**")
                for cid, s in sorted_ch[:10]:
                    lines.append(
                        f"  `{cid}` — {s['message_count']} msgs, "
                        f"{s['input_tokens'] + s['output_tokens']:,} tokens, "
                        f"${s['cost_usd']:.4f}"
                    )

            return "\n".join(lines)
        except Exception as e:
            logger.warning("CostTracker.format_global_summary() failed: %s", e)
            return "Could not retrieve global cost summary."
