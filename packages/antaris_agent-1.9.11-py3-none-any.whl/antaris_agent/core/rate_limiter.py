"""
Antaris Agent — Per-user sliding window rate limiter + token bucket limiter.
"""
from collections import deque
import logging
import time

logger = logging.getLogger(__name__)


class RateLimiter:
    """Per-user sliding window rate limiter."""

    def __init__(self, max_messages: int = 20, window_seconds: int = 60):
        self.max_messages = max_messages
        self.window_seconds = window_seconds
        self._windows: dict[str, deque] = {}

    def _prune(self, user_id: str) -> None:
        window = self._windows.get(user_id)
        if not window:
            return
        cutoff = time.time() - self.window_seconds
        while window and window[0] <= cutoff:
            window.popleft()

    def is_allowed(self, user_id: str) -> bool:
        """Returns True (and records this attempt) if user is within rate limit."""
        self._prune(user_id)
        if user_id not in self._windows:
            self._windows[user_id] = deque()
        window = self._windows[user_id]
        if len(window) < self.max_messages:
            window.append(time.time())
            return True
        return False

    def get_wait_seconds(self, user_id: str) -> float:
        """Returns seconds until next message is allowed (0 if allowed now)."""
        self._prune(user_id)
        window = self._windows.get(user_id)
        if not window or len(window) < self.max_messages:
            return 0.0
        oldest = window[0]
        wait = self.window_seconds - (time.time() - oldest)
        return max(0.0, wait)

    def reset(self, user_id: str) -> None:
        """Reset rate limit for a user (admin use)."""
        self._windows.pop(user_id, None)


class TokenBucketLimiter:
    """
    Per-user token budget limiter (hourly rolling window).

    Tracks estimated LLM input+output tokens consumed per user per hour.
    Designed to prevent a single user from consuming a disproportionate share
    of the API budget.

    Usage:
        limiter = TokenBucketLimiter(max_tokens_per_hour=100_000)

        # Before processing — check if user has budget remaining
        if not limiter.is_allowed(user_id):
            return "Token budget exhausted. Try again later."

        # After LLM response — record actual usage
        limiter.record_usage(user_id, input_tokens=800, output_tokens=200)

        # Inspect remaining budget
        remaining = limiter.get_remaining(user_id)
    """

    _WINDOW_SECONDS: int = 3600  # 1 hour

    def __init__(self, max_tokens_per_hour: int = 100_000):
        self.max_tokens_per_hour = max_tokens_per_hour
        # Stores list of (timestamp, tokens) tuples per user
        self._usage: dict[str, deque] = {}

    def _prune(self, user_id: str) -> None:
        """Remove usage records older than the rolling window."""
        try:
            entries = self._usage.get(user_id)
            if not entries:
                return
            cutoff = time.time() - self._WINDOW_SECONDS
            while entries and entries[0][0] <= cutoff:
                entries.popleft()
        except Exception as e:
            logger.warning("TokenBucketLimiter._prune error for user=%s: %s", user_id, e)

    def _get_used(self, user_id: str) -> int:
        """Return total tokens used in the current window (after pruning)."""
        try:
            self._prune(user_id)
            entries = self._usage.get(user_id)
            if not entries:
                return 0
            return sum(tokens for _, tokens in entries)
        except Exception as e:
            logger.warning("TokenBucketLimiter._get_used error for user=%s: %s", user_id, e)
            return 0

    def is_allowed(self, user_id: str) -> bool:
        """
        Returns True if the user still has token budget remaining this hour.

        Note: This is a pre-flight check only — it does NOT consume any budget.
        Call record_usage() after the LLM responds to deduct actual tokens.
        """
        try:
            used = self._get_used(user_id)
            allowed = used < self.max_tokens_per_hour
            if not allowed:
                logger.warning(
                    "TokenBucketLimiter: user=%s over budget (used=%d, max=%d)",
                    user_id, used, self.max_tokens_per_hour,
                )
            return allowed
        except Exception as e:
            logger.warning("TokenBucketLimiter.is_allowed error for user=%s: %s", user_id, e)
            return True  # fail open — never crash the pipeline

    def record_usage(self, user_id: str, input_tokens: int, output_tokens: int) -> None:
        """
        Record actual token usage after an LLM response.

        Args:
            user_id: The user identifier.
            input_tokens: Number of prompt/input tokens consumed.
            output_tokens: Number of completion/output tokens consumed.
        """
        try:
            total = max(0, int(input_tokens or 0)) + max(0, int(output_tokens or 0))
            if total == 0:
                return
            if user_id not in self._usage:
                self._usage[user_id] = deque()
            self._usage[user_id].append((time.time(), total))
            logger.debug(
                "TokenBucketLimiter: recorded %d tokens for user=%s (in=%d, out=%d)",
                total, user_id, input_tokens, output_tokens,
            )
        except Exception as e:
            logger.warning(
                "TokenBucketLimiter.record_usage error for user=%s: %s", user_id, e
            )

    def get_remaining(self, user_id: str) -> int:
        """
        Returns the number of tokens remaining in the current hour window.

        Returns 0 if the budget is exhausted, max_tokens_per_hour if no usage yet.
        """
        try:
            used = self._get_used(user_id)
            return max(0, self.max_tokens_per_hour - used)
        except Exception as e:
            logger.warning(
                "TokenBucketLimiter.get_remaining error for user=%s: %s", user_id, e
            )
            return self.max_tokens_per_hour  # fail open

    def reset(self, user_id: str) -> None:
        """Reset token budget for a user (admin use)."""
        try:
            self._usage.pop(user_id, None)
        except Exception as e:
            logger.warning("TokenBucketLimiter.reset error for user=%s: %s", user_id, e)
