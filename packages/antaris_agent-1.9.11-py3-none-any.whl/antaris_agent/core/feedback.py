"""
Antaris Agent Feedback Tracker — reaction-based implicit training.

When a user reacts to a bot message with 👍 or similar, that response is
recorded as positively rated. Reactions like 👎 mark it negatively. Over
time, this calibrates the system prompt to reflect user preferences.

Persistence: per-user JSON files in a `feedback/` directory.
Rolling window: last 50 entries per user kept.
"""
import json
import logging
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

POSITIVE_REACTIONS: frozenset[str] = frozenset(["👍", "❤️", "✅", "🔥", "💯", "👏"])
NEGATIVE_REACTIONS: frozenset[str] = frozenset(["👎", "❌", "😕", "🚫"])
ALL_TRACKED_REACTIONS: frozenset[str] = POSITIVE_REACTIONS | NEGATIVE_REACTIONS

MAX_ENTRIES = 50


class FeedbackEntry:
    """A single feedback record."""

    __slots__ = ("message_preview", "reaction", "timestamp")

    def __init__(self, message_preview: str, reaction: str, timestamp: float):
        self.message_preview = message_preview
        self.reaction = reaction
        self.timestamp = timestamp

    def to_dict(self) -> dict:
        return {
            "message_preview": self.message_preview,
            "reaction": self.reaction,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "FeedbackEntry":
        return cls(
            message_preview=data.get("message_preview", ""),
            reaction=data.get("reaction", ""),
            timestamp=data.get("timestamp", 0.0),
        )


class FeedbackTracker:
    """
    Per-user feedback store backed by JSON files.

    Usage:
        tracker = FeedbackTracker(store_dir="path/to/feedback")
        tracker.record_feedback(user_id, message_preview, "👍")
        ctx = tracker.get_context(user_id)
        # inject ctx into system prompt
    """

    def __init__(self, store_dir: str = "feedback"):
        self._store_dir = Path(store_dir)
        self._store_dir.mkdir(parents=True, exist_ok=True)
        # In-memory cache: user_id -> list[FeedbackEntry]
        self._cache: dict[str, list[FeedbackEntry]] = {}

    # ── Public API ────────────────────────────────────────────────────────

    def record_feedback(self, user_id: str, message_preview: str, reaction: str) -> bool:
        """
        Record a feedback reaction for a bot message.

        Returns True if the reaction was tracked, False if it is unknown and
        was ignored.
        """
        if reaction not in ALL_TRACKED_REACTIONS:
            logger.debug(
                "FeedbackTracker: ignoring unknown reaction %r from user=%s", reaction, user_id
            )
            return False

        entries = self._load(user_id)
        entry = FeedbackEntry(
            message_preview=message_preview[:200],
            reaction=reaction,
            timestamp=time.time(),
        )
        entries.append(entry)

        # Rolling window: keep only the last MAX_ENTRIES
        if len(entries) > MAX_ENTRIES:
            entries = entries[-MAX_ENTRIES:]

        self._cache[user_id] = entries
        self._save(user_id, entries)
        logger.debug(
            "FeedbackTracker: recorded %s for user=%s (total=%d)",
            reaction, user_id, len(entries),
        )
        return True

    def get_positive_patterns(self, user_id: str) -> list[str]:
        """Return message previews that received a positive reaction."""
        entries = self._load(user_id)
        return [e.message_preview for e in entries if e.reaction in POSITIVE_REACTIONS]

    def get_negative_patterns(self, user_id: str) -> list[str]:
        """Return message previews that received a negative reaction."""
        entries = self._load(user_id)
        return [e.message_preview for e in entries if e.reaction in NEGATIVE_REACTIONS]

    def get_context(self, user_id: str) -> str:
        """
        Build a system prompt injection summarising user feedback.

        Returns an empty string if there is no feedback yet.
        """
        positive = self.get_positive_patterns(user_id)
        negative = self.get_negative_patterns(user_id)

        if not positive and not negative:
            return ""

        lines: list[str] = ["## User Response Feedback"]

        if positive:
            lines.append(
                f"The user has reacted positively ({len(positive)} time(s)) to responses like:"
            )
            # Show up to 5 most recent positive previews
            for preview in positive[-5:]:
                short = preview[:100].replace("\n", " ")
                lines.append(f"  - {short}")

        if negative:
            lines.append(
                f"The user has reacted negatively ({len(negative)} time(s)) to responses like:"
            )
            # Show up to 5 most recent negative previews
            for preview in negative[-5:]:
                short = preview[:100].replace("\n", " ")
                lines.append(f"  - {short}")

        lines.append("Adapt your responses accordingly.")
        return "\n".join(lines)

    def get_stats(self, user_id: str) -> dict:
        """Return a summary dict: {positive: int, negative: int, total: int}."""
        entries = self._load(user_id)
        pos = sum(1 for e in entries if e.reaction in POSITIVE_REACTIONS)
        neg = sum(1 for e in entries if e.reaction in NEGATIVE_REACTIONS)
        return {"positive": pos, "negative": neg, "total": len(entries)}

    def clear(self, user_id: str) -> None:
        """Remove all feedback for a user."""
        self._cache.pop(user_id, None)
        path = self._user_path(user_id)
        if path.exists():
            path.unlink()
        logger.debug("FeedbackTracker: cleared feedback for user=%s", user_id)

    # ── Persistence ───────────────────────────────────────────────────────

    def _user_path(self, user_id: str) -> Path:
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in user_id)
        return self._store_dir / f"{safe}.json"

    def _load(self, user_id: str) -> list[FeedbackEntry]:
        if user_id in self._cache:
            return self._cache[user_id]
        path = self._user_path(user_id)
        if not path.exists():
            self._cache[user_id] = []
            return self._cache[user_id]
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            entries = [FeedbackEntry.from_dict(d) for d in data if isinstance(d, dict)]
            self._cache[user_id] = entries
        except Exception as e:
            logger.warning("FeedbackTracker: failed to load %s: %s", path, e)
            self._cache[user_id] = []
        return self._cache[user_id]

    def _save(self, user_id: str, entries: list[FeedbackEntry]) -> None:
        path = self._user_path(user_id)
        try:
            path.write_text(
                json.dumps([e.to_dict() for e in entries], ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as e:
            logger.warning("FeedbackTracker: failed to save %s: %s", path, e)
