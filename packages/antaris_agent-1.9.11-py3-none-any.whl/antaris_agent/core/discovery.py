"""
Antaris Agent Capability Discovery — ongoing feature discovery and setup reminders.

Turns initial setup from a one-time event into an ongoing capability discovery
system. Periodically checks which feature groups are unconfigured and surfaces
gentle, dismissible reminders to the user.

Reminder categories (aligned with the setup wizard):
  1. General setup   — bot name, provider, API key, persona
  2. Integrations    — channels (Discord, Telegram, Slack)
  3. Automation      — tools, heartbeat, cron, extensions
  4. Power-user      — security mode, memory tuning, router, multi-provider

Each reminder is:
  - Occasional (not on every message)
  - Dismissible (one-time skip)
  - Snoozable (hide for N hours)
  - Permanently disable-able (per-category or globally)
  - Only shown if that area is still unconfigured
"""

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from antaris_agent.core.config import Config

logger = logging.getLogger(__name__)

# ── Category definitions ──────────────────────────────────────────────────

CATEGORY_GENERAL = "general_setup"
CATEGORY_INTEGRATIONS = "integrations"
CATEGORY_AUTOMATION = "automation"
CATEGORY_POWER_USER = "power_user"

ALL_CATEGORIES = [
    CATEGORY_GENERAL,
    CATEGORY_INTEGRATIONS,
    CATEGORY_AUTOMATION,
    CATEGORY_POWER_USER,
]


@dataclass
class DiscoveryHint:
    """A single capability discovery hint to show the user."""
    category: str
    title: str
    message: str
    action_hint: str  # brief instruction, e.g. "Run antaris init" or "Add to config.json"
    priority: int = 0  # higher = more important, shown first


@dataclass
class CategoryState:
    """Tracks user interaction state for a single category."""
    dismissed: bool = False          # one-time dismiss (resets on next check cycle)
    snoozed_until: float = 0.0      # epoch timestamp; 0 = not snoozed
    permanently_disabled: bool = False
    last_shown: float = 0.0         # epoch timestamp of last time shown
    show_count: int = 0             # how many times this category has been surfaced


@dataclass
class DiscoveryState:
    """Persistent state for the discovery system."""
    enabled: bool = True
    categories: dict[str, CategoryState] = field(default_factory=dict)
    # Global settings
    min_interval_hours: float = 8.0     # minimum hours between reminders per category
    snooze_hours: float = 24.0          # default snooze duration
    messages_between_hints: int = 25    # minimum messages between any hint
    last_hint_message_count: int = 0    # message count when last hint was shown
    globally_disabled: bool = False     # user disabled all reminders

    def __post_init__(self):
        # Ensure all categories have state
        for cat in ALL_CATEGORIES:
            if cat not in self.categories:
                self.categories[cat] = CategoryState()


# ── Persistence ───────────────────────────────────────────────────────────

_STATE_FILENAME = "discovery_state.json"


def _state_path(config_dir: str | Path) -> Path:
    return Path(config_dir) / _STATE_FILENAME


def load_discovery_state(config_dir: str | Path) -> DiscoveryState:
    """Load discovery state from disk, or return fresh defaults."""
    path = _state_path(config_dir)
    if not path.exists():
        return DiscoveryState()
    try:
        with open(path) as f:
            data = json.load(f)
        state = DiscoveryState()
        state.enabled = data.get("enabled", True)
        state.globally_disabled = data.get("globally_disabled", False)
        state.min_interval_hours = data.get("min_interval_hours", 8.0)
        state.snooze_hours = data.get("snooze_hours", 24.0)
        state.messages_between_hints = data.get("messages_between_hints", 25)
        state.last_hint_message_count = data.get("last_hint_message_count", 0)
        for cat_name, cat_data in data.get("categories", {}).items():
            if cat_name in ALL_CATEGORIES:
                cs = CategoryState(
                    dismissed=cat_data.get("dismissed", False),
                    snoozed_until=cat_data.get("snoozed_until", 0.0),
                    permanently_disabled=cat_data.get("permanently_disabled", False),
                    last_shown=cat_data.get("last_shown", 0.0),
                    show_count=cat_data.get("show_count", 0),
                )
                state.categories[cat_name] = cs
        # Fill any missing categories
        for cat in ALL_CATEGORIES:
            if cat not in state.categories:
                state.categories[cat] = CategoryState()
        return state
    except Exception as e:
        logger.warning("Could not load discovery state: %s", e)
        return DiscoveryState()


def save_discovery_state(config_dir: str | Path, state: DiscoveryState) -> None:
    """Persist discovery state to disk."""
    path = _state_path(config_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "enabled": state.enabled,
        "globally_disabled": state.globally_disabled,
        "min_interval_hours": state.min_interval_hours,
        "snooze_hours": state.snooze_hours,
        "messages_between_hints": state.messages_between_hints,
        "last_hint_message_count": state.last_hint_message_count,
        "categories": {},
    }
    for cat_name, cs in state.categories.items():
        data["categories"][cat_name] = {
            "dismissed": cs.dismissed,
            "snoozed_until": cs.snoozed_until,
            "permanently_disabled": cs.permanently_disabled,
            "last_shown": cs.last_shown,
            "show_count": cs.show_count,
        }
    try:
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logger.warning("Could not save discovery state: %s", e)


# ── Config inspection — what's unconfigured? ──────────────────────────────

def _check_general_setup(config: "Config") -> list[DiscoveryHint]:
    """Check for general setup gaps."""
    hints = []

    # Check persona / SOUL.md
    config_dir = Path(config.config_path).parent
    soul_path = config_dir / "SOUL.md"
    if not soul_path.exists():
        hints.append(DiscoveryHint(
            category=CATEGORY_GENERAL,
            title="Create your bot's personality",
            message="Your bot doesn't have a SOUL.md persona file yet. "
                    "A persona makes your bot feel unique — it shapes how it talks, "
                    "what it cares about, and how it presents itself.",
            action_hint="Run `antaris persona edit` or create SOUL.md in your config directory.",
            priority=8,
        ))
    else:
        soul_content = soul_path.read_text().strip()
        if soul_content == "AWAKENING_NEEDED" or len(soul_content) < 50:
            hints.append(DiscoveryHint(
                category=CATEGORY_GENERAL,
                title="Personalize your bot",
                message="Your SOUL.md is minimal. Start a conversation with your bot "
                        "to trigger awakening, or edit the persona file directly.",
                action_hint="Chat with your bot or run `antaris persona edit`.",
                priority=5,
            ))

    # Check USER.md
    user_path = config_dir / "USER.md"
    if not user_path.exists():
        hints.append(DiscoveryHint(
            category=CATEGORY_GENERAL,
            title="Tell your bot about you",
            message="A USER.md file helps your bot understand who you are, "
                    "your preferences, and how to best help you.",
            action_hint="Create USER.md in your config directory with a few lines about yourself.",
            priority=4,
        ))

    return hints


def _check_integrations(config: "Config") -> list[DiscoveryHint]:
    """Check for unconfigured channels / integrations."""
    hints = []

    has_discord = bool(config.discord_enabled and config.discord_token)
    has_telegram = bool(config.telegram_enabled and config.telegram_token)
    has_slack = bool(getattr(config, "slack_enabled", False) and getattr(config, "slack_bot_token", ""))
    active_channels = sum([has_discord, has_telegram, has_slack])

    if active_channels == 0:
        hints.append(DiscoveryHint(
            category=CATEGORY_INTEGRATIONS,
            title="Connect a messaging channel",
            message="Your bot is only accessible via terminal. Connect Discord, Telegram, "
                    "or Slack so you can chat from your phone or any device.",
            action_hint="Run `antaris setup` to add a channel, or `antaris config telegram-token <token>`.",
            priority=9,
        ))
    elif active_channels == 1:
        # Suggest adding a second channel
        missing = []
        if not has_discord:
            missing.append("Discord")
        if not has_telegram:
            missing.append("Telegram")
        if not has_slack:
            missing.append("Slack")
        hints.append(DiscoveryHint(
            category=CATEGORY_INTEGRATIONS,
            title="Add another channel",
            message=f"Your bot is on {'1 channel' if active_channels == 1 else f'{active_channels} channels'}. "
                    f"You could also connect {' or '.join(missing[:2])} for multi-platform access.",
            action_hint="Run `antaris setup` to add more channels.",
            priority=2,
        ))

    # Check owner_user_id for notifications
    if not getattr(config, "owner_user_id", ""):
        hints.append(DiscoveryHint(
            category=CATEGORY_INTEGRATIONS,
            title="Set your owner ID",
            message="Setting your Discord/platform user ID lets your bot send you "
                    "direct notifications for important events (compaction warnings, "
                    "auth rotation alerts, etc.).",
            action_hint='Add "ownerUserId": "YOUR_ID" to the "bot" section of config.json.',
            priority=3,
        ))

    return hints


def _check_automation(config: "Config") -> list[DiscoveryHint]:
    """Check for automation and tool gaps."""
    hints = []

    tools_config = getattr(config, "_tools_config", {})

    # Check if any tools are enabled
    enabled_tools = []
    for tool_name, tool_cfg in tools_config.items():
        if tool_name == "mcp_servers":
            continue
        if isinstance(tool_cfg, dict) and tool_cfg.get("enabled"):
            enabled_tools.append(tool_name)

    if not enabled_tools:
        hints.append(DiscoveryHint(
            category=CATEGORY_AUTOMATION,
            title="Enable tools for your bot",
            message="Your bot has no tools enabled. Tools let it search the web, "
                    "read/write files, run shell commands, browse websites, and more. "
                    "Without tools, your bot can only chat.",
            action_hint='Add a "tools" section to config.json. See EXAMPLE_TOOLS_CONFIG.json for reference.',
            priority=9,
        ))
    else:
        # Suggest specific missing tools
        suggestions = []
        if "brave_search" not in enabled_tools and "web_search" not in enabled_tools:
            suggestions.append(("web search", "brave_search"))
        if "shell" not in enabled_tools:
            suggestions.append(("shell commands", "shell"))
        if "file_ops" not in enabled_tools:
            suggestions.append(("file operations", "file_ops"))

        if suggestions and len(suggestions) >= 2:
            tool_names = ", ".join(s[0] for s in suggestions[:3])
            hints.append(DiscoveryHint(
                category=CATEGORY_AUTOMATION,
                title="Expand your bot's toolkit",
                message=f"Your bot has {len(enabled_tools)} tool(s) enabled but is missing "
                        f"{tool_names}. More tools = more capable assistant.",
                action_hint='Enable more tools in config.json under "tools".',
                priority=3,
            ))

    # Check heartbeat
    if not getattr(config, "heartbeat_enabled", False):
        hints.append(DiscoveryHint(
            category=CATEGORY_AUTOMATION,
            title="Enable heartbeat checks",
            message="The heartbeat system lets your bot proactively check email, "
                    "calendar, and system health on a schedule — so it can reach out "
                    "when something needs your attention.",
            action_hint='Set "heartbeatEnabled": true in the "bot" section of config.json.',
            priority=4,
        ))

    # Check MCP servers
    mcp_servers = tools_config.get("mcp_servers", [])
    if not mcp_servers and enabled_tools:
        hints.append(DiscoveryHint(
            category=CATEGORY_AUTOMATION,
            title="Connect external tools via MCP",
            message="MCP (Model Context Protocol) lets you plug in external tool servers — "
                    "database access, custom APIs, specialized services. Your bot can use "
                    "any MCP-compatible tool server.",
            action_hint='Add "mcp_servers" to the "tools" section of config.json.',
            priority=2,
        ))

    return hints


def _check_power_user(config: "Config") -> list[DiscoveryHint]:
    """Check for power-user / advanced configuration gaps."""
    hints = []

    # Check security mode
    security_mode = getattr(config, "security_mode", "sandboxed")
    if security_mode == "sandboxed":
        hints.append(DiscoveryHint(
            category=CATEGORY_POWER_USER,
            title="Review your security mode",
            message="Your bot is in sandboxed mode (default and recommended). If you trust your setup, "
                    "'standard' mode gives more capability. For sensitive environments, "
                    "'secured' or 'encrypted' modes add approval gates and audit logging.",
            action_hint="Run `antaris security status` to review, or `antaris start --security <mode>`.",
            priority=3,
        ))

    # Check multi-provider routing
    has_multi = False
    for provider in ("anthropic_api_key", "openai_api_key", "google_api_key"):
        if getattr(config, provider, ""):
            has_multi = True
            break
    if not has_multi:
        hints.append(DiscoveryHint(
            category=CATEGORY_POWER_USER,
            title="Set up multi-provider routing",
            message="With multiple AI provider keys, your bot can route requests to "
                    "the best model for each task — fast models for simple queries, "
                    "powerful models for complex reasoning, with automatic fallback.",
            action_hint='Add provider keys under "providers" in config.json.',
            priority=2,
        ))

    # Check memory configuration
    if not getattr(config, "per_turn_recall", True):
        hints.append(DiscoveryHint(
            category=CATEGORY_POWER_USER,
            title="Enable per-turn memory recall",
            message="Per-turn memory recall lets your bot search its memories on every "
                    "message, giving it better context awareness across conversations.",
            action_hint='Set "perTurnRecall": true in the "memory" section of config.json.',
            priority=4,
        ))

    # Check extensions
    if not getattr(config, "extensions_enabled", True):
        hints.append(DiscoveryHint(
            category=CATEGORY_POWER_USER,
            title="Enable extensions",
            message="Extensions let you add custom capabilities to your bot — "
                    "from desktop control to custom skills to webhook integrations.",
            action_hint='Set "extensions": {"enabled": true} in config.json.',
            priority=3,
        ))

    return hints


# ── Category metadata ─────────────────────────────────────────────────────

CATEGORY_LABELS = {
    CATEGORY_GENERAL: "🏠 General Setup",
    CATEGORY_INTEGRATIONS: "🔗 Integrations",
    CATEGORY_AUTOMATION: "⚡ Automation & Tools",
    CATEGORY_POWER_USER: "🔧 Power User",
}

CATEGORY_CHECKERS = {
    CATEGORY_GENERAL: _check_general_setup,
    CATEGORY_INTEGRATIONS: _check_integrations,
    CATEGORY_AUTOMATION: _check_automation,
    CATEGORY_POWER_USER: _check_power_user,
}


# ── Main discovery manager ────────────────────────────────────────────────

class DiscoveryManager:
    """
    Manages the capability discovery / reminder system.

    Wired into the bot's message pipeline to occasionally surface hints
    about unconfigured capabilities. Respects snooze, dismiss, and disable.

    Usage::

        dm = DiscoveryManager(config_dir="/path/to/config")
        hint = dm.get_next_hint(config, message_count=42)
        if hint:
            # Show hint to user
            dm.mark_shown(hint.category)
            dm.save()

        # User actions:
        dm.dismiss(category)      # hide this one time
        dm.snooze(category)       # hide for snooze_hours
        dm.disable(category)      # never show again
        dm.disable_all()          # disable the whole system
        dm.enable(category)       # re-enable a disabled category
        dm.enable_all()           # re-enable the whole system
    """

    def __init__(self, config_dir: str | Path):
        self.config_dir = Path(config_dir)
        self.state = load_discovery_state(config_dir)

    def save(self) -> None:
        """Persist state to disk."""
        save_discovery_state(self.config_dir, self.state)

    # ── Query ─────────────────────────────────────────────────────────────

    def get_all_hints(self, config: "Config") -> list[DiscoveryHint]:
        """Get all current hints across all categories (ignoring timing/state).

        Useful for a full capability audit view.
        """
        hints = []
        for category, checker in CATEGORY_CHECKERS.items():
            try:
                hints.extend(checker(config))
            except Exception as e:
                logger.warning("Discovery check for %s failed: %s", category, e)
        hints.sort(key=lambda h: h.priority, reverse=True)
        return hints

    def get_next_hint(
        self,
        config: "Config",
        message_count: int = 0,
    ) -> Optional[DiscoveryHint]:
        """
        Get the next appropriate hint to show, respecting all timing and state.

        Returns None if no hint should be shown right now.

        Args:
            config: Current bot config to inspect.
            message_count: Current bot message count (used for spacing).
        """
        if self.state.globally_disabled:
            return None

        if not self.state.enabled:
            return None

        # Check message spacing
        msgs_since_last = message_count - self.state.last_hint_message_count
        if msgs_since_last < self.state.messages_between_hints and self.state.last_hint_message_count > 0:
            return None

        now = time.time()

        # Gather hints from all eligible categories
        candidates: list[DiscoveryHint] = []

        for category, checker in CATEGORY_CHECKERS.items():
            cat_state = self.state.categories.get(category, CategoryState())

            # Skip permanently disabled
            if cat_state.permanently_disabled:
                continue

            # Skip dismissed (one-time skip)
            if cat_state.dismissed:
                continue

            # Skip snoozed
            if cat_state.snoozed_until > now:
                continue

            # Check minimum interval
            hours_since = (now - cat_state.last_shown) / 3600 if cat_state.last_shown > 0 else float("inf")
            if hours_since < self.state.min_interval_hours:
                continue

            # Run the checker
            try:
                hints = checker(config)
                candidates.extend(hints)
            except Exception as e:
                logger.warning("Discovery check for %s failed: %s", category, e)

        if not candidates:
            return None

        # Sort by priority (highest first), then by least-shown category
        def sort_key(hint: DiscoveryHint) -> tuple:
            cat_state = self.state.categories.get(hint.category, CategoryState())
            return (-hint.priority, cat_state.show_count, cat_state.last_shown)

        candidates.sort(key=sort_key)
        return candidates[0]

    def get_category_status(self) -> dict[str, dict]:
        """Get the current status of all categories. Useful for a settings/status view."""
        result = {}
        for cat in ALL_CATEGORIES:
            cs = self.state.categories.get(cat, CategoryState())
            now = time.time()
            result[cat] = {
                "label": CATEGORY_LABELS.get(cat, cat),
                "permanently_disabled": cs.permanently_disabled,
                "snoozed": cs.snoozed_until > now,
                "snoozed_until": datetime.fromtimestamp(cs.snoozed_until, tz=timezone.utc).isoformat() if cs.snoozed_until > now else None,
                "show_count": cs.show_count,
                "last_shown": datetime.fromtimestamp(cs.last_shown, tz=timezone.utc).isoformat() if cs.last_shown > 0 else None,
            }
        result["_global"] = {
            "enabled": self.state.enabled,
            "globally_disabled": self.state.globally_disabled,
            "min_interval_hours": self.state.min_interval_hours,
            "snooze_hours": self.state.snooze_hours,
            "messages_between_hints": self.state.messages_between_hints,
        }
        return result

    # ── User actions ──────────────────────────────────────────────────────

    def mark_shown(self, category: str, message_count: int = 0) -> None:
        """Record that a hint was shown for this category."""
        if category not in self.state.categories:
            self.state.categories[category] = CategoryState()
        cs = self.state.categories[category]
        cs.last_shown = time.time()
        cs.show_count += 1
        cs.dismissed = False  # reset dismiss flag when showing
        self.state.last_hint_message_count = message_count
        self.save()

    def dismiss(self, category: str) -> None:
        """Dismiss a hint for this category (one-time skip, resets on next eligible check)."""
        if category not in self.state.categories:
            self.state.categories[category] = CategoryState()
        self.state.categories[category].dismissed = True
        self.save()
        logger.info("Discovery: dismissed category %s", category)

    def snooze(self, category: str, hours: Optional[float] = None) -> None:
        """Snooze a category for the specified hours (defaults to state.snooze_hours)."""
        if category not in self.state.categories:
            self.state.categories[category] = CategoryState()
        snooze_h = hours if hours is not None else self.state.snooze_hours
        self.state.categories[category].snoozed_until = time.time() + (snooze_h * 3600)
        self.state.categories[category].dismissed = False  # clear dismiss since we're snoozing
        self.save()
        logger.info("Discovery: snoozed category %s for %.1f hours", category, snooze_h)

    def disable(self, category: str) -> None:
        """Permanently disable a category. Can be re-enabled with enable()."""
        if category not in self.state.categories:
            self.state.categories[category] = CategoryState()
        self.state.categories[category].permanently_disabled = True
        self.save()
        logger.info("Discovery: permanently disabled category %s", category)

    def enable(self, category: str) -> None:
        """Re-enable a previously disabled category."""
        if category not in self.state.categories:
            self.state.categories[category] = CategoryState()
        self.state.categories[category].permanently_disabled = False
        self.state.categories[category].dismissed = False
        self.state.categories[category].snoozed_until = 0.0
        self.save()
        logger.info("Discovery: re-enabled category %s", category)

    def disable_all(self) -> None:
        """Disable the entire discovery system."""
        self.state.globally_disabled = True
        self.save()
        logger.info("Discovery: globally disabled")

    def enable_all(self) -> None:
        """Re-enable the entire discovery system."""
        self.state.globally_disabled = False
        self.state.enabled = True
        self.save()
        logger.info("Discovery: globally re-enabled")

    def reset(self) -> None:
        """Reset all discovery state to defaults."""
        self.state = DiscoveryState()
        self.save()
        logger.info("Discovery: state reset to defaults")

    # ── Configuration ─────────────────────────────────────────────────────

    def set_interval(self, hours: float) -> None:
        """Set minimum hours between reminders per category."""
        self.state.min_interval_hours = max(1.0, hours)
        self.save()

    def set_snooze_duration(self, hours: float) -> None:
        """Set default snooze duration in hours."""
        self.state.snooze_hours = max(1.0, hours)
        self.save()

    def set_message_spacing(self, messages: int) -> None:
        """Set minimum messages between any hint."""
        self.state.messages_between_hints = max(5, messages)
        self.save()


# ── Hint formatting helpers ───────────────────────────────────────────────

def format_hint_markdown(hint: DiscoveryHint) -> str:
    """Format a discovery hint as markdown for Discord/Telegram/terminal."""
    category_label = CATEGORY_LABELS.get(hint.category, hint.category)
    lines = [
        f"💡 **{hint.title}**",
        f"_{category_label}_",
        "",
        hint.message,
        "",
        f"**→** {hint.action_hint}",
        "",
        "_Dismiss: `!discover dismiss` · Snooze: `!discover snooze` · Disable: `!discover disable`_",
    ]
    return "\n".join(lines)


def format_hint_plain(hint: DiscoveryHint) -> str:
    """Format a discovery hint as plain text for terminal."""
    category_label = CATEGORY_LABELS.get(hint.category, hint.category)
    lines = [
        f"💡 {hint.title} ({category_label})",
        f"   {hint.message}",
        f"   → {hint.action_hint}",
    ]
    return "\n".join(lines)


def format_status_markdown(status: dict) -> str:
    """Format the full discovery status as markdown."""
    global_status = status.get("_global", {})
    lines = [
        "**🔍 Capability Discovery Status**",
        "",
        f"System: {'🟢 enabled' if not global_status.get('globally_disabled') else '🔴 disabled'}",
        f"Hint spacing: every {global_status.get('messages_between_hints', 25)} messages",
        f"Min interval: {global_status.get('min_interval_hours', 8)}h per category",
        f"Snooze duration: {global_status.get('snooze_hours', 24)}h",
        "",
        "**Categories:**",
    ]

    for cat in ALL_CATEGORIES:
        cat_status = status.get(cat, {})
        label = cat_status.get("label", cat)
        if cat_status.get("permanently_disabled"):
            state_str = "🔴 disabled"
        elif cat_status.get("snoozed"):
            state_str = f"😴 snoozed until {cat_status.get('snoozed_until', 'unknown')}"
        else:
            state_str = "🟢 active"
        shown = cat_status.get("show_count", 0)
        lines.append(f"  • {label}: {state_str} (shown {shown}x)")

    return "\n".join(lines)
