"""
Antaris Agent Message Pipeline — Step 10
"""
from __future__ import annotations

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from antaris_agent.channels.base import InboundMessage, OutboundMessage, ChannelAdapter
from antaris_agent.core.config import Config
from antaris_agent.core.cost_tracker import CostTracker
from antaris_agent.core.error_formatter import format_user_error
from antaris_agent.core.memory import BotMemory
from antaris_agent.core.guard import BotGuard
from antaris_agent.core.media import build_media_context, build_provider_text_fallback, build_screenshot_response_hint
from antaris_agent.core.rate_limiter import RateLimiter, TokenBucketLimiter
from antaris_agent.core.session import SessionManager
from antaris_agent.llm.base import LLMProvider, Message, LLMResponse, ThinkingConfig
from antaris_agent.persona.loader import PersonaLoader
from antaris_agent.persona.user_tracker import UserTracker
from antaris_agent.core.relay_intent import detect_relay_intent, build_relay_context_block
from antaris_agent.tools.pipeline_integration import run_tool_loop
from antaris_agent.tools.tool_registry import ToolRegistry
from antaris_agent.suite.pipeline.hooks import PipelineHooks

logger = logging.getLogger(__name__)

MAX_HISTORY = 20

RELAY_FRAME_GUARD = (
    "Stay addressed to the current speaker by default. When they mention a third party "
    "(for example 'tell X' or 'let X know'), do not write as though you are directly speaking to that third party "
    "unless the user explicitly asks you to draft, compose, or write a direct message for them to send."
)


@dataclass
class PipelineResult:
    success: bool
    response_text: str
    blocked: bool = False
    block_reason: str = ""
    tokens_used: int = 0
    cost_usd: float = 0.0
    error: Optional[str] = None
    failed_stages: list = field(default_factory=list)
    metadata: dict = field(default_factory=dict)


class Pipeline:
    """
    10-stage message processing pipeline with error isolation.

    Stage 0:  Rate limit check (sliding window, before guard)
    Stage 1:  Input guard check (critical)
    Stage 2:  User identification
    Stage 3:  Memory recall (non-critical)
    Stage 4:  Persona load (non-critical)
    Stage 5:  Context assembly
    Stage 6:  LLM call (critical)
    Stage 7:  Output guard check (non-critical)
    Stage 8:  Memory ingest (non-critical)
    Stage 9:  Surface formatting (non-critical)
    Stage 10: Return result

    Non-critical failures are logged, defaults used, processing continues.
    Critical failures return a friendly error PipelineResult.
    """

    def __init__(
        self,
        config: Config,
        memory: BotMemory,
        guard: BotGuard,
        persona: PersonaLoader,
        llm: LLMProvider,
        awakening=None,
        tool_middleware=None,
        router=None,
        dispatcher=None,
        commands: Optional[any] = None,
        profiles: Optional[any] = None,
        teachings: Optional[any] = None,
        focus: Optional[any] = None,
        threads: Optional[any] = None,
        shortcuts: Optional[any] = None,
        proactive: Optional[any] = None,
        mood: Optional[any] = None,
        feedback: Optional[any] = None,
        tool_registry: Optional[ToolRegistry] = None,
    ):
        self.config = config
        self.memory = memory
        self.guard = guard
        self.persona = persona
        self.llm = llm
        self.awakening = awakening
        self.tool_middleware = tool_middleware
        self.router = router
        self.dispatcher = dispatcher
        self.commands = commands
        self.profiles = profiles
        self.teachings = teachings
        self.focus = focus
        self.threads = threads
        self.shortcuts = shortcuts
        self.proactive = proactive
        self.mood = mood
        self.feedback = feedback
        self.tool_registry = tool_registry
        
        # ── Pipeline hooks ────────────────────────────────────────────────
        self._hooks = PipelineHooks()

        self._history: dict[str, list[Message]] = {}
        self._last_message: dict[str, float] = {}
        self._cooldown_seconds: float = 1.0
        self._startup_recalled: bool = False

        # ── Session persistence ──────────────────────────────────────────
        self._session_manager = SessionManager(config)
        self._sessions_path: Optional[Path] = None
        try:
            _config_dir = Path(getattr(config, "config_path", "~/.antarisbot/config.json")).parent
            self._sessions_path = _config_dir / "sessions.json"
            if getattr(config, "session_persistence_enabled", True):
                self._session_manager.load_all(self._sessions_path)
                # Restore history from loaded sessions
                for sid, session in self._session_manager._sessions.items():
                    if session.history:
                        self._history[sid] = list(session.history)
                logger.info("Pipeline: loaded %d sessions from %s",
                            len(self._session_manager._sessions), self._sessions_path)
        except Exception as _e:
            logger.warning("Pipeline: session load failed (will start fresh): %s", _e)

        # Sliding-window rate limiter lives on Pipeline (not recreated per message)
        # Use isinstance guard: MagicMock attributes are not int and fall back to defaults
        _raw_max = getattr(config, "rate_limit_messages", 20)
        _raw_win = getattr(config, "rate_limit_window_seconds", 60)
        _max_msg = _raw_max if isinstance(_raw_max, int) else 20
        _window  = _raw_win if isinstance(_raw_win, int) else 60
        self._rate_limiter = RateLimiter(max_messages=_max_msg, window_seconds=_window)

        # Token-bucket limiter (hourly rolling window, off by default)
        _tok_enabled = getattr(config, "token_rate_limit_enabled", False)
        _tok_per_hour = getattr(config, "token_rate_limit_per_hour", 100_000)
        _tok_per_hour = _tok_per_hour if isinstance(_tok_per_hour, int) else 100_000
        self._token_limiter_enabled: bool = bool(_tok_enabled)
        self._token_limiter = TokenBucketLimiter(max_tokens_per_hour=_tok_per_hour)

        # UserTracker: silently learns facts about the user from their messages
        config_dir = str(getattr(persona, "config_dir", ""))
        self.user_tracker = UserTracker(config_dir) if config_dir else None

        # CostTracker — persists token/cost data per user and channel
        try:
            _ct_enabled = getattr(config, "cost_tracking_enabled", True)
            _ct_interval = getattr(config, "cost_tracking_save_interval", 10)
            _ct_dir = Path(getattr(config, "config_path", "")).parent
            _ct_path = _ct_dir / "cost_tracking.json" if _ct_dir != Path("") else None
            self.cost_tracker = CostTracker(
                save_path=_ct_path,
                save_interval=_ct_interval,
                enabled=bool(_ct_enabled),
            )
        except Exception as _ct_err:
            logger.warning("CostTracker init failed, cost tracking disabled: %s", _ct_err)
            self.cost_tracker = CostTracker(enabled=False)

    async def process(self, inbound: InboundMessage, adapter: ChannelAdapter) -> PipelineResult:
        """Run a message through all stages. Returns a PipelineResult."""
        failed_stages: list[str] = []

        try:
            # ── Command dispatch (before rate limit — commands are always allowed) ──
            if self.commands:
                cmd_result = await self.commands.dispatch(inbound)
                if cmd_result.handled:
                    return PipelineResult(success=True, response_text=cmd_result.response or "")

            # ── Awakening check ────────────────────────────────────────────
            if self.awakening:
                if self.awakening.is_needed() and not self.awakening.is_active():
                    await asyncio.sleep(1.5)
                    response = self.awakening.start(inbound.user_id)
                    return PipelineResult(success=True, response_text=adapter.format_for_surface(response))
                if self.awakening.is_active():
                    await asyncio.sleep(1.2)
                    response = await self.awakening.process(inbound.user_id, inbound.text)
                    return PipelineResult(success=True, response_text=adapter.format_for_surface(response))

            # ── Stage 0: Sliding-window rate limit check ──────────────────
            if not self._rate_limiter.is_allowed(inbound.user_id):
                wait = self._rate_limiter.get_wait_seconds(inbound.user_id)
                wait_int = math.ceil(wait)
                logger.warning("Rate limited user=%s (wait=%.1fs)", inbound.user_id, wait)
                return PipelineResult(
                    success=True,
                    response_text=(
                        f"You're sending messages too fast. "
                        f"Please wait {wait_int} second{'s' if wait_int != 1 else ''}."
                    ),
                    failed_stages=[],
                )

            # ── Stage 0b: Token budget check (hourly rolling window) ──────
            try:
                if self._token_limiter_enabled and not self._token_limiter.is_allowed(inbound.user_id):
                    remaining = self._token_limiter.get_remaining(inbound.user_id)
                    logger.warning(
                        "Token budget exhausted for user=%s (remaining=%d)",
                        inbound.user_id, remaining,
                    )
                    return PipelineResult(
                        success=True,
                        response_text=(
                            "You've reached your hourly token budget. "
                            "Please wait a while before sending more messages."
                        ),
                        failed_stages=[],
                    )
            except Exception as _tbl_err:
                logger.warning("Stage 0b (token budget check) failed: %s", _tbl_err)

            # ── Basic cooldown ────────────────────────────────────────────
            now = time.time()
            last = self._last_message.get(inbound.user_id, 0)
            if now - last < self._cooldown_seconds:
                logger.debug("Cooldown hit for user=%s", inbound.user_id)
                return PipelineResult(success=True, response_text="")
            self._last_message[inbound.user_id] = now

            # ── Stage 1: Input guard (critical) ──────────────────────────
            try:
                allowed, reason = await self.guard.check_input(inbound.text, inbound.user_id)
                if not allowed:
                    logger.warning("Guard blocked user=%s reason=%s", inbound.user_id, reason)
                    return PipelineResult(
                        success=True, response_text="I can't respond to that.",
                        blocked=True, block_reason=reason, failed_stages=failed_stages,
                    )
            except Exception as e:
                logger.error("Stage 1 (input guard) failed: %s", e, exc_info=True)
                failed_stages.append("input_guard")
                return PipelineResult(
                    success=False,
                    response_text=format_user_error(e, stage="input_guard"),
                    error=str(e), failed_stages=failed_stages,
                )

            user_id = inbound.user_id

            # ── Stage 1.5: Tool approval gate (secured/encrypted mode — before any state mutation) ──
            if self.tool_middleware and hasattr(self.tool_middleware, 'approve_and_run'):
                # ToolMiddleware stores self.level (int), not self.mode (string)
                # LEVEL_SECURED = 3, LEVEL_ENCRYPTED = 4
                _security_level = getattr(self.tool_middleware, 'level', 1)
                if _security_level >= 3:  # SECURED or ENCRYPTED
                    approved = await self.tool_middleware.approve_and_run(
                        tool_name="process_message",
                        args={"preview": inbound.text[:80]},
                        fn=None,
                    )
                    if approved is None:  # None means rejected
                        return PipelineResult(
                            success=True,
                            response_text="❌ Message processing cancelled.",
                            failed_stages=failed_stages,
                        )

            # ── Mood observation (after guard, before stage 2) ────────────
            if self.mood:
                try:
                    self.mood.observe(user_id, inbound.text)
                except Exception:
                    pass

            # ── Stage 2: User profile touch ───────────────────────────────
            if self.profiles:
                try:
                    self.profiles.touch(user_id)
                    profile_context = self.profiles.get_context(user_id)
                    if profile_context:
                        logger.debug("Profile context for %s: %s", user_id, profile_context)
                except Exception as e:
                    logger.warning("Profile touch failed: %s", e)

            # ── Stage 2b: Proactive memory scan ───────────────────────────
            if self.proactive:
                try:
                    self.proactive.scan_and_note(user_id, inbound.text)
                except Exception as e:
                    logger.warning("Proactive scan failed: %s", e)

            # ── Stage 2c: Cross-channel recency recall (v1.7.0) ─────────────
            recency_context = ""
            try:
                _recency_enabled = getattr(self.config, "recency_enabled", True)
                if _recency_enabled and hasattr(self.memory, 'search_recent'):
                    _recency_hours = getattr(self.config, "recency_window", 6.0)
                    _recency_limit = getattr(self.config, "recency_limit", 5)
                    _session_key = f"{inbound.platform}:{inbound.channel_id}"
                    recent = self.memory.search_recent(
                        hours=float(_recency_hours),
                        limit=int(_recency_limit),
                        exclude_session=_session_key,
                    )
                    if recent:
                        lines = [f"\n[Recent cross-channel context — last {_recency_hours}h]"]
                        for m in recent:
                            src = getattr(m, 'source', '') or getattr(m, 'session_id', 'unknown')
                            content = getattr(m, 'content', str(m))[:300]
                            lines.append(f"{src}: {content}")
                        recency_context = "\n".join(lines)
                        logger.debug("Recency: injected %d cross-channel memories", len(recent))
            except Exception as e:
                logger.warning("Cross-channel recency recall failed: %s", e)

            # ── Stage 3: Memory recall (non-critical) ─────────────────────
            memories: list[str] = []
            # Check if per-turn recall is enabled
            per_turn_recall = getattr(self.config, "per_turn_recall", True)
            if per_turn_recall:
                try:
                    if self.tool_middleware:
                        logger.debug("Stage 3: memory recall pre-flight for user=%s", user_id)
                    recall_query = inbound.text
                    if self.focus:
                        focus_session = self.focus.get(user_id)
                        if focus_session:
                            recall_query = f"{focus_session.topic} {inbound.text}"
                            logger.debug("Focus recall bias: topic=%s user=%s", focus_session.topic, user_id)
                    memories = await self.memory.recall(user_id, recall_query)
                    logger.debug("Recalled %d memories for user=%s", len(memories), user_id)
                except Exception as e:
                    logger.warning("Stage 3 (memory recall) failed: %s", e)
                    failed_stages.append("memory_recall")
            else:
                logger.debug("Per-turn recall disabled, skipping memory recall for user=%s", user_id)

            # Startup recall: first message only, inject recent context
            if not self._startup_recalled:
                self._startup_recalled = True
                try:
                    _config_dir = str(
                        Path(getattr(self.config, "config_path", "")).parent
                    )
                    _restore_days = getattr(self.config, "startup_restore_days", 2)
                    _file_contexts = self._restore_post_compaction(
                        _config_dir, days=_restore_days
                    )
                    startup_memories = await self.memory.recall(
                        "system", "recent events today"
                    )
                    combined: list[str] = []
                    combined.extend(_file_contexts)
                    if startup_memories:
                        combined.extend(startup_memories[:10])
                    if combined:
                        self._startup_context = combined
                except Exception:
                    pass

            # ── Stage 4: Persona load (non-critical) ──────────────────────
            try:
                system_prompt = self.persona.build_system_prompt(memories)
            except Exception as e:
                logger.warning("Stage 4 (persona load) failed: %s", e)
                failed_stages.append("persona_load")
                system_prompt = "You are a helpful assistant."

            # Inject startup recall context (first message only)
            if hasattr(self, '_startup_context') and self._startup_context:
                recent_block = "\n\n---\n## Recently (startup recall):\n" + "\n".join(f"- {m}" for m in self._startup_context)
                system_prompt += recent_block
                del self._startup_context  # one-shot, don't repeat

            # Inject user profile context
            if self.profiles:
                try:
                    profile_ctx = self.profiles.get_context(user_id)
                    if profile_ctx:
                        system_prompt += f"\n\n---\n## About this user:\n{profile_ctx}"
                except Exception:
                    pass

            # Inject user teaching context
            if self.teachings:
                try:
                    teaching_ctx = self.teachings.get_context(user_id)
                    if teaching_ctx:
                        system_prompt += f"\n\n---\n{teaching_ctx}"
                except Exception:
                    pass

            # Inject focus context
            if self.focus:
                try:
                    focus_ctx = self.focus.get_context(user_id)
                    if focus_ctx:
                        system_prompt += f"\n\n---\n{focus_ctx}"
                except Exception:
                    pass

            # Inject proactive memory surfaces
            if self.proactive:
                try:
                    proactive_ctx = self.proactive.get_context(user_id, inbound.text)
                    if proactive_ctx:
                        system_prompt += f"\n\n---\n{proactive_ctx}"
                except Exception as e:
                    logger.warning("Proactive context failed: %s", e)

            # Inject shortcut context
            if self.shortcuts:
                try:
                    shortcut_ctx = self.shortcuts.get_context(user_id, inbound.text)
                    if shortcut_ctx:
                        system_prompt += f"\n\n---\n{shortcut_ctx}"
                except Exception:
                    pass

            # Inject mood style guidance
            if self.mood:
                try:
                    mood_ctx = self.mood.get_context(user_id)
                    if mood_ctx:
                        system_prompt += f"\n\n---\n{mood_ctx}"
                except Exception:
                    pass

            # Inject reaction-based feedback context
            if self.feedback:
                try:
                    feedback_ctx = self.feedback.get_context(user_id)
                    if feedback_ctx:
                        system_prompt += f"\n\n---\n{feedback_ctx}"
                except Exception as e:
                    logger.warning("Feedback context failed: %s", e)

            # ── Stage 4b: Inject recency context (v1.7.0) ────────────────
            if recency_context:
                system_prompt += f"\n\n---\n{recency_context}"

            # ── Stage 4c: Inject document text (v1.7.0) ──────────────────
            if hasattr(inbound, 'documents') and inbound.documents:
                for doc in inbound.documents:
                    doc_block = f"\n\n---\n[Document: {doc['filename']}]\n{doc['text']}\n[End Document]"
                    system_prompt += doc_block

            # ── Stage 4d: Inject image/screenshot UX context ──────────────
            media_summary: dict = {"has_images": False, "image_count": 0, "image_kind": None}
            if hasattr(inbound, 'images') and inbound.images:
                media_block, media_summary = build_media_context(inbound.text, inbound.images)
                if media_block:
                    system_prompt += f"\n\n---\n{media_block}"
                if media_summary.get("image_kind") == "screenshot":
                    system_prompt += f"\n\n---\n{build_screenshot_response_hint()}"

            # ── Stage 4e: Relay / audience framing hardening ─────────────
            # Run the relay-intent detector on the incoming text.
            # Mode A (acknowledge): stay in current-speaker frame.
            # Mode B (compose): user wants a drafted direct message.
            # Falls back to the static guard if no specific intent detected.
            _relay = detect_relay_intent(inbound.text)
            if _relay.detected:
                _relay_block = build_relay_context_block(_relay)
                if _relay_block:
                    system_prompt += f"\n\n---\n{_relay_block}"
            else:
                system_prompt += f"\n\n---\n## Relay framing guard\n{RELAY_FRAME_GUARD}"

            # ── Stage 5: Context assembly ─────────────────────────────────
            history = self._get_history(user_id)

            # Build user message with vision-aware structured content when images exist.
            # Also include a text fallback so non-multimodal providers still get explicit
            # image/screenshot context instead of silently ignoring attachments.
            user_content = inbound.text
            if hasattr(inbound, 'images') and inbound.images:
                fallback_text = build_provider_text_fallback(inbound.text, inbound.images)
                content_blocks = [{"type": "text", "text": fallback_text}]
                for img in inbound.images:
                    content_blocks.append({
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": img["media_type"],
                            "data": img["data"],
                        }
                    })
                user_content = content_blocks

            messages = history + [Message(role="user", content=user_content)]

            # ── Stage 6: LLM call (critical) — with optional tool loop ─────
            _max_retries = 3
            raw_text: str = ""
            tool_metadata: dict = {}
            llm_response: Optional[any] = None  # v1.7.0: proper init for cost/token tracking
            
            for _attempt in range(_max_retries):
                try:
                    # ── Stage 5.5: Route to best model (if router available) ──
                    _use_model = self.config.model  # default
                    _use_provider = None

                    # Check for user model override first
                    _user_override = None
                    if self.commands:
                        _user_override = self.commands.get_model_override(inbound.user_id)
                    if _user_override:
                        # Find provider for this model from router config
                        _use_model = _user_override
                        _use_provider = self._resolve_provider_for_model(_user_override)
                        logger.info("User model override: %s/%s", _use_provider, _use_model)
                    elif self.router:
                        try:
                            decision = self.router.route(prompt=inbound.text)
                            _use_model = decision.model
                            _use_provider = decision.provider
                            logger.info(
                                "Router: %s → %s/%s (tier=%s, conf=%.2f)",
                                inbound.text[:50], decision.provider, decision.model,
                                decision.tier, decision.confidence,
                            )
                        except Exception as _re:
                            logger.warning("Router failed, using default model: %s", _re)

                    # ── Resolve thinking config from ModelController ──────
                    _thinking_config = None
                    _thinking_warning_text = None
                    try:
                        _bot = getattr(self, '_bot', None)
                        # Try to get model_controller from bot (attached in bot.py)
                        # or from commands dispatcher which holds bot reference
                        _model_ctrl = None
                        if _bot and hasattr(_bot, 'model_controller'):
                            _model_ctrl = _bot.model_controller
                        elif self.commands and hasattr(self.commands, 'bot') and self.commands.bot:
                            _model_ctrl = getattr(self.commands.bot, 'model_controller', None)
                        
                        if _model_ctrl:
                            _thinking_level, _thinking_budget = _model_ctrl.get_thinking_for_user(user_id)
                            if _thinking_level != "off" and _thinking_budget > 0:
                                _support = _model_ctrl.get_thinking_support(
                                    user_id,
                                    provider=_use_provider or "",
                                    model=_use_model or "",
                                )
                                if _support.supported:
                                    _thinking_config = ThinkingConfig.from_level(_thinking_level, _thinking_budget)
                                    logger.info(
                                        "Thinking enabled for user=%s: level=%s, budget=%d, provider=%s, model=%s",
                                        user_id, _thinking_level, _thinking_budget, _use_provider, _use_model,
                                    )
                                elif _support.warning:
                                    _should_surface = _model_ctrl.note_thinking_warning(
                                        user_id,
                                        _support.warning,
                                        provider=_use_provider or "",
                                        model=_use_model or "",
                                    )
                                    logger.warning(
                                        "Thinking requested but unsupported for user=%s: provider=%s model=%s level=%s",
                                        user_id, _use_provider, _use_model, _thinking_level,
                                    )
                                    if _should_surface:
                                        _thinking_warning_text = _support.warning
                    except Exception as _tk_err:
                        logger.debug("Thinking config resolution failed (non-fatal): %s", _tk_err)

                    # Choose LLM provider for tool loop or direct call
                    if self.dispatcher and _use_provider:
                        # Dispatcher now supports tools and thinking — use it
                        current_llm = self.dispatcher.get(_use_provider) or self.llm
                    else:
                        current_llm = self.llm

                    # Use tool loop if ToolRegistry is configured
                    if self.tool_registry:
                        try:
                            # Get available tools (sync to avoid await in try block)
                            tools = self.tool_registry.get_tool_definitions_sync()

                            # Part A: Pre-flight warning — registry exists but has no tools.
                            # This means any action-intent in the response will silently fail.
                            if not tools:
                                logger.warning(
                                    "Stage 6 pre-flight: tool_registry is configured but "
                                    "get_tool_definitions_sync() returned an empty list. "
                                    "The LLM will not be able to execute any tools this turn."
                                )
                            
                            if tools:
                                logger.debug("Using tool loop with %d tools available", len(tools))
                                raw_text, updated_messages, tool_metadata = await run_tool_loop(
                                    llm=current_llm,
                                    messages=messages,
                                    tools=tools,
                                    tool_registry=self.tool_registry,
                                    max_iterations=10,
                                    system=system_prompt,
                                    model=_use_model,
                                    tool_middleware=self.tool_middleware,
                                    thinking=_thinking_config,
                                )
                                # Update messages to include tool conversation
                                messages = updated_messages
                            else:
                                logger.debug("No tools available, using direct LLM call")
                                # No tools available, use direct LLM call
                                llm_response: LLMResponse = await current_llm.complete(
                                    messages=messages, system=system_prompt, model=_use_model,
                                    thinking=_thinking_config,
                                )
                                raw_text = llm_response.content
                        except Exception as e:
                            logger.error("Tool loop failed, falling back to direct LLM: %s", e)
                            # Fall back to direct LLM call
                            llm_response: LLMResponse = await current_llm.complete(
                                messages=messages, system=system_prompt, model=_use_model,
                                thinking=_thinking_config,
                            )
                            raw_text = llm_response.content
                    else:
                        # No tool registry, use direct LLM call
                        if self.dispatcher and _use_provider:
                            llm_response: LLMResponse = await self.dispatcher.complete(
                                provider=_use_provider,
                                model=_use_model,
                                messages=messages,
                                system=system_prompt,
                                thinking=_thinking_config,
                            )
                        else:
                            llm_response: LLMResponse = await current_llm.complete(
                                messages=messages, system=system_prompt, model=_use_model,
                                thinking=_thinking_config,
                            )
                        raw_text = llm_response.content
                        
                    if _thinking_warning_text and raw_text:
                        raw_text = f"{_thinking_warning_text}\n\n{raw_text}"
                    break  # success
                except Exception as e:
                    err_str = str(e).lower()
                    is_transient = any(kw in err_str for kw in ["rate limit", "429", "500", "503", "timeout", "overloaded"])
                    if is_transient and _attempt < _max_retries - 1:
                        wait = 2 ** _attempt  # attempt 0→1s, 1→2s, 2→4s
                        logger.warning(
                            "Stage 6 transient error (attempt %d/%d, retry in %ds): %s",
                            _attempt + 1, _max_retries, wait, e,
                        )
                        await asyncio.sleep(wait)
                        continue
                    logger.error("Stage 6 (LLM call) failed: %s", e, exc_info=True)
                    failed_stages.append("llm_call")
                    return PipelineResult(
                        success=False,
                        response_text=format_user_error(e, stage="llm_call"),
                        error=str(e), failed_stages=failed_stages,
                    )

            if not raw_text or not raw_text.strip():
                logger.warning("LLM returned empty response for user=%s", user_id)
                return PipelineResult(
                    success=False,
                    response_text="I didn't get a response. Please try again.",
                    error="empty_llm_response",
                    failed_stages=failed_stages + ["llm_empty"],
                )

            # ── Stage 6b: Record token usage for budget tracking ──────────
            try:
                if self._token_limiter_enabled:
                    _in_tok = 0
                    _out_tok = 0
                    if llm_response is not None:
                        _in_tok = getattr(llm_response, 'input_tokens', 0) or 0
                        _out_tok = getattr(llm_response, 'output_tokens', 0) or 0
                    elif tool_metadata:
                        # Tool loop doesn't expose llm_response directly; use metadata if present
                        _in_tok = tool_metadata.get('input_tokens', 0) or 0
                        _out_tok = tool_metadata.get('output_tokens', 0) or 0
                    if _in_tok or _out_tok:
                        self._token_limiter.record_usage(user_id, _in_tok, _out_tok)
            except Exception as _tbl_rec_err:
                logger.warning("Stage 6b (token usage record) failed: %s", _tbl_rec_err)

            # Part C: Do not surface internal tool-loop fallback text to end users.
            # The old annotation leaked infrastructure wording into chat and sounded robotic.
            if tool_metadata.get("intent_without_action"):
                logger.info(
                    "Stage 6 post-check: intent_without_action detected for user=%s "
                    "(suppressed user-facing annotation)", user_id
                )

            # ── Stage 6c: Cost tracking (non-critical) ────────────────────
            try:
                if llm_response is not None:
                    self.cost_tracker.record(
                        user_id=user_id,
                        channel_id=inbound.channel_id or "unknown",
                        input_tokens=llm_response.input_tokens,
                        output_tokens=llm_response.output_tokens,
                        cost_usd=llm_response.cost_usd,
                    )
                elif tool_metadata:
                    # Tool-loop path: tokens are accumulated in metadata
                    self.cost_tracker.record(
                        user_id=user_id,
                        channel_id=inbound.channel_id or "unknown",
                        input_tokens=tool_metadata.get("input_tokens", 0),
                        output_tokens=tool_metadata.get("output_tokens", 0),
                        cost_usd=tool_metadata.get("cost_usd", 0.0),
                    )
            except Exception as _ct_err:
                logger.debug("Cost tracking record failed (non-fatal): %s", _ct_err)

            # ── Stage 7: Output guard (non-critical) ──────────────────────
            try:
                _ok, filtered_text = await self.guard.check_output(raw_text)
            except Exception as e:
                logger.warning("Stage 7 (output guard) failed: %s", e)
                failed_stages.append("output_guard")
                filtered_text = raw_text

            # ── Stage 8: Memory ingest (non-critical) ─────────────────────
            try:
                await self.memory.ingest(
                    user_id, 
                    inbound.text, 
                    filtered_text,
                    session_id=getattr(inbound, 'session_id', ''),
                    channel_id=inbound.channel_id
                )
            except Exception as e:
                logger.warning("Stage 8 (memory ingest) failed: %s", e)
                failed_stages.append("memory_ingest")

            # ── Stage 8b: Thread filing (non-critical) ───────────────────
            if self.threads:
                try:
                    self.threads.file_turn(user_id, "user", inbound.text)
                    self.threads.file_turn(user_id, "assistant", filtered_text)
                except Exception as e:
                    logger.warning("Thread filing failed: %s", e)
                    failed_stages.append("thread_filing")

            # ── Stage 8c: USER.md update (non-critical) ──────────────────
            learned_facts: list[str] = []
            try:
                await self._maybe_update_user_context(inbound, filtered_text)
                if self.user_tracker is not None:
                    learned_facts = self.user_tracker.process_message(inbound.text)
                    if learned_facts:
                        logger.debug(
                            "UserTracker: learned %d fact(s) for user=%s",
                            len(learned_facts),
                            user_id,
                        )
            except Exception as e:
                logger.warning("USER.md update failed: %s", e)
                failed_stages.append("user_context_update")

            # ── Stage 8d: Shortcut observation (non-critical) ────────────
            if self.shortcuts:
                try:
                    learned = self.shortcuts.observe(user_id, inbound.text, filtered_text)
                    if learned:
                        logger.info("New shortcut learned: %s", learned)
                except Exception as e:
                    logger.warning("Shortcut observation failed: %s", e)

            self._update_history(user_id, inbound.text, filtered_text)

            # ── Stage 9: Surface formatting (non-critical) ────────────────
            try:
                formatted = adapter.format_for_surface(filtered_text)
            except Exception as e:
                logger.warning("Stage 9 (formatting) failed: %s", e)
                failed_stages.append("surface_format")
                formatted = filtered_text

            result_metadata: dict = {}
            if learned_facts:
                result_metadata["learned_facts"] = learned_facts
            
            # Add tool metadata if tools were used
            if tool_metadata:
                result_metadata.update(tool_metadata)
            if media_summary.get("has_images"):
                result_metadata["visual_input"] = media_summary

            # Handle token/cost info (may not be available from tool loop)
            tokens_used = 0
            cost_usd = 0.0
            if llm_response is not None:
                tokens_used = llm_response.input_tokens + llm_response.output_tokens
                cost_usd = llm_response.cost_usd

            return PipelineResult(
                success=True,
                response_text=formatted,
                tokens_used=tokens_used,
                cost_usd=cost_usd,
                failed_stages=failed_stages,
                metadata=result_metadata,
            )

        except Exception as e:
            logger.error("Pipeline unexpected error: %s", e, exc_info=True)
            return PipelineResult(
                success=False,
                response_text=format_user_error(e, stage="pipeline"),
                error=str(e), failed_stages=failed_stages,
            )

    def _resolve_provider_for_model(self, model: str) -> Optional[str]:
        """Try to resolve which provider owns a given model name."""
        model_lower = model.lower()
        if "claude" in model_lower or "anthropic" in model_lower:
            return "anthropic"
        if "gpt" in model_lower or "openai" in model_lower:
            return "openai"
        if "gemini" in model_lower or "google" in model_lower:
            return "google"
        if "qwen" in model_lower or "ollama" in model_lower:
            return "ollama"
        return None

    def _get_history(self, user_id: str) -> list[Message]:
        return list(self._history.get(user_id, []))

    def _update_history(self, user_id: str, user_text: str, bot_text: str):
        if user_id not in self._history:
            self._history[user_id] = []
        hist = self._history[user_id]
        hist.append(Message(role="user", content=user_text))
        hist.append(Message(role="assistant", content=bot_text))
        if len(hist) > MAX_HISTORY:
            self._history[user_id] = hist[-MAX_HISTORY:]
        # Sync to session manager and maybe auto-save
        self._sync_and_autosave(user_id)

    def _sync_and_autosave(self, user_id: str) -> None:
        """Sync history to SessionManager and trigger auto-save if threshold reached."""
        if self._sessions_path is None:
            return
        try:
            from antaris_agent.core.session import SessionState
            sid = user_id
            if sid not in self._session_manager._sessions:
                # Create a lightweight session entry for persistence
                session = SessionState(
                    session_id=sid,
                    user_id=user_id,
                    channel_id="",
                    platform="unknown",
                    history=[],
                )
                self._session_manager._sessions[sid] = session
            session = self._session_manager._sessions[sid]
            session.history = list(self._history.get(user_id, []))
            session.last_active = time.time()
            # Auto-save
            self._session_manager.maybe_autosave(self._sessions_path)
        except Exception as e:
            logger.warning("Pipeline._sync_and_autosave failed: %s", e)

    def save_sessions(self) -> None:
        """Force-save all sessions immediately (for shutdown)."""
        if self._sessions_path is None:
            return
        try:
            self._session_manager.save_all(self._sessions_path)
        except Exception as e:
            logger.warning("Pipeline.save_sessions() failed: %s", e)

    def clear_history(self, user_id: str):
        self._history.pop(user_id, None)
        # Also remove from session manager
        try:
            self._session_manager._sessions.pop(user_id, None)
        except Exception:
            pass

    def history_length(self, user_id: str) -> int:
        return len(self._history.get(user_id, []))

    def _restore_post_compaction(
        self,
        config_dir: str,
        days: int = 2,
    ) -> list[str]:
        """Read daily logs and MEMORY.md to rebuild context after compaction.

        Priority order: MEMORY.md facts first, then daily log summaries.
        Handles missing files gracefully.

        Args:
            config_dir: Path to the bot config directory (where MEMORY.md lives
                        and where memory/ subdirectory contains daily logs).
            days: How many past days of daily logs to read.

        Returns:
            List of context strings to inject into the startup context.
        """
        from datetime import timedelta, date as _date

        contexts: list[str] = []
        base = Path(config_dir)

        # 1. MEMORY.md (long-term curated facts) - highest priority
        memory_md = base / "MEMORY.md"
        if memory_md.exists():
            try:
                content = memory_md.read_text(encoding="utf-8").strip()
                if content:
                    contexts.append(f"## Long-term memory (MEMORY.md)\n{content}")
                    logger.debug("Loaded MEMORY.md (%d chars)", len(content))
            except Exception as e:
                logger.warning("Could not read MEMORY.md: %s", e)
        else:
            logger.debug("MEMORY.md not found at %s, skipping", memory_md)

        # 2. Daily logs for the last N days
        memory_dir = base / "memory"
        today = _date.today()
        for delta in range(days):
            log_date = today - timedelta(days=delta)
            log_path = memory_dir / f"{log_date.isoformat()}.md"
            if log_path.exists():
                try:
                    content = log_path.read_text(encoding="utf-8").strip()
                    if content:
                        label = "Today" if delta == 0 else f"{delta} day(s) ago"
                        contexts.append(
                            f"## Daily log ({label}, {log_date.isoformat()})\n{content}"
                        )
                        logger.debug(
                            "Loaded daily log %s (%d chars)", log_path.name, len(content)
                        )
                except Exception as e:
                    logger.warning("Could not read daily log %s: %s", log_path, e)
            else:
                logger.debug("No daily log for %s, skipping", log_date.isoformat())

        return contexts

    async def _maybe_update_user_context(self, inbound: InboundMessage, bot_response: str):
        text = inbound.text.lower()
        personal_triggers = [
            "my name is", "i'm called", "call me",
            "i work", "i live", "i'm from", "i am from",
            "my job", "my role", "i like", "i love", "i hate",
            "i prefer", "i usually", "i always", "i never",
            "my favorite", "i'm a ", "i am a ",
        ]
        triggered = any(trigger in text for trigger in personal_triggers)
        if not triggered:
            return
        sentences = [s.strip() for s in inbound.text.split('.') if s.strip()]
        relevant = [s for s in sentences if any(t in s.lower() for t in personal_triggers)]
        if relevant:
            fact = '. '.join(relevant[:2])
            self.persona.update_user_context(f"- {fact}")
            logger.debug("Updated USER.md with: %s", fact[:80])
