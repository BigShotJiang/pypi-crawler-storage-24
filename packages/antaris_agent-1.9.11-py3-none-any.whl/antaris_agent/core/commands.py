"""
Antaris Agent Command Dispatcher — handles ! prefixed commands.

Commands are resolved before rate-limiting and the normal pipeline so
they are always available regardless of LLM state.
"""
import logging
from dataclasses import dataclass
from typing import Optional

from antaris_agent.channels.base import InboundMessage
from antaris_agent.core.google_workspace_commands import GoogleWorkspaceCommandMixin

logger = logging.getLogger(__name__)


@dataclass
class CommandResult:
    handled: bool
    response: Optional[str] = None


class CommandDispatcher(GoogleWorkspaceCommandMixin):
    """
    Dispatch ! commands from inbound messages.

    Usage:
        dispatcher = CommandDispatcher(bot=bot_instance)
        result = await dispatcher.dispatch(inbound)
        if result.handled:
            return result.response
    """

    def __init__(self, bot=None):
        self.bot = bot
        self._model_overrides: dict[str, str] = {}  # user_id → model override

    def get_model_override(self, user_id: str) -> Optional[str]:
        """Get model override for user, if set."""
        return self._model_overrides.get(user_id)

    async def dispatch(self, inbound: InboundMessage) -> CommandResult:
        """Check if message is a command and handle it."""
        text = (inbound.text or "").strip()
        if not text.startswith("!"):
            return CommandResult(handled=False)

        parts = text.split(maxsplit=1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        logger.debug("Command dispatch: cmd=%s user=%s", cmd, inbound.user_id)

        if cmd == "!status":
            return CommandResult(handled=True, response=await self._cmd_status())

        elif cmd == "!model":
            return CommandResult(handled=True, response=await self._cmd_model(inbound.user_id, args))

        elif cmd == "!gather":
            return CommandResult(handled=True, response=await self._cmd_gather(inbound, args))

        elif cmd == "!recap":
            return CommandResult(handled=True, response=await self._cmd_recap(inbound, args))

        elif cmd == "!focus":
            return CommandResult(handled=True, response=await self._cmd_focus(inbound.user_id, args))

        elif cmd == "!unfocus":
            return CommandResult(handled=True, response=await self._cmd_unfocus(inbound.user_id))

        elif cmd == "!help":
            return CommandResult(handled=True, response=self._cmd_help())

        elif cmd == "!gmail":
            return CommandResult(
                handled=True,
                response=await self._cmd_gmail(inbound, args),
            )

        elif cmd == "!calendar":
            return CommandResult(
                handled=True,
                response=await self._cmd_calendar(inbound, args),
            )

        elif cmd == "!drive":
            return CommandResult(
                handled=True,
                response=await self._cmd_drive(inbound, args),
            )

        elif cmd == "!ping":
            return CommandResult(handled=True, response="🏓 Pong!")

        elif cmd == "!memory":
            return CommandResult(
                handled=True,
                response=await self._cmd_memory(inbound.user_id, args),
            )

        elif cmd == "!cron":
            return CommandResult(
                handled=True,
                response=await self._cmd_cron(inbound.user_id, args),
            )

        elif cmd == "!profile":
            return CommandResult(
                handled=True,
                response=await self._cmd_profile(inbound.user_id, args),
            )

        elif cmd == "!teach":
            return CommandResult(
                handled=True,
                response=await self._cmd_teach(inbound.user_id, args),
            )

        elif cmd == "!threads":
            return CommandResult(
                handled=True,
                response=await self._cmd_threads(inbound.user_id),
            )

        elif cmd == "!thread":
            return CommandResult(
                handled=True,
                response=await self._cmd_thread(inbound.user_id, args),
            )

        elif cmd == "!shortcuts":
            return CommandResult(
                handled=True,
                response=await self._cmd_shortcuts(inbound.user_id, args),
            )

        elif cmd == "!export":
            return CommandResult(
                handled=True,
                response=await self._cmd_export(inbound.user_id, args),
            )

        elif cmd == "!feedback":
            return CommandResult(
                handled=True,
                response=await self._cmd_feedback(inbound.user_id, args),
            )

        elif cmd in ("!spawn", "!agent"):
            return CommandResult(
                handled=True,
                response=await self._cmd_spawn(inbound, args),
            )

        elif cmd in ("!agents",):
            return CommandResult(
                handled=True,
                response=await self._cmd_agents(inbound, args),
            )

        elif cmd == "!cost":
            return CommandResult(
                handled=True,
                response=await self._cmd_cost(inbound.user_id, args),
            )

        elif cmd == "!extensions":
            return CommandResult(
                handled=True,
                response=await self._cmd_extensions(inbound.user_id, args),
            )

        elif cmd == "!auth":
            return CommandResult(
                handled=True,
                response=await self._cmd_auth(inbound.user_id, args),
            )

        elif cmd == "!skills":
            return CommandResult(
                handled=True,
                response=await self._cmd_skills(inbound.user_id, args),
            )

        elif cmd in ("!thinking", "!reasoning"):
            return CommandResult(
                handled=True,
                response=await self._cmd_thinking(inbound.user_id, args),
            )

        elif cmd == "!models":
            return CommandResult(
                handled=True,
                response=await self._cmd_models(inbound.user_id),
            )

        elif cmd == "!webhooks":
            return CommandResult(
                handled=True,
                response=await self._cmd_webhooks(inbound.user_id, args),
            )

        elif cmd == "!discover":
            return CommandResult(
                handled=True,
                response=await self._cmd_discover(inbound.user_id, args),
            )

        # Try extension-registered commands
        from antaris_agent.extensions.manager import ExtensionManager
        _ext_mgr = getattr(self.bot, '_extension_manager', None)
        if isinstance(_ext_mgr, ExtensionManager):
            ext_result = _ext_mgr.dispatch_command(
                cmd[1:], inbound.user_id, args
            )
            if ext_result is not None:
                return CommandResult(handled=True, response=ext_result)

        # Unknown command -- don't handle, let it fall through to the LLM
        return CommandResult(handled=False)

    # ── Commands ──────────────────────────────────────────────────────────

    async def _cmd_status(self) -> str:
        lines = ["**📊 Antaris Status**"]
        try:
            stats = self.bot.memory.stats()
            lines.append(f"🧠 Memory: {stats.get('total', 0):,} entries")
        except Exception:
            lines.append("🧠 Memory: unavailable")
        if self.bot and hasattr(self.bot, 'dispatcher') and self.bot.dispatcher:
            providers = list(self.bot.dispatcher.providers.keys())
            lines.append(f"🔌 Providers: {', '.join(providers)}")
        if self.bot and hasattr(self.bot, 'config'):
            lines.append(f"🤖 Model: {self.bot.config.model} via {self.bot.config.provider_name}")
            lines.append(f"🛡️ Guard: {self.bot.config.guard_mode}")
            lines.append(f"🔒 Security: {getattr(self.bot.config, 'security_mode', 'sandboxed')}")
        if self.bot and getattr(self.bot, 'router', None):
            lines.append("🧭 Router: active")
        else:
            lines.append("🧭 Router: off")
        return "\n".join(lines)

    async def _cmd_model(self, user_id: str, args: str) -> str:
        # Use ModelController if available, otherwise fall back to legacy aliases
        from antaris_agent.extensions.model_control import ModelController
        controller = getattr(self.bot, 'model_controller', None)
        if controller and isinstance(controller, ModelController):
            if not args or args.lower() == "auto":
                self._model_overrides.pop(user_id, None)
                controller.set_model(user_id, "auto")
                return "🔄 Model routing reset to auto."
            
            # Check for duration suffix: "opus 30m" or "gpt 1h"
            parts = args.strip().split()
            model_spec = parts[0]
            duration = 0
            if len(parts) > 1:
                dur_str = parts[-1].lower()
                from antaris_agent.core.focus import parse_duration_minutes
                parsed = parse_duration_minutes(dur_str)
                if parsed is not None:
                    duration = parsed
                    # model_spec is everything except the duration
                    model_spec = " ".join(parts[:-1])
            
            model, provider, msg = controller.set_model(user_id, model_spec, duration)
            if model:
                self._model_overrides[user_id] = model
            return msg
        
        # Legacy fallback
        if not args or args.lower() == "auto":
            self._model_overrides.pop(user_id, None)
            return "🔄 Model routing reset to auto."
        aliases = {
            "opus": "claude-opus-4-6",
            "sonnet": "claude-sonnet-4-6",
            "haiku": "claude-haiku-4-5-20251001",
            "gpt": "gpt-5.4",
            "gpt5": "gpt-5.4",
            "gpt4": "gpt-4o",
            "gemini": "gemini-3.1-pro",
            "flash": "gemini-2.0-flash",
            "qwen": "qwen3.5:4b",
            "qwen9b": "qwen3.5:9b",
            "qwen8b": "qwen3:8b",
        }
        model = aliases.get(args.lower(), args)
        self._model_overrides[user_id] = model
        return f"✅ Model set to `{model}`. Use `!model auto` to reset."

    async def _cmd_gather(self, inbound: InboundMessage, args: str) -> str:
        """Gather and ingest recent Discord channel history."""
        from antaris_agent.core import gather as _gather

        # Parse hours argument
        hours = 12
        if args.strip():
            try:
                hours = int(args.strip())
            except ValueError:
                return f"Invalid hours value. Valid options: {', '.join(str(h) for h in _gather.VALID_HOURS)}"

        if hours not in _gather.VALID_HOURS:
            return f"Invalid hours: {hours}. Valid options: {', '.join(str(h) for h in _gather.VALID_HOURS)}"

        # Get the Discord client from the DiscordAdapter if available
        discord_client = None
        for ch in getattr(self.bot, '_channels', []):
            from antaris_agent.channels.discord import DiscordAdapter
            if isinstance(ch, DiscordAdapter):
                discord_client = ch._client
                break

        if not discord_client:
            return "Gather requires a connected Discord client. Bot may not be running on Discord."

        channel_ids = list(getattr(self.bot.config, 'discord_open_channels', []))
        if not channel_ids:
            return "No open channels configured. Add channels to discord_open_channels in config."

        try:
            result = await _gather.gather_and_ingest(
                client=discord_client,
                memory=self.bot.memory,
                llm=self.bot.llm,
                channel_ids=channel_ids,
                hours=hours,
                user_id=inbound.user_id,
            )
            synced = result["channels_synced"]
            total = result["total_messages"]
            errors = result.get("errors", [])
            channel_summaries = result.get("channel_summaries", [])

            if not channel_summaries:
                msg = f"No new messages found in the last {hours}h."
                if errors:
                    msg += f" Errors: {'; '.join(errors[:3])}"
                return msg

            lines = [f"**Gathered {synced} channel(s) over the last {hours}h ({total} messages):**\n"]
            for cs in channel_summaries:
                lines.append(f"**#{cs['channel_name']}** ({cs['count']} msgs)")
                lines.append(cs["summary"])
                lines.append("")

            if errors:
                lines.append(f"Errors: {'; '.join(errors[:3])}")

            return "\n".join(lines).strip()
        except Exception as e:
            logger.error("gather failed: %s", e)
            return f"Gather failed: {e}"

    async def _cmd_recap(self, inbound: InboundMessage, args: str) -> str:
        try:
            n = int(args) if args else 10
            n = min(max(n, 1), 50)
        except ValueError:
            n = 10
        return f"📝 Recap of last {n} messages: *coming soon.*"

    def _cmd_help(self) -> str:
        return (
            "**📖 Antaris Command Guide**\n"
            "Use `!help` anytime. Unknown `!` commands fall through to the LLM instead of hard-failing.\n"
            "\n"
            "**Getting started**\n"
            "`!status` — show bot / provider / security / router status\n"
            "`!ping` — quick alive check\n"
            "`!gather [3|6|12|18|24|48]` — catch up on recent Discord history with summaries\n"
            "`!help` — show this guide\n"
            "\n"
            "**Memory + recall**\n"
            "`!memory help` — memory subcommand help\n"
            "`!memory search <query>` — search your memories\n"
            "`!memory recent` — show recent memories\n"
            "`!memory stats` — show memory health + size\n"
            "`!memory forget <query>` — forget memories matching a query\n"
            "`!memory clear` — clear conversation history\n"
            "`!teach <text>` — explicitly teach a fact or preference\n"
            "`!teach list|remove <n>|clear` — manage teachings\n"
            "\n"
            "**Focus + threads**\n"
            "`!focus <topic> [duration]` — focus the assistant on a project or topic\n"
            "`!focus` — show current focus\n"
            "`!unfocus` — exit focus mode\n"
            "`!threads` — list detected conversation threads\n"
            "`!thread <topic>` — reopen a specific thread\n"
            "`!shortcuts` — list learned implicit shortcuts\n"
            "`!shortcuts remove <phrase>` — remove a shortcut\n"
            "\n"
            "**Export + scheduling**\n"
            "`!export today|week|project <name>|all` — export conversations to markdown\n"
            "`!cron list` — list scheduled jobs\n"
            "`!cron remove <id>` — remove a job\n"
            "`!cron run <id>` — run a job now\n"
            "`!profile` — show your user profile\n"
            "`!feedback` — show reaction feedback stats\n"
            "`!feedback clear` — clear feedback\n"
            "\n"
            "**Models + reasoning**\n"
            "`!model <name>` — switch model (opus / sonnet / gpt / gemini / qwen / auto)\n"
            "`!models` — list available model aliases, costs, and thinking support\n"
            "`!thinking <off|low|medium|high|max>` — set reasoning depth\n"
            "`!reasoning <level>` — alias for `!thinking`\n"
            "\n"
            "**Agents + orchestration**\n"
            "`!spawn <task>` — spawn an auto-named subagent\n"
            "`!spawn <name> <task>` — spawn a named subagent\n"
            "`!spawn 3 <task>` — spawn multiple auto-named subagents\n"
            "`!spawn a,b,c <task>` — spawn multiple named subagents\n"
            "`!agents` — list subagents and status\n"
            "`!agents kill <name>` — stop a subagent\n"
            "`!agents result <name>` — show a subagent result\n"
            "`!cost` — show your token usage / estimated cost\n"
            "`!cost all` — global cost summary (admin only)\n"
            "\n"
            "**Google Workspace shortcuts**\n"
            "`!gmail ...` — search / draft / send mail\n"
            "`!calendar ...` — list / create calendar events\n"
            "`!drive ...` — search and read Drive / Docs content\n"
            "\n"
            "**Platform / power-user**\n"
            "`!extensions` — list loaded extensions and status\n"
            "`!extensions reload <name>` — hot-reload an extension\n"
            "`!auth` — show API key health and auth status\n"
            "`!auth rotate [provider]` — rotate auth profile manually\n"
            "`!skills` — list custom skills\n"
            "`!webhooks` — show webhook delivery status\n"
            "\n"
            "**Capability discovery**\n"
            "`!discover` — show the next setup hint for unconfigured features\n"
            "`!discover audit` — full audit of what's not configured\n"
            "`!discover status` — show reminder category statuses\n"
            "`!discover snooze [hours]` — snooze reminders for a category\n"
            "`!discover disable [category]` — permanently disable a category\n"
            "`!discover off` / `!discover on` — toggle all reminders\n"
            "\n"
            "**Most useful discovery commands**\n"
            "If you're not sure what exists, start with: `!help`, `!discover audit`, `!models`, `!memory help`, `!agents`, `!extensions`, `!skills`."
        )

    async def _cmd_focus(self, user_id: str, args: str) -> str:
        """Start, show, or check focus mode."""
        from antaris_agent.core.focus import FocusManager, parse_duration_minutes

        focus: Optional[FocusManager] = getattr(self.bot, 'focus', None)
        if focus is None:
            return "Focus mode is not available."

        # No args: show current status
        if not args.strip():
            session = focus.get(user_id)
            if not session:
                return "No active focus session. Use `!focus <topic> [duration]` to start one."
            remaining = session.remaining_minutes
            if remaining < 0:
                time_str = "no time limit"
            else:
                time_str = f"{remaining}m remaining"
            return f"Focused on: **{session.topic}** ({time_str})"

        # Parse "<topic> [duration]"
        parts = args.strip().split()
        topic_parts = []
        duration_minutes = 0

        for part in parts:
            parsed = parse_duration_minutes(part)
            if parsed is not None:
                duration_minutes = parsed
                break
            topic_parts.append(part)

        if not topic_parts:
            return "Usage: `!focus <topic> [duration]` — e.g. !focus 'antaris agent' 1h"

        topic = " ".join(topic_parts)
        focus.start(user_id, topic, duration_minutes)

        if duration_minutes > 0:
            time_str = f"{duration_minutes}m"
        else:
            time_str = "no time limit"
        return f"Focus set: **{topic}** ({time_str}). Memory recall and context will prioritize this topic."

    async def _cmd_unfocus(self, user_id: str) -> str:
        """End focus mode."""
        from antaris_agent.core.focus import FocusManager

        focus: Optional[FocusManager] = getattr(self.bot, 'focus', None)
        if focus is None:
            return "Focus mode is not available."
        was_active = focus.stop(user_id)
        if was_active:
            return "Focus mode ended. Returning to general mode."
        return "No active focus session."

    async def _cmd_memory(self, user_id: str, args: str) -> str:
        """Memory subcommands: search, recent, stats, forget, help, clear."""
        text = args.strip()
        parts = text.split(maxsplit=1) if text else []
        subcmd = parts[0].lower() if parts else ""
        subargs = parts[1].strip() if len(parts) > 1 else ""

        # ── !memory (no args) or !memory help ────────────────────────────
        if not subcmd or subcmd == "help":
            return (
                "**🧠 Memory Commands:**\n"
                "`!memory search <query>` — search your memories\n"
                "`!memory recent` — show 5 most recent memories\n"
                "`!memory stats` — show memory statistics\n"
                "`!memory forget <query>` — forget memories matching a query\n"
                "`!memory clear` — clear conversation history\n"
                "`!memory help` — show this message"
            )

        # ── !memory clear (legacy: clear conversation history) ───────────
        if subcmd == "clear":
            pipeline = getattr(self.bot, 'pipeline', None)
            if not pipeline:
                return "❌ Pipeline not available."
            pipeline.clear_history(user_id)
            return "🧹 Conversation history cleared."

        # ── Remaining subcommands need bot.memory ────────────────────────
        bot_memory = getattr(self.bot, 'memory', None)
        if not bot_memory:
            return "❌ Memory system not available."

        # ── !memory search <query> ────────────────────────────────────────
        if subcmd == "search":
            if not subargs:
                return "Usage: `!memory search <query>`"
            try:
                results = bot_memory.search_memories(user_id, subargs, limit=5)
                if not results:
                    return f"🔍 No memories found matching **{subargs}**."
                lines = [f"**🔍 Memory search: \"{subargs}\"**\n"]
                for i, r in enumerate(results, 1):
                    content = r.get("content", "")
                    if len(content) > 200:
                        content = content[:200] + "..."
                    score = r.get("score", r.get("relevance", 0.0))
                    ts = r.get("timestamp") or r.get("created")
                    ts_str = ""
                    if ts:
                        try:
                            from datetime import datetime, timezone
                            if isinstance(ts, (int, float)):
                                dt = datetime.fromtimestamp(ts, tz=timezone.utc)
                            else:
                                dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
                            ts_str = f" _{dt.strftime('%b %d %H:%M UTC')}_"
                        except Exception:
                            pass
                    lines.append(f"**{i}.** {content}{ts_str}")
                return "\n".join(lines)
            except Exception as e:
                logger.warning("!memory search error: %s", e)
                return f"❌ Search failed: {e}"

        # ── !memory recent ────────────────────────────────────────────────
        if subcmd == "recent":
            try:
                store = bot_memory._get_store(user_id)
                # Use recall_recent (by time window) — 72h to ensure we get results
                entries = store.recall_recent(hours=72.0, limit=5)
                if not entries:
                    # Fallback: use .recent() by access order
                    entries = store.recent(limit=5)
                if not entries:
                    return "🕐 No recent memories found."
                lines = ["**🕐 Recent Memories:**\n"]
                for i, entry in enumerate(entries, 1):
                    content = getattr(entry, "content", str(entry))
                    if len(content) > 200:
                        content = content[:200] + "..."
                    # Timestamp from created field
                    created = getattr(entry, "created", None)
                    ts_str = ""
                    if created:
                        try:
                            from datetime import datetime, timezone
                            if isinstance(created, (int, float)):
                                dt = datetime.fromtimestamp(created, tz=timezone.utc)
                            else:
                                dt = datetime.fromisoformat(str(created).replace("Z", "+00:00"))
                            ts_str = f" _{dt.strftime('%b %d %H:%M UTC')}_"
                        except Exception:
                            pass
                    lines.append(f"**{i}.** {content}{ts_str}")
                return "\n".join(lines)
            except Exception as e:
                logger.warning("!memory recent error: %s", e)
                return f"❌ Could not retrieve recent memories: {e}"

        # ── !memory stats ─────────────────────────────────────────────────
        if subcmd == "stats":
            try:
                user_stats = bot_memory.stats(user_id)
                entry_count = user_stats.get("entry_count", 0)
                size_bytes = user_stats.get("store_size_bytes", 0)
                newest = user_stats.get("newest_entry")
                error = user_stats.get("error")

                # Health from the underlying MemorySystem
                health_str = "unknown"
                try:
                    store = bot_memory._get_store(user_id)
                    health = store.get_health()
                    all_ok = all(health.get("checks", {}).values())
                    health_str = "✅ healthy" if all_ok else "⚠️ degraded"
                except Exception:
                    pass

                # Format size
                if size_bytes >= 1_048_576:
                    size_str = f"{size_bytes / 1_048_576:.1f} MB"
                elif size_bytes >= 1024:
                    size_str = f"{size_bytes / 1024:.1f} KB"
                else:
                    size_str = f"{size_bytes} B"

                lines = ["**🧠 Memory Stats**"]
                lines.append(f"Total memories: **{entry_count:,}**")
                lines.append(f"Store size: **{size_str}**")
                lines.append(f"Health: {health_str}")
                if newest:
                    try:
                        from datetime import datetime, timezone
                        dt = datetime.fromisoformat(newest.replace("Z", "+00:00"))
                        lines.append(f"Last ingestion: **{dt.strftime('%b %d %H:%M UTC')}**")
                    except Exception:
                        lines.append(f"Last ingestion: {newest}")
                if error:
                    lines.append(f"⚠️ Error: {error}")
                return "\n".join(lines)
            except Exception as e:
                logger.warning("!memory stats error: %s", e)
                return f"❌ Could not retrieve stats: {e}"

        # ── !memory forget <query> ────────────────────────────────────────
        if subcmd == "forget":
            if not subargs:
                return "Usage: `!memory forget <query>` — forgets memories matching the query."
            try:
                store = bot_memory._get_store(user_id)
                # Preview: search for matching memories first
                preview_results = bot_memory.search_memories(user_id, subargs, limit=5)
                # Call forget on the underlying store
                result = store.forget(topic=subargs)
                forgotten = 0
                if isinstance(result, dict):
                    forgotten = result.get("forgotten", result.get("deleted", result.get("count", 0)))
                elif isinstance(result, int):
                    forgotten = result

                if forgotten == 0 and not preview_results:
                    return f"🔍 No memories found matching **\"{subargs}\"**. Nothing forgotten."

                lines = [f"🗑️ Forgot **{forgotten}** memor{'y' if forgotten == 1 else 'ies'} matching **\"{subargs}\"**."]
                if preview_results:
                    lines.append("_(Matched entries included:)_")
                    for r in preview_results[:3]:
                        snippet = r.get("content", "")[:100]
                        if len(r.get("content", "")) > 100:
                            snippet += "..."
                        lines.append(f"• {snippet}")
                try:
                    store.save()
                except Exception as _save_err:
                    logger.warning("Memory save after forget failed: %s", _save_err)
                return "\n".join(lines)
            except Exception as e:
                logger.warning("!memory forget error: %s", e)
                return f"❌ Forget failed: {e}"

        # ── Unknown subcommand ────────────────────────────────────────────
        return (
            f"Unknown memory subcommand: `{subcmd}`\n"
            "Try: `!memory help` to see available options."
        )

    async def _cmd_cron(self, user_id: str, args: str) -> str:
        """Manage cron jobs."""
        cron = getattr(self.bot, 'cron', None)
        if not cron:
            return "❌ Cron scheduler not available."

        parts = args.split(maxsplit=1) if args else []
        subcmd = parts[0].lower() if parts else "list"

        if subcmd == "list":
            jobs = cron.list_jobs()
            if not jobs:
                return "📋 No cron jobs scheduled."
            lines = ["**📋 Cron Jobs:**"]
            for job in jobs:
                status = "✅" if job.enabled else "⏸️"
                lines.append(f"{status} `{job.id[:8]}` **{job.name}** — {job.schedule_kind}")
            return "\n".join(lines)

        elif subcmd == "remove" and len(parts) > 1:
            job_id = parts[1].strip()
            # Try partial match
            for jid in [j.id for j in cron.list_jobs()]:
                if jid.startswith(job_id):
                    cron.remove_job(jid)
                    return f"✅ Removed job `{jid[:8]}`."
            return f"❌ No job found matching `{job_id}`."

        elif subcmd == "run" and len(parts) > 1:
            job_id = parts[1].strip()
            for job in cron.list_jobs():
                if job.id.startswith(job_id):
                    cron.run_now(job.id)
                    return f"▶️ Job `{job.id[:8]}` queued to run next tick."
            return f"❌ No job found matching `{job_id}`."

        return "Usage: `!cron list` | `!cron remove <id>` | `!cron run <id>`"

    async def _cmd_profile(self, user_id: str, args: str) -> str:
        """Show user profile."""
        profiles = getattr(self.bot, 'profiles', None)
        if not profiles:
            return "❌ Profile manager not available."
        profile = profiles.get(user_id)
        lines = [f"**👤 Profile: `{user_id}`**"]
        if profile.display_name:
            lines.append(f"Name: {profile.display_name}")
        lines.append(f"Messages: {profile.message_count}")
        lines.append(f"Style: {profile.conversation_style}")
        if profile.last_seen:
            lines.append(f"Last seen: {profile.last_seen[:19].replace('T', ' ')} UTC")
        if profile.notes:
            lines.append(f"Notes: {len(profile.notes)} stored")
        return "\n".join(lines)

    async def _cmd_teach(self, user_id: str, args: str) -> str:
        """Manage user teachings."""
        teachings = getattr(self.bot, 'teachings', None)
        if not teachings:
            return "❌ Teaching store not available."

        text = args.strip()

        if not text or text.lower() == "list":
            items = teachings.list(user_id)
            if not items:
                return "📚 No teachings stored. Use `!teach <text>` to add one."
            lines = ["**📚 Your Teachings:**"]
            for i, t in enumerate(items, 1):
                lines.append(f"{i}. {t['text']}")
            return "\n".join(lines)

        if text.lower() == "clear":
            count = teachings.clear(user_id)
            if count == 0:
                return "📚 No teachings to clear."
            return f"🧹 Cleared {count} teaching(s)."

        parts = text.split(maxsplit=1)
        if parts[0].lower() == "remove":
            if len(parts) < 2:
                return "Usage: `!teach remove <n>`"
            try:
                index = int(parts[1].strip())
            except ValueError:
                return "Usage: `!teach remove <n>` — n must be a number."
            success = teachings.remove(user_id, index)
            if success:
                return f"✅ Teaching #{index} removed."
            return f"❌ No teaching #{index}. Use `!teach list` to see your teachings."

        # Store the teaching
        count = teachings.add(user_id, text)
        return f"✅ Got it! Teaching stored. You now have {count} teaching(s). Use `!teach list` to review."

    async def _cmd_threads(self, user_id: str) -> str:
        """List all active conversation threads for the user."""
        threads = getattr(self.bot, 'threads', None)
        if not threads:
            return "Thread tracking is not available."
        summaries = threads.list_threads(user_id)
        if not summaries:
            return "No conversation threads yet. Chat a bit and they will appear here."
        lines = ["**🧵 Conversation Threads:**"]
        for s in summaries:
            last_ts = s["last_active"]
            import time as _time
            age_s = _time.time() - last_ts
            if age_s < 3600:
                age = f"{int(age_s // 60)}m ago"
            elif age_s < 86400:
                age = f"{int(age_s // 3600)}h ago"
            else:
                age = f"{int(age_s // 86400)}d ago"
            lines.append(
                f"**{s['name']}** -- {s['turn_count']} turns, last active {age}"
            )
        return "\n".join(lines)

    async def _cmd_thread(self, user_id: str, args: str) -> str:
        """Show the conversation thread matching a topic query."""
        threads = getattr(self.bot, 'threads', None)
        if not threads:
            return "Thread tracking is not available."
        query = args.strip()
        if not query:
            return "Usage: `!thread <topic>` -- e.g. `!thread website` or `!thread deployment`"
        turns = threads.get_thread(user_id, query)
        if not turns:
            return f"No thread found matching '{query}'. Use `!threads` to see available topics."
        lines = [f"**🧵 Thread: {turns[0]['topic']}** ({len(turns)} turns)\n"]
        for t in turns[-20:]:  # show up to 20 most recent turns
            prefix = "You" if t["role"] == "user" else "Antaris"
            snippet = t["content"][:200].replace("\n", " ")
            if len(t["content"]) > 200:
                snippet += "..."
            lines.append(f"**{prefix}:** {snippet}")
        return "\n".join(lines)

    async def _cmd_export(self, user_id: str, args: str) -> str:
        """Export conversation history to a markdown file."""
        exporter = getattr(self.bot, 'exporter', None)
        if not exporter:
            return "Export is not available."

        text = args.strip().lower()

        if not text:
            return (
                "**Export usage:**\n"
                "`!export today` — export today's conversation\n"
                "`!export week` — export last 7 days\n"
                "`!export project <name>` — export conversations about a topic\n"
                "`!export all` — export everything"
            )

        if text == "today":
            filepath, summary = exporter.export_recent(user_id, days=1)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        if text == "week":
            filepath, summary = exporter.export_recent(user_id, days=7)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        if text == "all":
            filepath, summary = exporter.export_all(user_id)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        # project <name>
        parts = args.strip().split(maxsplit=1)
        if parts[0].lower() == "project":
            if len(parts) < 2 or not parts[1].strip():
                return "Usage: `!export project <name>`"
            topic = parts[1].strip()
            filepath, summary = exporter.export_by_topic(user_id, topic)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        return (
            "Unknown export option. Try:\n"
            "`!export today` | `!export week` | `!export project <name>` | `!export all`"
        )

    async def _cmd_shortcuts(self, user_id: str, args: str) -> str:
        """List or remove learned implicit shortcuts."""
        shortcuts = getattr(self.bot, 'shortcuts', None)
        if not shortcuts:
            return "Shortcut learning is not available."

        text = args.strip()

        if not text:
            items = shortcuts.list_shortcuts(user_id)
            if not items:
                return (
                    "No shortcuts learned yet. "
                    "Use short phrases repeatedly for the same action and I will learn them automatically."
                )
            lines = ["**Learned Shortcuts:**"]
            for item in items:
                lines.append(f'`{item["phrase"]}` -> {item["expansion"]} (seen {item["count"]}x)')
            return "\n".join(lines)

        parts = text.split(maxsplit=1)
        if parts[0].lower() == "remove":
            if len(parts) < 2:
                return "Usage: `!shortcuts remove <phrase>`"
            phrase = parts[1].strip()
            removed = shortcuts.remove(user_id, phrase)
            if removed:
                return f'Shortcut `{phrase}` removed.'
            return f'No shortcut found for `{phrase}`. Use `!shortcuts` to see your shortcuts.'

        return "Usage: `!shortcuts` or `!shortcuts remove <phrase>`"

    async def _cmd_feedback(self, user_id: str, args: str) -> str:
        """Show or clear reaction-based feedback."""
        feedback = getattr(self.bot, 'feedback', None)
        if not feedback:
            return "Feedback tracking is not available."

        text = args.strip().lower()

        if text == "clear":
            feedback.clear(user_id)
            return "Feedback cleared."

        stats = feedback.get_stats(user_id)
        if stats["total"] == 0:
            return (
                "No feedback recorded yet.\n"
                "React to my messages with 👍 or 👎 to train my responses."
            )

        pos = stats["positive"]
        neg = stats["negative"]
        total = stats["total"]
        lines = [
            f"**Reaction Feedback ({total} total)**",
            f"Positive: {pos} (👍 ❤️ ✅ 🔥 💯 👏)",
            f"Negative: {neg} (👎 ❌ 😕 🚫)",
            "",
            "Use `!feedback clear` to reset.",
        ]
        return "\n".join(lines)

    # ── Subagent commands ─────────────────────────────────────────────────

    async def _cmd_spawn(self, inbound: "InboundMessage", args: str) -> str:
        """
        !spawn [name] <task>
        !spawn <task>            — auto-named (a, b, c …)
        !spawn 3 <task>          — spawn 3 auto-named agents with the same task
        !spawn a,b,c <task>      — spawn named agents a, b, c with same task
        """
        if not hasattr(self.bot, "subagents"):
            return "⚠️ Subagent system not initialised."

        args = args.strip()
        if not args:
            return "Usage: `!spawn [name] <task>` — e.g. `!spawn scout Research antaris-suite competitors`"

        registry = self.bot.subagents
        channel = getattr(self.bot, "_active_discord_channel", None)

        # Parse: "3 <task>" → spawn 3 auto-named agents
        parts = args.split(maxsplit=1)
        if parts[0].isdigit():
            count = int(parts[0])
            task = parts[1] if len(parts) > 1 else "No task specified."
            results = await registry.spawn_many([task] * count, origin_channel=channel)
            lines = [msg for _, msg in results]
            return "\n".join(lines)

        # Parse: "a,b,c <task>" → spawn named agents
        if "," in parts[0] and len(parts) > 1:
            names = [n.strip() for n in parts[0].split(",")]
            task = parts[1]
            results = await registry.spawn_many([task] * len(names), names=names, origin_channel=channel)
            lines = [msg for _, msg in results]
            return "\n".join(lines)

        # Parse: "name task…" — first word is name if it looks like a label
        # (single word, no spaces, short) — otherwise whole thing is the task
        first = parts[0]
        rest = parts[1] if len(parts) > 1 else ""

        if rest and len(first) <= 20 and first.replace("-", "").replace("_", "").isalnum():
            # "scout research competitors" → name=scout, task=research competitors
            name = first
            task = rest
        else:
            # whole args is the task, auto-name
            name = None
            task = args

        channel = getattr(self.bot, "_active_discord_channel", None)
        ok, msg = await registry.spawn(task=task, name=name, origin_channel=channel)
        return msg

    async def _cmd_agents(self, inbound: "InboundMessage", args: str) -> str:
        """
        !agents             — list all subagents
        !agents kill <name> — terminate a subagent
        !agents result <name> — get full result text
        """
        if not hasattr(self.bot, "subagents"):
            return "⚠️ Subagent system not initialised."

        registry = self.bot.subagents
        args = args.strip()

        if not args:
            return registry.status_board()

        parts = args.split(maxsplit=1)
        subcmd = parts[0].lower()
        name = parts[1].strip() if len(parts) > 1 else ""

        if subcmd == "kill":
            if not name:
                return "Usage: `!agents kill <name>`"
            ok, msg = await registry.kill(name)
            return msg

        if subcmd == "result":
            if not name:
                return "Usage: `!agents result <name>`"
            text = registry.result_text(name)
            if text is None:
                return f"No result for **{name}** yet."
            return f"**Result from {name}:**\n{text}"

        return f"Unknown subcommand `{subcmd}`. Try: `!agents`, `!agents kill <name>`, `!agents result <name>`"

    # ── Cost command ──────────────────────────────────────────────────────

    async def _cmd_cost(self, user_id: str, args: str) -> str:
        """
        !cost       — show the requesting user's token usage and cost
        !cost all   — show global summary (admin only)
        """
        try:
            pipeline = getattr(self.bot, "pipeline", None)
            if not pipeline:
                return "❌ Pipeline not available."

            cost_tracker = getattr(pipeline, "cost_tracker", None)
            if not cost_tracker:
                return "❌ Cost tracker not available."

            if not cost_tracker.enabled:
                return "ℹ️ Cost tracking is disabled."

            sub = args.strip().lower()

            if sub == "all":
                # Admin-only: check owner_user_id or admin_users
                config = getattr(self.bot, "config", None)
                is_admin = False
                if config:
                    owner = getattr(config, "owner_user_id", "")
                    if owner and str(user_id) == str(owner):
                        is_admin = True
                    # Also check admin_users list if present
                    admin_users = getattr(config, "admin_users", [])
                    if str(user_id) in [str(u) for u in admin_users]:
                        is_admin = True

                if not is_admin:
                    return "⛔ `!cost all` is restricted to bot admins."

                return cost_tracker.format_global_summary()

            # Default: show requesting user's stats
            return cost_tracker.format_user_stats(user_id)

        except Exception as e:
            logger.warning("_cmd_cost failed: %s", e)
            return "❌ Could not retrieve cost stats."

    # ── Extension commands ────────────────────────────────────────────────

    async def _cmd_extensions(self, user_id: str, args: str) -> str:
        """
        !extensions          — list all extensions and their status
        !extensions reload <name> — hot-reload an extension
        !extensions disable <name> — disable an extension
        """
        manager = getattr(self.bot, '_extension_manager', None)
        if not manager:
            return "Extension system not available."

        text = args.strip()
        if not text:
            return manager.status_board()

        parts = text.split(maxsplit=1)
        subcmd = parts[0].lower()
        name = parts[1].strip() if len(parts) > 1 else ""

        if subcmd == "reload" and name:
            success = await manager.reload(name)
            if success:
                return f"✅ Extension **{name}** reloaded."
            return f"❌ Failed to reload **{name}**."

        if subcmd == "disable" and name:
            success = await manager.unload(name)
            if success:
                return f"⏸️ Extension **{name}** disabled."
            return f"❌ Could not disable **{name}**."

        return "Usage: `!extensions`, `!extensions reload <name>`, `!extensions disable <name>`"

    async def _cmd_auth(self, user_id: str, args: str) -> str:
        """Show auth/API key status or manage profiles.
        
        Usage:
            !auth          — show auth status
            !auth rotate   — manually trigger profile rotation for primary provider
            !auth rotate <provider> — rotate a specific provider
        """
        auth_monitor = getattr(self.bot, 'auth_monitor', None)
        if not auth_monitor:
            return "Auth monitoring not available."

        subcmd = args.strip().split()[0].lower() if args.strip() else ""

        if subcmd == "rotate":
            # Manual rotation
            parts = args.strip().split()
            provider = parts[1] if len(parts) > 1 else self.bot.config.provider_name
            current_profile = auth_monitor.get_active_profile(provider)
            result = auth_monitor.try_rotate_profile(
                provider,
                current_profile=current_profile,
                reason="manual",
            )
            if result:
                new_pid, new_cred = result
                # Update the live provider's key
                dispatcher = getattr(self.bot, 'dispatcher', None)
                if dispatcher:
                    p = dispatcher.get(provider)
                    if p:
                        p.api_key = new_cred
                    dispatcher.set_active_profile(provider, new_pid)
                return f"🔄 Rotated **{provider}** to profile `{new_pid}`"
            return f"❌ No alternative profile available for **{provider}**"

        return auth_monitor.get_status_text()

    async def _cmd_skills(self, user_id: str, args: str) -> str:
        """Show custom skills status."""
        skill_reg = getattr(self.bot, 'skill_registry', None)
        if not skill_reg:
            return "Custom skills not available."
        return skill_reg.status_text()

    async def _cmd_thinking(self, user_id: str, args: str) -> str:
        """Set thinking/reasoning level."""
        controller = getattr(self.bot, 'model_controller', None)
        if not controller:
            return "Model control not available."

        if not args.strip():
            level, budget = controller.get_thinking_for_user(user_id)
            if level == "off":
                return "🧠 Thinking: off\nSet with: `!thinking low|medium|high|max` or `!reasoning low|medium|high|max`"
            support = controller.get_thinking_support(user_id)
            if support.supported:
                return (
                    f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)\n"
                    f"✅ Active on `{support.model}` via {support.provider}" +
                    (f" ({support.mechanism})" if support.mechanism else "")
                )
            if support.model and support.provider:
                return (
                    f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)\n"
                    f"⚠️ Current model `{support.model}` via {support.provider} does not support provider-side thinking."
                )
            return f"🧠 Thinking: **{level}** (budget: {budget:,} tokens)"

        return controller.set_thinking(user_id, args.strip())

    async def _cmd_models(self, user_id: str) -> str:
        """List available model aliases and costs."""
        from antaris_agent.extensions.model_control import MODEL_ALIASES, MODEL_COSTS
        lines = ["**Available Models:**\n"]

        providers: dict = {}
        seen = set()
        for alias, (model, provider) in sorted(MODEL_ALIASES.items()):
            if provider not in providers:
                providers[provider] = []
            cost_info = ""
            if model in MODEL_COSTS:
                in_c, out_c = MODEL_COSTS[model]
                cost_info = f" (${in_c}/{out_c})"
            entry = f"`{alias}` → {model}{cost_info}"
            if entry not in seen:
                providers[provider].append(entry)
                seen.add(entry)

        for provider, entries in providers.items():
            lines.append(f"**{provider.title()}:**")
            for entry in entries:
                lines.append(f"  {entry}")
            lines.append("")

        lines.append("Use `!model <alias>` to switch, `!thinking <level>` (or `!reasoning <level>`) for reasoning depth")
        return "\n".join(lines)

    async def _cmd_discover(self, user_id: str, args: str) -> str:
        """
        !discover           — show the next capability hint
        !discover status    — show all category statuses
        !discover audit     — show all unconfigured capabilities (full audit)
        !discover dismiss   — dismiss the current hint category
        !discover snooze [hours] — snooze the current hint category
        !discover disable [category] — permanently disable a category
        !discover enable [category]  — re-enable a category
        !discover off       — disable all discovery reminders
        !discover on        — re-enable discovery reminders
        !discover reset     — reset all discovery state
        """
        from antaris_agent.core.discovery import (
            DiscoveryManager, ALL_CATEGORIES, CATEGORY_LABELS,
            format_hint_markdown, format_status_markdown,
        )
        from pathlib import Path

        config_dir = str(Path(self.bot.config.config_path).parent)
        dm = DiscoveryManager(config_dir)

        text = args.strip().lower()
        parts = text.split() if text else []
        subcmd = parts[0] if parts else ""

        if not subcmd:
            # Show the next hint (ignore timing constraints for manual invocation)
            hints = dm.get_all_hints(self.bot.config)
            # Filter out disabled/snoozed categories
            import time as _time
            now = _time.time()
            eligible = [
                h for h in hints
                if not dm.state.categories.get(h.category, type('', (), {'permanently_disabled': False, 'snoozed_until': 0})()).permanently_disabled
                and dm.state.categories.get(h.category, type('', (), {'snoozed_until': 0})()).snoozed_until <= now
            ]
            if not eligible:
                return "✅ All capabilities configured! Nothing to discover right now."
            hint = eligible[0]
            dm.mark_shown(hint.category, message_count=getattr(self.bot, '_message_count', 0))
            return format_hint_markdown(hint)

        if subcmd == "status":
            status = dm.get_category_status()
            return format_status_markdown(status)

        if subcmd == "audit":
            hints = dm.get_all_hints(self.bot.config)
            if not hints:
                return "✅ **Full capability audit complete** — everything is configured!"
            lines = ["**🔍 Capability Audit — Unconfigured Features:**\n"]
            current_cat = None
            for hint in hints:
                if hint.category != current_cat:
                    current_cat = hint.category
                    label = CATEGORY_LABELS.get(hint.category, hint.category)
                    lines.append(f"\n**{label}**")
                lines.append(f"  • **{hint.title}** — {hint.message[:100]}...")
                lines.append(f"    → {hint.action_hint}")
            return "\n".join(lines)

        if subcmd == "dismiss":
            # Dismiss the most recently relevant category
            hints = dm.get_all_hints(self.bot.config)
            if hints:
                dm.dismiss(hints[0].category)
                label = CATEGORY_LABELS.get(hints[0].category, hints[0].category)
                return f"👋 Dismissed {label} hint. It will come back next check cycle."
            return "Nothing to dismiss."

        if subcmd == "snooze":
            hours = 24.0
            if len(parts) > 1:
                try:
                    hours = float(parts[1])
                except ValueError:
                    return "Usage: `!discover snooze [hours]` — e.g. `!discover snooze 48`"
            hints = dm.get_all_hints(self.bot.config)
            if hints:
                dm.snooze(hints[0].category, hours=hours)
                label = CATEGORY_LABELS.get(hints[0].category, hints[0].category)
                return f"😴 Snoozed {label} for {hours:.0f} hours."
            return "Nothing to snooze."

        if subcmd == "disable":
            if len(parts) > 1:
                cat = parts[1]
                # Try to match by name or partial
                matched = None
                for c in ALL_CATEGORIES:
                    if c == cat or c.startswith(cat) or cat in c:
                        matched = c
                        break
                if not matched:
                    cats = ", ".join(f"`{c}`" for c in ALL_CATEGORIES)
                    return f"Unknown category `{cat}`. Available: {cats}"
                dm.disable(matched)
                label = CATEGORY_LABELS.get(matched, matched)
                return f"🔴 Permanently disabled {label} reminders. Use `!discover enable {matched}` to re-enable."
            # No category specified: disable the top hint category
            hints = dm.get_all_hints(self.bot.config)
            if hints:
                dm.disable(hints[0].category)
                label = CATEGORY_LABELS.get(hints[0].category, hints[0].category)
                return f"🔴 Permanently disabled {label} reminders."
            return "Nothing to disable."

        if subcmd == "enable":
            if len(parts) > 1:
                cat = parts[1]
                matched = None
                for c in ALL_CATEGORIES:
                    if c == cat or c.startswith(cat) or cat in c:
                        matched = c
                        break
                if not matched:
                    cats = ", ".join(f"`{c}`" for c in ALL_CATEGORIES)
                    return f"Unknown category `{cat}`. Available: {cats}"
                dm.enable(matched)
                label = CATEGORY_LABELS.get(matched, matched)
                return f"🟢 Re-enabled {label} reminders."
            return "Usage: `!discover enable <category>` — e.g. `!discover enable automation`"

        if subcmd == "off":
            dm.disable_all()
            return "🔴 All discovery reminders disabled. Use `!discover on` to re-enable."

        if subcmd == "on":
            dm.enable_all()
            return "🟢 Discovery reminders re-enabled."

        if subcmd == "reset":
            dm.reset()
            return "🔄 Discovery state reset to defaults."

        return (
            "**🔍 Discover Commands:**\n"
            "`!discover` — show the next capability hint\n"
            "`!discover status` — show all category statuses\n"
            "`!discover audit` — full audit of unconfigured features\n"
            "`!discover dismiss` — dismiss the current hint\n"
            "`!discover snooze [hours]` — snooze current category (default: 24h)\n"
            "`!discover disable [category]` — permanently disable a category\n"
            "`!discover enable <category>` — re-enable a disabled category\n"
            "`!discover off` — disable all reminders\n"
            "`!discover on` — re-enable all reminders\n"
            "`!discover reset` — reset all discovery state\n"
            f"\nCategories: {', '.join(f'`{c}`' for c in ALL_CATEGORIES)}"
        )

    async def _cmd_webhooks(self, user_id: str, args: str) -> str:
        """Show webhook status."""
        webhooks = getattr(self.bot, 'webhooks', None)
        if not webhooks:
            return "Webhook system not available."

        status = webhooks.status()
        lines = ["**🔗 Webhooks:**"]
        lines.append(f"Running: {'✅' if status['running'] else '❌'}")
        lines.append(f"Queue size: {status['queue_size']}")
        lines.append(f"Sent: {status['stats']['total_sent']}")
        lines.append(f"Failed: {status['stats']['total_failed']}")

        for ep in status['endpoints']:
            icon = "✅" if ep['enabled'] else "⏸️"
            circuit = " ⚡OPEN" if ep.get('circuit_open') else ""
            events = ep['events'] if ep['events'] != "all" else "all events"
            lines.append(f"\n{icon} `{ep['url']}`{circuit}")
            lines.append(f"  Events: {events}")
            if ep.get('failure_count', 0) > 0:
                lines.append(f"  Failures: {ep['failure_count']}")

        return "\n".join(lines)
