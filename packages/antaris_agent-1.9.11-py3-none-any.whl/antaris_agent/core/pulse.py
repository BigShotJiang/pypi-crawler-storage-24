"""
antaris pulse — System health check.

Checks every system component and reports status.
Run before launching to verify everything is configured correctly.
"""

import asyncio
import httpx
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

def _resolve_config_dir() -> Path:
    """Resolve the config directory, honoring explicit config path overrides."""
    from antaris_agent.core.config import resolve_config_path
    return resolve_config_path().parent

DEFAULT_CONFIG_DIR = _resolve_config_dir()


@dataclass
class PulseCheck:
    name: str
    status: str  # "ok" | "warn" | "fail" | "skip"
    message: str = ""
    detail: str = ""

    def icon(self) -> str:
        return {"ok": "✅", "warn": "⚠️ ", "fail": "❌", "skip": "⏭️ "}.get(self.status, "?")

    def __str__(self) -> str:
        base = f"{self.icon()} {self.name}"
        if self.message:
            base += f" — {self.message}"
        if self.detail:
            base += f"\n     {self.detail}"
        return base


@dataclass
class PulseReport:
    checks: list = field(default_factory=list)

    def add(self, check: PulseCheck):
        self.checks.append(check)

    def passed(self) -> bool:
        return not any(c.status == "fail" for c in self.checks)

    def has_warnings(self) -> bool:
        return any(c.status == "warn" for c in self.checks)

    def summary(self) -> str:
        lines = ["", "🔬 antaris pulse — system health check", ""]
        for check in self.checks:
            lines.append(f"  {check}")
        lines.append("")
        if self.passed():
            if self.has_warnings():
                lines.append("  ⚡ Ready to launch — with warnings above")
            else:
                lines.append("  ⚡ All systems go — antaris start")
        else:
            lines.append("  ❌ Issues found — resolve before launching")
        lines.append("")
        return "\n".join(lines)


async def run_pulse(config_dir: Optional[str] = None) -> PulseReport:
    """Run all health checks and return a PulseReport."""
    report = PulseReport()
    cfg_dir = Path(config_dir or DEFAULT_CONFIG_DIR)

    # ── Check 1: Config file ────────────────────────────────────────────────
    config_path = cfg_dir / "config.json"
    if not config_path.exists():
        report.add(PulseCheck("config", "fail", "config.json not found", "Run: antaris init"))
        return report  # can't continue without config

    try:
        import json
        cfg = json.loads(config_path.read_text())
        report.add(PulseCheck("config", "ok", f"found at {config_path}"))
    except Exception as e:
        report.add(PulseCheck("config", "fail", f"parse error: {e}"))
        return report

    # ── Check 2: API key ────────────────────────────────────────────────────
    provider = cfg.get("provider", {}).get("name", "anthropic")
    api_key = cfg.get("provider", {}).get("apiKey", "")
    if not api_key:
        try:
            from antaris_agent.core.config import resolve_provider_credential
            cred, profile_id = resolve_provider_credential(provider, cfg.get("authProfilesPath") or cfg.get("provider", {}).get("authProfilesPath"))
            if cred:
                api_key = cred
                cfg.setdefault("provider", {})["apiKey"] = cred
                cfg["resolvedAuthProfile"] = profile_id
        except Exception:
            pass
    auth_profiles = cfg.get("auth_profiles", {})
    if auth_profiles.get("enabled"):
        try:
            from antaris_agent.core.config import load_auth_profile_credential
            resolved_provider, resolved_key = load_auth_profile_credential(provider, auth_profiles.get("path") or None)
            if resolved_key:
                api_key = resolved_key
                provider = resolved_provider or provider
        except Exception:
            pass
    if not api_key:
        report.add(PulseCheck("api_key", "fail", "no API key configured", "Run: antaris init"))
    elif len(api_key) < 20:
        report.add(PulseCheck("api_key", "warn", "API key looks short — verify it's correct"))
    else:
        suffix = f" via {cfg.get("resolvedAuthProfile")}" if cfg.get("resolvedAuthProfile") else ""
        report.add(PulseCheck("api_key", "ok", f"{provider} key present ({api_key[:8]}...){suffix}"))

    # ── Check 3: API connectivity ───────────────────────────────────────────
    if api_key and len(api_key) >= 20:
        api_ok, api_msg = await _check_api(provider, api_key, cfg)
        report.add(PulseCheck("api_connectivity", api_ok, api_msg))

    # ── Check 4: SOUL.md ────────────────────────────────────────────────────
    soul_path = cfg_dir / "SOUL.md"
    if not soul_path.exists():
        report.add(PulseCheck("soul_md", "warn", "SOUL.md not found", "Bot will use default persona"))
    else:
        content = soul_path.read_text().strip()
        if "AWAKENING_NEEDED" in content or len(content) < 20:
            report.add(PulseCheck("soul_md", "warn", "awaiting awakening", "First message will trigger identity setup"))
        else:
            name_line = content.split("\n")[0].replace("#", "").strip()
            report.add(PulseCheck("soul_md", "ok", f"persona: {name_line[:40]}"))

    # ── Check 5: Memory store ───────────────────────────────────────────────
    memory_store = cfg.get("memory", {}).get("store", str(cfg_dir / "memory"))
    memory_path = Path(memory_store)
    if not memory_path.exists():
        report.add(PulseCheck("memory_store", "warn", "store directory not created yet", "Created on first conversation"))
    else:
        user_dirs = [d for d in memory_path.iterdir() if d.is_dir()]
        total_files = sum(len(list(d.glob("**/*"))) for d in user_dirs)
        report.add(PulseCheck("memory_store", "ok", f"{len(user_dirs)} user(s), ~{total_files} memory files"))

    # ── Check 6: Discord config ─────────────────────────────────────────────
    discord = cfg.get("channels", {}).get("discord", {})
    if not discord.get("enabled", False):
        report.add(PulseCheck("discord", "skip", "not configured (terminal mode only)"))
    elif not discord.get("token", ""):
        report.add(PulseCheck("discord", "fail", "enabled but no token", "antaris config set discord-token <token>"))
    else:
        token = discord["token"]
        report.add(PulseCheck("discord", "ok", f"token present ({token[:10]}...)"))

    # ── Check 7: antaris-suite packages ────────────────────────────────────
    suite_ok = await _check_suite()
    report.add(suite_ok)

    # ── Check 8: Disk space ─────────────────────────────────────────────────
    try:
        import shutil
        usage = shutil.disk_usage(cfg_dir)
        free_gb = usage.free / (1024 ** 3)
        if free_gb < 0.5:
            report.add(PulseCheck("disk_space", "warn", f"{free_gb:.1f}GB free — low", "Memory store may not grow"))
        else:
            report.add(PulseCheck("disk_space", "ok", f"{free_gb:.1f}GB free"))
    except Exception:
        report.add(PulseCheck("disk_space", "skip", "could not check"))

    return report


async def _check_api(provider: str, api_key: str, cfg: dict) -> tuple[str, str]:
    """Ping the API to verify the key works. Returns (status, message)."""
    try:
        if provider == "anthropic":
            async with httpx.AsyncClient(timeout=8.0) as client:
                headers = {
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                }
                if api_key.startswith("sk-ant-oat"):
                    headers["Authorization"] = f"Bearer {api_key}"
                    headers["anthropic-beta"] = "oauth-2025-04-20"
                else:
                    headers["x-api-key"] = api_key
                r = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers=headers,
                    json={
                        "model": "claude-haiku-4-5-20251001",
                        "max_tokens": 1,
                        "messages": [{"role": "user", "content": "hi"}],
                    },
                )
                if r.status_code in (200, 400):  # 400 = bad request but key is valid
                    return "ok", "Anthropic API reachable"
                elif r.status_code == 401:
                    return "fail", "Invalid API key"
                else:
                    return "warn", f"Unexpected status {r.status_code}"
        elif provider == "openai":
            async with httpx.AsyncClient(timeout=8.0) as client:
                r = await client.get(
                    "https://api.openai.com/v1/models",
                    headers={"Authorization": f"Bearer {api_key}"},
                )
                if r.status_code == 200:
                    return "ok", "OpenAI API reachable"
                elif r.status_code == 403:
                    return "ok", "OpenAI auth accepted (restricted endpoint access)"
                elif r.status_code == 401:
                    return "fail", "Invalid API key"
                else:
                    return "warn", f"Unexpected status {r.status_code}"
        else:
            return "skip", f"Connectivity check not implemented for {provider}"
    except httpx.TimeoutException:
        return "warn", "API timeout — check your internet connection"
    except Exception as e:
        return "warn", f"Could not reach API: {e}"


async def _check_suite() -> PulseCheck:
    """Verify bundled suite packages are importable."""
    packages = [
        "parsica_memory",
        "antaris_agent.suite.guard",
        "antaris_agent.suite.context",
        "antaris_agent.suite.router",
        "antaris_agent.suite.pipeline",
    ]
    missing = []
    for pkg in packages:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg.split(".")[-1])

    if missing:
        return PulseCheck(
            "antaris_suite",
            "fail",
            f"missing suite modules: {', '.join(missing)}",
            "pip install antaris-agent",
        )
    return PulseCheck("antaris_suite", "ok", "all suite modules present")
