"""
Extension base classes and contracts.

An Extension is a self-contained unit of functionality that can:
  - Register hooks into the pipeline lifecycle
  - Register custom native tools
  - Register ! commands
  - Emit and subscribe to events
  - Declare webhooks
  - Access bot components through ExtensionContext
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from antaris_agent.core.bot import Bot
    from antaris_agent.suite.pipeline.hooks import PipelineHooks
    from antaris_agent.tools.tool_registry import ToolRegistry
    from antaris_agent.tools.models import NativeTool

logger = logging.getLogger(__name__)


class ExtensionState(Enum):
    """Lifecycle state of an extension."""
    REGISTERED = "registered"    # Known but not loaded
    LOADING = "loading"          # on_load() in progress
    ACTIVE = "active"            # Loaded and running
    ERROR = "error"              # Failed to load
    DISABLED = "disabled"        # Explicitly disabled
    UNLOADED = "unloaded"        # Was active, now unloaded


@dataclass
class ExtensionMetadata:
    """Metadata about an extension for discovery and display."""
    name: str
    version: str = "0.0.0"
    description: str = ""
    author: str = ""
    homepage: str = ""
    requires: List[str] = field(default_factory=list)  # Other extension names
    tags: List[str] = field(default_factory=list)
    config_schema: Dict[str, Any] = field(default_factory=dict)


class ExtensionContext:
    """Context provided to extensions during their lifecycle.
    
    This is the extension's window into the bot. Extensions should NOT
    hold direct references to bot internals — use this context instead.
    
    Attributes:
        hooks: Pipeline hooks registry for lifecycle callbacks
        config: Extension-specific configuration from config.json
        bot_config: Read-only view of bot configuration
        data_dir: Path to extension's persistent data directory
    """

    def __init__(
        self,
        bot: 'Bot',
        extension_name: str,
        extension_config: Dict[str, Any],
    ):
        self._bot = bot
        self._extension_name = extension_name
        self._config = extension_config
        self._registered_tools: List[str] = []
        self._registered_commands: Dict[str, Callable] = {}
        self._registered_hooks: List[tuple] = []  # (phase, name) for cleanup

    @property
    def hooks(self) -> 'PipelineHooks':
        """Access the pipeline hooks registry."""
        if hasattr(self._bot, 'pipeline') and self._bot.pipeline:
            hooks = getattr(self._bot.pipeline, '_hooks', None)
            if hooks:
                return hooks
        # Create hooks on the pipeline if not present
        from antaris_agent.suite.pipeline.hooks import PipelineHooks
        if hasattr(self._bot, 'pipeline') and self._bot.pipeline:
            if not hasattr(self._bot.pipeline, '_hooks'):
                self._bot.pipeline._hooks = PipelineHooks()
            return self._bot.pipeline._hooks
        raise RuntimeError("Pipeline not initialized — cannot access hooks")

    @property
    def config(self) -> Dict[str, Any]:
        """Extension-specific configuration."""
        return dict(self._config)

    @property
    def bot_name(self) -> str:
        """The bot's display name."""
        return getattr(self._bot.config, 'bot_name', 'Antaris')

    @property
    def memory(self):
        """Access the memory system."""
        return self._bot.memory

    @property
    def llm(self):
        """Access the primary LLM provider."""
        return self._bot.llm

    @property
    def dispatcher(self):
        """Access the multi-provider LLM dispatcher."""
        return getattr(self._bot, 'dispatcher', None)

    @property
    def data_dir(self) -> str:
        """Path to extension's persistent data directory."""
        from pathlib import Path
        base = Path(self._bot.config.config_path).parent / "extensions" / self._extension_name
        base.mkdir(parents=True, exist_ok=True)
        return str(base)

    @property
    def security(self):
        """Access the extension security manager."""
        return getattr(self._bot, 'extension_security', None)

    def check_capability(self, capability) -> bool:
        """Check if this extension has a specific capability.
        
        Args:
            capability: An ExtensionCapability enum value
            
        Returns:
            True if allowed, False if denied or requires approval
        """
        sec = self.security
        if sec is None:
            return True  # No security manager = allow (open mode)
        return sec.is_allowed(self._extension_name, capability)

    def register_tool(self, name: str, tool: 'NativeTool') -> None:
        """Register a native tool into the bot's tool registry.
        
        The tool will be available to the LLM for use in conversations.
        """
        if self._bot.tool_registry is None:
            from antaris_agent.tools.tool_registry import ToolRegistry
            self._bot.tool_registry = ToolRegistry()
            self._bot.tool_registry._initialized = True

        from antaris_agent.tools.models import ToolDef
        registry = self._bot.tool_registry
        registry._native_tools[name] = tool
        registry._tool_definitions[name] = ToolDef(
            name=name,
            description=tool.description,
            input_schema=tool.input_schema,
            source=f"extension:{self._extension_name}",
        )
        self._registered_tools.append(name)
        logger.info("Extension '%s' registered tool: %s", self._extension_name, name)

    def unregister_tool(self, name: str) -> None:
        """Remove a tool registered by this extension."""
        if self._bot.tool_registry:
            self._bot.tool_registry._native_tools.pop(name, None)
            self._bot.tool_registry._tool_definitions.pop(name, None)
        if name in self._registered_tools:
            self._registered_tools.remove(name)

    def register_command(self, name: str, handler: Callable) -> None:
        """Register a ! command handler.
        
        The handler receives (user_id: str, args: str) and should return a string.
        """
        self._registered_commands[name] = handler
        logger.info("Extension '%s' registered command: !%s", self._extension_name, name)

    def emit_event(self, event_type: str, data: Dict[str, Any] = None) -> None:
        """Emit an event to the extension event bus.
        
        Other extensions and the webhook system can subscribe to events.
        """
        if hasattr(self._bot, '_extension_manager'):
            self._bot._extension_manager.emit(event_type, {
                "source": self._extension_name,
                **(data or {}),
            })

    def subscribe_event(self, event_type: str, handler: Callable) -> None:
        """Subscribe to events on the extension event bus."""
        if hasattr(self._bot, '_extension_manager'):
            self._bot._extension_manager.subscribe(event_type, handler)

    def get_extension(self, name: str) -> Optional['Extension']:
        """Get another loaded extension by name (for inter-extension communication)."""
        if hasattr(self._bot, '_extension_manager'):
            return self._bot._extension_manager.get(name)
        return None

    def cleanup(self) -> None:
        """Clean up all resources registered by this extension."""
        # Remove tools
        for tool_name in list(self._registered_tools):
            self.unregister_tool(tool_name)
        self._registered_tools.clear()
        self._registered_commands.clear()


class Extension(ABC):
    """Base class for all Antaris Agent extensions.
    
    Subclass this to create a custom extension. At minimum, implement
    on_load() to register your hooks, tools, and commands.
    
    Example:
        class WeatherExtension(Extension):
            name = "weather"
            version = "1.0.0"
            description = "Provides weather information"
            
            async def on_load(self, ctx: ExtensionContext):
                ctx.register_tool("weather", WeatherTool())
                ctx.hooks.on_before_llm(self.inject_weather, name="weather.before-llm")
            
            async def inject_weather(self, hook_ctx):
                # Inject current weather into context
                ...
    """

    # ── Required class attributes (override in subclass) ──────────────────

    name: str = ""          # Unique extension identifier
    version: str = "0.0.0"  # Semver version
    description: str = ""   # Human-readable description
    author: str = ""
    requires: List[str] = []  # Names of required extensions
    capabilities: List[str] = []  # Capabilities this extension needs (ExtensionCapability values)

    # ── Lifecycle methods ─────────────────────────────────────────────────

    @abstractmethod
    async def on_load(self, ctx: ExtensionContext) -> None:
        """Called when the extension is loaded.
        
        Register hooks, tools, commands, and event subscriptions here.
        Raise an exception to abort loading (extension will be marked as ERROR).
        """
        ...

    async def on_unload(self, ctx: ExtensionContext) -> None:
        """Called when the extension is unloaded.
        
        Clean up external resources, close connections, etc.
        The context will automatically clean up registered tools and commands.
        """
        pass

    async def on_config_change(self, ctx: ExtensionContext, new_config: Dict[str, Any]) -> None:
        """Called when the extension's configuration changes at runtime."""
        pass

    def get_metadata(self) -> ExtensionMetadata:
        """Return metadata about this extension."""
        return ExtensionMetadata(
            name=self.name,
            version=self.version,
            description=self.description,
            author=self.author,
            requires=list(self.requires),
        )

    def get_status(self) -> Dict[str, Any]:
        """Return current status information (for !extensions command)."""
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
        }
