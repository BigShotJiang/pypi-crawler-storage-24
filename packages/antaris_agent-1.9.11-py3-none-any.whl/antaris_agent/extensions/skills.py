"""
Custom Skills System — user-defined tools and skills loaded from disk.

Skills are directories in the skills/ folder with a SKILL.md manifest
and optional Python tool implementations. This is the Antaris Agent
equivalent of OpenClaw's skill system.

Directory structure:
    ~/.antarisbot/skills/
        weather/
            SKILL.md          # Manifest + instructions
            tool.py           # Optional Python NativeTool
            scripts/          # Optional helper scripts
            references/       # Optional reference files
        my-custom-tool/
            SKILL.md
            tool.py

SKILL.md format:
    # Skill Name
    Description of what this skill does.
    
    ## Config
    - api_key: required (env: WEATHER_API_KEY)
    
    ## Tools
    - weather_lookup: Get current weather for a location
    
    ## Triggers
    - "what's the weather"
    - "forecast for"
"""

from __future__ import annotations

import importlib.util
import json
import logging
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from antaris_agent.tools.models import NativeTool, ToolDef, ToolResult

logger = logging.getLogger(__name__)


@dataclass
class SkillManifest:
    """Parsed metadata from a SKILL.md file."""
    name: str
    description: str = ""
    config_vars: Dict[str, str] = field(default_factory=dict)  # var → description
    tool_names: List[str] = field(default_factory=list)
    triggers: List[str] = field(default_factory=list)
    instructions: str = ""  # Full SKILL.md content for context injection
    path: str = ""


def parse_skill_md(content: str, skill_name: str = "") -> SkillManifest:
    """Parse a SKILL.md file into a SkillManifest.
    
    Extracts:
      - First H1 as name
      - Text after H1 as description
      - ## Config section for config variables
      - ## Tools section for tool names
      - ## Triggers section for trigger phrases
    """
    manifest = SkillManifest(name=skill_name)
    
    lines = content.split('\n')
    current_section = ""
    desc_lines = []
    
    for line in lines:
        stripped = line.strip()
        
        # H1 = skill name
        if stripped.startswith('# ') and not stripped.startswith('## '):
            manifest.name = stripped[2:].strip()
            current_section = "description"
            continue
        
        # H2 = section header
        if stripped.startswith('## '):
            section_name = stripped[3:].strip().lower()
            if section_name in ('config', 'configuration'):
                current_section = "config"
            elif section_name in ('tools', 'tool'):
                current_section = "tools"
            elif section_name in ('triggers', 'trigger', 'trigger phrases'):
                current_section = "triggers"
            else:
                current_section = section_name
            continue
        
        # Parse section content
        if current_section == "description" and stripped:
            desc_lines.append(stripped)
        
        elif current_section == "config" and stripped.startswith('- '):
            # Parse "- var_name: description (env: ENV_VAR)"
            config_line = stripped[2:].strip()
            if ':' in config_line:
                var_name, var_desc = config_line.split(':', 1)
                manifest.config_vars[var_name.strip()] = var_desc.strip()
        
        elif current_section == "tools" and stripped.startswith('- '):
            tool_line = stripped[2:].strip()
            if ':' in tool_line:
                tool_name = tool_line.split(':')[0].strip()
            else:
                tool_name = tool_line
            manifest.tool_names.append(tool_name)
        
        elif current_section == "triggers" and stripped.startswith('- '):
            trigger = stripped[2:].strip().strip('"').strip("'")
            manifest.triggers.append(trigger)
    
    manifest.description = ' '.join(desc_lines)
    manifest.instructions = content
    
    return manifest


class SkillLoader:
    """Discovers and loads custom skills from the skills/ directory.
    
    Usage:
        loader = SkillLoader(config_dir="/path/to/.antarisbot")
        skills = loader.discover()
        
        for skill in skills:
            # skill.manifest has metadata
            # skill.tools has NativeTool instances
            for tool in skill.tools:
                registry.register(tool.name, tool)
    """

    def __init__(self, config_dir: str):
        self.config_dir = Path(config_dir)
        self.skills_dir = self.config_dir / "skills"

    def discover(self) -> List['LoadedSkill']:
        """Discover and load all skills from the skills/ directory."""
        skills = []
        
        if not self.skills_dir.exists():
            logger.debug("Skills directory does not exist: %s", self.skills_dir)
            return skills
        
        for item in sorted(self.skills_dir.iterdir()):
            if item.name.startswith(('.', '_')):
                continue
            if not item.is_dir():
                continue
            
            skill = self._load_skill(item)
            if skill:
                skills.append(skill)
        
        logger.info("Discovered %d skill(s) from %s", len(skills), self.skills_dir)
        return skills

    def _load_skill(self, skill_dir: Path) -> Optional['LoadedSkill']:
        """Load a single skill from a directory."""
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            logger.debug("No SKILL.md in %s, skipping", skill_dir)
            return None
        
        try:
            content = skill_md.read_text(encoding='utf-8')
            manifest = parse_skill_md(content, skill_dir.name)
            manifest.path = str(skill_dir)
            
            # Load tools from tool.py if present
            tools = []
            tool_file = skill_dir / "tool.py"
            if tool_file.exists():
                tools = self._load_tools_from_file(tool_file, skill_dir.name)
            
            # Also check for multiple tool files: tools/*.py
            tools_dir = skill_dir / "tools"
            if tools_dir.exists() and tools_dir.is_dir():
                for py_file in sorted(tools_dir.glob("*.py")):
                    if py_file.name.startswith('_'):
                        continue
                    file_tools = self._load_tools_from_file(py_file, skill_dir.name)
                    tools.extend(file_tools)
            
            loaded = LoadedSkill(
                manifest=manifest,
                tools=tools,
                skill_dir=str(skill_dir),
            )
            
            logger.info(
                "Loaded skill '%s': %d tool(s), %d trigger(s)", 
                manifest.name, len(tools), len(manifest.triggers)
            )
            return loaded
            
        except Exception as e:
            logger.error("Failed to load skill from %s: %s", skill_dir, e)
            return None

    def _load_tools_from_file(self, file_path: Path, skill_name: str) -> List[NativeTool]:
        """Load NativeTool instances from a Python file."""
        tools = []
        
        try:
            module_name = f"antaris_skill_{skill_name}_{file_path.stem}"
            spec = importlib.util.spec_from_file_location(module_name, str(file_path))
            if spec is None or spec.loader is None:
                return tools
            
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
            
            # Find all NativeTool subclasses
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (
                    isinstance(attr, type) 
                    and issubclass(attr, NativeTool) 
                    and attr is not NativeTool
                    and not attr_name.startswith('_')
                ):
                    try:
                        instance = attr()
                        tools.append(instance)
                        logger.debug("Loaded tool '%s' from %s", instance.name, file_path)
                    except Exception as e:
                        logger.warning("Could not instantiate tool %s: %s", attr_name, e)
            
            # Also check for pre-instantiated tools
            if hasattr(module, 'tools') and isinstance(module.tools, list):
                for tool in module.tools:
                    if isinstance(tool, NativeTool):
                        tools.append(tool)
            
        except Exception as e:
            logger.error("Failed to load tools from %s: %s", file_path, e)
        
        return tools


@dataclass
class LoadedSkill:
    """A skill that has been loaded from disk."""
    manifest: SkillManifest
    tools: List[NativeTool] = field(default_factory=list)
    skill_dir: str = ""
    enabled: bool = True

    def matches_trigger(self, text: str) -> bool:
        """Check if user text matches any of this skill's triggers."""
        text_lower = text.lower()
        return any(trigger.lower() in text_lower for trigger in self.manifest.triggers)

    def get_context_injection(self) -> str:
        """Get the skill's instructions for context injection."""
        return self.manifest.instructions


class SkillRegistry:
    """Registry of loaded skills with trigger matching and context injection.
    
    Integrates with the pipeline to:
      1. Match incoming messages to skill triggers
      2. Inject relevant skill instructions into the system prompt
      3. Make skill tools available for LLM tool_use
    """

    def __init__(self):
        self._skills: Dict[str, LoadedSkill] = {}

    def register(self, skill: LoadedSkill) -> None:
        """Register a loaded skill."""
        self._skills[skill.manifest.name] = skill

    def unregister(self, name: str) -> None:
        """Remove a skill from the registry."""
        self._skills.pop(name, None)

    def match_skills(self, text: str) -> List[LoadedSkill]:
        """Find skills whose triggers match the given text."""
        return [
            skill for skill in self._skills.values()
            if skill.enabled and skill.matches_trigger(text)
        ]

    def get_all_tools(self) -> List[NativeTool]:
        """Get all tools from all enabled skills."""
        tools = []
        for skill in self._skills.values():
            if skill.enabled:
                tools.extend(skill.tools)
        return tools

    def get_context_for_message(self, text: str) -> str:
        """Get combined context injection for matching skills."""
        matching = self.match_skills(text)
        if not matching:
            return ""
        
        parts = ["\n## Active Skills"]
        for skill in matching:
            parts.append(f"\n### {skill.manifest.name}")
            parts.append(skill.get_context_injection())
        
        return "\n".join(parts)

    def list_skills(self) -> List[Dict[str, Any]]:
        """List all registered skills."""
        return [
            {
                "name": skill.manifest.name,
                "description": skill.manifest.description,
                "tools": len(skill.tools),
                "triggers": len(skill.manifest.triggers),
                "enabled": skill.enabled,
                "path": skill.skill_dir,
            }
            for skill in self._skills.values()
        ]

    def status_text(self) -> str:
        """Generate human-readable skill status."""
        if not self._skills:
            return "No custom skills loaded. Add skills to ~/.antarisbot/skills/"
        
        lines = ["**🎯 Custom Skills:**"]
        for name, skill in self._skills.items():
            icon = "✅" if skill.enabled else "⏸️"
            tools = len(skill.tools)
            triggers = len(skill.manifest.triggers)
            desc = skill.manifest.description[:60] if skill.manifest.description else "no description"
            lines.append(f"{icon} **{name}** — {desc} ({tools} tools, {triggers} triggers)")
        
        return "\n".join(lines)
