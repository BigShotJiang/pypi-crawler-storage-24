"""
Webhook System — outbound event notifications via HTTP.

Supports:
  - Configurable webhook endpoints per event type
  - Retry logic with exponential backoff
  - HMAC signature verification (shared secret)
  - Event filtering and payload transformation
  - Health tracking and circuit breaker
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


class WebhookEvent(Enum):
    """Standard webhook event types."""
    # Message lifecycle
    MESSAGE_RECEIVED = "message.received"
    MESSAGE_RESPONDED = "message.responded"
    MESSAGE_BLOCKED = "message.blocked"
    
    # Memory events
    MEMORY_INGESTED = "memory.ingested"
    MEMORY_RECALLED = "memory.recalled"
    MEMORY_FORGOTTEN = "memory.forgotten"
    
    # Pipeline events
    PIPELINE_ERROR = "pipeline.error"
    LLM_CALL_START = "llm.call.start"
    LLM_CALL_END = "llm.call.end"
    
    # Tool events
    TOOL_EXECUTED = "tool.executed"
    TOOL_FAILED = "tool.failed"
    TOOL_APPROVAL_REQUIRED = "tool.approval_required"
    
    # Extension events
    EXTENSION_LOADED = "extension.loaded"
    EXTENSION_UNLOADED = "extension.unloaded"
    EXTENSION_ERROR = "extension.error"
    
    # Auth events
    AUTH_KEY_EXPIRING = "auth.key_expiring"
    AUTH_KEY_ROTATED = "auth.key_rotated"
    AUTH_RATE_LIMITED = "auth.rate_limited"
    
    # System events
    BOT_STARTED = "bot.started"
    BOT_STOPPED = "bot.stopped"
    COMPACTION_WARNING = "bot.compaction_warning"
    HEALTH_CHECK = "bot.health_check"
    
    # Custom (catch-all for extension-defined events)
    CUSTOM = "custom"


@dataclass
class WebhookEndpoint:
    """Configuration for a webhook endpoint."""
    url: str
    secret: str = ""                          # HMAC shared secret
    events: List[str] = field(default_factory=list)  # Empty = all events
    enabled: bool = True
    max_retries: int = 3
    timeout_seconds: int = 10
    # Circuit breaker
    failure_count: int = 0
    last_failure: float = 0.0
    circuit_open: bool = False
    circuit_reset_seconds: int = 300          # 5 minutes


@dataclass
class WebhookPayload:
    """Standard webhook payload structure."""
    event: str
    timestamp: float
    bot_name: str
    data: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "event": self.event,
            "timestamp": self.timestamp,
            "bot_name": self.bot_name,
            "data": self.data,
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), default=str)


class WebhookManager:
    """Manages outbound webhook notifications.
    
    Usage:
        manager = WebhookManager(bot_name="Moro")
        manager.add_endpoint(WebhookEndpoint(
            url="https://example.com/webhook",
            secret="my-secret",
            events=["message.responded", "pipeline.error"],
        ))
        
        await manager.fire(WebhookEvent.MESSAGE_RESPONDED, {
            "user_id": "123",
            "response": "Hello!",
        })
    """

    def __init__(self, bot_name: str = "Antaris"):
        self.bot_name = bot_name
        self._endpoints: Dict[str, WebhookEndpoint] = {}  # url → endpoint
        self._queue: asyncio.Queue = asyncio.Queue()
        self._worker_task: Optional[asyncio.Task] = None
        self._running = False
        self._stats = {
            "total_sent": 0,
            "total_failed": 0,
            "total_retried": 0,
        }

    def add_endpoint(self, endpoint: WebhookEndpoint) -> None:
        """Register a webhook endpoint."""
        self._endpoints[endpoint.url] = endpoint
        logger.info("Webhook endpoint added: %s (events=%s)", 
                    endpoint.url, endpoint.events or "all")

    def remove_endpoint(self, url: str) -> bool:
        """Remove a webhook endpoint by URL."""
        if url in self._endpoints:
            del self._endpoints[url]
            logger.info("Webhook endpoint removed: %s", url)
            return True
        return False

    async def start(self) -> None:
        """Start the webhook delivery worker."""
        if self._running:
            return
        self._running = True
        self._worker_task = asyncio.create_task(self._delivery_worker())
        logger.info("Webhook manager started")

    async def stop(self) -> None:
        """Stop the webhook delivery worker."""
        self._running = False
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
        logger.info("Webhook manager stopped")

    async def fire(self, event: WebhookEvent | str, data: Dict[str, Any] = None) -> None:
        """Fire a webhook event to all matching endpoints.
        
        Non-blocking — events are queued for async delivery.
        """
        event_str = event.value if isinstance(event, WebhookEvent) else event
        
        payload = WebhookPayload(
            event=event_str,
            timestamp=time.time(),
            bot_name=self.bot_name,
            data=data or {},
        )
        
        for url, endpoint in self._endpoints.items():
            if not endpoint.enabled:
                continue
            if endpoint.circuit_open:
                # Check if circuit should reset
                if time.time() - endpoint.last_failure > endpoint.circuit_reset_seconds:
                    endpoint.circuit_open = False
                    endpoint.failure_count = 0
                    logger.info("Webhook circuit reset for %s", url)
                else:
                    continue
            if endpoint.events and event_str not in endpoint.events:
                continue
            
            await self._queue.put((endpoint, payload))

    def sign_payload(self, payload: str, secret: str) -> str:
        """Generate HMAC-SHA256 signature for a payload."""
        return hmac.new(
            secret.encode('utf-8'),
            payload.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()

    # ── Config Loading ────────────────────────────────────────────────────

    @classmethod
    def from_config(cls, config: Dict[str, Any], bot_name: str = "Antaris") -> 'WebhookManager':
        """Create a WebhookManager from config.json webhooks section.
        
        Config format:
            {
                "webhooks": {
                    "endpoints": [
                        {
                            "url": "https://example.com/webhook",
                            "secret": "my-secret",
                            "events": ["message.responded"],
                            "enabled": true
                        }
                    ]
                }
            }
        """
        manager = cls(bot_name=bot_name)
        
        webhooks_config = config.get("webhooks", {})
        endpoints = webhooks_config.get("endpoints", [])
        
        for ep_config in endpoints:
            url = ep_config.get("url", "")
            if not url:
                continue
            
            # Validate URL
            parsed = urlparse(url)
            if parsed.scheme not in ("http", "https"):
                logger.warning("Skipping invalid webhook URL: %s", url)
                continue
            
            endpoint = WebhookEndpoint(
                url=url,
                secret=ep_config.get("secret", ""),
                events=ep_config.get("events", []),
                enabled=ep_config.get("enabled", True),
                max_retries=ep_config.get("maxRetries", 3),
                timeout_seconds=ep_config.get("timeoutSeconds", 10),
            )
            manager.add_endpoint(endpoint)
        
        return manager

    # ── Status ────────────────────────────────────────────────────────────

    def status(self) -> Dict[str, Any]:
        """Get webhook system status."""
        endpoints = []
        for url, ep in self._endpoints.items():
            endpoints.append({
                "url": url,
                "enabled": ep.enabled,
                "events": ep.events or "all",
                "circuit_open": ep.circuit_open,
                "failure_count": ep.failure_count,
            })
        
        return {
            "running": self._running,
            "endpoints": endpoints,
            "queue_size": self._queue.qsize(),
            "stats": dict(self._stats),
        }

    # ── Internal ──────────────────────────────────────────────────────────

    async def _delivery_worker(self) -> None:
        """Background worker that processes the webhook delivery queue."""
        while self._running:
            try:
                endpoint, payload = await asyncio.wait_for(
                    self._queue.get(), timeout=5.0
                )
                await self._deliver(endpoint, payload)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Webhook worker error: %s", e)

    async def _deliver(self, endpoint: WebhookEndpoint, payload: WebhookPayload) -> bool:
        """Deliver a webhook payload with retries."""
        payload_json = payload.to_json()
        
        headers = {
            "Content-Type": "application/json",
            "User-Agent": f"AntarisAgent/{self.bot_name}",
            "X-Webhook-Event": payload.event,
            "X-Webhook-Timestamp": str(int(payload.timestamp)),
        }
        
        if endpoint.secret:
            signature = self.sign_payload(payload_json, endpoint.secret)
            headers["X-Webhook-Signature"] = f"sha256={signature}"
        
        for attempt in range(endpoint.max_retries):
            try:
                # Use aiohttp if available, otherwise fall back to urllib
                try:
                    import aiohttp
                    async with aiohttp.ClientSession() as session:
                        async with session.post(
                            endpoint.url,
                            data=payload_json,
                            headers=headers,
                            timeout=aiohttp.ClientTimeout(total=endpoint.timeout_seconds),
                        ) as response:
                            if 200 <= response.status < 300:
                                self._stats["total_sent"] += 1
                                endpoint.failure_count = 0
                                return True
                            elif response.status >= 500:
                                raise Exception(f"Server error: {response.status}")
                            else:
                                logger.warning(
                                    "Webhook %s returned %d for event %s",
                                    endpoint.url, response.status, payload.event
                                )
                                self._stats["total_failed"] += 1
                                return False
                                
                except ImportError:
                    # Fallback to urllib (blocking but functional)
                    import urllib.request
                    req = urllib.request.Request(
                        endpoint.url,
                        data=payload_json.encode('utf-8'),
                        headers=headers,
                        method='POST'
                    )
                    loop = asyncio.get_running_loop()
                    await loop.run_in_executor(
                        None,
                        lambda: urllib.request.urlopen(req, timeout=endpoint.timeout_seconds)
                    )
                    self._stats["total_sent"] += 1
                    endpoint.failure_count = 0
                    return True
                    
            except Exception as e:
                self._stats["total_retried"] += 1
                endpoint.failure_count += 1
                endpoint.last_failure = time.time()
                
                if endpoint.failure_count >= endpoint.max_retries * 2:
                    endpoint.circuit_open = True
                    logger.error(
                        "Webhook circuit opened for %s after %d failures",
                        endpoint.url, endpoint.failure_count
                    )
                
                if attempt < endpoint.max_retries - 1:
                    wait = 2 ** attempt  # 1s, 2s, 4s
                    logger.warning(
                        "Webhook delivery failed (attempt %d/%d, retry in %ds): %s — %s",
                        attempt + 1, endpoint.max_retries, wait, endpoint.url, e
                    )
                    await asyncio.sleep(wait)
                else:
                    logger.error(
                        "Webhook delivery failed after %d attempts: %s — %s",
                        endpoint.max_retries, endpoint.url, e
                    )
                    self._stats["total_failed"] += 1
        
        return False
