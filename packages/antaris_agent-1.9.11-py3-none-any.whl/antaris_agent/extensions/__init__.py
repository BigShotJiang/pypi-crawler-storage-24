"""
Antaris Agent Extension System

Provides a plugin architecture for extending the agent with custom functionality.
Extensions can register hooks, tools, commands, and webhooks.

Usage:
    from antaris_agent.extensions import ExtensionManager, Extension

    class MyExtension(Extension):
        name = "my-extension"
        version = "1.0.0"

        async def on_load(self, ctx):
            ctx.hooks.on_before_llm(self.my_hook, name="my-ext.before-llm")
            ctx.register_tool("my_tool", MyTool())

    manager = ExtensionManager()
    manager.register(MyExtension())
    await manager.load_all(bot)
"""

from .base import Extension, ExtensionContext, ExtensionState
from .manager import ExtensionManager
from .loader import ExtensionLoader
from .security import (
    ExtensionCapability,
    ExtensionSource,
    ExtensionSecurityManager,
    ExtensionAllowlist,
    HIGH_RISK_CAPABILITIES,
    BUILTIN_EXTENSION_NAMES,
)

__all__ = [
    "Extension",
    "ExtensionContext",
    "ExtensionState",
    "ExtensionManager",
    "ExtensionLoader",
    "ExtensionCapability",
    "ExtensionSource",
    "ExtensionSecurityManager",
    "ExtensionAllowlist",
    "HIGH_RISK_CAPABILITIES",
    "BUILTIN_EXTENSION_NAMES",
]
