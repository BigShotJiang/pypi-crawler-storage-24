"""
Desktop Control Extension — browser automation, desktop control, terminal management.

Provides architecture and first implementation hooks for:
  - Browser automation (via Puppeteer/Playwright)
  - Desktop control (mouse/keyboard via nut-tree or AppleScript)
  - Screenshot capture and analysis
  - Terminal session management
  - Peekaboo integration (macOS UI automation)

This is the parity layer for OpenClaw's browser, peekaboo, and exec tools.
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from antaris_agent.tools.models import NativeTool, ToolResult
from .base import Extension, ExtensionContext

logger = logging.getLogger(__name__)


# ── Terminal Session Manager ──────────────────────────────────────────────

@dataclass
class TerminalSession:
    """A managed terminal/shell session."""
    id: str
    pid: int = 0
    command: str = ""
    workdir: str = ""
    started_at: float = 0.0
    background: bool = False
    pty: bool = False
    status: str = "running"    # running | completed | killed | error
    exit_code: Optional[int] = None
    output_buffer: str = ""
    max_output: int = 102400   # 100KB


class TerminalManager:
    """Manages multiple terminal sessions with background execution.
    
    Provides OpenClaw-like exec/process functionality:
      - Start background processes
      - Poll for output
      - Send input to running processes
      - Kill processes
    """

    def __init__(self, workspace_path: str):
        self.workspace_path = Path(workspace_path)
        self._sessions: Dict[str, TerminalSession] = {}
        self._processes: Dict[str, asyncio.subprocess.Process] = {}
        self._counter = 0

    async def exec(
        self,
        command: str,
        workdir: str = "",
        timeout: int = 30,
        background: bool = False,
        env: Optional[Dict[str, str]] = None,
    ) -> tuple[str, TerminalSession]:
        """Execute a command, optionally in background.
        
        Returns (session_id, session).
        """
        import time
        
        self._counter += 1
        session_id = f"term_{self._counter}"
        
        cwd = Path(workdir) if workdir else self.workspace_path
        if not cwd.exists():
            cwd = self.workspace_path
        
        session = TerminalSession(
            id=session_id,
            command=command,
            workdir=str(cwd),
            started_at=time.time(),
            background=background,
        )
        
        # Merge environment
        proc_env = dict(os.environ)
        if env:
            proc_env.update(env)
        
        try:
            process = await asyncio.create_subprocess_shell(
                command,
                cwd=cwd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                stdin=asyncio.subprocess.PIPE if background else None,
                env=proc_env,
                limit=1024 * 1024,
            )
            session.pid = process.pid
            self._sessions[session_id] = session
            self._processes[session_id] = process
            
            if background:
                # Don't wait — let it run
                asyncio.create_task(self._monitor_background(session_id, process))
                return (session_id, session)
            else:
                # Wait with timeout
                try:
                    stdout, _ = await asyncio.wait_for(
                        process.communicate(), timeout=timeout
                    )
                    session.output_buffer = stdout.decode('utf-8', errors='replace') if stdout else ""
                    session.exit_code = process.returncode
                    session.status = "completed"
                except asyncio.TimeoutError:
                    process.kill()
                    await process.wait()
                    session.status = "killed"
                    session.output_buffer = "(timed out)"
                
                return (session_id, session)
                
        except Exception as e:
            session.status = "error"
            session.output_buffer = str(e)
            self._sessions[session_id] = session
            return (session_id, session)

    async def poll(self, session_id: str, timeout_ms: int = 0) -> Optional[TerminalSession]:
        """Poll a background session for updates."""
        session = self._sessions.get(session_id)
        if not session:
            return None
        
        process = self._processes.get(session_id)
        if process and session.status == "running":
            # Try to read available output
            try:
                if timeout_ms > 0:
                    await asyncio.sleep(timeout_ms / 1000)
                
                if process.returncode is not None:
                    session.status = "completed"
                    session.exit_code = process.returncode
            except Exception:
                pass
        
        return session

    async def write_stdin(self, session_id: str, data: str) -> bool:
        """Write data to a background session's stdin."""
        process = self._processes.get(session_id)
        if not process or not process.stdin:
            return False
        try:
            process.stdin.write(data.encode('utf-8'))
            await process.stdin.drain()
            return True
        except Exception:
            return False

    async def kill(self, session_id: str) -> bool:
        """Kill a running session."""
        process = self._processes.get(session_id)
        session = self._sessions.get(session_id)
        if not process or not session:
            return False
        try:
            process.kill()
            await process.wait()
            session.status = "killed"
            return True
        except Exception:
            return False

    def list_sessions(self) -> List[Dict[str, Any]]:
        """List all sessions."""
        return [
            {
                "id": s.id,
                "command": s.command[:60],
                "status": s.status,
                "pid": s.pid,
                "background": s.background,
            }
            for s in self._sessions.values()
        ]

    def get_output(self, session_id: str, offset: int = 0, limit: int = 0) -> str:
        """Get output from a session."""
        session = self._sessions.get(session_id)
        if not session:
            return ""
        output = session.output_buffer
        if offset > 0:
            output = output[offset:]
        if limit > 0:
            output = output[:limit]
        return output

    async def _monitor_background(self, session_id: str, process: asyncio.subprocess.Process) -> None:
        """Monitor a background process, capturing output."""
        session = self._sessions.get(session_id)
        if not session:
            return
        
        try:
            while True:
                chunk = await process.stdout.read(4096)
                if not chunk:
                    break
                decoded = chunk.decode('utf-8', errors='replace')
                session.output_buffer += decoded
                # Truncate if too long
                if len(session.output_buffer) > session.max_output:
                    session.output_buffer = session.output_buffer[-session.max_output:]
            
            session.exit_code = process.returncode
            session.status = "completed"
        except Exception as e:
            session.status = "error"
            session.output_buffer += f"\n[Monitor error: {e}]"


# ── Screenshot Tool ───────────────────────────────────────────────────────

class ScreenshotTool(NativeTool):
    """Capture screenshots on macOS/Linux."""
    
    def __init__(self, workspace_path: str):
        self.workspace_path = Path(workspace_path)
    
    @property
    def name(self) -> str:
        return "screenshot"
    
    @property
    def description(self) -> str:
        return "Capture a screenshot of the current screen or a specific window"
    
    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "window": {
                    "type": "string",
                    "description": "Window name/title to capture (optional, captures full screen if omitted)"
                },
                "filename": {
                    "type": "string",
                    "description": "Output filename (optional, auto-generated if omitted)"
                },
                "region": {
                    "type": "object",
                    "description": "Capture region {x, y, width, height} (optional)",
                    "properties": {
                        "x": {"type": "integer"},
                        "y": {"type": "integer"},
                        "width": {"type": "integer"},
                        "height": {"type": "integer"},
                    }
                }
            },
        }
    
    async def execute(self, arguments: dict) -> ToolResult:
        import time
        
        filename = arguments.get("filename") or f"screenshot_{int(time.time())}.png"
        output_path = self.workspace_path / filename
        
        system = platform.system()
        
        try:
            if system == "Darwin":
                # macOS: use screencapture
                cmd = f"/usr/sbin/screencapture -x {output_path}"
                region = arguments.get("region")
                if region:
                    x = region.get("x", 0)
                    y = region.get("y", 0)
                    w = region.get("width", 800)
                    h = region.get("height", 600)
                    cmd = f"/usr/sbin/screencapture -x -R{x},{y},{w},{h} {output_path}"
                
                process = await asyncio.create_subprocess_shell(
                    cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
                )
                await process.communicate()
                
                if output_path.exists():
                    size = output_path.stat().st_size
                    return ToolResult(
                        success=True,
                        content=f"Screenshot saved: {output_path} ({size:,} bytes)"
                    )
                return ToolResult(success=False, content="Screenshot failed", is_error=True)
            
            elif system == "Linux":
                # Linux: try scrot, then import (ImageMagick)
                for tool in ["scrot", "import"]:
                    if shutil.which(tool):
                        if tool == "scrot":
                            cmd = f"scrot {output_path}"
                        else:
                            cmd = f"import -window root {output_path}"
                        
                        process = await asyncio.create_subprocess_shell(
                            cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
                        )
                        await process.communicate()
                        
                        if output_path.exists():
                            size = output_path.stat().st_size
                            return ToolResult(
                                success=True,
                                content=f"Screenshot saved: {output_path} ({size:,} bytes)"
                            )
                
                return ToolResult(
                    success=False,
                    content="No screenshot tool available. Install scrot or ImageMagick.",
                    is_error=True
                )
            
            else:
                return ToolResult(
                    success=False,
                    content=f"Screenshots not supported on {system}",
                    is_error=True
                )
                
        except Exception as e:
            return ToolResult(success=False, content=f"Screenshot error: {e}", is_error=True)


# ── Desktop Control Tool ─────────────────────────────────────────────────

class DesktopControlTool(NativeTool):
    """Control mouse and keyboard on macOS (via AppleScript/cliclick)."""
    
    @property
    def name(self) -> str:
        return "desktop_control"
    
    @property
    def description(self) -> str:
        return (
            "Control the desktop: move/click mouse, type text, press keys, "
            "list windows, activate apps. macOS only."
        )
    
    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "click", "double_click", "right_click",
                        "move", "type", "key", "hotkey",
                        "list_windows", "activate_app", "get_frontmost"
                    ],
                    "description": "Action to perform"
                },
                "x": {"type": "integer", "description": "X coordinate for mouse actions"},
                "y": {"type": "integer", "description": "Y coordinate for mouse actions"},
                "text": {"type": "string", "description": "Text to type or key to press"},
                "app": {"type": "string", "description": "Application name for activate_app"},
                "modifiers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Key modifiers: command, option, control, shift"
                },
            },
            "required": ["action"]
        }
    
    async def execute(self, arguments: dict) -> ToolResult:
        if platform.system() != "Darwin":
            return ToolResult(
                success=False,
                content="Desktop control is only available on macOS",
                is_error=True
            )
        
        action = arguments.get("action", "")
        
        try:
            if action == "list_windows":
                return await self._list_windows()
            elif action == "get_frontmost":
                return await self._get_frontmost()
            elif action == "activate_app":
                app = arguments.get("app", "")
                return await self._activate_app(app)
            elif action == "type":
                text = arguments.get("text", "")
                return await self._type_text(text)
            elif action == "key":
                text = arguments.get("text", "")
                modifiers = arguments.get("modifiers", [])
                return await self._press_key(text, modifiers)
            elif action == "hotkey":
                text = arguments.get("text", "")
                modifiers = arguments.get("modifiers", [])
                return await self._press_key(text, modifiers)
            elif action in ("click", "double_click", "right_click", "move"):
                x = arguments.get("x", 0)
                y = arguments.get("y", 0)
                return await self._mouse_action(action, x, y)
            else:
                return ToolResult(success=False, content=f"Unknown action: {action}", is_error=True)
        except Exception as e:
            return ToolResult(success=False, content=f"Desktop control error: {e}", is_error=True)
    
    async def _run_applescript(self, script: str) -> str:
        """Run an AppleScript and return output."""
        process = await asyncio.create_subprocess_exec(
            "osascript", "-e", script,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            raise RuntimeError(stderr.decode('utf-8', errors='replace'))
        return stdout.decode('utf-8', errors='replace').strip()
    
    async def _list_windows(self) -> ToolResult:
        script = '''
        tell application "System Events"
            set windowList to ""
            repeat with proc in (every process whose background only is false)
                set procName to name of proc
                try
                    repeat with win in (every window of proc)
                        set windowList to windowList & procName & ": " & name of win & linefeed
                    end repeat
                end try
            end repeat
            return windowList
        end tell
        '''
        output = await self._run_applescript(script)
        return ToolResult(success=True, content=output or "No windows found")
    
    async def _get_frontmost(self) -> ToolResult:
        script = '''
        tell application "System Events"
            set frontApp to name of first application process whose frontmost is true
            set frontWindow to ""
            try
                tell process frontApp
                    set frontWindow to name of front window
                end tell
            end try
            return frontApp & ": " & frontWindow
        end tell
        '''
        output = await self._run_applescript(script)
        return ToolResult(success=True, content=output)
    
    async def _activate_app(self, app_name: str) -> ToolResult:
        if not app_name:
            return ToolResult(success=False, content="App name required", is_error=True)
        script = f'tell application "{app_name}" to activate'
        await self._run_applescript(script)
        return ToolResult(success=True, content=f"Activated: {app_name}")
    
    async def _type_text(self, text: str) -> ToolResult:
        if not text:
            return ToolResult(success=False, content="Text required", is_error=True)
        # Escape for AppleScript
        escaped = text.replace('\\', '\\\\').replace('"', '\\"')
        script = f'''
        tell application "System Events"
            keystroke "{escaped}"
        end tell
        '''
        await self._run_applescript(script)
        return ToolResult(success=True, content=f"Typed: {text[:50]}")
    
    async def _press_key(self, key: str, modifiers: List[str] = None) -> ToolResult:
        if not key:
            return ToolResult(success=False, content="Key required", is_error=True)
        
        # Map key names to key codes
        key_codes = {
            "return": 36, "enter": 36, "tab": 48, "space": 49,
            "delete": 51, "escape": 53, "esc": 53,
            "left": 123, "right": 124, "down": 125, "up": 126,
            "f1": 122, "f2": 120, "f3": 99, "f4": 118,
        }
        
        mod_map = {
            "command": "command down",
            "cmd": "command down",
            "option": "option down",
            "alt": "option down",
            "control": "control down",
            "ctrl": "control down",
            "shift": "shift down",
        }
        
        mod_str = ""
        if modifiers:
            mod_parts = [mod_map.get(m.lower(), "") for m in modifiers if m.lower() in mod_map]
            if mod_parts:
                mod_str = " using {" + ", ".join(mod_parts) + "}"
        
        if key.lower() in key_codes:
            script = f'''
            tell application "System Events"
                key code {key_codes[key.lower()]}{mod_str}
            end tell
            '''
        else:
            script = f'''
            tell application "System Events"
                keystroke "{key}"{mod_str}
            end tell
            '''
        
        await self._run_applescript(script)
        return ToolResult(success=True, content=f"Pressed: {key}" + (f" with {modifiers}" if modifiers else ""))
    
    async def _mouse_action(self, action: str, x: int, y: int) -> ToolResult:
        # Use cliclick if available, otherwise AppleScript
        if shutil.which("cliclick"):
            cmd_map = {
                "click": f"cliclick c:{x},{y}",
                "double_click": f"cliclick dc:{x},{y}",
                "right_click": f"cliclick rc:{x},{y}",
                "move": f"cliclick m:{x},{y}",
            }
            cmd = cmd_map.get(action, f"cliclick c:{x},{y}")
            process = await asyncio.create_subprocess_shell(
                cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            await process.communicate()
            return ToolResult(success=True, content=f"{action} at ({x}, {y})")
        
        # Fallback to AppleScript (less reliable for clicks)
        script = f'''
        tell application "System Events"
            click at {{{x}, {y}}}
        end tell
        '''
        try:
            await self._run_applescript(script)
            return ToolResult(success=True, content=f"{action} at ({x}, {y})")
        except Exception as e:
            return ToolResult(
                success=False,
                content=f"Mouse action failed. Install cliclick for reliable mouse control: brew install cliclick\nError: {e}",
                is_error=True
            )


# ── Desktop Control Extension ────────────────────────────────────────────

class DesktopControlExtension(Extension):
    """Extension that provides browser, desktop, and terminal control.
    
    Registers:
      - screenshot tool
      - desktop_control tool (macOS)
      - terminal_exec tool (background processes)
      - !sessions command (list terminal sessions)
    """

    name = "desktop-control"
    version = "1.0.0"
    description = "Browser automation, desktop control, and terminal management"
    capabilities = ["shell.exec", "desktop", "browser"]

    def __init__(self):
        self._terminal: Optional[TerminalManager] = None

    async def on_load(self, ctx: ExtensionContext) -> None:
        workspace = ctx.data_dir
        
        # Terminal manager
        self._terminal = TerminalManager(workspace)
        
        # Register tools based on security policy
        ctx.register_tool("screenshot", ScreenshotTool(workspace_path=workspace))
        
        if platform.system() == "Darwin":
            # Only register desktop control if the security policy allows it
            if ctx.check_capability(_ExtCap.DESKTOP) if (_ExtCap := self._get_cap_enum()) else True:
                ctx.register_tool("desktop_control", DesktopControlTool())
            else:
                logger.info("Desktop control tool skipped — not allowed by security policy")
        
        # Register browser tool via extension if not already registered natively
        if ctx.check_capability(_ExtCap.BROWSER) if (_ExtCap := self._get_cap_enum()) else True:
            # Browser tool is registered as a native tool in bot._init_tools(),
            # but we log that the extension layer is aware of it
            logger.info("Browser automation capability: active (registered via native tools)")
        
        # Register commands
        ctx.register_command("sessions", self._cmd_sessions)

    @staticmethod
    def _get_cap_enum():
        """Get ExtensionCapability enum (lazy import to avoid circular deps)."""
        try:
            from antaris_agent.extensions.security import ExtensionCapability
            return ExtensionCapability
        except ImportError:
            return None
    
    def _cmd_sessions(self, user_id: str, args: str) -> str:
        """Handle !sessions command."""
        if not self._terminal:
            return "Terminal manager not initialized."
        
        sessions = self._terminal.list_sessions()
        if not sessions:
            return "No terminal sessions."
        
        lines = ["**Terminal Sessions:**"]
        for s in sessions:
            icon = "🟢" if s["status"] == "running" else "⚪"
            bg = " (bg)" if s["background"] else ""
            lines.append(f"{icon} `{s['id']}` — {s['command']}{bg} [{s['status']}]")
        
        return "\n".join(lines)

    async def on_unload(self, ctx: ExtensionContext) -> None:
        # Kill all background sessions
        if self._terminal:
            for session_id in list(self._terminal._sessions.keys()):
                session = self._terminal._sessions[session_id]
                if session.status == "running":
                    await self._terminal.kill(session_id)
