"""
Example Extension — demonstrates how to build an Antaris Agent extension.

This is a reference implementation showing all extension capabilities:
  - Registering pipeline hooks
  - Registering custom tools
  - Registering ! commands
  - Emitting and subscribing to events
  - Accessing bot components via ExtensionContext
  - Persistent data storage
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict

from antaris_agent.extensions.base import Extension, ExtensionContext
from antaris_agent.suite.pipeline.hooks import HookContext, HookResult, HookPhase
from antaris_agent.tools.models import NativeTool, ToolResult

logger = logging.getLogger(__name__)


# ── Custom Tool ───────────────────────────────────────────────────────────

class GreetingTool(NativeTool):
    """A simple example tool that generates personalized greetings."""
    
    @property
    def name(self) -> str:
        return "greeting"
    
    @property
    def description(self) -> str:
        return "Generate a personalized greeting for someone"
    
    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Name of the person to greet"
                },
                "style": {
                    "type": "string",
                    "enum": ["formal", "casual", "pirate"],
                    "description": "Greeting style",
                    "default": "casual"
                }
            },
            "required": ["name"]
        }
    
    async def execute(self, arguments: dict) -> ToolResult:
        name = arguments.get("name", "World")
        style = arguments.get("style", "casual")
        
        greetings = {
            "formal": f"Good day, {name}. It is a pleasure to make your acquaintance.",
            "casual": f"Hey {name}! What's up?",
            "pirate": f"Ahoy, {name}! Avast ye landlubber!",
        }
        
        greeting = greetings.get(style, greetings["casual"])
        return ToolResult(success=True, content=greeting)


# ── Example Extension ────────────────────────────────────────────────────

class ExampleExtension(Extension):
    """A complete example extension demonstrating all capabilities.
    
    Features:
      - Custom greeting tool
      - Message counter hook (tracks messages per user)
      - !greet command
      - Event emission on milestones
    """

    name = "example"
    version = "1.0.0"
    description = "Example extension demonstrating all extension capabilities"
    author = "Antaris"

    def __init__(self):
        self._message_counts: Dict[str, int] = {}
        self._data_dir: str = ""

    async def on_load(self, ctx: ExtensionContext) -> None:
        """Register all hooks, tools, and commands."""
        self._data_dir = ctx.data_dir
        
        # Load persisted state
        self._load_counts()
        
        # Register a custom tool
        ctx.register_tool("greeting", GreetingTool())
        
        # Register a hook that runs before every LLM call
        ctx.hooks.on_before_llm(self._count_messages, name="example.counter")
        
        # Register a ! command
        ctx.register_command("greet", self._cmd_greet)
        ctx.register_command("msgcount", self._cmd_msgcount)
        
        # Subscribe to events
        ctx.subscribe_event("message.responded", self._on_message_responded)
        
        logger.info("Example extension loaded!")

    async def on_unload(self, ctx: ExtensionContext) -> None:
        """Save state on unload."""
        self._save_counts()
        logger.info("Example extension unloaded")

    # ── Hook callbacks ────────────────────────────────────────────────────

    def _count_messages(self, hook_ctx: HookContext) -> HookResult:
        """Count messages per user (runs before every LLM call)."""
        agent_id = hook_ctx.agent_id or "unknown"
        self._message_counts[agent_id] = self._message_counts.get(agent_id, 0) + 1
        
        count = self._message_counts[agent_id]
        
        # Emit milestone events
        if count % 100 == 0:
            hook_ctx.metadata["milestone"] = count
        
        return HookResult(
            success=True,
            data={"message_count": count}
        )

    # ── Event handlers ────────────────────────────────────────────────────

    def _on_message_responded(self, event_type: str, data: Dict[str, Any]) -> None:
        """Handle message.responded events."""
        # Save counts periodically
        total = sum(self._message_counts.values())
        if total % 10 == 0:
            self._save_counts()

    # ── Commands ──────────────────────────────────────────────────────────

    def _cmd_greet(self, user_id: str, args: str) -> str:
        """Handle !greet command."""
        name = args.strip() or "World"
        return f"👋 Hello, {name}! (from the Example Extension)"

    def _cmd_msgcount(self, user_id: str, args: str) -> str:
        """Handle !msgcount command."""
        count = self._message_counts.get(user_id, 0)
        total = sum(self._message_counts.values())
        return f"📊 Your messages: {count}\nTotal across all users: {total}"

    # ── Persistence ───────────────────────────────────────────────────────

    def _save_counts(self) -> None:
        """Save message counts to disk."""
        if not self._data_dir:
            return
        try:
            path = Path(self._data_dir) / "message_counts.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(self._message_counts, f)
        except Exception as e:
            logger.debug("Could not save counts: %s", e)

    def _load_counts(self) -> None:
        """Load message counts from disk."""
        if not self._data_dir:
            return
        try:
            path = Path(self._data_dir) / "message_counts.json"
            if path.exists():
                with open(path) as f:
                    self._message_counts = json.load(f)
        except Exception as e:
            logger.debug("Could not load counts: %s", e)


# Module-level extension instance for auto-discovery
extension = ExampleExtension()
