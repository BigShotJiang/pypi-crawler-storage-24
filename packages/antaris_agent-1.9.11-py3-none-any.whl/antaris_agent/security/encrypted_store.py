"""Antaris Agent encrypted store — AES-256-GCM memory encryption via cryptography + keyring."""
from __future__ import annotations

import base64
import getpass
import json
import os
from pathlib import Path


def load_or_create_key(
    service: str = "antaris-agent",
    account: str = "memory-key",
) -> bytes:
    """Return a 32-byte AES key, loading from keyring / env / passphrase derivation.

    Resolution order:
    1. ``keyring.get_password(service, account)`` — base64url-encoded stored key
    2. ``ANTARISBOT_MEMORY_KEY`` env var — base64url-encoded key
    3. Interactive passphrase → Scrypt derivation → stored in keyring

    Returns:
        32 bytes (256-bit key).
    """
    import keyring  # lazy import — not stdlib

    # 1. Keyring
    try:
        stored = keyring.get_password(service, account)
        if stored:
            key = base64.urlsafe_b64decode(stored.encode())
            if len(key) == 32:
                return key
    except Exception:
        pass

    # 2. Environment variable
    env_val = os.environ.get("ANTARISBOT_MEMORY_KEY")
    if env_val:
        try:
            key = base64.urlsafe_b64decode(env_val.encode())
            if len(key) == 32:
                return key
        except Exception:
            pass

    # 3. Passphrase derivation (Scrypt)
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    from cryptography.hazmat.backends import default_backend

    passphrase = getpass.getpass("Antaris Agent memory passphrase: ").encode("utf-8")
    salt = os.urandom(16)

    kdf = Scrypt(
        salt=salt,
        length=32,
        n=2**14,
        r=8,
        p=1,
        backend=default_backend(),
    )
    key = kdf.derive(passphrase)

    # Encode key WITH the salt prepended so we can reconstruct later if needed.
    # Store as base64url: first 16 bytes = salt, next 32 bytes = derived key.
    blob = base64.urlsafe_b64encode(salt + key).decode()
    try:
        keyring.set_password(service, account, blob)
    except Exception:
        pass  # Non-fatal if keyring write fails

    return key


def encrypt_json(data: dict, key: bytes) -> bytes:
    """Encrypt *data* as JSON using AES-256-GCM.

    Returns:
        ``nonce (12 bytes) + ciphertext+tag`` as a single byte string.
    """
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    nonce = os.urandom(12)
    plaintext = json.dumps(data).encode("utf-8")
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, None)
    return nonce + ciphertext


def decrypt_json(blob: bytes, key: bytes) -> dict:
    """Decrypt a blob produced by :func:`encrypt_json`.

    Returns:
        The original dict.
    """
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    nonce, ciphertext = blob[:12], blob[12:]
    plaintext = AESGCM(key).decrypt(nonce, ciphertext, None)
    return json.loads(plaintext.decode("utf-8"))


def save_store(path: Path, data: dict, key: bytes) -> None:
    """Encrypt *data* and write to *path* (mode 0o600).

    Args:
        path: Destination file path (created or overwritten).
        data: JSON-serialisable dict to store.
        key: 32-byte AES key.
    """
    encrypted = encrypt_json(data, key)
    path.write_bytes(encrypted)
    path.chmod(0o600)


def load_store(path: Path, key: bytes) -> dict:
    """Load and decrypt the store at *path*.

    Returns:
        Decrypted dict, or ``{}`` if the file does not exist.
    """
    if not path.exists():
        return {}
    return decrypt_json(path.read_bytes(), key)
