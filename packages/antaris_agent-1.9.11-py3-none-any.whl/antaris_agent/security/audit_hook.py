"""Antaris Agent audit hook — filesystem, subprocess, network enforcement via sys.addaudithook()."""
from __future__ import annotations

import os
import site
import sys
from pathlib import Path
from typing import Union

from .levels import LEVEL_OPEN, LEVEL_STANDARD, LEVEL_SANDBOXED, LEVEL_SECURED, LEVEL_ENCRYPTED

# ---------------------------------------------------------------------------
# Module-level state (mutated once by install())
# ---------------------------------------------------------------------------
_LEVEL: int = LEVEL_STANDARD
_WORKSPACE: str = ""


def _is_inside_workspace(resolved_path: str) -> bool:
    """Check if a resolved path is genuinely inside the workspace (not just prefix match)."""
    if not _WORKSPACE:
        return False
    try:
        Path(resolved_path).relative_to(_WORKSPACE)
        return True
    except ValueError:
        return False
_ALLOWED_PATHS: set[str] = set()
_INSTALLED: bool = False  # Guard against double audit hook installation

# ---------------------------------------------------------------------------
# Read-only system paths that stdlib modules legitimately access.
# These are inherently safe — they are OS-provided, read-only resources
# that Python's own standard library (mimetypes, ssl, locale, timezone,
# etc.) needs to function correctly.
# ---------------------------------------------------------------------------
# Entries ending in "/" are directory prefixes (match anything beneath).
# Entries without "/" are exact file matches OR prefix matches with "/".
_SYSTEM_READ_PREFIXES: tuple[str, ...] = (
    # MIME databases (Python mimetypes module)
    "/etc/mime.types",
    "/etc/httpd",          # /etc/httpd/mime.types, /etc/httpd/conf/mime.types
    "/etc/apache",         # /etc/apache/mime.types
    "/etc/apache2",        # /etc/apache2/mime.types
    # SSL / TLS certificates & config
    "/etc/ssl",            # /etc/ssl/certs/*, /etc/ssl/openssl.cnf
    "/etc/pki",            # /etc/pki/tls/certs/ca-bundle.crt
    # System config reads (stdlib: socket, pwd, grp, etc.)
    "/etc/localtime",
    "/etc/resolv.conf",
    "/etc/hosts",
    "/etc/passwd",         # getpwnam / getpwuid (stdlib pwd module)
    "/etc/group",          # grp module
    "/etc/nsswitch.conf",
    # /usr/share resources (timezone, locale, MIME)
    "/usr/share/zoneinfo",
    "/usr/share/locale",
    "/usr/share/mime",
    # Homebrew / /usr/local resources
    "/usr/local/etc/mime.types",
    "/usr/local/etc/httpd",
    "/usr/local/etc/openssl",
    "/usr/local/share/mime",
    # macOS: /etc → /private/etc (symlink target)
    "/private/etc",
    # Device files
    "/dev/null",
    "/dev/urandom",
    "/dev/random",
    "/dev/zero",
)

# Hosts always permitted in secured/encrypted modes
ALLOWED_HOSTS: set[str] = {
    "api.anthropic.com",
    "api.openai.com",
    "generativelanguage.googleapis.com",
    "localhost",
    "127.0.0.1",
}


def _build_allowed_paths() -> set[str]:
    """Collect Python stdlib and site-packages roots that are always safe."""
    candidates: list[str] = [
        sys.prefix,
        sys.base_prefix,
        sys.exec_prefix,
        getattr(sys, "base_exec_prefix", sys.exec_prefix),
    ]
    # site-packages directories
    try:
        candidates.extend(site.getsitepackages())
    except AttributeError:
        pass
    try:
        candidates.append(site.getusersitepackages())
    except AttributeError:
        pass
    # Standard lib location (CPython)
    try:
        import sysconfig
        stdlib = sysconfig.get_path("stdlib")
        platstdlib = sysconfig.get_path("platstdlib")
        if stdlib:
            candidates.append(stdlib)
        if platstdlib:
            candidates.append(platstdlib)
    except Exception:
        pass

    allowed: set[str] = set()
    for p in candidates:
        if p:
            try:
                allowed.add(str(Path(p).resolve()))
            except Exception:
                pass
    return allowed


def install(level_or_mode: Union[int, str], workspace_path: str) -> None:
    """Register the Antaris Agent audit hook for the given security level.

    This calls ``sys.addaudithook`` which is **irremovable** for the lifetime
    of the interpreter — call it exactly once, at bot startup.

    Args:
        level_or_mode: Security level (0-4) or legacy mode string for backward compat.
        workspace_path: Absolute path to the bot's workspace root.
    """
    global _LEVEL, _WORKSPACE, _ALLOWED_PATHS, _INSTALLED

    # Accept both int level and string mode for backward compat
    if isinstance(level_or_mode, str):
        mode_map = {
            "open": LEVEL_OPEN,
            "standard": LEVEL_STANDARD,
            "sandboxed": LEVEL_SANDBOXED,
            "secured": LEVEL_SECURED,
            "encrypted": LEVEL_ENCRYPTED,
            "locked": LEVEL_ENCRYPTED,  # legacy alias
        }
        level = mode_map.get(level_or_mode, LEVEL_STANDARD)
    else:
        level = level_or_mode

    _LEVEL = level
    _WORKSPACE = str(Path(workspace_path).resolve())
    _ALLOWED_PATHS = _build_allowed_paths()

    # Always allow the bot's own package directory (needed to import its own modules)
    _bot_pkg_dir = str(Path(__file__).resolve().parent.parent)
    _ALLOWED_PATHS.add(_bot_pkg_dir)

    # Allow bundled suite module directories
    for _mod_name in ("parsica_memory", "antaris_agent.suite.guard", "antaris_agent.suite.context", "antaris_agent.suite.router", "antaris_agent.suite.pipeline"):
        try:
            _mod = __import__(_mod_name, fromlist=[_mod_name.split(".")[-1]])
            _mod_dir = str(Path(_mod.__file__).resolve().parent)
            _ALLOWED_PATHS.add(_mod_dir)
        except Exception:
            pass

    # Allow bundled parsica_memory package (top-level, not under antaris_agent)
    # Needed for package-data reads (word_expansion.json, etc.)
    try:
        import parsica_memory as _pm
        _pm_dir = str(Path(_pm.__file__).resolve().parent)
        _ALLOWED_PATHS.add(_pm_dir)
    except Exception:
        pass

    # Also allow the workspace path itself
    _ALLOWED_PATHS.add(_WORKSPACE)

    # Level 0 (OPEN) skips audit hook entirely
    # Guard: sys.addaudithook is irremovable — only install once per process
    if level > LEVEL_OPEN and not _INSTALLED:
        sys.addaudithook(_antaris_hook)
        _INSTALLED = True


def escalate(new_level: int) -> bool:
    """Escalate to a higher security level.
    
    Returns:
        False if new_level <= current (can't downgrade), True otherwise.
    """
    global _LEVEL
    if new_level <= _LEVEL:
        return False
    _LEVEL = new_level
    return True


def current_level() -> int:
    """Get the current security level."""
    return _LEVEL


def add_allowed_host(host: str) -> None:
    """Add a host to the network allowlist for SECURED/ENCRYPTED levels."""
    ALLOWED_HOSTS.add(host)


# ---------------------------------------------------------------------------
# File access helper (shared by STANDARD and SANDBOXED+ branches)
# ---------------------------------------------------------------------------

def _check_file_access(resolved: str) -> bool:
    """Return True if file access to *resolved* should be permitted.

    Checks (in order):
    1. Inside workspace → allow
    2. Inside approved home subdirectories → allow
    3. Inside /tmp or system temp dirs → allow
    4. Inside Python's own paths (stdlib, site-packages, venv) → allow
    5. Read-only system paths (MIME, SSL, timezone, /dev/null, etc.) → allow
    6. Otherwise → deny (caller should raise PermissionError)
    """
    # 1. Workspace
    if _is_inside_workspace(resolved):
        return True

    # 2. Approved home subdirectories (.antarisbot / .antarisagent kept for backward compat)
    try:
        home_dir = str(Path.home().resolve())
        _allowed_home_subdirs = (
            os.path.join(home_dir, ".antarisbot"),
            os.path.join(home_dir, ".antarisagent"),
            os.path.join(home_dir, ".openclaw"),
            os.path.join(home_dir, ".config"),
        )
        for _subdir in _allowed_home_subdirs:
            # Use os.sep to avoid prefix collisions (e.g. .configX)
            if resolved.startswith(_subdir + os.sep) or resolved == _subdir:
                return True
    except Exception:
        pass

    # 3. /tmp and system temp directories (startswith is safe for system-owned dirs)
    if (
        resolved.startswith("/tmp")
        or resolved.startswith("/private/tmp")
        or resolved.startswith("/var/folders/")
        or resolved.startswith("/private/var/folders/")  # macOS temporary folders
    ):
        return True

    # 4. Python stdlib / site-packages / venv
    for allowed in _ALLOWED_PATHS:
        if resolved.startswith(allowed):
            return True

    # 5. Read-only system paths (MIME types, SSL certs, timezone, /dev/null, etc.)
    #    These are OS-provided resources that stdlib modules need to function.
    for prefix in _SYSTEM_READ_PREFIXES:
        if resolved == prefix or resolved.startswith(prefix + os.sep):
            return True

    return False


# ---------------------------------------------------------------------------
# The audit hook
# ---------------------------------------------------------------------------

def _antaris_hook(event: str, args: tuple) -> None:  # noqa: C901
    """sys.audit hook — enforces level-based restrictions."""
    try:
        # ------------------------------------------------------------------ #
        # File access
        # ------------------------------------------------------------------ #
        if event == "open":
            # args: (path, mode, flags)
            raw_path = args[0] if args else None
            if raw_path is None:
                return

            # Integer file descriptors (from os.fdopen, os.dup, etc.) are not
            # filesystem paths — they reference already-opened kernel handles.
            # The security decision was made when the FD was originally opened;
            # re-wrapping it via fdopen is not a new access vector.
            if isinstance(raw_path, int):
                return

            try:
                resolved = str(Path(str(raw_path)).resolve())
            except Exception:
                return  # can't resolve → allow (best effort)

            # Level 1 (STANDARD) and Level 2+ (SANDBOXED and above) share the
            # same allow-list logic; only the error message label differs.
            if _LEVEL >= LEVEL_STANDARD:
                if not _check_file_access(resolved):
                    raise PermissionError(
                        f"[Antaris Agent/level-{_LEVEL}] File access blocked: {resolved}"
                    )

        # ------------------------------------------------------------------ #
        # Subprocess
        # ------------------------------------------------------------------ #
        elif event == "subprocess.Popen":
            if _LEVEL == LEVEL_STANDARD:
                # Level 1: Allow but could log (logging not implemented in audit hook)
                return
            elif _LEVEL >= LEVEL_SANDBOXED:
                # Level 2+: Block subprocess execution
                raise PermissionError(
                    f"[Antaris Agent/level-{_LEVEL}] Subprocess execution blocked"
                )

        # ------------------------------------------------------------------ #
        # exec() — ENCRYPTED only
        # ------------------------------------------------------------------ #
        elif event == "exec":
            if _LEVEL >= LEVEL_ENCRYPTED:
                raise PermissionError(
                    f"[Antaris Agent/level-{_LEVEL}] Code execution blocked"
                )

        # ------------------------------------------------------------------ #
        # Network — SECURED and ENCRYPTED
        # ------------------------------------------------------------------ #
        elif event == "socket.connect":
            if _LEVEL >= LEVEL_SECURED:
                # args varies by address family; try to extract host
                addr = args[1] if len(args) > 1 else None
                if addr is None:
                    return
                if isinstance(addr, (list, tuple)) and len(addr) >= 1:
                    host = str(addr[0])
                elif isinstance(addr, str):
                    # Unix socket path — allow
                    return
                else:
                    return

                if host not in ALLOWED_HOSTS:
                    raise PermissionError(
                        f"[Antaris Agent/level-{_LEVEL}] Network access blocked: {host}"
                    )

    except PermissionError:
        # Always propagate PermissionError — that's how we block things
        raise
    except Exception:
        # Swallow everything else; we must never crash the bot
        pass
