"""Antaris Agent security package — audit hooks, encryption, tool middleware."""
from .audit_hook import install as install_audit_hook
from .tool_middleware import ToolMiddleware

__all__ = ["install_audit_hook", "ToolMiddleware"]
