"""Antaris Agent tool middleware — approval prompts and audit logging for secured/encrypted modes."""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import logging.handlers
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional, Union

from .levels import (
    LEVEL_OPEN, LEVEL_STANDARD, LEVEL_SANDBOXED, LEVEL_SECURED, LEVEL_ENCRYPTED,
    is_destructive_tool
)
from antaris_agent.core.error_formatter import format_tool_error, ToolExecutionError


class ToolMiddleware:
    """Wraps tool invocations with per-level approval logic and audit logging.

    Levels:
        - 0 (OPEN):      No restrictions; tool runs immediately.
        - 1 (STANDARD):  No restrictions; tool runs immediately.
        - 2 (SANDBOXED): Prints tool name to stdout; tool runs immediately.
        - 3 (SECURED):   Logs tool calls with SHA-256. Prompts for destructive ops.
        - 4 (ENCRYPTED): Interactive ``[y/N]`` prompt for ALL tools; full audit log.

    Args:
        mode_or_level: Security level (0-4) or legacy mode string for backward compat.
        audit_log_path: Path to the audit log file. Required when level >= 3; ignored otherwise.
    """

    def __init__(self, mode_or_level: Union[int, str], audit_log_path: Optional[str] = None) -> None:
        # Accept both int level and string mode for backward compat
        if isinstance(mode_or_level, str):
            mode_map = {
            "open": LEVEL_OPEN,
            "standard": LEVEL_STANDARD,
            "sandboxed": LEVEL_SANDBOXED,
            "secured": LEVEL_SECURED,
            "encrypted": LEVEL_ENCRYPTED,
            "locked": LEVEL_ENCRYPTED,  # legacy alias
        }
            self.level = mode_map.get(mode_or_level, LEVEL_STANDARD)
        else:
            self.level = mode_or_level

        self._audit_logger: Optional[logging.Logger] = None

        if self.level >= LEVEL_SECURED and audit_log_path:
            self._audit_logger = self._setup_audit_logger(audit_log_path)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def approve_and_run(
        self,
        tool_name: str,
        args: dict,
        fn: Optional[Callable],
        *fn_args: Any,
        **fn_kwargs: Any,
    ) -> Any:
        """Gate a tool call through level-appropriate approval logic.

        Args:
            tool_name: Human-readable name of the tool (e.g. ``"read_file"``).
            args: Dict of arguments for display / audit purposes.
            fn: Async callable to invoke, or ``None`` (dry-run / capability check).
            *fn_args: Positional arguments forwarded to *fn*.
            **fn_kwargs: Keyword arguments forwarded to *fn*.

        Returns:
            The return value of *fn*, ``True`` (if fn is None in open/standard mode),
            or ``None`` if the call was rejected in secured/encrypted mode.
        """
        if self.level <= LEVEL_STANDARD:  # Open or Standard
            # Just run it
            if fn is not None:
                try:
                    return await fn(*fn_args, **fn_kwargs)
                except Exception as e:
                    raise ToolExecutionError(format_tool_error(tool_name, e)) from e
            return True

        elif self.level == LEVEL_SANDBOXED:  # Sandboxed
            print(f"   [tool] {tool_name}", flush=True)
            if fn is not None:
                try:
                    return await fn(*fn_args, **fn_kwargs)
                except Exception as e:
                    raise ToolExecutionError(format_tool_error(tool_name, e)) from e
            return True

        elif self.level == LEVEL_SECURED:  # Secured
            # Log with hash, prompt if destructive
            is_destructive = is_destructive_tool(tool_name)
            
            if is_destructive:
                prompt = (
                    f"\n⚠️  [secured] Approve destructive tool: {tool_name}"
                    f"({self._fmt_args(args)})? [y/N] "
                )
                loop = asyncio.get_running_loop()
                answer: str = await loop.run_in_executor(None, input, prompt)

                if answer.strip().lower() != "y":
                    self._log_audit(
                        tool_name=tool_name,
                        args=args,
                        approved=False,
                        response_hash=None,
                        status="rejected",
                    )
                    return None

            # Execute (either approved destructive or non-destructive)
            result = None
            if fn is not None:
                try:
                    result = await fn(*fn_args, **fn_kwargs)
                except Exception as e:
                    self._log_audit(
                        tool_name=tool_name,
                        args=args,
                        approved=True,
                        response_hash=None,
                        status="error",
                    )
                    raise ToolExecutionError(format_tool_error(tool_name, e)) from e

            # Log with SHA-256 hash
            response_hash = hashlib.sha256(str(result).encode("utf-8")).hexdigest()
            self._log_audit(
                tool_name=tool_name,
                args=args,
                approved=True,
                response_hash=response_hash,
                status="success",
            )
            return result

        elif self.level == LEVEL_ENCRYPTED:  # Encrypted
            # Prompt for ALL tool calls, full audit
            prompt = (
                f"\n🔐 [encrypted] Approve: {tool_name}"
                f"({self._fmt_args(args)})? [y/N] "
            )
            loop = asyncio.get_running_loop()
            answer: str = await loop.run_in_executor(None, input, prompt)

            if answer.strip().lower() != "y":
                self._log_audit(
                    tool_name=tool_name,
                    args=args,
                    approved=False,
                    response_hash=None,
                    status="rejected",
                )
                return None

            # Approved — execute
            result = None
            if fn is not None:
                try:
                    result = await fn(*fn_args, **fn_kwargs)
                except Exception as e:
                    self._log_audit(
                        tool_name=tool_name,
                        args=args,
                        approved=True,
                        response_hash=None,
                        status="error",
                    )
                    raise ToolExecutionError(format_tool_error(tool_name, e)) from e
            response_hash = hashlib.sha256(str(result).encode("utf-8")).hexdigest()
            self._log_audit(
                tool_name=tool_name,
                args=args,
                approved=True,
                response_hash=response_hash,
                status="success",
            )
            return result

        # Should never reach here
        return None

    def escalate(self, new_level: int) -> bool:
        """Escalate to a higher security level.
        
        Returns:
            False if new_level <= current (can't downgrade), True otherwise.
        """
        if new_level <= self.level:
            return False
        self.level = new_level
        return True

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _fmt_args(self, args: dict) -> str:
        """Return a truncated repr of *args* (max 80 chars)."""
        raw = repr(args)
        if len(raw) <= 80:
            return raw
        return raw[:77] + "..."

    def _log_audit(
        self,
        tool_name: str,
        args: dict,
        approved: bool,
        response_hash: Optional[str] = None,
        status: str = "success",
    ) -> None:
        """Write a JSON line to the audit logger (locked mode only)."""
        if self._audit_logger is None:
            return

        record = {
            "ts": datetime.now(tz=timezone.utc).isoformat(),
            "tool": tool_name,
            "args_repr": self._fmt_args(args),
            "approved": approved,
            "status": status,
            "response_sha256": response_hash,
        }
        self._audit_logger.info(json.dumps(record))

    # ------------------------------------------------------------------
    # Logger setup
    # ------------------------------------------------------------------

    @staticmethod
    def _setup_audit_logger(log_path: str) -> logging.Logger:
        """Create a dedicated logger writing JSON lines to a rotating file."""
        logger = logging.getLogger("antaris.audit")
        logger.setLevel(logging.INFO)
        logger.propagate = False  # don't bubble up to root logger

        # Only add the handler once (guard against double-init in tests)
        if not logger.handlers:
            handler = logging.handlers.TimedRotatingFileHandler(
                log_path,
                when="midnight",
                backupCount=30,
                encoding="utf-8",
            )
            # Plain formatter — the record body is already a JSON string
            handler.setFormatter(logging.Formatter("%(message)s"))
            logger.addHandler(handler)

        return logger
