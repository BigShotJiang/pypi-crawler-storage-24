import asyncio
import logging
from typing import Optional, TYPE_CHECKING

from .base import ChannelAdapter, InboundMessage, OutboundMessage

if TYPE_CHECKING:
    from telegram import Update
    from telegram.ext import Application, ContextTypes

Application = None
TGMessageHandler = None
filters = None
NetworkError = None
TimedOut = None
ChatAction = None
_PTBT_IMPORTED = False

logger = logging.getLogger(__name__)

MAX_MESSAGE_LENGTH = 4096  # Telegram limit


class TelegramAdapter(ChannelAdapter):
    """Telegram channel adapter using python-telegram-bot v20+."""

    def __init__(
        self,
        token: str,
        bot_name: str = "Antaris",
        open_chats: Optional[list] = None,
    ):
        """
        Args:
            token: Telegram bot token from BotFather.
            bot_name: Display name.
            open_chats: Chat IDs where bot responds to ALL messages (no @mention
                        required). If empty, bot responds to every message
                        (open mode). DMs are always responded to regardless.
        """
        if not token:
            raise ValueError("Telegram token is required")
        super().__init__()
        self.token = token
        self.bot_name = bot_name
        self.open_chats: set[str] = set(str(c) for c in (open_chats or []))
        self._app: Optional["Application"] = None
        self._stop_event: Optional[asyncio.Event] = None

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def connect(self):
        """Build Application, start polling with retry, block until disconnect() called."""
        global Application, TGMessageHandler, filters, NetworkError, TimedOut, _PTBT_IMPORTED
        if not _PTBT_IMPORTED:
            try:
                from telegram.error import NetworkError as _NetworkError, TimedOut as _TimedOut
                from telegram.ext import Application as _Application, MessageHandler as _TGMessageHandler, filters as _filters
            except ImportError as exc:
                raise ImportError(
                    "Telegram support requires the optional dependency 'python-telegram-bot'. "
                    "Install it with: pip install 'antaris-agent[telegram]'"
                ) from exc
            if Application is None:
                Application = _Application
            if TGMessageHandler is None:
                TGMessageHandler = _TGMessageHandler
            if filters is None:
                filters = _filters
            if NetworkError is None:
                NetworkError = _NetworkError
            if TimedOut is None:
                TimedOut = _TimedOut
            _PTBT_IMPORTED = True

        if any(x is None for x in (Application, TGMessageHandler, filters, NetworkError, TimedOut)):
            try:
                from telegram.error import NetworkError as _NetworkError, TimedOut as _TimedOut
                from telegram.ext import Application as _Application, MessageHandler as _TGMessageHandler, filters as _filters
            except ImportError as exc:
                raise ImportError(
                    "Telegram support requires the optional dependency 'python-telegram-bot'. "
                    "Install it with: pip install 'antaris-agent[telegram]'"
                ) from exc
            Application = _Application
            TGMessageHandler = _TGMessageHandler
            filters = _filters
            NetworkError = _NetworkError
            TimedOut = _TimedOut

        self._stop_event = asyncio.Event()

        self._app = Application.builder().token(self.token).build()
        self._app.add_handler(
            TGMessageHandler(filters.TEXT & ~filters.COMMAND, self._on_message)
        )

        await self._app.initialize()
        await self._app.start()

        # ── Polling with retry on network errors ─────────────────────────────
        max_retries = 5
        retry_delay_seconds = 5
        attempt = 0

        while attempt <= max_retries:
            try:
                await self._app.updater.start_polling()
                logger.info("Telegram: Connected and polling ✅")
                if self.open_chats:
                    logger.info("Telegram: Restricted to chats: %s", self.open_chats)
                break  # Successfully started — exit retry loop
            except (NetworkError, TimedOut) as e:
                attempt += 1
                if attempt > max_retries:
                    logger.error(
                        "Telegram: Polling failed after %d attempts: %s", max_retries, e
                    )
                    raise
                logger.warning(
                    "Telegram: Polling attempt %d/%d failed (%s). "
                    "Retrying in %ds...",
                    attempt, max_retries, e, retry_delay_seconds,
                )
                await asyncio.sleep(retry_delay_seconds)

        # Wait until disconnect() is called
        await self._stop_event.wait()

        # Clean shutdown
        await self._app.updater.stop()
        await self._app.stop()
        await self._app.shutdown()

    async def disconnect(self):
        """Signal the polling loop to stop."""
        if self._stop_event:
            self._stop_event.set()

    async def start(self):
        """Alias for connect()."""
        await self.connect()

    async def stop(self):
        """Alias for disconnect()."""
        await self.disconnect()

    # ── Message handling ─────────────────────────────────────────────────

    async def _on_message(self, update: "Update", context: "ContextTypes.DEFAULT_TYPE"):
        """Route incoming Telegram messages to the registered handler."""
        if not update.message or not update.message.text:
            return

        message = update.message
        chat_id = str(message.chat.id)
        chat_type = message.chat.type  # "private" | "group" | "supergroup" | "channel"
        is_dm = chat_type == "private"

        # @mention detection
        bot_username = context.bot.username
        is_mentioned = bool(
            bot_username and f"@{bot_username}" in message.text
        )

        # Routing logic
        if is_dm:
            should_respond = True
        elif is_mentioned:
            should_respond = True
        elif self.open_chats:
            # Restricted mode: only configured chats (and DMs / @mentions above)
            should_respond = chat_id in self.open_chats
        else:
            # Unrestricted: respond to every message
            should_respond = True

        if not should_respond:
            return

        # Strip @mention from text
        text = message.text
        if bot_username:
            text = text.replace(f"@{bot_username}", "").strip()

        if not text:
            return

        # Typing indicator
        try:
            global ChatAction
            if ChatAction is None:
                from telegram.constants import ChatAction as _ChatAction
                ChatAction = _ChatAction
            await context.bot.send_chat_action(
                chat_id=message.chat.id,
                action=ChatAction.TYPING,
            )
        except Exception as e:
            logger.debug("Could not send typing action: %s", e)

        if self._handler:
            user = message.from_user
            inbound = InboundMessage(
                id=str(message.message_id),
                user_id=str(user.id) if user else chat_id,
                user_name=user.full_name if user else "unknown",
                channel_id=chat_id,
                platform="telegram",
                text=text,
                timestamp_ms=int(message.date.timestamp() * 1000) if message.date else 0,
                metadata={"chat_type": chat_type},
            )
            await self._handler(inbound)

    # ── Outbound ─────────────────────────────────────────────────────────

    async def send(self, message: OutboundMessage):
        """Send a message, splitting at the 4096-char Telegram limit."""
        if not self._app:
            return

        chunks = self._split_message(message.text)
        for chunk in chunks:
            try:
                await self._app.bot.send_message(
                    chat_id=int(message.channel_id),
                    text=chunk,
                )
            except Exception as e:
                logger.error("Telegram send error: %s", e)

    async def send_message(self, chat_id, text: str):
        """Helper: send a message directly by chat_id (int or str)."""
        if not self._app:
            return

        chunks = self._split_message(text)
        for chunk in chunks:
            try:
                await self._app.bot.send_message(chat_id=int(chat_id), text=chunk)
            except Exception as e:
                logger.error("Telegram send_message error: %s", e)

    def _split_message(self, text: str) -> list[str]:
        """Split long messages at newlines, respecting Telegram's 4096-char limit."""
        if len(text) <= MAX_MESSAGE_LENGTH:
            return [text]

        chunks = []
        lines = text.split("\n")
        current = ""
        for line in lines:
            if len(current) + len(line) + 1 > MAX_MESSAGE_LENGTH:
                if current:
                    chunks.append(current.strip())
                current = line
            else:
                current = current + "\n" + line if current else line
        if current:
            chunks.append(current.strip())
        return chunks

    def format_for_surface(self, text: str) -> str:
        return text
