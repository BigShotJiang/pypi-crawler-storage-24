from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

SCOPES = [
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/documents",
]

TOKEN_PATH = Path.home() / ".antarisbot" / "google_token.json"

NOT_AUTHORIZED_MSG = (
    "Google account not connected. Run `antaris google-auth` to authorize."
)


class GoogleAuthManager:
    """Manages Google OAuth2 credentials using device flow (no browser redirect)."""

    def __init__(self, client_id: str, client_secret: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self._credentials: Optional[object] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def is_authorized(self) -> bool:
        """Return True if a valid (or refreshable) token exists."""
        try:
            creds = self.get_credentials()
            return creds is not None and creds.valid
        except Exception:
            return False

    def get_credentials(self):
        """Return valid Credentials, refreshing if expired. Returns None if not authed.

        NOTE: The self._credentials.refresh(Request()) call below is blocking (network I/O).
        This method must always be called from within a thread-pool executor (e.g. via
        run_in_executor), never directly from an async context on the event loop.
        _build_service() in each Google tool file already does this correctly.
        """
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request

        if self._credentials and self._credentials.valid:
            return self._credentials

        if TOKEN_PATH.exists():
            try:
                self._credentials = Credentials.from_authorized_user_file(
                    str(TOKEN_PATH), SCOPES
                )
            except Exception as e:
                logger.warning("Failed to load google token: %s", e)
                return None

        if self._credentials and self._credentials.expired and self._credentials.refresh_token:
            try:
                self._credentials.refresh(Request())  # blocking — must run in executor
                self._save_token()
            except Exception as e:
                logger.warning("Failed to refresh google token: %s", e)
                return None

        return self._credentials if (self._credentials and self._credentials.valid) else None

    async def start_auth_flow(self) -> str:
        """
        Begin device authorization flow (async wrapper — non-blocking).
        Returns a user-facing string with the verification URL and user code.
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._start_auth_flow_sync)

    def _start_auth_flow_sync(self) -> str:
        """Blocking implementation of start_auth_flow. Call via run_in_executor only."""
        import urllib.request
        import urllib.parse

        data = urllib.parse.urlencode({
            "client_id": self.client_id,
            "scope": " ".join(SCOPES),
        }).encode()

        req = urllib.request.Request(
            "https://oauth2.googleapis.com/device/code",
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            payload = json.loads(resp.read())

        self._pending_device = payload  # stash for finish_auth_flow
        verification_url = payload.get("verification_url", "https://google.com/device")
        user_code = payload.get("user_code", "")

        return (
            f"Visit {verification_url} and enter the code: **{user_code}**\n"
            f"Then call `finish_auth_flow` with device_code='{payload.get('device_code', '')}'"
        )

    async def finish_auth_flow(self, device_code: str) -> bool:
        """
        Poll Google for the access token after the user has approved (async wrapper — non-blocking).
        Returns True on success, False on failure.
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._finish_auth_flow_sync, device_code)

    def _finish_auth_flow_sync(self, device_code: str) -> bool:
        """Blocking implementation of finish_auth_flow. Call via run_in_executor only."""
        import urllib.request
        import urllib.parse
        from google.oauth2.credentials import Credentials

        interval = getattr(self, "_pending_device", {}).get("interval", 5)
        deadline = time.time() + 300  # 5 min max

        while time.time() < deadline:
            data = urllib.parse.urlencode({
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "device_code": device_code,
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            }).encode()

            req = urllib.request.Request(
                "https://oauth2.googleapis.com/token",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            try:
                with urllib.request.urlopen(req, timeout=15) as resp:
                    payload = json.loads(resp.read())
            except Exception as e:
                # HTTP errors come as urllib.error.HTTPError
                try:
                    body = e.read().decode()  # type: ignore[attr-defined]
                    payload = json.loads(body)
                except Exception:
                    logger.warning("finish_auth_flow request error: %s", e)
                    return False

            error = payload.get("error")
            if error == "authorization_pending":
                time.sleep(interval)
                continue
            if error == "slow_down":
                interval += 5
                time.sleep(interval)
                continue
            if error:
                logger.warning("Device auth error: %s", error)
                return False

            # Success — build Credentials object
            self._credentials = Credentials(
                token=payload["access_token"],
                refresh_token=payload.get("refresh_token"),
                token_uri="https://oauth2.googleapis.com/token",
                client_id=self.client_id,
                client_secret=self.client_secret,
                scopes=SCOPES,
            )
            self._save_token()
            return True

        return False  # timed out

    def revoke(self) -> None:
        """Clear stored token and in-memory credentials."""
        if TOKEN_PATH.exists():
            TOKEN_PATH.unlink()
        self._credentials = None
        logger.info("Google credentials revoked.")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _save_token(self) -> None:
        TOKEN_PATH.parent.mkdir(parents=True, exist_ok=True)
        TOKEN_PATH.write_text(self._credentials.to_json())  # type: ignore[union-attr]
        logger.debug("Google token saved to %s", TOKEN_PATH)
