from __future__ import annotations

import asyncio
import logging
from typing import List

try:
    from googleapiclient.errors import HttpError
except ImportError:
    HttpError = Exception  # type: ignore[assignment,misc]

from .base import NativeTool, ToolResult
from .google_auth import GoogleAuthManager, NOT_AUTHORIZED_MSG

logger = logging.getLogger(__name__)


def _build_service(auth: GoogleAuthManager):
    from googleapiclient.discovery import build
    return build("sheets", "v4", credentials=auth.get_credentials(), cache_discovery=False)


def _fmt_table(values: List[List]) -> str:
    if not values:
        return "(empty)"
    col_widths = [0] * max(len(row) for row in values)
    for row in values:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))
    lines = []
    for row in values:
        parts = [str(cell).ljust(col_widths[i]) for i, cell in enumerate(row)]
        lines.append(" | ".join(parts))
    return "\n".join(lines)


class SheetsReadTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "sheets_read"

    @property
    def description(self) -> str:
        return "Read a range of cells from a Google Sheets spreadsheet."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "spreadsheet_id": {"type": "string"},
                "range": {"type": "string", "description": "e.g. Sheet1!A1:D10"},
            },
            "required": ["spreadsheet_id", "range"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        spreadsheet_id = arguments["spreadsheet_id"]
        range_ = arguments["range"]

        def _read():
            svc = _build_service(self._auth)
            result = svc.spreadsheets().values().get(
                spreadsheetId=spreadsheet_id, range=range_
            ).execute()
            return result.get("values", [])

        try:
            values = await asyncio.get_running_loop().run_in_executor(None, _read)
            return ToolResult(success=True, content=_fmt_table(values))
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class SheetsWriteTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "sheets_write"

    @property
    def description(self) -> str:
        return "Write values to a range in a Google Sheets spreadsheet."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "spreadsheet_id": {"type": "string"},
                "range": {"type": "string", "description": "e.g. Sheet1!A1"},
                "values": {
                    "type": "array",
                    "items": {"type": "array", "items": {"type": "string"}},
                    "description": "2D array of values (rows × columns)",
                },
            },
            "required": ["spreadsheet_id", "range", "values"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        spreadsheet_id = arguments["spreadsheet_id"]
        range_ = arguments["range"]
        values = arguments["values"]

        def _write():
            svc = _build_service(self._auth)
            result = svc.spreadsheets().values().update(
                spreadsheetId=spreadsheet_id,
                range=range_,
                valueInputOption="USER_ENTERED",
                body={"values": values},
            ).execute()
            return result.get("updatedRange", range_)

        try:
            updated = await asyncio.get_running_loop().run_in_executor(None, _write)
            return ToolResult(success=True, content=f"Written to range: {updated}")
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class SheetsAppendTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "sheets_append"

    @property
    def description(self) -> str:
        return "Append a row to a Google Sheets spreadsheet."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "spreadsheet_id": {"type": "string"},
                "sheet_name": {"type": "string", "default": "Sheet1"},
                "values": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Row values to append",
                },
            },
            "required": ["spreadsheet_id", "values"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        spreadsheet_id = arguments["spreadsheet_id"]
        sheet_name = arguments.get("sheet_name", "Sheet1")
        values = arguments["values"]
        range_ = f"{sheet_name}!A:A"

        def _append():
            svc = _build_service(self._auth)
            result = svc.spreadsheets().values().append(
                spreadsheetId=spreadsheet_id,
                range=range_,
                valueInputOption="USER_ENTERED",
                insertDataOption="INSERT_ROWS",
                body={"values": [values]},
            ).execute()
            updates = result.get("updates", {})
            return updates.get("updatedRange", "unknown")

        try:
            updated = await asyncio.get_running_loop().run_in_executor(None, _append)
            return ToolResult(success=True, content=f"Row appended. Range: {updated}")
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)
