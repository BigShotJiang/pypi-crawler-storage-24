"""
SpawnSubagentTool — lets the LLM autonomously spawn a named subagent
to handle a parallel or background task.
"""
from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from .base import NativeTool, ToolResult

if TYPE_CHECKING:
    from antaris_agent.core.subagents import SubagentRegistry

logger = logging.getLogger(__name__)


class SpawnSubagentTool(NativeTool):
    """
    Tool that allows the LLM to spawn a named subagent for parallel/background work.
    The subagent runs an LLM call with the given task and posts results back to Discord.
    """

    def __init__(self, registry: "SubagentRegistry", origin_channel=None):
        self.registry = registry
        self.origin_channel = origin_channel  # captured at request time

    @property
    def name(self) -> str:
        return "spawn_subagent"

    @property
    def description(self) -> str:
        return (
            "Spawn a background subagent to handle a task in parallel. "
            "The subagent runs independently and posts its result to Discord when done. "
            "Use this when a task would take a long time, needs to run in parallel with other work, "
            "or should be delegated to a focused worker. "
            "Returns immediately with the subagent name — results arrive later."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "The task for the subagent to complete. Be specific and detailed."
                },
                "name": {
                    "type": "string",
                    "description": "Optional name for the subagent (a-z). Auto-assigned if omitted."
                },
                "context": {
                    "type": "string",
                    "description": "Optional context to pass to the subagent (relevant background info)."
                }
            },
            "required": ["task"]
        }

    async def execute(self, arguments: dict) -> ToolResult:
        task = arguments.get("task", "").strip()
        name = arguments.get("name")
        context = arguments.get("context")

        if not task:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: task",
                is_error=True
            )

        if not self.registry:
            return ToolResult(
                success=False,
                content="",
                error="Subagent registry not available",
                is_error=True
            )

        ok, msg = await self.registry.spawn(
            task=task,
            name=name,
            context=context,
            origin_channel=self.origin_channel,
        )

        return ToolResult(
            success=ok,
            content=msg,
            error="" if ok else msg,
            is_error=not ok
        )
