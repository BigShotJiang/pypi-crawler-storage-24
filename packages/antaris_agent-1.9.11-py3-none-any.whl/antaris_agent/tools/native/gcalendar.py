from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import List, Optional

try:
    from googleapiclient.errors import HttpError
except ImportError:
    HttpError = Exception  # type: ignore[assignment,misc]

from .base import NativeTool, ToolResult
from .google_auth import GoogleAuthManager, NOT_AUTHORIZED_MSG

logger = logging.getLogger(__name__)


def _build_service(auth: GoogleAuthManager):
    from googleapiclient.discovery import build
    return build("calendar", "v3", credentials=auth.get_credentials(), cache_discovery=False)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _fmt_event(event: dict) -> str:
    start = event.get("start", {})
    end = event.get("end", {})
    start_str = start.get("dateTime", start.get("date", "?"))
    end_str = end.get("dateTime", end.get("date", "?"))
    attendees = ", ".join(
        a.get("email", "") for a in event.get("attendees", [])
    )
    return (
        f"ID: {event.get('id', '?')}\n"
        f"Title: {event.get('summary', '(no title)')}\n"
        f"Start: {start_str}\n"
        f"End: {end_str}\n"
        f"Location: {event.get('location', '')}\n"
        f"Attendees: {attendees or 'none'}\n"
        f"Link: {event.get('htmlLink', '')}\n"
    )


class CalendarListEventsTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "calendar_list_events"

    @property
    def description(self) -> str:
        return "List upcoming Google Calendar events."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "time_min": {"type": "string", "description": "Start time ISO8601 (default: now)"},
                "time_max": {"type": "string", "description": "End time ISO8601 (optional)"},
                "max_results": {"type": "integer", "default": 10},
                "calendar_id": {"type": "string", "default": "primary"},
            },
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        time_min = arguments.get("time_min") or _now_iso()
        time_max = arguments.get("time_max")
        max_results = int(arguments.get("max_results", 10))
        calendar_id = arguments.get("calendar_id", "primary")

        def _fetch():
            svc = _build_service(self._auth)
            params = dict(
                calendarId=calendar_id,
                timeMin=time_min,
                maxResults=max_results,
                singleEvents=True,
                orderBy="startTime",
            )
            if time_max:
                params["timeMax"] = time_max
            result = svc.events().list(**params).execute()
            return result.get("items", [])

        try:
            events = await asyncio.get_running_loop().run_in_executor(None, _fetch)
            if not events:
                return ToolResult(success=True, content="No events found.")
            return ToolResult(
                success=True,
                content=("\n" + "-" * 40 + "\n").join(_fmt_event(e) for e in events),
            )
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class CalendarCreateEventTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "calendar_create_event"

    @property
    def description(self) -> str:
        return "Create a new Google Calendar event."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "start": {"type": "string", "description": "ISO8601 datetime"},
                "end": {"type": "string", "description": "ISO8601 datetime"},
                "description": {"type": "string"},
                "attendees": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of attendee email addresses",
                },
                "location": {"type": "string"},
                "calendar_id": {"type": "string", "default": "primary"},
            },
            "required": ["title", "start", "end"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        body: dict = {
            "summary": arguments["title"],
            "start": {"dateTime": arguments["start"]},
            "end": {"dateTime": arguments["end"]},
        }
        if arguments.get("description"):
            body["description"] = arguments["description"]
        if arguments.get("location"):
            body["location"] = arguments["location"]
        if arguments.get("attendees"):
            body["attendees"] = [{"email": e} for e in arguments["attendees"]]

        calendar_id = arguments.get("calendar_id", "primary")

        def _create():
            svc = _build_service(self._auth)
            event = svc.events().insert(calendarId=calendar_id, body=body).execute()
            return event.get("id", "?"), event.get("htmlLink", "")

        try:
            event_id, link = await asyncio.get_running_loop().run_in_executor(None, _create)
            return ToolResult(
                success=True,
                content=f"Event created.\nID: {event_id}\nLink: {link}",
            )
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class CalendarUpdateEventTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "calendar_update_event"

    @property
    def description(self) -> str:
        return "Update an existing Google Calendar event (only provided fields are changed)."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "event_id": {"type": "string"},
                "calendar_id": {"type": "string", "default": "primary"},
                "title": {"type": "string"},
                "start": {"type": "string"},
                "end": {"type": "string"},
                "description": {"type": "string"},
                "location": {"type": "string"},
            },
            "required": ["event_id"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        event_id = arguments["event_id"]
        calendar_id = arguments.get("calendar_id", "primary")
        patch: dict = {}

        if arguments.get("title"):
            patch["summary"] = arguments["title"]
        if arguments.get("start"):
            patch["start"] = {"dateTime": arguments["start"]}
        if arguments.get("end"):
            patch["end"] = {"dateTime": arguments["end"]}
        if arguments.get("description"):
            patch["description"] = arguments["description"]
        if arguments.get("location"):
            patch["location"] = arguments["location"]

        def _update():
            svc = _build_service(self._auth)
            event = svc.events().patch(
                calendarId=calendar_id, eventId=event_id, body=patch
            ).execute()
            return event.get("htmlLink", "")

        try:
            link = await asyncio.get_running_loop().run_in_executor(None, _update)
            return ToolResult(success=True, content=f"Event updated.\nLink: {link}")
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class CalendarDeleteEventTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "calendar_delete_event"

    @property
    def description(self) -> str:
        return "Delete a Google Calendar event."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "event_id": {"type": "string"},
                "calendar_id": {"type": "string", "default": "primary"},
            },
            "required": ["event_id"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        event_id = arguments["event_id"]
        calendar_id = arguments.get("calendar_id", "primary")

        def _delete():
            svc = _build_service(self._auth)
            svc.events().delete(calendarId=calendar_id, eventId=event_id).execute()

        try:
            await asyncio.get_running_loop().run_in_executor(None, _delete)
            return ToolResult(success=True, content=f"Event {event_id} deleted.")
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class CalendarFreeBusyTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "calendar_free_busy"

    @property
    def description(self) -> str:
        return "Query free/busy time blocks for a calendar."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "time_min": {"type": "string", "description": "Start ISO8601"},
                "time_max": {"type": "string", "description": "End ISO8601"},
                "calendar_id": {"type": "string", "default": "primary"},
            },
            "required": ["time_min", "time_max"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        calendar_id = arguments.get("calendar_id", "primary")

        def _query():
            svc = _build_service(self._auth)
            result = svc.freebusy().query(body={
                "timeMin": arguments["time_min"],
                "timeMax": arguments["time_max"],
                "items": [{"id": calendar_id}],
            }).execute()
            busy = result.get("calendars", {}).get(calendar_id, {}).get("busy", [])
            return busy

        try:
            busy = await asyncio.get_running_loop().run_in_executor(None, _query)
            if not busy:
                return ToolResult(success=True, content="No busy blocks in that range — you're free!")
            lines = [f"Busy: {b['start']} → {b['end']}" for b in busy]
            return ToolResult(success=True, content="\n".join(lines))
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)
