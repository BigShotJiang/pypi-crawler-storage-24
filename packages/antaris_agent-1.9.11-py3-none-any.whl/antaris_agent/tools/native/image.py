from __future__ import annotations

import base64
import logging
import mimetypes
from pathlib import Path
from typing import Any, Dict

import httpx

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class ImageTool(NativeTool):
    def __init__(self, dispatcher):
        """Initialize ImageTool with LLM dispatcher for vision analysis."""
        self.dispatcher = dispatcher

    @property
    def name(self) -> str:
        return "image"

    @property
    def description(self) -> str:
        return "Analyze images using vision capabilities of the configured LLM"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "image_path": {
                    "type": "string",
                    "description": "Local path to image file"
                },
                "image_url": {
                    "type": "string",
                    "description": "URL to image"
                },
                "prompt": {
                    "type": "string",
                    "description": "Analysis prompt (optional, defaults to general description)",
                    "default": "Describe this image in detail."
                }
            },
            "required": []
        }

    async def execute(self, arguments: dict) -> ToolResult:
        image_path = arguments.get("image_path")
        image_url = arguments.get("image_url")
        prompt = arguments.get("prompt", "Describe this image in detail.")

        if not image_path and not image_url:
            return ToolResult(
                success=False,
                content="",
                error="Must provide either image_path or image_url",
                is_error=True
            )

        if image_path and image_url:
            return ToolResult(
                success=False,
                content="",
                error="Cannot provide both image_path and image_url",
                is_error=True
            )

        try:
            if image_path:
                image_b64, media_type = await self._load_local_image(image_path)
                image_source = f"local file: {image_path}"
            else:
                image_b64, media_type = await self._fetch_remote_image(image_url)
                image_source = f"URL: {image_url}"

            if not image_b64:
                return ToolResult(
                    success=False,
                    content="",
                    error="Failed to load image",
                    is_error=True
                )

            providers = self.dispatcher.providers
            if not providers:
                return ToolResult(
                    success=False,
                    content="",
                    error="No LLM providers available for image analysis",
                    is_error=True
                )

            provider_name = next(iter(providers.keys()))
            provider = providers[provider_name]

            messages = [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": prompt
                        },
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": image_b64
                            }
                        }
                    ]
                }
            ]

            response = await provider.complete(
                messages=messages,
                system="You are an AI assistant that analyzes images. Provide detailed, accurate descriptions.",
                max_tokens=2048,
                temperature=0.3
            )

            result_content = f"Image Analysis ({image_source}):\n\n{response.content}"

            return ToolResult(
                success=True,
                content=result_content
            )

        except Exception as e:
            logger.exception("Error in image analysis")
            return ToolResult(
                success=False,
                content="",
                error=f"Image analysis failed: {e}",
                is_error=True
            )

    async def _load_local_image(self, image_path: str) -> tuple[str, str]:
        """Load local image file and return (base64, media_type)."""
        try:
            path = Path(image_path).resolve()
            if not path.exists():
                raise FileNotFoundError(f"Image file not found: {image_path}")

            if not path.is_file():
                raise ValueError(f"Path is not a file: {image_path}")

            image_data = path.read_bytes()
            media_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            return base64.b64encode(image_data).decode("utf-8"), media_type

        except Exception as e:
            logger.error("Failed to load local image %s: %s", image_path, e)
            raise

    async def _fetch_remote_image(self, image_url: str) -> tuple[str, str]:
        """Fetch remote image and return (base64, media_type)."""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(image_url, timeout=30.0)
                response.raise_for_status()

                image_data = response.content
                media_type = response.headers.get("content-type", "").split(";", 1)[0].strip() or "application/octet-stream"
                return base64.b64encode(image_data).decode("utf-8"), media_type

        except Exception as e:
            logger.error("Failed to fetch remote image %s: %s", image_url, e)
            raise
