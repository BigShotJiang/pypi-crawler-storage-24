from __future__ import annotations

import asyncio
import json
import os
import shlex
import shutil
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .base import NativeTool, ToolResult


DEFAULT_GOG_ACCOUNT = os.environ.get("GOG_ACCOUNT", "")


class GogCommandError(RuntimeError):
    pass


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _coerce_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"1", "true", "yes", "y", "on", "send", "draft", "confirm", "confirmed"}:
            return True
        if lowered in {"0", "false", "no", "n", "off"}:
            return False
    return default


class GogRunner:
    def __init__(self, account: Optional[str] = None, bin_path: str = "gog"):
        self.account = account or DEFAULT_GOG_ACCOUNT
        self.bin_path = bin_path

    def is_available(self) -> bool:
        return shutil.which(self.bin_path) is not None

    async def run_json(self, args: List[str]) -> Any:
        data = await self._run(args + ["--json", "--no-input"])
        try:
            return json.loads(data)
        except json.JSONDecodeError as e:
            raise GogCommandError(f"Failed to parse gog JSON output: {e}\nOutput: {data[:500]}") from e

    async def run_text(self, args: List[str]) -> str:
        return await self._run(args + ["--no-input"])

    async def _run(self, args: List[str]) -> str:
        if not self.is_available():
            raise GogCommandError("`gog` CLI is not installed or not on PATH.")

        cmd = [self.bin_path]
        if self.account:
            cmd.extend(["--account", self.account])
        cmd.extend(args)

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        out = stdout.decode("utf-8", errors="replace").strip()
        err = stderr.decode("utf-8", errors="replace").strip()
        if proc.returncode != 0:
            raise GogCommandError(err or out or f"gog exited with code {proc.returncode}")
        return out


class GogNativeTool(NativeTool):
    service_label = "Google Workspace"

    def __init__(self, runner: GogRunner):
        self._runner = runner

    def _availability_error(self) -> ToolResult:
        return ToolResult(
            success=False,
            content="",
            error="Google Workspace is not available: `gog` CLI missing or not configured.",
            is_error=True,
        )

    def _wrap_error(self, e: Exception) -> ToolResult:
        return ToolResult(success=False, content="", error=str(e), is_error=True)


class GmailSearchGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "gmail_search"

    @property
    def description(self) -> str:
        return "Search Gmail messages with Gmail query syntax and return a clean summary."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Gmail search query, e.g. from:alice newer_than:7d"},
                "max_results": {"type": "integer", "default": 10},
            },
            "required": ["query"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()
        query = arguments.get("query", "").strip()
        if not query:
            return ToolResult(False, "", "Missing required parameter: query", True)
        max_results = int(arguments.get("max_results", 10))
        try:
            data = await self._runner.run_json([
                "gmail", "messages", "search", query, "--max", str(max_results)
            ])
            items = data if isinstance(data, list) else data.get("messages", []) if isinstance(data, dict) else []
            if not items:
                return ToolResult(True, f"No Gmail messages found for query: {query}")
            lines = []
            for item in items[:max_results]:
                lines.append(
                    "\n".join([
                        f"ID: {item.get('id', '?')}",
                        f"Thread: {item.get('threadId', '?')}",
                        f"From: {item.get('from', item.get('sender', '?'))}",
                        f"Subject: {item.get('subject', '(no subject)')}",
                        f"Date: {item.get('date', item.get('internalDate', '?'))}",
                        f"Snippet: {item.get('snippet', '')}",
                    ])
                )
            return ToolResult(True, "\n----------------------------------------\n".join(lines))
        except Exception as e:
            return self._wrap_error(e)


class GmailReadGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "gmail_read"

    @property
    def description(self) -> str:
        return "Read a Gmail message by message ID."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "message_id": {"type": "string", "description": "Gmail message ID"},
            },
            "required": ["message_id"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()
        message_id = arguments.get("message_id", "").strip()
        if not message_id:
            return ToolResult(False, "", "Missing required parameter: message_id", True)
        try:
            content = await self._runner.run_text(["gmail", "messages", "cat", message_id])
            return ToolResult(True, content or "(empty message)")
        except Exception as e:
            return self._wrap_error(e)


class GmailSendGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "gmail_send"

    @property
    def description(self) -> str:
        return (
            "Compose a Gmail message with draft-first semantics by default. "
            "Use send=true or mode='send' to send immediately; otherwise a command preview is returned so a draft can be created intentionally."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "to": {"type": "string", "description": "Primary recipient email address(es)."},
                "subject": {"type": "string", "description": "Email subject line."},
                "body": {"type": "string", "description": "Plain-text email body."},
                "cc": {"type": "string", "description": "Optional CC recipient(s)."},
                "bcc": {"type": "string", "description": "Optional BCC recipient(s)."},
                "mode": {
                    "type": "string",
                    "enum": ["draft", "send"],
                    "description": "Workflow mode. Defaults to draft-first if omitted.",
                },
                "send": {
                    "type": "boolean",
                    "description": "If true, send immediately. If false or omitted, stay in draft-first mode.",
                },
                "confirm_send": {
                    "type": "boolean",
                    "description": "Explicit confirmation for immediate send. Recommended whenever send=true.",
                },
            },
            "required": ["to", "subject", "body"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()

        to = arguments.get("to", "").strip()
        subject = arguments.get("subject", "").strip()
        body = arguments.get("body", "")
        cc = arguments.get("cc", "").strip()
        bcc = arguments.get("bcc", "").strip()
        if not to or not subject:
            return ToolResult(False, "", "Missing required parameters: to and subject", True)

        mode = str(arguments.get("mode", "") or "").strip().lower()
        send_requested = _coerce_bool(arguments.get("send"), default=False) or mode == "send"
        confirm_send = _coerce_bool(arguments.get("confirm_send"), default=False)

        cli_args = ["gmail", "send", "--to", to, "--subject", subject, "--body-file", "-"]
        if cc:
            cli_args.extend(["--cc", cc])
        if bcc:
            cli_args.extend(["--bcc", bcc])

        cmd_preview = [self._runner.bin_path]
        if self._runner.account:
            cmd_preview.extend(["--account", self._runner.account])
        cmd_preview.extend(cli_args)
        preview = " ".join(shlex.quote(part) for part in cmd_preview)

        if not send_requested:
            lines = [
                "Draft-first mode selected. No email was sent.",
                f"To: {to}",
                f"Subject: {subject}",
            ]
            if cc:
                lines.append(f"CC: {cc}")
            if bcc:
                lines.append(f"BCC: {bcc}")
            lines.extend([
                f"Body length: {len(body)} chars",
                "",
                "Suggested next step:",
                "- Create/save this as a Gmail draft in the chat UX layer, or",
                "- Re-run with send=true and confirm_send=true for an immediate send.",
                "",
                f"Underlying gog command preview: {preview}",
            ])
            return ToolResult(True, "\n".join(lines))

        if not confirm_send:
            return ToolResult(
                True,
                "\n".join([
                    "Immediate send requested but not confirmed.",
                    "No email was sent.",
                    "Re-run with send=true and confirm_send=true to send now.",
                    f"Underlying gog command preview: {preview}",
                ]),
            )

        try:
            cmd = [self._runner.bin_path]
            if self._runner.account:
                cmd.extend(["--account", self._runner.account])
            cmd.extend(cli_args)
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate(body.encode("utf-8"))
            out = stdout.decode("utf-8", errors="replace").strip()
            err = stderr.decode("utf-8", errors="replace").strip()
            if proc.returncode != 0:
                raise GogCommandError(err or out or f"gog exited with code {proc.returncode}")
            return ToolResult(True, out or "Email sent immediately.")
        except Exception as e:
            return self._wrap_error(e)


class GmailDraftGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "gmail_draft"

    @property
    def description(self) -> str:
        return "Prepare a Gmail draft preview with the exact content that would be sent. This is a safe assistant-facing draft-first wrapper."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "to": {"type": "string"},
                "subject": {"type": "string"},
                "body": {"type": "string"},
                "cc": {"type": "string"},
                "bcc": {"type": "string"},
            },
            "required": ["to", "subject", "body"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()
        draft_args = dict(arguments)
        draft_args["mode"] = "draft"
        draft_args["send"] = False
        return await GmailSendGogTool(self._runner).execute(draft_args)


class CalendarListEventsGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "calendar_list_events"

    @property
    def description(self) -> str:
        return "List Google Calendar events in a time range."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "calendar_id": {"type": "string", "default": "primary"},
                "time_min": {"type": "string", "description": "ISO8601 start time"},
                "time_max": {"type": "string", "description": "ISO8601 end time"},
            },
            "required": ["time_min", "time_max"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()
        calendar_id = arguments.get("calendar_id", "primary")
        time_min = arguments.get("time_min", "").strip()
        time_max = arguments.get("time_max", "").strip()
        if not time_min or not time_max:
            return ToolResult(False, "", "Missing required parameters: time_min and time_max", True)
        try:
            data = await self._runner.run_json([
                "calendar", "events", calendar_id, "--from", time_min, "--to", time_max
            ])
            items = data if isinstance(data, list) else data.get("events", []) if isinstance(data, dict) else []
            if not items:
                return ToolResult(True, "No calendar events found.")
            lines = []
            for item in items:
                lines.append(
                    "\n".join([
                        f"ID: {item.get('id', '?')}",
                        f"Title: {item.get('summary', '(no title)')}",
                        f"Start: {item.get('start', {}).get('dateTime', item.get('start', {}).get('date', '?')) if isinstance(item.get('start'), dict) else item.get('start', '?')}",
                        f"End: {item.get('end', {}).get('dateTime', item.get('end', {}).get('date', '?')) if isinstance(item.get('end'), dict) else item.get('end', '?')}",
                        f"Location: {item.get('location', '')}",
                        f"Link: {item.get('htmlLink', '')}",
                    ])
                )
            return ToolResult(True, "\n----------------------------------------\n".join(lines))
        except Exception as e:
            return self._wrap_error(e)


class CalendarCreateEventGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "calendar_create_event"

    @property
    def description(self) -> str:
        return (
            "Create a Google Calendar event only after explicit confirmation. "
            "Without confirmed=true, this tool returns a safe preview instead of writing."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "calendar_id": {"type": "string", "default": "primary"},
                "title": {"type": "string"},
                "start": {"type": "string"},
                "end": {"type": "string"},
                "description": {"type": "string"},
                "location": {"type": "string"},
                "confirmed": {
                    "type": "boolean",
                    "description": "Must be true to actually create the event.",
                },
            },
            "required": ["title", "start", "end"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()
        calendar_id = arguments.get("calendar_id", "primary")
        title = arguments.get("title", "").strip()
        start = arguments.get("start", "").strip()
        end = arguments.get("end", "").strip()
        description = arguments.get("description", "").strip()
        location = arguments.get("location", "").strip()
        confirmed = _coerce_bool(arguments.get("confirmed"), default=False)
        if not title or not start or not end:
            return ToolResult(False, "", "Missing required parameters: title, start, end", True)

        cli_args = [
            "calendar", "create", calendar_id,
            "--summary", title,
            "--from", start,
            "--to", end,
        ]
        if description:
            cli_args.extend(["--description", description])
        if location:
            cli_args.extend(["--location", location])

        cmd_preview = [self._runner.bin_path]
        if self._runner.account:
            cmd_preview.extend(["--account", self._runner.account])
        cmd_preview.extend(cli_args)
        preview = " ".join(shlex.quote(part) for part in cmd_preview)

        if not confirmed:
            lines = [
                "Calendar write requires explicit confirmation. No event was created.",
                f"Calendar: {calendar_id}",
                f"Title: {title}",
                f"Start: {start}",
                f"End: {end}",
            ]
            if location:
                lines.append(f"Location: {location}")
            if description:
                lines.append(f"Description: {description}")
            lines.extend([
                "",
                "Re-run with confirmed=true to create this event.",
                f"Underlying gog command preview: {preview}",
            ])
            return ToolResult(True, "\n".join(lines))

        try:
            out = await self._runner.run_text(cli_args)
            return ToolResult(True, out or "Calendar event created.")
        except Exception as e:
            return self._wrap_error(e)


class DriveSearchGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "drive_search"

    @property
    def description(self) -> str:
        return "Search Google Drive files."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "max_results": {"type": "integer", "default": 10},
            },
            "required": ["query"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()
        query = arguments.get("query", "").strip()
        if not query:
            return ToolResult(False, "", "Missing required parameter: query", True)
        max_results = int(arguments.get("max_results", 10))
        try:
            data = await self._runner.run_json(["drive", "search", query, "--max", str(max_results)])
            items = data if isinstance(data, list) else data.get("files", []) if isinstance(data, dict) else []
            if not items:
                return ToolResult(True, f"No Drive files found for query: {query}")
            lines = []
            for item in items:
                lines.append(
                    "\n".join([
                        f"Name: {item.get('name', '?')}",
                        f"ID: {item.get('id', '?')}",
                        f"Type: {item.get('mimeType', '?')}",
                        f"Modified: {item.get('modifiedTime', '?')}",
                        f"Link: {item.get('webViewLink', item.get('webUrl', ''))}",
                    ])
                )
            return ToolResult(True, "\n----------------------------------------\n".join(lines))
        except Exception as e:
            return self._wrap_error(e)


class DriveReadGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "drive_read"

    @property
    def description(self) -> str:
        return "Read a Google Drive file or export Google Docs/Sheets-compatible text."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "file_id": {"type": "string"},
            },
            "required": ["file_id"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()
        file_id = arguments.get("file_id", "").strip()
        if not file_id:
            return ToolResult(False, "", "Missing required parameter: file_id", True)
        try:
            content = await self._runner.run_text(["docs", "cat", file_id])
            return ToolResult(True, content or "(empty file)")
        except Exception as docs_err:
            try:
                content = await self._runner.run_text(["drive", "cat", file_id])
                return ToolResult(True, content or "(empty file)")
            except Exception:
                return self._wrap_error(docs_err)


class DocsCreateGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "docs_create"

    @property
    def description(self) -> str:
        return "Create a Google Doc, optionally seeded with initial content."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["title"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()
        title = arguments.get("title", "").strip()
        content = arguments.get("content", "")
        if not title:
            return ToolResult(False, "", "Missing required parameter: title", True)
        try:
            out = await self._runner.run_text(["docs", "create", "--title", title, "--body", content])
            return ToolResult(True, out or "Document created.")
        except Exception as e:
            return self._wrap_error(e)


class SheetsReadGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "sheets_read"

    @property
    def description(self) -> str:
        return "Read a range from Google Sheets."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "spreadsheet_id": {"type": "string"},
                "range": {"type": "string"},
            },
            "required": ["spreadsheet_id", "range"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()
        spreadsheet_id = arguments.get("spreadsheet_id", "").strip()
        range_ = arguments.get("range", "").strip()
        if not spreadsheet_id or not range_:
            return ToolResult(False, "", "Missing required parameters: spreadsheet_id and range", True)
        try:
            data = await self._runner.run_json(["sheets", "get", spreadsheet_id, range_])
            return ToolResult(True, json.dumps(data, indent=2))
        except Exception as e:
            return self._wrap_error(e)


class SheetsAppendGogTool(GogNativeTool):
    @property
    def name(self) -> str:
        return "sheets_append"

    @property
    def description(self) -> str:
        return "Append rows to Google Sheets."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "spreadsheet_id": {"type": "string"},
                "range": {"type": "string", "description": "Target range like Sheet1!A:C"},
                "values": {
                    "type": "array",
                    "items": {"type": "array", "items": {"type": ["string", "number", "boolean", "null"]}},
                },
            },
            "required": ["spreadsheet_id", "range", "values"],
        }

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        if not self._runner.is_available():
            return self._availability_error()
        spreadsheet_id = arguments.get("spreadsheet_id", "").strip()
        range_ = arguments.get("range", "").strip()
        values = arguments.get("values")
        if not spreadsheet_id or not range_ or values is None:
            return ToolResult(False, "", "Missing required parameters: spreadsheet_id, range, values", True)
        try:
            out = await self._runner.run_text([
                "sheets", "append", spreadsheet_id, range_, "--values-json", json.dumps(values)
            ])
            return ToolResult(True, out or "Rows appended.")
        except Exception as e:
            return self._wrap_error(e)
