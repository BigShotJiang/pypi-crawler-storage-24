from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Optional, Set
from urllib.parse import urlparse

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)

# Default URL blocklist — prevents the browser from accessing sensitive endpoints
# when security_mode is not "open". Operators can override via config.
DEFAULT_BLOCKED_PATTERNS: Set[str] = {
    "localhost",
    "127.0.0.1",
    "0.0.0.0",
    "169.254.169.254",    # Cloud metadata endpoint (AWS/GCP/Azure)
    "[::1]",              # IPv6 loopback
    "metadata.google",    # GCP metadata
}


class BrowserTool(NativeTool):
    """Browser automation using Playwright.
    
    Security defaults:
      - headless=True (no visible browser window by default)
      - URL blocklist prevents access to cloud metadata and localhost
      - Screenshots saved only to workspace directory
      - Page content truncated to prevent token flooding
    """
    
    def __init__(
        self,
        headless: bool = True,
        workspace_path: str = "/tmp",
        allowed_domains: Optional[list[str]] = None,
        blocked_patterns: Optional[Set[str]] = None,
        max_content_length: int = 8000,
    ):
        self.headless = headless
        self.workspace_path = Path(workspace_path)
        self.allowed_domains = allowed_domains  # None = allow all (minus blocklist)
        self.blocked_patterns = blocked_patterns or DEFAULT_BLOCKED_PATTERNS
        self.max_content_length = max_content_length
        self.browser = None
        self.page = None
        self._playwright = None

    @property
    def name(self) -> str:
        return "browser"

    @property
    def description(self) -> str:
        return (
            "Browser automation using Playwright. Navigate to URLs, take screenshots, "
            "click elements, type text, extract text, evaluate JS, and wait for elements."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Browser action to perform",
                    "enum": [
                        "navigate", "screenshot", "click", "type", "get_text",
                        "evaluate", "wait_for", "go_back", "go_forward", "reload",
                        "get_url", "scroll",
                    ]
                },
                "url": {
                    "type": "string",
                    "description": "URL to navigate to (required for navigate action)"
                },
                "selector": {
                    "type": "string",
                    "description": "CSS selector (required for click, type, get_text, wait_for actions)"
                },
                "text": {
                    "type": "string",
                    "description": "Text to type (required for type action)"
                },
                "expression": {
                    "type": "string",
                    "description": "JavaScript expression to evaluate (for evaluate action)"
                },
                "direction": {
                    "type": "string",
                    "enum": ["up", "down"],
                    "description": "Scroll direction (for scroll action, default: down)"
                },
                "amount": {
                    "type": "integer",
                    "description": "Scroll amount in pixels (for scroll action, default: 500)"
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in milliseconds (optional, default 10000)",
                    "default": 10000,
                    "minimum": 1000,
                    "maximum": 60000
                }
            },
            "required": ["action"]
        }

    async def _ensure_browser(self) -> tuple[bool, str]:
        """Ensure browser is initialized. Returns (success, error_message)."""
        if self.browser and self.page:
            return True, ""

        try:
            # Lazy import playwright
            from playwright.async_api import async_playwright
            
            if not self._playwright:
                self._playwright = await async_playwright().__aenter__()
            
            if not self.browser:
                self.browser = await self._playwright.chromium.launch(headless=self.headless)
            
            if not self.page:
                self.page = await self.browser.new_page()
            
            return True, ""

        except ImportError:
            return False, "Browser tool requires playwright. Install with: pip install playwright && playwright install chromium"
        except Exception as e:
            logger.exception("Failed to initialize browser")
            return False, f"Failed to initialize browser: {e}"

    async def _cleanup(self):
        """Clean up browser resources."""
        try:
            if self.page:
                await self.page.close()
                self.page = None
            
            if self.browser:
                await self.browser.close()
                self.browser = None
            
            if self._playwright:
                await self._playwright.__aexit__(None, None, None)
                self._playwright = None
        except Exception as e:
            logger.exception("Error during browser cleanup")

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._cleanup()

    def _check_url_security(self, url: str) -> Optional[str]:
        """Check if a URL is allowed. Returns error message if blocked, None if OK."""
        try:
            parsed = urlparse(url)
            hostname = parsed.hostname or ""
            
            # Block non-http(s) schemes
            if parsed.scheme not in ("http", "https", ""):
                return f"URL scheme '{parsed.scheme}' is not allowed. Only http/https are permitted."
            
            # Check blocklist
            for pattern in self.blocked_patterns:
                if pattern in hostname:
                    return f"URL blocked: {hostname} matches security blocklist pattern '{pattern}'"
            
            # Check allowlist if configured
            if self.allowed_domains is not None:
                if not any(hostname.endswith(d) for d in self.allowed_domains):
                    return f"URL blocked: {hostname} is not in the allowed domains list"
            
            return None
        except Exception as e:
            return f"URL validation failed: {e}"

    async def execute(self, arguments: dict) -> ToolResult:
        action = arguments.get("action")
        url = arguments.get("url")
        selector = arguments.get("selector")
        text = arguments.get("text")
        expression = arguments.get("expression")
        timeout = arguments.get("timeout", 10000)

        if not action:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: action",
                is_error=True
            )

        # Ensure browser is initialized
        success, error = await self._ensure_browser()
        if not success:
            return ToolResult(
                success=False,
                content="",
                error=error,
                is_error=True
            )

        try:
            if action == "navigate":
                if not url:
                    return ToolResult(
                        success=False, content="",
                        error="Navigate action requires url parameter", is_error=True
                    )
                # Security check
                sec_error = self._check_url_security(url)
                if sec_error:
                    return ToolResult(success=False, content="", error=sec_error, is_error=True)
                return await self._navigate(url, timeout)

            elif action == "screenshot":
                return await self._screenshot()

            elif action == "click":
                if not selector:
                    return ToolResult(
                        success=False, content="",
                        error="Click action requires selector parameter", is_error=True
                    )
                return await self._click(selector, timeout)

            elif action == "type":
                if not selector or text is None:
                    return ToolResult(
                        success=False, content="",
                        error="Type action requires selector and text parameters", is_error=True
                    )
                return await self._type(selector, text, timeout)

            elif action == "get_text":
                if not selector:
                    return ToolResult(
                        success=False, content="",
                        error="get_text action requires selector parameter", is_error=True
                    )
                return await self._get_text(selector, timeout)

            elif action == "evaluate":
                if not expression:
                    return ToolResult(
                        success=False, content="",
                        error="evaluate action requires expression parameter", is_error=True
                    )
                return await self._evaluate(expression)

            elif action == "wait_for":
                if not selector:
                    return ToolResult(
                        success=False, content="",
                        error="wait_for action requires selector parameter", is_error=True
                    )
                return await self._wait_for(selector, timeout)

            elif action == "go_back":
                return await self._go_back(timeout)

            elif action == "go_forward":
                return await self._go_forward(timeout)

            elif action == "reload":
                return await self._reload(timeout)

            elif action == "get_url":
                return await self._get_url()

            elif action == "scroll":
                direction = arguments.get("direction", "down")
                amount = arguments.get("amount", 500)
                return await self._scroll(direction, amount)

            else:
                return ToolResult(
                    success=False, content="",
                    error=f"Unknown action: {action}", is_error=True
                )

        except Exception as e:
            logger.exception("Unexpected error in browser action")
            return ToolResult(
                success=False, content="",
                error=f"Unexpected error: {e}", is_error=True
            )

    async def _navigate(self, url: str, timeout: int) -> ToolResult:
        """Navigate to URL and return page title and text content."""
        try:
            await self.page.goto(url, timeout=timeout)
            title = await self.page.title()
            
            # Get text content (capped to max_content_length)
            text_content = await self.page.inner_text('body')
            if len(text_content) > self.max_content_length:
                text_content = text_content[:self.max_content_length] + "\n\n[Content truncated...]"
            
            current_url = self.page.url
            content = f"Title: {title}\nURL: {current_url}\n\nPage content:\n{text_content}"
            
            return ToolResult(
                success=True,
                content=content
            )

        except Exception as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Navigation failed: {e}",
                is_error=True
            )

    async def _screenshot(self) -> ToolResult:
        """Take a screenshot and save to workspace."""
        try:
            timestamp = int(time.time())
            screenshot_dir = self.workspace_path / "screenshots"
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            screenshot_path = str(screenshot_dir / f"screenshot_{timestamp}.png")
            await self.page.screenshot(path=screenshot_path)
            return ToolResult(success=True, content=f"Screenshot saved to: {screenshot_path}")
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Screenshot failed: {e}", is_error=True)

    async def _click(self, selector: str, timeout: int) -> ToolResult:
        """Click on element by CSS selector."""
        try:
            await self.page.click(selector, timeout=timeout)
            
            return ToolResult(
                success=True,
                content=f"Successfully clicked element: {selector}"
            )

        except Exception as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Click failed: {e}",
                is_error=True
            )

    async def _type(self, selector: str, text: str, timeout: int) -> ToolResult:
        """Type text into element by CSS selector."""
        try:
            await self.page.fill(selector, text, timeout=timeout)
            
            return ToolResult(
                success=True,
                content=f"Successfully typed text into element: {selector}"
            )

        except Exception as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Type failed: {e}",
                is_error=True
            )

    async def _get_text(self, selector: str, timeout: int) -> ToolResult:
        """Get text content from element by CSS selector."""
        try:
            element = await self.page.wait_for_selector(selector, timeout=timeout)
            if not element:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Element not found: {selector}",
                    is_error=True
                )
            
            text_content = await element.inner_text()
            
            return ToolResult(
                success=True,
                content=text_content
            )

        except Exception as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Get text failed: {e}",
                is_error=True
            )

    async def _evaluate(self, expression: str) -> ToolResult:
        """Evaluate JavaScript in the page context."""
        try:
            result = await self.page.evaluate(expression)
            content = str(result)
            if len(content) > self.max_content_length:
                content = content[:self.max_content_length] + "\n\n[Output truncated...]"
            return ToolResult(success=True, content=content)
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Evaluate failed: {e}", is_error=True)

    async def _wait_for(self, selector: str, timeout: int) -> ToolResult:
        """Wait for an element to appear on the page."""
        try:
            element = await self.page.wait_for_selector(selector, timeout=timeout)
            if element:
                tag = await element.evaluate("el => el.tagName.toLowerCase()")
                text = await element.inner_text()
                text_preview = text[:200] if text else "(empty)"
                return ToolResult(
                    success=True,
                    content=f"Element found: <{tag}> — {text_preview}"
                )
            return ToolResult(success=False, content="", error=f"Element not found: {selector}", is_error=True)
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Wait failed: {e}", is_error=True)

    async def _go_back(self, timeout: int) -> ToolResult:
        """Navigate back in browser history."""
        try:
            await self.page.go_back(timeout=timeout)
            title = await self.page.title()
            return ToolResult(success=True, content=f"Navigated back. Current page: {title}")
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Go back failed: {e}", is_error=True)

    async def _go_forward(self, timeout: int) -> ToolResult:
        """Navigate forward in browser history."""
        try:
            await self.page.go_forward(timeout=timeout)
            title = await self.page.title()
            return ToolResult(success=True, content=f"Navigated forward. Current page: {title}")
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Go forward failed: {e}", is_error=True)

    async def _reload(self, timeout: int) -> ToolResult:
        """Reload the current page."""
        try:
            await self.page.reload(timeout=timeout)
            title = await self.page.title()
            return ToolResult(success=True, content=f"Page reloaded. Title: {title}")
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Reload failed: {e}", is_error=True)

    async def _get_url(self) -> ToolResult:
        """Get the current page URL."""
        try:
            url = self.page.url
            title = await self.page.title()
            return ToolResult(success=True, content=f"URL: {url}\nTitle: {title}")
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Get URL failed: {e}", is_error=True)

    async def _scroll(self, direction: str, amount: int) -> ToolResult:
        """Scroll the page up or down."""
        try:
            scroll_amount = amount if direction == "down" else -amount
            await self.page.evaluate(f"window.scrollBy(0, {scroll_amount})")
            scroll_y = await self.page.evaluate("window.scrollY")
            page_height = await self.page.evaluate("document.body.scrollHeight")
            return ToolResult(
                success=True,
                content=f"Scrolled {direction} by {amount}px. Position: {int(scroll_y)}/{int(page_height)}px"
            )
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Scroll failed: {e}", is_error=True)

    def __del__(self):
        """Cleanup when object is destroyed."""
        # Note: We can't use async cleanup in __del__, so this is best effort
        if self.browser or self.page or self._playwright:
            logger.warning("Browser tool destroyed without proper cleanup. Call _cleanup() before destroying.")