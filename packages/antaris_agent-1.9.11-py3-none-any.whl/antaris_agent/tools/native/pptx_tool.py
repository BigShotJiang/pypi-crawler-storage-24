"""PowerPoint deck tool — read, summarize, extract, and rewrite slides.

Provides a first-class NativeTool for PowerPoint (.pptx) operations:
  - **read**: Full text extraction from a deck
  - **structure**: Deck structure map (slide titles, types, word counts)
  - **slide**: Extract text from a specific slide
  - **summarize**: Human-readable deck summary
  - **notes**: Extract speaker notes from all slides
  - **rewrite_notes**: Replace speaker notes on a specific slide
  - **export_outline**: Export deck as a markdown outline
  - **slide_text_replace**: Find-and-replace text on a specific slide

Dependencies: python-pptx (optional — graceful error if missing)
"""

from __future__ import annotations

import logging
import os
import re
from importlib import import_module
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


def _get_pptx_ingester_class():
    """Import PPTXIngester from the bundled runtime path, with shim fallback."""
    for module_name in ("parsica_memory.ingest_pptx",):
        try:
            module = import_module(module_name)
            return getattr(module, "PPTXIngester")
        except (ImportError, AttributeError):
            continue
    raise ImportError("PPTXIngester not available from bundled parsica_memory or compatibility shim")


class PowerPointTool(NativeTool):
    """Native tool for PowerPoint deck operations."""

    def __init__(self, workspace_path: str = ""):
        self.workspace_path = Path(workspace_path).resolve() if workspace_path else Path.cwd()

    @property
    def name(self) -> str:
        return "powerpoint"

    @property
    def description(self) -> str:
        return (
            "Read, summarize, and edit PowerPoint (.pptx) decks. "
            "Operations: read (full text), structure (deck map), slide (single slide text), "
            "summarize (overview), notes (speaker notes), rewrite_notes (replace notes), "
            "export_outline (markdown outline), slide_text_replace (find-replace on slide)."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "description": "Operation to perform on the deck",
                    "enum": [
                        "read",
                        "structure",
                        "slide",
                        "summarize",
                        "notes",
                        "rewrite_notes",
                        "export_outline",
                        "slide_text_replace",
                    ],
                },
                "path": {
                    "type": "string",
                    "description": "Path to the .pptx file (absolute or relative to workspace)",
                },
                "slide_number": {
                    "type": "integer",
                    "description": "Slide number (1-indexed) for single-slide operations",
                    "minimum": 1,
                },
                "notes_text": {
                    "type": "string",
                    "description": "New speaker notes text (for rewrite_notes operation)",
                },
                "old_text": {
                    "type": "string",
                    "description": "Text to find (for slide_text_replace operation)",
                },
                "new_text": {
                    "type": "string",
                    "description": "Replacement text (for slide_text_replace operation)",
                },
            },
            "required": ["operation", "path"],
        }

    def _resolve_path(self, path_str: str) -> Path:
        """Resolve path relative to workspace if not absolute."""
        p = Path(path_str)
        if p.is_absolute():
            return p.resolve()
        return (self.workspace_path / p).resolve()

    async def execute(self, arguments: dict) -> ToolResult:
        operation = arguments.get("operation")
        path_str = arguments.get("path")

        if not operation or not path_str:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameters: operation and path",
                is_error=True,
            )

        target_path = self._resolve_path(path_str)

        # Check python-pptx availability
        try:
            import pptx  # noqa: F401
        except ImportError:
            return ToolResult(
                success=False,
                content="",
                error="python-pptx not installed. Run: pip install python-pptx",
                is_error=True,
            )

        # For write operations, the file must exist
        if operation not in ("read", "structure", "slide", "summarize", "notes", "export_outline"):
            if not target_path.exists():
                return ToolResult(
                    success=False,
                    content="",
                    error=f"File not found: {target_path}",
                    is_error=True,
                )

        try:
            if operation == "read":
                return await self._read(target_path)
            elif operation == "structure":
                return await self._structure(target_path)
            elif operation == "slide":
                slide_num = arguments.get("slide_number")
                if not slide_num:
                    return ToolResult(
                        success=False,
                        content="",
                        error="slide_number is required for 'slide' operation",
                        is_error=True,
                    )
                return await self._slide(target_path, slide_num)
            elif operation == "summarize":
                return await self._summarize(target_path)
            elif operation == "notes":
                return await self._notes(target_path)
            elif operation == "rewrite_notes":
                slide_num = arguments.get("slide_number")
                notes_text = arguments.get("notes_text")
                if not slide_num or notes_text is None:
                    return ToolResult(
                        success=False,
                        content="",
                        error="slide_number and notes_text are required for 'rewrite_notes'",
                        is_error=True,
                    )
                return await self._rewrite_notes(target_path, slide_num, notes_text)
            elif operation == "export_outline":
                return await self._export_outline(target_path)
            elif operation == "slide_text_replace":
                slide_num = arguments.get("slide_number")
                old_text = arguments.get("old_text")
                new_text = arguments.get("new_text")
                if not slide_num or old_text is None or new_text is None:
                    return ToolResult(
                        success=False,
                        content="",
                        error="slide_number, old_text, and new_text are required for 'slide_text_replace'",
                        is_error=True,
                    )
                return await self._slide_text_replace(target_path, slide_num, old_text, new_text)
            else:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Unknown operation: {operation}",
                    is_error=True,
                )

        except Exception as e:
            logger.exception("PowerPoint tool error")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True,
            )

    async def _read(self, path: Path) -> ToolResult:
        """Full text extraction from the deck."""
        PPTXIngester = _get_pptx_ingester_class()
        ingester = PPTXIngester()
        result = ingester.ingest(str(path))

        if result.errors and not result.slides:
            return ToolResult(
                success=False,
                content="",
                error="; ".join(result.errors),
                is_error=True,
            )

        content = result.full_text
        if not content.strip():
            content = "(No text content found in deck)"

        # Prepend summary header
        header = result.summary()
        output = f"{header}\n\n---\n\n{content}"

        return ToolResult(success=True, content=output)

    async def _structure(self, path: Path) -> ToolResult:
        """Return the deck structure map."""
        PPTXIngester = _get_pptx_ingester_class()
        ingester = PPTXIngester()
        result = ingester.ingest(str(path))

        if result.errors and not result.slides:
            return ToolResult(
                success=False,
                content="",
                error="; ".join(result.errors),
                is_error=True,
            )

        structure = result.structure()
        lines = [f"Deck: {Path(path).name} ({result.slide_count} slides)\n"]

        for info in structure:
            flags = []
            if info.get("has_images"):
                flags.append("📷")
            if info.get("has_tables"):
                flags.append("📊")
            if info.get("has_charts"):
                flags.append("📈")
            if info.get("has_notes"):
                flags.append("📝")

            flag_str = " ".join(flags)
            title = info["title"]
            line = f"  Slide {info['slide']:2d}: {title}"
            if flag_str:
                line += f"  {flag_str}"
            line += f"  [{info['layout']}] ({info['word_count']} words)"
            lines.append(line)

        return ToolResult(success=True, content="\n".join(lines))

    async def _slide(self, path: Path, slide_number: int) -> ToolResult:
        """Extract text from a specific slide."""
        PPTXIngester = _get_pptx_ingester_class()
        ingester = PPTXIngester()
        result = ingester.ingest(str(path), slides=[slide_number])

        text = result.slide_text(slide_number)
        if text is None:
            return ToolResult(
                success=False,
                content="",
                error=f"Slide {slide_number} not found (deck has {result.metadata.slide_count} slides)",
                is_error=True,
            )

        return ToolResult(success=True, content=text)

    async def _summarize(self, path: Path) -> ToolResult:
        """Human-readable deck summary."""
        PPTXIngester = _get_pptx_ingester_class()
        ingester = PPTXIngester()
        result = ingester.ingest(str(path))

        if result.errors and not result.slides:
            return ToolResult(
                success=False,
                content="",
                error="; ".join(result.errors),
                is_error=True,
            )

        return ToolResult(success=True, content=result.summary())

    async def _notes(self, path: Path) -> ToolResult:
        """Extract all speaker notes."""
        PPTXIngester = _get_pptx_ingester_class()
        ingester = PPTXIngester(include_notes=True)
        result = ingester.ingest(str(path))

        if result.errors and not result.slides:
            return ToolResult(
                success=False,
                content="",
                error="; ".join(result.errors),
                is_error=True,
            )

        lines = []
        has_any_notes = False
        for slide in result.slides:
            if slide.notes_text:
                has_any_notes = True
                lines.append(f"--- Slide {slide.slide_number}: {slide.title or '(untitled)'} ---")
                lines.append(slide.notes_text)
                lines.append("")

        if not has_any_notes:
            return ToolResult(
                success=True,
                content="No speaker notes found in this deck.",
            )

        return ToolResult(success=True, content="\n".join(lines))

    async def _rewrite_notes(self, path: Path, slide_number: int, notes_text: str) -> ToolResult:
        """Replace speaker notes on a specific slide."""
        from pptx import Presentation
        from pptx.util import Inches, Pt

        if not path.exists():
            return ToolResult(
                success=False,
                content="",
                error=f"File not found: {path}",
                is_error=True,
            )

        prs = Presentation(str(path))

        if slide_number < 1 or slide_number > len(prs.slides):
            return ToolResult(
                success=False,
                content="",
                error=f"Slide {slide_number} out of range (deck has {len(prs.slides)} slides)",
                is_error=True,
            )

        slide = prs.slides[slide_number - 1]

        # Ensure notes slide exists
        if not slide.has_notes_slide:
            slide.notes_slide  # This creates it if it doesn't exist

        notes_slide = slide.notes_slide
        tf = notes_slide.notes_text_frame

        # Clear existing notes
        tf.clear()

        # Write new notes (split by newlines into paragraphs)
        paragraphs = notes_text.split("\n")
        for i, para_text in enumerate(paragraphs):
            if i == 0:
                tf.paragraphs[0].text = para_text
            else:
                p = tf.add_paragraph()
                p.text = para_text

        prs.save(str(path))

        return ToolResult(
            success=True,
            content=f"Updated speaker notes on slide {slide_number} ({len(notes_text)} chars)",
        )

    async def _export_outline(self, path: Path) -> ToolResult:
        """Export deck as a markdown outline."""
        PPTXIngester = _get_pptx_ingester_class()
        ingester = PPTXIngester(include_notes=True)
        result = ingester.ingest(str(path))

        if result.errors and not result.slides:
            return ToolResult(
                success=False,
                content="",
                error="; ".join(result.errors),
                is_error=True,
            )

        lines = [f"# {result.metadata.title or Path(path).stem}\n"]

        if result.metadata.author:
            lines.append(f"*Author: {result.metadata.author}*\n")

        for slide in result.slides:
            title = slide.title or "(untitled)"
            lines.append(f"## Slide {slide.slide_number}: {title}\n")

            if slide.body_text:
                # Indent body text as bullet points where appropriate
                for para in slide.body_text.split("\n"):
                    para = para.strip()
                    if para:
                        if para.startswith("|"):
                            # Table row — keep as-is
                            lines.append(para)
                        else:
                            lines.append(f"- {para}")
                lines.append("")

            if slide.notes_text:
                lines.append(f"> **Notes:** {slide.notes_text}\n")

        return ToolResult(success=True, content="\n".join(lines))

    async def _slide_text_replace(
        self, path: Path, slide_number: int, old_text: str, new_text: str
    ) -> ToolResult:
        """Find and replace text on a specific slide."""
        from pptx import Presentation

        if not path.exists():
            return ToolResult(
                success=False,
                content="",
                error=f"File not found: {path}",
                is_error=True,
            )

        prs = Presentation(str(path))

        if slide_number < 1 or slide_number > len(prs.slides):
            return ToolResult(
                success=False,
                content="",
                error=f"Slide {slide_number} out of range (deck has {len(prs.slides)} slides)",
                is_error=True,
            )

        slide = prs.slides[slide_number - 1]
        replacements = 0

        for shape in slide.shapes:
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        if old_text in run.text:
                            run.text = run.text.replace(old_text, new_text)
                            replacements += 1

            # Also check tables
            if shape.has_table:
                for row in shape.table.rows:
                    for cell in row.cells:
                        if cell.text_frame:
                            for paragraph in cell.text_frame.paragraphs:
                                for run in paragraph.runs:
                                    if old_text in run.text:
                                        run.text = run.text.replace(old_text, new_text)
                                        replacements += 1

        if replacements == 0:
            return ToolResult(
                success=False,
                content="",
                error=f"Text '{old_text}' not found on slide {slide_number}",
                is_error=True,
            )

        prs.save(str(path))

        return ToolResult(
            success=True,
            content=f"Replaced {replacements} occurrence(s) of '{old_text}' with '{new_text}' on slide {slide_number}",
        )
