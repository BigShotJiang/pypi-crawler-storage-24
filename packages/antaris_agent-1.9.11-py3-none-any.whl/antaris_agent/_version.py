"""Single source of truth for the Antaris package version."""

__version__ = "1.9.11"
