import argparse
import os
import signal
import sys
from pathlib import Path

from antaris_agent._version import __version__ as VERSION


def _resolve_config_dir() -> Path:
    """Resolve the config directory, honoring ANTARIS_CONFIG_DIR env var."""
    env_dir = os.environ.get("ANTARIS_CONFIG_DIR")
    if env_dir:
        return Path(env_dir).expanduser().resolve()
    return Path.home() / ".antarisbot"


PID_FILE = _resolve_config_dir() / "bot.pid"


def _is_valid_snowflake(value: str) -> bool:
    """Discord snowflake: 17-19 digit integer string."""
    return value.isdigit() and 17 <= len(value) <= 19


def _write_pid():
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))


def _read_pid() -> int | None:
    if not PID_FILE.exists():
        return None
    try:
        return int(PID_FILE.read_text().strip())
    except (ValueError, OSError):
        return None


def _clear_pid():
    try:
        PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _stop_bot() -> bool:
    """Send SIGTERM to the running bot. Returns True if stopped."""
    pid = _read_pid()
    if not pid:
        print("❌ No running bot found.")
        return False
    try:
        os.kill(pid, signal.SIGTERM)
        _clear_pid()
        print(f"🛑 Bot stopped (PID {pid})")
        return True
    except ProcessLookupError:
        print(f"⚠️  PID {pid} not found — was the bot already stopped?")
        _clear_pid()
        return False
    except PermissionError:
        print(f"❌ Permission denied stopping PID {pid}")
        return False


def _cmd_security_status():
    """Print current security configuration."""
    from antaris_agent.core.config import Config, DEFAULT_CONFIG_PATH
    config = Config.load()
    if not config:
        print("❌ Bot not initialized. Run 'antaris-agent init' first.")
        return
    security_mode = getattr(config, "security_mode", "sandboxed")
    guard_mode = getattr(config, "guard_mode", "monitor")

    mode_descriptions = {
        "open": "Open (0) — no restrictions, full access",
        "standard": "Standard (1) ★ — light safety net, workspace + home scoped (recommended)",
        "sandboxed": "Sandboxed (2) — filesystem restricted, subprocesses blocked",
        "secured": "Secured (3) — network allowlisted, destructive ops need approval",
        "encrypted": "Encrypted (4) — all tools need approval, memory encrypted, full audit",
        "locked": "Encrypted (4) — all tools need approval, memory encrypted, full audit",
    }

    print(f"\n🔐 Antaris Security Status")
    print(f"   Mode:         {mode_descriptions.get(security_mode, security_mode)}")
    print(f"   Guard:        {guard_mode}")
    print(f"   Memory store: {config.memory_store}")
    if security_mode == "locked":
        import os
        audit_path = os.path.expanduser("~/.antarisbot/audit.log")
        print(f"   Audit log:    {audit_path}")
        print(f"   Encryption:   AES-256-GCM (locked mode)")
    print(f"\n   CLI override: antaris-agent start --security {security_mode}")
    print()


def _cmd_tools(action: str):
    """Tool management commands — lightweight, no full Bot instantiation."""
    from antaris_agent.core.config import Config
    
    config = Config.load()
    if not config:
        print("❌ Bot not initialized. Run 'antaris init' first.")
        return
    
    tools_config = getattr(config, '_tools_config', {})
    
    if action == "list":
        print("\n🔧 Configured Tools\n")
        
        if not tools_config:
            print("   No tools configured in config.json")
            return
        
        # Show what WOULD be registered based on config (no Bot instantiation)
        tool_specs = {
            'brave_search': ('Web search via Brave Search API', lambda c: c.get('enabled') and c.get('apiKey')),
            'web_fetch': ('Fetch and extract readable content from URLs', lambda c: c.get('enabled', False)),
            'browser': ('Browser automation via Playwright', lambda c: c.get('enabled')),
            'file_ops': ('File read/write/edit operations', lambda c: c.get('enabled')),
            'shell': ('Execute shell commands', lambda c: c.get('enabled')),
            'video': ('Video understanding via ffmpeg/whisper + LLM summaries/Q&A', lambda c: c.get('enabled')),
        }
        
        registered = []
        for tool_name, (desc, check_fn) in tool_specs.items():
            tool_cfg = tools_config.get(tool_name, {})
            if check_fn(tool_cfg):
                registered.append((tool_name, desc))
        
        # Check MCP servers
        mcp_servers = tools_config.get('mcp_servers', [])
        
        if not registered and not mcp_servers:
            print("   No tools enabled")
        else:
            if registered:
                print(f"   Native tools ({len(registered)}):")
                for name, desc in registered:
                    print(f"     • {name} — {desc}")
            if mcp_servers:
                print(f"\n   MCP servers ({len(mcp_servers)}):")
                for server in mcp_servers:
                    transport = server.get('transport', 'stdio')
                    print(f"     • {server['name']} ({transport})")
        
    elif action == "status":
        print("\n🔧 Tool Configuration Status\n")
        
        if not tools_config:
            print("   No tools configured in config.json")
            print("\n   Add to config.json:")
            print('   "tools": {')
            print('     "brave_search": {"enabled": true, "apiKey": "your-key"},')
            print('     "web_fetch": {"enabled": true},')
            print('     "browser": {"enabled": false}')
            print('   }')
        else:
            for tool, config_data in tools_config.items():
                if tool == 'mcp_servers':
                    # Handle MCP servers list separately
                    print(f"   MCP servers: {len(config_data)} configured")
                    for server in config_data:
                        print(f"     • {server.get('name', 'unnamed')} ({server.get('transport', 'stdio')})")
                    continue
                enabled = config_data.get('enabled', False)
                status = "✅ enabled" if enabled else "⚪ disabled"
                if tool == 'brave_search':
                    has_key = bool(config_data.get('apiKey'))
                    if enabled and not has_key:
                        status = "❌ enabled but missing apiKey"
                print(f"     • {tool}: {status}")

def _cmd_doctor():
    """Run diagnostic checks and print status."""
    import sys
    from pathlib import Path

    print("\n🩺 Antaris Doctor\n")
    ok = True

    # Python version
    v = sys.version_info
    status = "✅" if v >= (3, 10) else "❌"
    if v < (3, 10):
        ok = False
    print(f"   {status} Python {v.major}.{v.minor}.{v.micro} (need >=3.10)")

    # Config exists
    from antaris_agent.core.config import Config, resolve_config_path
    config_path = resolve_config_path()
    cfg = Config.load(str(config_path))
    if cfg:
        print(f"   ✅ Config found at {config_path}")
        print(f"   ✅ Provider: {cfg.provider_name} / {cfg.model}")
        print(f"   ✅ Security: {getattr(cfg, 'security_mode', 'sandboxed')}")
        channels = []
        if cfg.discord_enabled:
            channels.append("Discord")
        if cfg.telegram_enabled:
            channels.append("Telegram")
        if getattr(cfg, 'slack_enabled', False):
            channels.append("Slack")
        print(f"   ✅ Channels: {', '.join(channels) if channels else 'terminal only'}")
    else:
        print(f"   ❌ No config found — run 'antaris init'")
        ok = False

    # Bundled suite modules
    suite_modules = [
        ("parsica_memory", "memory"),
        ("antaris_agent.suite.guard", "guard"),
        ("antaris_agent.suite.context", "context"),
        ("antaris_agent.suite.router", "router"),
        ("antaris_agent.suite.pipeline", "pipeline"),
    ]
    for module, name in suite_modules:
        try:
            m = __import__(module, fromlist=[name])
            ver = getattr(m, "__version__", "?")
            print(f"   ✅ suite.{name} {ver}")
        except ImportError:
            print(f"   ❌ suite.{name} missing — reinstall: pip install antaris-agent")
            ok = False

    # Security packages
    for module, pkg in [("cryptography", "cryptography"), ("keyring", "keyring")]:
        try:
            __import__(module)
            print(f"   ✅ {pkg}")
        except ImportError:
            print(f"   ⚠️  {pkg} not installed (needed for locked security mode)")

    # Memory store
    if cfg:
        from pathlib import Path as P
        store = P(cfg.memory_store)
        if store.exists():
            files = list(store.rglob("*"))
            print(f"   ✅ Memory store: {len(files)} files at {store}")
        else:
            print(f"   ⚠️  Memory store not found at {store} (will be created on first message)")

    print()
    if ok:
        print("   ✅ All checks passed — run 'antaris start' to launch")
    else:
        print("   ❌ Some checks failed — fix the issues above then retry")
    print()


def main():
    # Detect invocation name (antaris vs antarisbot)
    prog = os.path.basename(sys.argv[0])
    if prog not in ("antaris", "antarisbot"):
        prog = "antaris"

    parser = argparse.ArgumentParser(
        prog=prog,
        description="Antaris — Personal AI assistant powered by antaris-suite",
        epilog=(
            "Popular commands:\n"
            "  antaris init                 First-time setup wizard\n"
            "  antaris start --terminal     Run in terminal-only mode\n"
            "  antaris status               Show bot status\n"
            "  antaris doctor               Check config + dependencies\n"
            "  antaris tools list           Discover enabled tools\n"
            "  antaris memory stats         Inspect memory usage\n"
            "  antaris setup                Launch browser setup wizard\n\n"
            "Discovery tips:\n"
            "  In chat, use !help / !models / !memory help / !agents\n"
            "  In CLI, use '<command> --help' for deeper command help\n"
            "\n"
            "Note: this revision still uses legacy ~/.antarisbot runtime paths in some code paths; use --config-dir or ANTARIS_CONFIG_DIR if needed."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"{prog} {VERSION}")
    parser.add_argument(
        "--config-dir",
        default=None,
        metavar="DIR",
        help="Config directory (default: ~/.antarisbot or $ANTARIS_CONFIG_DIR)",
    )

    subparsers = parser.add_subparsers(dest="command")

    # init
    parser_init = subparsers.add_parser("init", help="Interactive setup wizard")
    parser_init.add_argument(
        "--security",
        choices=["open", "standard", "sandboxed", "secured", "encrypted"],
        default=None,
        help="Pre-select security mode (skips the wizard prompt for this step)"
    )

    # start
    start_parser = subparsers.add_parser("start", help="Launch the bot")
    start_parser.add_argument("--terminal", action="store_true", help="Terminal mode only")
    start_parser.add_argument("--debug", action="store_true", help="Verbose logging")
    start_parser.add_argument(
        "--security",
        choices=["open", "standard", "sandboxed", "secured", "encrypted"],
        default=None,
        metavar="MODE",
        help="Security mode: open (no restrictions), sandboxed (default, recommended), standard (more capability), secured/encrypted (approval gates + audit logging)",
    )

    # stop
    subparsers.add_parser("stop", help="Stop the running bot")

    # pulse
    subparsers.add_parser("pulse", help="System health check — verify all components before launch")

    # restart
    subparsers.add_parser("restart", help="Restart the bot")

    # chat
    subparsers.add_parser("chat", help="Direct terminal conversation")

    # status
    subparsers.add_parser("status", help="Show bot status")

    # config
    config_parser = subparsers.add_parser("config", help="View or edit configuration")
    config_parser.add_argument("action", nargs="?", choices=["show", "set", "add", "telegram-token", "slack-token", "open-channel"])
    config_parser.add_argument("key", nargs="?")
    config_parser.add_argument("value", nargs="?")

    # memory
    mem_parser = subparsers.add_parser(
        "memory",
        help="Inspect and search the memory system",
        description=(
            "Memory inspection and export commands.\n\n"
            "Examples:\n"
            "  antaris memory stats\n"
            "  antaris memory search deployment\n"
            "  antaris memory export"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    mem_parser.add_argument("action", nargs="?", choices=["stats", "search", "export", "import", "prune"], help="stats/search/export/import/prune")
    mem_parser.add_argument("query", nargs="?", help="search query or output path, depending on action")

    # guard
    guard_parser = subparsers.add_parser("guard", help="Guard policy management")
    guard_parser.add_argument("action", nargs="?", choices=["status", "mode", "test"])
    guard_parser.add_argument("value", nargs="?")

    # persona
    persona_parser = subparsers.add_parser("persona", help="Persona management")
    persona_parser.add_argument("action", nargs="?", choices=["show", "edit", "reset"])

    # migrate
    migrate_parser = subparsers.add_parser("migrate", help="Import from another bot framework")
    migrate_parser.add_argument(
        "--from", dest="source",
        choices=["openclaw", "mem0", "langchain", "lancedb", "custom"],
    )
    migrate_parser.add_argument("--path")
    migrate_parser.add_argument("--dry-run", action="store_true")
    migrate_parser.add_argument("--user-id", dest="user_id", default=None,
        help="Discord user ID to assign imported memories to")
    migrate_parser.add_argument("--all", dest="import_all", action="store_true",
        help="Non-interactive: import everything without prompts")

    # export
    export_parser = subparsers.add_parser("export", help="Export bot data to a portable format")
    export_parser.add_argument("--full", action="store_true",
        help="Export everything (identity + config + memories)")
    export_parser.add_argument("--memories-only", action="store_true",
        help="Export memories only as JSONL")
    export_parser.add_argument("--identity-only", action="store_true",
        help="Export identity markdown files only")
    export_parser.add_argument("--output", default=None,
        help="Output path (file for --memories-only, directory otherwise)")

    # logs
    logs_parser = subparsers.add_parser("logs", help="View bot logs")
    logs_parser.add_argument("--follow", "-f", action="store_true", help="Stream new log lines (like tail -f)")
    logs_parser.add_argument("--tail", "-n", type=int, default=50, metavar="N", help="Number of lines to show (default: 50)")
    logs_parser.add_argument("--level", "-l", choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], metavar="LEVEL", help="Filter to only show lines at or above this level (e.g. ERROR)")

    # setup
    setup_parser = subparsers.add_parser("setup", help="Run the web setup wizard")
    setup_parser.add_argument("--no-browser", action="store_true", help="Don't open browser automatically")
    setup_parser.add_argument(
        "--wizard",
        choices=["general", "integrations", "automation", "power", "all"],
        default="all",
        help="Open a specific setup wizard for re-entry (default: all)",
    )

    # update
    update_parser = subparsers.add_parser("update", help="Update antaris-agent to the latest version")
    update_parser.add_argument(
        "--check", action="store_true",
        help="Check for updates without installing"
    )

    # security
    parser_security = subparsers.add_parser("security", help="Show security status")
    parser_security.add_argument("action", nargs="?", default="status", choices=["status"])

    # doctor
    subparsers.add_parser("doctor", help="Check bot configuration and dependencies")

    # tools
    tools_parser = subparsers.add_parser(
        "tools",
        help="Discover and inspect enabled tools",
        description=(
            "Inspect Antaris tool availability.\n\n"
            "Examples:\n"
            "  antaris tools list\n"
            "  antaris tools status"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tools_parser.add_argument("action", nargs="?", default="list", 
                             choices=["list", "status"], 
                             help="list = show enabled tools, status = show tool configuration state")

    args = parser.parse_args()

    # Apply --config-dir override before any command runs.
    # This sets the env var so that Config, pulse, and PID_FILE all pick it up.
    if getattr(args, "config_dir", None):
        os.environ["ANTARIS_CONFIG_DIR"] = str(Path(args.config_dir).expanduser().resolve())
        # Re-resolve module-level defaults that were computed at import time
        global PID_FILE
        PID_FILE = _resolve_config_dir() / "bot.pid"

    if args.command is None:
        parser.print_help()
        return

    # ── Commands ─────────────────────────────────────────────────────────────

    if args.command == "init":
        from antaris_agent.core.config import run_init_wizard
        run_init_wizard(security_mode=getattr(args, "security", None))

    elif args.command == "start":
        import atexit
        # Guard: prevent multiple instances
        existing_pid = _read_pid()
        if existing_pid:
            try:
                os.kill(existing_pid, 0)  # check if process is alive
                print(f"⚠️  Bot is already running (PID {existing_pid}).")
                print(f"   Run 'antaris stop' first, or 'antaris restart'.")
                sys.exit(1)
            except ProcessLookupError:
                _clear_pid()  # stale PID file — clear and continue
        _write_pid()
        atexit.register(_clear_pid)
        from antaris_agent.core.config import Config
        config = Config.load()
        if hasattr(args, "security") and args.security:
            if config:
                config.security_mode = args.security
        from antaris_agent.core.bot import Bot
        bot = Bot()
        if hasattr(args, "security") and args.security:
            if bot.config:
                bot.config.security_mode = args.security
        bot.start(terminal_only=getattr(args, 'terminal', False))

    elif args.command == "stop":
        _stop_bot()

    elif args.command == "pulse":
        import asyncio as _asyncio
        from antaris_agent.core.pulse import run_pulse
        report = _asyncio.run(run_pulse())
        print(report.summary())
        if not report.passed():
            sys.exit(1)

    elif args.command == "restart":
        print("🔄 Restarting bot...")
        _stop_bot()
        import time, subprocess
        time.sleep(1.5)
        subprocess.Popen([sys.argv[0], "start"])
        print("✅ Bot restarting.")

    elif args.command == "chat":
        from antaris_agent.core.bot import Bot
        Bot().chat()

    elif args.command == "status":
        from antaris_agent.core.config import Config
        cfg = Config.load()
        if cfg:
            pid = _read_pid()
            status = f"Running (PID {pid})" if pid else "Stopped"
            print(f"🤖 {cfg.bot_name}")
            print(f"   Status: {status}")
            print(f"   Provider: {cfg.provider_name} / {cfg.model}")
            open_ch = cfg.discord_open_channels
            print(f"   Open channels: {len(open_ch)} configured")
        else:
            print("❌ Not initialized. Run 'antaris init' first.")

    elif args.command == "config":
        from antaris_agent.core.config import Config
        cfg = Config.load()
        if not cfg:
            print("❌ Not initialized. Run 'antaris init' first.")
            return
        action = getattr(args, 'action', None) or 'show'
        if action == 'show' or not action:
            import json
            with open(cfg.config_path) as f:
                print(json.dumps(json.load(f), indent=2))
        elif action == 'set':
            key = getattr(args, 'key', None)
            value = getattr(args, 'value', None)
            if not key or not value:
                print("Usage: antaris config set <key> <value>")
                return
            # Simple key=value setter for top-level provider fields
            if key == 'model':
                cfg.model = value
                cfg.save()
                print(f"✅ Model set to {value}")
            elif key == 'open-channel':
                channel_id = value
                if not _is_valid_snowflake(channel_id):
                    print(f"❌ Invalid channel ID '{channel_id}'. Discord channel IDs are 17-19 digit numbers.")
                    sys.exit(1)
                if channel_id not in (cfg.discord_open_channels or []):
                    cfg.discord_open_channels = (cfg.discord_open_channels or []) + [channel_id]
                    cfg.save()
                    print(f"✅ Added {channel_id} as open channel (restart bot to apply)")
                else:
                    print(f"Already an open channel: {channel_id}")
            elif key == 'remove-channel':
                channels = cfg.discord_open_channels or []
                if value in channels:
                    channels.remove(value)
                    cfg.discord_open_channels = channels
                    cfg.save()
                    print(f"✅ Removed {value} from open channels")
                else:
                    print(f"Not an open channel: {value}")
            else:
                print(f"Unknown config key: {key}")
                print("Available: model, open-channel, remove-channel")
        elif action == 'telegram-token':
            token = getattr(args, 'key', None)
            if not token:
                print("Usage: antaris config telegram-token <token>")
                return
            cfg.telegram_token = token
            cfg.telegram_enabled = True
            cfg.save()
            print(f"✅ Telegram token set and Telegram enabled")

        elif action == 'slack-token':
            bot_token = getattr(args, 'key', None)
            app_token = getattr(args, 'value', None)
            if not bot_token or not app_token:
                print("Usage: antaris config slack-token <bot-token> <app-token>")
                print("  bot-token: xoxb-... (Bot User OAuth Token)")
                print("  app-token: xapp-... (App-Level Token for Socket Mode)")
                return
            cfg.slack_bot_token = bot_token
            cfg.slack_app_token = app_token
            cfg.slack_enabled = True
            cfg.save()
            print(f"✅ Slack tokens set and Slack enabled")

        elif action == 'open-channel':
            sub = getattr(args, 'key', None)
            channel_id = getattr(args, 'value', None)

            def _is_valid_snowflake(cid: str) -> bool:
                """A Discord snowflake is a 17-19 digit integer string."""
                return cid.isdigit() and 17 <= len(cid) <= 19

            if sub == 'list' or not sub:
                channels = cfg.discord_open_channels or []
                if not channels:
                    print("   (no open channels configured)")
                else:
                    print(f"   Open channels ({len(channels)}):")
                    for ch in channels:
                        print(f"   • {ch}")

            elif sub == 'add':
                if not channel_id:
                    print("Usage: antaris config open-channel add <channel_id>")
                    return
                if not _is_valid_snowflake(channel_id):
                    print(f"❌ '{channel_id}' does not look like a Discord snowflake (17-19 digits).")
                    return
                channels = list(cfg.discord_open_channels or [])
                if channel_id in channels:
                    print(f"⚠️  Channel {channel_id} is already in the open-channels list.")
                else:
                    channels.append(channel_id)
                    cfg.discord_open_channels = channels
                    cfg.save()
                    print(f"✅ Added {channel_id} to open channels. Restart bot to apply.")

            elif sub == 'remove':
                if not channel_id:
                    print("Usage: antaris config open-channel remove <channel_id>")
                    return
                channels = list(cfg.discord_open_channels or [])
                if channel_id not in channels:
                    print(f"⚠️  Channel {channel_id} not found in open-channels list.")
                else:
                    channels.remove(channel_id)
                    cfg.discord_open_channels = channels
                    cfg.save()
                    print(f"✅ Removed {channel_id} from open channels. Restart bot to apply.")

            else:
                print(f"Unknown open-channel sub-command: {sub}")
                print("Usage: antaris config open-channel add|remove|list [channel_id]")

    elif args.command == "persona":
        action = getattr(args, 'action', None) or 'show'
        soul_path = Path.home() / ".antarisbot" / "SOUL.md"
        if action == 'show':
            if soul_path.exists():
                print(soul_path.read_text())
            else:
                print("No SOUL.md found. Run 'antaris init' first.")
        elif action == 'edit':
            editor = os.environ.get("EDITOR", "nano")
            os.system(f"{editor} {soul_path}")
        elif action == 'reset':
            print("⚠️  This will erase the current persona and trigger awakening on next start.")
            confirm = input("Are you sure? (y/N): ").strip().lower()
            if confirm in ("y", "yes"):
                soul_path.write_text("AWAKENING_NEEDED\n")
                print("✅ SOUL.md reset. Next bot start will trigger awakening.")
            else:
                print("Cancelled.")

    elif args.command == "memory":
        action = getattr(args, 'action', None) or 'stats'
        from antaris_agent.core.config import Config
        cfg = Config.load()
        if not cfg:
            print("❌ Not initialized. Run 'antaris init' first.")
            return

        from antaris_agent.core.memory import BotMemory
        memory = BotMemory(
            store_path=cfg.memory_store,
            search_limit=cfg.memory_search_limit,
            min_relevance=cfg.memory_min_relevance,
        )

        if action == 'stats' or not action:
            # List all users and their memory counts
            store_path = __import__('pathlib').Path(cfg.memory_store)
            if not store_path.exists() or not any(store_path.iterdir()):
                print("📭 No memories stored yet.")
                return
            total = 0
            for user_dir in sorted(store_path.iterdir()):
                if user_dir.is_dir():
                    stats = memory.stats(user_dir.name)
                    count = stats.get('entry_count', 0)
                    total += count
                    print(f"   {user_dir.name[:20]}: {count} memories")
            print(f"\n   Total: {total} memories across {len(list(store_path.iterdir()))} user(s)")

        elif action == 'search':
            query = getattr(args, 'query', None)
            if not query:
                print("Usage: antaris memory search <query>")
                return
            # Search across all users
            import asyncio
            store_path = __import__('pathlib').Path(cfg.memory_store)
            found_any = False
            for user_dir in sorted(store_path.iterdir()):
                if not user_dir.is_dir():
                    continue
                results = asyncio.run(memory.recall(user_dir.name, query))
                if results:
                    found_any = True
                    print(f"\n[{user_dir.name[:20]}]")
                    for r in results[:5]:
                        print(f"  • {r[:120]}")
            if not found_any:
                print(f"No memories found for '{query}'")

        elif action == 'export':
            import json, asyncio
            output_file = getattr(args, 'query', None) or 'memory_export.json'
            store_path = __import__('pathlib').Path(cfg.memory_store)
            export = {}
            for user_dir in sorted(store_path.iterdir()):
                if user_dir.is_dir():
                    results = asyncio.run(memory.recall(user_dir.name, ""))
                    export[user_dir.name] = results
            with open(output_file, 'w') as f:
                json.dump(export, f, indent=2)
            print(f"✅ Exported to {output_file}")

        else:
            print(f"Unknown memory action: {action}")

    elif args.command == "guard":
        print("Guard commands coming in next phase.")

    elif args.command == "migrate":
        from pathlib import Path as P
        source = getattr(args, 'source', None)
        source_path = getattr(args, 'path', None)
        dry_run = getattr(args, 'dry_run', False)
        user_id = getattr(args, 'user_id', None) or "migrated-user"
        import_all = getattr(args, 'import_all', False)
        dest_path = str(P.home() / ".antarisbot")

        from antaris_agent.migration import (
            OpenClawMigration, Mem0Migration, CustomMigration,
            LangChainMigration, LanceDBMigration,
        )

        source_class_map = {
            "openclaw": OpenClawMigration,
            "mem0": Mem0Migration,
            "langchain": LangChainMigration,
            "lancedb": LanceDBMigration,
            "custom": CustomMigration,
        }

        if not source:
            # Interactive mode: scan all known locations
            print("🔍 Scanning for importable data...\n")
            found_sources = []
            scan_targets = [
                ("openclaw", P.home() / ".openclaw" / "workspace"),
                ("mem0", P.home()),
                ("langchain", P.home()),
                ("lancedb", P.home() / ".openclaw" / "memory"),
            ]
            for src_name, default_path in scan_targets:
                cls = source_class_map.get(src_name)
                if cls:
                    try:
                        m = cls(str(default_path), dest_path, dry_run=dry_run, user_id=user_id)
                        if m.detect():
                            found_sources.append((src_name, str(default_path), cls))
                            print(f"  ✅ {src_name} — found at {default_path}")
                    except Exception:
                        pass

            if not found_sources:
                print("No importable data found in default locations.")
                print("Use --from to specify a source: antaris migrate --from openclaw|mem0|langchain|lancedb|custom")
                return

            if not import_all:
                print(f"\nFound {len(found_sources)} source(s). Run with --all to import all, or specify --from <source>.")
                return

            # Import all found sources
            for src_name, src_path, cls in found_sources:
                print(f"\n📦 Migrating from {src_name}...")
                m = cls(src_path, dest_path, dry_run=dry_run, user_id=user_id)
                result = m.migrate()
                print(result.summary())
            if not dry_run:
                print("\n✅ Migration complete. Run 'antaris start' to launch.")
            return

        if not source_path:
            # Default paths per source
            defaults = {
                "openclaw": str(P.home() / ".openclaw" / "workspace"),
                "mem0": str(P.home()),
                "langchain": str(P.home()),
                "lancedb": str(P.home() / ".openclaw" / "memory"),
                "custom": "import.json",
            }
            source_path = defaults.get(source, ".")
            print(f"No --path given, trying default: {source_path}")

        MigrationClass = source_class_map.get(source)
        if not MigrationClass:
            print(f"Unknown source: {source}")
            return

        migrator = MigrationClass(
            source_path=source_path,
            dest_path=dest_path,
            dry_run=dry_run,
            user_id=user_id,
        )

        if not migrator.detect():
            print(f"❌ Could not detect {source} data at: {source_path}")
            print("   Check the path and try again.")
            return

        if dry_run:
            print(f"🔍 Dry run — nothing will be written\n")
        else:
            print(f"📦 Migrating from {source}...\n")

        result = migrator.migrate()
        print(result.summary())

        if result.success and not dry_run:
            print(f"\n✅ Migration complete.")
            print(f"   Run 'antaris start' to launch with your imported data.")
        elif dry_run:
            print(f"\n   Run without --dry-run to apply.")

    elif args.command == "export":
        from pathlib import Path as P
        from antaris_agent.migration.export import ExportManager

        full = getattr(args, 'full', False)
        memories_only = getattr(args, 'memories_only', False)
        identity_only = getattr(args, 'identity_only', False)
        output = getattr(args, 'output', None)

        # Default output paths
        timestamp = __import__('datetime').datetime.now().strftime('%Y%m%d_%H%M%S')
        if not output:
            if memories_only:
                output = str(P.home() / f"antaris_memories_{timestamp}.jsonl")
            else:
                output = str(P.home() / f"antaris_export_{timestamp}")

        exporter = ExportManager()

        if memories_only:
            print(f"📤 Exporting memories to {output}...")
            count = exporter.export_memories(output)
            print(f"✅ Exported {count} memory entries to {output}")

        elif identity_only:
            print(f"📤 Exporting identity files to {output}...")
            count = exporter.export_identity(output)
            print(f"✅ Exported {count} identity files to {output}")

        elif full or not (memories_only or identity_only):
            print(f"📤 Exporting full Antaris data to {output}...")
            summary = exporter.export_full(output)
            print(f"✅ Export complete at {output}")
            for key, val in summary.items():
                print(f"   {key}: {val}")
            print(f"\n   To re-import: antaris migrate --from custom --path {output}")

    elif args.command == "logs":
        import subprocess
        log_dir = Path.home() / ".antarisbot" / "logs"
        log_file = log_dir / "antaris-agent.log"
        if not log_file.exists():
            print("No log file found. Logs appear here when the bot runs in daemon mode.")
            print("For now, logs print to terminal when running 'antaris start'.")
            return

        follow = getattr(args, 'follow', False)
        tail_n = getattr(args, 'tail', 50)
        level_filter = getattr(args, 'level', None)

        if follow and not level_filter:
            # Pure streaming — delegate to tail -f
            subprocess.run(["tail", "-f", str(log_file)])
        elif follow and level_filter:
            # Stream + filter: tail -f piped through grep
            import shlex
            tail_proc = subprocess.Popen(["tail", "-f", str(log_file)], stdout=subprocess.PIPE)
            grep_proc = subprocess.Popen(
                ["grep", "--line-buffered", f"[{level_filter}]"],
                stdin=tail_proc.stdout,
            )
            try:
                grep_proc.wait()
            except KeyboardInterrupt:
                tail_proc.terminate()
                grep_proc.terminate()
        elif level_filter:
            # Static read — tail N lines then filter
            result = subprocess.run(
                ["tail", "-n", str(tail_n), str(log_file)],
                capture_output=True, text=True,
            )
            for line in result.stdout.splitlines():
                if f"[{level_filter}]" in line:
                    print(line)
        else:
            # Plain tail — configurable number of lines
            subprocess.run(["tail", "-n", str(tail_n), str(log_file)])

    elif args.command == "setup":
        from antaris_agent.setup.wizard import SetupWizard
        wizard = SetupWizard()
        wizard.run(open_browser=not args.no_browser, wizard=getattr(args, "wizard", "all"))

    elif args.command == "update":
        from antaris_agent.core.updater import Updater
        updater = Updater()
        check_only = getattr(args, "check", False)

        if check_only:
            available, installed, latest = updater.is_update_available()
            print(f"📦 Installed: v{installed}")
            if latest == installed:
                print("✅ You are up to date.")
            elif available:
                print(f"⬆️  Latest:    v{latest}")
                print(f"   Run `antaris update` to upgrade.")
            else:
                print(f"   Latest:    v{latest}")
                print("✅ You are up to date.")
        else:
            available, installed, latest = updater.is_update_available()
            if not available:
                print(f"✅ Antaris v{installed} is already up to date.")
            else:
                print(f"⬆️  Updating Antaris v{installed} → v{latest}…")
            success = updater.update()
            if success:
                print("✅ Update complete.")
                print("   Run `antaris restart` to apply the update.")
            else:
                print("❌ Update failed. Check the output above for details.")

    elif args.command == "security":
        _cmd_security_status()

    elif args.command == "doctor":
        _cmd_doctor()

    elif args.command == "tools":
        _cmd_tools(getattr(args, "action", "list"))

    else:
        print(f"'{args.command}' — coming soon.")


if __name__ == "__main__":
    main()
