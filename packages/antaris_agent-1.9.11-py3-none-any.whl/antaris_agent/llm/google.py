"""Google Gemini provider — direct HTTP, no SDK."""

import json
from typing import Optional

import httpx

from .base import LLMProvider, Message, LLMResponse, ThinkingConfig


def _to_gemini_parts(content):
    """Translate Antaris message content into Gemini parts.

    Supports plain text plus the structured text/image blocks used elsewhere in
    the pipeline for vision-capable providers.
    """
    if isinstance(content, str):
        return [{"text": content}]

    parts = []
    if isinstance(content, list):
        for block in content:
            if not isinstance(block, dict):
                parts.append({"text": str(block)})
                continue
            btype = block.get("type")
            if btype == "text":
                parts.append({"text": block.get("text", "")})
            elif btype == "image" and "source" in block:
                src = block["source"] or {}
                if src.get("type") == "base64" and src.get("data"):
                    parts.append({
                        "inline_data": {
                            "mime_type": src.get("media_type", "image/png"),
                            "data": src.get("data", ""),
                        }
                    })
            elif btype == "tool_result":
                tool_content = block.get("content", "")
                if isinstance(tool_content, list):
                    for item in tool_content:
                        if isinstance(item, dict) and item.get("type") == "text":
                            parts.append({"text": item.get("text", "")})
                        else:
                            parts.append({"text": str(item)})
                else:
                    parts.append({"text": str(tool_content)})
            elif btype == "tool_use":
                tool_name = block.get("name", "")
                tool_input = block.get("input", {})
                rendered_input = json.dumps(tool_input, ensure_ascii=False) if isinstance(tool_input, (dict, list)) else str(tool_input)
                parts.append({"text": f"[Tool call requested: {tool_name} args={rendered_input}]"})
            else:
                parts.append({"text": str(block)})

    return parts or [{"text": ""}]


# Pricing per million tokens (approximate, for cost tracking)
MODEL_PRICING = {
    "gemini-3.1-pro": {"input": 2.50, "output": 10.00},
    "gemini-2.5-flash": {"input": 0.15, "output": 0.60},
    "gemini-2.0-flash": {"input": 0.10, "output": 0.40},
    "gemini-1.5-pro": {"input": 1.25, "output": 5.00},
    "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
}


class GoogleProvider(LLMProvider):
    """Google Gemini provider — direct HTTP to generativelanguage.googleapis.com, no SDK."""

    BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

    def __init__(self, api_key: str, model: str):
        super().__init__(api_key, model)
        self._client = httpx.AsyncClient(timeout=60.0)

    async def close(self) -> None:
        """Close the underlying httpx client."""
        await self._client.aclose()

    MODELS = [
        "gemini-3.1-pro",
        "gemini-2.5-flash",
        "gemini-2.0-flash",
        "gemini-1.5-pro",
        "gemini-1.5-flash",
    ]

    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        tools=None,
        thinking: Optional[ThinkingConfig] = None,
    ) -> LLMResponse:
        use_model = model or self.model

        contents = []
        for m in messages:
            if m.role == "system":
                continue
            role = "model" if m.role == "assistant" else "user"
            contents.append({
                "role": role,
                "parts": _to_gemini_parts(m.content),
            })

        generation_config = {
            "maxOutputTokens": max_tokens,
            "temperature": temperature,
        }

        _thinking_models = ("gemini-2.5", "gemini-3")
        _supports_thinking = any(use_model.startswith(p) for p in _thinking_models)
        if thinking and thinking.enabled and _supports_thinking:
            generation_config["thinkingConfig"] = {
                "thinkingBudget": thinking.budget_tokens,
            }

        payload = {
            "contents": contents,
            "generationConfig": generation_config,
        }

        if tools:
            function_declarations = []
            for tool in tools:
                function = tool.get("function", tool)
                function_declarations.append({
                    "name": function.get("name", ""),
                    "description": function.get("description", ""),
                    "parameters": function.get("parameters") or function.get("input_schema") or {"type": "object", "properties": {}},
                })
            if function_declarations:
                payload["tools"] = [{"functionDeclarations": function_declarations}]

        if system:
            payload["systemInstruction"] = {
                "parts": [{"text": system}],
            }

        url = f"{self.BASE_URL}/models/{use_model}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key,
        }

        client = self._client
        try:
            response = await client.post(url, json=payload, headers=headers)

            if response.status_code == 400:
                body = response.text
                if "not found" in body.lower():
                    raise ValueError(f"Model not found: {use_model}")
                raise ValueError(f"Gemini bad request: {body}")
            if response.status_code == 401:
                raise ValueError("Invalid Google API key")
            if response.status_code == 403:
                raise ValueError("Google API key does not have Gemini access")
            if response.status_code == 429:
                retry_after = response.headers.get("retry-after", "5")
                try:
                    wait = int(float(retry_after))
                except (ValueError, TypeError):
                    wait = 5
                raise RuntimeError(f"rate_limit:{wait}")
            if response.status_code in (500, 503):
                raise RuntimeError(f"server_error:{response.status_code}")

            response.raise_for_status()
            data = response.json()

            candidates = data.get("candidates", [])
            if not candidates:
                block_reason = data.get("promptFeedback", {}).get("blockReason")
                if block_reason:
                    raise RuntimeError(f"Gemini blocked response: {block_reason}")
                raise RuntimeError("Gemini returned empty candidates")

            candidate = candidates[0]
            parts = candidate.get("content", {}).get("parts", [])

            tool_use = []
            text_chunks = []
            for part in parts:
                if not isinstance(part, dict):
                    continue
                text = part.get("text")
                if text:
                    text_chunks.append(text)
                function_call = part.get("functionCall")
                if isinstance(function_call, dict):
                    tool_use.append({
                        "type": "tool_use",
                        "id": function_call.get("name", ""),
                        "name": function_call.get("name", ""),
                        "input": function_call.get("args", {}) or {},
                    })

            if not text_chunks and not tool_use:
                finish = candidate.get("finishReason", "UNKNOWN")
                if finish == "SAFETY":
                    raise RuntimeError("Gemini blocked response for safety reasons")
                raise RuntimeError("Gemini returned empty content")

            content = "\n".join(chunk for chunk in text_chunks if chunk)

            usage = data.get("usageMetadata", {})
            input_tokens = usage.get("promptTokenCount", 0)
            output_tokens = usage.get("candidatesTokenCount", 0)

            pricing = MODEL_PRICING.get(use_model, {"input": 0.15, "output": 0.60})
            cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000

            return LLMResponse(
                content=content,
                model=use_model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_usd=cost,
                tool_use=tool_use or None,
            )

        except (ValueError, RuntimeError):
            raise
        except httpx.TimeoutException:
            raise RuntimeError("Gemini API request timed out")
        except httpx.HTTPStatusError as e:
            raise RuntimeError(
                f"Gemini API error {e.response.status_code}: {e.response.text}"
            )

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)
