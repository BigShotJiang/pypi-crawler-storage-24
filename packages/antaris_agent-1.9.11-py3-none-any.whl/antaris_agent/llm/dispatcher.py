"""Multi-provider LLM dispatcher — routes to the correct provider based on routing decisions.

Supports two levels of automatic failover:
  1. Intra-provider profile rotation (same provider, different API key/profile)
  2. Cross-provider failover (e.g., anthropic → openai)
"""

import logging
import time
from typing import Dict, Optional

from .base import LLMProvider, LLMResponse, Message, ThinkingConfig

logger = logging.getLogger(__name__)

_PROVIDER_MODEL_PREFIXES = {
    "anthropic": ("claude",),
    "openai": ("gpt-", "o1", "o3", "o4"),
    "google": ("gemini",),
    "ollama": (),
}


def _model_looks_compatible(provider: str, model: str | None) -> bool:
    if not model:
        return True
    prefixes = _PROVIDER_MODEL_PREFIXES.get(provider, ())
    if not prefixes:
        return True
    lowered = model.lower()
    return any(lowered.startswith(prefix) for prefix in prefixes)


def _fallback_model_for_provider(provider_obj: LLMProvider, fallback_provider: str, requested_model: str | None) -> str | None:
    provider_default = getattr(provider_obj, "model", None)
    if provider_default:
        return provider_default
    if _model_looks_compatible(fallback_provider, requested_model):
        return requested_model
    return None


class LLMDispatcher:
    """Holds multiple LLM providers and dispatches calls based on provider name."""

    def __init__(self):
        self._providers: Dict[str, LLMProvider] = {}
        self._auth_monitor = None
        self._active_profile_ids: Dict[str, str] = {}

    def set_auth_monitor(self, monitor) -> None:
        self._auth_monitor = monitor

    def set_active_profile(self, provider: str, profile_id: str) -> None:
        self._active_profile_ids[provider] = profile_id

    def get_active_profile(self, provider: str) -> str:
        return self._active_profile_ids.get(provider, "")

    def register(self, name: str, provider: LLMProvider):
        self._providers[name] = provider
        logger.info("LLMDispatcher: registered provider '%s'", name)

    def get(self, name: str) -> Optional[LLMProvider]:
        return self._providers.get(name)

    @property
    def providers(self) -> Dict[str, LLMProvider]:
        return dict(self._providers)

    async def complete(
        self,
        provider: str,
        model: str,
        messages: list[Message],
        system: str,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        tools: Optional[list[dict]] = None,
        thinking: Optional[ThinkingConfig] = None,
    ) -> LLMResponse:
        p = self._providers.get(provider)
        if not p:
            raise ValueError(f"Unknown provider: {provider}. Available: {list(self._providers.keys())}")

        current_profile = self._active_profile_ids.get(provider, "")

        try:
            response = await p.complete(
                messages=messages,
                system=system,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                tools=tools,
                thinking=thinking,
            )
            if self._auth_monitor:
                self._auth_monitor.record_call(
                    provider,
                    success=True,
                    profile_id=current_profile,
                )
            return response

        except (RuntimeError, ValueError) as e:
            err_str = str(e).lower()
            is_rate_limit = "rate_limit" in err_str or "429" in err_str
            is_server_error = "server_error" in err_str or "500" in err_str or "503" in err_str
            is_auth_error = (
                "401" in err_str
                or "invalid" in err_str and ("api key" in err_str or "key" in err_str)
                or "unauthorized" in err_str
                or "authentication" in err_str
            )
            is_retryable = is_rate_limit or is_server_error or is_auth_error

            rate_reset = 0.0
            if is_rate_limit:
                try:
                    parts = str(e).split(":")
                    if len(parts) >= 2:
                        wait = int(parts[-1])
                        rate_reset = time.time() + wait
                except (ValueError, IndexError):
                    rate_reset = time.time() + 30

            if self._auth_monitor:
                self._auth_monitor.record_call(
                    provider,
                    success=False,
                    error=str(e),
                    rate_limited=is_rate_limit,
                    rate_limit_reset=rate_reset,
                    auth_error=is_auth_error,
                    profile_id=current_profile,
                )

            if not self._auth_monitor or not is_retryable:
                raise

            reason = "rate_limit" if is_rate_limit else ("auth_error" if is_auth_error else "server_error")
            rotated = self._auth_monitor.try_rotate_profile(
                provider,
                current_profile=current_profile,
                reason=reason,
            )

            rotation_failed = False
            if rotated:
                new_profile_id, new_credential = rotated
                logger.warning(
                    "Profile rotation: %s → %s (provider=%s, reason=%s)",
                    current_profile, new_profile_id, provider, reason,
                )
                p.api_key = new_credential
                self._active_profile_ids[provider] = new_profile_id

                try:
                    response = await p.complete(
                        messages=messages,
                        system=system,
                        model=model,
                        max_tokens=max_tokens,
                        temperature=temperature,
                        tools=tools,
                        thinking=thinking,
                    )
                    self._auth_monitor.record_call(
                        provider,
                        success=True,
                        profile_id=new_profile_id,
                    )
                    return response
                except Exception as rotation_err:
                    logger.error(
                        "Profile rotation to %s also failed: %s",
                        new_profile_id, rotation_err,
                    )
                    self._auth_monitor.record_call(
                        provider,
                        success=False,
                        error=str(rotation_err),
                        profile_id=new_profile_id,
                    )
                    rotation_failed = True

            fallback = self._auth_monitor.should_failover(provider)
            if not fallback and rotation_failed:
                for alt_name, alt_status in self._auth_monitor._health.providers.items():
                    if alt_name != provider and alt_status.is_valid and not alt_status.is_rate_limited:
                        fallback = alt_name
                        break

            if fallback and fallback in self._providers:
                logger.warning(
                    "Cross-provider failover: %s → %s (reason: %s)",
                    provider, fallback, e,
                )
                fallback_provider = self._providers[fallback]
                fallback_profile = self._active_profile_ids.get(fallback, "")
                fallback_model = _fallback_model_for_provider(fallback_provider, fallback, model)
                if fallback_model != model:
                    logger.warning(
                        "Cross-provider failover remapped model: %s/%s -> %s/%s",
                        provider, model, fallback, fallback_model,
                    )
                try:
                    response = await fallback_provider.complete(
                        messages=messages,
                        system=system,
                        model=fallback_model,
                        max_tokens=max_tokens,
                        temperature=temperature,
                        tools=tools,
                        thinking=thinking,
                    )
                    self._auth_monitor.record_call(
                        fallback,
                        success=True,
                        profile_id=fallback_profile,
                    )
                    return response
                except Exception as fallback_err:
                    logger.error("Fallback to %s also failed: %s", fallback, fallback_err)
                    self._auth_monitor.record_call(
                        fallback,
                        success=False,
                        error=str(fallback_err),
                        profile_id=fallback_profile,
                    )

            raise

    def estimate_tokens(self, text: str) -> int:
        for p in self._providers.values():
            return p.estimate_tokens(text)
        return max(1, len(text) // 4)
