"""OpenAI provider — Phase 4 (direct HTTP, no SDK)."""

import httpx
from typing import Optional
from .base import LLMProvider, Message, LLMResponse, ThinkingConfig

# Pricing per million tokens (approximate, for cost tracking)
MODEL_PRICING = {
    "gpt-5.4": {"input": 5.00, "output": 15.00},
    "gpt-5.2": {"input": 3.00, "output": 12.00},
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "o1": {"input": 15.00, "output": 60.00},
    "o3-mini": {"input": 1.10, "output": 4.40},
}


class OpenAIProvider(LLMProvider):
    """OpenAI provider — direct HTTP to api.openai.com, no SDK."""

    BASE_URL = "https://api.openai.com/v1"

    def __init__(self, api_key: str, model: str):
        super().__init__(api_key, model)
        self._client = httpx.AsyncClient(timeout=60.0)

    async def close(self) -> None:
        """Close the underlying httpx client."""
        await self._client.aclose()

    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        tools=None,
        thinking: Optional[ThinkingConfig] = None,
    ) -> LLMResponse:
        use_model = model or self.model

        # Build messages array: system first, then conversation messages (skip any role=system)
        openai_messages = []
        if system:
            openai_messages.append({"role": "system", "content": system})
        for m in messages:
            if m.role == "system":
                continue
            content = m.content
            # v1.7.0: Translate Anthropic-format vision blocks to OpenAI format
            if isinstance(content, list):
                openai_content = []
                for block in content:
                    if isinstance(block, dict):
                        btype = block.get("type", "")
                        if btype == "text":
                            openai_content.append({"type": "text", "text": block.get("text", "")})
                        elif btype == "image" and "source" in block:
                            # Anthropic: {"type":"image","source":{"type":"base64","media_type":"...","data":"..."}}
                            # OpenAI: {"type":"image_url","image_url":{"url":"data:media_type;base64,data"}}
                            src = block["source"]
                            media_type = src.get("media_type", "image/png")
                            b64_data = src.get("data", "")
                            openai_content.append({
                                "type": "image_url",
                                "image_url": {"url": f"data:{media_type};base64,{b64_data}"}
                            })
                        else:
                            openai_content.append({"type": "text", "text": str(block)})
                    else:
                        openai_content.append({"type": "text", "text": str(block)})
                content = openai_content
            openai_messages.append({"role": m.role, "content": content})

        # GPT-5.x and newer models use max_completion_tokens instead of max_tokens
        _new_api_models = ("gpt-5", "o1", "o3")
        _use_new_param = any(use_model.startswith(p) for p in _new_api_models)

        payload = {
            "model": use_model,
            "messages": openai_messages,
            "temperature": temperature,
        }
        if _use_new_param:
            payload["max_completion_tokens"] = max_tokens
        else:
            payload["max_tokens"] = max_tokens

        # Propagate thinking/reasoning config for o-series models
        _o_series = ("o1", "o3", "o4")
        _is_o_series = any(use_model.startswith(p) for p in _o_series)
        if thinking and thinking.enabled and _is_o_series:
            # OpenAI o-series uses reasoning_effort: low | medium | high
            _effort_map = {
                "low": "low",
                "medium": "medium",
                "high": "high",
                "max": "high",  # OpenAI caps at "high"
            }
            effort = _effort_map.get(thinking.level, "medium")
            payload["reasoning_effort"] = effort

        # v1.7.0: Pass tools to OpenAI if provided
        if tools:
            openai_tools = []
            for t in tools:
                openai_tools.append({
                    "type": "function",
                    "function": {
                        "name": t.get("name", t.get("function", {}).get("name", "")),
                        "description": t.get("description", t.get("function", {}).get("description", "")),
                        "parameters": t.get("input_schema", t.get("function", {}).get("parameters", {})) or {"type": "object", "properties": {}},
                    }
                })
            payload["tools"] = openai_tools

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        client = self._client
        try:
            response = await client.post(
                f"{self.BASE_URL}/chat/completions",
                json=payload,
                headers=headers,
            )

            if response.status_code == 401:
                raise ValueError("Invalid OpenAI API key")
            if response.status_code == 400:
                body = response.text
                if "model_not_found" in body:
                    raise ValueError(f"Model not found: {use_model}")
                raise ValueError(f"OpenAI bad request: {body}")
            if response.status_code == 429:
                retry_after = response.headers.get("retry-after", "5")
                try:
                    wait = int(float(retry_after))
                except (ValueError, TypeError):
                    wait = 5
                raise RuntimeError(f"rate_limit:{wait}")
            if response.status_code in (500, 503):
                raise RuntimeError(f"server_error:{response.status_code}")

            response.raise_for_status()
            data = response.json()

            msg = data["choices"][0]["message"]
            raw_content = msg.get("content") or ""
            usage = data.get("usage", {})
            input_tokens = usage.get("prompt_tokens", 0)
            output_tokens = usage.get("completion_tokens", 0)

            # Calculate cost
            pricing = MODEL_PRICING.get(use_model, {"input": 2.50, "output": 10.00})
            cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000

            # v1.7.0: Parse tool_calls from OpenAI response
            tool_use = None
            openai_tool_calls = msg.get("tool_calls")
            if openai_tool_calls:
                import json as _json
                tool_use = []
                for tc in openai_tool_calls:
                    fn = tc.get("function", {})
                    try:
                        args = _json.loads(fn.get("arguments", "{}"))
                    except (ValueError, _json.JSONDecodeError):
                        args = {}
                    tool_use.append({
                        "type": "tool_use",
                        "id": tc.get("id", ""),
                        "name": fn.get("name", ""),
                        "input": args,
                    })

            # Allow empty content when tool_calls are present
            if not raw_content.strip() and not tool_use:
                raise RuntimeError("OpenAI returned empty content")

            return LLMResponse(
                content=raw_content,
                model=use_model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_usd=cost,
                tool_use=tool_use,
            )

        except (ValueError, RuntimeError):
            raise
        except httpx.TimeoutException:
            raise RuntimeError("OpenAI API request timed out")
        except httpx.HTTPStatusError as e:
            raise RuntimeError(f"OpenAI API error {e.response.status_code}: {e.response.text}")

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)
