"""MCP server exposing researchbot tools to Claude Code."""

import json
from dataclasses import asdict

from mcp.server.fastmcp import FastMCP

from researchbot import config, pdf, scholar

server = FastMCP(
    name="researchbot",
    instructions=(
        "Search academic papers, get citations/references, "
        "and read full paper text via Semantic Scholar and OCR."
    ),
)


def _paper_to_dict(paper: scholar.Paper) -> dict:
    """Convert a Paper dataclass to a JSON-serializable dict."""
    return asdict(paper)


@server.tool()
def search_papers(query: str, limit: int = config.SEARCH_LIMIT) -> str:
    """Search for academic papers by keyword on Semantic Scholar.

    Args:
        query: Search query string (e.g. "attention mechanism", "state space models")
        limit: Maximum number of results to return (default 20)

    Returns:
        JSON list of papers with title, abstract, authors, year, venue, citation count, and URLs.
    """
    papers = scholar.search_papers(query, limit)
    return json.dumps([_paper_to_dict(p) for p in papers], ensure_ascii=False)


@server.tool()
def get_paper(paper_id: str) -> str:
    """Get full details for a single paper by its ID.

    Supported ID formats: ARXIV:xxx, DOI:xxx, CorpusId:xxx, Semantic Scholar hash, or URL:xxx.

    Args:
        paper_id: The paper identifier (e.g. "ARXIV:1706.03762", "DOI:10.18653/v1/N19-1423")

    Returns:
        JSON object with paper details including title, abstract, authors,
        year, venue, citation count, and URLs.
    """
    paper = scholar.get_paper(paper_id)
    return json.dumps(_paper_to_dict(paper), ensure_ascii=False)


@server.tool()
def get_citations(paper_id: str, limit: int = config.CITATION_LIMIT) -> str:
    """Get papers that cite the given paper.

    Args:
        paper_id: The paper identifier (e.g. "ARXIV:1706.03762")
        limit: Maximum number of citing papers to return (default 50)

    Returns:
        JSON list of citing papers.
    """
    papers = scholar.get_citations(paper_id, limit)
    return json.dumps([_paper_to_dict(p) for p in papers], ensure_ascii=False)


@server.tool()
def get_references(paper_id: str, limit: int = config.CITATION_LIMIT) -> str:
    """Get papers referenced by the given paper.

    Args:
        paper_id: The paper identifier (e.g. "ARXIV:1706.03762")
        limit: Maximum number of referenced papers to return (default 50)

    Returns:
        JSON list of referenced papers.
    """
    papers = scholar.get_references(paper_id, limit)
    return json.dumps([_paper_to_dict(p) for p in papers], ensure_ascii=False)


@server.tool()
def search_similar(paper_id: str, limit: int = config.SIMILAR_LIMIT) -> str:
    """Find similar papers via Semantic Scholar recommendations.

    Args:
        paper_id: The paper identifier (e.g. "ARXIV:1706.03762")
        limit: Maximum number of similar papers to return (default 20)

    Returns:
        JSON list of similar papers.
    """
    papers = scholar.search_similar(paper_id, limit)
    return json.dumps([_paper_to_dict(p) for p in papers], ensure_ascii=False)


@server.tool()
def ocr_local_pdf(pdf_path: str) -> str:
    """OCR a local PDF file and return the cache path to read it.

    Use this for local PDF files not in Semantic Scholar.
    For published papers, use read_paper instead.

    Args:
        pdf_path: Absolute path to a local PDF file.

    Returns:
        JSON with cache_path to read the full text via Read tool.
    """
    content = pdf.ocr_local_pdf(pdf_path)
    return json.dumps(
        {"cache_path": str(content.cache_path), "title": content.title},
        ensure_ascii=False,
    )


@server.tool()
def read_paper(paper_id: str, include_images: bool = False) -> str:
    """Download a paper's PDF, OCR it, and return metadata + cache path.

    This tool downloads the paper PDF (if not cached), runs OCR to extract text,
    and caches the result. Returns metadata and the path to the cached markdown
    file so the agent can read it selectively using the Read tool.

    The References section is automatically stripped from the cached text.

    Args:
        paper_id: The paper identifier (e.g. "ARXIV:2106.15928"), a URL
            (e.g. "https://arxiv.org/abs/2106.15928"), or a paper name
            (e.g. "Attention is All You Need"). Names are resolved via search.
        include_images: If true, include image file paths in the response.

    Returns:
        JSON object with paper metadata and cache_path to read the full text.
    """
    content = pdf.get_paper_text(paper_id)

    data = {
        "cache_path": str(content.cache_path),
        "title": content.title,
        "authors": content.authors,
        "year": content.year,
        "venue": content.venue,
        "citation_count": content.citation_count,
    }

    if include_images:
        data["image_paths"] = {k: str(v) for k, v in content.image_paths.items()}

    return json.dumps(data, ensure_ascii=False)


def main():
    """Run the MCP server with stdio transport."""
    server.run(transport="stdio")


if __name__ == "__main__":
    main()
