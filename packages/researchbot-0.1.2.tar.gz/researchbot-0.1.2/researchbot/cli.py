"""CLI entry point for researchbot."""

import json
import sys
from dataclasses import asdict

import click

from researchbot import pdf, scholar


def _output(data, pretty: bool) -> None:
    """Print data as JSON to stdout."""
    indent = 2 if pretty else None
    click.echo(json.dumps(data, indent=indent, ensure_ascii=False))


def _handle_errors(func):
    """Decorator that catches library exceptions and prints clean messages."""
    import functools

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except LookupError as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)
        except RuntimeError as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)
        except Exception as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)

    return wrapper


@click.group()
def main():
    """Researchbot — literature research tools for AI-assisted paper analysis."""
    pass


@main.command()
@click.argument("query")
@click.option("--limit", default=20, help="Max number of results.")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON output.")
@_handle_errors
def search(query: str, limit: int, pretty: bool) -> None:
    """Search for papers by keyword."""
    papers = scholar.search_papers(query, limit)
    _output([asdict(p) for p in papers], pretty)


@main.command()
@click.argument("paper_id")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON output.")
@_handle_errors
def paper(paper_id: str, pretty: bool) -> None:
    """Get details for a single paper by ID."""
    p = scholar.get_paper(paper_id)
    _output(asdict(p), pretty)


@main.command()
@click.argument("paper_id")
@click.option("--limit", default=50, help="Max number of results.")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON output.")
@_handle_errors
def citations(paper_id: str, limit: int, pretty: bool) -> None:
    """Get papers that cite the given paper."""
    papers = scholar.get_citations(paper_id, limit)
    _output([asdict(p) for p in papers], pretty)


@main.command()
@click.argument("paper_id")
@click.option("--limit", default=50, help="Max number of results.")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON output.")
@_handle_errors
def references(paper_id: str, limit: int, pretty: bool) -> None:
    """Get papers referenced by the given paper."""
    papers = scholar.get_references(paper_id, limit)
    _output([asdict(p) for p in papers], pretty)


@main.command()
@click.argument("paper_id")
@click.option("--limit", default=20, help="Max number of results.")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON output.")
@_handle_errors
def similar(paper_id: str, limit: int, pretty: bool) -> None:
    """Find similar papers via Semantic Scholar recommendations."""
    papers = scholar.search_similar(paper_id, limit)
    _output([asdict(p) for p in papers], pretty)


@main.command()
@click.argument("paper_id")
@click.option("--include-images", is_flag=True, help="Output JSON with image paths.")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON output.")
@_handle_errors
def read(paper_id: str, include_images: bool, pretty: bool) -> None:
    """Download, OCR, and output a paper's full text as markdown."""
    content = pdf.get_paper_text(paper_id)

    if include_images:
        data = {
            "text": content.markdown,
            "image_paths": {k: str(v) for k, v in content.image_paths.items()},
        }
        _output(data, pretty)
    else:
        click.echo(content.markdown)
