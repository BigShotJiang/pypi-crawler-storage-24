"""OCR pipeline — convert PDFs to markdown via Mistral or Deepseek."""

import base64
from pathlib import Path

from mistralai import Mistral

from researchbot import config, scholar
from researchbot.pdf import PaperContent, _sanitize_id, _strip_references


def pdf_to_markdown(
    pdf_path: Path, paper_id: str, paper_metadata: scholar.Paper, provider: str = config.OCR_PROVIDER
) -> PaperContent:
    """Convert a PDF file to markdown + images using OCR. Results are cached."""
    if provider == "mistral":
        return _mistral_ocr(pdf_path, paper_id, paper_metadata)
    elif provider == "deepseek":
        raise NotImplementedError("Deepseek OCR not yet implemented")
    else:
        raise ValueError(f"Unknown OCR provider: {provider}")


def _load_from_cache(ocr_dir: Path, paper_metadata: scholar.Paper) -> PaperContent | None:
    """Load cached OCR results if they exist."""
    text_path = ocr_dir / "text.md"
    if not text_path.exists():
        return None

    markdown = text_path.read_text(encoding="utf-8")
    images_dir = ocr_dir / "images"
    image_paths: dict[str, Path] = {}
    if images_dir.exists():
        for img_file in sorted(images_dir.iterdir()):
            image_paths[img_file.stem] = img_file

    return PaperContent(
        markdown=markdown,
        cache_path=text_path,
        title=paper_metadata.title,
        authors=paper_metadata.authors,
        year=paper_metadata.year,
        venue=paper_metadata.venue,
        citation_count=paper_metadata.citation_count,
        image_paths=image_paths
    )


def _mistral_ocr(pdf_path: Path, paper_id: str, paper_metadata: scholar.Paper) -> PaperContent:
    """Run Mistral OCR on a PDF and cache results."""
    sanitized = _sanitize_id(paper_id)
    ocr_dir = config.OCR_CACHE_DIR / sanitized

    # Check cache first
    cached = _load_from_cache(ocr_dir, paper_metadata)
    if cached is not None:
        return cached

    if not config.MISTRAL_API_KEY:
        raise RuntimeError(
            "MISTRAL_API_KEY not set. Add it to ~/.config/researchbot/.env to use OCR."
        )

    # Encode PDF as base64 data URI
    pdf_bytes = pdf_path.read_bytes()
    b64 = base64.standard_b64encode(pdf_bytes).decode("ascii")
    document_url = f"data:application/pdf;base64,{b64}"

    client = Mistral(api_key=config.MISTRAL_API_KEY)
    response = client.ocr.process(
        model="mistral-ocr-latest",
        document={"type": "document_url", "document_url": document_url},
        include_image_base64=True,
        table_format="html",
    )

    # Create cache directories
    ocr_dir.mkdir(parents=True, exist_ok=True)
    images_dir = ocr_dir / "images"
    images_dir.mkdir(exist_ok=True)

    # Process response pages
    page_markdowns: list[str] = []
    image_paths: dict[str, Path] = {}

    for page in response.pages:
        page_md = page.markdown

        # Save extracted images
        for image in page.images:
            if image.image_base64:
                # Mistral returns image_base64 as a data URI
                # (e.g. "data:image/jpeg;base64,...") — strip the prefix
                image_b64 = image.image_base64
                if image_b64.startswith("data:"):
                    image_b64 = image_b64.split(",", 1)[1]
                img_data = base64.b64decode(image_b64)
                img_path = images_dir / f"{image.id}.png"
                img_path.write_bytes(img_data)
                image_paths[image.id] = img_path

                # Rewrite image references in markdown to point to local path
                page_md = page_md.replace(
                    f"({image.id})", f"({img_path})"
                )

        page_markdowns.append(page_md)

    markdown = "\n\n---\n\n".join(page_markdowns)

    # Strip the References section to reduce size
    markdown = _strip_references(markdown)

    # Save markdown to cache
    text_path = ocr_dir / "text.md"
    text_path.write_text(markdown, encoding="utf-8")

    return PaperContent(
        markdown=markdown,
        cache_path=text_path,
        title=paper_metadata.title,
        authors=paper_metadata.authors,
        year=paper_metadata.year,
        venue=paper_metadata.venue,
        citation_count=paper_metadata.citation_count,
        image_paths=image_paths
    )
