"""Semantic Scholar API client."""

import sys
import time
from dataclasses import dataclass, field

import httpx

from researchbot import config

_MAX_RETRIES = 3
_INITIAL_BACKOFF = 2.0
_MIN_REQUEST_INTERVAL = 1.1  # Semantic Scholar rate limit: 1 request/second with API key (add margin)


@dataclass
class Paper:
    paper_id: str
    title: str
    abstract: str | None = None
    authors: list[str] = field(default_factory=list)
    year: int | None = None
    venue: str | None = None
    citation_count: int | None = None
    url: str | None = None
    pdf_url: str | None = None
    tldr: str | None = None
    arxiv_id: str | None = None


# Fields to request from paper endpoints.
# The tldr field is only supported on search and single-paper endpoints,
# not on citations, references, or recommendations.
_PAPER_FIELDS = "title,abstract,year,venue,citationCount,url,openAccessPdf,tldr,authors,externalIds"
_PAPER_FIELDS_NO_TLDR = (
    "title,abstract,year,venue,citationCount,url,openAccessPdf,authors,externalIds"
)


class SemanticScholarClient:
    BASE_URL = "https://api.semanticscholar.org"
    GRAPH_API = f"{BASE_URL}/graph/v1"
    RECOMMENDATIONS_API = f"{BASE_URL}/recommendations/v1"

    def __init__(self) -> None:
        headers = {}
        if config.SEMANTIC_SCHOLAR_API_KEY:
            headers["x-api-key"] = config.SEMANTIC_SCHOLAR_API_KEY
        self._client = httpx.Client(timeout=30.0, headers=headers)
        self._last_request_time: float = 0.0

    def _rate_limit_wait(self) -> None:
        """Wait if needed to respect the rate limit."""
        elapsed = time.time() - self._last_request_time
        if elapsed < _MIN_REQUEST_INTERVAL:
            time.sleep(_MIN_REQUEST_INTERVAL - elapsed)
        self._last_request_time = time.time()

    def _request(self, url: str, params: dict | None = None) -> dict:
        """Make a GET request with rate limiting and exponential backoff."""
        for attempt in range(_MAX_RETRIES + 1):
            self._rate_limit_wait()
            resp = self._client.get(url, params=params)
            if resp.status_code == 404:
                raise LookupError("Paper not found")
            if resp.status_code == 429:
                if attempt < _MAX_RETRIES:
                    wait = _INITIAL_BACKOFF * (2**attempt)
                    print(
                        f"Rate limited by Semantic Scholar. "
                        f"Retrying in {wait:.0f}s ({attempt + 1}/{_MAX_RETRIES})...",
                        file=sys.stderr,
                    )
                    time.sleep(wait)
                    continue
                raise RuntimeError(
                    "Rate limited by Semantic Scholar after multiple retries. "
                    "Add SEMANTIC_SCHOLAR_API_KEY to ~/.config/researchbot/.env for higher limits."
                )
            resp.raise_for_status()
            return resp.json()
        raise RuntimeError("Unexpected: exhausted retries without response")

    def _parse_paper(self, data: dict) -> Paper:
        external_ids = data.get("externalIds") or {}
        return Paper(
            paper_id=data.get("paperId", ""),
            title=data.get("title", ""),
            abstract=data.get("abstract"),
            authors=[a.get("name", "") for a in data.get("authors", [])],
            year=data.get("year"),
            venue=data.get("venue"),
            citation_count=data.get("citationCount"),
            url=data.get("url"),
            pdf_url=(data.get("openAccessPdf") or {}).get("url") or None,
            tldr=(data.get("tldr") or {}).get("text"),
            arxiv_id=external_ids.get("ArXiv"),
        )

    def search_papers(self, query: str, limit: int = config.SEARCH_LIMIT) -> list[Paper]:
        """Keyword search for papers."""
        data = self._request(
            f"{self.GRAPH_API}/paper/search",
            params={"query": query, "limit": limit, "fields": _PAPER_FIELDS},
        )
        return [self._parse_paper(item) for item in data.get("data", [])]

    def get_paper(self, paper_id: str) -> Paper:
        """Get full details for a single paper by ID.

        Supported ID formats: Semantic Scholar hash, CorpusId:xxx, DOI:xxx,
        ARXIV:xxx, PMID:xxx, URL:xxx.
        """
        data = self._request(
            f"{self.GRAPH_API}/paper/{paper_id}",
            params={"fields": _PAPER_FIELDS},
        )
        return self._parse_paper(data)

    def get_citations(self, paper_id: str, limit: int = config.CITATION_LIMIT) -> list[Paper]:
        """Get papers that cite the given paper."""
        data = self._request(
            f"{self.GRAPH_API}/paper/{paper_id}/citations",
            params={"limit": limit, "fields": _PAPER_FIELDS_NO_TLDR},
        )
        return [self._parse_paper(item["citingPaper"]) for item in data.get("data", [])]

    def get_references(self, paper_id: str, limit: int = config.CITATION_LIMIT) -> list[Paper]:
        """Get papers referenced by the given paper."""
        data = self._request(
            f"{self.GRAPH_API}/paper/{paper_id}/references",
            params={"limit": limit, "fields": _PAPER_FIELDS_NO_TLDR},
        )
        return [self._parse_paper(item["citedPaper"]) for item in data.get("data", [])]

    def search_similar(self, paper_id: str, limit: int = config.SIMILAR_LIMIT) -> list[Paper]:
        """Find similar papers via the Recommendations API.

        The recommendations endpoint only accepts Semantic Scholar IDs.
        If a non-SS ID is given (DOI, ArXiv, etc.), it is resolved first.
        """
        if not paper_id.isalnum():
            resolved = self.get_paper(paper_id)
            paper_id = resolved.paper_id

        data = self._request(
            f"{self.RECOMMENDATIONS_API}/papers/forpaper/{paper_id}",
            params={"limit": limit, "fields": _PAPER_FIELDS_NO_TLDR, "from": "all-cs"},
        )
        return [self._parse_paper(item) for item in data.get("recommendedPapers", [])]


# ---------------------------------------------------------------------------
# Module-level convenience functions
# ---------------------------------------------------------------------------

# Prefixes that identify a structured paper ID (case-insensitive).
_ID_PREFIXES = ("arxiv:", "doi:", "corpusid:", "pmid:", "mag:", "acl:", "url:")


def _looks_like_paper_id(s: str) -> bool:
    """Heuristic: return True if *s* looks like a structured paper ID or hash."""
    lower = s.lower()
    if any(lower.startswith(p) for p in _ID_PREFIXES):
        return True
    # Semantic Scholar 40-char hex hash
    if len(s) == 40 and all(c in "0123456789abcdef" for c in lower):
        return True
    return False


def _looks_like_url(s: str) -> bool:
    return s.startswith("http://") or s.startswith("https://")


def resolve_paper(query: str) -> Paper:
    """Resolve a paper from an ID, URL, or free-text name.

    Resolution order:
    1. If *query* looks like a known ID format (ARXIV:xxx, DOI:xxx, …) or a
       40-char hex hash, fetch it directly via ``get_paper``.
    2. If *query* looks like a URL, wrap it as ``URL:<query>`` and fetch.
    3. Otherwise, treat it as a keyword search and return the top result.

    Raises ``LookupError`` if nothing is found.
    """
    client = SemanticScholarClient()

    if _looks_like_paper_id(query):
        return client.get_paper(query)

    if _looks_like_url(query):
        return client.get_paper(f"URL:{query}")

    # Fall back to keyword search
    results = client.search_papers(query, limit=1)
    if not results:
        raise LookupError(f"No papers found for query: {query}")
    return results[0]


def search_papers(query: str, limit: int = config.SEARCH_LIMIT) -> list[Paper]:
    """Keyword search for papers."""
    return SemanticScholarClient().search_papers(query, limit)


def get_paper(paper_id: str) -> Paper:
    """Get full details for a single paper by ID."""
    return SemanticScholarClient().get_paper(paper_id)


def get_citations(paper_id: str, limit: int = config.CITATION_LIMIT) -> list[Paper]:
    """Get papers that cite the given paper."""
    return SemanticScholarClient().get_citations(paper_id, limit)


def get_references(paper_id: str, limit: int = config.CITATION_LIMIT) -> list[Paper]:
    """Get papers referenced by the given paper."""
    return SemanticScholarClient().get_references(paper_id, limit)


def search_similar(paper_id: str, limit: int = config.SIMILAR_LIMIT) -> list[Paper]:
    """Find similar papers via the Recommendations API."""
    return SemanticScholarClient().search_similar(paper_id, limit)
