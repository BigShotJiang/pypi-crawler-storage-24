"""Researchbot — a Git-based AI research assistant."""
