"""PDF download utilities."""

import re
from dataclasses import dataclass, field
from hashlib import sha256
from pathlib import Path

import httpx

from researchbot import config, scholar


@dataclass
class PaperContent:
    markdown: str
    cache_path: Path
    title: str
    authors: list[str]
    year: int | None
    venue: str | None
    citation_count: int | None
    image_paths: dict[str, Path] = field(default_factory=dict)


def _sanitize_id(paper_id: str) -> str:
    """Make a paper ID safe for use as a filesystem path component."""
    return paper_id.replace(":", "_").replace("/", "_")


def _strip_references(markdown: str) -> str:
    """Remove the References section from a paper's markdown.

    Looks for common patterns like:
    - # References
    - ## References
    - # REFERENCES
    - ## Bibliography

    Returns the markdown with everything from the References heading onward removed.
    """
    # Try to find References section (case-insensitive, with optional ## or #)
    patterns = [
        r"\n#+\s*References\s*\n",
        r"\n#+\s*REFERENCES\s*\n",
        r"\n#+\s*Bibliography\s*\n",
        r"\n#+\s*BIBLIOGRAPHY\s*\n",
    ]

    for pattern in patterns:
        match = re.search(pattern, markdown, re.IGNORECASE)
        if match:
            # Return everything before the References heading
            return markdown[:match.start()].rstrip()

    # If no References section found, return as-is
    return markdown


def _extract_arxiv_id(s: str) -> str | None:
    """Extract arXiv ID from various formats (ARXIV:xxx, arXiv URLs)."""
    # ARXIV:2106.15928 or arxiv:2106.15928
    if s.upper().startswith("ARXIV:"):
        return s.split(":", 1)[1]
    # https://arxiv.org/abs/2106.15928 or https://arxiv.org/pdf/2106.15928.pdf
    match = re.match(r"https?://arxiv\.org/(?:abs|pdf)/([^/.]+(?:\.[^/.]+)?)", s)
    if match:
        return match.group(1)
    return None


def _looks_like_pdf_url(url: str) -> bool:
    """Check if a URL appears to be a direct PDF link."""
    lower = url.lower()
    # Common PDF URL patterns
    if lower.endswith(".pdf"):
        return True
    # OpenReview PDF links: https://openreview.net/pdf?id=xxx
    if "openreview.net/pdf" in lower:
        return True
    return False


def _url_to_canonical_id(url: str) -> str:
    """Generate a stable canonical ID from a URL (for caching)."""
    # Use a short hash of the URL to avoid filesystem issues with long URLs
    return f"URL_{sha256(url.encode()).hexdigest()[:16]}"


def resolve_pdf_url(paper_id: str) -> tuple[str, str]:
    """Get a downloadable PDF URL for a paper.

    Accepts:
        - Structured IDs: ARXIV:xxx, DOI:xxx, CorpusId:xxx, etc.
        - arXiv URLs: https://arxiv.org/abs/xxx or https://arxiv.org/pdf/xxx.pdf
        - Direct PDF URLs: https://example.com/paper.pdf
        - Paper titles: resolved via Semantic Scholar search

    Returns:
        A ``(pdf_url, canonical_id)`` tuple where *canonical_id* is the
        identifier used for caching (e.g. ``ARXIV:1706.03762``).
    """
    # Case 1: Direct PDF URL - use it directly (skip Semantic Scholar lookup)
    if _looks_like_pdf_url(paper_id):
        return paper_id, _url_to_canonical_id(paper_id)

    # Case 2: arXiv reference (ID or URL) - construct PDF URL directly
    arxiv_id = _extract_arxiv_id(paper_id)
    if arxiv_id:
        canonical_id = f"ARXIV:{arxiv_id}"
        return f"https://arxiv.org/pdf/{arxiv_id}.pdf", canonical_id

    # Case 3: Other formats (DOI, paper title, etc.) - resolve via Semantic Scholar
    paper = scholar.resolve_paper(paper_id)

    # Build a stable cache key — prefer the caller's original ID when it
    # looks like a structured ID, otherwise use the Semantic Scholar hash.
    canonical_id = paper_id if scholar._looks_like_paper_id(paper_id) else paper.paper_id

    # Use openAccessPdf if available
    if paper.pdf_url:
        return paper.pdf_url, canonical_id

    # Try to use arXiv ID from the resolved paper metadata
    # (works when searching by title finds an arXiv paper)
    if paper.arxiv_id:
        return f"https://arxiv.org/pdf/{paper.arxiv_id}.pdf", f"ARXIV:{paper.arxiv_id}"

    raise LookupError(f"No PDF available for paper: {paper_id} (resolved to {paper.title!r})")


def download_pdf(url: str, paper_id: str) -> Path:
    """Download a PDF to the local cache. Returns the path to the cached file."""
    sanitized = _sanitize_id(paper_id)
    pdf_path = config.PDF_CACHE_DIR / f"{sanitized}.pdf"

    if pdf_path.exists():
        return pdf_path

    config.PDF_CACHE_DIR.mkdir(parents=True, exist_ok=True)

    resp = httpx.get(url, timeout=60.0, follow_redirects=True)
    if resp.status_code != 200:
        raise RuntimeError(f"Failed to download PDF: HTTP {resp.status_code} from {url}")

    pdf_path.write_bytes(resp.content)
    return pdf_path


def ocr_local_pdf(pdf_path: str) -> PaperContent:
    """OCR a local PDF file, skipping Semantic Scholar resolution.

    Use this for local PDF files (e.g., drafts) that aren't in Semantic Scholar.
    For published papers, use :func:`get_paper_text` instead.

    Args:
        pdf_path: Path to a local PDF file.

    Returns:
        A :class:`PaperContent` with the extracted markdown text.
    """
    from researchbot import ocr

    path = Path(pdf_path).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    # Cache key from file path hash
    cache_id = f"LOCAL_{sha256(str(path).encode()).hexdigest()[:16]}"

    # Stub metadata (no Semantic Scholar lookup for local files)
    stub = scholar.Paper(
        paper_id=cache_id,
        title=path.stem,
        abstract=None,
        authors=[],
        year=None,
        venue=None,
        citation_count=None,
        url=None,
        pdf_url=None,
        tldr=None,
        arxiv_id=None,
    )

    sanitized = _sanitize_id(cache_id)
    ocr_dir = config.OCR_CACHE_DIR / sanitized
    cached = ocr._load_from_cache(ocr_dir, stub)
    if cached is not None:
        return cached

    return ocr.pdf_to_markdown(path, cache_id, stub)


def get_paper_text(paper_id: str, include_images: bool = False) -> PaperContent:
    """Get the full text of a paper as markdown. Downloads and OCRs if needed.

    *paper_id* can be a structured ID (``ARXIV:xxx``, ``DOI:xxx``, …), a URL,
    or a free-text paper name.  Resolution is handled by
    :func:`scholar.resolve_paper`.
    """
    from researchbot import ocr

    # Resolve paper to get metadata
    paper_metadata = scholar.resolve_paper(paper_id)

    # Check OCR cache first to avoid unnecessary API calls.
    # For free-text names we won't hit cache on the first call, but after
    # resolution the canonical_id from resolve_pdf_url will be used.
    sanitized = _sanitize_id(paper_id)
    ocr_dir = config.OCR_CACHE_DIR / sanitized
    cached = ocr._load_from_cache(ocr_dir, paper_metadata)
    if cached is not None:
        return cached

    url, canonical_id = resolve_pdf_url(paper_id)
    # Re-check cache under canonical_id (may differ from original paper_id)
    if canonical_id != paper_id:
        sanitized_canonical = _sanitize_id(canonical_id)
        ocr_dir_canonical = config.OCR_CACHE_DIR / sanitized_canonical
        cached = ocr._load_from_cache(ocr_dir_canonical, paper_metadata)
        if cached is not None:
            return cached

    pdf_path = download_pdf(url, canonical_id)
    return ocr.pdf_to_markdown(pdf_path, canonical_id, paper_metadata)
