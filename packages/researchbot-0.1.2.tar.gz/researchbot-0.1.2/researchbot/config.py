"""Configuration for researchbot."""

import os
from pathlib import Path

from dotenv import load_dotenv

# Two-tier .env loading:
#   1. ~/.config/researchbot/.env  (user-level, higher priority — loaded first)
#   2. <project_root>/.env         (local dev fallback)
# Shell environment variables always take precedence over both.
_USER_CONFIG_DIR = Path(os.getenv("XDG_CONFIG_HOME", Path.home() / ".config")) / "researchbot"
_USER_ENV = _USER_CONFIG_DIR / ".env"
_PROJECT_ENV = Path(__file__).parent.parent / ".env"

load_dotenv(_USER_ENV)      # Higher priority (loaded first → won't be overwritten)
load_dotenv(_PROJECT_ENV)   # Fallback for local dev

# API keys (loaded from environment)
SEMANTIC_SCHOLAR_API_KEY = os.getenv("SEMANTIC_SCHOLAR_API_KEY", "")
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")

# OCR provider: "mistral" or "deepseek"
OCR_PROVIDER = os.getenv("RESEARCHBOT_OCR_PROVIDER", "mistral")

# Local cache for downloaded PDFs and OCR results
CACHE_DIR = Path(os.getenv("RESEARCHBOT_CACHE_DIR", Path.home() / ".cache" / "researchbot"))
PDF_CACHE_DIR = CACHE_DIR / "pdfs"
OCR_CACHE_DIR = CACHE_DIR / "ocr"

# Semantic Scholar defaults
SEARCH_LIMIT = 20
CITATION_LIMIT = 50
SIMILAR_LIMIT = 20
