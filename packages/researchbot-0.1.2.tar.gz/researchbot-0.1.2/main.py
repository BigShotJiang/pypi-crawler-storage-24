def main():
    print("Hello from researchbot!")


if __name__ == "__main__":
    main()
