"""mlvault CLI — artifact capture and restore for ML training runs."""

import subprocess
import sys
import tarfile
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

import click

from mlvault import crypto, snapshot, storage

_CREDENTIALS_FILE = Path.home() / ".mlvault" / "credentials"
_DEFAULT_API_URL = "https://mlvault-api-production.up.railway.app"


def _make_run_id(project: str) -> str:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    short = uuid.uuid4().hex[:6]
    return f"{project}_{ts}_{short}"


@click.group()
def main():
    """ML Training Vault — immutable snapshots of ML training runs."""


@main.command()
def init():
    """Configure your mlvault API key.

    Get a key at obsideo.io/mlvault-beta, then run:

        mlvault init
    """
    import requests as _requests

    click.echo("mlvault init")
    click.echo("")

    api_key = click.prompt("Paste your mlvault API key").strip()
    if not api_key:
        click.secho("No API key provided.", fg="red")
        sys.exit(1)

    click.echo("Validating key...", nl=False)

    try:
        resp = _requests.get(
            f"{_DEFAULT_API_URL}/v1/ping",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10,
        )
        if resp.status_code == 401:
            click.echo("")
            click.secho("Invalid API key. Check your key and try again.", fg="red")
            sys.exit(1)
        resp.raise_for_status()
        click.echo(" ok")
    except _requests.RequestException as e:
        click.echo("")
        click.secho(f"Could not reach mlvault API: {e}", fg="red")
        sys.exit(1)

    _CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CREDENTIALS_FILE.write_text(
        f"MLVAULT_API_KEY={api_key}\n"
        f"MLVAULT_API_URL={_DEFAULT_API_URL}\n"
    )
    _CREDENTIALS_FILE.chmod(0o600)

    click.echo("")
    click.secho("You're all set.", fg="green")
    click.echo("Test with: mlvault run python train.py")


@main.command(context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument("command", nargs=-1, required=True)
@click.option("--collect", "-c", default="./outputs", show_default=True,
              help="Directory to collect artifacts from after the run.")
@click.option("--project", "-p", default="default", show_default=True,
              help="Project name (used in run ID).")
def run(command, collect, project):
    """Run a training command and snapshot its artifacts.

    Example: mlvault run --collect ./outputs python train.py
    """
    run_id = _make_run_id(project)
    collect_dir = Path(collect).resolve()
    entrypoint = " ".join(command)

    click.echo(f"Run ID : {run_id}")
    click.echo(f"Collect: {collect_dir}")
    click.echo(f"Command: {entrypoint}")
    click.echo("")

    # Execute training command
    click.echo("-- Training started --")
    proc = subprocess.run(list(command))
    if proc.returncode != 0:
        click.secho(f"\nCommand exited with code {proc.returncode}. Snapshotting anyway.", fg="yellow")

    click.echo("\n-- Collecting artifacts --")
    if not collect_dir.exists():
        click.secho(f"Collect directory not found: {collect_dir}", fg="red")
        sys.exit(1)

    try:
        manifest, tar_path = snapshot.build_snapshot(run_id, project, entrypoint, collect_dir)
    except ValueError as e:
        click.secho(str(e), fg="red")
        sys.exit(1)

    click.echo(f"  {len(manifest['artifacts'])} artifact(s) -> {tar_path.name}")

    click.echo("\n-- Encrypting --")
    enc_path = crypto.encrypt_bundle(tar_path, run_id)
    click.echo(f"  {enc_path.name} ({enc_path.stat().st_size / 1024:.1f} KB)")

    click.echo("\n-- Uploading --")
    click.echo("  Storing to cloud — this may take a minute...")
    key = storage.remote_key_for(run_id)
    try:
        cid = storage.upload(enc_path, key)
        snapshot.update_manifest_jackal_path(run_id, cid)
        click.secho(f"\nDone. Run archived: {run_id}", fg="green")
        click.echo(f"Remote : {cid}")
    except (EnvironmentError, RuntimeError) as e:
        click.secho(f"\nUpload failed: {e}", fg="red")
        click.echo(f"Bundle saved locally: {enc_path}")
        sys.exit(1)


@main.command()
@click.argument("run_id")
@click.option("--out", "-o", default=None,
              help="Output directory. Defaults to ./<run_id>.")
def restore(run_id, out):
    """Download and decrypt a stored run.

    Example: mlvault restore default_20240307_143022_abc123
    """
    out_dir = Path(out) if out else Path.cwd() / run_id

    try:
        manifest = snapshot.load_manifest(run_id)
    except FileNotFoundError as e:
        click.secho(str(e), fg="red")
        sys.exit(1)

    cid = manifest.get("jackal_path")
    if not cid:
        click.secho("This run has no recorded remote path — was it uploaded?", fg="red")
        sys.exit(1)

    click.echo(f"Restoring {run_id} -> {out_dir}")

    with tempfile.TemporaryDirectory() as tmp:
        enc_path = Path(tmp) / "bundle.enc"

        click.echo("-- Downloading --")
        try:
            storage.download(cid, enc_path)
        except (EnvironmentError, RuntimeError) as e:
            click.secho(f"Download failed: {e}", fg="red")
            sys.exit(1)

        click.echo("-- Decrypting --")
        try:
            plaintext = crypto.decrypt_bundle(enc_path, run_id)
        except FileNotFoundError as e:
            click.secho(str(e), fg="red")
            sys.exit(1)

        tar_path = Path(tmp) / "bundle.tar.gz"
        tar_path.write_bytes(plaintext)

        click.echo("-- Extracting --")
        out_dir.mkdir(parents=True, exist_ok=True)
        with tarfile.open(tar_path, "r:gz") as tar:
            tar.extractall(out_dir)

    click.secho(f"\nRestored to: {out_dir}", fg="green")


@main.command("list")
def list_runs():
    """List all locally tracked runs."""
    runs = snapshot.list_runs()
    if not runs:
        click.echo("No runs found. Use 'mlvault run' to create one.")
        return

    click.echo(f"{'RUN ID':<45} {'PROJECT':<15} {'ARTIFACTS':>9}  {'UPLOADED':>8}")
    click.echo("-" * 85)
    for m in runs:
        uploaded = "yes" if m.get("jackal_path") else "no"
        click.echo(
            f"{m['run_id']:<45} {m['project']:<15} {len(m['artifacts']):>9}  {uploaded:>8}"
        )


@main.command()
@click.argument("mlflow_run_id")
@click.option("--project", "-p", default=None,
              help="Project name override (default: read from staging meta).")
def commit(mlflow_run_id, project):
    """Bundle and upload staged MLflow artifacts to mlvault storage.

    Run this after an MLflow training run to push staged artifacts:

        mlvault commit <mlflow_run_id>

    The mlflow_run_id appears in the MLflow UI or in mlflow.active_run().info.run_id.
    """
    import sys as _sys
    _sys.path.insert(0, str(Path(__file__).parent.parent / "mlvault-mlflow"))
    from mlvault_mlflow import staging as mlflow_staging

    try:
        meta = mlflow_staging.get_meta(mlflow_run_id)
    except FileNotFoundError:
        click.secho(f"No staged artifacts found for run: {mlflow_run_id}", fg="red")
        click.echo("Did you set MLFLOW_ARTIFACT_URI=mlvault://<project> before training?")
        sys.exit(1)

    proj = project or meta.get("project", "mlflow")
    staged_files = mlflow_staging.list_staged_files(mlflow_run_id)
    if not staged_files:
        click.secho("Staging area is empty — nothing to commit.", fg="red")
        sys.exit(1)

    run_id = _make_run_id(proj)
    artifacts_root = Path.home() / ".mlvault" / "mlflow-staging" / mlflow_run_id / "artifacts"

    click.echo(f"MLflow run : {mlflow_run_id}")
    click.echo(f"Run ID     : {run_id}")
    click.echo(f"Artifacts  : {len(staged_files)} file(s)")
    click.echo("")

    # Build manifest + tar from staging area
    click.echo("-- Bundling staged artifacts --")
    run_dir = snapshot.RUNS_DIR / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    artifact_entries = []
    tar_path = run_dir / f"{run_id}.tar.gz"
    with tarfile.open(tar_path, "w:gz") as tar:
        for f in sorted(staged_files):
            rel = f.relative_to(artifacts_root)
            tar.add(f, arcname=str(rel))
            artifact_entries.append({
                "name": f.name,
                "path": str(rel).replace("\\", "/"),
                "size": f.stat().st_size,
            })

    manifest = {
        "run_id": run_id,
        "project": proj,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "entrypoint": f"mlflow:{mlflow_run_id}",
        "collect_dir": str(artifacts_root),
        "artifacts": artifact_entries,
        "jackal_path": None,
    }
    (run_dir / "manifest.json").write_text(__import__("json").dumps(manifest, indent=2))
    click.echo(f"  {len(artifact_entries)} artifact(s) -> {tar_path.name}")

    click.echo("\n-- Encrypting --")
    enc_path = crypto.encrypt_bundle(tar_path, run_id)
    click.echo(f"  {enc_path.name} ({enc_path.stat().st_size / 1024:.1f} KB)")

    click.echo("\n-- Uploading --")
    click.echo("  Storing to cloud — this may take a minute...")
    key = storage.remote_key_for(run_id)
    try:
        cid = storage.upload(enc_path, key)
        snapshot.update_manifest_jackal_path(run_id, cid)
        click.secho(f"\nDone. Artifacts committed: {run_id}", fg="green")
        click.echo(f"Remote : {cid}")
        click.echo(f"\nTo restore:  mlvault restore {run_id}")
    except (EnvironmentError, RuntimeError) as e:
        click.secho(f"\nUpload failed: {e}", fg="red")
        click.echo(f"Bundle saved locally: {enc_path}")
        sys.exit(1)


@main.command()
@click.argument("run_id")
def log(run_id):
    """Show manifest details for a run."""
    try:
        manifest = snapshot.load_manifest(run_id)
    except FileNotFoundError as e:
        click.secho(str(e), fg="red")
        sys.exit(1)

    click.echo(f"Run ID   : {manifest['run_id']}")
    click.echo(f"Project  : {manifest['project']}")
    click.echo(f"Created  : {manifest['created_at']}")
    click.echo(f"Command  : {manifest['entrypoint']}")
    click.echo(f"Remote   : {manifest.get('jackal_path') or '(not uploaded)'}")
    click.echo(f"\nArtifacts ({len(manifest['artifacts'])}):")
    for a in manifest["artifacts"]:
        size_kb = a["size"] / 1024
        click.echo(f"  {a['path']:<40} {size_kb:>8.1f} KB")


@main.command()
@click.argument("run_id")
def verify(run_id):
    """Check Proof of Persistence status for a stored run.

    Queries the Jackal blockchain to confirm that storage providers
    can cryptographically prove they still hold your data.

    Example: mlvault verify default_20240307_143022_abc123
    """
    try:
        manifest = snapshot.load_manifest(run_id)
    except FileNotFoundError as e:
        click.secho(str(e), fg="red")
        sys.exit(1)

    cid = manifest.get("jackal_path")
    if not cid:
        click.secho("This run has no recorded remote path — was it uploaded?", fg="red")
        sys.exit(1)

    click.echo(f"Verifying {run_id}...")
    click.echo(f"Remote: {cid}")
    click.echo("")

    try:
        data = storage.verify_pop(cid)
    except (EnvironmentError, RuntimeError) as e:
        click.secho(f"Verification failed: {e}", fg="red")
        sys.exit(1)

    if not data.get("verified") and data.get("verified") is not None:
        click.secho("STATUS: NOT VERIFIED", fg="yellow", bold=True)
    elif data.get("verified"):
        click.secho("STATUS: VERIFIED", fg="green", bold=True)
    else:
        click.secho("STATUS: UNKNOWN", fg="yellow")

    summary = data.get("summary", {})
    click.echo(f"\n  Current block   : {data.get('currentBlock', '?')}")
    interval = data.get('proofWindow') or (data.get('files', [{}])[0].get('proofInterval'))
    click.echo(f"  Proof interval  : {interval or '?'} blocks")
    click.echo(f"  Providers       : {summary.get('totalProviders', '?')}")
    click.echo(f"  Fresh proofs    : {summary.get('freshProofs', '?')}")
    click.echo(f"  Stale proofs    : {summary.get('staleProofs', '?')}")

    proofs = data.get("proofs", [])
    if proofs:
        click.echo(f"\nProvider Details:")
        for p in proofs:
            status = click.style("fresh", fg="green") if p.get("isFresh") else click.style("STALE", fg="red")
            blocks_ago = p.get("blocksSinceProof", "?")
            click.echo(f"  {p.get('prover', '?')[:20]}...  last proof: {blocks_ago} blocks ago  [{status}]")
