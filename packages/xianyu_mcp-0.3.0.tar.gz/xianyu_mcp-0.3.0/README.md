# xianyu-mcp

`xianyu-mcp` 是一个面向 MCP 客户端使用者的闲鱼 MCP Server。它通过 Playwright 和闲鱼网页能力，提供登录、商品发布、收藏管理、商品查询、卖家主页读取等能力。

你可以把它接入支持 MCP 的客户端，例如 Codex、Claude Code、MCP Inspector，或任何兼容 `stdio` / `streamable_http` 的 MCP 工具。

## 它能做什么

- 登录闲鱼账号，获取扫码二维码并轮询登录结果
- 登录二维码会保存到本地 `screenshots/` 目录，并返回可供用户打开的图片文件提示
- 发布商品、下架商品、删除商品
- 搜索商品、读取商品详情、读取首页推荐
- 添加收藏、取消收藏、读取收藏列表
- 读取我发布的商品列表、读取卖家主页信息
- 通过 `analyze_goods` 工具生成商品分析提示词和分析上下文数据

当前项目实际注册了 **16 个 MCP tools**。

## 环境要求

- Python 3.10 或更高版本
- 可正常启动的 Chromium 浏览器环境
- 能访问闲鱼网页

## 通过 uvx 使用（推荐）

无需手动安装，uvx 会自动处理。

### Claude Desktop 配置

在 `~/Library/Application Support/Claude/claude_desktop_config.json` 中添加：

```json
{
  "mcpServers": {
    "xianyu": {
      "command": "uvx",
      "args": ["xianyu-mcp"],
      "env": {
        "HEADLESS": "true"
      }
    }
  }
}
```

### Claude Code 配置

```bash
claude mcp add xianyu -- uvx xianyu-mcp
```

### 首次运行

首次运行会自动安装 Playwright Chromium（约需 1-2 分钟）。

---

## 安装

下面的安装命令适用于 Windows、macOS 和 Linux：

```sh
python -m pip install .
python -m playwright install chromium
```

如果你想使用虚拟环境，可以先创建，但这不是必须的：

```sh
python -m venv .venv

macOS / Linux：
source .venv/bin/activate

Windows PowerShell：
.venv\Scripts\Activate.ps1

Windows CMD：
.venv\Scripts\activate.bat
```

## 快速开始

### 方式一：默认作为 `stdio` MCP Server 运行

默认启动方式是 `stdio`，适合 Claude Desktop / Claude Code 等 MCP 客户端以子进程方式拉起。

```sh
xianyu-mcp
```

如果命令行入口不可用，也可以这样启动：

```sh
python -m xianyu_mcp
```

### 方式二：作为本地 `streamable_http` MCP Server 运行

如果需要常驻服务供多个客户端复用，可切换到 `streamable_http`：

```env
MCP_TRANSPORT=streamable_http
```

然后启动服务：

```sh
xianyu-mcp
```

默认地址为：

```text
http://127.0.0.1:18000/mcp
```

## Docker 运行

如果你更希望把它作为常驻 MCP 服务运行，可以直接使用 Docker Compose。

项目已提供 [Dockerfile](./Dockerfile) 和 [docker-compose.yml](./docker-compose.yml)。

启动：

```sh
docker compose up -d --build
```

查看日志：

```sh
docker compose logs -f
```

停止：

```sh
docker compose down
```

默认情况下：

- 容器内监听 `0.0.0.0:18000`
- 宿主机访问地址为 `http://127.0.0.1:18000/mcp`
- `./browser_data` 挂载到容器内 `/app/browser_data`
- `./screenshots` 挂载到容器内 `/app/screenshots`
- 自动读取当前目录的 `.env`

## 配置

你可以通过 `.env` 调整运行行为。常用项如下：

| 变量 | 默认值 | 说明 |
|---|---|---|
| `HEADLESS` | `true` | 是否使用无头浏览器 |
| `PAGE_TIMEOUT` | `30000` | 页面操作超时，单位毫秒 |
| `SLOW_MO` | `0` | 浏览器慢动作延时，单位毫秒 |
| `COOKIE_AUTO_SYNC_ENABLED` | `true` | 是否开启 Cookie 自动同步 |
| `COOKIE_SYNC_INTERVAL_SECONDS` | `600` | Cookie 同步间隔，单位秒 |
| `COOKIE_SYNC_TIMEOUT_SECONDS` | `30` | 单次 Cookie 同步超时，单位秒 |
| `AUTO_SCREENSHOT` | `false` | 是否自动截图 |
| `SCREENSHOT_DIR` | `./screenshots` | 截图目录 |
| `LOG_LEVEL` | `INFO` | 日志级别 |
| `MCP_TRANSPORT` | `stdio` | 传输模式：`stdio` 或 `streamable_http` |
| `MCP_TOOL_TIMEOUT_SECONDS` | `10` | 单个工具调用超时，单位秒 |
| `MCP_HTTP_HOST` | `127.0.0.1` | HTTP 模式监听地址 |
| `MCP_HTTP_PORT` | `18000` | HTTP 模式监听端口 |
| `MCP_STREAMABLE_HTTP_PATH` | `/mcp` | HTTP 模式路径 |

例如，如果你想看到浏览器界面，可以在 `.env` 中设置：

```env
HEADLESS=false
```

## 接入 MCP 客户端

### OpenClaw（通过MCPorter）

把以下命令发送给OpenClaw。

```sh
帮我安装这个MCP：npx mcporter config add xianyu http://127.0.0.1:18000/mcp
```

### MCP Inspector

调试本地 `stdio` 服务时，先在 `.env` 中设置：

```env
MCP_TRANSPORT=stdio
```

然后执行：

```sh
npx @modelcontextprotocol/inspector python -m xianyu_mcp.server
```

调试 HTTP 服务：

```sh
npx @modelcontextprotocol/inspector
```

然后在 Inspector 页面中选择 `Streamable HTTP`，再填入：

```text
http://127.0.0.1:18000/mcp
```

其他主流客户端暂未测试，有兴趣的可以自己试试。

## Tools 一览

### 账号登录

- `check_login_status`：检查当前是否已登录
- `get_login_qrcode`：获取登录二维码（二维码图片保存到本地 `screenshots/`）
- `check_login_scan_result`：检查扫码结果（人脸验证时同样返回本地二维码文件提示）
- `logout`：退出登录并清理本地会话

### 商品查询与收藏

- `search_goods`：按关键词搜索商品（支持价格/排序/快速筛选）
- `get_home_goods`：读取首页推荐商品
- `get_goods_detail`：读取商品详情（支持传入商品 ID 或链接）
- `get_favorites`：读取收藏列表
- `add_favorite`：收藏商品
- `remove_favorite`：取消收藏

### 发布与我的商品管理

- `get_my_goods`：读取我发布的商品列表
- `publish_goods`：发布商品
- `take_down_goods`：下架商品
- `delete_goods`：删除商品

### 卖家与分析

- `get_seller_profile`：读取卖家主页信息（默认含商品与评价，最多各 10 条）
- `analyze_goods`：生成商品风险与价格分析提示词（返回 prompt + 商品/卖家数据）

## 使用建议

- 默认使用 `stdio`，适合 Claude Desktop / Claude Code 等 MCP 客户端以子进程方式拉起
- 如果需要常驻服务给多个客户端复用，可切换到 `streamable_http`
- 首次启动会拉起 Playwright/Chromium，客户端的启动超时建议适当放宽
- 登录、发布商品这类依赖页面状态的操作，建议先确认账号已登录
- 不考虑制作购买和聊天的工具。
