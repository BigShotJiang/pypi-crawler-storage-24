from xianyu_mcp.server import main

main()
