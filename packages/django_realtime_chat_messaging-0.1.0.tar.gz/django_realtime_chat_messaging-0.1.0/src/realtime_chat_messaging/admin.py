from django.contrib import admin

# Register your models here.
from .models import  Message,Session, Room, GroupChat, Channel, OneToOneChat, ReadReceipt, Reaction, ChatNotification, MessageMediaAsset


admin.site.register(Message)
admin.site.register(Session)
admin.site.register(Room)
admin.site.register(GroupChat)
admin.site.register(Channel)
admin.site.register(OneToOneChat)
admin.site.register(ReadReceipt)
admin.site.register(Reaction)
admin.site.register(ChatNotification)
admin.site.register(MessageMediaAsset)
