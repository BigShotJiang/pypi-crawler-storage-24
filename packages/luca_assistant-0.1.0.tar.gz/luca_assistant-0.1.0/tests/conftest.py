"""Test fixtures — in-memory SQLite database with seed data."""

from __future__ import annotations

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from luca_assistant.db.engine import reset_session_factory
from luca_assistant.db.models import Base
from luca_assistant.db.seed import seed_all


@pytest.fixture()
def db_session(monkeypatch: pytest.MonkeyPatch) -> Session:
    """Create an in-memory SQLite database with seed data."""
    engine = create_engine("sqlite:///:memory:", echo=False)
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine)
    session = factory()

    seed_all(session)

    # Patch get_session to return our test session
    monkeypatch.setattr("luca_assistant.db.engine._session_factory", factory)
    monkeypatch.setattr("luca_assistant.db.engine._session_factory_path", None)

    yield session

    session.close()
    reset_session_factory()


@pytest.fixture()
def clean_session(monkeypatch: pytest.MonkeyPatch) -> Session:
    """Create an in-memory SQLite database without seed data."""
    engine = create_engine("sqlite:///:memory:", echo=False)
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine)
    session = factory()

    monkeypatch.setattr("luca_assistant.db.engine._session_factory", factory)
    monkeypatch.setattr("luca_assistant.db.engine._session_factory_path", None)

    yield session

    session.close()
    reset_session_factory()
