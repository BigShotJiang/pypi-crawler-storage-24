---
description: "Look up bank application rules like Chase 5/24, Amex lifetime language, Citi 8/65."
argument-hint: "bank name"
allowed-tools: mcp__luca-assistant__luca_get_bank_rules, mcp__luca-assistant__luca_check_chase_524_status
---

Look up the application rules for the bank the user is asking about using luca_get_bank_rules.

If they ask about Chase, also check their 5/24 status with luca_check_chase_524_status.

Bank to look up: $ARGUMENTS

Respond in the same language the user writes in.
