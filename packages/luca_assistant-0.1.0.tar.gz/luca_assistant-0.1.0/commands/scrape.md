---
description: "Scrape credit card community sources for fresh data - Doctor of Credit, Reddit, forums."
argument-hint: "source"
allowed-tools: mcp__luca-assistant__luca_scrape_source, mcp__luca-assistant__luca_search_scraped, mcp__luca-assistant__luca_get_scrape_status
---

First check scrape status with luca_get_scrape_status to see what is fresh.

If the user specified a source, scrape it with luca_scrape_source.
If no source specified, scrape all available sources.

Available sources: doc (Doctor of Credit), reddit (r/CreditCards, r/churning), forum (US Card Forum)

Source to scrape: $ARGUMENTS

Respond in the same language the user writes in.
