---
description: "Look up credit card details, benefits, and current sign-up bonuses."
argument-hint: "card name"
allowed-tools: mcp__luca-assistant__luca_query_card_details, mcp__luca-assistant__luca_find_highest_offers
---

Look up details for the card the user is asking about using luca_query_card_details.

If the user is asking about the best offers generally (not a specific card), use luca_find_highest_offers instead.

Card to look up: $ARGUMENTS

Respond in the same language the user writes in.
