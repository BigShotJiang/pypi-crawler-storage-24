---
description: "Show your credit card portfolio and Chase 5/24 status."
allowed-tools: mcp__luca-assistant__luca_get_user_portfolio, mcp__luca-assistant__luca_check_chase_524_status
---

Show the user their current portfolio using luca_get_user_portfolio, then check their Chase 5/24 status with luca_check_chase_524_status.

Summarize:
- Open cards and their annual fees
- 5/24 count and remaining slots
- Next card to fall off 5/24 (if any)
- Any upcoming annual fee dates

Respond in the same language the user writes in.
