---
description: "Compare two or more credit cards side by side - benefits, offers, and annual fees."
argument-hint: "card1, card2"
allowed-tools: mcp__luca-assistant__luca_compare_card_benefits
---

Compare the cards the user mentioned using luca_compare_card_benefits.

Highlight the key differences: annual fee, sign-up bonus value, category multipliers, and credits.

Give a recommendation based on the user's likely use case.

Cards to compare: $ARGUMENTS

Respond in the same language the user writes in.
