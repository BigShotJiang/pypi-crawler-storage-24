"""Configuration via frozen dataclasses + dotenv."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent


@dataclass(frozen=True)
class DBSettings:
    db_path: str = field(
        default_factory=lambda: os.getenv("DB_PATH", str(PROJECT_ROOT / "data" / "luca.db"))
    )


@dataclass(frozen=True)
class AppSettings:
    db: DBSettings = field(default_factory=DBSettings)


def get_settings() -> AppSettings:
    """Get application settings (singleton-like, creates fresh each call)."""
    return AppSettings()
