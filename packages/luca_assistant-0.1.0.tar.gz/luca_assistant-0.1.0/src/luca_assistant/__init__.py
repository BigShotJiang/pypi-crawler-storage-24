"""Luca Assistant - Credit card optimization AI agent."""

__version__ = "0.1.0"
