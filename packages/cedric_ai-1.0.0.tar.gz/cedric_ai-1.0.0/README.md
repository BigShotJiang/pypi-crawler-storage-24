# cedric-ai

Client Python pour interroger l'IA **Cédric** (propulsé par Ollama).

Gère automatiquement la **file d'attente** si le serveur est éteint — les requêtes sont exécutées dès qu'il rallume.

## Installation

```bash
pip install cedric-ai
```

## Utilisation rapide

```python
from cedric_ai import CedricAI

ai = CedricAI(host="ai.monsite.com", token="MON_TOKEN")

# Requête directe
reponse = ai.ask("C'est quoi Python ?")
print(reponse)
```

## Requête asynchrone (file d'attente)

Si le serveur est éteint, la requête est sauvegardée et exécutée automatiquement dès qu'il se rallume.

```python
from cedric_ai import CedricAI

ai = CedricAI(host="ai.monsite.com", token="MON_TOKEN")

# Ajouter en file d'attente
job_id = ai.ask_async("Explique la relativité")

# Attendre le résultat (bloquant, max 10 min)
result = ai.wait_for_result(job_id, timeout=600)
print(result)
```

## Avec callback

```python
def quand_ca_repond(job_id, reponse):
    print(f"Réponse reçue : {reponse}")

job_id = ai.ask_async("Salut !", callback=quand_ca_repond)
```

## Avec une personnalité personnalisée

```python
CEDRIC = "Tu t'appelles Cédric, tu as 16 ans, tu parles comme un ado français."

reponse = ai.ask("T'as passé une bonne journée ?", system=CEDRIC)
print(reponse)
```

## Statut de la file

```python
print(ai.queue_status())
# {'online': True, 'pending': 2, 'done': 5, 'errors': 0, 'total': 7}

ai.clear_done()  # Supprime les jobs terminés
```

## Paramètres

| Paramètre        | Défaut              | Description                                      |
|------------------|---------------------|--------------------------------------------------|
| `host`           | `"localhost"`       | Adresse du serveur                               |
| `port`           | `11434`             | Port Ollama                                      |
| `model`          | `"llama3"`          | Modèle à utiliser                                |
| `token`          | `None`              | Token d'authentification                         |
| `queue_mode`     | `True`              | Active la file d'attente automatique             |
| `queue_file`     | `"cedric_queue.json"` | Fichier de persistance de la file              |
| `retry_interval` | `30`                | Secondes entre chaque tentative si hors ligne    |
| `timeout`        | `120`               | Timeout par requête en secondes                  |
