# scraper2_hj3415/cli.py
from __future__ import annotations

import asyncio
import time
from collections.abc import Iterable, Sequence
from datetime import datetime, timezone
from typing import Annotated, cast, get_args

import typer
from contracts_hj3415.common.types import Endpoint
from db2_hj3415.universe.repo import list_latest_universe_codes
from logging_hj3415 import (
    current_log_level,
    reset_logging,
    setup_logging,
    to_pretty_json,
)
from scraper2_hj3415.app.composition import AppUsecases, build_usecases
from scraper2_hj3415.app.nfs.ports.ingest.nfs_ingest_port import NfsIngestPort
from scraper2_hj3415.app.settings import get_settings

# -----------------------------------------------------------------------------
# logging
# -----------------------------------------------------------------------------

setup_logging()
reset_logging(get_settings().log_level)
print(f"Current log level - {current_log_level()}")

# -----------------------------------------------------------------------------
# typer apps
# -----------------------------------------------------------------------------

app = typer.Typer(no_args_is_help=True)
nfs_app = typer.Typer(no_args_is_help=True, help="NFS 수집/저장")
dart_app = typer.Typer(no_args_is_help=True, help="OpenDART 공시 수집")
mi_app = typer.Typer(no_args_is_help=True, help="(reserved) MI commands")

app.add_typer(nfs_app, name="nfs")
app.add_typer(dart_app, name="dart")
app.add_typer(mi_app, name="mi")

# -----------------------------------------------------------------------------
# parameter aliases
# -----------------------------------------------------------------------------

ArgCode = Annotated[str, typer.Argument(help="종목코드 (예: 005930)")]
ArgEndpoint = Annotated[str, typer.Argument(help="c101|c103|c104|c106|c108|all")]

OptShow = Annotated[bool, typer.Option(help="결과 출력")]
OptAsOf = Annotated[
    str | None,
    typer.Option(help="배치 기준시각(UTC 권장). 예: 2026-01-09T05:00:00Z"),
]
OptUniverse = Annotated[str, typer.Option(help="유니버스 이름")]
OptLimit = Annotated[int, typer.Option(help="0=전체")]
OptChunk = Annotated[int, typer.Option(help="진행률 표시용 배치 크기")]

OptDartSDate = Annotated[
    str,
    typer.Option("--sdate", help="조회 시작일 (YYYYMMDD)"),
]
OptDartEDate = Annotated[
    str,
    typer.Option("--edate", help="조회 종료일 (YYYYMMDD)"),
]

# -----------------------------------------------------------------------------
# small helpers
# -----------------------------------------------------------------------------


def iter_endpoints(endpoint: str) -> list[str]:
    """
    endpoint arg를 ingest 속성명들("c101"...)로 변환.
    """
    ep = endpoint.strip().lower()
    if ep == "all":
        return list(get_args(Endpoint))

    valid = set(get_args(Endpoint))
    if ep not in valid:
        raise typer.BadParameter(
            f"endpoint must be one of {sorted(valid)} or 'all'. got={endpoint!r}"
        )
    return [ep]


def parse_asof(asof: str | None) -> datetime:
    """
    ISO8601 string -> UTC aware datetime.
    """
    if not asof or not asof.strip():
        return datetime.now(timezone.utc)

    s = asof.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"

    try:
        dt = datetime.fromisoformat(s)
    except ValueError as e:
        raise typer.BadParameter(
            f"--asof must be ISO8601 datetime (e.g. 2026-01-09T05:00:00Z). got={asof!r}"
        ) from e

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    return dt.astimezone(timezone.utc)


def format_elapsed(sec: float) -> str:
    if sec < 60:
        return f"{sec:.1f}s"
    m, s = divmod(int(sec), 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m {s}s"


def chunks(xs: Sequence[str], n: int) -> Iterable[list[str]]:
    if n <= 0:
        yield list(xs)
        return
    for i in range(0, len(xs), n):
        yield list(xs[i : i + n])


def get_ingest_uc(ucs: AppUsecases, ep: str) -> NfsIngestPort:
    try:
        return cast(NfsIngestPort, getattr(ucs.nfs.ingest, ep))
    except AttributeError as e:
        raise RuntimeError(f"ingest usecase not found: {ep!r}") from e


# -----------------------------------------------------------------------------
# internal runners
# -----------------------------------------------------------------------------


async def _run_ingest_many_with_progress(
    *,
    ucs: AppUsecases,
    endpoints: list[str],
    codes: list[str],
    sleep_sec: float,
    asof: datetime,
    chunk_size: int,
    progress_every: int,
) -> None:
    total = len(codes)
    if total == 0:
        typer.echo("(no codes)")
        return

    t0 = time.perf_counter()

    for ep in endpoints:
        ingest_uc = get_ingest_uc(ucs, ep)

        ok = 0
        fail = 0
        typer.echo(f"\n=== START: {ep} === total={total}, chunk_size={chunk_size}")

        for idx, batch in enumerate(chunks(codes, chunk_size), start=1):
            try:
                results = await ingest_uc.execute_many(
                    batch,
                    sleep_sec=sleep_sec,
                    asof=asof,
                )
                ok += len(results)
            except Exception as e:
                fail += len(batch)
                typer.echo(f"[WARN] batch failed: {type(e).__name__}: {e}")

            done = min(idx * chunk_size, total)
            if progress_every > 0 and (idx % progress_every == 0 or done == total):
                typer.echo(f"progress: {done}/{total} (ok={ok}, fail={fail})")

        typer.echo(f"=== DONE: {ep} === ok={ok}, fail={fail}, total={total}")

    elapsed = time.perf_counter() - t0
    typer.echo(f"\n⏱ elapsed time: {format_elapsed(elapsed)}")


# -----------------------------------------------------------------------------
# nfs commands
# -----------------------------------------------------------------------------


@nfs_app.command("one")
def nfs_one(
    code: ArgCode,
    endpoint: ArgEndpoint,
    show: OptShow = True,
    asof: OptAsOf = None,
) -> None:
    code = code.strip()
    if not code:
        raise typer.BadParameter("code는 비어있을 수 없습니다.")

    settings = get_settings()
    resolved_sink = settings.nfs_sink
    resolved_sleep_sec = settings.scraper_sleep_sec_default

    if resolved_sink == "memory" and not show:
        typer.echo("memory sink에서는 출력 결과를 항상 보여줍니다.")
        show = True

    endpoints = iter_endpoints(endpoint)
    run_asof = parse_asof(asof)

    async def _run() -> None:
        ucs = build_usecases(nfs_sink=resolved_sink)

        try:
            if resolved_sink == "mongo":
                await ucs.resources.bootstrap()

            for ep in endpoints:
                ingest_uc = get_ingest_uc(ucs, ep)
                env = await ingest_uc.execute(
                    code,
                    sleep_sec=resolved_sleep_sec,
                    asof=run_asof,
                )

                typer.echo(f"\n=== ONE DONE: {ep} {code} ===")
                if show:
                    typer.echo(to_pretty_json(env))
        finally:
            await ucs.resources.aclose()

    asyncio.run(_run())


@nfs_app.command("all")
def nfs_all(
    endpoint: ArgEndpoint,
    universe: OptUniverse = "krx300",
    limit: OptLimit = 0,
    chunk_size: OptChunk = 5,
    asof: OptAsOf = None,
) -> None:
    settings = get_settings()
    resolved_sink = settings.nfs_sink
    resolved_sleep_sec = settings.scraper_sleep_sec_default

    endpoints = iter_endpoints(endpoint)
    run_asof = parse_asof(asof)

    if endpoint == "c104":
        typer.echo("C104는 수집 속도가 느려 chunk_size를 3으로 설정합니다.")
        chunk_size = 3

    async def _run() -> None:
        ucs = build_usecases(nfs_sink=resolved_sink)

        try:
            await ucs.resources.bootstrap()

            db = ucs.resources.db
            codes = sorted(await list_latest_universe_codes(db, universe=universe))
            if limit > 0:
                codes = codes[:limit]

            typer.echo(
                f"\n=== NFS ALL === universe={universe}, endpoint={endpoint}, codes={len(codes)}, sink={resolved_sink}"
            )

            await _run_ingest_many_with_progress(
                ucs=ucs,
                endpoints=endpoints,
                codes=codes,
                sleep_sec=resolved_sleep_sec,
                asof=run_asof,
                chunk_size=chunk_size,
                progress_every=1,
            )
        finally:
            await ucs.resources.aclose()

    asyncio.run(_run())


# -----------------------------------------------------------------------------
# dart commands
# -----------------------------------------------------------------------------


@dart_app.command("reports")
def dart_reports(
    sdate: OptDartSDate = "",
    edate: OptDartEDate = "",
    show: OptShow = True,
) -> None:
    """
    OpenDART 공시 리스트를 수집한다.
    """

    async def _run() -> None:
        ucs = build_usecases()

        try:
            result = await ucs.dart.collect_reports.execute(
                sdate=sdate,
                edate=edate,
            )

            typer.echo("\n=== DART REPORTS DONE ===")
            if show:
                typer.echo(to_pretty_json(result))
        finally:
            await ucs.resources.aclose()

    asyncio.run(_run())


@dart_app.command("today")
def dart_today(
    show: OptShow = True,
) -> None:
    """
    OpenDART 오늘 공시를 수집한다.
    """

    async def _run() -> None:
        ucs = build_usecases()

        try:
            result = await ucs.dart.collect_reports.execute()

            typer.echo("\n=== DART TODAY DONE ===")
            if show:
                typer.echo(to_pretty_json(result))
        finally:
            await ucs.resources.aclose()

    asyncio.run(_run())


# -----------------------------------------------------------------------------
# misc
# -----------------------------------------------------------------------------


@mi_app.callback(invoke_without_command=True)
def mi() -> None:
    pass


if __name__ == "__main__":
    app()
