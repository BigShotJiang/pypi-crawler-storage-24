# scraper2_hj3415/app/nfs/services/fetch/fetch_c103.py
from __future__ import annotations

import asyncio
import random
from collections.abc import Iterable

from logging_hj3415 import logger
from scraper2_hj3415.app.nfs.adapters.site.wisereport_playwright import (
    WiseReportPlaywright,
)
from scraper2_hj3415.app.nfs.domain.constants import BLOCK_KEYS_BY_ENDPOINT
from scraper2_hj3415.app.nfs.domain.doc import NfsDoc
from scraper2_hj3415.app.nfs.domain.endpoint import EndpointKind
from scraper2_hj3415.app.nfs.domain.types import Records
from scraper2_hj3415.app.nfs.parsing.c103_parser import (
    TABLE_XPATH,
    parse_c103_current_table,
)
from scraper2_hj3415.app.nfs.ports.browser.browser_factory_port import (
    BrowserFactoryPort,
)
from scraper2_hj3415.app.nfs.ports.site.wisereport_port import WiseReportPort
from scraper2_hj3415.app.nfs.services.fetch.common import gather_docs
from scraper2_hj3415.app.nfs.services.nfs_doc_builders import (
    build_metrics_doc_from_parsed,
)

BTN_SETS: dict[str, list[tuple[str, str]]] = {
    "손익계산서y": [
        ("손익계산서", 'xpath=//*[@id="rpt_tab1"]'),
        ("연간", 'xpath=//*[@id="frqTyp0"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "재무상태표y": [
        ("재무상태표", 'xpath=//*[@id="rpt_tab2"]'),
        ("연간", 'xpath=//*[@id="frqTyp0"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "현금흐름표y": [
        ("현금흐름표", 'xpath=//*[@id="rpt_tab3"]'),
        ("연간", 'xpath=//*[@id="frqTyp0"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "손익계산서q": [
        ("손익계산서", 'xpath=//*[@id="rpt_tab1"]'),
        ("분기", 'xpath=//*[@id="frqTyp1"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "재무상태표q": [
        ("재무상태표", 'xpath=//*[@id="rpt_tab2"]'),
        ("분기", 'xpath=//*[@id="frqTyp1"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
    "현금흐름표q": [
        ("현금흐름표", 'xpath=//*[@id="rpt_tab3"]'),
        ("분기", 'xpath=//*[@id="frqTyp1"]'),
        ("검색", 'xpath=//*[@id="hfinGubun"]'),
    ],
}

TABLE_INDEX = 2


class FetchC103:
    factory: BrowserFactoryPort

    def __init__(self, factory: BrowserFactoryPort):
        self.factory = factory

    async def _fetch_one(self, code: str, *, sleep_sec: float) -> NfsDoc | None:
        async with self.factory.lease() as browser:
            wr: WiseReportPort = WiseReportPlaywright(browser)

            url = (
                "https://navercomp.wisereport.co.kr/v2/company/c1030001.aspx"
                f"?cn=&cmp_cd={code}"
            )
            await browser.goto_and_wait_for_stable(url, timeout_ms=10_000)

            if sleep_sec > 0:
                await asyncio.sleep(sleep_sec + random.uniform(0, 1.0))

            parsed: dict[str, Records] = {}

            for key, steps in BTN_SETS.items():
                try:
                    # 1) 상태 확정 (분기/연간이 맞는지 헤더로 검증)
                    await wr.set_view_c103(
                        key=key,
                        steps=steps,
                        table_selector=TABLE_XPATH,
                        table_index=TABLE_INDEX,
                        max_attempts=5,
                        stabilize_timeout_sec=10.0,
                        code=code,
                    )

                    # 2) 파싱은 “현재 화면 테이블”만
                    parsed[key] = await parse_c103_current_table(browser)

                except Exception as e:
                    logger.warning(
                        f"c103 view/parse failed: code={code} key={key} err={type(e).__name__}: {e}"
                    )
                    parsed[key] = []

            block_keys = BLOCK_KEYS_BY_ENDPOINT[EndpointKind.C103]
            if not parsed or all(not (parsed.get(str(bk)) or []) for bk in block_keys):
                logger.warning(
                    f"c103 fetch: parsed result empty; return None | code={code}"
                )
                return None

            doc = build_metrics_doc_from_parsed(
                code=code,
                endpoint_kind=EndpointKind.C103,
                parsed=parsed,
                block_keys=block_keys,
                item_key="항목",
                raw_label_key="항목_raw",
                keep_empty_blocks=True,
            )
            return doc

    async def execute(self, code: str, *, sleep_sec: float = 2.0) -> NfsDoc | None:
        return await self._fetch_one(code, sleep_sec=sleep_sec)

    async def execute_many(
        self, codes: Iterable[str], *, sleep_sec: float = 2.0
    ) -> list[NfsDoc]:
        code_list = list(codes)
        return await gather_docs(
            {c: self._fetch_one(c, sleep_sec=sleep_sec) for c in code_list},
            endpoint="c103",
        )
