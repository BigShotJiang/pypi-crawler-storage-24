# scraper2_hj3415/app/ports/site/wisereport_port.py
from __future__ import annotations

from typing import Protocol


class WiseReportPort(Protocol):
    async def set_view_c103(
        self,
        *,
        key: str,
        steps: list[tuple[str, str]],
        table_selector: str,
        table_index: int,
        max_attempts: int = 5,
        stabilize_timeout_sec: float = 10.0,
        code: str | None = None,
    ) -> None: ...

    async def set_view_c104(
        self,
        *,
        key: str,
        steps: list[tuple[str, str]],
        table_selector: str,
        table_index: int,
        prev_text_by_idx: dict[int, str | None],
        max_attempts: int = 5,
        stabilize_timeout_sec: float = 10.0,
        min_rows: int = 4,
        min_lines: int = 30,
        open_consensus: bool = True,
        code: str | None = None,
    ) -> None: ...
