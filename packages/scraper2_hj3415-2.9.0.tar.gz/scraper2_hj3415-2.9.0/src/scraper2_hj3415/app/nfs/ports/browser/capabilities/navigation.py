from __future__ import annotations

from typing import Protocol


class BrowserNavigationPort(Protocol):
    """페이지 이동/기본 정보"""

    async def title(self) -> str: ...
    async def current_url(self) -> str: ...

    async def goto_and_wait_for_stable(
        self,
        url: str,
        timeout_ms: int = 10_000,
    ) -> None: ...

    async def reload(self, *, timeout_ms: int = 10_000) -> None: ...