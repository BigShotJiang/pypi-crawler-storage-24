from __future__ import annotations

from typing import Any, Protocol


class BrowserTablePort(Protocol):
    """테이블 파싱/헤더 추출"""

    async def table_records(
        self,
        table_selector: str,
        *,
        header: int | list[int] | None = 0,
    ) -> list[dict[str, Any]]: ...  # pyright: ignore[reportExplicitAny]

    async def table_header_texts_nth(
        self,
        table_selector: str,
        *,
        index: int,
    ) -> list[str]: ...

    async def table_header_periods_mm_nth(
        self,
        table_selector: str,
        *,
        index: int,
    ) -> list[str]: ...
