# scraper2_hj3415/app/ports/browser/browser_factory_port.py
from __future__ import annotations

from contextlib import AbstractAsyncContextManager
from typing import Protocol

from scraper2_hj3415.app.nfs.ports.browser.browser_port import BrowserPort


class BrowserFactoryPort(Protocol):
    def lease(self) -> AbstractAsyncContextManager[BrowserPort]: ...
    async def aclose(self) -> None: ...
