# scraper2_hj3415/app/ports/sinks/nfs_sink_port.py
from __future__ import annotations

from collections.abc import Iterable
from typing import Protocol

from contracts_hj3415.common.envelope import NfsEnvelopeDTO


class NfsSinkPort(Protocol):
    async def write(self, env: NfsEnvelopeDTO) -> None: ...
    async def write_many(self, envs: Iterable[NfsEnvelopeDTO]) -> None: ...
