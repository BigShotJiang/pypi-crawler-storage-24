from __future__ import annotations

from typing import Protocol


class BrowserInteractionPort(Protocol):
    """클릭/스크롤 등 상호작용"""

    async def click(
        self,
        selector: str,
        *,
        index: int = 0,
        timeout_ms: int = 4_000,
        force: bool = False,
    ) -> None: ...

    async def try_click(
        self,
        selector: str,
        *,
        index: int = 0,
        timeout_ms: int = 1_500,
        force: bool = False,
    ) -> bool: ...

    async def scroll_into_view(self, selector: str, *, index: int = 0) -> None: ...