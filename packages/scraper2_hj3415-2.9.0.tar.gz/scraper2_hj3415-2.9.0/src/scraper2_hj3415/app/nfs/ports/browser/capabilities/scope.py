from __future__ import annotations

from typing import Any, Protocol


class BrowserScopePort(Protocol):
    """scope/nth 컨텍스트 기반 조회 (현재는 기존 API 유지)"""

    async def is_attached(self, selector: str, *, index: int = 0) -> bool: ...

    async def computed_style(
        self,
        selector: str,
        *,
        index: int = 0,
        prop: str,
    ) -> str: ...

    async def count_in_nth(
        self,
        scope_selector: str,
        *,
        scope_index: int,
        inner_selector: str,
    ) -> int: ...

    async def eval_in_nth_first(  # pyright: ignore[reportAny]
        self,
        scope_selector: str,
        *,
        scope_index: int,
        inner_selector: str,
        expression: str,
    ) -> Any: ...  # pyright: ignore[reportExplicitAny]

    async def inner_text_in_nth(
        self,
        scope_selector: str,
        *,
        scope_index: int,
        inner_selector: str,
        inner_index: int = 0,
        timeout_ms: int = 10_000,
    ) -> str:
        """
        scope_selector의 nth(scope_index) 요소 안에서
        inner_selector의 nth(inner_index) 요소의 innerText를 반환.
        (렌더링 기준 텍스트: 줄바꿈/스타일 영향 반영)
        """
        ...

    async def text_content_in_nth(
        self,
        scope_selector: str,
        *,
        scope_index: int,
        inner_selector: str,
        inner_index: int = 0,
        timeout_ms: int = 10_000,
    ) -> str:
        """
        scope_selector의 nth(scope_index) 요소 안에서
        inner_selector의 nth(inner_index) 요소의 textContent를 반환.
        (DOM 기준 텍스트: 숨김 텍스트도 포함될 수 있음)
        """
        ...
