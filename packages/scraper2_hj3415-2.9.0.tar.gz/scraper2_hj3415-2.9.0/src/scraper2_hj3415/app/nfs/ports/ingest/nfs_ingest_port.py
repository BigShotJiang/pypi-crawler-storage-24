# scraper2_hj3415/app/ports/ingest/nfs_ingest_port.py
from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime
from typing import Protocol

from contracts_hj3415.common.envelope import NfsEnvelopeDTO


class NfsIngestPort(Protocol):

    async def execute(
        self,
        code: str,
        *,
        sleep_sec: float = 2.0,
        asof: datetime | None = None,
    ) -> NfsEnvelopeDTO: ...

    async def execute_many(
        self,
        codes: Iterable[str],
        *,
        sleep_sec: float = 2.0,
        asof: datetime | None = None,
    ) -> list[NfsEnvelopeDTO]: ...
