# scraper2_hj3415/app/ports/browser/browser_port.py
from __future__ import annotations

from typing import Protocol

from .capabilities import (
    BrowserInteractionPort,
    BrowserNavigationPort,
    BrowserScopePort,
    BrowserTablePort,
    BrowserTextPort,
    BrowserWaitPort,
)


class BrowserPort(
    BrowserNavigationPort,
    BrowserWaitPort,
    BrowserInteractionPort,
    BrowserTextPort,
    BrowserScopePort,
    BrowserTablePort,
    Protocol,
):
    """
    프로젝트에서 사용하는 최종 BrowserPort.

    - 내부는 capability 단위로 분리되어 있으며,
      필요하면 파서/유스케이스가 BrowserPort 대신
      특정 capability 포트만 의존하도록 바꿀 수 있다.
    """
    ...
