# scraper2_hj3415/app/nfs/domain/constants.py
from __future__ import annotations

from collections.abc import Mapping

from contracts_hj3415.nfs.types import BlockKey
from scraper2_hj3415.app.nfs.domain.endpoint import EndpointKind

ENDPOINTS: tuple[str, ...] = ("c101", "c103", "c104", "c106", "c108")


C101_BLOCK_KEYS: tuple[str, ...] = (
    "요약",
    "시세",
    "주주현황",
    "기업개요",
    "펀더멘털",
    "어닝서프라이즈",
    "연간컨센서스",
)


C103_BLOCK_KEYS: tuple[str, ...] = (
    "손익계산서y",
    "손익계산서q",
    "재무상태표y",
    "재무상태표q",
    "현금흐름표y",
    "현금흐름표q",
)


C104_BLOCK_KEYS: tuple[str, ...] = (
    "수익성y",
    "성장성y",
    "안정성y",
    "활동성y",
    "가치분석y",
    "수익성q",
    "성장성q",
    "안정성q",
    "활동성q",
    "가치분석q",
)


C106_BLOCK_KEYS: tuple[str, ...] = (
    "y",
    "q",
)


C108_BLOCK_KEYS: tuple[str, ...] = ("리포트",)


BLOCK_KEYS_BY_ENDPOINT: Mapping[EndpointKind, tuple[str, ...]] = {
    EndpointKind.C101: C101_BLOCK_KEYS,
    EndpointKind.C103: C103_BLOCK_KEYS,
    EndpointKind.C104: C104_BLOCK_KEYS,
    EndpointKind.C106: C106_BLOCK_KEYS,
    EndpointKind.C108: C108_BLOCK_KEYS,
}


def get_block_keys(endpoint: EndpointKind) -> tuple[str, ...]:
    """
    엔드포인트의 "공식" 블록 키 목록.
    - 도메인 레이어에 두되, selector/table index 같은 구현 디테일은 넣지 않는다.
    """
    return BLOCK_KEYS_BY_ENDPOINT.get(endpoint, ())


def is_known_block(endpoint: EndpointKind, key: BlockKey) -> bool:
    """
    블록 키가 해당 endpoint의 공식 목록에 포함되는지 여부.
    (검증/필터링/동적 payload merge 등에 사용)
    """
    return key in BLOCK_KEYS_BY_ENDPOINT.get(endpoint, ())
