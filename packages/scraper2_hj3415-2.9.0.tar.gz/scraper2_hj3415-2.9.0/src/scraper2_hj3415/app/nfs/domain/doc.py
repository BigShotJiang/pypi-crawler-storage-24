# scraper2_hj3415/app/nfs/domain/doc.py
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from scraper2_hj3415.app.nfs.domain.blocks import BlockData
from scraper2_hj3415.app.nfs.domain.endpoint import EndpointKind
from scraper2_hj3415.app.nfs.domain.types import BlockKey, LabelsMap


@dataclass(frozen=True)
class NfsDoc:
    code: str
    endpoint_kind: EndpointKind
    blocks: Mapping[BlockKey, BlockData]
    labels: Mapping[BlockKey, LabelsMap]
