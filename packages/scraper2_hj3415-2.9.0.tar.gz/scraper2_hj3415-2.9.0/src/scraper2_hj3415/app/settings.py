# scraper2_hj3415/app/settings.py
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal, TypeAlias

from pydantic_settings import BaseSettings, SettingsConfigDict

SinkSetting: TypeAlias = Literal["mongo", "memory"]

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ENV_FILE = PROJECT_ROOT / ".env"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(ENV_FILE),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # app
    app_name: str = "scraper2"
    app_env: str = "prod"
    log_level: str = "INFO"

    # db
    mongo_uri: str = "mongodb://localhost:27017"
    mongo_db_name: str = "hj3415"
    mongo_connect_timeout_ms: int = 5_000
    mongo_server_selection_timeout_ms: int = 5_000
    snapshot_ttl_days: int | None = 730

    # nfs
    nfs_sink: SinkSetting = "mongo"
    scraper_headless: bool = True
    scraper_timeout_ms: int = 20_000
    scraper_max_concurrency: int = 2
    scraper_sleep_sec_default: float = 2.0

    # dart
    dart_api_key: str = ""


@lru_cache
def get_settings() -> Settings:
    return Settings()
