from __future__ import annotations

import re
from dataclasses import dataclass

_YYYYMMDD_RE = re.compile(r"^\d{8}$")
_SIX_DIGIT_RE = re.compile(r"^\d{6}$")


def _is_ymd_format(value: str) -> bool:
    return bool(_YYYYMMDD_RE.fullmatch(value))


def _is_6digit(value: str) -> bool:
    return bool(_SIX_DIGIT_RE.fullmatch(value))


@dataclass(slots=True, frozen=True)
class DartQuery:
    """
    OpenDART list 조회 입력값 검증용 Value Object.
    """

    sdate: str | None = None
    edate: str | None = None
    corp_code: str | None = None

    def __post_init__(self) -> None:
        if self.sdate is not None and not _is_ymd_format(self.sdate):
            raise ValueError("sdate 형식이 맞지 않습니다. (YYYYMMDD)")
        if self.edate is not None and not _is_ymd_format(self.edate):
            raise ValueError("edate 형식이 맞지 않습니다. (YYYYMMDD)")
        if self.corp_code is not None and not _is_6digit(self.corp_code):
            raise ValueError("corp_code 형식이 맞지 않습니다. (6자리 숫자 문자열)")
