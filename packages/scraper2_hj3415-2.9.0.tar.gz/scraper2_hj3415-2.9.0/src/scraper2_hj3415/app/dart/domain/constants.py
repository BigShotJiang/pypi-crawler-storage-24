from __future__ import annotations

USELESS_TITLES: tuple[str, ...] = (
    "기재정정",
    "첨부정정",
    "자회사의",
    "종속회사의",
    "기타경영사항",
    "첨부추가",
)

ALLOWED_CORP_CLASSES: frozenset[str] = frozenset({"K", "Y"})

DART_DOCUMENT_URL_PREFIX = "http://dart.fss.or.kr/dsaf001/main.do?rcpNo="
