from __future__ import annotations

from dataclasses import replace

from scraper2_hj3415.app.dart.domain.constants import (
    ALLOWED_CORP_CLASSES,
    USELESS_TITLES,
)
from scraper2_hj3415.app.dart.domain.entities.dart_report import DartReport
from scraper2_hj3415.app.dart.domain.services.dart_title_normalizer import (
    DartTitleNormalizer,
)


class DartReportFilter:
    """
    공시 후처리 정책 모음.
    """

    @staticmethod
    def only_kospi_kosdaq(reports: list[DartReport]) -> list[DartReport]:
        return [report for report in reports if report.corp_cls in ALLOWED_CORP_CLASSES]

    @staticmethod
    def only_in_stock_codes(
        reports: list[DartReport],
        stock_codes: set[str],
    ) -> list[DartReport]:
        return [report for report in reports if report.stock_code in stock_codes]

    @staticmethod
    def exclude_useless_titles(reports: list[DartReport]) -> list[DartReport]:
        result: list[DartReport] = []
        for report in reports:
            compact_title = DartTitleNormalizer.remove_all_spaces(report.report_nm)
            if any(word in compact_title for word in USELESS_TITLES):
                continue
            result.append(replace(report, report_nm=compact_title))
        return result
