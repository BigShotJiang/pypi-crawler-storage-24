# scraper2_hj3415/app/dart/domain/entities/dart_report.py
from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True, frozen=True)
class DartReport:
    """
    OpenDART 공시목록의 코어 도메인 엔티티.
    usecase / domain layer에서는 이 엔티티만 사용한다.
    """

    corp_cls: str
    corp_code: str
    corp_name: str
    stock_code: str
    report_nm: str
    rcept_no: str
    link: str
    flr_nm: str | None = None
    rcept_dt: str | None = None
