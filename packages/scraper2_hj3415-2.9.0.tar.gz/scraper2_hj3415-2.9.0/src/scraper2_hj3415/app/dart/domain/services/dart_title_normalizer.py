from __future__ import annotations

import re
from dataclasses import replace

from scraper2_hj3415.app.dart.domain.entities.dart_report import DartReport


class DartTitleNormalizer:
    """
    공시 제목(report_nm) 정규화 정책.
    """

    @staticmethod
    def normalize_whitespace(reports: list[DartReport]) -> list[DartReport]:
        normalized: list[DartReport] = []
        for report in reports:
            refined = re.sub(r"\s+", " ", report.report_nm.strip())
            normalized.append(replace(report, report_nm=refined))
        return normalized

    @staticmethod
    def remove_all_spaces(text: str) -> str:
        return text.replace(" ", "")
