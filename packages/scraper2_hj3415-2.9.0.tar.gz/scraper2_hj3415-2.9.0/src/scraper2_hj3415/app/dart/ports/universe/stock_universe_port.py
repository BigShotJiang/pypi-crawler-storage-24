from __future__ import annotations

from typing import Protocol


class StockUniversePort(Protocol):
    async def get_codes(self) -> list[str]: ...
