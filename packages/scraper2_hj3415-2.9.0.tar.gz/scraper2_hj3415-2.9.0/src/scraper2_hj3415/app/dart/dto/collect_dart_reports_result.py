from __future__ import annotations

from dataclasses import dataclass

from scraper2_hj3415.app.dart.domain.entities.dart_report import DartReport


@dataclass(slots=True, frozen=True)
class CollectDartReportsResult:
    """
    공시 목록 수집 유스케이스 결과 DTO.
    """

    total_pages: int
    raw_count: int
    filtered_count: int
    reports: list[DartReport]
