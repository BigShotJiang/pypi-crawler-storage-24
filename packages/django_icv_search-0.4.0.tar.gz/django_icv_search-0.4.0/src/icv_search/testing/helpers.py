"""Test helper functions for icv-search."""

from icv_search.backends.dummy import _documents, _indexes


def get_indexed_documents(index_uid: str) -> list[dict]:
    """Return all documents in the dummy backend for a given index."""
    return list(_documents.get(index_uid, {}).values())


def get_dummy_indexes() -> dict:
    """Return all indexes in the dummy backend."""
    return dict(_indexes)


def assert_document_indexed(index_uid: str, doc_id: str) -> None:
    """Assert that a document exists in the dummy backend."""
    docs = _documents.get(index_uid, {})
    assert str(doc_id) in docs, f"Document {doc_id} not found in index {index_uid}. Found: {list(docs.keys())}"
