"""
Package-level settings with defaults.

All settings are namespaced under ICV_SEARCH_* and accessed via this module.
Consuming projects override in their Django settings file.

Usage:
    from icv_search.conf import ICV_SEARCH_BACKEND
"""

from django.conf import settings

# Dotted path to the search backend class
ICV_SEARCH_BACKEND: str = getattr(settings, "ICV_SEARCH_BACKEND", "icv_search.backends.meilisearch.MeilisearchBackend")

# Search engine connection URL
ICV_SEARCH_URL: str = getattr(settings, "ICV_SEARCH_URL", "http://localhost:7700")

# Master/admin API key for the search engine
ICV_SEARCH_API_KEY: str = getattr(settings, "ICV_SEARCH_API_KEY", "")

# Request timeout in seconds for backend calls
ICV_SEARCH_TIMEOUT: int = getattr(settings, "ICV_SEARCH_TIMEOUT", 30)

# Dotted path to callable (request_or_none) -> str returning the tenant prefix.
# Empty string disables multi-tenancy.
ICV_SEARCH_TENANT_PREFIX_FUNC: str = getattr(settings, "ICV_SEARCH_TENANT_PREFIX_FUNC", "")

# Auto-sync index settings to the engine on SearchIndex.save()
ICV_SEARCH_AUTO_SYNC: bool = getattr(settings, "ICV_SEARCH_AUTO_SYNC", True)

# Use Celery for document indexing operations
ICV_SEARCH_ASYNC_INDEXING: bool = getattr(settings, "ICV_SEARCH_ASYNC_INDEXING", True)

# Global prefix applied to all index names (e.g. environment prefix "staging_")
ICV_SEARCH_INDEX_PREFIX: str = getattr(settings, "ICV_SEARCH_INDEX_PREFIX", "")

# Auto-index configuration — dict mapping index names to model configs.
# When configured, post_save/post_delete signals are automatically connected
# in IcvSearchConfig.ready(). An empty dict (the default) disables auto-indexing.
#
# Example::
#
#     ICV_SEARCH_AUTO_INDEX = {
#         "articles": {
#             "model": "blog.Article",       # required — "app_label.ModelName"
#             "on_save": True,               # index on post_save (default True)
#             "on_delete": True,             # remove on post_delete (default True)
#             "async": True,                 # use Celery; falls back to ICV_SEARCH_ASYNC_INDEXING
#             "auto_create": True,           # auto-create SearchIndex if missing (default True)
#             "should_update": "blog.utils.should_index_article",  # optional callable(instance) -> bool
#             "updated_field": "updated_at", # for incremental reindex (informational)
#         },
#     }
ICV_SEARCH_AUTO_INDEX: dict = getattr(settings, "ICV_SEARCH_AUTO_INDEX", {})

# Debounce window for auto-index signal batching (in seconds).
# When > 0, rapid successive saves are batched into a single indexing task
# dispatched after this delay. Requires Django's cache framework.
# Set to 0 to disable debouncing (each save dispatches immediately).
ICV_SEARCH_DEBOUNCE_SECONDS: int = getattr(settings, "ICV_SEARCH_DEBOUNCE_SECONDS", 0)

# Query logging — when True, every search() call creates a SearchQueryLog record.
ICV_SEARCH_LOG_QUERIES: bool = getattr(settings, "ICV_SEARCH_LOG_QUERIES", False)

# When True (and LOG_QUERIES is True), only queries that returned zero results
# are logged.  Useful for reducing storage whilst still capturing actionable data.
ICV_SEARCH_LOG_ZERO_RESULTS_ONLY: bool = getattr(settings, "ICV_SEARCH_LOG_ZERO_RESULTS_ONLY", False)

# Logging mode — controls how search queries are recorded.
# "individual" = one row per query (default, current behaviour)
# "aggregate"  = increment counters on a (query, index_name, date) key
# "both"       = do both
ICV_SEARCH_LOG_MODE: str = getattr(settings, "ICV_SEARCH_LOG_MODE", "individual")

# Sample rate for individual query logging (0.0–1.0).
# 1.0 = log every query (default), 0.5 = log ~50% of queries.
# Only applies to "individual" mode rows. Aggregate mode always counts 100%.
ICV_SEARCH_LOG_SAMPLE_RATE: float = getattr(settings, "ICV_SEARCH_LOG_SAMPLE_RATE", 1.0)

# Enable the search result cache layer (requires Django's cache framework).
# When False (the default), search() always calls the backend directly.
ICV_SEARCH_CACHE_ENABLED: bool = getattr(settings, "ICV_SEARCH_CACHE_ENABLED", False)

# Cache TTL in seconds for stored search results.
ICV_SEARCH_CACHE_TIMEOUT: int = getattr(settings, "ICV_SEARCH_CACHE_TIMEOUT", 60)

# Django cache alias used by the search result cache.
# Defaults to "default". Set to a dedicated alias (e.g. "search") when
# you want to control eviction independently from other cached data.
ICV_SEARCH_CACHE_ALIAS: str = getattr(settings, "ICV_SEARCH_CACHE_ALIAS", "default")

# Enable the merchandising layer (query redirects, rewrites, pins, boosts,
# banners, zero-result fallbacks). When False (the default), merchandised_search()
# delegates directly to search() with no rule evaluation.
ICV_SEARCH_MERCHANDISING_ENABLED: bool = getattr(settings, "ICV_SEARCH_MERCHANDISING_ENABLED", False)

# Cache TTL in seconds for merchandising rules loaded from the database.
# Set to 0 to disable caching (useful in tests).
ICV_SEARCH_MERCHANDISING_CACHE_TIMEOUT: int = getattr(settings, "ICV_SEARCH_MERCHANDISING_CACHE_TIMEOUT", 300)
