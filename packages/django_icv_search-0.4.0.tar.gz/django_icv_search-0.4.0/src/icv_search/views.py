"""Health check views for icv-search."""

from __future__ import annotations

from django.http import JsonResponse
from django.views.decorators.http import require_GET

from icv_search.backends import get_search_backend


@require_GET
def icv_search_health(request):
    """Health check endpoint for the search backend.

    Returns 200 with {"status": "ok"} when the backend is reachable,
    or 503 with {"status": "unavailable"} when it is not.

    Intended for load balancer health probes and monitoring dashboards.
    """
    backend = get_search_backend()
    try:
        healthy = backend.health()
    except Exception:
        healthy = False

    if healthy:
        return JsonResponse({"status": "ok"})
    return JsonResponse({"status": "unavailable"}, status=503)
