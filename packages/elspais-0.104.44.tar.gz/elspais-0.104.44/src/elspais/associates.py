# Implements: REQ-p00005-A
"""
elspais.associates - Associate repository configuration and discovery.

Provides functions for discovering associate repositories from their
.elspais.toml config and resolving associate spec directories.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class Associate:
    """
    Represents an associate repository configuration.

    Attributes:
        name: Associate name (e.g., "callisto")
        code: Short code used in requirement IDs (e.g., "CAL")
        enabled: Whether this associate is enabled for scanning
        path: Default path relative to project root
        spec_path: Spec directory within associate path (e.g., "spec")
        local_path: Override path for local development
    """

    name: str
    code: str
    enabled: bool = True
    path: str = ""
    spec_path: str = "spec"
    local_path: str | None = None


def get_associate_spec_directories(
    config: dict[str, Any],
    base_path: Path | None = None,
    canonical_root: Path | None = None,
) -> tuple[list[Path], list[str]]:
    """
    Get all associate spec directories from configuration.

    Handles two cases:
    - Associated projects reading core repo specs (project.type == "associated")
    - Path-based loading from config["associates"]["paths"]

    Args:
        config: Main elspais configuration dictionary
        base_path: Base path to resolve relative paths (defaults to cwd)
        canonical_root: Canonical (non-worktree) repo root for cross-repo paths

    Returns:
        Tuple of (spec_dirs, errors). errors contains messages for any
        configured associate paths that could not be resolved.
    """
    # Implements: REQ-p00005-F
    if base_path is None:
        base_path = Path.cwd()

    spec_dirs = []
    errors: list[str] = []

    # 0. Core repo spec directories (for associated projects)
    # Read the core repo's own config to discover all its spec dirs.
    project_type = config.get("project", {}).get("type")
    if project_type == "associated":
        core_path_str = config.get("core", {}).get("path")
        if core_path_str:
            core_path = Path(core_path_str)
            if not core_path.is_absolute() and canonical_root:
                core_path = canonical_root / core_path
            core_config_file = core_path / ".elspais.toml"
            if core_config_file.exists():
                from elspais.config import get_config, get_spec_directories

                core_config = get_config(core_config_file, core_path)
                core_spec_dirs = get_spec_directories(None, core_config, core_path)
                for csd in core_spec_dirs:
                    if csd.exists() and csd.is_dir():
                        spec_dirs.append(csd)
            else:
                # Fallback: use configured or default "spec" subdir
                core_spec_dir_name = config.get("core", {}).get("spec", "spec")
                core_spec_dir = core_path / core_spec_dir_name
                if core_spec_dir.exists() and core_spec_dir.is_dir():
                    spec_dirs.append(core_spec_dir)
                else:
                    errors.append(f"Core repo spec directory not found: {core_spec_dir}")

    # 1. Path-based loading (reads from config["associates"]["paths"])
    # Implements: REQ-p00005-C
    associate_paths = config.get("associates", {}).get("paths", [])
    for repo_path_str in associate_paths:
        repo_path = Path(repo_path_str)
        if not repo_path.is_absolute() and canonical_root:
            repo_path = canonical_root / repo_path
        result = discover_associate_from_path(repo_path)
        if isinstance(result, str):
            errors.append(result)
            continue
        spec_dir = repo_path / result.spec_path
        if spec_dir.exists() and spec_dir.is_dir():
            spec_dirs.append(spec_dir)
        else:
            errors.append(f"Spec directory not found: {spec_dir}")

    return spec_dirs, errors


def discover_associate_from_path(
    repo_path: Path,
) -> Associate | str:
    """Discover associate identity by reading a repo's .elspais.toml.

    Reads {repo_path}/.elspais.toml and extracts associate configuration.
    Returns an error message string if the path is invalid, has no config,
    or isn't configured as an associated repository.

    Args:
        repo_path: Path to the associate repository root.

    Returns:
        Associate object if valid, error message string otherwise.
    """
    # Implements: REQ-p00005-D
    repo_path = Path(repo_path)

    if not repo_path.exists():
        return f"Associate path does not exist: {repo_path}"

    config_file = repo_path / ".elspais.toml"
    if not config_file.exists():
        return f"No .elspais.toml found in associate path: {repo_path}"

    from elspais.config import parse_toml_document

    config = parse_toml_document(config_file.read_text(encoding="utf-8"))

    project_type = config.get("project", {}).get("type")
    if project_type != "associated":
        return (
            f"Repository at {repo_path} has project.type='{project_type}', "
            f"expected 'associated'"
        )

    prefix = config.get("associated", {}).get("prefix")
    if not prefix:
        return f"Associated repository at {repo_path} is missing [associated] prefix"

    name = config.get("project", {}).get("name", repo_path.name)
    spec_path = config.get("directories", {}).get("spec", "spec")

    return Associate(
        name=name,
        code=prefix,
        enabled=True,
        path=str(repo_path),
        spec_path=spec_path,
    )


__all__ = [
    "Associate",
    "get_associate_spec_directories",
    "discover_associate_from_path",
]
