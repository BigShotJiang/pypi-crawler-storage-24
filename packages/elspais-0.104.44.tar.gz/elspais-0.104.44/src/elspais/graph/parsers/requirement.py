"""RequirementParser - Priority 50 parser for requirement blocks.

Parses requirement specifications from markdown, claiming lines from
header through end marker.
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from typing import Any

from elspais.graph.parsers import ParseContext, ParsedContent
from elspais.utilities.hasher import HASH_VALUE_PATTERN
from elspais.utilities.patterns import IdResolver


# Implements: REQ-p00002-A
class RequirementParser:
    """Parser for requirement blocks.

    Priority: 50 (after comments, before remainder)

    Parses requirement blocks in the standard format:
    - Header: ## REQ-xxx: Title
    - Metadata: **Level**: ... | **Status**: ...
    - Body text
    - Optional assertions section
    - End marker: *End* *REQ-xxx*
    """

    priority = 50

    # Regex patterns
    HEADER_PATTERN = re.compile(r"^(?P<hashes>#+)\s*(?P<id>[A-Z]+-[A-Za-z0-9-]+):\s*(?P<title>.+)$")
    LEVEL_STATUS_PATTERN = re.compile(
        r"\*\*Level\*\*:\s*(?P<level>\w+)"
        r"(?:\s*\|\s*\*\*Implements\*\*:\s*(?P<implements>[^|\n]+))?"
        r"(?:\s*\|\s*\*\*Status\*\*:\s*(?P<status>\w+))?"
    )
    ALT_STATUS_PATTERN = re.compile(r"\*\*Status\*\*:\s*(?P<status>\w+)")
    IMPLEMENTS_PATTERN = re.compile(r"\*\*Implements\*\*:\s*(?P<implements>[^|\n]+)")
    REFINES_PATTERN = re.compile(r"\*\*Refines\*\*:\s*(?P<refines>[^|\n]+)")
    # Implements: REQ-d00069-H
    SATISFIES_PATTERN = re.compile(
        r"^(?:\*\*)?Satisfies(?:\*\*)?:\s*(?P<satisfies>.+)$", re.MULTILINE
    )
    END_MARKER_PATTERN = re.compile(
        rf"^\*End\*\s+\*[^*]+\*\s*(?:\|\s*\*\*Hash\*\*:\s*(?P<hash>{HASH_VALUE_PATTERN}))?",
        re.MULTILINE,
    )
    ASSERTIONS_HEADER_PATTERN = re.compile(r"^##\s+Assertions\s*$", re.MULTILINE)
    ASSERTION_LINE_PATTERN = re.compile(r"^\s*([A-Z0-9]+)\.\s+(.+)$", re.MULTILINE)

    # Values that mean "no references"
    NO_REFERENCE_VALUES = ["-", "null", "none", "x", "X", "N/A", "n/a"]

    def __init__(self, resolver: IdResolver) -> None:
        """Initialize parser with ID resolver.

        Args:
            resolver: IdResolver for ID parsing and validation.
        """
        self.resolver = resolver

    # Implements: REQ-p00002-A
    def claim_and_parse(
        self,
        lines: list[tuple[int, str]],
        context: ParseContext,
    ) -> Iterator[ParsedContent]:
        """Claim and parse requirement blocks.

        Args:
            lines: List of (line_number, content) tuples.
            context: Parsing context.

        Yields:
            ParsedContent for each requirement block.
        """
        # Build line map for quick access
        line_map = dict(lines)
        line_numbers = sorted(line_map.keys())

        if not line_numbers:
            return

        claimed: set[int] = set()
        i = 0

        while i < len(line_numbers):
            ln = line_numbers[i]
            if ln in claimed:
                i += 1
                continue

            text = line_map[ln]

            # Check for requirement header
            header_match = self.HEADER_PATTERN.match(text)
            if header_match:
                req_id = header_match.group("id")

                # Validate ID against configured pattern
                if not self.resolver.is_valid(req_id):
                    i += 1
                    continue

                title = header_match.group("title").strip()
                heading_level = len(header_match.group("hashes"))
                start_line = ln

                # Find the end of this requirement
                req_lines = [(ln, text)]
                end_line = ln
                j = i + 1

                while j < len(line_numbers):
                    next_ln = line_numbers[j]
                    next_text = line_map[next_ln]
                    req_lines.append((next_ln, next_text))
                    end_line = next_ln

                    # Check for end marker
                    if self.END_MARKER_PATTERN.match(next_text):
                        j += 1
                        # Separator (---) is NOT claimed; it becomes REMAINDER
                        break

                    # Check for next requirement header
                    next_match = self.HEADER_PATTERN.match(next_text)
                    if next_match and self.resolver.is_valid(next_match.group("id")):
                        # Hit next requirement - don't include this line
                        req_lines.pop()
                        end_line = line_numbers[j - 1] if j > i + 1 else ln
                        break

                    j += 1

                # Claim all lines in this requirement
                for claim_ln, _ in req_lines:
                    claimed.add(claim_ln)

                # Parse the requirement data
                raw_text = "\n".join(t for _, t in req_lines)
                parsed_data = self._parse_requirement(req_id, title, raw_text, start_line)
                parsed_data["heading_level"] = heading_level

                yield ParsedContent(
                    content_type="requirement",
                    start_line=start_line,
                    end_line=end_line,
                    raw_text=raw_text,
                    parsed_data=parsed_data,
                )

                # Move index past claimed lines
                while i < len(line_numbers) and line_numbers[i] in claimed:
                    i += 1
            else:
                i += 1

    # Implements: REQ-p00002-A
    def _parse_requirement(
        self, req_id: str, title: str, text: str, start_line: int = 0
    ) -> dict[str, Any]:
        """Parse requirement fields from text block.

        Args:
            req_id: Requirement ID.
            title: Requirement title.
            text: Full requirement text.
            start_line: Line number where the requirement starts in the file.

        Returns:
            Dictionary of parsed requirement data.
        """
        data: dict[str, Any] = {
            "id": req_id,
            "title": title,
            "level": "Unknown",
            "status": "Unknown",
            "implements": [],
            "refines": [],
            "satisfies": [],
            "assertions": [],
            "changelog": [],
            "hash": None,
            "body_text": "",  # Raw text between header and footer for hash computation
        }

        # Extract body_text: everything AFTER header line and BEFORE footer line
        # Per spec: "hash SHALL be calculated from every line AFTER Header, BEFORE Footer"
        data["body_text"] = self._extract_body_text(text)

        # Extract level and status only (implements collected via finditer below)
        level_match = self.LEVEL_STATUS_PATTERN.search(text)
        if level_match:
            raw_level = level_match.group("level") or "Unknown"
            # Normalize level to canonical config type key
            resolved = self.resolver.resolve_level(raw_level)
            data["level"] = resolved if resolved is not None else raw_level
            data["status"] = level_match.group("status") or "Unknown"

        # Try alternative status pattern
        if data["status"] == "Unknown":
            alt_match = self.ALT_STATUS_PATTERN.search(text)
            if alt_match:
                data["status"] = alt_match.group("status")

        # Collect ALL **Implements**: occurrences (additive, any number of lines)
        all_impl_refs: list[str] = list(data["implements"])  # seed with any from level_match
        for m in self.IMPLEMENTS_PATTERN.finditer(text):
            all_impl_refs.extend(self._parse_refs(m.group("implements")))
        data["implements"], impl_had_dups = self._dedup_refs(all_impl_refs)

        # Collect ALL **Refines**: occurrences (additive, any number of lines)
        all_refines_refs: list[str] = []
        for m in self.REFINES_PATTERN.finditer(text):
            all_refines_refs.extend(self._parse_refs(m.group("refines")))
        data["refines"], refines_had_dups = self._dedup_refs(all_refines_refs)

        if impl_had_dups or refines_had_dups:
            data["has_redundant_refs"] = True

        # Parse satisfies
        # Implements: REQ-d00069-H
        satisfies_match = self.SATISFIES_PATTERN.search(text)
        if satisfies_match:
            data["satisfies"] = self._parse_refs(satisfies_match.group("satisfies"))

        # Extract assertions
        data["assertions"] = self._extract_assertions(text, start_line)

        # Extract non-normative sections from body_text (REQ-d00062-B, REQ-d00064-B)
        data["sections"] = self._extract_sections(data["body_text"], start_line, text)

        # Extract changelog entries from body_text
        data["changelog"] = self._extract_changelog(data["body_text"])

        # Extract hash
        end_match = self.END_MARKER_PATTERN.search(text)
        if end_match and end_match.group("hash"):
            data["hash"] = end_match.group("hash")

        return data

    def _dedup_refs(self, refs: list[str]) -> tuple[list[str], bool]:
        """Deduplicate a reference list, preserving first-seen order.

        Returns:
            (deduplicated list, True if any duplicates were removed)
        """
        seen: set[str] = set()
        result: list[str] = []
        for ref in refs:
            if ref not in seen:
                seen.add(ref)
                result.append(ref)
        return result, len(result) < len(refs)

    # Implements: REQ-p00002-A
    def _parse_refs(self, refs_str: str) -> list[str]:
        """Parse comma-separated reference list.

        Handles both full IDs (REQ-p00001) and shorthand (p00001).
        Shorthand references are normalized to full IDs using the configured prefix.
        """
        if not refs_str:
            return []

        stripped = refs_str.strip()
        if stripped in self.NO_REFERENCE_VALUES:
            return []

        parts = [p.strip() for p in refs_str.split(",")]
        result = []

        for p in parts:
            if not p or p in self.NO_REFERENCE_VALUES:
                continue
            # Normalize to canonical form (e.g., "o00001" -> "REQ-o00001")
            canonical = self.resolver.to_canonical(p)
            result.append(canonical if canonical else p)

        return result

    # Implements: REQ-o00050-D
    def _extract_assertions(self, text: str, start_line: int = 0) -> list[dict[str, Any]]:
        """Extract assertions from text.

        Args:
            text: Full requirement text.
            start_line: Line number where the requirement starts in the file.

        Returns:
            List of assertion dicts with label, text, and line number.
        """
        assertions = []

        header_match = self.ASSERTIONS_HEADER_PATTERN.search(text)
        if not header_match:
            return assertions

        # Get text after header
        start_pos = header_match.end()
        section_text = text[start_pos:]

        # Find end of assertions section
        end_patterns = [r"^##\s+", r"^\*End\*", r"^---\s*$"]
        end_pos = len(section_text)
        for pattern in end_patterns:
            match = re.search(pattern, section_text, re.MULTILINE)
            if match and match.start() < end_pos:
                end_pos = match.start()

        assertions_text = section_text[:end_pos]

        # Parse assertion lines with multi-line continuation.
        # A continuation line is any non-blank line that doesn't start a new
        # assertion label (e.g. indented list items under "A. ... SHALL contain:").
        assertion_lines = assertions_text.split("\n")
        current_label: str | None = None
        current_text_parts: list[str] = []
        current_line_num = 0

        def _flush() -> None:
            if current_label is not None:
                # Strip trailing blank lines (inter-assertion gaps)
                parts = list(current_text_parts)
                while parts and not parts[-1].strip():
                    parts.pop()
                assertions.append(
                    {
                        "label": current_label,
                        "text": "\n".join(parts),
                        "line": current_line_num,
                    }
                )

        for i, raw_line in enumerate(assertion_lines):
            abs_pos = start_pos + sum(len(assertion_lines[k]) + 1 for k in range(i))
            line_num = start_line + text[:abs_pos].count("\n")

            m = self.ASSERTION_LINE_PATTERN.match(raw_line)
            if m:
                _flush()
                current_label = m.group(1)
                current_text_parts = [m.group(2).strip()]
                current_line_num = line_num
            elif current_label is not None:
                # Continuation: blank lines and indented/list content
                # belong to the current assertion. Trailing blanks are
                # stripped during _flush so inter-assertion gaps work.
                current_text_parts.append(raw_line)

        _flush()
        return assertions

    # Implements: REQ-p00002-C
    def _extract_body_text(self, text: str) -> str:
        """Extract body text for hash computation.

        Per spec/requirements-spec.md:
        > The hash SHALL be calculated from:
        > - every line AFTER the Header line
        > - every line BEFORE the Footer line

        Args:
            text: Full requirement text including header and footer.

        Returns:
            Body text (between header and footer) for hash computation.
        """
        lines = text.split("\n")
        if not lines:
            return ""

        # Header is the first line (## REQ-xxx: Title)
        # Body starts from line 1 (after header)
        body_start = 1

        # Find footer line (*End* *Title* | **Hash**: xxx)
        body_end = len(lines)
        for i, line in enumerate(lines):
            if self.END_MARKER_PATTERN.match(line):
                body_end = i
                break

        # Extract body lines and join
        body_lines = lines[body_start:body_end]

        # Strip leading/trailing empty lines but preserve internal structure
        while body_lines and not body_lines[0].strip():
            body_lines.pop(0)
        while body_lines and not body_lines[-1].strip():
            body_lines.pop()

        return "\n".join(body_lines)

    # Pattern to split on ## headings (captures the heading name)
    _SECTION_HEADER_RE = re.compile(r"^##\s+(.+)$", re.MULTILINE)

    # Implements: REQ-p00002-A
    def _extract_sections(
        self, body_text: str, start_line: int = 0, raw_text: str = ""
    ) -> list[dict[str, Any]]:
        """Extract named sections from body text.

        Parses ## headings into separate sections. Content before the first
        heading (minus the metadata line) goes into a "preamble" section.
        The Assertions section is excluded (already parsed as assertion nodes).

        Args:
            body_text: The body text between header and footer.
            start_line: Line number where the requirement starts in the file.
            raw_text: Full raw requirement text (for computing line offsets).

        Returns:
            List of {"heading": str, "content": str, "line": int} dicts.
            Empty sections are omitted.
        """
        if not body_text:
            return []

        # Compute the line offset where body_text begins within raw_text.
        # body_text is extracted from raw_text by stripping header and footer,
        # so we find where the first body line appears.
        body_start_offset = 0
        if raw_text and body_text:
            # The header is line 0 of raw_text, body starts after that
            # Find the body_text content in raw_text to get proper offset
            first_body_line = body_text.split("\n")[0] if body_text else ""
            raw_lines = raw_text.split("\n")
            for i, rl in enumerate(raw_lines):
                if rl == first_body_line and i > 0:
                    body_start_offset = i
                    break
            else:
                # Fallback: body starts on line 1 (after header)
                body_start_offset = 1

        sections: list[dict[str, Any]] = []
        lines = body_text.split("\n")

        current_heading: str | None = None
        current_lines: list[str] = []
        current_line_num = start_line + body_start_offset

        # Track starting line for each section
        section_start_line = current_line_num

        for i, line in enumerate(lines):
            match = self._SECTION_HEADER_RE.match(line)
            if match:
                # Flush previous section
                self._flush_section(sections, current_heading, current_lines, section_start_line)
                current_heading = match.group(1).strip()
                current_lines = []
                section_start_line = start_line + body_start_offset + i
            else:
                current_lines.append(line)

        # Flush final section
        self._flush_section(sections, current_heading, current_lines, section_start_line)

        return sections

    def _flush_section(
        self,
        sections: list[dict[str, Any]],
        heading: str | None,
        lines: list[str],
        line_num: int = 0,
    ) -> None:
        """Flush accumulated lines into a section if non-empty.

        For the preamble (heading=None), strips the metadata line
        (**Level**: ... | **Status**: ...) since it's already parsed
        into structured fields.

        Skips the Assertions and Changelog sections (parsed separately).
        """
        if heading is not None and heading.lower() in ("assertions", "changelog"):
            return

        # Strip metadata line from preamble
        if heading is None:
            lines = [
                ln
                for ln in lines
                if not self.LEVEL_STATUS_PATTERN.search(ln)
                and not self.ALT_STATUS_PATTERN.search(ln)
                and not self.IMPLEMENTS_PATTERN.search(ln)
                and not self.REFINES_PATTERN.search(ln)
                and not self.SATISFIES_PATTERN.search(ln)
            ]

        content = "\n".join(lines).strip()
        if not content:
            return

        sections.append(
            {
                "heading": heading if heading is not None else "preamble",
                "content": content,
                "line": line_num,
            }
        )

    # Pattern for changelog entry lines
    _CHANGELOG_ENTRY_RE = re.compile(r"^- (.+?) \| (\S+) \| (.+?) \| (.+?) \((.+?)\) \| (.+)$")

    def _extract_changelog(self, body_text: str) -> list[dict[str, str]]:
        """Extract changelog entries from body text.

        Looks for a ## Changelog section and parses each entry line.

        Args:
            body_text: The body text between header and footer.

        Returns:
            List of changelog entry dicts with keys:
            date, hash, change_order, author_name, author_id, reason.
        """
        # Find ## Changelog section
        match = re.search(r"^## Changelog\s*$", body_text, re.MULTILINE)
        if not match:
            return []

        changelog_text = body_text[match.end() :]
        entries: list[dict[str, str]] = []

        for line in changelog_text.split("\n"):
            line = line.strip()
            entry_match = self._CHANGELOG_ENTRY_RE.match(line)
            if entry_match:
                entries.append(
                    {
                        "date": entry_match.group(1),
                        "hash": entry_match.group(2),
                        "change_order": entry_match.group(3),
                        "author_name": entry_match.group(4),
                        "author_id": entry_match.group(5),
                        "reason": entry_match.group(6),
                    }
                )

        return entries
