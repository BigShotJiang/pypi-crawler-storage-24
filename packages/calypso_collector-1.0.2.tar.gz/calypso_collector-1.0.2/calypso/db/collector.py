"""Query registry and DuckDB collection engine for Calypso."""

import base64
import inspect
import logging
from dataclasses import dataclass, field
from datetime import datetime, date
from decimal import Decimal
from pathlib import Path

import duckdb
import oracledb

from calypso.db import queries

logger = logging.getLogger(__name__)


@dataclass
class CollectionResult:
    duckdb_path: Path
    tables_collected: int = 0
    tables_failed: int = 0
    errors: list[dict] = field(default_factory=list)


def build_query_registry() -> dict[str, callable]:
    """Auto-discover all query functions in queries.py.

    Returns a dict of {table_name: callable} where table_name is the
    full function name (e.g. 'get_system_info_query', 'archive_log_info').
    """
    registry = {}
    for name, func in inspect.getmembers(queries, inspect.isfunction):
        if func.__module__ == queries.__name__:
            registry[name] = func
    # Safety check
    assert len(registry) == len(set(registry.keys())), "Duplicate table names in query registry"
    return registry


def _sanitize_value(val):
    """Convert Oracle-specific types to DuckDB-safe values."""
    if val is None:
        return None
    if isinstance(val, Decimal):
        return str(val)
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if isinstance(val, bytes):
        return base64.b64encode(val).decode("ascii")
    if hasattr(val, "read"):  # LOB objects
        data = val.read()
        if isinstance(data, bytes):
            return base64.b64encode(data).decode("ascii")
        return str(data)
    return str(val)


def _collect_one(oracle_conn, duckdb_conn, table_name, query_func):
    """Execute one query against Oracle and store results in DuckDB.

    Returns (row_count, error_or_none).
    """
    try:
        sql = query_func()
        cursor = oracle_conn.cursor()
        cursor.execute(sql)
        raw_columns = [col[0].lower() for col in cursor.description]

        # Deduplicate column names (e.g. two 'username' columns from a join)
        columns = []
        seen = {}
        for c in raw_columns:
            if c in seen:
                seen[c] += 1
                columns.append(f"{c}_{seen[c]}")
            else:
                seen[c] = 0
                columns.append(c)

        rows = cursor.fetchall()
    except oracledb.Error as e:
        error_obj = e.args[0] if e.args else e
        error_code = str(getattr(error_obj, "code", "N/A"))
        return 0, {"table_name": table_name, "error_code": error_code, "error_message": str(e)}

    # Sanitize all values
    sanitized = []
    for row in rows:
        sanitized.append([_sanitize_value(v) for v in row])

    # Create table and insert rows
    if columns:
        col_defs = ", ".join(f'"{c}" VARCHAR' for c in columns)
        duckdb_conn.execute(f'CREATE TABLE "{table_name}" ({col_defs})')
        if sanitized:
            placeholders = ", ".join(["?"] * len(columns))
            duckdb_conn.executemany(
                f'INSERT INTO "{table_name}" VALUES ({placeholders})',
                sanitized,
            )
    else:
        duckdb_conn.execute(f'CREATE TABLE "{table_name}" (empty_result VARCHAR)')

    return len(sanitized), None


def run_collection(oracle_conn, output_dir, metadata=None, progress_callback=None):
    """Run all queries and store results in a DuckDB file.

    Args:
        oracle_conn: Active oracledb connection.
        output_dir: Directory for the .duckdb file.
        metadata: Dict of key/value pairs to store (host, port, etc.).
        progress_callback: Callable(table_name, current, total) for progress updates.

    Returns:
        CollectionResult with summary of the collection.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    duckdb_path = output_dir / "calypso_collection.duckdb"

    # Remove existing file to start fresh
    if duckdb_path.exists():
        duckdb_path.unlink()

    registry = build_query_registry()
    result = CollectionResult(duckdb_path=duckdb_path)
    total = len(registry)

    con = duckdb.connect(str(duckdb_path))
    try:
        # Create metadata table
        con.execute("CREATE TABLE _metadata (key VARCHAR, value VARCHAR)")
        meta = {
            "calypso_collected_at": datetime.now().isoformat(),
            "query_count": str(total),
        }
        if metadata:
            meta.update(metadata)
        for k, v in meta.items():
            con.execute("INSERT INTO _metadata VALUES (?, ?)", [k, str(v)])

        # Create manifest and errors tables
        con.execute(
            "CREATE TABLE _manifest (table_name VARCHAR, row_count INTEGER, column_count INTEGER, collected_at TIMESTAMP)"
        )
        con.execute(
            "CREATE TABLE _errors (table_name VARCHAR, error_code VARCHAR, error_message VARCHAR)"
        )

        # Collect each query
        for i, (table_name, query_func) in enumerate(registry.items()):
            if progress_callback:
                progress_callback(table_name, i, total)

            row_count, error = _collect_one(oracle_conn, con, table_name, query_func)

            if error:
                result.tables_failed += 1
                result.errors.append(error)
                con.execute(
                    "INSERT INTO _errors VALUES (?, ?, ?)",
                    [error["table_name"], error["error_code"], error["error_message"]],
                )
                # ORA-942 (table/view does not exist) is expected for optional
                # components like Statspack, x$ internal tables, and features
                # not installed on the target database.
                if error["error_code"] == "942":
                    logger.debug("Query '%s' skipped (ORA-942): table or view does not exist", table_name)
                else:
                    logger.warning("Query '%s' failed (ORA-%s): %s", table_name, error["error_code"], error["error_message"])
            else:
                result.tables_collected += 1
                # Get column count from the table we just created
                col_info = con.execute(f"SELECT * FROM \"{table_name}\" LIMIT 0").description
                col_count = len(col_info) if col_info else 0
                con.execute(
                    "INSERT INTO _manifest VALUES (?, ?, ?, ?)",
                    [table_name, row_count, col_count, datetime.now()],
                )
    finally:
        con.close()

    return result
