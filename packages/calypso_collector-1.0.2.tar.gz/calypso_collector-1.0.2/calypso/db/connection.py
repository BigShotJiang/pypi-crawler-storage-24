# db/connection.py

import oracledb
import logging
import os

logger = logging.getLogger(__name__)

# Track if thick mode has been initialized
_thick_mode_initialized = False


def init_thick_mode(lib_dir: str = None) -> bool:
    """
    Initialize Oracle thick mode for Native Network Encryption support.

    Args:
        lib_dir: Path to Oracle Instant Client libraries. If None, uses
                 ORACLE_CLIENT_LIB env var or searches default locations.

    Returns:
        bool: True if initialized successfully.

    Raises:
        RuntimeError: If thick mode initialization fails.
    """
    global _thick_mode_initialized

    if _thick_mode_initialized:
        logger.debug("Thick mode already initialized")
        return True

    if lib_dir is None:
        lib_dir = os.environ.get('ORACLE_CLIENT_LIB')

    try:
        if lib_dir:
            logger.info(f"Initializing Oracle thick mode with lib_dir: {lib_dir}")
            oracledb.init_oracle_client(lib_dir=lib_dir)
        else:
            logger.info("Initializing Oracle thick mode (default library search)")
            oracledb.init_oracle_client()

        _thick_mode_initialized = True
        logger.info("Oracle thick mode initialized successfully")
        return True
    except oracledb.Error as e:
        raise RuntimeError(f"Failed to initialize thick mode: {e}. "
                           "Ensure Oracle Instant Client is installed.") from e


class DatabaseConnectionError(Exception):
    """Custom exception for database connection errors."""
    pass

def get_db_connection(user, password, hostname, port, service_name, sysdba=False) -> oracledb.Connection:
    """
    Establishes and returns a connection to the Oracle database using provided credentials.

    Args:
        user (str): The database username.
        password (str): The database password.
        hostname (str): The database host.
        port (int): The database port.
        service_name (str): The database service name.

    Returns:
        oracledb.Connection: An active database connection object.

    Raises:
        DatabaseConnectionError: If the connection to the database fails.
    """
    try:
        # Use oracledb's DSN builder for clarity and correctness
        dsn = oracledb.makedsn(hostname, int(port), service_name=service_name)
    except (ValueError, TypeError) as e:
        msg = f"Invalid connection parameters. Details: {e}"
        logger.error(msg)
        raise DatabaseConnectionError(msg) from e

    try:
        logger.info(f"Attempting to connect to {hostname}...")
        # DEBUG log to show connection parameters (NEVER log the password)
        logger.debug(f"Connection details: user='{user}', dsn='{dsn}'")

        connect_kwargs = dict(user=user, password=password, dsn=dsn)
        if sysdba:
            connect_kwargs["mode"] = oracledb.AUTH_MODE_SYSDBA
            logger.info("Connecting with SYSDBA privilege")
        connection = oracledb.connect(**connect_kwargs)
        logger.info("Database connection successful! 🎉")
        return connection
    except oracledb.Error as e:
        msg = f"Error connecting to Oracle Database: {e}"
        logger.error(msg)
        raise DatabaseConnectionError(msg) from e
