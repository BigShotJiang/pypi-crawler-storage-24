"""Calypso Collector - Oracle database data collector for assessment."""

__version__ = "1.0.2"
__version_info__ = (1, 0, 2)
