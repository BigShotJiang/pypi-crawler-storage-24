"""Command-line interface for Calypso Collector."""

import argparse
import getpass
import logging
import os
import sys

from rich.progress import Progress, BarColumn, TextColumn, TaskProgressColumn, TimeElapsedColumn

from calypso import __version__
from calypso.db.connection import get_db_connection, DatabaseConnectionError, init_thick_mode
from calypso.db.collector import run_collection
from calypso.export import export_all


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="calypso",
        description="Calypso Collector - Oracle database data collector for assessment",
    )
    parser.add_argument("-V", "--version", action="version", version=f"%(prog)s {__version__}")

    # Database connection (required unless just checking --version/--help)
    parser.add_argument("--host", required=True, help="Database hostname or IP address")
    parser.add_argument("--port", type=int, default=1521, help="Database port (default: 1521)")
    parser.add_argument("--service-name", required=True, help="Database service name")
    parser.add_argument("--user", required=True, help="Database username")
    parser.add_argument("--password", default=None,
                        help="Database password (or set CALYPSO_PASSWORD env var; prompted if neither)")

    # Oracle client options
    parser.add_argument("--thick", action="store_true",
                        help="Enable thick mode for Native Network Encryption (requires Oracle Instant Client)")
    parser.add_argument("--oracle-lib", default=None,
                        help="Path to Oracle Instant Client libraries (used with --thick)")
    parser.add_argument("--sysdba", action="store_true",
                        help="Connect with SYSDBA privilege (required for x$ tables and SYS user)")
    parser.add_argument("--pdb", default=None,
                        help="PDB name to switch to after connecting to CDB")

    # Output options
    parser.add_argument("--output-dir", default="./calypso_output",
                        help="Output directory (default: ./calypso_output)")
    parser.add_argument("--skip-export", action="store_true",
                        help="Only produce .duckdb file, skip JSON/Parquet export")
    parser.add_argument("--save-cache", action="store_true",
                        help="Keep the .duckdb file after export (deleted by default)")

    # Logging
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable debug logging")

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s - %(levelname)s - %(message)s")

    # Resolve password: --password flag > env var > interactive prompt
    if args.password is None:
        args.password = os.environ.get("CALYPSO_PASSWORD")
    if args.password is None:
        args.password = getpass.getpass("Database password: ")

    try:
        # Initialize thick mode if requested
        if args.thick:
            print("Initializing Oracle thick mode...")
            init_thick_mode(args.oracle_lib)

        # Connect to Oracle
        print(f"Connecting to {args.host}:{args.port}/{args.service_name}...")
        connection = get_db_connection(args.user, args.password, args.host, args.port, args.service_name, sysdba=args.sysdba)

        # Switch to PDB if specified
        if args.pdb:
            print(f"Switching to PDB: {args.pdb}")
            cursor = connection.cursor()
            cursor.execute(f"ALTER SESSION SET CONTAINER = {args.pdb}")
            cursor.close()
            print(f"Connected to PDB: {args.pdb}")

        # Build metadata for the collection
        metadata = {
            "source_host": args.host,
            "source_port": str(args.port),
            "source_service": args.service_name,
            "source_user": args.user,
            "calypso_version": __version__,
        }
        if args.pdb:
            metadata["source_pdb"] = args.pdb

        print(f"\n")
        print(f"*******************************************\n")
        print(f"RheoData Calypso Collector v{__version__}")
        print(f"\n*******************************************")

        # Collect data with progress bar
        print(f"\nCollecting Oracle assessment data...")
        with Progress(
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
        ) as progress:
            task = progress.add_task("Starting collection...", total=None)

            def on_progress(table_name, current, total):
                progress.update(task, total=total, completed=current, description=f"[cyan]{table_name}")

            result = run_collection(connection, args.output_dir, metadata=metadata, progress_callback=on_progress)
            progress.update(task, completed=result.tables_collected + result.tables_failed)

        connection.close()

        # Summary
        print(f"\nCollection complete:")
        print(f"  Tables collected: {result.tables_collected}")
        print(f"  Tables failed:    {result.tables_failed}")
        print(f"  DB file:      {result.duckdb_path}")

        if result.errors:
            print(f"\nFailed queries:")
            for err in result.errors:
                print(f"  {err['table_name']}: ORA-{err['error_code']}")

        # Export to JSON + Parquet
        if not args.skip_export:
            print(f"\nExporting to JSON and Parquet...")
            with Progress(
                TextColumn("[bold green]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                TimeElapsedColumn(),
            ) as progress:
                task = progress.add_task("Exporting...", total=None)

                def on_export_progress(table_name, current, total):
                    progress.update(task, total=total, completed=current, description=f"[green]{table_name}")

                json_count, parquet_count = export_all(result.duckdb_path, args.output_dir, on_export_progress)
                progress.update(task, completed=json_count)

            print(f"  JSON files:    {args.output_dir}/json/ ({json_count} files)")
            print(f"  Parquet files: {args.output_dir}/parquet/ ({parquet_count} files)")
            print(f"  Please zip up these files to {args.output_dir}/calypso_output.zip and contact RheoData")

        # Clean up or keep the .duckdb cache file
        if args.save_cache or args.skip_export:
            print(f"  Cache file:    {result.duckdb_path}")
        else:
            result.duckdb_path.unlink(missing_ok=True)

        print(f"\nCalypso collection complete.")
        return 0

    except DatabaseConnectionError as e:
        print(f"Connection failed: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        logging.critical(f"An unexpected error occurred: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
