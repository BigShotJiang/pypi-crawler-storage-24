"""Tests for the Calypso Collector."""

from calypso import __version__
from calypso.db.collector import build_query_registry


def test_version():
    assert __version__ == "1.0.2"


def test_query_registry_has_333_entries():
    registry = build_query_registry()
    assert len(registry) == 333


def test_query_registry_no_duplicate_table_names():
    registry = build_query_registry()
    table_names = list(registry.keys())
    assert len(table_names) == len(set(table_names))


def test_all_registry_entries_are_callable():
    registry = build_query_registry()
    for name, func in registry.items():
        assert callable(func), f"{name} is not callable"


def test_all_queries_return_strings():
    registry = build_query_registry()
    for name, func in registry.items():
        sql = func()
        assert isinstance(sql, str), f"{name} returned {type(sql)}, expected str"
        assert len(sql.strip()) > 0, f"{name} returned empty SQL"
