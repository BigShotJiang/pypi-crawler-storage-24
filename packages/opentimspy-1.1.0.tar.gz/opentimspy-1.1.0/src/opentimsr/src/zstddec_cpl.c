#include "zstd/zstddeclib.c"
