from allianceauth.services.hooks import get_extension_logger
from django.shortcuts import render, redirect
from django.views.generic import TemplateView, View
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from .permissions import PERMISSION_CAN_MANAGE
from .forms import AddBrForm
from .models.filterentities import FilterEntity
from .models.battlereport import BattleReport
from .models.killmails import KillCompensation
from .models.charmail import CharMailParse
from eveuniverse.models import EveEntity

from allianceauth.framework.api.user import get_main_character_from_user
from django.conf import settings
from esi.models import Token
from esi.decorators import tokens_required
from django.utils.translation import gettext as _
from django.db.models import Q
from django.db.models import Sum
from esi.views import sso_redirect

logger = get_extension_logger(__name__)
required_scopes = "esi-mail.read_mail.v1 esi-mail.send_mail.v1 esi-ui.open_window.v1"

def request_scopes(request, *args, **kwargs):
    redir = sso_redirect(request,required_scopes.split(' '), 'br_compensations:dashboard')
    return redir

class DashboardView(LoginRequiredMixin, PermissionRequiredMixin,TemplateView): 
    template_name = 'br_compensations/dashboard.html'
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    
    def get_context_data(self, filter=None, **kwargs):
        context = super().get_context_data(**kwargs)

        character = get_main_character_from_user(self.request.user)
        charToken = Token.get_token(character.character_id,"esi-mail.read_mail.v1 esi-mail.send_mail.v1 esi-ui.open_window.v1")
        
        if charToken:
            context['scopes_valid'] = True
        else:
            context['scopes_valid'] = False
        
        
        # Получаем параметр сортировки из GET запроса
        sort_by = self.request.GET.get('sort', '-created_at')
        context['current_sort'] = sort_by
        
        data = []
        dbFilters = FilterEntity.objects.all()
            
        for f in dbFilters:
            entry_icon = ""
            match f.entity_type:
                case FilterEntity.ALLIANCE:
                    entry_icon = f"https://images.evetech.net/alliances/{f.entity_id}/logo?size=32"
                case FilterEntity.CORPORATION:
                    entry_icon = f"https://images.evetech.net/corporations/{f.entity_id}/logo?size=32"
                case FilterEntity.CHARACTER:
                    entry_icon = f"https://images.evetech.net/characters/{f.entity_id}/portrait?size=32"
                case _:
                    entry_icon = ''
            
            try:
                #entry = EveEntity.objects.get(id=f.entity_id)

                data.append({
                    'filter': {
                        'id': f.entity_id,
                        'type': f.entity_type,
                        },
                    'display_name': str(f),
                    "icon": entry_icon
                })
            except Exception as e:
                logger.error(f"Ошибка при поиске в ESI: {e}")
                try:
                    EveEntity.objects.resolve_name(id=f.entity_id)
                    entry = EveEntity.objects.get(id=f.entity_id)
                
                    data.append({
                        'filter': {
                            'id': f.entity_id,
                            'type': f.entity_type,
                            },
                        'display_name': str(entry),
                        "icon": entry_icon
                    })
                except Exception as e:
                    logger.error(f"Ошибка при поиске в eve universe: {e}")
            
        match filter:
            case 'rejected':
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_REJECT).all()
                context['listTitle'] = _('Отмененные компенсации')
            case 'accepted':
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_COMPLETE).all()
                context['listTitle'] = _('Выполненные компенсации')
            case 'all':
                kills = KillCompensation.objects.all()
                context['listTitle'] = _('Все компенсации')
            case BattleReport.BATTLEREPORT:
                kills = KillCompensation.objects.filter(source__report_type = BattleReport.BATTLEREPORT, status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Баттл репорты')
            case BattleReport.KILLMAIL:
                kills = KillCompensation.objects.filter(source__report_type = BattleReport.KILLMAIL, status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Киллмэйл')
            case _:
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Текущие компенсации')
        
        context["data"] = sorted(data, key=lambda filter: filter['display_name'])
        context["total_loss"] = kills.aggregate(Sum('loss_value'))['loss_value__sum']
        
        # Применяем сортировку к полному набору данных
        valid_sort_fields = {
            'character_name': 'character_name',
            '-character_name': '-character_name',
            'status': 'status',
            '-status': '-status',
            'loss_value': 'loss_value',
            '-loss_value': '-loss_value',
            'timestamp': 'timestamp',
            '-timestamp': '-timestamp',
            'created_at': 'created_at',
            '-created_at': '-created_at',
        }
        
        if sort_by in valid_sort_fields:
            kills_queryset = kills.order_by(valid_sort_fields[sort_by])
        else:
            kills_queryset = kills.order_by('-created_at', 'status', 'timestamp', '-loss_value')
        
        # Пагинация для killmails
        page_size = 20
        page = self.request.GET.get('page', 1)
        paginator = Paginator(kills_queryset, page_size)
        
        try:
            killmails_page = paginator.page(page)
        except PageNotAnInteger:
            killmails_page = paginator.page(1)
        except EmptyPage:
            killmails_page = paginator.page(paginator.num_pages)
        
        context["killmails"] = killmails_page
        context["is_paginated"] = paginator.num_pages > 1
        context["page_obj"] = killmails_page
        context["paginator"] = paginator
        
        context["mailparser"] = CharMailParse.objects.get(character_id=character.character_id) if character and CharMailParse.objects.filter(character_id = character.character_id).exists() else None
        context["parse_check"] = 'checked' if context['mailparser'] is not None else ''
        context["character_id"] = character.character_id
        context["show_api"] = settings.DEBUG
        
        return context
    
    def post(self, request, *args, **kwargs):
        """
        Обрабатывает POST запросы (например, после выбора персонажа).
        Перенаправляем на GET запрос той же страницы.
        """
        filter_param = kwargs.get('filter', None)
        if filter_param:
            return redirect(f"/br_compensations/dashboard/{filter_param}/")
        return redirect('/br_compensations/dashboard/')


class BattleReportsView(LoginRequiredMixin,PermissionRequiredMixin, TemplateView):
    template_name="br_compensations/reports.html"
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def get_context_data(self, filter:str = None, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Получаем параметр сортировки из GET запроса
        sort_by = self.request.GET.get('sort', '-added_at')
        context['current_sort'] = sort_by
        
        match filter:
            case 'complete':
                reports_queryset = BattleReport.objects.filter(status = BattleReport.PROCESS_COMPLETE)
            case 'failed':
                reports_queryset = BattleReport.objects.filter(status = BattleReport.PROCESS_FAILED)
            case 'all':
                reports_queryset = BattleReport.objects.all()
            case _:
                reports_queryset = BattleReport.objects.filter(Q(status = BattleReport.PROCESS_NEW)|Q(status = BattleReport.PROCESS_PROCESSING)|Q(status = BattleReport.PROCESS_REINITIALIZE))
        
        # Применяем сортировку к полному набору данных
        valid_sort_fields = {
            'report_type': 'report_type',
            '-report_type': '-report_type',
            'uid': 'uid',
            '-uid': '-uid',
            'updatedAt': 'updatedAt',
            '-updatedAt': '-updatedAt',
            'comment': 'comment',
            '-comment': '-comment',
            'status': 'status',
            '-status': '-status',
            'added_at': 'added_at',
            '-added_at': '-added_at',
        }
        
        if sort_by in valid_sort_fields:
            reports_queryset = reports_queryset.order_by(valid_sort_fields[sort_by])
        else:
            reports_queryset = reports_queryset.order_by('-added_at', '-updatedAt')
        
        # Пагинация для reports
        page_size = 20
        page = self.request.GET.get('page', 1)
        paginator = Paginator(reports_queryset, page_size)
        
        try:
            reports_page = paginator.page(page)
        except PageNotAnInteger:
            reports_page = paginator.page(1)
        except EmptyPage:
            reports_page = paginator.page(paginator.num_pages)
        
        context["reports"] = reports_page
        context["is_paginated"] = paginator.num_pages > 1
        context["page_obj"] = reports_page
        context["paginator"] = paginator
        context["form"] = AddBrForm()
        context["show_api"] = False
        return context
    
    def post(self,request):
        brForm = AddBrForm(request.POST)
        if brForm.is_valid():
            report = BattleReport(link = brForm.cleaned_data['link'], comment = brForm.cleaned_data['comment'])
            report.save()
            return redirect('/br_compensations/reports/')
        return render(request,'/br_compensations/reports.html',{"form":brForm, "reports": BattleReport.objects.all()})

    
dashboard = DashboardView.as_view()
reports = BattleReportsView.as_view()

class MassActionView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    View для обработки массовых операций с киллмэйлами
    """
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def post(self, request, *args, **kwargs):
        """
        Обработка массовых операций (синхронная обработка без Celery)
        action: 'approve', 'reject', 'delete', 'restore'
        """
        from .models.killmails import KillCompensation
        from .utils.mailtools import IngameMail
        from allianceauth.eveonline.models import EveCharacter
        from django.conf import settings
        from allianceauth.framework.api.user import get_main_character_from_user
        
        # Получаем список ID киллмэйлов
        if request.content_type == 'application/json':
            import json
            data = json.loads(request.body)
            killmail_ids = data.get('killmail_ids', [])
        else:
            killmail_ids = request.POST.getlist('killmail_ids', [])
        
        if not killmail_ids:
            return JsonResponse({
                'success': False,
                'message': 'Не выбраны киллмэйлы для обработки'
            }, status=400)
        
        # Валидация действия
        allowed_actions = ['approve', 'reject', 'delete', 'restore']
        action = kwargs.get('action')
        if action not in allowed_actions:
            return JsonResponse({
                'success': False,
                'message': f'Недопустимое действие: {action}'
            }, status=400)
        
        try:
            # Получаем текущего персонажа пользователя
            current_character = None
            try:
                current_character = get_main_character_from_user(request.user)
            except Exception as e:
                logger.warning(f'Could not get main character for user {request.user.pk}: {e}')
            
            # Получаем киллмэйлы
            kills = KillCompensation.objects.filter(killmail_id__in=killmail_ids)
            total_count = kills.count()
            updated_count = 0
            deleted_count = 0
            failed_count = 0
            errors = []
            
            logger.info(f'Starting mass action: {action} for {total_count} items by user {request.user}')
            
            # Обрабатываем каждый киллмэйл синхронно
            for kill in kills:
                try:
                    if action == 'approve':
                        # Одобрить компенсацию
                        if kill.status == KillCompensation.STATUS_NEW:
                            kill.status = KillCompensation.STATUS_COMPLETE
                            kill.comment = 'Массовое одобрение администратором'
                            
                            # Отправляем письмо, если есть текущий персонаж
                            if current_character and (request.content_type == 'application/json' and data.get('openMail') == 'true' or request.POST.get('openMail') == 'true'):
                                try:
                                    IngameMail.create_mail(
                                        sender=current_character,
                                        to=[kill.character_id],
                                        subject=("[TEST] " if settings.DEBUG else "") + "КОМПЕНСАЦИЯ БОЕВЫХ ВЫЛЕТОВ",
                                        body=f"""Уважаемый, <a href="showinfo:1377//{kill.character_id}">{kill.character_name}</a>.

Вам будет выплачена компенсация <a href="killReport:{kill.killmail_id}:{kill.hash}">потери корабля</a> от {kill.timestamp.strftime("%d.%m.%Y, %H:%M")}!
Компенсация будет выслана в виде ISK по оценке ZKB за вычетом страховки и некоторых предметов в карго по типу бустеров.
Если вам не нужна выданная компенсация, либо же она пришла повторно, вы всегда можете отослать иски на <a href="showinfo:2//98698983">Scan Stakan</a>!

С уважением,
<a href="showinfo:1377//{current_character.character_id}">{current_character.character_name}</a>"""
                                    )
                                except Exception as mail_error:
                                    logger.error(f'Failed to send mail for kill {kill.killmail_id}: {mail_error}')
                            
                            kill.save()
                            updated_count += 1
                            logger.debug(f'Approved killmail {kill.killmail_id}')
                    
                    elif action == 'reject':
                        # Отклонить компенсацию
                        if kill.status == KillCompensation.STATUS_NEW:
                            kill.status = KillCompensation.STATUS_REJECT
                            kill.comment = 'Массовое отклонение администратором'
                            
                            # Отправляем письмо, если есть текущий персонаж
                            if current_character and (request.content_type == 'application/json' and data.get('openMail') == 'true' or request.POST.get('openMail') == 'true'):
                                try:
                                    IngameMail.create_mail(
                                        sender=current_character,
                                        to=[kill.character_id],
                                        subject=("[TEST] " if settings.DEBUG else "") + "ОТКАЗ В КОМПЕНСАЦИИ",
                                        body=f"""Уважаемый, <a href="showinfo:1377//{kill.character_id}">{kill.character_name}</a>.

<a href="killReport:{kill.killmail_id}:{kill.hash}">Потерянный вами корабль</a> от {kill.timestamp.strftime("%d.%m.%Y, %H:%M")} не подпадает под программу компенсации!
В соответствии с правилами компенсации боевых потерь ваш корабль не будет компенсирован.
Если вы не согласны с данным решением, обратитесь к ответственному за компенсации или офицеру альянса.

С уважением,
<a href="showinfo:1377//{current_character.character_id}">{current_character.character_name}</a>"""
                                    )
                                except Exception as mail_error:
                                    logger.error(f'Failed to send mail for kill {kill.killmail_id}: {mail_error}')
                            
                            kill.save()
                            updated_count += 1
                            logger.debug(f'Rejected killmail {kill.killmail_id}')
                    
                    elif action == 'delete':
                        # Удалить киллмэйл
                        kill_id = kill.killmail_id
                        kill.delete()
                        deleted_count += 1
                        logger.debug(f'Deleted killmail {kill_id}')
                    
                    elif action == 'restore':
                        # Восстановить киллмэйл
                        if kill.status in [KillCompensation.STATUS_COMPLETE, KillCompensation.STATUS_REJECT]:
                            kill.status = KillCompensation.STATUS_NEW
                            kill.comment = 'Восстановлено администратором'
                            kill.save()
                            updated_count += 1
                            logger.debug(f'Restored killmail {kill.killmail_id}')
                    
                    else:
                        logger.warning(f'Unknown action: {action}')
                        failed_count += 1
                        
                except Exception as e:
                    logger.error(f'Error processing killmail {kill.killmail_id}: {e}')
                    failed_count += 1
                    errors.append(f'{kill.killmail_id}: {str(e)}')
            
            logger.info(f'Mass action completed: {action}. Updated: {updated_count}, Deleted: {deleted_count}, Failed: {failed_count}')
            
            return JsonResponse({
                'success': True,
                'updated': updated_count,
                'deleted': deleted_count,
                'failed': failed_count,
                'total': total_count,
                'errors': errors[:10],  # Максимум 10 ошибок в ответе
                'message': f'Операция завершена: {updated_count} обновлено, {deleted_count} удалено, {failed_count} ошибок'
            })
        except Exception as e:
            logger.error(f'Error in mass action: {e}')
            return JsonResponse({
                'success': False,
                'message': f'Ошибка при выполнении операции: {str(e)}'
            }, status=500)

class TaskStatusView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    View для проверки статуса Celery задачи
    """
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def get(self, request, *args, **kwargs):
        """
        Получение статуса задачи по её ID
        """
        from celery.result import AsyncResult
        
        # Получаем task_id из URL параметров
        task_id = kwargs.get('task_id')
        
        try:
            # Проверяем статус задачи через Celery AsyncResult
            task = AsyncResult(task_id)
            
            # Проверяем, поддерживает ли backend получение статуса
            try:
                status = task.status
            except AttributeError:
                # Backend не поддерживает получение статуса (например, DisabledBackend)
                return JsonResponse({
                    'status': 'UNKNOWN',
                    'result': {'message': 'Backend для хранения результатов не настроен'}
                })
            
            result = None
            
            if status == 'SUCCESS':
                try:
                    result = task.result
                    if isinstance(result, str):
                        import json
                        try:
                            result = json.loads(result)
                        except (json.JSONDecodeError, TypeError):
                            result = {'data': result}
                except Exception as e:
                    result = {'error': f'Ошибка получения результата: {str(e)}'}
            elif status == 'FAILURE':
                result = {'error': str(task.info)}
            elif status == 'PROGRESS':
                try:
                    result = task.info
                    if isinstance(result, str):
                        import json
                        try:
                            result = json.loads(result)
                        except (json.JSONDecodeError, TypeError):
                            result = {'data': result}
                except Exception as e:
                    result = {'error': f'Ошибка получения прогресса: {str(e)}'}
            elif status == 'PENDING':
                result = {'message': 'Задача в очереди на выполнение'}
            elif status == 'RETRY':
                result = {'message': 'Задача повторно выполняется'}
            elif status == 'UNKNOWN':
                result = {'message': 'Статус задачи неизвестен'}
            
            return JsonResponse({
                'status': status,
                'result': result
            })
        except Exception as e:
            logger.error(f'Error getting task status: {e}')
            return JsonResponse({
                'status': 'FAILURE',
                'result': {'error': str(e)}
            }, status=500)