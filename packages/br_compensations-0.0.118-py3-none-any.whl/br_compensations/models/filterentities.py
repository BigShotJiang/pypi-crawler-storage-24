from django.db import models
from django.utils.translation import gettext_lazy as _
from allianceauth.eveonline.models import EveCharacter, EveAllianceInfo, EveCorporationInfo


# Create your models here.
class FilterEntity(models.Model):
    '''
        Таблица для хранения данных фильтров киллмэйлов
    '''
    ALLIANCE = 'alliance'
    CORPORATION = 'corporation'
    CHARACTER = 'character'
    ENTITY_TYPE_CHOICE = [
        (ALLIANCE,'Alliance'),
        (CORPORATION,'Corporation'),
        (CHARACTER,'Character')
    ]
    
    entity_type = models.CharField(max_length=20, choices=ENTITY_TYPE_CHOICE)
    entity_id = models.IntegerField(
        name='entity_id',
        null=False,
        blank=False,
        unique=True
    )
    added_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['entity_type']),
        ]
        unique_together = [('entity_type', 'entity_id')]
    def __str__(self):
        if self.entity_type == self.ALLIANCE:
            alliance = EveAllianceInfo.objects.get(alliance_id=self.entity_id)
            if alliance:
                return alliance.alliance_name 
            else:
                return f"Alliance: {self.entity_id}"
        elif self.entity_type == self.CORPORATION:
            corp = EveCorporationInfo.objects.get(corporation_id=self.entity_id)
            if corp:
                return corp.corporation_name
            else:
                return f"Corporation: {self.entity_id}"
            
        character = EveCharacter.objects.get_character_by_id(self.entity_id)
        if character:
            return character.character_name
        else:
            return f"Character: {self.entity_id}"