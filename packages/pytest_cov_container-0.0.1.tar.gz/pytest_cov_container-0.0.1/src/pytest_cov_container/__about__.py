# SPDX-FileCopyrightText: 2026-present tomaDev <genins21@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
