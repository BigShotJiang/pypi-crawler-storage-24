from instaui.systems.dataclass_system import dataclass


@dataclass(frozen=True)
class StyleTag:
    content: str
    group_id: str | None = None
    attrs: dict | None = None
