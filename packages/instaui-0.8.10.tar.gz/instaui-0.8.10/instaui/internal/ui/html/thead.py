from __future__ import annotations
from instaui.internal.ui.element import Element


class THead(Element):
    def __init__(self):
        super().__init__("thead")
