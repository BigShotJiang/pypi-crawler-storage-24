from __future__ import annotations
from instaui.internal.ui.element import Element


class TBody(Element):
    def __init__(self):
        super().__init__("tbody")
