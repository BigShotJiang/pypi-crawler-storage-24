from __future__ import annotations
from typing import Any
from instaui.internal.ui.element import Element


class Code(Element):
    def __init__(self, code: str | Any | None = None):
        super().__init__("code")
        self.props({"innerText": code})
