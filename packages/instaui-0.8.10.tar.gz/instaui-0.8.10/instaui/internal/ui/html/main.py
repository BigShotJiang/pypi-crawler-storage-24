from __future__ import annotations
from instaui.internal.ui.element import Element


class Main(Element):
    def __init__(self, content: str | None = None):
        super().__init__("main")
        self.props({"innerText": content})
