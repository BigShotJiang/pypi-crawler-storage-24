from __future__ import annotations
from instaui.internal.ui.element import Element


class Header(Element):
    def __init__(self, content: str | None = None):
        super().__init__("header")
        self.props({"innerText": content})
