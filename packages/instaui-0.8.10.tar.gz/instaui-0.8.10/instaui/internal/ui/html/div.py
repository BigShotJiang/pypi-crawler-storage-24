from __future__ import annotations
from instaui.internal.ui.element import Element


class Div(Element):
    def __init__(self, content: str | None = None):
        super().__init__("div")
        self.props({"innerText": content})
