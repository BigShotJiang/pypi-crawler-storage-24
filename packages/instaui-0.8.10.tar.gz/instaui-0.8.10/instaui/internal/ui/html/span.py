from __future__ import annotations
from typing import Any
from instaui.internal.ui.element import Element


class Span(Element):
    def __init__(
        self,
        text: str | Any | None = None,
    ):
        super().__init__("span")
        self.props(
            {
                "innerText": text,
            }
        )
