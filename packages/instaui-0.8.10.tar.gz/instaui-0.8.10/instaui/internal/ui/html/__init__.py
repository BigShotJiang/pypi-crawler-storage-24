__all__ = [
    "span",
    "label",
    "paragraph",
    "p",
    "input",
    "number",
    "button",
    "checkbox",
    "radio",
    "form",
    "select",
    "option",
    "ul",
    "li",
    "div",
    "range",
    "date",
    "link",
    "textarea",
    "table",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "image",
    "video",
    "i",
    "br",
    "code",
    "thead",
    "th",
    "tr",
    "tbody",
    "td",
    "table_header",
    "header",
    "nav",
    "main",
]

from .button import Button as button
from .checkbox import Checkbox as checkbox
from .code import Code as code
from .date import Date as date
from .div import Div as div
from .form import Form as form
from .header import Header as header
from .heading import H1 as h1
from .heading import H2 as h2
from .heading import H3 as h3
from .heading import H4 as h4
from .heading import H5 as h5
from .heading import H6 as h6
from .image import Image as image
from .input import Input as input
from .italic import Italic as i
from .label import Label as label
from .li import Li as li
from .line_break import Break as br
from .link import Link as link
from .main import Main as main
from .navigation import Navigation as nav
from .number import Number as number
from .paragraph import Paragraph as p
from .paragraph import Paragraph as paragraph
from .radio import Radio as radio
from .range import Range as range
from .select import Select as select
from .span import Span as span
from .table import Table as table
from .table_data import TableData as td
from .table_header import TableHeader as th
from .table_row import TableRow as tr
from .tbody import TBody as tbody
from .textarea import Textarea as textarea
from .thead import THead as thead
from .ul import Ul as ul
from .video import Video as video

option = select.Option
