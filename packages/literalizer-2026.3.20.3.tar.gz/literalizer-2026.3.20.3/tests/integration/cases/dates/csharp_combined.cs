using System.Collections.Generic;
var my_data = new Dictionary<string, object> {
    ["date"] = "2024-01-15",
    ["datetime"] = "2024-01-15T12:30:00+00:00"
};
my_data = new Dictionary<string, object> {
    ["date"] = "2024-01-15",
    ["datetime"] = "2024-01-15T12:30:00+00:00"
};
