def main():
    var my_data = {
        # Server configuration
        "host": "localhost",  # default host
        "port": "8080",
        # Enable debug mode
        "debug": "True",
    }
    my_data = {
        # Server configuration
        "host": "localhost",  # default host
        "port": "8080",
        # Enable debug mode
        "debug": "True",
    }
