import java.util.Map;
import java.util.Set;
class Check {
    public static void check() {
var my_data = new Object[]{
    "48656c6c6f"
};
my_data = new Object[]{
    "48656c6c6f"
};
    }
}
