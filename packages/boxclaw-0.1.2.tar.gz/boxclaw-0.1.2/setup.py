from setuptools import setup, find_packages

setup(
    name="boxclaw",
    version="0.1.1",
    description="Lean-verified multi-agent sandboxing for AI Applications",
    url="https://github.com/paulinebourigault/boxclaw",
    project_urls={
        "Repository": "https://github.com/paulinebourigault/boxclaw",
        "Bug Tracker": "https://github.com/paulinebourigault/boxclaw/issues",
    },
    packages=find_packages(),
    install_requires=[
    ],
)
