"""MCP server exposing techmanual.ai documentation tools to AI agents.

Provides three tools for searching and retrieving technical documentation:
    search        — Free-text search across all manual pages.
    list_manuals  — Browse and filter the manual catalog.
    get_page      — Retrieve specific page(s) from a document.

Run via stdio transport:
    python client/mcp_server.py

Register in claude_desktop_config.json or .claude.json with env vars:
    TMAI_API_URL, TMAI_API_KEY
"""

import json
import sys
from typing import Optional

from mcp.server.fastmcp import FastMCP

from techmanual_client import (
    Config,
    get_page,
    list_documents,
    load_config,
    search,
)

# Config is loaded lazily on first tool call so the module can be imported
# in test contexts without TMAI_API_KEY set.  When running as a server the
# first tool call will trigger the load and exit cleanly on missing config.
_cfg: Optional[Config] = None


def _get_cfg() -> Config:
    """Return the singleton Config, loading it on first access."""
    global _cfg
    if _cfg is None:
        try:
            _cfg = load_config()
        except ValueError as exc:
            print(f"MCP server startup error: {exc}", file=sys.stderr)
            sys.exit(1)
    return _cfg

_INSTRUCTIONS = """
techmanual.ai provides structured, searchable technical documentation for T&M
and industrial equipment. Pages are indexed from manufacturer PDFs and returned
with snippets and self-describing metadata.

## Model Number Rule

Never include model numbers in the query string. Model numbers degrade semantic
search and can produce zero results. Use the model_number filter instead.

  WRONG: search(query="N9040B phase noise measurement")
  RIGHT: search(query="phase noise measurement", model_number="N9040B")

The model_number filter is a metadata pre-filter — it scopes the search to
documents that cover that model, then ranks results by semantic relevance.

## Search Strategy

IMPORTANT: The search index contains technical documentation written in
manufacturer terminology.  Casual or vague queries will miss.  ALWAYS
rewrite the user's intent into precise technical terms before calling search.

  "make signal bigger"      -> "Reference Level", "Attenuation", "Scale/Div"
  "zoom in"                 -> "Span", "Start Frequency", "Stop Frequency"
  "clean up signal"         -> "Resolution Bandwidth", "Video Bandwidth", "Average"
  "speed up"                -> "Sweep Time", "Aperture"
  "trigger on spike"        -> "Slope", "Level", "Hysteresis"
  "save screenshot to USB"  -> "Save", "Screenshot", "Print to File"
  "connect to instrument"   -> "VISA", "GPIB", "LAN", "Remote Control Setup"
  "fix alignment"           -> "Alignment", "Calibration", "Self-Test"
  "measure voltage"         -> "DC Voltage Measurement", "Acquisition Mode"
  "set current limit"       -> "Current Limit", "OCP", "Protection"
  "decode serial data"      -> "Protocol Decode", "Bus Trigger", "I2C SPI UART"

If unsure of the right terminology, search broadly (e.g. "calibration") and
refine based on document titles and snippets in the results.

## Filter Warnings

If a filter (e.g. model_number) matches no documents, the response includes a
`filter_warnings` list with actionable guidance. Check this field when results
are empty — the filter, not the query, may be the problem.

## Workflow

1. list_manuals() — confirm a model is covered and get document IDs
2. search(query, model_number) — find relevant pages; start broad, then filter
3. get_page(document_id, page) — retrieve specific pages for cross-references
   or surrounding context around a search hit
"""

mcp = FastMCP("techmanual", instructions=_INSTRUCTIONS)


@mcp.tool(
    name="search",
    description=(
        "Search all technical documentation in the techmanual.ai catalog. "
        "Returns ranked manual pages with snippets and "
        "self-describing metadata (document title, equipment manufacturer, "
        "instrument type, and applicable model numbers). Use this as the "
        "primary way to find information. IMPORTANT: never put model numbers "
        "in the query string — pass them via the model_number filter instead."
    ),
)
def mcp_search(
    query: str,
    manufacturer: Optional[str] = None,
    model_number: Optional[str] = None,
    instrument_type: Optional[str] = None,
    document_id: Optional[int] = None,
    category: Optional[str] = None,
    limit: Optional[int] = None,
) -> str:
    """Search technical documentation pages.

    Args:
        query: Semantic search query describing the topic or procedure —
            e.g. "phase noise measurement", "error code E15", "rated wattage
            at 40°C". Do NOT include model numbers here; use the model_number
            filter instead. Model numbers in the query degrade search quality
            and can produce zero results.
        manufacturer: Case-insensitive substring match on manufacturer name.
            Scopes the search to documents from that manufacturer.
        model_number: Normalized match on applicable model number — spaces,
            hyphens, and case are ignored. Scopes the search to documents that
            cover that model, then ranks by semantic relevance of the query.
            Use this instead of putting the model number in the query string.
        instrument_type: Case-insensitive substring match on instrument type
            (e.g. "Spectrum Analyzer").
        document_id: Narrow to a single document.
        category: Filter by equipment type (future).
        limit: Maximum number of results to return (1-50, default 4). Use a
            low value (1-2) for focused lookups to save context, or higher
            values (8-10) when surveying a broad topic.

    Returns:
        JSON string of search results with page content, snippets,
        and nested document/equipment metadata.
    """
    results = search(
        _get_cfg(),
        query,
        manufacturer=manufacturer,
        model_number=model_number,
        instrument_type=instrument_type,
        document_id=document_id,
        category=category,
        limit=limit,
    )
    return json.dumps(results, indent=2)


@mcp.tool(
    name="list_manuals",
    description=(
        "Browse and filter the manual catalog. Returns document metadata "
        "including title, page count, estimated token count, and associated "
        "equipment (manufacturer, instrument_type, applicable model numbers). "
        "Use this to discover what documentation is available before diving "
        "into search or targeted page retrieval."
    ),
)
def mcp_list_manuals(
    query: Optional[str] = None,
    manufacturer: Optional[str] = None,
    model_number: Optional[str] = None,
    instrument_type: Optional[str] = None,
    category: Optional[str] = None,
    document_type: Optional[str] = None,
) -> str:
    """Browse and filter the manual catalog.

    Args:
        query: Fuzzy match on title/metadata — e.g. "FSW option K70",
            "installation guide".
        manufacturer: Case-insensitive substring match on manufacturer name.
        model_number: Case-insensitive substring match on applicable model
            number (matched against all models covered by each manual).
        instrument_type: Case-insensitive substring match on instrument type
            (e.g. "Network Analyzer").
        category: Filter by equipment type (future).
        document_type: Filter by document type (future).

    Returns:
        JSON string of document metadata with associated equipment info.
    """
    results = list_documents(
        _get_cfg(),
        query=query,
        manufacturer=manufacturer,
        model_number=model_number,
        instrument_type=instrument_type,
        category=category,
        document_type=document_type,
    )
    return json.dumps(results, indent=2)


@mcp.tool(
    name="get_page",
    description=(
        "Retrieve specific page(s) from a document by document ID. "
        "Use this for targeted retrieval — following cross-references, "
        "reading pages around a search hit, or browsing sequentially. "
        "Supports single pages and small ranges (up to 10 pages)."
    ),
)
def mcp_get_page(document_id: int, page: str) -> str:
    """Retrieve specific page(s) from a document.

    Args:
        document_id: Which document to read from.
        page: Page number (e.g. "47") or range (e.g. "45-50").

    Returns:
        JSON string with document_id, total_pages, and page content.
    """
    result = get_page(_get_cfg(), document_id, page)
    return json.dumps(result, indent=2)


def main() -> None:
    """Entry point for the ``techmanual-mcp`` console script (uvx / pip install)."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
