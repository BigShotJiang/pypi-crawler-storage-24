"""techmanual_client — search and retrieve technical documentation."""

from .api import get_page, list_documents, search
from .config import Config, load_config

__all__ = [
    "load_config",
    "Config",
    "search",
    "list_documents",
    "get_page",
]
