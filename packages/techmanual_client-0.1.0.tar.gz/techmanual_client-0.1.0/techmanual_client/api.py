"""techmanual.ai API client — thin wrapper over REST endpoints."""

from typing import Any, Dict, List, Optional, Union

import requests

from .config import Config


def _headers(cfg: Config) -> Dict[str, str]:
    """Return Authorization headers for the API.

    Args:
        cfg: Runtime configuration.

    Returns:
        Dict with Authorization Bearer header.
    """
    return {"Authorization": f"Bearer {cfg.api_key}"}


def search(
    cfg: Config,
    query: str,
    manufacturer: Optional[str] = None,
    model_number: Optional[str] = None,
    instrument_type: Optional[str] = None,
    document_id: Optional[int] = None,
    category: Optional[str] = None,
    limit: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """Search manual pages using hybrid search.

    Calls GET /v1/search with optional filters. All filters use
    case-insensitive substring matching on the server. ``model_number``
    is matched against applicable_models in the catalog.

    Args:
        cfg: Runtime configuration.
        query: Free-text search query.
        manufacturer: Filter by manufacturer (substring match).
        model_number: Filter by applicable model number (substring match).
        instrument_type: Filter by instrument type (substring match).
        document_id: Narrow results to a single document.
        category: Filter by equipment category (future — accepted but not
            sent to server until schema supports it).
        limit: Max results to return. Defaults to cfg.search_limit.

    Returns:
        List of enriched search result dicts with nested document and
        equipment metadata.

    Raises:
        requests.HTTPError: On non-2xx responses.
    """
    params: Dict[str, Any] = {
        "q": query,
        "limit": limit or cfg.search_limit,
    }
    if manufacturer:
        params["manufacturer"] = manufacturer
    if model_number:
        params["model_number"] = model_number
    if instrument_type:
        params["instrument_type"] = instrument_type
    if document_id is not None:
        params["document_id"] = document_id
    # category accepted but not sent until server supports it.

    resp = requests.get(
        f"{cfg.api_url}/v1/search",
        headers=_headers(cfg),
        params=params,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def list_documents(
    cfg: Config,
    query: Optional[str] = None,
    manufacturer: Optional[str] = None,
    model_number: Optional[str] = None,
    instrument_type: Optional[str] = None,
    category: Optional[str] = None,
    document_type: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """List available documents with metadata.

    Calls GET /v1/documents with optional filters. ``model_number`` is
    matched against the manual's applicable_models list.

    Args:
        cfg: Runtime configuration.
        query: Fuzzy match on document title/filename.
        manufacturer: Filter by manufacturer (substring match).
        model_number: Filter by applicable model number (substring match).
        instrument_type: Filter by instrument type (substring match).
        category: Filter by equipment category (future — not sent yet).
        document_type: Filter by document type (future — not sent yet).

    Returns:
        List of document metadata dicts.

    Raises:
        requests.HTTPError: On non-2xx responses.
    """
    params: Dict[str, Any] = {}
    if query:
        params["query"] = query
    if manufacturer:
        params["manufacturer"] = manufacturer
    if model_number:
        params["model_number"] = model_number
    if instrument_type:
        params["instrument_type"] = instrument_type
    # category and document_type accepted but not sent until server supports them.

    resp = requests.get(
        f"{cfg.api_url}/v1/documents",
        headers=_headers(cfg),
        params=params,
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()


def get_page(
    cfg: Config,
    document_id: int,
    page: Union[int, str] = 1,
) -> Dict[str, Any]:
    """Retrieve page(s) from a document by document ID.

    Calls GET /v1/documents/{document_id}/pages?page=N.

    Args:
        cfg: Runtime configuration.
        document_id: The document to retrieve pages from.
        page: Page number or range string (e.g. "5-10").

    Returns:
        Dict with document_id, total_pages, and pages list.

    Raises:
        requests.HTTPError: On non-2xx responses.
    """
    resp = requests.get(
        f"{cfg.api_url}/v1/documents/{document_id}/pages",
        headers=_headers(cfg),
        params={"page": str(page)},
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()

