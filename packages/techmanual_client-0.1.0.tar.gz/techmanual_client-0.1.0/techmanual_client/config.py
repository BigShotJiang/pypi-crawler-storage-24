"""Configuration loaded from environment variables."""

import os
from dataclasses import dataclass


@dataclass
class Config:
    """Runtime configuration for the techmanual client.

    Attributes:
        api_url: Base URL for the techmanual.ai API.
        api_key: Bearer token for the techmanual.ai API.
        search_limit: Number of pages to retrieve from search.
    """

    api_url: str
    api_key: str
    search_limit: int = 4


def load_config() -> Config:
    """Load configuration from environment variables.

    Reads TMAI_API_URL, TMAI_API_KEY, and TMAI_SEARCH_LIMIT from the
    environment.

    Returns:
        A populated Config dataclass.

    Raises:
        ValueError: If required env vars are not set.
    """
    api_url = os.environ.get("TMAI_API_URL", "http://localhost:8000")
    api_key = os.environ.get("TMAI_API_KEY", "")
    search_limit = int(os.environ.get("TMAI_SEARCH_LIMIT", "4"))

    if not api_key:
        raise ValueError("Required env var not set: TMAI_API_KEY")

    return Config(
        api_url=api_url.rstrip("/"),
        api_key=api_key,
        search_limit=search_limit,
    )
