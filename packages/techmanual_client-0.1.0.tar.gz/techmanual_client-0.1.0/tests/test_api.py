"""Unit tests for techmanual_client.api."""

from unittest.mock import MagicMock, patch

import pytest

from techmanual_client.api import get_page, list_documents, search
from techmanual_client.config import Config


def _cfg() -> Config:
    """Return a test Config with dummy values."""
    return Config(
        api_url="http://test:8000",
        api_key="tmai_testkey",
    )


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


class TestSearch:
    """Tests for search()."""

    @patch("techmanual_client.api.requests.get")
    def test_returns_list(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = [
            {
                "page_number": 1,
                "content": "text",
                "snippet": "snip",
                "rank": 0.5,
                "document": {"id": 1, "title": "Manual", "page_count": 10,
                             "estimated_tokens": 5000},
                "equipment": {"manufacturer": "R&S", "model_number": "FSW"},
            }
        ]
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        result = search(_cfg(), "center frequency")
        assert isinstance(result, list)
        assert len(result) == 1
        assert result[0]["page_number"] == 1

    @patch("techmanual_client.api.requests.get")
    def test_sends_only_required_params_when_no_filters(
        self, mock_get: MagicMock
    ) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        search(_cfg(), "query")

        params = mock_get.call_args.kwargs["params"]
        assert "q" in params
        assert "limit" in params
        assert "model_number" not in params
        assert "manufacturer" not in params
        assert "document_id" not in params

    @patch("techmanual_client.api.requests.get")
    def test_passes_optional_filters(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        search(
            _cfg(), "query",
            manufacturer="R&S",
            model_number="FSW",
            document_id=42,
        )

        params = mock_get.call_args.kwargs["params"]
        assert params["manufacturer"] == "R&S"
        assert params["model_number"] == "FSW"
        assert params["document_id"] == 42

    @patch("techmanual_client.api.requests.get")
    def test_sends_auth_header(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        cfg = _cfg()
        search(cfg, "query")

        headers = mock_get.call_args.kwargs["headers"]
        assert headers["Authorization"] == f"Bearer {cfg.api_key}"

    @patch("techmanual_client.api.requests.get")
    def test_raises_on_http_error(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.raise_for_status.side_effect = Exception("401 Unauthorized")
        mock_get.return_value = mock_resp

        with pytest.raises(Exception, match="401"):
            search(_cfg(), "query")

    @patch("techmanual_client.api.requests.get")
    def test_uses_config_search_limit(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        cfg = Config(api_url="http://test:8000", api_key="key", search_limit=15)
        search(cfg, "query")

        params = mock_get.call_args.kwargs["params"]
        assert params["limit"] == 15

    @patch("techmanual_client.api.requests.get")
    def test_explicit_limit_overrides_config(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        search(_cfg(), "query", limit=3)

        params = mock_get.call_args.kwargs["params"]
        assert params["limit"] == 3

    @patch("techmanual_client.api.requests.get")
    def test_category_not_sent_to_server(self, mock_get: MagicMock) -> None:
        """category param is accepted but not sent until server supports it."""
        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        search(_cfg(), "query", category="inverter")

        params = mock_get.call_args.kwargs["params"]
        assert "category" not in params


# ---------------------------------------------------------------------------
# list_documents
# ---------------------------------------------------------------------------


class TestListDocuments:
    """Tests for list_documents()."""

    @patch("techmanual_client.api.requests.get")
    def test_returns_list(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = [
            {"document_id": 1, "title": "FSW Manual", "manufacturer": "R&S",
             "model_number": "FSW", "page_count": 100, "estimated_token_count": 50000}
        ]
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        result = list_documents(_cfg())
        assert len(result) == 1
        assert result[0]["document_id"] == 1

    @patch("techmanual_client.api.requests.get")
    def test_no_params_when_unfiltered(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        list_documents(_cfg())

        params = mock_get.call_args.kwargs["params"]
        assert params == {}

    @patch("techmanual_client.api.requests.get")
    def test_passes_query_and_filters(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        list_documents(
            _cfg(),
            query="installation",
            manufacturer="SMA",
            model_number="SB-5.0",
        )

        params = mock_get.call_args.kwargs["params"]
        assert params["query"] == "installation"
        assert params["manufacturer"] == "SMA"
        assert params["model_number"] == "SB-5.0"

    @patch("techmanual_client.api.requests.get")
    def test_calls_documents_endpoint(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        list_documents(_cfg())

        url = mock_get.call_args.args[0]
        assert url == "http://test:8000/v1/documents"


# ---------------------------------------------------------------------------
# get_page
# ---------------------------------------------------------------------------


class TestGetPage:
    """Tests for get_page()."""

    @patch("techmanual_client.api.requests.get")
    def test_returns_dict(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "document_id": 1, "total_pages": 100,
            "pages": [{"page_number": 5, "content": "text", "manual_id": 1}],
        }
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        result = get_page(_cfg(), document_id=1, page=5)
        assert result["document_id"] == 1
        assert len(result["pages"]) == 1

    @patch("techmanual_client.api.requests.get")
    def test_constructs_correct_url(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"document_id": 42, "total_pages": 10, "pages": []}
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        get_page(_cfg(), document_id=42, page="5-10")

        url = mock_get.call_args.args[0]
        assert url == "http://test:8000/v1/documents/42/pages"
        assert mock_get.call_args.kwargs["params"]["page"] == "5-10"

    @patch("techmanual_client.api.requests.get")
    def test_sends_auth_header(self, mock_get: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"document_id": 1, "total_pages": 1, "pages": []}
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        cfg = _cfg()
        get_page(cfg, document_id=1, page=1)

        headers = mock_get.call_args.kwargs["headers"]
        assert headers["Authorization"] == f"Bearer {cfg.api_key}"

