"""Unit tests for the MCP server tool functions.

Patches the underlying techmanual_client API functions and verifies that
each MCP tool serializes results correctly and passes parameters through.

The mcp_server module calls load_config() at import time, so we set the
required env var before importing.
"""

import json
import os
from unittest.mock import patch

# mcp_server.py calls load_config() at module scope, which requires
# TMAI_API_KEY. Set a dummy value before importing.
os.environ.setdefault("TMAI_API_KEY", "tmai_test_dummy_key")

from mcp_server import mcp_search, mcp_list_manuals, mcp_get_page


class TestMcpSearch:
    """Tests for the search MCP tool."""

    @patch("mcp_server.search")
    def test_returns_valid_json(self, mock_search):
        """search tool returns a JSON-serializable string."""
        canned = [{"page_number": 1, "content": "test", "rank": 0.5}]
        mock_search.return_value = canned

        result = mcp_search("center frequency")
        parsed = json.loads(result)

        assert parsed == canned

    @patch("mcp_server.search")
    def test_passes_optional_filters(self, mock_search):
        """search tool forwards optional filter parameters."""
        mock_search.return_value = []

        mcp_search(
            "query",
            manufacturer="R&S",
            model_number="FSW",
            instrument_type="Spectrum Analyzer",
            document_id=42,
            category="spectrum_analyzer",
        )

        mock_search.assert_called_once()
        kwargs = mock_search.call_args.kwargs
        assert kwargs["manufacturer"] == "R&S"
        assert kwargs["model_number"] == "FSW"
        assert kwargs["instrument_type"] == "Spectrum Analyzer"
        assert kwargs["document_id"] == 42
        assert kwargs["category"] == "spectrum_analyzer"


class TestMcpListManuals:
    """Tests for the list_manuals MCP tool."""

    @patch("mcp_server.list_documents")
    def test_returns_valid_json(self, mock_list):
        """list_manuals tool returns a JSON-serializable string."""
        canned = [{"document_id": 1, "title": "Manual", "page_count": 50}]
        mock_list.return_value = canned

        result = mcp_list_manuals()
        parsed = json.loads(result)

        assert parsed == canned

    @patch("mcp_server.list_documents")
    def test_passes_filters(self, mock_list):
        """list_manuals tool forwards filter parameters."""
        mock_list.return_value = []

        mcp_list_manuals(
            query="installation",
            manufacturer="Keysight",
            model_number="N9010B",
            instrument_type="Signal Analyzer",
        )

        kwargs = mock_list.call_args.kwargs
        assert kwargs["query"] == "installation"
        assert kwargs["manufacturer"] == "Keysight"
        assert kwargs["model_number"] == "N9010B"
        assert kwargs["instrument_type"] == "Signal Analyzer"


class TestMcpGetPage:
    """Tests for the get_page MCP tool."""

    @patch("mcp_server.get_page")
    def test_returns_valid_json(self, mock_get_page):
        """get_page tool returns a JSON-serializable string."""
        canned = {"document_id": 1, "total_pages": 100, "pages": []}
        mock_get_page.return_value = canned

        result = mcp_get_page(document_id=1, page="5")
        parsed = json.loads(result)

        assert parsed == canned

    @patch("mcp_server.get_page")
    def test_passes_page_range(self, mock_get_page):
        """get_page tool passes range strings through."""
        mock_get_page.return_value = {"document_id": 1, "total_pages": 10, "pages": []}

        mcp_get_page(document_id=1, page="5-10")

        # get_page is called positionally: get_page(_cfg, document_id, page)
        call_args = mock_get_page.call_args
        positional = call_args[0]
        assert positional[2] == "5-10"

