# techmanual-client

API client, CLI, and MCP server for [techmanual.ai](https://techmanual.ai) — the technical manual index for AI agents.

Search and retrieve hardware documentation (oscilloscopes, spectrum analyzers, power supplies, DMMs, etc.) without the PDF babysitting.

## Install

```bash
pip install techmanual-client
```

## Quick Start

### 1. Get an API key

Visit [techmanual.ai/setup](https://techmanual.ai/setup) to generate a free, read-only API key instantly (no account required).

### 2. Set environment variables

```bash
export TMAI_API_URL="https://api.techmanual.ai"
export TMAI_API_KEY="tmai_..."
```

### 3. Use with Claude Code (MCP)

Add to your `~/.claude.json`:

```json
{
  "mcpServers": {
    "techmanual": {
      "command": "techmanual-mcp",
      "env": {
        "TMAI_API_URL": "https://api.techmanual.ai",
        "TMAI_API_KEY": "tmai_..."
      }
    }
  }
}
```

### 4. Use the CLI

```bash
techmanual search "phase noise measurement" --model-number N9040B
techmanual list-manuals --manufacturer "Rohde & Schwarz"
techmanual get-page --document-id 42 --page 15
```

### 5. Use as a Python library

```python
from techmanual_client import load_config, search

cfg = load_config()
results = search(cfg, query="bandwidth measurement", manufacturer="Keysight")
```

## Tools

| Tool | Description |
|---|---|
| `search` | Hybrid FTS + vector search across all manuals. Filters: manufacturer, model_number, instrument_type, document_id. |
| `list_manuals` | Browse and filter the manual catalog. |
| `get_page` | Retrieve specific page(s) from a document by ID. |

## Links

- [techmanual.ai](https://techmanual.ai)
- [Setup guide](https://techmanual.ai/setup)
- [Upload a manual](https://techmanual.ai/upload)
