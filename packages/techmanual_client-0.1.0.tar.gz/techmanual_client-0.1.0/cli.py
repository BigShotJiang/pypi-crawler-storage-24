"""CLI entrypoint for techmanual — technical documentation search and retrieval.

Subcommands:
    search       — Search all documentation and display matching pages/snippets.
    list-manuals — Browse and filter the manual catalog.
    get-page     — Retrieve specific page(s) from a document by ID.
"""

import sys

import click

from techmanual_client import (
    get_page,
    list_documents,
    load_config,
    search,
)


@click.group()
def cli() -> None:
    """techmanual — search and retrieve technical documentation."""


# ---- search ---------------------------------------------------------------


@cli.command()
@click.option("--query", "-q", required=True, help="Free-text search query.")
@click.option("--model", default=None, help="Filter by applicable model number (substring).")
@click.option("--instrument-type", default=None, help="Filter by instrument type (substring).")
@click.option("--manufacturer", default=None, help="Filter by manufacturer (substring).")
@click.option("--document-id", default=None, type=int, help="Narrow to a single document.")
@click.option("--limit", default=None, type=int, help="Max results (default: 8).")
@click.option(
    "--full", is_flag=True, default=False,
    help="Print full page content instead of snippets.",
)
def search_cmd(
    query: str,
    model: str,
    instrument_type: str,
    manufacturer: str,
    document_id: int,
    limit: int,
    full: bool,
) -> None:
    """Search all documentation for relevant manual pages."""
    try:
        cfg = load_config()
    except ValueError as exc:
        click.echo(f"Configuration error: {exc}", err=True)
        sys.exit(1)

    click.echo(f"Query: {query}", err=True)

    results = search(
        cfg, query,
        manufacturer=manufacturer,
        model_number=model,
        instrument_type=instrument_type,
        document_id=document_id,
        limit=limit,
    )
    if not results:
        click.echo("No results found.", err=True)
        sys.exit(1)

    click.echo(f"\n{len(results)} results:\n", err=True)
    for r in results:
        doc = r.get("document", {})
        equip = r.get("equipment", {})
        models_str = ", ".join(equip.get("applicable_models", [])) or "?"
        header = (
            f"--- Page {r['page_number']}  "
            f"[{equip.get('manufacturer', '?')} | {equip.get('instrument_type', '?')} | {models_str}] "
            f"doc={doc.get('document_id', '?')}  (rank: {r.get('rank', 'n/a')}) ---"
        )
        click.echo(header)
        if full:
            click.echo(r.get("content", ""))
        else:
            click.echo(r.get("snippet", "(no snippet)"))
        click.echo()


# ---- list-manuals ---------------------------------------------------------


@cli.command("list-manuals")
@click.option("--query", "-q", default=None, help="Fuzzy match on title/metadata.")
@click.option("--model", default=None, help="Filter by applicable model number (substring).")
@click.option("--instrument-type", default=None, help="Filter by instrument type (substring).")
@click.option("--manufacturer", default=None, help="Filter by manufacturer (substring).")
@click.option("--document-type", default=None, help="Filter by document type (future).")
def list_manuals_cmd(
    query: str, model: str, instrument_type: str, manufacturer: str, document_type: str
) -> None:
    """Browse and filter the manual catalog."""
    try:
        cfg = load_config()
    except ValueError as exc:
        click.echo(f"Configuration error: {exc}", err=True)
        sys.exit(1)

    results = list_documents(
        cfg,
        query=query,
        manufacturer=manufacturer,
        model_number=model,
        instrument_type=instrument_type,
        document_type=document_type,
    )
    if not results:
        click.echo("No documents found.", err=True)
        sys.exit(1)

    click.echo(f"{len(results)} document(s):\n", err=True)
    for doc in results:
        models_str = ", ".join(doc.get("applicable_models", [])) or "—"
        click.echo(
            f"  [{doc['document_id']}] {doc['title']}  "
            f"({doc.get('manufacturer', '?')} | {doc.get('instrument_type', '?')} | {models_str})  "
            f"{doc['page_count']} pages  ~{doc['estimated_token_count']} tokens"
        )


# ---- get-page -------------------------------------------------------------


@cli.command("get-page")
@click.option("--document-id", required=True, type=int, help="Document ID.")
@click.option("--page", required=True, help='Page number or range (e.g. "5" or "5-10").')
def get_page_cmd(document_id: int, page: str) -> None:
    """Retrieve specific page(s) from a document."""
    try:
        cfg = load_config()
    except ValueError as exc:
        click.echo(f"Configuration error: {exc}", err=True)
        sys.exit(1)

    result = get_page(cfg, document_id, page)

    pages = result.get("pages", [])
    click.echo(
        f"Document {document_id} — {result.get('total_pages', '?')} total pages\n",
        err=True,
    )
    for p in pages:
        click.echo(f"--- Page {p['page_number']} ---")
        click.echo(p.get("content", ""))
        click.echo()


if __name__ == "__main__":
    cli()
