# Examples

## Healthcheck

Simple connectivity test — verify that `AllegoClient` can reach the server.

```python
--8<-- "tutorials/healthcheck_example.py"
```

## Stream State

Monitor and control the streaming state with `AllegoClient`.

```python
--8<-- "tutorials/stream_state_example.py"
```

## Record State

Manage recordings — start, stop, and query recording state.

```python
--8<-- "tutorials/record_state_example.py"
```

## Stimulation Steps

Run a stimulation sequence (restart example).

```python
--8<-- "tutorials/restart_example.py"
```

## Data Curation

Convert and manage recorded data with `CurateClient`.

```python
--8<-- "tutorials/curate_example.py"
```

## Running Examples Locally

Copy any example above into a `.py` file and run it after installing `radiens-core`:

```bash
pip install radiens-core
python healthcheck_example.py
```
