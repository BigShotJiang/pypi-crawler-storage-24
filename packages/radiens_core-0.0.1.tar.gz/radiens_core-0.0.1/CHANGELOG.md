# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- `CurateClient.set_protocol()` for registering arbitrary multi-step transform graphs (DAGs) with the server.
- `TransformNode` domain model with factory class methods (`highpass`, `lowpass`, `bandpass`, `bandstop`, `notch`, `car`, `virtual_ref`, `paired_ref`, `slice_time`, `slice_channels`, `downsample`, `source`, `sink`, `bulk_source`, `bulk_sink`) for constructing protocol graph nodes.
- `TransformEdge` domain model for wiring nodes together by ID.
- `TransformNodeType` enum for all supported transform node types.
- Transform parameter models: `HighLowPassParams`, `BandParams`, `NotchParams`, `CARParams`, `VirtualRefParams`, `PairedRefParams`, `SliceTimeParams`, `SliceChannelsParams`, `DownsampleParams`, `SourceParams`, `SinkParams`, `BulkSourceParams`, `BulkSinkParams`.

## [0.0.0b9] - 2026-03-23

### Added

- `AllegoClient.get_dsp_group()` and `AllegoClient.set_dsp_group()` for real-time filter configuration.
- `VidereClient.get_dsp_group()` and `VidereClient.set_dsp_group()` for offline filter configuration.
- `VidereClient.list_data_sources()`, `VidereClient.list_data_source_ids()`, `VidereClient.clear_data_sources()`, and `VidereClient.export_data_source()` for data source management.
- `DSPGroup`, `DSPParams`, `DSPType`, and `FilterStage` domain models.
- `AllegoClient.get_intan_impedance()` for measuring channel impedance across specified hardware ports.
- `AllegoClient.scan_ports()` for real-time hardware discovery and updating channel metadata.
- `Impedance` and `ImpedanceValue` domain models for impedance measurement data.
- `AllegoClient.get_dac_reg()`, `AllegoClient.set_dac_gain()`, `AllegoClient.set_dac_stream()`, `AllegoClient.set_dac_off()`, and `AllegoClient.set_dac_highpass()` for hardware DAC control.
- `AllegoClient.get_dio_reg()`, `AllegoClient.set_dio_events()`, `AllegoClient.set_dio_manual()`, `AllegoClient.set_dio_gated()`, and `AllegoClient.set_dio_pulse()` for hardware Digital Output (DIO) control.
- `AnalogOutRegister`, `AnalogOutChannel`, and `DACHighPass` domain models for DAC configuration.
- `DigitalOutRegister`, `DigitalOutChannelRegister`, and `DIOMode` domain models for DIO configuration.
- `AllegoClient.get_core_config()` and `AllegoClient.set_core_config()` for reading and updating global hardware settings (sampling frequency, loop duration, cable delays).
- `CoreConfig`, `CableDelay`, and `SetCoreConfigRequest` domain models.
- `CurateClient` filtering transforms: `highpass()`, `lowpass()`, `bandpass()`, `bandstop()`, and `notch()`.
- `CurateClient.slice_channels()` for extracting a subset of channels to a new file.
- `CurateClient.car()` for Common Average Reference re-referencing.
- `CurateClient.virtual_ref()` for single-channel virtual referencing.
- `CurateClient.paired_ref()` for paired single-channel re-referencing.
- `AllegoClient.get_kpi_metrics()`, `get_kpi_status()`, `set_kpi_packet_dur()`, and `set_kpi_update_period()` for real-time KPI signal metrics.
- `VidereClient.get_kpi_metrics()`, `get_kpi_status()`, `kpi_calculate()`, `kpi_clear()`, and `set_kpi_packet_dur()` for offline KPI signal metrics.
- `KpiMetric`, `KpiMetricId`, `KpiMetricsResult`, `KpiMode`, and `KpiStatus` domain models.

## [0.0.0b8] - 2026-03-19

### Added

- `headstage_global_amp_settle` parameter to `StimParams` model for headstage-level amplifier settle control.

### Changed

- Refactored `CurateClient` initialization and internal protocol execution logic (added progress bars for curation tasks).
- Improved documentation structure and configuration for the MkDocs site.

## [0.0.0b7] - 2026-03-19

### Added

- MkDocs documentation site with `mkdocstrings` API reference, GitHub Actions workflow for build and deployment.

### Fixed

- Site positions now converted from proto units to microns in the domain model.

## [0.0.0b6] - 2026-03-18

### Added

- `BaseClient` class for shared gRPC service logic; `AllegoClient`, `CurateClient`, and `VidereClient` now inherit from it.
- `CurateClient.slice_time()` and `CurateClient.downsample()` methods.
- `CurateClient.link_data_file()` with support for `Path` objects and protocol execution progress bar.

### Fixed

- `MAX_PB_MSG_SIZE_BYTES` set to unlimited; channel options type corrected.

## [0.0.0b5] - 2026-03-18

### Added

- `AllegoClient.get_signals()` and `VidereClient.get_signals()` for signal data retrieval.
- `FlexTimeRange` and `FlexSignalSpec` type aliases with Pydantic runtime coercion support.

### Changed

- Flat client API: all methods directly on client classes, no sub-clients.
- Auto-discovery of server UUID via `_try_server_uuid`.
- Time range and signal specification refactored to use `FlexTimeRange` / `FlexSignalSpec`.
- PyPI publishing automated via GitHub Actions; pre-push validation hook added.

## [0.0.0b4] - 2026-03-16

### Changed

- Restructured package layout and public exports (`refactor: file structure and exports`).
- Version now managed via `importlib.metadata`; removed `_version.py`.

## [0.0.0b3] - 2026-03-05

### Added

- Recording configuration management: models, converters, and `AllegoClient` service methods.

## [0.0.0b2] - 2026-03-05

### Added

- Channel metadata retrieval (`AllegoClient.get_channel_metadata()`).
- Stimulation parameter models and converters, including `StimParams`, enums, and proto integration.
- Stim keypress trigger control and stimulation step support.
- Stimulation parameter hypercube generator with safety tests.

## [0.0.0b1] - 2026-02-20

### Added

- Initial beta release.
- `AllegoClient` with: `healthcheck`, `get_status`, `set_stream_state`, `set_record_state`, `restart`, `set_stim_params`, `set_trigger_control`.
- Zero-config authentication via `AuthInterceptor`.
- Core domain models: status, stream state, record state, stimulation parameters.
- Strict mypy typing, Pydantic v2 models, gRPC transport layer.
- Proto-driven type safety architecture with `_converters/` / `_services/` layer separation.
