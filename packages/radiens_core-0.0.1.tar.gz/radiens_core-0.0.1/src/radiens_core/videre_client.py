"""VidereClient — offline file-based analysis client."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, ClassVar, cast

from pydantic import ConfigDict, validate_call

from radiens_core._base_file_client import BaseFileClient
from radiens_core._converters._dsp import (
    domain_to_proto_dsp_params,
    proto_to_domain_dsp_group,
)
from radiens_core._converters._kpi import (
    build_bundle_req,
    kpi_metrics_result_from_proto,
    kpi_status_from_proto,
)
from radiens_core._converters._signals import sig_select_to_proto, signal_arrays_from_signals2
from radiens_core._converters._time_range import time_range_to_proto, trs_mode_to_proto
from radiens_core._converters._validation import validate_proto
from radiens_core._generated import common_pb2
from radiens_core._services._radiens_core import (
    get_dsp_group_proto,
    get_hd_snapshot_py_proto,
    get_kpi_status_radiens_proto,
    kpi_calculate_proto,
    kpi_clear_proto,
    kpi_get_metrics_radiens_proto,
    set_dsp_group_proto,
    set_kpi_packet_dur_radiens_proto,
)
from radiens_core._typing_helpers import validated
from radiens_core.exceptions import RadiensError
from radiens_core.models.common import ClientType, ServiceEndpoint
from radiens_core.models.dataset import DatasetMetadata, FlexTimeRange, TimeRangeSpec
from radiens_core.models.kpi import KpiMetricId, KpiMetricsResult, KpiStatus
from radiens_core.models.signals import FlexSignalSpec, SignalArrays, SignalSpec, SignalType

if TYPE_CHECKING:
    from radiens_core.models.dsp import DSPGroup, DSPParams, FilterStage
    from radiens_core.models.types import DatasetRef


class VidereClient(BaseFileClient):
    """Client for offline file-based analysis.

    Auto-discovers a running ``radiensserver`` on the local machine.

    Usage::

        with VidereClient() as client:
            meta = client.link_data_file("/path/to/recording.xdat")
            sigs = client.get_signals(meta, time_range=[0, 1], signals=[0, 1, 2])
    """

    _client_type: ClassVar[ClientType] = ClientType.VIDERE

    # --- Public API ---

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_signals(
        self,
        dataset: str | Path | DatasetMetadata,
        time_range: FlexTimeRange,
        signals: FlexSignalSpec,
    ) -> SignalArrays:
        """Retrieve signal data for a specific time range and channel selection.

        Args:
        dataset
            Dataset to query (metadata object or ID).
        time_range
            Time range specification (e.g., [start, end] in seconds).
        signals
            Signal selection (e.g., list of amplifier channel indices).

        Returns:
        SignalArrays
            The requested signal data as numpy arrays.
        """

        meta = self._resolve_dataset(dataset)

        tr_spec = validated(time_range, TimeRangeSpec)
        sig_spec = validated(signals, SignalSpec)

        # Resolve specs into concrete domain models
        concrete_tr = tr_spec.resolve(dataset_metadata=meta)
        if concrete_tr is None:
            # FROM_HEAD (lookback) mode is not meaningful for offline files
            raise ValueError(
                f"lookback() time range is not supported for offline files; "
                f"use TimeRangeSpec.subset(start, end) or TimeRangeSpec.full() instead. Got: {time_range}"
            )

        sig_select = sig_spec.to_sig_select(meta.channel_metadata)

        # Build proto request
        req = common_pb2.HDSnapshotRequest2(
            dsourceID=meta.id,
            tR=time_range_to_proto(concrete_tr),
            selMode=trs_mode_to_proto(tr_spec.mode),
            sigSel=sig_select_to_proto(sig_select),
        )
        validate_proto(req)

        # Execute RPC
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = get_hd_snapshot_py_proto(self._pool, addr, req)

        return signal_arrays_from_signals2(response.sigs)

    def get_dsp_group(self, dataset: DatasetRef) -> DSPGroup:
        """Get DSP filter configuration for a dataset.

        Args:
        dataset
            Dataset to query (metadata object or ID).

        Returns:
        DSPGroup
            The current hardware and software filter parameters.
        """
        meta = self._resolve_dataset(dataset)
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = get_dsp_group_proto(self._pool, addr, meta.id)
        return proto_to_domain_dsp_group(response)

    def set_dsp_group(
        self,
        dataset: DatasetRef,
        stage: FilterStage,
        params: list[DSPParams],
    ) -> None:
        """Update DSP filter configuration for a specific dataset and stage.

        Args:
        dataset
            Dataset to update (metadata object or ID).
        stage
            The filter stage to update (e.g. STAGE1, STAGE2).
        params
            List of filter parameters for this stage.
        """
        meta = self._resolve_dataset(dataset)
        req = common_pb2.SetDSPGroupRequest(
            streamGroupId=meta.id,
            stage=cast("common_pb2.FilterStage.ValueType", stage.value),
            dspParams=[domain_to_proto_dsp_params(p) for p in params],
        )
        validate_proto(req)

        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        set_dsp_group_proto(self._pool, addr, req)

    # ===================================================================
    # KPI Metrics
    # ===================================================================

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_kpi_metrics(
        self,
        dataset: str | Path | DatasetMetadata,
        metrics: list[KpiMetricId],
        channel_indices: list[int],
        time_range: FlexTimeRange,
        signal_type: SignalType = SignalType.AMP,
    ) -> KpiMetricsResult:
        """Retrieve computed KPI signal metrics for a linked dataset.

        Args:
        dataset
            Dataset to query (metadata object, ID string, or file path).
        metrics
            List of KPI metric identifiers to retrieve.
        channel_indices
            Native channel indices (ntvIdxs) to query.
        time_range
            Time range within the dataset (e.g. ``[start, end]`` in seconds).
            Lookback mode is not supported for offline files.
        signal_type
            Signal type to query (default ``AMP``).

        Returns:
        KpiMetricsResult
            Metric values as a ``(n_channels, n_metrics)`` numpy array
            with row/column labels.

        Raises:
        ValueError
            If lookback time range mode is used (not supported offline).
        RadiensError
            On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        tr_spec = validated(time_range, TimeRangeSpec)
        concrete_tr = tr_spec.resolve(dataset_metadata=meta)
        if concrete_tr is None:
            raise ValueError(
                "lookback() time range is not supported for offline files; "
                f"use TimeRangeSpec.subset(start, end) or TimeRangeSpec.full() instead. Got: {time_range}"
            )
        req = common_pb2.KpiMetricsReq(
            streamGroupId=meta.id,
            stype=cast("common_pb2.SignalType.ValueType", signal_type.value),
            arg=build_bundle_req(channel_indices, list(concrete_tr.sec), metrics),
        )
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = kpi_get_metrics_radiens_proto(self._pool, addr, req)
        return kpi_metrics_result_from_proto(response)

    def get_kpi_status(self, dataset: DatasetRef) -> KpiStatus:
        """Get the current KPI cache status for a dataset.

        Args:
        dataset
            Dataset to query (metadata object, ID string, or file path).

        Returns:
        KpiStatus
            Number of packets in cache, packet duration, memory usage,
            and availability state.
        """
        meta = self._resolve_dataset(dataset)
        req = common_pb2.GetKpiStatusRequest(streamGroupId=meta.id)
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = get_kpi_status_radiens_proto(self._pool, addr, req)
        return kpi_status_from_proto(response)

    def kpi_calculate(self, dataset: DatasetRef) -> None:
        """Trigger KPI computation for a linked dataset.

        Must be called before ``get_kpi_metrics`` returns useful data
        on a freshly linked file.

        Args:
        dataset
            Dataset to compute KPIs for (metadata object, ID string, or file path).

        Raises:
        RadiensError
            On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        req = common_pb2.KpiStandardRequest(dsourceID=[meta.id])
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = kpi_calculate_proto(self._pool, addr, req)
        if response.errMsg:
            raise RadiensError(f"KPI calculate failed: {response.errMsg}")

    def kpi_clear(self, dataset: DatasetRef) -> None:
        """Clear the KPI cache for a dataset.

        Resets accumulated KPI state. Useful before rerunning with
        changed parameters.

        Args:
        dataset
            Dataset to clear KPI state for (metadata object, ID string, or file path).

        Raises:
        RadiensError
            On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        req = common_pb2.KpiStandardRequest(dsourceID=[meta.id])
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = kpi_clear_proto(self._pool, addr, req)
        if response.errMsg:
            raise RadiensError(f"KPI clear failed: {response.errMsg}")

    def set_kpi_packet_dur(self, dataset: DatasetRef, packet_dur: float) -> None:
        """Set the KPI packet duration (integration window) for a dataset.

        Args:
        dataset
            Dataset to configure (metadata object, ID string, or file path).
        packet_dur
            Duration of each KPI packet in seconds.

        Raises:
        RadiensError
            On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        req = common_pb2.SetKpiParamRequest(streamGroupId=meta.id, param=packet_dur)
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = set_kpi_packet_dur_radiens_proto(self._pool, addr, req)
        if response.errMsg:
            raise RadiensError(f"Failed to set KPI packet duration: {response.errMsg}")
