"""Radiens Python client for neuroscience data acquisition and analysis."""

from importlib.metadata import version

__version__ = version("radiens-core")

from radiens_core.allego_client import AllegoClient
from radiens_core.curate_client import CurateClient
from radiens_core.models.common import ServiceEndpoint
from radiens_core.models.core_config import CableDelay, CoreConfig, SetCoreConfigRequest
from radiens_core.models.dataset import (
    BandParams,
    BulkSinkParams,
    BulkSourceParams,
    CARParams,
    DownsampleParams,
    FileInfo,
    HighLowPassParams,
    NotchParams,
    PairedRefParams,
    ProtocolSpec,
    SinkParams,
    SliceChannelsParams,
    SliceTimeParams,
    SourceParams,
    TransformEdge,
    TransformNode,
    TransformNodeType,
    VirtualRefParams,
)
from radiens_core.models.kpi import KpiMetric, KpiMetricId, KpiMetricsResult, KpiMode, KpiStatus
from radiens_core.videre_client import VidereClient

__all__ = [
    "AllegoClient",
    "BandParams",
    "BulkSinkParams",
    "BulkSourceParams",
    "CARParams",
    "CableDelay",
    "CoreConfig",
    "CurateClient",
    "DownsampleParams",
    "FileInfo",
    "HighLowPassParams",
    "KpiMetric",
    "KpiMetricId",
    "KpiMetricsResult",
    "KpiMode",
    "KpiStatus",
    "NotchParams",
    "PairedRefParams",
    "ProtocolSpec",
    "ServiceEndpoint",
    "SetCoreConfigRequest",
    "SinkParams",
    "SliceChannelsParams",
    "SliceTimeParams",
    "SourceParams",
    "TransformEdge",
    "TransformNode",
    "TransformNodeType",
    "VidereClient",
    "VirtualRefParams",
    "__version__",
]
