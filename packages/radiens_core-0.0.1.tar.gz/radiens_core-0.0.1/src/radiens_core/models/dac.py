"""DAC (Analog Output) domain models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class DACHighPass(BaseModel):
    """DAC high-pass filter configuration.

    Attributes:
        enable: Whether the high-pass filter is enabled.
        cutoff_freq: High-pass filter cutoff frequency in Hertz.
    """

    model_config = ConfigDict(frozen=True)

    enable: bool
    cutoff_freq: float


class AnalogOutChannel(BaseModel):
    """Configuration for a single analog output channel.

    Attributes:
        pri_ntv_chan_idx: Primary native channel index.
        analog_out_ntv_chan_idx: Analog output native channel index.
        stream: Stream identifier.
        stream_offset_idx: Index offset within the stream.
    """

    model_config = ConfigDict(frozen=True)

    pri_ntv_chan_idx: int
    analog_out_ntv_chan_idx: int
    stream: int
    stream_offset_idx: int


class AnalogOutRegister(BaseModel):
    """Complete DAC (Analog Output) register state.

    Attributes:
        gain: DAC gain setting.
        highpass_reg: High-pass filter configuration. References DACHighPass.
        channels: List of individual analog output channel configurations. References AnalogOutChannel.
    """

    model_config = ConfigDict(frozen=True)

    gain: int
    highpass_reg: DACHighPass
    channels: list[AnalogOutChannel]
