"""Converters for core hardware configuration models."""

from radiens_core._converters._common_enums import (
    backbone_mode_from_proto,
    port_to_proto,
)
from radiens_core._generated import allegoserver_pb2
from radiens_core.models.core_config import CableDelay, CoreConfig, SetCoreConfigRequest
from radiens_core.models.ports import Port


def core_config_from_proto(proto: allegoserver_pb2.ConfigCore) -> CoreConfig:
    """Convert ConfigCore proto to domain model."""
    cable_delays = {}
    for key, val in proto.cableDelays.cableDelays.items():
        cable_delays[key] = CableDelay(
            port=Port(val.port),
            cable_delay=val.cableDelay,
            is_auto=val.isAuto,
        )

    return CoreConfig(
        allego_core_server_port=proto.allegoCoreServerPort,
        base_samp_freq=proto.baseSampFreq,
        stream_loop_dur_ms=proto.streamLoopDurMs,
        backbone_mode=backbone_mode_from_proto(proto.backboneMode),
        has_xdaq_gpio_expander=proto.hasXDAQGPIOExpander,
        cable_delays=cable_delays,
    )


def set_core_config_to_proto(
    req: SetCoreConfigRequest,
) -> allegoserver_pb2.SetConfigCoreRequest:
    """Convert SetCoreConfigRequest domain model to proto."""
    proto = allegoserver_pb2.SetConfigCoreRequest()

    if req.samp_freq is not None:
        proto.sampFreq = req.samp_freq
    if req.loop_dur is not None:
        proto.loopDur = req.loop_dur
    if req.pcache_persistence is not None:
        proto.pcachePersistence = req.pcache_persistence
    if req.cable_delay is not None:
        proto.cableDelay.port = port_to_proto(req.cable_delay.port)
        proto.cableDelay.cableDelay = req.cable_delay.cable_delay
        proto.cableDelay.isAuto = req.cable_delay.is_auto

    return proto
