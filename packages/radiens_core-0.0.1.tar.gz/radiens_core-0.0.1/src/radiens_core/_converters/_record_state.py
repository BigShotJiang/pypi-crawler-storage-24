"""Record state converters — domain models <-> proto messages."""

from __future__ import annotations

from typing import TYPE_CHECKING

from radiens_core._converters._common_enums import (
    port_to_proto,
    record_mode_to_proto,
)
from radiens_core._generated import allegoserver_pb2

if TYPE_CHECKING:
    from radiens_core.models.status import RecordStateRequest


def record_state_request_to_proto(
    request: RecordStateRequest,
) -> allegoserver_pb2.SetRecordRequest:
    """Convert domain RecordStateRequest to proto SetRecordRequest."""
    proto_request = allegoserver_pb2.SetRecordRequest(
        mode=record_mode_to_proto(request.mode),
    )

    # Add port if specified (for per-port recording control)
    if request.port is not None:
        proto_request.port = port_to_proto(request.port)

    return proto_request
