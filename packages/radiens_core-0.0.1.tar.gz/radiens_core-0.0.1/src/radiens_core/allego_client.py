"""AllegoClient — real-time data acquisition client."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, cast

from pydantic import ConfigDict, validate_call

from radiens_core._base_client import BaseClient
from radiens_core._constants import (
    ALLEGO_SERVICE_DEFAULTS,
    PRIMARY_CACHE_STREAM_GROUP_ID,
)
from radiens_core._converters import validate_proto
from radiens_core._converters._channels import channel_metadata_from_proto
from radiens_core._converters._core_config import core_config_from_proto, set_core_config_to_proto
from radiens_core._converters._dac import (
    analog_out_register_from_proto,
    dac_highpass_to_proto,
    set_dac_gain_to_proto,
    set_dac_off_to_proto,
    set_dac_stream_to_proto,
)
from radiens_core._converters._dio import (
    digital_out_register_from_proto,
    set_dio_events_to_proto,
    set_dio_gated_to_proto,
    set_dio_manual_to_proto,
    set_dio_pulse_to_proto,
)
from radiens_core._converters._dsp import (
    domain_to_proto_dsp_params,
    proto_to_domain_dsp_group,
)
from radiens_core._converters._impedance import impedance_from_proto, impedance_request_to_proto
from radiens_core._converters._kpi import (
    build_bundle_req,
    kpi_metrics_result_from_proto,
    kpi_status_from_proto,
)
from radiens_core._converters._record_state import record_state_request_to_proto
from radiens_core._converters._recording_config import recording_config_from_proto, recording_config_to_proto
from radiens_core._converters._restart import restart_request_to_proto
from radiens_core._converters._signals import signal_arrays_from_hd_snapshot
from radiens_core._converters._status import backbone_status_from_proto
from radiens_core._converters._stim import stim_params_from_proto, stim_params_to_proto
from radiens_core._converters._stim_step import stim_step_request_to_proto, stim_step_state_from_proto
from radiens_core._converters._stream_state import stream_state_request_to_proto
from radiens_core._converters._trigger_control import (
    manual_stim_trigger_request_to_proto,
    manual_stim_trigger_toggle_request_to_proto,
    set_trigger_state_request_to_proto,
    trigger_state_from_proto,
)
from radiens_core._generated import common_pb2
from radiens_core._services._allego_core import (
    get_config_proto,
    get_dac_reg_proto,
    get_dio_reg_proto,
    get_dsp_group_proto,
    get_intan_impedance_proto,
    get_recording_config_proto,
    get_signal_group_proto,
    get_status_proto,
    get_stim_params_proto,
    get_stim_step_proto,
    get_trigger_state_proto,
    healthcheck_proto,
    manual_stim_trigger_proto,
    manual_stim_trigger_toggle_proto,
    restart_proto,
    scan_ports_proto,
    set_config_core_proto,
    set_dac_gain_proto,
    set_dac_highpass_proto,
    set_dac_off_proto,
    set_dac_stream_proto,
    set_dio_events_proto,
    set_dio_gated_proto,
    set_dio_manual_proto,
    set_dio_pulse_proto,
    set_dsp_group_proto,
    set_record_state_proto,
    set_recording_config_proto,
    set_stim_params_proto,
    set_stim_step_proto,
    set_stream_state_proto,
    set_trigger_state_proto,
)
from radiens_core._services._allego_kpi import (
    get_kpi_status_allego_proto,
    kpi_get_metrics_allego_proto,
    set_kpi_packet_dur_allego_proto,
    set_kpi_update_period_proto,
)
from radiens_core._services._allego_pcache import get_hd_snapshot_proto
from radiens_core._typing_helpers import validated
from radiens_core.exceptions import RadiensError
from radiens_core.models.common import ServiceEndpoint
from radiens_core.models.dac import DACHighPass
from radiens_core.models.dataset import FlexTimeRange, TimeRangeSpec, TrsMode
from radiens_core.models.impedance import Impedance
from radiens_core.models.kpi import KpiMetricId, KpiMetricsResult, KpiStatus
from radiens_core.models.ports import Port
from radiens_core.models.signals import FlexSignalSpec, SignalArrays, SignalSpec, SignalType

if TYPE_CHECKING:
    from radiens_core.models.channels import ChannelMetadata
    from radiens_core.models.core_config import CoreConfig, SetCoreConfigRequest
    from radiens_core.models.dac import AnalogOutRegister
    from radiens_core.models.dio import DigitalOutRegister
    from radiens_core.models.dsp import DSPGroup, DSPParams, FilterStage
    from radiens_core.models.status import (
        BackboneStatus,
        RecordingConfig,
        RecordStateRequest,
        RestartRequest,
        StreamStateRequest,
    )
    from radiens_core.models.stim import StimParams, StimStepRequest, StimStepState
    from radiens_core.models.triggers import (
        ManualStimTriggerRequest,
        ManualStimTriggerToggleRequest,
        SetTriggerStateRequest,
        TriggerState,
    )

_log = logging.getLogger(__name__)


def _time_range_floats(tr_spec: TimeRangeSpec) -> list[float]:
    """Convert a TimeRangeSpec to [start, end_or_nan] for HDSnapshotRequest.timeRange.

    FROM_HEAD: [duration_sec, nan] — server reads back ``duration`` seconds from cache head.
    SUBSET:    [start_sec, end_sec].
    TO_HEAD:   [start_sec, nan].
    """
    if tr_spec.mode == TrsMode.SUBSET:
        return [tr_spec.start, tr_spec.end if tr_spec.end is not None else float("nan")]
    return [tr_spec.start, float("nan")]


class AllegoClient(BaseClient):
    """Client for real-time data acquisition and streaming.

    Auto-discovers running servers.  Falls back to well-known allego
    ports if server discovery is unavailable (no radiensserver running).

    Usage::

        with AllegoClient() as client:
            params = client.get_stim_params()
    """

    def __init__(self) -> None:
        addresses = self._discover()
        core_addr = addresses[ServiceEndpoint.ALLEGO_CORE]
        super().__init__(
            addresses=addresses,
            auth_server_address=core_addr,
            fallback_service=ServiceEndpoint.ALLEGO_CORE,
        )

    @staticmethod
    def _discover() -> dict[str, str]:
        return dict(ALLEGO_SERVICE_DEFAULTS)

    # --- Internal helpers ---

    @property
    def _core_address(self) -> str:
        return self._server_address(ServiceEndpoint.ALLEGO_CORE)

    @property
    def _pcache_address(self) -> str:
        return self._server_address(ServiceEndpoint.ALLEGO_PCACHE)

    @property
    def _kpi_address(self) -> str:
        return self._server_address(ServiceEndpoint.ALLEGO_KPI)

    # --- Public API ---

    def get_stim_params(self) -> dict[int, StimParams]:
        """Get stimulation parameters for all configured channels.

        Returns a dict keyed by system channel index (ntvAbsKeyIdx).
        """
        response = get_stim_params_proto(self._pool, self._core_address)
        return stim_params_from_proto(response)

    def get_status(self) -> BackboneStatus:
        """Get comprehensive system status.

        Returns current streaming status, recording status, port information,
        connection state, and GPIO channel counts.
        """
        response = get_status_proto(self._pool, self._core_address)
        return backbone_status_from_proto(response)

    def get_dsp_group(self, stream_group_id: str = PRIMARY_CACHE_STREAM_GROUP_ID) -> DSPGroup:
        """Get current DSP filter configurations.

        Args:
        stream_group_id
            The stream group to query (default "default").

        Returns:
        DSPGroup
            The current hardware and software filter parameters.
        """
        response = get_dsp_group_proto(self._pool, self._core_address, stream_group_id)
        return proto_to_domain_dsp_group(response)

    def set_dsp_group(
        self,
        stage: FilterStage,
        params: list[DSPParams],
        stream_group_id: str = PRIMARY_CACHE_STREAM_GROUP_ID,
    ) -> None:
        """Update DSP filter configuration for a specific stage.

        Args:
        stage
            The filter stage to update (e.g. STAGE1, STAGE2).
        params
            List of filter parameters for this stage.
        stream_group_id
            The stream group to update (default "default").
        """
        req = common_pb2.SetDSPGroupRequest(
            streamGroupId=stream_group_id,
            stage=cast("common_pb2.FilterStage.ValueType", stage.value),
            dspParams=[domain_to_proto_dsp_params(p) for p in params],
        )
        validate_proto(req)
        set_dsp_group_proto(self._pool, self._core_address, req)

    def get_channel_metadata(self) -> ChannelMetadata:
        """Get current channel metadata for all connected channels.

        Returns:
            Complete channel metadata including probe geometry, signal types,
            channel indices, and site positions for all channels.

        Raises:
            RadiensError: On communication failure or server error
        """
        response = get_signal_group_proto(self._pool, self._core_address)
        return channel_metadata_from_proto(response)

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_signals(
        self,
        time_range: FlexTimeRange,
        signals: FlexSignalSpec,
    ) -> SignalArrays:
        """Retrieve signal data from the primary live cache.

        Args:
        time_range
            Time range spec. Most common: ``TimeRangeSpec.lookback(5.0)`` or
            shorthand ``[duration, float('nan')]``. Also accepts
            ``[start, end]`` for absolute SUBSET requests.
        signals
            Channel selection — list of amp indices, ``SignalSpec.amp([...])``,
            or dict for multi-type.

        Returns:
        SignalArrays
            Signal data as numpy arrays (channels x samples).
        """
        tr_spec = validated(time_range, TimeRangeSpec)
        sig_spec = validated(signals, SignalSpec)

        channel_meta = self.get_channel_metadata()
        sig_select = sig_spec.to_sig_select(channel_meta)

        def _sel(idxs: list[int]) -> common_pb2.HDSnapshotRequest.SelectedSignals | None:
            return common_pb2.HDSnapshotRequest.SelectedSignals(ntvChanIdxs=idxs) if idxs else None

        req = common_pb2.HDSnapshotRequest(
            streamGroupId=PRIMARY_CACHE_STREAM_GROUP_ID,
            timeRange=_time_range_floats(tr_spec),
            priSignals=_sel(sig_select.amp.tolist()),
            auxSignals=_sel(sig_select.gpio_ain.tolist()),
            dinSignals=_sel(sig_select.gpio_din.tolist()),
            doutSignals=_sel(sig_select.gpio_dout.tolist()),
        )

        response = get_hd_snapshot_proto(self._pool, self._pcache_address, req)
        return signal_arrays_from_hd_snapshot(response)

    def set_stream_state(self, request: StreamStateRequest) -> None:
        """Set data streaming state.

        Args:
            request: Stream state configuration specifying the desired mode

        Raises:
            RadiensError: If the stream state change fails
        """
        proto_request = stream_state_request_to_proto(request)
        response = set_stream_state_proto(self._pool, self._core_address, proto_request)

        if response.errMsg:
            raise RadiensError(f"Failed to set stream state: {response.errMsg}")

    def healthcheck(self, service: ServiceEndpoint = ServiceEndpoint.ALLEGO_LIFECYCLE) -> None:
        """Perform lightweight system health verification.

        Args:
        service
            Which gRPC service to probe (default ``ALLEGO_LIFECYCLE``).
            ``ALLEGO_CORE`` is also supported.

        Raises:
            RadiensError: If the health check fails or system is unresponsive
        """
        response = healthcheck_proto(self._pool, self._server_address(service), service=service)
        if response.errMsg:
            raise RadiensError(f"Health check failed: {response.errMsg}")

    def set_record_state(self, request: RecordStateRequest) -> None:
        """Set data recording state.

        Args:
            request: Record state configuration specifying the desired mode and optional port

        Raises:
            RadiensError: If the record state change fails
        """
        proto_request = record_state_request_to_proto(request)
        response = set_record_state_proto(self._pool, self._core_address, proto_request)
        if response.errMsg:
            raise RadiensError(f"Failed to set record state: {response.errMsg}")

    def restart(self, request: RestartRequest) -> None:
        """Restart the system with specified backbone mode.

        Args:
            request: Restart configuration specifying the desired backbone mode

        Raises:
            RadiensError: If the restart fails
        """
        proto_request = restart_request_to_proto(request)
        response = restart_proto(self._pool, self._core_address, proto_request)
        if response.errMsg:
            raise RadiensError(f"System restart failed: {response.errMsg}")

    def set_stim_params(self, params: dict[int, StimParams]) -> None:
        """Update stimulation parameters for specified channels.

        Args:
            params: Map from system channel indices to their new stimulation parameters.
                   Each StimParams defines waveform shape, timing, amplitudes, trigger
                   settings, pulse trains, and recovery parameters for that channel.

        Raises:
            RadiensError: On communication failure or server error

        Note:
            The underlying gRPC API sets parameters for one channel at a time.
            This method calls SetStimParams once per channel in the provided dictionary.

        Usage:
            Update stimulation parameters for multiple channels::

                # Define stimulation parameters
                stim_params = StimParams(
                    stim_shape=StimShape.BIPHASIC,
                    stim_polarity=StimPolarity.CATHODIC_FIRST,
                    first_phase_duration=100.0,  # 100 µs
                    second_phase_duration=100.0,  # 100 µs
                    interphase_delay=50.0,  # 50 µs
                    first_phase_amplitude=100.0,  # 100 µA
                    second_phase_amplitude=-100.0,  # 100 µA (opposite polarity)
                    baseline_voltage=0.0,
                    trigger_edge_or_level=StimTriggerEdge.EDGE,
                    trigger_high_or_low=StimTriggerLevel.HIGH,
                    enabled=True,
                    post_trigger_delay=1000.0,  # 1 ms = 1000 µs
                    pulse_or_train=StimPulseMode.SINGLE_PULSE,
                    number_of_stim_pulses=1,
                    pulse_train_period=20000.0,  # 20 ms = 50 Hz
                    refractory_period=10000.0,  # 10 ms
                    pre_stim_amp_settle=1000.0,  # 1 ms
                    post_stim_amp_settle=1000.0,  # 1 ms
                    maintain_amp_settle=False,
                    enable_amp_settle=True,
                    post_stim_charge_recov_on=1000.0,  # 1 ms
                    post_stim_charge_recov_off=0.0,
                    enable_charge_recovery=True,
                    trigger_source_is_keypress=False,
                    trigger_source_idx=0,
                    stim_sys_chan_idx=42,
                )

                # Update channels 42 and 43
                client.set_stim_params({
                    42: stim_params,
                    43: stim_params.model_copy(update={'first_phase_amplitude': 150.0}),
                })
        """

        if not params:
            msg = "params cannot be empty - must specify at least one channel"
            raise RadiensError(msg)

        # SetStimParams works on one channel at a time
        # Validate and process each channel
        for sys_chan_idx, stim_params in params.items():
            # Ensure the sys_chan_idx matches the one in the StimParams
            if stim_params.stim_sys_chan_idx != sys_chan_idx:
                # Create updated stim_params with correct sys_chan_idx
                updated_params = stim_params.model_copy(update={"stim_sys_chan_idx": sys_chan_idx})
            else:
                updated_params = stim_params

            proto_request = stim_params_to_proto(updated_params)
            response = set_stim_params_proto(self._pool, self._core_address, proto_request)

            # Check for errors in the response
            if response.errMsg:
                raise RadiensError(f"Set stimulation parameters failed for channel {sys_chan_idx}: {response.errMsg}")

    def set_trigger_state(self, request: SetTriggerStateRequest) -> None:
        """Set trigger channel state for stimulation control.

        Args:
            request: Configuration for trigger channel state

        Raises:
            RadiensError: On communication failure or server error
        """
        proto_request = set_trigger_state_request_to_proto(request)
        response = set_trigger_state_proto(self._pool, self._core_address, proto_request)
        if response.errMsg:
            raise RadiensError(f"Set trigger state failed: {response.errMsg}")

    def get_trigger_state(self) -> TriggerState:
        """Get current trigger channel configuration.

        Returns:
            Current trigger state showing enabled channels and ports

        Raises:
            RadiensError: On communication failure or server error
        """
        response = get_trigger_state_proto(self._pool, self._core_address)
        return trigger_state_from_proto(response)

    def manual_stim_trigger(self, request: ManualStimTriggerRequest) -> None:
        """Manually trigger stimulation.

        Args:
            request: Manual trigger configuration

        Raises:
            RadiensError: On communication failure or server error
        """
        proto_request = manual_stim_trigger_request_to_proto(request)
        response = manual_stim_trigger_proto(self._pool, self._core_address, proto_request)
        if response.errMsg:
            raise RadiensError(f"Manual stim trigger failed: {response.errMsg}")

    def manual_stim_trigger_toggle(self, request: ManualStimTriggerToggleRequest) -> None:
        """Toggle manual stimulation trigger.

        Args:
            request: Manual trigger toggle configuration

        Raises:
            RadiensError: On communication failure or server error
        """
        proto_request = manual_stim_trigger_toggle_request_to_proto(request)
        response = manual_stim_trigger_toggle_proto(self._pool, self._core_address, proto_request)
        if response.errMsg:
            raise RadiensError(f"Manual stim trigger toggle failed: {response.errMsg}")

    def set_stim_step(self, request: StimStepRequest) -> None:
        """Set stimulation step size.

        Args:
            request: Stimulation step configuration

        Raises:
            RadiensError: On communication failure or server error
        """
        proto_request = stim_step_request_to_proto(request)
        response = set_stim_step_proto(self._pool, self._core_address, proto_request)
        if response.errMsg:
            raise RadiensError(f"Set stim step failed: {response.errMsg}")

    def get_stim_step(self) -> StimStepState:
        """Get current stimulation step size setting.

        Returns:
            Current stimulation step configuration

        Raises:
            RadiensError: On communication failure or server error
        """
        response = get_stim_step_proto(self._pool, self._core_address)
        return stim_step_state_from_proto(response)

    def set_recording_config(self, config: RecordingConfig) -> None:
        """Set recording configuration settings.

        Configures output file paths, naming, and recording behavior.
        This affects where recorded data will be saved when recording is started.

        Args:
            config: Recording configuration specifying file paths, naming,
                   and recording type (continuous/spikes/both)

        Raises:
            RadiensError: If the recording config change fails

        Example:
            Configure recording to save continuous data with timestamps::

                config = RecordingConfig(
                    base_file_name="my_recording",
                    base_file_path="/path/to/data",
                    recording_type=DataRecordingType.CONTINUOUS,
                    time_stamp=True,
                )
                client.set_recording_config(config)
        """
        proto_request = recording_config_to_proto(config)
        response = set_recording_config_proto(self._pool, self._core_address, proto_request)
        if response.errMsg:
            raise RadiensError(f"Failed to set recording config: {response.errMsg}")

    def get_core_config(self) -> CoreConfig:
        """Get core hardware configuration settings.

        Returns:
            Current core hardware configuration including sampling frequency,
            loop duration, and cable delays.

        Raises:
            RadiensError: On communication failure or server error
        """
        response = get_config_proto(self._pool, self._core_address)
        return core_config_from_proto(response)

    def set_core_config(self, request: SetCoreConfigRequest) -> None:
        """Update core hardware configuration settings.

        Args:
            request: Configuration parameters to update

        Raises:
            RadiensError: On communication failure or server error
        """
        proto_req = set_core_config_to_proto(request)
        response = set_config_core_proto(self._pool, self._core_address, proto_req)
        if response.errMsg:
            raise RadiensError(f"Failed to set core config: {response.errMsg}")

    def get_recording_config(self) -> RecordingConfig:
        """Get current recording configuration settings.

        Returns:
            Current recording configuration including file paths, naming,
            and recording type settings

        Raises:
            RadiensError: On communication failure or server error
        """
        response = get_recording_config_proto(self._pool, self._core_address)
        return recording_config_from_proto(response)

    # ===================================================================
    # Hardware Diagnostics
    # ===================================================================

    @validate_call
    def get_intan_impedance(self, port: Port) -> Impedance:
        """Measure impedance for all channels on a specific port.

        Args:
            port: The hardware port to measure (e.g., Port.A)

        Returns:
            Impedance measurements for all channels on the specified port.

        Raises:
            RadiensError: On communication failure or server error
        """
        proto_req = impedance_request_to_proto(port)
        response = get_intan_impedance_proto(self._pool, self._core_address, proto_req)
        return impedance_from_proto(response)

    def scan_ports(self) -> ChannelMetadata:
        """Scan all hardware ports to determine connected headstages and probes.

        Returns:
            Updated channel metadata based on the newly discovered hardware.

        Raises:
            RadiensError: On communication failure or server error
        """
        response = scan_ports_proto(self._pool, self._core_address)
        return channel_metadata_from_proto(response)

    def get_dac_reg(self) -> AnalogOutRegister:
        """Get current DAC (Analog Output) register settings.

        Returns:
            The complete DAC register state, including gain, high-pass
            filter configuration, and channel mappings.

        Raises:
            RadiensError: On communication failure or server error
        """
        response = get_dac_reg_proto(self._pool, self._core_address)
        return analog_out_register_from_proto(response)

    @validate_call
    def set_dac_gain(self, gain: int) -> None:
        """Set DAC (Analog Output) gain.

        Args:
            gain: The gain value to set.

        Raises:
            RadiensError: On communication failure or server error
        """
        request = set_dac_gain_to_proto(gain)
        response = set_dac_gain_proto(self._pool, self._core_address, request)
        validate_proto(response)

    @validate_call
    def set_dac_stream(self, dac_idx: int, ntv_chan_idx: int) -> None:
        """Map a source channel to a DAC (Analog Output) channel.

        Args:
            dac_idx: The DAC channel index to configure.
            ntv_chan_idx: The source channel index to output.

        Raises:
            RadiensError: On communication failure or server error
        """
        request = set_dac_stream_to_proto(dac_idx, ntv_chan_idx, PRIMARY_CACHE_STREAM_GROUP_ID)
        response = set_dac_stream_proto(self._pool, self._core_address, request)
        validate_proto(response)

    def set_dac_off(self) -> None:
        """Turn off all DAC (Analog Output) streams.

        Raises:
            RadiensError: On communication failure or server error
        """
        request = set_dac_off_to_proto(PRIMARY_CACHE_STREAM_GROUP_ID)
        response = set_dac_off_proto(self._pool, self._core_address, request)
        validate_proto(response)

    @validate_call
    def set_dac_highpass(self, enable: bool, cutoff_freq: float) -> None:
        """Configure DAC (Analog Output) high-pass filter.

        Args:
            enable: Whether to enable the high-pass filter.
            cutoff_freq: The cutoff frequency in Hz.

        Raises:
            RadiensError: On communication failure or server error
        """
        request = dac_highpass_to_proto(DACHighPass(enable=enable, cutoff_freq=cutoff_freq))
        response = set_dac_highpass_proto(self._pool, self._core_address, request)
        validate_proto(response)

    # ===================================================================
    # Digital Output (DIO) Control
    # ===================================================================

    def get_dio_reg(self) -> DigitalOutRegister:
        """Get current DIO (Digital Output) register settings.

        Returns:
            The complete DIO register state, including current mode and
            per-channel configurations.

        Raises:
            RadiensError: On communication failure or server error
        """
        response = get_dio_reg_proto(self._pool, self._core_address)
        return digital_out_register_from_proto(response)

    @validate_call
    def set_dio_events(self, chan_idx: int, threshold: float, polarity: bool) -> None:
        """Configure DIO channel to trigger on analog threshold crossings.

        Args:
            chan_idx: Native channel index.
            threshold: Event threshold in microvolts (μV).
            polarity: Event polarity (True for positive-going, False for negative-going).

        Raises:
            RadiensError: On communication failure or server error
        """
        request = set_dio_events_to_proto(chan_idx, threshold, polarity)
        response = set_dio_events_proto(self._pool, self._core_address, request)
        validate_proto(response)

    @validate_call
    def set_dio_manual(self, chan_idx: int, state: bool) -> None:
        """Set DIO channel state manually.

        Note:
            The DIO mode must be set to MANUAL for this to take effect.

        Args:
            chan_idx: Native channel index.
            state: Desired state (True for high, False for low).

        Raises:
            RadiensError: On communication failure or server error
        """
        request = set_dio_manual_to_proto(chan_idx, state)
        response = set_dio_manual_proto(self._pool, self._core_address, request)
        validate_proto(response)

    @validate_call
    def set_dio_gated(self, polarity: bool) -> None:
        """Set DIO gated mode polarity.

        Args:
            polarity: Gated polarity (True for high-active, False for low-active).

        Raises:
            RadiensError: On communication failure or server error
        """
        request = set_dio_gated_to_proto(polarity)
        response = set_dio_gated_proto(self._pool, self._core_address, request)
        validate_proto(response)

    @validate_call
    def set_dio_pulse(self, interval_sec: float, duration_sec: float, chan_idx: int = -1) -> None:
        """Configure DIO channel(s) for pulse mode.

        Args:
            interval_sec: Pulse interval in seconds.
            duration_sec: Pulse duration in seconds.
            chan_idx: Native channel index (-1 for all channels).

        Raises:
            RadiensError: On communication failure or server error
        """
        request = set_dio_pulse_to_proto(interval_sec, duration_sec, chan_idx)
        response = set_dio_pulse_proto(self._pool, self._core_address, request)
        validate_proto(response)

    # ===================================================================
    # KPI Metrics
    # ===================================================================

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_kpi_metrics(
        self,
        metrics: list[KpiMetricId],
        channel_indices: list[int],
        time_range: FlexTimeRange,
        signal_type: SignalType = SignalType.AMP,
        stream_group_id: str = PRIMARY_CACHE_STREAM_GROUP_ID,
    ) -> KpiMetricsResult:
        """Retrieve computed KPI signal metrics from the live cache.

        Args:
        metrics
            List of KPI metric identifiers to compute.
        channel_indices
            Native channel indices (ntvIdxs) to query.
        time_range
            Time range spec. Use ``[duration, float('nan')]`` for a lookback
            window or ``[start, end]`` for an absolute range.
        signal_type
            Signal type to query (default ``AMP``).
        stream_group_id
            Stream group to query (default ``"default"``).

        Returns:
        KpiMetricsResult
            Metric values as a ``(n_channels, n_metrics)`` numpy array
            with row/column labels.
        """
        tr_spec = validated(time_range, TimeRangeSpec)
        req = common_pb2.KpiMetricsReq(
            streamGroupId=stream_group_id,
            stype=cast("common_pb2.SignalType.ValueType", signal_type.value),
            arg=build_bundle_req(channel_indices, _time_range_floats(tr_spec), metrics),
        )
        response = kpi_get_metrics_allego_proto(self._pool, self._kpi_address, req)
        return kpi_metrics_result_from_proto(response)

    def get_kpi_status(
        self,
        stream_group_id: str = PRIMARY_CACHE_STREAM_GROUP_ID,
    ) -> KpiStatus:
        """Get the current KPI cache status.

        Args:
        stream_group_id
            Stream group to query (default ``"default"``).

        Returns:
        KpiStatus
            Number of packets in cache, packet duration, update period,
            memory usage, and tracking state.
        """
        req = common_pb2.GetKpiStatusRequest(streamGroupId=stream_group_id)
        response = get_kpi_status_allego_proto(self._pool, self._kpi_address, req)
        return kpi_status_from_proto(response)

    def set_kpi_packet_dur(
        self,
        packet_dur: float,
        stream_group_id: str = PRIMARY_CACHE_STREAM_GROUP_ID,
    ) -> None:
        """Set the KPI packet duration (integration window).

        Args:
        packet_dur
            Duration of each KPI packet in seconds.
        stream_group_id
            Stream group to configure (default ``"default"``).

        Raises:
        RadiensError
            On communication failure or server error.
        """
        req = common_pb2.SetKpiParamRequest(streamGroupId=stream_group_id, param=packet_dur)
        response = set_kpi_packet_dur_allego_proto(self._pool, self._kpi_address, req)
        if response.errMsg:
            raise RadiensError(f"Failed to set KPI packet duration: {response.errMsg}")

    def set_kpi_update_period(
        self,
        update_period: float,
        stream_group_id: str = PRIMARY_CACHE_STREAM_GROUP_ID,
    ) -> None:
        """Set how often the KPI cache is refreshed from the live signal stream.

        Args:
        update_period
            Update interval in seconds.
        stream_group_id
            Stream group to configure (default ``"default"``).

        Raises:
        RadiensError
            On communication failure or server error.
        """
        req = common_pb2.SetKpiParamRequest(streamGroupId=stream_group_id, param=update_period)
        response = set_kpi_update_period_proto(self._pool, self._kpi_address, req)
        if response.errMsg:
            raise RadiensError(f"Failed to set KPI update period: {response.errMsg}")
