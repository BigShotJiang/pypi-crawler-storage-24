# API Implementation Status

This document tracks the implementation status of gRPC endpoints from `radiensserver` and `allegoserver` within the `radiens-core-python` clients. It identifies implemented methods, pending tasks, and endpoints that are intentionally excluded.

## AllegoClient (Real-Time)

`AllegoClient` is the primary interface for real-time data acquisition.

### Implemented

- **Lifecycle:** `healthcheck`
- **System State:** `get_status` (BackboneStatus), `restart`, `set_stream_state`, `set_record_state`
- **Configuration:** `get_recording_config`, `set_recording_config`, `get_core_config`, `set_core_config`
- **DSP:** `get_dsp_group`, `set_dsp_group`
- **Data Retrieval:** `get_signals` (via HDSnapshot), `get_channel_metadata` (via SignalGroup)
- **Stimulation:** `get_stim_params`, `set_stim_params`, `get_stim_step`, `set_stim_step`, `manual_stim_trigger`, `manual_stim_trigger_toggle`
- **Triggers:** `get_trigger_state`, `set_trigger_state`
- **Analog Output (DAC) Control:** `get_dac_reg`, `set_dac_gain`, `set_dac_stream`, `set_dac_off`, `set_dac_highpass`
- **Digital Output (DIO) Control:** `get_dio_reg`, `set_dio_events`, `set_dio_manual`, `set_dio_gated`, `set_dio_pulse`
- **Metrics (KPI):** `get_kpi_metrics`, `get_kpi_status`, `set_kpi_packet_dur`, `set_kpi_update_period`
- **Hardware Diagnostics:** `get_intan_impedance`, `scan_ports`

### Pending Implementation

- **Spike Sorting (Biointerface):** `spikeSorterSetParam`, `spikeSorterGetParam`, `spikesGetSpikesDense`, `spikesGetNeurons`
- **Sinaps:** `loadAllMosi`, `transmitMosi`, `readWireOut`, `getSinapsStatusRegisters`, `flashSinaps`

---

## VidereClient (Offline)

`VidereClient` provides access to recorded data files via `radiensserver`.

### Implemented

- **Lifecycle:** `healthcheck`
- **Data Loading:** `link_data_file` (set_datasource)
- **Data Retrieval:** `get_signals` (via HDSnapshotPy)
- **Filtering:** `get_dsp_group`, `set_dsp_group`
- **Metrics (KPI):** `get_kpi_metrics`, `get_kpi_status`, `kpi_calculate`, `kpi_clear`, `set_kpi_packet_dur`
- **Data Management:** `list_data_sources`, `list_data_source_ids`, `clear_data_sources`, `export_data_source`
- **Remote Filesystem:** `list_directory`, `copy_data_source_file`, `move_data_source_file`, `remove_data_source_file`

### Pending Implementation

- **Spike Data:** `spikesGetSpikesDense`, `spikesGetNeurons`, `getSpikeTrainAnalytic`, `spikesGetSpec`
- **Hardware Playback:** `setDACStream`, `setDACOff` (routing file data to physical DAC)

---

## CurateClient (Processing)

`CurateClient` manages data transformation pipelines (Protocols).

### Implemented

- **Lifecycle:** `healthcheck`
- **Data Loading:** `link_data_file`
- **Data Management:** `list_data_sources`, `list_data_source_ids`, `clear_data_sources`, `export_data_source`
- **Remote Filesystem:** `list_directory`, `copy_data_source_file`, `move_data_source_file`, `remove_data_source_file`
- **Transforms:** `slice_time`, `downsample`, `highpass`, `lowpass`, `bandpass`, `bandstop`, `notch`, `slice_channels`
- **Re-referencing:** `car`, `virtual_ref`, `paired_ref`
- **Bulk Transforms:** `bulk_highpass`, `bulk_lowpass`, `bulk_bandpass`, `bulk_bandstop`, `bulk_notch`, `bulk_downsample`, `bulk_slice_time`
- **Protocol Management:** `apply_protocol`, `get_protocol`, `get_all_protocols`, `set_protocol`

### Pending Implementation

_(none)_

---

## Intentionally Excluded Endpoints

The following endpoints are used by the `allego-electron` frontend for UI and session management and are not planned for the Python client:

- **UI/Layout:** `workspaceControl`, `getWorkspace`, `getOrCreateEventViewer`, `updateEventViewer`, `listEventViewerEvents`, `getEventViewerEvent`, `listEventViewers`.
- **App Lifecycle:** `launchSummaService`, `getStartupStatus`, `close` (process termination), `getRadixEnvironment`, `clientConnect`, `clientDisconnect`.
- **Licensing/Telemetry:** `featureStart`, `featureStop`, `getPrivacy`, `setPrivacy`, `getOfflineLicenseStatus`.
- **Frontend Optimization:** `getStatusPollFieldsToUpdate`.
