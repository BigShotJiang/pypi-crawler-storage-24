from __future__ import annotations

from radiens_core._converters._impedance import (
    impedance_from_proto,
    impedance_request_to_proto,
    port_to_proto,
)
from radiens_core._generated import common_pb2, datasource_pb2
from radiens_core.models.ports import Port


def test_port_to_proto() -> None:
    assert port_to_proto(Port.A) == common_pb2.A
    assert port_to_proto(Port.H) == common_pb2.H


def test_impedance_from_proto() -> None:
    proto = datasource_pb2.Impedance(
        impedances=[
            datasource_pb2.Impedance.ImpedanceValue(ntvChanIdx=0, zMag=1000.0, zPhase=0.0),
            datasource_pb2.Impedance.ImpedanceValue(ntvChanIdx=1, zMag=2000.0, zPhase=1.0),
        ]
    )
    domain = impedance_from_proto(proto)
    assert len(domain.measurements) == 2
    assert domain.measurements[0].ntv_chan_idx == 0
    assert domain.measurements[0].magnitude_ohm == 1000.0
    assert domain.measurements[0].phase_deg == 0.0
    assert domain.measurements[1].ntv_chan_idx == 1
    assert domain.measurements[1].magnitude_ohm == 2000.0
    assert domain.measurements[1].phase_deg == 1.0


def test_impedance_request_to_proto() -> None:
    proto = impedance_request_to_proto(Port.B)
    assert isinstance(proto, datasource_pb2.ImpedanceRequest)
    assert proto.port == common_pb2.B
