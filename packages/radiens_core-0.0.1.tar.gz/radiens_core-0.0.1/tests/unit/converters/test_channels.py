"""Tests for channel metadata converters."""

from __future__ import annotations

from radiens_core._converters._channels import channel_metadata_from_proto
from radiens_core._generated import common_pb2


class TestChannelCoordinateScaling:
    def test_site_ctr_x_scaled_by_10(self) -> None:
        """siteCtrX in proto (10s of microns) must be multiplied by 10 in domain."""
        ch = common_pb2.ChannelRecord(
            chanType=common_pb2.PRI,
            siteCtrX=5.0,
            siteCtrY=0.0,
            siteCtrZ=0.0,
        )
        sig_group = common_pb2.SignalGroup()
        sig_group.channels.append(ch)

        metadata = channel_metadata_from_proto(sig_group)

        assert len(metadata.site_positions) == 1
        assert metadata.site_positions[0].probe_x == 50.0

    def test_all_site_coordinates_scaled(self) -> None:
        """All site coordinate fields must be scaled by 10."""
        ch = common_pb2.ChannelRecord(
            chanType=common_pb2.PRI,
            siteCtrX=1.0,
            siteCtrY=2.0,
            siteCtrZ=3.0,
        )
        sig_group = common_pb2.SignalGroup()
        sig_group.channels.append(ch)

        metadata = channel_metadata_from_proto(sig_group)

        pos = metadata.site_positions[0]
        assert pos.probe_x == 10.0
        assert pos.probe_y == 20.0
        assert pos.probe_z == 30.0
