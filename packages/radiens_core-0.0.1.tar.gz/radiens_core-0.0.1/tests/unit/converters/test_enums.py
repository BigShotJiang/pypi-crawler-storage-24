"""Tests for enum converters — roundtrip domain -> proto -> domain."""

from radiens_core._converters._channels import signal_type_from_proto, signal_type_to_proto
from radiens_core._converters._common_enums import (
    backbone_mode_from_proto,
    backbone_mode_to_proto,
    port_from_proto,
    port_to_proto,
    record_mode_from_proto,
    record_mode_to_proto,
    stream_mode_from_proto,
    stream_mode_to_proto,
)
from radiens_core._converters._dataset import file_type_from_proto, file_type_to_proto
from radiens_core._converters._time_range import trs_mode_from_proto, trs_mode_to_proto
from radiens_core.models.dataset import RadiensFileType, TrsMode
from radiens_core.models.ports import Port
from radiens_core.models.signals import SignalType
from radiens_core.models.status import BackboneMode, RecordMode, StreamMode


def test_signal_type_roundtrip() -> None:
    for st in SignalType:
        proto_val = signal_type_to_proto(st)
        back = signal_type_from_proto(int(proto_val))
        assert back == st, f"SignalType roundtrip failed for {st}"


def test_trs_mode_roundtrip() -> None:
    for mode in TrsMode:
        proto_val = trs_mode_to_proto(mode)
        back = trs_mode_from_proto(int(proto_val))
        assert back == mode, f"TrsMode roundtrip failed for {mode}"


def test_file_type_roundtrip() -> None:
    for ft in RadiensFileType:
        proto_val = file_type_to_proto(ft)
        back = file_type_from_proto(proto_val)
        assert back == ft, f"RadiensFileType roundtrip failed for {ft}"


def test_stream_mode_roundtrip() -> None:
    for mode in StreamMode:
        proto_val = stream_mode_to_proto(mode)
        back = stream_mode_from_proto(int(proto_val))
        assert back == mode, f"StreamMode roundtrip failed for {mode}"


def test_record_mode_roundtrip() -> None:
    for mode in RecordMode:
        proto_val = record_mode_to_proto(mode)
        back = record_mode_from_proto(int(proto_val))
        assert back == mode, f"RecordMode roundtrip failed for {mode}"


def test_port_roundtrip() -> None:
    for port in Port:
        proto_val = port_to_proto(port)
        back = port_from_proto(int(proto_val))
        assert back == port, f"Port roundtrip failed for {port}"


def test_backbone_mode_roundtrip() -> None:
    for mode in BackboneMode:
        proto_val = backbone_mode_to_proto(mode)
        back = backbone_mode_from_proto(int(proto_val))
        assert back == mode, f"BackboneMode roundtrip failed for {mode}"
