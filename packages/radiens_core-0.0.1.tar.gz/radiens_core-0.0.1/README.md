# radiens-core

**A typed Python client for the Radiens electrophysiology platform.**

## Overview

`radiens-core` is a Python client library that communicates with the Radiens backend servers over gRPC. It provides type-safe domain models (via Pydantic v2) and auto-discovers locally running services, giving Python scripts and notebooks programmatic access to the same acquisition, analysis, and curation capabilities available in the Radiens desktop applications.

> **Status:** This package is in beta. APIs may change between releases.

## Key Capabilities

- **Real-time Acquisition (`AllegoClient`)** — Control streaming and recording state, retrieve live signal data, configure DSP filters, manage stimulation parameters, and read hardware diagnostics (impedance, port scanning).
- **Offline Analysis (`VidereClient`)** — Link recorded data files (`.xdat`, `.rhd`), retrieve signal segments, apply DSP filters, and compute signal-quality metrics (KPI).
- **Data Curation (`CurateClient`)** — Run filtering, re-referencing, downsampling, and time/channel slicing transforms on recorded datasets. Supports bulk operations and reusable transform protocols.

All three clients require a running Radiens backend (`allegoserver` or `radiensserver`). Clients auto-discover services on the local machine.

## Documentation

API reference and usage guides: <https://neuronexus.github.io/radiens-core-python/>

## Installation

```bash
pip install radiens-core
```

Requires Python 3.12+ and a running Radiens backend server.

## Support

For technical support or inquiries regarding the Radiens platform:

- **Web**: [NeuroNexus Support](https://neuronexus.com/support/)
- **Email**: <support@neuronexus.com>

## License

This project is licensed under the terms described in the LICENSE file included with this distribution.
