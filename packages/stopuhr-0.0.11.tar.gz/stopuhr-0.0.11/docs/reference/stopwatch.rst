stopwatch
=================

.. autodata:: stopuhr.stopwatch
