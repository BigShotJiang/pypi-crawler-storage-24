def template():
    code = """
import pandas as pd
import xml.etree.ElementTree as ET

# Parse XML file
tree = ET.parse("student_data.xml")
root = tree.getroot()

# List to store extracted rows
rows = []

# Loop through each student node
for node in root:
    sname = node.attrib.get("name") if node is not None else None
    smail = node.find("email").text if node.find("email") is not None else None
    sroll = node.find("roll_no").text if node.find("roll_no") is not None else None
    sage  = node.find("age").text if node.find("age") is not None else None

    rows.append({
        "name": sname,
        "email": smail,
        "roll_no": sroll,
        "age": sage
    })

# Convert to DataFrame
output_df = pd.DataFrame(rows)

# Display DataFrame
print(output_df)

# Save to CSV (optional)
output_df.to_csv("student_data.csv", index=False)

<data>
    <student name="John">
        <email>john@email.com</email>
        <roll_no>101</roll_no>
        <age>20</age>
    </student>
</data>

"""
    return code
