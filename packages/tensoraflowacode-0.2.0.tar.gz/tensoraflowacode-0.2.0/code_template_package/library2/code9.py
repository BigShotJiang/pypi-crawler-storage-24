def template():
    code = """
PRACTICAL 6B
Aim: Demonstrate Table Partitioning and Clustering (Bucketing in Hive)

Step 1: Create partition table
Command:
create table emp_partition(
emp_id int,
name string,
mob_no string
)
partitioned by (dept string)
row format delimited
fields terminated by ',';

Step 2: Enable dynamic partition
Command:
set hive.exec.dynamic.partition.mode=nonstrict;

Step 3: Insert data into partition table
Commands:
insert into emp_partition partition(dept='HR') values(1,'jay','89272861');
insert into emp_partition partition(dept='HR') values(2,'uday','89272567');
insert into emp_partition partition(dept='IT') values(3,'ajay','98772567');

Step 4: Display table data

Command:
select * from emp_partition;

Step 5: Retrieve data from specific partition
Command:
select * from emp_partition where dept='IT';

Step 6: Create bucket table without partition
Command:
create table emp_buck_no_partition(
emp_id int,
name string,
m_no string
)
clustered by (m_no) into 5 buckets;

Step 7: Insert values into bucket table
Commands:
insert into emp_buck_no_partition values(1,'abc','89734567');
insert into emp_buck_no_partition values(2,'def','89734239');
insert into emp_buck_no_partition values(3,'xyz','69534239');

Step 8: Display bucket table data
Command:
select * from emp_buck_no_partition;

Step 9: Create table with both partition and bucket
Command:
create table emp_buck_with_partition(
emp_id int,
name string,
m_no string
)
partitioned by (dept string)
clustered by (m_no) into 5 buckets;

set hive.exec.dynamic.partition.mode=nonstrict;

Step 10: Insert data
Command:
insert into emp_buck_with_partition partition(dept='IT') values(1,'abc','89762981');

select * from emp_buck_with_partition where dept='IT';
"""
    return code
