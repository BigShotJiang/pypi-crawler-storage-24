def template():
    code = """
prac8

pip install pyspark==3.5.0
pip install pandas
# Run first 2 lines separately as it is creating one session

from pyspark.sql import SparkSession
from pyspark.sql.functions import col




spark = SparkSession.builder.appName("DataProcessingRDD").getOrCreate()

df_iris = spark.read.format("csv") \
    .option("header","true") \
    .option("inferSchema","true") \
    .load("iris.csv")

df_iris.show()

df_iris.count()

# Rename columns to remove dots
df_iris_cleaned = df_iris.withColumnRenamed("Sepal.Length","Sepal_Length") \
                         .withColumnRenamed("Sepal.Width","Sepal_Width") \
                         .withColumnRenamed("Petal.Length","Petal_Length") \
                         .withColumnRenamed("Petal.Width","Petal_Width")

df_iris_cleaned.summary().show()

df_iris_cleaned.select('Sepal_Length').summary().show()

df_iris_cleaned.select('Sepal_Length','Petal_Length').show()

df_iris_cleaned.createOrReplaceTempView("iris_table")

df_iris1 = spark.sql('select * from iris_table where Petal_Length<2.5')

df_iris1.show()

df_iris1.count()

df_iris2 = spark.sql('select * from iris_table where Petal_Length between 2.5 and 4.5')

df_iris2.show()

df_iris2.count()

spark.sql("select Species, Count(*) from iris_table group by Species").show()

spark.sql("select Sepal_Length, Sepal_Width, Species from iris_table where Species='setosa'").show()

df_iris3 = spark.sql("select Species, min(Sepal_Length) as Min_Sepal_Length from iris_table group by Species")

df_iris3.show()

df_iris_cleaned.groupBy('Species').min('Sepal_Length').show()

spark.sql("" #add " one more time
select Species,
min(Petal_Length) as Min_Petal_Length,
max(Petal_Length) as Max_Petal_Length,
avg(Petal_Length) as Avg_Petal_Length
from iris_table
group by Species
"").show()    #add " one more time

spark.sql(""    #add " one more time
select Species, mean(Petal_Length) as Avg_Petal_Length
from iris_table
group by Species
having mean(Petal_Length)>4
"").show() #add " one more time

df_iris_cleaned.where('Species="setosa"').show()

df_iris_cleaned.columns

pd_iris = df_iris_cleaned.toPandas()

pd_iris.head()

df_iris_cleaned.orderBy('Sepal_Length').show()

df_iris_cleaned2 = df_iris.toDF('ID','Sepal_Length','Sepal_Width','Petal_Length','Petal_Width','Species')

df_iris_cleaned2.show()

"""
    return code
