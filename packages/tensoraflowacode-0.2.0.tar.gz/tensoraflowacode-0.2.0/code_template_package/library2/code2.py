def template():
    code = """
pip install requests
pip install beautifulsoup4
import requests
from bs4 import BeautifulSoup

BASE='https://quotes.toscrape.com/page/{}/'

Start=1
End=5

for page in range(Start,End+1):

    url=BASE.format(page)

    r=requests.get(url)

    if r.status_code!=200:
        print('Failed:',r.status_code)
        continue

    soup=BeautifulSoup(r.text,"html.parser")

    quotes=soup.select(".quote")

    for q in quotes:
        text=q.select_one(".text").get_text(strip=True)
        author=q.select_one(".author").get_text(strip=True)

        print(text,'-',author)

print('Done')
"""
    return code
