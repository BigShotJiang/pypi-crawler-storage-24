def template():
    code = """
PRACTICAL 4
Aim: Working with NoSQL Database – HBase

Step 1: Start HBase Shell
Command:
hbase shell
Step 2: List existing tables (Verify tables)
Command:
list
Step 3: Create table with column families
Command:
create 'studrj','studname','studaddress'
Step 4: Verify created tables
Command:
list
Step 5: Verify structure of table
Command:
describe 'studrj'
Step 6: Inserting values in table
Commands:
put 'studrj','1','studname:fname','ramu'
put 'studrj','1','studname:mname','kaka'
put 'studrj','1','studname:lname','shukla'
put 'studrj','1','studname:place','poland'

put 'studrj','2','studname:fname','sumit'
put 'studrj','2','studname:lname','neeraj'
put 'studrj','2','studname:mname','kulkarni'
put 'studrj','2','studaddress:road','Devi Dayal Road'
put 'studrj','2','studaddress:place','Mulund W'
Step 7: To display all rows with all column values from table
Command:
scan 'studrj'
Step 8: Get value for column (Conditional Retrieval)
Command:
get 'studrj','1','studname'
Step 9: Conditional delete (Delete column middle name for student id 1)
Command:
delete 'studrj','1','studname:mname'
Step 10: Deleting whole record for specific id
Command:
deleteall 'studrj','1'
Step 11: Setting maximum number of cell versions for column family
Command:
alter 'studrj', NAME=>'studadd', VERSIONS=>5
Step 12: Delete column family from table
Command:
alter 'studrj', 'delete'=>'studadd'
Step 13: Dropping table and checking existence
Commands:
disable 'studrj'
drop 'studrj'
exists 'studrj'
"""
    return code
