def template():
    code = """
pip install pandas
pip install scikit-learn


import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score,classification_report
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier

ds=load_breast_cancer()

df=pd.DataFrame(ds.data,columns=ds.feature_names)

df['class']=ds.target

logit_ml=Pipeline([
('scaling',StandardScaler()),
('pca',PCA(n_components=3)),
('model_logit',LogisticRegression())
])

dtree_ml=Pipeline([
('scaling',StandardScaler()),
('pca',PCA(n_components=3)),
('model_logit',DecisionTreeClassifier())
])

nb_ml=Pipeline([
('scaling',StandardScaler()),
('pca',PCA(n_components=3)),
('model_logit',GaussianNB())
])

Random_ml=Pipeline([
('scaling',StandardScaler()),
('pca',PCA(n_components=3)),
('model_logit',RandomForestClassifier())
])

X=df.iloc[:,:-1]
y=df.iloc[:,-1]

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.25,random_state=1)

my_pipeline=[logit_ml,dtree_ml,nb_ml]

pipeline_dict={0:'Logistic_Regression',1:'Decision_Tree',2:'Naive_Bayes'}

for i in my_pipeline:
    i.fit(X_train,y_train)

for i, model in enumerate(my_pipeline):
    print(f"{pipeline_dict[i]}'s training accuracy is: {model.score(X_train,y_train)}")

for i, model in enumerate(my_pipeline):
    print(f"{pipeline_dict[i]}'s testing accuracy is: {model.score(X_test, y_test)}")
"""
    return code
