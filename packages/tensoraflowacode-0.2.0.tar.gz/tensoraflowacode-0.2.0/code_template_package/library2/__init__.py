from .code1 import template as code1
from .code2 import template as code2
from .code3 import template as code3
from .code4 import template as code4
from .code5 import template as code5
from .code6 import template as code6
from .code7 import template as code7
from .code8 import template as code8
from .code9 import template as code9
from .code10 import template as code10
from .code11 import template as code11
from .code12 import template as code12
from .code13 import template as code13
from .code14 import template as code14
from .code15 import template as code15

__all__ = ['code1', 'code2', 'code3', 'code4', 'code5', 'code6', 'code7', 'code8', 'code9', 'code10', 'code11', 'code12', 'code13', 'code14', 'code15']
