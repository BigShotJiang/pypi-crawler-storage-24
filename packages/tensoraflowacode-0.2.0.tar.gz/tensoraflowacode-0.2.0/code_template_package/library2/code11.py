def template():
    code = """
prac 7b 
# Run first 2 lines separately as it is creating one session

from pyspark.context import SparkContext

sc = SparkContext("local","iris")

# Find & initialize PySpark Home Variable
iris1 = sc.textFile("iris.csv",2)  # 2 partitions to be made while import

# Retrieve records from dataset
iris1.collect()

partitioned_data = iris1.glom().collect()

for i, partition in enumerate(partitioned_data):
    print(f"Partition {i+1} has {len(partition)} records")

iris2 = sc.parallelize(iris1.collect(),8)

iris2.getNumPartitions()

str_to_igr = 'Id,SepalLengthCm,SepalWidthCm,PetalLengthCm,PetalWidthCm,Species'

iris2 = iris2.filter(lambda x: x != str_to_igr)

iris2.collect()

header = iris2.first()

iris2 = iris2.filter(lambda x: x != header)

iris2.collect()

iris3 = iris2.map(lambda x: x*2)

iris3.collect()

iris4 = iris2.flatMap(lambda x: x.split(','))

iris4.collect()

partitions = iris4.glom().collect()

print("Total Partitions:", len(partitions))

partitions[0]

iris5 = iris4.map(lambda x: x*2)

iris4.take(5)

iris6 = iris1.flatMap(lambda x: x.split(',')) \
             .filter(lambda x: x == 'virginica') \
             .map(lambda x: (x,1))

partitions = iris6.glom().collect()

partitions

species = ['virginica','setosa','versicolor']

species1 = iris1.flatMap(lambda x: x.split(',')) \
                .filter(lambda x: x in species)

species1.collect()

species2 = species1.groupBy(lambda x: x).mapValues(len)

species2.collect()

"""
    return code
