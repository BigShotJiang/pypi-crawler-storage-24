def template():
    code = """
prac 3

replace in zookeeper.properties in config folder
‘dataDir=\tmp\zookeeper-data’ with ‘dataDir=C:\kafka\zookeeper-data’
replace in server.properties in config
‘log.dirs=\tmp\kafka-logs’ with ‘log.dirs=C:\kafka\kafka-logs’
powershell \kafka folder
.\bin\windows\zookeeper-server-start.bat .\config\zookeeper.properties
.\bin\windows\kafka-server-start.bat .\config\server.properties
cmd kafka\bin\windows\  folder
kafka-topics.bat –create –bootstrap-server localhost:9092 –replication-factor 1 –partitions 1 –topic test
kafka-console-producer.bat –broker-list localhost:9092 –topic test
kafka-console-consumer.bat –bootstrap-server localhost:9092 –topic test –from-beginning
"""
    return code
