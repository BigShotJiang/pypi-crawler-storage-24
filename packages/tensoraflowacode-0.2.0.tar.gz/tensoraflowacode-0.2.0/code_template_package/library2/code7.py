def template():
    code = """
PRACTICAL 5
Aim: Simulating Data Warehouse Environment using Hive Application

Step 1: Start Hive
Command:
hive
Step 2: Create database college1
Commands:
create database college1;
use college1;
Step 3: Create table student
Command:
create table student(
roll_no int,
name string,
course string,
marks float
)
row format delimited
fields terminated by ',';
Step 4: Display tables
Command:
show tables;
Step 5: Create text file for student data
exit hive
exit;
gedit studentdata1.txt
Example content of studentdata1.txt
1,ariel,msc dsai,90
2,ronny,msc dsai,80
3,sammy,msc dsai,70

Step 6: Create directory in HDFS and upload file
Commands:
hdfs dfs -mkdir /hadoop1
hdfs dfs -mkdir /hadoop1/data
hdfs dfs -put studentdata1.txt /hadoop1/data
hdfs dfs -ls

Step 7: Load data from HDFS into Hive table
open hive
hive
use college1;
Command:
load data inpath '/hadoop1/data/studentdata1.txt' into table student;

Step 8: Display data in table
Command:
select * from student;
----------for local import ----------------
Step 9: Create another database and table
Commands:
create database licdw;
use licdw;

create table customer(
id int,
name string,
dob string,
contactno string,
address string,
gender string
)
row format delimited
fields terminated by ',';

exit hive
exit;
gedit licdata.csv
Step 10: Load CSV file into table
ammy,4/5/6,435345,fsdff,f
Command:
load data local inpath '/home/cloudera/licdata.csv' into table customer;

Step 11: Display data
Command:
select * from customer;

"""
    return code
