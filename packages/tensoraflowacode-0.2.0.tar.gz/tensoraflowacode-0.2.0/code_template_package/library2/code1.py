def template():
    code = """
pip install pandas
pip install requests
pip install beautifulsoup4
pip install lxml


import pandas as pd
from bs4 import BeautifulSoup
import requests as rs
import re

url="https://www.worldometers.info/world-population/population-by-country/"

src=rs.get(url)

soup=BeautifulSoup(src.content,features='lxml')

t1=soup.find('table')

cols=[]
t_head=t1.find('thead')

for tr in t_head.find_all('tr'):
    cols.append(tr.text)

cols = re.split(r'\s{2,}', cols[0].strip())

t_body=t1.find('tbody')
t_rows=t_body.find_all('tr')

d1=[]

for row in t_rows:
    data=[]
    for row_data in row.find_all('td'):
        data.append(row_data.text)
    d1.append(data)

df1=pd.DataFrame(data=d1,columns=cols)

df1.to_csv('output.csv')
"""
    return code
