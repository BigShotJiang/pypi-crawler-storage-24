def template():
    code = """
PRACTICAL 6A
Aim: Working with different types of tables in Hive

Step 1: Start Hive and create database
Commands:
hive
show databases;
create database licdw;
use licdw;

Step 2: Create internal table
Command:
create table customer(
id int,
name string,
dob string,
email string,
contactno string,
address string,
gender string
)
row format delimited
fields terminated by ',';

Step 3: Show tables
Command:
show tables;

Step 4: Describe table structure
Command:
describe customer;

Step 5: Load data into internal table
Command:
load data local inpath '/home/cloudera/customer.csv' into table customer;

Step 6: Display data
Command:
select * from customer;

Step 7: Create external table
Command:
create external table policy_details(
id int,
name string,
age_criteria int,
tenure int,
maturity string
)
row format delimited
fields terminated by ','
stored as textfile
location '/home/cloudera/';

Step 8: Load data into external table
Command:
load data local inpath '/home/cloudera/policy_details.csv' into table policy_details;

Step 9: Display table data
Command:
select * from policy_details;

exit;  not sure
hdfs dfs -cat hdfs://quickstart.cloudera:8020/home/cloudera/policy_details.csv


Step 14: Create temporary table
Command:
create temporary table policy_temp(
id int,
name string,
tenure int
);

Step 15: Insert values
Command:
insert into policy_temp values(1,'abc',5);

Step 16: Display temporary table
Command:
select * from policy_temp;
show tables;
exit;
hive
use licdw;
show tables;


Step 10: Create table using SELECT
Command:
create table policy_details_dup as select * from policy_details;

Step 11: Display duplicated table data
Command:
select * from policy_details_dup;

Step 12: Create table using LIKE
Command:
create table policy_details_like like policy_details;

Step 13: Describe table
Command:
describe policy_details_like;
"""
    return code
