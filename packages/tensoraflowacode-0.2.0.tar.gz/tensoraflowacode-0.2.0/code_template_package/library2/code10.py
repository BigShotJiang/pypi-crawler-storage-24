def template():
    code = """
prac7 
pip install pyspark==3.5.0

JAVA_HOME = C:\Program Files\Java\jdk1.8.0_221
path new %JAVA_HOME%\bin
PYSPARK_DRIVER_PYTHON = where python
PYSPARK_PYTHON = where python

from pyspark.sql import SparkSession
from pyspark.context import SparkContext
spark=SparkSession.builder.master("local[*]").appName('myapp').getOrCreate()
sc=spark.sparkContext
rdd=sc.parallelize([1,2,3,4,5])
rdd_squared=rdd.map(lambda x:x*x)
print(rdd_squared.collect())

spark.stop()
"""
    return code
