# Code Template Package

A professional Python package containing 1 library with 10 code templates. This package is designed to be installed via pip and used in any Python environment or Jupyter Notebook.

## Installation

You can install this package using pip:

```bash
pip install code_template_package
```

Or, if installing from source:

```bash
pip install -e .
```

## Quick Start

### Basic Usage

Import and use a library template:

```python
from code_template_package import library1

# Call the template function
print(library1.code1())
```

### Using in Jupyter Notebook

```python
from code_template_package import library1, library2

# Access templates from the libraries
template_code = library1.code1()
print(template_code)

# You can access all templates from library1 (10 templates)
template_code2 = library1.code5()
template_code3 = library1.code10()

# Access library2 templates (15 templates)
template_code4 = library2.code1()
template_code5 = library2.code8()
template_code6 = library2.code15()
```

### Available Libraries

- **library1**: Contains templates code1 through code10
- **library2**: Contains templates code1 through code15

Each template is accessible as a function that returns the template code string.

## Usage Examples

```python
from code_template_package import library1, library2

# Get templates from library1
template = library1.code1()
template2 = library1.code3()

# Get templates from library2
template3 = library2.code1()  # Data Preprocessing with Pandas
template4 = library2.code6()  # K-Means Clustering
template5 = library2.code15() # Hyperparameter Tuning
```

## Package Structure

```
code_template_package/
├── code_template_package/
│   ├── __init__.py
│   ├── library1/
│   │   ├── __init__.py
│   │   ├── code1.py
│   │   ├── code2.py
│   │   ├── ... (code3.py to code10.py)
├── pyproject.toml
├── README.md
└── LICENSE
│   ├── library2/
│   │   ├── __init__.py
│   │   ├── code1.py
│   │   ├── code2.py
│   │   ├── ... (code3.py to code15.py)
```

## Requirements

- Python >= 3.8

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

For issues and questions, please open an issue on the GitHub repository.
