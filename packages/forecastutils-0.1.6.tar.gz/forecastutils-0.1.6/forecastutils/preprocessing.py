
from sklearn.base import BaseEstimator, TransformerMixin
import pandas as pd

class MonthBinaryEncoder(BaseEstimator, TransformerMixin):
    def __init__(self, date_column:str):
        self.date_column = date_column
        self.month_names = [
            'janvier', 'fevrier', 'mars', 'avril', 'mai', 'juin',
            'juillet', 'aout', 'septembre', 'octobre', 'novembre', 'decembre'
        ]

    def fit(self, X, y=None):
        return self  # Pas d'apprentissage nécessaire

    def transform(self, X):
        X_ = X.copy()
        if not pd.api.types.is_datetime64_any_dtype(X_[self.date_column]):
            X_[self.date_column] = pd.to_datetime(X_[self.date_column])

        # Extraire le mois et créer les colonnes binaires
        for i, name in enumerate(self.month_names, start=1):
            X_[f'is_{name}'] = X_[self.date_column].dt.month == i

        return X_

class MonthlyCumulativeSalesTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, date_column='date', value_column='sales'):
        self.date_column = date_column
        self.value_column = value_column
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X_copy = X.copy()
        X_copy[self.date_column] = pd.to_datetime(X_copy[self.date_column])
        X_copy['year_month'] = X_copy[self.date_column].dt.to_period('M')
        X_copy.sort_values(by=self.date_column, inplace=True)
        X_copy['monthly_cumulative_sales'] = X_copy.groupby('year_month')[self.value_column].cumsum()
        X_copy.drop(columns=['year_month'], inplace=True)
        return X_copy

class MonthlySumLagTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, date_col: str, value_col: str, lags: list[int], fillna: bool = True):
        self.date_col = date_col
        self.value_col = value_col
        self.lags = lags
        self.fillna = fillna

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        df = X.copy()
        df[self.date_col] = pd.to_datetime(df[self.date_col])
        df['month'] = df[self.date_col].dt.to_period('M').dt.to_timestamp()

        # Agrégation mensuelle
        monthly = df.groupby('month')[self.value_col].sum().reset_index()
        monthly.columns = ['month', f'{self.value_col}_monthly_sum']

        # Ajout des lags
        for lag in self.lags:
            lagged = monthly.copy()
            lagged['month'] += pd.DateOffset(months=lag)
            lagged.columns = ['month', f'{self.value_col}_monthly_sum_lag{lag}']
            df = df.merge(lagged, on='month', how='left')

        # Ajout de la valeur agrégée actuelle
        df = df.merge(monthly, on='month', how='left')

        if self.fillna:
            df.fillna(value=pd.NA, inplace=True)

        return df.drop(columns=['month', f'{self.value_col}_monthly_sum'])

class MovingAverageDeltaTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, date_column:str, value_column:str, window_pairs:list[tuple]=[(7, 28)]):
        self.date_column = date_column
        self.value_column = value_column
        self.window_pairs = window_pairs

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X_ = X.copy()
        X_[self.date_column] = pd.to_datetime(X_[self.date_column])
        X_.sort_values(by=self.date_column, inplace=True)

        # Calcul des moyennes mobiles
        for short_win, long_win in self.window_pairs:
            short_ma = X_[self.value_column].rolling(window=short_win, min_periods=1).mean()
            long_ma = X_[self.value_column].rolling(window=long_win, min_periods=1).mean()
            delta = short_ma - long_ma
            col_name = f'delta_ma_{short_win}_{long_win}'
            X_[col_name] = delta

        return X_

class RemainingWeekdaysInMonthTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, date_column: str):
        self.date_column = date_column

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X_ = X.copy()
        X_[self.date_column] = pd.to_datetime(X_[self.date_column])

        weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

        def count_remaining_weekdays_excluding_today(date):
            end_of_month = date + pd.offsets.MonthEnd(0)
            remaining_dates = pd.date_range(start=date + pd.Timedelta(days=1), end=end_of_month)
            counts = {day: 0 for day in weekdays}
            for d in remaining_dates:
                day_name = d.day_name()
                counts[day_name] += 1
            return pd.Series(counts)

        weekday_counts = X_[self.date_column].apply(count_remaining_weekdays_excluding_today)
        X_ = pd.concat([X_, weekday_counts], axis=1)

        return X_

class SameWeekdayLastYearTransformer(BaseEstimator, TransformerMixin):
    """
    Transformer sklearn qui ajoute une colonne avec la valeur d'une année précédente
    pour le même jour de la semaine (même semaine ISO).
    
    Robuste aux années bissextiles.
    
    Parameters:
    -----------
    date_col : str
        Nom de la colonne contenant les dates
    value_col : str
        Nom de la colonne contenant les valeurs à décaler
    groupby_cols : list of str, default=['Enseigne']
        Colonnes pour grouper (ex: ['Enseigne'], ['Pays_code', 'Enseigne'])
    year_lag : int, default=1
        Nombre d'années de décalage (1 pour Y-1, 2 pour Y-2, etc.)
    output_col : str, optional
        Nom de la colonne de sortie. Si None, utilise f"{value_col}_Y-{year_lag}"
    keep_iso_columns : bool, default=False
        Si True, conserve les colonnes Year, Week, Weekday temporaires
    
    Attributes:
    -----------
    feature_names_in_ : list
        Noms des colonnes en entrée
    
    Examples:
    ---------
    >>> # Pour Y-1
    >>> transformer = SameWeekdayLastYearTransformer(
    ...     date_col='DateVteInitialString',
    ...     value_col='NbVentes',
    ...     groupby_cols=['Enseigne'],
    ...     year_lag=1
    ... )
    >>> df_transformed = transformer.fit_transform(df)
    
    >>> # Pour Y-2
    >>> transformer = SameWeekdayLastYearTransformer(
    ...     date_col='DateVteInitialString',
    ...     value_col='NbVentes',
    ...     groupby_cols=['Enseigne'],
    ...     year_lag=2
    ... )
    >>> df_transformed = transformer.fit_transform(df)
    """
    
    def __init__(self, date_col, value_col, groupby_cols=None, 
                 year_lag=1, output_col=None, keep_iso_columns=False):
        self.date_col = date_col
        self.value_col = value_col
        self.groupby_cols = groupby_cols if groupby_cols is not None else ['Enseigne']
        self.year_lag = year_lag
        self.output_col = output_col if output_col is not None else f"{value_col}_Y-{year_lag}"
        self.keep_iso_columns = keep_iso_columns
    
    def fit(self, X, y=None):
        """
        Fit du transformer (ne fait rien, juste pour compatibilité sklearn).
        
        Parameters:
        -----------
        X : pd.DataFrame
            DataFrame d'entrée
        y : array-like, optional
            Ignoré, présent pour compatibilité sklearn
            
        Returns:
        --------
        self
        """
        # Vérifier que les colonnes existent
        if not isinstance(X, pd.DataFrame):
            raise ValueError("X doit être un pandas DataFrame")
        
        required_cols = [self.date_col, self.value_col] + self.groupby_cols
        missing_cols = [col for col in required_cols if col not in X.columns]
        
        if missing_cols:
            raise ValueError(f"Colonnes manquantes dans X: {missing_cols}")
        
        # Stocker les noms des colonnes
        self.feature_names_in_ = X.columns.tolist()
        
        return self
    
    def transform(self, X):
        """
        Transforme le DataFrame en ajoutant la colonne N-year_lag.
        
        Parameters:
        -----------
        X : pd.DataFrame
            DataFrame d'entrée
            
        Returns:
        --------
        X_transformed : pd.DataFrame
            DataFrame avec la nouvelle colonne
        """
        # Copier pour ne pas modifier l'original
        X_transformed = X.copy()
        
        # S'assurer que la date est en datetime
        X_transformed[self.date_col] = pd.to_datetime(X_transformed[self.date_col])
        
        # Ajouter les colonnes ISO temporaires
        X_transformed['_Year_ISO'] = X_transformed[self.date_col].dt.isocalendar().year
        X_transformed['_Week_ISO'] = X_transformed[self.date_col].dt.isocalendar().week
        X_transformed['_Weekday_ISO'] = X_transformed[self.date_col].dt.dayofweek
        
        # Créer le DataFrame N-year_lag (années précédentes)
        merge_cols = self.groupby_cols + ['_Year_ISO', '_Week_ISO', '_Weekday_ISO']
        
        df_prev = X_transformed[merge_cols + [self.value_col]].copy()
        df_prev['_Year_ISO'] = df_prev['_Year_ISO'] + self.year_lag  # Décaler de year_lag années
        df_prev = df_prev.rename(columns={self.value_col: self.output_col})
        
        # Merge pour récupérer les valeurs N-year_lag
        X_transformed = X_transformed.merge(
            df_prev,
            on=merge_cols,
            how='left'
        )
        
        # Nettoyer les colonnes temporaires si demandé
        if not self.keep_iso_columns:
            X_transformed = X_transformed.drop(
                columns=['_Year_ISO', '_Week_ISO', '_Weekday_ISO']
            )
        else:
            # Renommer pour être plus explicites
            X_transformed = X_transformed.rename(columns={
                '_Year_ISO': 'Year_ISO',
                '_Week_ISO': 'Week_ISO',
                '_Weekday_ISO': 'Weekday_ISO'
            })
        
        return X_transformed
    
