"""caprail migrate fresh"""
from __future__ import annotations
import asyncio
from pathlib import Path
import typer
from rich.console import Console

console = Console()

def command(
    path: str = typer.Option("database/migrations", "--path"),
    seed: bool = typer.Option(False, "--seed", help="Run seeders after migration"),
) -> None:
    """Drop all tables and re-run all migrations."""
    async def _run():
        from caprail.console.commands.migrate_cmd import _load_app
        _load_app()
        from caprail.orm.model import _engine
        from caprail.orm.migrations import Migrator
        migrator = Migrator(_engine)
        applied = await migrator.fresh(Path(path))
        for name in applied:
            console.print(f"[green]Migrated:[/] {name}")
    asyncio.run(_run())
