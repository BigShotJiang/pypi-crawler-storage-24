"""caprail make request <Name>"""
from __future__ import annotations
from pathlib import Path
import typer
from rich.console import Console

console = Console()

TEMPLATE = '''"""
{name} form request.
"""
from __future__ import annotations

from caprail.http.form_request import FormRequest


class {name}(FormRequest):

    def authorize(self) -> bool:
        return True

    def rules(self) -> dict:
        return {{
            # "field": "required|string|max:255",
        }}
'''

def command(name: str = typer.Argument(..., help="Request class name")) -> None:
    """Generate a new form request class."""
    if not name.endswith("Request"):
        name += "Request"
    dest = Path.cwd() / "app" / "Http" / "Requests" / f"{name}.py"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        console.print(f"[yellow]Request already exists:[/] {dest}")
        raise typer.Exit(1)
    dest.write_text(TEMPLATE.format(name=name))
    console.print(f"[green]Form request created:[/] {dest}")
