"""caprail make provider <Name>"""
from __future__ import annotations
from pathlib import Path
import typer
from rich.console import Console

console = Console()

TEMPLATE = '''"""
{name} service provider.
"""
from __future__ import annotations

from caprail.foundation.service_provider import ServiceProvider


class {name}(ServiceProvider):

    def register(self) -> None:
        """Register bindings in the container."""

    def boot(self) -> None:
        """Bootstrap application services."""
'''

def command(name: str = typer.Argument(..., help="Provider class name")) -> None:
    """Generate a new service provider."""
    if not name.endswith("ServiceProvider"):
        name += "ServiceProvider"
    dest = Path.cwd() / "app" / "Providers" / f"{name}.py"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        console.print(f"[yellow]Provider already exists:[/] {dest}")
        raise typer.Exit(1)
    dest.write_text(TEMPLATE.format(name=name))
    console.print(f"[green]Service provider created:[/] {dest}")
