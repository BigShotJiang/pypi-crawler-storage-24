"""caprail migrate status"""
from __future__ import annotations
import asyncio
from pathlib import Path
import typer
from rich.console import Console
from rich.table import Table

console = Console()

def command(
    path: str = typer.Option("database/migrations", "--path"),
) -> None:
    """Show the status of each migration."""
    async def _run():
        from caprail.console.commands.migrate_cmd import _load_app
        _load_app()
        from caprail.orm.model import _engine
        from caprail.orm.migrations import Migrator
        migrator = Migrator(_engine)
        await migrator.install()
        ran = await migrator._get_ran()
        classes = await migrator._load_migration_classes(Path(path))
        table = Table(title="Migration Status")
        table.add_column("Migration", style="cyan")
        table.add_column("Status", style="bold")
        for name in sorted(classes.keys()):
            status = "[green]Ran[/]" if name in ran else "[yellow]Pending[/]"
            table.add_row(name, status)
        console.print(table)
    asyncio.run(_run())
