"""HTTP exceptions."""
from __future__ import annotations


class HttpException(Exception):
    def __init__(self, status: int, message: str = "") -> None:
        self.status = status
        self.message = message
        super().__init__(message)
