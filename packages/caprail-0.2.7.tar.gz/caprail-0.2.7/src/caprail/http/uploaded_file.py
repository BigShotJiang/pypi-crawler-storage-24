"""Uploaded file wrapper."""
from __future__ import annotations

import os
import aiofiles


class UploadedFile:
    """Represents a file uploaded via a multipart form."""

    def __init__(self, filename: str, content_type: str, content: bytes) -> None:
        self.filename = filename
        self.content_type = content_type
        self._content = content

    @property
    def size(self) -> int:
        return len(self._content)

    async def read(self) -> bytes:
        return self._content

    async def store(self, path: str) -> None:
        """Save the file to the given absolute path."""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        async with aiofiles.open(path, "wb") as f:
            await f.write(self._content)

    def __repr__(self) -> str:
        return f"<UploadedFile {self.filename!r} ({self.size} bytes)>"
