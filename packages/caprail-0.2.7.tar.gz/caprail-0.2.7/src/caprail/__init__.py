"""
Caprail — the Laravel-inspired Python web framework.

Quick start::

    from caprail import Application
    from caprail.http import Response
    from caprail.routing import Router

    app = Application()

    @app.router.get("/")
    async def home(request):
        return Response("Hello, Caprail!")

    application = app.make_asgi()
"""
from caprail.application import Application
from caprail.http.request import Request
from caprail.http.response import Response, StreamingResponse, FileResponse
from caprail.http.middleware import Middleware, Pipeline
from caprail.http.exceptions import HttpException
from caprail.foundation.container import Container, BindingResolutionError
from caprail.foundation.service_provider import ServiceProvider
from caprail.routing.router import Router, Route
from caprail.view.engine import ViewEngine
from caprail.orm.model import Model, configure_database
from caprail.orm.migrations import Migration, Schema, Blueprint
from caprail.auth.auth_manager import Auth

__version__ = "0.1.0"

__all__ = [
    "Application",
    "Request",
    "Response",
    "StreamingResponse",
    "FileResponse",
    "Middleware",
    "Pipeline",
    "HttpException",
    "Container",
    "BindingResolutionError",
    "ServiceProvider",
    "Router",
    "Route",
    "ViewEngine",
    "Model",
    "configure_database",
    "Migration",
    "Schema",
    "Blueprint",
    "Auth",
]
