"""WebSocket communication tests."""
