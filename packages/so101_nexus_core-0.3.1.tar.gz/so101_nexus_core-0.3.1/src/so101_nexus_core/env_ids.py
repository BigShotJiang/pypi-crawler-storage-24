"""Helpers for SO101-Nexus Gymnasium environment IDs."""

from __future__ import annotations


def all_registered_env_ids() -> list[str]:
    """Return a list of all registered SO101-Nexus environment IDs."""
    return [
        "MuJoCoPickLift-v1",
        "MuJoCoPickAndPlace-v1",
        "MuJoCoReach-v1",
        "MuJoCoLookAt-v1",
        "MuJoCoMove-v1",
        "ManiSkillPickLiftSO100-v1",
        "ManiSkillPickLiftSO101-v1",
        "ManiSkillReachSO100-v1",
        "ManiSkillReachSO101-v1",
        "ManiSkillLookAtSO100-v1",
        "ManiSkillLookAtSO101-v1",
        "ManiSkillMoveSO100-v1",
        "ManiSkillMoveSO101-v1",
    ]
