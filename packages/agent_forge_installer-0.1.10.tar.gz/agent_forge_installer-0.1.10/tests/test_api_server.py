from __future__ import annotations

import json
import os
import sqlite3

from fastapi.testclient import TestClient

from agentforge.api_server import create_app
from agentforge.conversation_store import ConversationStore


def _auth_headers() -> dict[str, str]:
    return {"Authorization": "Bearer secret-token"}


def _make_store(tmp_root) -> ConversationStore:
    return ConversationStore(str(tmp_root / "data" / "conversations.db"))


def _build_app(tmp_root, config_file, store: ConversationStore, mirror_message_fn=None):
    os.environ["AGENTFORGE_API_KEY"] = "secret-token"

    def fake_invoke_claude(**kwargs):
        return f"reply:{kwargs['user_text']}"

    kwargs = dict(
        config_path=config_file,
        store=store,
        invoke_claude_fn=fake_invoke_claude,
    )
    if mirror_message_fn is not None:
        kwargs["mirror_message_fn"] = mirror_message_fn
    return create_app(**kwargs)


def test_health_requires_bearer_token(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/api/health")

    assert response.status_code == 401


def test_list_agents_and_channels(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    agents = client.get("/api/agents", headers=_auth_headers())
    channels = client.get("/api/channels", headers=_auth_headers())

    assert agents.status_code == 200
    assert sorted(agent["id"] for agent in agents.json()["agents"]) == sorted(["clawdia", "victor", "archie"])
    assert channels.status_code == 200
    assert any(channel["id"] == "11" for channel in channels.json()["channels"])
    assert any(channel["id"] == "16" for channel in channels.json()["channels"])


def test_create_topic_persists_project_topic(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.post(
        "/api/channels/topics",
        headers=_auth_headers(),
        json={"name": "Ops", "label": "Ops"},
    )

    assert response.status_code == 200
    payload = response.json()["channel"]
    assert payload["name"] == "Ops"
    assert payload["type"] == "project_topic"

    saved = json.loads((tmp_root / "bot" / "config.json").read_text())
    created = saved["project_topics"][payload["id"]]
    assert created["name"] == "Ops"
    assert created["label"] == "Ops"
    assert created["default_agent"] == "clawdia"
    assert created["agents"] == ["clawdia", "victor", "archie"]


def test_monitoring_status_endpoint_returns_snapshot(tmp_root, config_file):
    (tmp_root / "logs" / "heartbeat.log").write_text("[2026-03-19 00:00:00] Heartbeat starting\n")
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/api/monitoring/status", headers=_auth_headers())

    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] in {"ok", "error"}
    assert payload["checked_at"]
    assert isinstance(payload["services"], list)
    assert any(service["id"] == "cron" for service in payload["services"])


def test_monitoring_agents_endpoint_returns_agent_heartbeats(tmp_root, config_file):
    agent_dir = tmp_root / "agents" / "clawdia"
    (agent_dir / "daily").mkdir(parents=True)
    (agent_dir / "soul.md").write_text("# soul")
    (agent_dir / "memory.md").write_text("# memory")
    (tmp_root / "logs" / "actions.log").write_text(
        "[2026-03-19 09:30] clawdia | git_push | github | synced\n"
    )
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/api/monitoring/agents", headers=_auth_headers())

    assert response.status_code == 200
    payload = response.json()
    assert payload["checked_at"]
    clawdia = next(agent for agent in payload["agents"] if agent["name"] == "clawdia")
    assert clawdia["last_heartbeat_at"] == "2026-03-19T09:30:00Z"
    assert clawdia["has_soul"] is True
    assert clawdia["has_memory"] is True


def test_agents_endpoints_return_details_and_documents(tmp_root, config_file):
    agent_dir = tmp_root / "agents" / "clawdia"
    (agent_dir / "daily").mkdir(parents=True)
    (agent_dir / "soul.md").write_text("# Soul")
    (agent_dir / "memory.md").write_text("# Memory")
    (agent_dir / "daily" / "2026-03-19.md").write_text("# Day")
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    agents_response = client.get("/api/agents", headers=_auth_headers())
    detail_response = client.get("/api/agents/clawdia", headers=_auth_headers())
    document_response = client.get("/api/agents/clawdia/documents/soul", headers=_auth_headers())
    daily_list_response = client.get("/api/agents/clawdia/daily", headers=_auth_headers())
    daily_note_response = client.get("/api/agents/clawdia/daily/2026-03-19.md", headers=_auth_headers())

    assert agents_response.status_code == 200
    assert any(agent["name"] == "clawdia" for agent in agents_response.json()["agents"])

    assert detail_response.status_code == 200
    detail = detail_response.json()["agent"]
    assert detail["files"]["soul"]["exists"] is True
    assert detail["files"]["memory"]["exists"] is True
    assert detail["daily_notes"][0]["name"] == "2026-03-19.md"
    assert any(job["id"] == "memory-consolidation" for job in detail["cron_jobs"])

    assert document_response.status_code == 200
    assert document_response.json()["content"] == "# Soul"

    assert daily_list_response.status_code == 200
    assert daily_list_response.json()["notes"][0]["name"] == "2026-03-19.md"

    assert daily_note_response.status_code == 200
    assert daily_note_response.json()["content"] == "# Day"


def test_agents_endpoints_save_documents(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    soul_response = client.post(
        "/api/agents/clawdia/documents/soul",
        headers=_auth_headers(),
        json={"content": "# Updated soul"},
    )
    daily_response = client.post(
        "/api/agents/clawdia/daily/2026-03-20.md",
        headers=_auth_headers(),
        json={"content": "# Day note"},
    )

    assert soul_response.status_code == 200
    assert daily_response.status_code == 200
    assert (tmp_root / "agents" / "clawdia" / "soul.md").read_text() == "# Updated soul"
    assert (tmp_root / "agents" / "clawdia" / "daily" / "2026-03-20.md").read_text() == "# Day note"


def test_get_messages_supports_before_cursor(tmp_root, config_file):
    store = _make_store(tmp_root)
    store.save_message(
        "api-channel-11",
        "user",
        "old",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
        timestamp="2026-03-14 09:00:00",
    )
    store.save_message(
        "api-channel-11",
        "assistant",
        "newer",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
        timestamp="2026-03-14 10:00:00",
    )
    store.save_message(
        "tg--100123456-t11",
        "assistant",
        "telegram",
        source="telegram",
        metadata={"channel": "11", "agent": "clawdia"},
        timestamp="2026-03-14 11:00:00",
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.get(
        "/api/messages",
        headers=_auth_headers(),
        params={"channel": "11", "before": "2026-03-14 11:00:00", "limit": 10},
    )

    assert response.status_code == 200
    contents = [message["content"] for message in response.json()["messages"]]
    assert contents == ["newer", "old"]


def test_get_messages_includes_channel_metadata_entries(tmp_root, config_file):
    store = _make_store(tmp_root)
    store.save_message(
        "external-sync-session",
        "assistant",
        "from metadata channel",
        source="telegram",
        metadata={"channel": "11", "agent": "clawdia"},
        timestamp="2026-03-14 12:00:00",
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.get(
        "/api/messages",
        headers=_auth_headers(),
        params={"channel": "11", "limit": 10},
    )

    assert response.status_code == 200
    contents = [message["content"] for message in response.json()["messages"]]
    assert contents == ["from metadata channel"]


def test_post_messages_persists_exchange(tmp_root, config_file):
    store = _make_store(tmp_root)
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.post(
        "/api/messages",
        headers=_auth_headers(),
        json={"channel": "11", "message": "hello api"},
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["response"]["content"] == "reply:hello api"

    conn = sqlite3.connect(tmp_root / "data" / "conversations.db")
    rows = conn.execute(
        "SELECT role, content, source FROM conversations WHERE session_id = ? ORDER BY id",
        ("api-channel-11",),
    ).fetchall()
    conn.close()
    assert rows == [
        ("user", "hello api", "api"),
        ("assistant", "reply:hello api", "api"),
    ]


def test_websocket_receives_typing_and_message_events(tmp_root, config_file):
    store = _make_store(tmp_root)
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    with client.websocket_connect("/api/ws?token=secret-token&channel=11") as websocket:
        connected = websocket.receive_json()
        assert connected["type"] == "connected"

        response = client.post(
            "/api/messages",
            headers=_auth_headers(),
            json={"channel": "11", "message": "ping"},
        )

        assert response.status_code == 200
        events = [websocket.receive_json() for _ in range(4)]

    event_types = [event["type"] for event in events]
    assert event_types == ["message_created", "typing", "typing", "message_created"]
    assert events[1]["active"] is True
    assert events[2]["active"] is False


def test_post_messages_triggers_telegram_mirror_hook(tmp_root, config_file):
    store = _make_store(tmp_root)
    mirror_calls = []

    def fake_mirror(*, config, channel, message):
        mirror_calls.append((channel, message, bool(config.get("telegram"))))

    app = _build_app(tmp_root, config_file, store, mirror_message_fn=fake_mirror)
    client = TestClient(app)

    response = client.post(
        "/api/messages",
        headers=_auth_headers(),
        json={"channel": "11", "message": "mirror me"},
    )

    assert response.status_code == 200
    assert mirror_calls == [("11", "mirror me", True)]


# ---------------------------------------------------------------------------
# Vault endpoints
# ---------------------------------------------------------------------------


def test_vault_tree_empty_when_no_notes(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/tree", headers=_auth_headers())

    assert response.status_code == 200
    # Inbox folder exists but has no .md files — tree may list the folder or be empty
    tree = response.json()["tree"]
    assert isinstance(tree, list)


def test_vault_tree_lists_notes_and_folders(tmp_root, config_file):
    (tmp_root / "vault" / "Inbox" / "2026-03-17.md").write_text("# Hello")
    (tmp_root / "vault" / "Projects").mkdir()
    (tmp_root / "vault" / "Projects" / "agentforge.md").write_text("# AgentForge")
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/tree", headers=_auth_headers())

    assert response.status_code == 200
    tree = response.json()["tree"]
    names = [node["name"] for node in tree]
    assert "Inbox" in names
    assert "Projects" in names
    inbox = next(n for n in tree if n["name"] == "Inbox")
    assert inbox["type"] == "folder"
    assert any(c["name"] == "2026-03-17.md" for c in inbox["children"])


def test_vault_list_notes(tmp_root, config_file):
    (tmp_root / "vault" / "Inbox" / "today.md").write_text("hello")
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/notes", headers=_auth_headers())

    assert response.status_code == 200
    notes = response.json()["notes"]
    assert len(notes) == 1
    assert notes[0]["path"] == "Inbox/today.md"
    assert notes[0]["name"] == "today.md"
    assert "modified_at" in notes[0]
    assert "size_bytes" in notes[0]


def test_vault_get_note(tmp_root, config_file):
    (tmp_root / "vault" / "Inbox" / "note.md").write_text("# My Note\n\nContent here.")
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/notes/Inbox/note.md", headers=_auth_headers())

    assert response.status_code == 200
    payload = response.json()
    assert payload["path"] == "Inbox/note.md"
    assert payload["content"] == "# My Note\n\nContent here."


def test_vault_get_note_returns_404_for_missing(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/notes/Inbox/missing.md", headers=_auth_headers())

    assert response.status_code == 404


def test_vault_save_note_creates_and_updates(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.post(
        "/vault/notes/Inbox/2026-03-17.md",
        headers=_auth_headers(),
        json={"content": "# New note"},
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["path"] == "Inbox/2026-03-17.md"
    assert "modified_at" in payload
    assert (tmp_root / "vault" / "Inbox" / "2026-03-17.md").read_text() == "# New note"


def test_vault_save_note_creates_intermediate_folders(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.post(
        "/vault/notes/Projects/agentforge/roadmap.md",
        headers=_auth_headers(),
        json={"content": "roadmap"},
    )

    assert response.status_code == 200
    assert (tmp_root / "vault" / "Projects" / "agentforge" / "roadmap.md").read_text() == "roadmap"


def test_vault_path_traversal_blocked(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/notes/../../../etc/passwd", headers=_auth_headers())

    assert response.status_code in (400, 404)


def test_vault_endpoints_require_auth(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    assert client.get("/vault/tree").status_code == 401
    assert client.get("/vault/notes").status_code == 401
    assert client.get("/vault/notes/Inbox/x.md").status_code == 401
    assert client.post("/vault/notes/Inbox/x.md", json={"content": "x"}).status_code == 401


# ---------------------------------------------------------------------------
# Thread reply endpoints
# ---------------------------------------------------------------------------


def test_get_thread_messages_returns_replies(tmp_root, config_file):
    store = _make_store(tmp_root)
    parent = store.save_message(
        "api-channel-11",
        "user",
        "parent message",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
    )
    store.save_message(
        "api-channel-11",
        "assistant",
        "thread reply 1",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
        parent_message_id=parent.id,
    )
    store.save_message(
        "api-channel-11",
        "user",
        "thread reply 2",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
        parent_message_id=parent.id,
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.get(f"/api/messages/{parent.id}/thread", headers=_auth_headers(), params={"channel": "11"})

    assert response.status_code == 200
    messages = response.json()["messages"]
    assert len(messages) == 2
    assert messages[0]["content"] == "thread reply 1"
    assert messages[1]["content"] == "thread reply 2"
    assert all(m["parent_message_id"] == parent.id for m in messages)


def test_get_thread_messages_returns_empty_for_no_replies(tmp_root, config_file):
    store = _make_store(tmp_root)
    parent = store.save_message(
        "api-channel-11",
        "user",
        "lonely message",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.get(f"/api/messages/{parent.id}/thread", headers=_auth_headers(), params={"channel": "11"})

    assert response.status_code == 200
    assert response.json()["messages"] == []


def test_post_message_with_parent_stores_reply(tmp_root, config_file):
    store = _make_store(tmp_root)
    parent = store.save_message(
        "api-channel-11",
        "user",
        "original",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.post(
        "/api/messages",
        headers=_auth_headers(),
        json={"channel": "11", "message": "thread reply", "parent_message_id": parent.id},
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["message"]["parent_message_id"] == parent.id
    assert payload["response"]["parent_message_id"] == parent.id

    thread_response = client.get(f"/api/messages/{parent.id}/thread", headers=_auth_headers(), params={"channel": "11"})
    assert thread_response.status_code == 200
    thread_messages = thread_response.json()["messages"]
    assert len(thread_messages) == 2  # user reply + agent reply


def test_get_messages_excludes_thread_replies_from_main_list(tmp_root, config_file):
    store = _make_store(tmp_root)
    parent = store.save_message(
        "api-channel-11",
        "user",
        "parent",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
    )
    store.save_message(
        "api-channel-11",
        "user",
        "reply (should be hidden)",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
        parent_message_id=parent.id,
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.get("/api/messages", headers=_auth_headers(), params={"channel": "11"})

    assert response.status_code == 200
    contents = [m["content"] for m in response.json()["messages"]]
    assert "parent" in contents
    assert "reply (should be hidden)" not in contents


def test_get_messages_includes_thread_reply_count(tmp_root, config_file):
    store = _make_store(tmp_root)
    parent = store.save_message(
        "api-channel-11",
        "user",
        "parent with replies",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
    )
    store.save_message(
        "api-channel-11",
        "assistant",
        "reply",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
        parent_message_id=parent.id,
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.get("/api/messages", headers=_auth_headers(), params={"channel": "11"})

    assert response.status_code == 200
    messages = response.json()["messages"]
    parent_msg = next(m for m in messages if m["content"] == "parent with replies")
    assert parent_msg["thread_reply_count"] == 1


def test_thread_reply_skips_telegram_mirror(tmp_root, config_file):
    store = _make_store(tmp_root)
    parent = store.save_message(
        "api-channel-11",
        "user",
        "original",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
    )
    mirror_calls = []

    def fake_mirror(*, config, channel, message):
        mirror_calls.append(message)

    app = _build_app(tmp_root, config_file, store, mirror_message_fn=fake_mirror)
    client = TestClient(app)

    client.post(
        "/api/messages",
        headers=_auth_headers(),
        json={"channel": "11", "message": "thread reply", "parent_message_id": parent.id},
    )

    assert mirror_calls == []


def test_get_thread_messages_requires_channel_param(tmp_root, config_file):
    store = _make_store(tmp_root)
    parent = store.save_message(
        "api-channel-11",
        "user",
        "parent",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.get(f"/api/messages/{parent.id}/thread", headers=_auth_headers())

    assert response.status_code == 422


def test_get_thread_messages_rejects_wrong_channel(tmp_root, config_file):
    store = _make_store(tmp_root)
    parent = store.save_message(
        "api-channel-11",
        "user",
        "parent",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.get(f"/api/messages/{parent.id}/thread", headers=_auth_headers(), params={"channel": "16"})

    assert response.status_code == 403


def test_get_thread_messages_404_for_missing_parent(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/api/messages/99999/thread", headers=_auth_headers(), params={"channel": "11"})

    assert response.status_code == 404


def test_post_message_rejects_nonexistent_parent(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.post(
        "/api/messages",
        headers=_auth_headers(),
        json={"channel": "11", "message": "orphan reply", "parent_message_id": 99999},
    )

    assert response.status_code == 404


def test_post_message_rejects_reply_to_reply(tmp_root, config_file):
    store = _make_store(tmp_root)
    parent = store.save_message(
        "api-channel-11",
        "user",
        "root",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
    )
    reply = store.save_message(
        "api-channel-11",
        "user",
        "first reply",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
        parent_message_id=parent.id,
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.post(
        "/api/messages",
        headers=_auth_headers(),
        json={"channel": "11", "message": "nested reply", "parent_message_id": reply.id},
    )

    assert response.status_code == 400


def test_post_message_rejects_reply_to_wrong_channel(tmp_root, config_file):
    store = _make_store(tmp_root)
    parent = store.save_message(
        "api-channel-11",
        "user",
        "root in channel 11",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.post(
        "/api/messages",
        headers=_auth_headers(),
        json={"channel": "16", "message": "cross-channel reply", "parent_message_id": parent.id},
    )

    assert response.status_code == 403
