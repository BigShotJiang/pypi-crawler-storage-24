from __future__ import annotations

from pathlib import Path

from agentforge.claude_runner import MAX_CONTEXT_SECTION_CHARS, invoke_claude


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def test_invoke_claude_loads_clawdia_memory_and_latest_daily(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "memory" / "soul.md", "soul section")
    _write(tmp_path / "memory" / "memory.md", "memory section")
    _write(tmp_path / "memory" / "daily" / "2026-03-17.md", "older daily")
    _write(tmp_path / "memory" / "daily" / "2026-03-18.md", "latest daily")

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd
        captured["kwargs"] = kwargs

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    response = invoke_claude(
        session_id="sess-1",
        user_text="hello",
        thread_cfg={"name": "clawdia", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    assert response == "ok"
    cmd = captured["cmd"]
    prompt_index = cmd.index("--system-prompt") + 1
    assert (
        cmd[prompt_index]
        == "## Soul\nsoul section\n\n## Memory\nmemory section\n\n## Latest Daily Note\nlatest daily"
    )


def test_invoke_claude_routes_named_agent_context(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "agents" / "researcher" / "soul.md", "agent soul")
    _write(tmp_path / "agents" / "researcher" / "memory.md", "agent memory")

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    invoke_claude(
        session_id="sess-2",
        user_text="hello",
        thread_cfg={"name": "researcher", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    prompt_index = cmd.index("--system-prompt") + 1
    assert cmd[prompt_index] == "## Soul\nagent soul\n\n## Memory\nagent memory"


def test_invoke_claude_skips_missing_context_files(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "agents" / "writer" / "soul.md", "writer soul")

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    invoke_claude(
        session_id="sess-3",
        user_text="hello",
        thread_cfg={"name": "writer", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    prompt_index = cmd.index("--system-prompt") + 1
    assert cmd[prompt_index] == "## Soul\nwriter soul"


def test_invoke_claude_caps_large_context_sections(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "agents" / "writer" / "soul.md", "writer soul")
    _write(
        tmp_path / "agents" / "writer" / "memory.md",
        "m" * (MAX_CONTEXT_SECTION_CHARS + 50),
    )

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    invoke_claude(
        session_id="sess-4",
        user_text="hello",
        thread_cfg={"name": "writer", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    prompt_index = cmd.index("--system-prompt") + 1
    expected_memory = "m" * MAX_CONTEXT_SECTION_CHARS
    assert cmd[prompt_index] == f"## Soul\nwriter soul\n\n## Memory\n{expected_memory}"
