"""Submodule for image filtering"""

# from scipy.ndimage import vectorized_filter
from scipy import ndimage
from scipy.signal import medfilt2d
from scipy.stats import median_abs_deviation
import numpy as np
from astropy.io import fits
from astropy.convolution import convolve_fft


def is_square(arr):
    if len(arr.shape) > 2:
        return False
    # elif arr.shape[0] != arr.shape[1]:
    #    return False
    return True


def multiscale_median_transform(image, max_scales=6):
    if not is_square(image):
        raise ValueError("Input image must be square")
    N = image.shape[0]
    J = int(np.log2(N))
    if J > max_scales:
        J = max_scales
    s = 2
    weights = []
    cj = image
    print(f"Decomposing image into {J} scales.")
    for j in range(J):
        print(f"scale {j}, filter {s+1}")
        # c_jp1 = vectorized_filter(image, function=np.median, size=(s, s))
        c_jp1 = medfilt2d(cj, kernel_size=2 * s + 1)
        w_jp1 = cj - c_jp1
        s *= 2
        weights.append(w_jp1)
        cj = c_jp1
    weights.append(cj)
    return weights


def iuwt(image, max_scales):
    c0 = image
    N = image.shape[0]
    J = int(np.log2(N))
    if J > max_scales:
        J = max_scales
    h = (
        np.asarray(
            [
                [1, 4, 6, 4, 1],
                [4, 16, 24, 16, 4],
                [6, 24, 36, 24, 6],
                [4, 16, 24, 16, 4],
                [1, 4, 6, 4, 1],
            ]
        )
        / 16
    )
    cj = image
    weights = []
    for j in range(J):
        c_jp1 = convolve_fft(cj, h, boundary="wrap")
        w_jp1 = cj - c_jp1
        weights.append(w_jp1)
        cj = c_jp1
        weights.append(cj)
        h = insert_zeros_vectorized(h, 2**j)
    return weights


def insert_zeros_vectorized(array, j):
    """
    Inserts j zeros between values in a 2D NumPy array using vectorized operations.

    Parameters:
    array (np.ndarray): Input 2D NumPy array
    j (int): Number of zeros to insert between values

    Returns:
    np.ndarray: New array with j zeros inserted between original values
    """
    if not isinstance(array, np.ndarray) or array.ndim != 2 or j < 0:
        raise ValueError("Input must be a 2D NumPy array and j must be non-negative")

    # Get original dimensions
    rows, cols = array.shape

    # Calculate new dimensions
    new_rows = rows + (rows - 1) * j
    new_cols = cols + (cols - 1) * j

    # Create output array filled with zeros
    result = np.zeros((new_rows, new_cols), dtype=array.dtype)

    # Create index arrays for original values
    row_indices = np.arange(rows) * (j + 1)
    col_indices = np.arange(cols) * (j + 1)

    # Use meshgrid to create 2D index arrays
    row_grid, col_grid = np.meshgrid(row_indices, col_indices, indexing="ij")

    # Assign original values to their new positions
    result[row_grid, col_grid] = array

    return result


def median_wavelet_multiscale_transform(image, max_scales=6):
    N = image.shape[0]
    J = int(np.log2(N))
    if J > max_scales:
        J = max_scales
    s = 2
    t = 5
    weights = []
    cj = image
    print(f"Decomposing image into {J} scales.")
    for j in range(J):
        print(f"scale {j}, filter {s+1}")
        c_jp1 = medfilt2d(cj, kernel_size=2 * s + 1)
        w_jp1 = c_jp1 - cj
        w_jp1 = np.where(
            np.abs(w_jp1) > t * median_abs_deviation(w_jp1) / 0.6745, 0, w_jp1
        )
        cjprime = w_jp1 + c_jp1
        iuwt_weights = iuwt(cjprime, max_scales=j + 1)
        c_jp1_prime = iuwt_weights[-1]
        c_jp1 = c_jp1_prime
        med_wav_coeff_jp1 = cj - c_jp1
        s *= 2
        weights.append(med_wav_coeff_jp1)
    return weights


if __name__ == "__main__":
    import sys
    import matplotlib.pyplot as plt

    d = fits.getdata(sys.argv[1]).squeeze()
    # d = plt.imread("/home/ddkq81/Downloads/ngc2997.gif")[:, :, 0]
    # print(d.shape)
    # images = multiscale_median_transform(d)
    images = median_wavelet_multiscale_transform(d)
    for i in images:
        plt.imshow(i, vmin=0, vmax=1e-3)
        plt.show()
        plt.close()
