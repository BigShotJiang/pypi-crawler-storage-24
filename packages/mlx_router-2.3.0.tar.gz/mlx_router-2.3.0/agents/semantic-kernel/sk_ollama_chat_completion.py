# This example takes the ollama_chat_completion.py as the source example
# but works with the mlx-router local models instead of ollama
# https://github.com/henrybravo/mlx-router

# Copyright (c) Microsoft. All rights reserved.

import asyncio

from openai import AsyncOpenAI

from semantic_kernel.connectors.ai.open_ai import OpenAIChatCompletion
from semantic_kernel.contents.chat_history import ChatHistory
from semantic_kernel.kernel import Kernel

# This concept sample shows how to use the OpenAI connector with
# a local model running in Ollama: https://github.com/ollama/ollama
# A docker image is also available: https://hub.docker.com/r/ollama/ollama
# The default model used in this sample is phi3 due to its compact size.
# At the time of creating this sample, Ollama only provides experimental
# compatibility with the `chat/completions` endpoint:
# https://github.com/ollama/ollama/blob/main/docs/openai.md
# Please follow the instructions in the Ollama repository to set up Ollama.

system_message = """
You are a chat bot. Your name is Mosscap and
you have one goal: figure out what people need.
Your full name, should you need to know it, is
Splendid Speckled Mosscap. You communicate
effectively, but you tend to answer with long
flowery prose.
"""

# local_model="mlx-community/Llama-3.2-3B-Instruct-4bit"
# local_model="deepseek-ai/deepseek-coder-6.7b-instruct"
#local_model="mlx-community/Phi-4-reasoning-plus-6bit"
# local_model="mlx-community/Qwen3-30B-A3B-8bit"
local_model = "mlx-community/gpt-oss-120b-MXFP4-Q8"

kernel = Kernel()

service_id = "local-gpt"

openAIClient: AsyncOpenAI = AsyncOpenAI(
    api_key="sk-key",  # This cannot be an empty string, use a fake key
    base_url="http://localhost:8800/v1",
)
kernel.add_service(OpenAIChatCompletion(service_id=service_id, ai_model_id=local_model, async_client=openAIClient))

chat_completion = kernel.get_service(service_id)

settings = kernel.get_prompt_execution_settings_from_service_id(service_id)
settings.max_tokens = 2000
settings.temperature = 0.7
settings.top_p = 0.8

chat_history = ChatHistory(system_message=system_message)
chat_history.add_user_message("Hi there, who are you?")
chat_history.add_assistant_message("I am Mosscap, a chat bot. I'm trying to figure out what people need")


async def chat() -> bool:
    try:
        user_input = input("User:> ")
    except KeyboardInterrupt:
        print("\n\nExiting chat...")
        return False
    except EOFError:
        print("\n\nExiting chat...")
        return False

    if user_input == "exit":
        print("\n\nExiting chat...")
        return False

    if not user_input.strip():
        return True

    chat_history.add_user_message(user_input)
    response = await chat_completion.get_chat_message_contents(chat_history=chat_history, settings=settings)
    chat_history.add_assistant_message(response[0].content)
    print(f"Mosscap:> {response[0].content}")
    return True


async def main() -> None:
    chatting = True
    while chatting:
        chatting = await chat()


if __name__ == "__main__":
    asyncio.run(main())
