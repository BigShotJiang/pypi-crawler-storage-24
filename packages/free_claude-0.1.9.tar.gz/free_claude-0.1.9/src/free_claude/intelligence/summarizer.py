"""Context summarizer — condenses long conversations to save tokens."""
import json
import urllib.request
import urllib.error
from typing import List, Dict, Optional


class ContextSummarizer:
    """
    Automatically summarizes long conversation histories.

    When the context exceeds a threshold, replaces older messages with a
    compact summary so the agent can continue without hitting token limits.

    Usage:
        summarizer = ContextSummarizer(threshold_chars=200_000)
        if summarizer.should_summarize(messages):
            summary_text = await summarizer.summarize(messages, api_call_fn)
            messages = summarizer.compress(messages, summary_text)
    """

    def __init__(self, threshold_chars: int = 600_000, keep_recent: int = 20):
        """
        Args:
            threshold_chars: Total chars before summarization triggers.
            keep_recent: Number of most recent messages to always keep verbatim.
        """
        self.threshold_chars = threshold_chars
        self.keep_recent = keep_recent

    def total_chars(self, messages: List[Dict]) -> int:
        return sum(len(str(m.get("content", ""))) for m in messages)

    def should_summarize(self, messages: List[Dict]) -> bool:
        """Return True if context is large enough to warrant summarization."""
        return (len(messages) > self.keep_recent + 2 and
                self.total_chars(messages) > self.threshold_chars)

    def build_summary_prompt(self, messages: List[Dict]) -> List[Dict]:
        """Build the messages list to request a summary from the API."""
        to_summarize = messages[:-self.keep_recent] if len(messages) > self.keep_recent else messages

        # Format as readable transcript
        transcript_lines = []
        for m in to_summarize:
            role = m.get("role", "?").upper()
            content = m.get("content", "")
            if isinstance(content, list):
                # Tool results etc.
                content = " ".join(
                    c.get("text", c.get("content", "")) if isinstance(c, dict) else str(c)
                    for c in content
                )
            transcript_lines.append(f"[{role}]: {str(content)[:500]}")

        transcript = "\n".join(transcript_lines)

        return [
            {
                "role": "user",
                "content": (
                    "Please summarize the following conversation transcript concisely. "
                    "Keep key decisions, code changes, facts discovered, and important context. "
                    "Format as bullet points. Be thorough but brief.\n\n"
                    f"TRANSCRIPT:\n{transcript}"
                ),
            }
        ]

    def compress(self, messages: List[Dict], summary: str) -> List[Dict]:
        """
        Replace old messages with a summary message, keeping recent ones verbatim.

        Returns a new (shorter) messages list.
        """
        recent = messages[-self.keep_recent:] if len(messages) >= self.keep_recent else messages
        summary_msg = {
            "role": "user",
            "content": (
                f"[Previous conversation summary]\n{summary}\n\n"
                "[End of summary — continuing from here]"
            ),
        }
        summary_ack = {
            "role": "assistant",
            "content": "Understood, I have the context from our previous conversation.",
        }
        return [summary_msg, summary_ack] + recent

    def summarize(self, messages: List[Dict], api_base: str, token: str,
                  model: str = "claude-haiku-4-5-20251001") -> str:
        """
        Call the API to produce a summary of old messages.
        Uses a cheap/fast model by default to save cost.
        Returns summary text, or empty string on failure.
        """
        summary_messages = self.build_summary_prompt(messages)
        payload = {
            "model": model,
            "max_tokens": 1024,
            "messages": summary_messages,
        }
        try:
            req = urllib.request.Request(
                f"{api_base}/v1/messages",
                data=json.dumps(payload).encode(),
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                    "anthropic-version": "2023-06-01",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read())
            for block in result.get("content", []):
                if block.get("type") == "text":
                    return block["text"]
        except Exception:
            pass
        return ""

    def maybe_compress(self, messages: List[Dict], api_base: str, token: str,
                       model: str = "claude-haiku-4-5-20251001") -> List[Dict]:
        """
        If context is large enough, summarize and compress in one call.
        Returns original messages unchanged if below threshold or on error.
        """
        if not self.should_summarize(messages):
            return messages
        summary = self.summarize(messages, api_base, token, model)
        if not summary:
            return messages
        return self.compress(messages, summary)

    def estimate_token_savings(self, messages: List[Dict], summary: str) -> int:
        """Estimate how many chars will be saved by compression."""
        original = self.total_chars(messages)
        compressed = self.total_chars(self.compress(messages, summary))
        return max(0, original - compressed)


__all__ = ["ContextSummarizer"]
