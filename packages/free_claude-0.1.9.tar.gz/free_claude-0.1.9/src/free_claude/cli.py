"""CLI entry point for free-claude."""
import argparse
import os
import sys

from . import __version__
from .config import MODELS
from .mcp import discover_hfi_plugins, list_hfi_plugins, create_mcp_client


def main():
    parser = argparse.ArgumentParser(
        prog="fclaude",
        description="free-claude: Free Claude AI agent with tools and MCP support",
    )
    parser.add_argument("--version", action="version", version=f"free-claude {__version__}")
    parser.add_argument("-m", "--model", default="default", choices=list(MODELS.keys()),
                        help="Model to use (default: opus4 = claude-opus-4-6)")
    parser.add_argument("-q", "--query", help="Single query (non-interactive mode)")
    parser.add_argument("-s", "--system", help="System prompt")
    parser.add_argument("--mcp", nargs="+", action="append", metavar="ARG",
                        help="Add MCP server: --mcp name command [args...]")
    parser.add_argument("--plugin", action="append", nargs="+", metavar="NAME",
                        help="Enable plugin(s) by name (e.g. --plugin context7 playwright serena)")
    parser.add_argument("--plugins", action="store_true",
                        help="List available claude-hfi plugins and exit")
    parser.add_argument("--cwd", help="Set working directory")
    parser.add_argument("--no-tools", action="store_true", help="Disable built-in tools")
    parser.add_argument("--no-auto-plugins", action="store_true",
                        help="Disable auto-loading of claude-hfi plugins")
    parser.add_argument("--think", action="store_true",
                        help="Enable extended thinking (default budget: 8000 tokens)")
    parser.add_argument("--think-budget", type=int, default=0, metavar="N",
                        help="Extended thinking token budget (enables thinking if > 0)")

    args = parser.parse_args()

    if args.cwd:
        os.chdir(args.cwd)

    # List plugins and exit
    if args.plugins:
        print("\n🔌 Available claude-hfi plugins:")
        list_hfi_plugins()
        print("\nUsage: fclaude --plugin <name>")
        return

    # Parse manual MCP servers
    mcp_servers = {}
    if args.mcp:
        for mcp_args in args.mcp:
            if len(mcp_args) >= 2:
                mcp_servers[mcp_args[0]] = mcp_args[1:]

    # ── Load MCP plugins ─────────────────────────────────────────────────
    # Default plugins loaded on every startup (if available)
    # Disable with: fclaude --no-auto-plugins
    _DEFAULT_PLUGINS = ["playwright", "serena", "context7"]

    # Flatten --plugin args: [[name1, name2], [name3]] → [name1, name2, name3]
    explicit_plugins = []
    if args.plugin:
        explicit_plugins = [name for group in args.plugin for name in group]

    # --no-auto-plugins: skip defaults, only load explicitly requested ones
    if args.no_auto_plugins:
        plugin_names_to_load = explicit_plugins
    else:
        # Merge: explicit overrides default (dedup, explicit wins order)
        plugin_names_to_load = list(dict.fromkeys(explicit_plugins or _DEFAULT_PLUGINS))

    hfi_plugin_clients = []
    available = discover_hfi_plugins()

    # Filter available candidates
    to_load = [n for n in plugin_names_to_load if n in available]
    not_found = [n for n in plugin_names_to_load if n not in available]
    for n in not_found:
        print(f"  ❌ Plugin '{n}' not found. Run: fclaude --plugins")

    if to_load:
        import shutil, threading, contextlib, io as _io, time as _time
        from rich.console import Console as _Console
        from rich.text import Text as _Text
        _con = _Console(highlight=False)

        # Filter out plugins whose command isn't installed
        runnable = []
        for name in to_load:
            cfg = available[name]
            transport = cfg.get("type", "stdio")
            cmd = cfg.get("command", "")
            from .compat import resolve_command
            if transport == "stdio" and cmd and not shutil.which(resolve_command(cmd)):
                _con.print(_Text.assemble(
                    ("  ⚠ ", "yellow"), (f"{name}", "bold"),
                    (f": command '{cmd}' not found", "dim"),
                ))
            else:
                runnable.append((name, cfg))

        if runnable:
            results_lock = threading.Lock()
            loaded = []  # list of (name, client, n_tools)
            failed = []

            def _connect_one(plugin_name, cfg):
                try:
                    client = create_mcp_client(plugin_name, cfg)
                    ok = client.start(verbose=False)
                    with results_lock:
                        if ok:
                            loaded.append((plugin_name, client, len(client.tools)))
                        else:
                            failed.append(plugin_name)
                except Exception as ex:
                    with results_lock:
                        failed.append(f"{plugin_name}({ex})")

            workers = [
                threading.Thread(target=_connect_one, args=(n, c), daemon=True)
                for n, c in runnable
            ]
            for w in workers:
                w.start()

            # Show spinner while connecting (parallel, max 15s)
            names_str = ", ".join(n for n, _ in runnable)
            with _con.status(
                _Text.assemble(
                    ("  🔌 ", "dim"),
                    ("Connecting MCP: ", "dim cyan"),
                    (names_str, "cyan"),
                    ("...", "dim"),
                ),
                spinner="dots",
            ):
                deadline = _time.monotonic() + 15.0
                while any(w.is_alive() for w in workers):
                    if _time.monotonic() > deadline:
                        break
                    _time.sleep(0.05)
            for w in workers:
                w.join(timeout=0.1)

            # Report results
            for name, client, n_tools in loaded:
                _con.print(_Text.assemble(
                    ("  ✓ ", "bold green"),
                    (f"{name}", "bold"),
                    (f" {n_tools} tools", "green"),
                ))
                hfi_plugin_clients.append(client)
            for name in failed:
                _con.print(_Text.assemble(
                    ("  ✗ ", "bold red"), (str(name), "dim"),
                ))

    try:
        from .agent import Agent
        from .core.streaming import DEFAULT_THINKING_BUDGET

        # Resolve thinking budget
        thinking_budget = 0
        if args.think_budget > 0:
            thinking_budget = args.think_budget
        elif args.think:
            thinking_budget = DEFAULT_THINKING_BUDGET

        agent = Agent(
            model=args.model,
            system=args.system,
            mcp_servers=mcp_servers or None,
            mcp_clients=hfi_plugin_clients or None,
            auto_plugins=not args.no_auto_plugins,
            thinking_budget=thinking_budget,
        )

        if args.query:
            # Single query: stream trực tiếp ra stdout
            agent.run(args.query, stream=True)
        else:
            agent.chat()

    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
        sys.exit(0)
    except SystemExit:
        raise
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)


def login_cmd():
    """fclaude-login command."""
    from .auth import is_logged_in, login, refresh_token

    print("🔐 free-claude Login")
    print("=" * 40)

    if is_logged_in():
        print("✅ Already logged in. Attempting to refresh token...")
        try:
            token = refresh_token()
            if token:
                print(f"✅ Token refreshed successfully!")
                print(f"   Token: {token[:30]}...")
                return
        except Exception as e:
            print(f"⚠️  Refresh failed: {e}")
        print("Starting fresh login...")

    try:
        token = login(open_browser=True)
        print(f"\n🎉 Login successful!")
        print(f"   Token: {token[:30]}...")
        print(f"\n💡 Now run: fclaude")
    except KeyboardInterrupt:
        print("\n❌ Login cancelled")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Login failed: {e}")
        sys.exit(1)
