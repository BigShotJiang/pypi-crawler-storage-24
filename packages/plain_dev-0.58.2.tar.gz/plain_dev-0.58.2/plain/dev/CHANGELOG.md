# plain-dev changelog

## [0.58.2](https://github.com/dropseed/plain/releases/plain-dev@0.58.2) (2026-03-10)

### What's changed

- Fixed `AliasManager.is_installed_in_shell()` crashing when `self.shell` is `None` ([f56c6454b164](https://github.com/dropseed/plain/commit/f56c6454b164))
- Used `signal.Signals` enum for signal name lookup in poncho manager instead of raw int keys ([f56c6454b164](https://github.com/dropseed/plain/commit/f56c6454b164))

### Upgrade instructions

- No changes required.

## [0.58.1](https://github.com/dropseed/plain/releases/plain-dev@0.58.1) (2026-03-04)

### What's changed

- Added minimum `plain>=0.113.0` version constraint in dependencies ([217751b866](https://github.com/dropseed/plain/commit/217751b866))

### Upgrade instructions

- No changes required.

## [0.58.0](https://github.com/dropseed/plain/releases/plain-dev@0.58.0) (2026-03-04)

### What's changed

- Dev server now sets `PLAIN_SERVER_ACCESS_LOG_FIELDS` to show a compact set of fields (method, url, status, duration_ms, size) by default ([72a905fbe1c3](https://github.com/dropseed/plain/commit/72a905fbe1c3))
- Removed logging CLI options (`--log-level`, `--log-format`, `--access-log-format`) from dev server invocation, matching the server's new settings-based configuration ([d00dc098b32d](https://github.com/dropseed/plain/commit/d00dc098b32d))

### Upgrade instructions

- Requires plain >= 0.113.0.

## [0.57.1](https://github.com/dropseed/plain/releases/plain-dev@0.57.1) (2026-02-28)

### What's changed

- Fixed dev server crash on macOS where Tailwind would exit immediately after compiling instead of watching for changes, bringing down all other processes ([5b7db81a43da](https://github.com/dropseed/plain/commit/5b7db81a43da))

### Upgrade instructions

- No changes required.

## [0.57.0](https://github.com/dropseed/plain/releases/plain-dev@0.57.0) (2026-02-28)

### What's changed

- `plain dev` no longer prompts for sudo to modify `/etc/hosts` on systems where `*.localhost` already resolves to loopback (e.g., modern macOS and Linux with systemd-resolved) ([a97e244091](https://github.com/dropseed/plain/commit/a97e244091))

### Upgrade instructions

- No changes required.

## [0.56.0](https://github.com/dropseed/plain/releases/plain-dev@0.56.0) (2026-02-25)

### What's changed

- Renamed `PLAIN_DEV_TUNNEL_URL` environment variable to `DEV_TUNNEL_URL` for displaying the tunnel URL in the dev server header ([6154e6ef8693](https://github.com/dropseed/plain/commit/6154e6ef8693))
- Removed unused `default_settings.py` ([73a51a723c64](https://github.com/dropseed/plain/commit/73a51a723c64))

### Upgrade instructions

- Rename `PLAIN_DEV_TUNNEL_URL` to `DEV_TUNNEL_URL` in your `.env` file.

## [0.55.1](https://github.com/dropseed/plain/releases/plain-dev@0.55.1) (2026-02-24)

### What's changed

- Dev server now explicitly passes `--workers 1` to keep single-process behavior after the core server default changed to `auto` ([c38ee93de5b4](https://github.com/dropseed/plain/commit/c38ee93de5b4))

### Upgrade instructions

- No changes required.

## [0.55.0](https://github.com/dropseed/plain/releases/plain-dev@0.55.0) (2026-02-12)

### What's changed

- Refactored pre-commit to use the new `plain check` command, removing duplicated check logic ([430268a12ae2](https://github.com/dropseed/plain/commit/430268a12ae2))
- Custom pre-commit commands configuration moved from `tool.plain.pre-commit.run` to `tool.plain.check.run` in pyproject.toml ([430268a12ae2](https://github.com/dropseed/plain/commit/430268a12ae2))

### Upgrade instructions

- If you have custom commands in `[tool.plain.pre-commit.run]`, move them to `[tool.plain.check.run]`.

## [0.54.2](https://github.com/dropseed/plain/releases/plain-dev@0.54.2) (2026-01-28)

### What's changed

- Converted `plain-dev` and `plain-pre-commit` skills to a single passive `.claude/rules/` file ([512040ac51](https://github.com/dropseed/plain/commit/512040ac51))

### Upgrade instructions

- Run `plain agent install` to update your `.claude/` directory.

## [0.54.1](https://github.com/dropseed/plain/releases/plain-dev@0.54.1) (2026-01-28)

### What's changed

- Added `dev` to the service auto-start allow-list so that database services start automatically when running `plain dev`, which runs preflight checks internally ([4b146a0ae2](https://github.com/dropseed/plain/commit/4b146a0ae2))
- Added Settings section to README ([803fee1ad5](https://github.com/dropseed/plain/commit/803fee1ad5))

### Upgrade instructions

- No changes required.

## [0.54.0](https://github.com/dropseed/plain/releases/plain-dev@0.54.0) (2026-01-22)

### What's changed

- The development server now shows `DeprecationWarning` and `PendingDeprecationWarning` messages by default, helping you catch deprecated code before it breaks in future versions. You can override this by setting your own `PYTHONWARNINGS` environment variable. ([2ca42c6f96](https://github.com/dropseed/plain/commit/2ca42c6f96))

### Upgrade instructions

- No changes required.

## [0.53.0](https://github.com/dropseed/plain/releases/plain-dev@0.53.0) (2026-01-15)

### What's changed

- Service auto-start now uses an allow-list instead of deny-list, only starting services for commands that need the database (`db`, `makemigrations`, `migrate`, `migrations`, `preflight`, `request`, `run`, `shell`, `test`) ([0b11c79656](https://github.com/dropseed/plain/commit/0b11c79656))
- The `plain dev` command now runs `plain agent install` instead of `plain skills --install` to set up AI agent skills and hooks ([fac8673436](https://github.com/dropseed/plain/commit/fac8673436))

### Upgrade instructions

- No changes required

## [0.52.0](https://github.com/dropseed/plain/releases/plain-dev@0.52.0) (2026-01-15)

### What's changed

- Removed the `plain dev debug` command and custom remote pdb debugger since Python 3.14 provides native remote debugging via `python -m pdb -p <pid>` ([db19b5ef00](https://github.com/dropseed/plain/commit/db19b5ef00))
- Replaced `python-dotenv` dependency with a custom bash-compatible `.env` parser that supports variable expansion (`$VAR`), command substitution (`$(command)`), and multiline values ([a9b2dc3e16](https://github.com/dropseed/plain/commit/a9b2dc3e16))

### Upgrade instructions

- If you were using `plain dev debug` for remote debugging, use Python's native `python -m pdb -p <pid>` command instead

## [0.51.0](https://github.com/dropseed/plain/releases/plain-dev@0.51.0) (2026-01-13)

### What's changed

- Dev services auto-start now runs via the runtime setup hook instead of at CLI load time, which prevents services from starting unnecessarily for commands that don't need the runtime like `plain code`, `plain fix`, and `plain scan` ([fc1c8624b6](https://github.com/dropseed/plain/commit/fc1c8624b6))
- Added new `plain-pre-commit` skill for AI assistants to run pre-commit checks when finishing code changes ([d51294ace1](https://github.com/dropseed/plain/commit/d51294ace1))
- Renamed the `plain-check` skill to `plain-lint` to better describe its purpose ([d51294ace1](https://github.com/dropseed/plain/commit/d51294ace1))
- Pre-commit install now uses `uv run plain` instead of just `plain` for better environment consistency ([8104c9b29f](https://github.com/dropseed/plain/commit/8104c9b29f))

### Upgrade instructions

- No changes required

## [0.50.0](https://github.com/dropseed/plain/releases/plain-dev@0.50.0) (2026-01-13)

### What's changed

- Added `--reinstall-ssl` flag to `plain dev` command that redownloads the mkcert binary, reinstalls the CA into the system trust store, and regenerates domain certificates ([04579b74d7](https://github.com/dropseed/plain/commit/04579b74d7))
- Fixed mkcert CA detection to check for CA file existence instead of using the non-existent `mkcert -check` command ([04579b74d7](https://github.com/dropseed/plain/commit/04579b74d7))
- Improved migration output during `plain dev` startup - now shows "✔ Up to date" when no migrations are needed, or "applying" when migrations are being run ([006efae92d](https://github.com/dropseed/plain/commit/006efae92d))
- Converted package-specific AGENTS.md to skills system - `plain dev` now installs skills to `.claude/agents/` instead of generating `.plain/AGENTS.md` ([b592c32cb9](https://github.com/dropseed/plain/commit/b592c32cb9))

### Upgrade instructions

- No changes required

## [0.49.1](https://github.com/dropseed/plain/releases/plain-dev@0.49.1) (2025-12-22)

### What's changed

- Updated type ignore comments for improved compatibility with the ty type checker ([539a706760](https://github.com/dropseed/plain/commit/539a706760))

### Upgrade instructions

- No changes required

## [0.49.0](https://github.com/dropseed/plain/releases/plain-dev@0.49.0) (2025-12-04)

### What's changed

- Improved type annotations in `mkcert.py` and `pdb.py` for better type checker compatibility ([ac1eeb0ea0](https://github.com/dropseed/plain/commit/ac1eeb0ea0))

### Upgrade instructions

- No changes required

## [0.48.0](https://github.com/dropseed/plain/releases/plain-dev@0.48.0) (2025-12-01)

### What's changed

- Pre-commit checks now preserve colored output from subprocesses by setting `FORCE_COLOR=1` ([a56158394b](https://github.com/dropseed/plain/commit/a56158394b))
- Simplified and streamlined the pre-commit check output formatting for improved readability ([b09edfd2a1](https://github.com/dropseed/plain/commit/b09edfd2a1))

### Upgrade instructions

- No changes required

## [0.47.1](https://github.com/dropseed/plain/releases/plain-dev@0.47.1) (2025-11-17)

### What's changed

- The `plain pre-commit install` command is now a separate subcommand that uses `@without_runtime_setup` to avoid loading the full Plain runtime, improving performance and reliability during installation ([cfa4ed2](https://github.com/dropseed/plain/commit/cfa4ed2))

### Upgrade instructions

- Update any scripts or documentation that use `plain pre-commit --install` to use `plain pre-commit install` instead

## [0.47.0](https://github.com/dropseed/plain/releases/plain-dev@0.47.0) (2025-11-12)

### What's changed

- Fixed type errors and warnings for improved type checker compatibility ([f4dbcef](https://github.com/dropseed/plain/commit/f4dbcef))

### Upgrade instructions

- No changes required

## [0.46.0](https://github.com/dropseed/plain/releases/plain-dev@0.46.0) (2025-11-10)

### What's changed

- The `plain dev` command now separates stdout and stderr output with distinct visual indicators - stderr uses a red pipe (`┃`) while stdout uses a dimmed pipe (`|`) to make error messages more visible ([ea78a6d](https://github.com/dropseed/plain/commit/ea78a6d359))
- The `FORCE_COLOR` environment variable is now automatically set in the development server and services to ensure consistent color output across all processes ([2a63270](https://github.com/dropseed/plain/commit/2a63270179))

### Upgrade instructions

- No changes required

## [0.45.1](https://github.com/dropseed/plain/releases/plain-dev@0.45.1) (2025-11-03)

### What's changed

- Fixed the database wait command call in the dev server startup to use the updated `plain db wait` command instead of the deprecated `plain models db-wait` ([b293750](https://github.com/dropseed/plain/commit/b293750f6f))
- Fixed the pre-commit database connection check to use the updated `plain migrations list` command instead of the deprecated `plain models show-migrations` ([b293750](https://github.com/dropseed/plain/commit/b293750f6f))

### Upgrade instructions

- No changes required

## [0.45.0](https://github.com/dropseed/plain/releases/plain-dev@0.45.0) (2025-11-03)

### What's changed

- The `plain dev` command now automatically generates and persists `.plain/AGENTS.md` during startup, ensuring AI coding assistants have up-to-date package documentation ([786b7a0](https://github.com/dropseed/plain/commit/786b7a0ca1))
- CLI command descriptions have been updated to be more concise and consistent across all `plain dev` subcommands ([fdb9e80](https://github.com/dropseed/plain/commit/fdb9e80103))
- The `plain dev` command is now marked as a "common command" in the CLI for better discoverability ([73d3a48](https://github.com/dropseed/plain/commit/73d3a48fca))

### Upgrade instructions

- No changes required

## [0.44.0](https://github.com/dropseed/plain/releases/plain-dev@0.44.0) (2025-10-29)

### What's changed

- The `plain preflight check` command has been simplified back to `plain preflight` throughout the development workflow, including pre-commit hooks and the dev server startup ([40c2c45](https://github.com/dropseed/plain/commit/40c2c4560e))

### Upgrade instructions

- No changes required

## [0.43.1](https://github.com/dropseed/plain/releases/plain-dev@0.43.1) (2025-10-27)

### What's changed

- The `plain precommit` command output has been redesigned with improved styling and clearer labels for each check that runs ([b45011c](https://github.com/dropseed/plain/commit/b45011cc44))

### Upgrade instructions

- No changes required

## [0.43.0](https://github.com/dropseed/plain/releases/plain-dev@0.43.0) (2025-10-22)

### What's changed

- The `plain contrib` command now uses `@without_runtime_setup` decorator to avoid loading the full Plain runtime, improving performance and reliability ([8b8cc2d](https://github.com/dropseed/plain/commit/8b8cc2d6c6))
- Removed the standalone `plain-contrib` command-line script as it is no longer needed with the runtime setup improvements ([8b8cc2d](https://github.com/dropseed/plain/commit/8b8cc2d6c6))

### Upgrade instructions

- No changes required

## [0.42.0](https://github.com/dropseed/plain/releases/plain-dev@0.42.0) (2025-10-13)

### What's changed

- The development server now uses `watchfiles` for file watching and auto-reloading instead of gunicorn's built-in reloader, providing more reliable and efficient file change detection ([92e95c5032](https://github.com/dropseed/plain/commit/92e95c5032))
- Removed manual `.env` file watching configuration from `plain dev` as this is now handled automatically by the server's reloader ([92e95c5032](https://github.com/dropseed/plain/commit/92e95c5032))

### Upgrade instructions

- No changes required

## [0.41.0](https://github.com/dropseed/plain/releases/plain-dev@0.41.0) (2025-10-12)

### What's changed

- The `plain dev` command now uses the new `plain server` command instead of `gunicorn` for running the development server ([f9dc2867c7](https://github.com/dropseed/plain/commit/f9dc2867c7))
- Removed `gunicorn` as a dependency - the development server now uses Plain's built-in HTTP server ([f9dc2867c7](https://github.com/dropseed/plain/commit/f9dc2867c7))
- Removed gunicorn-specific logging configuration file in favor of simplified log formatting ([fb8a00ca73](https://github.com/dropseed/plain/commit/fb8a00ca73))

### Upgrade instructions

- No changes required

## [0.40.0](https://github.com/dropseed/plain/releases/plain-dev@0.40.0) (2025-10-10)

### What's changed

- Updated documentation to reference `plain-jobs` instead of the deprecated `plain-worker` package name ([24219856e0](https://github.com/dropseed/plain/commit/24219856e0))

### Upgrade instructions

- No changes required

## [0.39.1](https://github.com/dropseed/plain/releases/plain-dev@0.39.1) (2025-10-06)

### What's changed

- Added comprehensive type annotations across the entire package to improve IDE support and type checking ([1d00e9f](https://github.com/dropseed/plain/commit/1d00e9f6f))

### Upgrade instructions

- No changes required

## [0.39.0](https://github.com/dropseed/plain/releases/plain-dev@0.39.0) (2025-09-30)

### What's changed

- The `plain dev` command now sets both `PLAIN_LOG_LEVEL` and `PLAIN_FRAMEWORK_LOG_LEVEL` environment variables when a log level is specified, replacing the previous `APP_LOG_LEVEL` setting ([4c5f216](https://github.com/dropseed/plain/commit/4c5f2166c1))

### Upgrade instructions

- No changes required

## [0.38.0](https://github.com/dropseed/plain/releases/plain-dev@0.38.0) (2025-09-30)

### What's changed

- Added an `AGENTS.md` file with package-specific agent instructions for the `plain dev logs` command ([5841a3f](https://github.com/dropseed/plain/commit/5841a3fb0b))

### Upgrade instructions

- No changes required

## [0.37.0](https://github.com/dropseed/plain/releases/plain-dev@0.37.0) (2025-09-29)

### What's changed

- Added a `p` alias prompt that suggests setting up a shell alias for `uv run plain` to make command execution faster ([d913b44](https://github.com/dropseed/plain/commit/d913b44fab), [6632529](https://github.com/dropseed/plain/commit/663252925b))

### Upgrade instructions

- No changes required

## [0.36.0](https://github.com/dropseed/plain/releases/plain-dev@0.36.0) (2025-09-25)

### What's changed

- The `plain preflight` command has been updated to use `plain preflight check` with a `--quiet` flag for cleaner output in development workflows ([b0b610d](https://github.com/dropseed/plain/commit/b0b610d461))
- Pre-commit hooks now use the updated preflight check syntax ([b0b610d](https://github.com/dropseed/plain/commit/b0b610d461))

### Upgrade instructions

- No changes required

## [0.35.0](https://github.com/dropseed/plain/releases/plain-dev@0.35.0) (2025-09-22)

### What's changed

- Removed automatic `PLAIN_ALLOWED_HOSTS` configuration from the dev server as this is now handled by the core Plain framework ([d3cb771](https://github.com/dropseed/plain/commit/d3cb7712b9))

### Upgrade instructions

- No changes required

## [0.34.0](https://github.com/dropseed/plain/releases/plain-dev@0.34.0) (2025-09-19)

### What's changed

- Minimum Python version requirement increased from 3.11 to 3.13 ([d86e307](https://github.com/dropseed/plain/commit/d86e307efb))

### Upgrade instructions

- Upgrade your Python environment to Python 3.13 or later

## [0.33.3](https://github.com/dropseed/plain/releases/plain-dev@0.33.3) (2025-09-03)

### What's changed

- Added retries to background service startup to improve reliability when services take longer to initialize ([e2b3a42](https://github.com/dropseed/plain/commit/e2b3a42313))

### Upgrade instructions

- No changes required

## [0.33.2](https://github.com/dropseed/plain/releases/plain-dev@0.33.2) (2025-08-22)

### What's changed

- The development localhost hostname is now automatically lowercased when generated from the pyproject.toml name ([4454f01](https://github.com/dropseed/plain/commit/4454f01787))
- Updated README with improved structure, table of contents, and better installation instructions ([4ebecd1](https://github.com/dropseed/plain/commit/4ebecd1856))

### Upgrade instructions

- No changes required

## [0.33.1](https://github.com/dropseed/plain/releases/plain-dev@0.33.1) (2025-07-18)

### What's changed

- Dev services are no longer automatically started when running in CI environments unless explicitly enabled with `PLAIN_DEV_SERVICES_AUTO=true` ([b8452bae74](https://github.com/dropseed/plain/commit/b8452bae74))
- The `plain dev logs` command now skips automatic service startup to avoid conflicts ([ff65428bca](https://github.com/dropseed/plain/commit/ff65428bca))

### Upgrade instructions

- No changes required

## [0.33.0](https://github.com/dropseed/plain/releases/plain-dev@0.33.0) (2025-07-18)

### What's changed

- Added automatic background startup of dev services when running `plain dev` commands. Services defined in `pyproject.toml` will now start automatically ([0a5ffc6de5](https://github.com/dropseed/plain/commit/0a5ffc6de5)).
- Added `plain dev logs` command to view output from recent `plain dev` runs. Supports options like `--follow`, `--pid`, `--path`, and `--services` to manage and view different log outputs ([0a5ffc6de5](https://github.com/dropseed/plain/commit/0a5ffc6de5)).
- Added `--start` and `--stop` flags to both `plain dev` and `plain dev services` commands for running processes in the background. Use `plain dev --start` to launch the dev server in background mode and `plain dev --stop` to terminate it ([0a5ffc6de5](https://github.com/dropseed/plain/commit/0a5ffc6de5)).
- Improved process management with better PID tracking and graceful shutdown handling for both dev server and services ([0a5ffc6de5](https://github.com/dropseed/plain/commit/0a5ffc6de5)).
- Improved CLI error handling by using `click.UsageError` instead of manual error printing and `sys.exit()` ([88f06c5184](https://github.com/dropseed/plain/commit/88f06c5184)).
- Removed `psycopg[binary]` dependency from plain-dev as database drivers should be installed separately based on project needs ([63224001c9](https://github.com/dropseed/plain/commit/63224001c9)).

### Upgrade instructions

- No changes required

## [0.32.1](https://github.com/dropseed/plain/releases/plain-dev@0.32.1) (2025-06-27)

### What's changed

- Fixed an error when running `plain dev precommit` (or the `plain precommit` helper) that passed an extra `default` argument to `plain preflight --database`. The flag now correctly aligns with the current `plain preflight` CLI ([db65930](https://github.com/dropseed/plain/commit/db659304129a453676c0dcc20c13b606254ce1c2)).

### Upgrade instructions

- No changes required.

## [0.32.0](https://github.com/dropseed/plain/releases/plain-dev@0.32.0) (2025-06-23)

### What's changed

- `plain dev` now writes a PID file and will refuse to start if it detects that another `plain dev` instance is already running in the same project ([75b7a50](https://github.com/dropseed/plain/commit/75b7a505ae3c60675099ffd440f35cf8f30665da)).
- When no `--port` is provided, `plain dev` now checks if port 8443 is available and, if not, automatically selects the next free port. Supplying `--port` will error if that port is already in use ([3f5141f](https://github.com/dropseed/plain/commit/3f5141f54a65455f5784ed3f97be2d153ed10a23)).
- The development request-log UI has been removed for now, along with its related endpoints and templates ([8ac6f71](https://github.com/dropseed/plain/commit/8ac6f7170efa72e6069bae3cc91809b5fe0f8a7d)).
- `plain contrib --all` skips any installed `plainx-*` packages instead of erroring when it can’t locate their repository ([3a26aee](https://github.com/dropseed/plain/commit/3a26aee25e586a66e02a348aa24ee6e048ea0b71)).

### Upgrade instructions

- No changes required.
