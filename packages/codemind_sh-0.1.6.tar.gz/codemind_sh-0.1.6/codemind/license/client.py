"""License server HTTP client — graceful offline fallback.

All network calls are wrapped so that any failure (no internet, server
down, timeout) silently falls back to local behaviour.  The CLI must
never crash or block because of a license-server outage.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any

from codemind.license.keygen import generate_trial_key


class LicenseLimitReached(Exception):
    """Raised when the server rejects a new project due to plan limit (HTTP 402)."""
    def __init__(self, detail: str = "") -> None:
        self.detail = detail
        super().__init__(detail)


from codemind.license.license import (
    LICENSE_FILE,
    LicenseManager,
    LicenseState,
    FREE_FEATURES,
)

_TIMEOUT = 5   # seconds — fast enough for CLI startup, long enough to work on slow VPS

_DEFAULT_SERVER = "https://codemind.sh"


def _server_url() -> str:
    return os.environ.get("CODEMIND_LICENSE_SERVER", _DEFAULT_SERVER).rstrip("/")


def _post(path: str, payload: dict[str, Any]) -> dict[str, Any] | None:
    """POST JSON to the license server. Returns parsed JSON or None on any error.

    Raises LicenseLimitReached on HTTP 402 (project limit reached on server).
    """
    url = f"{_server_url()}{path}"
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json", "User-Agent": "codemind-cli/0.1"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        if e.code == 402:
            try:
                body = json.loads(e.read().decode())
                raise LicenseLimitReached(body.get("detail", "Project limit reached."))
            except (json.JSONDecodeError, AttributeError):
                raise LicenseLimitReached("Project limit reached.")
        return None
    except (urllib.error.URLError, OSError, json.JSONDecodeError, TimeoutError):
        return None


def _get(path: str) -> dict[str, Any] | None:
    url = f"{_server_url()}{path}"
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "codemind-cli/0.1"},
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return json.loads(resp.read().decode())
    except (urllib.error.URLError, OSError, json.JSONDecodeError, TimeoutError):
        return None


def _parse_state(data: dict[str, Any]) -> LicenseState:
    return LicenseManager()._from_dict(data)  # type: ignore[attr-defined]


def _local_free() -> LicenseState:
    """Create an offline free-tier key when the license server is unreachable.

    Permanent free — 1 project (server-enforced), no expiry.
    The server will register it properly when connectivity is restored.
    """
    key = generate_trial_key()
    return LicenseState(
        license_key=key,
        features=list(FREE_FEATURES),
        activated_projects=[],
    )


class LicenseClient:
    """Talk to the license server."""

    def generate_trial(self, email: str = "") -> LicenseState:
        """Request a permanent free-tier license from the server.

        Requires internet on first run — no offline fallback.
        Raises RuntimeError if server is unreachable so the CLI can show
        a clear message instead of silently issuing an unregistered key.
        """
        payload: dict = {"email": email.strip().lower()} if email.strip() else {}
        result = _post("/api/licenses/trial", payload)
        if result:
            try:
                return _parse_state(result)
            except Exception:
                pass
        raise RuntimeError(
            "Could not reach the CodeMind license server.\n"
            "  Please check your internet connection and run [bold]codemind init[/bold] again.\n"
            "  If the problem persists, visit [cyan]codemind.sh[/cyan] or open an issue at\n"
            "  github.com/onixsolutions/codemind-community"
        )

    def validate(self, license_key: str, project_id: str) -> LicenseState | None:
        """Validate key + register project activation on server.

        Returns updated LicenseState (with refreshed features from server)
        or None if the server is unreachable.
        Raises LicenseLimitReached on HTTP 402 (project limit reached).
        """
        result = _post(
            "/api/licenses/validate",
            {"license_key": license_key, "project_id": project_id},
        )
        if result:
            try:
                return _parse_state(result)
            except Exception:
                pass
        return None

    def register_email(self, license_key: str, email: str) -> bool:
        """Associate an email with a license key for recovery purposes.

        Silently returns False if the server is unreachable.
        """
        result = _post(
            "/api/licenses/register-email",
            {"license_key": license_key, "email": email},
        )
        return result is not None

    def refresh(self, license_key: str) -> LicenseState | None:
        """Pull latest tier/features/expiry from server. None if offline."""
        result = _get(f"/api/licenses/{license_key}/status")
        if result:
            try:
                return _parse_state(result)
            except Exception:
                pass
        return None
