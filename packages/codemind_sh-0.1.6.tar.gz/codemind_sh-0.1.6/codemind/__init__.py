"""CodeMind — Local-first intelligence layer for software projects."""

__version__ = "0.1.6"
__app_name__ = "codemind"
