"""Setup for Pulse — process vital signs monitor."""

from setuptools import setup, find_packages
import os

here = os.path.abspath(os.path.dirname(__file__))

with open(os.path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="pulse-vital",
    version="0.1.0",
    description="Detect when processes are alive but not doing meaningful work",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="suzukidai",
    url="https://github.com/uzucky/Business/tree/master/business/products/pulse",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[],
    extras_require={
        "yaml": ["PyYAML>=5.0"],
        "dev": ["pytest>=6.0"],
    },
    entry_points={
        "console_scripts": [
            "pulse=pulse.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: System :: Monitoring",
    ],
    keywords="monitoring process health vital signs devops",
)
