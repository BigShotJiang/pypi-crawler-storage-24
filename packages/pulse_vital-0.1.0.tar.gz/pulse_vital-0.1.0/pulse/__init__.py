"""Pulse — Detect when processes are alive but not doing meaningful work."""

__version__ = "0.1.0"
