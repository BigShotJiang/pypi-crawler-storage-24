"""Allow running pulse as: python -m pulse"""
from .cli import main
import sys

sys.exit(main())
