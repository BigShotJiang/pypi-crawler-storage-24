from setuptools import setup, find_packages

setup(
    name="tempmail-detection-prit",
    version="0.1.0",
    description="Machine learning based disposable email detection",
    author="Prit Jasani",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "scikit-learn",
        "joblib"
    ],
)