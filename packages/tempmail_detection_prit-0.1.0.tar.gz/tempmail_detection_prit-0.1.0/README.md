# TempMail Detection System

A machine learning based system that detects whether an email address belongs to a temporary/disposable email service or a legitimate email provider.

This project uses domain classification and machine learning to identify temporary email domains and prevent fake registrations on websites.

## Features

- Detects disposable / temporary email addresses
- Machine learning based classification
- FastAPI backend for prediction API
- Simple frontend for testing
- Easy integration with other projects (Node.js, React, etc.)

## Project Structure

Tempmail_Detection
│
├── backend
│   ├── app.py
│   ├── train_model.py
│   ├── model.pkl
│   ├── vectorizer.pkl
│   └── data
│       ├── temp_domains.txt
│       └── real_domains.txt
│
├── frontend
│   ├── index.html
│   ├── script.js
│   └── style.css
│
└── requirements.txt

## How It Works

1. User enters an email address.
2. The system extracts the email domain.
3. The trained ML model analyzes the domain.
4. The API returns whether the email is temporary or legitimate.

Example:

test@mailinator.com → Temporary Email  
user@gmail.com → Legitimate Email

## Installation

Clone the repository

git clone https://github.com/pritjasani08/tempmail-detection.git

cd tempmail-detection

Install dependencies

pip install -r requirements.txt

## Running the API

Start the FastAPI server using Uvicorn

uvicorn backend.app:app --reload

The API will run at

http://localhost:8000

## API Endpoint

POST /check-email

Request Body

{
 "email": "test@mailinator.com"
}

Response

{
 "prediction": "Temporary Email"
}

## Use Case

This service can be integrated into

- User registration systems
- Login/signup validation
- Anti-spam protection
- Web applications that need email verification

Example architecture

Frontend → Backend (Node/Express) → TempMail Detection API → Response

## Technologies Used

- Python
- FastAPI
- Scikit-learn
- HTML
- CSS
- JavaScript
- Uvicorn

## Future Improvements

- Add larger disposable domain dataset
- Improve ML accuracy
- Deploy API to cloud
- Add domain reputation scoring

## Author

Prit Jasani  
Computer Science Student interested in Web Development and AI/ML