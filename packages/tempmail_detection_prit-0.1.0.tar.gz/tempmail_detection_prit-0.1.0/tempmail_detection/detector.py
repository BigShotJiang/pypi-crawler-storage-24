import joblib
import os

BASE_DIR = os.path.dirname(__file__)

model = joblib.load(os.path.join(BASE_DIR, "../backend/model.pkl"))
vectorizer = joblib.load(os.path.join(BASE_DIR, "../backend/vectorizer.pkl"))

def check_email(email):

    domain = email.split("@")[-1]

    features = vectorizer.transform([domain])
    prediction = model.predict(features)[0]

    if prediction == 1:
        return "Temporary Email"
    else:
        return "Legitimate Email"