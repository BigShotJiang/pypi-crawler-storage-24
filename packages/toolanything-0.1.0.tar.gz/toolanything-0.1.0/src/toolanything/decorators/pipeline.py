"""`@pipeline` decorator 實作。"""
from __future__ import annotations

import inspect
from functools import wraps
from typing import Any, Callable, Optional

from ..core.models import PipelineDefinition
from ..core.registry import ToolRegistry
from ..core.schema import build_parameters_schema
from ..pipeline.context import PipelineContext
from ..state import StateManager
from ..utils.docstring_parser import parse_docstring


def pipeline(
    name: str,
    description: str,
    registry: Optional[ToolRegistry] = None,
    state_manager: Optional[StateManager] = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """註冊 pipeline 函數，預設會注入 PipelineContext。"""

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        active_registry = registry or ToolRegistry.global_instance()
        params_schema = build_parameters_schema(func)
        documentation = parse_docstring(func)
        definition = PipelineDefinition(
            name=name,
            description=description,
            func=func,
            parameters=params_schema,
            state_manager=state_manager,
            documentation=documentation,
        )

        active_registry.register_pipeline(definition)

        if inspect.iscoroutinefunction(func):
            @wraps(func)
            async def wrapper(*args: Any, **kwargs: Any) -> Any:
                user_id = kwargs.pop("user_id", None)
                ctx = PipelineContext(state_manager=state_manager, user_id=user_id)
                return await func(ctx, *args, **kwargs)
        else:
            @wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                user_id = kwargs.pop("user_id", None)
                ctx = PipelineContext(state_manager=state_manager, user_id=user_id)
                return func(ctx, *args, **kwargs)

        wrapper.metadata = definition  # type: ignore[attr-defined]
        return wrapper

    return decorator
