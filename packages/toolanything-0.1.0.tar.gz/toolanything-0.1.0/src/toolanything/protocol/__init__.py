"""Protocol layer interfaces."""
