import http.client
import io
import json
import sys
import threading
from http.server import ThreadingHTTPServer
from types import MethodType

import pytest

from toolanything import pipeline, tool
from toolanything.core.registry import ToolRegistry
from toolanything.exceptions import ToolError
from toolanything.protocol.mcp_jsonrpc import (
    MCP_METHOD_INITIALIZE,
    MCP_METHOD_TOOLS_CALL,
    MCP_METHOD_TOOLS_LIST,
    build_request,
)
from toolanything.server.mcp_streamable_http import (
    MCP_PROTOCOL_VERSION_HEADER,
    MCP_SESSION_ID_HEADER,
)
from toolanything.server.mcp_stdio_server import MCPStdioServer
from toolanything.server.mcp_tool_server import _build_handler
from toolanything.state import StateManager


@pytest.fixture()
def registry_with_tools():
    registry = ToolRegistry()
    state_manager = StateManager()

    @tool(name="echo", description="Echo message", registry=registry)
    def echo(message: str):
        return {"echo": message}

    @tool(name="fail", description="Failing tool", registry=registry)
    def fail(api_key: str):
        raise ToolError("boom", error_type="bad_request", data={"hint": "nope"})

    @tool(name="explode", description="Unexpected crash", registry=registry)
    def explode():
        raise RuntimeError("crash")

    @pipeline(
        name="remember",
        description="Store a value in state",
        registry=registry,
        state_manager=state_manager,
    )
    def remember(ctx, value: str):
        ctx.set("remembered", value)
        return {"remembered": ctx.get("remembered")}

    def execute_tool_stub(self, name: str, *, arguments=None, user_id=None, state_manager=None, failure_log=None):
        arguments = arguments or {}
        if name == "fail":
            raise ToolError("boom", error_type="bad_request", data={"hint": "nope"})
        if name == "explode":
            raise RuntimeError("crash")
        return ToolRegistry.execute_tool(
            self,
            name,
            arguments=arguments,
            user_id=user_id,
            state_manager=state_manager,
            failure_log=failure_log,
        )

    registry.execute_tool = MethodType(execute_tool_stub, registry)

    return registry, state_manager


def start_http_server(registry: ToolRegistry):
    handler_cls = _build_handler(registry, host="127.0.0.1", port=0)
    server = ThreadingHTTPServer(("localhost", 0), handler_cls)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread


def test_mcp_http_server_endpoints(registry_with_tools):
    registry, _ = registry_with_tools
    server, thread = start_http_server(registry)
    port = server.server_address[1]
    conn = http.client.HTTPConnection("localhost", port, timeout=5)

    try:
        conn.request("GET", "/")
        resp = conn.getresponse()
        root_body = json.loads(resp.read())
        assert resp.status == 200
        assert root_body["status"] == "ok"
        assert root_body["transport"] == "legacy_sse"
        assert root_body["mcp"]["sse"] == "/sse"
        assert root_body["mcp"]["messages"] == "/messages/{session_id}"

        conn.request("GET", "/health")
        resp = conn.getresponse()
        body = json.loads(resp.read())
        assert resp.status == 200
        assert body["status"] == "ok"

        conn.request("GET", "/tools")
        resp = conn.getresponse()
        tools_body = json.loads(resp.read())
        assert resp.status == 200
        assert any(tool["name"] == "echo" for tool in tools_body["tools"])

        payload = json.dumps({"name": "echo", "arguments": {"message": "hi"}})
        conn.request("POST", "/invoke", body=payload, headers={"Content-Type": "application/json"})
        resp = conn.getresponse()
        invoke_body = json.loads(resp.read())
        assert resp.status == 200
        assert invoke_body["result"] == {"contentType": "application/json", "content": {"echo": "hi"}}
        assert invoke_body["audit"]["tool"] == "echo"

        invalid_body = "{bad"
        conn.request("POST", "/invoke", body=invalid_body, headers={"Content-Type": "application/json"})
        resp = conn.getresponse()
        error_body = json.loads(resp.read())
        assert resp.status == 400
        assert error_body["error"] == "invalid_json"

        conn.request(
            "POST",
            "/",
            body=json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "initialize",
                    "params": {"protocolVersion": "2025-11-25"},
                }
            ),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                MCP_PROTOCOL_VERSION_HEADER: "2025-11-25",
            },
        )
        resp = conn.getresponse()
        initialize_body = json.loads(resp.read())
        session_id = resp.getheader(MCP_SESSION_ID_HEADER)
        protocol_version = resp.getheader(MCP_PROTOCOL_VERSION_HEADER)
        assert resp.status == 200
        assert initialize_body["result"]["protocolVersion"] == "2025-11-25"
        assert session_id
        assert protocol_version == "2025-11-25"

        conn.request(
            "POST",
            "/mcp",
            body=json.dumps({"jsonrpc": "2.0", "id": 2, "method": "tools/list"}),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                MCP_SESSION_ID_HEADER: session_id,
                MCP_PROTOCOL_VERSION_HEADER: protocol_version,
            },
        )
        resp = conn.getresponse()
        mcp_tools_body = json.loads(resp.read())
        assert resp.status == 200
        assert any(tool["name"] == "echo" for tool in mcp_tools_body["result"]["tools"])

        conn.request("POST", "/invoke", body=json.dumps({"arguments": {}}), headers={"Content-Type": "application/json"})
        resp = conn.getresponse()
        missing_name_body = json.loads(resp.read())
        assert resp.status == 400
        assert missing_name_body["error"] == "missing_name"

        conn.request(
            "POST",
            "/invoke",
            body=json.dumps({"name": "fail", "arguments": {"api_key": "secret"}}),
            headers={"Content-Type": "application/json"},
        )
        resp = conn.getresponse()
        fail_body = json.loads(resp.read())
        assert resp.status == 400
        assert fail_body["error"]["type"] == "bad_request"
        assert fail_body["arguments"]["api_key"] == "***MASKED***"

        conn.request("POST", "/invoke", body=json.dumps({"name": "missing"}), headers={"Content-Type": "application/json"})
        resp = conn.getresponse()
        missing_body = json.loads(resp.read())
        assert resp.status == 500
        assert missing_body["error"]["type"] == "internal_error"
    finally:
        conn.close()
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)


def test_mcp_http_server_rejects_disallowed_origin(registry_with_tools):
    registry, _ = registry_with_tools
    server, thread = start_http_server(registry)
    port = server.server_address[1]
    conn = http.client.HTTPConnection("localhost", port, timeout=5)

    try:
        conn.request(
            "GET",
            "/health",
            headers={"Origin": "https://evil.example"},
        )
        resp = conn.getresponse()
        body = json.loads(resp.read())
        assert resp.status == 403
        assert body["error"] == "origin_not_allowed"
    finally:
        conn.close()
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)


def test_mcp_stdio_server_flow(monkeypatch, registry_with_tools):
    registry, _ = registry_with_tools
    server = MCPStdioServer(registry)

    requests = [
        build_request(MCP_METHOD_INITIALIZE, 1),
        build_request(MCP_METHOD_TOOLS_LIST, 2),
        build_request(
            MCP_METHOD_TOOLS_CALL,
            3,
            params={"name": "echo", "arguments": {"message": "world"}},
        ),
        build_request(
            MCP_METHOD_TOOLS_CALL,
            4,
            params={"name": "fail", "arguments": {"api_key": "top-secret"}},
        ),
    ]

    input_data = "\n".join(json.dumps(r, ensure_ascii=False) for r in requests) + "\n"
    fake_stdin = io.StringIO(input_data)
    fake_stdout = io.StringIO()

    monkeypatch.setattr(sys, "stdin", fake_stdin)
    monkeypatch.setattr(sys, "stdout", fake_stdout)

    server.run()

    output_lines = [json.loads(line) for line in fake_stdout.getvalue().strip().splitlines()]
    assert output_lines[0]["result"]["protocolVersion"]
    assert any(tool["name"] == "echo" for tool in output_lines[1]["result"]["tools"])

    success = output_lines[2]["result"]
    assert success["arguments"] == {"message": "world"}
    assert success["meta"]["contentType"] == "application/json"

    fail_response = output_lines[3]["error"]
    assert fail_response["message"] == "bad_request"
    assert fail_response["data"]["arguments"]["api_key"] == "***MASKED***"


def test_mcp_http_invoke_pipeline_persists_state(registry_with_tools):
    registry, state_manager = registry_with_tools
    server, thread = start_http_server(registry)
    port = server.server_address[1]
    conn = http.client.HTTPConnection("localhost", port, timeout=5)

    try:
        payload = json.dumps(
            {"name": "remember", "arguments": {"value": "hello"}, "user_id": "user-http"}
        )
        conn.request("POST", "/invoke", body=payload, headers={"Content-Type": "application/json"})
        resp = conn.getresponse()
        invoke_body = json.loads(resp.read())
        assert resp.status == 200
        assert invoke_body["result"] == {
            "contentType": "application/json",
            "content": {"remembered": "hello"},
        }
        assert state_manager.get("user-http")["remembered"] == "hello"
    finally:
        conn.close()
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)
