# Tests for tipster
