from typing import Optional, List, Tuple
from runai_model_streamer_azure.credentials.credentials import AzureCredentials, get_credentials

import fnmatch
import os
import posixpath
from pathlib import Path

from azure.storage.blob import BlobServiceClient


# Application ID for telemetry (prepended to User-Agent)
# Reference: https://azure.github.io/azure-sdk/general_azurecore.html#user-agent-format
_USER_AGENT = "azpartner-runai"


def _create_client(credentials: Optional[AzureCredentials] = None) -> BlobServiceClient:
    """
    Creates an Azure BlobServiceClient.

    Authentication priority:
    1. Connection string (AZURE_STORAGE_CONNECTION_STRING) - for local testing with Azurite
    2. DefaultAzureCredential with account URL - for production

    Args:
        credentials: Optional AzureCredentials object

    Returns:
        BlobServiceClient instance
    """
    if credentials is None:
        credentials = get_credentials()

    # Use connection string if available (for Azurite/local testing)
    if credentials.connection_string:
        return BlobServiceClient.from_connection_string(
            credentials.connection_string,
            user_agent=_USER_AGENT
        )

    # Use account name + DefaultAzureCredential (for production)
    account_url = f"https://{credentials.account_name}.blob.core.windows.net"
    return BlobServiceClient(
        account_url=account_url,
        credential=credentials.credential,
        user_agent=_USER_AGENT
    )


def glob(path: str, allow_pattern: Optional[List[str]] = None, credentials: Optional[AzureCredentials] = None) -> List[str]:
    """
    List files in Azure Blob Storage matching the given pattern.
    
    Args:
        path: Azure blob path in format "az://container/prefix"
        allow_pattern: Optional list of glob patterns to include
        credentials: Optional AzureCredentials object
        
    Returns:
        List of full Azure blob paths
    """
    client = _create_client(credentials)

    if not path.endswith("/"):
        path = f"{path}/"
    
    # glob is non-recursive - only list files in the given directory
    container_name, _, keys = list_files(client, path, allow_pattern, recursive=False)
    return [f"az://{container_name}/{key}" for key in keys]


def pull_files(
    model_path: str,
    dst: str,
    allow_pattern: Optional[List[str]] = None,
    ignore_pattern: Optional[List[str]] = None,
    credentials: Optional[AzureCredentials] = None
) -> None:
    """
    Download files from Azure Blob Storage to local directory.
    
    Args:
        model_path: Azure blob path in format "az://container/prefix"
        dst: Local destination directory
        allow_pattern: Optional list of glob patterns to include
        ignore_pattern: Optional list of glob patterns to exclude
        credentials: Optional AzureCredentials object
    """
    client = _create_client(credentials)

    if not model_path.endswith("/"):
        model_path = model_path + "/"

    # pull_files is recursive - download all files including subdirectories
    container_name, base_dir, files = list_files(
        client, model_path, allow_pattern, ignore_pattern, recursive=True
    )
    
    if len(files) == 0:
        return

    container_client = client.get_container_client(container_name)

    for file in files:
        destination_file = os.path.join(
            dst,
            removeprefix(file, base_dir).lstrip("/")
        )
        local_dir = Path(destination_file).parent
        os.makedirs(local_dir, exist_ok=True)
        
        blob_client = container_client.get_blob_client(file)
        with open(destination_file, "wb") as download_file:
            download_file.write(blob_client.download_blob().readall())


def list_files(
    client: BlobServiceClient,
    path: str,
    allow_pattern: Optional[List[str]] = None,
    ignore_pattern: Optional[List[str]] = None,
    recursive: bool = False
) -> Tuple[str, str, List[str]]:
    """
    List files in Azure Blob Storage at the given path.
    
    Args:
        client: BlobServiceClient instance
        path: Azure blob path
        allow_pattern: Optional list of glob patterns to include
        ignore_pattern: Optional list of glob patterns to exclude
        recursive: If True, list files in subdirectories. If False, only list files directly in the path.

    Returns:
        Tuple of (container_name, prefix, list_of_blob_names)
    """
    # Parse az://container/prefix format
    path = removeprefix(path, 'az://')
    parts = path.split('/', 1)
    container_name = parts[0]
    prefix = parts[1] if len(parts) > 1 else ""

    # Reconstruct the prefix
    prefix = prefix.rstrip('/')
    
    if prefix:
        # This ensures a trailing slash without double-slashing
        prefix = posixpath.join(prefix, '')

    container_client = client.get_container_client(container_name)
    
    paths = []
    if recursive:
        # Recursive: list all blobs under the prefix
        blob_items = container_client.list_blobs(name_starts_with=prefix)
        for item in blob_items:
            if hasattr(item, 'name'):
                paths.append(item.name)
    else:
        # Non-recursive: use walk_blobs with delimiter to only get blobs at this level
        # This is more efficient as Azure service handles the filtering
        blob_items = container_client.walk_blobs(name_starts_with=prefix, delimiter='/')
        for item in blob_items:
            # walk_blobs returns BlobProperties for blobs and BlobPrefix for directories
            # We only want blobs (files), not prefixes (directories)
            if hasattr(item, 'name') and not item.name.endswith('/'):
                paths.append(item.name)

    # Filter out directories (blobs ending with /)
    paths = _filter_ignore(paths, ["*/"])
    
    if allow_pattern is not None:
        paths = _filter_allow(paths, allow_pattern)

    if ignore_pattern is not None:
        paths = _filter_ignore(paths, ignore_pattern)

    return container_name, prefix, paths


def _filter_allow(paths: List[str], patterns: List[str]) -> List[str]:
    return [
        path for path in paths if any(
            fnmatch.fnmatch(path, pattern) for pattern in patterns
        )
    ]


def _filter_ignore(paths: List[str], patterns: List[str]) -> List[str]:
    return [
        path for path in paths
        if not any(fnmatch.fnmatch(path, pattern) for pattern in patterns)
    ]


def removeprefix(s: str, prefix: str) -> str:
    if s.startswith(prefix):
        return s[len(prefix):]
    return s
