"""Merge strategies — LAST_WINS vs FIRST_WINS."""

from dataclasses import dataclass
from pathlib import Path

from dature import Merge, MergeStrategy, Source, load

SHARED_DIR = Path(__file__).parents[2] / "shared"


@dataclass
class Config:
    host: str
    port: int
    tags: list[str]


last_wins = load(
    Merge(
        sources=(
            Source(file_=SHARED_DIR / "common_defaults.yaml"),
            Source(file_=SHARED_DIR / "common_overrides.yaml"),
        ),
        strategy=MergeStrategy.LAST_WINS,
    ),
    Config,
)

first_wins = load(
    Merge(
        sources=(
            Source(file_=SHARED_DIR / "common_defaults.yaml"),
            Source(file_=SHARED_DIR / "common_overrides.yaml"),
        ),
        strategy=MergeStrategy.FIRST_WINS,
    ),
    Config,
)

assert last_wins.host == "production.example.com"
assert first_wins.host == "localhost"
