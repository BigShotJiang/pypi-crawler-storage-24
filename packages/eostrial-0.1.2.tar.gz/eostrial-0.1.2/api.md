# Memories

Types:

```python
from eostrial.types import MemoryAddResponse
```

Methods:

- <code title="post /api/v1/memories">client.memories.<a href="./src/eostrial/resources/memories.py">add</a>(\*\*<a href="src/eostrial/types/memory_add_params.py">params</a>) -> <a href="./src/eostrial/types/memory_add_response.py">MemoryAddResponse</a></code>

# Storage

Types:

```python
from eostrial.types import StorageCreatePresignedURLResponse
```

Methods:

- <code title="post /api/v1/storage/presign">client.storage.<a href="./src/eostrial/resources/storage.py">create_presigned_url</a>(\*\*<a href="src/eostrial/types/storage_create_presigned_url_params.py">params</a>) -> <a href="./src/eostrial/types/storage_create_presigned_url_response.py">StorageCreatePresignedURLResponse</a></code>
