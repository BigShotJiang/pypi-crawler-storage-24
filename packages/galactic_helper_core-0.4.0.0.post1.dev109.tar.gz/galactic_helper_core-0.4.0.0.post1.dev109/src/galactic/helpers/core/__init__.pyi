def detect_plugins(group: str = "galactic", name: str | None = None) -> None: ...
def default_repr(
    item: object,
    *,
    class_name: str | None = None,
    module_name: str | None = None,
) -> str: ...
