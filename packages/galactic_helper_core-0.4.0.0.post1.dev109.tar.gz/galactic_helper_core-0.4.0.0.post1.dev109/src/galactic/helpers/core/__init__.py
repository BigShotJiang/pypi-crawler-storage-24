"""
Defines two helper functions.

 One for detecting plugins and one for providing a unified string representation of
 objects.

* :func:`detect_plugins`
* :func:`default_repr`
"""

from ._plugins import detect_plugins
from ._repr import default_repr

__all__ = ("detect_plugins", "default_repr")
