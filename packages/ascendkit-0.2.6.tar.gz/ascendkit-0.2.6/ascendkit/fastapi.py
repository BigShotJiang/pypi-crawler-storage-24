"""FastAPI integration helpers for AscendKit auth."""

from __future__ import annotations

from ascendkit._client import _DEFAULT_API_URL
from ascendkit.auth import AsyncAuthClient


def get_current_user_dependency(
    public_key: str,
    *,
    api_url: str = _DEFAULT_API_URL,
):
    """Return a FastAPI dependency that resolves the current user from Bearer token."""

    client = AsyncAuthClient(public_key=public_key, api_url=api_url)
    try:
        from fastapi import Header, HTTPException
    except Exception as exc:  # pragma: no cover - optional dependency guard
        raise RuntimeError(
            "FastAPI integration requires installing fastapi. "
            "Install with: pip install fastapi"
        ) from exc

    async def _get_current_user(authorization: str = Header(default="")) -> dict:
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Missing or invalid Authorization header")
        token = authorization.removeprefix("Bearer ").strip()
        if not token:
            raise HTTPException(status_code=401, detail="Missing bearer token")
        try:
            return await client.verify_token(token)
        except Exception as exc:
            raise HTTPException(status_code=401, detail=str(exc))

    return _get_current_user


def get_current_user(public_key: str, *, api_url: str = _DEFAULT_API_URL):
    """Backward-compatible alias."""
    return get_current_user_dependency(public_key, api_url=api_url)
