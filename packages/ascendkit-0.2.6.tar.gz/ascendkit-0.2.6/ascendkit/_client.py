"""AscendKit API client (sync and async)."""

from __future__ import annotations

import logging
import os
import uuid
from typing import Any

import httpx

from ascendkit._errors import AscendKitError, AuthError, NotFoundError, ValidationError
from ascendkit._version import SDK_VERSION

logger = logging.getLogger("ascendkit")

_DEFAULT_API_URL = "https://api.ascendkit.dev"
_VERSION_HEADER = {"X-AscendKit-Client-Version": f"python/{SDK_VERSION}"}

_upgrade_warned = False


def _check_upgrade(response: httpx.Response) -> None:
    global _upgrade_warned
    if _upgrade_warned:
        return
    upgrade = response.headers.get("X-AscendKit-Upgrade")
    if upgrade == "recommended":
        latest = response.headers.get("X-AscendKit-Latest-Version", "latest")
        logger.warning(
            "A newer SDK version (v%s) is available. "
            "You are running v%s. Run 'pip install --upgrade ascendkit' to upgrade.",
            latest,
            SDK_VERSION,
        )
        _upgrade_warned = True


def _handle_error(response: httpx.Response) -> None:
    if response.status_code < 400:
        return
    try:
        body = response.json()
        detail = body.get("error") or body.get("detail") or str(body)
    except Exception:
        detail = response.text

    if response.status_code == 401:
        raise AuthError(detail, status_code=401)
    if response.status_code == 404:
        raise NotFoundError(detail, status_code=404)
    if response.status_code == 422:
        raise ValidationError(detail, status_code=422)
    raise AscendKitError(detail, status_code=response.status_code)


class AscendKit:
    """Synchronous AscendKit client.

    The ``public_key`` parameter is optional — if omitted, the constructor
    reads ``ASCENDKIT_ENV_KEY`` from the environment.
    """

    def __init__(
        self,
        public_key: str | None = None,
        api_url: str = _DEFAULT_API_URL,
        invocation_id: str | None = None,
    ) -> None:
        resolved_key = public_key or os.environ.get("ASCENDKIT_ENV_KEY")
        if not resolved_key:
            raise ValueError(
                "AscendKit: missing public key. Pass public_key or set ASCENDKIT_ENV_KEY."
            )
        self.public_key = resolved_key
        self._invocation_id = invocation_id or str(uuid.uuid4())
        self._client = httpx.Client(
            base_url=api_url,
            headers={
                "X-AscendKit-Public-Key": resolved_key,
                "X-AscendKit-Invocation-Id": self._invocation_id,
                **_VERSION_HEADER,
            },
        )

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        per_request_headers = {"X-AscendKit-Client-Request-Id": str(uuid.uuid4())}
        existing = kwargs.pop("headers", None)
        if existing:
            per_request_headers.update(existing)
        response = self._client.request(method, path, headers=per_request_headers, **kwargs)
        _check_upgrade(response)
        _handle_error(response)
        body = response.json()
        return body.get("data", body)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> AscendKit:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncAscendKit:
    """Asynchronous AscendKit client.

    The ``public_key`` parameter is optional — if omitted, the constructor
    reads ``ASCENDKIT_ENV_KEY`` from the environment.
    """

    def __init__(
        self,
        public_key: str | None = None,
        api_url: str = _DEFAULT_API_URL,
        invocation_id: str | None = None,
    ) -> None:
        resolved_key = public_key or os.environ.get("ASCENDKIT_ENV_KEY")
        if not resolved_key:
            raise ValueError(
                "AscendKit: missing public key. Pass public_key or set ASCENDKIT_ENV_KEY."
            )
        self.public_key = resolved_key
        self._invocation_id = invocation_id or str(uuid.uuid4())
        self._client = httpx.AsyncClient(
            base_url=api_url,
            headers={
                "X-AscendKit-Public-Key": resolved_key,
                "X-AscendKit-Invocation-Id": self._invocation_id,
                **_VERSION_HEADER,
            },
        )

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        per_request_headers = {"X-AscendKit-Client-Request-Id": str(uuid.uuid4())}
        existing = kwargs.pop("headers", None)
        if existing:
            per_request_headers.update(existing)
        response = await self._client.request(method, path, headers=per_request_headers, **kwargs)
        _check_upgrade(response)
        _handle_error(response)
        body = response.json()
        return body.get("data", body)

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncAscendKit:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
