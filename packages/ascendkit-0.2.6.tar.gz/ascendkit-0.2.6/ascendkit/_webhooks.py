"""Webhook signature verification for AscendKit.

AscendKit signs every webhook request with an HMAC-SHA256 signature. The
signature header contains a timestamp and one or more versioned signatures
in the format: ``t=<unix_seconds>,v1=<hex_hmac>``.

The signed content is ``<timestamp>.<raw_body>``, ensuring both freshness
and integrity.

Usage with FastAPI::

    from fastapi import Request, Response
    from ascendkit import verify_webhook_signature

    WEBHOOK_SECRET = "whsec_..."

    @app.post("/webhooks/ascendkit")
    async def handle_webhook(request: Request) -> Response:
        body = await request.body()
        signature = request.headers.get("x-ascendkit-signature", "")

        if not verify_webhook_signature(
            secret=WEBHOOK_SECRET,
            signature_header=signature,
            payload=body.decode(),
        ):
            return Response(status_code=401, content="Invalid signature")

        event = await request.json()
        # Handle the event...
        return Response(status_code=200, content="OK")

Usage with Flask::

    from flask import Flask, request
    from ascendkit import verify_webhook_signature

    WEBHOOK_SECRET = "whsec_..."

    @app.route("/webhooks/ascendkit", methods=["POST"])
    def handle_webhook():
        body = request.get_data(as_text=True)
        signature = request.headers.get("x-ascendkit-signature", "")

        if not verify_webhook_signature(
            secret=WEBHOOK_SECRET,
            signature_header=signature,
            payload=body,
        ):
            return "Invalid signature", 401

        event = request.get_json()
        # Handle the event...
        return "OK", 200
"""

from __future__ import annotations

import hashlib
import hmac
import time

_DEFAULT_TOLERANCE_SECONDS = 300


def verify_webhook_signature(
    secret: str,
    signature_header: str,
    payload: str,
    tolerance: int = _DEFAULT_TOLERANCE_SECONDS,
) -> bool:
    """Verify an AscendKit webhook signature.

    Args:
        secret: Your webhook signing secret.
        signature_header: The value of the ``X-AscendKit-Signature`` header.
        payload: The raw request body as a string.
        tolerance: Maximum allowed age of the timestamp in seconds (default 300).

    Returns:
        ``True`` if the signature is valid and the timestamp is within tolerance.
    """
    # Parse header: t=<timestamp>,v1=<hmac>
    parts = signature_header.split(",")

    timestamp: str | None = None
    signature_hex: str | None = None

    for part in parts:
        key, _, value = part.partition("=")
        if key == "t":
            timestamp = value
        elif key == "v1":
            signature_hex = value

    if not timestamp or not signature_hex:
        return False

    # Validate timestamp freshness
    try:
        timestamp_seconds = int(timestamp)
    except ValueError:
        return False

    now = int(time.time())
    if abs(now - timestamp_seconds) > tolerance:
        return False

    # Compute expected signature: HMAC-SHA256 of "<timestamp>.<payload>"
    signed_content = f"{timestamp}.{payload}"
    expected_hmac = hmac.new(
        secret.encode(),
        signed_content.encode(),
        hashlib.sha256,
    ).hexdigest()

    # Constant-time comparison to prevent timing attacks
    return hmac.compare_digest(expected_hmac, signature_hex)
