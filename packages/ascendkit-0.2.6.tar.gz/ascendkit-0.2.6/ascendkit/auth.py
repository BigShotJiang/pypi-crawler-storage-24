"""Auth-focused helpers for user lookup and token verification."""

from __future__ import annotations

from typing import Any
from urllib.parse import urlencode

from ascendkit._client import AscendKit, AsyncAscendKit, _DEFAULT_API_URL
from ascendkit._errors import AuthError


def _auth_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


class AuthClient:
    """Synchronous auth client for AscendKit user operations."""

    def __init__(
        self,
        public_key: str | None = None,
        api_url: str = _DEFAULT_API_URL,
        *,
        secret_key: str | None = None,
        token: str | None = None,
    ) -> None:
        self._client = AscendKit(public_key=public_key, api_url=api_url)
        self._secret_key = secret_key
        self._token = token

    def _admin_headers(self, token: str | None = None) -> dict[str, str]:
        headers: dict[str, str] = {}
        use_token = token or self._token
        if use_token:
            headers.update(_auth_headers(use_token))
        if self._secret_key:
            headers["X-AscendKit-Secret-Key"] = self._secret_key
        if not headers:
            raise AuthError(
                "Admin operations require either a platform token or a secret key.",
                status_code=401,
            )
        return headers

    def verify_token(self, token: str) -> dict[str, Any]:
        return self._client._request("GET", "/api/users/me", headers=_auth_headers(token))

    def get_user(self, user_id: str, token: str | None = None) -> dict[str, Any]:
        return self._client._request(
            "GET",
            f"/api/users/{user_id}",
            headers=self._admin_headers(token),
        )

    def update_user(
        self,
        user_id: str,
        data: dict[str, Any],
        token: str | None = None,
    ) -> dict[str, Any]:
        return self._client._request(
            "PATCH",
            f"/api/users/{user_id}",
            json=data,
            headers={
                "Content-Type": "application/json",
                **self._admin_headers(token),
            },
        )

    def list_users(
        self,
        filters: dict[str, Any] | None = None,
        token: str | None = None,
    ) -> list[dict[str, Any]]:
        params = urlencode(filters or {})
        path = "/api/users" if not params else f"/api/users?{params}"
        return self._client._request("GET", path, headers=self._admin_headers(token))


class AsyncAuthClient:
    """Asynchronous auth client for AscendKit user operations."""

    def __init__(
        self,
        public_key: str | None = None,
        api_url: str = _DEFAULT_API_URL,
        *,
        secret_key: str | None = None,
        token: str | None = None,
    ) -> None:
        self._client = AsyncAscendKit(public_key=public_key, api_url=api_url)
        self._secret_key = secret_key
        self._token = token

    def _admin_headers(self, token: str | None = None) -> dict[str, str]:
        headers: dict[str, str] = {}
        use_token = token or self._token
        if use_token:
            headers.update(_auth_headers(use_token))
        if self._secret_key:
            headers["X-AscendKit-Secret-Key"] = self._secret_key
        if not headers:
            raise AuthError(
                "Admin operations require either a platform token or a secret key.",
                status_code=401,
            )
        return headers

    async def verify_token(self, token: str) -> dict[str, Any]:
        return await self._client._request("GET", "/api/users/me", headers=_auth_headers(token))

    async def get_user(self, user_id: str, token: str | None = None) -> dict[str, Any]:
        return await self._client._request(
            "GET",
            f"/api/users/{user_id}",
            headers=self._admin_headers(token),
        )

    async def update_user(
        self,
        user_id: str,
        data: dict[str, Any],
        token: str | None = None,
    ) -> dict[str, Any]:
        return await self._client._request(
            "PATCH",
            f"/api/users/{user_id}",
            json=data,
            headers={
                "Content-Type": "application/json",
                **self._admin_headers(token),
            },
        )

    async def list_users(
        self,
        filters: dict[str, Any] | None = None,
        token: str | None = None,
    ) -> list[dict[str, Any]]:
        params = urlencode(filters or {})
        path = "/api/users" if not params else f"/api/users?{params}"
        return await self._client._request("GET", path, headers=self._admin_headers(token))
