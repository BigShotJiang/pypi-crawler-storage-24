"""Tests for AscendKit webhook signature verification."""

import hashlib
import hmac
import time

from ascendkit import verify_webhook_signature

SECRET = "whsec_test_secret_key"
PAYLOAD = '{"event":"user.created","data":{"id":"usr_abc123"}}'


def _sign(secret: str, payload: str, timestamp: int | None = None) -> str:
    """Build a valid signature header for testing."""
    ts = timestamp if timestamp is not None else int(time.time())
    signed_content = f"{ts}.{payload}"
    signature = hmac.new(
        secret.encode(),
        signed_content.encode(),
        hashlib.sha256,
    ).hexdigest()
    return f"t={ts},v1={signature}"


def test_valid_signature_verifies():
    header = _sign(SECRET, PAYLOAD)
    assert verify_webhook_signature(SECRET, header, PAYLOAD) is True


def test_wrong_secret_rejects():
    header = _sign(SECRET, PAYLOAD)
    assert verify_webhook_signature("wrong_secret", header, PAYLOAD) is False


def test_expired_timestamp_rejects():
    old_timestamp = int(time.time()) - 400  # 400 seconds ago, beyond 300s tolerance
    header = _sign(SECRET, PAYLOAD, timestamp=old_timestamp)
    assert verify_webhook_signature(SECRET, header, PAYLOAD) is False


def test_expired_timestamp_with_custom_tolerance():
    old_timestamp = int(time.time()) - 400
    header = _sign(SECRET, PAYLOAD, timestamp=old_timestamp)
    # With a larger tolerance, the signature should be accepted
    assert verify_webhook_signature(SECRET, header, PAYLOAD, tolerance=500) is True


def test_tampered_payload_rejects():
    header = _sign(SECRET, PAYLOAD)
    tampered = PAYLOAD.replace("usr_abc123", "usr_evil666")
    assert verify_webhook_signature(SECRET, header, tampered) is False


def test_malformed_header_rejects():
    assert verify_webhook_signature(SECRET, "garbage", PAYLOAD) is False


def test_missing_timestamp_rejects():
    header = "v1=abcdef1234567890"
    assert verify_webhook_signature(SECRET, header, PAYLOAD) is False


def test_missing_signature_rejects():
    header = f"t={int(time.time())}"
    assert verify_webhook_signature(SECRET, header, PAYLOAD) is False
