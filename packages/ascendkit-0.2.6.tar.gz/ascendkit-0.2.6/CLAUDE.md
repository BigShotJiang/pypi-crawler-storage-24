# SDK Python — `ascendkit`

Python 3.10+ SDK. httpx (async), published to PyPI.

## Rules
- MUST use `httpx` — not `requests`. Support both sync and async patterns.
- Logger: drop-in for `logging` module. Keyword args for context: `logger.info("msg", port=3000)`
- Batch logs (5s / 100 events) via `POST /api/logs/ingest` — NEVER send one-at-a-time
- Flush on interpreter shutdown via `atexit`
- All public functions MUST have type annotations
- Gracefully handle network failures on flush — buffer and retry, NEVER crash host app
- In async frameworks, use `httpx.AsyncClient` — sync client blocks the event loop

## Release & Publish
Trigger: GitHub release (`release: published`) → `python -m build` → PyPI trusted publishing (`pypa/gh-action-pypi-publish`)
To ship: bump `pyproject.toml` version on `dev` → merge to `main` → create GitHub release tagged `vX.Y.Z`

## GUIDANCE
You are a thin client, rely on backend api for business logic validation
