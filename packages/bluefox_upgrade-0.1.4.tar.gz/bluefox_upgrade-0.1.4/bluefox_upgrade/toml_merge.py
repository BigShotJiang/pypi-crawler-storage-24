import re
from pathlib import Path
from typing import Any

import tomlkit


def _load_pyproject(project_dir: Path) -> tomlkit.TOMLDocument:
    path = project_dir / "pyproject.toml"
    return tomlkit.parse(path.read_text())


def _save_pyproject(project_dir: Path, doc: tomlkit.TOMLDocument) -> None:
    path = project_dir / "pyproject.toml"
    path.write_text(tomlkit.dumps(doc))


def _get_dependencies(doc: tomlkit.TOMLDocument) -> Any:
    return doc["project"]["dependencies"]  # type: ignore[index]


def _parse_dep_name(dep_string: str) -> str:
    """Extract package name from a dependency string like 'fastapi>=0.115'."""
    match = re.match(r"^([a-zA-Z0-9_-]+)", dep_string)
    return match.group(1) if match else dep_string


def find_dependency(project_dir: Path, name: str) -> str | None:
    """Find a dependency by name. Returns the full spec string or None."""
    doc = _load_pyproject(project_dir)
    deps = _get_dependencies(doc)
    for dep in deps:
        if _parse_dep_name(str(dep)) == name:
            return str(dep)
    return None


def add_dependency(project_dir: Path, name: str, spec: str) -> bool:
    """Add a dependency. Returns False if already exists."""
    doc = _load_pyproject(project_dir)
    deps = _get_dependencies(doc)

    for dep in deps:
        if _parse_dep_name(str(dep)) == name:
            return False

    deps.append(f"{name}{spec}")
    _save_pyproject(project_dir, doc)
    return True


def bump_dependency(project_dir: Path, name: str, old_spec: str, new_spec: str) -> bool | None:
    """Bump a dependency version. Returns True on success, False if not found, None if conflict."""
    doc = _load_pyproject(project_dir)
    deps = _get_dependencies(doc)

    for i, dep in enumerate(deps):
        if _parse_dep_name(str(dep)) == name:
            expected = f"{name}{old_spec}"
            if str(dep) != expected:
                return None  # conflict — user changed it
            deps[i] = f"{name}{new_spec}"
            _save_pyproject(project_dir, doc)
            return True

    return False  # not found


def remove_dependency(project_dir: Path, name: str) -> bool:
    """Remove a dependency. Returns False if not found."""
    doc = _load_pyproject(project_dir)
    deps = _get_dependencies(doc)

    for i, dep in enumerate(deps):
        if _parse_dep_name(str(dep)) == name:
            del deps[i]
            _save_pyproject(project_dir, doc)
            return True

    return False
