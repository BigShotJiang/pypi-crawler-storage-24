from datetime import UTC, datetime
from pathlib import Path

import yaml
from pydantic import BaseModel, ValidationError

from bluefox_upgrade.exceptions import UpgradeError
from bluefox_upgrade.hashing import hash_file

DOTFILE_NAME = ".bluefox"


class TrackedFile(BaseModel):
    managed: str  # "full", "sections", "structured"
    hash: str | None = None  # SHA-256, not used for "structured"
    markers: list[str] | None = None  # only for "sections"


class DotBluefox(BaseModel):
    cli_version: str
    generated_at: str  # ISO date string
    upgraded_at: str | None = None  # ISO date string
    files: dict[str, TrackedFile] = {}


def load_dotfile(project_dir: Path) -> DotBluefox:
    """Read .bluefox from project directory. Raises UpgradeError if missing/invalid."""
    dotfile_path = project_dir / DOTFILE_NAME

    if not dotfile_path.exists():
        raise UpgradeError("No .bluefox file found. Is this a BFF project?")

    try:
        raw = yaml.safe_load(dotfile_path.read_text())
    except yaml.YAMLError as e:
        raise UpgradeError(f"Invalid .bluefox file: {e}") from e

    if not isinstance(raw, dict):
        raise UpgradeError("Invalid .bluefox file: expected a YAML mapping")

    try:
        return DotBluefox.model_validate(raw)
    except ValidationError as e:
        raise UpgradeError(f"Invalid .bluefox file: {e}") from e


def save_dotfile(project_dir: Path, dotfile: DotBluefox) -> None:
    """Write .bluefox to project directory."""
    dotfile_path = project_dir / DOTFILE_NAME
    data = dotfile.model_dump(exclude_none=True)
    dotfile_path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))


def create_dotfile(
    project_dir: Path,
    cli_version: str,
    tracked_files: dict[str, TrackedFile],
) -> DotBluefox:
    """Create a new .bluefox file for a freshly initialized project.

    Hashes all full-managed and sections-managed files from disk.
    """
    files: dict[str, TrackedFile] = {}

    for path, tf in tracked_files.items():
        file_path = project_dir / path
        if tf.managed in ("full", "sections") and file_path.exists():
            files[path] = TrackedFile(
                managed=tf.managed,
                hash=hash_file(file_path),
                markers=tf.markers,
            )
        else:
            files[path] = tf.model_copy()

    dotfile = DotBluefox(
        cli_version=cli_version,
        generated_at=datetime.now(UTC).strftime("%Y-%m-%d"),
        files=files,
    )
    save_dotfile(project_dir, dotfile)
    return dotfile


def full_tracked(path: str) -> tuple[str, TrackedFile]:
    """Convenience for declaring a full-managed file."""
    return (path, TrackedFile(managed="full"))


def sections_tracked(path: str, markers: list[str]) -> tuple[str, TrackedFile]:
    """Convenience for declaring a sections-managed file."""
    return (path, TrackedFile(managed="sections", markers=markers))


def structured_tracked(path: str) -> tuple[str, TrackedFile]:
    """Convenience for declaring a structured-managed file."""
    return (path, TrackedFile(managed="structured"))
