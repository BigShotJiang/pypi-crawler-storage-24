class UpgradeError(Exception):
    """Raised when an upgrade operation fails."""
