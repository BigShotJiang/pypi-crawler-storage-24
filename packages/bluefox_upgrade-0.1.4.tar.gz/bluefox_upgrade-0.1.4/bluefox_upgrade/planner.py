from pathlib import Path

from pydantic import BaseModel

from bluefox_upgrade.collapse import collapse_operations
from bluefox_upgrade.dotfile import DotBluefox
from bluefox_upgrade.exceptions import UpgradeError
from bluefox_upgrade.models import AnyOperation, Upgrade
from bluefox_upgrade.operations import ConflictResult


class UpgradePlan(BaseModel):
    current_version: str
    target_version: str
    upgrades: list[Upgrade]
    operations: list[AnyOperation]


class ConflictReport(BaseModel):
    operation: AnyOperation
    conflict: ConflictResult


def plan_upgrade(
    dotfile: DotBluefox,
    available_upgrades: list[Upgrade],
    target_version: str,
) -> UpgradePlan:
    """Compute the upgrade path from current version to target.

    Raises UpgradeError if no path exists.
    """
    current = dotfile.cli_version

    if current == target_version:
        return UpgradePlan(
            current_version=current,
            target_version=target_version,
            upgrades=[],
            operations=[],
        )

    # Build a lookup: from_version -> Upgrade
    by_from: dict[str, Upgrade] = {}
    for upgrade in available_upgrades:
        by_from[upgrade.from_version] = upgrade

    # Walk the chain
    chain: list[Upgrade] = []
    version = current
    visited: set[str] = set()

    while version != target_version:
        if version in visited:
            raise UpgradeError(f"Cycle detected at version {version}")
        visited.add(version)

        upgrade = by_from.get(version)
        if upgrade is None:
            raise UpgradeError(f"No upgrade path from {version} to {target_version}")

        chain.append(upgrade)
        version = upgrade.to_version

    # Flatten operations
    all_ops: list[AnyOperation] = []
    for upgrade in chain:
        all_ops.extend(upgrade.operations)

    return UpgradePlan(
        current_version=current,
        target_version=target_version,
        upgrades=chain,
        operations=collapse_operations(all_ops),
    )


def check_conflicts(
    plan: UpgradePlan,
    project_dir: Path,
    dotfile: DotBluefox,
) -> list[ConflictReport]:
    """Check all operations for conflicts. Returns list of conflicts (empty = clean)."""
    reports: list[ConflictReport] = []
    for op in plan.operations:
        result = op.check_conflict(project_dir, dotfile)
        if result.has_conflict:
            reports.append(ConflictReport(operation=op, conflict=result))
    return reports
