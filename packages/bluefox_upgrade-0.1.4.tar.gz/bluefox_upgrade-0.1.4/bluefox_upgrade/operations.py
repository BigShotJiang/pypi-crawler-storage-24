from abc import ABC, abstractmethod
from collections.abc import Callable
from pathlib import Path

from pydantic import BaseModel

from bluefox_upgrade.dotfile import DotBluefox, TrackedFile
from bluefox_upgrade.hashing import file_is_modified, hash_file
from bluefox_upgrade.sections import find_section, replace_section
from bluefox_upgrade.toml_merge import add_dependency, bump_dependency, find_dependency, remove_dependency


class ConflictResult(BaseModel):
    has_conflict: bool
    message: str | None = None


class Operation(ABC):
    @abstractmethod
    def check_conflict(self, project_dir: Path, dotfile: DotBluefox) -> ConflictResult:
        """Can this operation be applied safely?"""

    @abstractmethod
    def apply(self, project_dir: Path, dotfile: DotBluefox, render_template: Callable[[str], str]) -> None:
        """Execute the operation. Mutates dotfile in-place."""

    @abstractmethod
    def describe(self) -> str:
        """Human-readable description of what this does."""


class ReplaceFile(Operation, BaseModel):
    path: str
    template: str
    description: str

    def check_conflict(self, project_dir: Path, dotfile: DotBluefox) -> ConflictResult:
        tracked = dotfile.files.get(self.path)
        if not tracked or not tracked.hash:
            return ConflictResult(has_conflict=False)

        file_path = project_dir / self.path
        if not file_path.exists():
            return ConflictResult(has_conflict=False)

        if file_is_modified(file_path, tracked.hash):
            return ConflictResult(
                has_conflict=True,
                message=f"{self.path} — modified since last upgrade",
            )

        return ConflictResult(has_conflict=False)

    def apply(self, project_dir: Path, dotfile: DotBluefox, render_template: Callable[[str], str]) -> None:
        file_path = project_dir / self.path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        content = render_template(self.template)
        file_path.write_text(content)

        dotfile.files[self.path] = TrackedFile(
            managed="full",
            hash=hash_file(file_path),
        )

    def describe(self) -> str:
        return f"{self.path} — {self.description}"


class CreateFile(Operation, BaseModel):
    path: str
    template: str
    description: str

    def check_conflict(self, project_dir: Path, dotfile: DotBluefox) -> ConflictResult:
        file_path = project_dir / self.path
        if file_path.exists():
            return ConflictResult(
                has_conflict=True,
                message=f"{self.path} — file already exists",
            )
        return ConflictResult(has_conflict=False)

    def apply(self, project_dir: Path, dotfile: DotBluefox, render_template: Callable[[str], str]) -> None:
        file_path = project_dir / self.path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        content = render_template(self.template)
        file_path.write_text(content)

        dotfile.files[self.path] = TrackedFile(
            managed="full",
            hash=hash_file(file_path),
        )

    def describe(self) -> str:
        return f"{self.path} — new file: {self.description}"


class RemoveFile(Operation, BaseModel):
    path: str
    description: str

    def check_conflict(self, project_dir: Path, dotfile: DotBluefox) -> ConflictResult:
        tracked = dotfile.files.get(self.path)
        if not tracked or not tracked.hash:
            return ConflictResult(has_conflict=False)

        file_path = project_dir / self.path
        if not file_path.exists():
            return ConflictResult(has_conflict=False)

        if file_is_modified(file_path, tracked.hash):
            return ConflictResult(
                has_conflict=True,
                message=f"{self.path} — modified since last upgrade",
            )

        return ConflictResult(has_conflict=False)

    def apply(self, project_dir: Path, dotfile: DotBluefox, render_template: Callable[[str], str]) -> None:
        file_path = project_dir / self.path
        if file_path.exists():
            file_path.unlink()
        dotfile.files.pop(self.path, None)

    def describe(self) -> str:
        return f"{self.path} — removed: {self.description}"


class UpdateSection(Operation, BaseModel):
    path: str
    marker: str
    content: str
    description: str

    def check_conflict(self, project_dir: Path, dotfile: DotBluefox) -> ConflictResult:
        file_path = project_dir / self.path
        if not file_path.exists():
            return ConflictResult(
                has_conflict=True,
                message=f"{self.path} — file not found",
            )

        file_content = file_path.read_text()
        if find_section(file_content, self.marker) is None:
            return ConflictResult(
                has_conflict=True,
                message=f"{self.path} — marker '{self.marker}' not found",
            )

        return ConflictResult(has_conflict=False)

    def apply(self, project_dir: Path, dotfile: DotBluefox, render_template: Callable[[str], str]) -> None:
        file_path = project_dir / self.path
        file_content = file_path.read_text()
        updated = replace_section(file_content, self.marker, self.content)
        file_path.write_text(updated)

        existing = dotfile.files.get(self.path)
        dotfile.files[self.path] = TrackedFile(
            managed="sections",
            hash=hash_file(file_path),
            markers=existing.markers if existing else None,
        )

    def describe(self) -> str:
        return f"{self.path} [{self.marker}] — {self.description}"


class AddDependency(Operation, BaseModel):
    name: str
    spec: str
    description: str | None = None

    def check_conflict(self, project_dir: Path, dotfile: DotBluefox) -> ConflictResult:
        existing = find_dependency(project_dir, self.name)
        if existing is not None:
            return ConflictResult(
                has_conflict=True,
                message=f"pyproject.toml — {self.name} already exists ({existing})",
            )
        return ConflictResult(has_conflict=False)

    def apply(self, project_dir: Path, dotfile: DotBluefox, render_template: Callable[[str], str]) -> None:
        add_dependency(project_dir, self.name, self.spec)

    def describe(self) -> str:
        desc = self.description or f"added {self.name} {self.spec}"
        return f"pyproject.toml — {desc}"


class BumpDependency(Operation, BaseModel):
    name: str
    old_spec: str
    new_spec: str
    description: str | None = None

    def check_conflict(self, project_dir: Path, dotfile: DotBluefox) -> ConflictResult:
        existing = find_dependency(project_dir, self.name)
        if existing is None:
            return ConflictResult(
                has_conflict=True,
                message=f"pyproject.toml — {self.name} not found",
            )
        expected = f"{self.name}{self.old_spec}"
        if existing != expected:
            return ConflictResult(
                has_conflict=True,
                message=f"pyproject.toml — {self.name} has unexpected spec: {existing} (expected {expected})",
            )
        return ConflictResult(has_conflict=False)

    def apply(self, project_dir: Path, dotfile: DotBluefox, render_template: Callable[[str], str]) -> None:
        bump_dependency(project_dir, self.name, self.old_spec, self.new_spec)

    def describe(self) -> str:
        desc = self.description or f"bumped {self.name} from {self.old_spec} to {self.new_spec}"
        return f"pyproject.toml — {desc}"


class RemoveDependency(Operation, BaseModel):
    name: str
    description: str | None = None

    def check_conflict(self, project_dir: Path, dotfile: DotBluefox) -> ConflictResult:
        existing = find_dependency(project_dir, self.name)
        if existing is None:
            return ConflictResult(
                has_conflict=True,
                message=f"pyproject.toml — {self.name} not found (already removed?)",
            )
        return ConflictResult(has_conflict=False)

    def apply(self, project_dir: Path, dotfile: DotBluefox, render_template: Callable[[str], str]) -> None:
        remove_dependency(project_dir, self.name)

    def describe(self) -> str:
        desc = self.description or f"removed {self.name}"
        return f"pyproject.toml — {desc}"
