from bluefox_upgrade.operations import (
    AddDependency,
    BumpDependency,
    CreateFile,
    RemoveDependency,
    RemoveFile,
    ReplaceFile,
    UpdateSection,
)


def collapse_operations(operations: list) -> list:
    """Remove redundant operations from a flattened upgrade chain."""
    ops = list(operations)
    ops = _collapse_file_ops(ops)
    ops = _collapse_section_ops(ops)
    ops = _collapse_dep_ops(ops)
    return ops


def _collapse_file_ops(ops: list) -> list:
    """Collapse file operations (ReplaceFile, CreateFile, RemoveFile)."""
    # Track the effective operation per path
    effective: dict[str, list[int]] = {}
    for i, op in enumerate(ops):
        if isinstance(op, ReplaceFile | CreateFile | RemoveFile):
            effective.setdefault(op.path, []).append(i)

    remove_indices: set[int] = set()
    replacements: dict[int, object] = {}

    for _path, indices in effective.items():
        if len(indices) < 2:
            continue

        # Walk through pairs to apply collapse rules
        # We reduce from left to right
        surviving_idx = indices[0]
        for next_idx in indices[1:]:
            first = replacements.get(surviving_idx, ops[surviving_idx])
            second = ops[next_idx]

            if isinstance(first, ReplaceFile) and isinstance(second, ReplaceFile):
                # Multiple ReplaceFile: keep last only
                remove_indices.add(surviving_idx)
                surviving_idx = next_idx

            elif isinstance(first, CreateFile) and isinstance(second, ReplaceFile):
                # CreateFile then ReplaceFile: CreateFile with final template
                replacements[surviving_idx] = CreateFile(
                    path=first.path,
                    template=second.template,
                    description=second.description,
                )
                remove_indices.add(next_idx)

            elif isinstance(first, CreateFile) and isinstance(second, RemoveFile):
                # CreateFile then RemoveFile: both removed
                remove_indices.add(surviving_idx)
                remove_indices.add(next_idx)
                surviving_idx = next_idx  # won't matter, both gone

            elif isinstance(first, ReplaceFile) and isinstance(second, RemoveFile):
                # ReplaceFile then RemoveFile: RemoveFile only
                remove_indices.add(surviving_idx)
                surviving_idx = next_idx

            else:
                surviving_idx = next_idx

    result = []
    for i, op in enumerate(ops):
        if i in remove_indices:
            continue
        if i in replacements:
            result.append(replacements[i])
        else:
            result.append(op)
    return result


def _collapse_section_ops(ops: list) -> list:
    """Collapse UpdateSection operations on same path + marker."""
    # Track by (path, marker) -> list of indices
    effective: dict[tuple[str, str], list[int]] = {}
    for i, op in enumerate(ops):
        if isinstance(op, UpdateSection):
            key = (op.path, op.marker)
            effective.setdefault(key, []).append(i)

    remove_indices: set[int] = set()
    for _key, indices in effective.items():
        if len(indices) < 2:
            continue
        # Keep last only
        for idx in indices[:-1]:
            remove_indices.add(idx)

    return [op for i, op in enumerate(ops) if i not in remove_indices]


def _collapse_dep_ops(ops: list) -> list:
    """Collapse dependency operations on same package."""
    # Track by package name -> list of (index, op)
    effective: dict[str, list[tuple[int, object]]] = {}
    for i, op in enumerate(ops):
        if isinstance(op, AddDependency | BumpDependency | RemoveDependency):
            effective.setdefault(op.name, []).append((i, op))

    remove_indices: set[int] = set()
    replacements: dict[int, object] = {}

    for _name, entries in effective.items():
        if len(entries) < 2:
            continue

        surviving_idx, surviving_op = entries[0]
        for next_idx, next_op in entries[1:]:
            first = replacements.get(surviving_idx, surviving_op)

            if isinstance(first, AddDependency) and isinstance(next_op, BumpDependency):
                # AddDependency then BumpDependency: AddDependency with final spec
                replacements[surviving_idx] = AddDependency(
                    name=first.name,
                    spec=next_op.new_spec,
                    description=first.description,
                )
                remove_indices.add(next_idx)

            elif isinstance(first, AddDependency) and isinstance(next_op, RemoveDependency):
                # AddDependency then RemoveDependency: both removed
                remove_indices.add(surviving_idx)
                remove_indices.add(next_idx)
                surviving_idx, surviving_op = next_idx, next_op

            elif isinstance(first, BumpDependency) and isinstance(next_op, BumpDependency):
                # Multiple BumpDependency: single bump from first old_spec to last new_spec
                replacements[surviving_idx] = BumpDependency(
                    name=first.name,
                    old_spec=first.old_spec,
                    new_spec=next_op.new_spec,
                    description=next_op.description,
                )
                remove_indices.add(next_idx)

            else:
                surviving_idx, surviving_op = next_idx, next_op

    result = []
    for i, op in enumerate(ops):
        if i in remove_indices:
            continue
        if i in replacements:
            result.append(replacements[i])
        else:
            result.append(op)
    return result
