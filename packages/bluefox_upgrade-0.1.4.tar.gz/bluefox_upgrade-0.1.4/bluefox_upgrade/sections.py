import re


def find_section(content: str, marker: str) -> tuple[int, int] | None:
    """Find start and end positions of a marker section.

    Returns (start, end) byte positions of the content BETWEEN markers,
    or None if markers not found.
    """
    start_pattern = re.compile(rf"^\s*# --- {re.escape(marker)} ---\s*$", re.MULTILINE)
    end_pattern = re.compile(rf"^\s*# --- end:{re.escape(marker)} ---\s*$", re.MULTILINE)

    start_match = start_pattern.search(content)
    if not start_match:
        return None

    end_match = end_pattern.search(content, start_match.end())
    if not end_match:
        return None

    # Content starts after the start marker line (including its newline)
    content_start = start_match.end()
    if content_start < len(content) and content[content_start] == "\n":
        content_start += 1

    # Content ends at the beginning of the end marker line
    content_end = end_match.start()

    return (content_start, content_end)


def replace_section(content: str, marker: str, new_content: str) -> str:
    """Replace content between markers. Preserves marker lines."""
    positions = find_section(content, marker)
    if positions is None:
        raise ValueError(f"Marker '{marker}' not found in content")

    start, end = positions
    return content[:start] + new_content + content[end:]
