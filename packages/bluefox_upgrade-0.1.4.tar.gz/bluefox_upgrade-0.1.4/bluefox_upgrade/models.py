from pydantic import BaseModel

from bluefox_upgrade.operations import (
    AddDependency,
    BumpDependency,
    CreateFile,
    RemoveDependency,
    RemoveFile,
    ReplaceFile,
    UpdateSection,
)

AnyOperation = (
    ReplaceFile
    | CreateFile
    | RemoveFile
    | UpdateSection
    | AddDependency
    | BumpDependency
    | RemoveDependency
)


class Upgrade(BaseModel):
    from_version: str
    to_version: str
    description: str
    operations: list[AnyOperation]
