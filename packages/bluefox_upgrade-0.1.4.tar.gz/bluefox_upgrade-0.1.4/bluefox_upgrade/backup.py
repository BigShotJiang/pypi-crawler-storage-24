import shutil
from datetime import UTC, datetime
from pathlib import Path


def backup_file(project_dir: Path, file_path: str, timestamp: str | None = None) -> Path:
    """Copy a file to .bluefox-backups/<timestamp>/<file_path>.

    Returns the backup path.
    """
    if timestamp is None:
        timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S")

    source = project_dir / file_path
    backup_dir = project_dir / ".bluefox-backups" / timestamp
    dest = backup_dir / file_path

    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)

    return dest
