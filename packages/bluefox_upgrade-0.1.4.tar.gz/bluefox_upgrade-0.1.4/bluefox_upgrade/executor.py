from collections.abc import Callable
from pathlib import Path

from pydantic import BaseModel

from bluefox_upgrade.backup import backup_file
from bluefox_upgrade.dotfile import DotBluefox
from bluefox_upgrade.exceptions import UpgradeError
from bluefox_upgrade.models import AnyOperation
from bluefox_upgrade.operations import CreateFile, RemoveFile, ReplaceFile, UpdateSection
from bluefox_upgrade.planner import UpgradePlan


class ExecutionResult(BaseModel):
    applied: list[AnyOperation] = []
    skipped: list[tuple[AnyOperation, str]] = []
    backed_up: list[tuple[str, Path]] = []


def _get_file_path(op: AnyOperation) -> str | None:
    """Get the file path from an operation, if it has one."""
    if isinstance(op, ReplaceFile | CreateFile | RemoveFile | UpdateSection):
        return op.path
    return None


def execute_upgrade(
    plan: UpgradePlan,
    project_dir: Path,
    dotfile: DotBluefox,
    render_template: Callable[[str], str],
    skip_conflicts: bool = False,
    force: bool = False,
) -> ExecutionResult:
    """Apply all operations in the plan.

    - Default: abort on first conflict (raise UpgradeError)
    - skip_conflicts: skip conflicting operations, apply the rest
    - force: backup conflicting files and overwrite

    Mutates dotfile. Caller is responsible for saving it after.
    """
    result = ExecutionResult()

    for op in plan.operations:
        conflict = op.check_conflict(project_dir, dotfile)

        if conflict.has_conflict:
            if force:
                file_path = _get_file_path(op)
                if file_path and (project_dir / file_path).exists():
                    backup_path = backup_file(project_dir, file_path)
                    result.backed_up.append((file_path, backup_path))
                op.apply(project_dir, dotfile, render_template)
                result.applied.append(op)
            elif skip_conflicts:
                result.skipped.append((op, conflict.message or "conflict"))
            else:
                raise UpgradeError(f"Conflict: {conflict.message}")
        else:
            op.apply(project_dir, dotfile, render_template)
            result.applied.append(op)

    return result
