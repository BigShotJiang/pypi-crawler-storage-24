import hashlib
from pathlib import Path


def hash_file(path: Path) -> str:
    """SHA-256 hash of file contents. Returns 'sha256:...' string."""
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return f"sha256:{digest}"


def file_is_modified(path: Path, expected_hash: str) -> bool:
    """True if current file hash differs from expected hash."""
    return hash_file(path) != expected_hash
