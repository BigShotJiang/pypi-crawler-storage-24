from bluefox_upgrade.collapse import collapse_operations
from bluefox_upgrade.dotfile import (
    DotBluefox,
    TrackedFile,
    create_dotfile,
    full_tracked,
    load_dotfile,
    save_dotfile,
    sections_tracked,
    structured_tracked,
)
from bluefox_upgrade.exceptions import UpgradeError
from bluefox_upgrade.executor import ExecutionResult, execute_upgrade
from bluefox_upgrade.models import Upgrade
from bluefox_upgrade.operations import (
    AddDependency,
    BumpDependency,
    CreateFile,
    Operation,
    RemoveDependency,
    RemoveFile,
    ReplaceFile,
    UpdateSection,
)
from bluefox_upgrade.planner import (
    ConflictReport,
    UpgradePlan,
    check_conflicts,
    plan_upgrade,
)

__all__ = [
    "AddDependency",
    "BumpDependency",
    "ConflictReport",
    "CreateFile",
    "DotBluefox",
    "ExecutionResult",
    "Operation",
    "RemoveDependency",
    "RemoveFile",
    "ReplaceFile",
    "TrackedFile",
    "UpdateSection",
    "Upgrade",
    "UpgradeError",
    "UpgradePlan",
    "check_conflicts",
    "collapse_operations",
    "create_dotfile",
    "execute_upgrade",
    "full_tracked",
    "load_dotfile",
    "plan_upgrade",
    "save_dotfile",
    "sections_tracked",
    "structured_tracked",
]
