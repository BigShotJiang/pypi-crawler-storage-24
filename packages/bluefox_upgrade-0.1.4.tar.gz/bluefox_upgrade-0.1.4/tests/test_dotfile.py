import pytest

from bluefox_upgrade.dotfile import (
    DotBluefox,
    TrackedFile,
    create_dotfile,
    full_tracked,
    load_dotfile,
    save_dotfile,
    sections_tracked,
    structured_tracked,
)
from bluefox_upgrade.exceptions import UpgradeError


class TestDotfileModel:
    def test_create_dotbluefox(self):
        dotfile = DotBluefox(
            cli_version="0.1.0",
            generated_at="2026-03-15",
            files={
                "Dockerfile": TrackedFile(managed="full", hash="sha256:abc123"),
                "app/__init__.py": TrackedFile(
                    managed="sections",
                    hash="sha256:def456",
                    markers=["bluefox:framework-imports", "bluefox:routers"],
                ),
                "pyproject.toml": TrackedFile(managed="structured"),
            },
        )

        assert dotfile.cli_version == "0.1.0"
        assert dotfile.generated_at == "2026-03-15"
        assert dotfile.upgraded_at is None
        assert len(dotfile.files) == 3

    def test_tracked_file_full(self):
        tf = TrackedFile(managed="full", hash="sha256:abc123")
        assert tf.managed == "full"
        assert tf.hash == "sha256:abc123"
        assert tf.markers is None

    def test_tracked_file_sections(self):
        tf = TrackedFile(
            managed="sections",
            hash="sha256:abc123",
            markers=["bluefox:framework-imports"],
        )
        assert tf.managed == "sections"
        assert tf.markers == ["bluefox:framework-imports"]

    def test_tracked_file_structured(self):
        tf = TrackedFile(managed="structured")
        assert tf.managed == "structured"
        assert tf.hash is None
        assert tf.markers is None

    def test_dotbluefox_with_upgraded_at(self):
        dotfile = DotBluefox(
            cli_version="0.2.0",
            generated_at="2026-03-15",
            upgraded_at="2026-03-16",
            files={},
        )
        assert dotfile.upgraded_at == "2026-03-16"

    def test_dotbluefox_empty_files(self):
        dotfile = DotBluefox(
            cli_version="0.1.0",
            generated_at="2026-03-15",
        )
        assert dotfile.files == {}


class TestLoadDotfile:
    def test_load_valid_dotfile(self, tmp_path):
        (tmp_path / ".bluefox").write_text(
            "cli_version: '0.1.0'\n"
            "generated_at: '2026-03-15'\n"
            "files:\n"
            "  Dockerfile:\n"
            "    managed: full\n"
            "    hash: 'sha256:abc123'\n"
            "  app/__init__.py:\n"
            "    managed: sections\n"
            "    hash: 'sha256:def456'\n"
            "    markers:\n"
            "      - bluefox:framework-imports\n"
            "      - bluefox:routers\n"
            "  pyproject.toml:\n"
            "    managed: structured\n"
        )

        dotfile = load_dotfile(tmp_path)

        assert dotfile.cli_version == "0.1.0"
        assert dotfile.generated_at == "2026-03-15"
        assert len(dotfile.files) == 3
        assert dotfile.files["Dockerfile"].managed == "full"
        assert dotfile.files["Dockerfile"].hash == "sha256:abc123"
        assert dotfile.files["app/__init__.py"].markers == [
            "bluefox:framework-imports",
            "bluefox:routers",
        ]
        assert dotfile.files["pyproject.toml"].managed == "structured"
        assert dotfile.files["pyproject.toml"].hash is None

    def test_load_with_upgraded_at(self, tmp_path):
        (tmp_path / ".bluefox").write_text(
            "cli_version: '0.2.0'\n"
            "generated_at: '2026-03-15'\n"
            "upgraded_at: '2026-03-16'\n"
            "files: {}\n"
        )

        dotfile = load_dotfile(tmp_path)
        assert dotfile.upgraded_at == "2026-03-16"

    def test_load_missing_file(self, tmp_path):
        with pytest.raises(UpgradeError, match="No .bluefox file found"):
            load_dotfile(tmp_path)

    def test_load_invalid_yaml(self, tmp_path):
        (tmp_path / ".bluefox").write_text(":\n  :\n  - [invalid")

        with pytest.raises(UpgradeError, match="Invalid .bluefox file"):
            load_dotfile(tmp_path)

    def test_load_missing_required_fields(self, tmp_path):
        (tmp_path / ".bluefox").write_text("files: {}\n")

        with pytest.raises(UpgradeError, match="Invalid .bluefox file"):
            load_dotfile(tmp_path)

    def test_load_not_a_mapping(self, tmp_path):
        (tmp_path / ".bluefox").write_text("- just\n- a\n- list\n")

        with pytest.raises(UpgradeError, match="expected a YAML mapping"):
            load_dotfile(tmp_path)


class TestSaveDotfile:
    def test_save_and_load_round_trip(self, tmp_path):
        original = DotBluefox(
            cli_version="0.1.0",
            generated_at="2026-03-15",
            files={
                "Dockerfile": TrackedFile(managed="full", hash="sha256:abc123"),
                "app/__init__.py": TrackedFile(
                    managed="sections",
                    hash="sha256:def456",
                    markers=["bluefox:framework-imports", "bluefox:routers"],
                ),
                "pyproject.toml": TrackedFile(managed="structured"),
            },
        )

        save_dotfile(tmp_path, original)
        loaded = load_dotfile(tmp_path)

        assert loaded == original

    def test_save_with_upgraded_at(self, tmp_path):
        original = DotBluefox(
            cli_version="0.2.0",
            generated_at="2026-03-15",
            upgraded_at="2026-03-16",
            files={"Dockerfile": TrackedFile(managed="full", hash="sha256:abc")},
        )

        save_dotfile(tmp_path, original)
        loaded = load_dotfile(tmp_path)

        assert loaded == original
        assert loaded.upgraded_at == "2026-03-16"

    def test_save_excludes_none_values(self, tmp_path):
        dotfile = DotBluefox(
            cli_version="0.1.0",
            generated_at="2026-03-15",
            files={"Dockerfile": TrackedFile(managed="full", hash="sha256:abc")},
        )

        save_dotfile(tmp_path, dotfile)
        raw = (tmp_path / ".bluefox").read_text()

        assert "upgraded_at" not in raw
        assert "markers" not in raw

    def test_save_creates_file(self, tmp_path):
        dotfile = DotBluefox(
            cli_version="0.1.0",
            generated_at="2026-03-15",
        )

        assert not (tmp_path / ".bluefox").exists()
        save_dotfile(tmp_path, dotfile)
        assert (tmp_path / ".bluefox").exists()


class TestCreateDotfile:
    def test_creates_dotfile_with_hashes(self, tmp_path):
        (tmp_path / "Dockerfile").write_text("FROM python:3.12")
        tracked = dict([full_tracked("Dockerfile")])

        dotfile = create_dotfile(tmp_path, "0.1.0", tracked)

        assert dotfile.cli_version == "0.1.0"
        assert dotfile.files["Dockerfile"].managed == "full"
        assert dotfile.files["Dockerfile"].hash is not None
        assert dotfile.files["Dockerfile"].hash.startswith("sha256:")

    def test_saves_to_disk(self, tmp_path):
        (tmp_path / "app.py").write_text("print('hello')")
        tracked = dict([full_tracked("app.py")])

        create_dotfile(tmp_path, "0.1.0", tracked)

        assert (tmp_path / ".bluefox").exists()
        loaded = load_dotfile(tmp_path)
        assert loaded.cli_version == "0.1.0"

    def test_sections_tracked_with_markers(self, tmp_path):
        (tmp_path / "main.py").write_text("# app code")
        tracked = dict([sections_tracked("main.py", ["routers", "middleware"])])

        dotfile = create_dotfile(tmp_path, "0.1.0", tracked)

        assert dotfile.files["main.py"].managed == "sections"
        assert dotfile.files["main.py"].markers == ["routers", "middleware"]
        assert dotfile.files["main.py"].hash is not None

    def test_structured_tracked_no_hash(self, tmp_path):
        (tmp_path / "pyproject.toml").write_text("[project]\nname = 'app'")
        tracked = dict([structured_tracked("pyproject.toml")])

        dotfile = create_dotfile(tmp_path, "0.1.0", tracked)

        assert dotfile.files["pyproject.toml"].managed == "structured"
        assert dotfile.files["pyproject.toml"].hash is None

    def test_generated_at_set(self, tmp_path):
        tracked = dict([structured_tracked("pyproject.toml")])

        dotfile = create_dotfile(tmp_path, "0.1.0", tracked)

        assert dotfile.generated_at  # non-empty date string

    def test_multiple_file_types(self, tmp_path):
        (tmp_path / "Dockerfile").write_text("FROM python")
        (tmp_path / "main.py").write_text("# code")
        (tmp_path / "pyproject.toml").write_text("[project]")
        tracked = dict([
            full_tracked("Dockerfile"),
            sections_tracked("main.py", ["routers"]),
            structured_tracked("pyproject.toml"),
        ])

        dotfile = create_dotfile(tmp_path, "0.1.0", tracked)

        assert len(dotfile.files) == 3
        assert dotfile.files["Dockerfile"].hash is not None
        assert dotfile.files["main.py"].hash is not None
        assert dotfile.files["pyproject.toml"].hash is None


class TestConvenienceHelpers:
    def test_full_tracked(self):
        path, tf = full_tracked("Dockerfile")
        assert path == "Dockerfile"
        assert tf.managed == "full"
        assert tf.hash is None

    def test_sections_tracked(self):
        path, tf = sections_tracked("main.py", ["routers"])
        assert path == "main.py"
        assert tf.managed == "sections"
        assert tf.markers == ["routers"]

    def test_structured_tracked(self):
        path, tf = structured_tracked("pyproject.toml")
        assert path == "pyproject.toml"
        assert tf.managed == "structured"
