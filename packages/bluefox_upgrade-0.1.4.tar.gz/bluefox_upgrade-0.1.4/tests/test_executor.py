import pytest

from bluefox_upgrade.dotfile import DotBluefox, TrackedFile
from bluefox_upgrade.exceptions import UpgradeError
from bluefox_upgrade.executor import execute_upgrade
from bluefox_upgrade.models import Upgrade
from bluefox_upgrade.operations import CreateFile, ReplaceFile
from bluefox_upgrade.planner import UpgradePlan, plan_upgrade


def make_dotfile(version: str = "0.1.0") -> DotBluefox:
    return DotBluefox(
        cli_version=version,
        generated_at="2026-03-15",
    )


def simple_renderer(template: str) -> str:
    return f"rendered:{template}"


def make_plan(ops, from_v="0.1.0", to_v="0.2.0") -> UpgradePlan:
    return UpgradePlan(
        current_version=from_v,
        target_version=to_v,
        upgrades=[Upgrade(from_version=from_v, to_version=to_v, description="test", operations=ops)],
        operations=ops,
    )


class TestExecuteClean:
    def test_all_applied(self, tmp_path):
        dotfile = make_dotfile()
        op = CreateFile(path="new.py", template="new.jinja", description="new file")
        plan = make_plan([op])

        result = execute_upgrade(plan, tmp_path, dotfile, simple_renderer)

        assert len(result.applied) == 1
        assert result.skipped == []
        assert result.backed_up == []
        assert (tmp_path / "new.py").read_text() == "rendered:new.jinja"

    def test_dotfile_mutated(self, tmp_path):
        dotfile = make_dotfile()
        op = CreateFile(path="new.py", template="new.jinja", description="new file")
        plan = make_plan([op])

        execute_upgrade(plan, tmp_path, dotfile, simple_renderer)

        assert "new.py" in dotfile.files
        assert dotfile.files["new.py"].managed == "full"

    def test_multiple_operations(self, tmp_path):
        dotfile = make_dotfile()
        ops = [
            CreateFile(path="a.py", template="a.jinja", description="a"),
            CreateFile(path="b.py", template="b.jinja", description="b"),
        ]
        plan = make_plan(ops)

        result = execute_upgrade(plan, tmp_path, dotfile, simple_renderer)

        assert len(result.applied) == 2
        assert (tmp_path / "a.py").exists()
        assert (tmp_path / "b.py").exists()


class TestExecuteConflictDefault:
    def test_aborts_on_conflict(self, tmp_path):
        dotfile = make_dotfile()
        (tmp_path / "existing.py").write_text("user content")
        op = CreateFile(path="existing.py", template="new.jinja", description="new file")
        plan = make_plan([op])

        with pytest.raises(UpgradeError, match="Conflict"):
            execute_upgrade(plan, tmp_path, dotfile, simple_renderer)

    def test_nothing_applied_on_abort(self, tmp_path):
        dotfile = make_dotfile()
        (tmp_path / "existing.py").write_text("user content")
        ops = [
            CreateFile(path="existing.py", template="new.jinja", description="conflict"),
            CreateFile(path="clean.py", template="clean.jinja", description="clean"),
        ]
        plan = make_plan(ops)

        with pytest.raises(UpgradeError):
            execute_upgrade(plan, tmp_path, dotfile, simple_renderer)

        # Second op was never reached
        assert not (tmp_path / "clean.py").exists()


class TestExecuteSkipConflicts:
    def test_skips_conflict_applies_rest(self, tmp_path):
        dotfile = make_dotfile()
        (tmp_path / "existing.py").write_text("user content")
        ops = [
            CreateFile(path="existing.py", template="new.jinja", description="conflict"),
            CreateFile(path="clean.py", template="clean.jinja", description="clean"),
        ]
        plan = make_plan(ops)

        result = execute_upgrade(plan, tmp_path, dotfile, simple_renderer, skip_conflicts=True)

        assert len(result.applied) == 1
        assert len(result.skipped) == 1
        assert result.skipped[0][0].path == "existing.py"
        assert (tmp_path / "existing.py").read_text() == "user content"
        assert (tmp_path / "clean.py").exists()


class TestExecuteForce:
    def test_backs_up_and_overwrites(self, tmp_path):
        dotfile = make_dotfile()
        # Set up a tracked file that has been modified (creates conflict for ReplaceFile)
        (tmp_path / "tracked.py").write_text("original")
        dotfile.files["tracked.py"] = TrackedFile(managed="full", hash="sha256:wrong")

        op = ReplaceFile(path="tracked.py", template="new.jinja", description="update")
        plan = make_plan([op])

        result = execute_upgrade(plan, tmp_path, dotfile, simple_renderer, force=True)

        assert len(result.applied) == 1
        assert len(result.backed_up) == 1
        assert result.backed_up[0][0] == "tracked.py"
        # Backup contains original content
        assert result.backed_up[0][1].read_text() == "original"
        # File was overwritten
        assert (tmp_path / "tracked.py").read_text() == "rendered:new.jinja"


class TestExecuteMultiStep:
    def test_multi_step_all_applied(self, tmp_path):
        dotfile = make_dotfile("0.1.0")
        op1 = CreateFile(path="a.py", template="a.jinja", description="a")
        op2 = CreateFile(path="b.py", template="b.jinja", description="b")
        upgrades = [
            Upgrade(from_version="0.1.0", to_version="0.2.0", description="v2", operations=[op1]),
            Upgrade(from_version="0.2.0", to_version="0.3.0", description="v3", operations=[op2]),
        ]
        plan = plan_upgrade(dotfile, upgrades, "0.3.0")

        result = execute_upgrade(plan, tmp_path, dotfile, simple_renderer)

        assert len(result.applied) == 2
        assert (tmp_path / "a.py").exists()
        assert (tmp_path / "b.py").exists()
