from bluefox_upgrade.hashing import file_is_modified, hash_file


class TestHashing:
    def test_hash_file_deterministic(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello world")

        assert hash_file(f) == hash_file(f)

    def test_hash_file_format(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello world")

        h = hash_file(f)
        assert h.startswith("sha256:")
        assert len(h) == len("sha256:") + 64  # SHA-256 is 64 hex chars

    def test_hash_file_different_content(self, tmp_path):
        f1 = tmp_path / "a.txt"
        f2 = tmp_path / "b.txt"
        f1.write_text("hello")
        f2.write_text("world")

        assert hash_file(f1) != hash_file(f2)

    def test_file_is_modified_untouched(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("original content")
        original_hash = hash_file(f)

        assert not file_is_modified(f, original_hash)

    def test_file_is_modified_changed(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("original content")
        original_hash = hash_file(f)

        f.write_text("modified content")
        assert file_is_modified(f, original_hash)
