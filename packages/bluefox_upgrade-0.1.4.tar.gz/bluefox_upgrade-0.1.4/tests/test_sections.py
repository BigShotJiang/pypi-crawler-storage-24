import pytest

from bluefox_upgrade.sections import find_section, replace_section

SAMPLE_FILE = """\
from fastapi import FastAPI

# --- bluefox:framework-imports ---
from app.health.router import router as health_router
# --- end:bluefox:framework-imports ---

# Your imports below


def create_app() -> FastAPI:
    app = FastAPI(title="My App")

    # --- bluefox:routers ---
    app.include_router(health_router)
    # --- end:bluefox:routers ---

    # Your startup code below

    return app
"""


class TestFindSection:
    def test_finds_section(self):
        result = find_section(SAMPLE_FILE, "bluefox:framework-imports")
        assert result is not None
        start, end = result
        assert SAMPLE_FILE[start:end] == "from app.health.router import router as health_router\n"

    def test_finds_second_section(self):
        result = find_section(SAMPLE_FILE, "bluefox:routers")
        assert result is not None
        start, end = result
        assert SAMPLE_FILE[start:end] == "    app.include_router(health_router)\n"

    def test_returns_none_missing_start(self):
        content = "# --- end:bluefox:routers ---\n"
        assert find_section(content, "bluefox:routers") is None

    def test_returns_none_missing_end(self):
        content = "# --- bluefox:routers ---\nsome content\n"
        assert find_section(content, "bluefox:routers") is None

    def test_returns_none_no_markers(self):
        assert find_section("just some code", "bluefox:routers") is None


class TestReplaceSection:
    def test_replaces_content(self):
        new_content = "from app.health.router import router as health_router\nfrom app.middleware import setup_cors\n"
        result = replace_section(SAMPLE_FILE, "bluefox:framework-imports", new_content)

        assert "from app.middleware import setup_cors" in result
        assert "# --- bluefox:framework-imports ---" in result
        assert "# --- end:bluefox:framework-imports ---" in result

    def test_preserves_content_outside_markers(self):
        new_content = "REPLACED\n"
        result = replace_section(SAMPLE_FILE, "bluefox:framework-imports", new_content)

        assert "from fastapi import FastAPI" in result
        assert "# Your imports below" in result
        assert "def create_app() -> FastAPI:" in result
        assert "# Your startup code below" in result

    def test_preserves_other_sections(self):
        new_content = "REPLACED\n"
        result = replace_section(SAMPLE_FILE, "bluefox:framework-imports", new_content)

        assert "# --- bluefox:routers ---" in result
        assert "app.include_router(health_router)" in result
        assert "# --- end:bluefox:routers ---" in result

    def test_raises_on_missing_marker(self):
        with pytest.raises(ValueError, match="not found"):
            replace_section(SAMPLE_FILE, "bluefox:nonexistent", "new")

    def test_content_outside_is_byte_identical(self):
        new_content = "REPLACED\n"
        result = replace_section(SAMPLE_FILE, "bluefox:framework-imports", new_content)

        # Everything before the start marker should be identical
        marker_line = "# --- bluefox:framework-imports ---\n"
        original_before = SAMPLE_FILE[: SAMPLE_FILE.index(marker_line)]
        result_before = result[: result.index(marker_line)]
        assert original_before == result_before

        # Everything after the end marker should be identical
        end_marker = "# --- end:bluefox:framework-imports ---"
        original_after = SAMPLE_FILE[SAMPLE_FILE.index(end_marker) :]
        result_after = result[result.index(end_marker) :]
        assert original_after == result_after
