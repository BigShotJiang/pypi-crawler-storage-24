from bluefox_upgrade.backup import backup_file


class TestBackupFile:
    def test_creates_backup(self, tmp_path):
        (tmp_path / "app.py").write_text("hello world")

        result = backup_file(tmp_path, "app.py", timestamp="20260315T120000")

        assert result.exists()
        assert result.read_text() == "hello world"

    def test_backup_path_structure(self, tmp_path):
        (tmp_path / "app.py").write_text("content")

        result = backup_file(tmp_path, "app.py", timestamp="20260315T120000")

        expected = tmp_path / ".bluefox-backups" / "20260315T120000" / "app.py"
        assert result == expected

    def test_original_untouched(self, tmp_path):
        (tmp_path / "app.py").write_text("original")

        backup_file(tmp_path, "app.py", timestamp="20260315T120000")

        assert (tmp_path / "app.py").read_text() == "original"

    def test_nested_file_path(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("nested")

        result = backup_file(tmp_path, "src/main.py", timestamp="20260315T120000")

        expected = tmp_path / ".bluefox-backups" / "20260315T120000" / "src" / "main.py"
        assert result == expected
        assert result.read_text() == "nested"

    def test_multiple_backups_different_timestamps(self, tmp_path):
        (tmp_path / "app.py").write_text("v1")
        backup1 = backup_file(tmp_path, "app.py", timestamp="20260315T120000")

        (tmp_path / "app.py").write_text("v2")
        backup2 = backup_file(tmp_path, "app.py", timestamp="20260315T130000")

        assert backup1.read_text() == "v1"
        assert backup2.read_text() == "v2"
        assert backup1 != backup2

    def test_auto_timestamp(self, tmp_path):
        (tmp_path / "app.py").write_text("content")

        result = backup_file(tmp_path, "app.py")

        assert result.exists()
        assert ".bluefox-backups/" in str(result)
