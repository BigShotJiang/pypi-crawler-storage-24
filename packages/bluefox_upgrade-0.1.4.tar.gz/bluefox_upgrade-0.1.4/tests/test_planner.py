import pytest

from bluefox_upgrade.dotfile import DotBluefox
from bluefox_upgrade.exceptions import UpgradeError
from bluefox_upgrade.models import Upgrade
from bluefox_upgrade.operations import CreateFile, ReplaceFile
from bluefox_upgrade.planner import check_conflicts, plan_upgrade


def make_dotfile(version: str = "0.1.0") -> DotBluefox:
    return DotBluefox(
        cli_version=version,
        generated_at="2026-03-15",
    )


def make_upgrade(from_v: str, to_v: str, ops=None) -> Upgrade:
    return Upgrade(
        from_version=from_v,
        to_version=to_v,
        description=f"Upgrade from {from_v} to {to_v}",
        operations=ops or [],
    )


class TestPlanUpgrade:
    def test_single_step(self):
        dotfile = make_dotfile("0.1.0")
        op = ReplaceFile(path="Dockerfile", template="dockerfile.jinja", description="update Dockerfile")
        upgrades = [make_upgrade("0.1.0", "0.2.0", [op])]

        plan = plan_upgrade(dotfile, upgrades, "0.2.0")

        assert plan.current_version == "0.1.0"
        assert plan.target_version == "0.2.0"
        assert len(plan.upgrades) == 1
        assert len(plan.operations) == 1
        assert plan.operations[0] == op

    def test_multi_step(self):
        dotfile = make_dotfile("0.1.0")
        op1 = ReplaceFile(path="Dockerfile", template="v2.jinja", description="v2")
        op2 = ReplaceFile(path="entrypoint.sh", template="entry.jinja", description="entry")
        upgrades = [
            make_upgrade("0.1.0", "0.2.0", [op1]),
            make_upgrade("0.2.0", "0.3.0", [op2]),
        ]

        plan = plan_upgrade(dotfile, upgrades, "0.3.0")

        assert plan.current_version == "0.1.0"
        assert plan.target_version == "0.3.0"
        assert len(plan.upgrades) == 2
        assert len(plan.operations) == 2
        assert plan.operations[0] == op1
        assert plan.operations[1] == op2

    def test_already_at_target(self):
        dotfile = make_dotfile("0.3.0")

        plan = plan_upgrade(dotfile, [], "0.3.0")

        assert plan.upgrades == []
        assert plan.operations == []

    def test_no_path_raises(self):
        dotfile = make_dotfile("0.1.0")
        upgrades = [make_upgrade("0.2.0", "0.3.0")]

        with pytest.raises(UpgradeError, match="No upgrade path"):
            plan_upgrade(dotfile, upgrades, "0.3.0")

    def test_gap_in_chain_raises(self):
        dotfile = make_dotfile("0.1.0")
        upgrades = [
            make_upgrade("0.1.0", "0.2.0"),
            make_upgrade("0.3.0", "0.4.0"),
        ]

        with pytest.raises(UpgradeError, match="No upgrade path"):
            plan_upgrade(dotfile, upgrades, "0.4.0")

    def test_operations_flattened_across_upgrades(self):
        dotfile = make_dotfile("0.1.0")
        op1 = ReplaceFile(path="a.py", template="a.jinja", description="a")
        op2 = CreateFile(path="b.py", template="b.jinja", description="b")
        op3 = ReplaceFile(path="c.py", template="c.jinja", description="c")
        upgrades = [
            make_upgrade("0.1.0", "0.2.0", [op1, op2]),
            make_upgrade("0.2.0", "0.3.0", [op3]),
        ]

        plan = plan_upgrade(dotfile, upgrades, "0.3.0")

        assert len(plan.operations) == 3
        assert plan.operations == [op1, op2, op3]


class TestCheckConflicts:
    def test_no_conflicts(self, tmp_path):
        dotfile = make_dotfile("0.1.0")
        op = CreateFile(path="new_file.py", template="new.jinja", description="new file")
        upgrades = [make_upgrade("0.1.0", "0.2.0", [op])]
        plan = plan_upgrade(dotfile, upgrades, "0.2.0")

        conflicts = check_conflicts(plan, tmp_path, dotfile)

        assert conflicts == []

    def test_conflict_detected(self, tmp_path):
        dotfile = make_dotfile("0.1.0")
        # CreateFile conflicts if file already exists
        (tmp_path / "existing.py").write_text("hello")
        op = CreateFile(path="existing.py", template="new.jinja", description="new file")
        upgrades = [make_upgrade("0.1.0", "0.2.0", [op])]
        plan = plan_upgrade(dotfile, upgrades, "0.2.0")

        conflicts = check_conflicts(plan, tmp_path, dotfile)

        assert len(conflicts) == 1
        assert conflicts[0].conflict.has_conflict
        assert "already exists" in conflicts[0].conflict.message

    def test_empty_plan_no_conflicts(self, tmp_path):
        dotfile = make_dotfile("0.3.0")
        plan = plan_upgrade(dotfile, [], "0.3.0")

        conflicts = check_conflicts(plan, tmp_path, dotfile)

        assert conflicts == []
