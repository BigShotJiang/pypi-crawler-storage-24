from bluefox_upgrade.collapse import collapse_operations
from bluefox_upgrade.operations import (
    AddDependency,
    BumpDependency,
    CreateFile,
    RemoveDependency,
    RemoveFile,
    ReplaceFile,
    UpdateSection,
)


class TestCollapseReplaceFile:
    def test_multiple_replace_keeps_last(self):
        ops = [
            ReplaceFile(path="Dockerfile", template="v1.jinja", description="v1"),
            ReplaceFile(path="Dockerfile", template="v2.jinja", description="v2"),
            ReplaceFile(path="Dockerfile", template="v3.jinja", description="v3"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 1
        assert isinstance(result[0], ReplaceFile)
        assert result[0].template == "v3.jinja"

    def test_replace_different_paths_preserved(self):
        ops = [
            ReplaceFile(path="a.py", template="a.jinja", description="a"),
            ReplaceFile(path="b.py", template="b.jinja", description="b"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 2


class TestCollapseCreateReplace:
    def test_create_then_replace(self):
        ops = [
            CreateFile(path="app.py", template="v1.jinja", description="initial"),
            ReplaceFile(path="app.py", template="v2.jinja", description="updated"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 1
        assert isinstance(result[0], CreateFile)
        assert result[0].template == "v2.jinja"
        assert result[0].description == "updated"


class TestCollapseCreateRemove:
    def test_create_then_remove(self):
        ops = [
            CreateFile(path="entrypoint.sh", template="entry.jinja", description="add"),
            RemoveFile(path="entrypoint.sh", description="remove"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 0


class TestCollapseReplaceRemove:
    def test_replace_then_remove(self):
        ops = [
            ReplaceFile(path="old.py", template="old.jinja", description="update"),
            RemoveFile(path="old.py", description="remove"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 1
        assert isinstance(result[0], RemoveFile)


class TestCollapseUpdateSection:
    def test_multiple_same_marker_keeps_last(self):
        ops = [
            UpdateSection(path="main.py", marker="routers", content="v1", description="v1"),
            UpdateSection(path="main.py", marker="routers", content="v2", description="v2"),
            UpdateSection(path="main.py", marker="routers", content="v3", description="v3"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 1
        assert result[0].content == "v3"

    def test_different_markers_preserved(self):
        ops = [
            UpdateSection(path="main.py", marker="routers", content="r1", description="r"),
            UpdateSection(path="main.py", marker="middleware", content="m1", description="m"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 2


class TestCollapseAddBumpDependency:
    def test_add_then_bump(self):
        ops = [
            AddDependency(name="x", spec=">=0.1"),
            BumpDependency(name="x", old_spec=">=0.1", new_spec=">=0.2"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 1
        assert isinstance(result[0], AddDependency)
        assert result[0].spec == ">=0.2"

    def test_add_then_multiple_bumps(self):
        ops = [
            AddDependency(name="x", spec=">=0.1"),
            BumpDependency(name="x", old_spec=">=0.1", new_spec=">=0.2"),
            BumpDependency(name="x", old_spec=">=0.2", new_spec=">=0.5"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 1
        assert isinstance(result[0], AddDependency)
        assert result[0].spec == ">=0.5"


class TestCollapseAddRemoveDependency:
    def test_add_then_remove(self):
        ops = [
            AddDependency(name="x", spec=">=0.1"),
            RemoveDependency(name="x"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 0


class TestCollapseBumpDependency:
    def test_multiple_bumps(self):
        ops = [
            BumpDependency(name="x", old_spec=">=0.1", new_spec=">=0.2"),
            BumpDependency(name="x", old_spec=">=0.2", new_spec=">=0.5"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 1
        assert isinstance(result[0], BumpDependency)
        assert result[0].old_spec == ">=0.1"
        assert result[0].new_spec == ">=0.5"


class TestCollapsePreservesOrder:
    def test_different_files_order_preserved(self):
        ops = [
            ReplaceFile(path="a.py", template="a.jinja", description="a"),
            CreateFile(path="b.py", template="b.jinja", description="b"),
            ReplaceFile(path="c.py", template="c.jinja", description="c"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 3
        assert result[0].path == "a.py"
        assert result[1].path == "b.py"
        assert result[2].path == "c.py"

    def test_single_step_unchanged(self):
        ops = [
            ReplaceFile(path="Dockerfile", template="v1.jinja", description="v1"),
            AddDependency(name="x", spec=">=0.1"),
        ]
        result = collapse_operations(ops)
        assert len(result) == 2
        assert result == ops
