"""Integration test: multi-step upgrade chain with collapsing."""

from bluefox_upgrade.dotfile import create_dotfile, full_tracked, structured_tracked
from bluefox_upgrade.executor import execute_upgrade
from bluefox_upgrade.models import Upgrade
from bluefox_upgrade.operations import AddDependency, BumpDependency, CreateFile, ReplaceFile
from bluefox_upgrade.planner import plan_upgrade

PYPROJECT = """\
[project]
name = "my-app"
version = "0.1.0"
dependencies = [
    "fastapi>=0.115",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
"""


def simple_renderer(template: str) -> str:
    templates = {
        "dockerfile_v2.jinja": "FROM python:3.12\n# v2\n",
        "dockerfile_v3.jinja": "FROM python:3.13\n# v3\n",
        "dockerfile_v4.jinja": "FROM python:3.14\n# v4\n",
        "entrypoint.jinja": "#!/bin/bash\nexec python main.py\n",
    }
    return templates.get(template, f"rendered:{template}")


class TestMultiStepChain:
    def test_chain_with_collapsing(self, tmp_path):
        # Setup: project at v0.1.0
        (tmp_path / "Dockerfile").write_text("FROM python:3.11\n")
        (tmp_path / "pyproject.toml").write_text(PYPROJECT)

        tracked = dict([
            full_tracked("Dockerfile"),
            structured_tracked("pyproject.toml"),
        ])
        dotfile = create_dotfile(tmp_path, "0.1.0", tracked)

        # Define 3 upgrades with redundant operations
        upgrades = [
            Upgrade(
                from_version="0.1.0",
                to_version="0.2.0",
                description="v0.2.0",
                operations=[
                    ReplaceFile(path="Dockerfile", template="dockerfile_v2.jinja", description="v2"),
                    BumpDependency(name="fastapi", old_spec=">=0.115", new_spec=">=0.118"),
                    AddDependency(name="httpx", spec=">=0.25"),
                ],
            ),
            Upgrade(
                from_version="0.2.0",
                to_version="0.3.0",
                description="v0.3.0",
                operations=[
                    ReplaceFile(path="Dockerfile", template="dockerfile_v3.jinja", description="v3"),
                    BumpDependency(name="fastapi", old_spec=">=0.118", new_spec=">=0.120"),
                    BumpDependency(name="httpx", old_spec=">=0.25", new_spec=">=0.27"),
                    CreateFile(path="entrypoint.sh", template="entrypoint.jinja", description="add entrypoint"),
                ],
            ),
            Upgrade(
                from_version="0.3.0",
                to_version="0.4.0",
                description="v0.4.0",
                operations=[
                    ReplaceFile(path="Dockerfile", template="dockerfile_v4.jinja", description="v4"),
                    BumpDependency(name="fastapi", old_spec=">=0.120", new_spec=">=0.125"),
                ],
            ),
        ]

        # Plan: should chain all 3 and collapse
        plan = plan_upgrade(dotfile, upgrades, "0.4.0")

        assert plan.current_version == "0.1.0"
        assert plan.target_version == "0.4.0"
        assert len(plan.upgrades) == 3

        # Verify collapsing:
        # - 3 ReplaceFile("Dockerfile") → 1 (last template)
        # - AddDependency("httpx") + BumpDependency("httpx") → AddDependency with final spec
        # - 3 BumpDependency("fastapi") → 1 (first old_spec to last new_spec)
        # - CreateFile("entrypoint.sh") → kept as-is
        # Total: 4 operations
        assert len(plan.operations) == 4

        # Find specific operations by type
        replace_ops = [op for op in plan.operations if isinstance(op, ReplaceFile)]
        assert len(replace_ops) == 1
        assert replace_ops[0].template == "dockerfile_v4.jinja"

        bump_ops = [op for op in plan.operations if isinstance(op, BumpDependency)]
        assert len(bump_ops) == 1
        assert bump_ops[0].name == "fastapi"
        assert bump_ops[0].old_spec == ">=0.115"
        assert bump_ops[0].new_spec == ">=0.125"

        add_ops = [op for op in plan.operations if isinstance(op, AddDependency)]
        assert len(add_ops) == 1
        assert add_ops[0].name == "httpx"
        assert add_ops[0].spec == ">=0.27"

        create_ops = [op for op in plan.operations if isinstance(op, CreateFile)]
        assert len(create_ops) == 1
        assert create_ops[0].path == "entrypoint.sh"

        # Execute and verify final state
        result = execute_upgrade(plan, tmp_path, dotfile, simple_renderer)

        assert len(result.applied) == 4
        assert result.skipped == []

        # Dockerfile has v4 content
        assert (tmp_path / "Dockerfile").read_text() == "FROM python:3.14\n# v4\n"

        # entrypoint.sh was created
        assert (tmp_path / "entrypoint.sh").read_text() == "#!/bin/bash\nexec python main.py\n"

        # Dependencies updated correctly
        pyproject = (tmp_path / "pyproject.toml").read_text()
        assert "fastapi>=0.125" in pyproject
        assert "httpx>=0.27" in pyproject

    def test_single_step_no_collapsing(self, tmp_path):
        (tmp_path / "Dockerfile").write_text("FROM python:3.11\n")
        tracked = dict([full_tracked("Dockerfile")])
        dotfile = create_dotfile(tmp_path, "0.1.0", tracked)

        upgrades = [
            Upgrade(
                from_version="0.1.0",
                to_version="0.2.0",
                description="v0.2.0",
                operations=[
                    ReplaceFile(path="Dockerfile", template="dockerfile_v2.jinja", description="v2"),
                ],
            ),
        ]

        plan = plan_upgrade(dotfile, upgrades, "0.2.0")
        assert len(plan.operations) == 1

        result = execute_upgrade(plan, tmp_path, dotfile, simple_renderer)
        assert len(result.applied) == 1
        assert (tmp_path / "Dockerfile").read_text() == "FROM python:3.12\n# v2\n"
