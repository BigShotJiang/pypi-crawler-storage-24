"""Integration test: full init → modify → upgrade cycle."""

from bluefox_upgrade.dotfile import (
    create_dotfile,
    full_tracked,
    load_dotfile,
    save_dotfile,
    sections_tracked,
    structured_tracked,
)
from bluefox_upgrade.executor import execute_upgrade
from bluefox_upgrade.models import Upgrade
from bluefox_upgrade.operations import AddDependency, BumpDependency, ReplaceFile, UpdateSection
from bluefox_upgrade.planner import check_conflicts, plan_upgrade

DOCKERFILE_V1 = "FROM python:3.12-slim\nWORKDIR /app\nCOPY . .\n"
DOCKERFILE_V2 = "FROM python:3.13-slim\nWORKDIR /app\nCOPY . .\nRUN pip install --no-cache-dir -r requirements.txt\n"

APP_INIT = """\
from fastapi import FastAPI

app = FastAPI()

# --- bluefox:routers ---
from app.routes import health
app.include_router(health.router)
# --- end:bluefox:routers ---

# user code below
@app.get("/custom")
def custom():
    return {"custom": True}
"""

PYPROJECT = """\
[project]
name = "my-app"
version = "0.1.0"
description = "My app"
requires-python = ">=3.12"
dependencies = [
    "fastapi>=0.115",
    "uvicorn[standard]>=0.34",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
"""


def simple_renderer(template: str) -> str:
    templates = {
        "dockerfile_v2.jinja": DOCKERFILE_V2,
    }
    return templates.get(template, f"rendered:{template}")


class TestFullCycle:
    def test_init_modify_upgrade_skip(self, tmp_path):
        # 1. Create project files
        (tmp_path / "Dockerfile").write_text(DOCKERFILE_V1)
        (tmp_path / "app").mkdir()
        (tmp_path / "app" / "__init__.py").write_text(APP_INIT)
        (tmp_path / "pyproject.toml").write_text(PYPROJECT)

        # 2. Init: create .bluefox
        tracked = dict([
            full_tracked("Dockerfile"),
            sections_tracked("app/__init__.py", ["bluefox:routers"]),
            structured_tracked("pyproject.toml"),
        ])
        dotfile = create_dotfile(tmp_path, "0.1.0", tracked)

        assert dotfile.files["Dockerfile"].hash is not None
        assert dotfile.files["app/__init__.py"].hash is not None
        assert dotfile.files["pyproject.toml"].hash is None

        # 3. User modifies Dockerfile (simulating user edit)
        (tmp_path / "Dockerfile").write_text(DOCKERFILE_V1 + "# my custom layer\nRUN apt-get update\n")

        # 4. Define upgrade 0.1.0 → 0.2.0
        upgrade = Upgrade(
            from_version="0.1.0",
            to_version="0.2.0",
            description="Upgrade to v0.2.0",
            operations=[
                ReplaceFile(path="Dockerfile", template="dockerfile_v2.jinja", description="update base image"),
                UpdateSection(
                    path="app/__init__.py",
                    marker="bluefox:routers",
                    content=(
                        "from app.routes import health, users\n"
                        "app.include_router(health.router)\n"
                        "app.include_router(users.router)\n"
                    ),
                    description="add users router",
                ),
                BumpDependency(name="fastapi", old_spec=">=0.115", new_spec=">=0.120"),
            ],
        )

        # 5. Plan
        plan = plan_upgrade(dotfile, [upgrade], "0.2.0")
        assert len(plan.operations) == 3

        # 6. Check conflicts
        conflicts = check_conflicts(plan, tmp_path, dotfile)
        assert len(conflicts) == 1
        assert "Dockerfile" in conflicts[0].conflict.message

        # 7. Execute with skip_conflicts
        result = execute_upgrade(plan, tmp_path, dotfile, simple_renderer, skip_conflicts=True)

        assert len(result.applied) == 2
        assert len(result.skipped) == 1
        assert result.skipped[0][0].path == "Dockerfile"

        # 8. Verify results
        # Dockerfile was NOT overwritten (user edits preserved)
        assert "my custom layer" in (tmp_path / "Dockerfile").read_text()

        # Section was updated
        init_content = (tmp_path / "app" / "__init__.py").read_text()
        assert "users" in init_content
        # User code outside markers preserved
        assert "custom" in init_content

        # Dependency was bumped
        pyproject_content = (tmp_path / "pyproject.toml").read_text()
        assert "fastapi>=0.120" in pyproject_content
        # Other deps preserved
        assert "uvicorn[standard]>=0.34" in pyproject_content

        # 9. Dotfile was mutated
        assert "app/__init__.py" in dotfile.files
        assert dotfile.files["app/__init__.py"].hash is not None

    def test_init_upgrade_force(self, tmp_path):
        # Setup
        (tmp_path / "Dockerfile").write_text(DOCKERFILE_V1)
        (tmp_path / "pyproject.toml").write_text(PYPROJECT)

        tracked = dict([
            full_tracked("Dockerfile"),
            structured_tracked("pyproject.toml"),
        ])
        dotfile = create_dotfile(tmp_path, "0.1.0", tracked)

        # User modifies Dockerfile
        (tmp_path / "Dockerfile").write_text("FROM custom:latest\n")

        upgrade = Upgrade(
            from_version="0.1.0",
            to_version="0.2.0",
            description="v0.2.0",
            operations=[
                ReplaceFile(path="Dockerfile", template="dockerfile_v2.jinja", description="update"),
            ],
        )

        plan = plan_upgrade(dotfile, [upgrade], "0.2.0")
        result = execute_upgrade(plan, tmp_path, dotfile, simple_renderer, force=True)

        assert len(result.applied) == 1
        assert len(result.backed_up) == 1
        assert result.backed_up[0][0] == "Dockerfile"
        # Backup has old content
        assert result.backed_up[0][1].read_text() == "FROM custom:latest\n"
        # File was overwritten
        assert (tmp_path / "Dockerfile").read_text() == DOCKERFILE_V2

    def test_clean_upgrade_no_conflicts(self, tmp_path):
        # Setup: no user modifications
        (tmp_path / "Dockerfile").write_text(DOCKERFILE_V1)
        (tmp_path / "pyproject.toml").write_text(PYPROJECT)

        tracked = dict([
            full_tracked("Dockerfile"),
            structured_tracked("pyproject.toml"),
        ])
        dotfile = create_dotfile(tmp_path, "0.1.0", tracked)

        upgrade = Upgrade(
            from_version="0.1.0",
            to_version="0.2.0",
            description="v0.2.0",
            operations=[
                ReplaceFile(path="Dockerfile", template="dockerfile_v2.jinja", description="update"),
                AddDependency(name="httpx", spec=">=0.27"),
            ],
        )

        plan = plan_upgrade(dotfile, [upgrade], "0.2.0")
        conflicts = check_conflicts(plan, tmp_path, dotfile)
        assert len(conflicts) == 0

        result = execute_upgrade(plan, tmp_path, dotfile, simple_renderer)
        assert len(result.applied) == 2
        assert result.skipped == []

        # Verify final state
        assert (tmp_path / "Dockerfile").read_text() == DOCKERFILE_V2
        pyproject = (tmp_path / "pyproject.toml").read_text()
        assert "httpx>=0.27" in pyproject

        # Save dotfile and reload to verify persistence
        save_dotfile(tmp_path, dotfile)
        reloaded = load_dotfile(tmp_path)
        assert reloaded.files["Dockerfile"].hash is not None
