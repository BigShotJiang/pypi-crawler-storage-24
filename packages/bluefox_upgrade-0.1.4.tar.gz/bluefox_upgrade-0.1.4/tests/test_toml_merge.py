from bluefox_upgrade.dotfile import DotBluefox, TrackedFile
from bluefox_upgrade.operations import AddDependency, BumpDependency, RemoveDependency
from bluefox_upgrade.toml_merge import find_dependency

SAMPLE_PYPROJECT = """\
[project]
name = "my-app"
version = "0.1.0"
description = "A test app"
requires-python = ">=3.12"
dependencies = [
    "fastapi>=0.115",
    "uvicorn[standard]>=0.34",
    "pydantic-settings>=2.7",
    "sqlmodel>=0.0.22",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
"""


def make_dotfile() -> DotBluefox:
    return DotBluefox(
        cli_version="0.1.0",
        generated_at="2026-03-15",
        files={"pyproject.toml": TrackedFile(managed="structured")},
    )


def write_pyproject(tmp_path, content=SAMPLE_PYPROJECT):
    (tmp_path / "pyproject.toml").write_text(content)


class TestAddDependency:
    def test_no_conflict(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = AddDependency(name="bluefox-core", spec=">=0.1.0")
        result = op.check_conflict(tmp_path, dotfile)

        assert not result.has_conflict

    def test_conflict_already_exists(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = AddDependency(name="fastapi", spec=">=0.115")
        result = op.check_conflict(tmp_path, dotfile)

        assert result.has_conflict
        assert "already exists" in result.message

    def test_apply_adds_dependency(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = AddDependency(name="bluefox-core", spec=">=0.1.0")
        op.apply(tmp_path, dotfile, lambda _: "")

        assert find_dependency(tmp_path, "bluefox-core") == "bluefox-core>=0.1.0"

    def test_apply_preserves_existing(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = AddDependency(name="bluefox-core", spec=">=0.1.0")
        op.apply(tmp_path, dotfile, lambda _: "")

        assert find_dependency(tmp_path, "fastapi") == "fastapi>=0.115"
        assert find_dependency(tmp_path, "sqlmodel") == "sqlmodel>=0.0.22"

    def test_apply_preserves_formatting(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = AddDependency(name="bluefox-core", spec=">=0.1.0")
        op.apply(tmp_path, dotfile, lambda _: "")

        content = (tmp_path / "pyproject.toml").read_text()
        assert 'name = "my-app"' in content
        assert "[build-system]" in content

    def test_describe(self):
        op = AddDependency(name="bluefox-core", spec=">=0.1.0")
        assert op.describe() == "pyproject.toml — added bluefox-core >=0.1.0"

    def test_describe_custom(self):
        op = AddDependency(name="bluefox-core", spec=">=0.1.0", description="core utilities")
        assert op.describe() == "pyproject.toml — core utilities"


class TestBumpDependency:
    def test_no_conflict(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = BumpDependency(name="fastapi", old_spec=">=0.115", new_spec=">=0.120")
        result = op.check_conflict(tmp_path, dotfile)

        assert not result.has_conflict

    def test_conflict_not_found(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = BumpDependency(name="nonexistent", old_spec=">=0.1", new_spec=">=0.2")
        result = op.check_conflict(tmp_path, dotfile)

        assert result.has_conflict
        assert "not found" in result.message

    def test_conflict_spec_changed(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = BumpDependency(name="fastapi", old_spec=">=0.100", new_spec=">=0.120")
        result = op.check_conflict(tmp_path, dotfile)

        assert result.has_conflict
        assert "unexpected spec" in result.message

    def test_apply_bumps_version(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = BumpDependency(name="fastapi", old_spec=">=0.115", new_spec=">=0.120")
        op.apply(tmp_path, dotfile, lambda _: "")

        assert find_dependency(tmp_path, "fastapi") == "fastapi>=0.120"

    def test_apply_preserves_others(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = BumpDependency(name="fastapi", old_spec=">=0.115", new_spec=">=0.120")
        op.apply(tmp_path, dotfile, lambda _: "")

        assert find_dependency(tmp_path, "sqlmodel") == "sqlmodel>=0.0.22"

    def test_describe(self):
        op = BumpDependency(name="fastapi", old_spec=">=0.115", new_spec=">=0.120")
        assert op.describe() == "pyproject.toml — bumped fastapi from >=0.115 to >=0.120"


class TestRemoveDependency:
    def test_no_conflict(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = RemoveDependency(name="sqlmodel")
        result = op.check_conflict(tmp_path, dotfile)

        assert not result.has_conflict

    def test_conflict_not_found(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = RemoveDependency(name="nonexistent")
        result = op.check_conflict(tmp_path, dotfile)

        assert result.has_conflict
        assert "not found" in result.message

    def test_apply_removes(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = RemoveDependency(name="sqlmodel")
        op.apply(tmp_path, dotfile, lambda _: "")

        assert find_dependency(tmp_path, "sqlmodel") is None

    def test_apply_preserves_others(self, tmp_path):
        write_pyproject(tmp_path)
        dotfile = make_dotfile()

        op = RemoveDependency(name="sqlmodel")
        op.apply(tmp_path, dotfile, lambda _: "")

        assert find_dependency(tmp_path, "fastapi") == "fastapi>=0.115"
        assert find_dependency(tmp_path, "uvicorn[standard]") is None  # name parsing
        assert find_dependency(tmp_path, "uvicorn") is not None

    def test_describe(self):
        op = RemoveDependency(name="old-package")
        assert op.describe() == "pyproject.toml — removed old-package"
