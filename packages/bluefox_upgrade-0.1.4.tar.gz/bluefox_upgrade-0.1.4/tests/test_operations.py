from bluefox_upgrade.dotfile import DotBluefox, TrackedFile
from bluefox_upgrade.hashing import hash_file
from bluefox_upgrade.operations import CreateFile, RemoveFile, ReplaceFile, UpdateSection


def make_dotfile(**files: TrackedFile) -> DotBluefox:
    return DotBluefox(cli_version="0.1.0", generated_at="2026-03-15", files=files)


def simple_renderer(templates: dict[str, str]):
    def render(name: str) -> str:
        return templates[name]

    return render


class TestReplaceFile:
    def test_no_conflict_untouched(self, tmp_path):
        f = tmp_path / "Dockerfile"
        f.write_text("FROM python:3.12")
        dotfile = make_dotfile(Dockerfile=TrackedFile(managed="full", hash=hash_file(f)))

        op = ReplaceFile(path="Dockerfile", template="dockerfile", description="updated base image")
        result = op.check_conflict(tmp_path, dotfile)

        assert not result.has_conflict

    def test_conflict_modified(self, tmp_path):
        f = tmp_path / "Dockerfile"
        f.write_text("FROM python:3.12")
        original_hash = hash_file(f)
        f.write_text("FROM python:3.13-slim  # user edit")
        dotfile = make_dotfile(Dockerfile=TrackedFile(managed="full", hash=original_hash))

        op = ReplaceFile(path="Dockerfile", template="dockerfile", description="updated base image")
        result = op.check_conflict(tmp_path, dotfile)

        assert result.has_conflict
        assert "modified" in result.message

    def test_no_conflict_not_tracked(self, tmp_path):
        dotfile = make_dotfile()

        op = ReplaceFile(path="Dockerfile", template="dockerfile", description="updated base image")
        result = op.check_conflict(tmp_path, dotfile)

        assert not result.has_conflict

    def test_apply_writes_file(self, tmp_path):
        f = tmp_path / "Dockerfile"
        f.write_text("FROM python:3.12")
        dotfile = make_dotfile(Dockerfile=TrackedFile(managed="full", hash=hash_file(f)))
        render = simple_renderer({"dockerfile": "FROM python:3.13-slim\nWORKDIR /app\n"})

        op = ReplaceFile(path="Dockerfile", template="dockerfile", description="updated base image")
        op.apply(tmp_path, dotfile, render)

        assert f.read_text() == "FROM python:3.13-slim\nWORKDIR /app\n"
        assert dotfile.files["Dockerfile"].hash == hash_file(f)
        assert dotfile.files["Dockerfile"].managed == "full"

    def test_apply_creates_parent_dirs(self, tmp_path):
        dotfile = make_dotfile()
        render = simple_renderer({"env": "# alembic env"})

        op = ReplaceFile(path="migrations/env.py", template="env", description="new env")
        op.apply(tmp_path, dotfile, render)

        assert (tmp_path / "migrations" / "env.py").read_text() == "# alembic env"
        assert "migrations/env.py" in dotfile.files

    def test_describe(self):
        op = ReplaceFile(path="Dockerfile", template="dockerfile", description="updated base image")
        assert op.describe() == "Dockerfile — updated base image"


class TestCreateFile:
    def test_no_conflict_file_missing(self, tmp_path):
        dotfile = make_dotfile()

        op = CreateFile(path="entrypoint.sh", template="entrypoint", description="process selector")
        result = op.check_conflict(tmp_path, dotfile)

        assert not result.has_conflict

    def test_conflict_file_exists(self, tmp_path):
        (tmp_path / "entrypoint.sh").write_text("#!/bin/bash")
        dotfile = make_dotfile()

        op = CreateFile(path="entrypoint.sh", template="entrypoint", description="process selector")
        result = op.check_conflict(tmp_path, dotfile)

        assert result.has_conflict
        assert "already exists" in result.message

    def test_apply_creates_file(self, tmp_path):
        dotfile = make_dotfile()
        render = simple_renderer({"entrypoint": "#!/bin/bash\nset -e\n"})

        op = CreateFile(path="entrypoint.sh", template="entrypoint", description="process selector")
        op.apply(tmp_path, dotfile, render)

        f = tmp_path / "entrypoint.sh"
        assert f.read_text() == "#!/bin/bash\nset -e\n"
        assert dotfile.files["entrypoint.sh"].managed == "full"
        assert dotfile.files["entrypoint.sh"].hash == hash_file(f)

    def test_apply_creates_parent_dirs(self, tmp_path):
        dotfile = make_dotfile()
        render = simple_renderer({"env": "# env content"})

        op = CreateFile(path="migrations/env.py", template="env", description="alembic env")
        op.apply(tmp_path, dotfile, render)

        assert (tmp_path / "migrations" / "env.py").exists()

    def test_describe(self):
        op = CreateFile(path="entrypoint.sh", template="entrypoint", description="process selector")
        assert op.describe() == "entrypoint.sh — new file: process selector"


class TestRemoveFile:
    def test_no_conflict_untouched(self, tmp_path):
        f = tmp_path / "old.py"
        f.write_text("old content")
        dotfile = make_dotfile(**{"old.py": TrackedFile(managed="full", hash=hash_file(f))})

        op = RemoveFile(path="old.py", description="no longer needed")
        result = op.check_conflict(tmp_path, dotfile)

        assert not result.has_conflict

    def test_conflict_modified(self, tmp_path):
        f = tmp_path / "old.py"
        f.write_text("old content")
        original_hash = hash_file(f)
        f.write_text("user modified this")
        dotfile = make_dotfile(**{"old.py": TrackedFile(managed="full", hash=original_hash)})

        op = RemoveFile(path="old.py", description="no longer needed")
        result = op.check_conflict(tmp_path, dotfile)

        assert result.has_conflict
        assert "modified" in result.message

    def test_no_conflict_already_gone(self, tmp_path):
        dotfile = make_dotfile(**{"old.py": TrackedFile(managed="full", hash="sha256:abc")})

        op = RemoveFile(path="old.py", description="no longer needed")
        result = op.check_conflict(tmp_path, dotfile)

        assert not result.has_conflict

    def test_apply_deletes_file(self, tmp_path):
        f = tmp_path / "old.py"
        f.write_text("old content")
        dotfile = make_dotfile(**{"old.py": TrackedFile(managed="full", hash=hash_file(f))})

        op = RemoveFile(path="old.py", description="no longer needed")
        op.apply(tmp_path, dotfile, lambda _: "")

        assert not f.exists()
        assert "old.py" not in dotfile.files

    def test_apply_already_gone_cleans_dotfile(self, tmp_path):
        dotfile = make_dotfile(**{"old.py": TrackedFile(managed="full", hash="sha256:abc")})

        op = RemoveFile(path="old.py", description="no longer needed")
        op.apply(tmp_path, dotfile, lambda _: "")

        assert "old.py" not in dotfile.files

    def test_describe(self):
        op = RemoveFile(path="old.py", description="no longer needed")
        assert op.describe() == "old.py — removed: no longer needed"


INIT_PY = """\
from fastapi import FastAPI

# --- bluefox:framework-imports ---
from app.health.router import router as health_router
# --- end:bluefox:framework-imports ---


def create_app() -> FastAPI:
    app = FastAPI(title="My App")

    # --- bluefox:routers ---
    app.include_router(health_router)
    # --- end:bluefox:routers ---

    return app
"""


class TestUpdateSection:
    def test_no_conflict_markers_present(self, tmp_path):
        (tmp_path / "app").mkdir()
        f = tmp_path / "app" / "__init__.py"
        f.write_text(INIT_PY)
        dotfile = make_dotfile(
            **{"app/__init__.py": TrackedFile(
                managed="sections",
                hash=hash_file(f),
                markers=["bluefox:framework-imports", "bluefox:routers"],
            )}
        )

        op = UpdateSection(
            path="app/__init__.py",
            marker="bluefox:framework-imports",
            content="from app.health.router import router as health_router\nfrom app.middleware import setup_cors\n",
            description="added CORS import",
        )
        result = op.check_conflict(tmp_path, dotfile)

        assert not result.has_conflict

    def test_conflict_marker_missing(self, tmp_path):
        (tmp_path / "app").mkdir()
        f = tmp_path / "app" / "__init__.py"
        f.write_text("from fastapi import FastAPI\n# no markers here\n")
        dotfile = make_dotfile(
            **{"app/__init__.py": TrackedFile(managed="sections", hash=hash_file(f))}
        )

        op = UpdateSection(
            path="app/__init__.py",
            marker="bluefox:framework-imports",
            content="new content\n",
            description="update imports",
        )
        result = op.check_conflict(tmp_path, dotfile)

        assert result.has_conflict
        assert "not found" in result.message

    def test_conflict_file_missing(self, tmp_path):
        dotfile = make_dotfile()

        op = UpdateSection(
            path="app/__init__.py",
            marker="bluefox:framework-imports",
            content="new content\n",
            description="update imports",
        )
        result = op.check_conflict(tmp_path, dotfile)

        assert result.has_conflict
        assert "not found" in result.message

    def test_apply_replaces_section(self, tmp_path):
        (tmp_path / "app").mkdir()
        f = tmp_path / "app" / "__init__.py"
        f.write_text(INIT_PY)
        dotfile = make_dotfile(
            **{"app/__init__.py": TrackedFile(
                managed="sections",
                hash=hash_file(f),
                markers=["bluefox:framework-imports", "bluefox:routers"],
            )}
        )

        new_imports = "from app.health.router import router as health_router\nfrom app.middleware import setup_cors\n"
        op = UpdateSection(
            path="app/__init__.py",
            marker="bluefox:framework-imports",
            content=new_imports,
            description="added CORS import",
        )
        op.apply(tmp_path, dotfile, lambda _: "")

        result = f.read_text()
        assert "from app.middleware import setup_cors" in result
        assert "def create_app() -> FastAPI:" in result
        assert "app.include_router(health_router)" in result
        assert dotfile.files["app/__init__.py"].managed == "sections"
        assert dotfile.files["app/__init__.py"].markers == [
            "bluefox:framework-imports",
            "bluefox:routers",
        ]

    def test_apply_preserves_user_code(self, tmp_path):
        (tmp_path / "app").mkdir()
        f = tmp_path / "app" / "__init__.py"
        content_with_user_code = INIT_PY.replace(
            "    return app",
            "    # user's custom middleware\n    app.add_middleware(CORSMiddleware)\n\n    return app",
        )
        f.write_text(content_with_user_code)
        dotfile = make_dotfile(
            **{"app/__init__.py": TrackedFile(
                managed="sections",
                hash=hash_file(f),
                markers=["bluefox:framework-imports", "bluefox:routers"],
            )}
        )

        op = UpdateSection(
            path="app/__init__.py",
            marker="bluefox:framework-imports",
            content="REPLACED\n",
            description="test",
        )
        op.apply(tmp_path, dotfile, lambda _: "")

        result = f.read_text()
        assert "# user's custom middleware" in result
        assert "app.add_middleware(CORSMiddleware)" in result

    def test_describe(self):
        op = UpdateSection(
            path="app/__init__.py",
            marker="bluefox:framework-imports",
            content="new\n",
            description="added CORS import",
        )
        assert op.describe() == "app/__init__.py [bluefox:framework-imports] — added CORS import"
