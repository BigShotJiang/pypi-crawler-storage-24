# Planner

The planner builds an upgrade path from the current version to a target version, chaining multiple upgrades and collapsing redundant operations.

## Functions

### `plan_upgrade(dotfile, upgrades, target) → UpgradePlan`

Builds an upgrade plan by walking the version chain from `dotfile.cli_version` to `target`.

```python
plan = plan_upgrade(dotfile, upgrades, target="0.4.0")
```

- Finds all upgrades in the chain (e.g. 0.1→0.2→0.3→0.4)
- Detects cycles and raises `UpgradeError`
- Raises `UpgradeError` if no path exists to the target
- Collapses redundant operations across steps

### `check_conflicts(plan, project_dir, dotfile) → list[ConflictReport]`

Checks each operation in the plan for conflicts against the current file state.

```python
conflicts = check_conflicts(plan, project_dir, dotfile)
for c in conflicts:
    print(c.conflict.message)
```

## Models

### UpgradePlan

```python
class UpgradePlan(BaseModel):
    current_version: str
    target_version: str
    upgrades: list[Upgrade]
    operations: list[AnyOperation]
```

`operations` is the collapsed list — the final set of operations to execute.

### ConflictReport

```python
class ConflictReport(BaseModel):
    operation: AnyOperation
    conflict: ConflictResult
```

### ConflictResult

```python
class ConflictResult(BaseModel):
    has_conflict: bool
    message: str
```
