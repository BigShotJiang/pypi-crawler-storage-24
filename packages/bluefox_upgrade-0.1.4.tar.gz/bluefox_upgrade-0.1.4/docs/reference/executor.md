# Executor

The executor applies a planned upgrade to the project directory.

## Function

### `execute_upgrade(plan, project_dir, dotfile, render_template, *, skip_conflicts=False, force=False) → ExecutionResult`

Applies all operations in the plan to the project directory.

```python
result = execute_upgrade(plan, project_dir, dotfile, render_template)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `plan` | `UpgradePlan` | The plan from `plan_upgrade()` |
| `project_dir` | `Path` | Root of the project |
| `dotfile` | `DotBluefox` | Current project state |
| `render_template` | `Callable[[str], str]` | Template renderer |
| `skip_conflicts` | `bool` | Skip operations that conflict (default: `False`) |
| `force` | `bool` | Backup and overwrite conflicts (default: `False`) |

### Conflict modes

| Mode | Behavior |
|------|----------|
| Default | Abort on first conflict (`UpgradeError`) |
| `skip_conflicts=True` | Skip conflicting operations, apply the rest |
| `force=True` | Backup modified files to `.bluefox-backups/`, then overwrite |

### Side effects

After execution, the executor:

1. Updates hashes in `dotfile.files` for modified `full` and `sections` files
2. Adds new entries to `dotfile.files` for `CreateFile` operations
3. Removes entries from `dotfile.files` for `RemoveFile` operations
4. Updates `dotfile.cli_version` to the plan's target version

## Model

### ExecutionResult

```python
class ExecutionResult(BaseModel):
    applied: list[AnyOperation]
    skipped: list[tuple[AnyOperation, ConflictResult]]
    backed_up: list[tuple[str, Path]]
```

| Field | Description |
|-------|-------------|
| `applied` | Operations that were successfully applied |
| `skipped` | Operations skipped due to conflicts (with reason) |
| `backed_up` | Files backed up in force mode `(path, backup_path)` |
