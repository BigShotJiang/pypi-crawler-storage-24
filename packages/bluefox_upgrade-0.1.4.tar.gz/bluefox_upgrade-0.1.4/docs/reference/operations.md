# Operations

All operations inherit from `Operation` (ABC) and are Pydantic `BaseModel` subclasses. Each operation implements `check_conflict()`, `apply()`, and `describe()`.

## File operations

### ReplaceFile

Replaces an entire file with rendered template content.

```python
ReplaceFile(path="Dockerfile", template="dockerfile_v2.jinja", description="update base image")
```

| Field | Type | Description |
|-------|------|-------------|
| `path` | `str` | Relative path to the file |
| `template` | `str` | Template name passed to `render_template` |
| `description` | `str` | Human-readable description |

**Conflict detection:** Checks SHA-256 hash against the stored hash in `.bluefox`. If the file has been modified by the user, reports a conflict.

### CreateFile

Creates a new file from a template. Conflicts if the file already exists.

```python
CreateFile(path="entrypoint.sh", template="entrypoint.jinja", description="add entrypoint script")
```

| Field | Type | Description |
|-------|------|-------------|
| `path` | `str` | Relative path for the new file |
| `template` | `str` | Template name |
| `description` | `str` | Human-readable description |

### RemoveFile

Deletes a tracked file. Conflicts if the file has been modified.

```python
RemoveFile(path="old_config.yml", description="remove deprecated config")
```

| Field | Type | Description |
|-------|------|-------------|
| `path` | `str` | Relative path to remove |
| `description` | `str` | Human-readable description |

## Section operations

### UpdateSection

Updates content between marker comments while preserving everything outside the markers.

```python
UpdateSection(
    path="app/__init__.py",
    marker="bluefox:routers",
    content="from app.routes import health, users\napp.include_router(health.router)\napp.include_router(users.router)\n",
    description="add users router",
)
```

| Field | Type | Description |
|-------|------|-------------|
| `path` | `str` | File containing the section |
| `marker` | `str` | Marker name (matched as `# --- marker ---`) |
| `content` | `str` | New content for the section |
| `description` | `str` | Human-readable description |

Markers in your source files look like:

```python
# --- bluefox:routers ---
from app.routes import health
app.include_router(health.router)
# --- end:bluefox:routers ---
```

**Conflict detection:** Checks the full file hash. If the file has been modified outside the markers, reports a conflict.

## Dependency operations

These operate on `pyproject.toml` using format-preserving TOML (tomlkit). They never lose comments or formatting.

### AddDependency

Adds a new dependency to `[project.dependencies]`.

```python
AddDependency(name="httpx", spec=">=0.27")
```

### BumpDependency

Updates an existing dependency's version specifier.

```python
BumpDependency(name="fastapi", old_spec=">=0.115", new_spec=">=0.120")
```

### RemoveDependency

Removes a dependency from `[project.dependencies]`.

```python
RemoveDependency(name="deprecated-pkg")
```

All dependency operations have `structured` tracking — no hash conflict detection, since they modify specific fields rather than replacing entire files.
