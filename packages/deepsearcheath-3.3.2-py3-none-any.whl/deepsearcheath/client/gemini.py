import os
import aiohttp
from typing import Optional, Dict, Any, List


class GeminiClient:
    """
    Google Gemini API Async Client

    사용 가능한 모델 목록:
        https://ai.google.dev/gemini-api/docs/models
    """
    BASE_URL = "https://generativelanguage.googleapis.com"

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the Gemini client.
        :param api_key: Gemini API Key. If not provided, it looks for GEMINI_API_KEY env var.
        """
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY environment variable is not set")
        self.session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        self.session = aiohttp.ClientSession(
            headers={"Content-Type": "application/json"}
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
            self.session = None

    async def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        url = f"{self.BASE_URL}{endpoint}"
        params = kwargs.pop("params", {})
        params["key"] = self.api_key

        if self.session:
            async with self.session.request(method, url, params=params, **kwargs) as response:
                if not response.ok:
                    error_text = await response.text()
                    raise aiohttp.ClientResponseError(
                        response.request_info,
                        response.history,
                        status=response.status,
                        message=f"{response.reason}, body={error_text}",
                        headers=response.headers
                    )
                return await response.json()

        async with aiohttp.ClientSession(
            headers={"Content-Type": "application/json"}
        ) as session:
            async with session.request(method, url, params=params, **kwargs) as response:
                if not response.ok:
                    error_text = await response.text()
                    raise aiohttp.ClientResponseError(
                        response.request_info,
                        response.history,
                        status=response.status,
                        message=f"{response.reason}, body={error_text}",
                        headers=response.headers
                    )
                return await response.json()

    async def generate(
        self,
        prompt: str,
        model: str = "gemini-2.0-flash",
        max_tokens: int = 1024,
        temperature: Optional[float] = None,
        system_instruction: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Gemini generateContent 호출 (단일 턴)

        사용 가능한 모델: https://ai.google.dev/gemini-api/docs/models

        :param prompt: 사용자 프롬프트
        :param model: 모델 ID (기본값: 'gemini-2.0-flash')
        :param max_tokens: 최대 출력 토큰 수 (기본값: 1024)
        :param temperature: 생성 온도 (None이면 API 기본값)
        :param system_instruction: 시스템 프롬프트 (Optional)
        :return: Gemini API 응답 JSON
        """
        endpoint = f"/v1beta/models/{model}:generateContent"

        body: Dict[str, Any] = {
            "contents": [
                {
                    "parts": [{"text": prompt}]
                }
            ],
            "generationConfig": {
                "maxOutputTokens": max_tokens,
            }
        }

        if temperature is not None:
            body["generationConfig"]["temperature"] = temperature

        if system_instruction:
            body["systemInstruction"] = {
                "parts": [{"text": system_instruction}]
            }

        return await self._request("POST", endpoint, json=body)

    async def generate_multiturn(
        self,
        contents: List[Dict[str, Any]],
        model: str = "gemini-2.0-flash",
        max_tokens: int = 1024,
        temperature: Optional[float] = None,
        system_instruction: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Gemini generateContent 호출 (멀티턴 대화)

        사용 가능한 모델: https://ai.google.dev/gemini-api/docs/models

        :param contents: 대화 히스토리 (role/parts 딕셔너리 리스트)
        :param model: 모델 ID (기본값: 'gemini-2.0-flash')
        :param max_tokens: 최대 출력 토큰 수 (기본값: 1024)
        :param temperature: 생성 온도 (None이면 API 기본값)
        :param system_instruction: 시스템 프롬프트 (Optional)
        :return: Gemini API 응답 JSON
        """
        endpoint = f"/v1beta/models/{model}:generateContent"

        body: Dict[str, Any] = {
            "contents": contents,
            "generationConfig": {
                "maxOutputTokens": max_tokens,
            }
        }

        if temperature is not None:
            body["generationConfig"]["temperature"] = temperature

        if system_instruction:
            body["systemInstruction"] = {
                "parts": [{"text": system_instruction}]
            }

        return await self._request("POST", endpoint, json=body)

    @staticmethod
    def extract_text(response: Dict[str, Any]) -> str:
        """
        Gemini 응답에서 텍스트만 추출

        :param response: generate() 또는 generate_multiturn()의 반환값
        :return: 생성된 텍스트
        """
        try:
            return response["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError):
            return ""
