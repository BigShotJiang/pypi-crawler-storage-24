import asyncio
import logging
import datetime
import json
from typing import List, Dict, Optional
from tqdm.asyncio import tqdm
import pandas as pd
from pathlib import Path
import gc
from ..client.http import DeepSearchClient
from .store import MarketDataCache
from .collection_index import CollectionIndex
from .news import chunk_date_range

logger = logging.getLogger(__name__)


async def fetch_symbol_disclosure(
    client: DeepSearchClient,
    symbol: Optional[str],
    date_from: str,
    date_to: str,
    semaphore: asyncio.Semaphore,
    max_retries: int = 3,
    save_raw_response: bool = False,
    raw_response_dir: Optional[str] = None,
    **kwargs
) -> List[Dict]:
    """
    단일 심볼 또는 키워드 공시 데이터 비동기 요청 (페이징 포함)

    Args:
        client: API 클라이언트
        symbol: 종목 코드 (Optional)
        date_from: 시작일
        date_to: 종료일
        semaphore: 동시성 제어 세마포어
        max_retries: 재시도 횟수
        save_raw_response: 원본 응답 저장 여부
        raw_response_dir: 원본 응답 저장 경로
        **kwargs: 추가 검색 파라미터 (keyword, company_name, filing_type, order)
    """
    async with semaphore:
        for attempt in range(max_retries):
            try:
                query_symbol = None
                if symbol:
                    query_symbol = symbol
                    if symbol.isdigit() and len(symbol) == 6:
                        query_symbol = f"KRX:{symbol}"

                target_keyword = kwargs.get('keyword')

                all_processed_data = []
                page = 1
                max_pages = 1000

                while page <= max_pages:
                    response = await client.get_filings(
                        symbols=query_symbol,
                        date_from=date_from,
                        date_to=date_to,
                        page=page,
                        page_size=100,
                        **kwargs
                    )

                    if save_raw_response and raw_response_dir:
                        try:
                            save_dir = Path(raw_response_dir) / date_from[:4]
                            save_dir.mkdir(parents=True, exist_ok=True)
                            file_ident = symbol if symbol else (target_keyword if target_keyword else 'ALL')
                            filename = f"disclosure_{file_ident}_{date_from}_{date_to}_p{page}.json"
                            file_path = save_dir / filename
                            with open(file_path, "w", encoding="utf-8") as f:
                                json.dump(response, f, ensure_ascii=False, indent=2)
                        except Exception as e:
                            logger.error(f"Failed to save raw response: {e}")

                    data = response.get('data', [])
                    if not data:
                        break

                    for item in data:
                        processed_item = item.copy()
                        processed_item['keyword'] = target_keyword
                        processed_item['symbol_req'] = symbol

                        resp_companies = item.get('companies', [])
                        extracted_symbols = []
                        extracted_names = []

                        if resp_companies and isinstance(resp_companies, list):
                            for comp in resp_companies:
                                if isinstance(comp, dict):
                                    comp_symbol = comp.get('symbol')
                                    comp_name = comp.get('name')
                                    if comp_symbol:
                                        extracted_symbols.append(comp_symbol)
                                    if comp_name:
                                        extracted_names.append(comp_name)

                        if not extracted_symbols:
                            if symbol:
                                extracted_symbols = [symbol]

                        processed_item['symbol'] = extracted_symbols
                        processed_item['symbol_name'] = extracted_names
                        processed_item['date'] = item.get('published_at', '')

                        if 'url' not in processed_item:
                            processed_item['url'] = item.get('content_url', '')

                        all_processed_data.append(processed_item)

                    total_pages = response.get('total_pages', 0)
                    if page >= total_pages:
                        break

                    page += 1

                return all_processed_data

            except Exception as e:
                if attempt == max_retries - 1:
                    logger.error(f"Error fetching disclosure for {symbol}: {e}")
                    return []
                await asyncio.sleep(2 ** attempt)
        return []


async def prepare_disclosure_data(
    symbols: Optional[List[str]] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    cache_dir: str = ".cache/disclosure_data",
    concurrency: int = 10,
    force_refresh: bool = False,
    flush: bool = False,
    verbose: bool = True,
    save_raw_response: bool = False,
    raw_response_dir: Optional[str] = None,
    **kwargs
) -> MarketDataCache:
    """
    공시 데이터 준비 메인 함수

    Args:
        symbols: 조회할 티커 리스트 (Optional)
        date_from: 시작 날짜 (YYYY-MM-DD)
        date_to: 종료 날짜 (YYYY-MM-DD)
        cache_dir: 캐시 디렉토리
        concurrency: 동시 요청 수
        force_refresh: 캐시 무시하고 새로 요청 여부
        flush: 기존 캐시 파일을 삭제하고 처음부터 다시 시작할지 여부
        verbose: 상세 로그 출력 여부 (기본값: True)
        save_raw_response: 원본 JSON 응답 저장 여부
        raw_response_dir: 원본 저장 경로
        **kwargs: 추가 검색 파라미터 (keyword, company_name, filing_type, order)
    """
    if date_from is None or date_to is None:
        raise ValueError("date_from and date_to must be provided")

    if flush:
        import shutil
        cache_path = Path(cache_dir)
        if cache_path.exists():
            if verbose:
                logger.warning(f"Flush requested. Deleting cache directory: {cache_dir}")
            try:
                shutil.rmtree(cache_path)
            except Exception as e:
                logger.error(f"Failed to delete cache directory: {e}")

    cache = MarketDataCache(cache_dir)
    client = DeepSearchClient()
    semaphore = asyncio.Semaphore(concurrency)

    date_to_dt = pd.to_datetime(date_to).date()
    date_from_dt = pd.to_datetime(date_from).date()

    symbols_to_fetch = []

    if not symbols:
        target_iterator = [None]
        identifier = kwargs.get('keyword')
        if verbose:
            logger.info(f"Checking disclosure cache for keyword: '{identifier}'...")
    else:
        target_iterator = symbols
        if verbose:
            logger.info(f"Checking disclosure cache for {len(symbols)} symbols...")

    for symbol in target_iterator:
        fetch_start = date_from_dt
        cache_key_keyword = kwargs.get('keyword')

        if not force_refresh:
            if symbol:
                last_date = cache.get_last_news_date(symbol=symbol)
            elif cache_key_keyword:
                last_date = cache.get_last_news_date(keyword=cache_key_keyword)
            else:
                last_date = None

            if last_date:
                if last_date >= date_to_dt:
                    continue
                fetch_start = max(date_from_dt, last_date + datetime.timedelta(days=1))

        if fetch_start > date_to_dt:
            continue

        symbols_to_fetch.append((symbol, fetch_start.strftime("%Y-%m-%d")))

    if not symbols_to_fetch:
        if verbose:
            logger.info("All disclosure data is up to date.")
        return cache

    if verbose:
        logger.info(f"Fetching disclosure for {len(symbols_to_fetch)} items...")

    async with client:
        fetch_tasks = []
        for symbol, start_date in symbols_to_fetch:
            task_start_dt = pd.to_datetime(start_date).date()
            task_end_dt = date_to_dt

            for chunk_start, chunk_end in chunk_date_range(task_start_dt, task_end_dt):
                fetch_tasks.append(
                    fetch_symbol_disclosure(
                        client,
                        symbol,
                        chunk_start.strftime("%Y-%m-%d"),
                        chunk_end.strftime("%Y-%m-%d"),
                        semaphore,
                        save_raw_response=save_raw_response,
                        raw_response_dir=raw_response_dir,
                        **kwargs
                    )
                )

        results = []
        iterator = tqdm.as_completed(fetch_tasks, total=len(fetch_tasks), desc="Fetching Disclosure") if verbose else asyncio.as_completed(fetch_tasks)
        for f in iterator:
            res = await f
            results.append(res)

        all_new_data = []
        for res in results:
            all_new_data.extend(res)

        if all_new_data:
            if verbose:
                logger.info(f"Fetched {len(all_new_data)} disclosure items. Updating cache...")
            cache.update_news_data(all_new_data)
            cache.save()
            if verbose:
                logger.info("Disclosure cache saved.")
        else:
            if verbose:
                logger.info("No new disclosure fetched.")

    return cache


async def collect_disclosure_frozen(
    target_symbols: list,
    start_date: str,
    end_date: str,
    base_cache_dir: str = ".cache/disclosure_data_batches",
    batch_size: int = 50,
    concurrency: int = 10,
    verbose: bool = True,
    save_raw_response: bool = False,
    raw_response_dir: Optional[str] = None,
    keyword: Optional[str] = None,
    company_name: Optional[str] = None,
    filing_type: Optional[str] = None,
    order: Optional[str] = None,
    **kwargs
):
    """
    대용량 공시 데이터 고정 수집 함수 (심볼x기간 단위로 갭만 수집)

    Args:
        target_symbols: 수집할 종목 코드 리스트
        start_date: 시작일 (YYYY-MM-DD)
        end_date: 종료일 (YYYY-MM-DD)
        base_cache_dir: 데이터를 저장할 기본 디렉토리
        batch_size: 한 번에 처리할 종목 수
        concurrency: 동시 요청 수
        verbose: 진행 상황 출력 여부
        save_raw_response: 원본 응답 저장 여부
        raw_response_dir: 원본 저장 경로
        keyword: 검색 키워드
        company_name: 회사 이름
        filing_type: 공시 유형
        order: 정렬 기준
    """
    BASE_DIR = Path(base_cache_dir)
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    TEMP_DIR = BASE_DIR / "temp_worker"

    index = CollectionIndex(str(BASE_DIR))

    symbols_to_fetch = []
    skipped = []

    for symbol in target_symbols:
        gaps = index.get_gaps(symbol, start_date, end_date)
        if gaps:
            symbols_to_fetch.append((symbol, gaps))
        else:
            skipped.append(symbol)

    if verbose:
        print("=== Frozen Disclosure Data Collection Start ===")
        print(f"Total Targets: {len(target_symbols)} symbols")
        print(f"Period: {start_date} ~ {end_date}")
        print(f"To fetch: {len(symbols_to_fetch)} symbols | Already covered: {len(skipped)} symbols")

    if not symbols_to_fetch:
        if verbose:
            print("All symbols are already fully covered. Nothing to do.")
        return

    batch_items = []
    for i in range(0, len(symbols_to_fetch), batch_size):
        batch_items.append(symbols_to_fetch[i : i + batch_size])

    total_batches = len(batch_items)

    if verbose:
        print(f"Batch Size: {batch_size} | Total Batches: {total_batches}")

    iterator = enumerate(batch_items, 1)
    if verbose:
        iterator = tqdm(
            list(iterator),
            total=total_batches,
            desc="Overall Progress",
            unit="batch",
        )

    api_params = {
        "keyword": keyword,
        "company_name": company_name,
        "filing_type": filing_type,
        "order": order,
        **kwargs,
    }

    total_fetched = 0
    total_skipped = len(skipped)

    for batch_num, batch in iterator:
        if verbose:
            gap_summary = ", ".join(
                f"{sym}({len(gaps)} gaps)" for sym, gaps in batch
            )
            tqdm.write(f"\nBatch {batch_num}/{total_batches}: {gap_summary}")

        for symbol, gaps in batch:
            for gap_from, gap_to in gaps:
                try:
                    temp_cache = await prepare_disclosure_data(
                        [symbol],
                        gap_from,
                        gap_to,
                        cache_dir=str(TEMP_DIR),
                        concurrency=concurrency,
                        force_refresh=True,
                        flush=True,
                        verbose=False,
                        save_raw_response=save_raw_response,
                        raw_response_dir=raw_response_dir,
                        **api_params,
                    )

                    rows = 0
                    if not temp_cache.news_data.empty:
                        safe_sym = symbol.replace(":", "_")
                        fname = f"disclosure_{safe_sym}_{gap_from.replace('-','')}_{gap_to.replace('-','')}.parquet"
                        out_file = BASE_DIR / fname

                        if out_file.exists():
                            existing = pd.read_parquet(out_file)
                            merged = pd.concat([existing, temp_cache.news_data], ignore_index=True)
                            merged.to_parquet(out_file, index=False)
                            rows = len(merged)
                        else:
                            temp_cache.news_data.to_parquet(out_file, index=False)
                            rows = len(temp_cache.news_data)

                        if verbose:
                            tqdm.write(f"  {symbol} [{gap_from} ~ {gap_to}]: {rows} rows -> {out_file.name}")
                    else:
                        if verbose:
                            tqdm.write(f"  {symbol} [{gap_from} ~ {gap_to}]: no data")

                    index.mark_collected(symbol, gap_from, gap_to)
                    index.save()
                    total_fetched += rows

                    del temp_cache
                    gc.collect()

                except Exception as e:
                    logger.error(f"Error fetching {symbol} [{gap_from}~{gap_to}]: {e}")
                    if verbose:
                        tqdm.write(f"  Error {symbol} [{gap_from} ~ {gap_to}]: {e}")
                    continue

    if verbose:
        print(f"\n=== Collection Completed ===")
        print(f"Fetched: {len(symbols_to_fetch)} symbols ({total_fetched} rows) | Skipped: {total_skipped} symbols")
        print(f"Data saved in: {BASE_DIR}")
        print(f"Index saved: {index._path}")
