"""mspec - 成员规范驱动开发工作流 CLI 工具"""

__version__ = "4.0.0"
__author__ = "mspec Team"
__email__ = "team@mspec.io"
