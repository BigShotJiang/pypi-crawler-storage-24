#!/usr/bin/env python3
"""doctor 命令实现"""

import shutil
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from mspec.core.openspec_manager import OpenspecManager, OpenspecStatus
from mspec.utils.console import print_error, print_success, print_warning

console = Console()


@click.command(name="doctor")
def doctor_cmd() -> None:
    """诊断环境配置

    检查 mspec 运行所需的环境配置是否正确。

    示例:
        mspec doctor
    """
    console.print("[bold blue]🔍 mspec 环境诊断[/bold blue]\n")

    checks = [
        ("Python 版本", _check_python_version),
        ("openspec CLI", _check_openspec_cli),
        ("openspec/ 目录", _check_openspec_dir),
        ("config.yaml", _check_config_file),
        ("模板文件", _check_template_files),
        ("Git 安装", _check_git),
    ]

    results = []
    all_passed = True

    for name, check_fn in checks:
        console.print(f"  检查 {name}...", end=" ")
        try:
            result = check_fn()
            if result["ok"]:
                message = result.get("message", "")
                if message:
                    console.print(f"[green]✓[/green] {message}")
                else:
                    console.print("[green]✓[/green]")
                results.append((name, True, result.get("message", "")))
            else:
                console.print(f"[red]✗[/red] {result['message']}")
                results.append((name, False, result["message"]))
                all_passed = False
        except Exception as e:
            console.print(f"[red]✗[/red] {e}")
            results.append((name, False, str(e)))
            all_passed = False

    # 显示结果表格
    console.print()
    table = Table(show_header=False, box=None)
    table.add_column("检查项")
    table.add_column("状态")

    for name, passed, _ in results:
        status = "[green]✓ 通过[/green]" if passed else "[red]✗ 失败[/red]"
        table.add_row(name, status)

    console.print(table)
    console.print()

    if all_passed:
        print_success("所有检查通过，环境正常！")
    else:
        print_warning("部分检查未通过，请参考上述提示修复")
        sys.exit(1)


def _check_python_version() -> dict:
    """检查 Python 版本"""
    if sys.version_info < (3, 8):
        return {"ok": False, "message": "需要 Python 3.8+"}
    return {"ok": True, "message": f"{sys.version.split()[0]}"}


def _check_openspec_cli() -> dict:
    """检查 openspec CLI 是否安装"""
    manager = OpenspecManager()
    status = manager.check()

    if status == OpenspecStatus.INSTALLED:
        version = manager.get_version()
        version_str = f" ({version})" if version else ""
        return {"ok": True, "message": f"已安装{version_str}"}
    elif status == OpenspecStatus.NPX_AVAILABLE:
        return {
            "ok": True,
            "message": "未全局安装，但可通过 npx 运行",
        }
    else:
        return {
            "ok": False,
            "message": "未安装。运行 `npm install -g @fission-ai/openspec` 安装",
        }


def _check_openspec_dir() -> dict:
    """检查 openspec 目录"""
    if not Path("openspec").exists():
        return {
            "ok": False,
            "message": "未找到 openspec/ 目录，请先运行 mspec init",
        }
    return {"ok": True, "message": ""}


def _check_config_file() -> dict:
    """检查配置文件"""
    config_path = Path("openspec/config.yaml")
    if not config_path.exists():
        return {"ok": False, "message": "未找到 config.yaml"}
    return {"ok": True, "message": ""}


def _check_template_files() -> dict:
    """检查模板文件"""
    templates_path = Path("openspec/templates")
    if not templates_path.exists():
        return {"ok": False, "message": "未找到 templates/ 目录"}

    required_files = [
        "requirement-issue-taxonomy.md",
        "design-issue-taxonomy.md",
        "requirement-issues.md",
        "design-issues.md",
    ]

    missing = []
    for file in required_files:
        if not (templates_path / file).exists():
            missing.append(file)

    if missing:
        return {"ok": False, "message": f"缺少文件: {', '.join(missing)}"}

    return {"ok": True, "message": ""}


def _check_git() -> dict:
    """检查 Git 安装"""
    if shutil.which("git") is None:
        return {"ok": False, "message": "未找到 Git，请先安装 Git"}
    return {"ok": True, "message": ""}
