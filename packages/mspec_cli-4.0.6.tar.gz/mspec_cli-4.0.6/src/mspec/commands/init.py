#!/usr/bin/env python3
"""init 命令实现"""

import subprocess
from pathlib import Path
from typing import Optional

import click
import questionary
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from mspec.core.config import ConfigManager
from mspec.core.openspec_manager import OpenspecManager, OpenspecStatus
from mspec.core.template import TemplateManager
from mspec.utils.console import print_error, print_success

console = Console()


@click.command(name="init")
@click.argument("path", required=False, default=".")
@click.option("--template", "-t", help="使用自定义模板仓库 URL")
@click.option("--force", "-f", is_flag=True, help="强制覆盖已有配置")
@click.option("--dry-run", is_flag=True, help="模拟运行，不实际创建文件")
@click.option("--yes", "-y", is_flag=True, help="跳过确认，使用默认配置")
@click.pass_context
def init_cmd(
    ctx: click.Context,
    path: str,
    template: Optional[str],
    force: bool,
    dry_run: bool,
    yes: bool,
) -> None:
    """初始化 mspec 项目

    PATH 是项目目录路径，默认为当前目录。

    示例:
        mspec init                    # 初始化当前目录
        mspec init ./my-project       # 初始化指定目录
        mspec init --force            # 强制覆盖已有配置
        mspec init --template <url>   # 使用自定义模板
    """
    target_path = Path(path).resolve()
    openspec_path = target_path / "openspec"

    console.print(
        Panel.fit(
            f"[bold blue]📦 mspec 初始化[/bold blue]\n"
            f"目标目录: [cyan]{target_path}[/cyan]",
            title="mspec",
            border_style="blue",
        )
    )

    # 检查现有配置
    if openspec_path.exists() and not force:
        if not yes:
            overwrite = questionary.confirm(
                "openspec/ 目录已存在，是否覆盖？", default=False
            ).ask()
            if not overwrite:
                console.print("[yellow]已取消[/yellow]")
                return

    # 获取模板
    template_manager = TemplateManager()

    if template:
        console.print(f"[dim]正在下载自定义模板: {template}[/dim]")
        try:
            files = template_manager.download_from_url(template)
        except Exception as e:
            print_error(f"下载模板失败: {e}")
            return
    else:
        console.print("[dim]使用内置模板[/dim]")
        files = template_manager.get_builtin_templates()

    # 模拟运行模式
    if dry_run:
        _show_dry_run(files, target_path)
        return

    # 确认安装
    if not yes:
        _show_files_table(files, target_path)
        confirm = questionary.confirm("确认初始化?", default=True).ask()
        if not confirm:
            return

    # 调用 openspec init 初始化 OpenSpec 目录结构
    _run_openspec_init(target_path)

    # 创建目录和文件
    console.print("\n[dim]正在创建文件...[/dim]")
    try:
        _create_files(files, openspec_path)
        print_success("文件创建完成")
    except Exception as e:
        print_error(f"创建文件失败: {e}")
        return

    # 验证安装
    console.print("[dim]正在验证配置...[/dim]")
    config_manager = ConfigManager(openspec_path)
    validation = config_manager.validate()

    if validation.valid:
        print_success("验证通过")
        _print_success_message()
    else:
        print_error("验证失败:")
        for error in validation.errors:
            console.print(f"  [red]• {error}[/red]")


def _run_openspec_init(target_path: Path) -> bool:
    """调用 openspec init 初始化 OpenSpec 目录结构

    支持自动检测 openspec，如未安装则尝试使用 npx 或自动安装

    Args:
        target_path: 目标目录路径

    Returns:
        bool: 是否成功调用 openspec init
    """
    manager = OpenspecManager()

    # 1. 检查当前状态
    status = manager.check()

    if status == OpenspecStatus.INSTALLED:
        console.print("[dim]检测到 openspec 已安装[/dim]")
    elif status == OpenspecStatus.NPX_AVAILABLE:
        console.print("[dim]openspec 未全局安装，将使用 npx 运行[/dim]")
    else:
        # 检查 npm 是否安装
        import shutil

        if not shutil.which("npm"):
            manager.print_npm_not_found_guide()
            # 询问是否继续（不使用 openspec）
            continue_anyway = questionary.confirm(
                "是否继续初始化（跳过 openspec）?", default=True
            ).ask()
            return continue_anyway

        console.print("[yellow]openspec 未安装，正在尝试自动安装...[/yellow]")
        if manager.install():
            # 重新检测
            status = manager.check()
        else:
            # 安装失败，打印指引
            manager.print_install_guide()
            # 询问是否继续（不使用 openspec）
            continue_anyway = questionary.confirm(
                "是否继续初始化（跳过 openspec）?", default=True
            ).ask()
            return continue_anyway

    # 2. 执行 openspec init（交互模式，让用户可以看到界面并交互）
    console.print("[dim]正在调用 openspec init...[/dim]")
    try:
        result = manager.run(["init"], cwd=target_path, interactive=True)
        if result.returncode == 0:
            console.print("[green]✓ openspec init 完成[/green]")
            return True
        else:
            console.print("[yellow]⚠ openspec init 返回非零退出码，继续执行...[/yellow]")
            return True  # 仍视为成功，继续执行
    except Exception as e:
        console.print(f"[yellow]⚠ openspec init 执行异常: {e}[/yellow]")
        return True  # 仍视为成功，继续执行


def _show_dry_run(files: dict, target_path: Path) -> None:
    """显示模拟运行信息"""
    console.print("\n[cyan]📋 模拟运行 - 将执行以下操作：[/cyan]")
    console.print("  [dim]• 调用 openspec init 初始化 OpenSpec 目录结构[/dim]")
    console.print("  [dim]• 创建以下文件：[/dim]")
    for file_path in files.keys():
        full_path = target_path / "openspec" / file_path
        console.print(f"  [green]✓[/green] {full_path}")


def _show_files_table(files: dict, target_path: Path) -> None:
    """显示文件表格"""
    table = Table(title="将创建以下文件")
    table.add_column("文件", style="cyan")
    table.add_column("大小", style="dim")

    for file_path, content in files.items():
        size = len(content.encode("utf-8"))
        size_str = f"{size} B" if size < 1024 else f"{size / 1024:.1f} KB"
        table.add_row(str(file_path), size_str)

    console.print()
    console.print(table)


def _create_files(files: dict, openspec_path: Path) -> None:
    """创建文件"""
    openspec_path.mkdir(parents=True, exist_ok=True)
    (openspec_path / "templates").mkdir(exist_ok=True)

    for file_path, content in files.items():
        full_path = openspec_path / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")
        console.print(f"  [green]✓[/green] {file_path}")


def _print_success_message() -> None:
    """打印成功消息"""
    console.print("\n[bold green]✅ 初始化完成![/bold green]\n")
    console.print("接下来你可以：")
    console.print("  • 使用 [cyan]/opsx:propose[/cyan] 创建新变更")
    console.print("  • 使用 [cyan]mspec doctor[/cyan] 检查环境")
    console.print("  • 查看 [cyan]https://docs.mspec.io[/cyan] 获取完整文档")
