"""Utility helpers for DBDuck."""
