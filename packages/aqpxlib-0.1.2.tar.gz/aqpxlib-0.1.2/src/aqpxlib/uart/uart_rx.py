# Copyright 2025 Acute Technology Inc. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
"""UART RX Target Class."""

from typing import TYPE_CHECKING, ClassVar

from aqpxlib.abstract import PxAbstractTarget

if TYPE_CHECKING:
    from aqpxlib.toplevel import AqProtocolExerciser

from ._uart_message import PxUartConfig, PxUartParityMode


class PxUartRx(PxAbstractTarget):
    """Uart Rx Class."""

    # Used to identify the class
    identifier: str = "uart_rx"
    protobuf_key: str = "uart_rx"
    valid_buses: ClassVar[list[str]] = ["uart"]

    # All inherited devices shall add the event fields to the list they accept
    _protobuf_available_event_fields: ClassVar[list[str]] = [
        "uart_rx_data",
    ]

    def __init__(
        self,
        exerciser: "AqProtocolExerciser",
        baud_rate: int = 9600,
        stop_bits: int = 1,
        data_bits: int = 8,
        parity: PxUartParityMode = PxUartParityMode.PARITY_MODE_NONE,
        config: PxUartConfig | None = None,
        *args,
        **kwargs,
    ) -> None:
        """Initialize UART Rx."""
        if config is None:
            config = PxUartConfig(
                baud_rate=baud_rate,
                stop_bits=stop_bits,
                data_bits=data_bits,
                parity=parity,
                enabled=1,
            )

        super().__init__(exerciser, config=config, *args, **kwargs)


__all__ = [
    "PxUartRx",
]
