# Copyright 2025 Acute Technology Inc. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
"""I3C Common Command Code Definition."""

from aqpxlib.message import I3CCommonCommandCode as PxI3CCommonCommandCode

__all__ = [
    "PxI3CCommonCommandCode",
]
