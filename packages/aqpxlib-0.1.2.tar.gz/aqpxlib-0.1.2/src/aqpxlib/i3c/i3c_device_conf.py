# Copyright 2025 Acute Technology Inc. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
"""I3C Device Configuration."""

ACUTE_DEFAULT_MANUFACTURER_ID = 0x0495
ACUTE_DEFAULT_PID = ACUTE_DEFAULT_MANUFACTURER_ID << 33
