# ChopChop

PyPI-ready packaging for the ChopChop Streamlit app.

## Install

```bash
pip install chopchop-wenxi
```

## Run

```bash
chopchop
```

## What it does

ChopChop splits large files into smaller, LLM-ready chunks and can package the outputs into a single ZIP.
