from __future__ import annotations

import subprocess
import sys
from importlib.resources import files


def main() -> None:
    app_path = files("chopchop_app").joinpath("app.py")
    cmd = [sys.executable, "-m", "streamlit", "run", str(app_path)]
    raise SystemExit(subprocess.call(cmd))
