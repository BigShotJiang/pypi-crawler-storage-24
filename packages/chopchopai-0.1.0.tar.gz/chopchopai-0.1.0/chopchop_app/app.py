import io
import math
import os
import zipfile
from pathlib import Path
from typing import List, Tuple, Optional

import streamlit as st
from PIL import Image
from pypdf import PdfReader, PdfWriter


TEXT_EXTS = {
    ".txt", ".md", ".csv", ".json", ".yaml", ".yml",
    ".py", ".js", ".ts", ".java", ".cpp", ".c", ".h",
    ".go", ".rs", ".swift", ".kt", ".html", ".css", ".xml",
    ".toml", ".ini", ".log",
}
IMAGE_EXTS = {".png", ".jpg", ".jpeg"}


def do_rerun() -> None:
    """Rerun Streamlit app across versions."""
    if hasattr(st, "rerun"):
        st.rerun()
        return
    if hasattr(st, "experimental_rerun"):
        st.experimental_rerun()


def split_bytes(data: bytes, chunk_size: int):
    for i in range(0, len(data), chunk_size):
        yield data[i:i + chunk_size]


def split_utf8_safely(data: bytes, chunk_size: int):
    """Split bytes while trying not to cut inside UTF-8 continuation bytes."""
    i = 0
    n = len(data)
    while i < n:
        j = min(i + chunk_size, n)
        while j > i and (data[j - 1] & 0xC0) == 0x80:
            j -= 1
        if j == i:
            j = min(i + chunk_size, n)
        yield data[i:j]
        i = j


def is_zip_bytes(b: bytes) -> bool:
    return zipfile.is_zipfile(io.BytesIO(b))


def is_pdf_bytes(b: bytes) -> bool:
    return b[:5] == b"%PDF-"


def sanitize_folder_name(name: str) -> str:
    bad = '<>:"/\\|?*'
    for ch in bad:
        name = name.replace(ch, "_")
    return (name.strip() or "item")


def image_tiles_by_target_size(
    img_bytes: bytes,
    out_ext: str,
    target_bytes: int,
    overlap_px: int = 0,
) -> List[Tuple[str, bytes]]:
    """Decode image and crop into tiles so each part is a valid image (best-effort size control)."""
    with Image.open(io.BytesIO(img_bytes)) as im:
        im = im.convert("RGBA") if out_ext.lower() == ".png" else im.convert("RGB")
        w, h = im.size
        if w <= 0 or h <= 0:
            return []

        # Initial guess: how many tiles needed based on raw file size.
        n_tiles = max(1, math.ceil(len(img_bytes) / max(1, target_bytes)))

        def grid_for_n(n: int) -> Tuple[int, int]:
            aspect = w / h if h else 1.0
            cols = max(1, math.ceil(math.sqrt(n * aspect)))
            rows = max(1, math.ceil(n / cols))
            return cols, rows

        def make_tiles(cols: int, rows: int) -> List[Tuple[str, bytes]]:
            tile_w = math.ceil(w / cols)
            tile_h = math.ceil(h / rows)
            out: List[Tuple[str, bytes]] = []
            idx = 1
            for r in range(rows):
                for c in range(cols):
                    left = c * tile_w
                    top = r * tile_h
                    right = min((c + 1) * tile_w, w)
                    bottom = min((r + 1) * tile_h, h)

                    # apply overlap
                    left2 = max(0, left - overlap_px)
                    top2 = max(0, top - overlap_px)
                    right2 = min(w, right + overlap_px)
                    bottom2 = min(h, bottom + overlap_px)

                    # guard against invalid crop boxes
                    if right2 <= left2 or bottom2 <= top2:
                        continue

                    tile = im.crop((left2, top2, right2, bottom2))
                    buf = io.BytesIO()
                    if out_ext.lower() == ".png":
                        tile.save(buf, format="PNG", optimize=True)
                    else:
                        tile.save(buf, format="JPEG", quality=92, optimize=True)
                    out.append((f"tile{idx:04d}{out_ext}", buf.getvalue()))
                    idx += 1
            return out

        # Iterate: increase tile count if a tile is still too large (best-effort).
        for _ in range(10):
            cols, rows = grid_for_n(n_tiles)
            tiles = make_tiles(cols, rows)
            if not tiles:
                return []
            biggest = max(len(b) for _, b in tiles)
            if biggest <= target_bytes or n_tiles >= 5000:
                return tiles
            n_tiles = int(n_tiles * 1.5) + 1

        return tiles


def split_pdf_readable(pdf_bytes: bytes, target_bytes: int) -> List[Tuple[str, bytes]]:
    """Split PDF into valid PDFs by grouping pages until size would exceed target_bytes."""
    reader = PdfReader(io.BytesIO(pdf_bytes))
    parts: List[Tuple[str, bytes]] = []

    def writer_bytes(wr: PdfWriter) -> bytes:
        buf = io.BytesIO()
        wr.write(buf)
        return buf.getvalue()

    writer = PdfWriter()
    last_good: Optional[bytes] = None
    part_idx = 1

    for page in reader.pages:
        writer.add_page(page)
        cur = writer_bytes(writer)

        if len(cur) <= target_bytes:
            last_good = cur
            continue

        if last_good is None:
            # even single page exceeds target; still output it
            parts.append((f"part{part_idx:04d}.pdf", cur))
            part_idx += 1
            writer = PdfWriter()
            last_good = None
            continue

        parts.append((f"part{part_idx:04d}.pdf", last_good))
        part_idx += 1

        writer = PdfWriter()
        writer.add_page(page)
        last_good = writer_bytes(writer)

    if last_good is not None:
        parts.append((f"part{part_idx:04d}.pdf", last_good))

    return parts


def add_to_zip(zf: zipfile.ZipFile, manifest: List[Tuple[str, int]], zip_path: str, data: bytes):
    zf.writestr(zip_path, data)
    manifest.append((zip_path, len(data)))


def process_single_file(
    zf: zipfile.ZipFile,
    manifest: List[Tuple[str, int]],
    group_root: str,
    rel_path: str,
    data: bytes,
    target_bytes: int,
    overlap_px: int,
):
    p = Path(rel_path)
    ext = p.suffix.lower()
    stem = p.stem
    safe_group = sanitize_folder_name(group_root)

    base_dir = f"chopchop_output/{safe_group}/{p.parent.as_posix()}".rstrip("/")
    base_dir = base_dir if base_dir else f"chopchop_output/{safe_group}"
    file_dir = f"{base_dir}/{sanitize_folder_name(stem)}"

    # ZIP inputs: treat as folder container (don't byte-split)
    if ext == ".zip" and is_zip_bytes(data):
        try:
            with zipfile.ZipFile(io.BytesIO(data), "r") as inner:
                for info in inner.infolist():
                    if info.is_dir():
                        continue
                    inner_bytes = inner.read(info.filename)
                    inner_name = info.filename
                    process_single_file(
                        zf,
                        manifest,
                        group_root=f"{safe_group}/{sanitize_folder_name(stem)}",
                        rel_path=inner_name,
                        data=inner_bytes,
                        target_bytes=target_bytes,
                        overlap_px=overlap_px,
                    )
            return
        except Exception:
            # corrupted zip: fallback below
            pass

    # Images: decode + tile
    if ext in IMAGE_EXTS:
        out_ext = ".png" if ext == ".png" else ".jpg"
        try:
            tiles = image_tiles_by_target_size(data, out_ext, target_bytes, overlap_px=overlap_px)
            if tiles:
                for name, b in tiles:
                    add_to_zip(zf, manifest, f"{file_dir}/{stem}_{name}", b)
                return
        except Exception:
            pass

    # PDFs: split into readable PDFs
    if ext == ".pdf" and is_pdf_bytes(data):
        try:
            parts = split_pdf_readable(data, target_bytes)
            if parts:
                for name, b in parts:
                    add_to_zip(zf, manifest, f"{file_dir}/{stem}_{name}", b)
                return
        except Exception:
            pass

    # Text/code: keep UTF-8 readable
    if ext in TEXT_EXTS:
        idx = 1
        for chunk in split_utf8_safely(data, target_bytes):
            add_to_zip(zf, manifest, f"{file_dir}/{stem}_part{idx:04d}{ext}", chunk)
            idx += 1
        return

    # Other binary: split by bytes (cannot guarantee independent usability)
    idx = 1
    for chunk in split_bytes(data, target_bytes):
        add_to_zip(zf, manifest, f"{file_dir}/{stem}_part{idx:04d}{ext}", chunk)
        idx += 1


def main():
    st.set_page_config(page_title="ChopChop", layout="wide")
    st.title("✂️ ChopChop – Smart Splitter (Readable Parts)")

    if "uploader_key" not in st.session_state:
        st.session_state.uploader_key = 1
    if "output_zip" not in st.session_state:
        st.session_state.output_zip = None
    if "manifest" not in st.session_state:
        st.session_state.manifest = []

    left, right = st.columns([1, 1], gap="large")

    with left:
        st.subheader("Input")
        st.caption("You can upload a folder using the directory upload option.")

        # Directory upload is supported in newer Streamlit versions.
        # Fallback to multi-file upload if the current version doesn't support it.
        try:
            uploaded = st.file_uploader(
                "Drop files or a folder here",
                accept_multiple_files="directory",
                key=f"uploader_{st.session_state.uploader_key}",
            )
        except Exception:
            uploaded = st.file_uploader(
                "Drop files here",
                accept_multiple_files=True,
                key=f"uploader_{st.session_state.uploader_key}",
            )

        c1, c2 = st.columns([2, 1])
        with c1:
            size_value = st.number_input("Max part size", min_value=1, value=10, step=1)
        with c2:
            unit = st.selectbox("Unit", ["MB", "KB"], index=0)

        overlap_px = st.slider("Image tile overlap (px)", 0, 200, 0, 10)

        st.divider()
        b1, b2 = st.columns([1, 1])
        with b1:
            run = st.button("Split → One ZIP", type="primary", use_container_width=True, disabled=not uploaded)
        with b2:
            if st.button("Clear environment", use_container_width=True):
                st.session_state.output_zip = None
                st.session_state.manifest = []
                st.session_state.uploader_key += 1
                do_rerun()

        st.caption("Rules: PNG/JPG → tiles, PDF → page chunks, text/code → UTF‑8 chunks, ZIP → treated as folder (not byte‑split).")

    with right:
        st.subheader("Output")
        if st.session_state.output_zip is None:
            st.info("No output yet. Upload files/folder, choose size, and click **Split → One ZIP**.")
        else:
            st.success(f"Ready: {len(st.session_state.manifest)} file(s) inside the ZIP.")
            st.download_button(
                "Download output ZIP",
                data=st.session_state.output_zip,
                file_name="chopchop_output.zip",
                mime="application/zip",
                use_container_width=True,
                key="download_all_zip",
            )
            with st.expander("Show output file list"):
                for p, sz in st.session_state.manifest:
                    st.write(f"- `{p}`  ({sz/1024:.1f} KB)")

    if not run:
        return

    target_bytes = int(size_value * 1024 * 1024) if unit == "MB" else int(size_value * 1024)
    target_bytes = max(1, target_bytes)

    zip_buf = io.BytesIO()
    manifest: List[Tuple[str, int]] = []

    # Determine common top folder if directory upload
    paths = [Path(u.name) for u in uploaded]
    top_parts = [p.parts[0] for p in paths if len(p.parts) > 1]
    common_top = top_parts[0] if top_parts and all(t == top_parts[0] for t in top_parts) else None

    with zipfile.ZipFile(zip_buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        if common_top:
            group_root = common_top
            for u in uploaded:
                data = u.getvalue()
                rel = Path(u.name).as_posix()
                rel = str(Path(rel).relative_to(common_top)).replace("\\", "/")
                process_single_file(zf, manifest, group_root, rel, data, target_bytes, overlap_px)
        else:
            for u in uploaded:
                data = u.getvalue()
                p = Path(u.name)
                group_root = p.stem
                rel = p.name
                process_single_file(zf, manifest, group_root, rel, data, target_bytes, overlap_px)

    zip_bytes = zip_buf.getvalue()

    # Validate output zip so Windows doesn't complain
    if not zipfile.is_zipfile(io.BytesIO(zip_bytes)):
        st.error("Internal error: generated ZIP is invalid. Try smaller inputs.")
        return

    st.session_state.output_zip = zip_bytes
    st.session_state.manifest = manifest
    do_rerun()


if __name__ == "__main__":
    main()
