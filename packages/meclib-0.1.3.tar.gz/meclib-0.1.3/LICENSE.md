AFL-3.0 (Academic Free License v3.0)
