"""mancp - MCP profile manager for Claude Code."""

__version__ = "0.2.0"
