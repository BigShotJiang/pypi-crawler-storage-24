.. automodule:: piquasso.fermionic
