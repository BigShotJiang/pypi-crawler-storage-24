Tutorials
=========

This document contains the basic tutorials of Piquasso.

.. grid:: 3

   .. grid-item-card::  Getting started
      :link: getting-started
      :link-type: doc

      A basic usage example of Piquasso.


   .. grid-item-card::  Boson Sampling
      :link: boson-sampling
      :link-type: doc

      Boson Sampling simulations using Piquasso.


   .. grid-item-card::  Boson Sampling as an accelerator
      :link: boson-sampling-mc-integral
      :link-type: doc

      Using Boson Sampling to accelerate Monte Carlo integration.


.. grid:: 3

   .. grid-item-card::  Gaussian Boson Sampling
      :link: gaussian-boson-sampling
      :link-type: doc

      Gaussian Boson Sampling simulations using Piquasso.


   .. grid-item-card::  Modularity in Piquasso
      :link: separating-programs
      :link-type: doc

      Compose Piquasso programs and define custom gates with ease.


   .. grid-item-card::  Quantum Neural Network layers
      :link: cvqnn-with-tensorflow
      :link-type: doc

      Using the automatic differentiation capabilities of Piquasso with TensorFlow.


.. grid:: 3


   .. grid-item-card::  Using JAX with Piquasso
      :link: jax-example
      :link-type: doc

      A simple state learning example using JAX and Piquasso.

   .. grid-item-card::  Dense k-subgraph problem
      :link: dense-subgraph-gbs
      :link-type: doc

      Solve dense k-subgraph problem with Gaussian Boson Sampling.


.. toctree::
   :maxdepth: 3
   :hidden:

   getting-started
   boson-sampling
   boson-sampling-mc-integral
   gaussian-boson-sampling
   separating-programs
   cvqnn-with-tensorflow
   jax-example
   dense-subgraph-gbs
