import json
from marco.core.preprocessor import SUPPORTED_TOKENIZE_METHODS, SUPPORTED_STOPWORD_LANGUAGES

def build_interactive_config() -> dict:
    print("Welcome to Marco Interactive Dataset Builder!")
    pipeline = []
    
    if input("1. Clean newlines? (Y/n): ").strip().lower() != 'n':
        pipeline.append({"func": "normalize_newlines", "params": {}, "depends_on": []})
        
    if input("2. Convert to lowercase? (Y/n): ").strip().lower() != 'n':
        pipeline.append({"func": "lowercase", "params": {"enabled": True}, "depends_on": []})
        
    while True:
        method = input(f"3. Tokenization method {list(SUPPORTED_TOKENIZE_METHODS)} (or press Enter to skip): ").strip()
        if method == "":
            break  # skip tokenization
        if method in SUPPORTED_TOKENIZE_METHODS:
            pipeline.append({"func": "tokenize", "params": {"method": method}, "depends_on": []})
            break
        print(f"  ❌ Unsupported method '{method}'. Choose from: {list(SUPPORTED_TOKENIZE_METHODS)}")
        
    if input("4. Remove Stopwords? (Y/n): ").strip().lower() != 'n':
        while True:
            lang = input("  Language [english]: ").strip() or "english"
            if lang in SUPPORTED_STOPWORD_LANGUAGES:
                break
            print(f"  ❌ Unsupported language '{lang}'. Supported: {list(SUPPORTED_STOPWORD_LANGUAGES)}")
        pipeline.append({"func": "remove_stopwords", "params": {"language": lang}, "depends_on": []})

    if input("5. Filter by length? (Y/n): ").strip().lower() != 'n':
        min_t = input("  Min tokens [1]: ").strip() or "1"
        max_t = input("  Max tokens [1000]: ").strip() or "1000"
        pipeline.append({"func": "filter_length", "params": {"min_tokens": int(min_t), "max_tokens": int(max_t)}, "depends_on": []})
        
    if input("6. Deduplicate? (Y/n): ").strip().lower() != 'n':
        pipeline.append({"func": "deduplicate", "params": {"method": "exact"}, "depends_on": []})

    dag = {}
    prev = None
    for i, step in enumerate(pipeline):
        step_name = f"step_{i+1}_{step['func']}"
        if prev:
            step["depends_on"] = [prev]
        dag[step_name] = step
        prev = step_name
        
    print("\nGenerated Pipeline Configuration:")
    print(json.dumps({"dag": dag}, indent=2))
    
    return {"dag": dag}
