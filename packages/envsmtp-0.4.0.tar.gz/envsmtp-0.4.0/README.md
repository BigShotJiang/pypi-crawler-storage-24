# envsmtp

[![Latest Release](https://img.shields.io/github/v/release/ofersadan85/envsmtp)](https://github.com/ofersadan85/envsmtp/releases/latest)
[![envsmtp on pypi](https://img.shields.io/pypi/v/envsmtp)](https://pypi.org/project/envsmtp/)
[![MIT License](https://img.shields.io/github/license/ofersadan85/envsmtp)](LICENSE)
[![Python package tests](https://github.com/ofersadan85/envsmtp/actions/workflows/tests.yml/badge.svg)](https://github.com/ofersadan85/envsmtp/actions/workflows/tests.yml)

Simple sending of smtp emails using environment     variables

## Install

[![envsmtp on pypi](https://img.shields.io/pypi/v/envsmtp)](https://pypi.org/project/envsmtp/)
![envsmtp](https://img.shields.io/pypi/wheel/envsmtp)

    pip install --upgrade envsmtp

## Environment Variables

By default (STARTTLS + auth mode), you must set `SMTP_USER` and `SMTP_PASS` in your environment.

To send without TLS/SSL/auth, set:

- `SMTP_USE_TLS=false`
- `SMTP_USE_SSL=false`
- `SMTP_NO_AUTH=true`
- `SMTP_FROM=sender@example.com` (required whenever `SMTP_USER` is not set, regardless of auth mode, or if you want to use a different sender than the SMTP_USER email)

Alternatively, you may set *both* SMTP_FROM_NAME and SMTP_FROM_EMAIL instead of SMTP_FROM:

- `SMTP_FROM_NAME=Tests`
- `SMTP_FROM_EMAIL=tests@example.com`

See additional optional settings in [example.env](example.env)

## Usage

This package defaults to STARTTLS on `smtp.gmail.com:587` with SMTP auth enabled.
You can change host/port with `SMTP_HOST` and `SMTP_PORT`, and transport/auth behavior with:

- `SMTP_USE_TLS` (default: `true`)
- `SMTP_USE_SSL` (default: `false`)
- `SMTP_NO_AUTH` (default: `false`)

Once installed, here's a simple example of how to use this package:

    from envsmtp import EmailMessage

    msg = EmailMessage(
        sender="sender@example.com",
        recipients="recipient@example.com",
        subject="envsmtp test",
        body="This is just a test message",
    )
    msg.smtp_send()

To send with attachments:

    from envsmtp import EmailMessage, EmailAttachment

    attachments = [
        EmailAttachment(content='/path/to/file.txt'),
        EmailAttachment(content=b'randombytes', filename='bytes_test.txt'),
        EmailAttachment(content='/path/to/another.txt', filename='this_name_is_different_.txt')
    ]
    msg = EmailMessage(
        sender="sender@example.com",
        recipients="recipient@example.com",
        subject="envsmtp test",
        body="This is just a test message",
        attachments=attachments,
    )
    msg.smtp_send()

## Requirements

![envsmtp](https://img.shields.io/pypi/pyversions/envsmtp)

Supports Python 3.10 and above (currently tested in CI on 3.10-3.13). Project dependencies are defined in [pyproject.toml](pyproject.toml).

## Testing

Install project + dev dependencies:

    uv sync --locked --group dev

Run all tests (default + integration) with coverage using a single command:

    just test

Integration tests require `SMTP_USER`, `SMTP_PASS`, and `SMTP_TEST`. If missing, integration tests are skipped.

## Contributing

For bugs / feature requests please submit [issues](https://github.com/ofersadan85/envsmtp/issues)

[![Open Issues](https://img.shields.io/github/issues-raw/ofersadan85/envsmtp)](https://github.com/ofersadan85/envsmtp/issues)
[![Closed Issues](https://img.shields.io/github/issues-closed-raw/ofersadan85/envsmtp)](https://github.com/ofersadan85/envsmtp/issues)

If you would like to contribute to this project, you are welcome
to [submit a pull request](https://github.com/ofersadan85/envsmtp/pulls)

[![Open Pull Requests](https://img.shields.io/github/issues-pr-raw/ofersadan85/envsmtp)](https://github.com/ofersadan85/envsmtp/pulls)
[![Closed Pull Requests](https://img.shields.io/github/issues-pr-closed-raw/ofersadan85/envsmtp)](https://github.com/ofersadan85/envsmtp/pulls)

## Warranty / Liability / Official support

This project is being developed independently, we provide the
package "as-is" without any implied warranty or liability, usage is your own responsibility

## Additional info

Just because I like badges

![Code Size](https://img.shields.io/github/languages/code-size/ofersadan85/envsmtp)
![Pypi downloads per month](https://img.shields.io/pypi/dm/envsmtp?label=pypi%20downloads)
![Pypi downloads per week](https://img.shields.io/pypi/dw/envsmtp?label=pypi%20downloads)
![Pypi downloads per day](https://img.shields.io/pypi/dd/envsmtp?label=pypi%20downloads)
