# TinyFish Python SDK (`tinyfish`)

Official Python SDK for TinyFish. Provides sync (`TinyFish`) and async (`AsyncTinyFish`) clients for running
automations, streaming events, and managing runs.

For full method reference and examples: see `README.md`.

---

## Package Manager

`uv` — not pip, not poetry.

## Key Entry Points

```
src/tinyfish/__init__.py    → exports TinyFish, AsyncTinyFish, and all public types
src/tinyfish/client.py      → TinyFish client class (sync)
src/tinyfish/agent/         → agent.run(), agent.queue(), agent.stream()
src/tinyfish/runs/          → runs.get(), runs.list()
src/tinyfish/_utils/        → HTTP client base (sync + async), retry, error handling
```

## Quick Usage

```python
from tinyfish import TinyFish

client = TinyFish(api_key="your-api-key")  # or set TINYFISH_API_KEY env var
response = client.agent.run(goal="...", url="https://...")
print(response.result)
```

## Tests

```bash
cd sdk/sdk-python && uv run pytest
```

## Pre-commit Hooks

```bash
cd sdk/sdk-python && pre-commit install
```

Hooks: `ruff format`, `ruff check`, `uv-lock` sync. Run before first commit and after any dep change.

## Lint / Format

```bash
cd sdk/sdk-python && uv run ruff check . && uv run ruff format .
```

## Package name

`tinyfish` (PyPI). The npm org uses a hyphen: `@tiny-fish/` (not `@tinyfish/`).

## Further Reading

See `README.md` for full usage examples, authentication patterns, and SDK changelog.
