# Releasing the Python SDK to PyPI

This document covers how to publish a new version of the TinyFish Python SDK to the public PyPI registry so users can `pip install tinyfish`.

## Prerequisites (one-time infra setup)

The `PYPI_API_TOKEN` secret exists in AWS Secrets Manager (`pypi-token`) and is already used by other repos. It needs to be added to the `ux-labs` repo via a PR to `github-control/repos.tf`:

```hcl
"ux-labs" : {
  secrets = {
    # ... existing secrets ...
    PYPI_API_TOKEN = data.aws_secretsmanager_secret_version.pypi-token.secret_string
  }
}
```

This is a one-time change. Once merged and applied, the workflow will have access to the token.

## Release process

### Step 1: Bump the version

Edit `sdk/sdk-python/pyproject.toml` and update the `version` field:

```toml
[project]
version = "0.2.0"  # bump this
```

Commit and merge to main.

### Step 2: Create a GitHub Release

1. Go to the `ux-labs` repo on GitHub → **Releases** → **Draft a new release**
2. Set the tag to match the version exactly, prefixed with `v`:
   - Version `0.2.0` → tag `v0.2.0`
3. Set the target to `main`
4. Write release notes summarizing what changed
5. Click **Publish release**

The workflow validates that the tag matches the version in `pyproject.toml` — if they don't match, the build fails before anything is published.

### Step 3: Monitor the workflow

The `SDK Python CD - Publish to PyPI` workflow triggers automatically on release publish. It runs two jobs in sequence:

1. **Build** — validates the tag matches `pyproject.toml` version, builds the package with `uv build`
2. **Publish to PyPI** — publishes to `pypi.org` using the `PYPI_API_TOKEN` secret

Monitor progress at: `github.com/tinyfish-io/ux-labs/actions`

### Step 4: Verify

After the workflow completes, verify the release:

```bash
pip install tinyfish==0.2.0
python -c "from tinyfish import Tinyfish; print('ok')"
```

## Troubleshooting

**Tag does not match pyproject.toml version**
The build job validates that the git tag (e.g., `v0.2.0`) matches the version in `pyproject.toml` (e.g., `0.2.0`). Fix by updating `pyproject.toml` to match the tag before publishing, then delete and recreate the release.

**403 / authentication error**
Verify that `PYPI_API_TOKEN` has been added to the `ux-labs` repo secrets in `github-control`. The token must exist as a GitHub Actions secret before the workflow can publish.

**Package already exists on PyPI**
PyPI does not allow re-uploading the same version. Bump the version in `pyproject.toml` and create a new release.
