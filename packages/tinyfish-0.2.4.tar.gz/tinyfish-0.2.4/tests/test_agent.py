"""Tests for agent resource — run(), queue(), and stream()."""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest
from respx import MockRouter

from tests.conftest import API_KEY, BASE_URL
from tinyfish import (
    AsyncTinyFish,
    AuthenticationError,
    BrowserProfile,
    InternalServerError,
    ProxyConfig,
    ProxyCountryCode,
    RateLimitError,
    TinyFish,
)
from tinyfish.agent.types import (
    AgentRunAsyncResponse,
    AgentRunResponse,
    CompleteEvent,
    HeartbeatEvent,
    ProgressEvent,
    StartedEvent,
    StreamingUrlEvent,
)

# ─── Paths ────────────────────────────────────────────────────────────────────

_RUN_PATH = "/v1/automation/run"
_QUEUE_PATH = "/v1/automation/run-async"
_SSE_PATH = "/v1/automation/run-sse"

# ─── Shared fixtures ──────────────────────────────────────────────────────────

_TS = "2024-01-01T00:00:00Z"
_RUN_ID = "run-test-123"
_BODY: dict[str, Any] = {"goal": "Find the price of iPhone 15", "url": "https://example.com"}

_EV_STARTED: dict[str, Any] = {"type": "STARTED", "runId": _RUN_ID, "timestamp": _TS}
_EV_STREAMING_URL: dict[str, Any] = {
    "type": "STREAMING_URL",
    "runId": _RUN_ID,
    "streamingUrl": "wss://stream.example.com/abc",
    "timestamp": _TS,
}
_EV_PROGRESS: dict[str, Any] = {"type": "PROGRESS", "runId": _RUN_ID, "purpose": "Clicking button", "timestamp": _TS}
_EV_HEARTBEAT: dict[str, Any] = {"type": "HEARTBEAT", "timestamp": _TS}
_EV_COMPLETE_OK: dict[str, Any] = {
    "type": "COMPLETE",
    "runId": _RUN_ID,
    "status": "COMPLETED",
    "timestamp": _TS,
    "resultJson": {"price": "$999"},
    "error": None,
}
_EV_COMPLETE_FAIL: dict[str, Any] = {
    "type": "COMPLETE",
    "runId": _RUN_ID,
    "status": "FAILED",
    "timestamp": _TS,
    "resultJson": None,
    "error": {"message": "something went wrong", "category": "AGENT_FAILURE"},
}
_EV_COMPLETE_CANCELLED: dict[str, Any] = {
    "type": "COMPLETE",
    "runId": _RUN_ID,
    "status": "CANCELLED",
    "timestamp": _TS,
    "resultJson": None,
    "error": None,
}

_RUN_OK: dict[str, Any] = {
    "status": "COMPLETED",
    "run_id": _RUN_ID,
    "result": {"price": "$999"},
    "error": None,
    "num_of_steps": 5,
    "started_at": _TS,
    "finished_at": "2024-01-01T00:01:00Z",
}
_RUN_FAIL: dict[str, Any] = {
    "status": "FAILED",
    "run_id": _RUN_ID,
    "result": None,
    "error": {"message": "something went wrong", "category": "SYSTEM_FAILURE"},
    "num_of_steps": 3,
    "started_at": _TS,
    "finished_at": "2024-01-01T00:00:30Z",
}
_QUEUE_OK: dict[str, Any] = {"run_id": _RUN_ID, "error": None}


def _sse_bytes(*events: dict[str, Any]) -> bytes:
    return b"".join(f"data: {json.dumps(e)}\n\n".encode() for e in events)


# ═══════════════════════════════════════════════════════════════════════════════
# agent.run() — sync
# ═══════════════════════════════════════════════════════════════════════════════


# Sync run() returns AgentRunResponse with minimal params
@pytest.mark.respx(base_url=BASE_URL)
def test_run_minimal(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    result = client.agent.run(**_BODY)
    assert isinstance(result, AgentRunResponse)


# Sync run() returns COMPLETED status with run_id, result, and no error
@pytest.mark.respx(base_url=BASE_URL)
def test_run_completed_status(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    result = client.agent.run(**_BODY)
    assert result.status == "COMPLETED"
    assert result.run_id == _RUN_ID
    assert result.result == {"price": "$999"}
    assert result.error is None


# Sync run() returns FAILED status with error message
@pytest.mark.respx(base_url=BASE_URL)
def test_run_failed_status(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_FAIL))
    result = client.agent.run(**_BODY)
    assert result.status == "FAILED"
    assert result.result is None
    assert result.error is not None
    assert result.error.message == "something went wrong"


# Sync run() sends browser_profile=lite in request body
@pytest.mark.respx(base_url=BASE_URL)
def test_run_browser_profile_lite(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(**_BODY, browser_profile=BrowserProfile.LITE)
    assert json.loads(route.calls[0].request.content)["browser_profile"] == "lite"


# Sync run() sends browser_profile=stealth in request body
@pytest.mark.respx(base_url=BASE_URL)
def test_run_browser_profile_stealth(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(**_BODY, browser_profile=BrowserProfile.STEALTH)
    assert json.loads(route.calls[0].request.content)["browser_profile"] == "stealth"


# Sync run() omits browser_profile from body when not provided
@pytest.mark.respx(base_url=BASE_URL)
def test_run_browser_profile_not_sent_when_omitted(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(**_BODY)
    assert "browser_profile" not in json.loads(route.calls[0].request.content)


# Sync run() sends proxy_config with enabled=True and no country_code
@pytest.mark.respx(base_url=BASE_URL)
def test_run_proxy_enabled_no_country(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(**_BODY, proxy_config=ProxyConfig(enabled=True))
    body = json.loads(route.calls[0].request.content)
    assert body["proxy_config"]["enabled"] is True
    assert "country_code" not in body["proxy_config"]


# Sync run() sends proxy_config with enabled=False
@pytest.mark.respx(base_url=BASE_URL)
def test_run_proxy_disabled(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(**_BODY, proxy_config=ProxyConfig(enabled=False))
    body = json.loads(route.calls[0].request.content)
    assert body["proxy_config"]["enabled"] is False


# Sync run() sends correct country_code for each ProxyCountryCode value
@pytest.mark.parametrize("country", list(ProxyCountryCode))
@pytest.mark.respx(base_url=BASE_URL)
def test_run_proxy_with_country(country: ProxyCountryCode, client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(**_BODY, proxy_config=ProxyConfig(enabled=True, country_code=country))
    body = json.loads(route.calls[0].request.content)
    assert body["proxy_config"]["country_code"] == country.value


# Sync run() sends all params (goal, url, browser_profile, proxy_config) in body
@pytest.mark.respx(base_url=BASE_URL)
def test_run_all_params(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(
        **_BODY,
        browser_profile=BrowserProfile.STEALTH,
        proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.GB),
    )
    body = json.loads(route.calls[0].request.content)
    assert body["goal"] == _BODY["goal"]
    assert body["url"] == _BODY["url"]
    assert body["browser_profile"] == "stealth"
    assert body["proxy_config"]["enabled"] is True
    assert body["proxy_config"]["country_code"] == "GB"


# Sync run() parses started_at and finished_at as datetime objects
@pytest.mark.respx(base_url=BASE_URL)
def test_run_datetime_fields_parsed(client: TinyFish, respx_mock: MockRouter):
    from datetime import datetime

    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    result = client.agent.run(**_BODY)
    assert isinstance(result.started_at, datetime)
    assert isinstance(result.finished_at, datetime)


# Sync run() handles null optional fields (run_id, started_at, finished_at)
@pytest.mark.respx(base_url=BASE_URL)
def test_run_null_optional_fields(client: TinyFish, respx_mock: MockRouter):
    data = {**_RUN_OK, "run_id": None, "started_at": None, "finished_at": None}
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=data))
    result = client.agent.run(**_BODY)
    assert result.run_id is None
    assert result.started_at is None
    assert result.finished_at is None


# Sync run() populates error.category on failed response
@pytest.mark.respx(base_url=BASE_URL)
def test_run_error_has_category(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_FAIL))
    result = client.agent.run(**_BODY)
    assert result.error is not None
    assert result.error.category == "SYSTEM_FAILURE"


# Sync run() correctly maps each error category string
@pytest.mark.parametrize("category", ["SYSTEM_FAILURE", "AGENT_FAILURE", "UNKNOWN"])
@pytest.mark.respx(base_url=BASE_URL)
def test_run_error_category_values(category: str, client: TinyFish, respx_mock: MockRouter):
    data = {**_RUN_FAIL, "error": {"message": "err", "category": category}}
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=data))
    result = client.agent.run(**_BODY)
    assert result.error is not None
    assert result.error.category == category


# Sync run() raises AuthenticationError on 401 response
@pytest.mark.respx(base_url=BASE_URL)
def test_run_401(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}))
    with pytest.raises(AuthenticationError):
        client.agent.run(**_BODY)


# Sync run() raises InternalServerError on 500 response
@pytest.mark.respx(base_url=BASE_URL)
def test_run_500(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(500, json={"error": {"message": "server error"}}))
    with pytest.raises(InternalServerError):
        client.agent.run(**_BODY)


# ═══════════════════════════════════════════════════════════════════════════════
# agent.run() — async
# ═══════════════════════════════════════════════════════════════════════════════


# Async run() returns AgentRunResponse with minimal params
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_run_minimal(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    async with async_client as c:
        result = await c.agent.run(**_BODY)
    assert isinstance(result, AgentRunResponse)


# Async run() returns COMPLETED status with correct run_id
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_run_completed_status(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    async with async_client as c:
        result = await c.agent.run(**_BODY)
    assert result.status == "COMPLETED"
    assert result.run_id == _RUN_ID


# Async run() returns FAILED status with error populated
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_run_failed_status(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_FAIL))
    async with async_client as c:
        result = await c.agent.run(**_BODY)
    assert result.status == "FAILED"
    assert result.error is not None


# Async run() sends browser_profile=stealth in request body
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_run_browser_profile_stealth(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    async with async_client as c:
        await c.agent.run(**_BODY, browser_profile=BrowserProfile.STEALTH)
    assert json.loads(route.calls[0].request.content)["browser_profile"] == "stealth"


# Async run() sends proxy_config with country_code in request body
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_run_proxy_config(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    async with async_client as c:
        await c.agent.run(**_BODY, proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.DE))
    body = json.loads(route.calls[0].request.content)
    assert body["proxy_config"]["country_code"] == "DE"


# Async run() populates error.category on failed response
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_run_error_has_category(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_FAIL))
    async with async_client as c:
        result = await c.agent.run(**_BODY)
    assert result.error is not None
    assert result.error.category == "SYSTEM_FAILURE"


# Async run() correctly maps each error category string
@pytest.mark.parametrize("category", ["SYSTEM_FAILURE", "AGENT_FAILURE", "UNKNOWN"])
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_run_error_category_values(category: str, async_client: AsyncTinyFish, respx_mock: MockRouter):
    data = {**_RUN_FAIL, "error": {"message": "err", "category": category}}
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=data))
    async with async_client as c:
        result = await c.agent.run(**_BODY)
    assert result.error is not None
    assert result.error.category == category


# Async run() sends all params (browser_profile, proxy_config) in body
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_run_all_params(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    async with async_client as c:
        await c.agent.run(
            **_BODY,
            browser_profile=BrowserProfile.STEALTH,
            proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.JP),
        )
    body = json.loads(route.calls[0].request.content)
    assert body["browser_profile"] == "stealth"
    assert body["proxy_config"]["country_code"] == "JP"


# Async run() raises AuthenticationError on 401 response
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_run_401(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}))
    async with async_client as c:
        with pytest.raises(AuthenticationError):
            await c.agent.run(**_BODY)


# Async run() raises InternalServerError on 500 response
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_run_500(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(500, json={"error": {"message": "server error"}}))
    async with async_client as c:
        with pytest.raises(InternalServerError):
            await c.agent.run(**_BODY)


# ═══════════════════════════════════════════════════════════════════════════════
# agent.queue() — sync
# ═══════════════════════════════════════════════════════════════════════════════


# Sync queue() returns AgentRunAsyncResponse with run_id
@pytest.mark.respx(base_url=BASE_URL)
def test_queue_minimal(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_QUEUE_PATH).mock(return_value=httpx.Response(200, json=_QUEUE_OK))
    result = client.agent.queue(**_BODY)
    assert isinstance(result, AgentRunAsyncResponse)
    assert result.run_id == _RUN_ID


# Sync queue() sends browser_profile=stealth in request body
@pytest.mark.respx(base_url=BASE_URL)
def test_queue_browser_profile_stealth(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_QUEUE_PATH).mock(return_value=httpx.Response(200, json=_QUEUE_OK))
    client.agent.queue(**_BODY, browser_profile=BrowserProfile.STEALTH)
    assert json.loads(route.calls[0].request.content)["browser_profile"] == "stealth"


# Sync queue() sends proxy_config with country_code in request body
@pytest.mark.respx(base_url=BASE_URL)
def test_queue_proxy_with_country(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_QUEUE_PATH).mock(return_value=httpx.Response(200, json=_QUEUE_OK))
    client.agent.queue(**_BODY, proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.GB))
    body = json.loads(route.calls[0].request.content)
    assert body["proxy_config"]["country_code"] == "GB"


# Sync queue() sends all params (browser_profile, proxy_config) in body
@pytest.mark.respx(base_url=BASE_URL)
def test_queue_all_params(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_QUEUE_PATH).mock(return_value=httpx.Response(200, json=_QUEUE_OK))
    client.agent.queue(
        **_BODY,
        browser_profile=BrowserProfile.STEALTH,
        proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.AU),
    )
    body = json.loads(route.calls[0].request.content)
    assert body["browser_profile"] == "stealth"
    assert body["proxy_config"]["country_code"] == "AU"


# Sync queue() handles error response with null run_id and error details
@pytest.mark.respx(base_url=BASE_URL)
def test_queue_error_response(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_QUEUE_PATH).mock(
        return_value=httpx.Response(
            200, json={"run_id": None, "error": {"message": "queue full", "category": "SYSTEM_FAILURE"}}
        )
    )
    result = client.agent.queue(**_BODY)
    assert result.run_id is None
    assert result.error is not None
    assert result.error.message == "queue full"
    assert result.error.category == "SYSTEM_FAILURE"


# Sync queue() raises AuthenticationError on 401 response
@pytest.mark.respx(base_url=BASE_URL)
def test_queue_401(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_QUEUE_PATH).mock(return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}))
    with pytest.raises(AuthenticationError):
        client.agent.queue(**_BODY)


# ═══════════════════════════════════════════════════════════════════════════════
# agent.queue() — async
# ═══════════════════════════════════════════════════════════════════════════════


# Async queue() returns AgentRunAsyncResponse with run_id
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_queue_minimal(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_QUEUE_PATH).mock(return_value=httpx.Response(200, json=_QUEUE_OK))
    async with async_client as c:
        result = await c.agent.queue(**_BODY)
    assert isinstance(result, AgentRunAsyncResponse)
    assert result.run_id == _RUN_ID


# Async queue() sends browser_profile=stealth in request body
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_queue_browser_profile_stealth(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_QUEUE_PATH).mock(return_value=httpx.Response(200, json=_QUEUE_OK))
    async with async_client as c:
        await c.agent.queue(**_BODY, browser_profile=BrowserProfile.STEALTH)
    assert json.loads(route.calls[0].request.content)["browser_profile"] == "stealth"


# Async queue() sends all params (browser_profile, proxy_config) in body
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_queue_all_params(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_QUEUE_PATH).mock(return_value=httpx.Response(200, json=_QUEUE_OK))
    async with async_client as c:
        await c.agent.queue(
            **_BODY,
            browser_profile=BrowserProfile.STEALTH,
            proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.FR),
        )
    body = json.loads(route.calls[0].request.content)
    assert body["browser_profile"] == "stealth"
    assert body["proxy_config"]["country_code"] == "FR"


# Async queue() handles error response with null run_id and error details
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_queue_error_response(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_QUEUE_PATH).mock(
        return_value=httpx.Response(
            200, json={"run_id": None, "error": {"message": "queue full", "category": "SYSTEM_FAILURE"}}
        )
    )
    async with async_client as c:
        result = await c.agent.queue(**_BODY)
    assert result.run_id is None
    assert result.error is not None


# Async queue() raises AuthenticationError on 401 response
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_queue_401(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_QUEUE_PATH).mock(return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}))
    async with async_client as c:
        with pytest.raises(AuthenticationError):
            await c.agent.queue(**_BODY)


# ═══════════════════════════════════════════════════════════════════════════════
# agent.stream() — sync
# ═══════════════════════════════════════════════════════════════════════════════


# Sync stream() yields StartedEvent with run_id as first event
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_started_event(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_STARTED, _EV_COMPLETE_OK)))
    with client.agent.stream(**_BODY) as s:
        events = list(s)
    assert isinstance(events[0], StartedEvent)
    assert events[0].run_id == _RUN_ID


# Sync stream() yields StreamingUrlEvent with websocket URL
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_streaming_url_event(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_STARTED, _EV_STREAMING_URL, _EV_COMPLETE_OK))
    )
    with client.agent.stream(**_BODY) as s:
        events = list(s)
    assert isinstance(events[1], StreamingUrlEvent)
    assert events[1].streaming_url == "wss://stream.example.com/abc"


# Sync stream() yields ProgressEvent with purpose text
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_progress_event(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_STARTED, _EV_PROGRESS, _EV_COMPLETE_OK))
    )
    with client.agent.stream(**_BODY) as s:
        events = list(s)
    assert isinstance(events[1], ProgressEvent)
    assert events[1].purpose == "Clicking button"


# Sync stream() yields HeartbeatEvent
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_heartbeat_event(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_HEARTBEAT, _EV_COMPLETE_OK))
    )
    with client.agent.stream(**_BODY) as s:
        events = list(s)
    assert isinstance(events[0], HeartbeatEvent)


# Sync stream() yields CompleteEvent with COMPLETED status and result
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_complete_ok(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    with client.agent.stream(**_BODY) as s:
        ev = list(s)[0]
    assert isinstance(ev, CompleteEvent)
    assert ev.status == "COMPLETED"
    assert ev.result_json == {"price": "$999"}


# Sync stream() yields CompleteEvent with FAILED status and error details
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_complete_failed(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_FAIL)))
    with client.agent.stream(**_BODY) as s:
        ev = list(s)[0]
    assert isinstance(ev, CompleteEvent)
    assert ev.status == "FAILED"
    assert ev.error is not None
    assert ev.error.message == "something went wrong"
    assert ev.error.category == "AGENT_FAILURE"


# Sync stream() yields CompleteEvent with CANCELLED status
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_complete_cancelled(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_CANCELLED)))
    with client.agent.stream(**_BODY) as s:
        ev = list(s)[0]
    assert ev.status == "CANCELLED"


# Sync stream() yields all 5 event types in correct order
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_full_sequence(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(
            200,
            content=_sse_bytes(_EV_STARTED, _EV_STREAMING_URL, _EV_PROGRESS, _EV_HEARTBEAT, _EV_COMPLETE_OK),
        )
    )
    with client.agent.stream(**_BODY) as s:
        events = list(s)
    assert len(events) == 5
    assert isinstance(events[0], StartedEvent)
    assert isinstance(events[1], StreamingUrlEvent)
    assert isinstance(events[2], ProgressEvent)
    assert isinstance(events[3], HeartbeatEvent)
    assert isinstance(events[4], CompleteEvent)


# Sync stream() silently skips unrecognized event types
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_unknown_event_skipped(client: TinyFish, respx_mock: MockRouter):
    unknown: dict[str, Any] = {"type": "UNKNOWN", "data": "ignored"}
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(unknown, _EV_COMPLETE_OK)))
    with client.agent.stream(**_BODY) as s:
        events = list(s)
    assert len(events) == 1
    assert isinstance(events[0], CompleteEvent)


# Sync stream() sends browser_profile=stealth in request body
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_browser_profile_stealth_in_body(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    with client.agent.stream(**_BODY, browser_profile=BrowserProfile.STEALTH) as s:
        list(s)
    body = json.loads(route.calls[0].request.content)
    assert body["browser_profile"] == "stealth"


# Sync stream() sends proxy_config with country_code in request body
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_proxy_config_in_body(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    with client.agent.stream(**_BODY, proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.US)) as s:
        list(s)
    body = json.loads(route.calls[0].request.content)
    assert body["proxy_config"]["enabled"] is True
    assert body["proxy_config"]["country_code"] == "US"


# Sync stream() sends all params (goal, url, browser_profile, proxy_config) in body
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_all_params_in_body(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    with client.agent.stream(
        **_BODY,
        browser_profile=BrowserProfile.STEALTH,
        proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.CA),
    ) as s:
        list(s)
    body = json.loads(route.calls[0].request.content)
    assert body["goal"] == _BODY["goal"]
    assert body["url"] == _BODY["url"]
    assert body["browser_profile"] == "stealth"
    assert body["proxy_config"]["enabled"] is True
    assert body["proxy_config"]["country_code"] == "CA"


# Sync stream() on_started callback fires with StartedEvent
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_on_started_callback(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_STARTED, _EV_COMPLETE_OK)))
    received: list[StartedEvent] = []
    with client.agent.stream(**_BODY, on_started=received.append) as s:
        list(s)
    assert len(received) == 1
    assert isinstance(received[0], StartedEvent)


# Sync stream() on_streaming_url callback fires with streaming URL
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_on_streaming_url_callback(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_STREAMING_URL, _EV_COMPLETE_OK))
    )
    received: list[StreamingUrlEvent] = []
    with client.agent.stream(**_BODY, on_streaming_url=received.append) as s:
        list(s)
    assert len(received) == 1
    assert received[0].streaming_url == "wss://stream.example.com/abc"


# Sync stream() on_progress callback fires for each PROGRESS event
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_on_progress_callback(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_PROGRESS, _EV_PROGRESS, _EV_COMPLETE_OK))
    )
    received: list[ProgressEvent] = []
    with client.agent.stream(**_BODY, on_progress=received.append) as s:
        list(s)
    assert len(received) == 2


# Sync stream() on_heartbeat callback fires for HEARTBEAT event
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_on_heartbeat_callback(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_HEARTBEAT, _EV_COMPLETE_OK))
    )
    received: list[HeartbeatEvent] = []
    with client.agent.stream(**_BODY, on_heartbeat=received.append) as s:
        list(s)
    assert len(received) == 1


# Sync stream() on_complete callback fires with CompleteEvent
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_on_complete_callback(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    received: list[CompleteEvent] = []
    with client.agent.stream(**_BODY, on_complete=received.append) as s:
        list(s)
    assert len(received) == 1
    assert isinstance(received[0], CompleteEvent)


# Sync stream() fires all callbacks in correct event order
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_all_callbacks_in_sequence(client: TinyFish, respx_mock: MockRouter):
    call_log: list[str] = []
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(
            200,
            content=_sse_bytes(_EV_STARTED, _EV_STREAMING_URL, _EV_PROGRESS, _EV_HEARTBEAT, _EV_COMPLETE_OK),
        )
    )
    with client.agent.stream(
        **_BODY,
        on_started=lambda e: call_log.append("started"),
        on_streaming_url=lambda e: call_log.append("streaming_url"),
        on_progress=lambda e: call_log.append("progress"),
        on_heartbeat=lambda e: call_log.append("heartbeat"),
        on_complete=lambda e: call_log.append("complete"),
    ) as s:
        list(s)
    assert call_log == ["started", "streaming_url", "progress", "heartbeat", "complete"]


# Sync stream() still yields events even when callbacks are registered
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_callbacks_dont_suppress_yield(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_STARTED, _EV_COMPLETE_OK)))
    with client.agent.stream(**_BODY, on_started=lambda e: None) as s:
        events = list(s)
    assert len(events) == 2


# Sync stream() sends goal and url in request body
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_request_body(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    with client.agent.stream(goal="find price", url="https://example.com") as s:
        list(s)
    body = json.loads(route.calls[0].request.content)
    assert body["goal"] == "find price"
    assert body["url"] == "https://example.com"


# Sync stream() includes x-api-key auth header in request
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_auth_header(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    with client.agent.stream(**_BODY) as s:
        list(s)
    assert route.calls[0].request.headers["x-api-key"] == API_KEY


# Sync stream() raises AuthenticationError on 401 response
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_401(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}))
    with pytest.raises(AuthenticationError):
        with client.agent.stream(**_BODY) as s:
            list(s)


# Sync stream() raises InternalServerError on 500 response
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_500(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(500, json={"error": {"message": "server error"}}))
    with pytest.raises(InternalServerError):
        with client.agent.stream(**_BODY) as s:
            list(s)


# ═══════════════════════════════════════════════════════════════════════════════
# agent.stream() — async
# ═══════════════════════════════════════════════════════════════════════════════


# Async stream() yields StartedEvent with run_id as first event
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_started_event(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_STARTED, _EV_COMPLETE_OK)))
    async with async_client as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    assert isinstance(events[0], StartedEvent)
    assert events[0].run_id == _RUN_ID


# Async stream() yields StreamingUrlEvent with websocket URL
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_streaming_url_event(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_STARTED, _EV_STREAMING_URL, _EV_COMPLETE_OK))
    )
    async with async_client as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    assert isinstance(events[1], StreamingUrlEvent)
    assert events[1].streaming_url == "wss://stream.example.com/abc"


# Async stream() yields ProgressEvent with purpose text
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_progress_event(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_STARTED, _EV_PROGRESS, _EV_COMPLETE_OK))
    )
    async with async_client as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    assert isinstance(events[1], ProgressEvent)
    assert events[1].purpose == "Clicking button"


# Async stream() yields HeartbeatEvent
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_heartbeat_event(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_HEARTBEAT, _EV_COMPLETE_OK))
    )
    async with async_client as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    assert isinstance(events[0], HeartbeatEvent)


# Async stream() yields CompleteEvent with COMPLETED status and result
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_complete_ok(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    async with async_client as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    ev = events[0]
    assert isinstance(ev, CompleteEvent)
    assert ev.status == "COMPLETED"
    assert ev.result_json == {"price": "$999"}


# Async stream() yields CompleteEvent with FAILED status and error details
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_complete_failed(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_FAIL)))
    async with async_client as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    ev = events[0]
    assert ev.status == "FAILED"
    assert ev.error is not None
    assert ev.error.category == "AGENT_FAILURE"


# Async stream() yields CompleteEvent with CANCELLED status
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_complete_cancelled(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_CANCELLED)))
    async with async_client as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    assert events[0].status == "CANCELLED"


# Async stream() yields all 5 event types in correct order
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_full_sequence(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(
            200,
            content=_sse_bytes(_EV_STARTED, _EV_STREAMING_URL, _EV_PROGRESS, _EV_HEARTBEAT, _EV_COMPLETE_OK),
        )
    )
    async with async_client as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    assert len(events) == 5
    assert isinstance(events[0], StartedEvent)
    assert isinstance(events[1], StreamingUrlEvent)
    assert isinstance(events[2], ProgressEvent)
    assert isinstance(events[3], HeartbeatEvent)
    assert isinstance(events[4], CompleteEvent)


# Async stream() silently skips unrecognized event types
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_unknown_event_skipped(async_client: AsyncTinyFish, respx_mock: MockRouter):
    unknown: dict[str, Any] = {"type": "UNKNOWN", "data": "ignored"}
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(unknown, _EV_COMPLETE_OK)))
    async with async_client as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    assert len(events) == 1
    assert isinstance(events[0], CompleteEvent)


# Async stream() sends browser_profile=stealth in request body
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_browser_profile_stealth_in_body(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    async with async_client as c:
        async with c.agent.stream(**_BODY, browser_profile=BrowserProfile.STEALTH) as s:
            async for _ in s:
                pass
    body = json.loads(route.calls[0].request.content)
    assert body["browser_profile"] == "stealth"


# Async stream() sends proxy_config with country_code in request body
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_proxy_config_in_body(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    async with async_client as c:
        async with c.agent.stream(
            **_BODY, proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.US)
        ) as s:
            async for _ in s:
                pass
    body = json.loads(route.calls[0].request.content)
    assert body["proxy_config"]["enabled"] is True
    assert body["proxy_config"]["country_code"] == "US"


# Async stream() sends all params (browser_profile, proxy_config) in body
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_all_params_in_body(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    async with async_client as c:
        async with c.agent.stream(
            **_BODY,
            browser_profile=BrowserProfile.STEALTH,
            proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.CA),
        ) as s:
            async for _ in s:
                pass
    body = json.loads(route.calls[0].request.content)
    assert body["browser_profile"] == "stealth"
    assert body["proxy_config"]["country_code"] == "CA"


# Async stream() on_started callback fires with StartedEvent
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_on_started_callback(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_STARTED, _EV_COMPLETE_OK)))
    received: list[StartedEvent] = []
    async with async_client as c:
        async with c.agent.stream(**_BODY, on_started=received.append) as s:
            async for _ in s:
                pass
    assert len(received) == 1


# Async stream() on_streaming_url callback fires with streaming URL
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_on_streaming_url_callback(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_STREAMING_URL, _EV_COMPLETE_OK))
    )
    received: list[StreamingUrlEvent] = []
    async with async_client as c:
        async with c.agent.stream(**_BODY, on_streaming_url=received.append) as s:
            async for _ in s:
                pass
    assert len(received) == 1
    assert received[0].streaming_url == "wss://stream.example.com/abc"


# Async stream() on_progress callback fires for each PROGRESS event
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_on_progress_callback(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_PROGRESS, _EV_PROGRESS, _EV_COMPLETE_OK))
    )
    received: list[ProgressEvent] = []
    async with async_client as c:
        async with c.agent.stream(**_BODY, on_progress=received.append) as s:
            async for _ in s:
                pass
    assert len(received) == 2


# Async stream() on_heartbeat callback fires for HEARTBEAT event
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_on_heartbeat_callback(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(200, content=_sse_bytes(_EV_HEARTBEAT, _EV_COMPLETE_OK))
    )
    received: list[HeartbeatEvent] = []
    async with async_client as c:
        async with c.agent.stream(**_BODY, on_heartbeat=received.append) as s:
            async for _ in s:
                pass
    assert len(received) == 1


# Async stream() on_complete callback fires with CompleteEvent
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_on_complete_callback(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    received: list[CompleteEvent] = []
    async with async_client as c:
        async with c.agent.stream(**_BODY, on_complete=received.append) as s:
            async for _ in s:
                pass
    assert len(received) == 1


# Async stream() fires all callbacks in correct event order
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_all_callbacks_in_sequence(async_client: AsyncTinyFish, respx_mock: MockRouter):
    call_log: list[str] = []
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(
            200,
            content=_sse_bytes(_EV_STARTED, _EV_STREAMING_URL, _EV_PROGRESS, _EV_HEARTBEAT, _EV_COMPLETE_OK),
        )
    )
    async with async_client as c:
        async with c.agent.stream(
            **_BODY,
            on_started=lambda e: call_log.append("started"),
            on_streaming_url=lambda e: call_log.append("streaming_url"),
            on_progress=lambda e: call_log.append("progress"),
            on_heartbeat=lambda e: call_log.append("heartbeat"),
            on_complete=lambda e: call_log.append("complete"),
        ) as s:
            async for _ in s:
                pass
    assert call_log == ["started", "streaming_url", "progress", "heartbeat", "complete"]


# Async stream() still yields events even when callbacks are registered
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_callbacks_dont_suppress_yield(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_STARTED, _EV_COMPLETE_OK)))
    async with async_client as c:
        async with c.agent.stream(**_BODY, on_started=lambda e: None) as s:
            events = [e async for e in s]
    assert len(events) == 2


# Async stream() sends goal and url in request body
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_request_body(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    async with async_client as c:
        async with c.agent.stream(goal="find price", url="https://example.com") as s:
            async for _ in s:
                pass
    body = json.loads(route.calls[0].request.content)
    assert body["goal"] == "find price"
    assert body["url"] == "https://example.com"


# Async stream() includes x-api-key auth header in request
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_auth_header(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)))
    async with async_client as c:
        async with c.agent.stream(**_BODY) as s:
            async for _ in s:
                pass
    assert route.calls[0].request.headers["x-api-key"] == API_KEY


# Async stream() raises AuthenticationError on 401 response
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_401(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}))
    async with async_client as c:
        with pytest.raises(AuthenticationError):
            async with c.agent.stream(**_BODY) as s:
                async for _ in s:
                    pass


# Async stream() raises InternalServerError on 500 response
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_500(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(return_value=httpx.Response(500, json={"error": {"message": "server error"}}))
    async with async_client as c:
        with pytest.raises(InternalServerError):
            async with c.agent.stream(**_BODY) as s:
                async for _ in s:
                    pass


# ═══════════════════════════════════════════════════════════════════════════════
# agent.stream() — sync retry
# ═══════════════════════════════════════════════════════════════════════════════


# Sync stream() retries on 429 and succeeds on the next attempt
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_retries_on_429(respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH)
    route.side_effect = [
        httpx.Response(429, json={"error": {"message": "rate limited"}}),
        httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)),
    ]
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2)
    with c.agent.stream(**_BODY) as s:
        events = list(s)
    assert len(events) == 1
    assert isinstance(events[0], CompleteEvent)
    assert route.call_count == 2


# Sync stream() retries on 500 and succeeds on the next attempt
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_retries_on_500(respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH)
    route.side_effect = [
        httpx.Response(500, json={"error": {"message": "server error"}}),
        httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)),
    ]
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2)
    with c.agent.stream(**_BODY) as s:
        events = list(s)
    assert len(events) == 1
    assert isinstance(events[0], CompleteEvent)
    assert route.call_count == 2


# Sync stream() raises RateLimitError after all retries are exhausted
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_raises_after_retries_exhausted(respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(429, json={"error": {"message": "rate limited"}}),
    )
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2)
    with pytest.raises(RateLimitError):
        with c.agent.stream(**_BODY) as s:
            list(s)


# Sync stream() does not retry non-retryable 401 errors
@pytest.mark.respx(base_url=BASE_URL)
def test_stream_does_not_retry_on_401(respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}),
    )
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2)
    with pytest.raises(AuthenticationError):
        with c.agent.stream(**_BODY) as s:
            list(s)
    assert route.call_count == 1


# ═══════════════════════════════════════════════════════════════════════════════
# agent.stream() — async retry
# ═══════════════════════════════════════════════════════════════════════════════


# Async stream() retries on 429 and succeeds on the next attempt
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_retries_on_429(respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH)
    route.side_effect = [
        httpx.Response(429, json={"error": {"message": "rate limited"}}),
        httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)),
    ]
    async with AsyncTinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2) as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    assert len(events) == 1
    assert isinstance(events[0], CompleteEvent)
    assert route.call_count == 2


# Async stream() retries on 500 and succeeds on the next attempt
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_retries_on_500(respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH)
    route.side_effect = [
        httpx.Response(500, json={"error": {"message": "server error"}}),
        httpx.Response(200, content=_sse_bytes(_EV_COMPLETE_OK)),
    ]
    async with AsyncTinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2) as c:
        async with c.agent.stream(**_BODY) as s:
            events = [e async for e in s]
    assert len(events) == 1
    assert isinstance(events[0], CompleteEvent)
    assert route.call_count == 2


# Async stream() raises RateLimitError after all retries are exhausted
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_raises_after_retries_exhausted(respx_mock: MockRouter):
    respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(429, json={"error": {"message": "rate limited"}}),
    )
    async with AsyncTinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2) as c:
        with pytest.raises(RateLimitError):
            async with c.agent.stream(**_BODY) as s:
                async for _ in s:
                    pass


# Async stream() does not retry non-retryable 401 errors
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_stream_does_not_retry_on_401(respx_mock: MockRouter):
    route = respx_mock.post(_SSE_PATH).mock(
        return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}),
    )
    async with AsyncTinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2) as c:
        with pytest.raises(AuthenticationError):
            async with c.agent.stream(**_BODY) as s:
                async for _ in s:
                    pass
    assert route.call_count == 1
