"""Client construction, headers, context manager, and repr tests."""

from __future__ import annotations

import os
from unittest import mock

import httpx
import pytest
from respx import MockRouter

from tests.conftest import API_KEY, BASE_URL
from tinyfish import AsyncTinyFish, TinyFish

_PATH = "/v1/automation/run"
_RUN_OK = {
    "status": "COMPLETED",
    "run_id": "run-001",
    "result": None,
    "error": None,
    "num_of_steps": 1,
    "started_at": "2024-01-01T00:00:00Z",
    "finished_at": "2024-01-01T00:01:00Z",
}
_BODY = {"goal": "test", "url": "https://example.com"}


# ─── Construction ───────────────────────────────────────────────────────────


# Explicit api_key is stored on the client
def test_explicit_api_key():
    c = TinyFish(api_key="my-key", base_url=BASE_URL)
    assert c._api_key == "my-key"


# Falls back to TINYFISH_API_KEY environment variable
def test_api_key_from_env_var():
    with mock.patch.dict(os.environ, {"TINYFISH_API_KEY": "env-key"}):
        c = TinyFish(base_url=BASE_URL)
    assert c._api_key == "env-key"


# Raises ValueError when no api_key is provided and env var is unset
def test_missing_api_key_raises_value_error():
    with mock.patch.dict(os.environ, {}, clear=True):
        with pytest.raises(ValueError, match="No API key provided"):
            TinyFish(base_url=BASE_URL)


# Custom base_url overrides the default
def test_custom_base_url():
    c = TinyFish(api_key=API_KEY, base_url="https://custom.example.com")
    assert c._base_url == "https://custom.example.com"


# Custom timeout is applied to the underlying httpx client
def test_custom_timeout():
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL, timeout=30.0)
    assert c._client.timeout.connect == 30.0


# Custom max_retries is stored on the client
def test_custom_max_retries():
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=5)
    assert c._max_retries == 5


# Default timeout is 600 seconds
def test_default_timeout_is_600():
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL)
    assert c._client.timeout.connect == 600.0


# Default max_retries is 2
def test_default_max_retries_is_2():
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL)
    assert c._max_retries == 2


# Async client stores explicit api_key
def test_async_explicit_api_key():
    c = AsyncTinyFish(api_key="my-key", base_url=BASE_URL)
    assert c._api_key == "my-key"


# Async client raises ValueError when api_key is missing
def test_async_missing_api_key_raises_value_error():
    with mock.patch.dict(os.environ, {}, clear=True):
        with pytest.raises(ValueError, match="No API key provided"):
            AsyncTinyFish(base_url=BASE_URL)


# ─── Headers ────────────────────────────────────────────────────────────────


# Sends x-api-key header with every request
@pytest.mark.respx(base_url=BASE_URL)
def test_x_api_key_header(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(**_BODY)
    assert route.calls[0].request.headers["x-api-key"] == API_KEY


# Sends application/json content-type header
@pytest.mark.respx(base_url=BASE_URL)
def test_content_type_header(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(**_BODY)
    assert "application/json" in route.calls[0].request.headers["content-type"]


# Sends application/json accept header
@pytest.mark.respx(base_url=BASE_URL)
def test_accept_header(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(**_BODY)
    assert "application/json" in route.calls[0].request.headers["accept"]


# Sends user-agent header prefixed with tinyfish-python/
@pytest.mark.respx(base_url=BASE_URL)
def test_user_agent_header(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    client.agent.run(**_BODY)
    ua = route.calls[0].request.headers["user-agent"]
    assert ua.startswith("tinyfish-python/")


# Async client sends x-api-key header with every request
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_x_api_key_header(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    async with async_client as c:
        await c.agent.run(**_BODY)
    assert route.calls[0].request.headers["x-api-key"] == API_KEY


# Async client sends user-agent header prefixed with tinyfish-python/
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_user_agent_header(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    async with async_client as c:
        await c.agent.run(**_BODY)
    ua = route.calls[0].request.headers["user-agent"]
    assert ua.startswith("tinyfish-python/")


# ─── Context manager ────────────────────────────────────────────────────────


# Sync context manager allows requests and closes cleanly
@pytest.mark.respx(base_url=BASE_URL)
def test_sync_context_manager(respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    with TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=0) as c:
        result = c.agent.run(**_BODY)
    assert result.run_id == "run-001"


# Async context manager allows requests and closes cleanly
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_context_manager(respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
    async with AsyncTinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=0) as c:
        result = await c.agent.run(**_BODY)
    assert result.run_id == "run-001"


# ─── Repr / key masking ────────────────────────────────────────────────────


# repr masks all but the first 7 characters of the api_key
def test_repr_masks_api_key():
    c = TinyFish(api_key="test-key-0000000000", base_url=BASE_URL)
    r = repr(c)
    assert "test-key****" in r
    assert "test-key-0000000000" not in r


# repr fully masks short api_keys
def test_repr_short_key():
    c = TinyFish(api_key="short", base_url=BASE_URL)
    r = repr(c)
    assert "****" in r
    assert "short" not in r


# ─── TF_API_INTEGRATION env var ───────────────────────────────────────────


# TF_API_INTEGRATION env var injects api_integration into request body
@pytest.mark.respx(base_url=BASE_URL)
def test_integration_in_body_via_env(respx_mock: MockRouter):
    with mock.patch.dict(os.environ, {"TF_API_INTEGRATION": "n8n"}):
        c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=0)
        route = respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
        c.agent.run(**_BODY)
    import json

    body = json.loads(route.calls[0].request.content)
    assert body["api_integration"] == "n8n"


# Without TF_API_INTEGRATION, api_integration is not in request body
@pytest.mark.respx(base_url=BASE_URL)
def test_no_integration_in_body_by_default(respx_mock: MockRouter):
    with mock.patch.dict(os.environ, {}, clear=False):
        os.environ.pop("TF_API_INTEGRATION", None)
        c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=0)
        route = respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
        c.agent.run(**_BODY)
    import json

    body = json.loads(route.calls[0].request.content)
    assert "api_integration" not in body


# Async client injects api_integration into request body when env var is set
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_integration_in_body_via_env(respx_mock: MockRouter):
    with mock.patch.dict(os.environ, {"TF_API_INTEGRATION": "dify"}):
        route = respx_mock.post(_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
        async with AsyncTinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=0) as c:
            await c.agent.run(**_BODY)
    import json

    body = json.loads(route.calls[0].request.content)
    assert body["api_integration"] == "dify"
