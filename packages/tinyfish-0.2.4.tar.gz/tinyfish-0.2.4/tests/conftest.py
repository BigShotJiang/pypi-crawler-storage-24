"""Shared fixtures and constants for the test suite."""

from __future__ import annotations

from collections.abc import Iterator

import pytest

from tinyfish import AsyncTinyFish, TinyFish

BASE_URL = "http://127.0.0.1:4010"
API_KEY = "test-api-key"


@pytest.fixture
def client() -> Iterator[TinyFish]:
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=0)
    yield c
    c.close()


@pytest.fixture
async def async_client() -> AsyncTinyFish:
    c = AsyncTinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=0)
    yield c
    await c.close()
