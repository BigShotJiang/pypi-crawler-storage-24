"""Tests for runs resource — get() and list()."""

from __future__ import annotations

from typing import Any

import httpx
import pytest
from respx import MockRouter

from tests.conftest import BASE_URL
from tinyfish import AsyncTinyFish, AuthenticationError, NotFoundError, RunStatus, SortDirection, TinyFish
from tinyfish.runs.types import RunListResponse, RunRetrieveResponse

# ─── Paths ────────────────────────────────────────────────────────────────────

_RUNS_PATH = "/v1/runs"

# ─── Helpers ──────────────────────────────────────────────────────────────────

_TS = "2024-01-01T00:00:00Z"
_RUN_ID = "run-abc-123"


def _run(*, status: str = "COMPLETED", run_id: str = _RUN_ID, **overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "run_id": run_id,
        "status": status,
        "goal": "test goal",
        "created_at": _TS,
        "started_at": _TS,
        "finished_at": "2024-01-01T00:01:00Z",
        "result": {"data": "ok"} if status == "COMPLETED" else None,
        "error": {"message": "failed", "category": "AGENT_FAILURE"} if status == "FAILED" else None,
        "streaming_url": None,
        "browser_config": None,
    }
    return {**base, **overrides}


def _list_response(
    runs: list[dict[str, Any]],
    *,
    has_more: bool = False,
    next_cursor: str | None = None,
    total: int = 0,
) -> dict[str, Any]:
    return {
        "data": runs,
        "pagination": {"has_more": has_more, "next_cursor": next_cursor, "total": total},
    }


# ═══════════════════════════════════════════════════════════════════════════════
# runs.get() — sync
# ═══════════════════════════════════════════════════════════════════════════════


# get() returns RunRetrieveResponse with correct run_id
@pytest.mark.respx(base_url=BASE_URL)
def test_get_returns_run(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=_run()))
    result = client.runs.get(_RUN_ID)
    assert isinstance(result, RunRetrieveResponse)
    assert result.run_id == _RUN_ID


# get() returns PENDING status correctly
@pytest.mark.respx(base_url=BASE_URL)
def test_get_status_pending(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=_run(status="PENDING")))
    assert client.runs.get(_RUN_ID).status == "PENDING"


# get() returns RUNNING status correctly
@pytest.mark.respx(base_url=BASE_URL)
def test_get_status_running(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=_run(status="RUNNING")))
    assert client.runs.get(_RUN_ID).status == "RUNNING"


# get() COMPLETED run has result set and no error
@pytest.mark.respx(base_url=BASE_URL)
def test_get_status_completed(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=_run(status="COMPLETED")))
    result = client.runs.get(_RUN_ID)
    assert result.status == "COMPLETED"
    assert result.result is not None
    assert result.error is None


# get() FAILED run has error with message and no result
@pytest.mark.respx(base_url=BASE_URL)
def test_get_status_failed(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=_run(status="FAILED")))
    result = client.runs.get(_RUN_ID)
    assert result.status == "FAILED"
    assert result.result is None
    assert result.error is not None
    assert result.error.message == "failed"


# get() returns CANCELLED status correctly
@pytest.mark.respx(base_url=BASE_URL)
def test_get_status_cancelled(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(
        return_value=httpx.Response(200, json=_run(status="CANCELLED", error=None))
    )
    assert client.runs.get(_RUN_ID).status == "CANCELLED"


# get() FAILED run includes AGENT_FAILURE error category
@pytest.mark.respx(base_url=BASE_URL)
def test_get_failed_error_category(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=_run(status="FAILED")))
    result = client.runs.get(_RUN_ID)
    assert result.error is not None
    assert result.error.category == "AGENT_FAILURE"


# get() correctly parses all error category values
@pytest.mark.parametrize("category", ["SYSTEM_FAILURE", "AGENT_FAILURE", "UNKNOWN"])
@pytest.mark.respx(base_url=BASE_URL)
def test_get_error_category_values(category: str, client: TinyFish, respx_mock: MockRouter):
    data = _run(status="FAILED", error={"message": "err", "category": category})
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=data))
    result = client.runs.get(_RUN_ID)
    assert result.error is not None
    assert result.error.category == category


# get() parses browser_config with proxy_enabled and proxy_country_code
@pytest.mark.respx(base_url=BASE_URL)
def test_get_browser_config_fields(client: TinyFish, respx_mock: MockRouter):
    data = _run(browser_config={"proxy_enabled": True, "proxy_country_code": "US"})
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=data))
    result = client.runs.get(_RUN_ID)
    assert result.browser_config is not None
    assert result.browser_config.proxy_enabled is True
    assert result.browser_config.proxy_country_code == "US"


# get() browser_config does not expose browser_type attribute
@pytest.mark.respx(base_url=BASE_URL)
def test_get_browser_config_no_browser_type(client: TinyFish, respx_mock: MockRouter):
    data = _run(browser_config={"proxy_enabled": False, "proxy_country_code": None})
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=data))
    result = client.runs.get(_RUN_ID)
    assert result.browser_config is not None
    assert not hasattr(result.browser_config, "browser_type")


# get() returns None for optional fields when absent
@pytest.mark.respx(base_url=BASE_URL)
def test_get_optional_fields_absent(client: TinyFish, respx_mock: MockRouter):
    data = _run(started_at=None, finished_at=None, streaming_url=None, browser_config=None)
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=data))
    result = client.runs.get(_RUN_ID)
    assert result.started_at is None
    assert result.finished_at is None
    assert result.streaming_url is None
    assert result.browser_config is None


# get() raises ValueError for empty string run_id
def test_get_empty_run_id_raises_value_error(client: TinyFish):
    with pytest.raises(ValueError, match="non-empty"):
        client.runs.get("")


# get() raises ValueError for whitespace-only run_id
def test_get_whitespace_run_id_raises_value_error(client: TinyFish):
    with pytest.raises(ValueError, match="non-empty"):
        client.runs.get("   ")


# get() raises NotFoundError on 404 response
@pytest.mark.respx(base_url=BASE_URL)
def test_get_404(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(
        return_value=httpx.Response(404, json={"error": {"message": "run not found"}})
    )
    with pytest.raises(NotFoundError):
        client.runs.get(_RUN_ID)


# get() raises AuthenticationError on 401 response
@pytest.mark.respx(base_url=BASE_URL)
def test_get_401(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(
        return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}})
    )
    with pytest.raises(AuthenticationError):
        client.runs.get(_RUN_ID)


# ═══════════════════════════════════════════════════════════════════════════════
# runs.get() — async
# ═══════════════════════════════════════════════════════════════════════════════


# async get() returns Run instance with correct run_id
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_get_returns_run(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=_run()))
    async with async_client as c:
        result = await c.runs.get(_RUN_ID)
    assert isinstance(result, RunRetrieveResponse)
    assert result.run_id == _RUN_ID


# async get() COMPLETED run has result populated
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_get_status_completed(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=_run(status="COMPLETED")))
    async with async_client as c:
        result = await c.runs.get(_RUN_ID)
    assert result.status == "COMPLETED"
    assert result.result is not None


# async get() FAILED run has error with AGENT_FAILURE category
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_get_status_failed(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=_run(status="FAILED")))
    async with async_client as c:
        result = await c.runs.get(_RUN_ID)
    assert result.status == "FAILED"
    assert result.error is not None
    assert result.error.category == "AGENT_FAILURE"


# async get() handles all five run statuses correctly
@pytest.mark.parametrize("status", ["PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED"])
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_get_all_statuses(status: str, async_client: AsyncTinyFish, respx_mock: MockRouter):
    error = {"message": "err", "category": "UNKNOWN"} if status == "FAILED" else None
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(
        return_value=httpx.Response(200, json=_run(status=status, error=error))
    )
    async with async_client as c:
        result = await c.runs.get(_RUN_ID)
    assert result.status == status


# async get() parses browser_config with proxy country code
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_get_browser_config(async_client: AsyncTinyFish, respx_mock: MockRouter):
    data = _run(browser_config={"proxy_enabled": True, "proxy_country_code": "GB"})
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(return_value=httpx.Response(200, json=data))
    async with async_client as c:
        result = await c.runs.get(_RUN_ID)
    assert result.browser_config is not None
    assert result.browser_config.proxy_country_code == "GB"


# async get() raises ValueError for empty string run_id
async def test_async_get_empty_run_id_raises_value_error(async_client: AsyncTinyFish):
    async with async_client as c:
        with pytest.raises(ValueError, match="non-empty"):
            await c.runs.get("")


# async get() raises NotFoundError on 404 response
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_get_404(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(
        return_value=httpx.Response(404, json={"error": {"message": "not found"}})
    )
    async with async_client as c:
        with pytest.raises(NotFoundError):
            await c.runs.get(_RUN_ID)


# async get() raises AuthenticationError on 401 response
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_get_401(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.get(f"{_RUNS_PATH}/{_RUN_ID}").mock(
        return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}})
    )
    async with async_client as c:
        with pytest.raises(AuthenticationError):
            await c.runs.get(_RUN_ID)


# ═══════════════════════════════════════════════════════════════════════════════
# runs.list() — sync
# ═══════════════════════════════════════════════════════════════════════════════


# list() with no params returns RunListResponse with data
@pytest.mark.respx(base_url=BASE_URL)
def test_list_no_params(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([_run()], total=1)))
    result = client.runs.list()
    assert isinstance(result, RunListResponse)
    assert len(result.data) == 1


# list() sends limit as query param
@pytest.mark.respx(base_url=BASE_URL)
def test_list_with_limit(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list(limit=10)
    assert route.calls[0].request.url.params["limit"] == "10"


# list() sends status filter as query param for all status values
@pytest.mark.parametrize("status", ["PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED"])
@pytest.mark.respx(base_url=BASE_URL)
def test_list_filter_status(status: str, client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list(status=RunStatus(status))
    assert route.calls[0].request.url.params["status"] == status


# list() sends goal filter as query param
@pytest.mark.respx(base_url=BASE_URL)
def test_list_filter_goal(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list(goal="linkedin")
    assert route.calls[0].request.url.params["goal"] == "linkedin"


# list() sends created_after filter as query param
@pytest.mark.respx(base_url=BASE_URL)
def test_list_filter_created_after(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list(created_after="2026-01-01T00:00:00Z")
    assert route.calls[0].request.url.params["created_after"] == "2026-01-01T00:00:00Z"


# list() sends created_before filter as query param
@pytest.mark.respx(base_url=BASE_URL)
def test_list_filter_created_before(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list(created_before="2026-02-01T00:00:00Z")
    assert route.calls[0].request.url.params["created_before"] == "2026-02-01T00:00:00Z"


# list() sends both created_after and created_before for date range filtering
@pytest.mark.respx(base_url=BASE_URL)
def test_list_filter_date_range(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list(created_after="2026-01-01T00:00:00Z", created_before="2026-02-01T00:00:00Z")
    params = route.calls[0].request.url.params
    assert params["created_after"] == "2026-01-01T00:00:00Z"
    assert params["created_before"] == "2026-02-01T00:00:00Z"


# list() sends sort_direction=asc as query param
@pytest.mark.respx(base_url=BASE_URL)
def test_list_sort_asc(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list(sort_direction=SortDirection.ASC)
    assert route.calls[0].request.url.params["sort_direction"] == "asc"


# list() sends sort_direction=desc as query param
@pytest.mark.respx(base_url=BASE_URL)
def test_list_sort_desc(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list(sort_direction=SortDirection.DESC)
    assert route.calls[0].request.url.params["sort_direction"] == "desc"


# list() sends cursor as query param for pagination
@pytest.mark.respx(base_url=BASE_URL)
def test_list_cursor_pagination(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list(cursor="abc123")
    assert route.calls[0].request.url.params["cursor"] == "abc123"


# list() sends all params together as query params
@pytest.mark.respx(base_url=BASE_URL)
def test_list_all_params(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list(
        cursor="abc",
        limit=5,
        status=RunStatus.FAILED,
        goal="scrape prices",
        created_after="2026-01-01T00:00:00Z",
        created_before="2026-02-01T00:00:00Z",
        sort_direction=SortDirection.ASC,
    )
    params = route.calls[0].request.url.params
    assert params["cursor"] == "abc"
    assert params["limit"] == "5"
    assert params["status"] == "FAILED"
    assert params["goal"] == "scrape prices"
    assert params["created_after"] == "2026-01-01T00:00:00Z"
    assert params["created_before"] == "2026-02-01T00:00:00Z"
    assert params["sort_direction"] == "asc"


# list() omits all query params when no arguments provided
@pytest.mark.respx(base_url=BASE_URL)
def test_list_no_query_params_when_omitted(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    client.runs.list()
    params = route.calls[0].request.url.params
    assert "cursor" not in params
    assert "limit" not in params
    assert "status" not in params
    assert "goal" not in params
    assert "created_after" not in params
    assert "created_before" not in params
    assert "sort_direction" not in params


# list() returns empty data with has_more=False when no runs exist
@pytest.mark.respx(base_url=BASE_URL)
def test_list_empty_result(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([], has_more=False, total=0)))
    result = client.runs.list()
    assert result.data == []
    assert result.pagination.has_more is False


# list() paginated response includes has_more and next_cursor
@pytest.mark.respx(base_url=BASE_URL)
def test_list_paginated_result(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(_RUNS_PATH).mock(
        return_value=httpx.Response(
            200, json=_list_response([_run()], has_more=True, next_cursor="next-page", total=10)
        )
    )
    result = client.runs.list()
    assert result.pagination.has_more is True
    assert result.pagination.next_cursor == "next-page"


# list() returns multiple runs with correct run_ids and statuses
@pytest.mark.respx(base_url=BASE_URL)
def test_list_multiple_runs(client: TinyFish, respx_mock: MockRouter):
    runs = [
        _run(run_id="run-1", status="COMPLETED"),
        _run(run_id="run-2", status="FAILED"),
        _run(run_id="run-3", status="RUNNING"),
    ]
    respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response(runs, total=3)))
    result = client.runs.list()
    assert len(result.data) == 3
    assert result.data[0].run_id == "run-1"
    assert result.data[1].status == "FAILED"
    assert result.data[2].status == "RUNNING"


# list() pagination includes correct total count
@pytest.mark.respx(base_url=BASE_URL)
def test_list_pagination_total(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([_run()], total=42)))
    result = client.runs.list()
    assert result.pagination.total == 42


# list() raises AuthenticationError on 401 response
@pytest.mark.respx(base_url=BASE_URL)
def test_list_401(client: TinyFish, respx_mock: MockRouter):
    respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}))
    with pytest.raises(AuthenticationError):
        client.runs.list()


# ═══════════════════════════════════════════════════════════════════════════════
# runs.list() — async
# ═══════════════════════════════════════════════════════════════════════════════


# async list() with no params returns RunListResponse with data
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_no_params(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([_run()], total=1)))
    async with async_client as c:
        result = await c.runs.list()
    assert isinstance(result, RunListResponse)
    assert len(result.data) == 1


# async list() sends limit as query param
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_with_limit(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    async with async_client as c:
        await c.runs.list(limit=10)
    assert route.calls[0].request.url.params["limit"] == "10"


# async list() sends status filter as query param for all status values
@pytest.mark.parametrize("status", ["PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED"])
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_filter_status(status: str, async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    async with async_client as c:
        await c.runs.list(status=RunStatus(status))
    assert route.calls[0].request.url.params["status"] == status


# async list() sends goal filter as query param
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_filter_goal(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    async with async_client as c:
        await c.runs.list(goal="scrape")
    assert route.calls[0].request.url.params["goal"] == "scrape"


# async list() sends created_after filter as query param
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_filter_created_after(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    async with async_client as c:
        await c.runs.list(created_after="2026-01-01T00:00:00Z")
    assert route.calls[0].request.url.params["created_after"] == "2026-01-01T00:00:00Z"


# async list() sends sort_direction=asc as query param
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_sort_asc(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    async with async_client as c:
        await c.runs.list(sort_direction=SortDirection.ASC)
    assert route.calls[0].request.url.params["sort_direction"] == "asc"


# async list() sends all params together as query params
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_all_params(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    async with async_client as c:
        await c.runs.list(
            cursor="abc",
            limit=5,
            status=RunStatus.FAILED,
            goal="scrape",
            created_after="2026-01-01T00:00:00Z",
            created_before="2026-02-01T00:00:00Z",
            sort_direction=SortDirection.ASC,
        )
    params = route.calls[0].request.url.params
    assert params["cursor"] == "abc"
    assert params["limit"] == "5"
    assert params["status"] == "FAILED"
    assert params["goal"] == "scrape"


# async list() omits all query params when no arguments provided
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_no_query_params_when_omitted(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([])))
    async with async_client as c:
        await c.runs.list()
    params = route.calls[0].request.url.params
    assert "cursor" not in params
    assert "status" not in params


# async list() returns empty data with has_more=False when no runs exist
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_empty_result(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([], has_more=False, total=0)))
    async with async_client as c:
        result = await c.runs.list()
    assert result.data == []
    assert result.pagination.has_more is False


# async list() paginated response includes has_more and next_cursor
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_paginated_result(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.get(_RUNS_PATH).mock(
        return_value=httpx.Response(200, json=_list_response([_run()], has_more=True, next_cursor="next", total=10))
    )
    async with async_client as c:
        result = await c.runs.list()
    assert result.pagination.has_more is True
    assert result.pagination.next_cursor == "next"


# async list() returns multiple runs with correct count
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_multiple_runs(async_client: AsyncTinyFish, respx_mock: MockRouter):
    runs = [_run(run_id="r1"), _run(run_id="r2"), _run(run_id="r3")]
    respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response(runs, total=3)))
    async with async_client as c:
        result = await c.runs.list()
    assert len(result.data) == 3


# async list() pagination includes correct total count
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_pagination_total(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(200, json=_list_response([_run()], total=7)))
    async with async_client as c:
        result = await c.runs.list()
    assert result.pagination.total == 7


# async list() raises AuthenticationError on 401 response
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_list_401(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.get(_RUNS_PATH).mock(return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}))
    async with async_client as c:
        with pytest.raises(AuthenticationError):
            await c.runs.list()
