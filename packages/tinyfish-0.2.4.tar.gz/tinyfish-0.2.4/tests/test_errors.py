"""Error mapping, exception attributes, and retry behaviour tests."""

from __future__ import annotations

from typing import Any
from unittest import mock

import httpx
import pytest
from respx import MockRouter

from tests.conftest import API_KEY, BASE_URL
from tinyfish import (
    APIConnectionError,
    APITimeoutError,
    AsyncTinyFish,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    RequestTimeoutError,
    TinyFish,
    UnprocessableEntityError,
)

_PATH = "/v1/automation/run"
_BODY: dict[str, Any] = {"goal": "test", "url": "https://example.com"}
_RUN_OK = {
    "status": "COMPLETED",
    "run_id": "run-001",
    "result": None,
    "error": None,
    "num_of_steps": 1,
    "started_at": "2024-01-01T00:00:00Z",
    "finished_at": "2024-01-01T00:01:00Z",
}


def _err_json(msg: str = "error") -> dict[str, Any]:
    return {"error": {"message": msg}}


# ═══════════════════════════════════════════════════════════════════════════════
# HTTP status → exception class mapping (sync)
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.parametrize(
    "status_code,exc_class",
    [
        (400, BadRequestError),
        (401, AuthenticationError),
        (403, PermissionDeniedError),
        (404, NotFoundError),
        (408, RequestTimeoutError),
        (409, ConflictError),
        (422, UnprocessableEntityError),
        (429, RateLimitError),
        (500, InternalServerError),
        (502, InternalServerError),
        (503, InternalServerError),
    ],
)
# Each HTTP status code maps to the correct exception class
@pytest.mark.respx(base_url=BASE_URL)
def test_status_code_mapping(status_code: int, exc_class: type, client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(return_value=httpx.Response(status_code, json=_err_json()))
    with pytest.raises(exc_class) as exc:
        client.agent.run(**_BODY)
    assert exc.value.status_code == status_code


# Raised exception exposes the underlying httpx.Response object
@pytest.mark.respx(base_url=BASE_URL)
def test_exception_has_response_attribute(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(return_value=httpx.Response(401, json=_err_json("unauthorized")))
    with pytest.raises(AuthenticationError) as exc:
        client.agent.run(**_BODY)
    assert isinstance(exc.value.response, httpx.Response)
    assert exc.value.response.status_code == 401


# Exception message is extracted from the JSON error body
@pytest.mark.respx(base_url=BASE_URL)
def test_exception_message_from_json(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(return_value=httpx.Response(400, json=_err_json("the real message")))
    with pytest.raises(BadRequestError) as exc:
        client.agent.run(**_BODY)
    assert "the real message" in exc.value.message


# Exception message falls back to raw text when response is not JSON
@pytest.mark.respx(base_url=BASE_URL)
def test_exception_message_fallback_to_text(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(return_value=httpx.Response(400, content=b"plain error text"))
    with pytest.raises(BadRequestError) as exc:
        client.agent.run(**_BODY)
    assert exc.value.message  # non-empty


# httpx timeout is wrapped as APITimeoutError
@pytest.mark.respx(base_url=BASE_URL)
def test_timeout_raises(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(side_effect=httpx.TimeoutException("timed out"))
    with pytest.raises(APITimeoutError):
        client.agent.run(**_BODY)


# httpx connection error is wrapped as APIConnectionError
@pytest.mark.respx(base_url=BASE_URL)
def test_connection_error_raises(client: TinyFish, respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(side_effect=httpx.ConnectError("connection refused"))
    with pytest.raises(APIConnectionError):
        client.agent.run(**_BODY)


# ═══════════════════════════════════════════════════════════════════════════════
# HTTP status → exception class mapping (async)
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.parametrize(
    "status_code,exc_class",
    [
        (400, BadRequestError),
        (401, AuthenticationError),
        (403, PermissionDeniedError),
        (404, NotFoundError),
        (408, RequestTimeoutError),
        (409, ConflictError),
        (422, UnprocessableEntityError),
        (429, RateLimitError),
        (500, InternalServerError),
        (503, InternalServerError),
    ],
)
# Each HTTP status code maps to the correct exception class (async)
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_status_code_mapping(
    status_code: int, exc_class: type, async_client: AsyncTinyFish, respx_mock: MockRouter
):
    respx_mock.post(_PATH).mock(return_value=httpx.Response(status_code, json=_err_json()))
    async with async_client as c:
        with pytest.raises(exc_class) as exc:
            await c.agent.run(**_BODY)
    assert exc.value.status_code == status_code


# Async exception exposes the underlying httpx.Response object
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_exception_has_response(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(return_value=httpx.Response(401, json=_err_json("unauthorized")))
    async with async_client as c:
        with pytest.raises(AuthenticationError) as exc:
            await c.agent.run(**_BODY)
    assert isinstance(exc.value.response, httpx.Response)
    assert exc.value.response.status_code == 401


# Async exception message is extracted from the JSON error body
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_exception_message_from_json(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(return_value=httpx.Response(400, json=_err_json("the real message")))
    async with async_client as c:
        with pytest.raises(BadRequestError) as exc:
            await c.agent.run(**_BODY)
    assert "the real message" in exc.value.message


# Async httpx timeout is wrapped as APITimeoutError
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_timeout_raises(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(side_effect=httpx.TimeoutException("timed out"))
    async with async_client as c:
        with pytest.raises(APITimeoutError):
            await c.agent.run(**_BODY)


# Async httpx connection error is wrapped as APIConnectionError
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_connection_error_raises(async_client: AsyncTinyFish, respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(side_effect=httpx.ConnectError("connection refused"))
    async with async_client as c:
        with pytest.raises(APIConnectionError):
            await c.agent.run(**_BODY)


# ═══════════════════════════════════════════════════════════════════════════════
# Retry behaviour (sync)
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.parametrize(
    "status_code,exc_class",
    [(429, RateLimitError), (408, RequestTimeoutError), (500, InternalServerError)],
)
# Retryable status codes (429, 408, 500) are retried up to max_retries
@pytest.mark.respx(base_url=BASE_URL)
def test_retryable_codes_are_retried(status_code: int, exc_class: type, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(status_code, json=_err_json()))
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2)
    with mock.patch("time.sleep"):
        with pytest.raises(exc_class):
            c.agent.run(**_BODY)
    assert route.call_count == 3  # 1 original + 2 retries


@pytest.mark.parametrize("status_code,exc_class", [(400, BadRequestError), (401, AuthenticationError)])
# Non-retryable status codes (400, 401) fail immediately without retry
@pytest.mark.respx(base_url=BASE_URL)
def test_non_retryable_codes_not_retried(status_code: int, exc_class: type, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(status_code, json=_err_json()))
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2)
    with pytest.raises(exc_class):
        c.agent.run(**_BODY)
    assert route.call_count == 1


# A retryable failure followed by a 200 succeeds on the second attempt
@pytest.mark.respx(base_url=BASE_URL)
def test_retries_eventually_succeed(respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(
        side_effect=[
            httpx.Response(429, json=_err_json("rate limited")),
            httpx.Response(200, json=_RUN_OK),
        ]
    )
    c = TinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2)
    with mock.patch("time.sleep"):
        result = c.agent.run(**_BODY)
    assert result.run_id == "run-001"


# Setting max_retries=0 disables retry logic entirely
@pytest.mark.respx(base_url=BASE_URL)
def test_max_retries_0_does_not_retry(client: TinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(429, json=_err_json("rate limited")))
    with pytest.raises(RateLimitError):
        client.agent.run(**_BODY)
    assert route.call_count == 1


# ═══════════════════════════════════════════════════════════════════════════════
# Retry behaviour (async)
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.parametrize("status_code,exc_class", [(429, RateLimitError), (500, InternalServerError)])
# Async retryable status codes (429, 500) are retried up to max_retries
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_retryable_codes_are_retried(status_code: int, exc_class: type, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(status_code, json=_err_json()))
    c = AsyncTinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2)
    with mock.patch("asyncio.sleep"):
        async with c:
            with pytest.raises(exc_class):
                await c.agent.run(**_BODY)
    assert route.call_count == 3


@pytest.mark.parametrize("status_code,exc_class", [(400, BadRequestError), (401, AuthenticationError)])
# Async non-retryable status codes (400, 401) fail immediately without retry
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_non_retryable_codes_not_retried(status_code: int, exc_class: type, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(status_code, json=_err_json()))
    async with AsyncTinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2) as c:
        with pytest.raises(exc_class):
            await c.agent.run(**_BODY)
    assert route.call_count == 1


# Async retryable failure followed by a 200 succeeds on the second attempt
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_retries_eventually_succeed(respx_mock: MockRouter):
    respx_mock.post(_PATH).mock(
        side_effect=[
            httpx.Response(429, json=_err_json("rate limited")),
            httpx.Response(200, json=_RUN_OK),
        ]
    )
    c = AsyncTinyFish(api_key=API_KEY, base_url=BASE_URL, max_retries=2)
    with mock.patch("asyncio.sleep"):
        async with c:
            result = await c.agent.run(**_BODY)
    assert result.run_id == "run-001"


# Async client with max_retries=0 disables retry logic entirely
@pytest.mark.respx(base_url=BASE_URL)
async def test_async_max_retries_0_does_not_retry(async_client: AsyncTinyFish, respx_mock: MockRouter):
    route = respx_mock.post(_PATH).mock(return_value=httpx.Response(429, json=_err_json("rate limited")))
    async with async_client as c:
        with pytest.raises(RateLimitError):
            await c.agent.run(**_BODY)
    assert route.call_count == 1
