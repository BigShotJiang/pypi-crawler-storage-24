# Testing Guide

> New to pytest/respx? Jump to [Testing with respx for Dummies](#testing-with-respx-for-dummies) at the bottom.

## Running Tests

```bash
# Full suite
uv run pytest tests/ -v

# Single file
uv run pytest tests/test_agent.py -v

# Single test
uv run pytest tests/test_agent.py::test_run_minimal -v

# Parametrized test (specific variant)
uv run pytest "tests/test_runs.py::test_list_filter_status[COMPLETED]" -v

# Lint
uv run ruff check tests/
```

## Test Architecture

### File layout

| File | What it covers |
|---|---|
| `conftest.py` | Shared fixtures (`client`, `async_client`) and constants (`BASE_URL`, `API_KEY`) |
| `test_client.py` | Client construction, headers, context managers, repr |
| `test_agent.py` | `agent.run()`, `agent.queue()`, `agent.stream()` |
| `test_runs.py` | `runs.get()`, `runs.list()` |
| `test_errors.py` | HTTP status-to-exception mapping, retries |

### How tests work

Every test follows the same pattern:

1. **Set up a fake HTTP response** using `respx_mock`
2. **Call the SDK method** (e.g. `client.agent.run(...)`)
3. **Assert** the return value, raised exception, or sent request body/headers

No real network calls are ever made. respx intercepts all httpx traffic.

### Conventions

- **Flat functions**, not classes — each test is `def test_<method>_<what_it_checks>`
- **Full sync/async parity** — every sync test has an `async` mirror prefixed with `test_async_`
- **Fixtures for clients** — tests receive `client` or `async_client` via pytest injection, not manual construction
- **No `# type: ignore`** — if the SDK types support it, the tests should too
- **No `# FAILS` markers** — if a test can't pass, use `@pytest.mark.xfail(reason="...")` instead

## Updating Tests

### Adding a test for a new parameter

If the SDK adds a new param (e.g. `timeout` on `agent.run()`):

1. Add a test that sends the param and checks the request body:

   ```python
   @pytest.mark.respx(base_url=BASE_URL)
   def test_run_timeout_in_body(client: TinyFish, respx_mock: MockRouter):
       route = respx_mock.post(_RUN_PATH).mock(return_value=httpx.Response(200, json=_RUN_OK))
       client.agent.run(**_BODY, timeout=30)
       assert json.loads(route.calls[0].request.content)["timeout"] == 30
   ```

2. Add the async mirror (`test_async_run_timeout_in_body`)

### Adding a test for a new endpoint

1. Add the path constant (e.g. `_NEW_PATH = "/v1/new-endpoint"`)
2. Add mock response data
3. Write sync + async tests
4. If the endpoint has multiple param combos, use `@pytest.mark.parametrize`

### Adding a test for a new error scenario

Add it to `test_errors.py`. If it's a new status code, just add a tuple to the existing parametrize list:

```python
@pytest.mark.parametrize("status_code,exc_class", [
    ...
    (418, TeapotError),  # add here
])
```

---

## Testing with respx for Dummies

### What is respx?

The SDK uses `httpx` to make HTTP calls. In tests, you don't want to hit a real server. **respx** intercepts those calls and returns fake responses you control.

### The 3 pieces you need

```python
@pytest.mark.respx(base_url=BASE_URL)          # 1. activate respx for this test
def test_something(client, respx_mock):         # 2. get the mock router
    respx_mock.post("/v1/automation/run").mock(  # 3. define what to return
        return_value=httpx.Response(200, json={"status": "COMPLETED", ...})
    )
```

- `@pytest.mark.respx(base_url=...)` — tells respx to intercept requests to this base URL
- `respx_mock` — the mock router (a pytest fixture provided by respx automatically)
- `.mock(return_value=...)` — the fake response to return

### Returning different responses

```python
# Fixed response
respx_mock.post(path).mock(return_value=httpx.Response(200, json={...}))

# Error response
respx_mock.post(path).mock(return_value=httpx.Response(401, json={"error": {"message": "unauthorized"}}))

# Sequence (first call returns 429, second returns 200)
respx_mock.post(path).mock(side_effect=[
    httpx.Response(429, json={"error": {"message": "rate limited"}}),
    httpx.Response(200, json={...}),
])

# Simulate network error
respx_mock.post(path).mock(side_effect=httpx.ConnectError("connection refused"))
```

### Inspecting what the SDK sent

```python
route = respx_mock.post(path).mock(return_value=httpx.Response(200, json={...}))
client.agent.run(goal="test", url="https://example.com")

# Request body
body = json.loads(route.calls[0].request.content)
assert body["goal"] == "test"

# Headers
assert route.calls[0].request.headers["x-api-key"] == "test-api-key"

# Query params (for GET requests)
assert route.calls[0].request.url.params["limit"] == "10"

# Number of calls made
assert route.call_count == 1
```

### Asserting errors

```python
# Assert an exception is raised
with pytest.raises(AuthenticationError):
    client.agent.run(**_BODY)

# Assert exception details
with pytest.raises(ValueError, match="non-empty"):
    client.runs.get("")
```

### Fixtures (how `client` appears magically)

```python
# conftest.py defines this:
@pytest.fixture
def client():
    return TinyFish(api_key="test-api-key", base_url="http://127.0.0.1:4010", max_retries=0)

# Any test that has `client` as a parameter gets it automatically:
def test_something(client):  # pytest sees "client", finds the fixture, injects it
    client.agent.run(...)
```

### Parametrize (one test, many inputs)

```python
@pytest.mark.parametrize("status", ["PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED"])
def test_filter_status(status, client, respx_mock):
    ...
# Generates 5 tests: test_filter_status[PENDING], test_filter_status[RUNNING], etc.

# Multiple values per case:
@pytest.mark.parametrize("code,exc", [(400, BadRequestError), (401, AuthenticationError)])
def test_error(code, exc, client, respx_mock):
    ...
```

### Async tests

Same thing, just `async`:

```python
async def test_async_run(async_client, respx_mock):
    respx_mock.post(path).mock(return_value=httpx.Response(200, json={...}))
    async with async_client as c:
        result = await c.agent.run(**_BODY)
```

`asyncio_mode = "auto"` is configured in `pyproject.toml` under `[tool.pytest.ini_options]`. This tells `pytest-asyncio` to automatically detect `async def test_*` functions without needing `@pytest.mark.asyncio` on each one.
