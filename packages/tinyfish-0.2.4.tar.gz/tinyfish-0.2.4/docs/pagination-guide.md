# Pagination Guide

The `runs.list()` method supports filtering, sorting, and cursor-based pagination.

## Basic listing

```python
from tinyfish import TinyFish

client = TinyFish()

response = client.runs.list()

for run in response.data:
    print(f"{run.run_id} | {run.status} | {run.goal}")
```

## Filtering

### By status

```python
from tinyfish import RunStatus

response = client.runs.list(status=RunStatus.COMPLETED)
```

Available statuses: `PENDING`, `RUNNING`, `COMPLETED`, `FAILED`, `CANCELLED`.

### By goal text

```python
response = client.runs.list(goal="Bitcoin price")
```

Matches runs whose goal contains the given text.

### By date range

```python
response = client.runs.list(
    created_after="2025-01-01T00:00:00Z",
    created_before="2025-12-31T23:59:59Z",
)
```

Both `created_after` and `created_before` accept ISO 8601 timestamps.

### Combining filters

All filters can be combined:

```python
response = client.runs.list(
    status=RunStatus.COMPLETED,
    goal="headlines",
    created_after="2025-06-01T00:00:00Z",
    limit=20,
)
```

## Sorting

Control the order with `sort_direction`:

```python
from tinyfish import SortDirection

# Newest first
response = client.runs.list(sort_direction=SortDirection.DESC)

# Oldest first
response = client.runs.list(sort_direction=SortDirection.ASC)
```

## Pagination

### Limit

Set the maximum number of runs per page:

```python
response = client.runs.list(limit=10)
```

### Pagination info

Every response includes pagination metadata:

```python
response = client.runs.list(limit=10)

print(response.pagination.total)       # Total runs matching filters
print(response.pagination.has_more)    # True if more pages exist
print(response.pagination.next_cursor) # Pass to cursor= for the next page
```

### Full pagination loop

```python
from tinyfish import TinyFish, RunStatus

client = TinyFish()
all_runs = []
cursor = None

while True:
    response = client.runs.list(
        status=RunStatus.COMPLETED,
        limit=50,
        cursor=cursor,
    )
    all_runs.extend(response.data)

    if not response.pagination.has_more:
        break
    cursor = response.pagination.next_cursor

print(f"Fetched {len(all_runs)} completed runs")
```

## Async

`AsyncTinyFish` supports the same interface:

```python
from tinyfish import AsyncTinyFish, RunStatus

client = AsyncTinyFish()
response = await client.runs.list(status=RunStatus.COMPLETED, limit=10)
```

## Parameter reference

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `cursor` | `str \| None` | `None` | Pagination cursor from `next_cursor` |
| `limit` | `int \| None` | `None` | Max runs per page |
| `status` | `RunStatus \| None` | `None` | Filter by status |
| `goal` | `str \| None` | `None` | Filter by goal text |
| `created_after` | `str \| None` | `None` | ISO 8601 lower bound |
| `created_before` | `str \| None` | `None` | ISO 8601 upper bound |
| `sort_direction` | `SortDirection \| None` | `None` | `"asc"` or `"desc"` |
