# Proxy & Browser Profiles Guide

Configure how the agent's browser behaves and routes traffic.

## Browser profiles

The `browser_profile` parameter controls the browser environment used for a run.

| Profile | Description | Use when |
|---------|-------------|----------|
| `lite` | Fast, lightweight (default) | Most websites |
| `stealth` | Anti-detection fingerprinting | Sites with bot protection (Cloudflare, DataDome, etc.) |

```python
from tinyfish import TinyFish, BrowserProfile

client = TinyFish()

# Default — lite profile
response = client.agent.run(
    goal="Extract product details",
    url="https://example.com/products",
)

# Stealth — for sites with bot detection
response = client.agent.run(
    goal="Extract product details",
    url="https://protected-site.com/products",
    browser_profile=BrowserProfile.STEALTH,
)
```

Start with `lite`. Switch to `stealth` if the target site blocks or challenges the agent.

## Proxy configuration

Route the agent's browser traffic through a proxy with `ProxyConfig`. Optionally pin the proxy to a specific country.

```python
from tinyfish import ProxyConfig, ProxyCountryCode
```

### No proxy (default)

If you omit `proxy_config`, no proxy is used:

```python
response = client.agent.run(
    goal="...",
    url="...",
)
```

### Proxy enabled, no specific country

```python
response = client.agent.run(
    goal="...",
    url="...",
    proxy_config=ProxyConfig(enabled=True),
)
```

### Proxy with a country

```python
response = client.agent.run(
    goal="...",
    url="...",
    proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.GB),
)
```

### Available countries

| Code | Country |
|------|---------|
| `US` | United States |
| `GB` | United Kingdom |
| `CA` | Canada |
| `DE` | Germany |
| `FR` | France |
| `JP` | Japan |
| `AU` | Australia |

## Works with all integration methods

Browser profiles and proxy config can be passed to `run()`, `queue()`, and `stream()`:

```python
# run()
client.agent.run(
    goal="...", url="...",
    browser_profile=BrowserProfile.STEALTH,
    proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.US),
)

# queue()
client.agent.queue(
    goal="...", url="...",
    browser_profile=BrowserProfile.STEALTH,
    proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.US),
)

# stream()
with client.agent.stream(
    goal="...", url="...",
    browser_profile=BrowserProfile.STEALTH,
    proxy_config=ProxyConfig(enabled=True, country_code=ProxyCountryCode.US),
) as stream:
    for event in stream:
        pass
```

## Checking what config was used

When you retrieve a run, `browser_config` shows what was used:

```python
run = client.runs.get("run_abc123")
print(run.browser_config.proxy_enabled)       # True/False
print(run.browser_config.proxy_country_code)  # "US" or None
```
