# Exceptions & Error Handling

---

## Layer 1 — httpx (the bottom, third-party)

`httpx` is the HTTP library doing the actual network calls. It can throw two kinds of errors (regardless of async or sync):

- `httpx.TimeoutException` — the request took too long
- `httpx.RequestError` — any other network failure (DNS, connection refused, etc.)

These are not SDK errors yet. The job of the layers above is to catch and translate them.

---

## Layer 2 — `_make_status_error` in `_base.py` (the translator)

When the server responds but with a bad status code, httpx itself doesn't raise — it just returns a response with `response.is_error == True`. So `_base.py:60` has `_make_status_error()` which:

1. Looks up the status code in a map → picks the right exception class
2. Tries to parse the JSON body for a human-readable message
3. Falls back to raw response text if the body isn't JSON

```
404  → NotFoundError
401  → AuthenticationError
429  → RateLimitError
5xx  → InternalServerError
...etc
```

This is where the raw HTTP world gets converted into SDK-typed exceptions.

---

## Layer 3 — `_request()` in `sync.py` / `async_.py` (the retry + catch layer)

This is the core of the logic. It has two jobs:

**Job 1 — retry certain errors via tenacity:**

```
RequestTimeoutError  ← server sent 408
RateLimitError       ← server sent 429
InternalServerError  ← server sent 5xx
httpx.RequestError   ← network failure
```

These are retried up to `max_retries` times (default 2) with exponential backoff (0.5s multiplier, max 8s wait).

**Job 2 — translate the remaining httpx errors that survived all retries:**

```python
except httpx.TimeoutException → raise APITimeoutError
except httpx.RequestError     → raise APIConnectionError
```

Notice what's *not* retried: `BadRequestError` (400), `AuthenticationError` (401), `NotFoundError` (404), etc. Those propagate immediately on the first attempt — there's no point retrying them.

---

## Layer 4 — `_get` / `_post` / `_post_stream` (the interface layer)

These call `_request()` and either parse the response via Pydantic (`_parse_response`) or yield raw lines (for SSE streams). They don't add any error handling — they just let exceptions propagate upward.

---

## Layer 5 — The exception hierarchy (`exceptions.py`)

Everything the user can catch inherits from `SDKError`:

```
SDKError
└─ APIError                   ← carries .request and .response
   ├─ APIConnectionError       ← network failed
   │  └─ APITimeoutError       ← specifically a timeout
   └─ APIStatusError           ← carries .status_code too
      ├─ BadRequestError       (400)
      ├─ AuthenticationError   (401)
      ├─ PermissionDeniedError (403)
      ├─ NotFoundError         (404)
      ├─ RequestTimeoutError   (408)  ← server-side timeout
      ├─ ConflictError         (409)
      ├─ UnprocessableEntityError (422)
      ├─ RateLimitError        (429)
      └─ InternalServerError   (500+)
```

Note the distinction between `APITimeoutError` (client-side — the request never completed) and `RequestTimeoutError` (server-side — server responded with 408).

---

## What this means for SDK users

They can be as broad or specific as they want:

```python
from tinyfish import TinyFish, RateLimitError, AuthenticationError, SDKError

client = TinyFish(api_key="...")

try:
    result = client.agent.run(...)
except AuthenticationError:
    # bad API key — don't retry
except RateLimitError:
    # already retried internally, give up
except SDKError:
    # catch anything else
```
