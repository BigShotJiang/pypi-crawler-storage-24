# Streaming Guide

The `agent.stream()` method opens a Server-Sent Events (SSE) connection and yields events in real time as the agent works. Use it when you need live progress updates or a live browser preview.

## When to use streaming

| Method | Use when |
|--------|----------|
| `agent.run()` | You just want the final result |
| `agent.queue()` | You want to start a run and check back later |
| `agent.stream()` | You need real-time progress, step-by-step updates, or a live browser preview URL |

## Event lifecycle

Events arrive in this order:

```text
STARTED → STREAMING_URL → PROGRESS (repeated) → COMPLETE
           ↑ optional       ↑ 0 or more
```

Heartbeat events (`HEARTBEAT`) may appear at any point to keep the connection alive.

## Two consumption patterns

### 1. Callbacks

Pass callback functions when opening the stream. They fire automatically as you iterate.

```python
from tinyfish import TinyFish

client = TinyFish()

with client.agent.stream(
    goal="Extract the top 5 headlines",
    url="https://news.ycombinator.com",
    on_started=lambda e: print(f"Run {e.run_id} started"),
    on_streaming_url=lambda e: print(f"Watch live: {e.streaming_url}"),
    on_progress=lambda e: print(f"  Step: {e.purpose}"),
    on_heartbeat=lambda e: print(f"  heartbeat at {e.timestamp}"),
    on_complete=lambda e: print(f"Finished with status: {e.status}"),
) as stream:
    for event in stream:
        pass  # callbacks fire during iteration
```

### 2. Iteration

Skip the callbacks and inspect each event yourself.

```python
from tinyfish import TinyFish, RunStatus
from tinyfish import (
    StartedEvent,
    StreamingUrlEvent,
    ProgressEvent,
    CompleteEvent,
)

client = TinyFish()

with client.agent.stream(
    goal="Extract the top 5 headlines",
    url="https://news.ycombinator.com",
) as stream:
    for event in stream:
        if isinstance(event, StartedEvent):
            print(f"Run {event.run_id} started")
        elif isinstance(event, StreamingUrlEvent):
            print(f"Live browser: {event.streaming_url}")
        elif isinstance(event, ProgressEvent):
            print(f"  > {event.purpose}")
        elif isinstance(event, CompleteEvent):
            if event.status == RunStatus.COMPLETED:
                print(event.result_json)
            else:
                print(f"Failed: {event.error.message}")
```

### Using both at the same time

Callbacks and iteration work together. Callbacks fire first, then the event is yielded to the iterator. This is useful when you want a callback to handle side effects (like logging) while the main loop handles business logic.

```python
def log_progress(event):
    logger.info(f"Step: {event.purpose}")

with client.agent.stream(
    goal="...",
    url="...",
    on_progress=log_progress,
) as stream:
    for event in stream:
        if isinstance(event, CompleteEvent):
            save_to_database(event.result_json)
```

## Async streaming

Use `AsyncTinyFish` with `async for`:

```python
from tinyfish import AsyncTinyFish, CompleteEvent

client = AsyncTinyFish()

async with client.agent.stream(
    goal="Extract the top 5 headlines",
    url="https://news.ycombinator.com",
    on_progress=lambda e: print(f"  > {e.purpose}"),
) as stream:
    async for event in stream:
        if isinstance(event, CompleteEvent):
            print(event.result_json)
```

## Event type reference

### `StartedEvent`

| Field | Type | Description |
|-------|------|-------------|
| `type` | `EventType` | Always `EventType.STARTED` |
| `run_id` | `str` | Unique run identifier |
| `timestamp` | `datetime` | When the run started |

### `StreamingUrlEvent`

| Field | Type | Description |
|-------|------|-------------|
| `type` | `EventType` | Always `EventType.STREAMING_URL` |
| `run_id` | `str` | Unique run identifier |
| `streaming_url` | `str` | WebSocket URL for live browser preview |
| `timestamp` | `datetime` | When the URL became available |

### `ProgressEvent`

| Field | Type | Description |
|-------|------|-------------|
| `type` | `EventType` | Always `EventType.PROGRESS` |
| `run_id` | `str` | Unique run identifier |
| `purpose` | `str` | Description of the current step |
| `timestamp` | `datetime` | When the step occurred |

### `HeartbeatEvent`

| Field | Type | Description |
|-------|------|-------------|
| `type` | `EventType` | Always `EventType.HEARTBEAT` |
| `timestamp` | `datetime` | When the heartbeat was sent |

### `CompleteEvent`

| Field | Type | Description |
|-------|------|-------------|
| `type` | `EventType` | Always `EventType.COMPLETE` |
| `run_id` | `str` | Unique run identifier |
| `status` | `RunStatus` | Final status (`COMPLETED`, `FAILED`, etc.) |
| `timestamp` | `datetime` | When the run finished |
| `result_json` | `dict \| None` | Extracted data (None if failed) |
| `error` | `RunError \| None` | Error details (None if succeeded) |

## Error handling in streams

HTTP errors (`401`, `500`, etc.) are raised **before** the stream yields any events. You can catch them normally:

```python
from tinyfish import AuthenticationError, SDKError

try:
    with client.agent.stream(goal="...", url="...") as stream:
        for event in stream:
            pass
except AuthenticationError:
    print("Invalid API key")
except SDKError:
    print("Connection or server error")
```

If the connection drops mid-stream or an SSE event can't be parsed, an `SSEParseError` is raised during iteration.
