# API Integration Tagging (`TF_API_INTEGRATION`)

Internal-only mechanism for identifying which integration platform is making API requests through our SDK.

## How it works

The SDK reads the `TF_API_INTEGRATION` environment variable when building request bodies. When set, the SDK injects `api_integration` into every request body sent to the automation endpoints.

```text
TF_API_INTEGRATION=n8n  -->  { "goal": "...", "url": "...", "api_integration": "n8n" }
```

This reuses the existing `api_integration` body field that the server already parses, stores in the DB, and emits to PostHog — no backend changes needed.

This is intentionally **not** exposed as a constructor parameter or public API. It does not appear in editor autocomplete, type definitions, or documentation. Only we control which integrations set this value.

## Environment variable

| Variable              | Example values         | Required |
| --------------------- | ---------------------- | -------- |
| `TF_API_INTEGRATION`  | `n8n`, `dify`, `zapier` | No       |

When unset or empty, `api_integration` is omitted from the body. Existing behavior is unchanged.

## Where it's read

`src/tinyfish/_utils/client/_base.py` — `_inject_integration()`, called from `_request()` in both sync and async clients:

```python
integration = os.environ.get("TF_API_INTEGRATION", "").strip()
if integration:
    json["api_integration"] = integration
```

This runs on every API request automatically — no per-resource setup needed.

## Server-side flow

1. Server validates `api_integration` via Zod schema (`frontend/app/v1/schemas.ts`)
2. `buildRunOptions()` extracts it from the request body
3. Stored in `runs.api_integration` DB column
4. Emitted on `run_completed` PostHog event as `api_integration` property

## Setting up a new integration

To tag requests from a new integration partner:

1. Set `TF_API_INTEGRATION=<name>` in the environment where the SDK runs (e.g., the n8n node, Dify plugin, Zapier action)
2. No SDK code changes needed — the env var is picked up automatically
3. The value will appear in PostHog under `run_completed.api_integration`

## Tests

`tests/test_client.py`:

- `test_integration_in_body_via_env` — `api_integration` is in the request body when env var is set
- `test_no_integration_in_body_by_default` — `api_integration` is absent when env var is not set
- `test_async_integration_in_body_via_env` — async client variant
