# Publishing to the TinyFish Private Registry

## Prerequisites

- [uv](https://docs.astral.sh/uv/) installed
- PyPI credentials from 1Password
- Need to be connected to VPN (or company wifi)

## 1. Clean and build

```bash
cd sdk/sdk-python
rm -rf dist/
uv build
```

This outputs `dist/tinyfish-<version>-py3-none-any.whl` and `dist/tinyfish-<version>.tar.gz`.

## 2. Publish

Set credentials via environment variables (values are in 1Password):

```bash
export UV_PUBLISH_USERNAME="<from 1password>"
export UV_PUBLISH_PASSWORD="<from 1password>"
```

Then publish:

```bash
uv publish dist/* --publish-url https://pypi.production.tinyfish.io/
```

## 3. Verify the install

Configure pip to authenticate with the private registry. Add to `~/.pip/pip.conf` (or `pip.ini` on Windows):

```ini
[global]
extra-index-url = https://pypi.production.tinyfish.io/
```

Then set credentials via environment variables:

```bash
export PIP_EXTRA_INDEX_URL="https://${TINYFISH_PYPI_USER}:${TINYFISH_PYPI_PASS}@pypi.production.tinyfish.io/"
```

```bash
pip install tinyfish
python -c "from tinyfish import TinyFish; print('ok')"
```

Use `--extra-index-url` (not `--index-url`) so pip still falls back to public PyPI for dependencies like `httpx`, `pydantic`, and `tenacity`.

## Notes

- **Bump the version** before each publish — the registry rejects duplicate versions. Update the version in `pyproject.toml`.
- **Never put credentials inline** in commands — they leak into shell history and logs. Always use environment variables or config files.
