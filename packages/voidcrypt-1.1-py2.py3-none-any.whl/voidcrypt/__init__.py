"""
VoidCrypt - 12-Layer Military Grade Encryption
"""

__version__ = "1.1"
__author__ = "Sarvesh"  # Internal only

from .core import main