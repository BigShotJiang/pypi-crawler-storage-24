"""
Workflow Tracking Service — cross-tenant execution monitoring.

Manages WorkflowTracking records: lightweight status snapshots written
alongside every Workflow save so monitoring and diagnostics can query
execution state globally without touching tenant-scoped indexes.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from typing import List, Optional

from aws_lambda_powertools import Logger
from boto3_assist.dynamodb.dynamodb import DynamoDB

from geek_cafe_saas_sdk.core.request_context import RequestContext
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.core.error_codes import ErrorCode
from geek_cafe_saas_sdk.core.services.database_service import DatabaseService
from geek_cafe_saas_sdk.lambda_handlers._base.decorators import service_method

from ..models.workflow_tracking import WorkflowTracking

logger = Logger()


class WorkflowTrackingService(DatabaseService[WorkflowTracking]):
    """
    Service for managing cross-tenant workflow tracking records.

    Write path:
        Called as a fire-and-forget side-effect by WorkflowService._save_model().
        One upsert per Workflow save keeps the tracking record in sync.

    Read path:
        Used by monitoring Lambdas, admin tooling, and diagnostic services to
        query execution status across all tenants without tenant-scoped filtering.

    Security model:
        This service is intentionally cross-tenant.  It must only be instantiated
        with a SystemRequestContext.  Callers are responsible for ensuring that
        query results are not exposed to regular (non-admin) users.
    """

    def __init__(
        self,
        *,
        dynamodb: Optional[DynamoDB] = None,
        table_name: Optional[str] = None,
        request_context: Optional[RequestContext] = None,
        **kwargs,
    ):
        super().__init__(
            dynamodb=dynamodb,
            table_name=table_name,
            request_context=request_context,
            **kwargs,
        )

    # =========================================================================
    # Write
    # =========================================================================

    @service_method("upsert_tracking")
    def upsert(self, execution) -> ServiceResult[WorkflowTracking]:
        """
        Create or update the tracking record for an execution.

        Accepts a Workflow model instance (or any object with the relevant
        fields) and writes a WorkflowTracking snapshot to DynamoDB.

        Args:
            execution: Workflow model instance to snapshot

        Returns:
            ServiceResult with the saved WorkflowTracking record
        """
        try:
            if not execution or not (execution.id or getattr(execution, "execution_id", None)):
                return ServiceResult.error_result(
                    "execution_id is required for tracking",
                    ErrorCode.INVALID_INPUT,
                )

            record = WorkflowTracking.from_workflow(execution)
            return self._save_model(record, skip_access_check=True)

        except Exception as e:
            logger.exception(f"Error upserting tracking record: {e}")
            return ServiceResult.error_result(str(e), ErrorCode.INTERNAL_ERROR)

    # =========================================================================
    # Read
    # =========================================================================

    @service_method("get_tracking")
    def get(self, execution_id: str) -> ServiceResult[WorkflowTracking]:
        """
        Fetch the tracking record for a single execution.

        Args:
            execution_id: Execution ID to look up

        Returns:
            ServiceResult with the WorkflowTracking record, or None if not found
        """
        try:
            record = WorkflowTracking()
            record.execution_id = execution_id
            fetched = self._fetch_model_raw(record)
            return ServiceResult.success_result(data=fetched)
        except Exception as e:
            logger.exception(f"Error fetching tracking record {execution_id}: {e}")
            return ServiceResult.error_result(str(e), ErrorCode.INTERNAL_ERROR)

    @service_method("list_running_for_monitoring")
    def list_running_for_monitoring(
        self,
        limit: int = 1000,
    ) -> ServiceResult[List[WorkflowTracking]]:
        """
        List all RUNNING executions across all tenants.

        Security Model: CROSS-TENANT MONITORING (skip_security_check=True)
            For system-level monitoring only.

        Uses gsi3 (PK='tracking#monitoring#status#running',
        SK begins_with 'started_ts#') for an efficient single-partition query.

        Prefer list_timed_out_executions() when only potentially-timed-out
        executions are needed.

        Args:
            limit: Maximum number of records to return (default 1000)

        Returns:
            ServiceResult containing all RUNNING WorkflowTracking records
        """
        query_model = WorkflowTracking()
        query_model.status = "running"

        return self._query_by_index(
            query_model,
            "gsi3",
            limit=limit,
            query_condition="begins_with",
            skip_security_check=True,
        )

    @service_method("list_by_status_for_monitoring")
    def list_by_status_for_monitoring(
        self,
        status: str,
        limit: int = 1000,
    ) -> ServiceResult[List[WorkflowTracking]]:
        """
        List all executions with the given status across all tenants.

        Security Model: CROSS-TENANT MONITORING — system/admin use only.

        Args:
            status: Status value to query (e.g. "running", "failed", "pending")
            limit: Maximum number of records to return (default 1000)

        Returns:
            ServiceResult containing matching WorkflowTracking records
        """
        query_model = WorkflowTracking()
        query_model.status = status

        return self._query_by_index(
            query_model,
            "gsi3",
            limit=limit,
            query_condition="begins_with",
            skip_security_check=True,
        )

    @service_method("list_timed_out_executions")
    def list_timed_out_executions(
        self,
        min_timeout_seconds: int,
        limit: int = 1000,
    ) -> ServiceResult[List[WorkflowTracking]]:
        """
        List RUNNING executions that started before the given timeout threshold.

        Uses gsi3 BETWEEN query to filter by timestamp directly in DynamoDB,
        returning only executions that have potentially timed out.

        Security Model: CROSS-TENANT MONITORING (skip_security_check=True)

        Args:
            min_timeout_seconds: Executions started more than this many seconds
                                 ago are considered potentially timed out.
            limit: Maximum number of records to return (default 1000)

        Returns:
            ServiceResult containing RUNNING executions started before the cutoff
        """
        import time

        cutoff_ts = time.time() - min_timeout_seconds

        query_model = WorkflowTracking()
        query_model.status = "running"

        return self._query_by_index(
            query_model,
            "gsi3",
            limit=limit,
            query_condition="between",
            low_value=0,
            high_value=cutoff_ts,
            skip_security_check=True,
        )

    # =========================================================================
    # Required DatabaseService abstract methods
    # =========================================================================

    def create(self, tenant_id: str, user_id: str, **kwargs) -> ServiceResult:
        raise NotImplementedError("Use upsert() instead")

    def get_by_id(
        self, resource_id: str, tenant_id: str, user_id: str
    ) -> ServiceResult[WorkflowTracking]:
        return self.get(resource_id)

    def update(
        self, resource_id: str, tenant_id: str, user_id: str, updates: dict
    ) -> ServiceResult[WorkflowTracking]:
        raise NotImplementedError("Use upsert() instead")

    def delete(
        self, resource_id: str, tenant_id: str, user_id: str
    ) -> ServiceResult[bool]:
        raise NotImplementedError("Tracking records are not deleted directly")
