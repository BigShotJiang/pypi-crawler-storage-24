#    firmware_id.py
#        Holds the default firmware ID. Used for detection of untagged firmware
#
#   - License : MIT - See LICENSE file
#   - Project : Scrutiny Debugger (github.com/scrutinydebugger/scrutiny-main)
#
#    Copyright (c) 2022 Scrutiny Debugger

__all__ = ['PLACEHOLDER']

# Placeholder used for search and replace tagging
PLACEHOLDER: bytes = bytes([
    0xA9, 0xDC, 0xC0, 0x65, 0x28, 0xFD, 0x41, 0xFA,
    0x7C, 0xE8, 0x63, 0xD6, 0xAA, 0x94, 0xA7, 0x08
])
