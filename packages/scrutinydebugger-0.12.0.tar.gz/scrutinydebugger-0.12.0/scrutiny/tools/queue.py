#    queue.py
#        An extension of the native Python queue with some helpers to deal more cleanly with
#        empty/full conditions
#
#   - License : MIT - See LICENSE file
#   - Project : Scrutiny Debugger (github.com/scrutinydebugger/scrutiny-main)
#
#    Copyright (c) 2025 Scrutiny Debugger

__all__ = ['ScrutinyQueue']


from scrutiny.tools.typing import *
import queue

T = TypeVar("T")


class ScrutinyQueue(Generic[T], queue.Queue[T]):
    """A queue that extends the native Python queue with helper methods."""

    def deplete(self) -> None:
        """Remove all items from the queue."""
        while True:
            try:
                self.get_nowait()
            except queue.Empty:
                break

    def get_or_none(self) -> Optional[T]:
        """Get an item from the queue without blocking.

        :returns: The next item, or ``None`` if the queue is empty.
        """
        try:
            return self.get_nowait()
        except queue.Empty:
            return None

    def put_circular(self, obj: T) -> None:
        """Put an item in the queue, removing oldest if full.

        :param obj: The item to add to the queue.
        """
        while True:
            try:
                self.put_nowait(obj)
                break
            except queue.Full:
                self.get_nowait()
