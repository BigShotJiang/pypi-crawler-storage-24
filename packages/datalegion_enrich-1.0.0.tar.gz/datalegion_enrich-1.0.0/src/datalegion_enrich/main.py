"""Main CLI entry point — assembles all sub-commands."""

from __future__ import annotations

from typing import Annotated

import typer
from loguru import logger

from datalegion_enrich import __version__
from datalegion_enrich.async_typer import async_command
from datalegion_enrich.commands import company, credits, person, utility
from datalegion_enrich.config import load_config, save_config
from datalegion_enrich.logging import setup_logging
from datalegion_enrich.output import emit_json
from datalegion_enrich.update import check_for_update, self_update

app = typer.Typer(
    name="datalegion-enrich-cli",
    help="Data Legion Enrichment CLI — enrich person and company data at scale.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

# ── Register sub-command groups ──────────────────────────────────────

app.add_typer(person.app, name="person")
app.add_typer(company.app, name="company")
app.add_typer(utility.app, name="utility")
app.add_typer(credits.app, name="credits")

# ── Global callback for shared flags ────────────────────────────────


@app.callback()
def main_callback(
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Enable debug logging.")] = False,
    quiet: Annotated[bool, typer.Option("--quiet", "-q", help="Suppress all log output.")] = False,
) -> None:
    """Data Legion Enrichment CLI."""
    setup_logging(verbose=verbose, quiet=quiet)


# ── Top-level commands ───────────────────────────────────────────────


@app.command()
@async_command
async def version() -> None:
    """Show the CLI version."""
    emit_json({"version": __version__})


@app.command()
@async_command
async def config(
    action: Annotated[str, typer.Argument(help="Action: get, set, list, path.")],
    key: Annotated[str | None, typer.Argument(help="Config key.")] = None,
    value: Annotated[str | None, typer.Argument(help="Config value.")] = None,
) -> None:
    """Manage CLI configuration.

    Examples:
        datalegion-enrich-cli config set api_key legion_abc123...
        datalegion-enrich-cli config set api_base_url https://api.datalegion.ai
        datalegion-enrich-cli config get api_key
        datalegion-enrich-cli config list
        datalegion-enrich-cli config path
    """
    cfg = load_config()

    if action == "path":
        from datalegion_enrich.config import CONFIG_FILE

        emit_json({"path": str(CONFIG_FILE)})
        return

    if action == "list":
        # Mask the API key for display
        display = dict(cfg)
        if display.get("api_key"):
            k = str(display["api_key"])
            display["api_key"] = k[:10] + "..." + k[-4:] if len(k) > 14 else "***"
        emit_json(display)
        return

    if action == "get":
        if not key:
            raise typer.BadParameter("Key is required for 'get'.")
        val = cfg.get(key)
        if val is None:
            raise typer.BadParameter(f"Unknown key: {key}")
        emit_json({key: val})
        return

    if action == "set":
        if not key or value is None:
            raise typer.BadParameter("Both key and value required for 'set'.")
        # Type coercion for booleans
        if value.lower() in ("true", "1", "yes"):
            cfg[key] = True
        elif value.lower() in ("false", "0", "no"):
            cfg[key] = False
        else:
            cfg[key] = value
        save_config(cfg)
        logger.info("Set {} = {}", key, cfg[key])
        emit_json({"ok": True, "key": key, "value": cfg[key]})
        return

    raise typer.BadParameter(f"Unknown action: {action}. Use get, set, list, or path.")


@app.command()
@async_command
async def update(
    check: Annotated[bool, typer.Option("--check", help="Only check, don't install.")] = False,
) -> None:
    """Check for updates and optionally self-update."""
    new_version = await check_for_update()
    if new_version:
        emit_json({"update_available": True, "current": __version__, "latest": new_version})
        if not check:
            await self_update(new_version)
    else:
        emit_json({"update_available": False, "current": __version__})


def run() -> None:
    """CLI entry point — called by the console script."""
    from datalegion_enrich.async_typer import run as async_run

    async_run(app)
