"""Data Legion Enrichment CLI."""

__version__ = "0.1.0"
