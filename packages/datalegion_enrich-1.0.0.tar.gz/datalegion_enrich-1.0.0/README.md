# datalegion-enrich-cli

A fully async CLI for the Data Legion Enrichment API. Designed to be used by both humans and AI agents.

Enrich person and company data at scale — look up contacts by email, phone, name, or social URL; search with SQL syntax.

## Features

- **Fully async** — async from entry point to HTTP client, powered by `asyncio` and `httpx`
- **Agent-friendly** — all output is JSON to stdout, logs go to stderr, supports `--stdin` for piping
- **Encrypted config** — API keys are stored encrypted at rest (Fernet + PBKDF2, machine-tied)
- **Auto-update** — checks GitHub releases and self-updates via Homebrew, GitHub release, git pull, or pip/uv
- **Multiple install methods** — Homebrew, GitHub release, pip/uv (with private index support), or from source

## Installation

### Homebrew

```bash
brew install datalegion/tap/datalegion-enrich-cli
```

### From PyPI (or private index)

```bash
uv pip install datalegion-enrich-cli
```

Or with pip:

```bash
pip install datalegion-enrich-cli
```

To install from a private index:

```bash
uv pip install datalegion-enrich-cli --extra-index-url https://your-private-index.com/simple
```

### From GitHub release

Download the `.whl` from the [latest release](https://github.com/datalegion/datalegion-enrich-cli/releases/latest) and install:

```bash
uv pip install datalegion_enrich-*.whl
```

### From source

```bash
git clone https://github.com/datalegion/datalegion-enrich-cli.git
cd datalegion-enrich-cli
uv sync
```

## Configuration

Set your API key (stored encrypted on disk):

```bash
datalegion-enrich-cli config set api_key legion_your_key_here
```

Or via environment variable (takes precedence over file config):

```bash
export LEGION_API_KEY=legion_your_key_here
```

### Other config options

```bash
# Set the API base URL
datalegion-enrich-cli config set api_base_url https://api.datalegion.ai

# Set install method for auto-update (brew, github, git, or pip)
datalegion-enrich-cli config set install_method brew

# View all config
datalegion-enrich-cli config list

# Show config file path
datalegion-enrich-cli config path
```

Config is stored at `~/.datalegion/config.toml`. Override the location with `LEGION_CONFIG_DIR`.

### Install method detection

The `update` command auto-detects how the CLI was installed:

| Method | Detection | Update strategy |
|--------|-----------|-----------------|
| `brew` | `brew list` finds the formula | `brew upgrade` |
| `github` | Set via config | Downloads `.whl` from GitHub release |
| `git` | `.git` directory in parent tree | `git pull --ff-only` + `uv sync` |
| `pip` | Default fallback | `uv pip install --upgrade` |

You can override detection by setting `install_method` in config. For pip installs from a private index, set the `LEGION_PIP_INDEX_URL` environment variable.

## Usage

### Person enrichment

```bash
# By email
datalegion-enrich-cli person enrich --email john@example.com

# By name + company
datalegion-enrich-cli person enrich --name "Jane Smith" --company "Acme Corp" --city "NYC"

# By LinkedIn
datalegion-enrich-cli person enrich --social-url "https://linkedin.com/in/johndoe"

# Multiple results with minimum confidence
datalegion-enrich-cli person enrich --email john@example.com --multiple --min-confidence high

# Select specific fields
datalegion-enrich-cli person enrich --email john@example.com --fields "full_name,emails,phones"
```

### Person search

```bash
# SQL-based search
datalegion-enrich-cli person search "SELECT * FROM people WHERE company_name ILIKE '%google%' AND state = 'CA'" --limit 5
```

### Company enrichment

```bash
# By domain
datalegion-enrich-cli company enrich --domain google.com

# By ticker symbol
datalegion-enrich-cli company enrich --ticker AAPL

# By name with industry context
datalegion-enrich-cli company enrich --name "Stripe" --industry "Financial Services"
```

### Company search

```bash
# SQL-based search
datalegion-enrich-cli company search "SELECT * FROM companies WHERE industry ILIKE '%software%' AND legion_employee_count > 100"
```

### Utility commands

```bash
# Clean and normalize fields
datalegion-enrich-cli utility clean '{"email": "John.Doe+tag@gmail.com", "phone": "(555) 123-4567"}'

# Hash an email for privacy-preserving lookups
datalegion-enrich-cli utility hash john@example.com

# Validate fields before enrichment
datalegion-enrich-cli utility validate --email "test@example.com" --phone "+15551234567"
```

### Credits

```bash
# Check balance
datalegion-enrich-cli credits balance

# View usage history
datalegion-enrich-cli credits usage --from 2026-01-01 --to 2026-03-01
```

### Other commands

```bash
# Check for updates
datalegion-enrich-cli update --check

# Self-update
datalegion-enrich-cli update

# Show version
datalegion-enrich-cli version
```

## Agent / automation usage

The CLI is designed to be called by AI agents and scripts. Key patterns:

```bash
# All output is JSON to stdout — parse it directly
datalegion-enrich-cli person enrich --email john@example.com | jq '.matches[0].full_name'

# Pipe JSON payloads via stdin
echo '{"email":"john@example.com","company":"Acme"}' | datalegion-enrich-cli person enrich --stdin

# Suppress logs with --quiet (only JSON on stdout)
datalegion-enrich-cli --quiet person enrich --email john@example.com

# Errors are also JSON
datalegion-enrich-cli person enrich --email bad 2>/dev/null
# {"ok": false, "error": "bad_request", "message": "..."}
```

## Global flags

| Flag | Description |
|------|-------------|
| `--verbose` / `-v` | Enable debug logging to stderr |
| `--quiet` / `-q` | Suppress all log output |
| `--help` | Show help for any command |

## Development

```bash
# Install dev dependencies
uv sync

# Run tests
uv run pytest

# Lint
uv run ruff check src/ tests/

# Build wheel
uv build
```

## License

MIT