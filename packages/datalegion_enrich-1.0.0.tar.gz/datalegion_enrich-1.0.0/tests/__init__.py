"""Tests for datalegion-enrich CLI."""
