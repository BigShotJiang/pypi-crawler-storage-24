"""Tests for auto-update functionality."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import httpx
import pytest

from datalegion_enrich.update import _detect_install_method, _run, check_for_update, self_update


@pytest.mark.asyncio
class TestCheckForUpdate:
    async def test_newer_version_available(self):
        resp = httpx.Response(200, json={"tag_name": "v99.0.0"})
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("datalegion_enrich.update.httpx.AsyncClient", return_value=mock_client):
            result = await check_for_update(quiet=True)
        assert result == "99.0.0"

    async def test_already_latest(self):
        resp = httpx.Response(200, json={"tag_name": "v0.0.1"})
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("datalegion_enrich.update.httpx.AsyncClient", return_value=mock_client):
            result = await check_for_update(quiet=True)
        assert result is None

    async def test_github_returns_non_200(self):
        resp = httpx.Response(404, json={})
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("datalegion_enrich.update.httpx.AsyncClient", return_value=mock_client):
            result = await check_for_update(quiet=True)
        assert result is None

    async def test_network_error_returns_none(self):
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(side_effect=httpx.ConnectError("fail"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("datalegion_enrich.update.httpx.AsyncClient", return_value=mock_client):
            result = await check_for_update(quiet=True)
        assert result is None

    async def test_empty_tag_returns_none(self):
        resp = httpx.Response(200, json={"tag_name": ""})
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("datalegion_enrich.update.httpx.AsyncClient", return_value=mock_client):
            result = await check_for_update(quiet=True)
        assert result is None


@pytest.mark.asyncio
class TestRun:
    async def test_successful_command(self):
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"output", b""))
        mock_proc.returncode = 0

        with patch(
            "datalegion_enrich.update.asyncio.create_subprocess_exec", return_value=mock_proc
        ):
            await _run(["echo", "hello"])

    async def test_failed_command_raises(self):
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b"some error"))
        mock_proc.returncode = 1

        with (
            patch(
                "datalegion_enrich.update.asyncio.create_subprocess_exec", return_value=mock_proc
            ),
            pytest.raises(SystemExit),
        ):
            await _run(["false"])


@pytest.mark.asyncio
class TestDetectInstallMethod:
    async def test_config_override(self):
        with patch(
            "datalegion_enrich.config.load_config", return_value={"install_method": "github"}
        ):
            assert await _detect_install_method() == "github"

    async def test_detects_git_when_in_repo(self):
        # Running from a git clone, should detect "git"
        with (
            patch("datalegion_enrich.config.load_config", return_value={"install_method": ""}),
            patch("datalegion_enrich.update.shutil.which", return_value=None),
        ):
            assert await _detect_install_method() == "git"

    async def test_falls_back_to_pip(self, tmp_path):
        # Point __file__ to a path with no .git parent
        fake_file = tmp_path / "pkg" / "update.py"
        fake_file.parent.mkdir(parents=True)
        fake_file.touch()

        with (
            patch("datalegion_enrich.config.load_config", return_value={"install_method": ""}),
            patch("datalegion_enrich.update.shutil.which", return_value=None),
            patch("datalegion_enrich.update.__file__", str(fake_file)),
        ):
            assert await _detect_install_method() == "pip"


@pytest.mark.asyncio
class TestSelfUpdate:
    async def test_uses_uv_when_pip_method(self):
        with (
            patch("datalegion_enrich.update._detect_install_method", return_value="pip"),
            patch(
                "datalegion_enrich.update.shutil.which",
                side_effect=lambda x: "/usr/bin/uv" if x == "uv" else None,
            ),
            patch("datalegion_enrich.update._run", new_callable=AsyncMock) as mock_run,
            patch("datalegion_enrich.update.sys.exit"),
        ):
            await self_update("1.0.0")
            cmd = mock_run.call_args[0][0]
            assert cmd[0] == "/usr/bin/uv"
            assert "datalegion-enrich==1.0.0" in cmd

    async def test_falls_back_to_pip(self):
        def which(name):
            return "/usr/bin/pip" if name == "pip" else None

        with (
            patch("datalegion_enrich.update._detect_install_method", return_value="pip"),
            patch("datalegion_enrich.update.shutil.which", side_effect=which),
            patch("datalegion_enrich.update._run", new_callable=AsyncMock) as mock_run,
            patch("datalegion_enrich.update.sys.exit"),
        ):
            await self_update("2.0.0")
            cmd = mock_run.call_args[0][0]
            assert cmd[0] == "/usr/bin/pip"

    async def test_raises_when_no_installer(self):
        with (
            patch("datalegion_enrich.update._detect_install_method", return_value="pip"),
            patch("datalegion_enrich.update.shutil.which", return_value=None),
            pytest.raises(SystemExit),
        ):
            await self_update("1.0.0")

    async def test_brew_method(self):
        with (
            patch("datalegion_enrich.update._detect_install_method", return_value="brew"),
            patch("datalegion_enrich.update.shutil.which", return_value="/usr/local/bin/brew"),
            patch("datalegion_enrich.update._run", new_callable=AsyncMock) as mock_run,
            patch("datalegion_enrich.update.sys.exit"),
        ):
            await self_update()
            assert mock_run.call_count == 2
            assert "upgrade" in mock_run.call_args_list[1][0][0]
