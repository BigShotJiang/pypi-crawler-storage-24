"""Tests for event listener fallback behavior."""

import importlib.util
import sys
import unittest
from pathlib import Path

root = Path(__file__).parent.parent
sys.path.insert(0, str(root))

spec = importlib.util.spec_from_file_location(
    "event_listener", root / "dfcode_remote" / "lark_client" / "event_listener.py"
)
assert spec is not None and spec.loader is not None
mod = importlib.util.module_from_spec(spec)
sys.modules["event_listener"] = mod
spec.loader.exec_module(mod)

types_spec = importlib.util.spec_from_file_location(
    "df_types", root / "dfcode_remote" / "dfcode_client" / "types.py"
)
assert types_spec is not None and types_spec.loader is not None
types_mod = importlib.util.module_from_spec(types_spec)
sys.modules["df_types"] = types_mod
types_spec.loader.exec_module(types_mod)

PartInfo = types_mod.PartInfo
EventListener = mod.EventListener
CardServiceError = mod.CardServiceError
Persistence = importlib.import_module("dfcode_remote.utils.persistence").Persistence


class FakeClient:
    def __init__(self):
        self.messages = []

    async def get_messages(self, session_id):
        return self.messages


class FakeCardService:
    def __init__(self):
        self.direct = []
        self.text = []

    async def create_card(self, content):
        raise CardServiceError("cardkit unavailable")

    async def send_card(self, chat_id, card_id):
        raise AssertionError("send_card should not be reached")

    async def send_card_direct(self, chat_id, content):
        self.direct.append((chat_id, content))
        return "msg-direct"

    async def send_text(self, chat_id, text):
        self.text.append((chat_id, text))
        return "msg-text"


class FakePersistence:
    def __init__(self):
        self.data = {"chat-1": "ses-1"}

    def list_bindings(self):
        return self.data


class TestEventListenerFallback(unittest.IsolatedAsyncioTestCase):
    async def test_falls_back_to_direct_card_when_cardkit_create_fails(self):
        listener = EventListener(
            "http://localhost:4096",
            FakeClient(),
            FakeCardService(),
            FakePersistence(),
        )
        state = listener._get_or_create_state("ses-1")
        assert state is not None
        state.parts.append(PartInfo(type="text", text="hello"))

        await listener._flush_update(state)

        self.assertTrue(state.direct_mode)
        self.assertEqual(state.last_card_digest != "", True)
        self.assertIsNone(state.message_id)
        self.assertEqual(state.card_id, None)

    async def test_ignores_non_rendering_session_events(self):
        listener = EventListener(
            "http://localhost:4096",
            FakeClient(),
            FakeCardService(),
            FakePersistence(),
        )

        class Evt:
            def __init__(self, t, props):
                self.type = t
                self.properties = props

        await listener._dispatch(Evt("session.diff", {"sessionID": "ses-1"}))
        self.assertNotIn("ses-1", listener._states)

    async def test_upsert_part_replaces_same_part_id(self):
        listener = EventListener(
            "http://localhost:4096",
            FakeClient(),
            FakeCardService(),
            FakePersistence(),
        )
        state = listener._get_or_create_state("ses-1")
        assert state is not None

        state.upsert_part(PartInfo(type="text", id="part-1", text="hello"))
        state.upsert_part(PartInfo(type="text", id="part-1", text="hello world"))

        self.assertEqual(len(state.parts), 1)
        self.assertEqual(state.parts[0].text, "hello world")

    async def test_final_card_uses_latest_assistant_text_only(self):
        client = FakeClient()
        client.messages = [
            types_mod.MessageInfo(
                id="msg-1",
                sessionID="ses-1",
                role="assistant",
                parts=[
                    PartInfo(type="tool", callID="c1", tool="bash"),
                    PartInfo(type="text", text="final answer"),
                ],
            )
        ]
        card = FakeCardService()
        listener = EventListener(
            "http://localhost:4096", client, card, FakePersistence()
        )
        state = listener._get_or_create_state("ses-1")
        assert state is not None
        state.direct_mode = True
        state.parts = [
            PartInfo(type="tool", callID="c1", tool="bash"),
            PartInfo(type="text", text="stream chunk 1"),
            PartInfo(type="text", text="stream chunk 2"),
        ]

        await listener._send_final_card(state)

        self.assertEqual(len(card.direct), 1)
        content = str(card.direct[0][1])
        self.assertIn("final answer", content)
        self.assertNotIn("stream chunk 1", content)
        self.assertNotIn("bash", content)


if __name__ == "__main__":
    unittest.main()
