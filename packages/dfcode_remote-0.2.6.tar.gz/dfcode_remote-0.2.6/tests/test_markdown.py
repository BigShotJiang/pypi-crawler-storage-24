"""Tests for markdown utility module."""

import unittest
from dfcode_remote.utils.markdown import (
    markdown_to_lark,
    truncate_output,
    format_tool_output,
)


class TestMarkdownToLark(unittest.TestCase):
    """Tests for markdown_to_lark function."""

    def test_plain_text_preserved(self):
        """Plain text should be preserved."""
        text = "Hello world"
        result = markdown_to_lark(text)
        self.assertEqual(result, text)

    def test_bold_preserved(self):
        """Bold markdown should be preserved."""
        text = "**bold**"
        result = markdown_to_lark(text)
        self.assertEqual(result, text)

    def test_italic_preserved(self):
        """Italic markdown should be preserved."""
        text = "*italic*"
        result = markdown_to_lark(text)
        self.assertEqual(result, text)

    def test_code_preserved(self):
        """Inline code should be preserved."""
        text = "`code`"
        result = markdown_to_lark(text)
        self.assertEqual(result, text)

    def test_link_preserved(self):
        """Links should be preserved."""
        text = "[link](http://example.com)"
        result = markdown_to_lark(text)
        self.assertEqual(result, text)

    def test_image_stripped_keeps_alt_text(self):
        """Images should be stripped but alt text kept."""
        text = "![alt text](http://example.com/image.png)"
        result = markdown_to_lark(text)
        self.assertEqual(result, "[alt text]")
        self.assertNotIn("http://example.com", result)

    def test_image_without_alt_stripped(self):
        """Images without alt text should be stripped to empty brackets."""
        text = "![](http://example.com/image.png)"
        result = markdown_to_lark(text)
        self.assertEqual(result, "[]")

    def test_multiple_images_stripped(self):
        """Multiple images should all be stripped."""
        text = "![a](x.png) text ![b](y.png)"
        result = markdown_to_lark(text)
        self.assertEqual(result, "[a] text [b]")

    def test_truncation_at_30000_chars(self):
        """Text over 30000 chars should be truncated."""
        text = "x" * 30001
        result = markdown_to_lark(text)
        self.assertLess(len(result), 30001)
        self.assertIn("(truncated)", result)

    def test_no_truncation_under_limit(self):
        """Text under 30000 chars should not be truncated."""
        text = "x" * 1000
        result = markdown_to_lark(text)
        self.assertEqual(result, text)
        self.assertNotIn("(truncated)", result)


class TestTruncateOutput(unittest.TestCase):
    """Tests for truncate_output function."""

    def test_short_text_unchanged(self):
        """Short text should be returned unchanged."""
        text = "Short text"
        result = truncate_output(text, max_chars=100)
        self.assertEqual(result, text)

    def test_long_text_truncated(self):
        """Long text should be truncated with marker."""
        text = "x" * 3000
        result = truncate_output(text, max_chars=2000)
        self.assertLess(len(result), 3000)
        self.assertIn("(truncated)", result)

    def test_truncation_keeps_head_and_tail(self):
        """Truncation should keep head and tail portions."""
        text = "A" * 1000 + "MIDDLE" + "B" * 1000
        result = truncate_output(text, max_chars=500)
        self.assertIn("A" * 100, result)
        self.assertIn("B" * 100, result)
        self.assertIn("(truncated)", result)

    def test_exact_limit_unchanged(self):
        """Text at exact limit should be unchanged."""
        text = "x" * 100
        result = truncate_output(text, max_chars=100)
        self.assertEqual(result, text)

    def test_one_char_over_truncated(self):
        """Text one char over limit should be truncated."""
        text = "x" * 101
        result = truncate_output(text, max_chars=100)
        self.assertIn("(truncated)", result)


class TestFormatToolOutput(unittest.TestCase):
    """Tests for format_tool_output function."""

    def test_empty_string_returns_empty(self):
        """Empty string should return empty."""
        result = format_tool_output("")
        self.assertEqual(result, "")

    def test_whitespace_only_returns_empty(self):
        """Whitespace-only string should return empty."""
        result = format_tool_output("   \n\t  ")
        self.assertEqual(result, "")

    def test_strips_whitespace(self):
        """Output should strip leading/trailing whitespace."""
        result = format_tool_output("  hello  ")
        self.assertIn("hello", result)
        self.assertNotIn("  hello  ", result)

    def test_wraps_in_code_block(self):
        """Output should be wrapped in code block."""
        result = format_tool_output("output")
        self.assertTrue(result.startswith("```"))
        self.assertTrue(result.endswith("```"))

    def test_truncates_long_output(self):
        """Long output should be truncated."""
        text = "x" * 1000
        result = format_tool_output(text, max_chars=100)
        self.assertIn("(truncated)", result)

    def test_short_output_not_truncated(self):
        """Short output should not be truncated."""
        text = "short"
        result = format_tool_output(text, max_chars=100)
        self.assertNotIn("(truncated)", result)


if __name__ == "__main__":
    unittest.main()
