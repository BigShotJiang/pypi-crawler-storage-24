"""Tests for mobile-friendly session UX in handler."""

import importlib.util
import importlib.abc
import sys
import types
import unittest
from pathlib import Path
from typing import cast


class _DummyMessageEvent:
    pass


class _DummyCardEvent:
    pass


class _DummyCardActionResponse:
    pass


lark_mod = types.ModuleType("lark_oapi")
im_mod = types.ModuleType("lark_oapi.api.im.v1.model.p2_im_message_receive_v1")
card_mod = types.ModuleType("lark_oapi.event.callback.model.p2_card_action_trigger")
setattr(im_mod, "P2ImMessageReceiveV1", _DummyMessageEvent)
setattr(card_mod, "P2CardActionTrigger", _DummyCardEvent)
setattr(card_mod, "P2CardActionTriggerResponse", _DummyCardActionResponse)
sys.modules["lark_oapi"] = lark_mod
sys.modules["lark_oapi.api.im.v1.model.p2_im_message_receive_v1"] = im_mod
sys.modules["lark_oapi.event.callback.model.p2_card_action_trigger"] = card_mod

root = Path(__file__).parent.parent
sys.path.insert(0, str(root))

spec = importlib.util.spec_from_file_location(
    "handler", root / "dfcode_remote" / "lark_client" / "handler.py"
)
assert spec is not None and spec.loader is not None
handler_mod = importlib.util.module_from_spec(spec)
sys.modules["handler"] = handler_mod
cast(importlib.abc.Loader, spec.loader).exec_module(handler_mod)

types_spec = importlib.util.spec_from_file_location(
    "df_types", root / "dfcode_remote" / "dfcode_client" / "types.py"
)
assert types_spec is not None and types_spec.loader is not None
types_mod = importlib.util.module_from_spec(types_spec)
sys.modules["df_types"] = types_mod
cast(importlib.abc.Loader, types_spec.loader).exec_module(types_mod)
SessionInfo = types_mod.SessionInfo
SessionStatus = types_mod.SessionStatus
ActiveSessionInfo = types_mod.ActiveSessionInfo
Handler = handler_mod.Handler


class FakeConfig:
    allowed_users = []


class FakeClient:
    def __init__(self):
        self.sessions = [
            ActiveSessionInfo(
                id="ses_alpha_full_123456",
                title="Project A",
                directory="/repo/a",
                projectRoot="/repo",
                projectID="proj-a",
                status=SessionStatus(type="busy"),
                activity={"updated": 100, "source": "status", "summary": "Running now"},
                attachable=True,
                continueable=True,
                rank=2,
            ),
            ActiveSessionInfo(
                id="ses_beta_full_654321",
                title="Project B",
                directory="/repo/b",
                projectRoot="/repo",
                projectID="proj-b",
                status=SessionStatus(type="idle"),
                activity={
                    "updated": 90,
                    "source": "message",
                    "summary": "Awaiting assistant response",
                },
                attachable=True,
                continueable=True,
                rank=1,
            ),
        ]
        self.got = []
        self.prompts = []
        self.project_prompts = []
        self.created = SessionInfo(
            id="ses_created_full_abcdef", title="New Session", directory="/repo/new"
        )

    async def list_active_sessions(self):
        return self.sessions

    async def get_session(self, session_id):
        self.got.append(session_id)
        for item in self.sessions:
            if item.id == session_id:
                return SessionInfo(
                    id=item.id, title=item.title, directory=item.directory
                )
        raise AssertionError(f"unknown session lookup: {session_id}")

    async def get_active_session(self, session_id):
        self.got.append(session_id)
        for item in self.sessions:
            if item.id == session_id:
                return item
        raise AssertionError(f"unknown active session lookup: {session_id}")

    async def prompt_active_async(self, session_id, text):
        self.prompts.append((session_id, text))

    async def prompt_async_in_project(self, session_id, text, project_root):
        self.project_prompts.append((session_id, text, project_root))

    async def create_session(self, title=None):
        return self.created


class FakeCardService:
    def __init__(self):
        self.texts = []
        self.cards = []

    async def send_text(self, chat_id, text):
        self.texts.append((chat_id, text))
        return "msg-text"

    async def send_card_direct(self, chat_id, content):
        self.cards.append((chat_id, content))
        return "msg-card"

    async def create_card(self, content):
        return "card-id"

    async def send_card(self, chat_id, card_id):
        return "msg-cardkit"

    async def update_card(self, card_id, sequence, content):
        return True


class FakePersistence:
    def __init__(self):
        self.data = {}

    def get_binding(self, chat_id):
        return self.data.get(chat_id)

    def set_binding(self, chat_id, session_id):
        self.data[chat_id] = session_id

    def remove_binding(self, chat_id):
        self.data.pop(chat_id, None)


class TestHandlerSessionUx(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.client = FakeClient()
        self.card = FakeCardService()
        self.persistence = FakePersistence()
        self.handler = Handler(FakeConfig(), self.client, self.card, self.persistence)

    async def test_list_card_includes_index_full_id_directory_and_status(self):
        await self.handler._cmd_list("chat-1")
        self.assertEqual(len(self.card.cards), 1)
        body = str(self.card.cards[0][1])
        self.assertIn("1.", body)
        self.assertIn("2.", body)
        self.assertIn("ses_alpha_full_123456", body)
        self.assertIn("project: /repo", body)
        self.assertIn("dir: /repo/a", body)
        self.assertIn("busy", body)
        self.assertIn("Running now", body)

    async def test_attach_by_index_binds_first_session(self):
        await self.handler._cmd_attach("chat-1", "1")
        self.assertEqual(
            self.persistence.get_binding("chat-1"), "ses_alpha_full_123456"
        )
        self.assertEqual(self.client.got, [])

    async def test_new_returns_full_id_not_short_prefix(self):
        await self.handler._cmd_new("chat-1", "New Session")
        self.assertEqual(
            self.persistence.get_binding("chat-1"), "ses_created_full_abcdef"
        )
        self.assertTrue(self.card.texts)
        text = self.card.texts[-1][1]
        self.assertIn("ses_created_full_abcdef", text)
        self.assertIn("/repo/new", text)

    async def test_handle_prompt_uses_session_endpoint_with_project_context(self):
        self.persistence.set_binding("chat-1", "ses_beta_full_654321")
        await self.handler._handle_prompt("chat-1", "hello")
        self.assertEqual(
            self.client.project_prompts,
            [("ses_beta_full_654321", "hello", "/repo")],
        )
