import unittest

from dfcode_remote.lark_client.card_service import (
    _normalize_card_tags,
    _scan_legacy_tags,
)


class TestCardServiceNormalize(unittest.TestCase):
    def test_normalize_action_and_note_tags(self):
        card = {
            "schema": "2.0",
            "body": {
                "elements": [
                    {
                        "tag": "note",
                        "elements": [{"tag": "plain_text", "content": "done"}],
                    },
                    {
                        "tag": "action",
                        "actions": [
                            {
                                "tag": "button",
                                "text": {"tag": "plain_text", "content": "ok"},
                                "value": {"type": "x"},
                            }
                        ],
                    },
                ]
            },
        }

        hits = _scan_legacy_tags(card)
        self.assertTrue(hits)

        normalized = _normalize_card_tags(card)
        hits_after = _scan_legacy_tags(normalized)
        self.assertEqual(hits_after, [])

        elements = normalized["body"]["elements"]
        self.assertEqual(elements[0]["tag"], "div")
        self.assertEqual(elements[1]["tag"], "column_set")


if __name__ == "__main__":
    unittest.main()
