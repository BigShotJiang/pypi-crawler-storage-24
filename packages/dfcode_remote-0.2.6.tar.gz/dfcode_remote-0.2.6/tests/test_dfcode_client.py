"""Tests for dfcode_client.client."""

import json
import unittest

import httpx

from dfcode_remote.dfcode_client.client import DfcodeAPIError, DfcodeClient


class TestDfcodeClient(unittest.IsolatedAsyncioTestCase):
    async def test_list_active_sessions_requests_expected_endpoint(self):
        seen = {}

        def handler(request: httpx.Request) -> httpx.Response:
            seen["method"] = request.method
            seen["path"] = request.url.path
            return httpx.Response(
                200,
                json=[
                    {
                        "id": "ses-1",
                        "title": "Active",
                        "directory": "/repo/a",
                        "projectID": "proj-a",
                        "status": {"type": "busy"},
                        "activity": {
                            "updated": 1,
                            "source": "status",
                            "summary": "Running",
                        },
                        "attachable": True,
                        "continueable": True,
                        "rank": 2,
                    }
                ],
            )

        client = DfcodeClient("http://localhost:4096")
        await client._client.aclose()
        client._client = httpx.AsyncClient(
            base_url=client.base_url,
            transport=httpx.MockTransport(handler),
        )

        items = await client.list_active_sessions()
        self.assertEqual(seen["method"], "GET")
        self.assertEqual(seen["path"], "/session/active")
        self.assertEqual(items[0].id, "ses-1")
        self.assertEqual(items[0].status.type, "busy")
        await client.close()

    async def test_list_active_sessions_raises_api_error(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, text=json.dumps({"error": "boom"}))

        client = DfcodeClient("http://localhost:4096")
        await client._client.aclose()
        client._client = httpx.AsyncClient(
            base_url=client.base_url,
            transport=httpx.MockTransport(handler),
        )

        with self.assertRaises(DfcodeAPIError):
            await client.list_active_sessions()

        await client.close()

    async def test_get_active_session_requests_expected_endpoint(self):
        seen = {}

        def handler(request: httpx.Request) -> httpx.Response:
            seen["path"] = request.url.path
            return httpx.Response(200, json={"id": "ses-1", "projectRoot": "/repo/a"})

        client = DfcodeClient("http://localhost:4096")
        await client._client.aclose()
        client._client = httpx.AsyncClient(
            base_url=client.base_url,
            transport=httpx.MockTransport(handler),
        )

        item = await client.get_active_session("ses-1")
        self.assertEqual(seen["path"], "/session/active/ses-1")
        self.assertEqual(item.id, "ses-1")
        await client.close()

    async def test_prompt_active_async_requests_expected_endpoint(self):
        seen = {}

        def handler(request: httpx.Request) -> httpx.Response:
            seen["path"] = request.url.path
            seen["body"] = request.content.decode()
            return httpx.Response(204)

        client = DfcodeClient("http://localhost:4096")
        await client._client.aclose()
        client._client = httpx.AsyncClient(
            base_url=client.base_url,
            transport=httpx.MockTransport(handler),
        )

        await client.prompt_active_async("ses-1", "hello")
        self.assertEqual(seen["path"], "/session/active/ses-1/prompt_async")
        self.assertIn("hello", seen["body"])
        await client.close()

    async def test_prompt_async_in_project_uses_session_endpoint_and_header(self):
        seen = {}

        def handler(request: httpx.Request) -> httpx.Response:
            seen["path"] = request.url.path
            seen["body"] = request.content.decode()
            seen["dir"] = request.headers.get("x-dfcode-directory")
            return httpx.Response(204)

        client = DfcodeClient("http://localhost:4096")
        await client._client.aclose()
        client._client = httpx.AsyncClient(
            base_url=client.base_url,
            transport=httpx.MockTransport(handler),
        )

        await client.prompt_async_in_project("ses-1", "hello", "/repo/a")
        self.assertEqual(seen["path"], "/session/ses-1/prompt_async")
        self.assertIn("hello", seen["body"])
        self.assertEqual(seen["dir"], "/repo/a")
        await client.close()


if __name__ == "__main__":
    unittest.main()
