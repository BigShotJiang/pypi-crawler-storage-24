"""Tests for types module dataclasses."""

import unittest
from dfcode_remote.dfcode_client.types import (
    ActiveSessionInfo,
    SessionInfo,
    SessionStatus,
    PartInfo,
    MessageInfo,
    PermissionRequest,
    QuestionRequest,
    SSEEvent,
)


class TestPartInfo(unittest.TestCase):
    """Tests for PartInfo dataclass."""

    def test_from_dict_text_type(self):
        """Test parsing text type part."""
        data = {
            "type": "text",
            "text": "Hello world",
            "time": {"created": 123},
            "sessionID": "ses-1",
            "messageID": "msg-1",
        }
        part = PartInfo.from_dict(data)
        self.assertEqual(part.type, "text")
        self.assertEqual(part.id, None)
        self.assertEqual(part.text, "Hello world")
        self.assertEqual(part.time, {"created": 123})
        self.assertEqual(part.sessionID, "ses-1")
        self.assertEqual(part.messageID, "msg-1")

    def test_from_dict_preserves_part_id(self):
        data = {
            "id": "part-1",
            "type": "text",
            "text": "Hello world",
            "sessionID": "ses-1",
            "messageID": "msg-1",
        }
        part = PartInfo.from_dict(data)
        self.assertEqual(part.id, "part-1")

    def test_from_dict_tool_type_running(self):
        """Test parsing tool type part with running status."""
        data = {
            "type": "tool",
            "callID": "call-1",
            "tool": "bash",
            "state": {"status": "running"},
            "time": {"created": 123},
            "sessionID": "ses-1",
            "messageID": "msg-1",
        }
        part = PartInfo.from_dict(data)
        self.assertEqual(part.type, "tool")
        self.assertEqual(part.callID, "call-1")
        self.assertEqual(part.tool, "bash")
        self.assertEqual(part.state, {"status": "running"})
        self.assertEqual(part.sessionID, "ses-1")
        self.assertEqual(part.messageID, "msg-1")

    def test_from_dict_tool_type_completed(self):
        """Test parsing tool type part with completed status."""
        data = {
            "type": "tool",
            "callID": "call-1",
            "tool": "read_file",
            "state": {"status": "completed", "output": "file content"},
        }
        part = PartInfo.from_dict(data)
        self.assertIsNotNone(part.state)
        state = part.state or {}
        self.assertEqual(state["status"], "completed")
        self.assertEqual(state["output"], "file content")

    def test_from_dict_step_finish_type(self):
        """Test parsing step-finish type part."""
        data = {
            "type": "step-finish",
            "cost": {"total": 0.001},
            "tokens": {"input": 100, "output": 50},
            "time": {"created": 123},
        }
        part = PartInfo.from_dict(data)
        self.assertEqual(part.type, "step-finish")
        self.assertEqual(part.cost, {"total": 0.001})
        self.assertEqual(part.tokens, {"input": 100, "output": 50})

    def test_from_dict_reasoning_type(self):
        """Test parsing reasoning type part."""
        data = {"type": "reasoning", "text": "Thinking...", "time": {"created": 123}}
        part = PartInfo.from_dict(data)
        self.assertEqual(part.type, "reasoning")
        self.assertEqual(part.text, "Thinking...")

    def test_from_dict_unknown_type(self):
        """Test parsing unknown type stores raw data."""
        data = {
            "type": "unknown",
            "custom": "value",
            "sessionID": "ses-2",
            "messageID": "msg-2",
        }
        part = PartInfo.from_dict(data)
        self.assertEqual(part.type, "unknown")
        self.assertEqual(part.raw, data)
        self.assertEqual(part.sessionID, "ses-2")
        self.assertEqual(part.messageID, "msg-2")

    def test_direct_construction(self):
        """Test direct dataclass construction."""
        part = PartInfo(type="text", text="Direct")
        self.assertEqual(part.type, "text")
        self.assertEqual(part.text, "Direct")


class TestSessionInfo(unittest.TestCase):
    """Tests for SessionInfo dataclass."""

    def test_from_dict_full(self):
        """Test parsing full session info."""
        data = {
            "id": "sess-123",
            "title": "Test Session",
            "directory": "/home/user/project",
            "parentID": "parent-456",
            "time": {"created": 123, "updated": 456},
        }
        session = SessionInfo.from_dict(data)
        self.assertEqual(session.id, "sess-123")
        self.assertEqual(session.title, "Test Session")
        self.assertEqual(session.directory, "/home/user/project")
        self.assertEqual(session.parentID, "parent-456")
        self.assertEqual(session.time, {"created": 123, "updated": 456})

    def test_from_dict_minimal(self):
        """Test parsing minimal session info."""
        data = {"id": "sess-123"}
        session = SessionInfo.from_dict(data)
        self.assertEqual(session.id, "sess-123")
        self.assertEqual(session.title, "")
        self.assertEqual(session.directory, "")
        self.assertIsNone(session.parentID)


class TestSessionStatus(unittest.TestCase):
    """Tests for SessionStatus dataclass."""

    def test_from_dict_idle(self):
        """Test parsing idle status."""
        data = {"type": "idle"}
        status = SessionStatus.from_dict(data)
        self.assertEqual(status.type, "idle")


class TestActiveSessionInfo(unittest.TestCase):
    """Tests for ActiveSessionInfo dataclass."""

    def test_from_dict_full(self):
        data = {
            "id": "ses-123",
            "title": "Active Session",
            "directory": "/repo/a",
            "projectRoot": "/repo",
            "projectID": "proj-a",
            "parentID": "parent-1",
            "time": {"created": 1, "updated": 2},
            "status": {"type": "busy"},
            "activity": {"updated": 3, "source": "status", "summary": "Running now"},
            "attachable": True,
            "continueable": True,
            "rank": 2,
        }
        item = ActiveSessionInfo.from_dict(data)
        self.assertEqual(item.id, "ses-123")
        self.assertEqual(item.directory, "/repo/a")
        self.assertEqual(item.projectRoot, "/repo")
        self.assertEqual(item.status.type, "busy")
        self.assertIsNotNone(item.activity)
        activity = item.activity or {}
        self.assertEqual(activity["summary"], "Running now")
        self.assertTrue(item.attachable)
        self.assertEqual(item.rank, 2)

    def test_from_dict_minimal(self):
        item = ActiveSessionInfo.from_dict({"id": "ses-1"})
        self.assertEqual(item.id, "ses-1")
        self.assertEqual(item.title, "")
        self.assertEqual(item.directory, "")
        self.assertEqual(item.projectRoot, "")
        self.assertEqual(item.projectID, "")
        self.assertEqual(item.status.type, "idle")
        self.assertEqual(item.activity, {})
        self.assertFalse(item.attachable)
        self.assertFalse(item.continueable)
        self.assertEqual(item.rank, 0)

    def test_from_dict_busy(self):
        """Test parsing busy status."""
        data = {"type": "busy"}
        status = SessionStatus.from_dict(data)
        self.assertEqual(status.type, "busy")

    def test_from_dict_empty_defaults_to_idle(self):
        """Test empty dict defaults to idle."""
        data = {}
        status = SessionStatus.from_dict(data)
        self.assertEqual(status.type, "idle")


class TestMessageInfo(unittest.TestCase):
    """Tests for MessageInfo dataclass."""

    def test_from_dict_with_parts(self):
        """Test parsing message with parts."""
        data = {
            "id": "msg-1",
            "sessionID": "sess-1",
            "role": "assistant",
            "parts": [
                {"type": "text", "text": "Hello"},
                {"type": "tool", "tool": "bash", "callID": "c1"},
            ],
        }
        msg = MessageInfo.from_dict(data)
        self.assertEqual(msg.id, "msg-1")
        self.assertEqual(msg.sessionID, "sess-1")
        self.assertEqual(msg.role, "assistant")
        self.assertEqual(len(msg.parts), 2)
        self.assertEqual(msg.parts[0].type, "text")
        self.assertEqual(msg.parts[1].type, "tool")

    def test_from_dict_with_nested_info_shape(self):
        data = {
            "info": {
                "id": "msg-2",
                "sessionID": "sess-2",
                "role": "assistant",
            },
            "parts": [
                {"id": "part-1", "type": "text", "text": "hello"},
            ],
        }
        msg = MessageInfo.from_dict(data)
        self.assertEqual(msg.id, "msg-2")
        self.assertEqual(msg.sessionID, "sess-2")
        self.assertEqual(msg.role, "assistant")
        self.assertEqual(len(msg.parts), 1)
        self.assertEqual(msg.parts[0].text, "hello")

    def test_from_dict_no_parts(self):
        """Test parsing message without parts."""
        data = {"id": "msg-1", "sessionID": "sess-1", "role": "user"}
        msg = MessageInfo.from_dict(data)
        self.assertEqual(len(msg.parts), 0)


class TestPermissionRequest(unittest.TestCase):
    """Tests for PermissionRequest dataclass."""

    def test_from_dict_full(self):
        """Test parsing full permission request."""
        data = {
            "id": "perm-1",
            "sessionID": "sess-1",
            "permission": "write_file",
            "patterns": ["/path/to/file"],
            "metadata": {"tool": "bash"},
            "tool": "bash",
        }
        perm = PermissionRequest.from_dict(data)
        self.assertEqual(perm.id, "perm-1")
        self.assertEqual(perm.sessionID, "sess-1")
        self.assertEqual(perm.permission, "write_file")
        self.assertEqual(perm.patterns, ["/path/to/file"])
        self.assertEqual(perm.metadata, {"tool": "bash"})
        self.assertEqual(perm.tool, "bash")

    def test_from_dict_minimal(self):
        """Test parsing minimal permission request."""
        data = {"id": "perm-1"}
        perm = PermissionRequest.from_dict(data)
        self.assertEqual(perm.id, "perm-1")
        self.assertEqual(perm.sessionID, "")
        self.assertEqual(perm.permission, "")
        self.assertEqual(perm.patterns, [])
        self.assertEqual(perm.metadata, {})
        self.assertIsNone(perm.tool)


class TestQuestionRequest(unittest.TestCase):
    """Tests for QuestionRequest dataclass."""

    def test_from_dict_full(self):
        """Test parsing full question request."""
        data = {
            "id": "q-1",
            "sessionID": "sess-1",
            "questions": [
                {"question": "Continue?", "options": ["Yes", "No"]},
            ],
        }
        q = QuestionRequest.from_dict(data)
        self.assertEqual(q.id, "q-1")
        self.assertEqual(q.sessionID, "sess-1")
        self.assertEqual(len(q.questions), 1)
        self.assertEqual(q.questions[0]["question"], "Continue?")

    def test_from_dict_minimal(self):
        """Test parsing minimal question request."""
        data = {"id": "q-1"}
        q = QuestionRequest.from_dict(data)
        self.assertEqual(q.id, "q-1")
        self.assertEqual(q.sessionID, "")
        self.assertEqual(q.questions, [])


class TestSSEEvent(unittest.TestCase):
    """Tests for SSEEvent dataclass."""

    def test_from_dict_full(self):
        """Test parsing full SSE event."""
        data = {
            "type": "message.part.updated",
            "properties": {"sessionID": "sess-1", "part": {"type": "text"}},
        }
        event = SSEEvent.from_dict(data)
        self.assertEqual(event.type, "message.part.updated")
        self.assertEqual(event.properties["sessionID"], "sess-1")

    def test_from_dict_minimal(self):
        """Test parsing minimal SSE event."""
        data = {}
        event = SSEEvent.from_dict(data)
        self.assertEqual(event.type, "")
        self.assertEqual(event.properties, {})

    def test_from_dict_server_connected(self):
        """Test parsing server.connected event."""
        data = {"type": "server.connected"}
        event = SSEEvent.from_dict(data)
        self.assertEqual(event.type, "server.connected")

    def test_from_dict_permission_asked(self):
        """Test parsing permission.asked event."""
        data = {
            "type": "permission.asked",
            "properties": {
                "id": "perm-1",
                "sessionID": "sess-1",
                "permission": "write_file",
            },
        }
        event = SSEEvent.from_dict(data)
        self.assertEqual(event.type, "permission.asked")
        self.assertEqual(event.properties["id"], "perm-1")


if __name__ == "__main__":
    unittest.main()
