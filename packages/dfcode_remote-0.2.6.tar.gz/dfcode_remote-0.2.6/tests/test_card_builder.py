"""Tests for card_builder module."""

import importlib.util
import sys
import unittest
from pathlib import Path

# Import card_builder directly without going through lark_client/__init__.py
# This avoids importing bot.py which requires lark_oapi
spec = importlib.util.spec_from_file_location(
    "card_builder",
    Path(__file__).parent.parent / "dfcode_remote" / "lark_client" / "card_builder.py",
)
card_builder = importlib.util.module_from_spec(spec)
sys.modules["card_builder"] = card_builder
spec.loader.exec_module(card_builder)

# Now import the things we need from it
MAX_CARD_BLOCKS = card_builder.MAX_CARD_BLOCKS
ACTION_TYPE_PERMISSION = card_builder.ACTION_TYPE_PERMISSION
ACTION_TYPE_QUESTION = card_builder.ACTION_TYPE_QUESTION
build_streaming_card = card_builder.build_streaming_card
build_frozen_card = card_builder.build_frozen_card
build_menu_card = card_builder.build_menu_card
build_command_response_card = card_builder.build_command_response_card
_permission_buttons = card_builder._permission_buttons
_question_buttons = card_builder._question_buttons

# Import PartInfo from dfcode_remote.dfcode_client.types
sys.path.insert(0, str(Path(__file__).parent.parent))
from dfcode_remote.dfcode_client.types import PartInfo


class TestBuildStreamingCard(unittest.TestCase):
    """Tests for build_streaming_card function."""

    def test_empty_parts_returns_waiting_message(self):
        """Empty parts should show waiting message."""
        card = build_streaming_card([])
        self.assertEqual(card["schema"], "2.0")
        self.assertIn("body", card)
        self.assertIn("header", card)
        elements = card["body"]["elements"]
        self.assertTrue(any("等待响应" in str(e) for e in elements))

    def test_text_part_renders_markdown(self):
        """Text parts should be rendered as markdown blocks."""
        parts = [PartInfo(type="text", text="Hello **world**")]
        card = build_streaming_card(parts)
        elements = card["body"]["elements"]
        md_blocks = [e for e in elements if e.get("tag") == "markdown"]
        self.assertTrue(len(md_blocks) > 0)

    def test_tool_part_renders_collapsible_panel(self):
        """Tool parts should render as collapsible panels."""
        parts = [
            PartInfo(
                type="tool",
                tool="bash",
                callID="call-1",
                state={"status": "running"},
            )
        ]
        card = build_streaming_card(parts)
        elements = card["body"]["elements"]
        panels = [e for e in elements if e.get("tag") == "collapsible_panel"]
        self.assertEqual(len(panels), 1)

    def test_completed_tool_shows_output(self):
        """Completed tool should show output in panel."""
        parts = [
            PartInfo(
                type="tool",
                tool="bash",
                callID="call-1",
                state={"status": "completed", "title": "Run tests", "output": "passed"},
            )
        ]
        card = build_streaming_card(parts)
        elements = card["body"]["elements"]
        panels = [e for e in elements if e.get("tag") == "collapsible_panel"]
        self.assertEqual(len(panels), 1)
        self.assertIn("bash", str(panels[0]))

    def test_step_finish_renders_note(self):
        """Step-finish parts should render as div with token info."""
        parts = [
            PartInfo(
                type="step-finish",
                tokens={"input": 100, "output": 50},
                cost={"total": 0.001},
            )
        ]
        card = build_streaming_card(parts)
        elements = card["body"]["elements"]
        notes = [e for e in elements if e.get("tag") == "div"]
        self.assertTrue(any("tokens" in str(n) for n in notes))

    def test_reasoning_part_renders_panel(self):
        """Reasoning parts should render as collapsible panel."""
        parts = [PartInfo(type="reasoning", text="Thinking about this...")]
        card = build_streaming_card(parts)
        elements = card["body"]["elements"]
        panels = [e for e in elements if e.get("tag") == "collapsible_panel"]
        self.assertEqual(len(panels), 1)
        self.assertIn("Reasoning", str(panels[0]))

    def test_busy_status_has_blue_header(self):
        """Busy status should have blue header template."""
        card = build_streaming_card([], status="busy")
        self.assertEqual(card["header"]["template"], "blue")

    def test_idle_status_has_green_header(self):
        """Idle status should have green header template."""
        card = build_streaming_card([], status="idle")
        self.assertEqual(card["header"]["template"], "green")

    def test_permission_adds_buttons(self):
        """Permission request should add permission buttons."""
        permission = {"id": "perm-1", "permission": "write_file", "tool": "bash"}
        card = build_streaming_card([], permission=permission, session_id="sess-1")
        elements = card["body"]["elements"]
        actions = [e for e in elements if e.get("tag") == "column_set"]
        self.assertTrue(len(actions) > 0)

    def test_question_adds_buttons(self):
        """Question request should add question buttons."""
        question = {
            "id": "q-1",
            "questions": [{"question": "Continue?", "options": ["Yes", "No"]}],
        }
        card = build_streaming_card([], question=question, session_id="sess-1")
        elements = card["body"]["elements"]
        actions = [e for e in elements if e.get("tag") == "column_set"]
        self.assertTrue(len(actions) > 0)

    def test_busy_without_permission_has_abort_button(self):
        """Busy status without permission/question should have abort button."""
        card = build_streaming_card([], status="busy", session_id="sess-1")
        elements = card["body"]["elements"]
        actions = [e for e in elements if e.get("tag") == "column_set"]
        self.assertEqual(len(actions), 1)
        self.assertIn("中止", str(actions[0]))

    def test_max_card_blocks_trimming(self):
        """Content should be trimmed to MAX_CARD_BLOCKS - 5."""
        parts = [
            PartInfo(type="text", text=f"Line {i}") for i in range(MAX_CARD_BLOCKS)
        ]
        card = build_streaming_card(parts)
        elements = card["body"]["elements"]
        # Should be trimmed to MAX_CARD_BLOCKS - 5 (reserve space for status/interaction)
        md_blocks = [e for e in elements if e.get("tag") == "markdown"]
        self.assertLessEqual(len(md_blocks), MAX_CARD_BLOCKS - 5)


class TestBuildFrozenCard(unittest.TestCase):
    """Tests for build_frozen_card function."""

    def test_strips_interaction_areas(self):
        """Frozen card should not have abort/permission/question buttons."""
        parts = [PartInfo(type="text", text="Done")]
        card = build_frozen_card(parts)
        elements = card["body"]["elements"]
        actions = [e for e in elements if e.get("tag") == "column_set"]
        self.assertEqual(len(actions), 0)

    def test_has_green_header(self):
        """Frozen card should have green header."""
        card = build_frozen_card([])
        self.assertEqual(card["header"]["template"], "green")

    def test_empty_shows_placeholder(self):
        """Empty frozen card should show placeholder."""
        card = build_frozen_card([])
        elements = card["body"]["elements"]
        self.assertTrue(any("(empty)" in str(e) for e in elements))

    def test_has_completion_note(self):
        """Frozen card should have completion note text."""
        card = build_frozen_card([PartInfo(type="text", text="Done")])
        elements = card["body"]["elements"]
        notes = [e for e in elements if e.get("tag") == "div"]
        self.assertTrue(any("完成" in str(n) for n in notes))


class TestBuildMenuCard(unittest.TestCase):
    """Tests for build_menu_card function."""

    def test_returns_valid_card_structure(self):
        """Menu card should have valid schema."""
        card = build_menu_card()
        self.assertEqual(card["schema"], "2.0")
        self.assertIn("body", card)
        self.assertIn("header", card)

    def test_contains_default_commands(self):
        """Menu card should list default commands."""
        card = build_menu_card()
        content = str(card)
        self.assertIn("/new", content)
        self.assertIn("/attach", content)
        self.assertIn("/detach", content)
        self.assertIn("/menu", content)

    def test_custom_commands(self):
        """Menu card should accept custom commands."""
        custom = [{"cmd": "/custom", "desc": "Custom command"}]
        card = build_menu_card(custom)
        self.assertIn("/custom", str(card))


class TestBuildCommandResponseCard(unittest.TestCase):
    """Tests for build_command_response_card function."""

    def test_returns_valid_card_structure(self):
        """Command response card should have valid schema."""
        card = build_command_response_card("Title", "Content")
        self.assertEqual(card["schema"], "2.0")
        self.assertIn("body", card)
        self.assertIn("header", card)

    def test_uses_provided_title(self):
        """Card header should use provided title."""
        card = build_command_response_card("My Title", "Content")
        self.assertEqual(card["header"]["title"]["content"], "My Title")

    def test_renders_content(self):
        """Card body should contain content."""
        card = build_command_response_card("Title", "My **content**")
        elements = card["body"]["elements"]
        self.assertTrue(any("content" in str(e) for e in elements))


class TestPermissionButtons(unittest.TestCase):
    """Tests for _permission_buttons function."""

    def test_produces_correct_action_payloads(self):
        """Permission buttons should have correct action payloads."""
        permission = {"id": "perm-123", "permission": "write_file", "tool": "bash"}
        blocks = _permission_buttons(permission)
        self.assertEqual(len(blocks), 2)  # markdown + button row

        action_block = blocks[1]
        self.assertEqual(action_block["tag"], "column_set")
        actions = [c["elements"][0] for c in action_block["columns"]]
        self.assertEqual(len(actions), 3)

        # Check button values
        values = [a["value"] for a in actions]
        self.assertEqual(values[0]["type"], ACTION_TYPE_PERMISSION)
        self.assertEqual(values[0]["id"], "perm-123")
        self.assertEqual(values[0]["reply"], "once")
        self.assertEqual(values[1]["reply"], "always")
        self.assertEqual(values[2]["reply"], "reject")

    def test_shows_tool_and_permission(self):
        """Permission description should show tool and permission."""
        permission = {"id": "perm-123", "permission": "write_file", "tool": "bash"}
        blocks = _permission_buttons(permission)
        desc_block = blocks[0]
        self.assertIn("bash", str(desc_block))
        self.assertIn("write_file", str(desc_block))


class TestQuestionButtons(unittest.TestCase):
    """Tests for _question_buttons function."""

    def test_produces_correct_action_payloads(self):
        """Question buttons should have correct action payloads."""
        question = {
            "id": "q-123",
            "questions": [
                {
                    "question": "Continue?",
                    "options": [
                        {"label": "Yes", "description": "Go ahead"},
                        {"label": "No", "description": "Stop"},
                    ],
                    "custom": False,
                }
            ],
        }
        blocks = _question_buttons(question)
        self.assertTrue(len(blocks) > 0)

        # With description: each option = 1 markdown + 1 column_set
        action_blocks = [
            b
            for b in blocks
            if b.get("tag") == "column_set"
            and b["columns"][0]["elements"][0].get("tag") == "button"
        ]
        self.assertEqual(len(action_blocks), 2)

        btn0 = action_blocks[0]["columns"][0]["elements"][0]
        btn1 = action_blocks[1]["columns"][0]["elements"][0]
        self.assertEqual(btn0["value"]["type"], ACTION_TYPE_QUESTION)
        self.assertEqual(btn0["value"]["id"], "q-123")
        self.assertEqual(btn0["value"]["answer"], "Yes")
        self.assertEqual(btn1["value"]["answer"], "No")

    def test_multiple_questions(self):
        """Multiple questions should render multiple blocks."""
        question = {
            "id": "q-123",
            "questions": [
                {"question": "Q1?", "options": ["A", "B"], "custom": False},
                {"question": "Q2?", "options": ["C", "D"], "custom": False},
            ],
        }
        blocks = _question_buttons(question)
        md_blocks = [b for b in blocks if b.get("tag") == "markdown"]
        action_blocks = [b for b in blocks if b.get("tag") == "column_set"]
        # 2 question headers
        self.assertEqual(len(md_blocks), 2)
        # 2 options per question x 2 questions = 4 button column_sets
        self.assertEqual(len(action_blocks), 4)

    def test_custom_input_shown_by_default(self):
        """Custom input form should appear when custom is not False."""
        question = {
            "id": "q-123",
            "questions": [{"question": "Pick?", "options": ["A"]}],
        }
        blocks = _question_buttons(question)
        form_blocks = [b for b in blocks if b.get("tag") == "form"]
        self.assertEqual(len(form_blocks), 1)

    def test_custom_input_hidden_when_false(self):
        """Custom input form should not appear when custom is False."""
        question = {
            "id": "q-123",
            "questions": [{"question": "Pick?", "options": ["A"], "custom": False}],
        }
        blocks = _question_buttons(question)
        form_blocks = [b for b in blocks if b.get("tag") == "form"]
        self.assertEqual(len(form_blocks), 0)


class TestCardSchema(unittest.TestCase):
    """Tests for card JSON schema compliance."""

    def test_streaming_card_has_required_keys(self):
        """Streaming card should have schema, header, body."""
        card = build_streaming_card([])
        self.assertIn("schema", card)
        self.assertIn("header", card)
        self.assertIn("body", card)
        self.assertIn("elements", card["body"])
        self.assertIn("title", card["header"])
        self.assertIn("template", card["header"])

    def test_frozen_card_has_required_keys(self):
        """Frozen card should have schema, header, body."""
        card = build_frozen_card([])
        self.assertIn("schema", card)
        self.assertIn("header", card)
        self.assertIn("body", card)

    def test_menu_card_has_required_keys(self):
        """Menu card should have schema, header, body."""
        card = build_menu_card()
        self.assertIn("schema", card)
        self.assertIn("header", card)
        self.assertIn("body", card)


if __name__ == "__main__":
    unittest.main()
