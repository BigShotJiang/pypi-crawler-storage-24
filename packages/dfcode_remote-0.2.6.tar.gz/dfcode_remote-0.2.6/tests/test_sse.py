"""Tests for SSE parsing module."""

import unittest
from dfcode_remote.dfcode_client.sse import _parse_frame
from dfcode_remote.dfcode_client.types import SSEEvent


class TestParseFrame(unittest.TestCase):
    """Tests for _parse_frame function."""

    def test_valid_sse_data_line(self):
        """Parse valid SSE data line into event."""
        frame = 'data: {"type": "message.part.updated", "properties": {"sessionID": "sess-1"}}'
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertIsInstance(event, SSEEvent)
        self.assertEqual(event.type, "message.part.updated")
        self.assertEqual(event.properties["sessionID"], "sess-1")

    def test_multiline_frame(self):
        """Parse frame with multiple lines, only data: matters."""
        frame = """event: update
data: {"type": "test", "properties": {}}
id: 123"""
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertEqual(event.type, "test")

    def test_empty_data_line_skipped(self):
        """Empty data line should be skipped."""
        frame = 'data: \ndata: {"type": "test"}'
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertEqual(event.type, "test")

    def test_malformed_json_returns_none(self):
        """Malformed JSON should return None."""
        frame = "data: {not valid json}"
        event = _parse_frame(frame)
        self.assertIsNone(event)

    def test_no_data_line_returns_none(self):
        """Frame without data: line should return None."""
        frame = "event: update\nid: 123"
        event = _parse_frame(frame)
        self.assertIsNone(event)

    def test_empty_frame_returns_none(self):
        """Empty frame should return None."""
        event = _parse_frame("")
        self.assertIsNone(event)

    def test_whitespace_only_frame_returns_none(self):
        """Whitespace-only frame should return None."""
        event = _parse_frame("   \n\t  ")
        self.assertIsNone(event)

    def test_server_connected_event(self):
        """Parse server.connected event."""
        frame = 'data: {"type": "server.connected"}'
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertEqual(event.type, "server.connected")

    def test_permission_asked_event(self):
        """Parse permission.asked event."""
        frame = 'data: {"type": "permission.asked", "properties": {"id": "perm-1", "permission": "write"}}'
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertEqual(event.type, "permission.asked")
        self.assertEqual(event.properties["id"], "perm-1")

    def test_question_asked_event(self):
        """Parse question.asked event."""
        frame = 'data: {"type": "question.asked", "properties": {"id": "q-1", "questions": []}}'
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertEqual(event.type, "question.asked")

    def test_session_status_event(self):
        """Parse session.status event."""
        frame = 'data: {"type": "session.status", "properties": {"sessionID": "sess-1", "status": {"type": "idle"}}}'
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertEqual(event.type, "session.status")
        self.assertEqual(event.properties["status"]["type"], "idle")

    def test_session_error_event(self):
        """Parse session.error event."""
        frame = 'data: {"type": "session.error", "properties": {"sessionID": "sess-1", "error": {"message": "Oops"}}}'
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertEqual(event.type, "session.error")
        self.assertEqual(event.properties["error"]["message"], "Oops")

    def test_message_part_updated_event(self):
        """Parse message.part.updated event."""
        frame = 'data: {"type": "message.part.updated", "properties": {"sessionID": "sess-1", "part": {"type": "text", "text": "Hello"}}}'
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertEqual(event.type, "message.part.updated")
        self.assertEqual(event.properties["part"]["text"], "Hello")

    def test_data_with_leading_spaces(self):
        """Data with leading spaces should be stripped."""
        frame = 'data:    {"type": "test"}'
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertEqual(event.type, "test")

    def test_multiple_data_lines_uses_first_valid(self):
        """Multiple data lines, first valid one is used."""
        frame = 'data: {"type": "first"}\ndata: {"type": "second"}'
        event = _parse_frame(frame)
        self.assertIsNotNone(event)
        self.assertEqual(event.type, "first")


if __name__ == "__main__":
    unittest.main()
