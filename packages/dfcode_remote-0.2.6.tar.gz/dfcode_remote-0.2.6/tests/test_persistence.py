"""Tests for persistence utility module."""

import os
import tempfile
import unittest
from pathlib import Path
from dfcode_remote.utils.persistence import Persistence


class TestPersistence(unittest.TestCase):
    """Tests for Persistence class."""

    def setUp(self):
        """Create a temporary directory for each test."""
        self.temp_dir = tempfile.mkdtemp()
        self.persistence = Persistence(data_dir=self.temp_dir)

    def tearDown(self):
        """Clean up temporary directory."""
        import shutil

        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_set_binding_creates_file(self):
        """Setting a binding should create the bindings file."""
        self.persistence.set_binding("chat-1", "session-1")
        self.assertTrue(self.persistence._file.exists())

    def test_get_binding_returns_session_id(self):
        """Getting a binding should return the session ID."""
        self.persistence.set_binding("chat-1", "session-1")
        result = self.persistence.get_binding("chat-1")
        self.assertEqual(result, "session-1")

    def test_get_binding_returns_none_for_missing(self):
        """Getting a missing binding should return None."""
        result = self.persistence.get_binding("nonexistent")
        self.assertIsNone(result)

    def test_remove_binding_deletes_entry(self):
        """Removing a binding should delete the entry."""
        self.persistence.set_binding("chat-1", "session-1")
        self.persistence.remove_binding("chat-1")
        result = self.persistence.get_binding("chat-1")
        self.assertIsNone(result)

    def test_remove_binding_no_error_for_missing(self):
        """Removing a missing binding should not raise error."""
        self.persistence.remove_binding("nonexistent")  # Should not raise

    def test_list_bindings_returns_all(self):
        """Listing bindings should return all chat->session mappings."""
        self.persistence.set_binding("chat-1", "session-1")
        self.persistence.set_binding("chat-2", "session-2")
        bindings = self.persistence.list_bindings()
        self.assertEqual(len(bindings), 2)
        self.assertEqual(bindings["chat-1"], "session-1")
        self.assertEqual(bindings["chat-2"], "session-2")

    def test_list_bindings_empty_when_no_file(self):
        """Listing bindings should return empty dict when no file exists."""
        bindings = self.persistence.list_bindings()
        self.assertEqual(bindings, {})

    def test_update_binding_overwrites(self):
        """Setting a binding for existing chat should overwrite."""
        self.persistence.set_binding("chat-1", "session-1")
        self.persistence.set_binding("chat-1", "session-2")
        result = self.persistence.get_binding("chat-1")
        self.assertEqual(result, "session-2")

    def test_atomic_write_file_exists_after_write(self):
        """File should exist after atomic write completes."""
        self.persistence.set_binding("chat-1", "session-1")
        self.assertTrue(self.persistence._file.exists())
        content = self.persistence._file.read_text(encoding="utf-8")
        self.assertIn("chat-1", content)
        self.assertIn("session-1", content)

    def test_persists_across_instances(self):
        """Data should persist across Persistence instances."""
        self.persistence.set_binding("chat-1", "session-1")
        # Create new instance pointing to same directory
        new_persistence = Persistence(data_dir=self.temp_dir)
        result = new_persistence.get_binding("chat-1")
        self.assertEqual(result, "session-1")

    def test_handles_corrupted_file(self):
        """Should handle corrupted JSON file gracefully."""
        self.persistence._file.write_text("not valid json", encoding="utf-8")
        bindings = self.persistence.list_bindings()
        self.assertEqual(bindings, {})

    def test_multiple_chats_same_session(self):
        """Multiple chats can bind to the same session."""
        self.persistence.set_binding("chat-1", "session-x")
        self.persistence.set_binding("chat-2", "session-x")
        self.assertEqual(self.persistence.get_binding("chat-1"), "session-x")
        self.assertEqual(self.persistence.get_binding("chat-2"), "session-x")


if __name__ == "__main__":
    unittest.main()
