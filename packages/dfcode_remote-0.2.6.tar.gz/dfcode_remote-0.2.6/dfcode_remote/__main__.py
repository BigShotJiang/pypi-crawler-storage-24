"""Allow running as `python -m dfcode_remote`."""

from dfcode_remote.cli import main

if __name__ == "__main__":
    main()
