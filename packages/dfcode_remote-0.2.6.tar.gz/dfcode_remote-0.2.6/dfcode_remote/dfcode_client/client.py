import httpx
from typing import Optional

from dfcode_remote.dfcode_client.types import (
    ActiveSessionInfo,
    SessionInfo,
    SessionStatus,
    MessageInfo,
)


class DfcodeAPIError(Exception):
    """Raised when the dfcode API returns an error response."""

    def __init__(self, status: int, message: str, url: str = ""):
        self.status = status
        self.url = url
        super().__init__(f"dfcode API error {status}: {message} (url={url})")


class DfcodeClient:
    """Async HTTP client wrapping the dfcode REST API."""

    def __init__(
        self,
        base_url: str = "http://localhost:4096",
        directory: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.directory = directory
        headers: dict[str, str] = {}
        if directory:
            headers["x-dfcode-directory"] = directory
        auth = None
        if username and password:
            auth = httpx.BasicAuth(username, password)
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=headers,
            auth=auth,
            timeout=httpx.Timeout(30.0, connect=10.0),
        )

    async def __aenter__(self) -> "DfcodeClient":
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        """Send a request and raise on non-2xx status."""
        resp = await self._client.request(method, path, **kwargs)
        if resp.status_code >= 400:
            text = resp.text
            raise DfcodeAPIError(resp.status_code, text, url=str(resp.url))
        return resp

    # --- Global ---

    async def health(self) -> dict:
        """GET /global/health"""
        resp = await self._request("GET", "/global/health")
        return resp.json()

    # --- Sessions ---

    async def list_sessions(self) -> list[SessionInfo]:
        """GET /session"""
        resp = await self._request("GET", "/session")
        return [SessionInfo.from_dict(s) for s in resp.json()]

    async def list_active_sessions(self) -> list[ActiveSessionInfo]:
        """GET /session/active"""
        resp = await self._request("GET", "/session/active")
        return [ActiveSessionInfo.from_dict(s) for s in resp.json()]

    async def get_active_session(self, session_id: str) -> ActiveSessionInfo:
        """GET /session/active/{id}"""
        resp = await self._request("GET", f"/session/active/{session_id}")
        return ActiveSessionInfo.from_dict(resp.json())

    async def create_session(self, title: Optional[str] = None) -> SessionInfo:
        """POST /session"""
        body: dict = {}
        if title:
            body["title"] = title
        resp = await self._request("POST", "/session", json=body)
        return SessionInfo.from_dict(resp.json())

    async def get_session(self, session_id: str) -> SessionInfo:
        """GET /session/{id}"""
        resp = await self._request("GET", f"/session/{session_id}")
        return SessionInfo.from_dict(resp.json())

    async def delete_session(self, session_id: str) -> bool:
        """DELETE /session/{id}"""
        resp = await self._request("DELETE", f"/session/{session_id}")
        return resp.status_code < 400

    async def get_status(self) -> dict[str, SessionStatus]:
        """GET /session/status"""
        resp = await self._request("GET", "/session/status")
        data = resp.json()
        return {k: SessionStatus.from_dict(v) for k, v in data.items()}

    async def prompt_async(self, session_id: str, text: str) -> None:
        """POST /session/{id}/prompt_async — returns 204 immediately."""
        await self._request(
            "POST",
            f"/session/{session_id}/prompt_async",
            json={"parts": [{"type": "text", "text": text}]},
        )

    async def prompt_active_async(self, session_id: str, text: str) -> None:
        """POST /session/active/{id}/prompt_async — cross-project active session prompt."""
        await self._request(
            "POST",
            f"/session/active/{session_id}/prompt_async",
            json={"parts": [{"type": "text", "text": text}]},
        )

    async def prompt_async_in_project(
        self,
        session_id: str,
        text: str,
        project_root: str,
    ) -> None:
        """POST /session/{id}/prompt_async with explicit project directory context."""
        await self._request(
            "POST",
            f"/session/{session_id}/prompt_async",
            json={"parts": [{"type": "text", "text": text}]},
            headers={"x-dfcode-directory": project_root},
        )

    async def abort(self, session_id: str) -> bool:
        """POST /session/{id}/abort"""
        resp = await self._request("POST", f"/session/{session_id}/abort")
        return resp.status_code < 400

    async def get_messages(self, session_id: str) -> list[MessageInfo]:
        """GET /session/{id}/message"""
        resp = await self._request("GET", f"/session/{session_id}/message")
        return [MessageInfo.from_dict(m) for m in resp.json()]

    # --- Permissions ---

    async def reply_permission(
        self,
        request_id: str,
        reply: str,
        message: Optional[str] = None,
    ) -> bool:
        """POST /permission/{id}/reply"""
        body: dict = {"reply": reply}
        if message:
            body["message"] = message
        resp = await self._request("POST", f"/permission/{request_id}/reply", json=body)
        return resp.status_code < 400

    async def list_permissions(self) -> list[dict]:
        """GET /permission"""
        resp = await self._request("GET", "/permission")
        return resp.json()

    # --- Questions ---

    async def reply_question(self, request_id: str, answers: list[list[str]]) -> bool:
        """POST /question/{id}/reply

        Each element in answers corresponds to one question.
        Each answer is a list of selected labels (even for single-select).
        Example: [["Yes"]] for a single question with one selection.
        """
        resp = await self._request(
            "POST",
            f"/question/{request_id}/reply",
            json={"answers": answers},
        )
        return resp.status_code < 400

    async def reject_question(self, request_id: str) -> bool:
        """POST /question/{id}/reject"""
        resp = await self._request("POST", f"/question/{request_id}/reject")
        return resp.status_code < 400

    async def list_questions(self) -> list[dict]:
        """GET /question"""
        resp = await self._request("GET", "/question")
        return resp.json()
