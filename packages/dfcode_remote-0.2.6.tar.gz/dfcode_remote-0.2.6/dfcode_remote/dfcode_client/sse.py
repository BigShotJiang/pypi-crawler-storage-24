import asyncio
import json
import logging
from typing import AsyncIterator, Optional

import httpx

from dfcode_remote.dfcode_client.types import SSEEvent

logger = logging.getLogger(__name__)

_INITIAL_BACKOFF = 1.0
_MAX_BACKOFF = 30.0
_HEARTBEAT_TIMEOUT = 60.0


async def sse_stream(
    url: str,
    headers: Optional[dict[str, str]] = None,
) -> AsyncIterator[SSEEvent]:
    """Connect to a dfcode SSE endpoint and yield parsed events.

    Auto-reconnects with exponential backoff on connection loss.
    Reconnects if no data received within the heartbeat timeout (60s).
    """
    backoff = _INITIAL_BACKOFF

    while True:
        try:
            async with httpx.AsyncClient(timeout=None) as client:
                async with client.stream(
                    "GET",
                    url,
                    headers={**(headers or {}), "Accept": "text/event-stream"},
                ) as resp:
                    if resp.status_code >= 400:
                        logger.error("SSE connect failed: %d", resp.status_code)
                        await asyncio.sleep(backoff)
                        backoff = min(backoff * 2, _MAX_BACKOFF)
                        continue

                    # Connected — reset backoff
                    backoff = _INITIAL_BACKOFF

                    async for event in _parse_stream(resp):
                        yield event

        except asyncio.CancelledError:
            logger.debug("SSE stream cancelled")
            return

        except (httpx.HTTPError, OSError) as exc:
            logger.warning(
                "SSE connection error: %s — reconnecting in %.0fs", exc, backoff
            )
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, _MAX_BACKOFF)


async def _parse_stream(resp: httpx.Response) -> AsyncIterator[SSEEvent]:
    """Parse SSE frames from an httpx streaming response with heartbeat timeout."""
    buffer = ""

    async for chunk in _timeout_iter(resp.aiter_text(), _HEARTBEAT_TIMEOUT):
        buffer += chunk
        while "\n\n" in buffer:
            frame, buffer = buffer.split("\n\n", 1)
            event = _parse_frame(frame)
            if event:
                yield event


async def _timeout_iter(aiter, timeout: float):
    """Wrap an async iterator with a per-item timeout. Raises TimeoutError on expiry."""
    ait = aiter.__aiter__()
    while True:
        try:
            item = await asyncio.wait_for(ait.__anext__(), timeout=timeout)
            yield item
        except StopAsyncIteration:
            return
        except asyncio.TimeoutError:
            logger.warning("SSE heartbeat timeout (%.0fs) — will reconnect", timeout)
            return


def _parse_frame(frame: str) -> Optional[SSEEvent]:
    """Parse a single SSE frame into an SSEEvent, or None if unparseable."""
    for line in frame.strip().splitlines():
        if line.startswith("data:"):
            payload = line[len("data:") :].strip()
            if not payload:
                continue
            try:
                data = json.loads(payload)
                if (
                    isinstance(data, dict)
                    and "payload" in data
                    and isinstance(data["payload"], dict)
                ):
                    data = data["payload"]
                return SSEEvent.from_dict(data)
            except (json.JSONDecodeError, KeyError) as exc:
                logger.debug("Failed to parse SSE data: %s", exc)
    return None
