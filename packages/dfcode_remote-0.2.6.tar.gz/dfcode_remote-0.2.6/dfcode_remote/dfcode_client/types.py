from dataclasses import dataclass, field
from typing import Optional, Any


@dataclass
class SessionInfo:
    """Represents a dfcode session."""

    id: str
    title: str
    directory: str
    parentID: Optional[str] = None
    time: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> "SessionInfo":
        return cls(
            id=data["id"],
            title=data.get("title", ""),
            directory=data.get("directory", ""),
            parentID=data.get("parentID"),
            time=data.get("time", {}),
        )


@dataclass
class SessionStatus:
    """Session processing status."""

    type: str  # "idle" | "busy" | "retry"

    @classmethod
    def from_dict(cls, data: dict) -> "SessionStatus":
        return cls(type=data.get("type", "idle"))


@dataclass
class ActiveSessionInfo:
    """A cross-project active session item from /session/active."""

    id: str
    title: str = ""
    directory: str = ""
    projectRoot: str = ""
    projectID: str = ""
    parentID: Optional[str] = None
    time: dict = field(default_factory=dict)
    status: SessionStatus = field(default_factory=lambda: SessionStatus(type="idle"))
    activity: dict = field(default_factory=dict)
    attachable: bool = False
    continueable: bool = False
    rank: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "ActiveSessionInfo":
        return cls(
            id=data["id"],
            title=data.get("title", ""),
            directory=data.get("directory", ""),
            projectRoot=data.get("projectRoot", data.get("directory", "")),
            projectID=data.get("projectID", ""),
            parentID=data.get("parentID"),
            time=data.get("time", {}),
            status=SessionStatus.from_dict(data.get("status", {})),
            activity=data.get("activity", {}),
            attachable=data.get("attachable", False),
            continueable=data.get("continueable", False),
            rank=data.get("rank", 0),
        )


@dataclass
class PartInfo:
    """Message part — discriminated union on 'type' field."""

    type: str
    id: Optional[str] = None
    text: Optional[str] = None
    time: Optional[dict] = None
    callID: Optional[str] = None
    tool: Optional[str] = None
    state: Optional[dict] = None
    cost: Optional[dict] = None
    tokens: Optional[dict] = None
    sessionID: Optional[str] = None
    messageID: Optional[str] = None
    raw: Optional[dict] = None

    @classmethod
    def from_dict(cls, data: dict) -> "PartInfo":
        t = data.get("type", "")
        if t == "text":
            return cls(
                type=t,
                id=data.get("id"),
                text=data.get("text"),
                time=data.get("time"),
                sessionID=data.get("sessionID"),
                messageID=data.get("messageID"),
            )
        if t == "tool":
            return cls(
                type=t,
                id=data.get("id"),
                callID=data.get("callID"),
                tool=data.get("tool"),
                state=data.get("state"),
                time=data.get("time"),
                sessionID=data.get("sessionID"),
                messageID=data.get("messageID"),
            )
        if t == "step-finish":
            return cls(
                type=t,
                id=data.get("id"),
                cost=data.get("cost"),
                tokens=data.get("tokens"),
                time=data.get("time"),
                sessionID=data.get("sessionID"),
                messageID=data.get("messageID"),
            )
        if t == "reasoning":
            return cls(
                type=t,
                id=data.get("id"),
                text=data.get("text"),
                time=data.get("time"),
                sessionID=data.get("sessionID"),
                messageID=data.get("messageID"),
            )
        return cls(
            type=t,
            id=data.get("id"),
            sessionID=data.get("sessionID"),
            messageID=data.get("messageID"),
            raw=data,
        )


@dataclass
class MessageInfo:
    """A message in a session."""

    id: str
    sessionID: str
    role: str
    parts: list[PartInfo] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "MessageInfo":
        info = data.get("info", data)
        parts = [PartInfo.from_dict(p) for p in data.get("parts", [])]
        return cls(
            id=info.get("id", ""),
            sessionID=info.get("sessionID", ""),
            role=info.get("role", ""),
            parts=parts,
        )


@dataclass
class PermissionRequest:
    """A pending permission request from dfcode."""

    id: str
    sessionID: str
    permission: str
    patterns: list[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
    tool: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "PermissionRequest":
        return cls(
            id=data["id"],
            sessionID=data.get("sessionID", ""),
            permission=data.get("permission", ""),
            patterns=data.get("patterns", []),
            metadata=data.get("metadata", {}),
            tool=data.get("tool"),
        )


@dataclass
class QuestionRequest:
    """A pending question from dfcode."""

    id: str
    sessionID: str
    questions: list[dict] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "QuestionRequest":
        return cls(
            id=data["id"],
            sessionID=data.get("sessionID", ""),
            questions=data.get("questions", []),
        )


@dataclass
class SSEEvent:
    """A parsed Server-Sent Event."""

    type: str
    properties: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> "SSEEvent":
        return cls(
            type=data.get("type", ""),
            properties=data.get("properties", {}),
        )
