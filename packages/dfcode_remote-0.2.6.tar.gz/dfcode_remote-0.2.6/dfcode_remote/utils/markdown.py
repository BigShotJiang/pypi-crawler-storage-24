import re

_MAX_CARD_CHARS = 30000
_IMAGE_RE = re.compile(r"!\[([^\]]*)\]\([^)]+\)")


def markdown_to_lark(text: str) -> str:
    """Convert standard markdown to Feishu card-compatible markdown.

    Feishu cards support bold, italic, strikethrough, links, inline code,
    and code blocks — but not images. Images are stripped and replaced
    with alt-text placeholders.

    Truncates at 30000 chars with a suffix marker.
    """
    # Strip image syntax, keep alt text as placeholder
    result = _IMAGE_RE.sub(r"[\1]", text)

    if len(result) > _MAX_CARD_CHARS:
        result = result[: _MAX_CARD_CHARS - 20] + "\n\n... (truncated)"

    return result


def format_tool_output(text: str, max_chars: int = 500) -> str:
    """Format tool output for display in a card panel.

    Strips leading/trailing whitespace and truncates to max_chars.
    Wraps in a code block if it looks like command output.
    """
    stripped = text.strip()
    if not stripped:
        return ""
    truncated = truncate_output(stripped, max_chars)
    return f"```\n{truncated}\n```"


def truncate_output(text: str, max_chars: int = 2000) -> str:
    """Smart truncation keeping first and last portions for readability.

    If text fits within max_chars, returns it unchanged.
    Otherwise keeps roughly 60% from the start and 40% from the end,
    joined by a truncation marker.
    """
    if len(text) <= max_chars:
        return text

    marker = "\n\n... (truncated) ...\n\n"
    available = max_chars - len(marker)
    head = int(available * 0.6)
    tail = available - head

    return text[:head] + marker + text[-tail:]
