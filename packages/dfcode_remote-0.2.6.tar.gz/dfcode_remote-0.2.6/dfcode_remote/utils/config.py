import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv


def _config_dir() -> Path:
    """Return platform-appropriate config directory."""
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "dfcode-remote"


CONFIG_DIR = _config_dir()


@dataclass
class Config:
    """Application configuration loaded from .env and environment variables."""

    feishu_app_id: str = ""
    feishu_app_secret: str = ""
    dfcode_url: str = "http://localhost:4096"
    dfcode_directory: str = "."
    dfcode_username: str = ""
    dfcode_password: str = ""
    allowed_users: list[str] = field(default_factory=list)
    enable_urgent: bool = True

    @staticmethod
    def load() -> "Config":
        """Load config from .env files and environment variables.

        Priority (highest to lowest):
        1. Environment variables
        2. .env in current working directory
        3. ~/.config/dfcode-remote/.env
        """
        # Load global config first (lower priority)
        global_env = CONFIG_DIR / ".env"
        if global_env.exists():
            load_dotenv(global_env)

        # Load local .env (overrides global)
        load_dotenv(override=True)

        raw_users = os.getenv("ALLOWED_USERS", "")
        allowed = [u.strip() for u in raw_users.split(",") if u.strip()]

        raw_urgent = os.getenv("ENABLE_URGENT", "true")
        urgent = raw_urgent.lower() not in ("false", "0", "no")

        return Config(
            feishu_app_id=os.getenv("FEISHU_APP_ID", ""),
            feishu_app_secret=os.getenv("FEISHU_APP_SECRET", ""),
            dfcode_url=os.getenv("DFCODE_URL", "http://localhost:4096"),
            dfcode_directory=os.getenv("DFCODE_DIRECTORY", "."),
            dfcode_username=os.getenv("DFCODE_USERNAME", ""),
            dfcode_password=os.getenv("DFCODE_PASSWORD", ""),
            allowed_users=allowed,
            enable_urgent=urgent,
        )
