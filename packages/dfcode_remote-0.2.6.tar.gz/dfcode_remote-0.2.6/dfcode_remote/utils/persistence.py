import json
import os
import tempfile
from pathlib import Path
from typing import Optional


class Persistence:
    """JSON file persistence for chat-to-session bindings.

    Stores data at ~/.dfcode-remote/bindings.json with atomic writes.
    """

    def __init__(self, data_dir: str = "~/.dfcode-remote"):
        self._dir = Path(data_dir).expanduser()
        self._file = self._dir / "bindings.json"
        self._dir.mkdir(parents=True, exist_ok=True)

    def _read(self) -> dict[str, str]:
        if not self._file.exists():
            return {}
        try:
            return json.loads(self._file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def _write(self, data: dict[str, str]) -> None:
        """Atomic write: write to temp file then rename."""
        fd, tmp = tempfile.mkstemp(dir=str(self._dir), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, str(self._file))
        except BaseException:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise

    def get_binding(self, chat_id: str) -> Optional[str]:
        """Get session_id bound to chat_id, or None."""
        return self._read().get(chat_id)

    def set_binding(self, chat_id: str, session_id: str) -> None:
        """Bind chat_id to session_id."""
        data = self._read()
        data[chat_id] = session_id
        self._write(data)

    def remove_binding(self, chat_id: str) -> None:
        """Remove binding for chat_id."""
        data = self._read()
        if chat_id in data:
            del data[chat_id]
            self._write(data)

    def list_bindings(self) -> dict[str, str]:
        """Return all {chat_id: session_id} bindings."""
        return self._read()
