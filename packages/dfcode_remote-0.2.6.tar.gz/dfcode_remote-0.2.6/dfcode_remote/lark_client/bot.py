"""Feishu WebSocket long-connection bootstrap.

Initialises the lark_oapi WebSocket client and registers event handlers.

The lark_oapi SDK runs its own internal event loop for WebSocket handling.
Our async handlers need to run on the main asyncio loop. We solve this by
capturing the main loop reference and using run_coroutine_threadsafe() to
dispatch coroutines from the SDK thread to the main loop.
"""

import asyncio
import logging
from typing import Callable, Coroutine, Any

import lark_oapi as lark
from lark_oapi.api.im.v1.model.p2_im_message_receive_v1 import P2ImMessageReceiveV1
from lark_oapi.event.callback.model.p2_card_action_trigger import (
    P2CardActionTrigger,
    P2CardActionTriggerResponse,
)

logger = logging.getLogger(__name__)

MessageHandler = Callable[[P2ImMessageReceiveV1], Coroutine[Any, Any, None]]
CardActionHandler = Callable[[P2CardActionTrigger], Coroutine[Any, Any, None]]


async def start_bot_async(
    app_id: str,
    app_secret: str,
    on_message: MessageHandler,
    on_card_action: CardActionHandler,
) -> None:
    """Start the Feishu WebSocket bot without blocking the main event loop.

    Captures the running event loop, then launches the blocking SDK client
    in a thread executor. SDK callbacks dispatch coroutines back to the
    main loop via run_coroutine_threadsafe().
    """
    main_loop = asyncio.get_running_loop()

    def _sync_message(data: P2ImMessageReceiveV1) -> None:
        try:
            future = asyncio.run_coroutine_threadsafe(on_message(data), main_loop)
            future.result(timeout=30)
        except Exception as e:
            logger.error("Error handling message: %s", e, exc_info=True)

    def _sync_card(data: P2CardActionTrigger) -> P2CardActionTriggerResponse:
        try:
            logger.info("Received card action callback: %r", data)
            future = asyncio.run_coroutine_threadsafe(on_card_action(data), main_loop)
            future.result(timeout=30)
        except Exception as e:
            logger.error("Error handling card action: %s", e, exc_info=True)
        return P2CardActionTriggerResponse()

    handler = (
        lark.EventDispatcherHandler.builder("", "")
        .register_p2_im_message_receive_v1(_sync_message)
        .register_p2_card_action_trigger(_sync_card)
        .build()
    )

    cli = lark.ws.Client(
        app_id,
        app_secret,
        log_level=lark.LogLevel.DEBUG,
        event_handler=handler,
    )

    logger.info("Starting Feishu WebSocket bot (app_id=%s)", app_id)
    await main_loop.run_in_executor(None, cli.start)
