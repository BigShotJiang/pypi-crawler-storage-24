"""Pure card JSON builders for Feishu Card Schema 2.0.

No network calls — all functions take data and return dicts.
"""

from typing import Optional
from dfcode_remote.dfcode_client.types import PartInfo
from dfcode_remote.utils.markdown import markdown_to_lark, format_tool_output

MAX_CARD_BLOCKS = 50

# Action payload keys
ACTION_TYPE_PERMISSION = "permission"
ACTION_TYPE_QUESTION = "question"
ACTION_TYPE_ABORT = "abort"
ACTION_TYPE_MENU = "menu"


def _md_block(text: str) -> dict:
    return {"tag": "markdown", "content": text}


def _divider() -> dict:
    return {"tag": "hr"}


def _note(text: str) -> dict:
    """Create a note-style text block using div instead of deprecated note tag."""
    return {
        "tag": "div",
        "text": {"tag": "plain_text", "content": text},
    }


def _column_set(columns: list[dict]) -> dict:
    return {"tag": "column_set", "flex_mode": "none", "columns": columns}


def _column(elements: list[dict], weight: int = 1) -> dict:
    return {
        "tag": "column",
        "width": "weighted",
        "weight": weight,
        "elements": elements,
    }


def _button(
    label: str, value: dict, style: str = "default", disabled: bool = False
) -> dict:
    return {
        "tag": "button",
        "text": {"tag": "plain_text", "content": label},
        "type": style,
        "value": value,
        "disabled": disabled,
    }


def _collapsible_panel(title: str, content: str, expanded: bool = False) -> dict:
    return {
        "tag": "collapsible_panel",
        "expanded": expanded,
        "header": {
            "title": {"tag": "plain_text", "content": title},
        },
        "elements": [_md_block(content)] if content else [],
    }


def _render_tool_part(part: PartInfo) -> dict:
    state = part.state or {}
    status = state.get("status", "running")
    title_text = state.get("title", part.tool or "tool")
    output = state.get("output", "")

    if status == "completed":
        icon = "🔧"
        label = f"{icon} {part.tool} — {title_text}"
        body = format_tool_output(output) if output else ""
        return _collapsible_panel(label, body, expanded=False)

    icon = "⏳"
    label = f"{icon} {part.tool or 'tool'}"
    return _collapsible_panel(label, "", expanded=False)


def _render_step_finish(part: PartInfo) -> dict:
    tokens = part.tokens or {}
    cost = part.cost or {}
    inp = tokens.get("input", 0)
    out = tokens.get("output", 0)
    total_cost = cost.get("total", 0)
    line = f"tokens: {inp} in / {out} out"
    if total_cost:
        line += f"  |  cost: ${total_cost:.4f}"
    return _note(line)


def _content_blocks(parts: list[PartInfo]) -> list[dict]:
    blocks: list[dict] = []
    for part in parts:
        if part.type == "text" and part.text:
            blocks.append(_md_block(markdown_to_lark(part.text)))
        elif part.type == "tool":
            blocks.append(_render_tool_part(part))
        elif part.type == "step-finish":
            blocks.append(_render_step_finish(part))
        elif part.type == "reasoning" and part.text:
            blocks.append(
                _collapsible_panel(
                    "💭 Reasoning", markdown_to_lark(part.text), expanded=False
                )
            )
    return blocks


def _status_block(status: str) -> dict:
    label = "⏳ 思考中..." if status == "busy" else "✅ 完成"
    return {
        "tag": "div",
        "text": {"tag": "plain_text", "content": label},
    }


def _permission_buttons(permission: dict) -> list[dict]:
    req_id = permission.get("id", "")
    perm = permission.get("permission", "")
    tool = permission.get("tool", "")
    desc = f"🔐 {tool}: {perm}" if tool else f"🔐 {perm}"
    return [
        _md_block(desc),
        _column_set(
            [
                _column(
                    [
                        _button(
                            "允许",
                            {
                                "type": ACTION_TYPE_PERMISSION,
                                "id": req_id,
                                "reply": "once",
                            },
                            style="primary",
                        )
                    ]
                ),
                _column(
                    [
                        _button(
                            "始终允许",
                            {
                                "type": ACTION_TYPE_PERMISSION,
                                "id": req_id,
                                "reply": "always",
                            },
                            style="default",
                        )
                    ]
                ),
                _column(
                    [
                        _button(
                            "拒绝",
                            {
                                "type": ACTION_TYPE_PERMISSION,
                                "id": req_id,
                                "reply": "reject",
                            },
                            style="danger",
                        )
                    ]
                ),
            ]
        ),
    ]


def _question_buttons(question: dict) -> list[dict]:
    req_id = question.get("id", "")
    questions = question.get("questions", [])
    blocks: list[dict] = []
    for q in questions:
        text = q.get("question", "")
        options = q.get("options", [])
        multiple = q.get("multiple", False)
        custom = q.get("custom", True)
        if text:
            blocks.append(_md_block(f"❓ {text}"))
        if not options:
            continue

        if multiple:
            # Multi-select: dropdown + submit button in a form
            select_options = []
            for opt in options:
                label = (
                    opt.get("label", str(opt)) if isinstance(opt, dict) else str(opt)
                )
                desc = opt.get("description", "") if isinstance(opt, dict) else ""
                full_text = f"{label} — {desc}" if desc else label
                select_options.append(
                    {
                        "text": {"tag": "plain_text", "content": full_text},
                        "value": label,
                    }
                )
            form_elements: list[dict] = [
                {
                    "tag": "multi_select_static",
                    "name": "selected_options",
                    "placeholder": {
                        "tag": "plain_text",
                        "content": "选择一个或多个选项...",
                    },
                    "options": select_options,
                    "width": "fill",
                },
            ]
            if custom is not False:
                form_elements.append(
                    {
                        "tag": "input",
                        "name": "custom_answer",
                        "placeholder": {
                            "tag": "plain_text",
                            "content": "或输入自定义回答...",
                        },
                        "width": "fill",
                    }
                )
            form_elements.append(
                _column_set(
                    [
                        _column(
                            [
                                {
                                    "tag": "button",
                                    "name": "submit_multi",
                                    "text": {
                                        "tag": "plain_text",
                                        "content": "确认提交",
                                    },
                                    "type": "primary",
                                    "action_type": "form_submit",
                                    "value": {
                                        "type": ACTION_TYPE_QUESTION,
                                        "id": req_id,
                                    },
                                }
                            ]
                        ),
                    ]
                )
            )
            blocks.append(
                {
                    "tag": "form",
                    "name": f"question_form_{req_id}",
                    "elements": form_elements,
                }
            )
        else:
            # Single-select: description as markdown, then button with short label
            for opt in options:
                label = (
                    opt.get("label", str(opt)) if isinstance(opt, dict) else str(opt)
                )
                desc = opt.get("description", "") if isinstance(opt, dict) else ""
                if desc:
                    blocks.append(_md_block(f"**{label}**\n{desc}"))
                    blocks.append(
                        _column_set(
                            [
                                _column(
                                    [
                                        _button(
                                            f"👉 {label}",
                                            {
                                                "type": ACTION_TYPE_QUESTION,
                                                "id": req_id,
                                                "answer": label,
                                            },
                                        )
                                    ]
                                )
                            ]
                        )
                    )
                else:
                    blocks.append(
                        _column_set(
                            [
                                _column(
                                    [
                                        _button(
                                            label,
                                            {
                                                "type": ACTION_TYPE_QUESTION,
                                                "id": req_id,
                                                "answer": label,
                                            },
                                        )
                                    ]
                                )
                            ]
                        )
                    )
            # Custom text input for single-select
            if custom is not False:
                blocks.append(
                    {
                        "tag": "form",
                        "name": f"question_form_{req_id}",
                        "elements": [
                            {
                                "tag": "input",
                                "name": "custom_answer",
                                "placeholder": {
                                    "tag": "plain_text",
                                    "content": "或输入自定义回答...",
                                },
                                "width": "fill",
                            },
                            _column_set(
                                [
                                    _column(
                                        [
                                            {
                                                "tag": "button",
                                                "name": "submit_custom",
                                                "text": {
                                                    "tag": "plain_text",
                                                    "content": "提交自定义回答",
                                                },
                                                "type": "default",
                                                "action_type": "form_submit",
                                                "value": {
                                                    "type": ACTION_TYPE_QUESTION,
                                                    "id": req_id,
                                                },
                                            }
                                        ]
                                    ),
                                ]
                            ),
                        ],
                    }
                )
    return blocks


def _abort_button(session_id: str) -> dict:
    """Create an abort button using column_set instead of deprecated action tag."""
    return _column_set(
        [
            _column(
                [
                    _button(
                        "⛔ 中止",
                        {"type": ACTION_TYPE_ABORT, "session_id": session_id},
                        style="danger",
                    )
                ]
            ),
        ]
    )


def build_streaming_card(
    parts: list[PartInfo],
    status: str = "busy",
    permission: Optional[dict] = None,
    question: Optional[dict] = None,
    session_id: str = "",
) -> dict:
    """Build a live streaming card with content, status, and interaction areas."""
    content = _content_blocks(parts)

    # Trim to MAX_CARD_BLOCKS - reserve space for status/interaction
    max_content = MAX_CARD_BLOCKS - 5
    if len(content) > max_content:
        content = content[:max_content]

    body: list[dict] = []
    body.extend(content)

    if not content:
        body.append(_md_block("_等待响应..._"))

    body.append(_divider())
    body.append(_status_block(status))

    if permission:
        body.append(_divider())
        body.extend(_permission_buttons(permission))
    elif question:
        body.append(_divider())
        body.extend(_question_buttons(question))
    elif status == "busy" and session_id:
        body.append(_abort_button(session_id))

    return {
        "schema": "2.0",
        "body": {"elements": body},
        "header": {
            "title": {"tag": "plain_text", "content": "dfcode"},
            "template": "blue" if status == "busy" else "green",
        },
    }


def build_frozen_card(parts: list[PartInfo]) -> dict:
    """Build a completed/frozen card — no interaction area."""
    content = _content_blocks(parts)
    body: list[dict] = list(content)
    if not body:
        body.append(_md_block("_(empty)_"))
    body.append(_divider())
    body.append(_note("✅ 完成"))
    return {
        "schema": "2.0",
        "body": {"elements": body},
        "header": {
            "title": {"tag": "plain_text", "content": "dfcode"},
            "template": "green",
        },
    }


def build_answered_card(kind: str, label: str) -> dict:
    """Build a card showing that a question/permission has been answered."""
    icon = "🔐" if kind == "permission" else "❓"
    return {
        "schema": "2.0",
        "body": {
            "elements": [
                _md_block(f"{icon} 已处理: **{label}**"),
            ]
        },
        "header": {
            "title": {"tag": "plain_text", "content": "dfcode"},
            "template": "grey",
        },
    }


def build_menu_card(commands: Optional[list[dict]] = None) -> dict:
    """Build a command help/menu card."""
    default_commands = [
        ("/new [title]", "创建新会话"),
        ("/attach <session_id>", "绑定到已有会话"),
        ("/detach", "解绑当前会话"),
        ("/list", "列出所有活跃会话"),
        ("/status", "查看当前会话状态"),
        ("/kill [session_id]", "终止会话"),
        ("/menu", "显示此帮助"),
    ]
    cmds = commands or [{"cmd": c, "desc": d} for c, d in default_commands]
    lines = ["**dfcode 命令列表**\n"]
    for item in cmds:
        cmd = item.get("cmd", "")
        desc = item.get("desc", "")
        lines.append(f"`{cmd}` — {desc}")
    return {
        "schema": "2.0",
        "body": {"elements": [_md_block("\n".join(lines))]},
        "header": {
            "title": {"tag": "plain_text", "content": "命令菜单"},
            "template": "grey",
        },
    }


def build_command_response_card(title: str, content: str) -> dict:
    """Build a simple informational response card."""
    return {
        "schema": "2.0",
        "body": {"elements": [_md_block(markdown_to_lark(content))]},
        "header": {
            "title": {"tag": "plain_text", "content": title},
            "template": "grey",
        },
    }
