"""Feishu CardKit and messaging API wrapper.

Handles tenant_access_token management and all outbound Feishu API calls.
"""

import json
import logging
import time
from typing import Optional, Any

import httpx

logger = logging.getLogger(__name__)

_FEISHU_BASE = "https://open.feishu.cn"
_TOKEN_MARGIN = 60  # refresh token this many seconds before expiry


def _normalize_card_tags(node: Any) -> Any:
    """Normalize legacy card tags to Feishu schema v2-compatible tags."""
    if isinstance(node, list):
        return [_normalize_card_tags(item) for item in node]
    if not isinstance(node, dict):
        return node

    tag = node.get("tag")
    if tag == "note":
        elements = node.get("elements", [])
        text = ""
        for item in elements:
            if isinstance(item, dict) and item.get("tag") == "plain_text":
                text += item.get("content", "")
        if not text:
            text = node.get("text", {}).get("content", "")
        return {
            "tag": "div",
            "text": {"tag": "plain_text", "content": text},
        }

    if tag == "action":
        actions = node.get("actions", [])
        cols = []
        for btn in actions:
            cols.append(
                {
                    "tag": "column",
                    "width": "weighted",
                    "weight": 1,
                    "elements": [_normalize_card_tags(btn)],
                }
            )
        return {
            "tag": "column_set",
            "flex_mode": "none",
            "columns": cols,
        }

    out: dict[str, Any] = {}
    for key, value in node.items():
        out[key] = _normalize_card_tags(value)
    return out


def _scan_legacy_tags(node: Any, path: str = "ROOT") -> list[str]:
    if isinstance(node, list):
        hits: list[str] = []
        for i, item in enumerate(node):
            hits.extend(_scan_legacy_tags(item, f"{path}[{i}]"))
        return hits
    if not isinstance(node, dict):
        return []
    hits: list[str] = []
    tag = node.get("tag")
    if tag in ("action", "note"):
        hits.append(f"{path}(tag:{tag})")
    for key, value in node.items():
        hits.extend(_scan_legacy_tags(value, f"{path}.{key}"))
    return hits


class CardServiceError(Exception):
    """Raised when a Feishu API call fails."""


class CardService:
    """Wraps Feishu CardKit + IM APIs with automatic token refresh."""

    def __init__(self, app_id: str, app_secret: str):
        self._app_id = app_id
        self._app_secret = app_secret
        self._token: Optional[str] = None
        self._token_expires_at: float = 0.0
        self._client = httpx.AsyncClient(base_url=_FEISHU_BASE, timeout=30.0)

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "CardService":
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    # --- Token management ---

    async def _ensure_token(self) -> str:
        if self._token and time.time() < self._token_expires_at - _TOKEN_MARGIN:
            return self._token
        resp = await self._client.post(
            "/open-apis/auth/v3/tenant_access_token/internal",
            json={"app_id": self._app_id, "app_secret": self._app_secret},
        )
        data = resp.json()
        if data.get("code") != 0:
            raise CardServiceError(f"token fetch failed: {data}")
        self._token = data["tenant_access_token"]
        self._token_expires_at = time.time() + data.get("expire", 7200)
        logger.debug(
            "tenant_access_token refreshed, expires in %ds", data.get("expire", 7200)
        )
        return self._token  # type: ignore[return-value]

    async def _headers(self) -> dict[str, str]:
        token = await self._ensure_token()
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    async def _post(self, path: str, body: dict) -> dict:
        headers = await self._headers()
        resp = await self._client.post(path, headers=headers, content=json.dumps(body))
        try:
            data = resp.json()
        except Exception as e:
            logger.error(
                "Failed to parse JSON response from POST %s: %s\nResponse text: %s",
                path,
                e,
                resp.text,
            )
            raise CardServiceError(f"POST {path} JSON parse error: {e}")
        if data.get("code") != 0:
            logger.error("Feishu POST %s failed: %s", path, data)
            raise CardServiceError(f"POST {path} failed: {data}")
        return data

    async def _put(self, path: str, body: dict) -> dict:
        headers = await self._headers()
        resp = await self._client.put(path, headers=headers, content=json.dumps(body))
        data = resp.json()
        if data.get("code") != 0:
            logger.error("Feishu PUT %s failed: %s", path, data)
            raise CardServiceError(f"PUT {path} failed: {data}")
        return data

    # --- CardKit ---

    async def create_card(self, content: dict) -> str:
        """Create a card via CardKit and return card_id."""
        data = await self._post(
            "/open-apis/cardkit/v1/cards",
            {"type": "card_json", "data": json.dumps(content)},
        )
        card_id: str = data["data"]["card_id"]
        logger.debug("created card %s", card_id)
        return card_id

    async def update_card(self, card_id: str, sequence: int, content: dict) -> bool:
        """Update an existing card in-place."""
        try:
            await self._put(
                f"/open-apis/cardkit/v1/cards/{card_id}",
                {
                    "card": {"type": "card_json", "data": json.dumps(content)},
                    "sequence": sequence,
                },
            )
            return True
        except CardServiceError as exc:
            logger.warning("update_card failed: %s", exc)
            return False

    # --- IM messaging ---

    async def send_card(self, chat_id: str, card_id: str) -> str:
        """Send a card to a chat and return message_id."""
        data = await self._post(
            "/open-apis/im/v1/messages?receive_id_type=chat_id",
            {
                "receive_id": chat_id,
                "msg_type": "interactive",
                "content": json.dumps({"type": "card", "data": {"card_id": card_id}}),
            },
        )
        msg_id: str = data["data"]["message_id"]
        logger.debug("sent card %s to chat %s → msg %s", card_id, chat_id, msg_id)
        return msg_id

    async def send_card_direct(self, chat_id: str, card_content: dict) -> str:
        """Send a card directly without using CardKit (bypasses create_card)."""
        legacy_hits = _scan_legacy_tags(card_content)
        if legacy_hits:
            logger.warning("legacy tags detected before normalize: %s", legacy_hits)

        normalized = _normalize_card_tags(card_content)
        normalized_hits = _scan_legacy_tags(normalized)
        if normalized_hits:
            logger.error(
                "legacy tags still present after normalize: %s", normalized_hits
            )

        data = await self._post(
            "/open-apis/im/v1/messages?receive_id_type=chat_id",
            {
                "receive_id": chat_id,
                "msg_type": "interactive",
                "content": json.dumps(normalized),
            },
        )
        msg_id: str = data["data"]["message_id"]
        logger.debug("sent card directly to chat %s → msg %s", chat_id, msg_id)
        return msg_id

    async def send_text(self, chat_id: str, text: str) -> str:
        """Send a plain text message and return message_id."""
        data = await self._post(
            "/open-apis/im/v1/messages?receive_id_type=chat_id",
            {
                "receive_id": chat_id,
                "msg_type": "text",
                "content": json.dumps({"text": text}),
            },
        )
        msg_id: str = data["data"]["message_id"]
        logger.debug("sent text to chat %s → msg %s", chat_id, msg_id)
        return msg_id

    async def send_urgent(self, message_id: str, open_ids: list[str]) -> bool:
        """Send an urgent notification for a message."""
        try:
            await self._post(
                f"/open-apis/im/v1/messages/{message_id}/urgent_app",
                {"user_id_list": open_ids},
            )
            return True
        except CardServiceError as exc:
            logger.warning("send_urgent failed: %s", exc)
            return False

    async def cancel_urgent(self, message_id: str) -> bool:
        """Cancel an urgent notification."""
        try:
            headers = await self._headers()
            resp = await self._client.delete(
                f"/open-apis/im/v1/messages/{message_id}/urgent_app",
                headers=headers,
            )
            return resp.json().get("code") == 0
        except Exception as exc:
            logger.warning("cancel_urgent failed: %s", exc)
            return False
