"""Unified output service for CLI presentation.

This module provides format-aware output that can switch between
Rich terminal output and JSON for scripting/piping.
"""

from enum import Enum
from importlib import import_module

from pydantic import BaseModel

from cli.infrastructure.console import get_console
from cli.infrastructure.formatters.base import Formatter
from cli.infrastructure.formatters.compact_formatter import CompactFormatter
from cli.infrastructure.formatters.json_formatter import JsonFormatter
from cli.infrastructure.formatters.lines_formatter import LinesFormatter
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from cli.infrastructure.renderers.list_renderer import ColumnConfig


class OutputFormat(Enum):
    """Supported output formats."""

    COMPACT = "compact"  # Default: 2-line blocks, copy-friendly, no borders
    JSON = "json"  # Machine-readable JSON
    LINES = "lines"  # Key-value lines format
    TOON = "toon"


class OutputService:
    """Format-aware output service.

    Usage:
        output = OutputService.get()  # Uses global format setting
        output.success("Operation completed")
        output.entity(response, "User Details", USER_FIELDS)
        output.table(items, "Users", USER_COLUMNS)
    """

    _instance: "OutputService | None" = None
    _format: OutputFormat = OutputFormat.COMPACT

    def __init__(self, format: OutputFormat = OutputFormat.COMPACT):
        """Initialize output service with specified format.

        Args:
            format: Output format (compact, json, or lines)
        """
        self.format = format
        self._console = get_console()
        self._formatter = self._create_formatter(format)

    @classmethod
    def configure(cls, format: OutputFormat) -> None:
        """Configure global output format. Call once at app startup.

        Args:
            format: Output format to use globally
        """
        cls._format = format
        cls._instance = None  # Reset singleton

    @classmethod
    def get(cls) -> "OutputService":
        """Get the configured output service instance.

        Returns:
            Singleton OutputService instance
        """
        if cls._instance is None:
            cls._instance = cls(cls._format)
        return cls._instance

    def _create_formatter(self, format: OutputFormat) -> Formatter:
        """Create formatter instance for the specified format.

        Args:
            format: Output format

        Returns:
            Formatter instance
        """
        if format == OutputFormat.JSON:
            return JsonFormatter()
        if format == OutputFormat.LINES:
            return LinesFormatter()
        if format == OutputFormat.TOON:
            module = import_module("cli.infrastructure.formatters.toon_formatter")
            formatter_class = getattr(module, "ToonFormatter")
            return formatter_class()
        # Default: COMPACT
        return CompactFormatter(self._console)

    # Message methods
    def success(self, message: str) -> None:
        """Print a success message.

        Args:
            message: Success message to display
        """
        output = self._formatter.format_success(message)
        self._console.print(output)

    def info(self, message: str) -> None:
        """Print an informational message.

        Args:
            message: Info message to display
        """
        output = self._formatter.format_info(message)
        self._console.print(output)

    def warning(self, message: str) -> None:
        """Print a warning message.

        Args:
            message: Warning message to display
        """
        output = self._formatter.format_warning(message)
        self._console.print(output)

    def status(self, message: str) -> None:
        """Print a status message (dim, no icon).

        Args:
            message: Status message to display
        """
        if self.format == OutputFormat.TOON:
            output = self._formatter.format_info(message)
            self._console.print(output)
            return
        self._console.print(f"[dim]{message}[/dim]")

    # Entity rendering
    def entity(
        self, entity: BaseModel, title: str | None, fields: list[FieldConfig]
    ) -> None:
        """Render a single entity (Pydantic model).

        Args:
            entity: Pydantic model instance to render
            title: Display title for the entity
            fields: Field configurations defining what to show
        """
        from cli.infrastructure.renderers.entity_renderer import EntityRenderer

        renderer = EntityRenderer(self._formatter)
        renderer.render(entity, title, fields)

    # List rendering
    def table(
        self, items: list[BaseModel], title: str | None, columns: list[ColumnConfig]
    ) -> None:
        """Render a list of entities as a table.

        Args:
            items: List of Pydantic model instances
            title: Optional table title
            columns: Column configurations
        """
        from cli.infrastructure.renderers.list_renderer import ListRenderer

        renderer = ListRenderer(self._formatter)
        renderer.render(items, columns, title)

    # Raw console access for complex cases
    @property
    def console(self):
        """Get the underlying console for complex rendering needs.

        Returns:
            Rich Console instance
        """
        return self._console


# Convenience functions for direct usage (uses global singleton)
def print_success(message: str) -> None:
    """Print a success message with checkmark.

    Args:
        message: Success message to display
    """
    OutputService.get().success(message)


def print_info(message: str) -> None:
    """Print an informational message.

    Args:
        message: Info message to display
    """
    OutputService.get().info(message)


def print_warning(message: str) -> None:
    """Print a warning message.

    Args:
        message: Warning message to display
    """
    OutputService.get().warning(message)
