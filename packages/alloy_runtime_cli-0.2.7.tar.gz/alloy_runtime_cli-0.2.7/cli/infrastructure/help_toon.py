from importlib import import_module
from typing import Any


def render_help_toon(payload: dict[str, Any]) -> str:
    try:
        module = import_module("toon_format")
    except ModuleNotFoundError:
        raise ModuleNotFoundError(
            "toon-format is not installed. Install with: "
            "pip install git+https://github.com/toon-format/toon-python.git"
        ) from None
    encode = getattr(module, "encode")
    return str(encode(payload))
