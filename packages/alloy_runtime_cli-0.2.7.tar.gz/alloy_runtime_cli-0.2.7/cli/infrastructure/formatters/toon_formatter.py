from importlib import import_module
from typing import Any

from cli.infrastructure.formatters.base import ColumnMeta, Formatter


def _encode(value: Any) -> str:
    try:
        module = import_module("toon_format")
    except ModuleNotFoundError:
        raise ModuleNotFoundError(
            "toon-format is not installed. Install with: "
            "pip install git+https://github.com/toon-format/toon-python.git"
        ) from None
    encode = getattr(module, "encode")
    return str(encode(value))


class ToonFormatter(Formatter):
    def format_entity(self, data: dict[str, Any], title: str | None = None) -> str:
        return _encode(data)

    def format_list(
        self,
        items: list[dict[str, Any]],
        title: str | None = None,
        columns: list[ColumnMeta] | None = None,
    ) -> str:
        return _encode(items)

    def format_success(self, message: str) -> str:
        return _encode({"status": "success", "message": message})

    def format_info(self, message: str) -> str:
        return _encode({"status": "info", "message": message})

    def format_warning(self, message: str) -> str:
        return _encode({"status": "warning", "message": message})
