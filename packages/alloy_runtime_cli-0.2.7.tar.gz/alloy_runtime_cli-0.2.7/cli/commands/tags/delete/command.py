"""Tag delete command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.tags.delete.presenter import present_delete_result
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import Confirm


def tags_delete_command(
    tag_id: str = typer.Argument(
        ...,
        help="Tag UUID",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation",
    ),
) -> None:
    """Delete a tag.

    Examples:
        alloy tags delete 123e4567-89ab-cdef-0123-456789abcdef
        alloy tags delete 123e4567-89ab... -y
    """
    tag_uuid = validate_uuid(tag_id, "tag")

    if not yes:
        confirmed = Confirm.ask(f"[yellow]Delete tag {tag_id}?[/yellow]")
        if not confirmed:
            raise typer.Abort()

    _execute_delete(tag_id=tag_uuid)


@async_command
async def _execute_delete(tag_id: UUID) -> None:
    """Execute delete tag operation."""
    async with authenticated_client() as (_config, client):
        response = await client.delete_tag(tag_id)

    present_delete_result(response)
