"""Schemas list command implementation."""

from typing import Optional

import typer

from cli.commands.schemas.list.presenter import present_schemas_list
from cli.infrastructure.command import async_command, authenticated_client


def schemas_list_command(
    search: Optional[str] = typer.Option(
        None,
        "-s",
        "--search",
        help="Fuzzy search terms",
    ),
    schema_format: Optional[str] = typer.Option(
        None,
        "--schema-format",
        help="Filter: json_schema or regex",
    ),
    limit: int = typer.Option(
        50,
        "-l",
        "--limit",
        min=1,
        max=100,
        help="Max results",
    ),
    offset: int = typer.Option(
        0,
        "--offset",
        min=0,
        help="Skip N results",
    ),
) -> None:
    """List schemas.

    Examples:
        alloy schemas list
        alloy schemas list -s "user profile"
        alloy schemas list --schema-format json_schema
        alloy schemas list -l 20
    """
    _execute_list(
        search=search, schema_format=schema_format, limit=limit, offset=offset
    )


@async_command
async def _execute_list(
    search: Optional[str], schema_format: Optional[str], limit: int, offset: int
) -> None:
    """Execute list schemas operation."""
    async with authenticated_client() as (_config, client):
        response = await client.list_schemas(
            search=search,
            schema_format=schema_format,
            limit=limit,
            offset=offset,
        )

    present_schemas_list(response)
