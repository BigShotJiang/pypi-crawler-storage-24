"""Pipelines list command implementation."""

from typing import Optional

import typer

from cli.commands.pipelines.list.presenter import present_pipelines_list
from cli.infrastructure.command import async_command, authenticated_client


def pipelines_list_command(
    search: Optional[str] = typer.Option(
        None,
        "-s",
        "--search",
        help="Fuzzy search terms",
    ),
    limit: int = typer.Option(
        50,
        "-l",
        "--limit",
        min=1,
        max=100,
        help="Max results",
    ),
    offset: int = typer.Option(
        0,
        "--offset",
        min=0,
        help="Skip N results",
    ),
) -> None:
    """List pipelines accessible to you.

    Examples:
        alloy pipelines list
        alloy pipelines list -s "content"
        alloy pipelines list -l 20
    """
    _execute_list(search=search, limit=limit, offset=offset)


@async_command
async def _execute_list(search: Optional[str], limit: int, offset: int) -> None:
    """Execute list pipelines operation."""
    async with authenticated_client() as (_config, client):
        response = await client.list_pipelines(
            search=search,
            limit=limit,
            offset=offset,
        )

    present_pipelines_list(response)
