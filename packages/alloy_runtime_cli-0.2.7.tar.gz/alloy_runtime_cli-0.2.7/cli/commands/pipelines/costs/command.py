"""Pipeline costs command implementation."""

from typing import Optional
from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.pipelines.costs.presenter import present_pipeline_costs
from cli.infrastructure.command import async_command, authenticated_client


def pipelines_costs_command(
    pipeline_id: str = typer.Argument(
        ...,
        help="Pipeline UUID",
    ),
    start_date: Optional[str] = typer.Option(
        None,
        "--start",
        help="Start date (ISO 8601, defaults to 30 days ago)",
    ),
    end_date: Optional[str] = typer.Option(
        None,
        "--end",
        help="End date (ISO 8601, defaults to now)",
    ),
) -> None:
    """Get cost summary for a pipeline.

    Examples:
        alloy pipelines costs 123e4567-89ab...
        alloy pipelines costs 123e4567-89ab... --start 2026-01-01 --end 2026-01-31
    """
    pipeline_uuid = validate_uuid(pipeline_id, "pipeline")
    _execute_costs(
        pipeline_id=pipeline_uuid,
        start_date=start_date,
        end_date=end_date,
    )


@async_command
async def _execute_costs(
    pipeline_id: UUID,
    start_date: Optional[str],
    end_date: Optional[str],
) -> None:
    """Execute get pipeline costs operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_pipeline_costs(
            pipeline_id,
            start_date=start_date,
            end_date=end_date,
        )

    present_pipeline_costs(response)
