"""Pipeline schedules list command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.pipelines.schedules.presenter import present_schedules_list
from cli.infrastructure.command import async_command, authenticated_client


def pipelines_schedules_list_command(
    pipeline_id: str = typer.Argument(
        ...,
        help="Pipeline UUID",
    ),
) -> None:
    """List schedules for a pipeline.

    Examples:
        alloy pipelines schedules list 123e4567-89ab...
    """
    pipeline_uuid = validate_uuid(pipeline_id, "pipeline")
    _execute_list(pipeline_id=pipeline_uuid)


@async_command
async def _execute_list(pipeline_id: UUID) -> None:
    """Execute list schedules operation."""
    async with authenticated_client() as (_config, client):
        response = await client.list_pipeline_schedules(pipeline_id)

    present_schedules_list(response)
