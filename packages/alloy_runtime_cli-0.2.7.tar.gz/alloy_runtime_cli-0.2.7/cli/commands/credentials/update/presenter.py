"""Presenter for credential update command output."""

from cli.commands.credentials.update.fields import CREDENTIAL_FIELDS
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.organization_credentials import (
    OrganizationCredentialResponse,
)


def present_credential_update_success(
    credential: OrganizationCredentialResponse,
) -> None:
    """Present a successful credential update with Rich formatting.

    Args:
        credential: Updated credential data from server
    """
    output = OutputService.get()
    output.success(f"Updated credential: {credential.name}")
    output.entity(credential, "Credential Details", CREDENTIAL_FIELDS)
