from pydantic import BaseModel

from alloy_runtime_types.credential_targets import SupportedCredentialTargets

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


class SupportedProviderRow(BaseModel):
    key: str
    category: str


class SupportedToolServiceRow(BaseModel):
    key: str
    category: str


class SupportedToolMappingRow(BaseModel):
    tool_id: str
    org_service_keys: str
    provider_keys: str


def present_supported_credentials(catalog: SupportedCredentialTargets) -> None:
    output = OutputService.get()

    if not any(
        (catalog.inference_providers, catalog.tool_services, catalog.tool_mappings)
    ):
        output.info("No supported credential targets found")
        return

    if catalog.inference_providers:
        output.table(
            items=[
                SupportedProviderRow(key=item.key, category=item.category)
                for item in catalog.inference_providers
            ],
            title=f"Inference Providers ({len(catalog.inference_providers)})",
            columns=[
                ColumnConfig(source_field="key", header_label="Key", compact_line=1),
                ColumnConfig(
                    source_field="category",
                    header_label="Category",
                    compact_line=2,
                    compact_style="dim",
                ),
            ],
        )

    if catalog.tool_services:
        output.table(
            items=[
                SupportedToolServiceRow(key=item.key, category=item.category)
                for item in catalog.tool_services
            ],
            title=f"Tool Services ({len(catalog.tool_services)})",
            columns=[
                ColumnConfig(source_field="key", header_label="Key", compact_line=1),
                ColumnConfig(
                    source_field="category",
                    header_label="Category",
                    compact_line=2,
                    compact_style="dim",
                ),
            ],
        )

    if catalog.tool_mappings:
        output.table(
            items=[
                SupportedToolMappingRow(
                    tool_id=item.tool_id,
                    org_service_keys=_format_values(item.org_service_keys),
                    provider_keys=_format_values(item.provider_keys),
                )
                for item in catalog.tool_mappings
            ],
            title=f"Tool Credential Mapping ({len(catalog.tool_mappings)})",
            columns=[
                ColumnConfig(
                    source_field="tool_id", header_label="Tool", compact_line=1
                ),
                ColumnConfig(
                    source_field="org_service_keys",
                    header_label="Org Service Keys",
                    compact_line=2,
                    compact_style="dim",
                ),
                ColumnConfig(
                    source_field="provider_keys",
                    header_label="Provider Keys",
                    compact_line=3,
                    compact_style="dim",
                ),
            ],
        )


def _format_values(values: tuple[str, ...]) -> str:
    if not values:
        return "-"
    return ", ".join(values)
