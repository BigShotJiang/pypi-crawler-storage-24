"""Content delete command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.content.delete.presenter import present_delete_result
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import Confirm


def content_delete_command(
    content_part_id: str = typer.Argument(
        ...,
        help="Content part UUID",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation",
    ),
) -> None:
    """Delete a content part.

    Examples:
        alloy content delete 019405e0-e000-7000-f100-000000000001
        alloy content delete <id> -y
    """
    content_uuid = validate_uuid(content_part_id, "content")
    _execute_delete(content_part_id=content_uuid, skip_confirm=yes)


@async_command
async def _execute_delete(content_part_id: UUID, skip_confirm: bool) -> None:
    """Execute delete content part operation."""
    if not skip_confirm:
        short_id = str(content_part_id)[:8]
        confirmed = Confirm.ask(
            f"[yellow]Delete content part '{short_id}...'?[/yellow] This cannot be undone"
        )
        if not confirmed:
            raise typer.Abort()

    async with authenticated_client() as (_config, client):
        response = await client.delete_content_part(content_part_id)

    present_delete_result(response)
