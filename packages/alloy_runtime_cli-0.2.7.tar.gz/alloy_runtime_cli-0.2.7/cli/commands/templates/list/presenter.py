"""Presenter for templates list command output."""

from alloy_runtime_types.dtos.templates import ListTemplatesResponse, TagResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_tags(tags: list[TagResponse]) -> str:
    """Format tags for display, truncating if too many.

    Args:
        tags: List of tag responses

    Returns:
        Formatted tags string
    """
    if not tags:
        return "-"
    tag_paths = [t.tag_path for t in tags[:3]]
    result = ", ".join(tag_paths)
    if len(tags) > 3:
        result += f" (+{len(tags) - 3})"
    return result


def present_templates_list(response: ListTemplatesResponse) -> None:
    """Present list of templates with Rich table formatting.

    Args:
        response: List templates response from server
    """
    output = OutputService.get()

    if not response.templates:
        output.info("No templates found")
        return

    # Define table columns with compact layout configuration
    # Line 1 (primary): ID, type, visibility, version - machine-readable data
    # Line 2 (detail): Name, tags - human-readable content
    columns = [
        ColumnConfig(
            source_field="id",
            header_label="UUID",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="content_type_id",
            header_label="Type",
            compact_line=1,
            compact_style="magenta",
        ),
        ColumnConfig(
            source_field="visibility_id",
            header_label="Visibility",
            compact_line=1,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="latest_version_number",
            header_label="Version",
            formatter=lambda x: f"v{x}" if x else "-",
            align="right",
            compact_line=1,
            compact_style="yellow",
        ),
        ColumnConfig(
            source_field="name",
            header_label="Name",
            compact_line=2,
            compact_style="white bold",
        ),
        ColumnConfig(
            source_field="tags",
            header_label="Tags",
            formatter=_format_tags,
            compact_line=2,
            compact_style="dim italic",
        ),
    ]

    # Render table
    output.table(
        items=response.templates,  # type: ignore[arg-type]
        title=f"Templates ({response.total_count})",
        columns=columns,
    )

    # Show pagination info if there's a next page
    if response.cursor:
        output.status(f"Next page: alloy templates list --cursor '{response.cursor}'")
