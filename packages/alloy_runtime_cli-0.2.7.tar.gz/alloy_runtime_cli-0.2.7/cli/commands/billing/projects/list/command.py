"""Billing projects list command implementation."""

import typer

from cli.commands.billing.projects.list.presenter import present_billing_projects_list
from cli.infrastructure.command import async_command, authenticated_client


def billing_projects_list_command(
    limit: int = typer.Option(
        50,
        "-l",
        "--limit",
        min=1,
        max=100,
        help="Max results",
    ),
    offset: int = typer.Option(
        0,
        "--offset",
        min=0,
        help="Skip N results",
    ),
) -> None:
    """List billing projects in your organization.

    Examples:
        alloy billing projects list
        alloy billing projects list -l 10
    """
    _execute_list(limit=limit, offset=offset)


@async_command
async def _execute_list(limit: int, offset: int) -> None:
    """Execute list billing projects operation."""
    async with authenticated_client() as (_config, client):
        response = await client.list_billing_projects()

    present_billing_projects_list(response)
