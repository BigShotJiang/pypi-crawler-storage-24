"""Billing project daily costs command implementation."""

from uuid import UUID

import typer

from cli.commands.billing.costs.daily.presenter import present_billing_daily_costs
from cli.commands.flag_utils import validate_uuid
from cli.infrastructure.command import async_command, authenticated_client


def billing_costs_daily_command(
    project_id: str = typer.Argument(
        ...,
        help="Billing project UUID",
    ),
    start_date: str = typer.Option(
        ...,
        "--from",
        help="Start date (ISO 8601, required)",
    ),
    end_date: str = typer.Option(
        ...,
        "--to",
        help="End date (ISO 8601, required)",
    ),
) -> None:
    """Get daily cost breakdown for a billing project.

    Examples:
        alloy billing costs daily 123e4567-89ab... --from 2026-01-01 --to 2026-01-31
    """
    project_uuid = validate_uuid(project_id, "billing project")
    _execute_daily_costs(
        project_id=project_uuid,
        start_date=start_date,
        end_date=end_date,
    )


@async_command
async def _execute_daily_costs(
    project_id: UUID,
    start_date: str,
    end_date: str,
) -> None:
    """Execute get billing project daily costs operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_billing_project_costs_daily(
            project_id,
            start_date=start_date,
            end_date=end_date,
        )

    present_billing_daily_costs(response)
