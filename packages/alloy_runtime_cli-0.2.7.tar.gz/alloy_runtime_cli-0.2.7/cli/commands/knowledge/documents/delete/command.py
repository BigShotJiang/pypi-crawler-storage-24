"""Knowledge documents delete command implementation."""

import typer

from cli.commands.knowledge.documents.delete.presenter import present_delete_result
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import Confirm


def knowledge_documents_delete_command(
    document: str = typer.Argument(
        ...,
        help="Document UUID",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation",
    ),
) -> None:
    """Delete a document and all its chunks.

    Permanently removes the document and all associated chunks and questions.

    Examples:
        alloy knowledge documents delete 550e8400-e29b-41d4-a716-446655440000
        alloy knowledge documents delete 550e8400-e29b-41d4-a716-446655440000 -y
    """
    _execute_delete(document_id=document, skip_confirm=yes)


@async_command
async def _execute_delete(document_id: str, skip_confirm: bool) -> None:
    """Execute delete document operation."""
    if not skip_confirm:
        confirmed = Confirm.ask(
            f"[yellow]Delete document '{document_id}'?[/yellow] "
            "This will delete all chunks and cannot be undone"
        )
        if not confirmed:
            raise typer.Abort()

    async with authenticated_client() as (_config, client):
        response = await client.delete_document(document_id)

    present_delete_result(response)
