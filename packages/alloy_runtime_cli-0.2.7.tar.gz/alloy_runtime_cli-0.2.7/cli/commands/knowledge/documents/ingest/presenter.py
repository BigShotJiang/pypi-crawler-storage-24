"""Presenter for document ingest output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import IngestDocumentResponse


def present_ingest_success(response: IngestDocumentResponse) -> None:
    """Present successful document ingestion (queued for processing).

    Args:
        response: Document ingestion response from server
    """
    output = OutputService.get()

    if response.document_id is None:
        output.info("Dry run complete - document not persisted")
    else:
        output.info("Document queued for processing")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    if response.document_id is not None:
        table.add_row("Document ID", format_uuid(response.document_id, short=False))
    table.add_row("Title", response.title)
    table.add_row("Status", f"[yellow]{response.status}[/yellow]")

    if response.document_id is not None:
        table.add_row("", "")
        table.add_row(
            "[dim]Next Step[/dim]",
            "[dim]Poll with: alloy knowledge documents get <id>[/dim]",
        )

    panel = Panel(table, title=f"Document: {response.title}", border_style="blue")
    output.console.print(panel)
