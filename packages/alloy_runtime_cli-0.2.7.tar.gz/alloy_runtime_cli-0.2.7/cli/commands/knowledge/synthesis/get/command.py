"""Knowledge synthesis get command implementation."""

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.knowledge.synthesis.get.presenter import present_synthesis_details
from cli.infrastructure.command import async_command, authenticated_client


def knowledge_synthesis_get_command(
    synthesis_id: str = typer.Argument(
        ...,
        help="Synthesis UUID",
    ),
    output: str = typer.Option(
        "panel",
        "-o",
        "--output",
        help="Output format: 'panel' or 'json'",
    ),
) -> None:
    """Get synthesis details.

    Returns the full synthesis details including content (if completed),
    status, staleness information, and source tracking.

    Examples:
        alloy knowledge synthesis get <synthesis-uuid>
        alloy knowledge synthesis get <uuid> --output json
    """
    _execute_get_from_flags(synthesis_id=synthesis_id, output=output)


def _execute_get_from_flags(synthesis_id: str, output: str) -> None:
    """Validate flags and execute get."""
    # Validate synthesis UUID
    validate_uuid(synthesis_id, "synthesis")

    # Validate output format
    output_format = output.lower()
    if output_format not in ("panel", "json"):
        raise typer.BadParameter(
            f"Invalid output format '{output}'. Valid: panel, json"
        )

    _execute_get(synthesis_id, output_format)


@async_command
async def _execute_get(synthesis_id: str, output_format: str) -> None:
    """Execute synthesis get."""
    async with authenticated_client() as (_config, client):
        response = await client.get_synthesis(synthesis_id)

    present_synthesis_details(response, output_format)
