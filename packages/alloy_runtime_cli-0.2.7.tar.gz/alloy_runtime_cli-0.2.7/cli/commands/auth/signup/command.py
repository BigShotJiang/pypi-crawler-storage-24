"""Signup command implementation."""

import typer

from cli.infrastructure.auth_storage import save_credentials
from cli.infrastructure.command import async_command
from cli.infrastructure.config import get_api_url
from cli.infrastructure.console import Confirm, Prompt, get_console
from cli.infrastructure.output import print_info, print_success
from cli.infrastructure.provider_setup import prompt_provider_credentials
from alloy_runtime_sdk.api_client.client import ApiClient
from alloy_runtime_types.dtos.auth import SignupRequest


def signup_command(
    email: str | None = typer.Option(None, "-e", "--email", help="Email address"),
    password: str | None = typer.Option(
        None, "--password", help="Password (avoid: exposes in shell history)"
    ),
    name: str | None = typer.Option(None, "-n", "--name", help="Display name"),
    org_name: str | None = typer.Option(
        None,
        "--org",
        help="Organization name",
    ),
) -> None:
    """Create a new Alloy Runtime account.

    You'll be prompted to set up provider credentials after signup.

    Examples:

        alloy signup
        alloy signup -e user@example.com -n "John Doe" --org "My Company"
    """
    _execute_signup(email, password, name, org_name)


@async_command
async def _execute_signup(
    email: str | None,
    password: str | None,
    name: str | None,
    org_name: str | None,
) -> None:
    """Execute the signup operation.

    Args:
        email: Optional email (will prompt if not provided)
        password: Optional password (will prompt if not provided)
        name: Optional name (will prompt if not provided)
        org_name: Optional organization name
    """
    console = get_console()
    api_url = get_api_url()

    # Prompt for required fields if not provided
    if not email:
        email = Prompt.ask("[cyan]Email address[/cyan]")

    if not name:
        name = Prompt.ask("[cyan]Your name[/cyan]")

    if not password:
        while True:
            password = Prompt.ask("[cyan]Password[/cyan] (min 8 chars)", password=True)
            confirm = Prompt.ask("[cyan]Confirm password[/cyan]", password=True)

            if password != confirm:
                console.print("[red]Passwords do not match. Please try again.[/red]\n")
                continue

            if password and len(password) < 8:
                console.print("[red]Password must be at least 8 characters.[/red]\n")
                continue

            break

    console.print("\n[blue]Creating your account...[/blue]")

    # Create unauthenticated client
    async with ApiClient(base_url=api_url, api_key="") as client:
        response = await client.signup(
            SignupRequest(
                email=email,
                password=password,
                name=name,
                organization_name=org_name,
            )
        )

    # Save credentials
    save_credentials(api_url, response.api_key)

    console.print()
    print_success(f"Account created for {response.name}")
    print_info(f"Email: {response.email}")
    print_info(f"Organization ID: {response.organization_id}")
    print_info("API key saved to ~/.alloy-runtime/config")

    # Prompt for provider setup
    console.print(
        "\n[bold yellow]Let's set up your AI provider credentials[/bold yellow]"
    )
    console.print(
        "[dim]You'll need API keys from providers like OpenAI, Anthropic, or Google.[/dim]\n"
    )

    if Confirm.ask("Set up provider credentials now?", default=True):
        await prompt_provider_credentials(api_url, response.api_key)
    else:
        console.print("\n[dim]You can add provider credentials later with:[/dim]")
        console.print(
            "[dim]  alloy credentials update <credential-id> --value <api-key>[/dim]"
        )
