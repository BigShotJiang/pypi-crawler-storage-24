# Luvia

> **Autonomous AI-Driven Network Penetration Testing Library**

Luvia orchestrates reconnaissance, vulnerability identification, and AI-powered remediation. It uses recursive logic to switch between ports and services until a vulnerability is found or the target is fully mapped.

## Features

- **Stealth Scanning** — SYN scans, fragmentation, decoy IPs for firewall evasion
- **Full Port Audit** — Scan all 65,535 ports with service fingerprinting
- **Autonomous Port Routing** — Automatically dispatches service-specific modules based on open ports
- **CVE Mapping** — Local vulnerability database + NVD API lookups
- **Known Backdoor Detection** — Hard-coded signatures for vsftpd 2.3.4, UnrealIRCd, Samba, etc.
- **Credential Spraying** — Async SSH/FTP/Telnet/HTTP brute-force with IDS evasion
- **Web Security Audit** — Headers, TLS, directory brute-force, WAF detection, CORS checking
- **Traffic Analysis** — TShark pcap parsing with anomaly detection
- **OSINT & Discovery** — Subdomain enumeration, DNS zone transfer, WHOIS, host discovery
- **AI Remediation Brain** — OpenAI / Ollama / HuggingFace integration for intelligent analysis
- **Autonomous Pivoting** — Detect internal networks for lateral movement
- **Professional Reports** — JSON and PDF export with styled formatting

## Prerequisites

Luvia depends on industry-standard security tools that must be installed on your system:

- **Nmap** (Required for all scanning) — [nmap.org](https://nmap.org/download.html)
- **TShark / Wireshark** (Optional, for traffic analysis) — [wireshark.org](https://www.wireshark.org/download.html)
- **Ollama** (Optional, for local AI remediation) — [ollama.com](https://ollama.com/)

## Installation

### Method 1: Docker (One Command, Bundled Dependencies)
This is the **recommended** method as it automatically installs Nmap and TShark for you.

```bash
git clone https://github.com/luvia-team/luvia.git
cd luvia
docker compose up -d  # Spins up Luvia + Ollama
docker compose run luvia audit --target example.com
```

### Method 2: pip (Custom Install)
```bash
pip install luvia
luvia setup   # One-command automated install of Nmap & TShark
luvia check   # Verify everything is ready
```

## Quick Start

```bash
# Stealth scan
luvia scan --target 192.168.1.100 --type stealth

# Full vulnerability audit with AI analysis
luvia audit --target 192.168.1.100 --ai-backend openai --ai-key YOUR_KEY

# Analyse prior results
luvia analyze --input results.json --ai-backend ollama

# Reconnaissance
luvia discover --domain example.com --cidr 192.168.1.0/24

# Export reports
luvia report --input scan_results.json --format both
```

## Architecture

```
luvia/
├── core/
│   ├── scanner.py        # Nmap/Scapy orchestration
│   ├── traffic.py        # TShark/Packet analysis
│   └── discovery.py      # Subdomain and OSINT logic
├── modules/
│   ├── web_audit.py      # HTTP/HTTPS security checks
│   ├── exploit_db.py     # CVE mapping logic
│   └── brute_force.py    # Credential testing
├── brain/
│   ├── ai_client.py      # LLM integration
│   └── remediator.py     # Findings → solutions
├── utils/
│   ├── reporters.py      # JSON/PDF export
│   └── logger.py         # Stealth-compliant logging
├── database/
│   ├── models.py         # Pydantic + SQLAlchemy models
│   └── checklist.json    # Security checklist (25 items)
├── main.py               # CLI entry point
└── __main__.py            # python -m luvia support
```

## Requirements

- Python 3.11+
- Nmap (installed on PATH)
- TShark (for traffic analysis)

## License

MIT
