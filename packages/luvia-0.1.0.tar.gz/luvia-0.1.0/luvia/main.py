"""
Luvia CLI — Command-Line Entry Point.

The primary interface for running Luvia scans, vulnerability assessments,
AI analysis, and report generation from the terminal.
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from typing import Any, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from luvia import __version__

try:
    if sys.stdout and getattr(sys.stdout, 'encoding', '').lower() != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

console = Console()


# ═══════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _run_async(coro: Any) -> Any:
    """Run an async coroutine from synchronous Click context."""
    return asyncio.run(coro)


def _banner() -> None:
    console.print(Panel.fit(
        "[bold cyan]╦  ╦ ╦╦  ╦╦╔═╗[/]\n"
        "[bold cyan]║  ║ ║╚╗╔╝║╠═╣[/]\n"
        "[bold cyan]╩═╝╚═╝ ╚╝ ╩╩ ╩[/]\n"
        f"[dim]v{__version__} — AI-Driven Penetration Testing[/]",
        border_style="cyan",
    ))


# ═══════════════════════════════════════════════════════════════════════════
# CLI Group
# ═══════════════════════════════════════════════════════════════════════════

@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable debug logging")
@click.option("--log-file", type=click.Path(), default=None, help="Log to file")
@click.pass_context
def cli(ctx: click.Context, verbose: bool, log_file: str | None) -> None:
    """Luvia — Autonomous AI-Driven Network Penetration Testing."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["log_file"] = log_file


# ═══════════════════════════════════════════════════════════════════════════
# Check Command
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
def check() -> None:
    """Check for required system dependencies."""
    _banner()
    import shutil
    import subprocess
    
    table = Table(title="Environment & Dependency Check")
    table.add_column("Dependency", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Version / Path", style="dim")

    # Nmap
    from luvia.core.scanner import _find_nmap
    nmap_check = shutil.which("nmap") or _find_nmap()
    if nmap_check:
        try:
            # If shutil.which failed but _find_nmap found it, we need to call it by full path
            cmd = "nmap" if shutil.which("nmap") else nmap_check
            ver = subprocess.check_output([cmd, "--version"], text=True).splitlines()[0]
            table.add_row("Nmap", "[green]INSTALLED[/]", ver)
        except Exception:
            table.add_row("Nmap", "[green]INSTALLED[/]", nmap_check)
    else:
        table.add_row("Nmap", "[red]MISSING[/]", "Install from nmap.org")

    # TShark
    tshark_check = shutil.which("tshark")
    if tshark_check:
        try:
            ver = subprocess.check_output(["tshark", "--version"], text=True).splitlines()[0]
            table.add_row("TShark", "[green]INSTALLED[/]", ver)
        except Exception:
            table.add_row("TShark", "[green]INSTALLED[/]", tshark_check)
    else:
        table.add_row("TShark", "[yellow]MISSING[/]", "Install Wireshark/TShark for traffic audit")

    # Python Version
    table.add_row("Python", "[green]OK[/]", sys.version.split()[0])

    console.print(table)
    
    if not nmap_check:
        console.print("\n[bold red]CRITICAL:[/] Nmap is required for core scanning. Please install it and add to PATH.")
        console.print("[yellow]Tip:[/] Run [bold]luvia setup[/] to attempt automated installation.")
    else:
        console.print("\n[green]Base environment is ready for scanning.[/]")


# ═══════════════════════════════════════════════════════════════════════════
# Setup Command
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
def setup() -> None:
    """Automate system dependency installation (Nmap, TShark)."""
    _banner()
    import platform
    import subprocess
    import shutil

    os_name = platform.system()
    console.print(f"Detected OS: [bold cyan]{os_name}[/]")

    if os_name == "Windows":
        console.print("Attempting Windows installation via [bold]winget[/]...")
        if shutil.which("winget"):
            try:
                subprocess.run(["winget", "install", "-e", "--id", "nmap.nmap"], check=True)
                subprocess.run(["winget", "install", "-e", "--id", "WiresharkFoundation.Wireshark"], check=True)
                console.print("[green]✓ Installation commands dispatched via winget.[/]")
            except subprocess.CalledProcessError:
                console.print("[red]✗ winget installation failed or was cancelled.[/]")
        else:
            console.print("[yellow]! winget not found.[/] Please download manually from [link=https://nmap.org]nmap.org[/].")

    elif os_name == "Linux":
        console.print("Attempting Linux installation via [bold]apt[/]...")
        if shutil.which("apt"):
            try:
                console.print("[yellow]Note: This requires sudo permissions.[/]")
                subprocess.run(["sudo", "apt-get", "update"], check=True)
                subprocess.run(["sudo", "apt-get", "install", "-y", "nmap", "tshark"], check=True)
                console.print("[green]✓ System dependencies installed via apt-get.[/]")
            except subprocess.CalledProcessError:
                console.print("[red]✗ apt installation failed. Please run manually: 'sudo apt install nmap tshark'[/]")
        else:
            console.print("[yellow]! apt not found.[/] Please use your distribution's package manager to install 'nmap' and 'tshark'.")

    elif os_name == "Darwin": # macOS
        console.print("Attempting macOS installation via [bold]Homebrew[/]...")
        if shutil.which("brew"):
            try:
                subprocess.run(["brew", "install", "nmap", "wireshark"], check=True)
                console.print("[green]✓ System dependencies installed via Homebrew.[/]")
            except subprocess.CalledProcessError:
                console.print("[red]✗ Homebrew installation failed.[/]")
        else:
            console.print("[yellow]! Homebrew not found.[/] Please install it first from [link=https://brew.sh]brew.sh[/].")

    else:
        console.print(f"[red]Unsupported OS for automated setup:[/] {os_name}")
        console.print("Please install 'nmap' and 'tshark' manually.")


# ═══════════════════════════════════════════════════════════════════════════
# Scan Command
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--target", "-t", required=True, help="Target IP or hostname")
@click.option("--ports", "-p", default="1-1024", help="Port range (default: 1-1024)")
@click.option(
    "--type", "-T", "scan_type",
    type=click.Choice(["stealth", "full", "service", "os", "fragment", "decoy"]),
    default="stealth",
    help="Scan type",
)
@click.option("--decoys", "-D", default="", help="Comma-separated decoy IPs")
@click.option("--output", "-o", type=click.Path(), default=None, help="Output JSON file")
@click.option("--stealth", is_flag=True, help="Enable stealth mode (SYN scan)")
@click.option("--evasion", is_flag=True, help="Enable evasion techniques")
def scan(
    target: str,
    ports: str,
    scan_type: str,
    decoys: str,
    output: str | None,
    stealth: bool,
    evasion: bool,
) -> None:
    """Run a network scan against a target."""
    _banner()

    async def _scan() -> None:
        from luvia.core.scanner import NmapScanner
        from luvia.utils.reporters import JSONReporter

        scanner = NmapScanner()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Scanning {target}...", total=None)

            if scan_type == "stealth" or stealth:
                result = await scanner.stealth_scan(target, ports)
            elif scan_type == "full":
                result = await scanner.full_audit(target)
            elif scan_type == "service":
                result = await scanner.service_fingerprint(target, ports)
            elif scan_type == "os":
                result = await scanner.os_detection(target)
            elif scan_type == "fragment" or evasion:
                result = await scanner.fragment_scan(target, ports)
            elif scan_type == "decoy":
                decoy_list = [d.strip() for d in decoys.split(",") if d.strip()] or None
                result = await scanner.decoy_scan(target, decoy_list, ports)
            else:
                result = await scanner.stealth_scan(target, ports)

            progress.update(task, description="Scan complete!")

        # Display results
        _display_scan_results(result)

        # Export if requested
        if output:
            JSONReporter.export_scan(result, output)
            console.print(f"\n[green]Results saved to {output}[/]")

    _run_async(_scan())


# ═══════════════════════════════════════════════════════════════════════════
# Audit Command (Full Pipeline)
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--target", "-t", required=True, help="Target IP or hostname")
@click.option("--output-dir", "-o", default="reports", help="Output directory")
@click.option("--ai-backend", default="", help="AI backend (openai/ollama/huggingface)")
@click.option("--ai-model", default="", help="AI model name")
@click.option("--ai-key", default="", help="AI API key")
@click.option("--stealth", is_flag=True, help="Enable stealth scanning")
@click.option("--evasion", is_flag=True, help="Enable evasion techniques")
@click.option("--pivot", is_flag=True, help="Enable autonomous pivoting")
@click.option("--nvd", is_flag=True, help="Enable online NVD API lookups for CVEs (slow without API key)")
@click.option("--exploit", is_flag=True, help="Enable automated credential testing & system audit")
def audit(
    target: str,
    output_dir: str,
    ai_backend: str,
    ai_model: str,
    ai_key: str,
    stealth: bool,
    evasion: bool,
    pivot: bool,
    nvd: bool,
    exploit: bool,
) -> None:
    """Run a full vulnerability assessment pipeline."""
    _banner()

    async def _audit() -> None:
        from luvia.core.scanner import NmapScanner, PortRouter
        from luvia.modules.exploit_db import ExploitDatabase
        from luvia.modules.web_audit import WebAuditor
        from luvia.modules.brute_force import BruteForcer
        from luvia.brain.ai_client import AIClient
        from luvia.brain.remediator import Remediator
        from luvia.utils.reporters import ReportManager

        scanner = NmapScanner()
        exploit_db = ExploitDatabase(nvd_api_key=ai_key if nvd else "")
        web_auditor = WebAuditor()
        bruter = BruteForcer()
        report_mgr = ReportManager(output_dir)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            # Phase 1: Scan
            task = progress.add_task("Phase 1: Scanning target...", total=None)
            if evasion:
                result = await scanner.fragment_scan(target)
            elif stealth:
                result = await scanner.stealth_scan(target)
            else:
                result = await scanner.service_fingerprint(target)
            progress.update(task, description="✓ Scan complete")

            # Phase 2: Vulnerability mapping
            task2 = progress.add_task("Phase 2: Mapping vulnerabilities...", total=None)
            
            # Use a slightly more robust deduplication structure for NVD
            _seen_services: set[str] = set()
            
            for host in result.hosts:
                for port_info in host.ports:
                    if port_info.state.value == "open":
                        svc = port_info.service
                        service_key = f"{svc.product} {svc.name}".strip()
                        
                        # Only query NVD once per unique service/version to save time
                        cache_key = f"{service_key}:{svc.version}"
                        do_nvd = nvd and cache_key not in _seen_services
                        _seen_services.add(cache_key)

                        vulns = await exploit_db.search_cve(
                            service_key,
                            svc.version,
                            use_nvd=do_nvd,
                        )
                        host.vulnerabilities.extend(vulns)

                        # Check known backdoors
                        backdoors = exploit_db.check_known_backdoors(
                            service_key,
                            svc.version,
                        )
                        for bd in backdoors:
                            if bd.cve_id not in {v.cve_id for v in host.vulnerabilities}:
                                host.vulnerabilities.append(bd)

                # Deduplicate vulnerabilities per host across all ports
                seen_vulns = set()
                deduped_vulns = []
                for v in host.vulnerabilities:
                    key = v.cve_id if v.cve_id else v.title
                    if key not in seen_vulns:
                        seen_vulns.add(key)
                        deduped_vulns.append(v)
                host.vulnerabilities = deduped_vulns

            progress.update(task2, description="✓ Vulnerability mapping complete")

            # Phase 3: Web audit for HTTP ports
            task3 = progress.add_task("Phase 3: Web security audit...", total=None)
            for host in result.hosts:
                for port_info in host.ports:
                    if port_info.state.value == "open" and port_info.service.name in ("http", "https"):
                        scheme = "https" if port_info.port == 443 else "http"
                        url = f"{scheme}://{host.ip}:{port_info.port}"
                        try:
                            web_findings = await web_auditor.check_headers(url)
                            host.vulnerabilities.extend(web_findings)
                        except Exception:
                            pass
            progress.update(task3, description="✓ Web audit complete")

            # Phase 3.5: Automated Exploitation
            if exploit:
                task_exp = progress.add_task("Phase 3.5: Validating exploits...", total=None)
                from luvia.database.models import ExploitInfo
                for host in result.hosts:
                    for p in host.ports:
                        if p.state.value == "open":
                            svc_name = p.service.name.lower()
                            if any(x in svc_name for x in ("ssh", "ftp", "telnet", "http")):
                                svc_type = "ssh" if "ssh" in svc_name else \
                                           "ftp" if "ftp" in svc_name else \
                                           "telnet" if "telnet" in svc_name else "http"
                                
                                progress.update(task_exp, description=f"Spraying {svc_type}@{host.ip}...")
                                if svc_type == "ssh":
                                    res_list = await bruter.ssh_spray(host.ip, port=p.port)
                                elif svc_type == "ftp":
                                    res_list = await bruter.ftp_spray(host.ip, port=p.port)
                                elif svc_type == "telnet":
                                    res_list = await bruter.telnet_spray(host.ip, port=p.port)
                                else:
                                    res_list = await bruter.http_basic_spray(f"http://{host.ip}:{p.port}")
                                
                                successes = [r for r in res_list if r.success]
                                if successes:
                                    best = successes[0]
                                    audit_data = {}
                                    if svc_type in ("ssh", "telnet"):
                                        audit_data = await bruter.post_exploit_system_check(
                                            host.ip, p.port, best.username, best.password
                                        )
                                    
                                    host.exploits.append(ExploitInfo(
                                        service=svc_type,
                                        port=p.port,
                                        proof=f"Successful login: {best.username}:{best.password}",
                                        system_audit=audit_data
                                    ))
                progress.update(task_exp, description="✓ Exploitation analysis complete")

            # Phase 4: AI Remediation
            task4 = progress.add_task("Phase 4: AI analysis...", total=None)
            ai_client = None
            if ai_backend:
                try:
                    ai_client = AIClient(
                        backend=ai_backend,
                        model=ai_model,
                        api_key=ai_key,
                    )
                except Exception as exc:
                    console.print(f"[yellow]AI init failed: {exc} — using local analysis[/]")

            remediator = Remediator(ai_client=ai_client)
            remediation = await remediator.generate_report(
                result, use_ai=bool(ai_client),
            )
            progress.update(task4, description="✓ Analysis complete")

            # Phase 5: Autonomous pivoting
            if pivot:
                task5 = progress.add_task("Phase 5: Pivot detection...", total=None)
                from luvia.core.discovery import NetworkMapper
                pivots = NetworkMapper.detect_pivot_targets([result])
                if pivots:
                    console.print(f"\n[bold yellow]Pivot targets found: {pivots}[/]")
                progress.update(task5, description="✓ Pivot analysis complete")

        # Display results
        _display_scan_results(result)
        _display_remediation(remediation)

        # Export
        scan_paths = report_mgr.export_scan(result)
        rem_paths = report_mgr.export_remediation(remediation)
        console.print(f"\n[green]Reports saved to {output_dir}/[/]")
        for fmt, p in {**scan_paths, **rem_paths}.items():
            console.print(f"  • {fmt}: {p}")

    _run_async(_audit())


# ═══════════════════════════════════════════════════════════════════════════
# Analyze Command
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--input", "-i", "input_file", required=True, type=click.Path(exists=True),
              help="Input JSON scan results file")
@click.option("--ai-backend", default="openai", help="AI backend")
@click.option("--ai-model", default="", help="AI model name")
@click.option("--ai-key", default="", help="AI API key")
@click.option("--output", "-o", type=click.Path(), default=None, help="Output file")
def analyze(
    input_file: str,
    ai_backend: str,
    ai_model: str,
    ai_key: str,
    output: str | None,
) -> None:
    """Analyze prior scan results with AI."""
    _banner()

    async def _analyze() -> None:
        from luvia.database.models import ScanResult
        from luvia.brain.ai_client import AIClient
        from luvia.brain.remediator import Remediator
        from luvia.utils.reporters import JSONReporter

        data = json.loads(Path(input_file).read_text(encoding="utf-8"))
        scan_result = ScanResult(**data)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Analyzing with AI...", total=None)

            ai_client = AIClient(backend=ai_backend, model=ai_model, api_key=ai_key)
            remediator = Remediator(ai_client=ai_client)
            report = await remediator.generate_report(scan_result, use_ai=True)

            progress.update(task, description="✓ Analysis complete")

        _display_remediation(report)

        if output:
            JSONReporter.export_remediation(report, output)
            console.print(f"\n[green]Report saved to {output}[/]")

    _run_async(_analyze())


# ═══════════════════════════════════════════════════════════════════════════
# Report Command
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--input", "-i", "input_file", required=True, type=click.Path(exists=True),
              help="Input JSON file (scan or remediation)")
@click.option("--format", "-f", "fmt", type=click.Choice(["json", "pdf", "both"]),
              default="both", help="Output format")
@click.option("--output-dir", "-o", default="reports", help="Output directory")
def report(input_file: str, fmt: str, output_dir: str) -> None:
    """Export scan results or remediation reports."""
    _banner()

    from luvia.database.models import ScanResult, RemediationReport
    from luvia.utils.reporters import ReportManager

    data = json.loads(Path(input_file).read_text(encoding="utf-8"))
    mgr = ReportManager(output_dir)

    formats = ["json", "pdf"] if fmt == "both" else [fmt]

    try:
        scan = ScanResult(**data)
        paths = mgr.export_scan(scan, formats)
        console.print("[green]Scan report exported:[/]")
    except Exception:
        try:
            rem = RemediationReport(**data)
            paths = mgr.export_remediation(rem, formats)
            console.print("[green]Remediation report exported:[/]")
        except Exception as exc:
            console.print(f"[red]Failed to parse input: {exc}[/]")
            return

    for f, p in paths.items():
        console.print(f"  • {f}: {p}")


# ═══════════════════════════════════════════════════════════════════════════
# Discover Command
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--domain", "-d", default="", help="Domain for subdomain enumeration")
@click.option("--cidr", "-c", default="", help="CIDR range for host discovery")
@click.option("--whois", "-w", default="", help="Target for WHOIS lookup")
def discover(domain: str, cidr: str, whois: str) -> None:
    """Run reconnaissance discovery modules."""
    _banner()

    async def _discover() -> None:
        from luvia.core.discovery import SubdomainEnumerator, OSINTGatherer, NetworkMapper

        if domain:
            console.print(f"\n[bold]Subdomain Enumeration: {domain}[/]")
            enumerator = SubdomainEnumerator()
            results = await enumerator.brute_force(domain)
            table = Table(title="Subdomains Found")
            table.add_column("Subdomain", style="cyan")
            table.add_column("IP", style="green")
            for r in results:
                table.add_row(r["subdomain"], r["ip"])
            console.print(table)

        if cidr:
            console.print(f"\n[bold]Host Discovery: {cidr}[/]")
            mapper = NetworkMapper()
            hosts = await mapper.discover_hosts(cidr)
            table = Table(title="Live Hosts")
            table.add_column("IP", style="cyan")
            table.add_column("Status", style="green")
            for h in hosts:
                table.add_row(h["ip"], h["status"])
            console.print(table)

        if whois:
            console.print(f"\n[bold]WHOIS Lookup: {whois}[/]")
            gatherer = OSINTGatherer()
            data = await gatherer.whois_lookup(whois)
            for k, v in data.items():
                if k != "raw":
                    console.print(f"  [cyan]{k}[/]: {v}")

    _run_async(_discover())


# ═══════════════════════════════════════════════════════════════════════════
# Exploit Command
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--target", "-t", help="Target IP or hostname")
@click.option("--port", "-p", type=int, help="Target port")
@click.option(
    "--service", "-s", type=click.Choice(["ssh", "ftp", "telnet", "http"]),
    help="Service type to exploit"
)
@click.option("--input", "-i", "input_file", type=click.Path(exists=True),
              help="Input JSON scan results to auto-exploit")
@click.option("--user-list", type=click.Path(exists=True), help="Path to username wordlist")
@click.option("--pass-list", type=click.Path(exists=True), help="Path to password wordlist")
@click.option("--max-attempts", default=0, help="Stop after N attempts (0 = unlimited)")
@click.option("--auto-post", is_flag=True, help="Automatically run system audit on success")
def exploit(
    target: str | None,
    port: int | None,
    service: str | None,
    input_file: str | None,
    user_list: str | None,
    pass_list: str | None,
    max_attempts: int,
    auto_post: bool,
) -> None:
    """Validate and exploit discovered vulnerabilities."""
    _banner()

    async def _exploit() -> None:
        from luvia.modules.brute_force import BruteForcer, CredentialManager
        from luvia.database.models import ScanResult

        bruter = BruteForcer(max_attempts=max_attempts)
        users = await CredentialManager.load_wordlist(user_list) if user_list else None
        pws = await CredentialManager.load_wordlist(pass_list) if pass_list else None

        targets: list[dict[str, Any]] = []

        if input_file:
            data = json.loads(Path(input_file).read_text(encoding="utf-8"))
            res = ScanResult(**data)
            for host in res.hosts:
                for p in host.ports:
                    if p.state.value == "open":
                        svc_name = p.service.name.lower()
                        if any(x in svc_name for x in ("ssh", "ftp", "telnet", "http")):
                            targets.append({
                                "host": host.ip,
                                "port": p.port,
                                "service": "ssh" if "ssh" in svc_name else
                                           "ftp" if "ftp" in svc_name else
                                           "telnet" if "telnet" in svc_name else "http"
                            })
        elif target and port and service:
            targets.append({"host": target, "port": port, "service": service})
        else:
            console.print("[red]Error: Specify --target/--port/--service OR --input[/]")
            return

        if not targets:
            console.print("[yellow]No exploitable services found in target list.[/]")
            return

        for job in targets:
            host, port, svc = job["host"], job["port"], job["service"]
            console.print(f"\n[bold cyan]Exploiting {svc} on {host}:{port}...[/]")
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task(f"Spraying {svc} credentials...", total=None)
                
                results = []
                if svc == "ssh":
                    results = await bruter.ssh_spray(host, users, pws, port)
                elif svc == "ftp":
                    results = await bruter.ftp_spray(host, users, pws, port)
                elif svc == "telnet":
                    results = await bruter.telnet_spray(host, users, pws, port)
                elif svc == "http":
                    url = f"http://{host}:{port}"
                    results = await bruter.http_basic_spray(url, users, pws)

                successes = [r for r in results if r.success]
                progress.update(task, description=f"✓ {svc} spray complete")

                if successes:
                    console.print(f"[bold green]SUCCESS![/] Valid credentials found for {svc}@{host}:")
                    for s in successes:
                        console.print(f"  - {s.username}:{s.password}")

                    if auto_post and svc in ("ssh", "telnet"):
                        task_post = progress.add_task("Running post-exploit system audit...", total=None)
                        # We use the first successful credential
                        best = successes[0]
                        audit = await bruter.post_exploit_system_check(
                            host, port, best.username, best.password
                        )
                        progress.update(task_post, description="✓ System audit complete")
                        
                        _display_post_exploit(audit)
                else:
                    console.print(f"[dim]No credentials found for {svc}.[/]")

    _run_async(_exploit())


def _display_post_exploit(audit: dict[str, Any]) -> None:
    """Display post-exploitation system audit findings."""
    if "error" in audit:
        console.print(f"[red]Audit failed: {audit['error']}[/]")
        return

    console.print(f"\n[bold]Post-Exploitation System Audit — {audit['host']}[/]")
    console.print(f"  Kernel: [yellow]{audit.get('kernel', 'unknown')}[/]")
    
    table = Table(title="Security Configuration Audit", border_style="red")
    table.add_column("Check", style="cyan")
    table.add_column("Result", style="white")
    table.add_column("Recommendation", style="green")

    for check in audit.get("checks", []):
        name = check["check"].replace("_", " ").title()
        if "users" in check:
            val = ", ".join(check["users"]) or "None"
        elif "count" in check:
            val = f"Found {check['count']} items"
        else:
            val = str(check.get("value", "N/A"))
            
        table.add_row(name, val, check.get("recommendation", ""))
    
    console.print(table)
    
    # List files if available
    for check in audit.get("checks", []):
        if check.get("files"):
            console.print(f"\n[bold red]Samples for {check['check']}:[/]")
            for f in check["files"]:
                console.print(f"  [dim]- {f}[/]")


# ═══════════════════════════════════════════════════════════════════════════
# Display Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _display_scan_results(result: Any) -> None:
    """Render scan results as a Rich table."""
    from luvia.database.models import ScanResult

    console.print(f"\n[bold]Scan Results — {result.target}[/]")
    console.print(f"  Scan ID:  {result.scan_id}")
    console.print(f"  Type:     {result.scan_type.value}")
    console.print(f"  Hosts:    {len(result.hosts)}")

    for host in result.hosts:
        table = Table(title=f"Host: {host.ip} ({host.hostname or 'N/A'})")
        table.add_column("Port", style="cyan", justify="right")
        table.add_column("State", style="green")
        table.add_column("Service", style="yellow")
        table.add_column("Version", style="magenta")

        for p in host.ports:
            table.add_row(
                str(p.port),
                p.state.value,
                p.service.name,
                f"{p.service.product} {p.service.version}".strip() or "—",
            )
        console.print(table)

        if host.vulnerabilities:
            vuln_table = Table(title="Vulnerabilities", border_style="red")
            vuln_table.add_column("CVE", style="red")
            vuln_table.add_column("Risk", style="bold")
            vuln_table.add_column("Title")
            vuln_table.add_column("CVSS", justify="right")

            risk_colors = {
                "critical": "bold red", "high": "red",
                "medium": "yellow", "low": "green", "info": "dim",
            }
            for v in host.vulnerabilities:
                style = risk_colors.get(v.risk_level.value, "")
                vuln_table.add_row(
                    v.cve_id or "—",
                    f"[{style}]{v.risk_level.value.upper()}[/]",
                    v.title,
                    f"{v.cvss_score:.1f}" if v.cvss_score else "—",
                )
            console.print(vuln_table)


def _display_remediation(report: Any) -> None:
    """Render a remediation report as Rich panels."""
    from luvia.database.models import RemediationReport

    risk_colors = {
        "critical": "red", "high": "red",
        "medium": "yellow", "low": "green", "info": "dim",
    }

    console.print(f"\n[bold]AI Remediation Report[/]")
    console.print(f"  Overall Risk: [{risk_colors.get(report.overall_risk.value, '')}]"
                  f"{report.overall_risk.value.upper()}[/]")
    console.print(f"  Summary: {report.summary}")

    for idx, item in enumerate(report.items, 1):
        color = risk_colors.get(item.risk_level.value, "white")
        console.print(Panel(
            f"[bold]Finding:[/] {item.finding}\n"
            f"[bold]Risk:[/] [{color}]{item.risk_level.value.upper()}[/]\n"
            f"[bold]Logic:[/] {item.logic}\n"
            f"[bold]Fix:[/] {item.remediation}\n"
            + (f"[bold]Checklist:[/] {item.checklist_ref}" if item.checklist_ref else ""),
            title=f"[{color}]#{idx}[/]",
            border_style=color,
        ))


# ═══════════════════════════════════════════════════════════════════════════
# Module entry point
# ═══════════════════════════════════════════════════════════════════════════

def main() -> None:
    """Package entry point for ``python -m luvia``."""
    cli()


if __name__ == "__main__":
    main()
