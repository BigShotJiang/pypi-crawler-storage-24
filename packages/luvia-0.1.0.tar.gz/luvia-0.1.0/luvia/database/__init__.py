"""Database layer — models, persistence, and security checklist data."""
