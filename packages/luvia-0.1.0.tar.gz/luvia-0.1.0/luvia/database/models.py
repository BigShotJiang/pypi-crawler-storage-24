"""
Data Models for Luvia — Pydantic validation & SQLAlchemy persistence.

Security Principle:
    All scan data flows through validated Pydantic models before persistence
    or analysis, preventing injection of malformed data into the pipeline.
    SQLAlchemy models provide persistent scan history for trend analysis.
"""

from __future__ import annotations

import enum
from datetime import datetime, timezone
from typing import Any, Optional

from pydantic import BaseModel, Field
from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    create_engine,
)
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, relationship


# ═══════════════════════════════════════════════════════════════════════════
# Enumerations
# ═══════════════════════════════════════════════════════════════════════════

class RiskLevel(str, enum.Enum):
    """Vulnerability severity classification."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ScanType(str, enum.Enum):
    """Supported scan methodologies."""
    STEALTH = "stealth"
    FULL = "full"
    SERVICE = "service"
    OS_DETECT = "os_detect"
    FRAGMENT = "fragment"
    DECOY = "decoy"
    CUSTOM_NSE = "custom_nse"


class PortState(str, enum.Enum):
    """Port status classification."""
    OPEN = "open"
    CLOSED = "closed"
    FILTERED = "filtered"
    OPEN_FILTERED = "open|filtered"


# ═══════════════════════════════════════════════════════════════════════════
# Pydantic Models (validation & serialisation)
# ═══════════════════════════════════════════════════════════════════════════

class ServiceInfo(BaseModel):
    """Detected service running on a port."""
    name: str = Field(default="unknown", description="Service name (e.g. ssh, http)")
    product: str = Field(default="", description="Product name (e.g. OpenSSH)")
    version: str = Field(default="", description="Version string (e.g. 8.9p1)")
    extra_info: str = Field(default="", description="Additional service information")
    os_type: str = Field(default="", description="Detected operating system")
    cpe: str = Field(default="", description="Common Platform Enumeration identifier")


class PortInfo(BaseModel):
    """Information about a single scanned port."""
    port: int = Field(ge=0, le=65535, description="Port number")
    protocol: str = Field(default="tcp", description="Transport protocol")
    state: PortState = Field(description="Port state")
    service: ServiceInfo = Field(default_factory=ServiceInfo)
    scripts: dict[str, str] = Field(default_factory=dict, description="NSE script output")


class VulnerabilityInfo(BaseModel):
    """A discovered vulnerability linked to a service."""
    cve_id: str = Field(default="", description="CVE identifier (e.g. CVE-2011-2523)")
    title: str = Field(description="Short vulnerability description")
    risk_level: RiskLevel = Field(description="Assessed severity")
    cvss_score: float = Field(default=0.0, ge=0.0, le=10.0, description="CVSS v3 score")
    description: str = Field(default="", description="Detailed explanation")
    remediation: str = Field(default="", description="Suggested remediation steps")
    references: list[str] = Field(default_factory=list, description="Reference URLs")
    affected_service: str = Field(default="", description="Service/version affected")
    checklist_id: str = Field(default="", description="Mapped checklist guidance SLNO")


class HostInfo(BaseModel):
    """Aggregated scan results for a single host."""
    ip: str = Field(description="Target IP address")
    hostname: str = Field(default="", description="Resolved hostname")
    state: str = Field(default="up", description="Host status")
    os_matches: list[str] = Field(default_factory=list, description="OS detection results")
    ports: list[PortInfo] = Field(default_factory=list)
    vulnerabilities: list[VulnerabilityInfo] = Field(default_factory=list)
    exploits: list[ExploitInfo] = Field(default_factory=list, description="Verified exploitation proofs")


class ScanResult(BaseModel):
    """Complete scan result for one or more hosts."""
    scan_id: str = Field(description="Unique scan identifier")
    scan_type: ScanType = Field(description="Scan methodology used")
    target: str = Field(description="Original target specification")
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: Optional[datetime] = Field(default=None)
    hosts: list[HostInfo] = Field(default_factory=list)
    raw_output: str = Field(default="", description="Raw tool output for forensics")
    metadata: dict[str, Any] = Field(default_factory=dict)


class CredentialResult(BaseModel):
    """Result of a credential spray attempt."""
    target: str
    port: int
    service: str
    username: str
    password: str
    success: bool
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    error: str = Field(default="")


class ExploitInfo(BaseModel):
    """Verified exploitation proof and system audit data."""
    service: str = Field(description="Exploited service (e.g. ssh, ftp)")
    port: int = Field(description="Exploited port")
    method: str = Field(default="credential_spray", description="Exploitation method used")
    proof: str = Field(description="Proof of access (e.g. 'Successful login as root')")
    system_audit: dict[str, Any] = Field(default_factory=dict, description="Post-exploitation findings")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class RemediationItem(BaseModel):
    """A single AI-generated remediation recommendation."""
    finding: str = Field(description="What was found")
    risk_level: RiskLevel = Field(description="Severity classification")
    logic: str = Field(description="Why this is a threat")
    remediation: str = Field(description="Exact commands / steps to fix")
    checklist_ref: str = Field(default="", description="Matched checklist guidance ID")


class RemediationReport(BaseModel):
    """Complete AI remediation report for a scan."""
    scan_id: str
    target: str
    generated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    summary: str = Field(default="")
    items: list[RemediationItem] = Field(default_factory=list)
    overall_risk: RiskLevel = Field(default=RiskLevel.INFO)
    hosts: list[HostInfo] = Field(default_factory=list, description="Raw hosts and port findings")


class TrafficAnomaly(BaseModel):
    """Detected anomaly in traffic analysis."""
    protocol: str
    source: str
    destination: str
    packet_count: int
    anomaly_type: str = Field(description="Type of anomaly detected")
    severity: RiskLevel = Field(default=RiskLevel.MEDIUM)
    details: str = Field(default="")


# ═══════════════════════════════════════════════════════════════════════════
# SQLAlchemy ORM Models (persistence)
# ═══════════════════════════════════════════════════════════════════════════

class Base(DeclarativeBase):
    """SQLAlchemy declarative base for Luvia ORM models."""
    pass


class ScanHistory(Base):
    """Persistent record of every scan execution."""

    __tablename__ = "scan_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    scan_id = Column(String(64), unique=True, nullable=False, index=True)
    scan_type = Column(Enum(ScanType), nullable=False)
    target = Column(String(256), nullable=False)
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    finished_at = Column(DateTime, nullable=True)
    host_count = Column(Integer, default=0)
    port_count = Column(Integer, default=0)
    vuln_count = Column(Integer, default=0)
    raw_result = Column(JSON, nullable=True)
    metadata_json = Column(JSON, nullable=True)

    findings = relationship("Finding", back_populates="scan", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<ScanHistory(scan_id={self.scan_id!r}, target={self.target!r})>"


class Finding(Base):
    """Individual vulnerability finding persisted to the database."""

    __tablename__ = "findings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    scan_id = Column(String(64), ForeignKey("scan_history.scan_id"), nullable=False)
    host = Column(String(256), nullable=False)
    port = Column(Integer, nullable=True)
    service = Column(String(128), nullable=True)
    cve_id = Column(String(32), nullable=True)
    title = Column(String(512), nullable=False)
    risk_level = Column(Enum(RiskLevel), nullable=False)
    cvss_score = Column(Float, default=0.0)
    description = Column(Text, nullable=True)
    remediation = Column(Text, nullable=True)
    discovered_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    scan = relationship("ScanHistory", back_populates="findings")

    def __repr__(self) -> str:
        return f"<Finding(cve={self.cve_id!r}, host={self.host!r}, risk={self.risk_level!r})>"


# ═══════════════════════════════════════════════════════════════════════════
# Database Manager
# ═══════════════════════════════════════════════════════════════════════════

class DatabaseManager:
    """Async database session manager.

    Usage::

        db = DatabaseManager("sqlite+aiosqlite:///luvia.db")
        await db.initialize()
        async with db.session() as session:
            session.add(scan_record)
            await session.commit()
    """

    def __init__(self, url: str = "sqlite+aiosqlite:///luvia.db") -> None:
        self._engine = create_async_engine(url, echo=False)
        self._session_factory = async_sessionmaker(self._engine, expire_on_commit=False)

    async def initialize(self) -> None:
        """Create all tables if they do not exist."""
        async with self._engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    def session(self) -> AsyncSession:
        """Return a new async session."""
        return self._session_factory()

    async def close(self) -> None:
        """Dispose of the engine connection pool."""
        await self._engine.dispose()
