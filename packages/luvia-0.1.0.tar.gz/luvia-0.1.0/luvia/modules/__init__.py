"""Service-specific vulnerability and entry modules."""
