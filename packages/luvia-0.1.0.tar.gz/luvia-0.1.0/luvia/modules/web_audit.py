"""
Web Auditor — HTTP/HTTPS Security Checks for Luvia.

Security Principle:
    Web services are the most commonly exposed attack surface.  This module
    checks security headers, TLS configuration, directory exposure, WAF
    presence, and CORS misconfiguration to identify low-hanging fruit
    that attackers exploit first.
"""

from __future__ import annotations

import asyncio
import ssl
import socket
from datetime import datetime, timezone
from typing import Any, Optional
from pathlib import Path

import httpx

from luvia.database.models import RiskLevel, VulnerabilityInfo
from luvia.utils.logger import setup_logger

_log = setup_logger("luvia.modules.web_audit")


# ═══════════════════════════════════════════════════════════════════════════
# Security Header Definitions
# ═══════════════════════════════════════════════════════════════════════════

_REQUIRED_HEADERS: dict[str, dict[str, Any]] = {
    "strict-transport-security": {
        "label": "HTTP Strict Transport Security (HSTS)",
        "risk": RiskLevel.HIGH,
        "guidance": "Enforces HTTPS and prevents SSL stripping attacks.",
    },
    "content-security-policy": {
        "label": "Content Security Policy (CSP)",
        "risk": RiskLevel.MEDIUM,
        "guidance": "Mitigates XSS by restricting resource origins.",
    },
    "x-frame-options": {
        "label": "X-Frame-Options",
        "risk": RiskLevel.MEDIUM,
        "guidance": "Prevents clickjacking via iframe embedding.",
    },
    "x-content-type-options": {
        "label": "X-Content-Type-Options",
        "risk": RiskLevel.LOW,
        "guidance": "Prevents MIME-type sniffing.",
    },
    "x-xss-protection": {
        "label": "X-XSS-Protection",
        "risk": RiskLevel.LOW,
        "guidance": "Legacy XSS filter (superseded by CSP).",
    },
    "referrer-policy": {
        "label": "Referrer-Policy",
        "risk": RiskLevel.LOW,
        "guidance": "Controls referrer information leakage.",
    },
    "permissions-policy": {
        "label": "Permissions-Policy",
        "risk": RiskLevel.MEDIUM,
        "guidance": "Restricts browser feature access (camera, mic, geolocation).",
    },
}

_DANGEROUS_HEADERS: list[str] = [
    "server", "x-powered-by", "x-aspnet-version", "x-aspnetmvc-version",
]

_WEAK_TLS = {"SSLv2", "SSLv3", "TLSv1", "TLSv1.0", "TLSv1.1"}

_COMMON_DIRS: list[str] = [
    "admin", "login", "dashboard", "wp-admin", "wp-login.php",
    "phpmyadmin", "cpanel", "webmail", ".env", ".git", ".htaccess",
    "robots.txt", "sitemap.xml", "backup", "config", "api", "swagger",
    "graphql", "debug", "test", "staging", "uploads", "server-status",
    "server-info", "elmah.axd", "trace.axd",
]

# Patterns observed in WAF responses
_WAF_SIGNATURES: dict[str, list[str]] = {
    "Cloudflare": ["cf-ray", "cloudflare"],
    "AWS WAF": ["aws", "x-amzn-requestid"],
    "Akamai": ["akamai", "x-akamai-transformed"],
    "Imperva": ["incap_ses", "visid_incap"],
    "ModSecurity": ["mod_security", "modsecurity"],
    "Sucuri": ["sucuri", "x-sucuri-id"],
    "F5 BIG-IP": ["bigipserver", "x-wa-info"],
}


class WebAuditor:
    """Comprehensive HTTP/HTTPS security assessment.

    Attributes:
        timeout:    Request timeout in seconds.
        user_agent: User-Agent string for requests.
    """

    DEFAULT_UA = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    )

    def __init__(
        self,
        timeout: float = 10.0,
        user_agent: str = "",
    ) -> None:
        self.timeout = timeout
        self.user_agent = user_agent or self.DEFAULT_UA

    def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            timeout=self.timeout,
            verify=False,
            follow_redirects=True,
            headers={"User-Agent": self.user_agent},
        )

    # ── Security Header Analysis ──────────────────────────────────

    async def check_headers(self, url: str) -> list[VulnerabilityInfo]:
        """Analyse HTTP response headers for missing security controls.

        Returns:
            List of :class:`VulnerabilityInfo` for each missing/weak header.
        """
        findings: list[VulnerabilityInfo] = []
        async with self._client() as client:
            try:
                resp = await client.get(url)
                headers_lower = {k.lower(): v for k, v in resp.headers.items()}
            except httpx.HTTPError as exc:
                _log.error(f"Header check failed for {url}: {exc}")
                return findings

        # Missing security headers
        for hdr, meta in _REQUIRED_HEADERS.items():
            if hdr not in headers_lower:
                findings.append(VulnerabilityInfo(
                    title=f"Missing {meta['label']}",
                    risk_level=meta["risk"],
                    description=meta["guidance"],
                    remediation=f"Add '{hdr}' header to server configuration.",
                    affected_service=url,
                    checklist_id="SLNO-17",
                ))

        # Information-leaking headers
        for hdr in _DANGEROUS_HEADERS:
            if hdr in headers_lower:
                findings.append(VulnerabilityInfo(
                    title=f"Information Disclosure via '{hdr}' header",
                    risk_level=RiskLevel.LOW,
                    description=f"Header value: {headers_lower[hdr]}",
                    remediation=f"Remove or suppress the '{hdr}' header.",
                    affected_service=url,
                ))

        _log.info(f"Header audit on {url}: {len(findings)} finding(s)")
        return findings

    # ── TLS / SSL Analysis ────────────────────────────────────────

    async def check_ssl(
        self, host: str, port: int = 443
    ) -> list[VulnerabilityInfo]:
        """Examine TLS version, cipher suite, and certificate validity.

        Returns:
            List of SSL/TLS-related findings.
        """
        findings: list[VulnerabilityInfo] = []
        loop = asyncio.get_running_loop()

        def _inspect() -> list[VulnerabilityInfo]:
            local_findings: list[VulnerabilityInfo] = []
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            try:
                with socket.create_connection((host, port), timeout=self.timeout) as sock:
                    with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                        version = ssock.version() or ""
                        cipher = ssock.cipher() or ("", "", 0)
                        cert = ssock.getpeercert(binary_form=False)

                        # Weak TLS version
                        if version in _WEAK_TLS:
                            local_findings.append(VulnerabilityInfo(
                                title=f"Weak TLS version: {version}",
                                risk_level=RiskLevel.HIGH,
                                description=f"Server supports {version} which is deprecated.",
                                remediation="Disable TLS 1.0/1.1 and SSLv3; enforce TLS 1.2+.",
                                affected_service=f"{host}:{port}",
                                checklist_id="SLNO-06",
                            ))

                        # Weak cipher
                        if cipher[2] and cipher[2] < 128:
                            local_findings.append(VulnerabilityInfo(
                                title=f"Weak cipher suite: {cipher[0]}",
                                risk_level=RiskLevel.MEDIUM,
                                description=f"Cipher key length is {cipher[2]} bits.",
                                remediation="Configure strong cipher suites (AES-256, ChaCha20).",
                                affected_service=f"{host}:{port}",
                                checklist_id="SLNO-06",
                            ))

                        # Certificate expiry
                        if cert:
                            not_after = cert.get("notAfter", "")
                            if not_after:
                                try:
                                    expiry = datetime.strptime(
                                        not_after, "%b %d %H:%M:%S %Y %Z"
                                    )
                                    if expiry < datetime.now():
                                        local_findings.append(VulnerabilityInfo(
                                            title="Expired SSL/TLS certificate",
                                            risk_level=RiskLevel.CRITICAL,
                                            description=f"Certificate expired on {not_after}.",
                                            remediation="Renew the TLS certificate immediately.",
                                            affected_service=f"{host}:{port}",
                                        ))
                                except ValueError:
                                    pass

            except (ssl.SSLError, socket.error, OSError) as exc:
                _log.warning(f"SSL check failed for {host}:{port}: {exc}")

            return local_findings

        findings = await loop.run_in_executor(None, _inspect)
        _log.info(f"SSL audit on {host}:{port}: {len(findings)} finding(s)")
        return findings

    # ── Directory Brute-Force ─────────────────────────────────────

    async def directory_brute(
        self,
        url: str,
        wordlist: list[str] | None = None,
        concurrency: int = 20,
    ) -> list[dict[str, Any]]:
        """Enumerate common directories and files.

        Args:
            url:         Base URL (e.g. ``https://example.com``).
            wordlist:    Custom paths to check; defaults to :data:`_COMMON_DIRS`.
            concurrency: Maximum simultaneous requests.

        Returns:
            List of ``{"path": …, "status": …, "length": …}`` dicts for
            paths that returned non-404 responses.
        """
        paths = wordlist or _COMMON_DIRS
        base = url.rstrip("/")
        semaphore = asyncio.Semaphore(concurrency)
        found: list[dict[str, Any]] = []

        async with self._client() as client:
            async def _check(path: str) -> None:
                async with semaphore:
                    try:
                        resp = await client.get(f"{base}/{path}")
                        if resp.status_code != 404:
                            found.append({
                                "path": f"/{path}",
                                "status": resp.status_code,
                                "length": len(resp.content),
                            })
                    except httpx.HTTPError:
                        pass

            await asyncio.gather(*[_check(p) for p in paths])

        _log.info(f"Directory brute on {url}: {len(found)} non-404 path(s)")
        return found

    # ── WAF Detection ─────────────────────────────────────────────

    async def detect_waf(self, url: str) -> dict[str, Any]:
        """Attempt to fingerprint Web Application Firewalls.

        Returns:
            Dict with ``detected`` (bool) and ``waf_name`` if identified.
        """
        result: dict[str, Any] = {"url": url, "detected": False, "waf_name": ""}

        async with self._client() as client:
            try:
                # Normal request
                resp = await client.get(url)
                headers_str = " ".join(
                    f"{k}={v}" for k, v in resp.headers.items()
                ).lower()

                for waf_name, sigs in _WAF_SIGNATURES.items():
                    if any(sig in headers_str for sig in sigs):
                        result["detected"] = True
                        result["waf_name"] = waf_name
                        break

                # Trigger-based detection: malicious-looking request
                if not result["detected"]:
                    trigger_url = f"{url}/?q=<script>alert(1)</script>"
                    try:
                        trigger_resp = await client.get(trigger_url)
                        if trigger_resp.status_code in (403, 406, 429, 503):
                            result["detected"] = True
                            result["waf_name"] = "Unknown (behavioral)"
                    except httpx.HTTPError:
                        result["detected"] = True
                        result["waf_name"] = "Unknown (connection reset)"

            except httpx.HTTPError as exc:
                _log.warning(f"WAF detection failed for {url}: {exc}")

        if result["detected"]:
            _log.info(f"WAF detected on {url}: {result['waf_name']}")
        return result

    # ── CORS Misconfiguration ─────────────────────────────────────

    async def check_cors(self, url: str) -> list[VulnerabilityInfo]:
        """Test for permissive CORS configurations.

        Returns:
            List of CORS-related findings.
        """
        findings: list[VulnerabilityInfo] = []
        evil_origins = [
            "https://evil.com",
            "null",
            url.replace("https://", "https://evil."),
        ]

        async with self._client() as client:
            for origin in evil_origins:
                try:
                    resp = await client.get(
                        url, headers={"Origin": origin}
                    )
                    acao = resp.headers.get("access-control-allow-origin", "")

                    if acao == "*":
                        findings.append(VulnerabilityInfo(
                            title="Wildcard CORS: Access-Control-Allow-Origin: *",
                            risk_level=RiskLevel.MEDIUM,
                            description="Any origin can read responses from this endpoint.",
                            remediation="Restrict CORS to specific trusted origins.",
                            affected_service=url,
                            checklist_id="SLNO-18",
                        ))
                        break

                    if acao == origin and origin != url:
                        findings.append(VulnerabilityInfo(
                            title=f"CORS reflects untrusted origin: {origin}",
                            risk_level=RiskLevel.HIGH,
                            description="Server reflects arbitrary Origin headers, enabling data theft.",
                            remediation="Whitelist trusted origins; do not reflect the Origin header.",
                            affected_service=url,
                            checklist_id="SLNO-18",
                        ))
                        break
                except httpx.HTTPError:
                    continue

        _log.info(f"CORS audit on {url}: {len(findings)} finding(s)")
        return findings

    # ── Full Web Audit ────────────────────────────────────────────

    async def full_audit(self, url: str) -> dict[str, Any]:
        """Run all web checks concurrently.

        Returns:
            Dict with keys ``headers``, ``ssl``, ``directories``, ``waf``, ``cors``.
        """
        from urllib.parse import urlparse
        parsed = urlparse(url)
        host = parsed.hostname or ""
        port = parsed.port or (443 if parsed.scheme == "https" else 80)

        header_task = self.check_headers(url)
        ssl_task = self.check_ssl(host, port) if parsed.scheme == "https" else asyncio.sleep(0)
        dir_task = self.directory_brute(url)
        waf_task = self.detect_waf(url)
        cors_task = self.check_cors(url)

        results = await asyncio.gather(
            header_task, ssl_task, dir_task, waf_task, cors_task,
            return_exceptions=True,
        )

        return {
            "headers": results[0] if not isinstance(results[0], Exception) else [],
            "ssl": results[1] if not isinstance(results[1], Exception) else [],
            "directories": results[2] if not isinstance(results[2], Exception) else [],
            "waf": results[3] if not isinstance(results[3], Exception) else {},
            "cors": results[4] if not isinstance(results[4], Exception) else [],
        }
