"""
AI Client — Multi-Backend LLM Integration for Luvia.

Security Principle:
    The AI layer transforms raw scan data into actionable intelligence by
    leveraging Large Language Models.  Supporting multiple backends (OpenAI,
    Ollama, HuggingFace) ensures the library works in both cloud-connected
    and air-gapped environments.
"""

from __future__ import annotations

import asyncio
import json
import os
from abc import ABC, abstractmethod
from typing import Any, Optional

import httpx

from luvia.utils.logger import setup_logger

_log = setup_logger("luvia.brain.ai_client")


# ═══════════════════════════════════════════════════════════════════════════
# Abstract Backend
# ═══════════════════════════════════════════════════════════════════════════

class LLMBackend(ABC):
    """Abstract interface for LLM backends."""

    @abstractmethod
    async def generate(
        self,
        prompt: str,
        system_prompt: str = "",
        temperature: float = 0.3,
        max_tokens: int = 2000,
    ) -> str:
        """Send a prompt and return the model's text response."""
        ...


# ═══════════════════════════════════════════════════════════════════════════
# OpenAI Backend
# ═══════════════════════════════════════════════════════════════════════════

class OpenAIBackend(LLMBackend):
    """OpenAI API backend (GPT-4 / GPT-3.5-turbo).

    Requires ``OPENAI_API_KEY`` environment variable or explicit key.
    """

    def __init__(
        self,
        api_key: str = "",
        model: str = "gpt-4",
        base_url: str = "https://api.openai.com/v1",
    ) -> None:
        self.api_key = api_key or os.getenv("OPENAI_API_KEY", "")
        self.model = model
        self.base_url = base_url.rstrip("/")

    async def generate(
        self,
        prompt: str,
        system_prompt: str = "",
        temperature: float = 0.3,
        max_tokens: int = 2000,
    ) -> str:
        if not self.api_key:
            raise ValueError("OpenAI API key not set. Set OPENAI_API_KEY or pass api_key.")

        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        body = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        for attempt in range(3):
            try:
                async with httpx.AsyncClient(timeout=60) as client:
                    resp = await client.post(
                        f"{self.base_url}/chat/completions",
                        json=body,
                        headers=headers,
                    )
                    resp.raise_for_status()
                    data = resp.json()
                    return data["choices"][0]["message"]["content"]
            except (httpx.HTTPError, KeyError) as exc:
                wait = 2 ** attempt
                _log.warning(f"OpenAI attempt {attempt + 1} failed: {exc} — retrying in {wait}s")
                await asyncio.sleep(wait)

        raise RuntimeError("OpenAI API failed after 3 retries")


# ═══════════════════════════════════════════════════════════════════════════
# Ollama Backend (local / self-hosted)
# ═══════════════════════════════════════════════════════════════════════════

class OllamaBackend(LLMBackend):
    """Ollama REST API backend for local LLMs (Llama, Mistral, etc.)."""

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "llama3",
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model

    async def generate(
        self,
        prompt: str,
        system_prompt: str = "",
        temperature: float = 0.3,
        max_tokens: int = 2000,
    ) -> str:
        body: dict[str, Any] = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
            },
        }
        if system_prompt:
            body["system"] = system_prompt

        for attempt in range(3):
            try:
                async with httpx.AsyncClient(timeout=120) as client:
                    resp = await client.post(
                        f"{self.base_url}/api/generate", json=body,
                    )
                    resp.raise_for_status()
                    data = resp.json()
                    return data.get("response", "")
            except (httpx.HTTPError, KeyError) as exc:
                wait = 2 ** attempt
                _log.warning(f"Ollama attempt {attempt + 1} failed: {exc} — retrying in {wait}s")
                await asyncio.sleep(wait)

        raise RuntimeError("Ollama API failed after 3 retries")


# ═══════════════════════════════════════════════════════════════════════════
# HuggingFace Inference Backend
# ═══════════════════════════════════════════════════════════════════════════

class HuggingFaceBackend(LLMBackend):
    """HuggingFace Inference API backend.

    Requires ``HF_API_TOKEN`` environment variable or explicit token.
    """

    def __init__(
        self,
        api_token: str = "",
        model: str = "mistralai/Mistral-7B-Instruct-v0.2",
    ) -> None:
        self.api_token = api_token or os.getenv("HF_API_TOKEN", "")
        self.model = model
        self.api_url = f"https://api-inference.huggingface.co/models/{model}"

    async def generate(
        self,
        prompt: str,
        system_prompt: str = "",
        temperature: float = 0.3,
        max_tokens: int = 2000,
    ) -> str:
        if not self.api_token:
            raise ValueError("HuggingFace API token not set. Set HF_API_TOKEN or pass api_token.")

        full_prompt = f"{system_prompt}\n\n{prompt}" if system_prompt else prompt

        body = {
            "inputs": full_prompt,
            "parameters": {
                "temperature": temperature,
                "max_new_tokens": max_tokens,
                "return_full_text": False,
            },
        }

        headers = {"Authorization": f"Bearer {self.api_token}"}

        for attempt in range(3):
            try:
                async with httpx.AsyncClient(timeout=60) as client:
                    resp = await client.post(self.api_url, json=body, headers=headers)
                    resp.raise_for_status()
                    data = resp.json()
                    if isinstance(data, list) and data:
                        return data[0].get("generated_text", "")
                    return str(data)
            except (httpx.HTTPError, KeyError) as exc:
                wait = 2 ** attempt
                _log.warning(f"HuggingFace attempt {attempt + 1} failed: {exc}")
                await asyncio.sleep(wait)

        raise RuntimeError("HuggingFace API failed after 3 retries")


# ═══════════════════════════════════════════════════════════════════════════
# Unified AI Client
# ═══════════════════════════════════════════════════════════════════════════

class AIClient:
    """Unified interface to multiple LLM backends.

    Usage::

        client = AIClient(backend="openai", model="gpt-4")
        analysis = await client.analyze(findings_json, checklist_data)
    """

    _BACKENDS: dict[str, type[LLMBackend]] = {
        "openai": OpenAIBackend,
        "ollama": OllamaBackend,
        "huggingface": HuggingFaceBackend,
    }

    def __init__(
        self,
        backend: str = "openai",
        model: str = "",
        api_key: str = "",
        base_url: str = "",
        **kwargs: Any,
    ) -> None:
        backend_lower = backend.lower()
        if backend_lower not in self._BACKENDS:
            raise ValueError(f"Unknown backend '{backend}'. Choices: {list(self._BACKENDS.keys())}")

        init_kwargs: dict[str, Any] = {}
        if model:
            init_kwargs["model"] = model

        if backend_lower == "openai":
            if api_key:
                init_kwargs["api_key"] = api_key
            if base_url:
                init_kwargs["base_url"] = base_url
        elif backend_lower == "ollama":
            if base_url:
                init_kwargs["base_url"] = base_url
        elif backend_lower == "huggingface":
            if api_key:
                init_kwargs["api_token"] = api_key

        init_kwargs.update(kwargs)
        self._backend: LLMBackend = self._BACKENDS[backend_lower](**init_kwargs)
        self._backend_name = backend_lower
        _log.info(f"AI Client initialised with {backend_lower} backend")

    async def analyze(
        self,
        findings_json: str,
        checklist: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
        max_tokens: int = 3000,
    ) -> str:
        """Submit scan findings for AI analysis.

        Args:
            findings_json: JSON string of scan results.
            checklist:     Optional security checklist data.
            temperature:   LLM temperature parameter.
            max_tokens:    Maximum response length.

        Returns:
            Raw LLM response text (typically structured JSON/markdown).
        """
        system_prompt = self._build_system_prompt(checklist)
        user_prompt = self._build_analysis_prompt(findings_json)

        _log.info("Sending findings to AI for analysis")
        return await self._backend.generate(
            prompt=user_prompt,
            system_prompt=system_prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    async def raw_query(
        self,
        prompt: str,
        system_prompt: str = "",
        temperature: float = 0.5,
        max_tokens: int = 2000,
    ) -> str:
        """Send an arbitrary prompt to the AI backend."""
        return await self._backend.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    # ── Prompt builders ───────────────────────────────────────────

    @staticmethod
    def _build_system_prompt(checklist: list[dict[str, Any]] | None) -> str:
        lines = [
            "You are Luvia AI — an expert network security analyst.",
            "Your task is to analyze penetration test findings and provide remediation.",
            "",
            "For EACH finding, output a JSON object with:",
            '  "finding": string — what was discovered',
            '  "risk_level": "critical" | "high" | "medium" | "low"',
            '  "logic": string — why this is a threat',
            '  "remediation": string — exact Linux/Python commands to fix',
            '  "checklist_ref": string — matching checklist guidance ID',
            "",
            "Wrap all items in a JSON array.",
        ]

        if checklist:
            lines.append("\n--- SECURITY CHECKLIST ---")
            for item in checklist:
                lines.append(
                    f"[{item.get('id', '')}] ({item.get('severity', '')}) "
                    f"{item.get('category', '')}: {item.get('guidance', '')}"
                )

        return "\n".join(lines)

    @staticmethod
    def _build_analysis_prompt(findings_json: str) -> str:
        return (
            "Analyze the following penetration test findings and provide "
            "remediation for each issue found:\n\n"
            f"```json\n{findings_json}\n```\n\n"
            "Respond with a JSON array of remediation items."
        )
