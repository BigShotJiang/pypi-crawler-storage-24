"""
Remediator — AI-Powered Findings-to-Solutions Engine for Luvia.

Security Principle:
    Raw vulnerability data is only useful when paired with actionable
    remediation.  This module consumes scan results, cross-references them
    against the Network Security Checklist, and uses the AI client to
    produce structured remediation reports with risk levels, threat logic,
    and exact fix commands.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from luvia.brain.ai_client import AIClient
from luvia.database.models import (
    RemediationItem,
    RemediationReport,
    RiskLevel,
    ScanResult,
    VulnerabilityInfo,
)
from luvia.utils.logger import setup_logger

_log = setup_logger("luvia.brain.remediator")

_CHECKLIST_PATH = Path(__file__).resolve().parent.parent / "database" / "checklist.json"


class Remediator:
    """Transform scan findings into AI-powered remediation reports.

    Usage::

        r = Remediator(ai_client=AIClient(backend="openai"))
        report = await r.generate_report(scan_result)
    """

    def __init__(
        self,
        ai_client: AIClient | None = None,
        checklist_path: Path | str | None = None,
    ) -> None:
        self._ai = ai_client
        self._checklist = self._load_checklist(checklist_path or _CHECKLIST_PATH)

    # ── Checklist ─────────────────────────────────────────────────

    @staticmethod
    def _load_checklist(path: Path | str) -> list[dict[str, Any]]:
        p = Path(path)
        if not p.is_file():
            _log.warning(f"Checklist not found at {p} — cross-referencing disabled")
            return []
        return json.loads(p.read_text(encoding="utf-8"))

    # ── Risk Assessment ───────────────────────────────────────────

    @staticmethod
    def assess_risk(findings: list[VulnerabilityInfo]) -> RiskLevel:
        """Determine the overall risk level from a list of findings.

        Logic: the highest individual risk drives the overall assessment.
        """
        if not findings:
            return RiskLevel.INFO

        severity_order = [
            RiskLevel.CRITICAL,
            RiskLevel.HIGH,
            RiskLevel.MEDIUM,
            RiskLevel.LOW,
            RiskLevel.INFO,
        ]

        for level in severity_order:
            if any(f.risk_level == level for f in findings):
                return level

        return RiskLevel.INFO

    # ── Checklist Cross-Reference ─────────────────────────────────

    def cross_reference_checklist(
        self, finding: VulnerabilityInfo,
    ) -> str:
        """Find the best-matching checklist guidance for a finding.

        Uses keyword matching between finding title/description and
        checklist guidance text.

        Returns:
            Checklist item ID (e.g. ``"SLNO-03"``) or empty string.
        """
        if not self._checklist:
            return finding.checklist_id or ""

        # If already tagged, keep it
        if finding.checklist_id:
            return finding.checklist_id

        best_id = ""
        best_score = 0
        search_text = (
            f"{finding.title} {finding.description} {finding.remediation}"
        ).lower()

        for item in self._checklist:
            keywords = (
                f"{item.get('category', '')} {item.get('guidance', '')} "
                f"{item.get('remediation_hint', '')}"
            ).lower().split()

            score = sum(1 for kw in keywords if len(kw) > 3 and kw in search_text)
            if score > best_score:
                best_score = score
                best_id = item.get("id", "")

        return best_id if best_score >= 2 else ""

    # ── Local Remediation (no AI) ─────────────────────────────────

    def generate_local_remediation(
        self, finding: VulnerabilityInfo,
    ) -> RemediationItem:
        """Generate a remediation item using only local checklist data.

        This is the fallback when no AI backend is configured.
        """
        checklist_ref = self.cross_reference_checklist(finding)

        # Try to get remediation hint from checklist
        hint = ""
        if checklist_ref:
            for item in self._checklist:
                if item.get("id") == checklist_ref:
                    hint = item.get("remediation_hint", "")
                    break

        remediation = finding.remediation or hint or "Review and apply vendor patches."

        return RemediationItem(
            finding=finding.title,
            risk_level=finding.risk_level,
            logic=finding.description or "This service/configuration poses a security risk.",
            remediation=remediation,
            checklist_ref=checklist_ref,
        )

    # ── AI-Powered Remediation ────────────────────────────────────

    async def generate_ai_remediation(
        self,
        scan_result: ScanResult,
    ) -> list[RemediationItem]:
        """Use the AI backend to generate remediation from scan data.

        Returns:
            List of :class:`RemediationItem` objects parsed from AI output.
        """
        if not self._ai:
            _log.warning("No AI client configured — falling back to local remediation")
            items: list[RemediationItem] = []
            for host in scan_result.hosts:
                for vuln in host.vulnerabilities:
                    items.append(self.generate_local_remediation(vuln))
            return items

        # Serialize the scan result for the AI
        findings_json = scan_result.model_dump_json(indent=2)

        try:
            raw_response = await self._ai.analyze(
                findings_json=findings_json,
                checklist=self._checklist,
            )
            return self._parse_ai_response(raw_response)
        except Exception as exc:
            _log.error(f"AI analysis failed: {exc} — falling back to local")
            items = []
            for host in scan_result.hosts:
                for vuln in host.vulnerabilities:
                    items.append(self.generate_local_remediation(vuln))
            return items

    # ── Full Report Generation ────────────────────────────────────

    async def generate_report(
        self,
        scan_result: ScanResult,
        use_ai: bool = True,
    ) -> RemediationReport:
        """Generate a complete remediation report.

        Args:
            scan_result: Validated scan data.
            use_ai:      Whether to use the AI backend (``True``) or
                         local-only analysis (``False``).

        Returns:
            A validated :class:`RemediationReport`.
        """
        _log.info(f"Generating remediation report for scan {scan_result.scan_id}")

        if use_ai and self._ai:
            items = await self.generate_ai_remediation(scan_result)
        else:
            items = []

        # 1. Fallback: Add any missed vulnerabilities (if AI skipped them)
        ai_findings_str = " ".join([i.finding.lower() + " " + i.logic.lower() for i in items]) if items else ""
        for host in scan_result.hosts:
            for vuln in host.vulnerabilities:
                is_missing = True
                if items:
                    if vuln.cve_id and vuln.cve_id.lower() in ai_findings_str:
                        is_missing = False
                    elif vuln.title.lower() in ai_findings_str:
                        is_missing = False
                
                if is_missing or not items:
                    _log.debug(f"Adding local fallback for vulnerability: {vuln.title}")
                    items.append(self.generate_local_remediation(vuln))

        # 2. Attack Surface: Document all open ports (INFO level risk) that have no explicit warning
        for host in scan_result.hosts:
            for port_info in host.ports:
                if port_info.state.value == "open":
                    port_str = str(port_info.port)
                    service_name = port_info.service.name.lower()
                    
                    service_covered = False
                    for item in items:
                        text = (item.finding + " " + item.logic + " " + item.remediation).lower()
                        if port_str in text or service_name in text:
                            service_covered = True
                            break
                    
                    if not service_covered:
                        _log.debug(f"Adding attack surface item for port {port_info.port}/{port_info.protocol}")
                        items.append(
                            RemediationItem(
                                finding=f"Open Port: {port_info.port}/{port_info.protocol} ({port_info.service.name})",
                                risk_level=RiskLevel.INFO,
                                logic=f"Port {port_info.port} is open and exposing the '{port_info.service.name}' service. Every open port increases the external attack surface of the network.",
                                remediation=f"Validate if {port_info.service.name} on port {port_info.port} is strictly required for business operations. If not, restrict access via firewall rules or disable the service entirely.",
                                checklist_ref="SLNO-01"
                            )
                        )

        # Determine overall risk from findings
        all_vulns: list[VulnerabilityInfo] = []
        for host in scan_result.hosts:
            all_vulns.extend(host.vulnerabilities)
        overall_risk = self.assess_risk(all_vulns)

        # Build summary
        vuln_count = len(all_vulns)
        critical_count = sum(1 for v in all_vulns if v.risk_level == RiskLevel.CRITICAL)
        high_count = sum(1 for v in all_vulns if v.risk_level == RiskLevel.HIGH)
        summary = (
            f"Scan of {scan_result.target} found {vuln_count} vulnerability(ies): "
            f"{critical_count} critical, {high_count} high. "
            f"Overall risk: {overall_risk.value.upper()}."
        )

        report = RemediationReport(
            scan_id=scan_result.scan_id,
            target=scan_result.target,
            summary=summary,
            items=items,
            overall_risk=overall_risk,
            hosts=scan_result.hosts,
        )

        _log.info(
            f"Report generated: {len(items)} remediation item(s), "
            f"overall risk: {overall_risk.value}"
        )
        return report

    # ── AI response parser ────────────────────────────────────────

    @staticmethod
    def _parse_ai_response(raw: str) -> list[RemediationItem]:
        """Extract :class:`RemediationItem` objects from AI text.

        The AI is instructed to return a JSON array, but this parser
        is resilient to markdown code fences and partial outputs.
        """
        # Strip markdown fences
        text = raw.strip()
        if "```" in text:
            parts = text.split("```")
            for part in parts:
                stripped = part.strip()
                if stripped.startswith("json"):
                    stripped = stripped[4:].strip()
                if stripped.startswith("["):
                    text = stripped
                    break

        items: list[RemediationItem] = []
        try:
            data = json.loads(text)
            if isinstance(data, list):
                for entry in data:
                    if isinstance(entry, dict):
                        risk_str = entry.get("risk_level", "medium").lower()
                        try:
                            risk = RiskLevel(risk_str)
                        except ValueError:
                            risk = RiskLevel.MEDIUM

                        items.append(RemediationItem(
                            finding=entry.get("finding", "Unknown finding"),
                            risk_level=risk,
                            logic=entry.get("logic", ""),
                            remediation=entry.get("remediation", ""),
                            checklist_ref=entry.get("checklist_ref", ""),
                        ))
        except json.JSONDecodeError:
            _log.warning("Failed to parse AI response as JSON — using raw text")
            items.append(RemediationItem(
                finding="AI Analysis",
                risk_level=RiskLevel.INFO,
                logic=raw[:500],
                remediation="Review the AI output manually.",
            ))

        return items
