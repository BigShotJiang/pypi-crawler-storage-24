"""AI remediation brain — LLM integration and intelligent analysis."""
