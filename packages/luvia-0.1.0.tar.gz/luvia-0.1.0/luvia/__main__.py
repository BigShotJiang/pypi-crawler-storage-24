"""Allow running Luvia as ``python -m luvia``."""

from luvia.main import main

main()
