"""
Stealth-Compliant Logging Module for Luvia.

Security Principle:
    Provides structured, filterable logging that avoids leaking sensitive
    information (credentials, internal IPs) into log output. Supports both
    console and file output with JSON-structured records for forensic review.
"""

from __future__ import annotations

import json
import logging
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Sensitive-data filter
# ---------------------------------------------------------------------------

_SENSITIVE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"password\s*[=:]\s*\S+", re.IGNORECASE), "password=***REDACTED***"),
    (re.compile(r"token\s*[=:]\s*\S+", re.IGNORECASE), "token=***REDACTED***"),
    (re.compile(r"api[_-]?key\s*[=:]\s*\S+", re.IGNORECASE), "api_key=***REDACTED***"),
    (re.compile(r"secret\s*[=:]\s*\S+", re.IGNORECASE), "secret=***REDACTED***"),
    (re.compile(r"Authorization:\s*\S+", re.IGNORECASE), "Authorization: ***REDACTED***"),
]


class SensitiveFilter(logging.Filter):
    """Strip credentials and tokens from log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            for pattern, replacement in _SENSITIVE_PATTERNS:
                record.msg = pattern.sub(replacement, record.msg)
        return True


# ---------------------------------------------------------------------------
# JSON formatter
# ---------------------------------------------------------------------------

class JSONFormatter(logging.Formatter):
    """Emit each log record as a single-line JSON object."""

    def format(self, record: logging.LogRecord) -> str:
        log_entry: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[1]:
            log_entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_entry, default=str)


# ---------------------------------------------------------------------------
# Rich console formatter
# ---------------------------------------------------------------------------

class ConsoleFormatter(logging.Formatter):
    """Color-coded console output via Rich-compatible ANSI."""

    _COLORS = {
        "DEBUG": "\033[36m",     # cyan
        "INFO": "\033[32m",      # green
        "WARNING": "\033[33m",   # yellow
        "ERROR": "\033[31m",     # red
        "CRITICAL": "\033[1;31m",  # bold red
    }
    _RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        color = self._COLORS.get(record.levelname, "")
        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        return (
            f"{color}[{ts}] [{record.levelname:<8}]{self._RESET} "
            f"{record.module}.{record.funcName}: {record.getMessage()}"
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class StealthLogger:
    """Factory wrapper that creates pre-configured loggers for Luvia modules.

    Attributes:
        name:     Logger namespace (e.g. ``luvia.core.scanner``).
        level:    Minimum severity to emit.
        log_file: Optional path for JSON-structured file output.
    """

    def __init__(
        self,
        name: str = "luvia",
        level: int = logging.INFO,
        log_file: Path | str | None = None,
    ) -> None:
        self._logger = logging.getLogger(name)
        self._logger.setLevel(level)
        self._logger.addFilter(SensitiveFilter())

        # Avoid duplicate handlers on repeated instantiation
        if not self._logger.handlers:
            # Console handler
            console = logging.StreamHandler(sys.stderr)
            console.setFormatter(ConsoleFormatter())
            self._logger.addHandler(console)

            # Optional file handler
            if log_file:
                path = Path(log_file)
                path.parent.mkdir(parents=True, exist_ok=True)
                fh = logging.FileHandler(str(path), encoding="utf-8")
                fh.setFormatter(JSONFormatter())
                self._logger.addHandler(fh)

    @property
    def logger(self) -> logging.Logger:
        return self._logger

    # Convenience proxies ───────────────────────────────────────────────
    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.debug(msg, *args, **kwargs)

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.info(msg, *args, **kwargs)

    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.warning(msg, *args, **kwargs)

    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.error(msg, *args, **kwargs)

    def critical(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.critical(msg, *args, **kwargs)


def setup_logger(
    name: str = "luvia",
    level: int = logging.INFO,
    log_file: Path | str | None = None,
) -> StealthLogger:
    """Create and return a configured :class:`StealthLogger` instance."""
    return StealthLogger(name=name, level=level, log_file=log_file)
