"""Utility modules — logging, reporting, and helpers."""
