"""
Traffic Analyzer — TShark / Packet Analysis for Luvia.

Security Principle:
    Passive traffic analysis complements active scanning.  By examining
    packet distribution trees and protocol anomalies, Luvia can detect
    data exfiltration, C2 beaconing, and protocol misuse that port
    scans alone cannot reveal.
"""

from __future__ import annotations

import asyncio
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from luvia.database.models import RiskLevel, TrafficAnomaly
from luvia.utils.logger import setup_logger

_log = setup_logger("luvia.core.traffic")


# ═══════════════════════════════════════════════════════════════════════════
# Data Structures
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class PacketRecord:
    """Lightweight representation of a single decoded packet."""

    frame_number: int = 0
    timestamp: str = ""
    source: str = ""
    destination: str = ""
    protocol: str = ""
    length: int = 0
    info: str = ""
    layers: list[str] = field(default_factory=list)


@dataclass
class ProtocolNode:
    """Node in a packet distribution tree."""

    name: str
    count: int = 0
    bytes_total: int = 0
    children: dict[str, "ProtocolNode"] = field(default_factory=dict)

    def add(self, layers: list[str], pkt_len: int) -> None:
        """Recursively add a packet's protocol stack to the tree."""
        self.count += 1
        self.bytes_total += pkt_len
        if layers:
            child_name = layers[0]
            if child_name not in self.children:
                self.children[child_name] = ProtocolNode(name=child_name)
            self.children[child_name].add(layers[1:], pkt_len)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "count": self.count,
            "bytes": self.bytes_total,
            "children": {k: v.to_dict() for k, v in self.children.items()},
        }


# ═══════════════════════════════════════════════════════════════════════════
# Traffic Analyzer
# ═══════════════════════════════════════════════════════════════════════════

class TrafficAnalyzer:
    """Analyse network traffic via TShark sub-processes or parsed captures.

    All heavy I/O uses ``asyncio.subprocess`` to keep the event loop free.
    """

    def __init__(self, tshark_path: str = "tshark") -> None:
        self._tshark = tshark_path

    # ── TShark helpers ────────────────────────────────────────────────

    async def _run_tshark(self, args: list[str]) -> str:
        """Execute TShark with *args* and return stdout."""
        cmd = [self._tshark, *args]
        _log.debug(f"Running: {' '.join(cmd)}")
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            err = stderr.decode(errors="replace").strip()
            _log.error(f"TShark error: {err}")
            raise RuntimeError(f"TShark failed (rc={proc.returncode}): {err}")
        return stdout.decode(errors="replace")

    # ── Public API ────────────────────────────────────────────────────

    async def capture_live(
        self,
        interface: str,
        duration: int = 30,
        bpf_filter: str = "",
        output_file: str | Path | None = None,
    ) -> list[PacketRecord]:
        """Run a live packet capture.

        Args:
            interface:   Network interface name.
            duration:    Capture duration in seconds.
            bpf_filter:  Optional BPF filter expression.
            output_file: If provided, also write a ``.pcap`` to disk.

        Returns:
            List of :class:`PacketRecord` objects.
        """
        args = [
            "-i", interface,
            "-a", f"duration:{duration}",
            "-T", "fields",
            "-e", "frame.number",
            "-e", "frame.time",
            "-e", "ip.src",
            "-e", "ip.dst",
            "-e", "frame.protocols",
            "-e", "frame.len",
            "-e", "_ws.col.Info",
            "-E", "separator=|",
            "-E", "quote=d",
        ]
        if bpf_filter:
            args.extend(["-f", bpf_filter])
        if output_file:
            args.extend(["-w", str(output_file)])

        _log.info(f"Starting live capture on {interface} for {duration}s")
        raw = await self._run_tshark(args)
        return self._parse_fields(raw)

    async def read_pcap(self, path: str | Path) -> list[PacketRecord]:
        """Parse an existing ``.pcap`` file via TShark.

        Args:
            path: Path to the capture file.

        Returns:
            List of :class:`PacketRecord` objects.
        """
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Capture file not found: {p}")

        args = [
            "-r", str(p),
            "-T", "fields",
            "-e", "frame.number",
            "-e", "frame.time",
            "-e", "ip.src",
            "-e", "ip.dst",
            "-e", "frame.protocols",
            "-e", "frame.len",
            "-e", "_ws.col.Info",
            "-E", "separator=|",
            "-E", "quote=d",
        ]
        _log.info(f"Reading pcap: {p}")
        raw = await self._run_tshark(args)
        return self._parse_fields(raw)

    # ── Analysis ──────────────────────────────────────────────────────

    def packet_distribution_tree(self, packets: list[PacketRecord]) -> ProtocolNode:
        """Build a protocol distribution tree from parsed packets.

        The tree mirrors TShark's protocol hierarchy statistics, revealing
        the proportion of each protocol in the capture.
        """
        root = ProtocolNode(name="root")
        for pkt in packets:
            layers = pkt.layers if pkt.layers else [pkt.protocol or "unknown"]
            root.add(layers, pkt.length)
        return root

    def detect_anomalies(
        self,
        packets: list[PacketRecord],
        tree: ProtocolNode | None = None,
    ) -> list[TrafficAnomaly]:
        """Identify statistical anomalies in traffic patterns.

        Heuristics:
        1. **Protocol imbalance** — unusual dominance of a single protocol.
        2. **Beaconing** — regular-interval traffic from one source.
        3. **Data-size disparity** — unusually large/small packets.
        4. **Suspicious ports** — traffic on known C2/exfil ports.
        """
        anomalies: list[TrafficAnomaly] = []

        if not packets:
            return anomalies

        # ── 1. Protocol imbalance ─────────────────────────────────
        proto_counts: Counter[str] = Counter()
        for pkt in packets:
            proto_counts[pkt.protocol] += 1

        total = sum(proto_counts.values()) or 1
        for proto, count in proto_counts.most_common(5):
            ratio = count / total
            if ratio > 0.80 and total > 50:
                anomalies.append(TrafficAnomaly(
                    protocol=proto,
                    source="multiple",
                    destination="multiple",
                    packet_count=count,
                    anomaly_type="protocol_imbalance",
                    severity=RiskLevel.MEDIUM,
                    details=f"{proto} constitutes {ratio:.0%} of all traffic",
                ))

        # ── 2. Excessive traffic from single source ───────────────
        src_counts: Counter[str] = Counter()
        for pkt in packets:
            if pkt.source:
                src_counts[pkt.source] += 1

        for src, count in src_counts.most_common(3):
            ratio = count / total
            if ratio > 0.60 and total > 30:
                anomalies.append(TrafficAnomaly(
                    protocol="mixed",
                    source=src,
                    destination="multiple",
                    packet_count=count,
                    anomaly_type="source_dominance",
                    severity=RiskLevel.HIGH,
                    details=f"Source {src} generates {ratio:.0%} of traffic — possible beaconing",
                ))

        # ── 3. Large-packet outliers ──────────────────────────────
        lengths = [p.length for p in packets if p.length > 0]
        if lengths:
            avg_len = sum(lengths) / len(lengths)
            for pkt in packets:
                if pkt.length > avg_len * 5 and pkt.length > 5000:
                    anomalies.append(TrafficAnomaly(
                        protocol=pkt.protocol,
                        source=pkt.source,
                        destination=pkt.destination,
                        packet_count=1,
                        anomaly_type="oversized_packet",
                        severity=RiskLevel.MEDIUM,
                        details=f"Packet #{pkt.frame_number}: {pkt.length}B "
                                f"(avg {avg_len:.0f}B)",
                    ))

        # ── 4. Suspicious destination ports in info ───────────────
        _SUSPICIOUS = {4444, 5555, 1337, 31337, 12345, 6666, 6969, 9999}
        port_re = re.compile(r"(?:→|->|dst[= ])\s*(\d+)")
        for pkt in packets:
            m = port_re.search(pkt.info)
            if m and int(m.group(1)) in _SUSPICIOUS:
                anomalies.append(TrafficAnomaly(
                    protocol=pkt.protocol,
                    source=pkt.source,
                    destination=pkt.destination,
                    packet_count=1,
                    anomaly_type="suspicious_port",
                    severity=RiskLevel.HIGH,
                    details=f"Traffic to suspicious port {m.group(1)}",
                ))

        _log.info(f"Anomaly detection complete — {len(anomalies)} finding(s)")
        return anomalies

    # ── Internal parsing ──────────────────────────────────────────

    @staticmethod
    def _parse_fields(raw: str) -> list[PacketRecord]:
        """Parse TShark ``-T fields`` pipe-delimited output."""
        records: list[PacketRecord] = []
        for line in raw.strip().splitlines():
            parts = [p.strip('"') for p in line.split("|")]
            if len(parts) < 5:
                continue
            layers = parts[4].split(":") if parts[4] else []
            protocol = layers[-1] if layers else "unknown"
            try:
                length = int(parts[5]) if len(parts) > 5 and parts[5] else 0
            except ValueError:
                length = 0
            records.append(PacketRecord(
                frame_number=int(parts[0]) if parts[0].isdigit() else 0,
                timestamp=parts[1],
                source=parts[2],
                destination=parts[3],
                protocol=protocol,
                length=length,
                info=parts[6] if len(parts) > 6 else "",
                layers=layers,
            ))
        return records
