"""
Network Discovery — Subdomain Enumeration, OSINT & Host Discovery for Luvia.

Security Principle:
    Reconnaissance is the first phase of any penetration test.  This module
    gathers intelligence through DNS brute-forcing, zone transfers, WHOIS,
    reverse DNS, HTTP header analysis, and ARP/ping sweeps — all
    asynchronously to maximise coverage speed while minimising detection.
"""

from __future__ import annotations

import asyncio
import ipaddress
import re
import socket
from pathlib import Path
from typing import Any, Optional

import httpx

from luvia.database.models import HostInfo, ScanResult
from luvia.utils.logger import setup_logger

_log = setup_logger("luvia.core.discovery")


# ═══════════════════════════════════════════════════════════════════════════
# Subdomain Enumerator
# ═══════════════════════════════════════════════════════════════════════════

class SubdomainEnumerator:
    """Discover subdomains through DNS brute-forcing and zone transfers."""

    DEFAULT_WORDLIST: list[str] = [
        "www", "mail", "ftp", "remote", "blog", "webmail", "server", "ns1",
        "ns2", "smtp", "secure", "vpn", "admin", "api", "dev", "staging",
        "test", "portal", "app", "m", "mobile", "cdn", "media", "static",
        "docs", "git", "ci", "monitor", "status", "dashboard", "db",
        "internal", "intranet", "wiki", "support", "help", "shop", "store",
    ]

    async def brute_force(
        self,
        domain: str,
        wordlist: list[str] | Path | None = None,
        concurrency: int = 50,
    ) -> list[dict[str, str]]:
        """DNS brute-force subdomain enumeration.

        Args:
            domain:      Base domain (e.g. ``example.com``).
            wordlist:    List of prefixes, path to a file, or ``None`` for defaults.
            concurrency: Maximum concurrent DNS lookups.

        Returns:
            List of ``{"subdomain": …, "ip": …}`` dicts.
        """
        words = await self._load_wordlist(wordlist)
        _log.info(f"Brute-forcing {domain} with {len(words)} prefixes")

        semaphore = asyncio.Semaphore(concurrency)
        results: list[dict[str, str]] = []

        async def _resolve(prefix: str) -> None:
            fqdn = f"{prefix}.{domain}"
            async with semaphore:
                loop = asyncio.get_running_loop()
                try:
                    infos = await loop.getaddrinfo(fqdn, None)
                    ips = {info[4][0] for info in infos}
                    for ip in ips:
                        results.append({"subdomain": fqdn, "ip": ip})
                        _log.debug(f"Found: {fqdn} → {ip}")
                except (socket.gaierror, OSError):
                    pass

        await asyncio.gather(*[_resolve(w) for w in words])
        _log.info(f"Brute-force complete — {len(results)} subdomain(s) found")
        return results

    async def dns_zone_transfer(self, domain: str, nameserver: str = "") -> list[str]:
        """Attempt an AXFR zone transfer.

        Args:
            domain:     Target domain.
            nameserver: Specific NS to try.  If empty, resolves from SOA.

        Returns:
            List of zone-transfer record lines, empty if transfer denied.
        """
        loop = asyncio.get_running_loop()

        def _attempt() -> list[str]:
            try:
                import dns.resolver  # type: ignore[import-untyped]
                import dns.zone  # type: ignore[import-untyped]
                import dns.query  # type: ignore[import-untyped]

                ns = nameserver
                if not ns:
                    answers = dns.resolver.resolve(domain, "NS")
                    ns = str(answers[0].target).rstrip(".")

                zone = dns.zone.from_xfr(dns.query.xfr(ns, domain, timeout=10))
                records: list[str] = []
                for name, node in zone.nodes.items():
                    records.append(str(name) + "." + domain)
                return records
            except ImportError:
                _log.warning("dnspython not installed — zone transfer unavailable")
                return []
            except Exception as exc:
                _log.debug(f"Zone transfer denied for {domain}: {exc}")
                return []

        records = await loop.run_in_executor(None, _attempt)
        if records:
            _log.warning(f"Zone transfer SUCCEEDED for {domain} — {len(records)} records")
        return records

    # ── helpers ────────────────────────────────────────────────────

    async def _load_wordlist(self, source: list[str] | Path | None) -> list[str]:
        if source is None:
            return self.DEFAULT_WORDLIST
        if isinstance(source, list):
            return source
        p = Path(source)
        if p.is_file():
            text = await asyncio.to_thread(p.read_text, encoding="utf-8")
            return [w.strip() for w in text.splitlines() if w.strip()]
        return self.DEFAULT_WORDLIST


# ═══════════════════════════════════════════════════════════════════════════
# OSINT Gatherer
# ═══════════════════════════════════════════════════════════════════════════

class OSINTGatherer:
    """Passive intelligence collection — WHOIS, reverse DNS, header analysis."""

    async def whois_lookup(self, target: str) -> dict[str, Any]:
        """Retrieve WHOIS information for a domain or IP.

        Uses the system ``whois`` command wrapped in an async subprocess.
        Falls back to a public HTTP API if the binary is missing (e.g. Windows).
        """
        loop = asyncio.get_running_loop()

        def _lookup() -> dict[str, Any]:
            import subprocess
            out = ""
            try:
                out = subprocess.check_output(
                    ["whois", target], timeout=15, stderr=subprocess.DEVNULL,
                ).decode(errors="replace")
            except FileNotFoundError:
                try:
                    import httpx
                    resp = httpx.get(f"https://api.hackertarget.com/whois/?q={target}", timeout=15)
                    resp.raise_for_status()
                    out = resp.text
                except Exception as api_exc:
                    _log.warning(f"WHOIS lookup failed (binary missing & API fallback failed): {api_exc}")
                    return {"target": target, "error": f"whois binary missing and API failed: {api_exc}"}
            except Exception as exc:
                _log.warning(f"WHOIS lookup failed for {target}: {exc}")
                return {"target": target, "error": str(exc)}

            data: dict[str, Any] = {"raw": out, "target": target}
            for line in out.splitlines():
                if ":" in line:
                    key, _, val = line.partition(":")
                    key = key.strip().lower().replace(" ", "_")
                    if key and val.strip():
                        data[key] = val.strip()
            return data

        return await loop.run_in_executor(None, _lookup)

    async def reverse_dns(self, ip: str) -> str:
        """Perform reverse DNS lookup.

        Returns:
            Hostname string or empty string if lookup fails.
        """
        loop = asyncio.get_running_loop()
        try:
            result = await loop.getnameinfo((ip, 0), socket.NI_NAMEREQD)
            hostname = result[0]
            _log.debug(f"rDNS: {ip} → {hostname}")
            return hostname
        except (socket.gaierror, OSError):
            return ""

    async def headers_grab(self, url: str) -> dict[str, str]:
        """Fetch and return HTTP response headers.

        Looks for security-relevant headers such as ``Server``,
        ``X-Powered-By``, ``Strict-Transport-Security``, etc.
        """
        async with httpx.AsyncClient(
            follow_redirects=True, timeout=10, verify=False
        ) as client:
            try:
                resp = await client.head(url)
                headers = dict(resp.headers)
                _log.info(f"Headers from {url}: {len(headers)} entries")
                return headers
            except httpx.HTTPError as exc:
                _log.warning(f"Header grab failed for {url}: {exc}")
                return {"error": str(exc)}


# ═══════════════════════════════════════════════════════════════════════════
# Network Mapper — Host Discovery & Pivot Detection
# ═══════════════════════════════════════════════════════════════════════════

class NetworkMapper:
    """Discover live hosts on a subnet and identify internal pivot targets."""

    async def discover_hosts(
        self,
        cidr: str,
        timeout: float = 1.0,
        concurrency: int = 100,
    ) -> list[dict[str, str]]:
        """Ping sweep to discover live hosts in a CIDR range.

        Uses a raw ``asyncio`` TCP connect probe on port 80 / ICMP echo
        as a fast heuristic (no raw sockets needed on most OSes).

        Args:
            cidr:        Network in CIDR notation (e.g. ``192.168.1.0/24``).
            timeout:     Per-host timeout in seconds.
            concurrency: Maximum simultaneous probes.

        Returns:
            List of ``{"ip": …, "status": "up"/"down"}`` dicts.
        """
        network = ipaddress.ip_network(cidr, strict=False)
        hosts = [str(ip) for ip in network.hosts()]
        _log.info(f"Discovering hosts in {cidr} ({len(hosts)} addresses)")

        semaphore = asyncio.Semaphore(concurrency)
        results: list[dict[str, str]] = []

        async def _probe(ip: str) -> None:
            async with semaphore:
                try:
                    _, writer = await asyncio.wait_for(
                        asyncio.open_connection(ip, 80),
                        timeout=timeout,
                    )
                    writer.close()
                    await writer.wait_closed()
                    results.append({"ip": ip, "status": "up"})
                except (asyncio.TimeoutError, OSError):
                    # Fallback: try common alternative ports
                    for alt_port in (443, 22, 445):
                        try:
                            _, writer = await asyncio.wait_for(
                                asyncio.open_connection(ip, alt_port),
                                timeout=timeout,
                            )
                            writer.close()
                            await writer.wait_closed()
                            results.append({"ip": ip, "status": "up"})
                            return
                        except (asyncio.TimeoutError, OSError):
                            continue

        await asyncio.gather(*[_probe(ip) for ip in hosts])
        _log.info(f"Host discovery complete — {len(results)} live host(s)")
        return results

    @staticmethod
    def detect_pivot_targets(
        scan_results: list[ScanResult],
    ) -> list[str]:
        """Analyse scan results to identify potential internal pivot networks.

        Logic:
        - Extract all discovered IPs.
        - Identify RFC-1918 networks present.
        - Return CIDR ranges for further internal scanning.
        """
        private_nets: set[str] = set()

        for result in scan_results:
            for host in result.hosts:
                try:
                    addr = ipaddress.ip_address(host.ip)
                    if addr.is_private:
                        # Find the /24 subnet
                        net = ipaddress.ip_network(f"{host.ip}/24", strict=False)
                        private_nets.add(str(net))
                except ValueError:
                    continue

        pivots = sorted(private_nets)
        if pivots:
            _log.warning(f"Potential pivot targets: {pivots}")
        return pivots

    @staticmethod
    def detect_internal_ranges_from_traceroute(
        traceroute_output: str,
    ) -> list[str]:
        """Parse traceroute output to discover internal network hops.

        Args:
            traceroute_output: Raw traceroute text.

        Returns:
            List of private IP addresses found in the path.
        """
        ip_re = re.compile(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")
        internal: list[str] = []
        for match in ip_re.finditer(traceroute_output):
            ip_str = match.group()
            try:
                addr = ipaddress.ip_address(ip_str)
                if addr.is_private and ip_str not in internal:
                    internal.append(ip_str)
            except ValueError:
                continue
        return internal
