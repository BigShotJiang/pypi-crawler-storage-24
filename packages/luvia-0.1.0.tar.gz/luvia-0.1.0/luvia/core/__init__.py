"""Core orchestration layer — scanner, traffic analysis, and network discovery."""
