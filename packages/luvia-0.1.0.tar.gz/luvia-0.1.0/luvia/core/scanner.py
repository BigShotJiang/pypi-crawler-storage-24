"""
Network Scanner — Nmap & Scapy Orchestration for Luvia.

Security Principle:
    Provides the primary reconnaissance layer.  Supports stealth SYN scans,
    full-port audits, service fingerprinting, OS detection, fragmentation
    evasion, decoy scanning, and custom NSE scripts.  All scan functions are
    async-first and feed validated Pydantic models downstream.
"""

from __future__ import annotations

import asyncio
import os
import shutil
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

import nmap

from luvia.database.models import (
    HostInfo,
    PortInfo,
    PortState,
    ScanResult,
    ScanType,
    ServiceInfo,
)
from luvia.utils.logger import setup_logger

_log = setup_logger("luvia.core.scanner")


# ═══════════════════════════════════════════════════════════════════════════
# Nmap path auto-detection (Windows common install locations)
# ═══════════════════════════════════════════════════════════════════════════

_NMAP_SEARCH_PATHS: list[str] = [
    r"C:\Program Files (x86)\Nmap",
    r"C:\Program Files\Nmap",
    r"C:\Nmap",
]


def _find_nmap() -> str | None:
    """Locate the nmap binary, checking PATH first, then common directories."""
    if shutil.which("nmap"):
        return None  # on PATH already, let python-nmap find it
    for directory in _NMAP_SEARCH_PATHS:
        exe = os.path.join(directory, "nmap.exe")
        if os.path.isfile(exe):
            _log.info(f"Found nmap at {exe}")
            return exe
    return None


# ═══════════════════════════════════════════════════════════════════════════
# Nmap Scanner
# ═══════════════════════════════════════════════════════════════════════════

class NmapScanner:
    """High-level async wrapper around ``python-nmap``.

    Every public method returns a validated :class:`ScanResult`.
    The underlying ``nmap.PortScanner`` calls are offloaded to a thread-pool
    so the event loop is never blocked.
    """

    def __init__(self, nmap_path: str | None = None) -> None:
        search_path = nmap_path or _find_nmap()
        if search_path:
            self._scanner = nmap.PortScanner(
                nmap_search_path=(search_path,)
            )
        else:
            self._scanner = nmap.PortScanner()

    # ── helpers ────────────────────────────────────────────────────────

    @staticmethod
    def _gen_id() -> str:
        return uuid.uuid4().hex[:12]

    def _parse_results(
        self,
        target: str,
        scan_type: ScanType,
        scan_id: str,
        started: datetime,
    ) -> ScanResult:
        """Convert raw ``python-nmap`` data to a :class:`ScanResult`."""
        hosts: list[HostInfo] = []

        for host_ip in self._scanner.all_hosts():
            host_data = self._scanner[host_ip]

            # ── ports ─────────────────────────────────────────────
            ports: list[PortInfo] = []
            for proto in host_data.all_protocols():
                for port_num in sorted(host_data[proto].keys()):
                    port_data = host_data[proto][port_num]
                    state_str = port_data.get("state", "filtered")
                    try:
                        state = PortState(state_str)
                    except ValueError:
                        state = PortState.FILTERED

                    service = ServiceInfo(
                        name=port_data.get("name", "unknown"),
                        product=port_data.get("product", ""),
                        version=port_data.get("version", ""),
                        extra_info=port_data.get("extrainfo", ""),
                        os_type=port_data.get("ostype", ""),
                        cpe=port_data.get("cpe", ""),
                    )

                    scripts: dict[str, str] = {}
                    if "script" in port_data:
                        scripts = dict(port_data["script"])

                    ports.append(PortInfo(
                        port=port_num,
                        protocol=proto,
                        state=state,
                        service=service,
                        scripts=scripts,
                    ))

            # ── OS detection ──────────────────────────────────────
            os_matches: list[str] = []
            if "osmatch" in host_data:
                os_matches = [m.get("name", "") for m in host_data["osmatch"] if m.get("name")]

            hosts.append(HostInfo(
                ip=host_ip,
                hostname=host_data.hostname() if hasattr(host_data, "hostname") else "",
                state=host_data.state() if hasattr(host_data, "state") else "up",
                os_matches=os_matches,
                ports=ports,
            ))

        return ScanResult(
            scan_id=scan_id,
            scan_type=scan_type,
            target=target,
            started_at=started,
            finished_at=datetime.now(timezone.utc),
            hosts=hosts,
            raw_output=self._scanner.csv(),
        )

    async def _run_scan(
        self,
        target: str,
        arguments: str,
        scan_type: ScanType,
        ports: str | None = None,
    ) -> ScanResult:
        """Execute an nmap scan in a background thread."""
        scan_id = self._gen_id()
        started = datetime.now(timezone.utc)
        _log.info(f"[{scan_id}] Starting {scan_type.value} scan on {target}  args={arguments}")

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(
            None,
            lambda: self._scanner.scan(
                hosts=target,
                ports=ports or "",
                arguments=arguments,
            ),
        )

        result = self._parse_results(target, scan_type, scan_id, started)
        _log.info(
            f"[{scan_id}] Scan complete — "
            f"{len(result.hosts)} host(s), "
            f"{sum(len(h.ports) for h in result.hosts)} port(s)"
        )
        return result

    # ── public scan functions ─────────────────────────────────────────

    async def stealth_scan(
        self,
        target: str,
        ports: str = "1-1024",
    ) -> ScanResult:
        """SYN stealth scan (``-sS -T4``).

        Sends SYN packets without completing the TCP handshake, reducing
        the chance of detection by target-side logging.
        """
        return await self._run_scan(target, "-sS -T4", ScanType.STEALTH, ports)

    async def full_audit(self, target: str) -> ScanResult:
        """Audit all 65 535 ports (``-sS -T4 -p 0-65535``)."""
        return await self._run_scan(target, "-sS -T4 -p 0-65535", ScanType.FULL)

    async def service_fingerprint(
        self,
        target: str,
        ports: str = "1-1024",
    ) -> ScanResult:
        """Version detection (``-sV --version-intensity 5``)."""
        return await self._run_scan(
            target, "-sV --version-intensity 5", ScanType.SERVICE, ports
        )

    async def os_detection(self, target: str) -> ScanResult:
        """Operating system fingerprinting (``-O --osscan-guess``)."""
        return await self._run_scan(target, "-O --osscan-guess", ScanType.OS_DETECT)

    async def fragment_scan(
        self,
        target: str,
        ports: str = "1-1024",
    ) -> ScanResult:
        """Fragmented packet scan for firewall evasion (``-sS -f -T4``)."""
        return await self._run_scan(target, "-sS -f -T4", ScanType.FRAGMENT, ports)

    async def decoy_scan(
        self,
        target: str,
        decoys: list[str] | None = None,
        ports: str = "1-1024",
    ) -> ScanResult:
        """Decoy IP scan for IDS evasion (``-sS -D <decoys>``)."""
        decoy_str = ",".join(decoys) if decoys else "RND:5"
        return await self._run_scan(
            target, f"-sS -T4 -D {decoy_str}", ScanType.DECOY, ports
        )

    async def custom_nse(
        self,
        target: str,
        scripts: str | list[str] = "default",
        ports: str = "1-1024",
        script_args: str = "",
    ) -> ScanResult:
        """Run user-supplied NSE scripts.

        Args:
            target:      Host specification.
            scripts:     Comma-separated script names or a list.
            ports:       Port specification.
            script_args: Additional ``--script-args`` string.
        """
        if isinstance(scripts, list):
            scripts = ",".join(scripts)
        args = f"-sV --script={scripts}"
        if script_args:
            args += f" --script-args={script_args}"
        return await self._run_scan(target, args, ScanType.CUSTOM_NSE, ports)


# ═══════════════════════════════════════════════════════════════════════════
# Scapy Prober (raw-packet level)
# ═══════════════════════════════════════════════════════════════════════════

class ScapyProber:
    """Low-level packet probes using Scapy.

    These complement the Nmap scanner for cases requiring crafted packets
    or when nmap is not available on the host.
    """

    @staticmethod
    async def syn_probe(target: str, port: int, timeout: float = 3.0) -> PortState:
        """Send a single SYN packet and interpret the response.

        Returns:
            :class:`PortState` — ``OPEN`` if SYN-ACK, ``CLOSED`` if RST,
            ``FILTERED`` if no response.
        """
        loop = asyncio.get_running_loop()

        def _probe() -> PortState:
            # Lazy import so users without scapy installed still get clean errors.
            from scapy.all import IP, TCP, sr1  # type: ignore[import-untyped]

            pkt = IP(dst=target) / TCP(dport=port, flags="S")
            resp = sr1(pkt, timeout=timeout, verbose=0)

            if resp is None:
                return PortState.FILTERED
            tcp_layer = resp.getlayer(TCP)
            if tcp_layer is None:
                return PortState.FILTERED
            if tcp_layer.flags == 0x12:  # SYN-ACK
                return PortState.OPEN
            if tcp_layer.flags & 0x04:  # RST
                return PortState.CLOSED
            return PortState.FILTERED

        return await loop.run_in_executor(None, _probe)

    @staticmethod
    async def ack_probe(target: str, port: int, timeout: float = 3.0) -> str:
        """ACK probe for firewall rule detection.

        Returns:
            ``"unfiltered"`` if RST received (no stateful firewall),
            ``"filtered"`` otherwise.
        """
        loop = asyncio.get_running_loop()

        def _probe() -> str:
            from scapy.all import IP, TCP, sr1  # type: ignore[import-untyped]

            pkt = IP(dst=target) / TCP(dport=port, flags="A")
            resp = sr1(pkt, timeout=timeout, verbose=0)
            if resp and resp.getlayer(TCP) and resp.getlayer(TCP).flags & 0x04:
                return "unfiltered"
            return "filtered"

        return await loop.run_in_executor(None, _probe)


# ═══════════════════════════════════════════════════════════════════════════
# Port Router — autonomous service-module dispatch
# ═══════════════════════════════════════════════════════════════════════════

class PortRouter:
    """Inspects scan results and dispatches service-specific modules.

    The router maps open ports to handler coroutines. When :meth:`route` is
    called, matching handlers are launched concurrently via ``asyncio``.
    """

    # Default port → module-name mapping.  Handlers are registered at runtime.
    DEFAULT_PORT_MAP: dict[int, str] = {
        21: "ftp",
        22: "ssh",
        23: "telnet",
        25: "smtp",
        53: "dns",
        80: "http",
        110: "pop3",
        143: "imap",
        443: "https",
        445: "smb",
        3306: "mysql",
        3389: "rdp",
        5432: "postgres",
        5900: "vnc",
        6379: "redis",
        6667: "irc",
        8080: "http-proxy",
        8443: "https-alt",
        27017: "mongodb",
    }

    def __init__(self) -> None:
        self._handlers: dict[str, Any] = {}

    def register(self, service_name: str, handler: Any) -> None:
        """Register an async handler for a service name.

        Args:
            service_name: One of the values in :attr:`DEFAULT_PORT_MAP`.
            handler:      An async callable ``(host_ip, port_info) → result``.
        """
        self._handlers[service_name] = handler
        _log.debug(f"Registered handler for service '{service_name}'")

    async def route(self, result: ScanResult) -> dict[str, list[Any]]:
        """Dispatch handlers for every open port in *result*.

        Returns:
            Mapping ``service_name → [handler_result, …]``.
        """
        tasks: list[tuple[str, asyncio.Task[Any]]] = []

        for host in result.hosts:
            for port_info in host.ports:
                if port_info.state != PortState.OPEN:
                    continue

                svc = self.DEFAULT_PORT_MAP.get(port_info.port)
                if svc is None:
                    svc = port_info.service.name

                handler = self._handlers.get(svc)
                if handler:
                    task = asyncio.create_task(handler(host.ip, port_info))
                    tasks.append((svc, task))
                    _log.info(
                        f"Dispatched '{svc}' handler for "
                        f"{host.ip}:{port_info.port}"
                    )
                else:
                    _log.debug(
                        f"No handler for service '{svc}' on "
                        f"{host.ip}:{port_info.port} — skipping"
                    )

        results: dict[str, list[Any]] = {}
        for svc, task in tasks:
            try:
                res = await task
                results.setdefault(svc, []).append(res)
            except Exception as exc:
                _log.error(f"Handler '{svc}' raised: {exc}")
                results.setdefault(svc, []).append({"error": str(exc)})

        return results
