"""
Luvia — Autonomous AI-Driven Network Penetration Testing Library.

Luvia orchestrates reconnaissance, vulnerability identification, and AI-powered
remediation. It uses recursive logic to switch between ports and services until
a vulnerability is found or the target is fully mapped.
"""

__version__ = "0.1.0"
__author__ = "Luvia Team"
