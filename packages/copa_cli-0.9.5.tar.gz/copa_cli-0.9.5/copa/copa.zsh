# Copa — shell integration for zsh
# Add to your .zshrc:  eval "$(copa init zsh)"
#
# First time? Run these to get started:
#   copa _init          # create the database
#   copa sync           # import your shell history
#   copa doctor         # check everything is set up
#
# What this does:
#   1. Records every command you run (precmd hook, background, zero latency)
#   2. Replaces Ctrl+R with an fzf command palette that searches across
#      command text AND descriptions — not just raw history
#   3. Ctrl+R cycles modes inside fzf: all → frequent → recent → recipes → all
#   4. Ctrl+X opens a compose submenu to append shell operators (|, &&, &, etc.)

# --- Load keybinding config (runs once at shell startup) ---
eval "$(copa _fzf-config 2>/dev/null)" || {
  # Fallback defaults if copa _fzf-config fails
  _COPA_EXPECT=''
  _COPA_DESCRIBE_KEY='ctrl-d'
  _COPA_GROUP_KEY='ctrl-g'
  _COPA_FLAGS_KEY='ctrl-f'
  _COPA_FILTER_GROUP_KEY='ctrl-s'
  _COPA_CYCLE_GROUP_KEY='ctrl-n'
  _COPA_TOGGLE_HEADER_KEY='ctrl-h'
  _COPA_COMPOSE_KEY='ctrl-x'
  _COPA_SELECT_KEY='ctrl-b'
  _COPA_HEIGHT='80%'
  _COPA_PREVIEW_SIZE='40%'
  _COPA_COMPLETION_BRANDING='true'
  _COPA_COMPLETION_MODE='hybrid'
  _COPA_SUGGEST_ENABLED='true'
  _COPA_SUGGEST_MIN_LENGTH='2'
  _COPA_SUGGEST_TAB_ACCEPT='2'
  _COPA_SUGGEST_COLOR='242'
  _COPA_SUGGEST_DIR_AWARE='true'
  _COPA_HEADER='Copa | ^R:cycle | ^X:compose | ^G:grp | ^D:desc | ^F:flag | ^S:scope | ^N:↻grp | ^B:sel | ^H:keys'
}

# --- precmd hook: record last command ---
_copa_precmd() {
  (( $+commands[copa] )) || return
  local last_cmd
  last_cmd="$(fc -ln -1 2>/dev/null)"
  last_cmd="${last_cmd## }"  # strip leading space
  if [[ -n "$last_cmd" && "$last_cmd" != _copa_* ]]; then
    copa _record "$last_cmd" --cwd "$PWD" </dev/null &>/dev/null &!
  fi
}

# Add to precmd hooks (avoid duplicates)
autoload -Uz add-zsh-hook
add-zsh-hook precmd _copa_precmd

# --- Wrap header to fit terminal width ---
# Splits the " | "-delimited header into lines that fit within $COLUMNS.
_copa_wrap_header() {
  local raw="$1"
  local full_width="${COLUMNS:-80}"
  # Account for fzf preview pane (e.g. "40%" or "40")
  local preview="${_COPA_PREVIEW_SIZE:-40%}"
  local width=$full_width
  if [[ "$preview" == *% ]]; then
    local pct="${preview%%%}"
    width=$(( full_width * (100 - pct) / 100 ))
  fi
  local -a items
  items=("${(@s: | :)raw}")
  local line="" result="" candidate
  for item in "${items[@]}"; do
    if [[ -z "$line" ]]; then
      candidate="$item"
    else
      candidate="$line | $item"
    fi
    if (( ${#candidate} > width )) && [[ -n "$line" ]]; then
      [[ -n "$result" ]] && result+=$'\n'
      result+="$line"
      line="$item"
    else
      line="$candidate"
    fi
  done
  [[ -n "$line" ]] && { [[ -n "$result" ]] && result+=$'\n'; result+="$line"; }
  echo "$result"
}

# --- Ctrl+R: fzf-powered command palette ---
# Replaces default zsh reverse-search. fzf searches all visible fields:
# command text, description, group badges, shared-set names, and frequency.
# Selected command is placed into the prompt without executing.
# Composition keys (configured via copa _fzf-config) append shell operators.
# Requires fzf: brew install fzf
_copa_fzf_widget() {
  [[ "$_COPA_SUGGEST_ENABLED" == 'true' ]] && _copa_suggest_clear
  if ! command -v fzf &>/dev/null; then
    zle -M "Copa: fzf not found. Install with: brew install fzf"
    return 1
  fi

  local mode="all"
  local output
  local copa_bin="${commands[copa]:-copa}"
  local _copa_modal_file=$(mktemp -t copa_modal.XXXXXX)
  local _copa_compose_file=$(mktemp -t copa_compose.XXXXXX)
  local accumulated=""

  while true; do
    # Clear compose file for this iteration
    > "$_copa_compose_file"

    # Build prompt showing accumulated chain
    local prompt_text="copa> "
    if [[ -n "$accumulated" ]]; then
      local display="$accumulated"
      if (( ${#display} > 30 )); then
        display="...${display: -30}"
      fi
      prompt_text="copa [${display}]> "
    fi

    # Preview command: auto-detect recipe IDs (prefixed with 'r') vs command IDs
    local preview_cmd="id={1}; if [[ \$id == r* ]]; then $copa_bin _recipe-preview \${id#r}; else $copa_bin _preview \$id; fi"

    # Wrap header to fit terminal width
    local wrapped_header
    wrapped_header=$(_copa_wrap_header "$_COPA_HEADER")

    # Build fzf args dynamically
    local -a fzf_args=(
        --ansi
        --delimiter '┃'
        --with-nth '2..3'
        --preview "$preview_cmd"
        --preview-window "right:${_COPA_PREVIEW_SIZE}:wrap"
        --header "$wrapped_header"
        --prompt "$prompt_text"
        --height "${_COPA_HEIGHT}"
        --layout reverse
        --bind "${_COPA_DESCRIBE_KEY}:execute($copa_bin describe {1})+refresh-preview"
        --bind "${_COPA_FLAGS_KEY}:execute($copa_bin _set-flags {1})+reload($copa_bin fzf-list)+refresh-preview"
        --bind "${_COPA_FILTER_GROUP_KEY}:reload($copa_bin _list-groups)+change-prompt(scope> )+clear-query+hide-preview"
        --bind "${_COPA_GROUP_KEY}:transform:
          echo {1} > ${_copa_modal_file};
          echo \"reload(${copa_bin} _list-groups-for-assign)+change-prompt(group> )+clear-query+hide-preview\""
        --bind "${_COPA_CYCLE_GROUP_KEY}:transform:
          cur_group='(all)';
          if [[ \$FZF_PROMPT =~ 'copa \\[(.+)\\]> ' ]]; then
            cur_group=\"\${match[1]}\";
          fi;
          next=\$(${copa_bin} _next-group \"\$cur_group\");
          if [[ \$next == '(all)' ]]; then
            echo \"reload(${copa_bin} fzf-list --mode all)+change-prompt(copa> )\";
          else
            echo \"reload(${copa_bin} fzf-list --mode group --group \$next)+change-prompt(copa [\$next]> )\";
          fi"
        --bind 'ctrl-r:transform:
          if [[ $FZF_PROMPT == "copa> " ]]; then
            echo "reload('"$copa_bin"' fzf-list --mode frequent)+change-prompt(frequent> )"
          elif [[ $FZF_PROMPT == "frequent> " ]]; then
            echo "reload('"$copa_bin"' fzf-list --mode recent)+change-prompt(recent> )"
          elif [[ $FZF_PROMPT == "recent> " ]]; then
            echo "reload('"$copa_bin"' fzf-list --mode recipes)+change-prompt(recipes> )"
          else
            echo "reload('"$copa_bin"' fzf-list --mode all)+change-prompt(copa> )"
          fi'
        --bind "${_COPA_TOGGLE_HEADER_KEY}:toggle-header"
        --bind "${_COPA_SELECT_KEY}:execute-silent(printf 'SELECT' > ${_copa_compose_file})+accept"
        --bind "${_COPA_COMPOSE_KEY}:execute-silent(printf 'COMPOSE' > ${_copa_compose_file})+accept"
        --bind 'enter:transform:
          if [[ $FZF_PROMPT == "scope> " ]]; then
            selected="{2}";
            if [[ $selected == "(all)" ]]; then
              echo "reload('"$copa_bin"' fzf-list --mode all)+change-prompt(copa> )+clear-query+show-preview"
            else
              echo "reload('"$copa_bin"' fzf-list --mode group --group $selected)+change-prompt(copa [$selected]> )+clear-query+show-preview"
            fi
          elif [[ $FZF_PROMPT == "group> " ]]; then
            cmd_id=$(cat '"${_copa_modal_file}"');
            selected="{2}";
            '"$copa_bin"' _set-group-direct "$cmd_id" "$selected";
            echo "reload('"$copa_bin"' fzf-list)+change-prompt(copa> )+clear-query+show-preview"
          else
            echo "accept"
          fi'
        --bind 'esc:transform:
          if [[ $FZF_PROMPT == "scope> " || $FZF_PROMPT == "group> " ]]; then
            echo "reload('"$copa_bin"' fzf-list)+change-prompt(copa> )+clear-query+show-preview"
          else
            echo "abort"
          fi'
    )

    output=$("$copa_bin" fzf-list --mode "$mode" | fzf "${fzf_args[@]}")

    local compose_action=""
    [[ -s "$_copa_compose_file" ]] && compose_action=$(<"$_copa_compose_file")

    if [[ "$compose_action" == "SELECT" ]]; then
      _copa_select_mode "$copa_bin"
      break
    fi

    if [[ -n "$output" ]]; then
      local selected cmd
      selected=$(echo "$output" | tail -1)

      if [[ -n "$selected" && "$selected" == *┃* ]]; then
        local id_field="${selected%%┃*}"
        id_field="${id_field// /}"

        # Recipe mode: expand recipe steps to && chain
        if [[ "$id_field" == r* ]]; then
          local recipe_id="${id_field#r}"
          cmd=$("$copa_bin" _recipe-expand "$recipe_id" 2>/dev/null)
          [[ -z "$cmd" ]] && cmd=$(echo "$selected" | cut -d'┃' -f2 | sed 's/^ *//;s/ *$//')
        else
          cmd=$(echo "$selected" | cut -d'┃' -f2 | sed 's/^ *//;s/ *$//')
        fi

        if [[ "$compose_action" == "COMPOSE" ]]; then
          # Show compose submenu (fzf-based)
          local suffix
          suffix=$(_copa_compose_menu)
          if [[ -n "$suffix" ]]; then
            local behavior=$(_copa_compose_behavior "$suffix")
            if [[ "$behavior" == "continue" ]]; then
              accumulated="${accumulated}${cmd}${suffix}"
              continue
            else
              LBUFFER="${accumulated}${cmd}${suffix}"
            fi
          else
            # Cancelled — return to the main fzf palette
            accumulated="${accumulated}"
            continue
          fi
        else
          LBUFFER="${accumulated}${cmd}"
        fi
      fi
    fi
    break
  done

  [[ -f "$_copa_modal_file" ]] && rm -f "$_copa_modal_file"
  [[ -f "$_copa_compose_file" ]] && rm -f "$_copa_compose_file"

  zle reset-prompt
}

# --- Compose submenu: pick a shell operator via fzf ---
_copa_compose_menu() {
  local choice
  choice=$(printf '%s\n' \
    '|           pipe         → re-opens fzf' \
    '&&          chain        → re-opens fzf' \
    '>           redirect     → re-opens fzf' \
    '&           background' \
    '2>&1        merge stderr' \
    '2>/dev/null suppress stderr' \
  | fzf \
      --height 10 \
      --layout reverse \
      --prompt 'compose> ' \
      --header 'Select operator · Tab/↑↓:navigate · Enter:select · Esc:cancel' \
      --no-info \
      --no-sort \
      --pointer '▶' \
      --color 'pointer:yellow' \
  )

  [[ -z "$choice" ]] && return

  # Extract operator (first whitespace-delimited token)
  local op="${choice%% *}"
  case "$op" in
    '|')           echo " | " ;;
    '&&')          echo " && " ;;
    '>')           echo " > " ;;
    '&')           echo " &" ;;
    '2>&1')        echo " 2>&1" ;;
    '2>/dev/null') echo " 2>/dev/null" ;;
  esac
}

# --- Compose behavior: continue (re-open fzf) or close ---
_copa_compose_behavior() {
  case "$1" in
    " | "|" && "|" > ") echo "continue" ;;
    *) echo "close" ;;
  esac
}

# --- Select mode: multi-select items then batch-operate ---
_copa_select_mode() {
  local copa_bin="${1:-${commands[copa]:-copa}}"
  local select_output

  select_output=$("$copa_bin" fzf-list --mode all | fzf \
    --ansi \
    --multi \
    --delimiter '┃' \
    --with-nth '2..3' \
    --preview "$copa_bin _preview {1}" \
    --preview-window "right:${_COPA_PREVIEW_SIZE}:wrap" \
    --header "SELECT MODE | Tab:toggle | Enter:batch action | Esc:cancel" \
    --prompt "select> " \
    --height "${_COPA_HEIGHT}" \
    --layout reverse \
    --bind 'ctrl-r:transform:
      if [[ $FZF_PROMPT == "select> " ]]; then
        echo "reload('"$copa_bin"' fzf-list --mode frequent)+change-prompt(select [frequent]> )"
      elif [[ $FZF_PROMPT == "select [frequent]> " ]]; then
        echo "reload('"$copa_bin"' fzf-list --mode recent)+change-prompt(select [recent]> )"
      else
        echo "reload('"$copa_bin"' fzf-list --mode all)+change-prompt(select> )"
      fi'
  )

  [[ -z "$select_output" ]] && return

  # Parse selected IDs from output lines
  local -a selected_ids
  local line
  while IFS= read -r line; do
    if [[ "$line" == *┃* ]]; then
      local id_field="${line%%┃*}"
      id_field="${id_field// /}"  # trim spaces
      [[ -n "$id_field" ]] && selected_ids+=("$id_field")
    fi
  done <<< "$select_output"

  (( ${#selected_ids} == 0 )) && return

  # Show batch action menu via tty
  local count=${#selected_ids}
  local action
  local _copa_tty
  exec {_copa_tty}</dev/tty

  echo "Selected $count command(s)." >&$_copa_tty
  echo "  g = assign group" >&$_copa_tty
  echo "  d = delete" >&$_copa_tty
  echo "  a = auto-describe (LLM)" >&$_copa_tty
  echo "  q = cancel" >&$_copa_tty
  echo -n "Action: " >&$_copa_tty
  read -u $_copa_tty action

  exec {_copa_tty}<&-

  case "$action" in
    g)
      "$copa_bin" _batch-group "${selected_ids[@]}"
      ;;
    d)
      "$copa_bin" _batch-delete "${selected_ids[@]}"
      ;;
    a)
      "$copa_bin" _batch-describe "${selected_ids[@]}"
      ;;
  esac
}

zle -N _copa_fzf_widget
bindkey '^R' _copa_fzf_widget

# --- Tab completion ---
# Ensure zsh completion system is available, then register Copa completions.
if ! (( $+functions[compdef] )); then
  autoload -Uz compinit && compinit -i -C
fi
eval "$(copa completion zsh 2>/dev/null)"

# --- Supplemental tab completion from Copa database ---
# Mode is controlled by _COPA_COMPLETION_MODE (set via copa _fzf-config):
#   fallback — only when native completers found nothing (default)
#   always   — Copa completions replace native completions
#   hybrid   — Copa completions shown alongside native completions
#   never    — disable Copa tab completion entirely
if [[ "$_COPA_COMPLETION_MODE" != 'never' ]]; then

# Suggestion completer: runs FIRST so menu-complete highlights the Copa
# suggestion before native completions.  No-op when nothing is pending.
# Always returns 1 so the chain continues to _complete and _copa_history_complete;
# compadd matches persist across completers regardless of return value.
_copa_suggestion_complete() {
    [[ -z "$_COPA_SUGGEST_PENDING" ]] && return 1
    local pending="$_COPA_SUGGEST_PENDING"
    _COPA_SUGGEST_PENDING=""
    local cur_word="${words[CURRENT]}"
    local prefix_len=$(( ${#LBUFFER} - ${#cur_word} ))
    local insert_text="${pending:$prefix_len}"
    if [[ -n "$insert_text" ]]; then
        compadd -U -Q -S '' -V 'copa-suggestion' -X 'SUGGESTED' -o nosort -- "$insert_text"
    fi
    compstate[list]='list force'
    return 1  # don't stop chain — let _complete and _copa_history_complete also run
}

_copa_history_complete() {
    # In fallback mode, only show when native completers found nothing
    if [[ "$_COPA_COMPLETION_MODE" == 'fallback' ]]; then
        (( compstate[nmatches] > 0 )) && return
    fi
    # Skip bare <TAB> on empty line; allow empty subcommand completion in hybrid/always
    if [[ -z "${words[CURRENT]}" ]]; then
        (( CURRENT <= 1 )) && return
        [[ "$_COPA_COMPLETION_MODE" == 'fallback' ]] && return
    fi
    # Skip internal copa commands
    [[ "${words[CURRENT]}" == _copa_* ]] && return
    local -a results
    results=("${(@f)$(copa _complete-word "${(@)words[1,CURRENT]}" 2>/dev/null)}")
    if (( ${#results} )); then
        if [[ "$_COPA_COMPLETION_MODE" == 'always' ]]; then
            # Replace: clear native matches, add only Copa results
            compadd -U -S '' -V 'copa-history' -X 'COPA HISTORY' -o nosort -- "${results[@]}"
        else
            # fallback & hybrid: add Copa results as a separate group
            compadd -S '' -V 'copa-history' -X 'COPA HISTORY' -o nosort -- "${results[@]}"
        fi
    fi
}

# Append to existing completers without clobbering user config.
# _copa_suggestion_complete runs first so menu-complete highlights
# the Copa suggestion; _copa_history_complete runs last for history matches.
() {
    local -a cur
    zstyle -g cur ':completion:*' completer 2>/dev/null
    if (( ! ${cur[(Ie)_copa_history_complete]} )); then
        zstyle ':completion:*' completer _copa_suggestion_complete ${cur:-_complete} _copa_history_complete _files
    fi
    # Enable group separation so Copa results appear as a distinct section
    zstyle ':completion:*' group-name ''
    # Copa suggestion first, then Copa history, then native completions
    zstyle ':completion:*' group-order copa-suggestion copa-history
    # Interactive menu with highlighting
    zstyle ':completion:*' menu select
    zmodload zsh/complist 2>/dev/null
    # Tab cycles forward through completions (standard behavior)
    bindkey -M menuselect '^I' menu-complete
    # Shift+Tab cycles backward
    bindkey -M menuselect '^[[Z' reverse-menu-complete
    # Enter accepts the highlighted completion
    bindkey -M menuselect '^M' accept-search
    bindkey -M menuselect '^J' accept-search
    # Escape cancels the menu and restores the original buffer
    bindkey -M menuselect '^[' send-break
    # Space accepts the highlighted completion
    bindkey -M menuselect ' ' accept-search
    # Raise threshold before "show all N?" prompt
    LISTMAX=200
    # Copa completion branding: show group description headers
    if [[ "$_COPA_COMPLETION_BRANDING" != 'false' ]]; then
        zstyle ':completion:*:descriptions' format '%F{cyan}%B──── %d ────%b%f'
    fi
}

fi  # end _COPA_COMPLETION_MODE != 'never'

# --- Inline suggestions (ghost text) ---
# Shows grey suggestion text after the cursor as you type.
# Controlled by _COPA_SUGGEST_ENABLED (set via copa _fzf-config).
if [[ "$_COPA_SUGGEST_ENABLED" == 'true' ]]; then
zmodload zsh/datetime 2>/dev/null  # provides EPOCHREALTIME for debouncing

typeset -g _COPA_SUGGESTION=""
typeset -g _COPA_SUGGEST_LATCHED=0  # 1 = suppressed (backspace latch)
typeset -g _COPA_SUGGEST_PENDING=""  # full suggestion passed to completion system
typeset -g _COPA_SUGGEST_PASTING=0  # 1 = inside a bracketed paste
typeset -g _COPA_SUGGEST_LAST_FETCH=0  # epoch ms of last fetch
typeset -gi _COPA_SUGGEST_DEBOUNCE_MS=80  # min ms between fetches

# _copa_suggest_clear is always defined (used by _copa_fzf_widget)
_copa_suggest_clear() {
  _COPA_SUGGESTION=""
  _COPA_SUGGEST_PENDING=""
  POSTDISPLAY=""
  region_highlight=()
}

_copa_suggest_fetch() {
  _COPA_SUGGESTION=""
  _COPA_SUGGEST_PENDING=""
  POSTDISPLAY=""
  region_highlight=()
  (( _COPA_SUGGEST_PASTING )) && return  # skip during paste
  (( _COPA_SUGGEST_LATCHED )) && return  # suppressed by backspace latch
  (( ${#BUFFER} < _COPA_SUGGEST_MIN_LENGTH )) && return
  (( CURSOR != ${#BUFFER} )) && return  # skip if cursor not at end

  # Debounce: skip if last fetch was too recent (avoids subprocess flood on fast typing)
  local now_ms
  if [[ -n "$EPOCHREALTIME" ]]; then
    # EPOCHREALTIME is e.g. "1774041695.803544" — extract seconds and first 3 decimals
    local secs="${EPOCHREALTIME%%.*}"
    local frac="${EPOCHREALTIME#*.}"
    frac="${frac:0:3}"  # first 3 digits = milliseconds
    now_ms=$(( secs * 1000 + ${frac:-0} ))
  else
    now_ms=$(( EPOCHSECONDS * 1000 ))
  fi
  if (( now_ms - _COPA_SUGGEST_LAST_FETCH < _COPA_SUGGEST_DEBOUNCE_MS )); then
    return
  fi
  _COPA_SUGGEST_LAST_FETCH=$now_ms

  local result
  local _suggest_args=("$BUFFER")
  [[ "$_COPA_SUGGEST_DIR_AWARE" == 'true' ]] && _suggest_args+=(--cwd "$PWD")
  result=$(copa _suggest "${_suggest_args[@]}" 2>/dev/null)
  if [[ -n "$result" && "$result" != "$BUFFER" ]]; then
    _COPA_SUGGESTION="$result"
    local blen=${#BUFFER}
    local ghost="${result:$blen}"
    POSTDISPLAY="$ghost"
    # Use buffer-relative offsets that extend into POSTDISPLAY
    region_highlight=("$blen $(( blen + ${#ghost} )) fg=${_COPA_SUGGEST_COLOR:-242}")
  fi
}

# --- Widget wrappers ---

# Bracketed paste: suppress suggestions during paste, fetch once at end.
# Terminals send ESC[200~ before paste and ESC[201~ after.
_copa_suggest_bracketed_paste() {
  _COPA_SUGGEST_PASTING=1
  _copa_suggest_clear
  zle .bracketed-paste
  _COPA_SUGGEST_PASTING=0
  _COPA_SUGGEST_LATCHED=0
  _copa_suggest_fetch
}
zle -N bracketed-paste _copa_suggest_bracketed_paste

# self-insert: type a character, unlatch, then fetch suggestion
_copa_suggest_self_insert() {
  _COPA_SUGGEST_LATCHED=0
  zle .self-insert
  _copa_suggest_fetch
}
zle -N self-insert _copa_suggest_self_insert

# backward-delete-char (Backspace): latch — suppress suggestions until Tab
_copa_suggest_backward_delete_char() {
  _COPA_SUGGEST_LATCHED=1
  _copa_suggest_clear
  zle .backward-delete-char
}
zle -N backward-delete-char _copa_suggest_backward_delete_char

# Tab: accept suggestion or open completion menu.
# Don't call _copa_suggest_fetch after menu-complete — menu-select
# runs asynchronously and fetch would overwrite the display with
# ghost text.  The self-insert wrapper re-fetches on the next keystroke.
_copa_suggest_expand_or_complete() {
  if [[ -n "$_COPA_SUGGESTION" ]]; then
    if [[ "$_COPA_SUGGEST_TAB_ACCEPT" == '1' ]]; then
      # tab_accept=1: directly accept the suggestion
      BUFFER="$_COPA_SUGGESTION"
      CURSOR=${#BUFFER}
      _copa_suggest_clear
    else
      # tab_accept=2: open completion menu with suggestion highlighted.
      # menu-complete enters menu-select mode reliably (unlike
      # .expand-or-complete which bypasses menu-select).  With
      # group-order copa-suggestion copa-history, menu-select cycles
      # in display order, so the Copa suggestion is highlighted first.
      local pending="$_COPA_SUGGESTION"
      _copa_suggest_clear
      _COPA_SUGGEST_PENDING="$pending"
      zle menu-complete
    fi
    return
  fi
  if (( _COPA_SUGGEST_LATCHED )); then
    _COPA_SUGGEST_LATCHED=0
    _copa_suggest_fetch
    return
  fi
  zle menu-complete
}
zle -N _copa_suggest_expand_or_complete
bindkey '^I' _copa_suggest_expand_or_complete

# forward-char (Right arrow): accept one word if ghost text showing at EOL
_copa_suggest_forward_char() {
  if [[ -n "$POSTDISPLAY" && -n "$_COPA_SUGGESTION" && $CURSOR -eq ${#BUFFER} ]]; then
    # Accept one word from the suggestion
    local suffix="${_COPA_SUGGESTION:${#BUFFER}}"
    local word
    # Extract leading whitespace + next word
    if [[ "$suffix" =~ ^[[:space:]]*[^[:space:]]+ ]]; then
      word="$MATCH"
    else
      word="$suffix"
    fi
    BUFFER="${BUFFER}${word}"
    CURSOR=${#BUFFER}
    # Update ghost text from existing suggestion (no re-query, no flicker)
    local blen=${#BUFFER}
    local remaining="${_COPA_SUGGESTION:$blen}"
    if [[ -n "$remaining" ]]; then
      POSTDISPLAY="$remaining"
      region_highlight=("$blen $(( blen + ${#remaining} )) fg=${_COPA_SUGGEST_COLOR:-242}")
    else
      # Fully accepted; clear and re-fetch for extended suggestions
      _copa_suggest_clear
      _COPA_SUGGEST_LATCHED=0
      _copa_suggest_fetch
    fi
  else
    zle .forward-char
  fi
}
zle -N forward-char _copa_suggest_forward_char

# forward-word: same as forward-char when ghost text showing
_copa_suggest_forward_word() {
  if [[ -n "$POSTDISPLAY" && -n "$_COPA_SUGGESTION" && $CURSOR -eq ${#BUFFER} ]]; then
    _copa_suggest_forward_char
  else
    zle .forward-word
  fi
}
zle -N forward-word _copa_suggest_forward_word

# end-of-line (Cmd+Right / End): accept full suggestion if ghost text showing
_copa_suggest_end_of_line() {
  if [[ -n "$POSTDISPLAY" && -n "$_COPA_SUGGESTION" && $CURSOR -eq ${#BUFFER} ]]; then
    BUFFER="$_COPA_SUGGESTION"
    CURSOR=${#BUFFER}
    _copa_suggest_clear
    _COPA_SUGGEST_LATCHED=0
    _copa_suggest_fetch
  else
    zle .end-of-line
  fi
}
zle -N end-of-line _copa_suggest_end_of_line

# accept-line (Enter): clear suggestion + latch, then execute
_copa_suggest_accept_line() {
  _copa_suggest_clear
  _COPA_SUGGEST_LATCHED=0
  zle .accept-line
}
zle -N accept-line _copa_suggest_accept_line

# send-break (Esc): dismiss ghost text suggestion or normal
_copa_suggest_send_break() {
  if [[ -n "$POSTDISPLAY" && -n "$_COPA_SUGGESTION" ]]; then
    _copa_suggest_clear
    zle -R  # redraw to remove ghost text
  else
    _COPA_SUGGESTION=""  # clear stored suggestion silently
    zle .send-break
  fi
}
zle -N send-break _copa_suggest_send_break

# History navigation: clear suggestion then call original
_copa_suggest_up_line_or_history() {
  _copa_suggest_clear
  zle .up-line-or-history
}
zle -N up-line-or-history _copa_suggest_up_line_or_history

_copa_suggest_down_line_or_history() {
  if [[ -n "$_COPA_SUGGESTION" ]]; then
    local pending="$_COPA_SUGGESTION"
    _copa_suggest_clear
    _COPA_SUGGEST_PENDING="$pending"
    zle menu-complete
  else
    zle .down-line-or-history
  fi
}
zle -N down-line-or-history _copa_suggest_down_line_or_history

_copa_suggest_up_line_or_search() {
  _copa_suggest_clear
  zle .up-line-or-search
}
zle -N up-line-or-search _copa_suggest_up_line_or_search

_copa_suggest_down_line_or_search() {
  if [[ -n "$_COPA_SUGGESTION" ]]; then
    local pending="$_COPA_SUGGESTION"
    _copa_suggest_clear
    _COPA_SUGGEST_PENDING="$pending"
    zle menu-complete
  else
    zle .down-line-or-search
  fi
}
zle -N down-line-or-search _copa_suggest_down_line_or_search

# Editing operations: backward-kill latches, forward operations re-fetch
_copa_suggest_backward_kill_word() {
  _COPA_SUGGEST_LATCHED=1
  _copa_suggest_clear
  zle .backward-kill-word
}
zle -N backward-kill-word _copa_suggest_backward_kill_word

_copa_suggest_kill_word() {
  zle .kill-word
  _copa_suggest_fetch
}
zle -N kill-word _copa_suggest_kill_word

_copa_suggest_kill_line() {
  zle .kill-line
  _copa_suggest_fetch
}
zle -N kill-line _copa_suggest_kill_line

_copa_suggest_backward_kill_line() {
  _COPA_SUGGEST_LATCHED=1
  _copa_suggest_clear
  zle .backward-kill-line
}
zle -N backward-kill-line _copa_suggest_backward_kill_line

_copa_suggest_kill_whole_line() {
  _COPA_SUGGEST_LATCHED=1
  _copa_suggest_clear
  zle .kill-whole-line
}
zle -N kill-whole-line _copa_suggest_kill_whole_line

_copa_suggest_yank() {
  zle .yank
  _copa_suggest_fetch
}
zle -N yank _copa_suggest_yank

fi  # end _COPA_SUGGEST_ENABLED == 'true'
