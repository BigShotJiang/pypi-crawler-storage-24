from setuptools import setup, find_packages

setup(
    name='ranim_h',
    version='0.0.4',
    description='.',
    long_description=open('README.md').read(),
    author='Anthony Gocmen',
    author_email='anthony.gocmen@gmail.com',
    url='https://ag-algolab.github.io/',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    python_requires='>=3.11',
    install_requires=[],
    license='MIT'
)
