from datetime import datetime

SEPARATOR = "═" * 58
THIN_SEP  = "─" * 58

STATUSES = {
    (0, 3): {
        "emoji":  "💢",
        "status": "Ranim est actuellement très en colère",
        "risk":   "CRITIQUE",
        "color":  "🔴",
        "advice": (
            "Toute tentative de communication sera interprétée comme une agression.\n"
            "Ne pas envoyer de message, ne pas appeler, ne pas exister.\n"
            "En cas de contact accidentel : rester immobile et attendre que ça passe."
        ),
        "exam_note": "Niveau de danger multiplié par 2. Les révisions ont empiré les choses."
    },
    (3, 8): {
        "emoji":  "🔕",
        "status": "Ranim dort",
        "risk":   "MODÉRÉ",
        "color":  "🟡",
        "advice": (
            "Profiter de cette fenêtre de paix pour récupérer mentalement.\n"
        ),
        "exam_note": "Elle dort peut-être. Ou elle révise en silence. Ne pas déranger dans les deux cas."
    },
    (8, 12): {
        "emoji":  "😵",
        "status": "Ranim est fatiguée (qualité de sommeil : déplorable)",
        "risk":   "ÉLEVÉ",
        "color":  "🟠",
        "advice": (
            "Elle est physiquement présente mais cognitivement absente.\n"
            "Éviter les questions complexes, les débats et les blagues.\n"
            "Un thé peut améliorer temporairement la situation. Résultats non garantis."
        ),
        "exam_note": "Elle a probablement révisé jusqu'à 3h. Ne pas lui parler de l'examen."
    },
    (12, 19): {
        "emoji":  "🎲",
        "status": "Ranim est imprévisible",
        "risk":   "VARIABLE",
        "color":  "🟠",
        "advice": (
            "La fenêtre la plus dangereuse de la journée.\n"
            "Elle peut être de bonne humeur ou dévatatrice — parfois les deux en 4 minutes.\n"
            "Lire attentivement les signaux non-verbaux avant toute interaction."
        ),
        "exam_note": "Stress d'examen actif. Toute question sur ses révisions est à éviter absolument."
    },
    (19, 22): {
        "emoji":  "🍽️",
        "status": "Ranim est full",
        "risk":   "MOYEN",
        "color":  "🟡",
        "advice": (
            "La digestion mobilise toutes ses ressources cognitives disponibles.\n"
            "Éviter de parler rapidement en français : risque d'incompréhension totale.\n"
            "Préférer les échanges courts, simples, non-conflictuels."
        ),
        "exam_note": "Elle pense à l'examen de demain tout en mangeant. Ne pas en rajouter."
    },
    (22, 24): {
        "emoji":  "🌀",
        "status": "Ranim est mi-fatiguée, mi-énervée",
        "risk":   "ÉLEVÉ",
        "color":  "🔴",
        "advice": (
            "La folie n'a pas encore commencé, mais les prémices se font sentir.\n"
            "Elle est encore récupérable par une bonne conversation, mais la marge est étroite.\n"
            "Dans 1h elle passe en mode CRITIQUE — planifier sa sortie en conséquence."
        ),
        "exam_note": "Révisions de dernière minute en cours. Interaction fortement déconseillée."
    },
}

def get_status(hour: int) -> dict:
    for (start, end), data in STATUSES.items():
        if start <= hour < end:
            return data
    return STATUSES[(22, 24)]

def ask_exam() -> bool:
    print(THIN_SEP)
    print("Afin d'avoir une vue d'ensemble de la situation,")
    print("veuillez répondre à la question suivante :\n")
    answer = input("Ranim est-elle en période d'examens ? (Y/N) -> ").strip()
    while answer.lower() not in ('y', 'n'):
        answer = input("  Réponse invalide. Veuillez répondre par Y (oui) ou N (non) -> ").strip()
    return answer.lower() == 'y'

def ranim_now():
    now  = datetime.now()
    hour = now.hour

    print(f"\n{SEPARATOR}")
    print(f"{'🧠  RANIM BEHAVIOR FORECAST'}")
    print(SEPARATOR)
    print(f"🕐  Heure actuelle : {now.strftime('%H:%M:%S')}  —  {now.strftime('%A %d %B %Y')}")
    print()

    exam_soon = ask_exam()
    data = get_status(hour)

    print(f"\n{THIN_SEP}")
    print(f"{data['color']}  Niveau de risque : {data['risk']}")
    print(THIN_SEP)
    print(f"{data['emoji']}  Status  : {data['status']}")
    print(f"\n💡 Conseil :\n{data['advice']}")

    if exam_soon:
        print(f"\n📚 Alerte examens :\n{data['exam_note']}")
        print(f"Délai de réponse estimé : [1h ; +∞)")

    print(f"\n{SEPARATOR}")
    print(f"  Brought to you by AG Algo Lab — https://ag-algolab.github.io/")
    print(f"{SEPARATOR}\n")

