# ipee-lemon

Python library for controlling IPEE Lemon devices over Bluetooth Low Energy (BLE) and serial (CLI).

## Installation

Requires Python >= 3.12.

```bash
pip install ipee-lemon
```

Or with Poetry:

```bash
poetry add ipee-lemon
```

## BLE

Connect to a Lemon device over BLE using the async API built on [Bleak](https://github.com/hbldh/bleak).

```python
import asyncio
from ipee.lemon.ble.lemon_ble import LemonBleDevice

async def main():
    device = LemonBleDevice("AA:BB:CC:DD:EE:FF")
    await device.connect()

    # Send data via Nordic UART Service (NUS)
    await device.write("6E400002-B5A3-F393-E0A9-E50E24DCCA9E", b"hello")

    # Provision Wi-Fi credentials
    from ipee.lemon.ble.wifi_provision_service import WifiProvisioningService
    await device.write(WifiProvisioningService.SSID_UUID, b"MyNetwork")
    await device.write(WifiProvisioningService.PASSWORD_UUID, b"secret")

    # Trigger an OTA firmware update (requires Wi-Fi connection)
    from ipee.lemon.ble.ota_service import OtaService
    await device.write(OtaService.OTA_URL_UUID, b"https://example.com/firmware.bin")

    await device.disconnect()

asyncio.run(main())
```

`LemonBleDevice` comes with three services pre-registered:

| Service                | Purpose                                      |
|------------------------|----------------------------------------------|
| **NUS** (Nordic UART)  | Text-based communication with the device     |
| **Wi-Fi Provisioning** | Set SSID and password for network connection |
| **OTA**                | Trigger over-the-air firmware updates        |

## Serial (CLI)

Control a Lemon device over a serial connection using command wrappers built on [pySerial](https://github.com/pyserial/pyserial).

```python
from serial import Serial
from ipee.lemon.cli.cli_wifi_service import CliWifiService
from ipee.lemon.cli.cli_ble_service import CliBleService
from ipee.lemon.cli.cli_sweep_service import CliSweepService, SweepMeasurementType

ser = Serial("/dev/ttyUSB0", baudrate=115200)

# Wi-Fi
wifi = CliWifiService()
wifi.set_ssid(ser, "MyNetwork")
wifi.set_password(ser, "secret")
wifi.connect(ser)
info = wifi.get_connection_info(ser)
print(info.ip, info.subnet, info.gateway)

# BLE
ble = CliBleService()
ble.enable(ser)
ble.send(ser, "hello from serial")

# Voltage sweep
sweep = CliSweepService()
sweep.start_voltage(ser, 0)
sweep.end_voltage(ser, 3_300_000)
sweep.set_step_size(ser, 1000)
sweep.set_step_duration(ser, 500)
sweep.set_measurement_type(ser, SweepMeasurementType.AMPLITUDE)

ser.close()
```

Available CLI services:

| Service           | Tag         | Purpose                                   |
|-------------------|-------------|-------------------------------------------|
| `CliBleService`   | `ble`       | Enable/disable BLE, send NUS data         |
| `CliWifiService`  | `wifi`      | Configure and connect to Wi-Fi            |
| `CliOtaService`   | `ota_start` | Start OTA firmware update from a URL      |
| `CliLemonService` | `lemon`     | Set settle time and measurement frequency |
| `CliSweepService` | `sweep`     | Configure and run voltage sweeps          |

## Development

```bash
poetry install
make lint       # runs black, isort, flake8
```
