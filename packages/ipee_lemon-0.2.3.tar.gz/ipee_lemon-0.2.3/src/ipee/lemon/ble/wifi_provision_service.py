from .service import BleCharacteristic, BleService, CharMode


class WifiProvisioningService(BleService):
    """The Wi-Fi Provisioning Service is used for setting the SSID and PW of the AP to connect to.

    Once the SSID and Password are written, the device shall attempt connection.
    """

    SSID_UUID = "6E400005-B5A3-F393-E0A9-E50E24DCCA9E"
    PASSWORD_UUID = "6E400006-B5A3-F393-E0A9-E50E24DCCA9E"  # NOSONAR - not a password field

    def __init__(self):
        super().__init__(
            uuid="6E400004-B5A3-F393-E0A9-E50E24DCCA9E",
            name="Wifi provisioning service",
        )

        self.add_characteristic(
            BleCharacteristic(
                uuid=self.SSID_UUID,
                modes={CharMode.NOTIFY, CharMode.READ, CharMode.WRITE},
                description="The SSID to connect to",
            )
        )

        self.add_characteristic(
            BleCharacteristic(
                uuid=self.PASSWORD_UUID,
                modes={CharMode.WRITE},
                description="The password to connect to",
            )
        )
