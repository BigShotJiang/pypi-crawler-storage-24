from .device import BleCharacteristic, BleService, CharMode


class NUSService(BleService):
    """The NUS service is a BLEService that can be used for testing if the connection works

    it has a rx and tx characteristic that prints data on the command line.
    From the lemon perspective, you can send data to ble nodes by writing `ble send <some-text>`
    """

    RX_UUID = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
    TX_UUID = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"

    def __init__(self, on_rx=None):
        super().__init__(uuid="6E400001-B5A3-F393-E0A9-E50E24DCCA9E", name="Nordic UART Service")

        self.add_characteristic(
            BleCharacteristic(
                uuid=self.TX_UUID,
                modes={CharMode.NOTIFY},
                description="Device → Host",
                on_data=on_rx,
            )
        )

        self.add_characteristic(
            BleCharacteristic(
                uuid=self.RX_UUID, modes={CharMode.WRITE}, description="Host → Device"
            )
        )
