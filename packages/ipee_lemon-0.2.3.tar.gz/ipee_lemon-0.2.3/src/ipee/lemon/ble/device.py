from typing import Dict

from bleak import BleakClient

from .service import BleCharacteristic, BleService, CharMode


class BleDevice:
    """Base class for all BLE devices.

    For specific devices ble services and characteristics
    can be registered in their respective class through

    ```python
    ble_service = SpecificBleService()
    self.register_service(ble_service)
    ```

    """

    def __init__(self, address: str):
        self.address = address
        self.client = BleakClient(self.address)
        self.services: Dict[str, BleService] = {}

    def register_service(self, service: BleService):
        self.services[service.uuid] = service

    async def connect(self):
        await self.client.connect()
        # IMPORTANT: force service discovery
        for service in self.client.services:
            print(f"Service: {service.uuid}")
            for char in service.characteristics:
                print(f"  Characteristic: {char.uuid}")
        print("Connected: ", self.address)

        for service in self.services.values():
            for char in service.characteristics.values():
                if char.modes & {CharMode.NOTIFY, CharMode.INDICATE} and char.on_data:
                    await self.client.start_notify(char.uuid, self._make_data_handler(char))

    async def disconnect(self):
        await self.client.disconnect()

    @staticmethod
    def _make_data_handler(char: BleCharacteristic):
        def handler(_, data: bytearray):
            if char.on_data:
                char.on_data(bytes(data))

        return handler

        # ---------------------------
        # Read / Write API
        # ---------------------------

    async def read(self, char_uuid: str) -> bytes:
        return await self.client.read_gatt_char(char_uuid)

    async def write(self, char_uuid: str, data: bytes, response: bool = False):
        await self.client.write_gatt_char(char_uuid, data, response)
