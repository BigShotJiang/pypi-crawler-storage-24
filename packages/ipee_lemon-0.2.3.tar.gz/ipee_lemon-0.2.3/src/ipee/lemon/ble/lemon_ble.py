from .device import BleDevice
from .nus_service import NUSService
from .ota_service import OtaService
from .wifi_provision_service import WifiProvisioningService


class LemonBleDevice(BleDevice):
    def __init__(self, address: str):
        super().__init__(address)

        nus = NUSService(on_rx=self.on_nus_data)
        self.register_service(nus)
        ota = OtaService()
        self.register_service(ota)
        wifi = WifiProvisioningService()
        self.register_service(wifi)

    @staticmethod
    def on_nus_data(data: bytearray):
        print("NUS RX:", data.decode(errors="ignore"))

    async def start_ota(self, url: str):
        await self.write(OtaService.OTA_URL_UUID, bytes(url + "\x00", encoding="utf-8"))
