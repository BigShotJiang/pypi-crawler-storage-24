from .service import BleCharacteristic, BleService, CharMode


class OtaService(BleService):
    """The Over The Air (OTA) update service is used for setting the OTA URL and start updating

    Make sure the device is connected through Wi-Fi before starting the update.
    """

    OTA_URL_UUID = "6E400008-B5A3-F393-E0A9-E50E24DCCA9E"

    def __init__(self):
        super().__init__(
            uuid="6E400009-B5A3-F393-E0A9-E50E24DCCA9E",
            name="OTA Service",
        )

        self.add_characteristic(
            BleCharacteristic(
                uuid=self.OTA_URL_UUID,
                modes={CharMode.WRITE},
                description="Set the OTA URL and start updating",
            )
        )
