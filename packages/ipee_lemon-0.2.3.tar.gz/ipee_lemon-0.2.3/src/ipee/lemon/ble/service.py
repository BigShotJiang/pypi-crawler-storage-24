from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, Optional, Set


class CharMode(Enum):
    READ = "read"
    WRITE = "write"
    NOTIFY = "notify"
    INDICATE = "indicate"


@dataclass
class BleCharacteristic:
    uuid: str
    modes: Set[CharMode]
    description: str = ""
    on_data: Optional[Callable[[bytes], None]] = None


@dataclass
class BleService:
    uuid: str
    name: str
    characteristics: Dict[str, BleCharacteristic] = field(default_factory=dict)

    def add_characteristic(self, characteristic: BleCharacteristic):
        self.characteristics[characteristic.uuid] = characteristic
