from serial import Serial

from ipee.lemon.cli.base_service import CliBaseService


class CliOtaService(CliBaseService):
    def __init__(self):
        super().__init__("ota_start", "cli ble service")

    def start(self, serial: Serial, url: str):
        self.write(serial, url)
