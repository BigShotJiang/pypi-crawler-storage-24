from serial import Serial

from ipee.lemon.cli.base_service import CliBaseService


class CliLemonService(CliBaseService):
    def __init__(self):
        super().__init__(
            "lemon",
            "lemon cli service",
        )

    def set_settle_time(self, serial: Serial):
        self.write(serial, "set_settle_time")

    def set_frequency_duration(self, serial: Serial, duration_ms: int):
        self.write(serial, "set_frequency_duration " + str(duration_ms))
