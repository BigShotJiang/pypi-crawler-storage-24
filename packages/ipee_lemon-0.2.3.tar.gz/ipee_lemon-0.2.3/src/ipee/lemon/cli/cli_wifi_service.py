from dataclasses import dataclass

from serial import Serial

from .base_service import CliBaseService


@dataclass()
class CliWifiInfo:
    ip: str | None = None
    subnet: str | None = None
    gateway: str | None = None


class CliWifiService(CliBaseService):
    def __init__(self):
        super().__init__("wifi", "wifi-service")

    def set_ssid(self, serial: Serial, ssid: str):
        command = "set_ssid " + ssid
        self.write(serial, command)

    def get_ssid(self, serial: Serial) -> str:
        serial.flush()
        self.write(serial, "get_ssid")
        return self.read(serial).encode("utf-8")

    def set_password(self, serial: Serial, password: str):
        command = "set_password " + password
        self.write(serial, command)

    def connect(self, serial: Serial):
        self.write(serial, "connect")

    def disconnect(self, serial: Serial):
        self.write(serial, "disconnect")

    def enable(self, serial: Serial):
        self.write(serial, "enable")

    def disable(self, serial: Serial):
        self.write(serial, "disable")

    def get_connection_info(self, serial: Serial) -> CliWifiInfo:
        serial.flush()
        self.write(serial, "get_connection")
        info = CliWifiInfo()
        info.ip = str(serial.readline())
        info.subnet = str(serial.readline())
        info.gateway = str(serial.readline())
        return info
