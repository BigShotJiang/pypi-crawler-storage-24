from enum import Enum

from serial import Serial

from ipee.lemon.cli.base_service import CliBaseService


class SweepMeasurementType(Enum):
    AMPLITUDE = "AMPLITUDE"
    FREQUENCY = "FREQUENCY"


class LoggingState(Enum):
    ON = "ON"
    OFF = "OFF"


class CliSweepService(CliBaseService):
    def __init__(self):
        super().__init__(
            "sweep",
            "sweep service",
        )

    def start_voltage(self, serial: Serial, voltage_uv: int):
        command = "set_start_voltage_uv " + str(voltage_uv)
        self.write(serial, command)

    def end_voltage(self, serial: Serial, voltage_uv: int):
        command = "set_end_voltage_uv " + str(voltage_uv)
        self.write(serial, command)

    def set_step_size(self, serial: Serial, step_size: int):
        command = "set_step_uv " + str(step_size)
        self.write(serial, command)

    def set_step_duration(self, serial: Serial, step_duration_us: int):
        command = "set_step_duration_us " + str(step_duration_us)
        self.write(serial, command)

    def set_measurement_type(self, serial: Serial, measurement_type: SweepMeasurementType):
        command = "set_measurement_type " + str(measurement_type)
        self.write(serial, command)

    def start(self, serial: Serial):
        self.write(serial, "start")

    def stop(self, serial: Serial):
        self.write(serial, "stop")

    def set_logging(self, serial: Serial, state: LoggingState):
        command = "set_logging " + str(state)
        self.write(serial, command)
