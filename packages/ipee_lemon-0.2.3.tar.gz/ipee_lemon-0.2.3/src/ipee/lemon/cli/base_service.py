from serial import Serial


class CliBaseService:
    def __init__(self, tag: str, service_name: str):
        self.tag = tag
        self.service_name = service_name

    def write(self, serial: Serial, command: str):
        serial.write((self.tag + " " + command + "\n").encode())

    @staticmethod
    def read(serial: Serial):
        return serial.readline()
