from serial import Serial

from .base_service import CliBaseService


class CliBleService(CliBaseService):
    def __init__(self):
        super().__init__("ble", "ble service")

    def enable(self, serial: Serial):
        self.write(serial, "enable")

    def disable(self, serial: Serial):
        self.write(serial, "disable")

    def send(self, serial: Serial, data: str):
        command = "send " + data
        self.write(serial, command)
