"""List elements"""

import argparse
import os
import sys
import time

from rich import box
from rich.console import Console
from rich.markdown import Markdown
from rich.prompt import Prompt
from rich.table import Table

from pyegeria import (
    EgeriaTech,
    print_basic_exception,
    PyegeriaException,
    settings, load_app_config, pretty_print_config,
    config_logging,
    save_mermaid_html,
)

app_config = settings.Environment
config_path = os.path.join(app_config.pyegeria_config_directory, app_config.pyegeria_config_file)

EGERIA_USER = os.environ.get("EGERIA_USER", "erinoverview")
EGERIA_USER_PASSWORD = os.environ.get("EGERIA_USER_PASSWORD", "secret")
EGERIA_MERMAID_FOLDER = os.path.join(app_config.pyegeria_root, app_config.egeria_mermaid_folder)
conf = load_app_config(config_path)
# print(f"Loading config from {config_path} and mermaid folder is {EGERIA_MERMAID_FOLDER}")
console = Console(width=app_config.console_width)
config_logging()


def find_elements_by_prop_value_x(
    om_type: str,
    property_value: str,
    property_names: [str],
    server: str,
    url: str,
    username: str,
    password: str,
    jupyter: bool = app_config.egeria_jupyter,
    width: int = app_config.console_width,
):
    c_client = EgeriaTech(server, url, user_id=username, user_pwd=password)
    token = c_client.create_egeria_bearer_token()

    om_typedef = c_client.get_typedef_by_name(om_type)
    if type(om_typedef) is str:
        print(
            f"The type name '{om_type}' is not known to the Egeria platform at {url} - {server}"
        )
        sys.exit(1)
    elements = c_client.find_elements_by_property_value(
        property_value, property_names, om_type
    )

    def generate_table() -> Table:
        """Make a new table."""
        table = Table(
            caption=f"Metadata Elements for: {url} - {server} @ {time.asctime()}",
            style="bold bright_white on black",
            row_styles=["bold bright_white on black"],
            header_style="white on dark_blue",
            title_style="bold bright_white on black",
            caption_style="white on black",
            show_lines=True,
            box=box.ROUNDED,
            title=f"Find Elements for Open Metadata Type: {om_type}, property value: {property_value}, "
            f"properties: {property_names} - Extended",
            expand=True,
            width=width,
        )

        table.add_column("Qualified Name")
        table.add_column("Type")
        table.add_column("Created")
        table.add_column("Home Store")
        table.add_column("GUID", width=38, no_wrap=True)
        table.add_column("Properties")
        table.add_column("Feedback", min_width=30)
        table.add_column("Public Comments")

        if type(elements) is list:
            for element in elements:
                header = element["elementHeader"]
                el_q_name = element["properties"].get("qualifiedName", "---")
                el_type = header["type"]["typeName"]
                el_home = header["origin"]["homeMetadataCollectionName"]
                el_create_time = header["versions"]["createTime"][:-18]
                el_guid = header["guid"]

                el_props_md = ""
                for prop in element["properties"].keys():
                    el_props_md += f"* **{prop}**: {element['properties'][prop]}\n"

                el_props_out = Markdown(el_props_md)

                tags = c_client.get_attached_tags(el_guid)
                tags_md = "Tags:\n"
                if type(tags) is list:
                    for tag in tags:
                        tags_md += (
                            f"* tag: {tag.get('name','')}\n"
                            f"\t description: {tag.get('description','---')}\n"
                            f"\t assigned by: {tag.get('user','---')}\n"
                        )

                else:
                    tags_md = ""

                likes = c_client.get_attached_likes(el_guid)
                likes_md = "Likes:\b"
                if type(likes) is list:
                    for like in likes:
                        likes_md += (
                            f"* tag: {like['name']}\n"
                            f"* description: {like['description']}\n"
                            f"* assigned by: {like['user']}\n"
                            f"\n"
                        )

                else:
                    likes_md = ""

                if len(tags_md) > 0 and len(likes_md) > 0:
                    feedback_out = f"{tags_md}\n --- \n{likes_md}"
                else:
                    feedback_out = ""

                comments_out = " "

                table.add_row(
                    el_q_name,
                    el_type,
                    el_create_time,
                    el_home,
                    el_guid,
                    el_props_out,
                    feedback_out,
                    comments_out,
                )

            return table
        else:
            print("No instances found")
            sys.exit(1)

    try:
        console = Console(width=width, force_terminal=not jupyter)

        with console.pager(styles=True):
            console.print(generate_table())

    except (
        PyegeriaException,
    ) as e:
        print_basic_exception(e)
        print("\n\nPerhaps the type name isn't known")
    finally:
        c_client.close_session()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", help="Name of the server to display status for")
    parser.add_argument("--url", help="URL Platform to connect to")
    parser.add_argument("--userid", help="User Id")
    parser.add_argument("--password", help="Password")

    args = parser.parse_args()

    server = args.server if args.server is not None else app_config.egeria_view_server
    url = args.url if args.url is not None else app_config.egeria_platform_url
    userid = args.userid if args.userid is not None else EGERIA_USER
    password = args.password if args.password is not None else EGERIA_USER_PASSWORD

    try:
        om_type = Prompt.ask(
            "Enter the Open Metadata Type to find elements of", default="Referenceable"
        )
        property_value = Prompt.ask("Enter the property value to search for")
        property_names = Prompt.ask(
            "Enter a comma seperated list of properties to search"
        )
        find_elements_by_prop_value_x(om_type, property_value, [property_names], server, url, userid, password)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
