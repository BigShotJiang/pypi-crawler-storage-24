"""macOS accessibility. ax provides the main API."""

from . import ax

__all__ = ["ax"]
