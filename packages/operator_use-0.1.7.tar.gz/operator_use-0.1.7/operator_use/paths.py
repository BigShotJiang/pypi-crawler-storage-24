from pathlib import Path
from platformdirs import user_data_path

APP_NAME = "operator-use"
_LEGACY_DIR = Path.home() / ".operator_use"


def get_userdata_dir() -> Path:
    """Return the user data directory for Operator.

    Prefers the platformdirs path (AppData/Local/operator-use on Windows).
    Falls back to ~/.operator_use if it exists and has a config there.
    """
    primary = user_data_path(APP_NAME)
    if not (primary / "config.json").exists() and (_LEGACY_DIR / "config.json").exists():
        return _LEGACY_DIR
    return primary
