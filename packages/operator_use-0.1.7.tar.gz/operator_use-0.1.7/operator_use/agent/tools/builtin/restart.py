﻿"""Restart tool: signals the agent process to perform a clean restart."""

from operator_use.tools import Tool, ToolResult
from pydantic import BaseModel, Field
from pathlib import Path
from typing import Optional
import asyncio
import logging
import json
import sys
import os

logger = logging.getLogger(__name__)

RESTART_FILE = Path.cwd() / ".operator_use" / "restart.json"


async def _trigger_restart():
    # Small delay so the ToolResult can be returned and the response sent first
    await asyncio.sleep(5)
    os.execv(sys.executable, [sys.executable] + sys.argv)


class Restart(BaseModel):
    continue_with: Optional[str] = Field(
        default=None,
        description=(
            "REQUIRED when restart is an intermediate step and there is more work to do after. "
            "Describe exactly what to continue after restart — e.g. "
            "'Test the new tool I just added and report results to the user'. "
            "Without this, the task cannot resume after restart. "
            "Omit only when the restart itself is the final action the user requested."
        ),
    )


@Tool(
    name="restart",
    description=(
        "Restart the agent process to reload updated source code or config. "
        "Use after editing your own codebase files (e.g. adding a tool, changing a provider, updating config). "
        "The restart happens ~5 seconds after this tool returns, giving time for the response to be sent first. "
        "Only call this when a code or config change actually requires a reload.\n\n"
        "IMPORTANT — `continue_with` field:\n"
        "- If restart is an INTERMEDIATE step (more work to do after): you MUST set `continue_with` "
        "with a full description of what to do next. The process memory is wiped on restart — without "
        "this the task cannot continue.\n"
        "- If restart is the FINAL action the user requested: omit `continue_with`.\n\n"
        "Example: editing a tool then testing it → "
        "restart(continue_with='Run a test of the new scraper tool and report results to the user')"
    ),
    model=Restart,
)
async def restart(continue_with: Optional[str] = None, **kwargs) -> ToolResult:
    """Schedule an agent restart, optionally saving a continuation task."""

    if continue_with:
        channel = kwargs.get("_channel")
        chat_id = kwargs.get("_chat_id")
        restart_data = {
            "task": continue_with,
            "channel": channel,
            "chat_id": chat_id,
        }
        RESTART_FILE.parent.mkdir(parents=True, exist_ok=True)
        RESTART_FILE.write_text(json.dumps(restart_data), encoding="utf-8")
        print(f"[restart] Saved continuation → {RESTART_FILE} (channel={channel} chat_id={chat_id})", flush=True)

    asyncio.ensure_future(_trigger_restart())

    msg = "Reboot initiated."
    if continue_with:
        msg += f" Will continue after restart: {continue_with[:100]}"
    return ToolResult.success_result(msg, metadata={"stop_loop": True})
