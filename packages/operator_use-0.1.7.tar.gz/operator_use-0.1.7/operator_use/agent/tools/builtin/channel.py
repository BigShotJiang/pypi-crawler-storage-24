"""Channel management tools — list, enable, disable, status."""

from pydantic import BaseModel, Field
from operator_use.tools.service import Tool, ToolResult


class ListChannels(BaseModel):
    pass


class ChannelName(BaseModel):
    name: str = Field(..., description="Channel name, e.g. 'slack', 'telegram', 'discord'.")


@Tool(name="list_channels", description="List all registered channels and their status (running or stopped).", model=ListChannels)
async def list_channels(**kwargs) -> ToolResult:
    gateway = kwargs.get("_gateway")
    if not gateway:
        return ToolResult.error_result("Gateway not available.")

    channels = gateway.list_channels()
    if not channels:
        return ToolResult.success_result("No channels registered.")

    lines = []
    for ch in channels:
        status = "running" if ch.running else "stopped"
        lines.append(f"- {ch.name}: {status}")

    return ToolResult.success_result("\n".join(lines))


@Tool(name="channel_status", description="Check the status of a specific channel.", model=ChannelName)
async def channel_status(name: str, **kwargs) -> ToolResult:
    gateway = kwargs.get("_gateway")
    if not gateway:
        return ToolResult.error_result("Gateway not available.")

    channel = gateway.get_channel(name)
    if not channel:
        return ToolResult.error_result(f"Channel '{name}' not found.")

    status = "running" if channel.running else "stopped"
    return ToolResult.success_result(f"Channel '{name}' is {status}.")


@Tool(name="enable_channel", description="Start a stopped channel.", model=ChannelName)
async def enable_channel(name: str, **kwargs) -> ToolResult:
    gateway = kwargs.get("_gateway")
    if not gateway:
        return ToolResult.error_result("Gateway not available.")

    channel = gateway.get_channel(name)
    if not channel:
        return ToolResult.error_result(f"Channel '{name}' not found.")
    if channel.running:
        return ToolResult.success_result(f"Channel '{name}' is already running.")

    started = await gateway.enable_channel(name)
    if started:
        return ToolResult.success_result(f"Channel '{name}' started.")
    return ToolResult.error_result(f"Failed to start channel '{name}'.")


@Tool(name="disable_channel", description="Stop a running channel.", model=ChannelName)
async def disable_channel(name: str, **kwargs) -> ToolResult:
    gateway = kwargs.get("_gateway")
    if not gateway:
        return ToolResult.error_result("Gateway not available.")

    channel = gateway.get_channel(name)
    if not channel:
        return ToolResult.error_result(f"Channel '{name}' not found.")
    if not channel.running:
        return ToolResult.success_result(f"Channel '{name}' is already stopped.")

    stopped = await gateway.disable_channel(name)
    if stopped:
        return ToolResult.success_result(f"Channel '{name}' stopped.")
    return ToolResult.error_result(f"Failed to stop channel '{name}'.")
