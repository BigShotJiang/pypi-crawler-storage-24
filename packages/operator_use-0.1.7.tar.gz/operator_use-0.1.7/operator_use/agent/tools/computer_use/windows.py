﻿"""Windows computer-use tools adapted from Windows-Use. Uses UIA for click, type, scroll, move."""

import asyncio
from typing import Literal, Optional
from pydantic import BaseModel, Field
from operator_use.tools import Tool, ToolResult
from operator_use.accessibility.windows import uia,vdm


# Key aliases for shortcut_tool (from Windows-Use)
KEY_ALIASES = {
    "backspace": "Back",
    "capslock": "Capital",
    "scrolllock": "Scroll",
    "windows": "Win",
    "win": "Win",
    "command": "Win",
    "option": "Alt",
}


class Wait(BaseModel):
    duration: int = Field(
        ...,
        description="Number of seconds to pause. Use to wait for applications to launch, pages to load, or animations to finish before the next action.",
        examples=[2, 5, 10],
    )


@Tool(
    name="wait",
    description="Pauses for the specified number of seconds before the next action. Use to wait for applications to launch, pages to load, dialogs to appear, or animations to finish. Typical waits: 2-3s for UI transitions, 5s for app launches, 10s+ for installations or downloads.",
    model=Wait,
)
async def wait(duration: int, **kwargs) -> ToolResult:
    await asyncio.sleep(duration)
    return ToolResult.success_result(f"Waited for {duration} seconds.")

class Desktop(BaseModel):
    action: Literal["create", "remove", "rename", "switch"] = Field(
        ...,
        description="Virtual desktop action: 'create' adds a new desktop, 'remove' deletes a desktop by name, 'rename' changes a desktop's name, 'switch' activates a desktop by name",
        examples=["create", "switch", "rename", "remove"],
    )
    desktop_name: Optional[str] = Field(
        default=None,
        description="Name of the target desktop. Required for remove, rename, and switch. Optional for create (auto-named if omitted).",
        examples=["Desktop 1", "Work", "Research"],
    )
    new_name: Optional[str] = Field(
        default=None,
        description="New name for rename only.",
        examples=["My Workspace", "Project Alpha"],
    )


@Tool(
    name="desktop",
    description="Manages Windows virtual desktops for workspace organization. create: Creates a new virtual desktop. Optionally provide a name via desktop_name. remove: Deletes the desktop specified by desktop_name. Ensure no needed windows remain on it. rename: Renames desktop_name to new_name. switch: Activates the desktop specified by desktop_name. Verify success in the next Desktop State.",
    model=Desktop,
)
async def desktop(
    action: Literal["create", "remove", "rename", "switch"],
    desktop_name: Optional[str] = None,
    new_name: Optional[str] = None,
    **kwargs,
) -> ToolResult:
    try:
        match action:
            case "create":
                created_name = vdm.create_desktop(desktop_name)
                return ToolResult.success_result(f"Created desktop: '{created_name}'")
            case "remove":
                if not desktop_name:
                    return ToolResult.error_result("desktop_name is required for remove.")
                vdm.remove_desktop(desktop_name)
                return ToolResult.success_result(f"Removed desktop '{desktop_name}'")
            case "rename":
                if not desktop_name or not new_name:
                    return ToolResult.error_result("desktop_name and new_name required for rename.")
                vdm.rename_desktop(desktop_name, new_name)
                return ToolResult.success_result(f"Renamed '{desktop_name}' to '{new_name}'")
            case "switch":
                if not desktop_name:
                    return ToolResult.error_result("desktop_name is required for switch.")
                vdm.switch_desktop(desktop_name)
                return ToolResult.success_result(f"Switched to desktop '{desktop_name}'")
            case _:
                return ToolResult.error_result(f"Unknown action: {action}")
    except Exception as e:
        return ToolResult.error_result(str(e))

class Click(BaseModel):
    loc: list[int] = Field(
        ...,
        description="[x, y] pixel coordinates of the target element to click. Use coordinates from the Interactive Elements list.",
        examples=[[640, 360], [100, 200]],
    )
    button: Literal["left", "right", "middle"] = Field(
        default="left",
        description="Mouse button: 'left' for standard clicks and selection, 'right' for context menus, 'middle' for middle-click actions",
        examples=["left", "right"],
    )
    clicks: int = Field(
        default=1,
        description="Number of clicks: 1 for single click (select, focus, press buttons), 2 for double click (open files, folders, apps), 0 for hover only (no click performed)",
        examples=[1, 2],
    )


@Tool(
    name="click",
    description="Clicks at the specified pixel coordinates on screen. Single left click (clicks=1): Select elements, press buttons, focus fields, follow links. Double left click (clicks=2): Open files, folders, and desktop icons. Right click (button='right'): Open context menus. Hover only (clicks=0): Move cursor to location without clicking. Use coordinates from the Interactive Elements list in the Desktop State.",
    model=Click,
)
async def click(loc: list[int], button: Literal["left", "right", "middle"] = "left", clicks: int = 1, **kwargs) -> ToolResult:
    x, y = loc[0], loc[1]
    if clicks == 0:
        uia.SetCursorPos(x, y)
        return ToolResult.success_result(f"Moved cursor to ({x},{y}).")
    match button:
        case "left":
            if clicks >= 2:
                uia.DoubleClick(x, y)
            else:
                uia.Click(x, y)
        case "right":
            uia.RightClick(x, y)
        case "middle":
            uia.MiddleClick(x, y)
    num = {1: "Single", 2: "Double", 3: "Triple"}
    return ToolResult.success_result(f"{num.get(clicks, str(clicks))} {button} clicked at ({x},{y}).")


class Type(BaseModel):
    loc: list[int] = Field(
        ...,
        description="[x, y] pixel coordinates of the input field to type into. The tool clicks this location automatically before typing — do not pre-click.",
        examples=[[640, 360], [200, 150]],
    )
    text: str = Field(
        ...,
        description="The text string to type into the element",
        examples=["hello world", "user@example.com", "search query"],
    )
    clear: bool = Field(
        default=False,
        description="If true, selects all existing text and replaces it. If false, appends to whatever is already in the field.",
        examples=[True, False],
    )
    caret_position: Literal["start", "idle", "end"] = Field(
        default="idle",
        description="Where to position the text cursor before typing: 'start' moves to the beginning of the field, 'end' moves to the end, 'idle' leaves it where it is",
        examples=["start", "end", "idle"],
    )
    press_enter: bool = Field(
        default=False,
        description="If true, presses Enter after typing to submit the input (search, form, dialog). If false, leaves the cursor in the field.",
        examples=[True, False],
    )


@Tool(
    name="type",
    description="Clicks an input field and types text into it. Do NOT pre-click with click_tool — this tool handles focusing automatically. Set clear=true to replace existing text, or clear=false to append. Set press_enter=true to submit after typing (search bars, forms, dialogs). Set caret_position to control where typing begins relative to existing text. Use for search queries, form fields, text editors, address bars, and any text input.",
    model=Type,
)
async def type(
    loc: list[int],
    text: str,
    clear: bool = False,
    caret_position: str = "idle",
    press_enter: bool = False,
    **kwargs,
) -> ToolResult:
    x, y = loc[0], loc[1]
    uia.Click(x, y)
    if caret_position == "start":
        uia.SendKeys("{Home}", waitTime=0.05)
    elif caret_position == "end":
        uia.SendKeys("{End}", waitTime=0.05)
    if clear:
        await asyncio.sleep(0.5)
        uia.SendKeys("{Ctrl}a", waitTime=0.05)
        uia.SendKeys("{Back}", waitTime=0.05)
    escaped = uia._escape_text_for_sendkeys(text)
    uia.SendKeys(escaped, interval=0.01, waitTime=0.05)
    if press_enter:
        uia.SendKeys("{Enter}", waitTime=0.05)
    return ToolResult.success_result(f"Typed at ({x},{y}).")


class Scroll(BaseModel):
    loc: Optional[list[int]] = Field(
        default=None,
        description="[x, y] pixel coordinates where scrolling occurs. If omitted, scrolls at the current cursor position.",
        examples=[[640, 360], [800, 400]],
    )
    type: Literal["horizontal", "vertical"] = Field(
        default="vertical",
        description="Scroll axis: 'vertical' for up/down scrolling, 'horizontal' for left/right scrolling",
        examples=["vertical", "horizontal"],
    )
    direction: Literal["up", "down", "left", "right"] = Field(
        default="down",
        description="Scroll direction: 'up' or 'down' for vertical, 'left' or 'right' for horizontal",
        examples=["down", "up", "right"],
    )
    wheel_times: int = Field(
        default=1,
        description="Number of scroll increments. Each increment scrolls roughly 3-5 lines of text. Use 3-5 for moderate scrolling, 10+ for large jumps.",
        examples=[1, 3, 5, 10],
    )


@Tool(
    name="scroll",
    description="Scrolls content at the specified location or at the current cursor position. Each wheel increment scrolls roughly 3-5 lines of text. Use wheel_times=3-5 for moderate scrolling, 10+ for large jumps. Check scroll percentages in the Scrollable Elements list to gauge position before scrolling. If loc is omitted, scrolling occurs at the current cursor location.",
    model=Scroll,
)
async def scroll(
    loc: Optional[list[int]] = None,
    type: str = "vertical",
    direction: str = "down",
    wheel_times: int = 1,
    **kwargs,
) -> ToolResult:
    if loc:
        uia.MoveTo(loc[0], loc[1])
    match type:
        case "vertical":
            if direction == "up":
                uia.WheelUp(wheel_times)
            elif direction == "down":
                uia.WheelDown(wheel_times)
            else:
                return ToolResult.error_result('Invalid direction. Use "up" or "down".')
        case "horizontal":
            if direction == "left":
                uia.WheelLeft(wheel_times)
            elif direction == "right":
                uia.WheelRight(wheel_times)
            else:
                return ToolResult.error_result('Invalid direction. Use "left" or "right".')
        case _:
            return ToolResult.error_result('Invalid type. Use "horizontal" or "vertical".')
    return ToolResult.success_result(f"Scrolled {type} {direction} by {wheel_times}.")


class Move(BaseModel):
    loc: list[int] = Field(
        ...,
        description="[x, y] pixel coordinates to move the mouse cursor to",
        examples=[[640, 360], [100, 100]],
    )
    drag: bool = Field(
        default=False,
        description="If true, holds the left mouse button and drags from the current position to the target (drag-and-drop). If false, moves the cursor without clicking (hover).",
        examples=[True, False],
    )


@Tool(
    name="move",
    description="Moves the mouse cursor to a target location, or drags from the current position to the target. drag=false: Hover over elements to reveal tooltips, dropdown menus, or reposition the cursor. drag=true: Hold left mouse button from the current cursor position and drag to the target coordinates. Use for drag-and-drop of files, window resizing, slider adjustment, or reordering items.",
    model=Move,
)
async def move(loc: list[int], drag: bool = False, **kwargs) -> ToolResult:
    x, y = loc[0], loc[1]
    if drag:
        cx, cy = uia.GetCursorPos()
        uia.DragTo(cx, cy, x, y)
        return ToolResult.success_result(f"Dragged to ({x},{y}).")
    uia.MoveTo(x, y, moveSpeed=10)
    return ToolResult.success_result(f"Moved to ({x},{y}).")


class Shortcut(BaseModel):
    shortcut: str = Field(
        ...,
        description="Keyboard shortcut to press. Use '+' to combine keys for simultaneous press. Examples: 'ctrl+c' for copy, 'alt+tab' for window switch, 'enter' for confirm, 'escape' for cancel.",
        examples=["enter", "escape", "ctrl+c", "ctrl+v", "alt+tab", "ctrl+shift+n", "win"],
    )


@Tool(
    name="shortcut",
    description="Presses a keyboard shortcut. Use '+' to combine keys (e.g., 'ctrl+c'). Common shortcuts: ctrl+c (copy), ctrl+v (paste), ctrl+z (undo), ctrl+s (save), ctrl+a (select all), ctrl+f (find), ctrl+w (close tab), ctrl+t (new tab), alt+tab (switch window), alt+f4 (close app), enter (confirm), escape (cancel), win (start menu). Prefer shortcuts over mouse interactions when the operation is unambiguous.",
    model=Shortcut,
)
async def shortcut(shortcut: str, **kwargs) -> ToolResult:
    keys = shortcut.split("+")
    sendkeys_str = ""
    for key in keys:
        key = key.strip()
        if len(key) == 1:
            sendkeys_str += key
        else:
            name = KEY_ALIASES.get(key.lower(), key)
            sendkeys_str += "{" + name + "}"
    uia.SendKeys(sendkeys_str, interval=0.01)
    return ToolResult.success_result(f"Pressed {shortcut}.")
