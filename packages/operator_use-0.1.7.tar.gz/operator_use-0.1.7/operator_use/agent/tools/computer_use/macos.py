﻿"""macOS computer-use tools. Uses ax module for click, type, scroll, move."""

import asyncio
from typing import Literal, Optional
from pydantic import BaseModel, Field
from operator_use.tools import Tool, ToolResult
from operator_use.accessibility.macos import ax

# Key mapping: Windows/alias -> macOS (for shortcut_tool)
KEY_ALIASES = {
    "ctrl": "command",
    "cmd": "command",
    "command": "command",
    "win": "command",
    "alt": "option",
    "opt": "option",
}


class Wait(BaseModel):
    duration: int = Field(
        ...,
        description="Number of seconds to pause. Use to wait for applications to launch, pages to load, or animations to finish before the next action.",
        examples=[2, 5, 10],
    )


@Tool(
    name="wait",
    description="Pauses for the specified number of seconds before the next action. Use to wait for applications to launch, pages to load, dialogs to appear, or animations to finish. Typical waits: 2-3s for UI transitions, 5s for app launches, 10s+ for installations or downloads.",
    model=Wait,
)
async def wait(duration: int, **kwargs) -> ToolResult:
    await asyncio.sleep(duration)
    return ToolResult.success_result(f"Waited for {duration} seconds.")


class Desktop(BaseModel):
    action: Literal["create", "remove", "rename", "switch"] = Field(
        ...,
        description="Virtual desktop (Space) action: 'create' adds a new Space, 'remove' deletes current Space, 'switch' activates a Space by number or direction. 'rename' not supported on macOS.",
        examples=["create", "switch", "remove"],
    )
    desktop_name: Optional[str] = Field(
        default=None,
        description="For switch: Space number (1-9) or direction ('left'/'right'/'next'/'previous'). Required for switch. For remove: switch to target Space first, then remove.",
        examples=["1", "2", "left", "right", "next"],
    )
    new_name: Optional[str] = Field(
        default=None,
        description="Not used on macOS. Spaces are identified by number.",
    )


@Tool(
    name="desktop",
    description="Manages macOS virtual desktops (Spaces) for workspace organization via Mission Control. create: Creates a new Space by opening Mission Control and adding a desktop. remove: Removes the current Space. Switch to the target Space first using switch, then remove. switch: Switches to a Space by number (e.g., desktop_name='2') or direction (desktop_name='left'/'right'/'next'/'previous'). Switching by number requires the shortcut to be enabled in System Settings > Keyboard > Shortcuts > Mission Control. rename: Not supported on macOS. Spaces are identified by number, not name.",
    model=Desktop,
)
async def desktop(
    action: Literal["create", "remove", "rename", "switch"],
    desktop_name: Optional[str] = None,
    new_name: Optional[str] = None,
    **kwargs,
) -> ToolResult:
    try:
        match action:
            case "create":
                script = "\n".join([
                    'tell application "System Events"',
                    "    key code 126 using {control down}",
                    "    delay 1.0",
                    "end tell",
                    "",
                    'tell application "System Events" to tell process "Dock"',
                    "    click button 1 of group 2 of group 1 of group 1",
                    "end tell",
                    "",
                    "delay 0.5",
                    "",
                    'tell application "System Events"',
                    "    key code 53",
                    "end tell",
                ])
                response, status = ax.ExecuteCommand(script, mode="osascript", timeout=15)
                if status == 0:
                    return ToolResult.success_result("Created a new Space via Mission Control.")
                return ToolResult.error_result(f"Error creating Space: {response}")

            case "remove":
                if desktop_name:
                    return ToolResult.error_result(
                        "To remove a specific Space, first switch to it using the 'switch' action, "
                        "then call remove without desktop_name."
                    )
                script = "\n".join([
                    'tell application "System Events"',
                    "    key code 126 using {control down}",
                    "    delay 1.0",
                    "end tell",
                    "",
                    'tell application "System Events" to tell process "Dock"',
                    "    set mcGroup to group 1 of group 1",
                    "    set spacesBar to list 1 of group 2 of mcGroup",
                    "    set allSpaces to buttons of spacesBar",
                    "    if (count of allSpaces) is less than or equal to 1 then",
                    '        error "Cannot remove the last remaining Space."',
                    "    end if",
                    "    repeat with sp in allSpaces",
                    '        if value of attribute "AXIsSelected" of sp is true then',
                    '            perform action "AXRemoveDesktop" of sp',
                    "            exit repeat",
                    "        end if",
                    "    end repeat",
                    "end tell",
                    "",
                    "delay 0.5",
                    "",
                    'tell application "System Events"',
                    "    key code 53",
                    "end tell",
                ])
                response, status = ax.ExecuteCommand(script, mode="osascript", timeout=15)
                if status == 0:
                    return ToolResult.success_result("Removed the current Space.")
                return ToolResult.error_result(f"Error removing Space: {response}")

            case "rename":
                return ToolResult.error_result(
                    "Renaming Spaces is not supported on macOS. Spaces are identified by their number."
                )

            case "switch":
                if not desktop_name:
                    return ToolResult.error_result(
                        "desktop_name is required for switching. "
                        "Use a number (e.g., '1', '2') or direction ('left', 'right', 'next', 'previous')."
                    )
                name = desktop_name.strip().lower()
                if name in ("left", "previous"):
                    script = 'tell application "System Events" to key code 123 using {control down}'
                elif name in ("right", "next"):
                    script = 'tell application "System Events" to key code 124 using {control down}'
                elif name.isdigit():
                    space_num = int(name)
                    if space_num < 1 or space_num > 9:
                        return ToolResult.error_result(f"Space number must be between 1 and 9. Got: {space_num}")
                    key_codes = {1: 18, 2: 19, 3: 20, 4: 21, 5: 23, 6: 22, 7: 26, 8: 28, 9: 25}
                    key_code = key_codes[space_num]
                    script = f'tell application "System Events" to key code {key_code} using {{control down}}'
                else:
                    return ToolResult.error_result(
                        f"Invalid desktop_name '{desktop_name}'. "
                        "Use a number (1-9) or direction ('left', 'right', 'next', 'previous')."
                    )
                response, status = ax.ExecuteCommand(script, mode="osascript")
                if status == 0:
                    return ToolResult.success_result(f"Switched to Space ({desktop_name}).")
                return ToolResult.error_result(
                    f"Error switching Space: {response}. "
                    "Ensure shortcuts are enabled in System Settings > Keyboard > Shortcuts > Mission Control."
                )
            case _:
                return ToolResult.error_result(f"Unknown action: {action}")
    except Exception as e:
        return ToolResult.error_result(str(e))


class Click(BaseModel):
    loc: list[int] = Field(
        ...,
        description="[x, y] pixel coordinates of the target element to click. Use coordinates from the Interactive Elements list.",
        examples=[[640, 360], [100, 200]],
    )
    button: Literal["left", "right", "middle"] = Field(
        default="left",
        description="Mouse button: 'left' for standard clicks and selection, 'right' for context menus, 'middle' for middle-click actions",
        examples=["left", "right"],
    )
    clicks: int = Field(
        default=1,
        description="Number of clicks: 1 for single click (select, focus, press buttons), 2 for double click (open files, folders, apps), 0 for hover only (no click performed)",
        examples=[1, 2],
    )


@Tool(
    name="click",
    description="Clicks at the specified pixel coordinates on screen. Single left click (clicks=1): Select elements, press buttons, focus fields, follow links. Double left click (clicks=2): Open files, folders, and desktop icons. Right click (button='right'): Open context menus. Hover only (clicks=0): Move cursor to location without clicking. Use coordinates from the Interactive Elements list in the Desktop State.",
    model=Click,
)
async def click(loc: list[int], button: str = "left", clicks: int = 1, **kwargs) -> ToolResult:
    x, y = loc[0], loc[1]
    if clicks == 0:
        ax.SetCursorPos(x, y)
        return ToolResult.success_result(f"Moved cursor to ({x},{y}).")
    ax.MoveTo(x, y)
    if clicks > 0:
        await asyncio.sleep(0.05)
        match button:
            case "right":
                ax.RightClick(x, y)
            case "middle":
                ax.MiddleClick(x, y)
            case "left":
                if clicks >= 2:
                    ax.DoubleClick(x, y)
                else:
                    ax.Click(x, y)
    num = {1: "Single", 2: "Double", 3: "Triple"}
    return ToolResult.success_result(f"{num.get(clicks, str(clicks))} {button} clicked at ({x},{y}).")


class Type(BaseModel):
    loc: list[int] = Field(
        ...,
        description="[x, y] pixel coordinates of the input field to type into. The tool clicks this location automatically before typing — do not pre-click.",
        examples=[[640, 360], [200, 150]],
    )
    text: str = Field(
        ...,
        description="The text string to type into the element",
        examples=["hello world", "user@example.com", "search query"],
    )
    clear: bool = Field(
        default=False,
        description="If true, selects all existing text and replaces it. If false, appends to whatever is already in the field.",
        examples=[True, False],
    )
    caret_position: Literal["start", "idle", "end"] = Field(
        default="idle",
        description="Where to position the text cursor before typing: 'start' moves to the beginning of the field, 'end' moves to the end, 'idle' leaves it where it is",
        examples=["start", "end", "idle"],
    )
    press_enter: bool = Field(
        default=False,
        description="If true, presses Enter after typing to submit the input (search, form, dialog). If false, leaves the cursor in the field.",
        examples=[True, False],
    )


@Tool(
    name="type",
    description="Clicks an input field and types text into it. Do NOT pre-click with click_tool — this tool handles focusing automatically. Set clear=true to replace existing text, or clear=false to append. Set press_enter=true to submit after typing (search bars, forms, dialogs). Set caret_position to control where typing begins relative to existing text. Use for search queries, form fields, text editors, address bars, and any text input.",
    model=Type,
)
async def type(
    loc: list[int],
    text: str,
    clear: bool = False,
    caret_position: str = "idle",
    press_enter: bool = False,
    **kwargs,
) -> ToolResult:
    x, y = loc[0], loc[1]
    ax.Click(x, y)
    await asyncio.sleep(0.05)
    if clear:
        ax.HotKey("command", "a")
        await asyncio.sleep(0.05)
        ax.KeyPress(ax.KeyCode.Delete)
    if caret_position == "start":
        ax.HotKey("command", "left")
        await asyncio.sleep(0.05)
    elif caret_position == "end":
        ax.HotKey("command", "right")
        await asyncio.sleep(0.05)
    ax.TypeText(text)
    if press_enter:
        await asyncio.sleep(0.05)
        ax.KeyPress(ax.KeyCode.Return)
    return ToolResult.success_result(f"Typed at ({x},{y}).")


class Scroll(BaseModel):
    loc: Optional[list[int]] = Field(
        default=None,
        description="[x, y] pixel coordinates where scrolling occurs. If omitted, scrolls at the current cursor position.",
        examples=[[640, 360], [800, 400]],
    )
    type: Literal["horizontal", "vertical"] = Field(
        default="vertical",
        description="Scroll axis: 'vertical' for up/down scrolling, 'horizontal' for left/right scrolling",
        examples=["vertical", "horizontal"],
    )
    direction: Literal["up", "down", "left", "right"] = Field(
        default="down",
        description="Scroll direction: 'up' or 'down' for vertical, 'left' or 'right' for horizontal",
        examples=["down", "up", "right"],
    )
    wheel_times: int = Field(
        default=1,
        description="Number of scroll increments. Each increment scrolls roughly 3-5 lines of text. Use 3-5 for moderate scrolling, 10+ for large jumps.",
        examples=[1, 3, 5, 10],
    )


@Tool(
    name="scroll",
    description="Scrolls content at the specified location or at the current cursor position. Each wheel increment scrolls roughly 3-5 lines of text. Use wheel_times=3-5 for moderate scrolling, 10+ for large jumps. Check scroll percentages in the Scrollable Elements list to gauge position before scrolling. If loc is omitted, scrolling occurs at the current cursor location.",
    model=Scroll,
)
async def scroll(
    loc: Optional[list[int]] = None,
    type: str = "vertical",
    direction: str = "down",
    wheel_times: int = 1,
    **kwargs,
) -> ToolResult:
    if loc:
        ax.MoveTo(loc[0], loc[1])
    if type == "vertical":
        if direction == "up":
            ax.WheelUp(clicks=wheel_times)
        elif direction == "down":
            ax.WheelDown(clicks=wheel_times)
        else:
            return ToolResult.error_result('Invalid direction. Use "up" or "down".')
    elif type == "horizontal":
        if direction == "left":
            ax.WheelLeft(clicks=wheel_times)
        elif direction == "right":
            ax.WheelRight(clicks=wheel_times)
        else:
            return ToolResult.error_result('Invalid direction. Use "left" or "right".')
    else:
        return ToolResult.error_result('Invalid type. Use "horizontal" or "vertical".')
    return ToolResult.success_result(f"Scrolled {type} {direction} by {wheel_times}.")


class Move(BaseModel):
    loc: list[int] = Field(
        ...,
        description="[x, y] pixel coordinates to move the mouse cursor to",
        examples=[[640, 360], [100, 100]],
    )
    drag: bool = Field(
        default=False,
        description="If true, holds the left mouse button and drags from the current position to the target (drag-and-drop). If false, moves the cursor without clicking (hover).",
        examples=[True, False],
    )


@Tool(
    name="move",
    description="Moves the mouse cursor to a target location, or drags from the current position to the target. drag=false: Hover over elements to reveal tooltips, dropdown menus, or reposition the cursor. drag=true: Hold left mouse button from the current cursor position and drag to the target coordinates. Use for drag-and-drop of files, window resizing, slider adjustment, or reordering items.",
    model=Move,
)
async def move(loc: list[int], drag: bool = False, **kwargs) -> ToolResult:
    x, y = loc[0], loc[1]
    if drag:
        cx, cy = ax.GetCursorPos()
        ax.DragTo(cx, cy, x, y)
        return ToolResult.success_result(f"Dragged to ({x},{y}).")
    ax.MoveTo(x, y)
    return ToolResult.success_result(f"Moved to ({x},{y}).")


class Shortcut(BaseModel):
    shortcut: str = Field(
        ...,
        description="Keyboard shortcut to press. Use '+' to combine keys. On macOS: 'command+c' for copy, 'command+tab' for window switch. Common aliases: ctrl->command, win->command, alt->option.",
        examples=["enter", "escape", "command+c", "command+v", "command+tab", "command+shift+n"],
    )


@Tool(
    name="shortcut",
    description="Presses a keyboard shortcut. Use '+' to combine keys (e.g., 'command+c'). Common shortcuts: command+c (copy), command+v (paste), command+z (undo), command+s (save), command+a (select all), command+f (find), command+w (close tab), command+t (new tab), command+tab (switch window), enter (confirm), escape (cancel). On macOS, ctrl/win map to command, alt maps to option. Prefer shortcuts over mouse interactions when the operation is unambiguous.",
    model=Shortcut,
)
async def shortcut(shortcut: str, **kwargs) -> ToolResult:
    keys = shortcut.split("+")
    mapped = [KEY_ALIASES.get(k.strip().lower(), k.strip()) for k in keys]
    ax.HotKey(*mapped)
    return ToolResult.success_result(f"Pressed {shortcut}.")
