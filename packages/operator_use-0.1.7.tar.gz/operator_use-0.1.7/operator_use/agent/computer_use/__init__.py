﻿"""Computer-use Desktop and Tree services for Windows/macOS."""

import sys

Desktop = None
WatchDog = None

try:
    match sys.platform:
        case "win32":
            from operator_use.agent.computer_use.windows.desktop.service import Desktop
            from operator_use.agent.computer_use.windows.watchdog.service import WatchDog
        case "darwin":
            from operator_use.agent.computer_use.macos.desktop.service import Desktop
            from operator_use.agent.computer_use.macos.watchdog.service import WatchDog
        case _:
            pass
except (ImportError, OSError):
    pass

__all__ = ["Desktop", "WatchDog"]
