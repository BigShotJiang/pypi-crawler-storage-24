from pathlib import Path

class Memory:
    def __init__(self,workspace:Path) -> None:
        self.workspace = workspace
        self.memory_dir = workspace / "memory"
        self.memory_file = self.memory_dir / "MEMORY.md"
    
    def read_memory(self) -> str:
        if not self.memory_file.exists():
            return ""
        return self.memory_file.read_text()
    
    def write_memory(self, memory: str) -> None:
        self.memory_file.write_text(memory)

    def get_memory_context(self) -> str|None:
        memory=self.read_memory()
        return f"""## Memory (Long-Term Memory)\n\n{memory}""" if memory else None