# Operator

**A personal assistant that operates your computer. Just like you.**

Operator is an AI agent you message from anywhere — Telegram, Discord, or Slack — and it works on your computer. It reads files, browses the web, runs commands, clicks through apps, and remembers who you are. It runs locally, connects to any LLM, and gets smarter over time.

Inspired by [nanobot](https://github.com/HKUDS/nanobot) by the Data Intelligence Lab at the University of Hong Kong.

> Currently supported on **Windows** and **macOS**.

---

## Install

```bash
uvx operator-use onboard
```

Or with uv:

```bash
uv tool install operator-use
operator onboard
```

Follow the setup wizard to configure your LLM and connect a channel (Telegram, Discord, or Slack).

Then start your assistant:

```bash
operator run
```

---

## What it can do

- Control your desktop — click, type, scroll, take screenshots, open apps
- Run terminal commands and manage files
- Browse and search the web
- Respond through Telegram, Discord, Slack, or MQTT
- Speak and listen via voice (STT / TTS)
- Remember context across conversations
- Schedule and run tasks on a schedule

---

## Supported LLMs

OpenAI · Anthropic · Google · Mistral · Groq · Ollama · Azure · Cerebras · DeepSeek · LiteLLM · and more

---

## License

MIT
