#!/bin/bash

ROOT_GIT=$(git rev-parse --show-toplevel)
PROTO_PKG=$ROOT_GIT/sdk/python/frogml/frogml/_proto
mkdir -p "$PROTO_PKG"

#################
#### Helpers ####
#################

function qwak_generate_proto() {
  [ ! -d $1 ] && echo "Directory $1 no exists"  && exit 1
  [ ! -f $1/$2 ] && echo "File $1/$2 no exists"  && exit 1
  if [ -z "$3" ]
  then
    python -m grpc_tools.protoc -I $1 --python_out=$PROTO_PKG --mypy_out=$PROTO_PKG --grpc_python_out=$PROTO_PKG $1/$2
  else
      if [ -z "$4" ]
      then
        python -m grpc_tools.protoc -I $1 --python_out=$PROTO_PKG --mypy_out=$PROTO_PKG --grpc_python_out=$PROTO_PKG $1/$2 --proto_path $3
      else
        python -m grpc_tools.protoc -I $1 --python_out=$PROTO_PKG --mypy_out=$PROTO_PKG --grpc_python_out=$PROTO_PKG $1/$2 --proto_path $3 --proto_path $4
      fi
  fi
}

###################
#### Users api ####
###################
USER_API="$ROOT_GIT/services/core/java/user-management/user-management-api/src/main/proto"
declare -a users_proto=(
  "qwak/administration/v0/authentication/authentication_service.proto"
  "qwak/administration/authenticated_user/v1/authenticated_user_service.proto"
  "qwak/administration/authenticated_user/v1/credentials.proto"
  "qwak/administration/authenticated_user/v1/details.proto"
  "qwak/administration/account/v1/personalization.proto"
  "qwak/administration/account/v1/preferences.proto"
  "qwak/administration/account/v1/terms.proto"
  "qwak/administration/account/v1/jfrog_tenant_details.proto"
  "qwak/administration/account/v1/account.proto"
  "qwak/administration/account/v1/account_service.proto"
  "qwak/administration/cluster/v2/cluster.proto"
  "qwak/administration/cluster/v2/cluster_service.proto"
  "qwak/administration/v0/environments/configuration.proto"
  "qwak/administration/v0/environments/personalization.proto"
  "qwak/administration/v0/environments/environment.proto"
  "qwak/administration/v0/environments/environment_service.proto"
  "qwak/administration/v1/environments/environment.proto"
  "qwak/administration/v1/environments/environment_service.proto"
  "qwak/administration/v0/users/user.proto"
  "qwak/self_service/user/v1/api_key.proto"
  "qwak/self_service/user/v1/user.proto"
  "qwak/self_service/user/v1/user_service.proto"
  "qwak/self_service/account/v0/account_membership_service.proto"
  "qwak/self_service/account/v0/account_membership.proto"
  "qwak/self_service/account/v0/account_status.proto"
  "qwak/self_service/account/v0/managing_account_service.proto"
  "qwak/self_service/account/v0/managing_account.proto"
  "qwak/administration/runtime_configuration/v0/creds/auth.proto"
  "qwak/administration/runtime_configuration/v0/creds/secret.proto"
  "qwak/administration/runtime_configuration/v0/runtime_config.proto"
  "qwak/administration/runtime_configuration/v0/network_config.proto"
  "qwak/administration/runtime_configuration/v0/feature_store_config.proto"
  "qwak/administration/runtime_configuration/v0/sql_engine_config.proto"
  "qwak/administration/runtime_configuration/v0/data_catalog_config.proto"
  "qwak/administration/runtime_configuration/v0/logs_storage_config.proto"
  "qwak/administration/runtime_configuration/v0/object_storage_config.proto"
  "qwak/administration/runtime_configuration/v0/hosting/azure/auth.proto"
  "qwak/administration/runtime_configuration/v0/external/databricks/auth.proto"
  "qwak/administration/runtime_configuration/v0/hosting_config.proto"
  "qwak/administration/runtime_configuration/v0/model_analytics_storage_config.proto"
  "qwak/administration/runtime_configuration/v0/external/redis_config.proto"
  "qwak/administration/runtime_configuration/v0/external/kafka_config.proto"
  "qwak/administration/runtime_configuration/v0/external/prometheus_config.proto"
  "qwak/administration/runtime_configuration/v0/external/victoriametrics_config.proto"
  "qwak/administration/runtime_configuration/v0/observability_config.proto"
  "qwak/administration/runtime_configuration/v0/external/elasticsearch_config.proto"
  "qwak/administration/runtime_configuration/v0/container_registry_config.proto"
  "qwak/administration/runtime_configuration/v0/hosting/aws/auth.proto"
)
for p in "${users_proto[@]}"
do
  qwak_generate_proto $USER_API $p
done

###############################
#### Service Discovery API ####
###############################
SERVICE_DISCOVERY_API="$ROOT_GIT/services/core/java/user-management/user-management-api/src/main/proto"
declare -a service_discovery_proto=(
  "qwak/service_discovery/service_discovery_location.proto"
  "qwak/service_discovery/service_discovery_location_service.proto"
)
for p in "${service_discovery_proto[@]}"
do
  qwak_generate_proto "$SERVICE_DISCOVERY_API" $p
done

######################
#### Alerting api ####
######################
MONITORING_API="$ROOT_GIT/services/core/java/user-management/monitoring-mangement-api/src/main/proto"
declare -a alerting_proto=(
  "qwak/monitoring/v0/alerting_channel.proto"
  "qwak/monitoring/v0/alerting_channel_management_service.proto"
  "qwak/monitoring/v0/alerting_channel_sync_service.proto"

)
for p in "${alerting_proto[@]}"
do
  qwak_generate_proto $MONITORING_API $p
done

#######################
#### Ecosystem api ####
#######################
ECOSYSTEM_API="$ROOT_GIT/services/shared/java/libs/qwak-common/qwak-common-api/qwak-platform-ecosystem-api/src/main/proto"
USER_API="$ROOT_GIT/services/core/java/user-management/user-management-api/src/main/proto"
declare -a ecosystem_proto=(
  "qwak/ecosystem/v0/credentials.proto"
  "qwak/ecosystem/v0/auth.proto"
  "qwak/ecosystem/v0/azure_credentials.proto"
  "qwak/ecosystem/v0/ecosystem.proto"
  "qwak/ecosystem/v0/ecosystem_runtime_service.proto"
  "qwak/ecosystem/jfrog/v0/token.proto"
  "qwak/ecosystem/jfrog/v0/token_service.proto"
  "qwak/ecosystem/jfrog/v0/jfrog_tenant.proto"
  "qwak/ecosystem/jfrog/v0/jfrog_tenant_info_service.proto"
)
for p in "${ecosystem_proto[@]}"
do
  qwak_generate_proto $ECOSYSTEM_API $p $USER_API
done

####################################
#### User Application Value api ####
####################################
USER_APP_VALUE_API="$ROOT_GIT/services/core/go/admiral/user-application-value-api/src/main/proto"
declare -a user_app_proto=(
  "qwak/user_application/common/v0/resources.proto"
  "qwak/user_application/v0/user_application.proto"
)
for p in "${user_app_proto[@]}"
do
  qwak_generate_proto $USER_APP_VALUE_API $p
done


####################################
#### Admiral api ####
####################################
USER_APP_INSTANCE_API="$ROOT_GIT/services/core/go/admiral/admiral-api/src/main/proto"
declare -a user_instance_proto=(
  "qwak/admiral/user_application_instance/v0/user_application_instance.proto"
  "qwak/admiral/user_application_instance/v0/user_application_instance_service.proto"
)
for p in "${user_instance_proto[@]}"
do
  qwak_generate_proto $USER_APP_INSTANCE_API $p $USER_APP_VALUE_API $USER_API
done

####################################
#### Admiral system secret api ####
####################################
ADMIRAL_SYSTEM_SECRET_API="$ROOT_GIT/services/core/go/admiral/admiral-api/src/main/proto"
declare -a admiral_system_secret_proto=(
  "qwak/admiral/secret/v0/system_secret_service.proto"
  "qwak/admiral/secret/v0/secret_service.proto"
  "qwak/admiral/secret/v0/secret.proto"
  "qwak/admiral/secret/v0/account_secret.proto"
)
for p in "${admiral_system_secret_proto[@]}"
do
  qwak_generate_proto $ADMIRAL_SYSTEM_SECRET_API $p
done


#######################
#### Monitoring api ####
#######################
MONITORING_API="$ROOT_GIT/services/core/java/user-management/monitoring-mangement-api/src/main/proto"
USER_API="$ROOT_GIT/services/core/java/user-management/user-management-api/src/main/proto"
declare -a ecosystem_proto=(
  "qwak/monitoring/v0/alerting_channel.proto"
  "qwak/monitoring/v0/alerting_channel_management_service.proto"
  "qwak/monitoring/v0/alerting_channel_sync_service.proto"
)
for p in "${ecosystem_proto[@]}"
do
  qwak_generate_proto $MONITORING_API $p $USER_API
done

#############################
#### Fitness service api ####
#############################
FITNESS_API="$ROOT_GIT/services/edge/java/fitness-service/fitness-service-api/src/main/proto"
declare -a fitness_proto=(
  "qwak/fitness_service/constructs.proto"
  "qwak/fitness_service/fitness.proto"
  "qwak/fitness_service/status.proto"
)
for p in "${fitness_proto[@]}"
do
  python -m grpc_tools.protoc -I $FITNESS_API --python_out=$PROTO_PKG --mypy_out=$PROTO_PKG --grpc_python_out=$PROTO_PKG $FITNESS_API/$p
done


###########################
#### Feature store api ####
###########################
FEATURE_STORE_API="$ROOT_GIT/services/core/java/features-manager/features-manager-api/src/main/proto"
declare -a feature_store_proto=(
    "qwak/feature_store/repository/common/platform.proto"
    "qwak/feature_store/platform/platform_details.proto"
    "qwak/feature_store/v1/internal/featureset/featureset_token_service.proto"
    "qwak/feature_store/features/feature_set_attribute.proto"
    "qwak/feature_store/v1/internal/data_source/data_source_service.proto"
    "qwak/feature_store/features/feature_set.proto"
    "qwak/feature_store/v1/common/source_code/source_code.proto"
    "qwak/feature_store/features/feature_set_types.proto"
    "qwak/feature_store/features/feature_set_service.proto"
    "qwak/feature_store/features/execution.proto"
    "qwak/feature_store/features/aggregation.proto"
    "qwak/feature_store/features/feature_set_state.proto"
    "qwak/feature_store/features/feature_set_state_service.proto"
    "qwak/feature_store/features/monitoring.proto"
    "qwak/feature_store/features/real_time_feature_extractor.proto"
    "qwak/feature_store/features/deployment.proto"
    "qwak/feature_store/features/deployment_service.proto"
    "qwak/feature_store/sources/batch.proto"
    "qwak/feature_store/sources/data_source_attribute.proto"
    "qwak/feature_store/sources/data_source.proto"
    "qwak/feature_store/sources/data_source_service.proto"
    "qwak/feature_store/sources/streaming.proto"
    "qwak/feature_store/entities/entity_service.proto"
    "qwak/feature_store/entities/entity.proto"
    "qwak/feature_store/sinks/sink.proto"
    "qwak/feature_store/v1/common/jfrog_artifact/jfrog_artifact.proto"
    "qwak/feature_store/repository/common/platform.proto"
)
for p in "${feature_store_proto[@]}"
do
  qwak_generate_proto $FEATURE_STORE_API $p
done

#############################################
#### Feature Store Execution Manager API ####
#############################################
FEATURE_STORE_EXEC_API="$ROOT_GIT/services/core/java/fs-execution-manager/fs-execution-manager-api/src/main/proto"
declare -a feature_store_exec_proto=(
    "qwak/execution/v1/backfill.proto"
    "qwak/execution/v1/batch.proto"
    "qwak/execution/v1/streaming.proto"
    "qwak/execution/v1/streaming_aggregation.proto"
    "qwak/execution/v1/deletion.proto"
    "qwak/execution/v1/execution.proto"
    "qwak/execution/v1/execution_service.proto"
    "qwak/execution/v1/jobs/reports/report.proto"
    "qwak/execution/v1/jobs/job.proto"
    "qwak/execution/v1/jobs/job_service.proto"
    "qwak/execution/v1/state/execution_state.proto"
    "qwak/execution/v1/state/execution_state_service.proto"
    "qwak/execution/v1/state/featureset_state.proto"
    "qwak/execution/v1/state/spark_execution_state.proto"
    "qwak/execution/v1/internal/deployment/platform_details.proto"
)
for p in "${feature_store_exec_proto[@]}"
do
  qwak_generate_proto $FEATURE_STORE_EXEC_API $p $FEATURE_STORE_API
done

#######################################
#### Feature Sets Job Registry api ####
#######################################
FEATURE_SETS_JOB_REGISTRY_API="$ROOT_GIT/services/core/java/feature-sets-job-registry/feature-sets-job-registry-api/src/main/proto"
declare -a feature_sets_job_registry_proto=(
    "qwak/feature_store/jobs/job.proto"
    "qwak/feature_store/jobs/job_service.proto"
    "qwak/feature_store/jobs/v1/job.proto"
    "qwak/feature_store/jobs/v1/job_service.proto"
    "qwak/feature_store/reports/report.proto"
)
for p in "${feature_sets_job_registry_proto[@]}"
do
  qwak_generate_proto $FEATURE_SETS_JOB_REGISTRY_API $p
done

###################
#### Analytics ####
###################
ANALYTICS_API="$ROOT_GIT/services/core/java/analytics-engine/analytics-engine-api/src/main/proto"
declare -a analytics_proto=(
    "qwak/analytics/analytics.proto"
    "qwak/analytics/analytics_service.proto"
)
for p in "${analytics_proto[@]}"
do
  qwak_generate_proto $ANALYTICS_API $p
done

#####################
#### Serving api ####
#####################
SERVING_API="$ROOT_GIT/services/edge/java/online-serving/serving-api/src/main/proto"
declare -a online_serving_proto=(
  "qwak/feature_store/serving/serving.proto"
  "qwak/feature_store/serving/metadata.proto"
  "qwak/feature_store/serving/v1/value.proto"
  "qwak/feature_store/serving/management.proto"
)
for p in "${online_serving_proto[@]}"
do
  qwak_generate_proto "$SERVING_API" $p $FEATURE_STORE_API
done

########################
#### Deployment api ####
########################
DEPLOYMENT_API="$ROOT_GIT/services/core/java/deployment-management/deployment-api/src/main/proto"
declare -a deployment_proto=(
    "qwak/audience/v1/audience.proto"
    "qwak/audience/v1/audience_api.proto"
    "qwak/auto_scaling/v1/auto_scaling.proto"
    "qwak/auto_scaling/v1/auto_scaling_service.proto"
    "qwak/deployment/deployment.proto"
    "qwak/deployment/deployment_messages.proto"
    "qwak/deployment/deployment_service.proto"
    "qwak/deployment/alert.proto"
    "qwak/deployment/alert_service.proto"
)
for p in "${deployment_proto[@]}"
do
  qwak_generate_proto $DEPLOYMENT_API $p $USER_APP_VALUE_API
done

######################
#### Feedback API ####
######################
FEEDBACK_API="$ROOT_GIT/services/edge/java/feedback/feedback-api/src/main/proto"
qwak_generate_proto $FEEDBACK_API "qwak/inference/feedback/feedback.proto"

################################
#### Build orchestrator api ####
################################
BUILD_ORCHESTRATOR_API="$ROOT_GIT/services/core/java/builds-orchestration/builds-orchestrator-api/src/main/proto"

declare -a proto=(
    "qwak/builds/build_values.proto"
    "qwak/builds/build.proto"
    "qwak/build/v1/build.proto"
    "qwak/builds/build_url.proto"
    "qwak/build/v1/build_api.proto"
    "qwak/builds/builds_orchestrator_service.proto"
    "qwak/build_settings/build_settings.proto"
    "qwak/build_settings/build_settings_api.proto"
    "qwak/artifactory_settings/artifactory_settings.proto"
)
for p in "${proto[@]}"
do
  qwak_generate_proto $BUILD_ORCHESTRATOR_API $p $USER_APP_VALUE_API $FITNESS_API
done

qwak_generate_proto $BUILD_ORCHESTRATOR_API "qwak/builds/internal_builds_orchestrator_service.proto" $FITNESS_API $USER_APP_VALUE_API

####################
#### Models api ####
####################
MODEL_API="$ROOT_GIT/services/core/java/models-management/models-management-api/src/main/proto"
declare -a model_proto=(
  "qwak/projects/jfrog_project_spec.proto"
  "qwak/projects/projects.proto"
  "qwak/model_group/model_group_repository_details.proto"
  "qwak/model_group/model_group.proto"
  "qwak/builds/builds.proto"
  "qwak/models/models_query.proto"
  "qwak/models/models.proto"
  "qwak/data_versioning/data_versioning.proto"
  "qwak/data_versioning/data_versioning_service.proto"
  "qwak/file_versioning/file_versioning.proto"
  "qwak/file_versioning/file_versioning_service.proto"
  "qwak/instance_template/instance_template.proto"
  "qwak/instance_template/instance_template_service.proto"
)
for p in "${model_proto[@]}"
do
  python -m grpc_tools.protoc -I $MODEL_API --python_out=$PROTO_PKG --mypy_out=$PROTO_PKG --grpc_python_out=$PROTO_PKG $MODEL_API/$p --proto_path $BUILD_ORCHESTRATOR_API --proto_path $FITNESS_API --proto_path $DEPLOYMENT_API --proto_path $USER_APP_VALUE_API
done

####################
#### Secret api ####
####################
SECRET_API="$ROOT_GIT/services/edge/java/secret-service/secret-api/src/main/proto"
qwak_generate_proto $SECRET_API "qwak/secret_service/secret_service.proto"

###########################
#### Logger reader api ####
###########################
LOGGER_READER_API="$ROOT_GIT/services/edge/go/log-reader/log-reader-api/proto"
declare -a logger_proto=(
  "qwak/logging/log_filter.proto"
  "qwak/logging/log_reader_service.proto"
  "qwak/logging/log_source.proto"
  "qwak/logging/log_line.proto"
)
for p in "${logger_proto[@]}"
do
  qwak_generate_proto $LOGGER_READER_API $p
done


#################################
## Kube Deployment Captain API ##
#################################
KUBE_CAPTAIN_API="$ROOT_GIT/services/edge/java/kube-deployment-captain/kube-deployment-captain-api/src/main/proto"
declare -a kube_captain_proto=(
  "qwak/kube_deployment_captain/alert.proto"
  "qwak/kube_deployment_captain/alerting.proto"
  "qwak/kube_deployment_captain/batch_job.proto"
  "qwak/kube_deployment_captain/deployment.proto"
  "qwak/kube_deployment_captain/feature_set_deployment.proto"
  "qwak/kube_deployment_captain/kube_deployment_captain_service.proto"
  "qwak/kube_deployment_captain/traffic_mapping.proto"
  "qwak/traffic/v1/traffic.proto"
  "qwak/traffic/v1/traffic_api.proto"
)
for p in "${kube_captain_proto[@]}"
do
  qwak_generate_proto "$KUBE_CAPTAIN_API" $p $FEATURE_STORE_API $FEATURE_STORE_EXEC_API
done

###############################
#### Batch Job Manager API ####
###############################
BATCH_JOB_API="$ROOT_GIT/services/core/java/batch-job-management/batch-job-api/src/main/proto"
declare -a batch_job_proto=(
  "qwak/batch_job/v1/batch_job_resources.proto"
  "qwak/batch_job/v1/batch_job_service.proto"
  "qwak/batch_job/v1/batch_job_events.proto"
)
for p in "${batch_job_proto[@]}"
do
  python -m grpc_tools.protoc -I $BATCH_JOB_API --python_out=$PROTO_PKG --mypy_out=$PROTO_PKG --grpc_python_out=$PROTO_PKG $BATCH_JOB_API/$p --proto_path $USER_API --proto_path $USER_APP_VALUE_API --proto_path $KUBE_CAPTAIN_API
done


################################
## Automations Management api ##
################################
AUTOMATIONS_MANAGEMENT_API="$ROOT_GIT/services/core/java/automation-management/automation-management-api/src/main/proto"
declare -a automation_proto=(
  "qwak/automation/v1/automation_management_service.proto"
  "qwak/automation/v1/automation.proto"
  "qwak/automation/v1/auto_scaling.proto"
  "qwak/automation/v1/automation_execution.proto"
  "qwak/automation/v1/action.proto"
  "qwak/automation/v1/trigger.proto"
  "qwak/automation/v1/notification.proto"
  "qwak/automation/v1/common.proto"
)
for p in "${automation_proto[@]}"
do
  python -m grpc_tools.protoc -I $AUTOMATIONS_MANAGEMENT_API --python_out=$PROTO_PKG --mypy_out=$PROTO_PKG --grpc_python_out=$PROTO_PKG $AUTOMATIONS_MANAGEMENT_API/$p --proto_path $BATCH_JOB_API --proto_path $USER_API --proto_path $USER_APP_VALUE_API --proto_path $KUBE_CAPTAIN_API
done

###############################
#### Offline Serving API ####
###############################
FS_OFFLINE_SERVING_API="$ROOT_GIT/services/core/java/fs-offline-serving/fs-offline-serving-api/src/main/proto"
declare -a fs_offline_serving_proto=(
  "qwak/offline/serving/v1/feature_values.proto"
  "qwak/offline/serving/v1/population.proto"
  "qwak/offline/serving/v1/options.proto"
  "qwak/offline/serving/v1/offline_serving_async_service.proto"
)
for p in "${fs_offline_serving_proto[@]}"
do
  qwak_generate_proto $FS_OFFLINE_SERVING_API $p $FEATURE_STORE_API
done


###############################
#### Features Operator API ####
###############################
FEATURES_OPERATOR_API="$ROOT_GIT/services/core/java/features-operator/features-operator-api/src/main/proto"
declare -a features_operator_proto=(
  "qwak/features_operator/v1/features_operator.proto"
  "qwak/features_operator/v1/features_operator_service.proto"
  "qwak/features_operator/v2/features_operator.proto"
  "qwak/features_operator/v2/features_operator_service.proto"
  "qwak/features_operator/v3/features_operator_async_service.proto"
  "qwak/features_operator/v3/features_operator.proto"
)
for p in "${features_operator_proto[@]}"
do
  qwak_generate_proto $FEATURES_OPERATOR_API $p $FEATURE_STORE_API
done


#################################
## Feature Sets Job Registry API ##
#################################

JOB_REGISTRY_API="$ROOT_GIT/services/core/java/feature-sets-job-registry/feature-sets-job-registry-api/src/main/proto"
declare -a job_registry_proto=(
  "qwak/feature_store/jobs/job.proto"
  "qwak/feature_store/jobs/job_service.proto"
)
for p in "${job_registry_proto[@]}"
do
  qwak_generate_proto $JOB_REGISTRY_API $p
done

#################################
## Integration Manager API ##
#################################
INTEGRATION_MANAGER_API="$ROOT_GIT/services/core/java/Integration-management/Integration-management-api/src/main/proto"
declare -a integration_manager_proto=(
  "qwak/integration/integration_service.proto"
  "qwak/integration/integration.proto"
  "qwak/integration/open_a_i_integration.proto"
  "qwak/integration/opsgenie_integration.proto"
  "qwak/integration/pagerduty_integration.proto"
  "qwak/integration/slack_app_integration.proto"
  "qwak/integration/hugging_face_integration.proto"
)
for p in "${integration_manager_proto[@]}"
do
  qwak_generate_proto $INTEGRATION_MANAGER_API $p
done



#################################
## Model Descriptor API ##
#################################
MODL_DESCRIPTOR_API="$ROOT_GIT/services/shared/java/libs/model-descriptor-api/src/main/proto"
declare -a model_descriptor_proto=(
  "qwak/model_descriptor/open_ai_descriptor.proto"
)
for p in "${model_descriptor_proto[@]}"
do
  qwak_generate_proto $MODL_DESCRIPTOR_API $p
done


#################################
## Model Version Manager API ##
#################################
MODEL_VERSION_MANAGER_API="$ROOT_GIT/services/core/java/model-version-manager/model-version-manager-api/src/main/proto"
declare -a model_version_manager_proto=(
  "jfml/model_version/v1/model_repository_spec.proto"
  "jfml/model_version/v1/model_version_framework.proto"
  "jfml/model_version/v1/model_version.proto"
  "jfml/model_version/v1/build_spec.proto"
  "jfml/model_version/v1/artifact.proto"
  "jfml/model_version/v1/model_version_manager_service.proto"
)
for proto_file in "${model_version_manager_proto[@]}"
do
  qwak_generate_proto $MODEL_VERSION_MANAGER_API $proto_file $FITNESS_API $USER_APP_VALUE_API
done


#################################
## JFrog Gateway API ##
#################################
JFROG_GATEWAY_API="$ROOT_GIT/services/core/java/jfrog-gateway/jfrog-gateway-api/src/main/proto"
declare -a jfrog_gateway_proto=(
  "qwak/jfrog/gateway/v0/repository.proto"
  "qwak/jfrog/gateway/v0/repository_service.proto"
)
for proto_file in "${jfrog_gateway_proto[@]}"
do
  qwak_generate_proto $JFROG_GATEWAY_API $proto_file
done


#################################
## Hosting Gateway API ##
#################################
HOSTING_GATEWAY_API="$ROOT_GIT/services/shared/java/hosting-gateway/hosting-gateway-api/src/main/proto"
declare -a hosting_gateway_proto=(
  "jfml/hosting_gateway/v1/build_upload_url.proto"
  "jfml/hosting_gateway/v1/hosting_gateway_service.proto"
)
for proto_file in "${hosting_gateway_proto[@]}"
do
  qwak_generate_proto $HOSTING_GATEWAY_API $proto_file
done


##################################
## Model Deployment Manager API ##
##################################
MODEL_DEPLOYMENT_MANAGER_API="$ROOT_GIT/services/core/java/model-deployment-manager/model-deployment-manager-api/src/main/proto"
declare -a model_deployment_manager_proto=(
  "com/jfrog/ml/model/deployment/v1/auto_scaling.proto"
  "com/jfrog/ml/model/deployment/v1/environment_variables_configuration.proto"
  "com/jfrog/ml/model/deployment/v1/model_artifact_identifier.proto"
  "com/jfrog/ml/model/deployment/v1/probes_configuration.proto"
  "com/jfrog/ml/model/deployment/v1/realtime_deployment.proto"
  "com/jfrog/ml/model/deployment/v1/resource_configuration.proto"
  "com/jfrog/ml/model/deployment/v1/deployment.proto"
  "com/jfrog/ml/model/deployment/v1/model_deployment_brief.proto"
  "com/jfrog/ml/model/deployment/v1/model_deployment_filter.proto"
  "com/jfrog/ml/model/deployment/v1/deployment_service.proto"
)
for proto_file in "${model_deployment_manager_proto[@]}"
do
  qwak_generate_proto $MODEL_DEPLOYMENT_MANAGER_API $proto_file
done

###########################################################################
#### Replace imports from qwak., jfml., com. to frogml._proto.<prefix> ####
###########################################################################

if [[ "$OSTYPE" == "darwin"* ]]; then
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/from qwak./from frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/import qwak./import frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/-> qwak./-> frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/: qwak./: frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/from jfml./from frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/import jfml./import frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/-> jfml./-> frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/: jfml./: frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/from com\./from frogml._proto.com./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/import com\./import frogml._proto.com./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/-> com\./-> frogml._proto.com./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i '' -e "s/: com\./: frogml._proto.com./g"

  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/from qwak./from frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/import qwak./import frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/-> qwak./-> frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/: qwak./: frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/from jfml./from frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/import jfml./import frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/-> jfml./-> frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/: jfml./: frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/from com\./from frogml._proto.com./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/import com\./import frogml._proto.com./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/-> com\./-> frogml._proto.com./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i '' -e "s/: com\./: frogml._proto.com./g"
else
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/from qwak./from frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/import qwak./import frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/-> qwak./-> frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/: qwak./: frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/from jfml./from frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/import jfml./import frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/-> jfml./-> frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/: jfml./: frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/from com\./from frogml._proto.com./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/import com\./import frogml._proto.com./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/-> com\./-> frogml._proto.com./g"
  find $PROTO_PKG -name \*.py -type f -print0 | xargs -0 -n1 sed -i -e "s/: com\./: frogml._proto.com./g"

  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/from qwak./from frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/import qwak./import frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/-> qwak./-> frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/: qwak./: frogml._proto.qwak./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/from jfml./from frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/import jfml./import frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/-> jfml./-> frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/: jfml./: frogml._proto.jfml./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/from com\./from frogml._proto.com./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/import com\./import frogml._proto.com./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/-> com\./-> frogml._proto.com./g"
  find $PROTO_PKG -name \*.pyi -type f -print0 | xargs -0 -n1 sed -i -e "s/: com\./: frogml._proto.com./g"
fi
