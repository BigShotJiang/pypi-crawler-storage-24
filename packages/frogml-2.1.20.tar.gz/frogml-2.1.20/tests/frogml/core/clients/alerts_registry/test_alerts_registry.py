from http import HTTPStatus
from typing import Callable
from unittest.mock import MagicMock

import grpc
import pytest

from frogml.core.clients.alerts_registry import AlertingRegistryClient
from frogml.core.clients.alerts_registry.channel import Channel, SlackChannel
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
    create_grpc_error,
)


def test_create_alert(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    client = AlertingRegistryClient()
    name = "name"
    api_url = "url"
    conf = SlackChannel(api_url=api_url)
    channel = Channel(name=name, channel_conf=conf)

    # When
    client.create_alerting_channel(channel=channel)

    # Then
    assert len(frogml_services_mock.alerts_registry_service.alerts_channels) == 1
    assert (
        frogml_services_mock.alerts_registry_service.alerts_channels[
            name
        ].spec.configuration.slack.api_url.value
        == api_url
    )


def test_get_alert(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    client = AlertingRegistryClient()
    name = "name"
    channel = Channel(name=name, channel_conf=SlackChannel(api_url="url"))
    client.create_alerting_channel(channel=channel)

    # When
    _channel_id, result = client.get_alerting_channel(name)

    # Then
    assert result is not None
    assert result.name == name
    assert result.channel_conf.api_url == "url"


def test_list_alerts(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    client = AlertingRegistryClient()
    name = "name"
    channel = Channel(name=name, channel_conf=SlackChannel(api_url="http://url"))
    client.create_alerting_channel(channel=channel)

    # When
    channels = client.list_alerting_channel_from_client().description

    # Then
    assert len(channels) == 1


_CHANNEL = Channel(name="ch", channel_conf=SlackChannel(api_url="http://u"))

DECORATOR_EXCEPTION_CASES = [
    pytest.param(
        "ListAlertingChannel",
        lambda c: c.list_alerting_channel(),
        "Failed to list alerting channels",
        "List Alerting Channels",
        id="list",
    ),
    pytest.param(
        "CreateAlertingChannel",
        lambda c: c.create_alerting_channel(channel=_CHANNEL),
        "Failed to create alerting channel: 'ch': Exception: backend error",
        "Create Alerting Channel",
        id="create",
    ),
    pytest.param(
        "UpdateAlertingChannel",
        lambda c: c.update_alerting_channel(channel_id="id1", channel=_CHANNEL),
        "Failed to update alerting channel named: ch: Exception: backend error",
        "Update Alerting Channel",
        id="update",
    ),
    pytest.param(
        "DeleteAlertingChannel",
        lambda c: c.delete_alerting_channel(channel_name="mychannel"),
        "Failed to delete alerting channel named: mychannel: Exception: backend error",
        "Delete Alerting Channel",
        id="delete",
    ),
]


@pytest.mark.parametrize(
    "stub_method, invoke_client, expected_msg, expected_op",
    DECORATOR_EXCEPTION_CASES,
)
def test_generic_exception_raises_frogml_exception(
    stub_method: str,
    invoke_client: Callable,
    expected_msg: str,
    expected_op: str,
) -> None:
    client = AlertingRegistryClient()
    client.alerting_channel_mgmt_service = MagicMock()
    getattr(client.alerting_channel_mgmt_service, stub_method).side_effect = Exception(
        "backend error"
    )
    with pytest.raises(FrogmlException) as exc_info:
        invoke_client(client)
    assert_frogml_exception(
        exc_info.value,
        expected_error_message=expected_msg,
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation=expected_op,
    )


def test_get_alerting_channel_generic_exception_raises_frogml_exception() -> None:
    client = AlertingRegistryClient()
    client.alerting_channel_mgmt_service = MagicMock()
    client.alerting_channel_mgmt_service.GetAlertingChannelByName = MagicMock(
        side_effect=Exception("backend error")
    )
    with pytest.raises(FrogmlException) as exc_info:
        client.get_alerting_channel("mychannel")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Failed to get alerting channel name: mychannel",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Get Alerting Channel",
    )


def test_get_alerting_channel_not_found_returns_none() -> None:
    client = AlertingRegistryClient()
    client.alerting_channel_mgmt_service = MagicMock()
    client.alerting_channel_mgmt_service.GetAlertingChannelByName = MagicMock(
        side_effect=create_grpc_error(
            code=grpc.StatusCode.NOT_FOUND, details="channel not found"
        )
    )

    channel_id, channel = client.get_alerting_channel("nonexistent")

    assert channel_id is None
    assert channel is None


def test_get_alerting_channel_non_not_found_error_raises_frogml_exception() -> None:
    client = AlertingRegistryClient()
    client.alerting_channel_mgmt_service = MagicMock()
    client.alerting_channel_mgmt_service.GetAlertingChannelByName = MagicMock(
        side_effect=create_grpc_error(
            code=grpc.StatusCode.INTERNAL, details="server error"
        )
    )

    with pytest.raises(FrogmlException) as exc_info:
        client.get_alerting_channel("mychannel")

    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Failed to get alerting channel name: mychannel",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Get Alerting Channel",
    )


def test_list_alerting_channel_happy_flow(frogml_services_mock: FrogmlMocks) -> None:
    client = AlertingRegistryClient()
    channel = Channel(name="test_ch", channel_conf=SlackChannel(api_url="http://url"))
    client.create_alerting_channel(channel=channel)

    result = client.list_alerting_channel()

    assert len(result) == 1
    channel_id, returned_channel = result[0]
    assert channel_id is not None
    assert returned_channel.name == "test_ch"
