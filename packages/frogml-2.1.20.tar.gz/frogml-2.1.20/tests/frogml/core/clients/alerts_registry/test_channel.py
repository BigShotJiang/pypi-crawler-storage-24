from http import HTTPStatus

import pytest

from frogml._proto.qwak.monitoring.v0.alerting_channel_pb2 import (
    ChannelConfiguration as ChannelConfigurationProto,
)
from frogml.core.clients.alerts_registry.channel import (
    Channel,
    ChannelConfiguration,
    PagerDutyChannel,
    SlackChannel,
)
from frogml.core.exceptions import FrogmlException
from tests.frogml.core.utils.frogml_exception_helpers import assert_frogml_exception


def test_channel_configuration_from_proto_unsupported_type_raises() -> None:
    proto = ChannelConfigurationProto()
    with pytest.raises(FrogmlException) as exc_info:
        ChannelConfiguration.from_proto(proto)
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Got unsupported channel type",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="Parse Channel Configuration",
    )


def test_channel_invalid_name_raises() -> None:
    with pytest.raises(FrogmlException) as exc_info:
        Channel(name="InvalidUpperCase", channel_conf=SlackChannel(api_url="http://u"))
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Channel name is limited to lower case letters and numbers",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="Validate Channel Name",
    )


def test_pagerduty_channel_both_keys_missing_raises() -> None:
    with pytest.raises(FrogmlException) as exc_info:
        PagerDutyChannel(url="http://pd", routing_key=None, service_key=None)
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Routing and service key are mutually exclusive",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="Validate PagerDuty Channel",
    )


def test_pagerduty_channel_both_keys_present_raises() -> None:
    with pytest.raises(FrogmlException) as exc_info:
        PagerDutyChannel(
            url="http://pd",
            routing_key="rk",
            service_key="sk",
        )
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Routing and service key are mutually exclusive",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="Validate PagerDuty Channel",
    )
