from http import HTTPStatus
from unittest.mock import MagicMock

import grpc
import pytest

from frogml._proto.qwak.automation.v1.action_pb2 import (
    Action,
    BuildAndDeployAction,
    BuildSpec,
    GitModelSource,
)
from frogml._proto.qwak.automation.v1.automation_pb2 import Automation, AutomationSpec
from frogml._proto.qwak.automation.v1.notification_pb2 import (
    CustomWebhook,
    HttpMethodType,
    Notification,
)
from frogml.core.automations.automation_executions import (
    ExecutionRunDetails,
    ExecutionStatus,
)
from frogml.core.clients.automation_management.client import AutomationsManagementClient
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
    create_grpc_error,
)

# noinspection PyUnresolvedReferences
# from frogml_services_mock import (  # F5
#     frogml_services_mock,
# )


def test_register_automation(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    automation_client = AutomationsManagementClient()
    model_id = "test_model_id"
    name = "automation_name"
    ssh_secret_name = "ssh_secret_name"
    automation_spec = AutomationSpec(
        model_id=model_id,
        automation_name=name,
        action=Action(
            build_deploy=BuildAndDeployAction(
                build_spec=BuildSpec(
                    git_model_source=GitModelSource(git_ssh_secret_name=ssh_secret_name)
                )
            )
        ),
    )
    automation = Automation(automation_spec=automation_spec)

    # When
    automation_id = automation_client.create_automation(automation)

    # Then
    assert type(automation_id) is str
    assert len(frogml_services_mock.automation_management_service_mock.automations) == 1
    saved_automation = (
        frogml_services_mock.automation_management_service_mock.automations[
            automation_id
        ]
    )
    assert saved_automation.automation_spec.automation_name == name
    assert saved_automation.automation_spec.model_id == model_id
    assert saved_automation.automation_spec.is_sdk_v1 is True
    assert (
        saved_automation.automation_spec.action.build_deploy.build_spec.git_model_source.git_ssh_secret_name
        == ssh_secret_name
    )


def test_create_and_print_automation(frogml_services_mock):
    # Given
    automation_client = AutomationsManagementClient()
    model_id = "test_model_id"
    name = "automation_name"
    ssh_secret_name = "ssh_secret_name"
    automation_spec = AutomationSpec(
        model_id=model_id,
        automation_name=name,
        action=Action(
            build_deploy=BuildAndDeployAction(
                build_spec=BuildSpec(
                    git_model_source=GitModelSource(git_ssh_secret_name=ssh_secret_name)
                )
            )
        ),
    )
    automation = Automation(automation_spec=automation_spec)

    # When
    automation_id = automation_client.create_automation(automation)

    # Then
    assert type(automation_id) is str
    assert len(frogml_services_mock.automation_management_service_mock.automations) == 1
    saved_automation = (
        frogml_services_mock.automation_management_service_mock.automations[
            automation_id
        ]
    )
    expected_automation_str = f"""automation_id: "{automation_id}"
automation_spec {{
  model_id: "{model_id}"
  automation_name: "{name}"
  action {{
    build_deploy {{
      build_spec {{
        git_model_source {{
          git_ssh_secret_name: "{ssh_secret_name}"
        }}
      }}
    }}
  }}
  is_sdk_v1: true
}}
qwak_environment_id: "test_environment\"
"""
    assert saved_automation.__str__() == expected_automation_str


def test_update_automation(frogml_services_mock):
    # Given
    automation_client = AutomationsManagementClient()
    first_model_id = "test_model"
    second_model_id = "test_model2"
    name = "automation_name"
    first_automation_spec = AutomationSpec(
        model_id=first_model_id, automation_name=name
    )
    second_automation_spec = AutomationSpec(
        model_id=second_model_id, automation_name=name
    )
    automation = Automation(automation_spec=first_automation_spec)
    automation_id = automation_client.create_automation(automation)

    # When
    automation_client.update_automation(
        automation_id=automation_id,
        automation=Automation(automation_spec=second_automation_spec),
    )

    # Then
    assert len(frogml_services_mock.automation_management_service_mock.automations) == 1
    saved_automation = (
        frogml_services_mock.automation_management_service_mock.automations[
            automation_id
        ]
    )
    assert saved_automation.automation_spec.automation_name == name
    assert saved_automation.automation_spec.model_id == second_model_id
    assert saved_automation.automation_spec.is_sdk_v1 is True


def test_delete_automation(frogml_services_mock):
    # Given
    automation_client = AutomationsManagementClient()
    model_id = "test_model"
    name = "automation_name"
    automation_spec = AutomationSpec(model_id=model_id, automation_name=name)
    automation = Automation(automation_spec=automation_spec)
    automation_id = automation_client.create_automation(automation)
    assert len(frogml_services_mock.automation_management_service_mock.automations) == 1

    # When
    is_deleted = automation_client.delete_automation(automation_id=automation_id)

    # Then
    assert is_deleted is True
    assert len(frogml_services_mock.automation_management_service_mock.automations) == 0


def test_get_automation_by_id(frogml_services_mock):
    # Given
    automation_client = AutomationsManagementClient()
    model_id = "test_model"
    name = "automation_name"
    success_webhook_url = "http://api/v1"
    automation_spec = AutomationSpec(
        model_id=model_id,
        automation_name=name,
        on_success=Notification(
            custom_webhook=CustomWebhook(
                url=success_webhook_url,
                http_method=HttpMethodType.HTTP_METHOD_TYPE_GET,
                data={"k1": "v1"},
                headers={"content-type": "application-json"},
            )
        ),
    )

    automation = Automation(automation_spec=automation_spec)
    automation_id = automation_client.create_automation(automation)
    assert len(frogml_services_mock.automation_management_service_mock.automations) == 1

    # When
    returned_automation = automation_client.get_automation_by_id(
        automation_id=automation_id
    )

    # Then
    assert returned_automation.name == name
    assert returned_automation.model_id == model_id
    assert returned_automation.on_success.url == success_webhook_url
    assert returned_automation.on_success.http_method == "GET"


def test_get_automation_by_name(frogml_services_mock):
    # Given
    automation_client = AutomationsManagementClient()
    model_id = "test_model"
    name = "automation_name"
    automation_spec = AutomationSpec(model_id=model_id, automation_name=name)
    automation = Automation(automation_spec=automation_spec)
    automation_id = automation_client.create_automation(automation)
    assert len(frogml_services_mock.automation_management_service_mock.automations) == 1

    # When
    returned_automation = automation_client.get_automation_by_name(automation_name=name)

    # Then
    assert returned_automation.name == name
    assert returned_automation.model_id == model_id
    assert returned_automation.id == automation_id


def test_list_automations(frogml_services_mock):
    # Given
    automation_client = AutomationsManagementClient()
    model_id1 = "test_model_1"
    model_id2 = "test_model_2"
    name1 = "automation_name_1"
    name2 = "automation_name_2"
    automation_spec1 = AutomationSpec(model_id=model_id1, automation_name=name1)
    automation_spec2 = AutomationSpec(model_id=model_id2, automation_name=name2)
    automation1 = Automation(automation_spec=automation_spec1)
    automation2 = Automation(automation_spec=automation_spec2)
    automation_id1 = automation_client.create_automation(automation1)
    automation_id2 = automation_client.create_automation(automation2)
    assert len(frogml_services_mock.automation_management_service_mock.automations) == 2

    # When
    returned_automations = automation_client.list_automations()

    # Then
    assert len(returned_automations) == 2
    first_automation = list(
        filter(lambda a: a.id == automation_id1, returned_automations)
    )
    second_automation = list(
        filter(lambda a: a.id == automation_id2, returned_automations)
    )
    assert first_automation
    assert second_automation
    assert first_automation[0].id == automation_id1
    assert first_automation[0].name == name1
    assert first_automation[0].model_id == model_id1
    assert second_automation[0].id == automation_id2
    assert second_automation[0].name == name2
    assert second_automation[0].model_id == model_id2


def test_register_execution(frogml_services_mock):
    # Given
    automation_client = AutomationsManagementClient()
    model_id = "test_model"
    name = "automation_name"
    automation_spec = AutomationSpec(model_id=model_id, automation_name=name)
    automation = Automation(automation_spec=automation_spec)
    automation_id = automation_client.create_automation(automation)

    # When
    execution_id = automation_client.register_execution(automation_id=automation_id)

    # Then
    assert type(execution_id) is str
    assert (
        len(
            frogml_services_mock.automation_management_service_mock.automation_executions
        )
        == 1
    )
    assert (
        len(
            frogml_services_mock.automation_management_service_mock.automation_executions[
                automation_id
            ]
        )
        == 1
    )
    assert (
        frogml_services_mock.automation_management_service_mock.automation_executions[
            automation_id
        ][0].execution_id
        == execution_id
    )


def test_update_execution(frogml_services_mock):
    # Given
    automation_client = AutomationsManagementClient()
    model_id = "test_model"
    name = "automation_name"
    automation_spec = AutomationSpec(model_id=model_id, automation_name=name)
    automation = Automation(automation_spec=automation_spec)
    automation_id = automation_client.create_automation(automation)
    execution_id = automation_client.register_execution(automation_id=automation_id)
    task = "some task"
    status = ExecutionStatus.FAILED

    # When
    automation_client.update_execution(
        execution_id=execution_id,
        run_details=ExecutionRunDetails(task=task, status=status),
    )

    # Then
    assert (
        len(
            frogml_services_mock.automation_management_service_mock.automation_executions
        )
        == 1
    )
    assert (
        len(
            frogml_services_mock.automation_management_service_mock.automation_executions[
                automation_id
            ]
        )
        == 1
    )
    assert (
        frogml_services_mock.automation_management_service_mock.automation_executions[
            automation_id
        ][0].execution_id
        == execution_id
    )
    assert (
        frogml_services_mock.automation_management_service_mock.automation_executions[
            automation_id
        ][0].run_details.status
        == status.value
    )
    assert (
        frogml_services_mock.automation_management_service_mock.automation_executions[
            automation_id
        ][0].run_details.task
        == task
    )


def test_register_execution_not_found_raises_frogml_not_found_exception() -> None:
    client = AutomationsManagementClient(grpc_channel=MagicMock())
    client._service_stub = MagicMock()
    client._service_stub.RegisterAutomationExecution.side_effect = create_grpc_error(
        code=grpc.StatusCode.NOT_FOUND, details="automation not found"
    )
    with pytest.raises(FrogmlException) as exc_info:
        client.register_execution(automation_id="missing_automation_id")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Failed to register automation execution, automation missing_automation_id was not found",
        expected_status_code=HTTPStatus.NOT_FOUND,
        expected_operation="Register Automation Execution",
    )


def test_update_execution_not_found_raises_frogml_not_found_exception() -> None:
    client = AutomationsManagementClient(grpc_channel=MagicMock())
    client._service_stub = MagicMock()
    client._service_stub.UpdateAutomationExecution.side_effect = create_grpc_error(
        code=grpc.StatusCode.NOT_FOUND, details="execution not found"
    )
    with pytest.raises(FrogmlException) as exc_info:
        client.update_execution(
            execution_id="missing_execution_id",
            run_details=ExecutionRunDetails(
                task="task", status=ExecutionStatus.SUCCESSFUL
            ),
        )
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Failed to update automation execution, execution missing_execution_id was not found",
        expected_status_code=HTTPStatus.NOT_FOUND,
        expected_operation="Update Automation Execution",
    )


def test_list_executions_not_found_raises_frogml_not_found_exception() -> None:
    client = AutomationsManagementClient(grpc_channel=MagicMock())
    client._service_stub = MagicMock()
    client._service_stub.ListAutomationExecutions.side_effect = create_grpc_error(
        code=grpc.StatusCode.NOT_FOUND, details="automation not found"
    )
    with pytest.raises(FrogmlException) as exc_info:
        client.list_executions(automation_id="missing_automation_id")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Failed to list executions for automation, automation missing_automation_id was not found",
        expected_status_code=HTTPStatus.NOT_FOUND,
        expected_operation="List Automation Executions",
    )
