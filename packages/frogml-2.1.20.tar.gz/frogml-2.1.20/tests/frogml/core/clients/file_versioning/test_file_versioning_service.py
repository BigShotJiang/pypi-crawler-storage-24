from http import HTTPStatus
from unittest.mock import MagicMock

import grpc
import pytest

from frogml._proto.qwak.file_versioning.file_versioning_pb2 import FileTagSpec
from frogml._proto.qwak.file_versioning.file_versioning_service_pb2 import (
    GetModelFileTagsResponse,
)
from frogml.core.clients.file_versioning.client import FileVersioningManagementClient
from frogml.core.exceptions import FrogmlException
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
    create_grpc_error,
)


def test_register_file_tag(frogml_services_mock):
    # Given
    client = FileVersioningManagementClient()
    model_id = "model_id"
    build_id = "build_id"
    tag = "file_tag"
    extension = "log"
    file_path = f"/local/file/path.{extension}"

    # When
    client.register_file_tag(model_id, tag, file_path, build_id)

    # Then
    assert build_id in frogml_services_mock.file_versioning_service_mock.tags
    assert len(frogml_services_mock.file_versioning_service_mock.tags[build_id]) == 1
    file_spec: FileTagSpec = frogml_services_mock.file_versioning_service_mock.tags[
        build_id
    ][0]
    assert tag == file_spec.tag
    assert build_id == file_spec.build_id
    assert extension == file_spec.extension_type


def test_get_model_file_tags(frogml_services_mock):
    # Given
    client = FileVersioningManagementClient()
    model_id = "model_id"
    build_id = "build_id"
    tag_1 = "file_tag_1"
    tag_2 = "file_tag_2"
    extension = "log"
    file_path = f"/local/file/path.{extension}"

    client.register_file_tag(model_id, tag_1, file_path, build_id)
    client.register_file_tag(model_id, tag_2, file_path, build_id)

    # When
    model_file_tags: GetModelFileTagsResponse = client.get_model_file_tags(
        model_id, build_id
    )

    # Then
    assert len(model_file_tags.file_tags) == 2
    for x in model_file_tags.file_tags:
        assert x.model_id == model_id
        assert x.build_id == build_id
        assert x.extension_type == extension


def test_register_file_tag_already_exists_re_raises() -> None:
    client = FileVersioningManagementClient()
    client._file_management_service = MagicMock()
    grpc_error = create_grpc_error(
        code=grpc.StatusCode.ALREADY_EXISTS,
        details="tag already exists",
    )
    client._file_management_service.RegisterFileTag = MagicMock(
        side_effect=grpc_error,
    )

    with pytest.raises(grpc.RpcError) as exc:
        client.register_file_tag("model_id", "tag", "/path/to/file.log", "build_id")

    assert exc.value.code() == grpc.StatusCode.ALREADY_EXISTS


def test_register_file_tag_non_already_exists_error_raises_frogml_exception() -> None:
    client = FileVersioningManagementClient()
    client._file_management_service = MagicMock()
    client._file_management_service.RegisterFileTag = MagicMock(
        side_effect=create_grpc_error(
            code=grpc.StatusCode.INTERNAL,
            details="server error",
        )
    )

    with pytest.raises(FrogmlException) as exc:
        client.register_file_tag("model_id", "my_tag", "/path/to/file.log", "build_id")

    assert_frogml_exception(
        exc.value,
        expected_error_message="Failed to register file tag 'my_tag'",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Register File Tag",
    )
