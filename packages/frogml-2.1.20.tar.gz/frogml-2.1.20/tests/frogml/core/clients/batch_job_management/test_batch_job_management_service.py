from http import HTTPStatus
from unittest import mock

import pytest

from frogml._proto.qwak.batch_job.v1.batch_job_service_pb2 import (
    BatchJobDataDetails,
    BatchJobDeploymentSize,
    BatchJobDestinationPath,
    BatchJobExecutionDetails,
    BatchJobModelDetails,
    BatchJobRequest,
    BatchJobSourcePath,
    CancelWarmupJobResponse,
    InputFileType,
    OutputFileType,
    StartBatchJobResponse,
    StartWarmupJobResponse,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import GpuType
from frogml.core.clients.batch_job_management import BatchJobManagerClient
from frogml.core.clients.batch_job_management.executions_config import ExecutionConfig
from frogml.core.clients.batch_job_management.results import (
    CancelExecutionResult,
    ExecutionStatusResult,
    GetExecutionReportResult,
    StartExecutionResult,
)
from frogml.core.clients.logging_client import LoggingClient
from frogml.core.exceptions import FrogmlException
from tests.frogml.core.utils.frogml_exception_helpers import create_grpc_error
from tests.frogml.core.utils.frogml_exception_helpers import (
    GrpcErrorTestCase,
    assert_frogml_exception,
)
from tests.frogml.core.utils.test_create_model_verify_patched import setup_mock_model


def test_start_execution(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)
    start_result: StartExecutionResult = client.start_execution(
        execution_config=get_batch_job_execution_config(model_id)
    )
    assert start_result.success
    execution_id = start_result.execution_id

    assert (
        execution_id in frogml_services_mock.batch_job_manager_service.id_to_batch_job
    )


def test_start_execution_with_credentials(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)
    execution_config = get_batch_job_execution_config_with_cred(model_id)
    start_result: StartExecutionResult = client.start_execution(
        execution_config=execution_config
    )
    assert start_result.success
    execution_id = start_result.execution_id

    assert (
        execution_id in frogml_services_mock.batch_job_manager_service.id_to_batch_job
    )


def test_start_execution_with_non_existing_purchase_option(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)
    execution_config = get_batch_job_execution_config(model_id)
    execution_config.advanced_options.purchase_option = "non_existing_purchase_option"

    with pytest.raises(Exception) as exc:
        client.start_execution(execution_config=execution_config)

    assert "Invalid purchase option" in str(exc.value)


def test_start_execution_with_existing_purchase_option(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)
    execution_config = get_batch_job_execution_config(model_id)
    execution_config.advanced_options.purchase_option = "spot"
    start_result: StartExecutionResult = client.start_execution(
        execution_config=execution_config
    )

    assert start_result.success
    execution_id = start_result.execution_id

    assert (
        execution_id in frogml_services_mock.batch_job_manager_service.id_to_batch_job
    )
    assert (
        execution_config.advanced_options.purchase_option
        == frogml_services_mock.batch_job_manager_service.id_to_batch_job.get(
            execution_id
        ).start_request.batch_job_request.execution_details.advanced_deployment_options.purchase_option
    )

    assert (
        execution_config.advanced_options.service_account_key_secret_name
        == frogml_services_mock.batch_job_manager_service.id_to_batch_job.get(
            execution_id
        ).start_request.batch_job_request.execution_details.advanced_deployment_options.service_account_key_secret_name
    )


def test_start_execution_with_on_demand_purchase_option(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)
    execution_config = get_batch_job_execution_config(model_id)
    execution_config.advanced_options.purchase_option = "on-demand"
    start_result: StartExecutionResult = client.start_execution(
        execution_config=execution_config
    )
    assert start_result.success
    execution_id = start_result.execution_id

    assert (
        execution_id in frogml_services_mock.batch_job_manager_service.id_to_batch_job
    )
    assert (
        "ondemand"
        == frogml_services_mock.batch_job_manager_service.id_to_batch_job.get(
            execution_id
        ).start_request.batch_job_request.execution_details.advanced_deployment_options.purchase_option
    )


def test_start_batch_job_execution(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"

    start_result: StartBatchJobResponse = client._start_batch_job(
        batch_job_request=get_start_batch_job_request(model_id)
    )

    assert start_result.success
    execution_id = start_result.batch_id

    assert (
        execution_id in frogml_services_mock.batch_job_manager_service.id_to_batch_job
    )


def test_start_execution_failure(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "fail_model_id"
    frogml_services_mock.batch_job_manager_service.models_to_fail.add(model_id)
    setup_mock_model(frogml_services_mock, model_id)
    start_result: StartExecutionResult = client.start_execution(
        execution_config=get_batch_job_execution_config(model_id)
    )
    assert not start_result.success
    assert len(start_result.failure_message) > 1


def test_get_batch_job_status(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)
    start_result: StartExecutionResult = client.start_execution(
        execution_config=get_batch_job_execution_config(model_id)
    )
    job_id = start_result.execution_id
    status_result: ExecutionStatusResult = client.get_execution_status(
        execution_id=job_id
    )
    assert status_result.success
    assert status_result.status == "BATCH_JOB_PENDING_STATUS"


def test_cancel_batch_job(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)
    start_result: StartExecutionResult = client.start_execution(
        execution_config=get_batch_job_execution_config(model_id)
    )
    job_id = start_result.execution_id
    cancel_result: CancelExecutionResult = client.cancel_execution(execution_id=job_id)
    assert cancel_result.success
    assert not cancel_result.failure_message

    status_result: ExecutionStatusResult = client.get_execution_status(
        execution_id=job_id
    )
    assert status_result.success
    assert status_result.status == "BATCH_JOB_CANCELLED_STATUS"


def test_start_warmup_job(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)
    start_result: StartWarmupJobResponse = client.start_warmup_job(
        execution_config=get_batch_job_execution_config(model_id)
    )
    assert start_result.success
    assert not start_result.failure_message
    assert (
        model_id
        in frogml_services_mock.batch_job_manager_service.model_id_active_warmup
    )


def test_cancel_warmup_job(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)
    client.start_warmup_job(execution_config=get_batch_job_execution_config(model_id))
    cancel_response: CancelWarmupJobResponse = client.cancel_warmup(
        execution_config=get_batch_job_execution_config(model_id)
    )
    assert cancel_response.success
    assert not cancel_response.failure_message


def test_cancel_warmup_job_without_start(frogml_services_mock):
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)
    cancel_response: CancelWarmupJobResponse = client.cancel_warmup(
        execution_config=get_batch_job_execution_config(model_id)
    )
    assert cancel_response.success
    assert not cancel_response.failure_message


def test_get_batch_job_report(frogml_services_mock):
    logging_client = LoggingClient(
        endpoint_url=f"localhost:{frogml_services_mock.port}", enable_ssl=False
    )
    client = BatchJobManagerClient(logging_client=logging_client)
    model_id = "model_id"
    model_group_name = "model_group_name"
    report_messages = ["report line 1", "report line 2", "report line 3"]
    setup_mock_model(frogml_services_mock, model_id)
    start_result: StartExecutionResult = client.start_execution(
        execution_config=get_batch_job_execution_config(model_id)
    )
    execution_id = start_result.execution_id
    frogml_services_mock.batch_job_manager_service.id_to_batch_job[
        execution_id
    ].add_report_messages(report_messages)
    report_result: GetExecutionReportResult = client.get_execution_report(
        execution_id=execution_id,
        model_id=model_id,
        model_group_name=model_group_name,
    )
    assert report_result.success
    for record in report_result.records:
        assert record in report_messages


def get_batch_job_execution_config(model_id: str) -> ExecutionConfig:
    return ExecutionConfig(
        execution=ExecutionConfig.Execution(
            model_id=model_id,
            build_id="build_id",
            branch="branch",
            bucket="bucket",
            source_folder="source_folder",
            destination_folder="destination_folder",
            input_file_type="csv",
            output_file_type="csv",
        ),
        resources=ExecutionConfig.Resources(pods=2, cpus=4, memory=512),
        advanced_options=ExecutionConfig.AdvancedOptions(
            custom_iam_role_arn="custom_role",
            service_account_key_secret_name="service_account_key_secret_name",
        ),
        warmup=ExecutionConfig.Warmup(),
    )


def get_batch_job_execution_config_with_cred(model_id: str) -> ExecutionConfig:
    """
    Creates an ExecutionConfig with AWS credentials for testing batch job execution with authentication.

    Args:
        model_id: The model ID to use for the batch job execution

    Returns:
        ExecutionConfig configured with test AWS credentials including:
        - access_token_name: Secret name for AWS access key ID
        - access_secret_name: Secret name for AWS secret access key
        - session_token: AWS session token for temporary credentials
    """
    return ExecutionConfig(
        execution=ExecutionConfig.Execution(
            model_id=model_id,
            build_id="build_id",
            branch="branch",
            bucket="bucket",
            source_folder="source_folder",
            destination_folder="destination_folder",
            input_file_type="csv",
            output_file_type="csv",
            access_token_name="access_token_name",
            access_secret_name="access_secret_name",
            session_token="session_token",
        ),
        resources=ExecutionConfig.Resources(pods=2, cpus=4, memory=512),
        advanced_options=ExecutionConfig.AdvancedOptions(
            custom_iam_role_arn="custom_role",
            service_account_key_secret_name="service_account_key_secret_name",
        ),
        warmup=ExecutionConfig.Warmup(),
    )


def test_get_batch_deployment_size_from_resources_cpu():
    # Given
    cpus = 14.0
    memory_amount = 515
    execution_config = ExecutionConfig(
        resources=ExecutionConfig.Resources(pods=1, cpus=cpus, memory=memory_amount)
    )

    # When
    result = BatchJobManagerClient.get_batch_deployment_size_from_resources(
        execution_config
    )

    # Then
    assert result.client_pod_compute_resources.cpu_resources.cpu == cpus
    assert (
        result.client_pod_compute_resources.cpu_resources.memory_amount == memory_amount
    )


def test_get_batch_deployment_size_from_resources_gpu():
    # Given
    gpu = 14
    execution_config = ExecutionConfig(
        resources=ExecutionConfig.Resources(
            pods=1, gpu_amount=gpu, gpu_type="NVIDIA_K80"
        )
    )

    # When
    result = BatchJobManagerClient.get_batch_deployment_size_from_resources(
        execution_config
    )

    # Then
    assert result.client_pod_compute_resources.gpu_resources.gpu_amount == gpu
    assert (
        result.client_pod_compute_resources.gpu_resources.gpu_type == GpuType.NVIDIA_K80
    )


def test_get_batch_deployment_size_from_resources_instance():
    # Given
    template_id = "small"
    execution_config = ExecutionConfig(
        resources=ExecutionConfig.Resources(pods=1, instance_size=template_id)
    )

    # When
    result = BatchJobManagerClient.get_batch_deployment_size_from_resources(
        execution_config
    )

    # Then
    assert result.client_pod_compute_resources.template_spec.template_id == template_id


def test_update_task_details(frogml_services_mock):
    # Given
    client = BatchJobManagerClient()
    task_id = "task_1"
    input_file_paths = ["/path/to/file1", "/path/to/file2"]

    # When
    client.update_task_details(task_id, input_file_paths)

    # Then
    task_details = frogml_services_mock.batch_job_manager_service.get_task_details(
        task_id
    )
    assert task_details is not None
    assert len(task_details.input_files_details) == len(input_file_paths)
    assert task_details.input_files_details[0].path == input_file_paths[0]
    assert task_details.input_files_details[1].path == input_file_paths[1]
    assert task_details.task_id == task_id


def test_update_task_details_when_service_throw_exception(frogml_services_mock):

    # Given
    client = BatchJobManagerClient()
    task_id = ""
    input_file_paths = ["/path/to/file1", "/path/to/file2"]

    # When + Then
    with pytest.raises(
        FrogmlException,
        match=f"Failed to update task details for task '{task_id}':",
    ):
        client.update_task_details(task_id, input_file_paths)


def get_test_case_id(test_case: GrpcErrorTestCase) -> str:
    return test_case.test_name


GRPC_ERROR_TEST_CASES: list[GrpcErrorTestCase] = [
    GrpcErrorTestCase(
        test_name="get_execution_status",
        method_name="GetBatchJobStatus",
        client_method="get_execution_status",
        client_kwargs={"execution_id": "test_id"},
        expected_error_msg="Failed to get execution status",
        expected_operation="Get Batch Execution Status",
    ),
    GrpcErrorTestCase(
        test_name="cancel_execution",
        method_name="CancelBatchJob",
        client_method="cancel_execution",
        client_kwargs={"execution_id": "test_id"},
        expected_error_msg="Failed to cancel execution",
        expected_operation="Cancel Batch Execution",
    ),
    GrpcErrorTestCase(
        test_name="get_upload_details",
        method_name="GetBatchJobUploadDetails",
        client_method="get_upload_details",
        client_kwargs={"model_id": "test_model_id"},
        expected_error_msg="Failed to get upload details",
        expected_operation="Get Batch Upload Details",
    ),
    GrpcErrorTestCase(
        test_name="get_download_details",
        method_name="GetBatchJobDownloadDetails",
        client_method="get_download_details",
        client_kwargs={"execution_id": "test_execution_id"},
        expected_error_msg="Failed to get download details",
        expected_operation="Get Batch Download Details",
    ),
    GrpcErrorTestCase(
        test_name="list_batch_jobs",
        method_name="ListBatchJobs",
        client_method="list_batch_jobs",
        client_kwargs={"model_id": "test_model_id", "build_id": "test_build_id"},
        expected_error_msg="Failed to list batch jobs",
        expected_operation="List Batch Jobs",
    ),
    GrpcErrorTestCase(
        test_name="get_batch_job_details",
        method_name="GetBatchJobDetails",
        client_method="get_batch_job_details",
        client_kwargs={"job_id": "test_job_id"},
        expected_error_msg="Failed to get batch job details",
        expected_operation="Get Batch Job Details",
    ),
]


@pytest.mark.parametrize("test_case", GRPC_ERROR_TEST_CASES, ids=get_test_case_id)
@mock.patch(
    "frogml.core.clients.batch_job_management.client.BatchJobManagementServiceStub"
)
def test_client_method_when_grpc_error_raises_frogml_exception(
    mock_stub: mock.MagicMock, frogml_services_mock, test_case: GrpcErrorTestCase
):
    """
    Verifies that gRPC errors are properly caught and converted to FrogmlException
    with correct error message, status code, and operation name.
    """
    # Configure the mock stub to raise a gRPC error when the method is called
    stub_method = getattr(mock_stub.return_value, test_case.method_name)
    stub_method.side_effect = create_grpc_error()

    client = BatchJobManagerClient()
    client_method = getattr(client, test_case.client_method)

    with pytest.raises(FrogmlException) as exc:
        client_method(**test_case.client_kwargs)

    assert_frogml_exception(
        exc.value,
        expected_error_message=test_case.expected_error_msg,
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation=test_case.expected_operation,
    )


@mock.patch(
    "frogml.core.clients.batch_job_management.client.BatchJobManagementServiceStub"
)
def test_start_warmup_job_when_grpc_error_raises_frogml_exception(
    mock_stub: mock.MagicMock, frogml_services_mock
):
    mock_stub.return_value.StartWarmupJob.side_effect = create_grpc_error()
    client = BatchJobManagerClient()
    model_id = "model_id"
    setup_mock_model(frogml_services_mock, model_id)

    with pytest.raises(FrogmlException) as exc:
        client.start_warmup_job(
            execution_config=get_batch_job_execution_config(model_id)
        )

    assert_frogml_exception(
        exc.value,
        expected_error_message="Failed to start warmup",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Start Batch Warmup Job",
    )


def get_start_batch_job_request(model_id: str) -> BatchJobRequest:
    return BatchJobRequest(
        model_details=BatchJobModelDetails(
            model_id=model_id,
            build_id="build_id",
        ),
        data_details=BatchJobDataDetails(
            source_path=BatchJobSourcePath(
                source_folder="source_folder",
                source_bucket="bucket",
                input_file_type=InputFileType.CSV_INPUT_FILE_TYPE,
            ),
            destination_path=BatchJobDestinationPath(
                destination_bucket="bucket",
                destination_folder="destination_folder",
                output_file_type=OutputFileType.CSV_OUTPUT_FILE_TYPE,
            ),
            token_secret="token_secret",
            secret_secret="secret_secret",
            session_token="session_token",
        ),
        execution_details=BatchJobExecutionDetails(
            job_timeout=2,
            task_timeout=3,
            batch_job_deployment_size=BatchJobDeploymentSize(
                cpu=2,
                memory_amount=2,
                memory_units=BatchJobDeploymentSize.MemoryUnit.MIB,
            ),
        ),
    )
