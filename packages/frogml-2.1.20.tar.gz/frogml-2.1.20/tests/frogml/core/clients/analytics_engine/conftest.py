import grpc
import pytest
from frogml.core.clients.analytics.client import AnalyticsEngineClient


@pytest.fixture
def analytics_engine_client(frogml_services_mock) -> AnalyticsEngineClient:
    port = frogml_services_mock.port
    channel = grpc.insecure_channel(f"localhost: {port}")
    return AnalyticsEngineClient(grpc_channel=channel)
