from datetime import timedelta

import pytest
from frogml.core.clients.analytics.client import (
    AnalyticsEngineClient,
    AnalyticsEngineError,
)
from frogml.core.exceptions.frogml_exception import FrogmlException
from frogml._proto.qwak.service_discovery.service_discovery_location_pb2 import (
    ServiceLocationDescriptor,
)
from frogml_services_mock.mocks.analytics_api import (
    CANCELLED_QUERY,
    DOWNLOAD_URL,
    FAILED_QUERY,
    SUCCESSFUL_QUERY,
    TIMEOUT_QUERY,
)


def test_get_error_when_query_fails(analytics_engine_client):
    with pytest.raises(AnalyticsEngineError):
        analytics_engine_client.get_analytics_data(FAILED_QUERY)


def test_get_timeout_error_when_query_times_out(analytics_engine_client):
    with pytest.raises(TimeoutError):
        analytics_engine_client.get_analytics_data(TIMEOUT_QUERY, timedelta(seconds=1))


def test_get_error_when_query_cancelled(analytics_engine_client):
    with pytest.raises(AnalyticsEngineError):
        analytics_engine_client.get_analytics_data(CANCELLED_QUERY)


def test_get_dataframe_when_query_succeeds(analytics_engine_client):
    result = analytics_engine_client.get_analytics_data(SUCCESSFUL_QUERY)

    assert result == DOWNLOAD_URL


def test_create_grpc_client_with_invalid_url(frogml_services_mock):
    frogml_services_mock.location_discovery_service.set_get_analytics_engine_url_response(
        ServiceLocationDescriptor(service_url="")
    )
    with pytest.raises(FrogmlException):
        AnalyticsEngineClient()
