from http import HTTPStatus
from unittest.mock import MagicMock

import grpc
import pytest

from frogml._proto.qwak.data_versioning.data_versioning_pb2 import DataTagSpec
from frogml._proto.qwak.data_versioning.data_versioning_service_pb2 import (
    GetModelDataTagsResponse,
)
from frogml.core.clients.data_versioning.client import DataVersioningManagementClient
from frogml.core.exceptions import FrogmlException
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
    create_grpc_error,
)


def test_register_data_tag(frogml_services_mock):
    # Given
    client = DataVersioningManagementClient()
    build_id = "build_id"
    model_id = "model_id"
    tag = "data_tag"
    extension = "log"

    # When
    client.register_data_tag(model_id, tag, build_id, extension)

    # Then
    assert build_id in frogml_services_mock.data_versioning_service_mock.tags
    assert len(frogml_services_mock.data_versioning_service_mock.tags[build_id]) == 1
    data_spec: DataTagSpec = frogml_services_mock.data_versioning_service_mock.tags[
        build_id
    ][0]
    assert tag == data_spec.tag
    assert build_id == data_spec.build_id
    assert extension == data_spec.extension_type


def test_get_model_data_tags(frogml_services_mock):
    # Given
    client = DataVersioningManagementClient()
    model_id = "model_id"
    build_id = "build_id"
    tag_1 = "data_tag_1"
    tag_2 = "data_tag_2"
    extension = "log"

    client.register_data_tag(model_id, tag_1, build_id, extension)
    client.register_data_tag(model_id, tag_2, build_id, extension)

    # When
    model_data_tags: GetModelDataTagsResponse = client.get_model_data_tags(
        model_id, build_id
    )

    # Then
    assert len(model_data_tags.data_tags) == 2
    for x in model_data_tags.data_tags:
        assert x.model_id == model_id
        assert x.build_id == build_id
        assert x.extension_type == extension


def test_register_data_tag_already_exists_is_silently_ignored() -> None:
    client = DataVersioningManagementClient()
    client._data_management_service = MagicMock()
    client._data_management_service.RegisterDataTag = MagicMock(
        side_effect=create_grpc_error(
            code=grpc.StatusCode.ALREADY_EXISTS,
            details="tag already exists",
        )
    )

    client.register_data_tag("model_id", "tag", "build_id", "log")


def test_register_data_tag_non_already_exists_error_raises_frogml_exception() -> None:
    client = DataVersioningManagementClient()
    client._data_management_service = MagicMock()
    client._data_management_service.RegisterDataTag = MagicMock(
        side_effect=create_grpc_error(
            code=grpc.StatusCode.INTERNAL,
            details="server error",
        )
    )

    with pytest.raises(FrogmlException) as exc:
        client.register_data_tag("model_id", "my_tag", "build_id", "log")

    assert_frogml_exception(
        exc.value,
        expected_error_message="Failed to register data tag 'my_tag'",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Register Data Tag",
    )
