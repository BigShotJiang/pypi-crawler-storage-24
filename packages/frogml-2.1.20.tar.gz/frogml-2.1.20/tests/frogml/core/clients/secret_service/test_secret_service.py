from http import HTTPStatus
from unittest.mock import MagicMock

import grpc
import pytest

from frogml.core.clients.secret_service import SecretServiceClient
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
    create_grpc_error,
)


def test_create_secret(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    client = SecretServiceClient(
        edge_services_url=f"localhost:{frogml_services_mock.port}", enable_ssl=False
    )
    secret_name = "secret_name"
    secret_value = "secret_value"
    client.set_secret(secret_name, secret_value)

    # When
    value = client.get_secret(secret_name)

    # Then
    assert value == secret_value


def test_get_secret_returns_value() -> None:
    client = SecretServiceClient(grpc_channel=MagicMock())
    client._secret_service = MagicMock()
    client._secret_service.GetSecret.return_value = MagicMock(value="my_secret")
    assert client.get_secret("my_name") == "my_secret"
    client._secret_service.GetSecret.assert_called_once()


def test_get_secret_not_found_raises_frogml_not_found_exception() -> None:
    client = SecretServiceClient(grpc_channel=MagicMock())
    client._secret_service = MagicMock()
    client._secret_service.GetSecret.side_effect = create_grpc_error(
        code=grpc.StatusCode.NOT_FOUND, details="secret not found"
    )
    with pytest.raises(FrogmlException) as exc_info:
        client.get_secret("missing_secret")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Secret 'missing_secret' not found",
        expected_status_code=HTTPStatus.NOT_FOUND,
        expected_operation="Get Secret",
    )


def test_get_secret_other_grpc_error_raises_frogml_exception() -> None:
    client = SecretServiceClient(grpc_channel=MagicMock())
    client._secret_service = MagicMock()
    client._secret_service.GetSecret.side_effect = create_grpc_error(
        code=grpc.StatusCode.INTERNAL, details="backend error"
    )
    with pytest.raises(FrogmlException) as exc_info:
        client.get_secret("some_secret")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Failed to get secret 'some_secret': backend error",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Get Secret",
    )
