from http import HTTPStatus
from typing import Any
from unittest.mock import MagicMock, patch
from uuid import uuid4

import pytest
from frogml._proto.qwak.logging.log_line_pb2 import LogLine
from frogml._proto.qwak.logging.log_reader_service_pb2 import ReadLogsResponse
from frogml._proto.qwak.logging.log_source_pb2 import (
    InferenceExecutionSource,
    ModelRuntimeSource,
    RemoteBuildSource,
)
from frogml.core.clients.logging_client import LoggingClient
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.logging_service import MockLogLine
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
)


@pytest.fixture()
def execution_id() -> str:
    return str(uuid4())


@pytest.fixture()
def model_id() -> str:
    return "model_id"


@pytest.fixture()
def model_group_name() -> str:
    return "model_group_name"


@pytest.fixture()
def deployment_id() -> str:
    return str(uuid4())


@pytest.fixture()
def build_id() -> str:
    return str(uuid4())


FIRST_LOG_LINE = "First Test log line"
SECOND_LOG_LINE = "Second Test log line"


def test_read_logs(frogml_services_mock, deployment_id: str) -> None:
    # Given
    metadata = {"deployment_id": deployment_id}

    frogml_services_mock.logging_service_mock.add_mock_logs(
        source=ModelRuntimeSource(),
        rows=__create_mocked_logs(metadata, [FIRST_LOG_LINE, SECOND_LOG_LINE]),
    )

    client = LoggingClient(
        endpoint_url=f"localhost:{frogml_services_mock.port}", enable_ssl=False
    )

    # When
    response: ReadLogsResponse = client.read_model_runtime_logs(
        deployment_id=deployment_id,
        before_offset=None,
        after_offset=None,
        max_number_of_results=None,
        log_text_filter=None,
    )

    # Then
    assert response.log_line[0].text == FIRST_LOG_LINE
    assert response.log_line[1].text == SECOND_LOG_LINE


def test_read_build_logs(
    frogml_services_mock, build_id: str, model_id: str, model_group_name: str
) -> None:
    # Given
    metadata = {"build_id": build_id}

    frogml_services_mock.logging_service_mock.add_mock_logs(
        source=RemoteBuildSource(),
        rows=__create_mocked_logs(metadata, [FIRST_LOG_LINE, SECOND_LOG_LINE]),
    )

    client = LoggingClient(
        endpoint_url=f"localhost:{frogml_services_mock.port}", enable_ssl=False
    )

    # When
    response: ReadLogsResponse = client.read_build_logs(
        build_id=build_id,
        before_offset=None,
        after_offset=None,
        max_number_of_results=None,
        log_text_filter=None,
        model_id=model_id,
        model_group_name=model_group_name,
    )

    # Then
    assert response.log_line[0].text == FIRST_LOG_LINE
    assert response.log_line[1].text == SECOND_LOG_LINE


def test_read_model_runtime_logs(
    frogml_services_mock, deployment_id: str, model_id: str, model_group_name: str
) -> None:
    # Given
    metadata = {"deployment_id": deployment_id}

    frogml_services_mock.logging_service_mock.add_mock_logs(
        source=ModelRuntimeSource(),
        rows=__create_mocked_logs(metadata, [FIRST_LOG_LINE, SECOND_LOG_LINE]),
    )

    client = LoggingClient(
        endpoint_url=f"localhost:{frogml_services_mock.port}", enable_ssl=False
    )

    # When
    response: ReadLogsResponse = client.read_model_runtime_logs(
        deployment_id=deployment_id,
        before_offset=None,
        after_offset=None,
        max_number_of_results=None,
        log_text_filter=None,
        model_id=model_id,
        model_group_name=model_group_name,
    )

    # Then
    assert response.log_line[0].text == FIRST_LOG_LINE
    assert response.log_line[1].text == SECOND_LOG_LINE


def test_read_execution_logs(
    frogml_services_mock, execution_id: str, model_id: str, model_group_name: str
) -> None:
    # Given
    metadata = {"inference_job_id": execution_id}

    frogml_services_mock.logging_service_mock.add_mock_logs(
        source=InferenceExecutionSource(),
        rows=__create_mocked_logs(metadata, [FIRST_LOG_LINE, SECOND_LOG_LINE]),
    )

    client = LoggingClient(
        endpoint_url=f"localhost:{frogml_services_mock.port}", enable_ssl=False
    )

    # When
    response: ReadLogsResponse = client.read_execution_models_logs(
        execution_id=execution_id,
        before_offset=None,
        after_offset=None,
        max_number_of_results=None,
        log_text_filter=None,
        model_id=model_id,
        model_group_name=model_group_name,
    )

    # Then
    assert response.log_line[0].text == FIRST_LOG_LINE
    assert response.log_line[1].text == SECOND_LOG_LINE


def test_read_build_logs_frogml_exception_reraises_with_context() -> None:
    with patch(
        "frogml.core.clients.logging_client.client.create_grpc_channel",
        return_value=MagicMock(),
    ):
        client = LoggingClient(endpoint_url="http://localhost:9999", enable_ssl=False)
    client.read_logs = MagicMock(side_effect=FrogmlException("inner read_logs error"))
    with pytest.raises(FrogmlException) as exc_info:
        client.read_build_logs(build_id="bid")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Failed to fetch build logs",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Read Build Logs",
    )


def test_read_model_runtime_logs_frogml_exception_reraises_with_context() -> None:
    with patch(
        "frogml.core.clients.logging_client.client.create_grpc_channel",
        return_value=MagicMock(),
    ):
        client = LoggingClient(endpoint_url="http://localhost:9999", enable_ssl=False)
    client.read_logs = MagicMock(side_effect=FrogmlException("inner read_logs error"))
    with pytest.raises(FrogmlException) as exc_info:
        client.read_model_runtime_logs(deployment_id="did")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Failed to fetch runtime logs",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Read Runtime Logs",
    )


def test_read_execution_models_logs_frogml_exception_reraises_with_context() -> None:
    with patch(
        "frogml.core.clients.logging_client.client.create_grpc_channel",
        return_value=MagicMock(),
    ):
        client = LoggingClient(endpoint_url="http://localhost:9999", enable_ssl=False)
    client.read_logs = MagicMock(side_effect=FrogmlException("inner read_logs error"))
    with pytest.raises(FrogmlException) as exc_info:
        client.read_execution_models_logs(execution_id="eid")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Failed to fetch execution logs",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Read Execution Logs",
    )


def test_max_logs(
    frogml_services_mock, execution_id: str, model_id: str, model_group_name: str
) -> None:
    # Given
    metadata = {"inference_job_id": execution_id}

    frogml_services_mock.logging_service_mock.add_mock_logs(
        source=InferenceExecutionSource(),
        rows=__create_mocked_logs(metadata, [FIRST_LOG_LINE, SECOND_LOG_LINE]),
    )

    client = LoggingClient(
        endpoint_url=f"localhost:{frogml_services_mock.port}", enable_ssl=False
    )

    # When
    response: ReadLogsResponse = client.read_execution_models_logs(
        execution_id=execution_id,
        before_offset=None,
        after_offset=None,
        max_number_of_results=1,
        log_text_filter=None,
        model_id=model_id,
        model_group_name=model_group_name,
    )

    # Then
    assert len(response.log_line) == 1
    assert response.has_next_page


def __create_mocked_logs(
    metadata: dict[str, Any], logs: list[str]
) -> list[MockLogLine]:
    return [
        MockLogLine(
            log_line=LogLine(text=log_line, metadata=metadata), metadata=metadata
        )
        for log_line in logs
    ]
