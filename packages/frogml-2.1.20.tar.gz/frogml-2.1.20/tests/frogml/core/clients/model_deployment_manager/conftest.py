import pytest
from frogml.core.clients.model_deployment_manager import ModelDeploymentManagerClient


@pytest.fixture()
def model_deployment_manager_client() -> ModelDeploymentManagerClient:
    return ModelDeploymentManagerClient()
