import uuid

import pytest
from frogml._proto.com.jfrog.ml.model.deployment.v1.deployment_pb2 import (
    Deployment,
    ModelDeploymentInformation,
)
from frogml._proto.com.jfrog.ml.model.deployment.v1.environment_variables_configuration_pb2 import (
    EnvironmentVariable,
    EnvironmentVariablesConfiguration,
    EnvironmentVariableSourceLiteral,
)
from frogml._proto.com.jfrog.ml.model.deployment.v1.model_deployment_brief_pb2 import (
    ModelDeploymentBrief,
)
from frogml._proto.com.jfrog.ml.model.deployment.v1.model_deployment_filter_pb2 import (
    EnvironmentIds,
    ModelDeploymentFilter,
    ModelGroupIds,
    ModelIdentifierFilter,
    ModelIds,
    SimpleModelDeploymentFilter,
)
from frogml._proto.com.jfrog.ml.model.deployment.v1.realtime_deployment_pb2 import (
    RealtimeDeployment,
)
from frogml._proto.com.jfrog.ml.model.deployment.v1.resource_configuration_pb2 import (
    ResourceConfiguration,
)
from frogml.core.clients.model_deployment_manager.client import (
    ModelDeploymentManagerClient,
)
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks
from frogml_services_mock.mocks.model_deployment_manager_service_mock import (
    DeploymentInformation,
)

DEFAULT_MODEL_ID = "test_model"
DEFAULT_MODEL_GROUP_ID = "test_group"
DEFAULT_JFROG_PROJECT_KEY = "test_project"
DEFAULT_IMAGE_PATH = "test/image:latest"
DEFAULT_TEMPLATE_SPEC = "medium"
DEFAULT_API_PATH = "/v1/predict"
DEFAULT_REPLICA_COUNT = 2
DEFAULT_ENV_VAR_NAME = "LOG_LEVEL"
DEFAULT_ENV_VAR_VALUE = "INFO"


def _create_deployment_config(
    template_spec: str = DEFAULT_TEMPLATE_SPEC,
    api_path: str = DEFAULT_API_PATH,
    replica_count: int = DEFAULT_REPLICA_COUNT,
    env_var_name: str = DEFAULT_ENV_VAR_NAME,
    env_var_value: str = DEFAULT_ENV_VAR_VALUE,
) -> Deployment:
    return Deployment(
        resource_configuration=ResourceConfiguration(
            template_specification=template_spec,
        ),
        environment_variables_configuration=EnvironmentVariablesConfiguration(
            environment_variables=[
                EnvironmentVariable(
                    name=env_var_name,
                    literal_value=EnvironmentVariableSourceLiteral(value=env_var_value),
                )
            ]
        ),
        realtime_deployment=RealtimeDeployment(
            exposed_api_path=api_path,
            replica_count=replica_count,
        ),
    )


def _validate_non_duplicate_deployment(
    frogml_services_mock: FrogmlMocks,
    model_id: str,
    model_group_id: str,
    environment_id: str,
) -> None:
    for (
        deployment
    ) in frogml_services_mock.model_deployment_manager_mock.get_all_deployments():
        if (
            deployment.model_id == model_id
            and deployment.model_group_id == model_group_id
            and str(deployment.environment_id) == environment_id
        ):
            raise ValueError(
                f"Deployment already exists for model_id={model_id}, "
                f"model_group_id={model_group_id}, environment_id={environment_id}"
            )


def _given_deployed_model(
    frogml_services_mock: FrogmlMocks,
    client: ModelDeploymentManagerClient = None,
    model_id: str = DEFAULT_MODEL_ID,
    model_group_id: str = DEFAULT_MODEL_GROUP_ID,
    jfrog_project_key: str = DEFAULT_JFROG_PROJECT_KEY,
    image_path: str = DEFAULT_IMAGE_PATH,
    environment_id: str = None,
) -> str:
    """
    Helper to deploy a model and return deployment_id for subsequent tests.
    Uses the mock directly to find the created deployment ID.
    """
    if client is None:
        client = ModelDeploymentManagerClient()
    if environment_id is None:
        environment_id = str(uuid.uuid4())

    _validate_non_duplicate_deployment(
        frogml_services_mock, model_id, model_group_id, environment_id
    )

    deployment_config: Deployment = _create_deployment_config()
    environment_deployment_configuration = {environment_id: deployment_config}

    client.deploy_llm(
        model_id=model_id,
        model_group_id=model_group_id,
        jfrog_project_key=jfrog_project_key,
        image_path=image_path,
        environment_deployment_configuration=environment_deployment_configuration,
    )

    deployments: list[DeploymentInformation] = (
        frogml_services_mock.model_deployment_manager_mock.get_all_deployments()
    )
    for deployment in deployments:
        if (
            deployment.model_id == model_id
            and deployment.model_group_id == model_group_id
            and str(deployment.environment_id) == environment_id
        ):
            return str(deployment.deployment_id)

    raise Exception("Deployment not found after deploy_llm call")


def test_deploy_llm(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
) -> None:
    # Given
    model_id = "test_model"
    model_group_id = "test_group"
    jfrog_project_key = "test_project"
    image_path = "test/image:latest"
    environment_id = str(uuid.uuid4())
    deployment_config: Deployment = _create_deployment_config()

    environment_deployment_configuration = {environment_id: deployment_config}

    # When
    model_deployment_manager_client.deploy_llm(
        model_id=model_id,
        model_group_id=model_group_id,
        jfrog_project_key=jfrog_project_key,
        image_path=image_path,
        environment_deployment_configuration=environment_deployment_configuration,
    )

    # Then
    deployments: list[DeploymentInformation] = (
        frogml_services_mock.model_deployment_manager_mock.get_all_deployments()
    )
    assert len(deployments) == 1
    deployment = deployments[0]
    assert deployment.model_id == model_id
    assert deployment.model_group_id == model_group_id
    assert deployment.jfrog_project_key == jfrog_project_key
    assert deployment.path == image_path
    assert str(deployment.environment_id) == environment_id
    assert (
        deployment.deployment_config.resource_configuration.template_specification
        == DEFAULT_TEMPLATE_SPEC
    )
    assert (
        deployment.deployment_config.realtime_deployment.exposed_api_path
        == DEFAULT_API_PATH
    )
    assert (
        deployment.deployment_config.realtime_deployment.replica_count
        == DEFAULT_REPLICA_COUNT
    )
    assert (
        len(
            deployment.deployment_config.environment_variables_configuration.environment_variables
        )
        == 1
    )
    assert (
        deployment.deployment_config.environment_variables_configuration.environment_variables[
            0
        ].name
        == DEFAULT_ENV_VAR_NAME
    )


def test_deploy_llm_multiple_environments(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    model_id = "test_model"
    model_group_id = "test_group"
    jfrog_project_key = "test_project"
    image_path = "test/image:latest"
    env1 = str(uuid.uuid4())
    env2 = str(uuid.uuid4())
    deployment_config: Deployment = _create_deployment_config()

    environment_deployment_configuration = {
        env1: deployment_config,
        env2: deployment_config,
    }

    # When
    model_deployment_manager_client.deploy_llm(
        model_id=model_id,
        model_group_id=model_group_id,
        jfrog_project_key=jfrog_project_key,
        image_path=image_path,
        environment_deployment_configuration=environment_deployment_configuration,
    )

    # Then
    deployments: list[DeploymentInformation] = (
        frogml_services_mock.model_deployment_manager_mock.get_all_deployments()
    )
    assert len(deployments) == 2

    environment_ids = {str(d.environment_id) for d in deployments}
    assert environment_ids == {env1, env2}

    for deployment in deployments:
        assert deployment.jfrog_project_key == jfrog_project_key


def test_undeploy(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    deployment_id: str = _given_deployed_model(
        frogml_services_mock, client=model_deployment_manager_client
    )

    assert (
        frogml_services_mock.model_deployment_manager_mock.get_deployment_by_id(
            deployment_id
        )
        is not None
    )

    # When
    model_deployment_manager_client.undeploy(deployment_ids=[deployment_id])

    # Then
    assert (
        frogml_services_mock.model_deployment_manager_mock.get_deployment_by_id(
            deployment_id
        )
        is None
    )
    assert (
        len(frogml_services_mock.model_deployment_manager_mock.get_all_deployments())
        == 0
    )


def test_undeploy_multiple(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    deployment_id_1: str = _given_deployed_model(
        frogml_services_mock, client=model_deployment_manager_client
    )
    deployment_id_2: str = _given_deployed_model(
        frogml_services_mock, client=model_deployment_manager_client
    )

    assert (
        len(frogml_services_mock.model_deployment_manager_mock.get_all_deployments())
        == 2
    )

    # When
    model_deployment_manager_client.undeploy(
        deployment_ids=[deployment_id_1, deployment_id_2]
    )

    # Then
    assert (
        len(frogml_services_mock.model_deployment_manager_mock.get_all_deployments())
        == 0
    )


def test_edit_deployments(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    deployment_id: str = _given_deployed_model(
        frogml_services_mock, client=model_deployment_manager_client
    )

    new_template_spec = "large"
    new_api_path = "/v2/chat/completions"
    new_replica_count = 5
    new_deployment_config = _create_deployment_config(
        template_spec=new_template_spec,
        api_path=new_api_path,
        replica_count=new_replica_count,
    )

    # When
    model_deployment_manager_client.edit_deployments(
        deployment_id_to_spec_map={deployment_id: new_deployment_config}
    )

    # Then
    deployment_info = model_deployment_manager_client.get_deployment(
        deployment_id=deployment_id
    )
    assert (
        deployment_info.model_deployment_spec.resource_configuration.template_specification
        == new_template_spec
    )
    assert (
        deployment_info.model_deployment_spec.realtime_deployment.exposed_api_path
        == new_api_path
    )
    assert (
        deployment_info.model_deployment_spec.realtime_deployment.replica_count
        == new_replica_count
    )


def test_list_deployments_no_filter(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    _given_deployed_model(frogml_services_mock, client=model_deployment_manager_client)
    _given_deployed_model(frogml_services_mock, client=model_deployment_manager_client)
    _given_deployed_model(frogml_services_mock, client=model_deployment_manager_client)

    # When
    briefs: list[ModelDeploymentBrief] = (
        model_deployment_manager_client.list_deployments()
    )

    # Then
    assert len(briefs) == 3


def test_list_deployments_with_model_filter(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    model_id_1 = "model_1"
    model_id_2 = "model_2"

    _given_deployed_model(
        frogml_services_mock,
        client=model_deployment_manager_client,
        model_id=model_id_1,
    )
    _given_deployed_model(
        frogml_services_mock,
        client=model_deployment_manager_client,
        model_id=model_id_2,
    )

    model_filter = ModelDeploymentFilter(
        simple_model_deployment_filter=SimpleModelDeploymentFilter(
            model_identifier_filter=ModelIdentifierFilter(
                model_group_id=DEFAULT_MODEL_GROUP_ID,
                model_id=model_id_1,
            )
        )
    )

    # When
    briefs: list[ModelDeploymentBrief] = (
        model_deployment_manager_client.list_deployments(
            model_deployment_filter=model_filter
        )
    )

    # Then
    assert len(briefs) == 1
    assert (
        briefs[0].model_artifact_identifier.model_based_artifact_id.model_id
        == model_id_1
    )


def test_list_deployments_with_environment_filter(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    env1 = str(uuid.uuid4())
    env2 = str(uuid.uuid4())
    env3 = str(uuid.uuid4())

    _given_deployed_model(
        frogml_services_mock,
        client=model_deployment_manager_client,
        environment_id=env1,
    )
    _given_deployed_model(
        frogml_services_mock,
        client=model_deployment_manager_client,
        environment_id=env2,
    )
    _given_deployed_model(
        frogml_services_mock,
        client=model_deployment_manager_client,
        environment_id=env3,
    )

    model_filter = ModelDeploymentFilter(
        simple_model_deployment_filter=SimpleModelDeploymentFilter(
            environment_ids=EnvironmentIds(environment_id=[env1, env2])
        )
    )

    # When
    briefs: list[ModelDeploymentBrief] = (
        model_deployment_manager_client.list_deployments(
            model_deployment_filter=model_filter
        )
    )

    # Then
    assert len(briefs) == 2
    environments = {b.environment for b in briefs}
    assert environments == {env1, env2}


def test_list_deployments_with_model_group_filter(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    group_1 = "group_1"
    group_2 = "group_2"

    _given_deployed_model(
        frogml_services_mock,
        client=model_deployment_manager_client,
        model_group_id=group_1,
    )
    _given_deployed_model(
        frogml_services_mock,
        client=model_deployment_manager_client,
        model_group_id=group_2,
    )

    model_filter = ModelDeploymentFilter(
        simple_model_deployment_filter=SimpleModelDeploymentFilter(
            model_group_ids=ModelGroupIds(model_group_id=[group_1])
        )
    )

    # When
    briefs: list[ModelDeploymentBrief] = (
        model_deployment_manager_client.list_deployments(
            model_deployment_filter=model_filter
        )
    )

    # Then
    assert len(briefs) == 1
    assert (
        briefs[0].model_artifact_identifier.model_based_artifact_id.model_group_id
        == group_1
    )


def test_list_deployments_with_model_ids_filter(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    model_id_1 = "model_1"
    model_id_2 = "model_2"
    model_id_3 = "model_3"

    _given_deployed_model(
        frogml_services_mock,
        client=model_deployment_manager_client,
        model_id=model_id_1,
    )
    _given_deployed_model(
        frogml_services_mock,
        client=model_deployment_manager_client,
        model_id=model_id_2,
    )
    _given_deployed_model(
        frogml_services_mock,
        client=model_deployment_manager_client,
        model_id=model_id_3,
    )

    model_filter = ModelDeploymentFilter(
        simple_model_deployment_filter=SimpleModelDeploymentFilter(
            model_ids=ModelIds(model_id=[model_id_1, model_id_2])
        )
    )

    # When
    briefs: list[ModelDeploymentBrief] = (
        model_deployment_manager_client.list_deployments(
            model_deployment_filter=model_filter
        )
    )

    # Then
    assert len(briefs) == 2
    model_ids = {
        b.model_artifact_identifier.model_based_artifact_id.model_id for b in briefs
    }
    assert model_ids == {model_id_1, model_id_2}


def test_list_deployments_empty(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given - No deployments

    # When
    briefs: list[ModelDeploymentBrief] = (
        model_deployment_manager_client.list_deployments()
    )

    # Then
    assert len(briefs) == 0


def test_get_deployment(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    deployment_id = _given_deployed_model(
        frogml_services_mock, client=model_deployment_manager_client
    )

    # When
    deployment_info: ModelDeploymentInformation = (
        model_deployment_manager_client.get_deployment(deployment_id=deployment_id)
    )

    # Then
    assert deployment_info is not None
    assert deployment_info.model_deployment_metadata.deployment_id == deployment_id
    assert (
        deployment_info.model_artifact_identifier.model_based_artifact_id.model_id
        == DEFAULT_MODEL_ID
    )
    assert (
        deployment_info.model_artifact_identifier.model_based_artifact_id.model_group_id
        == DEFAULT_MODEL_GROUP_ID
    )
    assert (
        deployment_info.model_artifact_identifier.model_based_artifact_id.image_path
        == DEFAULT_IMAGE_PATH
    )
    assert (
        deployment_info.model_deployment_spec.resource_configuration.template_specification
        == DEFAULT_TEMPLATE_SPEC
    )
    assert (
        deployment_info.model_deployment_spec.realtime_deployment.exposed_api_path
        == DEFAULT_API_PATH
    )
    assert (
        deployment_info.model_deployment_spec.realtime_deployment.replica_count
        == DEFAULT_REPLICA_COUNT
    )


def test_full_deployment_lifecycle(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    """Deploy -> List -> Edit -> Get -> Undeploy -> List empty"""
    # Given
    deployment_id: str = _given_deployed_model(
        frogml_services_mock, client=model_deployment_manager_client
    )

    # Then - List and verify deployment exists
    briefs: list[ModelDeploymentBrief] = (
        model_deployment_manager_client.list_deployments()
    )
    assert len(briefs) == 1
    assert briefs[0].deployment_id == deployment_id

    # When - Edit the deployment
    updated_template_spec = "large"
    updated_replica_count = 5
    updated_api_path = "/v1/chat/completions"
    new_config = _create_deployment_config(
        template_spec=updated_template_spec,
        api_path=updated_api_path,
        replica_count=updated_replica_count,
    )
    model_deployment_manager_client.edit_deployments(
        deployment_id_to_spec_map={deployment_id: new_config}
    )

    # Then - Get and verify edited
    deployment_info: ModelDeploymentInformation = (
        model_deployment_manager_client.get_deployment(deployment_id=deployment_id)
    )
    assert deployment_info.model_deployment_metadata.deployment_id == deployment_id
    assert (
        deployment_info.model_deployment_spec.resource_configuration.template_specification
        == updated_template_spec
    )
    assert (
        deployment_info.model_deployment_spec.realtime_deployment.exposed_api_path
        == updated_api_path
    )
    assert (
        deployment_info.model_deployment_spec.realtime_deployment.replica_count
        == updated_replica_count
    )

    # When - Undeploy
    model_deployment_manager_client.undeploy(deployment_ids=[deployment_id])

    # Then - List and verify empty
    briefs: list[ModelDeploymentBrief] = (
        model_deployment_manager_client.list_deployments()
    )
    assert len(briefs) == 0


def test_edit_deployment_non_existent(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    non_existent_deployment_id = str(uuid.uuid4())
    deployment_config: Deployment = _create_deployment_config()

    # When + Then
    with pytest.raises(FrogmlException) as exc_info:
        model_deployment_manager_client.edit_deployments(
            deployment_id_to_spec_map={non_existent_deployment_id: deployment_config}
        )

    assert "Failed to edit deployments" in str(exc_info.value)


def test_undeploy_non_existent(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    non_existent_deployment_id = str(uuid.uuid4())

    # When + Then
    with pytest.raises(FrogmlException) as exc_info:
        model_deployment_manager_client.undeploy(
            deployment_ids=[non_existent_deployment_id]
        )

    assert "Failed to undeploy" in str(exc_info.value)


def test_undeploy_partial_non_existent(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    existing_deployment_id = _given_deployed_model(
        frogml_services_mock, client=model_deployment_manager_client
    )
    non_existent_deployment_id = str(uuid.uuid4())

    # When + Then
    with pytest.raises(FrogmlException) as exc_info:
        model_deployment_manager_client.undeploy(
            deployment_ids=[existing_deployment_id, non_existent_deployment_id]
        )

    assert "Failed to undeploy" in str(exc_info.value)


def test_get_deployment_non_existent(
    frogml_services_mock: FrogmlMocks,
    model_deployment_manager_client: ModelDeploymentManagerClient,
):
    # Given
    non_existent_deployment_id = str(uuid.uuid4())

    # When
    deployment_info: ModelDeploymentInformation = (
        model_deployment_manager_client.get_deployment(
            deployment_id=non_existent_deployment_id
        )
    )

    # Then
    assert deployment_info.model_deployment_metadata.deployment_id == ""
    assert (
        deployment_info.model_artifact_identifier.model_based_artifact_id.model_id == ""
    )
