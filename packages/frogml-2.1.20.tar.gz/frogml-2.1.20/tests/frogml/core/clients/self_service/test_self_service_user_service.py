from http import HTTPStatus
from unittest.mock import MagicMock

import grpc
import pytest

from frogml._proto.qwak.models.models_pb2 import CreateModelResponse
from frogml._proto.qwak.self_service.user.v1.user_service_pb2 import (
    RevokeApiKeyResponse,
)
from frogml.core.clients.administration import SelfServiceUserClient
from frogml.core.clients.administration.self_service.client import (
    APIKEY_ALREADY_EXISTS,
    OPERATION_GENERATE_API_KEY,
)
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks
from frogml_services_mock.mocks.self_service_user_service import API_KEY_FORMAT
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
    create_grpc_error,
)


def test_generate_apikey(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    user_id = "user_id"
    environment_id = "environment_id"

    # When
    client = SelfServiceUserClient()
    response: CreateModelResponse = client.generate_apikey(
        user_id=user_id,
        environment_id=environment_id,
    )

    # Then
    assert API_KEY_FORMAT.format(user_id, environment_id) == response.api_key


def test_revoke_apikey(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    user_id = "user_id"
    environment_id = "environment_id"

    # When
    client = SelfServiceUserClient()
    client.generate_apikey(
        user_id=user_id,
        environment_id=environment_id,
    )
    response_revoke: RevokeApiKeyResponse = client.revoke_apikey(
        user_id=user_id,
        environment_id=environment_id,
    )

    # Then
    assert RevokeApiKeyResponse.Status.REVOKED == response_revoke.status


GENERATE_APIKEY_ERROR_CASES = [
    pytest.param(
        grpc.StatusCode.ALREADY_EXISTS,
        APIKEY_ALREADY_EXISTS,
        HTTPStatus.CONFLICT,
        id="already_exists",
    ),
    pytest.param(
        grpc.StatusCode.PERMISSION_DENIED,
        "You are not authorized to perform administration operations",
        HTTPStatus.FORBIDDEN,
        id="permission_denied",
    ),
    pytest.param(
        grpc.StatusCode.UNKNOWN,
        "Failed to generate api key",
        HTTPStatus.INTERNAL_SERVER_ERROR,
        id="unknown_error",
    ),
]


@pytest.mark.parametrize(
    "grpc_code, expected_msg, expected_status", GENERATE_APIKEY_ERROR_CASES
)
def test_generate_apikey_grpc_error_raises_frogml_exception(
    grpc_code: grpc.StatusCode,
    expected_msg: str,
    expected_status: HTTPStatus,
) -> None:
    client = SelfServiceUserClient()
    client._user_service = MagicMock()
    client._user_service.GenerateApiKey = MagicMock(
        side_effect=create_grpc_error(code=grpc_code, details="error")
    )
    with pytest.raises(FrogmlException) as exc_info:
        client.generate_apikey(user_id="u", environment_id="e")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message=expected_msg,
        expected_status_code=expected_status,
        expected_operation=OPERATION_GENERATE_API_KEY,
    )


REVOKE_APIKEY_ERROR_CASES = [
    pytest.param(
        grpc.StatusCode.PERMISSION_DENIED,
        "You are not authorized to perform administration operations",
        HTTPStatus.FORBIDDEN,
        id="permission_denied",
    ),
    pytest.param(
        grpc.StatusCode.UNKNOWN,
        "Failed to revoke api key",
        HTTPStatus.INTERNAL_SERVER_ERROR,
        id="unknown_error",
    ),
]


@pytest.mark.parametrize(
    "grpc_code, expected_msg, expected_status", REVOKE_APIKEY_ERROR_CASES
)
def test_revoke_apikey_grpc_error_raises_frogml_exception(
    grpc_code: grpc.StatusCode,
    expected_msg: str,
    expected_status: HTTPStatus,
) -> None:
    client = SelfServiceUserClient()
    client._user_service = MagicMock()
    client._user_service.RevokeApiKey = MagicMock(
        side_effect=create_grpc_error(code=grpc_code, details="error")
    )
    with pytest.raises(FrogmlException) as exc_info:
        client.revoke_apikey(user_id="u", environment_id="e")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message=expected_msg,
        expected_status_code=expected_status,
        expected_operation="Revoke API Key",
    )
