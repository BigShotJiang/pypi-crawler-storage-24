"""Tests for ClusterV2Client."""

import grpc
import pytest

from frogml._proto.qwak.administration.cluster.v2.cluster_pb2 import (
    ClusterSpec,
    ClusterState,
)
from frogml._proto.qwak.administration.cluster.v2.cluster_service_pb2 import (
    CreateClusterCreationRequestResponse,
    DeleteClusterResponse,
    GetClusterResponse,
    GetClusterStateResponse,
    ListClustersResponse,
    UpdateClusterConfigurationResponse,
)
from frogml.core.clients.administration.cluster_v2.client import ClusterV2Client
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks


def test_create_cluster_success(frogml_services_mock: FrogmlMocks) -> None:
    expected_response = CreateClusterCreationRequestResponse(request_id="req-123")
    frogml_services_mock.cluster_v2_service_mock.given_create_cluster(
        response=expected_response
    )

    client = ClusterV2Client()
    cluster_spec = ClusterSpec(display_name="test-cluster")
    response = client.create_cluster(cluster_spec)

    assert response.request_id == "req-123"


def test_create_cluster_grpc_error(frogml_services_mock: FrogmlMocks) -> None:
    frogml_services_mock.cluster_v2_service_mock.given_create_cluster(
        error_code=grpc.StatusCode.INTERNAL,
    )

    client = ClusterV2Client()
    cluster_spec = ClusterSpec(display_name="test-cluster")

    with pytest.raises(FrogmlException) as exc_info:
        client.create_cluster(cluster_spec)

    assert "Failed to create cluster" in str(exc_info.value)


def test_get_cluster_success(frogml_services_mock: FrogmlMocks) -> None:
    expected_response = GetClusterResponse(cluster_state=ClusterState())
    frogml_services_mock.cluster_v2_service_mock.given_get_cluster(
        response=expected_response
    )

    client = ClusterV2Client()
    response = client.get_cluster("cluster-123")

    assert response == expected_response


def test_get_cluster_grpc_error(frogml_services_mock: FrogmlMocks) -> None:
    frogml_services_mock.cluster_v2_service_mock.given_get_cluster(
        error_code=grpc.StatusCode.NOT_FOUND,
    )

    client = ClusterV2Client()

    with pytest.raises(FrogmlException) as exc_info:
        client.get_cluster("cluster-123")

    assert "Failed to get cluster" in str(exc_info.value)


def test_list_clusters_success(frogml_services_mock: FrogmlMocks) -> None:
    expected_response = ListClustersResponse()
    frogml_services_mock.cluster_v2_service_mock.given_list_clusters(
        response=expected_response
    )

    client = ClusterV2Client()
    response = client.list_clusters()

    assert response == expected_response


def test_list_clusters_grpc_error(frogml_services_mock: FrogmlMocks) -> None:
    frogml_services_mock.cluster_v2_service_mock.given_list_clusters(
        error_code=grpc.StatusCode.INTERNAL,
    )

    client = ClusterV2Client()

    with pytest.raises(FrogmlException) as exc_info:
        client.list_clusters()

    assert "Failed to list clusters" in str(exc_info.value)


def test_update_cluster_success(frogml_services_mock: FrogmlMocks) -> None:
    expected_response = UpdateClusterConfigurationResponse(request_id="req-456")
    frogml_services_mock.cluster_v2_service_mock.given_update_cluster(
        response=expected_response
    )

    client = ClusterV2Client()
    cluster_spec = ClusterSpec(display_name="updated-cluster")
    response = client.update_cluster("cluster-123", cluster_spec)

    assert response.request_id == "req-456"


def test_update_cluster_grpc_error(frogml_services_mock: FrogmlMocks) -> None:
    frogml_services_mock.cluster_v2_service_mock.given_update_cluster(
        error_code=grpc.StatusCode.PERMISSION_DENIED,
    )

    client = ClusterV2Client()
    cluster_spec = ClusterSpec(display_name="updated-cluster")

    with pytest.raises(FrogmlException) as exc_info:
        client.update_cluster("cluster-123", cluster_spec)

    assert "Failed to update cluster" in str(exc_info.value)


def test_delete_cluster_success(frogml_services_mock: FrogmlMocks) -> None:
    expected_response = DeleteClusterResponse(request_id="req-789")
    frogml_services_mock.cluster_v2_service_mock.given_delete_cluster(
        response=expected_response
    )

    client = ClusterV2Client()
    response = client.delete_cluster("cluster-123")

    assert response.request_id == "req-789"


def test_delete_cluster_grpc_error(frogml_services_mock: FrogmlMocks) -> None:
    frogml_services_mock.cluster_v2_service_mock.given_delete_cluster(
        error_code=grpc.StatusCode.NOT_FOUND,
    )

    client = ClusterV2Client()

    with pytest.raises(FrogmlException) as exc_info:
        client.delete_cluster("cluster-123")

    assert "Failed to delete cluster" in str(exc_info.value)


def test_get_cluster_state_success(frogml_services_mock: FrogmlMocks) -> None:
    expected_response = GetClusterStateResponse(cluster_state=ClusterState())
    frogml_services_mock.cluster_v2_service_mock.given_get_cluster_state(
        response=expected_response
    )

    client = ClusterV2Client()
    response = client.get_cluster_state("req-123")

    assert response == expected_response


def test_get_cluster_state_grpc_error(frogml_services_mock: FrogmlMocks) -> None:
    frogml_services_mock.cluster_v2_service_mock.given_get_cluster_state(
        error_code=grpc.StatusCode.NOT_FOUND,
    )

    client = ClusterV2Client()

    with pytest.raises(FrogmlException) as exc_info:
        client.get_cluster_state("req-123")

    assert "Failed to get cluster state" in str(exc_info.value)
