"""Tests for EnvironmentV1Client."""

import grpc
import pytest

from frogml._proto.qwak.administration.v0.environments.environment_pb2 import (
    QwakEnvironment,
)
from frogml._proto.qwak.administration.v1.environments.environment_pb2 import (
    EnvironmentRuntimeConfigSpec,
)
from frogml._proto.qwak.administration.v1.environments.environment_service_pb2 import (
    CreateEnvironmentResponse,
)
from frogml.core.clients.administration.environment_v1.client import EnvironmentV1Client
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks


def test_create_environment_success(frogml_services_mock: FrogmlMocks) -> None:
    expected_env = QwakEnvironment(id="env-123")
    expected_response = CreateEnvironmentResponse(environment=expected_env)
    frogml_services_mock.environment_v1_service_mock.given_create_environment(
        response=expected_response
    )

    client = EnvironmentV1Client()
    spec = EnvironmentRuntimeConfigSpec()
    response = client.create_environment(
        environment_name="test-env",
        cluster_id="cluster-123",
        spec=spec,
    )

    assert response.environment.id == "env-123"


def test_create_environment_grpc_error(frogml_services_mock: FrogmlMocks) -> None:
    frogml_services_mock.environment_v1_service_mock.given_create_environment(
        error_code=grpc.StatusCode.ALREADY_EXISTS,
    )

    client = EnvironmentV1Client()
    spec = EnvironmentRuntimeConfigSpec()

    with pytest.raises(FrogmlException) as exc_info:
        client.create_environment(
            environment_name="test-env",
            cluster_id="cluster-123",
            spec=spec,
        )

    assert "Failed to create environment" in str(exc_info.value)


def test_create_environment_cluster_not_found(
    frogml_services_mock: FrogmlMocks,
) -> None:
    frogml_services_mock.environment_v1_service_mock.given_create_environment(
        error_code=grpc.StatusCode.NOT_FOUND,
    )

    client = EnvironmentV1Client()
    spec = EnvironmentRuntimeConfigSpec()

    with pytest.raises(FrogmlException) as exc_info:
        client.create_environment(
            environment_name="test-env",
            cluster_id="non-existent-cluster",
            spec=spec,
        )

    assert "Failed to create environment" in str(exc_info.value)


def test_create_environment_permission_denied(
    frogml_services_mock: FrogmlMocks,
) -> None:
    frogml_services_mock.environment_v1_service_mock.given_create_environment(
        error_code=grpc.StatusCode.PERMISSION_DENIED,
    )

    client = EnvironmentV1Client()
    spec = EnvironmentRuntimeConfigSpec()

    with pytest.raises(FrogmlException) as exc_info:
        client.create_environment(
            environment_name="test-env",
            cluster_id="cluster-123",
            spec=spec,
        )

    assert "Failed to create environment" in str(exc_info.value)
