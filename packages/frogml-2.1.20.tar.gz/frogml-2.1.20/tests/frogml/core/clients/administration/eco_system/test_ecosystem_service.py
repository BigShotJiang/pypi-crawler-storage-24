import pytest
from google.protobuf.timestamp_pb2 import Timestamp

from frogml._proto.qwak.ecosystem.v0.credentials_pb2 import AwsTemporaryCredentials
from frogml._proto.qwak.ecosystem.v0.ecosystem_runtime_service_pb2 import (
    GetCloudCredentialsRequest,
    GetCloudCredentialsResponse,
)
from frogml.core.clients.administration.eco_system.client import EcosystemClient
from frogml.core.exceptions import FrogmlException

aws_temp_credentials: AwsTemporaryCredentials = AwsTemporaryCredentials(
    access_key_id="some_access_key_id",
    secret_access_key="some_secret_access_key",
    session_token="some_session_token",
    expiration_time=Timestamp(seconds=1),
)


def test_get_cloud_credentials(frogml_services_mock):
    frogml_services_mock.ecosystem_client_mock.given_credentials(aws_temp_credentials)

    client = EcosystemClient()

    response: GetCloudCredentialsResponse = client.get_cloud_credentials(
        GetCloudCredentialsRequest()
    )
    response_credentials: AwsTemporaryCredentials = (
        response.cloud_credentials.aws_temporary_credentials
    )
    assert response_credentials.access_key_id == aws_temp_credentials.access_key_id
    assert response_credentials.session_token == aws_temp_credentials.session_token
    assert (
        response_credentials.secret_access_key == aws_temp_credentials.secret_access_key
    )
    assert response_credentials.expiration_time == aws_temp_credentials.expiration_time


def test_get_cloud_credentials_exception(frogml_services_mock):
    with pytest.raises(FrogmlException):
        frogml_services_mock.ecosystem_client_mock.given_credentials(
            aws_temp_credentials
        )

        client = EcosystemClient()

        client.get_cloud_credentials("Exception")
