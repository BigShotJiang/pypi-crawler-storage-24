"""Tests for EnvironmentClient (v0)."""

import grpc
import pytest

from frogml._proto.qwak.administration.v0.environments.configuration_pb2 import (
    QwakEnvironmentConfiguration,
)
from frogml._proto.qwak.administration.v0.environments.environment_service_pb2 import (
    UpdateEnvironmentConfigurationResponse,
)
from frogml.core.clients.administration.environment.client import EnvironmentClient
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks


def test_update_environment_configuration_success(
    frogml_services_mock: FrogmlMocks,
) -> None:
    expected_response = UpdateEnvironmentConfigurationResponse()
    frogml_services_mock.environment_v0_service_mock.given_update_environment_configuration(
        response=expected_response
    )

    client = EnvironmentClient()
    configuration = QwakEnvironmentConfiguration()
    response = client.update_environment_configuration(
        environment_id="env-123",
        configuration=configuration,
    )

    assert response == expected_response


def test_update_environment_configuration_grpc_error(
    frogml_services_mock: FrogmlMocks,
) -> None:
    frogml_services_mock.environment_v0_service_mock.given_update_environment_configuration(
        error_code=grpc.StatusCode.NOT_FOUND,
    )

    client = EnvironmentClient()
    configuration = QwakEnvironmentConfiguration()

    with pytest.raises(FrogmlException) as exc_info:
        client.update_environment_configuration(
            environment_id="env-123",
            configuration=configuration,
        )

    assert "Failed to update environment configuration" in str(exc_info.value)


def test_update_environment_configuration_permission_denied(
    frogml_services_mock: FrogmlMocks,
) -> None:
    frogml_services_mock.environment_v0_service_mock.given_update_environment_configuration(
        error_code=grpc.StatusCode.PERMISSION_DENIED,
    )

    client = EnvironmentClient()
    configuration = QwakEnvironmentConfiguration()

    with pytest.raises(FrogmlException) as exc_info:
        client.update_environment_configuration(
            environment_id="env-123",
            configuration=configuration,
        )

    assert "Failed to update environment configuration" in str(exc_info.value)
