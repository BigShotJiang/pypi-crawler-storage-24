from unittest.mock import MagicMock

import pytest

from frogml.core.clients.build_orchestrator import BuildOrchestratorClient
from frogml.core.clients.build_orchestrator.client import (
    UrlInfo,
    BuildVersioningTagsTypeEnum,
)


def test_get_upload_urls(frogml_services_mock):
    client = BuildOrchestratorClient()
    client._builds_orchestrator_stub = MagicMock()
    client._builds_orchestrator_stub.GetBuildVersioningUploadUrls = MagicMock(
        return_value="dummy_response"
    )

    code: list[UrlInfo] = [
        UrlInfo(
            build_id="123",
            model_id="456",
            tag_type=BuildVersioningTagsTypeEnum.CODE_TAG_TYPE,
            tag="code",
        ),
        UrlInfo(
            build_id="555",
            model_id="444",
            tag_type=BuildVersioningTagsTypeEnum.DATA_TAG_TYPE,
            tag="data",
        ),
    ]
    client.get_build_versioning_upload_urls(url_infos=code)
    assert client._builds_orchestrator_stub.GetBuildVersioningUploadUrls.called
    call_args, _ = (
        client._builds_orchestrator_stub.GetBuildVersioningUploadUrls.call_args
    )
    assert len(call_args[0].params)


def test_get_upload_urls_with_exception(frogml_services_mock):
    client = BuildOrchestratorClient()
    client._builds_orchestrator_stub = MagicMock()
    client._builds_orchestrator_stub.GetBuildVersioningUploadUrls.side_effect = (
        Exception("GRPC failed")
    )

    url_infos = [
        UrlInfo(build_id="123", model_id="456", tag="code"),
    ]

    # Act & Assert
    with pytest.raises(Exception) as excinfo:
        client.get_build_versioning_upload_urls(url_infos)

    assert "Failed to get build versioning upload urls [UrlInfo" in str(excinfo.value)
    assert "GRPC failed" in str(excinfo.value)
