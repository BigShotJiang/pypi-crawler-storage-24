from unittest.mock import MagicMock

import pytest

from frogml.core.clients.build_orchestrator.build_model_request_getter import (
    _get_build_model_spec,
)
from frogml.core.exceptions import FrogmlException


def test_build_model_request_getter():
    build_conf = MagicMock()
    verbose: int = 0
    git_commit_id: str = ""
    resolved_model_url: str = ""
    build_code_path: str = ""
    build_v1_flag = False
    build_config_url: str = ""
    frogml_cli_wheel_url: str = ""
    frogml_cli_version_url: str = ""
    build_steps = None
    sdk_version = "1.0.9"
    build_properties = MagicMock()
    model_uri = MagicMock()
    build_env = MagicMock()
    docker = MagicMock()

    build_conf.build_properties = build_properties
    build_properties.build_id = "build_id"
    build_properties.build_name = "build_name"
    build_properties.gpu_compatible = True
    build_properties.branch = "main"
    build_properties.model_id = "model_id"
    build_properties.tags = []
    build_properties.model_uri = model_uri
    model_uri.uri = "."
    model_uri.git_branch = "master"
    model_uri.git_credentials_secret = None
    model_uri.git_credentials = None
    model_uri.main_dir = "main"
    build_conf.build_env = build_env
    build_env.docker = docker
    build_conf.purchase_option = "spot"
    build_env.remote.resources.instance = "small"
    docker.base_image = "base_image"
    docker.assumed_iam_role_arn = "assumed_iam_role_arn"
    docker.service_account_key_secret_name = "service_account_key_secret_name"
    docker.cache = True
    docker.env_vars = ["env1", "env2"]
    build_conf.to_yaml.return_value = "hello"
    build_spec = _get_build_model_spec(
        build_conf,
        verbose,
        git_commit_id,
        resolved_model_url,
        build_code_path,
        build_v1_flag,
        build_config_url,
        frogml_cli_wheel_url,
        frogml_cli_version_url,
        build_steps,
        sdk_version,
    )

    assert build_spec.build_properties.gpu_compatible
    assert build_properties.build_id == build_spec.build_properties.build_id
    assert build_properties.model_id == build_spec.build_properties.model_id
    assert model_uri.uri == build_spec.build_properties.model_uri.uri


def test_build_model_request_getter_with_ondemand():
    build_conf = MagicMock()
    verbose: int = 0
    git_commit_id: str = ""
    resolved_model_url: str = ""
    build_code_path: str = ""
    build_v1_flag = False
    build_config_url: str = ""
    frogml_cli_wheel_url: str = ""
    frogml_cli_version_url: str = ""
    build_steps = None
    sdk_version = "1.0.9"
    build_properties = MagicMock()
    model_uri = MagicMock()
    build_env = MagicMock()
    docker = MagicMock()

    build_conf.build_properties = build_properties
    build_properties.build_id = "build_id"
    build_properties.build_name = "build_name"
    build_properties.gpu_compatible = True
    build_properties.branch = "main"
    build_properties.model_id = "model_id"
    build_properties.tags = []
    build_properties.model_uri = model_uri
    model_uri.uri = "."
    model_uri.git_branch = "master"
    model_uri.git_credentials_secret = None
    model_uri.git_credentials = None
    model_uri.main_dir = "main"
    build_conf.build_env = build_env
    build_env.docker = docker
    build_conf.purchase_option = "ondemand"
    build_env.remote.resources.instance = "small"
    docker.base_image = "base_image"
    docker.assumed_iam_role_arn = "assumed_iam_role_arn"
    docker.service_account_key_secret_name = "service_account_key_secret_name"
    docker.cache = True
    docker.env_vars = ["env1", "env2"]
    build_conf.to_yaml.return_value = "hello"
    build_spec = _get_build_model_spec(
        build_conf,
        verbose,
        git_commit_id,
        resolved_model_url,
        build_code_path,
        build_v1_flag,
        build_config_url,
        frogml_cli_wheel_url,
        frogml_cli_version_url,
        build_steps,
        sdk_version,
    )

    assert build_spec.build_properties.gpu_compatible
    assert build_properties.build_id == build_spec.build_properties.build_id
    assert build_properties.model_id == build_spec.build_properties.model_id
    assert model_uri.uri == build_spec.build_properties.model_uri.uri


def test_build_model_request_getter_empty_purchase_option():
    build_conf = MagicMock()
    verbose: int = 0
    git_commit_id: str = ""
    resolved_model_url: str = ""
    build_code_path: str = ""
    build_v1_flag = False
    build_config_url: str = ""
    frogml_cli_wheel_url: str = ""
    frogml_cli_version_url: str = ""
    build_steps = None
    sdk_version = "1.0.9"
    build_properties = MagicMock()
    model_uri = MagicMock()
    build_env = MagicMock()
    docker = MagicMock()

    build_conf.build_properties = build_properties
    build_properties.build_id = "build_id"
    build_properties.build_name = "build_name"
    build_properties.gpu_compatible = True
    build_properties.branch = "main"
    build_properties.model_id = "model_id"
    build_properties.tags = []
    build_properties.model_uri = model_uri
    build_conf.purchase_option = None
    model_uri.uri = "."
    model_uri.git_branch = "master"
    model_uri.git_credentials_secret = None
    model_uri.git_credentials = None
    model_uri.main_dir = "main"
    build_conf.build_env = build_env
    build_env.docker = docker
    build_env.remote.resources.instance = "small"
    docker.base_image = "base_image"
    docker.assumed_iam_role_arn = "assumed_iam_role_arn"
    docker.service_account_key_secret_name = "service_account_key_secret_name"
    docker.cache = True
    docker.env_vars = ["env1", "env2"]
    build_conf.to_yaml.return_value = "hello"
    build_spec = _get_build_model_spec(
        build_conf,
        verbose,
        git_commit_id,
        resolved_model_url,
        build_code_path,
        build_v1_flag,
        build_config_url,
        frogml_cli_wheel_url,
        frogml_cli_version_url,
        build_steps,
        sdk_version,
    )

    assert build_spec.build_properties.gpu_compatible
    assert build_properties.build_id == build_spec.build_properties.build_id
    assert build_properties.model_id == build_spec.build_properties.model_id
    assert model_uri.uri == build_spec.build_properties.model_uri.uri


def test_build_model_request_getter_wrong_purchase_option():
    build_conf = MagicMock()
    verbose: int = 0
    git_commit_id: str = ""
    resolved_model_url: str = ""
    build_code_path: str = ""
    build_v1_flag = False
    build_config_url: str = ""
    frogml_cli_wheel_url: str = ""
    frogml_cli_version_url: str = ""
    build_steps = None
    sdk_version = "1.0.9"
    build_properties = MagicMock()
    model_uri = MagicMock()
    build_env = MagicMock()
    docker = MagicMock()

    build_conf.build_properties = build_properties
    build_properties.build_id = "build_id"
    build_properties.gpu_compatible = True
    build_properties.branch = "main"
    build_properties.model_id = "model_id"
    build_properties.tags = []
    build_properties.model_uri = model_uri
    build_conf.purchase_option = "Ondemand"
    model_uri.uri = "."
    model_uri.git_branch = "master"
    model_uri.git_credentials_secret = None
    model_uri.git_credentials = None
    model_uri.main_dir = "main"
    build_conf.build_env = build_env
    build_env.docker = docker
    build_env.remote.resources.instance = "small"
    docker.base_image = "base_image"
    docker.assumed_iam_role_arn = "assumed_iam_role_arn"
    docker.service_account_key_secret_name = "service_account_key_secret_name"
    docker.cache = True
    docker.env_vars = ["env1", "env2"]
    build_conf.to_yaml.return_value = "hello"

    with pytest.raises(Exception) as exception:
        _get_build_model_spec(
            build_conf,
            verbose,
            git_commit_id,
            resolved_model_url,
            build_code_path,
            build_v1_flag,
            build_config_url,
            frogml_cli_wheel_url,
            frogml_cli_version_url,
            build_steps,
            sdk_version,
        )
    assert type(exception.value).__class__ == FrogmlException.__class__
