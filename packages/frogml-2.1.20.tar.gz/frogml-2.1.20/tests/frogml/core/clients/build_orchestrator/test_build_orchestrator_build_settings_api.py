import pytest

from frogml._proto.qwak.build_settings.build_settings_pb2 import (
    AuthenticationSettings,
    BuildSettings,
    ModelRepositorySettings,
    RepositorySettingsJFrog,
)
from frogml.core.clients.build_orchestrator.client import BuildOrchestratorClient
from frogml.core.exceptions import FrogmlException


def test_get_build_settings(frogml_services_mock):
    # Given
    environment_id = "env_id"
    container_registry_prefix = "container_registry_prefix"
    token = "token"

    build_settings = BuildSettings(
        model_repository_setting=ModelRepositorySettings(
            container_registry_prefix=container_registry_prefix,
            repository_settings_jfrog=RepositorySettingsJFrog(
                authentication_settings=AuthenticationSettings(token=token)
            ),
        )
    )
    frogml_services_mock.build_orchestrator_build_settings_api.given_build_settings(
        environment_id=environment_id, build_settings=build_settings
    )

    # When
    client = BuildOrchestratorClient()

    build_settings_response = client.get_build_settings(environment_id=environment_id)
    build_settings = build_settings_response.build_settings

    # Then
    assert (
        build_settings.model_repository_setting.container_registry_prefix
        == container_registry_prefix
    )
    assert (
        build_settings.model_repository_setting.repository_settings_jfrog.authentication_settings.token
        == token
    )


def test_none_existing_build_settings(frogml_services_mock):
    environment_id = "none_existing_env_id"
    client = BuildOrchestratorClient()

    with pytest.raises(Exception) as exception:
        client.get_build_settings(environment_id=environment_id)
    assert type(exception.value).__class__ == FrogmlException.__class__
