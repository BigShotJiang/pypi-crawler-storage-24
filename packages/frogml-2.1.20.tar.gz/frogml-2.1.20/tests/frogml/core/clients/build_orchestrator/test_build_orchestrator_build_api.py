from http import HTTPStatus
from unittest import mock

import pytest

from frogml._proto.qwak.build.v1.build_api_pb2 import (
    GetBuildResponse,
    ListBuildsResponse,
    PhaseStatus,
)
from frogml._proto.qwak.build.v1.build_pb2 import (
    Build,
    BuildFilter,
    BuildStatus,
    Entity,
    ExplicitFeature,
    Feature,
    InferenceOutput,
    ModelSchema,
    Prediction,
)
from frogml._proto.qwak.builds.build_pb2 import BaseDockerImageType
from frogml._proto.qwak.builds.build_url_pb2 import BuildVersioningTagsType
from frogml.core.clients.build_orchestrator.client import (
    BuildOrchestratorClient,
    HuggingFaceModel,
    HuggingModelDataClass,
)
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks
from tests.frogml.core.utils.frogml_exception_helpers import (
    GrpcErrorTestCase,
    assert_frogml_exception,
    create_grpc_error,
)
from tests.frogml.core.clients.build_orchestrator.utils import (
    NonHuggingFaceModel,
    get_build_mock_data,
    given_mock_build,
)


def test_get_build(frogml_services_mock: FrogmlMocks) -> None:
    (
        now,
        created_by,
        created_at,
        last_modified_by,
        last_modified_at,
        build_id,
        commit_id,
        branch_id,
        model_uuid,
        build_config,
        build_status,
        tags,
        steps,
        params,
        metrics,
        model_schema,
        audit,
    ) = get_build_mock_data()

    frogml_services_mock.build_orchestrator_build_api.given_build(
        Build(
            buildId=build_id,
            commitId=commit_id,
            branchId=branch_id,
            model_uuid=model_uuid,
            buildConfig=build_config,
            build_status=build_status,
            tags=tags,
            steps=steps,
            params=params,
            metrics=metrics,
            model_schema=model_schema,
            audit=audit,
        ),
    )
    client = BuildOrchestratorClient()

    build_response: GetBuildResponse = client.get_build(build_id=build_id)
    build = build_response.build
    assert build.buildId == build_id
    assert build.commitId == commit_id
    assert build.branchId == branch_id
    assert build.model_uuid == model_uuid
    assert build.buildConfig == build_config
    assert build.build_status == build_status
    assert build.tags == tags
    assert build.steps == steps
    assert build.params == params
    assert build.metrics == metrics
    assert build.model_schema == model_schema
    assert build.audit == audit


def test_delete_build_happy_flow_succeeds(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    mock_params: dict = given_mock_build(
        frogml_services_mock.build_orchestrator_build_api
    )
    build_id = mock_params.get("build_id")
    assert build_id is not None
    client: BuildOrchestratorClient = BuildOrchestratorClient()
    assert build_id in frogml_services_mock.build_orchestrator_build_api.builds

    # When
    client.delete_build(build_id)

    # Then
    assert build_id not in frogml_services_mock.build_orchestrator_build_api.builds


def test_delete_builds_happy_flow_succeeds(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    mock_params1: dict = given_mock_build(
        frogml_services_mock.build_orchestrator_build_api
    )
    mock_params2: dict = given_mock_build(
        frogml_services_mock.build_orchestrator_build_api
    )
    build_id_1 = mock_params1.get("build_id")
    build_id_2 = mock_params2.get("build_id")
    assert build_id_1 is not None
    assert build_id_2 is not None
    client: BuildOrchestratorClient = BuildOrchestratorClient()
    assert build_id_1 in frogml_services_mock.build_orchestrator_build_api.builds
    assert build_id_2 in frogml_services_mock.build_orchestrator_build_api.builds

    # When
    client.delete_builds([build_id_1, build_id_2])

    # Then
    assert build_id_1 not in frogml_services_mock.build_orchestrator_build_api.builds
    assert build_id_2 not in frogml_services_mock.build_orchestrator_build_api.builds


def test_update_build_status(frogml_services_mock: FrogmlMocks) -> None:
    mock_params = given_mock_build(frogml_services_mock.build_orchestrator_build_api)
    client = BuildOrchestratorClient()

    updated_status = BuildStatus.FAILED

    assert (
        frogml_services_mock.build_orchestrator_build_api.builds[
            mock_params["build_id"]
        ].build_status
        != updated_status
    )

    client.update_build_status(mock_params["build_id"], updated_status)

    assert (
        frogml_services_mock.build_orchestrator_build_api.builds[
            mock_params["build_id"]
        ].build_status
        == updated_status
    )


def test_register_model_schema(frogml_services_mock: FrogmlMocks) -> None:
    mock_params = given_mock_build(frogml_services_mock.build_orchestrator_build_api)
    client = BuildOrchestratorClient()

    model_schema: ModelSchema = ModelSchema(
        entities=[Entity(name="YO")],
        features=[Feature(explicit_feature=ExplicitFeature(name="explicit"))],
        predictions=[Prediction(name="YOYO")],
        inference_output=[InferenceOutput(name="YOYO3")],
    )

    assert (
        frogml_services_mock.build_orchestrator_build_api.builds[
            mock_params["build_id"]
        ].model_schema
        != model_schema
    )

    client.register_model_schema(mock_params["build_id"], model_schema)

    assert (
        frogml_services_mock.build_orchestrator_build_api.builds[
            mock_params["build_id"]
        ].model_schema
        == model_schema
    )


def test_save_framework_models(frogml_services_mock: FrogmlMocks) -> None:
    build_id = "build_id"
    huggingface_model_name = "pretrained_model_name"
    version = "version"
    repository = "repository"
    model_names_to_version = {}
    model_names_to_version[huggingface_model_name] = [version]
    hugging_pretrained_model_data_class = [
        HuggingModelDataClass(
            models_name_to_versions=model_names_to_version,
            repository=repository,
        )
    ]
    client = BuildOrchestratorClient()
    client.save_framework_models(
        build_id=build_id,
        frameworks_model_data_class=hugging_pretrained_model_data_class,
    )

    actual_framework_model_data_class = (
        frogml_services_mock.build_orchestrator_build_api._framework_models[build_id][
            0
        ].huggingface_model_spec
    )

    assert actual_framework_model_data_class.repository == repository
    assert actual_framework_model_data_class.version == version
    assert actual_framework_model_data_class.model_name == huggingface_model_name


def test_save_used_framework_models(frogml_services_mock: FrogmlMocks) -> None:
    build_id = "build_id"

    hugging_pretrained_model = HuggingFaceModel(
        model_name="pretrained_model_name",
        version="main",
        sha1="abc-sha1",
        repository="repository",
    )

    second_hugging_pretrained_model = HuggingFaceModel(
        model_name="pretrained_model_name2",
        version="commit_hash",
        sha1="abc-sha2",
        repository="repository",
    )
    client = BuildOrchestratorClient()
    client.save_used_framework_models(
        build_id=build_id,
        models=[hugging_pretrained_model, second_hugging_pretrained_model],
    )

    first_model = frogml_services_mock.build_orchestrator_build_api._framework_models[
        build_id
    ][0].huggingface_model_spec

    second_model = frogml_services_mock.build_orchestrator_build_api._framework_models[
        build_id
    ][1].huggingface_model_spec

    assert first_model.repository == hugging_pretrained_model.repository
    assert first_model.version == hugging_pretrained_model.version
    assert first_model.model_name == hugging_pretrained_model.model_name
    assert first_model.sha1 == hugging_pretrained_model.sha1

    assert second_model.repository == second_hugging_pretrained_model.repository
    assert second_model.version == second_hugging_pretrained_model.version
    assert second_model.model_name == second_hugging_pretrained_model.model_name
    assert second_model.sha1 == second_hugging_pretrained_model.sha1


def test_save_framework_models_num_of_versions(
    frogml_services_mock: FrogmlMocks,
) -> None:
    build_id = "build_id"
    huggingface_model_name = "pretrained_model_name"
    version1 = "version1"
    version2 = "version2"
    repository = "repository"
    model_names_to_version = {}
    model_names_to_version[huggingface_model_name] = [version1, version2]
    hugging_pretrained_model_data_class = [
        HuggingModelDataClass(
            models_name_to_versions=model_names_to_version,
            repository=repository,
        )
    ]
    client = BuildOrchestratorClient()
    client.save_framework_models(
        build_id=build_id,
        frameworks_model_data_class=hugging_pretrained_model_data_class,
    )

    filter_version1_condition = (
        lambda element: element.huggingface_model_spec.version == version1
    )
    filter_version2_condition = (
        lambda element: element.huggingface_model_spec.version == version2
    )

    version1_result = next(
        filter(
            filter_version1_condition,
            frogml_services_mock.build_orchestrator_build_api._framework_models[
                build_id
            ],
        ),
        None,
    )

    version2_result = next(
        filter(
            filter_version2_condition,
            frogml_services_mock.build_orchestrator_build_api._framework_models[
                build_id
            ],
        ),
        None,
    )

    assert version1_result.huggingface_model_spec.repository == repository
    assert version1_result.huggingface_model_spec.version == version1
    assert version1_result.huggingface_model_spec.model_name == huggingface_model_name
    assert version2_result.huggingface_model_spec.repository == repository
    assert version2_result.huggingface_model_spec.version == version2
    assert version2_result.huggingface_model_spec.model_name == huggingface_model_name


def test_register_tags(frogml_services_mock: FrogmlMocks) -> None:
    mock_params = given_mock_build(frogml_services_mock.build_orchestrator_build_api)
    client = BuildOrchestratorClient()

    tags_list = ["Tag_1", "Tag_2"]
    current_build_tags = list(
        frogml_services_mock.build_orchestrator_build_api.builds[
            mock_params["build_id"]
        ].tags
    )
    assert (
        tags_list
        not in frogml_services_mock.build_orchestrator_build_api.builds[
            mock_params["build_id"]
        ].tags
    )

    client.register_tags(mock_params["build_id"], tags_list)

    assert current_build_tags + tags_list == list(
        frogml_services_mock.build_orchestrator_build_api.builds[
            mock_params["build_id"]
        ].tags
    )


def test_register_experiment_tracking(frogml_services_mock: FrogmlMocks) -> None:
    mock_params = given_mock_build(frogml_services_mock.build_orchestrator_build_api)
    client = BuildOrchestratorClient()

    params = {"param1": "HEY"}

    assert (
        frogml_services_mock.build_orchestrator_build_api.builds[
            mock_params["build_id"]
        ].params
        != params
    )

    client.register_experiment_tracking(mock_params["build_id"], params)

    assert (
        frogml_services_mock.build_orchestrator_build_api.builds[
            mock_params["build_id"]
        ].params
        == params
    )


def test_list_builds(frogml_services_mock: FrogmlMocks) -> None:
    mock_params = given_mock_build(frogml_services_mock.build_orchestrator_build_api)
    _ = given_mock_build(frogml_services_mock.build_orchestrator_build_api)
    (
        now,
        created_by,
        created_at,
        last_modified_by,
        last_modified_at,
        build_id,
        commit_id,
        branch_id,
        model_uuid,
        build_config,
        build_status,
        tags,
        steps,
        params,
        metrics,
        model_schema,
        audit,
    ) = get_build_mock_data()

    frogml_services_mock.build_orchestrator_build_api.given_build(
        Build(
            buildId=build_id,
            commitId=commit_id,
            branchId=mock_params["branch_id"],
            model_uuid=mock_params["model_uuid"],
            buildConfig=build_config,
            build_status=build_status,
            tags=tags,
            steps=steps,
            params=params,
            metrics=metrics,
            model_schema=model_schema,
            audit=audit,
        ),
    )
    client = BuildOrchestratorClient()

    builds: ListBuildsResponse = client.list_builds(mock_params["model_uuid"])

    assert len(builds.build) == 2

    for x in builds.build:
        assert x.model_uuid == mock_params["model_uuid"]


def test_list_builds_with_tags(frogml_services_mock: FrogmlMocks) -> None:
    mock_params = given_mock_build(frogml_services_mock.build_orchestrator_build_api)
    _ = given_mock_build(frogml_services_mock.build_orchestrator_build_api)
    (
        now,
        created_by,
        created_at,
        last_modified_by,
        last_modified_at,
        build_id,
        commit_id,
        branch_id,
        model_uuid,
        build_config,
        build_status,
        tags,
        steps,
        params,
        metrics,
        model_schema,
        audit,
    ) = get_build_mock_data()

    frogml_services_mock.build_orchestrator_build_api.given_build(
        Build(
            buildId=build_id,
            commitId=commit_id,
            branchId=mock_params["branch_id"],
            buildConfig=build_config,
            build_status=build_status,
            tags=tags,
            steps=steps,
            params=params,
            metrics=metrics,
            model_schema=model_schema,
            audit=audit,
        ),
    )
    client = BuildOrchestratorClient()

    builds: ListBuildsResponse = client.list_builds(
        mock_params["branch_id"], BuildFilter(tags=mock_params["tags"])
    )

    assert len(builds.build) == 1
    assert builds.build[0].branchId == mock_params["branch_id"]
    for x in builds.build[0].tags:
        assert x in mock_params["tags"]


def test_log_phase_status(frogml_services_mock: FrogmlMocks) -> None:
    (
        now,
        created_by,
        created_at,
        last_modified_by,
        last_modified_at,
        build_id,
        commit_id,
        branch_id,
        model_uuid,
        build_config,
        build_status,
        tags,
        steps,
        params,
        metrics,
        model_schema,
        audit,
    ) = get_build_mock_data()
    client = BuildOrchestratorClient()

    assert len(frogml_services_mock.build_orchestrator_build_api.builds) == 0
    frogml_services_mock.build_orchestrator_build_api.given_build(
        Build(
            buildId=build_id,
            commitId=commit_id,
            model_uuid=model_uuid,
            buildConfig=build_config,
            tags=tags,
            steps=steps,
        ),
    )

    try:
        client.log_phase_status(
            build_id, "phase_id", PhaseStatus.PHASE_STATUS_IN_PROGRESS, 0
        )
    except Exception:
        pytest.fail(
            "Logging a phase status should work for a build that was registered before."
        )


def test_log_phase_status_without_build_id(frogml_services_mock: FrogmlMocks) -> None:
    client = BuildOrchestratorClient()
    try:
        client.log_phase_status("", "phase_id", PhaseStatus.PHASE_STATUS_IN_PROGRESS, 0)
    except Exception:
        pytest.fail(
            "Logging a phase status without a build should not work, but shouldn't throw an exception."
        )


def test_log_phase_status_for_unknown_build(frogml_services_mock: FrogmlMocks) -> None:
    client = BuildOrchestratorClient()

    with pytest.raises(Exception):
        client.log_phase_status(
            "build_id", "phase_id", PhaseStatus.PHASE_STATUS_IN_PROGRESS, 0
        )


def test_retrieve_base_docker_image_for_cpu_from_mock(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = BuildOrchestratorClient()

    result = client.fetch_base_docker_image_name(BaseDockerImageType.CPU)

    assert result.base_docker_image_name == "mocked_cpu_image"


def test_retrieve_base_docker_image_for_gpu_from_mock(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = BuildOrchestratorClient()

    result = client.fetch_base_docker_image_name(BaseDockerImageType.GPU)

    assert result.base_docker_image_name == "mocked_gpu_image"


def test_get_build_versioning_download_url(frogml_services_mock: FrogmlMocks) -> None:
    client = BuildOrchestratorClient()
    build_id = "build_id"
    model_id = "model_id"
    tag = "tag"
    expected_url = f"/{build_id}/download_urls/file.zip"

    download_url = client.get_build_versioning_download_url(
        build_id, model_id, tag, BuildVersioningTagsType.FILE_TAG_TYPE
    ).download_url

    assert download_url == expected_url


def test_get_build_versioning_download_url_not_found(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = BuildOrchestratorClient()
    build_id = "not_found"  # hard coded in the mock to raise exception
    model_id = "model_id"
    tag = "tag"
    with pytest.raises(FrogmlException) as e:
        client.get_build_versioning_download_url(
            build_id, model_id, tag, BuildVersioningTagsType.FILE_TAG_TYPE
        )

    assert (
        "The specified file cannot be found. Please verify the file name before trying again"
        in str(e.value)
    )


def test_get_build_versioning_download_url_internal_error(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = BuildOrchestratorClient()
    build_id = "internal_error"
    model_id = "model_id"
    tag = "tag"
    with pytest.raises(FrogmlException) as exc:
        client.get_build_versioning_download_url(
            build_id, model_id, tag, BuildVersioningTagsType.FILE_TAG_TYPE
        )

    assert_frogml_exception(
        exc.value,
        expected_error_message="The specified file cannot be loaded",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Get Build Versioning Download URL",
    )


@mock.patch(
    "frogml.core.clients.build_orchestrator.client.BuildsOrchestratorServiceStub"
)
def test_get_build_versioning_download_url_generic_exception_raises_frogml_exception(
    mock_stub: mock.MagicMock,
    frogml_services_mock: FrogmlMocks,
) -> None:
    mock_stub.return_value.GetBuildVersioningDownloadURL.side_effect = RuntimeError(
        "unexpected failure"
    )
    client = BuildOrchestratorClient()

    with pytest.raises(FrogmlException) as exc:
        client.get_build_versioning_download_url(
            "build_id", "model_id", "tag", BuildVersioningTagsType.FILE_TAG_TYPE
        )

    assert_frogml_exception(
        exc.value,
        expected_error_message="Failed to get build versioning download url: RuntimeError: unexpected failure",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Get Build Versioning Download URL",
    )


def test_get_build_versioning_download_url_no_tag_type(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = BuildOrchestratorClient()
    build_id = "build_id"
    model_id = "model_id"
    tag = "tag"
    expected_url = f"/{build_id}/download_urls/file.zip"

    download_url = client.get_build_versioning_download_url(
        build_id, model_id, tag
    ).download_url

    assert download_url == expected_url


def test_get_build_versioning_upload_url_no_tag_type(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = BuildOrchestratorClient()
    build_id = "build_id"
    model_id = "model_id"
    tag = "tag"
    expected_url = f"/{build_id}/upload_urls/file.zip"

    upload_url = client.get_build_versioning_upload_url(
        build_id,
        model_id,
        tag,
    ).upload_url

    assert upload_url == expected_url


def test_get_build_versioning_upload_url(frogml_services_mock: FrogmlMocks) -> None:
    client = BuildOrchestratorClient()
    build_id = "build_id"
    model_id = "model_id"
    tag = "tag"
    expected_url = f"/{build_id}/upload_urls/file.zip"

    upload_url = client.get_build_versioning_upload_url(
        build_id, model_id, tag, BuildVersioningTagsType.FILE_TAG_TYPE
    ).upload_url

    assert upload_url == expected_url


def get_test_case_id(test_case: GrpcErrorTestCase) -> str:
    return test_case.test_name


GRPC_ERROR_TEST_CASES: list[GrpcErrorTestCase] = [
    GrpcErrorTestCase(
        test_name="cancel_build_model",
        method_name="CancelBuildModel",
        client_method="cancel_build_model",
        client_kwargs={"build_id": "test_build_id"},
        expected_error_msg="Failed to cancel build",
        expected_operation="Cancel Build",
    ),
    GrpcErrorTestCase(
        test_name="fetch_base_docker_image_name",
        method_name="GetBaseDockerImageName",
        client_method="fetch_base_docker_image_name",
        client_kwargs={"image_type": BaseDockerImageType.CPU},
        expected_error_msg="Failed to retrieve base docker image name",
        expected_operation="Get Build Base Docker Image Name",
    ),
]


@pytest.mark.parametrize("test_case", GRPC_ERROR_TEST_CASES, ids=get_test_case_id)
@mock.patch(
    "frogml.core.clients.build_orchestrator.client.BuildsOrchestratorServiceStub"
)
def test_client_method_when_grpc_error_raises_frogml_exception(
    mock_stub: mock.MagicMock,
    frogml_services_mock: FrogmlMocks,
    test_case: GrpcErrorTestCase,
) -> None:
    """
    Verifies that gRPC errors are properly caught and converted to FrogmlException
    with correct error message, status code, and operation name.
    """
    # Configure the mock stub to raise a gRPC error when the method is called
    stub_method = getattr(mock_stub.return_value, test_case.method_name)
    stub_method.side_effect = create_grpc_error()

    client = BuildOrchestratorClient()
    client_method = getattr(client, test_case.client_method)

    with pytest.raises(FrogmlException) as exc:
        client_method(**test_case.client_kwargs)

    assert_frogml_exception(
        exc.value,
        expected_error_message=test_case.expected_error_msg,
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation=test_case.expected_operation,
    )


def test_list_builds_missing_model_uuid(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = BuildOrchestratorClient()

    with pytest.raises(FrogmlException) as exc:
        client.list_builds()

    assert_frogml_exception(
        exc.value,
        expected_error_message="Missing argument model uuid or branch id",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="List Builds",
    )


def test_save_used_framework_models_skips_non_huggingface_models(
    frogml_services_mock: FrogmlMocks,
) -> None:
    build_id = "build_id"

    hugging_model = HuggingFaceModel(
        model_name="bert-base",
        version="main",
        sha1="abc-sha1",
        repository="hf-repo",
    )
    non_hf_model = NonHuggingFaceModel(name="custom_model", version="v1")

    client = BuildOrchestratorClient()
    client.save_used_framework_models(
        build_id=build_id,
        models=[hugging_model, non_hf_model],
    )

    saved_models = frogml_services_mock.build_orchestrator_build_api._framework_models[
        build_id
    ]
    assert len(saved_models) == 1
    saved_spec = saved_models[0].huggingface_model_spec
    assert saved_spec.model_name == hugging_model.model_name
    assert saved_spec.version == hugging_model.version
    assert saved_spec.repository == hugging_model.repository
    assert saved_spec.sha1 == hugging_model.sha1


@mock.patch.object(BuildOrchestratorClient, "get_build")
def test_is_build_exists_returns_true_when_build_exists(
    mock_get_build: mock.MagicMock,
) -> None:
    build_id = "existing_build"
    response = mock.MagicMock()
    response.build.build_spec.build_id = build_id
    mock_get_build.return_value = response

    client = BuildOrchestratorClient()
    result = client.is_build_exists(build_id)

    assert result is True
    mock_get_build.assert_called_once_with(build_id)


@mock.patch.object(BuildOrchestratorClient, "get_build")
def test_is_build_exists_returns_false_when_not_found(
    mock_get_build: mock.MagicMock,
) -> None:
    mock_get_build.side_effect = FrogmlException(
        error_message="not found",
        status_code=HTTPStatus.NOT_FOUND,
        operation="Get Build",
    )

    client = BuildOrchestratorClient()
    result = client.is_build_exists("nonexistent_build")

    assert result is False


@mock.patch.object(BuildOrchestratorClient, "get_build")
def test_is_build_exists_raises_on_non_not_found_error(
    mock_get_build: mock.MagicMock,
) -> None:
    mock_get_build.side_effect = FrogmlException(
        error_message="server error",
        status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        operation="Get Build",
    )

    client = BuildOrchestratorClient()
    with pytest.raises(FrogmlException) as exc:
        client.is_build_exists("some_build")

    assert_frogml_exception(
        exc.value,
        expected_error_message="server error",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Get Build",
    )
