import uuid
from dataclasses import dataclass

from google.protobuf.timestamp_pb2 import Timestamp

from frogml._proto.qwak.build.v1.build_pb2 import Audit, Build, BuildStatus, ModelSchema
from frogml.core.clients.build_orchestrator.client import FrameworkModelDataClass


@dataclass
class NonHuggingFaceModel(FrameworkModelDataClass):
    name: str
    version: str


def get_build_mock_data():
    timestamp = Timestamp()
    timestamp.GetCurrentTime()
    now = timestamp
    created_by = str(uuid.uuid4())
    created_at = now
    last_modified_by = created_by
    last_modified_at = now

    build_id = str(uuid.uuid4())
    commit_id = str(uuid.uuid4())
    branch_id = str(uuid.uuid4())
    model_uuid = branch_id
    build_config = "{}"
    build_status = BuildStatus.IN_PROGRESS
    tags = [str(uuid.uuid4()), str(uuid.uuid4())]
    steps = []
    params = {}
    metrics = {}
    model_schema = ModelSchema()
    audit = Audit(
        created_by=created_by,
        created_at=created_at,
        last_modified_by=last_modified_by,
        last_modified_at=last_modified_at,
    )
    return (
        now,
        created_by,
        created_at,
        last_modified_by,
        last_modified_at,
        build_id,
        commit_id,
        branch_id,
        model_uuid,
        build_config,
        build_status,
        tags,
        steps,
        params,
        metrics,
        model_schema,
        audit,
    )


def given_mock_build(build_orchestrator):
    (
        now,
        created_by,
        created_at,
        last_modified_by,
        last_modified_at,
        build_id,
        commit_id,
        branch_id,
        model_uuid,
        build_config,
        build_status,
        tags,
        steps,
        params,
        metrics,
        model_schema,
        audit,
    ) = get_build_mock_data()

    build_orchestrator.given_build(
        Build(
            buildId=build_id,
            commitId=commit_id,
            branchId=branch_id,
            model_uuid=model_uuid,
            buildConfig=build_config,
            build_status=build_status,
            tags=tags,
            steps=steps,
            params=params,
            metrics=metrics,
            model_schema=model_schema,
            audit=audit,
        ),
    )

    return {
        "now": now,
        "created_by": created_by,
        "created_at": created_at,
        "last_modified_by": last_modified_by,
        "last_modified_at": last_modified_at,
        "build_id": build_id,
        "commit_id": commit_id,
        "branch_id": branch_id,
        "model_uuid": model_uuid,
        "build_config": build_config,
        "build_status": build_status,
        "tags": tags,
        "steps": steps,
        "params": params,
        "metrics": metrics,
        "model_schema": model_schema,
        "audit": audit,
    }
