from http import HTTPStatus
from unittest import mock
from unittest.mock import MagicMock

import pytest

from frogml._proto.qwak.builds.build_pb2 import AutomationBuildInitiator, BuildInitiator
from frogml.core.clients.build_orchestrator import InternalBuildOrchestratorClient
from frogml.core.clients.build_orchestrator.build_model_request_getter import (
    BUILD_MODEL_OPERATION,
)
from frogml.core.exceptions import FrogmlException
from tests.frogml.core.utils.frogml_exception_helpers import create_grpc_error
from tests.frogml.core.utils.frogml_exception_helpers import assert_frogml_exception


def test_build_model(frogml_services_mock):
    # Given
    automation_id = "automation_id"
    execution_id = "execution_id"
    automation_name = "automation_name"
    client = InternalBuildOrchestratorClient()
    build_initiator = BuildInitiator(
        automation=AutomationBuildInitiator(
            automation_id=automation_id,
            execution_id=execution_id,
            automation_name=automation_name,
        )
    )
    # When
    build_id = "build_id"
    client.build_model(get_build_config(build_id), build_initiator=build_initiator)
    build_init_details = (
        frogml_services_mock.internal_build_orchestrator_service._builds_requests[
            "build_id"
        ]
    )

    # Then
    assert (
        "frogml_cli"
        in build_init_details.build_spec.build_env.python_env.frogml_cli_version
    )
    assert automation_id == build_init_details.initiator.automation.automation_id
    assert execution_id == build_init_details.initiator.automation.execution_id
    assert automation_name == build_init_details.initiator.automation.automation_name


def test_build_model_without_initiator(frogml_services_mock):
    # Given
    client = InternalBuildOrchestratorClient()

    # When
    build_id = "build_id"
    client.build_model(get_build_config(build_id), cli_version="not_frogml_cli")
    build_init_details = (
        frogml_services_mock.internal_build_orchestrator_service._builds_requests[
            "build_id"
        ]
    )

    # Then
    assert build_id == build_init_details.build_spec.build_properties.build_id
    assert (
        "frogml_cli/not_frogml_cli"
        == build_init_details.build_spec.build_env.python_env.frogml_cli_version
    )


def test_build_model_with_frogml_cli_version_uses_provided_version(
    frogml_services_mock,
):
    # Given
    client = InternalBuildOrchestratorClient()

    # When
    build_id = "build_id"
    client.build_model(get_build_config(build_id), cli_version="frogml_cli/1.0.0")
    build_init_details = (
        frogml_services_mock.internal_build_orchestrator_service._builds_requests[
            "build_id"
        ]
    )

    # Then
    assert build_id == build_init_details.build_spec.build_properties.build_id
    assert (
        "frogml_cli/1.0.0"
        == build_init_details.build_spec.build_env.python_env.frogml_cli_version
    )


def get_build_config(build_id):
    config = MagicMock()
    config.build_properties.model_uri.uri = "git_uri"
    config.build_properties.model_uri.git_credentials = ""
    config.build_properties.model_uri.git_credentials_secret = "secret"
    config.build_properties.model_uri.git_branch = "main"
    config.build_properties.model_id = "model_id"
    config.build_properties.model_uri.main_dir = "main"
    config.build_properties.tags = ["one", "two"]
    config.build_env.remote.is_remote = True
    config.build_properties.build_id = build_id
    config.build_properties.build_name = "build_name"
    config.build_properties.branch = "branch"
    config.build_env.docker.env_vars = {}
    config.build_env.docker.base_image = ""
    config.build_env.docker.assumed_iam_role_arn = "assumed_iam_role_arn"
    config.build_env.docker.service_account_key_secret_name = (
        "service_account_key_secret_name"
    )
    config.to_yaml = MagicMock(return_value="")
    config.build_env.remote.resources.instance = False
    config.build_env.remote.resources.gpu_type = "NVIDIA_K80"
    config.build_env.remote.resources.gpu_amount = 1
    config.purchase_option = "spot"

    return config


def test_build_model_when_grpc_channel_unavailable_raises_frogml_exception():
    client = InternalBuildOrchestratorClient(grpc_channel_factory=lambda *args: None)

    with pytest.raises(FrogmlException) as exc:
        client.build_model(get_build_config("build_id"))

    assert_frogml_exception(
        exc.value,
        expected_error_message="Internal gRPC channel is not available",
        expected_status_code=HTTPStatus.SERVICE_UNAVAILABLE,
        expected_operation=BUILD_MODEL_OPERATION,
    )


@mock.patch(
    "frogml.core.clients.build_orchestrator.internal_client.InternalBuildsOrchestratorServiceStub"
)
def test_build_model_when_grpc_error_raises_frogml_exception(
    mock_stub: mock.MagicMock, frogml_services_mock
):
    mock_stub.return_value.BuildModel.side_effect = create_grpc_error()
    client = InternalBuildOrchestratorClient()

    with pytest.raises(FrogmlException) as exc:
        client.build_model(get_build_config("build_id"))

    assert_frogml_exception(
        exc.value,
        expected_error_message="Failed to build model: Internal error",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation=BUILD_MODEL_OPERATION,
    )


@mock.patch(
    "frogml.core.clients.build_orchestrator.internal_client.InternalBuildsOrchestratorServiceStub"
)
def test_build_model_when_general_exception_raises_frogml_exception(
    mock_stub: mock.MagicMock, frogml_services_mock
):
    mock_stub.return_value.BuildModel.side_effect = ValueError("some error")
    client = InternalBuildOrchestratorClient()

    with pytest.raises(FrogmlException) as exc:
        client.build_model(get_build_config("build_id"))

    assert_frogml_exception(
        exc.value,
        expected_error_message="Failed to build model: ValueError: some error",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation=BUILD_MODEL_OPERATION,
    )
