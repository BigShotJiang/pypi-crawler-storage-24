from frogml._proto.qwak.feature_store.jobs.v1.job_pb2 import JobState
from frogml._proto.qwak.feature_store.jobs.v1.job_service_pb2 import ApplyJobResponse
from frogml.core.clients.feature_store.job_registry_client import (
    FeatureSetsJobRegistryClient,
)

FEATURESET_ID = "featureset_id"
FEATURESET_NAME = "feature_set_name"
JOB_ID = "123"
ENVIRONMENT_ID = "111-111"


def given_job(
    client: FeatureSetsJobRegistryClient,
    featureset_id: str,
    job_id: str,
    job_state: JobState,
) -> ApplyJobResponse:
    return client.apply_job(
        featureset_id=featureset_id,
        featureset_name=FEATURESET_NAME,
        environment_id=ENVIRONMENT_ID,
        job_id=job_id,
        try_number=1,
        job_state=job_state,
        job_creation_time=None,
        job_start_time=None,
        job_end_time=None,
        ingestion_window=None,
        ingested_data_start_time=None,
        ingested_data_end_time=None,
        ingested_data_updated_rows=None,
        execution_id=None,
    )
