import uuid
from http import HTTPStatus
from typing import Callable
from unittest.mock import MagicMock

import grpc
import pytest

from frogml._proto.qwak.feature_store.jobs.v1.job_pb2 import JobRecord, JobState
from frogml._proto.qwak.feature_store.jobs.v1.job_service_pb2 import (
    GetLatestJobResponse,
    GetLatestSuccessfulJobResponse,
)
from frogml.core.clients.feature_store.job_registry_client import (
    FeatureSetsJobRegistryClient,
)
from frogml.core.exceptions import FrogmlException
from tests.frogml.core.clients.feature_set_job_registry.job_registry_utils import (
    ENVIRONMENT_ID,
)
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
    create_grpc_error,
)

# noinspection PyUnresolvedReferences


def test_get_latest_job(frogml_services_mock):
    job_registry = frogml_services_mock.job_registry_service_mock

    client = FeatureSetsJobRegistryClient()
    job_id_1 = str(uuid.uuid4())
    job_id_2 = str(uuid.uuid4())
    featureset_id = str(uuid.uuid4())

    job_registry.given_job(
        feature_set_id=featureset_id,
        job_id=job_id_1,
        job_state=JobState.RUNNING,
    )

    job_registry.given_job(
        feature_set_id=featureset_id,
        job_id=job_id_2,
        job_state=JobState.COMPLETED,
    )
    response: GetLatestJobResponse = client.get_latest_job(
        featureset_id=featureset_id,
        environment_id=ENVIRONMENT_ID,
    )
    job: JobRecord = response.job
    assert job.featureset_id == featureset_id
    assert job.job_state == JobState.COMPLETED


def test_get_latest_successful_job(frogml_services_mock):
    job_registry = frogml_services_mock.job_registry_service_mock

    client = FeatureSetsJobRegistryClient()
    job_id_1 = str(uuid.uuid4())
    job_id_2 = str(uuid.uuid4())
    featureset_id = str(uuid.uuid4())

    job_registry.given_job(
        feature_set_id=featureset_id,
        job_id=job_id_1,
        job_state=JobState.COMPLETED,
    )

    job_registry.given_job(
        feature_set_id=featureset_id,
        job_id=job_id_2,
        job_state=JobState.FAILED,
    )

    response: GetLatestSuccessfulJobResponse = client.get_latest_successful_job(
        featureset_id=featureset_id,
        environment_id=ENVIRONMENT_ID,
    )
    job: JobRecord = response.job
    assert job.job_id == job_id_1
    assert job.featureset_id == featureset_id


def test_get_latest_job_no_record(frogml_services_mock):
    client = FeatureSetsJobRegistryClient()
    with pytest.raises(Exception) as exception:
        client.get_latest_job(featureset_id="some_name", environment_id="123")
    assert type(exception.value).__class__ == FrogmlException.__class__


def test_get_latest_successful_job_no_record(frogml_services_mock):
    client = FeatureSetsJobRegistryClient()
    with pytest.raises(Exception) as exception:
        client.get_latest_successful_job(
            featureset_id="some_name", environment_id="123"
        )
    assert type(exception.value).__class__ == FrogmlException.__class__


NOT_FOUND_CUSTOM_MESSAGE_CASES = [
    pytest.param(
        "GetLatestSuccessfulJob",
        lambda c: c.get_latest_successful_job(
            featureset_id="my_fs", environment_id="env1"
        ),
        "Latest successful job not found for FeatureSet 'my_fs'",
        "Get Latest Successful Job",
        id="get_latest_successful_job",
    ),
    pytest.param(
        "GetLatestJob",
        lambda c: c.get_latest_job(featureset_id="my_fs", environment_id="env1"),
        "Latest job not found for FeatureSet 'my_fs'",
        "Get Latest Job",
        id="get_latest_job",
    ),
]


@pytest.mark.parametrize(
    "stub_method, invoke_client, expected_msg, expected_op",
    NOT_FOUND_CUSTOM_MESSAGE_CASES,
)
def test_not_found_uses_custom_message(
    stub_method: str,
    invoke_client: Callable,
    expected_msg: str,
    expected_op: str,
) -> None:
    client = FeatureSetsJobRegistryClient()
    client._job_registry = MagicMock()
    getattr(client._job_registry, stub_method).side_effect = create_grpc_error(
        code=grpc.StatusCode.NOT_FOUND, details="not found"
    )

    with pytest.raises(FrogmlException) as exc:
        invoke_client(client)

    assert_frogml_exception(
        exc.value,
        expected_error_message=expected_msg,
        expected_status_code=HTTPStatus.NOT_FOUND,
        expected_operation=expected_op,
    )
