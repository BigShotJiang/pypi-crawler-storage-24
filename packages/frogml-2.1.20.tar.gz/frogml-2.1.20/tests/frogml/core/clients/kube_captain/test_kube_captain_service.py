from frogml._proto.qwak.feature_store.entities.entity_pb2 import EntityDefinition
from frogml._proto.qwak.feature_store.features.feature_set_types_pb2 import (
    StreamingAggregationFeatureSet,
)
from frogml._proto.qwak.kube_deployment_captain.kube_deployment_captain_service_pb2 import (
    DeployStreamingAggregationCompactionRequest,
)
from frogml.core.clients.kube_deployment_captain import KubeDeploymentClient


def test_deploy_streaming_aggregation_compaction(frogml_services_mock):
    frogml_services_mock.kube_captain_service_mock.reset_service()
    feature_set_id = "feature_set_id"
    feature_set_name = "feature_set_name"
    job_run_id = 123
    environment_id = "123"
    client = KubeDeploymentClient(
        edge_services_url=f"localhost:{frogml_services_mock.port}", enable_ssl=False
    )

    client.deploy_streaming_aggregation_compaction(
        feature_set_id=feature_set_id,
        feature_set_name=feature_set_name,
        streaming_aggregation_feature_set=StreamingAggregationFeatureSet(),
        entity=EntityDefinition(),
        extra_deployment_configuration="",
        extra_env_configuration="",
        secret_service_url="",
        job_run_id=job_run_id,
        environment_id=environment_id,
    )

    service_request: DeployStreamingAggregationCompactionRequest = (
        frogml_services_mock.kube_captain_service_mock._last_deploy_streaming_aggregation_compaction_request
    )
    assert service_request.feature_set_deployment.featureset_name == feature_set_name
    assert service_request.feature_set_deployment.run_id == job_run_id
