from http import HTTPStatus
from uuid import uuid4

import grpc
import pytest

from frogml._proto.qwak.model_group.model_group_pb2 import ModelGroupBriefInfoResponse
from frogml._proto.qwak.projects.projects_pb2 import (
    CreateProjectRequest,
    CreateProjectResponse,
    GetProjectResponse,
    ProjectSpec,
)
from frogml.core.clients.model_group_management import ModelGroupManagementClient
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks
from tests.frogml.core.utils.frogml_exception_helpers import assert_frogml_exception


def test_create_if_not_exists_returns_valid_values(frogml_services_mock: FrogmlMocks):
    frogml_services_mock.model_group_management_service_mock.set_variables(
        model_group_id="model_group_id",
        model_group_description="model_group_description",
    )
    client: ModelGroupManagementClient = ModelGroupManagementClient()
    response: ModelGroupBriefInfoResponse = client.create_if_not_exists_model_group(
        project_key="project_key"
    )
    # assert request params
    assert (
        frogml_services_mock.model_group_management_service_mock.model_group_name
        == "project_key"
    )
    assert (
        frogml_services_mock.model_group_management_service_mock.jfrog_project_key
        == "project_key"
    )
    # assert response params
    assert isinstance(response, ModelGroupBriefInfoResponse)
    assert response.model_group_id == "model_group_id"
    assert response.model_group_description == "model_group_description"


def test_create_if_not_exists_raises_and_captures_request(
    frogml_services_mock: FrogmlMocks,
):
    error = grpc.RpcError(grpc.StatusCode.UNAVAILABLE, "You shell not pass")
    frogml_services_mock.model_group_management_service_mock.set_variables(
        model_group_id="model_group_id",
        model_group_description="model_group_description",
        grpc_exception=error,
    )
    client: ModelGroupManagementClient = ModelGroupManagementClient()
    # Run and assert exception
    with pytest.raises(FrogmlException) as excinfo:
        client.create_if_not_exists_model_group(project_key="project_key")

    assert_frogml_exception(
        excinfo.value,
        expected_error_message="Failed to create model",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Create Model Group",
    )
    assert "You shell not pass" in excinfo.value.error_message


@pytest.mark.parametrize("request_by", ["model_group_id", "model_group_name"])
def test_get_model_group_when_found_then_successful_details(
    request_by: str, frogml_services_mock: FrogmlMocks
):
    client = ModelGroupManagementClient()

    # Given
    model_group_name = "test_project_name"
    model_group_description = "test_project_description"
    create_model_group_response: CreateProjectResponse = (
        frogml_services_mock.project_manager_service_mock.CreateProject(
            CreateProjectRequest(
                project_name=model_group_name,
                project_description=model_group_description,
            ),
            None,
        )
    )

    # When
    model_group_spec: ProjectSpec = create_model_group_response.project
    param: dict[str, str] = {
        request_by: (
            model_group_spec.project_id
            if request_by == "model_group_id"
            else model_group_spec.project_name
        )
    }
    get_model_group_response: GetProjectResponse = client.get_model_group(**param)
    get_model_group_response_spec: ProjectSpec = get_model_group_response.project.spec

    # Then
    assert model_group_name == get_model_group_response_spec.project_name
    assert model_group_description == get_model_group_response_spec.project_description
    assert model_group_spec.project_id == get_model_group_response_spec.project_id


@pytest.mark.parametrize("request_by", ["model_group_id", "model_group_name"])
def test_get_model_group_when_not_found_then_exception(
    request_by: str, frogml_services_mock: FrogmlMocks
):
    client = ModelGroupManagementClient()

    # Given
    model_group_name = "test_project_name"
    model_group_id = str(uuid4())

    param: dict[str, str] = {
        request_by: (
            model_group_id if request_by == "model_group_id" else model_group_name
        )
    }

    with pytest.raises(FrogmlException) as exc:
        client.get_model_group(**param)

    assert_frogml_exception(
        exc.value,
        expected_error_message="Failed to get model group with model_group_id",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Get Model Group",
    )
    if request_by == "model_group_id":
        assert model_group_id in exc.value.error_message
    else:
        assert model_group_name in exc.value.error_message
