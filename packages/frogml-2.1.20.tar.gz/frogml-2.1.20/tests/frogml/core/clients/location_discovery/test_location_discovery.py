import pytest
from frogml._proto.qwak.service_discovery.service_discovery_location_pb2 import (
    ServiceLocationDescriptor,
)


@pytest.mark.parametrize(
    "method_name",
    [
        "get_distribution_manager",
        "get_analytics_engine",
        "get_metrics_gateway",
        "get_features_operator",
        "get_hosting_gateway",
    ],
)
def test_discovery_method_returns_expected_url(
    location_discovery_client, discovery_method_mocks, method_name
):
    expected_url = discovery_method_mocks[method_name][1]
    method = getattr(location_discovery_client, method_name)
    result = method()

    assert isinstance(
        result, ServiceLocationDescriptor
    ), f"{method_name} did not return a ServiceLocationDescriptor"
    assert (
        result.service_url == expected_url
    ), f"{method_name} returned URL '{result.service_url}', expected '{expected_url}'"
