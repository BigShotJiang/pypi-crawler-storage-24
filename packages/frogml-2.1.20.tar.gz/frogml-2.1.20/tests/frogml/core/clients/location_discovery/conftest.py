import pytest
from frogml.core.clients.location_discovery.client import LocationDiscoveryClient
from frogml._proto.qwak.service_discovery.service_discovery_location_pb2 import (
    ServiceLocationDescriptor,
)


@pytest.fixture
def discovery_method_mocks() -> dict:
    """Provides a mapping of discovery method names to (setter_name, expected_url)."""
    return {
        "get_distribution_manager": (
            "set_get_distribution_manager_url_response",
            "mock://distribution",
        ),
        "get_analytics_engine": (
            "set_get_analytics_engine_url_response",
            "mock://analytics",
        ),
        "get_metrics_gateway": (
            "set_get_metrics_gateway_url_response",
            "mock://metrics",
        ),
        "get_features_operator": (
            "set_get_features_operator_url_response",
            "mock://features",
        ),
        "get_hosting_gateway": (
            "set_get_hosting_gateway_url_response",
            "mock://hosting",
        ),
    }


@pytest.fixture
def location_discovery_client() -> LocationDiscoveryClient:
    return LocationDiscoveryClient()


@pytest.fixture(autouse=True)
def setup_mock_discovery_service(frogml_services_mock, discovery_method_mocks):
    """Configures the mock discovery service with one mock URL per method."""
    for _, (setter_name, url) in discovery_method_mocks.items():
        setter = getattr(frogml_services_mock.location_discovery_service, setter_name)
        setter(ServiceLocationDescriptor(service_url=url))
