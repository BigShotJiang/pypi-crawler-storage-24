from frogml._proto.qwak.auto_scaling.v1.auto_scaling_pb2 import (
    AGGREGATION_TYPE_MIN,
    METRIC_TYPE_CPU,
    AutoScalingConfig,
    PrometheusTrigger,
    QuerySpec,
    Trigger,
    Triggers,
)
from frogml.core.clients.autoscaling.client import AutoScalingClient


def test_attach_autoscaling(frogml_services_mock):
    client = AutoScalingClient()
    model_id = "model_id"
    variation = "var1"
    auto_scaling_config = AutoScalingConfig(
        min_replica_count=1,
        max_replica_count=2,
        polling_interval=60,
        cool_down_period=120,
        triggers=Triggers(
            triggers=[
                Trigger(
                    prometheus_trigger=PrometheusTrigger(
                        query_spec=QuerySpec(
                            metric_type=METRIC_TYPE_CPU,
                            aggregation_type=AGGREGATION_TYPE_MIN,
                            time_period=20,
                        )
                    )
                )
            ]
        ),
    )
    client.attach_autoscaling(
        model_id=model_id,
        variation_name=variation,
        auto_scaling_config=auto_scaling_config,
    )

    assert (
        len(frogml_services_mock.autoscaling_service_mock.autoscaling_policies.values())
        == 1
    )
    assert (
        frogml_services_mock.autoscaling_service_mock.autoscaling_policies[model_id][1]
        == auto_scaling_config
    )
