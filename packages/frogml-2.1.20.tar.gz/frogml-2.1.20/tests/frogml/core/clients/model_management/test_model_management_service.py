import pytest

from frogml._proto.qwak.models.models_pb2 import CreateModelResponse, GetModelResponse
from frogml.core.clients.model_management import ModelsManagementClient
from frogml.core.exceptions import FrogmlException
from tests.frogml.core.utils.test_create_model_verify_patched import (
    verify_patched_create_model,
)


def test_create_model(frogml_services_mock):
    # Given
    project_id = "project_id"
    model_name = "Model Name"
    expected_model_id = "model_name"
    model_description = "some description"
    client = ModelsManagementClient()

    # When
    response: CreateModelResponse = client.create_model(
        project_id=project_id,
        model_name=model_name,
        model_description=model_description,
    )

    # Then
    assert expected_model_id == response.model_id
    assert len(frogml_services_mock.model_management_service_mock.models) == 1


def test_create_model_when_jfrog_project_key_present_then_successful_single_call_to_create_model(
    frogml_services_mock,
):
    # Given
    project_id = "project_id"
    model_name = "Model Name"
    model_description = "some description"
    jfrog_project_key = "jfrog_project_key"
    client = ModelsManagementClient()

    # When + Then
    verify_patched_create_model(
        client, project_id, model_name, model_description, jfrog_project_key
    )


def test_create_model_when_jfrog_project_key_empty_then_successful_single_call_to_create_model(
    frogml_services_mock,
):
    # Given
    project_id = "project_id"
    model_name = "Model Name"
    model_description = "some description"
    jfrog_project_key = ""
    client = ModelsManagementClient()

    # When + Then
    verify_patched_create_model(
        client, project_id, model_name, model_description, jfrog_project_key
    )


def test_create_model_when_no_jfrog_project_key_then_successful_single_call_to_create_model(
    frogml_services_mock,
):
    # Given
    project_id = "project_id"
    model_name = "Model Name"
    model_description = "some description"
    jfrog_project_key = None
    client = ModelsManagementClient()

    # When + Then
    verify_patched_create_model(
        client, project_id, model_name, model_description, jfrog_project_key
    )


def test_get_model(frogml_services_mock):
    # Given
    project_id = "project_id"
    model_name = "Model Name"
    model_description = "some description"
    client = ModelsManagementClient()
    create_model_response: CreateModelResponse = client.create_model(
        project_id=project_id,
        model_name=model_name,
        model_description=model_description,
    )

    # When
    response: GetModelResponse = client.get_model(
        model_id=create_model_response.model_id
    )

    # Then
    assert create_model_response.model_id == response.model_id
    assert model_description == response.model_description
    assert project_id == response.project_id
    assert model_name == response.display_name


def test_get_model_with_exception(frogml_services_mock):
    # Given
    client = ModelsManagementClient()

    # When + Then
    with pytest.raises(Exception) as exception:
        client.get_model(
            model_id="non_existing_model",
            exception_on_missing=True,
        )
    assert type(exception.value).__class__ == FrogmlException.__class__


def test_get_model_no_exception(frogml_services_mock):
    # Given
    client = ModelsManagementClient()

    # When
    model_exists = client.get_model(
        model_id="non_existing_model",
        exception_on_missing=False,
    )

    # Then
    assert not model_exists


def test_get_model_by_uuid(frogml_services_mock):
    # Given
    project_id = "project_id"
    model_name = "Model Name"
    model_description = "some description"
    client = ModelsManagementClient()
    create_model_response: CreateModelResponse = client.create_model(
        project_id=project_id,
        model_name=model_name,
        model_description=model_description,
    )
    model_uuid = client.get_model_uuid(model_id=create_model_response.model_id)

    # When
    response: GetModelResponse = client.get_model_by_uuid(model_uuid=model_uuid)

    # Then
    assert create_model_response.model_id == response.model_id
    assert model_description == response.model_description
    assert project_id == response.project_id
    assert model_name == response.display_name


def test_get_model_by_uuid_with_exception(frogml_services_mock):
    # Given
    client = ModelsManagementClient()

    # When + Then
    with pytest.raises(Exception) as exception:
        client.get_model_by_uuid(
            model_uuid="non_existing_model",
            exception_on_missing=True,
        )
    assert type(exception.value).__class__ == FrogmlException.__class__


def test_get_model_by_uuid_no_exception(frogml_services_mock):
    # Given
    client = ModelsManagementClient()

    # When
    model_exists = client.get_model_by_uuid(
        model_uuid="non_existing_model",
        exception_on_missing=False,
    )

    # Then
    assert not model_exists


def test_delete_model(frogml_services_mock):
    # Given
    project_id = "project_id"
    model_name = "Model Name"
    model_description = "some description"
    client = ModelsManagementClient()
    create_model_response: CreateModelResponse = client.create_model(
        project_id=project_id,
        model_name=model_name,
        model_description=model_description,
    )

    # When
    client.delete_model(model_id=create_model_response.model_id, project_id=project_id)

    # Then
    assert len(frogml_services_mock.model_management_service_mock.models) == 0


def test_get_model_uuid(frogml_services_mock):
    # Given
    project_id = "project_id"
    model_name = "Model Name"
    model_description = "some description"
    client = ModelsManagementClient()
    create_model_response: CreateModelResponse = client.create_model(
        project_id=project_id,
        model_name=model_name,
        model_description=model_description,
    )

    # When
    model_uuid = client.get_model_uuid(model_id=create_model_response.model_id)

    # Then
    assert (
        frogml_services_mock.model_management_service_mock.models[
            create_model_response.model_id
        ].uuid
        == model_uuid
    )


def test_is_model_exists_when_exists(frogml_services_mock):
    # Given
    project_id = "project_id"
    model_name = "Model Name"
    model_description = "some description"
    client = ModelsManagementClient()
    create_model_response: CreateModelResponse = client.create_model(
        project_id=project_id,
        model_name=model_name,
        model_description=model_description,
    )

    # When
    model_exists = client.is_model_exists(model_id=create_model_response.model_id)

    # Then
    assert model_exists


def test_is_model_exists_when_not_exists(frogml_services_mock):
    # Given
    client = ModelsManagementClient()

    # When
    model_exists = client.is_model_exists(model_id="non_existing_model")

    # Then
    assert not model_exists


def test_get_model_metadata(frogml_services_mock):
    # Given
    project_id = "project_id"
    model_name = "Model Name"
    model_description = "some description"
    client = ModelsManagementClient()
    create_model_response: CreateModelResponse = client.create_model(
        project_id=project_id,
        model_name=model_name,
        model_description=model_description,
    )

    # When
    model_metadata_response = client.get_model_metadata(
        model_id=create_model_response.model_id
    )

    # Then
    model = model_metadata_response.model_metadata.model
    assert model.model_id == create_model_response.model_id


def test_get_model_metadata_with_exception(frogml_services_mock):
    # Given
    client = ModelsManagementClient()

    # When + Then
    with pytest.raises(Exception) as exception:
        client.get_model_metadata(model_id="throw_exception")
    assert type(exception.value).__class__ == FrogmlException.__class__
