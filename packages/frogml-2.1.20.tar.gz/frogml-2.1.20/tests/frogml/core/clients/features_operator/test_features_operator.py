import pytest
from frogml._proto.qwak.feature_store.features.feature_set_pb2 import (
    FeatureSetSpec as FeatureSetSpecProto,
)
from frogml._proto.qwak.feature_store.sources.data_source_pb2 import (
    DataSourceSpec as DataSourceSpecProto,
)
from frogml._proto.qwak.features_operator.v3.features_operator_async_service_pb2 import (
    GetValidationResultResponse,
)
from frogml._proto.qwak.features_operator.v3.features_operator_pb2 import (
    ValidationFailureResponse,
    ValidationNotReadyResponse,
    ValidationSuccessResponse,
)
from frogml.core.clients.feature_store.operator_client import (
    FeaturesOperatorClient,
    ValidationTimeoutException,
)
from frogml.core.exceptions import FrogmlException


def test_success_data_source(frogml_services_mock):
    final_result = GetValidationResultResponse(
        success_response=ValidationSuccessResponse()
    )
    client = FeaturesOperatorClient()
    response = client.validate_data_source(data_source_spec=DataSourceSpecProto())
    frogml_services_mock.features_operator_service.given_next_response(final_result)
    result = client.get_result(request_handle=response)
    assert result == final_result


def test_failure_data_source(frogml_services_mock):
    final_result = GetValidationResultResponse(
        failure_response=ValidationFailureResponse()
    )
    client = FeaturesOperatorClient()
    response = client.validate_data_source(data_source_spec=DataSourceSpecProto())
    frogml_services_mock.features_operator_service.given_next_response(final_result)
    result = client.get_result(request_handle=response)
    assert result == final_result


def test_timeout_data_source(frogml_services_mock):
    client = FeaturesOperatorClient()
    frogml_services_mock.features_operator_service.given_next_response(
        GetValidationResultResponse(not_ready_response=ValidationNotReadyResponse())
    )
    with pytest.raises(ValidationTimeoutException):
        client.validate_data_source_blocking(
            data_source_spec=DataSourceSpecProto(),
            timeout_seconds=3,
            poll_interval_seconds=1,
        )


def test_success_featureset(frogml_services_mock):
    final_result = GetValidationResultResponse(
        success_response=ValidationSuccessResponse()
    )
    client = FeaturesOperatorClient()

    response = client.validate_featureset(featureset_spec=FeatureSetSpecProto())

    frogml_services_mock.features_operator_service.given_next_response(final_result)

    result = client.get_result(request_handle=response)
    assert result == final_result


def test_failure_featureset(frogml_services_mock):
    final_result = GetValidationResultResponse(
        failure_response=ValidationFailureResponse()
    )
    client = FeaturesOperatorClient()
    response = client.validate_featureset(featureset_spec=FeatureSetSpecProto())
    frogml_services_mock.features_operator_service.given_next_response(final_result)
    result = client.get_result(request_handle=response)
    assert result == final_result


def test_timeout_featureset(frogml_services_mock):
    client = FeaturesOperatorClient()
    frogml_services_mock.features_operator_service.given_next_response(
        GetValidationResultResponse(not_ready_response=ValidationNotReadyResponse())
    )
    with pytest.raises(ValidationTimeoutException):
        client.validate_featureset_blocking(
            featureset_spec=FeatureSetSpecProto(),
            timeout_seconds=3,
            poll_interval_seconds=1,
        )


def test_blocking_featureset_success_response(frogml_services_mock):
    client = FeaturesOperatorClient()
    frogml_services_mock.features_operator_service.given_next_response(
        GetValidationResultResponse(not_ready_response=ValidationNotReadyResponse())
    )
    with pytest.raises(ValidationTimeoutException):
        client.validate_featureset_blocking(
            featureset_spec=FeatureSetSpecProto(),
            timeout_seconds=3,
            poll_interval_seconds=1,
        )

    frogml_services_mock.features_operator_service.given_next_response(
        GetValidationResultResponse(success_response=ValidationSuccessResponse())
    )

    response = client.validate_featureset_blocking(
        featureset_spec=FeatureSetSpecProto(),
        timeout_seconds=3,
        poll_interval_seconds=1,
    )

    assert isinstance(
        getattr(response, response.WhichOneof("type")), ValidationSuccessResponse
    )


def test_blocking_data_source_success_response(frogml_services_mock):
    client = FeaturesOperatorClient()
    frogml_services_mock.features_operator_service.given_next_response(
        GetValidationResultResponse(not_ready_response=ValidationNotReadyResponse())
    )
    with pytest.raises(ValidationTimeoutException):
        client.validate_data_source_blocking(
            data_source_spec=DataSourceSpecProto(),
            timeout_seconds=3,
            poll_interval_seconds=1,
        )

    frogml_services_mock.features_operator_service.given_next_response(
        GetValidationResultResponse(success_response=ValidationSuccessResponse())
    )

    response = client.validate_data_source_blocking(
        data_source_spec=DataSourceSpecProto(),
        timeout_seconds=3,
        poll_interval_seconds=1,
    )

    assert isinstance(
        getattr(response, response.WhichOneof("type")), ValidationSuccessResponse
    )


def test_validate_data_source_with_invalid_get_sample(frogml_services_mock):
    client = FeaturesOperatorClient()
    with pytest.raises(FrogmlException) as e:
        client.validate_data_source(
            data_source_spec=DataSourceSpecProto(), num_samples=-1
        )
    assert "NumberOfSamples must be between 0 and 1000, got" in str(e.value)


def test_validate_feature_set_with_invalid_get_sample(frogml_services_mock):
    client = FeaturesOperatorClient()
    with pytest.raises(FrogmlException) as e:
        client.validate_featureset_blocking(
            featureset_spec=FeatureSetSpecProto(), num_samples=-1
        )
    assert "NumberOfSamples must be between 0 and 1000, got" in str(e.value)


def test_poll_result_with_invalid_request_id(frogml_services_mock):
    client = FeaturesOperatorClient()
    with pytest.raises(FrogmlException) as e:
        client.get_result(request_handle="")
    assert "Request handle id not found" in str(e.value)
