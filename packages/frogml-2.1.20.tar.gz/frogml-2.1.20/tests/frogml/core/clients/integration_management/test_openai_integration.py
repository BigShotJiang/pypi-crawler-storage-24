from frogml.core.clients.integration_management.integration_utils import (
    IntegrationUtils,
)


def test_read_openai_integration(
    create_open_ai_system_secret: str, openai_api_key: str
):
    all_openai_keys = IntegrationUtils().get_openai_api_keys()
    assert len(all_openai_keys) == 1
    assert openai_api_key == all_openai_keys[0].get_api_key()
