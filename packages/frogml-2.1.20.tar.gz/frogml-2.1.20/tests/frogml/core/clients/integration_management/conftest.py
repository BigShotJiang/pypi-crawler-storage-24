from base64 import b64encode

import pytest

from frogml._proto.qwak.admiral.secret.v0.secret_pb2 import (
    EnvironmentSecretIdentifier,
    OpaquePairValue,
    SetSystemEnvironmentSecretOptions,
    SystemSecretSpec,
    SystemSecretValue,
)
from frogml._proto.qwak.admiral.secret.v0.system_secret_service_pb2 import (
    SetSystemSecretRequest,
)
from frogml._proto.qwak.admiral.secret.v0.system_secret_service_pb2_grpc import (
    SystemSecretServiceStub,
)
from frogml._proto.qwak.integration.integration_pb2 import Integration, IntegrationSpec
from frogml._proto.qwak.integration.integration_service_pb2 import (
    CreateIntegrationRequest,
    CreateIntegrationResponse,
)
from frogml._proto.qwak.integration.integration_service_pb2_grpc import (
    IntegrationManagementServiceStub,
)
from frogml._proto.qwak.integration.open_a_i_integration_pb2 import (
    OpenAIApiKeyAuthConfig,
    OpenAIApiKeySystemSecretDescriptor,
    OpenAIIntegrationSpec,
)
from frogml.core.clients.integration_management.integration_manager_client import (
    IntegrationManagerClient,
)
from frogml.core.clients.system_secret.system_secret_client import SystemSecretClient
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks


@pytest.fixture()
def openai_integration_name() -> str:
    return "openai_integration"


@pytest.fixture()
def openai_api_key() -> str:
    return "openai_api_key"


@pytest.fixture()
def create_openai_integration(
    frogml_services_mock: FrogmlMocks, openai_integration_name: str, openai_api_key: str
) -> str:
    client = IntegrationManagerClient()
    grpc_client: IntegrationManagementServiceStub = client._grpc_client
    openai_spec = OpenAIIntegrationSpec(
        openai_api_key_auth_config=OpenAIApiKeyAuthConfig(api_key=openai_api_key)
    )
    integration_spec = IntegrationSpec(
        name=openai_integration_name, openai_integration_spec=openai_spec
    )

    response: CreateIntegrationResponse = grpc_client.CreateIntegration(
        CreateIntegrationRequest(integration_spec=integration_spec)
    )
    return response.integration_id


@pytest.fixture()
def create_open_ai_system_secret(
    ecosystem_service_mock,
    frogml_services_mock: FrogmlMocks,
    openai_integration_name: str,
    create_openai_integration: str,
    openai_api_key: str,
    default_environment_id: str,
) -> str:
    openai_integration: Integration = IntegrationManagerClient().get_by_id(
        integration_id=create_openai_integration
    )
    openai_descriptor: OpenAIApiKeySystemSecretDescriptor = (
        openai_integration.openai_integration.openai_api_key_system_secret_descriptor
    )

    system_secret_client = SystemSecretClient()
    grpc_client: SystemSecretServiceStub = system_secret_client._grpc_client
    options = SetSystemEnvironmentSecretOptions(
        identifier=EnvironmentSecretIdentifier(
            name=openai_descriptor.secret_name, environment_id=default_environment_id
        ),
        spec=SystemSecretSpec(
            value=SystemSecretValue(
                opaque_pair=OpaquePairValue(
                    pairs={
                        openai_descriptor.api_key_secret_key: b64encode(
                            openai_api_key.encode()
                        ).decode("utf-8")
                    }
                )
            )
        ),
    )
    grpc_client.SetSystemSecret(SetSystemSecretRequest(options=options))
    yield create_openai_integration
    frogml_services_mock.system_secret_service.clear()
    frogml_services_mock.integration_management_service.clear()
