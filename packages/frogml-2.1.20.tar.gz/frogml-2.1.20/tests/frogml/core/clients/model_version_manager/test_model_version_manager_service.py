import uuid
from http import HTTPStatus
from typing import Generator, Any
from unittest import mock

import pytest
from _pytest._code import ExceptionInfo
from grpc import RpcError, StatusCode

from tests.frogml.core.utils.frogml_exception_helpers import assert_frogml_exception

from frogml._proto.jfml.model_version.v1.model_version_framework_pb2 import (
    ModelVersionFramework,
    CatboostFramework,
)
from frogml._proto.jfml.model_version.v1.model_version_manager_service_pb2 import (
    CreateModelVersionResponse,
)
from frogml.core.clients.model_version_manager import ModelVersionManagerClient
from frogml.core.clients.model_version_manager.build_model_version_dto import (
    BuildConfigDTO,
    BuildPropertiesDTO,
    BuildEnvDTO,
    DockerEnvDTO,
    PodResourcesDTO,
    TemplateSpecDTO,
    CpuResourcesDTO,
    GpuResourcesDTO,
)
from frogml.core.clients.model_version_manager.const import (
    InternalMemoryUnit,
    PurchaseOptionInternal,
    InternalGpuType,
)
from frogml.core.exceptions import FrogmlException
from frogml.storage.models.entity_manifest import Artifact, Checksums
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks


def test_create_model_version_when_all_parameters_provided_then_successful_response(
    frogml_services_mock: Generator[FrogmlMocks, Any, None],
):
    # Given
    repository_key = "my_repository"
    model_name = "my_model"
    model_version_name = "v1.0"
    catboost_framework = CatboostFramework()
    model_version_framework = ModelVersionFramework(
        catboost=catboost_framework, version="0.1"
    )
    checksums = Checksums(sha2="sha2")
    model_artifact = [
        Artifact(
            artifact_path="/path/to/model_weights.cbm",
            size=2**10,
            checksums=checksums,
        )
    ]
    dependency_artifacts = [
        Artifact(
            artifact_path="/path/to/dependency_1.zip", size=2**11, checksums=checksums
        ),
        Artifact(
            artifact_path="/path/to/dependency_2.zip", size=2**12, checksums=checksums
        ),
    ]
    code_artifacts = [
        Artifact(
            artifact_path="/path/to/source_code.zip", size=2**13, checksums=checksums
        )
    ]

    parameters = {
        "learning_rate": "0.1",
        "iterations": "1000",
        "depth": "10",
    }

    metrics = {
        "accuracy": "0.93",
        "logloss": "0.05",
    }

    # When
    response: (
        CreateModelVersionResponse
    ) = ModelVersionManagerClient().create_model_version(
        repository_key=repository_key,
        model_name=model_name,
        model_version_name=model_version_name,
        model_version_framework=model_version_framework,
        model_artifact=model_artifact,
        dependency_artifacts=dependency_artifacts,
        code_artifacts=code_artifacts,
        parameters=parameters,
        metrics=metrics,
    )

    # Then
    assert response is not None


def test_create_model_version_without_extra_params(
    frogml_services_mock: Generator[FrogmlMocks, Any, None],
):
    # Given
    repository_key = "my_repository"
    model_name = "my_model"
    model_version_name = "v1.0"
    catboost_framework = CatboostFramework()
    model_version_framework = ModelVersionFramework(
        catboost=catboost_framework, version="0.1"
    )
    checksums = Checksums(sha2="sha2")
    model_artifact = [
        Artifact(
            artifact_path="/path/to/model_weights.cbm", size=1024, checksums=checksums
        )
    ]

    # When
    response: (
        CreateModelVersionResponse
    ) = ModelVersionManagerClient().create_model_version(
        repository_key=repository_key,
        model_name=model_name,
        model_version_name=model_version_name,
        model_version_framework=model_version_framework,
        model_artifact=model_artifact,
    )

    # Then
    assert response is not None


def test_promote_to_build_with_model_version_id_successful_response(
    frogml_services_mock: Generator[FrogmlMocks, Any, None],
):
    # Given
    model_version_id = "mv_123456"
    build_config = BuildConfigDTO(
        build_properties=BuildPropertiesDTO(
            build_name="test-build",
            tags=["tag1", "tag2"],
            gpu_compatible=True,
        ),
        build_env=BuildEnvDTO(
            docker_env=DockerEnvDTO(
                base_image="python:3.9",
                cache=False,
            )
        ),
        pod_resources=PodResourcesDTO(
            template_spec=TemplateSpecDTO(template_id="template-123")
        ),
        verbose=1,
        environment_id="env-123",
        purchase_option=PurchaseOptionInternal.ONDEMAND,
    )

    # When
    build_id: str = ModelVersionManagerClient().promote_to_build(
        build_config=build_config, model_version_id=model_version_id
    )

    # Then
    try:
        uuid.UUID(hex=build_id, version=4)
    except (ValueError, TypeError) as e:
        raise AssertionError(f"build_id '{build_id}' is not a valid UUID") from e


def test_promote_to_build_with_model_id_and_version_name_successful_response(
    frogml_services_mock: Generator[FrogmlMocks, Any, None],
):
    # Given
    model_id = "model_123"
    model_version_name = "v1.0"
    build_config = BuildConfigDTO(
        build_properties=BuildPropertiesDTO(
            build_name="cpu-build",
            gpu_compatible=False,
        ),
        build_env=BuildEnvDTO(
            docker_env=DockerEnvDTO(
                base_image="ubuntu:20.04",
                cache=True,
            )
        ),
        pod_resources=PodResourcesDTO(
            cpu_resources=CpuResourcesDTO(
                cpu=2.0,
                memory_amount=4,
                memory_units=InternalMemoryUnit.GIB,
            )
        ),
        purchase_option=PurchaseOptionInternal.SPOT,
    )

    # When
    build_id: str = ModelVersionManagerClient().promote_to_build(
        build_config=build_config,
        model_id=model_id,
        model_version_name=model_version_name,
    )

    # Then
    try:
        uuid.UUID(hex=build_id, version=4)
    except (ValueError, TypeError) as e:
        raise AssertionError(f"build_id '{build_id}' is not a valid UUID") from e


def test_promote_to_build_with_gpu_resources_successful_response(
    frogml_services_mock: Generator[FrogmlMocks, Any, None],
):
    # Given
    model_version_id = "mv_789"
    build_config = BuildConfigDTO(
        build_properties=BuildPropertiesDTO(
            build_name="gpu-build",
            tags=["gpu", "training"],
            gpu_compatible=True,
        ),
        pod_resources=PodResourcesDTO(
            gpu_resources=GpuResourcesDTO(
                gpu_type=InternalGpuType.NVIDIA_T4,
                gpu_amount=2,
            )
        ),
        verbose=2,
    )

    # When
    build_id: str = ModelVersionManagerClient().promote_to_build(
        build_config=build_config, model_version_id=model_version_id
    )

    # Then
    try:
        uuid.UUID(hex=build_id, version=4)
    except (ValueError, TypeError) as e:
        raise AssertionError(f"build_id '{build_id}' is not a valid UUID") from e


def test_promote_to_build_missing_required_parameters_raises_exception(
    frogml_services_mock: Generator[FrogmlMocks, Any, None],
):
    # Given
    build_config = BuildConfigDTO(
        pod_resources=PodResourcesDTO(
            template_spec=TemplateSpecDTO(template_id="template-123")
        )
    )

    # When & Then
    with pytest.raises(FrogmlException) as exc_info:
        ModelVersionManagerClient().promote_to_build(build_config=build_config)

    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Either model_version_id must be provided, or both model_id and model_version_name must be provided",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="Promote Model Version",
    )


def test_promote_to_build_partial_parameters_raises_exception(
    frogml_services_mock: Generator[FrogmlMocks, Any, None],
):
    # Given
    build_config = BuildConfigDTO(
        pod_resources=PodResourcesDTO(
            template_spec=TemplateSpecDTO(template_id="template-123")
        )
    )

    client = ModelVersionManagerClient()

    # When & Then - only model_id provided
    with pytest.raises(FrogmlException) as exc_info:
        client.promote_to_build(build_config=build_config, model_id="model_123")

    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Either model_version_id must be provided, or both model_id and model_version_name must be provided",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="Promote Model Version",
    )

    # When & Then - only model_version_name provided
    with pytest.raises(FrogmlException) as exc_info:
        client.promote_to_build(build_config=build_config, model_version_name="v1.0")

    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Either model_version_id must be provided, or both model_id and model_version_name must be provided",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="Promote Model Version",
    )


def test_promote_to_build_minimal_config(
    frogml_services_mock: Generator[FrogmlMocks, Any, None],
):
    # Given
    model_version_id = "mv_minimal"
    build_config = BuildConfigDTO(
        pod_resources=PodResourcesDTO(
            template_spec=TemplateSpecDTO(template_id="minimal-template")
        )
    )

    # When
    build_id: str = ModelVersionManagerClient().promote_to_build(
        build_config=build_config, model_version_id=model_version_id
    )

    # Then
    try:
        uuid.UUID(hex=build_id, version=4)
    except (ValueError, TypeError) as e:
        raise AssertionError(f"build_id '{build_id}' is not a valid UUID") from e


@mock.patch(
    "frogml.core.clients.model_version_manager.client.ModelVersionManagerServiceStub"
)
def test_promote_to_build_when_grpc_error_raises_frogml_exception(
    mock_stub: mock.MagicMock,
):
    # Given
    e: RpcError = RpcError()
    e.code = lambda: StatusCode.UNAVAILABLE
    e.details = lambda: "details"
    e.debug_error_string = lambda: "gRPC error"

    mock_stub.return_value.PromoteModelVersionToBuild.side_effect = e

    exc_info: ExceptionInfo[FrogmlException] = execute_promote_to_build_with_exception()
    # Then
    mock_stub.return_value.PromoteModelVersionToBuild.assert_called_once()
    assert "Failed to promote model version" in exc_info.value.error_message


@mock.patch(
    "frogml.core.clients.model_version_manager.client.ModelVersionManagerServiceStub"
)
def test_promote_to_build_when_general_exception_raises_frogml_exception(
    mock_stub: mock.MagicMock,
):
    # Given
    mock_stub.return_value.PromoteModelVersionToBuild.side_effect = Exception(
        "General error"
    )

    exc_info: ExceptionInfo[FrogmlException] = execute_promote_to_build_with_exception()
    # Then
    mock_stub.return_value.PromoteModelVersionToBuild.assert_called_once()
    assert "Failed to promote model version" in exc_info.value.error_message


def execute_promote_to_build_with_exception() -> ExceptionInfo[FrogmlException]:
    model_version_id: str = "mv_error"
    build_config: BuildConfigDTO = BuildConfigDTO(
        pod_resources=PodResourcesDTO(
            template_spec=TemplateSpecDTO(template_id="template-123")
        )
    )
    # When
    with pytest.raises(FrogmlException) as exc_info:
        ModelVersionManagerClient().promote_to_build(
            build_config=build_config, model_version_id=model_version_id
        )
    return exc_info
