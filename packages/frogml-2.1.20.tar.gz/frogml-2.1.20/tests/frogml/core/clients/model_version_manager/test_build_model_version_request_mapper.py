import pytest

from frogml._proto.jfml.model_version.v1.build_spec_pb2 import BuildSpec
from frogml._proto.qwak.fitness_service.fitness_pb2 import PurchaseOption
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    GpuType,
    MemoryUnit,
)


from frogml.core.clients.model_version_manager.build_model_version_dto import (
    BuildConfigDTO,
    BuildPropertiesDTO,
    BuildEnvDTO,
    DockerEnvDTO,
    PodResourcesDTO,
    TemplateSpecDTO,
    CpuResourcesDTO,
    GpuResourcesDTO,
)
from frogml.core.clients.model_version_manager.build_model_version_request_mapper import (
    map_build_conf_to_build_spec,
)
from frogml.core.clients.model_version_manager.const import (
    InternalMemoryUnit,
    PurchaseOptionInternal,
    InternalGpuType,
)
from frogml.core.exceptions import FrogmlException


def test_map_build_conf_to_build_spec_with_template_spec():
    """Test mapping with template spec pod resources"""
    build_conf = BuildConfigDTO(
        build_properties=BuildPropertiesDTO(
            build_name="test-build", tags=["tag1", "tag2"], gpu_compatible=True
        ),
        build_env=BuildEnvDTO(
            docker_env=DockerEnvDTO(base_image="python:3.9", cache=False)
        ),
        pod_resources=PodResourcesDTO(
            template_spec=TemplateSpecDTO(template_id="template-123")
        ),
        verbose=1,
        environment_id="env-123",
        purchase_option=PurchaseOptionInternal.ONDEMAND,
    )

    result = map_build_conf_to_build_spec(build_conf)

    assert isinstance(result, BuildSpec)
    assert result.build_properties.build_name == "test-build"
    assert result.build_properties.tags == ["tag1", "tag2"]
    assert result.build_properties.gpu_compatible is True
    assert result.build_env.docker_env.base_image == "python:3.9"
    assert result.build_env.docker_env.no_cache is True  # negated cache value
    assert result.verbose == 1
    assert result.environment_id == "env-123"
    assert result.purchase_option == PurchaseOption.ONDEMAND_PURCHASE_OPTION
    assert result.pod_resources.HasField("template_spec")
    assert result.pod_resources.template_spec.template_id == "template-123"


@pytest.mark.parametrize(
    "memory_unit_internal, memory_unit_proto",
    [
        (None, MemoryUnit.INVALID_MEMORY_UNIT),
        (InternalMemoryUnit.GIB, MemoryUnit.GIB),
        (InternalMemoryUnit.MIB, MemoryUnit.MIB),
    ],
)
def test_map_build_conf_to_build_spec_with_cpu_resources(
    memory_unit_internal: InternalMemoryUnit, memory_unit_proto: MemoryUnit
):
    """Test mapping with CPU resources"""
    build_conf = BuildConfigDTO(
        build_properties=BuildPropertiesDTO(
            build_name="cpu-build", gpu_compatible=False
        ),
        build_env=BuildEnvDTO(
            docker_env=DockerEnvDTO(base_image="ubuntu:20.04", cache=True)
        ),
        pod_resources=PodResourcesDTO(
            cpu_resources=CpuResourcesDTO(
                cpu=2.0, memory_amount=4, memory_units=memory_unit_internal
            )
        ),
        purchase_option=PurchaseOptionInternal.SPOT,
    )

    result = map_build_conf_to_build_spec(build_conf)

    assert result.build_properties.build_name == "cpu-build"
    assert result.build_properties.gpu_compatible is False
    assert result.build_env.docker_env.base_image == "ubuntu:20.04"
    assert result.build_env.docker_env.no_cache is False
    assert result.purchase_option == PurchaseOption.SPOT_PURCHASE_OPTION
    assert result.pod_resources.HasField("cpu_resources")
    assert result.pod_resources.cpu_resources.cpu == 2
    assert result.pod_resources.cpu_resources.memory_amount == 4
    assert result.pod_resources.cpu_resources.memory_units == memory_unit_proto


@pytest.mark.parametrize(
    "gpu_type_internal, gpu_type_proto",
    [
        (None, GpuType.INVALID_GPU_TYPE),
        (InternalGpuType.NVIDIA_K80, GpuType.NVIDIA_K80),
        (InternalGpuType.NVIDIA_V100, GpuType.NVIDIA_V100),
        (InternalGpuType.NVIDIA_A100, GpuType.NVIDIA_A100),
        (InternalGpuType.NVIDIA_T4, GpuType.NVIDIA_T4),
        (InternalGpuType.NVIDIA_A10G, GpuType.NVIDIA_A10G),
        (InternalGpuType.NVIDIA_L4, GpuType.NVIDIA_L4),
        (InternalGpuType.NVIDIA_T4_1_4_15, GpuType.NVIDIA_T4_1_4_15),
        (InternalGpuType.NVIDIA_T4_1_8_30, GpuType.NVIDIA_T4_1_8_30),
        (InternalGpuType.NVIDIA_T4_1_16_60, GpuType.NVIDIA_T4_1_16_60),
        (
            InternalGpuType.NVIDIA_A100_80GB_8_96_1360,
            GpuType.NVIDIA_A100_80GB_8_96_1360,
        ),
        (InternalGpuType.NVIDIA_V100_1_8_52, GpuType.NVIDIA_V100_1_8_52),
        (InternalGpuType.NVIDIA_V100_4_32_208, GpuType.NVIDIA_V100_4_32_208),
    ],
)
def test_map_build_conf_to_build_spec_with_gpu_resources(
    gpu_type_internal: InternalGpuType, gpu_type_proto: GpuType
):
    """Test mapping with GPU resources"""
    build_conf = BuildConfigDTO(
        build_properties=BuildPropertiesDTO(
            build_name="gpu-build", tags=["gpu", "training"], gpu_compatible=True
        ),
        build_env=BuildEnvDTO(
            docker_env=DockerEnvDTO(base_image="tensorflow/tensorflow:latest-gpu")
        ),
        pod_resources=PodResourcesDTO(
            gpu_resources=GpuResourcesDTO(gpu_type=gpu_type_internal, gpu_amount=2)
        ),
        verbose=2,
    )

    result = map_build_conf_to_build_spec(build_conf)

    assert result.build_properties.build_name == "gpu-build"
    assert result.build_properties.tags == ["gpu", "training"]
    assert result.build_properties.gpu_compatible is True
    assert result.verbose == 2
    assert result.pod_resources.HasField("gpu_resources")
    assert result.pod_resources.gpu_resources.gpu_type == gpu_type_proto
    assert result.pod_resources.gpu_resources.gpu_amount == 2


def test_map_build_conf_to_build_spec_minimal_config():
    """Test mapping with minimal configuration"""
    build_conf = BuildConfigDTO(
        pod_resources=PodResourcesDTO(
            template_spec=TemplateSpecDTO(template_id="minimal-template")
        )
    )

    result = map_build_conf_to_build_spec(build_conf)

    assert result.HasField("build_properties") is False
    assert result.HasField("build_env") is False
    assert result.verbose == 3
    assert result.environment_id == ""
    assert result.purchase_option == PurchaseOption.INVALID_PURCHASE_OPTION
    assert result.pod_resources.HasField("template_spec") is True


def test_map_build_conf_dto_no_pod_resources_raises_exception():
    """Test that missing pod resources raises an exception"""
    with pytest.raises(FrogmlException) as exc_info:
        BuildConfigDTO(
            build_properties=BuildPropertiesDTO(build_name="test"),
            pod_resources=PodResourcesDTO(),  # No resources specified
        )

    assert (
        "Exactly one of template_spec, cpu_resources, or gpu_resources must be set"
        in str(exc_info.value)
    )


def test_map_build_conf_dto_multiple_pod_resources_raises_exception():
    """Test that multiple pod resources raises an exception"""
    with pytest.raises(FrogmlException) as exc_info:
        BuildConfigDTO(
            build_properties=BuildPropertiesDTO(build_name="test"),
            pod_resources=PodResourcesDTO(
                template_spec=TemplateSpecDTO(template_id="template-123"),
                gpu_resources=GpuResourcesDTO(
                    gpu_type=InternalGpuType.NVIDIA_K80, gpu_amount=2
                ),
            ),  # Multiple resources specified
        )

    assert (
        "Exactly one of template_spec, cpu_resources, or gpu_resources must be set"
        in str(exc_info.value)
    )


def test_empty_tags_list():
    """Test that empty tags list is handled correctly"""
    build_conf = BuildConfigDTO(
        build_properties=BuildPropertiesDTO(
            build_name="test", tags=[], gpu_compatible=False  # Empty tags
        ),
        pod_resources=PodResourcesDTO(
            template_spec=TemplateSpecDTO(template_id="test")
        ),
    )

    result = map_build_conf_to_build_spec(build_conf)
    assert result.build_properties.tags == []
