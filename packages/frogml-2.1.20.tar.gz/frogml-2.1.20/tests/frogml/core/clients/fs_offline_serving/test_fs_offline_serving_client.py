from datetime import datetime

import pytest
from frogml.core.clients.feature_store.offline_serving_client import (
    FeatureValuesTimeoutException,
    FsOfflineServingClient,
)
from frogml.core.exceptions.frogml_exception import FrogmlException
from frogml.core.utils.datetime_utils import datetime_to_pts
from frogml._proto.qwak.offline.serving.v1.offline_serving_async_service_pb2 import (
    FileFormat as ProtoFileFormat,
    GetFeatureValuesResultResponse as ProtoGetFeatureValuesResultResponse,
    GetFileUploadUrlResponse as ProtoGetFileUploadUrlResponse,
)
from frogml._proto.qwak.offline.serving.v1.options_pb2 import (
    OfflineServingQueryOptions as ProtoOfflineServingQueryOptions,
)
from frogml._proto.qwak.service_discovery.service_discovery_location_pb2 import (
    ServiceLocationDescriptor,
)
from pytest_lazy_fixtures import lf


@pytest.mark.parametrize(
    "expected_result,given_query_options",
    [
        (
            lf("success_get_feature_values_result"),
            lf("offline_serving_query_options_include_version"),
        ),
        (
            lf("success_get_feature_values_result"),
            lf("offline_serving_query_options_dont_include_version"),
        ),
        (
            lf("failure_get_feature_values_result"),
            lf("offline_serving_query_options_include_version"),
        ),
        (
            lf("cancelled_get_feature_values_result"),
            lf("offline_serving_query_options_include_version"),
        ),
    ],
)
def test_get_feature_values_blocking_terminal(
    frogml_services_mock,
    fs_offline_serving_client,
    featureset_features_proto_list,
    timed_population_proto,
    expected_result,
    given_query_options: ProtoOfflineServingQueryOptions,
):
    frogml_services_mock.fs_offline_serving_service.given_next_response(expected_result)

    actual: ProtoGetFeatureValuesResultResponse = (
        fs_offline_serving_client.get_feature_values_blocking(
            features=featureset_features_proto_list,
            population=timed_population_proto,
            result_file_format=ProtoFileFormat.FILE_FORMAT_CSV,
            options=given_query_options,
        )
    )

    assert actual == expected_result


def test_get_feature_values_blocking_pending(
    frogml_services_mock,
    fs_offline_serving_client,
    featureset_features_proto_list,
    timed_population_proto,
    pending_get_feature_values_result,
    offline_serving_query_options_include_version,
):
    frogml_services_mock.fs_offline_serving_service.given_next_response(
        pending_get_feature_values_result
    )

    with pytest.raises(FeatureValuesTimeoutException):
        fs_offline_serving_client.get_feature_values_blocking(
            features=featureset_features_proto_list,
            population=timed_population_proto,
            result_file_format=ProtoFileFormat.FILE_FORMAT_CSV,
            timeout_seconds=3,
            poll_interval_seconds=1,
            options=offline_serving_query_options_include_version,
        )


@pytest.mark.parametrize(
    "expected_result,given_query_options",
    [
        (
            lf("success_get_feature_values_result"),
            lf("offline_serving_query_options_include_version"),
        ),
        (
            lf("success_get_feature_values_result"),
            lf("offline_serving_query_options_dont_include_version"),
        ),
        (
            lf("failure_get_feature_values_result"),
            lf("offline_serving_query_options_include_version"),
        ),
        (
            lf("cancelled_get_feature_values_result"),
            lf("offline_serving_query_options_dont_include_version"),
        ),
    ],
)
def test_get_feature_values_in_range_blocking_terminal(
    frogml_services_mock,
    fs_offline_serving_client,
    featureset_features_1_proto,
    population_proto,
    expected_result,
    given_query_options: ProtoOfflineServingQueryOptions,
):
    frogml_services_mock.fs_offline_serving_service.given_next_response(expected_result)

    actual: ProtoGetFeatureValuesResultResponse = (
        fs_offline_serving_client.get_feature_values_in_range_blocking(
            features=featureset_features_1_proto,
            lower_time_bound=datetime_to_pts(datetime(2023, 1, 1)),
            upper_time_bound=datetime_to_pts(datetime(2024, 1, 1)),
            population=population_proto,
            result_file_format=ProtoFileFormat.FILE_FORMAT_CSV,
            options=given_query_options,
        )
    )

    assert actual == expected_result


def test_get_feature_values_in_range_blocking_pending(
    frogml_services_mock,
    fs_offline_serving_client,
    featureset_features_1_proto,
    population_proto,
    pending_get_feature_values_result,
    offline_serving_query_options_dont_include_version: ProtoOfflineServingQueryOptions,
):
    frogml_services_mock.fs_offline_serving_service.given_next_response(
        pending_get_feature_values_result
    )

    with pytest.raises(FeatureValuesTimeoutException):
        fs_offline_serving_client.get_feature_values_in_range_blocking(
            features=featureset_features_1_proto,
            lower_time_bound=datetime_to_pts(datetime(2023, 1, 1)),
            upper_time_bound=datetime_to_pts(datetime(2024, 1, 1)),
            population=population_proto,
            result_file_format=ProtoFileFormat.FILE_FORMAT_CSV,
            timeout_seconds=1,
            options=offline_serving_query_options_dont_include_version,
        )


def test_upload_file_url(frogml_services_mock, fs_offline_serving_client):
    response = ProtoGetFileUploadUrlResponse(file_upload_url="blabla")
    frogml_services_mock.fs_offline_serving_service.given_next_file_upload_url(response)

    actual: str = fs_offline_serving_client.get_population_file_upload_url()
    assert actual == response.file_upload_url


def test_get_offline_serving_url(frogml_services_mock, fs_offline_serving_client):
    expected_url = "mock-url"
    response = ServiceLocationDescriptor(service_url="mock-url")
    frogml_services_mock.location_discovery_service.set_get_offline_serving_url_response(
        response
    )

    result = fs_offline_serving_client._get_offline_serving_url()
    assert result == expected_url


def test_get_client_with_invalid_url(frogml_services_mock):
    frogml_services_mock.location_discovery_service.set_get_offline_serving_url_response(
        ServiceLocationDescriptor(service_url="")
    )
    with pytest.raises(FrogmlException):
        FsOfflineServingClient()
