from typing import List

import grpc
import pytest
from frogml.core.clients.feature_store.offline_serving_client import (
    FsOfflineServingClient,
)
from frogml._proto.qwak.offline.serving.v1.feature_values_pb2 import (
    FeaturesetFeatures as ProtoFeaturesetFeatures,
)
from frogml._proto.qwak.offline.serving.v1.offline_serving_async_service_pb2 import (
    FailureReason as ProtoFailureReason,
    FeatureValuesRequestStatus as ProtoFeatureValuesRequestStatus,
    GetFeatureValuesResultResponse as ProtoGetFeatureValuesResultResponse,
    LinkToFiles as ProtoLinkToFiles,
)
from frogml._proto.qwak.offline.serving.v1.population_pb2 import (
    ArrowSchemaJson as ProtoArrowSchemaJson,
    Population as ProtoPopulation,
    PopulationFile as ProtoPopulationFile,
    TimedPopulation as ProtoTimedPopulation,
)


@pytest.fixture
def fs_offline_serving_client(frogml_services_mock) -> FsOfflineServingClient:
    port = frogml_services_mock.port
    channel = grpc.insecure_channel(f"localhost: {port}")
    return FsOfflineServingClient(grpc_channel=channel)


@pytest.fixture
def featureset_features_1_proto() -> ProtoFeaturesetFeatures:
    return ProtoFeaturesetFeatures(
        featureset_name="fs_1", feature_names=["feature_1", "feature_2"]
    )


@pytest.fixture
def featureset_features_2_proto() -> ProtoFeaturesetFeatures:
    return ProtoFeaturesetFeatures(
        featureset_name="fs_2", feature_names=["feature_1", "feature_2"]
    )


@pytest.fixture
def featureset_features_proto_list(
    featureset_features_1_proto, featureset_features_2_proto
) -> List[ProtoFeaturesetFeatures]:
    return [featureset_features_1_proto, featureset_features_2_proto]


@pytest.fixture
def population_proto() -> ProtoPopulation:
    return ProtoPopulation(
        population_file=ProtoPopulationFile(
            file_url="http://blabla",
            arrow_schema_json=ProtoArrowSchemaJson(schema='{"entity": "string"}'),
        )
    )


@pytest.fixture
def timed_population_proto(population_proto: ProtoPopulation) -> ProtoTimedPopulation:
    return ProtoTimedPopulation(population=population_proto)


@pytest.fixture
def success_get_feature_values_result():
    link_to_files = [
        "/resources/success_get_feature_values_part_1.csv",
        "/resources/success_get_feature_values_part_2.csv",
    ]
    return ProtoGetFeatureValuesResultResponse(
        status=ProtoFeatureValuesRequestStatus.FEATURE_VALUES_REQUEST_STATUS_SUCCEEDED,
        link_to_files=ProtoLinkToFiles(link_to_files=link_to_files),
    )


@pytest.fixture
def failure_get_feature_values_result():
    return ProtoGetFeatureValuesResultResponse(
        status=ProtoFeatureValuesRequestStatus.FEATURE_VALUES_REQUEST_STATUS_FAILED,
        failure_reason=ProtoFailureReason(message="blabla"),
    )


@pytest.fixture
def cancelled_get_feature_values_result():
    return ProtoGetFeatureValuesResultResponse(
        status=ProtoFeatureValuesRequestStatus.FEATURE_VALUES_REQUEST_STATUS_CANCELLED,
    )


@pytest.fixture
def pending_get_feature_values_result():
    return ProtoGetFeatureValuesResultResponse(
        status=ProtoFeatureValuesRequestStatus.FEATURE_VALUES_REQUEST_STATUS_PENDING,
    )
