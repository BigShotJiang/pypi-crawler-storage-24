from http import HTTPStatus
from unittest.mock import MagicMock

import grpc
import pytest
from google.protobuf.struct_pb2 import Struct

from frogml._proto.qwak.admiral.user_application_instance.v0.user_application_instance_pb2 import (
    Identifier,
)
from frogml._proto.qwak.admiral.user_application_instance.v0.user_application_instance_service_pb2 import (
    GetUserApplicationInstanceResponse,
)
from frogml._proto.qwak.user_application.v0.user_application_pb2 import Spec, Type
from frogml.core.clients.user_application_instance.client import (
    UserApplicationInstanceClient,
)
from frogml.core.exceptions import FrogmlException
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
    create_grpc_error,
)


def _assert_indetifier(
    identifier: Identifier, name: str, account_id: str, environment_id: str
):
    assert identifier.name == name
    assert identifier.account_id == account_id
    assert identifier.environment_id == environment_id


def test_create_user_application_instance(frogml_services_mock):
    environment_id = "123"
    account_id = "111"
    name = "batch-featureset"
    user_application_type = Type.BATCH_FEATURE_PROCESSOR
    client = UserApplicationInstanceClient()
    spec = Struct()
    spec.update({"key": "value"})
    client.create_user_application_instance(
        account_id=account_id,
        environment_id=environment_id,
        name=name,
        spec=Spec(value=spec),
        kind_sem_version=None,
        type=user_application_type,
    )
    response = client.get_user_application_instance(
        account_id=account_id,
        environment_id=environment_id,
        name=name,
        type=user_application_type,
    )
    _assert_indetifier(
        response.description.metadata.identifier,
        name=name,
        account_id=account_id,
        environment_id=environment_id,
    )

    assert response.description.spec_description.spec.value == spec


def test_create_user_application_instance_which_already_exists(frogml_services_mock):
    environment_id = "123"
    account_id = "111"
    name = "batch-featureset"
    spec = Struct()
    spec.update({"key": "value"})
    user_application_type = Type.BATCH_FEATURE_PROCESSOR
    client = UserApplicationInstanceClient()
    client.create_user_application_instance(
        account_id=account_id,
        environment_id=environment_id,
        name=name,
        spec=Spec(value=spec),
        kind_sem_version=None,
        type=user_application_type,
    )
    with pytest.raises(Exception) as exception:
        client.create_user_application_instance(
            account_id=account_id,
            environment_id=environment_id,
            name=name,
            spec=Spec(),
            kind_sem_version=None,
            type=user_application_type,
        )
    assert exception.type.__class__ == FrogmlException.__class__


def test_update_none_existing_user_application_instance(frogml_services_mock):
    environment_id = "123"
    account_id = "111"
    name = "batch-featureset"
    user_application_type = Type.BATCH_FEATURE_PROCESSOR
    client = UserApplicationInstanceClient()
    with pytest.raises(Exception) as exception:
        client.update_user_application_instance(
            account_id=account_id,
            environment_id=environment_id,
            name=name,
            type=user_application_type,
            spec=Spec(),
            current_spec_revision=1,
        )
    assert exception.type.__class__ == FrogmlException.__class__


def test_update_user_application_instance(frogml_services_mock):
    environment_id = "123"
    account_id = "111"
    name = "batch-featureset"
    user_application_type = Type.BATCH_FEATURE_PROCESSOR
    spec = Struct()
    spec.update({"key": "value"})
    client = UserApplicationInstanceClient()
    client.create_user_application_instance(
        account_id=account_id,
        environment_id=environment_id,
        name=name,
        spec=Spec(value=spec),
        kind_sem_version=None,
        type=user_application_type,
    )
    updated_spec = Struct()
    updated_spec.update({"key1": "value1"})
    client.update_user_application_instance(
        account_id=account_id,
        environment_id=environment_id,
        name=name,
        type=user_application_type,
        spec=Spec(value=updated_spec),
        current_spec_revision=1,
    )
    response = client.get_user_application_instance(
        account_id=account_id,
        environment_id=environment_id,
        name=name,
        type=user_application_type,
    )
    _assert_indetifier(
        response.description.metadata.identifier,
        name=name,
        account_id=account_id,
        environment_id=environment_id,
    )
    actual_spec = response.description.spec_description.spec.value
    assert actual_spec == updated_spec


def test_delete_user_application_instance(frogml_services_mock):
    environment_id = "123"
    account_id = "111"
    name = "batch-featureset"
    user_application_type = Type.BATCH_FEATURE_PROCESSOR
    spec = Struct()
    spec.update({"key": "value"})
    client = UserApplicationInstanceClient()
    client.create_user_application_instance(
        account_id=account_id,
        environment_id=environment_id,
        name=name,
        spec=Spec(value=spec),
        kind_sem_version=None,
        type=user_application_type,
    )
    client.delete_user_application_instance(
        account_id=account_id,
        environment_id=environment_id,
        name=name,
        type=user_application_type,
    )
    response = client.get_user_application_instance(
        account_id=account_id,
        environment_id=environment_id,
        name=name,
        type=user_application_type,
    )
    assert response == GetUserApplicationInstanceResponse()


def test_delete_none_existing_user_application_instance(frogml_services_mock):
    environment_id = "123"
    account_id = "111"
    name = "batch-featureset"
    user_application_type = Type.BATCH_FEATURE_PROCESSOR
    spec = Struct()
    spec.update({"key": "value"})
    client = UserApplicationInstanceClient()
    with pytest.raises(Exception) as exception:
        client.delete_user_application_instance(
            account_id=account_id,
            environment_id=environment_id,
            name=name,
            type=user_application_type,
        )
    assert exception.type.__class__ == FrogmlException.__class__


def test_get_none_existing_user_application_instance(frogml_services_mock):
    environment_id = "123"
    account_id = "111"
    name = "batch-featureset"
    user_application_type = Type.BATCH_FEATURE_PROCESSOR
    spec = Struct()
    spec.update({"key": "value"})
    client = UserApplicationInstanceClient()
    response = client.get_user_application_instance(
        account_id=account_id,
        environment_id=environment_id,
        name=name,
        type=user_application_type,
    )
    assert response == GetUserApplicationInstanceResponse()


GET_USER_APP_INSTANCE_ERROR_CASES = [
    pytest.param(
        grpc.StatusCode.NOT_FOUND,
        "User application instance 'my-app' was not found",
        HTTPStatus.NOT_FOUND,
        id="not_found",
    ),
    pytest.param(
        grpc.StatusCode.INTERNAL,
        "Failed to get user application instance 'my-app'",
        HTTPStatus.INTERNAL_SERVER_ERROR,
        id="internal_error",
    ),
]


@pytest.mark.parametrize(
    "grpc_code, expected_msg, expected_status",
    GET_USER_APP_INSTANCE_ERROR_CASES,
)
def test_get_user_application_instance_grpc_error_raises_frogml_exception(
    grpc_code: grpc.StatusCode,
    expected_msg: str,
    expected_status: HTTPStatus,
) -> None:
    client = UserApplicationInstanceClient()
    client._user_application_instance_service = MagicMock()
    client._user_application_instance_service.GetUserApplicationInstance = MagicMock(
        side_effect=create_grpc_error(code=grpc_code, details="error")
    )

    with pytest.raises(FrogmlException) as exc:
        client.get_user_application_instance(
            account_id="acc1",
            environment_id="env1",
            name="my-app",
            type=Type.BATCH_FEATURE_PROCESSOR,
        )

    assert_frogml_exception(
        exc.value,
        expected_error_message=expected_msg,
        expected_status_code=expected_status,
        expected_operation="Get User Application Instance",
    )
