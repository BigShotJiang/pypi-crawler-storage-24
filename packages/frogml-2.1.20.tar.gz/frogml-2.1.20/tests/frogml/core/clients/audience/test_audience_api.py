from typing import List

from frogml._proto.qwak.audience.v1.audience_pb2 import Audience, AudienceEntry
from frogml.core.clients.audience import AudienceClient


def test_create_automation(frogml_services_mock):
    # Given
    client = AudienceClient()
    name = "audience name"
    description = "audience description"
    audience = Audience(name=name, description=description)

    # When
    audience_id = client.create_audience(audience=audience)

    # Then
    assert len(frogml_services_mock.audience_api_mock.audiences) == 1
    assert audience_id in frogml_services_mock.audience_api_mock.audiences.keys()
    assert frogml_services_mock.audience_api_mock.audiences[audience_id] == audience


def test_get_automation(frogml_services_mock):
    # Given
    client = AudienceClient()
    name = "audience name"
    description = "audience description"
    audience = Audience(name=name, description=description)
    audience_id = client.create_audience(audience=audience)

    # When
    audience_returned = client.get_audience(audience_id=audience_id)

    # Then
    assert audience == audience_returned


def test_delete_automation(frogml_services_mock):
    # Given
    client = AudienceClient()
    name = "audience name"
    description = "audience description"
    audience = Audience(name=name, description=description)
    audience_id = client.create_audience(audience=audience)

    # When
    client.delete_audience(audience_id=audience_id)

    # Then
    assert len(frogml_services_mock.audience_api_mock.audiences) == 0


def test_update_automation(frogml_services_mock):
    # Given
    client = AudienceClient()
    name = "audience name"
    description = "audience description"
    audience = Audience(name=name, description=description)
    updated_audience = Audience(name=name, description="Updated audience")
    audience_id = client.create_audience(audience=audience)

    # When
    client.update_audience(audience_id=audience_id, audience=updated_audience)

    # Then
    assert len(frogml_services_mock.audience_api_mock.audiences) == 1
    assert audience_id in frogml_services_mock.audience_api_mock.audiences.keys()
    assert (
        frogml_services_mock.audience_api_mock.audiences[audience_id]
        == updated_audience
    )


def test_list_automation(frogml_services_mock):
    # Given
    client = AudienceClient()
    name1 = "audience name 1"
    name2 = "audience name 2"
    description1 = "audience description1"
    description2 = "audience description2"
    audience1 = Audience(name=name1, description=description1)
    audience2 = Audience(name=name2, description=description2)
    audience1_id = client.create_audience(audience=audience1)
    audience2_id = client.create_audience(audience=audience2)

    # When
    result: List[AudienceEntry] = client.list_audience()

    # Then
    assert len(result) == 2
    first_audience_entry = list(filter(lambda e: e.id == audience1_id, result))[0]
    second_audience_entry = list(filter(lambda e: e.id == audience2_id, result))[0]
    assert first_audience_entry.audience == audience1
    assert second_audience_entry.audience == audience2
