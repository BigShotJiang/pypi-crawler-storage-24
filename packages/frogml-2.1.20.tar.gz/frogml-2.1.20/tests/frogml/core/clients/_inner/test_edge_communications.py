from http import HTTPStatus
from unittest.mock import MagicMock, patch

import pytest

from frogml.core.clients._inner.edge_communications import get_endpoint_url
from frogml.core.exceptions import FrogmlException
from tests.frogml.core.utils.frogml_exception_helpers import assert_frogml_exception


@patch("frogml.core.clients._inner.edge_communications.EcosystemClient")
def test_get_endpoint_url_raises_when_environment_not_found(
    mock_ecosystem_client: MagicMock,
) -> None:
    user = MagicMock()
    user.account_details.default_environment_id = "default_env"
    user.account_details.environment_by_id = {"default_env": MagicMock()}
    mock_ecosystem_client.return_value.get_authenticated_user_context.return_value.user = (
        user
    )
    with pytest.raises(FrogmlException) as exc_info:
        get_endpoint_url(endpoint_url=None, environment_id="missing_env")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Configuration for environment 'missing_env' was not found",
        expected_status_code=HTTPStatus.NOT_FOUND,
        expected_operation="Get Endpoint URL",
    )
