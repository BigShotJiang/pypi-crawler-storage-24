from http import HTTPStatus
from unittest.mock import MagicMock

import grpc
import pytest

from frogml._proto.qwak.deployment.deployment_pb2 import (
    EnvironmentDeploymentDetailsMessage,
    EnvironmentDeploymentMessage,
    EnvironmentDeploymentResultMessage,
    EnvironmentRuntimeDeploymentSettingsResultMessage,
    EnvironmentUndeploymentMessage,
    HostingService,
    KubeDeployment,
    KubeDeploymentType,
    ModelDeploymentStatus,
    RealTimeConfig,
    ServingStrategy,
    TrafficConfig,
    TrafficSpec,
    Variation,
)
from frogml._proto.qwak.deployment.deployment_service_pb2 import (
    ApplyModelTrafficResponse,
    DeployModelResponse,
    GetDeploymentDetailsResponse,
    GetDeploymentStatusResponse,
    GetModelTrafficResponse,
    UndeployModelResponse,
    UpdateDeploymentRuntimeSettingsResponse,
)
from frogml.core.clients.deployment.client import DeploymentManagementClient
from frogml.core.exceptions import FrogmlException, FrogmlNotFoundException
from frogml_services_mock.mocks.deployment_management_service import (
    DEPLOYMENT_ALREADY_RUNNING_MESSAGE,
    FAILED_TO_UNDEPLOY_DEPLOYMENT_IN_PROGRESS,
    FAILED_TO_UNDEPLOY_NO_ACTIVE_DEPLOYMENT,
)
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
    create_grpc_error,
)


def test_deploy_model(frogml_services_mock: FrogmlMocks) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    variation = "variation"
    realtime_hosting_service = HostingService(
        kube_deployment=KubeDeployment(
            kube_deployment_type=KubeDeploymentType.ONLINE,
            serving_strategy=ServingStrategy(
                realtime_config=RealTimeConfig(
                    traffic_config=TrafficConfig(selected_variation_name=variation)
                )
            ),
        )
    )
    env_deployment_messages = {
        env1: EnvironmentDeploymentMessage(
            model_id=model_id,
            model_uuid=model_uuid,
            build_id=build_id,
            hosting_service=realtime_hosting_service,
        )
    }
    deploy_response: DeployModelResponse = client.deploy_model(
        model_id=model_id,
        build_id=build_id,
        env_deployment_messages=env_deployment_messages,
    )
    assert env1 in deploy_response.environment_to_deployment_result
    env_deploy_response: EnvironmentDeploymentResultMessage = (
        deploy_response.environment_to_deployment_result[env1]
    )
    assert env_deploy_response.status == ModelDeploymentStatus.INITIATING_DEPLOYMENT
    assert not env_deploy_response.info
    deployment_details = (
        frogml_services_mock.deployment_management_service_mock.get_deployment_by_id(
            env_deploy_response.deployment_named_id
        )
    )
    assert deployment_details
    assert realtime_hosting_service == deployment_details["hosting_service"]


def test_deploy_model_in_progress(frogml_services_mock: FrogmlMocks) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    variation = "variation"
    realtime_hosting_service = HostingService(
        kube_deployment=KubeDeployment(
            kube_deployment_type=KubeDeploymentType.ONLINE,
            serving_strategy=ServingStrategy(
                realtime_config=RealTimeConfig(
                    traffic_config=TrafficConfig(selected_variation_name=variation)
                )
            ),
        )
    )
    env_deployment_messages = {
        env1: EnvironmentDeploymentMessage(
            model_id=model_id,
            model_uuid=model_uuid,
            build_id=build_id,
            hosting_service=realtime_hosting_service,
        )
    }
    client.deploy_model(
        model_id=model_id,
        build_id=build_id,
        env_deployment_messages=env_deployment_messages,
    )
    deploy_response: DeployModelResponse = client.deploy_model(
        model_id=model_id,
        build_id=build_id,
        env_deployment_messages=env_deployment_messages,
    )
    assert env1 in deploy_response.environment_to_deployment_result
    env_deploy_response: EnvironmentDeploymentResultMessage = (
        deploy_response.environment_to_deployment_result[env1]
    )
    assert (
        env_deploy_response.status == ModelDeploymentStatus.FAILED_INITIATING_DEPLOYMENT
    )
    assert DEPLOYMENT_ALREADY_RUNNING_MESSAGE in env_deploy_response.info
    deployment_details = (
        frogml_services_mock.deployment_management_service_mock.get_deployment_by_id(
            env_deploy_response.deployment_named_id
        )
    )
    assert deployment_details is None


def test_undeploy_model(frogml_services_mock: FrogmlMocks) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    variation = "variation"
    __given_deployed_model(
        frogml_services_mock, model_id, model_uuid, build_id, env1, variation
    )
    env_undeployment_requests = {
        env1: EnvironmentUndeploymentMessage(
            model_id=model_id,
            model_uuid=model_uuid,
            variation_name=variation,
            traffic_config=TrafficConfig(),
        )
    }
    undeploy_response: UndeployModelResponse = client.undeploy_model(
        model_id=model_id,
        model_uuid=model_uuid,
        env_undeployment_requests=env_undeployment_requests,
    )
    assert env1 in undeploy_response.environment_to_undeployment_result
    env_undeploy_response: EnvironmentUndeploymentMessage = (
        undeploy_response.environment_to_undeployment_result[env1]
    )
    assert env_undeploy_response.status == ModelDeploymentStatus.SUCCESSFUL_UNDEPLOYMENT
    assert not env_undeploy_response.info


def test_undeploy_in_running_deployment_model(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    variation = "variation"
    __given_deployed_model(
        frogml_services_mock,
        model_id,
        model_uuid,
        build_id,
        env1,
        variation,
        advance_to_successful=False,
    )
    env_undeployment_requests = {
        env1: EnvironmentUndeploymentMessage(
            model_id=model_id,
            model_uuid=model_uuid,
            variation_name=variation,
            traffic_config=TrafficConfig(),
        )
    }
    undeploy_response: UndeployModelResponse = client.undeploy_model(
        model_id=model_id,
        model_uuid=model_uuid,
        env_undeployment_requests=env_undeployment_requests,
    )
    assert env1 in undeploy_response.environment_to_undeployment_result
    env_undeploy_response: EnvironmentUndeploymentMessage = (
        undeploy_response.environment_to_undeployment_result[env1]
    )
    assert env_undeploy_response.status == ModelDeploymentStatus.FAILED_UNDEPLOYMENT
    assert env_undeploy_response.info == FAILED_TO_UNDEPLOY_DEPLOYMENT_IN_PROGRESS


def test_undeploy_non_deployed_model(frogml_services_mock: FrogmlMocks) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    env1 = "env1"
    variation = "variation"
    env_undeployment_requests = {
        env1: EnvironmentUndeploymentMessage(
            model_id=model_id,
            model_uuid=model_uuid,
            variation_name=variation,
            traffic_config=TrafficConfig(),
        )
    }
    undeploy_response: UndeployModelResponse = client.undeploy_model(
        model_id=model_id,
        model_uuid=model_uuid,
        env_undeployment_requests=env_undeployment_requests,
    )
    assert env1 in undeploy_response.environment_to_undeployment_result
    env_undeploy_response: EnvironmentUndeploymentMessage = (
        undeploy_response.environment_to_undeployment_result[env1]
    )
    assert env_undeploy_response.status == ModelDeploymentStatus.FAILED_UNDEPLOYMENT
    assert env_undeploy_response.info == FAILED_TO_UNDEPLOY_NO_ACTIVE_DEPLOYMENT


def test_get_deployment_status(frogml_services_mock: FrogmlMocks) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    variation = "variation"
    result = __given_deployed_model(
        frogml_services_mock,
        model_id,
        model_uuid,
        build_id,
        env1,
        variation,
        advance_to_successful=False,
    )
    env_result = result.environment_to_deployment_result[env1]
    deployment_status: GetDeploymentStatusResponse = client.get_deployment_status(
        deployment_named_id=env_result.deployment_named_id
    )
    assert deployment_status.status == env_result.status


def test_get_deployment_status_on_historic(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    variation = "variation"
    result = __given_deployed_model(
        frogml_services_mock, model_id, model_uuid, build_id, env1, variation
    )
    __undeploy_model(model_id, model_uuid, variation, env1)
    env_result = result.environment_to_deployment_result[env1]
    deployment_status: GetDeploymentStatusResponse = client.get_deployment_status(
        deployment_named_id=env_result.deployment_named_id
    )
    assert deployment_status.status == ModelDeploymentStatus.SUCCESSFUL_UNDEPLOYMENT


def test_get_deployment_status_non_existing(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = DeploymentManagementClient()
    deployment_status: GetDeploymentStatusResponse = client.get_deployment_status(
        deployment_named_id="123"
    )
    assert deployment_status.status == ModelDeploymentStatus.SUCCESSFUL_UNDEPLOYMENT


def test_get_deployment_details_empty(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = DeploymentManagementClient()
    deployments_details: GetDeploymentDetailsResponse = client.get_deployment_details(
        model_id="model", model_uuid="model_uuid"
    )
    assert not dict(deployments_details.environment_to_deployment_details)


def test_get_deployment_details(frogml_services_mock: FrogmlMocks) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    variation = "variation"
    deploy_model_response = __given_deployed_model(
        frogml_services_mock, model_id, model_uuid, build_id, env1, variation
    )
    deployment_id = deploy_model_response.environment_to_deployment_result.get(
        env1
    ).deployment_named_id
    deployments_details: GetDeploymentDetailsResponse = client.get_deployment_details(
        model_id=model_id, model_uuid=model_uuid
    )
    details_result = dict(deployments_details.environment_to_deployment_details)
    assert env1 in details_result
    env1_details_result: EnvironmentDeploymentDetailsMessage = details_result[env1]
    assert len(env1_details_result.deployments_details) == 1
    assert env1_details_result.deployments_details[0].build_id == build_id
    assert env1_details_result.deployments_details[0].deployment_id == deployment_id


def test_get_deployment_details_missing_model_uuid_and_branch_id_raises() -> None:
    client = DeploymentManagementClient()
    with pytest.raises(FrogmlException) as exc_info:
        client.get_deployment_details(model_id="model_id", model_uuid="")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Missing argument model uuid or branch id",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="Get Deployment Details",
    )


def test_get_deployment_details_rpc_error_raises_frogml_exception() -> None:
    client = DeploymentManagementClient()
    client.deployment_management = MagicMock()
    client.deployment_management.GetDeploymentDetails = MagicMock(
        side_effect=create_grpc_error(
            code=grpc.StatusCode.NOT_FOUND, details="model not found"
        )
    )
    with pytest.raises(FrogmlException) as exc_info:
        client.get_deployment_details(model_id="model_id", model_uuid="model_uuid")
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Failed to get model status for model model_id",
        expected_status_code=HTTPStatus.NOT_FOUND,
        expected_operation="Get Deployment Details",
    )


def test_get_deployed_variations_to_build_id_no_deployments_raises_frogml_not_found() -> (
    None
):
    client = DeploymentManagementClient()
    client.deployment_management = MagicMock()
    client.get_deployment_details = MagicMock(return_value=None)
    with pytest.raises(FrogmlNotFoundException) as exc_info:
        client.get_deployed_variations_to_build_id(
            model_id="model_123", model_uuid="branch_456"
        )
    assert_frogml_exception(
        exc_info.value,
        expected_error_message="There are currently no deployed variations for model model_123",
        expected_status_code=HTTPStatus.NOT_FOUND,
        expected_operation="Get Deployed Variations",
    )


def test_get_deployment_history(frogml_services_mock: FrogmlMocks) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    variation = "variation"
    deploy_model_response = __given_deployed_model(
        frogml_services_mock, model_id, model_uuid, build_id, env1, variation
    )
    deployment_id = deploy_model_response.environment_to_deployment_result.get(
        env1
    ).deployment_named_id
    deployments_history: GetDeploymentDetailsResponse = client.get_deployment_history(
        model_uuid=model_uuid
    )
    assert deployments_history.deployments[0].build_id == build_id
    assert deployments_history.deployments[0].deployment_id == deployment_id


def test_update_deployment_runtime_settings(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    variation = "variation"
    __given_deployed_model(
        frogml_services_mock, model_id, model_uuid, build_id, env1, variation
    )
    result: UpdateDeploymentRuntimeSettingsResponse = (
        client.update_runtime_configurations(
            model_id=model_id, model_uuid=model_uuid, log_level="INFO"
        )
    )
    update_results = dict(result.environment_to_runtime_deployment_settings_response)
    assert env1 in update_results
    env1_update_result: EnvironmentRuntimeDeploymentSettingsResultMessage = (
        update_results[env1]
    )
    assert not env1_update_result.error_info


def test_update_deployment_runtime_settings_no_model(
    frogml_services_mock: FrogmlMocks,
) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    env1 = "env1"
    result: UpdateDeploymentRuntimeSettingsResponse = (
        client.update_runtime_configurations(
            model_id=model_id, model_uuid=model_uuid, log_level="INFO"
        )
    )
    update_results = dict(result.environment_to_runtime_deployment_settings_response)
    assert env1 not in update_results


def test_apply_traffic(frogml_services_mock: FrogmlMocks) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    env2 = "env2"
    variation = "variation"
    percentage = 30
    __given_deployed_model(
        frogml_services_mock, model_id, model_uuid, build_id, env1, variation
    )
    __given_deployed_model(
        frogml_services_mock, model_id, model_uuid, build_id, env2, variation
    )
    result: ApplyModelTrafficResponse = client.apply_model_traffic_config(
        model_id=model_id,
        requested_variations=[
            Variation(name=variation, traffic=TrafficSpec(percentage=percentage))
        ],
        environment_ids=[env1, env2],
    )

    assert env1 in result.environment_to_apply_model_traffic_response
    assert env2 in result.environment_to_apply_model_traffic_response
    assert not result.environment_to_apply_model_traffic_response[env1].info
    assert not result.environment_to_apply_model_traffic_response[env2].info


def test_get_model_traffic(frogml_services_mock: FrogmlMocks) -> None:
    client = DeploymentManagementClient()
    model_id = "model_id"
    model_uuid = "model_uuid"
    build_id = "build_id"
    env1 = "env1"
    env2 = "env2"
    variation = "variation"
    __given_deployed_model(
        frogml_services_mock, model_id, model_uuid, build_id, env1, variation
    )
    __given_deployed_model(
        frogml_services_mock, model_id, model_uuid, build_id, env2, variation
    )
    result: GetModelTrafficResponse = client.get_model_traffic_config(model_id=model_id)

    assert env1 in result.environment_to_model_traffic
    assert env2 in result.environment_to_model_traffic
    assert len(result.environment_to_model_traffic[env1].variations) == 1
    assert len(result.environment_to_model_traffic[env2].variations) == 1


def __given_deployed_model(
    frogml_services_mock: FrogmlMocks,
    model_id: str,
    model_uuid: str,
    build_id: str,
    env: str,
    variation: str,
    advance_to_successful: bool = True,
):
    client = DeploymentManagementClient()
    realtime_hosting_service = HostingService(
        kube_deployment=KubeDeployment(
            kube_deployment_type=KubeDeploymentType.ONLINE,
            serving_strategy=ServingStrategy(
                realtime_config=RealTimeConfig(
                    traffic_config=TrafficConfig(
                        selected_variation_name=variation,
                        variations=[
                            Variation(
                                name=variation, traffic=TrafficSpec(percentage=100)
                            )
                        ],
                    )
                )
            ),
        )
    )
    env_deployment_messages = {
        env: EnvironmentDeploymentMessage(
            model_id=model_id,
            model_uuid=model_uuid,
            build_id=build_id,
            hosting_service=realtime_hosting_service,
        )
    }
    deploy_response: DeployModelResponse = client.deploy_model(
        model_id=model_id,
        build_id=build_id,
        env_deployment_messages=env_deployment_messages,
    )

    if advance_to_successful:
        frogml_services_mock.deployment_management_service_mock.mark_deployment_successful(
            model_id=model_id, variation=variation, env=env
        )

    return deploy_response


def __undeploy_model(
    model_id: str, model_uuid: str, variation: str, env: str
) -> UndeployModelResponse:
    client = DeploymentManagementClient()
    env_undeployment_requests = {
        env: EnvironmentUndeploymentMessage(
            model_id=model_id,
            model_uuid=model_uuid,
            variation_name=variation,
            traffic_config=TrafficConfig(),
        )
    }
    return client.undeploy_model(
        model_id=model_id,
        model_uuid=model_uuid,
        env_undeployment_requests=env_undeployment_requests,
    )
