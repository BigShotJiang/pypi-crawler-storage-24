from typing import Callable

import pytest
from frogml._proto.qwak.feature_store.sources.batch_pb2 import BatchSource
from frogml._proto.qwak.feature_store.sources.data_source_pb2 import (
    DataSourceDefinition,
    DataSourceSpec,
)


@pytest.fixture
def given_batch_data_source(
    featureset_registry_client,
) -> Callable[[str], DataSourceDefinition]:
    def create(name: str) -> DataSourceDefinition:
        return featureset_registry_client.create_data_source(
            DataSourceSpec(
                batch_source=BatchSource(
                    name=name,
                    date_created_column="timestamp",
                ),
            )
        ).data_source.data_source_definition

    return create
