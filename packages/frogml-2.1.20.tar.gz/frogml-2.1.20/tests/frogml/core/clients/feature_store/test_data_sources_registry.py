from typing import Callable

import pytest
from frogml._proto.qwak.feature_store.sources.data_source_pb2 import (
    DataSourceDefinition,
)
from frogml.core.clients.feature_store import FeatureRegistryClient
from frogml.core.exceptions import FrogmlException


def test_delete_batch_data_source(
    frogml_services_mock, given_batch_data_source: Callable[[str], DataSourceDefinition]
):
    client = FeatureRegistryClient()
    ds_name_to_delete = "ds_to_delete"

    ds_definition = given_batch_data_source(ds_name_to_delete)
    given_batch_data_source("ds_not_to_delete")
    client.delete_data_source(ds_definition.data_source_id)

    assert any(
        ds.data_source_definition.data_source_id != ds_definition.data_source_id
        for ds in client.list_data_sources().data_sources
    )


def test_delete_non_existing_data_source(frogml_services_mock):
    client = FeatureRegistryClient()
    ds_name_to_delete = "non_existing_ds"

    with pytest.raises(FrogmlException) as e:
        client.delete_data_source(ds_name_to_delete)

    assert "Failed to delete data source" in e.value.error_message
