from typing import Callable, List

import pytest
from frogml._proto.qwak.feature_store.features.feature_set_pb2 import (
    FeatureSetDefinition,
    FeaturesetInfo,
)
from frogml.core.clients.feature_store import FeatureRegistryClient
from frogml.core.exceptions import FrogmlException


def test_delete_feature_set(
    frogml_services_mock, given_batch_feature_set: Callable[[str], FeatureSetDefinition]
):
    client = FeatureRegistryClient()
    fs_name_to_delete = "fs_to_delete"

    fs_definition = given_batch_feature_set(fs_name_to_delete)
    given_batch_feature_set("fs_not_to_delete")
    client.delete_feature_set(fs_definition.feature_set_id)

    assert any(
        [
            fs
            for fs in client.list_feature_sets().feature_families
            if fs.feature_set_definition.feature_set_spec.name != fs_name_to_delete
        ]
    )


def test_delete_non_existing_feature_set(frogml_services_mock):
    client = FeatureRegistryClient()
    fs_name_to_delete = "non_existing_fs"

    with pytest.raises(FrogmlException) as e:
        client.delete_feature_set(fs_name_to_delete)

    assert "Failed to delete feature" in e.value.error_message


def test_delete_non_existing_entity(frogml_services_mock):
    client = FeatureRegistryClient()
    fs_name_to_delete = "non_existing_fs"

    with pytest.raises(FrogmlException) as e:
        client.delete_entity(fs_name_to_delete)

    assert "Failed to delete entity" in e.value.error_message


def test_list_features(
    frogml_services_mock,
    given_batch_feature_set: Callable[[str], FeatureSetDefinition],
    given_streaming_feature_set: Callable[[str], FeatureSetDefinition],
):
    client = FeatureRegistryClient()

    # Given
    feature_set_batch: FeatureSetDefinition = given_batch_feature_set(
        "test_batch_feature"
    )
    feature_set_streaming: FeatureSetDefinition = given_streaming_feature_set(
        "test-streaming-feature"
    )

    # When
    actual_feature_list = client.list_feature_sets().feature_families

    # Then
    assert [
        fs.feature_set_definition.feature_set_spec.name for fs in actual_feature_list
    ] == [
        feature_set_batch.feature_set_spec.name,
        feature_set_streaming.feature_set_spec.name,
    ]


def test_list_featureset_versions(
    frogml_services_mock,
    given_batch_feature_set: Callable[[str], FeatureSetDefinition],
    given_update_batch_feature_set: Callable[[str], FeatureSetDefinition],
):
    client = FeatureRegistryClient()

    # Given
    name = "test_batch_feature"
    given_batch_feature_set(name)
    given_update_batch_feature_set(name)

    # When
    actual_featureset_list: List[FeaturesetInfo] = client.list_featureset_versions(
        name
    ).featuresets

    # Then
    assert [
        fs.featureset_definition.featureset_version_number
        for fs in actual_featureset_list
    ] == [1, 2]
