from http import HTTPStatus
from typing import Callable
from unittest.mock import MagicMock

import pytest

from frogml.core.clients.instance_template.client import (
    InstanceTemplateManagementClient,
)
from frogml.core.exceptions import FrogmlException
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks
from tests.frogml.core.utils.frogml_exception_helpers import (
    assert_frogml_exception,
)


def test_list_instance_template(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    client = InstanceTemplateManagementClient()

    # When
    templates = client.list_instance_templates()

    # Then
    assert len(templates) == len(
        frogml_services_mock.instance_templates_service.INSTANCES.values()
    )


def test_get_instance_template(frogml_services_mock: FrogmlMocks) -> None:
    # Given
    client = InstanceTemplateManagementClient()
    template_id = list(
        frogml_services_mock.instance_templates_service.INSTANCES.values()
    )[0].id

    # When
    template = client.get_instance_template(template_id)

    # Then
    assert template.id == template_id


GENERIC_EXCEPTION_CASES = [
    pytest.param(
        "GetInstanceTemplate",
        lambda c: c.get_instance_template(instance_template_id="tid"),
        "Failed to get instance template",
        "Get Instance Template",
        id="get",
    ),
    pytest.param(
        "ListInstanceTemplates",
        lambda c: c.list_instance_templates(),
        "Failed to list instance templates",
        "List Instance Templates",
        id="list",
    ),
]


@pytest.mark.parametrize(
    "stub_method, invoke_client, expected_msg, expected_op",
    GENERIC_EXCEPTION_CASES,
)
def test_generic_exception_raises_frogml_exception(
    stub_method: str,
    invoke_client: Callable,
    expected_msg: str,
    expected_op: str,
) -> None:
    client = InstanceTemplateManagementClient()
    client._instance_template_service = MagicMock()
    getattr(client._instance_template_service, stub_method).side_effect = Exception(
        "generic failure"
    )
    with pytest.raises(FrogmlException) as exc_info:
        invoke_client(client)
    assert_frogml_exception(
        exc_info.value,
        expected_error_message=expected_msg,
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation=expected_op,
    )
