from frogml._proto.qwak.deployment.alert_pb2 import (
    NotificationChannelSettings,
    SlackSettings,
)
from frogml.core.clients.alert_management.client import AlertsManagementClient


def test_apply_channel(frogml_services_mock):
    client = AlertsManagementClient()
    channel1_name = "test1"
    url1 = "url1"

    client.configure_channel(
        channel_name=channel1_name,
        notification_settings=NotificationChannelSettings(
            slack_settings=SlackSettings(url=url1)
        ),
    )

    assert (
        len(
            frogml_services_mock.alert_manager_service_mock.notification_channels.values()
        )
        == 1
    )
    notification_channel = list(
        frogml_services_mock.alert_manager_service_mock.notification_channels.values()
    )[0]
    assert notification_channel.notification_channel_name == channel1_name
    assert notification_channel.notification_settings.slack_settings.url == url1


def test_delete_channel(frogml_services_mock):
    client = AlertsManagementClient()
    channel1_name = "test1"
    url1 = "url1"

    client.configure_channel(
        channel_name=channel1_name,
        notification_settings=NotificationChannelSettings(
            slack_settings=SlackSettings(url=url1)
        ),
    )
    notification = list(
        frogml_services_mock.alert_manager_service_mock.notification_channels.values()
    )[0]
    client.delete_channel(notification_channel_id=notification.notification_channel_id)

    assert (
        len(
            frogml_services_mock.alert_manager_service_mock.notification_channels.values()
        )
        == 0
    )


def test_list_channels(frogml_services_mock):
    client = AlertsManagementClient()
    channel1_name = "test1"
    channel2_name = "test2"
    url1 = "url1"
    url2 = "url2"

    client.configure_channel(
        channel_name=channel1_name,
        notification_settings=NotificationChannelSettings(
            slack_settings=SlackSettings(url=url1)
        ),
    )
    client.configure_channel(
        channel_name=channel2_name,
        notification_settings=NotificationChannelSettings(
            slack_settings=SlackSettings(url=url2)
        ),
    )
    assert (
        len(
            frogml_services_mock.alert_manager_service_mock.notification_channels.values()
        )
        == 2
    )

    result = client.list_channels()
    assert len(result.notification_channels) == 2
    assert (
        len(
            list(
                filter(
                    lambda notification: notification.notification_channel_name
                    == channel1_name,
                    result.notification_channels,
                )
            )
        )
        == 1
    )
    assert (
        len(
            list(
                filter(
                    lambda notification: notification.notification_channel_name
                    == channel2_name,
                    result.notification_channels,
                )
            )
        )
        == 1
    )
