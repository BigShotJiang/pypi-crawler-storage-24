from types import TracebackType
from unittest.mock import MagicMock, patch

import pytest

from frogml.core.exceptions import FrogmlException, _quiet_hook


def test_frogml_exception_suppresses_traceback(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """FrogmlException should print formatted message without traceback."""
    ex = FrogmlException(error_message="Something failed", operation="Test")

    _quiet_hook(FrogmlException, ex, None)

    captured = capsys.readouterr()
    assert "Error: Test Failed" in captured.out
    assert "Message: Something failed" in captured.out


@patch("sys.__excepthook__")
def test_non_frogml_exception_calls_default_hook(mock_excepthook: MagicMock) -> None:
    """Non-FrogmlException should delegate to sys.__excepthook__."""
    ex = ValueError("value error")
    mock_tb = MagicMock(spec=TracebackType)

    _quiet_hook(ValueError, ex, mock_tb)

    mock_excepthook.assert_called_once_with(ValueError, ex, mock_tb)
