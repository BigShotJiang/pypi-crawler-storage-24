from http import HTTPStatus

from frogml.core.exceptions import FrogmlGeneralBuildException
from tests.frogml.core.utils.frogml_exception_helpers import assert_frogml_exception


def test_without_source_exception():
    ex = FrogmlGeneralBuildException(error_message="Build failed")

    assert_frogml_exception(
        ex,
        expected_error_message="Build failed",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Build",
    )


def test_with_source_exception():
    source_error = ValueError("invalid config")
    ex = FrogmlGeneralBuildException(
        error_message="Build failed", src_exception=source_error
    )

    assert_frogml_exception(
        ex,
        expected_error_message="Build failed: invalid config",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Build",
    )


def test_with_custom_status_code():
    ex = FrogmlGeneralBuildException(
        error_message="Build failed", status_code=HTTPStatus.BAD_REQUEST
    )

    assert_frogml_exception(
        ex,
        expected_error_message="Build failed",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="Build",
    )
