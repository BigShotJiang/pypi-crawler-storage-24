from http import HTTPStatus

import pytest

from frogml.core.exceptions import FrogmlException
from tests.frogml.core.utils.frogml_exception_helpers import (
    FrogmlExceptionTestCase,
    assert_frogml_exception,
)


EXCEPTION_TEST_CASES: list[FrogmlExceptionTestCase] = [
    FrogmlExceptionTestCase(
        test_name="defaults",
        error_message="Something went wrong",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="FrogML Operation",
    ),
    FrogmlExceptionTestCase(
        test_name="with_status_code",
        error_message="Not found",
        status_code=HTTPStatus.NOT_FOUND,
        expected_status_code=HTTPStatus.NOT_FOUND,
        expected_operation="FrogML Operation",
    ),
    FrogmlExceptionTestCase(
        test_name="with_operation",
        error_message="Error",
        operation="Delete Model",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="Delete Model",
    ),
    FrogmlExceptionTestCase(
        test_name="with_all_params",
        error_message="Custom error",
        status_code=HTTPStatus.BAD_REQUEST,
        operation="Create Model",
        expected_status_code=HTTPStatus.BAD_REQUEST,
        expected_operation="Create Model",
    ),
]


def get_test_case_id(test_case: FrogmlExceptionTestCase) -> str:
    return test_case.test_name


@pytest.mark.parametrize("test_case", EXCEPTION_TEST_CASES, ids=get_test_case_id)
def test_exception_properties(test_case: FrogmlExceptionTestCase) -> None:
    kwargs: dict[str, str | int] = {"error_message": test_case.error_message}
    if test_case.status_code is not None:
        kwargs["status_code"] = test_case.status_code
    if test_case.operation is not None:
        kwargs["operation"] = test_case.operation

    ex = FrogmlException(**kwargs)

    assert_frogml_exception(
        ex,
        expected_error_message=test_case.error_message,
        expected_status_code=test_case.expected_status_code,
        expected_operation=test_case.expected_operation,
    )


def test_str_returns_simple_message() -> None:
    ex = FrogmlException(
        error_message="Model not found",
        status_code=HTTPStatus.NOT_FOUND,
        operation="Get Model",
    )
    result = str(ex)

    assert result == "Model not found"


def test_repr_returns_developer_friendly_representation() -> None:
    ex = FrogmlException(
        error_message="Model not found",
        status_code=HTTPStatus.NOT_FOUND,
        operation="Get Model",
    )
    result = repr(ex)

    assert "FrogmlException(" in result
    assert "error_message='Model not found'" in result
    assert "status_code=404" in result
    assert "operation='Get Model'" in result


def test_formatted_message_returns_formatted_block() -> None:
    ex = FrogmlException(
        error_message="Model not found",
        status_code=HTTPStatus.NOT_FOUND,
        operation="Get Model",
    )
    result = ex.formatted_message()

    assert "Error: Get Model" in result
    assert "404 Not Found" in result
    assert "Message: Model not found" in result


def test_formatted_message_unknown_status_code() -> None:
    ex = FrogmlException(error_message="Error", status_code=999)
    result = ex.formatted_message()

    assert "999" in result


def test_can_be_raised_and_caught() -> None:
    with pytest.raises(FrogmlException) as exc_info:
        raise FrogmlException(error_message="Test error")

    assert_frogml_exception(
        exc_info.value,
        expected_error_message="Test error",
        expected_status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        expected_operation="FrogML Operation",
    )
