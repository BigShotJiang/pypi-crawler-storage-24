from http import HTTPStatus
from typing import Optional

import grpc
import pytest

from frogml.core.exceptions.grpc_status_mapping import grpc_to_http_status

CLIENT_CLOSED_REQUEST_STATUS: int = 499


@pytest.mark.parametrize(
    "grpc_code,expected_http",
    [
        (grpc.StatusCode.OK, HTTPStatus.OK),
        (grpc.StatusCode.CANCELLED, CLIENT_CLOSED_REQUEST_STATUS),
        (grpc.StatusCode.INVALID_ARGUMENT, HTTPStatus.BAD_REQUEST),
        (grpc.StatusCode.NOT_FOUND, HTTPStatus.NOT_FOUND),
        (grpc.StatusCode.ALREADY_EXISTS, HTTPStatus.CONFLICT),
        (grpc.StatusCode.PERMISSION_DENIED, HTTPStatus.FORBIDDEN),
        (grpc.StatusCode.UNAUTHENTICATED, HTTPStatus.UNAUTHORIZED),
        (grpc.StatusCode.RESOURCE_EXHAUSTED, HTTPStatus.TOO_MANY_REQUESTS),
        (grpc.StatusCode.FAILED_PRECONDITION, HTTPStatus.PRECONDITION_FAILED),
        (grpc.StatusCode.ABORTED, HTTPStatus.CONFLICT),
        (grpc.StatusCode.OUT_OF_RANGE, HTTPStatus.BAD_REQUEST),
        (grpc.StatusCode.UNKNOWN, HTTPStatus.INTERNAL_SERVER_ERROR),
        (grpc.StatusCode.DEADLINE_EXCEEDED, HTTPStatus.GATEWAY_TIMEOUT),
        (grpc.StatusCode.UNIMPLEMENTED, HTTPStatus.NOT_IMPLEMENTED),
        (grpc.StatusCode.INTERNAL, HTTPStatus.INTERNAL_SERVER_ERROR),
        (grpc.StatusCode.UNAVAILABLE, HTTPStatus.SERVICE_UNAVAILABLE),
        (grpc.StatusCode.DATA_LOSS, HTTPStatus.INTERNAL_SERVER_ERROR),
        (None, HTTPStatus.INTERNAL_SERVER_ERROR),
    ],
)
def test_grpc_to_http_status_mapping(
    grpc_code: Optional[grpc.StatusCode],
    expected_http: int,
) -> None:
    result = grpc_to_http_status(grpc_code)
    assert result == expected_http
