from datetime import datetime, timezone

import pandas as pd
import pytest
from frogml._proto.qwak.feature_store.entities.entity_pb2 import EntitySpec
from frogml._proto.qwak.feature_store.entities.entity_service_pb2 import (
    CreateEntityRequest,
)
from frogml._proto.qwak.feature_store.sources.batch_pb2 import BatchSource
from frogml._proto.qwak.feature_store.sources.data_source_pb2 import DataSourceSpec
from frogml._proto.qwak.feature_store.sources.data_source_service_pb2 import (
    CreateDataSourceRequest,
)
from frogml._proto.qwak.feature_store.sources.streaming_pb2 import StreamingSource
from frogml._proto.qwak.features_operator.v3.features_operator_async_service_pb2 import (
    GetValidationResultResponse,
)
from frogml._proto.qwak.features_operator.v3.features_operator_pb2 import (
    Outputs,
    SparkColumnDescription,
    ValidationFailureResponse,
    ValidationSuccessResponse,
)
from frogml.core.clients.feature_store import FeatureRegistryClient
from frogml.core.feature_store.feature_sets.read_policies import ReadPolicy
from frogml.core.feature_store.validations.validation_options import (
    DataSourceValidationOptions,
    FeatureSetValidationOptions,
)
from pytest_lazy_fixtures import lf


@pytest.fixture()
def single_ds_timeframe(REGISTERED_BATCH_DS):
    return {REGISTERED_BATCH_DS: ReadPolicy.TimeFrame(minutes=90)}


@pytest.fixture()
def single_ds_newonly(REGISTERED_BATCH_DS):
    return {REGISTERED_BATCH_DS: ReadPolicy.NewOnly()}


@pytest.fixture()
def single_ds_fullread(REGISTERED_BATCH_DS):
    return {REGISTERED_BATCH_DS: ReadPolicy.FullRead()}


@pytest.fixture()
def multi_ds_all_timeframe(REGISTERED_BATCH_DS, REGISTERED_BATCH_DS_2):
    return {
        REGISTERED_BATCH_DS: ReadPolicy.TimeFrame(minutes=90),
        REGISTERED_BATCH_DS_2: ReadPolicy.TimeFrame(minutes=555),
    }


@pytest.fixture()
def multi_ds_single_timeframe(REGISTERED_BATCH_DS, REGISTERED_BATCH_DS_2):
    return {
        REGISTERED_BATCH_DS: ReadPolicy.TimeFrame(minutes=90),
        REGISTERED_BATCH_DS_2: ReadPolicy.FullRead(),
    }


@pytest.fixture()
def multi_ds_single_newonly(REGISTERED_BATCH_DS, REGISTERED_BATCH_DS_2):
    return {
        REGISTERED_BATCH_DS: ReadPolicy.NewOnly(),
        REGISTERED_BATCH_DS_2: ReadPolicy.FullRead(),
    }


@pytest.fixture()
def multi_ds_all_fullread(REGISTERED_BATCH_DS, REGISTERED_BATCH_DS_2):
    return {
        REGISTERED_BATCH_DS: ReadPolicy.FullRead(),
        REGISTERED_BATCH_DS_2: ReadPolicy.FullRead(),
    }


@pytest.fixture()
def multi_ds_all_newonly(REGISTERED_BATCH_DS, REGISTERED_BATCH_DS_2):
    return {
        REGISTERED_BATCH_DS: ReadPolicy.NewOnly(),
        REGISTERED_BATCH_DS_2: ReadPolicy.NewOnly(),
    }


@pytest.fixture(scope="session")
def TEST_ENTITY_ID1():
    return "id"


@pytest.fixture(scope="session")
def TEST_ENTITY_ID2():
    return "store_id"


@pytest.fixture(scope="session")
def TEST_BATCHV1_FEATURESET_NAME():
    return "purchases-mongo-feature-set"


@pytest.fixture(scope="session")
def TEST_BATCHV1_FEATURESET_NAME2():
    return "purchases-mongo-store-feature-set"


@pytest.fixture(scope="session")
def TEST_STREAMING_FEATURESET_NAME():
    return "streaming1"


@pytest.fixture(scope="session")
def REGISTERED_ENTITY_NAME():
    return "id"


@pytest.fixture(scope="session")
def KEY_NAME():
    return "id"


@pytest.fixture(scope="session")
def REGISTERED_BATCH_DS():
    return "my_batch_source"


@pytest.fixture(scope="session")
def REGISTERED_STREAMING_DS():
    return "sample_kafka_source"


@pytest.fixture(scope="session")
def REPOSITORY_NAME():
    return "test_repository"


@pytest.fixture(scope="session")
def REGISTERED_BATCH_DS_2():
    return "my_batch_source_2"


@pytest.fixture(scope="session")
def REGISTERED_BATCH_TS_COLUMN():
    return "timestamp_test"


@pytest.fixture
def feature_registry(
    frogml_services_mock,
    REGISTERED_ENTITY_NAME,
    REGISTERED_BATCH_DS,
    REGISTERED_BATCH_DS_2,
    REGISTERED_BATCH_TS_COLUMN,
    REGISTERED_STREAMING_DS,
):
    frogml_services_mock.fs_data_sources_service.CreateDataSource(
        request=CreateDataSourceRequest(
            data_source_spec=DataSourceSpec(
                batch_source=BatchSource(
                    name=REGISTERED_BATCH_DS,
                    date_created_column=REGISTERED_BATCH_TS_COLUMN,
                ),
            )
        ),
        context=None,
    )

    frogml_services_mock.fs_data_sources_service.CreateDataSource(
        request=CreateDataSourceRequest(
            data_source_spec=DataSourceSpec(
                batch_source=BatchSource(
                    name=REGISTERED_BATCH_DS_2,
                    date_created_column=REGISTERED_BATCH_TS_COLUMN,
                ),
            )
        ),
        context=None,
    )

    frogml_services_mock.fs_data_sources_service.CreateDataSource(
        request=CreateDataSourceRequest(
            data_source_spec=DataSourceSpec(
                stream_source=StreamingSource(name=REGISTERED_STREAMING_DS),
            )
        ),
        context=None,
    )

    frogml_services_mock.fs_entities_service.CreateEntity(
        request=CreateEntityRequest(
            entity_spec=EntitySpec(
                name=REGISTERED_ENTITY_NAME,
                keys=[REGISTERED_ENTITY_NAME],
                description=REGISTERED_ENTITY_NAME,
                value_type=1,  # string
            )
        ),
        context=None,
    )

    return FeatureRegistryClient()


@pytest.fixture(scope="session")
def validation_success_empty() -> ValidationSuccessResponse:
    return ValidationSuccessResponse()


@pytest.fixture(scope="session")
def validation_success_empty_outputs() -> ValidationSuccessResponse:
    return ValidationSuccessResponse(outputs=Outputs())


@pytest.fixture(scope="session")
def validation_success_blank_outputs() -> ValidationSuccessResponse:
    return ValidationSuccessResponse(outputs=Outputs(stdout="", stderr=""))


@pytest.fixture(scope="session")
def validation_success_stderr() -> ValidationSuccessResponse:
    return ValidationSuccessResponse(outputs=Outputs(stdout="", stderr="asd"))


@pytest.fixture(scope="session")
def validation_success_stdout() -> ValidationSuccessResponse:
    return ValidationSuccessResponse(outputs=Outputs(stdout="asda"))


@pytest.fixture(scope="session")
def validation_success_stdout_and_stderr() -> ValidationSuccessResponse:
    return ValidationSuccessResponse(
        sample='\'{"taxi_id":{"0":5647,"1":6301,"2":6301}}\'',
        spark_column_description=[
            SparkColumnDescription(column_name="taxi_id", spark_type="bigint")
        ],
        outputs=Outputs(stdout="123", stderr="some err"),
    )


@pytest.fixture
def validation_result_response_success(validation_success_stdout_and_stderr):
    return GetValidationResultResponse(
        success_response=validation_success_stdout_and_stderr
    )


@pytest.fixture(scope="session")
def validation_result_response_failure():
    return GetValidationResultResponse(
        failure_response=ValidationFailureResponse(
            outputs=Outputs(stdout="123", stderr="some err")
        )
    )


@pytest.fixture(scope="session")
def taxi_df():
    return pd.DataFrame.from_records(
        [{"taxi_id": 5647}, {"taxi_id": 6301}, {"taxi_id": 6301}]
    )


@pytest.fixture(scope="session")
def upper_time_bound() -> datetime:
    return datetime(year=2022, month=7, day=3).replace(tzinfo=timezone.utc)


@pytest.fixture(scope="session")
def lower_time_bound() -> datetime:
    return datetime(year=2022, month=1, day=3).replace(tzinfo=timezone.utc)


@pytest.fixture(scope="session")
def data_source_validation_options_full_range(
    lower_time_bound,
    upper_time_bound,
) -> DataSourceValidationOptions:
    return DataSourceValidationOptions(
        lower_time_bound=lower_time_bound, upper_time_bound=upper_time_bound
    )


@pytest.fixture(scope="session")
def data_source_validation_options_lower_bound(
    lower_time_bound,
) -> DataSourceValidationOptions:
    return DataSourceValidationOptions(lower_time_bound=lower_time_bound)


@pytest.fixture(scope="session")
def data_source_validation_options_upper_bound(
    upper_time_bound,
) -> DataSourceValidationOptions:
    return DataSourceValidationOptions(upper_time_bound=upper_time_bound)


@pytest.fixture(scope="session")
def empty_data_source_validation_options() -> DataSourceValidationOptions:
    return DataSourceValidationOptions()


@pytest.fixture(
    params=[
        lf("data_source_validation_options_full_range"),
        lf("data_source_validation_options_lower_bound"),
        lf("data_source_validation_options_upper_bound"),
    ]
)
def data_source_validation_options(request) -> DataSourceValidationOptions:
    return request.param


@pytest.fixture(scope="session")
def feature_set_validation_options_full_range(
    lower_time_bound,
    upper_time_bound,
) -> FeatureSetValidationOptions:
    return FeatureSetValidationOptions(
        lower_time_bound=lower_time_bound, upper_time_bound=upper_time_bound
    )


@pytest.fixture(scope="session")
def feature_set_validation_options_lower_bound(
    lower_time_bound,
) -> FeatureSetValidationOptions:
    return FeatureSetValidationOptions(
        lower_time_bound=lower_time_bound,
    )


@pytest.fixture(scope="session")
def feature_set_validation_options_upper_bound(
    upper_time_bound,
) -> FeatureSetValidationOptions:
    return FeatureSetValidationOptions(upper_time_bound=upper_time_bound)


@pytest.fixture(scope="session")
def empty_feature_set_validation_options() -> FeatureSetValidationOptions:
    return FeatureSetValidationOptions()


@pytest.fixture(scope="session")
def feature_set_validation_options_full_range_with_data_source_limit(
    lower_time_bound, upper_time_bound
) -> FeatureSetValidationOptions:
    return FeatureSetValidationOptions(
        data_source_limit=10,
        lower_time_bound=lower_time_bound,
        upper_time_bound=upper_time_bound,
    )


@pytest.fixture(scope="session")
def feature_set_validation_options_lower_bound_with_data_source_limit(
    lower_time_bound,
) -> FeatureSetValidationOptions:
    return FeatureSetValidationOptions(
        data_source_limit=10, lower_time_bound=lower_time_bound
    )


@pytest.fixture(scope="session")
def feature_set_validation_options_upper_bound_with_data_source_limit(
    upper_time_bound,
) -> FeatureSetValidationOptions:
    return FeatureSetValidationOptions(
        data_source_limit=10, upper_time_bound=upper_time_bound
    )


@pytest.fixture(scope="session")
def empty_feature_set_validation_options_with_data_source_limit() -> (
    FeatureSetValidationOptions
):
    return FeatureSetValidationOptions(data_source_limit=10)


@pytest.fixture(
    params=[
        lf("feature_set_validation_options_full_range"),
        lf("feature_set_validation_options_lower_bound"),
        lf("feature_set_validation_options_upper_bound"),
        lf("empty_feature_set_validation_options"),
        lf("feature_set_validation_options_full_range_with_data_source_limit"),
        lf("feature_set_validation_options_lower_bound_with_data_source_limit"),
        lf("feature_set_validation_options_upper_bound_with_data_source_limit"),
        lf("empty_feature_set_validation_options_with_data_source_limit"),
    ]
)
def feature_set_validation_options(request) -> FeatureSetValidationOptions:
    return request.param
