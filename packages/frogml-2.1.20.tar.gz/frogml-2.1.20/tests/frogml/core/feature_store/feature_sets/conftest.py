from typing import Any, Dict

import pyspark.pandas as ps_pandas
import pyspark.sql as ps_sql
import pytest

from frogml._proto.qwak.feature_store.features.feature_set_types_pb2 import (
    PandasOnSparkTransformation as ProtoPandasOnSparkTransformation,
)
from frogml._proto.qwak.feature_store.features.feature_set_types_pb2 import (
    PySparkTransformation as ProtoPysparkTransformation,
)
from frogml._proto.qwak.feature_store.features.feature_set_types_pb2 import (
    SqlTransformation as ProtoSqlTransformation,
)
from frogml._proto.qwak.feature_store.features.feature_set_types_pb2 import (
    TransformArguments as ProtoTransformArguments,
)
from frogml._proto.qwak.feature_store.features.feature_set_types_pb2 import (
    Transformation as ProtoTransformation,
)
from frogml._proto.qwak.feature_store.features.feature_set_types_pb2 import (
    UdfTransformation as ProtoUdfTransformation,
)
from frogml.core.feature_store.feature_sets.transformations import (
    Column,
    Schema,
    frogml_pandas_udf,
)
from frogml.core.feature_store.feature_sets.transformations.functions.schema import (
    SimpleType,
)
from frogml.core.feature_store.feature_sets.transformations.transformations import (
    PandasOnSparkTransformation,
    PySparkTransformation,
    SparkSqlTransformation,
    UdfTransformation,
)


@pytest.fixture(scope="session")
def artifact_path():
    return "/hello/world"


@pytest.fixture(scope="session")
def pyspark_transform_no_qwargs():
    def f(dfs: Dict[str, ps_sql.DataFrame]) -> ps_sql.DataFrame:
        return 2

    return PySparkTransformation(function=f)


@pytest.fixture(scope="session")
def udf_transform():
    import numpy as np
    import pandas as pd

    @frogml_pandas_udf(output_schema=Schema([Column(type=SimpleType("integer"))]))
    def f() -> pd.Series:
        data = np.random.randn(3)
        series = pd.Series(data)
        return series

    return UdfTransformation(function=f)


@pytest.fixture(scope="session")
def sql_transform_no_udf():
    spark_sql = "SELECT * FROM my_data_source"
    return SparkSqlTransformation(sql=spark_sql)


@pytest.fixture(scope="session")
def sql_transform_with_udf():
    spark_sql = "SELECT * FROM my_data_source"

    def f():
        return 2

    return SparkSqlTransformation(sql=spark_sql, functions=[f])


@pytest.fixture(scope="session")
def proto_sql_transform_no_udf():
    return ProtoTransformation(
        sql_transformation=ProtoSqlTransformation(sql="SELECT * FROM my_data_source")
    )


@pytest.fixture(scope="session")
def proto_udf_transform():
    return ProtoTransformation(
        udf_transformation=ProtoUdfTransformation(function_name="f")
    )


@pytest.fixture(scope="session")
def pyspark_transform_with_qwargs() -> PySparkTransformation:
    def f(dfs: Dict[str, ps_sql.DataFrame], qwargs: Dict[str, Any]) -> ps_sql.DataFrame:
        pass

    return PySparkTransformation(function=f, qwargs={"hi": "bye"})


@pytest.fixture(scope="session")
def proto_pyspark_transform_with_qwargs(artifact_path) -> ProtoTransformation:
    t = ProtoPysparkTransformation(
        function_name="f", qwargs=ProtoTransformArguments(qwargs={"hi": "bye"})
    )
    return ProtoTransformation(pyspark_transformation=t, artifact_path=artifact_path)


@pytest.fixture(scope="session")
def proto_pyspark_transform_no_qwargs(artifact_path) -> ProtoTransformation:
    t = ProtoPysparkTransformation(
        function_name="f", qwargs=ProtoTransformArguments(qwargs={})
    )
    return ProtoTransformation(
        pyspark_transformation=t,
        artifact_path=artifact_path,
    )


@pytest.fixture(scope="session")
def proto_pandas_on_spark_transform_with_qwargs(artifact_path):
    t = ProtoPandasOnSparkTransformation(
        function_name="f", qwargs=ProtoTransformArguments(qwargs={"hi": "bye"})
    )
    return ProtoTransformation(
        pandas_on_spark_transformation=t, artifact_path=artifact_path
    )


@pytest.fixture(scope="session")
def proto_pandas_on_spark_transform_no_qwargs(artifact_path):
    t = ProtoPandasOnSparkTransformation(
        function_name="f", qwargs=ProtoTransformArguments(qwargs={})
    )
    return ProtoTransformation(
        pandas_on_spark_transformation=t, artifact_path=artifact_path
    )


@pytest.fixture(scope="session")
def pandas_on_spark_transform_with_qwargs():
    def f(dfs: Dict[str, ps_pandas.DataFrame]) -> ps_pandas.DataFrame:
        pass

    return PandasOnSparkTransformation(function=f, qwargs={"hi": "bye"})


@pytest.fixture(scope="session")
def pandas_on_spark_transform_no_qwargs():
    def f(dfs: Dict[str, ps_pandas.DataFrame]) -> ps_pandas.DataFrame:
        pass

    return PandasOnSparkTransformation(function=f)


@pytest.fixture(scope="session")
def proto_sql_transform_with_udf():
    return ProtoTransformation(
        sql_transformation=ProtoSqlTransformation(
            sql="SELECT * FROM my_data_source", function_names=["f"]
        )
    )
