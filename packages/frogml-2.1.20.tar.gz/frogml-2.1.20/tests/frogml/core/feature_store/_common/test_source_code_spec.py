import pytest
from frogml._proto.qwak.feature_store.v1.common.source_code.source_code_pb2 import (
    SourceCodeArtifact as ProtoSourceCodeArtifact,
    SourceCodeSpec as ProtoSourceCodeSpec,
)
from frogml.core.exceptions import FrogmlException
from frogml.core.feature_store._common.source_code_spec import (
    SourceCodeSpec,
    ZipArtifact,
)
from pytest_lazy_fixtures import lf


@pytest.mark.parametrize(
    "given_zip_artifact, expected_proto",
    [
        (lf("valid_zip_artifact_qwak"), lf("valid_zip_artifact_qwak_proto")),
        (
            lf("valid_zip_artifact_artifactory"),
            lf("valid_zip_artifact_artifactory_proto"),
        ),
    ],
)
def test_zip_artifact_to_proto(
    given_zip_artifact: ZipArtifact, expected_proto: ProtoSourceCodeArtifact
):
    actual_proto = given_zip_artifact._to_proto()
    assert actual_proto == expected_proto


@pytest.mark.parametrize(
    "given_proto_zip_artifact, expected_zip_artifact",
    [
        (lf("valid_zip_artifact_qwak_proto"), lf("valid_zip_artifact_qwak")),
        (
            lf("valid_zip_artifact_artifactory_proto"),
            lf("valid_zip_artifact_artifactory"),
        ),
    ],
)
def test_zip_artifact_from_proto(
    given_proto_zip_artifact: ProtoSourceCodeArtifact,
    expected_zip_artifact: ZipArtifact,
):
    actual_zip_artifact: ZipArtifact = ZipArtifact._from_proto(
        proto=given_proto_zip_artifact
    )
    assert actual_zip_artifact == expected_zip_artifact


@pytest.mark.parametrize(
    "given_proto_zip_artifact, expected_error_message",
    [
        (
            lf("empty_source_code_artifact_proto"),
            lf("empty_source_code_artifact_error_message"),
        ),
        (
            lf("invalid_source_code_artifact_proto"),
            lf("invalid_source_code_artifact_error_message"),
        ),
    ],
)
def test_invalid_zip_artifact_from_proto(
    given_proto_zip_artifact: ProtoSourceCodeArtifact, expected_error_message: str
):
    with pytest.raises(FrogmlException) as e:
        ZipArtifact._from_proto(proto=given_proto_zip_artifact)
    assert expected_error_message in str(e.value)


@pytest.mark.parametrize(
    "given_source_code_spec, expected_proto",
    [
        (lf("zip_source_code_spec"), lf("zip_source_code_spec_proto")),
        (lf("empty_source_code_spec"), lf("empty_source_code_spec_proto")),
    ],
)
def test_source_code_spec_to_proto(
    given_source_code_spec: SourceCodeSpec, expected_proto: ProtoSourceCodeSpec
):
    actual_source_code_spec: SourceCodeSpec = given_source_code_spec._to_proto()
    assert actual_source_code_spec == expected_proto


@pytest.mark.parametrize(
    "given_source_code_spec_proto, expected_source_code_spec",
    [
        (lf("zip_source_code_spec_proto"), lf("zip_source_code_spec")),
        (lf("empty_source_code_spec_proto"), lf("empty_source_code_spec")),
    ],
)
def test_source_code_spec_from_proto(
    given_source_code_spec_proto: ProtoSourceCodeArtifact,
    expected_source_code_spec: SourceCodeSpec,
):
    actual_source_code_spec: SourceCodeSpec = SourceCodeSpec._from_proto(
        proto=given_source_code_spec_proto
    )
    assert actual_source_code_spec == expected_source_code_spec
