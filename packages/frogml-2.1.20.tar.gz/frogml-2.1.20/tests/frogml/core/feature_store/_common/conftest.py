import pytest
from frogml._proto.qwak.feature_store.v1.common.jfrog_artifact.jfrog_artifact_pb2 import (
    JfrogArtifact as ProtoJfrogArtifact,
)
from frogml._proto.qwak.feature_store.v1.common.source_code.source_code_pb2 import (
    SourceCodeArtifact as ProtoSourceCodeArtifact,
    SourceCodeSpec as ProtoSourceCodeSpec,
    ZipArtifact as ProtoZipArtifact,
)
from frogml.core.feature_store._common.source_code_spec import (
    JfrogArtifact,
    SourceCodeSpec,
    ZipArtifact,
)


@pytest.fixture
def valid_zip_artifact_qwak() -> ZipArtifact:
    return ZipArtifact(qwak_artifact_path="path", main_file="main")


@pytest.fixture
def valid_zip_artifact_qwak_proto() -> ProtoSourceCodeArtifact:
    return ProtoSourceCodeArtifact(
        zip_artifact=ProtoZipArtifact(path="path", main_file="main")
    )


@pytest.fixture
def artifactory_path() -> str:
    return "https://artifactory.example.com/artifact.zip"


@pytest.fixture
def valid_jfrog_artifact(artifactory_path: str) -> JfrogArtifact:
    return JfrogArtifact(path=artifactory_path)


@pytest.fixture
def valid_jfrog_artifact_proto(artifactory_path: str) -> ProtoJfrogArtifact:
    return ProtoJfrogArtifact(path=artifactory_path)


@pytest.fixture
def valid_zip_artifact_artifactory(valid_jfrog_artifact: JfrogArtifact) -> ZipArtifact:
    return ZipArtifact(
        main_file="main",
        jfrog_artifact_path=valid_jfrog_artifact,
    )


@pytest.fixture
def valid_zip_artifact_artifactory_proto(
    valid_jfrog_artifact_proto: ProtoJfrogArtifact,
) -> ProtoSourceCodeArtifact:
    return ProtoSourceCodeArtifact(
        zip_artifact=ProtoZipArtifact(
            main_file="main", jfrog_artifact_path=valid_jfrog_artifact_proto
        )
    )


@pytest.fixture
def empty_source_code_artifact_proto() -> ProtoSourceCodeArtifact:
    return ProtoSourceCodeArtifact()


@pytest.fixture
def empty_source_code_artifact_error_message() -> str:
    return "Instead of 'zip_artifact' got"


@pytest.fixture
def invalid_source_code_artifact_proto() -> ProtoSourceCodeArtifact:
    return ProtoSourceCodeArtifact(zip_artifact=ProtoZipArtifact(main_file="main"))


@pytest.fixture
def invalid_source_code_artifact_error_message() -> str:
    return "Either 'path' or 'jfrog_artifact_path' must be provided inside SourceCodeArtifact proto"


@pytest.fixture
def zip_source_code_spec(valid_zip_artifact_qwak: ZipArtifact) -> SourceCodeSpec:
    return SourceCodeSpec(artifact=valid_zip_artifact_qwak)


@pytest.fixture
def zip_source_code_spec_proto(
    valid_zip_artifact_qwak_proto: ProtoSourceCodeArtifact,
) -> ProtoSourceCodeSpec:
    return ProtoSourceCodeSpec(artifact=valid_zip_artifact_qwak_proto)


@pytest.fixture
def empty_source_code_spec_proto(
    valid_zip_artifact_qwak_proto: ProtoSourceCodeArtifact,
) -> ProtoSourceCodeSpec:
    return ProtoSourceCodeSpec()


@pytest.fixture
def empty_source_code_spec() -> SourceCodeSpec:
    return SourceCodeSpec()
