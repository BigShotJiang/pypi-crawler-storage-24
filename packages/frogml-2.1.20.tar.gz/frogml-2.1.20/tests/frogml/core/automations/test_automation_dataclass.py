import pytest

from frogml._proto.qwak.automation.v1.action_pb2 import Action as ActionProto
from frogml._proto.qwak.automation.v1.action_pb2 import BatchExecutionAction
from frogml._proto.qwak.automation.v1.action_pb2 import (
    BuildAndDeployAction as BuildAndDeployActionProto,
)
from frogml._proto.qwak.automation.v1.action_pb2 import (
    BuildMetricCondition as BuildMetricConditionProto,
)
from frogml._proto.qwak.automation.v1.action_pb2 import BuildSpec as BuildSpecProto
from frogml._proto.qwak.automation.v1.action_pb2 import (
    CpuResources as CpuResourcesProto,
)
from frogml._proto.qwak.automation.v1.action_pb2 import (
    DeployedBuildMetricCondition as DeployedBuildMetricConditionProto,
)
from frogml._proto.qwak.automation.v1.action_pb2 import (
    DeploymentCondition as DeploymentConditionProto,
)
from frogml._proto.qwak.automation.v1.action_pb2 import (
    DeploymentSize as DeploymentSizeProto,
)
from frogml._proto.qwak.automation.v1.action_pb2 import DeploymentSpec
from frogml._proto.qwak.automation.v1.action_pb2 import (
    DeploymentSpec as DeploymentSpecProto,
)
from frogml._proto.qwak.automation.v1.action_pb2 import (
    GitModelSource as GitModelSourceProto,
)
from frogml._proto.qwak.automation.v1.action_pb2 import (
    GpuResources as GpuResourcesProto,
)
from frogml._proto.qwak.automation.v1.action_pb2 import GpuType as GpuTypeProto
from frogml._proto.qwak.automation.v1.action_pb2 import MemoryUnit
from frogml._proto.qwak.automation.v1.action_pb2 import MemoryUnit as MemoryUnitProto
from frogml._proto.qwak.automation.v1.action_pb2 import (
    PurchaseOption as PurchaseOptionProto,
)
from frogml._proto.qwak.automation.v1.action_pb2 import Resources as ResourcesProto

from frogml._proto.qwak.automation.v1.auto_scaling_pb2 import (
    AGGREGATION_TYPE_AVERAGE,
    AGGREGATION_TYPE_MAX,
    AGGREGATION_TYPE_MIN,
    AGGREGATION_TYPE_P50,
    AGGREGATION_TYPE_P90,
    AGGREGATION_TYPE_P95,
    AGGREGATION_TYPE_P99,
    AGGREGATION_TYPE_SUM,
    METRIC_TYPE_CPU,
    METRIC_TYPE_LATENCY,
    METRIC_TYPE_MEMORY,
    METRIC_TYPE_ERROR_RATE,
    METRIC_TYPE_THROUGHPUT,
    METRIC_TYPE_GPU,
    QuerySpec,
)

from frogml._proto.qwak.automation.v1.automation_pb2 import (
    Automation as AutomationProto,
)
from frogml._proto.qwak.automation.v1.automation_pb2 import (
    AutomationSpec as AutomationSpecProto,
)
from frogml._proto.qwak.automation.v1.common_pb2 import (
    MetricThresholdDirection as MetricThresholdDirectionProto,
)
from frogml._proto.qwak.automation.v1.trigger_pb2 import NoneTrigger as NoneTriggerProto
from frogml._proto.qwak.automation.v1.trigger_pb2 import (
    OnBoardingTrigger as OnBoardingTriggerProto,
)
from frogml._proto.qwak.automation.v1.trigger_pb2 import (
    ScheduledTrigger as ScheduledTriggerProto,
)
from frogml._proto.qwak.automation.v1.trigger_pb2 import Trigger as TriggerProto
from frogml._proto.qwak.batch_job.v1.batch_job_service_pb2 import (
    AdvancedDeploymentOptions as BatchAdvancedDeploymentOptions,
)
from frogml._proto.qwak.batch_job.v1.batch_job_service_pb2 import (
    BatchJobDataDetails,
    BatchJobDeploymentSize,
    BatchJobDestinationPath,
    BatchJobExecutionDetails,
    BatchJobModelDetails,
    BatchJobParameter,
    BatchJobRequest,
    BatchJobSourcePath,
    InputFileType,
    OutputFileType,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    ClientPodComputeResources,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    CpuResources as CommonCpuResourcesProto,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    GpuResources as CommonGpuResourcesProto,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    GpuType as CommonGpuTypeProto,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    MemoryUnit as CommonMemoryUnitProto,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    PodComputeResourceTemplateSpec,
)
from frogml.core.automations import (
    Automation,
    BatchExecution,
    BatchJobDataSpecifications,
    BuildMetric,
    BuildSpecifications,
    CpuResources,
    DeploymentSpecifications,
    FrogmlBuildDeploy,
    GpuResources,
    NoneTrigger,
    ScheduledTrigger,
    ThresholdDirection,
)
from frogml.core.automations.automations import OnBoardingTrigger
from frogml.core.automations.build_and_deploy_action import (
    ClientResources,
    DeployedBuildMetric,
    AutoScaleQuerySpec,
)


def test_automation_to_proto():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"

    trigger = ScheduledTrigger(cron="0 0 1 1 1")

    build_spec = BuildSpecifications(
        git_uri="https://github.com/qwak-ai/model-test.git#models/model_init/churn",
        git_access_token_secret="automation_sanity_github_token",
        git_branch="main",
        main_dir="main",
        purchase_option="ondemand",
        provision_instance_timeout=120,
        service_account_key_secret_name="service_account_key_secret_name",
    )

    deployment_condition = DeployedBuildMetric(
        metric_name="f1_score", direction=ThresholdDirection.ABOVE
    )

    deployment_spec = DeploymentSpecifications(
        number_of_pods=1,
        cpu_fraction=1.0,
        memory="512Mi",
        variation_name="default",
        service_account_key_secret_name="service_account_key_secret_name_for_deployment",
    )

    action = FrogmlBuildDeploy(
        build_spec=build_spec,
        deployment_condition=deployment_condition,
        deployment_spec=deployment_spec,
    )

    automation = Automation(
        id=automation_id,
        name=automation_name,
        model_id=model_id,
        execute_immediately=False,
        trigger=trigger,
        action=action,
        is_sdk_v1=True,
    )

    # When
    automation_to_proto = automation.to_proto()

    # Then
    assert automation_to_proto.automation_id == automation_id
    assert automation_to_proto.automation_spec.automation_name == automation_name
    assert automation_to_proto.automation_spec.model_id == model_id
    assert (
        automation_to_proto.automation_spec.trigger.scheduled_trigger.cron
        == trigger.cron
    )
    assert (
        automation_to_proto.automation_spec.action.build_deploy.deployment_spec.deployment_size.cpu
        == 1.0
    )
    assert (
        automation_to_proto.automation_spec.action.build_deploy.deployment_spec.deployment_size.gpu_resources.gpu_amount
        == 0
    )
    assert automation_to_proto.automation_spec.is_sdk_v1
    assert (
        automation_to_proto.automation_spec.action.build_deploy.build_spec.purchase_option
        == PurchaseOptionProto.ON_DEMAND
    )
    assert (
        automation_to_proto.automation_spec.action.build_deploy.build_spec.provision_instance_timeout
        == 120
    )
    assert (
        automation_to_proto.automation_spec.action.build_deploy.build_spec.service_account_key_secret_name
        == "service_account_key_secret_name"
    )
    assert (
        automation_to_proto.automation_spec.action.build_deploy.deployment_spec.advanced_options.service_account_key_secret_name
        == "service_account_key_secret_name_for_deployment"
    )


def test_automation_to_proto_with_default_purchase_option():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"

    trigger = ScheduledTrigger(cron="0 0 1 1 1")

    build_spec = BuildSpecifications()
    deployment_condition = BuildMetric()
    deployment_spec = DeploymentSpecifications()

    action = FrogmlBuildDeploy(
        build_spec=build_spec,
        deployment_condition=deployment_condition,
        deployment_spec=deployment_spec,
    )

    automation = Automation(
        id=automation_id,
        name=automation_name,
        model_id=model_id,
        execute_immediately=False,
        trigger=trigger,
        action=action,
        is_sdk_v1=True,
    )

    # When
    automation_to_proto = automation.to_proto()

    # Then
    assert (
        automation_to_proto.automation_spec.action.build_deploy.build_spec.purchase_option
        == PurchaseOptionProto.SPOT
    )


def test_automation_to_proto_with_invalid_purchase_option():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"

    trigger = ScheduledTrigger(cron="0 0 1 1 1")

    build_spec = BuildSpecifications(purchase_option="not an option")

    deployment_condition = BuildMetric()
    deployment_spec = DeploymentSpecifications()

    action = FrogmlBuildDeploy(
        build_spec=build_spec,
        deployment_condition=deployment_condition,
        deployment_spec=deployment_spec,
    )

    automation = Automation(
        id=automation_id,
        name=automation_name,
        model_id=model_id,
        execute_immediately=False,
        trigger=trigger,
        action=action,
        is_sdk_v1=True,
    )

    # When
    with pytest.raises(ValueError) as excinfo:
        automation.to_proto()
        assert "Invalid purchase option not an option'" in str(excinfo.value)


def test_automation_from_proto():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"
    jfrog_token_id = "token"

    scheduled_trigger = ScheduledTriggerProto(cron="0 0 1 1 1")
    trigger = TriggerProto(scheduled_trigger=scheduled_trigger)

    git_model_source = GitModelSourceProto(
        git_uri="https://github.com/qwak-ai/model-test.git#models/model_init/churn",
        git_credentials_secret_name="automation_sanity_github_token",
        git_branch="main",
    )
    cpu_resources = CpuResourcesProto(
        cpu=1.0, memory_amount=1, memory_units=MemoryUnitProto.MIB
    )
    resources = ResourcesProto(cpu_resources=cpu_resources)
    build_spec = BuildSpecProto(
        git_model_source=git_model_source,
        main_dir="main",
        resource=resources,
        purchase_option=PurchaseOptionProto.SPOT,
        provision_instance_timeout=100,
    )

    build_metric = BuildMetricConditionProto(
        metric_name="f1_score",
        threshold_direction=MetricThresholdDirectionProto.ABOVE,
        threshold="0.0",
    )
    deployment_condition = DeploymentConditionProto(build_metric=build_metric)

    deployment_size = DeploymentSizeProto(
        number_of_pods=1,
        cpu=1.0,
        memory_amount=512,
        memory_units=MemoryUnitProto.MIB,
    )
    deployment_spec = DeploymentSpecProto(
        deployment_size=deployment_size,
        selected_variation_name="default",
    )

    build_deploy = BuildAndDeployActionProto(
        build_spec=build_spec,
        deployment_condition=deployment_condition,
        deployment_spec=deployment_spec,
    )
    action = ActionProto(build_deploy=build_deploy)

    automation_spec = AutomationSpecProto(
        model_id=model_id,
        automation_name=automation_name,
        trigger=trigger,
        action=action,
        is_sdk_v1=True,
    )

    automation = AutomationProto(
        automation_id=automation_id,
        automation_spec=automation_spec,
        jfrog_token_id=jfrog_token_id,
    )

    # When
    automation_from_proto = Automation.from_proto(automation)

    # Then
    assert automation_from_proto.id == automation_id
    assert automation_from_proto.name == automation_name
    assert automation_from_proto.model_id == model_id
    assert automation_from_proto.is_sdk_v1
    assert automation_from_proto.trigger.cron == trigger.scheduled_trigger.cron
    assert automation_from_proto.action.deployment_spec.cpu_fraction == 1.0
    assert automation_from_proto.action.deployment_spec.gpu_resources.gpu_amount == 0
    assert automation_from_proto.action.build_spec.purchase_option == "spot"
    assert automation_from_proto.action.build_spec.provision_instance_timeout == 100
    assert automation_from_proto.jfrog_token_id == jfrog_token_id


def test_automation_to_proto_from_proto():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"
    jfrog_token_id = "token"

    trigger = ScheduledTrigger(cron="0 0 1 1 1")

    build_spec = BuildSpecifications(
        git_uri="https://github.com/qwak-ai/model-test.git#models/model_init/churn",
        git_access_token_secret="automation_sanity_github_token",
        git_branch="main",
        main_dir="main",
        service_account_key_secret_name="service_account_key_secret_name",
    )

    deployment_condition = BuildMetric(
        metric_name="f1_score", direction=ThresholdDirection.ABOVE, threshold="0.0"
    )

    deployment_spec = DeploymentSpecifications(
        number_of_pods=1,
        cpu_fraction=1.0,
        memory="512Mi",
        variation_name="default",
        service_account_key_secret_name="service_account_key_secret_name_for_deployment",
    )

    action = FrogmlBuildDeploy(
        build_spec=build_spec,
        deployment_condition=deployment_condition,
        deployment_spec=deployment_spec,
    )

    automation = Automation(
        id=automation_id,
        name=automation_name,
        model_id=model_id,
        execute_immediately=False,
        trigger=trigger,
        action=action,
        is_sdk_v1=True,
        jfrog_token_id=jfrog_token_id,
    )

    # When
    automation_to_proto = automation.to_proto()
    automation_from_proto = Automation.from_proto(automation_to_proto)

    # Then
    assert automation_to_proto.automation_id == automation_from_proto.id
    assert (
        automation_to_proto.automation_spec.is_sdk_v1 == automation_from_proto.is_sdk_v1
    )
    assert (
        automation_to_proto.automation_spec.automation_name
        == automation_from_proto.name
    )
    assert (
        automation_to_proto.automation_spec.model_id == automation_from_proto.model_id
    )
    assert (
        automation_to_proto.automation_spec.trigger.scheduled_trigger.cron
        == automation_from_proto.trigger.cron
    )
    assert (
        automation_to_proto.automation_spec.action.build_deploy.deployment_spec.deployment_size.cpu
        == automation_from_proto.action.deployment_spec.cpu_fraction
    )
    assert (
        automation_to_proto.automation_spec.action.build_deploy.deployment_spec.deployment_size.gpu_resources.gpu_amount
        == 0
    )
    assert (
        automation_to_proto.automation_spec.action.build_deploy.build_spec.service_account_key_secret_name
        == "service_account_key_secret_name"
    )
    assert (
        automation_to_proto.automation_spec.action.build_deploy.deployment_spec.advanced_options.service_account_key_secret_name
        == "service_account_key_secret_name_for_deployment"
    )
    assert automation_to_proto.jfrog_token_id == automation_from_proto.jfrog_token_id


def test_automation_from_proto_to_proto():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"

    scheduled_trigger = ScheduledTriggerProto(cron="0 0 1 1 1")
    trigger = TriggerProto(scheduled_trigger=scheduled_trigger)

    git_model_source = GitModelSourceProto(
        git_uri="https://github.com/qwak-ai/model-test.git#models/model_init/churn",
        git_credentials_secret_name="automation_sanity_github_token",
        git_branch="main",
    )
    cpu_resources = CpuResourcesProto(
        cpu=1.0, memory_amount=1, memory_units=MemoryUnitProto.MIB
    )
    resources = ResourcesProto(cpu_resources=cpu_resources)
    build_spec = BuildSpecProto(
        git_model_source=git_model_source, main_dir="main", resource=resources
    )

    build_metric = BuildMetricConditionProto(
        metric_name="f1_score",
        threshold_direction=MetricThresholdDirectionProto.ABOVE,
        threshold="0.0",
    )
    deployment_condition = DeploymentConditionProto(build_metric=build_metric)

    deployment_size = DeploymentSizeProto(
        number_of_pods=1,
        cpu=1.0,
        memory_amount=512,
        memory_units=MemoryUnitProto.MIB,
    )
    deployment_spec = DeploymentSpecProto(
        deployment_size=deployment_size,
        selected_variation_name="default",
    )

    build_deploy = BuildAndDeployActionProto(
        build_spec=build_spec,
        deployment_condition=deployment_condition,
        deployment_spec=deployment_spec,
    )
    action = ActionProto(build_deploy=build_deploy)

    automation_spec = AutomationSpecProto(
        model_id=model_id,
        automation_name=automation_name,
        trigger=trigger,
        action=action,
        is_sdk_v1=True,
    )

    automation = AutomationProto(
        automation_id=automation_id, automation_spec=automation_spec
    )

    # When
    automation_from_proto = Automation.from_proto(automation)
    automation_to_proto = automation_from_proto.to_proto()

    # Then
    assert automation_from_proto.id == automation_to_proto.automation_id
    assert (
        automation_from_proto.is_sdk_v1 == automation_to_proto.automation_spec.is_sdk_v1
    )
    assert (
        automation_from_proto.name
        == automation_to_proto.automation_spec.automation_name
    )
    assert (
        automation_from_proto.model_id == automation_to_proto.automation_spec.model_id
    )
    assert (
        automation_from_proto.trigger.cron
        == automation_to_proto.automation_spec.trigger.scheduled_trigger.cron
    )
    assert (
        automation_from_proto.action.deployment_spec.cpu_fraction
        == automation_to_proto.automation_spec.action.build_deploy.deployment_spec.deployment_size.cpu
    )
    assert automation_from_proto.action.deployment_spec.gpu_resources.gpu_amount == 0


def test_deployed_build_metric_condition():
    deployed_build_metric = DeployedBuildMetricConditionProto(
        metric_name="f1_score",
        threshold_direction=MetricThresholdDirectionProto.ABOVE,
        variation="default",
    )

    deployment_condition_proto = DeploymentConditionProto(
        deployed_build_metric=deployed_build_metric
    )
    deployment_condition = DeployedBuildMetric.from_proto(deployment_condition_proto)

    assert (
        deployment_condition_proto.deployed_build_metric.metric_name
        == deployment_condition.metric_name
    )
    assert (
        deployment_condition_proto.deployed_build_metric.variation
        == deployment_condition.variation
    )


def test_automation_to_proto_with_none_trigger_type():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"

    trigger = NoneTrigger()

    build_spec = BuildSpecifications(
        git_uri="https://github.com/qwak-ai/model-test.git#models/model_init/churn",
        git_access_token_secret="automation_sanity_github_token",
        git_branch="main",
        main_dir="main",
    )

    deployment_condition = BuildMetric(
        metric_name="f1_score", direction=ThresholdDirection.ABOVE, threshold="0.0"
    )

    deployment_spec = DeploymentSpecifications(
        number_of_pods=1, cpu_fraction=1.0, memory="512Mi", variation_name="default"
    )

    action = FrogmlBuildDeploy(
        build_spec=build_spec,
        deployment_condition=deployment_condition,
        deployment_spec=deployment_spec,
    )

    automation = Automation(
        id=automation_id,
        name=automation_name,
        model_id=model_id,
        execute_immediately=False,
        trigger=trigger,
        action=action,
    )

    # When
    automation_to_proto = automation.to_proto()

    # Then
    assert automation_to_proto.automation_id == automation_id
    assert automation_to_proto.automation_spec.automation_name == automation_name
    assert automation_to_proto.automation_spec.model_id == model_id
    assert (
        automation_to_proto.automation_spec.trigger.WhichOneof("trigger")
        == "none_trigger"
    )


def test_automation_from_proto_with_none_trigger_type():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"

    trigger = TriggerProto(none_trigger=NoneTriggerProto())

    git_model_source = GitModelSourceProto(
        git_uri="https://github.com/qwak-ai/model-test.git#models/model_init/churn",
        git_credentials_secret_name="automation_sanity_github_token",
        git_branch="main",
    )
    cpu_resources = CpuResourcesProto(
        cpu=1.0, memory_amount=1, memory_units=MemoryUnitProto.MIB
    )
    resources = ResourcesProto(cpu_resources=cpu_resources)
    build_spec = BuildSpecProto(
        git_model_source=git_model_source, main_dir="main", resource=resources
    )

    build_metric = BuildMetricConditionProto(
        metric_name="f1_score",
        threshold_direction=MetricThresholdDirectionProto.ABOVE,
        threshold="0.0",
    )
    deployment_condition = DeploymentConditionProto(build_metric=build_metric)

    deployment_size = DeploymentSizeProto(
        number_of_pods=1,
        cpu=1.0,
        memory_amount=512,
        memory_units=MemoryUnitProto.MIB,
    )
    deployment_spec = DeploymentSpecProto(
        deployment_size=deployment_size,
        selected_variation_name="default",
    )

    build_deploy = BuildAndDeployActionProto(
        build_spec=build_spec,
        deployment_condition=deployment_condition,
        deployment_spec=deployment_spec,
    )
    action = ActionProto(build_deploy=build_deploy)

    automation_spec = AutomationSpecProto(
        model_id=model_id,
        automation_name=automation_name,
        trigger=trigger,
        action=action,
    )

    automation = AutomationProto(
        automation_id=automation_id, automation_spec=automation_spec
    )

    # When
    automation_from_proto = Automation.from_proto(automation)

    # Then
    assert automation_from_proto.id == automation_id
    assert automation_from_proto.name == automation_name
    assert automation_from_proto.model_id == model_id
    assert isinstance(automation_from_proto.trigger, NoneTrigger)


def test_automation_to_proto_with_on_boarding_trigger_type():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"

    trigger = OnBoardingTrigger()

    build_spec = BuildSpecifications(
        git_uri="https://github.com/qwak-ai/model-test.git#models/model_init/churn",
        git_access_token_secret="automation_sanity_github_token",
        git_branch="main",
        main_dir="main",
    )

    deployment_condition = BuildMetric(
        metric_name="f1_score", direction=ThresholdDirection.ABOVE, threshold="0.0"
    )

    deployment_spec = DeploymentSpecifications(
        number_of_pods=1, cpu_fraction=1.0, memory="512Mi", variation_name="default"
    )

    action = FrogmlBuildDeploy(
        build_spec=build_spec,
        deployment_condition=deployment_condition,
        deployment_spec=deployment_spec,
    )

    automation = Automation(
        id=automation_id,
        name=automation_name,
        model_id=model_id,
        execute_immediately=False,
        trigger=trigger,
        action=action,
    )

    # When
    automation_to_proto = automation.to_proto()

    # Then
    assert automation_to_proto.automation_id == automation_id
    assert automation_to_proto.automation_spec.automation_name == automation_name
    assert automation_to_proto.automation_spec.model_id == model_id
    assert (
        automation_to_proto.automation_spec.trigger.WhichOneof("trigger")
        == "on_boarding_trigger"
    )


def test_automation_from_proto_with_on_boarding_trigger_type():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"

    trigger = TriggerProto(on_boarding_trigger=OnBoardingTriggerProto())

    git_model_source = GitModelSourceProto(
        git_uri="https://github.com/qwak-ai/model-test.git#models/model_init/churn",
        git_credentials_secret_name="automation_sanity_github_token",
        git_branch="main",
    )
    cpu_resources = CpuResourcesProto(
        cpu=1.0, memory_amount=1, memory_units=MemoryUnitProto.MIB
    )
    resources = ResourcesProto(cpu_resources=cpu_resources)
    build_spec = BuildSpecProto(
        git_model_source=git_model_source, main_dir="main", resource=resources
    )

    build_metric = BuildMetricConditionProto(
        metric_name="f1_score",
        threshold_direction=MetricThresholdDirectionProto.ABOVE,
        threshold="0.0",
    )
    deployment_condition = DeploymentConditionProto(build_metric=build_metric)

    deployment_size = DeploymentSizeProto(
        number_of_pods=1,
        cpu=1.0,
        memory_amount=512,
        memory_units=MemoryUnitProto.MIB,
    )
    deployment_spec = DeploymentSpecProto(
        deployment_size=deployment_size,
        selected_variation_name="default",
    )

    build_deploy = BuildAndDeployActionProto(
        build_spec=build_spec,
        deployment_condition=deployment_condition,
        deployment_spec=deployment_spec,
    )
    action = ActionProto(build_deploy=build_deploy)

    automation_spec = AutomationSpecProto(
        model_id=model_id,
        automation_name=automation_name,
        trigger=trigger,
        action=action,
    )

    automation = AutomationProto(
        automation_id=automation_id, automation_spec=automation_spec
    )

    # When
    automation_from_proto = Automation.from_proto(automation)

    # Then
    assert automation_from_proto.id == automation_id
    assert automation_from_proto.name == automation_name
    assert automation_from_proto.model_id == model_id
    assert isinstance(automation_from_proto.trigger, OnBoardingTrigger)


def test_automation_to_proto_with_batch_execution_action():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"

    trigger = ScheduledTrigger(cron="0 0 1 1 1")

    data_specifications = BatchJobDataSpecifications(
        source_folder="source_folder",
        source_bucket="source_bucket",
        destination_folder="destination_folder",
        destination_bucket="destination_bucket",
        input_file_type="csv",
        output_file_type="csv",
        access_token_secret_name="access_token_secret_name",
        access_secret_secret_name="access_secret_secret_name",
        session_token_secret_name="session_token_secret_name",
    )

    batch_job_action = BatchExecution(data_specifications=data_specifications)

    automation = Automation(
        id=automation_id,
        name=automation_name,
        model_id=model_id,
        execute_immediately=False,
        trigger=trigger,
        action=batch_job_action,
        is_sdk_v1=True,
    )

    # When
    automation_to_proto = automation.to_proto()
    print(automation)
    # Then
    assert automation_to_proto.automation_id == automation_id
    assert automation_to_proto.automation_spec.automation_name == automation_name
    assert automation_to_proto.automation_spec.model_id == model_id
    assert (
        automation_to_proto.automation_spec.trigger.scheduled_trigger.cron
        == trigger.cron
    )
    assert (
        automation_to_proto.automation_spec.action.batch_execution.execute_batch_job.data_details.token_secret
        == data_specifications.access_token_secret_name
    )
    assert (
        automation_to_proto.automation_spec.action.batch_execution.execute_batch_job.data_details.session_token
        == data_specifications.session_token_secret_name
    )


def test_automation_from_proto_with_batch_execution_action():
    # Given
    automation_id = "automation_id"
    automation_name = "automation_name"
    model_id = "model_id"
    build_id = "build_id"
    source_folder = "source_folder"
    source_bucket = "source_bucket"
    access_token_secret_name = "access_token_secret_name"
    access_secret_secret_name = "access_secret_secret_name"
    session_token_secret_name = "session_token_secret_name"
    input_file_type = InputFileType.CSV_INPUT_FILE_TYPE
    destination_bucket = "bucket"
    destination_folder = "destination_folder"
    output_file_type = OutputFileType.CSV_OUTPUT_FILE_TYPE
    job_timeout = 2
    task_timeout = 3
    executors = 1
    cpu = 2
    custom_iam_role_arn = "custom_iam_role_arn"

    scheduled_trigger = ScheduledTriggerProto(cron="0 0 1 1 1")
    trigger = TriggerProto(scheduled_trigger=scheduled_trigger)

    data_details = BatchJobDataDetails(
        source_path=BatchJobSourcePath(
            source_folder=source_folder,
            source_bucket=source_bucket,
            input_file_type=input_file_type,
        ),
        destination_path=BatchJobDestinationPath(
            destination_folder=destination_folder,
            destination_bucket=destination_bucket,
            output_file_type=output_file_type,
        ),
        token_secret=access_token_secret_name,
        secret_secret=access_secret_secret_name,
        session_token=session_token_secret_name,
    )

    execution_details = BatchJobExecutionDetails(
        batch_job_deployment_size=BatchJobDeploymentSize(
            cpu=cpu,
            memory_units=MemoryUnit.GIB,
            memory_amount=3,
            number_of_pods=executors,
        ),
        job_timeout=job_timeout,
        task_timeout=task_timeout,
        advanced_deployment_options=BatchAdvancedDeploymentOptions(
            custom_iam_role_arn=custom_iam_role_arn
        ),
        parameters=[BatchJobParameter(key="parmeter_key", value="parmeter_value")],
    )

    action = ActionProto(
        batch_execution=BatchExecutionAction(
            execute_batch_job=BatchJobRequest(
                data_details=data_details,
                model_details=BatchJobModelDetails(build_id=build_id),
                execution_details=execution_details,
            )
        )
    )

    automation_spec = AutomationSpecProto(
        model_id=model_id,
        automation_name=automation_name,
        trigger=trigger,
        action=action,
        is_sdk_v1=True,
    )

    automation = AutomationProto(
        automation_id=automation_id, automation_spec=automation_spec
    )

    # When
    automation_from_proto = Automation.from_proto(automation)

    # Then
    assert automation_from_proto.id == automation_id
    assert automation_from_proto.name == automation_name
    assert automation_from_proto.model_id == model_id
    assert automation_from_proto.is_sdk_v1
    assert automation_from_proto.trigger.cron == trigger.scheduled_trigger.cron
    assert (
        job_timeout == automation_from_proto.action.execution_specifications.job_timeout
    )
    assert (
        task_timeout
        == automation_from_proto.action.execution_specifications.task_timeout
    )


def test_cpu_resources_from_common():
    # Given
    cpu_proto = CommonCpuResourcesProto(
        cpu=14.0, memory_amount=250, memory_units=CommonMemoryUnitProto.GIB
    )

    # When
    result = CpuResources.from_common_cpu_proto(cpu_proto)

    # Then
    assert result.cpu_fraction == cpu_proto.cpu
    assert result.memory == f"{cpu_proto.memory_amount}Gi"


def test_gpu_resources_to_common():
    # Given
    gpu_resources = GpuResources(gpu_amount=15, gpu_type="NVIDIA_K80")

    # When
    result = gpu_resources.to_gpu_proto()

    # Then
    assert result.gpu_type == CommonGpuTypeProto.NVIDIA_K80
    assert result.gpu_amount == gpu_resources.gpu_amount


def test_gpu_resources_from_common():
    # Given
    gpu_resources = CommonGpuResourcesProto(
        gpu_amount=15, gpu_type=CommonGpuTypeProto.NVIDIA_K80
    )

    # When
    result = GpuResources.from_gpu_proto(gpu_resources)

    # Then
    assert result.gpu_type == "NVIDIA_K80"
    assert result.gpu_amount == gpu_resources.gpu_amount


def test_client_resources_to_proto_with_instance():
    # Given
    resources = ClientResources(instance="medium")

    # When
    result = resources.to_proto()

    # Then
    assert (
        result.client_pod_compute_resources.template_spec.template_id
        == resources.instance
    )
    assert result.client_pod_compute_resources.cpu_resources.cpu == 0
    assert result.client_pod_compute_resources.cpu_resources.memory_amount == 0
    assert result.client_pod_compute_resources.gpu_resources.gpu_amount == 0
    assert result.client_pod_compute_resources.gpu_resources.gpu_type == 0


def test_client_resources_to_proto_with_cpu():
    # Given
    resources = ClientResources(
        cpu_resources=CpuResources(cpu_fraction=15.0, memory="32Mib")
    )

    # When
    result = resources.to_proto()

    # Then
    assert not result.client_pod_compute_resources.template_spec.template_id
    assert (
        result.client_pod_compute_resources.cpu_resources.cpu
        == resources.cpu_resources.cpu_fraction
    )
    assert result.client_pod_compute_resources.cpu_resources.memory_amount == 32
    assert result.client_pod_compute_resources.gpu_resources.gpu_amount == 0
    assert result.client_pod_compute_resources.gpu_resources.gpu_type == 0


def test_client_resources_to_proto_with_gpu():
    # Given
    resources = ClientResources(
        gpu_resources=GpuResources(gpu_amount=11, gpu_type="NVIDIA_K80")
    )

    # When
    result = resources.to_proto()

    # Then
    assert not result.client_pod_compute_resources.template_spec.template_id
    assert result.client_pod_compute_resources.cpu_resources.cpu == 0
    assert result.client_pod_compute_resources.cpu_resources.memory_amount == 0
    assert (
        result.client_pod_compute_resources.gpu_resources.gpu_amount
        == resources.gpu_resources.gpu_amount
    )
    assert (
        result.client_pod_compute_resources.gpu_resources.gpu_type
        == CommonGpuTypeProto.NVIDIA_K80
    )


def test_client_resources_from_proto_with_instance():
    # Given
    resources = ResourcesProto(
        client_pod_compute_resources=ClientPodComputeResources(
            template_spec=PodComputeResourceTemplateSpec(template_id="medium")
        )
    )

    # When
    result = ClientResources.from_proto(resources)

    # Then
    assert (
        result.instance
        == resources.client_pod_compute_resources.template_spec.template_id
    )
    assert result.cpu_resources is None
    assert result.gpu_resources is None


def test_client_resources_from_proto_with_cpu_resources():
    # Given
    resources = ResourcesProto(
        client_pod_compute_resources=ClientPodComputeResources(
            cpu_resources=CommonCpuResourcesProto(
                cpu=19.0,
                memory_units=CommonMemoryUnitProto.MIB,
                memory_amount=9,
            )
        )
    )

    # When
    result = ClientResources.from_proto(resources)

    # Then
    assert result.instance == ""
    assert (
        result.cpu_resources.cpu_fraction
        == resources.client_pod_compute_resources.cpu_resources.cpu
    )
    assert (
        result.cpu_resources.memory
        == f"{resources.client_pod_compute_resources.cpu_resources.memory_amount}Mib"
    )
    assert result.gpu_resources is None


def test_client_resources_from_proto_with_gpu_resources():
    # Given
    resources = ResourcesProto(
        client_pod_compute_resources=ClientPodComputeResources(
            gpu_resources=CommonGpuResourcesProto(
                gpu_type=CommonGpuTypeProto.NVIDIA_A100,
                gpu_amount=22,
            )
        )
    )

    # When
    result = ClientResources.from_proto(resources)

    # Then
    assert result.instance == ""
    assert result.cpu_resources is None
    assert (
        result.gpu_resources.gpu_amount
        == resources.client_pod_compute_resources.gpu_resources.gpu_amount
    )
    assert result.gpu_resources.gpu_type == "NVIDIA_A100"


def test_deployment_spec_from_common_resources_with_template():
    # Given
    deployment_spec_proto = DeploymentSpec(
        deployment_size=DeploymentSizeProto(
            client_pod_compute_resources=ClientPodComputeResources(
                template_spec=PodComputeResourceTemplateSpec(template_id="medium")
            )
        )
    )

    # When
    result = DeploymentSpecifications.from_proto(deployment_spec_proto)

    # Then
    assert (
        result.instance
        == deployment_spec_proto.deployment_size.client_pod_compute_resources.template_spec.template_id
    )


def test_deployment_spec_from_common_resources_with_cpu():
    # Given
    deployment_spec_proto = DeploymentSpec(
        deployment_size=DeploymentSizeProto(
            client_pod_compute_resources=ClientPodComputeResources(
                cpu_resources=CommonCpuResourcesProto(
                    cpu=3.0, memory_units=CommonMemoryUnitProto.GIB, memory_amount=14
                )
            )
        )
    )

    # When
    result = DeploymentSpecifications.from_proto(deployment_spec_proto)

    # Then
    assert result.instance == ""
    assert (
        result.cpu_fraction
        == deployment_spec_proto.deployment_size.client_pod_compute_resources.cpu_resources.cpu
    )
    assert (
        result.memory
        == f"{deployment_spec_proto.deployment_size.client_pod_compute_resources.cpu_resources.memory_amount}Gi"
    )


def test_deployment_spec_from_common_resources_with_gpu():
    # Given
    deployment_spec_proto = DeploymentSpec(
        deployment_size=DeploymentSizeProto(
            client_pod_compute_resources=ClientPodComputeResources(
                gpu_resources=CommonGpuResourcesProto(
                    gpu_amount=11, gpu_type=CommonGpuTypeProto.NVIDIA_T4
                )
            )
        )
    )

    # When
    result = DeploymentSpecifications.from_proto(deployment_spec_proto)

    # Then
    assert result.instance == ""
    assert result.cpu_fraction == 0
    assert (
        result.gpu_resources.gpu_amount
        == deployment_spec_proto.deployment_size.client_pod_compute_resources.gpu_resources.gpu_amount
    )
    assert result.gpu_resources.gpu_type == "NVIDIA_T4"


def test_deployment_spec_from_deprecated_resources_with_cpu():
    # Given
    deployment_spec_proto = DeploymentSpec(
        deployment_size=DeploymentSizeProto(
            cpu=3.0, memory_units=CommonMemoryUnitProto.GIB, memory_amount=14
        )
    )

    # When
    result = DeploymentSpecifications.from_proto(deployment_spec_proto)

    # Then
    assert result.instance == ""
    assert result.cpu_fraction == deployment_spec_proto.deployment_size.cpu
    assert result.memory == f"{deployment_spec_proto.deployment_size.memory_amount}Gi"


def test_deployment_spec_from_deprecated_resources_with_gpu():
    # Given
    deployment_spec_proto = DeploymentSpec(
        deployment_size=DeploymentSizeProto(
            gpu_resources=GpuResourcesProto(
                gpu_amount=11, gpu_type=GpuTypeProto.NVIDIA_T4
            )
        )
    )

    # When
    result = DeploymentSpecifications.from_proto(deployment_spec_proto)

    # Then
    assert result.instance == ""
    assert result.cpu_fraction == 0
    assert (
        result.gpu_resources.gpu_amount
        == deployment_spec_proto.deployment_size.gpu_resources.gpu_amount
    )
    assert result.gpu_resources.gpu_type == "NVIDIA_T4"


def test_deployment_spec_str_with_instance():
    spec = DeploymentSpecifications(instance="medium")
    print(spec)


def test_deployment_spec_str_with_cpu():
    spec = DeploymentSpecifications(cpu_fraction=1.0, memory="14Gi")
    print(spec)


def test_deployment_spec_str_with_gpu():
    spec = DeploymentSpecifications(
        gpu_resources=GpuResources(gpu_type="NVIDIA_K80", gpu_amount=15)
    )
    print(spec)


def test_deployment_specification_to_proto_with_instance():
    # Given
    spec = DeploymentSpecifications(instance="small")

    # When
    result = spec.to_proto()

    # Then
    assert (
        result.deployment_size.client_pod_compute_resources.template_spec.template_id
        == spec.instance
    )


def test_deployment_specification_to_proto_with_cpu():
    # Given
    spec = DeploymentSpecifications(cpu_fraction=12.0, memory="14Gi")

    # When
    result = spec.to_proto()

    # Then
    assert (
        result.deployment_size.client_pod_compute_resources.cpu_resources.cpu
        == spec.cpu_fraction
    )
    assert (
        result.deployment_size.client_pod_compute_resources.cpu_resources.memory_amount
        == 14
    )
    assert (
        result.deployment_size.client_pod_compute_resources.cpu_resources.memory_units
        == CommonMemoryUnitProto.GIB
    )

    # Check backwards compatibility
    assert result.deployment_size.cpu == spec.cpu_fraction
    assert result.deployment_size.memory_amount == 14
    assert result.deployment_size.memory_units == MemoryUnitProto.GIB


def test_deployment_specification_to_proto_with_gpu():
    # Given
    spec = DeploymentSpecifications(
        gpu_resources=GpuResources(gpu_amount=14, gpu_type="NVIDIA_K80")
    )

    # When
    result = spec.to_proto()

    # Then
    assert (
        result.deployment_size.client_pod_compute_resources.gpu_resources.gpu_amount
        == spec.gpu_resources.gpu_amount
    )
    assert (
        result.deployment_size.client_pod_compute_resources.gpu_resources.gpu_type
        == CommonGpuTypeProto.NVIDIA_K80
    )

    # Check backwards compatibility
    assert (
        result.deployment_size.gpu_resources.gpu_amount == spec.gpu_resources.gpu_amount
    )
    assert result.deployment_size.gpu_resources.gpu_type == GpuTypeProto.NVIDIA_K80


def test_build_specifications_to_proto_default_push_image_true():
    # Given
    build_spec = BuildSpecifications()

    # When
    result = build_spec.to_proto()

    # Then
    assert result.push_image.value is True


def test_build_specifications_to_proto_push_image_true():
    # Given
    build_spec = BuildSpecifications(push_image=True)

    # When
    result = build_spec.to_proto()

    # Then
    assert result.push_image.value is True


def test_build_specifications_to_proto_push_image_false():
    # Given
    build_spec = BuildSpecifications(push_image=False)

    # When
    result = build_spec.to_proto()

    # Then
    assert result.push_image.value is False


# Tests for AutoScaleQuerySpec with MetricType and AggregationType enums
@pytest.mark.parametrize(
    "metric_type, aggregation_type, expected_metric_proto, expected_aggregation_proto",
    [
        ("cpu", "avg", METRIC_TYPE_CPU, AGGREGATION_TYPE_AVERAGE),
        ("latency", "max", METRIC_TYPE_LATENCY, AGGREGATION_TYPE_MAX),
        ("memory", "min", METRIC_TYPE_MEMORY, AGGREGATION_TYPE_MIN),
        ("error_rate", "sum", METRIC_TYPE_ERROR_RATE, AGGREGATION_TYPE_SUM),
        ("cpu", "avg", METRIC_TYPE_CPU, AGGREGATION_TYPE_AVERAGE),
        # Percentile aggregations only for latency
        ("latency", "p50", METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P50),
        ("latency", "p90", METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P90),
        ("latency", "p95", METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P95),
        ("latency", "p99", METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P99),
        # Additional test cases for throughput and gpu
        ("throughput", "avg", METRIC_TYPE_THROUGHPUT, AGGREGATION_TYPE_AVERAGE),
        ("throughput", "max", METRIC_TYPE_THROUGHPUT, AGGREGATION_TYPE_MAX),
        ("throughput", "min", METRIC_TYPE_THROUGHPUT, AGGREGATION_TYPE_MIN),
        ("throughput", "sum", METRIC_TYPE_THROUGHPUT, AGGREGATION_TYPE_SUM),
        ("gpu", "avg", METRIC_TYPE_GPU, AGGREGATION_TYPE_AVERAGE),
        ("gpu", "max", METRIC_TYPE_GPU, AGGREGATION_TYPE_MAX),
        ("gpu", "min", METRIC_TYPE_GPU, AGGREGATION_TYPE_MIN),
        ("gpu", "sum", METRIC_TYPE_GPU, AGGREGATION_TYPE_SUM),
    ],
    ids=[
        "cpu_avg",
        "latency_max",
        "memory_min",
        "error_rate_sum",
        "cpu_avg_duplicate",
        "latency_p50",
        "latency_p90",
        "latency_p95",
        "latency_p99",
        "throughput_avg",
        "throughput_max",
        "throughput_min",
        "throughput_sum",
        "gpu_avg",
        "gpu_max",
        "gpu_min",
        "gpu_sum",
    ],
)
def test_auto_scale_query_spec_to_proto_map_when_parametrize_metric_type_then_succeed(
    metric_type, aggregation_type, expected_metric_proto, expected_aggregation_proto
):
    # Given
    query_spec = AutoScaleQuerySpec(
        metric_type=metric_type, aggregation_type=aggregation_type, time_period=60
    )

    # When
    result = query_spec.to_proto()

    # Then
    assert result.metric_type == expected_metric_proto
    assert result.aggregation_type == expected_aggregation_proto
    assert result.time_period == 60


@pytest.mark.parametrize(
    "metric_proto, aggregation_proto, expected_metric_type, expected_aggregation_type",
    [
        (METRIC_TYPE_CPU, AGGREGATION_TYPE_AVERAGE, "cpu", "avg"),
        (METRIC_TYPE_LATENCY, AGGREGATION_TYPE_MAX, "latency", "max"),
        (METRIC_TYPE_MEMORY, AGGREGATION_TYPE_MIN, "memory", "min"),
        (METRIC_TYPE_ERROR_RATE, AGGREGATION_TYPE_SUM, "error_rate", "sum"),
        # Percentile aggregations only for latency
        (METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P50, "latency", "p50"),
        (METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P90, "latency", "p90"),
        (METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P95, "latency", "p95"),
        (METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P99, "latency", "p99"),
        # Additional test cases for throughput and gpu
        (METRIC_TYPE_THROUGHPUT, AGGREGATION_TYPE_AVERAGE, "throughput", "avg"),
        (METRIC_TYPE_THROUGHPUT, AGGREGATION_TYPE_MAX, "throughput", "max"),
        (METRIC_TYPE_THROUGHPUT, AGGREGATION_TYPE_MIN, "throughput", "min"),
        (METRIC_TYPE_THROUGHPUT, AGGREGATION_TYPE_SUM, "throughput", "sum"),
        (METRIC_TYPE_GPU, AGGREGATION_TYPE_AVERAGE, "gpu", "avg"),
        (METRIC_TYPE_GPU, AGGREGATION_TYPE_MAX, "gpu", "max"),
        (METRIC_TYPE_GPU, AGGREGATION_TYPE_MIN, "gpu", "min"),
        (METRIC_TYPE_GPU, AGGREGATION_TYPE_SUM, "gpu", "sum"),
    ],
    ids=[
        "proto_cpu_avg",
        "proto_latency_max",
        "proto_memory_min",
        "proto_error_rate_sum",
        "proto_latency_p50",
        "proto_latency_p90",
        "proto_latency_p95",
        "proto_latency_p99",
        "proto_throughput_avg",
        "proto_throughput_max",
        "proto_throughput_min",
        "proto_throughput_sum",
        "proto_gpu_avg",
        "proto_gpu_max",
        "proto_gpu_min",
        "proto_gpu_sum",
    ],
)
def test_auto_scale_query_spec_from_proto_when_parametrize_metric_type_then_succeed(
    metric_proto, aggregation_proto, expected_metric_type, expected_aggregation_type
):
    # Given
    proto = QuerySpec(
        metric_type=metric_proto, aggregation_type=aggregation_proto, time_period=60
    )

    # When
    result = AutoScaleQuerySpec.from_proto(proto)

    # Then
    assert result.metric_type == expected_metric_type
    assert result.aggregation_type == expected_aggregation_type
    assert result.time_period == 60


@pytest.mark.parametrize(
    "metric_type, aggregation_type, expected_metric_proto, expected_aggregation_proto",
    [
        ("latency", "p50", METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P50),
        ("latency", "p90", METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P90),
        ("latency", "p95", METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P95),
        ("latency", "p99", METRIC_TYPE_LATENCY, AGGREGATION_TYPE_P99),
    ],
    ids=["percentile_p50", "percentile_p90", "percentile_p95", "percentile_p99"],
)
def test_auto_scale_query_spec_to_proto_when_map_parametrize_latency_metric_type_then_succeed(
    metric_type, aggregation_type, expected_metric_proto, expected_aggregation_proto
):
    # Given
    query_spec = AutoScaleQuerySpec(
        metric_type=metric_type, aggregation_type=aggregation_type, time_period=60
    )

    # When
    result = query_spec.to_proto()

    # Then
    assert result.metric_type == expected_metric_proto
    assert result.aggregation_type == expected_aggregation_proto
    assert result.time_period == 60


@pytest.mark.parametrize("proto_value", ["https://example.com", ""])
def test_automation_to_proto_when_platform_url_varies_then_maps_correctly(
    proto_value,
):
    dataclass = Automation(
        id="automation_id",
        name="automation_name",
        model_id="model_id",
        trigger=ScheduledTrigger(cron="0 0 1 1 1"),
        action=FrogmlBuildDeploy(
            build_spec=BuildSpecifications(),
            deployment_condition=BuildMetric(),
            deployment_spec=DeploymentSpecifications(),
        ),
        is_sdk_v1=True,
        platform_url=proto_value,
    )
    to_proto_result = Automation.to_proto(dataclass)
    assert to_proto_result.platform_url == proto_value


@pytest.mark.parametrize("platform_url", ["https://example.com", None, ""])
def test_automation_from_proto_when_platform_url_varies_then_maps_correctly(
    platform_url,
):
    proto = Automation(
        id="automation_id",
        name="automation_name",
        model_id="model_id",
        trigger=ScheduledTrigger(cron="0 0 1 1 1"),
        action=FrogmlBuildDeploy(
            build_spec=BuildSpecifications(),
            deployment_condition=BuildMetric(),
            deployment_spec=DeploymentSpecifications(),
        ),
        is_sdk_v1=True,
        platform_url=platform_url,
    ).to_proto()
    from_proto_result = Automation.from_proto(proto)
    assert from_proto_result.platform_url == (platform_url or "")
