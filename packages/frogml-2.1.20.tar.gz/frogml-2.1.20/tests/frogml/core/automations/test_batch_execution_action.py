import pytest

from frogml._proto.qwak.automation.v1.action_pb2 import (
    Action,
    BatchExecutionAction,
    MemoryUnit,
)
from frogml._proto.qwak.batch_job.v1.batch_job_service_pb2 import (
    AdvancedDeploymentOptions as BatchAdvancedDeploymentOptions,
)
from frogml._proto.qwak.batch_job.v1.batch_job_service_pb2 import (
    BatchJobDataDetails,
    BatchJobDeploymentSize,
    BatchJobDestinationPath,
    BatchJobExecutionDetails,
    BatchJobModelDetails,
    BatchJobParameter,
    BatchJobRequest,
    BatchJobSourcePath,
    InputFileType,
    OutputFileType,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    ClientPodComputeResources,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    CpuResources as CommonCpuResourcesProto,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    GpuResources as CommonGpuResourcesProto,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    GpuType as CommonGpuTypeProto,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    MemoryUnit as CommonMemoryUnitProto,
)
from frogml._proto.qwak.user_application.common.v0.resources_pb2 import (
    PodComputeResourceTemplateSpec,
)
from frogml.core.automations import (
    BatchExecution,
    BatchJobDataSpecifications,
    BatchJobExecutionSpecifications,
)
from frogml.core.automations.batch_execution_action import (
    input_file_type_convert_from_enum,
    input_file_type_convert_to_enum,
    output_file_type_convert_from_enum,
    output_file_type_convert_to_enum,
)


def test_batch_execution_to_proto():
    # given
    source_folder = "source_folder"
    source_bucket = "source_bucket"
    access_token_secret_name = "access_token_secret_name"
    access_secret_secret_name = "access_secret_secret_name"
    session_token_secret_name = "session_token_secret_name"
    input_file_type = "csv"
    destination_bucket = "bucket"
    destination_folder = "destination_folder"
    output_file_type = "csv"

    job_timeout = 2
    task_timeout = 3
    executors = 1
    cpu = 2
    memory = "2Gi"
    parmas = {"key": "value", "key2": "value2"}
    data_specifications = BatchJobDataSpecifications(
        source_folder=source_folder,
        source_bucket=source_bucket,
        destination_folder=destination_folder,
        destination_bucket=destination_bucket,
        input_file_type=input_file_type,
        output_file_type=output_file_type,
        access_token_secret_name=access_token_secret_name,
        access_secret_secret_name=access_secret_secret_name,
        session_token_secret_name=session_token_secret_name,
    )
    execution_specifications = BatchJobExecutionSpecifications(
        job_timeout=job_timeout,
        task_timeout=task_timeout,
        executors=executors,
        cpu=cpu,
        memory=memory,
        params=parmas,
        gpu_type="NVIDIA_T4",
        gpu_amount=1,
    )

    batch_job_action = BatchExecution(
        execution_specifications=execution_specifications,
        data_specifications=data_specifications,
    )

    print(batch_job_action)

    # When
    action_proto = batch_job_action.to_proto()

    # Then
    assert (
        source_folder
        == action_proto.batch_execution.execute_batch_job.data_details.source_path.source_folder
    )
    assert (
        source_bucket
        == action_proto.batch_execution.execute_batch_job.data_details.source_path.source_bucket
    )
    assert (
        InputFileType.CSV_INPUT_FILE_TYPE
        == action_proto.batch_execution.execute_batch_job.data_details.source_path.input_file_type
    )
    assert (
        destination_folder
        == action_proto.batch_execution.execute_batch_job.data_details.destination_path.destination_folder
    )
    assert (
        destination_bucket
        == action_proto.batch_execution.execute_batch_job.data_details.destination_path.destination_bucket
    )
    assert (
        OutputFileType.CSV_OUTPUT_FILE_TYPE
        == action_proto.batch_execution.execute_batch_job.data_details.destination_path.output_file_type
    )
    assert (
        access_secret_secret_name
        == action_proto.batch_execution.execute_batch_job.data_details.secret_secret
    )
    assert (
        access_token_secret_name
        == action_proto.batch_execution.execute_batch_job.data_details.token_secret
    )
    assert (
        session_token_secret_name
        == action_proto.batch_execution.execute_batch_job.data_details.session_token
    )

    assert (
        job_timeout
        == action_proto.batch_execution.execute_batch_job.execution_details.job_timeout
    )
    assert (
        task_timeout
        == action_proto.batch_execution.execute_batch_job.execution_details.task_timeout
    )

    assert (
        cpu
        == action_proto.batch_execution.execute_batch_job.execution_details.batch_job_deployment_size.cpu
    )
    assert (
        executors
        == action_proto.batch_execution.execute_batch_job.execution_details.batch_job_deployment_size.number_of_pods
    )
    assert (
        2
        == action_proto.batch_execution.execute_batch_job.execution_details.batch_job_deployment_size.memory_amount
    )
    assert (
        MemoryUnit.GIB
        == action_proto.batch_execution.execute_batch_job.execution_details.batch_job_deployment_size.memory_units
    )
    first_param = [
        param
        for param in action_proto.batch_execution.execute_batch_job.execution_details.parameters
        if param.key == "key"
    ][0]
    assert parmas["key"] == first_param.value

    secound_param = [
        param
        for param in action_proto.batch_execution.execute_batch_job.execution_details.parameters
        if param.key == "key2"
    ][0]
    assert parmas["key2"] == secound_param.value


def test_batch_execution_without_execution_specifications_to_proto():
    # given
    source_folder = "source_folder"
    source_bucket = "source_bucket"
    access_token_secret_name = "access_token_secret_name"
    access_secret_secret_name = "access_secret_secret_name"
    session_token_secret_name = "session_token_secret_name"
    input_file_type = "csv"
    destination_bucket = "bucket"
    destination_folder = "destination_folder"
    output_file_type = "csv"

    data_specifications = BatchJobDataSpecifications(
        source_folder=source_folder,
        source_bucket=source_bucket,
        destination_folder=destination_folder,
        destination_bucket=destination_bucket,
        input_file_type=input_file_type,
        output_file_type=output_file_type,
        access_token_secret_name=access_token_secret_name,
        access_secret_secret_name=access_secret_secret_name,
        session_token_secret_name=session_token_secret_name,
    )

    batch_job_action = BatchExecution(data_specifications=data_specifications)

    # When
    action_proto = batch_job_action.to_proto()

    # Then
    assert (
        source_folder
        == action_proto.batch_execution.execute_batch_job.data_details.source_path.source_folder
    )
    assert (
        source_bucket
        == action_proto.batch_execution.execute_batch_job.data_details.source_path.source_bucket
    )
    assert (
        InputFileType.CSV_INPUT_FILE_TYPE
        == action_proto.batch_execution.execute_batch_job.data_details.source_path.input_file_type
    )
    assert (
        destination_folder
        == action_proto.batch_execution.execute_batch_job.data_details.destination_path.destination_folder
    )
    assert (
        destination_bucket
        == action_proto.batch_execution.execute_batch_job.data_details.destination_path.destination_bucket
    )
    assert (
        OutputFileType.CSV_OUTPUT_FILE_TYPE
        == action_proto.batch_execution.execute_batch_job.data_details.destination_path.output_file_type
    )
    assert (
        access_secret_secret_name
        == action_proto.batch_execution.execute_batch_job.data_details.secret_secret
    )
    assert (
        access_token_secret_name
        == action_proto.batch_execution.execute_batch_job.data_details.token_secret
    )
    assert (
        session_token_secret_name
        == action_proto.batch_execution.execute_batch_job.data_details.session_token
    )


def test_batch_execution_from_proto():
    # given
    build_id = "build_id"
    source_folder = "source_folder"
    source_bucket = "source_bucket"
    access_token_secret_name = "access_token_secret_name"
    access_secret_secret_name = "access_secret_secret_name"
    input_file_type = InputFileType.CSV_INPUT_FILE_TYPE
    session_token_secret_name = "session_token_secret_name"
    destination_bucket = "bucket"
    destination_folder = "destination_folder"
    output_file_type = OutputFileType.CSV_OUTPUT_FILE_TYPE

    job_timeout = 2
    task_timeout = 3
    executors = 1
    cpu = 2
    custom_iam_role_arn = "custom_iam_role_arn"
    param = BatchJobParameter(key="parmeter_key", value="parmeter_value")
    data_details = BatchJobDataDetails(
        source_path=BatchJobSourcePath(
            source_folder=source_folder,
            source_bucket=source_bucket,
            input_file_type=input_file_type,
        ),
        destination_path=BatchJobDestinationPath(
            destination_folder=destination_folder,
            destination_bucket=destination_bucket,
            output_file_type=output_file_type,
        ),
        token_secret=access_token_secret_name,
        secret_secret=access_secret_secret_name,
        session_token=session_token_secret_name,
    )

    execution_details = BatchJobExecutionDetails(
        batch_job_deployment_size=BatchJobDeploymentSize(
            cpu=cpu,
            memory_units=MemoryUnit.GIB,
            memory_amount=3,
            number_of_pods=executors,
        ),
        job_timeout=job_timeout,
        task_timeout=task_timeout,
        advanced_deployment_options=BatchAdvancedDeploymentOptions(
            custom_iam_role_arn=custom_iam_role_arn
        ),
        parameters=[param],
    )

    batch_job_action = Action(
        batch_execution=BatchExecutionAction(
            execute_batch_job=BatchJobRequest(
                data_details=data_details,
                model_details=BatchJobModelDetails(build_id=build_id),
                execution_details=execution_details,
            )
        )
    )

    # When
    action = BatchExecution.from_proto(batch_job_action)

    # Then
    assert source_folder == action.data_specifications.source_folder
    assert source_bucket == action.data_specifications.source_bucket
    assert "csv" == action.data_specifications.input_file_type
    assert destination_folder == action.data_specifications.destination_folder
    assert destination_bucket == action.data_specifications.destination_bucket
    assert "csv" == action.data_specifications.output_file_type
    assert (
        access_secret_secret_name
        == action.data_specifications.access_secret_secret_name
    )
    assert (
        access_token_secret_name == action.data_specifications.access_token_secret_name
    )
    assert (
        session_token_secret_name
        == action.data_specifications.session_token_secret_name
    )

    assert job_timeout == action.execution_specifications.job_timeout
    assert task_timeout == action.execution_specifications.task_timeout
    assert cpu == action.execution_specifications.cpu
    assert executors == action.execution_specifications.executors
    assert "3Gi" == action.execution_specifications.memory  #
    assert custom_iam_role_arn == action.execution_specifications.custom_iam_role_arn
    assert param.value == action.execution_specifications.params[param.key]

    assert build_id == action.build_id


@pytest.mark.parametrize(
    "input_text, intput_type_expected",
    [
        ("CSV", InputFileType.CSV_INPUT_FILE_TYPE),
        ("Csv", InputFileType.CSV_INPUT_FILE_TYPE),
        ("parquet", InputFileType.PARQUET_INPUT_FILE_TYPE),
        ("feather", InputFileType.FEATHER_INPUT_FILE_TYPE),
        ("PNG", InputFileType.UNDEFINED_INPUT_FILE_TYPE),
    ],
)
def test_input_file_type_mapper_to_enum(input_text, intput_type_expected):
    assert intput_type_expected == input_file_type_convert_to_enum(input_text)


@pytest.mark.parametrize(
    "input_type, intput_text_expected",
    [
        (InputFileType.CSV_INPUT_FILE_TYPE, "csv"),
        (InputFileType.PARQUET_INPUT_FILE_TYPE, "parquet"),
        (InputFileType.FEATHER_INPUT_FILE_TYPE, "feather"),
    ],
)
def test_input_file_type_mapper_from_enum(input_type, intput_text_expected):
    assert intput_text_expected == input_file_type_convert_from_enum(input_type)


@pytest.mark.parametrize(
    "output_text, output_type_expected",
    [
        ("CSV", OutputFileType.CSV_OUTPUT_FILE_TYPE),
        ("Csv", OutputFileType.CSV_OUTPUT_FILE_TYPE),
        ("parquet", OutputFileType.PARQUET_OUTPUT_FILE_TYPE),
        ("feather", OutputFileType.FEATHER_OUTPUT_FILE_TYPE),
        ("PNG", OutputFileType.UNDEFINED_OUTPUT_FILE_TYPE),
    ],
)
def test_output_file_type_mapper_to_enum(output_text, output_type_expected):
    assert output_type_expected == output_file_type_convert_to_enum(output_text)


@pytest.mark.parametrize(
    "output_type, output_text_expected",
    [
        (OutputFileType.CSV_OUTPUT_FILE_TYPE, "csv"),
        (OutputFileType.PARQUET_OUTPUT_FILE_TYPE, "parquet"),
        (OutputFileType.FEATHER_OUTPUT_FILE_TYPE, "feather"),
    ],
)
def test_output_file_type_mapper_from_enum(output_type, output_text_expected):
    assert output_file_type_convert_from_enum(output_type) == output_text_expected


def test_batch_execution_spec_from_common_resources_with_instance():
    # Given
    execution_details_proto = BatchJobExecutionDetails(
        batch_job_deployment_size=BatchJobDeploymentSize(
            client_pod_compute_resources=ClientPodComputeResources(
                template_spec=PodComputeResourceTemplateSpec(template_id="large")
            )
        )
    )

    # When
    result = BatchJobExecutionSpecifications.from_proto(execution_details_proto)

    # Then
    assert (
        result.instance
        == execution_details_proto.batch_job_deployment_size.client_pod_compute_resources.template_spec.template_id
    )


def test_batch_execution_spec_from_common_resources_with_cpu():
    # Given
    execution_details_proto = BatchJobExecutionDetails(
        batch_job_deployment_size=BatchJobDeploymentSize(
            client_pod_compute_resources=ClientPodComputeResources(
                cpu_resources=CommonCpuResourcesProto(
                    cpu=11, memory_amount=12, memory_units=CommonMemoryUnitProto.MIB
                )
            )
        )
    )

    # When
    result = BatchJobExecutionSpecifications.from_proto(execution_details_proto)

    # Then
    assert (
        result.cpu
        == execution_details_proto.batch_job_deployment_size.client_pod_compute_resources.cpu_resources.cpu
    )
    assert (
        result.memory
        == f"{execution_details_proto.batch_job_deployment_size.client_pod_compute_resources.cpu_resources.memory_amount}Mib"
    )


def test_batch_execution_spec_from_common_resources_with_gpu():
    # Given
    execution_details_proto = BatchJobExecutionDetails(
        batch_job_deployment_size=BatchJobDeploymentSize(
            client_pod_compute_resources=ClientPodComputeResources(
                gpu_resources=CommonGpuResourcesProto(
                    gpu_amount=12, gpu_type=CommonGpuTypeProto.NVIDIA_A10G
                )
            )
        )
    )

    # When
    result = BatchJobExecutionSpecifications.from_proto(execution_details_proto)

    # Then
    assert (
        result.gpu_amount
        == execution_details_proto.batch_job_deployment_size.client_pod_compute_resources.gpu_resources.gpu_amount
    )
    assert result.gpu_type == "NVIDIA_A10G"


def test_batch_execution_spec_from_deprecated_resources_with_cpu():
    # Given
    execution_details_proto = BatchJobExecutionDetails(
        batch_job_deployment_size=BatchJobDeploymentSize(
            cpu=11, memory_amount=12, memory_units=MemoryUnit.MIB
        )
    )

    # When
    result = BatchJobExecutionSpecifications.from_proto(execution_details_proto)

    # Then
    assert result.cpu == execution_details_proto.batch_job_deployment_size.cpu
    assert (
        result.memory
        == f"{execution_details_proto.batch_job_deployment_size.memory_amount}Mib"
    )


def test_batch_execution_spec_from_deprecated_resources_with_gpu():
    # Given
    execution_details_proto = BatchJobExecutionDetails(
        batch_job_deployment_size=BatchJobDeploymentSize(
            gpu_resources=CommonGpuResourcesProto(
                gpu_amount=12, gpu_type=CommonGpuTypeProto.NVIDIA_A10G
            )
        )
    )

    # When
    result = BatchJobExecutionSpecifications.from_proto(execution_details_proto)

    # Then
    assert (
        result.gpu_amount
        == execution_details_proto.batch_job_deployment_size.gpu_resources.gpu_amount
    )
    assert result.gpu_type == "NVIDIA_A10G"
