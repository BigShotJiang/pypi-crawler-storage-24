from concurrent import futures
from pathlib import Path
from typing import Callable

import grpc
import pytest
import yaml

from frogml._proto.qwak.administration.account.v1.account_pb2 import AccountType
from frogml._proto.qwak.administration.v0.authentication import (
    authentication_service_pb2_grpc,
)
from frogml._proto.qwak.administration.v0.environments.configuration_pb2 import (
    QwakEnvironmentConfiguration as FrogmlEnvironmentConfiguration,
)
from frogml._proto.qwak.ecosystem.v0.ecosystem_pb2 import (
    AuthenticatedUnifiedUserContext,
    AuthenticatedUserContext,
    EnvironmentDetails,
    UserContextAccountDetails,
)
from frogml._proto.qwak.ecosystem.v0.ecosystem_runtime_service_pb2 import (
    GetAuthenticatedUserContextResponse,
)
from frogml._proto.qwak.feature_store.entities.entity_pb2 import (
    EntityDefinition,
    EntitySpec,
)
from frogml._proto.qwak.feature_store.features.feature_set_pb2 import (
    FeatureSetDefinition,
    FeatureSetSpec,
)
from frogml._proto.qwak.feature_store.features.feature_set_types_pb2 import (
    BatchFeatureSet,
    FeatureSetType,
    StreamingFeatureSetV1,
)
from frogml._proto.qwak.feature_store.serving import serving_pb2_grpc
from frogml._proto.qwak.offline.serving.v1.options_pb2 import (
    OfflineServingQueryOptions as ProtoOfflineServingQueryOptions,
)
from frogml.core.clients.feature_store import FeatureRegistryClient
from frogml.core.inner.tool.grpc.grpc_tools import create_grpc_channel
from frogml_services_mock.mocks.authentication_service import AuthenticationServiceMock
from frogml_services_mock.mocks.features_online_serving_api import ServingServiceMock
from frogml_services_mock.mocks.frogml_mocks import FrogmlMocks
from frogml_services_mock.services_mock import attach_servicers, frogml_container
from frogml_services_mock.utils.service_utils import find_free_port


def pytest_addoption(parser):
    parser.addoption(
        "--rt_url", action="store", default="http://localhost:8081/artifactory"
    )
    parser.addoption("--rt_access_token", action="store", default="")


@pytest.fixture(scope="session")
def serving_service():
    serving = ServingServiceMock()
    return serving


@pytest.fixture(scope="session")
def grpc_server(serving_service):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    authentication_service_pb2_grpc.add_AuthenticationServiceServicer_to_server(
        AuthenticationServiceMock(), server
    )
    serving_pb2_grpc.add_ServingServiceServicer_to_server(serving_service, server)

    port = find_free_port()
    server.add_insecure_port(f"[::]:{port}")  # noqa: E231
    server.start()
    yield server, port
    server.stop(0)


@pytest.fixture(scope="function")
def grpc_channel(grpc_server):
    return create_grpc_channel(
        url=f"localhost:{grpc_server[1]}",  # noqa: E231
        enable_ssl=False,
        enable_auth=False,  # noqa: E231
    )


@pytest.fixture(scope="function")
def frogml_services_mock():
    free_port = frogml_container()

    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    frogml_mocks: FrogmlMocks = attach_servicers(free_port, server)

    server.add_insecure_port(f"[::]:{free_port}")  # noqa: E231
    server.start()

    yield frogml_mocks

    server.stop(0)


@pytest.fixture(scope="function")
def model_api_url(httpserver):
    port = httpserver.port
    host = httpserver.host
    return f"{host}:{port}"  # noqa


@pytest.fixture(scope="session")
def default_environment_id() -> str:
    return "env_id"


@pytest.fixture(scope="session")
def env_name() -> str:
    return "env_name"


@pytest.fixture(scope="function")
def ecosystem_service_mock(
    frogml_services_mock, model_api_url, default_environment_id: str, env_name: str
):
    frogml_services_mock.ecosystem_client_mock.given_authenticated_user_context(
        GetAuthenticatedUserContextResponse(
            authenticated_user_context=AuthenticatedUserContext(
                user=AuthenticatedUnifiedUserContext(
                    account_details=UserContextAccountDetails(
                        default_environment_id=default_environment_id,
                        environment_by_id={
                            default_environment_id: EnvironmentDetails(
                                name=env_name,
                                configuration=FrogmlEnvironmentConfiguration(
                                    edge_services_url="grpc.test.com",
                                    model_api_url=model_api_url,
                                ),
                            )
                        },
                        type=AccountType.HYBRID,
                    ),
                    environment_details=EnvironmentDetails(
                        id=default_environment_id,
                        name=env_name,
                        configuration=FrogmlEnvironmentConfiguration(
                            edge_services_url="grpc.test.com",
                            model_api_url=model_api_url,
                        ),
                    ),
                )
            )
        )
    )


@pytest.fixture
def featureset_registry_client():
    return FeatureRegistryClient()


@pytest.fixture
def given_batch_feature_set(
    featureset_registry_client,
) -> Callable[[str], FeatureSetDefinition]:
    def create(name: str) -> FeatureSetDefinition:
        return featureset_registry_client.create_feature_set(
            FeatureSetSpec(
                name=name,
                git_commit="123",
                entity=EntityDefinition(
                    entity_id="123", entity_spec=EntitySpec(keys=["uuid"])
                ),
                feature_set_type=FeatureSetType(
                    batch_feature_set=BatchFeatureSet(
                        scheduling_policy="@daily",
                    )
                ),
                features=[],
            )
        ).feature_set.feature_set_definition

    return create


@pytest.fixture
def given_update_batch_feature_set(
    featureset_registry_client: FeatureRegistryClient,
) -> Callable[[str], FeatureSetDefinition]:
    def update(name: str) -> FeatureSetDefinition:
        fs_definition: FeatureSetDefinition = (
            featureset_registry_client.get_feature_set_by_name(
                feature_set_name=name
            ).feature_set.feature_set_definition
        )

        return featureset_registry_client.update_feature_set(
            feature_set_id=fs_definition.feature_set_id,
            proto_feature_set=fs_definition.feature_set_spec,
        ).feature_set.feature_set_definition

    return update


@pytest.fixture
def given_streaming_feature_set(
    featureset_registry_client,
) -> Callable[[str], FeatureSetDefinition]:
    def create(name):
        return featureset_registry_client.create_feature_set(
            FeatureSetSpec(
                name=name,
                git_commit="123",
                entity=EntityDefinition(
                    entity_id="123", entity_spec=EntitySpec(keys=["uuid"])
                ),
                feature_set_type=FeatureSetType(
                    streaming_feature_set_v1=StreamingFeatureSetV1(
                        timestamp_column_name="time_column"
                    )
                ),
                features=[],
            )
        ).feature_set.feature_set_definition

    return create


@pytest.fixture
def offline_serving_query_options_include_version() -> ProtoOfflineServingQueryOptions:
    return ProtoOfflineServingQueryOptions(include_featureset_version_column=True)


@pytest.fixture
def offline_serving_query_options_dont_include_version() -> (
    ProtoOfflineServingQueryOptions
):
    return ProtoOfflineServingQueryOptions(include_featureset_version_column=False)


@pytest.fixture(scope="session")
def default_grpc_config() -> dict:
    config_text: str = (
        Path(__file__).parent.parent.parent
        / "frogml"
        / "core"
        / "inner"
        / "di_configuration"
        / "config.yml"
    ).read_text()

    return yaml.load(stream=config_text, Loader=yaml.SafeLoader)


@pytest.fixture(scope="session")
def default_control_plane_grpc_address(
    default_grpc_config: dict,
) -> str:
    return default_grpc_config["grpc"]["core"]["address"]
