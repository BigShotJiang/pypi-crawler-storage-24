from http import HTTPStatus

from frogml.core.exceptions.frogml_exception import FrogmlException


class FrogmlNotFoundException(FrogmlException):
    """Exception for resource not found errors."""

    def __init__(
        self,
        error_message: str,
        status_code: int = HTTPStatus.NOT_FOUND,
        operation: str = "FrogML Operation",
    ) -> None:
        super().__init__(
            error_message=error_message,
            status_code=status_code,
            operation=operation,
        )
