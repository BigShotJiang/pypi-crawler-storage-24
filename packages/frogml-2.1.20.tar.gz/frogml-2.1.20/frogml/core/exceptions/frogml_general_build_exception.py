from http import HTTPStatus
from typing import Optional

from frogml.core.exceptions.frogml_exception import FrogmlException


class FrogmlGeneralBuildException(FrogmlException):
    def __init__(
        self,
        error_message: str,
        src_exception: Optional[Exception] = None,
        status_code: int = HTTPStatus.INTERNAL_SERVER_ERROR,
    ) -> None:
        full_message: str = error_message
        if src_exception:
            full_message = f"{error_message}: {src_exception}"
        super().__init__(
            error_message=full_message,
            status_code=status_code,
            operation="Build",
        )
