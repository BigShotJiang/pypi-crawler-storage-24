import sys
from types import TracebackType
from typing import Optional

from .frogml_exception import FrogmlException
from .frogml_general_build_exception import FrogmlGeneralBuildException
from .frogml_grpc_address_exception import FrogmlGrpcAddressException
from .frogml_http_exception import FrogmlHTTPException
from .frogml_inference_exception import FrogmlInferenceException
from .frogml_load_configuration_exception import LoadConfigurationException
from .frogml_login_exception import FrogmlLoginException
from .frogml_mock_http_exception import MockHttpException
from .frogml_model_initialization_exception import FrogmlModelInitializationException
from .frogml_not_found_exception import FrogmlNotFoundException
from .frogml_remote_build_failed import FrogmlRemoteBuildFailedException
from .frogml_suggestion_exception import FrogmlSuggestionException


def _quiet_hook(
    kind: type[BaseException],
    message: BaseException,
    traceback: Optional[TracebackType],
) -> None:
    """Custom exception hook that suppresses tracebacks for FrogmlException."""
    if isinstance(message, FrogmlException):
        print(message.formatted_message())
    else:
        sys.__excepthook__(kind, message, traceback)


sys.excepthook = _quiet_hook
