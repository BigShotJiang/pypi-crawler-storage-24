"""Mapping between gRPC status codes and HTTP status codes."""

from http import HTTPStatus
from typing import Final, Optional

import grpc

# Standard gRPC to HTTP status code mapping
# Reference: https://cloud.google.com/apis/design/errors#handling_errors
GRPC_TO_HTTP_STATUS: Final[dict[grpc.StatusCode, int]] = {
    grpc.StatusCode.OK: HTTPStatus.OK,
    grpc.StatusCode.CANCELLED: 499,  # Client Closed Request (non-standard)
    grpc.StatusCode.UNKNOWN: HTTPStatus.INTERNAL_SERVER_ERROR,
    grpc.StatusCode.INVALID_ARGUMENT: HTTPStatus.BAD_REQUEST,
    grpc.StatusCode.DEADLINE_EXCEEDED: HTTPStatus.GATEWAY_TIMEOUT,
    grpc.StatusCode.NOT_FOUND: HTTPStatus.NOT_FOUND,
    grpc.StatusCode.ALREADY_EXISTS: HTTPStatus.CONFLICT,
    grpc.StatusCode.PERMISSION_DENIED: HTTPStatus.FORBIDDEN,
    grpc.StatusCode.RESOURCE_EXHAUSTED: HTTPStatus.TOO_MANY_REQUESTS,
    grpc.StatusCode.FAILED_PRECONDITION: HTTPStatus.PRECONDITION_FAILED,
    grpc.StatusCode.ABORTED: HTTPStatus.CONFLICT,
    grpc.StatusCode.OUT_OF_RANGE: HTTPStatus.BAD_REQUEST,
    grpc.StatusCode.UNIMPLEMENTED: HTTPStatus.NOT_IMPLEMENTED,
    grpc.StatusCode.INTERNAL: HTTPStatus.INTERNAL_SERVER_ERROR,
    grpc.StatusCode.UNAVAILABLE: HTTPStatus.SERVICE_UNAVAILABLE,
    grpc.StatusCode.DATA_LOSS: HTTPStatus.INTERNAL_SERVER_ERROR,
    grpc.StatusCode.UNAUTHENTICATED: HTTPStatus.UNAUTHORIZED,
}


def grpc_to_http_status(grpc_code: Optional[grpc.StatusCode]) -> int:
    """
    Convert gRPC status code to HTTP status code.

    Args:
        grpc_code: The gRPC status code to convert.

    Returns:
        The corresponding HTTP status code. Defaults to 500 if grpc_code is None or unknown.
    """
    if grpc_code is None:
        return HTTPStatus.INTERNAL_SERVER_ERROR
    return GRPC_TO_HTTP_STATUS.get(grpc_code, HTTPStatus.INTERNAL_SERVER_ERROR)
