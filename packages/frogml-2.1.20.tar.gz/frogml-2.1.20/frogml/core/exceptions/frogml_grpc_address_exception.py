from http import HTTPStatus

from frogml.core.exceptions import FrogmlException


class FrogmlGrpcAddressException(FrogmlException):
    """Exception for invalid gRPC address configuration."""

    def __init__(
        self,
        details: str,
        grpc_address: str,
        status_code: int = HTTPStatus.BAD_REQUEST,
        operation: str = "Configure gRPC Address",
    ) -> None:
        super().__init__(
            error_message=f"Not a valid gRPC address: '{grpc_address}'. Details: {details}",
            status_code=status_code,
            operation=operation,
        )
