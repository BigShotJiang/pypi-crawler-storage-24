import inspect
from http import HTTPStatus
from typing import Callable, Optional, Any

import grpc

from frogml.core.exceptions.grpc_status_mapping import grpc_to_http_status
from frogml.storage.logging import logger


class FrogmlException(Exception):
    """
    Base exception for FrogML SDK errors.

    Displays errors in JF CLI format without tracebacks:
        Error: {operation}
        -----------------------------
        Status:  {status_code} {status_phrase}
        Message: {error_message}
    """

    def __init__(
        self,
        error_message: str,
        status_code: int = HTTPStatus.INTERNAL_SERVER_ERROR,
        operation: str = "FrogML Operation",
    ) -> None:
        super().__init__(error_message)
        self.error_message: str = error_message
        self.status_code: int = status_code
        self.operation: str = operation

    def __str__(self) -> str:
        """Return simple error message."""
        return self.error_message

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"error_message={self.error_message!r}, "
            f"status_code={self.status_code}, "
            f"operation={self.operation!r})"
        )

    def formatted_message(self) -> str:
        """Return formatted error block."""
        try:
            status_text = f"{self.status_code} {HTTPStatus(self.status_code).phrase}"
        except ValueError:
            status_text = str(self.status_code)
        lines = [
            f"Error: {self.operation.title()} Failed",
            "-----------------------------",
            f"Status:  {status_text}",
            f"Message: {self.error_message}",
        ]
        return "\n".join(lines)


def build_frogml_exception(
    exception: Exception,
    error_message: str,
    operation: str,
    function: Optional[Callable] = None,
    args: tuple = (),
    kwargs: Optional[dict] = None,
) -> FrogmlException:
    """Build a FrogmlException from the caught exception.

    Can be used both as a helper for the ``grpc_try_catch_wrapper`` decorator
    (passing *function*, *args* and *kwargs* for message interpolation) and
    directly inside manual ``try / except`` blocks (omitting those parameters).

    Parameters
    ----------
    exception : Exception
        The caught exception.
    error_message : str
        A human-readable error description.  May contain ``{placeholder}``
        tokens that will be resolved against the decorated function's
        signature when *function* is provided.
    operation : str
        Short operation label shown in the formatted output
        (e.g. ``"Get Model"``).
    function : Callable, optional
        The decorated / calling function – used only for message
        interpolation.  ``None`` skips interpolation (suitable for manual
        ``try / except`` blocks where the caller already uses f-strings).
    args : tuple
        Positional arguments forwarded to *function* (decorator usage).
    kwargs : dict, optional
        Keyword arguments forwarded to *function* (decorator usage).
    """
    if isinstance(exception, FrogmlException):
        status_code: int = exception.status_code
        error_detail: Optional[str] = exception.error_message
    elif isinstance(exception, grpc.RpcError):
        status_code, error_detail = _extract_grpc_error_info(exception, error_message)
    else:
        status_code = HTTPStatus.INTERNAL_SERVER_ERROR
        error_detail = f"{type(exception).__name__}: {exception}"

    base_message: str = __get_formatted_error_message(
        error_message, function, args, kwargs or {}
    )
    message: str = f"{base_message}: {error_detail}" if error_detail else base_message

    return FrogmlException(
        error_message=message,
        status_code=status_code,
        operation=operation,
    )


def _extract_grpc_error_info(
    e: grpc.RpcError, error_message: str
) -> tuple[int, Optional[str]]:
    """Extract status code and error detail from a gRPC error."""
    status_code: int = grpc_to_http_status(e.code() if hasattr(e, "code") else None)
    error_detail: Optional[str]

    if hasattr(e, "details") and e.details() is not None:
        error_detail = e.details()
    elif hasattr(e, "debug_error_string"):
        error_detail = e.debug_error_string()
    else:
        error_detail = None

    logger.debug("%s: %s: %s", error_message, error_detail, e)
    return status_code, error_detail


def __get_formatted_error_message(
    error_message: str,
    function: Optional[Callable],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> str:
    """Formats an error message string with the runtime arguments of a function.

    When *function* is ``None`` the message is returned as-is (no interpolation).
    """
    if function is None:
        return error_message
    try:
        sig: inspect.Signature = inspect.signature(function)
        bound_args: inspect.BoundArguments = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()

        return error_message.format(**bound_args.arguments)
    except (ValueError, KeyError, TypeError):
        return error_message
