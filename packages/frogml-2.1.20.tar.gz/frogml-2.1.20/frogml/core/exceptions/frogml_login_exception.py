from http import HTTPStatus

from frogml.core.exceptions.frogml_exception import FrogmlException


class FrogmlLoginException(FrogmlException):
    """Exception for login failures."""

    def __init__(
        self,
        error_message: str = "Failed to login to FrogML. Please check your credentials",
        status_code: int = HTTPStatus.UNAUTHORIZED,
        operation: str = "Login",
    ) -> None:
        super().__init__(
            error_message=error_message,
            status_code=status_code,
            operation=operation,
        )
