from http import HTTPStatus

from frogml.core.exceptions.frogml_exception import FrogmlException


class FrogMLTokenException(FrogmlException):
    """Exception for token-related errors."""

    def __init__(
        self,
        error_message: str,
        status_code: int = HTTPStatus.UNAUTHORIZED,
        operation: str = "Authenticate",
    ) -> None:
        super().__init__(
            error_message=error_message,
            status_code=status_code,
            operation=operation,
        )
