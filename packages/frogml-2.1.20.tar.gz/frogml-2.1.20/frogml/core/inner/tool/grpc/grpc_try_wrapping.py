import functools
from typing import Callable

from frogml.core.exceptions.frogml_exception import build_frogml_exception


def grpc_try_catch_wrapper(
    error_message: str, operation: str = "FrogML Operation"
) -> Callable:
    """A decorator for handling exceptions in client methods.

    This decorator wraps a function, catching any `grpc.RpcError` or other
    `Exception` and re-raises them as a `FrogmlException` with consistent formatting.

    Parameters
    ----------
    error_message : str
        The error message template. This can be a static string or a format
        string using placeholders that match the decorated function's
        parameter names (e.g., "Failed on item {item_id}").
    operation : str, optional
        The operation name for error display (e.g., "Delete Model").
        Defaults to "FrogML Operation".

    Returns
    -------
    Callable
        A decorator that wraps the function with the error handling logic.

    Raises
    ------
    FrogmlException
        Raised when the decorated function encounters any exception.

    Usage
    -----
        @grpc_try_catch_wrapper(
            error_message="Failed to delete version {version_number} for FeatureSet {featureset_name}",
            operation="Delete FeatureSet Version"
        )
        def delete_featureset_version(self, featureset_name: str, version_number: int):
            # ... gRPC call ...
    """

    def decorator(function: Callable):
        @functools.wraps(function)
        def _inner_wrapper(*args, **kwargs):
            try:
                return function(*args, **kwargs)
            except Exception as e:
                raise build_frogml_exception(
                    exception=e,
                    error_message=error_message,
                    operation=operation,
                    function=function,
                    args=args,
                    kwargs=kwargs,
                ) from e

        return _inner_wrapper

    return decorator
