from typing import List, Optional, Tuple

import grpc
from dependency_injector.wiring import Provide
from google.protobuf.wrappers_pb2 import StringValue

from frogml._proto.qwak.monitoring.v0.alerting_channel_management_service_pb2 import (
    CreateAlertingChannelRequest,
    DeleteAlertingChannelRequest,
    GetAlertingChannelRequestByName,
    GetAlertingChannelResponseByName,
    ListAlertingChannelRequest,
    ListAlertingChannelResponse,
    UpdateAlertingChannelRequest,
)
from frogml._proto.qwak.monitoring.v0.alerting_channel_management_service_pb2_grpc import (
    AlertingChannelManagementServiceStub,
)
from frogml._proto.qwak.monitoring.v0.alerting_channel_pb2 import (
    AlertingChannelCreateOptions,
    AlertingChannelSpec,
    AlertingChannelUpdateOptions,
)
from frogml.core.clients.alerts_registry.channel import Channel
from frogml.core.exceptions.frogml_exception import build_frogml_exception
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class AlertingRegistryClient:
    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self.alerting_channel_mgmt_service = AlertingChannelManagementServiceStub(
            grpc_channel
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to create alerting channel: '{channel.name}'",
        operation="Create Alerting Channel",
    )
    def create_alerting_channel(self, channel: Channel) -> None:
        request = CreateAlertingChannelRequest(
            options=AlertingChannelCreateOptions(
                name=channel.name,
                spec=AlertingChannelSpec(configuration=channel.channel_conf.to_proto()),
            )
        )
        self.alerting_channel_mgmt_service.CreateAlertingChannel(request)

    @grpc_try_catch_wrapper(
        error_message="Failed to update alerting channel named: {channel.name}",
        operation="Update Alerting Channel",
    )
    def update_alerting_channel(self, channel_id: str, channel: Channel) -> None:
        request = UpdateAlertingChannelRequest(
            options=AlertingChannelUpdateOptions(
                id=channel_id,
                name=StringValue(value=channel.name),
                spec=AlertingChannelSpec(configuration=channel.channel_conf.to_proto()),
            )
        )
        self.alerting_channel_mgmt_service.UpdateAlertingChannel(request)

    def get_alerting_channel(
        self, channel_name: str
    ) -> Optional[Tuple[Optional[str], Optional[Channel]]]:
        error_message: str = f"Failed to get alerting channel name: {channel_name}"
        operation: str = "Get Alerting Channel"
        try:
            request = GetAlertingChannelRequestByName(name=channel_name)
            response: GetAlertingChannelResponseByName = (
                self.alerting_channel_mgmt_service.GetAlertingChannelByName(request)
            )

            return response.description.metadata.id, Channel.from_proto(
                response.description
            )
        except grpc.RpcError as e:
            if e.code() == grpc.StatusCode.NOT_FOUND:
                return None, None
            raise build_frogml_exception(
                exception=e,
                error_message=error_message,
                operation=operation,
            ) from e
        except Exception as e:
            raise build_frogml_exception(
                exception=e,
                error_message=error_message,
                operation=operation,
            ) from e

    def list_alerting_channel(self) -> List[Tuple[str, Channel]]:
        response: ListAlertingChannelResponse = self.list_alerting_channel_from_client()
        return [(d.metadata.id, Channel.from_proto(d)) for d in response.description]

    @grpc_try_catch_wrapper(
        error_message="Failed to delete alerting channel named: {channel_name}",
        operation="Delete Alerting Channel",
    )
    def delete_alerting_channel(self, channel_name: str) -> None:
        self.alerting_channel_mgmt_service.DeleteAlertingChannel(
            DeleteAlertingChannelRequest(name=channel_name)
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to list alerting channels from server",
        operation="List Alerting Channels",
    )
    def list_alerting_channel_from_client(self) -> ListAlertingChannelResponse:
        """
        Get list of alerting channels from the server
        """
        response: ListAlertingChannelResponse = (
            self.alerting_channel_mgmt_service.ListAlertingChannel(
                ListAlertingChannelRequest()
            )
        )
        return response
