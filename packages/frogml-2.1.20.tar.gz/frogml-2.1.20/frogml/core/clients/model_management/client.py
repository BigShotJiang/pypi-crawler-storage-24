from typing import Optional

import grpc
from dependency_injector.wiring import Provide

from frogml.core.utils.model_utils import get_model_id_from_model_name
from frogml._proto.qwak.models.models_pb2 import (
    CreateModelRequest,
    DeleteModelRequest,
    DeleteModelResponse,
    GetModelMetadataRequest,
    GetModelMetadataResponse,
    GetModelRequest,
    GetModelResponse,
    ListModelsMetadataRequest,
    ListModelsMetadataResponse,
    ListModelsRequest,
    ListModelsResponse,
    Model,
    ModelSpec,
)
from frogml._proto.qwak.models.models_pb2_grpc import ModelsManagementServiceStub

from frogml.core.exceptions.frogml_exception import build_frogml_exception
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper
from frogml._proto.qwak.projects.jfrog_project_spec_pb2 import ModelRepositoryJFrogSpec


class ModelsManagementClient:
    """
    Used for interacting with Feature Registry endpoints
    """

    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._models_management_service = ModelsManagementServiceStub(grpc_channel)

    def get_model(
        self, model_id: str, exception_on_missing: bool = True
    ) -> Optional[Model]:
        try:
            response: GetModelResponse = self._models_management_service.GetModel(
                GetModelRequest(model_id=model_id)
            )
            return response.model

        except grpc.RpcError as e:
            if e.code() == grpc.StatusCode.NOT_FOUND and not exception_on_missing:
                return None
            raise build_frogml_exception(
                exception=e,
                error_message=f"Failed to get model '{model_id}'",
                operation="Get Model",
            ) from e

    def get_model_by_uuid(
        self, model_uuid, exception_on_missing: bool = True
    ) -> Optional[Model]:
        try:
            return self._models_management_service.GetModel(
                GetModelRequest(model_uuid=model_uuid)
            ).model

        except grpc.RpcError as e:
            if e.code() == grpc.StatusCode.NOT_FOUND and not exception_on_missing:
                return None
            raise build_frogml_exception(
                exception=e,
                error_message=f"Failed to get model by UUID '{model_uuid}'",
                operation="Get Model",
            ) from e

    def get_model_uuid(self, model_id: str) -> str:
        model: Optional[Model] = self.get_model(model_id)
        return model.uuid

    @grpc_try_catch_wrapper(
        error_message="Failed to create model", operation="Create Model"
    )
    def create_model(
        self,
        project_id: str,
        model_name: str,
        model_description: str,
        jfrog_project_key: Optional[str] = None,
    ):
        return self._models_management_service.CreateModel(
            CreateModelRequest(
                model_spec=ModelSpec(
                    model_named_id=get_model_id_from_model_name(model_name),
                    display_name=model_name,
                    project_id=project_id,
                    model_description=model_description,
                ),
                jfrog_project_spec=ModelRepositoryJFrogSpec(
                    jfrog_project_key=jfrog_project_key,
                ),
            )
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to delete model", operation="Delete Model"
    )
    def delete_model(self, project_id: str, model_id: str) -> DeleteModelResponse:
        return self._models_management_service.DeleteModel(
            DeleteModelRequest(model_id=model_id, project_id=project_id)
        )

    def is_model_exists(self, model_id: str) -> bool:
        """Check if model exists in environment

        Args:
            model_id: the model id to check if exists.

        Returns: if model exists.
        """
        try:
            # noinspection PyStatementEffect
            self._models_management_service.GetModel(
                GetModelRequest(model_id=model_id)
            ).model
            return True
        except grpc.RpcError as e:
            if e.code() == grpc.StatusCode.NOT_FOUND:
                return False
            raise build_frogml_exception(
                exception=e,
                error_message=f"Failed to check if model '{model_id}' exists",
                operation="Check Model Exists",
            ) from e

    @grpc_try_catch_wrapper(
        error_message="Failed to list models metadata", operation="List Models Metadata"
    )
    def list_models_metadata(self, project_id: str) -> ListModelsMetadataResponse:
        return self._models_management_service.ListModelsMetadata(
            ListModelsMetadataRequest(project_id=project_id)
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to list models", operation="List Models"
    )
    def list_models(self, project_id: str) -> ListModelsResponse:
        return self._models_management_service.ListModels(
            ListModelsRequest(project_id=project_id)
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to get model metadata", operation="Get Model Metadata"
    )
    def get_model_metadata(self, model_id: str) -> GetModelMetadataResponse:
        return self._models_management_service.GetModelMetadata(
            GetModelMetadataRequest(model_id=model_id)
        )
