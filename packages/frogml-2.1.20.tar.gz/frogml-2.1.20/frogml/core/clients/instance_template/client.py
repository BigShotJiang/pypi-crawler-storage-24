from typing import List

from dependency_injector.wiring import Provide

from frogml._proto.qwak.instance_template.instance_template_pb2 import (
    InstanceFilter,
    InstanceTemplateSpec,
    InstanceTypeFilter,
)
from frogml._proto.qwak.instance_template.instance_template_service_pb2 import (
    GetInstanceTemplateRequest,
    GetInstanceTemplateResponse,
    ListInstanceTemplatesRequest,
    ListInstanceTemplatesResponse,
)
from frogml._proto.qwak.instance_template.instance_template_service_pb2_grpc import (
    InstanceTemplateManagementServiceStub,
)
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class InstanceTemplateManagementClient:
    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._instance_template_service = InstanceTemplateManagementServiceStub(
            grpc_channel
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to get instance template",
        operation="Get Instance Template",
    )
    def get_instance_template(self, instance_template_id: str) -> InstanceTemplateSpec:
        result: GetInstanceTemplateResponse = (
            self._instance_template_service.GetInstanceTemplate(
                GetInstanceTemplateRequest(id=instance_template_id)
            )
        )
        return result.instance_template

    @grpc_try_catch_wrapper(
        error_message="Failed to list instance templates",
        operation="List Instance Templates",
    )
    def list_instance_templates(self) -> List[InstanceTemplateSpec]:
        result: ListInstanceTemplatesResponse = (
            self._instance_template_service.ListInstanceTemplates(
                ListInstanceTemplatesRequest(
                    optional_instance_filter=InstanceFilter(
                        instance_type_filter=InstanceTypeFilter.INSTANCE_TYPE_FILTER_ALL
                    )
                )
            )
        )
        return list(result.instance_template_list)
