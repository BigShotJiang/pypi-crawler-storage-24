from typing import List

from dependency_injector.wiring import Provide

from frogml._proto.qwak.audience.v1.audience_api_pb2 import (
    CreateAudienceRequest,
    CreateAudienceResponse,
    DeleteAudienceRequest,
    GetAudienceRequest,
    GetAudienceResponse,
    ListAudienceRequest,
    ListAudienceResponse,
    UpdateAudienceRequest,
)
from frogml._proto.qwak.audience.v1.audience_api_pb2_grpc import AudienceAPIStub
from frogml._proto.qwak.audience.v1.audience_pb2 import Audience, AudienceEntry
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class AudienceClient:
    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._service_stub = AudienceAPIStub(grpc_channel)

    @grpc_try_catch_wrapper(
        error_message="Failed to create audience",
        operation="Create Audience",
    )
    def create_audience(self, audience: Audience) -> str:
        create_audience_request = CreateAudienceRequest(audience=audience)
        create_audience_response: CreateAudienceResponse = (
            self._service_stub.CreateAudience(create_audience_request)
        )
        return create_audience_response.audience_id

    @grpc_try_catch_wrapper(
        error_message="Failed to get audience",
        operation="Get Audience",
    )
    def get_audience(self, audience_id: str) -> Audience:
        get_audience_request = GetAudienceRequest(audience_id=audience_id)
        get_audience_response: GetAudienceResponse = self._service_stub.GetAudience(
            get_audience_request
        )
        return get_audience_response.audience

    @grpc_try_catch_wrapper(
        error_message="Failed to delete audience",
        operation="Delete Audience",
    )
    def delete_audience(self, audience_id: str) -> None:
        delete_audience_request = DeleteAudienceRequest(audience_id=audience_id)
        self._service_stub.DeleteAudience(delete_audience_request)

    @grpc_try_catch_wrapper(
        error_message="Failed to list audiences",
        operation="List Audiences",
    )
    def list_audience(self) -> List[AudienceEntry]:
        list_audience_request = ListAudienceRequest()
        list_audience_response: ListAudienceResponse = self._service_stub.ListAudience(
            list_audience_request
        )
        return list_audience_response.audience_entries

    @grpc_try_catch_wrapper(
        error_message="Failed to update audience",
        operation="Update Audience",
    )
    def update_audience(self, audience_id: str, audience: Audience) -> None:
        update_audience_request = UpdateAudienceRequest(
            id=audience_id, audience=audience
        )
        self._service_stub.UpdateAudience(update_audience_request)
