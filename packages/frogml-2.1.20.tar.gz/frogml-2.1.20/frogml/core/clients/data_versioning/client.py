from typing import Optional

import grpc
from dependency_injector.wiring import Provide

from frogml._proto.qwak.data_versioning.data_versioning_pb2 import (
    DataTagFilter,
    DataTagSpec,
)
from frogml._proto.qwak.data_versioning.data_versioning_service_pb2 import (
    GetModelDataTagsRequest,
    RegisterDataTagRequest,
)
from frogml._proto.qwak.data_versioning.data_versioning_service_pb2_grpc import (
    DataVersioningManagementServiceStub,
)
from frogml.core.exceptions.frogml_exception import build_frogml_exception
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class DataVersioningManagementClient:
    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._data_management_service = DataVersioningManagementServiceStub(
            grpc_channel
        )

    def register_data_tag(
        self,
        model_id: str,
        tag: str,
        build_id: Optional[str] = "",
        extension: Optional[str] = "",
    ) -> None:
        """
        Register data tag to service
        Args:
            build_id: build id to save tag by.
            model_id: model id to save tag by.
            tag: tag to save.
            extension: The file extension

        Returns:

        """
        try:
            self._data_management_service.RegisterDataTag(
                RegisterDataTagRequest(
                    data_tag_spec=(
                        DataTagSpec(
                            build_id=build_id,
                            model_id=model_id,
                            tag=tag,
                            extension_type=extension,
                        )
                    )
                )
            )
        except grpc.RpcError as e:
            if e.code() == grpc.StatusCode.ALREADY_EXISTS:
                return
            raise build_frogml_exception(
                exception=e,
                error_message=f"Failed to register data tag '{tag}'",
                operation="Register Data Tag",
            ) from e

    @grpc_try_catch_wrapper(
        error_message="Failed to list model data tags for model {model_id}",
        operation="Get Model Data Tags",
    )
    def get_model_data_tags(
        self, model_id: str, build_id: str, data_tag_filter: DataTagFilter = None
    ):
        return self._data_management_service.GetModelDataTags(
            GetModelDataTagsRequest(
                model_id=model_id, build_id=build_id, filter=data_tag_filter
            )
        )
