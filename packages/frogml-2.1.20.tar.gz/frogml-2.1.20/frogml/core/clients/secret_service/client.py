from typing import Optional

import grpc

from frogml._proto.qwak.secret_service.secret_service_pb2 import (
    DeleteSecretRequest,
    GetSecretRequest,
    SetSecretRequest,
)
from frogml._proto.qwak.secret_service.secret_service_pb2_grpc import SecretServiceStub
from frogml.core.clients.administration.eco_system.client import EcosystemClient
from frogml.core.exceptions import FrogmlNotFoundException
from frogml.core.exceptions.frogml_exception import build_frogml_exception
from frogml.core.inner.tool.grpc.grpc_tools import create_grpc_channel
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class SecretServiceClient:
    """
    gRPC client of the secret service
    """

    def __init__(
        self,
        edge_services_url: Optional[str] = None,
        enable_ssl: bool = True,
        grpc_channel: Optional[grpc.Channel] = None,
        environment_id: Optional[str] = None,
    ):
        if not grpc_channel:
            edge_services_url = self.__get_endpoint_url(
                edge_services_url, environment_id
            )
            grpc_channel = create_grpc_channel(
                url=edge_services_url,
                enable_ssl=enable_ssl,
                status_for_retry=(
                    grpc.StatusCode.UNAVAILABLE,
                    grpc.StatusCode.DEADLINE_EXCEEDED,
                    grpc.StatusCode.INTERNAL,
                ),
                backoff_options={"init_backoff_ms": 250},
            )
        self._secret_service = SecretServiceStub(grpc_channel)

    @staticmethod
    def __get_endpoint_url(
        endpoint_url: Optional[str] = None, environment_id: Optional[str] = None
    ) -> str:
        if endpoint_url is None:
            user_context = EcosystemClient().get_authenticated_user_context().user
            if environment_id is None:
                environment_id = user_context.environment_details.id

            # If the environment id is not found, try to use the default environment id
            if environment_id not in user_context.account_details.environment_by_id:
                environment_id = user_context.account_details.default_environment_id

            if environment_id not in user_context.account_details.environment_by_id:
                raise FrogmlNotFoundException(
                    error_message=f"Configuration for environment '{environment_id}' was not found",
                    operation="Get Endpoint URL",
                )

            endpoint_url = user_context.account_details.environment_by_id[
                environment_id
            ].configuration.edge_services_url

        return endpoint_url

    def get_secret(self, name: str) -> str:
        try:
            request = GetSecretRequest(name=name)
            return self._secret_service.GetSecret(request).value
        except grpc.RpcError as e:
            error_message: str = f"Failed to get secret '{name}'"
            if e.code() == grpc.StatusCode.NOT_FOUND:
                error_message = f"Secret '{name}' not found"
            raise build_frogml_exception(
                exception=e,
                error_message=error_message,
                operation="Get Secret",
            ) from e

    @grpc_try_catch_wrapper(
        error_message="Failed to set secret '{name}'",
        operation="Set Secret",
    )
    def set_secret(self, name: str, value: str) -> None:
        request = SetSecretRequest(name=name, value=value)
        self._secret_service.SetSecret(request)

    @grpc_try_catch_wrapper(
        error_message="Failed to delete secret '{name}'",
        operation="Delete Secret",
    )
    def delete_secret(self, name: str) -> None:
        request = DeleteSecretRequest(name=name)
        self._secret_service.DeleteSecret(request)
