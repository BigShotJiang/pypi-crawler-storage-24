from dependency_injector.wiring import Provide
from grpc import RpcError, StatusCode

from frogml._proto.qwak.self_service.user.v1.user_service_pb2 import (
    GenerateApiKeyRequest,
    GenerateApiKeyResponse,
    RevokeApiKeyRequest,
    RevokeApiKeyResponse,
)
from frogml._proto.qwak.self_service.user.v1.user_service_pb2_grpc import (
    UserServiceStub,
)
from frogml.core.exceptions.frogml_exception import build_frogml_exception
from frogml.core.inner.di_configuration import FrogmlContainer

APIKEY_ALREADY_EXISTS: str = "Api-key already exists"
OPERATION_GENERATE_API_KEY: str = "Generate API Key"
OPERATION_REVOKE_API_KEY: str = "Revoke API Key"


class SelfServiceUserClient:
    """
    Used for interacting with Frogml's Self service -  user service
    """

    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._user_service = UserServiceStub(grpc_channel)

    def generate_apikey(
        self,
        user_id: str,
        environment_id: str,
        force: bool = False,
    ) -> GenerateApiKeyResponse:
        """
        Generate api key
        user_id: the wanted user id.
        environment_id: the wanted environment id
        force: if override existing one.
        Return Api Key for the wanted user and environment.
        """
        request = GenerateApiKeyRequest(
            user_id=user_id, environment_id=environment_id, force=force
        )
        try:
            return self._user_service.GenerateApiKey(request)
        except RpcError as e:
            error_message: str = "Failed to generate api key"
            if e.code() == StatusCode.PERMISSION_DENIED:
                error_message = (
                    "You are not authorized to perform administration operations"
                )
            elif e.code() == StatusCode.ALREADY_EXISTS:
                error_message = APIKEY_ALREADY_EXISTS
            raise build_frogml_exception(
                exception=e,
                error_message=error_message,
                operation=OPERATION_GENERATE_API_KEY,
            ) from e

    def revoke_apikey(self, user_id: str, environment_id: str) -> RevokeApiKeyResponse:
        """
        Revoke api eky
        user_id: the wanted user id to revoke from
        environment_id: the wanted environment id
        Return if the api key has been revoked

        """
        try:
            request = RevokeApiKeyRequest(
                user_id=user_id, environment_id=environment_id
            )
            return self._user_service.RevokeApiKey(request)

        except RpcError as e:
            error_message: str = "Failed to revoke api key"
            if e.code() == StatusCode.PERMISSION_DENIED:
                error_message = (
                    "You are not authorized to perform administration operations"
                )
            raise build_frogml_exception(
                exception=e,
                error_message=error_message,
                operation=OPERATION_REVOKE_API_KEY,
            ) from e
