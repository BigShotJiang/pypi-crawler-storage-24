from typing import Callable

from dependency_injector.wiring import Provide
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper
from frogml._proto.qwak.service_discovery.service_discovery_location_pb2 import (
    ServiceLocationDescriptor,
)
from frogml._proto.qwak.service_discovery.service_discovery_location_service_pb2 import (
    GetServingUrlRequest as ProtoGetServingUrlRequest,
    GetServingUrlRequestResponse as ProtoGetServingUrlRequestResponse,
)
from frogml._proto.qwak.service_discovery.service_discovery_location_service_pb2_grpc import (
    LocationDiscoveryServiceStub,
)


class LocationDiscoveryClient:
    """
    Client for querying service locations from the LocationDiscoveryService.
    """

    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._service = LocationDiscoveryServiceStub(grpc_channel)

    @staticmethod
    @grpc_try_catch_wrapper(
        error_message="Failed to retrieve service location",
        operation="Get Service Location",
    )
    def _get_location(
        method: Callable[
            [ProtoGetServingUrlRequest], ProtoGetServingUrlRequestResponse
        ],
    ) -> ServiceLocationDescriptor:
        """
        Calls a specific RPC and extracts the service location descriptor.

        Args:
            method: The gRPC method to call.

        Returns:
            ServiceLocationDescriptor: Contains service_url and location metadata.
        """
        request = ProtoGetServingUrlRequest()
        response = method(request)
        return response.location

    def get_offline_serving(self) -> ServiceLocationDescriptor:
        """Fetches the offline serving service location."""
        return self._get_location(self._service.GetOfflineServingUrl)

    def get_distribution_manager(self) -> ServiceLocationDescriptor:
        """Fetches the distribution manager service location."""
        return self._get_location(self._service.GetDistributionManagerUrl)

    def get_analytics_engine(self) -> ServiceLocationDescriptor:
        """Fetches the analytics engine service location."""
        return self._get_location(self._service.GetAnalyticsEngineUrl)

    def get_metrics_gateway(self) -> ServiceLocationDescriptor:
        """Fetches the metrics gateway service location."""
        return self._get_location(self._service.GetMetricsGatewayUrl)

    def get_features_operator(self) -> ServiceLocationDescriptor:
        """Fetches the features operator service location."""
        return self._get_location(self._service.GetFeaturesOperatorUrl)

    def get_hosting_gateway(self) -> ServiceLocationDescriptor:
        """Fetches the hosting gateway service location."""
        return self._get_location(self._service.GetHostingGatewayUrl)
