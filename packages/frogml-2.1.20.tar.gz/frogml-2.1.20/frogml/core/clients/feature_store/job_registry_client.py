import grpc
from dependency_injector.wiring import Provide

from frogml._proto.qwak.feature_store.jobs.v1.job_service_pb2 import (
    GetLatestJobRequest,
    GetLatestJobResponse,
    GetLatestSuccessfulJobRequest,
    GetLatestSuccessfulJobResponse,
)
from frogml._proto.qwak.feature_store.jobs.v1.job_service_pb2_grpc import JobServiceStub
from frogml.core.exceptions.frogml_exception import build_frogml_exception
from frogml.core.inner.di_configuration import FrogmlContainer


class FeatureSetsJobRegistryClient:
    """
    Used for interacting with Feature Registry endpoints
    """

    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._job_registry = JobServiceStub(grpc_channel)

    def get_latest_successful_job(
        self, featureset_id: str, environment_id: str
    ) -> GetLatestSuccessfulJobResponse:
        """
        Args:
            featureset_id: The id of the requested FeatureSet
            environment_id: The environment id of the requested FeatureSet

        Returns:
            The response of the latest successful job
        """
        try:
            get_latest_successful_job_request = GetLatestSuccessfulJobRequest(
                featureset_id=featureset_id, environment_id=environment_id
            )
            return self._job_registry.GetLatestSuccessfulJob(
                get_latest_successful_job_request
            )
        except grpc.RpcError as e:
            error_message: str = (
                f"Failed to get latest successful job for FeatureSet '{featureset_id}'"
            )
            if e.code() == grpc.StatusCode.NOT_FOUND:
                error_message = (
                    f"Latest successful job not found for FeatureSet '{featureset_id}'"
                )
            raise build_frogml_exception(
                exception=e,
                error_message=error_message,
                operation="Get Latest Successful Job",
            ) from e

    def get_latest_job(
        self, featureset_id: str, environment_id: str
    ) -> GetLatestJobResponse:
        """
        Args:
            featureset_id: The id of the requested FeatureSet
            environment_id: The environment id of the requested FeatureSet

        Returns:
            The response of the latest successful job
        """
        try:
            get_latest_job_request = GetLatestJobRequest(
                featureset_id=featureset_id, environment_id=environment_id
            )
            return self._job_registry.GetLatestJob(get_latest_job_request)
        except grpc.RpcError as e:
            error_message: str = (
                f"Failed to get latest job for FeatureSet '{featureset_id}'"
            )
            if e.code() == grpc.StatusCode.NOT_FOUND:
                error_message = f"Latest job not found for FeatureSet '{featureset_id}'"
            raise build_frogml_exception(
                exception=e,
                error_message=error_message,
                operation="Get Latest Job",
            ) from e
