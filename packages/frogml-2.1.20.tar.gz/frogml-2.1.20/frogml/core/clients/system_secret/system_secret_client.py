from dependency_injector.wiring import Provide, inject

from frogml._proto.qwak.admiral.secret.v0.secret_pb2 import (
    EnvironmentSecretIdentifier,
    SystemSecretValue,
)
from frogml._proto.qwak.admiral.secret.v0.system_secret_service_pb2 import (
    GetSystemSecretRequest,
    GetSystemSecretResponse,
)
from frogml._proto.qwak.admiral.secret.v0.system_secret_service_pb2_grpc import (
    SystemSecretServiceStub,
)
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class SystemSecretClient:
    @inject
    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._grpc_client: SystemSecretServiceStub = SystemSecretServiceStub(
            grpc_channel
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to get system secret '{name}'",
        operation="Get System Secret",
    )
    def get_system_secret(self, name: str, env_id: str) -> SystemSecretValue:
        response: GetSystemSecretResponse = self._grpc_client.GetSystemSecret(
            GetSystemSecretRequest(
                identifier=EnvironmentSecretIdentifier(name=name, environment_id=env_id)
            )
        )

        return response.secret_definition.spec.value
