# vt100wasm

Python bindings for the Rust [vt100](https://crates.io/crates/vt100) terminal emulator, compiled to WebAssembly.

Provides efficient terminal state tracking (apply deltas, extract screen contents) without native compilation -- the WASM binary is bundled in the wheel.

## Install

```
pip install vt100wasm
```

## Usage

```python
from vt100wasm import apply_delta, screen_contents, screen_contents_formatted

state = apply_delta(None, b"hello world\r\n$ ", rows=24, cols=80)
print(screen_contents(state))

state2 = apply_delta(state, b"\x1b[31mred text\x1b[0m", rows=24, cols=80)
formatted = screen_contents_formatted(state2)
```

## Building the WASM binary

```
cargo build --target wasm32-wasip1 --release
cp target/wasm32-wasip1/release/vt100wasm.wasm src/vt100wasm/_vt100.wasm
```
