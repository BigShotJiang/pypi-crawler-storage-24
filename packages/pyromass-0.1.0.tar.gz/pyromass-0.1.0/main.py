from pyromass.reaction import PyrolysisModel

model = PyrolysisModel(500)
result1 = model.run()
result2 = model.add(10,5)

print(result1, result2)
