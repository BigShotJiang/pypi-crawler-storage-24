class PyrolysisModel:
	def __init__(self, temperature):
		self.temperature = temperature
	def run(self):
		return f"Running pyrolysis at {self.temperature}C"

	def add(self,a,b):
		return a+b
