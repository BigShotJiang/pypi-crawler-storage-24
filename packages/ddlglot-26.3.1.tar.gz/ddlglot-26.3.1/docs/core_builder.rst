# Core Builder

## CreateBuilder

The core builder provides a fluent API for generating DDL statements.

### Factory Function

```python
from ddlglot import create

builder = create("table")  # or create("view")
```

### Methods

#### name()

Set the table or view name.

```python
.name("schema.table_name")
```

#### column()

Add a column definition with optional constraints.

```python
.column("name", "VARCHAR(100)")
.column("id", "INT", pk=True, not_null=True)
.column("price", "DECIMAL(10,2)", default=0)
```

**Parameters:**

- `name` (str): Column name
- `dtype` (str): Data type
- `not_null` (bool, optional): Add NOT NULL constraint
- `pk` (bool, optional): Add PRIMARY KEY constraint
- `unique` (bool, optional): Add UNIQUE constraint
- `default` (optional): Default value

#### columns()

Add multiple columns at once.

```python
.columns(("id", "INT"), ("name", "VARCHAR(100)"))
```

#### primary_key()

Add a table-level PRIMARY KEY constraint.

```python
.primary_key("col1", "col2")
```

#### unique_key()

Add a table-level UNIQUE constraint.

```python
.unique_key("email")
```

#### if_not_exists()

Add IF NOT EXISTS clause.

```python
.if_not_exists()
```

#### temporary()

Mark as TEMPORARY table.

```python
.temporary()
```

#### comment()

Add a table comment.

```python
.comment("User information table")
```

#### as_select()

Set CTAS expression or view definition.

```python
.as_select(exp.select("*").from_("other_table"))
```

#### using()

Set USING format (for file-based tables).

```python
.using("delta")
```

#### partitioned_by()

Add PARTITIONED BY clause.

```python
.partitioned_by("date_column")
```

#### location()

Set LOCATION path.

```python
.location("s3://bucket/path/")
```

#### tblproperties()

Add TBLPROPERTIES.

```python
.tblproperties({"key": "value"})
```

### Output Methods

#### to_ast()

Return SQLGlot AST expression.

```python
ast = builder.to_ast()
```

#### sql()

Generate SQL string.

```python
sql = builder.sql(dialect="postgres", pretty=True)
```

**Parameters:**

- `dialect` (str, optional): SQL dialect (default: None)
- `pretty` (bool, optional): Enable pretty printing
