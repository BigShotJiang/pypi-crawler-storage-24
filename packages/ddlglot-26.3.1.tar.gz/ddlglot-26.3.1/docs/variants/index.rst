# SQL Dialect Variants

ddlglot provides specialized builders for different SQL dialects.

## Available Variants

- [Spark+Delta](spark_delta)
- [Hive](hive)
- [PostgreSQL](postgres)
- [DuckDB](duckdb)
- [BigQuery](bigquery)

## Using Variants

Import the variant-specific builder:

```python
from ddlglot import create_spark_delta

sql = (
    create_spark_delta()
    .name("default.events")
    .column("id", "INT")
    .sql()
)
```

Or use the registry:

```python
from ddlglot import create_variant

builder = create_variant("spark_delta")
```
