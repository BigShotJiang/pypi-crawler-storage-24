import importlib.resources as _ir
from pathlib import Path as _P

# Chunk metadata
CANONICAL_NAME = 'address_dictionary.dat'
FILE_CHUNK_INDEX = 0
TOTAL_FILE_CHUNKS = 1
CHUNK_SHA256 = '66c8132975c6ee6c29222299be2e8cc55c22496d695d43bebf527c79de749ae9'
FILE_ORIGINAL_SIZE = 8737530

def chunk_path() -> _P:
    """Return path to the raw compressed chunk file."""            try:
        ref = _ir.files(__name__) / "data" / "chunk.bin"
        return _P(str(ref))
    except AttributeError:
        import pkg_resources
        return _P(pkg_resources.resource_filename(__name__, "data/chunk.bin"))
