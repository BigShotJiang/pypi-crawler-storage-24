#!/bin/zsh
# AXEL — One-click installer
# curl -sSL https://raw.githubusercontent.com/Sector11x/axel-protocol/main/install.sh | zsh

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo "${BOLD}╔══════════════════════════════════════════╗${NC}"
echo "${BOLD}║   AXEL — Agent eXchange Language         ║${NC}"
echo "${BOLD}║   One-click installer                    ║${NC}"
echo "${BOLD}╚══════════════════════════════════════════╝${NC}"
echo ""

# 1. Check Python
echo "Checking Python..."
if ! command -v python3 &>/dev/null; then
  echo "${RED}✗  Python 3 not found.${NC}"
  echo "   Install it from https://python.org/downloads then re-run."
  exit 1
fi

PY_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
PY_MAJOR=$(python3 -c "import sys; print(sys.version_info.major)")
PY_MINOR=$(python3 -c "import sys; print(sys.version_info.minor)")

if [[ $PY_MAJOR -lt 3 ]] || [[ $PY_MAJOR -eq 3 && $PY_MINOR -lt 10 ]]; then
  echo "${RED}✗  Python 3.10+ required (you have $PY_VERSION).${NC}"
  echo "   Download from https://python.org/downloads"
  exit 1
fi
echo "${GREEN}✓  Python $PY_VERSION${NC}"

# 2. Install
echo "Installing axel-protocol..."
pip3 install --quiet --upgrade axel-protocol
echo "${GREEN}✓  axel-protocol installed${NC}"

# 3. Fix PATH
PYTHON_BIN=$(python3 -c "import sysconfig; print(sysconfig.get_path('scripts'))")
USER_BIN="$HOME/Library/Python/$PY_VERSION/bin"
SHELL_RC="$HOME/.zshrc"
[[ -f "$HOME/.bashrc" && ! -f "$HOME/.zshrc" ]] && SHELL_RC="$HOME/.bashrc"

if ! grep -q "axel-protocol PATH" "$SHELL_RC" 2>/dev/null; then
  echo "" >> "$SHELL_RC"
  echo "# axel-protocol PATH" >> "$SHELL_RC"
  echo "export PATH=\"$PYTHON_BIN:$USER_BIN:\$PATH\"" >> "$SHELL_RC"
fi
export PATH="$PYTHON_BIN:$USER_BIN:$PATH"
echo "${GREEN}✓  PATH configured${NC}"

# 4. OpenRouter key
echo ""
echo "${BOLD}OpenRouter Setup${NC}"
echo "One free key → 100+ models (GPT-4o, Claude, Gemini, Llama, Mistral...)"
echo ""

EXISTING=$(python3 -c "
import json,pathlib
p=pathlib.Path.home()/'.axel/config.json'
print(json.loads(p.read_text()).get('OPENROUTER_API_KEY','') if p.exists() else '')
" 2>/dev/null)

if [[ -n "$EXISTING" ]]; then
  echo "${GREEN}✓  OpenRouter key already saved${NC}"
else
  echo "Get your free key at: ${BOLD}https://openrouter.ai${NC}"
  echo ""
  echo -n "  Paste your OpenRouter key (or Enter to skip): "
  read OR_KEY
  OR_KEY=$(echo "$OR_KEY" | tr -d '[:space:]')
  if [[ -n "$OR_KEY" ]]; then
    mkdir -p "$HOME/.axel"
    python3 -c "
import json, pathlib
p = pathlib.Path.home() / '.axel/config.json'
cfg = json.loads(p.read_text()) if p.exists() else {}
cfg['OPENROUTER_API_KEY'] = '$OR_KEY'
p.write_text(json.dumps(cfg, indent=2))
"
    export OPENROUTER_API_KEY="$OR_KEY"
    echo "${GREEN}✓  Key saved${NC}"
  else
    echo "${YELLOW}  Skipped — run 'axel setup' anytime to add your key${NC}"
  fi
fi

# 5. Done
echo ""
echo "${GREEN}${BOLD}✓  AXEL is ready!${NC}"
echo ""
echo "  Start the server:  python3 -m axel.server"
echo "  Run live demo:     axel demo"
echo "  All commands:      axel --help"
echo "  Dashboard:         http://localhost:7331/ui"
echo ""
echo "  Open a new terminal tab or run: source $SHELL_RC"
echo ""