#!/usr/bin/env python3
"""
axel_demo_live.py  —  AXEL Live Network Demo
═════════════════════════════════════════════
Starts a real AXEL server, connects real agent clients over HTTP,
and demonstrates a full multi-LLM workflow with live message passing.

Works out of the box using MockAdapters (no API keys needed).

To upgrade to real LLMs:
    export ANTHROPIC_API_KEY=sk-ant-...    # Claude
    export OPENAI_API_KEY=sk-...           # GPT
    ollama serve                           # Llama (free, local)

Then set USE_REAL_APIS = True below.
"""

import json
import sys
import time
from pathlib import Path

_HERE = Path(__file__).parent
sys.path.insert(0, str(_HERE))

from axel.server import AXELServer
from axel.client import AXELClient, AXELAgent

# ── Config ────────────────────────────────────────────────────────
HOST          = "127.0.0.1"
PORT          = 7331
BASE          = f"http://{HOST}:{PORT}"
USE_REAL_APIS = False   # flip to True when you have API keys / Ollama running

SEP  = "─" * 64
SEP2 = "═" * 64

def hdr(title):  print(f"\n{SEP}\n  {title}\n{SEP}")
def ok(msg):     print(f"  ✓  {msg}")
def ev(msg):     print(f"  ▶  {msg}")
def info(msg):   print(f"  ·  {msg}")
def warn(msg):   print(f"  ⚠  {msg}")


# ══════════════════════════════════════════════════════════════════
# Demo
# ══════════════════════════════════════════════════════════════════

def main():
    print(f"\n{SEP2}")
    print(f"  AXEL Live Network Demo  —  {BASE}")
    print(SEP2)

    # ── 0. Start server ──────────────────────────────────────────
    print("\n  Starting AXEL Network Server…")
    server = AXELServer(host=HOST, port=PORT)
    server.start_background(log_level="warning")
    time.sleep(0.5)
    ok(f"Server online  →  {BASE}")
    ok(f"Swagger docs   →  {BASE}/docs")
    ok(f"Live stream    →  {BASE}/stream")

    # ── 1. Register agents & adapters ────────────────────────────
    hdr("1 · Agents coming online")

    # Attach execution adapters to the server bridge
    # (swap add_mock → add_anthropic / add_openai / add_ollama for real LLMs)
    server.bridge.add_mock("orchestrator")
    server.bridge.add_mock("researcher")
    server.bridge.add_mock("writer")
    server.bridge.add_mock("reviewer")

    # Connect clients (announce to server + create inboxes)
    orch  = AXELClient(BASE, "orchestrator",
                       model="claude-3-5-sonnet",    provider="anthropic",
                       caps=["plan", "orchestrate", "route"])
    res   = AXELClient(BASE, "researcher",
                       model="claude-3-5-haiku",     provider="anthropic",
                       caps=["research", "summarize", "extract_entities"])
    wri   = AXELClient(BASE, "writer",
                       model="gpt-4o-mini",          provider="openai",
                       caps=["draft_content", "write", "edit", "format"])
    rev   = AXELClient(BASE, "reviewer",
                       model="llama3",               provider="ollama",
                       caps=["review", "proofread", "score_quality"])

    agents = {"orchestrator": orch, "researcher": res,
              "writer": wri, "reviewer": rev}

    status = orch.status()
    ok(f"{status['agents']['count']} agents registered on network")
    for a in status["agents"]["list"]:
        provider_tag = f"[{a['provider']}]"
        info(f"  {a['id']:<20} {a['model']:<30} {provider_tag}")

    # ── 2. Pub/Sub setup ─────────────────────────────────────────
    hdr("2 · Pub/Sub channel subscriptions")

    orch.subscribe("task.completed")
    orch.subscribe("memory.updated")
    res.subscribe("chain.started")
    ok("orchestrator  →  task.completed, memory.updated")
    ok("researcher    →  chain.started")

    # ── 3. Direct task execution ─────────────────────────────────
    hdr("3 · Direct task execution  (TK → execute → OK)")

    tasks = [
        ("researcher", "research",
         {"topic": "distributed inference networks"}),
        ("writer",     "draft_content",
         {"topic": "cross-LLM communication", "format": "blog post"}),
        ("reviewer",   "review",
         {"content": "Agents can communicate via AXEL…", "criteria": "clarity"}),
    ]

    for to, action, args in tasks:
        t0     = time.time()
        result = orch.execute(to, action, args)
        ms     = int((time.time() - t0) * 1000)
        status_t = result.get("t", "?")
        preview  = str(result.get("body", {}).get("result", ""))[:55]
        ev(f"  {action:<22}  →  {to:<14}  [{status_t}]  {ms}ms   {preview}…")

    # ── 4. Chain pipeline ─────────────────────────────────────────
    hdr("4 · Chain pipeline  (researcher → writer → reviewer)")

    t0 = time.time()
    results = orch.chain(
        steps=[
            {"to": "researcher", "act": "research",
             "args": {"topic": "Fractionalized Language Models and AGI"}},
            {"to": "writer",     "act": "draft_content",
             "args": {"format": "technical brief", "length": "medium"}},
            {"to": "reviewer",   "act": "review",
             "args": {"criteria": "technical accuracy, clarity, completeness"}},
        ],
        ctx={"project": "AXEL-FLM-paper", "priority": "high"},
    )
    elapsed = time.time() - t0
    ok(f"Chain complete: {len(results)} steps in {elapsed:.2f}s")
    for i, r in enumerate(results, 1):
        t    = r.get("t", "?")
        prev = str(r.get("body", {}).get("result", ""))[:58]
        info(f"  Step {i}  [{t}]  {prev}…")

    # ── 5. Cross-agent lesson sharing ────────────────────────────
    hdr("5 · Cross-agent lesson sharing")

    lessons = [
        (res,  "research",
         "Multi-hop queries (topic → subtopic → detail) surface 3× more context"),
        (wri,  "draft_content",
         "Structured outline before prose yields 40% better coherence scores"),
        (rev,  "review",
         "Score rubric axes (clarity / accuracy / completeness) separately, then combine"),
        (orch, "orchestrate",
         "Route long-form tasks to models with >128k context to avoid truncation"),
    ]

    for client, key, insight in lessons:
        client.learn(key, insight, confidence=0.92)
        ev(f"  [{client.agent_id:<14}]  {key:<20}  {insight[:52]}…")

    time.sleep(0.2)  # allow server to process

    # BM25 search across shared memory
    print()
    hits = orch.memory_search("research context queries", n=3)
    ok(f"Memory search 'research context queries' → {len(hits)} hits")
    for h in hits:
        info(f"  [{h['source']:<14}]  ({h['confidence']:.2f})  {h['insight'][:58]}…")

    # ── 6. Capability discovery ───────────────────────────────────
    hdr("6 · Capability discovery  (/discover/<action>)")

    for action in ["research", "draft_content", "review",
                   "translate_text", "classify"]:
        disc = orch.discover(action)
        best = disc.get("best")
        n    = len(disc.get("candidates", []))
        if best:
            ev(f"  '{action}'  →  best: {best}  ({n} candidate{'s' if n != 1 else ''})")
        else:
            warn(f"  '{action}'  →  no agent registered (use /axel-announce)")

    # ── 7. Live pub/sub event ─────────────────────────────────────
    hdr("7 · Pub/Sub  (publish pipeline.finished to channel)")

    orch.publish("task.completed", {
        "pipeline": "AXEL-FLM-paper",
        "status":   "done",
        "steps":    len(results),
    })
    ok("Published pipeline.finished → task.completed channel")

    # ── 8. Network status ─────────────────────────────────────────
    hdr("8 · Network status")

    final = orch.status()
    ok(f"Uptime:     {final['uptime_s']}s")
    ok(f"Agents:     {final['agents']['count']}")
    ok(f"Memory:     {final['memory'].get('total', 0)} lessons  "
       f"(avg confidence {final['memory'].get('avg_confidence', 0):.2f})")
    ok(f"Channels:   {final['channels']}")
    pending = sum(final["inboxes"].values())
    ok(f"Pending:    {pending} messages in inboxes")

    # ── What a real multi-LLM setup looks like ───────────────────
    if not USE_REAL_APIS:
        hdr("To use real LLMs")
        print("""
  CLAUDE (via Anthropic API):
    server.bridge.add_anthropic("researcher",
        model="claude-3-5-haiku-20241022",
        api_key=os.environ["ANTHROPIC_API_KEY"],
        caps=["research","summarize"])

  GPT-4 (via OpenAI API):
    server.bridge.add_openai("writer",
        model="gpt-4o-mini",
        api_key=os.environ["OPENAI_API_KEY"],
        caps=["draft_content","write"])

  LLAMA (via Ollama, free + local):
    ollama pull llama3          # one-time download
    ollama serve                # start the server
    server.bridge.add_ollama("reviewer",
        model="llama3",
        endpoint="http://localhost:11434",
        caps=["review","classify"])

  Then set USE_REAL_APIS = True at the top of this file.
  The rest of the demo runs identically — same AXEL messages,
  same memory, same discovery — just real model inference.
        """)

    print(SEP2)
    print(f"  Live network demo complete!")
    print(f"  Server running at:  {BASE}")
    print(f"  Swagger API docs:   {BASE}/docs")
    print(f"  Live event stream:  {BASE}/stream  (open in browser)")
    print(f"  Network status:     {BASE}/status")
    print(SEP2)
    print("\n  Press Ctrl+C to stop the server.\n")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("  Server stopped.\n")


if __name__ == "__main__":
    main()
