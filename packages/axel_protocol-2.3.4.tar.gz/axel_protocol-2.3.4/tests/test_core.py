"""
tests/test_core.py — Unit tests for AXEL core message building & parsing
"""
import json
import time

import pytest

from axel.core import AXELBuilder, AXELMessage, MsgType, Priority


# ── Fixtures ──────────────────────────────────────────────────────

@pytest.fixture
def builder():
    return AXELBuilder("test_agent")


# ── Message construction ──────────────────────────────────────────

class TestAXELBuilder:

    def test_task_message_structure(self, builder):
        msg = builder.task(
            to="writer",
            action="draft_content",
            args={"topic": "AXEL", "format": "blog"},
        )
        assert isinstance(msg, AXELMessage)
        d = msg.to_dict()
        assert d["t"] == "TK"
        assert d["v"] == "1"
        assert d["fr"] == "test_agent"
        assert d["to"] == "writer"
        assert d["body"]["act"] == "draft_content"
        assert d["body"]["args"]["topic"] == "AXEL"
        assert d["id"].startswith("msg_")
        assert isinstance(d["ts"], int)

    def test_heartbeat_message_structure(self, builder):
        msg = builder.heartbeat("other_agent")
        d = msg.to_dict()
        assert d["t"] == "HB"
        assert d["to"] == "other_agent"

    def test_broadcast_message_structure(self, builder):
        msg = builder.broadcast("hello network", data={"version": "2"})
        d = msg.to_dict()
        assert d["t"] == "BR"
        assert d["to"] == "*"
        assert d["body"]["msg"] == "hello network"

    def test_unique_message_ids(self, builder):
        ids = {builder.task("a", "act", {}).to_dict()["id"] for _ in range(50)}
        assert len(ids) == 50, "Message IDs should be unique"

    def test_conversation_id_consistency(self, builder):
        """All messages from the same builder share a conversation ID."""
        cids = {builder.task("a", "act", {}).to_dict()["cid"] for _ in range(5)}
        assert len(cids) == 1, "All messages from one builder should share a cid"

    def test_timestamp_is_milliseconds(self, builder):
        before = int(time.time() * 1000)
        msg = builder.task("a", "act", {})
        after = int(time.time() * 1000)
        ts = msg.to_dict()["ts"]
        assert before <= ts <= after

    def test_priority_default(self, builder):
        msg = builder.task("a", "act", {})
        # Priority.NORMAL == 2
        assert msg.to_dict()["pri"] == Priority.NORMAL
        assert msg.to_dict()["pri"] == 2

    def test_priority_custom(self, builder):
        msg = builder.task("a", "act", {}, priority=Priority.HIGH)
        assert msg.to_dict()["pri"] == Priority.HIGH
        assert msg.to_dict()["pri"] == 3

    def test_priority_urgent(self, builder):
        msg = builder.task("a", "act", {}, priority=Priority.URGENT)
        assert msg.to_dict()["pri"] == 4

    def test_error_message(self, builder):
        msg = builder.error("other", "TIMEOUT", "took too long", retry=True)
        d = msg.to_dict()
        assert d["t"] == "ER"
        assert d["body"]["code"] == "TIMEOUT"
        assert d["body"]["retry"] is True

    def test_done_message(self, builder):
        msg = builder.done("caller", result={"status": "ok"}, reply_to="msg_abc")
        d = msg.to_dict()
        assert d["t"] == "OK"
        assert d["body"]["result"]["status"] == "ok"
        assert d["re"] == "msg_abc"

    def test_cancel_message(self, builder):
        msg = builder.cancel("agent", task_id="msg_xyz", reason="no longer needed")
        d = msg.to_dict()
        assert d["t"] == "CX"
        assert d["body"]["task_id"] == "msg_xyz"

    def test_negotiate_propose(self, builder):
        msg = builder.propose("other", terms={"rate": 10})
        d = msg.to_dict()
        assert d["t"] == "NG"
        assert d["body"]["op"] == "propose"

    def test_lock_unlock(self, builder):
        lock = builder.lock("server", resource="db_write", ttl=60)
        unlock = builder.unlock("server", resource="db_write")
        assert lock.to_dict()["t"] == "LK"
        assert unlock.to_dict()["t"] == "UL"

    def test_sync_message(self, builder):
        msg = builder.sync("peer", key="state", data={"count": 42})
        d = msg.to_dict()
        assert d["t"] == "SY"
        assert d["body"]["key"] == "state"


# ── Serialisation ────────────────────────────────────────────────

class TestAXELMessageSerialization:

    def test_to_json_roundtrip(self, builder):
        msg = builder.task("writer", "draft_content", {"topic": "AI"})
        raw = msg.to_json()
        assert isinstance(raw, str)
        parsed = json.loads(raw)
        assert parsed["t"] == "TK"
        assert parsed["body"]["args"]["topic"] == "AI"

    def test_from_dict(self, builder):
        original = builder.task("writer", "draft_content", {}).to_dict()
        reconstructed = AXELMessage.from_dict(original)
        assert reconstructed.t == "TK"
        assert reconstructed.to == "writer"
        assert reconstructed.fr == "test_agent"

    def test_from_json(self, builder):
        raw = builder.task("writer", "act", {}).to_json()
        msg = AXELMessage.from_json(raw)
        assert msg.t == "TK"
        assert msg.fr == "test_agent"

    def test_compact_json(self, builder):
        msg = builder.task("a", "act", {})
        compact = msg.to_json(compact=True)
        pretty = msg.to_json(compact=False)
        assert len(compact) < len(pretty)
        # Both should parse to the same message type
        assert json.loads(compact)["t"] == json.loads(pretty)["t"]


# ── Validation ───────────────────────────────────────────────────

class TestAXELMessageValidation:

    def test_valid_message_types_via_builder(self, builder):
        """All core message types can be created through the builder."""
        msgs = [
            builder.task("b", "act", {}),
            builder.query("b", "what?"),
            builder.reply("b", data="answer"),
            builder.status("b", pct=50),
            builder.done("b", result={}),
            builder.error("b", "INTERNAL", "oops"),
            builder.cancel("b", task_id="x"),
            builder.heartbeat("b"),
            builder.broadcast("msg"),
            builder.lock("b", resource="r"),
            builder.unlock("b", resource="r"),
            builder.sync("b", key="k", data={}),
        ]
        # All should be valid AXELMessage instances
        for m in msgs:
            assert isinstance(m, AXELMessage)
            assert m.fr == "test_agent"

    def test_required_fields_present(self, builder):
        d = builder.task("a", "act", {}).to_dict()
        for field in ("v", "t", "id", "cid", "fr", "to", "ts", "pri", "body"):
            assert field in d, f"Required field '{field}' missing from message"

    def test_message_direct_construction(self):
        """AXELMessage can be constructed directly with t= field."""
        msg = AXELMessage(
            t="TK", id="msg_test", cid="cid_test",
            fr="a", to="b", ts=0, pri=3, body={},
        )
        assert msg.t == "TK"
        assert msg.fr == "a"
        assert msg.to == "b"

    def test_all_msgtype_values(self):
        """All MsgType enum values are accessible."""
        assert MsgType.TASK.value      == "TK"
        assert MsgType.DONE.value      == "OK"
        assert MsgType.ERROR.value     == "ER"
        assert MsgType.HEARTBEAT.value == "HB"
        assert MsgType.BROADCAST.value == "BR"
        assert MsgType.CANCEL.value    == "CX"
        assert MsgType.NEGOTIATE.value == "NG"
        assert MsgType.SYNC.value      == "SY"

    def test_priority_values(self):
        """Priority enum values are correct."""
        assert Priority.LOW      == 1
        assert Priority.NORMAL   == 2
        assert Priority.HIGH     == 3
        assert Priority.URGENT   == 4
        assert Priority.CRITICAL == 5
