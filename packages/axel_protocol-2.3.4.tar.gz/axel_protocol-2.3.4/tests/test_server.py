"""
tests/test_server.py — Integration tests for AXEL HTTP server endpoints

Uses httpx + pytest-asyncio with FastAPI's AsyncClient (no real server process needed).
"""
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport

from axel.server import create_app, AXELServer


# ── App fixture ───────────────────────────────────────────────────

@pytest_asyncio.fixture
async def app():
    """Fresh AXEL app instance for each test with clean in-memory state."""
    server = AXELServer()
    # Clear any state loaded from ~/.axel/ so tests are isolated
    with server.registry._lock:
        server.registry._agents.clear()
    with server.memory._lock:
        server.memory._store.clear()
    return server.app


@pytest_asyncio.fixture
async def client(app):
    """Async HTTP client wired directly to the ASGI app."""
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as c:
        yield c


# ── Status & health ──────────────────────────────────────────────

class TestStatus:

    async def test_status_ok(self, client):
        r = await client.get("/status")
        assert r.status_code == 200
        data = r.json()
        assert "agents" in data
        assert "memory" in data
        assert "uptime_s" in data

    async def test_root_redirects_or_200(self, client):
        r = await client.get("/", follow_redirects=True)
        assert r.status_code == 200


# ── Agent registration ────────────────────────────────────────────

class TestAgents:

    async def test_announce_agent(self, client):
        r = await client.post("/agents/announce", json={
            "agent_id": "researcher",
            "model":    "claude-3-5-haiku",
            "provider": "anthropic",
            "caps":     ["research", "summarize"],
            "tags":     [],
        })
        assert r.status_code == 200
        data = r.json()
        # Response may be {"ok": True, "agent": {...}} or {"status": "registered"}
        assert data.get("ok") is True or data.get("status") in ("registered", "updated", "ok")

    async def test_list_agents_empty(self, client):
        r = await client.get("/agents")
        assert r.status_code == 200
        assert "agents" in r.json()

    async def test_list_agents_after_announce(self, client):
        await client.post("/agents/announce", json={
            "agent_id": "writer", "model": "gpt-4o", "provider": "openai",
            "caps": ["write"], "tags": [],
        })
        r = await client.get("/agents")
        agents = r.json()["agents"]
        ids = [a.get("agent_id") or a.get("agent") or a.get("id") for a in agents]
        assert "writer" in ids

    async def test_get_agent_by_id(self, client):
        await client.post("/agents/announce", json={
            "agent_id": "reviewer", "model": "llama3", "provider": "ollama",
            "caps": ["review"], "tags": [],
        })
        r = await client.get("/agents/reviewer")
        assert r.status_code == 200
        data = r.json()
        assert (data.get("agent_id") or data.get("agent") or data.get("id")) == "reviewer"

    async def test_get_unknown_agent_404(self, client):
        r = await client.get("/agents/nonexistent")
        assert r.status_code == 404


# ── Discovery ─────────────────────────────────────────────────────

class TestDiscovery:

    async def test_discover_no_agents(self, client):
        r = await client.get("/discover/translate_text")
        assert r.status_code == 200
        data = r.json()
        assert data.get("best") is None or data.get("candidates") == []

    async def test_discover_finds_capable_agent(self, client):
        await client.post("/agents/announce", json={
            "agent_id": "translator", "model": "gemini-pro", "provider": "google",
            "caps": ["translate_text", "detect_language"], "tags": [],
        })
        r = await client.get("/discover/translate_text")
        assert r.status_code == 200
        data = r.json()
        assert data.get("best") == "translator"


# ── Messaging ─────────────────────────────────────────────────────

class TestMessaging:

    async def test_send_message(self, client):
        # Register recipient first
        await client.post("/agents/announce", json={
            "agent_id": "recipient", "model": "test", "provider": "mock",
            "caps": [], "tags": [],
        })
        msg = {
            "v": "2", "t": "NT", "id": "msg_test001",
            "cid": "cid_test", "fr": "sender", "to": "recipient",
            "ts": 1700000000000, "pri": 3, "body": {"note": "hello"},
        }
        r = await client.post("/send", json=msg)
        assert r.status_code == 200

    async def test_inbox_drain(self, client):
        await client.post("/agents/announce", json={
            "agent_id": "drainer", "model": "test", "provider": "mock",
            "caps": [], "tags": [],
        })
        # Send two messages
        for i in range(2):
            await client.post("/send", json={
                "v": "2", "t": "NT", "id": f"msg_d00{i}",
                "cid": "cid_test", "fr": "sender", "to": "drainer",
                "ts": 1700000000000, "pri": 3, "body": {"n": i},
            })
        r = await client.get("/inbox/drainer/all")
        assert r.status_code == 200
        msgs = r.json().get("msgs", [])
        assert len(msgs) >= 2


# ── Memory ────────────────────────────────────────────────────────

class TestMemory:

    async def test_write_and_list(self, client):
        r = await client.post("/memory/write", json={
            "key": "test_skill",
            "insight": "Testing always catches edge cases",
            "source": "test_agent",
            "confidence": 0.95,
        })
        assert r.status_code == 200

        r2 = await client.get("/memory", params={"top": 10})
        lessons = r2.json().get("lessons", [])
        insights = [l["insight"] for l in lessons]
        assert "Testing always catches edge cases" in insights

    async def test_memory_search(self, client):
        await client.post("/memory/write", json={
            "key": "research",
            "insight": "Multi-hop queries surface deeper context",
            "source": "researcher",
            "confidence": 0.9,
        })
        r = await client.get("/memory/search", params={"q": "multi-hop queries", "n": 5})
        assert r.status_code == 200
        results = r.json().get("results", [])
        # BM25 should surface our lesson
        assert len(results) > 0


# ── Pub/Sub ───────────────────────────────────────────────────────

class TestPubSub:

    async def test_subscribe_and_publish(self, client):
        # Subscribe
        r = await client.post("/channels/subscribe", json={
            "agent_id": "watcher",
            "channel": "task.completed",
            "filter": {},
        })
        assert r.status_code == 200

        # Publish
        r2 = await client.post("/channels/publish", json={
            "publisher": "orchestrator",
            "channel": "task.completed",
            "event": {"status": "done", "task_id": "t001"},
        })
        assert r2.status_code == 200

    async def test_list_channels(self, client):
        await client.post("/channels/subscribe", json={
            "agent_id": "agent1", "channel": "pipeline.ready", "filter": {},
        })
        r = await client.get("/channels")
        assert r.status_code == 200
