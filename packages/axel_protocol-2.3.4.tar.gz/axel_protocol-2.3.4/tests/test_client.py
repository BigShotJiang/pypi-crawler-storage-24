"""
tests/test_client.py — Integration tests for AXELClient SDK

These tests spin up a real in-process AXEL server (background thread)
to exercise the full HTTP round-trip from the client SDK.
"""
import time
import threading

import pytest

from axel.server import AXELServer
from axel.client import AXELClient, AXELAgent


# ── Server fixture ────────────────────────────────────────────────

@pytest.fixture(scope="module")
def live_server():
    """Start a real AXEL server on a free port for the test module."""
    server = AXELServer(host="127.0.0.1", port=17331)
    server.start_background(log_level="error")
    time.sleep(1.0)
    yield "http://127.0.0.1:17331"
    # Server stops when process exits (daemon thread)


@pytest.fixture
def client(live_server):
    c = AXELClient(live_server, "test_client",
                   model="test", provider="mock", caps=["test"])
    yield c


# ── Connection ───────────────────────────────────────────────────

class TestConnection:

    def test_connect_returns_status(self, live_server):
        c = AXELClient(live_server, "conn_test",
                       model="test", provider="mock", caps=[])
        assert c._connected is True

    def test_status_after_connect(self, client):
        s = client.status()
        assert "agents" in s
        assert s["agents"]["count"] >= 1

    def test_network_summary_string(self, client):
        summary = client.network_summary()
        assert "AXEL Network" in summary
        assert "agents" in summary


# ── Agent registration ─────────────────────────────────────────

class TestAgentRegistration:

    def test_agents_list_includes_self(self, live_server):
        c = AXELClient(live_server, "self_checker",
                       model="gpt-4o", provider="openai",
                       caps=["write", "edit"])
        agents = c.agents()
        # Leaderboard entries use "agent_id" (or "agent") as the identifier key
        ids = [a.get("agent_id") or a.get("agent") or a.get("id") for a in agents]
        assert "self_checker" in ids


# ── Discovery ─────────────────────────────────────────────────────

class TestDiscovery:

    def test_discover_registered_capability(self, live_server):
        import uuid
        unique_cap = f"unique_cap_{uuid.uuid4().hex[:8]}"
        c = AXELClient(live_server, "cap_holder",
                       model="test", provider="mock",
                       caps=[unique_cap])
        disc = c.discover(unique_cap)
        assert disc.get("best") == "cap_holder"

    def test_discover_missing_capability(self, client):
        disc = client.discover("nonexistent_action_xyz")
        assert disc.get("best") is None


# ── Memory ────────────────────────────────────────────────────────

class TestMemory:

    def test_learn_and_search(self, client):
        client.learn(
            "pytest_insight",
            "Always write tests before shipping",
            confidence=0.99,
        )
        time.sleep(0.1)
        hits = client.memory_search("write tests", n=5)
        insights = [h["insight"] for h in hits]
        assert any("tests" in i for i in insights)

    def test_memory_list(self, client):
        client.learn("list_test", "Listing memory works", confidence=0.8)
        lessons = client.memory_list(top=20)
        assert isinstance(lessons, list)


# ── Pub/Sub ───────────────────────────────────────────────────────

class TestPubSub:

    def test_subscribe_and_publish(self, live_server):
        watcher = AXELClient(live_server, "pubsub_watcher",
                             model="test", provider="mock", caps=[])
        publisher = AXELClient(live_server, "pubsub_pub",
                               model="test", provider="mock", caps=[])

        watcher.subscribe("events.test")
        result = publisher.publish("events.test", {"msg": "hello from test"})
        assert result is not None   # no exception = success


# ── Mock execution (requires bridge adapter) ─────────────────────

class TestMockExecution:

    def test_execute_with_mock_adapter(self, live_server):
        server = AXELServer.__new__(AXELServer)
        # We can't easily get the running server instance here,
        # so just verify the client's execute path doesn't crash
        # with a short timeout (will get an error response, not raise)
        c = AXELClient(live_server, "exec_tester",
                       model="test", provider="mock", caps=[])
        try:
            result = c.execute("nonexistent_agent", "test_action", {}, timeout=3)
            # Should return an error dict, not raise
            assert isinstance(result, dict)
        except RuntimeError:
            pass  # timeout / no adapter is acceptable in unit test context


# ── AXELAgent base class ──────────────────────────────────────────

class TestAXELAgent:

    def test_task_handler_decorator(self):
        class TestWorker(AXELAgent):
            @AXELAgent.task_handler("my_action")
            def handle_it(self, args, ctx):
                return {"done": True, "topic": args.get("topic")}

        # Handler should be registered at class level
        assert "my_action" in TestWorker._class_handlers

    def test_agent_instantiation(self, live_server):
        class SimpleAgent(AXELAgent):
            @AXELAgent.task_handler("ping_back")
            def handle_ping(self, args, ctx):
                return {"pong": True}

        agent = SimpleAgent(live_server, "simple_agent",
                            model="test", provider="mock",
                            caps=["ping_back"])
        assert agent._connected is True
        assert "ping_back" in agent._handlers
