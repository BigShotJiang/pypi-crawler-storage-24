"""
tests/test_adapters.py — Tests for all AXEL LLM adapters

All tests run without real API keys by using MockAdapter or
verifying adapter class structure only (no network calls).
Provider-specific live tests are marked @pytest.mark.live and
skipped unless the corresponding env var is set.
"""

import os
import pytest

from axel.core import AXELBuilder
from axel.adapters import (
    MockAdapter,
    AnthropicAdapter,
    OpenAIAdapter,
    OllamaAdapter,
    GeminiAdapter,
    MistralAdapter,
    GroqAdapter,
    TogetherAdapter,
    CohereAdapter,
    LiteLLMAdapter,
    BedrockAdapter,
    make_adapter,
    get_adapter,
    PROVIDERS,
)


# ── Helpers ───────────────────────────────────────────────────────

def sample_task(action: str = "summarize", args: dict = None):
    """Build a minimal TK message for testing."""
    b = AXELBuilder("test_caller")
    return b.task("target_agent", action, args or {"text": "hello world"})


# ── MockAdapter ───────────────────────────────────────────────────

class TestMockAdapter:

    def test_returns_ok_message(self):
        adapter = MockAdapter("test_agent")
        msg     = sample_task()
        result  = adapter.execute(msg)
        assert result.t  == "OK"        # AXELMessage uses .t not .type
        assert result.fr == "test_agent"
        assert result.to == "test_caller"

    def test_custom_response_function(self):
        adapter = MockAdapter("test_agent",
                              response_fn=lambda m: {"custom": True})
        result  = adapter.execute(sample_task())
        assert result.body["result"]["custom"] is True

    def test_re_field_set(self):
        msg    = sample_task()
        result = MockAdapter("a").execute(msg)
        assert result.body.get("re") == msg.id or result.re == msg.id


# ── Adapter class structure ───────────────────────────────────────

ADAPTER_CLASSES = [
    AnthropicAdapter,
    OpenAIAdapter,
    OllamaAdapter,
    GeminiAdapter,
    MistralAdapter,
    GroqAdapter,
    TogetherAdapter,
    CohereAdapter,
    LiteLLMAdapter,
    BedrockAdapter,
]


class TestAdapterStructure:
    """Verify every adapter has the required interface without making API calls."""

    @pytest.mark.parametrize("AdapterClass", ADAPTER_CLASSES)
    def test_has_execute_method(self, AdapterClass):
        assert callable(getattr(AdapterClass, "execute", None)), \
            f"{AdapterClass.__name__} missing execute()"

    @pytest.mark.parametrize("AdapterClass", ADAPTER_CLASSES)
    def test_has_provider_attribute(self, AdapterClass):
        assert hasattr(AdapterClass, "PROVIDER"), \
            f"{AdapterClass.__name__} missing PROVIDER class attribute"

    @pytest.mark.parametrize("AdapterClass", ADAPTER_CLASSES)
    def test_has_default_model(self, AdapterClass):
        assert hasattr(AdapterClass, "DEFAULT_MODEL"), \
            f"{AdapterClass.__name__} missing DEFAULT_MODEL"

    @pytest.mark.parametrize("AdapterClass", ADAPTER_CLASSES)
    def test_instantiates_without_api_key(self, AdapterClass):
        """All adapters should instantiate without a key — key only needed at execute()."""
        if AdapterClass is BedrockAdapter:
            obj = AdapterClass("test", capabilities=["test"])
        else:
            obj = AdapterClass("test", capabilities=["test"])
        assert obj.agent_id == "test"

    @pytest.mark.parametrize("AdapterClass", ADAPTER_CLASSES)
    def test_capabilities_stored(self, AdapterClass):
        obj = AdapterClass("test", capabilities=["cap_a", "cap_b"])
        # system prompt should mention the agent and capabilities
        assert "test" in obj.system_prompt or obj.agent_id == "test"


# ── Factory helpers ───────────────────────────────────────────────

class TestAdapterFactory:

    def test_get_adapter_known_provider(self):
        cls = get_adapter("groq")
        assert cls is GroqAdapter

    def test_get_adapter_case_insensitive(self):
        assert get_adapter("GROQ") is GroqAdapter
        assert get_adapter("Mistral") is MistralAdapter

    def test_get_adapter_aliases(self):
        assert get_adapter("aws") is BedrockAdapter
        assert get_adapter("gemini") is GeminiAdapter

    def test_get_adapter_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown provider"):
            get_adapter("nonexistent_provider_xyz")

    def test_make_adapter_returns_instance(self):
        adapter = make_adapter("test_agent", "mock", "mock-model",
                               capabilities=["test"])
        assert isinstance(adapter, MockAdapter)

    def test_providers_dict_complete(self):
        expected = {
            "anthropic", "openai", "ollama", "google", "gemini",
            "mistral", "groq", "together", "cohere", "litellm",
            "bedrock", "aws", "mock",
        }
        assert expected.issubset(set(PROVIDERS.keys()))


# ── Live tests (skipped without API keys) ────────────────────────

def has_key(env_var: str) -> bool:
    return bool(os.environ.get(env_var))


@pytest.mark.live
@pytest.mark.skipif(not has_key("ANTHROPIC_API_KEY"),
                    reason="ANTHROPIC_API_KEY not set")
class TestAnthropicLive:
    def test_execute_real_task(self):
        adapter = AnthropicAdapter("test", capabilities=["summarize"])
        result  = adapter.execute(sample_task("summarize", {"text": "The sky is blue."}))
        assert result.t in ("OK", "ER")
        assert result.fr == "test"


@pytest.mark.live
@pytest.mark.skipif(not has_key("OPENAI_API_KEY"),
                    reason="OPENAI_API_KEY not set")
class TestOpenAILive:
    def test_execute_real_task(self):
        adapter = OpenAIAdapter("test", model="gpt-4o-mini", capabilities=["summarize"])
        result  = adapter.execute(sample_task("summarize", {"text": "The sky is blue."}))
        assert result.t in ("OK", "ER")


@pytest.mark.live
@pytest.mark.skipif(not has_key("GROQ_API_KEY"),
                    reason="GROQ_API_KEY not set")
class TestGroqLive:
    def test_execute_real_task(self):
        adapter = GroqAdapter("test",
                              model="llama-3.1-8b-instant",
                              capabilities=["summarize"])
        result  = adapter.execute(sample_task("summarize", {"text": "The sky is blue."}))
        assert result.t in ("OK", "ER")


@pytest.mark.live
@pytest.mark.skipif(not has_key("GOOGLE_API_KEY"),
                    reason="GOOGLE_API_KEY not set")
class TestGeminiLive:
    def test_execute_real_task(self):
        adapter = GeminiAdapter("test",
                                model="gemini-1.5-flash",
                                capabilities=["summarize"])
        result  = adapter.execute(sample_task("summarize", {"text": "The sky is blue."}))
        assert result.t in ("OK", "ER")
