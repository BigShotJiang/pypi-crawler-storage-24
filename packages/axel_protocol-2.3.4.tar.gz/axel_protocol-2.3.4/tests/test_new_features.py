"""
tests/test_new_features.py — Tests for auth, /ui, liveness, SQLite, testing utils, CLI

Covers:
  - Server auth (X-AXEL-Key middleware)
  - GET /ui serves the dashboard HTML
  - Agent liveness tracking (online flag)
  - SQLite persistence layer
  - axel.testing.MockServer context manager
  - axel.testing.MessageCapture
  - axel CLI argument parsing
"""
import json
import os
import tempfile
import time
import urllib.request
import urllib.error

import pytest

from axel.server import AXELServer
from axel.client import AXELClient
from axel.testing import MockServer, MessageCapture, find_free_port
from axel.persistence import PersistenceLayer
from axel.core import AXELMessage


# ──────────────────────────────────────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────────────────────────────────────

TEST_KEY = "test-secret-key-xyz"


@pytest.fixture(scope="module")
def plain_server():
    """Server without auth."""
    s = AXELServer(host="127.0.0.1", port=17340)
    s.start_background(log_level="error")
    time.sleep(0.5)
    yield f"http://127.0.0.1:17340"


@pytest.fixture(scope="module")
def auth_server():
    """Server with auth enabled."""
    s = AXELServer(host="127.0.0.1", port=17341, key=TEST_KEY)
    s.start_background(log_level="error")
    time.sleep(0.5)
    yield f"http://127.0.0.1:17341"


# ──────────────────────────────────────────────────────────────────────────────
# Auth tests
# ──────────────────────────────────────────────────────────────────────────────

class TestAuth:

    def _get(self, url, key=None):
        headers = {}
        if key:
            headers["X-AXEL-Key"] = key
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, {}

    def test_exempt_routes_no_key_needed(self, auth_server):
        """/, /status, /ui, /stream are exempt from auth."""
        for path in ["/", "/status"]:
            code, data = self._get(f"{auth_server}{path}")
            assert code == 200, f"{path} should be accessible without key"

    def test_protected_route_rejected_without_key(self, auth_server):
        code, _ = self._get(f"{auth_server}/agents")
        assert code == 401

    def test_protected_route_accepted_with_key(self, auth_server):
        code, data = self._get(f"{auth_server}/agents", key=TEST_KEY)
        assert code == 200
        assert "agents" in data

    def test_client_passes_key_automatically(self, auth_server):
        """AXELClient with key= should be able to connect and list agents."""
        c = AXELClient(auth_server, "auth_tester",
                       model="test", provider="mock",
                       caps=["test"], key=TEST_KEY)
        assert c._connected is True
        agents = c.agents()
        ids = [a.get("agent_id") or a.get("agent") for a in agents]
        assert "auth_tester" in ids

    def test_status_shows_auth_enabled(self, auth_server):
        _, data = self._get(f"{auth_server}/status")
        assert data.get("auth") is True

    def test_plain_server_no_auth(self, plain_server):
        _, data = self._get(f"{plain_server}/status")
        assert data.get("auth") is False


# ──────────────────────────────────────────────────────────────────────────────
# /ui dashboard
# ──────────────────────────────────────────────────────────────────────────────

class TestDashboard:

    def test_ui_serves_html(self, plain_server):
        req = urllib.request.Request(f"{plain_server}/ui")
        with urllib.request.urlopen(req, timeout=5) as r:
            assert r.status == 200
            content_type = r.headers.get("Content-Type", "")
            assert "html" in content_type.lower()
            body = r.read().decode()
            assert "<html" in body.lower()
            assert "AXEL" in body

    def test_ui_in_root_links(self, plain_server):
        req = urllib.request.Request(f"{plain_server}/")
        with urllib.request.urlopen(req, timeout=5) as r:
            data = json.loads(r.read())
            assert "ui" in data


# ──────────────────────────────────────────────────────────────────────────────
# Liveness tracking
# ──────────────────────────────────────────────────────────────────────────────

class TestLiveness:

    def test_agent_online_after_announce(self, plain_server):
        c = AXELClient(plain_server, "liveness_agent",
                       model="test", provider="mock", caps=["live_cap"])
        agents = c.agents()
        found = next(
            (a for a in agents
             if (a.get("agent_id") or a.get("agent")) == "liveness_agent"),
            None,
        )
        assert found is not None
        assert found.get("online") is True

    def test_status_has_online_count(self, plain_server):
        req = urllib.request.Request(f"{plain_server}/status")
        with urllib.request.urlopen(req, timeout=5) as r:
            data = json.loads(r.read())
        assert "online" in data["agents"]
        assert isinstance(data["agents"]["online"], int)

    def test_status_agents_have_online_field(self, plain_server):
        req = urllib.request.Request(f"{plain_server}/status")
        with urllib.request.urlopen(req, timeout=5) as r:
            data = json.loads(r.read())
        for agent in data["agents"]["list"]:
            assert "online" in agent


# ──────────────────────────────────────────────────────────────────────────────
# SQLite persistence
# ──────────────────────────────────────────────────────────────────────────────

class TestPersistence:

    def test_upsert_and_list_agents(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            p = PersistenceLayer(db_path)
            p.upsert_agent("alice", model="gpt-4o", provider="openai",
                           caps=["write"], score=9.5, tasks_done=42)
            p.upsert_agent("bob", model="claude-3", provider="anthropic",
                           caps=["research"])
            agents = p.list_agents()
            ids = [a["agent_id"] for a in agents]
            assert "alice" in ids
            assert "bob" in ids
            # alice has higher score — should appear first
            assert agents[0]["agent_id"] == "alice"
            p.close()
        finally:
            os.unlink(db_path)

    def test_write_and_search_lessons(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            p = PersistenceLayer(db_path)
            p.write_lesson("research", "Multi-hop queries improve context", "tester", 0.9)
            p.write_lesson("writing", "Active voice is clearer", "tester", 0.8)
            results = p.search_lessons("queries")
            assert len(results) >= 1
            assert "Multi-hop" in results[0]["insight"]
            p.close()
        finally:
            os.unlink(db_path)

    def test_inbox_enqueue_and_peek(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            p = PersistenceLayer(db_path)
            msg = {"t": "TK", "id": "msg_001", "fr": "planner", "to": "worker",
                   "body": {"act": "draft", "args": {}}, "ts": 0, "pri": 2}
            p.enqueue_message("worker", msg)
            inbox = p.peek_inbox("worker")
            assert len(inbox) == 1
            assert inbox[0]["id"] == "msg_001"
            p.mark_delivered("worker", ["msg_001"])
            inbox_after = p.peek_inbox("worker")
            assert len(inbox_after) == 0
            p.close()
        finally:
            os.unlink(db_path)

    def test_stats(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            p = PersistenceLayer(db_path)
            p.upsert_agent("x", model="m", provider="p", caps=[])
            p.write_lesson("k", "insight", "src", 0.5)
            s = p.stats()
            assert s["agents"] == 1
            assert s["lessons"] == 1
            p.close()
        finally:
            os.unlink(db_path)

    def test_server_with_db_flag(self):
        """Server with --db persists data and stats appear in /status."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            port = find_free_port()
            s = AXELServer(host="127.0.0.1", port=port, db=db_path)
            s.start_background(log_level="error")
            c = AXELClient(f"http://127.0.0.1:{port}", "db_tester",
                           model="test", provider="mock", caps=[])
            c.learn("db_key", "persistence works", confidence=0.99)
            time.sleep(0.2)
            req = urllib.request.Request(f"http://127.0.0.1:{port}/status")
            with urllib.request.urlopen(req, timeout=5) as r:
                data = json.loads(r.read())
            assert data.get("db") == db_path
            assert "db_stats" in data
        finally:
            os.unlink(db_path)


# ──────────────────────────────────────────────────────────────────────────────
# axel.testing utilities
# ──────────────────────────────────────────────────────────────────────────────

class TestMockServerUtil:

    def test_context_manager_returns_url(self):
        with MockServer() as url:
            assert url.startswith("http://127.0.0.1:")

    def test_server_is_reachable(self):
        with MockServer() as url:
            req = urllib.request.Request(f"{url}/status")
            with urllib.request.urlopen(req, timeout=5) as r:
                data = json.loads(r.read())
            assert "agents" in data

    def test_client_connects_inside_context(self):
        with MockServer() as url:
            c = AXELClient(url, "ctx_agent",
                           model="test", provider="mock", caps=["ctx_cap"])
            assert c._connected is True
            agents = c.agents()
            ids = [a.get("agent_id") or a.get("agent") for a in agents]
            assert "ctx_agent" in ids

    def test_each_context_gets_fresh_port(self):
        with MockServer() as url1:
            with MockServer() as url2:
                assert url1 != url2

    def test_mock_server_with_auth_key(self):
        with MockServer(key="my-key") as url:
            c = AXELClient(url, "keyed_agent",
                           model="x", provider="mock", caps=[], key="my-key")
            assert c._connected is True
            # Without key, /agents should be 401
            try:
                req = urllib.request.Request(f"{url}/agents")
                urllib.request.urlopen(req, timeout=5)
                assert False, "Expected 401"
            except urllib.error.HTTPError as e:
                assert e.code == 401


class TestMessageCapture:

    def test_record_and_inspect(self):
        cap = MessageCapture()
        msg = AXELMessage(t="TK", fr="planner", to="worker",
                          body={"act": "draft", "args": {}})
        cap.record(msg)
        assert len(cap.messages) == 1
        assert cap.of_type("TK")[0].fr == "planner"

    def test_assert_received_pass(self):
        cap = MessageCapture()
        msg = AXELMessage(t="TK", fr="a", to="b",
                          body={"act": "write", "args": {}})
        cap.record(msg)
        found = cap.assert_received("TK", action="write")
        assert found.fr == "a"

    def test_assert_received_fail(self):
        cap = MessageCapture()
        with pytest.raises(AssertionError):
            cap.assert_received("TK", action="missing_action")

    def test_assert_count(self):
        cap = MessageCapture()
        for i in range(3):
            cap.record(AXELMessage(t="TK", fr="a", to="b", body={}))
        cap.assert_count(3)
        cap.assert_count(3, msg_type="TK")
        cap.assert_count(0, msg_type="ER")

    def test_assert_no_errors_passes(self):
        cap = MessageCapture()
        cap.record(AXELMessage(t="TK", fr="a", to="b", body={}))
        cap.assert_no_errors()  # should not raise

    def test_assert_no_errors_fails(self):
        cap = MessageCapture()
        cap.record(AXELMessage(t="ER", fr="a", to="b",
                               body={"code": "TIMEOUT", "msg": "too slow"}))
        with pytest.raises(AssertionError):
            cap.assert_no_errors()

    def test_clear(self):
        cap = MessageCapture()
        cap.record(AXELMessage(t="TK", fr="a", to="b", body={}))
        assert len(cap.messages) == 1
        cap.clear()
        assert len(cap.messages) == 0

    def test_wrap_decorator(self):
        cap = MessageCapture()
        received = []

        @cap.wrap
        def handler(msg):
            received.append(msg.body.get("act"))

        msg = AXELMessage(t="TK", fr="x", to="y", body={"act": "do_thing"})
        handler(msg)
        assert len(cap.messages) == 1
        assert received == ["do_thing"]


# ──────────────────────────────────────────────────────────────────────────────
# CLI argument parsing (no server needed)
# ──────────────────────────────────────────────────────────────────────────────

class TestCLIParsing:

    def test_status_subcommand(self):
        from axel.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["status"])
        assert args.command == "status"
        assert "localhost:7331" in args.server

    def test_agents_subcommand(self):
        from axel.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["--json", "agents"])
        assert args.command == "agents"
        assert args.json is True

    def test_send_subcommand(self):
        from axel.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["send", "writer", "draft_content",
                                  "--args", '{"topic": "AI"}',
                                  "--priority", "3"])
        assert args.to == "writer"
        assert args.action == "draft_content"
        assert json.loads(args.args)["topic"] == "AI"
        assert args.priority == 3

    def test_memory_search_subcommand(self):
        from axel.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["memory", "search", "multi-hop queries", "--n", "5"])
        assert args.memory_cmd == "search"
        assert args.query == "multi-hop queries"
        assert args.n == 5

    def test_memory_list_subcommand(self):
        from axel.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["memory", "list", "--top", "50"])
        assert args.memory_cmd == "list"
        assert args.top == 50

    def test_discover_subcommand(self):
        from axel.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["discover", "code_review"])
        assert args.capability == "code_review"

    def test_server_flag(self):
        from axel.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["--server", "http://prod.example.com:7331", "status"])
        assert args.server == "http://prod.example.com:7331"

    def test_key_flag(self):
        from axel.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["--key", "my-secret", "agents"])
        assert args.key == "my-secret"


# ──────────────────────────────────────────────────────────────────────────────
# OpenRouter adapter tests
# ──────────────────────────────────────────────────────────────────────────────

class TestOpenRouterAdapter:
    """Tests for OpenRouterAdapter — all run without a real API key."""

    def test_provider_and_default_model(self):
        from axel.universal import OpenRouterAdapter
        assert OpenRouterAdapter.PROVIDER      == "openrouter"
        assert "free" in OpenRouterAdapter.DEFAULT_MODEL

    def test_shortcut_resolution(self):
        from axel.universal import OpenRouterAdapter
        a = OpenRouterAdapter("bot", model="llama-free")
        assert a.model == "meta-llama/llama-3.1-8b-instruct:free"

    def test_shortcut_gpt4o_mini(self):
        from axel.universal import OpenRouterAdapter
        a = OpenRouterAdapter("bot", model="gpt-4o-mini")
        assert a.model == "openai/gpt-4o-mini"

    def test_shortcut_claude_sonnet(self):
        from axel.universal import OpenRouterAdapter
        a = OpenRouterAdapter("bot", model="claude-sonnet")
        assert a.model == "anthropic/claude-3-5-sonnet"

    def test_full_model_id_passthrough(self):
        """A raw model ID that isn't a shortcut passes through unchanged."""
        from axel.universal import OpenRouterAdapter
        model = "x-ai/grok-beta"
        a     = OpenRouterAdapter("bot", model=model)
        assert a.model == model

    def test_key_from_kwarg(self):
        from axel.universal import OpenRouterAdapter
        a = OpenRouterAdapter("bot", key="sk-test-1234")
        assert a._key == "sk-test-1234"

    def test_key_from_env(self, monkeypatch):
        from axel.universal import OpenRouterAdapter
        monkeypatch.setenv("OPENROUTER_API_KEY", "sk-env-9876")
        a = OpenRouterAdapter("bot")
        assert a._key == "sk-env-9876"

    def test_no_key_raises_on_execute(self, monkeypatch):
        """execute() should return ER when no API key is set."""
        from axel.universal import OpenRouterAdapter
        from axel.core import AXELBuilder
        monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
        adapter = OpenRouterAdapter("bot", key="")
        adapter._key = None  # force-clear
        task = AXELBuilder("sender").task("bot", "do_thing", {})
        result = adapter.execute(task)
        assert result.t == "ER"

    def test_err_on_bad_http(self, monkeypatch):
        """execute() wraps HTTP failures as ER messages."""
        from axel.universal import OpenRouterAdapter
        from axel.core import AXELBuilder

        def fake_client(*a, **kw):
            raise RuntimeError("network error")

        adapter = OpenRouterAdapter("bot", key="sk-fake")
        adapter._get_client = fake_client
        task   = AXELBuilder("sender").task("bot", "do_thing", {})
        result = adapter.execute(task)
        assert result.t == "ER"

    def test_exported_from_package(self):
        from axel import OpenRouterAdapter
        assert OpenRouterAdapter is not None

    def test_bridge_add_openrouter(self):
        """AXELBridge.add_openrouter registers an OpenRouterAdapter."""
        from axel.universal import AXELBridge, OpenRouterAdapter
        bridge = AXELBridge()
        bridge.add_openrouter("mybot", ["research"], key="sk-fake")
        adapter = bridge._adapters["mybot"]
        assert isinstance(adapter, OpenRouterAdapter)
        assert "research" in adapter.system_prompt

    def test_shortcuts_cover_all_free_models(self):
        """Verify the three advertised free shortcuts exist."""
        from axel.universal import OpenRouterAdapter
        free_shortcuts = ["llama-free", "gemma-free", "mistral-free"]
        for s in free_shortcuts:
            resolved = OpenRouterAdapter.SHORTCUTS[s]
            assert ":free" in resolved, f"{s} should resolve to a :free model"


class TestCLISetupAndModels:
    """CLI parsing tests for the new setup + models subcommands."""

    def test_setup_subcommand_parses(self):
        from axel.cli import build_parser
        p    = build_parser()
        args = p.parse_args(["setup"])
        assert args.command == "setup"

    def test_models_subcommand_parses(self):
        from axel.cli import build_parser
        p    = build_parser()
        args = p.parse_args(["models"])
        assert args.command == "models"
        assert args.free is False

    def test_models_free_flag(self):
        from axel.cli import build_parser
        p    = build_parser()
        args = p.parse_args(["models", "--free"])
        assert args.free is True

    def test_load_config_returns_dict_when_missing(self, tmp_path, monkeypatch):
        monkeypatch.setattr("axel.cli._CONFIG_FILE",
                            tmp_path / "nonexistent" / "config.json")
        from axel.cli import _load_config
        assert _load_config() == {}

    def test_save_and_load_config(self, tmp_path, monkeypatch):
        cfg_path = tmp_path / "config.json"
        monkeypatch.setattr("axel.cli._CONFIG_FILE", cfg_path)
        from axel.cli import _save_config, _load_config
        _save_config({"OPENROUTER_API_KEY": "sk-test"})
        loaded = _load_config()
        assert loaded["OPENROUTER_API_KEY"] == "sk-test"
