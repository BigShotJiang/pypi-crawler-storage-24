"""
axel/testing.py — Test utilities for AXEL-based agents.

Provides:
  - MockServer      : context manager that spins up a real AXELServer on a
                      free ephemeral port and tears it down on exit.
  - MessageCapture  : attach to a client and record all messages received,
                      with fluent assertion helpers.
  - find_free_port  : return a free TCP port on localhost.

Quick example::

    from axel.testing import MockServer
    from axel.client import AXELClient

    def test_my_agent():
        with MockServer() as url:
            c = AXELClient(url, "tester", model="test", provider="mock", caps=[])
            c.learn("tip", "always test", confidence=1.0)
            hits = c.memory_search("test", n=5)
            assert any("test" in h["insight"] for h in hits)
"""
from __future__ import annotations

import socket
import time
import threading
from typing import Callable, List, Optional

from axel.core import AXELMessage


# ──────────────────────────────────────────────────────────────────────────────
# Port helper
# ──────────────────────────────────────────────────────────────────────────────

def find_free_port() -> int:
    """Return an available TCP port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


# ──────────────────────────────────────────────────────────────────────────────
# MockServer
# ──────────────────────────────────────────────────────────────────────────────

class MockServer:
    """
    Context manager that starts a real AXELServer on a free port and
    returns its base URL so tests can connect real clients against it.

    Usage::

        with MockServer() as url:
            c = AXELClient(url, "agent", model="x", provider="mock", caps=[])
            ...

    Optional keyword arguments:
        host       : bind address (default "127.0.0.1")
        startup_timeout : seconds to wait for the server to accept connections
                          (default 5.0)
        key        : optional API key to enable auth on the test server
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        startup_timeout: float = 5.0,
        key: Optional[str] = None,
    ):
        self.host = host
        self.port = find_free_port()
        self.startup_timeout = startup_timeout
        self.key = key
        self._server = None

    # ── context manager ───────────────────────────────────────────

    def __enter__(self) -> str:
        from axel.server import AXELServer
        self._server = AXELServer(host=self.host, port=self.port, key=self.key)
        self._server.start_background(log_level="error")
        self._wait_ready()
        return self.url

    def __exit__(self, *_):
        # Server runs as a daemon thread — it stops with the process.
        # For test isolation we just let the port go; each test gets a fresh port.
        self._server = None

    # ── helpers ───────────────────────────────────────────────────

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self.port}"

    def _wait_ready(self):
        import urllib.request as _ur
        deadline = time.time() + self.startup_timeout
        while time.time() < deadline:
            try:
                _ur.urlopen(f"{self.url}/status", timeout=0.5)
                return
            except Exception:
                time.sleep(0.1)
        raise RuntimeError(
            f"MockServer on port {self.port} did not become ready "
            f"within {self.startup_timeout}s"
        )


# ──────────────────────────────────────────────────────────────────────────────
# MessageCapture
# ──────────────────────────────────────────────────────────────────────────────

class MessageCapture:
    """
    Record AXEL messages received by an agent for assertion in tests.

    Attach it to any callable that receives an AXELMessage and call
    ``wrap()`` on the handler, or use ``install()`` on an AXELAgent
    subclass instance.

    Usage with a bare handler function::

        cap = MessageCapture()

        @cap.wrap
        def my_handler(msg: AXELMessage):
            ...   # original logic

    Usage with an AXELAgent — monkey-patches the internal dispatch::

        agent = MyAgent(url, "worker", ...)
        cap = MessageCapture()
        cap.install(agent)

        # ... trigger some work ...
        cap.assert_received("TK", action="draft_content")
        cap.assert_count(1)

    """

    def __init__(self):
        self._messages: List[AXELMessage] = []
        self._lock = threading.Lock()

    # ── recording ─────────────────────────────────────────────────

    def record(self, msg: AXELMessage) -> None:
        """Manually record a message."""
        with self._lock:
            self._messages.append(msg)

    def wrap(self, fn: Callable) -> Callable:
        """Decorator — wraps a handler so every call is captured."""
        def _wrapped(msg: AXELMessage, *args, **kwargs):
            self.record(msg)
            return fn(msg, *args, **kwargs)
        return _wrapped

    def install(self, agent) -> None:
        """
        Monkey-patch an AXELAgent instance to capture all dispatched messages.
        """
        original_dispatch = agent._dispatch

        def _patched(msg):
            self.record(msg)
            return original_dispatch(msg)

        agent._dispatch = _patched

    # ── inspection ────────────────────────────────────────────────

    @property
    def messages(self) -> List[AXELMessage]:
        with self._lock:
            return list(self._messages)

    def clear(self) -> None:
        with self._lock:
            self._messages.clear()

    def of_type(self, t: str) -> List[AXELMessage]:
        """Return all captured messages with the given type code."""
        return [m for m in self.messages if m.t == t]

    def wait_for(
        self,
        predicate: Callable[[AXELMessage], bool],
        timeout: float = 5.0,
        poll: float = 0.05,
    ) -> AXELMessage:
        """
        Block until a message matching *predicate* is received, then return it.
        Raises TimeoutError if not received within *timeout* seconds.
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            for m in self.messages:
                if predicate(m):
                    return m
            time.sleep(poll)
        raise TimeoutError(
            f"No matching message received within {timeout}s. "
            f"Captured: {[m.t for m in self.messages]}"
        )

    # ── assertions ────────────────────────────────────────────────

    def assert_received(
        self,
        msg_type: str,
        *,
        action: Optional[str] = None,
        fr: Optional[str] = None,
        to: Optional[str] = None,
    ) -> AXELMessage:
        """
        Assert that at least one captured message matches the given criteria.
        Returns the first matching message.

        Args:
            msg_type : AXEL type code, e.g. "TK", "OK", "ER"
            action   : expected ``body["act"]`` value (for TASK messages)
            fr       : expected sender agent ID
            to       : expected recipient agent ID
        """
        for m in self.messages:
            if m.t != msg_type:
                continue
            if action is not None and m.body.get("act") != action:
                continue
            if fr is not None and m.fr != fr:
                continue
            if to is not None and m.to != to:
                continue
            return m
        criteria = {"type": msg_type}
        if action: criteria["action"] = action
        if fr:     criteria["from"]   = fr
        if to:     criteria["to"]     = to
        raise AssertionError(
            f"No message matching {criteria} in captured messages. "
            f"Got: {[(m.t, m.body.get('act')) for m in self.messages]}"
        )

    def assert_count(self, n: int, msg_type: Optional[str] = None) -> None:
        """Assert total (or per-type) message count."""
        msgs = self.of_type(msg_type) if msg_type else self.messages
        actual = len(msgs)
        label = f"of type {msg_type!r} " if msg_type else ""
        assert actual == n, (
            f"Expected {n} messages {label}but got {actual}. "
            f"Types: {[m.t for m in self.messages]}"
        )

    def assert_no_errors(self) -> None:
        """Assert no ER messages were captured."""
        errors = self.of_type("ER")
        if errors:
            summaries = [f"[{m.fr}→{m.to}] {m.body.get('msg','?')}" for m in errors]
            raise AssertionError(
                f"Unexpected ER messages captured:\n" + "\n".join(summaries)
            )

    def __repr__(self) -> str:
        counts: dict[str, int] = {}
        for m in self.messages:
            counts[m.t] = counts.get(m.t, 0) + 1
        return f"MessageCapture({counts})"
