"""
axel — Agent eXchange Language
================================
A universal protocol for multi-LLM networks.

Quick start:
    from axel import AXELClient, AXELAgent, AXELServer

    # Start the hub (with optional auth + persistence)
    server = AXELServer(key="secret", db="axel.db")
    server.start_background()

    # Connect an agent
    client = AXELClient("http://localhost:7331", "my_agent",
                        model="claude-3-5-haiku", provider="anthropic",
                        caps=["research", "summarize"],
                        key="secret")

    # Execute a task on another agent
    result = client.execute("writer", "draft_content", {"topic": "AI"})

Testing:
    from axel.testing import MockServer, MessageCapture

    with MockServer() as url:
        c = AXELClient(url, "tester", model="x", provider="mock", caps=[])
        ...
"""

from axel.core import AXELBuilder, AXELMessage
from axel.client import AXELClient, AXELAgent
from axel.server import AXELServer
from axel.universal import SmartMemory
from axel.adapters import (
    # bundled
    MockAdapter, AnthropicAdapter, OpenAIAdapter, OllamaAdapter, OpenRouterAdapter,
    # optional (lazy-loaded)
    GeminiAdapter, MistralAdapter, GroqAdapter,
    TogetherAdapter, CohereAdapter, LiteLLMAdapter, BedrockAdapter,
    # factory
    make_adapter, get_adapter,
)

__version__ = "2.1.1"
__author__  = "Sector X"
__license__ = "MIT"

__all__ = [
    # Core message types
    "AXELMessage",
    "AXELBuilder",
    # Client SDK
    "AXELClient",
    "AXELAgent",
    # Server
    "AXELServer",
    # Memory
    "SmartMemory",
    # Adapters — bundled
    "MockAdapter",
    "AnthropicAdapter",
    "OpenAIAdapter",
    "OllamaAdapter",
    "OpenRouterAdapter",
    # Adapters — optional providers
    "GeminiAdapter",
    "MistralAdapter",
    "GroqAdapter",
    "TogetherAdapter",
    "CohereAdapter",
    "LiteLLMAdapter",
    "BedrockAdapter",
    # Factory helpers
    "make_adapter",
    "get_adapter",
    # Testing utilities
    "testing",
    # Persistence
    "persistence",
]
