"""
AXEL — Agent eXchange Language
Reference Python Implementation v1.0

A compact, structured, expressive language for agent-to-agent communication.

Usage:
    from axel import AXELBuilder, AXELParser, AXELRouter, MsgType, Priority

    # Create a builder for your agent
    builder = AXELBuilder("planner_agent")

    # Build messages
    task_msg = builder.task("executor_agent", "summarize_doc", args={"url": "https://..."})
    print(task_msg.to_json())  # compact wire format

    # Parse incoming messages
    msg = AXELParser.parse('{"v":"1","id":"msg_abc",...}')

    # Route messages
    router = AXELRouter()
    router.register("executor_agent", MsgType.TASK, handle_task)
    router.route(incoming_msg)
"""

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class MsgType(str, Enum):
    """All valid AXEL message type codes."""
    TASK      = "TK"   # Assign work
    QUERY     = "QR"   # Request information
    REPLY     = "RP"   # Respond to task/query
    STATUS    = "ST"   # Progress update
    DONE      = "OK"   # Task completed
    ERROR     = "ER"   # Failure report
    CANCEL    = "CX"   # Cancel in-flight task
    HANDOFF   = "HO"   # Transfer task ownership
    NEGOTIATE = "NG"   # Negotiate terms
    SYNC      = "SY"   # State synchronization
    HEARTBEAT = "HB"   # Keepalive
    BROADCAST = "BR"   # One-to-many announcement
    LOCK      = "LK"   # Acquire resource lock
    UNLOCK    = "UL"   # Release resource lock
    EVENT     = "EV"   # Emit typed event


class Priority(int, Enum):
    """Message priority levels."""
    LOW      = 1
    NORMAL   = 2
    HIGH     = 3
    URGENT   = 4
    CRITICAL = 5


class ErrorCode(str, Enum):
    """Standard AXEL error codes."""
    TIMEOUT      = "TIMEOUT"
    NOT_FOUND    = "NOT_FOUND"
    UNAUTHORIZED = "UNAUTHORIZED"
    INVALID      = "INVALID"
    OVERLOADED   = "OVERLOADED"
    CANCELLED    = "CANCELLED"
    DEPENDENCY   = "DEPENDENCY"
    INTERNAL     = "INTERNAL"


class NegotiateOp(str, Enum):
    """Operations for NEGOTIATE messages."""
    PROPOSE = "propose"
    ACCEPT  = "accept"
    REJECT  = "reject"
    COUNTER = "counter"


# ---------------------------------------------------------------------------
# Message dataclass
# ---------------------------------------------------------------------------

def _new_id(prefix: str = "msg") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"

def _now_ms() -> int:
    return int(time.time() * 1000)


@dataclass
class AXELMessage:
    """
    An AXEL protocol message.

    Envelope fields match the spec exactly (short keys).
    `body` is a free-form dict whose schema depends on `t` (message type).
    """
    t:    str           # message type code
    fr:   str           # sender agent ID
    to:   str           # recipient agent ID (or "*")
    body: Dict          # type-specific payload

    v:    str           = "1"
    id:   str           = field(default_factory=lambda: _new_id("msg"))
    cid:  str           = field(default_factory=lambda: _new_id("cnv"))
    ts:   int           = field(default_factory=_now_ms)
    pri:  int           = Priority.NORMAL
    ttl:  int           = 0
    re:   Optional[str] = None
    sig:  Optional[str] = None

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self, strip_none: bool = True) -> dict:
        """Convert to a plain dict. Strips None values by default."""
        d = asdict(self)
        if strip_none:
            d = {k: v for k, v in d.items() if v is not None}
        return d

    def to_json(self, compact: bool = True) -> str:
        """
        Serialize to a JSON string.

        compact=True  → no whitespace (recommended for wire format)
        compact=False → pretty-printed (useful for debugging)
        """
        d = self.to_dict()
        if compact:
            return json.dumps(d, separators=(',', ':'))
        return json.dumps(d, indent=2)

    def is_expired(self) -> bool:
        """Return True if the message TTL has elapsed."""
        if self.ttl == 0:
            return False
        elapsed = (int(time.time() * 1000) - self.ts) / 1000
        return elapsed > self.ttl

    # ------------------------------------------------------------------
    # Deserialization
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, d: dict) -> "AXELMessage":
        """Create from a dict. Extra/unknown fields are ignored."""
        known = {f for f in cls.__dataclass_fields__}
        filtered = {k: v for k, v in d.items() if k in known}
        return cls(**filtered)

    @classmethod
    def from_json(cls, raw: str) -> "AXELMessage":
        """Create from a JSON string."""
        return cls.from_dict(json.loads(raw))

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def reply_envelope(self, from_agent: str) -> "AXELMessage":
        """
        Create a bare reply shell with envelope fields pre-filled.
        Caller must set `t` and `body` before sending.
        """
        return AXELMessage(
            t="RP", fr=from_agent, to=self.fr,
            body={}, cid=self.cid, re=self.id
        )

    def __repr__(self) -> str:
        return f"AXELMessage(t={self.t!r}, fr={self.fr!r}, to={self.to!r}, id={self.id!r})"


# ---------------------------------------------------------------------------
# Builder — fluent factory for all message types
# ---------------------------------------------------------------------------

class AXELBuilder:
    """
    Fluent builder for AXEL messages.

    Instantiate once per agent; the builder remembers your agent ID and
    optionally pins a conversation ID for threading.

    Example:
        b = AXELBuilder("planner", conversation_id="cnv_abc")
        msg = b.task("worker", "analyze", args={"doc": "..."}, priority=Priority.HIGH)
    """

    def __init__(self, agent_id: str, conversation_id: Optional[str] = None):
        self.agent_id = agent_id
        self.conversation_id = conversation_id or _new_id("cnv")

    def new_conversation(self) -> "AXELBuilder":
        """Return a new builder with a fresh conversation ID."""
        return AXELBuilder(self.agent_id)

    def _msg(self, t: str, to: str, body: dict, **kwargs) -> AXELMessage:
        return AXELMessage(
            t=t, fr=self.agent_id, to=to,
            body=body, cid=self.conversation_id,
            **kwargs
        )

    # ------------------------------------------------------------------
    # TASK
    # ------------------------------------------------------------------

    def task(
        self,
        to: str,
        action: str,
        args: Optional[dict] = None,
        ctx: Optional[dict] = None,
        deps: Optional[List[str]] = None,
        timeout: Optional[int] = None,
        retries: int = 0,
        priority: int = Priority.NORMAL,
        ttl: int = 0,
    ) -> AXELMessage:
        """Assign work to an agent."""
        body: dict = {"act": action, "args": args or {}}
        if ctx:     body["ctx"] = ctx
        if deps:    body["deps"] = deps
        if timeout: body["timeout"] = timeout
        if retries: body["retries"] = retries
        return self._msg(MsgType.TASK, to, body, pri=priority, ttl=ttl)

    # ------------------------------------------------------------------
    # QUERY
    # ------------------------------------------------------------------

    def query(
        self,
        to: str,
        question: str,
        fmt: str = "text",
        opts: Optional[dict] = None,
        priority: int = Priority.NORMAL,
    ) -> AXELMessage:
        """Request information from an agent."""
        body: dict = {"q": question, "fmt": fmt}
        if opts: body["opts"] = opts
        return self._msg(MsgType.QUERY, to, body, pri=priority)

    # ------------------------------------------------------------------
    # REPLY
    # ------------------------------------------------------------------

    def reply(
        self,
        to: str,
        data: Any,
        reply_to: Optional[str] = None,
        partial: bool = False,
        err: Optional[str] = None,
    ) -> AXELMessage:
        """Respond to a task or query."""
        body: dict = {"data": data, "partial": partial}
        if err: body["err"] = err
        return self._msg(MsgType.REPLY, to, body, re=reply_to)

    # ------------------------------------------------------------------
    # STATUS
    # ------------------------------------------------------------------

    def status(
        self,
        to: str,
        pct: int,
        phase: str = "",
        msg: str = "",
        eta: int = 0,
    ) -> AXELMessage:
        """Report progress on a running task."""
        return self._msg(MsgType.STATUS, to, {
            "pct": pct, "phase": phase, "msg": msg, "eta": eta
        })

    # ------------------------------------------------------------------
    # DONE
    # ------------------------------------------------------------------

    def done(
        self,
        to: str,
        result: Any = None,
        reply_to: Optional[str] = None,
    ) -> AXELMessage:
        """Signal successful task completion."""
        body: dict = {}
        if result is not None: body["result"] = result
        return self._msg(MsgType.DONE, to, body, re=reply_to)

    # ------------------------------------------------------------------
    # ERROR
    # ------------------------------------------------------------------

    def error(
        self,
        to: str,
        code: str,
        msg: str,
        retry: bool = False,
        trace: Optional[str] = None,
        reply_to: Optional[str] = None,
    ) -> AXELMessage:
        """Report a failure."""
        body: dict = {"code": code, "msg": msg, "retry": retry}
        if trace: body["trace"] = trace
        return self._msg(MsgType.ERROR, to, body, re=reply_to)

    # ------------------------------------------------------------------
    # CANCEL
    # ------------------------------------------------------------------

    def cancel(self, to: str, task_id: str, reason: str = "") -> AXELMessage:
        """Request cancellation of an in-flight task."""
        return self._msg(MsgType.CANCEL, to, {"task_id": task_id, "reason": reason})

    # ------------------------------------------------------------------
    # HANDOFF
    # ------------------------------------------------------------------

    def handoff(
        self,
        to: str,
        new_agent: str,
        ctx: Optional[dict] = None,
        tasks: Optional[List[str]] = None,
        reason: str = "",
    ) -> AXELMessage:
        """Transfer task ownership to another agent."""
        return self._msg(MsgType.HANDOFF, to, {
            "new_agent": new_agent,
            "ctx": ctx or {},
            "tasks": tasks or [],
            "reason": reason,
        })

    # ------------------------------------------------------------------
    # NEGOTIATE
    # ------------------------------------------------------------------

    def propose(self, to: str, terms: dict) -> AXELMessage:
        """Initiate a negotiation with proposed terms."""
        return self._msg(MsgType.NEGOTIATE, to, {"op": NegotiateOp.PROPOSE, "terms": terms})

    def accept(self, to: str, terms: dict) -> AXELMessage:
        """Accept proposed terms."""
        return self._msg(MsgType.NEGOTIATE, to, {"op": NegotiateOp.ACCEPT, "terms": terms})

    def reject(self, to: str, terms: dict, reason: str = "") -> AXELMessage:
        """Reject proposed terms."""
        return self._msg(MsgType.NEGOTIATE, to, {"op": NegotiateOp.REJECT, "terms": terms, "reason": reason})

    def counter(self, to: str, terms: dict, counter: dict, reason: str = "") -> AXELMessage:
        """Counter-propose during negotiation."""
        return self._msg(MsgType.NEGOTIATE, to, {
            "op": NegotiateOp.COUNTER, "terms": terms, "counter": counter, "reason": reason
        })

    # ------------------------------------------------------------------
    # SYNC
    # ------------------------------------------------------------------

    def sync(self, to: str, key: str, data: dict, patch: bool = False) -> AXELMessage:
        """Synchronize shared state."""
        return self._msg(MsgType.SYNC, to, {"key": key, "data": data, "patch": patch})

    # ------------------------------------------------------------------
    # HEARTBEAT
    # ------------------------------------------------------------------

    def heartbeat(self, to: str = "*") -> AXELMessage:
        """Send a keepalive signal."""
        return self._msg(MsgType.HEARTBEAT, to, {})

    # ------------------------------------------------------------------
    # BROADCAST
    # ------------------------------------------------------------------

    def broadcast(self, message: str, data: Optional[dict] = None) -> AXELMessage:
        """Announce something to all agents."""
        return self._msg(MsgType.BROADCAST, "*", {"msg": message, "data": data or {}})

    # ------------------------------------------------------------------
    # LOCK / UNLOCK
    # ------------------------------------------------------------------

    def lock(self, to: str, resource: str, ttl: int = 30) -> AXELMessage:
        """Request exclusive access to a named resource."""
        return self._msg(MsgType.LOCK, to, {"resource": resource, "ttl": ttl})

    def unlock(self, to: str, resource: str) -> AXELMessage:
        """Release a previously held lock."""
        return self._msg(MsgType.UNLOCK, to, {"resource": resource})

    # ------------------------------------------------------------------
    # EVENT
    # ------------------------------------------------------------------

    def event(self, evt: str, data: Optional[dict] = None, to: str = "*") -> AXELMessage:
        """Emit a typed event to subscribers."""
        return self._msg(MsgType.EVENT, to, {"evt": evt, "data": data or {}})


# ---------------------------------------------------------------------------
# Parser — validate and deserialize incoming messages
# ---------------------------------------------------------------------------

class AXELParser:
    """
    Parse and validate AXEL messages from JSON strings or dicts.

    Raises ValueError with descriptive messages on validation failure.
    """

    REQUIRED_FIELDS  = frozenset({"v", "id", "cid", "t", "fr", "to", "ts", "body"})
    VALID_TYPES      = frozenset(t.value for t in MsgType)

    @classmethod
    def parse(cls, raw: Union[str, dict]) -> AXELMessage:
        """
        Parse an AXEL message. Raises ValueError if invalid.

        Args:
            raw: A JSON string or a pre-decoded dict.

        Returns:
            An AXELMessage instance.
        """
        if isinstance(raw, str):
            try:
                data = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise ValueError(f"AXEL parse error — invalid JSON: {exc}") from exc
        elif isinstance(raw, dict):
            data = raw
        else:
            raise TypeError(f"Expected str or dict, got {type(raw).__name__}")

        cls._validate(data)
        return AXELMessage.from_dict(data)

    @classmethod
    def _validate(cls, data: dict) -> None:
        missing = cls.REQUIRED_FIELDS - set(data.keys())
        if missing:
            raise ValueError(f"AXEL validation error — missing required fields: {sorted(missing)}")

        if data["t"] not in cls.VALID_TYPES:
            raise ValueError(
                f"AXEL validation error — unknown message type '{data['t']}'. "
                f"Valid types: {sorted(cls.VALID_TYPES)}"
            )

        if not isinstance(data["body"], dict):
            raise ValueError("AXEL validation error — 'body' must be a JSON object")

        if not isinstance(data["ts"], (int, float)):
            raise ValueError("AXEL validation error — 'ts' must be a numeric timestamp")

    @classmethod
    def is_valid(cls, raw: Union[str, dict]) -> bool:
        """Return True if the message parses without error, False otherwise."""
        try:
            if isinstance(raw, str):
                raw = json.loads(raw)
            cls._validate(raw)
            return True
        except (ValueError, TypeError, json.JSONDecodeError):
            return False


# ---------------------------------------------------------------------------
# Router — dispatch incoming messages to registered handlers
# ---------------------------------------------------------------------------

Handler = Callable[[AXELMessage], Any]


class AXELRouter:
    """
    Simple synchronous message router.

    Register handlers per (agent_id, message_type) pair. When a message
    arrives, call router.route(msg) to dispatch it.

    Example:
        router = AXELRouter()

        def handle_task(msg: AXELMessage):
            print(f"Got task: {msg.body['act']}")

        router.register("worker_agent", MsgType.TASK, handle_task)
        router.register("worker_agent", MsgType.CANCEL, handle_cancel)

        # Broadcast handler (catches to="*" for that type)
        router.register_broadcast(MsgType.BROADCAST, handle_broadcast)

        router.route(incoming_message)
    """

    def __init__(self):
        # { agent_id: { msg_type_code: handler } }
        self._handlers: Dict[str, Dict[str, Handler]] = {}
        # { msg_type_code: handler }  — for broadcast/event messages
        self._broadcast_handlers: Dict[str, Handler] = {}

    def register(self, agent_id: str, msg_type: Union[MsgType, str], handler: Handler) -> None:
        """Register a handler for a specific agent and message type."""
        code = msg_type.value if isinstance(msg_type, MsgType) else msg_type
        self._handlers.setdefault(agent_id, {})[code] = handler

    def register_broadcast(self, msg_type: Union[MsgType, str], handler: Handler) -> None:
        """Register a handler for broadcast/event messages (to="*")."""
        code = msg_type.value if isinstance(msg_type, MsgType) else msg_type
        self._broadcast_handlers[code] = handler

    def route(self, msg: AXELMessage) -> Any:
        """
        Dispatch msg to the appropriate handler.

        Raises LookupError if no handler is registered for the message.
        Skips expired messages silently (logs a warning).
        """
        if msg.is_expired():
            # In production, replace with your logger
            print(f"[AXELRouter] WARNING: Dropping expired message {msg.id}")
            return None

        if msg.to == "*":
            handler = self._broadcast_handlers.get(msg.t)
        else:
            handler = self._handlers.get(msg.to, {}).get(msg.t)

        if handler is None:
            raise LookupError(
                f"[AXELRouter] No handler registered for agent='{msg.to}', type='{msg.t}'"
            )

        return handler(msg)

    def has_handler(self, agent_id: str, msg_type: Union[MsgType, str]) -> bool:
        """Check whether a handler is registered."""
        code = msg_type.value if isinstance(msg_type, MsgType) else msg_type
        return code in self._handlers.get(agent_id, {})


# ---------------------------------------------------------------------------
# Convenience top-level functions
# ---------------------------------------------------------------------------

def parse(raw: Union[str, dict]) -> AXELMessage:
    """Parse and validate an AXEL message. Raises ValueError if invalid."""
    return AXELParser.parse(raw)


def is_valid(raw: Union[str, dict]) -> bool:
    """Return True if raw is a valid AXEL message, False otherwise."""
    return AXELParser.is_valid(raw)


# ---------------------------------------------------------------------------
# Demo — run this file directly to see AXEL in action
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=" * 60)
    print("AXEL — Agent eXchange Language  |  Reference Demo")
    print("=" * 60)

    # ── Setup ──────────────────────────────────────────────────────────
    planner  = AXELBuilder("planner",  conversation_id="cnv_demo01")
    executor = AXELBuilder("executor", conversation_id="cnv_demo01")
    monitor  = AXELBuilder("monitor",  conversation_id="cnv_demo01")

    router = AXELRouter()

    # ── 1. Planner assigns a task ──────────────────────────────────────
    task_msg = planner.task(
        to="executor",
        action="summarize_document",
        args={"url": "https://example.com/report.pdf", "max_words": 200},
        timeout=120,
        priority=Priority.HIGH,
    )

    print("\n[1] TASK (compact wire format):")
    print(task_msg.to_json())

    print("\n[1] TASK (pretty):")
    print(task_msg.to_json(compact=False))

    # ── 2. Executor reports progress ───────────────────────────────────
    status_msg = executor.status(
        to="planner", pct=45, phase="fetching", msg="Downloading PDF…", eta=30
    )
    print("\n[2] STATUS:")
    print(status_msg.to_json())

    # ── 3. Executor completes the task ─────────────────────────────────
    done_msg = executor.done(
        to="planner",
        result={"summary": "The report covers Q1 results…"},
        reply_to=task_msg.id,
    )
    print("\n[3] DONE:")
    print(done_msg.to_json())

    # ── 4. Negotiation flow ────────────────────────────────────────────
    propose_msg = planner.propose("executor", terms={"deadline_s": 30, "fmt": "json"})
    counter_msg = executor.counter(
        to="planner",
        terms={"deadline_s": 30, "fmt": "json"},
        counter={"deadline_s": 90},
        reason="30s is too tight for this model",
    )
    accept_msg = planner.accept("executor", terms={"deadline_s": 90, "fmt": "json"})

    print("\n[4] NEGOTIATE — propose → counter → accept:")
    for m in [propose_msg, counter_msg, accept_msg]:
        print(f"  {m.t}  {m.fr:10s} → {m.to:10s}  op={m.body.get('op','')}")

    # ── 5. Broadcast event ─────────────────────────────────────────────
    bc_msg = monitor.broadcast("Pipeline phase 1 complete", data={"items_processed": 142})
    print("\n[5] BROADCAST:")
    print(bc_msg.to_json())

    # ── 6. Parse round-trip ────────────────────────────────────────────
    wire = task_msg.to_json()
    parsed = parse(wire)
    assert parsed.id   == task_msg.id
    assert parsed.t    == task_msg.t
    assert parsed.body == task_msg.body
    print("\n[6] Parse round-trip: ✓  (parsed.id ==", parsed.id, ")")

    # ── 7. Validation ──────────────────────────────────────────────────
    print("\n[7] Validation:")
    print("  valid msg   →", is_valid(wire))
    print("  empty dict  →", is_valid({}))
    print("  bad type    →", is_valid({**task_msg.to_dict(), "t": "XX"}))

    # ── 8. Router dispatch ─────────────────────────────────────────────
    results = []

    def handle_task(msg: AXELMessage):
        results.append(f"executor handled TASK: {msg.body['act']}")

    def handle_broadcast(msg: AXELMessage):
        results.append(f"broadcast received: {msg.body['msg']}")

    router.register("executor", MsgType.TASK, handle_task)
    router.register_broadcast(MsgType.BROADCAST, handle_broadcast)

    router.route(task_msg)
    router.route(bc_msg)

    print("\n[8] Router dispatch results:")
    for r in results:
        print(" ", r)

    print("\n" + "=" * 60)
    print("All demos complete.")
