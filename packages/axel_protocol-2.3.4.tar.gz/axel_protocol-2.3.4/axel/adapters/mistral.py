"""
axel/adapters/mistral.py — Mistral AI adapter for AXEL

Supported models (as of 2024):
    mistral-small-latest    fast, cheap
    mistral-medium-latest   balanced
    mistral-large-latest    flagship
    codestral-latest        code specialised
    open-mixtral-8x7b       open weights MoE
    open-mixtral-8x22b      open weights large MoE

Install:
    pip install mistralai

Auth:
    export MISTRAL_API_KEY=your_key
"""

from __future__ import annotations

import json
import os
import re
from typing import List, Optional

from axel.universal import BaseAdapter, make_system_prompt, AXELMessage


class MistralAdapter(BaseAdapter):
    """
    Execute AXEL TASK messages using Mistral AI.

    Example::

        adapter = MistralAdapter(
            "coder",
            model="codestral-latest",
            capabilities=["write_code", "review_code", "debug"],
        )
        result = adapter.execute(task_msg)
    """

    PROVIDER = "mistral"
    DEFAULT_MODEL = "mistral-small-latest"

    def __init__(
        self,
        agent_id: str,
        model: str = DEFAULT_MODEL,
        capabilities: Optional[List[str]] = None,
        api_key: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ):
        system = make_system_prompt(agent_id, capabilities or [], f"mistral/{model}")
        super().__init__(agent_id, system)
        self.model       = model
        self.temperature = temperature
        self.max_tokens  = max_tokens
        self._api_key    = api_key or os.environ.get("MISTRAL_API_KEY")
        self._client     = None

    def _get_client(self):
        if self._client is None:
            try:
                from mistralai import Mistral
            except ImportError:
                raise RuntimeError(
                    "Mistral AI SDK not installed.\n"
                    "Run: pip install mistralai"
                )
            self._client = Mistral(api_key=self._api_key)
        return self._client

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        action = task_msg.body.get("act", "unknown")
        args   = task_msg.body.get("args", {})
        ctx    = task_msg.body.get("ctx", {})

        user_content = (
            f"AXEL TASK:\n{task_msg.to_json(compact=False)}\n\n"
            f"Execute '{action}' with args: {json.dumps(args)}\n"
            f"Context: {json.dumps(ctx)}\n\n"
            f"Respond with a single compact AXEL OK or ER JSON message."
        )

        try:
            client = self._get_client()
            resp   = client.chat.complete(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user",   "content": user_content},
                ],
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            raw = resp.choices[0].message.content.strip()

            try:
                match = re.search(r"\{.*\}", raw, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    return AXELMessage.from_dict({
                        **parsed,
                        "fr":  self.agent_id,
                        "to":  task_msg.fr,
                        "cid": task_msg.cid,
                        "re":  task_msg.id,
                    })
            except Exception:
                pass

            return self._ok(task_msg, {"text": raw})

        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)
