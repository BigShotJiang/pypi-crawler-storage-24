"""
axel/adapters/together.py — Together AI adapter for AXEL

Together AI hosts 100+ open-source models with competitive pricing
and an OpenAI-compatible API.

Popular models (as of 2024):
    meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo    fast Llama 70B
    meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo     cheapest Llama
    mistralai/Mixtral-8x7B-Instruct-v0.1             MoE
    mistralai/Mistral-7B-Instruct-v0.3               tiny + fast
    Qwen/Qwen2.5-72B-Instruct-Turbo                  strong multilingual
    deepseek-ai/deepseek-coder-33b-instruct          code specialist
    NousResearch/Nous-Hermes-2-Mixtral-8x7B-DPO      instruction tuned

Install:
    pip install together

Auth:
    export TOGETHER_API_KEY=your_key
    # Free $1 credit on sign-up at https://api.together.xyz
"""

from __future__ import annotations

import json
import os
import re
from typing import List, Optional

from axel.universal import BaseAdapter, make_system_prompt, AXELMessage


class TogetherAdapter(BaseAdapter):
    """
    Execute AXEL TASK messages using Together AI.

    Together gives access to 100+ open-source models under one API key,
    making it ideal for experimenting with different models in the same network.

    Example::

        adapter = TogetherAdapter(
            "coder",
            model="deepseek-ai/deepseek-coder-33b-instruct",
            capabilities=["write_code", "explain_code", "debug"],
        )
        result = adapter.execute(task_msg)
    """

    PROVIDER = "together"
    DEFAULT_MODEL = "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo"

    def __init__(
        self,
        agent_id: str,
        model: str = DEFAULT_MODEL,
        capabilities: Optional[List[str]] = None,
        api_key: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ):
        system = make_system_prompt(agent_id, capabilities or [], f"together/{model}")
        super().__init__(agent_id, system)
        self.model       = model
        self.temperature = temperature
        self.max_tokens  = max_tokens
        self._api_key    = api_key or os.environ.get("TOGETHER_API_KEY")
        self._client     = None

    def _get_client(self):
        if self._client is None:
            try:
                from together import Together
            except ImportError:
                raise RuntimeError(
                    "Together AI SDK not installed.\n"
                    "Run: pip install together"
                )
            self._client = Together(api_key=self._api_key)
        return self._client

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        action = task_msg.body.get("act", "unknown")
        args   = task_msg.body.get("args", {})
        ctx    = task_msg.body.get("ctx", {})

        user_content = (
            f"AXEL TASK:\n{task_msg.to_json(compact=False)}\n\n"
            f"Execute '{action}' with args: {json.dumps(args)}\n"
            f"Context: {json.dumps(ctx)}\n\n"
            f"Respond with a single compact AXEL OK or ER JSON message."
        )

        try:
            client = self._get_client()
            resp   = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user",   "content": user_content},
                ],
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            raw = resp.choices[0].message.content.strip()

            try:
                match = re.search(r"\{.*\}", raw, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    return AXELMessage.from_dict({
                        **parsed,
                        "fr":  self.agent_id,
                        "to":  task_msg.fr,
                        "cid": task_msg.cid,
                        "re":  task_msg.id,
                    })
            except Exception:
                pass

            return self._ok(task_msg, {"text": raw})

        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)
