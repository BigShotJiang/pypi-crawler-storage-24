"""
axel.adapters — LLM provider adapters for the AXEL network
===========================================================

All adapters share the same interface: instantiate with an agent_id + model,
then call adapter.execute(task_msg) to get back an AXELMessage.

Quick reference
---------------
Provider          Class               Install                     Env var
──────────────    ────────────────    ────────────────────────    ────────────────────────
OpenRouter        OpenRouterAdapter   pip install openai          OPENROUTER_API_KEY  ← start here
Anthropic         AnthropicAdapter    (bundled)                   ANTHROPIC_API_KEY
OpenAI            OpenAIAdapter       (bundled)                   OPENAI_API_KEY
Ollama (local)    OllamaAdapter       (bundled)                   —
Google Gemini     GeminiAdapter       google-generativeai         GOOGLE_API_KEY
Mistral AI        MistralAdapter      mistralai                   MISTRAL_API_KEY
Groq              GroqAdapter         groq                        GROQ_API_KEY
Together AI       TogetherAdapter     together                    TOGETHER_API_KEY
Cohere            CohereAdapter       cohere                      COHERE_API_KEY
AWS Bedrock       BedrockAdapter      boto3                       AWS_* credentials
Any (LiteLLM)     LiteLLMAdapter      litellm                     provider-specific
Mock (testing)    MockAdapter         (bundled)                   —

Usage
-----
    from axel.adapters import GeminiAdapter, GroqAdapter, LiteLLMAdapter

    # Google Gemini researcher
    researcher = GeminiAdapter("researcher",
                               model="gemini-1.5-flash",
                               capabilities=["research", "summarize"])

    # Groq fast reviewer
    reviewer = GroqAdapter("reviewer",
                           model="llama-3.1-8b-instant",
                           capabilities=["review", "score"])

    # LiteLLM — any model, one adapter
    writer = LiteLLMAdapter("writer",
                            model="groq/llama-3.3-70b-versatile",
                            capabilities=["write", "edit"])

    # Register with the AXEL server bridge
    bridge.add_adapter("researcher", researcher)
    bridge.add_adapter("reviewer",   reviewer)
    bridge.add_adapter("writer",     writer)
"""

# ── Bundled adapters (no extra install) ───────────────────────────
from axel.universal import (
    AnthropicAdapter,
    OpenAIAdapter,
    OllamaAdapter,
    OpenRouterAdapter,
    MockAdapter,
    BaseAdapter,
)

# ── Optional provider adapters ────────────────────────────────────
# All use lazy imports internally — importing these classes is free.
# The provider SDK is only loaded when execute() is first called.

from axel.adapters.gemini   import GeminiAdapter
from axel.adapters.mistral  import MistralAdapter
from axel.adapters.groq     import GroqAdapter
from axel.adapters.together import TogetherAdapter
from axel.adapters.cohere   import CohereAdapter
from axel.adapters.litellm  import LiteLLMAdapter
from axel.adapters.bedrock  import BedrockAdapter

__all__ = [
    # Bundled
    "BaseAdapter",
    "MockAdapter",
    "AnthropicAdapter",
    "OpenAIAdapter",
    "OllamaAdapter",
    "OpenRouterAdapter",
    # Optional
    "GeminiAdapter",
    "MistralAdapter",
    "GroqAdapter",
    "TogetherAdapter",
    "CohereAdapter",
    "LiteLLMAdapter",
    "BedrockAdapter",
]

# ── Provider registry — useful for dynamic instantiation ──────────
PROVIDERS: dict[str, type] = {
    "anthropic": AnthropicAdapter,
    "openai":    OpenAIAdapter,
    "ollama":    OllamaAdapter,
    "google":    GeminiAdapter,
    "gemini":    GeminiAdapter,
    "mistral":   MistralAdapter,
    "groq":      GroqAdapter,
    "together":  TogetherAdapter,
    "cohere":    CohereAdapter,
    "litellm":   LiteLLMAdapter,
    "bedrock":   BedrockAdapter,
    "aws":       BedrockAdapter,
    "openrouter": OpenRouterAdapter,
    "mock":        MockAdapter,
}


def get_adapter(provider: str) -> type:
    """
    Lookup an adapter class by provider name (case-insensitive).

    Example::

        AdapterClass = get_adapter("groq")
        adapter = AdapterClass("my_agent", model="llama-3.1-8b-instant")
    """
    key = provider.lower()
    if key not in PROVIDERS:
        available = ", ".join(sorted(PROVIDERS))
        raise ValueError(
            f"Unknown provider '{provider}'. Available: {available}"
        )
    return PROVIDERS[key]


def make_adapter(
    agent_id: str,
    provider: str,
    model: str,
    capabilities: list[str] | None = None,
    **kwargs,
) -> BaseAdapter:
    """
    Factory: create any adapter by provider name.

    Example::

        adapter = make_adapter("researcher", "groq",
                               "llama-3.3-70b-versatile",
                               capabilities=["research"])
        result  = adapter.execute(task_msg)
    """
    AdapterClass = get_adapter(provider)
    # MockAdapter has a simplified signature
    if AdapterClass is MockAdapter:
        return AdapterClass(agent_id)
    return AdapterClass(agent_id, model=model, capabilities=capabilities, **kwargs)
