"""
axel/adapters/bedrock.py — AWS Bedrock adapter for AXEL

Bedrock gives access to frontier models (Claude, Llama, Mistral, Titan)
inside your AWS VPC — no data leaves your cloud environment.
Ideal for enterprise deployments with strict data residency requirements.

Supported model IDs (as of 2024):
    anthropic.claude-3-5-haiku-20241022-v1:0    Claude 3.5 Haiku
    anthropic.claude-3-5-sonnet-20241022-v2:0   Claude 3.5 Sonnet
    anthropic.claude-3-opus-20240229-v1:0        Claude 3 Opus
    meta.llama3-1-70b-instruct-v1:0              Llama 3.1 70B
    meta.llama3-1-8b-instruct-v1:0               Llama 3.1 8B
    mistral.mistral-large-2402-v1:0              Mistral Large
    amazon.titan-text-premier-v1:0               Amazon Titan

Install:
    pip install boto3

Auth:
    AWS credentials via env vars, ~/.aws/credentials, or IAM role:
    export AWS_ACCESS_KEY_ID=...
    export AWS_SECRET_ACCESS_KEY=...
    export AWS_DEFAULT_REGION=us-east-1

Permissions needed:
    bedrock:InvokeModel on arn:aws:bedrock:*::foundation-model/*
"""

from __future__ import annotations

import json
import os
import re
from typing import List, Optional

from axel.universal import BaseAdapter, make_system_prompt, AXELMessage


class BedrockAdapter(BaseAdapter):
    """
    Execute AXEL TASK messages using AWS Bedrock.

    Bedrock uses the Converse API (unified chat interface across all models),
    so this adapter works consistently regardless of which model is selected.

    Example::

        adapter = BedrockAdapter(
            "secure_researcher",
            model_id="anthropic.claude-3-5-haiku-20241022-v1:0",
            region="us-east-1",
            capabilities=["research", "summarize"],
        )
        result = adapter.execute(task_msg)

    Notes:
        - Model access must be enabled in the Bedrock console for your region
        - Cross-region inference profiles are supported (prefix with region code)
    """

    PROVIDER = "bedrock"
    DEFAULT_MODEL = "anthropic.claude-3-5-haiku-20241022-v1:0"

    def __init__(
        self,
        agent_id: str,
        model_id: str = DEFAULT_MODEL,
        capabilities: Optional[List[str]] = None,
        region: Optional[str] = None,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        aws_session_token: Optional[str] = None,
        max_tokens: int = 2048,
        temperature: float = 0.7,
    ):
        system = make_system_prompt(agent_id, capabilities or [], f"bedrock/{model_id}")
        super().__init__(agent_id, system)
        self.model_id    = model_id
        self.max_tokens  = max_tokens
        self.temperature = temperature
        self._region     = region or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
        self._key_id     = aws_access_key_id
        self._secret     = aws_secret_access_key
        self._token      = aws_session_token
        self._client     = None

    def _get_client(self):
        if self._client is None:
            try:
                import boto3
            except ImportError:
                raise RuntimeError(
                    "boto3 not installed.\n"
                    "Run: pip install boto3"
                )
            session_kwargs = {}
            if self._key_id:
                session_kwargs["aws_access_key_id"]     = self._key_id
            if self._secret:
                session_kwargs["aws_secret_access_key"] = self._secret
            if self._token:
                session_kwargs["aws_session_token"]     = self._token

            session = boto3.Session(**session_kwargs) if session_kwargs else boto3.Session()
            self._client = session.client("bedrock-runtime", region_name=self._region)
        return self._client

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        action = task_msg.body.get("act", "unknown")
        args   = task_msg.body.get("args", {})
        ctx    = task_msg.body.get("ctx", {})

        user_content = (
            f"AXEL TASK:\n{task_msg.to_json(compact=False)}\n\n"
            f"Execute '{action}' with args: {json.dumps(args)}\n"
            f"Context: {json.dumps(ctx)}\n\n"
            f"Respond with a single compact AXEL OK or ER JSON message."
        )

        try:
            client = self._get_client()

            # Bedrock Converse API — unified interface across all models
            resp = client.converse(
                modelId=self.model_id,
                system=[{"text": self.system_prompt}],
                messages=[{"role": "user", "content": [{"text": user_content}]}],
                inferenceConfig={
                    "maxTokens":   self.max_tokens,
                    "temperature": self.temperature,
                },
            )
            raw = resp["output"]["message"]["content"][0]["text"].strip()

            try:
                match = re.search(r"\{.*\}", raw, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    return AXELMessage.from_dict({
                        **parsed,
                        "fr":  self.agent_id,
                        "to":  task_msg.fr,
                        "cid": task_msg.cid,
                        "re":  task_msg.id,
                    })
            except Exception:
                pass

            return self._ok(task_msg, {"text": raw})

        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)
