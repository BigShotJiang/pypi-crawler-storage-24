"""
axel/adapters/gemini.py — Google Gemini adapter for AXEL

Supported models (as of 2024):
    gemini-1.5-flash        fast, cheap, 1M context
    gemini-1.5-pro          flagship, multimodal, 2M context
    gemini-2.0-flash        next-gen fast model

Install:
    pip install google-generativeai

Auth:
    export GOOGLE_API_KEY=your_key
    # OR pass api_key= directly
    # OR use Application Default Credentials (ADC) on GCP/Vertex
"""

from __future__ import annotations

import json
import os
import re
from typing import List, Optional

from axel.universal import BaseAdapter, make_system_prompt, AXELMessage


class GeminiAdapter(BaseAdapter):
    """
    Execute AXEL TASK messages using Google Gemini.

    Example::

        adapter = GeminiAdapter(
            "researcher",
            model="gemini-1.5-flash",
            capabilities=["research", "summarize"],
        )
        result = adapter.execute(task_msg)
    """

    PROVIDER = "google"
    DEFAULT_MODEL = "gemini-1.5-flash"

    def __init__(
        self,
        agent_id: str,
        model: str = DEFAULT_MODEL,
        capabilities: Optional[List[str]] = None,
        api_key: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ):
        system = make_system_prompt(agent_id, capabilities or [], f"gemini/{model}")
        super().__init__(agent_id, system)
        self.model       = model
        self.temperature = temperature
        self.max_tokens  = max_tokens
        self._api_key    = api_key or os.environ.get("GOOGLE_API_KEY")
        self._client     = None

    def _get_client(self):
        if self._client is None:
            try:
                import google.generativeai as genai
            except ImportError:
                raise RuntimeError(
                    "Google Generative AI SDK not installed.\n"
                    "Run: pip install google-generativeai"
                )
            if self._api_key:
                genai.configure(api_key=self._api_key)
            # else relies on GOOGLE_API_KEY env var or ADC
            self._client = genai.GenerativeModel(
                model_name=self.model,
                system_instruction=self.system_prompt,
                generation_config={
                    "temperature":     self.temperature,
                    "max_output_tokens": self.max_tokens,
                },
            )
        return self._client

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        action = task_msg.body.get("act", "unknown")
        args   = task_msg.body.get("args", {})
        ctx    = task_msg.body.get("ctx", {})

        prompt = (
            f"AXEL TASK received:\n"
            f"{task_msg.to_json(compact=False)}\n\n"
            f"Execute action '{action}' with args: {json.dumps(args)}\n"
            f"Context: {json.dumps(ctx)}\n\n"
            f"Respond with a single compact AXEL OK or ER JSON message."
        )

        try:
            model  = self._get_client()
            resp   = model.generate_content(prompt)
            raw    = resp.text.strip()

            try:
                match = re.search(r"\{.*\}", raw, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    return AXELMessage.from_dict({
                        **parsed,
                        "fr":  self.agent_id,
                        "to":  task_msg.fr,
                        "cid": task_msg.cid,
                        "re":  task_msg.id,
                    })
            except Exception:
                pass

            return self._ok(task_msg, {"text": raw})

        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)
