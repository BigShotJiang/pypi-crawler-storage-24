"""
axel/adapters/litellm.py — LiteLLM meta-adapter for AXEL

LiteLLM is a universal LLM proxy that supports 100+ providers under one interface.
If you're not sure which provider to use, start here.

Providers supported via LiteLLM (single install, no extra SDKs):
    claude-3-5-haiku-20241022         Anthropic
    gpt-4o-mini                       OpenAI
    gemini/gemini-1.5-flash           Google
    mistral/mistral-small-latest      Mistral
    groq/llama-3.3-70b-versatile      Groq
    together_ai/llama-3.1-70b         Together AI
    cohere/command-r-plus             Cohere
    ollama/llama3                     Local Ollama
    bedrock/anthropic.claude-3...     AWS Bedrock
    vertex_ai/gemini-pro              GCP Vertex
    huggingface/...                   Hugging Face
    replicate/...                     Replicate
    azure/...                         Azure OpenAI

Install:
    pip install litellm

Auth: set the relevant provider's env var (ANTHROPIC_API_KEY, OPENAI_API_KEY, etc.)

Docs: https://docs.litellm.ai/docs/providers
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional

from axel.universal import BaseAdapter, make_system_prompt, AXELMessage


class LiteLLMAdapter(BaseAdapter):
    """
    Execute AXEL TASK messages using ANY LiteLLM-supported provider.

    This is the "batteries included" adapter — one class, 100+ providers.
    Just change the model string to switch providers.

    Example::

        # Claude via Anthropic
        adapter = LiteLLMAdapter("researcher", model="claude-3-5-haiku-20241022")

        # Llama via Groq (ultra-fast)
        adapter = LiteLLMAdapter("reviewer", model="groq/llama-3.3-70b-versatile")

        # Gemini via Google
        adapter = LiteLLMAdapter("writer", model="gemini/gemini-1.5-flash")

        # Local Ollama (free, private)
        adapter = LiteLLMAdapter("local", model="ollama/llama3")

        # Any of the above as AXEL network agents:
        result = adapter.execute(task_msg)

    Notes:
        - Pass extra_kwargs to forward provider-specific params (e.g. base_url for Ollama)
        - Set LITELLM_LOG=ERROR to silence verbose logging
    """

    PROVIDER = "litellm"
    DEFAULT_MODEL = "gpt-4o-mini"

    def __init__(
        self,
        agent_id: str,
        model: str = DEFAULT_MODEL,
        capabilities: Optional[List[str]] = None,
        api_key: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        extra_kwargs: Optional[Dict[str, Any]] = None,
    ):
        system = make_system_prompt(agent_id, capabilities or [], f"litellm/{model}")
        super().__init__(agent_id, system)
        self.model        = model
        self.temperature  = temperature
        self.max_tokens   = max_tokens
        self.api_key      = api_key
        self.extra_kwargs = extra_kwargs or {}

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        action = task_msg.body.get("act", "unknown")
        args   = task_msg.body.get("args", {})
        ctx    = task_msg.body.get("ctx", {})

        user_content = (
            f"AXEL TASK:\n{task_msg.to_json(compact=False)}\n\n"
            f"Execute '{action}' with args: {json.dumps(args)}\n"
            f"Context: {json.dumps(ctx)}\n\n"
            f"Respond with a single compact AXEL OK or ER JSON message."
        )

        try:
            try:
                import litellm
            except ImportError:
                raise RuntimeError(
                    "LiteLLM not installed.\n"
                    "Run: pip install litellm\n"
                    "Docs: https://docs.litellm.ai"
                )

            # Silence verbose output unless user opted in
            litellm.set_verbose = os.environ.get("LITELLM_VERBOSE", "").lower() == "true"

            call_kwargs: Dict[str, Any] = {
                "model":       self.model,
                "messages": [
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user",   "content": user_content},
                ],
                "temperature": self.temperature,
                "max_tokens":  self.max_tokens,
                **self.extra_kwargs,
            }
            if self.api_key:
                call_kwargs["api_key"] = self.api_key

            resp = litellm.completion(**call_kwargs)
            raw  = resp.choices[0].message.content.strip()

            try:
                match = re.search(r"\{.*\}", raw, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    return AXELMessage.from_dict({
                        **parsed,
                        "fr":  self.agent_id,
                        "to":  task_msg.fr,
                        "cid": task_msg.cid,
                        "re":  task_msg.id,
                    })
            except Exception:
                pass

            return self._ok(task_msg, {"text": raw})

        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)
