"""
axel/adapters/groq.py — Groq adapter for AXEL

Groq runs open-source models at extremely fast inference speeds (hundreds of tokens/s)
using their custom LPU hardware. Perfect for low-latency AXEL tasks.

Supported models (as of 2024):
    llama-3.3-70b-versatile     best quality on Groq
    llama-3.1-8b-instant        fastest, ultra-low latency
    mixtral-8x7b-32768          MoE, long context
    gemma2-9b-it                Google Gemma 2
    llama3-groq-70b-8192-tool-use-preview   tool-use optimised

Install:
    pip install groq

Auth:
    export GROQ_API_KEY=your_key
    # Free tier available at https://console.groq.com
"""

from __future__ import annotations

import json
import os
import re
from typing import List, Optional

from axel.universal import BaseAdapter, make_system_prompt, AXELMessage


class GroqAdapter(BaseAdapter):
    """
    Execute AXEL TASK messages using Groq (extremely fast open-model inference).

    Groq uses an OpenAI-compatible API, so the integration is clean and reliable.

    Example::

        adapter = GroqAdapter(
            "fast_reviewer",
            model="llama-3.1-8b-instant",
            capabilities=["review", "classify", "score"],
        )
        result = adapter.execute(task_msg)
    """

    PROVIDER = "groq"
    DEFAULT_MODEL = "llama-3.3-70b-versatile"

    def __init__(
        self,
        agent_id: str,
        model: str = DEFAULT_MODEL,
        capabilities: Optional[List[str]] = None,
        api_key: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ):
        system = make_system_prompt(agent_id, capabilities or [], f"groq/{model}")
        super().__init__(agent_id, system)
        self.model       = model
        self.temperature = temperature
        self.max_tokens  = max_tokens
        self._api_key    = api_key or os.environ.get("GROQ_API_KEY")
        self._client     = None

    def _get_client(self):
        if self._client is None:
            try:
                from groq import Groq
            except ImportError:
                raise RuntimeError(
                    "Groq SDK not installed.\n"
                    "Run: pip install groq"
                )
            self._client = Groq(api_key=self._api_key)
        return self._client

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        action = task_msg.body.get("act", "unknown")
        args   = task_msg.body.get("args", {})
        ctx    = task_msg.body.get("ctx", {})

        user_content = (
            f"AXEL TASK:\n{task_msg.to_json(compact=False)}\n\n"
            f"Execute '{action}' with args: {json.dumps(args)}\n"
            f"Context: {json.dumps(ctx)}\n\n"
            f"Respond with a single compact AXEL OK or ER JSON message."
        )

        try:
            client = self._get_client()
            resp   = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user",   "content": user_content},
                ],
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            raw = resp.choices[0].message.content.strip()

            try:
                match = re.search(r"\{.*\}", raw, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    return AXELMessage.from_dict({
                        **parsed,
                        "fr":  self.agent_id,
                        "to":  task_msg.fr,
                        "cid": task_msg.cid,
                        "re":  task_msg.id,
                    })
            except Exception:
                pass

            return self._ok(task_msg, {"text": raw})

        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)
