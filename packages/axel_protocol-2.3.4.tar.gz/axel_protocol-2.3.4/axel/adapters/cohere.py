"""
axel/adapters/cohere.py — Cohere adapter for AXEL

Cohere specialises in enterprise NLP: RAG, classification, reranking, and embeddings.
Their Command R+ model is particularly strong for tool-use and multi-step reasoning.

Supported models (as of 2024):
    command-r-plus     best quality, tool-use, 128k context
    command-r          balanced speed/quality, 128k context
    command-light      fast and cheap
    command            production-ready general model

Install:
    pip install cohere

Auth:
    export COHERE_API_KEY=your_key
"""

from __future__ import annotations

import json
import os
import re
from typing import List, Optional

from axel.universal import BaseAdapter, make_system_prompt, AXELMessage


class CohereAdapter(BaseAdapter):
    """
    Execute AXEL TASK messages using Cohere.

    Cohere's Command R+ is excellent for RAG-augmented tasks and tool use,
    making it well-suited for research and retrieval agent roles in a network.

    Example::

        adapter = CohereAdapter(
            "rag_researcher",
            model="command-r-plus",
            capabilities=["research", "rag_query", "rerank"],
        )
        result = adapter.execute(task_msg)
    """

    PROVIDER = "cohere"
    DEFAULT_MODEL = "command-r-plus"

    def __init__(
        self,
        agent_id: str,
        model: str = DEFAULT_MODEL,
        capabilities: Optional[List[str]] = None,
        api_key: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ):
        system = make_system_prompt(agent_id, capabilities or [], f"cohere/{model}")
        super().__init__(agent_id, system)
        self.model       = model
        self.temperature = temperature
        self.max_tokens  = max_tokens
        self._api_key    = api_key or os.environ.get("COHERE_API_KEY")
        self._client     = None

    def _get_client(self):
        if self._client is None:
            try:
                import cohere
            except ImportError:
                raise RuntimeError(
                    "Cohere SDK not installed.\n"
                    "Run: pip install cohere"
                )
            self._client = cohere.ClientV2(api_key=self._api_key)
        return self._client

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        action = task_msg.body.get("act", "unknown")
        args   = task_msg.body.get("args", {})
        ctx    = task_msg.body.get("ctx", {})

        user_content = (
            f"AXEL TASK:\n{task_msg.to_json(compact=False)}\n\n"
            f"Execute '{action}' with args: {json.dumps(args)}\n"
            f"Context: {json.dumps(ctx)}\n\n"
            f"Respond with a single compact AXEL OK or ER JSON message."
        )

        try:
            client = self._get_client()
            resp   = client.chat(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user",   "content": user_content},
                ],
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            raw = resp.message.content[0].text.strip()

            try:
                match = re.search(r"\{.*\}", raw, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    return AXELMessage.from_dict({
                        **parsed,
                        "fr":  self.agent_id,
                        "to":  task_msg.fr,
                        "cid": task_msg.cid,
                        "re":  task_msg.id,
                    })
            except Exception:
                pass

            return self._ok(task_msg, {"text": raw})

        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)
