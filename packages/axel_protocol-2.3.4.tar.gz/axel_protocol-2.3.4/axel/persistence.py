"""
axel/persistence.py — Optional SQLite persistence for AXEL server state.

When enabled (via AXELServer(db="path/to/axel.db") or --db CLI flag),
the server persists:
  - Agent registry (survives restarts)
  - Shared memory / lessons
  - Inbox messages (undelivered)
  - Event log (last N events)

Usage::

    # In Python
    server = AXELServer(host="0.0.0.0", port=7331, db="axel.db")
    server.run()

    # Via CLI
    axel-server --db /var/lib/axel/axel.db

Schema is created automatically on first run. The db file is a single
portable SQLite file — easy to back up, inspect with any SQLite browser,
and move between machines.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


# ──────────────────────────────────────────────────────────────────────────────
# Schema
# ──────────────────────────────────────────────────────────────────────────────

_SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;

CREATE TABLE IF NOT EXISTS agents (
    agent_id    TEXT PRIMARY KEY,
    model       TEXT,
    provider    TEXT,
    caps        TEXT,           -- JSON array
    score       REAL DEFAULT 0,
    tasks_done  INTEGER DEFAULT 0,
    last_seen   INTEGER,        -- unix ms
    announced_at INTEGER,       -- unix ms
    meta        TEXT DEFAULT '{}'  -- JSON
);

CREATE TABLE IF NOT EXISTS memory (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    key         TEXT NOT NULL,
    insight     TEXT NOT NULL,
    source      TEXT,
    confidence  REAL DEFAULT 0.5,
    uses        INTEGER DEFAULT 0,
    created_at  INTEGER,        -- unix ms
    UNIQUE(key, source)
);
CREATE INDEX IF NOT EXISTS idx_memory_key ON memory(key);

CREATE TABLE IF NOT EXISTS inbox (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    recipient   TEXT NOT NULL,
    msg_id      TEXT NOT NULL UNIQUE,
    msg_type    TEXT,
    payload     TEXT NOT NULL,  -- JSON
    created_at  INTEGER,
    delivered   INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_inbox_recipient ON inbox(recipient, delivered);

CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          INTEGER,        -- unix ms
    msg_type    TEXT,
    fr          TEXT,
    to_agent    TEXT,
    payload     TEXT            -- JSON (condensed)
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
"""

_MAX_EVENTS = 10_000   # trim to this many rows periodically


# ──────────────────────────────────────────────────────────────────────────────
# PersistenceLayer
# ──────────────────────────────────────────────────────────────────────────────

class PersistenceLayer:
    """
    Thread-safe SQLite persistence layer for AXEL server state.

    One connection per thread (check_same_thread=False + manual lock).
    """

    def __init__(self, db_path: str):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    # ── setup ─────────────────────────────────────────────────────

    def _init_schema(self):
        with self._lock:
            self._conn.executescript(_SCHEMA)
            self._conn.commit()

    def _now(self) -> int:
        return int(time.time() * 1000)

    # ── agents ────────────────────────────────────────────────────

    def upsert_agent(
        self,
        agent_id: str,
        model: str = "",
        provider: str = "",
        caps: Optional[List[str]] = None,
        score: float = 0.0,
        tasks_done: int = 0,
        meta: Optional[dict] = None,
    ) -> None:
        now = self._now()
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO agents
                    (agent_id, model, provider, caps, score, tasks_done,
                     last_seen, announced_at, meta)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(agent_id) DO UPDATE SET
                    model       = excluded.model,
                    provider    = excluded.provider,
                    caps        = excluded.caps,
                    score       = excluded.score,
                    tasks_done  = excluded.tasks_done,
                    last_seen   = excluded.last_seen,
                    meta        = excluded.meta
                """,
                (
                    agent_id,
                    model,
                    provider,
                    json.dumps(caps or []),
                    score,
                    tasks_done,
                    now,
                    now,
                    json.dumps(meta or {}),
                ),
            )
            self._conn.commit()

    def touch_agent(self, agent_id: str) -> None:
        """Update last_seen for heartbeat / activity."""
        with self._lock:
            self._conn.execute(
                "UPDATE agents SET last_seen = ? WHERE agent_id = ?",
                (self._now(), agent_id),
            )
            self._conn.commit()

    def update_agent_score(self, agent_id: str, score: float, tasks_done: int) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE agents SET score = ?, tasks_done = ?, last_seen = ? WHERE agent_id = ?",
                (score, tasks_done, self._now(), agent_id),
            )
            self._conn.commit()

    def list_agents(self) -> List[Dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM agents ORDER BY score DESC"
            ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["caps"] = json.loads(d.get("caps") or "[]")
            d["meta"] = json.loads(d.get("meta") or "{}")
            result.append(d)
        return result

    def get_agent(self, agent_id: str) -> Optional[Dict]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM agents WHERE agent_id = ?", (agent_id,)
            ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["caps"] = json.loads(d.get("caps") or "[]")
        d["meta"] = json.loads(d.get("meta") or "{}")
        return d

    def remove_agent(self, agent_id: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM agents WHERE agent_id = ?", (agent_id,))
            self._conn.commit()

    # ── memory / lessons ─────────────────────────────────────────

    def write_lesson(
        self,
        key: str,
        insight: str,
        source: str = "",
        confidence: float = 0.5,
    ) -> None:
        now = self._now()
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO memory (key, insight, source, confidence, uses, created_at)
                VALUES (?, ?, ?, ?, 0, ?)
                ON CONFLICT(key, source) DO UPDATE SET
                    insight    = excluded.insight,
                    confidence = excluded.confidence,
                    uses       = uses + 1
                """,
                (key, insight, source, confidence, now),
            )
            self._conn.commit()

    def search_lessons(
        self,
        query: str,
        n: int = 10,
        min_confidence: float = 0.0,
    ) -> List[Dict]:
        q = f"%{query.lower()}%"
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT * FROM memory
                WHERE (LOWER(key) LIKE ? OR LOWER(insight) LIKE ?)
                  AND confidence >= ?
                ORDER BY confidence DESC, uses DESC
                LIMIT ?
                """,
                (q, q, min_confidence, n),
            ).fetchall()
        return [dict(r) for r in rows]

    def list_lessons(self, top: int = 50) -> List[Dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM memory ORDER BY confidence DESC, uses DESC LIMIT ?",
                (top,),
            ).fetchall()
        return [dict(r) for r in rows]

    # ── inbox ─────────────────────────────────────────────────────

    def enqueue_message(self, recipient: str, msg: Dict) -> None:
        now = self._now()
        with self._lock:
            self._conn.execute(
                """
                INSERT OR IGNORE INTO inbox
                    (recipient, msg_id, msg_type, payload, created_at, delivered)
                VALUES (?, ?, ?, ?, ?, 0)
                """,
                (
                    recipient,
                    msg.get("id", f"msg_{now}"),
                    msg.get("t", ""),
                    json.dumps(msg),
                    now,
                ),
            )
            self._conn.commit()

    def peek_inbox(self, recipient: str, limit: int = 100) -> List[Dict]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT payload FROM inbox
                WHERE recipient = ? AND delivered = 0
                ORDER BY created_at ASC
                LIMIT ?
                """,
                (recipient, limit),
            ).fetchall()
        return [json.loads(r["payload"]) for r in rows]

    def mark_delivered(self, recipient: str, msg_ids: List[str]) -> None:
        if not msg_ids:
            return
        placeholders = ",".join("?" * len(msg_ids))
        with self._lock:
            self._conn.execute(
                f"UPDATE inbox SET delivered = 1 WHERE recipient = ? AND msg_id IN ({placeholders})",
                [recipient] + msg_ids,
            )
            self._conn.commit()

    def clear_inbox(self, recipient: str) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE inbox SET delivered = 1 WHERE recipient = ?",
                (recipient,),
            )
            self._conn.commit()

    # ── event log ─────────────────────────────────────────────────

    def log_event(self, msg: Dict) -> None:
        now = self._now()
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO events (ts, msg_type, fr, to_agent, payload)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    now,
                    msg.get("t", ""),
                    msg.get("fr", ""),
                    msg.get("to", ""),
                    json.dumps({k: msg[k] for k in ("t", "id", "fr", "to", "body") if k in msg}),
                ),
            )
            self._conn.commit()
        self._trim_events()

    def _trim_events(self):
        with self._lock:
            count = self._conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            if count > _MAX_EVENTS * 1.2:
                self._conn.execute(
                    f"DELETE FROM events WHERE id NOT IN "
                    f"(SELECT id FROM events ORDER BY id DESC LIMIT {_MAX_EVENTS})"
                )
                self._conn.commit()

    def recent_events(self, n: int = 200) -> List[Dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM events ORDER BY id DESC LIMIT ?", (n,)
            ).fetchall()
        return [dict(r) for r in reversed(rows)]

    # ── housekeeping ─────────────────────────────────────────────

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except Exception:
                pass

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            agents  = self._conn.execute("SELECT COUNT(*) FROM agents").fetchone()[0]
            lessons = self._conn.execute("SELECT COUNT(*) FROM memory").fetchone()[0]
            inbox   = self._conn.execute(
                "SELECT COUNT(*) FROM inbox WHERE delivered = 0"
            ).fetchone()[0]
            events  = self._conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        return {
            "db": str(self.db_path),
            "agents": agents,
            "lessons": lessons,
            "inbox_pending": inbox,
            "events": events,
        }
