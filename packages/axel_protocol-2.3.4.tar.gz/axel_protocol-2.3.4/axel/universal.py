"""
AXEL Universal — axel_universal.py
Cross-LLM Agent Network: any model, any provider, one protocol.

What this adds over axel.py + axel_learning.py:

  1. AXEL v2 message types  — ANNOUNCE, CAPABILITY, SPAWN, SUBSCRIBE, PUBLISH, CHAIN
  2. AXELRegistry           — agents advertise capabilities; orchestrators auto-discover
  3. AXELBridge             — routes TK messages to real LLM APIs (Anthropic, OpenAI, Ollama)
  4. SmartMemory            — confidence decay, quality scoring, BM25 search, lesson merging
  5. AXEL_SYSTEM_PROMPT     — inject into any LLM to make it speak AXEL natively
  6. AXELNetwork            — high-level class tying everything together

Vision:
  Claude, GPT-4, Gemini, and Llama all join the same AXEL network.
  They ANNOUNCE capabilities, route tasks to the best agent, share lessons
  via broadcast, and collectively get smarter — across models, providers,
  and sessions.

Usage:
    from axel_universal import AXELNetwork, AXELRegistry, AXELBridge, SmartMemory

    net = AXELNetwork.load()          # loads ~/.axel/ state
    net.announce("my_agent", capabilities=["summarize","translate"], model="claude-3-5-sonnet")

    # Find best agent for a task
    agent = net.registry.best_for("summarize")

    # Execute via real API (if adapters configured)
    result = net.bridge.execute(task_msg)

    # Query collective memory
    hints = net.memory.search("summarize")
"""

import json
import math
import os
import re
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# Core AXEL primitives
from axel.core import AXELMessage, AXELBuilder, AXELParser, Priority, _new_id, _now_ms
from axel.learning import AXELMemory, Lesson, build_lesson, build_feedback

AXEL_HOME = Path.home() / ".axel"


# ─────────────────────────────────────────────────────────────────────────────
# V2 Message Types
# ─────────────────────────────────────────────────────────────────────────────

class MsgTypeV2(str, Enum):
    """AXEL v2 additions on top of v1 types."""
    ANNOUNCE    = "AN"   # Agent comes online, broadcasts capabilities
    CAPABILITY  = "CP"   # Detailed single-capability advertisement
    SPAWN       = "SP"   # Request creation of a new agent instance
    SUBSCRIBE   = "SB"   # Subscribe to an event channel
    PUBLISH     = "PB"   # Publish event to channel subscribers
    CHAIN       = "CH"   # Define a sequential multi-agent pipeline


# Extend the parser to recognise v2 types
try:
    AXELParser.VALID_TYPES = AXELParser.VALID_TYPES | frozenset(t.value for t in MsgTypeV2)
except Exception:
    pass


# ─────────────────────────────────────────────────────────────────────────────
# AXEL System Prompt — inject into any LLM to make it speak AXEL
# ─────────────────────────────────────────────────────────────────────────────

def make_system_prompt(agent_id: str, capabilities: List[str], model: str = "unknown") -> str:
    """
    Generate the AXEL system prompt for any LLM agent.

    Injecting this prompt into a Claude, GPT-4, Gemini, or local model
    makes it a fully protocol-compliant AXEL participant.
    """
    caps_str = ", ".join(capabilities) if capabilities else "general purpose"
    return f"""You are an AXEL protocol agent participating in a cross-LLM network.

AXEL (Agent eXchange Language) is a compact JSON protocol for structured agent communication.
Your agent ID: {agent_id}
Your model:    {model}
Your capabilities: {caps_str}

## Message Format
Every message you send must be a valid AXEL JSON envelope:
{{"v":"2","id":"msg_<12hex>","cid":"<same_cid>","t":"<TYPE>","fr":"{agent_id}","to":"<target>","ts":<unix_ms>,"body":{{...}}}}

## Your Response Protocol

When you receive a TASK (TK) message:
1. Read the "act" and "args" fields in the body.
2. Check "ctx" for shared context and "deps" for dependency results.
3. Execute the requested action using your capabilities.
4. Respond with ONE of:
   - SUCCESS: {{"t":"OK","body":{{"result":<your_output>}}}}
   - FAILURE: {{"t":"ER","body":{{"code":"INTERNAL","msg":"<reason>","retry":false}}}}
5. After success, broadcast a lesson if you learned something:
   {{"t":"LS","to":"*","body":{{"key":"<action>","insight":"<what worked>","confidence":0.9}}}}

## Key Rules
- Preserve the "cid" from the incoming message in ALL your replies.
- Set "re" to the incoming message's "id" in your OK/ER response.
- Never invent agent IDs — only address agents you have seen in the conversation.
- Use compact JSON (no extra whitespace) for all wire-format output.
- Priority 3 (HIGH) unless you have reason to change it.

## Type Codes
TK=task  OK=done  ER=error  ST=status  QR=query  RP=reply
HO=handoff  NG=negotiate  LS=lesson  FB=feedback  BR=broadcast
AN=announce  SP=spawn  SB=subscribe  PB=publish  CH=chain

You are now online as agent "{agent_id}". Announce yourself when this session starts.
"""


# ─────────────────────────────────────────────────────────────────────────────
# Agent Registry
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AgentRecord:
    """A registered agent in the AXEL network."""
    agent_id:     str
    model:        str                    # e.g. "claude-3-5-sonnet", "gpt-4o", "llama3"
    provider:     str                    # "anthropic"|"openai"|"google"|"ollama"|"custom"
    endpoint:     Optional[str]          # API endpoint (None = use provider default)
    capabilities: List[str]             # list of actions this agent can handle
    tags:         List[str] = field(default_factory=list)
    status:       str = "online"         # "online"|"offline"|"busy"
    avg_score:    float = 3.0            # running performance score
    tasks_done:   int = 0
    last_seen:    int = field(default_factory=_now_ms)
    metadata:     Dict = field(default_factory=dict)

    def matches(self, action: str) -> bool:
        al = action.lower()
        return any(al in c.lower() or c.lower() in al for c in self.capabilities)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "AgentRecord":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class AXELRegistry:
    """
    Agent registry — agents announce capabilities, orchestrators discover them.

    Persists to ~/.axel/registry.json so registrations survive sessions.

    Example:
        registry = AXELRegistry()
        registry.register("claude_researcher", model="claude-3-5-sonnet",
                          provider="anthropic", capabilities=["research","summarize"])

        best = registry.best_for("summarize")
        print(best.agent_id, best.avg_score)

        # Auto-route: find the best available agent for an action
        agent_id = registry.route("extract_entities")
    """

    REGISTRY_FILE = AXEL_HOME / "registry.json"

    def __init__(self):
        self._agents: Dict[str, AgentRecord] = {}
        self._lock   = threading.Lock()
        self._load()

    # ------------------------------------------------------------------
    # Register / update
    # ------------------------------------------------------------------

    def register(
        self,
        agent_id: str,
        model: str,
        provider: str,
        capabilities: List[str],
        endpoint: Optional[str] = None,
        tags: List[str] = None,
        metadata: Dict = None,
    ) -> AgentRecord:
        """Register or update an agent. Returns the AgentRecord."""
        record = AgentRecord(
            agent_id=agent_id, model=model, provider=provider,
            endpoint=endpoint, capabilities=capabilities,
            tags=tags or [], metadata=metadata or {},
        )
        with self._lock:
            self._agents[agent_id] = record
        self._save()
        return record

    def update_score(self, agent_id: str, new_score: float, blend: float = 0.2) -> None:
        """Blend a new score into an agent's running average."""
        with self._lock:
            if agent_id in self._agents:
                a = self._agents[agent_id]
                a.avg_score = a.avg_score * (1 - blend) + new_score * blend
                a.tasks_done += 1
                a.last_seen  = _now_ms()
        self._save()

    def set_status(self, agent_id: str, status: str) -> None:
        with self._lock:
            if agent_id in self._agents:
                self._agents[agent_id].status = status
                self._agents[agent_id].last_seen = _now_ms()
        self._save()

    def unregister(self, agent_id: str) -> None:
        with self._lock:
            self._agents.pop(agent_id, None)
        self._save()

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def find(self, action: str) -> List[AgentRecord]:
        """
        Find all online agents that claim the given capability.
        Sorted by avg_score descending.
        """
        with self._lock:
            matches = [a for a in self._agents.values()
                       if a.status == "online" and a.matches(action)]
        matches.sort(key=lambda a: a.avg_score, reverse=True)
        return matches

    def best_for(self, action: str) -> Optional[AgentRecord]:
        """Return the single highest-scoring online agent for an action."""
        results = self.find(action)
        return results[0] if results else None

    def route(self, action: str) -> Optional[str]:
        """Return the agent_id to route `action` to, or None if no match."""
        best = self.best_for(action)
        return best.agent_id if best else None

    def all_agents(self) -> List[AgentRecord]:
        with self._lock:
            return list(self._agents.values())

    def get(self, agent_id: str) -> Optional[AgentRecord]:
        with self._lock:
            return self._agents.get(agent_id)

    # ------------------------------------------------------------------
    # ANNOUNCE message processing
    # ------------------------------------------------------------------

    def process_announce(self, msg: AXELMessage) -> AgentRecord:
        """
        Process an ANNOUNCE (AN) message and update the registry.
        This is how LLM agents self-register when they come online.
        """
        b = msg.body
        return self.register(
            agent_id=msg.fr,
            model=b.get("model", "unknown"),
            provider=b.get("provider", "unknown"),
            capabilities=b.get("capabilities", []),
            endpoint=b.get("endpoint"),
            tags=b.get("tags", []),
            metadata=b.get("metadata", {}),
        )

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def _save(self) -> None:
        AXEL_HOME.mkdir(parents=True, exist_ok=True)
        with self._lock:
            data = {k: v.to_dict() for k, v in self._agents.items()}
        self.REGISTRY_FILE.write_text(json.dumps(data, indent=2))

    def _load(self) -> None:
        if not self.REGISTRY_FILE.exists():
            return
        try:
            data = json.loads(self.REGISTRY_FILE.read_text())
            with self._lock:
                self._agents = {k: AgentRecord.from_dict(v) for k, v in data.items()}
        except Exception:
            pass

    def leaderboard(self) -> List[dict]:
        agents = self.all_agents()
        agents.sort(key=lambda a: a.avg_score, reverse=True)
        return [{"rank": i+1, "agent": a.agent_id, "model": a.model,
                 "score": round(a.avg_score, 2), "tasks": a.tasks_done,
                 "capabilities": a.capabilities, "status": a.status}
                for i, a in enumerate(agents)]

    def __len__(self) -> int:
        with self._lock:
            return len(self._agents)

    def __repr__(self) -> str:
        return f"AXELRegistry({len(self)} agents)"


# ─────────────────────────────────────────────────────────────────────────────
# Smart Memory (upgrade to AXELMemory)
# ─────────────────────────────────────────────────────────────────────────────

class SmartMemory(AXELMemory):
    """
    Upgraded shared memory with:
    - Confidence decay (old lessons slowly lose relevance)
    - BM25-style search (better than substring matching)
    - Lesson quality scoring (how much did this lesson actually help?)
    - Near-duplicate merging
    - Cross-model attribution (tracks which model produced each lesson)

    Drop-in replacement for AXELMemory.
    """

    MEMORY_FILE = AXEL_HOME / "memory.json"
    DECAY_RATE  = 0.005   # confidence loss per day of inactivity

    def __init__(self, max_per_key: int = 20):
        super().__init__(max_per_key=max_per_key)
        self._load_from_disk()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def write(self, lesson: Lesson) -> None:
        super().write(lesson)
        self._save_to_disk()

    def _save_to_disk(self) -> None:
        AXEL_HOME.mkdir(parents=True, exist_ok=True)
        with self._lock:
            data = {"lessons": [l.to_dict() for bucket in self._store.values() for l in bucket]}
        self.MEMORY_FILE.write_text(json.dumps(data, indent=2))

    def _load_from_disk(self) -> None:
        if not self.MEMORY_FILE.exists():
            return
        try:
            data = json.loads(self.MEMORY_FILE.read_text())
            for entry in data.get("lessons", []):
                try:
                    lesson = Lesson.from_dict(entry)
                    # Bypass the parent write to avoid re-saving on load
                    with self._lock:
                        bucket = self._store.setdefault(lesson.key, [])
                        if not any(l.insight == lesson.insight for l in bucket):
                            bucket.append(lesson)
                except Exception:
                    pass
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Confidence decay
    # ------------------------------------------------------------------

    def apply_decay(self) -> int:
        """
        Reduce confidence of lessons that haven't been used recently.
        Returns the number of lessons that had decay applied.

        Call this periodically (e.g. once per session start) to keep
        the memory store fresh and relevant.
        """
        now_days = _now_ms() / (1000 * 86400)
        decayed = 0
        with self._lock:
            for bucket in self._store.values():
                for lesson in bucket:
                    age_days = now_days - lesson.ts / (1000 * 86400)
                    if age_days > 1 and lesson.uses == 0:
                        drop = self.DECAY_RATE * age_days
                        lesson.confidence = max(0.1, lesson.confidence - drop)
                        decayed += 1
        if decayed:
            self._save_to_disk()
        return decayed

    def prune_stale(self, min_confidence: float = 0.2) -> int:
        """Remove lessons below a confidence threshold. Returns count removed."""
        removed = 0
        with self._lock:
            for key in list(self._store.keys()):
                before = len(self._store[key])
                self._store[key] = [l for l in self._store[key]
                                     if l.confidence >= min_confidence]
                removed += before - len(self._store[key])
                if not self._store[key]:
                    del self._store[key]
        if removed:
            self._save_to_disk()
        return removed

    # ------------------------------------------------------------------
    # BM25-style search
    # ------------------------------------------------------------------

    def search(self, query: str, n: int = 5) -> List[Tuple[Lesson, float]]:
        """
        BM25-inspired text search across all lessons.

        Returns list of (lesson, relevance_score) sorted by relevance desc.
        Better than substring matching for multi-word queries.
        """
        tokens = re.findall(r'\w+', query.lower())
        if not tokens:
            return []

        results: List[Tuple[Lesson, float]] = []
        all_lessons = self.all_lessons()
        total_docs  = len(all_lessons) or 1
        k1, b = 1.5, 0.75

        # Compute average document length
        avg_dl = sum(len(re.findall(r'\w+', l.insight + ' ' + l.key))
                     for l in all_lessons) / total_docs

        for lesson in all_lessons:
            doc_tokens = re.findall(r'\w+', (lesson.insight + ' ' + lesson.key).lower())
            dl = len(doc_tokens) or 1
            score = 0.0

            for token in tokens:
                tf   = doc_tokens.count(token)
                # Document frequency (how many lessons contain this token)
                df   = sum(1 for l in all_lessons
                           if token in re.findall(r'\w+', (l.insight+' '+l.key).lower()))
                idf  = math.log((total_docs - df + 0.5) / (df + 0.5) + 1)
                norm = tf * (k1 + 1) / (tf + k1 * (1 - b + b * dl / avg_dl))
                score += idf * norm

            # Boost by confidence and usage
            score *= (0.5 + lesson.confidence * 0.5) * (1 + lesson.uses * 0.1)

            if score > 0:
                results.append((lesson, round(score, 4)))

        results.sort(key=lambda x: x[1], reverse=True)
        return results[:n]

    def search_lessons(self, query: str, n: int = 5) -> List[Lesson]:
        """Like search() but returns just the Lesson objects."""
        return [lesson for lesson, _ in self.search(query, n)]

    # ------------------------------------------------------------------
    # Lesson quality feedback
    # ------------------------------------------------------------------

    def record_outcome(self, key: str, insight: str, helped: bool) -> None:
        """
        Record whether a lesson actually helped in practice.
        Increases or decreases confidence based on real outcomes.
        """
        delta = 0.05 if helped else -0.08
        with self._lock:
            for lesson in self._store.get(key, []):
                if lesson.insight == insight:
                    lesson.confidence = max(0.0, min(1.0, lesson.confidence + delta))
                    lesson.uses += 1
                    break
        self._save_to_disk()

    # ------------------------------------------------------------------
    # Near-duplicate merging
    # ------------------------------------------------------------------

    def merge_similar(self, similarity_threshold: float = 0.7) -> int:
        """
        Merge lessons that are very similar (overlap > threshold).
        Keeps the higher-confidence version. Returns number of merges.
        """
        def token_overlap(a: str, b: str) -> float:
            ta = set(re.findall(r'\w+', a.lower()))
            tb = set(re.findall(r'\w+', b.lower()))
            if not ta or not tb:
                return 0.0
            return len(ta & tb) / len(ta | tb)

        merged = 0
        with self._lock:
            for key, bucket in list(self._store.items()):
                to_remove = set()
                for i, a in enumerate(bucket):
                    if i in to_remove:
                        continue
                    for j, b in enumerate(bucket):
                        if j <= i or j in to_remove:
                            continue
                        if token_overlap(a.insight, b.insight) >= similarity_threshold:
                            # Keep the higher-confidence one
                            keep, drop = (i, j) if a.confidence >= b.confidence else (j, i)
                            # Merge uses and boost confidence of winner
                            bucket[keep].uses       += bucket[drop].uses
                            bucket[keep].confidence  = min(1.0, bucket[keep].confidence + 0.02)
                            to_remove.add(drop)
                            merged += 1
                self._store[key] = [l for k, l in enumerate(bucket) if k not in to_remove]
        if merged:
            self._save_to_disk()
        return merged

    def stats(self) -> dict:
        base = super().stats()
        # Add model attribution breakdown
        with self._lock:
            flat = [l for bucket in self._store.values() for l in bucket]
        sources: Dict[str, int] = {}
        for l in flat:
            sources[l.source] = sources.get(l.source, 0) + 1
        base["by_source"]      = sources
        base["avg_uses"]       = round(sum(l.uses for l in flat)/len(flat), 2) if flat else 0
        base["high_conf_count"]= sum(1 for l in flat if l.confidence > 0.8)
        return base


# ─────────────────────────────────────────────────────────────────────────────
# LLM Adapters (pluggable)
# ─────────────────────────────────────────────────────────────────────────────

class BaseAdapter:
    """Base class for LLM adapters. Subclass and implement execute()."""

    def __init__(self, agent_id: str, system_prompt: str = ""):
        self.agent_id     = agent_id
        self.system_prompt = system_prompt

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        raise NotImplementedError

    def _ok(self, task_msg: AXELMessage, result: Any) -> AXELMessage:
        return AXELMessage(
            t="OK", fr=self.agent_id, to=task_msg.fr,
            body={"result": result}, cid=task_msg.cid, re=task_msg.id
        )

    def _err(self, task_msg: AXELMessage, code: str, msg: str, retry: bool = False) -> AXELMessage:
        return AXELMessage(
            t="ER", fr=self.agent_id, to=task_msg.fr,
            body={"code": code, "msg": msg, "retry": retry},
            cid=task_msg.cid, re=task_msg.id
        )


class AnthropicAdapter(BaseAdapter):
    """
    Execute TASK messages using Anthropic Claude.

    Requires: pip install anthropic
    Requires: ANTHROPIC_API_KEY environment variable

    The adapter injects the AXEL system prompt so Claude becomes
    a fully protocol-compliant network participant.
    """

    PROVIDER      = "anthropic"
    DEFAULT_MODEL = "claude-3-5-haiku-20241022"

    def __init__(self, agent_id: str, model: str = "claude-3-5-haiku-20241022",
                 capabilities: List[str] = None):
        system = make_system_prompt(agent_id, capabilities or [], model)
        super().__init__(agent_id, system)
        self.model = model
        self._client = None

    def _get_client(self):
        if not self._client:
            try:
                import anthropic
                self._client = anthropic.Anthropic()
            except ImportError:
                raise RuntimeError("Install anthropic: pip install anthropic")
        return self._client

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        """Send the TASK to Claude and return an OK or ER message."""
        action = task_msg.body.get("act", "")
        args   = task_msg.body.get("args", {})
        ctx    = task_msg.body.get("ctx", {})

        user_content = (
            f"AXEL TASK received:\n"
            f"{task_msg.to_json(compact=False)}\n\n"
            f"Execute action '{action}' with args: {json.dumps(args)}\n"
            f"Context: {json.dumps(ctx)}\n\n"
            f"Respond with a single compact AXEL OK or ER JSON message."
        )

        try:
            client = self._get_client()
            response = client.messages.create(
                model=self.model,
                max_tokens=2048,
                system=self.system_prompt,
                messages=[{"role": "user", "content": user_content}]
            )
            raw = response.content[0].text.strip()

            # Try to parse AXEL response from the LLM output
            try:
                # Find the JSON object in the response
                match = re.search(r'\{.*\}', raw, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    return AXELMessage.from_dict({
                        **parsed,
                        "fr": self.agent_id,
                        "to": task_msg.fr,
                        "cid": task_msg.cid,
                        "re": task_msg.id,
                    })
            except Exception:
                pass

            # Fallback: wrap raw response in OK
            return self._ok(task_msg, {"text": raw})

        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)


class OpenAIAdapter(BaseAdapter):
    """
    Execute TASK messages using OpenAI GPT.

    Requires: pip install openai
    Requires: OPENAI_API_KEY environment variable
    """

    PROVIDER      = "openai"
    DEFAULT_MODEL = "gpt-4o-mini"

    def __init__(self, agent_id: str, model: str = "gpt-4o-mini",
                 capabilities: List[str] = None):
        system = make_system_prompt(agent_id, capabilities or [], model)
        super().__init__(agent_id, system)
        self.model = model
        self._client = None

    def _get_client(self):
        if not self._client:
            try:
                from openai import OpenAI
                self._client = OpenAI()
            except ImportError:
                raise RuntimeError("Install openai: pip install openai")
        return self._client

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        action = task_msg.body.get("act", "")
        args   = task_msg.body.get("args", {})

        user_content = (
            f"AXEL TASK:\n{task_msg.to_json(compact=False)}\n\n"
            f"Execute '{action}' with {json.dumps(args)}. "
            f"Respond with a compact AXEL OK or ER JSON."
        )

        try:
            client = self._get_client()
            resp = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user",   "content": user_content},
                ]
            )
            raw = resp.choices[0].message.content.strip()
            try:
                match = re.search(r'\{.*\}', raw, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    return AXELMessage.from_dict({
                        **parsed, "fr": self.agent_id,
                        "to": task_msg.fr, "cid": task_msg.cid, "re": task_msg.id
                    })
            except Exception:
                pass
            return self._ok(task_msg, {"text": raw})
        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)


class OllamaAdapter(BaseAdapter):
    """
    Execute TASK messages using a local Ollama model.

    Requires: Ollama running at http://localhost:11434
    No API key needed — fully local and free.
    """

    PROVIDER      = "ollama"
    DEFAULT_MODEL = "llama3"

    def __init__(self, agent_id: str, model: str = "llama3",
                 host: str = "http://localhost:11434",
                 capabilities: List[str] = None):
        system = make_system_prompt(agent_id, capabilities or [], f"ollama/{model}")
        super().__init__(agent_id, system)
        self.model = model
        self.host  = host.rstrip("/")

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        try:
            import urllib.request
            action = task_msg.body.get("act", "")
            args   = task_msg.body.get("args", {})
            prompt = (
                f"{self.system_prompt}\n\n"
                f"AXEL TASK:\n{task_msg.to_json(compact=False)}\n\n"
                f"Execute '{action}' with {json.dumps(args)}. "
                f"Reply with compact AXEL OK or ER JSON only."
            )
            payload = json.dumps({
                "model": self.model, "prompt": prompt, "stream": False
            }).encode()
            req = urllib.request.Request(
                f"{self.host}/api/generate",
                data=payload,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                data  = json.loads(resp.read())
                raw   = data.get("response", "").strip()
                try:
                    match = re.search(r'\{.*\}', raw, re.DOTALL)
                    if match:
                        parsed = json.loads(match.group())
                        return AXELMessage.from_dict({
                            **parsed, "fr": self.agent_id,
                            "to": task_msg.fr, "cid": task_msg.cid, "re": task_msg.id
                        })
                except Exception:
                    pass
                return self._ok(task_msg, {"text": raw})
        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)


class OpenRouterAdapter(BaseAdapter):
    """
    Execute TASK messages using ANY model via OpenRouter.

    One API key → 100+ models (GPT-4o, Claude, Gemini, Llama, Mistral, …)
    Sign up at https://openrouter.ai — free tier available, no credit card.

    Requires: pip install openai         (uses the OpenAI-compatible SDK)
    Requires: OPENROUTER_API_KEY env var  (or pass key= directly)

    Quick-start:
        from axel import OpenRouterAdapter, AXELBridge
        bridge = AXELBridge()
        bridge.add_openrouter("researcher", capabilities=["research"],
                              model="meta-llama/llama-3.1-8b-instruct:free")

    Popular free models (no billing required):
        "meta-llama/llama-3.1-8b-instruct:free"
        "google/gemma-2-9b-it:free"
        "mistralai/mistral-7b-instruct:free"

    Model shortcuts (pass as model=):
        "llama-free"     → meta-llama/llama-3.1-8b-instruct:free
        "gemma-free"     → google/gemma-2-9b-it:free
        "mistral-free"   → mistralai/mistral-7b-instruct:free
        "gpt-4o-mini"    → openai/gpt-4o-mini
        "gpt-4o"         → openai/gpt-4o
        "claude-haiku"   → anthropic/claude-3-haiku
        "claude-sonnet"  → anthropic/claude-3-5-sonnet
        "gemini-flash"   → google/gemini-flash-1.5
        "llama-70b"      → meta-llama/llama-3.1-70b-instruct
        "mistral-large"  → mistralai/mistral-large
    """

    PROVIDER      = "openrouter"
    DEFAULT_MODEL = "meta-llama/llama-3.1-8b-instruct:free"
    BASE_URL      = "https://openrouter.ai/api/v1"

    # Friendly shortcuts → full OpenRouter model IDs
    SHORTCUTS: Dict[str, str] = {
        "llama-free":    "meta-llama/llama-3.1-8b-instruct:free",
        "gemma-free":    "google/gemma-2-9b-it:free",
        "mistral-free":  "mistralai/mistral-7b-instruct:free",
        "gpt-4o-mini":   "openai/gpt-4o-mini",
        "gpt-4o":        "openai/gpt-4o",
        "claude-haiku":  "anthropic/claude-3-haiku",
        "claude-sonnet": "anthropic/claude-3-5-sonnet",
        "gemini-flash":  "google/gemini-flash-1.5",
        "gemini-pro":    "google/gemini-pro-1.5",
        "llama-70b":     "meta-llama/llama-3.1-70b-instruct",
        "mistral-large": "mistralai/mistral-large",
    }

    def __init__(self, agent_id: str,
                 model: str = "meta-llama/llama-3.1-8b-instruct:free",
                 capabilities: List[str] = None,
                 key: Optional[str] = None):
        resolved = self.SHORTCUTS.get(model, model)
        system   = make_system_prompt(agent_id, capabilities or [], resolved)
        super().__init__(agent_id, system)
        self.model    = resolved
        self._key     = key or os.environ.get("OPENROUTER_API_KEY") or None
        self._client  = None

    def _get_client(self):
        if not self._client:
            try:
                from openai import OpenAI
            except ImportError:
                raise RuntimeError(
                    "OpenRouter requires the openai package: pip install openai"
                )
            if not self._key:
                raise RuntimeError(
                    "Set OPENROUTER_API_KEY (get a free key at https://openrouter.ai)"
                )
            self._client = OpenAI(
                base_url=self.BASE_URL,
                api_key=self._key,
                default_headers={
                    "HTTP-Referer": "https://github.com/axel-protocol/axel",
                    "X-Title":      "AXEL Multi-Agent Framework",
                },
            )
        return self._client

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        action = task_msg.body.get("act", "")
        args   = task_msg.body.get("args", {})
        user_content = (
            f"AXEL TASK:\n{task_msg.to_json(compact=False)}\n\n"
            f"Execute '{action}' with {json.dumps(args)}. "
            f"Respond with a compact AXEL OK or ER JSON."
        )
        try:
            client = self._get_client()
            resp   = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user",   "content": user_content},
                ],
            )
            raw = resp.choices[0].message.content.strip()
            try:
                match = re.search(r'\{.*\}', raw, re.DOTALL)
                if match:
                    parsed = json.loads(match.group())
                    return AXELMessage.from_dict({
                        **parsed, "fr": self.agent_id,
                        "to": task_msg.fr, "cid": task_msg.cid, "re": task_msg.id
                    })
            except Exception:
                pass
            return self._ok(task_msg, {"text": raw})
        except Exception as exc:
            return self._err(task_msg, "INTERNAL", str(exc), retry=True)

    @classmethod
    def list_models(cls, key: Optional[str] = None,
                    free_only: bool = False) -> List[Dict]:
        """
        Fetch all models available on OpenRouter.

        Args:
            key:       API key (falls back to OPENROUTER_API_KEY env var)
            free_only: If True, only return models with no per-token cost.

        Returns list of dicts with: id, name, context_length, pricing
        """
        import urllib.request as _req
        api_key = key or os.environ.get("OPENROUTER_API_KEY") or ""
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        request = _req.Request(
            f"{cls.BASE_URL}/models",
            headers={**headers, "Content-Type": "application/json"},
        )
        with _req.urlopen(request, timeout=10) as resp:
            data   = json.loads(resp.read())
        models = data.get("data", [])
        if free_only:
            models = [
                m for m in models
                if m.get("pricing", {}).get("prompt") in ("0", 0, "0.0", 0.0)
            ]
        return [
            {
                "id":             m.get("id", ""),
                "name":           m.get("name", ""),
                "context_length": m.get("context_length", 0),
                "pricing":        m.get("pricing", {}),
            }
            for m in models
        ]


class MockAdapter(BaseAdapter):
    """
    Fake adapter for testing — returns a canned OK response.
    Useful for unit tests and demos without real API keys.
    """

    PROVIDER      = "mock"
    DEFAULT_MODEL = "mock-model"

    def __init__(self, agent_id: str, response_fn: Callable = None):
        super().__init__(agent_id)
        self._fn = response_fn or (lambda msg: {"mock": True, "action": msg.body.get("act")})

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        result = self._fn(task_msg)
        return self._ok(task_msg, result)


# ─────────────────────────────────────────────────────────────────────────────
# AXEL Bridge — routes tasks to real LLM agents
# ─────────────────────────────────────────────────────────────────────────────

class AXELBridge:
    """
    Routes TK messages to the appropriate LLM adapter.
    Integrates with AXELRegistry for automatic agent discovery.

    Example:
        bridge = AXELBridge(registry)
        bridge.add_adapter("claude_researcher",
                           AnthropicAdapter("claude_researcher", capabilities=["research"]))

        result = bridge.execute(task_msg)   # returns OK or ER
    """

    def __init__(self, registry: Optional[AXELRegistry] = None,
                 memory: Optional[SmartMemory] = None):
        self._adapters: Dict[str, BaseAdapter] = {}
        self.registry  = registry
        self.memory    = memory

    def add_adapter(self, agent_id: str, adapter: BaseAdapter) -> None:
        self._adapters[agent_id] = adapter

    def add_anthropic(self, agent_id: str, capabilities: List[str],
                      model: str = "claude-3-5-haiku-20241022") -> None:
        self.add_adapter(agent_id, AnthropicAdapter(agent_id, model, capabilities))

    def add_openai(self, agent_id: str, capabilities: List[str],
                   model: str = "gpt-4o-mini") -> None:
        self.add_adapter(agent_id, OpenAIAdapter(agent_id, model, capabilities))

    def add_ollama(self, agent_id: str, capabilities: List[str],
                   model: str = "llama3") -> None:
        self.add_adapter(agent_id, OllamaAdapter(agent_id, model=model, capabilities=capabilities))

    def add_openrouter(self, agent_id: str, capabilities: List[str],
                       model: str = "meta-llama/llama-3.1-8b-instruct:free",
                       key: Optional[str] = None) -> None:
        self.add_adapter(agent_id, OpenRouterAdapter(
            agent_id, model=model, capabilities=capabilities, key=key
        ))

    def add_mock(self, agent_id: str, response_fn: Callable = None) -> None:
        self.add_adapter(agent_id, MockAdapter(agent_id, response_fn))

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        """
        Execute a TASK message. Routing priority:
          1. Exact match on task_msg.to
          2. Registry auto-route by action capability
          3. Error if no adapter found
        """
        target = task_msg.to

        # 1. Direct target
        if target in self._adapters:
            return self._run(target, task_msg)

        # 2. Auto-route via registry
        if self.registry:
            action = task_msg.body.get("act", "")
            routed = self.registry.route(action)
            if routed and routed in self._adapters:
                return self._run(routed, task_msg)

        # 3. Fallback: try any adapter
        if self._adapters:
            first = next(iter(self._adapters))
            return self._run(first, task_msg)

        return AXELMessage(
            t="ER", fr="bridge", to=task_msg.fr,
            body={"code": "NOT_FOUND",
                  "msg": f"No adapter for agent '{target}'", "retry": False},
            cid=task_msg.cid, re=task_msg.id
        )

    def _run(self, agent_id: str, task_msg: AXELMessage) -> AXELMessage:
        """Run adapter and post-process the result."""
        start = time.time()
        result = self._adapters[agent_id].execute(task_msg)
        duration = time.time() - start

        # Update registry score if result is OK
        if self.registry and result.t == "OK":
            self.registry.update_score(agent_id, 4.5)

        # Extract and store any LS lesson in the result body
        if self.memory and result.t == "OK":
            lesson_hint = result.body.get("lesson")
            if lesson_hint:
                self.memory.write(Lesson(
                    key=task_msg.body.get("act", ""),
                    insight=lesson_hint,
                    source=agent_id,
                    confidence=0.8,
                ))

        result.body["_duration_s"] = round(duration, 3)
        return result

    def list_adapters(self) -> List[str]:
        return list(self._adapters.keys())


# ─────────────────────────────────────────────────────────────────────────────
# Builder extensions for v2 message types
# ─────────────────────────────────────────────────────────────────────────────

def build_announce(
    builder: AXELBuilder,
    model: str,
    provider: str,
    capabilities: List[str],
    endpoint: Optional[str] = None,
    tags: List[str] = None,
) -> AXELMessage:
    """Build an ANNOUNCE message — broadcast when an agent comes online."""
    body = {
        "model": model, "provider": provider,
        "capabilities": capabilities, "status": "online",
        "tags": tags or [],
    }
    if endpoint:
        body["endpoint"] = endpoint
    return AXELMessage(
        t=MsgTypeV2.ANNOUNCE, fr=builder.agent_id, to="*",
        body=body, cid=builder.conversation_id
    )


def build_chain(
    builder: AXELBuilder,
    to: str,
    steps: List[Dict],
    ctx: Dict = None,
) -> AXELMessage:
    """
    Build a CHAIN message defining a sequential pipeline.

    Each step: {"agent": "...", "act": "...", "args": {}, "deps": [step_index]}
    """
    return AXELMessage(
        t=MsgTypeV2.CHAIN, fr=builder.agent_id, to=to,
        body={"steps": steps, "ctx": ctx or {}},
        cid=builder.conversation_id
    )


def build_subscribe(builder: AXELBuilder, to: str, channel: str,
                    filter_: Dict = None) -> AXELMessage:
    """Subscribe to an event channel."""
    return AXELMessage(
        t=MsgTypeV2.SUBSCRIBE, fr=builder.agent_id, to=to,
        body={"channel": channel, "filter": filter_ or {}},
        cid=builder.conversation_id
    )


def build_publish(builder: AXELBuilder, channel: str, event: Dict) -> AXELMessage:
    """Publish an event to a channel."""
    return AXELMessage(
        t=MsgTypeV2.PUBLISH, fr=builder.agent_id, to="*",
        body={"channel": channel, "event": event},
        cid=builder.conversation_id
    )


# ─────────────────────────────────────────────────────────────────────────────
# AXELNetwork — the full stack in one object
# ─────────────────────────────────────────────────────────────────────────────

class AXELNetwork:
    """
    The complete AXEL cross-LLM network.

    Ties together: registry, memory, bridge, and session logging.
    Persists all state to ~/.axel/.

    Example:
        net = AXELNetwork.load()

        # Register a Claude agent
        net.add_agent("claude_researcher",
                      provider="anthropic", model="claude-3-5-haiku-20241022",
                      capabilities=["research","summarize","extract_entities"])

        # Register a GPT agent
        net.add_agent("gpt_writer",
                      provider="openai", model="gpt-4o-mini",
                      capabilities=["draft","write","edit"])

        # Register a local Llama agent
        net.add_agent("llama_classifier",
                      provider="ollama", model="llama3",
                      capabilities=["classify","label","tag"])

        # Route a task to the best available agent
        builder = AXELBuilder("orchestrator")
        task = builder.task("auto", "summarize_document", args={"url": "..."})
        result = net.execute(task)
        print(result.body["result"])

        # See what everyone has learned
        print(net.memory.stats())
        print(net.registry.leaderboard())
    """

    SESSION_LOG = AXEL_HOME / "session_log.jsonl"

    def __init__(self):
        self.registry = AXELRegistry()
        self.memory   = SmartMemory()
        self.bridge   = AXELBridge(self.registry, self.memory)
        self._lock    = threading.Lock()

    @classmethod
    def load(cls) -> "AXELNetwork":
        """Load existing state from ~/.axel/ and return a network instance."""
        net = cls()
        # Apply memory decay on load
        decayed = net.memory.apply_decay()
        if decayed:
            net.memory.merge_similar()
        return net

    def add_agent(
        self,
        agent_id: str,
        provider: str,
        model: str,
        capabilities: List[str],
        endpoint: Optional[str] = None,
        use_mock: bool = False,
    ) -> AgentRecord:
        """
        Register an agent and wire up its adapter.

        provider: "anthropic" | "openai" | "ollama" | "mock"
        use_mock: if True, uses MockAdapter regardless of provider (for testing)
        """
        record = self.registry.register(
            agent_id=agent_id, model=model, provider=provider,
            capabilities=capabilities, endpoint=endpoint
        )

        if use_mock:
            self.bridge.add_mock(agent_id)
        elif provider == "anthropic":
            self.bridge.add_anthropic(agent_id, capabilities, model)
        elif provider == "openai":
            self.bridge.add_openai(agent_id, capabilities, model)
        elif provider == "ollama":
            self.bridge.add_ollama(agent_id, capabilities, model)
        else:
            self.bridge.add_mock(agent_id)  # Unknown provider → mock

        return record

    def announce(
        self,
        agent_id: str,
        capabilities: List[str],
        model: str,
        provider: str = "custom",
    ) -> AXELMessage:
        """
        Announce an agent to the network and log the message.
        Returns the ANNOUNCE message.
        """
        builder = AXELBuilder(agent_id)
        msg = build_announce(builder, model, provider, capabilities)
        self.registry.process_announce(msg)
        self._log(msg)
        return msg

    def execute(self, task_msg: AXELMessage) -> AXELMessage:
        """Execute a task and log both the task and the result."""
        self._log(task_msg)
        result = self.bridge.execute(task_msg)
        self._log(result)

        # Auto-record feedback if result is OK
        if result.t == "OK":
            target = task_msg.to
            if target != "auto":
                self.registry.update_score(target, 4.5)

        return result

    def learn(self, key: str, insight: str, source: str,
              confidence: float = 0.9) -> Lesson:
        """Directly add a lesson to shared memory."""
        lesson = Lesson(key=key, insight=insight, source=source,
                        confidence=confidence)
        self.memory.write(lesson)
        return lesson

    def _log(self, msg: AXELMessage) -> None:
        AXEL_HOME.mkdir(parents=True, exist_ok=True)
        with self._lock:
            with open(self.SESSION_LOG, "a") as f:
                f.write(msg.to_json() + "\n")

    def status(self) -> dict:
        return {
            "agents":          len(self.registry),
            "memory_lessons":  len(self.memory),
            "memory_stats":    self.memory.stats(),
            "leaderboard":     self.registry.leaderboard(),
            "adapters":        self.bridge.list_adapters(),
        }

    def __repr__(self) -> str:
        return (f"AXELNetwork("
                f"agents={len(self.registry)}, "
                f"memory={len(self.memory)} lessons)")


# ─────────────────────────────────────────────────────────────────────────────
# Demo
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import random

    print("=" * 70)
    print("AXEL Universal — Cross-LLM Network Demo")
    print("=" * 70)

    # ── Build the network ────────────────────────────────────────────────────
    net = AXELNetwork.load()

    # Register agents from different "providers" (mocked here)
    net.add_agent("claude_researcher", provider="anthropic",
                  model="claude-3-5-haiku-20241022",
                  capabilities=["research","summarize","extract_entities"],
                  use_mock=True)

    net.add_agent("gpt_writer",        provider="openai",
                  model="gpt-4o-mini",
                  capabilities=["draft_content","write","edit"],
                  use_mock=True)

    net.add_agent("llama_classifier",  provider="ollama",
                  model="llama3",
                  capabilities=["classify","label","tag","categorize"],
                  use_mock=True)

    net.add_agent("gemini_translator", provider="google",
                  model="gemini-1.5-flash",
                  capabilities=["translate_text","localize","multilingual"],
                  use_mock=True)

    print(f"\nNetwork: {net}")
    print("\nRegistered agents:")
    for entry in net.registry.leaderboard():
        print(f"  [{entry['rank']}] {entry['agent']:22s} "
              f"({entry['model']:30s}) caps: {', '.join(entry['capabilities'])}")

    # ── Announce all agents ──────────────────────────────────────────────────
    print("\n── Agents coming online (ANNOUNCE) ──")
    for agent_id, model, prov, caps in [
        ("claude_researcher", "claude-3-5-haiku-20241022", "anthropic", ["research","summarize"]),
        ("gpt_writer",        "gpt-4o-mini",               "openai",    ["draft","write"]),
        ("llama_classifier",  "llama3",                    "ollama",    ["classify","tag"]),
        ("gemini_translator", "gemini-1.5-flash",          "google",    ["translate"]),
    ]:
        msg = net.announce(agent_id, caps, model, prov)
        print(f"  {msg.t}  {msg.fr:22s}  {model:30s}  caps: {', '.join(caps)}")

    # ── Auto-route tasks by capability ───────────────────────────────────────
    print("\n── Auto-routing tasks to best agents ──")
    builder = AXELBuilder("orchestrator")

    test_tasks = [
        ("summarize",         "summarize_report",  {"text": "Q1 results show 20% growth..."}),
        ("draft",             "draft_content",     {"topic": "AI trends 2025", "words": 300}),
        ("classify",          "classify_documents",{"docs": ["doc1","doc2"]}),
        ("translate",         "translate_text",    {"text": "Hello world", "target": "fr"}),
        ("extract_entities",  "extract_entities",  {"text": "Apple and Google announced..."}),
    ]

    for cap, action, args in test_tasks:
        routed_to = net.registry.route(action) or net.registry.route(cap) or "claude_researcher"
        task = AXELMessage(
            t="TK", fr="orchestrator", to=routed_to,
            body={"act": action, "args": args}, cid="cnv_demo",
            id=_new_id("msg"), ts=_now_ms()
        )
        result = net.execute(task)
        print(f"  {action:25s} → {routed_to:22s} → {result.t}")

    # ── Cross-LLM learning ───────────────────────────────────────────────────
    print("\n── Cross-LLM lesson sharing ──")
    cross_lessons = [
        ("claude_researcher", "summarize",          "Bullet-point summaries transfer better across models"),
        ("gpt_writer",        "draft_content",      "Use active voice — all LLMs reproduce it more accurately"),
        ("llama_classifier",  "classify_documents", "Zero-shot classification improves with explicit label sets"),
        ("gemini_translator", "translate_text",     "Preserve markup tags in a separate pass before translating"),
    ]
    for source, key, insight in cross_lessons:
        lesson = net.learn(key, insight, source, confidence=0.88)
        print(f"  [{source}] ({key}) — {insight[:55]}…")

    # ── BM25 search across all lessons ──────────────────────────────────────
    print("\n── Smart memory search: 'classification labels' ──")
    results = net.memory.search("classification labels", n=3)
    for lesson, score in results:
        print(f"  score={score:.3f}  [{lesson.source}] {lesson.insight[:60]}…")

    # ── Confidence decay simulation ──────────────────────────────────────────
    print("\n── Applying confidence decay to old lessons ──")
    # Artificially age some lessons for demo
    with net.memory._lock:
        for bucket in net.memory._store.values():
            for l in bucket:
                l.ts = l.ts - (8 * 24 * 3600 * 1000)  # age 8 days
    decayed = net.memory.apply_decay()
    print(f"  {decayed} lessons had confidence decay applied")

    merged = net.memory.merge_similar(similarity_threshold=0.4)
    print(f"  {merged} near-duplicate lessons merged")

    # ── Network status ───────────────────────────────────────────────────────
    print("\n── Network Status ──")
    s = net.status()
    print(f"  Agents:   {s['agents']}")
    print(f"  Memory:   {s['memory_stats']['total_lessons']} lessons  "
          f"| {s['memory_stats']['unique_keys']} keys  "
          f"| avg confidence {s['memory_stats']['avg_confidence']}")
    print(f"  Sources:  {s['memory_stats']['by_source']}")

    print("\n── AXEL System Prompt (first 300 chars) ──")
    sp = make_system_prompt("example_agent", ["research","summarize"], "claude-3-5-sonnet")
    print("  " + sp[:300].replace("\n", "\n  ") + "…")

    print("\n" + "=" * 70)
    print("Cross-LLM network demo complete.")
    print(f"Session log: {AXELNetwork.SESSION_LOG}")
    print(f"Registry:    {AXELRegistry.REGISTRY_FILE}")
    print(f"Memory:      {SmartMemory.MEMORY_FILE}")
