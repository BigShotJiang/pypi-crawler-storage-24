"""
AXEL Learning System — axel_learning.py
Extension to axel.py: shared memory, lesson broadcasting, and score-based feedback.

New message types:
  LS  LESSON    — Agent broadcasts an insight it learned from completed work
  FB  FEEDBACK  — Scorer rates a completed task (adjusts agent scores)

New classes:
  Lesson       — A single stored insight
  AXELMemory   — Thread-safe shared knowledge store (grows as agents work)
  AXELLearner  — Learning wrapper: tracks score, shares/absorbs lessons
  AXELScorer   — Assigns feedback scores after task completion

Usage:
    from axel.core import AXELBuilder, AXELParser
    from axel_learning import AXELMemory, AXELLearner, AXELScorer

    memory  = AXELMemory()
    learner = AXELLearner("executor_agent", memory)

    # Before a task: look up relevant lessons
    hints = learner.lookup("summarize_document")

    # After success: record outcome + broadcast lesson
    lesson_msg = learner.record_success(
        action="summarize_document",
        result={"summary": "..."},
        insight="Chunking the doc by section improves summary coherence"
    )
    if lesson_msg:
        broadcast(lesson_msg)   # send to other agents

    # When receiving a LESSON broadcast from another agent:
    learner.absorb_lesson(incoming_msg)

    # When receiving a FEEDBACK score:
    learner.apply_feedback(incoming_msg)

    print(learner.stats())
"""

import json
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

# Re-use core AXEL primitives
from axel.core import AXELBuilder, AXELMessage, _new_id, _now_ms


# ─────────────────────────────────────────────────────────────────────────────
# Extended message types
# ─────────────────────────────────────────────────────────────────────────────

LESSON_TYPE   = "LS"   # Agent shares an insight with all peers
FEEDBACK_TYPE = "FB"   # Scorer rates a completed task

# Extend AXELParser to accept LS + FB (monkey-patch without modifying axel.py)
try:
    from axel.core import AXELParser
    AXELParser.VALID_TYPES = AXELParser.VALID_TYPES | frozenset({LESSON_TYPE, FEEDBACK_TYPE})
except Exception:
    pass


# ─────────────────────────────────────────────────────────────────────────────
# Lesson dataclass
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Lesson:
    """A single piece of knowledge an agent has learned."""
    key:        str          # Capability or action this applies to (e.g. "summarize_doc")
    insight:    str          # The actual lesson text
    source:     str          # Agent ID that learned it
    confidence: float = 1.0  # How confident the source is (0–1)
    ts:         int   = field(default_factory=_now_ms)
    uses:       int   = 0    # How many times other agents have applied it

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Lesson":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    def __repr__(self) -> str:
        stars = "★" * round(self.confidence * 5)
        return f"Lesson(key={self.key!r}, src={self.source!r}, {stars}: {self.insight[:50]}…)"


# ─────────────────────────────────────────────────────────────────────────────
# AXELMemory — shared knowledge store
# ─────────────────────────────────────────────────────────────────────────────

class AXELMemory:
    """
    Thread-safe shared knowledge store.

    Agents write lessons here after successful tasks. Other agents read
    lessons before tackling similar work — creating a collective learning loop.

    The store is keyed by capability/action name. Multiple lessons can exist
    for the same key (from different agents or different times).

    Example:
        memory = AXELMemory()

        # Write a lesson
        memory.write(Lesson(
            key="summarize_doc",
            insight="Chunking by section gives better coherence",
            source="researcher",
            confidence=0.9
        ))

        # Read lessons for a capability
        lessons = memory.read("summarize_doc")

        # Fuzzy search across all lessons
        results = memory.query("summarize")

        # Full stats
        print(memory.stats())
    """

    def __init__(self, max_per_key: int = 10):
        self._store: Dict[str, List[Lesson]] = {}
        self._lock  = threading.Lock()
        self._max   = max_per_key

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def write(self, lesson: Lesson) -> None:
        """Store a lesson. Evicts the oldest entry if max_per_key is reached."""
        with self._lock:
            bucket = self._store.setdefault(lesson.key, [])
            # Avoid exact duplicate insights
            if any(l.insight == lesson.insight for l in bucket):
                return
            bucket.append(lesson)
            # Trim to max
            if len(bucket) > self._max:
                bucket.sort(key=lambda l: (l.confidence, l.uses), reverse=True)
                bucket[:] = bucket[:self._max]

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read(self, key: str) -> List[Lesson]:
        """Return all lessons for an exact key, sorted by confidence desc."""
        with self._lock:
            lessons = list(self._store.get(key, []))
        lessons.sort(key=lambda l: (l.confidence, l.uses), reverse=True)
        return lessons

    def best(self, key: str) -> Optional[Lesson]:
        """Return the single highest-confidence lesson for a key, or None."""
        lessons = self.read(key)
        return lessons[0] if lessons else None

    def query(self, topic: str, n: int = 5) -> List[Lesson]:
        """
        Search across all lessons whose key contains `topic` (case-insensitive).
        Returns up to n results ordered by confidence.
        """
        topic_lower = topic.lower()
        with self._lock:
            matches = [
                l for bucket in self._store.values()
                for l in bucket
                if topic_lower in l.key.lower() or topic_lower in l.insight.lower()
            ]
        matches.sort(key=lambda l: (l.confidence, l.uses), reverse=True)
        return matches[:n]

    def mark_used(self, key: str, insight: str) -> None:
        """Increment the `uses` counter on a lesson (call when an agent applies it)."""
        with self._lock:
            for lesson in self._store.get(key, []):
                if lesson.insight == insight:
                    lesson.uses += 1
                    break

    def all_lessons(self) -> List[Lesson]:
        """Return every lesson in the store, ordered by timestamp desc."""
        with self._lock:
            flat = [l for bucket in self._store.values() for l in bucket]
        flat.sort(key=lambda l: l.ts, reverse=True)
        return flat

    def top(self, n: int = 10) -> List[Lesson]:
        """Return the n highest-confidence, most-used lessons."""
        all_l = self.all_lessons()
        all_l.sort(key=lambda l: (l.confidence*2 + l.uses*0.5), reverse=True)
        return all_l[:n]

    def stats(self) -> dict:
        with self._lock:
            keys   = list(self._store.keys())
            flat   = [l for b in self._store.values() for l in b]
        avg_conf = sum(l.confidence for l in flat) / len(flat) if flat else 0.0
        return {
            "total_lessons":  len(flat),
            "unique_keys":    len(keys),
            "avg_confidence": round(avg_conf, 3),
            "most_populated": max(keys, key=lambda k: len(self._store[k])) if keys else None,
        }

    def to_json(self, compact: bool = False) -> str:
        with self._lock:
            data = {k: [l.to_dict() for l in v] for k, v in self._store.items()}
        return json.dumps(data, separators=(',',':') if compact else None, indent=None if compact else 2)

    def __len__(self) -> int:
        with self._lock:
            return sum(len(b) for b in self._store.values())

    def __repr__(self) -> str:
        return f"AXELMemory({len(self)} lessons across {len(self._store)} keys)"


# ─────────────────────────────────────────────────────────────────────────────
# Builder extension: lesson + feedback message factories
# ─────────────────────────────────────────────────────────────────────────────

def build_lesson(
    builder: AXELBuilder,
    action: str,
    insight: str,
    confidence: float = 1.0,
    to: str = "*",
) -> AXELMessage:
    """
    Build a LESSON broadcast message.
    `to` defaults to "*" (broadcast to all agents).
    """
    return AXELMessage(
        t=LESSON_TYPE,
        fr=builder.agent_id,
        to=to,
        body={"key": action, "insight": insight, "confidence": confidence},
        cid=builder.conversation_id,
    )


def build_feedback(
    builder: AXELBuilder,
    to: str,
    score: float,
    task_id: str,
    comment: str = "",
) -> AXELMessage:
    """
    Build a FEEDBACK message rating a completed task.
    score: 1.0–5.0 stars
    task_id: the id of the TASK message being rated
    """
    return AXELMessage(
        t=FEEDBACK_TYPE,
        fr=builder.agent_id,
        to=to,
        body={"score": round(score, 2), "task_id": task_id, "comment": comment},
        cid=builder.conversation_id,
        re=task_id,
    )


# ─────────────────────────────────────────────────────────────────────────────
# AXELLearner — per-agent learning wrapper
# ─────────────────────────────────────────────────────────────────────────────

class AXELLearner:
    """
    Learning wrapper for an AXEL agent.

    Tracks performance (score, task history), shares lessons after successes,
    absorbs lessons from peers, and adjusts score based on feedback.

    Example:
        memory  = AXELMemory()
        learner = AXELLearner("researcher", memory)

        # Before a task — get hints from shared memory
        hints = learner.lookup("analyze_data")
        for h in hints:
            print(f"  Hint from {h.source}: {h.insight}")

        # After a successful task
        msg = learner.record_success("analyze_data", result, "Normalize first!")
        if msg: broadcast(msg)

        # On receiving a peer's LESSON broadcast
        learner.absorb_lesson(incoming_ls_msg)

        # On receiving a FEEDBACK score
        learner.apply_feedback(incoming_fb_msg)

        print(learner.stats())
    """

    SCORE_MIN = 1.0
    SCORE_MAX = 5.0
    BASE_SCORE = 3.0
    SUCCESS_GAIN = 0.10    # score gained per success
    FAILURE_LOSS = 0.20    # score lost per failure
    FB_WEIGHT    = 0.15    # how much a single FB score adjusts the running average

    def __init__(self, agent_id: str, memory: AXELMemory, initial_score: float = 3.0):
        self.agent_id = agent_id
        self.memory   = memory
        self.builder  = AXELBuilder(agent_id)
        self._score   = float(initial_score)
        self._lock    = threading.Lock()

        # Counters
        self.tasks_done:       int   = 0
        self.tasks_failed:     int   = 0
        self.lessons_shared:   int   = 0
        self.lessons_absorbed: int   = 0
        self.feedback_received: int  = 0

        # History: list of {"action", "success", "score_delta", "ts"}
        self._history: List[dict] = []

    # ------------------------------------------------------------------
    # Score property (thread-safe read)
    # ------------------------------------------------------------------

    @property
    def score(self) -> float:
        with self._lock:
            return round(self._score, 3)

    @property
    def star_rating(self) -> str:
        """Human-readable star rating."""
        s = self.score
        full  = int(s)
        half  = 1 if (s - full) >= 0.5 else 0
        empty = 5 - full - half
        return "★" * full + "½" * half + "☆" * empty

    # ------------------------------------------------------------------
    # Task outcome recording
    # ------------------------------------------------------------------

    def record_success(
        self,
        action: str,
        result: Any = None,
        insight: str = "",
        confidence: float = 0.85,
    ) -> Optional[AXELMessage]:
        """
        Record a successful task completion.

        Returns a LESSON AXELMessage to broadcast if an insight is provided,
        otherwise returns None.
        """
        with self._lock:
            self.tasks_done += 1
            self._score = min(self.SCORE_MAX, self._score + self.SUCCESS_GAIN)
            self._history.append({
                "action": action, "success": True,
                "score_delta": self.SUCCESS_GAIN, "ts": _now_ms()
            })

        if insight:
            lesson = Lesson(
                key=action, insight=insight,
                source=self.agent_id, confidence=confidence,
            )
            self.memory.write(lesson)
            self.lessons_shared += 1
            return build_lesson(self.builder, action, insight, confidence)
        return None

    def record_failure(self, action: str, error: str = "") -> None:
        """Record a task failure and reduce score."""
        with self._lock:
            self.tasks_failed += 1
            self._score = max(self.SCORE_MIN, self._score - self.FAILURE_LOSS)
            self._history.append({
                "action": action, "success": False,
                "score_delta": -self.FAILURE_LOSS, "ts": _now_ms()
            })

    # ------------------------------------------------------------------
    # Learning from peers
    # ------------------------------------------------------------------

    def absorb_lesson(self, msg: AXELMessage) -> Optional[Lesson]:
        """
        Process a LESSON message from another agent.
        Writes the lesson to shared memory and increments the absorbed counter.
        Returns the Lesson object if successfully absorbed, None if skipped.
        """
        if msg.t != LESSON_TYPE:
            return None
        if msg.fr == self.agent_id:
            return None  # Don't absorb your own lessons

        lesson = Lesson(
            key=msg.body.get("key", ""),
            insight=msg.body.get("insight", ""),
            source=msg.fr,
            confidence=float(msg.body.get("confidence", 0.8)),
            ts=msg.ts,
        )
        self.memory.write(lesson)
        self.lessons_absorbed += 1

        # Small score boost for being an active learner
        with self._lock:
            self._score = min(self.SCORE_MAX, self._score + 0.01)

        return lesson

    def apply_feedback(self, msg: AXELMessage) -> float:
        """
        Process a FEEDBACK message from a scorer/orchestrator.
        Adjusts running score toward the received rating.
        Returns the updated score.
        """
        if msg.t != FEEDBACK_TYPE:
            return self.score

        fb_score = float(msg.body.get("score", self.score))
        self.feedback_received += 1

        with self._lock:
            # Weighted blend: pull score toward feedback rating
            self._score = self._score * (1 - self.FB_WEIGHT) + fb_score * self.FB_WEIGHT
            self._score = max(self.SCORE_MIN, min(self.SCORE_MAX, self._score))

        return self.score

    # ------------------------------------------------------------------
    # Memory lookup
    # ------------------------------------------------------------------

    def lookup(self, topic: str, n: int = 3) -> List[Lesson]:
        """
        Query shared memory for lessons relevant to a task before starting it.
        Marks returned lessons as 'used'.
        """
        results = self.memory.query(topic, n=n)
        for r in results:
            self.memory.mark_used(r.key, r.insight)
        return results

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict:
        total = self.tasks_done + self.tasks_failed
        success_rate = (self.tasks_done / total) if total else 0.0
        return {
            "agent":            self.agent_id,
            "score":            self.score,
            "stars":            self.star_rating,
            "tasks_done":       self.tasks_done,
            "tasks_failed":     self.tasks_failed,
            "success_rate":     round(success_rate, 3),
            "lessons_shared":   self.lessons_shared,
            "lessons_absorbed": self.lessons_absorbed,
            "feedback_received":self.feedback_received,
        }

    def __repr__(self) -> str:
        return (f"AXELLearner(agent={self.agent_id!r}, "
                f"score={self.score}, {self.star_rating}, "
                f"tasks={self.tasks_done}/{self.tasks_done+self.tasks_failed})")


# ─────────────────────────────────────────────────────────────────────────────
# AXELScorer — evaluates task outcomes and issues feedback
# ─────────────────────────────────────────────────────────────────────────────

class AXELScorer:
    """
    Evaluates completed tasks and issues FEEDBACK messages.

    The default scoring heuristic is simple (speed + success). Override
    `evaluate()` with your own logic in production.

    Example:
        scorer  = AXELScorer("scorer_agent")
        builder = AXELBuilder("scorer_agent")

        # After receiving an OK message from worker
        fb_msg = scorer.score_task(
            task_msg_id=original_task.id,
            worker_id="executor",
            duration_s=12.4,
            success=True,
        )
        send(fb_msg)   # dispatch to worker agent
    """

    def __init__(self, agent_id: str = "scorer"):
        self.agent_id = agent_id
        self.builder  = AXELBuilder(agent_id)
        self._history: List[dict] = []

    def evaluate(
        self,
        success: bool,
        duration_s: float = 0.0,
        expected_s: float = 30.0,
        quality: Optional[float] = None,  # 0–1 if available
    ) -> float:
        """
        Compute a 1.0–5.0 score.

        Base: 5.0 for success, 2.0 for failure.
        Speed bonus: up to +0.5 if faster than expected.
        Speed penalty: up to -1.0 if much slower.
        Quality adjustment: ±1.0 if provided.
        """
        if not success:
            base = 2.0
        else:
            base = 4.5
            # Speed adjustment
            if expected_s > 0:
                ratio = duration_s / expected_s
                if ratio < 0.5:
                    base += 0.5           # Very fast
                elif ratio < 1.0:
                    base += 0.2           # Faster than expected
                elif ratio > 2.0:
                    base -= 1.0           # Much slower
                elif ratio > 1.5:
                    base -= 0.5           # Slightly slow

        if quality is not None:
            base += (quality - 0.5) * 2   # -1.0 to +1.0

        return round(max(1.0, min(5.0, base)), 2)

    def score_task(
        self,
        task_msg_id: str,
        worker_id: str,
        success: bool,
        duration_s: float = 0.0,
        expected_s: float = 30.0,
        quality: Optional[float] = None,
        comment: str = "",
    ) -> AXELMessage:
        """
        Evaluate a task outcome and return a FEEDBACK message to send to the worker.
        """
        score = self.evaluate(success, duration_s, expected_s, quality)
        self._history.append({
            "task_id": task_msg_id, "worker": worker_id,
            "score": score, "ts": _now_ms()
        })
        return build_feedback(self.builder, worker_id, score, task_msg_id, comment)

    def leaderboard(self) -> List[dict]:
        """
        Return per-worker average scores from history, sorted best first.
        """
        totals: Dict[str, List[float]] = {}
        for h in self._history:
            totals.setdefault(h["worker"], []).append(h["score"])
        lb = [
            {"agent": w, "avg_score": round(sum(s)/len(s),2), "tasks_rated": len(s)}
            for w, s in totals.items()
        ]
        lb.sort(key=lambda x: x["avg_score"], reverse=True)
        return lb


# ─────────────────────────────────────────────────────────────────────────────
# Demo
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import random

    print("=" * 65)
    print("AXEL Learning System — Demo")
    print("=" * 65)

    # ── Setup ────────────────────────────────────────────────────────────
    memory   = AXELMemory()
    planner  = AXELLearner("planner",    memory, initial_score=3.2)
    executor = AXELLearner("executor",   memory, initial_score=2.9)
    analyst  = AXELLearner("analyst",    memory, initial_score=3.1)
    scorer   = AXELScorer("scorer")

    agents = [planner, executor, analyst]

    print(f"\nInitial state:")
    for a in agents:
        print(f"  {a}")

    # ── Simulate 20 tasks ────────────────────────────────────────────────
    task_actions = [
        ("summarize_report",    "Chunking by section gives better coherence"),
        ("extract_entities",    "NER pre-pass reduces false positives by 30%"),
        ("classify_documents",  "Use embeddings not keywords for edge cases"),
        ("analyze_trends",      "Normalize time-series before comparison"),
        ("draft_content",       "Bullet points first, prose second — faster"),
        ("fact_check",          "Cross-reference ≥3 sources before concluding"),
        ("translate_text",      "Preserve formatting tags during translation"),
        ("generate_outline",    "Start with conclusion, then fill backwards"),
    ]

    print("\n── Simulating 20 tasks... ──")
    for i in range(20):
        worker = random.choice(agents)
        action, insight = random.choice(task_actions)
        success = random.random() < 0.75

        if success:
            # Check memory first
            hints = worker.lookup(action, n=2)
            if hints:
                print(f"  [{i+1:02d}] {worker.agent_id:10s} found {len(hints)} hint(s) for '{action}'")

            # Record success + maybe broadcast lesson
            share_insight = insight if random.random() > 0.4 else ""
            lesson_msg = worker.record_success(action, result={"ok": True}, insight=share_insight)

            # If a lesson was created, other agents absorb it
            if lesson_msg:
                for other in agents:
                    if other is not worker:
                        absorbed = other.absorb_lesson(lesson_msg)
                        if absorbed:
                            pass  # silently absorbed

            # Scorer issues feedback
            duration = random.uniform(5, 60)
            fb_msg = scorer.score_task(
                task_msg_id=_new_id("msg"),
                worker_id=worker.agent_id,
                success=True,
                duration_s=duration,
            )
            worker.apply_feedback(fb_msg)
            stars = fb_msg.body["score"]
            print(f"  [{i+1:02d}] {worker.agent_id:10s} ✓ {action:25s}  ★{stars:.1f}  score→{worker.score:.2f}")

        else:
            worker.record_failure(action, error="TIMEOUT")
            print(f"  [{i+1:02d}] {worker.agent_id:10s} ✗ {action:25s}  FAIL   score→{worker.score:.2f}")

    # ── Final state ──────────────────────────────────────────────────────
    print("\n── Final Agent Stats ──")
    for a in agents:
        s = a.stats()
        print(f"\n  {s['agent']}  {s['stars']}  ({s['score']})")
        print(f"    Tasks:    {s['tasks_done']} done / {s['tasks_failed']} failed  ({s['success_rate']*100:.0f}% success)")
        print(f"    Lessons:  {s['lessons_shared']} shared / {s['lessons_absorbed']} absorbed")
        print(f"    Feedback: {s['feedback_received']} received")

    print("\n── Shared Memory ──")
    ms = memory.stats()
    print(f"  Total lessons: {ms['total_lessons']}  |  Unique keys: {ms['unique_keys']}  |  Avg confidence: {ms['avg_confidence']}")
    print(f"\n  Top 5 lessons:")
    for l in memory.top(5):
        print(f"    [{l.source}] ({l.key}) — {l.insight[:55]}…  (used {l.uses}x)")

    print("\n── Scorer Leaderboard ──")
    for rank, entry in enumerate(scorer.leaderboard(), 1):
        print(f"  #{rank}  {entry['agent']:12s}  ★{entry['avg_score']}  ({entry['tasks_rated']} tasks rated)")

    print("\n── Memory Lookup Demo ──")
    hints = executor.lookup("summarize", n=3)
    print(f"  executor looking up 'summarize' → {len(hints)} hint(s):")
    for h in hints:
        print(f"    • [{h.source}] {h.insight}")

    print("\n" + "=" * 65)
    print("Learning system demo complete.")
