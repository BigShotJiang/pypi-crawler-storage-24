# Contributing to AXEL

Thanks for your interest in making AXEL better. Contributions of all sizes are welcome — from typo fixes to new LLM adapters.

## Ways to contribute

**New LLM adapters** are the highest-impact contribution. Every new adapter connects AXEL to a new family of models. Priority targets:
- Google Gemini (`GeminiAdapter`)
- Mistral AI (`MistralAdapter`)
- Cohere (`CohereAdapter`)
- Together AI (`TogetherAdapter`)
- Groq (`GroqAdapter`)

**Memory backends** — the current `SmartMemory` is in-process dict + JSON file. Production deployments need:
- `RedisMemory` — shared across multiple server instances
- `SQLiteMemory` — persistent, zero infrastructure
- `PostgresMemory` — for larger deployments

**Agent templates** — pre-built `AXELAgent` subclasses for common roles:
- `ResearcherAgent` — wraps search APIs (Tavily, Perplexity, SerpAPI)
- `CoderAgent` — integrates code execution (E2B, local subprocess)
- `ReviewerAgent` — standardised quality scoring rubric

**Language clients** — the Python client is pure stdlib. Ports needed:
- TypeScript/Node.js
- Rust
- Go

**AXEL Studio** — a visual drag-and-drop network editor for designing multi-agent pipelines.

---

## Getting started

```bash
git clone https://github.com/sectorx/axel-protocol
cd axel-protocol
pip install -e ".[dev]"

# Run tests
pytest

# Run the demo (no API keys needed)
python examples/demo_live.py
```

---

## Adding an adapter

An adapter wraps a single LLM provider. It receives an AXEL `TK` message, calls the provider's API, and returns a result dict.

Create `axel/adapters/<name>.py`:

```python
from axel.server import BaseAdapter


class GeminiAdapter(BaseAdapter):
    """Google Gemini adapter for the AXEL bridge."""

    provider = "google"

    def __init__(self, agent_id: str, model: str, api_key: str, caps: list[str] = None):
        super().__init__(agent_id, model, caps)
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        self._client = genai.GenerativeModel(model)

    def execute(self, action: str, args: dict, ctx: dict) -> dict:
        prompt = self._build_prompt(action, args, ctx)
        response = self._client.generate_content(prompt)
        return {"result": response.text, "action": action}
```

Then register it in `axel/server.py`'s `AXELBridge.add_*` factory methods and add tests in `tests/test_adapters.py`.

---

## Code style

- Python 3.10+ type hints where practical
- `ruff` for linting and formatting: `ruff check . && ruff format .`
- Docstrings for public classes and methods
- Tests for all new adapters and backends

---

## Pull request process

1. Fork the repo and create a branch: `git checkout -b feat/gemini-adapter`
2. Write your code and tests
3. Run `pytest` — all tests must pass
4. Run `ruff check . && ruff format .` — no lint errors
5. Open a PR against `main` with a clear description of what you built and why

---

## Reporting bugs

Open a GitHub issue with:
- Python version and OS
- AXEL version (`pip show axel-protocol`)
- Minimal reproduction script
- Full error traceback

---

## Questions

Open a Discussion on GitHub or start a thread in the community Discord (link in repo sidebar once live).

---

*AXEL is MIT-licensed. By contributing you agree your contributions will be released under the same license.*
