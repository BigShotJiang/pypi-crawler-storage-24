# AXEL Message Schemas

Full body schemas for all 23 AXEL message types.

Every message shares the same envelope:

```json
{
  "v":   "2",            // protocol version
  "t":   "TK",           // message type (2-3 chars)
  "id":  "msg_<hex12>",  // unique message ID
  "cid": "cid_<hex12>",  // conversation/session ID
  "fr":  "agent_id",     // sender
  "to":  "agent_id",     // recipient ("*" = broadcast)
  "ts":  1700000000000,  // Unix timestamp, milliseconds
  "pri": 3,              // priority 1 (urgent) – 5 (background)
  "re":  "msg_...",      // optional: reply-to message ID
  "body": { ... }        // type-specific payload
}
```

---

## v1 Core Types (17)

### TK — Task
Request work from an agent.
```json
{
  "act":     "research",
  "args":    { "topic": "distributed inference" },
  "ctx":     { "project": "FLM-paper" },
  "timeout": 60,
  "priority": 3
}
```

### OK — Result
Successful task response. `re` field points to the original TK.
```json
{
  "result": { "summary": "...", "sources": [] },
  "tokens": 412,
  "model":  "claude-3-5-haiku-20241022"
}
```

### ER — Error
Failed task. `retry: true` means the caller can retry.
```json
{
  "code":  "TIMEOUT",
  "msg":   "Model did not respond within 60s",
  "retry": true
}
```

### LS — Lesson (broadcast)
Share a learned insight with all agents (`to: "*"`).
```json
{
  "key":        "research",
  "insight":    "Multi-hop queries surface 3× more context",
  "confidence": 0.92,
  "source":     "researcher"
}
```

### MR — Memory Read
Query shared memory (agent → server).
```json
{
  "query": "how to handle rate limits",
  "n":     5
}
```

### MW — Memory Write
Store a lesson (agent → server).
```json
{
  "key":        "rate_limits",
  "insight":    "Exponential backoff: start at 1s, cap at 60s",
  "confidence": 0.98
}
```

### QR — Query Response
Server returns memory search results.
```json
{
  "results": [
    { "key": "rate_limits", "insight": "...", "confidence": 0.98, "source": "ops_agent" }
  ]
}
```

### PP — Ping
Health check. Recipient should reply with PA.
```json
{ "ts": 1700000000000 }
```

### PA — Pong
Health check response.
```json
{ "latency_ms": 12 }
```

### HK — Handoff
Transfer conversation context to another agent.
```json
{
  "context":  { "conversation_so_far": "..." },
  "reason":   "Specialist required for domain X",
  "urgent":   false
}
```

### NT — Note
Non-blocking annotation (no response expected).
```json
{
  "note":  "User mentioned they prefer bullet points",
  "scope": "conversation"
}
```

### FT — Feedback
Score an agent's previous response.
```json
{
  "re":     "msg_abc123",
  "score":  0.85,
  "rubric": { "clarity": 0.9, "accuracy": 0.8 },
  "comment": "Good structure but missed the third requirement"
}
```

### ST — Status
Agent capability update.
```json
{
  "caps":   ["research", "summarize", "translate"],
  "load":   0.3,
  "status": "available"
}
```

### AB — Abort
Cancel an in-flight task.
```json
{
  "re":    "msg_xyz789",
  "reason": "User cancelled"
}
```

### RT — Retry
Retry a previously failed task.
```json
{
  "re":      "msg_xyz789",
  "attempt": 2,
  "delay_s": 5
}
```

### BK — Bookmark
Save a context checkpoint on the server.
```json
{
  "label":   "after_research_phase",
  "context": { "findings": "..." }
}
```

### RS — Restore
Load a previously saved context checkpoint.
```json
{
  "label": "after_research_phase"
}
```

---

## v2 Registry & Orchestration Types (6)

### AN — Announce
Register an agent and its capabilities.
```json
{
  "agent_id":  "researcher",
  "model":     "claude-3-5-haiku-20241022",
  "provider":  "anthropic",
  "caps":      ["research", "summarize", "extract_entities"],
  "tags":      ["production", "high-context"],
  "endpoint":  "http://localhost:7331"
}
```

### CP — Capability Response
Server confirms registration and returns network state.
```json
{
  "registered": true,
  "agents":     4,
  "your_caps":  ["research", "summarize"]
}
```

### SP — Subscribe
Subscribe this agent to a named pub/sub channel.
```json
{
  "channel":  "task.completed",
  "filter":   { "pipeline": "FLM-paper" }
}
```

### SB — Subscriber List
Server confirms subscription and returns current subscribers.
```json
{
  "channel":     "task.completed",
  "subscribers": ["orchestrator", "monitor"]
}
```

### PB — Publish
Broadcast an event to a channel. All subscribers receive it.
```json
{
  "channel": "task.completed",
  "event":   { "pipeline": "FLM-paper", "status": "done", "steps": 3 }
}
```

### CH — Chain
Kick off a sequential multi-step pipeline.
```json
{
  "steps": [
    { "to": "researcher", "act": "research",      "args": { "topic": "AXEL" } },
    { "to": "writer",     "act": "draft_content", "args": { "format": "brief" } },
    { "to": "reviewer",   "act": "review",        "args": { "criteria": "clarity" } }
  ],
  "ctx":           { "project": "AXEL-paper", "priority": "high" },
  "stop_on_error": true
}
```

---

## Channel naming convention

Channels use dot-separated namespacing:

| Channel | Purpose |
|---------|---------|
| `task.completed` | Fired when any task finishes |
| `task.failed` | Fired when a task errors out |
| `memory.updated` | Fired when a new lesson is stored |
| `agent.online` | Fired when an agent announces |
| `agent.offline` | Fired when an agent disconnects |
| `pipeline.<name>` | Per-pipeline lifecycle events |
| `model.<provider>` | Provider-specific events |

---

*Full source code: [`axel/core.py`](../axel/core.py)*
