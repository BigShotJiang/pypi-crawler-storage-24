# Changelog

All notable changes to AXEL are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [2.0.0] — 2024-12

### Added
- **AXEL Network Server** (`axel.server`) — FastAPI HTTP hub for real multi-LLM networks
- **AXELClient SDK** (`axel.client`) — pure Python stdlib client, zero extra dependencies
- **AXELAgent base class** — `@task_handler` decorator for self-contained agents
- **LLM Adapters** — MockAdapter, AnthropicAdapter, OpenAIAdapter, OllamaAdapter
- **Chain pipeline** (`CH` message type) — sequential multi-step execution with context passing
- **Server-Sent Events stream** (`/stream`) — real-time event feed for dashboards
- **Live monitor dashboard** (`examples/monitor.html`) — browser-based SSE dashboard
- **6 new v2 message types** — `AN`, `CP`, `SP`, `SB`, `PB`, `CH`
- `/agents/announce` — agent registration endpoint
- `/discover/<action>` — capability-based agent discovery
- `/channels/subscribe` and `/channels/publish` — pub/sub system
- `/execute` — synchronous task + chain execution endpoint
- Long-poll inbox (`/inbox/{id}`) with configurable timeout
- Persistent memory path configurable via `AXEL_MEMORY_PATH`

### Changed
- Protocol version bumped to `v: "2"`
- `AXELBuilder` now the canonical message factory (replaces raw dict construction)
- SmartMemory BM25 search now normalises scores across corpus

---

## [1.0.0] — 2024-10

### Added
- **AXEL protocol spec** — 17 core message types (TK, OK, ER, LS, MR, MW, QR, PP, PA, HK, NT, FT, ST, AB, RT, BK, RS)
- **axel.core** — `AXELMessage`, `AXELBuilder`, message parsing and validation
- **SmartMemory** — in-process shared memory with BM25 search and confidence decay
- **AXELRegistry** — cross-model agent discovery and capability matching
- **axel_dashboard.html** — first-generation in-browser dashboard
- **Cowork plugin** (`axel-protocol`) — slash commands for Claude: `/axel-init`, `/axel-task`, `/axel-status`, `/axel-lesson`, `/axel-memory`, `/axel-announce`, `/axel-discover`
