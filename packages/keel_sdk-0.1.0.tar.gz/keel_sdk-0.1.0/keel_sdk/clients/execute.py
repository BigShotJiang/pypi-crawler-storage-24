from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..types import JSONDict


class ExecuteClient:
    def __init__(self, request_fn: Any, request_async_fn: Any) -> None:
        self._request = request_fn
        self._request_async = request_async_fn

    def run(self, request: JSONDict) -> JSONDict:
        return self._request("POST", "/v1/execute", json=request)

    async def run_async(self, request: JSONDict) -> JSONDict:
        return await self._request_async("POST", "/v1/execute", json=request)
