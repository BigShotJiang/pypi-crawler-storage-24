from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..types import JSONDict


class PermitsClient:
    def __init__(self, request_fn: Any, request_async_fn: Any, get_fn: Any, get_async_fn: Any) -> None:
        self._request = request_fn
        self._request_async = request_async_fn
        self._get = get_fn
        self._get_async = get_async_fn

    def create(self, request: JSONDict) -> JSONDict:
        return self._request("POST", "/v1/permits", json=request)

    async def create_async(self, request: JSONDict) -> JSONDict:
        return await self._request_async("POST", "/v1/permits", json=request)

    def dry_run(self, request: JSONDict) -> JSONDict:
        return self._request("POST", "/v1/permits/dry-run", json=request)

    async def dry_run_async(self, request: JSONDict) -> JSONDict:
        return await self._request_async("POST", "/v1/permits/dry-run", json=request)

    def list(
        self,
        *,
        limit: int | None = None,
        project_id: str | None = None,
        before: str | None = None,
        subject_id: str | None = None,
        subject_type: str | None = None,
        action_name: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        decision: str | None = None,
    ) -> JSONDict:
        params = _build_params(locals())
        return self._get("/v1/permits", params=params)

    async def list_async(
        self,
        *,
        limit: int | None = None,
        project_id: str | None = None,
        before: str | None = None,
        subject_id: str | None = None,
        subject_type: str | None = None,
        action_name: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        decision: str | None = None,
    ) -> JSONDict:
        params = _build_params(locals())
        return await self._get_async("/v1/permits", params=params)

    def get(self, permit_id: str) -> JSONDict:
        return self._get(f"/v1/permits/{permit_id}")

    async def get_async(self, permit_id: str) -> JSONDict:
        return await self._get_async(f"/v1/permits/{permit_id}")

    def export(self, *, from_: str, to: str, format: str = "json") -> JSONDict:
        params = {"from": from_, "to": to, "format": format}
        return self._get("/v1/permits/export", params=params)

    async def export_async(self, *, from_: str, to: str, format: str = "json") -> JSONDict:
        params = {"from": from_, "to": to, "format": format}
        return await self._get_async("/v1/permits/export", params=params)

    def report_usage(self, permit_id: str, request: JSONDict) -> JSONDict:
        return self._request("POST", f"/v1/permits/{permit_id}/usage", json=request)

    async def report_usage_async(self, permit_id: str, request: JSONDict) -> JSONDict:
        return await self._request_async("POST", f"/v1/permits/{permit_id}/usage", json=request)

    def attest(self, permit_id: str, request: JSONDict) -> JSONDict:
        return self._request("POST", f"/v1/permits/{permit_id}/attest", json=request)

    async def attest_async(self, permit_id: str, request: JSONDict) -> JSONDict:
        return await self._request_async("POST", f"/v1/permits/{permit_id}/attest", json=request)

    def add_evidence(self, permit_id: str, request: JSONDict) -> JSONDict:
        return self._request("POST", f"/v1/permits/{permit_id}/evidence", json=request)

    async def add_evidence_async(self, permit_id: str, request: JSONDict) -> JSONDict:
        return await self._request_async("POST", f"/v1/permits/{permit_id}/evidence", json=request)

    def list_evidence(self, permit_id: str) -> JSONDict:
        return self._get(f"/v1/permits/{permit_id}/evidence")

    async def list_evidence_async(self, permit_id: str) -> JSONDict:
        return await self._get_async(f"/v1/permits/{permit_id}/evidence")

    def lineage(self, permit_id: str) -> JSONDict:
        return self._get(f"/v1/permits/{permit_id}/lineage")

    async def lineage_async(self, permit_id: str) -> JSONDict:
        return await self._get_async(f"/v1/permits/{permit_id}/lineage")

    def bundle(self, permit_id: str) -> JSONDict:
        return self._get(f"/v1/permits/{permit_id}/bundle")

    async def bundle_async(self, permit_id: str) -> JSONDict:
        return await self._get_async(f"/v1/permits/{permit_id}/bundle")


def _build_params(local_vars: dict[str, Any]) -> dict[str, str]:
    params: dict[str, str] = {}
    for key, val in local_vars.items():
        if key == "self" or val is None:
            continue
        params[key] = str(val)
    return params
