from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..types import JSONDict


class RequestsClient:
    def __init__(self, get_fn: Any, get_async_fn: Any) -> None:
        self._get = get_fn
        self._get_async = get_async_fn

    def timeline(self, request_id: str) -> JSONDict:
        return self._get(f"/v1/requests/{request_id}/timeline")

    async def timeline_async(self, request_id: str) -> JSONDict:
        return await self._get_async(f"/v1/requests/{request_id}/timeline")
