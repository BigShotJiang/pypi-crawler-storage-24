from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..types import JSONDict


class ProxyClient:
    def __init__(self, request_fn: Any, request_async_fn: Any) -> None:
        self._request = request_fn
        self._request_async = request_async_fn

    def openai(self, payload: JSONDict) -> JSONDict:
        return self._request("POST", "/v1/proxy/openai", json=payload)

    async def openai_async(self, payload: JSONDict) -> JSONDict:
        return await self._request_async("POST", "/v1/proxy/openai", json=payload)

    def anthropic(self, payload: JSONDict) -> JSONDict:
        return self._request("POST", "/v1/proxy/anthropic", json=payload)

    async def anthropic_async(self, payload: JSONDict) -> JSONDict:
        return await self._request_async("POST", "/v1/proxy/anthropic", json=payload)

    def google(self, payload: JSONDict) -> JSONDict:
        return self._request("POST", "/v1/proxy/google", json=payload)

    async def google_async(self, payload: JSONDict) -> JSONDict:
        return await self._request_async("POST", "/v1/proxy/google", json=payload)

    def xai(self, payload: JSONDict) -> JSONDict:
        return self._request("POST", "/v1/proxy/xai", json=payload)

    async def xai_async(self, payload: JSONDict) -> JSONDict:
        return await self._request_async("POST", "/v1/proxy/xai", json=payload)

    def meta(self, payload: JSONDict) -> JSONDict:
        return self._request("POST", "/v1/proxy/meta", json=payload)

    async def meta_async(self, payload: JSONDict) -> JSONDict:
        return await self._request_async("POST", "/v1/proxy/meta", json=payload)
