from __future__ import annotations

from typing import TYPE_CHECKING, Any, AsyncIterator, Iterator

if TYPE_CHECKING:
    from ..types import JSONDict


class ExecutionsClient:
    def __init__(
        self,
        request_fn: Any,
        request_async_fn: Any,
        get_fn: Any,
        get_async_fn: Any,
        stream_fn: Any,
        stream_async_fn: Any,
    ) -> None:
        self._request = request_fn
        self._request_async = request_async_fn
        self._get = get_fn
        self._get_async = get_async_fn
        self._stream = stream_fn
        self._stream_async = stream_async_fn

    def create(self, request: JSONDict) -> JSONDict:
        body = {**request, "mode": "sync"}
        return self._request("POST", "/v1/executions", json=body)

    async def create_async(self, request: JSONDict) -> JSONDict:
        body = {**request, "mode": "sync"}
        return await self._request_async("POST", "/v1/executions", json=body)

    def stream(self, request: JSONDict) -> Iterator[dict[str, Any]]:
        body = {**request, "mode": "stream"}
        return self._stream("POST", "/v1/executions", json=body)

    async def stream_async(self, request: JSONDict) -> AsyncIterator[dict[str, Any]]:
        body = {**request, "mode": "stream"}
        return self._stream_async("POST", "/v1/executions", json=body)

    def get(self, request_id: str) -> JSONDict:
        return self._get(f"/v1/executions/{request_id}")

    async def get_async(self, request_id: str) -> JSONDict:
        return await self._get_async(f"/v1/executions/{request_id}")
