from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..types import JSONDict


class JobsClient:
    def __init__(self, request_fn: Any, request_async_fn: Any, get_fn: Any, get_async_fn: Any) -> None:
        self._request = request_fn
        self._request_async = request_async_fn
        self._get = get_fn
        self._get_async = get_async_fn

    def create(self, request: JSONDict) -> JSONDict:
        return self._request("POST", "/v1/jobs", json=request)

    async def create_async(self, request: JSONDict) -> JSONDict:
        return await self._request_async("POST", "/v1/jobs", json=request)

    def get(self, job_id: str) -> JSONDict:
        return self._get(f"/v1/jobs/{job_id}")

    async def get_async(self, job_id: str) -> JSONDict:
        return await self._get_async(f"/v1/jobs/{job_id}")
