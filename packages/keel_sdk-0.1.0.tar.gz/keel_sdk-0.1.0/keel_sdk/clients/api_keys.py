from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..types import JSONDict


class ApiKeysClient:
    def __init__(self, request_fn: Any, request_async_fn: Any, get_fn: Any, get_async_fn: Any) -> None:
        self._request = request_fn
        self._request_async = request_async_fn
        self._get = get_fn
        self._get_async = get_async_fn

    def create(self, request: JSONDict | None = None) -> JSONDict:
        return self._request("POST", "/v1/api-keys", json=request or {})

    async def create_async(self, request: JSONDict | None = None) -> JSONDict:
        return await self._request_async("POST", "/v1/api-keys", json=request or {})

    def list(
        self,
        *,
        limit: int | None = None,
        cursor: str | None = None,
        status: str | None = None,
        scope: str | None = None,
    ) -> JSONDict:
        params: dict[str, str] = {}
        if limit is not None:
            params["limit"] = str(limit)
        if cursor:
            params["cursor"] = cursor
        if status:
            params["status"] = status
        if scope:
            params["scope"] = scope
        return self._get("/v1/api-keys", params=params)

    async def list_async(
        self,
        *,
        limit: int | None = None,
        cursor: str | None = None,
        status: str | None = None,
        scope: str | None = None,
    ) -> JSONDict:
        params: dict[str, str] = {}
        if limit is not None:
            params["limit"] = str(limit)
        if cursor:
            params["cursor"] = cursor
        if status:
            params["status"] = status
        if scope:
            params["scope"] = scope
        return await self._get_async("/v1/api-keys", params=params)

    def get(self, key_id: str) -> JSONDict:
        return self._get(f"/v1/api-keys/{key_id}")

    async def get_async(self, key_id: str) -> JSONDict:
        return await self._get_async(f"/v1/api-keys/{key_id}")

    def revoke(self, key_id: str) -> None:
        self._request("DELETE", f"/v1/api-keys/{key_id}")

    async def revoke_async(self, key_id: str) -> None:
        await self._request_async("DELETE", f"/v1/api-keys/{key_id}")
