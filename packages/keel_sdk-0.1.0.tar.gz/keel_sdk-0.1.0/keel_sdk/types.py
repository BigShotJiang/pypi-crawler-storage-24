from __future__ import annotations

from typing import Any, List, Literal, NotRequired, Required, TypedDict, Union


JSONDict = dict[str, Any]

Decision = Literal["allow", "deny", "challenge"]

ExecutionOperation = Literal[
    "generate.text",
    "embed.text",
    "generate.image",
    "edit.image",
    "understand.image",
    "generate.audio",
    "transcribe.audio",
    "generate.video",
    "understand.video",
    "call.tools",
    "run.batch",
    "run.async",
    "realtime.session",
]

ExecutionMode = Literal["sync", "stream"]

ExecutionRole = Literal["system", "user", "assistant"]

RoutingProvider = Literal["openai", "anthropic", "google", "xai", "meta"]

RoutingPriority = Literal["cheap", "balanced", "quality"]

JobStatus = Literal["submitted", "queued", "processing", "completed", "failed"]


# ---------------------------------------------------------------------------
# Permit types
# ---------------------------------------------------------------------------


class Message(TypedDict, total=False):
    role: str
    content: str
    name: NotRequired[str]
    tool_call_id: NotRequired[str]


class PermitSubject(TypedDict, total=False):
    type: Required[str]
    id: Required[str]
    attributes: dict[str, Any]


class PermitAction(TypedDict, total=False):
    name: Required[str]
    attributes: dict[str, Any]


class PermitInput(TypedDict, total=False):
    type: Required[Literal["text", "image", "audio", "video", "file", "binary", "json"]]
    source: Union[Literal["url", "upload", "base64", "asset_ref"], None]
    url: str
    filename: str
    mime_type: str
    size_bytes: int
    sha256: str
    asset_id: str
    base64_data: str
    metadata: dict[str, Any]


class RoutingTarget(TypedDict):
    provider: str
    model: str


class RoutingPreferences(TypedDict, total=False):
    priority: Union[Literal["cheap", "balanced", "quality"], None]
    task_type: str
    latency_target_ms: int
    allow_cross_provider_fallback: bool
    fallback_chain: List[RoutingTarget]


class PermitResourceAttributes(TypedDict, total=False):
    provider: Required[str]
    model: Required[str]
    operation: str
    modality: str
    execution_mode: str
    estimated_input_tokens: Required[int]
    estimated_output_tokens: Required[int]
    max_output_tokens_requested: int
    inputs: List[PermitInput]
    asset_summary: Union[dict[str, Any], None]
    routing: RoutingPreferences
    callback_url: str


class PermitResource(TypedDict, total=False):
    type: Required[str]
    id: Required[str]
    attributes: Required[PermitResourceAttributes]


class PermitContext(TypedDict, total=False):
    timestamp: str
    ip: str
    user_agent: str


class PermitConditionRule(TypedDict, total=False):
    field: Required[str]
    operator: Required[str]
    value: Any


class PermitConditions(TypedDict, total=False):
    match: Literal["all", "any"]
    rules: Required[List[PermitConditionRule]]


class PermitRequest(TypedDict, total=False):
    project_id: Required[str]
    idempotency_key: Required[str]
    subject: Required[PermitSubject]
    action: Required[PermitAction]
    resource: Required[PermitResource]
    context: PermitContext
    conditions: PermitConditions
    parent_permit_id: str
    budget_envelope_id: str
    session_id: str


class ActionMessage(TypedDict):
    type: str
    message: str


class PermitDecisionDetails(TypedDict, total=False):
    decision: Required[Decision]
    code: Required[str]
    reason: Required[str]


class RoutingDecision(TypedDict, total=False):
    decision_id: str
    decided_at: str
    requested_provider: Required[str]
    requested_model: Required[str]
    selected_provider: Required[str]
    selected_model: Required[str]
    reason_code: Required[str]
    fallback_occurred: bool
    policy_id: str
    policy_version: str
    estimated_cost_usd_micros: int
    priority: str
    task_type: str
    latency_target_ms: int
    fallback_chain: List[RoutingTarget]
    reason_metadata: Union[dict[str, Any], None]


class PermitMetadataSubject(TypedDict):
    type: str
    id: str


class PermitMetadataAction(TypedDict):
    name: str


class PermitMetadata(TypedDict, total=False):
    policy_id: Required[str]
    policy_version: Required[str]
    evaluated_at: Required[str]
    subject: Union[PermitMetadataSubject, None]
    action: Union[PermitMetadataAction, None]
    session_id: str


class PermitResponse(TypedDict, total=False):
    permit_id: Required[str]
    project_id: Required[str]
    parent_permit_id: str
    delegation_depth: int
    decision: Required[Decision]
    reason: Required[str]
    status: str
    constraints: Union[dict[str, Any], None]
    budgets: Union[dict[str, Any], None]
    actions: Required[List[ActionMessage]]
    decision_details: PermitDecisionDetails
    routing: RoutingDecision
    metadata: Required[PermitMetadata]


class PermitListParams(TypedDict, total=False):
    limit: int
    project_id: str
    before: str
    subject_id: str
    subject_type: str
    action_name: str
    start_date: str
    end_date: str
    decision: Decision


class PermitAuditItem(TypedDict, total=False):
    id: Required[str]
    project_id: Required[str]
    parent_permit_id: str
    delegation_depth: int
    subject_type: Required[str]
    subject_id: Required[str]
    action_name: Required[str]
    resource_provider: Required[str]
    resource_model: Required[str]
    resource_operation: str
    resource_modality: str
    resource_inputs_json: Union[List[dict[str, Any]], None]
    resource_attributes_json: Union[dict[str, Any], None]
    estimated_input_tokens: Required[int]
    estimated_output_tokens: Required[int]
    max_output_tokens_requested: int
    decision: Required[Decision]
    reason: Required[str]
    status: str
    constraints_json: Union[dict[str, Any], None]
    budgets_json: Union[dict[str, Any], None]
    actions_json: Required[List[dict[str, Any]]]
    decision_details: PermitDecisionDetails
    routing: RoutingDecision
    actual_usage_json: Union[dict[str, Any], None]
    policy_id: Required[str]
    policy_version: Required[str]
    metadata: Required[PermitMetadata]
    idempotency_key: Required[str]
    request_fingerprint: Required[str]
    expires_at: str
    created_at: Required[str]


class PermitAuditListResponse(TypedDict):
    items: List[PermitAuditItem]
    next_cursor: Union[str, None]


class PermitUsageReportRequest(TypedDict, total=False):
    provider: str
    model: str
    actual_input_tokens: int
    actual_output_tokens: int
    actual_total_tokens: int
    cost_usd: Union[str, float, None]
    cost_usd_micros: int
    usage_idempotency_key: str
    normalized_usage: Union[dict[str, Any], None]
    usage_metrics: Union[List[dict[str, Any]], None]
    metadata: Union[dict[str, Any], None]


class PermitUsageReportResponse(TypedDict, total=False):
    permit_id: Required[str]
    project_id: Required[str]
    usage_reported_at: str
    actual_input_tokens: int
    actual_output_tokens: int
    actual_total_tokens: int
    actual_cost_usd_micros: int
    actual_usage_json: Union[dict[str, Any], None]
    status: str


class ConditionEvaluation(TypedDict, total=False):
    outcome: Required[Literal["allow", "deny", "indeterminate"]]
    evaluated_at: Required[str]
    match: Required[Literal["all", "any"]]
    rule_count: Required[int]
    failed_rule_index: int
    code: str
    message: str
    field: str
    operator: str
    expected_value: Any
    actual_value: Any


class BudgetEnvelopeSummary(TypedDict, total=False):
    envelope_id: Required[str]
    reservation_status: str
    estimated_cost_usd_micros: int
    total_budget_usd_micros: int
    reserved_budget_usd_micros: int
    spent_budget_usd_micros: int
    remaining_budget_usd_micros: int
    correction_usd_micros: int


class PermitDryRunResponse(TypedDict, total=False):
    dry_run: Required[bool]
    project_id: Required[str]
    existing_permit_id: str
    replay_outcome: Required[str]
    parent_permit_id: str
    delegation_depth: int
    decision: Required[Decision]
    reason: Required[str]
    status: str
    constraints: Union[dict[str, Any], None]
    budgets: Union[dict[str, Any], None]
    actions: Required[List[ActionMessage]]
    decision_details: PermitDecisionDetails
    routing: RoutingDecision
    metadata: Required[PermitMetadata]
    budget_envelope: BudgetEnvelopeSummary
    condition_evaluation: ConditionEvaluation


# ---------------------------------------------------------------------------
# Permit governance types (attestation, evidence, lineage, bundle)
# ---------------------------------------------------------------------------


class PermitAttestationRequest(TypedDict, total=False):
    attestor: Required[str]
    attestation_type: Required[Literal["approve", "reject"]]
    evidence_url: str


class PermitAttestationOut(TypedDict):
    id: str
    permit_id: str
    project_id: str
    attestor: str
    attestation_type: Literal["approve", "reject"]
    evidence_url: Union[str, None]
    attested_at: str
    created_at: str


class PermitEvidenceCreateRequest(TypedDict):
    evidence_type: str
    evidence_value: str
    label: str
    attached_by: str


class PermitEvidenceOut(TypedDict):
    id: str
    permit_id: str
    project_id: str
    evidence_type: str
    evidence_value: str
    label: str
    attached_by: str
    attached_at: str


class PermitEvidenceListResponse(TypedDict):
    items: List[PermitEvidenceOut]


class PermitLineageNodeSummary(TypedDict, total=False):
    permit_id: Required[str]
    parent_permit_id: str
    delegation_depth: Required[int]
    decision: Required[Decision]
    status: str
    reason: Required[str]
    action_name: Required[str]
    resource_provider: Required[str]
    resource_model: Required[str]
    created_at: Required[str]
    expires_at: str
    usage_reported_at: str
    actual_total_tokens: int
    actual_cost_usd_micros: int


class PermitLineageNode(TypedDict, total=False):
    permit_id: Required[str]
    parent_permit_id: str
    delegation_depth: Required[int]
    decision: Required[Decision]
    status: str
    reason: Required[str]
    action_name: Required[str]
    resource_provider: Required[str]
    resource_model: Required[str]
    created_at: Required[str]
    expires_at: str
    usage_reported_at: str
    actual_total_tokens: int
    actual_cost_usd_micros: int
    children: List[dict[str, Any]]


class PermitLineageResponse(TypedDict, total=False):
    project_id: Required[str]
    root_permit_id: Required[str]
    current_permit_id: Required[str]
    parent: PermitLineageNodeSummary
    ancestors: Required[List[PermitLineageNodeSummary]]
    current: Required[PermitLineageNode]


class PermitAuditBundle(TypedDict, total=False):
    bundle_type: Required[str]
    schema_version: Required[int]
    format: Required[str]
    project_id: Required[str]
    permit_id: Required[str]
    generated_at: Required[str]
    record: Required[dict[str, Any]]
    governance_events: List[dict[str, Any]]


# ---------------------------------------------------------------------------
# API Key types
# ---------------------------------------------------------------------------


class ApiKeyCreateRequest(TypedDict, total=False):
    name: str
    description: str
    scope: Literal["admin", "client"]
    created_by: str
    expires_at: str


class ApiKeyRecord(TypedDict, total=False):
    id: Required[str]
    project_id: Required[str]
    prefix: Required[str]
    name: str
    description: str
    scope: str
    created_by: str
    created_at: Required[str]
    revoked_at: str
    last_used_at: str
    expires_at: str


class ApiKeyCreateResponse(TypedDict, total=False):
    id: Required[str]
    project_id: Required[str]
    prefix: Required[str]
    raw_key: Required[str]
    name: str
    description: str
    scope: str
    created_by: str
    created_at: Required[str]
    expires_at: str


class ApiKeyListResponse(TypedDict):
    items: List[ApiKeyRecord]
    next_cursor: Union[str, None]


# ---------------------------------------------------------------------------
# Execution types
# ---------------------------------------------------------------------------


class ExecutionMessage(TypedDict, total=False):
    role: Required[ExecutionRole]
    content: Required[str]


class ExecutionAssetInput(TypedDict, total=False):
    source: Required[Literal["url", "upload", "base64", "asset_ref"]]
    url: str
    asset_id: str
    base64_data: str
    mime_type: str
    filename: str
    size_bytes: int
    metadata: dict[str, Any]


class ExecutionInputPart(TypedDict, total=False):
    type: Required[Literal["text", "json", "image", "audio", "video", "file", "binary"]]
    role: ExecutionRole
    text: str
    json: Union[dict[str, Any], None]
    asset: ExecutionAssetInput
    metadata: dict[str, Any]


class ExecutionRoutingInput(TypedDict, total=False):
    provider: RoutingProvider
    model: str
    priority: RoutingPriority
    task_type: str
    latency_target_ms: int
    allow_cross_provider_fallback: bool
    fallback_chain: List[RoutingTarget]


class ExecutionParameters(TypedDict, total=False):
    max_output_tokens: int
    temperature: float
    top_p: float


class ExecutionCreateRequest(TypedDict, total=False):
    operation: Required[ExecutionOperation]
    mode: ExecutionMode
    messages: List[ExecutionMessage]
    inputs: List[ExecutionInputPart]
    routing: ExecutionRoutingInput
    parameters: ExecutionParameters
    provider_options: dict[str, dict[str, Any]]


class ExecuteRequest(TypedDict, total=False):
    provider: str
    model: Required[str]
    input: Required[dict[str, Any]]


class ExecutionOutputPart(TypedDict, total=False):
    type: str
    text: str
    json: Union[dict[str, Any], None]
    asset_id: str
    metadata: dict[str, Any]


class ExecutionOutput(TypedDict, total=False):
    parts: List[ExecutionOutputPart]


class ExecutionUsage(TypedDict, total=False):
    input_tokens: int
    output_tokens: int
    total_tokens: int
    cost_usd_micros: int


class ExecutionTiming(TypedDict, total=False):
    total_ms: int
    permit_ms: int
    routing_ms: int
    dispatch_ms: int


class ExecutionErrorPayload(TypedDict, total=False):
    code: Required[str]
    message: Required[str]
    provider_code: str


class ExecutionRoutingResult(TypedDict, total=False):
    provider: str
    model: str
    reason_code: str
    fallback_occurred: bool


class ExecutionGovernance(TypedDict, total=False):
    permit_id: str
    decision: Decision
    policy_id: str
    policy_version: str


class ExecutionResolved(TypedDict, total=False):
    provider: str
    model: str
    operation: str


class ExecutionResponse(TypedDict, total=False):
    id: Required[str]
    object: str
    created_at: str
    status: Required[str]
    status_code: int
    output: ExecutionOutput
    output_assets: List[dict[str, Any]]
    routing: ExecutionRoutingResult
    governance: ExecutionGovernance
    usage: ExecutionUsage
    timing: ExecutionTiming
    error: ExecutionErrorPayload
    resolved: ExecutionResolved


# ---------------------------------------------------------------------------
# Streaming types
# ---------------------------------------------------------------------------


class ExecutionStartedEvent(TypedDict, total=False):
    id: Required[str]
    status: Required[str]
    routing: ExecutionRoutingResult
    governance: ExecutionGovernance
    resolved: ExecutionResolved


class ExecutionContentDelta(TypedDict, total=False):
    index: int
    type: str
    text: str


class ExecutionDone(TypedDict, total=False):
    id: Required[str]
    status: Required[str]
    output: ExecutionOutput
    usage: ExecutionUsage
    timing: ExecutionTiming
    error: ExecutionErrorPayload


class StreamEvent(TypedDict):
    event_type: str
    data: dict[str, Any]


# ---------------------------------------------------------------------------
# Job types
# ---------------------------------------------------------------------------


class JobSubmitRequest(TypedDict, total=False):
    permit: Required[dict[str, Any]]
    provider_payload: dict[str, Any]
    metadata: dict[str, Any]


class JobCreateResponse(TypedDict, total=False):
    job_id: Required[str]
    status: Required[JobStatus]
    execution_mode: Required[str]
    submitted_at: Required[str]
    permit_id: str


class JobStatusResponse(TypedDict, total=False):
    job_id: Required[str]
    request_id: Required[str]
    permit_id: str
    provider: Required[str]
    model: Required[str]
    operation: Required[str]
    execution_mode: Required[str]
    status: Required[JobStatus]
    progress: float
    callback_url: str
    submitted_at: Required[str]
    started_at: str
    completed_at: str
    result_assets: List[dict[str, Any]]
    usage_metrics: List[dict[str, Any]]
    error: Union[dict[str, Any], None]
    metadata: Union[dict[str, Any], None]


# ---------------------------------------------------------------------------
# Timeline types
# ---------------------------------------------------------------------------


class RequestTimelineEvent(TypedDict, total=False):
    timestamp: Required[str]
    event_type: Required[str]
    source: Required[str]
    phase: Required[str]
    provider: str
    model: str
    permit_id: str
    request_id: str
    job_id: str
    session_id: str
    metadata: Union[dict[str, Any], None]


class RequestTimelineResponse(TypedDict):
    project_id: str
    request_id: str
    permit_ids: List[str]
    job_ids: List[str]
    session_ids: List[str]
    events: List[RequestTimelineEvent]


class ExecutionTimelinePermit(TypedDict, total=False):
    decision: str
    timestamp: str


class ExecutionTimelineRouting(TypedDict, total=False):
    provider: str
    model: str
    fallback_chain: List[RoutingTarget]


class ExecutionTimelineQueue(TypedDict, total=False):
    job_id: str
    status: str
    attempts: int


class ExecutionTimelineExecution(TypedDict, total=False):
    started_at: str
    completed_at: str
    latency_ms: int


class ExecutionTimelineUsage(TypedDict, total=False):
    input_tokens: int
    output_tokens: int
    cost_usd: float


class ExecutionTimelineResponse(TypedDict):
    request_id: str
    permit: ExecutionTimelinePermit
    routing: ExecutionTimelineRouting
    queue: ExecutionTimelineQueue
    execution: ExecutionTimelineExecution
    usage: ExecutionTimelineUsage
