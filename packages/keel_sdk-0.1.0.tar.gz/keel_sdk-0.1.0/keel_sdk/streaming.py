from __future__ import annotations

import json
from typing import Any, AsyncIterator, Iterator

import httpx


def parse_sse_stream(response: httpx.Response) -> Iterator[dict[str, Any]]:
    """Parse Server-Sent Events from a sync httpx streaming response."""
    current_event = "message"
    data_lines: list[str] = []

    for raw_line in response.iter_lines():
        line = raw_line.rstrip("\r")

        if line == "":
            if data_lines:
                yield _decode_event(current_event, "\n".join(data_lines))
                data_lines = []
                current_event = "message"
            continue

        if line.startswith(":"):
            continue

        if line.startswith("event:"):
            current_event = line[6:].lstrip()
        elif line.startswith("data:"):
            data_lines.append(line[5:].lstrip())

    if data_lines:
        yield _decode_event(current_event, "\n".join(data_lines))


async def parse_sse_stream_async(
    response: httpx.Response,
) -> AsyncIterator[dict[str, Any]]:
    """Parse Server-Sent Events from an async httpx streaming response."""
    current_event = "message"
    data_lines: list[str] = []

    async for raw_line in response.aiter_lines():
        line = raw_line.rstrip("\r")

        if line == "":
            if data_lines:
                yield _decode_event(current_event, "\n".join(data_lines))
                data_lines = []
                current_event = "message"
            continue

        if line.startswith(":"):
            continue

        if line.startswith("event:"):
            current_event = line[6:].lstrip()
        elif line.startswith("data:"):
            data_lines.append(line[5:].lstrip())

    if data_lines:
        yield _decode_event(current_event, "\n".join(data_lines))


def _decode_event(event_type: str, data_str: str) -> dict[str, Any]:
    try:
        data = json.loads(data_str)
    except (json.JSONDecodeError, ValueError):
        data = data_str
    return {"event_type": event_type, "data": data}
