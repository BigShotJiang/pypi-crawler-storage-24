from __future__ import annotations

import secrets
import time
import warnings
from typing import Any, AsyncIterator, Iterator, Mapping

import httpx

from .clients.api_keys import ApiKeysClient
from .clients.executions import ExecutionsClient
from .clients.execute import ExecuteClient
from .clients.jobs import JobsClient
from .clients.permits import PermitsClient
from .clients.proxy import ProxyClient
from .clients.requests import RequestsClient
from .errors import KeelError
from .streaming import parse_sse_stream, parse_sse_stream_async
from .types import JSONDict, Message


class KeelClient:
    permits: PermitsClient
    executions: ExecutionsClient
    execute: ExecuteClient
    proxy: ProxyClient
    jobs: JobsClient
    requests: RequestsClient
    api_keys: ApiKeysClient

    def __init__(
        self,
        base_url: str,
        api_key: str,
        request_freshness: bool = False,
        *,
        timeout: float = 30.0,
        transport: httpx.BaseTransport | None = None,
        async_transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.request_freshness = request_freshness
        self._sync_client = httpx.Client(
            base_url=self.base_url, timeout=timeout, transport=transport
        )
        self._async_client = httpx.AsyncClient(
            base_url=self.base_url, timeout=timeout, transport=async_transport
        )

        self.permits = PermitsClient(self.request, self.request_async, self._get, self._get_async)
        self.executions = ExecutionsClient(
            self.request, self.request_async,
            self._get, self._get_async,
            self._stream, self._stream_async,
        )
        self.execute = ExecuteClient(self.request, self.request_async)
        self.proxy = ProxyClient(self.request, self.request_async)
        self.jobs = JobsClient(self.request, self.request_async, self._get, self._get_async)
        self.requests = RequestsClient(self._get, self._get_async)
        self.api_keys = ApiKeysClient(self.request, self.request_async, self._get, self._get_async)

    def _build_headers(self, headers: Mapping[str, str] | None = None) -> dict[str, str]:
        merged = dict(headers or {})
        merged["Authorization"] = f"Bearer {self.api_key}"

        if self.request_freshness:
            merged["X-Keel-Timestamp"] = str(int(time.time()))
            merged["X-Keel-Nonce"] = secrets.token_urlsafe(16)

        return merged

    @staticmethod
    def _normalize_path(path: str) -> str:
        if path.startswith("http://") or path.startswith("https://"):
            return path
        return f"/{path.lstrip('/')}"

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        if response.is_success:
            return
        try:
            body = response.json()
            err = body.get("error", {})
            code = err.get("code", "unknown_error")
            message = err.get("message", response.text)
            field = err.get("field")
        except Exception:
            code = "unknown_error"
            message = response.text
            field = None
        raise KeelError(response.status_code, code, message, field)

    @staticmethod
    def _response_to_dict(response: httpx.Response) -> JSONDict:
        if not response.content:
            return {}
        return response.json()

    def request(
        self,
        method: str,
        path: str,
        json: JSONDict | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> JSONDict:
        response = self._sync_client.request(
            method=method.upper(),
            url=self._normalize_path(path),
            json=json,
            headers=self._build_headers(headers),
        )
        self._raise_for_status(response)
        return self._response_to_dict(response)

    async def request_async(
        self,
        method: str,
        path: str,
        json: JSONDict | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> JSONDict:
        response = await self._async_client.request(
            method=method.upper(),
            url=self._normalize_path(path),
            json=json,
            headers=self._build_headers(headers),
        )
        self._raise_for_status(response)
        return self._response_to_dict(response)

    def _get(
        self,
        path: str,
        params: dict[str, str] | None = None,
    ) -> JSONDict:
        response = self._sync_client.request(
            method="GET",
            url=self._normalize_path(path),
            params=params,
            headers=self._build_headers(),
        )
        self._raise_for_status(response)
        return self._response_to_dict(response)

    async def _get_async(
        self,
        path: str,
        params: dict[str, str] | None = None,
    ) -> JSONDict:
        response = await self._async_client.request(
            method="GET",
            url=self._normalize_path(path),
            params=params,
            headers=self._build_headers(),
        )
        self._raise_for_status(response)
        return self._response_to_dict(response)

    def _stream(
        self,
        method: str,
        path: str,
        json: JSONDict | None = None,
    ) -> Iterator[dict[str, Any]]:
        with self._sync_client.stream(
            method=method.upper(),
            url=self._normalize_path(path),
            json=json,
            headers=self._build_headers(),
        ) as response:
            self._raise_for_status(response)
            yield from parse_sse_stream(response)

    async def _stream_async(
        self,
        method: str,
        path: str,
        json: JSONDict | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        async with self._async_client.stream(
            method=method.upper(),
            url=self._normalize_path(path),
            json=json,
            headers=self._build_headers(),
        ) as response:
            self._raise_for_status(response)
            async for event in parse_sse_stream_async(response):
                yield event

    def create_canonical_permit(self, permit_request: JSONDict) -> JSONDict:
        """Canonical permit helper for POST /v1/permits."""
        return self.permits.create(permit_request)

    async def create_canonical_permit_async(
        self,
        permit_request: JSONDict,
    ) -> JSONDict:
        """Async canonical permit helper for POST /v1/permits."""
        return await self.permits.create_async(permit_request)

    def create_permit(
        self,
        project_id: str,
        provider: str,
        model: str,
        messages: list[Message],
        idempotency_key: str,
        **kwargs: Any,
    ) -> JSONDict:
        """Compatibility helper for the path-scoped permits route."""
        warnings.warn(
            "create_permit() uses the deprecated /v1/projects/{project_id}/permits route. "
            "Use create_canonical_permit() or client.permits.create() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        body: JSONDict = {
            "provider": provider,
            "model": model,
            "messages": messages,
            "idempotency_key": idempotency_key,
            **kwargs,
        }
        return self.request("POST", f"/v1/projects/{project_id}/permits", json=body)

    async def create_permit_async(
        self,
        project_id: str,
        provider: str,
        model: str,
        messages: list[Message],
        idempotency_key: str,
        **kwargs: Any,
    ) -> JSONDict:
        """Async compatibility helper for the path-scoped permits route."""
        warnings.warn(
            "create_permit_async() uses the deprecated /v1/projects/{project_id}/permits route. "
            "Use create_canonical_permit_async() or client.permits.create_async() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        body: JSONDict = {
            "provider": provider,
            "model": model,
            "messages": messages,
            "idempotency_key": idempotency_key,
            **kwargs,
        }
        return await self.request_async(
            "POST", f"/v1/projects/{project_id}/permits", json=body
        )

    def close(self) -> None:
        self._sync_client.close()

    async def aclose(self) -> None:
        await self._async_client.aclose()

    def __enter__(self) -> KeelClient:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    async def __aenter__(self) -> KeelClient:
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.aclose()
