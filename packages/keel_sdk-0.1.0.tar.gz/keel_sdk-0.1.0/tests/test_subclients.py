from __future__ import annotations

import json

import httpx
import pytest

from keel_sdk import KeelClient


def _handler(expected_method: str, expected_path: str, response_json: dict):
    """Create a mock transport handler that validates method/path and returns JSON."""
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == expected_method
        assert expected_path in str(request.url)
        return httpx.Response(200, json=response_json)
    return handler


def _make_client(handler) -> KeelClient:
    transport = httpx.MockTransport(handler)
    return KeelClient(
        base_url="https://api.keel.test",
        api_key="keel_sk_test",
        transport=transport,
        async_transport=httpx.MockTransport(handler),
    )


PERMIT_RESPONSE = {
    "permit_id": "pmt_1",
    "project_id": "prj_1",
    "decision": "allow",
    "reason": "ok",
    "actions": [],
    "metadata": {"policy_id": "p1", "policy_version": "1", "evaluated_at": "2026-01-01T00:00:00Z"},
}

PERMIT_REQUEST = {
    "project_id": "prj_1",
    "idempotency_key": "idem_1",
    "subject": {"type": "user", "id": "u1"},
    "action": {"name": "chat"},
    "resource": {
        "type": "request",
        "id": "r1",
        "attributes": {
            "provider": "openai",
            "model": "gpt-4o-mini",
            "estimated_input_tokens": 10,
            "estimated_output_tokens": 20,
        },
    },
}


class TestPermitsClient:
    def test_create(self):
        client = _make_client(_handler("POST", "/v1/permits", PERMIT_RESPONSE))
        result = client.permits.create(PERMIT_REQUEST)
        assert result["permit_id"] == "pmt_1"
        assert result["decision"] == "allow"

    def test_dry_run(self):
        resp = {**PERMIT_RESPONSE, "dry_run": True, "replay_outcome": "fresh"}
        client = _make_client(_handler("POST", "/v1/permits/dry-run", resp))
        result = client.permits.dry_run(PERMIT_REQUEST)
        assert result["dry_run"] is True
        assert result["replay_outcome"] == "fresh"

    def test_list(self):
        resp = {"items": [], "next_cursor": None}
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/v1/permits" in str(request.url)
            assert "limit=10" in str(request.url)
            return httpx.Response(200, json=resp)

        client = _make_client(handler)
        result = client.permits.list(limit=10, decision="allow")
        assert result["items"] == []

    def test_get(self):
        item = {
            "id": "pmt_1", "project_id": "prj_1",
            "subject_type": "user", "subject_id": "u1",
            "action_name": "chat", "resource_provider": "openai",
            "resource_model": "gpt-4o-mini",
            "estimated_input_tokens": 10, "estimated_output_tokens": 20,
            "decision": "allow", "reason": "ok", "actions_json": [],
            "policy_id": "p1", "policy_version": "1",
            "metadata": {"policy_id": "p1", "policy_version": "1", "evaluated_at": "2026-01-01T00:00:00Z"},
            "idempotency_key": "i1", "request_fingerprint": "f1", "created_at": "2026-01-01T00:00:00Z",
        }
        client = _make_client(_handler("GET", "/v1/permits/pmt_1", item))
        result = client.permits.get("pmt_1")
        assert result["id"] == "pmt_1"

    def test_report_usage(self):
        resp = {"permit_id": "pmt_1", "project_id": "prj_1", "actual_input_tokens": 100}
        client = _make_client(_handler("POST", "/v1/permits/pmt_1/usage", resp))
        result = client.permits.report_usage("pmt_1", {"actual_input_tokens": 100})
        assert result["actual_input_tokens"] == 100

    def test_export(self):
        resp = {"bundle_type": "audit", "records": []}
        client = _make_client(_handler("GET", "/v1/permits/export", resp))
        result = client.permits.export(from_="2026-01-01T00:00:00+00:00", to="2026-02-01T00:00:00+00:00")
        assert result["bundle_type"] == "audit"


class TestExecutionsClient:
    def test_create(self):
        resp = {
            "id": "exec_1", "object": "execution", "status": "completed",
            "status_code": 200, "output": {"parts": [{"type": "text", "text": "Hi"}]},
            "routing": {"provider": "openai", "model": "gpt-4o-mini"},
            "timing": {"total_ms": 100},
        }
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["mode"] == "sync"
            return httpx.Response(200, json=resp)

        client = _make_client(handler)
        result = client.executions.create({"operation": "generate.text"})
        assert result["id"] == "exec_1"

    def test_get(self):
        resp = {
            "request_id": "req_1",
            "permit": {"decision": "allow"},
            "routing": {"provider": "openai"},
            "queue": {},
            "execution": {"latency_ms": 100},
            "usage": {"input_tokens": 10},
        }
        client = _make_client(_handler("GET", "/v1/executions/req_1", resp))
        result = client.executions.get("req_1")
        assert result["request_id"] == "req_1"


class TestExecuteClient:
    def test_run(self):
        resp = {
            "id": "exec_1", "object": "execution", "status": "completed",
            "status_code": 200, "routing": {}, "timing": {},
        }
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["model"] == "gpt-4o-mini"
            return httpx.Response(200, json=resp)

        client = _make_client(handler)
        result = client.execute.run({"model": "gpt-4o-mini", "input": {"messages": []}})
        assert result["id"] == "exec_1"


class TestProxyClient:
    @pytest.mark.parametrize("provider", ["openai", "anthropic", "google", "xai", "meta"])
    def test_proxy_routes(self, provider: str):
        resp = {"id": f"{provider}_1", "result": "ok"}
        client = _make_client(_handler("POST", f"/v1/proxy/{provider}", resp))
        method = getattr(client.proxy, provider)
        result = method({"model": "test", "messages": []})
        assert result["id"] == f"{provider}_1"


class TestJobsClient:
    def test_create(self):
        resp = {"job_id": "job_1", "status": "submitted", "execution_mode": "async", "submitted_at": "2026-01-01T00:00:00Z"}
        client = _make_client(_handler("POST", "/v1/jobs", resp))
        result = client.jobs.create({"permit": PERMIT_REQUEST, "provider_payload": {}})
        assert result["job_id"] == "job_1"
        assert result["status"] == "submitted"

    def test_get(self):
        resp = {
            "job_id": "job_1", "request_id": "req_1", "provider": "openai",
            "model": "gpt-4o-mini", "operation": "generate.text",
            "execution_mode": "async", "status": "completed",
            "submitted_at": "2026-01-01T00:00:00Z",
        }
        client = _make_client(_handler("GET", "/v1/jobs/job_1", resp))
        result = client.jobs.get("job_1")
        assert result["status"] == "completed"


class TestRequestsClient:
    def test_timeline(self):
        resp = {
            "project_id": "prj_1", "request_id": "req_1",
            "permit_ids": ["pmt_1"], "job_ids": [], "session_ids": [],
            "events": [{"timestamp": "2026-01-01T00:00:00Z", "event_type": "permit.created", "source": "permits", "phase": "permit"}],
        }
        client = _make_client(_handler("GET", "/v1/requests/req_1/timeline", resp))
        result = client.requests.timeline("req_1")
        assert result["request_id"] == "req_1"
        assert len(result["events"]) == 1


class TestBackwardCompat:
    def test_create_canonical_permit_delegates(self):
        client = _make_client(_handler("POST", "/v1/permits", PERMIT_RESPONSE))
        result = client.create_canonical_permit(PERMIT_REQUEST)
        assert result["permit_id"] == "pmt_1"
