from __future__ import annotations

import asyncio
import json
import warnings

import httpx
import pytest

from keel_sdk import (
    KeelClient,
    KeelError,
    PermitSubject,
    PermitAction,
    PermitResourceAttributes,
    PermitResource,
    PermitRequest,
    PermitResponse,
    ActionMessage,
    PermitMetadata,
)


def test_create_canonical_permit_sends_expected_payload_and_auth() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/v1/permits"
        assert request.headers["Authorization"] == "Bearer test-key"

        payload = json.loads(request.content.decode("utf-8"))
        assert payload == {
            "project_id": "proj_123",
            "idempotency_key": "idem-1",
            "subject": {"type": "user", "id": "usr_1", "attributes": {}},
            "action": {"name": "ai.generate.summary", "attributes": {}},
            "resource": {
                "type": "request",
                "id": "req_1",
                "attributes": {
                    "provider": "openai",
                    "model": "gpt-4o-mini",
                    "estimated_input_tokens": 12,
                    "estimated_output_tokens": 8,
                    "max_output_tokens_requested": 16,
                },
            },
        }
        return httpx.Response(200, json={"permit_id": "permit_1"})

    client = KeelClient(
        base_url="https://api.keel.example",
        api_key="test-key",
        transport=httpx.MockTransport(handler),
    )

    result = client.create_canonical_permit(
        {
            "project_id": "proj_123",
            "idempotency_key": "idem-1",
            "subject": {"type": "user", "id": "usr_1", "attributes": {}},
            "action": {"name": "ai.generate.summary", "attributes": {}},
            "resource": {
                "type": "request",
                "id": "req_1",
                "attributes": {
                    "provider": "openai",
                    "model": "gpt-4o-mini",
                    "estimated_input_tokens": 12,
                    "estimated_output_tokens": 8,
                    "max_output_tokens_requested": 16,
                },
            },
        }
    )
    client.close()

    assert result == {"permit_id": "permit_1"}


def test_create_permit_sends_expected_payload_and_auth() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/v1/projects/proj_123/permits"
        assert request.headers["Authorization"] == "Bearer test-key"

        payload = json.loads(request.content.decode("utf-8"))
        assert payload["provider"] == "openai"
        assert payload["model"] == "gpt-4o-mini"
        assert payload["messages"] == [{"role": "user", "content": "hello"}]
        assert payload["idempotency_key"] == "idem-1"
        assert payload["temperature"] == 0.2
        return httpx.Response(200, json={"permit_id": "permit_1"})

    client = KeelClient(
        base_url="https://api.keel.example",
        api_key="test-key",
        transport=httpx.MockTransport(handler),
    )

    with warnings.catch_warnings(record=True):
        warnings.simplefilter("always")
        result = client.create_permit(
            project_id="proj_123",
            provider="openai",
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "hello"}],
            idempotency_key="idem-1",
            temperature=0.2,
        )
    client.close()

    assert result == {"permit_id": "permit_1"}


def test_request_adds_freshness_headers_when_enabled() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        timestamp = request.headers.get("X-Keel-Timestamp")
        nonce = request.headers.get("X-Keel-Nonce")

        assert timestamp is not None and timestamp.isdigit()
        assert nonce is not None and len(nonce) >= 16
        return httpx.Response(200, json={"ok": True})

    client = KeelClient(
        base_url="https://api.keel.example",
        api_key="test-key",
        request_freshness=True,
        transport=httpx.MockTransport(handler),
    )
    result = client.request("GET", "/v1/health")
    client.close()

    assert result == {"ok": True}


def test_request_does_not_add_freshness_headers_when_disabled() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert "X-Keel-Timestamp" not in request.headers
        assert "X-Keel-Nonce" not in request.headers
        return httpx.Response(200, json={"ok": True})

    client = KeelClient(
        base_url="https://api.keel.example",
        api_key="test-key",
        request_freshness=False,
        transport=httpx.MockTransport(handler),
    )
    result = client.request("GET", "/v1/health")
    client.close()

    assert result == {"ok": True}


def test_request_allows_custom_idempotency_header() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["Idempotency-Key"] == "proxy-idem-1"
        return httpx.Response(200, json={"allowed": True})

    client = KeelClient(
        base_url="https://api.keel.example",
        api_key="test-key",
        transport=httpx.MockTransport(handler),
    )
    result = client.request(
        "POST",
        "/v1/gateway/permit-check",
        json={"foo": "bar"},
        headers={"Idempotency-Key": "proxy-idem-1"},
    )
    client.close()

    assert result == {"allowed": True}


def test_async_request_and_create_permit() -> None:
    async def run() -> None:
        calls: list[str] = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            if request.url.path == "/v1/ping":
                return httpx.Response(200, json={"pong": True})
            if request.url.path == "/v1/permits":
                body = json.loads(request.content.decode("utf-8"))
                assert body["idempotency_key"] == "idem-canonical-async"
                return httpx.Response(200, json={"permit_id": "permit_canonical_async"})
            if request.url.path == "/v1/projects/proj_a/permits":
                body = json.loads(request.content.decode("utf-8"))
                assert body["idempotency_key"] == "idem-async"
                return httpx.Response(200, json={"permit_id": "permit_async"})
            return httpx.Response(404, json={"error": {"code": "not_found", "message": "not found"}})

        client = KeelClient(
            base_url="https://api.keel.example",
            api_key="test-key",
            async_transport=httpx.MockTransport(handler),
        )
        ping = await client.request_async("GET", "/v1/ping")
        canonical_permit = await client.create_canonical_permit_async(
            {
                "project_id": "proj_a",
                "idempotency_key": "idem-canonical-async",
                "subject": {"type": "user", "id": "usr_async"},
                "action": {"name": "ai.generate.summary"},
                "resource": {
                    "type": "request",
                    "id": "req_async",
                    "attributes": {
                        "provider": "openai",
                        "model": "gpt-4o-mini",
                        "estimated_input_tokens": 10,
                        "estimated_output_tokens": 5,
                    },
                },
            }
        )
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            permit = await client.create_permit_async(
                project_id="proj_a",
                provider="openai",
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "hello"}],
                idempotency_key="idem-async",
            )
        await client.aclose()

        assert ping == {"pong": True}
        assert canonical_permit == {"permit_id": "permit_canonical_async"}
        assert permit == {"permit_id": "permit_async"}
        assert calls == ["/v1/ping", "/v1/permits", "/v1/projects/proj_a/permits"]

    asyncio.run(run())


def test_keel_error_on_api_error_with_json_body() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            422,
            json={"error": {"code": "validation_error", "message": "bad input", "field": "model"}},
        )

    client = KeelClient(
        base_url="https://api.keel.example",
        api_key="test-key",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(KeelError) as exc_info:
        client.request("POST", "/v1/permits", json={})
    client.close()

    err = exc_info.value
    assert err.status == 422
    assert err.code == "validation_error"
    assert err.message == "bad input"
    assert err.field == "model"


def test_keel_error_on_api_error_with_non_json_body() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="Internal Server Error")

    client = KeelClient(
        base_url="https://api.keel.example",
        api_key="test-key",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(KeelError) as exc_info:
        client.request("GET", "/v1/health")
    client.close()

    err = exc_info.value
    assert err.status == 500
    assert err.code == "unknown_error"
    assert err.message == "Internal Server Error"
    assert err.field is None


def test_keel_error_on_async_api_error() -> None:
    async def run() -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                403,
                json={"error": {"code": "forbidden", "message": "not allowed"}},
            )

        client = KeelClient(
            base_url="https://api.keel.example",
            api_key="test-key",
            async_transport=httpx.MockTransport(handler),
        )

        with pytest.raises(KeelError) as exc_info:
            await client.request_async("GET", "/v1/something")
        await client.aclose()

        err = exc_info.value
        assert err.status == 403
        assert err.code == "forbidden"
        assert err.message == "not allowed"
        assert err.field is None

    asyncio.run(run())


def test_response_to_dict_returns_json_directly() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=[1, 2, 3])

    client = KeelClient(
        base_url="https://api.keel.example",
        api_key="test-key",
        transport=httpx.MockTransport(handler),
    )
    result = client.request("GET", "/v1/test")
    client.close()

    assert result == [1, 2, 3]


def test_create_permit_emits_deprecation_warning() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"permit_id": "p1"})

    client = KeelClient(
        base_url="https://api.keel.example",
        api_key="test-key",
        transport=httpx.MockTransport(handler),
    )

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        client.create_permit(
            project_id="proj_1",
            provider="openai",
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "hi"}],
            idempotency_key="k1",
        )

    client.close()

    assert len(w) == 1
    assert issubclass(w[0].category, DeprecationWarning)
    assert "create_permit()" in str(w[0].message)
    assert "create_canonical_permit()" in str(w[0].message)


def test_create_permit_async_emits_deprecation_warning() -> None:
    async def run() -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"permit_id": "p1"})

        client = KeelClient(
            base_url="https://api.keel.example",
            api_key="test-key",
            async_transport=httpx.MockTransport(handler),
        )

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            await client.create_permit_async(
                project_id="proj_1",
                provider="openai",
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "hi"}],
                idempotency_key="k1",
            )

        await client.aclose()

        assert len(w) == 1
        assert issubclass(w[0].category, DeprecationWarning)
        assert "create_permit_async()" in str(w[0].message)
        assert "create_canonical_permit_async()" in str(w[0].message)

    asyncio.run(run())


def test_typed_models_can_be_constructed() -> None:
    subject: PermitSubject = {"type": "user", "id": "usr_1"}
    assert subject["type"] == "user"

    action: PermitAction = {"name": "ai.generate.summary"}
    assert action["name"] == "ai.generate.summary"

    attrs: PermitResourceAttributes = {
        "provider": "openai",
        "model": "gpt-4o-mini",
        "estimated_input_tokens": 10,
        "estimated_output_tokens": 5,
    }
    assert attrs["provider"] == "openai"

    resource: PermitResource = {"type": "request", "id": "req_1", "attributes": attrs}
    assert resource["attributes"]["model"] == "gpt-4o-mini"

    meta: PermitMetadata = {
        "policy_id": "pol_1",
        "policy_version": "v1",
        "evaluated_at": "2026-01-01T00:00:00Z",
    }

    action_msg: ActionMessage = {"type": "info", "message": "ok"}

    resp: PermitResponse = {
        "permit_id": "permit_1",
        "project_id": "proj_1",
        "decision": "allow",
        "reason": "policy matched",
        "actions": [action_msg],
        "metadata": meta,
    }
    assert resp["decision"] == "allow"
