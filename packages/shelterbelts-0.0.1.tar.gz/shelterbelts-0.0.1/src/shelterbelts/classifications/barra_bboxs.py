# +
import os
import glob
from pathlib import Path
import geopandas as gpd
from shapely.prepared import prep
from shapely.geometry import box, Polygon

import rioxarray as rxr
import xarray as xr
import numpy as np

from shelterbelts.utils.filepaths import (
    barra_bboxs_dir,
    barra_bboxs_full,
    state_boundaries,
    aus_boundaries,
    elvis_outputs_dir
)

def single_boundary():
    """Creating a single boundary for NSW (missing jervis bay)"""
    gdf = gpd.read_file(state_boundaries)
    multipolygon = gdf.iloc[0]['geometry']
    largest_polygon = max(multipolygon.geoms, key=lambda p: p.area)
    polygon_no_holes = Polygon(largest_polygon.exterior)
    gdf_no_holes = gpd.GeoDataFrame(
        [gdf.iloc[0].to_dict()],  # Copy all the attributes from the original row
        geometry=[polygon_no_holes],
        crs=gdf.crs  # Preserve the coordinate reference system
    )
    gdf_no_holes.to_file('/Users/christopherbradley/Documents/PHD/Data/Australia_datasets/NSW_Border_Largest_Polygon.shp')


# +
def geopackage_km(filename_state_boundaries, state='New South Wales', tile_size=30000, crs=7855, outdir=elvis_outputs_dir):
    """Create a geopackage of bounding boxes of a given size covering a given area for ELVIS downloads"""
    gdf2 = gpd.read_file(filename_state_boundaries)
    nsw = gdf2.loc[gdf2['STE_NAME21'] == state].to_crs(crs)
    
    minx, miny, maxx, maxy = nsw.total_bounds
    if state == 'New South Wales':
        minx, miny, maxx, maxy = -85000, 5845000, 1250000, 6870000  # These are nicer boundaries for NSW. Will need to unhardcode if I want to reuse for other states. 
        # minx, miny, maxx, maxy = -84000, 5844000, 1250000, 6870000  # Exactly matching up with the 2kmx2km NSW grid

    xs = np.arange(minx, maxx, tile_size)
    ys = np.arange(miny, maxy, tile_size)
    
    tiles = [box(x, y, x + tile_size, y + tile_size) for y in ys for x in xs]
    grid = gpd.GeoDataFrame(geometry=tiles, crs=nsw.crs)
    
    # Keep only tiles that intersect NSW
    geom = nsw.union_all()
    geom_prep = prep(geom)
    mask = grid.geometry.map(geom_prep.intersects)
    grid_in_nsw = grid[mask]
    print("Number of tiles:", len(grid_in_nsw))
    
    outdir_geojsons = os.path.join(outdir, f"geojsons_{tile_size}")
    os.makedirs(outdir_geojsons, exist_ok=True)
    
    filenames = []
    grid_in_nsw = grid_in_nsw.reset_index(drop=True)
    for idx, row in grid_in_nsw.iterrows():
        centroid = row.geometry.centroid
        cx, cy = map(int, (centroid.x, centroid.y))  # round or cast to int for filenames
        filename = f"{outdir_geojsons}/tile{idx}_{cx}_{cy}.geojson"
        filenames.append(f'tile{idx}_{cx}_{cy}')
        gdf = gpd.GeoDataFrame([row], crs=grid_in_nsw.crs).to_crs(4326)
        gdf.to_file(filename, driver="GeoJSON")
        if idx % 100 == 0:
            print('Saved:', filename)
    
    grid_in_nsw["filename"] = filenames
    filename = os.path.join(outdir, f'tiles_{tile_size}_{state.replace(" ", "_")}.gpkg')
    grid_in_nsw.to_file(filename, driver="GPKG")
    print('Saved:', filename)

# filename_state_boundaries = '/g/data/xe2/cb8590/Outlines/STE_2021_AUST_GDA2020.shp'
# geopackage_km(filename_state_boundaries, tile_size=30000)


# +
def pixel_bbox(i, j, transform):
    """Get the bbox of a specific pixel"""
    x0, y0 = transform * (j, i)        # top-left corner
    x1, y1 = transform * (j + 1, i + 1)  # bottom-right corner
    return box(x0, y1, x1, y0) 

def get_barra_bboxs(filename=None):
    """Create a gdf of all the bboxs in the BARRA dataset"""
    # Could swap this to the Thredds version to make it work not on NCI
    # Might want to make ds an input if I need to do this on a different dataset
    url = f"/g/data/ob53/BARRA2/output/reanalysis/AUST-04/BOM/ERA5/historical/hres/BARRA-C2/v1/day/uas/latest/uas_AUST-04_ERA5_historical_hres_BOM_BARRA-C2_v1_day_202001-202001.nc"
    ds = xr.open_dataset(url, engine="netcdf4")

    # Get properties
    transform = ds.rio.transform()
    crs = ds.rio.crs
    ny, nx = ds.rio.shape

    # Create the gdf
    bboxes = []
    for i in range(ny):
        for j in range(nx):
            geom = pixel_bbox(i, j, transform)
            bboxes.append(geom)
    gdf_all = gpd.GeoDataFrame(geometry=bboxes, crs=crs)  # Took about 40 secs

    if filename:
        gdf_all.to_file(filename)  # Took about 5 mins and final output was about 200MB. Could make it smaller by cropping to the Australia border.
        print(f"Saved: {filename}")
        # Then I created smaller files for testing by selecting the relevant tiles in QGIS and Export > Save Selected Features as 

    return gdf_all

# filename = '/scratch/xe2/cb8590/tmp/barra_bboxs.gpkg'
# get_barra_bboxs(filename)

def crop_barra_bboxs():
    # This is the code I used to create barra_bboxs_aus and the state versions
    gdf = gpd.read_file(barra_bboxs_full)

    gdf2 = gpd.read_file(state_boundaries)

    state_mapping = {"New South Wales": "nsw",
                     "Victoria":"vic",
                     "Queensland":"qld",
                     "South Australia":"sa",
                     "Western Australia":"wa",
                     "Tasmania":"tas",
                     "Northern Territory":"nt",
                     "Australian Capital Territory":"act"
    }

    # Create a geopackage for each state
    gdf_sindex = gdf.sindex
    for state, abbreviation in state_mapping.items():
        geom = gdf2.loc[gdf2['STE_NAME21'] == state, 'geometry'].unary_union
        
        if state == "New South Wales":
            # Remove the hole in the middle so we also get ACT
            multipolygon = gdf2.iloc[0]['geometry']
            largest_polygon = max(multipolygon.geoms, key=lambda p: p.area)
            polygon_no_holes = Polygon(largest_polygon.exterior)
            gdf_no_holes = gpd.GeoDataFrame(
                [gdf.iloc[0].to_dict()],  
                geometry=[polygon_no_holes],
                crs=gdf.crs  
            )
            geom = gdf_no_holes['geometry'].iloc[0]
        
        possible_matches_index = list(gdf_sindex.intersection(geom.bounds))
        possible_matches = gdf.iloc[possible_matches_index]
        geom_prep = prep(geom)
        mask = possible_matches.geometry.map(geom_prep.intersects)
        gdf_state = possible_matches[mask]

        filename = os.path.join(barra_bboxs_dir, f'barra_bboxs_{abbreviation}.gpkg')
        gdf_state.to_file(filename)
        print(f"Saved: {filename}")

    # Create a geopackage of the tiles inside Australia
    gdf3 = gpd.read_file(aus_boundaries)
    geom_prep = prep(gdf3.loc[0,'geometry'])
    mask = gdf.geometry.map(geom_prep.intersects) # Only took 1 min, I love shapely's prep function
    gdf_aus = gdf[mask]
    filename = os.path.join(barra_bboxs_dir, f'barra_bboxs_aus.gpkg')
    gdf_aus.to_file(filename)
    print(f"Saved: {filename}")

    # Notes on number of tiles:
    # 1 million in the original barra_bboxs
    # 440k tiles in Australia boundary
    # 100k in the NSW bbox
    # 50k in NSW boundary

    # Convert to EPSG:3857
    # gdf = gpd.read_file('/g/data/xe2/cb8590/Outlines/BARRA_bboxs/barra_bboxs_nsw.gpkg')
    # gdf_3857 = gdf.to_crs('EPSG:3857')


# -

# Did this before running predictions_batch.py
def sub_gpkgs(state='actnsw', stub='actnsw_4326', chunk_size=500, processed_folder="/scratch/xe2/cb8590/barra_trees_s4_2020_actnsw_4326", save_gpkg=True):
    """Create smaller gpkgs for passing to multiple prediction jobs at once"""
    # Input / output paths
    input_file = f"/g/data/xe2/cb8590/Outlines/BARRA_bboxs/barra_bboxs_{state}.gpkg"
    output_dir = f"/g/data/xe2/cb8590/Outlines/BARRA_bboxs/BARRA_bboxs_{stub}"
    
    # Load the GeoDataFrame
    gdf = gpd.read_file(input_file)
    gdf['stub'] = [f"{geom.centroid.y:.2f}-{geom.centroid.x:.2f}".replace(".", "_")[1:] for geom in gdf['geometry']]
    print(f"Original length of gdf: {len(gdf)}")
    
    # Remove tiles that have already been processed
    processed_filenames = Path(processed_folder).glob("*_predicted.tif")
    processed_stubs = {
        f.stem[:len('28_97-152_94')] for f in processed_filenames  # This doesn't match the tiles starting with a single digit, e.g. 9_93-142_22. Should do some string splitting based on the underscores instead. 
    }
    gdf = gdf[~gdf["stub"].isin(processed_stubs)]
    print(f"Filtered length of gdf: {len(gdf)}")

    if save_gpkg:
        os.makedirs(output_dir, exist_ok=False)
        # Split into chunks and save
        for start in range(0, len(gdf), chunk_size):
            end = min(start + chunk_size, len(gdf))
            chunk = gdf.iloc[start:end]
            out_file = os.path.join(output_dir, f"BARRA_bboxs_{stub}_{start}-{end}.gpkg")
            chunk.to_file(out_file, driver="GPKG")
    
            print(f"Saved {out_file}")
# year = 2019
# sub_gpkgs(save_gpkg=False, state='actnsw', stub=f'actnsw_4326_{year}attempt3', chunk_size=10, processed_folder=f"/scratch/xe2/cb8590/barra_trees_s4_{year}_actnsw_4326")

# +
# %%time
year = 2017
state = 'aus'
stub = f'{state}_noxy_df_4326_{year}'
sub_gpkgs(save_gpkg=False, state=state, stub=f"{stub}_attempt5", chunk_size=300, processed_folder=f"/scratch/xe2/cb8590/barra_trees_s4_{stub}")  

# Took 1.5 mins to save 883 files for all of aus.

# -

asc_folder = '/g/data/xe2/cb8590/NSW_5m_DEMs'        # 265GB - Should convert to tif files but keep in the original EPSG
out_folder = '/scratch/xe2/cb8590/NSW_5m_DEMs_3857'  # 95GB - Should move these to scratch and maybe should be using an Aus crs instead of global

def asc_folder_to_tif(asc_folder, out_folder, dst_crs="EPSG:3857"):
    """Convert all the files to tifs and reproject to EPSG:3857 for faster stitching later"""
    
    os.makedirs(out_folder, exist_ok=True)
    asc_files = sorted(glob.glob(os.path.join(asc_folder, "*.asc")))

    # Remove files that have already been done
    tif_files = sorted(glob.glob(os.path.join(out_folder, "*.tif")))
    asc_stems  = [Path(asc_file).stem for asc_file in  asc_files]
    tif_stems = set(Path(tif_file).stem for tif_file in  tif_files)
    asc_files = [asc_file for asc_file, asc_stem in zip(asc_files, asc_stems) if asc_stem not in tif_stems]

    for i, asc_path in enumerate(asc_files, 1):
        base = os.path.splitext(os.path.basename(asc_path))[0]
        print(f"Working on {i}/{len(asc_files)}: {base}")
        out_path = os.path.join(out_folder, f"{base}.tif")

        da = rxr.open_rasterio(asc_path, masked=True)
        da = da.squeeze()
        da = da.rio.reproject(dst_crs)

        da.rio.to_raster(
            out_path,
            compress="LZW",
            tiled=True,
            BIGTIFF="IF_SAFER"
        )
    print(f"\n Finished converting {len(asc_files)} tiles → {out_folder}")

# asc_folder_to_tif(asc_folder, out_folder) # Going to take about 4 hours.
