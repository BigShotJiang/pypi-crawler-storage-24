"""Shared pytest fixtures for mloopforml test suite."""

import logging
import pytest


@pytest.fixture(autouse=True, scope="session")
def suppress_mloop_logging():
    """Suppress M-LOOP's verbose logger and file creation for the entire test session.

    M-LOOP's _config_logger adds handlers (including a FileHandler that creates
    M-LOOP_logs/ files) only when log.handlers is empty. By adding a NullHandler
    first, we prevent M-LOOP from installing its own handlers, which stops both
    console noise and file creation. Setting ERROR level also ensures any
    messages from M-LOOP before this fixture runs are suppressed.
    """
    log = logging.getLogger("mloop")
    log.setLevel(logging.ERROR)
    # NullHandler prevents M-LOOP's _config_logger from adding its own handlers
    # (it checks len(log.handlers) == 0 before adding FileHandler + StreamHandler)
    if not log.handlers:
        log.addHandler(logging.NullHandler())
