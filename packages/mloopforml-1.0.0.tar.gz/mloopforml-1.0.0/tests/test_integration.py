"""Integration tests for M-LOOP wiring (Phase 3).

Wave 1: Real assertions — optimizer loop runs end-to-end with NeuralNetController.
"""

import math
import re
import subprocess
import sys

import pytest

import mloopforml as mloop


# ── Shared fixtures ───────────────────────────────────────────────────────────


@pytest.fixture
def simple_objective():
    """1-param synthetic objective: minimize (x-3)^2. Optimum at x=3.0."""

    @mloop.optimize(
        params={"x": (0.0, 6.0)},
        max_iterations=5,
        direction="minimize",
        num_training_runs=1,
        seed=42,
    )
    def _obj(x):
        return (x - 3.0) ** 2

    return _obj


@pytest.fixture
def maximize_objective():
    """1-param synthetic objective: maximize -(x-3)^2. Optimum at x=3.0."""

    @mloop.optimize(
        params={"x": (0.0, 6.0)},
        max_iterations=5,
        direction="maximize",
        num_training_runs=1,
        seed=42,
    )
    def _obj(x):
        return -((x - 3.0) ** 2)

    return _obj


# ── API-06: calling decorated function blocks and returns OptimizeResult ──────


def test_optimize_returns_result(simple_objective):
    """API-06: calling decorated function returns OptimizeResult."""
    result = simple_objective()
    assert isinstance(result, mloop.OptimizeResult)
    assert isinstance(result.best_params, dict)
    assert isinstance(result.best_score, float)


# ── OPT-01: num_training_runs trials in bootstrap phase ───────────────────────


def test_num_training_runs(simple_objective):
    """OPT-01: max_iterations=5 means 5 total trials (TRAIN + OPT)."""
    result = simple_objective()
    assert len(result.all_costs) == 5
    assert len(result.all_params) == 5


# ── OPT-02: NeuralNetController backend is used ───────────────────────────────


def test_neural_net_backend():
    """OPT-02: create_controller uses controller_type='neural_net' → NeuralNetController."""

    @mloop.optimize(
        params={"x": (0.0, 6.0)},
        max_iterations=5,
        direction="minimize",
        num_training_runs=1,
        seed=0,
    )
    def obj(x):
        return x**2

    result = obj()
    assert isinstance(result, mloop.OptimizeResult)
    assert len(result.all_costs) == 5


# ── OPT-03: all proposed params stay within declared bounds ───────────────────


def test_params_within_bounds():
    """OPT-03: all trial params are within [min, max] bounds."""

    @mloop.optimize(
        params={"x": (1.0, 4.0), "y": (0.5, 2.5)},
        max_iterations=5,
        direction="minimize",
        num_training_runs=1,
        seed=7,
    )
    def obj(x, y):
        return (x - 2.5) ** 2 + (y - 1.5) ** 2

    result = obj()
    for trial_params in result.all_params:
        assert 1.0 <= trial_params["x"] <= 4.0, (
            f"x={trial_params['x']} out of bounds [1.0, 4.0]"
        )
        assert 0.5 <= trial_params["y"] <= 2.5, (
            f"y={trial_params['y']} out of bounds [0.5, 2.5]"
        )


# ── OPT-05: scores in result are in user space (not normalized) ───────────────


def test_result_scores_in_user_space(maximize_objective):
    """OPT-05: best_score is in user's score space (not M-LOOP's normalized cost)."""
    result = maximize_objective()
    # maximize -(x-3)^2 is always <= 0 for any x in [0, 6]
    assert result.best_score <= 0.0, (
        f"maximize -(x-3)^2 must be <= 0 but got {result.best_score}"
    )


# ── OPT-06: exception in objective → bad trial, run continues ─────────────────


def test_exception_handling():
    """OPT-06: exception in objective raises WARNING and marks trial bad; run continues."""
    call_count = {"n": 0}

    @mloop.optimize(
        params={"x": (0.0, 6.0)},
        max_iterations=5,
        direction="minimize",
        num_training_runs=1,
        seed=99,
    )
    def obj(x):
        call_count["n"] += 1
        if call_count["n"] == 2:
            raise ValueError("Simulated trial failure")
        return x**2

    result = obj()
    # Run completed with all 5 trials
    assert len(result.all_costs) == 5
    # Trial 2 (index 1) should have NaN cost since it raised an exception
    assert math.isnan(result.all_costs[1]), (
        f"Expected nan for failed trial but got {result.all_costs[1]}"
    )
    # Other trials have finite costs
    assert not math.isnan(result.all_costs[0])


# ── OBS-01: trial log line format ─────────────────────────────────────────────


def test_trial_log_format(simple_objective, capsys):
    """OBS-01: each completed trial emits '[Trial N/M LABEL] params={...} score=X.XXX (best: X.XXX)'."""
    simple_objective()
    captured = capsys.readouterr()
    output = captured.out
    # Pattern: [Trial  1/5 TRAIN] params={...} score=X.XXX (best: X.XXX)
    pattern = r"\[Trial\s+\d+/\d+\s+\w+\s*\].*params=.*score=.*best:"
    trial_lines = [line for line in output.splitlines() if "[Trial" in line]
    assert len(trial_lines) == 5, (
        f"Expected 5 trial lines, got {len(trial_lines)}. Output:\n{output}"
    )
    for line in trial_lines:
        assert re.search(pattern, line), f"Line doesn't match format: {line!r}"


# ── OBS-02: TRAIN vs OPT labels ───────────────────────────────────────────────


def test_trial_labels(simple_objective, capsys):
    """OBS-02: first num_training_runs trials labeled TRAIN, subsequent labeled OPT."""
    simple_objective()
    captured = capsys.readouterr()
    output = captured.out
    trial_lines = [line for line in output.splitlines() if "[Trial" in line]
    assert len(trial_lines) == 5
    # First 1 trial (num_training_runs=1) should be TRAIN
    assert "TRAIN" in trial_lines[0], (
        f"First line should have TRAIN: {trial_lines[0]!r}"
    )
    # Remaining trials should be OPT
    for line in trial_lines[1:]:
        assert "OPT" in line, f"Expected OPT label in: {line!r}"


# ── EX-01: examples/quickstart.py runs to completion ─────────────────────────


def test_quickstart_example():
    """EX-01: examples/quickstart.py runs to completion without error."""
    import pathlib

    quickstart_path = pathlib.Path("examples/quickstart.py")
    assert quickstart_path.exists(), "examples/quickstart.py must exist"

    result = subprocess.run(
        [sys.executable, str(quickstart_path)],
        capture_output=True,
        text=True,
        timeout=60,  # max_iterations=20 should complete in <30s
    )

    assert result.returncode == 0, (
        f"quickstart.py exited with code {result.returncode}\n"
        f"stdout: {result.stdout}\n"
        f"stderr: {result.stderr}"
    )
    assert "Optimization complete!" in result.stdout
    assert "Best score:" in result.stdout
    assert "Best params:" in result.stdout
