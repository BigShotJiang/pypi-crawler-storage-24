"""Tests for optimize() decorator factory (API-01 through API-08)."""

import pytest

import mloopforml as mloop

# ─── Happy path ──────────────────────────────────────────────────────────────


def test_decorate_function_no_error():
    """Decorating a function with valid args raises no error (API-01–05)."""

    @mloop.optimize(
        params={"lr": (0.001, 0.1)},
        max_iterations=20,
        direction="maximize",
        seed=42,
    )
    def train(lr):
        return lr * 2

    assert callable(train)


def test_import_module_no_error():
    """import mloopforml as mloop does not raise; optimize is callable (API-07)."""
    assert callable(mloop.optimize)


def test_seed_none_accepted():
    """seed=None is accepted — produces a callable (API-05)."""

    @mloop.optimize(params={"lr": (0.001, 0.1)}, seed=None)
    def fn(lr):
        return lr

    assert callable(fn)


def test_seed_int_accepted():
    """seed=42 (integer) is accepted — produces a callable (API-05)."""

    @mloop.optimize(params={"lr": (0.001, 0.1)}, seed=42)
    def fn(lr):
        return lr

    assert callable(fn)


@pytest.mark.parametrize("direction", ["minimize", "min", "maximize", "max"])
def test_all_directions_accepted(direction):
    """All valid direction strings are accepted (API-04)."""

    @mloop.optimize(params={"lr": (0.001, 0.1)}, direction=direction)
    def fn(lr):
        return lr

    assert callable(fn)


# ─── params validation ────────────────────────────────────────────────────────


def test_params_inverted_bounds_raises():
    """params with lo >= hi raises ValueError with 'min' in message (API-08)."""
    with pytest.raises(ValueError, match="min"):
        mloop.optimize(params={"lr": (0.1, 0.001)})


def test_params_empty_dict_raises():
    """params={} raises ValueError with 'non-empty dict' in message (API-08)."""
    with pytest.raises(ValueError, match="non-empty dict"):
        mloop.optimize(params={})


def test_params_non_numeric_bounds_raises():
    """String bounds raise ValueError with 'numeric' in message (API-08)."""
    with pytest.raises(ValueError, match="numeric"):
        mloop.optimize(params={"lr": ("fast", "slow")})


def test_params_not_tuple_raises():
    """Scalar bound raises ValueError matching '(min, max) tuple' (API-08)."""
    with pytest.raises(ValueError, match=r"\(min, max\) tuple"):
        mloop.optimize(params={"lr": 0.01})


def test_params_equal_bounds_raises():
    """params with equal bounds raises ValueError with 'min' in message (API-08)."""
    with pytest.raises(ValueError, match="min"):
        mloop.optimize(params={"lr": (0.1, 0.1)})


def test_params_infinite_bound_raises():
    """params with inf bound raises ValueError with 'finite' in message (API-08)."""
    with pytest.raises(ValueError, match="finite"):
        mloop.optimize(params={"lr": (float("inf"), 1.0)})


def test_params_validation_at_decoration_time():
    """Validation fires before any function is decorated (API-07, API-08)."""
    with pytest.raises(ValueError):
        mloop.optimize(params={"lr": (0.1, 0.001)})  # error before decorator is applied


# ─── direction validation ─────────────────────────────────────────────────────


def test_invalid_direction_raises():
    """direction='up' raises ValueError with 'direction must be' in message (API-04)."""
    with pytest.raises(ValueError, match="direction must be"):
        mloop.optimize(params={"lr": (0.001, 0.1)}, direction="up")


# ─── seed validation ──────────────────────────────────────────────────────────


def test_seed_float_raises():
    """seed=3.7 (float) raises ValueError with 'integer or None' in message (API-05)."""
    with pytest.raises(ValueError, match="integer or None"):
        mloop.optimize(params={"lr": (0.001, 0.1)}, seed=3.7)


def test_seed_bool_raises():
    """seed=True (bool, even though subclass of int) raises ValueError (API-05)."""
    with pytest.raises(ValueError, match="integer or None"):
        mloop.optimize(params={"lr": (0.001, 0.1)}, seed=True)


# ─── max_iterations validation ───────────────────────────────────────────────


def test_max_iterations_zero_raises():
    """max_iterations=0 raises ValueError (API-03)."""
    with pytest.raises(ValueError):
        mloop.optimize(params={"lr": (0.001, 0.1)}, max_iterations=0)


def test_max_iterations_negative_raises():
    """max_iterations=-1 raises ValueError (API-03)."""
    with pytest.raises(ValueError):
        mloop.optimize(params={"lr": (0.001, 0.1)}, max_iterations=-1)


def test_max_iterations_string_raises():
    """max_iterations='fifty' raises ValueError (API-03)."""
    with pytest.raises(ValueError):
        mloop.optimize(params={"lr": (0.001, 0.1)}, max_iterations="fifty")


# ─── config inspection ────────────────────────────────────────────────────────


def test_mloop_config_keys_present():
    """Decorated function has _mloop_config with all required keys."""

    @mloop.optimize(
        params={"lr": (0.001, 0.1)},
        max_iterations=20,
        direction="maximize",
        seed=42,
    )
    def fn(lr):
        return lr

    cfg = fn._mloop_config
    assert set(cfg.keys()) == {
        "params",
        "max_iterations",
        "direction",
        "direction_sign",
        "seed",
        "num_training_runs",
    }


def test_mloop_config_values_correct():
    """_mloop_config stores expected values for each key."""

    @mloop.optimize(
        params={"lr": (0.001, 0.1)},
        max_iterations=20,
        direction="maximize",
        seed=42,
    )
    def fn(lr):
        return lr

    cfg = fn._mloop_config
    assert cfg["params"] == {"lr": (0.001, 0.1)}
    assert cfg["max_iterations"] == 20
    assert cfg["direction"] == "maximize"
    assert cfg["direction_sign"] == 1
    assert cfg["seed"] == 42


def test_mloop_config_direction_sign_minimize():
    """direction='minimize' produces direction_sign=-1."""

    @mloop.optimize(params={"lr": (0.001, 0.1)}, direction="minimize")
    def fn(lr):
        return lr

    assert fn._mloop_config["direction_sign"] == -1


def test_mloop_config_params_is_deep_copy():
    """Mutating original params post-decoration leaves _mloop_config intact (API-08)."""
    original = {"lr": (0.001, 0.1)}

    @mloop.optimize(params=original)
    def fn(lr):
        return lr

    original["lr"] = (0.5, 0.9)  # mutate after decoration
    assert fn._mloop_config["params"]["lr"] == (0.001, 0.1)  # unchanged
