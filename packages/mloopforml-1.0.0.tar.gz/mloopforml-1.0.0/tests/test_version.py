"""Smoke tests for package metadata (PKG-04, PKG-06)."""

import importlib.metadata
import subprocess
import sys

import mloopforml


def test_version_is_string():
    """__version__ must be a non-empty string — not 'unknown'."""
    assert isinstance(mloopforml.__version__, str)
    assert mloopforml.__version__ != ""
    assert mloopforml.__version__ != "unknown"


def test_version_matches_metadata():
    """__version__ must match importlib.metadata — no skew allowed (PKG-06)."""
    assert mloopforml.__version__ == importlib.metadata.version("mloopforml")


def test_no_runtime_deps_beyond_numpy_scipy():
    """Importing mloopforml must not pull in heavy ML frameworks (PKG-04).

    Tested in a subprocess to avoid contamination from other tests that
    exercise the optimizer (which lazily imports M-LOOP/TensorFlow).
    """
    result = subprocess.run(
        [
            sys.executable,
            "-c",
            (
                "import mloopforml, sys; "
                "bad = [m for m in ['torch', 'tensorflow', 'sklearn'] if m in sys.modules]; "
                "print('BAD:', bad) if bad else print('OK')"
            ),
        ],
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert result.returncode == 0, f"Import check failed: {result.stderr}"
    assert result.stdout.strip() == "OK", (
        f"Importing mloopforml pulled in unwanted deps: {result.stdout.strip()}"
    )
