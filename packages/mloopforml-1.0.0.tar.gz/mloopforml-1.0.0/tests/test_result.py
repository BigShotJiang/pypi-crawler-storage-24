"""Tests for OptimizeResult frozen dataclass (RES-01, RES-02)."""

import math

import pytest

from mloopforml import OptimizeResult

# ─── Happy path ──────────────────────────────────────────────────────────────


def test_optimize_result_constructs():
    """OptimizeResult builds with all 4 fields accessible (RES-01)."""
    result = OptimizeResult(
        best_params={"lr": 0.05},
        best_score=0.95,
        all_params=[{"lr": 0.05}],
        all_costs=[0.95],
    )
    assert result.best_params == {"lr": 0.05}
    assert result.best_score == 0.95
    assert result.all_params == [{"lr": 0.05}]
    assert result.all_costs == [0.95]


def test_optimize_result_is_immutable():
    """Assigning to any field raises FrozenInstanceError (RES-02)."""
    result = OptimizeResult(
        best_params={"lr": 0.05},
        best_score=0.95,
        all_params=[{"lr": 0.05}],
        all_costs=[0.95],
    )
    with pytest.raises(Exception):  # FrozenInstanceError is subclass of AttributeError
        result.best_score = 0.0  # type: ignore[misc]


def test_optimize_result_nan_cost():
    """all_costs can store float('nan') — NaN convention for failed trials (RES-01)."""
    result = OptimizeResult(
        best_params={"lr": 0.05},
        best_score=0.95,
        all_params=[{"lr": 0.05}],
        all_costs=[float("nan")],
    )
    assert math.isnan(result.all_costs[0])


def test_optimize_result_top_level_import():
    """from mloopforml import OptimizeResult works as a top-level export (RES-01)."""
    # The import at the top of this module already validates this;
    # this test makes the assertion explicit.
    assert OptimizeResult is not None
