"""mloopforml — neural network surrogate hyperparameter optimization."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("mloopforml")
except PackageNotFoundError:
    # Package not installed (running from source without pip install -e .)
    __version__ = "unknown"

from .optimize import optimize
from .result import OptimizeResult

__all__ = ["__version__", "optimize", "OptimizeResult"]
