"""optimize() — decorator factory for mloopforml hyperparameter search.

Usage
-----
::

    import mloopforml as mloop

    @mloop.optimize(
        params={"lr": (0.001, 0.1), "dropout": (0.0, 0.5)},
        max_iterations=50,
        direction="minimize",
        seed=42,
    )
    def train(lr, dropout):
        ...  # return scalar loss

Validation runs at *decoration time* (when ``optimize(...)`` is called), not
at call time — so parameter range errors surface immediately.

M-LOOP and rich are imported lazily inside wrapper() and _MLOOPInterface so
that ``import mloopforml`` does not pull in TensorFlow (M-LOOP's heavy dep).
"""

import copy
import functools
import logging
import math
import threading
from collections.abc import Callable
from typing import Any

# ─── Validation helpers ───────────────────────────────────────────────────────


def _validate_params(params: dict[str, Any]) -> None:
    """Validate the params dict at decoration time (API-08)."""
    if not isinstance(params, dict) or len(params) == 0:
        raise ValueError(
            "params must be a non-empty dict mapping parameter names to "
            "(min, max) tuples of finite floats."
        )
    for name, bounds in params.items():
        if not isinstance(bounds, tuple) or len(bounds) != 2:
            raise ValueError(
                f"Each parameter must map to a (min, max) tuple, "
                f"but '{name}' maps to {bounds!r}."
            )
        lo, hi = bounds
        # bool is a subclass of int — exclude it explicitly
        if (
            isinstance(lo, bool)
            or isinstance(hi, bool)
            or not isinstance(lo, (int, float))
            or not isinstance(hi, (int, float))
        ):
            raise ValueError(
                f"Parameter bounds must be numeric (int or float), "
                f"but '{name}' has bounds ({lo!r}, {hi!r})."
            )
        if not math.isfinite(lo) or not math.isfinite(hi):
            raise ValueError(
                f"Parameter bounds must be finite, "
                f"but '{name}' has non-finite bounds ({lo!r}, {hi!r})."
            )
        if lo >= hi:
            raise ValueError(
                f"Parameter bounds must satisfy min < max, "
                f"but '{name}' has lo={lo!r} >= hi={hi!r}."
            )


def _validate_direction(direction: str) -> None:
    """Validate direction string (API-04)."""
    valid = {"minimize", "min", "maximize", "max"}
    if direction not in valid:
        raise ValueError(
            f"direction must be one of {sorted(valid)!r}, got {direction!r}."
        )


def _validate_seed(seed: Any) -> None:
    """Validate seed is int (not bool) or None (API-05)."""
    if seed is not None:
        if isinstance(seed, bool) or not isinstance(seed, int):
            raise ValueError(
                f"seed must be an integer or None, got {seed!r} "
                f"(type {type(seed).__name__!r})."
            )


def _validate_max_iterations(max_iterations: Any) -> None:
    """Validate max_iterations is a positive integer (API-03)."""
    if (
        isinstance(max_iterations, bool)
        or not isinstance(max_iterations, int)
        or max_iterations <= 0
    ):
        raise ValueError(
            f"max_iterations must be a positive integer, got {max_iterations!r}."
        )


def _validate_num_training_runs(num_training_runs: Any) -> None:
    """Validate num_training_runs is a positive integer (OPT-01)."""
    if (
        isinstance(num_training_runs, bool)
        or not isinstance(num_training_runs, int)
        or num_training_runs <= 0
    ):
        raise ValueError(
            f"num_training_runs must be a positive integer, got {num_training_runs!r}."
        )


# ─── M-LOOP integration helpers ───────────────────────────────────────────────


class _MLOOPInterface:
    """M-LOOP Interface subclass that calls the user's decorated function.

    Actual M-LOOP base class (mloop.interfaces.Interface) is mixed in lazily
    at instantiation time so importing mloopforml does not pull in TensorFlow.

    get_next_cost_dict is the single integration point — called once per trial.
    """

    def __new__(cls, *args: Any, **kwargs: Any) -> "_MLOOPInterface":
        """Lazily mixin mloop.interfaces.Interface as a base class."""
        import mloop.interfaces as _mli

        # Build a concrete subclass that inherits from the real Interface
        if not issubclass(cls, _mli.Interface):
            cls = type(cls.__name__, (cls, _mli.Interface), {})
        return object.__new__(cls)

    def __init__(
        self,
        func: Callable,
        param_names: list[str],
        direction_sign: int,
        max_iterations: int,
        num_training_runs: int,
        console: Any,
        shared: dict,
        lock: threading.Lock,
    ) -> None:
        super().__init__()
        self._func = func
        self._param_names = param_names
        self._direction_sign = direction_sign
        self._max_iterations = max_iterations
        self._num_training_runs = num_training_runs
        self._console = console
        self._shared = shared
        self._lock = lock
        self._width = len(str(max_iterations))

    def get_next_cost_dict(self, params_dict: dict) -> dict:
        """Called by M-LOOP's interface thread once per trial."""
        params_array = params_dict["params"]
        named = dict(zip(self._param_names, map(float, params_array)))

        try:
            score = float(self._func(**named))
            cost = -score * self._direction_sign
            bad = False
        except Exception:
            logging.getLogger(__name__).warning(
                "Trial raised an exception — marking bad", exc_info=True
            )
            score = float("nan")
            cost = float("inf")
            bad = True

        with self._lock:
            self._shared["trial"] += 1
            n = self._shared["trial"]
            if not bad and (
                self._shared["best_cost_internal"] is None
                or cost < self._shared["best_cost_internal"]
            ):
                self._shared["best_cost_internal"] = cost
                self._shared["best_score"] = score
                self._shared["best_params"] = named
            best_score = self._shared["best_score"]

        label = "TRAIN" if n <= self._num_training_runs else "OPT  "
        w = self._width
        score_str = f"{score:.3f}" if not bad else "FAILED"
        best_str = f"{best_score:.3f}" if best_score is not None else "N/A"
        self._console.print(
            f"[Trial {n:{w}d}/{self._max_iterations} {label}]"
            f" params={named}  score={score_str}  (best: {best_str})"
        )

        return {"cost": cost, "uncer": 0, "bad": bad}


def _build_result(controller: Any, cfg: dict, param_names: list[str]) -> Any:
    """Convert M-LOOP controller state to OptimizeResult after optimize() completes."""
    from .result import OptimizeResult

    direction_sign = cfg["direction_sign"]

    best_score = float(-controller.best_cost * direction_sign)
    best_params = dict(zip(param_names, map(float, controller.best_params)))

    all_params = [dict(zip(param_names, map(float, p))) for p in controller.out_params]
    all_costs = [
        float("nan") if bad else float(-cost * direction_sign)
        for cost, bad in zip(controller.in_costs, controller.in_bads)
    ]

    return OptimizeResult(
        best_params=best_params,
        best_score=best_score,
        all_params=all_params,
        all_costs=all_costs,
    )


# ─── Public factory ───────────────────────────────────────────────────────────


def optimize(
    params: dict[str, tuple[float, float]],
    max_iterations: int = 50,
    direction: str = "minimize",
    seed: int | None = None,
    num_training_runs: int = 1,
) -> Callable:
    """Decorator factory that declares a hyperparameter search over *params*.

    Validation runs immediately (at factory-call time), before any function
    is decorated (API-07, API-08).

    Parameters
    ----------
    params:
        Mapping from parameter name to ``(min, max)`` bounds tuple. Both
        bounds must be finite; ``min < max`` required.
    max_iterations:
        Maximum number of optimization iterations. Must be a positive integer.
    direction:
        ``"minimize"`` / ``"min"`` or ``"maximize"`` / ``"max"``.
    seed:
        Integer random seed for reproducibility, or ``None`` for unseeded.
    num_training_runs:
        Number of random bootstrap trials before the neural-net surrogate
        activates. Must be a positive integer. Defaults to 1.

    Returns
    -------
    Callable
        A decorator that wraps the user's objective function and attaches
        ``._mloop_config``.
    """
    # Deep-copy params BEFORE validation to defend against post-call mutation.
    params = copy.deepcopy(params)

    # ── Staged validation (all at factory-call time) ──────────────────────────
    _validate_params(params)
    _validate_direction(direction)
    _validate_seed(seed)
    _validate_max_iterations(max_iterations)
    _validate_num_training_runs(num_training_runs)

    # ── Compute direction sign ────────────────────────────────────────────────
    direction_sign = -1 if direction in ("minimize", "min") else 1

    # ── Decorator ─────────────────────────────────────────────────────────────
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Lazy imports — keep mloopforml import lightweight (no TF at import time)
            import mloop.controllers as _mlc
            from rich.console import Console

            cfg = wrapper._mloop_config  # type: ignore[attr-defined]
            param_names = list(cfg["params"].keys())

            # 1. Suppress M-LOOP's logger before any M-LOOP construction
            logging.getLogger("mloop").setLevel(logging.ERROR)

            # 2. Shared state (interface thread writes; wrapper thread reads after)
            lock = threading.Lock()
            shared: dict = {
                "trial": 0,
                "best_score": None,
                "best_params": None,
                "best_cost_internal": None,
            }

            # 3. Thread-safe rich Console for trial log lines
            console = Console(stderr=False, highlight=False)

            # 4. Build interface (not started yet — controller starts it)
            interface = _MLOOPInterface(
                func=func,
                param_names=param_names,
                direction_sign=cfg["direction_sign"],
                max_iterations=cfg["max_iterations"],
                num_training_runs=cfg["num_training_runs"],
                console=console,
                shared=shared,
                lock=lock,
            )

            # 5. Build controller — suppress all file side-effects
            controller = _mlc.create_controller(
                interface,
                controller_type="neural_net",
                max_num_runs=cfg["max_iterations"],
                num_params=len(param_names),
                min_boundary=[b[0] for b in cfg["params"].values()],
                max_boundary=[b[1] for b in cfg["params"].values()],
                num_training_runs=cfg["num_training_runs"],
                visualizations=False,
                controller_archive_filename=None,  # no M-LOOP_archives/
                log_filename=None,  # no M-LOOP_logs/
            )

            # 6. Run optimization (blocks until max_iterations complete)
            controller.optimize()

            # 7. Assemble and return result
            return _build_result(controller, cfg, param_names)

        wrapper._mloop_config = {  # type: ignore[attr-defined]
            "params": params,
            "max_iterations": max_iterations,
            "direction": direction,
            "direction_sign": direction_sign,
            "seed": seed,
            "num_training_runs": num_training_runs,
        }
        return wrapper

    return decorator
