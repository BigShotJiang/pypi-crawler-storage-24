"""OptimizeResult — immutable container for mloopforml optimization output.

Fields
------
best_params : dict[str, float]
    Parameter combination that achieved the best score.
best_score : float
    Objective value at best_params (direction-adjusted: higher is always better
    internally, but stored as the raw score seen by the objective function).
all_params : list[dict[str, float]]
    Parameter combinations tried across all iterations, in trial order.
all_costs : list[float]
    Objective values corresponding to all_params. Failed trials store
    float('nan') to indicate the trial did not produce a valid result.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class OptimizeResult:
    """Immutable result of a completed mloopforml optimization run.

    This is a frozen dataclass — all fields are read-only after construction.
    Attempting to assign to any field raises ``dataclasses.FrozenInstanceError``.

    Attributes
    ----------
    best_params : dict[str, float]
        Parameter combination that achieved the best score.
    best_score : float
        Best objective value observed during optimization.
    all_params : list[dict[str, float]]
        All parameter combinations evaluated, in trial order.
    all_costs : list[float]
        Objective values for each trial. Failed trials are represented as
        ``float('nan')``.
    """

    best_params: dict[str, float]
    best_score: float
    all_params: list[dict[str, float]]
    all_costs: list[float]
