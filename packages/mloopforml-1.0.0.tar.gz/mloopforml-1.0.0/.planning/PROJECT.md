# mloopforml

## What This Is

A Python library for ML hyperparameter optimization using a neural net surrogate model, inspired by the original M-LOOP project. Users wrap their training call in a decorated function, set continuous parameter ranges, and the library handles the optimization loop automatically. Published as a public package on PyPI via GitHub CI/CD.

## Core Value

A researcher or engineer can `pip install mloopforml`, write a decorator with parameter ranges, and have a working hyperparameter optimization loop running in under 5 minutes — without learning a framework.

## Requirements

### Validated

(None yet — ship to validate)

### Active

- [ ] User can install via `pip install mloopforml`
- [ ] User can decorate a wrapper function with `@mloop.optimize(params={...})` to define the optimization target
- [ ] User specifies continuous hyperparameter ranges as `(min, max)` tuples
- [ ] User sets `max_iterations` to control how many trials run
- [ ] Library runs optimization using a neural net surrogate model
- [ ] Library returns best params and best score after the run
- [ ] Public GitHub repo with CI/CD pipeline that publishes to PyPI on release
- [ ] At least one working example that demonstrates a real ML use case

### Out of Scope

- Discrete / categorical parameter types — v1 is continuous only
- Distributed / parallel trial execution — single-process for now
- Dashboard or UI — CLI/log output only
- Framework-specific integrations — caller returns a float, mloop doesn't care what produces it
- Early stopping / auto-convergence — user controls iteration count

## Context

- Inspired by the original M-LOOP (Machine Learning Online Optimization Package) which uses a neural net to model the cost landscape as a surrogate
- Existing tools (Optuna, Ray Tune, Hyperopt) are too complex and ceremony-heavy for the target use case
- The key API insight: the decorator wraps a *user-defined wrapper function* that calls training, not the training function itself — keeps training code untouched
- Framework-agnostic: the decorated function just needs to return a float score

## Constraints

- **Language**: Python 3.9+ — widest compatibility with current ML ecosystem
- **Packaging**: Must be installable via `pip install mloopforml` from PyPI
- **Distribution**: Public GitHub repo, CI/CD via GitHub Actions → PyPI
- **Scope**: v1 ships as minimal viable optimizer — correctness and ease of use over features

## Key Decisions

| Decision | Rationale | Outcome |
|----------|-----------|---------|
| Decorator on wrapper, not training fn | Keeps training code decoupled from optimization library | — Pending |
| Neural net surrogate model | User's proven experience with M-LOOP approach | — Pending |
| Continuous params only for v1 | Keeps implementation scope tight; original M-LOOP also starts here | — Pending |
| Fixed iterations, no auto-converge | Predictable runtime; user controls the budget | — Pending |

---
*Last updated: 2026-03-06 after initialization*
