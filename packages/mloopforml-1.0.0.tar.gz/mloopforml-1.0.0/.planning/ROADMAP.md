# Roadmap: mloopforml

**Created:** 2026-03-06
**Granularity:** Coarse
**Coverage:** 26/26 v1 requirements mapped ✓

---

## Phases

- [x] **Phase 1: Scaffold & Packaging Pipeline** - Repo structure, pyproject.toml, CI/CD publish to PyPI
- [x] **Phase 2: Parameter Space & Results Layer** - Validated param bounds, `OptimizeResult` dataclass (completed 2026-03-07)
- [ ] **Phase 3: M-LOOP Integration & Example** - Wire optimize() to call M-LOOP, translate _mloop_config to M-LOOP API, collect results, add trial logging, ship example

---

## Phase Details

### Phase 1: Scaffold & Packaging Pipeline

**Goal:** A properly structured, publishable Python package exists on PyPI before any library code is written.

**Depends on:** Nothing (first phase)

**Requirements:** PKG-01, PKG-02, PKG-03, PKG-04, PKG-05, PKG-06

**Success Criteria** (what must be TRUE):
  1. Running `pip install mloopforml` on a clean environment installs the package without errors
  2. A `v*` git tag triggers GitHub Actions to build and publish sdist + wheel to PyPI automatically (no manual upload, no long-lived API tokens)
  3. `import mloopforml; mloopforml.__version__` returns a version string matching the tag
  4. The installed package pulls in only `numpy` and `scipy` as runtime dependencies — no PyTorch, TensorFlow, or scikit-learn

**Plans:** 2 plans

Plans:
- [x] 01-01-PLAN.md — Repo scaffold: pyproject.toml, src layout, version tests, build artifacts (PKG-01, PKG-03, PKG-04, PKG-05, PKG-06)
- [x] 01-02-PLAN.md — GitHub Actions CI/CD: test matrix + OIDC Trusted Publishing to TestPyPI and PyPI (PKG-02, PKG-03)

---

### Phase 2: Parameter Space & Results Layer

**Goal:** Users can declare hyperparameter ranges that are validated at decoration time, and the result contract is fully defined and tested.

**Depends on:** Phase 1

**Requirements:** API-01, API-02, API-03, API-04, API-05, API-07, API-08, RES-01, RES-02

**Success Criteria** (what must be TRUE):
  1. A user decorating a function with `@mloop.optimize(params={"lr": (0.001, 0.1)}, max_iterations=20, direction="maximize", seed=42)` receives no errors at decoration time
  2. Invalid parameter bounds (e.g., `min >= max`, non-numeric values) raise a `ValueError` immediately when the decorator is applied — not during trial execution
  3. Importing `mloopforml` does not trigger any optimization logic
  4. `OptimizeResult` exposes `best_params`, `best_score`, `all_params`, and `all_costs` with the correct types

**Plans:** 1/1 plans complete

Plans:
- [ ] 02-01-PLAN.md — OptimizeResult dataclass + optimize() decorator factory with validation + __init__ exports + full test suite (API-01, API-02, API-03, API-04, API-05, API-07, API-08, RES-01, RES-02)

---

### Phase 3: M-LOOP Integration & Example

**Goal:** A researcher can `pip install mloopforml`, copy-paste the README example, and have a working hyperparameter optimization loop in under 5 minutes. M-LOOP handles the surrogate, bootstrap, scipy restarts, and normalization internally — this phase wires the decorator to call it correctly.

**Depends on:** Phase 2

**Requirements:** API-06, OPT-01, OPT-02, OPT-03, OPT-04, OPT-05, OPT-06, OBS-01, OBS-02, EX-01, EX-02

**Success Criteria** (what must be TRUE):
  1. Calling a decorated function blocks until `max_iterations` trials complete and returns an `OptimizeResult`
  2. M-LOOP's `MachineLearnerController` is used as the backend — no hand-rolled surrogate
  3. All proposed parameter values stay within declared bounds (M-LOOP clips; we verify in tests)
  4. If the objective function raises an exception, the error is logged at WARNING and the trial is marked bad (M-LOOP's `bad=True` convention) — run continues
  5. Each completed trial prints `[Trial N/M] params={...} score=X.XXX (best: X.XXX)` to stdout
  6. Running `examples/quickstart.py` produces a visible best score and params after the run

**Plans:** 3 plans

Plans:
- [ ] 03-01-PLAN.md — Wave 0 scaffold: test_integration.py stubs, conftest.py, num_training_runs API extension, rich dependency (API-06, OPT-01–03, OPT-05–06, OBS-01–02, EX-01)
- [ ] 03-02-PLAN.md — M-LOOP wiring: _MLOOPInterface, wrapper() implementation, _build_result() (API-06, OPT-01–06, OBS-01–02)
- [ ] 03-03-PLAN.md — Example + README: finalize examples/quickstart.py, write README quickstart block (EX-01, EX-02)

---

## Progress

| Phase | Plans Complete | Status | Completed |
|-------|----------------|--------|-----------|
| 1. Scaffold & Packaging Pipeline | 2/2 | Complete | 2026-03-07 |
| 2. Parameter Space & Results Layer | 0/1 | Complete    | 2026-03-07 |
| 3. M-LOOP Integration & Example | 0/3 | Not started | — |

---

## Coverage

| Requirement | Phase |
|-------------|-------|
| PKG-01 | Phase 1 |
| PKG-02 | Phase 1 |
| PKG-03 | Phase 1 |
| PKG-04 | Phase 1 |
| PKG-05 | Phase 1 |
| PKG-06 | Phase 1 |
| API-01 | Phase 2 |
| API-02 | Phase 2 |
| API-03 | Phase 2 |
| API-04 | Phase 2 |
| API-05 | Phase 2 |
| API-07 | Phase 2 |
| API-08 | Phase 2 |
| RES-01 | Phase 2 |
| RES-02 | Phase 2 |
| OPT-01 | Phase 3 |
| OPT-02 | Phase 3 |
| OPT-03 | Phase 3 |
| OPT-04 | Phase 3 |
| OPT-05 | Phase 3 |
| OPT-06 | Phase 3 |
| API-06 | Phase 3 |
| OBS-01 | Phase 3 |
| OBS-02 | Phase 3 |
| EX-01 | Phase 3 |
| EX-02 | Phase 3 |

**Total mapped:** 26/26 ✓

---

*Roadmap created: 2026-03-06*
