# Phase 2: Parameter Space & Results Layer - Context

**Gathered:** 2026-03-07
**Status:** Ready for planning

<domain>
## Phase Boundary

Define the public API contract for the `@mloop.optimize(...)` decorator — parameter declaration, validation at decoration time, and the `OptimizeResult` dataclass. This is what users write code against and what Phases 3–4 build on top of. The actual optimization loop (Phase 4) and surrogate model (Phase 3) are out of scope here.

</domain>

<decisions>
## Implementation Decisions

### Import & Usage Style
- Canonical form shown in all examples and README: `import mloopforml as mloop` → `@mloop.optimize(...)`
- Bare import also supported: `from mloopforml import optimize` → `@optimize(...)`
- Package name stays `mloopforml` — `mloop` is a user-side alias convention only, not a top-level importable module
- `optimize` must be exported from `mloopforml.__init__`

### OptimizeResult Shape
- Lean — exactly 4 fields, no extras:
  - `best_params` (dict) — best parameter set found
  - `best_score` (float) — best score as the user returned it (not negated)
  - `all_params` (list of dicts) — full parameter history, one entry per trial
  - `all_costs` (list of floats) — full score history, stored as user returned them; failed trials stored as `float('nan')`
- No `n_iterations_run`, `elapsed_seconds`, or other extras in v1

### Bad Run Handling
- Bad runs are auto-detected — user never needs a special API:
  - User's function returns `float('nan')` or `float('inf')` → classified as bad run
  - User's function raises an exception → caught, classified as bad run
- Internally follows M-LOOP's `bad=True` + `float('inf')` convention when feeding the surrogate (Phase 3), so future M-LOOP compatibility is preserved
- `all_costs` stores `float('nan')` for bad runs so history is honest and transparent
- User is never exposed to the internal bad-run mechanism

### Validation — Decorator Arguments
All invalid inputs raise a contextual `ValueError` **at decoration time**, not at trial execution. Error messages always include: parameter name (where applicable) + what's wrong + what was actually provided.

Validated at decoration time:
- `params` dict: must be non-empty; each value must be a 2-tuple of numeric `(min, max)` with `min < max`
  - Non-numeric values → `ValueError: Parameter 'lr': bounds must be numeric, got ('fast', 'slow')`
  - Wrong shape (single value, 3-tuple, etc.) → `ValueError: Parameter 'lr': bounds must be a (min, max) tuple, got 0.01`
  - `min >= max` → `ValueError: Parameter 'lr': min (0.1) must be less than max (0.001). Got: (0.1, 0.001)`
  - Empty dict → `ValueError: params must be a non-empty dict of parameter bounds, got {}`
- `direction`: accepts `"minimize"`, `"min"`, `"maximize"`, `"max"` (normalized internally); anything else → `ValueError: direction must be 'minimize'/'min' or 'maximize'/'max', got 'up'`
- `seed`: must be `int` or `None`; anything else → `ValueError: seed must be an integer or None, got 3.7`

### Claude's Discretion
- `OptimizeResult` implementation: `@dataclass` vs `NamedTuple` — Claude decides
- Internal module layout (`optimize.py`, `result.py`, etc.) — Claude decides
- `OptimizeResult` exported from `__init__` (reasonable since it's the return type, but not emphasized in docs)

</decisions>

<specifics>
## Specific Ideas

- "mloopforml is verbose — mloop is a nice shortening. My library is just a convenient wrapper for the M-LOOP work anyway." → `mloop` alias is the idiomatic style in all examples.
- Bad run handling should follow M-LOOP's internal convention (`bad=True` + `float('inf')` to surrogate) so if M-LOOP's approach changes in the future, we stay compatible. This is an internal detail — users never see it.
- Contextual errors always preferred over minimal ones: "contextual is always best."

</specifics>

<code_context>
## Existing Code Insights

### Reusable Assets
- `src/mloopforml/__init__.py`: Currently only exports `__version__`. Phase 2 will add `optimize` (and optionally `OptimizeResult`) to `__all__` and the module namespace.
- `tests/test_version.py`: Existing test pattern — straightforward pytest, no fixtures. New tests follow the same style.

### Established Patterns
- `importlib.metadata` for version — already in place, no changes needed
- `src/` layout with `pyproject.toml` — package installs cleanly via `pip install -e .`
- `requires-python = ">=3.11"`, numpy + scipy only runtime deps

### Integration Points
- `__init__.py` must export `optimize` so `from mloopforml import optimize` works
- Phase 3 (surrogate) will consume the validated parameter space produced here — the bounds dict is the contract between phases
- Phase 4 (loop) will call the decorator-wrapped function and populate `OptimizeResult` with trial results

### M-LOOP Reference
- Bad run mechanism sourced from `mloop/controllers.py` `_send_to_learner()`: `cost = float('inf') if self.curr_bad else self.curr_cost`
- Bootstrap threshold from `MachineLearnerController.__init__`: `max(10, 2 * int(num_params))` — used in Phase 3

</code_context>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope.

</deferred>

---

*Phase: 02-parameter-space-results-layer*
*Context gathered: 2026-03-07*
