# Phase 2: Parameter Space & Results Layer — Research

**Researched:** 2026-03-07
**Domain:** Python decorator construction, dataclasses/NamedTuple, parameter validation, public API design
**Confidence:** HIGH — all findings drawn from stdlib docs, existing codebase inspection, and Python 3.11+ language specification

---

<user_constraints>
## User Constraints (from CONTEXT.md)

### Locked Decisions

**Import & Usage Style**
- Canonical form shown in all examples and README: `import mloopforml as mloop` → `@mloop.optimize(...)`
- Bare import also supported: `from mloopforml import optimize` → `@optimize(...)`
- Package name stays `mloopforml` — `mloop` is a user-side alias convention only, not a top-level importable module
- `optimize` must be exported from `mloopforml.__init__`

**OptimizeResult Shape**
- Lean — exactly 4 fields, no extras:
  - `best_params` (dict) — best parameter set found
  - `best_score` (float) — best score as the user returned it (not negated)
  - `all_params` (list of dicts) — full parameter history, one entry per trial
  - `all_costs` (list of floats) — full score history, stored as user returned them; failed trials stored as `float('nan')`
- No `n_iterations_run`, `elapsed_seconds`, or other extras in v1

**Bad Run Handling**
- Bad runs are auto-detected — user never needs a special API:
  - User's function returns `float('nan')` or `float('inf')` → classified as bad run
  - User's function raises an exception → caught, classified as bad run
- Internally follows M-LOOP's `bad=True` + `float('inf')` convention when feeding the surrogate (Phase 3)
- `all_costs` stores `float('nan')` for bad runs so history is honest and transparent
- User is never exposed to the internal bad-run mechanism

**Validation — Decorator Arguments**
All invalid inputs raise a contextual `ValueError` **at decoration time**, not at trial execution.
Error messages always include: parameter name (where applicable) + what's wrong + what was actually provided.

Validated at decoration time:
- `params` dict: must be non-empty; each value must be a 2-tuple of numeric `(min, max)` with `min < max`
  - Non-numeric values → `ValueError: Parameter 'lr': bounds must be numeric, got ('fast', 'slow')`
  - Wrong shape (single value, 3-tuple, etc.) → `ValueError: Parameter 'lr': bounds must be a (min, max) tuple, got 0.01`
  - `min >= max` → `ValueError: Parameter 'lr': min (0.1) must be less than max (0.001). Got: (0.1, 0.001)`
  - Empty dict → `ValueError: params must be a non-empty dict of parameter bounds, got {}`
- `direction`: accepts `"minimize"`, `"min"`, `"maximize"`, `"max"` (normalized internally); anything else → `ValueError: direction must be 'minimize'/'min' or 'maximize'/'max', got 'up'`
- `seed`: must be `int` or `None`; anything else → `ValueError: seed must be an integer or None, got 3.7`

### Claude's Discretion

- `OptimizeResult` implementation: `@dataclass` vs `NamedTuple` — Claude decides
- Internal module layout (`optimize.py`, `result.py`, etc.) — Claude decides
- `OptimizeResult` exported from `__init__` (reasonable since it's the return type, but not emphasized in docs)

### Deferred Ideas (OUT OF SCOPE)

None — discussion stayed within phase scope.
</user_constraints>

---

<phase_requirements>
## Phase Requirements

| ID | Description | Research Support |
|----|-------------|-----------------|
| API-01 | User can decorate a function with `@mloop.optimize(params={"lr": (0.001, 0.1)})` | Decorator factory pattern (`optimize(**kwargs)` returns a decorator); `functools.wraps` preserves function metadata |
| API-02 | User can specify continuous hyperparameter ranges as `(min, max)` float tuples | `params` dict validation: check each value is a 2-tuple, both elements are `int` or `float`, `min < max` |
| API-03 | User can set `max_iterations` on the decorator to control total trial count | Decorator signature: `optimize(params, max_iterations=50, direction="minimize", seed=None)` — validated at decoration time |
| API-04 | User can set `direction="minimize"` or `direction="maximize"` | Normalize at decoration time: `{"minimize": -1, "min": -1, "maximize": 1, "max": 1}` dict lookup; unknown values → `ValueError` |
| API-05 | User can set `seed` for reproducible runs | Accept `int` or `None`; store on decorator config; passed to numpy RNG in Phase 4 |
| API-07 | Importing the module does not trigger any optimization logic | `optimize` at decoration time only validates + stores config; actual loop runs only when the wrapped function is called (Phase 4) |
| API-08 | Invalid parameter bounds raise `ValueError` at decoration time | Validation runs inside `optimize()` before the inner decorator function is returned; never deferred to wrapper execution |
| RES-01 | Decorated function returns `OptimizeResult` with `best_params` (dict) and `best_score` (float) | `OptimizeResult` dataclass with typed fields; Phase 4 populates and returns it |
| RES-02 | `OptimizeResult` also exposes `all_params` (list of dicts) and `all_costs` (list of floats) | Same dataclass — 4-field definition fully in scope for Phase 2 |
</phase_requirements>

---

## Summary

Phase 2 is a pure Python API layer — no numeric computation, no ML code. The deliverables are: (1) a validated decorator factory that accepts the optimization configuration and locks the parameter space contract, and (2) an `OptimizeResult` dataclass (or NamedTuple) that defines the shape of the final output that Phases 3 and 4 will populate.

The entire phase's complexity lives in two places: the validation logic inside `optimize()`, and the choice of `@dataclass` vs `NamedTuple` for `OptimizeResult`. Everything else is Python fundamentals — decorator factories, `functools.wraps`, and type annotations. Because this is stdlib-only, there are no third-party library choices to make: no research into PyPI packages is needed.

**Recommendation on `@dataclass` vs `NamedTuple`:** Use `@dataclass(frozen=True)` for `OptimizeResult`. It gives named fields, type annotations, `repr`, `eq`, and immutability — everything a `NamedTuple` offers — without the footguns of index-based access (`result[0]`) and positional construction that NamedTuple allows. It is also easier to extend with `@classmethod` factory methods if Phase 4 needs them. Both approaches are equivalent for this use case; `@dataclass(frozen=True)` is the modern idiomatic choice for Python 3.11+.

**Primary recommendation:** Single-plan phase — implement `optimize.py` (decorator + validation) + `result.py` (`OptimizeResult`) + update `__init__.py` in one wave, with tests written first.

---

## Standard Stack

### Core (stdlib only — no new dependencies)

| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| `functools.wraps` | stdlib 3.11+ | Preserve `__name__`, `__doc__`, `__wrapped__` on the decorated function | Required to avoid confusing users who inspect `help(their_function)` or use debuggers |
| `dataclasses.dataclass` | stdlib 3.11+ | `OptimizeResult` — typed, immutable result container | `frozen=True` gives immutability; cleaner than NamedTuple for heterogeneous field types |
| `typing` / `collections.abc` | stdlib 3.11+ | Type annotations — `Any`, `Callable`, `dict`, `list` | Python 3.11+ allows `list[dict[str, float]]` natively without `from typing import List` |
| `math.isfinite`, `math.isnan` | stdlib 3.11+ | Numeric bound validation | Handles `float('inf')`, `float('nan')`, and NaN bounds correctly; no external dep |

### Supporting (already installed — no additions)

| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| `pytest` | >=8.0 | Test runner | All tests |
| `pytest-cov` | >=7.0 | Coverage | CI coverage gate |

### No New PyPI Dependencies

Phase 2 adds zero new runtime or dev dependencies. The existing stack from `pyproject.toml` (`numpy>=2.0`, `scipy>=1.15`, `pytest`, `ruff`) covers everything.

---

## Architecture Patterns

### Recommended Module Layout

```
src/mloopforml/
├── __init__.py          # exports: optimize, OptimizeResult, __version__
├── optimize.py          # optimize() decorator factory + _validate_params()
└── result.py            # OptimizeResult dataclass
```

**Why split `optimize.py` and `result.py`:**
- Phase 3 will import `OptimizeResult` to construct results — it should not need to import anything from the optimizer/decorator machinery
- Phase 4 will import both; the split keeps imports clean and avoids circular imports
- `result.py` is a pure data definition with zero logic — it stays stable across all future phases
- `optimize.py` will grow significantly in Phase 4 when the loop is wired in; isolation now prevents conflicts

### Pattern 1: Decorator Factory (Two-Level)

**What:** `optimize(params=..., max_iterations=50, ...)` is called with config → validates → returns a decorator → decorator wraps the user's function. The wrapped function is callable but does nothing yet (Phase 4 adds the loop).

**When to use:** Any time a decorator takes arguments. This is the standard Python pattern for parameterized decorators.

**Example:**
```python
# src/mloopforml/optimize.py
# Source: Python docs — https://docs.python.org/3.11/reference/compound_stmts.html#function-definitions
import functools
from collections.abc import Callable
from typing import Any

from .result import OptimizeResult


def optimize(
    params: dict[str, tuple[float, float]],
    max_iterations: int = 50,
    direction: str = "minimize",
    seed: int | None = None,
) -> Callable:
    """Decorator factory: validate config at decoration time, store for Phase 4."""
    # All validation happens here — before the inner decorator is returned
    _validate_params(params)
    _validate_direction(direction)
    _validate_seed(seed)

    # Normalize direction to internal sign convention
    _direction_sign = -1 if direction in ("minimize", "min") else 1

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> OptimizeResult:
            # Phase 4 replaces this body with the actual optimization loop
            raise NotImplementedError(
                "Optimization loop not yet implemented (Phase 4). "
                "This stub exists to validate the decorator API."
            )

        # Attach config to wrapper for Phase 4 to discover
        wrapper._mloop_config = {
            "params": params,
            "max_iterations": max_iterations,
            "direction": direction,
            "direction_sign": _direction_sign,
            "seed": seed,
        }
        return wrapper

    return decorator
```

**Important:** The `wrapper._mloop_config` attribute attachment is the clean handoff mechanism for Phase 4. Phase 4 replaces the `wrapper` body — it doesn't monkey-patch; the entire `optimize.py` gets expanded. Attaching config to the wrapper function object makes it inspectable from tests and the loop.

### Pattern 2: Staged Validation with Contextual Errors

**What:** Validation runs in discrete steps — params structure → params types → params min < max → direction → seed. Each step raises immediately with a message that includes the parameter name, what went wrong, and what was received.

**When to use:** Always — decorators that fail silently or give generic errors destroy user trust.

**Example:**
```python
# src/mloopforml/optimize.py (validation helpers)
# Source: Python docs — isinstance, type checking, ValueError conventions

def _validate_params(params: dict) -> None:
    """Validate the params dict at decoration time."""
    if not isinstance(params, dict) or len(params) == 0:
        raise ValueError(
            f"params must be a non-empty dict of parameter bounds, got {params!r}"
        )
    for name, bounds in params.items():
        # Check shape: must be a 2-element sequence
        if (
            not isinstance(bounds, (tuple, list))
            or len(bounds) != 2
        ):
            raise ValueError(
                f"Parameter {name!r}: bounds must be a (min, max) tuple, got {bounds!r}"
            )
        lo, hi = bounds
        # Check numeric types: int or float, but not bool (bool is subclass of int)
        if not isinstance(lo, (int, float)) or isinstance(lo, bool) or \
           not isinstance(hi, (int, float)) or isinstance(hi, bool):
            raise ValueError(
                f"Parameter {name!r}: bounds must be numeric, got {(lo, hi)!r}"
            )
        # Reject NaN / inf bounds (semantically nonsensical)
        import math
        if not math.isfinite(lo) or not math.isfinite(hi):
            raise ValueError(
                f"Parameter {name!r}: bounds must be finite numbers, got {(lo, hi)!r}"
            )
        # Check ordering
        if lo >= hi:
            raise ValueError(
                f"Parameter {name!r}: min ({lo}) must be less than max ({hi}). "
                f"Got: {(lo, hi)!r}"
            )


def _validate_direction(direction: str) -> None:
    _valid = {"minimize", "min", "maximize", "max"}
    if direction not in _valid:
        raise ValueError(
            f"direction must be 'minimize'/'min' or 'maximize'/'max', got {direction!r}"
        )


def _validate_seed(seed: object) -> None:
    if seed is not None and (not isinstance(seed, int) or isinstance(seed, bool)):
        raise ValueError(
            f"seed must be an integer or None, got {seed!r}"
        )
```

**`bool` exclusion detail:** In Python, `bool` is a subclass of `int`, so `isinstance(True, int)` is `True`. A user passing `seed=True` or bounds `(True, False)` should get a `ValueError`, not silent acceptance. Always check `not isinstance(x, bool)` after `isinstance(x, int)`.

### Pattern 3: OptimizeResult as Frozen Dataclass

**What:** A `@dataclass(frozen=True)` with 4 typed fields. Frozen makes it immutable — Phase 4 creates one instance and returns it; nothing can mutate it afterward.

**When to use:** Result objects that are returned to users and should not change after creation.

**Example:**
```python
# src/mloopforml/result.py
# Source: Python docs — https://docs.python.org/3.11/library/dataclasses.html
from dataclasses import dataclass


@dataclass(frozen=True)
class OptimizeResult:
    """Immutable result of a completed mloopforml optimization run.

    Attributes:
        best_params: Parameter set that produced the best score.
        best_score: Best score returned by the objective function (not negated).
        all_params: One dict per trial, in trial order.
        all_costs: One float per trial (user-returned value). Failed trials
            are stored as float('nan').
    """

    best_params: dict[str, float]
    best_score: float
    all_params: list[dict[str, float]]
    all_costs: list[float]
```

**Why `frozen=True`:** Prevents accidental mutation (`result.best_score = 99.0` raises `FrozenInstanceError`). Results should be immutable records — they represent a completed experiment, not mutable state.

**Why not `NamedTuple`:** NamedTuple allows index-based access (`result[0]`) which is confusing for a 4-field object with heterogeneous types. It also cannot have `@classmethod` factory methods or docstrings on fields. `@dataclass` is the more forward-compatible choice and has no meaningful downside here.

### Pattern 4: `__init__.py` Export Update

**What:** Add `optimize` and optionally `OptimizeResult` to `__init__.py` so both usage styles work.

**Example:**
```python
# src/mloopforml/__init__.py (Phase 2 version)
"""mloopforml — neural network surrogate hyperparameter optimization."""

from importlib.metadata import PackageNotFoundError, version

from .optimize import optimize
from .result import OptimizeResult

try:
    __version__ = version("mloopforml")
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = ["__version__", "optimize", "OptimizeResult"]
```

**Import order matters for API-07:** The `from .optimize import optimize` line runs when the module is imported. Since `optimize.py` only defines functions (no module-level side effects), this is safe. The optimization loop will only run when the decorated function is *called*, not when it is *defined* or when the module is *imported*.

### Anti-Patterns to Avoid

- **Lazy validation inside the wrapper:** Running `_validate_params()` inside the `wrapper` function instead of inside `optimize()` means validation doesn't happen until the function is called — violates API-08.
- **`isinstance(x, int)` without `bool` exclusion:** `True` and `False` silently pass as valid seeds or bounds. Always exclude `bool` explicitly.
- **Mutable default arguments:** `def optimize(params={}):` — Python creates the dict once, shared across all calls. Use `None` with a `params is None` guard, or rely on type annotations only (no default for required args like `params`).
- **Importing numpy at module load time in optimize.py:** Phase 4 will add numpy; but Phase 2 should not import numpy at the top of optimize.py since Phase 2 doesn't use it. Premature imports add cost to every `import mloopforml`.
- **Storing the inner function's args:** Don't store `*args/**kwargs` from the `wrapper` call — Phase 2's wrapper body will be replaced in Phase 4. The `_mloop_config` dict stores decorator-time config only.
- **`@dataclass` without `frozen=True`:** Mutable result objects let users corrupt their own results accidentally (`result.best_score = 0`). Always freeze result objects.

---

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Decorator metadata preservation | Custom `__name__` copying | `functools.wraps` | Handles `__name__`, `__qualname__`, `__doc__`, `__annotations__`, `__module__`, `__dict__`, `__wrapped__` — missing any one breaks debuggers and `help()` |
| Immutable result containers | Custom `__setattr__` guard | `@dataclass(frozen=True)` | `frozen=True` generates `__setattr__` and `__delattr__` that raise `FrozenInstanceError`; `__hash__` is also generated (hashable by default); no boilerplate |
| `repr` for result objects | Custom `__repr__` | `@dataclass` auto-generates `repr=True` (default) | Auto-repr includes all fields with names; matches user expectations for `print(result)` |

**Key insight:** Phase 2 is pure Python stdlib. Every piece of "infrastructure" needed (frozen dataclasses, functools.wraps, type hints) was added to Python before 3.9. There is nothing to install.

---

## Common Pitfalls

### Pitfall 1: Validation That Runs at Call Time Instead of Decoration Time

**What goes wrong:** `_validate_params(params)` is placed inside `wrapper()` rather than inside `optimize()`. The decorator applies successfully even with invalid bounds. The `ValueError` only fires when the user calls `result = my_function()` — possibly much later in their script, after setup work.

**Why it happens:** It feels natural to put all logic inside the wrapper. Developers forget the two-level structure means `optimize()` runs at decoration time.

**How to avoid:** Place ALL validation in the `optimize()` function body, before `def decorator(func):`. Test this explicitly: `optimize(params={"lr": (0.1, 0.001)})` (no decorating) should raise immediately.

**Warning signs:** Test for `API-08` passes only when calling the function, not when applying the decorator.

### Pitfall 2: `bool` Accepted as `int` for Seed and Bounds

**What goes wrong:** `@mloop.optimize(params={"lr": (True, False)}, seed=True)` silently succeeds because `isinstance(True, int)` is `True` in Python. The surrogate later receives `(1, 0)` as bounds with `min > max`.

**Why it happens:** `bool` is a subclass of `int` in Python — this surprises many developers.

**How to avoid:**
```python
# Correct check for "int but not bool"
def is_real_int(x):
    return isinstance(x, int) and not isinstance(x, bool)

# Correct check for "numeric (int or float) but not bool"
def is_numeric(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)
```

**Warning signs:** `seed=True` passes validation without error.

### Pitfall 3: `params` Dict Mutated After Decoration

**What goes wrong:** User holds a reference to the `params` dict and mutates it after decoration. The stored bounds in `_mloop_config["params"]` change underneath the optimizer.

**Why it happens:** Python dicts are mutable and passed by reference. Storing the original reference means changes propagate.

**How to avoid:** Deep-copy the params dict inside `optimize()`:
```python
import copy
params = copy.deepcopy(params)  # defend against external mutation
```

**Warning signs:** Running the same decorated function twice with different external `params` dicts produces inconsistent results.

### Pitfall 4: `all_costs` Type Confusion — Storing "direction-adjusted" Costs

**What goes wrong:** Phase 4 uses negated costs internally for minimization. If `all_costs` accidentally stores the negated value instead of the user's raw return value, `OptimizeResult` violates the spec ("stored as user returned them").

**Why it happens:** The optimization loop internally flips sign for `direction="maximize"`. If that negated value flows into `OptimizeResult` construction, users see `-0.95` instead of `0.95`.

**How to avoid:** `OptimizeResult.all_costs` always receives the raw value from the objective function, before any sign flip. Document this contract in a comment in Phase 4's loop. Phase 2's dataclass definition makes no claim about internal conventions — this is a Phase 4 implementation concern, but the Phase 2 contract must state it explicitly.

**Warning signs:** `result.best_score` is negative when user function returns positive values under `direction="maximize"`.

### Pitfall 5: Circular Import Between `__init__.py` and `optimize.py`

**What goes wrong:** `optimize.py` imports something from `mloopforml` (the package) instead of using relative imports. When Python imports `mloopforml`, it runs `__init__.py`, which imports from `optimize.py`, which tries to import from `mloopforml` — circular.

**Why it happens:** Developers use `from mloopforml.result import OptimizeResult` (absolute) inside `optimize.py` instead of `from .result import OptimizeResult` (relative).

**How to avoid:** All intra-package imports in `optimize.py` and `result.py` must use relative imports (`from .result import OptimizeResult`). `__init__.py` uses relative imports too (`from .optimize import optimize`).

**Warning signs:** `ImportError: cannot import name 'optimize' from partially initialized module 'mloopforml'`

---

## Code Examples

### Complete `result.py`

```python
# src/mloopforml/result.py
# Source: Python docs — https://docs.python.org/3.11/library/dataclasses.html
from dataclasses import dataclass


@dataclass(frozen=True)
class OptimizeResult:
    """Immutable result of a completed mloopforml optimization run.

    Attributes:
        best_params: Parameter set that produced the best score.
        best_score: Best score as returned by the objective function
            (not sign-flipped). Higher or lower depending on direction.
        all_params: Full parameter history — one dict per trial in order.
        all_costs: Full score history — one float per trial as returned
            by the objective function. Failed trials are float('nan').
    """

    best_params: dict[str, float]
    best_score: float
    all_params: list[dict[str, float]]
    all_costs: list[float]
```

### Complete `optimize.py` (Phase 2 stub — Phase 4 expands the wrapper body)

```python
# src/mloopforml/optimize.py
"""optimize() decorator factory — parameter validation and config storage."""

import copy
import math
from collections.abc import Callable
from typing import Any

from .result import OptimizeResult


_VALID_DIRECTIONS = {"minimize", "min", "maximize", "max"}


def optimize(
    params: dict[str, tuple[float, float]],
    max_iterations: int = 50,
    direction: str = "minimize",
    seed: int | None = None,
) -> Callable:
    """Decorate a function to define it as a hyperparameter optimization target.

    All arguments are validated immediately when the decorator is applied.

    Args:
        params: Mapping of parameter name to (min, max) float bounds.
        max_iterations: Total number of trials to run (default 50).
        direction: "minimize" / "min" or "maximize" / "max".
        seed: Integer seed for reproducibility, or None for random.

    Returns:
        A decorator that wraps the objective function.

    Raises:
        ValueError: On invalid params, direction, or seed — at decoration time.
    """
    # Deep-copy to prevent external mutation after decoration
    params = copy.deepcopy(params)

    # Validate everything at decoration time (API-08)
    _validate_params(params)
    _validate_direction(direction)
    _validate_seed(seed)

    # Normalize direction to internal sign convention
    direction_sign = -1 if direction in ("minimize", "min") else 1

    def decorator(func: Callable) -> Callable:
        import functools

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> OptimizeResult:
            # Phase 4 replaces this body with the full optimization loop.
            raise NotImplementedError(
                "Optimization loop not yet implemented (Phase 4)."
            )

        # Attach validated config for Phase 4 to discover
        wrapper._mloop_config = {
            "params": params,
            "max_iterations": max_iterations,
            "direction": direction,
            "direction_sign": direction_sign,
            "seed": seed,
        }
        return wrapper

    return decorator


def _validate_params(params: object) -> None:
    if not isinstance(params, dict) or len(params) == 0:
        raise ValueError(
            f"params must be a non-empty dict of parameter bounds, got {params!r}"
        )
    for name, bounds in params.items():
        if not isinstance(bounds, (tuple, list)) or len(bounds) != 2:
            raise ValueError(
                f"Parameter {name!r}: bounds must be a (min, max) tuple, got {bounds!r}"
            )
        lo, hi = bounds
        if (
            not isinstance(lo, (int, float)) or isinstance(lo, bool)
            or not isinstance(hi, (int, float)) or isinstance(hi, bool)
        ):
            raise ValueError(
                f"Parameter {name!r}: bounds must be numeric, got {(lo, hi)!r}"
            )
        if not math.isfinite(lo) or not math.isfinite(hi):
            raise ValueError(
                f"Parameter {name!r}: bounds must be finite numbers, got {(lo, hi)!r}"
            )
        if lo >= hi:
            raise ValueError(
                f"Parameter {name!r}: min ({lo}) must be less than max ({hi}). "
                f"Got: {(lo, hi)!r}"
            )


def _validate_direction(direction: object) -> None:
    if direction not in _VALID_DIRECTIONS:
        raise ValueError(
            f"direction must be 'minimize'/'min' or 'maximize'/'max', got {direction!r}"
        )


def _validate_seed(seed: object) -> None:
    if seed is not None and (not isinstance(seed, int) or isinstance(seed, bool)):
        raise ValueError(
            f"seed must be an integer or None, got {seed!r}"
        )
```

### Key Test Patterns

```python
# tests/test_optimize.py — decoration-time validation (API-08)
import pytest
import mloopforml as mloop


# ── Happy path ────────────────────────────────────────────────────────────────

def test_decoration_succeeds_with_valid_params():
    """API-01, API-02, API-03, API-04, API-05: No error at decoration time."""
    @mloop.optimize(params={"lr": (0.001, 0.1)}, max_iterations=20,
                    direction="maximize", seed=42)
    def train(lr):
        return lr * 2  # stub

    assert callable(train)


# ── params validation ─────────────────────────────────────────────────────────

def test_empty_params_raises():
    with pytest.raises(ValueError, match="non-empty dict"):
        mloop.optimize(params={})

def test_non_numeric_bounds_raises():
    with pytest.raises(ValueError, match="Parameter 'lr': bounds must be numeric"):
        mloop.optimize(params={"lr": ("fast", "slow")})

def test_wrong_shape_bounds_raises():
    with pytest.raises(ValueError, match="Parameter 'lr': bounds must be a .min, max. tuple"):
        mloop.optimize(params={"lr": 0.01})

def test_min_ge_max_raises():
    with pytest.raises(ValueError, match="min .* must be less than max"):
        mloop.optimize(params={"lr": (0.1, 0.001)})

def test_min_equal_max_raises():
    with pytest.raises(ValueError, match="min .* must be less than max"):
        mloop.optimize(params={"lr": (0.1, 0.1)})

# ── direction validation ──────────────────────────────────────────────────────

def test_invalid_direction_raises():
    with pytest.raises(ValueError, match="direction must be"):
        mloop.optimize(params={"lr": (0.001, 0.1)}, direction="up")

@pytest.mark.parametrize("direction", ["minimize", "min", "maximize", "max"])
def test_valid_directions_accepted(direction):
    @mloop.optimize(params={"lr": (0.001, 0.1)}, direction=direction)
    def f(lr): ...
    assert callable(f)

# ── seed validation ───────────────────────────────────────────────────────────

def test_invalid_seed_raises():
    with pytest.raises(ValueError, match="seed must be an integer or None"):
        mloop.optimize(params={"lr": (0.001, 0.1)}, seed=3.7)

def test_bool_seed_raises():
    with pytest.raises(ValueError, match="seed must be an integer or None"):
        mloop.optimize(params={"lr": (0.001, 0.1)}, seed=True)

# ── validation at decoration time, not call time ──────────────────────────────

def test_validation_happens_at_decoration_not_call_time():
    """API-08: Error fires when optimize() is called, not when wrapper() is called."""
    with pytest.raises(ValueError):
        # This is the decoration step — no function involved yet
        mloop.optimize(params={"lr": (0.1, 0.001)})


# tests/test_result.py — OptimizeResult contract (RES-01, RES-02)
from mloopforml import OptimizeResult

def test_optimize_result_fields():
    result = OptimizeResult(
        best_params={"lr": 0.05},
        best_score=0.95,
        all_params=[{"lr": 0.05}],
        all_costs=[0.95],
    )
    assert result.best_params == {"lr": 0.05}
    assert result.best_score == 0.95
    assert result.all_params == [{"lr": 0.05}]
    assert result.all_costs == [0.95]

def test_optimize_result_is_immutable():
    result = OptimizeResult(
        best_params={"lr": 0.05},
        best_score=0.95,
        all_params=[],
        all_costs=[],
    )
    with pytest.raises(Exception):  # FrozenInstanceError
        result.best_score = 0.0

def test_failed_trial_stored_as_nan():
    import math
    result = OptimizeResult(
        best_params={"lr": 0.05},
        best_score=0.95,
        all_params=[{"lr": 0.01}, {"lr": 0.05}],
        all_costs=[float("nan"), 0.95],
    )
    assert math.isnan(result.all_costs[0])
```

---

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| `NamedTuple` for result containers | `@dataclass(frozen=True)` | Python 3.7+ (dataclasses) | Named field access, forward-compatible with adding `@classmethod`, no index-based access footgun |
| `from typing import List, Dict, Tuple` | `list[dict]`, `tuple[float, float]` (built-in generics) | Python 3.9+ (PEP 585), standard in 3.11 | Cleaner annotations, no import needed; `list[dict[str, float]]` is idiomatic in 3.11+ |
| `Union[int, None]` | `int \| None` (PEP 604 union syntax) | Python 3.10+, standard in 3.11 | More readable; requires `from __future__ import annotations` in 3.9/3.10 — not needed in 3.11+ |
| Custom `__repr__` / `__eq__` | `@dataclass` auto-generates both | Python 3.7+ | No boilerplate |

**Deprecated/outdated (for this phase):**
- `typing.NamedTuple` for result objects: Works, but no immutability enforcement, no methods, awkward to extend. Not wrong, but `@dataclass(frozen=True)` is the modern choice.
- `from typing import Callable, Any`: In Python 3.11+, prefer `from collections.abc import Callable` for `Callable` (PEP 585); use bare `Any` from `typing` (still required for `Any`).

---

## Open Questions

1. **`functools.wraps` and `_mloop_config` attribute on wrapper**
   - What we know: `functools.wraps` copies `__wrapped__`, `__doc__`, etc. but does NOT prevent adding custom attributes. `wrapper._mloop_config = {...}` after `@functools.wraps(func)` works correctly.
   - What's unclear: Nothing — this pattern is confirmed Python behavior.
   - Recommendation: Use it as shown. Phase 4 reads `wrapper._mloop_config` to get the validated params and config.

2. **`max_iterations` validation scope**
   - What we know: CONTEXT.md specifies validation for `params`, `direction`, `seed`. `max_iterations` is not listed explicitly.
   - What's unclear: Should `max_iterations=0` or `max_iterations=-5` raise at decoration time?
   - Recommendation: Add basic sanity validation for `max_iterations`: must be a positive `int`. Error: `ValueError: max_iterations must be a positive integer, got 0`. This is consistent with the "contextual errors always preferred" principle from CONTEXT.md, and the Phase 4 loop can't work with zero iterations.

3. **`OptimizeResult` exported from `__init__`**
   - What we know: CONTEXT.md marks this as Claude's discretion — "reasonable since it's the return type."
   - Recommendation: YES, export it. Users who do `from mloopforml import OptimizeResult` for type annotations (e.g., in their own type hints) will expect it to be importable from the top level. The cost is one line in `__init__.py`.

---

## Validation Architecture

### Test Framework

| Property | Value |
|----------|-------|
| Framework | pytest >=8.0 + pytest-cov >=7.0 |
| Config file | `pyproject.toml` `[tool.pytest.ini_options]` (already configured) |
| Quick run command | `pytest tests/test_optimize.py tests/test_result.py -x` |
| Full suite command | `pytest` |

### Phase Requirements → Test Map

| Req ID | Behavior | Test Type | Automated Command | File Exists? |
|--------|----------|-----------|-------------------|-------------|
| API-01 | `@mloop.optimize(params={"lr": (0.001, 0.1)})` applies without error | unit | `pytest tests/test_optimize.py::test_decoration_succeeds_with_valid_params -x` | ❌ Wave 0 |
| API-02 | `(min, max)` float tuples accepted; invalid shapes rejected | unit | `pytest tests/test_optimize.py -k "bounds" -x` | ❌ Wave 0 |
| API-03 | `max_iterations=20` accepted at decoration time | unit | `pytest tests/test_optimize.py::test_decoration_succeeds_with_valid_params -x` | ❌ Wave 0 |
| API-04 | `direction="maximize"` and aliases accepted; invalid → ValueError | unit | `pytest tests/test_optimize.py -k "direction" -x` | ❌ Wave 0 |
| API-05 | `seed=42` accepted; non-int → ValueError; bool → ValueError | unit | `pytest tests/test_optimize.py -k "seed" -x` | ❌ Wave 0 |
| API-07 | `import mloopforml` runs no optimization logic | unit | `pytest tests/test_optimize.py::test_import_has_no_side_effects -x` | ❌ Wave 0 |
| API-08 | Invalid bounds raise ValueError at decoration time, not call time | unit | `pytest tests/test_optimize.py::test_validation_happens_at_decoration_not_call_time -x` | ❌ Wave 0 |
| RES-01 | `OptimizeResult` has `best_params` (dict) and `best_score` (float) | unit | `pytest tests/test_result.py::test_optimize_result_fields -x` | ❌ Wave 0 |
| RES-02 | `OptimizeResult` has `all_params` (list[dict]) and `all_costs` (list[float]) | unit | `pytest tests/test_result.py::test_optimize_result_fields -x` | ❌ Wave 0 |

### Sampling Rate

- **Per task commit:** `pytest tests/test_optimize.py tests/test_result.py -x`
- **Per wave merge:** `pytest` (full suite including `test_version.py`)
- **Phase gate:** Full suite green before marking Phase 2 complete

### Wave 0 Gaps

- [ ] `tests/test_optimize.py` — covers API-01, API-02, API-03, API-04, API-05, API-07, API-08
- [ ] `tests/test_result.py` — covers RES-01, RES-02
- [ ] `src/mloopforml/optimize.py` — new module (decorator factory + validation)
- [ ] `src/mloopforml/result.py` — new module (OptimizeResult dataclass)
- [ ] `src/mloopforml/__init__.py` — update exports (add `optimize`, `OptimizeResult`)

*(No framework changes needed — pytest and pyproject.toml are already configured from Phase 1.)*

---

## Sources

### Primary (HIGH confidence)

- Python 3.11 stdlib docs — `dataclasses` module: https://docs.python.org/3.11/library/dataclasses.html
- Python 3.11 stdlib docs — `functools.wraps`: https://docs.python.org/3.11/library/functools.html#functools.wraps
- Python 3.11 stdlib docs — `math.isfinite`: https://docs.python.org/3.11/library/math.html#math.isfinite
- Python 3.11 stdlib docs — decorator syntax: https://docs.python.org/3.11/reference/compound_stmts.html#function-definitions
- PEP 585 — built-in generic types (Python 3.9+, standard in 3.11): https://peps.python.org/pep-0585/
- PEP 604 — `X | Y` union syntax (Python 3.10+, standard in 3.11): https://peps.python.org/pep-0604/
- Existing codebase inspection: `src/mloopforml/__init__.py`, `tests/test_version.py`, `pyproject.toml` — all confirmed current on 2026-03-07
- `.planning/phases/02-parameter-space-results-layer/02-CONTEXT.md` — all locked decisions sourced here

### Secondary (MEDIUM confidence)

- Phase 1 RESEARCH.md (`01-RESEARCH.md`) — established patterns (pytest, ruff, src layout) carried forward; all verified from Phase 1 sources

### Tertiary (LOW confidence — none)

*All Phase 2 findings are grounded in Python 3.11 stdlib documentation or direct codebase inspection. No speculative or unverified claims.*

---

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH — stdlib only; Python 3.11 docs are definitive
- Architecture patterns: HIGH — decorator factory pattern, `@dataclass(frozen=True)`, `functools.wraps` are well-established Python idioms with official docs
- Pitfalls: HIGH — `bool`-as-`int` and validation timing are documented Python behaviors; circular import pattern is well-understood

**Research date:** 2026-03-07
**Valid until:** Stable indefinitely — all findings are Python stdlib; no PyPI packages involved
