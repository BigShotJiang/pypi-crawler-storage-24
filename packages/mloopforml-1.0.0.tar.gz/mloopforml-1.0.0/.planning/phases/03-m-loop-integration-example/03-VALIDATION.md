---
phase: 3
slug: m-loop-integration-example
status: draft
nyquist_compliant: false
wave_0_complete: false
created: 2026-03-07
---

# Phase 3 — Validation Strategy

> Per-phase validation contract for feedback sampling during execution.

---

## Test Infrastructure

| Property | Value |
|----------|-------|
| **Framework** | pytest ≥8.0 |
| **Config file** | `pyproject.toml` `[tool.pytest.ini_options]` |
| **Quick run command** | `pytest tests/ -x -q --no-cov` |
| **Full suite command** | `pytest tests/ --cov=mloopforml --cov-report=term-missing` |
| **Estimated runtime** | ~30 seconds (integration tests use max_iterations=5) |

---

## Sampling Rate

- **After every task commit:** Run `pytest tests/ -x -q --no-cov`
- **After every plan wave:** Run `pytest tests/ --cov=mloopforml --cov-report=term-missing`
- **Before `/gsd-verify-work`:** Full suite must be green
- **Max feedback latency:** 30 seconds

---

## Per-Task Verification Map

| Task ID | Plan | Wave | Requirement | Test Type | Automated Command | File Exists | Status |
|---------|------|------|-------------|-----------|-------------------|-------------|--------|
| 3-01-01 | 01 | 0 | API-06, OPT-01..OPT-06, OBS-01, OBS-02, EX-01 | scaffold | `pytest tests/test_integration.py --collect-only` | ❌ W0 | ⬜ pending |
| 3-02-01 | 02 | 1 | API-06, OPT-01, OPT-02, OPT-03, OPT-05, OPT-06 | integration | `pytest tests/test_integration.py::test_optimize_returns_result tests/test_integration.py::test_neural_net_backend tests/test_integration.py::test_params_within_bounds tests/test_integration.py::test_result_scores_in_user_space tests/test_integration.py::test_exception_handling -x` | ❌ W0 | ⬜ pending |
| 3-02-02 | 02 | 1 | OBS-01, OBS-02 | unit | `pytest tests/test_integration.py::test_trial_log_format tests/test_integration.py::test_trial_labels -x` | ❌ W0 | ⬜ pending |
| 3-03-01 | 03 | 2 | EX-01, EX-02 | smoke | `pytest tests/test_integration.py::test_quickstart_example -x` | ❌ W0 | ⬜ pending |

*Status: ⬜ pending · ✅ green · ❌ red · ⚠️ flaky*

---

## Wave 0 Requirements

- [ ] `tests/test_integration.py` — stubs for API-06, OPT-01, OPT-02, OPT-03, OPT-05, OPT-06, OBS-01, OBS-02, EX-01
- [ ] `tests/conftest.py` — suppress mloop logger session-wide (`autouse=True, scope='session'`)
- [ ] `examples/quickstart.py` — runnable quickstart script (EX-01)
- [ ] `pyproject.toml` — add `rich>=13.0` to `[project.dependencies]`
- [ ] `src/mloopforml/optimize.py` — add `num_training_runs` param to factory + `_validate_num_training_runs()` + store in `_mloop_config`

*(No framework install needed — pytest already in `[dev]` extras)*

---

## Manual-Only Verifications

| Behavior | Requirement | Why Manual | Test Instructions |
|----------|-------------|------------|-------------------|
| README quickstart is correct API syntax | EX-02 | Requires human to copy-paste and confirm readable output | Run README snippet manually; verify `best_score` and `best_params` print at end |

---

## Validation Sign-Off

- [ ] All tasks have `<automated>` verify or Wave 0 dependencies
- [ ] Sampling continuity: no 3 consecutive tasks without automated verify
- [ ] Wave 0 covers all MISSING references
- [ ] No watch-mode flags
- [ ] Feedback latency < 30s
- [ ] `nyquist_compliant: true` set in frontmatter

**Approval:** pending
