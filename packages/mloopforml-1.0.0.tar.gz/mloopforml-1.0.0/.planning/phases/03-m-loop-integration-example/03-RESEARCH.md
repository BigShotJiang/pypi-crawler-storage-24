# Phase 3: M-LOOP Integration & Example - Research

**Researched:** 2026-03-07
**Domain:** M-LOOP Python API wiring, `rich` live terminal display, exception-safe optimization loops
**Confidence:** HIGH — M-LOOP source read directly from GitHub; `rich` API verified locally

---

<user_constraints>
## User Constraints (from CONTEXT.md)

### Locked Decisions

**M-LOOP API wiring:**
- Use `mloop.interfaces.Interface` subclass + `mloop.controllers.create_controller` + `controller.optimize()`
- M-LOOP passes params as a numpy array via `params_dict['params']` in `get_next_cost_dict` — map by index to param names from `_mloop_config['params']`
- Call user's function with `**named_params` (kwargs, matching param names declared in decorator)
- Convert returned score to M-LOOP cost using `direction_sign` already stored in `_mloop_config`
- Suppress M-LOOP's console logging to `ERROR` level — only our `rich` output shows

**`num_training_runs` parameter:**
- Exposed on the `@optimize` decorator as `num_training_runs`
- Defaults to `1` (not M-LOOP's default of 20)
- Maps directly to M-LOOP's `num_training_runs` config option
- Overrides OPT-01's `max(10, 2 × n_params)` default — planner should update that requirement

**Trial output (rich live display):**
- `rich` is a **required runtime dependency** — added to `pyproject.toml`, always available
- Live panel pinned to bottom of terminal, always showing: best score so far, best params so far, trials complete `N/M`
- Scrolling log above the panel: one line per completed trial
- Trial line format: `[Trial  N/M  LABEL] params={...} score=X.XXX (best: X.XXX)`
- Label is `TRAIN` for the first `num_training_runs` trials, `OPT` for all subsequent ML-guided trials

**Failed trial handling (OPT-06):**
- Claude's discretion on exact UX — requirements specify: log at WARNING, return `{'bad': True}` to M-LOOP, run continues
- Failed trials should still appear in the scrolling log with a visible failure indicator

**Example and README:**
- Claude's discretion — ship something minimal that works and demonstrates the decorator pattern
- README quickstart must use the correct API (`max_iterations=`, kwargs-style function signature)
- `examples/` directory should contain at least one runnable script

### Claude's Discretion
- Exact `rich` panel layout and styling
- Float precision in trial log output
- Failed trial log format
- Example content (synthetic function is fine)
- README structure beyond the quickstart snippet

### Deferred Ideas (OUT OF SCOPE)
None — discussion stayed within phase scope.
</user_constraints>

---

<phase_requirements>
## Phase Requirements

| ID | Description | Research Support |
|----|-------------|-----------------|
| API-06 | Calling the decorated function triggers the optimization loop and blocks until complete | `controller.optimize()` is synchronous; blocks until `max_num_runs` reached |
| OPT-01 | Bootstrap phase of `num_training_runs` random trials before surrogate activates | `MachineLearnerController.num_training_runs`; set to `1` by default per locked decisions |
| OPT-02 | Neural net surrogate (MLP) proposes candidates via scipy | `NeuralNetController` (subclass of `MachineLearnerController`) uses `NeuralNetLearner` internally |
| OPT-03 | All proposed parameter values stay within declared bounds | `Controller._enforce_boundaries()` clips automatically; we verify bounds in integration tests |
| OPT-04 | Multiple random restarts in scipy minimize | M-LOOP's `NeuralNetLearner` handles internally — verified by using library correctly |
| OPT-05 | Input/output normalization is internal to M-LOOP | `ParameterScaler` (MinMaxScaler) in `utilities.py`; `StandardScaler` in `neuralnet.py` — never surfaces to user |
| OPT-06 | Exception in objective → log WARNING + `bad=True` to M-LOOP + continue | `get_next_cost_dict` catches exception, logs, returns `{'bad': True}` |
| OBS-01 | Each completed trial logged: `[Trial N/M] params={...} score=X.XXX (best: X.XXX)` | `rich` Console from within `get_next_cost_dict` thread; must be thread-safe |
| OBS-02 | Bootstrap phase clearly identified in logs | Label `TRAIN` for first `num_training_runs` trials, `OPT` thereafter |
| EX-01 | Working example in `examples/` demonstrating decorator on ML use case | `examples/quickstart.py` with synthetic objective; `examples/sklearn_iris.py` if time allows |
| EX-02 | README minimal install-and-run example, copy-paste in <5 min | README.md quickstart block; correct API: `max_iterations=`, kwargs-style |
</phase_requirements>

---

## Summary

Phase 3 wires the `optimize()` decorator's `wrapper()` function to M-LOOP's Python API. The key insight is that M-LOOP is **multi-threaded**: `Interface` runs in one thread, learners run in background threads, and the controller drives both from the calling thread via `mp.Queue`. Our `_MLOOPInterface` subclass implements `get_next_cost_dict(params_dict)` — this single method is where all the interesting logic lives: param extraction, user function call, exception handling, `rich` logging, and returning cost dict.

The `rich` live display must be created in `wrapper()` (the calling thread) and accessed from `get_next_cost_dict` (the interface thread). The safest pattern is to use a `rich.console.Console` with `stderr=False` and call `console.print()` from the interface thread, while the Live panel's renderable is updated via shared mutable state (a list or dict protected by a threading.Lock). `rich.live.Live` was designed for exactly this pattern.

M-LOOP creates `./M-LOOP_archives/` and `./M-LOOP_logs/` directories and writes files unless explicitly suppressed. These side effects must be disabled in `create_controller` via `controller_archive_file_type=None` and `log_filename=None`, and M-LOOP's logger must be set to ERROR level before controller construction.

**Primary recommendation:** Implement `_MLOOPInterface` as a pure Python subclass of `mloop.interfaces.Interface`, wire it to `NeuralNetController` via `create_controller(..., controller_type='neural_net')`, and use `rich.live.Live` with a `Console(stderr=False)` for thread-safe live output.

---

## Standard Stack

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| M-LOOP | 3.3.5 | Neural net surrogate optimization backend | Already declared dependency; this phase wires to it |
| rich | 14.3.3 | Live terminal display of trials | Locked decision; runtime dep to be added to pyproject.toml |
| threading | stdlib | Thread safety for shared display state | M-LOOP's Interface runs in its own thread |
| logging | stdlib | Suppress M-LOOP's logger; emit our own warnings | Standard Python logging hierarchy |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| numpy | ≥2.0 | Param array access, bounds checking | Already a dep; params_dict['params'] is np.ndarray |
| functools | stdlib | preserve `__wrapped__` for tests | Already used in optimize.py |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| `rich.live.Live` | `tqdm` | tqdm is progress bars only; Live gives live-updating panel + scrolling log simultaneously |
| `rich.live.Live` | `curses` | curses is far harder; rich handles terminal detection, CI environments, and piped output gracefully |
| `controller_type='neural_net'` | `controller_type='gaussian_process'` | Locked decision: neural_net is the backend; GP not in scope |

**Installation (add to pyproject.toml `[project.dependencies]`):**
```toml
dependencies = [
    "numpy>=2.0",
    "scipy>=1.15",
    "M-LOOP>=3.0",
    "rich>=13.0",   # Add this line
]
```

---

## Architecture Patterns

### M-LOOP Threading Model (CRITICAL to understand)

M-LOOP's `controller.optimize()` starts two threads:
- **Interface thread** (`self.interface.start()`) — calls `get_next_cost_dict()` for each trial
- **Learner thread(s)** (`self.learner.start()`, `self.ml_learner.start()`) — trains NN, computes next params

The controller loop runs in the **calling thread** (our `wrapper()` thread). Communication happens via `mp.Queue`.

```
wrapper() [calling thread]
  │
  ├── creates _MLOOPInterface (not started yet)
  ├── creates controller via create_controller(...)
  ├── controller.optimize()
  │     ├── _start_up() → starts interface.start() + learner threads
  │     ├── _optimization_routine() ← BLOCKS HERE until max_num_runs
  │     │     ├── _put_params_and_out_dict() → puts params in params_out_queue
  │     │     ├── _get_cost_and_in_dict() ← BLOCKS waiting for cost in costs_in_queue
  │     │     └── loops until check_end_conditions() → False
  │     └── _shut_down() → joins all threads + saves archive
  └── reads controller.best_params, controller.best_cost, controller.out_params, etc.
```

**Interface thread:**
```
Interface.run() [interface thread]
  └── loop:
        ├── params_dict = params_out_queue.get(timeout=interface_wait)
        ├── cost_dict = self.get_next_cost_dict(params_dict)  ← OUR CODE RUNS HERE
        └── costs_in_queue.put(cost_dict)
```

### Recommended Project Structure
```
src/
└── mloopforml/
    ├── __init__.py          # unchanged
    ├── optimize.py          # wrapper() gets the M-LOOP wiring implementation
    └── result.py            # unchanged

examples/
└── quickstart.py            # minimal synthetic function demo (EX-01)

tests/
├── test_optimize.py         # existing (27 tests) + new integration tests
└── test_integration.py      # NEW: end-to-end tests with fast synthetic objectives
```

### Pattern 1: `_MLOOPInterface` — the integration core

**What:** Subclass of `mloop.interfaces.Interface` that:
1. Receives `params_dict['params']` (numpy array, indexed by param position)
2. Maps array indices → named dict using `param_names` (ordered keys from `_mloop_config['params']`)
3. Calls user's function with `**named_params`
4. Handles exceptions: log WARNING + return `{'bad': True}`
5. Converts score → cost: `cost = -score * direction_sign` (M-LOOP always minimizes)
6. Emits trial log via `rich` Console
7. Returns `{'cost': float, 'uncer': 0, 'bad': False}`

**When to use:** This is the only approach — M-LOOP requires an Interface subclass.

**Example (from M-LOOP source + CONTEXT.md confirmed API):**
```python
# Source: github.com/michaelhush/M-LOOP/blob/master/mloop/interfaces.py
import logging
import threading
import mloop.interfaces as mli
import mloop.controllers as mlc
from rich.console import Console

class _MLOOPInterface(mli.Interface):
    def __init__(self, func, param_names, direction_sign,
                 max_iterations, num_training_runs, console, shared_state, lock):
        super().__init__()  # sets up params_out_queue, costs_in_queue, end_event
        self._func = func
        self._param_names = param_names          # list[str], in declaration order
        self._direction_sign = direction_sign    # -1 or +1
        self._max_iterations = max_iterations
        self._num_training_runs = num_training_runs
        self._console = console                  # rich Console for thread-safe print
        self._shared = shared_state              # dict: {'trial': 0, 'best': None}
        self._lock = lock

    def get_next_cost_dict(self, params_dict):
        params_array = params_dict['params']     # np.ndarray, shape (n_params,)
        named_params = dict(zip(self._param_names, params_array.tolist()))

        try:
            score = float(self._func(**named_params))
            cost = -score * self._direction_sign  # M-LOOP minimizes cost
            bad = False
        except Exception:
            logging.getLogger(__name__).warning(
                "Trial raised an exception", exc_info=True
            )
            score = float('nan')
            cost = float('inf')
            bad = True

        with self._lock:
            self._shared['trial'] += 1
            trial_num = self._shared['trial']
            if not bad and (
                self._shared['best'] is None
                or score > self._shared['best_score']   # raw score (higher=better internally)
            ):
                self._shared['best_score'] = score
                self._shared['best_params'] = named_params

        label = 'TRAIN' if trial_num <= self._num_training_runs else 'OPT'
        best_score = self._shared.get('best_score')
        # Emit one scrolling log line via rich Console (thread-safe)
        self._console.print(
            f"[Trial {trial_num:>{len(str(self._max_iterations))}}"
            f"/{self._max_iterations} {label:5}] "
            f"params={named_params} score={score:.3f} "
            f"(best: {best_score:.3f})"
        )

        return {'cost': cost, 'uncer': 0, 'bad': bad}
```

### Pattern 2: Suppressing M-LOOP's logging and file side-effects

M-LOOP's `_config_logger` (called inside `Controller.__init__`) creates `./M-LOOP_logs/` and `./M-LOOP_archives/` directories and adds a StreamHandler to `logging.getLogger('mloop')`. To suppress all of this:

```python
import logging

# 1. Suppress M-LOOP console and file output BEFORE creating controller
mloop_logger = logging.getLogger('mloop')
mloop_logger.setLevel(logging.ERROR)

# 2. Pass these to create_controller to disable archive + log files:
controller = mlc.create_controller(
    interface,
    controller_type='neural_net',
    max_num_runs=max_iterations,
    num_params=len(params),
    min_boundary=[lo for lo, hi in params.values()],
    max_boundary=[hi for lo, hi in params.values()],
    num_training_runs=num_training_runs,
    visualizations=False,
    # Disable file side effects:
    controller_archive_file_type=None,  # no M-LOOP_archives/ files
    log_filename=None,                  # no M-LOOP_logs/ files
)
```

**Note:** `_config_logger` only adds handlers if `len(log.handlers) == 0`. Since we set `mloop_logger.setLevel(logging.ERROR)` before calling `create_controller`, we may still get handler registration but no output. The cleanest approach: set level first AND pass `log_filename=None` to skip file creation.

### Pattern 3: Extracting results from controller after optimize()

After `controller.optimize()` returns:

```python
# Source: controllers.py Controller class attributes
param_names = list(cfg['params'].keys())
direction_sign = cfg['direction_sign']

# best result
best_params_array = controller.best_params    # np.ndarray, shape (n_params,)
best_cost = controller.best_cost              # float (M-LOOP's minimized cost)
best_score = -best_cost * direction_sign      # reverse to user's score space

best_params_dict = dict(zip(param_names, best_params_array.tolist()))

# full history
all_params_list = [
    dict(zip(param_names, p.tolist()))
    for p in controller.out_params             # list of np.ndarray
]
all_costs_list = [
    float('nan') if bad else -cost * direction_sign   # cost → score
    for cost, bad in zip(controller.in_costs, controller.in_bads)
]

return OptimizeResult(
    best_params=best_params_dict,
    best_score=best_score,
    all_params=all_params_list,
    all_costs=all_costs_list,
)
```

### Pattern 4: `wrapper()` implementation skeleton

```python
def wrapper(*args, **kwargs) -> OptimizeResult:
    cfg = wrapper._mloop_config
    param_names = list(cfg['params'].keys())

    # 1. Suppress M-LOOP logging
    logging.getLogger('mloop').setLevel(logging.ERROR)

    # 2. Shared state for live display (accessed from interface thread)
    lock = threading.Lock()
    shared = {'trial': 0, 'best_score': None, 'best_params': None}

    # 3. Create rich Console (no redirect — avoid fighting with Live)
    console = Console()

    # 4. Build interface
    interface = _MLOOPInterface(
        func=func,
        param_names=param_names,
        direction_sign=cfg['direction_sign'],
        max_iterations=cfg['max_iterations'],
        num_training_runs=cfg.get('num_training_runs', 1),
        console=console,
        shared_state=shared,
        lock=lock,
    )

    # 5. Build controller (NeuralNetController internally)
    controller = mlc.create_controller(
        interface,
        controller_type='neural_net',
        max_num_runs=cfg['max_iterations'],
        num_params=len(param_names),
        min_boundary=[b[0] for b in cfg['params'].values()],
        max_boundary=[b[1] for b in cfg['params'].values()],
        num_training_runs=cfg.get('num_training_runs', 1),
        visualizations=False,
        controller_archive_file_type=None,
        log_filename=None,
    )

    # 6. Run (blocks until max_iterations complete)
    controller.optimize()

    # 7. Assemble OptimizeResult
    return _build_result(controller, cfg, param_names)
```

### Anti-Patterns to Avoid

- **`rich.live.Live` from the interface thread:** Live's `__enter__`/`__exit__` must be in the same thread; calling `live.update()` from the interface thread while Live's context is in wrapper() thread causes deadlocks. Use `console.print()` for scrolling output from the interface thread instead. If Live panel is desired, use `Live(get_renderable=lambda: _render_panel(shared))` with `refresh_per_second=4` so rich polls shared state rather than being pushed to.
- **Thread-unsafe shared state:** The interface thread and wrapper thread both touch trial count and best score. Always use `threading.Lock`.
- **Not setting `controller_archive_file_type=None`:** M-LOOP creates `./M-LOOP_archives/` in the CWD by default. This pollutes the user's working directory unexpectedly.
- **Not setting `log_filename=None`:** M-LOOP creates `./M-LOOP_logs/` with timestamped `.log` files. Same problem.
- **Forgetting `visualizations=False`:** M-LOOP defaults to trying to open matplotlib windows. Always pass `visualizations=False`.
- **Calling `controller.optimize()` in a separate thread:** Don't. It's already multi-threaded internally. Call it directly from `wrapper()`.

---

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Neural net surrogate | Custom MLP | M-LOOP's `NeuralNetLearner` | M-LOOP handles 5-layer net, GELU activations, StandardScaler, scipy minimize with restarts |
| Bootstrap random phase | Custom random sampler | M-LOOP's `DifferentialEvolutionLearner` (default training_type) | Built-in, battle-tested, respects boundaries |
| Parameter bounds clipping | `np.clip()` in our code | `Controller._enforce_boundaries()` | M-LOOP clips automatically with tolerance for float precision |
| Input/output normalization | Custom StandardScaler | M-LOOP's `ParameterScaler` (MinMaxScaler-based) | Already happens inside M-LOOP; external normalization would double-normalize |
| Thread-safe queue between UI and optimizer | `queue.Queue` with custom protocol | M-LOOP's existing `mp.Queue` (params_out / costs_in) | Already set up by Interface base class |

**Key insight:** M-LOOP is not just a library call — it's a complete optimization engine with threading built in. Our job is to write exactly one method (`get_next_cost_dict`) and configure the controller correctly.

---

## Common Pitfalls

### Pitfall 1: M-LOOP creates files in CWD silently
**What goes wrong:** Running any test or example creates `./M-LOOP_archives/` and `./M-LOOP_logs/` directories with timestamped files in the user's CWD.
**Why it happens:** `Controller.__init__` calls `mlu._config_logger(log_filename=default_log_filename)` which creates `./M-LOOP_logs/`. Archive creation happens in `_put_params_and_out_dict` → `save_archive()`.
**How to avoid:** Always pass `controller_archive_file_type=None` and `log_filename=None` to `create_controller`.
**Warning signs:** Unexpected directories appearing in project root or test runner CWD.

### Pitfall 2: M-LOOP logger handlers accumulate in test suites
**What goes wrong:** `_config_logger` only adds handlers if `len(log.handlers) == 0`. But if the first test creates the logger and a second test runs in the same process, the handlers are already there from the first run, causing accumulated output.
**Why it happens:** M-LOOP's logger is module-level state.
**How to avoid:** In tests, set `logging.getLogger('mloop').setLevel(logging.ERROR)` before any M-LOOP import. Alternatively, add a `conftest.py` fixture that suppresses the mloop logger for the entire session.
**Warning signs:** M-LOOP log lines appearing in test output after the first test.

### Pitfall 3: `out_params` vs `best_params` index mismatch
**What goes wrong:** `controller.out_params` has `len = max_iterations` (one per trial). `controller.in_costs` also has `len = max_iterations`. But `controller.best_params` is a numpy array (the actual best, not an index). Mapping params to names using wrong indices produces incorrect `all_params`.
**Why it happens:** `out_params` is populated by `_put_params_and_out_dict` before the cost comes back; `in_costs` is populated by `_get_cost_and_in_dict` after. They are correctly aligned (same order). Map index-by-index.
**How to avoid:** `zip(controller.out_params, controller.in_costs, controller.in_bads)` — these three lists are always the same length and aligned.

### Pitfall 4: `direction_sign` inversion is asymmetric
**What goes wrong:** M-LOOP minimizes cost. For `direction='maximize'`, `direction_sign = +1`. Cost = `-score * direction_sign = -score`. For `direction='minimize'`, `direction_sign = -1`. Cost = `-score * -1 = score`. When converting back: `score = -cost * direction_sign`.
**Why it happens:** The formula is: cost = `-score * direction_sign`. Inversion: score = `-cost / direction_sign = -cost * direction_sign` (since `direction_sign` is ±1, division = multiplication).
**How to avoid:** Always use `score = -cost * direction_sign` for the inversion. Test with both directions on a synthetic function. Store `best_cost` from M-LOOP and convert: `best_score = -controller.best_cost * direction_sign`.

### Pitfall 5: `rich.live.Live` context manager in multi-threaded code
**What goes wrong:** If `Live.__enter__` is called in `wrapper()` thread and `console.print()` is called from the interface thread, rich's internal `_lock` (a `threading.RLock`) can deadlock if the threads have inconsistent call stacks.
**Why it happens:** `Live.update()` acquires the internal lock; `console.print()` also acquires it. If Live is refreshing when `console.print` is called from another thread, they compete.
**How to avoid:** Use `console.print()` for all scrolling output from the interface thread (thread-safe in rich). For a live summary panel, use `Live(get_renderable=..., redirect_stdout=False, redirect_stderr=False)` to avoid stdout/stderr redirection conflicts.
**Warning signs:** Occasional terminal corruption, garbled output, or hangs during long optimization runs.

### Pitfall 6: `num_training_runs=1` with the default `no_delay=True`
**What goes wrong:** With `no_delay=True` (default), M-LOOP uses the training learner (differential evolution) whenever the ML learner hasn't prepared next params yet. With only 1 training run, the NN has very little data. Most post-training trials may still be differential-evolution-driven, not NN-driven, because the NN isn't ready.
**Why it happens:** `no_delay=True` means the controller never waits for the NN — it falls back to DE immediately.
**How to avoid:** This is expected behavior with `num_training_runs=1`. Document clearly that low `num_training_runs` means more DE-driven trials. For the label logic: count trials where `out_type == 'neural_net'` vs `'differential_evolution'` if accurate labeling is needed. Alternatively, keep the simpler `trial <= num_training_runs → TRAIN, else OPT` heuristic.
**Warning signs:** Users confused why trials after the training phase don't seem ML-guided.

### Pitfall 7: `visualizations=True` (the default) tries to open matplotlib windows
**What goes wrong:** M-LOOP defaults to `visualizations=True` on `NeuralNetController`, which calls matplotlib to save plots. This fails silently or loudly depending on the environment (headless CI, non-interactive shells).
**Why it happens:** M-LOOP was designed for lab experiments with display outputs.
**How to avoid:** Always pass `visualizations=False` to `create_controller`.

---

## Code Examples

Verified patterns from M-LOOP source (github.com/michaelhush/M-LOOP):

### Complete `_MLOOPInterface` subclass
```python
# Source: mloop/interfaces.py — Interface base class; mloop/controllers.py — threading model
import logging
import threading
import mloop.interfaces as mli
from rich.console import Console

class _MLOOPInterface(mli.Interface):
    """Custom M-LOOP interface that calls the user's decorated function."""

    def __init__(self, func, param_names, direction_sign,
                 max_iterations, num_training_runs, console, shared, lock):
        super().__init__()  # sets up mp.Queue params_out/costs_in, end_event
        self._func = func
        self._param_names = param_names          # list[str]
        self._direction_sign = direction_sign    # -1 (minimize) or +1 (maximize)
        self._max_iterations = max_iterations
        self._num_training_runs = num_training_runs
        self._console = console                  # rich.console.Console
        self._shared = shared                    # dict with 'trial', 'best_score', 'best_params'
        self._lock = lock                        # threading.Lock

    def get_next_cost_dict(self, params_dict):
        # params_dict['params'] is a numpy array, indexed by param position
        params_array = params_dict['params']
        named = dict(zip(self._param_names, map(float, params_array)))

        try:
            score = float(self._func(**named))
            cost = -score * self._direction_sign
            bad = False
        except Exception:
            logging.warning("Trial raised an exception", exc_info=True)
            score = float('nan')
            cost = float('nan')  # M-LOOP ignores cost when bad=True
            bad = True

        with self._lock:
            self._shared['trial'] += 1
            n = self._shared['trial']
            if not bad:
                if (self._shared['best_score'] is None
                        or cost < self._shared['best_cost_internal']):
                    self._shared['best_score'] = score
                    self._shared['best_cost_internal'] = cost
                    self._shared['best_params'] = named
            best_score = self._shared.get('best_score')

        label = 'TRAIN' if n <= self._num_training_runs else 'OPT'
        w = len(str(self._max_iterations))
        best_str = f"{best_score:.3f}" if best_score is not None else "N/A"
        score_str = f"{score:.3f}" if not bad else "FAILED"
        self._console.print(
            f"[Trial {n:{w}}/{self._max_iterations} {label:5}]"
            f" params={named}  score={score_str}  (best: {best_str})"
        )

        return {'cost': cost, 'uncer': 0, 'bad': bad}
```

### Controller creation with all side effects suppressed
```python
# Source: mloop/controllers.py — create_controller, MachineLearnerController
import mloop.controllers as mlc
import logging

def _run_mloop(func, cfg):
    param_names = list(cfg['params'].keys())

    # Suppress M-LOOP's logger before construction
    logging.getLogger('mloop').setLevel(logging.ERROR)

    interface = _MLOOPInterface(...)

    controller = mlc.create_controller(
        interface,
        controller_type='neural_net',          # uses NeuralNetController
        max_num_runs=cfg['max_iterations'],
        num_params=len(param_names),
        min_boundary=[v[0] for v in cfg['params'].values()],
        max_boundary=[v[1] for v in cfg['params'].values()],
        num_training_runs=cfg.get('num_training_runs', 1),
        visualizations=False,                  # no matplotlib
        controller_archive_file_type=None,     # no M-LOOP_archives/
        log_filename=None,                     # no M-LOOP_logs/
    )

    controller.optimize()  # blocks until max_num_runs complete
    return controller
```

### Extracting `OptimizeResult` from completed controller
```python
# Source: controllers.py Controller attributes: out_params, in_costs, in_bads, best_params, best_cost
def _build_result(controller, cfg, param_names):
    direction_sign = cfg['direction_sign']

    best_score = -controller.best_cost * direction_sign
    best_params = dict(zip(param_names, map(float, controller.best_params)))

    all_params = [
        dict(zip(param_names, map(float, p)))
        for p in controller.out_params  # list of np.ndarray, aligned with in_costs
    ]
    all_costs = [
        float('nan') if bad else -cost * direction_sign
        for cost, bad in zip(controller.in_costs, controller.in_bads)
    ]

    return OptimizeResult(
        best_params=best_params,
        best_score=best_score,
        all_params=all_params,
        all_costs=all_costs,
    )
```

### Rich Console setup for thread-safe trial logging
```python
# Source: rich 14.3.3 — Console is thread-safe for .print() calls
from rich.console import Console

# Create once in wrapper(), pass to interface
# redirect_stdout=False/redirect_stderr=False avoids conflicts with Live
console = Console(stderr=False, highlight=False)
# console.print() is thread-safe — can be called from interface thread
```

### Suppressing M-LOOP logger in pytest
```python
# tests/conftest.py
import logging
import pytest

@pytest.fixture(autouse=True, scope='session')
def suppress_mloop_logging():
    logging.getLogger('mloop').setLevel(logging.ERROR)
```

### `examples/quickstart.py` skeleton
```python
"""Quickstart example: minimize a synthetic noisy quadratic."""
import mloopforml as mloop

@mloop.optimize(
    params={"x": (-5.0, 5.0), "y": (-5.0, 5.0)},
    max_iterations=20,
    direction="minimize",
    seed=42,
)
def objective(x, y):
    """Synthetic objective: Rosenbrock-inspired with noise."""
    import random
    return (1 - x)**2 + 100 * (y - x**2)**2 + random.gauss(0, 0.01)

if __name__ == "__main__":
    result = objective()
    print(f"\nBest params: {result.best_params}")
    print(f"Best score:  {result.best_score:.4f}")
```

---

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| M-LOOP via config files (`.txt` params/cost files) | M-LOOP via Python Interface subclass | M-LOOP 2.x+ | Our approach; no filesystem polling needed |
| `rich` manual Console refresh | `rich.live.Live` with `get_renderable` callback | rich 10.0+ | Clean separation: rendering logic in lambda, shared state in dict |
| M-LOOP's `visualizations=True` default | Always pass `visualizations=False` | M-LOOP 3.x | Avoids matplotlib window popups in headless envs |

**Deprecated/outdated:**
- `mloop.interfaces.InterfaceInterrupt`: Deprecated in M-LOOP 3.x — just raise any exception from `get_next_cost_dict` and M-LOOP will halt. Don't use.
- File-based interface (writing `exp_input.txt`, reading `exp_output.txt`): The old way; Python Interface subclass is cleaner and faster.

---

## Open Questions

1. **`num_training_runs=1` + `no_delay=True` interaction**
   - What we know: With `no_delay=True`, M-LOOP falls back to DE when the NN isn't ready. With only 1 training run, the NN may rarely drive trials.
   - What's unclear: Whether tests should verify the NN actually ran (checking `out_type` in `controller.out_type`).
   - Recommendation: Don't test NN participation — test only that results are within bounds and optimization ran to completion. The `num_training_runs` parameter is user-tunable.

2. **`best_cost = float('inf')` initial value**
   - What we know: `Controller.__init__` sets `self.best_cost = float('inf')`. If ALL trials are bad (`bad=True`), `best_cost` remains `float('inf')` and `best_params` remains `float('nan')`.
   - What's unclear: Whether Phase 3 should handle all-bad-trial edge case.
   - Recommendation: For v1, propagate this as-is into `OptimizeResult(best_score=float('-inf'), best_params={})` or raise a clear RuntimeError. Either is acceptable; planner should pick one and include a test.

3. **`rich` output in CI / piped stdout**
   - What we know: `rich.Console` detects non-TTY and disables color/markup automatically. `console.print()` still outputs plain text.
   - What's unclear: Whether the scrolling log output should be suppressed when `stdout` is not a TTY.
   - Recommendation: Let rich handle it natively. Don't add custom TTY detection. Rich's behavior (plain text in non-TTY, colored in TTY) is the correct behavior.

---

## Validation Architecture

> `nyquist_validation` is `true` in `.planning/config.json` — section required.

### Test Framework
| Property | Value |
|----------|-------|
| Framework | pytest ≥8.0 |
| Config file | `pyproject.toml` `[tool.pytest.ini_options]` |
| Quick run command | `pytest tests/ -x -q --no-cov` |
| Full suite command | `pytest tests/ --cov=mloopforml --cov-report=term-missing` |

### Phase Requirements → Test Map
| Req ID | Behavior | Test Type | Automated Command | File Exists? |
|--------|----------|-----------|-------------------|-------------|
| API-06 | Calling decorated function blocks and returns OptimizeResult | integration | `pytest tests/test_integration.py::test_optimize_returns_result -x` | ❌ Wave 0 |
| OPT-01 | `num_training_runs` trials run before NN phase | integration | `pytest tests/test_integration.py::test_num_training_runs -x` | ❌ Wave 0 |
| OPT-02 | NeuralNetController is used as backend | integration | `pytest tests/test_integration.py::test_neural_net_backend -x` | ❌ Wave 0 |
| OPT-03 | All proposed params stay within bounds | integration | `pytest tests/test_integration.py::test_params_within_bounds -x` | ❌ Wave 0 |
| OPT-04 | Scipy restarts internal to M-LOOP | verified-by-use | (no direct test — covered by OPT-02; using library correctly suffices) | n/a |
| OPT-05 | Normalization never surfaces to OptimizeResult | integration | `pytest tests/test_integration.py::test_result_scores_in_user_space -x` | ❌ Wave 0 |
| OPT-06 | Exception → WARNING log + bad=True + run continues | integration | `pytest tests/test_integration.py::test_exception_handling -x` | ❌ Wave 0 |
| OBS-01 | Trial log line format correct | unit | `pytest tests/test_integration.py::test_trial_log_format -x` | ❌ Wave 0 |
| OBS-02 | Bootstrap trials labeled TRAIN, ML trials labeled OPT | unit | `pytest tests/test_integration.py::test_trial_labels -x` | ❌ Wave 0 |
| EX-01 | `examples/quickstart.py` runs to completion | smoke | `pytest tests/test_integration.py::test_quickstart_example -x` | ❌ Wave 0 |
| EX-02 | README quickstart is correct API syntax | manual | (verify by running README snippet) | n/a |

**Note on integration test speed:** M-LOOP with `num_training_runs=1` and `max_iterations=5` on a 1-2 param synthetic function (e.g., `lambda x: -(x-3)**2`) runs in ~2-5 seconds. Tests must use very small `max_iterations` to stay under 30 seconds each.

### Sampling Rate
- **Per task commit:** `pytest tests/ -x -q --no-cov`
- **Per wave merge:** `pytest tests/ --cov=mloopforml --cov-report=term-missing`
- **Phase gate:** Full suite green before `/gsd-verify-work`

### Wave 0 Gaps
- [ ] `tests/test_integration.py` — covers API-06, OPT-01, OPT-02, OPT-03, OPT-05, OPT-06, OBS-01, OBS-02, EX-01
- [ ] `tests/conftest.py` — suppress mloop logger session-wide (`autouse=True, scope='session'`)
- [ ] `examples/quickstart.py` — EX-01 runnable script
- [ ] `pyproject.toml` — add `rich>=13.0` to `[project.dependencies]`
- [ ] `optimize.py` — add `num_training_runs` param to `optimize()` factory + `_validate_num_training_runs()` + store in `_mloop_config`

*(No framework install needed — pytest already in `[dev]` extras)*

---

## Sources

### Primary (HIGH confidence)
- `https://raw.githubusercontent.com/michaelhush/M-LOOP/master/mloop/controllers.py` — Controller, MachineLearnerController, NeuralNetController, create_controller (read in full)
- `https://raw.githubusercontent.com/michaelhush/M-LOOP/master/mloop/interfaces.py` — Interface base class, threading model, get_next_cost_dict contract (read in full)
- `https://raw.githubusercontent.com/michaelhush/M-LOOP/master/mloop/utilities.py` — _config_logger, archive_foldername, log_foldername (read in full)
- `rich` 14.3.3 installed locally — Console, Live, Panel API verified via `python3 -c` tests
- `src/mloopforml/optimize.py` — existing `_mloop_config` structure, `wrapper()` stub
- `src/mloopforml/result.py` — `OptimizeResult` dataclass contract

### Secondary (MEDIUM confidence)
- `.planning/phases/03-m-loop-integration-example/03-CONTEXT.md` — locked decisions verified against M-LOOP source (all confirmed correct)
- `.planning/research/ARCHITECTURE.md` — prior research on M-LOOP threading (HIGH for source citations)

### Tertiary (LOW confidence)
- None

---

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH — M-LOOP source read directly; rich installed and tested locally
- Architecture: HIGH — Threading model verified from controllers.py and interfaces.py source
- Pitfalls: HIGH — Identified directly from M-LOOP source (archive creation, logging, visualizations default)
- Test patterns: HIGH — Based on existing test suite patterns in test_optimize.py

**Research date:** 2026-03-07
**Valid until:** 2026-06-07 (M-LOOP 3.x is stable; rich major version unlikely to change)
