---
phase: 03-m-loop-integration-example
plan: "01"
subsystem: testing
tags: [pytest, mloop, integration-tests, wave0, red-phase, rich, num_training_runs]

requires:
  - phase: 02-parameter-space-results-layer
    provides: optimize() decorator factory, OptimizeResult dataclass, validation helpers

provides:
  - "Wave 0 RED-phase test scaffold: 9 failing integration test stubs in test_integration.py"
  - "num_training_runs parameter added to optimize() with validation and _mloop_config storage"
  - "rich>=13.0 added as runtime dependency"
  - "tests/conftest.py with session-wide mloop logger suppression"
  - "examples/quickstart.py: importable Rosenbrock quickstart script"

affects:
  - 03-m-loop-integration-example
  - 03-02-PLAN (Wave 1 — implements real optimization loop targeting these tests)

tech-stack:
  added: [rich>=13.0]
  patterns:
    - "Wave 0 RED stubs: pytest.raises(NotImplementedError) wraps each integration test call"
    - "Session-scoped autouse fixture for logger suppression in conftest.py"
    - "examples/ directory with __main__ guard so optimizer doesn't run at import time"

key-files:
  created:
    - tests/test_integration.py
    - tests/conftest.py
    - examples/quickstart.py
  modified:
    - src/mloopforml/optimize.py
    - pyproject.toml
    - tests/test_optimize.py

key-decisions:
  - "Wave 0 uses pytest.raises(NotImplementedError) stubs — tests PASS in RED phase, become real assertions in Wave 1"
  - "num_training_runs=1 as default preserves backward compatibility with all existing tests"
  - "_validate_num_training_runs checks isinstance(x, bool) first (bool is subclass of int)"
  - "test_num_training_runs added as 9th test (plan listed 8 but spec included OPT-01 stub)"
  - "examples/quickstart.py uses __main__ guard so test_quickstart_example can import safely"

patterns-established:
  - "Wave 0 stub pattern: wrap NotImplementedError call in pytest.raises, add TODO Wave 1 comment"
  - "conftest.py session-scoped logger suppression: prevents M-LOOP log file creation during tests"

requirements-completed: [API-06, OPT-01, OPT-02, OPT-03, OPT-05, OPT-06, OBS-01, OBS-02, EX-01]

duration: 3 min
completed: 2026-03-07
---

# Phase 3 Plan 01: Wave 0 Test Scaffold Summary

**Wave 0 RED phase: 9 integration test stubs with pytest.raises(NotImplementedError), num_training_runs parameter validated and stored in _mloop_config, rich>=13.0 added as runtime dep**

## Performance

- **Duration:** 3 min
- **Started:** 2026-03-07T20:27:02Z
- **Completed:** 2026-03-07T20:30:50Z
- **Tasks:** 2 completed
- **Files modified:** 5 (optimize.py, pyproject.toml, test_optimize.py, test_integration.py, conftest.py) + 2 created (examples/quickstart.py already existed)

## Accomplishments

- Extended `optimize()` with `num_training_runs: int = 1` parameter and `_validate_num_training_runs()` helper that rejects bool, non-int, and values ≤ 0
- Created 9 Wave 0 integration test stubs in `tests/test_integration.py` — all pass by catching `NotImplementedError` from the current `wrapper()` stub
- Established session-wide mloop logger suppression in `tests/conftest.py` (prevents M-LOOP log file creation)
- Confirmed `examples/quickstart.py` exists and is importable without executing optimizer
- Added `rich>=13.0` to `[project.dependencies]` in `pyproject.toml`

## Task Commits

Each task was committed atomically:

1. **Task 1: Extend optimize() with num_training_runs + add rich dependency** - `aa7f4ff` (feat)
2. **Task 2: Create conftest.py + test_integration.py scaffold + examples/quickstart.py** - `f9d454d` (feat)

**Plan metadata:** (docs commit — see below)

## Files Created/Modified

- `src/mloopforml/optimize.py` — Added `_validate_num_training_runs()`, `num_training_runs` param, stored in `_mloop_config`
- `pyproject.toml` — Added `rich>=13.0` to `[project.dependencies]`
- `tests/test_optimize.py` — Updated `test_mloop_config_keys_present` to include `num_training_runs` key
- `tests/conftest.py` — Session-scoped `suppress_mloop_logging` fixture (autouse)
- `tests/test_integration.py` — 9 Wave 0 stubs using `pytest.raises(NotImplementedError)`
- `examples/quickstart.py` — Rosenbrock 2-param quickstart with `__main__` guard

## Decisions Made

- Wave 0 uses `pytest.raises(NotImplementedError)` so tests PASS in RED phase — Wave 1 removes these wrappers and adds real assertions
- `num_training_runs=1` default maintains backward compatibility with all 32 existing tests
- `isinstance(x, bool)` check must precede `isinstance(x, int)` because `bool` is a subclass of `int`
- `test_num_training_runs` added as 9th stub (OPT-01 requirement); plan listed 8 exports but this was in the spec

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Updated test_mloop_config_keys_present to include num_training_runs**
- **Found during:** Task 1 (extend optimize() with num_training_runs)
- **Issue:** Existing test asserted exact key set `{"params", "max_iterations", "direction", "direction_sign", "seed"}` — adding `num_training_runs` to `_mloop_config` would break it
- **Fix:** Added `"num_training_runs"` to the expected key set in the assertion
- **Files modified:** `tests/test_optimize.py`
- **Verification:** All 25 `test_optimize.py` tests pass after fix
- **Committed in:** `aa7f4ff` (Task 1 commit)

---

**Total deviations:** 1 auto-fixed (1 bug)
**Impact on plan:** Necessary correctness fix — the test was checking exact API shape which changed with num_training_runs addition. No scope creep.

## Issues Encountered

Both tasks were already partially executed in a prior session (commits `aa7f4ff` and `f9d454d` at 14:28/14:30). The prior session's `test_integration.py` contained Wave 0 stubs matching the plan spec. This session verified correctness, rewrote `test_integration.py` to ensure exact spec match, and confirmed all 41 tests pass.

## User Setup Required

None — no external service configuration required.

## Next Phase Readiness

- Wave 0 complete: 9 RED-phase stubs in `test_integration.py`
- `num_training_runs` in `_mloop_config` ready for Wave 1 M-LOOP wiring
- `rich>=13.0` available for terminal progress output in Wave 1
- Ready for `03-02-PLAN.md` — Wave 1: implement the real optimization loop

---
*Phase: 03-m-loop-integration-example*
*Completed: 2026-03-07*

## Self-Check: PASSED
