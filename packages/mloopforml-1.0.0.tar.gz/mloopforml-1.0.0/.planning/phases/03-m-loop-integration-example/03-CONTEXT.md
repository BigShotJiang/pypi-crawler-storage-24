# Phase 3: M-LOOP Integration & Example - Context

**Gathered:** 2026-03-07
**Status:** Ready for planning

<domain>
## Phase Boundary

Wire the `optimize()` decorator to call M-LOOP, replacing the `raise NotImplementedError` stub in `wrapper()`. Translate `_mloop_config` to M-LOOP's Python API, collect results into `OptimizeResult`, add `rich` trial logging, and ship a working example. M-LOOP handles the surrogate, training, and optimization internally — this phase wires the decorator to call it correctly.

</domain>

<decisions>
## Implementation Decisions

### M-LOOP API wiring
- Use `mloop.interfaces.Interface` subclass + `mloop.controllers.create_controller` + `controller.optimize()`
- M-LOOP passes params as a numpy array via `params_dict['params']` in `get_next_cost_dict` — map by index to param names from `_mloop_config['params']`
- Call user's function with `**named_params` (kwargs, matching param names declared in decorator)
- Convert returned score to M-LOOP cost using `direction_sign` already stored in `_mloop_config`
- Suppress M-LOOP's console logging to `ERROR` level — only our `rich` output shows

### num_training_runs parameter
- Exposed on the `@optimize` decorator as `num_training_runs`
- Defaults to `1` (not M-LOOP's default of 20)
- Maps directly to M-LOOP's `num_training_runs` config option
- Overrides OPT-01's `max(10, 2 × n_params)` default — planner should update that requirement

### Trial output (rich live display)
- `rich` is a **required runtime dependency** — added to `pyproject.toml`, always available
- Live panel pinned to bottom of terminal, always showing:
  - Best score so far
  - Best params so far
  - Trials complete `N/M`
- Scrolling log above the panel: one line per completed trial
- Trial line format: `[Trial  N/M  LABEL] params={...} score=X.XXX (best: X.XXX)`
- Label is `TRAIN` for the first `num_training_runs` trials, `OPT` for all subsequent ML-guided trials

### Failed trial handling (OPT-06)
- Claude's discretion on exact UX — requirements specify: log at WARNING, return `{'bad': True}` to M-LOOP, run continues
- Failed trials should still appear in the scrolling log with a visible failure indicator

### Example and README
- Claude's discretion — ship something minimal that works and demonstrates the decorator pattern
- README quickstart must use the correct API (`max_iterations=`, kwargs-style function signature)
- `examples/` directory should contain at least one runnable script

### Claude's Discretion
- Exact `rich` panel layout and styling
- Float precision in trial log output
- Failed trial log format
- Example content (synthetic function is fine)
- README structure beyond the quickstart snippet

</decisions>

<specifics>
## Specific Ideas

- Trial labels must be `TRAIN` and `OPT` exactly — these map to the two M-LOOP phases
- The rich live panel keeps best score and best params *always on screen* during the run
- M-LOOP's own verbose logging should be silenced so it doesn't pollute the rich display

</specifics>

<code_context>
## Existing Code Insights

### Reusable Assets
- `src/mloopforml/optimize.py` — `wrapper()` raises `NotImplementedError`; `_mloop_config` dict is fully populated with `params`, `max_iterations`, `direction`, `direction_sign`, `seed`
- `src/mloopforml/result.py` — `OptimizeResult(best_params, best_score, all_params, all_costs)` frozen dataclass, ready to receive results
- `src/mloopforml/__init__.py` — both `optimize` and `OptimizeResult` already exported

### Established Patterns
- Param validation runs at decoration time in `optimize()` — Phase 3 code goes inside `wrapper()`
- `direction_sign` is pre-computed: `-1` for minimize, `+1` for maximize. Cost to M-LOOP = `-score * direction_sign` (so M-LOOP always minimizes)
- Tests import `mloopforml as mloop` and use `@mloop.optimize(...)` pattern
- pytest uses `pythonpath = ["src"]` (no editable install)

### Integration Points
- `wrapper()` in `optimize.py` is the insertion point — replace `raise NotImplementedError` with M-LOOP controller call
- `pyproject.toml` `[project.dependencies]` needs `rich` added alongside `numpy`, `scipy`, `mloop`
- `_mloop_config` keys: `params` (dict name→(lo,hi)), `max_iterations` (int), `direction` (str), `direction_sign` (int), `seed` (int|None)

### M-LOOP API (confirmed from docs)
```python
import mloop.interfaces as mli
import mloop.controllers as mlc

class _MLOOPInterface(mli.Interface):
    def get_next_cost_dict(self, params_dict):
        params = params_dict['params']  # numpy array, indexed by position
        # map to named dict, call user func, return cost dict
        return {'cost': float, 'uncer': 0, 'bad': False}

interface = _MLOOPInterface(...)
controller = mlc.create_controller(
    interface,
    controller_type='neural_net',
    max_num_runs=max_iterations,
    num_params=len(params),
    min_boundary=[lo for lo, hi in params.values()],
    max_boundary=[hi for lo, hi in params.values()],
    num_training_runs=num_training_runs,  # user-settable, default 1
    first_params=None,
    visualizations=False,
)
controller.optimize()
# results: controller.best_params (numpy array), controller.best_cost (float)
```

</code_context>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope.

</deferred>

---

*Phase: 03-m-loop-integration-example*
*Context gathered: 2026-03-07*
