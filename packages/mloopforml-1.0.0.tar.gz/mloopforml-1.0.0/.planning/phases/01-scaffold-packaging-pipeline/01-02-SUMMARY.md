---
phase: 01-scaffold-packaging-pipeline
plan: "02"
subsystem: infra
tags: [github-actions, pypi, testpypi, oidc, trusted-publishing, ci-cd, packaging]

# Dependency graph
requires:
  - phase: 01-scaffold-packaging-pipeline
    provides: pyproject.toml with hatchling build backend, src/ layout, pytest + ruff config, local dist artifacts verified

provides:
  - GitHub Actions test workflow (ruff + pytest matrix on Python 3.11/3.12/3.13)
  - GitHub Actions publish workflow (TestPyPI on push, PyPI on v* tags, OIDC only)
  - Live repo at https://github.com/emv-dev/mloopforml with CI green on all 3 Python versions
  - Clear instructions for completing PyPI/TestPyPI Trusted Publisher registration

affects:
  - Phase 2 (library code development) — all future pushes will run CI automatically
  - Future release tags — publish-to-pypi.yml enforces version match before PyPI publish

# Tech tracking
tech-stack:
  added:
    - pypa/gh-action-pypi-publish@release/v1 (OIDC publish action)
    - actions/checkout@v6
    - actions/setup-python@v6
    - actions/upload-artifact@v5
    - actions/download-artifact@v6
  patterns:
    - OIDC Trusted Publishing (id-token: write) — zero long-lived PyPI secrets
    - Separate test and publish workflows for CI/CD separation of concerns
    - GitHub Environments (testpypi / pypi) as OIDC trust anchors
    - Tag-guard (startsWith github.ref refs/tags/) for production PyPI publish
    - tomllib version verification: git tag must match pyproject.toml before publish

key-files:
  created:
    - .github/workflows/test.yml
    - .github/workflows/publish-to-pypi.yml
  modified: []

key-decisions:
  - "Separate test.yml and publish-to-pypi.yml: clear separation of CI (always runs) vs CD (publish on condition)"
  - "OIDC Trusted Publishing only — no PYPI_API_TOKEN secret ever created or stored"
  - "TestPyPI publishes on every push to main — continuous pipeline validation, not just on tags"
  - "Tag version verification via tomllib (Python 3.11+ stdlib) — no extra deps needed"
  - "PyPI Trusted Publisher registration deferred — user must complete via pypi.org dashboard when device auth is available"

patterns-established:
  - "OIDC pattern: environment block + id-token: write permission = trustless publish, no secrets"
  - "Tag guard pattern: if startsWith(github.ref, refs/tags/) guards all production releases"
  - "Artifact handoff pattern: upload-artifact in build job, download-artifact in publish jobs"

requirements-completed: [PKG-02, PKG-03]

# Metrics
duration: ~30 min (including checkpoint wait time)
completed: 2026-03-07
---

# Phase 1 Plan 2: GitHub Actions CI/CD Pipeline Summary

**Two GitHub Actions workflows — OIDC-only publish pipeline with test matrix (3.11/3.12/3.13) and zero long-lived PyPI secrets, live and green on https://github.com/emv-dev/mloopforml**

## Performance

- **Duration:** ~30 min (including human checkpoint)
- **Started:** 2026-03-07T13:00:00Z (approx)
- **Completed:** 2026-03-07T13:53:51Z
- **Tasks:** 2 (Task 1 auto + Task 2 checkpoint)
- **Files modified:** 2 (both workflow YAML files created)

## Accomplishments

- Created `test.yml`: ruff lint + pytest matrix on Python 3.11, 3.12, 3.13 triggered on every push/PR to main
- Created `publish-to-pypi.yml`: build job → TestPyPI publish (on push) → PyPI publish (on v* tag only), all via OIDC Trusted Publishing with zero API token secrets
- Pushed to GitHub — CI ran green on all 3 Python versions
- Test workflow green confirmed by user ("actions all good")
- `publish-to-testpypi` job failed as expected (PyPI Trusted Publisher registration not yet completed — device auth issue)

## Task Commits

Each task was committed atomically:

1. **Task 1: Create GitHub Actions workflows (test.yml + publish-to-pypi.yml)** - `c6f23e0` (feat)
2. **Task 1 (follow-up): Set GitHub URLs to emv-dev/mloopforml** - `3dd2953` (chore)
3. **Task 2: Checkpoint verified (CI green, publish deferred)** — no new code commit; state captured in this summary

**Plan metadata:** (docs commit — see below)

## Files Created/Modified

- `.github/workflows/test.yml` — CI workflow: ruff check + pytest on Python 3.11/3.12/3.13, triggered on push and PR to main
- `.github/workflows/publish-to-pypi.yml` — CD workflow: build sdist+wheel, publish to TestPyPI on push, publish to PyPI on v* tags via OIDC; includes tomllib version verification step

## Decisions Made

- **OIDC-only publish:** No `PYPI_API_TOKEN` secret created or referenced anywhere. Both publish jobs use `environment:` block + `id-token: write` for Trusted Publishing.
- **Separate workflows:** `test.yml` (always runs) vs `publish-to-pypi.yml` (conditional publish) keeps CI and CD responsibilities separate and independently debuggable.
- **TestPyPI on every push:** Continuous pipeline validation rather than only on tags. Requires Trusted Publisher registration but validates the full publish path automatically.
- **Tag version guard:** `tomllib` (stdlib since Python 3.11) checks git tag == `pyproject.toml` version before uploading to PyPI — prevents version skew without extra dependencies.
- **PyPI/TestPyPI registration deferred:** User encountered device auth issue on PyPI dashboard. Registration is a one-time manual step (no CLI, no API) — documented in pending manual steps below.

## Deviations from Plan

None — plan executed exactly as written. The `publish-to-testpypi` job failing (as expected without Trusted Publisher registration) is not a deviation — it was anticipated in the checkpoint instructions.

## Issues Encountered

**PyPI/TestPyPI Trusted Publisher registration deferred (pending manual step)**

The publish-to-testpypi GitHub Actions job failed with a 403 because Trusted Publisher registration was not completed before the push. This is expected behavior — the registration must happen *before* the first workflow push.

User encountered a device authentication issue on the PyPI dashboard and could not complete registration during this session. This is a known limitation of PyPI's web-only registration flow (no API/CLI equivalent — it truly requires a human browser session).

**Resolution:** User must complete the following steps manually when device auth is resolved:

1. **TestPyPI pending publisher** — https://test.pypi.org/manage/account/publishing/
   - PyPI Project Name: `mloopforml`
   - Owner: `emv-dev`
   - Repository name: `mloopforml`
   - Workflow name: `publish-to-pypi.yml`
   - Environment name: `testpypi`

2. **PyPI pending publisher** — https://pypi.org/manage/account/publishing/
   - Same fields, but Environment name: `pypi`

3. **GitHub Environments** — https://github.com/emv-dev/mloopforml/settings/environments
   - Create `testpypi` (no required reviewers)
   - Create `pypi` (add self as required reviewer)

4. **Verify** by pushing a trivial commit to main and confirming `publish-to-testpypi` goes green in GitHub Actions.

Once registration is complete, the full pipeline (TestPyPI on push, PyPI on v* tags) will work automatically with no further configuration.

## User Setup Required

**External services require manual configuration.** PyPI/TestPyPI Trusted Publisher registration is a web-only flow with no CLI/API equivalent. See the issues section above for exact steps.

Key steps pending:
- Register pending publisher on TestPyPI (https://test.pypi.org/manage/account/publishing/)
- Register pending publisher on PyPI (https://pypi.org/manage/account/publishing/)
- Create GitHub Environments `testpypi` and `pypi` in repo settings

## Next Phase Readiness

- **CI is green:** All 3 Python versions pass ruff + pytest on every push — Phase 2 library development can proceed immediately
- **CD wired up:** Publish workflow exists and is structurally correct — once PyPI registration is completed, the first `git tag v0.1.0 && git push --tags` will publish to PyPI
- **Blocker (non-blocking for Phase 2):** PyPI Trusted Publisher registration pending — does NOT block Phase 2 library development, only blocks the first public PyPI release
- Phase 2 goal: Implement the core optimizer decorator, parameter space API, and random search baseline

---
*Phase: 01-scaffold-packaging-pipeline*
*Completed: 2026-03-07*
