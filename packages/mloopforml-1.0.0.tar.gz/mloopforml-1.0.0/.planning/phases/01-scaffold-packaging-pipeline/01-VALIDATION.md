---
phase: 1
slug: scaffold-packaging-pipeline
status: draft
nyquist_compliant: false
wave_0_complete: false
created: 2026-03-06
---

# Phase 1 — Validation Strategy

> Per-phase validation contract for feedback sampling during execution.

---

## Test Infrastructure

| Property | Value |
|----------|-------|
| **Framework** | pytest >=8.0 + pytest-cov >=7.0 |
| **Config file** | `pyproject.toml` `[tool.pytest.ini_options]` (Wave 0 installs) |
| **Quick run command** | `pytest tests/test_version.py -x` |
| **Full suite command** | `pytest` |
| **Estimated runtime** | ~5 seconds |

---

## Sampling Rate

- **After every task commit:** Run `pytest tests/test_version.py -x`
- **After every plan wave:** Run `pytest` (full suite)
- **Before `/gsd-verify-work`:** Full suite must be green + manual TestPyPI install validated
- **Max feedback latency:** ~5 seconds

---

## Per-Task Verification Map

| Task ID | Plan | Wave | Requirement | Test Type | Automated Command | File Exists | Status |
|---------|------|------|-------------|-----------|-------------------|-------------|--------|
| 1-01-01 | 01 | 1 | PKG-05, PKG-06, PKG-04 | unit | `pytest tests/test_version.py -x` | ❌ W0 | ⬜ pending |
| 1-01-02 | 01 | 1 | PKG-01, PKG-03 | smoke | `python -m build && ls dist/*.whl dist/*.tar.gz` | ❌ W0 | ⬜ pending |
| 1-02-01 | 02 | 1 | PKG-02 | manual | Inspect GitHub Actions run log for `publish-to-pypi` job | N/A | ⬜ pending |
| 1-02-02 | 02 | 2 | PKG-01, PKG-02 | smoke | `pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ mloopforml` | N/A | ⬜ pending |

*Status: ⬜ pending · ✅ green · ❌ red · ⚠️ flaky*

---

## Wave 0 Requirements

- [ ] `src/mloopforml/__init__.py` — minimal `__version__` via `importlib.metadata`
- [ ] `tests/__init__.py` — empty, makes tests a package
- [ ] `tests/test_version.py` — covers PKG-04, PKG-06 (version string and no-runtime-deps checks)
- [ ] `pyproject.toml` — full configuration with pytest, ruff, hatchling
- [ ] Framework install: `pip install -e ".[dev]"` — required before `pytest` runs

---

## Manual-Only Verifications

| Behavior | Requirement | Why Manual | Test Instructions |
|----------|-------------|------------|-------------------|
| `v*` tag triggers PyPI publish via OIDC (no API token in logs) | PKG-02 | Requires a real GitHub Actions run with a registered Trusted Publisher | Push a `v*` tag; inspect GitHub Actions run for `publish-to-pypi` job; confirm no `PYPI_API_TOKEN` in logs |
| `pip install mloopforml` on Python 3.10 fails with requires-python error | PKG-05 | Cannot automate python version constraint rejection without a real multi-python env | `python3.10 -m pip install dist/*.whl` → should exit non-zero with requires-python message |
| Package installs cleanly from TestPyPI | PKG-01 | Requires live TestPyPI artifact | `pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ mloopforml` → `python -c "import mloopforml; print(mloopforml.__version__)"` |

---

## Validation Sign-Off

- [ ] All tasks have `<automated>` verify or Wave 0 dependencies
- [ ] Sampling continuity: no 3 consecutive tasks without automated verify
- [ ] Wave 0 covers all MISSING references
- [ ] No watch-mode flags
- [ ] Feedback latency < 10s
- [ ] `nyquist_compliant: true` set in frontmatter

**Approval:** pending
