# Phase 1: Scaffold & Packaging Pipeline — Research

**Researched:** 2026-03-06
**Domain:** Python packaging — pyproject.toml, hatchling, PyPI Trusted Publishing (OIDC), GitHub Actions CI/CD
**Confidence:** HIGH — all findings verified from official PyPA docs (updated Mar 05, 2026), official PyPI docs, and official hatchling docs

---

<phase_requirements>
## Phase Requirements

| ID | Description | Research Support |
|----|-------------|-----------------|
| PKG-01 | Package installable via `pip install mloopforml` from PyPI | `pyproject.toml` [project] table with correct metadata + successful PyPI publish via GitHub Actions |
| PKG-02 | Auto-publishes to PyPI on `v*` tag via GitHub Actions (OIDC Trusted Publishing — no long-lived tokens) | `publish-to-pypi.yml` workflow with `id-token: write`, `if: startsWith(github.ref, 'refs/tags/')`, `pypa/gh-action-pypi-publish@release/v1` |
| PKG-03 | Ships both sdist and wheel | `python -m build` (produces both by default); upload everything in `dist/` |
| PKG-04 | Runtime deps are `numpy>=2.0` and `scipy>=1.15` only | `[project.dependencies]` with only those two entries; verified no torch/tensorflow |
| PKG-05 | Requires Python >=3.11 | `requires-python = ">=3.11"` in `[project]` table |
| PKG-06 | Version single-sourced in pyproject.toml, accessible via `mloopforml.__version__` | Static `version` in pyproject.toml + `importlib.metadata.version("mloopforml")` in `__init__.py` |
</phase_requirements>

---

## Summary

Phase 1 establishes the full packaging infrastructure before any library code exists. The technology stack is narrow and well-understood: `hatchling` as the build backend, `pyproject.toml` as the sole configuration file, GitHub Actions with OIDC Trusted Publishing to eliminate long-lived secrets, and `importlib.metadata` for single-sourced version access at runtime. All of these are PyPA-official patterns with first-class documentation verified as of March 2026.

The most critical decision — already locked in STATE.md — is OIDC Trusted Publishing from day one. The PyPA guide explicitly marks `PYPI_API_TOKEN` secrets as obsolete. Trusted Publishing requires pre-registering "pending publishers" on both `pypi.org` and `test.pypi.org` before the first push, mapping to the exact workflow filename and GitHub Environment name (`pypi` / `testpypi`). This is a one-time manual step that cannot be automated.

Version management is solved by keeping a static `version = "0.1.0"` in `pyproject.toml` and reading it at runtime via `importlib.metadata.version("mloopforml")`. This eliminates the three-way version skew problem (tag / pyproject / `__version__`) at the cost of one manual edit per release. The CI workflow should enforce consistency: verify `pyproject.toml` version matches the git tag name before publishing.

**Primary recommendation:** Scaffold the entire packaging pipeline in one wave — `pyproject.toml`, minimal `src/mloopforml/__init__.py`, both GitHub Actions workflows — and validate the full publish cycle to TestPyPI before writing any library code.

---

## Standard Stack

### Core

| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| hatchling | >=1.26 (current: 1.29.0) | Build backend — produces sdist + wheel from pyproject.toml | PyPA-maintained; recommended in official Python Packaging Guide; zero config for pure-Python packages; supports PEP 639 license format since 1.27.0 |
| build | >=1.2 | Frontend — `python -m build` invokes the backend, produces `dist/*.whl` and `dist/*.tar.gz` | Canonical PyPA build frontend; used in all official workflow examples |
| pypa/gh-action-pypi-publish | release/v1 | GitHub Actions → PyPI upload step with OIDC | Official PyPA action; used in PyPA's own workflow guide; handles attestations automatically since v1.11.0 |

### Supporting (dev only — never in runtime deps)

| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| pytest | >=8.0 | Test runner | All tests |
| pytest-cov | >=7.0 (current: 7.0.0) | Coverage measurement | CI and local coverage runs |
| ruff | >=0.15 (current: 0.15.5) | Linting + formatting | All code; replaces flake8 + black + isort |

### Alternatives Considered

| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| hatchling | setuptools | setuptools requires more config boilerplate; tempts `setup.py` usage; hatchling is cleaner for pure-Python |
| hatchling | flit | flit is simpler but less featureful; no dynamic versioning hooks; hatchling is the PyPA primary recommendation |
| static version in pyproject.toml | hatch-vcs (git-tag dynamic version) | hatch-vcs auto-reads version from git tags (eliminates pyproject.toml edit per release) but adds `hatch-vcs` as a build dependency and complicates the version-tag enforcement CI step; overkill for v1 |
| `importlib.metadata` at runtime | hardcoded `__version__` in `__init__.py` | Two sources of truth → version skew; `importlib.metadata` reads the installed package metadata, always consistent |
| Trusted Publishing (OIDC) | `PYPI_API_TOKEN` GitHub secret | API tokens are long-lived, can't be scoped to workflow, require manual rotation; OIDC tokens expire in 15 minutes and are auto-generated per run |

**Installation (dev environment):**
```bash
pip install -e ".[dev]"
```

---

## Architecture Patterns

### Recommended Project Structure

```
mloopforml/                      # repo root
├── src/
│   └── mloopforml/
│       └── __init__.py          # only file needed in Phase 1; exports __version__
├── tests/
│   └── test_version.py          # smoke test: __version__ matches importlib.metadata
├── .github/
│   └── workflows/
│       ├── test.yml             # runs on every push + PR; pytest + ruff
│       └── publish-to-pypi.yml  # builds dist; publishes to TestPyPI on push, PyPI on v* tag
├── pyproject.toml               # single config file for all metadata and tooling
├── README.md                    # required by PyPI for project description
└── LICENSE                      # required; MIT
```

**Why `src/` layout:** Prevents accidentally importing the local uninstalled package in tests. If you run `pytest` from the repo root without `src/`, Python finds `mloopforml/` in the working directory — not the installed editable package. The `src/` layout forces the installed (editable) version to be used. PyPA recommends it for all packages with tests. [Source: PyPA src vs flat layout discussion]

### Pattern 1: Static Version in pyproject.toml + importlib.metadata at Runtime

**What:** `version = "0.1.0"` is the single source in `pyproject.toml`. `__init__.py` reads it back at runtime via `importlib.metadata`, which reads the installed package's METADATA file.

**When to use:** Always — this is the approach that eliminates version skew.

**Example:**
```python
# src/mloopforml/__init__.py
# Source: https://packaging.python.org/en/latest/discussions/single-source-version/
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("mloopforml")
except PackageNotFoundError:
    # package is not installed (running directly from source without pip install -e .)
    __version__ = "unknown"
```

**Important:** `importlib.metadata` is in the Python 3.8+ stdlib — no extra dependency needed.

### Pattern 2: Minimal pyproject.toml (Phase 1)

**What:** The complete `pyproject.toml` for Phase 1. No library code exists yet; only the shell package.

```toml
# Source: https://packaging.python.org/en/latest/guides/writing-pyproject-toml/
# Source: https://pypi.org/project/hatchling/ (1.29.0, Feb 23 2026)

[build-system]
requires = ["hatchling>=1.26"]
build-backend = "hatchling.build"

[project]
name = "mloopforml"
version = "0.1.0"
description = "Neural network surrogate hyperparameter optimization via a simple decorator"
readme = "README.md"
license = "MIT"
license-files = ["LICENSE*"]
requires-python = ">=3.11"
dependencies = [
    "numpy>=2.0",
    "scipy>=1.15",
]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Science/Research",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "License :: OSI Approved :: MIT License",
    "Topic :: Scientific/Engineering :: Artificial Intelligence",
]
keywords = ["hyperparameter", "optimization", "machine learning", "neural network", "bayesian"]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-cov>=7.0",
    "ruff>=0.15",
    "build>=1.2",
]

[project.urls]
Homepage = "https://github.com/{owner}/mloopforml"
Repository = "https://github.com/{owner}/mloopforml"
Issues = "https://github.com/{owner}/mloopforml/issues"

[tool.hatch.build.targets.wheel]
packages = ["src/mloopforml"]

[tool.ruff]
target-version = "py311"
line-length = 88

[tool.ruff.lint]
select = ["E", "F", "I", "UP"]

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = "--cov=mloopforml --cov-report=term-missing"
```

**Note on PEP 639 license format:** `license = "MIT"` (SPDX expression) + `license-files = ["LICENSE*"]` is the new PEP 639 format. Hatchling >=1.27.0 supports it. The old format `license = {text = "MIT"}` is deprecated. Verified: hatchling 1.29.0 (released Feb 23 2026) supports PEP 639.

### Pattern 3: GitHub Actions Workflow — Test on Push

```yaml
# .github/workflows/test.yml
# Source: https://packaging.python.org/en/latest/guides/publishing-package-distribution-releases-using-github-actions-ci-cd-workflows/
name: Test

on:
  push:
    branches: ["main"]
  pull_request:
    branches: ["main"]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.11", "3.12", "3.13"]
    steps:
      - uses: actions/checkout@v6
        with:
          persist-credentials: false
      - uses: actions/setup-python@v6
        with:
          python-version: ${{ matrix.python-version }}
      - name: Install dev dependencies
        run: pip install -e ".[dev]"
      - name: Lint with ruff
        run: ruff check .
      - name: Run tests
        run: pytest
```

### Pattern 4: GitHub Actions Workflow — Build + Publish via OIDC Trusted Publishing

```yaml
# .github/workflows/publish-to-pypi.yml
# Source: https://packaging.python.org/en/latest/guides/publishing-package-distribution-releases-using-github-actions-ci-cd-workflows/
# VERIFIED against official PyPA guide (Mar 05, 2026)
name: Publish to PyPI and TestPyPI

on: push

jobs:
  build:
    name: Build distribution
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v6
        with:
          persist-credentials: false
      - uses: actions/setup-python@v6
        with:
          python-version: "3.x"
      - name: Install build frontend
        run: pip install build --user
      - name: Build sdist and wheel
        run: python -m build
      - name: Store distribution packages
        uses: actions/upload-artifact@v5
        with:
          name: python-package-distributions
          path: dist/

  publish-to-testpypi:
    name: Publish to TestPyPI
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: testpypi
      url: https://test.pypi.org/p/mloopforml
    permissions:
      id-token: write  # REQUIRED for Trusted Publishing
    steps:
      - uses: actions/download-artifact@v6
        with:
          name: python-package-distributions
          path: dist/
      - uses: pypa/gh-action-pypi-publish@release/v1
        with:
          repository-url: https://test.pypi.org/legacy/

  publish-to-pypi:
    name: Publish to PyPI
    if: startsWith(github.ref, 'refs/tags/')  # Only on v* tags
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: pypi
      url: https://pypi.org/p/mloopforml
    permissions:
      id-token: write  # REQUIRED for Trusted Publishing
    steps:
      - uses: actions/download-artifact@v6
        with:
          name: python-package-distributions
          path: dist/
      - uses: pypa/gh-action-pypi-publish@release/v1
```

**Key design decisions:**
- `publish-to-testpypi` runs on every push (no tag filter) — validates pipeline health continuously
- `publish-to-pypi` only runs on `refs/tags/` — guards against accidental production publishes
- Both jobs use `environment:` — this is required for OIDC trust; environment names must exactly match what was registered on pypi.org
- Neither job stores any secret — OIDC tokens are minted per-run and expire after ~15 minutes
- `persist-credentials: false` on checkout — security best practice (prevents token leakage)

### Pattern 5: Version Tag Enforcement in CI

Add this step to `publish-to-pypi` job before the publish step to prevent tag/version skew:

```yaml
      - uses: actions/checkout@v6
        with:
          persist-credentials: false
      - name: Verify tag matches pyproject.toml version
        run: |
          TAG_VERSION="${GITHUB_REF_NAME#v}"   # strip leading 'v' from tag
          TOML_VERSION=$(python -c "
          import tomllib
          with open('pyproject.toml', 'rb') as f:
              data = tomllib.load(f)
          print(data['project']['version'])
          ")
          if [ "$TAG_VERSION" != "$TOML_VERSION" ]; then
            echo "ERROR: git tag $GITHUB_REF_NAME != pyproject.toml version $TOML_VERSION"
            exit 1
          fi
          echo "Version verified: $TOML_VERSION"
```

**Note:** `tomllib` is in stdlib since Python 3.11 — no extra deps needed.

### Anti-Patterns to Avoid

- **`setup.py` or `setup.cfg`:** Legacy formats. `pyproject.toml` only — PyPA deprecated setup.py as build interface.
- **`PYPI_API_TOKEN` in GitHub secrets:** Long-lived credential. PyPA guide explicitly marks it "obsolete." Use OIDC.
- **Exact version pins in `[project.dependencies]`:** `numpy==2.4.2` breaks installs on environments with different numpy. Use `numpy>=2.0`.
- **Cherry-picking `dist/` for upload:** `twine upload dist/*.tar.gz` skips the wheel. Always upload everything in `dist/`.
- **`on: release: types: [published]` trigger for PyPI:** Creates a race condition if the GitHub Release is created before the wheel is built. Use `on: push` + `if: startsWith(github.ref, 'refs/tags/')` instead.
- **Skipping `testpypi` GitHub Environment registration:** Without the environment registered on test.pypi.org, the OIDC token will be rejected with a 403.

---

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Producing sdist + wheel | Custom build scripts | `python -m build` | Handles backend protocol, MANIFEST.in equivalents, wheel metadata correctly |
| Uploading to PyPI | `curl` / `requests` to upload API | `pypa/gh-action-pypi-publish@release/v1` | Handles OIDC token exchange, retry logic, attestation upload, API versioning |
| Version at runtime | Read `pyproject.toml` at runtime | `importlib.metadata.version()` | pyproject.toml may not be installed; importlib reads the package's installed METADATA which is always present |
| Tagging releases | Custom version bump scripts | `git tag v0.1.0 && git push --tags` | Simple manual process; automation adds complexity; use `hatch version` CLI if desired |

**Key insight:** The PyPI publishing ecosystem is mature and opinionated. The `build` + `pypa/gh-action-pypi-publish` combination handles edge cases (wheel tags, METADATA format, attestations, retry on transient 5xx) that are non-trivial to replicate correctly.

---

## Common Pitfalls

### Pitfall 1: TestPyPI Environment Not Registered Before First Push

**What goes wrong:** The first push triggers the `publish-to-testpypi` job. GitHub sends the OIDC token to TestPyPI, but there's no matching "pending publisher" configured on test.pypi.org. The job fails with HTTP 403. Because this is the first publish, the project doesn't exist on TestPyPI yet, so you must use the "pending publisher" flow.

**Why it happens:** Developers set up the workflow first, then forget to configure the publisher on test.pypi.org before pushing.

**How to avoid:** Register pending publishers on BOTH test.pypi.org AND pypi.org BEFORE the first commit with the workflow file. Order of operations:
1. Create accounts on both pypi.org and test.pypi.org (separate accounts)
2. Go to `https://test.pypi.org/manage/account/publishing/` → add pending publisher
3. Go to `https://pypi.org/manage/account/publishing/` → add pending publisher
4. Set up the GitHub Environments (`testpypi` and `pypi`) in repo settings
5. Only then push the workflow YAML

**Warning signs:** Publish job fails with 403 on first run; no environment configured in GitHub repo settings.

---

### Pitfall 2: TestPyPI Install Fails Because numpy/scipy Aren't on TestPyPI

**What goes wrong:** Validating the TestPyPI publish with `pip install --index-url https://test.pypi.org/simple/ mloopforml` fails because `numpy` and `scipy` aren't mirrored on TestPyPI. pip can't find the dependencies.

**Why it happens:** TestPyPI is a separate index with a fraction of PyPI's packages. Runtime dependencies like numpy are on PyPI but not TestPyPI.

**How to avoid:** Always use `--extra-index-url https://pypi.org/simple/` when installing from TestPyPI:
```bash
pip install \
  --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/ \
  mloopforml
```

**Warning signs:** `pip install` from TestPyPI exits with "Could not find a version that satisfies the requirement numpy".

---

### Pitfall 3: Every Push to TestPyPI Hits PyPI Project Size Limit

**What goes wrong:** The `publish-to-testpypi` job runs on every push. After 50–100 pushes, the TestPyPI project accumulates many versions and approaches the 10GB project size limit. TestPyPI starts rejecting uploads.

**Why it happens:** PyPI docs warn: "If your repository has frequent commit activity and every push is uploaded to TestPyPI, the project might exceed the PyPI project size limit." The official guide acknowledges this tradeoff.

**How to avoid:** For active development, restrict TestPyPI to pushes on main only (not feature branches):
```yaml
on:
  push:
    branches: ["main"]
  pull_request:
    branches: ["main"]
```
Or add a version suffix based on commit SHA so versions don't collide. For a new library with infrequent pushes, the default "every push" is fine.

---

### Pitfall 4: `importlib.metadata.version()` Raises PackageNotFoundError in Development

**What goes wrong:** Developer clones the repo and runs `python -c "import mloopforml; print(mloopforml.__version__)"` without installing. `importlib.metadata.version("mloopforml")` raises `PackageNotFoundError` because the package metadata doesn't exist until `pip install -e .` is run.

**Why it happens:** `importlib.metadata` reads from installed package METADATA files, not from source `pyproject.toml`. If the package isn't installed, there's no METADATA.

**How to avoid:** Wrap in try/except in `__init__.py`:
```python
try:
    __version__ = version("mloopforml")
except PackageNotFoundError:
    __version__ = "unknown"
```
And document in README: always install with `pip install -e ".[dev]"` before developing.

---

### Pitfall 5: GitHub Environment Manual Approval Required for Production PyPI

**What goes wrong:** Developer pushes a `v0.1.0` tag. The `publish-to-pypi` job queues but never runs. GitHub shows "Waiting for review" indefinitely. The publish is stuck.

**Why it happens:** PyPI's documentation for Trusted Publishing **requires** manual approval on each run for the `pypi` environment (not testpypi). This is a security requirement. Developers don't realize they need to configure reviewers in the GitHub Environment settings and approve each production publish.

**How to avoid:** In GitHub repo settings → Environments → `pypi` → configure "Required reviewers" with at least one reviewer. When a `v*` tag is pushed, the job will pause and send an email to configured reviewers for a one-click approval.

---

### Pitfall 6: Missing `[tool.hatch.build.targets.wheel]` packages Declaration

**What goes wrong:** `python -m build` produces a wheel, but the wheel is empty or contains everything in the repo root instead of just `src/mloopforml/`. Installing from the wheel does not make `import mloopforml` work.

**Why it happens:** Hatchling's auto-discovery for `src/` layout requires either placing packages at the root level or explicitly declaring the source packages path.

**How to avoid:** Always include:
```toml
[tool.hatch.build.targets.wheel]
packages = ["src/mloopforml"]
```
Verify after build: `unzip -l dist/*.whl | grep mloopforml` — should show `mloopforml/__init__.py` not `src/mloopforml/__init__.py`.

---

## Code Examples

### Minimal `__init__.py` for Phase 1

```python
# src/mloopforml/__init__.py
# Source: https://packaging.python.org/en/latest/discussions/single-source-version/
"""mloopforml — neural network surrogate hyperparameter optimization."""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("mloopforml")
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = ["__version__"]
```

### Version Smoke Test

```python
# tests/test_version.py
import importlib.metadata
import mloopforml


def test_version_is_string():
    """__version__ must be a non-empty string."""
    assert isinstance(mloopforml.__version__, str)
    assert mloopforml.__version__ != ""
    assert mloopforml.__version__ != "unknown"


def test_version_matches_metadata():
    """__version__ must match importlib.metadata — no skew allowed."""
    assert mloopforml.__version__ == importlib.metadata.version("mloopforml")


def test_no_runtime_deps_beyond_numpy_scipy():
    """Verify only numpy and scipy are imported at package import time."""
    import sys
    # After importing mloopforml, neither torch nor tensorflow should be loaded
    assert "torch" not in sys.modules
    assert "tensorflow" not in sys.modules
    assert "sklearn" not in sys.modules
```

### Verify Built Distribution Contains Both Artifacts

```bash
# Run after python -m build, before publishing
ls dist/
# Expected:
#   mloopforml-0.1.0-py3-none-any.whl
#   mloopforml-0.1.0.tar.gz

# Verify wheel contents
unzip -l dist/mloopforml-0.1.0-py3-none-any.whl
# Must contain mloopforml/__init__.py (NOT src/mloopforml/__init__.py)

# Verify install from wheel on clean env
pip install dist/mloopforml-0.1.0-py3-none-any.whl
python -c "import mloopforml; print(mloopforml.__version__)"
# Expected: 0.1.0
```

---

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| `PYPI_API_TOKEN` GitHub secret | OIDC Trusted Publishing | 2023 (PyPI) | API tokens explicitly marked "obsolete" in PyPA guide; no secrets to manage |
| `setup.py` / `setup.cfg` | `pyproject.toml` only | 2022 (PEP 621) | setup.py as build interface is deprecated; `setup.py` is still valid for config but no longer recommended |
| `license = {text = "MIT"}` in pyproject.toml | `license = "MIT"` (SPDX) + `license-files` | PEP 639, hatchling 1.27.0 (2024) | Old format deprecated; hatchling 1.29.0 (current) warns on old format |
| `pypa/gh-action-pypi-publish` with API token | Same action, OIDC mode + automatic PEP 740 attestations | v1.11.0 (2024) | Attestations uploaded automatically; verifiable provenance for all packages |
| `actions/checkout@v4`, `setup-python@v5` | `actions/checkout@v6`, `actions/setup-python@v6` | 2025 | Updated major versions; v6 is what the official PyPA guide now recommends |

**Deprecated/outdated:**
- `twine`: Still works but replaced by `pypa/gh-action-pypi-publish` for CI; use for manual emergency uploads only
- `setup.py sdist bdist_wheel`: Replaced by `python -m build`; never produces both correctly in one command
- `PYPI_API_TOKEN` GitHub Secrets: PyPA guide explicitly says "remove them and revoke them"

---

## Open Questions

1. **GitHub repository name / owner for `[project.urls]`**
   - What we know: The URLs in pyproject.toml should point to the actual GitHub repo
   - What's unclear: The GitHub repo may not exist yet at Phase 1 start
   - Recommendation: Use placeholder `{owner}/mloopforml`, fill in when repo is created; URLs are metadata only and don't affect install

2. **TestPyPI publish on every push vs. only on main**
   - What we know: Official guide says "every push"; PyPI docs warn about project size limits with frequent activity
   - What's unclear: How frequently will this repo receive commits during development?
   - Recommendation: Restrict TestPyPI to `main` branch pushes only (not feature branches / PRs) to avoid size limit issues

3. **Python version matrix for CI**
   - What we know: `requires-python = ">=3.11"`; numpy 2.x supports 3.11, 3.12, 3.13
   - What's unclear: Whether to test 3.13 (latest stable) or just 3.11 + 3.12 in the matrix
   - Recommendation: Test 3.11, 3.12, 3.13 — all are actively supported; 3.13 is stable as of Oct 2024

---

## Validation Architecture

### Test Framework

| Property | Value |
|----------|-------|
| Framework | pytest >=8.0 + pytest-cov >=7.0 |
| Config file | `pyproject.toml` `[tool.pytest.ini_options]` (Wave 0 creates this) |
| Quick run command | `pytest tests/test_version.py -x` |
| Full suite command | `pytest` |

### Phase Requirements → Test Map

| Req ID | Behavior | Test Type | Automated Command | File Exists? |
|--------|----------|-----------|-------------------|-------------|
| PKG-01 | Package installs from built wheel without error | smoke | `pip install dist/*.whl && python -c "import mloopforml"` | ❌ Wave 0 |
| PKG-02 | `v*` tag triggers publish workflow; OIDC produces no API token in logs | manual-only | Inspect GitHub Actions run log for `publish-to-pypi` job | N/A — CI validation |
| PKG-03 | `python -m build` produces both `.whl` and `.tar.gz` | smoke | `ls dist/*.whl dist/*.tar.gz` (exit 0 = both present) | ❌ Wave 0 |
| PKG-04 | Importing mloopforml does not load torch/tensorflow/sklearn | unit | `pytest tests/test_version.py::test_no_runtime_deps_beyond_numpy_scipy -x` | ❌ Wave 0 |
| PKG-05 | `pip install mloopforml` on Python 3.10 fails with requires-python error | smoke | `python3.10 -m pip install dist/*.whl` → should exit non-zero | manual-only |
| PKG-06 | `mloopforml.__version__` equals `importlib.metadata.version("mloopforml")` | unit | `pytest tests/test_version.py::test_version_matches_metadata -x` | ❌ Wave 0 |

### Sampling Rate

- **Per task commit:** `pytest tests/test_version.py -x`
- **Per wave merge:** `pytest` (full suite)
- **Phase gate:** Full suite green + manual TestPyPI install validated before marking Phase 1 complete

### Wave 0 Gaps

- [ ] `tests/test_version.py` — covers PKG-04, PKG-06 (version string and no-runtime-deps checks)
- [ ] `tests/__init__.py` — empty, makes tests a package
- [ ] `src/mloopforml/__init__.py` — minimal, with `__version__` via `importlib.metadata`
- [ ] `pyproject.toml` — full configuration as specified above
- [ ] Framework install: `pip install -e ".[dev]"` — if not already installed

*(PKG-01, PKG-03 are validated by CI build steps; PKG-02, PKG-05 are manual-only — no automated test can fully simulate a tag-triggered publish or a requires-python rejection without a real environment.)*

---

## Sources

### Primary (HIGH confidence)
- `https://packaging.python.org/en/latest/guides/publishing-package-distribution-releases-using-github-actions-ci-cd-workflows/` — Complete GitHub Actions + Trusted Publishing workflow; verified Mar 05, 2026 (last updated Mar 05, 2026)
- `https://docs.pypi.org/trusted-publishers/adding-a-publisher/` — Trusted Publisher configuration steps; official PyPI docs
- `https://packaging.python.org/en/latest/discussions/single-source-version/` — Single-sourcing version; last reviewed Oct 2024, updated Mar 05, 2026
- `https://packaging.python.org/en/latest/guides/writing-pyproject-toml/` — pyproject.toml authoring guide; updated Mar 05, 2026
- `https://hatch.pypa.io/latest/version/` — Hatchling versioning documentation (official)
- `.planning/research/STACK.md` — Stack versions verified from PyPI (hatchling 1.29.0, numpy 2.4.2, scipy 1.17.1, ruff 0.15.5, pytest-cov 7.0.0); verified Mar 06, 2026
- `.planning/research/PITFALLS.md` — PyPI packaging pitfalls; sources verified Mar 2026

### Secondary (MEDIUM confidence)
- `.planning/research/ARCHITECTURE.md` — CI/CD workflow patterns; cross-verified with official PyPA guide

### Tertiary (LOW confidence — none in this research)

*(All findings for Phase 1 scope are directly supported by official PyPA or PyPI documentation.)*

---

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH — hatchling, build, gh-action-pypi-publish all from official PyPA docs; versions from PyPI (Mar 2026)
- Architecture patterns: HIGH — workflow YAML taken directly from PyPA guide (Mar 05, 2026); pyproject.toml skeleton from official authoring guide
- Pitfalls: HIGH — all pitfalls sourced from official PyPI docs or PyPA guide; tested patterns cross-referenced

**Research date:** 2026-03-06
**Valid until:** 2026-04-06 (stable ecosystem; PyPI packaging standards change slowly; re-verify action major versions before use if >30 days old)
