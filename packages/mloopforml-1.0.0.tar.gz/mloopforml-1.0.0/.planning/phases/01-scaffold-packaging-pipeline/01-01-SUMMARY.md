---
phase: 01-scaffold-packaging-pipeline
plan: "01"
subsystem: infra
tags: [python, packaging, hatchling, pyproject, pytest, importlib-metadata]

# Dependency graph
requires: []
provides:
  - Installable Python package with src layout (pip install -e ".[dev]")
  - pyproject.toml with hatchling build backend and complete metadata
  - __version__ via importlib.metadata (single source of truth)
  - Automated test suite for PKG-04 and PKG-06
  - Both dist artifacts: .whl and .tar.gz
affects: [02-ci-cd, 03-optimizer-core, 04-decorator-api]

# Tech tracking
tech-stack:
  added: [hatchling>=1.26, pytest>=8.0, pytest-cov>=7.0, ruff>=0.15, build>=1.2]
  patterns:
    - "src/ layout: package lives in src/mloopforml/, hatch strips src/ prefix in wheel"
    - "importlib.metadata.version() for single-sourced version, fallback to 'unknown'"
    - "dev extras in pyproject.toml for test/lint/build tooling"

key-files:
  created:
    - pyproject.toml
    - src/mloopforml/__init__.py
    - tests/__init__.py
    - tests/test_version.py
    - README.md
    - LICENSE
  modified: []

key-decisions:
  - "hatchling chosen as build backend (modern, fast, src-layout native)"
  - "requires-python = '>=3.11' enforced per numpy 2.x requirements"
  - "Runtime deps locked to numpy>=2.0 and scipy>=1.15 only — no ML framework transitive deps"
  - "importlib.metadata for version (PEP 566 compliant, no duplication)"

patterns-established:
  - "src/ layout: all package code lives under src/mloopforml/"
  - "Version single-sourced: pyproject.toml version field → importlib.metadata → __version__"
  - "Test smoke tests live in tests/test_version.py following PKG requirement IDs as docstrings"

requirements-completed: [PKG-01, PKG-03, PKG-04, PKG-05, PKG-06]

# Metrics
duration: 2min
completed: 2026-03-07
---

# Phase 1 Plan 01: Package Scaffold Summary

**Installable mloopforml package with hatchling src-layout, importlib.metadata version, and pytest test suite producing both .whl and .tar.gz artifacts**

## Performance

- **Duration:** 2 min
- **Started:** 2026-03-07T13:18:32Z
- **Completed:** 2026-03-07T13:20:43Z
- **Tasks:** 2
- **Files modified:** 6

## Accomplishments
- Complete pyproject.toml with hatchling build backend, requires-python>=3.11, numpy+scipy runtime only
- src/mloopforml/__init__.py with importlib.metadata version (single source of truth)
- 3-test pytest suite covering: version string, metadata match (PKG-06), no ML runtime deps (PKG-04)
- Both dist artifacts built and verified: `.whl` with correct `mloopforml/__init__.py` internal path (no `src/` prefix), `.tar.gz`

## Task Commits

Each task was committed atomically:

1. **Task 1: Create package scaffold** - `f5d0494` (feat)
2. **Task 2: Write version test suite and validate build artifacts** - `1eb7528` (feat)

**Plan metadata:** `(pending)` (docs: complete plan)

## Files Created/Modified
- `pyproject.toml` - Package metadata, hatchling build config, dev deps, ruff+pytest tool config
- `src/mloopforml/__init__.py` - Package entry point: `__version__` via importlib.metadata
- `tests/__init__.py` - Empty init making tests a package for pytest import resolution
- `tests/test_version.py` - Smoke tests for PKG-04 (no ML deps) and PKG-06 (version single-sourced)
- `README.md` - Minimal project description required by PyPI
- `LICENSE` - MIT license 2026 mloopforml contributors

## Decisions Made
- **hatchling** as build backend: modern, actively maintained, native src-layout support
- **requires-python = ">=3.11"**: enforced per numpy 2.x and scipy 1.15 minimum requirements
- **importlib.metadata** for version: PEP 566 compliant, eliminates duplication between pyproject.toml and code
- Runtime deps: `numpy>=2.0` and `scipy>=1.15` only — all ML frameworks excluded

## Deviations from Plan

None - plan executed exactly as written.

## Issues Encountered
None.

## User Setup Required
None - no external service configuration required.

## Next Phase Readiness
- Package scaffold complete: `pip install -e ".[dev]"` works, all 3 tests pass
- Both distribution artifacts verified: wheel internal structure correct (no src/ prefix)
- Ready for Plan 02: GitHub Actions CI/CD pipeline setup

## Self-Check: PASSED

- FOUND: pyproject.toml
- FOUND: src/mloopforml/__init__.py
- FOUND: tests/__init__.py
- FOUND: tests/test_version.py
- FOUND: README.md
- FOUND: LICENSE
- FOUND commit f5d0494 (feat(01-01): create package scaffold)
- FOUND commit 1eb7528 (feat(01-01): add version test suite)

---
*Phase: 01-scaffold-packaging-pipeline*
*Completed: 2026-03-07*
