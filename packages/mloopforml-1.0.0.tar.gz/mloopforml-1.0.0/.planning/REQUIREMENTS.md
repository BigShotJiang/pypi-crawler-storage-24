# Requirements: mloopforml

**Defined:** 2026-03-06
**Core Value:** A researcher can `pip install mloopforml`, write a decorator with parameter ranges, and have a working hyperparameter optimization loop running in under 5 minutes — without learning a framework.

## v1 Requirements

### Packaging

- [x] **PKG-01**: Package is installable via `pip install mloopforml` from PyPI
- [x] **PKG-02**: Package publishes to PyPI automatically on version tag via GitHub Actions (Trusted Publishing / OIDC — no long-lived API tokens)
- [x] **PKG-03**: Package ships both sdist and wheel so users on restricted systems don't need a compiler
- [x] **PKG-04**: Runtime dependencies are numpy>=2.0, scipy>=1.15, and M-LOOP>=3.0 only — no ML framework (PyTorch, TensorFlow, scikit-learn) required at runtime
- [x] **PKG-05**: Package requires Python >=3.11 and declares this in pyproject.toml
- [x] **PKG-06**: Version is single-sourced in pyproject.toml and accessible at runtime via `mloopforml.__version__`

### API

- [x] **API-01**: User can decorate a wrapper function with `@mloop.optimize(params={"lr": (0.001, 0.1)})` to define an optimization target
- [x] **API-02**: User can specify continuous hyperparameter ranges as `(min, max)` float tuples
- [x] **API-03**: User can set `max_iterations` on the decorator to control total trial count
- [x] **API-04**: User can set `direction="minimize"` or `direction="maximize"` to control optimization direction
- [x] **API-05**: User can set `seed` for reproducible runs
- [x] **API-06**: Calling the decorated function triggers the optimization loop and blocks until complete
- [x] **API-07**: Importing the module does not trigger any optimization logic
- [x] **API-08**: Invalid parameter bounds (min >= max, non-numeric) raise a clear `ValueError` at decoration time, not at iteration time

### Optimizer

_Note: OPT-01 through OPT-06 are satisfied by M-LOOP internally. Phase 3 wires M-LOOP correctly — it does not re-implement these behaviors._

- [x] **OPT-01**: Bootstrap phase of `max(10, 2 * n_params)` random trials runs before the surrogate activates — provided by M-LOOP's `MachineLearnerController`
- [x] **OPT-02**: Neural net surrogate (MLP) proposes candidates via scipy — provided by M-LOOP; we call it, not build it
- [x] **OPT-03**: All proposed parameter values stay within declared bounds — M-LOOP clips; Phase 3 verifies via integration tests
- [x] **OPT-04**: Multiple random restarts in scipy minimize — M-LOOP handles internally; verified by using the library correctly
- [x] **OPT-05**: Input/output normalization is internal to M-LOOP — normalized values never appear in `OptimizeResult`
- [x] **OPT-06**: If the objective raises, log at WARNING with full traceback, mark trial bad (`bad=True` to M-LOOP), continue

### Results

- [x] **RES-01**: Decorated function returns an `OptimizeResult` object with `best_params` (dict) and `best_score` (float)
- [x] **RES-02**: `OptimizeResult` also exposes `all_params` (list of dicts) and `all_costs` (list of floats) for full history access

### Observability

- [x] **OBS-01**: Each completed trial is logged to stdout in format: `[Trial N/M] params={...} score=X.XXX (best: X.XXX)`
- [x] **OBS-02**: Bootstrap phase is clearly identified in logs so users understand why early trials appear random

### Example

- [x] **EX-01**: Repository includes a working example (`examples/sklearn_iris.py` or similar) demonstrating the decorator pattern on a real ML use case
- [x] **EX-02**: README includes a minimal install-and-run example a user can copy-paste and execute in under 5 minutes

## v2 Requirements

### Parameter Types

- **PARAM-01**: User can specify integer (discrete) parameter ranges
- **PARAM-02**: User can specify categorical parameters (string choices)
- **PARAM-03**: User can specify log-scale continuous ranges for parameters spanning orders of magnitude (e.g., learning rate)

### Execution

- **EXEC-01**: User can run multiple trials in parallel (parallel objective evaluation)
- **EXEC-02**: User can supply a per-trial callback function invoked after each trial completes

### Observability

- **OBS-03**: User can access convergence plot showing score vs. trial number
- **OBS-04**: User can export full run history to CSV

### Integrations

- **INT-01**: User can log trials to Weights & Biases via callback
- **INT-02**: User can log trials to MLflow via callback

## Out of Scope

| Feature | Reason |
|---------|--------|
| Pruning / early stopping | Requires objective to report intermediate values — breaks the "return a float" API contract |
| Dashboard or web UI | Separate product; stdout logging is sufficient for v1 |
| CLI interface | Not core to decorator-based API; users run Python scripts |
| Distributed execution | Ray Tune exists for this; out of mloopforml's scope |
| Categorical / integer params | Requires surrogate architecture changes; defer to v2 |
| PyTorch / TensorFlow as runtime dep | Would collapse adoption on ML clusters; numpy-only is non-negotiable |
| Auto-convergence / early stop | User controls iteration count; predictable runtime is more valuable for v1 |

## Traceability

Which phases cover which requirements. Updated during roadmap creation.

| Requirement | Phase | Status |
|-------------|-------|--------|
| PKG-01 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| PKG-02 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| PKG-03 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| PKG-04 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| PKG-05 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| PKG-06 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| API-01 | Phase 2: Parameter Space & Results Layer | Complete |
| API-02 | Phase 2: Parameter Space & Results Layer | Complete |
| API-03 | Phase 2: Parameter Space & Results Layer | Complete |
| API-04 | Phase 2: Parameter Space & Results Layer | Complete |
| API-05 | Phase 2: Parameter Space & Results Layer | Complete |
| API-07 | Phase 2: Parameter Space & Results Layer | Complete |
| API-08 | Phase 2: Parameter Space & Results Layer | Complete |
| RES-01 | Phase 2: Parameter Space & Results Layer | Complete |
| RES-02 | Phase 2: Parameter Space & Results Layer | Complete |
| OPT-01 | Phase 3: M-LOOP Integration & Example | Complete |
| OPT-02 | Phase 3: M-LOOP Integration & Example | Complete |
| OPT-03 | Phase 3: M-LOOP Integration & Example | Complete |
| OPT-04 | Phase 3: M-LOOP Integration & Example | Complete |
| OPT-05 | Phase 3: M-LOOP Integration & Example | Complete |
| OPT-06 | Phase 3: M-LOOP Integration & Example | Complete |
| API-06 | Phase 3: M-LOOP Integration & Example | Complete |
| OBS-01 | Phase 3: M-LOOP Integration & Example | Complete |
| OBS-02 | Phase 3: M-LOOP Integration & Example | Complete |
| EX-01 | Phase 3: M-LOOP Integration & Example | Complete |
| EX-02 | Phase 3: M-LOOP Integration & Example | Complete |

**Coverage:**
- v1 requirements: 26 total
- Mapped to phases: 26
- Unmapped: 0 ✓

---
*Requirements defined: 2026-03-06*
*Last updated: 2026-03-06 after initial definition*
