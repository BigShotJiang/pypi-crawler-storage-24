"""Quickstart: minimize a synthetic noisy function with mloopforml.

Usage
-----
    python examples/quickstart.py

This example shows the decorator pattern on a 2-parameter synthetic function.
Replace the objective body with your own model training loop.
"""

import logging

import mloopforml as mloop

# Suppress M-LOOP's verbose logger (prevents M-LOOP_logs/ file creation)
_mloop_log = logging.getLogger("mloop")
_mloop_log.setLevel(logging.ERROR)
if not _mloop_log.handlers:
    _mloop_log.addHandler(logging.NullHandler())


@mloop.optimize(
    params={"x": (-5.0, 5.0), "y": (-5.0, 5.0)},
    max_iterations=20,
    direction="minimize",
    num_training_runs=5,
    seed=42,
)
def objective(x, y):
    """Rosenbrock function — minimum is 0 at (x=1, y=1)."""
    import random

    noise = random.gauss(0, 0.01)
    return (1 - x) ** 2 + 100 * (y - x**2) ** 2 + noise


if __name__ == "__main__":
    result = objective()

    print(f"\n{'─' * 40}")
    print("Optimization complete!")
    print(f"Best score:  {result.best_score:.4f}")
    print(f"Best params: {result.best_params}")
    print(f"Trials run:  {len(result.all_costs)}")
    print(f"{'─' * 40}")
