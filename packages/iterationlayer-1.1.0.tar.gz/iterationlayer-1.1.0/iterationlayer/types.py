from __future__ import annotations

from typing import Literal, TypedDict, Union

# ── File Input ──────────────────────────────────────────────────────────────


class FileInputBase64(TypedDict):
    type: Literal["base64"]
    name: str
    base64: str


class FileInputUrl(TypedDict):
    type: Literal["url"]
    name: str
    url: str


FileInput = Union[FileInputBase64, FileInputUrl]

# ── Responses ───────────────────────────────────────────────────────────────


class ExtractionFieldResult(TypedDict):
    value: object
    confidence: float
    citations: list[str]
    source: str
    type: str


ExtractionResult = dict[str, ExtractionFieldResult]


class BinaryResult(TypedDict):
    buffer: str
    mime_type: str


class AsyncResult(TypedDict):
    async_: Literal[True]
    message: str


# ── Document Extraction ────────────────────────────────────────────────────


class _TextFieldConfigRequired(TypedDict):
    type: Literal["TEXT"]
    name: str
    description: str


class TextFieldConfig(_TextFieldConfigRequired, total=False):
    is_required: bool
    max_length: int
    default_value: str


class _TextareaFieldConfigRequired(TypedDict):
    type: Literal["TEXTAREA"]
    name: str
    description: str


class TextareaFieldConfig(_TextareaFieldConfigRequired, total=False):
    is_required: bool
    max_length: int
    default_value: str


class _IntegerFieldConfigRequired(TypedDict):
    type: Literal["INTEGER"]
    name: str
    description: str


class IntegerFieldConfig(_IntegerFieldConfigRequired, total=False):
    is_required: bool
    min: int
    max: int
    unit: str
    default_value: int


class _DecimalFieldConfigRequired(TypedDict):
    type: Literal["DECIMAL"]
    name: str
    description: str


class DecimalFieldConfig(_DecimalFieldConfigRequired, total=False):
    is_required: bool
    min: float
    max: float
    decimal_points: int
    unit: str
    default_value: float


class _DateFieldConfigRequired(TypedDict):
    type: Literal["DATE"]
    name: str
    description: str


class DateFieldConfig(_DateFieldConfigRequired, total=False):
    is_required: bool
    allow_future_dates: bool
    allow_past_dates: bool


class _DatetimeFieldConfigRequired(TypedDict):
    type: Literal["DATETIME"]
    name: str
    description: str


class DatetimeFieldConfig(_DatetimeFieldConfigRequired, total=False):
    is_required: bool
    allow_future_dates: bool
    allow_past_dates: bool


class _TimeFieldConfigRequired(TypedDict):
    type: Literal["TIME"]
    name: str
    description: str


class TimeFieldConfig(_TimeFieldConfigRequired, total=False):
    is_required: bool


class _EnumFieldConfigRequired(TypedDict):
    type: Literal["ENUM"]
    name: str
    description: str
    values: list[str]


class EnumFieldConfig(_EnumFieldConfigRequired, total=False):
    is_required: bool
    min_selected: int
    max_selected: int
    default_value: list[str]


class _BooleanFieldConfigRequired(TypedDict):
    type: Literal["BOOLEAN"]
    name: str
    description: str


class BooleanFieldConfig(_BooleanFieldConfigRequired, total=False):
    is_required: bool
    default_value: bool


class _EmailFieldConfigRequired(TypedDict):
    type: Literal["EMAIL"]
    name: str
    description: str


class EmailFieldConfig(_EmailFieldConfigRequired, total=False):
    is_required: bool
    default_value: str


class _IbanFieldConfigRequired(TypedDict):
    type: Literal["IBAN"]
    name: str
    description: str


class IbanFieldConfig(_IbanFieldConfigRequired, total=False):
    is_required: bool
    default_value: str


class _CountryFieldConfigRequired(TypedDict):
    type: Literal["COUNTRY"]
    name: str
    description: str


class CountryFieldConfig(_CountryFieldConfigRequired, total=False):
    is_required: bool
    default_value: str


class _CurrencyCodeFieldConfigRequired(TypedDict):
    type: Literal["CURRENCY_CODE"]
    name: str
    description: str


class CurrencyCodeFieldConfig(_CurrencyCodeFieldConfigRequired, total=False):
    is_required: bool
    default_value: str


class _CurrencyAmountFieldConfigRequired(TypedDict):
    type: Literal["CURRENCY_AMOUNT"]
    name: str
    description: str


class CurrencyAmountFieldConfig(_CurrencyAmountFieldConfigRequired, total=False):
    is_required: bool
    min: float
    max: float
    decimal_points: int
    default_value: float


class _AddressFieldConfigRequired(TypedDict):
    type: Literal["ADDRESS"]
    name: str
    description: str


class AddressFieldConfig(_AddressFieldConfigRequired, total=False):
    is_required: bool
    allowed_country_codes: list[str]


class ItemSchema(TypedDict):
    fields: list[FieldConfig]


class _ArrayFieldConfigRequired(TypedDict):
    type: Literal["ARRAY"]
    name: str
    description: str
    item_schema: ItemSchema


class ArrayFieldConfig(_ArrayFieldConfigRequired, total=False):
    is_required: bool


class _CalculatedFieldConfigRequired(TypedDict):
    type: Literal["CALCULATED"]
    name: str
    description: str
    operation: Literal["sum", "subtract", "multiply", "divide"]
    source_field_names: list[str]


class CalculatedFieldConfig(_CalculatedFieldConfigRequired, total=False):
    is_required: bool
    unit: str


FieldConfig = Union[
    TextFieldConfig,
    TextareaFieldConfig,
    IntegerFieldConfig,
    DecimalFieldConfig,
    DateFieldConfig,
    DatetimeFieldConfig,
    TimeFieldConfig,
    EnumFieldConfig,
    BooleanFieldConfig,
    EmailFieldConfig,
    IbanFieldConfig,
    CountryFieldConfig,
    CurrencyCodeFieldConfig,
    CurrencyAmountFieldConfig,
    AddressFieldConfig,
    ArrayFieldConfig,
    CalculatedFieldConfig,
]


class ExtractionSchema(TypedDict):
    fields: list[FieldConfig]


class _ExtractRequestRequired(TypedDict):
    files: list[FileInput]
    schema: ExtractionSchema


class ExtractRequest(_ExtractRequestRequired, total=False):
    webhook_url: str


# ── Image Transformation ───────────────────────────────────────────────────

ResizeFit = Literal["cover", "contain", "fill", "inside", "outside"]
ConvertFormat = Literal["png", "jpeg", "webp", "avif", "heif"]


class ResizeOperation(TypedDict):
    type: Literal["resize"]
    width_in_px: int
    height_in_px: int
    fit: ResizeFit


class CropOperation(TypedDict):
    type: Literal["crop"]
    left_in_px: int
    top_in_px: int
    width_in_px: int
    height_in_px: int


class ExtendOperation(TypedDict):
    type: Literal["extend"]
    top_in_px: int
    bottom_in_px: int
    left_in_px: int
    right_in_px: int
    hex_color: str


class TrimOperation(TypedDict):
    type: Literal["trim"]
    threshold: int


class _RotateOperationRequired(TypedDict):
    type: Literal["rotate"]
    angle_in_degrees: float


class RotateOperation(_RotateOperationRequired, total=False):
    hex_color: str


class FlipOperation(TypedDict):
    type: Literal["flip"]


class FlopOperation(TypedDict):
    type: Literal["flop"]


class BlurOperation(TypedDict):
    type: Literal["blur"]
    sigma: float


class SharpenOperation(TypedDict):
    type: Literal["sharpen"]
    sigma: float


class _ModulateOperationRequired(TypedDict):
    type: Literal["modulate"]


class ModulateOperation(_ModulateOperationRequired, total=False):
    brightness: float
    saturation: float
    hue: float


class TintOperation(TypedDict):
    type: Literal["tint"]
    hex_color: str


class GrayscaleOperation(TypedDict):
    type: Literal["grayscale"]


class InvertColorsOperation(TypedDict):
    type: Literal["invert_colors"]


class AutoContrastOperation(TypedDict):
    type: Literal["auto_contrast"]


class GammaOperation(TypedDict):
    type: Literal["gamma"]
    gamma: float


class RemoveTransparencyOperation(TypedDict):
    type: Literal["remove_transparency"]
    hex_color: str


class ThresholdOperation(TypedDict):
    type: Literal["threshold"]
    value: int
    is_grayscale: bool


class DenoiseOperation(TypedDict):
    type: Literal["denoise"]
    size: int


class OpacityOperation(TypedDict):
    type: Literal["opacity"]
    opacity_in_percent: int


class _ConvertOperationRequired(TypedDict):
    type: Literal["convert"]
    format: ConvertFormat


class ConvertOperation(_ConvertOperationRequired, total=False):
    quality: int


class UpscaleOperation(TypedDict):
    type: Literal["upscale"]
    factor: Literal[2, 3, 4]


class SmartCropOperation(TypedDict):
    type: Literal["smart_crop"]
    width_in_px: int
    height_in_px: int


class CompressToSizeOperation(TypedDict):
    type: Literal["compress_to_size"]
    max_file_size_in_bytes: int


class _RemoveBackgroundOperationRequired(TypedDict):
    type: Literal["remove_background"]


class RemoveBackgroundOperation(_RemoveBackgroundOperationRequired, total=False):
    background_hex_color: str


TransformOperation = Union[
    ResizeOperation,
    CropOperation,
    ExtendOperation,
    TrimOperation,
    RotateOperation,
    FlipOperation,
    FlopOperation,
    BlurOperation,
    SharpenOperation,
    ModulateOperation,
    TintOperation,
    GrayscaleOperation,
    InvertColorsOperation,
    AutoContrastOperation,
    GammaOperation,
    RemoveTransparencyOperation,
    ThresholdOperation,
    DenoiseOperation,
    OpacityOperation,
    ConvertOperation,
    UpscaleOperation,
    SmartCropOperation,
    CompressToSizeOperation,
    RemoveBackgroundOperation,
]


class _TransformRequestRequired(TypedDict):
    file: FileInput
    operations: list[TransformOperation]


class TransformRequest(_TransformRequestRequired, total=False):
    webhook_url: str


# ── Image Generation ────────────────────────────────────────────────────────


class Dimensions(TypedDict):
    width_in_px: int
    height_in_px: int


class Position(TypedDict):
    x_in_px: int
    y_in_px: int


class AngledEdge(TypedDict):
    edge: Literal["left", "right", "top", "bottom"]
    angle_in_degrees: float


class GradientColorStop(TypedDict):
    hex_color: str
    position: float


class ImageFontDefinition(TypedDict):
    name: str
    weight: str
    style: Literal["normal", "italic"]
    file: FileInput


ImageOutputFormat = Literal["png", "jpeg", "webp", "tiff", "gif", "avif"]


class _SolidColorLayerRequired(TypedDict):
    type: Literal["solid-color"]
    index: int
    hex_color: str


class SolidColorLayer(_SolidColorLayerRequired, total=False):
    opacity: int


class _SolidColorLayerRequired(TypedDict):
    type: Literal["solid-color"]
    index: int
    hex_color: str
    position: Position
    dimensions: Dimensions


class SolidColorLayer(_SolidColorLayerRequired, total=False):
    rotation_in_degrees: float
    opacity: int
    angled_edges: list[AngledEdge]
    border_radius: int
    border_top_left_radius: int
    border_top_right_radius: int
    border_bottom_left_radius: int
    border_bottom_right_radius: int


class _TextLayerRequired(TypedDict):
    type: Literal["text"]
    index: int
    text: str
    font_name: str
    font_size_in_px: int
    text_color: str
    position: Position
    dimensions: Dimensions


class TextLayer(_TextLayerRequired, total=False):
    font_weight: str
    font_style: Literal["normal", "italic"]
    text_align: Literal["left", "center", "right"]
    vertical_align: Literal["top", "center", "bottom"]
    is_splitting_lines: bool
    paragraph_spacing_in_px: int
    should_auto_scale: bool
    rotation_in_degrees: float
    opacity: int


class _ImageLayerRequired(TypedDict):
    type: Literal["image"]
    index: int
    file: FileInput
    position: Position
    dimensions: Dimensions


class ImageLayer(_ImageLayerRequired, total=False):
    rotation_in_degrees: float
    opacity: int
    should_use_smart_cropping: bool
    should_remove_background: bool
    border_radius: int
    border_top_left_radius: int
    border_top_right_radius: int
    border_bottom_left_radius: int
    border_bottom_right_radius: int


class _ImageLayerRequired(TypedDict):
    type: Literal["image"]
    index: int
    file: FileInput


class ImageLayer(_ImageLayerRequired, total=False):
    opacity: int
    should_use_smart_cropping: bool


class _QrCodeLayerRequired(TypedDict):
    type: Literal["qr-code"]
    index: int
    value: str
    foreground_hex_color: str
    background_hex_color: str
    position: Position
    dimensions: Dimensions


class QrCodeLayer(_QrCodeLayerRequired, total=False):
    rotation_in_degrees: float
    opacity: int


class _BarcodeLayerRequired(TypedDict):
    type: Literal["barcode"]
    index: int
    value: str
    format: Literal["code128", "ean13", "ean8", "code39", "itf", "codabar"]
    foreground_hex_color: str
    background_hex_color: str
    position: Position
    dimensions: Dimensions


class BarcodeLayer(_BarcodeLayerRequired, total=False):
    rotation_in_degrees: float
    opacity: int


class _GradientLayerRequired(TypedDict):
    type: Literal["gradient"]
    index: int
    gradient_type: Literal["linear", "radial"]
    colors: list[GradientColorStop]
    position: Position
    dimensions: Dimensions


class GradientLayer(_GradientLayerRequired, total=False):
    angle_in_degrees: float
    rotation_in_degrees: float
    opacity: int
    border_radius: int
    border_top_left_radius: int
    border_top_right_radius: int
    border_bottom_left_radius: int
    border_bottom_right_radius: int


class _LayoutLayerRequired(TypedDict):
    type: Literal["layout"]
    index: int
    layers: list["Layer"]


class LayoutLayer(_LayoutLayerRequired, total=False):
    direction: Literal["horizontal", "vertical"]
    gap: int
    horizontal_alignment: Literal["start", "center", "end"]
    vertical_alignment: Literal["start", "center", "end"]
    position: Position
    dimensions: Dimensions
    opacity: int
    background_color: str
    padding: int
    padding_top: int
    padding_right: int
    padding_bottom: int
    padding_left: int
    border_radius: int
    border_top_left_radius: int
    border_top_right_radius: int
    border_bottom_left_radius: int
    border_bottom_right_radius: int


Layer = Union[
    SolidColorLayer,
    SolidColorLayer,
    TextLayer,
    ImageLayer,
    ImageLayer,
    QrCodeLayer,
    BarcodeLayer,
    GradientLayer,
    LayoutLayer,
]


class _GenerateImageRequestRequired(TypedDict):
    dimensions: Dimensions
    layers: list[Layer]


class GenerateImageRequest(_GenerateImageRequestRequired, total=False):
    fonts: list[ImageFontDefinition]
    output_format: ImageOutputFormat
    webhook_url: str


# ── Document Generation ─────────────────────────────────────────────────────

DocumentFormat = Literal["pdf", "docx", "epub", "pptx"]

PageSizePreset = Literal[
    "A0",
    "A1",
    "A2",
    "A3",
    "A4",
    "A5",
    "A6",
    "B0",
    "B1",
    "B2",
    "B3",
    "B4",
    "B5",
    "B6",
    "Letter",
    "Legal",
    "Tabloid",
    "Executive",
    "Statement",
]

HeadlineLevel = Literal["h1", "h2", "h3", "h4", "h5", "h6"]

TextAlignment = Literal["left", "center", "right", "justify"]

HorizontalAlignment = Literal["left", "center", "right"]

VerticalAlignment = Literal["top", "center", "bottom"]

FontWeight = Literal[
    "thin",
    "extralight",
    "light",
    "regular",
    "medium",
    "semibold",
    "bold",
    "extrabold",
    "black",
]

DocBarcodeFormat = Literal["code128", "ean13", "ean8", "code39", "itf", "codabar"]


class _DocumentMetadataRequired(TypedDict):
    title: str


class DocumentMetadata(_DocumentMetadataRequired, total=False):
    author: str
    language: str


class PageSize(TypedDict, total=False):
    preset: PageSizePreset
    width_in_pt: float
    height_in_pt: float


class Margins(TypedDict):
    top_in_pt: float
    right_in_pt: float
    bottom_in_pt: float
    left_in_pt: float


class _DocumentPageRequired(TypedDict):
    size: PageSize
    margins: Margins


class DocumentPage(_DocumentPageRequired, total=False):
    background_color: str


class DocumentFontDefinition(TypedDict):
    name: str
    weight: FontWeight
    style: Literal["normal", "italic"]
    buffer: str


class TextStyle(TypedDict):
    font_family: str
    font_size_in_pt: float
    line_height: float
    color: str


class _TextStyleOptional(TypedDict, total=False):
    is_bold: bool
    is_italic: bool


class HeadlineStyle(TypedDict):
    font_family: str
    font_size_in_pt: float
    color: str
    spacing_before_in_pt: float
    spacing_after_in_pt: float


class _HeadlineStyleOptional(TypedDict, total=False):
    is_bold: bool
    is_italic: bool


class LinkStyle(TypedDict):
    color: str


class _LinkStyleOptional(TypedDict, total=False):
    is_underlined: bool


class ListStyle(TypedDict):
    indent_in_pt: float
    spacing_between_items_in_pt: float


class BorderStyle(TypedDict):
    width_in_pt: float
    color: str


class _TableHeaderStyleRequired(TypedDict):
    background_color: str
    font_family: str
    font_size_in_pt: float
    color: str
    padding_in_pt: float


class TableHeaderStyle(_TableHeaderStyleRequired, total=False):
    is_bold: bool
    border: BorderStyle


class _TableBodyStyleRequired(TypedDict):
    font_family: str
    font_size_in_pt: float
    color: str
    padding_in_pt: float


class TableBodyStyle(_TableBodyStyleRequired, total=False):
    alternate_background_color: str
    border: BorderStyle


class TableStyle(TypedDict):
    header: TableHeaderStyle
    body: TableBodyStyle


class GridStyle(TypedDict):
    gap_in_pt: float


class SeparatorStyle(TypedDict):
    color: str
    thickness_in_pt: float
    margin_top_in_pt: float
    margin_bottom_in_pt: float


class ImageStyle(TypedDict):
    alignment: HorizontalAlignment
    margin_top_in_pt: float
    margin_bottom_in_pt: float


class DocumentStyles(TypedDict):
    text: TextStyle
    headline: HeadlineStyle
    link: LinkStyle
    list: ListStyle
    table: TableStyle
    grid: GridStyle
    separator: SeparatorStyle
    image: ImageStyle


# Style overrides (all optional)


class TextStyleOverrides(TypedDict, total=False):
    font_family: str
    font_size_in_pt: float
    line_height: float
    color: str
    is_bold: bool
    is_italic: bool


class HeadlineStyleOverrides(TypedDict, total=False):
    font_family: str
    font_size_in_pt: float
    color: str
    spacing_before_in_pt: float
    spacing_after_in_pt: float
    is_bold: bool
    is_italic: bool


class TableCellStyle(TypedDict, total=False):
    background_color: str
    color: str
    is_bold: bool
    is_italic: bool


class ListStyleOverrides(TypedDict, total=False):
    indent_in_pt: float
    spacing_between_items_in_pt: float


class SeparatorStyleOverrides(TypedDict, total=False):
    color: str
    thickness_in_pt: float
    margin_top_in_pt: float
    margin_bottom_in_pt: float


class ImageStyleOverrides(TypedDict, total=False):
    alignment: HorizontalAlignment
    margin_top_in_pt: float
    margin_bottom_in_pt: float


class GridStyleOverrides(TypedDict, total=False):
    gap_in_pt: float


class TableStyleOverrides(TypedDict, total=False):
    header: TableHeaderStyle
    body: TableBodyStyle


# Content blocks


class _ParagraphRunRequired(TypedDict):
    text: str


class ParagraphRun(_ParagraphRunRequired, total=False):
    is_bold: bool
    is_italic: bool
    link_url: str


class HeadlineTableOfContents(TypedDict, total=False):
    is_excluded: bool
    label: str


class ParagraphBlock(TypedDict, total=False):
    type: Literal["paragraph"]
    markdown: str
    text_alignment: TextAlignment
    runs: list[ParagraphRun]
    styles: TextStyleOverrides


class _HeadlineBlockRequired(TypedDict):
    type: Literal["headline"]
    level: HeadlineLevel
    text: str


class HeadlineBlock(_HeadlineBlockRequired, total=False):
    styles: HeadlineStyleOverrides
    table_of_contents: HeadlineTableOfContents


class _ImageBlockRequired(TypedDict):
    type: Literal["image"]
    buffer: str
    width_in_pt: float
    height_in_pt: float


class ImageBlock(_ImageBlockRequired, total=False):
    fit: Literal["cover", "contain"]
    styles: ImageStyleOverrides


class _TableCellRequired(TypedDict):
    text: str


class TableCell(_TableCellRequired, total=False):
    horizontal_alignment: HorizontalAlignment
    column_span: int
    row_span: int
    styles: TableCellStyle


class TableRow(TypedDict):
    cells: list[TableCell]


class _TableBlockRequired(TypedDict):
    type: Literal["table"]
    rows: list[TableRow]


class TableBlock(_TableBlockRequired, total=False):
    header: TableRow
    column_widths_in_percent: list[float]
    styles: TableStyleOverrides


class _GridColumnRequired(TypedDict):
    column_span: int
    blocks: list[ContentBlock]


class GridColumn(_GridColumnRequired, total=False):
    horizontal_alignment: HorizontalAlignment
    vertical_alignment: VerticalAlignment


class _GridBlockRequired(TypedDict):
    type: Literal["grid"]
    columns: list[GridColumn]


class GridBlock(_GridBlockRequired, total=False):
    horizontal_alignment: HorizontalAlignment
    vertical_alignment: VerticalAlignment
    styles: GridStyleOverrides


class ListItem(TypedDict):
    text: str


class _ListBlockRequired(TypedDict):
    type: Literal["list"]
    variant: Literal["ordered", "unordered"]
    items: list[ListItem]


class ListBlock(_ListBlockRequired, total=False):
    styles: ListStyleOverrides


class _TableOfContentsBlockRequired(TypedDict):
    type: Literal["table-of-contents"]
    levels: list[HeadlineLevel]
    leader: Literal["dots", "none"]


class TableOfContentsBlock(_TableOfContentsBlockRequired, total=False):
    text_alignment: TextAlignment
    styles: TextStyleOverrides


class PageBreakBlock(TypedDict):
    type: Literal["page-break"]


class SeparatorBlock(TypedDict, total=False):
    type: Literal["separator"]
    styles: SeparatorStyleOverrides


class _DocumentQrCodeBlockRequired(TypedDict):
    type: Literal["qr-code"]
    value: str
    width_in_pt: float
    height_in_pt: float


class DocumentQrCodeBlock(_DocumentQrCodeBlockRequired, total=False):
    fg_hex_color: str
    bg_hex_color: str


class _DocumentBarcodeBlockRequired(TypedDict):
    type: Literal["barcode"]
    value: str
    format: DocBarcodeFormat
    width_in_pt: float
    height_in_pt: float


class DocumentBarcodeBlock(_DocumentBarcodeBlockRequired, total=False):
    fg_hex_color: str
    bg_hex_color: str


ContentBlock = Union[
    ParagraphBlock,
    HeadlineBlock,
    ImageBlock,
    TableBlock,
    GridBlock,
    ListBlock,
    TableOfContentsBlock,
    PageBreakBlock,
    SeparatorBlock,
    DocumentQrCodeBlock,
    DocumentBarcodeBlock,
]


class PageNumberBlock(TypedDict, total=False):
    type: Literal["page-number"]
    text_alignment: TextAlignment
    styles: TextStyleOverrides


HeaderFooterBlock = Union[
    ParagraphBlock,
    HeadlineBlock,
    ImageBlock,
    TableBlock,
    GridBlock,
    ListBlock,
    PageNumberBlock,
    SeparatorBlock,
]


class _DocumentDefinitionRequired(TypedDict):
    metadata: DocumentMetadata
    page: DocumentPage
    styles: DocumentStyles
    content: list[ContentBlock]


class DocumentDefinition(_DocumentDefinitionRequired, total=False):
    fonts: list[DocumentFontDefinition]
    header: list[HeaderFooterBlock]
    footer: list[HeaderFooterBlock]
    header_distance_from_edge_in_pt: float
    footer_distance_from_edge_in_pt: float


class _GenerateDocumentRequestRequired(TypedDict):
    format: DocumentFormat
    document: DocumentDefinition


class GenerateDocumentRequest(_GenerateDocumentRequestRequired, total=False):
    webhook_url: str


# ── Sheet Generation ─────────────────────────────────────────────────────

SheetFormat = Literal["csv", "markdown", "xlsx"]

SheetCellFormat = Literal[
    "text",
    "number",
    "decimal",
    "currency",
    "percentage",
    "date",
    "datetime",
    "time",
    "custom",
]

SheetNumberStyle = Literal[
    "comma_period",
    "period_comma",
    "space_comma",
    "space_period",
]


class SheetCellStyle(TypedDict, total=False):
    bold: bool
    italic: bool
    font_color: str
    background_color: str
    font_size: int
    horizontal_alignment: Literal["left", "center", "right"]


class _SheetCellRequired(TypedDict):
    value: object


class SheetCell(_SheetCellRequired, total=False):
    format: SheetCellFormat
    currency_code: str
    number_style: SheetNumberStyle
    date_style: str
    styles: SheetCellStyle
    from_col: int
    to_col: int
    from_row: int
    to_row: int


class _SheetColumnRequired(TypedDict):
    name: str


class SheetColumn(_SheetColumnRequired, total=False):
    width: int


class _SheetDefinitionRequired(TypedDict):
    columns: list[SheetColumn]


class SheetDefinition(_SheetDefinitionRequired, total=False):
    name: str
    rows: list[list[SheetCell]]


class SheetFontDefinition(TypedDict):
    name: str
    buffer: str


class SheetStyles(TypedDict, total=False):
    header_font_color: str
    header_background_color: str
    header_font_size: int
    header_bold: bool
    alternate_row_color: str


class _GenerateSheetRequestRequired(TypedDict):
    format: SheetFormat
    sheets: list[SheetDefinition]


class GenerateSheetRequest(_GenerateSheetRequestRequired, total=False):
    styles: SheetStyles
    fonts: list[SheetFontDefinition]
    webhook_url: str
