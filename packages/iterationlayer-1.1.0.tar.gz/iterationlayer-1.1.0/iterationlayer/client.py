from __future__ import annotations

from typing import Any, cast

import httpx

from iterationlayer.types import (
    AsyncResult,
    BinaryResult,
    DocumentDefinition,
    DocumentFormat,
    ExtractionResult,
    ExtractionSchema,
    FileInput,
    ImageFontDefinition,
    ImageOutputFormat,
    Layer,
    SheetDefinition,
    SheetFontDefinition,
    SheetFormat,
    SheetStyles,
    TransformOperation,
)
from iterationlayer.types import Dimensions as ImageDimensions

DEFAULT_BASE_URL = "https://api.iterationlayer.com"
DEFAULT_TIMEOUT_IN_S = 300


class IterationLayerError(Exception):
    def __init__(self, status_code: int, error_message: str) -> None:
        self.status_code = status_code
        self.error_message = error_message
        super().__init__(f"Iteration Layer API error ({status_code}): {error_message}")


class IterationLayer:
    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout_in_s: float = DEFAULT_TIMEOUT_IN_S,
    ) -> None:
        self._client = httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout_in_s,
        )

    def extract(
        self,
        *,
        files: list[FileInput],
        schema: ExtractionSchema,
    ) -> ExtractionResult:
        body: dict[str, Any] = {"files": files, "schema": schema}

        return cast(ExtractionResult, self._post("/document-extraction/v1/extract", body))

    def extract_async(
        self,
        *,
        files: list[FileInput],
        schema: ExtractionSchema,
        webhook_url: str,
    ) -> AsyncResult:
        body: dict[str, Any] = {
            "files": files,
            "schema": schema,
            "webhook_url": webhook_url,
        }

        return cast(AsyncResult, self._post("/document-extraction/v1/extract", body))

    def transform(
        self,
        *,
        file: FileInput,
        operations: list[TransformOperation],
    ) -> BinaryResult:
        body: dict[str, Any] = {"file": file, "operations": operations}

        return cast(BinaryResult, self._post("/image-transformation/v1/transform", body))

    def transform_async(
        self,
        *,
        file: FileInput,
        operations: list[TransformOperation],
        webhook_url: str,
    ) -> AsyncResult:
        body: dict[str, Any] = {
            "file": file,
            "operations": operations,
            "webhook_url": webhook_url,
        }

        return cast(AsyncResult, self._post("/image-transformation/v1/transform", body))

    def generate_image(
        self,
        *,
        dimensions: ImageDimensions,
        layers: list[Layer],
        fonts: list[ImageFontDefinition] | None = None,
        output_format: ImageOutputFormat | None = None,
    ) -> BinaryResult:
        body: dict[str, Any] = {"dimensions": dimensions, "layers": layers}

        if fonts is not None:
            body["fonts"] = fonts
        if output_format is not None:
            body["output_format"] = output_format

        return cast(BinaryResult, self._post("/image-generation/v1/generate", body))

    def generate_image_async(
        self,
        *,
        dimensions: ImageDimensions,
        layers: list[Layer],
        webhook_url: str,
        fonts: list[ImageFontDefinition] | None = None,
        output_format: ImageOutputFormat | None = None,
    ) -> AsyncResult:
        body: dict[str, Any] = {
            "dimensions": dimensions,
            "layers": layers,
            "webhook_url": webhook_url,
        }

        if fonts is not None:
            body["fonts"] = fonts
        if output_format is not None:
            body["output_format"] = output_format

        return cast(AsyncResult, self._post("/image-generation/v1/generate", body))

    def generate_document(
        self,
        *,
        format: DocumentFormat,
        document: DocumentDefinition,
    ) -> BinaryResult:
        body: dict[str, Any] = {"format": format, "document": document}

        return cast(BinaryResult, self._post("/document-generation/v1/generate", body))

    def generate_document_async(
        self,
        *,
        format: DocumentFormat,
        document: DocumentDefinition,
        webhook_url: str,
    ) -> AsyncResult:
        body: dict[str, Any] = {
            "format": format,
            "document": document,
            "webhook_url": webhook_url,
        }

        return cast(AsyncResult, self._post("/document-generation/v1/generate", body))

    def generate_sheet(
        self,
        *,
        format: SheetFormat,
        sheets: list[SheetDefinition],
        styles: SheetStyles | None = None,
        fonts: list[SheetFontDefinition] | None = None,
    ) -> BinaryResult:
        body: dict[str, Any] = {"format": format, "sheets": sheets}

        if styles is not None:
            body["styles"] = styles
        if fonts is not None:
            body["fonts"] = fonts

        return cast(BinaryResult, self._post("/sheet-generation/v1/generate", body))

    def generate_sheet_async(
        self,
        *,
        format: SheetFormat,
        sheets: list[SheetDefinition],
        webhook_url: str,
        styles: SheetStyles | None = None,
        fonts: list[SheetFontDefinition] | None = None,
    ) -> AsyncResult:
        body: dict[str, Any] = {
            "format": format,
            "sheets": sheets,
            "webhook_url": webhook_url,
        }

        if styles is not None:
            body["styles"] = styles
        if fonts is not None:
            body["fonts"] = fonts

        return cast(AsyncResult, self._post("/sheet-generation/v1/generate", body))

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> IterationLayer:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def _post(self, path: str, body: dict[str, Any]) -> Any:
        response = self._client.post(path, json=body)
        parsed: dict[str, Any] = response.json()

        if not parsed.get("success"):
            raise IterationLayerError(
                response.status_code, str(parsed.get("error", "Unknown error"))
            )

        if parsed.get("async"):
            return {"async": True, "message": parsed["message"]}

        return parsed["data"]
