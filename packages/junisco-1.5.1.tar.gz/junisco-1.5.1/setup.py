from setuptools import setup

setup(
    name="junisco",
    version="1.5.1",
    py_modules=["junisco"],
    entry_points={
        "console_scripts": [
            "junisco=junisco:main",
        ],
    },
    install_requires=[
        "requests",
        "colorama",
        "pyfiglet",
    ],
    include_package_data=True,
    package_data={
        "": ["platforms.json"],
    },
)