import json
import pyfiglet
import requests
import time
import sys
import threading
import os
from colorama import Fore, init

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(BASE_DIR, 'platforms.json'), 'r') as f:
    platforms = json.load(f)

def banner():
    init(autoreset=True)
    print(pyfiglet.figlet_format("J u n i s c o", font="slant"))
    print("                                        Developer: Pov6")
    time.sleep(2)
    print(Fore.BLUE + "[INFO]" + Fore.WHITE + " Current Junisco Version - " + Fore.GREEN + "v1.5.1")
    time.sleep(3)
    print(Fore.BLUE + "[INFO]" + Fore.WHITE + " Enumerating Platform Templates")
    time.sleep(3)
    print(Fore.BLUE + "[INFO]" + Fore.WHITE + " Initializing modules...")
    time.sleep(1)

def check_platform(platform_name, url_base, username, found, proxies, lock):
    profile_url = url_base + username
    try:
        response = requests.get(profile_url, timeout=2, proxies=proxies)
        if response.status_code == 200:
            with lock:
                print(Fore.GREEN + "[FOUND] " + Fore.WHITE + profile_url)
                found.append(profile_url)
    except:
        pass

def main():
    if len(sys.argv) == 1:
        banner()
        return

    if sys.argv[1] == "-h":
        print(Fore.LIGHTCYAN_EX + "Junisco - Username Enumeration Tool")
        print("'-h' -> show help cmd\n"
              "'-u' -> username to scan\n"
              "'-d' -> specific domain to scan username\n"
              "'-o' -> save the output to a specific file\n"
              "'-proxy' -> setup a proxy server to use")
        return

    found = []
    username = None

    # -proxy
    if "-proxy" in sys.argv:
        proxy = sys.argv[sys.argv.index("-proxy") + 1]
        proxies = {
            "http": f"http://{proxy}",
            "https": f"http://{proxy}"
        }
        print(Fore.BLUE + "[INFO] " + Fore.WHITE + f"Using proxy: {proxy}")
    else:
        proxies = None

    # -u flag
    if "-u" in sys.argv:
        banner()
        username = sys.argv[sys.argv.index("-u") + 1]
        print(f"\nSearching for " + Fore.YELLOW + f"{username}:\n")
        time.sleep(3)

        lock = threading.Lock()
        threads = []
        start_time = time.time()

        for category, sites in platforms.items():
            for platform_name, url_base in sites.items():
                t = threading.Thread(
                    target=check_platform,
                    args=(platform_name, url_base, username, found, proxies, lock)
                )
                threads.append(t)
                t.start()

        for t in threads:
            t.join()

        elapsed = time.time() - start_time

        print(Fore.BLUE + "\n[INFO] " + Fore.WHITE + "Scan complete.")
        print(Fore.BLUE + "[INFO] " + Fore.WHITE + "Sites found:  " + Fore.GREEN + str(len(found)))
        print(Fore.BLUE + "[INFO] " + Fore.WHITE + "Time taken:   " + Fore.GREEN + f"{elapsed:.2f}s")

    # -d flag
    if "-u" in sys.argv and "-d" in sys.argv:
        username = sys.argv[sys.argv.index("-u") + 1]
        domain = sys.argv[sys.argv.index("-d") + 1]
        url1 = "https://" + domain + "/" + username
        print(f"\nSearching for {username} in {domain}:")

        start_time = time.time()

        try:
            response1 = requests.get(url1, timeout=2, proxies=proxies)
            if response1.status_code == 200:
                print(Fore.GREEN + "[FOUND] " + Fore.WHITE + url1)
                found.append(url1)
            elif response1.status_code == 404:
                print(Fore.YELLOW + "[NOT FOUND] " + Fore.WHITE + f"Username not found in {domain}")
            elif response1.status_code == 403:
                print(Fore.RED + "[BLOCKED] " + Fore.WHITE + "Access Denied - " + domain)
        except:
            pass

        elapsed = time.time() - start_time

        print(Fore.BLUE + "[INFO] " + Fore.WHITE + "Total Sites found:  " + Fore.GREEN + str(len(found)))
        print(Fore.BLUE + "[INFO] " + Fore.WHITE + "Time taken:   " + Fore.GREEN + f"{elapsed:.2f}s")

    # -o flag
    if "-o" in sys.argv:
        filename = sys.argv[sys.argv.index("-o") + 1]
        with open(filename, "w") as filez:
            for url in found:
                filez.write(url + "\n")
        print(Fore.BLUE + "\n[INFO] " + Fore.WHITE + f"Results saved to {filename}")

if __name__ == "__main__":
    main()