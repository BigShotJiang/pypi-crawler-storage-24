"""Baidu Pan Web client and Web UI."""

__all__ = ["__version__"]

__version__ = "0.1.1"
