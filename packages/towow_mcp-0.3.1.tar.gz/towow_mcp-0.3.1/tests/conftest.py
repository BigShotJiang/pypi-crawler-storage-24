"""Shared fixtures for lightweight MCP config / SSE tests."""

import json

import httpx
import pytest


@pytest.fixture
def tmp_config(tmp_path):
    """临时配置文件，避免污染 ~/.towow/"""
    config_path = tmp_path / "config.json"
    config_path.write_text(
        json.dumps(
            {"session_token": "test-tok", "base_url": "http://test"},
            ensure_ascii=False,
        )
    )
    return config_path


@pytest.fixture
def mock_sse_handler():
    """返回 SSE 流的 httpx MockTransport handler 工厂。

    用法:
        transport = mock_sse_handler(["data: hello\\n\\n", "data: world\\n\\n"])
    """

    def create(events: list[str]):
        def handler(request: httpx.Request):
            body = "\n".join(events)
            return httpx.Response(
                200,
                content=body.encode(),
                headers={"content-type": "text/event-stream"},
            )

        return httpx.MockTransport(handler)

    return create
