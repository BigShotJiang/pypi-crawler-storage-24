"""Deprecated V1 session store retained only for historical reference.

Canonical MCP formulation state now lives in `/protocol/formulations/*` on the
Towow backend. This module is intentionally unused by the Phase 1 adapter.
"""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field


@dataclass
class FormulationSession:
    """A single formulation chat session."""
    session_id: str
    messages: list[dict] = field(default_factory=list)  # [{role, text}]
    document_content: str = ""
    profile: str | None = None
    created_at: float = field(default_factory=time.monotonic)


class SessionLimitError(Exception):
    """Raised when the session hard limit is reached."""


class SessionStore:
    """In-memory session store with TTL expiration and hard limit.
    
    - TTL default: 30 minutes (1800 seconds)
    - Hard limit: 100 concurrent sessions
    - Lazy cleanup on get() and create()
    """

    def __init__(self, ttl_seconds: float = 1800.0, max_sessions: int = 100) -> None:
        self._sessions: dict[str, FormulationSession] = {}
        self._ttl = ttl_seconds
        self._max = max_sessions
        self._lock = threading.Lock()

    def create(
        self,
        user_msg: str,
        document_content: str = "",
        profile: str | None = None,
    ) -> str:
        """Create a new session. Returns session_id.
        
        Raises SessionLimitError if hard limit reached after cleanup.
        """
        with self._lock:
            self._cleanup_expired_locked()
            if len(self._sessions) >= self._max:
                raise SessionLimitError(
                    f"Session limit reached ({self._max}). Try again later."
                )
            session_id = uuid.uuid4().hex[:16]
            session = FormulationSession(
                session_id=session_id,
                messages=[{"role": "user", "text": user_msg}],
                document_content=document_content,
                profile=profile,
            )
            self._sessions[session_id] = session
            return session_id

    def get(self, session_id: str) -> FormulationSession | None:
        """Get session by ID, or None if not found or expired."""
        session = self._sessions.get(session_id)
        if session is None:
            return None
        if time.monotonic() - session.created_at > self._ttl:
            del self._sessions[session_id]
            return None
        return session

    def append(self, session_id: str, role: str, text: str) -> None:
        """Append a message to session history.
        
        Raises KeyError if session not found or expired.
        """
        session = self.get(session_id)
        if session is None:
            raise KeyError(f"Session not found: {session_id}")
        session.messages.append({"role": role, "text": text})

    def update_document(self, session_id: str, new_content: str) -> None:
        """Update the document content for a session.
        
        Raises KeyError if session not found or expired.
        """
        session = self.get(session_id)
        if session is None:
            raise KeyError(f"Session not found: {session_id}")
        session.document_content = new_content

    def cleanup_expired(self) -> int:
        """Remove all expired sessions. Returns count of removed sessions."""
        with self._lock:
            return self._cleanup_expired_locked()

    def _cleanup_expired_locked(self) -> int:
        """Internal cleanup (caller must hold self._lock)."""
        now = time.monotonic()
        expired = [
            sid for sid, s in self._sessions.items()
            if now - s.created_at > self._ttl
        ]
        for sid in expired:
            del self._sessions[sid]
        return len(expired)
