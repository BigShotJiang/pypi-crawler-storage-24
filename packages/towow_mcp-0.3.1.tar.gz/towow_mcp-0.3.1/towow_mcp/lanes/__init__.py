"""Lane-specific runtime helpers for Towow MCP."""
