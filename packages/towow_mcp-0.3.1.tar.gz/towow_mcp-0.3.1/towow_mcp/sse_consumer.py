"""SSE stream consumer for canonical formulation reply streams."""

from __future__ import annotations

import json
import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class SSEError(Exception):
    """Raised on SSE error events or parse failures."""


class AuthError(Exception):
    """Raised on HTTP 401 responses."""


async def consume_sse_stream(
    response: httpx.Response,
) -> tuple[str, dict[str, Any]]:
    """Consume an SSE stream from canonical formulation reply endpoints.

    Returns:
        (full_text, updates_dict) where:
        - full_text: all text event deltas concatenated
        - updates_dict: {field_name: value} from update events

    Raises:
        AuthError: on HTTP 401
        SSEError: on HTTP error, SSE error event, or parse failure
    """
    if response.status_code == 401:
        raise AuthError("Authentication failed (401)")
    if response.status_code != 200:
        raise SSEError(f"HTTP {response.status_code}: {response.text[:200]}")

    full_text = ""
    updates: dict[str, Any] = {}
    current_event = ""
    done_received = False

    async for line in response.aiter_lines():
        line = line.strip()

        if not line:
            # Empty line = end of event
            current_event = ""
            continue

        if line.startswith("event:"):
            current_event = line[6:].strip()
            continue

        if line.startswith("data:"):
            raw_data = line[5:].strip()
            try:
                data = json.loads(raw_data)
            except json.JSONDecodeError:
                logger.warning("Failed to parse SSE data: %s", raw_data[:100])
                continue

            if current_event == "text":
                delta = data.get("delta", "")
                full_text += delta

            elif current_event == "update":
                field = data.get("field", "")
                value = data.get("value", "")
                if field:
                    updates[field] = value

            elif current_event == "done":
                logger.debug("SSE stream done. Usage: %s", data.get("usage"))
                done_received = True
                break

            elif current_event == "error":
                msg = data.get("message", data.get("error", "Unknown SSE error"))
                raise SSEError(msg)

    if not done_received and not full_text:
        raise SSEError("SSE stream ended without done event and no content received")
    if not done_received:
        logger.warning("SSE stream ended without done event (partial response: %d chars)", len(full_text))

    return full_text, updates
