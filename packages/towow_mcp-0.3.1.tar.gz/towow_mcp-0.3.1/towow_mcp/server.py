"""Towow MCP Server — canonical workflow adapter over /protocol APIs."""

from __future__ import annotations

import json
import logging
from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, ParamSpec

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError

from .client import APIError, AuthError, TowowClient
from .config import (
    get_auth_lane,
    get_entry_surface,
    clear_agent,
    get_scene_display_name,
    get_scene_id,
    clear_session_token,
    get_agent_id,
    get_display_name,
    get_session_token,
    save_agent,
    save_scene,
    save_session_token,
)
from .lanes.secondme_ai import LANE_NAME as SECONDME_AI_LANE
from .lanes.secondme_ai import resolve_runtime_context, secondme_ai_lane_enabled
from .sse_consumer import AuthError as SSEAuthError
from .sse_consumer import SSEError, consume_sse_stream

logger = logging.getLogger(__name__)
P = ParamSpec("P")

_BASE_INSTRUCTIONS = """\
Towow (通爻) is an agent collaboration protocol. It connects agents who can help \
each other — not by searching, but by mutual discovery and structured negotiation.

## Quick Start

If the user hasn't registered yet, help them get started:
1. **Register**: `towow_register` with an invite code, email, password, name, and a profile.
2. **Build a good profile**: The profile is how other agents discover you. Include:
   - Who you are (role, background, key skills)
   - What you're working on (current projects, goals)
   - What you need help with (specific needs, collaboration interests)
   - What you can offer others (expertise, resources, connections)
   A 3-5 paragraph profile works best. Vague profiles get poor matches.
3. **Describe the need**: Use `towow_formulation_start` / `towow_formulation_reply` when \
the need is still vague, or `towow_discover` directly when it is already clear.
4. **Start hosted negotiation**: Default to `towow_formulation_confirm(..., \
start_negotiation=true, k=3)` or `towow_discover(..., start_negotiation=true, k=3)`. \
This is the canonical happy path.
5. **Get results**: Hosted runs default to `worker_distributed`, so participants do not \
need to stay online. Use `towow_result` or `towow_inbox` after completion.
6. **Enable notifications if needed**: Use `towow_email_status` and \
`towow_email_verify_send` to verify the account email for result notifications.

## Typical Workflow

```
Register/Login → Build Profile → Describe Need → Discover
    → Hosted Negotiation (`worker_distributed`) → Result → Inbox → Email
```

### Formulation (Need Refinement)
When the user has a vague need, use `towow_formulation_start` to begin a structured \
conversation that refines it into a clear, matchable demand. The system will ask \
clarifying questions. Reply with `towow_formulation_reply` until the need is well-defined, \
then `towow_formulation_confirm` to trigger discovery. If the user wants the system \
to immediately start a hosted run, call it with `start_negotiation=true` and explicit `k`.

### Quick Discovery
For a clear, specific need, skip formulation and use `towow_discover` directly. \
If the user wants the full default path, also pass `start_negotiation=true` and `k`.

### Hosted Negotiation
Hosted runs are the default happy path. They return a canonical run payload directly \
from `towow_formulation_confirm` or `towow_discover` when `start_negotiation=true`. \
The default execution mode is `worker_distributed`.

### Inbox And Email
Inbox is a result center, not a chat system. Use `towow_inbox` to list result items, \
`towow_inbox_item` to open one, and `towow_inbox_mark_read` to mark it read. \
Use `towow_email_status` and `towow_email_verify_send` for email verification status.

### Legacy / Advanced Flow
Invitation-based tools remain available for compatibility and advanced flows:
`towow_invite`, `towow_invitations`, `towow_invitation_respond`, and `towow_negotiate`.
Do not default to them when the hosted path is sufficient.

## Profile Standards

A good profile should include:
- **Identity**: Name, role, organization (if any)
- **Expertise**: What you know well, what you've built
- **Current focus**: What you're working on now
- **Needs**: What kind of help or collaboration you're looking for
- **Offerings**: What you can contribute to others

You can update the profile anytime with `towow_update_profile`.

## About API Keys

All features work out of the box — no API key needed. The Towow server handles all \
LLM calls (formulation, discovery profile generation, negotiation synthesis) using its \
own infrastructure. Users just register, describe their need, and get results.

**BYOK (Bring Your Own Key)** is for a specific situation: if you hit the platform's \
hosted quota while starting a hosted negotiation, you can bind your own Anthropic API key \
with `towow_byok_bind` to bypass the limit. This is optional and most users will never \
need it. Check quota with `towow_usage`.

## Tips
- Use `towow_agents` to see all your agents and which one is selected.
- Each account can have multiple agents for different contexts.
- Use `towow_agent_delete` to clean up agents you no longer need.
- Use `towow_refresh_token` if your session is about to expire.
- Use `towow_result` or `towow_inbox` after a hosted run completes.
- Verify email before you rely on result notifications.
- Invitation tools are legacy / advanced flow; only use them when the user explicitly \
needs invitation-based coordination.
- After a run completes, use `towow_feedback` to rate the experience.
- Use `towow_get_formulation` to check formulation state without sending a message.
- Use `towow_get_discovery` to re-read previous discovery results.
"""


def _build_instructions() -> str:
    auth_lane = get_auth_lane()
    scene_id = get_scene_id()
    if not scene_id and auth_lane != SECONDME_AI_LANE:
        return _BASE_INSTRUCTIONS

    sections = [_BASE_INSTRUCTIONS]
    if auth_lane == SECONDME_AI_LANE:
        sections.append(
            "## SecondMe AI Lane\n\n"
            "- This shell is configured for the `secondme_ai` auth lane.\n"
            "- Use `towow_auth_begin` to start OAuth, or call a protected tool directly "
            "to receive an `AUTH_REQUIRED` challenge.\n"
        )
    if scene_id:
        scene_display_name = get_scene_display_name()
        scene_label = f"{scene_display_name} ({scene_id})" if scene_display_name else scene_id
        sections.append(
            "## Scene Default\n\n"
            f"- Current default scene: {scene_label}\n"
            "- `towow_formulation_start` will use this scene automatically unless the caller "
            "explicitly passes `scene_context`.\n"
        )
    return "\n\n".join(sections)


mcp = FastMCP("towow", instructions=_build_instructions())


def _get_client() -> TowowClient:
    return TowowClient()


def _require_auth() -> None:
    if not get_session_token():
        raise ToolError("Not logged in. Call towow_login or towow_register first.")


def _require_agent_id() -> str:
    agent_id = get_agent_id()
    if not agent_id:
        raise ToolError("No current agent selected. Call towow_agents or towow_agent_select first.")
    return agent_id


def _json(payload: dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False, default=str)


def _selected_agent_payload() -> dict[str, Any]:
    return {
        "agent_id": get_agent_id(),
        "display_name": get_display_name(),
    }


def _pick_agent_payload(agent: dict[str, Any]) -> dict[str, Any]:
    return {
        "agent_id": agent.get("agent_id"),
        "display_name": agent.get("display_name"),
        "visibility": agent.get("visibility"),
        "scoped_tags": agent.get("scoped_tags", []),
    }


def _resolve_scene_context(scene_context: str | None) -> str:
    return (scene_context or get_scene_id() or "startup-hub").strip()


async def _begin_secondme_ai_auth(
    *,
    scene_id: str | None = None,
    entry_surface: str | None = None,
    consumer_kind: str | None = None,
) -> dict[str, Any]:
    try:
        context = resolve_runtime_context(
            scene_id=scene_id,
            entry_surface=entry_surface,
            consumer_kind=consumer_kind,
        )
    except ValueError as exc:
        raise ToolError(str(exc)) from exc

    client = _get_client()
    try:
        return await client.create_consumer_auth_session(
            lane=SECONDME_AI_LANE,
            scene_id=context.scene_id,
            entry_surface=context.entry_surface,
            consumer_kind=context.consumer_kind,
        )
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()


def _with_auth_status_next_tool(payload: dict[str, Any]) -> dict[str, Any]:
    body = dict(payload)
    if body.get("status") == "completed":
        body["next_tool"] = "towow_auth_exchange"
    return body


async def _maybe_build_auth_required_payload() -> dict[str, Any] | None:
    if get_session_token() or not secondme_ai_lane_enabled():
        return None
    challenge = await _begin_secondme_ai_auth(
        scene_id=get_scene_id(),
        entry_surface=get_entry_surface(),
    )
    challenge["next_tool"] = "towow_auth_status"
    return challenge


def _protect_auth_tool(func: Callable[P, Awaitable[str]]) -> Callable[P, Awaitable[str]]:
    @wraps(func)
    async def wrapper(*args: P.args, **kwargs: P.kwargs) -> str:
        challenge = await _maybe_build_auth_required_payload()
        if challenge is not None:
            return _json(challenge)
        return await func(*args, **kwargs)

    return wrapper


async def _canonical_formulation_confirm(
    *,
    session_id: str,
    scope_tags: list[str] | None,
    max_candidates: int,
    start_negotiation: bool,
    k: int | None,
) -> dict[str, Any]:
    _require_auth()
    client = _get_client()
    try:
        confirmed = await client.confirm_formulation(
            session_id=session_id,
            scope_tags=scope_tags,
            max_candidates=max_candidates,
            start_negotiation=start_negotiation,
            k=k,
        )
        query_id = confirmed["query_id"]
        query = await client.get_discovery_query(query_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return {
        "session_id": session_id,
        "demand_id": confirmed.get("demand_id"),
        "query_id": query_id,
        "session": confirmed.get("session"),
        "query": query,
        "run": confirmed.get("run"),
        "selected_agent": _selected_agent_payload(),
    }


@mcp.tool()
async def towow_register(
    invite_code: str,
    email: str,
    password: str,
    name: str,
    profile_text: str,
) -> str:
    """Register a new Towow account and persist the returned session locally."""
    client = _get_client()
    try:
        result = await client.register(invite_code, email, password, name, profile_text)
    except AuthError as exc:
        raise ToolError(f"Registration failed: {exc}") from exc
    except APIError as exc:
        raise ToolError(f"Registration failed: {exc.detail}") from exc
    finally:
        await client.close()

    token = result.get("session_token")
    if token:
        save_session_token(token)
    default_agent_id = result.get("default_agent_id")
    if default_agent_id:
        save_agent(default_agent_id, result.get("name"))

    return _json(
        {
            "account_id": result.get("account_id"),
            "default_agent_id": default_agent_id,
            "email": result.get("email"),
            "name": result.get("name"),
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
async def towow_login(email: str, password: str) -> str:
    """Login to Towow and persist the returned session locally."""
    client = _get_client()
    try:
        result = await client.login(email, password)
    except AuthError as exc:
        raise ToolError(f"Login failed: {exc}") from exc
    except APIError as exc:
        raise ToolError(f"Login failed: {exc.detail}") from exc
    finally:
        await client.close()

    token = result.get("session_token")
    if token:
        save_session_token(token)
    default_agent_id = result.get("default_agent_id")
    if default_agent_id:
        save_agent(default_agent_id, result.get("name"))

    return _json(
        {
            "account_id": result.get("account_id"),
            "default_agent_id": default_agent_id,
            "email": result.get("email"),
            "name": result.get("name"),
            "expires_at": result.get("expires_at"),
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
async def towow_auth_begin(
    scene_id: str | None = None,
    entry_surface: str | None = None,
    consumer_kind: str | None = None,
) -> str:
    """Start the SecondMe AI consumer auth flow and return the browser challenge."""
    return _json(
        await _begin_secondme_ai_auth(
            scene_id=scene_id,
            entry_surface=entry_surface,
            consumer_kind=consumer_kind,
        )
    )


@mcp.tool()
async def towow_auth_status(auth_session_id: str) -> str:
    """Poll the status of a previously created AI consumer auth session."""
    client = _get_client()
    try:
        result = await client.get_consumer_auth_session_status(auth_session_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(_with_auth_status_next_tool(result))


@mcp.tool()
async def towow_auth_exchange(auth_session_id: str) -> str:
    """Exchange a completed auth session for local Towow credentials."""
    client = _get_client()
    try:
        result = await client.exchange_consumer_auth_session(auth_session_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    session_token = result.pop("session_token", None)
    if not session_token:
        raise ToolError("Consumer auth exchange did not return a session_token.")

    save_session_token(session_token)
    default_agent_id = result.get("default_agent_id")
    if default_agent_id:
        save_agent(default_agent_id, result.get("name"))
    scene_id = result.get("scene_id")
    if scene_id:
        save_scene(scene_id, display_name=None)

    result["selected_agent"] = _selected_agent_payload()
    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_agents() -> str:
    """List all agents owned by the current account and show the selected agent."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.list_agents()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "selected_agent": _selected_agent_payload(),
            "agents": [_pick_agent_payload(agent) for agent in result.get("agents", [])],
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_agent_create(
    display_name: str,
    profile_text: str,
    visibility: str = "scoped",
    scoped_tags: list[str] | None = None,
) -> str:
    """Create a new agent under the current account."""
    _require_auth()
    client = _get_client()
    try:
        agent = await client.create_agent(
            display_name=display_name,
            profile_text=profile_text,
            visibility=visibility,
            scoped_tags=scoped_tags,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "agent": _pick_agent_payload(agent),
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_agent_select(agent_id: str) -> str:
    """Select which owned agent subsequent MCP actions should use."""
    _require_auth()
    client = _get_client()
    try:
        agent = await client.get_agent(agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    save_agent(agent["agent_id"], agent.get("display_name"))
    return _json(
        {
            "selected_agent": _selected_agent_payload(),
            "agent": _pick_agent_payload(agent),
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_agent_set_visibility(visibility: str, agent_id: str | None = None) -> str:
    """Update the visibility policy for the selected agent or an explicitly supplied agent."""
    _require_auth()
    selected_agent_id = agent_id or _require_agent_id()
    client = _get_client()
    try:
        updated = await client.set_agent_visibility(selected_agent_id, visibility)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    if selected_agent_id == get_agent_id():
        save_agent(updated["agent_id"], updated.get("display_name"))
    return _json(
        {
            "agent": _pick_agent_payload(updated),
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
async def towow_set_scene(scene_id: str) -> str:
    """Persist the default scene used for future Towow scene-aware workflows."""
    client = _get_client()
    try:
        scene = await client.get_scene(scene_id)
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    save_scene(scene["scene_id"], scene.get("display_name"))
    return _json(
        {
            "scene": scene,
            "selected_scene": {
                "scene_id": scene["scene_id"],
                "display_name": scene.get("display_name"),
            },
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_formulation_start(raw_intent: str, scene_context: str | None = None) -> str:
    """Start a canonical formulation session for the selected agent."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()

    try:
        result = await client.create_formulation(
            agent_id=agent_id,
            raw_intent=raw_intent,
            scene_context=_resolve_scene_context(scene_context),
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "session_id": result["session"]["session_id"],
            "agent_id": result["session"]["agent_id"],
            "reply": result["assistant_reply"],
            "document": result["session"]["formulated_demand"],
            "updates": result["updates"],
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_formulation_reply(session_id: str, user_message: str) -> str:
    """Continue a formulation session and return the fully-consumed SSE result."""
    _require_auth()
    client = _get_client()
    try:
        resp = await client.formulation_reply_stream(session_id, user_message)
        full_text, updates = await consume_sse_stream(resp)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except (SSEError, SSEAuthError) as exc:
        raise ToolError(f"Formulation error: {exc}") from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    client = _get_client()
    try:
        updated_session = await client.get_formulation(session_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "session_id": session_id,
            "reply": full_text,
            "document": updated_session.get("formulated_demand", ""),
            "updates": updates,
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
@_protect_auth_tool
async def towow_formulation_confirm(
    session_id: str,
    scope_tags: list[str] | None = None,
    max_candidates: int = 10,
    start_negotiation: bool = False,
    k: int | None = None,
) -> str:
    """Confirm a formulation session, execute discovery, and optionally start the hosted run happy path."""
    return _json(
        await _canonical_formulation_confirm(
            session_id=session_id,
            scope_tags=scope_tags,
            max_candidates=max_candidates,
            start_negotiation=start_negotiation,
            k=k,
        )
    )


@mcp.tool()
@_protect_auth_tool
async def towow_discover(
    demand_text: str,
    scope_tags: list[str] | None = None,
    scene_context: str | None = None,
    max_candidates: int = 10,
    start_negotiation: bool = False,
    k: int | None = None,
) -> str:
    """Run an ad-hoc discovery query and optionally start hosted negotiation immediately."""
    _require_auth()
    requester = _require_agent_id()
    client = _get_client()
    try:
        result = await client.discover(
            requester=requester,
            demand_text=demand_text,
            scope_tags=scope_tags,
            scene_context=_resolve_scene_context(scene_context),
            max_candidates=max_candidates,
            start_negotiation=start_negotiation,
            k=k,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_invite(nomination_id: str, expires_in_hours: int = 24) -> str:
    """Create a legacy / advanced-flow invitation from a nomination."""
    _require_auth()
    inviter = _require_agent_id()
    client = _get_client()
    try:
        invitation = await client.create_invitation(
            inviter=inviter,
            nomination_id=nomination_id,
            expires_in_hours=expires_in_hours,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(invitation)


@mcp.tool()
@_protect_auth_tool
async def towow_invitations(agent_id: str | None = None) -> str:
    """List legacy / advanced-flow invitations visible to the selected or supplied owned agent."""
    _require_auth()
    current_agent_id = agent_id or _require_agent_id()
    client = _get_client()
    try:
        result = await client.list_invitations(agent_id=current_agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_invitation_respond(invitation_id: str, action: str) -> str:
    """Accept or decline a legacy / advanced-flow invitation as the selected agent."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        invitation = await client.respond_invitation(invitation_id, agent_id=agent_id, action=action)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(invitation)


@mcp.tool()
@_protect_auth_tool
async def towow_negotiate(invitation_ids: list[str], max_rounds: int = 4) -> str:
    """Create a legacy / advanced-flow invitation-based run from accepted invitations."""
    _require_auth()
    initiator = _require_agent_id()
    client = _get_client()
    try:
        result = await client.create_run(
            initiator=initiator,
            invitation_ids=invitation_ids,
            max_rounds=max_rounds,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_run_status(run_id: str) -> str:
    """Fetch the current canonical run status."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_run(run_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_run_prompt(run_id: str) -> str:
    """Fetch the current round prompt for the selected agent in participant-distributed or legacy runs."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.get_run_prompt(run_id, agent_id=agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_run_respond(
    run_id: str,
    round_number: int,
    content: str,
    metadata: dict[str, Any] | None = None,
) -> str:
    """Submit a participant response for the selected agent in participant-distributed or legacy runs."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.respond_run(
            run_id,
            agent_id=agent_id,
            round_number=round_number,
            content=content,
            metadata=metadata,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_result(run_id: str) -> str:
    """Fetch the final result view for the selected agent."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.get_run_result(run_id, agent_id=agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_inbox() -> str:
    """List inbox result items for the current account."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.list_inbox()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_inbox_item(item_id: str) -> str:
    """Open a single inbox result item."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_inbox_item(item_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_inbox_mark_read(item_id: str) -> str:
    """Mark an inbox result item as read."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.mark_inbox_item_read(item_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_email_status() -> str:
    """Read account email verification status for result notifications."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_account()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    data["selected_agent"] = _selected_agent_payload()
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_email_verify_send() -> str:
    """Send an email verification link for result notifications."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.request_email_verification()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    data["selected_agent"] = _selected_agent_payload()
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_send_message(receiver_agent_id: str, source_run_id: str, content: str) -> str:
    """Send a post-run message to another agent you collaborated with."""
    _require_auth()
    sender_agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.send_message(
            sender_agent_id=sender_agent_id,
            receiver_agent_id=receiver_agent_id,
            source_run_id=source_run_id,
            content=content,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_conversations(limit: int = 20) -> str:
    """List your post-run conversations."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.list_conversations(limit=limit)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_conversation_messages(conversation_id: str, since_seq: int = 0) -> str:
    """Read messages in a post-run conversation."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_conversation_messages(conversation_id, since_seq=since_seq)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_feedback(
    target_type: str,
    target_id: str,
    exposure_event_id: str,
    rating: int,
    comment: str | None = None,
) -> str:
    """Submit canonical feedback for the selected agent."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.submit_feedback(
            agent_id=agent_id,
            target_type=target_type,
            target_id=target_id,
            exposure_event_id=exposure_event_id,
            rating=rating,
            comment=comment,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_usage(period: str = "month") -> str:
    """Fetch usage stats for the selected agent and owning account."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.get_usage(period=period, agent_id=agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_update_profile(
    profile_text: str | None = None,
    display_name: str | None = None,
    scoped_tags: list[str] | None = None,
    capability_manifest: dict | None = None,
) -> str:
    """Update the selected agent. Supports profile_text, display_name, scoped_tags, and capability_manifest."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.update_agent(
            agent_id,
            display_name=display_name,
            profile_text=profile_text,
            scoped_tags=scoped_tags,
            capability_manifest=capability_manifest,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    if agent_id == get_agent_id():
        save_agent(agent_id, data.get("display_name"))
    return _json({"agent": _pick_agent_payload(data), "selected_agent": _selected_agent_payload()})


@mcp.tool()
@_protect_auth_tool
async def towow_agent_delete(agent_id: str) -> str:
    """Delete an agent owned by the current account."""
    _require_auth()
    client = _get_client()
    try:
        await client.delete_agent(agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    if agent_id == get_agent_id():
        clear_agent()
    return _json({"ok": True, "deleted_agent_id": agent_id})


@mcp.tool()
@_protect_auth_tool
async def towow_refresh_token() -> str:
    """Refresh the session token before it expires."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.refresh_token()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    new_token = result.get("session_token")
    if new_token:
        save_session_token(new_token)
    return _json({"ok": True, "expires_at": result.get("expires_at")})


@mcp.tool()
@_protect_auth_tool
async def towow_byok_bind(api_key: str, provider: str = "anthropic") -> str:
    """Bind your own LLM API key to bypass free quota limits. Optional — all features work without this."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.bind_byok(api_key, provider)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_byok_status() -> str:
    """Check if a BYOK (Bring Your Own Key) session is active."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.get_byok()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_byok_clear() -> str:
    """Remove the BYOK API key binding."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.clear_byok()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
@_protect_auth_tool
async def towow_get_formulation(session_id: str) -> str:
    """Get the current state of a formulation session without sending a message."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_formulation(session_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_get_invitation(invitation_id: str) -> str:
    """Get details of a specific invitation."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_invitation(invitation_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_get_discovery(query_id: str) -> str:
    """Retrieve results from a previously completed discovery query."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_discovery_query(query_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_demand_confirm(
    session_id: str,
    scope_tags: list[str] | None = None,
    max_candidates: int = 10,
    start_negotiation: bool = False,
    k: int | None = None,
) -> str:
    """Deprecated alias for `towow_formulation_confirm`. Prefer the canonical tool name."""
    payload = await _canonical_formulation_confirm(
        session_id=session_id,
        scope_tags=scope_tags,
        max_candidates=max_candidates,
        start_negotiation=start_negotiation,
        k=k,
    )
    payload["deprecated_tool"] = "towow_demand_confirm"
    payload["replacement"] = "towow_formulation_confirm"
    return _json(payload)


@mcp.tool()
@_protect_auth_tool
async def towow_run_start(invitation_ids: list[str], max_rounds: int = 4) -> str:
    """Deprecated alias for `towow_negotiate`. Prefer the canonical tool name."""
    data = json.loads(await towow_negotiate(invitation_ids=invitation_ids, max_rounds=max_rounds))
    data["deprecated_tool"] = "towow_run_start"
    data["replacement"] = "towow_negotiate"
    return _json(data)


@mcp.tool()
@_protect_auth_tool
async def towow_run_result(run_id: str) -> str:
    """Deprecated alias for `towow_result`. Prefer the canonical tool name."""
    data = json.loads(await towow_result(run_id))
    data["deprecated_tool"] = "towow_run_result"
    data["replacement"] = "towow_result"
    return _json(data)


@mcp.tool()
async def towow_logout() -> str:
    """Clear the local MCP session context after best-effort remote logout."""
    token = get_session_token()
    if token:
        client = _get_client()
        try:
            await client.logout()
        except (AuthError, APIError):
            logger.debug("Ignoring remote logout failure during MCP local logout.", exc_info=True)
        finally:
            await client.close()
    clear_session_token()
    clear_agent()
    return _json({"ok": True})


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
