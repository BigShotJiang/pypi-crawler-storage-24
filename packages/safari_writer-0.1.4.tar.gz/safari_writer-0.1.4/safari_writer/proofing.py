"""Reusable proofing helpers for TUI and CLI flows."""

from __future__ import annotations

import re
from pathlib import Path
from typing import cast

from safari_writer.typed import SpellChecker, WordMatch

_CTRL_CHARS = re.compile(r"[\x01-\x1f]")

__all__ = [
    "check_word",
    "dict_lookup",
    "extract_words",
    "load_personal_dictionary",
    "make_checker",
    "suggest_words",
]


def make_checker(lang: str | None = None) -> SpellChecker | None:
    """Return an enchant dictionary for *lang*, defaulting to the OS locale.

    Falls back to the bare language code (e.g. ``'de'``) if the full tag
    (e.g. ``'de_DE'``) is not available.
    """
    from safari_writer.locale_info import LANGUAGE, LOCALE

    lang = lang or LOCALE
    try:
        import enchant

        try:
            return cast(SpellChecker, enchant.Dict(lang))
        except enchant.DictNotFoundError:
            # Try bare language code
            bare = lang.split("_")[0] if "_" in lang else LANGUAGE
            return cast(SpellChecker, enchant.Dict(bare))
    except Exception:
        return None


def check_word(
    word: str,
    checker: SpellChecker | None,
    kept: set[str],
    personal: set[str],
) -> bool:
    """Return True if word is correctly spelled."""

    stripped = word.strip(".,;:!?\"'()-")
    if not stripped or not stripped[0].isalpha():
        return True
    lowered = stripped.lower()
    if lowered in kept or lowered in personal:
        return True
    if checker is None:
        return True
    return checker.check(stripped)


def suggest_words(word: str, checker: SpellChecker | None) -> list[str]:
    """Return candidate spellings for a word."""

    if checker is None:
        return []
    try:
        return checker.suggest(word)[:18]
    except Exception:
        return []


def dict_lookup(prefix: str, checker: SpellChecker | None) -> tuple[bool, list[str]]:
    """Look up a word/prefix in the dictionary.

    Returns (exact_match, suggestions) where *exact_match* is True when
    the prefix itself is a recognized word and *suggestions* contains
    related words from the dictionary (up to 126).
    """

    if checker is None or len(prefix) < 2:
        return False, []
    exact = checker.check(prefix)
    try:
        suggestions = checker.suggest(prefix)
    except Exception:
        suggestions = []
    # Remove the exact word from suggestions to avoid duplication
    lower_prefix = prefix.lower()
    suggestions = [w for w in suggestions if w.lower() != lower_prefix]
    return exact, suggestions[:126]


def extract_words(buffer: list[str]) -> list[WordMatch]:
    """Yield (row, col, word) for every word token in the buffer."""

    word_re = re.compile(r"[A-Za-z']+")
    results: list[WordMatch] = []
    for row, line in enumerate(buffer):
        clean = _CTRL_CHARS.sub(" ", line)
        for match in word_re.finditer(clean):
            results.append((row, match.start(), match.group()))
    return results


def load_personal_dictionary(path: Path, encoding: str = "utf-8") -> set[str]:
    """Load personal-dictionary words from disk."""

    text = path.read_text(encoding=encoding)
    words = re.split(r"[\s\n]+", text.strip().lower())
    return {word for word in words if word}
