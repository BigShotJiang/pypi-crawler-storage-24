# paperclip-sdk

Public Python SDK for calling Paperclip remote functions.

## Install

```bash
poetry add paperclip-sdk
```

or

```bash
pip install paperclip-sdk
```

## Configure authentication

```bash
export LEASEKEY_API_KEY="your-api-key"
```

## Usage

```python
from paperclip_sdk import PaperclipClient

with PaperclipClient(base_url="https://leasekey.org") as client:
    result = client.call("core.hello_world", name="Ada")
    print(result)
```
