# src/paperclip_sdk/client.py

import logging
import os
import random
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Any, Protocol

import httpx

DEFAULT_BASE_URL = "https://leasekey.org"
API_KEY_ENV_VAR = "LEASEKEY_API_KEY"
RPC_RUN_PATH = "/rpc/run"
_DEBUG_HANDLER_NAME = "paperclip-sdk-client-debug-handler"

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    max_attempts: int = 5
    initial_backoff: float = 0.25
    max_backoff: float = 8.0
    backoff_multiplier: float = 2.0
    retryable_status_codes: frozenset[int] = field(
        default_factory=lambda: frozenset({408, 425, 429, 502, 503, 504})
    )

    def validate(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("RetryPolicy.max_attempts must be >= 1")
        if self.initial_backoff < 0:
            raise ValueError("RetryPolicy.initial_backoff must be >= 0")
        if self.max_backoff < 0:
            raise ValueError("RetryPolicy.max_backoff must be >= 0")
        if self.backoff_multiplier < 1:
            raise ValueError("RetryPolicy.backoff_multiplier must be >= 1")
        if self.max_backoff < self.initial_backoff:
            raise ValueError("RetryPolicy.max_backoff must be >= initial_backoff")


class PaperclipClientError(RuntimeError):
    pass


class HttpClientProtocol(Protocol):
    def post(
        self,
        url: str,
        *,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        ...

    def close(self) -> None:
        ...


def _extract_error_message(response: httpx.Response) -> str:
    try:
        data = response.json()
    except ValueError:
        return response.text

    detail = data.get("detail")
    if isinstance(detail, str):
        return detail

    return response.text


def _parse_retry_after(response: httpx.Response, *, max_delay: float) -> float | None:
    retry_after = response.headers.get("Retry-After")
    if not retry_after:
        return None

    retry_after = retry_after.strip()

    try:
        seconds = float(retry_after)
        return max(0.0, min(seconds, max_delay))
    except ValueError:
        pass

    try:
        retry_at = parsedate_to_datetime(retry_after)
        if retry_at.tzinfo is None:
            retry_at = retry_at.replace(tzinfo=timezone.utc)

        seconds = (retry_at - datetime.now(timezone.utc)).total_seconds()
        return max(0.0, min(seconds, max_delay))
    except (TypeError, ValueError, OverflowError):
        return None


def _to_ms(seconds: float) -> float:
    return round(seconds * 1000.0, 2)


def _configure_default_client_debug_logger(client_logger: logging.Logger) -> None:
    client_logger.setLevel(logging.DEBUG)
    client_logger.propagate = False

    for handler in client_logger.handlers:
        if handler.get_name() == _DEBUG_HANDLER_NAME:
            return

    handler = logging.StreamHandler()
    handler.set_name(_DEBUG_HANDLER_NAME)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    )
    client_logger.addHandler(handler)


class RemoteFunction:
    def __init__(self, client: "PaperclipClient", name: str) -> None:
        self._client = client
        self.name = name

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._client.call(self.name, *args, **kwargs)


class PaperclipClient:
    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
        http_client: HttpClientProtocol | None = None,
        retry_policy: RetryPolicy | None = None,
        client_logger: logging.Logger | None = None,
        log_server_meta: bool = False,
        debug: bool = False,
    ) -> None:
        self._owns_http_client = http_client is None
        self._retry_policy = retry_policy or RetryPolicy()
        self._retry_policy.validate()
        self._random = random.Random()
        self._sleep = time.sleep
        self._logger = client_logger or logger
        self._log_server_meta = log_server_meta

        if debug:
            if client_logger is None:
                _configure_default_client_debug_logger(self._logger)
            else:
                self._logger.setLevel(logging.DEBUG)

        if http_client is not None:
            self._http_client = http_client
            return

        resolved_base_url = f"{(base_url or DEFAULT_BASE_URL).rstrip('/')}/"
        resolved_api_key = api_key if api_key is not None else os.getenv(API_KEY_ENV_VAR)

        headers = {"Content-Type": "application/json"}
        if resolved_api_key:
            headers["Authorization"] = f"Bearer {resolved_api_key}"

        self._http_client = httpx.Client(
            base_url=resolved_base_url,
            timeout=timeout,
            headers=headers,
        )

    def _build_request_headers(self, request_id: str) -> dict[str, str]:
        return {
            "Idempotency-Key": request_id,
            "X-Paperclip-Request-Id": request_id,
            "X-Leasekey-Request-Id": request_id,
        }

    def _build_payload(
        self,
        function_name: str,
        request_id: str,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> dict[str, Any]:
        return {
            "function": function_name,
            "args": list(args),
            "kwargs": kwargs,
            "request_id": request_id,
        }

    def _post_rpc(
        self,
        payload: dict[str, Any],
        request_id: str,
    ) -> httpx.Response:
        return self._http_client.post(
            RPC_RUN_PATH,
            json=payload,
            headers=self._build_request_headers(request_id),
        )

    def _parse_response_json(
        self,
        response: httpx.Response,
        *,
        function_name: str,
        request_id: str,
        attempt: int,
        max_attempts: int,
        started_at: float,
    ) -> dict[str, Any]:
        try:
            data = response.json()
        except ValueError as exc:
            total_duration = time.perf_counter() - started_at
            self._logger.error(
                "Paperclip RPC invalid JSON response function=%s request_id=%s attempt=%d/%d status_code=%d total_duration_ms=%.2f",
                function_name,
                request_id,
                attempt,
                max_attempts,
                response.status_code,
                _to_ms(total_duration),
            )
            raise PaperclipClientError(
                "Invalid JSON response from Paperclip RPC server"
            ) from exc

        if not isinstance(data, dict):
            raise PaperclipClientError("Invalid RPC response payload")
        return data

    def _extract_result_from_response(
        self,
        data: dict[str, Any],
        *,
        function_name: str,
    ) -> Any:
        if not data.get("ok"):
            raise PaperclipClientError(f"RPC call failed: {function_name}")
        return data.get("result")

    def _should_retry_response(self, response: httpx.Response, attempt: int) -> bool:
        if attempt >= self._retry_policy.max_attempts:
            return False

        return response.status_code in self._retry_policy.retryable_status_codes

    def _should_retry_connect_error(self, attempt: int) -> bool:
        return attempt < self._retry_policy.max_attempts

    def _compute_retry_delay(
        self,
        attempt: int,
        response: httpx.Response | None = None,
    ) -> float:
        if response is not None:
            retry_after_delay = _parse_retry_after(
                response,
                max_delay=self._retry_policy.max_backoff,
            )
            if retry_after_delay is not None:
                return retry_after_delay

        cap = min(
            self._retry_policy.max_backoff,
            self._retry_policy.initial_backoff
            * (self._retry_policy.backoff_multiplier ** (attempt - 1))
        )
        return self._random.uniform(0.0, cap)

    def _get_base_url_for_logging(self) -> str:
        base_url = getattr(self._http_client, "base_url", None)
        if base_url is None:
            return "custom-http-client"
        return str(base_url)

    def _debug_log_server_meta(
        self,
        function_name: str,
        request_id: str,
        meta: Any,
    ) -> None:
        if not self._log_server_meta:
            return
        if not self._logger.isEnabledFor(logging.DEBUG):
            return
        if not isinstance(meta, dict):
            return

        self._logger.debug(
            "Paperclip RPC server meta function=%s request_id=%s server_request_id=%s handler_duration_ms=%s server_duration_ms=%s",
            function_name,
            request_id,
            meta.get("request_id"),
            meta.get("handler_duration_ms"),
            meta.get("server_duration_ms"),
        )

    def call(self, function_name: str, *args: Any, **kwargs: Any) -> Any:
        request_id = uuid.uuid4().hex
        max_attempts = self._retry_policy.max_attempts
        started_at = time.perf_counter()
        payload = self._build_payload(function_name, request_id, args, kwargs)

        self._logger.debug(
            "Paperclip RPC call started function=%s request_id=%s max_attempts=%d base_url=%s",
            function_name,
            request_id,
            max_attempts,
            self._get_base_url_for_logging(),
        )

        for attempt in range(1, max_attempts + 1):
            attempt_started_at = time.perf_counter()

            self._logger.debug(
                "Paperclip RPC attempt started function=%s request_id=%s attempt=%d/%d args_count=%d kwargs_keys=%s",
                function_name,
                request_id,
                attempt,
                max_attempts,
                len(args),
                sorted(kwargs.keys()),
            )

            try:
                response = self._post_rpc(payload, request_id)
                request_duration = time.perf_counter() - attempt_started_at

                self._logger.debug(
                    "Paperclip RPC response received function=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f",
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    _to_ms(request_duration),
                )

                response.raise_for_status()

                parse_started_at = time.perf_counter()
                data = self._parse_response_json(
                    response,
                    function_name=function_name,
                    request_id=request_id,
                    attempt=attempt,
                    max_attempts=max_attempts,
                    started_at=started_at,
                )
                parse_duration = time.perf_counter() - parse_started_at

                result = self._extract_result_from_response(
                    data,
                    function_name=function_name,
                )

                self._debug_log_server_meta(
                    function_name=function_name,
                    request_id=request_id,
                    meta=data.get("meta"),
                )

                attempt_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at
                self._logger.debug(
                    "Paperclip RPC call succeeded function=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f parse_duration_ms=%.2f attempt_duration_ms=%.2f total_duration_ms=%.2f",
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    _to_ms(request_duration),
                    _to_ms(parse_duration),
                    _to_ms(attempt_duration),
                    _to_ms(total_duration),
                )
                return result

            except PaperclipClientError:
                raise

            except httpx.HTTPStatusError as exc:
                response = exc.response
                request_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at
                error_message = _extract_error_message(response)

                if not self._should_retry_response(response, attempt):
                    self._logger.error(
                        "Paperclip RPC HTTP failure function=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f total_duration_ms=%.2f detail=%s",
                        function_name,
                        request_id,
                        attempt,
                        max_attempts,
                        response.status_code,
                        _to_ms(request_duration),
                        _to_ms(total_duration),
                        error_message,
                    )
                    raise PaperclipClientError(error_message) from exc

                retry_delay = self._compute_retry_delay(attempt, response=response)
                self._logger.warning(
                    "Paperclip RPC retry scheduled function=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f total_duration_ms=%.2f retry_delay_ms=%.2f detail=%s",
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    _to_ms(request_duration),
                    _to_ms(total_duration),
                    _to_ms(retry_delay),
                    error_message,
                )
                if retry_delay > 0:
                    self._sleep(retry_delay)

            except (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout) as exc:
                request_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at

                if not self._should_retry_connect_error(attempt):
                    self._logger.error(
                        "Paperclip RPC transport failure function=%s request_id=%s attempt=%d/%d error_type=%s request_duration_ms=%.2f total_duration_ms=%.2f error=%s",
                        function_name,
                        request_id,
                        attempt,
                        max_attempts,
                        exc.__class__.__name__,
                        _to_ms(request_duration),
                        _to_ms(total_duration),
                        str(exc),
                    )
                    raise PaperclipClientError(str(exc)) from exc

                retry_delay = self._compute_retry_delay(attempt)
                self._logger.warning(
                    "Paperclip RPC transport retry scheduled function=%s request_id=%s attempt=%d/%d error_type=%s request_duration_ms=%.2f total_duration_ms=%.2f retry_delay_ms=%.2f error=%s",
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    exc.__class__.__name__,
                    _to_ms(request_duration),
                    _to_ms(total_duration),
                    _to_ms(retry_delay),
                    str(exc),
                )
                if retry_delay > 0:
                    self._sleep(retry_delay)

            except httpx.RequestError as exc:
                total_duration = time.perf_counter() - started_at
                self._logger.error(
                    "Paperclip RPC non-retryable request failure function=%s request_id=%s attempt=%d/%d error_type=%s total_duration_ms=%.2f error=%s",
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    exc.__class__.__name__,
                    _to_ms(total_duration),
                    str(exc),
                )
                raise PaperclipClientError(str(exc)) from exc

        total_duration = time.perf_counter() - started_at
        self._logger.error(
            "Paperclip RPC exhausted retries function=%s request_id=%s max_attempts=%d total_duration_ms=%.2f",
            function_name,
            request_id,
            max_attempts,
            _to_ms(total_duration),
        )
        raise PaperclipClientError(f"RPC call failed after retries: {function_name}")

    def run(self, function_name: str, *args: Any, **kwargs: Any) -> Any:
        return self.call(function_name, *args, **kwargs)

    def function(self, name: str) -> RemoteFunction:
        return RemoteFunction(self, name)

    def close(self) -> None:
        if self._owns_http_client:
            self._http_client.close()

    def __enter__(self) -> "PaperclipClient":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()


__all__ = [
    "API_KEY_ENV_VAR",
    "DEFAULT_BASE_URL",
    "RPC_RUN_PATH",
    "RetryPolicy",
    "PaperclipClient",
    "PaperclipClientError",
]
