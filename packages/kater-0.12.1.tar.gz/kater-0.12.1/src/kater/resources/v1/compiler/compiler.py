# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional

import httpx

from .manifest import (
    ManifestResource,
    AsyncManifestResource,
    ManifestResourceWithRawResponse,
    AsyncManifestResourceWithRawResponse,
    ManifestResourceWithStreamingResponse,
    AsyncManifestResourceWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ...._utils import maybe_transform, strip_not_given, async_maybe_transform
from ...._compat import cached_property
from ....types.v1 import (
    compiler_compile_params,
    compiler_execute_params,
    compiler_resolve_params,
    compiler_validate_params,
    compiler_enumerate_params,
    compiler_compile_dashboard_params,
)
from .combination import (
    CombinationResource,
    AsyncCombinationResource,
    CombinationResourceWithRawResponse,
    AsyncCombinationResourceWithRawResponse,
    CombinationResourceWithStreamingResponse,
    AsyncCombinationResourceWithStreamingResponse,
)
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.v1.compiler_compile_response import CompilerCompileResponse
from ....types.v1.compiler_execute_response import CompilerExecuteResponse
from ....types.v1.compiler_resolve_response import CompilerResolveResponse
from ....types.v1.compiler_validate_response import CompilerValidateResponse
from ....types.v1.compiler_enumerate_response import CompilerEnumerateResponse
from ....types.v1.compiler_compile_dashboard_response import CompilerCompileDashboardResponse

__all__ = ["CompilerResource", "AsyncCompilerResource"]


class CompilerResource(SyncAPIResource):
    """Validate, resolve, and compile query templates to SQL"""

    @cached_property
    def combination(self) -> CombinationResource:
        """Validate, resolve, and compile query templates to SQL"""
        return CombinationResource(self._client)

    @cached_property
    def manifest(self) -> ManifestResource:
        """Validate, resolve, and compile query templates to SQL"""
        return ManifestResource(self._client)

    @cached_property
    def with_raw_response(self) -> CompilerResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/kater-ai/kater-python-sdk#accessing-raw-response-data-eg-headers
        """
        return CompilerResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CompilerResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/kater-ai/kater-python-sdk#with_streaming_response
        """
        return CompilerResourceWithStreamingResponse(self)

    def compile(
        self,
        *,
        connection_id: str,
        resolved_query: compiler_compile_params.ResolvedQuery,
        tenant_key: str,
        source: Optional[str] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerCompileResponse:
        """
        Compile a resolved query to SQL.

        Takes a previously resolved query and generates the final SQL statement for the
        target dialect.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          connection_id: Connection to compile against

          resolved_query: Previously resolved query object from /resolve

          tenant_key: Tenant key for multi-tenant compilation. Use 'kater_global_tenant' for
              no-tenancy clients or to bypass tenant isolation. For database tenancy, maps to
              the tenant's database. For row tenancy, used as the row-level filter value.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return self._post(
            "/api/v1/compiler/compile",
            body=maybe_transform(
                {
                    "connection_id": connection_id,
                    "resolved_query": resolved_query,
                    "tenant_key": tenant_key,
                },
                compiler_compile_params.CompilerCompileParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"source": source}, compiler_compile_params.CompilerCompileParams),
            ),
            cast_to=CompilerCompileResponse,
        )

    def compile_dashboard(
        self,
        *,
        connection_id: str,
        dashboard_path: str,
        tenant_key: str,
        source: Optional[str] | Omit = omit,
        filters: Optional[Dict[str, Union[str, SequenceNotStr[str], None]]] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerCompileDashboardResponse:
        """
        Compile a dashboard YAML file into fully resolved widget data.

        Reads a dashboard YAML from the client repo, resolves all data slots, executes
        queries, applies filters, and returns renderable widget data.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          connection_id: Connection to compile against

          dashboard_path: Relative path within the connection (e.g. 'dashboards/compliance_overview')

          tenant_key: Tenant key for multi-tenant execution. Use 'kater_global_tenant' for no-tenancy
              clients.

          filters: Optional filter overrides from UI

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return self._post(
            "/api/v1/compiler/dashboard",
            body=maybe_transform(
                {
                    "connection_id": connection_id,
                    "dashboard_path": dashboard_path,
                    "tenant_key": tenant_key,
                    "filters": filters,
                },
                compiler_compile_dashboard_params.CompilerCompileDashboardParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"source": source}, compiler_compile_dashboard_params.CompilerCompileDashboardParams
                ),
            ),
            cast_to=CompilerCompileDashboardResponse,
        )

    def enumerate(
        self,
        *,
        connection_id: str,
        tenant_key: str,
        source: Optional[str] | Omit = omit,
        query_ids: Optional[SequenceNotStr[str]] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerEnumerateResponse:
        """
        Enumerate every valid query configuration for a connection.

        Generates all valid combinations of optional dimensions, measures, calculations,
        filters, and variable values, constrained by widget category rules.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          connection_id: Connection to enumerate against

          tenant_key: Tenant key for multi-tenant clients. Use 'kater_global_tenant' for no-tenancy
              clients or when no tenant isolation is needed.

          query_ids: Optional query UUIDs to limit enumeration. If omitted, enumerates all queries.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return self._post(
            "/api/v1/compiler/enumerate",
            body=maybe_transform(
                {
                    "connection_id": connection_id,
                    "tenant_key": tenant_key,
                    "query_ids": query_ids,
                },
                compiler_enumerate_params.CompilerEnumerateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"source": source}, compiler_enumerate_params.CompilerEnumerateParams),
            ),
            cast_to=CompilerEnumerateResponse,
        )

    def execute(
        self,
        *,
        connection_id: str,
        resolved_query: compiler_execute_params.ResolvedQuery,
        tenant_key: str,
        source: Optional[str] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerExecuteResponse:
        """
        Execute a query with transparent caching.

        Compiles the resolved query to SQL, checks the cache for existing results,
        executes against the warehouse on cache miss, and stores the result for future
        requests. Cache failures are invisible to the caller.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          connection_id: Connection to execute against

          resolved_query: Previously resolved query object from /resolve

          tenant_key: Tenant key for multi-tenant execution. Use 'kater_global_tenant' for no-tenancy
              clients.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return self._post(
            "/api/v1/compiler/execute",
            body=maybe_transform(
                {
                    "connection_id": connection_id,
                    "resolved_query": resolved_query,
                    "tenant_key": tenant_key,
                },
                compiler_execute_params.CompilerExecuteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"source": source}, compiler_execute_params.CompilerExecuteParams),
            ),
            cast_to=CompilerExecuteResponse,
        )

    def resolve(
        self,
        *,
        connection_id: str,
        query_id: str,
        source: Optional[str] | Omit = omit,
        auto_fix: bool | Omit = omit,
        combination: str | Omit = omit,
        pinned_variant: Optional[str] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerResolveResponse:
        """
        Resolve a query template with user-selected parameters.

        Takes a query reference and variable selections, returns the fully resolved
        query object ready for compilation.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          connection_id: Connection to resolve against

          query_id: UUID of the query template

          auto_fix: Automatically fix broken refs caused by renames. Defaults to True.

          combination:
              Comma-separated slot selections and variable assignments. Reserved keys:
              measure, dimension, filter, calculation. All other keys are variable
              assignments. Example: 'measure=Compliance
              Rate,dimension=Department,breakdown=region'

          pinned_variant: Optional pinned variant name (e.g. '\\__base'). Selects a specific pinned
              configuration.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return self._post(
            "/api/v1/compiler/resolve",
            body=maybe_transform(
                {
                    "connection_id": connection_id,
                    "query_id": query_id,
                    "auto_fix": auto_fix,
                    "combination": combination,
                    "pinned_variant": pinned_variant,
                },
                compiler_resolve_params.CompilerResolveParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"source": source}, compiler_resolve_params.CompilerResolveParams),
            ),
            cast_to=CompilerResolveResponse,
        )

    def validate(
        self,
        *,
        source: Optional[str] | Omit = omit,
        auto_fix: bool | Omit = omit,
        connection_ids: Optional[SequenceNotStr[str]] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerValidateResponse:
        """
        Validate a schema file set against a connection.

        Checks all views, queries, and related schemas for correctness and returns any
        errors or warnings found.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          auto_fix: Automatically fix broken refs caused by renames. Defaults to True.

          connection_ids: Optional connection IDs to validate. If omitted, validates all connections.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return self._post(
            "/api/v1/compiler/validate",
            body=maybe_transform(
                {
                    "auto_fix": auto_fix,
                    "connection_ids": connection_ids,
                },
                compiler_validate_params.CompilerValidateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"source": source}, compiler_validate_params.CompilerValidateParams),
            ),
            cast_to=CompilerValidateResponse,
        )


class AsyncCompilerResource(AsyncAPIResource):
    """Validate, resolve, and compile query templates to SQL"""

    @cached_property
    def combination(self) -> AsyncCombinationResource:
        """Validate, resolve, and compile query templates to SQL"""
        return AsyncCombinationResource(self._client)

    @cached_property
    def manifest(self) -> AsyncManifestResource:
        """Validate, resolve, and compile query templates to SQL"""
        return AsyncManifestResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncCompilerResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/kater-ai/kater-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncCompilerResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCompilerResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/kater-ai/kater-python-sdk#with_streaming_response
        """
        return AsyncCompilerResourceWithStreamingResponse(self)

    async def compile(
        self,
        *,
        connection_id: str,
        resolved_query: compiler_compile_params.ResolvedQuery,
        tenant_key: str,
        source: Optional[str] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerCompileResponse:
        """
        Compile a resolved query to SQL.

        Takes a previously resolved query and generates the final SQL statement for the
        target dialect.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          connection_id: Connection to compile against

          resolved_query: Previously resolved query object from /resolve

          tenant_key: Tenant key for multi-tenant compilation. Use 'kater_global_tenant' for
              no-tenancy clients or to bypass tenant isolation. For database tenancy, maps to
              the tenant's database. For row tenancy, used as the row-level filter value.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return await self._post(
            "/api/v1/compiler/compile",
            body=await async_maybe_transform(
                {
                    "connection_id": connection_id,
                    "resolved_query": resolved_query,
                    "tenant_key": tenant_key,
                },
                compiler_compile_params.CompilerCompileParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"source": source}, compiler_compile_params.CompilerCompileParams),
            ),
            cast_to=CompilerCompileResponse,
        )

    async def compile_dashboard(
        self,
        *,
        connection_id: str,
        dashboard_path: str,
        tenant_key: str,
        source: Optional[str] | Omit = omit,
        filters: Optional[Dict[str, Union[str, SequenceNotStr[str], None]]] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerCompileDashboardResponse:
        """
        Compile a dashboard YAML file into fully resolved widget data.

        Reads a dashboard YAML from the client repo, resolves all data slots, executes
        queries, applies filters, and returns renderable widget data.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          connection_id: Connection to compile against

          dashboard_path: Relative path within the connection (e.g. 'dashboards/compliance_overview')

          tenant_key: Tenant key for multi-tenant execution. Use 'kater_global_tenant' for no-tenancy
              clients.

          filters: Optional filter overrides from UI

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return await self._post(
            "/api/v1/compiler/dashboard",
            body=await async_maybe_transform(
                {
                    "connection_id": connection_id,
                    "dashboard_path": dashboard_path,
                    "tenant_key": tenant_key,
                    "filters": filters,
                },
                compiler_compile_dashboard_params.CompilerCompileDashboardParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"source": source}, compiler_compile_dashboard_params.CompilerCompileDashboardParams
                ),
            ),
            cast_to=CompilerCompileDashboardResponse,
        )

    async def enumerate(
        self,
        *,
        connection_id: str,
        tenant_key: str,
        source: Optional[str] | Omit = omit,
        query_ids: Optional[SequenceNotStr[str]] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerEnumerateResponse:
        """
        Enumerate every valid query configuration for a connection.

        Generates all valid combinations of optional dimensions, measures, calculations,
        filters, and variable values, constrained by widget category rules.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          connection_id: Connection to enumerate against

          tenant_key: Tenant key for multi-tenant clients. Use 'kater_global_tenant' for no-tenancy
              clients or when no tenant isolation is needed.

          query_ids: Optional query UUIDs to limit enumeration. If omitted, enumerates all queries.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return await self._post(
            "/api/v1/compiler/enumerate",
            body=await async_maybe_transform(
                {
                    "connection_id": connection_id,
                    "tenant_key": tenant_key,
                    "query_ids": query_ids,
                },
                compiler_enumerate_params.CompilerEnumerateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"source": source}, compiler_enumerate_params.CompilerEnumerateParams
                ),
            ),
            cast_to=CompilerEnumerateResponse,
        )

    async def execute(
        self,
        *,
        connection_id: str,
        resolved_query: compiler_execute_params.ResolvedQuery,
        tenant_key: str,
        source: Optional[str] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerExecuteResponse:
        """
        Execute a query with transparent caching.

        Compiles the resolved query to SQL, checks the cache for existing results,
        executes against the warehouse on cache miss, and stores the result for future
        requests. Cache failures are invisible to the caller.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          connection_id: Connection to execute against

          resolved_query: Previously resolved query object from /resolve

          tenant_key: Tenant key for multi-tenant execution. Use 'kater_global_tenant' for no-tenancy
              clients.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return await self._post(
            "/api/v1/compiler/execute",
            body=await async_maybe_transform(
                {
                    "connection_id": connection_id,
                    "resolved_query": resolved_query,
                    "tenant_key": tenant_key,
                },
                compiler_execute_params.CompilerExecuteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"source": source}, compiler_execute_params.CompilerExecuteParams),
            ),
            cast_to=CompilerExecuteResponse,
        )

    async def resolve(
        self,
        *,
        connection_id: str,
        query_id: str,
        source: Optional[str] | Omit = omit,
        auto_fix: bool | Omit = omit,
        combination: str | Omit = omit,
        pinned_variant: Optional[str] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerResolveResponse:
        """
        Resolve a query template with user-selected parameters.

        Takes a query reference and variable selections, returns the fully resolved
        query object ready for compilation.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          connection_id: Connection to resolve against

          query_id: UUID of the query template

          auto_fix: Automatically fix broken refs caused by renames. Defaults to True.

          combination:
              Comma-separated slot selections and variable assignments. Reserved keys:
              measure, dimension, filter, calculation. All other keys are variable
              assignments. Example: 'measure=Compliance
              Rate,dimension=Department,breakdown=region'

          pinned_variant: Optional pinned variant name (e.g. '\\__base'). Selects a specific pinned
              configuration.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return await self._post(
            "/api/v1/compiler/resolve",
            body=await async_maybe_transform(
                {
                    "connection_id": connection_id,
                    "query_id": query_id,
                    "auto_fix": auto_fix,
                    "combination": combination,
                    "pinned_variant": pinned_variant,
                },
                compiler_resolve_params.CompilerResolveParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"source": source}, compiler_resolve_params.CompilerResolveParams),
            ),
            cast_to=CompilerResolveResponse,
        )

    async def validate(
        self,
        *,
        source: Optional[str] | Omit = omit,
        auto_fix: bool | Omit = omit,
        connection_ids: Optional[SequenceNotStr[str]] | Omit = omit,
        x_kater_cli_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompilerValidateResponse:
        """
        Validate a schema file set against a connection.

        Checks all views, queries, and related schemas for correctness and returns any
        errors or warnings found.

        RLS: Filtered to current client (ClientRLSDB).

        Args:
          auto_fix: Automatically fix broken refs caused by renames. Defaults to True.

          connection_ids: Optional connection IDs to validate. If omitted, validates all connections.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"X-Kater-CLI-ID": x_kater_cli_id}), **(extra_headers or {})}
        return await self._post(
            "/api/v1/compiler/validate",
            body=await async_maybe_transform(
                {
                    "auto_fix": auto_fix,
                    "connection_ids": connection_ids,
                },
                compiler_validate_params.CompilerValidateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"source": source}, compiler_validate_params.CompilerValidateParams),
            ),
            cast_to=CompilerValidateResponse,
        )


class CompilerResourceWithRawResponse:
    def __init__(self, compiler: CompilerResource) -> None:
        self._compiler = compiler

        self.compile = to_raw_response_wrapper(
            compiler.compile,
        )
        self.compile_dashboard = to_raw_response_wrapper(
            compiler.compile_dashboard,
        )
        self.enumerate = to_raw_response_wrapper(
            compiler.enumerate,
        )
        self.execute = to_raw_response_wrapper(
            compiler.execute,
        )
        self.resolve = to_raw_response_wrapper(
            compiler.resolve,
        )
        self.validate = to_raw_response_wrapper(
            compiler.validate,
        )

    @cached_property
    def combination(self) -> CombinationResourceWithRawResponse:
        """Validate, resolve, and compile query templates to SQL"""
        return CombinationResourceWithRawResponse(self._compiler.combination)

    @cached_property
    def manifest(self) -> ManifestResourceWithRawResponse:
        """Validate, resolve, and compile query templates to SQL"""
        return ManifestResourceWithRawResponse(self._compiler.manifest)


class AsyncCompilerResourceWithRawResponse:
    def __init__(self, compiler: AsyncCompilerResource) -> None:
        self._compiler = compiler

        self.compile = async_to_raw_response_wrapper(
            compiler.compile,
        )
        self.compile_dashboard = async_to_raw_response_wrapper(
            compiler.compile_dashboard,
        )
        self.enumerate = async_to_raw_response_wrapper(
            compiler.enumerate,
        )
        self.execute = async_to_raw_response_wrapper(
            compiler.execute,
        )
        self.resolve = async_to_raw_response_wrapper(
            compiler.resolve,
        )
        self.validate = async_to_raw_response_wrapper(
            compiler.validate,
        )

    @cached_property
    def combination(self) -> AsyncCombinationResourceWithRawResponse:
        """Validate, resolve, and compile query templates to SQL"""
        return AsyncCombinationResourceWithRawResponse(self._compiler.combination)

    @cached_property
    def manifest(self) -> AsyncManifestResourceWithRawResponse:
        """Validate, resolve, and compile query templates to SQL"""
        return AsyncManifestResourceWithRawResponse(self._compiler.manifest)


class CompilerResourceWithStreamingResponse:
    def __init__(self, compiler: CompilerResource) -> None:
        self._compiler = compiler

        self.compile = to_streamed_response_wrapper(
            compiler.compile,
        )
        self.compile_dashboard = to_streamed_response_wrapper(
            compiler.compile_dashboard,
        )
        self.enumerate = to_streamed_response_wrapper(
            compiler.enumerate,
        )
        self.execute = to_streamed_response_wrapper(
            compiler.execute,
        )
        self.resolve = to_streamed_response_wrapper(
            compiler.resolve,
        )
        self.validate = to_streamed_response_wrapper(
            compiler.validate,
        )

    @cached_property
    def combination(self) -> CombinationResourceWithStreamingResponse:
        """Validate, resolve, and compile query templates to SQL"""
        return CombinationResourceWithStreamingResponse(self._compiler.combination)

    @cached_property
    def manifest(self) -> ManifestResourceWithStreamingResponse:
        """Validate, resolve, and compile query templates to SQL"""
        return ManifestResourceWithStreamingResponse(self._compiler.manifest)


class AsyncCompilerResourceWithStreamingResponse:
    def __init__(self, compiler: AsyncCompilerResource) -> None:
        self._compiler = compiler

        self.compile = async_to_streamed_response_wrapper(
            compiler.compile,
        )
        self.compile_dashboard = async_to_streamed_response_wrapper(
            compiler.compile_dashboard,
        )
        self.enumerate = async_to_streamed_response_wrapper(
            compiler.enumerate,
        )
        self.execute = async_to_streamed_response_wrapper(
            compiler.execute,
        )
        self.resolve = async_to_streamed_response_wrapper(
            compiler.resolve,
        )
        self.validate = async_to_streamed_response_wrapper(
            compiler.validate,
        )

    @cached_property
    def combination(self) -> AsyncCombinationResourceWithStreamingResponse:
        """Validate, resolve, and compile query templates to SQL"""
        return AsyncCombinationResourceWithStreamingResponse(self._compiler.combination)

    @cached_property
    def manifest(self) -> AsyncManifestResourceWithStreamingResponse:
        """Validate, resolve, and compile query templates to SQL"""
        return AsyncManifestResourceWithStreamingResponse(self._compiler.manifest)
