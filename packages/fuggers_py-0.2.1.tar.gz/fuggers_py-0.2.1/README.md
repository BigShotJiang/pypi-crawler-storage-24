# fuggers-py

`fuggers-py` is a Python library for fixed-income pricing, spread, risk, and portfolio calculations. It includes bond, curve, rates, funding, credit, inflation, and portfolio packages that you can use directly from scripts or notebooks. Coverage is broad, but not complete; model-heavy paths are checked against small saved reference cases, and the docs call out the limits that still matter.

## Install

```bash
pip install fuggers-py
pip install "fuggers-py[dev]"
pip install "fuggers-py[engine]"
pip install "fuggers-py[examples]"
```

## Units And Quoting

- Rates and spreads are usually raw decimals, so `0.045` means 4.5%.
- Bond clean and dirty prices are usually quoted in percent of par, so `101.25` means 101.25% of face value.
- Accrued interest, coupon cash, repo cash, and PV outputs are currency amounts unless the API says otherwise.
- Settlement dates are economic settlement dates used for accrual, discounting, and pricing.
- `DiscountMarginCalculator` applies DM as a continuously compounded spread over ACT/365 settlement-to-cash-flow times.
- `OASCalculator` prices callable bonds with call schedules only and rejects puttable bonds.

## Fixed-Income Example

```python
from decimal import Decimal

from fuggers_py.analytics import calculate_modified_duration, yield_to_maturity
from fuggers_py.analytics.yields import current_yield_from_bond
from fuggers_py.bonds import FixedBondBuilder
from fuggers_py.core import Currency, Date, Frequency, Price

settlement = Date.from_ymd(2026, 1, 15)
clean_price = Decimal("101.25")
bond = (
    FixedBondBuilder.new()
    .with_issue_date(Date.from_ymd(2024, 1, 15))
    .with_maturity_date(Date.from_ymd(2031, 1, 15))
    .with_coupon_rate(Decimal("0.0450"))
    .with_frequency(Frequency.SEMI_ANNUAL)
    .with_currency(Currency.USD)
    .build()
)
price = Price.new(clean_price, Currency.USD)

ytm = yield_to_maturity(bond, price, settlement)
duration = calculate_modified_duration(bond, ytm, settlement)
current_yield = current_yield_from_bond(bond, clean_price)

assert ytm.value() > Decimal("0")
assert duration > 0
assert current_yield > Decimal("0")
```

## Curve And Engine Example

```python
from decimal import Decimal

from fuggers_py.core import Date
from fuggers_py.curves import DiscountCurveBuilder, ForwardCurve
from fuggers_py.data import MarketDataProvider, ReferenceDataProvider
from fuggers_py.engine import PricingEngineBuilder

settlement = Date.from_ymd(2026, 3, 13)
curve = (
    DiscountCurveBuilder(reference_date=settlement)
    .add_zero_rate(1.0, Decimal("0.0350"))
    .add_zero_rate(5.0, Decimal("0.0385"))
    .build()
)
forward_curve = ForwardCurve.from_months(curve, 3)
engine = (
    PricingEngineBuilder.new()
    .with_market_data_provider(MarketDataProvider())
    .with_reference_data_provider(ReferenceDataProvider())
    .with_settlement_date(settlement)
    .build()
)

assert curve.discount_factor(settlement.add_years(5)) > 0
assert forward_curve.forward_rate_at(1.0) > 0
assert engine.reactive_engine is not None
assert engine.pricing_router is not None
```

## More Docs

- [Core](docs/CORE_DOCS.md), [Math](docs/MATH_DOCS.md), [Curves](docs/CURVES_DOCS.md), [Bonds](docs/BONDS_DOCS.md), and [Analytics](docs/ANALYTICS_DOCS.md)
- [Rates](docs/RATES_DOCS.md), [Funding](docs/FUNDING_DOCS.md), [Credit](docs/CREDIT_DOCS.md), [Inflation](docs/INFLATION_DOCS.md), and [Portfolio](docs/PORTFOLIO_DOCS.md)
- [Data](docs/DATA_DOCS.md), [I/O](docs/IO_DOCS.md), [Engine](docs/ENGINE_DOCS.md), [Testing](docs/testing.md), [Examples](examples/README.md), and [Releasing](RELEASING.md)

## Tests

```bash
python -m pip install -e ".[dev,engine]"
pytest -q
```
