# Testing

## What Is Tested?

- Unit tests cover bond builders, pricing helpers, curve builders, spread and yield functions, portfolio calculations, and engine plumbing.
- Smoke tests run selected code blocks from the public docs and run every example script in `examples/`.
- Packaging tests check builds, installs, version metadata, and optional dependency paths.

## What Is Reference-Checked?

- `tests/validation/` loads JSON and CSV fixtures for exact or tight-tolerance checks on bond, curve, portfolio, and engine behavior.
- A legacy test file loads a saved JSON file of golden reference cases.
- These checks focus on a small set of fixed-rate, callable, floating-rate, curve, and portfolio cases that are useful for catching regressions.

## Where Model Differences Still Remain

- Callable OAS depends on the Hull-White tree setup and exercise rule, so small differences against other systems are still possible even when the input data matches.
- FRN discount margin depends on projected coupons, fixings, and the library's DM convention: a continuously compounded spread over ACT/365 settlement-to-cash-flow times.
- Some portfolio and engine tests use small synthetic data sets. They check the code path and units, not every market rule you might need in production.

## How To Add Cases

- Add a unit test next to the module when you change a formula or fix a bug.
- Add or update a fixture under `tests/fixtures/validation/` when the expected output should stay stable over time.
- If you update the golden JSON file, record why the values changed so the next reader can tell the difference between a bug fix and a model change.
