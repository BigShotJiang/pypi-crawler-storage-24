# Engine

## What Is In This Package?

`fuggers_py.engine` contains synchronous pricing routers, a calculation graph, market-data listeners, schedulers, and a builder that wires the pieces together.

## Main Objects And Functions

- `PricingRouter` and `PricingInput`
- `CalculationGraph`, `NodeId`, and `NodeUpdate`
- `MarketDataListener` and `MarketDataPublisher`
- `IntervalScheduler`, `EodScheduler`, and `CronScheduler`
- `PricingEngineBuilder` and `PricingEngine`

## Example

```python
from fuggers_py.core import Date
from fuggers_py.data import MarketDataProvider, ReferenceDataProvider
from fuggers_py.engine import PricingEngineBuilder

engine = (
    PricingEngineBuilder.new()
    .with_market_data_provider(MarketDataProvider())
    .with_reference_data_provider(ReferenceDataProvider())
    .with_settlement_date(Date.from_ymd(2026, 1, 15))
    .build()
)

assert engine.reactive_engine is not None
assert engine.settlement_date == Date.from_ymd(2026, 1, 15)
assert engine.pricing_router is not None
```

```python
from fuggers_py.engine import CalculationGraph, NodeId

graph = CalculationGraph()
quote_node = NodeId("quote:US91282CJN6")
price_node = NodeId("price:US91282CJN6")
graph.add_dependency(price_node, quote_node)
graph.update_node_value(quote_node, {"mid": 101.25})

assert graph.dependencies(price_node) == (quote_node,)
assert graph.get_node_value(quote_node) is not None
```

```python
from fuggers_py.engine import IntervalScheduler, NodeId

scheduler = IntervalScheduler([NodeId("curve:usd.discount")], interval_seconds=60.0)

assert scheduler.node_ids[0].as_str() == "curve:usd.discount"
assert scheduler.interval_seconds == 60.0
```

```python
from fuggers_py.engine import CalculationGraph, MarketDataListener, NodeId

graph = CalculationGraph()
graph.add_dependency(NodeId("price:US91282CJN6"), NodeId("quote:US91282CJN6"))
listener = MarketDataListener(calc_graph=graph)

assert listener.quote_node_id("US91282CJN6").as_str() == "quote:US91282CJN6"
assert graph.dependencies("price:US91282CJN6") == (NodeId("quote:US91282CJN6"),)
```

## Conventions And Limitations

- The synchronous router is the simplest entry point if you only need a price or a batch of prices.
- The reactive pieces are optional; you do not need them to use the pricing code.
- Funding and rates products keep their own routers instead of being folded into the bond router.
- `CronScheduler` requires the optional `engine` extra because it depends on `croniter`.
