# Core

## What Is In This Package?

`fuggers_py.core` holds the shared date, price, yield, calendar, day-count, and error types used across the library.

## Main Objects And Functions

- `Date`, `Price`, `Yield`, `Currency`, and `Frequency`
- Day-count classes such as `Act360`, `Act365Fixed`, and `Thirty360US`
- Calendars such as `SIFMACalendar`, `Target2Calendar`, `UKCalendar`, and `USGovernmentCalendar`
- Base interfaces and common error types

## Example

```python
from decimal import Decimal

from fuggers_py.core import Compounding, Currency, Date, Price, Yield

settlement = Date.from_ymd(2026, 1, 15)
clean_price = Price.new(Decimal("99.125"), Currency.USD)
ytm = Yield.new(Decimal("0.0415"), Compounding.SEMI_ANNUAL)

assert clean_price.as_percentage() == Decimal("99.125")
assert settlement.days_between(Date.from_ymd(2026, 1, 16)) == 1
assert ytm.as_percentage() == Decimal("4.1500")
```

## Conventions And Limitations

- `Price` values are percent-of-par values unless another type says otherwise.
- Rates and spreads are raw decimals unless a function says it returns percent or basis points.
- If you need a market calendar that is not built in, add a custom calendar instead of hardcoding date exceptions in analytics code.
