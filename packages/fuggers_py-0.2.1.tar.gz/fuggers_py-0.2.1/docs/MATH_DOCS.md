# Math

## What Is In This Package?

`fuggers_py.math` contains the numerical tools used by curves, pricing, and analytics code.

## Main Objects And Functions

- Root finders such as `brent`, `newton_raphson`, and `secant`
- Interpolators such as `LinearInterpolator`, `LogLinearInterpolator`, `CubicSpline`, and `MonotoneConvex`
- Extrapolators such as `FlatExtrapolator` and `LinearExtrapolator`
- Small linear algebra and optimization helpers

## Example

```python
from fuggers_py.math import brent, newton_raphson

result = brent(lambda x: x * x - 2.0, 0.0, 2.0)
newton = newton_raphson(lambda x: x * x - 2.0, lambda x: 2.0 * x, 1.0)

assert abs(result.root - 2 ** 0.5) < 1e-10
assert abs(newton.root - result.root) < 1e-10
```

## Conventions And Limitations

- Most helpers work with Python floats and return float-based results.
- Tolerances are absolute unless a function says otherwise.
- Use these helpers through `fuggers_py.math` instead of reaching into private modules from business logic.
