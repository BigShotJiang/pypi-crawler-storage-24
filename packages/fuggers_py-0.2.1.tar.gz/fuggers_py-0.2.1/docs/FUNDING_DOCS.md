# Funding

## What Is In This Package?

`fuggers_py.funding` contains repo trades, repo curves, and small carry and implied-repo helpers.

## Main Objects And Functions

- `RepoTrade` and `RepoCurve`
- `implied_repo_rate` and `implied_repo_rate_from_trade`
- `repo_financing_cost`, `repo_carry_return`, and `repo_net_carry`
- `haircut_amount` and `haircut_drag`

## Example

```python
from decimal import Decimal

from fuggers_py.core import Date
from fuggers_py.funding import implied_repo_rate

rate = implied_repo_rate(
    spot_price=Decimal("99.50"),
    futures_price=Decimal("100.10"),
    conversion_factor=Decimal("0.95"),
    start_date=Date.from_ymd(2026, 1, 15),
    end_date=Date.from_ymd(2026, 3, 15),
    coupon_income=Decimal("0.50"),
)

assert rate.is_finite()
assert rate != Decimal("0")
```

## Conventions And Limitations

- Repo rates and haircuts are raw decimals.
- Bond and futures prices stay in percent-of-par.
- The package expects explicit trade inputs. It does not build market data for you.
