# I/O

## What Is In This Package?

`fuggers_py.io` contains file loaders, JSON codecs, SQLite-backed stores, and storage and transport interfaces.

## Main Objects And Functions

- File loaders such as `CSVQuoteSource`, `CSVIndexFixingSource`, and `JSONCurveInputSource`
- `JsonCodec` and `PrettyJsonCodec`
- In-memory and SQLite stores
- Storage and transport interfaces used by the engine package

## Example

```python
from fuggers_py.io import JsonCodec, PrettyJsonCodec

codec = JsonCodec()
payload = codec.encode({"curve": "usd.discount", "nodes": 2, "pillars": [1, 5]})
decoded = codec.decode(payload)
pretty = PrettyJsonCodec().encode({"curve": "usd.discount"})

assert decoded["curve"] == "usd.discount"
assert decoded["pillars"] == [1, 5]
assert b"\n" in pretty
```

## Conventions And Limitations

- The I/O package handles persistence and transport, not market conventions.
- File loaders return typed records from `fuggers_py.data`.
- SQLite support is intended for local storage and testable tools, not as a replacement for a full market data platform.
