# Data

## What Is In This Package?

`fuggers_py.data` contains typed identifiers, market-data records, reference-data records, pricing specs, and output records.

## Main Objects And Functions

- Identifiers such as `InstrumentId`, `CurveId`, `PortfolioId`, and `VolSurfaceId`
- Market-data records such as `RawQuote`, `CurveInputs`, `CurvePoint`, and fixing records
- Reference-data records such as `BondReferenceData`, `SwapReferenceData`, and `RepoReferenceData`
- `PricingSpec` and `AnalyticsCurves`
- Output records such as `BondQuoteOutput`

## Example

```python
from decimal import Decimal

from fuggers_py.core import Date
from fuggers_py.data import CurveInputs, CurvePoint, PricingSpec, RawQuote

curve_inputs = CurveInputs.from_points(
    "usd.discount",
    Date.from_ymd(2026, 1, 15),
    [CurvePoint(Decimal("1.0"), Decimal("0.0350")), CurvePoint(Decimal("5.0"), Decimal("0.0385"))],
)
quote = RawQuote(instrument_id="US91282CJN6", value=Decimal("101.25"))
spec = PricingSpec()

assert len(curve_inputs.points) == 2
assert curve_inputs.points[0].tenor == Decimal("1.0")
assert quote.quoted_value() == Decimal("101.25")
assert spec.compute_spreads is True
```

## Conventions And Limitations

- These records are plain typed containers. They do not price instruments by themselves.
- Provider objects return `None` or empty tuples when a source is missing; they do not invent fallback data.
- Storage and transport code lives in `fuggers_py.io`, not here.
