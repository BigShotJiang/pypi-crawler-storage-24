# Inflation

## What Is In This Package?

`fuggers_py.inflation` contains CPI conventions, reference-index helpers, inflation curve tools, and a few linker and breakeven helpers.

## Main Objects And Functions

- `USD_CPI_U_NSA`
- `reference_cpi` and `reference_index_ratio`
- `InflationIndexCurve` and `bootstrap_inflation_curve`
- `breakeven_inflation_rate` and `nominal_real_yield_basis`

## Example

```python
from decimal import Decimal

from fuggers_py.inflation import breakeven_inflation_rate, nominal_real_yield_basis

breakeven = breakeven_inflation_rate(
    nominal_yield=Decimal("0.0450"),
    real_yield=Decimal("0.0175"),
)
basis = nominal_real_yield_basis(
    nominal_yield=Decimal("0.0450"),
    real_yield=Decimal("0.0175"),
)

assert breakeven > Decimal("0")
assert basis == Decimal("0.0275")
```

## Conventions And Limitations

- The current implementation is centered on USD CPI-U NSA.
- CPI levels and index ratios are stored as raw `Decimal` values.
- The package handles reference CPI, simple inflation curves, and swap inputs, but it does not cover seasonality, YoY swaps, or inflation options.
