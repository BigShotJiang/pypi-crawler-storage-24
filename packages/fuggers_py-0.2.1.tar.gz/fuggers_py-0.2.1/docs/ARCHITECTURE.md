# Architecture

## What Is In This Repo?

The repo is split by domain package. `core` and `math` hold shared types and numerical helpers, `bonds` and `curves` hold instrument and term-structure code, `analytics` and `portfolio` build on those packages, and `data`, `io`, and `engine` handle records, persistence, and routed pricing.

## Main Packages

- `fuggers_py.core` and `fuggers_py.math`
- `fuggers_py.bonds`, `fuggers_py.curves`, `fuggers_py.rates`, `fuggers_py.funding`, `fuggers_py.credit`, and `fuggers_py.inflation`
- `fuggers_py.analytics` and `fuggers_py.portfolio`
- `fuggers_py.data`, `fuggers_py.io`, and `fuggers_py.engine`

## Example

```python
from decimal import Decimal

from fuggers_py.analytics import yield_to_maturity
from fuggers_py.bonds import FixedBondBuilder
from fuggers_py.core import Currency, Date, Frequency, Price
from fuggers_py.curves import DiscountCurveBuilder

bond = (
    FixedBondBuilder.new()
    .with_issue_date(Date.from_ymd(2024, 1, 15))
    .with_maturity_date(Date.from_ymd(2029, 1, 15))
    .with_coupon_rate(Decimal("0.04"))
    .with_frequency(Frequency.SEMI_ANNUAL)
    .with_currency(Currency.USD)
    .build()
)
curve = (
    DiscountCurveBuilder(reference_date=Date.from_ymd(2026, 1, 15))
    .add_zero_rate(1.0, Decimal("0.0350"))
    .add_zero_rate(5.0, Decimal("0.0380"))
    .build()
)

ytm = yield_to_maturity(bond, Price.new(Decimal("99.5"), Currency.USD), Date.from_ymd(2026, 1, 15))
assert ytm.value() > Decimal("0")
assert curve.discount_factor(Date.from_ymd(2027, 1, 15)) > 0
```

## Conventions And Limitations

- Most business logic lives in the domain packages, not in the root package.
- The engine package builds on the lower packages; it does not replace them.
- A few areas are intentionally narrow today, such as puttable-bond OAS support and non-USD inflation coverage.
