# Curves

## What Is In This Package?

`fuggers_py.curves` contains discount and credit curves, builders, calibration code, bumping tools, and multicurve helpers.

## Main Objects And Functions

- `DiscountCurveBuilder`, `ZeroCurveBuilder`, `ForwardCurve`, and `ValueConverter`
- Calibration tools such as `SequentialBootstrapper`, `PiecewiseBootstrapper`, and `GlobalFitter`
- Bumping tools such as `ParallelBump`, `KeyRateBump`, and `Scenario`
- Multicurve helpers such as `MultiCurveEnvironmentBuilder`
- Fitted bond curve tools for cross-sectional fair-value work

## Example

```python
from decimal import Decimal

from fuggers_py.core import Date
from fuggers_py.curves import DiscountCurveBuilder, ForwardCurve

curve = (
    DiscountCurveBuilder(reference_date=Date.from_ymd(2026, 1, 15))
    .add_zero_rate(1.0, Decimal("0.0350"))
    .add_zero_rate(5.0, Decimal("0.0385"))
    .build()
)
forward_curve = ForwardCurve.from_months(curve, 3)

assert curve.discount_factor(Date.from_ymd(2027, 1, 15)) > 0
assert curve.discount_factor(Date.from_ymd(2027, 1, 15)) < 1
assert forward_curve.forward_rate_at(1.0) > 0
```

## Conventions And Limitations

- Tenors are expressed in years.
- Zero rates, forward rates, and spreads are raw decimals.
- Fitted bond tools are useful for fair-value and ranking work, but they are not a market data system by themselves.
- Shadow-rate and jump-diffusion curve wrappers are optional tools, not part of the default bootstrap path.
