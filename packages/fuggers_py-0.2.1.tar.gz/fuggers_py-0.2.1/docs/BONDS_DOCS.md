# Bonds

## What Is In This Package?

`fuggers_py.bonds` contains bond instruments, schedules, conventions, accrued-interest rules, and bond-specific pricing helpers.

## Main Objects And Functions

- `FixedBondBuilder`, `FloatingRateNoteBuilder`, and `CallableBondBuilder`
- `ZeroCouponBond`, `TipsBond`, and sinking-fund bond types
- Cash-flow and accrued-interest helpers
- Yield and bond-pricing helpers

## Example

```python
from decimal import Decimal

from fuggers_py.bonds import FixedBondBuilder
from fuggers_py.core import Date, Frequency

bond = (
    FixedBondBuilder.new()
    .with_issue_date(Date.from_ymd(2024, 1, 15))
    .with_maturity_date(Date.from_ymd(2031, 1, 15))
    .with_coupon_rate(Decimal("0.0450"))
    .with_frequency(Frequency.SEMI_ANNUAL)
    .build()
)

flows = bond.cash_flows()
accrued = bond.accrued_interest(Date.from_ymd(2026, 4, 15))

assert flows[0].is_coupon()
assert flows[-1].is_principal()
assert accrued > Decimal("0")
```

## Conventions And Limitations

- Clean and dirty prices are usually percent-of-par.
- Accrued interest and coupon cash flows are currency amounts.
- Floating-rate notes keep fixings and projected coupon paths explicit; they do not hide missing data behind a fallback market data service.
- Callable and puttable cash-flow structures are available here, but the OAS helper in `fuggers_py.analytics` currently handles call schedules only.
