# Analytics

## What Is In This Package?

`fuggers_py.analytics` contains yield, spread, risk, pricing, and YAS-style helpers that sit on top of bond and curve objects.

## Main Objects And Functions

- `yield_to_maturity`, `calculate_modified_duration`, `dv01`, and `convexity`
- `ZSpreadCalculator`, `DiscountMarginCalculator`, and `OASCalculator`
- Money-market, current-yield, and short-date helpers
- YAS-style reporting helpers and small option-greeks helpers
- Relative-value utilities for bond ranking and trade construction

## Example

```python
from decimal import Decimal

from fuggers_py.analytics import calculate_modified_duration, yield_to_maturity
from fuggers_py.analytics.yields import current_yield_from_bond
from fuggers_py.bonds import FixedBondBuilder
from fuggers_py.core import Currency, Date, Frequency, Price

settlement = Date.from_ymd(2026, 1, 15)
clean_price = Decimal("101.25")
bond = (
    FixedBondBuilder.new()
    .with_issue_date(Date.from_ymd(2024, 1, 15))
    .with_maturity_date(Date.from_ymd(2031, 1, 15))
    .with_coupon_rate(Decimal("0.0450"))
    .with_frequency(Frequency.SEMI_ANNUAL)
    .with_currency(Currency.USD)
    .build()
)
price = Price.new(clean_price, Currency.USD)

ytm = yield_to_maturity(bond, price, settlement)
duration = calculate_modified_duration(bond, ytm, settlement)
current_yield = current_yield_from_bond(bond, clean_price)

assert ytm.value() > Decimal("0")
assert duration > 0
assert current_yield > Decimal("0")
```

## Conventions And Limitations

- Bond price inputs are usually percent-of-par.
- Yields and spreads are usually raw decimals unless a helper says it returns percent or basis points.
- `money_market_yield*` helpers return quoted percentage yields.
- `DiscountMarginCalculator.price_with_dm()` returns dirty price in percent-of-par and uses a continuously compounded DM spread over ACT/365 times.
- `OASCalculator` rejects puttable bonds instead of ignoring the put schedule.
