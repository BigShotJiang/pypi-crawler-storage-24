# Rates

## What Is In This Package?

`fuggers_py.rates` contains swaps, FRAs, basis swaps, inflation swaps, government-bond-futures helpers, rates-option formulas, and pricers.

## Main Objects And Functions

- `FixedFloatSwap`, `Ois`, `Fra`, `BasisSwap`, and `CrossCurrencyBasisSwap`
- `GovernmentBondFuture` and futures invoice helpers
- `SwapPricer`, `FraPricer`, `BasisSwapPricer`, and `CrossCurrencyBasisSwapPricer`
- `black76_formula`, `BachelierPricer`, and `HullWhiteOptionPricer`

## Example

```python
from decimal import Decimal

from fuggers_py.rates import OptionType, black76_formula

result = black76_formula(
    forward=Decimal("0.035"),
    strike=Decimal("0.03"),
    volatility=Decimal("0.20"),
    expiry_years=Decimal("1.0"),
    option_type=OptionType.CALL,
)

assert result.present_value > Decimal("0")
assert result.time_value > Decimal("0")
assert result.greeks.delta > Decimal("0")
```

## Conventions And Limitations

- Rates, spreads, and volatilities are raw decimals unless a function says otherwise.
- Bond-futures prices and invoice-style bond inputs are percent-of-par.
- PV outputs are currency amounts.
- Pricers need explicit curve inputs. They do not fetch or infer missing market data.
