# Credit

## What Is In This Package?

`fuggers_py.credit` contains CDS instruments, CDS pricing, CDS curve bootstrapping, and a few cash-bond-versus-CDS helpers.

## Main Objects And Functions

- `Cds` and `ProtectionSide`
- `CdsPricer`
- `bootstrap_credit_curve`
- `bond_cds_basis` and `adjusted_cds_spread`

## Example

```python
from decimal import Decimal

from fuggers_py.credit import adjusted_cds_spread, bond_cds_basis

basis = bond_cds_basis(
    bond_spread=Decimal("0.0150"),
    cds_spread=Decimal("0.0125"),
)
adjusted = adjusted_cds_spread(
    quoted_spread=Decimal("0.0130"),
    delivery_option_adjustment=Decimal("0.0005"),
)

assert basis == Decimal("0.0025")
assert adjusted == Decimal("0.0125")
```

## Conventions And Limitations

- CDS spreads and rates are raw decimals.
- The package is CDS-focused. It does not try to model the full cash-credit market.
- Bond-versus-CDS helpers are explicit arithmetic breakdowns, not a full joint calibration framework.
