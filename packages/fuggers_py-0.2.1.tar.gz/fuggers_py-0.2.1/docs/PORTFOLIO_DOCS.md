# Portfolio

## What Is In This Package?

`fuggers_py.portfolio` contains holdings, portfolio containers, aggregate analytics, bucketing, attribution, benchmark comparison, ETF helpers, and stress tools.

## Main Objects And Functions

- `Holding`, `Portfolio`, and `PortfolioBuilder`
- `calculate_portfolio_analytics` and `aggregate_key_rate_profile`
- Benchmark helpers such as `PortfolioBenchmark` and `benchmark_comparison`
- Stress helpers such as `run_stress_scenarios` and `standard_scenarios`
- ETF helpers such as `calculate_etf_nav` and `calculate_sec_yield`

## Example

```python
from decimal import Decimal

from fuggers_py.bonds import FixedBondBuilder
from fuggers_py.core import Currency, Date, Frequency
from fuggers_py.portfolio import Holding, PortfolioBuilder

bond = (
    FixedBondBuilder.new()
    .with_issue_date(Date.from_ymd(2024, 1, 15))
    .with_maturity_date(Date.from_ymd(2029, 1, 15))
    .with_coupon_rate(Decimal("0.04"))
    .with_frequency(Frequency.SEMI_ANNUAL)
    .with_currency(Currency.USD)
    .build()
)
portfolio = (
    PortfolioBuilder()
    .with_currency(Currency.USD)
    .add_holding(Holding(instrument=bond, quantity=Decimal("100"), clean_price=Decimal("99.5"), label="sample"))
    .add_holding(Holding(instrument=bond, quantity=Decimal("50"), clean_price=Decimal("101.25"), label="hedge"))
    .build()
)

assert len(portfolio.investable_holdings()) == 2
assert portfolio.total_market_value() == Decimal("15012.50")
```

## Conventions And Limitations

- Holding clean prices are percent-of-par values.
- Market value and dirty value outputs are currency amounts.
- Portfolio analytics depend on the settlement date and the curve inputs you pass in; they do not fetch missing market data for you.
- The package is built for analytics and reporting, not for order management or position-keeping.
