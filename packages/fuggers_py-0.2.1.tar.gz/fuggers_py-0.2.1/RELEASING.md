# Releasing

`fuggers-py` uses `setuptools_scm`, so build and publish from a normal git checkout with `.git` metadata present.

## Release Checklist

1. Install the release dependencies.

```bash
python -m pip install -e ".[dev,engine,examples]"
```

2. Run the test and lint checks you want on the release candidate.

```bash
pytest -q
python tools/run_release_ruff.py
python -m build
python -m twine check dist/*
```

3. Optionally verify the built artifacts in a clean virtual environment.

```bash
python -m venv /tmp/fuggers-release-check
/tmp/fuggers-release-check/bin/pip install --upgrade pip
/tmp/fuggers-release-check/bin/pip install dist/fuggers_py-*.whl
/tmp/fuggers-release-check/bin/python -c "import fuggers_py; print(fuggers_py.__version__)"
```

4. Update `CHANGELOG.md` if needed.
5. Tag the release as `vX.Y.Z`.
6. Push `main` and the tag.

`setuptools_scm` maps `vX.Y.Z` to package version `X.Y.Z`.

## Exact-Version Check

If you want to verify that the tag resolves to the expected package version before pushing:

```bash
git tag vX.Y.Z
EXPECTED_RELEASE_VERSION=X.Y.Z pytest -q tests/test_packaging_version_consistency.py
git tag -d vX.Y.Z
```

## Publishing

The publish job is defined in [`.github/workflows/release.yml`](.github/workflows/release.yml). If PyPI trusted publishing is enabled for the project, pushing the release tag is enough for GitHub Actions to build and publish the distributions.
