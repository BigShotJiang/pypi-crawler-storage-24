# Examples

Run examples from the repository root after installing the example dependencies.

```bash
python -m pip install -e ".[examples]"
python examples/03_bonds/01_fixed_rate_bonds_pricing_and_risk.py
```

Each notebook is paired with a Jupytext `py:percent` file. Edit the `.py` file, then sync the notebook with `python -m jupytext --sync path/to/notebook.py`.

If you want the notebook view, start JupyterLab from the repository root so the `examples` package imports cleanly.

## Foundations

- `examples/01_foundations/01_dates_daycounts_and_calendars.py`: Compare settlement rules, business-day adjustments, calendars, and accrued-interest inputs.
- `examples/01_foundations/02_numerical_methods_for_term_structures.py`: Show interpolation, extrapolation, and root-finding tools on small curve problems.

## Curves

- `examples/02_curves/01_curve_construction_and_value_conversions.py`: Build discount curves and move between zero rates, discount factors, and forwards.
- `examples/02_curves/02_curve_calibration_piecewise_and_global_fit.py`: Compare piecewise bootstraps and fitted curve methods on the same set of inputs.
- `examples/02_curves/03_curve_scenarios_key_rates_and_multicurve.py`: Apply parallel and key-rate shocks and inspect a small multicurve setup.

## Bonds

- `examples/03_bonds/01_fixed_rate_bonds_pricing_and_risk.py`: Price fixed-rate bonds and inspect yield, duration, convexity, DV01, and a small TIPS case.
- `examples/03_bonds/02_floating_rate_notes_fixings_and_discount_margin.py`: Project FRN coupons from fixings and curves, then compare price and discount margin.
- `examples/03_bonds/03_callable_puttable_and_sinking_fund_structures.py`: Compare bullet, callable, puttable, and sinking-fund cash-flow shapes.

## Analytics

- `examples/04_analytics/01_yield_measures_and_yas.py`: Recreate a bond worksheet with yield measures, invoice data, and YAS-style outputs.
- `examples/04_analytics/02_spread_toolkit_g_i_z_asw_oas.py`: Compare common spread measures and show where callable-bond OAS changes the picture.
- `examples/04_analytics/03_risk_hedging_and_var.py`: Combine duration, key rates, hedge ratios, and VaR on a small rates-and-credit book.

## Portfolio

- `examples/05_portfolio/01_portfolio_summary_bucketing_and_liquidity.py`: Build a portfolio summary with buckets, spread metrics, and liquidity measures.
- `examples/05_portfolio/02_benchmark_active_risk_and_attribution.py`: Compare a portfolio with a benchmark and break down active bets.
- `examples/05_portfolio/03_stress_testing_key_rate_profiles_and_scenarios.py`: Run parallel, spread, and key-rate stress cases on the portfolio.
- `examples/05_portfolio/04_etf_nav_basket_and_sec_yield.py`: Turn bond holdings into ETF-style basket, NAV, and SEC-yield calculations.

## Data And I/O

- `examples/06_data_io/01_market_data_reference_data_and_pricing_specs.py`: Build market-data records, reference-data records, and pricing specs for downstream pricing.
- `examples/06_data_io/02_file_json_and_sqlite_workflows.py`: Read fixture data from files and write snapshots to JSON and SQLite.

## Engine

- `examples/07_engine/01_curve_builder_and_batch_pricing_router.py`: Build curve inputs and run batch pricing through the engine routers.
- `examples/07_engine/02_reactive_market_data_listener_and_scheduling.py`: Show how graph nodes, market-data updates, and schedulers fit together.
- `examples/07_engine/03_end_to_end_research_pipeline.py`: Run a small end-to-end pricing and portfolio example from input records to outputs.
