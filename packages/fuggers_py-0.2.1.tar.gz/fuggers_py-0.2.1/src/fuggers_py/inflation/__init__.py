"""Shared inflation conventions and reference-index helpers."""

from __future__ import annotations

from .analytics import (
    LinkerSwapParityCheck,
    breakeven_inflation_rate,
    linker_swap_parity_check,
    nominal_real_yield_basis,
    nominal_real_yield_spread,
)
from .conventions import InflationConvention, InflationIndexDefinition, USD_CPI_U_NSA
from .curve import InflationCurve, InflationIndexCurve
from .errors import InflationError, InvalidObservationLag, MissingInflationFixing, UnsupportedInflationInterpolation
from .reference_index import reference_cpi, reference_index_ratio
from .bootstrap import InflationBootstrapPoint, InflationBootstrapResult, bootstrap_inflation_curve
from .treasury_data import (
    load_monthly_cpi_fixings_csv,
    load_monthly_cpi_fixings_json,
    parse_bls_cpi_json,
    parse_fred_cpi_csv,
    parse_monthly_cpi_fixings_csv,
    parse_monthly_cpi_fixings_json,
    treasury_cpi_source_from_fixings,
)
from .treasury_auction_data import (
    TreasuryAuctionedTipsRow,
    load_treasury_auctioned_tips_csv,
    load_treasury_auctioned_tips_json,
    parse_treasury_auctioned_tips_csv,
    parse_treasury_auctioned_tips_json,
    tips_bond_from_treasury_auction_row,
)

__all__ = [
    "InflationBootstrapPoint",
    "InflationBootstrapResult",
    "InflationConvention",
    "InflationCurve",
    "InflationError",
    "InflationIndexCurve",
    "InflationIndexDefinition",
    "InvalidObservationLag",
    "LinkerSwapParityCheck",
    "MissingInflationFixing",
    "USD_CPI_U_NSA",
    "UnsupportedInflationInterpolation",
    "breakeven_inflation_rate",
    "bootstrap_inflation_curve",
    "linker_swap_parity_check",
    "nominal_real_yield_basis",
    "nominal_real_yield_spread",
    "parse_bls_cpi_json",
    "parse_fred_cpi_csv",
    "parse_monthly_cpi_fixings_csv",
    "parse_monthly_cpi_fixings_json",
    "TreasuryAuctionedTipsRow",
    "parse_treasury_auctioned_tips_csv",
    "parse_treasury_auctioned_tips_json",
    "load_treasury_auctioned_tips_csv",
    "load_treasury_auctioned_tips_json",
    "tips_bond_from_treasury_auction_row",
    "reference_cpi",
    "reference_index_ratio",
    "load_monthly_cpi_fixings_csv",
    "load_monthly_cpi_fixings_json",
    "treasury_cpi_source_from_fixings",
]
