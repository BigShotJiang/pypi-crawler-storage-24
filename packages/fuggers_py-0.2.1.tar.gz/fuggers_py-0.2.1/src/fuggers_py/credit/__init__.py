"""Credit-domain public API.

This namespace exposes CDS instruments, CDS pricing, CDS curve bootstrap, and
credit-adjustment analytics. CDS spreads and rates are raw decimals unless the
docstring states otherwise.
"""

from __future__ import annotations

from . import _api as _api


def __getattr__(name: str) -> object:
    return getattr(_api, name)

__all__ = list(_api.__all__)
