"""Credit instruments.

This package exposes CDS instruments and their protection-side sign
conventions.
"""

from __future__ import annotations

from .cds import Cds, CdsPremiumPeriod, CreditDefaultSwap, ProtectionSide

__all__ = [
    "Cds",
    "CdsPremiumPeriod",
    "CreditDefaultSwap",
    "ProtectionSide",
]
