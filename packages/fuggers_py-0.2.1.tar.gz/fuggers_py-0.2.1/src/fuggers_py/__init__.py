"""Public package roots for the :mod:`fuggers_py` fixed-income library.

The top-level package is intentionally thin. It exposes version metadata and the
stable domain package roots used throughout the library, including
``fuggers_py.core``, ``fuggers_py.curves``, ``fuggers_py.bonds``,
``fuggers_py.analytics``, ``fuggers_py.portfolio``, ``fuggers_py.inflation``,
and the adjacent data, funding, credit, rates, I/O, engine, and numerical
subpackages.
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as _dist_version

try:
    __version__ = _dist_version("fuggers-py")
except PackageNotFoundError:
    try:
        from ._version import version as __version__
    except ImportError:
        __version__ = "0.0.dev0"

__all__ = [
    "__version__",
    "analytics",
    "bonds",
    "credit",
    "core",
    "curves",
    "data",
    "engine",
    "funding",
    "inflation",
    "io",
    "math",
    "portfolio",
    "rates",
]
