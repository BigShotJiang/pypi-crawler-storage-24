"""Rates options tools.

The subpackage covers futures options, swaptions, cap/floor products, and the
associated Black-76, Bachelier, and Hull-White style pricers. Option inputs
are raw-decimal rates or volatilities, while pricer outputs are currency
present values and greeks scaled to the relevant contract notionals.
"""

from __future__ import annotations

from ._common import OptionType
from .cap_floor import CapFloor, CapFloorType
from .futures_option import FuturesOption
from .pricing import (
    BachelierPricer,
    Black76Pricer,
    CapFloorPricingResult,
    CapFloorletPricingResult,
    FuturesOptionPricingResult,
    HullWhiteOptionPricer,
    HullWhiteRateOptionModel,
    OptionFormulaResult,
    OptionGreeks,
    SwaptionPricingResult,
    bachelier_formula,
    black76_formula,
    hull_white_normal_volatility,
)
from .swaption import Swaption

__all__ = [
    "BachelierPricer",
    "Black76Pricer",
    "CapFloor",
    "CapFloorPricingResult",
    "CapFloorType",
    "CapFloorletPricingResult",
    "FuturesOption",
    "FuturesOptionPricingResult",
    "HullWhiteOptionPricer",
    "HullWhiteRateOptionModel",
    "OptionFormulaResult",
    "OptionGreeks",
    "OptionType",
    "Swaption",
    "SwaptionPricingResult",
    "bachelier_formula",
    "black76_formula",
    "hull_white_normal_volatility",
]
