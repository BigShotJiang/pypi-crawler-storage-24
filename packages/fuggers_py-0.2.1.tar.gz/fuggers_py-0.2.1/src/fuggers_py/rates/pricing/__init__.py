"""Rates pricing facades.

The pricers resolve discount and projection curves, then return PVs, par
spreads, and decompositions in the natural currency of the instrument.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .basis_swap_pricer import BasisSwapPricer, BasisSwapPricingResult
from .cross_currency_basis import CrossCurrencyBasisSwapPricer, CrossCurrencyBasisSwapPricingResult
from .fra_pricer import FraPricer, FraPricingResult
from .inflation_swap_pricer import (
    InflationProjection,
    InflationSwapPricer,
    StandardCouponInflationSwapPeriodPricing,
    StandardCouponInflationSwapPricingResult,
    ZeroCouponInflationSwapPricingResult,
)
from .swap_pricer import SwapPricer, SwapPricingResult

if TYPE_CHECKING:
    from .asset_swap import AssetSwapBreakdown, AssetSwapPricer, AssetSwapPricingResult


def __getattr__(name: str) -> object:
    if name in {"AssetSwapBreakdown", "AssetSwapPricer", "AssetSwapPricingResult"}:
        from .asset_swap import AssetSwapBreakdown, AssetSwapPricer, AssetSwapPricingResult

        return {
            "AssetSwapBreakdown": AssetSwapBreakdown,
            "AssetSwapPricer": AssetSwapPricer,
            "AssetSwapPricingResult": AssetSwapPricingResult,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "AssetSwapBreakdown",
    "AssetSwapPricer",
    "AssetSwapPricingResult",
    "BasisSwapPricer",
    "BasisSwapPricingResult",
    "CrossCurrencyBasisSwapPricer",
    "CrossCurrencyBasisSwapPricingResult",
    "FraPricer",
    "FraPricingResult",
    "InflationProjection",
    "InflationSwapPricer",
    "StandardCouponInflationSwapPeriodPricing",
    "StandardCouponInflationSwapPricingResult",
    "SwapPricer",
    "SwapPricingResult",
    "ZeroCouponInflationSwapPricingResult",
]
