"""Public rates-domain API.

This package re-exports the tradable rates instruments, pricers, and risk
helpers used across the library. Notional amounts are expressed in currency
units, rates and spreads are raw decimals unless a docstring states otherwise,
and prices are usually quoted as percent of par.
"""

from __future__ import annotations

from . import _api as _api


def __getattr__(name: str) -> object:
    return getattr(_api, name)

__all__ = list(_api.__all__)
