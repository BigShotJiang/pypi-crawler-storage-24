"""Tradable overnight indexed swaps.

This is the overnight-indexed alias of :class:`~fuggers_py.rates.instruments.fixed_float_swap.FixedFloatSwap`.
"""

from __future__ import annotations

from dataclasses import dataclass

from .fixed_float_swap import FixedFloatSwap


@dataclass(frozen=True, slots=True)
class Ois(FixedFloatSwap):
    """Overnight indexed swap."""

    def __post_init__(self) -> None:
        """Reuse the fixed-float swap validation."""

        FixedFloatSwap.__post_init__(self)


OvernightIndexedSwap = Ois


__all__ = ["Ois", "OvernightIndexedSwap"]
