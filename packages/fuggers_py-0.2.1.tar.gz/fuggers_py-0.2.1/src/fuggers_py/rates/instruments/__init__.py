"""Tradable rates instruments and leg specifications.

The subpackage defines plain data objects for swaps, FRAs, and related leg
conventions. Coupon rates, spreads, and other market rates are stored as raw
decimals unless a docstring states otherwise.
"""

from __future__ import annotations

from .asset_swap import AssetSwap
from .basis_swap import BasisSwap, SameCurrencyBasisSwap
from .common import AccrualPeriod, FixedLegSpec, FloatingLegSpec, PayReceive, ScheduleDefinition
from .cross_currency_basis import CrossCurrencyBasisSwap
from .fixed_float_swap import FixedFloatSwap, InterestRateSwap
from .fra import ForwardRateAgreement, Fra
from .ois import Ois, OvernightIndexedSwap
from .standard_coupon_inflation_swap import StandardCouponInflationSwap
from .zero_coupon_inflation_swap import ZeroCouponInflationSwap

__all__ = [
    "AccrualPeriod",
    "AssetSwap",
    "BasisSwap",
    "CrossCurrencyBasisSwap",
    "FixedFloatSwap",
    "FixedLegSpec",
    "FloatingLegSpec",
    "ForwardRateAgreement",
    "Fra",
    "InterestRateSwap",
    "Ois",
    "OvernightIndexedSwap",
    "PayReceive",
    "SameCurrencyBasisSwap",
    "ScheduleDefinition",
    "StandardCouponInflationSwap",
    "ZeroCouponInflationSwap",
]
