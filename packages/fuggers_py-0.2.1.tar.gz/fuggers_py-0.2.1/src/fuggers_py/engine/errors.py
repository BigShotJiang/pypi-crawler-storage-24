"""Exceptions raised by the engine routing, scheduling, and orchestration layers."""

from __future__ import annotations


class EngineError(Exception):
    """Base exception for research engine failures."""


class CurveNotFoundError(EngineError):
    """Raised when a named curve cannot be found."""


class RoutingError(EngineError):
    """Raised when the router cannot dispatch or complete a pricing path."""


class EngineConfigurationError(EngineError):
    """Raised when an engine component is missing a required dependency."""


class SchedulerError(EngineError):
    """Raised when a scheduler cannot be configured or run."""


__all__ = ["CurveNotFoundError", "EngineConfigurationError", "EngineError", "RoutingError", "SchedulerError"]
