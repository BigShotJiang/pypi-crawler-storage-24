"""Stable convenience facade for research and reactive engine workflows.

The engine package exposes the synchronous bond router, the rates and funding
specialized routers, and the async reactive orchestration layer from a single
import root. The pricing-engine facade is the synchronous composition object;
the reactive engine is the underlying async runtime that consumes market-data
and scheduler events. Bond pricing stays separate from funding and rates
routing, and the package re-exports the calculation graph, schedulers,
coordination helpers, and public engine records needed to wire those pieces
together.
"""

from __future__ import annotations

from fuggers_py.portfolio import Portfolio, Position

from .builder import PricingEngine, PricingEngineBuilder, ReactiveEngineBuilder
from .calc_graph import CalculationGraph, NodeId, NodeValue, ShardAssignment, ShardConfig, ShardStrategy
from .config import EngineConfig, NodeConfig, UpdateFrequency
from .coordination import (
    InMemoryLeaderElection,
    InMemoryPartitionRegistry,
    InMemoryServiceRegistry,
    LeaderElection,
    PartitionAssignment,
    PartitionRegistry,
    ServiceRegistration,
    ServiceRegistry,
)
from .curve_builder import BuiltCurve, CurveBuilder, ForwardRateCurve
from .errors import CurveNotFoundError, EngineConfigurationError, EngineError, RoutingError, SchedulerError
from .etf_pricing import EtfPricer
from .funding_pricing_router import FundingPricingRouter, RepoPricingResult
from .market_data_listener import (
    CurveInputUpdate,
    CurveUpdate,
    FxRateUpdate,
    IndexFixingUpdate,
    InflationFixingUpdate,
    MarketDataListener,
    MarketDataPublisher,
    MarketDataUpdate,
    QuoteUpdate,
    VolSurfaceUpdate,
)
from .portfolio_analytics import PortfolioAnalyzer, PortfolioPosition
from .pricing_router import BatchPricingResult, PricingFailure, PricingInput, PricingRouter
from .rates_pricing_router import RatesPricingRouter, RoutedFraPricingResult
from .reactive import ReactiveEngine
from .scheduler import CronScheduler, EodScheduler, IntervalScheduler, NodeUpdate, ThrottleManager, UpdateSource

__all__ = [
    "BatchPricingResult",
    "BuiltCurve",
    "CalculationGraph",
    "CronScheduler",
    "CurveBuilder",
    "CurveInputUpdate",
    "CurveUpdate",
    "CurveNotFoundError",
    "EngineConfig",
    "EngineConfigurationError",
    "EngineError",
    "EtfPricer",
    "EodScheduler",
    "FundingPricingRouter",
    "ForwardRateCurve",
    "FxRateUpdate",
    "IndexFixingUpdate",
    "InflationFixingUpdate",
    "IntervalScheduler",
    "MarketDataListener",
    "MarketDataPublisher",
    "MarketDataUpdate",
    "NodeConfig",
    "NodeId",
    "NodeUpdate",
    "NodeValue",
    "InMemoryLeaderElection",
    "InMemoryPartitionRegistry",
    "InMemoryServiceRegistry",
    "LeaderElection",
    "PartitionAssignment",
    "PartitionRegistry",
    "PortfolioAnalyzer",
    "Portfolio",
    "PortfolioPosition",
    "Position",
    "PricingEngine",
    "PricingEngineBuilder",
    "PricingFailure",
    "PricingInput",
    "PricingRouter",
    "QuoteUpdate",
    "ReactiveEngine",
    "ReactiveEngineBuilder",
    "RatesPricingRouter",
    "RepoPricingResult",
    "RoutedFraPricingResult",
    "RoutingError",
    "SchedulerError",
    "ServiceRegistration",
    "ServiceRegistry",
    "ShardAssignment",
    "ShardConfig",
    "ShardStrategy",
    "ThrottleManager",
    "UpdateFrequency",
    "UpdateSource",
    "VolSurfaceUpdate",
]
