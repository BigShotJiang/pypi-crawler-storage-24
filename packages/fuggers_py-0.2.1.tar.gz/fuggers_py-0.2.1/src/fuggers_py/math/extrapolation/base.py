"""Extrapolation interfaces and method enum."""

from __future__ import annotations

from enum import Enum
from typing import Protocol


class Extrapolator(Protocol):
    """Protocol for one-dimensional extrapolators."""

    def extrapolate(self, x: float) -> float:  # pragma: no cover - protocol
        ...

    def derivative(self, x: float) -> float:  # pragma: no cover - protocol
        ...


class ExtrapolationMethod(str, Enum):
    """Supported extrapolation schemes for curve construction."""

    FLAT = "FLAT"
    LINEAR = "LINEAR"
    SMITH_WILSON = "SMITH_WILSON"
