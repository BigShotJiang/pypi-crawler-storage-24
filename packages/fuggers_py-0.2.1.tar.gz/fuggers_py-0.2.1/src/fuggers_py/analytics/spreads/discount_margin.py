"""Discount-margin helpers.

Discount margins are returned as raw decimal spreads. ``price_with_dm()``
returns a dirty price in percent of par, regardless of the FRN notional.
The spread is applied as a continuously compounded add-on over settlement-
relative discount factors using ACT/365 year fractions.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from math import exp

from fuggers_py.bonds.instruments import FloatingRateNote
from fuggers_py.core.types import Date, Price
from fuggers_py.math import SolverConfig, brent, newton_raphson
from fuggers_py.math.errors import ConvergenceFailed, DivisionByZero, InvalidBracket

from ..error import AnalyticsError


DEFAULT_SOLVER_CONFIG = SolverConfig(tolerance=1e-10, max_iterations=200)


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, Price):
        return value.as_percentage()
    return Decimal(str(value))


@dataclass(frozen=True, slots=True)
class DiscountMarginCalculator:
    """Discount-margin solver and spread-sensitivity helper."""

    forward_curve: object
    discount_curve: object
    solver_config: SolverConfig = DEFAULT_SOLVER_CONFIG

    def calculate(self, frn: FloatingRateNote, dirty_price: object, settlement_date: Date) -> Decimal:
        """Solve the discount margin from a dirty price quoted in percent of par."""
        if settlement_date >= frn.maturity_date():
            raise AnalyticsError.invalid_settlement("Settlement date is on or after maturity.")

        future_flows = frn.projected_cash_flows(self.forward_curve, settlement_date)
        if not future_flows:
            raise AnalyticsError.invalid_settlement("No future cash flows remain after settlement.")
        target_price = _to_decimal(dirty_price)
        target = float(target_price)

        def objective(dm: float) -> float:
            return float(self.price_with_dm(frn, Decimal(str(dm)), settlement_date)) - target

        def derivative(dm: float) -> float:
            return self._dm_derivative(
                future_flows,
                Decimal(str(dm)),
                settlement_date,
                frn.notional(),
            )

        guess = self._initial_guess(frn, future_flows, settlement_date, target_price)
        try:
            result = newton_raphson(objective, derivative, guess, config=self.solver_config)
            return Decimal(str(result.root))
        except (ConvergenceFailed, DivisionByZero):
            pass

        for lower, upper in [(-0.1, 0.1), (-0.2, 0.2), (-0.5, 0.5)]:
            try:
                result = brent(objective, lower, upper, config=self.solver_config)
                return Decimal(str(result.root))
            except (ConvergenceFailed, InvalidBracket):
                continue

        raise AnalyticsError.spread_failed("Discount margin solver failed to converge.")

    def price_with_dm(self, frn: FloatingRateNote, dm_decimal: object, settlement_date: Date) -> Decimal:
        """Return the dirty price in percent of par for a raw-decimal discount margin."""
        if settlement_date >= frn.maturity_date():
            raise AnalyticsError.invalid_settlement("Settlement date is on or after maturity.")

        dm = _to_decimal(dm_decimal)
        df_settle = self.discount_curve.discount_factor(settlement_date)
        if df_settle == 0:
            raise AnalyticsError.pricing_failed("Discount factor at settlement is zero.")

        present_value = Decimal(0)
        for cf in frn.projected_cash_flows(self.forward_curve, settlement_date):
            t = float(settlement_date.days_between(cf.date)) / 365.0
            base_df = self.discount_curve.discount_factor(cf.date) / df_settle
            spread_df = Decimal(str(exp(-float(dm) * t)))
            present_value += cf.factored_amount() * base_df * spread_df
        return self._price_from_present_value(present_value, frn.notional())

    def spread_dv01(self, frn: FloatingRateNote, dm_decimal: object, settlement_date: Date) -> Decimal:
        """Return price change for a 1 bp discount-margin move."""
        dm = _to_decimal(dm_decimal)
        bump = Decimal("0.0001")
        price_down = self.price_with_dm(frn, dm - bump, settlement_date)
        price_up = self.price_with_dm(frn, dm + bump, settlement_date)
        return (price_down - price_up) / Decimal(2)

    def spread_duration(self, frn: FloatingRateNote, dm_decimal: object, settlement_date: Date) -> Decimal:
        """Return spread duration in spread-basis-point units."""
        price = self.price_with_dm(frn, dm_decimal, settlement_date)
        if price == 0:
            return Decimal(0)
        dv01 = self.spread_dv01(frn, dm_decimal, settlement_date)
        return dv01 / (price * Decimal("0.0001"))

    def _initial_guess(
        self,
        frn: FloatingRateNote,
        projected_flows,
        settlement_date: Date,
        dirty_price: Decimal,
    ) -> float:
        first_flow = projected_flows[0]
        days_to_next_payment = max(int(settlement_date.days_between(first_flow.date)), 1)
        reference_rate = first_flow.reference_rate
        if reference_rate is None:
            reference_rate = frn.current_reference_rate()
        try:
            guess = simple_margin(
                dirty_price,
                frn.current_coupon_rate(),
                reference_rate,
                days_to_next_payment,
                coupon_is_rate=True,
            )
        except AnalyticsError:
            return 0.0
        return float(guess)

    def _dm_derivative(
        self,
        projected_flows,
        dm_decimal: Decimal,
        settlement_date: Date,
        notional: Decimal,
    ) -> float:
        df_settle = self.discount_curve.discount_factor(settlement_date)
        derivative = 0.0
        for cf in projected_flows:
            years = float(settlement_date.days_between(cf.date)) / 365.0
            base_df = float(self.discount_curve.discount_factor(cf.date) / df_settle)
            derivative += -years * float(cf.factored_amount()) * base_df * exp(-float(dm_decimal) * years)
        return derivative * float(Decimal(100) / notional)

    def _price_from_present_value(self, present_value: Decimal, notional: Decimal) -> Decimal:
        if notional <= 0:
            raise AnalyticsError.invalid_input("FRN notional must be positive.")
        return present_value * Decimal(100) / notional


def simple_margin(
    dirty_price: object,
    next_coupon: object,
    reference_rate: object,
    days_to_reset: int | object,
    *,
    coupon_is_rate: bool = False,
) -> Decimal:
    """Approximate the discount margin from dirty price and next reset.

    ``dirty_price`` is quoted in percent of par. By default ``next_coupon`` is
    the annual coupon cash amount per 100 face. When ``coupon_is_rate`` is
    ``True``, ``next_coupon`` is treated as a raw decimal annual coupon rate
    and converted to an annual cash amount per 100 face.
    """
    price = _to_decimal(dirty_price)
    if price <= 0:
        raise AnalyticsError.invalid_input("dirty_price must be positive.")
    coupon = _to_decimal(next_coupon)
    ref_rate = _to_decimal(reference_rate)
    reset_days = Decimal(str(days_to_reset))
    if reset_days <= 0:
        raise AnalyticsError.invalid_input("days_to_reset must be positive.")
    annual_coupon = coupon * Decimal(100) if coupon_is_rate else coupon
    capital_change = (Decimal(100) - price) * Decimal(360) / reset_days
    average_price = (Decimal(100) + price) / Decimal(2)
    simple_yield = (annual_coupon + capital_change) / average_price
    return simple_yield - ref_rate


def z_discount_margin(
    frn: FloatingRateNote,
    dirty_price: object,
    settlement_date: Date,
    *,
    forward_curve: object,
    discount_curve: object,
) -> Decimal:
    """Solve the discount margin using the curve-backed calculator."""
    return DiscountMarginCalculator(forward_curve=forward_curve, discount_curve=discount_curve).calculate(
        frn,
        dirty_price,
        settlement_date,
    )


__all__ = ["DiscountMarginCalculator", "simple_margin", "z_discount_margin"]
