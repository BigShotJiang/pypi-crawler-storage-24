"""Analytics cashflow helpers and settlement utilities.

This namespace re-exports the bond-layer cashflow machinery behind analytics
names so callers can work entirely inside :mod:`fuggers_py.analytics` without
changing behavior.
"""

from __future__ import annotations

from .accrued import AccruedInterestCalculator
from .generator import CashFlowGenerator
from .irregular import IrregularPeriodHandler
from .schedule import Schedule, ScheduleConfig
from .settlement import (
    ExDividendRules,
    SettlementCalculator,
    SettlementRules,
    SettlementStatus,
    StubType,
)

__all__ = [
    "AccruedInterestCalculator",
    "CashFlowGenerator",
    "IrregularPeriodHandler",
    "Schedule",
    "ScheduleConfig",
    "SettlementCalculator",
    "SettlementRules",
    "SettlementStatus",
    "StubType",
    "ExDividendRules",
]
