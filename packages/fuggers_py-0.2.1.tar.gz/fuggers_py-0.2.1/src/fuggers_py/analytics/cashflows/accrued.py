"""Analytics re-export for accrued-interest helpers.

The implementation lives in :mod:`fuggers_py.bonds.cashflows.accrued`; this
module keeps the analytics import path stable.
"""

from __future__ import annotations

from fuggers_py.bonds.cashflows.accrued import AccruedInterestCalculator

__all__ = ["AccruedInterestCalculator"]
