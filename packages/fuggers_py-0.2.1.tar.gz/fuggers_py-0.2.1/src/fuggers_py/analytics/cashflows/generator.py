"""Analytics re-export for cashflow generation.

The underlying generator is provided by :mod:`fuggers_py.bonds.cashflows`.
"""

from __future__ import annotations

from fuggers_py.bonds.cashflows.generator import CashFlowGenerator

__all__ = ["CashFlowGenerator"]
