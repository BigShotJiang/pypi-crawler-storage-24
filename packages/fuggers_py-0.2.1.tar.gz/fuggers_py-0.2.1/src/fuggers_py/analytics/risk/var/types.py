"""VaR result types (`fuggers_py.analytics.risk.var.types`)."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum


class VaRMethod(str, Enum):
    """Method used to compute value at risk."""

    HISTORICAL = "HISTORICAL"
    PARAMETRIC = "PARAMETRIC"


@dataclass(frozen=True, slots=True)
class VaRResult:
    """Value-at-risk output container."""

    value: Decimal
    confidence: Decimal
    method: VaRMethod


__all__ = ["VaRMethod", "VaRResult"]
