"""Compatibility re-export for analytics exceptions.

The analytics package keeps its exception hierarchy in
``fuggers_py.analytics.errors``. This module mirrors that surface so older
imports continue to work without changing runtime behavior.
"""

from __future__ import annotations

from . import errors as _errors

AnalyticsError = _errors.AnalyticsError
CashflowError = _errors.CashflowError
InvalidInput = _errors.InvalidInput
InvalidSettlement = _errors.InvalidSettlement
NotImplementedAnalytics = _errors.NotImplementedAnalytics
PricingError = _errors.PricingError
RiskError = _errors.RiskError
SpreadError = _errors.SpreadError
YasError = _errors.YasError
YieldSolverError = _errors.YieldSolverError

__all__ = list(_errors.__all__)
