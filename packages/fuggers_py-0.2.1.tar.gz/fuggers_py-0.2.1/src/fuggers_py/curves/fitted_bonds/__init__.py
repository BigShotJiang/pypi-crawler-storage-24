"""Cross-sectional fitted bond curves and fair-value helpers.

This subpackage exposes the fitted-bond research workflow: build an
explanatory curve from clean-price bond observations, attach additive
regression adjustments, and translate the result back into dirty and clean
price fair values. The public API also includes benchmark selection and the
curve families used by the fitter.
"""

from __future__ import annotations

from .fair_value import (
    BondFairValueRequest,
    BondFairValueResult,
    clean_price_from_curve,
    dirty_price_from_curve,
    fair_value_from_curve,
    fair_value_from_fit,
)
from .model import (
    CubicSplineDiscountFactorCurve,
    CubicSplineDiscountFactorCurveModel,
    ExponentialSplineCurveModel,
    ExponentialSplineDiscountCurve,
    FittedBondCurveFamily,
    FittedBondCurveModel,
    FittedBondDiagnostics,
    FittedBondFitResult,
    FittedBondObservation,
    FittedBondObjective,
    FittedBondPointResult,
    RegressionCoefficient,
)
from .notional_benchmarks import BenchmarkComponent, NotionalBenchmark, build_notional_benchmark
from .optimization import FittedBondCurveFitter, FittedBondFitConfig
from .regression import (
    RegressionDesignMatrix,
    RegressionExposure,
    build_design_matrix,
    evaluate_regression_adjustment,
    merge_regression_exposures,
    metadata_regression_exposures,
)

__all__ = [
    "BenchmarkComponent",
    "BondFairValueRequest",
    "BondFairValueResult",
    "CubicSplineDiscountFactorCurve",
    "CubicSplineDiscountFactorCurveModel",
    "ExponentialSplineCurveModel",
    "ExponentialSplineDiscountCurve",
    "FittedBondCurveFamily",
    "FittedBondCurveFitter",
    "FittedBondCurveModel",
    "FittedBondDiagnostics",
    "FittedBondFitConfig",
    "FittedBondFitResult",
    "FittedBondObservation",
    "FittedBondObjective",
    "FittedBondPointResult",
    "NotionalBenchmark",
    "RegressionCoefficient",
    "RegressionDesignMatrix",
    "RegressionExposure",
    "build_design_matrix",
    "build_notional_benchmark",
    "clean_price_from_curve",
    "dirty_price_from_curve",
    "evaluate_regression_adjustment",
    "fair_value_from_curve",
    "fair_value_from_fit",
    "merge_regression_exposures",
    "metadata_regression_exposures",
]
