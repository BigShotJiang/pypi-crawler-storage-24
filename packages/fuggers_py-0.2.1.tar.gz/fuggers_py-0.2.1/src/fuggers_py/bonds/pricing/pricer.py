"""Bond pricer (`fuggers_py.bonds.pricing.pricer`)."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import TYPE_CHECKING

from fuggers_py.core.types import Compounding, Currency, Date, Price, Yield

from ..errors import BondPricingError
from ..traits import Bond
from ..types import CompoundingKind, CompoundingMethod, YieldCalculationRules
from .yield_engine import StandardYieldEngine, YieldEngineResult

if TYPE_CHECKING:  # pragma: no cover
    from fuggers_py.bonds.instruments import TipsBond


def _core_compounding_for(method: CompoundingMethod) -> Compounding:
    if method.kind is CompoundingKind.CONTINUOUS:
        return Compounding.CONTINUOUS
    if method.kind in {CompoundingKind.SIMPLE, CompoundingKind.DISCOUNT}:
        return Compounding.SIMPLE
    if method.frequency == 1:
        return Compounding.ANNUAL
    if method.frequency == 2:
        return Compounding.SEMI_ANNUAL
    if method.frequency == 4:
        return Compounding.QUARTERLY
    if method.frequency == 12:
        return Compounding.MONTHLY
    return Compounding.ANNUAL


@dataclass(frozen=True, slots=True)
class PriceResult:
    """Bond price decomposition at a settlement date.

    Dirty and clean prices are represented as :class:`~fuggers_py.core.types.Price`
    values. ``present_value`` mirrors the dirty price in percent-of-par form.
    """

    dirty: Price
    clean: Price
    accrued: Decimal

    @property
    def dirty_price(self) -> Price:
        return self.dirty

    @property
    def clean_price(self) -> Price:
        return self.clean

    @property
    def accrued_interest(self) -> Decimal:
        return self.accrued

    @property
    def present_value(self) -> Decimal:
        """Return the dirty price as a percent-of-par decimal."""
        return self.dirty.as_percentage()


@dataclass(frozen=True, slots=True)
class YieldResult:
    """Bond yield result together with the lower-level engine output."""

    ytm: Yield
    engine: YieldEngineResult


@dataclass(frozen=True, slots=True)
class TipsPricer:
    """Real-yield pricer for :class:`~fuggers_py.bonds.instruments.TipsBond`."""

    engine: StandardYieldEngine = StandardYieldEngine()

    def accrued_interest(
        self,
        bond: TipsBond,
        settlement_date: Date,
        *,
        fixing_source: object | None = None,
    ) -> Decimal:
        """Return settlement-date accrued interest on inflation-adjusted principal."""

        return bond.accrued_interest(settlement_date, fixing_source=fixing_source)

    def present_value_from_real_yield(
        self,
        bond: TipsBond,
        real_yield: Yield,
        settlement_date: Date,
        *,
        fixing_source: object | None = None,
    ) -> Decimal:
        """Return the dirty price in percent-of-par from a real yield."""

        rules = bond.rules()
        y = BondPricer._yield_to_engine_rate(real_yield, rules=rules)
        dirty = self.engine.dirty_price_from_yield(
            bond.projected_cash_flows(fixing_source=fixing_source),
            yield_rate=y,
            settlement_date=settlement_date,
            rules=rules,
        )
        return Decimal(str(dirty))

    def dirty_price_from_real_yield(
        self,
        bond: TipsBond,
        real_yield: Yield,
        settlement_date: Date,
        *,
        fixing_source: object | None = None,
    ) -> Price:
        """Return the dirty price implied by ``real_yield``."""

        dirty = self.present_value_from_real_yield(
            bond,
            real_yield,
            settlement_date,
            fixing_source=fixing_source,
        )
        return Price.new(dirty, bond.currency())

    def clean_price_from_real_yield(
        self,
        bond: TipsBond,
        real_yield: Yield,
        settlement_date: Date,
        *,
        fixing_source: object | None = None,
    ) -> Price:
        """Return the clean price implied by ``real_yield``."""

        dirty = self.present_value_from_real_yield(
            bond,
            real_yield,
            settlement_date,
            fixing_source=fixing_source,
        )
        accrued = self.accrued_interest(bond, settlement_date, fixing_source=fixing_source)
        return Price.new(dirty - accrued, bond.currency())

    def price_from_real_yield(
        self,
        bond: TipsBond,
        real_yield: Yield,
        settlement_date: Date,
        *,
        fixing_source: object | None = None,
    ) -> PriceResult:
        """Return clean and dirty prices from a real yield."""

        dirty = self.dirty_price_from_real_yield(
            bond,
            real_yield,
            settlement_date,
            fixing_source=fixing_source,
        )
        accrued = self.accrued_interest(bond, settlement_date, fixing_source=fixing_source)
        clean = dirty.as_percentage() - accrued
        return PriceResult(
            dirty=dirty,
            clean=Price.new(clean, bond.currency()),
            accrued=accrued,
        )

    def real_yield_from_clean_price(
        self,
        bond: TipsBond,
        clean_price: Price,
        settlement_date: Date,
        *,
        fixing_source: object | None = None,
    ) -> YieldResult:
        """Return the real yield implied by a clean price."""

        if clean_price.currency() != bond.currency():
            raise BondPricingError(reason="Price currency does not match bond currency.")

        rules = bond.rules()
        accrued = self.accrued_interest(bond, settlement_date, fixing_source=fixing_source)
        engine_res = self.engine.yield_from_price(
            bond.projected_cash_flows(fixing_source=fixing_source),
            clean_price=clean_price.as_percentage(),
            accrued=accrued,
            settlement_date=settlement_date,
            rules=rules,
        )
        compounding = _core_compounding_for(rules.compounding)
        ytm = Yield.new(Decimal(str(engine_res.yield_rate)), compounding=compounding)
        return YieldResult(ytm=ytm, engine=engine_res)

    def risk_metrics_from_real_yield(
        self,
        bond: TipsBond,
        real_yield: Yield,
        settlement_date: Date,
        *,
        fixing_source: object | None = None,
        bump: float = 1e-4,
    ):
        """Return duration, convexity, and DV01/PV01 with respect to real yield."""

        from ..risk import RiskMetrics

        return RiskMetrics.from_projected_cashflows(
            bond.projected_cash_flows(fixing_source=fixing_source),
            real_yield,
            settlement_date,
            rules=bond.rules(),
            bump=bump,
        )


@dataclass(frozen=True, slots=True)
class BondPricer:
    """Convert between bond yields and clean/dirty prices."""

    engine: StandardYieldEngine = StandardYieldEngine()

    def price_from_yield(
        self,
        bond: Bond,
        ytm: Yield,
        settlement_date: Date,
        *,
        fixing_source: object | None = None,
    ) -> PriceResult:
        """Return dirty and clean prices from a yield-to-maturity input.

        The yield input is converted to the bond's compounding convention before
        discounting. The returned clean price excludes accrued interest.
        """
        from ..instruments import TipsBond

        if isinstance(bond, TipsBond):
            return TipsPricer(self.engine).price_from_real_yield(
                bond,
                ytm,
                settlement_date,
                fixing_source=fixing_source,
            )

        rules = bond.rules()
        y = self._yield_to_engine_rate(ytm, rules=rules)

        dirty = self.engine.dirty_price_from_yield(
            bond.cash_flows(),
            yield_rate=y,
            settlement_date=settlement_date,
            rules=rules,
        )
        accrued = bond.accrued_interest(settlement_date)
        clean = dirty - float(accrued)

        ccy = bond.currency()
        return PriceResult(
            dirty=Price.new(Decimal(str(dirty)), ccy),
            clean=Price.new(Decimal(str(clean)), ccy),
            accrued=accrued,
        )

    def yield_from_price(
        self,
        bond: Bond,
        clean_price: Price,
        settlement_date: Date,
        *,
        fixing_source: object | None = None,
    ) -> YieldResult:
        """Return the yield implied by a clean price and settlement date."""
        from ..instruments import TipsBond

        if isinstance(bond, TipsBond):
            return TipsPricer(self.engine).real_yield_from_clean_price(
                bond,
                clean_price,
                settlement_date,
                fixing_source=fixing_source,
            )

        if clean_price.currency() != bond.currency():
            raise BondPricingError(reason="Price currency does not match bond currency.")

        rules = bond.rules()
        accrued = bond.accrued_interest(settlement_date)

        engine_res = self.engine.yield_from_price(
            bond.cash_flows(),
            clean_price=clean_price.as_percentage(),
            accrued=accrued,
            settlement_date=settlement_date,
            rules=rules,
        )

        compounding = _core_compounding_for(rules.compounding)
        ytm = Yield.new(Decimal(str(engine_res.yield_rate)), compounding=compounding)
        return YieldResult(ytm=ytm, engine=engine_res)

    def yield_to_maturity(
        self,
        bond: Bond,
        clean_price: Price,
        settlement_date: Date,
        *,
        fixing_source: object | None = None,
    ) -> Yield:
        """Return the yield implied by a clean price."""

        return self.yield_from_price(
            bond,
            clean_price,
            settlement_date,
            fixing_source=fixing_source,
        ).ytm

    @staticmethod
    def _yield_to_engine_rate(ytm: Yield, *, rules: YieldCalculationRules) -> float:
        """Convert a market yield into the engine's compounding convention."""
        target_compounding = _core_compounding_for(rules.compounding)
        y = ytm.convert_to(target_compounding).value()
        return float(y)


BondResult = PriceResult


__all__ = ["BondPricer", "BondResult", "PriceResult", "TipsPricer", "YieldResult"]
