"""Public bond instruments, conventions, and bond-specific helpers.

This package is the domain layer for cashflow-bearing bond instruments. It
owns instrument definitions, coupon schedules, accrued-interest conventions,
bond-specific pricing kernels, and bond market rules. Higher analytics layers
build on this package but do not redefine clean-price, dirty-price, settlement,
or yield-convention semantics.
"""

from __future__ import annotations

from . import _api as _api
from ._api import *  # noqa: F403

__all__ = list(_api.__all__)
