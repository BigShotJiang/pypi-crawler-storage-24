"""Risk-focused portfolio analytics."""

from __future__ import annotations

from decimal import Decimal

from ..portfolio import Portfolio
from .base import PortfolioAnalytics


def weighted_duration(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return portfolio duration as a raw decimal."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).duration


def weighted_convexity(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return portfolio convexity as a raw decimal."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).convexity


def total_dv01(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return portfolio DV01 in currency units per 1 bp."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).dv01


def total_cs01(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return portfolio CS01 in currency units per 1 bp."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).cs01


def weighted_spread_duration(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return portfolio spread duration as a raw decimal."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).spread_duration


def calculate_risk_metrics(portfolio: Portfolio, *, curve, settlement_date) -> dict[str, Decimal]:
    """Return the standard risk metrics as a plain mapping."""

    metrics = PortfolioAnalytics(portfolio).metrics(curve, settlement_date)
    return {
        "duration": metrics.duration,
        "modified_duration": metrics.modified_duration,
        "effective_duration": metrics.effective_duration,
        "macaulay_duration": metrics.macaulay_duration,
        "convexity": metrics.convexity,
        "effective_convexity": metrics.effective_convexity,
        "dv01": metrics.dv01,
        "cs01": metrics.cs01,
    }


__all__ = [
    "calculate_risk_metrics",
    "total_cs01",
    "total_dv01",
    "weighted_convexity",
    "weighted_duration",
    "weighted_spread_duration",
]
