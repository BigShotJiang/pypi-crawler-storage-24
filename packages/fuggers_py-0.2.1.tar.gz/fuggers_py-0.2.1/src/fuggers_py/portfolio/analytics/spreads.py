"""Spread-focused portfolio analytics."""

from __future__ import annotations

from decimal import Decimal

from ..portfolio import Portfolio
from .base import PortfolioAnalytics


def weighted_spreads(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return the portfolio Z-spread as a raw decimal."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).z_spread


def weighted_oas(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return the portfolio OAS as a raw decimal."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).oas


def weighted_asw(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return the portfolio ASW as a raw decimal."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).asw


def calculate_spread_metrics(portfolio: Portfolio, *, curve, settlement_date) -> dict[str, Decimal]:
    """Return the standard spread metrics as a plain mapping."""

    metrics = PortfolioAnalytics(portfolio).metrics(curve, settlement_date)
    return {
        "z_spread": metrics.z_spread,
        "oas": metrics.oas,
        "g_spread": metrics.g_spread,
        "i_spread": metrics.i_spread,
        "asw": metrics.asw,
        "best_spread": metrics.best_spread,
        "spread_duration": metrics.spread_duration,
        "cs01": metrics.cs01,
    }


__all__ = ["calculate_spread_metrics", "weighted_asw", "weighted_oas", "weighted_spreads"]
