"""Yield-focused portfolio analytics."""

from __future__ import annotations

from decimal import Decimal

from ..portfolio import Portfolio
from .base import PortfolioAnalytics


def weighted_ytm(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return the portfolio yield to maturity as a raw decimal."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).ytm


def weighted_ytw(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return the portfolio yield to worst as a raw decimal."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).ytw


def weighted_ytc(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return the portfolio yield to call as a raw decimal."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).ytc


def weighted_current_yield(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    """Return the portfolio current yield as a raw decimal."""

    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).current_yield


def calculate_yield_metrics(portfolio: Portfolio, *, curve, settlement_date) -> dict[str, Decimal]:
    """Return the standard yield metrics as a plain mapping."""

    metrics = PortfolioAnalytics(portfolio).metrics(curve, settlement_date)
    return {
        "ytm": metrics.ytm,
        "ytw": metrics.ytw,
        "ytc": metrics.ytc,
        "current_yield": metrics.current_yield,
        "best_yield": metrics.best_yield,
    }

__all__ = ["calculate_yield_metrics", "weighted_current_yield", "weighted_ytc", "weighted_ytm", "weighted_ytw"]
