"""Key-rate profile aggregation."""

from __future__ import annotations

from ..portfolio import Portfolio
from ..results import KeyRateProfile
from .base import PortfolioAnalytics


def aggregate_key_rate_profile(portfolio: Portfolio, *, curve, settlement_date) -> KeyRateProfile:
    """Return the portfolio key-rate DV01 profile."""

    return KeyRateProfile(entries=dict(PortfolioAnalytics(portfolio).metrics(curve, settlement_date).key_rate_profile))


def partial_dv01s(portfolio: Portfolio, *, curve, settlement_date) -> KeyRateProfile:
    """Compatibility alias for :func:`aggregate_key_rate_profile`."""

    return aggregate_key_rate_profile(portfolio, curve=curve, settlement_date=settlement_date)


__all__ = ["aggregate_key_rate_profile", "partial_dv01s"]
