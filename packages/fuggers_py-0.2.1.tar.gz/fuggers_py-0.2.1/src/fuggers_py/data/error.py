"""Compatibility wrapper for :mod:`fuggers_py.data.errors`.

The module re-exports the canonical error classes so older imports keep
working without changing runtime behavior.
"""

from __future__ import annotations

from . import errors as _errors

AlreadyExistsError = _errors.AlreadyExistsError
AuthenticationError = _errors.AuthenticationError
ConnectionFailureError = _errors.ConnectionFailureError
DatabaseError = _errors.DatabaseError
InternalError = _errors.InternalError
InvalidInputError = _errors.InvalidInputError
NotFoundError = _errors.NotFoundError
ParseError = _errors.ParseError
PermissionDeniedError = _errors.PermissionDeniedError
RateLimitError = _errors.RateLimitError
SerializationError = _errors.SerializationError
SourceUnavailableError = _errors.SourceUnavailableError
SubscriptionFailureError = _errors.SubscriptionFailureError
TraitError = _errors.TraitError
TraitIOError = _errors.TraitIOError
TraitTimeoutError = _errors.TraitTimeoutError


def __getattr__(name: str) -> object:
    """Delegate deprecated alias resolution to :mod:`fuggers_py.data.errors`."""
    return _errors.__getattr__(name)


__all__ = list(_errors.__all__)
