"""Funding-domain public API.

This namespace exposes repo trades, repo-curve helpers, and carry/specialness
analytics. Rates and haircuts documented here use raw decimal conventions
unless a docstring states otherwise.
"""

from __future__ import annotations

from . import _api as _api
from ._api import *  # noqa: F403

__all__ = list(_api.__all__)
