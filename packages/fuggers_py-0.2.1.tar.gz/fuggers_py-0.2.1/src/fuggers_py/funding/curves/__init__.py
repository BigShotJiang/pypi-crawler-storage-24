"""Funding curves.

Currently this package exposes the repo-curve wrapper used for forward-repo
and funding-spread calculations.
"""

from __future__ import annotations

from .repo_curve import RepoCurve

__all__ = ["RepoCurve"]
