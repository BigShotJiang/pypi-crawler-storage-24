"""Funding instruments.

This package exposes repo-trade instruments with raw-decimal rate and haircut
inputs and percent-of-par collateral pricing.
"""

from __future__ import annotations

from .repo import RepoTrade

__all__ = ["RepoTrade"]
