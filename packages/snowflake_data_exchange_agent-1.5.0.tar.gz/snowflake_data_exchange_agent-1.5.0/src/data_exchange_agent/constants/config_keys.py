"""
Configuration-related constants.

Note: Double underscores (__) in constant names represent dots (.) in the actual
configuration path. For example, APPLICATION__MAX_PARALLEL_TASKS represents "application.max_parallel_tasks".

Note: Short keys (without section prefix) are for within-section access only.
For cross-section access, use the full path constants (e.g., APPLICATION__MAX_PARALLEL_TASKS).
"""

SELECTED_TASK_SOURCE = "selected_task_source"

APPLICATION = "application"
MAX_PARALLEL_TASKS = "max_parallel_tasks"
DEBUG_MODE = "debug_mode"
TASK_FETCH_INTERVAL = "task_fetch_interval"
LEASE_REFRESH_INTERVAL = "lease_refresh_interval"
AGENT_ID = "agent_id"
AFFINITY = "affinity"
SNOWFLAKE_DATABASE_FOR_METADATA = "snowflake_database_for_metadata"
SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA = (
    "snowflake_schema_for_data_migration_metadata"
)
APPLICATION__MAX_PARALLEL_TASKS = f"{APPLICATION}.{MAX_PARALLEL_TASKS}"
APPLICATION__DEBUG_MODE = f"{APPLICATION}.{DEBUG_MODE}"
APPLICATION__TASK_FETCH_INTERVAL = f"{APPLICATION}.{TASK_FETCH_INTERVAL}"
APPLICATION__LEASE_REFRESH_INTERVAL = f"{APPLICATION}.{LEASE_REFRESH_INTERVAL}"
APPLICATION__AGENT_ID = f"{APPLICATION}.{AGENT_ID}"
APPLICATION__AFFINITY = f"{APPLICATION}.{AFFINITY}"
APPLICATION__SNOWFLAKE_DATABASE_FOR_METADATA = (
    f"{APPLICATION}.{SNOWFLAKE_DATABASE_FOR_METADATA}"
)
APPLICATION__SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA = (
    f"{APPLICATION}.{SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA}"
)

SERVER = "server"
HOST = "host"
PORT = "port"
SERVER__HOST = f"{SERVER}.{HOST}"
SERVER__PORT = f"{SERVER}.{PORT}"

TASK_SOURCE = "task_source"

CONNECTIONS = "connections"
SOURCE = "source"
TARGET = "target"
CONNECTIONS__SOURCE = f"{CONNECTIONS}.{SOURCE}"
CONNECTIONS__TARGET = f"{CONNECTIONS}.{TARGET}"
