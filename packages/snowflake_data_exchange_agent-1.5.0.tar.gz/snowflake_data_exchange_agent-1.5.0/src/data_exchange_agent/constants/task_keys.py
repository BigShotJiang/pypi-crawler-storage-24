"""Task-related constants."""

ENGINE = "engine"
DATABASE = "database"
STATEMENT = "statement"
TARGET_TYPE = "target_type"
TARGET_ID = "target_id"
ID = "id"
PAYLOAD = "payload"
STATUS = "status"
DETAILS = "details"
TOTAL = "total"
SUGGESTED_BATCH_SIZE = "suggested_batch_size"
IS_BULK_OPERATION = "is_bulk_operation"
USE_DATABASE_COMMAND = "use_database_command"

# Task kind discriminator
KIND = "kind"

# Task kinds
DATA_MOVEMENT = "data_movement"
DATA_VALIDATION = "data_validation"


# Target type values (match TargetType enum in orchestrator)
class TargetTypeValues:
    """Constants for target_type field values."""

    SNOWFLAKE_STAGE = "snowflake:stage"
    S3_UNLOAD = "s3:unload"
    NONE = "none"
    S3 = "s3"
    BLOB = "blob"
