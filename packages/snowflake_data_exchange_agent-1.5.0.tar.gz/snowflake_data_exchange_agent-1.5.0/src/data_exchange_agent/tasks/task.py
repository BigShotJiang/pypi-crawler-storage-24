"""Task class."""

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class Task:
    """
    Task class.

    This class represents a task that needs to be executed.
    """

    id: str
    engine: str
    database: str
    schema: str
    statement: str
    target_type: str
    target_id: str
    suggested_batch_size: int | None = None
    is_bulk_operation: bool = False
    use_database_command: str | None = None

    def to_dict(self) -> dict:
        """
        Convert the Task to a dictionary.

        Returns:
            dict: The Task as a dictionary.

        """
        return asdict(self)
