"""Connection registry for dynamic class registration."""

from typing import Any

from data_exchange_agent.config.sections.connections.base import BaseConnectionConfig
from data_exchange_agent.utils.base_registry import BaseRegistry


class ConnectionRegistry(BaseRegistry[BaseConnectionConfig]):
    """Registry for connection configuration classes."""

    _registry_type_name = "connection"

    @classmethod
    def create(cls, name: str, **kwargs: Any) -> BaseConnectionConfig:
        """
        Create an instance of a registered connection configuration.

        If the connection class has a `from_config_dict` classmethod, it will be used
        to construct the instance. Otherwise, falls back to direct instantiation.

        Args:
            name: The connection type name
            **kwargs: Arguments to pass to the configuration class constructor

        Returns:
            An instance of the connection configuration class

        """
        config_class = cls.get(name)

        # Check if the class has a factory method for config dict creation
        if hasattr(config_class, "from_config_dict") and callable(
            config_class.from_config_dict
        ):
            return config_class.from_config_dict(**kwargs)

        # Otherwise use standard instantiation
        return config_class(**kwargs)
