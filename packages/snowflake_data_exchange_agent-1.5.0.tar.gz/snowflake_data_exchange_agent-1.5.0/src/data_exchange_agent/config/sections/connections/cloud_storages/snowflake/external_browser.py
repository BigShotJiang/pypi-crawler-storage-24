"""Snowflake external browser authentication configuration."""

from pydantic import Field

from data_exchange_agent.config.sections.connections.cloud_storages.snowflake.authenticator_type import (
    SnowflakeAuthenticatorType,
)
from data_exchange_agent.config.sections.connections.cloud_storages.snowflake.base import (
    SnowflakeExtendedBaseConnectionConfig,
)


class SnowflakeConnectionExternalBrowserConfig(SnowflakeExtendedBaseConnectionConfig):
    """Configuration class for Snowflake connection using external browser authentication."""

    authenticator: SnowflakeAuthenticatorType = Field(
        default=SnowflakeAuthenticatorType.EXTERNAL_BROWSER,
        description="Snowflake authenticator type",
    )
