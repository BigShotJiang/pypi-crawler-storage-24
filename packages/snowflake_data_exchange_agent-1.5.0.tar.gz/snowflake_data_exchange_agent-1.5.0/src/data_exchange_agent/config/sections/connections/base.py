from data_exchange_agent.config.sections.base_section_config import BaseSectionConfig


class BaseConnectionConfig(BaseSectionConfig):
    """Base configuration class for database connection settings."""

    pass
