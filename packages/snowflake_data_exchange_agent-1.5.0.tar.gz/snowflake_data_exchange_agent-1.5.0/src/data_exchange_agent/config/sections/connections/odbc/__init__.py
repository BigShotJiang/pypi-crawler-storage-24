"""ODBC connection configuration module."""

from data_exchange_agent.config.sections.connections.connection_registry import (
    ConnectionRegistry,
)
from data_exchange_agent.config.sections.connections.odbc.base import (
    BaseODBCConnectionConfig,
)
from data_exchange_agent.config.sections.connections.odbc.postgresql import (
    PostgresqlConnectionConfig,
)
from data_exchange_agent.config.sections.connections.odbc.redshift import (
    AuthMethod,
    IAMProvisionedCredentials,
    IAMServerlessCredentials,
    RedshiftConnectionConfig,
    StandardCredentials,
)
from data_exchange_agent.config.sections.connections.odbc.sqlserver import (
    SQLServerConnectionConfig,
)
from data_exchange_agent.config.sections.connections.odbc.teradata import (
    DEFAULT_TERADATA_ODBC_DRIVER,
    DEFAULT_TERADATA_PORT,
    TeradataConnectionConfig,
)
from data_exchange_agent.constants.connection_types import ConnectionType
from shared.sqlserver.odbc_driver_utils import (
    get_best_sqlserver_driver,
    get_sqlserver_drivers,
    is_driver_available,
    validate_sqlserver_driver,
)


# Register connection types
ConnectionRegistry.register(ConnectionType.SQLSERVER, SQLServerConnectionConfig)
ConnectionRegistry.register(ConnectionType.REDSHIFT, RedshiftConnectionConfig)
ConnectionRegistry.register(ConnectionType.POSTGRESQL, PostgresqlConnectionConfig)
ConnectionRegistry.register(ConnectionType.TERADATA, TeradataConnectionConfig)

__all__ = [
    "BaseODBCConnectionConfig",
    "DEFAULT_TERADATA_ODBC_DRIVER",
    "DEFAULT_TERADATA_PORT",
    "PostgresqlConnectionConfig",
    "RedshiftConnectionConfig",
    "SQLServerConnectionConfig",
    "TeradataConnectionConfig",
    "AuthMethod",
    "StandardCredentials",
    "IAMProvisionedCredentials",
    "IAMServerlessCredentials",
    "get_best_sqlserver_driver",
    "get_sqlserver_drivers",
    "is_driver_available",
    "validate_sqlserver_driver",
]
