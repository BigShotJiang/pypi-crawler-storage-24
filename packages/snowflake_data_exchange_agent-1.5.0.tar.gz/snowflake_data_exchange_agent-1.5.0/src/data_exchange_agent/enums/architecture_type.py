"""
Architecture type enumeration.

This module defines an enumeration for different architecture types.
"""

from enum import Enum


class ArchitectureType(str, Enum):
    """
    Enumeration of supported architecture types.

    This enumeration defines all the architecture types that are supported.

    Attributes:
        X64: 64-bit architecture
        X86: 32-bit architecture

    """

    X64 = "x64"
    X86 = "x86"

    def __str__(self) -> str:
        """
        Return the string representation of the architecture type.

        Returns:
            str: The string representation of the architecture type.

        """
        return self.value
