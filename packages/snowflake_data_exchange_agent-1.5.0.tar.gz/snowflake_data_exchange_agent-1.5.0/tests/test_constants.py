"""
Tests for constants modules.

This module tests all the constant values defined in the constants package
to ensure they maintain their expected values and types.
"""

import unittest

from data_exchange_agent.constants.config_defaults import (
    DEFAULT__APPLICATION__TASK_FETCH_INTERVAL,
    DEFAULT__APPLICATION__MAX_PARALLEL_TASKS,
)
from data_exchange_agent.constants.container_keys import SF_LOGGER
from data_exchange_agent.constants.task_keys import (
    DATABASE,
    DETAILS,
    ENGINE,
    ID,
    IS_BULK_OPERATION,
    STATEMENT,
    STATUS,
    SUGGESTED_BATCH_SIZE,
    TARGET_ID,
    TARGET_TYPE,
    TOTAL,
    USE_DATABASE_COMMAND,
    TargetTypeValues,
)


class TestContainerConstants(unittest.TestCase):
    """Test container-related constants."""

    def test_sf_logger_constant(self):
        """Test SF_LOGGER constant value and type."""
        self.assertEqual(SF_LOGGER, "sf_logger")
        self.assertIsInstance(SF_LOGGER, str)


class TestManagerConstants(unittest.TestCase):
    """Test task manager configuration constants."""

    def test_max_workers_constant(self):
        """Test MAX_WORKERS constant value and type."""
        self.assertEqual(DEFAULT__APPLICATION__MAX_PARALLEL_TASKS, 4)
        self.assertIsInstance(DEFAULT__APPLICATION__MAX_PARALLEL_TASKS, int)
        self.assertGreater(DEFAULT__APPLICATION__MAX_PARALLEL_TASKS, 0)

    def test_task_fetch_interval_constant(self):
        """Test TASK_FETCH_INTERVAL constant value and type."""
        self.assertEqual(DEFAULT__APPLICATION__TASK_FETCH_INTERVAL, 5)
        self.assertIsInstance(DEFAULT__APPLICATION__TASK_FETCH_INTERVAL, int)
        self.assertGreater(DEFAULT__APPLICATION__TASK_FETCH_INTERVAL, 0)


class TestTaskConstants(unittest.TestCase):
    """Test task-related constants."""

    def test_engine_constant(self):
        """Test ENGINE constant value and type."""
        self.assertEqual(ENGINE, "engine")
        self.assertIsInstance(ENGINE, str)

    def test_database_constant(self):
        """Test DATABASE constant value and type."""
        self.assertEqual(DATABASE, "database")
        self.assertIsInstance(DATABASE, str)

    def test_statement_constant(self):
        """Test STATEMENT constant value and type."""
        self.assertEqual(STATEMENT, "statement")
        self.assertIsInstance(STATEMENT, str)

    def test_target_type_constant(self):
        """Test TARGET_TYPE constant value and type."""
        self.assertEqual(TARGET_TYPE, "target_type")
        self.assertIsInstance(TARGET_TYPE, str)

    def test_target_id_constant(self):
        """Test TARGET_ID constant value and type."""
        self.assertEqual(TARGET_ID, "target_id")
        self.assertIsInstance(TARGET_ID, str)

    def test_id_constant(self):
        """Test ID constant value and type."""
        self.assertEqual(ID, "id")
        self.assertIsInstance(ID, str)

    def test_status_constant(self):
        """Test STATUS constant value and type."""
        self.assertEqual(STATUS, "status")
        self.assertIsInstance(STATUS, str)

    def test_details_constant(self):
        """Test DETAILS constant value and type."""
        self.assertEqual(DETAILS, "details")
        self.assertIsInstance(DETAILS, str)

    def test_total_constant(self):
        """Test TOTAL constant value and type."""
        self.assertEqual(TOTAL, "total")
        self.assertIsInstance(TOTAL, str)

    def test_suggested_batch_size_constant(self):
        """Test SUGGESTED_BATCH_SIZE constant value and type."""
        self.assertEqual(SUGGESTED_BATCH_SIZE, "suggested_batch_size")
        self.assertIsInstance(SUGGESTED_BATCH_SIZE, str)

    def test_is_bulk_operation_constant(self):
        """Test IS_BULK_OPERATION constant value and type."""
        self.assertEqual(IS_BULK_OPERATION, "is_bulk_operation")
        self.assertIsInstance(IS_BULK_OPERATION, str)

    def test_use_database_command_constant(self):
        """Test USE_DATABASE_COMMAND constant value and type."""
        self.assertEqual(USE_DATABASE_COMMAND, "use_database_command")
        self.assertIsInstance(USE_DATABASE_COMMAND, str)

    def test_all_constants_are_strings(self):
        """Test that all task constants are strings."""
        constants = [
            ENGINE,
            DATABASE,
            STATEMENT,
            TARGET_TYPE,
            TARGET_ID,
            ID,
            STATUS,
            DETAILS,
            TOTAL,
            SUGGESTED_BATCH_SIZE,
            IS_BULK_OPERATION,
            USE_DATABASE_COMMAND,
        ]
        for constant in constants:
            self.assertIsInstance(constant, str)
            self.assertTrue(len(constant) > 0)


class TestTargetTypeValues(unittest.TestCase):
    """Test TargetTypeValues class constants."""

    def test_snowflake_stage_constant(self):
        """Test SNOWFLAKE_STAGE constant value and type."""
        self.assertEqual(TargetTypeValues.SNOWFLAKE_STAGE, "snowflake:stage")
        self.assertIsInstance(TargetTypeValues.SNOWFLAKE_STAGE, str)

    def test_s3_unload_constant(self):
        """Test S3_UNLOAD constant value and type."""
        self.assertEqual(TargetTypeValues.S3_UNLOAD, "s3:unload")
        self.assertIsInstance(TargetTypeValues.S3_UNLOAD, str)

    def test_none_constant(self):
        """Test NONE constant value and type."""
        self.assertEqual(TargetTypeValues.NONE, "none")
        self.assertIsInstance(TargetTypeValues.NONE, str)

    def test_s3_constant(self):
        """Test S3 constant value and type."""
        self.assertEqual(TargetTypeValues.S3, "s3")
        self.assertIsInstance(TargetTypeValues.S3, str)

    def test_blob_constant(self):
        """Test BLOB constant value and type."""
        self.assertEqual(TargetTypeValues.BLOB, "blob")
        self.assertIsInstance(TargetTypeValues.BLOB, str)


if __name__ == "__main__":
    unittest.main()
