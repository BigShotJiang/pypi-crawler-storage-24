# Copyright 2013 Hewlett-Packard Development Company, L.P.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from .. import base


class TraitDescription(base.Resource):
    def __repr__(self):
        return "<Trait %s>" % self._info


class TraitDescriptionManager(base.Manager):
    resource_class = TraitDescription

    def list(self, event_type):
        path = '/v2/event_types/%s/traits' % event_type
        return self._list(path)
