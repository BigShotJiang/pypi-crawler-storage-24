from setuptools import setup, find_packages

setup(
    name="potatoplm",
    version="0.2.0",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.20.0",
    ],
    python_requires=">=3.10",
    author="Potato Developer",
    description="A pure Python LLM library implemented with NumPy.",
)
