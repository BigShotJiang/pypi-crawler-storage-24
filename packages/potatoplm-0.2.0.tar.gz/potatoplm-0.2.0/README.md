# PotatoPLM

PotatoPLM is a **Pure Python** LLM library implemented from scratch using NumPy. 
It aims to be a transparent and educational implementation of the Transformer architecture.

## Features
- Pure NumPy-based Transformer implementation.
- **Llama-style architecture**:
    - **RMSNorm** for normalization.
    - **RoPE** (Rotary Positional Embeddings).
    - **SwiGLU** activation function.
- Minimal dependencies (only `numpy`).
- Python 3.10 compatible.
- GPT-style Decoder-only architecture.

## Installation & Setup

We recommend using a virtual environment:

```bash
# Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate

# Install the package in editable mode
pip install -e .
```

## Usage Example
Run the toy inference example:
```bash
python3 examples/toy_inference.py
```
