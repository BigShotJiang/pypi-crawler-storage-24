"""
setup.py — Build and distribution configuration for OpsLogger.

Install locally (editable):
    pip install -e .

Build a distribution:
    python setup.py sdist bdist_wheel
"""

from pathlib import Path
from setuptools import setup, find_packages

HERE = Path(__file__).parent
long_description = (HERE / "README.md").read_text(encoding="utf-8")

setup(
    name="opslogger",
    version="1.0.1",
    author="AnantaOps",
    author_email="hello@anantaops.dev",
    description="Structured, context-aware JSON logging for Python backend services.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Ananta-Ops/OpsLogger-python",
    license="MIT",
    packages=find_packages(exclude=["tests*", "examples*"]),
    python_requires=">=3.10",
    install_requires=[],          # Zero external runtime dependencies.
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
        ]
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: System :: Logging",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="logging structured json observability ops backend",
)
