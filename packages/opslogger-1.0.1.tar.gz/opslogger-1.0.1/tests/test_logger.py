"""
tests/test_logger.py — Comprehensive unit tests for OpsLogger.

Run with:
    python -m pytest tests/ -v
or:
    python -m unittest discover tests
"""

import io
import json
import unittest

from opslogger import OpsLogger, LogLevel


# ── helpers ───────────────────────────────────────────────────────────────────

def make_logger(service: str = "TestService", level: LogLevel = LogLevel.DEBUG) -> tuple[OpsLogger, io.StringIO]:
    """Return a logger wired to an in-memory StringIO buffer (no stderr noise)."""
    buf = io.StringIO()
    log = OpsLogger(service_name=service, min_level=level, console=False)
    # Inject the buffer directly into the outputs list for inspection.
    log._outputs = [buf]
    return log, buf


def parse_entry(buf: io.StringIO) -> dict:
    """Parse the first JSON line from the buffer."""
    line = buf.getvalue().strip().splitlines()[0]
    return json.loads(line)


def all_entries(buf: io.StringIO) -> list[dict]:
    """Parse every JSON line from the buffer."""
    return [json.loads(l) for l in buf.getvalue().strip().splitlines() if l.strip()]


# ── log level tests ───────────────────────────────────────────────────────────

class TestLogLevels(unittest.TestCase):

    def test_debug_level_label(self):
        log, buf = make_logger()
        log.debug("debug msg")
        self.assertEqual(parse_entry(buf)["level"], "DEBUG")

    def test_info_level_label(self):
        log, buf = make_logger()
        log.info("info msg")
        self.assertEqual(parse_entry(buf)["level"], "INFO")

    def test_warning_level_label(self):
        log, buf = make_logger()
        log.warning("warn msg")
        self.assertEqual(parse_entry(buf)["level"], "WARNING")

    def test_warn_alias(self):
        """OpsLogger.warn should be an alias for .warning."""
        log, buf = make_logger()
        log.warn("warn alias")
        self.assertEqual(parse_entry(buf)["level"], "WARNING")

    def test_error_level_label(self):
        log, buf = make_logger()
        log.error("error msg")
        self.assertEqual(parse_entry(buf)["level"], "ERROR")

    def test_critical_level_label(self):
        log, buf = make_logger()
        log.critical("critical msg")
        self.assertEqual(parse_entry(buf)["level"], "CRITICAL")


# ── mandatory fields ──────────────────────────────────────────────────────────

class TestMandatoryFields(unittest.TestCase):

    def test_timestamp_present_and_non_empty(self):
        log, buf = make_logger()
        log.info("ts check")
        ts = parse_entry(buf).get("timestamp", "")
        self.assertTrue(ts, "timestamp must be a non-empty string")

    def test_service_name_propagated(self):
        log, buf = make_logger(service="PaymentService")
        log.info("hello")
        self.assertEqual(parse_entry(buf)["service"], "PaymentService")

    def test_message_propagated(self):
        log, buf = make_logger()
        log.info("my unique message")
        self.assertEqual(parse_entry(buf)["message"], "my unique message")

    def test_output_is_valid_json(self):
        log, buf = make_logger()
        log.info("json validity", extra={"k": "v"})
        try:
            json.loads(buf.getvalue().strip())
        except json.JSONDecodeError as exc:
            self.fail(f"Output is not valid JSON: {exc}")


# ── request ID ────────────────────────────────────────────────────────────────

class TestRequestID(unittest.TestCase):

    def test_request_id_included_when_provided(self):
        log, buf = make_logger()
        log.info("req arrives", request_id="req-xyz-123")
        self.assertEqual(parse_entry(buf)["request_id"], "req-xyz-123")

    def test_request_id_absent_when_not_provided(self):
        log, buf = make_logger()
        log.info("no request id")
        entry = parse_entry(buf)
        self.assertNotIn("request_id", entry)

    def test_empty_string_request_id_not_included(self):
        log, buf = make_logger()
        log.info("empty rid", request_id="")
        entry = parse_entry(buf)
        self.assertNotIn("request_id", entry)


# ── extra fields ──────────────────────────────────────────────────────────────

class TestExtraFields(unittest.TestCase):

    def test_extra_fields_serialised(self):
        log, buf = make_logger()
        log.info("with extras", extra={"env": "prod", "port": 8080})
        extra = parse_entry(buf)["extra"]
        self.assertEqual(extra["env"], "prod")
        self.assertEqual(extra["port"], 8080)

    def test_no_extra_key_when_none(self):
        log, buf = make_logger()
        log.info("no extras")
        self.assertNotIn("extra", parse_entry(buf))

    def test_extra_does_not_mutate_caller_dict(self):
        log, buf = make_logger()
        caller_dict = {"key": "value"}
        log.info("mutation check", extra=caller_dict)
        caller_dict["new_key"] = "new_value"
        entry = parse_entry(buf)
        self.assertNotIn("new_key", entry.get("extra", {}))


# ── error capture ─────────────────────────────────────────────────────────────

class TestErrorCapture(unittest.TestCase):

    def test_error_field_included(self):
        log, buf = make_logger()
        log.error("bad thing", error=ValueError("something broke"))
        entry = parse_entry(buf)
        self.assertIn("ValueError", entry["error"])
        self.assertIn("something broke", entry["error"])

    def test_error_field_absent_when_none(self):
        log, buf = make_logger()
        log.error("no error obj")
        self.assertNotIn("error", parse_entry(buf))

    def test_traceback_included_for_raised_exception(self):
        log, buf = make_logger()
        try:
            raise RuntimeError("traceback test")
        except RuntimeError as exc:
            log.error("caught", error=exc)
        entry = parse_entry(buf)
        self.assertIn("traceback", entry)

    def test_traceback_absent_for_unraised_exception(self):
        """An exception created but never raised has no traceback."""
        log, buf = make_logger()
        log.error("no tb", error=RuntimeError("constructed only"))
        entry = parse_entry(buf)
        self.assertNotIn("traceback", entry)

    def test_critical_captures_error(self):
        log, buf = make_logger()
        log.critical("fatal", error=MemoryError("OOM"))
        entry = parse_entry(buf)
        self.assertIn("MemoryError", entry["error"])


# ── min-level filtering ───────────────────────────────────────────────────────

class TestMinLevelFiltering(unittest.TestCase):

    def test_below_min_level_not_written(self):
        log, buf = make_logger(level=LogLevel.WARNING)
        log.debug("dropped")
        log.info("dropped")
        self.assertEqual(buf.getvalue(), "")

    def test_at_min_level_is_written(self):
        log, buf = make_logger(level=LogLevel.WARNING)
        log.warning("passes")
        self.assertGreater(len(buf.getvalue()), 0)

    def test_above_min_level_is_written(self):
        log, buf = make_logger(level=LogLevel.WARNING)
        log.error("passes")
        log.critical("passes")
        entries = all_entries(buf)
        self.assertEqual(len(entries), 2)

    def test_set_min_level_filters_dynamically(self):
        log, buf = make_logger(level=LogLevel.DEBUG)
        log.debug("visible before change")
        log.set_min_level(LogLevel.ERROR)
        log.debug("now invisible")
        log.info("now invisible")
        log.warning("now invisible")
        log.error("still visible")
        entries = all_entries(buf)
        levels = [e["level"] for e in entries]
        self.assertIn("DEBUG", levels)
        self.assertIn("ERROR", levels)
        self.assertNotIn("INFO", levels)
        self.assertNotIn("WARNING", levels)


# ── constructor validation ────────────────────────────────────────────────────

class TestConstructorValidation(unittest.TestCase):

    def test_empty_service_name_raises(self):
        with self.assertRaises(ValueError):
            OpsLogger(service_name="")

    def test_non_string_service_name_raises(self):
        with self.assertRaises(ValueError):
            OpsLogger(service_name=None)  # type: ignore[arg-type]

    def test_invalid_set_min_level_raises(self):
        log, _ = make_logger()
        with self.assertRaises(TypeError):
            log.set_min_level(10)  # type: ignore[arg-type]


# ── context manager ───────────────────────────────────────────────────────────

class TestContextManager(unittest.TestCase):

    def test_context_manager_closes_without_error(self):
        buf = io.StringIO()
        log = OpsLogger(service_name="CM", console=False)
        log._outputs = [buf]
        with log as l:
            l.info("inside ctx")
        # After __exit__, writing should still succeed (buf still open)
        entries = all_entries(buf)
        self.assertEqual(len(entries), 1)


# ── multiple log entries ordering ─────────────────────────────────────────────

class TestMultipleEntries(unittest.TestCase):

    def test_entries_written_in_order(self):
        log, buf = make_logger()
        messages = ["first", "second", "third"]
        for msg in messages:
            log.info(msg)
        entries = all_entries(buf)
        self.assertEqual([e["message"] for e in entries], messages)

    def test_each_entry_is_one_line(self):
        log, buf = make_logger()
        log.debug("a")
        log.info("b")
        log.warning("c")
        lines = [l for l in buf.getvalue().splitlines() if l.strip()]
        self.assertEqual(len(lines), 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
