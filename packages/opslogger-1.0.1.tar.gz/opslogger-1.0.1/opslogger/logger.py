"""
Core logging engine for OpsLogger.

This module provides the ``OpsLogger`` class and the ``LogLevel`` enum.
All log output is emitted as a single JSON object per line, making it
immediately consumable by any log-aggregation pipeline.

Each log entry always contains:

- ``timestamp``  — ISO-8601 UTC timestamp with microsecond precision
- ``level``      — severity string (DEBUG / INFO / WARNING / ERROR / CRITICAL)
- ``service``    — the service name supplied at construction time
- ``message``    — the human-readable log message
- ``request_id`` — optional; included only when provided by the caller
- ``error``      — optional; stringified exception when ``error=`` is supplied
- ``extra``      — optional; any additional key/value pairs supplied by the caller
"""

from __future__ import annotations

import json
import logging
import sys
import traceback
from datetime import datetime, timezone
from enum import IntEnum
from pathlib import Path
from typing import Any, TextIO


class LogLevel(IntEnum):
    """Numeric severity levels, intentionally aligned with the stdlib ``logging`` constants."""

    DEBUG = logging.DEBUG        # 10
    INFO = logging.INFO          # 20
    WARNING = logging.WARNING    # 30
    ERROR = logging.ERROR        # 40
    CRITICAL = logging.CRITICAL  # 50


# Map LogLevel → label written to the JSON ``level`` field.
_LEVEL_LABELS: dict[LogLevel, str] = {
    LogLevel.DEBUG: "DEBUG",
    LogLevel.INFO: "INFO",
    LogLevel.WARNING: "WARNING",
    LogLevel.ERROR: "ERROR",
    LogLevel.CRITICAL: "CRITICAL",
}


class OpsLogger:
    """Structured, context-aware JSON logger for Python backend services.

    Args:
        service_name: A human-readable identifier for the producing service or
            component. Included in every log entry under the ``service`` key.
        min_level: Minimum severity that will be emitted. Messages below this
            level are silently discarded. Defaults to ``LogLevel.DEBUG`` (log
            everything).
        console: Whether to write log entries to *stderr*. Defaults to ``True``.
        log_file: Optional filesystem path. When supplied, log entries are
            **also** appended to this file (UTF-8, one JSON object per line).

    Example::

        log = OpsLogger(service_name="PaymentService", min_level=LogLevel.INFO)
        log.info("Charge authorised", extra={"amount": 99.99, "currency": "USD"})
    """

    def __init__(
        self,
        service_name: str,
        *,
        min_level: LogLevel = LogLevel.DEBUG,
        console: bool = True,
        log_file: str | Path | None = None,
    ) -> None:
        if not service_name or not isinstance(service_name, str):
            raise ValueError("service_name must be a non-empty string.")

        self._service = service_name
        self._min_level = min_level
        self._outputs: list[TextIO] = []

        if console:
            self._outputs.append(sys.stderr)

        if log_file is not None:
            path = Path(log_file)
            path.parent.mkdir(parents=True, exist_ok=True)
            # Keep the file handle open for the lifetime of this logger.
            self._file_handle: TextIO | None = path.open("a", encoding="utf-8")
            self._outputs.append(self._file_handle)
        else:
            self._file_handle = None

    # ──────────────────────────────────────────────────────────────────────────
    # Public logging methods
    # ──────────────────────────────────────────────────────────────────────────

    def debug(
        self,
        message: str,
        *,
        request_id: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        """Emit a DEBUG-level log entry.

        Use for verbose, diagnostic information that is only meaningful during
        active development or troubleshooting.

        Args:
            message: Human-readable description of the event.
            request_id: Optional request / trace identifier for correlation.
            extra: Optional mapping of additional structured fields.
        """
        self._emit(LogLevel.DEBUG, message, request_id=request_id, extra=extra)

    def info(
        self,
        message: str,
        *,
        request_id: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        """Emit an INFO-level log entry.

        Use for normal operational events such as service startup, user actions,
        or successful completions.

        Args:
            message: Human-readable description of the event.
            request_id: Optional request / trace identifier for correlation.
            extra: Optional mapping of additional structured fields.
        """
        self._emit(LogLevel.INFO, message, request_id=request_id, extra=extra)

    def warning(
        self,
        message: str,
        *,
        request_id: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        """Emit a WARNING-level log entry.

        Use for recoverable issues or degraded conditions that do not halt
        execution but should be investigated.

        Args:
            message: Human-readable description of the event.
            request_id: Optional request / trace identifier for correlation.
            extra: Optional mapping of additional structured fields.
        """
        self._emit(LogLevel.WARNING, message, request_id=request_id, extra=extra)

    # Convenience alias matching Python stdlib naming.
    warn = warning

    def error(
        self,
        message: str,
        *,
        error: BaseException | None = None,
        request_id: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        """Emit an ERROR-level log entry, optionally capturing exception details.

        Use for unexpected failures that require prompt investigation. When
        ``error`` is supplied the entry includes both a short ``error`` string
        and a full ``traceback`` field (if the exception carries traceback info).

        Args:
            message: Human-readable description of the failure.
            error: The exception instance to capture, if any.
            request_id: Optional request / trace identifier for correlation.
            extra: Optional mapping of additional structured fields.
        """
        self._emit(
            LogLevel.ERROR,
            message,
            error=error,
            request_id=request_id,
            extra=extra,
        )

    def critical(
        self,
        message: str,
        *,
        error: BaseException | None = None,
        request_id: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        """Emit a CRITICAL-level log entry.

        Use for catastrophic failures that may require the process to terminate
        (e.g. unrecoverable data corruption, infrastructure outage).

        Args:
            message: Human-readable description of the critical event.
            error: The exception instance to capture, if any.
            request_id: Optional request / trace identifier for correlation.
            extra: Optional mapping of additional structured fields.
        """
        self._emit(
            LogLevel.CRITICAL,
            message,
            error=error,
            request_id=request_id,
            extra=extra,
        )

    # ──────────────────────────────────────────────────────────────────────────
    # Runtime configuration helpers
    # ──────────────────────────────────────────────────────────────────────────

    def set_min_level(self, level: LogLevel) -> None:
        """Change the minimum log level at runtime.

        Args:
            level: The new minimum ``LogLevel``. Entries below this severity
                will be silently discarded.
        """
        if not isinstance(level, LogLevel):
            raise TypeError(f"Expected a LogLevel instance, got {type(level).__name__!r}.")
        self._min_level = level

    def close(self) -> None:
        """Release any open file handles held by this logger.

        Call this explicitly when the logger is no longer needed, or use the
        logger as a context manager to have it called automatically::

            with OpsLogger("MyService", log_file="app.log") as log:
                log.info("inside context")
        """
        if self._file_handle is not None:
            try:
                self._file_handle.close()
            except OSError:
                pass
            self._file_handle = None

    def __enter__(self) -> "OpsLogger":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # ──────────────────────────────────────────────────────────────────────────
    # Internal helpers
    # ──────────────────────────────────────────────────────────────────────────

    def _emit(
        self,
        level: LogLevel,
        message: str,
        *,
        error: BaseException | None = None,
        request_id: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        """Build and write a single JSON log entry to all configured outputs.

        This method is the single chokepoint for all log writes. It:

        1. Guards against the minimum level threshold.
        2. Builds the structured ``entry`` dict.
        3. Serialises it to JSON (with a compact fallback on serialisation errors).
        4. Writes to every configured output, one line per entry.
        """
        if level < self._min_level:
            return

        entry: dict[str, Any] = {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(timespec="microseconds"),
            "level": _LEVEL_LABELS[level],
            "service": self._service,
            "message": str(message),
        }

        if request_id:
            entry["request_id"] = request_id

        if error is not None:
            entry["error"] = f"{type(error).__name__}: {error}"
            tb = traceback.format_tb(error.__traceback__)
            if tb:
                entry["traceback"] = "".join(tb).strip()

        if extra:
            # Shallow-copy so mutations by the caller don't affect the entry.
            entry["extra"] = dict(extra)

        try:
            line = json.dumps(entry, default=str, ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            # Last-resort fallback — emit something rather than silently failing.
            line = json.dumps(
                {
                    "timestamp": entry["timestamp"],
                    "level": "ERROR",
                    "service": self._service,
                    "message": "opslogger: failed to serialise log entry",
                    "error": str(exc),
                }
            )

        for output in self._outputs:
            try:
                output.write(line + "\n")
                output.flush()
            except OSError:
                # Never let a logging failure crash the application.
                pass
