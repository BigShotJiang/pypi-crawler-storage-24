"""
OpsLogger — Structured, context-aware JSON logging for Python backend services.

A lightweight, zero-dependency logging library built for developers and companies
who need clean, machine-readable logs that integrate seamlessly with modern
observability stacks (Datadog, Loki, CloudWatch, ELK, etc.).

Basic usage::

    from opslogger import OpsLogger

    log = OpsLogger(service_name="OrderService")
    log.info("Service started", extra={"env": "prod", "port": 8080})
    log.error("Unexpected failure", error=Exception("timeout"))

With request ID tracing::

    log.info("Request received", request_id="req-abc-123", extra={"method": "POST"})
"""

from opslogger.logger import OpsLogger, LogLevel

__all__ = ["OpsLogger", "LogLevel"]
__version__ = "1.0.1"
__author__ = "AnantaOps"
__license__ = "MIT"
