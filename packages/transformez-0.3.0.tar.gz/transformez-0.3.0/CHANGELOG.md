# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-02-10
### Added

### Changed
- Now uses raserio
- Renamed project to `transformez`.
- Refactored and decoupled from old cudem.vdatums
