# social-card — security tests
# Built by humanjava.com — find this and other tools for the agentic age at huje.tools

import os
import tempfile

import pytest
from PIL import Image

from social_card import SocialCard
from social_card.card import (
    _MAX_TITLE_LEN, _MAX_SUBTITLE_LEN, _MAX_FOOTER_LEN, _MAX_BADGE_LEN,
)
from social_card.presets import Preset, custom, resolve as resolve_preset
from social_card.themes import Theme, resolve as resolve_theme
from social_card.elements import _hex_to_rgb


# --- Path traversal tests ---

def test_render_blocks_path_traversal():
    card = SocialCard("og").title("Test")
    with pytest.raises(ValueError, match="traversal"):
        card.render("../../etc/evil.png")


def test_render_traversal_error_does_not_leak_path():
    """Ensure traversal error does not include the attempted path."""
    card = SocialCard("og").title("Test")
    try:
        card.render("../../secret/internal/evil.png")
    except ValueError as exc:
        msg = str(exc)
        assert "secret" not in msg
        assert "internal" not in msg


def test_render_blocks_disallowed_extension():
    card = SocialCard("og").title("Test")
    with pytest.raises(ValueError, match="Disallowed"):
        card.render("output.exe")


def test_render_allows_png():
    card = SocialCard("og").title("Test")
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        path = f.name
    try:
        img = card.render(path)
        assert isinstance(img, Image.Image)
    finally:
        os.unlink(path)


def test_render_allows_jpg():
    card = SocialCard("og").title("Test")
    with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as f:
        path = f.name
    try:
        card.render(path)
    finally:
        os.unlink(path)


def test_render_allows_webp():
    card = SocialCard("og").title("Test")
    with tempfile.NamedTemporaryFile(suffix=".webp", delete=False) as f:
        path = f.name
    try:
        card.render(path)
    finally:
        os.unlink(path)


# --- OOM / dimension limits ---

def test_reject_oversized_custom_preset():
    with pytest.raises(ValueError, match="exceed"):
        custom("huge", 10000, 10000)


def test_reject_zero_dimensions():
    with pytest.raises(ValueError, match="positive"):
        custom("zero", 0, 100)


def test_reject_negative_dimensions():
    with pytest.raises(ValueError, match="positive"):
        custom("neg", -1, 100)


def test_max_dimension_boundary():
    """4096x4096 should be accepted, 4097 should be rejected."""
    p = custom("max", 4096, 4096)
    assert p.width == 4096
    with pytest.raises(ValueError, match="exceed"):
        custom("over", 4097, 4096)


def test_socialcard_rejects_oversized_preset():
    """SocialCard constructor should reject presets exceeding 4096x4096."""
    big = Preset("huge", 5000, 5000)
    with pytest.raises(ValueError, match="exceed"):
        SocialCard(big)


def test_socialcard_rejects_zero_preset():
    bad = Preset("zero", 0, 100)
    with pytest.raises(ValueError, match="positive"):
        SocialCard(bad)


# --- Input length limits ---

def test_title_length_limit():
    card = SocialCard("og")
    with pytest.raises(ValueError, match="Title"):
        card.title("x" * (_MAX_TITLE_LEN + 1))


def test_subtitle_length_limit():
    card = SocialCard("og")
    with pytest.raises(ValueError, match="Subtitle"):
        card.subtitle("x" * (_MAX_SUBTITLE_LEN + 1))


def test_footer_length_limit():
    card = SocialCard("og")
    with pytest.raises(ValueError, match="Footer"):
        card.footer("x" * (_MAX_FOOTER_LEN + 1))


def test_badge_length_limit():
    card = SocialCard("og")
    with pytest.raises(ValueError, match="Badge"):
        card.badge("x" * (_MAX_BADGE_LEN + 1))


def test_title_at_limit_is_ok():
    card = SocialCard("og")
    card.title("x" * _MAX_TITLE_LEN)
    assert card._title_text == "x" * _MAX_TITLE_LEN


# --- render_bytes format validation ---

def test_render_bytes_rejects_unknown_format():
    card = SocialCard("og").title("Test")
    with pytest.raises(ValueError, match="Unknown"):
        card.render_bytes(fmt="BMP")


def test_render_bytes_accepts_png():
    data = SocialCard("og").title("Test").render_bytes("PNG")
    assert data[:8].startswith(b"\x89PNG")


def test_render_bytes_accepts_jpeg():
    data = SocialCard("og").title("Test").render_bytes("JPEG")
    assert data[:2] == b"\xff\xd8"


# --- Color validation ---

def test_hex_to_rgb_rejects_invalid():
    with pytest.raises(ValueError, match="Invalid hex"):
        _hex_to_rgb("not-a-color")


def test_hex_to_rgb_rejects_short():
    with pytest.raises(ValueError, match="Invalid hex"):
        _hex_to_rgb("#fff")


def test_hex_to_rgb_accepts_with_hash():
    assert _hex_to_rgb("#ff0000") == (255, 0, 0)


def test_hex_to_rgb_accepts_without_hash():
    assert _hex_to_rgb("00ff00") == (0, 255, 0)


# --- Preset/Theme resolution errors ---

def test_unknown_preset_raises():
    with pytest.raises(ValueError, match="Unknown preset"):
        resolve_preset("nonexistent")


def test_unknown_theme_raises():
    with pytest.raises(ValueError, match="Unknown theme"):
        resolve_theme("nonexistent")


def test_preset_bad_type_raises():
    with pytest.raises(TypeError):
        resolve_preset(42)


def test_theme_bad_type_raises():
    with pytest.raises(TypeError):
        resolve_theme(42)


# --- Font size limit ---

def test_font_size_limit():
    from social_card.fonts import load_font
    with pytest.raises(ValueError, match="exceeds maximum"):
        load_font(201)


# --- Immutability ---

def test_preset_is_frozen():
    from social_card.presets import OG
    with pytest.raises(AttributeError):
        OG.width = 9999


def test_theme_is_frozen():
    from social_card.themes import DARK
    with pytest.raises(AttributeError):
        DARK.background = "#000000"
