#!/usr/bin/env python3
"""
Interrogate Parser - Documentation Coverage Analysis.
======================================================

Interrogate measures documentation coverage in Python code by analyzing
docstrings. It counts docstrings and reports the percentage of coverage
for functions, classes, and methods. This module provides structured
parsing of Interrogate output.

Implementation Status: NOT IMPLEMENTED
Priority: P3 - MEDIUM

============================================================================
============================================================================
COMMUNITY TIER - Documentation Coverage (P0-P2) [NOT IMPLEMENTED]
============================================================================

[P0_CRITICAL] Basic Coverage Analysis:
    - Parse Interrogate JSON output
    - Calculate documentation coverage percentage
    - Identify undocumented functions
    - Identify undocumented classes
    - Identify undocumented methods
    - Module-level documentation tracking
    - Test count: 40 tests

[P1_HIGH] Docstring Quality:
    - Docstring style detection (Google, NumPy, Sphinx)
    - Parameter documentation checking
    - Return value documentation checking
    - Exception documentation checking
    - Test count: 45 tests

[P2_MEDIUM] Coverage Reporting:
    - Per-file coverage metrics
    - Per-module coverage aggregation
    - Coverage trend tracking
    - Missing documentation identification
    - Test count: 35 tests

[P2_MEDIUM] Configuration:
    - pyproject.toml configuration
    - Coverage threshold settings
    - Exclusion patterns
    - Style guide enforcement
    - Test count: 25 tests

============================================================================
PRO TIER - Advanced Documentation Analysis (P1-P3)
============================================================================

[P1_HIGH] Docstring Quality Metrics:
    - Docstring completeness scoring
    - Example code validation
    - Cross-reference checking
    - Link validation
    - Test count: 50 tests

[P1_HIGH] API Documentation:
    - Public API documentation requirements
    - Private API documentation tracking
    - Deprecation notice detection
    - Version documentation
    - Test count: 45 tests

[P2_MEDIUM] Advanced Quality Checks:
    - Docstring spelling and grammar
    - Code example execution
    - Doctest integration
    - Type hint documentation consistency
    - Test count: 40 tests

[P3_LOW] Documentation Generation:
    - Auto-generate skeleton docstrings
    - Sphinx documentation integration
    - ReadTheDocs compatibility
    - Test count: 35 tests

============================================================================
ENTERPRISE TIER - Enterprise Documentation Management (P2-P4)
============================================================================

[P2_MEDIUM] Multi-Project Documentation:
    - Workspace-wide documentation coverage
    - Shared library documentation standards
    - Cross-project documentation linking
    - Test count: 45 tests

[P2_MEDIUM] Compliance and Standards:
    - Documentation policy enforcement
    - Mandatory documentation requirements
    - Industry-specific documentation standards
    - Test count: 40 tests

[P3_LOW] Documentation Quality Gates:
    - CI/CD documentation gates
    - Documentation SLA tracking
    - Documentation review workflows
    - Test count: 35 tests

[P3_LOW] Advanced Reporting:
    - Documentation quality dashboards
    - Documentation debt tracking
    - Documentation improvement planning
    - Test count: 30 tests

============================================================================
TOTAL TEST ESTIMATE: 465 tests (145 COMMUNITY + 170 PRO + 150 ENTERPRISE)
============================================================================

==============================================================================
PLANNED [P3-INTERROGATE-001]: InterrogateParser for documentation coverage
==============================================================================
Priority: MEDIUM
Status: ⏳ NOT IMPLEMENTED

Planned Features:
    - [ ] Parse Interrogate JSON output format
    - [ ] Calculate docstring coverage percentage
    - [ ] Identify undocumented functions, classes, methods
    - [ ] Track missing docstrings
    - [ ] Support module-level and nested documentation
    - [ ] Generate coverage reports
    - [ ] Configuration file support

    Interrogate produces JSON with coverage metrics:
    ```json
    {
        "total_items": 25,
        "total_documented": 20,
        "total_skipped": 0,
        "perc_covered": 80.0,
        "file_results": {
            "example.py": {
                "total_items": 10,
                "total_documented": 8,
                "total_skipped": 0,
                "perc_covered": 80.0,
                "items": [
                    {
                        "name": "MyClass",
                        "type": "class",
                        "lineno": 5,
                        "docstring": true
                    },
                    {
                        "name": "undocumented_function",
                        "type": "function",
                        "lineno": 15,
                        "docstring": false
                    }
                ]
            }
        }
    }
    ```

Data Structures (Planned):
    ```python
    @dataclass
    class DocumentedItem:
        name: str
        item_type: str  # "function", "class", "method", "module"
        location: SourceLocation
        has_docstring: bool
        docstring_type: str | None  # "numpy", "google", "sphinx", "rest"
        docstring_length: int  # Characters in docstring

    @dataclass
    class DocumentationCoverage:
        total_items: int
        documented_items: int
        coverage_percentage: float
        undocumented: list[DocumentedItem]

    @dataclass
    class InterrogateReport:
        file_path: str
        coverage: DocumentationCoverage
        items: list[DocumentedItem]
        error: str | None
    ```

Test Cases (Planned):
    - Calculate documentation coverage
    - Identify undocumented items
    - Detect different docstring styles
    - Verify module-level coverage
    - Test class and method documentation

    - [ ] Load from pyproject.toml [tool.interrogate]
    - [ ] Load from setup.cfg [interrogate]
    - [ ] Support --ignore-patterns parameter
    - [ ] Support --docstring-style parameter

Related Features:
    - Complements pydocstyle's documentation validation
    - Works with AST parser for structure analysis
    - Useful for documentation compliance
    - Important for API documentation coverage

Notes for Implementation:
    - Different docstring styles (NumPy, Google, Sphinx, etc.)
    - Can exclude specific patterns from checks
    - Useful for enforcing documentation standards
    - Can integrate with CI/CD for coverage gates
    - Helps maintain API documentation

API Design (Planned):
    ```python
    class InterrogateParser:
        def __init__(self, min_coverage: float = 80.0):
            self.min_coverage = min_coverage

        def analyze_file(self, path: str) -> InterrogateReport:
            '''Analyze documentation coverage in a file.'''
            pass

        def analyze_code(self, code: str, filename: str = "<string>") -> InterrogateReport:
            '''Analyze documentation coverage in code string.'''
            pass

        def get_coverage_percentage(self, report: InterrogateReport) -> float:
            '''Get coverage percentage from report.'''
            pass
    ```
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SourceLocation:
    """Location in source code."""

    line: int
    column: int = 0
    end_line: int | None = None
    end_column: int | None = None


@dataclass
class DocumentedItem:
    """Represents a potentially documentable item (function, class, method)."""

    name: str
    item_type: str  # "function", "class", "method", "module", "property"
    location: SourceLocation
    has_docstring: bool
    docstring_length: int = 0
    docstring_style: str | None = None  # "numpy", "google", "sphinx", "rest"
    is_dunder: bool = False  # Special method like __init__
    is_private: bool = False  # Starts with _

    @property
    def documentation_status(self) -> str:
        """Get documentation status."""
        if self.is_dunder or self.is_private:
            return "optional"
        return "documented" if self.has_docstring else "missing"


@dataclass
class DocumentationCoverage:
    """Aggregated documentation coverage metrics."""

    total_items: int
    documented_items: int
    skipped_items: int = 0

    @property
    def coverage_percentage(self) -> float:
        """Calculate coverage percentage."""
        if self.total_items == 0:
            return 100.0
        return (self.documented_items / self.total_items) * 100.0

    @property
    def status(self) -> str:
        """Get coverage status (Excellent, Good, Fair, Poor)."""
        pct = self.coverage_percentage
        if pct >= 90:
            return "Excellent"
        elif pct >= 75:
            return "Good"
        elif pct >= 50:
            return "Fair"
        else:
            return "Poor"


@dataclass
class InterrogateConfig:
    """Configuration for Interrogate parser."""

    min_coverage: float = 80.0  # Minimum acceptable coverage percentage
    ignore_patterns: list[str] = field(default_factory=list)
    docstring_style: str = "auto"  # auto, numpy, google, sphinx, rest
    include_private: bool = True
    include_dunder: bool = False

    @classmethod
    def from_pyproject(cls, pyproject_path: str | Path) -> "InterrogateConfig":
        """Load configuration from pyproject.toml."""
        return cls()


@dataclass
class InterrogateReport:
    """Results from Interrogate documentation coverage analysis."""

    file_path: str | None = None
    coverage: DocumentationCoverage = field(
        default_factory=lambda: DocumentationCoverage(0, 0)
    )
    items: list[DocumentedItem] = field(default_factory=list)
    error: str | None = None
    interrogate_version: str | None = None

    @property
    def undocumented_items(self) -> list[DocumentedItem]:
        """Get list of items missing documentation."""
        return [item for item in self.items if not item.has_docstring]

    @property
    def is_coverage_acceptable(self) -> bool:
        """Check if coverage meets minimum threshold."""
        # [20260120_BUGFIX] Use a conservative default threshold until config is wired.
        # InterrogateConfig defaults to 80%, but we don't have config access on the report,
        # so use the same default here to keep behavior predictable and satisfy static checks.
        return self.coverage.coverage_percentage >= 80.0

    @property
    def summary(self) -> str:
        """Get human-readable coverage summary."""
        return (
            f"Documentation coverage: {self.coverage.coverage_percentage:.1f}% "
            f"({self.coverage.documented_items}/{self.coverage.total_items} documented)"
        )


class InterrogateParser:
    """
    Parser for documentation coverage using Interrogate.

    STATUS: NOT IMPLEMENTED
    PRIORITY: P3 - MEDIUM

    Features (Planned):
        - Measure documentation coverage percentage
        - Identify undocumented items
        - Detect docstring styles
        - Support for different document types
        - Configuration support

        - Implement analyze_file() method
        - Implement analyze_code() method
        - Add JSON parsing
        - Implement coverage calculation
        - Add configuration support
    """

    def __init__(self, config: InterrogateConfig | None = None):
        """
        Initialize Interrogate parser.

        Args:
            config: InterrogateConfig instance or None to use defaults
        """
        self.config = config or InterrogateConfig()

    def analyze_file(self, file_path: str | Path) -> InterrogateReport:
        """
        Analyze documentation coverage in a Python file.

        Args:
            file_path: Path to Python file

        Returns:
            InterrogateReport with coverage analysis

        """
        # [20260303_FEATURE] run interrogate, build InterrogateReport from JSON
        path = Path(file_path)
        results = self.execute_interrogate(str(path))
        report_data = results[0] if results else {}
        cov = DocumentationCoverage(
            total_items=report_data.get("total_items", 0),
            documented_items=report_data.get("documented_items", 0),
        )
        items: list[DocumentedItem] = []
        for m in report_data.get("missing", []):
            parts = m.split(":", 1)
            itype = parts[0] if len(parts) == 2 else "function"
            name = parts[1] if len(parts) == 2 else m
            items.append(
                DocumentedItem(
                    name=name,
                    item_type=itype,
                    location=SourceLocation(line=0),
                    has_docstring=False,
                )
            )
        return InterrogateReport(file_path=str(path), coverage=cov, items=items)

    def analyze_code(self, code: str, filename: str = "<string>") -> InterrogateReport:
        """
        Analyze documentation coverage in Python code string.

        Args:
            code: Python source code
            filename: Filename for error reporting

        Returns:
            InterrogateReport with coverage analysis

        """
        # [20260303_FEATURE] write to temp file then analyze
        fd, tmp = tempfile.mkstemp(suffix=".py")
        try:
            os.write(fd, code.encode())
            os.close(fd)
            report = self.analyze_file(tmp)
            report.file_path = filename
            return report
        finally:
            os.unlink(tmp)

    # -------------------------------------------------------------------------
    # [20260303_FEATURE] New methods added per Stage 4a spec
    # -------------------------------------------------------------------------

    def execute_interrogate(self, path: str = ".") -> list[dict]:
        """Run interrogate --output-format json on path; return [] if not available."""
        if not shutil.which("interrogate"):
            return []
        result = subprocess.run(
            ["interrogate", path, "--output-format", "json"],
            capture_output=True,
            text=True,
        )
        return self.parse_json_output(result.stdout or result.stderr)

    def parse_json_output(self, output: str) -> list[dict]:
        """Parse interrogate JSON output into list of dicts."""
        try:
            data = json.loads(output)
        except (json.JSONDecodeError, ValueError):
            return []
        if isinstance(data, list):
            return data  # type: ignore[return-value]
        if isinstance(data, dict):
            return [data]
        return []

    def get_coverage_summary(self, results: list[dict]) -> dict:
        """Summarise coverage across all files in results."""
        if not results:
            return {"total_files": 0, "avg_coverage": 0.0, "files": []}
        coverages = [float(r.get("docstring_coverage", 0.0)) for r in results]
        return {
            "total_files": len(results),
            "avg_coverage": sum(coverages) / len(coverages),
            "files": [r.get("filename", "") for r in results],
        }

    def list_missing_docstrings(self, results: list[dict]) -> list[str]:
        """Flatten all missing docstring descriptions from results."""
        missing: list[str] = []
        for r in results:
            missing.extend(r.get("missing", []))
        return missing

    def generate_report(self, findings: list[dict], format: str = "json") -> str:
        """Return JSON report of documentation coverage."""
        summary = self.get_coverage_summary(findings)
        return json.dumps(
            {
                "tool": "interrogate",
                "total": summary["total_files"],
                "avg_coverage": summary["avg_coverage"],
            },
            indent=2,
        )

    def get_coverage_percentage(self, report: InterrogateReport) -> float:
        """
        Get documentation coverage percentage from report.

        Args:
            report: InterrogateReport from analysis

        Returns:
            Coverage percentage (0-100)
        """
        return report.coverage.coverage_percentage

    def is_acceptable_coverage(
        self,
        report: InterrogateReport,
        min_coverage: float | None = None,
    ) -> bool:
        """
        Check if coverage meets minimum threshold.

        Args:
            report: InterrogateReport to check
            min_coverage: Minimum acceptable percentage (uses config if None)

        Returns:
            True if coverage is acceptable
        """
        threshold = min_coverage or self.config.min_coverage
        return report.coverage.coverage_percentage >= threshold
