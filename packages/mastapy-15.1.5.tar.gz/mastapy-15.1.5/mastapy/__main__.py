"""Command line entry point for mastapy."""

import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import List


def detect_plugins() -> "List[str]":
    """Detect which plugins are installed for the user.

    Returns:
        A list of the installed plugins as descriptive strings.
    """
    import contextlib
    import itertools
    import site
    from pathlib import Path

    site_packages = site.getsitepackages()
    mastapy_cli_packages = itertools.chain.from_iterable(
        filter(lambda p: p.name.startswith("mastapy_cli_"), Path(path).iterdir())
        for path in site_packages
    )
    found_plugins = (path.name for path in mastapy_cli_packages)

    result = []

    for plugin in found_plugins:
        with contextlib.suppress(ImportError):
            imported_plugin = __import__(plugin)

            plugin_name = plugin.replace("mastapy_cli_", "")
            plugin_description = imported_plugin.__doc__
            plugin_version = imported_plugin.__version__

            desc = (
                f"    [green]{plugin_name}[/] ({plugin_version}): {plugin_description}"
            )
            result.append(desc)

    return result


def get_plugin_description() -> str:
    """Print a list of the plugins.

    Returns:
        A string listing all the available plugins.
    """
    installed_plugins = detect_plugins()

    if len(installed_plugins) == 0:
        result = (
            "[dark_orange]You have not installed any plugins yet![/]\n\n"
            "Check the mastapy project description on PyPI "
            "(https://pypi.org/project/mastapy/) for a list of available plugins to "
            "install. You can install plugins using the extras syntax with pip (e.g. "
            r"[bright_black]pip install mastapy\[cli-regression][/])"
        )
    else:
        result = "The following plugins are available:\n\n"
        result += "\n".join(installed_plugins)
        result += (
            "\n\nLaunch a plugin using the following syntax:\n\n"
            "    [bright_black]mastapy TOOL ...[/]"
        )

    return result


def print_version() -> None:
    """Print the version string."""
    from . import __version__

    print(f"mastapy {__version__}")


def print_help() -> None:
    """Print the help text."""
    from rich import print

    description = "A command-line interface for launching mastapy plugins.\n\n"
    description += get_plugin_description()

    print(description)


def print_missing_plugin(plugin_name: str) -> None:
    """Print the plugin missing text.

    Args:
        plugin_name (str): Name of the missing plugin.
    """
    from rich import print

    error = f"[red]Plugin not found:[/] {plugin_name}\n\n"
    error += get_plugin_description()
    print(error)


def main() -> None:
    """Main entry point for the command line."""
    try:
        arg_value = sys.argv[1]
    except IndexError:
        print_help()
        return

    plugin = None

    try:
        plugin = __import__(f"mastapy_cli_{arg_value}")
    except ImportError:
        if arg_value == "--help" or arg_value == "-h":
            print_help()
        elif arg_value == "--version" or arg_value == "-V":
            print_version()
        else:
            print_missing_plugin(arg_value)
            sys.exit(1)

    if plugin is not None:
        plugin.run(sys.argv[2:])


if __name__ == "__main__":
    main()
