"""
wechat_automator 工具：自动化交互聚合。

合并所有自动化 + 运行时查询工具（13 个 action）。
含内部必填参数校验，缺失时返回结构化错误指导。
"""
import asyncio
import os
import sys
import subprocess
import tempfile
from typing import TYPE_CHECKING

from ..core.cli import _resolve_project_path
from ..core.config import CLI_PATH, DEFAULT_PROJECT_PATH
from ..core.errors import ErrorCode
from ..core.node_bridge import _run_node_script
from ..models.schemas import WechatAutomatorInput
from ..utils.response import _ok, _fail

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

# 各 action 的必填参数映射
REQUIRED_PARAMS: dict[str, list[str]] = {
    "tap":          ["selector"],
    "input":        ["selector", "value"],
    "element_info": ["selector"],
    "set_data":     ["data_json"],
    "call_method":  ["method"],
    "call_wx":      ["method"],
    "mock_wx":      ["method", "result_json"],
    "evaluate":     ["expression"],
}


def register_automator(mcp: "FastMCP") -> None:
    """将 wechat_automator 工具注册到 FastMCP 实例。"""
    mcp.tool(
        name="wechat_automator",
        annotations={
            "title": "自动化交互",
            "readOnlyHint": False,
            "destructiveHint": False,
            "idempotentHint": False,
            "openWorldHint": False,
        },
    )(wechat_automator)


async def wechat_automator(params: WechatAutomatorInput) -> str:
    """小程序自动化交互与运行时查询。
    支持 action: start(开启自动化), tap(点击), input(输入),
    element_info(元素信息), set_data(设置数据), call_method(调用方法),
    call_wx(调用wx API), mock_wx(Mock wx), evaluate(执行JS),
    page_stack(页面栈), page_data(页面数据), system_info(系统信息),
    storage(缓存)。
    返回 JSON: {success, data, message, error_code?}。
    """
    # 必填参数校验
    missing = [
        p for p in REQUIRED_PARAMS.get(params.action, [])
        if getattr(params, p) is None
    ]
    if missing:
        return _fail(
            ErrorCode.PARAM_MISSING,
            f"action='{params.action}' 缺少必填参数: {', '.join(missing)}",
            hint=f"请提供以下参数：{', '.join(missing)}",
        )

    try:
        if params.action == "start":
            return await _action_start(params)
        elif params.action == "tap":
            return await _action_tap(params)
        elif params.action == "input":
            return await _action_input(params)
        elif params.action == "element_info":
            return await _action_element_info(params)
        elif params.action == "set_data":
            return await _action_set_data(params)
        elif params.action == "call_method":
            return await _action_call_method(params)
        elif params.action == "call_wx":
            return await _action_call_wx(params)
        elif params.action == "mock_wx":
            return await _action_mock_wx(params)
        elif params.action == "evaluate":
            return await _action_evaluate(params)
        elif params.action == "page_stack":
            return await _action_page_stack(params)
        elif params.action == "page_data":
            return await _action_page_data(params)
        elif params.action == "system_info":
            return await _action_system_info(params)
        elif params.action == "storage":
            return await _action_storage(params)
        return _fail(ErrorCode.UNKNOWN_ERROR, f"未知 action: {params.action}")
    except Exception as e:
        return _fail(ErrorCode.UNKNOWN_ERROR, f"执行失败：{type(e).__name__}: {e}")


async def _action_start(params: WechatAutomatorInput) -> str:
    """开启自动化测试端口（后台启动 CLI auto）。"""
    proj = params.project_path or DEFAULT_PROJECT_PATH
    if not proj:
        return _fail(ErrorCode.PROJECT_PATH_MISSING, "未提供小程序项目路径，无法开启自动化端口。")

    cli = os.environ.get("WECHAT_DEVTOOLS_CLI", CLI_PATH)
    cmd_args = [cli, "auto", "--project", proj, "--auto-port", str(params.auto_port)]
    if params.auto_account:
        cmd_args.extend(["--auto-account", params.auto_account])
    if sys.platform == "win32" and cli.lower().endswith(".bat"):
        cmd_args = ["cmd", "/c"] + cmd_args

    try:
        subprocess.Popen(
            cmd_args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        )
        await asyncio.sleep(3)
        return _ok({"port": params.auto_port}, message=f"自动化端口已在后台启动，监听端口 {params.auto_port}。")
    except FileNotFoundError:
        return _fail(ErrorCode.CLI_NOT_FOUND, f"找不到微信开发者工具 CLI：{cli}")
    except Exception as e:
        return _fail(ErrorCode.UNKNOWN_ERROR, str(e))


async def _action_tap(params: WechatAutomatorInput) -> str:
    result = await _run_node_script("automation.js", "--port", str(params.auto_port), "--action", "tap", "--selector", params.selector)
    if result.get("success"):
        return _ok({"selector": params.selector}, message=f"已点击元素：{params.selector}")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "点击失败"))


async def _action_input(params: WechatAutomatorInput) -> str:
    result = await _run_node_script("automation.js", "--port", str(params.auto_port), "--action", "input", "--selector", params.selector, "--value", params.value)
    if result.get("success"):
        return _ok({"selector": params.selector, "value": params.value}, message="输入成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "输入失败"))


async def _action_element_info(params: WechatAutomatorInput) -> str:
    args = ["--port", str(params.auto_port), "--action", "elementInfo", "--selector", params.selector]
    if params.style_prop:
        args.extend(["--prop", params.style_prop])
    result = await _run_node_script("automation.js", *args)
    if result.get("success"):
        return _ok({"element": result.get("element", {})}, message="获取元素信息成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "获取元素信息失败"))


async def _action_set_data(params: WechatAutomatorInput) -> str:
    result = await _run_node_script("automation.js", "--port", str(params.auto_port), "--action", "setData", "--data", params.data_json)
    if result.get("success"):
        return _ok({"path": result.get("path"), "updated_keys": result.get("updatedKeys", [])}, message="页面数据已更新。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "设置数据失败"))


async def _action_call_method(params: WechatAutomatorInput) -> str:
    args = ["--port", str(params.auto_port), "--action", "callMethod", "--method", params.method]
    if params.args_json:
        args.extend(["--args", params.args_json])
    result = await _run_node_script("automation.js", *args)
    if result.get("success"):
        return _ok({"method": params.method, "return_value": result.get("returnValue")}, message=f"方法 {params.method} 调用成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "方法调用失败"))


async def _action_call_wx(params: WechatAutomatorInput) -> str:
    args = ["--port", str(params.auto_port), "--action", "callWx", "--method", params.method]
    if params.args_json:
        args.extend(["--args", params.args_json])
    result = await _run_node_script("automation.js", *args)
    if result.get("success"):
        return _ok({"method": params.method, "return_value": result.get("returnValue")}, message=f"wx.{params.method} 调用成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "wx API 调用失败"))


async def _action_mock_wx(params: WechatAutomatorInput) -> str:
    result = await _run_node_script("automation.js", "--port", str(params.auto_port), "--action", "mockWx", "--method", params.method, "--result", params.result_json)
    if result.get("success"):
        return _ok({"method": params.method}, message=f"wx.{params.method} Mock 成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "Mock 失败"))


async def _action_evaluate(params: WechatAutomatorInput) -> str:
    result = await _run_node_script("ui_debug.js", "--port", str(params.auto_port), "--action", "evaluate", "--code", params.expression)
    if result.get("success"):
        return _ok({"result": result.get("result")}, message="表达式执行成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "执行失败"))


async def _action_page_stack(params: WechatAutomatorInput) -> str:
    result = await _run_node_script("automation.js", "--port", str(params.auto_port), "--action", "pageStack")
    if result.get("success"):
        return _ok({"depth": result.get("depth", 0), "pages": result.get("pages", [])}, message="获取页面栈成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "获取页面栈失败"))


async def _action_page_data(params: WechatAutomatorInput) -> str:
    result = await _run_node_script("ui_debug.js", "--port", str(params.auto_port), "--action", "data")
    if result.get("success"):
        return _ok({"path": result.get("path", ""), "data": result.get("data", {})}, message="获取页面数据成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "获取页面数据失败"))


async def _action_system_info(params: WechatAutomatorInput) -> str:
    system_info_script = """module.exports = async function(miniProgram) {
  const info = await miniProgram.systemInfo();
  return info;
};"""
    tmp_path = os.path.join(tempfile.gettempdir(), "wechat_mcp_sysinfo.js")
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(system_info_script)
    except Exception as e:
        return _fail(ErrorCode.UNKNOWN_ERROR, f"写入临时脚本失败: {e}")

    result = await _run_node_script("run_test_script.js", "--port", str(params.auto_port), "--script", tmp_path, "--timeout", "15", timeout=30)
    try:
        os.remove(tmp_path)
    except Exception:
        pass

    if result.get("success"):
        return _ok({"system_info": result.get("script_result", {})}, message="获取系统信息成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "获取系统信息失败"))


async def _action_storage(params: WechatAutomatorInput) -> str:
    args = ["--port", str(params.auto_port), "--action", "storage"]
    if params.key:
        args.extend(["--key", params.key])
    result = await _run_node_script("ui_debug.js", *args)
    if result.get("success"):
        if params.key:
            return _ok({"key": params.key, "value": result.get("value")}, message=f"Storage key '{params.key}' 获取成功。")
        return _ok({
            "keys": result.get("keys", []),
            "current_size": result.get("currentSize"),
            "limit_size": result.get("limitSize"),
        }, message="Storage 信息获取成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("error", "获取 Storage 失败"))
