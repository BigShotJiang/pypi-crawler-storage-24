"""
Node.js 脚本调用封装：检测 Node.js、执行 Bundle 文件。
"""
import asyncio
import json
import os
import sys
from typing import Optional

from .config import _SCRIPTS_DIR, _NODE_PATH as _DEFAULT_NODE_PATH
from .errors import ErrorCode, _make_error

# 模块级缓存
_node_available: Optional[bool] = None
_node_path_cache: Optional[str] = None
_NODE_PATH: str = _DEFAULT_NODE_PATH


async def _check_node_available() -> tuple[bool, str]:
    """检测 Node.js 是否可用，结果缓存到模块级变量。

    Returns:
        tuple[bool, str]: (是否可用, node 路径或空字符串)。
    """
    global _node_available, _node_path_cache, _NODE_PATH

    if _node_available is not None:
        return _node_available, _node_path_cache or ""

    candidates = [_NODE_PATH]
    if sys.platform == "win32":
        candidates += [
            r"C:\Program Files\nodejs\node.exe",
            r"C:\Program Files (x86)\nodejs\node.exe",
            os.path.expandvars(r"%APPDATA%\nvm\current\node.exe"),
            os.path.expandvars(r"%ProgramFiles%\nodejs\node.exe"),
        ]

    for candidate in candidates:
        try:
            process = await asyncio.create_subprocess_exec(
                candidate, "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await asyncio.wait_for(process.communicate(), timeout=10)
            if process.returncode == 0:
                version = stdout.decode("utf-8", errors="replace").strip()
                node_path = candidate if os.path.isabs(candidate) else f"node ({version})"
                _node_available = True
                _node_path_cache = node_path
                if os.path.isabs(candidate) and os.path.exists(candidate):
                    _NODE_PATH = candidate
                return True, node_path
        except Exception:
            continue

    _node_available = False
    _node_path_cache = ""
    return False, ""


async def _run_node_script(
    script_name: str,
    *extra_args: str,
    timeout: int = 120,
) -> dict:
    """调用 scripts/dist/ 目录下的 Bundle 文件，返回解析后的 JSON 结果。

    Args:
        script_name: 脚本文件名（不含路径），例如 'console_listener.js'。
        *extra_args: 传递给脚本的额外命令行参数。
        timeout: 执行超时时间（秒）。

    Returns:
        dict: 脚本输出的 JSON 对象，或包含 error 字段的错误信息。
    """
    global _NODE_PATH

    node_ok, node_path = await _check_node_available()
    if not node_ok:
        return json.loads(_make_error(
            ErrorCode.NODE_NOT_FOUND,
            "未检测到 Node.js，无法执行自动化脚本。",
            hint="请安装 Node.js（>= 8.0）并配置 PATH 环境变量。下载地址：https://nodejs.org/zh-cn/download/",
        ))

    script_stem = os.path.splitext(script_name)[0]
    bundle_path = os.path.join(_SCRIPTS_DIR, "dist", f"{script_stem}.bundle.js")

    if not os.path.exists(bundle_path):
        return {
            "success": False,
            "error": f"找不到 Bundle 文件: {bundle_path}",
        }

    cmd = [_NODE_PATH, bundle_path] + list(extra_args)
    cmd_display = " ".join(cmd)

    process = None
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=_SCRIPTS_DIR,
        )
        stdout, stderr = await asyncio.wait_for(
            process.communicate(), timeout=timeout
        )
        stdout_text = stdout.decode("utf-8", errors="replace").strip()
        stderr_text = stderr.decode("utf-8", errors="replace").strip()

        if stdout_text:
            try:
                return json.loads(stdout_text)
            except json.JSONDecodeError:
                pass

        return {
            "success": process.returncode == 0,
            "stdout": stdout_text,
            "stderr": stderr_text,
            "return_code": process.returncode,
            "command": cmd_display,
        }

    except asyncio.TimeoutError:
        return {
            "success": False,
            "error": f"Node.js 脚本执行超时（{timeout}秒）: {cmd_display}",
        }
    except FileNotFoundError:
        return {
            "success": False,
            "error": (
                f"找不到 Node.js 可执行文件: {_NODE_PATH}\n"
                "请确认已安装 Node.js（>= 8.0），或设置 NODE_PATH 环境变量。"
            ),
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"执行 Node.js 脚本失败: {type(e).__name__}: {e}",
        }
    finally:
        if process is not None and process.returncode is None:
            try:
                process.kill()
                await process.wait()
            except Exception:
                pass
