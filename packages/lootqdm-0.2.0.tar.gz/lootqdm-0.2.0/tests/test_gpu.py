"""Tests for lootqdm.gpu — cross-platform GPU stats."""
from __future__ import annotations


class TestGetGpuStats:
    def test_returns_none_or_valid_dict(self):
        from lootqdm.gpu import get_gpu_stats
        result = get_gpu_stats()
        if result is not None:
            assert "name" in result
            for key in ("util_pct", "mem_used_mb", "mem_total_mb", "temp_c"):
                assert key in result
                assert result[key] is None or isinstance(result[key], (int, float))

    def test_never_raises(self):
        from lootqdm.gpu import get_gpu_stats
        try:
            get_gpu_stats()
        except Exception as e:
            raise AssertionError(f"get_gpu_stats raised {e!r}")

    def test_try_nvidia_returns_none_when_pynvml_missing(self):
        import builtins
        import unittest.mock as mock
        real_import = builtins.__import__

        def block_pynvml(name, *args, **kwargs):
            if name == "pynvml":
                raise ImportError("blocked")
            return real_import(name, *args, **kwargs)

        with mock.patch("builtins.__import__", side_effect=block_pynvml):
            from lootqdm.gpu import _try_nvidia
            result = _try_nvidia()
            assert result is None


class TestParseIoregOutput:
    def test_parses_utilization_and_memory(self):
        from lootqdm.gpu import _parse_ioreg_output
        sample = (
            '| "PerformanceStatistics" = {"Device Utilization %"=42,'
            '"In use system memory"=2147483648}'
        )
        result = _parse_ioreg_output(sample)
        assert result is not None
        assert result["util_pct"] == 42.0
        assert abs(result["mem_used_mb"] - 2048.0) < 1.0

    def test_returns_none_on_empty_input(self):
        from lootqdm.gpu import _parse_ioreg_output
        assert _parse_ioreg_output("") is None
        assert _parse_ioreg_output("no relevant content") is None

    def test_partial_data_util_only(self):
        from lootqdm.gpu import _parse_ioreg_output
        result = _parse_ioreg_output('"Device Utilization %"=75')
        assert result is not None
        assert result["util_pct"] == 75.0
        assert result["mem_used_mb"] is None


class TestParseRocmOutput:
    def test_parses_rocm_json(self):
        import json
        from lootqdm.gpu import _parse_rocm_output
        sample = json.dumps({
            "card0": {
                "GPU use (%)": "55",
                "VRAM Total Memory (B)": "8589934592",
                "VRAM Total Used Memory (B)": "2147483648",
            }
        })
        result = _parse_rocm_output(sample)
        assert result is not None
        assert result["util_pct"] == 55.0
        assert abs(result["mem_total_mb"] - 8192.0) < 1.0
        assert abs(result["mem_used_mb"] - 2048.0) < 1.0

    def test_returns_none_on_bad_json(self):
        from lootqdm.gpu import _parse_rocm_output
        assert _parse_rocm_output("not json") is None
        assert _parse_rocm_output("{}") is None
