"""Tests for lootqdm.classes — class flavor system."""
from __future__ import annotations


class TestClassSystem:
    def test_valid_classes_defined(self):
        from lootqdm.classes import VALID_CLASSES
        assert "wizard" in VALID_CLASSES
        assert "warrior" in VALID_CLASSES
        assert "rogue" in VALID_CLASSES

    def test_all_classes_cover_all_rarities(self):
        from lootqdm.classes import CLASS_LOOT_OVERRIDES
        RARITIES = {"common", "uncommon", "rare", "epic", "legendary"}
        for class_name, overrides in CLASS_LOOT_OVERRIDES.items():
            missing = RARITIES - overrides.keys()
            assert not missing, f"{class_name} missing rarities: {missing}"
            for rarity, names in overrides.items():
                assert len(names) >= 3, f"{class_name}.{rarity} needs >=3 names"

    def test_get_loot_names_returns_class_override(self):
        from lootqdm.classes import get_loot_names
        from lootqdm.themes import get_theme
        theme = get_theme("dark_dungeon")
        names = get_loot_names("wizard", theme.loot_names)
        assert names != theme.loot_names
        all_names = [n for lst in names.values() for n in lst]
        assert any("Spell" in n or "Mana" in n or "Arcane" in n or "Glyph" in n for n in all_names)

    def test_get_loot_names_none_returns_theme(self):
        from lootqdm.classes import get_loot_names
        from lootqdm.themes import get_theme
        theme = get_theme("dark_dungeon")
        assert get_loot_names(None, theme.loot_names) == theme.loot_names

    def test_get_loot_names_invalid_class_returns_theme(self):
        from lootqdm.classes import get_loot_names
        from lootqdm.themes import get_theme
        theme = get_theme("dark_dungeon")
        assert get_loot_names("paladin", theme.loot_names) == theme.loot_names

    def test_boss_names_for_all_classes_and_none(self):
        from lootqdm.classes import BOSS_NAMES, VALID_CLASSES
        for class_name in list(VALID_CLASSES) + [None]:
            assert class_name in BOSS_NAMES
            for milestone in ("first", "mid", "final"):
                assert milestone in BOSS_NAMES[class_name]
                assert isinstance(BOSS_NAMES[class_name][milestone], str)
                assert len(BOSS_NAMES[class_name][milestone]) > 0
