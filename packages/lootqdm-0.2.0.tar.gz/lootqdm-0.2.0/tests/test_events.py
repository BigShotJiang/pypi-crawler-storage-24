"""Tests for lootqdm.events."""

from __future__ import annotations

from random import Random

from lootqdm.events import (
    roll_rarity,
    LootDrop,
    LootTable,
    Achievement,
    AchievementTracker,
    EventBus,
    Event,
    RARITY_ORDER,
)


class TestRollRarity:
    def test_returns_valid_rarity(self, rng):
        for _ in range(100):
            r = roll_rarity(rng)
            assert r in RARITY_ORDER

    def test_common_is_most_frequent(self, rng):
        counts = {"common": 0, "uncommon": 0, "rare": 0, "epic": 0, "legendary": 0}
        for _ in range(10000):
            counts[roll_rarity(rng)] += 1
        assert counts["common"] > counts["uncommon"] > counts["rare"]

    def test_luck_increases_rare_drops(self, rng):
        base_rng = Random(42)
        luck_rng = Random(42)
        base_rare = sum(1 for _ in range(10000) if roll_rarity(base_rng) in ("rare", "epic", "legendary"))
        luck_rare = sum(1 for _ in range(10000) if roll_rarity(luck_rng, luck=0.5) in ("rare", "epic", "legendary"))
        assert luck_rare > base_rare


class TestLootTable:
    def test_roll_returns_loot_drop(self, rng):
        table = LootTable("dark_dungeon")
        drop = table.roll(rng)
        assert isinstance(drop, LootDrop)
        assert drop.rarity in RARITY_ORDER
        assert isinstance(drop.name, str)
        assert drop.xp > 0

    def test_xp_scales_with_rarity(self):
        table = LootTable("dark_dungeon")
        common_xp = []
        epic_xp = []
        rng = Random(123)
        for _ in range(10000):
            drop = table.roll(rng)
            if drop.rarity == "common":
                common_xp.append(drop.xp)
            elif drop.rarity == "epic":
                epic_xp.append(drop.xp)
        if common_xp and epic_xp:
            assert sum(epic_xp) / len(epic_xp) > sum(common_xp) / len(common_xp)


class TestAchievementTracker:
    def test_unlock(self):
        tracker = AchievementTracker()
        result = tracker.unlock("first_epoch", "First Epoch Complete")
        assert result is True
        assert "first_epoch" in tracker.unlocked

    def test_duplicate_unlock_returns_false(self):
        tracker = AchievementTracker()
        tracker.unlock("first_epoch", "First Epoch Complete")
        result = tracker.unlock("first_epoch", "First Epoch Complete")
        assert result is False

    def test_list_achievements(self):
        tracker = AchievementTracker()
        tracker.unlock("first_epoch", "First Epoch Complete")
        tracker.unlock("best_acc", "New Best Accuracy")
        achievements = tracker.list_all()
        assert len(achievements) == 2


class TestEventBus:
    def test_emit_and_listen(self):
        bus = EventBus()
        received = []
        bus.on("loot", lambda e: received.append(e))
        bus.emit("loot", {"name": "Rusty Coin"})
        assert len(received) == 1
        assert received[0].data["name"] == "Rusty Coin"

    def test_multiple_listeners(self):
        bus = EventBus()
        a, b = [], []
        bus.on("loot", lambda e: a.append(e))
        bus.on("loot", lambda e: b.append(e))
        bus.emit("loot", {"name": "test"})
        assert len(a) == 1
        assert len(b) == 1

    def test_different_event_types(self):
        bus = EventBus()
        loot_events = []
        level_events = []
        bus.on("loot", lambda e: loot_events.append(e))
        bus.on("level_up", lambda e: level_events.append(e))
        bus.emit("loot", {"name": "x"})
        bus.emit("level_up", {"level": 5})
        assert len(loot_events) == 1
        assert len(level_events) == 1
