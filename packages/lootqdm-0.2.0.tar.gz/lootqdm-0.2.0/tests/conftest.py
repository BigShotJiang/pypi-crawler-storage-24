"""Shared test fixtures for lootqdm."""

from __future__ import annotations

import pytest
from random import Random


@pytest.fixture
def rng() -> Random:
    """Deterministic RNG for reproducible tests."""
    return Random(42)
