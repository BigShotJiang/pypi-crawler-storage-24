"""Tests for lootqdm.utils."""

from __future__ import annotations

from collections import deque

from lootqdm.utils import is_tty, sparkline, format_time, format_number, Throttle
import time


class TestSparkline:
    def test_empty(self):
        assert sparkline([]) == ""

    def test_single_value(self):
        result = sparkline([5.0])
        assert len(result) == 1
        assert result == "\u2588"

    def test_ascending(self):
        result = sparkline([0.0, 0.25, 0.5, 0.75, 1.0])
        assert result == "\u2581\u2583\u2585\u2586\u2588"

    def test_descending(self):
        result = sparkline([1.0, 0.75, 0.5, 0.25, 0.0])
        assert result == "\u2588\u2586\u2585\u2583\u2581"

    def test_all_same(self):
        result = sparkline([3.0, 3.0, 3.0])
        assert result == "\u2585\u2585\u2585"

    def test_max_width(self):
        values = list(range(100))
        result = sparkline(values, width=10)
        assert len(result) == 10


class TestFormatTime:
    def test_seconds(self):
        assert format_time(45) == "00:00:45"

    def test_minutes(self):
        assert format_time(125) == "00:02:05"

    def test_hours(self):
        assert format_time(3661) == "01:01:01"

    def test_zero(self):
        assert format_time(0) == "00:00:00"


class TestFormatNumber:
    def test_small_float(self):
        assert format_number(0.0234) == "0.0234"

    def test_percentage(self):
        assert format_number(94.2) == "94.20"

    def test_scientific(self):
        assert format_number(0.0001) == "1e-4"

    def test_large(self):
        assert format_number(1284) == "1284"

    def test_zero(self):
        assert format_number(0.0) == "0.0000"


class TestThrottle:
    def test_first_call_always_runs(self):
        t = Throttle(fps=10)
        assert t.should_update() is True

    def test_rapid_calls_throttled(self):
        t = Throttle(fps=10)
        t.should_update()  # first call
        assert t.should_update() is False

    def test_after_interval(self):
        t = Throttle(fps=10)
        t.should_update()
        t._last_update -= 0.2  # simulate time passing
        assert t.should_update() is True


class TestIsTty:
    def test_returns_bool(self):
        result = is_tty()
        assert isinstance(result, bool)
