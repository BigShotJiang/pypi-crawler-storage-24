"""Tests for lootqdm.persistence."""

from __future__ import annotations

import json
from pathlib import Path

from lootqdm.persistence import Profile, load_profile, save_profile


class TestProfile:
    def test_defaults(self):
        p = Profile()
        assert p.lifetime_xp == 0
        assert p.total_runs == 0
        assert p.level == 1
        assert p.achievements == []
        assert p.loot_log == []
        assert p.prestige == 0

    def test_add_xp(self):
        p = Profile()
        p.add_xp(100)
        assert p.lifetime_xp == 100

    def test_record_run(self):
        p = Profile()
        p.record_run()
        assert p.total_runs == 1

    def test_to_dict_and_from_dict(self):
        p = Profile()
        p.add_xp(500)
        p.record_run()
        p.achievements.append("first_epoch")
        d = p.to_dict()
        p2 = Profile.from_dict(d)
        assert p2.lifetime_xp == 500
        assert p2.total_runs == 1
        assert "first_epoch" in p2.achievements


class TestSaveLoad:
    def test_save_and_load(self, tmp_path):
        path = tmp_path / "profile.json"
        p = Profile()
        p.add_xp(1234)
        p.achievements.append("test")
        save_profile(p, path)
        assert path.exists()
        p2 = load_profile(path)
        assert p2.lifetime_xp == 1234
        assert "test" in p2.achievements

    def test_load_missing_returns_default(self, tmp_path):
        path = tmp_path / "nonexistent.json"
        p = load_profile(path)
        assert p.lifetime_xp == 0

    def test_load_corrupt_returns_default(self, tmp_path):
        path = tmp_path / "corrupt.json"
        path.write_text("not json at all {{{")
        p = load_profile(path)
        assert p.lifetime_xp == 0
