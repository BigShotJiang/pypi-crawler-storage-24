"""Tests for lootqdm.ui."""

from __future__ import annotations

import os
from unittest.mock import patch

from lootqdm.ui import GameUI, PlainUI


class TestGameUICreation:
    def test_create_with_defaults(self):
        ui = GameUI(total_steps=100, _force_plain=True)
        assert ui._total_steps == 100
        assert ui._total_epochs == 1

    def test_create_with_theme(self):
        ui = GameUI(total_steps=100, theme="neon_cyber", _force_plain=True)
        assert ui._theme.name == "neon_cyber"

    def test_invalid_theme_raises(self):
        import pytest
        with pytest.raises(KeyError):
            GameUI(total_steps=100, theme="nonexistent")


class TestGameUIContextManager:
    def test_context_manager(self):
        with GameUI(total_steps=10, _force_plain=True) as ui:
            for i in range(10):
                ui.step({"loss": 1.0 / (i + 1)})

    def test_epoch_end(self):
        with GameUI(total_steps=10, total_epochs=2, _force_plain=True) as ui:
            for epoch in range(2):
                for i in range(5):
                    ui.step({"loss": 0.5})
                ui.epoch_end({"val_acc": 0.9})


class TestGameUIStep:
    def test_step_increments(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.step()
            assert ui._current_step == 1
            ui.step(n=5)
            assert ui._current_step == 6

    def test_step_with_metrics(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.step({"loss": 0.5, "acc": 0.8})
            assert ui._latest_metrics["loss"] == 0.5

    def test_nan_detection(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.step({"loss": float("nan")})
            assert ui._achievements.is_unlocked("nan_survived")


class TestGameUIQuests:
    def test_quest_registration(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.quest("High Acc", "acc", 0.95)
            assert len(ui._quest_tracker.all()) == 1


class TestGameUILog:
    def test_log_adds_to_feed(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.log("Test message")
            assert len(ui._feed) == 1

    def test_log_with_rarity(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.log("Epic item!", rarity="epic")
            assert ui._feed[0]["rarity"] == "epic"


class TestGameUIWrap:
    def test_wrap_iterable(self):
        items = list(range(10))
        with GameUI(total_steps=10, _force_plain=True) as ui:
            result = list(ui.wrap(items))
        assert result == items

    def test_wrap_with_metrics_fn(self):
        items = [{"loss": 0.5}, {"loss": 0.3}]
        with GameUI(total_steps=2, _force_plain=True) as ui:
            for item in ui.wrap(items, metrics_fn=lambda x: x):
                pass
            assert ui._latest_metrics["loss"] == 0.3


class TestPlainUI:
    def test_plain_mode_no_crash(self):
        with PlainUI(total_steps=10) as ui:
            for i in range(10):
                ui.step({"loss": 0.5})
            ui.epoch_end({"val_acc": 0.9})
            ui.log("test message", rarity="rare")
            ui.quest("test", "acc", 0.95)


class TestTTYFallback:
    @patch.dict(os.environ, {"LOOTQDM_PLAIN": "1"})
    def test_env_forces_plain(self):
        ui = GameUI(total_steps=10)
        assert isinstance(ui._impl, PlainUI)


class TestGamePanelRender:
    def _make_rich_ui(self):
        import time
        from collections import deque
        from lootqdm.ui import RichUI
        from lootqdm.themes import get_theme
        from lootqdm.events import AchievementTracker, LootTable, EventBus
        from lootqdm.quests import QuestTracker
        from lootqdm.mappers import StatMapper
        from lootqdm.utils import Throttle
        from random import Random

        rui = object.__new__(RichUI)
        rui._theme = get_theme("dark_dungeon")
        rui._start_time = time.monotonic()
        rui._current_step = 5
        rui._total_steps = 100
        rui._current_epoch = 0
        rui._total_epochs = 2
        rui._latest_metrics = {"loss": 0.5, "acc": 0.8}
        rui._best_metrics = {}
        rui._feed = [{"message": "Test drop", "rarity": "common"}]
        rui._xp = 500
        rui._level = 2
        rui._emoji = True
        rui._run_name = "test_run"
        rui._sparkline_buffers = {}
        rui._achievements = AchievementTracker()
        rui._quest_tracker = QuestTracker()
        rui._mapper = StatMapper()
        return rui

    def test_render_produces_section_headers(self):
        from io import StringIO
        from rich.console import Console
        rui = self._make_rich_ui()
        buf = StringIO()
        console = Console(file=buf, width=80, no_color=True)
        console.print(rui._render())
        output = buf.getvalue()
        assert "PROGRESS" in output
        assert "STATS" in output
        assert "LOOT" in output
        assert "QUESTS" in output

    def test_render_uses_dark_dungeon_box_chars(self):
        from io import StringIO
        from rich.console import Console
        rui = self._make_rich_ui()
        buf = StringIO()
        console = Console(file=buf, width=80, no_color=True)
        console.print(rui._render())
        output = buf.getvalue()
        assert "┏" in output
        assert "┃" in output

    def test_render_cozy_pastel_uses_rounded_chars(self):
        from io import StringIO
        from rich.console import Console
        from lootqdm.themes import get_theme
        rui = self._make_rich_ui()
        rui._theme = get_theme("cozy_pastel")
        buf = StringIO()
        console = Console(file=buf, width=80, no_color=True)
        console.print(rui._render())
        assert "╭" in buf.getvalue()

    def test_render_retro_crt_uses_ascii_chars(self):
        from io import StringIO
        from rich.console import Console
        from lootqdm.themes import get_theme
        rui = self._make_rich_ui()
        rui._theme = get_theme("retro_crt")
        buf = StringIO()
        console = Console(file=buf, width=80, no_color=True)
        console.print(rui._render())
        output = buf.getvalue()
        assert "+" in output
        assert "-" in output
