"""Tests for lootqdm.mappers."""

from __future__ import annotations

from lootqdm.mappers import StatMapper


class TestStatMapper:
    def test_default_mappings(self):
        mapper = StatMapper()
        assert mapper.game_name("loss") == "DMG"
        assert mapper.game_name("acc") == "CRIT"
        assert mapper.game_name("lr") == "MANA"

    def test_default_icons(self):
        mapper = StatMapper()
        icon, _ = mapper.format("loss", 0.5)
        assert isinstance(icon, str)

    def test_unknown_metric_passes_through(self):
        mapper = StatMapper()
        assert mapper.game_name("custom_metric") == "custom_metric"

    def test_custom_mapping(self):
        mapper = StatMapper(mappings={"f1_score": ("F1 PWR", "\u2694")})
        assert mapper.game_name("f1_score") == "F1 PWR"

    def test_format_returns_icon_and_name(self):
        mapper = StatMapper()
        icon, name = mapper.format("loss", 0.023)
        assert name == "DMG"
        assert len(icon) > 0

    def test_merge_custom_with_defaults(self):
        mapper = StatMapper(mappings={"custom": ("CSTM", "?")})
        assert mapper.game_name("loss") == "DMG"
        assert mapper.game_name("custom") == "CSTM"
