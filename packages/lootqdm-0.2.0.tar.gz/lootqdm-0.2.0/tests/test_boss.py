"""Tests for boss battle events and class-flavored LootTable."""
from __future__ import annotations


class TestLootTableWithClass:
    def test_default_loot_uses_theme_names(self):
        from lootqdm.events import LootTable
        from lootqdm.themes import get_theme
        from random import Random
        table = LootTable("dark_dungeon")
        theme = get_theme("dark_dungeon")
        all_theme_names = [n for lst in theme.loot_names.values() for n in lst]
        rng = Random(42)
        for _ in range(20):
            drop = table.roll(rng)
            assert drop.name in all_theme_names

    def test_wizard_class_loot_uses_overrides(self):
        from lootqdm.events import LootTable
        from lootqdm.classes import CLASS_LOOT_OVERRIDES
        from random import Random
        table = LootTable("dark_dungeon", class_="wizard")
        all_wizard = [n for lst in CLASS_LOOT_OVERRIDES["wizard"].values() for n in lst]
        rng = Random(1)
        found = False
        for _ in range(100):
            drop = table.roll(rng)
            if drop.name in all_wizard:
                found = True
                break
        assert found

    def test_invalid_class_falls_back_to_theme(self):
        from lootqdm.events import LootTable
        from lootqdm.themes import get_theme
        from random import Random
        table = LootTable("dark_dungeon", class_="paladin")
        theme = get_theme("dark_dungeon")
        all_theme_names = [n for lst in theme.loot_names.values() for n in lst]
        rng = Random(42)
        for _ in range(20):
            drop = table.roll(rng)
            assert drop.name in all_theme_names


class TestBossSpawn:
    def test_boss_spawns_on_first_epoch(self):
        import lootqdm
        with lootqdm.GameUI(
            total_steps=10, total_epochs=3, _force_plain=True, class_="warrior"
        ) as ui:
            for _ in range(10):
                ui.step()
            ui.epoch_end({"acc": 0.5})
        boss_msgs = [e["message"] for e in ui._feed if "BOSS" in e.get("message", "")]
        assert len(boss_msgs) >= 1, f"No boss event in feed: {ui._feed}"

    def test_boss_defeated_when_metric_improves_5pct(self):
        import lootqdm
        with lootqdm.GameUI(
            total_steps=20, total_epochs=4, _force_plain=True, class_="wizard"
        ) as ui:
            for _ in range(10):
                ui.step()
            ui.epoch_end({"acc": 0.50})  # epoch 1 — boss spawns
            for _ in range(10):
                ui.step()
            ui.epoch_end({"acc": 0.60})  # epoch 2 — 20% improvement → boss defeated
        defeated = [e for e in ui._feed if "DEFEATED" in e.get("message", "")]
        assert len(defeated) >= 1, f"No defeat event: {ui._feed}"

    def test_boss_escapes_when_metric_does_not_improve(self):
        import lootqdm
        with lootqdm.GameUI(
            total_steps=20, total_epochs=4, _force_plain=True, class_="rogue"
        ) as ui:
            for _ in range(10):
                ui.step()
            ui.epoch_end({"acc": 0.50})  # epoch 1 — boss spawns
            for _ in range(10):
                ui.step()
            ui.epoch_end({"acc": 0.51})  # epoch 2 — only 2% → boss escapes
        escaped = [e for e in ui._feed if "escaped" in e.get("message", "").lower()]
        assert len(escaped) >= 1, f"No escape event: {ui._feed}"

    def test_boss_works_without_class(self):
        import lootqdm
        with lootqdm.GameUI(
            total_steps=10, total_epochs=1, _force_plain=True
        ) as ui:
            for _ in range(10):
                ui.step()
            ui.epoch_end({"loss": 0.5})
        assert isinstance(ui._feed, list)
