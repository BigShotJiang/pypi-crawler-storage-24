"""Tests for lootqdm.quests."""

from __future__ import annotations

from lootqdm.quests import Quest, QuestTracker


class TestQuest:
    def test_creation(self):
        q = Quest(name="High Accuracy", metric="acc", target=0.95, compare=">=")
        assert q.name == "High Accuracy"
        assert not q.completed
        assert q.progress == 0.0

    def test_check_gte(self):
        q = Quest(name="test", metric="acc", target=0.95, compare=">=")
        q.update(0.90)
        assert not q.completed
        q.update(0.96)
        assert q.completed

    def test_check_lte(self):
        q = Quest(name="test", metric="loss", target=0.01, compare="<=")
        q.update(0.5)
        assert not q.completed
        q.update(0.005)
        assert q.completed

    def test_progress_percentage(self):
        q = Quest(name="test", metric="acc", target=1.0, compare=">=")
        q.update(0.5)
        assert abs(q.progress - 0.5) < 0.01

    def test_progress_lte(self):
        q = Quest(name="test", metric="loss", target=0.1, compare="<=", start_value=1.0)
        q.update(0.55)
        assert abs(q.progress - 0.5) < 0.01

    def test_stays_completed(self):
        q = Quest(name="test", metric="acc", target=0.95, compare=">=")
        q.update(0.96)
        assert q.completed
        q.update(0.50)
        assert q.completed


class TestQuestTracker:
    def test_add_and_check(self):
        tracker = QuestTracker()
        tracker.add("High Acc", "acc", 0.95, ">=")
        results = tracker.check({"acc": 0.96})
        assert len(results) == 1

    def test_no_completions(self):
        tracker = QuestTracker()
        tracker.add("High Acc", "acc", 0.95, ">=")
        results = tracker.check({"acc": 0.5})
        assert len(results) == 0

    def test_multiple_quests(self):
        tracker = QuestTracker()
        tracker.add("High Acc", "acc", 0.95, ">=")
        tracker.add("Low Loss", "loss", 0.01, "<=")
        results = tracker.check({"acc": 0.96, "loss": 0.005})
        assert len(results) == 2

    def test_get_all(self):
        tracker = QuestTracker()
        tracker.add("q1", "acc", 0.95, ">=")
        tracker.add("q2", "loss", 0.01, "<=")
        assert len(tracker.all()) == 2
