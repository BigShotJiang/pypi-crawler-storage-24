"""Framework integrations for lootqdm."""
