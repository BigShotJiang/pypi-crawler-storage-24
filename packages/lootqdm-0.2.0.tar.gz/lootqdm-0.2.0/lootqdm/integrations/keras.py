"""Keras/TensorFlow integration for lootqdm."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from lootqdm.ui import GameUI

try:
    from tensorflow.keras.callbacks import Callback as _KerasCallback
except ImportError:
    try:
        from keras.callbacks import Callback as _KerasCallback
    except ImportError:
        class _KerasCallback:  # type: ignore[no-redef]
            """Stub base class when Keras is not installed."""
            def set_params(self, params: Any) -> None: ...
            def on_train_begin(self, logs: Any = None) -> None: ...
            def on_epoch_end(self, epoch: int, logs: Any = None) -> None: ...
            def on_batch_end(self, batch: int, logs: Any = None) -> None: ...
            def on_train_end(self, logs: Any = None) -> None: ...


class LootqdmKerasCallback(_KerasCallback):
    """Keras callback that feeds training metrics into a lootqdm GameUI.

    Usage:
        with GameUI(total_steps=steps_per_epoch * epochs, total_epochs=epochs) as ui:
            model.fit(x, y, callbacks=[LootqdmKerasCallback(ui)])
    """

    def __init__(self, ui: GameUI) -> None:
        super().__init__()
        self._ui = ui

    def on_batch_end(self, batch: int, logs: Any = None) -> None:
        metrics = {}
        if logs:
            for k, v in logs.items():
                try:
                    metrics[k] = float(v)
                except (TypeError, ValueError):
                    pass
        self._ui.step(metrics)

    def on_epoch_end(self, epoch: int, logs: Any = None) -> None:
        metrics = {}
        if logs:
            for k, v in logs.items():
                try:
                    metrics[k] = float(v)
                except (TypeError, ValueError):
                    pass
        self._ui.epoch_end(metrics)
