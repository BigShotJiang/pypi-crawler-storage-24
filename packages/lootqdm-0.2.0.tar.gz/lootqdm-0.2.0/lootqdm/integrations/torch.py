"""PyTorch integration for lootqdm."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from lootqdm.ui import GameUI


class LootqdmCallback:
    """Callback-style wrapper for PyTorch training loops.

    Usage:
        cb = LootqdmCallback(ui)
        for batch in dataloader:
            loss = train_step(batch)
            cb.on_batch_end(loss=loss.item(), lr=scheduler.get_last_lr()[0])
        cb.on_epoch_end(val_acc=val_accuracy)
    """

    def __init__(self, ui: GameUI) -> None:
        self._ui = ui

    def on_batch_end(self, **metrics: float) -> None:
        """Call after each training batch."""
        self._ui.step(metrics)

    def on_epoch_end(self, **metrics: float) -> None:
        """Call after each epoch."""
        self._ui.epoch_end(metrics)

    def on_log(self, message: str, rarity: str | None = None) -> None:
        """Log a custom message to the loot feed."""
        self._ui.log(message, rarity)
