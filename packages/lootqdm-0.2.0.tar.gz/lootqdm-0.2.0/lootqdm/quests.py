"""Quest system for lootqdm."""

from __future__ import annotations

import operator
from dataclasses import dataclass

COMPARISONS = {
    ">=": operator.ge,
    "<=": operator.le,
    ">": operator.gt,
    "<": operator.lt,
}


@dataclass
class Quest:
    """A single quest with metric-based completion."""

    name: str
    metric: str
    target: float
    compare: str
    start_value: float = 0.0
    completed: bool = False
    current: float = 0.0

    def update(self, value: float) -> bool:
        self.current = value
        if self.completed:
            return False
        op = COMPARISONS.get(self.compare, operator.ge)
        if op(value, self.target):
            self.completed = True
            return True
        return False

    @property
    def progress(self) -> float:
        if self.completed:
            return 1.0
        if self.compare in (">=", ">"):
            if self.target == 0:
                return 1.0 if self.current >= self.target else 0.0
            return min(1.0, max(0.0, self.current / self.target))
        else:
            span = self.start_value - self.target
            if span <= 0:
                return 1.0 if self.current <= self.target else 0.0
            traveled = self.start_value - self.current
            return min(1.0, max(0.0, traveled / span))


class QuestTracker:
    def __init__(self) -> None:
        self._quests: list[Quest] = []

    def add(self, name: str, metric: str, target: float, compare: str = ">=", start_value: float = 0.0) -> Quest:
        q = Quest(name=name, metric=metric, target=target, compare=compare, start_value=start_value)
        self._quests.append(q)
        return q

    def check(self, metrics: dict[str, float]) -> list[Quest]:
        newly_completed = []
        for q in self._quests:
            if q.metric in metrics:
                if q.update(metrics[q.metric]):
                    newly_completed.append(q)
        return newly_completed

    def all(self) -> list[Quest]:
        return list(self._quests)
