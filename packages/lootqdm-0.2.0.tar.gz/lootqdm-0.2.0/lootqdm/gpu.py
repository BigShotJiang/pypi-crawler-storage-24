"""Cross-platform GPU monitoring for lootqdm. Never raises exceptions."""
from __future__ import annotations

import json
import re
import subprocess
from typing import Any


def get_gpu_stats() -> dict[str, Any] | None:
    """Return GPU stats dict or None if unavailable. Never raises."""
    result = _try_nvidia()
    if result is not None:
        return result
    result = _try_apple_silicon()
    if result is not None:
        return result
    return _try_amd()


def _try_nvidia() -> dict[str, Any] | None:
    """Try pynvml for NVIDIA GPUs. Returns None if unavailable."""
    try:
        import pynvml  # noqa: PLC0415
        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        name = pynvml.nvmlDeviceGetName(handle)
        if isinstance(name, bytes):
            name = name.decode()
        util = pynvml.nvmlDeviceGetUtilizationRates(handle)
        mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
        try:
            temp = float(pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU))
        except Exception:
            temp = None
        return {
            "name": name,
            "util_pct": float(util.gpu),
            "mem_used_mb": mem.used / (1024 ** 2),
            "mem_total_mb": mem.total / (1024 ** 2),
            "temp_c": temp,
        }
    except Exception:
        return None


def _try_apple_silicon() -> dict[str, Any] | None:
    """Try ioreg on macOS for Apple Silicon GPU. Falls back to system_profiler for name."""
    try:
        proc = subprocess.run(
            ["ioreg", "-r", "-c", "AGXAccelerator", "-k", "PerformanceStatistics", "-d", "1"],
            capture_output=True, text=True, timeout=2,
        )
        parsed = _parse_ioreg_output(proc.stdout)
        if parsed is not None:
            return parsed
    except Exception:
        pass
    # Fallback: get GPU name only from system_profiler
    try:
        proc = subprocess.run(
            ["system_profiler", "SPDisplaysDataType", "-json"],
            capture_output=True, text=True, timeout=5,
        )
        data = json.loads(proc.stdout)
        displays = data.get("SPDisplaysDataType", [{}])
        name = displays[0].get("sppci_model", "Apple GPU")
        return {"name": name, "util_pct": None, "mem_used_mb": None, "mem_total_mb": None, "temp_c": None}
    except Exception:
        return None


def _parse_ioreg_output(text: str) -> dict[str, Any] | None:
    """Parse ioreg PerformanceStatistics output. Returns None if no relevant data found."""
    util_match = re.search(r'"Device Utilization %"=(\d+)', text)
    mem_match = re.search(r'"In use system memory"=(\d+)', text)
    if not util_match and not mem_match:
        return None
    return {
        "name": "Apple GPU",
        "util_pct": float(util_match.group(1)) if util_match else None,
        "mem_used_mb": float(mem_match.group(1)) / (1024 ** 2) if mem_match else None,
        "mem_total_mb": None,
        "temp_c": None,
    }


def _try_amd() -> dict[str, Any] | None:
    """Try rocm-smi for AMD GPUs on Linux."""
    try:
        proc = subprocess.run(
            ["rocm-smi", "--showuse", "--showmeminfo", "vram", "--json"],
            capture_output=True, text=True, timeout=3,
        )
        return _parse_rocm_output(proc.stdout)
    except Exception:
        return None


def _parse_rocm_output(text: str) -> dict[str, Any] | None:
    """Parse rocm-smi JSON output. Returns None on failure."""
    try:
        data = json.loads(text)
        if not data:
            return None
        card_data = next(iter(data.values()))
        util_pct = float(card_data.get("GPU use (%)", 0))
        mem_total_b = float(card_data.get("VRAM Total Memory (B)", 0))
        mem_used_b = float(card_data.get("VRAM Total Used Memory (B)", 0))
        return {
            "name": "AMD GPU",
            "util_pct": util_pct,
            "mem_used_mb": mem_used_b / (1024 ** 2) if mem_used_b else None,
            "mem_total_mb": mem_total_b / (1024 ** 2) if mem_total_b else None,
            "temp_c": None,
        }
    except Exception:
        return None
