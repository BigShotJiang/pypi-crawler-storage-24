"""GameUI: the main Rich Live layout for lootqdm."""

from __future__ import annotations

import logging
import math
import time
from collections import deque
from random import Random
from typing import Any, Callable, Iterable, Iterator, TypeVar

from lootqdm.events import (
    AchievementTracker,
    EventBus,
    LootTable,
    RARITY_XP,
)
from lootqdm.mappers import StatMapper
from lootqdm.persistence import Profile, load_profile, save_profile
from lootqdm.quests import QuestTracker
from lootqdm.themes import Theme, get_theme
from lootqdm.utils import Throttle, format_number, format_time, is_tty, sparkline

logger = logging.getLogger("lootqdm")

T = TypeVar("T")

# XP / Level constants
DEFAULT_TOTAL_XP = 10000
LEVEL_BASE = 100
LEVEL_EXPONENT = 1.5
LOOT_ROLL_INTERVAL = 50
CRIT_PROBABILITY = 0.03
LUCKY_PROBABILITY = 0.01
MAX_FEED_ITEMS = 20
SPARKLINE_BUFFER = 20


def _xp_for_level(level: int) -> int:
    """XP required to reach a given level."""
    return int(LEVEL_BASE * (level**LEVEL_EXPONENT))


def _split_to_lines(text: Any, col_w: int) -> list:
    """Split a multi-line Rich Text into right-padded per-line Text objects."""
    from rich.text import Text as _Text
    lines = []
    for raw_line in text.plain.split("\n"):
        t = _Text(raw_line)
        pad = max(0, col_w - len(raw_line))
        t.append(" " * pad)
        lines.append(t)
    # Drop trailing blank lines
    while lines and not lines[-1].plain.strip():
        lines.pop()
    return lines


class _GamePanel:
    """Custom Rich renderable: unified box-drawing 2x2 grid panel."""

    def __init__(
        self,
        title: str,
        title_style: str,
        header_plain: str,
        header_style: str,
        top_left_lines: list,
        top_right_lines: list,
        bot_left_lines: list,
        bot_right_lines: list,
        box_chars: dict,
        border_style: str,
        col_w: int,
    ) -> None:
        self._title = title
        self._title_style = title_style
        self._header_plain = header_plain
        self._header_style = header_style
        self._tl = top_left_lines
        self._tr = top_right_lines
        self._bl = bot_left_lines
        self._br = bot_right_lines
        self._bc = box_chars
        self._bs = border_style
        self._col_w = col_w

    def __rich_console__(self, console: Any, options: Any) -> Any:
        from rich.text import Text

        bc = self._bc
        bs = self._bs
        w = self._col_w
        h = bc["horiz"]
        v = bc["vert"]

        def btext(s: str) -> Text:
            return Text(s, style=bs)

        def hline(left: str, mid: str, right: str) -> Text:
            return btext(f"{left}{h * (w + 1)}{mid}{h * (w + 1)}{right}")

        # Total inner width between the two outer vertical bars
        inner_w = (w + 1) * 2 + 1

        # Top border with embedded title
        title_text = f" {self._title} "
        title_pad = max(0, inner_w - len(title_text))
        yield Text.assemble(
            Text(bc["top_left"], style=bs),
            Text(title_text, style=self._title_style),
            Text(h * title_pad + bc["top_right"], style=bs),
        )

        # Header line
        header_pad = max(0, inner_w - len(self._header_plain))
        yield Text.assemble(
            Text(v, style=bs),
            Text(self._header_plain, style=self._header_style),
            Text(" " * header_pad + v, style=bs),
        )

        # Divider after header
        yield hline(bc["left_tee"], bc["cross"], bc["right_tee"])

        # Top row: PROGRESS | STATS
        empty = Text(" " * w)
        max_top = max(len(self._tl), len(self._tr), 1)
        for i in range(max_top):
            ll = self._tl[i] if i < len(self._tl) else empty
            rl = self._tr[i] if i < len(self._tr) else empty
            yield Text.assemble(Text(v, style=bs), ll, Text(v, style=bs), rl, Text(v, style=bs))

        # Mid divider
        yield hline(bc["left_tee"], bc["cross"], bc["right_tee"])

        # Bottom row: LOOT & EVENTS | QUESTS
        max_bot = max(len(self._bl), len(self._br), 1)
        for i in range(max_bot):
            ll = self._bl[i] if i < len(self._bl) else empty
            rl = self._br[i] if i < len(self._br) else empty
            yield Text.assemble(Text(v, style=bs), ll, Text(v, style=bs), rl, Text(v, style=bs))

        # Bottom border
        yield hline(bc["bot_left"], bc["bot_tee"], bc["bot_right"])


class PlainUI:
    """Plain-text fallback when no TTY is available."""

    def __init__(
        self, total_steps: int = 0, total_epochs: int = 1, **kwargs: Any
    ) -> None:
        self._total_steps = total_steps
        self._total_epochs = total_epochs
        self._current_step = 0
        self._current_epoch = 0
        self._latest_metrics: dict[str, float] = {}
        self._feed: list[dict[str, Any]] = []
        self._achievements = AchievementTracker()
        self._quest_tracker = QuestTracker()
        self._log_interval = max(1, total_steps // 20) if total_steps > 0 else 100
        self._class = kwargs.get("class_")
        self._boss_active: str | None = None
        self._prev_epoch_metrics: dict[str, float] = {}

    def __enter__(self) -> PlainUI:
        logger.info(
            "lootqdm: starting run (%d steps, %d epochs)",
            self._total_steps,
            self._total_epochs,
        )
        return self

    def __exit__(self, *exc: Any) -> None:
        logger.info("lootqdm: run complete. Steps: %d", self._current_step)

    def step(self, metrics: dict[str, float] | None = None, n: int = 1) -> None:
        self._current_step += n
        if metrics:
            self._latest_metrics.update(metrics)
            for k, v in metrics.items():
                if isinstance(v, float) and math.isnan(v):
                    self._achievements.unlock("nan_survived", "NaN Survived")
                    logger.warning("lootqdm: NaN detected in metric '%s'", k)
        if (
            self._current_step % self._log_interval == 0
            or self._current_step >= self._total_steps
        ):
            logger.info(
                "Step %d/%d %s",
                self._current_step,
                self._total_steps,
                self._latest_metrics,
            )

    def _boss_milestone(self) -> str | None:
        if self._current_epoch == 1:
            return "first"
        mid = self._total_epochs // 2
        if mid > 1 and self._current_epoch == mid:
            return "mid"
        if self._current_epoch == self._total_epochs:
            return "final"
        return None

    def _check_boss_defeated(self, metrics: dict) -> bool:
        for k, v in metrics.items():
            prev = self._prev_epoch_metrics.get(k)
            if prev is None or prev == 0:
                continue
            if "loss" in k:
                if (prev - v) / abs(prev) >= 0.05:
                    return True
            else:
                if (v - prev) / abs(prev) >= 0.05:
                    return True
        return False

    def epoch_end(self, metrics: dict[str, float] | None = None) -> None:
        self._current_epoch += 1
        if metrics:
            self._latest_metrics.update(metrics)
        logger.info(
            "Epoch %d/%d complete. %s",
            self._current_epoch,
            self._total_epochs,
            self._latest_metrics,
        )
        self._quest_tracker.check(self._latest_metrics)
        # Boss resolution
        if self._boss_active and metrics:
            defeated = self._check_boss_defeated(metrics)
            msg = (
                f"BOSS DEFEATED: {self._boss_active}!"
                if defeated
                else f"Boss {self._boss_active} escaped..."
            )
            self._feed.append({"message": msg, "rarity": "legendary" if defeated else None})
            self._boss_active = None
        if metrics:
            self._prev_epoch_metrics.update(metrics)
        # Boss spawn
        milestone = self._boss_milestone()
        if milestone:
            from lootqdm.classes import BOSS_NAMES  # noqa: PLC0415
            boss_name = BOSS_NAMES.get(self._class, BOSS_NAMES[None])[milestone]
            self._boss_active = boss_name
            self._feed.append({"message": f"BOSS: {boss_name} has appeared!", "rarity": "epic"})

    def log(self, message: str, rarity: str | None = None) -> None:
        self._feed.append({"message": message, "rarity": rarity})
        logger.info("lootqdm: %s", message)

    def quest(self, name: str, metric: str, target: float, compare: str = ">=") -> None:
        self._quest_tracker.add(name, metric, target, compare)

    def wrap(
        self, iterable: Iterable[T], metrics_fn: Callable | None = None
    ) -> Iterator[T]:
        for item in iterable:
            if metrics_fn:
                m = metrics_fn(item)
                self.step(m)
            else:
                self.step()
            yield item

    def pytorch_step(self, **metrics: float) -> None:
        self.step(metrics)


class RichUI:
    """Rich Live terminal UI renderer."""

    def __init__(
        self,
        total_steps: int,
        total_epochs: int = 1,
        theme: Theme | None = None,
        refresh_rate: int = 10,
        emoji: bool = True,
        persist: bool = True,
        run_name: str | None = None,
        class_: str | None = None,
    ) -> None:
        self._total_steps = total_steps
        self._total_epochs = total_epochs
        self._theme = theme or get_theme()
        self._refresh_rate = refresh_rate
        self._emoji = emoji
        self._persist = persist
        self._run_name = run_name or "run"
        self._class = class_

        self._current_step = 0
        self._current_epoch = 0
        self._latest_metrics: dict[str, float] = {}
        self._best_metrics: dict[str, float] = {}
        self._feed: list[dict[str, Any]] = []
        self._achievements = AchievementTracker()
        self._quest_tracker = QuestTracker()
        self._mapper = StatMapper()

        self._xp = 0
        self._level = 1
        self._xp_per_step = DEFAULT_TOTAL_XP / max(1, total_steps)

        self._rng = Random()
        self._loot_table = LootTable(self._theme.name, class_=class_)
        self._event_bus = EventBus()
        self._boss_active: str | None = None
        self._prev_epoch_metrics: dict[str, float] = {}
        self._throttle = Throttle(fps=refresh_rate)
        self._start_time = 0.0

        self._sparkline_buffers: dict[str, deque] = {}
        self._profile = Profile()
        self._live = None

    def __enter__(self) -> RichUI:
        from rich.live import Live

        self._start_time = time.monotonic()
        if self._persist:
            self._profile = load_profile()
            self._profile.record_run()
        self._live = Live(
            self._render(),
            refresh_per_second=self._refresh_rate,
            transient=True,
        )
        self._live.__enter__()
        return self

    def __exit__(self, *exc: Any) -> None:
        if self._persist:
            self._profile.add_xp(self._xp)
            self._profile.level = self._level
            for a in self._achievements.list_all():
                if a.key not in self._profile.achievements:
                    self._profile.achievements.append(a.key)
            save_profile(self._profile)
        if self._live:
            self._live.update(self._render())
            self._live.__exit__(*exc)

    def step(self, metrics: dict[str, float] | None = None, n: int = 1) -> None:
        self._current_step += n

        # XP
        gained = int(self._xp_per_step * n)
        self._xp += gained
        self._check_level_up()

        if metrics:
            self._latest_metrics.update(metrics)
            for k, v in metrics.items():
                if isinstance(v, float) and math.isnan(v):
                    if self._achievements.unlock("nan_survived", "NaN Survived"):
                        self._add_feed(
                            f"{self._icon('warning')} NaN survived!", rarity=None
                        )
                    continue
                # Track sparklines
                buf = self._sparkline_buffers.setdefault(
                    k, deque(maxlen=SPARKLINE_BUFFER)
                )
                buf.append(v)
                # Track bests
                prev = self._best_metrics.get(k)
                is_loss_metric = k in ("loss", "train_loss", "val_loss")
                if prev is None:
                    self._best_metrics[k] = v
                elif (is_loss_metric and v < prev) or (not is_loss_metric and v > prev):
                    if self._achievements.unlock(f"best_{k}", f"New best {k}"):
                        self._add_feed(
                            f"{self._icon('achievement')} New best {k}!",
                            rarity="uncommon",
                        )
                    self._best_metrics[k] = v

        # Loot rolls
        if self._current_step % LOOT_ROLL_INTERVAL == 0:
            drop = self._loot_table.roll(self._rng)
            self._xp += drop.xp
            icon = self._theme.icons["loot"].get(drop.rarity, "")
            self._add_feed(
                f"{icon} {drop.rarity.upper()} {drop.name} +{drop.xp} XP",
                rarity=drop.rarity,
            )
            self._event_bus.emit("loot", {"drop": drop})

        # Random events
        roll = self._rng.random()
        if roll < CRIT_PROBABILITY:
            bonus = int(self._xp_per_step * 5)
            self._xp += bonus
            self._add_feed(
                f"{self._icon('crit')} CRITICAL BATCH! +{bonus} XP", rarity=None
            )
        elif roll < CRIT_PROBABILITY + LUCKY_PROBABILITY:
            self._add_feed(
                f"{self._icon('lucky')} Lucky batch! Bonus incoming...", rarity=None
            )

        # Throttled render
        if self._throttle.should_update() and self._live:
            self._live.update(self._render())

    def epoch_end(self, metrics: dict[str, float] | None = None) -> None:
        self._current_epoch += 1
        if metrics:
            self._latest_metrics.update(metrics)
            for k, v in metrics.items():
                if isinstance(v, float) and not math.isnan(v):
                    buf = self._sparkline_buffers.setdefault(
                        k, deque(maxlen=SPARKLINE_BUFFER)
                    )
                    buf.append(v)
        if self._achievements.unlock("first_epoch", "First Epoch Complete"):
            self._add_feed(
                f"{self._icon('achievement')} First epoch complete!", rarity="uncommon"
            )
        completed = self._quest_tracker.check(self._latest_metrics)
        for q in completed:
            self._add_feed(
                f"{self._icon('quest')} Quest complete: {q.name}!", rarity="rare"
            )
        # Boss resolution
        if self._boss_active and metrics:
            defeated = self._check_boss_defeated(metrics)
            if defeated:
                bonus = 200
                self._xp += bonus
                self._add_feed(f"\U0001f480 BOSS DEFEATED: {self._boss_active}! +{bonus} XP", rarity="legendary")
                self._achievements.unlock("boss_defeated", "Defeated a Boss!")
            else:
                self._add_feed(f"\u26a0 Boss {self._boss_active} escaped...", rarity=None)
            self._boss_active = None
        if metrics:
            self._prev_epoch_metrics.update(metrics)
        # Boss spawn
        milestone = self._boss_milestone()
        if milestone:
            from lootqdm.classes import BOSS_NAMES  # noqa: PLC0415
            boss_name = BOSS_NAMES.get(self._class, BOSS_NAMES[None])[milestone]
            self._boss_active = boss_name
            self._add_feed(f"\u2694 BOSS: {boss_name} has appeared!", rarity="epic")
        if self._live:
            self._live.update(self._render())

    def _boss_milestone(self) -> str | None:
        if self._current_epoch == 1:
            return "first"
        mid = self._total_epochs // 2
        if mid > 1 and self._current_epoch == mid:
            return "mid"
        if self._current_epoch == self._total_epochs:
            return "final"
        return None

    def _check_boss_defeated(self, metrics: dict) -> bool:
        for k, v in metrics.items():
            prev = self._prev_epoch_metrics.get(k)
            if prev is None or prev == 0:
                continue
            if "loss" in k:
                if (prev - v) / abs(prev) >= 0.05:
                    return True
            else:
                if (v - prev) / abs(prev) >= 0.05:
                    return True
        return False

    def log(self, message: str, rarity: str | None = None) -> None:
        self._add_feed(message, rarity=rarity)
        if self._live and self._throttle.should_update():
            self._live.update(self._render())

    def quest(self, name: str, metric: str, target: float, compare: str = ">=") -> None:
        self._quest_tracker.add(
            name,
            metric,
            target,
            compare,
            start_value=self._latest_metrics.get(metric, 0.0),
        )

    def wrap(
        self, iterable: Iterable[T], metrics_fn: Callable | None = None
    ) -> Iterator[T]:
        for item in iterable:
            if metrics_fn:
                m = metrics_fn(item)
                self.step(m)
            else:
                self.step()
            yield item

    def pytorch_step(self, **metrics: float) -> None:
        self.step(metrics)

    # ── Internal ──

    def _icon(self, key: str) -> str:
        events = self._theme.icons.get("events", {})
        if key in events:
            return events[key] if self._emoji else ""
        return self._theme.icons.get(key, "") if self._emoji else ""

    def _add_feed(self, message: str, rarity: str | None) -> None:
        self._feed.insert(0, {"message": message, "rarity": rarity})
        if len(self._feed) > MAX_FEED_ITEMS:
            self._feed.pop()

    def _check_level_up(self) -> None:
        while self._xp >= _xp_for_level(self._level + 1):
            self._level += 1
            self._add_feed(
                f"{self._icon('level')} LEVEL UP! Now level {self._level}",
                rarity="rare",
            )
            self._event_bus.emit("level_up", {"level": self._level})
            if self._level in (5, 10, 25, 50, 100):
                self._achievements.unlock(
                    f"level_{self._level}", f"Reached Level {self._level}"
                )

    def _make_bar(self, fraction: float, width: int = 20) -> str:
        filled_char, empty_char = self._theme.bar_chars
        filled = int(fraction * width)
        return filled_char * filled + empty_char * (width - filled)

    def _render(self) -> Any:
        from rich.text import Text

        t = self._theme
        elapsed = time.monotonic() - self._start_time

        # ── Header ──
        title_icon = self._icon("level")

        # ── Progress panel ──
        epoch_frac = self._current_epoch / max(1, self._total_epochs)
        batch_frac = self._current_step / max(1, self._total_steps)

        if self._current_step > 0:
            rate = self._current_step / max(0.001, elapsed)
            remaining = (self._total_steps - self._current_step) / max(0.001, rate)
        else:
            rate = 0
            remaining = 0

        progress_lines = Text()
        progress_lines.append("\n  PROGRESS\n\n", style=t.palette["accent"])
        progress_lines.append(
            f"  Epoch  {self._current_epoch}/{self._total_epochs}  ",
            style=t.palette["soft"],
        )
        progress_lines.append(self._make_bar(epoch_frac, 12), style=t.palette["accent"])
        progress_lines.append(f"  {int(epoch_frac * 100)}%\n", style=t.palette["dim"])
        progress_lines.append(
            f"  Batch {self._current_step}/{self._total_steps} ",
            style=t.palette["soft"],
        )
        progress_lines.append(self._make_bar(batch_frac, 12), style=t.palette["accent"])
        progress_lines.append(f"  {int(batch_frac * 100)}%\n", style=t.palette["dim"])
        progress_lines.append(f"  ETA {format_time(remaining)}", style=t.palette["dim"])
        progress_lines.append(f"  {t.separators[0]}  ", style=t.palette["dim"])
        progress_lines.append(f"{int(rate)} it/s\n\n", style=t.palette["dim"])

        # XP bar
        xp_needed = _xp_for_level(self._level + 1)
        xp_in_level = self._xp - _xp_for_level(self._level)
        xp_span = xp_needed - _xp_for_level(self._level)
        xp_frac = xp_in_level / max(1, xp_span)
        progress_lines.append(f"  {self._icon('xp')} ", style=t.palette["accent"])
        progress_lines.append(self._make_bar(xp_frac, 10), style=t.palette["accent"])
        progress_lines.append(
            f"  {self._xp}/{xp_needed}  LV {self._level}\n", style=t.palette["soft"]
        )

        # ── Stats panel ──
        stats_lines = Text()
        stats_lines.append("\n  STATS\n\n", style=t.palette["accent"])

        display_order = [
            "loss",
            "acc",
            "accuracy",
            "val_loss",
            "val_acc",
            "val_accuracy",
            "lr",
            "learning_rate",
        ]
        shown: set[str] = set()
        for key in display_order:
            if key in self._latest_metrics and key not in shown:
                icon_str, game_name = self._mapper.format(
                    key, self._latest_metrics[key]
                )
                val_str = format_number(self._latest_metrics[key])
                stats_lines.append(
                    f"  {icon_str if self._emoji else ''} ", style=t.palette["accent"]
                )
                stats_lines.append(f"{game_name:6s}", style=t.palette["soft"])
                stats_lines.append(f"({key})", style=t.palette["dim"])
                pad = max(1, 14 - len(key))
                stats_lines.append(" " * pad)
                stats_lines.append(f"{val_str}\n", style=t.palette["soft"])
                shown.add(key)

        for key, val in self._latest_metrics.items():
            if key not in shown:
                icon_str, game_name = self._mapper.format(key, val)
                val_str = (
                    format_number(val) if isinstance(val, (int, float)) else str(val)
                )
                stats_lines.append(
                    f"  {icon_str if self._emoji else ''} ", style=t.palette["accent"]
                )
                stats_lines.append(f"{game_name:6s}", style=t.palette["soft"])
                pad = max(1, 14 - len(game_name))
                stats_lines.append(" " * pad)
                stats_lines.append(f"{val_str}\n", style=t.palette["soft"])
                shown.add(key)

        # Sparkline for loss
        if (
            "loss" in self._sparkline_buffers
            and len(self._sparkline_buffers["loss"]) > 1
        ):
            spark = sparkline(list(self._sparkline_buffers["loss"]), width=12)
            stats_lines.append(f"  \U0001f4c9 loss  ", style=t.palette["accent"])
            stats_lines.append(f"{spark}\n", style=t.palette["dim"])

        # GPU stats row (optional — fails silently if no GPU info)
        try:
            from lootqdm.gpu import get_gpu_stats  # noqa: PLC0415
            gpu = get_gpu_stats()
            if gpu is not None:
                gpu_name = gpu["name"][:18]
                stats_lines.append(f"  \U0001f5a5 ", style=t.palette["accent"])
                stats_lines.append(f"{gpu_name}", style=t.palette["soft"])
                if gpu["util_pct"] is not None:
                    stats_lines.append(f"  {gpu['util_pct']:.0f}%", style=t.palette["dim"])
                if gpu["mem_used_mb"] is not None and gpu["mem_total_mb"] is not None:
                    stats_lines.append(
                        f"  {gpu['mem_used_mb']:.0f}/{gpu['mem_total_mb']:.0f}MB",
                        style=t.palette["dim"],
                    )
                elif gpu["mem_used_mb"] is not None:
                    stats_lines.append(f"  {gpu['mem_used_mb']:.0f}MB", style=t.palette["dim"])
                if gpu["temp_c"] is not None:
                    stats_lines.append(f"  {gpu['temp_c']:.0f}\u00b0C", style=t.palette["dim"])
                stats_lines.append("\n")
        except Exception:
            pass

        # ── Loot feed ──
        loot_lines = Text()
        loot_lines.append("\n  LOOT & EVENTS\n\n", style=t.palette["accent"])
        for entry in self._feed[:6]:
            style = t.palette["soft"]
            if entry["rarity"] and entry["rarity"] in t.rarity_styles:
                style = t.rarity_styles[entry["rarity"]]
            loot_lines.append(f"  {entry['message']}\n", style=style)
        if not self._feed:
            loot_lines.append("  Waiting for drops...\n", style=t.palette["dim"])

        # ── Quests ──
        quest_lines = Text()
        quest_lines.append("\n  QUESTS\n\n", style=t.palette["accent"])
        for q in self._quest_tracker.all():
            if q.completed:
                quest_lines.append(
                    f"  \u2705 {q.name}  \u2713\n",
                    style=t.rarity_styles.get("uncommon", t.palette["soft"]),
                )
            else:
                bar = self._make_bar(q.progress, 5)
                pct = int(q.progress * 100)
                quest_lines.append(
                    f"  {self._icon('quest')} {q.metric} {q.compare} {q.target}  ",
                    style=t.palette["soft"],
                )
                quest_lines.append(bar, style=t.palette["accent"])
                quest_lines.append(f"  {pct}%\n", style=t.palette["dim"])

        for a in self._achievements.list_all()[-3:]:
            quest_lines.append(
                f"  \u2705 {a.description}  \u2713\n",
                style=t.rarity_styles.get("uncommon", t.palette["soft"]),
            )

        if not self._quest_tracker.all() and not self._achievements.list_all():
            quest_lines.append("  No active quests.\n", style=t.palette["dim"])

        # ── Assemble panel ──
        W = 80
        col_w = (W - 3) // 2  # = 38

        title_str = f"{title_icon} LOOTQDM"
        run_display = f"  {self._run_name}"
        sep = f" {t.separators[0]} "
        theme_display = t.name
        time_display = f"\u2699  {format_time(elapsed)}"
        inner_w = (col_w + 1) * 2 + 1
        left_part = run_display + sep + theme_display
        pad_len = max(2, inner_w - len(left_part) - len(time_display) - 1)
        header_str = left_part + " " * pad_len + time_display

        return _GamePanel(
            title=title_str,
            title_style=t.palette["title"],
            header_plain=header_str,
            header_style=t.palette["soft"],
            top_left_lines=_split_to_lines(progress_lines, col_w),
            top_right_lines=_split_to_lines(stats_lines, col_w),
            bot_left_lines=_split_to_lines(loot_lines, col_w),
            bot_right_lines=_split_to_lines(quest_lines, col_w),
            box_chars=t.box_chars,
            border_style=t.palette["dim"],
            col_w=col_w,
        )


class GameUI:
    """Main entry point. Auto-detects TTY and delegates to RichUI or PlainUI."""

    def __init__(
        self,
        total_steps: int,
        total_epochs: int = 1,
        theme: str = "dark_dungeon",
        refresh_rate: int = 10,
        emoji: bool = True,
        persist: bool = True,
        run_name: str | None = None,
        _force_plain: bool = False,
        class_: str | None = None,
    ) -> None:
        self._theme = get_theme(theme)
        self._total_steps = total_steps
        self._total_epochs = total_epochs

        use_plain = _force_plain or not is_tty()
        if use_plain:
            self._impl = PlainUI(
                total_steps=total_steps,
                total_epochs=total_epochs,
                class_=class_,
            )
        else:
            self._impl = RichUI(
                total_steps=total_steps,
                total_epochs=total_epochs,
                theme=self._theme,
                refresh_rate=refresh_rate,
                emoji=emoji,
                persist=persist,
                run_name=run_name,
                class_=class_,
            )

        # Proxy state for testing
        self._current_step = 0
        self._latest_metrics: dict[str, float] = {}
        self._feed = self._impl._feed
        self._achievements = self._impl._achievements
        self._quest_tracker = self._impl._quest_tracker

    def __enter__(self) -> GameUI:
        self._impl.__enter__()
        return self

    def __exit__(self, *exc: Any) -> None:
        self._impl.__exit__(*exc)

    def step(self, metrics: dict[str, float] | None = None, n: int = 1) -> None:
        self._impl.step(metrics, n)
        self._current_step = self._impl._current_step
        self._latest_metrics = self._impl._latest_metrics

    def epoch_end(self, metrics: dict[str, float] | None = None) -> None:
        self._impl.epoch_end(metrics)
        self._latest_metrics = self._impl._latest_metrics

    def log(self, message: str, rarity: str | None = None) -> None:
        self._impl.log(message, rarity)

    def quest(self, name: str, metric: str, target: float, compare: str = ">=") -> None:
        self._impl.quest(name, metric, target, compare)

    def wrap(
        self, iterable: Iterable[T], metrics_fn: Callable | None = None
    ) -> Iterator[T]:
        for item in iterable:
            if metrics_fn:
                m = metrics_fn(item)
                self.step(m)
            else:
                self.step()
            yield item

    def pytorch_step(self, **metrics: float) -> None:
        self._impl.pytorch_step(**metrics)
