"""Theme definitions for lootqdm."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from rich.box import Box, ROUNDED, HEAVY, DOUBLE, ASCII


@dataclass(frozen=True)
class Theme:
    """Immutable theme definition."""

    name: str
    palette: dict[str, str]
    icons: dict[str, Any]
    rarity_styles: dict[str, str]
    bar_chars: tuple[str, str]
    border: Box
    separators: tuple[str, ...]
    loot_names: dict[str, list[str]]
    box_chars: dict[str, str]


_COZY_PASTEL = Theme(
    name="cozy_pastel",
    palette={
        "title": "bold magenta",
        "accent": "bright_cyan",
        "soft": "bright_white",
        "dim": "grey70",
    },
    icons={
        "xp": "\U0001f331",          # 🌱
        "level": "\U0001f9fa",        # 🧺
        "prestige": "\U0001f36f",     # 🍯
        "quest": "\U0001f4cc",        # 📌
        "achievement": "\U0001f3e1",  # 🏡
        "loot": {
            "common": "\U0001f353",     # 🍓
            "uncommon": "\U0001f950",   # 🥐
            "rare": "\U0001fad0",       # 🫐
            "epic": "\U0001f382",       # 🎂
            "legendary": "\U0001f9c1",  # 🧁
        },
        "events": {
            "crit": "\u2728",       # ✨
            "lucky": "\U0001f340",  # 🍀
            "warning": "\u26a0\ufe0f",  # ⚠️
        },
    },
    rarity_styles={
        "common": "grey70",
        "uncommon": "green",
        "rare": "bright_cyan",
        "epic": "bright_magenta",
        "legendary": "bold bright_yellow",
    },
    bar_chars=("\u25b0", "\u25b1"),  # ▰ ▱
    border=ROUNDED,
    separators=("\u00b7", "\u2022", "\u2500"),  # · • ─
    loot_names={
        "common": ["Strawberry Badge", "Daisy Pin", "Clover Patch", "Acorn Button", "Pebble Charm"],
        "uncommon": ["Croissant Medal", "Lavender Sprig", "Honeycomb Tile", "Rose Quartz", "Mint Leaf"],
        "rare": ["Blueberry Charm", "Moonstone Brooch", "Crystal Dewdrop", "Peach Blossom Ring", "Starfruit Gem"],
        "epic": ["Golden Honeycomb", "Aurora Ribbon", "Enchanted Teacup", "Rainbow Preserve", "Celestial Jam Jar"],
        "legendary": ["Crown of Petals", "Evergarden Seed", "The Cozy Chalice", "Sunbeam Locket", "Dreamer's Quilt"],
    },
    box_chars={
        "top_left": "╭", "top_right": "╮",
        "bot_left": "╰", "bot_right": "╯",
        "horiz": "─", "vert": "│",
        "top_tee": "┬", "bot_tee": "┴",
        "left_tee": "├", "right_tee": "┤",
        "cross": "┼",
    },
)

_DARK_DUNGEON = Theme(
    name="dark_dungeon",
    palette={
        "title": "bold bright_red",
        "accent": "yellow",
        "soft": "grey82",
        "dim": "grey42",
    },
    icons={
        "xp": "\U0001fa78",          # 🩸
        "level": "\U0001f5e1\ufe0f", # 🗡️
        "prestige": "\U0001f451",    # 👑
        "quest": "\U0001f4dc",       # 📜
        "achievement": "\U0001f3c6", # 🏆
        "loot": {
            "common": "\U0001fa99",    # 🪙
            "uncommon": "\U0001f527",  # 🔧
            "rare": "\U0001f4a0",      # 💠
            "epic": "\U0001f52e",      # 🔮
            "legendary": "\u269c\ufe0f",  # ⚜️
        },
        "events": {
            "crit": "\U0001f4a5",      # 💥
            "lucky": "\U0001f987",     # 🦇
            "warning": "\u2620\ufe0f", # ☠️
        },
    },
    rarity_styles={
        "common": "grey62",
        "uncommon": "green",
        "rare": "bright_cyan",
        "epic": "bright_magenta",
        "legendary": "bold bright_yellow",
    },
    bar_chars=("\u2588", "\u2591"),  # █ ░
    border=HEAVY,
    separators=("\u2550", "\u256c", "\u2502"),  # ═ ╬ │
    loot_names={
        "common": ["Rusty Coin", "Bone Fragment", "Tattered Cloth", "Dull Fang", "Cracked Stone"],
        "uncommon": ["Iron Buckle", "Goblin Ear", "Dungeon Moss", "Whetstone Shard", "Torch Stub"],
        "rare": ["Cursed Relic", "Void Shard", "Shadow Essence", "Dragon Scale", "Obsidian Key"],
        "epic": ["Bloodstone Amulet", "Lich's Finger", "Abyssal Lens", "Doom Signet", "Spectral Chain"],
        "legendary": ["Royal Sigil", "Cursed Crown", "Blade of Epochs", "The Undying Flame", "Throne Shard"],
    },
    box_chars={
        "top_left": "┏", "top_right": "┓",
        "bot_left": "┗", "bot_right": "┛",
        "horiz": "━", "vert": "┃",
        "top_tee": "┳", "bot_tee": "┻",
        "left_tee": "┣", "right_tee": "┫",
        "cross": "╋",
    },
)

_NEON_CYBER = Theme(
    name="neon_cyber",
    palette={
        "title": "bold bright_cyan",
        "accent": "bright_magenta",
        "soft": "bright_white",
        "dim": "grey58",
    },
    icons={
        "xp": "\u26a1",             # ⚡
        "level": "\U0001f9ec",       # 🧬
        "prestige": "\U0001f6f0\ufe0f",  # 🛰️
        "quest": "\U0001f3af",       # 🎯
        "achievement": "\U0001f947", # 🥇
        "loot": {
            "common": "\U0001f529",    # 🔩
            "uncommon": "\U0001f4c0",  # 📀
            "rare": "\U0001f4bf",      # 💿
            "epic": "\U0001f9ea",      # 🧪
            "legendary": "\U0001f48e", # 💎
        },
        "events": {
            "crit": "\U0001f525",      # 🔥
            "lucky": "\U0001f3b0",     # 🎰
            "warning": "\U0001f6a8",   # 🚨
        },
    },
    rarity_styles={
        "common": "grey62",
        "uncommon": "bright_green",
        "rare": "bright_cyan",
        "epic": "bright_magenta",
        "legendary": "bold bright_yellow",
    },
    bar_chars=("\u25ae", "\u25af"),  # ▮ ▯
    border=DOUBLE,
    separators=("\u2550", "\u2500", "\u23af"),  # ═ ─ ⎯
    loot_names={
        "common": ["Chrome Bolt", "Wire Scrap", "Pixel Dust", "Nano Chip", "Data Fragment"],
        "uncommon": ["Synth Disk", "Plasma Coil", "Neon Tube", "Circuit Board", "Holo Shard"],
        "rare": ["Quantum Core", "Cyber Lens", "Void Capacitor", "Neural Link", "Phase Crystal"],
        "epic": ["Antimatter Vial", "Singularity Probe", "Dark Energy Cell", "Fusion Matrix", "Nexus Key"],
        "legendary": ["Quantum Gem", "The Architect's Eye", "Infinity Codec", "Stellar Engine", "Omega Prism"],
    },
    box_chars={
        "top_left": "╔", "top_right": "╗",
        "bot_left": "╚", "bot_right": "╝",
        "horiz": "═", "vert": "║",
        "top_tee": "╦", "bot_tee": "╩",
        "left_tee": "╠", "right_tee": "╣",
        "cross": "╬",
    },
)

_RETRO_CRT = Theme(
    name="retro_crt",
    palette={
        "title": "bold green",
        "accent": "green",
        "soft": "bright_green",
        "dim": "grey37",
    },
    icons={
        "xp": "+XP",
        "level": "LV",
        "prestige": "ASC",
        "quest": "QST",
        "achievement": "ACH",
        "loot": {
            "common": "[C]",
            "uncommon": "[U]",
            "rare": "[R]",
            "epic": "[E]",
            "legendary": "[L]",
        },
        "events": {
            "crit": "!!",
            "lucky": "LUCK",
            "warning": "WARN",
        },
    },
    rarity_styles={
        "common": "grey62",
        "uncommon": "green",
        "rare": "bright_green",
        "epic": "bold green",
        "legendary": "bold bright_green on green",
    },
    bar_chars=("#", "-"),
    border=ASCII,
    separators=("-", "|", "+"),
    loot_names={
        "common": ["Green Phosphor", "Dot Matrix", "Null Byte", "Ping Token", "Baud Bit"],
        "uncommon": ["ANSI Escape", "Cursor Block", "Stack Frame", "Pipe Coupler", "Shell Script"],
        "rare": ["ANSI Trophy", "Kernel Panic Badge", "Root Shell", "Daemon Core", "Buffer Gem"],
        "epic": ["Segfault Sigil", "Fork Bomb Shield", "Mainframe Key", "Epoch Counter", "Recursive Ring"],
        "legendary": ["BBS Crown", "The Golden Prompt", "UNIX Epoch Zero", "Root of All Shells", "The Last Byte"],
    },
    box_chars={
        "top_left": "+", "top_right": "+",
        "bot_left": "+", "bot_right": "+",
        "horiz": "-", "vert": "|",
        "top_tee": "+", "bot_tee": "+",
        "left_tee": "+", "right_tee": "+",
        "cross": "+",
    },
)

THEMES: dict[str, Theme] = {
    "cozy_pastel": _COZY_PASTEL,
    "dark_dungeon": _DARK_DUNGEON,
    "neon_cyber": _NEON_CYBER,
    "retro_crt": _RETRO_CRT,
}


def get_theme(name: str = "dark_dungeon") -> Theme:
    """Get a theme by name. Raises KeyError if not found."""
    try:
        return THEMES[name]
    except KeyError:
        raise KeyError(f"Unknown theme {name!r}. Available: {list(THEMES.keys())}")


def list_themes() -> list[str]:
    """Return list of available theme names."""
    return list(THEMES.keys())
