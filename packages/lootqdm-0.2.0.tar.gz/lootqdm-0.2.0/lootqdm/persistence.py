"""Profile persistence for lootqdm."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger("lootqdm")

DEFAULT_PROFILE_DIR = Path.home() / ".lootqdm"
DEFAULT_PROFILE_PATH = DEFAULT_PROFILE_DIR / "profile.json"


@dataclass
class Profile:
    lifetime_xp: int = 0
    total_runs: int = 0
    level: int = 1
    achievements: list[str] = field(default_factory=list)
    loot_log: list[dict[str, Any]] = field(default_factory=list)
    prestige: int = 0

    def add_xp(self, xp: int) -> None:
        self.lifetime_xp += xp

    def record_run(self) -> None:
        self.total_runs += 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "lifetime_xp": self.lifetime_xp,
            "total_runs": self.total_runs,
            "level": self.level,
            "achievements": self.achievements,
            "loot_log": self.loot_log,
            "prestige": self.prestige,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Profile:
        return cls(
            lifetime_xp=data.get("lifetime_xp", 0),
            total_runs=data.get("total_runs", 0),
            level=data.get("level", 1),
            achievements=data.get("achievements", []),
            loot_log=data.get("loot_log", []),
            prestige=data.get("prestige", 0),
        )


def save_profile(profile: Profile, path: Path = DEFAULT_PROFILE_PATH) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(profile.to_dict(), indent=2))
    except OSError as e:
        logger.warning("Failed to save profile: %s", e)


def load_profile(path: Path = DEFAULT_PROFILE_PATH) -> Profile:
    try:
        if not path.exists():
            return Profile()
        data = json.loads(path.read_text())
        return Profile.from_dict(data)
    except (OSError, json.JSONDecodeError, TypeError) as e:
        logger.warning("Failed to load profile: %s", e)
        return Profile()
