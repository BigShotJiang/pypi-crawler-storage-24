"""Utility functions: TTY detection, sparklines, throttling, formatting."""

from __future__ import annotations

import os
import sys
import time
from collections import deque
from typing import Sequence

SPARK_CHARS = "\u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588"


def is_tty() -> bool:
    """Check if stdout is a TTY and Rich UI should be used."""
    if os.environ.get("LOOTQDM_PLAIN", "").strip() in ("1", "true", "yes"):
        return False
    if os.environ.get("TERM", "") == "dumb":
        return False
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


def sparkline(values: Sequence[float], width: int | None = None) -> str:
    """Render a sparkline string from numeric values using Unicode block chars."""
    if not values:
        return ""
    if width is not None and len(values) > width:
        values = values[-width:]
    mn, mx = min(values), max(values)
    span = mx - mn
    if span == 0:
        if len(values) == 1:
            return SPARK_CHARS[-1]
        idx = len(SPARK_CHARS) // 2
        return SPARK_CHARS[idx] * len(values)
    result = []
    for v in values:
        normalized = (v - mn) / span
        i = round(normalized * (len(SPARK_CHARS) - 1))
        result.append(SPARK_CHARS[i])
    return "".join(result)


def format_time(seconds: float) -> str:
    """Format seconds as HH:MM:SS."""
    seconds = int(max(0, seconds))
    h, remainder = divmod(seconds, 3600)
    m, s = divmod(remainder, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def format_number(value: float) -> str:
    """Format a metric value for display."""
    if value == 0:
        return "0.0000"
    abs_val = abs(value)
    if abs_val < 0.001:
        exp = 0
        v = abs_val
        while v < 1.0:
            v *= 10
            exp += 1
        mantissa = value * (10 ** exp)
        if mantissa == int(mantissa):
            return f"{int(mantissa)}e-{exp}"
        return f"{mantissa:.1f}e-{exp}"
    if abs_val < 1.0:
        return f"{value:.4f}"
    if abs_val < 100:
        return f"{value:.2f}"
    return f"{int(value)}"


class Throttle:
    """Rate limiter for UI refresh."""

    def __init__(self, fps: int = 10) -> None:
        self._interval = 1.0 / max(1, fps)
        self._last_update = 0.0

    def should_update(self) -> bool:
        now = time.monotonic()
        if now - self._last_update >= self._interval:
            self._last_update = now
            return True
        return False
