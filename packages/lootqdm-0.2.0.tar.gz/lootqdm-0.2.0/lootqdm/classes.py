"""Class system: loot name flavor overrides and boss names per player class."""
from __future__ import annotations

VALID_CLASSES: frozenset[str] = frozenset({"wizard", "warrior", "rogue"})

CLASS_LOOT_OVERRIDES: dict[str, dict[str, list[str]]] = {
    "wizard": {
        "common":    ["Arcane Dust", "Mana Residue", "Spell Fragment", "Glyph Chip", "Magic Cinder"],
        "uncommon":  ["Spell Tome", "Mana Crystal", "Glyph Shard", "Arcane Scroll", "Focus Gem"],
        "rare":      ["Ether Core", "Runic Slab", "Soul Prism", "Void Catalyst", "Arcane Sigil"],
        "epic":      ["Forbidden Codex", "Astral Lens", "Eldritch Staff", "Mana Vortex", "Lich Seal"],
        "legendary": ["Crown of Spells", "The Infinite Tome", "Arcane Throne", "Worldsoul Crystal", "Epoch Rune"],
    },
    "warrior": {
        "common":    ["Iron Scrap", "Battle Dust", "Dented Helm", "Broken Shield", "War Shard"],
        "uncommon":  ["Iron Shield", "War Axe", "Battle Standard", "Siege Bolt", "Warrior's Crest"],
        "rare":      ["Dragon Plate", "Warlord's Seal", "Bloodsteel Sword", "Fortress Key", "Titan Gauntlet"],
        "epic":      ["Siege Engine Part", "Colossus Pauldron", "Champion's Brand", "Iron Throne Shard", "Warmaster Relic"],
        "legendary": ["The Iron Crown", "Warbringer's Axe", "Eternal Shield", "Dragon Lord Armor", "Legendary War Banner"],
    },
    "rogue": {
        "common":    ["Shadow Dust", "Smoke Fragment", "Poison Drop", "Frayed Cloak", "Lockpick Shard"],
        "uncommon":  ["Shadow Dagger", "Smoke Bomb", "Poison Vial", "Thief's Coin", "Cloak of Shadows"],
        "rare":      ["Venomblade", "Phantom Step", "Night Seal", "Assassin's Mark", "Void Garrote"],
        "epic":      ["Wraith Shroud", "Deathwhisper Blade", "Phantom Crown", "Shadow Throne Token", "Eclipse Poison"],
        "legendary": ["The Night Throne", "Shadowstep Mantle", "Eternal Silence", "Void King's Mark", "The Last Shadow"],
    },
}

BOSS_NAMES: dict[str | None, dict[str, str]] = {
    "wizard":  {"first": "The Mana Drake",    "mid": "The Arcane Lich",   "final": "The Void Architect"},
    "warrior": {"first": "Iron Golem",         "mid": "The Warlord",       "final": "Dragon Lord"},
    "rogue":   {"first": "Shadow Stalker",     "mid": "The Phantom",       "final": "The Night King"},
    None:      {"first": "The First Guardian", "mid": "The Midfield Boss", "final": "The Final Arbiter"},
}


def get_loot_names(
    class_: str | None, theme_names: dict[str, list[str]]
) -> dict[str, list[str]]:
    """Return class-specific loot names, or theme names if no class/invalid class."""
    if class_ in VALID_CLASSES:
        return CLASS_LOOT_OVERRIDES[class_]
    return theme_names
