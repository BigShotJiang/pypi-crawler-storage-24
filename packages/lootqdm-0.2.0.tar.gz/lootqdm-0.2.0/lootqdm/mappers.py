"""StatMapper: translate ML metrics to game-stat names and icons."""

from __future__ import annotations

from typing import Any

DEFAULT_MAPPINGS: dict[str, tuple[str, str]] = {
    "loss": ("DMG", "\u2694"),
    "train_loss": ("DMG", "\u2694"),
    "val_loss": ("vDMG", "\U0001f6e1"),
    "acc": ("CRIT", "\U0001f3af"),
    "accuracy": ("CRIT", "\U0001f3af"),
    "val_acc": ("vCRIT", "\U0001f3af"),
    "val_accuracy": ("vCRIT", "\U0001f3af"),
    "lr": ("MANA", "\U0001f4a7"),
    "learning_rate": ("MANA", "\U0001f4a7"),
    "f1": ("F1 PWR", "\u2694"),
    "f1_score": ("F1 PWR", "\u2694"),
    "auc": ("AUC", "\U0001f4c8"),
    "throughput": ("SPD", "\U0001f3c3"),
    "gpu_mem": ("VRAM", "\U0001f525"),
    "gpu_util": ("GPU", "\U0001f525"),
}


class StatMapper:
    """Maps ML metric keys to game stat names and icons."""

    def __init__(self, mappings: dict[str, tuple[str, str]] | None = None) -> None:
        self._mappings = {**DEFAULT_MAPPINGS}
        if mappings:
            self._mappings.update(mappings)

    def game_name(self, metric_key: str) -> str:
        if metric_key in self._mappings:
            return self._mappings[metric_key][0]
        return metric_key

    def icon(self, metric_key: str) -> str:
        if metric_key in self._mappings:
            return self._mappings[metric_key][1]
        return "\u2022"

    def format(self, metric_key: str, value: float) -> tuple[str, str]:
        return self.icon(metric_key), self.game_name(metric_key)
