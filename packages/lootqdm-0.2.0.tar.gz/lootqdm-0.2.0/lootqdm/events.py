"""Event system: rarity rolls, loot tables, achievements, event bus."""

from __future__ import annotations

from dataclasses import dataclass, field
from random import Random
from typing import Any, Callable

from lootqdm.themes import get_theme

RARITY_ORDER = ("common", "uncommon", "rare", "epic", "legendary")

RARITY_WEIGHTS: dict[str, float] = {
    "common": 0.700,
    "uncommon": 0.200,
    "rare": 0.080,
    "epic": 0.019,
    "legendary": 0.001,
}

RARITY_XP: dict[str, int] = {
    "common": 5,
    "uncommon": 15,
    "rare": 50,
    "epic": 150,
    "legendary": 500,
}


def roll_rarity(rng: Random, luck: float = 0.0) -> str:
    """Roll a rarity tier. Luck (0.0-1.0) shifts probability toward rarer tiers."""
    luck = max(0.0, min(1.0, luck))
    weights = []
    for rarity in RARITY_ORDER:
        w = RARITY_WEIGHTS[rarity]
        if rarity == "common":
            w *= 1.0 - luck * 0.5
        elif rarity in ("rare", "epic", "legendary"):
            w *= 1.0 + luck * 3.0
        weights.append(w)
    total = sum(weights)
    roll = rng.random() * total
    cumulative = 0.0
    for i, w in enumerate(weights):
        cumulative += w
        if roll <= cumulative:
            return RARITY_ORDER[i]
    return RARITY_ORDER[0]


@dataclass(frozen=True)
class LootDrop:
    """A single loot drop result."""

    name: str
    rarity: str
    xp: int


class LootTable:
    """Generates loot drops themed to a specific theme."""

    def __init__(self, theme_name: str, class_: str | None = None) -> None:
        from lootqdm.classes import get_loot_names  # noqa: PLC0415
        self._theme = get_theme(theme_name)
        self._loot_names = get_loot_names(class_, self._theme.loot_names)

    def roll(self, rng: Random, luck: float = 0.0) -> LootDrop:
        rarity = roll_rarity(rng, luck)
        name = rng.choice(self._loot_names[rarity])
        return LootDrop(name=name, rarity=rarity, xp=RARITY_XP[rarity])


@dataclass
class Achievement:
    """A single achievement."""

    key: str
    description: str


class AchievementTracker:
    """Tracks unlocked achievements."""

    def __init__(self) -> None:
        self.unlocked: dict[str, Achievement] = {}

    def unlock(self, key: str, description: str) -> bool:
        """Unlock an achievement. Returns True if newly unlocked, False if duplicate."""
        if key in self.unlocked:
            return False
        self.unlocked[key] = Achievement(key=key, description=description)
        return True

    def list_all(self) -> list[Achievement]:
        """List all unlocked achievements."""
        return list(self.unlocked.values())

    def is_unlocked(self, key: str) -> bool:
        return key in self.unlocked


@dataclass
class Event:
    """An event emitted on the bus."""

    type: str
    data: dict[str, Any]


class EventBus:
    """Simple synchronous event bus."""

    def __init__(self) -> None:
        self._listeners: dict[str, list[Callable[[Event], None]]] = {}

    def on(self, event_type: str, callback: Callable[[Event], None]) -> None:
        """Register a listener for an event type."""
        self._listeners.setdefault(event_type, []).append(callback)

    def emit(self, event_type: str, data: dict[str, Any] | None = None) -> None:
        """Emit an event to all registered listeners."""
        event = Event(type=event_type, data=data or {})
        for callback in self._listeners.get(event_type, []):
            callback(event)
