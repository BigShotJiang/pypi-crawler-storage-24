# lootqdm Design Document

**Date**: 2026-03-09
**Tagline**: "Turn your training loop into an idle RPG."

## Overview

Drop-in progress visualization for ML training that feels like an idle/incremental game. XP bars, level-ups, loot drops, quests, achievements — all rendered in a beautiful Rich terminal UI.

## Decisions

- **Package name**: `lootqdm`
- **Build system**: Hatch (PEP 621)
- **Rendering**: Rich `Live` + `Table` (single-threaded, throttled)
- **Persistence**: JSON at `~/.lootqdm/profile.json`
- **TTY fallback**: Plain `logging` module
- **Scope**: Core + PyTorch + Keras integrations

## Module Structure

```
lootqdm/
  __init__.py          # Public API exports
  ui.py                # GameUI — Rich Live layout, context manager
  themes.py            # Theme dataclasses + registry (4 built-in)
  events.py            # EventBus, rarity system, LootTable, achievements
  mappers.py           # StatMapper: metrics -> game stats
  quests.py            # Quest definitions + tracking
  persistence.py       # JSON profile save/load
  utils.py             # TTY detection, throttling, terminal size, sparkline
  integrations/
    __init__.py
    torch.py           # PyTorch training helper
    keras.py           # Keras Callback subclass
examples/
  basic_loop.py
  pytorch_mnist.py
  keras_callback.py
tests/
  test_events.py
  test_mappers.py
  test_quests.py
  test_themes.py
  test_ui.py
  test_utils.py
  test_persistence.py
```

## UI Layout

Single rounded outer frame with 2x2 internal grid. Title integrated into top border. Themes swap border characters.

```
╭─ ⚔ LOOTQDM ──────────────────────────────────────────────────────────╮
│  mnist_run · dark_dungeon                    ⚙        00:12:34       │
├───────────────────────────────────┬──────────────────────────────────┤
│                                   │                                  │
│  PROGRESS                         │  STATS                           │
│                                   │                                  │
│  Epoch  3/10  █████████░░░  80%   │  ⚔  DMG  (loss)       0.0234   │
│  Batch 128/500 ███████░░░░  56%   │  🎯 CRIT (acc)        94.2%    │
│  ETA 00:08:22  ·  1284 it/s       │  💧 MANA (lr)         1e-4     │
│                                   │  📈 loss  ▇▆▅▄▃▃▂▂▁▁           │
│  XP ▰▰▰▰▰▰▰▱▱▱  2340/3000 LV 7  │  🔥 GPU   78%  · 4.2 GB       │
│                                   │                                  │
├───────────────────────────────────┼──────────────────────────────────┤
│                                   │                                  │
│  LOOT & EVENTS                    │  QUESTS                          │
│                                   │                                  │
│  ⚜️  LEGENDARY Cursed Crown! +500 │  📜 acc ≥ 0.95  ▰▰▰▰▱  94%    │
│  💠 Rare Void Shard  +50 XP       │  📜 loss < 0.01 ▰▰▱▱▱  42%    │
│  💥 CRITICAL BATCH!  +20 XP       │  ✅ First epoch  ✓              │
│  🪙 Rusty Coin  +5 XP             │  ✅ New best acc  ✓             │
│                                   │                                  │
╰───────────────────────────────────┴──────────────────────────────────╯
```

### Rich Implementation

- Outer frame: Custom `Box` on a `Table` (2 cols, 2 rows) inside `Panel(box=ROUNDED)`
- Header: Rendered above the table inside the panel
- Internal grid: `Table` with `show_lines=True`, custom box style for inner dividers
- Sparkline: Unicode block chars `▁▂▃▄▅▆▇█` built in `utils.py`
- Auto-collapse: Check terminal width; drop stats/quests columns if < 80 cols

## Public API

```python
class GameUI:
    def __init__(
        self,
        total_steps: int,
        total_epochs: int = 1,
        theme: str = "dark_dungeon",
        refresh_rate: int = 10,
        emoji: bool = True,
        persist: bool = True,
        run_name: str | None = None,
    ) -> None: ...

    def __enter__(self) -> "GameUI": ...
    def __exit__(self, *exc: Any) -> None: ...
    def step(self, metrics: dict[str, float] | None = None, n: int = 1) -> None: ...
    def epoch_end(self, metrics: dict[str, float] | None = None) -> None: ...
    def log(self, message: str, rarity: str | None = None) -> None: ...
    def quest(self, name: str, metric: str, target: float, compare: str = ">=") -> None: ...
    def wrap(self, iterable: Iterable[T], metrics_fn: Callable | None = None) -> Iterator[T]: ...
    def pytorch_step(self, **metrics: float) -> None: ...
```

## Theme System

4 built-in themes, each a frozen dataclass:

| Field | Type | Description |
|-------|------|-------------|
| `name` | str | Theme identifier |
| `palette` | dict | Rich style strings for title, accent, soft, dim |
| `icons` | dict | Emoji/text for xp, level, prestige, quest, achievement, loot rarities, events |
| `rarity_styles` | dict | Rich styles per rarity level |
| `bar_chars` | tuple[str,str] | (filled, empty) characters |
| `border` | Box | Rich Box style for outer frame |
| `separators` | tuple | Separator characters |

### Themes

1. **cozy_pastel** — Rounded borders, pastels, farming icons (🌱🧺🍓)
2. **dark_dungeon** — Thick/red borders, gritty icons (🩸🗡️🪙)
3. **neon_cyber** — Double-line cyan borders, synth icons (⚡🧬💎)
4. **retro_crt** — ASCII `+---+` borders, text-only tags ([C][U][R])

## Rarity System

Probabilities: common 0.70, uncommon 0.20, rare 0.08, epic 0.019, legendary 0.001

```python
def roll_rarity(rng: Random, luck: float = 0.0) -> str: ...

class LootTable:
    def __init__(self, theme: str) -> None: ...
    def roll(self, rng: Random, luck: float = 0.0) -> LootDrop: ...
```

Each theme has ~5 items per rarity with cosmetic names.

## XP & Level System

- Base XP per step: `total_xp / total_steps` (default total_xp = 10000)
- Level thresholds: `base * n^1.5` (quadratic-ish curve)
- Loot rolls every N steps (default 50, configurable)
- Event rolls per step with low probability

## Quest System

```python
@dataclass
class Quest:
    name: str
    metric: str
    target: float
    compare: str  # ">=", "<=", ">", "<"
    completed: bool = False
    current: float = 0.0
```

Checked on `epoch_end()`. Progress shown as inline mini-bars.

## Achievement System

Built-in achievements:
- First epoch complete
- New best metric (per metric key)
- NaN survived (detect + warn)
- Level milestones (5, 10, 25, 50)
- Legendary loot found

## Sparkline

Rolling buffer of last N values (default 20), rendered as `▁▂▃▄▅▆▇█` mapped to min-max range.

## Persistence

```json
{
  "lifetime_xp": 52340,
  "total_runs": 7,
  "level": 23,
  "achievements": ["first_epoch", "legendary_loot"],
  "loot_log": [{"name": "Cursed Crown", "rarity": "legendary", "run": 5}],
  "prestige": 0
}
```

Saved to `~/.lootqdm/profile.json` on `__exit__`.

## TTY Fallback

When `not sys.stdout.isatty()` or `LOOTQDM_PLAIN=1`:
- `GameUI` swaps to `PlainUI` internally
- Uses `logging.getLogger("lootqdm")`
- Logs: step counts, metrics, loot drops, quest completions
- No Rich, no special characters

## Dependencies

- **Required**: `rich>=13.0`
- **Optional**: `torch` (for integrations), `tensorflow` (for Keras callback)

## Performance

- Refresh throttled to `refresh_rate` fps (default 10)
- Loot/event rolls use cheap RNG (no crypto)
- Sparkline buffer is fixed-size deque
- No redraws if nothing changed since last frame
