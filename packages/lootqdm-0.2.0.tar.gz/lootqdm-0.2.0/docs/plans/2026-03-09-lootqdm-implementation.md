# lootqdm Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a complete, pip-installable Python library that replaces bland tqdm/rich training progress bars with an idle RPG experience — XP bars, loot drops, quests, achievements, themed UI.

**Architecture:** Rich `Live` wrapping a `Table`-based 2x2 grid layout inside a `Panel`. An internal `EventBus` decouples metric ingestion from visual effects. `ThemeRegistry` provides theme data as frozen dataclasses. `StatMapper` translates ML metrics to game stat names. TTY fallback via plain logging.

**Tech Stack:** Python 3.10+, Rich (rendering), Hatch (build), pytest (testing)

---

## Wave 1: Foundation (independent, parallelize all)

### Task 1: Project Scaffold + pyproject.toml

**Files:**
- Create: `pyproject.toml`
- Create: `lootqdm/__init__.py`
- Create: `lootqdm/integrations/__init__.py`
- Create: `tests/__init__.py`
- Create: `tests/conftest.py`

**Step 1: Create pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "lootqdm"
version = "0.1.0"
description = "Turn your training loop into an idle RPG."
readme = "README.md"
license = "MIT"
requires-python = ">=3.10"
authors = [{ name = "lootqdm contributors" }]
keywords = ["progress-bar", "training", "ml", "deep-learning", "tqdm", "rich", "game", "idle"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "Intended Audience :: Science/Research",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Topic :: Scientific/Engineering :: Artificial Intelligence",
    "Topic :: System :: Logging",
]
dependencies = ["rich>=13.0"]

[project.optional-dependencies]
torch = ["torch"]
keras = ["tensorflow"]
dev = ["pytest>=7.0", "pytest-cov"]

[project.urls]
Homepage = "https://github.com/lootqdm/lootqdm"
Repository = "https://github.com/lootqdm/lootqdm"

[tool.hatch.build.targets.wheel]
packages = ["lootqdm"]

[tool.pytest.ini_options]
testpaths = ["tests"]
```

**Step 2: Create lootqdm/__init__.py**

```python
"""lootqdm — Turn your training loop into an idle RPG."""

from lootqdm.ui import GameUI
from lootqdm.events import LootTable, roll_rarity
from lootqdm.mappers import StatMapper
from lootqdm.themes import get_theme, list_themes
from lootqdm.quests import Quest

__all__ = [
    "GameUI",
    "LootTable",
    "Quest",
    "StatMapper",
    "get_theme",
    "list_themes",
    "roll_rarity",
]
__version__ = "0.1.0"
```

**Step 3: Create empty integration and test init files**

```python
# lootqdm/integrations/__init__.py
"""Framework integrations for lootqdm."""

# tests/__init__.py
# (empty)
```

**Step 4: Create tests/conftest.py**

```python
"""Shared test fixtures for lootqdm."""

from __future__ import annotations

import pytest
from random import Random


@pytest.fixture
def rng() -> Random:
    """Deterministic RNG for reproducible tests."""
    return Random(42)
```

**Step 5: Commit**

```bash
git init
git add pyproject.toml lootqdm/__init__.py lootqdm/integrations/__init__.py tests/__init__.py tests/conftest.py
git commit -m "feat: project scaffold with pyproject.toml and package structure"
```

---

### Task 2: Utils Module (TTY detection, sparkline, throttle)

**Files:**
- Create: `lootqdm/utils.py`
- Create: `tests/test_utils.py`

**Step 1: Write failing tests**

```python
"""Tests for lootqdm.utils."""

from __future__ import annotations

from collections import deque

from lootqdm.utils import is_tty, sparkline, format_time, format_number, Throttle
import time


class TestSparkline:
    def test_empty(self):
        assert sparkline([]) == ""

    def test_single_value(self):
        result = sparkline([5.0])
        assert len(result) == 1
        assert result == "█"

    def test_ascending(self):
        result = sparkline([0.0, 0.25, 0.5, 0.75, 1.0])
        assert result == "▁▃▅▆█"

    def test_descending(self):
        result = sparkline([1.0, 0.75, 0.5, 0.25, 0.0])
        assert result == "█▆▅▃▁"

    def test_all_same(self):
        result = sparkline([3.0, 3.0, 3.0])
        assert result == "▅▅▅"

    def test_max_width(self):
        values = list(range(100))
        result = sparkline(values, width=10)
        assert len(result) == 10


class TestFormatTime:
    def test_seconds(self):
        assert format_time(45) == "00:00:45"

    def test_minutes(self):
        assert format_time(125) == "00:02:05"

    def test_hours(self):
        assert format_time(3661) == "01:01:01"

    def test_zero(self):
        assert format_time(0) == "00:00:00"


class TestFormatNumber:
    def test_small_float(self):
        assert format_number(0.0234) == "0.0234"

    def test_percentage(self):
        assert format_number(94.2) == "94.20"

    def test_scientific(self):
        assert format_number(0.0001) == "1e-4"

    def test_large(self):
        assert format_number(1284) == "1284"

    def test_zero(self):
        assert format_number(0.0) == "0.0000"


class TestThrottle:
    def test_first_call_always_runs(self):
        t = Throttle(fps=10)
        assert t.should_update() is True

    def test_rapid_calls_throttled(self):
        t = Throttle(fps=10)
        t.should_update()  # first call
        assert t.should_update() is False

    def test_after_interval(self):
        t = Throttle(fps=10)
        t.should_update()
        t._last_update -= 0.2  # simulate time passing
        assert t.should_update() is True


class TestIsTty:
    def test_returns_bool(self):
        result = is_tty()
        assert isinstance(result, bool)
```

**Step 2: Run tests to verify they fail**

Run: `cd /Volumes/Auxilary/Side_Projects/Lootqdm && python -m pytest tests/test_utils.py -v`
Expected: FAIL — ModuleNotFoundError

**Step 3: Implement utils.py**

```python
"""Utility functions: TTY detection, sparklines, throttling, formatting."""

from __future__ import annotations

import os
import sys
import time
from collections import deque
from typing import Sequence

SPARK_CHARS = "▁▂▃▄▅▆▇█"


def is_tty() -> bool:
    """Check if stdout is a TTY and Rich UI should be used."""
    if os.environ.get("LOOTQDM_PLAIN", "").strip() in ("1", "true", "yes"):
        return False
    if os.environ.get("TERM", "") == "dumb":
        return False
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


def sparkline(values: Sequence[float], width: int | None = None) -> str:
    """Render a sparkline string from numeric values using Unicode block chars."""
    if not values:
        return ""
    if width is not None and len(values) > width:
        values = values[-width:]
    mn, mx = min(values), max(values)
    span = mx - mn
    if span == 0:
        idx = len(SPARK_CHARS) // 2
        return SPARK_CHARS[idx] * len(values)
    result = []
    for v in values:
        normalized = (v - mn) / span
        i = int(normalized * (len(SPARK_CHARS) - 1))
        result.append(SPARK_CHARS[i])
    return "".join(result)


def format_time(seconds: float) -> str:
    """Format seconds as HH:MM:SS."""
    seconds = int(max(0, seconds))
    h, remainder = divmod(seconds, 3600)
    m, s = divmod(remainder, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def format_number(value: float) -> str:
    """Format a metric value for display."""
    if value == 0:
        return "0.0000"
    abs_val = abs(value)
    if abs_val < 0.001:
        exp = 0
        v = abs_val
        while v < 1.0:
            v *= 10
            exp += 1
        mantissa = value * (10 ** exp)
        if mantissa == int(mantissa):
            return f"{int(mantissa)}e-{exp}"
        return f"{mantissa:.1f}e-{exp}"
    if abs_val < 1.0:
        return f"{value:.4f}"
    if abs_val < 100:
        return f"{value:.2f}"
    return f"{int(value)}"


class Throttle:
    """Rate limiter for UI refresh."""

    def __init__(self, fps: int = 10) -> None:
        self._interval = 1.0 / max(1, fps)
        self._last_update = 0.0

    def should_update(self) -> bool:
        now = time.monotonic()
        if now - self._last_update >= self._interval:
            self._last_update = now
            return True
        return False
```

**Step 4: Run tests to verify they pass**

Run: `cd /Volumes/Auxilary/Side_Projects/Lootqdm && python -m pytest tests/test_utils.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add lootqdm/utils.py tests/test_utils.py
git commit -m "feat: utils module with sparkline, throttle, TTY detection, formatters"
```

---

### Task 3: Themes Module

**Files:**
- Create: `lootqdm/themes.py`
- Create: `tests/test_themes.py`

**Step 1: Write failing tests**

```python
"""Tests for lootqdm.themes."""

from __future__ import annotations

from lootqdm.themes import Theme, get_theme, list_themes, THEMES


class TestThemeRegistry:
    def test_list_themes(self):
        names = list_themes()
        assert "cozy_pastel" in names
        assert "dark_dungeon" in names
        assert "neon_cyber" in names
        assert "retro_crt" in names
        assert len(names) == 4

    def test_get_theme_by_name(self):
        theme = get_theme("dark_dungeon")
        assert isinstance(theme, Theme)
        assert theme.name == "dark_dungeon"

    def test_get_theme_invalid(self):
        import pytest
        with pytest.raises(KeyError):
            get_theme("nonexistent")

    def test_get_theme_default(self):
        theme = get_theme()
        assert theme.name == "dark_dungeon"


class TestThemeStructure:
    def test_all_themes_have_required_fields(self):
        for name in list_themes():
            theme = get_theme(name)
            assert theme.name == name
            assert "title" in theme.palette
            assert "accent" in theme.palette
            assert "soft" in theme.palette
            assert "dim" in theme.palette
            assert len(theme.bar_chars) == 2
            assert "xp" in theme.icons
            assert "level" in theme.icons
            assert "quest" in theme.icons
            assert "achievement" in theme.icons
            for rarity in ("common", "uncommon", "rare", "epic", "legendary"):
                assert rarity in theme.rarity_styles
                assert rarity in theme.icons["loot"]
            assert "crit" in theme.icons["events"]
            assert "lucky" in theme.icons["events"]
            assert "warning" in theme.icons["events"]

    def test_cozy_pastel_icons(self):
        theme = get_theme("cozy_pastel")
        assert theme.icons["xp"] == "\U0001f331"  # 🌱

    def test_retro_crt_ascii_only_icons(self):
        theme = get_theme("retro_crt")
        assert theme.icons["xp"] == "+XP"
        assert theme.icons["level"] == "LV"

    def test_theme_is_immutable(self):
        theme = get_theme("dark_dungeon")
        import pytest
        with pytest.raises(AttributeError):
            theme.name = "hacked"


class TestThemeLootNames:
    def test_all_themes_have_loot_names(self):
        for name in list_themes():
            theme = get_theme(name)
            assert hasattr(theme, "loot_names")
            for rarity in ("common", "uncommon", "rare", "epic", "legendary"):
                assert rarity in theme.loot_names
                assert len(theme.loot_names[rarity]) >= 3
```

**Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_themes.py -v`
Expected: FAIL

**Step 3: Implement themes.py**

```python
"""Theme definitions for lootqdm."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from rich.box import Box, ROUNDED, HEAVY, DOUBLE, ASCII


@dataclass(frozen=True)
class Theme:
    """Immutable theme definition."""

    name: str
    palette: dict[str, str]
    icons: dict[str, Any]
    rarity_styles: dict[str, str]
    bar_chars: tuple[str, str]
    border: Box
    separators: tuple[str, ...]
    loot_names: dict[str, list[str]]


_COZY_PASTEL = Theme(
    name="cozy_pastel",
    palette={
        "title": "bold magenta",
        "accent": "bright_cyan",
        "soft": "bright_white",
        "dim": "grey70",
    },
    icons={
        "xp": "\U0001f331",          # 🌱
        "level": "\U0001f9fa",        # 🧺
        "prestige": "\U0001f36f",     # 🍯
        "quest": "\U0001f4cc",        # 📌
        "achievement": "\U0001f3e1",  # 🏡
        "loot": {
            "common": "\U0001f353",     # 🍓
            "uncommon": "\U0001f950",   # 🥐
            "rare": "\U0001fad0",       # 🫐
            "epic": "\U0001f382",       # 🎂
            "legendary": "\U0001f9c1",  # 🧁
        },
        "events": {
            "crit": "\u2728",       # ✨
            "lucky": "\U0001f340",  # 🍀
            "warning": "\u26a0\ufe0f",  # ⚠️
        },
    },
    rarity_styles={
        "common": "grey70",
        "uncommon": "green",
        "rare": "bright_cyan",
        "epic": "bright_magenta",
        "legendary": "bold bright_yellow",
    },
    bar_chars=("\u25b0", "\u25b1"),  # ▰ ▱
    border=ROUNDED,
    separators=("\u00b7", "\u2022", "\u2500"),  # · • ─
    loot_names={
        "common": ["Strawberry Badge", "Daisy Pin", "Clover Patch", "Acorn Button", "Pebble Charm"],
        "uncommon": ["Croissant Medal", "Lavender Sprig", "Honeycomb Tile", "Rose Quartz", "Mint Leaf"],
        "rare": ["Blueberry Charm", "Moonstone Brooch", "Crystal Dewdrop", "Peach Blossom Ring", "Starfruit Gem"],
        "epic": ["Golden Honeycomb", "Aurora Ribbon", "Enchanted Teacup", "Rainbow Preserve", "Celestial Jam Jar"],
        "legendary": ["Crown of Petals", "Evergarden Seed", "The Cozy Chalice", "Sunbeam Locket", "Dreamer's Quilt"],
    },
)

_DARK_DUNGEON = Theme(
    name="dark_dungeon",
    palette={
        "title": "bold bright_red",
        "accent": "yellow",
        "soft": "grey82",
        "dim": "grey42",
    },
    icons={
        "xp": "\U0001fa78",          # 🩸
        "level": "\U0001f5e1\ufe0f", # 🗡️
        "prestige": "\U0001f451",    # 👑
        "quest": "\U0001f4dc",       # 📜
        "achievement": "\U0001f3c6", # 🏆
        "loot": {
            "common": "\U0001fa99",    # 🪙
            "uncommon": "\U0001f527",  # 🔧
            "rare": "\U0001f4a0",      # 💠
            "epic": "\U0001f52e",      # 🔮
            "legendary": "\u269c\ufe0f",  # ⚜️
        },
        "events": {
            "crit": "\U0001f4a5",      # 💥
            "lucky": "\U0001f987",     # 🦇
            "warning": "\u2620\ufe0f", # ☠️
        },
    },
    rarity_styles={
        "common": "grey62",
        "uncommon": "green",
        "rare": "bright_cyan",
        "epic": "bright_magenta",
        "legendary": "bold bright_yellow",
    },
    bar_chars=("\u2588", "\u2591"),  # █ ░
    border=HEAVY,
    separators=("\u2550", "\u256c", "\u2502"),  # ═ ╬ │
    loot_names={
        "common": ["Rusty Coin", "Bone Fragment", "Tattered Cloth", "Dull Fang", "Cracked Stone"],
        "uncommon": ["Iron Buckle", "Goblin Ear", "Dungeon Moss", "Whetstone Shard", "Torch Stub"],
        "rare": ["Cursed Relic", "Void Shard", "Shadow Essence", "Dragon Scale", "Obsidian Key"],
        "epic": ["Bloodstone Amulet", "Lich's Finger", "Abyssal Lens", "Doom Signet", "Spectral Chain"],
        "legendary": ["Royal Sigil", "Cursed Crown", "Blade of Epochs", "The Undying Flame", "Throne Shard"],
    },
)

_NEON_CYBER = Theme(
    name="neon_cyber",
    palette={
        "title": "bold bright_cyan",
        "accent": "bright_magenta",
        "soft": "bright_white",
        "dim": "grey58",
    },
    icons={
        "xp": "\u26a1",             # ⚡
        "level": "\U0001f9ec",       # 🧬
        "prestige": "\U0001f6f0\ufe0f",  # 🛰️
        "quest": "\U0001f3af",       # 🎯
        "achievement": "\U0001f947", # 🥇
        "loot": {
            "common": "\U0001f529",    # 🔩
            "uncommon": "\U0001f4c0",  # 📀
            "rare": "\U0001f4bf",      # 💿
            "epic": "\U0001f9ea",      # 🧪
            "legendary": "\U0001f48e", # 💎
        },
        "events": {
            "crit": "\U0001f525",      # 🔥
            "lucky": "\U0001f3b0",     # 🎰
            "warning": "\U0001f6a8",   # 🚨
        },
    },
    rarity_styles={
        "common": "grey62",
        "uncommon": "bright_green",
        "rare": "bright_cyan",
        "epic": "bright_magenta",
        "legendary": "bold bright_yellow",
    },
    bar_chars=("\u25ae", "\u25af"),  # ▮ ▯
    border=DOUBLE,
    separators=("\u2550", "\u2500", "\u23af"),  # ═ ─ ⎯
    loot_names={
        "common": ["Chrome Bolt", "Wire Scrap", "Pixel Dust", "Nano Chip", "Data Fragment"],
        "uncommon": ["Synth Disk", "Plasma Coil", "Neon Tube", "Circuit Board", "Holo Shard"],
        "rare": ["Quantum Core", "Cyber Lens", "Void Capacitor", "Neural Link", "Phase Crystal"],
        "epic": ["Antimatter Vial", "Singularity Probe", "Dark Energy Cell", "Fusion Matrix", "Nexus Key"],
        "legendary": ["Quantum Gem", "The Architect's Eye", "Infinity Codec", "Stellar Engine", "Omega Prism"],
    },
)

_RETRO_CRT = Theme(
    name="retro_crt",
    palette={
        "title": "bold green",
        "accent": "green",
        "soft": "bright_green",
        "dim": "grey37",
    },
    icons={
        "xp": "+XP",
        "level": "LV",
        "prestige": "ASC",
        "quest": "QST",
        "achievement": "ACH",
        "loot": {
            "common": "[C]",
            "uncommon": "[U]",
            "rare": "[R]",
            "epic": "[E]",
            "legendary": "[L]",
        },
        "events": {
            "crit": "!!",
            "lucky": "LUCK",
            "warning": "WARN",
        },
    },
    rarity_styles={
        "common": "grey62",
        "uncommon": "green",
        "rare": "bright_green",
        "epic": "bold green",
        "legendary": "bold bright_green on green",
    },
    bar_chars=("#", "-"),
    border=ASCII,
    separators=("-", "|", "+"),
    loot_names={
        "common": ["Green Phosphor", "Dot Matrix", "Null Byte", "Ping Token", "Baud Bit"],
        "uncommon": ["ANSI Escape", "Cursor Block", "Stack Frame", "Pipe Coupler", "Shell Script"],
        "rare": ["ANSI Trophy", "Kernel Panic Badge", "Root Shell", "Daemon Core", "Buffer Gem"],
        "epic": ["Segfault Sigil", "Fork Bomb Shield", "Mainframe Key", "Epoch Counter", "Recursive Ring"],
        "legendary": ["BBS Crown", "The Golden Prompt", "UNIX Epoch Zero", "Root of All Shells", "The Last Byte"],
    },
)

THEMES: dict[str, Theme] = {
    "cozy_pastel": _COZY_PASTEL,
    "dark_dungeon": _DARK_DUNGEON,
    "neon_cyber": _NEON_CYBER,
    "retro_crt": _RETRO_CRT,
}


def get_theme(name: str = "dark_dungeon") -> Theme:
    """Get a theme by name. Raises KeyError if not found."""
    try:
        return THEMES[name]
    except KeyError:
        raise KeyError(f"Unknown theme {name!r}. Available: {list(THEMES.keys())}")


def list_themes() -> list[str]:
    """Return list of available theme names."""
    return list(THEMES.keys())
```

**Step 4: Run tests**

Run: `python -m pytest tests/test_themes.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add lootqdm/themes.py tests/test_themes.py
git commit -m "feat: theme system with 4 built-in themes (cozy, dungeon, neon, retro)"
```

---

### Task 4: Events Module (rarity, loot, achievements)

**Files:**
- Create: `lootqdm/events.py`
- Create: `tests/test_events.py`

**Step 1: Write failing tests**

```python
"""Tests for lootqdm.events."""

from __future__ import annotations

from random import Random

from lootqdm.events import (
    roll_rarity,
    LootDrop,
    LootTable,
    Achievement,
    AchievementTracker,
    EventBus,
    Event,
    RARITY_ORDER,
)


class TestRollRarity:
    def test_returns_valid_rarity(self, rng):
        for _ in range(100):
            r = roll_rarity(rng)
            assert r in RARITY_ORDER

    def test_common_is_most_frequent(self, rng):
        counts = {"common": 0, "uncommon": 0, "rare": 0, "epic": 0, "legendary": 0}
        for _ in range(10000):
            counts[roll_rarity(rng)] += 1
        assert counts["common"] > counts["uncommon"] > counts["rare"]

    def test_luck_increases_rare_drops(self, rng):
        base_rare = sum(1 for _ in range(10000) if roll_rarity(Random(42)) in ("rare", "epic", "legendary"))
        luck_rare = sum(1 for _ in range(10000) if roll_rarity(Random(42), luck=0.5) in ("rare", "epic", "legendary"))
        assert luck_rare > base_rare


class TestLootTable:
    def test_roll_returns_loot_drop(self, rng):
        table = LootTable("dark_dungeon")
        drop = table.roll(rng)
        assert isinstance(drop, LootDrop)
        assert drop.rarity in RARITY_ORDER
        assert isinstance(drop.name, str)
        assert drop.xp > 0

    def test_xp_scales_with_rarity(self):
        table = LootTable("dark_dungeon")
        # Roll many times and check epic > common XP on average
        common_xp = []
        epic_xp = []
        rng = Random(123)
        for _ in range(10000):
            drop = table.roll(rng)
            if drop.rarity == "common":
                common_xp.append(drop.xp)
            elif drop.rarity == "epic":
                epic_xp.append(drop.xp)
        if common_xp and epic_xp:
            assert sum(epic_xp) / len(epic_xp) > sum(common_xp) / len(common_xp)


class TestAchievementTracker:
    def test_unlock(self):
        tracker = AchievementTracker()
        result = tracker.unlock("first_epoch", "First Epoch Complete")
        assert result is True
        assert "first_epoch" in tracker.unlocked

    def test_duplicate_unlock_returns_false(self):
        tracker = AchievementTracker()
        tracker.unlock("first_epoch", "First Epoch Complete")
        result = tracker.unlock("first_epoch", "First Epoch Complete")
        assert result is False

    def test_list_achievements(self):
        tracker = AchievementTracker()
        tracker.unlock("first_epoch", "First Epoch Complete")
        tracker.unlock("best_acc", "New Best Accuracy")
        achievements = tracker.list_all()
        assert len(achievements) == 2


class TestEventBus:
    def test_emit_and_listen(self):
        bus = EventBus()
        received = []
        bus.on("loot", lambda e: received.append(e))
        bus.emit("loot", {"name": "Rusty Coin"})
        assert len(received) == 1
        assert received[0].data["name"] == "Rusty Coin"

    def test_multiple_listeners(self):
        bus = EventBus()
        a, b = [], []
        bus.on("loot", lambda e: a.append(e))
        bus.on("loot", lambda e: b.append(e))
        bus.emit("loot", {"name": "test"})
        assert len(a) == 1
        assert len(b) == 1

    def test_different_event_types(self):
        bus = EventBus()
        loot_events = []
        level_events = []
        bus.on("loot", lambda e: loot_events.append(e))
        bus.on("level_up", lambda e: level_events.append(e))
        bus.emit("loot", {"name": "x"})
        bus.emit("level_up", {"level": 5})
        assert len(loot_events) == 1
        assert len(level_events) == 1
```

**Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_events.py -v`
Expected: FAIL

**Step 3: Implement events.py**

```python
"""Event system: rarity rolls, loot tables, achievements, event bus."""

from __future__ import annotations

from dataclasses import dataclass, field
from random import Random
from typing import Any, Callable

from lootqdm.themes import get_theme

RARITY_ORDER = ("common", "uncommon", "rare", "epic", "legendary")

RARITY_WEIGHTS: dict[str, float] = {
    "common": 0.700,
    "uncommon": 0.200,
    "rare": 0.080,
    "epic": 0.019,
    "legendary": 0.001,
}

RARITY_XP: dict[str, int] = {
    "common": 5,
    "uncommon": 15,
    "rare": 50,
    "epic": 150,
    "legendary": 500,
}


def roll_rarity(rng: Random, luck: float = 0.0) -> str:
    """Roll a rarity tier. Luck (0.0-1.0) shifts probability toward rarer tiers."""
    luck = max(0.0, min(1.0, luck))
    weights = []
    for rarity in RARITY_ORDER:
        w = RARITY_WEIGHTS[rarity]
        if rarity == "common":
            w *= 1.0 - luck * 0.5
        elif rarity in ("rare", "epic", "legendary"):
            w *= 1.0 + luck * 3.0
        weights.append(w)
    total = sum(weights)
    roll = rng.random() * total
    cumulative = 0.0
    for i, w in enumerate(weights):
        cumulative += w
        if roll <= cumulative:
            return RARITY_ORDER[i]
    return RARITY_ORDER[0]


@dataclass(frozen=True)
class LootDrop:
    """A single loot drop result."""

    name: str
    rarity: str
    xp: int


class LootTable:
    """Generates loot drops themed to a specific theme."""

    def __init__(self, theme_name: str) -> None:
        self._theme = get_theme(theme_name)

    def roll(self, rng: Random, luck: float = 0.0) -> LootDrop:
        """Roll for a loot drop."""
        rarity = roll_rarity(rng, luck)
        names = self._theme.loot_names[rarity]
        name = rng.choice(names)
        xp = RARITY_XP[rarity]
        return LootDrop(name=name, rarity=rarity, xp=xp)


@dataclass
class Achievement:
    """A single achievement."""

    key: str
    description: str


class AchievementTracker:
    """Tracks unlocked achievements."""

    def __init__(self) -> None:
        self.unlocked: dict[str, Achievement] = {}

    def unlock(self, key: str, description: str) -> bool:
        """Unlock an achievement. Returns True if newly unlocked, False if duplicate."""
        if key in self.unlocked:
            return False
        self.unlocked[key] = Achievement(key=key, description=description)
        return True

    def list_all(self) -> list[Achievement]:
        """List all unlocked achievements."""
        return list(self.unlocked.values())

    def is_unlocked(self, key: str) -> bool:
        return key in self.unlocked


@dataclass
class Event:
    """An event emitted on the bus."""

    type: str
    data: dict[str, Any]


class EventBus:
    """Simple synchronous event bus."""

    def __init__(self) -> None:
        self._listeners: dict[str, list[Callable[[Event], None]]] = {}

    def on(self, event_type: str, callback: Callable[[Event], None]) -> None:
        """Register a listener for an event type."""
        self._listeners.setdefault(event_type, []).append(callback)

    def emit(self, event_type: str, data: dict[str, Any] | None = None) -> None:
        """Emit an event to all registered listeners."""
        event = Event(type=event_type, data=data or {})
        for callback in self._listeners.get(event_type, []):
            callback(event)
```

**Step 4: Run tests**

Run: `python -m pytest tests/test_events.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add lootqdm/events.py tests/test_events.py
git commit -m "feat: event system with rarity rolls, loot tables, achievements, event bus"
```

---

### Task 5: StatMapper Module

**Files:**
- Create: `lootqdm/mappers.py`
- Create: `tests/test_mappers.py`

**Step 1: Write failing tests**

```python
"""Tests for lootqdm.mappers."""

from __future__ import annotations

from lootqdm.mappers import StatMapper


class TestStatMapper:
    def test_default_mappings(self):
        mapper = StatMapper()
        assert mapper.game_name("loss") == "DMG"
        assert mapper.game_name("acc") == "CRIT"
        assert mapper.game_name("lr") == "MANA"

    def test_default_icons(self):
        mapper = StatMapper()
        icon, _ = mapper.format("loss", 0.5)
        assert isinstance(icon, str)

    def test_unknown_metric_passes_through(self):
        mapper = StatMapper()
        assert mapper.game_name("custom_metric") == "custom_metric"

    def test_custom_mapping(self):
        mapper = StatMapper(mappings={"f1_score": ("F1 PWR", "\u2694")})
        assert mapper.game_name("f1_score") == "F1 PWR"

    def test_format_returns_icon_and_name(self):
        mapper = StatMapper()
        icon, name = mapper.format("loss", 0.023)
        assert name == "DMG"
        assert len(icon) > 0

    def test_merge_custom_with_defaults(self):
        mapper = StatMapper(mappings={"custom": ("CSTM", "?")})
        # Defaults still work
        assert mapper.game_name("loss") == "DMG"
        # Custom also works
        assert mapper.game_name("custom") == "CSTM"
```

**Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_mappers.py -v`
Expected: FAIL

**Step 3: Implement mappers.py**

```python
"""StatMapper: translate ML metrics to game-stat names and icons."""

from __future__ import annotations

from typing import Any

DEFAULT_MAPPINGS: dict[str, tuple[str, str]] = {
    "loss": ("DMG", "\u2694"),          # ⚔
    "train_loss": ("DMG", "\u2694"),
    "val_loss": ("vDMG", "\U0001f6e1"),  # 🛡
    "acc": ("CRIT", "\U0001f3af"),       # 🎯
    "accuracy": ("CRIT", "\U0001f3af"),
    "val_acc": ("vCRIT", "\U0001f3af"),
    "val_accuracy": ("vCRIT", "\U0001f3af"),
    "lr": ("MANA", "\U0001f4a7"),        # 💧
    "learning_rate": ("MANA", "\U0001f4a7"),
    "f1": ("F1 PWR", "\u2694"),
    "f1_score": ("F1 PWR", "\u2694"),
    "auc": ("AUC", "\U0001f4c8"),        # 📈
    "throughput": ("SPD", "\U0001f3c3"),  # 🏃
    "gpu_mem": ("VRAM", "\U0001f525"),   # 🔥
    "gpu_util": ("GPU", "\U0001f525"),
}


class StatMapper:
    """Maps ML metric keys to game stat names and icons."""

    def __init__(self, mappings: dict[str, tuple[str, str]] | None = None) -> None:
        self._mappings = {**DEFAULT_MAPPINGS}
        if mappings:
            self._mappings.update(mappings)

    def game_name(self, metric_key: str) -> str:
        """Get the game stat name for a metric key."""
        if metric_key in self._mappings:
            return self._mappings[metric_key][0]
        return metric_key

    def icon(self, metric_key: str) -> str:
        """Get the icon for a metric key."""
        if metric_key in self._mappings:
            return self._mappings[metric_key][1]
        return "\u2022"  # •

    def format(self, metric_key: str, value: float) -> tuple[str, str]:
        """Return (icon, game_name) for a metric."""
        return self.icon(metric_key), self.game_name(metric_key)
```

**Step 4: Run tests**

Run: `python -m pytest tests/test_mappers.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add lootqdm/mappers.py tests/test_mappers.py
git commit -m "feat: StatMapper for ML metric to game stat translation"
```

---

### Task 6: Quest Module

**Files:**
- Create: `lootqdm/quests.py`
- Create: `tests/test_quests.py`

**Step 1: Write failing tests**

```python
"""Tests for lootqdm.quests."""

from __future__ import annotations

from lootqdm.quests import Quest, QuestTracker


class TestQuest:
    def test_creation(self):
        q = Quest(name="High Accuracy", metric="acc", target=0.95, compare=">=")
        assert q.name == "High Accuracy"
        assert not q.completed
        assert q.progress == 0.0

    def test_check_gte(self):
        q = Quest(name="test", metric="acc", target=0.95, compare=">=")
        q.update(0.90)
        assert not q.completed
        q.update(0.96)
        assert q.completed

    def test_check_lte(self):
        q = Quest(name="test", metric="loss", target=0.01, compare="<=")
        q.update(0.5)
        assert not q.completed
        q.update(0.005)
        assert q.completed

    def test_progress_percentage(self):
        q = Quest(name="test", metric="acc", target=1.0, compare=">=")
        q.update(0.5)
        assert abs(q.progress - 0.5) < 0.01

    def test_progress_lte(self):
        q = Quest(name="test", metric="loss", target=0.1, compare="<=", start_value=1.0)
        q.update(0.55)
        assert abs(q.progress - 0.5) < 0.01

    def test_stays_completed(self):
        q = Quest(name="test", metric="acc", target=0.95, compare=">=")
        q.update(0.96)
        assert q.completed
        q.update(0.50)  # metric drops
        assert q.completed  # stays completed


class TestQuestTracker:
    def test_add_and_check(self):
        tracker = QuestTracker()
        tracker.add("High Acc", "acc", 0.95, ">=")
        results = tracker.check({"acc": 0.96})
        assert len(results) == 1
        assert results[0].name == "High Acc"

    def test_no_completions(self):
        tracker = QuestTracker()
        tracker.add("High Acc", "acc", 0.95, ">=")
        results = tracker.check({"acc": 0.5})
        assert len(results) == 0

    def test_multiple_quests(self):
        tracker = QuestTracker()
        tracker.add("High Acc", "acc", 0.95, ">=")
        tracker.add("Low Loss", "loss", 0.01, "<=")
        results = tracker.check({"acc": 0.96, "loss": 0.005})
        assert len(results) == 2

    def test_get_all(self):
        tracker = QuestTracker()
        tracker.add("q1", "acc", 0.95, ">=")
        tracker.add("q2", "loss", 0.01, "<=")
        assert len(tracker.all()) == 2
```

**Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_quests.py -v`
Expected: FAIL

**Step 3: Implement quests.py**

```python
"""Quest system for lootqdm."""

from __future__ import annotations

import operator
from dataclasses import dataclass, field

COMPARISONS = {
    ">=": operator.ge,
    "<=": operator.le,
    ">": operator.gt,
    "<": operator.lt,
}


@dataclass
class Quest:
    """A single quest with metric-based completion."""

    name: str
    metric: str
    target: float
    compare: str
    start_value: float = 0.0
    completed: bool = False
    current: float = 0.0

    def update(self, value: float) -> bool:
        """Update with a new metric value. Returns True if newly completed."""
        self.current = value
        if self.completed:
            return False
        op = COMPARISONS.get(self.compare, operator.ge)
        if op(value, self.target):
            self.completed = True
            return True
        return False

    @property
    def progress(self) -> float:
        """Return 0.0-1.0 progress toward the goal."""
        if self.completed:
            return 1.0
        if self.compare in (">=", ">"):
            if self.target == 0:
                return 1.0 if self.current >= self.target else 0.0
            return min(1.0, max(0.0, self.current / self.target))
        else:  # <= or <
            span = self.start_value - self.target
            if span <= 0:
                return 1.0 if self.current <= self.target else 0.0
            traveled = self.start_value - self.current
            return min(1.0, max(0.0, traveled / span))


class QuestTracker:
    """Manages multiple quests."""

    def __init__(self) -> None:
        self._quests: list[Quest] = []

    def add(
        self,
        name: str,
        metric: str,
        target: float,
        compare: str = ">=",
        start_value: float = 0.0,
    ) -> Quest:
        """Add a new quest."""
        q = Quest(
            name=name,
            metric=metric,
            target=target,
            compare=compare,
            start_value=start_value,
        )
        self._quests.append(q)
        return q

    def check(self, metrics: dict[str, float]) -> list[Quest]:
        """Check all quests against current metrics. Returns newly completed quests."""
        newly_completed = []
        for q in self._quests:
            if q.metric in metrics:
                if q.update(metrics[q.metric]):
                    newly_completed.append(q)
        return newly_completed

    def all(self) -> list[Quest]:
        """Return all quests."""
        return list(self._quests)
```

**Step 4: Run tests**

Run: `python -m pytest tests/test_quests.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add lootqdm/quests.py tests/test_quests.py
git commit -m "feat: quest system with metric-based goals and progress tracking"
```

---

### Task 7: Persistence Module

**Files:**
- Create: `lootqdm/persistence.py`
- Create: `tests/test_persistence.py`

**Step 1: Write failing tests**

```python
"""Tests for lootqdm.persistence."""

from __future__ import annotations

import json
from pathlib import Path

from lootqdm.persistence import Profile, load_profile, save_profile


class TestProfile:
    def test_defaults(self):
        p = Profile()
        assert p.lifetime_xp == 0
        assert p.total_runs == 0
        assert p.level == 1
        assert p.achievements == []
        assert p.loot_log == []
        assert p.prestige == 0

    def test_add_xp(self):
        p = Profile()
        p.add_xp(100)
        assert p.lifetime_xp == 100

    def test_record_run(self):
        p = Profile()
        p.record_run()
        assert p.total_runs == 1

    def test_to_dict_and_from_dict(self):
        p = Profile()
        p.add_xp(500)
        p.record_run()
        p.achievements.append("first_epoch")
        d = p.to_dict()
        p2 = Profile.from_dict(d)
        assert p2.lifetime_xp == 500
        assert p2.total_runs == 1
        assert "first_epoch" in p2.achievements


class TestSaveLoad:
    def test_save_and_load(self, tmp_path):
        path = tmp_path / "profile.json"
        p = Profile()
        p.add_xp(1234)
        p.achievements.append("test")
        save_profile(p, path)
        assert path.exists()
        p2 = load_profile(path)
        assert p2.lifetime_xp == 1234
        assert "test" in p2.achievements

    def test_load_missing_returns_default(self, tmp_path):
        path = tmp_path / "nonexistent.json"
        p = load_profile(path)
        assert p.lifetime_xp == 0

    def test_load_corrupt_returns_default(self, tmp_path):
        path = tmp_path / "corrupt.json"
        path.write_text("not json at all {{{")
        p = load_profile(path)
        assert p.lifetime_xp == 0
```

**Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_persistence.py -v`
Expected: FAIL

**Step 3: Implement persistence.py**

```python
"""Profile persistence for lootqdm."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger("lootqdm")

DEFAULT_PROFILE_DIR = Path.home() / ".lootqdm"
DEFAULT_PROFILE_PATH = DEFAULT_PROFILE_DIR / "profile.json"


@dataclass
class Profile:
    """Persistent player profile across training runs."""

    lifetime_xp: int = 0
    total_runs: int = 0
    level: int = 1
    achievements: list[str] = field(default_factory=list)
    loot_log: list[dict[str, Any]] = field(default_factory=list)
    prestige: int = 0

    def add_xp(self, xp: int) -> None:
        self.lifetime_xp += xp

    def record_run(self) -> None:
        self.total_runs += 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "lifetime_xp": self.lifetime_xp,
            "total_runs": self.total_runs,
            "level": self.level,
            "achievements": self.achievements,
            "loot_log": self.loot_log,
            "prestige": self.prestige,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Profile:
        return cls(
            lifetime_xp=data.get("lifetime_xp", 0),
            total_runs=data.get("total_runs", 0),
            level=data.get("level", 1),
            achievements=data.get("achievements", []),
            loot_log=data.get("loot_log", []),
            prestige=data.get("prestige", 0),
        )


def save_profile(profile: Profile, path: Path = DEFAULT_PROFILE_PATH) -> None:
    """Save profile to JSON file."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(profile.to_dict(), indent=2))
    except OSError as e:
        logger.warning("Failed to save profile: %s", e)


def load_profile(path: Path = DEFAULT_PROFILE_PATH) -> Profile:
    """Load profile from JSON file. Returns default profile on any error."""
    try:
        if not path.exists():
            return Profile()
        data = json.loads(path.read_text())
        return Profile.from_dict(data)
    except (OSError, json.JSONDecodeError, TypeError) as e:
        logger.warning("Failed to load profile: %s", e)
        return Profile()
```

**Step 4: Run tests**

Run: `python -m pytest tests/test_persistence.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add lootqdm/persistence.py tests/test_persistence.py
git commit -m "feat: JSON persistence for player profile across runs"
```

---

## Wave 2: Core UI (depends on Wave 1)

### Task 8: GameUI — The Main Rich Live Layout

**Files:**
- Create: `lootqdm/ui.py`
- Create: `tests/test_ui.py`

**Step 1: Write failing tests**

```python
"""Tests for lootqdm.ui."""

from __future__ import annotations

import io
import os
from unittest.mock import patch

from lootqdm.ui import GameUI, PlainUI


class TestGameUICreation:
    def test_create_with_defaults(self):
        ui = GameUI(total_steps=100, _force_plain=True)
        assert ui._total_steps == 100
        assert ui._total_epochs == 1

    def test_create_with_theme(self):
        ui = GameUI(total_steps=100, theme="neon_cyber", _force_plain=True)
        assert ui._theme.name == "neon_cyber"

    def test_invalid_theme_raises(self):
        import pytest
        with pytest.raises(KeyError):
            GameUI(total_steps=100, theme="nonexistent")


class TestGameUIContextManager:
    def test_context_manager(self):
        with GameUI(total_steps=10, _force_plain=True) as ui:
            for i in range(10):
                ui.step({"loss": 1.0 / (i + 1)})

    def test_epoch_end(self):
        with GameUI(total_steps=10, total_epochs=2, _force_plain=True) as ui:
            for epoch in range(2):
                for i in range(5):
                    ui.step({"loss": 0.5})
                ui.epoch_end({"val_acc": 0.9})


class TestGameUIStep:
    def test_step_increments(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.step()
            assert ui._current_step == 1
            ui.step(n=5)
            assert ui._current_step == 6

    def test_step_with_metrics(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.step({"loss": 0.5, "acc": 0.8})
            assert ui._latest_metrics["loss"] == 0.5

    def test_nan_detection(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.step({"loss": float("nan")})
            assert ui._achievements.is_unlocked("nan_survived")


class TestGameUIQuests:
    def test_quest_registration(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.quest("High Acc", "acc", 0.95)
            assert len(ui._quest_tracker.all()) == 1


class TestGameUILog:
    def test_log_adds_to_feed(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.log("Test message")
            assert len(ui._feed) == 1

    def test_log_with_rarity(self):
        with GameUI(total_steps=100, _force_plain=True) as ui:
            ui.log("Epic item!", rarity="epic")
            assert ui._feed[0]["rarity"] == "epic"


class TestGameUIWrap:
    def test_wrap_iterable(self):
        items = list(range(10))
        with GameUI(total_steps=10, _force_plain=True) as ui:
            result = list(ui.wrap(items))
        assert result == items

    def test_wrap_with_metrics_fn(self):
        items = [{"loss": 0.5}, {"loss": 0.3}]
        with GameUI(total_steps=2, _force_plain=True) as ui:
            for item in ui.wrap(items, metrics_fn=lambda x: x):
                pass
            assert ui._latest_metrics["loss"] == 0.3


class TestPlainUI:
    def test_plain_mode_no_crash(self):
        with PlainUI(total_steps=10) as ui:
            for i in range(10):
                ui.step({"loss": 0.5})
            ui.epoch_end({"val_acc": 0.9})
            ui.log("test message", rarity="rare")
            ui.quest("test", "acc", 0.95)


class TestTTYFallback:
    @patch.dict(os.environ, {"LOOTQDM_PLAIN": "1"})
    def test_env_forces_plain(self):
        ui = GameUI(total_steps=10)
        assert isinstance(ui._impl, PlainUI)
```

**Step 2: Run tests to verify they fail**

Run: `python -m pytest tests/test_ui.py -v`
Expected: FAIL

**Step 3: Implement ui.py**

This is the largest file. It contains `GameUI` (public facade), `RichUI` (Rich Live renderer), and `PlainUI` (logging fallback).

```python
"""GameUI: the main Rich Live layout for lootqdm."""

from __future__ import annotations

import logging
import math
import time
from collections import deque
from random import Random
from typing import Any, Callable, Iterable, Iterator, TypeVar

from lootqdm.events import (
    AchievementTracker,
    EventBus,
    LootTable,
    RARITY_XP,
)
from lootqdm.mappers import StatMapper
from lootqdm.persistence import Profile, load_profile, save_profile
from lootqdm.quests import QuestTracker
from lootqdm.themes import Theme, get_theme
from lootqdm.utils import Throttle, format_number, format_time, is_tty, sparkline

logger = logging.getLogger("lootqdm")

T = TypeVar("T")

# XP / Level constants
DEFAULT_TOTAL_XP = 10000
LEVEL_BASE = 100
LEVEL_EXPONENT = 1.5
LOOT_ROLL_INTERVAL = 50
CRIT_PROBABILITY = 0.03
LUCKY_PROBABILITY = 0.01
MAX_FEED_ITEMS = 20
SPARKLINE_BUFFER = 20


def _xp_for_level(level: int) -> int:
    """XP required to reach a given level."""
    return int(LEVEL_BASE * (level ** LEVEL_EXPONENT))


class PlainUI:
    """Plain-text fallback when no TTY is available."""

    def __init__(self, total_steps: int = 0, total_epochs: int = 1, **kwargs: Any) -> None:
        self._total_steps = total_steps
        self._total_epochs = total_epochs
        self._current_step = 0
        self._current_epoch = 0
        self._latest_metrics: dict[str, float] = {}
        self._feed: list[dict[str, Any]] = []
        self._achievements = AchievementTracker()
        self._quest_tracker = QuestTracker()
        self._log_interval = max(1, total_steps // 20) if total_steps > 0 else 100

    def __enter__(self) -> PlainUI:
        logger.info("lootqdm: starting run (%d steps, %d epochs)", self._total_steps, self._total_epochs)
        return self

    def __exit__(self, *exc: Any) -> None:
        logger.info("lootqdm: run complete. Steps: %d", self._current_step)

    def step(self, metrics: dict[str, float] | None = None, n: int = 1) -> None:
        self._current_step += n
        if metrics:
            self._latest_metrics.update(metrics)
            for k, v in metrics.items():
                if isinstance(v, float) and math.isnan(v):
                    self._achievements.unlock("nan_survived", "NaN Survived")
                    logger.warning("lootqdm: NaN detected in metric '%s'", k)
        if self._current_step % self._log_interval == 0 or self._current_step >= self._total_steps:
            logger.info("Step %d/%d %s", self._current_step, self._total_steps, self._latest_metrics)

    def epoch_end(self, metrics: dict[str, float] | None = None) -> None:
        self._current_epoch += 1
        if metrics:
            self._latest_metrics.update(metrics)
        logger.info("Epoch %d/%d complete. %s", self._current_epoch, self._total_epochs, self._latest_metrics)
        self._quest_tracker.check(self._latest_metrics)

    def log(self, message: str, rarity: str | None = None) -> None:
        self._feed.append({"message": message, "rarity": rarity})
        logger.info("lootqdm: %s", message)

    def quest(self, name: str, metric: str, target: float, compare: str = ">=") -> None:
        self._quest_tracker.add(name, metric, target, compare)

    def wrap(self, iterable: Iterable[T], metrics_fn: Callable | None = None) -> Iterator[T]:
        for item in iterable:
            if metrics_fn:
                m = metrics_fn(item)
                self.step(m)
            else:
                self.step()
            yield item

    def pytorch_step(self, **metrics: float) -> None:
        self.step(metrics)


class RichUI:
    """Rich Live terminal UI renderer."""

    def __init__(
        self,
        total_steps: int,
        total_epochs: int = 1,
        theme: Theme | None = None,
        refresh_rate: int = 10,
        emoji: bool = True,
        persist: bool = True,
        run_name: str | None = None,
    ) -> None:
        self._total_steps = total_steps
        self._total_epochs = total_epochs
        self._theme = theme or get_theme()
        self._refresh_rate = refresh_rate
        self._emoji = emoji
        self._persist = persist
        self._run_name = run_name or "run"

        self._current_step = 0
        self._current_epoch = 0
        self._latest_metrics: dict[str, float] = {}
        self._best_metrics: dict[str, float] = {}
        self._feed: list[dict[str, Any]] = []
        self._achievements = AchievementTracker()
        self._quest_tracker = QuestTracker()
        self._mapper = StatMapper()

        self._xp = 0
        self._level = 1
        self._xp_per_step = DEFAULT_TOTAL_XP / max(1, total_steps)

        self._rng = Random()
        self._loot_table = LootTable(self._theme.name)
        self._event_bus = EventBus()
        self._throttle = Throttle(fps=refresh_rate)
        self._start_time = 0.0

        self._sparkline_buffers: dict[str, deque] = {}
        self._profile = Profile()
        self._live = None

    def __enter__(self) -> RichUI:
        from rich.live import Live

        self._start_time = time.monotonic()
        if self._persist:
            self._profile = load_profile()
            self._profile.record_run()
        self._live = Live(
            self._render(),
            refresh_per_second=self._refresh_rate,
            transient=True,
        )
        self._live.__enter__()
        return self

    def __exit__(self, *exc: Any) -> None:
        if self._persist:
            self._profile.add_xp(self._xp)
            self._profile.level = self._level
            for a in self._achievements.list_all():
                if a.key not in self._profile.achievements:
                    self._profile.achievements.append(a.key)
            save_profile(self._profile)
        if self._live:
            self._live.update(self._render())
            self._live.__exit__(*exc)

    def step(self, metrics: dict[str, float] | None = None, n: int = 1) -> None:
        self._current_step += n

        # XP
        gained = int(self._xp_per_step * n)
        self._xp += gained
        self._check_level_up()

        if metrics:
            self._latest_metrics.update(metrics)
            for k, v in metrics.items():
                if isinstance(v, float) and math.isnan(v):
                    if self._achievements.unlock("nan_survived", "NaN Survived"):
                        self._add_feed(f"{self._icon('warning')} NaN survived!", rarity=None)
                    continue
                # Track sparklines
                buf = self._sparkline_buffers.setdefault(k, deque(maxlen=SPARKLINE_BUFFER))
                buf.append(v)
                # Track bests
                prev = self._best_metrics.get(k)
                if prev is None or (k in ("loss", "train_loss", "val_loss") and v < prev) or (k not in ("loss", "train_loss", "val_loss") and v > prev):
                    if prev is not None:
                        if self._achievements.unlock(f"best_{k}", f"New best {k}"):
                            self._add_feed(f"{self._icon('achievement')} New best {k}!", rarity="uncommon")
                    self._best_metrics[k] = v

        # Loot rolls
        if self._current_step % LOOT_ROLL_INTERVAL == 0:
            drop = self._loot_table.roll(self._rng)
            self._xp += drop.xp
            icon = self._theme.icons["loot"].get(drop.rarity, "")
            self._add_feed(f"{icon} {drop.rarity.upper()} {drop.name} +{drop.xp} XP", rarity=drop.rarity)
            self._event_bus.emit("loot", {"drop": drop})

        # Random events
        roll = self._rng.random()
        if roll < CRIT_PROBABILITY:
            bonus = int(self._xp_per_step * 5)
            self._xp += bonus
            self._add_feed(f"{self._icon('crit')} CRITICAL BATCH! +{bonus} XP", rarity=None)
        elif roll < CRIT_PROBABILITY + LUCKY_PROBABILITY:
            self._add_feed(f"{self._icon('lucky')} Lucky batch! Bonus incoming...", rarity=None)

        # First epoch check
        if self._current_epoch == 0 and self._current_step >= (self._total_steps // self._total_epochs if self._total_epochs > 0 else self._total_steps):
            self._achievements.unlock("first_epoch", "First Epoch Complete")

        # Throttled render
        if self._throttle.should_update() and self._live:
            self._live.update(self._render())

    def epoch_end(self, metrics: dict[str, float] | None = None) -> None:
        self._current_epoch += 1
        if metrics:
            self._latest_metrics.update(metrics)
            for k, v in metrics.items():
                if isinstance(v, float) and not math.isnan(v):
                    buf = self._sparkline_buffers.setdefault(k, deque(maxlen=SPARKLINE_BUFFER))
                    buf.append(v)
        if self._achievements.unlock("first_epoch", "First Epoch Complete"):
            self._add_feed(f"{self._icon('achievement')} First epoch complete!", rarity="uncommon")
        completed = self._quest_tracker.check(self._latest_metrics)
        for q in completed:
            self._add_feed(f"{self._icon('quest')} Quest complete: {q.name}!", rarity="rare")
        if self._live:
            self._live.update(self._render())

    def log(self, message: str, rarity: str | None = None) -> None:
        self._add_feed(message, rarity=rarity)
        if self._live and self._throttle.should_update():
            self._live.update(self._render())

    def quest(self, name: str, metric: str, target: float, compare: str = ">=") -> None:
        self._quest_tracker.add(name, metric, target, compare, start_value=self._latest_metrics.get(metric, 0.0))

    def wrap(self, iterable: Iterable[T], metrics_fn: Callable | None = None) -> Iterator[T]:
        for item in iterable:
            if metrics_fn:
                m = metrics_fn(item)
                self.step(m)
            else:
                self.step()
            yield item

    def pytorch_step(self, **metrics: float) -> None:
        self.step(metrics)

    # ── Internal ──

    def _icon(self, key: str) -> str:
        events = self._theme.icons.get("events", {})
        if key in events:
            return events[key] if self._emoji else ""
        return self._theme.icons.get(key, "") if self._emoji else ""

    def _add_feed(self, message: str, rarity: str | None) -> None:
        self._feed.insert(0, {"message": message, "rarity": rarity})
        if len(self._feed) > MAX_FEED_ITEMS:
            self._feed.pop()

    def _check_level_up(self) -> None:
        while self._xp >= _xp_for_level(self._level + 1):
            self._level += 1
            self._add_feed(f"{self._icon('level')} LEVEL UP! Now level {self._level}", rarity="rare")
            self._event_bus.emit("level_up", {"level": self._level})
            if self._level in (5, 10, 25, 50, 100):
                self._achievements.unlock(f"level_{self._level}", f"Reached Level {self._level}")

    def _make_bar(self, fraction: float, width: int = 20) -> str:
        filled_char, empty_char = self._theme.bar_chars
        filled = int(fraction * width)
        return filled_char * filled + empty_char * (width - filled)

    def _render(self) -> Any:
        from rich.panel import Panel
        from rich.table import Table
        from rich.text import Text

        t = self._theme
        elapsed = time.monotonic() - self._start_time

        # ── Header ──
        title_icon = self._icon("level")
        title = Text()
        title.append(f" {title_icon} LOOTQDM", style=t.palette["title"])

        header = Text()
        header.append(f"  {self._run_name}", style=t.palette["soft"])
        header.append(f" {t.separators[0]} ", style=t.palette["dim"])
        header.append(t.name, style=t.palette["dim"])
        padding = 40
        header.append(" " * max(1, padding - len(self._run_name) - len(t.name)))
        header.append(f"\u2699  {format_time(elapsed)}", style=t.palette["dim"])

        # ── Progress panel content ──
        epoch_frac = self._current_epoch / max(1, self._total_epochs)
        steps_in_epoch = self._total_steps // max(1, self._total_epochs)
        batch_in_epoch = self._current_step - (self._current_epoch * steps_in_epoch) if self._total_epochs > 1 else self._current_step
        batch_frac = self._current_step / max(1, self._total_steps)

        if self._current_step > 0:
            rate = self._current_step / max(0.001, elapsed)
            remaining = (self._total_steps - self._current_step) / max(0.001, rate)
        else:
            rate = 0
            remaining = 0

        progress_lines = Text()
        progress_lines.append("\n  PROGRESS\n\n", style=t.palette["accent"])
        progress_lines.append(f"  Epoch  {self._current_epoch}/{self._total_epochs}  ", style=t.palette["soft"])
        progress_lines.append(self._make_bar(epoch_frac, 12), style=t.palette["accent"])
        progress_lines.append(f"  {int(epoch_frac * 100)}%\n", style=t.palette["dim"])
        progress_lines.append(f"  Batch {self._current_step}/{self._total_steps} ", style=t.palette["soft"])
        progress_lines.append(self._make_bar(batch_frac, 12), style=t.palette["accent"])
        progress_lines.append(f"  {int(batch_frac * 100)}%\n", style=t.palette["dim"])
        progress_lines.append(f"  ETA {format_time(remaining)}", style=t.palette["dim"])
        progress_lines.append(f"  {t.separators[0]}  ", style=t.palette["dim"])
        progress_lines.append(f"{int(rate)} it/s\n\n", style=t.palette["dim"])

        # XP bar
        xp_needed = _xp_for_level(self._level + 1)
        xp_in_level = self._xp - _xp_for_level(self._level)
        xp_span = xp_needed - _xp_for_level(self._level)
        xp_frac = xp_in_level / max(1, xp_span)
        progress_lines.append(f"  {self._icon('xp')} ", style=t.palette["accent"])
        progress_lines.append(self._make_bar(xp_frac, 10), style=t.palette["accent"])
        progress_lines.append(f"  {self._xp}/{xp_needed}  LV {self._level}\n", style=t.palette["soft"])

        # ── Stats panel content ──
        stats_lines = Text()
        stats_lines.append("\n  STATS\n\n", style=t.palette["accent"])

        display_metrics = ["loss", "acc", "accuracy", "val_loss", "val_acc", "val_accuracy", "lr", "learning_rate"]
        shown = set()
        for key in display_metrics:
            if key in self._latest_metrics and key not in shown:
                icon_str, game_name = self._mapper.format(key, self._latest_metrics[key])
                val_str = format_number(self._latest_metrics[key])
                stats_lines.append(f"  {icon_str if self._emoji else ''} ", style=t.palette["accent"])
                stats_lines.append(f"{game_name:6s}", style=t.palette["soft"])
                stats_lines.append(f"({key})", style=t.palette["dim"])
                padding = max(1, 14 - len(key))
                stats_lines.append(" " * padding)
                stats_lines.append(f"{val_str}\n", style=t.palette["soft"])
                shown.add(key)

        # Extra custom metrics
        for key, val in self._latest_metrics.items():
            if key not in shown:
                icon_str, game_name = self._mapper.format(key, val)
                val_str = format_number(val) if isinstance(val, (int, float)) else str(val)
                stats_lines.append(f"  {icon_str if self._emoji else ''} ", style=t.palette["accent"])
                stats_lines.append(f"{game_name:6s}", style=t.palette["soft"])
                padding = max(1, 14 - len(game_name))
                stats_lines.append(" " * padding)
                stats_lines.append(f"{val_str}\n", style=t.palette["soft"])
                shown.add(key)

        # Sparkline for loss
        if "loss" in self._sparkline_buffers and len(self._sparkline_buffers["loss"]) > 1:
            spark = sparkline(list(self._sparkline_buffers["loss"]), width=12)
            stats_lines.append(f"  \U0001f4c9 loss  ", style=t.palette["accent"])
            stats_lines.append(f"{spark}\n", style=t.palette["dim"])

        # ── Loot feed content ──
        loot_lines = Text()
        loot_lines.append("\n  LOOT & EVENTS\n\n", style=t.palette["accent"])
        for entry in self._feed[:6]:
            style = t.palette["soft"]
            if entry["rarity"] and entry["rarity"] in t.rarity_styles:
                style = t.rarity_styles[entry["rarity"]]
            loot_lines.append(f"  {entry['message']}\n", style=style)
        if not self._feed:
            loot_lines.append("  Waiting for drops...\n", style=t.palette["dim"])

        # ── Quest content ──
        quest_lines = Text()
        quest_lines.append("\n  QUESTS\n\n", style=t.palette["accent"])
        for q in self._quest_tracker.all():
            if q.completed:
                quest_lines.append(f"  \u2705 {q.name}  \u2713\n", style=t.rarity_styles.get("uncommon", t.palette["soft"]))
            else:
                bar = self._make_bar(q.progress, 5)
                pct = int(q.progress * 100)
                quest_lines.append(f"  {self._icon('quest')} {q.metric} {q.compare} {q.target}  ", style=t.palette["soft"])
                quest_lines.append(bar, style=t.palette["accent"])
                quest_lines.append(f"  {pct}%\n", style=t.palette["dim"])

        # Achievements in quest panel
        for a in self._achievements.list_all()[-3:]:
            quest_lines.append(f"  \u2705 {a.description}  \u2713\n", style=t.rarity_styles.get("uncommon", t.palette["soft"]))

        if not self._quest_tracker.all() and not self._achievements.list_all():
            quest_lines.append("  No active quests.\n", style=t.palette["dim"])

        # ── Assemble table ──
        grid = Table(
            show_header=False,
            show_edge=False,
            show_lines=True,
            pad_edge=False,
            expand=True,
            border_style=t.palette["dim"],
        )
        grid.add_column(ratio=1)
        grid.add_column(ratio=1)
        grid.add_row(progress_lines, stats_lines)
        grid.add_row(loot_lines, quest_lines)

        panel = Panel(
            Text.assemble(header, "\n", grid),
            title=title,
            title_align="left",
            box=t.border,
            border_style=t.palette["dim"],
            expand=True,
        )
        return panel


class GameUI:
    """Main entry point. Auto-detects TTY and delegates to RichUI or PlainUI."""

    def __init__(
        self,
        total_steps: int,
        total_epochs: int = 1,
        theme: str = "dark_dungeon",
        refresh_rate: int = 10,
        emoji: bool = True,
        persist: bool = True,
        run_name: str | None = None,
        _force_plain: bool = False,
    ) -> None:
        self._theme = get_theme(theme)
        self._total_steps = total_steps
        self._total_epochs = total_epochs

        use_plain = _force_plain or not is_tty()
        if use_plain:
            self._impl = PlainUI(
                total_steps=total_steps,
                total_epochs=total_epochs,
            )
        else:
            self._impl = RichUI(
                total_steps=total_steps,
                total_epochs=total_epochs,
                theme=self._theme,
                refresh_rate=refresh_rate,
                emoji=emoji,
                persist=persist,
                run_name=run_name,
            )

        # Proxy state attrs for testing
        self._current_step = 0
        self._latest_metrics: dict[str, float] = {}
        self._feed = self._impl._feed
        self._achievements = self._impl._achievements
        self._quest_tracker = self._impl._quest_tracker

    def __enter__(self) -> GameUI:
        self._impl.__enter__()
        return self

    def __exit__(self, *exc: Any) -> None:
        self._impl.__exit__(*exc)

    def step(self, metrics: dict[str, float] | None = None, n: int = 1) -> None:
        self._impl.step(metrics, n)
        self._current_step = self._impl._current_step
        self._latest_metrics = self._impl._latest_metrics

    def epoch_end(self, metrics: dict[str, float] | None = None) -> None:
        self._impl.epoch_end(metrics)
        self._latest_metrics = self._impl._latest_metrics

    def log(self, message: str, rarity: str | None = None) -> None:
        self._impl.log(message, rarity)

    def quest(self, name: str, metric: str, target: float, compare: str = ">=") -> None:
        self._impl.quest(name, metric, target, compare)

    def wrap(self, iterable: Iterable[T], metrics_fn: Callable | None = None) -> Iterator[T]:
        return self._impl.wrap(iterable, metrics_fn)

    def pytorch_step(self, **metrics: float) -> None:
        self._impl.pytorch_step(**metrics)
```

**Step 4: Run tests**

Run: `python -m pytest tests/test_ui.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add lootqdm/ui.py tests/test_ui.py
git commit -m "feat: GameUI with Rich Live 2x2 layout, PlainUI fallback, full game mechanics"
```

---

## Wave 3: Integrations + Examples (depends on Wave 2)

### Task 9: PyTorch Integration

**Files:**
- Create: `lootqdm/integrations/torch.py`

**Step 1: Implement**

```python
"""PyTorch integration for lootqdm."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from lootqdm.ui import GameUI


class LootqdmCallback:
    """Callback-style wrapper for PyTorch training loops.

    Usage:
        cb = LootqdmCallback(ui)
        for batch in dataloader:
            loss = train_step(batch)
            cb.on_batch_end(loss=loss.item(), lr=scheduler.get_last_lr()[0])
        cb.on_epoch_end(val_acc=val_accuracy)
    """

    def __init__(self, ui: GameUI) -> None:
        self._ui = ui

    def on_batch_end(self, **metrics: float) -> None:
        """Call after each training batch."""
        self._ui.step(metrics)

    def on_epoch_end(self, **metrics: float) -> None:
        """Call after each epoch."""
        self._ui.epoch_end(metrics)

    def on_log(self, message: str, rarity: str | None = None) -> None:
        """Log a custom message to the loot feed."""
        self._ui.log(message, rarity)
```

**Step 2: Commit**

```bash
git add lootqdm/integrations/torch.py
git commit -m "feat: PyTorch integration callback"
```

---

### Task 10: Keras Integration

**Files:**
- Create: `lootqdm/integrations/keras.py`

**Step 1: Implement**

```python
"""Keras/TensorFlow integration for lootqdm."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from lootqdm.ui import GameUI

try:
    from tensorflow.keras.callbacks import Callback as _KerasCallback
except ImportError:
    try:
        from keras.callbacks import Callback as _KerasCallback
    except ImportError:
        # Provide a stub base class when Keras is not installed
        class _KerasCallback:  # type: ignore[no-redef]
            def set_params(self, params: Any) -> None: ...
            def on_train_begin(self, logs: Any = None) -> None: ...
            def on_epoch_end(self, epoch: int, logs: Any = None) -> None: ...
            def on_batch_end(self, batch: int, logs: Any = None) -> None: ...
            def on_train_end(self, logs: Any = None) -> None: ...


class LootqdmKerasCallback(_KerasCallback):
    """Keras callback that feeds training metrics into a lootqdm GameUI.

    Usage:
        with GameUI(total_steps=steps_per_epoch * epochs, total_epochs=epochs) as ui:
            model.fit(x, y, callbacks=[LootqdmKerasCallback(ui)])
    """

    def __init__(self, ui: GameUI) -> None:
        super().__init__()
        self._ui = ui

    def on_batch_end(self, batch: int, logs: Any = None) -> None:
        metrics = {}
        if logs:
            for k, v in logs.items():
                try:
                    metrics[k] = float(v)
                except (TypeError, ValueError):
                    pass
        self._ui.step(metrics)

    def on_epoch_end(self, epoch: int, logs: Any = None) -> None:
        metrics = {}
        if logs:
            for k, v in logs.items():
                try:
                    metrics[k] = float(v)
                except (TypeError, ValueError):
                    pass
        self._ui.epoch_end(metrics)
```

**Step 2: Commit**

```bash
git add lootqdm/integrations/keras.py
git commit -m "feat: Keras callback integration"
```

---

### Task 11: Examples

**Files:**
- Create: `examples/basic_loop.py`
- Create: `examples/pytorch_mnist.py`
- Create: `examples/keras_callback.py`

**Step 1: Create basic_loop.py**

```python
#!/usr/bin/env python3
"""Basic lootqdm example — a simple training-like loop."""

import math
import time
from lootqdm import GameUI

TOTAL_STEPS = 500
EPOCHS = 5
STEPS_PER_EPOCH = TOTAL_STEPS // EPOCHS

with GameUI(
    total_steps=TOTAL_STEPS,
    total_epochs=EPOCHS,
    theme="dark_dungeon",
    run_name="basic_demo",
) as ui:
    # Register quests
    ui.quest("Low Loss", "loss", 0.05, "<=")
    ui.quest("High Accuracy", "acc", 0.95, ">=")

    for epoch in range(EPOCHS):
        for step in range(STEPS_PER_EPOCH):
            global_step = epoch * STEPS_PER_EPOCH + step
            # Simulate decreasing loss and increasing accuracy
            loss = 1.0 * math.exp(-global_step / 100)
            acc = 1.0 - loss * 0.8
            lr = 1e-3 * (0.95 ** epoch)

            ui.step({"loss": loss, "acc": acc, "lr": lr})
            time.sleep(0.01)  # Simulate compute

        ui.epoch_end({"loss": loss, "acc": acc, "lr": lr})

print("Training complete!")
```

**Step 2: Create pytorch_mnist.py**

```python
#!/usr/bin/env python3
"""PyTorch MNIST example with lootqdm.

Requires: pip install torch torchvision
If deps are missing, falls back to a simulated loop.
"""

import math
import time

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import DataLoader, TensorDataset

    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False

from lootqdm import GameUI
from lootqdm.integrations.torch import LootqdmCallback


def run_real_training() -> None:
    """Train a tiny model on random data (structure mirrors real MNIST)."""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Fake MNIST-shaped data
    x = torch.randn(1000, 1, 28, 28)
    y = torch.randint(0, 10, (1000,))
    dataset = TensorDataset(x, y)
    loader = DataLoader(dataset, batch_size=32, shuffle=True)

    model = nn.Sequential(
        nn.Flatten(),
        nn.Linear(784, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    ).to(device)

    optimizer = optim.Adam(model.parameters(), lr=1e-3)
    criterion = nn.CrossEntropyLoss()

    epochs = 5
    total_steps = len(loader) * epochs

    with GameUI(total_steps=total_steps, total_epochs=epochs, theme="neon_cyber", run_name="mnist") as ui:
        ui.quest("Low Loss", "loss", 0.5, "<=")
        cb = LootqdmCallback(ui)

        for epoch in range(epochs):
            model.train()
            for batch_x, batch_y in loader:
                batch_x, batch_y = batch_x.to(device), batch_y.to(device)
                optimizer.zero_grad()
                out = model(batch_x)
                loss = criterion(out, batch_y)
                loss.backward()
                optimizer.step()

                acc = (out.argmax(1) == batch_y).float().mean().item()
                cb.on_batch_end(loss=loss.item(), acc=acc, lr=optimizer.param_groups[0]["lr"])

            cb.on_epoch_end(val_loss=loss.item(), val_acc=acc)


def run_simulated() -> None:
    """Simulated training when PyTorch is not installed."""
    total = 500
    epochs = 5
    steps_per = total // epochs

    with GameUI(total_steps=total, total_epochs=epochs, theme="neon_cyber", run_name="mnist_sim") as ui:
        ui.quest("Low Loss", "loss", 0.1, "<=")

        for epoch in range(epochs):
            for step in range(steps_per):
                g = epoch * steps_per + step
                loss = 2.0 * math.exp(-g / 80)
                acc = min(0.99, 0.5 + g / (total * 1.2))
                ui.step({"loss": loss, "acc": acc, "lr": 1e-3})
                time.sleep(0.01)
            ui.epoch_end({"val_loss": loss, "val_acc": acc})


if __name__ == "__main__":
    if HAS_TORCH:
        run_real_training()
    else:
        print("PyTorch not found — running simulated loop.")
        run_simulated()
```

**Step 3: Create keras_callback.py**

```python
#!/usr/bin/env python3
"""Keras callback example with lootqdm.

Requires: pip install tensorflow
If deps are missing, falls back to a simulated loop.
"""

import math
import time

try:
    import numpy as np
    import tensorflow as tf
    from tensorflow import keras

    HAS_KERAS = True
except ImportError:
    HAS_KERAS = False

from lootqdm import GameUI
from lootqdm.integrations.keras import LootqdmKerasCallback


def run_real_training() -> None:
    """Train a tiny Keras model on random data."""
    x = np.random.randn(1000, 784).astype("float32")
    y = np.random.randint(0, 10, (1000,))

    model = keras.Sequential([
        keras.layers.Dense(128, activation="relu", input_shape=(784,)),
        keras.layers.Dense(10, activation="softmax"),
    ])
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])

    epochs = 5
    batch_size = 32
    steps_per_epoch = len(x) // batch_size
    total_steps = steps_per_epoch * epochs

    with GameUI(total_steps=total_steps, total_epochs=epochs, theme="cozy_pastel", run_name="keras_demo") as ui:
        ui.quest("Low Loss", "loss", 0.5, "<=")
        model.fit(x, y, epochs=epochs, batch_size=batch_size, callbacks=[LootqdmKerasCallback(ui)], verbose=0)


def run_simulated() -> None:
    """Simulated training when Keras is not installed."""
    total = 400
    epochs = 5
    steps_per = total // epochs

    with GameUI(total_steps=total, total_epochs=epochs, theme="cozy_pastel", run_name="keras_sim") as ui:
        ui.quest("Low Loss", "loss", 0.5, "<=")

        for epoch in range(epochs):
            for step in range(steps_per):
                g = epoch * steps_per + step
                loss = 2.5 * math.exp(-g / 60)
                acc = min(0.98, 0.3 + g / (total * 1.5))
                ui.step({"loss": loss, "accuracy": acc})
                time.sleep(0.01)
            ui.epoch_end({"val_loss": loss, "val_accuracy": acc})


if __name__ == "__main__":
    if HAS_KERAS:
        run_real_training()
    else:
        print("TensorFlow/Keras not found — running simulated loop.")
        run_simulated()
```

**Step 4: Commit**

```bash
git add examples/
git commit -m "feat: examples for basic loop, PyTorch MNIST, and Keras callback"
```

---

## Wave 4: README + Final Polish

### Task 12: Update __init__.py exports + README

**Files:**
- Modify: `lootqdm/__init__.py` (add integration imports)
- Create: `README.md`

**Step 1: Create README.md**

```markdown
# lootqdm

> Turn your training loop into an idle RPG.

[![PyPI](https://img.shields.io/pypi/v/lootqdm)](https://pypi.org/project/lootqdm/)
[![Python](https://img.shields.io/pypi/pyversions/lootqdm)](https://pypi.org/project/lootqdm/)
[![License](https://img.shields.io/pypi/l/lootqdm)](https://github.com/lootqdm/lootqdm/blob/main/LICENSE)

**lootqdm** replaces your boring training progress bars with an idle RPG experience. XP bars, loot drops, quests, achievements, level-ups — all in your terminal.

## Quick Start

```bash
pip install lootqdm
```

### Minimal Example

```python
from lootqdm import GameUI

with GameUI(total_steps=1000) as ui:
    for i in range(1000):
        loss = 0.9 / (i + 1)
        ui.step({"loss": loss, "lr": 1e-3})
```

### Wrap an Iterable

```python
from lootqdm import GameUI

with GameUI(total_steps=len(dataloader)) as ui:
    for batch in ui.wrap(dataloader):
        loss = train_step(batch)
        ui.step({"loss": loss.item()})
```

### PyTorch

```python
from lootqdm import GameUI
from lootqdm.integrations.torch import LootqdmCallback

with GameUI(total_steps=len(loader) * epochs, total_epochs=epochs, theme="neon_cyber") as ui:
    cb = LootqdmCallback(ui)
    for epoch in range(epochs):
        for batch in loader:
            loss = train_step(batch)
            cb.on_batch_end(loss=loss.item(), acc=accuracy)
        cb.on_epoch_end(val_acc=val_accuracy)
```

### Keras

```python
from lootqdm import GameUI
from lootqdm.integrations.keras import LootqdmKerasCallback

with GameUI(total_steps=steps_per_epoch * epochs, total_epochs=epochs) as ui:
    model.fit(x, y, callbacks=[LootqdmKerasCallback(ui)])
```

## Themes

Choose from 4 built-in themes:

| Theme | Vibe | Preview |
|-------|------|---------|
| `dark_dungeon` | Roguelike, gritty | `🩸🗡️🪙💠⚜️` |
| `cozy_pastel` | Cottagecore, soft | `🌱🧺🍓🫐🧁` |
| `neon_cyber` | Synthwave, flashy | `⚡🧬📀🧪💎` |
| `retro_crt` | Old terminal, ASCII | `[C][U][R][E][L]` |

```python
GameUI(total_steps=1000, theme="cozy_pastel")
```

## Quests

Set metric-based goals:

```python
with GameUI(total_steps=1000) as ui:
    ui.quest("Low Loss", "loss", 0.05, "<=")
    ui.quest("High Accuracy", "acc", 0.95, ">=")
    # ...
```

## API Reference

### `GameUI`

| Method | Description |
|--------|-------------|
| `step(metrics, n=1)` | Advance progress by n steps with optional metrics dict |
| `epoch_end(metrics)` | Signal end of epoch, triggers quest checks |
| `log(message, rarity)` | Add a message to the loot feed |
| `quest(name, metric, target, compare)` | Register a quest goal |
| `wrap(iterable, metrics_fn)` | Wrap an iterable with automatic step tracking |
| `pytorch_step(**metrics)` | Convenience for `step(metrics)` with kwargs |

### Constructor

```python
GameUI(
    total_steps=1000,       # Total training steps
    total_epochs=10,        # Number of epochs
    theme="dark_dungeon",   # Theme name
    refresh_rate=10,        # Max FPS for terminal refresh
    emoji=True,             # Enable emoji icons
    persist=True,           # Save profile to ~/.lootqdm/
    run_name="my_run",      # Display name for the run
)
```

## How It Works

- Each `step()` grants XP, checks for loot drops, and may trigger random events
- Loot rarity: Common (70%) > Uncommon (20%) > Rare (8%) > Epic (1.9%) > Legendary (0.1%)
- Level thresholds follow a quadratic curve
- Metrics are mapped to game stats: loss → DMG, accuracy → CRIT, lr → MANA
- Profile persists across runs at `~/.lootqdm/profile.json`

## License

MIT
```

**Step 2: Commit**

```bash
git add README.md
git commit -m "docs: README with usage examples, API reference, and theme table"
```

---

### Task 13: Run Full Test Suite + Final Verification

**Step 1: Run all tests**

Run: `cd /Volumes/Auxilary/Side_Projects/Lootqdm && python -m pytest tests/ -v --tb=short`
Expected: All PASS

**Step 2: Verify package is importable**

Run: `cd /Volumes/Auxilary/Side_Projects/Lootqdm && python -c "from lootqdm import GameUI, StatMapper, LootTable, Quest; print('OK')"`
Expected: "OK"

**Step 3: Run basic example (smoke test)**

Run: `cd /Volumes/Auxilary/Side_Projects/Lootqdm && python examples/basic_loop.py`
Expected: Runs without crash (will use PlainUI in non-TTY)

**Step 4: Commit any final fixes if needed**

```bash
git add -A
git commit -m "chore: final verification pass"
```
