# lootqdm v0.2.0 Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Upgrade lootqdm with a unified-border box-drawing UI, cross-platform GPU monitoring, a class/boss-battle system, and corrected GitHub/PyPI metadata.

**Architecture:** Four independent subsystems: (A) `Theme.box_chars` dict + custom `_GamePanel` Renderable replacing the `Panel(Group(header, Table))` approach so inner grid lines use identical box characters as the outer border; (B) `lootqdm/gpu.py` with silent cross-platform fallback for GPU stats injected into the STATS panel; (C) `lootqdm/classes.py` loot flavor + boss events fired in `epoch_end` at milestone epochs; (D) `pyproject.toml` metadata + GitHub push.

**Tech Stack:** Python 3.10+, `rich>=13.0` (only required dep), `pynvml` (optional), `subprocess` (stdlib) for GPU fallbacks

---

## Chunk 1: Theme box_chars + Custom Box Renderable

### Task 1: Add `box_chars` to `Theme` dataclass

**Files:**
- Modify: `lootqdm/themes.py`
- Modify: `tests/test_themes.py`

- [ ] **Step 1.1: Write the failing test**

Add this test method inside `TestThemeStructure` class in `tests/test_themes.py`:

```python
def test_all_themes_have_box_chars(self):
    REQUIRED_KEYS = {
        "top_left", "top_right", "bot_left", "bot_right",
        "horiz", "vert", "top_tee", "bot_tee",
        "left_tee", "right_tee", "cross",
    }
    for name in list_themes():
        theme = get_theme(name)
        assert hasattr(theme, "box_chars"), f"{name} missing box_chars"
        missing = REQUIRED_KEYS - theme.box_chars.keys()
        assert not missing, f"{name} box_chars missing keys: {missing}"
```

- [ ] **Step 1.2: Run test to verify it fails**

```bash
cd /Volumes/Auxilary/Side_Projects/Lootqdm
python3 -m pytest tests/test_themes.py::TestThemeStructure::test_all_themes_have_box_chars -v
```
Expected: `AttributeError` or `FAILED`

- [ ] **Step 1.3: Add `box_chars` to Theme dataclass and all 4 themes**

In `lootqdm/themes.py`, add `box_chars: dict[str, str]` as the last field in `Theme` (after `loot_names`):

```python
@dataclass(frozen=True)
class Theme:
    name: str
    palette: dict[str, str]
    icons: dict[str, Any]
    rarity_styles: dict[str, str]
    bar_chars: tuple[str, str]
    border: Box
    separators: tuple[str, ...]
    loot_names: dict[str, list[str]]
    box_chars: dict[str, str]
```

Add `box_chars` to each theme definition:

**`_COZY_PASTEL`** (ROUNDED border → ╭╮╰╯─│┬┴├┤┼):
```python
box_chars={
    "top_left": "╭", "top_right": "╮",
    "bot_left": "╰", "bot_right": "╯",
    "horiz": "─", "vert": "│",
    "top_tee": "┬", "bot_tee": "┴",
    "left_tee": "├", "right_tee": "┤",
    "cross": "┼",
},
```

**`_DARK_DUNGEON`** (HEAVY border → ┏┓┗┛━┃┳┻┣┫╋):
```python
box_chars={
    "top_left": "┏", "top_right": "┓",
    "bot_left": "┗", "bot_right": "┛",
    "horiz": "━", "vert": "┃",
    "top_tee": "┳", "bot_tee": "┻",
    "left_tee": "┣", "right_tee": "┫",
    "cross": "╋",
},
```

**`_NEON_CYBER`** (DOUBLE border → ╔╗╚╝═║╦╩╠╣╬):
```python
box_chars={
    "top_left": "╔", "top_right": "╗",
    "bot_left": "╚", "bot_right": "╝",
    "horiz": "═", "vert": "║",
    "top_tee": "╦", "bot_tee": "╩",
    "left_tee": "╠", "right_tee": "╣",
    "cross": "╬",
},
```

**`_RETRO_CRT`** (ASCII border → all `+`, `-`, `|`):
```python
box_chars={
    "top_left": "+", "top_right": "+",
    "bot_left": "+", "bot_right": "+",
    "horiz": "-", "vert": "|",
    "top_tee": "+", "bot_tee": "+",
    "left_tee": "+", "right_tee": "+",
    "cross": "+",
},
```

- [ ] **Step 1.4: Run test to verify it passes**

```bash
python3 -m pytest tests/test_themes.py -v
```
Expected: all PASS

- [ ] **Step 1.5: Commit**

```bash
git add lootqdm/themes.py tests/test_themes.py
git commit -m "feat: add box_chars field to Theme for unified border rendering"
```

---

### Task 2: Implement `_GamePanel` custom Renderable + rewrite `_render()`

**Files:**
- Modify: `lootqdm/ui.py`

**Design:** Replace the current `_render()` return value of `Panel(Group(header, Table(...)))` with a custom `_GamePanel` instance. `_GamePanel` is a module-level class in `ui.py` implementing `__rich_console__` that yields `Text` lines building a 2×2 grid with unified box-drawing borders.

**Layout:**
```
<top_left><horiz>...<top_tee><horiz>...<top_right>    ← title embedded here
<vert> header text                          <vert>
<left_tee><horiz>...<cross><horiz>...<right_tee>
<vert> PROGRESS section    <vert> STATS section    <vert>
<left_tee><horiz>...<cross><horiz>...<right_tee>
<vert> LOOT & EVENTS       <vert> QUESTS           <vert>
<bot_left><horiz>...<bot_tee><horiz>...<bot_right>
```

**Module-level helper** (add before `PlainUI` class):

```python
def _split_to_lines(text: "Text", col_w: int) -> "list[Text]":
    """Split a multi-line Rich Text into right-padded per-line Text objects."""
    from rich.text import Text as RichText
    lines = []
    for raw_line in text.plain.split("\n"):
        t = RichText(raw_line)
        pad = max(0, col_w - len(raw_line))
        t.append(" " * pad)
        lines.append(t)
    # Drop trailing blank lines
    while lines and not lines[-1].plain.strip():
        lines.pop()
    return lines
```

**`_GamePanel` class** (add before `PlainUI`):

```python
class _GamePanel:
    """Custom Rich renderable: unified box-drawing 2×2 grid panel."""

    def __init__(
        self,
        title: str,
        title_style: str,
        header_plain: str,
        header_style: str,
        top_left_lines: "list[Text]",
        top_right_lines: "list[Text]",
        bot_left_lines: "list[Text]",
        bot_right_lines: "list[Text]",
        box_chars: dict,
        border_style: str,
        col_w: int,
    ) -> None:
        self._title = title
        self._title_style = title_style
        self._header_plain = header_plain
        self._header_style = header_style
        self._tl = top_left_lines
        self._tr = top_right_lines
        self._bl = bot_left_lines
        self._br = bot_right_lines
        self._bc = box_chars
        self._bs = border_style
        self._col_w = col_w

    def __rich_console__(self, console: Any, options: Any) -> Any:
        from rich.text import Text

        bc = self._bc
        bs = self._bs
        w = self._col_w
        h = bc["horiz"]
        v = bc["vert"]

        def btext(s: str) -> Text:
            return Text(s, style=bs)

        def hline(left: str, mid: str, right: str) -> Text:
            return btext(f"{left}{h * (w + 1)}{mid}{h * (w + 1)}{right}")

        # Total inner width (between the two outer vertical bars)
        inner_w = (w + 1) * 2 + 1

        # Top border with title
        title_text = f" {self._title} "
        title_pad = max(0, inner_w - len(title_text))
        yield Text.assemble(
            Text(bc["top_left"], style=bs),
            Text(title_text, style=self._title_style),
            Text(h * title_pad + bc["top_right"], style=bs),
        )

        # Header line
        header_pad = max(0, inner_w - len(self._header_plain))
        yield Text.assemble(
            Text(v, style=bs),
            Text(self._header_plain, style=self._header_style),
            Text(" " * header_pad + v, style=bs),
        )

        # Divider after header
        yield hline(bc["left_tee"], bc["cross"], bc["right_tee"])

        # Top row: PROGRESS | STATS
        max_top = max(len(self._tl), len(self._tr), 1)
        empty = Text(" " * w)
        for i in range(max_top):
            ll = self._tl[i] if i < len(self._tl) else empty
            rl = self._tr[i] if i < len(self._tr) else empty
            yield Text.assemble(Text(v, style=bs), ll, Text(v, style=bs), rl, Text(v, style=bs))

        # Mid divider
        yield hline(bc["left_tee"], bc["cross"], bc["right_tee"])

        # Bottom row: LOOT & EVENTS | QUESTS
        max_bot = max(len(self._bl), len(self._br), 1)
        for i in range(max_bot):
            ll = self._bl[i] if i < len(self._bl) else empty
            rl = self._br[i] if i < len(self._br) else empty
            yield Text.assemble(Text(v, style=bs), ll, Text(v, style=bs), rl, Text(v, style=bs))

        # Bottom border
        yield hline(bc["bot_left"], bc["bot_tee"], bc["bot_right"])
```

**Rewrite `RichUI._render()`:** Keep the same content-building logic for `progress_lines`, `stats_lines`, `loot_lines`, `quest_lines` (all as `Text` objects). Then replace the `grid = Table(...)` + `panel = Panel(...)` at the end with:

```python
# ── Assemble using unified box-drawing renderable ──
W = 80
col_w = (W - 3) // 2  # = 38 columns each

title_str = f"{title_icon} LOOTQDM"
header_str = (
    f"  {self._run_name} {t.separators[0]} {t.name}"
    + " " * max(1, 35 - len(self._run_name) - len(t.name))
    + f"\u2699  {format_time(elapsed)}"
)

return _GamePanel(
    title=title_str,
    title_style=t.palette["title"],
    header_plain=header_str,
    header_style=t.palette["soft"],
    top_left_lines=_split_to_lines(progress_lines, col_w),
    top_right_lines=_split_to_lines(stats_lines, col_w),
    bot_left_lines=_split_to_lines(loot_lines, col_w),
    bot_right_lines=_split_to_lines(quest_lines, col_w),
    box_chars=t.box_chars,
    border_style=t.palette["dim"],
    col_w=col_w,
)
```

Remove these now-unused imports from `_render()`: `from rich.panel import Panel`, `from rich.table import Table`, `from rich.console import Group`. Keep `from rich.text import Text`.

- [ ] **Step 2.1: Write failing tests**

Add `TestGamePanelRender` class to `tests/test_ui.py`:

```python
class TestGamePanelRender:
    def _make_rich_ui(self):
        import time
        from collections import deque
        from lootqdm.ui import RichUI
        from lootqdm.themes import get_theme
        from lootqdm.events import AchievementTracker, LootTable, EventBus
        from lootqdm.quests import QuestTracker
        from lootqdm.mappers import StatMapper
        from lootqdm.utils import Throttle
        from random import Random

        rui = object.__new__(RichUI)
        rui._theme = get_theme("dark_dungeon")
        rui._start_time = time.monotonic()
        rui._current_step = 5
        rui._total_steps = 100
        rui._current_epoch = 0
        rui._total_epochs = 2
        rui._latest_metrics = {"loss": 0.5, "acc": 0.8}
        rui._best_metrics = {}
        rui._feed = [{"message": "Test drop", "rarity": "common"}]
        rui._xp = 500
        rui._level = 2
        rui._emoji = True
        rui._run_name = "test_run"
        rui._sparkline_buffers = {}
        rui._achievements = AchievementTracker()
        rui._quest_tracker = QuestTracker()
        rui._mapper = StatMapper()
        return rui

    def test_render_produces_section_headers(self):
        from io import StringIO
        from rich.console import Console
        rui = self._make_rich_ui()
        buf = StringIO()
        console = Console(file=buf, width=80, no_color=True)
        console.print(rui._render())
        output = buf.getvalue()
        assert "PROGRESS" in output
        assert "STATS" in output
        assert "LOOT" in output
        assert "QUESTS" in output

    def test_render_uses_dark_dungeon_box_chars(self):
        from io import StringIO
        from rich.console import Console
        rui = self._make_rich_ui()
        buf = StringIO()
        console = Console(file=buf, width=80, no_color=True)
        console.print(rui._render())
        output = buf.getvalue()
        # HEAVY border chars
        assert "┏" in output
        assert "┃" in output

    def test_render_cozy_pastel_uses_rounded_chars(self):
        from io import StringIO
        from rich.console import Console
        from lootqdm.themes import get_theme
        rui = self._make_rich_ui()
        rui._theme = get_theme("cozy_pastel")
        buf = StringIO()
        console = Console(file=buf, width=80, no_color=True)
        console.print(rui._render())
        assert "╭" in buf.getvalue()

    def test_render_retro_crt_uses_ascii_chars(self):
        from io import StringIO
        from rich.console import Console
        from lootqdm.themes import get_theme
        rui = self._make_rich_ui()
        rui._theme = get_theme("retro_crt")
        buf = StringIO()
        console = Console(file=buf, width=80, no_color=True)
        console.print(rui._render())
        output = buf.getvalue()
        assert "+" in output
        assert "-" in output
```

- [ ] **Step 2.2: Run tests to verify they fail**

```bash
python3 -m pytest tests/test_ui.py::TestGamePanelRender -v
```
Expected: `FAILED` (box chars not yet implemented)

- [ ] **Step 2.3: Implement `_split_to_lines`, `_GamePanel`, and rewrite `_render()`**

Follow the skeletons above precisely. The `_render()` content-building code (progress_lines, stats_lines, loot_lines, quest_lines) stays the same — only the final assembly changes.

- [ ] **Step 2.4: Run UI tests**

```bash
python3 -m pytest tests/test_ui.py -v
```
Expected: all PASS

- [ ] **Step 2.5: Run full suite to check no regressions**

```bash
python3 -m pytest tests/ -q
```
Expected: 77+ tests PASS

- [ ] **Step 2.6: Commit**

```bash
git add lootqdm/ui.py tests/test_ui.py
git commit -m "feat: replace Panel+Table with unified GamePanel box-drawing renderable"
```

---

## Chunk 2: Cross-Platform GPU Module

### Task 3: Create `lootqdm/gpu.py` and integrate into STATS panel

**Files:**
- Create: `lootqdm/gpu.py`
- Modify: `lootqdm/ui.py` (STATS section of `_render()`)
- Create: `tests/test_gpu.py`

**Contract:** `get_gpu_stats() -> dict | None`

Return dict keys: `name: str`, `util_pct: float|None`, `mem_used_mb: float|None`, `mem_total_mb: float|None`, `temp_c: float|None`. Returns `None` if no GPU info available. Never raises.

**Detection order:** NVIDIA via pynvml → Apple Silicon via ioreg → AMD via rocm-smi → None

- [ ] **Step 3.1: Write failing tests**

Create `tests/test_gpu.py`:

```python
"""Tests for lootqdm.gpu — cross-platform GPU stats."""
from __future__ import annotations


class TestGetGpuStats:
    def test_returns_none_or_valid_dict(self):
        from lootqdm.gpu import get_gpu_stats
        result = get_gpu_stats()
        if result is not None:
            assert "name" in result
            for key in ("util_pct", "mem_used_mb", "mem_total_mb", "temp_c"):
                assert key in result
                assert result[key] is None or isinstance(result[key], (int, float))

    def test_never_raises(self):
        from lootqdm.gpu import get_gpu_stats
        try:
            get_gpu_stats()
        except Exception as e:
            raise AssertionError(f"get_gpu_stats raised {e!r}")

    def test_try_nvidia_returns_none_when_pynvml_missing(self):
        import builtins
        real_import = builtins.__import__

        def block_pynvml(name, *args, **kwargs):
            if name == "pynvml":
                raise ImportError("blocked")
            return real_import(name, *args, **kwargs)

        import unittest.mock as mock
        with mock.patch("builtins.__import__", side_effect=block_pynvml):
            from lootqdm.gpu import _try_nvidia
            result = _try_nvidia()
            assert result is None


class TestParseIoregOutput:
    def test_parses_utilization_and_memory(self):
        from lootqdm.gpu import _parse_ioreg_output
        sample = (
            '| "PerformanceStatistics" = {"Device Utilization %"=42,'
            '"In use system memory"=2147483648}'
        )
        result = _parse_ioreg_output(sample)
        assert result is not None
        assert result["util_pct"] == 42.0
        assert abs(result["mem_used_mb"] - 2048.0) < 1.0

    def test_returns_none_on_empty_input(self):
        from lootqdm.gpu import _parse_ioreg_output
        assert _parse_ioreg_output("") is None
        assert _parse_ioreg_output("no relevant content") is None

    def test_partial_data_ok(self):
        from lootqdm.gpu import _parse_ioreg_output
        # Only utilization, no memory
        result = _parse_ioreg_output('"Device Utilization %"=75')
        assert result is not None
        assert result["util_pct"] == 75.0
        assert result["mem_used_mb"] is None


class TestParseRocmOutput:
    def test_parses_rocm_json(self):
        import json
        from lootqdm.gpu import _parse_rocm_output
        sample = json.dumps({
            "card0": {
                "GPU use (%)": "55",
                "VRAM Total Memory (B)": "8589934592",
                "VRAM Total Used Memory (B)": "2147483648",
            }
        })
        result = _parse_rocm_output(sample)
        assert result is not None
        assert result["util_pct"] == 55.0
        assert abs(result["mem_total_mb"] - 8192.0) < 1.0
        assert abs(result["mem_used_mb"] - 2048.0) < 1.0

    def test_returns_none_on_bad_json(self):
        from lootqdm.gpu import _parse_rocm_output
        assert _parse_rocm_output("not json") is None
        assert _parse_rocm_output("{}") is None
```

- [ ] **Step 3.2: Run tests to verify they fail**

```bash
python3 -m pytest tests/test_gpu.py -v
```
Expected: `ModuleNotFoundError: No module named 'lootqdm.gpu'`

- [ ] **Step 3.3: Implement `lootqdm/gpu.py`**

```python
"""Cross-platform GPU monitoring for lootqdm. Never raises exceptions."""
from __future__ import annotations

import json
import re
import subprocess
from typing import Any


def get_gpu_stats() -> dict[str, Any] | None:
    """Return GPU stats dict or None if unavailable. Never raises."""
    result = _try_nvidia()
    if result is not None:
        return result
    result = _try_apple_silicon()
    if result is not None:
        return result
    return _try_amd()


def _try_nvidia() -> dict[str, Any] | None:
    """Try pynvml for NVIDIA GPUs. Returns None if unavailable."""
    try:
        import pynvml  # noqa: PLC0415
        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        name = pynvml.nvmlDeviceGetName(handle)
        if isinstance(name, bytes):
            name = name.decode()
        util = pynvml.nvmlDeviceGetUtilizationRates(handle)
        mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
        try:
            temp = float(pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU))
        except Exception:
            temp = None
        return {
            "name": name,
            "util_pct": float(util.gpu),
            "mem_used_mb": mem.used / (1024 ** 2),
            "mem_total_mb": mem.total / (1024 ** 2),
            "temp_c": temp,
        }
    except Exception:
        return None


def _try_apple_silicon() -> dict[str, Any] | None:
    """Try ioreg on macOS for Apple Silicon GPU. Falls back to system_profiler for name."""
    try:
        proc = subprocess.run(
            ["ioreg", "-r", "-c", "AGXAccelerator", "-k", "PerformanceStatistics", "-d", "1"],
            capture_output=True, text=True, timeout=2,
        )
        parsed = _parse_ioreg_output(proc.stdout)
        if parsed is not None:
            return parsed
    except Exception:
        pass
    # Fallback: get GPU name only
    try:
        proc = subprocess.run(
            ["system_profiler", "SPDisplaysDataType", "-json"],
            capture_output=True, text=True, timeout=5,
        )
        data = json.loads(proc.stdout)
        displays = data.get("SPDisplaysDataType", [{}])
        name = displays[0].get("sppci_model", "Apple GPU")
        return {"name": name, "util_pct": None, "mem_used_mb": None, "mem_total_mb": None, "temp_c": None}
    except Exception:
        return None


def _parse_ioreg_output(text: str) -> dict[str, Any] | None:
    """Parse ioreg PerformanceStatistics output. Returns None if no data found."""
    util_match = re.search(r'"Device Utilization %"=(\d+)', text)
    mem_match = re.search(r'"In use system memory"=(\d+)', text)
    if not util_match and not mem_match:
        return None
    return {
        "name": "Apple GPU",
        "util_pct": float(util_match.group(1)) if util_match else None,
        "mem_used_mb": float(mem_match.group(1)) / (1024 ** 2) if mem_match else None,
        "mem_total_mb": None,
        "temp_c": None,
    }


def _try_amd() -> dict[str, Any] | None:
    """Try rocm-smi for AMD GPUs on Linux."""
    try:
        proc = subprocess.run(
            ["rocm-smi", "--showuse", "--showmeminfo", "vram", "--json"],
            capture_output=True, text=True, timeout=3,
        )
        return _parse_rocm_output(proc.stdout)
    except Exception:
        return None


def _parse_rocm_output(text: str) -> dict[str, Any] | None:
    """Parse rocm-smi JSON output. Returns None on failure."""
    try:
        data = json.loads(text)
        if not data:
            return None
        card_data = next(iter(data.values()))
        util_pct = float(card_data.get("GPU use (%)", 0))
        mem_total_b = float(card_data.get("VRAM Total Memory (B)", 0))
        mem_used_b = float(card_data.get("VRAM Total Used Memory (B)", 0))
        return {
            "name": "AMD GPU",
            "util_pct": util_pct,
            "mem_used_mb": mem_used_b / (1024 ** 2) if mem_used_b else None,
            "mem_total_mb": mem_total_b / (1024 ** 2) if mem_total_b else None,
            "temp_c": None,
        }
    except Exception:
        return None
```

- [ ] **Step 3.4: Run GPU tests to verify they pass**

```bash
python3 -m pytest tests/test_gpu.py -v
```
Expected: all PASS

- [ ] **Step 3.5: Integrate GPU stats into STATS panel in `RichUI._render()`**

In `lootqdm/ui.py`, in `RichUI._render()`, after the sparkline section and before building `loot_lines`, add:

```python
# GPU stats row (optional — fails silently)
try:
    from lootqdm.gpu import get_gpu_stats  # noqa: PLC0415
    gpu = get_gpu_stats()
    if gpu is not None:
        gpu_name = gpu["name"][:18]
        stats_lines.append(f"  \U0001f5a5 ", style=t.palette["accent"])
        stats_lines.append(f"{gpu_name}", style=t.palette["soft"])
        if gpu["util_pct"] is not None:
            stats_lines.append(f"  {gpu['util_pct']:.0f}%", style=t.palette["dim"])
        if gpu["mem_used_mb"] is not None and gpu["mem_total_mb"] is not None:
            stats_lines.append(
                f"  {gpu['mem_used_mb']:.0f}/{gpu['mem_total_mb']:.0f}MB",
                style=t.palette["dim"],
            )
        elif gpu["mem_used_mb"] is not None:
            stats_lines.append(f"  {gpu['mem_used_mb']:.0f}MB", style=t.palette["dim"])
        if gpu["temp_c"] is not None:
            stats_lines.append(f"  {gpu['temp_c']:.0f}\u00b0C", style=t.palette["dim"])
        stats_lines.append("\n")
except Exception:
    pass
```

- [ ] **Step 3.6: Run full test suite**

```bash
python3 -m pytest tests/ -q
```
Expected: all PASS

- [ ] **Step 3.7: Commit**

```bash
git add lootqdm/gpu.py tests/test_gpu.py lootqdm/ui.py
git commit -m "feat: cross-platform GPU monitoring in STATS panel"
```

---

## Chunk 3: Class System + Boss Battles

### Task 4: Create `lootqdm/classes.py`

**Files:**
- Create: `lootqdm/classes.py`
- Create: `tests/test_classes.py`

- [ ] **Step 4.1: Write failing tests**

Create `tests/test_classes.py`:

```python
"""Tests for lootqdm.classes — class flavor system."""
from __future__ import annotations


class TestClassSystem:
    def test_valid_classes_defined(self):
        from lootqdm.classes import VALID_CLASSES
        assert "wizard" in VALID_CLASSES
        assert "warrior" in VALID_CLASSES
        assert "rogue" in VALID_CLASSES

    def test_all_classes_cover_all_rarities(self):
        from lootqdm.classes import CLASS_LOOT_OVERRIDES
        RARITIES = {"common", "uncommon", "rare", "epic", "legendary"}
        for class_name, overrides in CLASS_LOOT_OVERRIDES.items():
            missing = RARITIES - overrides.keys()
            assert not missing, f"{class_name} missing rarities: {missing}"
            for rarity, names in overrides.items():
                assert len(names) >= 3, f"{class_name}.{rarity} needs >=3 names"

    def test_get_loot_names_returns_class_override(self):
        from lootqdm.classes import get_loot_names
        from lootqdm.themes import get_theme
        theme = get_theme("dark_dungeon")
        names = get_loot_names("wizard", theme.loot_names)
        assert names != theme.loot_names
        all_names = [n for lst in names.values() for n in lst]
        assert any("Spell" in n or "Mana" in n or "Arcane" in n or "Glyph" in n for n in all_names)

    def test_get_loot_names_none_returns_theme(self):
        from lootqdm.classes import get_loot_names
        from lootqdm.themes import get_theme
        theme = get_theme("dark_dungeon")
        assert get_loot_names(None, theme.loot_names) == theme.loot_names

    def test_get_loot_names_invalid_class_returns_theme(self):
        from lootqdm.classes import get_loot_names
        from lootqdm.themes import get_theme
        theme = get_theme("dark_dungeon")
        assert get_loot_names("paladin", theme.loot_names) == theme.loot_names

    def test_boss_names_for_all_classes_and_none(self):
        from lootqdm.classes import BOSS_NAMES, VALID_CLASSES
        for class_name in list(VALID_CLASSES) + [None]:
            assert class_name in BOSS_NAMES
            for milestone in ("first", "mid", "final"):
                assert milestone in BOSS_NAMES[class_name]
                assert isinstance(BOSS_NAMES[class_name][milestone], str)
                assert len(BOSS_NAMES[class_name][milestone]) > 0
```

- [ ] **Step 4.2: Run tests to verify they fail**

```bash
python3 -m pytest tests/test_classes.py -v
```
Expected: `ModuleNotFoundError: No module named 'lootqdm.classes'`

- [ ] **Step 4.3: Implement `lootqdm/classes.py`**

```python
"""Class system: loot name flavor overrides and boss names per player class."""
from __future__ import annotations

VALID_CLASSES: frozenset[str] = frozenset({"wizard", "warrior", "rogue"})

CLASS_LOOT_OVERRIDES: dict[str, dict[str, list[str]]] = {
    "wizard": {
        "common":    ["Arcane Dust", "Mana Residue", "Spell Fragment", "Glyph Chip", "Magic Cinder"],
        "uncommon":  ["Spell Tome", "Mana Crystal", "Glyph Shard", "Arcane Scroll", "Focus Gem"],
        "rare":      ["Ether Core", "Runic Slab", "Soul Prism", "Void Catalyst", "Arcane Sigil"],
        "epic":      ["Forbidden Codex", "Astral Lens", "Eldritch Staff", "Mana Vortex", "Lich Seal"],
        "legendary": ["Crown of Spells", "The Infinite Tome", "Arcane Throne", "Worldsoul Crystal", "Epoch Rune"],
    },
    "warrior": {
        "common":    ["Iron Scrap", "Battle Dust", "Dented Helm", "Broken Shield", "War Shard"],
        "uncommon":  ["Iron Shield", "War Axe", "Battle Standard", "Siege Bolt", "Warrior's Crest"],
        "rare":      ["Dragon Plate", "Warlord's Seal", "Bloodsteel Sword", "Fortress Key", "Titan Gauntlet"],
        "epic":      ["Siege Engine Part", "Colossus Pauldron", "Champion's Brand", "Iron Throne Shard", "Warmaster Relic"],
        "legendary": ["The Iron Crown", "Warbringer's Axe", "Eternal Shield", "Dragon Lord Armor", "Legendary War Banner"],
    },
    "rogue": {
        "common":    ["Shadow Dust", "Smoke Fragment", "Poison Drop", "Frayed Cloak", "Lockpick Shard"],
        "uncommon":  ["Shadow Dagger", "Smoke Bomb", "Poison Vial", "Thief's Coin", "Cloak of Shadows"],
        "rare":      ["Venomblade", "Phantom Step", "Night Seal", "Assassin's Mark", "Void Garrote"],
        "epic":      ["Wraith Shroud", "Deathwhisper Blade", "Phantom Crown", "Shadow Throne Token", "Eclipse Poison"],
        "legendary": ["The Night Throne", "Shadowstep Mantle", "Eternal Silence", "Void King's Mark", "The Last Shadow"],
    },
}

BOSS_NAMES: dict[str | None, dict[str, str]] = {
    "wizard":  {"first": "The Mana Drake",   "mid": "The Arcane Lich",  "final": "The Void Architect"},
    "warrior": {"first": "Iron Golem",        "mid": "The Warlord",      "final": "Dragon Lord"},
    "rogue":   {"first": "Shadow Stalker",    "mid": "The Phantom",      "final": "The Night King"},
    None:      {"first": "The First Guardian","mid": "The Midfield Boss", "final": "The Final Arbiter"},
}


def get_loot_names(
    class_: str | None, theme_names: dict[str, list[str]]
) -> dict[str, list[str]]:
    """Return class-specific loot names, or theme names if no class/invalid."""
    if class_ in VALID_CLASSES:
        return CLASS_LOOT_OVERRIDES[class_]
    return theme_names
```

- [ ] **Step 4.4: Run tests to verify they pass**

```bash
python3 -m pytest tests/test_classes.py -v
```
Expected: all PASS

- [ ] **Step 4.5: Commit**

```bash
git add lootqdm/classes.py tests/test_classes.py
git commit -m "feat: class system with loot overrides and boss names"
```

---

### Task 5: Boss battles — wire class into LootTable + boss events

**Files:**
- Modify: `lootqdm/events.py` — `LootTable` accepts optional `class_` param
- Modify: `lootqdm/ui.py` — `GameUI`/`RichUI`/`PlainUI` accept `class_` param; boss logic in `epoch_end`
- Create: `tests/test_boss.py`

**Boss logic summary:**
- On `epoch_end`, check if current epoch is a milestone (1st, halfway, final)
- If milestone: spawn a boss (add to feed, store in `self._boss_active`)
- Next `epoch_end`: if any metric improved ≥5% vs previous epoch → boss defeated (+200 XP, epic feed entry); else boss escapes (no XP)
- Boss detection: for metrics where lower=better (contains "loss"), improvement = decrease ≥5%; for others, improvement = increase ≥5%

- [ ] **Step 5.1: Write failing tests**

Create `tests/test_boss.py`:

```python
"""Tests for boss battle events and class-flavored LootTable."""
from __future__ import annotations


class TestLootTableWithClass:
    def test_default_loot_uses_theme_names(self):
        from lootqdm.events import LootTable
        from lootqdm.themes import get_theme
        from random import Random
        table = LootTable("dark_dungeon")
        theme = get_theme("dark_dungeon")
        all_theme_names = [n for lst in theme.loot_names.values() for n in lst]
        for _ in range(20):
            drop = table.roll(Random(42))
            assert drop.name in all_theme_names

    def test_wizard_class_loot_uses_overrides(self):
        from lootqdm.events import LootTable
        from lootqdm.classes import CLASS_LOOT_OVERRIDES
        from random import Random
        table = LootTable("dark_dungeon", class_="wizard")
        all_wizard = [n for lst in CLASS_LOOT_OVERRIDES["wizard"].values() for n in lst]
        rng = Random(1)
        found = False
        for _ in range(100):
            drop = table.roll(rng)
            if drop.name in all_wizard:
                found = True
                break
        assert found

    def test_invalid_class_falls_back_to_theme(self):
        from lootqdm.events import LootTable
        from lootqdm.themes import get_theme
        from random import Random
        table = LootTable("dark_dungeon", class_="paladin")
        theme = get_theme("dark_dungeon")
        all_theme_names = [n for lst in theme.loot_names.values() for n in lst]
        for _ in range(20):
            drop = table.roll(Random(42))
            assert drop.name in all_theme_names


class TestBossSpawn:
    def test_boss_spawns_on_first_epoch(self):
        import lootqdm
        with lootqdm.GameUI(
            total_steps=10, total_epochs=3, _force_plain=True, class_="warrior"
        ) as ui:
            for _ in range(10):
                ui.step()
            ui.epoch_end({"acc": 0.5})
        boss_msgs = [e["message"] for e in ui._feed if "BOSS" in e.get("message", "")]
        assert len(boss_msgs) >= 1, f"No boss event in feed: {ui._feed}"

    def test_boss_defeated_when_metric_improves_5pct(self):
        import lootqdm
        with lootqdm.GameUI(
            total_steps=20, total_epochs=4, _force_plain=True, class_="wizard"
        ) as ui:
            for _ in range(10):
                ui.step()
            ui.epoch_end({"acc": 0.50})  # epoch 1 — boss spawns
            for _ in range(10):
                ui.step()
            ui.epoch_end({"acc": 0.60})  # epoch 2 — 20% improvement → boss defeated
        defeated = [e for e in ui._feed if "DEFEATED" in e.get("message", "")]
        assert len(defeated) >= 1, f"No defeat event: {ui._feed}"

    def test_boss_escapes_when_metric_does_not_improve(self):
        import lootqdm
        with lootqdm.GameUI(
            total_steps=20, total_epochs=4, _force_plain=True, class_="rogue"
        ) as ui:
            for _ in range(10):
                ui.step()
            ui.epoch_end({"acc": 0.50})  # epoch 1 — boss spawns
            for _ in range(10):
                ui.step()
            ui.epoch_end({"acc": 0.51})  # epoch 2 — only 2% → boss escapes
        escaped = [e for e in ui._feed if "escaped" in e.get("message", "").lower()]
        assert len(escaped) >= 1, f"No escape event: {ui._feed}"

    def test_boss_works_without_class(self):
        import lootqdm
        with lootqdm.GameUI(
            total_steps=10, total_epochs=1, _force_plain=True
        ) as ui:
            for _ in range(10):
                ui.step()
            ui.epoch_end({"loss": 0.5})
        # Should not crash; generic boss name used
        assert isinstance(ui._feed, list)
```

- [ ] **Step 5.2: Run tests to verify they fail**

```bash
python3 -m pytest tests/test_boss.py -v
```
Expected: `TypeError` (unexpected `class_` kwarg) or `FAILED`

- [ ] **Step 5.3: Modify `LootTable` in `events.py` to accept `class_`**

Replace the current `LootTable.__init__`:

```python
class LootTable:
    def __init__(self, theme_name: str, class_: str | None = None) -> None:
        from lootqdm.classes import get_loot_names  # noqa: PLC0415
        self._theme = get_theme(theme_name)
        self._loot_names = get_loot_names(class_, self._theme.loot_names)

    def roll(self, rng: Random, luck: float = 0.0) -> LootDrop:
        rarity = roll_rarity(rng, luck)
        name = rng.choice(self._loot_names[rarity])
        return LootDrop(name=name, rarity=rarity, xp=RARITY_XP[rarity])
```

- [ ] **Step 5.4: Add `class_` param and boss state to `PlainUI`**

In `PlainUI.__init__`, add:
```python
self._class = kwargs.get("class_")
self._boss_active: str | None = None
self._prev_epoch_metrics: dict[str, float] = {}
```

In `PlainUI.epoch_end`, add boss logic after `self._quest_tracker.check(...)`:

```python
# Boss resolution
if self._boss_active and metrics:
    defeated = self._check_boss_defeated(metrics)
    msg = f"BOSS DEFEATED: {self._boss_active}!" if defeated else f"Boss {self._boss_active} escaped..."
    self._feed.append({"message": msg, "rarity": "legendary" if defeated else None})
    self._boss_active = None
if metrics:
    self._prev_epoch_metrics.update(metrics)
# Boss spawn
milestone = self._boss_milestone()
if milestone:
    from lootqdm.classes import BOSS_NAMES  # noqa: PLC0415
    boss_name = BOSS_NAMES.get(self._class, BOSS_NAMES[None])[milestone]
    self._boss_active = boss_name
    self._feed.append({"message": f"BOSS: {boss_name} has appeared!", "rarity": "epic"})
```

Add these helper methods to `PlainUI`:

```python
def _boss_milestone(self) -> str | None:
    if self._current_epoch == 1:
        return "first"
    mid = self._total_epochs // 2
    if mid > 1 and self._current_epoch == mid:
        return "mid"
    if self._current_epoch == self._total_epochs:
        return "final"
    return None

def _check_boss_defeated(self, metrics: dict) -> bool:
    for k, v in metrics.items():
        prev = self._prev_epoch_metrics.get(k)
        if prev is None or prev == 0:
            continue
        is_loss = "loss" in k
        if is_loss:
            if (prev - v) / abs(prev) >= 0.05:
                return True
        else:
            if (v - prev) / abs(prev) >= 0.05:
                return True
    return False
```

- [ ] **Step 5.5: Add `class_` param and boss state to `RichUI`**

In `RichUI.__init__`, add `class_: str | None = None` param. Store `self._class = class_`. Update the `LootTable` line: `self._loot_table = LootTable(self._theme.name, class_=class_)`. Add boss state:

```python
self._boss_active: str | None = None
self._prev_epoch_metrics: dict[str, float] = {}
```

Add the same `_boss_milestone` and `_check_boss_defeated` methods to `RichUI`.

In `RichUI.epoch_end`, add the same boss logic as `PlainUI.epoch_end` (after quest check), but with `_add_feed` instead of `self._feed.append`:

```python
# Boss resolution
if self._boss_active and metrics:
    defeated = self._check_boss_defeated(metrics)
    if defeated:
        bonus = 200
        self._xp += bonus
        self._add_feed(f"\U0001f480 BOSS DEFEATED: {self._boss_active}! +{bonus} XP", rarity="legendary")
        self._achievements.unlock("boss_defeated", "Defeated a Boss!")
    else:
        self._add_feed(f"\u26a0 Boss {self._boss_active} escaped...", rarity=None)
    self._boss_active = None
if metrics:
    self._prev_epoch_metrics.update(metrics)
# Boss spawn
milestone = self._boss_milestone()
if milestone:
    from lootqdm.classes import BOSS_NAMES  # noqa: PLC0415
    boss_name = BOSS_NAMES.get(self._class, BOSS_NAMES[None])[milestone]
    self._boss_active = boss_name
    self._add_feed(f"\u2694 BOSS: {boss_name} has appeared!", rarity="epic")
```

- [ ] **Step 5.6: Add `class_` param to `GameUI`**

In `GameUI.__init__`, add `class_: str | None = None` param. Pass `class_=class_` to both `PlainUI(...)` and `RichUI(...)`.

Current `PlainUI` init: `PlainUI(total_steps=total_steps, total_epochs=total_epochs)` — update to `PlainUI(total_steps=total_steps, total_epochs=total_epochs, class_=class_)`. But `PlainUI.__init__` uses `**kwargs`, so this works.

Current `RichUI` init: add `class_=class_` to the `RichUI(...)` constructor call.

- [ ] **Step 5.7: Run all tests**

```bash
python3 -m pytest tests/ -q
```
Expected: all PASS (77+ original + new tests for GPU, classes, boss)

- [ ] **Step 5.8: Commit**

```bash
git add lootqdm/events.py lootqdm/ui.py tests/test_boss.py
git commit -m "feat: class-flavored loot and boss battle events at milestone epochs"
```

---

## Chunk 4: pyproject.toml + GitHub Push

### Task 6: Update metadata, bump version, push

**Files:**
- Modify: `pyproject.toml`
- Modify: `lootqdm/__init__.py`

- [ ] **Step 6.1: Update `pyproject.toml`**

Make three changes:
1. `version = "0.2.0"`
2. URLs section:
```toml
[project.urls]
Homepage = "https://github.com/Haadesx/lootqdm"
Repository = "https://github.com/Haadesx/lootqdm"
```
3. Add `gpu` optional dep:
```toml
[project.optional-dependencies]
torch = ["torch"]
keras = ["tensorflow"]
gpu = ["pynvml"]
dev = ["pytest>=7.0", "pytest-cov"]
```

- [ ] **Step 6.2: Bump version in `lootqdm/__init__.py`**

Change `__version__ = "0.1.0"` → `__version__ = "0.2.0"`

- [ ] **Step 6.3: Run full suite one final time**

```bash
python3 -m pytest tests/ -q
```
Expected: all PASS

- [ ] **Step 6.4: Commit**

```bash
git add pyproject.toml lootqdm/__init__.py
git commit -m "chore: bump version to 0.2.0, fix GitHub URLs, add gpu optional dep"
```

- [ ] **Step 6.5: Update remote and push**

```bash
git remote set-url origin https://github.com/Haadesx/lootqdm.git
git push -u origin main
```

- [ ] **Step 6.6: Rebuild dist**

```bash
cd /Volumes/Auxilary/Side_Projects/Lootqdm
python3 -m build
```
Expected: `dist/lootqdm-0.2.0.tar.gz` and `dist/lootqdm-0.2.0-py3-none-any.whl` created

- [ ] **Step 6.7: PyPI upload — MANUAL STEP (skip in automated session)**

The user must run this interactively:
```bash
python3 -m twine upload dist/lootqdm-0.2.0*
```
Enter PyPI API token when prompted.

---

## Execution Order

1. Task 1 (box_chars) → Task 2 (GamePanel) — sequential dependency
2. Task 3 (GPU) — independent, can run after Task 1
3. Task 4 (classes.py) → Task 5 (boss battles) — sequential dependency
4. Task 6 (metadata) — runs last

Tasks 2, 3, and 4 can be worked in parallel after Task 1 completes.
