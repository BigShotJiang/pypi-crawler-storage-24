#!/usr/bin/env python3
"""Keras callback example with lootqdm.

Requires: pip install tensorflow
If deps are missing, falls back to a simulated loop.
"""

import math
import time

try:
    import numpy as np
    import tensorflow as tf
    from tensorflow import keras

    HAS_KERAS = True
except ImportError:
    HAS_KERAS = False

from lootqdm import GameUI
from lootqdm.integrations.keras import LootqdmKerasCallback


def run_real_training() -> None:
    """Train a tiny Keras model on random data."""
    x = np.random.randn(1000, 784).astype("float32")
    y = np.random.randint(0, 10, (1000,))

    model = keras.Sequential([
        keras.layers.Dense(128, activation="relu", input_shape=(784,)),
        keras.layers.Dense(10, activation="softmax"),
    ])
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])

    epochs = 5
    batch_size = 32
    steps_per_epoch = len(x) // batch_size
    total_steps = steps_per_epoch * epochs

    with GameUI(total_steps=total_steps, total_epochs=epochs, theme="cozy_pastel", run_name="keras_demo") as ui:
        ui.quest("Low Loss", "loss", 0.5, "<=")
        model.fit(x, y, epochs=epochs, batch_size=batch_size, callbacks=[LootqdmKerasCallback(ui)], verbose=0)


def run_simulated() -> None:
    """Simulated training when Keras is not installed."""
    total = 400
    epochs = 5
    steps_per = total // epochs

    with GameUI(total_steps=total, total_epochs=epochs, theme="cozy_pastel", run_name="keras_sim") as ui:
        ui.quest("Low Loss", "loss", 0.5, "<=")

        for epoch in range(epochs):
            for step in range(steps_per):
                g = epoch * steps_per + step
                loss = 2.5 * math.exp(-g / 60)
                acc = min(0.98, 0.3 + g / (total * 1.5))
                ui.step({"loss": loss, "accuracy": acc})
                time.sleep(0.01)
            ui.epoch_end({"val_loss": loss, "val_accuracy": acc})


if __name__ == "__main__":
    if HAS_KERAS:
        run_real_training()
    else:
        print("TensorFlow/Keras not found -- running simulated loop.")
        run_simulated()
