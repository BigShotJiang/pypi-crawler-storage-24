#!/usr/bin/env python3
"""PyTorch MNIST example with lootqdm.

Requires: pip install torch torchvision
If deps are missing, falls back to a simulated loop.
"""

import math
import time

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import DataLoader, TensorDataset

    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False

from lootqdm import GameUI
from lootqdm.integrations.torch import LootqdmCallback


def run_real_training() -> None:
    """Train a tiny model on random data (structure mirrors real MNIST)."""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    x = torch.randn(1000, 1, 28, 28)
    y = torch.randint(0, 10, (1000,))
    dataset = TensorDataset(x, y)
    loader = DataLoader(dataset, batch_size=32, shuffle=True)

    model = nn.Sequential(
        nn.Flatten(),
        nn.Linear(784, 128),
        nn.ReLU(),
        nn.Linear(128, 10),
    ).to(device)

    optimizer = optim.Adam(model.parameters(), lr=1e-3)
    criterion = nn.CrossEntropyLoss()

    epochs = 5
    total_steps = len(loader) * epochs

    with GameUI(total_steps=total_steps, total_epochs=epochs, theme="neon_cyber", run_name="mnist") as ui:
        ui.quest("Low Loss", "loss", 0.5, "<=")
        cb = LootqdmCallback(ui)

        for epoch in range(epochs):
            model.train()
            for batch_x, batch_y in loader:
                batch_x, batch_y = batch_x.to(device), batch_y.to(device)
                optimizer.zero_grad()
                out = model(batch_x)
                loss = criterion(out, batch_y)
                loss.backward()
                optimizer.step()

                acc = (out.argmax(1) == batch_y).float().mean().item()
                cb.on_batch_end(loss=loss.item(), acc=acc, lr=optimizer.param_groups[0]["lr"])

            cb.on_epoch_end(val_loss=loss.item(), val_acc=acc)


def run_simulated() -> None:
    """Simulated training when PyTorch is not installed."""
    total = 500
    epochs = 5
    steps_per = total // epochs

    with GameUI(total_steps=total, total_epochs=epochs, theme="neon_cyber", run_name="mnist_sim") as ui:
        ui.quest("Low Loss", "loss", 0.1, "<=")

        for epoch in range(epochs):
            for step in range(steps_per):
                g = epoch * steps_per + step
                loss = 2.0 * math.exp(-g / 80)
                acc = min(0.99, 0.5 + g / (total * 1.2))
                ui.step({"loss": loss, "acc": acc, "lr": 1e-3})
                time.sleep(0.01)
            ui.epoch_end({"val_loss": loss, "val_acc": acc})


if __name__ == "__main__":
    if HAS_TORCH:
        run_real_training()
    else:
        print("PyTorch not found -- running simulated loop.")
        run_simulated()
