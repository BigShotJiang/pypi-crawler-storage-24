#!/usr/bin/env python3
"""Basic lootqdm example -- a simple training-like loop."""

import math
import time
from lootqdm import GameUI

TOTAL_STEPS = 500
EPOCHS = 5
STEPS_PER_EPOCH = TOTAL_STEPS // EPOCHS

with GameUI(
    total_steps=TOTAL_STEPS,
    total_epochs=EPOCHS,
    theme="dark_dungeon",
    run_name="basic_demo",
) as ui:
    ui.quest("Low Loss", "loss", 0.05, "<=")
    ui.quest("High Accuracy", "acc", 0.95, ">=")

    for epoch in range(EPOCHS):
        for step in range(STEPS_PER_EPOCH):
            global_step = epoch * STEPS_PER_EPOCH + step
            loss = 1.0 * math.exp(-global_step / 100)
            acc = 1.0 - loss * 0.8
            lr = 1e-3 * (0.95 ** epoch)

            ui.step({"loss": loss, "acc": acc, "lr": lr})
            time.sleep(0.01)

        ui.epoch_end({"loss": loss, "acc": acc, "lr": lr})

print("Training complete!")
