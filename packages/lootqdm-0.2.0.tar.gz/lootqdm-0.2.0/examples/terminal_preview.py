#!/usr/bin/env python3
"""
Render a static snapshot of all 4 lootqdm themes to the terminal.
Uses force_terminal=True so colours work even when piped.
"""

from rich.box import ROUNDED
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from lootqdm.themes import get_theme, list_themes
from lootqdm.mappers import StatMapper
from lootqdm.utils import sparkline, format_time, format_number

WIDTH = 104

# ── Shared simulated state ────────────────────────────────────────────────────
STEP, TOTAL_STEPS = 128, 500
EPOCH, TOTAL_EPOCHS = 3, 10
XP, LEVEL = 2340, 7
ELAPSED = 754  # seconds
LOSS_HISTORY = [1.2, 0.9, 0.7, 0.5, 0.38, 0.28, 0.18, 0.12, 0.07, 0.04, 0.023]
LOSS, ACC, LR = 0.0234, 0.942, 1e-4
MAPPER = StatMapper()

LEVEL_BASE = 100
LEVEL_EXP  = 1.5

def xp_for_level(n: int) -> int:
    return int(LEVEL_BASE * n ** LEVEL_EXP)


def make_bar(frac: float, filled: str, empty: str, w: int = 12) -> str:
    n = int(max(0.0, min(1.0, frac)) * w)
    return filled * n + empty * (w - n)


def render_theme(theme_name: str) -> Panel:
    t = get_theme(theme_name)
    fc, ec = t.bar_chars

    def bar(frac, w=12): return make_bar(frac, fc, ec, w)
    def icon(key):
        ev = t.icons.get("events", {})
        return t.icons.get(key, ev.get(key, ""))

    epoch_frac = EPOCH / TOTAL_EPOCHS
    batch_frac = STEP / TOTAL_STEPS
    rate       = STEP / max(1, ELAPSED)
    remaining  = (TOTAL_STEPS - STEP) / max(0.001, rate)
    xp_needed  = xp_for_level(LEVEL + 1)
    xp_floor   = xp_for_level(LEVEL)
    xp_frac    = (XP - xp_floor) / max(1, xp_needed - xp_floor)

    # ── PROGRESS ──
    prog = Text()
    prog.append("\n  PROGRESS\n\n", style=t.palette["accent"])
    prog.append(f"  Epoch  {EPOCH}/{TOTAL_EPOCHS}  ", style=t.palette["soft"])
    prog.append(bar(epoch_frac), style=t.palette["accent"])
    prog.append(f"  {int(epoch_frac*100)}%\n", style=t.palette["dim"])
    prog.append(f"  Batch {STEP}/{TOTAL_STEPS} ", style=t.palette["soft"])
    prog.append(bar(batch_frac), style=t.palette["accent"])
    prog.append(f"  {int(batch_frac*100)}%\n", style=t.palette["dim"])
    prog.append(f"  ETA {format_time(remaining)}", style=t.palette["dim"])
    prog.append(f"  {t.separators[0]}  {int(rate)} it/s\n\n", style=t.palette["dim"])
    prog.append(f"  {icon('xp')} ", style=t.palette["accent"])
    prog.append(bar(xp_frac, 10), style=t.palette["accent"])
    prog.append(f"  {XP}/{xp_needed}  LV {LEVEL}\n", style=t.palette["soft"])

    # ── STATS ──
    stats = Text()
    stats.append("\n  STATS\n\n", style=t.palette["accent"])
    for key, val in [("loss", LOSS), ("acc", ACC), ("lr", LR)]:
        ico, name = MAPPER.format(key, val)
        stats.append(f"  {ico} ", style=t.palette["accent"])
        stats.append(f"{name:6s}", style=t.palette["soft"])
        stats.append(f"({key})", style=t.palette["dim"])
        stats.append(" " * max(1, 14 - len(key)))
        stats.append(f"{format_number(val)}\n", style=t.palette["soft"])
    spark = sparkline(LOSS_HISTORY, width=12)
    stats.append(f"  \U0001f4c9 loss  ", style=t.palette["accent"])
    stats.append(f"{spark}\n", style=t.palette["dim"])

    # ── LOOT & EVENTS ──
    feed_data = [
        (t.icons["loot"]["legendary"], "LEGENDARY Cursed Crown! +500 XP", "legendary"),
        (t.icons["loot"]["rare"],      "Rare Void Shard  +50 XP",          "rare"),
        (t.icons["events"]["crit"],    "CRITICAL BATCH!  +20 XP",           None),
        (t.icons["loot"]["common"],    "Common Rusty Coin  +5 XP",          "common"),
    ]
    loot = Text()
    loot.append("\n  LOOT & EVENTS\n\n", style=t.palette["accent"])
    for ico, msg, rarity in feed_data:
        style = t.rarity_styles.get(rarity, t.palette["soft"]) if rarity else t.palette["soft"]
        loot.append(f"  {ico}  {msg}\n", style=style)

    # ── QUESTS ──
    quest_text = Text()
    quest_text.append("\n  QUESTS\n\n", style=t.palette["accent"])
    for label, prog_frac in [("acc \u2265 0.95", 0.94), ("loss \u2264 0.01", 0.42)]:
        quest_text.append(f"  {icon('quest')} {label}  ", style=t.palette["soft"])
        quest_text.append(bar(prog_frac, 5), style=t.palette["accent"])
        quest_text.append(f"  {int(prog_frac*100)}%\n", style=t.palette["dim"])
    for ach in ["First Epoch Complete", "New best acc"]:
        quest_text.append(f"  \u2705 {ach}  \u2713\n",
                          style=t.rarity_styles.get("uncommon", t.palette["soft"]))

    # ── 2x2 grid ──
    grid = Table(
        show_header=False, show_edge=False, show_lines=True,
        pad_edge=False, expand=True, border_style=t.palette["dim"],
    )
    grid.add_column(ratio=1)
    grid.add_column(ratio=1)
    grid.add_row(prog, stats)
    grid.add_row(loot, quest_text)

    # ── Header + Panel ──
    header = Text()
    header.append("  mnist_run", style=t.palette["soft"])
    header.append(f" {t.separators[0]} ", style=t.palette["dim"])
    header.append(t.name, style=t.palette["dim"])
    header.append("                              ")
    header.append(f"\u2699  {format_time(ELAPSED)}", style=t.palette["dim"])

    title = Text()
    title.append(f" {icon('level')} LOOTQDM", style=t.palette["title"])

    from rich.console import Group as RichGroup
    return Panel(
        RichGroup(header, grid),
        title=title,
        title_align="left",
        box=t.border,
        border_style=t.palette["dim"],
        expand=True,
    )


if __name__ == "__main__":
    con = Console(width=WIDTH, force_terminal=True)

    con.print()
    con.print(Rule("[bold bright_white] lootqdm — theme showcase [/bold bright_white]"))

    for theme_name in list_themes():
        con.print()
        con.print(render_theme(theme_name))

    con.print()
    con.rule("[dim]pip install lootqdm[/dim]")
    con.print()
