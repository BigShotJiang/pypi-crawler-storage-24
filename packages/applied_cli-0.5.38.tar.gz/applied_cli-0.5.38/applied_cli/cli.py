"""Applied Labs CLI entrypoint."""

import asyncio

import httpx
import typer

from applied_cli import tools
from applied_cli.client import AppliedClient
from applied_cli.credentials import (
    clear_credentials,
    load_credentials,
    save_credentials,
)

app = typer.Typer(
    name="applied",
    help="Applied Labs CLI - manage your AI agents and conversations.",
    no_args_is_help=True,
)

DEFAULT_BASE_URL = "https://api.appliedlabs.ai"
DEFAULT_CLIENT_URL = "https://appliedlabs.ai"


def get_client() -> AppliedClient:
    """Get an authenticated client from stored credentials."""
    creds = load_credentials()
    if not creds or not creds.get("api_token"):
        typer.echo("Not logged in. Run 'applied login' first.", err=True)
        raise typer.Exit(1)

    return AppliedClient(
        token=creds["api_token"],
        shop_id=creds.get("shop_id"),
        base_url=creds.get("base_url", DEFAULT_BASE_URL),
    )


# -----------------------------------------------------------------------------
# Auth commands
# -----------------------------------------------------------------------------


@app.command()
def login(
    base_url: str = typer.Option(DEFAULT_BASE_URL, "--api", help="API base URL"),
    client_url: str = typer.Option(
        DEFAULT_CLIENT_URL, "--client", help="Client URL for auth page"
    ),
) -> None:
    """Login using device authorization flow."""

    async def do_login() -> None:
        # Start device flow
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(f"{base_url}/v1/cli/device/start/")
            resp.raise_for_status()
            data = resp.json()

        device_code = data["device_code"]
        user_code = data["user_code"]
        auth_url = f"{client_url}/cli/authorize?code={user_code}"

        typer.echo(f"\nOpen this URL to authenticate:\n\n  {auth_url}\n")
        typer.echo(f"Your code: {user_code}\n")
        typer.echo("Waiting for approval...", nl=False)

        # Poll for token
        max_attempts = 60
        interval = 2

        async with httpx.AsyncClient(timeout=30.0) as client:
            for _ in range(max_attempts):
                await asyncio.sleep(interval)
                typer.echo(".", nl=False)

                resp = await client.post(
                    f"{base_url}/v1/cli/device/token/",
                    json={"device_code": device_code},
                )

                if resp.status_code == 200:
                    token_data = resp.json()
                    api_token = token_data.get("access_token")
                    shop_id = token_data.get("shop_id")

                    if api_token:
                        save_credentials(
                            {
                                "api_token": api_token,
                                "shop_id": shop_id,
                                "base_url": base_url,
                            }
                        )
                        typer.echo("\n\nLogged in successfully!")
                        return

                elif resp.status_code == 400:
                    error = resp.json().get("error")
                    if error == "authorization_pending":
                        continue
                    elif error == "access_denied":
                        typer.echo("\n\nAuthorization denied.", err=True)
                        raise typer.Exit(1)
                    elif error == "expired_token":
                        typer.echo(
                            "\n\nDevice code expired. Please try again.", err=True
                        )
                        raise typer.Exit(1)

        typer.echo("\n\nTimeout waiting for authorization.", err=True)
        raise typer.Exit(1)

    asyncio.run(do_login())


@app.command()
def logout() -> None:
    """Clear stored credentials."""
    clear_credentials()
    typer.echo("Logged out.")


@app.command()
def whoami() -> None:
    """Show current authentication status."""
    creds = load_credentials()
    if not creds or not creds.get("api_token"):
        typer.echo("Not logged in.")
        raise typer.Exit(1)

    token = creds["api_token"]
    masked = f"{token[:8]}...{token[-4:]}" if len(token) > 12 else "***"
    typer.echo(f"API Token: {masked}")
    typer.echo(f"Base URL: {creds.get('base_url', DEFAULT_BASE_URL)}")
    if creds.get("shop_id"):
        typer.echo(f"Shop ID: {creds['shop_id']}")


# -----------------------------------------------------------------------------
# Agent commands
# -----------------------------------------------------------------------------


@app.command()
def agents(
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List all AI agents."""
    client = get_client()
    result = asyncio.run(tools.agent_list(client, output_format=format))
    typer.echo(result)


# -----------------------------------------------------------------------------
# Taxonomy commands
# -----------------------------------------------------------------------------


@app.command()
def taxonomy(
    type: str = typer.Option(
        "all", "--type", "-t", help="Type: all, topics, intents, flags"
    ),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List conversation taxonomy (topics, intents, flags)."""
    client = get_client()
    result = asyncio.run(
        tools.taxonomy_list(client, taxonomy_type=type, output_format=format)
    )
    typer.echo(result)


@app.command()
def analytics(
    group_by: str = typer.Option(
        ...,
        "--group-by",
        "-g",
        help=(
            "Comma-separated dimensions: label_name, sublabel_name, agent_name, "
            "resolution, sentiment, type, user_id, label_id, sublabel_id, agent_id"
        ),
    ),
    metrics: str = typer.Option(
        "count",
        "--metrics",
        "-m",
        help="Comma-separated metrics: count, avg_score, avg_ttr, resolution_rate",
    ),
    filter: list[str] = typer.Option(
        [],
        "--filter",
        help='Filter as "field=value". Repeatable.',
    ),
    start: str = typer.Option(None, "--start", help="Start date, e.g. 2025-01-01"),
    end: str = typer.Option(None, "--end", help="End date, e.g. 2025-01-31"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Run a server-side analytics query grouped by dimensions."""
    client = get_client()
    result = asyncio.run(
        tools.analytics_query(
            client,
            group_by=[g.strip() for g in group_by.split(",") if g.strip()],
            metrics=[m.strip() for m in metrics.split(",") if m.strip()],
            filters=list(filter) or None,
            start=start,
            end=end,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command()
def metrics(
    metric_name: str = typer.Option(
        ...,
        "--metric-name",
        "-n",
        help="Metric name, e.g. customer.cancel, customer.save",
    ),
    group_by: str = typer.Option(
        "",
        "--group-by",
        "-g",
        help="Property key to group by, e.g. reason",
    ),
    period: str = typer.Option(
        "",
        "--period",
        "-p",
        help="Trending period: day, week, month",
    ),
    filter: list[str] = typer.Option(
        [],
        "--filter",
        help='Property filter as "key=value". Repeatable.',
    ),
    start: str = typer.Option(None, "--start", help="Start date, e.g. 2025-01-01"),
    end: str = typer.Option(None, "--end", help="End date, e.g. 2025-01-31"),
    object_type: str = typer.Option(
        "conversation", "--object-type", help="Object type"
    ),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Query metric events with property grouping and trending."""
    client = get_client()
    result = asyncio.run(
        tools.analytics_metrics(
            client,
            metric_name=metric_name,
            group_by=group_by or None,
            period=period or None,
            filters=list(filter) or None,
            start=start,
            end=end,
            object_type=object_type,
            output_format=format,
        )
    )
    typer.echo(result)


# -----------------------------------------------------------------------------
# Conversation commands
# -----------------------------------------------------------------------------


@app.command()
def conversations(
    resolution: str = typer.Option(
        None, "--resolution", "-r", help="Filter by resolution"
    ),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Query conversations."""
    client = get_client()
    filters = {}
    if resolution:
        filters["resolution"] = resolution

    result = asyncio.run(
        tools.conversation_query(
            client, filters=filters, limit=limit, output_format=format
        )
    )
    typer.echo(result)


@app.command()
def conversation(
    id: str = typer.Argument(..., help="Conversation ID"),
    messages: bool = typer.Option(False, "--messages", "-m", help="Include messages"),
    message_limit: int = typer.Option(50, "--message-limit", help="Max messages"),
) -> None:
    """Get a single conversation by ID."""
    client = get_client()
    result = asyncio.run(
        tools.conversation_get(
            client, id, include_messages=messages, message_limit=message_limit
        )
    )
    typer.echo(result)


# -----------------------------------------------------------------------------
# Ticket commands
# -----------------------------------------------------------------------------


@app.command()
def tickets(
    status: str = typer.Option(None, "--status", "-s", help="Filter by status"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Query tickets."""
    client = get_client()
    filters = {}
    if status:
        filters["status"] = status

    result = asyncio.run(
        tools.ticket_query(client, filters=filters, limit=limit, output_format=format)
    )
    typer.echo(result)


# -----------------------------------------------------------------------------
# Knowledge commands
# -----------------------------------------------------------------------------


@app.command()
def knowledge(
    type: str = typer.Option(
        None, "--type", "-t", help="Filter by type: qa, context, escalate, exact"
    ),
    search: str = typer.Option(None, "--search", "-s", help="Search query"),
    limit: int = typer.Option(100, "--limit", "-l", help="Results per page"),
    all_pages: bool = typer.Option(
        True, "--all/--no-all", help="Fetch all pages (default: True)"
    ),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List knowledge base items."""
    client = get_client()
    result = asyncio.run(
        tools.knowledge_list(
            client,
            kb_type=type,
            search=search,
            limit=limit,
            fetch_all=all_pages,
            output_format=format,
        )
    )
    typer.echo(result)


# -----------------------------------------------------------------------------
# Flow commands
# -----------------------------------------------------------------------------


@app.command()
def flows(
    agent_id: str = typer.Option(None, "--agent", "-a", help="Filter by agent ID"),
    status: str = typer.Option(
        None, "--status", "-s", help="Filter by status: Active, Draft, Archived"
    ),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List flows."""
    client = get_client()
    result = asyncio.run(
        tools.flow_list(client, agent_id=agent_id, status=status, output_format=format)
    )
    typer.echo(result)


@app.command()
def flow(
    id: str = typer.Argument(..., help="Flow ID"),
    format: str = typer.Option(
        "summary", "--format", "-f", help="Output format: summary, full, or json"
    ),
) -> None:
    """Get a single flow with its graph (nodes and edges)."""
    client = get_client()
    result = asyncio.run(tools.flow_get(client, id, output_format=format))
    typer.echo(result)


def main() -> None:
    """CLI entrypoint."""
    app()


if __name__ == "__main__":
    main()
