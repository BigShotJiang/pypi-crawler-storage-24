# Applied Labs CLI

CLI and client library for Applied Labs AI support agents.

## Installation

```bash
pip install applied-cli
```

## CLI Usage

```bash
# Authenticate
applied login

# List agents
applied agents
applied agents --format json

# Query conversations
applied conversations --resolution escalated --limit 10
applied conversation <id> --messages

# Query tickets
applied tickets --status open

# Knowledge base
applied knowledge --type qa --search "refund"

# Taxonomy
applied taxonomy --type topics
applied taxonomy-counts --start 2026-03-01 --end 2026-03-18 --format csv
```

## Library Usage

```python
from applied_cli import AppliedClient, tools

# Create client
client = AppliedClient(token="al_xxx")

# Use tools
agents = await tools.agent_list(client, output_format="csv")
conversations = await tools.conversation_query(
    client,
    filters={"resolution": "escalated"},
    fields=["id", "title", "contact.email"],
    limit=20,
)
```

## Tools

| Tool | Description |
|------|-------------|
| `agent_list` | List all AI agents |
| `conversation_get` | Get single conversation with messages |
| `conversation_query` | Search/filter conversations |
| `ticket_query` | Search/filter tickets |
| `knowledge_list` | List knowledge base items |
| `taxonomy_list` | List topics, intents, and flags |
| `taxonomy_counts` | Aggregate conversation counts by topic and intent |

## Examples

```python
# Find escalated conversations
await tools.conversation_query(
    client,
    filters={"resolution": "escalated"},
    fields=["id", "title", "contact.email"],
    output_format="csv"
)

# Get conversation with transcript
await tools.conversation_get(
    client,
    conversation_id="abc-123",
    include_messages=True,
    message_limit=50
)

# Search knowledge base
await tools.knowledge_list(
    client,
    kb_type="qa",
    search="refund policy",
    output_format="json"
)
```

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Lint
ruff check --fix .
ruff format .
```

## License

MIT
