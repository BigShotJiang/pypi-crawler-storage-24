# Changelog

## [Unreleased]

## [0.2.0] - 2026-03-17

### Added

- Add `gwframe select` command to keep only specified channels

### Changed

- Renamed `t0` parameter/attribute to `start` across `TimeSeries`, `FrameInfo`,
  and related APIs
- Renamed `channel` parameter to `channels` in `read()` and `read_bytes()`

## [0.1.2] - 2025-11-18

### Added

- Allow writing frames as bytes

## [0.1.1] - 2025-11-06

### Fixed

- Fix issue with wheels with 'dirty' tags being generated randomly in CI jobs
  * Prevented a subset of wheels from being published
  * No functional API change

## [0.1.0] - 2025-11-06

- Initial release

[unreleased]: https://git.ligo.org/olivia.godwin/gwframe/-/compare/0.2.0...main
[0.2.0]: https://git.ligo.org/olivia.godwin/gwframe/-/compare/0.1.2...0.2.0
[0.1.2]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.1.2
[0.1.1]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.1.1
[0.1.0]: https://git.ligo.org/olivia.godwin/gwframe/-/tags/0.1.0
