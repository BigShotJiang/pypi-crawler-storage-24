"""Test suite for gwframe."""
