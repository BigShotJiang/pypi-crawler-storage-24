from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from evalgate_sdk.cli import get_app

app = get_app()
runner = CliRunner()


def _write_run_artifact(path: Path, *, run_id: str, results: list[dict[str, object]], pass_rate: float | None = None) -> None:
    total = len(results)
    passed = sum(1 for result in results if result.get("passed") is True)
    data = {
        "runId": run_id,
        "summary": {
            "total": total,
            "passed": passed,
            "failed": total - passed,
            "passRate": pass_rate if pass_rate is not None else (passed / total if total else 0.0),
            "pass_rate": (pass_rate * 100.0) if pass_rate is not None else ((passed / total) * 100.0 if total else 0.0),
        },
        "results": results,
    }
    path.write_text(json.dumps(data), encoding="utf-8")


class TestGoldenCommands:
    def test_cluster_command_outputs_json(self, tmp_path: Path) -> None:
        run_path = tmp_path / "run.json"
        _write_run_artifact(
            run_path,
            run_id="run-cluster",
            results=[
                {
                    "specId": "case-1",
                    "testName": "math-a",
                    "filePath": "evals/math.py",
                    "input": "solve 1+1",
                    "expected": "2",
                    "actual": "3",
                    "passed": False,
                    "result": {"status": "failed", "score": 0.1, "duration": 12, "error": "wrong answer"},
                },
                {
                    "specId": "case-2",
                    "testName": "math-b",
                    "filePath": "evals/math.py",
                    "input": "solve 2+2",
                    "expected": "4",
                    "actual": "5",
                    "passed": False,
                    "result": {"status": "failed", "score": 0.2, "duration": 15, "error": "wrong answer"},
                },
            ],
        )

        result = runner.invoke(app, ["cluster", "--run", str(run_path), "--format", "json"])

        assert result.exit_code == 0
        payload = json.loads(result.stdout)
        assert payload["runId"] == "run-cluster"
        assert payload["clusteredCases"] == 2
        assert len(payload["clusters"]) >= 1

    def test_label_command_accepts_cluster_report(self, tmp_path: Path) -> None:
        run_path = tmp_path / "run.json"
        cluster_path = tmp_path / "cluster.json"
        output_path = tmp_path / "labeled.jsonl"
        _write_run_artifact(
            run_path,
            run_id="run-label-cluster",
            results=[
                {
                    "specId": "case-1",
                    "testName": "qa-a",
                    "filePath": "evals/qa.py",
                    "input": "question a",
                    "expected": "answer a",
                    "actual": "wrong a",
                    "passed": False,
                    "result": {"status": "failed", "score": 0.0, "duration": 8, "error": "bad answer"},
                }
            ],
        )

        cluster_result = runner.invoke(app, ["cluster", "--run", str(run_path), "--output", str(cluster_path), "--format", "json"])
        assert cluster_result.exit_code == 0

        result = runner.invoke(app, ["label", "--cluster", str(cluster_path), "--output", str(output_path), "--format", "json"])

        assert result.exit_code == 0
        payload = json.loads(result.stdout)
        assert payload["total"] == 1
        labeled_rows = [json.loads(line) for line in output_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        assert labeled_rows[0]["caseId"] == "case-1"
        assert labeled_rows[0]["clusterId"].startswith("cluster-")
        assert labeled_rows[0]["label"] == "fail"

    def test_analyze_and_synthesize_commands(self, tmp_path: Path) -> None:
        dataset_path = tmp_path / "labeled.jsonl"
        synthetic_path = tmp_path / "synthetic.jsonl"
        dimensions_path = tmp_path / "dimensions.json"
        dataset_path.write_text(
            "\n".join(
                [
                    json.dumps(
                        {
                            "caseId": "case-1",
                            "input": "input one",
                            "expected": "expected one",
                            "actual": "actual one",
                            "label": "fail",
                            "failureMode": "hallucination",
                            "labeledAt": "2026-03-20T10:00:00+00:00",
                        }
                    ),
                    json.dumps(
                        {
                            "caseId": "case-2",
                            "input": "input two",
                            "expected": "expected two",
                            "actual": "actual two",
                            "label": "pass",
                            "failureMode": None,
                            "labeledAt": "2026-03-20T10:00:01+00:00",
                        }
                    ),
                ]
            )
            + "\n",
            encoding="utf-8",
        )
        dimensions_path.write_text(json.dumps({"dimensions": {"tone": ["formal", "brief"]}}), encoding="utf-8")

        analyze_result = runner.invoke(app, ["analyze", "--dataset", str(dataset_path), "--format", "json"])
        assert analyze_result.exit_code == 0
        analyze_payload = json.loads(analyze_result.stdout)
        assert analyze_payload["total"] == 2
        assert analyze_payload["failed"] == 1
        assert analyze_payload["failureModes"][0]["mode"] == "hallucination"

        synthesize_result = runner.invoke(
            app,
            [
                "synthesize",
                "--dataset",
                str(dataset_path),
                "--dimensions",
                str(dimensions_path),
                "--output",
                str(synthetic_path),
                "--format",
                "json",
            ],
        )
        assert synthesize_result.exit_code == 0
        synthesize_payload = json.loads(synthesize_result.stdout)
        assert synthesize_payload["generated"] == 2
        generated_rows = [json.loads(line) for line in synthetic_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        assert len(generated_rows) == 2
        assert all(row["synthetic"] is True for row in generated_rows)

    def test_replay_decision_and_auto_run_commands(self, tmp_path: Path) -> None:
        previous_path = tmp_path / "previous.json"
        current_path = tmp_path / "current.json"
        report_path = tmp_path / "auto-report.json"
        _write_run_artifact(
            previous_path,
            run_id="run-prev",
            pass_rate=0.5,
            results=[
                {"test_name": "spec-a", "test_id": "spec-a", "input": "a", "expected": "A", "actual": "A", "passed": True, "score": 1.0, "duration_ms": 10, "status": "passed"},
                {"test_name": "spec-b", "test_id": "spec-b", "input": "b", "expected": "B", "actual": "x", "passed": False, "score": 0.0, "duration_ms": 11, "status": "failed"},
            ],
        )
        _write_run_artifact(
            current_path,
            run_id="run-current",
            pass_rate=1.0,
            results=[
                {"test_name": "spec-a", "test_id": "spec-a", "input": "a", "expected": "A", "actual": "A", "passed": True, "score": 1.0, "duration_ms": 9, "status": "passed"},
                {"test_name": "spec-b", "test_id": "spec-b", "input": "b", "expected": "B", "actual": "B", "passed": True, "score": 1.0, "duration_ms": 9, "status": "passed"},
            ],
        )

        replay_result = runner.invoke(
            app,
            [
                "replay-decision",
                "--previous",
                str(previous_path),
                "--current",
                str(current_path),
                "--max-traces",
                "10",
                "--format",
                "json",
            ],
        )
        assert replay_result.exit_code == 0
        replay_payload = json.loads(replay_result.stdout)
        assert replay_payload["action"] == "keep"
        assert replay_payload["reason"] == "pass_rate_improved"

        auto_result = runner.invoke(
            app,
            [
                "auto",
                "run",
                "--objective",
                "reduce hallucination",
                "--baseline-run",
                str(previous_path),
                "--candidate-run",
                str(current_path),
                "--budget",
                "10",
                "--report",
                str(report_path),
                "--format",
                "json",
            ],
        )
        assert auto_result.exit_code == 0
        auto_payload = json.loads(auto_result.stdout)
        assert auto_payload["executionMode"] == "evaluate"
        assert auto_payload["iterationResult"]["decision"] == "keep"
        assert report_path.exists()
