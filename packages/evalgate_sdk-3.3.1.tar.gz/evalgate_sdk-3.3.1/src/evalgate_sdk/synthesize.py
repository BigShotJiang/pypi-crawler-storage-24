from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from evalgate_sdk.golden import DEFAULT_SYNTHETIC_DATASET_PATH, LabeledGoldenCase, SyntheticGoldenCase


@dataclass(slots=True)
class SynthesizeSummary:
    source_cases: int
    source_failures: int
    selected_failure_modes: list[str]
    dimension_names: list[str]
    dimension_combination_count: int
    generated: int
    mode_counts: list[dict[str, Any]]
    output_path: str
    cases: list[SyntheticGoldenCase]

    def to_dict(self) -> dict[str, Any]:
        return {
            "sourceCases": self.source_cases,
            "sourceFailures": self.source_failures,
            "selectedFailureModes": list(self.selected_failure_modes),
            "dimensionNames": list(self.dimension_names),
            "dimensionCombinationCount": self.dimension_combination_count,
            "generated": self.generated,
            "modeCounts": list(self.mode_counts),
            "outputPath": self.output_path,
            "cases": [item.to_dict() for item in self.cases],
        }


@dataclass(slots=True)
class DimensionMatrix:
    dimensions: dict[str, list[str]]


def parse_dimension_matrix(content: str) -> DimensionMatrix:
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError("Dimension matrix must be valid JSON") from exc
    if not isinstance(parsed, dict):
        raise ValueError("Dimension matrix must be a JSON object")
    raw_dimensions = parsed.get("dimensions") if isinstance(parsed.get("dimensions"), dict) else parsed
    if not isinstance(raw_dimensions, dict):
        raise ValueError("Dimension matrix must be a JSON object")
    dimensions: dict[str, list[str]] = {}
    for name, values in raw_dimensions.items():
        if not isinstance(values, list):
            raise ValueError(f"Dimension '{name}' must be an array of strings")
        normalized: list[str] = []
        for value in values:
            if not isinstance(value, str):
                raise ValueError(f"Dimension '{name}' must contain only strings")
            stripped = value.strip()
            if stripped:
                normalized.append(stripped)
        if not normalized:
            raise ValueError(f"Dimension '{name}' must contain at least one value")
        dimensions[str(name)] = normalized
    return DimensionMatrix(dimensions=dimensions)


def _cartesian_dimensions(dimensions: dict[str, list[str]]) -> list[dict[str, str]]:
    entries = list(dimensions.items())
    if not entries:
        return [{}]
    combinations: list[dict[str, str]] = [{}]
    for name, values in entries:
        next_items: list[dict[str, str]] = []
        for combination in combinations:
            for value in values:
                candidate = dict(combination)
                candidate[name] = value
                next_items.append(candidate)
        combinations = next_items
    return combinations


def _slugify(value: str) -> str:
    result = []
    last_dash = False
    for char in value.lower():
        if char.isalnum():
            result.append(char)
            last_dash = False
        elif not last_dash:
            result.append("-")
            last_dash = True
    return "".join(result).strip("-")[:48]


def _dimension_label(dimensions: dict[str, str]) -> str:
    pairs = [f"{name}={value}" for name, value in dimensions.items()]
    return ", ".join(pairs) if pairs else "base"


def _build_synthetic_case(
    prototype: LabeledGoldenCase,
    failure_mode: str,
    dimensions: dict[str, str],
    sequence: int,
) -> SyntheticGoldenCase:
    from datetime import datetime, timezone

    timestamp = datetime.now(timezone.utc).isoformat()
    dims_text = _dimension_label(dimensions)
    dimension_suffix = _slugify(dims_text) or "base"
    mode_suffix = _slugify(failure_mode) or "failure-mode"
    input_parts = [prototype.input.strip()]
    expected_parts = [prototype.expected.strip()]
    actual_parts = [f"Representative {failure_mode} failure draft.", prototype.actual.strip()]
    if dims_text != "base":
        input_parts.append(f"Synthetic dimensions: {dims_text}")
        expected_parts.append(f"Target dimensions: {dims_text}")
        actual_parts.insert(1, f"Scenario dimensions: {dims_text}")
    return SyntheticGoldenCase(
        case_id=f"synthetic-{mode_suffix}-{dimension_suffix}-{str(sequence + 1).zfill(3)}",
        input="\n".join(part for part in input_parts if part),
        expected="\n".join(part for part in expected_parts if part),
        actual="\n".join(part for part in actual_parts if part),
        label="fail",
        failure_mode=failure_mode,
        labeled_at=timestamp,
        synthetic=True,
        synthesized_at=timestamp,
        source_case_ids=[prototype.case_id],
        dimensions=dict(dimensions),
        cluster_id=prototype.cluster_id,
        cluster_label=prototype.cluster_label,
    )


def synthesize_labeled_dataset(
    rows: list[LabeledGoldenCase],
    *,
    dimensions: dict[str, list[str]] | None = None,
    count: int | None = None,
    failure_modes: list[str] | None = None,
    output_path: str = DEFAULT_SYNTHETIC_DATASET_PATH,
) -> SynthesizeSummary:
    failed_rows = [row for row in rows if row.label == "fail" and isinstance(row.failure_mode, str) and row.failure_mode.strip()]
    grouped: dict[str, list[LabeledGoldenCase]] = {}
    for row in failed_rows:
        key = row.failure_mode.strip()
        grouped.setdefault(key, []).append(row)

    requested_modes = [mode.strip() for mode in (failure_modes or []) if mode.strip()]
    if requested_modes:
        selected_failure_modes = [mode for mode in requested_modes if mode in grouped]
    else:
        selected_failure_modes = [
            mode for mode, _items in sorted(grouped.items(), key=lambda item: (-len(item[1]), item[0]))
        ]

    dimension_matrix = dimensions or {}
    combinations = _cartesian_dimensions(dimension_matrix)
    dimension_names = list(dimension_matrix.keys())

    plan: list[tuple[str, dict[str, str]]] = []
    for failure_mode in selected_failure_modes:
        for combo in combinations:
            plan.append((failure_mode, combo))

    if count is not None:
        target_count = max(0, count)
    elif plan:
        target_count = len(plan)
    else:
        target_count = len(selected_failure_modes)

    cases: list[SyntheticGoldenCase] = []
    if target_count > 0 and plan:
        for index in range(target_count):
            failure_mode, combo = plan[index % len(plan)]
            source_rows = grouped[failure_mode]
            prototype = source_rows[(index // max(1, len(plan))) % len(source_rows)]
            cases.append(_build_synthetic_case(prototype, failure_mode, combo, index))

    counts: dict[str, int] = {}
    for case in cases:
        mode = case.failure_mode or "unknown"
        counts[mode] = counts.get(mode, 0) + 1

    return SynthesizeSummary(
        source_cases=len(rows),
        source_failures=len(failed_rows),
        selected_failure_modes=selected_failure_modes,
        dimension_names=dimension_names,
        dimension_combination_count=len(combinations),
        generated=len(cases),
        mode_counts=[
            {"failureMode": mode, "count": count_value}
            for mode, count_value in sorted(counts.items(), key=lambda item: (-item[1], item[0]))
        ],
        output_path=output_path,
        cases=cases,
    )


def format_synthesize_human(summary: SynthesizeSummary) -> str:
    lines = [
        "Synthesize phase",
        f"Source cases: {summary.source_cases}",
        f"Source failures: {summary.source_failures}",
        f"Failure modes used: {len(summary.selected_failure_modes)}",
        f"Dimension combinations: {summary.dimension_combination_count}",
        f"Generated synthetic cases: {summary.generated}",
    ]
    if summary.selected_failure_modes:
        lines.append(f"Modes: {', '.join(summary.selected_failure_modes)}")
    if summary.dimension_names:
        lines.append(f"Dimensions: {', '.join(summary.dimension_names)}")
    if summary.mode_counts:
        mode_line = ", ".join(f"{item['failureMode']} ×{item['count']}" for item in summary.mode_counts)
        lines.append(f"Mode counts: {mode_line}")
    if summary.cases:
        samples = ", ".join(
            f"{item.case_id} ({_dimension_label(item.dimensions)})" for item in summary.cases[:3]
        )
        lines.append(f"Samples: {samples}")
    return "\n".join(lines)
