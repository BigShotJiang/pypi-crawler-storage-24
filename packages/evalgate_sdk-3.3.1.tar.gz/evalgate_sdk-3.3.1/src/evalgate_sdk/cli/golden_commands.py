from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from evalgate_sdk.auto import (
    DEFAULT_AUTO_HISTORY_PATH,
    DEFAULT_AUTO_REPORT_PATH,
    AutoOptions,
    build_auto_report,
    format_auto_human,
    run_auto_daemon,
    write_auto_report,
)
from evalgate_sdk.cluster import cluster_run_result, format_cluster_human
from evalgate_sdk.golden import (
    DEFAULT_LABELED_DATASET_PATH,
    DEFAULT_SYNTHETIC_DATASET_PATH,
    LabeledGoldenCase,
    analyze_labeled_dataset,
    format_analyze_human,
    normalize_run_artifact,
    parse_labeled_dataset,
    write_jsonl,
)
from evalgate_sdk.replay_decision import NormalizedBudgetConfig, evaluate_replay_outcome
from evalgate_sdk.synthesize import format_synthesize_human, parse_dimension_matrix, synthesize_labeled_dataset

console = Console()

auto_app = typer.Typer(help="Autonomous prompt-improvement workflow commands.", no_args_is_help=True)


def _read_json(file_path: str) -> dict[str, Any]:
    try:
        data = json.loads(Path(file_path).read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise typer.BadParameter(f"File not found: {file_path}") from exc
    except json.JSONDecodeError as exc:
        raise typer.BadParameter(f"Invalid JSON: {file_path}") from exc
    if not isinstance(data, dict):
        raise typer.BadParameter(f"Expected JSON object in {file_path}")
    return data


def _build_labeled_rows_from_cluster_summary(
    cluster_summary: dict[str, Any],
    *,
    default_label: str,
    failure_mode: str | None,
    include_passed: bool,
) -> list[LabeledGoldenCase]:
    rows: list[LabeledGoldenCase] = []
    timestamp = datetime.now(timezone.utc).isoformat()
    for cluster in cluster_summary.get("clusters", []):
        if not isinstance(cluster, dict):
            continue
        cluster_id = cluster.get("id") if isinstance(cluster.get("id"), str) else None
        cluster_label = cluster.get("clusterLabel") if isinstance(cluster.get("clusterLabel"), str) else None
        cluster_failure_mode = failure_mode
        if cluster_failure_mode is None and isinstance(cluster.get("suggestedFailureMode"), str):
            cluster_failure_mode = cluster["suggestedFailureMode"]
        for case in cluster.get("cases", []):
            if not isinstance(case, dict):
                continue
            status = case.get("status") if isinstance(case.get("status"), str) else "failed"
            if status == "passed" and not include_passed:
                continue
            label_value = "pass" if status == "passed" and default_label != "fail" else ("pass" if status == "passed" else "fail")
            rows.append(
                LabeledGoldenCase(
                    case_id=str(case.get("caseId") or case.get("id") or case.get("name") or "case"),
                    input=str(case.get("input") or ""),
                    expected=str(case.get("expected") or ""),
                    actual=str(case.get("actual") or ""),
                    label=label_value,
                    failure_mode=None if label_value == "pass" else (cluster_failure_mode or status),
                    labeled_at=timestamp,
                    cluster_id=cluster_id,
                    cluster_label=cluster_label,
                )
            )
    return rows


@auto_app.command("run")
def auto_run(
    objective: str = typer.Option(..., "--objective", help="Target failure mode or objective"),
    prompt: str | None = typer.Option(None, "--prompt", help="Prompt file being optimized"),
    hypothesis: str | None = typer.Option(None, "--hypothesis", help="Experiment hypothesis"),
    baseline_run: str | None = typer.Option(None, "--baseline-run", help="Baseline run artifact"),
    candidate_run: str | None = typer.Option(None, "--candidate-run", help="Candidate run artifact"),
    budget: int = typer.Option(1, "--budget", help="Per-iteration budget"),
    budget_mode: str = typer.Option("traces", "--budget-mode", help="Budget mode: traces or cost"),
    autonomous: bool = typer.Option(False, "--autonomous", help="Enable autonomous bounded mode"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Plan only"),
    fmt: str = typer.Option("human", "--format", help="Output format: human or json"),
    report: str = typer.Option(DEFAULT_AUTO_REPORT_PATH, "--report", help="Auto report output path"),
) -> None:
    options = AutoOptions(
        objective=objective,
        hypothesis=hypothesis,
        prompt_path=prompt,
        baseline_run_path=baseline_run,
        candidate_run_path=candidate_run,
        budget=budget,
        budget_mode="cost" if budget_mode == "cost" else "traces",
        autonomous=autonomous,
        dry_run=dry_run,
        format="json" if fmt == "json" else "human",
        report_path=report,
    )
    auto_report = build_auto_report(options)
    write_auto_report(auto_report, report)
    if fmt == "json":
        console.print_json(json.dumps(auto_report.to_dict()))
    else:
        console.print(format_auto_human(auto_report))
        console.print(f"\nSaved → {Path(report)}")


@auto_app.command("daemon")
def auto_daemon(
    objective: str = typer.Option(..., "--objective", help="Target failure mode or objective"),
    prompt: str | None = typer.Option(None, "--prompt", help="Prompt file being optimized"),
    hypothesis: str | None = typer.Option(None, "--hypothesis", help="Experiment hypothesis"),
    baseline_run: str | None = typer.Option(None, "--baseline-run", help="Baseline run artifact"),
    candidate_run: str | None = typer.Option(None, "--candidate-run", help="Candidate run artifact"),
    budget: int = typer.Option(1, "--budget", help="Per-cycle budget"),
    cycles: int = typer.Option(1, "--cycles", help="Number of bounded cycles to run"),
    interval_ms: int = typer.Option(0, "--interval-ms", help="Delay between cycles"),
    fmt: str = typer.Option("human", "--format", help="Output format: human or json"),
    history: str = typer.Option(DEFAULT_AUTO_HISTORY_PATH, "--history", help="History JSONL path"),
) -> None:
    options = AutoOptions(
        objective=objective,
        hypothesis=hypothesis,
        prompt_path=prompt,
        baseline_run_path=baseline_run,
        candidate_run_path=candidate_run,
        budget=budget,
        format="json" if fmt == "json" else "human",
    )
    reports = run_auto_daemon(options, cycles=cycles, interval_ms=interval_ms, history_path=history)
    if fmt == "json":
        console.print_json(json.dumps({"cycles": len(reports), "history": history, "reports": [report.to_dict() for report in reports]}))
    else:
        for index, report_item in enumerate(reports, start=1):
            console.print(f"EvalGate auto daemon cycle {index}/{len(reports)}")
            console.print(format_auto_human(report_item))
            console.print()
        console.print(f"completed {len(reports)} cycle(s) successfully")


@auto_app.command("history")
def auto_history(
    history: str = typer.Option(DEFAULT_AUTO_HISTORY_PATH, "--history", help="History JSONL path"),
    fmt: str = typer.Option("human", "--format", help="Output format: human or json"),
) -> None:
    path = Path(history)
    if not path.exists():
        raise typer.Exit(0)
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    if fmt == "json":
        console.print_json(json.dumps({"history": rows}))
        return
    console.print(f"Auto history ({len(rows)})")
    for row in rows[-10:]:
        console.print(f"- {row.get('generatedAt', '?')} — {row.get('objective', '?')} ({row.get('executionMode', '?')})")


@auto_app.command("init")
def auto_init(
    report: str = typer.Option(DEFAULT_AUTO_REPORT_PATH, "--report", help="Initial report path"),
    history: str = typer.Option(DEFAULT_AUTO_HISTORY_PATH, "--history", help="History JSONL path"),
) -> None:
    Path(report).parent.mkdir(parents=True, exist_ok=True)
    Path(history).parent.mkdir(parents=True, exist_ok=True)
    Path(history).touch(exist_ok=True)
    console.print(f"[green]✓[/green] Prepared {Path(report).parent}")


def cluster(
    run: str = typer.Option(..., "--run", help="Run artifact to cluster"),
    output: str | None = typer.Option(None, "--output", help="Cluster report output path"),
    clusters: int | None = typer.Option(None, "--clusters", help="Requested cluster count"),
    include_passed: bool = typer.Option(False, "--include-passed", help="Include passed cases"),
    fmt: str = typer.Option("human", "--format", help="Output format: human or json"),
) -> None:
    run_data = _read_json(run)
    summary = cluster_run_result(normalize_run_artifact(run_data), clusters=clusters, include_passed=include_passed)
    if output:
        output_path = Path(output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(summary.to_dict(), indent=2), encoding="utf-8")
    if fmt == "json":
        console.print_json(json.dumps(summary.to_dict()))
    else:
        console.print(format_cluster_human(summary))


def analyze(
    dataset: str = typer.Option(DEFAULT_LABELED_DATASET_PATH, "--dataset", help="Labeled dataset JSONL path"),
    top: int = typer.Option(5, "--top", help="Top N failure modes"),
    fmt: str = typer.Option("human", "--format", help="Output format: human or json"),
) -> None:
    rows = parse_labeled_dataset(Path(dataset).read_text(encoding="utf-8"))
    summary = analyze_labeled_dataset(rows, top=top)
    if fmt == "json":
        console.print_json(json.dumps(summary.to_dict()))
    else:
        console.print(format_analyze_human(summary))


def label(
    run: str | None = typer.Option(None, "--run", help="Run artifact to convert into labeled JSONL"),
    cluster: str | None = typer.Option(None, "--cluster", help="Cluster report to convert into labeled JSONL"),
    output: str = typer.Option(DEFAULT_LABELED_DATASET_PATH, "--output", help="Output JSONL path"),
    default_label: str = typer.Option("fail", "--default-label", help="Default label: pass or fail"),
    failure_mode: str | None = typer.Option(None, "--failure-mode", help="Failure mode for failed rows"),
    include_passed: bool = typer.Option(False, "--include-passed", help="Include passed cases too"),
    fmt: str = typer.Option("human", "--format", help="Output format: human or json"),
) -> None:
    if bool(run) == bool(cluster):
        raise typer.BadParameter("Use exactly one of --run or --cluster")
    rows: list[LabeledGoldenCase] = []
    if cluster:
        rows = _build_labeled_rows_from_cluster_summary(
            _read_json(cluster),
            default_label=default_label,
            failure_mode=failure_mode,
            include_passed=include_passed,
        )
    else:
        normalized = normalize_run_artifact(_read_json(run or ""))
        timestamp = datetime.now(timezone.utc).isoformat()
        for case in normalized.cases:
            if case.status == "passed" and not include_passed:
                continue
            label_value = "pass" if case.status == "passed" and default_label != "fail" else ("pass" if case.status == "passed" else "fail")
            row_failure_mode = None if label_value == "pass" else (failure_mode or case.status)
            rows.append(
                LabeledGoldenCase(
                    case_id=case.case_id,
                    input=case.input,
                    expected=case.expected,
                    actual=case.actual,
                    label=label_value,
                    failure_mode=row_failure_mode,
                    labeled_at=timestamp,
                )
            )
    write_jsonl(output, rows)
    if fmt == "json":
        console.print_json(json.dumps({"total": len(rows), "output": output}))
    else:
        console.print(f"Wrote {len(rows)} labeled case(s) → {output}")


def synthesize(
    dataset: str = typer.Option(DEFAULT_LABELED_DATASET_PATH, "--dataset", help="Labeled dataset JSONL path"),
    dimensions: str | None = typer.Option(None, "--dimensions", help="Dimension matrix JSON path"),
    count: int | None = typer.Option(None, "--count", help="Synthetic case count"),
    failure_mode: list[str] | None = typer.Option(None, "--failure-mode", help="Requested failure modes"),
    output: str = typer.Option(DEFAULT_SYNTHETIC_DATASET_PATH, "--output", help="Synthetic dataset output path"),
    fmt: str = typer.Option("human", "--format", help="Output format: human or json"),
) -> None:
    rows = parse_labeled_dataset(Path(dataset).read_text(encoding="utf-8"))
    dimension_values: dict[str, list[str]] = {}
    if dimensions:
        dimension_values = parse_dimension_matrix(Path(dimensions).read_text(encoding="utf-8")).dimensions
    summary = synthesize_labeled_dataset(
        rows,
        dimensions=dimension_values,
        count=count,
        failure_modes=failure_mode,
        output_path=output,
    )
    if not summary.selected_failure_modes:
        raise typer.Exit(2)
    write_jsonl(output, summary.cases)
    if fmt == "json":
        console.print_json(json.dumps(summary.to_dict()))
    else:
        console.print(format_synthesize_human(summary))
        console.print(f"\nSaved → {output}")


def replay_decision(
    previous: str = typer.Option(..., "--previous", help="Previous run artifact"),
    current: str = typer.Option(..., "--current", help="Current run artifact"),
    budget_mode: str = typer.Option("traces", "--budget-mode", help="Budget mode: traces or cost"),
    max_traces: int = typer.Option(100, "--max-traces", help="Trace budget when using traces mode"),
    max_cost_usd: float = typer.Option(1.0, "--max-cost-usd", help="Cost budget when using cost mode"),
    fmt: str = typer.Option("human", "--format", help="Output format: human or json"),
) -> None:
    previous_run = _read_json(previous)
    current_run = _read_json(current)
    config = NormalizedBudgetConfig(
        mode="cost" if budget_mode == "cost" else "traces",
        max_traces=max_traces,
        max_cost_usd=max_cost_usd,
    )
    decision = evaluate_replay_outcome(previous_run, current_run, config)
    if fmt == "json":
        console.print_json(json.dumps(decision.to_dict()))
    else:
        console.print(f"Decision: {decision.action}")
        console.print(f"Reason: {decision.reason}")
        console.print(
            f"Comparison basis: {decision.comparison_basis} ({decision.previous_pass_rate:.4f} → {decision.new_pass_rate:.4f})"
        )
