from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from evalgate_sdk.golden import RunMetrics, extract_run_metrics


@dataclass(slots=True)
class NormalizedBudgetConfig:
    mode: Literal["traces", "cost"]
    max_traces: int | None = None
    max_cost_usd: float | None = None


@dataclass(slots=True)
class ReplayDecision:
    action: Literal["keep", "discard"]
    reason: Literal["pass_rate_improved", "pass_rate_declined", "budget_exceeded"]
    previous_pass_rate: float
    new_pass_rate: float
    previous_corrected_pass_rate: float | None
    new_corrected_pass_rate: float | None
    comparison_basis: Literal["corrected", "raw"]
    budget_used: float
    budget_limit: float

    def to_dict(self) -> dict[str, float | str | None]:
        return {
            "action": self.action,
            "reason": self.reason,
            "previousPassRate": self.previous_pass_rate,
            "newPassRate": self.new_pass_rate,
            "previousCorrectedPassRate": self.previous_corrected_pass_rate,
            "newCorrectedPassRate": self.new_corrected_pass_rate,
            "comparisonBasis": self.comparison_basis,
            "budgetUsed": self.budget_used,
            "budgetLimit": self.budget_limit,
        }


def determine_comparison_basis(
    previous_corrected: float | None,
    new_corrected: float | None,
) -> Literal["corrected", "raw"]:
    if previous_corrected is not None and new_corrected is not None:
        return "corrected"
    return "raw"


def _budget_values(metrics: RunMetrics, budget: NormalizedBudgetConfig) -> tuple[float, float]:
    if budget.mode == "traces":
        used = float(metrics.total_results)
        limit = float(budget.max_traces or 0)
        return used, limit
    used = float(metrics.total_cost_usd or 0.0)
    limit = float(budget.max_cost_usd or 0.0)
    return used, limit


def evaluate_replay_outcome(
    previous_run: dict,
    new_run: dict,
    budget_config: NormalizedBudgetConfig,
) -> ReplayDecision:
    previous_metrics = extract_run_metrics(previous_run)
    new_metrics = extract_run_metrics(new_run)
    budget_used, budget_limit = _budget_values(new_metrics, budget_config)
    comparison_basis = determine_comparison_basis(
        previous_metrics.corrected_pass_rate_ratio,
        new_metrics.corrected_pass_rate_ratio,
    )
    if budget_used > budget_limit:
        return ReplayDecision(
            action="discard",
            reason="budget_exceeded",
            previous_pass_rate=previous_metrics.pass_rate_ratio,
            new_pass_rate=new_metrics.pass_rate_ratio,
            previous_corrected_pass_rate=previous_metrics.corrected_pass_rate_ratio,
            new_corrected_pass_rate=new_metrics.corrected_pass_rate_ratio,
            comparison_basis=comparison_basis,
            budget_used=budget_used,
            budget_limit=budget_limit,
        )

    previous_rate = (
        previous_metrics.corrected_pass_rate_ratio if comparison_basis == "corrected" else previous_metrics.pass_rate_ratio
    )
    new_rate = new_metrics.corrected_pass_rate_ratio if comparison_basis == "corrected" else new_metrics.pass_rate_ratio
    previous_rate = previous_rate if previous_rate is not None else previous_metrics.pass_rate_ratio
    new_rate = new_rate if new_rate is not None else new_metrics.pass_rate_ratio

    if new_rate > previous_rate:
        return ReplayDecision(
            action="keep",
            reason="pass_rate_improved",
            previous_pass_rate=previous_metrics.pass_rate_ratio,
            new_pass_rate=new_metrics.pass_rate_ratio,
            previous_corrected_pass_rate=previous_metrics.corrected_pass_rate_ratio,
            new_corrected_pass_rate=new_metrics.corrected_pass_rate_ratio,
            comparison_basis=comparison_basis,
            budget_used=budget_used,
            budget_limit=budget_limit,
        )
    return ReplayDecision(
        action="discard",
        reason="pass_rate_declined",
        previous_pass_rate=previous_metrics.pass_rate_ratio,
        new_pass_rate=new_metrics.pass_rate_ratio,
        previous_corrected_pass_rate=previous_metrics.corrected_pass_rate_ratio,
        new_corrected_pass_rate=new_metrics.corrected_pass_rate_ratio,
        comparison_basis=comparison_basis,
        budget_used=budget_used,
        budget_limit=budget_limit,
    )
