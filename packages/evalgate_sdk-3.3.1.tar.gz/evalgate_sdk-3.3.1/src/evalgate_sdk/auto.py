from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from evalgate_sdk.golden import extract_run_metrics
from evalgate_sdk.replay_decision import NormalizedBudgetConfig, ReplayDecision, evaluate_replay_outcome

DEFAULT_AUTO_HISTORY_PATH = str(Path(".evalgate") / "auto" / "history.jsonl")
DEFAULT_AUTO_REPORT_PATH = str(Path(".evalgate") / "auto" / "latest-report.json")

AutoFormat = Literal["human", "json"]
AutoExecutionMode = Literal["plan", "evaluate"]
AutoDecision = Literal["keep", "discard", "investigate"]


@dataclass(slots=True)
class AutoPlanStep:
    title: str
    detail: str

    def to_dict(self) -> dict[str, str]:
        return {
            "title": self.title,
            "detail": self.detail,
        }


@dataclass(slots=True)
class AutoOptions:
    objective: str
    hypothesis: str | None = None
    prompt_path: str | None = None
    baseline_run_path: str | None = None
    candidate_run_path: str | None = None
    budget: int = 1
    budget_mode: Literal["traces", "cost"] = "traces"
    autonomous: bool = False
    dry_run: bool = False
    format: AutoFormat = "human"
    report_path: str = DEFAULT_AUTO_REPORT_PATH


@dataclass(slots=True)
class AutoDiffSnapshot:
    pass_rate_delta_ratio: float
    corrected_pass_rate_delta_ratio: float | None
    pass_rate_basis: Literal["corrected", "raw"]
    regressions: int = 0
    improvements: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "passRateDeltaRatio": self.pass_rate_delta_ratio,
            "correctedPassRateDeltaRatio": self.corrected_pass_rate_delta_ratio,
            "passRateBasis": self.pass_rate_basis,
            "regressions": self.regressions,
            "improvements": self.improvements,
        }


@dataclass(slots=True)
class AutoIterationResult:
    decision: AutoDecision
    reason: str
    replay_decision: ReplayDecision | None = None
    diff: AutoDiffSnapshot | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision,
            "reason": self.reason,
            "replayDecision": self.replay_decision.to_dict() if self.replay_decision else None,
            "diff": self.diff.to_dict() if self.diff else None,
        }


@dataclass(slots=True)
class AutoReport:
    objective: str
    execution_mode: AutoExecutionMode
    dry_run: bool
    autonomous: bool
    prompt_path: str | None
    baseline_run_path: str | None
    candidate_run_path: str | None
    iteration_budget: int
    generated_at: str
    plan: list[AutoPlanStep] = field(default_factory=list)
    iteration_result: AutoIterationResult | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "objective": self.objective,
            "executionMode": self.execution_mode,
            "dryRun": self.dry_run,
            "autonomous": self.autonomous,
            "promptPath": self.prompt_path,
            "baselineRunPath": self.baseline_run_path,
            "candidateRunPath": self.candidate_run_path,
            "iterationBudget": self.iteration_budget,
            "generatedAt": self.generated_at,
            "plan": [step.to_dict() for step in self.plan],
            "iterationResult": self.iteration_result.to_dict() if self.iteration_result else None,
        }


def build_auto_plan(options: AutoOptions) -> list[AutoPlanStep]:
    prompt_target = options.prompt_path or "declared prompt target"
    hypothesis = options.hypothesis or f"Reduce {options.objective} failures"
    return [
        AutoPlanStep(title="Objective", detail=f"Target failure mode: {options.objective}"),
        AutoPlanStep(title="Hypothesis", detail=hypothesis),
        AutoPlanStep(title="Mutation target", detail=prompt_target),
        AutoPlanStep(title="Budget", detail=f"{options.budget} {options.budget_mode} per iteration"),
        AutoPlanStep(
            title="Evaluation",
            detail=(
                "Compare candidate run to baseline and keep only non-regressing improvements"
                if options.baseline_run_path and options.candidate_run_path
                else "Generate bounded plan only until baseline/candidate artifacts are provided"
            ),
        ),
    ]


def _read_json(file_path: str) -> dict[str, Any]:
    data = json.loads(Path(file_path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Auto run input must be a JSON object")
    return data


def _build_diff_snapshot(previous_run: dict[str, Any], candidate_run: dict[str, Any], decision: ReplayDecision) -> AutoDiffSnapshot:
    previous_metrics = extract_run_metrics(previous_run)
    candidate_metrics = extract_run_metrics(candidate_run)
    corrected_delta = None
    if previous_metrics.corrected_pass_rate_ratio is not None and candidate_metrics.corrected_pass_rate_ratio is not None:
        corrected_delta = candidate_metrics.corrected_pass_rate_ratio - previous_metrics.corrected_pass_rate_ratio
    return AutoDiffSnapshot(
        pass_rate_delta_ratio=candidate_metrics.pass_rate_ratio - previous_metrics.pass_rate_ratio,
        corrected_pass_rate_delta_ratio=corrected_delta,
        pass_rate_basis=decision.comparison_basis,
        regressions=0 if decision.action == "keep" else 1,
        improvements=1 if decision.action == "keep" else 0,
    )


def decide_auto_experiment(options: AutoOptions) -> AutoIterationResult | None:
    if not options.baseline_run_path or not options.candidate_run_path:
        return None
    previous_run = _read_json(options.baseline_run_path)
    candidate_run = _read_json(options.candidate_run_path)
    budget_config = NormalizedBudgetConfig(
        mode=options.budget_mode,
        max_traces=options.budget if options.budget_mode == "traces" else None,
        max_cost_usd=float(options.budget) if options.budget_mode == "cost" else None,
    )
    replay = evaluate_replay_outcome(previous_run, candidate_run, budget_config)
    if replay.action == "keep":
        decision: AutoDecision = "keep"
    elif replay.reason == "budget_exceeded":
        decision = "investigate"
    else:
        decision = "discard"
    return AutoIterationResult(
        decision=decision,
        reason=replay.reason,
        replay_decision=replay,
        diff=_build_diff_snapshot(previous_run, candidate_run, replay),
    )


def build_auto_report(options: AutoOptions) -> AutoReport:
    execution_mode: AutoExecutionMode = (
        "evaluate" if options.baseline_run_path and options.candidate_run_path and not options.dry_run else "plan"
    )
    return AutoReport(
        objective=options.objective,
        execution_mode=execution_mode,
        dry_run=options.dry_run,
        autonomous=options.autonomous,
        prompt_path=options.prompt_path,
        baseline_run_path=options.baseline_run_path,
        candidate_run_path=options.candidate_run_path,
        iteration_budget=options.budget,
        generated_at=datetime.now(timezone.utc).isoformat(),
        plan=build_auto_plan(options),
        iteration_result=decide_auto_experiment(options) if execution_mode == "evaluate" else None,
    )


def format_auto_human(report: AutoReport) -> str:
    lines = [
        "Auto phase",
        f"Objective: {report.objective}",
        f"Mode: {report.execution_mode}",
        f"Budget: {report.iteration_budget}",
    ]
    if report.prompt_path:
        lines.append(f"Prompt: {report.prompt_path}")
    lines.append("Plan:")
    for index, step in enumerate(report.plan, start=1):
        lines.append(f"{index}. {step.title} — {step.detail}")
    if report.iteration_result:
        lines.append("")
        lines.append(f"Decision: {report.iteration_result.decision}")
        lines.append(f"Reason: {report.iteration_result.reason}")
        if report.iteration_result.diff:
            lines.append(
                f"Pass-rate delta: {report.iteration_result.diff.pass_rate_delta_ratio:+.4f} ({report.iteration_result.diff.pass_rate_basis})"
            )
    return "\n".join(lines)


def append_auto_history(report: AutoReport, history_path: str = DEFAULT_AUTO_HISTORY_PATH) -> None:
    path = Path(history_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(report.to_dict(), separators=(",", ":")) + "\n")


def write_auto_report(report: AutoReport, report_path: str | None = None) -> None:
    path = Path(report_path or DEFAULT_AUTO_REPORT_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")


def run_auto_daemon(
    options: AutoOptions,
    *,
    cycles: int,
    interval_ms: int = 0,
    history_path: str = DEFAULT_AUTO_HISTORY_PATH,
) -> list[AutoReport]:
    reports: list[AutoReport] = []
    for index in range(max(0, cycles)):
        report = build_auto_report(options)
        append_auto_history(report, history_path=history_path)
        reports.append(report)
        if interval_ms > 0 and index < cycles - 1:
            time.sleep(interval_ms / 1000.0)
    return reports
