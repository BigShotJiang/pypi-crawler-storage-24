from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from evalgate_sdk.golden import NormalizedRunArtifact, NormalizedRunCase

STOP_WORDS = {
    "the",
    "and",
    "for",
    "with",
    "that",
    "this",
    "from",
    "into",
    "your",
    "have",
    "should",
    "would",
    "could",
    "about",
    "what",
    "when",
    "where",
    "while",
    "were",
    "them",
    "then",
    "than",
    "also",
    "been",
    "because",
    "expected",
    "actual",
    "input",
    "output",
    "error",
    "failed",
    "passed",
    "skipped",
    "result",
    "spec",
    "case",
    "file",
}


@dataclass(slots=True)
class ClusterSample:
    case_id: str
    name: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "caseId": self.case_id,
            "name": self.name,
        }


@dataclass(slots=True)
class ClusterCase:
    case_id: str
    name: str
    file_path: str
    status: str
    input: str
    expected: str
    actual: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "caseId": self.case_id,
            "name": self.name,
            "filePath": self.file_path,
            "status": self.status,
            "input": self.input,
            "expected": self.expected,
            "actual": self.actual,
        }


@dataclass(slots=True)
class TraceCluster:
    id: str
    cluster_label: str
    dominant_pattern: str
    suggested_failure_mode: str | None
    similarity_threshold: float
    trace_ids: list[str]
    trace_count: int
    keywords: list[str]
    member_ids: list[str]
    member_count: int
    density: float
    status_counts: dict[str, int]
    samples: list[ClusterSample] = field(default_factory=list)
    cases: list[ClusterCase] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "clusterLabel": self.cluster_label,
            "dominantPattern": self.dominant_pattern,
            "suggestedFailureMode": self.suggested_failure_mode,
            "similarityThreshold": self.similarity_threshold,
            "traceIds": list(self.trace_ids),
            "traceCount": self.trace_count,
            "keywords": list(self.keywords),
            "memberIds": list(self.member_ids),
            "memberCount": self.member_count,
            "density": self.density,
            "statusCounts": dict(self.status_counts),
            "samples": [sample.to_dict() for sample in self.samples],
            "cases": [case.to_dict() for case in self.cases],
        }


@dataclass(slots=True)
class ClusterSummary:
    run_id: str
    total_run_results: int
    clustered_cases: int
    skipped_cases: int
    requested_clusters: int | None
    include_passed: bool
    clusters: list[TraceCluster]

    def to_dict(self) -> dict[str, Any]:
        return {
            "runId": self.run_id,
            "totalRunResults": self.total_run_results,
            "clusteredCases": self.clustered_cases,
            "skippedCases": self.skipped_cases,
            "requestedClusters": self.requested_clusters,
            "includePassed": self.include_passed,
            "clusters": [cluster.to_dict() for cluster in self.clusters],
        }


def _tokenize(text: str) -> list[str]:
    normalized = []
    current = []
    for char in text.lower():
        if char.isalnum():
            current.append(char)
        else:
            if current:
                token = "".join(current)
                if len(token) > 2 and token not in STOP_WORDS:
                    normalized.append(token)
                current = []
    if current:
        token = "".join(current)
        if len(token) > 2 and token not in STOP_WORDS:
            normalized.append(token)
    return normalized


def _token_set(text: str) -> set[str]:
    return set(_tokenize(text))


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    intersection = len(a.intersection(b))
    union = len(a.union(b))
    return intersection / union if union else 0.0


def _build_case_text(case: NormalizedRunCase) -> str:
    return "\n".join(
        part
        for part in [case.name, case.file_path, case.error or "", case.input, case.expected, case.actual]
        if part.strip()
    )


def _centroid_keywords(texts: list[str], top_n: int = 4) -> list[str]:
    frequencies: dict[str, int] = {}
    for text in texts:
        for token in _tokenize(text):
            frequencies[token] = frequencies.get(token, 0) + 1
    ordered = sorted(frequencies.items(), key=lambda item: (-item[1], item[0]))
    return [token for token, _count in ordered[:top_n]]


def _suggest_failure_mode(text: str, has_failed_members: bool) -> str | None:
    if not has_failed_members:
        return None
    lower = text.lower()
    if "timeout" in lower or "slow" in lower:
        return "performance_timeout"
    if "null" in lower or "undefined" in lower:
        return "null_reference"
    if "format" in lower or "parse" in lower:
        return "format_mismatch"
    if "constraint" in lower or "validation" in lower:
        return "constraint_violation"
    if "tone" in lower or "empathetic" in lower or "professional" in lower:
        return "tone_mismatch"
    if "halluc" in lower or "invented" in lower or "grounding" in lower:
        return "hallucination"
    return "general_failure"


def _density(member_sets: list[set[str]]) -> float:
    if len(member_sets) < 2:
        return 1.0
    total = 0.0
    count = 0
    for index, current in enumerate(member_sets):
        for other in member_sets[index + 1 :]:
            total += _jaccard(current, other)
            count += 1
    return total / count if count else 1.0


def _assign_clusters(points: list[dict[str, Any]], cluster_count: int) -> list[list[dict[str, Any]]]:
    if not points:
        return []
    clusters: list[list[dict[str, Any]]] = []
    for point in points:
        if len(clusters) < cluster_count:
            clusters.append([point])
            continue
        best_index = 0
        best_score = -1.0
        for index, cluster in enumerate(clusters):
            scores = [_jaccard(point["tokens"], member["tokens"]) for member in cluster]
            avg_score = sum(scores) / len(scores) if scores else 0.0
            if avg_score > best_score:
                best_score = avg_score
                best_index = index
        clusters[best_index].append(point)
    return clusters


def cluster_run_result(
    run_artifact: NormalizedRunArtifact,
    *,
    clusters: int | None = None,
    include_passed: bool = False,
) -> ClusterSummary:
    candidates = [case for case in run_artifact.cases if include_passed or case.status == "failed"]
    if not candidates:
        return ClusterSummary(
            run_id=run_artifact.run_id,
            total_run_results=run_artifact.total_run_results,
            clustered_cases=0,
            skipped_cases=run_artifact.total_run_results,
            requested_clusters=clusters,
            include_passed=include_passed,
            clusters=[],
        )

    points = []
    for case in candidates:
        text = _build_case_text(case)
        points.append({"case": case, "text": text, "tokens": _token_set(text)})

    cluster_count = clusters or min(8, max(1, round(len(points) ** 0.5)))
    grouped = _assign_clusters(points, min(cluster_count, len(points)))

    built_clusters: list[TraceCluster] = []
    for index, members in enumerate(grouped):
        texts = [member["text"] for member in members]
        keywords = _centroid_keywords(texts)
        dominant_pattern = ", ".join(keywords[:3]) if keywords else "No clear pattern"
        failed_text = " ".join(member["text"] for member in members if member["case"].status == "failed")
        status_counts = {"passed": 0, "failed": 0, "skipped": 0}
        for member in members:
            status = member["case"].status
            if status == "passed":
                status_counts["passed"] += 1
            elif status == "skipped":
                status_counts["skipped"] += 1
            else:
                status_counts["failed"] += 1
        member_token_sets = [member["tokens"] for member in members]
        density = _density(member_token_sets)
        cases = [
            ClusterCase(
                case_id=member["case"].case_id,
                name=member["case"].name,
                file_path=member["case"].file_path,
                status=member["case"].status,
                input=member["case"].input,
                expected=member["case"].expected,
                actual=member["case"].actual,
            )
            for member in members
        ]
        built_clusters.append(
            TraceCluster(
                id=f"cluster-{index}",
                cluster_label=", ".join(keywords[:3]) if keywords else f"Cluster {index + 1}",
                dominant_pattern=dominant_pattern,
                suggested_failure_mode=_suggest_failure_mode(failed_text, status_counts["failed"] > 0),
                similarity_threshold=density,
                trace_ids=[member["case"].case_id for member in members],
                trace_count=len(members),
                keywords=keywords,
                member_ids=[member["case"].case_id for member in members],
                member_count=len(members),
                density=density,
                status_counts=status_counts,
                samples=[
                    ClusterSample(case_id=member["case"].case_id, name=member["case"].name)
                    for member in members[:3]
                ],
                cases=cases,
            )
        )

    built_clusters.sort(key=lambda item: (-item.trace_count, -item.similarity_threshold, item.id))
    return ClusterSummary(
        run_id=run_artifact.run_id,
        total_run_results=run_artifact.total_run_results,
        clustered_cases=len(candidates),
        skipped_cases=run_artifact.total_run_results - len(candidates),
        requested_clusters=clusters,
        include_passed=include_passed,
        clusters=built_clusters,
    )


def format_cluster_human(summary: ClusterSummary) -> str:
    lines = [
        "Cluster phase",
        f"Run: {summary.run_id}",
        f"Clustered {summary.clustered_cases} case(s) into {len(summary.clusters)} cluster(s)",
    ]
    if summary.skipped_cases > 0:
        lines.append(
            f"Skipped {summary.skipped_cases} case(s) ({'none filtered' if summary.include_passed else 'use --include-passed to include non-failures'})"
        )
    if not summary.clusters:
        lines.append("No cases available for clustering")
        return "\n".join(lines)
    for index, cluster in enumerate(summary.clusters, start=1):
        lines.append("")
        lines.append(
            f"{index}. {cluster.id} — {cluster.cluster_label} ({cluster.trace_count} case(s), {(cluster.similarity_threshold * 100):.1f}% similarity)"
        )
        lines.append(
            f"   status: {cluster.status_counts['failed']} failed, {cluster.status_counts['passed']} passed, {cluster.status_counts['skipped']} skipped"
        )
        if cluster.dominant_pattern:
            lines.append(f"   pattern: {cluster.dominant_pattern}")
        if cluster.suggested_failure_mode:
            lines.append(f"   suggested failure mode: {cluster.suggested_failure_mode}")
        if cluster.samples:
            sample_line = ", ".join(f"{sample.case_id} ({sample.name})" for sample in cluster.samples)
            lines.append(f"   samples: {sample_line}")
    return "\n".join(lines)
