from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

DEFAULT_LABELED_DATASET_PATH = str(Path(".evalgate") / "golden" / "labeled.jsonl")
DEFAULT_SYNTHETIC_DATASET_PATH = str(Path(".evalgate") / "golden" / "synthetic.jsonl")

LabeledOutcome = Literal["pass", "fail"]
RunStatus = Literal["passed", "failed", "error", "timeout", "skipped"]


@dataclass(slots=True)
class LabeledGoldenCase:
    case_id: str
    input: str
    expected: str
    actual: str
    label: LabeledOutcome
    failure_mode: str | None
    labeled_at: str
    cluster_id: str | None = None
    cluster_label: str | None = None

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "caseId": self.case_id,
            "input": self.input,
            "expected": self.expected,
            "actual": self.actual,
            "label": self.label,
            "failureMode": self.failure_mode,
            "labeledAt": self.labeled_at,
        }
        if self.cluster_id is not None:
            data["clusterId"] = self.cluster_id
        if self.cluster_label is not None:
            data["clusterLabel"] = self.cluster_label
        return data


@dataclass(slots=True)
class SyntheticGoldenCase(LabeledGoldenCase):
    synthetic: bool = True
    synthesized_at: str = ""
    source_case_ids: list[str] = field(default_factory=list)
    dimensions: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = LabeledGoldenCase.to_dict(self)
        data.update(
            {
                "synthetic": True,
                "synthesizedAt": self.synthesized_at,
                "sourceCaseIds": list(self.source_case_ids),
                "dimensions": dict(self.dimensions),
            }
        )
        return data


@dataclass(slots=True)
class FailureModeSummary:
    mode: str
    count: int
    frequency: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "count": self.count,
            "frequency": self.frequency,
        }


@dataclass(slots=True)
class AnalyzeSummary:
    total: int
    failed: int
    pass_rate: float
    failure_modes: list[FailureModeSummary]

    def to_dict(self) -> dict[str, Any]:
        return {
            "total": self.total,
            "failed": self.failed,
            "passRate": self.pass_rate,
            "failureModes": [item.to_dict() for item in self.failure_modes],
        }


@dataclass(slots=True)
class NormalizedRunCase:
    case_id: str
    name: str
    file_path: str
    status: RunStatus
    input: str
    expected: str
    actual: str
    passed: bool
    score: float
    duration_ms: float
    error: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class NormalizedRunArtifact:
    run_id: str
    total_run_results: int
    summary: dict[str, Any]
    cases: list[NormalizedRunCase]
    source_format: str


@dataclass(slots=True)
class RunMetrics:
    pass_rate_ratio: float
    corrected_pass_rate_ratio: float | None
    total_cost_usd: float | None
    total_results: int


def _is_iso_timestamp(value: str) -> bool:
    candidate = value.strip()
    if not candidate:
        return False
    normalized = candidate[:-1] + "+00:00" if candidate.endswith("Z") else candidate
    try:
        datetime.fromisoformat(normalized)
    except ValueError:
        return False
    return True


def _require_string(record: dict[str, Any], key: str, line_number: int) -> str:
    value = record.get(key)
    if not isinstance(value, str):
        raise ValueError(f"Invalid labeled dataset at line {line_number}: {key} must be a string")
    return value


def parse_labeled_dataset(content: str) -> list[LabeledGoldenCase]:
    rows = [line.strip() for line in content.splitlines() if line.strip()]
    parsed_rows: list[LabeledGoldenCase] = []
    for index, line in enumerate(rows, start=1):
        try:
            parsed = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSONL at line {index}: expected valid JSON object") from exc
        if not isinstance(parsed, dict):
            raise ValueError(f"Invalid JSONL at line {index}: expected JSON object record")

        case_id = _require_string(parsed, "caseId", index).strip()
        if not case_id:
            raise ValueError(f"Invalid labeled dataset at line {index}: caseId must be a non-empty string")
        input_text = _require_string(parsed, "input", index)
        expected = _require_string(parsed, "expected", index)
        actual = _require_string(parsed, "actual", index)
        label = parsed.get("label")
        if label not in ("pass", "fail"):
            raise ValueError(f'Invalid labeled dataset at line {index}: label must be "pass" or "fail"')

        failure_mode_value = parsed.get("failureMode")
        if failure_mode_value == "":
            failure_mode_value = None
        if not (isinstance(failure_mode_value, str) or failure_mode_value is None):
            raise ValueError(f"Invalid labeled dataset at line {index}: failureMode must be string or null")
        if label == "fail" and (failure_mode_value is None or not failure_mode_value.strip()):
            raise ValueError(
                f"Invalid labeled dataset at line {index}: failed rows require a non-empty failureMode"
            )
        if label == "pass" and isinstance(failure_mode_value, str) and failure_mode_value.strip():
            raise ValueError(
                f"Invalid labeled dataset at line {index}: passing rows must set failureMode to null or empty string"
            )

        labeled_at = _require_string(parsed, "labeledAt", index)
        if not _is_iso_timestamp(labeled_at):
            raise ValueError(
                f"Invalid labeled dataset at line {index}: labeledAt must be an ISO timestamp string"
            )

        cluster_id = parsed.get("clusterId")
        cluster_label = parsed.get("clusterLabel")
        if cluster_id is not None and not isinstance(cluster_id, str):
            raise ValueError(f"Invalid labeled dataset at line {index}: clusterId must be a string when present")
        if cluster_label is not None and not isinstance(cluster_label, str):
            raise ValueError(f"Invalid labeled dataset at line {index}: clusterLabel must be a string when present")

        parsed_rows.append(
            LabeledGoldenCase(
                case_id=case_id,
                input=input_text,
                expected=expected,
                actual=actual,
                label=label,
                failure_mode=failure_mode_value.strip() if isinstance(failure_mode_value, str) else None,
                labeled_at=labeled_at,
                cluster_id=cluster_id,
                cluster_label=cluster_label,
            )
        )

    return parsed_rows


def analyze_labeled_dataset(rows: list[LabeledGoldenCase], top: int = 5) -> AnalyzeSummary:
    total = len(rows)
    failed_rows = [row for row in rows if row.label == "fail"]
    failed = len(failed_rows)
    pass_rate = (total - failed) / total if total > 0 else 0.0
    counts: dict[str, int] = {}
    for row in failed_rows:
        mode = row.failure_mode.strip() if isinstance(row.failure_mode, str) and row.failure_mode.strip() else "failed_without_mode"
        counts[mode] = counts.get(mode, 0) + 1
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))[: max(1, top)]
    return AnalyzeSummary(
        total=total,
        failed=failed,
        pass_rate=pass_rate,
        failure_modes=[
            FailureModeSummary(mode=mode, count=count, frequency=(count / failed if failed > 0 else 0.0))
            for mode, count in ordered
        ],
    )


def format_analyze_human(summary: AnalyzeSummary) -> str:
    lines = [
        "Analyze phase",
        f"Total cases: {summary.total}",
        f"Failed: {summary.failed} ({((summary.failed / summary.total) * 100 if summary.total else 0.0):.1f}%)",
        f"Pass rate: {(summary.pass_rate * 100):.1f}%",
    ]
    if not summary.failure_modes:
        lines.append("Failure modes: none")
        return "\n".join(lines)
    lines.append("Top failure modes:")
    for index, item in enumerate(summary.failure_modes, start=1):
        lines.append(f"{index}. {item.mode} — {item.count} ({(item.frequency * 100):.1f}%)")
    return "\n".join(lines)


def write_jsonl(file_path: str, rows: list[LabeledGoldenCase | SyntheticGoldenCase]) -> None:
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    content = "\n".join(json.dumps(row.to_dict(), separators=(",", ":")) for row in rows)
    path.write_text(f"{content}\n" if content else "", encoding="utf-8")


def _string_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else str(value)


def _status_from_mapping(item: dict[str, Any]) -> RunStatus:
    status = item.get("status")
    if isinstance(status, str) and status in {"passed", "failed", "error", "timeout", "skipped"}:
        return status
    passed = item.get("passed")
    if isinstance(passed, bool):
        return "passed" if passed else "failed"
    return "failed"


def _normalize_ratio(value: Any) -> float | None:
    if not isinstance(value, (int, float)):
        return None
    ratio = float(value)
    if ratio > 1.0:
        ratio /= 100.0
    if ratio < 0.0:
        return 0.0
    if ratio > 1.0:
        return 1.0
    return ratio


def extract_run_metrics(run_data: dict[str, Any]) -> RunMetrics:
    summary = run_data.get("summary") if isinstance(run_data.get("summary"), dict) else {}
    if not isinstance(summary, dict):
        summary = {}
    pass_rate = _normalize_ratio(summary.get("correctedPassRate"))
    corrected_pass_rate = pass_rate
    raw_pass_rate = _normalize_ratio(summary.get("passRate"))
    if raw_pass_rate is None:
        raw_pass_rate = _normalize_ratio(summary.get("pass_rate"))
    if raw_pass_rate is None:
        total = summary.get("total")
        passed = summary.get("passed")
        if isinstance(total, int) and total > 0 and isinstance(passed, int):
            raw_pass_rate = passed / total
        else:
            results = run_data.get("results") if isinstance(run_data.get("results"), list) else []
            total_count = len(results)
            passed_count = 0
            for item in results:
                if isinstance(item, dict):
                    nested_result = item.get("result")
                    if isinstance(nested_result, dict):
                        status = nested_result.get("status")
                        if status == "passed":
                            passed_count += 1
                    elif item.get("passed") is True:
                        passed_count += 1
            raw_pass_rate = (passed_count / total_count) if total_count > 0 else 0.0
    if corrected_pass_rate is None:
        corrected_pass_rate = _normalize_ratio(summary.get("corrected_pass_rate"))
    if corrected_pass_rate is None:
        corrected_pass_rate = None
    total_cost_usd = summary.get("totalCostUsd")
    if total_cost_usd is None:
        total_cost_usd = summary.get("total_cost_usd")
    if total_cost_usd is not None and not isinstance(total_cost_usd, (int, float)):
        total_cost_usd = None
    total_results = summary.get("total") if isinstance(summary.get("total"), int) else None
    if total_results is None:
        results = run_data.get("results") if isinstance(run_data.get("results"), list) else []
        total_results = len(results)
    return RunMetrics(
        pass_rate_ratio=raw_pass_rate or 0.0,
        corrected_pass_rate_ratio=corrected_pass_rate,
        total_cost_usd=float(total_cost_usd) if isinstance(total_cost_usd, (int, float)) else None,
        total_results=total_results,
    )


def normalize_run_artifact(run_data: dict[str, Any]) -> NormalizedRunArtifact:
    results = run_data.get("results")
    if not isinstance(results, list):
        raise ValueError("Run artifact must contain a results array")

    normalized_cases: list[NormalizedRunCase] = []
    source_format = "legacy"
    for index, item in enumerate(results):
        if not isinstance(item, dict):
            continue
        if isinstance(item.get("result"), dict):
            source_format = "typescript"
            nested = item["result"]
            status = nested.get("status") if isinstance(nested.get("status"), str) else _status_from_mapping(item)
            case = NormalizedRunCase(
                case_id=_string_value(item.get("specId") or item.get("testId") or item.get("caseId") or item.get("id") or f"case-{index + 1}"),
                name=_string_value(item.get("name") or item.get("testName") or item.get("spec") or f"case-{index + 1}"),
                file_path=_string_value(item.get("filePath") or item.get("file_path") or ""),
                status=status,
                input=_string_value(item.get("input")),
                expected=_string_value(item.get("expected") or item.get("expectedOutput")),
                actual=_string_value(item.get("actual") or item.get("output") or nested.get("error")),
                passed=status == "passed",
                score=float(nested.get("score") or 0.0),
                duration_ms=float(nested.get("duration") or nested.get("durationMs") or item.get("durationMs") or 0.0),
                error=_string_value(nested.get("error")) or None,
                raw=item,
            )
        elif "test_id" in item or "testId" in item or "test_name" in item or "testName" in item:
            source_format = "python_run_report"
            status = _status_from_mapping(item)
            metadata = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
            case = NormalizedRunCase(
                case_id=_string_value(item.get("test_id") or item.get("testId") or f"case-{index + 1}"),
                name=_string_value(item.get("test_name") or item.get("testName") or f"case-{index + 1}"),
                file_path=_string_value(item.get("file_path") or item.get("filePath") or ""),
                status=status,
                input=_string_value(item.get("input") or metadata.get("input")),
                expected=_string_value(item.get("expected") or metadata.get("expected")),
                actual=_string_value(item.get("actual") or metadata.get("actual") or metadata.get("output") or item.get("error")),
                passed=bool(item.get("passed")),
                score=float(item.get("score") or 0.0),
                duration_ms=float(item.get("duration_ms") or item.get("durationMs") or 0.0),
                error=_string_value(item.get("error")) or None,
                raw=item,
            )
        else:
            status = _status_from_mapping(item)
            case = NormalizedRunCase(
                case_id=_string_value(item.get("specId") or item.get("test_id") or item.get("spec") or item.get("name") or f"case-{index + 1}"),
                name=_string_value(item.get("name") or item.get("spec") or item.get("test_name") or item.get("testName") or f"case-{index + 1}"),
                file_path=_string_value(item.get("file_path") or item.get("filePath") or ""),
                status=status,
                input=_string_value(item.get("input")),
                expected=_string_value(item.get("expected") or item.get("expectedOutput")),
                actual=_string_value(item.get("actual") or item.get("output") or item.get("error")),
                passed=bool(item.get("passed")),
                score=float(item.get("score") or 0.0),
                duration_ms=float(item.get("duration_ms") or item.get("durationMs") or 0.0),
                error=_string_value(item.get("error")) or None,
                raw=item,
            )
        normalized_cases.append(case)

    run_id = _string_value(run_data.get("runId") or run_data.get("run_id") or run_data.get("id") or "run-latest")
    metrics = extract_run_metrics(run_data)
    summary = run_data.get("summary") if isinstance(run_data.get("summary"), dict) else {}
    if not isinstance(summary, dict):
        summary = {}
    if "total" not in summary:
        summary["total"] = len(normalized_cases)
    if "passed" not in summary:
        summary["passed"] = sum(1 for case in normalized_cases if case.passed)
    if "failed" not in summary:
        summary["failed"] = sum(1 for case in normalized_cases if case.status == "failed")
    if "errors" not in summary:
        summary["errors"] = sum(1 for case in normalized_cases if case.status == "error")
    if "timeouts" not in summary:
        summary["timeouts"] = sum(1 for case in normalized_cases if case.status == "timeout")
    summary.setdefault("passRate", metrics.pass_rate_ratio)
    summary.setdefault("pass_rate", metrics.pass_rate_ratio * 100.0)
    if metrics.corrected_pass_rate_ratio is not None:
        summary.setdefault("correctedPassRate", metrics.corrected_pass_rate_ratio)
        summary.setdefault("corrected_pass_rate", metrics.corrected_pass_rate_ratio)
    return NormalizedRunArtifact(
        run_id=run_id,
        total_run_results=len(normalized_cases),
        summary=summary,
        cases=normalized_cases,
        source_format=source_format,
    )
