#include "mProcess.h"
#include <stdlib.h>
#include <Psapi.h> //https://learn.microsoft.com/de-de/windows/win32/psapi/psapi-reference


// ------ fill vtable ---

static void _destroy_process(process_t *self) {

        if (self->hProcess) {
                CloseHandle(self->hProcess);
                self->hProcess = NULL;
        }

}

static process_vtable_t _process_vtable = {
        .destroy = _destroy_process,
};

// ------ public ---

void newProcess(process_t *self) {
        self->vtable = &_process_vtable;
        self->pid = GetCurrentProcessId();
        self->hProcess = OpenProcess(
                PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                FALSE,
                self->pid
        );
}

void destroyProcess(process_t *self) {
        if (self->vtable && self->vtable->destroy) {
                self->vtable->destroy(self);
        }
}