from mWinPy import Process

__all__ = [
    "Process"
]