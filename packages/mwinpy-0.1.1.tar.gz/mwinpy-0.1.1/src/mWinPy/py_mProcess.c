#include "py_types.h"
#include "mProcess.h"
#include <stdlib.h>

// --------------------------------------------------------------- dealloc --

static void PyProcess_dealloc(PyProcess *self) {
    if (self->proc) {
        destroyProcess(self->proc);
        free(self->proc);
        self->proc = NULL;
    }
    Py_TYPE(self)->tp_free((PyObject *)self);
}

// ------------------------------------------------------------------ init --

static int PyProcess_init(PyProcess *self, PyObject *args, PyObject *kw) {
    self->proc = calloc(1, sizeof(process_t));
    if (!self->proc) {
        PyErr_NoMemory();
        return -1;
    }
    newProcess(self->proc);
    return 0;
}

// ------------------------------------------------------------- properties --

static PyObject *PyProcess_get_pid(PyProcess *self, void *closure) {
    return PyLong_FromUnsignedLong(self->proc->pid);
}

static PyObject *PyProcess_get_handle(PyProcess *self, void *closure) {
    return PyLong_FromVoidPtr(self->proc->hProcess);
}

static PyGetSetDef PyProcess_getset[] = {
    {
        "pid",
        (getter)PyProcess_get_pid,
        NULL,
        "process ID",
        NULL
    },
    {
        "handle",
        (getter)PyProcess_get_handle,
        NULL,
        "native HANDLE as int",
        NULL
    },
    {NULL}
};

// ---------------------------------------------------------------- methods --

static PyObject *PyProcess_destroy(PyProcess *self, PyObject *_) {
    if (self->proc) {
        destroyProcess(self->proc);
        free(self->proc);
        self->proc = NULL;
    }
    Py_RETURN_NONE;
}

static PyMethodDef PyProcess_methods[] = {
    {
        "destroy",
        (PyCFunction)PyProcess_destroy,
        METH_NOARGS,
        "destroy() -> None\nRelease the process handle."
    },
    {NULL}
};

// ------------------------------------------------------------------ repr --

static PyObject *PyProcess_repr(PyProcess *self) {
    if (!self->proc)
        return PyUnicode_FromString("<Process (destroyed)>");
    return PyUnicode_FromFormat("<Process pid=%lu handle=%p>",
        self->proc->pid,
        self->proc->hProcess
    );
}

// -------------------------------------------------------------- richcmp  --
// lets Python do:  proc_a == proc_b  (same PID = same process)

static PyObject *PyProcess_richcmp(PyProcess *self, PyObject *other, int op) {
    if (!PyObject_TypeCheck(other, &PyProcessType))
        Py_RETURN_NOTIMPLEMENTED;

    PyProcess *b = (PyProcess *)other;

    int eq = (self->proc && b->proc && self->proc->pid == b->proc->pid);

    switch (op) {
        case Py_EQ: return PyBool_FromLong( eq);
        case Py_NE: return PyBool_FromLong(!eq);
        default:    Py_RETURN_NOTIMPLEMENTED;
    }
}

// ------------------------------------------------------------ type object --

PyTypeObject PyProcessType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    .tp_name      = "_mWinPy.Process",
    .tp_doc       = "Windows process.\n\nWraps the current process PID and HANDLE.",
    .tp_basicsize = sizeof(PyProcess),
    .tp_flags     = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE,
    .tp_new       = PyType_GenericNew,
    .tp_init      = (initproc)PyProcess_init,
    .tp_dealloc   = (destructor)PyProcess_dealloc,
    .tp_repr      = (reprfunc)PyProcess_repr,
    .tp_richcompare = (richcmpfunc)PyProcess_richcmp,
    .tp_methods   = PyProcess_methods,
    .tp_getset    = PyProcess_getset,
};