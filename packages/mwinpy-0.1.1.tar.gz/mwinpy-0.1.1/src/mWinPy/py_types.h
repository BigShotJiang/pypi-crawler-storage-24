#pragma once

#define PY_SSIZE_T_CLEAN
#include <Python.h>

#include "mProcess.h"

// ================================================================ PyProcess

typedef struct {
        PyObject_HEAD
        process_t *proc;
} PyProcess;

extern PyTypeObject PyProcessType;