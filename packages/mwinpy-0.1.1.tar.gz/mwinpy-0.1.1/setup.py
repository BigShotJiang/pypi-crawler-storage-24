import os
from setuptools import Extension, setup

# 1. Handle Windows SDK / MSVC Paths
SDK     = os.environ.get("WindowsSdkDir",    r"C:\Program Files (x86)\Windows Kits\10")
SDK_VER = os.environ.get("WindowsSDKVersion", "10.0.26100.0").strip("\\")
MSVC    = os.environ.get("VCToolsInstallDir", "").rstrip("\\")

include_dirs = ["src/mWinPy"]
library_dirs = []

if SDK and SDK_VER:
    include_dirs += [
        os.path.join(SDK, "Include", SDK_VER, "ucrt"),
        os.path.join(SDK, "Include", SDK_VER, "shared"),
        os.path.join(SDK, "Include", SDK_VER, "um"),
    ]
    library_dirs += [
        os.path.join(SDK, "Lib", SDK_VER, "ucrt", "x64"),
        os.path.join(SDK, "Lib", SDK_VER, "um", "x64"),
    ]

if MSVC:
    include_dirs.append(os.path.join(MSVC, "include"))
    library_dirs.append(os.path.join(MSVC, "lib", "x64"))

# 2. Define the Extension
ext = Extension(
    name="mWinPy._mWinPy",
    sources=[
        "src/mWinPy/_mWinPy.c",
        "src/mWinPy/mProcess.c",
        "src/mWinPy/py_mProcess.c",
    ],
    include_dirs=include_dirs,
    library_dirs=library_dirs,
    libraries=["user32", "psapi"],
)

setup(
    ext_modules=[ext],
)