"""MCP server for Datadog — placeholder, full version coming soon."""

def main() -> None:
    print("mcparmory-datadog: full server coming soon. See https://mcparmory.com")

if __name__ == "__main__":
    main()
