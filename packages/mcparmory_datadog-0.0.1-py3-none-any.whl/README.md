# mcparmory-datadog

MCP server for Datadog.

Full version coming soon. See [mcparmory.com](https://mcparmory.com)
