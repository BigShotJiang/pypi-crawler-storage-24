# Poligon — Practice Simulator

Part of the Megdan CTF Line.

Poligon is a CTF practice simulator for digital forensics training and competition preparation.

> Placeholder release — full build coming soon.

## Megdan CTF Line

| Package | Role |
|---|---|
| **Phalanx** | CTF dashboard |
| **Treska** | CTF parser |
| **Poligon** | Practice simulator |

## Author

GitHub: [ShadowStrike-CTF](https://github.com/ShadowStrike-CTF)
