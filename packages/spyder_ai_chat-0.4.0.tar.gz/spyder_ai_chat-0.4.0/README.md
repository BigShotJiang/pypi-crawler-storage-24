# Spyder AI Chat Plugin

An OpenAI-compatible chat pane for **Spyder 6.x**.
Supports **12 providers out of the box** — OpenAI, Groq, Mistral, DeepSeek, Together AI, Fireworks AI, OpenRouter, Azure OpenAI, Ollama, LM Studio, vLLM, and any custom OpenAI-compatible endpoint — all from inside your IDE without switching windows.

© 2026 Maciej Piecko — MIT License

---

## Features

| Feature | Details |
|---|---|
| 🗨️ Chat UI | Scrollable conversation with colour-coded user / assistant messages |
| ⚡ Streaming | Token-by-token streaming with incremental markdown rendering — completed blocks are formatted live as they arrive |
| 🔁 Model selector | Dropdown populated live from the API — switch models instantly |
| 🔧 12 providers | OpenAI, Groq, Mistral, DeepSeek, Together, Fireworks, OpenRouter, Azure, Ollama, LM Studio, vLLM, Custom |
| ⚙ Inference parameters | Per-chat temperature, max tokens, top-p, top-k, min-p, penalties, seed, num_ctx — provider-aware (only relevant params shown) |
| 🔑 Optional API key | Leave blank for local models that require no authentication |
| 🧠 System prompt | Custom system prompt field, or select from a saved prompts library |
| 💬 Saved system prompts | Define reusable system prompts; manage via Settings → System Prompts tab |
| ⏹ Stop | Cancel a streaming reply at any time |
| 🗑 New Chat | Start a fresh conversation; the current one is saved automatically |
| 📋 Chat history | Browse, load, and delete saved chats; active chat highlighted in green |
| 📎 File context | Attach whole files or selected text from the editor as context |
| 🖊️ Markdown rendering | Headings, bold, italic, tables, code blocks (with horizontal scroll), blockquotes, links, strikethrough |
| 🗂 Nested lists | Arbitrarily deep bullet & numbered lists, mixed types, blank-line-separated items |
| 🧠 Thinking blocks | `<think>` tags rendered as a collapsible scrollable thinking box (DeepSeek-R1, QwQ, Qwen-thinking …) |
| 📋 Copy to editor | Insert any code block or full response at the cursor in the active file |
| 🗑 Delete exchange | Remove any exchange with a 3-second undo window; or clear all exchanges before a point |
| 🔄 Regenerate | Re-run the last assistant response with one click |
| ⚙ Settings | Tabbed dialog: provider connection, dialog font sizes, history options, system prompts library, slash commands, AI auto-complete |
| / Commands | Define slash-command aliases (e.g. `/tests`, `/explain`) — type `/` in input to get a picker dropdown; commands expand to full prompts before sending |
| ✍️ AI auto-complete | FIM (fill-in-middle) ghost-text completions in the editor — supports Ollama, LM Studio, vLLM, DeepSeek, Codestral/Mistral, OpenRouter, and custom endpoints |

---

## Installation

### Install from source (recommended while in development)

```bash
# Unzip the release archive, then:
cd spyder_ai_chat
pip install -e .
```

> **Important:** install into the **same Python environment that Spyder uses**.
> If you launched Spyder from a conda environment, activate that environment first.

After installation, **restart Spyder**.
The plugin appears automatically; if the pane is not visible go to
**Window → Panes → AI Chat** to show it.

---

## Configuration

Click the **⚙ Settings** button in the plugin pane toolbar to open the tabbed settings dialog.

### Tab 1 — Connection

Select your provider from the dropdown. The form updates automatically to show only the fields relevant to that provider.

| Provider | Default URL | API key |
|---|---|---|
| OpenAI | `https://api.openai.com/v1` | Required |
| Groq | `https://api.groq.com/openai/v1` | Required |
| Mistral AI | `https://api.mistral.ai/v1` | Required |
| DeepSeek | `https://api.deepseek.com` | Required |
| Together AI | `https://api.together.xyz/v1` | Required |
| Fireworks AI | `https://api.fireworks.ai/inference/v1` | Required |
| OpenRouter | `https://openrouter.ai/api/v1` | Required |
| Azure OpenAI | `https://<resource>.openai.azure.com/…` | Required + deployment name + API version |
| Ollama (local) | `http://localhost:11434/v1` | Not required |
| LM Studio (local) | `http://localhost:1234/v1` | Optional |
| vLLM | `http://localhost:8000/v1` | Optional |
| Custom | *(any URL)* | Optional |

A **Test Connection** button sends a `GET /models` probe to the configured endpoint and reports how many models are available, helping verify credentials and reachability before saving.

### Tab 2 — Dialogs

Configure font sizes (6–24 pt) for each rendered element independently:

| Setting | Default | Affects |
|---|---|---|
| Base text | 10 pt | Paragraphs, blockquotes |
| Code blocks | 10 pt | Fenced code block content |
| Headings (H1 base) | 14 pt | H1 = base, H2 = base−2, H3 = base−4 |
| Lists | 10 pt | Bullet and numbered lists |
| Tables | 10 pt | Table header and data cells |
| Thinking box | 9 pt | `<think>` block content |

Changes apply to new messages rendered after saving.

### Tab 3 — History

- **Automatically save chats to history** — when on, every completed exchange is written to disk silently.
- **Save unsent chat when starting New Chat** — only relevant when auto-save is off; gives a one-time save at the moment you click New Chat.

### Tab 4 — System Prompts

Manage reusable system prompts. Selecting a prompt from the dropdown immediately opens it for editing. The **💾 Save prompt** button activates only when the title or content has been modified. Use **+ New** to create a prompt and **Delete** to remove the currently selected one.

### Tab 5 — Commands

Define slash-command aliases for the chat input field. Type `/` in the input box to open the command picker dropdown and select a command — it is inserted as a short token (e.g. `/tests`) that expands to its full prompt text before being sent to the LLM.

Selecting a command from the list immediately opens it for editing. The **Save command** button activates only when the name or prompt has been changed.

- **+ New** — create a new command (name ≥ 2 characters, no leading `/`)
- **Delete** — remove the currently selected command
- **Restore built-in defaults** — resets the 5 built-in commands (`/tests`, `/simplify`, `/fix`, `/explain`, `/doc`) to their default prompts without affecting user-defined commands

Commands are stored in `~/.spyder_ai_chat/commands.json`.

### Tab 6 — Auto-complete

Configure AI-powered fill-in-middle (FIM) ghost-text completions in the Spyder code editor. Auto-complete is **disabled by default** and requires explicit setup.

**Setup steps:**

1. Check **Enable AI auto-completion in the editor**.
2. Select a **Provider** and enter the **API URL** (pre-filled for known providers).
3. Click **Load Models** — the plugin fetches the model list and probes which FIM backends the endpoint supports.
4. Choose a **Model** and **Backend type** from the populated dropdowns.

**Backend types** (probed automatically, working ones shown first):

| Backend | Endpoint | Notes |
|---|---|---|
| Ollama /api/generate | `/api/generate` | Native FIM — best choice for Ollama |
| OpenAI-compat /v1/completions | `/v1/completions` | Legacy completions — LM Studio, vLLM |
| Codestral /v1/fim/completions | `/v1/fim/completions` | Mistral / Codestral native FIM |
| Chat completions | `/v1/chat/completions` | Prompt-injection fallback — any provider |

**Model Parameters:** max tokens, temperature, context window before/after cursor.

**Trigger modes:**
- *Auto* — completion fires after a configurable debounce delay (default 600 ms)
- *After new line only* — fires only when a newline is typed
- *Manual only* — press **Alt+\\** to request a completion

Ghost text appears in grey after the cursor. Press **Tab** to accept, **Escape** to dismiss.

---

## Usage

### Sending messages

1. Type your message in the input box at the bottom.
2. Press **Ctrl+Enter** or click **Send**.
3. The assistant's reply streams in above in real time.
4. Click **Stop** to cancel a reply mid-stream.

### Inference parameters

Click the **inference params bar** (the thin bar above the system prompts row) to open the per-chat parameters popup. Only the parameters supported by the selected provider are shown. Parameters set here override the provider's defaults for this chat session. When active, the bar turns amber and shows a summary of the values set. Starting a new chat resets parameters to defaults.

### Model selection

Click the model name button at the top of the pane to open the model dropdown.
Click **⟳** to refresh the model list from the API.

### System prompt

Type a system prompt in the field above the input box, or select a saved prompt from the **System prompts:** dropdown. Click **↓📋 Copy and edit** to copy a saved prompt into the editable field for customisation.

### Adding file context

Right-click in any editor tab to access the **AI Chat** submenu:

- **Add whole file to context** — attaches the current file's full content.
- **Add selection to context** — attaches the currently highlighted text.

Context tags appear above the input box and can be dismissed before sending. Once sent, they become locked badges (📎 for files, ✂ for selections) displayed inside the user message bubble.

### Chat history

Click the checklist icon (🗒) in the toolbar to open the chat history popup.

- **Click an entry** to load that chat.
- **✕** — delete a chat (3-second countdown with Cancel).
- **🗑 Delete all** — hover for 2 seconds to unlock, then a 3-second countdown before deletion.
- The **active chat** is highlighted green.

Chats are saved to `~/.spyder_ai_chat/chats/`.

### AI auto-complete (FIM ghost text)

Once configured in **Settings → Auto-complete**, ghost-text suggestions appear automatically while typing in the editor.

- **Tab** — accept the full suggestion
- **Escape** — dismiss the suggestion
- **Alt+\\** — manually request a completion (when trigger mode is *Manual only*)

The completion uses the code before and after the cursor as context (configurable character limits).

### Markdown rendering

- **Headings** H1–H3 with scaled sizes
- **Bold**, *italic*, ***bold+italic***, ~~strikethrough~~, `inline code`
- Bullet and numbered lists with **arbitrary nesting** — cycling symbols (`•`, `◦`, `▪`, `▸`)
- Blockquotes with blue left border
- Fenced code blocks with language label, **Copy to editor** button, and **horizontal scrollbar** for long lines
- Tables with header row and alternating row shading
- Clickable hyperlinks
- `<think>...</think>` blocks rendered as a collapsible **Thinking** box with scrollbar — works with DeepSeek-R1, QwQ, Qwen-thinking variants

### Ollama quick-start

```bash
ollama serve          # starts the server on port 11434
ollama pull llama3    # download a model
```

In **Settings → Connection** select **Ollama (local)**. URL is pre-filled; leave the API key blank.

---

## Data storage

All plugin data is stored under `~/.spyder_ai_chat/`:

| Path | Contents |
|---|---|
| `state.json` | Provider type, API URL, selected model, model list cache, editor font sizes, history settings, FIM configuration |
| `chats/` | One JSON file per saved chat session |
| `system_prompts.json` | Saved system prompts library |
| `commands.json` | Slash-command aliases |

---

## Project structure

```
spyder_ai_chat/
├── pyproject.toml               # Build config, version 0.4.0, author, license
├── README.md                    # This file
├── README_PYPI.md               # PyPI landing page description
├── LICENSE                      # MIT
└── spyder_ai_chat/
    ├── __init__.py              # Package init
    ├── plugin.py                # SpyderDockablePlugin subclass —
    │                            #   Spyder integration, editor context
    │                            #   menu injection, FIM ghost-text wiring
    ├── confpage.py              # Preferences page (reserved for future use)
    ├── fim/
    │   ├── __init__.py
    │   ├── client.py            # HTTP FIM client:
    │   │                        #   multi-backend request/response handling
    │   │                        #   (Ollama, OpenAI-compat, Codestral, chat fallback)
    │   ├── config.py            # FIM configuration dataclass:
    │   │                        #   provider, URL, API key, model, backend type,
    │   │                        #   max tokens, temperature, context window,
    │   │                        #   trigger mode, debounce delay
    │   ├── ghost_text.py        # Ghost-text rendering:
    │   │                        #   inline grey suggestion overlay in the editor,
    │   │                        #   Tab to accept, Escape to dismiss,
    │   │                        #   cursor-offset fix for \r\n line endings
    │   ├── provider.py          # FIM completion provider:
    │   │                        #   AiFimProvider (Spyder completions API),
    │   │                        #   debounce timer, trigger-mode dispatcher,
    │   │                        #   Escape ShortcutOverride intercept
    │   └── widgets/
    │       ├── __init__.py
    │       └── status.py        # FIM status-bar widget:
    │                            #   shows active model / provider in the editor status bar
    └── widgets/
        ├── __init__.py
        ├── chat_widget.py          # Main chat panel UI:
        │                           #   streaming API worker, model popup,
        │                           #   chat history popup, inference params popup,
        │                           #   file context bar, system prompt selector,
        │                           #   bottom panel layout, state persistence
        ├── chat_history_manager.py # File-per-chat JSON storage:
        │                           #   save / load / delete / list chats
        ├── markdown_renderer.py    # Markdown → Qt widgets renderer:
        │                           #   headings, paragraphs, recursive nested lists,
        │                           #   tables, code blocks (QPlainTextEdit + h-scroll),
        │                           #   blockquotes, think blocks (scrollable),
        │                           #   inline formatting, configurable font sizes
        ├── settings_dialog.py      # Tabbed settings dialog:
        │                           #   provider registry (12 providers + param defs),
        │                           #   Connection tab (dynamic form + Test Connection),
        │                           #   Dialogs font sizes, History options,
        │                           #   System Prompts & Commands (auto-edit on select,
        │                           #   dirty-save tracking), Auto-complete FIM tab
        ├── system_prompts.py       # Saved system prompts CRUD:
        │                           #   load / save / new / update / delete,
        │                           #   persisted to ~/.spyder_ai_chat/system_prompts.json
        └── commands.py             # Slash-command definitions:
                                    #   load / save / defaults,
                                    #   persisted to ~/.spyder_ai_chat/commands.json
```

---

## Requirements

- Python ≥ 3.9
- Spyder ≥ 6.0
- No extra Python packages — uses only `urllib` from the standard library for HTTP and Qt (already bundled with Spyder) for the UI.

---

## Changelog

### 0.4.0
- **Processing spinner** — a braille spinner (`⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏`) is shown in the chat panel while waiting for the first LLM token; it disappears and the streaming response appears as soon as the first character arrives
- **Incremental markdown rendering** — the response is formatted in real time as it streams: completed blocks (headings, paragraphs, code fences, tables, blockquotes, think boxes) are promoted to rendered Qt widgets immediately; only the trailing incomplete block remains as live plain text
- **HTTP error display** — API errors (e.g. HTTP 403/500) now appear in a visually distinct dark-red box with an "⚠ Response error" header instead of unstyled text; no spurious empty "Assistant:" block is created on error
- **Delete on error blocks** — the delete button on an error response block now works correctly (previously a message-index mismatch caused it to silently fail)
- **Regenerate on error** — the Regenerate button now appears on error response blocks, allowing an immediate retry without clearing the conversation

### 0.3.2
- **Plugin entry-point renamed** from `ai_chat` to `ai_chat_plugin` (`spyder.plugins` entry point in `pyproject.toml`); FIM provider entry-point renamed from `ai_fim` to `ai_fim_provider` (`spyder.completions` entry point)
- **`NAME` and `CONF_SECTION`** in `AIChatPlugin` updated to `"ai_chat_plugin"` to stay consistent with the entry-point key
- **`COMPLETION_PROVIDER_NAME` and `CONF_SECTION`** in `AiFimProvider` updated to `"ai_fim_provider"` and `"ai_chat_plugin"` respectively

### 0.3.1
- **Settings → ⚡ Auto-complete tab** completely redesigned as a step-by-step wizard: enable checkbox → set provider/URL/key → **Load Models** → pick model + backend; previous tab was a flat form with no guidance
- **Load Models button** with braille spinner animation fetches the model list and automatically probes which FIM backends the endpoint supports; backend probe validates the response body (not just HTTP status 200) to avoid false positives from providers that return `{"error":…}` on unsupported endpoints
- **Model list and backend list persistence**: full dropdown contents saved to config on OK; restored on next open without needing to re-run Load Models
- **Test Connection button** added to the Connection tab — sends a `GET /models` probe and reports the number of available models; uses an OpenAI-SDK-style `User-Agent` header to avoid Cloudflare 403 (error 1010) blocks
- **Settings window** width increased by ~10%; tab bar stretches edge-to-edge with uniform padding
- **"🖊 Dialogs" tab** (renamed from "🖊 Editor") with descriptive info label at the top
- **System Prompts tab**: Edit button removed; selecting a prompt from the dropdown immediately enables editing; **💾 Save prompt** activates only when title or content has been modified
- **Commands tab**: Edit button removed; selecting a command immediately enables editing; **Save command** activates only when name or prompt has been modified
- **FIM cursor-offset fix**: cursor position now derived from `(blockNumber, columnNumber)` and converted with a line-ending-aware helper, eliminating stale completions when files use `\r\n` endings
- **Editor context menu** (Add file / Add selection) fixed: items re-injected on every `aboutToShow` event to survive Spyder's menu rebuild cycle
- **FIM default values**: temperature default changed to 0.5, context before/after cursor default changed to 100 characters

### 0.3.0
- **AI auto-complete (FIM)** — fill-in-middle ghost-text completions in the Spyder code editor (`fim/provider.py`); registered as a `spyder.completions` entry point
- **Ghost-text rendering**: grey inline suggestion after the cursor; **Tab** to accept, **Escape** to dismiss
- **Multi-backend support**: Ollama `/api/generate`, OpenAI-compat `/v1/completions`, Codestral `/v1/fim/completions`, chat-completions fallback
- **Trigger modes**: auto (debounce), after-newline, manual (**Alt+\\**)
- **Settings → FIM tab**: provider, URL, API key, model, backend type, max tokens, temperature, context window, trigger mode, debounce delay
- **Escape key fix**: intercepts `ShortcutOverride` event to prevent Spyder's global Escape shortcut from stealing the dismiss keystroke before the FIM provider can handle it
- Fixed: editor context-menu items "Add whole file to context" and "Add selection to context" now reliably appear and call the correct attachment handler

### 0.2.1
- **Slash-command aliases** (`commands.py`): define short aliases (e.g. `/tests`, `/explain`) that expand to full prompt text before being sent to the LLM; type `/` in the input to open a keyboard-navigable picker dropdown
- **5 built-in commands**: `/tests`, `/simplify`, `/fix`, `/explain`, `/doc` — auto-seeded on first run to `~/.spyder_ai_chat/commands.json`
- **Settings → / Commands tab**: create, edit, delete, and restore built-in commands; restoring built-ins does not affect user-defined commands
- **Command highlighting**: active command tokens shown with a green highlight in the input field and in sent chat bubbles
- **Chat history**: command spans stored in JSON (`command_spans`); original expanded prompt preserved in `content_llm` so history replay is correct even if a command is later edited or deleted
- **Chat history preview**: command-only messages now show `/command — filename.py` (attachment), `/command — user text`, or `/command — at yyyy-mm-dd hh:mm` (timestamp fallback) instead of the bare command name
- **LM Studio API key**: now optional (previously hidden) — shown in Connection tab for setups with authentication enabled
- **Connection tab UI**: added "Only one provider can be active at a time." info label, horizontal separator, and "Configure active provider:" label above the provider form
- **Settings → Connection tab**: rebuilt to use permanent form rows with show/hide instead of takeRow/addRow on provider switch (layout stability improvement)

### 0.2.0
- **12-provider support** with a provider registry in `settings_dialog.py`: OpenAI, Groq, Mistral AI, DeepSeek, Together AI, Fireworks AI, OpenRouter, Azure OpenAI, Ollama, LM Studio, vLLM, Custom — each with its own default URL, API key requirement, and supported inference parameters
- **Provider dropdown with grouping**: Local (Ollama, LM Studio, vLLM) / Cloud API / Custom sections with non-selectable separator headers
- **Per-chat inference hyperparameters popup**: temperature, max_tokens, top_p, top_k, min_p, presence_penalty, frequency_penalty, repetition_penalty, seed, num_ctx — only parameters supported by the selected provider are displayed; popup anchors above the params bar
- **Inference params bar** always visible above the system prompts row: idle state shows muted hint text; amber summary text when params are active; clicking opens the popup; resets on New Chat
- **Bottom panel redesign**: inference params bar → system prompts row (label + combo + ⚙ settings shortcut + Copy and edit) → system prompt field → input row (text field + stacked Send/Stop buttons)
- **⚙ shortcut** in system prompts row opens Settings directly on the System Prompts tab
- **Send/Stop stacked layout**: Send button takes ~66% of height, Stop ~34%, separated by 4 px gap
- Azure OpenAI extra fields (deployment name, API version) now correctly hide when switching away from the Azure provider
- Thinking block now uses a scrollable `QPlainTextEdit` (max-height 200 px) — eliminates all previous word-wrap and height-calculation issues
- Code blocks now use `QPlainTextEdit` with `NoWrap` mode and a horizontal scrollbar — long lines no longer clip
- Delete-all warmup reduced from 2 s hover to 1 s hover

### 0.1.9
- **Delete exchange buttons** on every user and assistant message: `🗑 This` removes the user+assistant pair, `⏫ All before` removes all preceding exchanges; both have a 3-second countdown with `↩ Cancel`
- **🔄 Regenerate button** on the last assistant message; moves automatically after deletion or regeneration
- Fixed: scroll position anchors to the bottom after markdown re-render completes
- Fixed: `clear_all` method restored; chat history loading no longer raises `AttributeError`

### 0.1.8
- New **Saved System Prompts** library (`system_prompts.py`)
- **Settings → 💬 System Prompts** tab: create, edit, delete saved prompts
- **Prompt selector bar** with dropdown and **📋 Copy to field** button
- Chat history stores `prompt_id`; restored on load

### 0.1.7
- Fully recursive list parser; mixed bullet/numbered types at any depth; blank-line-separated items
- Bullet symbols cycle by depth: `•` `◦` `▪` `▸`
- Numbered lists preserve source numbers
- Fixed: auto-scroll to bottom on send and during streaming
- Fixed: short responses no longer float in the middle of the chat area

### 0.1.6
- Menu path corrected: **Window → Panes → AI Chat**

### 0.1.5
- PyPI `README_PYPI.md` added; `[project.urls]` Homepage field in `pyproject.toml`

### 0.1.4
- Tabbed settings dialog: Connection, Editor, History tabs
- Configurable font sizes for all rendered markdown elements
- History saving options with correct enable/disable logic
- Horizontal scrollbar in chat area for wide code blocks
- File/text context attachments restructured; locked badges in user message bubbles

### 0.1.3
- `User-Agent` header added to fix 403 errors with Groq and some providers
- Improved HTTP error reporting

### 0.1.2
- Full markdown rendering (`markdown_renderer.py`): headings, bold/italic, lists, tables, blockquotes, links, strikethrough
- `<think>` block support with collapsible thinking box
- Chat history: save, load, delete, browse
- Auto-save after every completed exchange
- Editor context menu: Add whole file / Add selection to context

### 0.1.0
- Initial release: streaming chat, model selector, system prompt, stop button, code block rendering with Copy to editor

---

## License

MIT — see `LICENSE` file.
