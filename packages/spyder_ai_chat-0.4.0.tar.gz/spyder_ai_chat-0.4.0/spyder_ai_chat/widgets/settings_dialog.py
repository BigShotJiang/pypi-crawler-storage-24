# -*- coding: utf-8 -*-
"""Settings dialog for AI Chat plugin (C) 2026 by Maciej Piecko"""

from qtpy.QtWidgets import (
    QDialog, QTabWidget, QWidget, QFormLayout, QVBoxLayout, QHBoxLayout,
    QLineEdit, QLabel, QDialogButtonBox, QSpinBox, QDoubleSpinBox, QCheckBox,
    QComboBox, QPlainTextEdit, QPushButton, QFrame, QSizePolicy,
    QGroupBox, QListWidget, QListWidgetItem,
)
from qtpy.QtCore import Qt, QThread, QTimer, Signal
from qtpy.QtGui import QFont, QBrush, QColor

from .system_prompts import (
    load_prompts, new_prompt, update_prompt, delete_prompt, CUSTOM_ID,
)
from .commands import load_commands, save_commands, DEFAULT_COMMANDS


# ---------------------------------------------------------------------------
# Provider registry — single source of truth for all provider metadata.
# Each entry defines connection fields and supported inference parameters.
# ---------------------------------------------------------------------------

# Master list of all possible inference parameters across all providers.
# Each entry: (param_id, display_label, type, range/options, tooltip)
PARAM_DEFS = {
    "temperature": (
        "Temperature", "float", (0.0, 2.0),
        "Randomness of output. 0 = deterministic, higher = more creative."
    ),
    "max_tokens": (
        "Max tokens", "int", (1, 128000),
        "Maximum number of tokens in the response. Leave at 0 to use provider default."
    ),
    "top_p": (
        "Top-p", "float", (0.0, 1.0),
        "Nucleus sampling. Only consider tokens in the top p% of probability mass."
    ),
    "top_k": (
        "Top-k", "int", (1, 200),
        "Only sample from the top K most likely tokens."
    ),
    "min_p": (
        "Min-p", "float", (0.0, 1.0),
        "Minimum probability threshold relative to the top token."
    ),
    "presence_penalty": (
        "Presence penalty", "float", (-2.0, 2.0),
        "Penalise tokens that have already appeared at all (encourages new topics)."
    ),
    "frequency_penalty": (
        "Frequency penalty", "float", (-2.0, 2.0),
        "Penalise tokens proportional to how often they have appeared (reduces repetition)."
    ),
    "repetition_penalty": (
        "Repetition penalty", "float", (0.0, 2.0),
        "Multiplicative penalty for repeated tokens (1.0 = no penalty)."
    ),
    "seed": (
        "Seed", "int", (0, 2**31 - 1),
        "Random seed for reproducible outputs. 0 = random."
    ),
    "num_ctx": (
        "Context window (num_ctx)", "int", (512, 131072),
        "Ollama: number of tokens of context the model uses. Default is model-dependent."
    ),
}

# Provider definitions
PROVIDERS = {
    "openai": {
        "label":         "OpenAI",
        "default_url":   "https://api.openai.com/v1",
        "url_editable":  False,
        "needs_api_key": True,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p",
            "presence_penalty", "frequency_penalty", "seed",
        ],
        "param_warnings": {},
        "temperature_max": 2.0,
        "notes": "",
    },
    "groq": {
        "label":         "Groq",
        "default_url":   "https://api.groq.com/openai/v1",
        "url_editable":  False,
        "needs_api_key": True,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p", "seed",
        ],
        "param_warnings": {
            "presence_penalty": "Accepted by API but currently has no effect on Groq.",
            "frequency_penalty": "Accepted by API but currently has no effect on Groq.",
        },
        "temperature_max": 2.0,
        "notes": "max_tokens is sent as max_completion_tokens automatically.",
    },
    "mistral": {
        "label":         "Mistral AI",
        "default_url":   "https://api.mistral.ai/v1",
        "url_editable":  False,
        "needs_api_key": True,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p",
            "presence_penalty", "seed",
        ],
        "param_warnings": {},
        "temperature_max": 1.0,
        "notes": "Temperature range is 0–1. Values above 0.7 are not recommended.",
    },
    "deepseek": {
        "label":         "DeepSeek",
        "default_url":   "https://api.deepseek.com",
        "url_editable":  False,
        "needs_api_key": True,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p",
            "presence_penalty", "frequency_penalty", "seed",
        ],
        "param_warnings": {},
        "temperature_max": 2.0,
        "notes": (
            "⚠ Reasoning models (deepseek-reasoner) ignore temperature, top_p "
            "and penalty parameters — they are accepted but have no effect."
        ),
    },
    "together": {
        "label":         "Together AI",
        "default_url":   "https://api.together.xyz/v1",
        "url_editable":  False,
        "needs_api_key": True,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p",
            "top_k", "repetition_penalty", "seed",
        ],
        "param_warnings": {},
        "temperature_max": 2.0,
        "notes": "",
    },
    "fireworks": {
        "label":         "Fireworks AI",
        "default_url":   "https://api.fireworks.ai/inference/v1",
        "url_editable":  False,
        "needs_api_key": True,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p", "top_k",
            "presence_penalty", "frequency_penalty", "seed",
        ],
        "param_warnings": {},
        "temperature_max": 2.0,
        "notes": (
            "If max_tokens exceeds the context window, "
            "Fireworks automatically truncates the prompt rather than returning an error."
        ),
    },
    "openrouter": {
        "label":         "OpenRouter",
        "default_url":   "https://openrouter.ai/api/v1",
        "url_editable":  False,
        "needs_api_key": True,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p", "top_k", "min_p",
            "presence_penalty", "frequency_penalty", "repetition_penalty", "seed",
        ],
        "param_warnings": {},
        "temperature_max": 2.0,
        "notes": (
            "OpenRouter routes to 300+ models. Use model names like "
            "openai/gpt-4o or meta-llama/llama-3.1-70b-instruct. "
            "Unsupported parameters are silently ignored per model."
        ),
    },
    "ollama": {
        "label":         "Ollama (local)",
        "default_url":   "http://localhost:11434/v1",
        "url_editable":  True,
        "needs_api_key": False,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p",
            "top_k", "seed", "num_ctx",
        ],
        "param_warnings": {},
        "temperature_max": 2.0,
        "notes": (
            "Default temperature in Ollama is 0.8 (higher than OpenAI's 1.0). "
            "Use num_ctx to increase the context window beyond the model's default."
        ),
    },
    "lmstudio": {
        "label":         "LM Studio (local)",
        "default_url":   "http://localhost:1234/v1",
        "url_editable":  True,
        "needs_api_key": True,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p", "top_k",
            "presence_penalty", "frequency_penalty", "seed",
        ],
        "param_warnings": {},
        "temperature_max": 2.0,
        "notes": "API key is optional — only needed if LM Studio was started with authentication enabled.",
    },
    "vllm": {
        "label":         "vLLM (local/server)",
        "default_url":   "http://localhost:8000/v1",
        "url_editable":  True,
        "needs_api_key": True,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p", "top_k", "min_p",
            "presence_penalty", "frequency_penalty", "repetition_penalty", "seed",
        ],
        "param_warnings": {},
        "temperature_max": 2.0,
        "notes": "API key is optional — only needed if vLLM was started with --api-key.",
    },
    "azure": {
        "label":         "Azure OpenAI",
        "default_url":   "",
        "url_editable":  True,
        "needs_api_key": True,
        "extra_fields":  ["azure_deployment", "azure_api_version"],
        "supported_params": [
            "temperature", "max_tokens", "top_p",
            "presence_penalty", "frequency_penalty", "seed",
        ],
        "param_warnings": {},
        "temperature_max": 2.0,
        "notes": (
            "Base URL format: https://<resource>.openai.azure.com/openai/deployments/<deployment>"
        ),
    },
    "custom": {
        "label":         "Custom (OpenAI-compatible)",
        "default_url":   "",
        "url_editable":  True,
        "needs_api_key": True,
        "extra_fields":  [],
        "supported_params": [
            "temperature", "max_tokens", "top_p", "top_k", "min_p",
            "presence_penalty", "frequency_penalty", "repetition_penalty", "seed",
        ],
        "param_warnings": {},
        "temperature_max": 2.0,
        "notes": (
            "Any OpenAI-compatible endpoint. Unsupported parameters "
            "are typically ignored by the server."
        ),
    },
}

# Ordered list for the dropdown — local first, then cloud, then custom
PROVIDER_ORDER = [
    "ollama", "lmstudio", "vllm",                                     # local
    "openai", "groq", "mistral", "deepseek", "together", "fireworks",  # cloud
    "openrouter", "azure",                                             # cloud (meta/other)
    "custom",                                                          # custom
]

# Groups shown in the dropdown (label, [provider ids])
PROVIDER_GROUPS = [
    ("── Local ──", ["ollama", "lmstudio", "vllm"]),
    ("── Cloud API ──", ["openai", "groq", "mistral", "deepseek",
                         "together", "fireworks", "openrouter", "azure"]),
    ("── Custom ──", ["custom"]),
]


# Default font size configuration
EDITOR_DEFAULTS = {
    "fs_base":    10,
    "fs_code":    10,
    "fs_heading": 14,
    "fs_list":    10,
    "fs_table":   10,
    "fs_think":    9,
}

HISTORY_DEFAULTS = {
    "autosave":    True,
    "save_on_new": True,
}


# ---------------------------------------------------------------------------
# FIM provider defaults (URL auto-filled when provider changes)
# ---------------------------------------------------------------------------
_FIM_PROVIDER_URLS = {
    "lmstudio":   "http://localhost:1234",
    "ollama":     "http://localhost:11434",
    "vllm":       "http://localhost:8000",
    "deepseek":   "https://api.deepseek.com",
    "codestral":  "https://codestral.mistral.ai",
    "openrouter": "https://openrouter.ai/api",
    "custom":     "",
}


class _ConnTester(QThread):
    """Background thread: verify provider connectivity via GET /models.

    Uses the /models endpoint (OpenAI-compat) which is available on every
    supported provider without triggering any generation or billing.
    Azure optionally appends ?api-version=<ver> to the same path.
    """

    sig_ok    = Signal(str)   # success message
    sig_error = Signal(str)   # error/failure message

    def __init__(self, url, key, api_version="", parent=None):
        super().__init__(parent)
        self._url     = url.rstrip("/")
        self._key     = key
        self._api_ver = api_version

    def run(self):
        import urllib.request, urllib.error, json

        # Use an OpenAI-SDK-style User-Agent so Cloudflare and other WAFs
        # do not block the request as a generic Python bot (HTTP 403 / 1010).
        headers = {
            "Content-Type": "application/json",
            "User-Agent":   "OpenAI/Python 1.0.0",
            "Accept":       "application/json",
        }
        if self._key:
            headers["Authorization"] = f"Bearer {self._key}"

        path = "/models"
        if self._api_ver:
            path += f"?api-version={self._api_ver}"

        try:
            req = urllib.request.Request(
                f"{self._url}{path}", headers=headers)
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())

            if data.get("error"):
                self.sig_error.emit(str(data["error"]))
                return

            # Count available models when the list is present
            count = None
            if isinstance(data.get("data"), list):
                count = len(data["data"])
            elif isinstance(data.get("models"), list):
                count = len(data["models"])

            msg = f"Connected — {count} model(s) available" if count is not None \
                  else "Connected"
            self.sig_ok.emit(msg)

        except urllib.error.HTTPError as e:
            try:
                body = e.read().decode()[:200]
            except Exception:
                body = e.reason
            self.sig_error.emit(f"HTTP {e.code}: {body}")
        except Exception as e:
            self.sig_error.emit(str(e))


class _FimLoader(QThread):
    """Background thread: fetch model list then probe available backends."""

    sig_status   = Signal(str)
    sig_models   = Signal(list)   # list[str] — model names
    sig_backends = Signal(list)   # list[tuple[str,str]] — (key, label) pairs
    sig_error    = Signal(str)

    _ALL_BACKENDS = [
        ("ollama_generate",    "Ollama /api/generate  (native FIM)"),
        ("openai_completions", "OpenAI-compat /v1/completions  (legacy FIM)"),
        ("codestral",          "Codestral /v1/fim/completions  (Mistral)"),
        ("chat",               "Chat completions  (prompt injection, fallback)"),
    ]

    def __init__(self, url, key, provider_id, parent=None):
        super().__init__(parent)
        self._url = url.rstrip("/")
        self._key = key
        self._pid = provider_id

    def _headers(self):
        h = {
            "Content-Type": "application/json",
            "User-Agent":   "OpenAI/Python 1.0.0",
            "Accept":       "application/json",
        }
        if self._key:
            h["Authorization"] = f"Bearer {self._key}"
        return h

    def _get(self, path, timeout=10):
        import urllib.request, json
        req = urllib.request.Request(
            f"{self._url}{path}", headers=self._headers())
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())

    def _post(self, path, body, timeout=8):
        import urllib.request, json
        data = json.dumps(body).encode()
        req  = urllib.request.Request(
            f"{self._url}{path}", data=data,
            headers=self._headers(), method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())

    def run(self):
        self.sig_status.emit("Fetching model list…")
        models = self._fetch_models()
        if models is None:
            return
        if not models:
            self.sig_error.emit("No models found at this endpoint")
            return
        self.sig_models.emit(models)

        self.sig_status.emit(
            f"{len(models)} model(s) found. Testing backends…")
        backends = self._probe_backends(models[0])
        if not backends:
            backends = list(self._ALL_BACKENDS)
        self.sig_backends.emit(backends)

    def _fetch_models(self):
        try:
            if self._pid == "ollama":
                data = self._get("/api/tags")
                return [m["name"] for m in data.get("models", [])]
            else:
                data = self._get("/v1/models")
                return [m["id"] for m in data.get("data", [])]
        except Exception as e:
            self.sig_error.emit(f"Cannot connect: {e}")
            return None

    @staticmethod
    def _validate(data, backend_key):
        """Raise ValueError if the response body signals an unsupported endpoint.

        Some providers (e.g. LM Studio) return HTTP 200 for unknown endpoints
        but include an error message in the JSON body instead of the expected
        fields.  We must check the body — not just the status code.
        """
        # Top-level "error" key means the endpoint is not supported
        if data.get("error"):
            raise ValueError(f"endpoint error: {data['error']}")

        # Each backend has a required field that a real response must contain
        required = {
            "ollama_generate":    lambda d: "response" in d or "done" in d,
            "openai_completions": lambda d: "choices" in d,
            "codestral":          lambda d: "choices" in d,
            "chat":               lambda d: "choices" in d,
        }
        if not required[backend_key](data):
            raise ValueError(
                f"missing expected field in response: {list(data.keys())}")

    def _probe_backends(self, model):
        working = []
        probes = [
            ("ollama_generate",    "/api/generate",
             {"model": model, "prompt": "x", "suffix": "",
              "stream": False, "num_predict": 1}),
            ("openai_completions", "/v1/completions",
             {"model": model, "prompt": "x",
              "max_tokens": 1, "stream": False}),
            ("codestral",          "/v1/fim/completions",
             {"model": model, "prompt": "x", "suffix": "",
              "max_tokens": 1}),
            ("chat",               "/v1/chat/completions",
             {"model": model,
              "messages": [{"role": "user", "content": "x"}],
              "max_tokens": 1, "stream": False}),
        ]
        for key, path, body in probes:
            label = next(lbl for k, lbl in self._ALL_BACKENDS if k == key)
            try:
                data = self._post(path, body)
                self._validate(data, key)
                working.append((key, label))
            except Exception:
                pass
        return working


class SettingsDialog(QDialog):
    """
    Tabbed settings dialog:
      1. Connection  — provider dropdown + dynamic URL/key/extra fields
      2. Editor      — font sizes for rendered markdown elements
      3. History     — auto-save toggles
      4. System Prompts
    """

    def __init__(self, parent, provider_type, api_url, api_key,
                 editor_cfg, history_cfg,
                 azure_deployment="", azure_api_version="2024-02-01",
                 commands=None, fim_cfg=None,
                 initial_tab=0):
        super().__init__(parent)
        self.setWindowTitle("AI Chat – Settings")
        self.setMinimumWidth(578)
        self.setMinimumHeight(418)

        tabs = QTabWidget()
        tabs.tabBar().setExpanding(True)
        tabs.setStyleSheet(
            "QTabBar::tab { padding: 8px 3px; min-width: 80px; }"
        )

        # ── Tab 1: Connection ────────────────────────────────────────
        conn_w = QWidget()
        conn_lay = QVBoxLayout(conn_w)
        conn_lay.setContentsMargins(12, 12, 12, 12)
        conn_lay.setSpacing(6)

        # Info notices
        info_lbl1 = QLabel("Only OpenAI-compatible API providers are supported.")
        info_lbl1.setStyleSheet("color: #888; font-size: 9pt;")
        conn_lay.addWidget(info_lbl1)

        info_lbl2 = QLabel("Only one provider can be active at a time.")
        info_lbl2.setStyleSheet("color: #888; font-size: 9pt;")
        conn_lay.addWidget(info_lbl2)

        # Separator
        conn_sep = QFrame()
        conn_sep.setFrameShape(QFrame.HLine)
        conn_sep.setStyleSheet("color: #444; margin: 4px 0;")
        conn_lay.addWidget(conn_sep)

        # Provider row with "Configure active provider:" label above
        active_lbl = QLabel("Configure active provider:")
        active_lbl.setStyleSheet("color: #ccc; font-size: 9pt;")
        conn_lay.addWidget(active_lbl)

        # Provider dropdown
        prov_row = QHBoxLayout()
        prov_lbl = QLabel("Provider:")
        prov_lbl.setFixedWidth(127)
        self._prov_combo = QComboBox()
        self._prov_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        for group_label, pids in PROVIDER_GROUPS:
            # Group header — non-selectable separator item
            sep_idx = self._prov_combo.count()
            self._prov_combo.addItem(group_label, userData=None)
            item = self._prov_combo.model().item(sep_idx)
            item.setEnabled(False)
            # Style: bold, slightly muted colour
            f = QFont(); f.setBold(True)
            item.setFont(f)
            item.setForeground(QBrush(QColor("#888888")))
            # Actual providers in this group
            for pid in pids:
                self._prov_combo.addItem(PROVIDERS[pid]["label"], userData=pid)
        prov_row.addWidget(prov_lbl)
        prov_row.addWidget(self._prov_combo, 1)
        conn_lay.addLayout(prov_row)

        # Dynamic fields form — built ONCE, rows shown/hidden per provider.
        # Never use takeRow/addRow after init — Wayland loses keyboard grab
        # when widgets are re-parented dynamically.
        self._conn_form = QFormLayout()
        self._conn_form.setSpacing(6)
        conn_lay.addLayout(self._conn_form)

        # Notes label (provider-specific)
        self._prov_notes = QLabel()
        self._prov_notes.setWordWrap(True)
        self._prov_notes.setTextFormat(Qt.RichText)
        self._prov_notes.setStyleSheet(
            "color: #aaa; font-size: 9pt; padding: 6px 4px 2px 4px;")
        conn_lay.addWidget(self._prov_notes)
        conn_lay.addStretch()

        tabs.addTab(conn_w, "🔌 Connection")

        # ── persistent field widgets (created once, shown/hidden) ────
        # URL
        self._url_edit = QLineEdit()
        self._url_edit.setPlaceholderText("https://…")
        # API key
        self._key_edit = QLineEdit()
        self._key_edit.setEchoMode(QLineEdit.Password)
        self._key_edit.setPlaceholderText("sk-…  (blank for local models)")
        # "No key needed" label shown instead of key field for local providers
        self._no_key_lbl = QLabel("No API key required for local models.")
        self._no_key_lbl.setStyleSheet("color: gray; font-size: 9pt;")
        # Azure extras
        self._azure_dep_edit = QLineEdit(azure_deployment)
        self._azure_dep_edit.setPlaceholderText("my-gpt4o-deployment")
        self._azure_ver_combo = QComboBox()
        for ver in ["2024-02-01", "2024-05-01-preview", "2024-08-01-preview",
                    "2024-10-01-preview", "2025-01-01-preview"]:
            self._azure_ver_combo.addItem(ver)
        idx = self._azure_ver_combo.findText(azure_api_version)
        if idx >= 0:
            self._azure_ver_combo.setCurrentIndex(idx)

        # Set initial values
        self._url_edit.setText(api_url)
        self._key_edit.setText(api_key)


        # Add ALL rows to the form permanently — visibility toggled in
        # _build_conn_form(), never removed/re-added
        self._url_lbl = QLabel("Base URL:")
        self._conn_form.addRow(self._url_lbl, self._url_edit)

        self._key_lbl = QLabel("API key:")
        self._conn_form.addRow(self._key_lbl, self._key_edit)

        self._no_key_lbl_row_lbl = QLabel("API key:")
        self._conn_form.addRow(self._no_key_lbl_row_lbl, self._no_key_lbl)

        self._azure_dep_lbl = QLabel("Deployment name:")
        self._conn_form.addRow(self._azure_dep_lbl, self._azure_dep_edit)

        self._azure_ver_lbl = QLabel("API version:")
        self._conn_form.addRow(self._azure_ver_lbl, self._azure_ver_combo)

        # Test connection row — always visible
        _test_row = QHBoxLayout()
        self._conn_test_btn = QPushButton("Test Connection")
        self._conn_test_btn.setFixedWidth(138)
        self._conn_test_lbl = QLabel("")
        self._conn_test_lbl.setWordWrap(True)
        _test_row.addWidget(self._conn_test_btn)
        _test_row.addWidget(self._conn_test_lbl, 1)
        self._conn_form.addRow("", _test_row)

        # Spinner state for test button
        self._conn_spinner_frames = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]
        self._conn_spinner_idx    = 0
        self._conn_status_msg     = ""
        self._conn_spinner_timer  = QTimer(self)
        self._conn_spinner_timer.setInterval(80)
        self._conn_spinner_timer.timeout.connect(self._conn_spinner_tick)
        self._conn_tester         = None

        self._conn_test_btn.clicked.connect(self._on_conn_test)

        # Wire provider change
        self._prov_combo.currentIndexChanged.connect(self._on_provider_changed)

        # Select the saved provider (triggers _on_provider_changed → updates visibility)
        saved_idx = self._prov_combo.findData(provider_type)
        if saved_idx < 0:
            saved_idx = self._prov_combo.findData("custom")
        self._prov_combo.setCurrentIndex(saved_idx)
        self._build_conn_form()

        # ── Tab 2: Dialogs (font sizes) ──────────────────────────────
        editor_w = QWidget()
        editor_outer = QVBoxLayout(editor_w)
        editor_outer.setContentsMargins(12, 12, 12, 12)
        editor_outer.setSpacing(6)

        dialogs_info = QLabel("Change font size of text types in dialogs.")
        dialogs_info.setStyleSheet("color: #888; font-size: 9pt;")
        editor_outer.addWidget(dialogs_info)

        ef = QFormLayout()
        ef.setSpacing(8)
        editor_outer.addLayout(ef)

        def _spin(key):
            s = QSpinBox()
            s.setRange(6, 24)
            s.setValue(editor_cfg.get(key, EDITOR_DEFAULTS[key]))
            s.setSuffix(" pt")
            s.setFixedWidth(83)
            return s

        self.fs_base    = _spin("fs_base")
        self.fs_code    = _spin("fs_code")
        self.fs_heading = _spin("fs_heading")
        self.fs_list    = _spin("fs_list")
        self.fs_table   = _spin("fs_table")
        self.fs_think   = _spin("fs_think")

        ef.addRow("Base text:", self.fs_base)
        ef.addRow("Code blocks:", self.fs_code)
        ef.addRow("Headings (H1 base):", self.fs_heading)
        ef.addRow("Lists:", self.fs_list)
        ef.addRow("Tables:", self.fs_table)
        ef.addRow("Thinking box:", self.fs_think)

        note = QLabel("Changes apply to new messages after saving.")
        note.setStyleSheet("color: gray; font-size: 9pt;")
        ef.addRow(note)
        editor_outer.addStretch()
        tabs.addTab(editor_w, "🖊 Dialogs")

        # ── Tab 3: History ───────────────────────────────────────────
        hist_w = QWidget()
        hl = QVBoxLayout(hist_w)
        hl.setContentsMargins(12, 12, 12, 12)
        hl.setSpacing(8)

        self.cb_autosave = QCheckBox("Automatically save chats to history")
        self.cb_autosave.setChecked(
            history_cfg.get("autosave", HISTORY_DEFAULTS["autosave"]))

        self.cb_save_on_new = QCheckBox(
            "Save unsent chat when starting New Chat")
        self.cb_save_on_new.setChecked(
            history_cfg.get("save_on_new", HISTORY_DEFAULTS["save_on_new"]))

        def _sync_hist():
            enabled = not self.cb_autosave.isChecked()
            self.cb_save_on_new.setEnabled(enabled)
            if not enabled:
                self.cb_save_on_new.setChecked(True)
        self.cb_autosave.toggled.connect(_sync_hist)
        _sync_hist()

        info = QLabel(
            "<b>How it works:</b><br>"
            "When <i>auto-save</i> is on, every completed exchange (your message "
            "and the AI reply) is written to disk automatically — you never lose "
            "a conversation.<br><br>"
            "When <i>auto-save</i> is off, nothing is saved unless you manually "
            "load a chat from history. In that case, <i>Save unsent chat on New Chat</i> "
            "gives you a one-time save at the moment you click New Chat, so the "
            "current unsaved conversation is not lost."
        )
        info.setWordWrap(True)
        info.setTextFormat(Qt.RichText)
        info.setStyleSheet(
            "color: gray; font-size: 9pt; padding: 8px; "
            "background: rgba(128,128,128,0.08); border-radius: 4px;")

        hl.addWidget(self.cb_autosave)
        hl.addWidget(self.cb_save_on_new)
        hl.addSpacing(4)
        hl.addWidget(info)
        hl.addStretch()
        tabs.addTab(hist_w, "🗂 History")

        # ── Tab 4: System Prompts ────────────────────────────────────
        sp_w = QWidget()
        sp_lay = QVBoxLayout(sp_w)
        sp_lay.setContentsMargins(12, 12, 12, 12)
        sp_lay.setSpacing(8)

        top_bar = QHBoxLayout()
        self.sp_combo = QComboBox()
        self.sp_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        top_bar.addWidget(self.sp_combo, 1)

        self.sp_delete_btn = QPushButton("Delete")
        self.sp_new_btn    = QPushButton("+ New")
        for btn in (self.sp_delete_btn, self.sp_new_btn):
            btn.setFixedWidth(74)
            top_bar.addWidget(btn)
        sp_lay.addLayout(top_bar)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("color: #444;")
        sp_lay.addWidget(line)

        form2 = QFormLayout()
        form2.setSpacing(6)
        self.sp_title_edit = QLineEdit()
        self.sp_title_edit.setPlaceholderText("Prompt title…")
        form2.addRow("Title:", self.sp_title_edit)
        sp_lay.addLayout(form2)

        self.sp_content_edit = QPlainTextEdit()
        self.sp_content_edit.setPlaceholderText("Prompt content…")
        self.sp_content_edit.setMinimumHeight(138)
        sp_lay.addWidget(self.sp_content_edit, 1)

        save_row = QHBoxLayout()
        save_row.addStretch()
        self.sp_save_btn = QPushButton("💾 Save prompt")
        self.sp_save_btn.setFixedWidth(150)
        save_row.addWidget(self.sp_save_btn)
        sp_lay.addLayout(save_row)

        tabs.addTab(sp_w, "💬 System Prompts")

        self._sp_current_id   = None
        self._sp_orig_title   = ""
        self._sp_orig_content = ""
        self._sp_populate_combo()

        self.sp_combo.currentIndexChanged.connect(self._sp_on_select)
        self.sp_new_btn.clicked.connect(self._sp_on_new)
        self.sp_delete_btn.clicked.connect(self._sp_on_delete)
        self.sp_save_btn.clicked.connect(self._sp_on_save)
        self.sp_title_edit.textChanged.connect(self._sp_mark_dirty)
        self.sp_content_edit.textChanged.connect(self._sp_mark_dirty)

        self._sp_set_editor_enabled(False)


        # ── Tab 5: Commands ──────────────────────────────────────────
        cmd_w = QWidget()
        cmd_lay = QVBoxLayout(cmd_w)
        cmd_lay.setContentsMargins(12, 12, 12, 12)
        cmd_lay.setSpacing(8)

        cmd_info = QLabel(
            "Define slash-command aliases for the chat input field. "
            "Type <b>/</b> in the input to see the command picker. "
            "Commands must be at least 2 characters. Name without the leading /."
        )
        cmd_info.setWordWrap(True)
        cmd_info.setTextFormat(Qt.RichText)
        cmd_info.setStyleSheet("color: #aaa; font-size: 9pt;")
        cmd_lay.addWidget(cmd_info)

        cmd_top = QHBoxLayout()
        self._cmd_list = QListWidget()
        self._cmd_list.setStyleSheet(
            "QListWidget { border: 1px solid #444; border-radius: 3px; }"
            "QListWidget::item { padding: 3px 6px; }"
            "QListWidget::item:selected { background: #2a4a2a; color: #b8e090; }"
        )
        self._cmd_list.setFixedHeight(161)
        cmd_top.addWidget(self._cmd_list, 1)

        cmd_btns = QVBoxLayout()
        cmd_btns.setSpacing(4)
        self._cmd_new_btn    = QPushButton("+ New")
        self._cmd_delete_btn = QPushButton("Delete")
        self._cmd_reset_btn  = QPushButton("Restore\nbuilt-in defaults")
        builtin_names = ", ".join(f"/{c['name']}" for c in DEFAULT_COMMANDS)
        self._cmd_reset_btn.setToolTip(
            f"Restores built-in commands to their default prompt texts:\n"
            f"{builtin_names}\n\n"
            f"User-defined commands are not affected."
        )
        for b in (self._cmd_new_btn, self._cmd_delete_btn, self._cmd_reset_btn):
            b.setFixedWidth(127)
            cmd_btns.addWidget(b)
        cmd_btns.addStretch()
        cmd_top.addLayout(cmd_btns)
        cmd_lay.addLayout(cmd_top)

        cmd_sep = QFrame()
        cmd_sep.setFrameShape(QFrame.HLine)
        cmd_sep.setStyleSheet("color: #444;")
        cmd_lay.addWidget(cmd_sep)

        cmd_form = QFormLayout()
        cmd_form.setSpacing(6)
        self._cmd_name_edit = QLineEdit()
        self._cmd_name_edit.setPlaceholderText("command name (min 2 chars, no /)")
        cmd_form.addRow("Name:", self._cmd_name_edit)
        cmd_lay.addLayout(cmd_form)

        self._cmd_prompt_edit = QPlainTextEdit()
        self._cmd_prompt_edit.setPlaceholderText(
            "Prompt text sent to LLM when this command is used…")
        self._cmd_prompt_edit.setMinimumHeight(92)
        cmd_lay.addWidget(self._cmd_prompt_edit, 1)

        cmd_save_row = QHBoxLayout()
        cmd_save_row.addStretch()
        self._cmd_save_btn = QPushButton("Save command")
        self._cmd_save_btn.setFixedWidth(150)
        cmd_save_row.addWidget(self._cmd_save_btn)
        cmd_lay.addLayout(cmd_save_row)

        tabs.addTab(cmd_w, "/ Commands")

        self._cmd_commands    = list(commands) if commands else load_commands()
        self._cmd_current_idx = -1
        self._cmd_orig_name   = ""
        self._cmd_orig_prompt = ""
        self._cmd_populate_list()
        self._cmd_set_editor_enabled(False)

        self._cmd_list.currentRowChanged.connect(self._cmd_on_select)
        self._cmd_new_btn.clicked.connect(self._cmd_on_new)
        self._cmd_delete_btn.clicked.connect(self._cmd_on_delete)
        self._cmd_reset_btn.clicked.connect(self._cmd_on_reset)
        self._cmd_save_btn.clicked.connect(self._cmd_on_save)
        self._cmd_name_edit.textChanged.connect(self._cmd_mark_dirty)
        self._cmd_prompt_edit.textChanged.connect(self._cmd_mark_dirty)



        # ── Tab 6: Auto-complete ─────────────────────────────────────
        fim_cfg = fim_cfg or {}
        fim_w = QWidget()
        fim_outer = QVBoxLayout(fim_w)
        fim_outer.setContentsMargins(10, 10, 10, 10)

        # Enable checkbox — unchecked by default (requires explicit setup)
        self.fim_enabled = QCheckBox("Enable AI auto-completion in the editor")
        self.fim_enabled.setChecked(fim_cfg.get("enabled", False))
        fim_outer.addWidget(self.fim_enabled)

        # ── Provider group ──────────────────────────────────────────
        prov_group = QGroupBox("Provider")
        pf = QFormLayout()
        pf.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)

        self.fim_provider_combo = QComboBox()
        for k, label in [
            ("lmstudio",    "LM Studio (local)"),
            ("ollama",      "Ollama (local)"),
            ("vllm",        "vLLM (local/remote)"),
            ("deepseek",    "DeepSeek"),
            ("codestral",   "Mistral / Codestral"),
            ("openrouter",  "OpenRouter"),
            ("custom",      "Custom"),
        ]:
            self.fim_provider_combo.addItem(label, userData=k)
        cur_prov = fim_cfg.get("provider", "lmstudio")
        idx = self.fim_provider_combo.findData(cur_prov)
        if idx >= 0:
            self.fim_provider_combo.setCurrentIndex(idx)
        pf.addRow("Provider:", self.fim_provider_combo)

        default_url = fim_cfg.get(
            "api_url",
            _FIM_PROVIDER_URLS.get(cur_prov, "http://localhost:1234"))
        self.fim_url_edit = QLineEdit(default_url)
        pf.addRow("API URL:", self.fim_url_edit)

        self.fim_key_edit = QLineEdit(fim_cfg.get("api_key", ""))
        self.fim_key_edit.setEchoMode(QLineEdit.Password)
        self.fim_key_edit.setPlaceholderText(
            "(optional — leave blank for local servers)")
        pf.addRow("API Key:", self.fim_key_edit)

        # Load button + inline status label
        load_row = QHBoxLayout()
        self.fim_load_btn = QPushButton("Load Models")
        self.fim_load_btn.setFixedWidth(127)
        self.fim_status_lbl = QLabel("")
        self.fim_status_lbl.setWordWrap(True)
        load_row.addWidget(self.fim_load_btn)
        load_row.addWidget(self.fim_status_lbl, 1)
        pf.addRow("", load_row)

        # Model combo — editable so user can also type a name manually.
        # Restore the full model list saved from the previous session so the
        # user gets their full dropdown back without needing to re-load models.
        self.fim_model_combo = QComboBox()
        self.fim_model_combo.setEditable(True)
        self.fim_model_combo.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.fim_model_combo.setMinimumContentsLength(30)
        saved_model  = fim_cfg.get("model", "")
        saved_models = fim_cfg.get("models", [])
        if saved_models:
            for m in saved_models:
                self.fim_model_combo.addItem(m)
            idx = self.fim_model_combo.findText(saved_model)
            if idx >= 0:
                self.fim_model_combo.setCurrentIndex(idx)
        elif saved_model:
            self.fim_model_combo.addItem(saved_model)
        pf.addRow("Model:", self.fim_model_combo)

        # Backend combo — restore the tested/filtered list from the previous
        # session; fall back to the full list only when nothing was saved yet.
        self.fim_backend_combo = QComboBox()
        saved_backends = fim_cfg.get("backends", [])   # list of [key, label]
        backend_source = (
            saved_backends if saved_backends else _FimLoader._ALL_BACKENDS)
        for k, label in backend_source:
            self.fim_backend_combo.addItem(label, userData=k)
        cur_bt = fim_cfg.get("backend_type", "openai_completions")
        idx = self.fim_backend_combo.findData(cur_bt)
        if idx >= 0:
            self.fim_backend_combo.setCurrentIndex(idx)
        pf.addRow("Backend type:", self.fim_backend_combo)

        prov_group.setLayout(pf)
        fim_outer.addWidget(prov_group)

        # ── Model Parameters group ──────────────────────────────────
        param_group = QGroupBox("Model Parameters")
        paramf = QFormLayout()

        self.fim_max_tokens = QSpinBox()
        self.fim_max_tokens.setRange(16, 1024)
        self.fim_max_tokens.setSingleStep(16)
        self.fim_max_tokens.setValue(fim_cfg.get("max_tokens", 128))
        paramf.addRow("Max tokens:", self.fim_max_tokens)

        self.fim_temperature = QDoubleSpinBox()
        self.fim_temperature.setRange(0.0, 2.0)
        self.fim_temperature.setSingleStep(0.05)
        self.fim_temperature.setDecimals(2)
        self.fim_temperature.setValue(fim_cfg.get("temperature", 0.5))
        paramf.addRow("Temperature:", self.fim_temperature)

        self.fim_ctx_before = QSpinBox()
        self.fim_ctx_before.setRange(100, 32000)
        self.fim_ctx_before.setSingleStep(500)
        self.fim_ctx_before.setValue(fim_cfg.get("context_before", 100))
        paramf.addRow("Context before cursor (chars):", self.fim_ctx_before)

        self.fim_ctx_after = QSpinBox()
        self.fim_ctx_after.setRange(0, 8000)
        self.fim_ctx_after.setSingleStep(100)
        self.fim_ctx_after.setValue(fim_cfg.get("context_after", 100))
        paramf.addRow("Context after cursor (chars):", self.fim_ctx_after)

        param_group.setLayout(paramf)
        fim_outer.addWidget(param_group)

        # ── Trigger group ───────────────────────────────────────────
        trig_group = QGroupBox("Trigger")
        trigf = QFormLayout()

        self.fim_trigger_combo = QComboBox()
        for k, label in [("auto",         "Auto (after typing pause)"),
                          ("newline_only", "After new line only"),
                          ("manual",       "Manual only (Alt+\\)")]:
            self.fim_trigger_combo.addItem(label, userData=k)
        cur_tm = fim_cfg.get("trigger_mode", "auto")
        idx = self.fim_trigger_combo.findData(cur_tm)
        if idx >= 0:
            self.fim_trigger_combo.setCurrentIndex(idx)
        trigf.addRow("Trigger mode:", self.fim_trigger_combo)

        self.fim_debounce = QSpinBox()
        self.fim_debounce.setRange(100, 5000)
        self.fim_debounce.setSingleStep(100)
        self.fim_debounce.setSuffix(" ms")
        self.fim_debounce.setValue(fim_cfg.get("debounce_ms", 600))
        trigf.addRow("Debounce delay:", self.fim_debounce)

        trig_group.setLayout(trigf)
        fim_outer.addWidget(trig_group)

        fim_outer.addStretch()

        # Keep refs for state management
        self._fim_param_group = param_group
        self._fim_trig_group  = trig_group
        self._fim_loader      = None

        # Spinner animation for loading feedback
        self._fim_spinner_frames = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]
        self._fim_spinner_idx    = 0
        self._fim_status_msg     = ""
        self._fim_spinner_timer  = QTimer(self)
        self._fim_spinner_timer.setInterval(80)
        self._fim_spinner_timer.timeout.connect(self._fim_spinner_tick)

        # Connect signals (after all widgets exist — avoids spurious init triggers)
        self.fim_enabled.toggled.connect(self._fim_on_enabled_toggled)
        self.fim_provider_combo.activated.connect(self._fim_on_provider_changed)
        self.fim_load_btn.clicked.connect(self._fim_load_models)

        # Apply initial state
        has_model = bool(fim_cfg.get("model", ""))
        if fim_cfg.get("enabled", False) and has_model:
            self._fim_set_state("ready")
        elif fim_cfg.get("enabled", False):
            self._fim_set_state("provider_only")
        else:
            self._fim_set_state("disabled")

        tabs.addTab(fim_w, "⚡ Auto-complete")

        # ── Dialog buttons ───────────────────────────────────────────
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)

        lay = QVBoxLayout(self)
        lay.addWidget(tabs)
        lay.addWidget(btns)

        if initial_tab:
            tabs.setCurrentIndex(initial_tab)

    # ── Connection tab helpers ───────────────────────────────────────

    def _current_provider_id(self):
        return self._prov_combo.currentData() or "custom"

    # ── Connection test helpers ───────────────────────────────────────

    def _on_conn_test(self):
        url = self._url_edit.text().strip()
        if not url:
            self._conn_test_lbl.setText("⚠ Enter a Base URL first")
            self._conn_test_lbl.setStyleSheet("color: orange;")
            return
        # Stop any running tester
        if self._conn_tester is not None:
            self._conn_tester.quit()
            self._conn_tester.wait(500)
        # Azure needs api-version query param
        api_ver = ""
        if self._current_provider_id() == "azure":
            api_ver = self._azure_ver_combo.currentText()
        key = self._key_edit.text().strip()
        self._conn_status_msg = "Testing connection…"
        self._conn_test_btn.setEnabled(False)
        self._conn_test_lbl.setStyleSheet("")
        self._conn_spinner_timer.start()
        tester = _ConnTester(url, key, api_ver, parent=self)
        tester.sig_ok.connect(self._conn_test_ok)
        tester.sig_error.connect(self._conn_test_error)
        tester.finished.connect(self._conn_test_finished)
        self._conn_tester = tester
        tester.start()

    def _conn_spinner_tick(self):
        self._conn_spinner_idx = (
            (self._conn_spinner_idx + 1) % len(self._conn_spinner_frames))
        frame = self._conn_spinner_frames[self._conn_spinner_idx]
        self._conn_test_lbl.setText(f"{frame}  {self._conn_status_msg}")
        self._conn_test_lbl.setStyleSheet("")

    def _conn_test_ok(self, msg):
        self._conn_spinner_timer.stop()
        self._conn_test_lbl.setText(f"✓ {msg}")
        self._conn_test_lbl.setStyleSheet("color: green;")

    def _conn_test_error(self, msg):
        self._conn_spinner_timer.stop()
        self._conn_test_lbl.setText(f"✗ {msg}")
        self._conn_test_lbl.setStyleSheet("color: red;")

    def _conn_test_finished(self):
        self._conn_spinner_timer.stop()
        self._conn_test_btn.setEnabled(True)
        self._conn_test_btn.setText("Test Connection")

    def _on_provider_changed(self, _idx=None):
        """Rebuild connection form when provider selection changes."""
        pid = self._current_provider_id()
        pdef = PROVIDERS[pid]

        # Update URL field with provider default IF the current URL looks like
        # it belongs to a different provider (i.e. don't overwrite a custom URL
        # the user has already typed in an editable field).
        old_url = self._url_edit.text().strip()
        new_default = pdef["default_url"]
        # Always set to default for fixed-URL providers; for editable providers
        # only replace if the field is empty or still holds another provider's default.
        is_other_default = any(
            old_url == PROVIDERS[p]["default_url"]
            for p in PROVIDER_ORDER
            if p != pid and PROVIDERS[p]["default_url"]
        )
        if not pdef["url_editable"] or not old_url or is_other_default:
            self._url_edit.setText(new_default)

        # Clear stale test result when provider changes
        self._conn_test_lbl.setText("")
        self._conn_test_lbl.setStyleSheet("")

        self._build_conn_form()

    def _build_conn_form(self):
        """Update connection form visibility for the current provider.
        Never removes or re-adds rows — only shows/hides them.
        This avoids the Wayland keyboard-grab bug caused by widget re-parenting.
        """
        pid  = self._current_provider_id()
        pdef = PROVIDERS[pid]

        # URL row — always visible, editable flag varies
        self._url_edit.setReadOnly(not pdef["url_editable"])
        self._url_edit.setStyleSheet(
            "color: gray;" if not pdef["url_editable"] else "")
        self._url_lbl.show()
        self._url_edit.show()

        # API key vs "no key" label
        if pdef["needs_api_key"]:
            self._key_lbl.show()
            self._key_edit.show()
            self._no_key_lbl_row_lbl.hide()
            self._no_key_lbl.hide()
        else:
            self._key_lbl.hide()
            self._key_edit.hide()
            self._no_key_lbl_row_lbl.show()
            self._no_key_lbl.show()

        # Azure extra fields
        show_dep = "azure_deployment" in pdef["extra_fields"]
        show_ver = "azure_api_version" in pdef["extra_fields"]
        self._azure_dep_lbl.setVisible(show_dep)
        self._azure_dep_edit.setVisible(show_dep)
        self._azure_ver_lbl.setVisible(show_ver)
        self._azure_ver_combo.setVisible(show_ver)

        # Provider notes
        notes = pdef.get("notes", "")
        self._prov_notes.setText(notes)
        self._prov_notes.setVisible(bool(notes))

    # ── System Prompts tab helpers ───────────────────────────────────

    def _sp_populate_combo(self, select_id=None):
        self.sp_combo.blockSignals(True)
        self.sp_combo.clear()
        self.sp_combo.addItem("— select a prompt —", userData=None)
        prompts = load_prompts()
        target_idx = 0
        for i, p in enumerate(prompts):
            self.sp_combo.addItem(p["title"], userData=p["id"])
            if p["id"] == select_id:
                target_idx = i + 1
        self.sp_combo.blockSignals(False)
        self.sp_combo.setCurrentIndex(target_idx)
        self._sp_on_select(target_idx)

    def _sp_on_select(self, idx):
        prompt_id = self.sp_combo.currentData()
        if prompt_id is None:
            self._sp_current_id = None
            self._sp_set_editor_enabled(False)
            self.sp_title_edit.blockSignals(True)
            self.sp_content_edit.blockSignals(True)
            self.sp_title_edit.clear()
            self.sp_content_edit.clear()
            self.sp_title_edit.blockSignals(False)
            self.sp_content_edit.blockSignals(False)
            self.sp_delete_btn.setEnabled(False)
        else:
            self._sp_current_id = prompt_id
            self.sp_delete_btn.setEnabled(True)
            from .system_prompts import get_prompt
            p = get_prompt(prompt_id)
            if p:
                self.sp_title_edit.blockSignals(True)
                self.sp_content_edit.blockSignals(True)
                self.sp_title_edit.setText(p["title"])
                self.sp_content_edit.setPlainText(p["content"])
                self.sp_title_edit.blockSignals(False)
                self.sp_content_edit.blockSignals(False)
                self._sp_orig_title   = p["title"]
                self._sp_orig_content = p["content"]
            self._sp_set_editor_enabled(True)
            self.sp_save_btn.setEnabled(False)  # not dirty yet

    def _sp_set_editor_enabled(self, enabled):
        # Use setReadOnly instead of setEnabled — setEnabled(False) on Wayland
        # can cause the widget to lose keyboard grab when re-enabled.
        self.sp_title_edit.setReadOnly(not enabled)
        self.sp_content_edit.setReadOnly(not enabled)
        # Save button is controlled by dirty tracking; only force-disable when
        # the fields are not editable at all.
        if not enabled:
            self.sp_save_btn.setEnabled(False)
        # Dim the fields visually when not editable
        style = "color: gray;" if not enabled else ""
        self.sp_title_edit.setStyleSheet(style)
        self.sp_content_edit.setStyleSheet(style)

    def _sp_mark_dirty(self):
        """Enable Save only when the content differs from the last-saved values."""
        if self.sp_title_edit.isReadOnly():
            return
        title   = self.sp_title_edit.text()
        content = self.sp_content_edit.toPlainText()
        dirty = (title != self._sp_orig_title or content != self._sp_orig_content)
        self.sp_save_btn.setEnabled(dirty)

    def _sp_on_new(self):
        self._sp_current_id = None
        self.sp_combo.blockSignals(True)
        self.sp_combo.setCurrentIndex(0)
        self.sp_combo.blockSignals(False)
        self.sp_title_edit.blockSignals(True)
        self.sp_content_edit.blockSignals(True)
        self.sp_title_edit.clear()
        self.sp_content_edit.clear()
        self.sp_title_edit.blockSignals(False)
        self.sp_content_edit.blockSignals(False)
        self._sp_orig_title   = ""
        self._sp_orig_content = ""
        self._sp_set_editor_enabled(True)
        self.sp_save_btn.setEnabled(False)
        self.sp_title_edit.setFocus()
        self.sp_delete_btn.setEnabled(False)

    def _sp_on_delete(self):
        prompt_id = self._sp_current_id
        if not prompt_id:
            return
        delete_prompt(prompt_id)
        self._sp_current_id = None
        self._sp_populate_combo()

    def _sp_on_save(self):
        title   = self.sp_title_edit.text().strip()
        content = self.sp_content_edit.toPlainText().strip()
        if not title:
            self.sp_title_edit.setPlaceholderText("⚠ Title is required")
            return
        if self._sp_current_id:
            update_prompt(self._sp_current_id, title, content)
            saved_id = self._sp_current_id
        else:
            p = new_prompt(title, content)
            saved_id = p["id"]
        self._sp_populate_combo(select_id=saved_id)

    # ── Commands tab helpers ─────────────────────────────────────────────

    def _cmd_populate_list(self):
        self._cmd_list.clear()
        for cmd in self._cmd_commands:
            self._cmd_list.addItem(f"/{cmd['name']}")

    def _cmd_set_editor_enabled(self, enabled):
        self._cmd_name_edit.setEnabled(enabled)
        self._cmd_prompt_edit.setEnabled(enabled)
        self._cmd_save_btn.setEnabled(False)  # controlled by dirty tracking
        self._cmd_delete_btn.setEnabled(bool(self._cmd_commands))

    def _cmd_mark_dirty(self):
        """Enable Save only when the content differs from the last-saved values."""
        name   = self._cmd_name_edit.text().strip().lstrip("/")
        prompt = self._cmd_prompt_edit.toPlainText()
        dirty = (name != self._cmd_orig_name or prompt != self._cmd_orig_prompt)
        self._cmd_save_btn.setEnabled(dirty and len(name) >= 2)

    def _cmd_on_select(self, row):
        if 0 <= row < len(self._cmd_commands):
            self._cmd_current_idx = row
            cmd = self._cmd_commands[row]
            self._cmd_name_edit.blockSignals(True)
            self._cmd_prompt_edit.blockSignals(True)
            self._cmd_name_edit.setText(cmd["name"])
            self._cmd_prompt_edit.setPlainText(cmd["prompt"])
            self._cmd_name_edit.blockSignals(False)
            self._cmd_prompt_edit.blockSignals(False)
            self._cmd_orig_name   = cmd["name"]
            self._cmd_orig_prompt = cmd["prompt"]
            self._cmd_name_edit.setEnabled(True)
            self._cmd_prompt_edit.setEnabled(True)
            self._cmd_save_btn.setEnabled(False)  # not dirty yet
            self._cmd_delete_btn.setEnabled(True)
        else:
            self._cmd_current_idx = -1

    def _cmd_on_new(self):
        self._cmd_list.clearSelection()
        self._cmd_current_idx = -1
        self._cmd_name_edit.blockSignals(True)
        self._cmd_prompt_edit.blockSignals(True)
        self._cmd_name_edit.clear()
        self._cmd_prompt_edit.clear()
        self._cmd_name_edit.blockSignals(False)
        self._cmd_prompt_edit.blockSignals(False)
        self._cmd_orig_name   = ""
        self._cmd_orig_prompt = ""
        self._cmd_name_edit.setEnabled(True)
        self._cmd_prompt_edit.setEnabled(True)
        self._cmd_save_btn.setEnabled(False)
        self._cmd_name_edit.setFocus()

    def _cmd_on_delete(self):
        row = self._cmd_list.currentRow()
        if 0 <= row < len(self._cmd_commands):
            self._cmd_commands.pop(row)
            save_commands(self._cmd_commands)
            self._cmd_populate_list()
            self._cmd_name_edit.blockSignals(True)
            self._cmd_prompt_edit.blockSignals(True)
            self._cmd_name_edit.clear()
            self._cmd_prompt_edit.clear()
            self._cmd_name_edit.blockSignals(False)
            self._cmd_prompt_edit.blockSignals(False)
            self._cmd_orig_name   = ""
            self._cmd_orig_prompt = ""
            self._cmd_current_idx = -1
            self._cmd_set_editor_enabled(False)

    def _cmd_on_reset(self):
        """Restore built-in commands to default prompts; keep user-defined commands."""
        builtin_names = {c["name"] for c in DEFAULT_COMMANDS}
        # Keep any command whose name is NOT in the built-in set (user-defined)
        user_commands = [c for c in self._cmd_commands
                         if c["name"] not in builtin_names]
        # Rebuild: built-in defaults first, then user commands
        self._cmd_commands = list(DEFAULT_COMMANDS) + user_commands
        save_commands(self._cmd_commands)
        self._cmd_populate_list()
        self._cmd_name_edit.blockSignals(True)
        self._cmd_prompt_edit.blockSignals(True)
        self._cmd_name_edit.clear()
        self._cmd_prompt_edit.clear()
        self._cmd_name_edit.blockSignals(False)
        self._cmd_prompt_edit.blockSignals(False)
        self._cmd_orig_name   = ""
        self._cmd_orig_prompt = ""
        self._cmd_current_idx = -1
        self._cmd_set_editor_enabled(False)

    def _cmd_on_save(self):
        name = self._cmd_name_edit.text().strip().lstrip("/")
        prompt = self._cmd_prompt_edit.toPlainText().strip()
        if len(name) < 2:
            self._cmd_name_edit.setPlaceholderText("Name must be at least 2 characters")
            self._cmd_name_edit.setFocus()
            return
        if not prompt:
            self._cmd_prompt_edit.setPlaceholderText("Prompt cannot be empty")
            self._cmd_prompt_edit.setFocus()
            return
        for i, cmd in enumerate(self._cmd_commands):
            if cmd["name"] == name and i != self._cmd_current_idx:
                self._cmd_name_edit.setPlaceholderText(f"Name '{name}' already exists")
                self._cmd_name_edit.clear()
                self._cmd_name_edit.setFocus()
                return
        new_cmd = {"name": name, "prompt": prompt}
        if self._cmd_current_idx >= 0:
            self._cmd_commands[self._cmd_current_idx] = new_cmd
        else:
            self._cmd_commands.append(new_cmd)
            self._cmd_current_idx = len(self._cmd_commands) - 1
        save_commands(self._cmd_commands)
        saved_idx = self._cmd_current_idx
        self._cmd_populate_list()
        self._cmd_list.setCurrentRow(saved_idx)
        # _cmd_on_select resets originals and disables save via currentRowChanged

    # ── Auto-complete tab helpers ─────────────────────────────────────────

    def _fim_set_state(self, state):
        """state: 'disabled' | 'provider_only' | 'loading' | 'ready'"""
        is_on      = state != "disabled"
        is_ready   = state == "ready"
        is_loading = state == "loading"

        # Provider connection widgets — enabled when checkbox is on and not loading
        for w in (self.fim_provider_combo, self.fim_url_edit,
                  self.fim_key_edit, self.fim_load_btn):
            w.setEnabled(is_on and not is_loading)

        # Model + backend — only when models have been loaded
        self.fim_model_combo.setEnabled(is_ready)
        self.fim_backend_combo.setEnabled(is_ready)

        # Params and trigger groups
        self._fim_param_group.setEnabled(is_ready)
        self._fim_trig_group.setEnabled(is_ready)

        if state == "loading":
            self.fim_load_btn.setText("Loading…")
            self._fim_spinner_timer.start()
        else:
            self._fim_spinner_timer.stop()
            self.fim_load_btn.setText("Load Models")

        if state == "disabled":
            self.fim_status_lbl.setText("")
            self.fim_status_lbl.setStyleSheet("")
        elif state == "provider_only":
            if not self.fim_status_lbl.text():
                self.fim_status_lbl.setText("Click 'Load Models' to connect")
                self.fim_status_lbl.setStyleSheet("")

    def _fim_on_enabled_toggled(self, checked):
        if checked:
            has_model = bool(self.fim_model_combo.currentText().strip())
            self._fim_set_state("ready" if has_model else "provider_only")
        else:
            self._fim_set_state("disabled")

    def _fim_on_provider_changed(self, _idx):
        pid = self.fim_provider_combo.currentData()
        default_url = _FIM_PROVIDER_URLS.get(pid, "")
        if default_url:
            self.fim_url_edit.setText(default_url)
        # Reset — require re-loading models for the new provider
        self.fim_model_combo.clear()
        self.fim_status_lbl.setText("Click 'Load Models' to connect")
        self.fim_status_lbl.setStyleSheet("")
        if self.fim_enabled.isChecked():
            self._fim_set_state("provider_only")

    def _fim_load_models(self):
        url = self.fim_url_edit.text().strip()
        if not url:
            self.fim_status_lbl.setText("⚠ Enter API URL first")
            self.fim_status_lbl.setStyleSheet("color: orange;")
            return
        # Stop any previous loader
        if self._fim_loader is not None:
            self._fim_loader.quit()
            self._fim_loader.wait(500)
        self._fim_status_msg = "Connecting…"
        self._fim_set_state("loading")
        loader = _FimLoader(
            url, self.fim_key_edit.text().strip(),
            self.fim_provider_combo.currentData(), parent=self)
        loader.sig_status.connect(self._fim_on_status)
        loader.sig_models.connect(self._fim_on_models)
        loader.sig_backends.connect(self._fim_on_backends)
        loader.sig_error.connect(self._fim_on_load_error)
        loader.finished.connect(self._fim_on_load_finished)
        self._fim_loader = loader
        loader.start()

    def _fim_spinner_tick(self):
        self._fim_spinner_idx = (
            (self._fim_spinner_idx + 1) % len(self._fim_spinner_frames))
        frame = self._fim_spinner_frames[self._fim_spinner_idx]
        self.fim_status_lbl.setText(f"{frame}  {self._fim_status_msg}")
        self.fim_status_lbl.setStyleSheet("")

    def _fim_on_status(self, msg):
        self._fim_status_msg = msg
        self.fim_status_lbl.setStyleSheet("")
        if not self._fim_spinner_timer.isActive():
            self.fim_status_lbl.setText(msg)

    def _fim_on_models(self, models):
        current = self.fim_model_combo.currentText()
        self.fim_model_combo.clear()
        for m in models:
            self.fim_model_combo.addItem(m)
        # Restore previously selected model if present
        idx = self.fim_model_combo.findText(current)
        if idx >= 0:
            self.fim_model_combo.setCurrentIndex(idx)

    def _fim_on_backends(self, backends):
        current_key = self.fim_backend_combo.currentData()
        self.fim_backend_combo.clear()
        for k, label in backends:
            self.fim_backend_combo.addItem(label, userData=k)
        idx = self.fim_backend_combo.findData(current_key)
        if idx >= 0:
            self.fim_backend_combo.setCurrentIndex(idx)

    def _fim_on_load_error(self, msg):
        self._fim_spinner_timer.stop()   # stop before setting text — prevents overwrite
        self.fim_status_lbl.setText(f"✗ {msg}")
        self.fim_status_lbl.setStyleSheet("color: red;")

    def _fim_on_load_finished(self):
        # _fim_set_state stops the spinner timer
        if self.fim_model_combo.count() > 0:
            n = self.fim_model_combo.count()
            self._fim_set_state("ready")
            self.fim_status_lbl.setText(f"✓ {n} model(s) loaded")
            self.fim_status_lbl.setStyleSheet("color: green;")
        else:
            # Error already shown by _fim_on_load_error; just restore state
            self._fim_set_state("provider_only")

    def values(self):
        """Return all settings as a dict ready to pass to _save_state."""
        pid = self._current_provider_id()
        return {
            "provider_type":       pid,
            "api_url":             self._url_edit.text().strip(),
            "api_key":             self._key_edit.text().strip(),
            "azure_deployment":    self._azure_dep_edit.text().strip(),
            "azure_api_version":   self._azure_ver_combo.currentText(),
            "editor": {
                "fs_base":    self.fs_base.value(),
                "fs_code":    self.fs_code.value(),
                "fs_heading": self.fs_heading.value(),
                "fs_list":    self.fs_list.value(),
                "fs_table":   self.fs_table.value(),
                "fs_think":   self.fs_think.value(),
            },
            "history": {
                "autosave":    self.cb_autosave.isChecked(),
                "save_on_new": self.cb_save_on_new.isChecked(),
            },
            "commands": self._cmd_commands,
            "fim": {
                "enabled":       self.fim_enabled.isChecked(),
                "provider":      self.fim_provider_combo.currentData(),
                "api_url":       self.fim_url_edit.text().strip(),
                "api_key":       self.fim_key_edit.text().strip(),
                "model":         self.fim_model_combo.currentText().strip(),
                "models":        [self.fim_model_combo.itemText(i)
                                  for i in range(self.fim_model_combo.count())],
                "backend_type":  self.fim_backend_combo.currentData(),
                "backends":      [[self.fim_backend_combo.itemData(i),
                                   self.fim_backend_combo.itemText(i)]
                                  for i in range(self.fim_backend_combo.count())],
                "max_tokens":    self.fim_max_tokens.value(),
                "temperature":   self.fim_temperature.value(),
                "context_before":self.fim_ctx_before.value(),
                "context_after": self.fim_ctx_after.value(),
                "trigger_mode":  self.fim_trigger_combo.currentData(),
                "debounce_ms":   self.fim_debounce.value(),
            },
        }
