# Arandu — Landing Page

Create a landing page for **Arandu**, an open-source Python SDK that gives AI agents long-term memory.

The name comes from the Guarani word meaning "wisdom acquired through experience" — literally "listening to time." It's a Brazilian project.

## The Vibe

**Sunlit Amazon rainforest.** Bright, warm, alive. Think golden afternoon light filtering through a lush green canopy, toucans perched on branches, macaws flying across a blue sky, a river reflecting sunlight. The page should feel like standing in a sun-drenched clearing in the Brazilian rainforest.

Use generated images heavily — this is where the magic happens. Beautiful rainforest photography/illustrations for hero backgrounds, section backgrounds, decorative elements. Toucans, macaws, tropical foliage, sunlight, rivers. Make it gorgeous.

The overall feel: nature meets technology. Ancient wisdom meets modern AI. Brazil.

## Content & Structure

### Navigation
- Logo: "Arandu" with a nature icon
- Links: About, How it Works, Docs, GitHub
- CTA: "Get Started"
- URLs:
  - Docs → https://pe-menezes.github.io/arandu/
  - GitHub → https://github.com/pe-menezes/arandu (new tab)
  - Get Started → https://pe-menezes.github.io/arandu/getting-started/

### Hero
- `pip install arandu` badge (with copy to clipboard)
- Headline: **"Arandu"**
- Subtitle: "Long-term memory for AI agents — wisdom acquired through experience"
- Tagline: "From the Guarani: to listen to time. Give your AI the gift of remembering."
- Buttons: "Get Started" → https://pe-menezes.github.io/arandu/getting-started/ | "View on GitHub" → https://github.com/pe-menezes/arandu
- Background: lush sunlit rainforest imagery

### What is Arandu?
- Heading: "Structured memory that grows with your agent."
- Text: "Most AI agents are stateless — they forget everything between sessions. Arandu gives your agent a persistent, structured memory that grows smarter over time. Using an advanced extraction and reconciliation pipeline, it resolves conflicting information automatically — ensuring your AI maintains a consistent, evolving understanding of the world."
- Visual: a flow diagram showing Message → Extract → Resolve → Reconcile → Remember

### How It Works (3 cards)

**Write Pipeline** — "Send a message, get structured knowledge. Arandu extracts facts, resolves entities, and reconciles with what it already knows — automatically."

**Read Pipeline** — "Ask a question, get relevant context. Semantic search, keyword matching, graph traversal, and recency scoring work together to find what matters."

**Background Jobs** — "Like a brain consolidating memories during sleep. Clustering, consolidation, and importance scoring keep memory organized and fresh."

### Code Example

Show this EXACT code in a beautiful dark code block styled as a code editor:

```python
from arandu import MemoryClient
from arandu.providers.openai import OpenAIProvider

provider = OpenAIProvider(api_key="sk-...")
memory = MemoryClient(
    database_url="postgresql+psycopg://user:pass@localhost/mydb",
    llm=provider,
    embeddings=provider,
)
await memory.initialize()

# Write — extracts facts automatically
await memory.write(
    user_id="user_123",
    message="I live in São Paulo with my wife Ana.",
)

# Retrieve — semantic search + keyword + reranking
result = await memory.retrieve(
    user_id="user_123",
    query="where does the user live?",
)
print(result.context)
# "Lives in São Paulo, Married to Ana..."
```

### Key Features (6 items)
1. **Auto Fact Extraction** — LLM-powered, zero manual tagging
2. **3-Phase Entity Resolution** — Exact → fuzzy → LLM matching
3. **Knowledge Reconciliation** — ADD, UPDATE, DELETE decisions automatically
4. **Multi-Signal Retrieval** — Semantic + keyword + graph + recency
5. **Provider Agnostic** — Bring your own LLM via Python protocols
6. **Built on PostgreSQL** — Battle-tested infrastructure with pgvector

### Architecture
Visual diagram of the two pipelines:
- **Write:** Message → Extract → Resolve → Reconcile → Storage
- **Read:** Query → Plan → Retrieve → Rerank → Context

### Open Source
- "Built in Brazil, shared with the world 🇧🇷"
- "Arandu is MIT licensed and open source."
- Badges: MIT Licensed | v0.6.7 | Python 3.11+

### Footer
- Links: Documentation (https://pe-menezes.github.io/arandu/) | GitHub (https://github.com/pe-menezes/arandu) | PyPI (https://pypi.org/project/arandu/)
- "Made with 💚 in Brazil"
- © 2025 Arandu Project

## Important
- All links must use the exact URLs provided above
- The code example must be exactly as written — it's the real API
- Be creative with the visual design, imagery and animations — make it beautiful and uniquely Brazilian
