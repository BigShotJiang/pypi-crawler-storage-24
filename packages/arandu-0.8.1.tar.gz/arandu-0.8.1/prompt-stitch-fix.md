# Prompt — Fix & Enhance Arandu Landing Page

I need you to make the following changes to this page. Apply ALL of them in a single pass.

---

## 1. FIX THE CODE EXAMPLE (Critical — this is wrong)

The code snippet in the "Code Example" section uses a fake API. Replace the entire code block content with this EXACT code (preserve the syntax highlighting style you already have):

```python
from arandu import MemoryClient
from arandu.providers.openai import OpenAIProvider

provider = OpenAIProvider(api_key="sk-...")
memory = MemoryClient(
    database_url="postgresql+psycopg://user:pass@localhost/mydb",
    llm=provider,
    embeddings=provider,
)
await memory.initialize()

# Write — extracts facts automatically
await memory.write(
    user_id="user_123",
    message="I live in São Paulo with my wife Ana.",
)

# Retrieve — semantic search + keyword + reranking
result = await memory.retrieve(
    user_id="user_123",
    query="where does the user live?",
)
print(result.context)
# "Lives in São Paulo, Married to Ana..."
```

Also rename the file tab from `example_implementation.py` to `quickstart.py`.

---

## 2. FIX ALL LINKS

Replace every `href="#"` with the correct URLs:

- **Nav "About"** → `#about` (scroll to the "What is Arandu?" section, add `id="about"` to that section)
- **Nav "How it Works"** → `#how-it-works` (scroll to the "Lifecycle" section, add `id="how-it-works"` to that section)
- **Nav "GitHub"** → `https://github.com/pe-menezes/arandu` (open in new tab)
- **"Get Started" buttons** (hero + nav) → `https://pe-menezes.github.io/arandu/getting-started/`
- **"View on GitHub" button** → `https://github.com/pe-menezes/arandu` (open in new tab)
- **Footer "Documentation"** → `https://pe-menezes.github.io/arandu/`
- **Footer "GitHub"** → `https://github.com/pe-menezes/arandu`
- **Footer "PyPI"** → `https://pypi.org/project/arandu/`

---

## 3. FIX THE "OPEN SOURCE" SECTION STATS

Remove the fake stats badges (1.2k Stars, v0.4.2, 24 Contributors). Replace them with these three:

- **Badge 1:** MIT License icon + "MIT Licensed"
- **Badge 2:** Package icon + "v0.6.7"
- **Badge 3:** Python icon + "Python 3.11+"

---

## 4. FIX COPYRIGHT

Change `© 2024 Arandu Project` to `© 2025 Arandu Project`.

---

## 5. ADD BRAZILIAN FAUNA — SVG ILLUSTRATIONS & ANIMATIONS

This is the most important visual change. The page is about a Brazilian project named after a Guarani word, but there are ZERO Brazilian animals. Fix this by adding inline SVG illustrations of native fauna with smooth CSS animations:

### 5a. HERO SECTION — Tucano (Toucan)

Remove the "Tucano Perch" placeholder (the Material Symbol icon + label). Replace it with an inline SVG of a **toucan silhouette** perched on a branch, positioned at `top-32 right-[10%]`. The toucan should be rendered in the `secondary` color (#ebc246) with subtle details in `primary` (#7ed9a5). Add a gentle CSS animation: the toucan's head tilts slightly (rotate 3deg back and forth) every 4 seconds with ease-in-out.

### 5b. HERO SECTION — Araras (Macaws) flying

Add 2-3 inline SVG **macaw silhouettes** flying across the hero section. Position them at different heights (top-20, top-48, top-64). Use colors: one in `secondary` (#ebc246), one in `primary` (#7ed9a5), one in `tertiary` (#8bcefb). Animate them with a slow `translateX` animation (flying from right to left), each at different speeds (25s, 35s, 45s) and different delays, looping infinitely. They should be semi-transparent (opacity 0.3-0.5) so they feel atmospheric, not distracting. The flight path should have a very subtle vertical oscillation (sine wave, ±10px) to feel organic.

### 5c. SECTION TRANSITIONS — Leaf decorations

Between the "What is Arandu?" and "How It Works" sections, add a decorative SVG strip of **tropical leaves** (monstera, palm fronds). Render them as simple green silhouettes in different shades of the palette (#0B3D2E, #1A5C3A, #2D8B5E). Give them a very subtle sway animation (rotate ±2deg, 6s cycle). These should act as a natural visual divider.

### 5d. FLOATING PARTICLES — Fireflies / Pollen

Add a layer of small floating particles (tiny circles, 2-4px) across the hero section. Use `primary` and `secondary` colors at very low opacity (0.1-0.2). Animate them floating upward slowly with slight horizontal drift. About 15-20 particles, randomly positioned, different animation durations (8s-20s). This creates the "Amazon at dawn" atmosphere with pollen/fireflies.

### 5e. ARCHITECTURE SECTION — Small bird silhouettes

In the "Memory Flow Architecture" section, add 2 small bird silhouettes (simple V-shapes or arara outlines) flying subtly in the background. Very low opacity (0.1), slow movement. Just to add life to the section without distracting from the content.

### 5f. FOOTER — Subtle vine decoration

Add a thin decorative SVG vine/branch running along the top edge of the footer, rendered in `primary` at 15% opacity. Simple, organic curves with a few small leaves.

---

## 6. ENHANCE HERO BACKGROUND

Replace the Google-hosted image (`lh3.googleusercontent.com/...`) with a CSS-only atmospheric background. Layer multiple radial gradients to create depth:
- Deep dark green base
- Lighter green "canopy" shapes at the top
- Subtle golden light rays from the upper-right corner (using a thin linear-gradient at ~30deg in `secondary` at 3-5% opacity)
- A very subtle noise/grain texture overlay using CSS (repeating-conic-gradient trick or SVG filter) to add organic texture

Also replace the second Google image (in the "What is Arandu?" card) with a CSS gradient + the existing `hub` icon. No external images — the page should work without any network dependencies beyond fonts and Tailwind CDN.

---

## 7. SMALL POLISH

- Remove the duplicate Google Material Symbols stylesheet import (it's loaded twice in `<head>`)
- Add `scroll-behavior: smooth` to the `<html>` element for smooth anchor scrolling
- The "pip install arandu" badge in the hero should actually copy to clipboard on click (add a small JS snippet)

---

## IMPORTANT CONSTRAINTS

- Keep ALL existing sections, layout structure, colors, typography, and glassmorphism effects exactly as they are
- All SVGs must be inline (no external files)
- All animations must be CSS-only (no JS animation libraries)
- Keep performance in mind — use `will-change: transform` on animated elements and prefer `transform` over layout-triggering properties
- The fauna illustrations should feel elegant and atmospheric, NOT cartoonish. Think silhouettes with minimal detail, like nature photography outlines
