"""Query Expansion — Entity Priming.

Post-processes a ``RetrievalPlan`` produced by the retrieval agent to:

1. **Entity priming**: resolve entities mentioned in the query via KG
   (aliases + relationships) and inject context into the query.

Temporal anchoring is handled by the retrieval agent LLM (``as_of_range``).
Called from ``run_read_pipeline()`` between ``plan_retrieval()`` and the
actual retrieval execution.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from arandu.models import MemoryEntity, MemoryEntityAlias, MemoryEntityRelationship, MemoryFact
from arandu.read.retrieval_agent import RetrievalPlan

logger = logging.getLogger(__name__)

__all__ = ["ExpandedQuery", "expand_query", "resolve_query_entities"]

# Maximum entities to expand and max chars to add to query
_MAX_ENTITIES_EXPAND = 5
_MAX_CHARS_ADDED = 200


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass
class ExpandedQuery:
    """Result of query expansion.

    Attributes:
        primed_entities: Entity keys discovered via alias + KG priming.
        temporal_range: Resolved date range (from retrieval agent as_of_range).
        expanded_terms: Additional context terms from entity facts.
    """

    primed_entities: list[str]
    temporal_range: tuple[datetime, datetime] | None
    expanded_terms: list[str]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def expand_query(
    session: AsyncSession,
    agent_id: str,
    query: str,
    plan: RetrievalPlan,
    llm: object,
) -> ExpandedQuery:
    """Expand a retrieval plan with entity priming and temporal anchoring.

    Fail-safe: any exception returns an empty ExpandedQuery.

    Args:
        session: Database session.
        agent_id: User identifier.
        query: Original user query text.
        plan: RetrievalPlan from the retrieval agent.
        llm: LLM provider (reserved for future use).

    Returns:
        ExpandedQuery with primed entities, temporal range, and expanded terms.
    """
    try:
        return await _expand_query_impl(session, agent_id, query, plan)
    except Exception as e:
        logger.warning("query_expansion_failed: user=%s, error=%s", agent_id, e)
        return ExpandedQuery(primed_entities=[], temporal_range=None, expanded_terms=[])


async def _expand_query_impl(
    session: AsyncSession,
    agent_id: str,
    query: str,
    plan: RetrievalPlan,
) -> ExpandedQuery:
    """Internal implementation — may raise."""
    query_text = plan.similarity_query or query or ""
    primed_entities: list[str] = []
    expanded_terms: list[str] = []
    temporal_range: tuple[datetime, datetime] | None = None

    # 1. Entity priming (only for similarity / multi_signal strategies)
    if plan.strategy in ("similarity", "multi_signal", "hybrid") and query_text:
        primed_entities, expanded_terms = await _entity_priming(session, agent_id, query_text)

    # Temporal anchoring is handled by the retrieval agent LLM (as_of_range).

    return ExpandedQuery(
        primed_entities=primed_entities,
        temporal_range=temporal_range,
        expanded_terms=expanded_terms,
    )


# ---------------------------------------------------------------------------
# Entity priming
# ---------------------------------------------------------------------------


async def _entity_priming(
    session: AsyncSession,
    agent_id: str,
    query_text: str,
) -> tuple[list[str], list[str]]:
    """Resolve entities mentioned in the query and return context.

    Steps:
    1. Search aliases matching words in the query → canonical entity_keys.
    2. Fetch 1-hop KG relationships for matched entities.
    3. Fetch top facts (value_text) for matched entities as context.

    Returns:
        Tuple of (entity_keys, context_terms).
    """
    words = _extract_query_words(query_text)
    if not words:
        return [], []

    matched_entities = await _resolve_aliases(session, agent_id, words)
    if not matched_entities:
        return [], []

    entity_keys = set(matched_entities.values())

    related_keys = await _fetch_related_entities(session, agent_id, entity_keys)
    all_keys = entity_keys | related_keys

    context_parts = await _fetch_entity_context(session, agent_id, all_keys)

    expansion = " ".join(context_parts)
    if len(expansion) > _MAX_CHARS_ADDED:
        expansion = expansion[:_MAX_CHARS_ADDED].rsplit(" ", 1)[0]

    terms = [t.strip() for t in expansion.split() if t.strip()]

    if terms:
        logger.info(
            "query_expansion: entity priming added %d terms for user %s (%d entities)",
            len(terms),
            agent_id,
            len(all_keys),
        )

    return list(all_keys), terms


def _extract_query_words(query_text: str) -> list[str]:
    """Extract candidate words from query for alias matching."""
    words = re.findall(r"\b[A-Za-zÀ-ÿ]{2,}\b", query_text)
    return list({w.lower() for w in words})


async def _resolve_aliases(
    session: AsyncSession,
    agent_id: str,
    words: list[str],
) -> dict[str, str]:
    """Resolve words against MemoryEntityAlias.

    Returns:
        Dict mapping alias → canonical_entity_key for matches found.
    """
    if not words:
        return {}

    stmt = (
        select(MemoryEntityAlias.alias, MemoryEntityAlias.canonical_entity_key)
        .where(
            MemoryEntityAlias.agent_id == agent_id,
            MemoryEntityAlias.alias.in_(words),
        )
        .limit(_MAX_ENTITIES_EXPAND * 2)
    )
    result = await session.execute(stmt)
    return {row[0]: row[1] for row in result.all()}


async def _fetch_related_entities(
    session: AsyncSession,
    agent_id: str,
    entity_keys: set[str],
) -> set[str]:
    """Fetch 1-hop related entity_keys from KG relationships."""
    if not entity_keys:
        return set()

    keys_list = list(entity_keys)
    stmt = (
        select(
            MemoryEntityRelationship.source_entity_key,
            MemoryEntityRelationship.target_entity_key,
        )
        .where(
            MemoryEntityRelationship.agent_id == agent_id,
            or_(
                MemoryEntityRelationship.source_entity_key.in_(keys_list),
                MemoryEntityRelationship.target_entity_key.in_(keys_list),
            ),
        )
        .limit(_MAX_ENTITIES_EXPAND * 3)
    )
    result = await session.execute(stmt)

    related: set[str] = set()
    for source, target in result.all():
        if source not in entity_keys:
            related.add(source)
        if target not in entity_keys:
            related.add(target)

    if len(related) > _MAX_ENTITIES_EXPAND:
        related = set(list(related)[:_MAX_ENTITIES_EXPAND])

    return related


async def _fetch_entity_context(
    session: AsyncSession,
    agent_id: str,
    entity_keys: set[str],
) -> list[str]:
    """Fetch top facts for entities to build context terms."""
    if not entity_keys:
        return []

    keys_list = list(entity_keys)[:_MAX_ENTITIES_EXPAND]
    stmt = (
        select(MemoryFact.entity_key, MemoryFact.value_text)
        .where(
            MemoryFact.agent_id == agent_id,
            MemoryFact.entity_key.in_(keys_list),
            MemoryFact.valid_to.is_(None),
            MemoryFact.value_text.isnot(None),
        )
        .order_by(MemoryFact.confidence.desc())
        .limit(_MAX_ENTITIES_EXPAND * 3)
    )
    result = await session.execute(stmt)

    parts: list[str] = []
    for _entity_key, value_text in result.all():
        if value_text and value_text.strip():
            parts.append(value_text.strip())

    return parts


# Temporal anchoring was removed — the retrieval agent LLM handles temporal
# resolution via as_of_range in the plan JSON. This approach is language-agnostic.


# ---------------------------------------------------------------------------
# Deterministic entity resolution for read pipeline
# ---------------------------------------------------------------------------


async def resolve_query_entities(
    session: AsyncSession,
    agent_id: str,
    query_text: str,
) -> list[str]:
    """Resolve entity_keys from query text deterministically (no LLM).

    Three resolution layers run in parallel:
    A) Alias match — words against MemoryEntityAlias.alias
    B) Display name match — words against MemoryEntity.display_name
    C) Slug match — words against entity_key slugs from MemoryFact

    Fail-safe: returns empty list on any error.

    Args:
        session: Database session.
        agent_id: User identifier.
        query_text: Raw query text.

    Returns:
        Deduplicated list of canonical entity_keys found.
    """
    try:
        return await _resolve_query_entities_impl(session, agent_id, query_text)
    except Exception as e:
        logger.warning("resolve_query_entities: failed for user=%s: %s", agent_id, e)
        return []


async def _resolve_query_entities_impl(
    session: AsyncSession,
    agent_id: str,
    query_text: str,
) -> list[str]:
    """Internal implementation — may raise."""
    words = _extract_query_words(query_text)
    if not words:
        return []

    import asyncio

    alias_task = _resolve_aliases(session, agent_id, words)
    display_task = _resolve_by_display_name(session, agent_id, words)
    slug_task = _resolve_by_slug(session, agent_id, words)

    alias_result, display_result, slug_result = await asyncio.gather(
        alias_task,
        display_task,
        slug_task,
        return_exceptions=True,
    )

    entity_keys: list[str] = []
    seen: set[str] = set()

    # Layer A: alias matches
    if isinstance(alias_result, dict):
        for ek in alias_result.values():
            if ek not in seen:
                seen.add(ek)
                entity_keys.append(ek)

    # Layer B: display name matches
    if isinstance(display_result, list):
        for ek in display_result:
            if ek not in seen:
                seen.add(ek)
                entity_keys.append(ek)

    # Layer C: slug matches
    if isinstance(slug_result, list):
        for ek in slug_result:
            if ek not in seen:
                seen.add(ek)
                entity_keys.append(ek)

    return entity_keys[:_MAX_ENTITIES_EXPAND]


async def _resolve_by_display_name(
    session: AsyncSession,
    agent_id: str,
    words: list[str],
) -> list[str]:
    """Resolve entity_keys by matching words against MemoryEntity.display_name.

    Returns:
        List of canonical_key for entities whose display_name contains a query word.
    """
    if not words:
        return []

    conditions = [func.lower(MemoryEntity.display_name).contains(w) for w in words]
    stmt = (
        select(MemoryEntity.canonical_key)
        .where(
            MemoryEntity.agent_id == agent_id,
            MemoryEntity.is_active.is_(True),
            MemoryEntity.display_name.isnot(None),
            or_(*conditions),
        )
        .limit(_MAX_ENTITIES_EXPAND)
    )
    result = await session.execute(stmt)
    return [row[0] for row in result.all()]


async def _resolve_by_slug(
    session: AsyncSession,
    agent_id: str,
    words: list[str],
) -> list[str]:
    """Resolve entity_keys by matching words against entity_key slugs.

    For entity_key "person:carlos", the slug is "carlos".
    Match is case-insensitive and requires full slug match (not substring).

    Returns:
        List of entity_keys whose slug matches a query word.
    """
    if not words:
        return []

    # Get distinct entity_keys for this user
    stmt = (
        select(MemoryFact.entity_key)
        .where(
            MemoryFact.agent_id == agent_id,
            MemoryFact.valid_to.is_(None),
        )
        .distinct()
    )
    result = await session.execute(stmt)
    all_keys = [row[0] for row in result.all() if row[0]]

    words_set = set(words)
    matched: list[str] = []
    for entity_key in all_keys:
        if ":" in entity_key:
            slug = entity_key.rsplit(":", 1)[1].lower().replace("_", " ")
            # Match full slug or individual slug parts against query words
            slug_parts = slug.split()
            if any(part in words_set for part in slug_parts):
                matched.append(entity_key)
        if len(matched) >= _MAX_ENTITIES_EXPAND:
            break

    return matched
