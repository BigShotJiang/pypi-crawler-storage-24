#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Consolidation Stages — thin re-export aggregator (split per Law 5 SoC).

Implementations live in stages/ submodules. This file re-exports the full
public API so all existing callers continue to work without modification.
"""
# Shared helpers (re-exported for tests that import _entry_hash etc.)
from .stages.stage_io import (  # noqa: F401
    _get_entries_for_file, _entry_hash,
    _load_processed_hashes, _save_processed_hashes,
)
# Stage implementations
from .stages.stage_dedup import stage_dedup  # noqa: F401
from .stages.stage_reconsolidation import stage_reconsolidation  # noqa: F401
from .stages.stage_mining import (  # noqa: F401
    stage_pattern_mining,
    stage_schema_promotion,
    stage_schema_promotion_from_sequences,
    stage_cross_domain_transfer,
    stage_2f_cross_region_mining,
    stage_schema_distortion_audit,
    stage_episodic_graduation,
)
from .stages.stage_quality import (  # noqa: F401
    stage_ltd_decay,
    stage_metacognitive_audit,
)
from .stages.stage_promotion import (  # noqa: F401
    stage_promote_to_patterns,
    stage_3c_micro_pattern_promotion,
)
from .stages.stage_graph import (  # noqa: F401
    stage_graph_update,
    stage_4c_abstraction,
)
from .stages.stage_maintenance import (  # noqa: F401
    stage_hierarchical_prune,
    stage_truth_verification,
    stage_10_metamemory,
    stage_synaptic_homeostasis,
    stage_deep_consolidation,
    stage_recency_bonus,
)
# Re-export helper originally from consolidation_helpers (used by daemon)
from .consolidation_helpers import register_discovered_procedures  # noqa: F401
