#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Stage 1: Deduplication — direct import (no subprocess, no timeout)."""
import logging


def stage_dedup(verbose=False):
    """Run pulse_dedup logic in-process instead of as a subprocess.

    FIX: The subprocess call timed out at 120s on every run, meaning
    dedup never completed. Direct import eliminates the timeout.
    """
    try:
        from pulse.daemons.synthesis.pulse_dedup import run_full_dedup
        result = run_full_dedup(verbose=verbose)
        merged = result.get("merged", 0) if isinstance(result, dict) else 0
        if verbose:
            print(f"  [DEDUP] {merged} items merged")
        return {"status": "ok", "merged": merged}
    except Exception as e:
        logging.warning("Stage 1 dedup failed: %s", e)
        return {"status": "error", "error": str(e)}
