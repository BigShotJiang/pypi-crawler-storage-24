#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""
Deep Consolidation — unified into consolidation_stages.py (Phase 1 AGI refinement).

This module re-exports for backward compatibility.
Single source of truth: consolidation_stages.stage_deep_consolidation()
"""
from pulse.daemons.consolidation.consolidation_stages import (  # noqa: F401
    stage_deep_consolidation as deep_consolidation_cycle,
)
