#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
Consolidation Helper Functions: Pattern mining and sequence extraction.

Extracted from consolidation_stages.py per Law 7 (files <= 300 lines).
Mining logic delegated to consolidation_mining.py (split for Law 7).

Helper functions for:
  - Event sequence extraction from agent sessions
  - Cross-session pattern mining from lessons/patterns
  - Procedural workflow registration

Dependencies: Python stdlib + brain_utils, consolidation_mining (internal)
"""
import sys
from pathlib import Path


# Re-export from consolidation_mining (mining functions)
from .consolidation_mining import (  # noqa: F401
    extract_event_sequences,
    mine_cross_session_patterns,
    register_discovered_procedures,
    _now_iso,
    SESSIONS_FILE,
    PATTERNS_FILE,
    LESSONS_FILE,
)
# Schema promotion lives in consolidation_promotion (single source of truth)
from .consolidation_promotion import (  # noqa: F401
    promote_cross_patterns_to_schemas,
    promote_sequences_to_schemas,
)
