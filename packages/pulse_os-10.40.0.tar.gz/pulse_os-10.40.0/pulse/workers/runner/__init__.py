# pulse.workers.runner — headless task execution pipeline
