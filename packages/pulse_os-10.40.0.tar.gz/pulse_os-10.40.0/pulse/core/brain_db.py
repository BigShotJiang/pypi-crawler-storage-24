import math
import sqlite3
import threading
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, List, Dict
from pulse.core.paths import get_state_dir, get_brain_dir
from pulse.core.brain_utils import _make_fingerprint as make_fingerprint
from pulse.core.brain_io import _acquire
DB_PATH = get_brain_dir() / "pulse_brain.db"
_local = threading.local()
_db_initialized = False
_init_lock = threading.Lock()

_VALID_TABLES = frozenset({
    "lessons", "failures", "patterns", "private", "intents", "decisions",
    "facts", "evidence", "predictions", "knowledge_fts",
})


def _validate_table(table: str) -> str:
    if table not in _VALID_TABLES:
        raise ValueError(f"Invalid table name: {table!r}")
    return table
# Item 55: Critical period tracking (P14 Neuroplasticity)
_CRITICAL_PERIOD_DOMAINS: dict = {}  # {domain: items_remaining}
_CRITICAL_PERIOD_SIZE = 10
# S37: protect _CRITICAL_PERIOD_DOMAINS mutations in hot path
_cp_lock = threading.Lock()

_KNOWLEDGE_COLS = """
    id                  TEXT PRIMARY KEY,
    fingerprint         TEXT NOT NULL,
    type                TEXT NOT NULL DEFAULT 'lesson',
    content             TEXT NOT NULL,
    title               TEXT NOT NULL DEFAULT '',
    domain              TEXT NOT NULL DEFAULT 'general',
    agent               TEXT NOT NULL DEFAULT 'unknown',
    timestamp           TEXT NOT NULL DEFAULT '',
    salience            REAL NOT NULL DEFAULT 1.0,
    confidence          REAL NOT NULL DEFAULT 0.5,
    consolidation_count INTEGER NOT NULL DEFAULT 1,
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    access_count        INTEGER NOT NULL DEFAULT 0,
    last_accessed       TEXT DEFAULT NULL,
    last_reinforced     TEXT DEFAULT NULL,
    source_type         TEXT NOT NULL DEFAULT 'CONVERSATIONAL',
    decay_score         REAL NOT NULL DEFAULT 1.0,
    validity            TEXT NOT NULL DEFAULT 'valid',
    embedding           BLOB DEFAULT NULL,
    tags                TEXT NOT NULL DEFAULT '[]',
    cross_refs          TEXT NOT NULL DEFAULT '[]',
    provenance          TEXT NOT NULL DEFAULT '{}',
    metadata            TEXT NOT NULL DEFAULT '{}',
    created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    updated_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
"""

def _knowledge_indexes(table: str) -> list[str]:
    _validate_table(table)
    return [
        f"CREATE UNIQUE INDEX IF NOT EXISTS uq_{table}_fingerprint ON {table}(fingerprint);",
        f"CREATE INDEX IF NOT EXISTS idx_{table}_domain ON {table}(domain);",
        f"CREATE INDEX IF NOT EXISTS idx_{table}_timestamp ON {table}(timestamp DESC);",
        f"CREATE INDEX IF NOT EXISTS idx_{table}_valid_salience ON {table}(validity, salience DESC);"
    ]

def _tables_exist(conn) -> bool:
    """Quick read-only check if all required tables exist (no write lock)."""
    try:
        _REQUIRED = {
            "lessons", "failures", "patterns", "private", "intents",
            "decisions", "facts", "evidence", "predictions",
            "knowledge_fts", "retrieval_metrics", "graph_nodes",
            "graph_edges", "schemas", "anti_patterns", "procedures", "episodic",
        }
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table','view')"
        ).fetchall()
        existing = {r[0] for r in rows}
        return _REQUIRED.issubset(existing)
    except Exception:
        return False


def get_conn() -> sqlite3.Connection:
    if not hasattr(_local, "conn"):
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(DB_PATH.resolve()), check_same_thread=False)
        try:
            import sqlite_vec
            conn.enable_load_extension(True)
            sqlite_vec.load(conn)
            conn.enable_load_extension(False)
        except Exception:
            pass
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA busy_timeout=30000;")
        conn.create_function("SQRT", 1, math.sqrt)
        conn.row_factory = sqlite3.Row
        _local.conn = conn
    global _db_initialized
    if not _db_initialized:
        # Fast path: if tables already exist, skip heavy init_db entirely.
        # This avoids the write-lock convoy when 12+ daemons start simultaneously.
        if _tables_exist(_local.conn):
            _db_initialized = True
        else:
            # Cross-process file lock prevents 12 daemon processes from
            # calling init_db() simultaneously on fresh DB (thundering herd).
            with _acquire(DB_PATH):
                with _init_lock:
                    if not _db_initialized:
                        if _tables_exist(_local.conn):
                            _db_initialized = True
                        else:
                            try:
                                init_db()
                                _db_initialized = True
                            except Exception:
                                raise
    return _local.conn

def init_db() -> None:
    conn = _local.conn  # Use thread-local conn directly — do NOT call get_conn() (causes infinite recursion)
    tables = [
        "lessons", "failures", "patterns", "private", "intents", "decisions", "facts", "evidence"
    ]
    with conn:
        # predictions table (queried by Gate 3 and prediction_daemon)
        conn.execute("""CREATE TABLE IF NOT EXISTS predictions (
            id TEXT PRIMARY KEY, content TEXT NOT NULL,
            domain TEXT NOT NULL DEFAULT 'general', agent TEXT NOT NULL DEFAULT 'unknown',
            confidence REAL NOT NULL DEFAULT 0.5, salience REAL NOT NULL DEFAULT 1.0,
            timestamp TEXT NOT NULL DEFAULT '', outcome TEXT DEFAULT NULL,
            verified INTEGER DEFAULT 0, metadata TEXT DEFAULT '{}'
        );""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_pred_domain ON predictions(domain);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_pred_ts ON predictions(timestamp DESC);")
        for t in tables:
            conn.execute(f"CREATE TABLE IF NOT EXISTS {t} ({_KNOWLEDGE_COLS});")
            for idx in _knowledge_indexes(t):
                conn.execute(idx)

        conn.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts5(
            item_id UNINDEXED, content, title, domain, agent, table_name
        );
        """)

        conn.execute("""
        CREATE TABLE IF NOT EXISTS retrieval_metrics (
            item_key TEXT PRIMARY KEY,
            retrieval_count INTEGER DEFAULT 0,
            last_accessed TEXT
        );""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS graph_nodes (
            id TEXT PRIMARY KEY, type TEXT NOT NULL DEFAULT 'CONCEPT',
            text TEXT NOT NULL, source TEXT DEFAULT '', confidence REAL DEFAULT 0.5,
            domain TEXT NOT NULL DEFAULT 'general',
            date TEXT DEFAULT '', degree INTEGER DEFAULT 0, embedding BLOB DEFAULT NULL,
            metadata TEXT DEFAULT '{}'
        );""")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS graph_edges (
            id INTEGER PRIMARY KEY AUTOINCREMENT, from_node TEXT NOT NULL,
            to_node TEXT NOT NULL, edge_type TEXT NOT NULL,
            confidence REAL DEFAULT 0.5, source_node TEXT DEFAULT '',
            metadata TEXT DEFAULT '{}',
            UNIQUE(from_node, edge_type, to_node)
        );""")

        conn.execute("CREATE INDEX IF NOT EXISTS idx_ge_to_node ON graph_edges(to_node);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_gn_degree ON graph_nodes(degree DESC);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_gn_domain ON graph_nodes(domain);")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS schemas (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT,
            domain TEXT DEFAULT 'general', confidence REAL DEFAULT 0.5,
            type TEXT DEFAULT 'heuristic', source TEXT DEFAULT 'schema_daemon',
            evidence_links TEXT DEFAULT '[]', created TEXT, metadata TEXT DEFAULT '{}'
        );""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_schemas_domain ON schemas(domain);")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS anti_patterns (
            id TEXT PRIMARY KEY, description TEXT NOT NULL, rule TEXT,
            reason TEXT, domain TEXT DEFAULT 'general', keywords TEXT DEFAULT '[]',
            severity TEXT DEFAULT 'medium', evidence_count INTEGER DEFAULT 1,
            status TEXT DEFAULT 'active', source TEXT, created TEXT,
            metadata TEXT DEFAULT '{}',
            validity TEXT DEFAULT 'valid',
            access_count INTEGER DEFAULT 0
        );""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ap_status ON anti_patterns(status);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ap_domain ON anti_patterns(domain);")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS procedures (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT,
            steps TEXT DEFAULT '[]', domain TEXT DEFAULT 'general',
            confidence REAL DEFAULT 0.5, executions INTEGER DEFAULT 0,
            successes INTEGER DEFAULT 0, failures_count INTEGER DEFAULT 0,
            source TEXT DEFAULT 'procedure_daemon', created TEXT,
            metadata TEXT DEFAULT '{}'
        );""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_proc_domain ON procedures(domain);")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS episodic (
            id TEXT PRIMARY KEY, summary TEXT, entities TEXT DEFAULT '[]',
            agent TEXT, domain TEXT DEFAULT 'general', keywords TEXT DEFAULT '[]',
            timestamp TEXT, session_id TEXT, metadata TEXT DEFAULT '{}'
        );""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_episodic_ts ON episodic(timestamp DESC);")

        for _stmt in [
            "ALTER TABLE graph_nodes ADD COLUMN domain TEXT NOT NULL DEFAULT 'general'",
            "ALTER TABLE anti_patterns ADD COLUMN validity TEXT DEFAULT 'valid'",
            "ALTER TABLE anti_patterns ADD COLUMN access_count INTEGER DEFAULT 0",
            "ALTER TABLE anti_patterns ADD COLUMN confidence REAL DEFAULT 0.5",
        ] + [f"ALTER TABLE {t} ADD COLUMN last_reinforced TEXT DEFAULT NULL" for t in tables]:
            try: conn.execute(_stmt)
            except sqlite3.OperationalError: pass
        conn.execute("UPDATE anti_patterns SET confidence=0.85 WHERE evidence_count>=5 AND (confidence IS NULL OR confidence<0.85)")

        for t in tables + ["schemas", "anti_patterns"]:
            try:
                conn.execute(
                    "ALTER TABLE " + t + " ADD COLUMN"
                    " source_type TEXT NOT NULL DEFAULT 'CONVERSATIONAL'"
                )
            except sqlite3.OperationalError:
                pass
            try:
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_" + t + "_source_type"
                    " ON " + t + "(source_type)"
                )
            except Exception:
                pass

        _FTS_MAP = {"schemas": ("description","name","source"), "anti_patterns": ("description","rule","source")}
        for _tbl in ("intents", "anti_patterns", "decisions", "schemas"):
            try:
                if conn.execute(f"SELECT COUNT(*) FROM {_tbl}").fetchone()[0] > 0 and conn.execute("SELECT COUNT(*) FROM knowledge_fts WHERE table_name=?", (_tbl,)).fetchone()[0] == 0:
                    _c, _t, _a = _FTS_MAP.get(_tbl, ("content","title","agent"))
                    conn.execute(f"INSERT INTO knowledge_fts (item_id,content,title,domain,agent,table_name) SELECT id,{_c},{_t},domain,{_a},'{_tbl}' FROM {_tbl}")
            except Exception: pass

        for _tbl in ("lessons","failures","patterns","facts","intents","decisions","schemas","anti_patterns"):
            try: conn.execute(f"DELETE FROM knowledge_fts WHERE table_name=? AND item_id NOT IN (SELECT id FROM {_tbl})", (_tbl,))
            except Exception: pass

        # Item 26: Primacy protection — earliest items are founding episodes, mark permanent
        try:
            for table in tables:
                conn.execute(
                    f"UPDATE {table} SET validity = 'permanent' "
                    f"WHERE id IN (SELECT id FROM {table} ORDER BY timestamp ASC LIMIT 10) "
                    f"AND validity != 'permanent'"
                )
            conn.commit()
        except Exception:
            pass
def insert_knowledge(table: str, data: Dict[str, Any]) -> Optional[str]:
    """Insert knowledge (idempotent via UNIQUE fingerprint)."""
    _validate_table(table)
    # BCM gate: suppress low-salience writes during high load
    try:
        signals = __import__("pulse.core.interoception", fromlist=["get_signals"]).get_signals()
        if signals.get("agent_load", 0) > 5 and float(data.get("salience", 1.0)) < 3.0:
            return None
    except Exception:
        pass
    conn = get_conn()
    content = data.get("content", "")
    fingerprint = data.get("fingerprint") or (make_fingerprint(content) if content else "null")
    item_id = data.get("id") or f"L-{fingerprint[:8]}"
    tags = json.dumps(data.get("tags", [])) if isinstance(data.get("tags"), list) else data.get("tags", "[]")
    cross_refs = json.dumps(data.get("cross_refs", [])) if isinstance(data.get("cross_refs"), list) else data.get("cross_refs", "[]")
    prov = json.dumps(data.get("_provenance", data.get("provenance", {})))
    meta = json.dumps(data.get("metadata", {})) if isinstance(data.get("metadata"), dict) else data.get("metadata", "{}")
    title = data.get("title", "")[:80]
    domain = data.get("domain", "general")
    agent = data.get("agent", "unknown")
    ts = data.get("timestamp", datetime.now(timezone.utc).isoformat())
    # Item 122: Catastrophic forgetting protection
    try:
        from pulse.core.forgetting_protection import protect_high_confidence
        item_id, fingerprint = protect_high_confidence(conn, table, fingerprint, item_id, ts)
    except Exception:
        pass  # fail-open

    with conn:
        conn.execute(
            f"INSERT OR IGNORE INTO {table} "
            "(id, fingerprint, type, content, title, domain, agent, timestamp, "
            "salience, confidence, consolidation_count, evidence_count, "
            "access_count, decay_score, validity, tags, cross_refs, provenance, metadata) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (item_id, fingerprint, data.get("type", "lesson"), content,
             title, domain, agent, ts,
             float(data.get("salience", 1.0)), float(data.get("confidence", 0.5)),
             int(data.get("consolidation_count", 1)), int(data.get("evidence_count", 1)),
             int(data.get("access_count", 0)), float(data.get("decay_score", 1.0)),
             data.get("validity", "valid"), tags, cross_refs, prov, meta))
        if conn.execute("SELECT changes()").fetchone()[0] > 0:
            conn.execute(
                "INSERT INTO knowledge_fts (item_id, content, title, domain, agent, table_name) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (item_id, content, title, domain, agent, table))
    # Item 55: Critical period for new domains (P14 Neuroplasticity)
    # S37: _cp_lock serializes all mutations to prevent race conditions
    try:
        with _cp_lock:
            if domain not in _CRITICAL_PERIOD_DOMAINS:
                existing = conn.execute(f"SELECT COUNT(*) FROM {table} WHERE domain=?", (domain,)).fetchone()[0]
                if existing <= 1:
                    _CRITICAL_PERIOD_DOMAINS[domain] = _CRITICAL_PERIOD_SIZE
            if _CRITICAL_PERIOD_DOMAINS.get(domain, 0) > 0:
                conn.execute(f"UPDATE {table} SET salience=MIN(salience*2.0,10.0) WHERE id=?", (item_id,))
                conn.commit()
                _CRITICAL_PERIOD_DOMAINS[domain] -= 1
                if _CRITICAL_PERIOD_DOMAINS[domain] <= 0:
                    del _CRITICAL_PERIOD_DOMAINS[domain]
    except Exception:
        pass  # fail-open
    # F23: sub-threshold trace — 3+ low-salience appearances → promote
    try:
        row = conn.execute(
            f"SELECT salience, consolidation_count FROM {table} WHERE fingerprint = ?",
            (fingerprint,)).fetchone()
        if row and 0.1 <= float(row["salience"]) <= 0.4 and int(row["consolidation_count"]) >= 3:
            with conn:
                conn.execute(f"UPDATE {table} SET salience = 1.0 WHERE fingerprint = ?", (fingerprint,))
    except Exception:
        pass

    return item_id

def search(query: str, limit: int = 5) -> List[Dict[str, Any]]:
    """FTS5 text search. Returns [] on malformed query instead of raising."""
    conn = get_conn()
    # S36: escape double-quotes to prevent FTS5 parse errors from special chars
    safe_query = query.replace('"', '""')
    try:
        cur = conn.execute(
            "SELECT content, title, domain, agent, table_name, rank "
            "FROM knowledge_fts WHERE knowledge_fts MATCH ? ORDER BY rank LIMIT ?",
            (safe_query, limit))
        return [dict(r) for r in cur.fetchall()]
    except Exception:
        return []
