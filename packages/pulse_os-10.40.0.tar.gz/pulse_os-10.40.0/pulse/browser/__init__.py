# pulse.browser — headless browser automation
