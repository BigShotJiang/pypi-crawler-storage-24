import json
import math
import threading
from datetime import datetime, timezone, timedelta

from pulse.core.paths import get_state_dir
from pulse.core import event_bus
from pulse.core.brain_db import get_conn

MEMORY_DIR = get_state_dir() / "memory"
LABILE_ITEMS_FILE = MEMORY_DIR / "labile_items.json"
TTL_SECONDS = 300  # default fallback

# F45 Per-table reconsolidation lability window (seconds).
# Patterns need longer to stabilize; facts are quickly verified.
_TABLE_TTL = {"lessons": 300, "patterns": 600, "facts": 120}

def _get_ttl(table_name: str) -> int:
    """Return lability TTL for a given table. Patterns longest, facts shortest."""
    return _TABLE_TTL.get(table_name, TTL_SECONDS)

# Phase 4: Critical Periods (Kleim & Jones 2008)
# Young domains are plastic (easy to update), mature domains resist change.
# Sigmoid: plasticity = 1.0 / (1.0 + exp(0.03 * (age_days - 90)))
# Age <30d → plasticity ~0.86, Age 90d → 0.50, Age >180d → ~0.06
CRITICAL_PERIOD_MIDPOINT = 90   # Days at which plasticity = 0.5
CRITICAL_PERIOD_STEEPNESS = 0.03  # How sharp the transition is
MIN_PLASTICITY = 0.1            # Floor — even mature domains can change

# Whitelist of valid DB tables — prevents SQL injection via f-string table names
_VALID_TABLES = frozenset({"lessons", "failures", "patterns", "facts",
                           "schemas", "procedures", "decisions", "episodic"})

_lock = threading.RLock()
_labile_state = {}

def get_domain_plasticity(domain: str) -> float:
    """Compute plasticity for a domain based on its age (Critical Periods).

    Young domains (<30 days) → high plasticity (~0.86), easy to update.
    Mature domains (>180 days) → low plasticity (~0.06), resist change.
    Returns float in [MIN_PLASTICITY, 1.0].
    """
    if not domain:
        return 1.0  # Unknown domain: fully plastic
    try:
        conn = get_conn()
        # Find earliest item timestamp in this domain
        earliest = None
        for table in ("lessons", "failures", "patterns"):
            row = conn.execute(
                f"SELECT MIN(timestamp) as first_ts FROM {table} "
                f"WHERE domain = ? AND validity = 'valid'", (domain,)
            ).fetchone()
            if row and row["first_ts"]:
                if earliest is None or row["first_ts"] < earliest:
                    earliest = row["first_ts"]
        if not earliest:
            return 1.0  # New domain: fully plastic
        first_dt = datetime.fromisoformat(earliest.replace("Z", "+00:00"))
        age_days = (datetime.now(timezone.utc) - first_dt).total_seconds() / 86400
        # Sigmoid: drops from ~1.0 to ~0.0 centered at MIDPOINT
        plasticity = 1.0 / (1.0 + math.exp(CRITICAL_PERIOD_STEEPNESS * (age_days - CRITICAL_PERIOD_MIDPOINT)))
        return max(MIN_PLASTICITY, round(plasticity, 3))
    except Exception:
        return 1.0  # On error: fully plastic (safe default)

def _load_labile():
    global _labile_state
    with _lock:
        if not LABILE_ITEMS_FILE.exists():
            _labile_state = {}
            return
        try:
            with open(LABILE_ITEMS_FILE, "r", encoding="utf-8") as f:
                _labile_state = json.load(f)
        except Exception:
            _labile_state = {}

def _save_labile():
    with _lock:
        MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        with open(LABILE_ITEMS_FILE, "w", encoding="utf-8") as f:
            json.dump(_labile_state, f, indent=2)

def mark_labile(item_id: str, table: str, prediction_error: float = 0.0):
    """Marks an item as labile (open to modification) with a TTL.

    N45: Per Sevenster et al. 2014, reconsolidation requires prediction error.
    Only opens the lability window if prediction_error > 0.3.
    Default prediction_error=0.0 preserves backward compatibility — callers
    that don't pass PE will NOT open a lability window (no silent regressions).
    """
    # N45: Prediction error gate — no PE, no reconsolidation window
    if prediction_error <= 0.3:
        return
    _sweep_expired()  # Clean up stale entries first
    if table not in _VALID_TABLES:
        return  # Reject unknown table names (SQL injection prevention)
    with _lock:
        if not _labile_state:
            _load_labile()

        _labile_state[item_id] = {
            "table": table,
            "expires_at": (datetime.now(timezone.utc) + timedelta(seconds=_get_ttl(table))).isoformat(),
            "prediction_error": round(float(prediction_error), 4),
        }
        _save_labile()
    # Item 164: Track reconsolidation rate for stability monitoring
    try:
        from pulse.brain.reconsolidation_stability import record_reconsolidation_event
        record_reconsolidation_event()
    except Exception:
        pass

def reinforce(item_id: str):
    """Reinforce a labile item (salience += 0.3, reset decay). Loss aversion: reinforce < contradict."""
    with _lock:
        if not _labile_state:
            _load_labile()
            
        if item_id not in _labile_state:
            return False # Not labile
            
        entry = _labile_state[item_id]
        if datetime.fromisoformat(entry["expires_at"]) < datetime.now(timezone.utc):
            del _labile_state[item_id]
            _save_labile()
            return False
            
        # Perform DB update (validate table against whitelist)
        conn = get_conn()
        table = entry["table"]
        if table not in _VALID_TABLES:
            del _labile_state[item_id]
            _save_labile()
            return False
        now_iso = datetime.now(timezone.utc).isoformat()
        # BCM Metaplasticity (Phase 3): diminishing returns for strong items.
        # Formula: delta = 0.3 / (1 + access_count/10) — ranges from 0.3 (new) to ~0.03 (100+ accesses)
        row = conn.execute(f"SELECT access_count, salience, domain FROM {table} WHERE id = ?", (item_id,)).fetchone()
        ac = row["access_count"] if row else 0
        bcm_delta = round(0.3 / (1 + ac / 10), 3)
        # Critical Periods (Phase 4): mature domains resist change
        plasticity = get_domain_plasticity(row["domain"] if row else None)
        bcm_delta = round(bcm_delta * plasticity, 3)
        with conn:
            conn.execute(f"""
                UPDATE {table}
                SET salience = MIN(salience + ?, 7.0),
                    last_accessed = ?,
                    last_reinforced = ?,
                    access_count = access_count + 1
                WHERE id = ?
            """, (bcm_delta, now_iso, now_iso, item_id))
            
        event_bus.publish("memory.reconsolidation.reinforce", "reconsolidation", {"item_id": item_id})
        del _labile_state[item_id]
        _save_labile()
        return True

def contradict(item_id: str):
    """Contradict a labile item (confidence -= 0.2, flag). Loss aversion: contradict > reinforce."""
    with _lock:
        if not _labile_state:
            _load_labile()
            
        if item_id not in _labile_state:
            return False
            
        entry = _labile_state[item_id]
        if datetime.fromisoformat(entry["expires_at"]) < datetime.now(timezone.utc):
            del _labile_state[item_id]
            _save_labile()
            return False
            
        conn = get_conn()
        table = entry["table"]
        if table not in _VALID_TABLES:
            del _labile_state[item_id]
            _save_labile()
            return False
        # Critical Periods (Phase 4): mature domains resist contradiction
        row = conn.execute(f"SELECT domain FROM {table} WHERE id = ?", (item_id,)).fetchone()
        plasticity = get_domain_plasticity(row["domain"] if row else None)
        contradict_delta = round(0.2 * plasticity, 3)
        with conn:
            conn.execute(f"""
                UPDATE {table}
                SET confidence = MAX(confidence - ?, 0.0),
                    validity = CASE WHEN confidence - ? <= 0.0 THEN 'contested' ELSE validity END
                WHERE id = ?
            """, (contradict_delta, contradict_delta, item_id))
        # Item 50 (P13): Tombstone if confidence hit zero (superseded, not deleted)
        try:
            _row50 = conn.execute(f"SELECT confidence FROM {table} WHERE id = ?", (item_id,)).fetchone()
            if _row50 and float(_row50["confidence"]) <= 0.0:
                tombstone_item(item_id, table, new_id="")
        except Exception:
            pass

        event_bus.publish("memory.reconsolidation.contradict", "reconsolidation",
                         {"item_id": item_id, "plasticity": plasticity})
        del _labile_state[item_id]
        _save_labile()
        return True

def _sweep_expired():
    """Clean up items past the 30s window."""
    with _lock:
        if not _labile_state:
            _load_labile()
        now = datetime.now(timezone.utc)
        expired = [k for k, v in _labile_state.items() if datetime.fromisoformat(v["expires_at"]) < now]
        if expired:
            for k in expired:
                del _labile_state[k]
            _save_labile()

def _resolve_superseded_chain(item_id: str, table: str, max_depth: int = 5) -> str:
    """Follow superseded_by chain to find final active version (P18-74).

    If A→B→C, resolves A directly to C. Prevents stale indirect references
    and models synaptic rewiring in neuroplasticity (Bhatt & Bhatt 2009).
    """
    if table not in _VALID_TABLES:
        return item_id
    try:
        import json as _json
        conn = get_conn()
        current = item_id
        for _ in range(max_depth):
            row = conn.execute(
                f"SELECT metadata FROM {table} WHERE id = ? AND validity = 'superseded'",
                (current,)
            ).fetchone()
            if not row:
                return current
            meta = _json.loads(row["metadata"] or "{}")
            next_id = meta.get("superseded_by")
            if not next_id or next_id == current:
                return current
            current = next_id
        return current
    except Exception:
        return item_id
def tombstone_item(old_id: str, table: str, new_id: str = "") -> bool:
    """Item 50 (P13): Tombstone instead of destructive rewrite.

    Marks old_id as superseded with a pointer to new_id, preserving history
    and enabling rollback. Tombstoned items remain queryable with status filter.

    Returns True on success, False on any failure (fail-open).
    """
    if table not in _VALID_TABLES:
        return False
    try:
        conn = get_conn()
        conn.execute(
            f"UPDATE {table} SET validity = 'superseded', "
            f"metadata = json_set(COALESCE(metadata, '{{}}'), '$.superseded_by', ?) "
            f"WHERE id = ? AND validity != 'historical'",
            (new_id, old_id)
        )
        conn.commit()
        return conn.execute("SELECT changes()").fetchone()[0] > 0
    except Exception:
        return False

# Item 125: Memory reconsolidation window tracking (Memory -- P29)
_LABILE_COUNT_WARN_THRESHOLD = 20

def _get_labile_count() -> int:
    """Count items in labile (reconsolidation) window. Large counts warn instability."""
    try:
        _sweep_expired()  # Clean up stale entries first
        with _lock:
            if not _labile_state:
                _load_labile()
            return len(_labile_state)
    except Exception:
        return 0  # fail-open

def _get_reconsolidation_health() -> dict:
    """Return reconsolidation window health metrics.

    Used by brain_health watchdog and dashboard.
    Returns a dict with labile_count and a warning if count > threshold.
    """
    try:
        count = _get_labile_count()
        warning = None
        if count > _LABILE_COUNT_WARN_THRESHOLD:
            warning = (
                f"Memory instability warning: {count} items in labile window "
                f"(threshold={_LABILE_COUNT_WARN_THRESHOLD}). "
                "Too many simultaneous reconsolidations may corrupt knowledge."
            )
        return {
            "labile_count": count,
            "threshold": _LABILE_COUNT_WARN_THRESHOLD,
            "stable": count <= _LABILE_COUNT_WARN_THRESHOLD,
            "warning": warning,
        }
    except Exception:
        return {"labile_count": 0, "threshold": _LABILE_COUNT_WARN_THRESHOLD,
                "stable": True, "warning": None}
get_reconsolidation_health = _get_reconsolidation_health
