# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Query runner — orchestrate brain search and return formatted briefing."""

import logging

try:
    from pulse.brain.brain_search import brain_search
except Exception:
    brain_search = None

from .briefing import format_briefing
from .query_log import _log_query
from .reflex import _inline_reflex
from .briefing_ext import record_query_outcome as _record_outcome


def run_query(query: str, raw_prompt: str = "") -> str:
    """Run brain search and return formatted briefing.

    If raw_prompt is provided, runs inline reflex detection first (<5ms).
    """
    reflex_lines = _inline_reflex(raw_prompt) if raw_prompt else []

    # FIX 9: Phonological buffer — store raw query for working memory rehearsal
    try:
        from pulse.brain.working_memory import _add_phonological
        _add_phonological(query)
    except Exception:
        pass

    if not brain_search or not query or len(query) < 3:
        if reflex_lines:
            return "\n".join(["[BRAIN] Inline reflex detection"] + reflex_lines)
        return ""
    try:
        # Infer task_type for goal-conditioned attention (Phase 1 wiring)
        task_type = "general"
        ql = query.lower()
        if "fix" in ql or "debug" in ql or "error" in ql: task_type = "debug"
        elif "design" in ql or "arch" in ql: task_type = "design"
        elif "feat" in ql or "impl" in ql or "add" in ql: task_type = "feature"
        elif "review" in ql or "audit" in ql: task_type = "review"

        # Metacognitive control: adapt search depth to domain competence
        _max_per_source = 3
        try:
            from pulse.brain.metacognitive_control import get_search_directive
            directive = get_search_directive(query)
            _max_per_source = directive.max_per_source
        except Exception:
            pass

        results = brain_search(query, max_per_source=_max_per_source, task_type=task_type)
        total = results.get("total_results", 0)
        _log_query(query, total)

        # P2-3: Structured ignorance — seed EXPLORE intent when brain is empty/low-quality
        if total == 0:
            try:
                from pulse.core.brain_db import insert_knowledge
                insert_knowledge("intents", {
                    "content": f"EXPLORE: {query}",
                    "type": "strategic_intent",
                    "salience": 3.0,
                })
            except Exception:
                pass
            try:
                _record_outcome(query, failed=True)
            except Exception:
                pass
        else:
            # Also seed if average confidence is below 0.4 across all hits
            all_h = [h for src in results.get("results", {}).values()
                     if isinstance(src, list) for h in src]
            if all_h:
                avg = sum(h.get("confidence", 0.0) for h in all_h) / len(all_h)
                if avg < 0.4:
                    try:
                        from pulse.core.brain_db import insert_knowledge
                        insert_knowledge("intents", {
                            "content": f"EXPLORE: {query}",
                            "type": "strategic_intent",
                            "salience": 3.0,
                        })
                    except Exception:
                        pass

        # Phase 3A: Global Workspace Ignition — runs BEFORE format_briefing so
        # broadcast_items can influence what gets prioritised in the briefing.
        _workspace_winners: list = []
        try:
            from pulse.brain.global_workspace import run_workspace_ignition
            broadcast = run_workspace_ignition("brain_query", query, results, task_type)
            _workspace_winners = broadcast.get("winning_sources", [])
            # Inject broadcast_items into results so format_briefing can see them
            _broadcast_items = broadcast.get("broadcast_items", [])
            if _broadcast_items:
                results["_workspace_broadcast"] = _broadcast_items
        except Exception as e:
            logging.debug(f"Workspace Ignition failed: {e}")

        briefing = format_briefing(query, results)

        if _workspace_winners:
            briefing = f"  [WORKSPACE IGNITION] Winning Coalitions: {', '.join(_workspace_winners).upper()}\n" + briefing

        if reflex_lines:
            # Inject reflex lines at the top, right after the header
            parts = briefing.split("\n", 1) if briefing else ["[BRAIN] Inline reflex"]
            header = parts[0]
            rest = parts[1] if len(parts) > 1 else ""
            return "\n".join([header] + reflex_lines + ([rest] if rest else []))
        return briefing
    except Exception:
        if reflex_lines:
            return "\n".join(["[BRAIN] Inline reflex detection"] + reflex_lines)
        return ""
