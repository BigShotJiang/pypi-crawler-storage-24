# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Hook input parsing — extract search query from file paths and hook events."""

from pathlib import Path


def _query_from_filepath(file_path: str) -> str:
    """Build a search query from a file path."""
    p = Path(file_path)
    name = p.stem.replace("_", " ").replace("-", " ")
    parent = p.parent.name
    if parent and parent not in (".", "", "Tools", "Daemons", "Utilities"):
        return f"{name} {parent.replace('_', ' ')}".strip()
    return name.strip()


def _query_from_hook(hook_input: dict) -> str:
    """Extract search query from Claude Code hook stdin JSON."""
    event = hook_input.get("hook_event_name", "")

    if event == "UserPromptSubmit":
        raw = hook_input.get("prompt", "")[:200].strip()
        return raw.encode("utf-8", errors="replace").decode("utf-8", errors="replace")

    # PreToolUse: Edit or Write
    tool_input = hook_input.get("tool_input", {})
    file_path = tool_input.get("file_path", "")
    if file_path:
        return _query_from_filepath(file_path)

    # Fallback: try command for Bash hooks
    command = tool_input.get("command", "")
    if command:
        return command[:100].strip()

    return ""
