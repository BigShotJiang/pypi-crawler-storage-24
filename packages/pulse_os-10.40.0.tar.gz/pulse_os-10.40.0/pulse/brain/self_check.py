# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Self-referential knowledge check — verifies agent claims about PULSE against brain facts."""

# Hard-coded ground truth about PULSE (canonical facts that should NEVER be wrong)
_PULSE_FACTS = {
    "open_source": False,  # PULSE is PROPRIETARY, not open source
    "repo_visibility": "private",  # GitHub repo is private
    "package_name": "pulse-os",  # PyPI package
    "website": "pulseos.dev",
    "founder": "Fernando",
    "language": "Python",
}

# Phrases that indicate incorrect claims about PULSE.
# Key = phrase to detect in text.
# Value = (fact_key, expected_correct_value, correction_message).
# A warning fires when fact_key value equals expected_correct_value
# (meaning the phrase contradicts that fact).
_CLAIM_PATTERNS = {
    "open.source": ("open_source", False, "PULSE is PROPRIETARY, not open source"),
    "open source": ("open_source", False, "PULSE is PROPRIETARY, not open source"),
    "public repo": ("repo_visibility", "private", "PULSE repo is PRIVATE"),
    "public repository": ("repo_visibility", "private", "PULSE repo is PRIVATE"),
}


def verify_output(text: str) -> list:
    """Check text for incorrect claims about PULSE.

    Returns list of (pattern, correction) tuples for each detected wrong claim.
    """
    warnings = []
    text_lower = text.lower()
    for pattern, (fact_key, expected, correction) in _CLAIM_PATTERNS.items():
        if pattern in text_lower:
            actual = _PULSE_FACTS.get(fact_key)
            if actual == expected:
                warnings.append((pattern, correction))
    return warnings


def check_and_warn(text: str) -> str:
    """Return warning string if text contains incorrect PULSE claims, empty string if OK."""
    issues = verify_output(text)
    if issues:
        return "!! SELF-CHECK WARNING: " + "; ".join(c for _, c in issues)
    return ""
