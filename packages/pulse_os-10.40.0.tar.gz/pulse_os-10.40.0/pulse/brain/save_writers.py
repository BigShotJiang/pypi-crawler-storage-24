#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# DEPRECATED: This file is superseded by save_writers/ package.
# Python resolves `pulse.brain.save_writers` to the package directory first;
# this file is only reached in edge cases. Re-export everything for safety.
from pulse.brain.save_writers import *  # noqa: F401,F403
from pulse.brain.save_writers import (
    _QUALITY_SIGNALS, _passes_quality_gate,
    _CACHE_MAX, _TYPE_PREFIX, _MD_TO_TYPE,
    _JSONL_DEDUP_CACHE, _DEDUP_CACHE,
    _make_fingerprint, _make_entry_id,
    build_jsonl_entry, _load_jsonl_dedup_cache,
    rewrite_jsonl, _micro_consolidation_hook, append_knowledge_jsonl,
    LESSONS_FILE, FAILS_FILE, SESSIONS_FILE, PRIVATE_LESSONS_FILE,
    _write_entries_to_md, write_learnings, write_failures, write_private_learnings,
    append_knowledge_md, append_decision, append_to_json_list,
    log_session, count_brain_queries, record_skill_usage,
    record_procedure, build_save_card,
)
