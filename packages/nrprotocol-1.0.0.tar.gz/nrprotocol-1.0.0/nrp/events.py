"""
NRP Events — real-time push notifications from nodes.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable


class EventSeverity(str, Enum):
    INFO      = "info"       # Normal operational event
    WARNING   = "warning"    # Attention needed, not critical
    CRITICAL  = "critical"   # Immediate action required
    EMERGENCY = "emergency"  # Safety-critical — bypass all queues


@dataclass
class NRPEvent:
    """A real-time notification from a node."""
    node_id: str
    event_type: str
    severity: EventSeverity
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    message: str = ""

    @property
    def is_emergency(self) -> bool:
        return self.severity == EventSeverity.EMERGENCY

    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "event_type": self.event_type,
            "severity": self.severity.value,
            "data": self.data,
            "timestamp": self.timestamp,
            "message": self.message,
        }


EventHandler = Callable[[NRPEvent], None]


class NRPEventBus:
    """
    Simple in-process event bus.
    Emergency events bypass all subscribers and go directly to emergency handlers.
    """

    def __init__(self) -> None:
        self._handlers: list[EventHandler] = []
        self._emergency_handlers: list[EventHandler] = []

    def subscribe(self, handler: EventHandler) -> None:
        self._handlers.append(handler)

    def subscribe_emergency(self, handler: EventHandler) -> None:
        """Emergency handlers are called first, synchronously."""
        self._emergency_handlers.append(handler)

    def emit(self, event: NRPEvent) -> None:
        if event.is_emergency:
            for h in self._emergency_handlers:
                h(event)
        for h in self._handlers:
            h(event)

    def emergency_stop(self, node_id: str, reason: str) -> None:
        """Emit an emergency stop event for a node."""
        self.emit(NRPEvent(
            node_id=node_id,
            event_type="emergency_stop",
            severity=EventSeverity.EMERGENCY,
            message=reason,
        ))
