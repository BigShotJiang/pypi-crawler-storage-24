"""
NRP Manifest — self-describing node capabilities.
Every NRP node declares: who it is, what it can do, what it cannot do.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
from .identity import NRPAddress
from .shield import ShieldRule


@dataclass
class ActionSpec:
    """Description of an action a node can perform."""
    name: str                           # e.g. "move", "grip", "set_temperature"
    description: str
    parameters: dict[str, str] = field(default_factory=dict)  # name -> type description
    reversible: bool = True             # False = physical irreversible action

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
            "reversible": self.reversible,
        }


@dataclass
class ObservableSpec:
    """Description of something a node can report."""
    name: str                           # e.g. "position", "temperature"
    description: str
    unit: str = ""
    type: str = "float"

    def to_dict(self) -> dict:
        return {"name": self.name, "description": self.description,
                "unit": self.unit, "type": self.type}


@dataclass
class NRPManifest:
    """
    Complete self-description of an NRP node.

    Every node publishes its manifest so that:
    - Orchestrators know what it can do
    - Shield rules are enforced before any action
    - Human supervisors can review capabilities
    """
    address: NRPAddress
    description: str
    version: str
    actions: list[ActionSpec] = field(default_factory=list)
    observables: list[ObservableSpec] = field(default_factory=list)
    shield_rules: list[ShieldRule] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    manufacturer: str | None = None
    model: str | None = None

    @property
    def is_physical(self) -> bool:
        return self.address.is_physical

    @property
    def nrp_id(self) -> str:
        return str(self.address)

    @property
    def aap_id(self) -> str:
        return self.address.aap_id

    def to_dict(self) -> dict:
        d: dict = {
            "nrp_id": self.nrp_id,
            "aap_id": self.aap_id,
            "description": self.description,
            "version": self.version,
            "is_physical": self.is_physical,
            "actions": [a.to_dict() for a in self.actions],
            "observables": [o.to_dict() for o in self.observables],
            "shield_rules": [r.to_dict() for r in self.shield_rules],
            "tags": self.tags,
        }
        if self.manufacturer: d["manufacturer"] = self.manufacturer
        if self.model: d["model"] = self.model
        return d
