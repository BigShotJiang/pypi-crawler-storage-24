"""
NRP Shield — unbreakable constraints for physical nodes.
Shield rules are NOT configurable by agents. They are enforced at the driver level.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable
from enum import Enum


class ShieldOperator(str, Enum):
    MAX       = "max"       # value must not exceed max
    MIN       = "min"       # value must not go below min
    RANGE     = "range"     # value must be within [min, max]
    ENUM      = "enum"      # value must be in allowed set
    FORBIDDEN = "forbidden" # action is completely forbidden


@dataclass
class ShieldRule:
    """
    An unbreakable constraint on a node parameter or action.

    Examples:
        ShieldRule("force_n", operator=ShieldOperator.MAX, max_value=50.0,
                   description="Max 50 Newtons — structural limit")
        ShieldRule("temperature_c", operator=ShieldOperator.RANGE,
                   min_value=-10.0, max_value=80.0)
        ShieldRule("delete_all", operator=ShieldOperator.FORBIDDEN,
                   description="Cannot delete all data")
    """
    parameter: str
    operator: ShieldOperator
    max_value: float | None = None
    min_value: float | None = None
    allowed_values: list[Any] = field(default_factory=list)
    description: str = ""
    unit: str = ""

    def check(self, value: Any) -> "ShieldResult":
        """
        Check if a value violates this rule.
        Returns ShieldResult with blocked=True if violated.
        """
        if self.operator == ShieldOperator.FORBIDDEN:
            return ShieldResult(
                blocked=True,
                rule=self,
                value=value,
                reason=f"Action '{self.parameter}' is forbidden. {self.description}",
            )
        if self.operator == ShieldOperator.MAX and self.max_value is not None:
            if float(value) > self.max_value:
                return ShieldResult(
                    blocked=True, rule=self, value=value,
                    reason=f"{self.parameter}={value}{self.unit} exceeds max {self.max_value}{self.unit}",
                )
        if self.operator == ShieldOperator.MIN and self.min_value is not None:
            if float(value) < self.min_value:
                return ShieldResult(
                    blocked=True, rule=self, value=value,
                    reason=f"{self.parameter}={value}{self.unit} below min {self.min_value}{self.unit}",
                )
        if self.operator == ShieldOperator.RANGE:
            v = float(value)
            if self.min_value is not None and v < self.min_value:
                return ShieldResult(
                    blocked=True, rule=self, value=value,
                    reason=f"{self.parameter}={value}{self.unit} below range min {self.min_value}{self.unit}",
                )
            if self.max_value is not None and v > self.max_value:
                return ShieldResult(
                    blocked=True, rule=self, value=value,
                    reason=f"{self.parameter}={value}{self.unit} exceeds range max {self.max_value}{self.unit}",
                )
        if self.operator == ShieldOperator.ENUM and self.allowed_values:
            if value not in self.allowed_values:
                return ShieldResult(
                    blocked=True, rule=self, value=value,
                    reason=f"{self.parameter}={value!r} not in allowed values: {self.allowed_values}",
                )
        return ShieldResult(blocked=False, rule=self, value=value)

    def to_dict(self) -> dict:
        d: dict = {"parameter": self.parameter, "operator": self.operator.value}
        if self.max_value is not None: d["max_value"] = self.max_value
        if self.min_value is not None: d["min_value"] = self.min_value
        if self.allowed_values: d["allowed_values"] = self.allowed_values
        if self.description: d["description"] = self.description
        if self.unit: d["unit"] = self.unit
        return d


@dataclass
class ShieldResult:
    """Result of a shield rule check."""
    blocked: bool
    rule: ShieldRule
    value: Any
    reason: str = ""

    def __bool__(self) -> bool:
        return not self.blocked


class ShieldViolation(Exception):
    """Raised when a shield rule is violated."""
    def __init__(self, result: ShieldResult):
        super().__init__(result.reason)
        self.result = result


def check_all(rules: list[ShieldRule], params: dict[str, Any]) -> list[ShieldResult]:
    """Check all shield rules against a parameter dict. Returns all violations."""
    violations = []
    for rule in rules:
        if rule.parameter in params:
            result = rule.check(params[rule.parameter])
            if result.blocked:
                violations.append(result)
        elif rule.operator == ShieldOperator.FORBIDDEN and rule.parameter in params:
            violations.append(ShieldResult(
                blocked=True, rule=rule, value=None,
                reason=f"Forbidden action: {rule.parameter}",
            ))
    return violations
