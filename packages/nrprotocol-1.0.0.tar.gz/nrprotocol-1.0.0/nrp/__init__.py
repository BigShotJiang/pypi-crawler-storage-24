"""
NRP — Node Reach Protocol
AAP for the physical world.

https://nrprotocol.dev
License: MIT
"""
from .identity import NRPAddress, NRPAddress as Address, is_physical_kind
from .manifest import NRPManifest, ActionSpec, ObservableSpec
from .driver import NRPDriver, NRPNode, ObserveResult, ActionResult
from .shield import ShieldRule, ShieldOperator, ShieldResult, ShieldViolation, check_all
from .events import NRPEvent, NRPEventBus, EventSeverity

__version__ = "0.1.0"
__all__ = [
    "NRPAddress", "Address", "is_physical_kind",
    "NRPManifest", "ActionSpec", "ObservableSpec",
    "NRPDriver", "NRPNode", "ObserveResult", "ActionResult",
    "ShieldRule", "ShieldOperator", "ShieldResult", "ShieldViolation", "check_all",
    "NRPEvent", "NRPEventBus", "EventSeverity",
]
