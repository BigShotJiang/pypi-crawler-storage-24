"""
NRP Identity — extends AAPIdentity for physical nodes.
Address: nrp://scope/kind/name
"""
from __future__ import annotations
import re
from dataclasses import dataclass

NRP_ID_PATTERN = re.compile(r"^nrp://[a-z0-9\-\.]+/[a-z0-9\-]+/[a-z0-9\-\.]+$")

PHYSICAL_KINDS = frozenset({
    "robot", "drone", "vehicle", "actuator", "valve",
    "motor", "gripper", "pump", "conveyor", "crane",
})
SENSOR_KINDS = frozenset({
    "sensor", "camera", "lidar", "gps", "accelerometer",
    "thermometer", "pressure", "humidity", "flow",
})
INFRA_KINDS = frozenset({
    "server", "gateway", "router", "switch", "plc", "hmi", "edge",
})


def is_physical_kind(kind: str) -> bool:
    """Physical kinds carry irreversible actuator potential."""
    return kind in PHYSICAL_KINDS


@dataclass
class NRPAddress:
    """
    Universal node address: nrp://scope/kind/name

    scope: location or organization  (factory-3, home, fleet)
    kind:  device category           (robot, sensor, server)
    name:  instance identifier       (arm-7, soil-north, prod-1)
    """
    scope: str
    kind: str
    name: str

    def __str__(self) -> str:
        return f"nrp://{self.scope}/{self.kind}/{self.name}"

    @classmethod
    def parse(cls, address: str) -> "NRPAddress":
        if not NRP_ID_PATTERN.match(address):
            raise ValueError(
                f"Invalid NRP address: {address!r}. "
                f"Expected: nrp://scope/kind/name"
            )
        parts = address.removeprefix("nrp://").split("/")
        return cls(scope=parts[0], kind=parts[1], name=parts[2])

    @property
    def is_physical(self) -> bool:
        return is_physical_kind(self.kind)

    @property
    def aap_id(self) -> str:
        return f"aap://{self.scope}/{self.kind}/{self.name}@1.0.0"
