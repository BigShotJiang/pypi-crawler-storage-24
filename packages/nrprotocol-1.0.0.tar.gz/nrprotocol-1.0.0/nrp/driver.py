"""
NRP Driver — the universal interface every physical node implements.
Exactly 4 methods. No more. No less.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any
from .manifest import NRPManifest
from .shield import ShieldRule, ShieldViolation, check_all


@dataclass
class ObserveResult:
    """Current state of the node."""
    node_id: str
    state: dict[str, Any]
    timestamp: str
    healthy: bool = True
    detail: str | None = None


@dataclass
class ActionResult:
    """Result of an executed action."""
    node_id: str
    action: str
    params: dict[str, Any]
    success: bool
    output: Any = None
    detail: str | None = None


class NRPDriver(ABC):
    """
    Universal interface for any NRP node.

    Implement these 4 methods to connect any device to the AAP ecosystem.
    Average implementation: ~100 lines.

    Example:
        class MySensor(NRPDriver):
            def manifest(self): ...
            def observe(self): ...
            def act(self, action, params): ...
            def shield_rules(self): ...
    """

    @abstractmethod
    def manifest(self) -> NRPManifest:
        """Declare who this node is and what it can do."""
        ...

    @abstractmethod
    def observe(self) -> ObserveResult:
        """Return current state. Read-only. No side effects."""
        ...

    @abstractmethod
    def act(self, action: str, params: dict[str, Any]) -> ActionResult:
        """
        Execute an action. Called ONLY after shield rules pass.
        Do NOT call directly — use NRPNode.execute() which enforces shields.
        """
        ...

    @abstractmethod
    def shield_rules(self) -> list[ShieldRule]:
        """
        Declare unbreakable constraints.
        These are enforced BEFORE act() is called.
        The agent cannot override them.
        """
        ...


class NRPNode:
    """
    Wraps a driver with shield enforcement and audit hooks.
    This is what orchestrators interact with — never the raw driver.
    """

    def __init__(self, driver: NRPDriver) -> None:
        self._driver = driver
        self._manifest: NRPManifest | None = None

    @property
    def manifest(self) -> NRPManifest:
        if self._manifest is None:
            self._manifest = self._driver.manifest()
        return self._manifest

    @property
    def id(self) -> str:
        return self.manifest.nrp_id

    @property
    def is_physical(self) -> bool:
        return self.manifest.is_physical

    def observe(self) -> ObserveResult:
        """Safe read — no shields needed."""
        return self._driver.observe()

    def execute(
        self,
        action: str,
        params: dict[str, Any],
        on_blocked: Any = None,
    ) -> ActionResult:
        """
        Execute an action with full shield enforcement.
        Shields are checked BEFORE the action runs.
        A blocked action never reaches act().
        """
        rules = self._driver.shield_rules()

        # Check action-level forbidden rules
        action_violations = [
            r for r in rules
            if r.parameter == action
            and r.operator.value == "forbidden"
        ]
        if action_violations:
            raise ShieldViolation(
                type("R", (), {
                    "blocked": True,
                    "rule": action_violations[0],
                    "value": action,
                    "reason": f"Action '{action}' is forbidden on {self.id}",
                })()
            )

        # Check parameter violations
        violations = check_all(rules, params)
        if violations:
            raise ShieldViolation(violations[0])

        return self._driver.act(action, params)

    def to_dict(self) -> dict:
        return self.manifest.to_dict()
