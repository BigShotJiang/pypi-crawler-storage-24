"""NRP Test Suite"""
import sys
sys.path.insert(0, "..")
import pytest
from nrp import (
    NRPAddress, NRPManifest, NRPDriver, NRPNode,
    ActionSpec, ObservableSpec, ObserveResult, ActionResult,
    ShieldRule, ShieldOperator, ShieldViolation,
    NRPEvent, NRPEventBus, EventSeverity,
)
from datetime import datetime, timezone


# ─── Fixtures ─────────────────────────────────────────────────────────────────

class MockSensorDriver(NRPDriver):
    def manifest(self):
        return NRPManifest(
            address=NRPAddress.parse("nrp://lab/sensor/temp-1"),
            description="Temperature sensor",
            version="1.0.0",
            observables=[ObservableSpec("temperature", "Current temp", "C", "float")],
        )
    def observe(self):
        return ObserveResult(
            node_id="nrp://lab/sensor/temp-1",
            state={"temperature": 22.5},
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
    def act(self, action, params):
        return ActionResult("nrp://lab/sensor/temp-1", action, params, success=True)
    def shield_rules(self):
        return []


class MockRobotDriver(NRPDriver):
    def manifest(self):
        return NRPManifest(
            address=NRPAddress.parse("nrp://factory/robot/arm-1"),
            description="Robot arm",
            version="1.0.0",
            actions=[ActionSpec("move", "Move arm", {"force_n": "float"})],
        )
    def observe(self):
        return ObserveResult(
            node_id="nrp://factory/robot/arm-1",
            state={"position": 0},
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
    def act(self, action, params):
        return ActionResult("nrp://factory/robot/arm-1", action, params, success=True)
    def shield_rules(self):
        return [
            ShieldRule("force_n", ShieldOperator.MAX, max_value=50.0, unit="N"),
            ShieldRule("delete_all", ShieldOperator.FORBIDDEN, description="Never"),
        ]


@pytest.fixture
def sensor_node():
    return NRPNode(MockSensorDriver())

@pytest.fixture
def robot_node():
    return NRPNode(MockRobotDriver())


# ─── NRPAddress ───────────────────────────────────────────────────────────────

class TestNRPAddress:
    def test_parse_valid(self):
        addr = NRPAddress.parse("nrp://factory-3/robot/arm-7")
        assert addr.scope == "factory-3"
        assert addr.kind == "robot"
        assert addr.name == "arm-7"
        assert str(addr) == "nrp://factory-3/robot/arm-7"

    def test_is_physical_robot(self):
        assert NRPAddress.parse("nrp://x/robot/y").is_physical is True

    def test_is_not_physical_sensor(self):
        assert NRPAddress.parse("nrp://x/sensor/y").is_physical is False

    def test_invalid_format_raises(self):
        with pytest.raises(ValueError, match="Invalid NRP address"):
            NRPAddress.parse("not-valid")

    def test_aap_id_conversion(self):
        addr = NRPAddress.parse("nrp://acme/robot/arm-1")
        assert addr.aap_id == "aap://acme/robot/arm-1@1.0.0"


# ─── ShieldRule ───────────────────────────────────────────────────────────────

class TestShieldRule:
    def test_max_rule_passes(self):
        rule = ShieldRule("force", ShieldOperator.MAX, max_value=50.0)
        result = rule.check(30.0)
        assert result.blocked is False

    def test_max_rule_blocks(self):
        rule = ShieldRule("force", ShieldOperator.MAX, max_value=50.0)
        result = rule.check(80.0)
        assert result.blocked is True
        assert "80.0" in result.reason

    def test_range_rule_passes(self):
        rule = ShieldRule("temp", ShieldOperator.RANGE, min_value=-10.0, max_value=80.0)
        assert rule.check(25.0).blocked is False

    def test_range_rule_blocks_above(self):
        rule = ShieldRule("temp", ShieldOperator.RANGE, min_value=-10.0, max_value=80.0)
        assert rule.check(90.0).blocked is True

    def test_range_rule_blocks_below(self):
        rule = ShieldRule("temp", ShieldOperator.RANGE, min_value=-10.0, max_value=80.0)
        assert rule.check(-20.0).blocked is True

    def test_forbidden_always_blocks(self):
        rule = ShieldRule("delete_all", ShieldOperator.FORBIDDEN)
        assert rule.check("anything").blocked is True

    def test_enum_rule_passes(self):
        rule = ShieldRule("mode", ShieldOperator.ENUM, allowed_values=["slow","fast"])
        assert rule.check("slow").blocked is False

    def test_enum_rule_blocks(self):
        rule = ShieldRule("mode", ShieldOperator.ENUM, allowed_values=["slow","fast"])
        assert rule.check("turbo").blocked is True


# ─── NRPNode ──────────────────────────────────────────────────────────────────

class TestNRPNode:
    def test_sensor_is_not_physical(self, sensor_node):
        assert sensor_node.is_physical is False

    def test_robot_is_physical(self, robot_node):
        assert robot_node.is_physical is True

    def test_observe_returns_state(self, sensor_node):
        obs = sensor_node.observe()
        assert obs.healthy is True
        assert "temperature" in obs.state

    def test_execute_within_limits(self, robot_node):
        result = robot_node.execute("move", {"force_n": 30.0})
        assert result.success is True

    def test_execute_blocked_by_shield(self, robot_node):
        with pytest.raises(ShieldViolation) as exc:
            robot_node.execute("move", {"force_n": 80.0})
        assert "50.0" in str(exc.value)

    def test_manifest_cached(self, robot_node):
        m1 = robot_node.manifest
        m2 = robot_node.manifest
        assert m1 is m2


# ─── Events ───────────────────────────────────────────────────────────────────

class TestEvents:
    def test_emit_and_receive(self):
        bus = NRPEventBus()
        received = []
        bus.subscribe(lambda e: received.append(e))
        event = NRPEvent(
            node_id="nrp://x/sensor/y",
            event_type="threshold_exceeded",
            severity=EventSeverity.WARNING,
            message="Temperature too high",
        )
        bus.emit(event)
        assert len(received) == 1
        assert received[0].severity == EventSeverity.WARNING

    def test_emergency_handler_called_first(self):
        bus = NRPEventBus()
        order = []
        bus.subscribe(lambda e: order.append("normal"))
        bus.subscribe_emergency(lambda e: order.append("emergency"))
        bus.emit(NRPEvent(
            node_id="nrp://x/robot/y",
            event_type="collision",
            severity=EventSeverity.EMERGENCY,
        ))
        assert order[0] == "emergency"

    def test_emergency_stop_event(self):
        bus = NRPEventBus()
        stops = []
        bus.subscribe_emergency(lambda e: stops.append(e))
        bus.emergency_stop("nrp://factory/robot/arm-1", "Collision detected")
        assert len(stops) == 1
        assert stops[0].event_type == "emergency_stop"
        assert stops[0].is_emergency is True
