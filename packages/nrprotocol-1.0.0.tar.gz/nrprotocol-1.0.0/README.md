<div align="center">

# NRP — Node Reach Protocol

**AAP for the physical world.**

[![PyPI](https://img.shields.io/pypi/v/nrprotocol?color=2563eb)](https://pypi.org/project/nrprotocol/)
[![License: MIT](https://img.shields.io/badge/License-MIT-2563eb.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-22%20passed-2563eb.svg)](tests/)

[Website](https://nrprotocol.dev) · [AAP Spec](https://aap-protocol.dev) · [Halyn](https://halyn.dev)

</div>

---

NRP implements the [AAP spec](https://aap-protocol.dev) for physical nodes:
robots, IoT sensors, industrial machines, drones, vehicles.

## The Physical World Rule

For nodes where actions have irreversible physical consequences,
**Autonomous (Level 4) is forbidden by spec.** Not configurable. Not overridable.

## 4 methods. Any device.

```python
from nrp import NRPDriver, NRPManifest, NRPAddress, ShieldRule, ShieldOperator

class MyRobot(NRPDriver):
    def manifest(self):
        return NRPManifest(
            address=NRPAddress.parse("nrp://factory/robot/arm-1"),
            description="6-DOF robot arm",
            version="1.0.0",
        )
    def observe(self): ...       # read state — no side effects
    def act(self, action, params): ...  # execute action
    def shield_rules(self):      # unbreakable constraints
        return [
            ShieldRule("force_n", ShieldOperator.MAX, max_value=50.0, unit="N"),
        ]
```

## AAP Ecosystem

| Layer | Project | Role |
|-------|---------|------|
| Spec | [AAP](https://aap-protocol.dev) | Protocol definition |
| Physical | **NRP** (this) | AAP for robots, IoT, machines |
| Full system | [Halyn](https://halyn.dev) | Complete demonstration |

## License

MIT
