from ..shared import BaseDepsKYCClient, DepsKYCException

__all__ = ["DocumentsClient"]


class DocumentsClient(BaseDepsKYCClient):
    def __init__(self, base_url: str, access_token: str) -> None:
        super().__init__(base_url, access_token)

    def get_documents(
        self,
        profile_id: str,
        document_type_kinds: list[str] | None = None,
        statuses: list[str] | None = None,
        subject_kinds: list[str] | None = None,
        subject_name: str | None = None,
        page: int = 0,
        per_page: int = 10,
    ) -> dict:
        """
        Get documents of a profile.

        Args:
            profile_id: ID of the profile to get documents of.
            document_type_kinds: Document type kinds to filter by.
            statuses: Statuses to filter by (`created`, `extracted`, `not_extracted`, `corrected`, `skipped`, `failed`).
            subject_kinds: Subject kinds to filter by (`Individual`, `LegalEntity`).
            subject_name: Subject name to filter by.
            page: The page number to get (0-indexed).
            per_page: The number of documents per page.
        """
        response = self._session.get(
            f"{self._base_url}/v1/documents",
            params={  # type: ignore[arg-type]
                "profileId": profile_id,
                "documentTypeKind": document_type_kinds,
                "status": statuses,
                "subjectKind": subject_kinds,
                "subjectName": subject_name,
                "page": page,
                "perPage": per_page,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def get_document(self, document_id: str) -> dict:
        """
        Get a document.

        Args:
            document_id: ID of the document to get.
        """
        response = self._session.get(f"{self._base_url}/v1/documents/{document_id}")

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def add_corrections(
        self, document_id: str, subject_kind: str, updated_entity: dict
    ) -> dict:
        """
        Add corrections to a document.
        The document should be in `extracted`, `not_extracted` or `corrected` status.

        Args:
            document_id: ID of the document to add corrections to.
            subject_kind: Subject kind of the entity (`Individual`, `LegalEntity`).
            updated_entity: Document entity with corrected values.
        """
        response = self._session.post(
            f"{self._base_url}/v1/documents/{document_id}/corrections",
            json={
                "subjectKind": subject_kind,
                "entity": updated_entity,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def retry_document(self, document_id: str) -> dict:
        """
        Retry a document.
        The document should be in `failed` status and should have retryable error.

        Args:
            document_id: ID of the document to retry.
        """
        response = self._session.post(
            f"{self._base_url}/v1/documents/{document_id}/retry"
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def skip_document(self, document_id: str) -> dict:
        """
        Skip a document.
        The document should be in `failed` or `not_extracted` status.

        Args:
            document_id: ID of the document to skip.
        """
        response = self._session.post(
            f"{self._base_url}/v1/documents/{document_id}/skip"
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()
