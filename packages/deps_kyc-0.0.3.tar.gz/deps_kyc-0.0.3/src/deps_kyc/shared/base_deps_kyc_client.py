from .abstract_rest_client import AbstractRESTClient
from .bearer_auth import BearerAuth

__all__ = ["BaseDepsKYCClient"]


class BaseDepsKYCClient(AbstractRESTClient):
    def __init__(self, base_url: str, access_token: str) -> None:
        self._access_token = access_token
        super().__init__(base_url)

    def _set_authentication(self) -> None:
        self._session.auth = BearerAuth(self._access_token)
