import requests

__all__ = ["BearerAuth"]


class BearerAuth(requests.auth.AuthBase):
    AUTH_HEADER: str = "Authorization"
    TOKEN_PREFIX: str = "Bearer "

    def __init__(self, access_token: str):
        self._access_token = access_token

    def __call__(self, request: requests.PreparedRequest) -> requests.PreparedRequest:
        request.headers.update(self._make_token_header())
        return request

    def _make_token_header(self) -> dict[str, str]:
        return {self.AUTH_HEADER: f"{self.TOKEN_PREFIX}{self._access_token}"}
