from requests import Response

__all__ = ["DepsKYCException"]


class DepsKYCException(Exception):
    def __init__(self, response: Response) -> None:
        super().__init__(f"HTTP {response.status_code}: {response.text}")
