from cachetools import func

from .auth import CognitoAuthClient
from .clients import ClientsClient
from .documents import DocumentsClient
from .files import FilesClient
from .profiles import ProfilesClient
from .settings import DepsKYCSettings

__all__ = ["DepsKYC"]


class DepsKYC:
    def __init__(self, settings: DepsKYCSettings | None = None) -> None:
        self._settings = settings or DepsKYCSettings()

        self._auth_client = CognitoAuthClient(self._settings.auth_settings)

    @property
    @func.ttl_cache(ttl=2700)
    def _access_token(self) -> str:
        return self._auth_client.get_access_token()

    @property
    def files(self) -> FilesClient:
        return FilesClient(self._settings.files_base_url, self._access_token)

    @property
    def profiles(self) -> ProfilesClient:
        return ProfilesClient(self._settings.profiles_base_url, self._access_token)

    @property
    def documents(self) -> DocumentsClient:
        return DocumentsClient(self._settings.documents_base_url, self._access_token)

    @property
    def clients(self) -> ClientsClient:
        return ClientsClient(self._settings.clients_base_url, self._access_token)
