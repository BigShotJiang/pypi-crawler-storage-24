from pydantic_settings import BaseSettings, SettingsConfigDict

__all__ = ["AuthSettings", "DEFAULT_AUTH_SCOPE"]


DEFAULT_AUTH_SCOPE: str = "default-m2m-resource-server-dgxpvr/read"


class AuthSettings(BaseSettings):
    aws_region: str
    aws_cognito_domain: str
    aws_client_id: str
    aws_client_secret: str
    aws_auth_scope: str = DEFAULT_AUTH_SCOPE

    @property
    def token_url(self) -> str:
        return f"https://{self.aws_cognito_domain}.auth.{self.aws_region}.amazoncognito.com/oauth2/token"

    model_config = SettingsConfigDict(env_prefix="DEPS_KYC_")
