import requests
from requests.auth import HTTPBasicAuth

from ..shared import DepsKYCException
from .settings import AuthSettings

__all__ = ["CognitoAuthClient"]


class CognitoAuthClient:
    def __init__(self, settings: AuthSettings | None = None):
        self._settings = settings or AuthSettings()

    def get_access_token(self) -> str:
        response = requests.post(
            self._settings.token_url,
            data={
                "grant_type": "client_credentials",
                "scope": self._settings.aws_auth_scope,
            },
            auth=HTTPBasicAuth(
                self._settings.aws_client_id, self._settings.aws_client_secret
            ),
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()["access_token"]
