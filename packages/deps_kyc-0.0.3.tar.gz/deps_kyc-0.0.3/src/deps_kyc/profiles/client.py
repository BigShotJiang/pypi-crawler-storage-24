from ..shared import BaseDepsKYCClient, DepsKYCException

__all__ = ["ProfilesClient"]


class ProfilesClient(BaseDepsKYCClient):
    def __init__(self, base_url: str, access_token: str) -> None:
        super().__init__(base_url, access_token)

    def create_profile(self, name: str, profile_type_id: str) -> dict:
        """
        Create a profile.

        Args:
            name: Name of the profile to create.
            profile_type_id: ID of the profile type to create the profile from.
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles",
            json={
                "name": name,
                "profileTypeId": profile_type_id,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def get_profiles(
        self,
        statuses: list[str] | None = None,
        name: str | None = None,
        page: int = 0,
        per_page: int = 10,
    ) -> dict:
        """
        Get profiles.

        Args:
            statuses: Statuses to filter by (
                `new`,
                `file_processing`,
                `document_processing`,
                `review`,
                `processed`,
                `submitted`,
                `reconciled`,
                `not_reconciled`,
                `escalated`,
                `approved`,
                `rejected`,
            ).
            name: Name to filter by.
            page: The page number to get (0-indexed).
            per_page: The number of profiles per page.
        """
        response = self._session.get(
            f"{self._base_url}/v1/profiles",
            params={  # type: ignore[arg-type]
                "status": statuses,
                "name": name,
                "page": page,
                "perPage": per_page,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def create_profile_type(
        self, name: str, description: str, subject_kind: str
    ) -> dict:
        """
        Create a profile type.

        Args:
            name: Name of the profile type to create.
            description: Description of the profile type to create.
            subject_kind: Kind of the subject to create the profile type for (`Individual`, `LegalEntity`).
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles-types",
            json={
                "name": name,
                "description": description,
                "subject_kind": subject_kind,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def update_profile_type(
        self, profile_type_id: str, name: str, description: str, subject_kind: str
    ) -> dict:
        """
        Update a profile type.

        Args:
            profile_type_id: ID of the profile type to update.
            name: New name of the profile type.
            description: New description of the profile type.
            subject_kind: New subject kind of the profile type (`Individual`, `LegalEntity`).
        """
        response = self._session.put(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/details",
            json={
                "name": name,
                "description": description,
                "subject_kind": subject_kind,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def add_profile_type_field(
        self,
        profile_type_id: str,
        field_type: str,
        field_name: str,
        field_description: str,
        field_required: bool,
        is_collection: bool,
    ) -> dict:
        """
        Add a field to a profile type.

        Args:
            profile_type_id: ID of the profile type to add the field to.
            field_type: Type of the field to add.
            field_name: Name of the field to add.
            field_description: Description of the field to add.
            field_required: Whether the field is required.
            is_collection: Whether the field is a collection.
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/fields",
            json={
                "type": field_type,
                "name": field_name,
                "description": field_description,
                "required": field_required,
                "is_collection": is_collection,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def update_profile_type_field(
        self,
        profile_type_id: str,
        field_id: str,
        field_name: str,
        field_description: str,
        field_required: bool,
        is_collection: bool,
    ) -> dict:
        """
        Update a field in a profile type.

        Args:
            profile_type_id: ID of the profile type to update the field in.
            field_id: ID of the field to update.
            field_name: New name of the field.
            field_description: New description of the field.
            field_required: New whether the field is required.
            is_collection: New whether the field is a collection.
        """
        response = self._session.put(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/fields/{field_id}",
            json={
                "name": field_name,
                "description": field_description,
                "required": field_required,
                "is_collection": is_collection,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def delete_profile_type_field(self, profile_type_id: str, field_id: str) -> dict:
        """
        Delete a field from a profile type.

        Args:
            profile_type_id: ID of the profile type to delete the field from.
            field_id: ID of the field to delete.
        """
        response = self._session.delete(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/fields/{field_id}"
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def get_profile_type(self, profile_type_id: str) -> dict:
        """
        Get a profile type.

        Args:
            profile_type_id: ID of the profile type to get.
        """
        response = self._session.get(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}"
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def add_document_type(
        self,
        profile_type_id: str,
        document_type_name: str,
        document_type_description: str,
        document_type_fields: list[dict],
    ) -> dict:
        """
        Add a document type to a profile type.

        Args:
            profile_type_id: ID of the profile type to add the document type to.
            document_type_name: Name of the document type to add.
            document_type_description: Description of the document type to add.
            document_type_fields: Fields of the document type to add in the next format:
            {
                "field_id": "string", # ID of the corresponding profile type field
                "description": "string",
            }
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/document-types",
            json={
                "name": document_type_name,
                "description": document_type_description,
                "fields": document_type_fields,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def update_document_type(
        self,
        profile_type_id: str,
        document_type_id: str,
        document_type_name: str,
        document_type_description: str,
        document_type_fields: list[dict],
    ) -> dict:
        """
        Update a document type in a profile type.

        Args:
            profile_type_id: ID of the profile type to update the document type in.
            document_type_id: ID of the document type to update.
            document_type_name: New name of the document type.
            document_type_description: New description of the document type.
            document_type_fields: New fields of the document type to update in the next format:
            {
                "field_id": "string", # ID of the corresponding profile type field
                "description": "string",
            }
        """
        response = self._session.put(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/document-types/{document_type_id}",
            json={
                "name": document_type_name,
                "description": document_type_description,
                "fields": document_type_fields,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def delete_document_type(self, profile_type_id: str, document_type_id: str) -> dict:
        """
        Delete a document type.

        Args:
            profile_type_id: ID of the profile type to delete the document type from.
            document_type_id: ID of the document type to delete.
        """
        response = self._session.delete(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/document-types/{document_type_id}"
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def add_document_type_validation_rule(
        self, profile_type_id: str, document_type_id: str, validation_rule: dict
    ) -> dict:
        """
        Add a validation rule to a document type.

        Args:
            profile_type_id: ID of the profile type to add the validation rule to.
            document_type_id: ID of the document type to add the validation rule to.
            validation_rule: Validation rule to add in the next format:
            {
                "name": "string",
                "code": "string",
                "field_ids": [
                    "string"
                ],
                "description": "string"
            }
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/document-types/{document_type_id}/validation-rules",
            json=validation_rule,
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def update_document_type_validation_rule(
        self,
        profile_type_id: str,
        document_type_id: str,
        validation_rule_id: str,
        validation_rule: dict,
    ) -> dict:
        """
        Update a validation rule in a document type.

        Args:
            profile_type_id: ID of the profile type to update the validation rule in.
            document_type_id: ID of the document type to update the validation rule in.
            validation_rule_id: ID of the validation rule to update.
            validation_rule: Validation rule to update in the next format:
            {
                "name": "string",
                "code": "string",
                "field_ids": [
                    "string"
                ],
                "description": "string"
            }
        """
        response = self._session.put(
            (
                f"{self._base_url}/v1/profiles-types/{profile_type_id}/document-types/"
                + f"{document_type_id}/validation-rules/{validation_rule_id}"
            ),
            json=validation_rule,
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def delete_document_type_validation_rule(
        self, profile_type_id: str, document_type_id: str, validation_rule_id: str
    ) -> dict:
        """
        Delete a validation rule from a document type.

        Args:
            profile_type_id: ID of the profile type to delete the validation rule from.
            document_type_id: ID of the document type to delete the validation rule from.
            validation_rule_id: ID of the validation rule to delete.
        """
        response = self._session.delete(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/document-types/{document_type_id}/"
            f"validation-rules/{validation_rule_id}",
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def add_reconciliation_rule(
        self, profile_type_id: str, reconciliation_rule: dict
    ) -> dict:
        """
        Add a reconciliation rule to a profile type.

        Args:
            profile_type_id: ID of the profile type to add the reconciliation rule to.
            reconciliation_rule: Reconciliation rule to add in the next format:
            {
                "name": "string",
                "description": "string"
            }
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/reconciliation-rules",
            json=reconciliation_rule,
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def update_reconciliation_rule(
        self,
        profile_type_id: str,
        reconciliation_rule_id: str,
        reconciliation_rule: dict,
    ) -> dict:
        """
        Update a reconciliation rule in a profile type.

        Args:
            profile_type_id: ID of the profile type to update the reconciliation rule in.
            reconciliation_rule_id: ID of the reconciliation rule to update.
            reconciliation_rule: Reconciliation rule to update in the next format:
            {
                "name": "string",
                "description": "string"
            }
        """
        response = self._session.put(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/reconciliation-rules/{reconciliation_rule_id}",
            json=reconciliation_rule,
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def delete_reconciliation_rule(
        self, profile_type_id: str, reconciliation_rule_id: str
    ) -> dict:
        """
        Delete a reconciliation rule from a profile type.

        Args:
            profile_type_id: ID of the profile type to delete the reconciliation rule from.
            reconciliation_rule_id: ID of the reconciliation rule to delete.
        """
        response = self._session.delete(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/reconciliation-rules/{reconciliation_rule_id}"
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def add_validation_rule(self, profile_type_id: str, validation_rule: dict) -> dict:
        """
        Add a validation rule to a profile type.

        Args:
            profile_type_id: ID of the profile type to add the validation rule to.
            validation_rule: Validation rule to add in the next format:
            {
                "name": "string",
                "code": "string",
                "field_ids": [
                    "string"
                ],
                "description": "string"
            }
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/validation-rules",
            json=validation_rule,
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def update_validation_rule(
        self, profile_type_id: str, validation_rule_id: str, validation_rule: dict
    ) -> dict:
        """
        Update a validation rule in a profile type.

        Args:
            profile_type_id: ID of the profile type to update the validation rule in.
            validation_rule_id: ID of the validation rule to update.
            validation_rule: Validation rule to update in the next format:
            {
                "name": "string",
                "code": "string",
                "field_ids": [
                    "string"
                ],
                "description": "string"
            }
        """
        response = self._session.put(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/validation-rules/{validation_rule_id}",
            json=validation_rule,
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def delete_validation_rule(
        self, profile_type_id: str, validation_rule_id: str
    ) -> dict:
        """
        Delete a validation rule from a profile type.

        Args:
            profile_type_id: ID of the profile type to delete the validation rule from.
            validation_rule_id: ID of the validation rule to delete.
        """
        response = self._session.delete(
            f"{self._base_url}/v1/profiles-types/{profile_type_id}/validation-rules/{validation_rule_id}"
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def get_profile_audit(self, profile_id: str, include_queries: bool = False) -> dict:
        """
        Get the audit of a profile.

        Args:
            profile_id: ID of the profile to get the audit of.
            include_queries: Whether to include queries in the audit.
        """
        response = self._session.get(
            f"{self._base_url}/v1/profiles/{profile_id}/audit",
            params={
                "includeQueries": include_queries,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def submit_profile(self, profile_id: str) -> dict:
        """
        Submit a profile.
        The profile should be in `processed` status.

        Args:
            profile_id: ID of the profile to submit.
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles/{profile_id}/submit"
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def escalate_profile(self, profile_id: str, note: str) -> dict:
        """
        Escalate a profile.
        The profile should be in `not_reconciled` status.

        Args:
            profile_id: ID of the profile to escalate.
            note: Note to add to the escalation.
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles/{profile_id}/escalate",
            json={
                "note": note,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def approve_profile_escalation(self, profile_id: str, note: str) -> dict:
        """
        Approve a profile escalation.
        The profile should be in `escalated` status.

        Args:
            profile_id: ID of the profile to approve the escalation of.
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles/{profile_id}/approve-escalation",
            json={
                "note": note,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def reject_profile_escalation(self, profile_id: str, note: str) -> dict:
        """
        Reject a profile escalation.
        The profile should be in `escalated` status.

        Args:
            profile_id: ID of the profile to reject the escalation of.
            note: Note to add to the rejection.
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles/{profile_id}/reject-escalation",
            json={
                "note": note,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()
