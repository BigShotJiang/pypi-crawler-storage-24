from pydantic_settings import BaseSettings, SettingsConfigDict

from .auth import DEFAULT_AUTH_SCOPE, AuthSettings

__all__ = ["DepsKYCSettings", "DEFAULT_FILES_API_PREFIX", "DEFAULT_PROFILES_API_PREFIX"]


DEFAULT_FILES_API_PREFIX: str = "api/files"
DEFAULT_PROFILES_API_PREFIX: str = "api/profiles"
DEFAULT_DOCUMENTS_API_PREFIX: str = "api/documents"
DEFAULT_CLIENTS_API_PREFIX: str = "api/clients"


class DepsKYCSettings(BaseSettings):
    url: str
    aws_client_id: str
    aws_client_secret: str
    aws_region: str
    aws_cognito_domain: str
    aws_auth_scope: str = DEFAULT_AUTH_SCOPE
    files_api_prefix: str = DEFAULT_FILES_API_PREFIX
    profiles_api_prefix: str = DEFAULT_PROFILES_API_PREFIX
    documents_api_prefix: str = DEFAULT_DOCUMENTS_API_PREFIX
    clients_api_prefix: str = DEFAULT_CLIENTS_API_PREFIX

    model_config = SettingsConfigDict(env_prefix="DEPS_KYC_")

    @property
    def files_base_url(self) -> str:
        return f"{self.url}/{self.files_api_prefix}"

    @property
    def profiles_base_url(self) -> str:
        return f"{self.url}/{self.profiles_api_prefix}"

    @property
    def documents_base_url(self) -> str:
        return f"{self.url}/{self.documents_api_prefix}"

    @property
    def clients_base_url(self) -> str:
        return f"{self.url}/{self.clients_api_prefix}"

    @property
    def auth_settings(self) -> AuthSettings:
        return AuthSettings(
            aws_client_id=self.aws_client_id,
            aws_client_secret=self.aws_client_secret,
            aws_region=self.aws_region,
            aws_cognito_domain=self.aws_cognito_domain,
            aws_auth_scope=self.aws_auth_scope,
        )
