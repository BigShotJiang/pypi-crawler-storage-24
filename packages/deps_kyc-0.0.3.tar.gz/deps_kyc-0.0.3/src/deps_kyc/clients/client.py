from ..shared import BaseDepsKYCClient, DepsKYCException

__all__ = ["ClientsClient"]


class ClientsClient(BaseDepsKYCClient):
    def __init__(self, base_url: str, access_token: str) -> None:
        super().__init__(base_url, access_token)

    def get_profile(self, profile_id: str, include: list[str] | None = None) -> dict:
        """
        Get a profile.

        Args:
            profile_id: ID of the profile to get.
            include: Entities to include (`subjects`, `individuals`, `legal_entities`).
        """
        response = self._session.get(
            f"{self._base_url}/v1/profiles/{profile_id}",
            params={
                "include": include,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()
