from ..shared import BaseDepsKYCClient, DepsKYCException

__all__ = ["FilesClient"]


class FilesClient(BaseDepsKYCClient):
    def __init__(self, base_url: str, access_token: str) -> None:
        super().__init__(base_url, access_token)

    def upload_file(self, profile_id: str, file_name: str, file_content: bytes) -> dict:
        """
        Upload a file to a profile.

        Args:
            profile_id: ID of the profile to upload the file to.
            file_name: Name of the file to upload.
            file_content: Content of the file to upload.
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles/{profile_id}/files",
            files={"file": (file_name, file_content)},
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def get_files(
        self,
        profile_id: str,
        statuses: list[str] | None = None,
        name: str | None = None,
        page: int = 0,
        per_page: int = 10,
    ) -> dict:
        """
        Get files of a profile.

        Args:
            profile_id: ID of the profile to get files of.
            statuses: Statuses to filter by (
                `new`,
                `prepared`,
                `retrieved`,
                `classified`,
                `not_classified`,
                `failed`,
                `skipped`,
                `redacted`,
            ).
            name: Name to filter by.
            page: The page number to get (0-indexed).
            per_page: The number of files per page.
        """
        response = self._session.get(
            f"{self._base_url}/v1/files",
            params={  # type: ignore[arg-type]
                "profileId": profile_id,
                "status": statuses,
                "name": name,
                "page": page,
                "perPage": per_page,
            },
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def retry_file(self, file_id: str) -> dict:
        """
        Retry a file.
        The file should be in `failed` status and should have retryable error.

        Args:
            file_id: ID of the file to retry.
        """
        response = self._session.post(f"{self._base_url}/v1/files/{file_id}/retry")

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def skip_file(self, file_id: str) -> dict:
        """
        Skip a file.
        The file should be in `failed` or `not_classified` status.

        Args:
            file_id: ID of the file to skip.
        """
        response = self._session.post(f"{self._base_url}/v1/files/{file_id}/skip")

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def assign_document_types(self, file_id: str, document_types: list[dict]) -> dict:
        """
        Assign document types to a file.
        The file should be in `retrieved`, `classified` or `not_classified` status.

        Args:
            file_id: ID of the file to assign document types to.
            document_types: Document types to assign.
        """
        response = self._session.post(
            f"{self._base_url}/v1/files/{file_id}/document-types",
            json={"documentTypes": document_types},
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()

    def start_pii_redaction(self, profile_id: str) -> dict:
        """
        Start PII redaction for a profile.
        All files in the profile should be in `classified`or `redacted` status.
        The profile should have at least one file in `classified` status.

        Args:
            profile_id: ID of the profile to start PII redaction for.
        """
        response = self._session.post(
            f"{self._base_url}/v1/profiles/{profile_id}/pii-redaction"
        )

        if not response.ok:
            raise DepsKYCException(response)

        return response.json()
