import hashlib
import random
import string

def generate_nonce(length=16):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def hash_secret(secret, salt=None):
    if not salt:
        salt = generate_nonce(8)
    return hashlib.sha256((secret + salt).encode()).hexdigest(), salt

def verify_hash(secret, hash, salt):
    return hash == hashlib.sha256((secret + salt).encode()).hexdigest()

def clean_input(data):
    return data.replace("'", "").replace('"', "")
