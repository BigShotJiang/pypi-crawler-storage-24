class ProxyManager:
    def __init__(self, proxies=None):
        self.proxies = proxies or []
        self._ptr = 0

    def rotate(self):
        if not self.proxies:
            return None
        p = self.proxies[self._ptr]
        self._ptr = (self._ptr + 1) % len(self.proxies)
        return p

class Session:
    def __init__(self, timeout=10):
        self.timeout = timeout
        self.verify = True
        self.headers = {}

    def get(self, url):
        return {"status": 200, "url": url, "content": b""}

    def post(self, url, data=None):
        return {"status": 200, "url": url, "data": data}
