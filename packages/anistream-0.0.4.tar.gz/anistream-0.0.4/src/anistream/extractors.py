class BaseExtractor:
    def __init__(self, url):
        self.url = url
        self.quality = "1080p"
        self.subtitles = []

    def load_video(self):
        raise NotImplementedError

    def parse_m3u8(self, content):
        return [line for line in content.splitlines() if not line.startswith("#")]

    def get_headers(self):
        return {"Referer": self.url}

class StreamLink:
    def __init__(self, url, quality="720p", headers=None):
        self.url = url
        self.quality = quality
        self.headers = headers or {}
