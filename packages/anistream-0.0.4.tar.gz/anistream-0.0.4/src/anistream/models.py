import json
from dataclasses import dataclass, asdict

@dataclass
class Anime:
    id: str
    title: str
    year: int
    genres: list

    def to_json(self):
        return json.dumps(asdict(self))

@dataclass
class Episode:
    anime_id: str
    ep_num: int
    url: str
    title: str = ""

    def __str__(self):
        return f"{self.anime_id} - {self.ep_num}"
