"""
Anusara

A deterministic execution engine built on event-sourced state,
replay integrity, and explicit lifecycle guarantees.

Public API surface.

Modules prefixed with `_` are internal and not stable.
Advanced APIs (e.g., mutation) must be imported explicitly.
"""

from importlib.metadata import version

# ---------------------------------------------------------
# Execution Contract
# ---------------------------------------------------------
from anusara.api import (
    AgentResult,
    ExecutionRequest,
    GraphDefinition,
    MeshResult,
)

# ---------------------------------------------------------
# Core
# ---------------------------------------------------------
from anusara.api.core import (
    Agent,
    AgentRegistry,
    ExecutionEngine,
    ExecutionPolicy,
    FailureMode,
    RetryPolicy,
)

# ---------------------------------------------------------
# Errors
# ---------------------------------------------------------
from anusara.api.errors import (
    ApprovalRequiredError,
    MaxHopExceededError,
    MutationComplianceError,
    SimulatedHardKillError,
)

# ---------------------------------------------------------
# Helper
# ---------------------------------------------------------
from anusara.api.helper import JSONValue, utc_now

# ---------------------------------------------------------
# Introspection
# ---------------------------------------------------------
from anusara.api.introspection import (
    ExecutionInput,
    ExecutionStatus,
    SnapshotMode,
)

# ---------------------------------------------------------
# Logging
# ---------------------------------------------------------
from anusara.api.logging import (
    ExecutionEventLog,
    FileExecutionEventLog,
    InMemoryExecutionEventLog,
)

# ---------------------------------------------------------
# Observability
# ---------------------------------------------------------
from anusara.api.observability import (
    DiagnosticsObserver,
    ExecutionDebugger,
    ExecutionGraphVisualizer,
    ExecutionObserver,
    MetricsObserver,
    OpenTelemetryObserver,
    StructuredConsoleObserver,
    TracingObserver,
)

# ---------------------------------------------------------
# Version
# ---------------------------------------------------------

__version__ = version("anusara")

__all__ = [
    # Core
    "ExecutionEngine",
    "ExecutionPolicy",
    "RetryPolicy",
    "FailureMode",
    "Agent",
    "AgentRegistry",
    # Execution Contract
    "ExecutionRequest",
    "AgentResult",
    "GraphDefinition",
    "MeshResult",
    # Introspection
    "ExecutionStatus",
    "SnapshotMode",
    "ExecutionInput",
    # Logging
    "ExecutionEventLog",
    "FileExecutionEventLog",
    "InMemoryExecutionEventLog",
    # Observability
    "ExecutionObserver",
    "StructuredConsoleObserver",
    "MetricsObserver",
    "OpenTelemetryObserver",
    "TracingObserver",
    "DiagnosticsObserver",
    "ExecutionDebugger",
    "ExecutionGraphVisualizer",
    # Errors
    "ApprovalRequiredError",
    "MutationComplianceError",
    "SimulatedHardKillError",
    "MaxHopExceededError",
    # Helper
    "utc_now",
    "JSONValue",
    # Version
    "__version__",
]
