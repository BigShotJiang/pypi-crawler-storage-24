# Security Hardening Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Wrap all ~25 operations that output external Google API content with `output_external_content()` to enable the full prompt-security-utils pipeline (markers, regex detection, semantic similarity, LLM screening).

**Architecture:** Each operation is converted from `output_success()` to `output_external_content()`. Complex data structures (lists of dicts) are serialized via `json.dumps()` into `content_fields`. Only our own metadata (counts, page tokens) remains as `**kwargs`. Two new source types (`calendar`, `contact`) are added to the allowlist routing.

**Tech Stack:** Python, prompt-security-utils >=1.2.0, pytest

**Design doc:** `docs/plans/2026-03-07-security-hardening-design.md`

---

### Task 1: Config — add `calendar` and `contact` to allowlist routing

**Files:**
- Modify: `src/gws/config.py:237-243` (`is_allowlisted` method)
- Test: `tests/test_output.py`

**Step 1: Write failing tests**

Add to `tests/test_output.py` at the end of `TestOutputExternalContent`:

```python
def test_calendar_allowlisted_skips_wrapping(self, capsys):
    """Calendar source type checks against allowlisted_documents."""
    config = Config()
    config.security_enabled = True
    config.allowlisted_documents = ["cal-event-123"]

    with patch.object(Config, "load", return_value=config), \
         patch("gws.context.get_active_account", return_value=None):
        output_external_content(
            operation="calendar.get",
            source_type="calendar",
            source_id="cal-event-123",
            content_fields={"summary": "Team meeting"},
        )

    captured = json.loads(capsys.readouterr().out)
    assert captured["summary"] == "Team meeting"

def test_contact_allowlisted_skips_wrapping(self, capsys):
    """Contact source type checks against allowlisted_documents."""
    config = Config()
    config.security_enabled = True
    config.allowlisted_documents = ["people/c999"]

    with patch.object(Config, "load", return_value=config), \
         patch("gws.context.get_active_account", return_value=None):
        output_external_content(
            operation="contacts.get",
            source_type="contact",
            source_id="people/c999",
            content_fields={"name": "Alice"},
        )

    captured = json.loads(capsys.readouterr().out)
    assert captured["name"] == "Alice"
```

**Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_output.py::TestOutputExternalContent::test_calendar_allowlisted_skips_wrapping tests/test_output.py::TestOutputExternalContent::test_contact_allowlisted_skips_wrapping -v`
Expected: FAIL — `calendar` and `contact` source types fall through to `return False` in `is_allowlisted()`

**Step 3: Implement — update `is_allowlisted()`**

In `src/gws/config.py`, change the `is_allowlisted` method (line 237-243) from:

```python
def is_allowlisted(self, source_type: str, source_id: str) -> bool:
    """Check if a source is in the allowlist."""
    if source_type in ("email", "message"):
        return source_id in self.allowlisted_emails
    elif source_type in ("document", "docs", "spreadsheet", "sheets", "slides"):
        return source_id in self.allowlisted_documents
    return False
```

to:

```python
def is_allowlisted(self, source_type: str, source_id: str) -> bool:
    """Check if a source is in the allowlist."""
    if source_type in ("email", "message"):
        return source_id in self.allowlisted_emails
    elif source_type in (
        "document", "docs", "spreadsheet", "sheets", "slides",
        "calendar", "contact",
    ):
        return source_id in self.allowlisted_documents
    return False
```

**Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_output.py -v`
Expected: ALL PASS

**Step 5: Commit**

```bash
git add src/gws/config.py tests/test_output.py
git commit -m "Security: add calendar/contact source types to allowlist routing"
```

---

### Task 2: Gmail — wrap list_messages, list_drafts, list_threads

**Files:**
- Modify: `src/gws/services/gmail.py`

**Step 1: Convert `list_messages()`**

Find the `output_success()` call in `list_messages()` and replace it. Change from:

```python
output_kwargs: dict[str, Any] = {
    "operation": "gmail.list",
    "message_count": len(messages),
    "messages": messages,
    "next_page_token": result.get("nextPageToken"),
}
if batch_errors:
    output_kwargs["failed_ids"] = batch_errors
output_success(**output_kwargs)
```

to:

```python
ext_kwargs: dict[str, Any] = {
    "message_count": len(messages),
    "next_page_token": result.get("nextPageToken"),
}
if batch_errors:
    ext_kwargs["failed_ids"] = batch_errors
output_external_content(
    operation="gmail.list",
    source_type="email",
    source_id=f"gmail.list:{query or 'all'}",
    content_fields={"messages": json.dumps(messages, default=str)},
    **ext_kwargs,
)
```

Note: `gmail.py` already imports `json` (check top of file — if not, add `import json`).

**Step 2: Convert `list_drafts()`**

Find the `output_success()` call in `list_drafts()` and replace. Change from:

```python
output_success(
    operation="gmail.list_drafts",
    draft_count=len(drafts),
    drafts=drafts,
)
```

to:

```python
output_external_content(
    operation="gmail.list_drafts",
    source_type="email",
    source_id="gmail.list_drafts",
    content_fields={"drafts": json.dumps(drafts, default=str)},
    draft_count=len(drafts),
)
```

**Step 3: Convert `list_threads()`**

Find the `output_success()` call in `list_threads()` and replace. Change from:

```python
output_success(
    operation="gmail.list_threads",
    thread_count=len(threads),
    threads=threads,
)
```

to:

```python
output_external_content(
    operation="gmail.list_threads",
    source_type="email",
    source_id=f"gmail.list_threads:{query or 'all'}",
    content_fields={"threads": json.dumps(threads, default=str)},
    thread_count=len(threads),
)
```

**Step 4: Verify imports**

Ensure `gmail.py` has `import json` at the top. Also ensure `output_external_content` is imported — check the existing imports line: it should already import it (used by `read_message`). If not, add to the import from `gws.output`.

**Step 5: Run tests**

Run: `uv run pytest -v`
Expected: ALL PASS (existing tests may need updating if they mock output_success for these methods)

**Step 6: Commit**

```bash
git add src/gws/services/gmail.py
git commit -m "Security: wrap gmail list_messages/list_drafts/list_threads with security markers"
```

---

### Task 3: Gmail — wrap get_vacation_settings, get_signature

**Files:**
- Modify: `src/gws/services/gmail.py`

**Step 1: Convert `get_vacation_settings()`**

Change from:

```python
output_success(
    operation="gmail.get_vacation_settings",
    enabled=settings.get("enableAutoReply", False),
    subject=settings.get("responseSubject", ""),
    body_plain_text=settings.get("responseBodyPlainText", ""),
    restrict_to_contacts=settings.get("restrictToContacts", False),
    restrict_to_domain=settings.get("restrictToDomain", False),
    start_time=settings.get("startTime"),
    end_time=settings.get("endTime"),
)
```

to:

```python
output_external_content(
    operation="gmail.get_vacation_settings",
    source_type="email",
    source_id="gmail.vacation_settings",
    content_fields={
        "subject": settings.get("responseSubject", ""),
        "body_plain_text": settings.get("responseBodyPlainText", ""),
    },
    enabled=settings.get("enableAutoReply", False),
    restrict_to_contacts=settings.get("restrictToContacts", False),
    restrict_to_domain=settings.get("restrictToDomain", False),
    start_time=settings.get("startTime"),
    end_time=settings.get("endTime"),
)
```

**Step 2: Convert `get_signature()`**

Change from:

```python
output_success(
    operation="gmail.get_signature",
    send_as_email=send_as_email,
    signature=result.get("signature", ""),
    display_name=result.get("displayName", ""),
    is_primary=result.get("isPrimary", False),
)
```

to:

```python
output_external_content(
    operation="gmail.get_signature",
    source_type="email",
    source_id=f"gmail.signature:{send_as_email}",
    content_fields={
        "signature": result.get("signature", ""),
        "display_name": result.get("displayName", ""),
    },
    send_as_email=send_as_email,
    is_primary=result.get("isPrimary", False),
)
```

**Step 3: Run tests**

Run: `uv run pytest -v`
Expected: ALL PASS

**Step 4: Commit**

```bash
git add src/gws/services/gmail.py
git commit -m "Security: wrap gmail vacation_settings/signature with security markers"
```

---

### Task 4: Drive — wrap list_files, search, get_metadata

**Files:**
- Modify: `src/gws/services/drive.py`

**Step 1: Verify imports**

Ensure `drive.py` imports `output_external_content` from `gws.output` and `import json`. Add if missing.

**Step 2: Convert `list_files()`**

Find the `output_success()` call and replace. The method builds a `files` list via `_file_to_dict()`. Change from:

```python
output_success(
    operation="drive.list",
    files=files,
    ...
)
```

to:

```python
output_external_content(
    operation="drive.list",
    source_type="document",
    source_id=f"drive.list:{query or 'all'}",
    content_fields={"files": json.dumps(files, default=str)},
    file_count=len(files),
    next_page_token=result.get("nextPageToken"),
)
```

Adjust kwargs to match only the non-content metadata fields currently output.

**Step 3: Convert `search()`**

Same pattern as `list_files()`. Change to:

```python
output_external_content(
    operation="drive.search",
    source_type="document",
    source_id=f"drive.search:{query}",
    content_fields={"files": json.dumps(files, default=str)},
    file_count=len(files),
    next_page_token=result.get("nextPageToken"),
)
```

**Step 4: Convert `get_metadata()`**

This returns a single file's metadata. Change to:

```python
output_external_content(
    operation="drive.get_metadata",
    source_type="document",
    source_id=f"drive.metadata:{file_id}",
    content_fields={"file": json.dumps(file_data, default=str)},
)
```

**Step 5: Run tests**

Run: `uv run pytest -v`
Expected: ALL PASS

**Step 6: Commit**

```bash
git add src/gws/services/drive.py
git commit -m "Security: wrap drive list_files/search/get_metadata with security markers"
```

---

### Task 5: Drive — wrap list_comments, list_replies, list_changes

**Files:**
- Modify: `src/gws/services/drive.py`

**Step 1: Convert `list_comments()`**

Change from `output_success()` to:

```python
output_external_content(
    operation="drive.list_comments",
    source_type="document",
    source_id=f"drive.comments:{file_id}",
    content_fields={"comments": json.dumps(comments, default=str)},
    comment_count=len(comments),
    next_page_token=result.get("nextPageToken"),
)
```

**Step 2: Convert `list_replies()`**

Change to:

```python
output_external_content(
    operation="drive.list_replies",
    source_type="document",
    source_id=f"drive.replies:{file_id}:{comment_id}",
    content_fields={"replies": json.dumps(replies, default=str)},
    reply_count=len(replies),
    next_page_token=result.get("nextPageToken"),
)
```

**Step 3: Convert `list_changes()`**

Change to:

```python
output_external_content(
    operation="drive.list_changes",
    source_type="document",
    source_id=f"drive.changes:{page_token}",
    content_fields={"changes": json.dumps(changes, default=str)},
    change_count=len(changes),
    new_start_page_token=result.get("newStartPageToken"),
)
```

**Step 4: Run tests**

Run: `uv run pytest -v`
Expected: ALL PASS

**Step 5: Commit**

```bash
git add src/gws/services/drive.py
git commit -m "Security: wrap drive comments/replies/changes with security markers"
```

---

### Task 6: Calendar — wrap all 4 operations

**Files:**
- Modify: `src/gws/services/calendar.py`

**Step 1: Verify imports**

Ensure `calendar.py` imports `output_external_content` from `gws.output` and `import json`. Add if missing.

**Step 2: Convert `list_events()`**

Change from `output_success()` to:

```python
output_external_content(
    operation="calendar.list",
    source_type="calendar",
    source_id=f"calendar.list:{calendar_id}",
    content_fields={"events": json.dumps(events, default=str)},
    event_count=len(events),
    next_page_token=result.get("nextPageToken"),
)
```

**Step 3: Convert `get_event()`**

This outputs individual fields. Change to:

```python
output_external_content(
    operation="calendar.get",
    source_type="calendar",
    source_id=f"calendar.get:{event_id}",
    content_fields={
        "summary": event.get("summary", "(no title)"),
        "location": event.get("location", ""),
        "description": event.get("description", ""),
        "attendees": json.dumps(attendees_list, default=str),
    },
    event_id=event["id"],
    calendar_id=calendar_id,
    start=start,
    end=end,
    status=event.get("status", ""),
    html_link=event.get("htmlLink", ""),
    organizer=event.get("organizer", {}).get("email", ""),
    created=event.get("created", ""),
    updated=event.get("updated", ""),
    recurrence=event.get("recurrence"),
)
```

Note: Adjust variable names to match the exact local variables in the method. Read the method body to confirm field names.

**Step 4: Convert `get_instances()`**

Change to:

```python
output_external_content(
    operation="calendar.get_instances",
    source_type="calendar",
    source_id=f"calendar.instances:{event_id}",
    content_fields={"instances": json.dumps(instances, default=str)},
    instance_count=len(instances),
)
```

**Step 5: Convert `get_attendees()`**

Change to:

```python
output_external_content(
    operation="calendar.get_attendees",
    source_type="calendar",
    source_id=f"calendar.attendees:{event_id}",
    content_fields={
        "summary": event.get("summary", ""),
        "attendees": json.dumps(attendees, default=str),
    },
    event_id=event_id,
    attendee_count=len(attendees),
)
```

**Step 6: Run tests**

Run: `uv run pytest -v`
Expected: ALL PASS

**Step 7: Commit**

```bash
git add src/gws/services/calendar.py
git commit -m "Security: wrap calendar list/get/instances/attendees with security markers"
```

---

### Task 7: Docs — wrap structure, get_suggestions, get_headers_footers

**Files:**
- Modify: `src/gws/services/docs.py`

**Step 1: Verify imports**

`docs.py` already imports `output_external_content` (used by `read()`). Ensure `import json` is present.

**Step 2: Convert `structure()`**

Change from `output_success()` to:

```python
output_external_content(
    operation="docs.structure",
    source_type="document",
    source_id=document_id,
    content_fields={"headings": json.dumps(headings, default=str)},
    document_id=document_id,
)
```

**Step 3: Convert `get_suggestions()`**

Change to:

```python
output_external_content(
    operation="docs.get_suggestions",
    source_type="document",
    source_id=document_id,
    content_fields={"suggestions": json.dumps(suggestion_list, default=str)},
    document_id=document_id,
    suggestion_count=len(suggestion_list),
)
```

Note: Verify the local variable name — it may be `suggestion_list` or `suggestions`. Read the method to confirm.

**Step 4: Convert `get_headers_footers()`**

Change to:

```python
output_external_content(
    operation="docs.get_headers_footers",
    source_type="document",
    source_id=document_id,
    content_fields={
        "headers": json.dumps(header_info, default=str),
        "footers": json.dumps(footer_info, default=str),
    },
    document_id=document_id,
)
```

Note: Verify local variable names (`header_info`/`footer_info` vs `headers`/`footers`).

**Step 5: Run tests**

Run: `uv run pytest -v`
Expected: ALL PASS

**Step 6: Commit**

```bash
git add src/gws/services/docs.py
git commit -m "Security: wrap docs structure/suggestions/headers_footers with security markers"
```

---

### Task 8: Slides — wrap get_speaker_notes

**Files:**
- Modify: `src/gws/services/slides.py`

**Step 1: Verify imports**

Ensure `slides.py` imports `output_external_content` (already used by `read()`).

**Step 2: Convert `get_speaker_notes()`**

Change from `output_success()` to:

```python
output_external_content(
    operation="slides.get_speaker_notes",
    source_type="slide",
    source_id=presentation_id,
    content_fields={"notes_text": notes_text.strip()},
    presentation_id=presentation_id,
    slide_index=slide_index,
)
```

Note: `notes_text` is already a string, no `json.dumps()` needed.

**Step 3: Run tests**

Run: `uv run pytest -v`
Expected: ALL PASS

**Step 4: Commit**

```bash
git add src/gws/services/slides.py
git commit -m "Security: wrap slides get_speaker_notes with security markers"
```

---

### Task 9: Contacts — wrap all 3 operations

**Files:**
- Modify: `src/gws/services/contacts.py`

**Step 1: Verify imports**

Add `output_external_content` to the import from `gws.output` and ensure `import json` is present. This service likely only imports `output_success` currently.

**Step 2: Convert `list_contacts()`**

Change from `output_success()` to:

```python
output_external_content(
    operation="contacts.list",
    source_type="contact",
    source_id="contacts.list",
    content_fields={"contacts": json.dumps(contacts, default=str)},
    contact_count=len(contacts),
    next_page_token=result.get("nextPageToken"),
)
```

**Step 3: Convert `get_contact()`**

This has individual fields. Change to:

```python
output_external_content(
    operation="contacts.get",
    source_type="contact",
    source_id=person.get("resourceName", resource_name),
    content_fields={
        "name": self._get_name(person),
        "emails": json.dumps([e.get("value", "") for e in person.get("emailAddresses", [])], default=str),
        "phones": json.dumps([p.get("value", "") for p in person.get("phoneNumbers", [])], default=str),
        "organization": self._get_organization(person),
        "addresses": json.dumps([a.get("formattedValue", "") for a in person.get("addresses", [])], default=str),
    },
    resource_name=person.get("resourceName", resource_name),
)
```

Note: Keep the existing data extraction logic — just move fields into `content_fields`. Verify exact variable names.

**Step 4: Convert `search_directory()`**

Change to:

```python
output_external_content(
    operation="contacts.search_directory",
    source_type="contact",
    source_id=f"contacts.directory:{query}",
    content_fields={"people": json.dumps(people, default=str)},
    people_count=len(people),
)
```

**Step 5: Run tests**

Run: `uv run pytest -v`
Expected: ALL PASS

**Step 6: Commit**

```bash
git add src/gws/services/contacts.py
git commit -m "Security: wrap contacts list/get/search_directory with security markers"
```

---

### Task 10: Final verification and cleanup

**Files:**
- All modified files

**Step 1: Run full test suite**

Run: `uv run pytest -v`
Expected: ALL PASS

**Step 2: Run type checking**

Run: `uv run mypy src/`
Expected: No new errors (pre-existing `googleapiclient` stub errors are expected)

**Step 3: Run linting**

Run: `uv run ruff check .`
Expected: No new errors

**Step 4: Verify no remaining `output_success` calls with external content**

Run: `grep -n "output_success" src/gws/services/*.py`

Review each remaining `output_success` call and confirm it only outputs:
- Write operation confirmations (send, create, update, delete)
- Admin/system metadata (labels, filters, colors, reminders, permissions)
- File download confirmations

None should output user-authored free text from Google APIs.

**Step 5: Verify all `output_external_content` calls use correct source_type**

Run: `grep -n "output_external_content" src/gws/services/*.py`

Confirm:
- Gmail operations use `source_type="email"`
- Drive operations use `source_type="document"`
- Calendar operations use `source_type="calendar"`
- Docs operations use `source_type="document"`
- Slides operations use `source_type="slide"`
- Contacts operations use `source_type="contact"`

**Step 6: Commit and prepare for review**

```bash
git add -A
git commit -m "Security: verify all external content wrapped with security markers"
```
