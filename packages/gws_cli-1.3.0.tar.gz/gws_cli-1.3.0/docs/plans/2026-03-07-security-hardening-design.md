# Security Hardening: Wrap All External Content

**Date**: 2026-03-07
**Status**: Approved

## Problem

Only 5 operations (`docs.read`, `sheets.read`, `slides.read`, `gmail.read`, `gmail.get_draft`) use `output_external_content()` with the full prompt-security-utils pipeline (session markers, regex detection, semantic similarity, optional LLM screening). ~25 other operations output user-authored content from Google APIs via raw `output_success()`, bypassing all security layers.

This means content from external senders (emails), collaborators (Drive comments, shared docs), and shared resources (calendar events) flows into Claude's context completely unwrapped — a direct prompt injection vector.

## Design Decisions

1. **Whole-response wrapping** — convert all ~25 operations from `output_success()` to `output_external_content()`. Wraps the entire response, not individual fields.
2. **All risk tiers** — HIGH, MEDIUM, and LOW risk operations all get wrapped. No exceptions. "Wrap all external content, period."
3. **Source types** — reuse existing (`email`, `document`, `spreadsheet`, `slide`); add `calendar` and `contact`.
4. **Source IDs** — synthetic descriptors for list operations (`"service.operation:key_param"`), resource IDs for singletons.
5. **Content fields** — all Google API response data goes into `content_fields`; only our own metadata (counts, page tokens) stays in `**kwargs`.

## Security Pipeline (via prompt-security-utils)

Every `output_external_content()` call triggers the full pipeline per content field:

```
output_external_content()
  -> prompt_security.output_external_content()
       -> wrap_field() [per content field]
            |-> wrap_untrusted_content()     — session-scoped markers
            |-> detect_suspicious_content()  — 40+ regex patterns (always on)
            |-> screen_content_semantic()    — embedding similarity (always on)
            '-> screen_content()             — Haiku/Ollama LLM screen (opt-in)
```

## Config Changes

### `Config.is_allowlisted()` — add new source types

Current mapping handles `email`, `document`, `docs`, `spreadsheet`, `sheets`, `slides`. Add:
- `"calendar"` → check against a new `allowlisted_calendars` list (or reuse `allowlisted_documents`)
- `"contact"` → check against a new `allowlisted_contacts` list (or reuse `allowlisted_documents`)

Decision: reuse `allowlisted_documents` for calendar and contact source IDs. These are opaque IDs and the allowlist mechanism is the same. Update `is_allowlisted()` to route `"calendar"` and `"contact"` through `allowlisted_documents`.

### `Config.READ_ONLY_OPS` — add new operations if missing

Ensure all new wrapped operations are listed in `READ_ONLY_OPS` if they are read-only.

## Per-Service Changes

### Gmail (6 operations)

| Operation | source_type | source_id | content_fields | kwargs (unwrapped) |
|-----------|-------------|-----------|----------------|-------------------|
| `list_messages` | `email` | `gmail.list:{query or 'all'}` | `messages` (JSON) | `message_count`, `next_page_token`, `failed_ids` |
| `search_messages` | `email` | delegates to `list_messages` | — | — |
| `list_drafts` | `email` | `gmail.list_drafts` | `drafts` (JSON) | `draft_count` |
| `list_threads` | `email` | `gmail.list_threads:{query or 'all'}` | `threads` (JSON) | `thread_count` |
| `get_vacation_settings` | `email` | `gmail.vacation_settings` | `subject`, `body_plain_text` | `enabled`, `restrict_to_*`, `start_time`, `end_time` |
| `get_signature` | `email` | `gmail.signature:{send_as_email}` | `signature`, `display_name` | `send_as_email`, `is_primary` |

### Drive (6 operations)

| Operation | source_type | source_id | content_fields | kwargs (unwrapped) |
|-----------|-------------|-----------|----------------|-------------------|
| `list_files` | `document` | `drive.list:{query or 'all'}` | `files` (JSON) | `file_count`, `next_page_token` |
| `search` | `document` | `drive.search:{query}` | `files` (JSON) | `file_count`, `next_page_token` |
| `get_metadata` | `document` | `drive.metadata:{file_id}` | `file` (JSON) | — |
| `list_comments` | `document` | `drive.comments:{file_id}` | `comments` (JSON) | `comment_count`, `next_page_token` |
| `list_replies` | `document` | `drive.replies:{file_id}:{comment_id}` | `replies` (JSON) | `reply_count`, `next_page_token` |
| `list_changes` | `document` | `drive.changes:{page_token}` | `changes` (JSON) | `change_count`, `new_start_page_token` |

### Calendar (4 operations)

| Operation | source_type | source_id | content_fields | kwargs (unwrapped) |
|-----------|-------------|-----------|----------------|-------------------|
| `list_events` | `calendar` | `calendar.list:{calendar_id}` | `events` (JSON) | `event_count`, `next_page_token` |
| `get_event` | `calendar` | `calendar.get:{event_id}` | `summary`, `location`, `description`, `attendees` (JSON) | `event_id`, `calendar_id`, `start`, `end`, `status`, etc. |
| `get_instances` | `calendar` | `calendar.instances:{event_id}` | `instances` (JSON) | `instance_count` |
| `get_attendees` | `calendar` | `calendar.attendees:{event_id}` | `summary`, `attendees` (JSON) | `event_id`, `attendee_count` |

### Docs (3 operations)

| Operation | source_type | source_id | content_fields | kwargs (unwrapped) |
|-----------|-------------|-----------|----------------|-------------------|
| `structure` | `document` | `{document_id}` | `headings` (JSON) | `document_id` |
| `get_suggestions` | `document` | `{document_id}` | `suggestions` (JSON) | `document_id`, `suggestion_count` |
| `get_headers_footers` | `document` | `{document_id}` | `headers` (JSON), `footers` (JSON) | `document_id` |

### Slides (1 operation)

| Operation | source_type | source_id | content_fields | kwargs (unwrapped) |
|-----------|-------------|-----------|----------------|-------------------|
| `get_speaker_notes` | `slide` | `{presentation_id}` | `notes_text` | `presentation_id`, `slide_index` |

### Contacts (3 operations)

| Operation | source_type | source_id | content_fields | kwargs (unwrapped) |
|-----------|-------------|-----------|----------------|-------------------|
| `list_contacts` | `contact` | `contacts.list` | `contacts` (JSON) | `contact_count`, `next_page_token` |
| `get_contact` | `contact` | `{resource_name}` | `name`, `emails` (JSON), `phones` (JSON), `organization`, `addresses` (JSON) | `resource_name` |
| `search_directory` | `contact` | `contacts.directory:{query}` | `people` (JSON) | `people_count` |

## Files Changed

| File | Change |
|------|--------|
| `src/gws/services/gmail.py` | Convert 5 operations (list_messages, list_drafts, list_threads, get_vacation_settings, get_signature) |
| `src/gws/services/drive.py` | Convert 6 operations (list_files, search, get_metadata, list_comments, list_replies, list_changes) |
| `src/gws/services/calendar.py` | Convert 4 operations (list_events, get_event, get_instances, get_attendees) |
| `src/gws/services/docs.py` | Convert 3 operations (structure, get_suggestions, get_headers_footers) |
| `src/gws/services/slides.py` | Convert 1 operation (get_speaker_notes) |
| `src/gws/services/contacts.py` | Convert 3 operations (list_contacts, get_contact, search_directory) |
| `src/gws/config.py` | Add `calendar`/`contact` to `is_allowlisted()` routing |
| `tests/test_output.py` | Add tests for new source types in allowlist |

## Not In Scope

- **Write operations** (send email, create doc, update event) — these send user-provided content TO Google, not FROM Google. No wrapping needed.
- **Admin/system metadata** (labels, filters, colors, reminders, permissions) — admin-controlled, not user-authored free text. Low injection risk.
- **File downloads** (drive.download, drive.export, gmail.download_attachment) — written to filesystem as binary, not output as JSON to Claude.
- **Existing wrapped operations** (docs.read, sheets.read, slides.read, gmail.read, gmail.get_draft) — already protected.
