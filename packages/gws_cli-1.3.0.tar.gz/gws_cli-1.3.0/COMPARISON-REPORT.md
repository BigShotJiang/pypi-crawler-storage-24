# Comparison: Our `gws-cli` vs Google's `gws` (googleworkspace/cli)

**Date**: 2026-03-06
**Purpose**: Gap analysis comparing our Google Workspace CLI skill against the official googleworkspace/cli project.

---

## Project Profiles

| Aspect | Our `gws-cli` | Google's `gws` |
|--------|---------------|----------------|
| **Language** | Python (Typer) | Rust (clap) |
| **Architecture** | Static, hand-crafted per-operation | Dynamic from Google Discovery Service |
| **Distribution** | pip / uv | npm / cargo / Nix |
| **AI Integration** | Claude Code skill (CLI subprocess) | 100+ agent skills (SKILL.md files) |
| **Stars** | Private | 14k |
| **Version** | 1.1.0 | 0.7.0 |

---

## What We're Doing Well

Our CLI is remarkably comprehensive for a hand-crafted tool:

- **239+ operations** across 8 services vs their dynamic discovery approach
- **Deeper API coverage** in Docs (50+ ops), Sheets (49), Slides (36) -- we have more granular operations than their helper-based approach
- **Prompt injection protection** with session-scoped security markers -- they don't have this
- **Markdown-to-Docs/Slides/PDF converter** with diagram rendering -- unique to us
- **Read-only per-account mode** -- more granular than their scope-level read-only
- **Multi-account with per-account config overrides** -- equivalent to theirs

---

## What We're Missing / Could Adopt

### 1. Services We Don't Cover (9 gaps)

| Service | Their CLI | Priority |
|---------|-----------|----------|
| **Tasks** | Full CRUD | HIGH -- natural companion to Calendar |
| **Chat** | Send messages, spaces | MEDIUM -- team communication |
| **Forms** | Full CRUD | LOW -- niche |
| **Keep** | Notes management | LOW -- niche |
| **Meet** | Meeting management | LOW |
| **Classroom** | Education API | LOW |
| **Admin Reports** | Audit logs | LOW |
| **Workspace Events** | Pub/Sub streaming | MEDIUM -- powerful for automation |
| **Model Armor** | AI safety filtering | LOW -- Google-specific |

**Tasks API** is the biggest gap. It's a lightweight API (v1) with just lists and tasks CRUD, but it unlocks powerful workflows like "email-to-task" and "standup reports" that combine Calendar + Tasks. Chat is the second priority -- team messaging is a core Workspace function.

### 2. Workflow / Recipe Commands (HIGH VALUE)

Their most innovative feature: **composite commands** that combine multiple APIs:

| Recipe | APIs Used | Value |
|--------|-----------|-------|
| `+standup-report` | Calendar + Tasks | Daily summary |
| `+meeting-prep` | Calendar + Docs | Pre-meeting brief |
| `+email-to-task` | Gmail + Tasks | Inbox to actionable |
| `+weekly-digest` | Calendar + Gmail | Weekly summary |
| `+file-announce` | Drive + Chat | Share notification |

We have nothing equivalent. These are high-value for AI agents because they reduce multi-step tool calls to one.

### 3. Output Format Flexibility

| Format | Theirs | Ours |
|--------|--------|------|
| JSON | Default | Default |
| Table | `--format table` | No |
| YAML | `--format yaml` | No |
| CSV | `--format csv` | No |
| NDJSON | For pagination | No |

For AI agent use, JSON-only is fine. But **NDJSON for pagination** is interesting -- it allows streaming large result sets line-by-line instead of buffering everything.

### 4. Schema Introspection

```bash
# Their CLI
gws schema drive.files.list  # Shows exact request/response types
```

We don't have an equivalent. An agent can't discover what parameters a method accepts without reading skill docs. A `gws-cli schema docs.insert` command could help agents self-discover.

### 5. Dry-Run Mode

```bash
gws drive files create --json '...' --dry-run
# Validates locally without calling API
```

We don't have `--dry-run`. Useful for agents to validate before executing destructive operations.

### 6. Auto-Pagination

```bash
gws drive files list --page-all --page-limit 10 --page-delay 100
```

Our commands handle pagination internally per-operation, but we don't have a **unified pagination flag** across all list operations. Some of our commands might not paginate at all.

### 7. Helper Shortcuts (Sugar Commands)

Their `+send`, `+append`, `+read`, `+upload` helpers simplify common operations:

```bash
# Their helper
gws gmail +send --to "user@example.com" --subject "Hi" --body "Hello"

# vs raw
gws gmail users messages send --params '{"userId": "me"}' --json '{"raw": "..."}'
```

Our CLI already has friendly commands (`gmail send`, `sheets append`), so this is less of a gap -- we're already at the helper level.

### 8. Persona-Based Skills (10)

Role bundles like `persona-exec-assistant`, `persona-project-manager`, `persona-sales-ops`. These are essentially curated skill combinations that tell an AI agent "when acting as an exec assistant, use these tools in these patterns."

We don't have personas, but this is a **skill-layer concern**, not a CLI concern.

### 9. 50+ Recipe Skills

Pre-built multi-step sequences:

- `recipe-label-and-archive-emails`
- `recipe-draft-email-from-doc`
- `recipe-organize-drive-folder`
- `recipe-create-expense-tracker`
- `recipe-block-focus-time`
- etc.

These are templates for common workflows. Our SKILL-advanced.md has some workflow guidance, but not discrete recipe files.

### 10. `gws auth setup` (Interactive TUI)

They have a full terminal UI (ratatui) that walks users through:

1. Creating a Google Cloud project
2. Enabling APIs
3. Creating OAuth credentials
4. First login

We rely on manual `import-credentials` + browser auth. Their setup experience is smoother.

---

## Best Practices to Adopt

### Priority 1 -- Quick Wins

1. **Add Google Tasks service** -- small API, huge workflow value
2. **Add `--dry-run` flag** to destructive operations (delete, send, share)
3. **Unified pagination** -- `--page-all` / `--max-pages` across all list commands

### Priority 2 -- Medium Effort

4. **Workflow commands** -- at minimum: standup-report, email-to-task, meeting-prep
5. **Google Chat service** -- team messaging integration
6. **Recipe skill files** -- discrete SKILL.md files for common multi-step tasks

### Priority 3 -- Nice to Have

7. **Schema/introspect command** -- `gws-cli schema <service.operation>`
8. **NDJSON streaming** for large result sets
9. **Persona skill bundles** in SKILL.md
10. **Multiple output formats** (table, CSV) -- lower priority since AI agents prefer JSON

---

## Architectural Philosophy

The key architectural difference is philosophy:

- **Their CLI is dynamic** (Discovery Service at runtime = zero maintenance when Google adds APIs)
- **Ours is static** (hand-crafted per-operation = deeper control, better error handling, richer formatting)

Both approaches have merit. Their dynamic approach means they cover ALL Google APIs automatically but with generic handling. Our static approach means we cover fewer APIs but with purpose-built operations (like our table manipulation, markdown conversion, security wrapping).

**Recommendation**: Keep our static approach for the core services but add workflow commands that combine them.

---

## Summary Table

| Category | Status | Action Needed |
|----------|--------|---------------|
| Core services (8) | Excellent | Keep |
| Operation depth | Better than theirs | Keep |
| Security (prompt injection) | Unique advantage | Keep |
| Converter (md to docs/slides/pdf) | Unique advantage | Keep |
| Multi-account | Equivalent | Keep |
| Encryption at rest | Equivalent | Keep |
| Tasks API | Missing | **Add** |
| Chat API | Missing | **Add** |
| Workflow commands | Missing | **Add** |
| Dry-run mode | Missing | **Add** |
| Unified pagination | Inconsistent | **Standardize** |
| Recipe skills | Missing | **Add skill files** |
| Schema introspection | Missing | Consider |
| Output formats | JSON only | Low priority |

---

## Their Repo Details

- **Repository**: https://github.com/googleworkspace/cli
- **Language**: Rust
- **License**: Apache 2.0
- **Author**: Justin Poehnelt
- **Key innovation**: Uses Google Discovery Service at runtime to dynamically generate the entire CLI command surface
- **Services**: 17 (Drive, Gmail, Sheets, Calendar, Docs, Slides, Tasks, People, Chat, Classroom, Forms, Keep, Meet, Admin Reports, Workspace Events, Model Armor, Workflow)
- **Skills**: 100+ auto-generated (18 service skills, 16 helper skills, 10 persona skills, 50+ recipe skills)
- **Note**: They removed MCP support in v0.7.0, going CLI-first
