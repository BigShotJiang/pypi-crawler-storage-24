"""Audio and Video Transcription

This module provides audio/video transcription with optional transcript error fixing.

Main Classes:
    - Transcriber: High-level transcription API with chunking and optional transcript error fixing
    - TranscriptionResult: Container for raw and corrected transcripts

Configuration:
    - get_openai_config: Get OpenAI/Azure configuration for transcription
    - create_openai_client: Create OpenAI client from config

Utilities:
    - split_and_transcribe: Chunk and transcribe long audio files
    - split_and_transcribe_with_context: Transcribe with context awareness
    - DEFAULT_PROMPT: Default transcription prompt for Whisper

Example:
    >>> from gaik.software_components.transcriber import Transcriber, get_openai_config
    >>> config = get_openai_config(use_azure=True)
    >>> transcriber = Transcriber(config)
    >>> result = transcriber.transcribe("audio.mp3")
    >>> result.save("output/")
"""

__all__ = []

# Configuration (requires openai, python-dotenv)
try:
    from gaik.software_components.config import (
        create_openai_client,
        get_openai_config,
    )

    __all__.extend(["get_openai_config", "create_openai_client"])
except ImportError:
    pass

# Transcription (requires openai, pydub)
try:
    from .transcriber import (
        DEFAULT_PROMPT,
        Transcriber,
        TranscriptionResult,
        split_and_transcribe,
        split_and_transcribe_with_context,
    )

    __all__.extend(
        [
            "Transcriber",
            "TranscriptionResult",
            "split_and_transcribe",
            "split_and_transcribe_with_context",
            "DEFAULT_PROMPT",
        ]
    )
except ImportError:
    pass

# SRT/VTT subtitle utilities (no extra dependencies)
from .srt_utils import (
    chunk_segments,
    parse_srt,
    segments_to_srt,
    segments_to_vtt,
)
from .srt_utils import format_timestamp as format_timestamp_display

__all__.extend(
    [
        "segments_to_srt",
        "segments_to_vtt",
        "parse_srt",
        "chunk_segments",
        "format_timestamp_display",
    ]
)
