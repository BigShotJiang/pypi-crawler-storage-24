from setuptools import setup

setup(
    name='EqualVoteBox',
    version='1.0.0',
    author='Aksheita Ruchir Dholakia',
    author_email='aksheitadholakia@gmail.com', 
    description='A medical transparency library for revealing internal split votes in Random Forest models',
    long_description=open('README.md', encoding='utf-8').read(), # Added encoding for safety
    long_description_content_type='text/markdown',
    url='https://github.com/Aksh13673/EqualVoteBox',
    py_modules=['evb_lib'],
    install_requires=[
        'pandas',
        'numpy',
        'scikit-learn',
        'shap'
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
