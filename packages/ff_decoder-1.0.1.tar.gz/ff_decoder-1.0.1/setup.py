from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ff-decoder",
    version="1.0.1",
    author="UNKNOWN666",
    author_email="arbasbilal25@gmail.com",
    description="Decode Free Fire encrypted payloads (hex/base64) with automatic decryption and expansion.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "pycryptodome>=3.15.0",
    ],
    entry_points={
        "console_scripts": [
            "ff-decode=ff_decoder.cli:main",
        ]
    },
)