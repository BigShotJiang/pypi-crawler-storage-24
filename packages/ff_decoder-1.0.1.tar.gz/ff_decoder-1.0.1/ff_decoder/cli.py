#!/usr/bin/env python3
"""
Free Fire payload decoder – command line interface.
"""

import sys
import argparse
from .decoder import decode_payload, format_messages

def main():
    parser = argparse.ArgumentParser(description="Decode Free Fire encrypted payloads.")
    parser.add_argument("file", nargs="?", help="Path to a file containing the payload")
    parser.add_argument("--json", action="store_true", help="Output as JSON (not yet implemented, but reserved)")
    parser.add_argument("--no-decrypt", action="store_true", help="Do not attempt outer decryption (use raw data)")
    args = parser.parse_args()

    # Determine input source
    if args.file:
        # Read from file
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                raw_input = f.read().strip()
        except Exception as e:
            print(f"Error reading file: {e}", file=sys.stderr)
            sys.exit(1)
    elif not sys.stdin.isatty():
        # There is piped input (stdin is not a terminal)
        raw_input = sys.stdin.read().strip()
        if not raw_input:
            print("No input provided via pipe.", file=sys.stderr)
            sys.exit(1)
    else:
        # Interactive mode: prompt user
        raw_input = input("Paste hex or base64 payload: ").strip()
        if not raw_input:
            print("No input provided.", file=sys.stderr)
            sys.exit(1)

    try:
        messages = decode_payload(raw_input)
        if not messages:
            print("No valid messages decoded.")
        else:
            output = format_messages(messages)
            print(output)
    except Exception as e:
        print(f"Decoding failed: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()