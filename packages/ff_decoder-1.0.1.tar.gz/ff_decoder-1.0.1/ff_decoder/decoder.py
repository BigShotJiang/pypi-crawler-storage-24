"""
Free Fire payload decoder – core module.
"""

import binascii
import base64
import re
import zlib
import gzip
from io import BytesIO
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad, pad

# ==================== FIXED KEY AND IV ====================
KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
IV  = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

# ==================== VARINT HELPERS ====================
def decode_varint(data, offset):
    value = 0
    shift = 0
    while True:
        if offset >= len(data):
            raise ValueError("Truncated varint")
        b = data[offset]
        value |= (b & 0x7F) << shift
        offset += 1
        if not (b & 0x80):
            break
        shift += 7
    return value, offset

# ==================== CUSTOM ID DECRYPTION ====================
dec = ['80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '8a', '8b', '8c', '8d', '8e', '8f',
       '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '9a', '9b', '9c', '9d', '9e', '9f',
       'a0', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'a8', 'a9', 'aa', 'ab', 'ac', 'ad', 'ae', 'af',
       'b0', 'b1', 'b2', 'b3', 'b4', 'b5', 'b6', 'b7', 'b8', 'b9', 'ba', 'bb', 'bc', 'bd', 'be', 'bf',
       'c0', 'c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8', 'c9', 'ca', 'cb', 'cc', 'cd', 'ce', 'cf',
       'd0', 'd1', 'd2', 'd3', 'd4', 'd5', 'd6', 'd7', 'd8', 'd9', 'da', 'db', 'dc', 'dd', 'de', 'df',
       'e0', 'e1', 'e2', 'e3', 'e4', 'e5', 'e6', 'e7', 'e8', 'e9', 'ea', 'eb', 'ec', 'ed', 'ee', 'ef',
       'f0', 'f1', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8', 'f9', 'fa', 'fb', 'fc', 'fd', 'fe', 'ff']

x_list = ['1','01', '02', '03', '04', '05', '06', '07', '08', '09', '0a', '0b', '0c', '0d', '0e', '0f',
          '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '1a', '1b', '1c', '1d', '1e', '1f',
          '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '2a', '2b', '2c', '2d', '2e', '2f',
          '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '3a', '3b', '3c', '3d', '3e', '3f',
          '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '4a', '4b', '4c', '4d', '4e', '4f',
          '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '5a', '5b', '5c', '5d', '5e', '5f',
          '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '6a', '6b', '6c', '6d', '6e', '6f',
          '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '7a', '7b', '7c', '7d', '7e', '7f']

def decrypt_id(da):
    """Decrypt custom ID format (6‑byte hex string like '30c1fab8b103')"""
    if da is not None and len(da) == 10:
        w = 128
        xxx = len(da)/2 - 1
        xxx = str(xxx)[:1]
        for i in range(int(xxx)-1):
            w = w * 128
        x1 = da[:2]
        x2 = da[2:4]
        x3 = da[4:6]
        x4 = da[6:8]
        x5 = da[8:10]
        return str(w * x_list.index(x5) + (dec.index(x2) * 128) + dec.index(x1) + (dec.index(x3) * 128 * 128) + (dec.index(x4) * 128 * 128 * 128))
    if da is not None and len(da) == 8:
        w = 128
        xxx = len(da)/2 - 1
        xxx = str(xxx)[:1]
        for i in range(int(xxx)-1):
            w = w * 128
        x1 = da[:2]
        x2 = da[2:4]
        x3 = da[4:6]
        x4 = da[6:8]
        return str(w * x_list.index(x4) + (dec.index(x2) * 128) + dec.index(x1) + (dec.index(x3) * 128 * 128))
    return None

# ==================== DECRYPTION / DECOMPRESSION HELPERS ====================
def decrypt_aes_cbc(data, key=KEY, iv=IV):
    """Try to decrypt AES‑CBC; fallback to no‑padding if unpadding fails."""
    cipher = AES.new(key, AES.MODE_CBC, iv)
    try:
        # Try with padding
        return unpad(cipher.decrypt(data), AES.block_size)
    except ValueError:
        # If padding fails, assume raw decrypted data is correct
        return cipher.decrypt(data)

def try_zlib(data):
    """Try to decompress as zlib. Return (decompressed, True) on success."""
    try:
        return zlib.decompress(data), True
    except:
        return data, False

def try_gzip(data):
    """Try to decompress as gzip. Return (decompressed, True) on success."""
    try:
        with gzip.GzipFile(fileobj=BytesIO(data)) as gz:
            return gz.read(), True
    except:
        return data, False

# ==================== RECURSIVE PROTOBUF PARSER (SINGLE MESSAGE) ====================
def parse_one_message(data, start, depth=0, parent_path=""):
    """
    Parse exactly one protobuf message starting at 'start'.
    Returns (fields, next_offset). fields is a list of field dicts.
    """
    fields = []
    idx = start
    while idx < len(data):
        try:
            key, idx = decode_varint(data, idx)
        except ValueError:
            # Not enough bytes for a varint – we've reached the end of this message
            break
        field_num = key >> 3
        wire_type = key & 0x07
        path = f"{parent_path}.{field_num}" if parent_path else f"Field {field_num}"

        if wire_type == 0:          # varint
            value, idx = decode_varint(data, idx)
            fields.append({
                'num': field_num,
                'type': 0,
                'value': value,
                'display': f"varint {value}",
                'path': path,
                'nested': None
            })
        elif wire_type == 1:        # 64-bit
            if idx + 8 > len(data):
                raise ValueError("Truncated 64-bit")
            value = int.from_bytes(data[idx:idx+8], 'little')
            idx += 8
            fields.append({
                'num': field_num,
                'type': 1,
                'value': value,
                'display': f"64-bit {value}",
                'path': path,
                'nested': None
            })
        elif wire_type == 2:        # length-delimited
            length, idx = decode_varint(data, idx)
            if idx + length > len(data):
                # This length would exceed remaining data – stop here (incomplete message)
                return fields, idx
            raw = data[idx:idx+length]
            idx += length

            display = f"bytes ({len(raw)} bytes : {raw})"
            nested = None
            processed_raw = raw

            # --- Automatic decoding attempts ---
            # 1) Custom ID (0x30 + 5 bytes)
            if len(raw) == 6 and raw[0] == 0x30:
                id_hex = raw[1:].hex()
                decrypted_id = decrypt_id(id_hex)
                if decrypted_id:
                    display = f"custom ID -> {decrypted_id}"

            # 2) Zlib decompression
            decompressed, ok = try_zlib(raw)
            if ok and decompressed != raw:
                processed_raw = decompressed
                display = f"zlib decompressed ({len(decompressed)} bytes)"
                # Try to parse as protobuf
                try:
                    nested, _ = parse_one_message(decompressed, 0, depth+1, path)
                    if nested:
                        display += f" → protobuf ({len(nested)} fields)"
                except Exception:
                    pass

            # 3) Gzip decompression (only if not already handled)
            if nested is None and not ok:   # only try if previous attempts didn't succeed
                decompressed, ok = try_gzip(raw)
                if ok and decompressed != raw:
                    processed_raw = decompressed
                    display = f"gzip decompressed ({len(decompressed)} bytes)"
                    try:
                        nested, _ = parse_one_message(decompressed, 0, depth+1, path)
                        if nested:
                            display += f" → protobuf ({len(nested)} fields)"
                    except Exception:
                        pass

            # 4) AES decryption (if length multiple of 16)
            if nested is None and len(raw) % 16 == 0 and len(raw) > 0:
                try:
                    decrypted = decrypt_aes_cbc(raw)
                    if decrypted != raw:
                        processed_raw = decrypted
                        display = f"AES decrypted ({len(decrypted)} bytes)"
                        # Try to parse as protobuf
                        try:
                            nested, _ = parse_one_message(decrypted, 0, depth+1, path)
                            if nested:
                                display += f" → protobuf ({len(nested)} fields)"
                        except Exception:
                            pass
                except Exception:
                    pass

            # 5) Try parsing raw (or decompressed/decrypted) as protobuf directly
            if nested is None:
                try:
                    nested, _ = parse_one_message(processed_raw, 0, depth+1, path)
                    if nested:
                        display = f"protobuf ({len(nested)} fields)"
                except Exception:
                    pass

            # 6) Try UTF-8 string
            if nested is None:
                try:
                    s = processed_raw.decode('utf-8')
                    if all(32 <= ord(c) < 127 or c in '\n\r\t' for c in s):
                        display = f"string '{s}'"
                except UnicodeDecodeError:
                    pass

            # 7) For very short bytes, try to interpret as integer
            if nested is None:
                if len(processed_raw) == 4:
                    val = int.from_bytes(processed_raw, 'little')
                    display = f"uint32 {val} (bytes: {processed_raw.hex()})"
                elif len(processed_raw) == 8:
                    val = int.from_bytes(processed_raw, 'little')
                    display = f"uint64 {val} (bytes: {processed_raw.hex()})"

            fields.append({
                'num': field_num,
                'type': 2,
                'value': processed_raw,
                'display': display,
                'path': path,
                'nested': nested
            })
        elif wire_type == 5:        # 32-bit
            if idx + 4 > len(data):
                raise ValueError("Truncated 32-bit")
            value = int.from_bytes(data[idx:idx+4], 'little')
            idx += 4
            fields.append({
                'num': field_num,
                'type': 5,
                'value': value,
                'display': f"32-bit {value}",
                'path': path,
                'nested': None
            })
        else:
            raise ValueError(f"Unsupported wire type {wire_type}")
    return fields, idx

def decode_payload(data):
    """
    Decode a payload (hex string, base64 string, or bytes) and return a list of messages.
    Each message is a list of field dicts.
    """
    if isinstance(data, str):
        # Try hex first
        hex_chars = re.sub(r'[^0-9a-fA-F]', '', data)
        if len(hex_chars) % 2 == 0 and len(hex_chars) > 0:
            try:
                data_bytes = binascii.unhexlify(hex_chars)
                used_format = "hex"
            except binascii.Error:
                data_bytes = None
        else:
            data_bytes = None

        if data_bytes is None:
            b64_chars = re.sub(r'[^A-Za-z0-9+/=]', '', data)
            if len(b64_chars) > 0:
                try:
                    data_bytes = base64.b64decode(b64_chars)
                    used_format = "base64"
                except binascii.Error:
                    data_bytes = None
        if data_bytes is None:
            raise ValueError("Could not decode input as hex or base64")
    else:
        # Assume bytes
        data_bytes = data

    # Try outer AES decryption
    try:
        plain = decrypt_aes_cbc(data_bytes)
    except Exception:
        plain = data_bytes

    # Parse all messages
    messages = []
    pos = 0
    while pos < len(plain):
        try:
            fields, pos = parse_one_message(plain, pos)
            if not fields:
                break
            messages.append(fields)
        except Exception:
            break
    return messages

def format_messages(messages):
    """Return a string representation of messages."""
    import sys
    out_lines = []
    for i, msg in enumerate(messages, start=1):
        out_lines.append(f"\n--- Message {i} ---")
        out_lines.extend(_format_fields(msg))
    return "\n".join(out_lines)

def _format_fields(fields, indent=""):
    lines = []
    for f in fields:
        lines.append(f"{indent}{f['path']} : {f['display']}")
        if f['nested']:
            lines.extend(_format_fields(f['nested'], indent + "  "))
    return lines