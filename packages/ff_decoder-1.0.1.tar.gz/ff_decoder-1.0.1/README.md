# FF Decoder

A Python library and command-line tool to decode encrypted Free Fire payloads (hex or base64). It automatically decrypts the outer AES layer, decompresses zlib/gzip, and recursively expands nested protobufs.

## Installation

```bash
pip install ff-decoder