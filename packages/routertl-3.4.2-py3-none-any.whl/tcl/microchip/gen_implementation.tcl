# MIT License
# Copyright (c) 2020-2026 Daniel J. Mazure
# Description: Microchip Libero SoC Implementation Script

if { $::argc > 0 } {
 set g_root_dir [lindex $argv 0]
}

set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

open_project -file "${g_project_dir}/${g_project_name}.prjx"

# Source per-stage TCL hooks (from tcl_hooks.implementation in project.yml)
if {[info exists g_implementation_hooks]} {
    foreach hook $g_implementation_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing implementation hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: implementation hook not found: $hook_path"
        }
    }
}

puts "================================================="
puts " Running Libero SoC Place and Route"
puts "================================================="

run_tool -name {PLACEROUTE}

puts "Place and route completed successfully."
save_project
close_project
