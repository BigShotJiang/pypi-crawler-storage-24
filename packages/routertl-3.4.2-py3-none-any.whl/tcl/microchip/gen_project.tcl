# MIT License
# Copyright (c) 2020-2026 Daniel J. Mazure
# Description: Generates a Microchip Libero SoC project from the command line

if { $::argc >= 2} {
    set g_root_dir [lindex $argv 0]
    set syn_files  [lindex $argv 1]
    set xci_files  [lindex $argv 2]
    set sim_files  [lindex $argv 3]
    set tcl_files  [lindex $argv 4]
    set xdc_files  [lindex $argv 5]
    set netlist_files [lindex $argv 6]
    puts "Root dir is $g_root_dir"
} else {
    puts "Error: Not enough arguments \($::argc\), exiting ..."
    exit
}

set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

puts "================================================="
puts " Creating Libero SoC Project: $g_project_name"
puts "================================================="

# Use resolved part values from environment.tcl
set family $g_mc_family
set die $g_mc_die
set package $g_mc_package

catch {
    new_project -location $g_project_dir -name $g_project_name \
                -family $family -die $die -package $package \
                -speed {-1} -die_voltage {1.0} -part_range {IND} -hdl {VHDL}
} err
if {$err != ""} {
    puts "Project creation may have failed or project already exists. Attempting to open..."
    catch { open_project -file "${g_project_dir}/${g_project_name}.prjx" }
}

foreach src_file $syn_files {
    puts "Importing source: $src_file"
    import_files -hdl_source "${g_root_dir}/${src_file}"
}

foreach sdc_file $xdc_files {
    puts "Importing constraint: $sdc_file"
    import_files -sdc "${g_root_dir}/${sdc_file}"
}

# Pre-compiled netlists (.edf/.edif EDIF, .pdc physical constraints, .cmp component)
if {[info exists netlist_files]} {
    foreach f $netlist_files {
        if {[string trim $f] eq ""} { continue }
        if {[file pathtype $f] eq "absolute"} {
            set abs_f $f
        } else {
            set abs_f [file normalize $g_root_dir/$f]
        }
        set ext [string tolower [file extension $f]]
        if {$ext eq ".edf" || $ext eq ".edif"} {
            import_files -hdl_source $abs_f
            puts "Info: Imported EDIF netlist '$abs_f'"
        } elseif {$ext eq ".pdc"} {
            import_files -io_pdc $abs_f
            puts "Info: Imported PDC constraints '$abs_f'"
        } elseif {$ext eq ".cmp"} {
            import_files -component $abs_f
            puts "Info: Imported component '$abs_f'"
        } elseif {$ext eq ".vhd" || $ext eq ".vhdl" || $ext eq ".sv" || $ext eq ".v"} {
            import_files -hdl_source $abs_f
        } else {
            puts "Warning: Unknown netlist extension '$ext' for $f — skipping"
        }
    }
}

# Libero must analyze sources before set_root can find entities
catch { build_design_hierarchy }
catch { set_root -module $g_top_mod }

if {[info exists g_gen_project_hooks]} {
    foreach hook_script $g_gen_project_hooks {
        set full_path "${g_root_dir}/${hook_script}"
        if {[file exists $full_path]} {
            puts "INFO: Sourcing gen_project hook: $hook_script"
            source $full_path
        } else {
            puts "WARNING: gen_project hook not found: $full_path"
        }
    }
}

foreach tcl_file $tcl_files {
    source ${g_root_dir}/$tcl_file
}

save_project
