# Xilinx Build Automation & IP Scripts

This directory contains the core Tcl infrastructure for automating Xilinx Vivado builds, Non-Project Mode (NPM) synthesis, and IP generation within the RouteRTL SDK. These scripts abstract the Vivado toolchain to provide a unified, predictable build experience regardless of the host environment.

## 🏗️ Core Build Scripts

- **`gen_project.tcl`**: Creates the Vivado project, configures IP paths, and registers source files automatically.
- **`gen_synthesis.tcl`**: Configures and executes the Vivado synthesis step, including reporting area and utilization.
- **`gen_implementation.tcl`**: Runs the full Vivado implementation flow (Place & Route) with timing analysis.
- **`gen_bitstream.tcl`**: Generates the final `.bit` bitstream file and associated hardware handoff representations.
- **`non_project_mode.tcl`**: Facilitates the NPM synthesis flow to transparently handle rapid synthesis iterations in a temporary workspace, supporting SDK `$ rr synth run` commands.

## 🔌 IP Generation Hooks

- **`gen_bram.tcl`**: Instantiates Block RAM macros.
- **`gen_xlnx_fifos.tcl`**: Automatically generates XPM and native Xilinx FIFOs.
- **`gen_info_pkg.tcl`**: Emits ROM packages containing build metadata (SDK version, git hash, timestamp).
- **`gen_bd.tcl`**: Wrappers for automated Block Design (BD) IP generation.

## 🛠️ Utilities

- **`environment.tcl`**: Normalizes variables and environment settings prior to Vivado execution.
- **`analysis_utils.tcl` / `impl_utils.tcl`**: Helper functions for parsing utilization, timing, and CDC reports.
- **`query_devices.tcl`**: Fast, headless device enumeration.
- **`connect_ila.tcl` / `vio_tester.tcl`**: Debugging core insertion and hardware front-panel automation.
- **`project_options_*.tcl`**: Standard property enforcement for synthesis and implementation runs.

> **Note:** These scripts are executed automatically via the SDK (`rr` CLI) or standard Make targets. Direct execution is generally not required unless debugging Vivado issues or extending the toolchain.

