# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 12.09.2024
# Description: 


if { $::argc > 0 } {
 set g_root_dir $::argv
 puts "Root directory is $g_root_dir"
} 

if {[info exists g_root_dir]} {
    puts "Root directory is $g_root_dir"
} else {
    puts "Root directory is not defined, the script will exit."
    exit 1
}

proc bitstream { g_root_dir } {
	file mkdir $g_root_dir/bitstream
	file mkdir $g_root_dir/build
	open_checkpoint $g_root_dir/dcp/implementation.dcp

	# Source per-stage TCL hooks (from tcl_hooks.bitstream in project.yml)
	if {[info exists g_bitstream_hooks]} {
	    foreach hook $g_bitstream_hooks {
	        set hook_path "$g_root_dir/$hook"
	        if {[file exists $hook_path]} {
	            puts "  Sourcing bitstream hook: $hook"
	            source $hook_path
	        } else {
	            puts "  WARNING: bitstream hook not found: $hook_path"
	        }
	    }
	}
	write_bitstream -force ${g_root_dir}/bitstream/system.bit
	write_debug_probes -no_partial_ltxfile -force $g_root_dir/bitstream/system.ltx
	
	# Native extraction of SoC Hardware Platform Hand-Off
	set proj_name "system"
	catch { set proj_name [current_project] }
	catch { write_hw_platform -fixed -include_bit -force -file $g_root_dir/build/${proj_name}.xsa }
}

### MAIN PROGRAM
set implDcpFile $g_root_dir/dcp/implementation.dcp
# Resolve script directory (SDK Support)
set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
set implTclFile "${script_dir}/gen_implementation.tcl"

if {![file exists $implDcpFile]} {
	puts "Running implementation first ..."
    source $implTclFile
}

bitstream $g_root_dir