# RouteRTL Report Emitter — Xilinx / Vivado
# Emits reports/build_report.json with structured build results.
#
# Usage: source this file, then call:
#   emit_synth_report  $root_dir
#   emit_impl_report   $root_dir

# ── Helpers ──────────────────────────────────────────────────────

proc _rr_json_escape {str} {
    # Minimal JSON string escaping
    set str [string map {"\\" "\\\\" "\"" "\\\"" "\n" "\\n" "\t" "\\t"} $str]
    return $str
}

proc _rr_get_timestamp {} {
    return [clock format [clock seconds] -format "%Y-%m-%dT%H:%M:%S" -gmt false]
}

proc _rr_get_vivado_version {} {
    if {[catch {set ver [version -short]}]} {
        return "Vivado (unknown)"
    }
    return "Vivado $ver"
}

# ── Resource Extraction ──────────────────────────────────────────

proc _rr_extract_resources {} {
    # Use report_utilization -return_string to get utilization data
    # without writing to a file.
    set resources [dict create]

    if {[catch {set util_text [report_utilization -return_string]}]} {
        return $resources
    }

    # Parse the utilization table for key resources
    # Lines look like: | Slice LUTs | 1234 | 0 | 5678 | 21.73 |
    set lines [split $util_text "\n"]
    foreach line $lines {
        # Match: | <name> | <used> | <fixed> | <available> | <util%> |
        if {[regexp {^\|\s+(.+?)\s+\|\s+(\d+)\s+\|\s+\d+\s+\|\s+(\d+)\s+\|} $line -> name used avail]} {
            set name [string trim $name]
            switch -glob -- $name {
                "Slice LUTs"      -
                "CLB LUTs"        { dict set resources "LUTs"  [list $used $avail] }
                "Slice Registers" -
                "CLB Registers"   { dict set resources "FFs"   [list $used $avail] }
                "Block RAM Tile"  { dict set resources "BRAM"  [list $used $avail] }
                "DSPs"            -
                "DSP Slices"      { dict set resources "DSPs"  [list $used $avail] }
                "Bonded IOB"      { dict set resources "IOs"   [list $used $avail] }
            }
        }
        # Also match simpler rows: | <name> | <used> | <available> | <util%> |
        if {[regexp {^\|\s+(.+?)\s+\|\s+(\d+)\s+\|\s+(\d+)\s+\|\s+[\d.]+\s+\|} $line -> name used avail]} {
            set name [string trim $name]
            switch -glob -- $name {
                "LUT as Logic"    { if {![dict exists $resources "LUTs"]}  { dict set resources "LUTs"  [list $used $avail] } }
                "Register as Flip Flop" { if {![dict exists $resources "FFs"]} { dict set resources "FFs"   [list $used $avail] } }
            }
        }
    }

    return $resources
}

# ── Timing Extraction ────────────────────────────────────────────

proc _rr_extract_timing {} {
    set timing [dict create fmax_mhz 0.0 clock_name "" wns_ns 0.0 tns_ns 0.0 met true]

    if {[catch {
        set tp [get_timing_paths -max_paths 1 -nworst 1 -setup]
        set wns [get_property SLACK $tp]
        dict set timing wns_ns $wns
        if {$wns < 0.0} {
            dict set timing met false
        }

        # Try to get the clock name and compute Fmax
        set clk_name ""
        if {[catch {set clk_name [get_property ENDPOINT_CLOCK $tp]}]} {
            set clk_name "unknown"
        }
        dict set timing clock_name $clk_name

        # Compute Fmax from clock period + WNS
        if {$clk_name ne "" && $clk_name ne "unknown"} {
            if {[catch {
                set clk_obj [get_clocks $clk_name]
                set period [get_property PERIOD $clk_obj]
                if {$period > 0} {
                    set fmax [expr {1000.0 / ($period - $wns)}]
                    dict set timing fmax_mhz [format "%.1f" $fmax]
                }
            }]} {
                # Clock period not available
            }
        }
    }]} {
        # Timing extraction failed — design may not be routed yet
    }

    return $timing
}

# ── Warning/Error Count ──────────────────────────────────────────

proc _rr_count_messages {} {
    set warnings 0
    set errors 0

    # Try to get message counts from Vivado's message store
    if {![catch {set msgs [get_msg_config -count -severity WARNING]}]} {
        set warnings $msgs
    }
    if {![catch {set msgs [get_msg_config -count -severity ERROR]}]} {
        set errors $msgs
    }

    return [list $warnings $errors]
}

# ── JSON Writer ──────────────────────────────────────────────────

proc _rr_write_report {root_dir report_dict} {
    file mkdir "$root_dir/reports"
    set outfile "$root_dir/reports/build_report.json"

    set fd [open $outfile "w"]
    puts $fd "\{"

    set vendor  [_rr_json_escape [dict get $report_dict vendor]]
    set part    [_rr_json_escape [dict get $report_dict part]]
    set top     [_rr_json_escape [dict get $report_dict top_module]]
    set tool    [_rr_json_escape [dict get $report_dict tool_name]]
    set ts      [_rr_json_escape [dict get $report_dict timestamp]]
    set warns   [dict get $report_dict warnings]
    set errs    [dict get $report_dict errors]

    puts $fd "  \"vendor\": \"$vendor\","
    puts $fd "  \"part\": \"$part\","
    puts $fd "  \"top_module\": \"$top\","
    puts $fd "  \"tool_name\": \"$tool\","
    puts $fd "  \"timestamp\": \"$ts\","
    puts $fd "  \"warnings\": $warns,"
    puts $fd "  \"errors\": $errs,"

    # Phases
    puts $fd "  \"phases\": \["
    set phases [dict get $report_dict phases]
    set n [llength $phases]
    for {set i 0} {$i < $n} {incr i} {
        set ph [lindex $phases $i]
        set ph_name [_rr_json_escape [dict get $ph name]]
        set ph_pass [dict get $ph passed]
        set ph_dur  [dict get $ph duration_s]
        set comma ","
        if {$i == $n - 1} { set comma "" }
        puts $fd "    \{\"name\": \"$ph_name\", \"passed\": $ph_pass, \"duration_s\": $ph_dur\}$comma"
    }
    puts $fd "  \],"

    # Resources
    puts $fd "  \"resources\": \{"
    set res [dict get $report_dict resources]
    set keys [dict keys $res]
    set nk [llength $keys]
    set ki 0
    foreach key $keys {
        set vals [dict get $res $key]
        set used [lindex $vals 0]
        set avail [lindex $vals 1]
        set comma ","
        incr ki
        if {$ki == $nk} { set comma "" }
        puts $fd "    \"$key\": \{\"used\": $used, \"available\": $avail\}$comma"
    }
    puts $fd "  \},"

    # Timing
    set timing [dict get $report_dict timing]
    puts $fd "  \"timing\": \{"
    puts $fd "    \"fmax_mhz\": [dict get $timing fmax_mhz],"
    puts $fd "    \"clock_name\": \"[_rr_json_escape [dict get $timing clock_name]]\","
    puts $fd "    \"wns_ns\": [dict get $timing wns_ns],"
    puts $fd "    \"tns_ns\": [dict get $timing tns_ns],"
    puts $fd "    \"met\": [dict get $timing met]"
    puts $fd "  \}"

    puts $fd "\}"
    close $fd

    puts "RouteRTL: Build report written to $outfile"
}

# ── Public API ───────────────────────────────────────────────────

proc emit_synth_report {root_dir} {
    global g_fpga_part g_top_mod

    set part ""
    set top  ""
    if {[info exists g_fpga_part]} { set part $g_fpga_part }
    if {[info exists g_top_mod]}   { set top  $g_top_mod   }

    set resources [_rr_extract_resources]
    lassign [_rr_count_messages] warnings errors

    set report [dict create \
        vendor    "xilinx" \
        part      $part \
        top_module $top \
        tool_name [_rr_get_vivado_version] \
        timestamp [_rr_get_timestamp] \
        warnings  $warnings \
        errors    $errors \
        phases    [list [dict create name "Synthesis" passed true duration_s 0.0]] \
        resources $resources \
        timing    [dict create fmax_mhz 0.0 clock_name "" wns_ns 0.0 tns_ns 0.0 met true] \
    ]

    _rr_write_report $root_dir $report
}

proc emit_impl_report {root_dir} {
    global g_fpga_part g_top_mod

    set part ""
    set top  ""
    if {[info exists g_fpga_part]} { set part $g_fpga_part }
    if {[info exists g_top_mod]}   { set top  $g_top_mod   }

    set resources [_rr_extract_resources]
    set timing    [_rr_extract_timing]
    lassign [_rr_count_messages] warnings errors

    set report [dict create \
        vendor    "xilinx" \
        part      $part \
        top_module $top \
        tool_name [_rr_get_vivado_version] \
        timestamp [_rr_get_timestamp] \
        warnings  $warnings \
        errors    $errors \
        phases    [list \
            [dict create name "Synthesis"       passed true duration_s 0.0] \
            [dict create name "Optimization"    passed true duration_s 0.0] \
            [dict create name "Place & Route"   passed true duration_s 0.0] \
            [dict create name "Timing Analysis" passed true duration_s 0.0] \
        ] \
        resources $resources \
        timing    $timing \
    ]

    _rr_write_report $root_dir $report
}
