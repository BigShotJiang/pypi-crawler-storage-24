# RouteRTL — Query Licensed FPGA Devices (Xilinx / AMD)
# Invoked by: vivado -mode batch -nolog -nojournal -notrace -source query_devices.tcl
#
# Output format (one line per entry, machine-parseable):
#   FAMILY:<family_name>
#   PART:<family_name>:<part_number>

set families {}

foreach p [get_parts] {
    set fam [get_property FAMILY $p]
    if {[lsearch -exact $families $fam] < 0} {
        lappend families $fam
    }
    puts "PART:$fam:$p"
}

foreach fam [lsort $families] {
    puts "FAMILY:$fam"
}

quit
