set_property library $g_project_name [get_files ${vhd_files}] 
set_property library $g_project_name [get_files ${sim_files}] 