set_property library $g_project_name [get_files ${vhd_files}] 
set_property library $g_project_name [get_files ${sim_files}] 
set_property library utils  [get_files "${g_root_dir}/src/pkg/functions_pkg.vhd"]

#update_compile_order -fileset sources_1
#update_compile_order -fileset sim_1

set ddr_model_pkg_file "${g_root_dir}/src/pkg/ddr_model_pkg.vhd"
add_files -fileset sources_1 $ddr_model_pkg_file
set_property library xil_defaultlib [get_files $ddr_model_pkg_file]

set regbank_hex_file "${g_root_dir}/src/regbank/regbank_schema.hex"

set_property file_type {Data Files} [get_files -of_objects [get_filesets sources_1] $regbank_hex_file]
set_property file_type {Data Files} [get_files -of_objects [get_filesets sim_1] $regbank_hex_file]


# Retiming
set_property STEPS.SYNTH_DESIGN.ARGS.RETIMING true [get_runs synth_1]


#source $g_tcl_dir/front_panel.tcl

# Supress Mesages, change severity
set_msg_config -suppress -id {Board 49-36}
set_msg_config -suppress -id {Board 49-26}
set_msg_config -id {Timing 38-469} -new_severity {Warning}
