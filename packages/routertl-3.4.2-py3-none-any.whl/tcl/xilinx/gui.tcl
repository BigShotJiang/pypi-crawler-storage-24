# Author: Daniel J.Mazure, Tich
# Date: 09.09.2024
# Description: 

if { $::argc > 0 } {
 set g_root_dir    [lindex $argv 0]
 puts "Root directory is $g_root_dir"
}

source $g_root_dir/tcl/xilinx/environment.tcl
open_project ${g_project_dir}/${g_project_name}.xpr
update_compile_order -quiet

cd [get_property DIRECTORY [current_project]]

start_gui