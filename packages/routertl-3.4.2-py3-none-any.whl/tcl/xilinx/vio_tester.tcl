create_ip -name vio -vendor xilinx.com -library ip -version 3.0 -module_name vio_tester -dir $g_root_dir/ip
set_property -dict [list \
  CONFIG.C_NUM_PROBE_IN {2} \
  CONFIG.C_NUM_PROBE_OUT {3} \
  CONFIG.C_PROBE_IN0_WIDTH {10} \
  CONFIG.C_PROBE_IN1_WIDTH {10} \
  CONFIG.C_PROBE_OUT1_WIDTH {16} \
  CONFIG.C_PROBE_OUT2_WIDTH {5} \
] [get_ips vio_tester]