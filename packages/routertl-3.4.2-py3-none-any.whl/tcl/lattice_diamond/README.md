# Lattice Diamond TCL Backend — Stub

> **Status**: Not yet implemented.

This directory is a placeholder for Lattice Diamond TCL scripts. The existing
`tcl/lattice/` scripts target Radiant exclusively (`prj_create`, `prj_add_source`
APIs). Diamond uses a different TCL API and requires its own backend.

When Diamond support is implemented, this directory should contain:

- `environment.tcl` — Diamond environment setup
- `gen_project.tcl` — Diamond project generation
- `gen_synthesis.tcl` — Diamond synthesis flow
- `gen_implementation.tcl` — Diamond implementation flow
- `gen_bitstream.tcl` — Diamond bitstream generation

See [P3.42](https://github.com/dasjimaz/routertl/issues) for tracking.
