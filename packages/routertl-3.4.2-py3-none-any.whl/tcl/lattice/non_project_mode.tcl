# MIT License
# Copyright (c) 2020-2026 Daniel J. Mazure
# Description: Emulates Non-Project Mode synthesis for Lattice Radiant

if { $::argc >= 6} {
    set g_root_dir [lindex $argv 0]
    set syn_files  [lindex $argv 1]
    set xci_files  [lindex $argv 2]
    set xdc_files  [lindex $argv 3]
    set g_top_mod  [lindex $argv 4]
    set netlist_files [lindex $argv 5]
    puts "Root dir is $g_root_dir"
} else {
    puts "Error: Not enough arguments \($::argc\), exiting ..."
    exit
}

set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

puts "================================================="
puts " Running Radiant 'NPM' Synthesis: $g_top_mod"
puts "================================================="

# NPM outputs go to dcp/<top_module>
set npm_dir "${g_root_dir}/dcp/${g_top_mod}"
set npm_prj_dir "${npm_dir}/lattice_npm_prj"
set npm_prj_name "${g_top_mod}_npm"
set g_impl_name "impl_1"

file mkdir $npm_prj_dir

# Basic mapping (users should override via TCL hooks if exact part is needed)
set dev_part "iCE40UP5K-SG48I"

# Attempt to read project.yml to retrieve actual part if available
catch {
    set dev_part $g_fpga_part
}

if {[catch {
    prj_create -name $npm_prj_name \
        -dev $dev_part \
        -impl $g_impl_name \
        -impl_dir $npm_prj_dir \
        -synthesis "synplify" \
        -dir $npm_prj_dir
} err]} {
    puts "Project creation failed ($err). Attempting to open existing..."
    catch { prj_open "${npm_prj_dir}/${npm_prj_name}.rdf" }
}

# Add sources
foreach src_file $syn_files {
    if {[string length $src_file] > 0} {
        puts "Adding source: ${g_root_dir}/${src_file}"
        catch { prj_add_source "${g_root_dir}/${src_file}" }
    }
}

foreach sdc_file $xdc_files {
    if {[string length $sdc_file] > 0} {
        puts "Adding constraint: ${g_root_dir}/${sdc_file}"
        catch { prj_add_source "${g_root_dir}/${sdc_file}" }
    }
}

# Pre-compiled netlists (.ngo native, .edf/.edif EDIF)
if {[info exists netlist_files]} {
    foreach f $netlist_files {
        if {[string trim $f] eq ""} { continue }
        if {[file pathtype $f] eq "absolute"} {
            set abs_f $f
        } else {
            set abs_f [file normalize $g_root_dir/$f]
        }
        set ext [string tolower [file extension $f]]
        if {$ext eq ".ngo"} {
            catch { prj_add_source $abs_f }
            puts "Info: Added NGO netlist '$abs_f'"
        } elseif {$ext eq ".edf" || $ext eq ".edif"} {
            catch { prj_add_source $abs_f }
            puts "Info: Added EDIF netlist '$abs_f'"
        } elseif {$ext eq ".vhd" || $ext eq ".vhdl" || $ext eq ".sv" || $ext eq ".v"} {
            catch { prj_add_source $abs_f }
        } else {
            puts "Warning: Unknown netlist extension '$ext' for $f — skipping"
        }
    }
}

catch { prj_set_impl_opt -impl $g_impl_name "top" $g_top_mod }

puts "Running SYNTHESIZE tool..."
catch { prj_run_synthesis }

set srr_file "${npm_prj_dir}/${g_impl_name}/${npm_prj_name}_${g_impl_name}.srr"
if {[file exists $srr_file]} {
    puts "NPM Synthesis emulation complete. Report generated at: $srr_file"
} else {
    puts "NPM Synthesis emulation failed. Check Radiant logs inside $npm_prj_dir"
}

prj_save
prj_close
