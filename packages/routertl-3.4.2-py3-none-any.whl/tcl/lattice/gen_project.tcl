# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Author: Daniel J.Mazure, Tich
# Date: 2025
# Description:  Generates a Lattice Radiant project from the command line

if { $::argc >= 2} {
    set g_root_dir [lindex $argv 0]
    set syn_files  [lindex $argv 1]
    set xci_files  [lindex $argv 2]
    set sim_files  [lindex $argv 3]
    set tcl_files  [lindex $argv 4]
    set xdc_files  [lindex $argv 5]
    set netlist_files [lindex $argv 6]
    puts "Root dir is $g_root_dir"
} else {
    puts "Error: Not enough arguments \($::argc\), exting ..."
    exit
}

# Resolve script directory for relative sourcing (SDK Support)
set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

# Define utils — library-aware file addition
proc find_library_for_file {file_path} {
    # Check if g_libraries dict exists and maps this file to a library
    if {![info exists ::g_libraries]} { return "" }
    dict for {lib_name lib_files} $::g_libraries {
        foreach lf $lib_files {
            # Match by tail (basename) or full relative path
            if {$file_path eq $lf || [file tail $file_path] eq [file tail $lf]} {
                return $lib_name
            }
        }
    }
    return ""
}

proc add_file_to_project {file_path root_dir} {
    set library [find_library_for_file $file_path]
    if {$library ne ""} {
        puts "Adding file: ${root_dir}/${file_path} (library: $library)"
        prj_add_source ${root_dir}/${file_path} -work $library
    } else {
        puts "Adding file: ${root_dir}/${file_path}"
        prj_add_source ${root_dir}/${file_path}
    }
}

# Create the project
set g_impl_name "impl_1"

prj_create -name $g_project_name \
    -dev ${g_fpga_part} \
    -impl ${g_impl_name} \
    -impl_dir $g_project_dir \
    -synthesis "synplify" \
    -dir $g_project_dir

prj_set_strategy_value -strategy Strategy1 syn_vhdl2008=True
prj_set_strategy_value -strategy Strategy1 {syn_pipelining_retiming=Pipelining and Retiming}
prj_set_strategy_value -strategy Strategy1 par_pathbased_place=On 
prj_set_strategy_value -strategy Strategy1 par_save_best_result=2 
prj_set_strategy_value -strategy Strategy1 par_place_iterator=4 
prj_set_strategy_value -strategy Strategy1 par_stop_zero=True
prj_set_strategy_value -strategy Strategy1 par_core_number=32
prj_set_strategy_value -strategy Strategy1 syn_allow_dup_modules=True
prj_set_strategy_value -strategy Strategy1 par_pack_logicutil=20 par_place_iterator_start_pt=20

# Add sources (with library awareness)
foreach src_file $syn_files {
    add_file_to_project $src_file $g_root_dir
}

# Workaround to add IPX files, as Radiant is not accepting the IPX files directly
set lattice_ip_folder "${g_root_dir}/ip/lattice"
foreach ipx_unit $xci_files {
    # The file is the folder name with the extension .ipx
    # Depending on how the IP is passed, xci_files might just be directories or the .ipx files itself. 
    # Let's assume it's just the folder name or we extract it
    set ip_name [file rootname [file tail $ipx_unit]]
    set ip_dir [file dirname $ipx_unit]
    
    set ipx_file ${g_root_dir}/${ipx_unit}
    puts "IPX file: $ipx_file"
    if {[file exists $ipx_file]} {
        file mkdir $g_project_dir/source/${g_impl_name}
        file copy -force ${g_root_dir}/${ip_dir} $g_project_dir/source/${g_impl_name}
        
        # Now add the copied file
        set local_ipx "source/${g_impl_name}/[file tail $ip_dir]/[file tail $ipx_file]"
        prj_add_source $local_ipx
    } else {
        puts "Unknown IP file: $ipx_unit"
    }
}

# Add constraints
foreach xdc_file $xdc_files {
    add_file_to_project $xdc_file $g_root_dir
}

# Pre-compiled netlists (.ngo native, .edf/.edif EDIF)
if {[info exists netlist_files]} {
    foreach f $netlist_files {
        if {[string trim $f] eq ""} { continue }
        if {[file pathtype $f] eq "absolute"} {
            set abs_f $f
        } else {
            set abs_f [file normalize $g_root_dir/$f]
        }
        set ext [string tolower [file extension $f]]
        if {$ext eq ".ngo"} {
            prj_add_source $abs_f
            puts "Info: Added NGO netlist '$abs_f'"
        } elseif {$ext eq ".edf" || $ext eq ".edif"} {
            prj_add_source $abs_f
            puts "Info: Added EDIF netlist '$abs_f'"
        } elseif {$ext eq ".vhd" || $ext eq ".vhdl" || $ext eq ".sv" || $ext eq ".v"} {
            prj_add_source $abs_f
        } else {
            puts "Warning: Unknown netlist extension '$ext' for $f — skipping"
        }
    }
}

prj_set_impl_opt -impl "impl_1" "top" $g_top_mod

# Bring up the IP defined in the tcl files (Hooks)
# ---------------------------------------------------------------------------
# User Hooks: Source custom TCL scripts defined in project.yml -> tcl_hooks.gen_project
# ---------------------------------------------------------------------------
if {[info exists g_gen_project_hooks]} {
    foreach hook_script $g_gen_project_hooks {
        set full_path "${g_root_dir}/${hook_script}"
        if {[file exists $full_path]} {
            puts "INFO: Sourcing gen_project hook: $hook_script"
            source $full_path
        } else {
            puts "WARNING: gen_project hook not found: $full_path"
        }
    }
}

foreach tcl_file $tcl_files {
    source ${g_root_dir}/$tcl_file
}

prj_save
prj_close