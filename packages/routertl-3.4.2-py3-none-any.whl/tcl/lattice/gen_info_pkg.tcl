# Tich (c) 2025
# Daniel J. Mazure

set g_root_dir [pwd]

if { $::argc >= 1 } {
    set g_root_dir  [lindex $argv 0]
    puts "Root dir is  $g_root_dir"
}

source ${g_root_dir}/tcl/lattice/environment.tcl
## 1. Create the constants and include them in the pkg file, which is created here
set g_info_file [file normalize "${g_root_dir}/misc/rom.data"]


set fd_info [open $g_info_file r]

# Pops from the file in order of appareance
set C_BUILD_DATE   [gets $fd_info]
set C_GIT_HASH     [gets $fd_info]
set C_SYSTEM_VERSION  [gets $fd_info]

close $fd_info
# set C_FIFO_EP_DEPTH_NBITS [expr {int(ceil(log(double($C_FIFO_EP_DEPTH))/log(2.0)))} + $FWFT]

puts "Git Hash Hex value: $C_GIT_HASH"
puts "Build Date: $C_BUILD_DATE"

set g_pkg_name    rom_info_pkg
set g_pkg_file    $g_root_dir/src/pkg/${g_pkg_name}

set fd_pkg    [open $g_pkg_file "w"]

set ActualTime  [clock seconds]
set InitialTime [clock format $ActualTime -format %H:%M:%S -gmt true]

puts $fd_pkg "-- Tich (c) 2025"
puts $fd_pkg "-- File created @[clock format [clock seconds]]"
puts $fd_pkg "-- This file was created automatically by the gen_info_pkg tcl script"


set libraries "
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
use IEEE.MATH_REAL.all;
"
# Write the libraries to the components file
puts $fd_pkg $libraries; 

# Write the package declaration to the components file
puts $fd_pkg "package ${g_pkg_name} is"

puts $fd_pkg "
  constant C_ROM_DATA_WIDTH  : integer  := 32;
  constant C_GIT_HASH        : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x\"${C_GIT_HASH}\";
  constant C_SYSTEM_VERSION     : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x\"${C_SYSTEM_VERSION}\";
  constant C_BUILD_DATE      : std_logic_vector(C_ROM_DATA_WIDTH-1 downto 0) := x\"${C_BUILD_DATE}\";
"

puts $fd_pkg "
end package ${g_pkg_name};
"
puts $fd_pkg "
package body ${g_pkg_name} is
"
puts $fd_pkg "
end ${g_pkg_name};
"

close $fd_pkg

file copy -force $g_pkg_file ${g_pkg_file}.vhd

file delete -force $g_pkg_file
