# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, ...
# 
# Author: Daniel J.Mazure, Tich
# Date: 2025
# Description: Lattice Radiant Programming Script 

if { $::argc > 0 } {
 set g_root_dir [lindex $argv 0]
}

set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

# If the implied bitstream was copied somewhere else manually,
# this expects the implementation name derived bitstream to be present.
# We map g_impl_name to impl_1 since Radiant defaults to impl_1 and 
# gen_project.tcl uses it explicitly.
set g_impl_name "impl_1"
set bitstream_path "${g_project_dir}/${g_project_name}.runs/${g_impl_name}/${g_top_mod}.bin"
if {![file exists $bitstream_path]} {
    puts "Warning: Expected bitstream at $bitstream_path not found. Is bitstream generated?"
}

puts "================================================="
puts " Running Radiant Programmer"
puts "================================================="

# Create and open programming project on the fly if needed
set xcf_path "${g_project_dir}/${g_project_name}.runs/${g_impl_name}/${g_impl_name}.xcf"
if {![file exists $xcf_path]} {
    # It's better to explicitly provide instructions or a default XCF file
    # This matches the legacy VDCO behavior of opening an existing config.
    puts "Error: Expected programming file $xcf_path not found. Please generate programming project."
    # We fallback to a generic xcf file if we wanted, but let's error out for now
    error "Programming file $xcf_path not found"
}

pgr_project open $xcf_path
pgr_program set -cable usb2 
pgr_program run

puts "Programming completed successfully."
