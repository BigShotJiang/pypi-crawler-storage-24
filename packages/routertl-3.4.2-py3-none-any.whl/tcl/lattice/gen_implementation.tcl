# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, ...
# 
# Author: Daniel J.Mazure, Tich
# Date: 2025
# Description: Lattice Radiant Implementation Script 

if { $::argc > 0 } {
 set g_root_dir [lindex $argv 0]
 puts "Root directory is $g_root_dir"
}

# Resolve script directory (SDK Support)
set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

prj_open ${g_project_dir}/${g_project_name}.rdf

# Source per-stage TCL hooks (from tcl_hooks.implementation in project.yml)
if {[info exists g_implementation_hooks]} {
    foreach hook $g_implementation_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing implementation hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: implementation hook not found: $hook_path"
        }
    }
}

puts "================================================="
puts " Running Radiant Place and Route"
puts "================================================="

prj_run_par

puts "Place and route completed successfully."
prj_save
prj_close
