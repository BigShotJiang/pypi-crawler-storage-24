# Open-Source FPGA Toolchain TCL Backend — Stub

> **Status**: Not yet implemented.

This directory is a placeholder for open-source FPGA toolchain scripts
(Yosys for synthesis, nextpnr for place & route, icepack/ecppack for
bitstream generation).

Unlike vendor TCL backends, the open-source flow uses a different
invocation model:

- **Yosys**: reads a `.ys` synthesis script (TCL-like but distinct)
- **nextpnr**: CLI-driven, no TCL at all
- **icepack / ecppack**: simple binary conversion

When implemented, this directory should contain wrapper scripts that
bridge the RouteRTL project model to the open-source toolchain.

See [P3.42](https://github.com/dasjimaz/routertl/issues) for tracking.
