# Altera Bitstream & Timing Script
# Tich (c) 2026

if { $::argc > 0 } {
    set g_root_dir [lindex $argv 0]
} else {
    set g_root_dir [pwd]
}

set script_dir [file dirname [info script]]
source ${script_dir}/environment.tcl

package require ::quartus::project
package require ::quartus::flow

# Check if implementation is needed (imitate Xilinx logic)
set fit_rpt "$g_project_dir/$g_project_name.fit.rpt"

if {![file exists $fit_rpt]} {
    puts "Implementation report not found, running Implementation first..."
    source ${script_dir}/gen_implementation.tcl
}

project_open $g_project_dir/$g_project_name -current_revision

# Source per-stage TCL hooks (from tcl_hooks.bitstream in project.yml)
if {[info exists g_bitstream_hooks]} {
    foreach hook $g_bitstream_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing bitstream hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: bitstream hook not found: $hook_path"
        }
    }
}

puts "-----------------------------------------------------------------------"
puts "Running Assembler (Bitstream Generation - quartus_asm)..."
puts "-----------------------------------------------------------------------"

if {[catch {execute_module -tool asm} result]} {
    puts "ERROR: Assembler failed."
    puts "$result"
    project_close
    exit 1
}

puts "-----------------------------------------------------------------------"
puts "Running Timing Analysis (quartus_sta)..."
puts "-----------------------------------------------------------------------"

if {[catch {execute_module -tool sta} result]} {
    puts "ERROR: Timing Analysis failed."
    puts "$result"
    project_close
    exit 1
}

# Copy bitstream output to a dedicated bitstream/ directory (parity with Xilinx flow)
file mkdir $g_root_dir/bitstream
set sof_file "$g_project_dir/$g_project_name.sof"
if {[file exists $sof_file]} {
    file copy -force $sof_file $g_root_dir/bitstream/
    puts "Bitstream copied to bitstream/$g_project_name.sof"
}
# Also copy .pof if present (flash-based devices)
set pof_file "$g_project_dir/$g_project_name.pof"
if {[file exists $pof_file]} {
    file copy -force $pof_file $g_root_dir/bitstream/
    puts "Flash image copied to bitstream/$g_project_name.pof"
}

project_close
puts "Bitstream generation and Timing Analysis completed successfully."

