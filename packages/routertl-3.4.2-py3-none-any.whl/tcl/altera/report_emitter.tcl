# RouteRTL Report Emitter — Altera / Quartus
# Emits reports/build_report.json with structured build results.
#
# Usage: source this file, then call:
#   emit_synthesis_report  $root_dir $project_dir $project_name
#   emit_implementation_report $root_dir $project_dir $project_name

package require ::quartus::report

# ── Helpers ──────────────────────────────────────────────────────

proc _rr_json_escape {str} {
    set str [string map {"\\" "\\\\" "\"" "\\\"" "\n" "\\n" "\t" "\\t"} $str]
    return $str
}

proc _rr_get_timestamp {} {
    return [clock format [clock seconds] -format "%Y-%m-%dT%H:%M:%S" -gmt false]
}

proc _rr_get_quartus_version {} {
    global quartus
    if {[info exists quartus(version)]} {
        return "Quartus Prime $quartus(version)"
    }
    return "Quartus Prime (unknown)"
}

# ── Resource Extraction ──────────────────────────────────────────

proc _rr_extract_quartus_resources {project_name} {
    set resources [dict create]

    # Try to read the Fitter Summary panel first (most accurate post-fit)
    set panels [list "Fitter || Resource Section || Fitter Resource Usage Summary" \
                     "Fitter || Fitter Resource Usage Summary" \
                     "Analysis & Synthesis || Resource Usage Summary" \
                     "Analysis & Synthesis || Analysis & Synthesis Resource Usage Summary"]

    foreach panel_id $panels {
        if {[catch {
            # Load the report (it may already be loaded)
            if {[catch {load_report $project_name}]} {
                # Report might already be loaded
            }

            set panel_names [get_report_panel_names]
            foreach pn $panel_names {
                if {[string match "*Resource*Summary*" $pn]} {
                    set rows [get_number_of_rows -name $pn]
                    for {set r 0} {$r < $rows} {incr r} {
                        set rname [get_report_panel_data -name $pn -row $r -col 0]
                        set rval  [get_report_panel_data -name $pn -row $r -col 1]

                        # Parse "4,210 / 18,480 ( 23 % )" or just "3,847"
                        set used 0
                        set avail 0
                        if {[regexp {([\d,]+)\s*/\s*([\d,]+)} $rval -> u a]} {
                            set used  [string map {"," ""} $u]
                            set avail [string map {"," ""} $a]
                        } elseif {[regexp {([\d,]+)} $rval -> u]} {
                            set used [string map {"," ""} $u]
                        }

                        # Map resource names
                        switch -glob -- [string trim $rname] {
                            "*ALM*"                  { dict set resources "ALMs"  [list $used $avail] }
                            "*logic element*"        -
                            "*combinational*"        { if {![dict exists $resources "ALMs"]} { dict set resources "ALMs" [list $used $avail] } }
                            "*register*"             -
                            "*Dedicated*register*"   { dict set resources "Regs"  [list $used $avail] }
                            "*M10K*"                 { dict set resources "M10K"  [list $used $avail] }
                            "*M20K*"                 { dict set resources "M20K"  [list $used $avail] }
                            "*memory bit*"           { if {![dict exists $resources "M10K"] && ![dict exists $resources "M20K"]} {
                                                        dict set resources "BRAM" [list $used $avail] } }
                            "*DSP*"                  { dict set resources "DSPs"  [list $used $avail] }
                            "*pin*"                  -
                            "*I/O*"                  { dict set resources "IOs"   [list $used $avail] }
                        }
                    }
                    # Found a valid panel, stop searching
                    if {[dict size $resources] > 0} {
                        return $resources
                    }
                }
            }
        }]} {
            # Panel read failed, try next
        }
    }

    return $resources
}

# ── Timing Extraction ────────────────────────────────────────────

proc _rr_extract_quartus_timing {project_name} {
    set timing [dict create fmax_mhz 0.0 clock_name "" wns_ns 0.0 tns_ns 0.0 met true]

    if {[catch {
        # Try STA report panels
        set panel_names [get_report_panel_names]
        foreach pn $panel_names {
            # Look for "Slow 1100mV 85C Model Fmax Summary" or similar
            if {[string match "*Fmax Summary*" $pn]} {
                set rows [get_number_of_rows -name $pn]
                set min_fmax 99999.0
                set min_clk ""
                for {set r 1} {$r < $rows} {incr r} {
                    set fmax_str [get_report_panel_data -name $pn -row $r -col 0]
                    set clk_str  [get_report_panel_data -name $pn -row $r -col 2]
                    if {[regexp {([\d.]+)\s*MHz} $fmax_str -> freq]} {
                        if {$freq < $min_fmax} {
                            set min_fmax $freq
                            set min_clk $clk_str
                        }
                    }
                }
                if {$min_fmax < 99999.0} {
                    dict set timing fmax_mhz $min_fmax
                    dict set timing clock_name [string trim $min_clk]
                }
                break
            }
        }

        # Look for setup slack
        foreach pn $panel_names {
            if {[string match "*Setup Summary*" $pn]} {
                set rows [get_number_of_rows -name $pn]
                set worst_slack 99999.0
                for {set r 1} {$r < $rows} {incr r} {
                    set slack_str [get_report_panel_data -name $pn -row $r -col 0]
                    if {[string is double -strict $slack_str]} {
                        if {$slack_str < $worst_slack} {
                            set worst_slack $slack_str
                        }
                    }
                }
                if {$worst_slack < 99999.0} {
                    dict set timing wns_ns $worst_slack
                    dict set timing met [expr {$worst_slack >= 0.0}]
                }
                break
            }
        }
    }]} {
        # Timing extraction failed
    }

    return $timing
}

# ── JSON Writer ──────────────────────────────────────────────────

proc _rr_write_report {root_dir report_dict} {
    file mkdir "$root_dir/reports"
    set outfile "$root_dir/reports/build_report.json"

    set fd [open $outfile "w"]
    puts $fd "\{"

    set vendor  [_rr_json_escape [dict get $report_dict vendor]]
    set part    [_rr_json_escape [dict get $report_dict part]]
    set top     [_rr_json_escape [dict get $report_dict top_module]]
    set tool    [_rr_json_escape [dict get $report_dict tool_name]]
    set ts      [_rr_json_escape [dict get $report_dict timestamp]]
    set warns   [dict get $report_dict warnings]
    set errs    [dict get $report_dict errors]

    puts $fd "  \"vendor\": \"$vendor\","
    puts $fd "  \"part\": \"$part\","
    puts $fd "  \"top_module\": \"$top\","
    puts $fd "  \"tool_name\": \"$tool\","
    puts $fd "  \"timestamp\": \"$ts\","
    puts $fd "  \"warnings\": $warns,"
    puts $fd "  \"errors\": $errs,"

    # Phases
    puts $fd "  \"phases\": \["
    set phases [dict get $report_dict phases]
    set n [llength $phases]
    for {set i 0} {$i < $n} {incr i} {
        set ph [lindex $phases $i]
        set ph_name [_rr_json_escape [dict get $ph name]]
        set ph_pass [dict get $ph passed]
        set ph_dur  [dict get $ph duration_s]
        set comma ","
        if {$i == $n - 1} { set comma "" }
        puts $fd "    \{\"name\": \"$ph_name\", \"passed\": $ph_pass, \"duration_s\": $ph_dur\}$comma"
    }
    puts $fd "  \],"

    # Resources
    puts $fd "  \"resources\": \{"
    set res [dict get $report_dict resources]
    set keys [dict keys $res]
    set nk [llength $keys]
    set ki 0
    foreach key $keys {
        set vals [dict get $res $key]
        set used [lindex $vals 0]
        set avail [lindex $vals 1]
        set comma ","
        incr ki
        if {$ki == $nk} { set comma "" }
        puts $fd "    \"$key\": \{\"used\": $used, \"available\": $avail\}$comma"
    }
    puts $fd "  \},"

    # Timing
    set timing [dict get $report_dict timing]
    puts $fd "  \"timing\": \{"
    puts $fd "    \"fmax_mhz\": [dict get $timing fmax_mhz],"
    puts $fd "    \"clock_name\": \"[_rr_json_escape [dict get $timing clock_name]]\","
    puts $fd "    \"wns_ns\": [dict get $timing wns_ns],"
    puts $fd "    \"tns_ns\": [dict get $timing tns_ns],"
    puts $fd "    \"met\": [dict get $timing met]"
    puts $fd "  \}"

    puts $fd "\}"
    close $fd

    puts "RouteRTL: Build report written to $outfile"
}

# ── Public API ───────────────────────────────────────────────────

proc emit_synthesis_report {root_dir project_dir project_name} {
    global g_fpga_part g_top_mod g_quartus_edition

    set part ""
    set top  ""
    if {[info exists g_fpga_part]} { set part $g_fpga_part }
    if {[info exists g_top_mod]}   { set top  $g_top_mod   }

    set resources [_rr_extract_quartus_resources $project_name]
    set tool_name [_rr_get_quartus_version]

    set report [dict create \
        vendor    "altera" \
        part      $part \
        top_module $top \
        tool_name $tool_name \
        timestamp [_rr_get_timestamp] \
        warnings  0 \
        errors    0 \
        phases    [list [dict create name "Analysis & Synthesis" passed true duration_s 0.0]] \
        resources $resources \
        timing    [dict create fmax_mhz 0.0 clock_name "" wns_ns 0.0 tns_ns 0.0 met true] \
    ]

    _rr_write_report $root_dir $report
}

proc emit_implementation_report {root_dir project_dir project_name} {
    global g_fpga_part g_top_mod

    set part ""
    set top  ""
    if {[info exists g_fpga_part]} { set part $g_fpga_part }
    if {[info exists g_top_mod]}   { set top  $g_top_mod   }

    set resources [_rr_extract_quartus_resources $project_name]
    set timing    [_rr_extract_quartus_timing $project_name]
    set tool_name [_rr_get_quartus_version]

    set report [dict create \
        vendor    "altera" \
        part      $part \
        top_module $top \
        tool_name $tool_name \
        timestamp [_rr_get_timestamp] \
        warnings  0 \
        errors    0 \
        phases    [list \
            [dict create name "Analysis & Synthesis" passed true duration_s 0.0] \
            [dict create name "Fitter"               passed true duration_s 0.0] \
            [dict create name "Timing Analysis"      passed true duration_s 0.0] \
        ] \
        resources $resources \
        timing    $timing \
    ]

    _rr_write_report $root_dir $report
}
