# Altera Project Generation
# Tich (c) 2026
# Description: Generates a Quartus project from the command line

if { $::argc >= 2 } {
    set g_root_dir    [lindex $argv 0]
    set vhd_files     [lindex $argv 1]
    set ip_files      [lindex $argv 2] ;# Includes .qsys or .ip
    set sim_files     [lindex $argv 3]
    set tcl_files     [lindex $argv 4]
    set xdc_files     [lindex $argv 5] ;# Includes .sdc or .tcl pinout
    set netlist_files [lindex $argv 6] ;# Pre-compiled netlists (.qxp/.qdb/.edf)
    puts "Root dir is $g_root_dir"
} else {
    puts "Error: Not enough arguments ($::argc), exiting ..."
    exit 1
}
# Environment configuration
set script_dir [file dirname [info script]]
source ${script_dir}/environment.tcl

# Create project
if {[project_exists $g_project_name]} {
    project_open $g_project_name -current_revision
} else {
    # Ensure project directory exists
    if {![file exists $g_project_dir]} {
        file mkdir $g_project_dir
    }
    project_new $g_project_dir/$g_project_name -overwrite
}

# -------------------------------------------------------------------------
# Project Options
# -------------------------------------------------------------------------
# Check if project_options.tcl is in the tcl_files or use default
set options_sourced 0
foreach tcl_file $tcl_files {
    if {[string match "*project_options.tcl" $tcl_file]} {
        if {[file pathtype $tcl_file] eq "absolute"} {
            set abs_tcl $tcl_file
        } else {
            set abs_tcl [file normalize $g_root_dir/$tcl_file]
        }
        puts "Sourcing project options from $abs_tcl"
        source $abs_tcl
        set options_sourced 1
        break
    }
}

if {!$options_sourced} {
    if {[file exists $g_tcl_dir/project_options.tcl]} {
        puts "Sourcing default project options from $g_tcl_dir/project_options.tcl"
        source $g_tcl_dir/project_options.tcl
    }
}

# ── FAMILY / DEVICE from project.yml ──────────────────────────
package require ::quartus::device

if {[info exists g_fpga_part] && $g_fpga_part ne ""} {
    # Derive FAMILY from part if not explicitly configured.
    if {![info exists g_fpga_family] || $g_fpga_family eq ""} {
        set g_fpga_family [lindex [get_part_info -family $g_fpga_part] 0]
        puts "Info: Derived FAMILY '$g_fpga_family' from part '$g_fpga_part'"
    }

    # Pre-flight license check.
    set licensed_families [get_family_list]
    if {[lsearch -exact $licensed_families $g_fpga_family] < 0} {
        puts "==========================================================================="
        puts "ERROR: No license for family '$g_fpga_family' (part: $g_fpga_part)"
        puts "  Quartus edition: $g_quartus_edition"
        puts "==========================================================================="
        puts ""
        puts "Licensed families on this machine:"
        foreach fam $licensed_families {
            puts "  • $fam"
        }
        puts ""
        puts "To fix:"
        puts "  1. Obtain a license for '$g_fpga_family' from Intel Licensing Center"
        puts "  2. Or target a licensed family:"
        puts "     rr config set hardware.part <part_from_licensed_family>"
        puts "     rr config set hardware.family <licensed_family>"
        puts "==========================================================================="
        exit 1
    }

    set_global_assignment -name FAMILY $g_fpga_family
    set_global_assignment -name DEVICE $g_fpga_part
}
set_global_assignment -name TOP_LEVEL_ENTITY $g_top_mod

# ── Library mapping from .routertl_cache/libraries.json ───────
# Build a reverse map: file_path → library_name
# This mirrors the NPM flow's lib:path token handling.
set lib_map [dict create]
set lib_json_path "$g_root_dir/.routertl_cache/libraries.json"
if {[file exists $lib_json_path]} {
    set fp [open $lib_json_path r]
    set json_raw [read $fp]
    close $fp
    # Minimal JSON parser: extract "lib": ["file1", "file2", ...]
    # regexp -all -inline returns: full_match, group1(lib), group2(file_list)
    foreach {match lib_name file_list} [regexp -all -inline {"(\w+)"\s*:\s*\[([^\]]*)\]} $json_raw] {
        foreach {fmatch file_path} [regexp -all -inline {"([^"]+)"} $file_list] {
            dict set lib_map $file_path $lib_name
        }
    }
    puts "Info: Loaded library map from $lib_json_path ([dict size $lib_map] entries)"
}

# VHDL / Verilog / SystemVerilog sources
# Also build a list of unique source directories for SEARCH_PATH discovery.
set src_dirs {}
foreach f $vhd_files {
    if {[file pathtype $f] eq "absolute"} {
        set abs_f $f
    } else {
        set abs_f [file normalize $g_root_dir/$f]
    }
    set ext [file extension $f]
    if {$ext eq ".vhd" || $ext eq ".vhdl"} {
        # Check library mapping — default to "work"
        set lib "work"
        if {[dict exists $lib_map $f]} {
            set lib [dict get $lib_map $f]
        }
        set_global_assignment -name VHDL_FILE $abs_f -library $lib
    } elseif {$ext eq ".sv" || $ext eq ".svh"} {
        set_global_assignment -name SYSTEMVERILOG_FILE $abs_f
    } elseif {$ext eq ".v"} {
        set_global_assignment -name VERILOG_FILE $abs_f
    }
    # Track unique parent directories of all source files
    set dir [file dirname $abs_f]
    if {$dir ni $src_dirs} {
        lappend src_dirs $dir
    }
}

# ── SEARCH_PATH for Verilog include directories ────────────────
# .vh files are NOT in the source list — they're `include'd by
# .v/.sv files.  Scan each source directory for .vh siblings and
# register their parent dirs as SEARCH_PATH entries.
set include_dirs {}
foreach dir $src_dirs {
    if {[llength [glob -nocomplain -directory $dir *.vh]] > 0} {
        if {$dir ni $include_dirs} {
            lappend include_dirs $dir
            set_global_assignment -name SEARCH_PATH $dir
            puts "Info: Added SEARCH_PATH $dir (contains .vh headers)"
        }
    }
}

# IP and Block Designs
foreach f $ip_files {
    if {[string trim $f] eq ""} { continue }
    if {[file pathtype $f] eq "absolute"} {
        set abs_f $f
    } else {
        set abs_f [file normalize $g_root_dir/$f]
    }
    if {[file extension $f] eq ".qsys"} {
        set_global_assignment -name QSYS_FILE $abs_f
    } elseif {[file extension $f] eq ".ip" || [file extension $f] eq ".qip"} {
        set_global_assignment -name QIP_FILE $abs_f
    }
}

# Constraints
foreach f $xdc_files {
    if {[file pathtype $f] eq "absolute"} {
        set abs_f $f
    } else {
        set abs_f [file normalize $g_root_dir/$f]
    }
    if {[file extension $f] eq ".sdc"} {
        set_global_assignment -name SDC_FILE $abs_f
    } elseif {[file extension $f] eq ".tcl"} {
        # Traditionally Altera pinouts can be TCL scripts
        source $abs_f
    }
}

# Custom TCL scripts / Block Design generation
foreach f $tcl_files {
    # Skip project_options.tcl as it was already sourced
    if {![string match "*project_options.tcl" $f]} {
        puts "Sourcing custom script: $f"
        source $f
    }
}

# Pre-compiled netlists (.qxp encrypted, .qdb database, .edf/.edif EDIF)
# Edition-aware: .qxp is native to Standard, .qdb is native to Pro.
if {[info exists netlist_files]} {
    # Pre-scan: collect entity names from QXP files so we can skip
    # duplicate _bb_standalone.vhd stubs that re-declare the same entity.
    set qxp_entities {}
    foreach f $netlist_files {
        if {[file extension $f] eq ".qxp"} {
            lappend qxp_entities [file rootname [file tail $f]]
        }
    }

    foreach f $netlist_files {
        if {[string trim $f] eq ""} { continue }
        if {[file pathtype $f] eq "absolute"} {
            set abs_f $f
        } else {
            set abs_f [file normalize $g_root_dir/$f]
        }
        set ext [file extension $f]
        if {$ext eq ".qxp"} {
            # QXP: Quartus Standard Edition incremental compilation export.
            # Register via SOURCE_FILE so the compile flow can import it.
            if {[info exists g_quartus_edition] && $g_quartus_edition eq "pro"} {
                puts "Warning: .qxp netlist '$f' is a Standard format — Pro uses .qdb"
            }
            set_global_assignment -name SOURCE_FILE $abs_f
            puts "Info: Registered QXP netlist '$abs_f' (Standard Edition)"
        } elseif {$ext eq ".qdb"} {
            # QDB: Quartus Pro Edition partition export.
            if {[info exists g_quartus_edition] && $g_quartus_edition eq "std"} {
                puts "Warning: .qdb netlist '$f' is a Pro format — Standard uses .qxp"
            }
            set_global_assignment -name QDB_FILE $abs_f
        } elseif {$ext eq ".edf" || $ext eq ".edif"} {
            set_global_assignment -name EDIF_FILE $abs_f
        } elseif {$ext eq ".vhd" || $ext eq ".vhdl"} {
            # Black-box entity stubs — skip if entity already registered via QXP
            set entity_name [file rootname [file tail $f]]
            regsub {_bb_standalone$} $entity_name "" entity_name
            regsub {_bb$} $entity_name "" entity_name
            if {$entity_name ni $qxp_entities} {
                set_global_assignment -name VHDL_FILE $abs_f
            } else {
                puts "Info: Skipping BB stub '$f' — entity '$entity_name' already in QXP"
            }
        } elseif {$ext eq ".sv"} {
            set_global_assignment -name SYSTEMVERILOG_FILE $abs_f
        } elseif {$ext eq ".v"} {
            set_global_assignment -name VERILOG_FILE $abs_f
        } else {
            puts "Warning: Unknown netlist extension '$ext' for $f — skipping"
        }
    }
}

export_assignments
project_close
puts "Altera project $g_project_name generated successfully."
