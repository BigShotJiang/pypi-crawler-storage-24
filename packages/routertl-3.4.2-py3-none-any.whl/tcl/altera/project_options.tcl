# Altera Project Options
# Tich (c) 2026

# Common Quartus assignments
set_global_assignment -name FAMILY "MAX 10"
set_global_assignment -name DEVICE $g_fpga_part
set_global_assignment -name ERROR_CHECK_FREQUENCY_DIVISOR 256
set_global_assignment -name EXTERNAL_FLASH_FALLBACK_ADDRESS 00000000
set_global_assignment -name USE_CONFIGURATION_DEVICE OFF
set_global_assignment -name INTERNAL_FLASH_UPDATE_MODE "SINGLE IMAGE WITH ERAM"

# Optimization Settings
set_global_assignment -name OPTIMIZATION_MODE "BALANCED"
set_global_assignment -name VHDL_INPUT_VERSION VHDL_2008

puts "Altera project options applied."
