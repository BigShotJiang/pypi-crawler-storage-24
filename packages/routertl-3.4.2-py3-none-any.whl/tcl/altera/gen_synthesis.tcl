# Altera Synthesis Script
# Tich (c) 2026

if { $::argc > 0 } {
    set g_root_dir [lindex $argv 0]
} else {
    set g_root_dir [pwd]
}

set script_dir [file dirname [info script]]
source ${script_dir}/environment.tcl

package require ::quartus::project
package require ::quartus::flow

puts "Opening project $g_project_name..."
project_open $g_project_dir/$g_project_name -current_revision

# Source per-stage TCL hooks (from tcl_hooks.synthesis in project.yml)
if {[info exists g_synthesis_hooks]} {
    foreach hook $g_synthesis_hooks {
        set hook_path "$g_root_dir/$hook"
        if {[file exists $hook_path]} {
            puts "  Sourcing synthesis hook: $hook"
            source $hook_path
        } else {
            puts "  WARNING: synthesis hook not found: $hook_path"
        }
    }
}

puts "-----------------------------------------------------------------------"
puts "Running Analysis & Synthesis (quartus_map)..."
puts "  Edition: $g_quartus_edition"
puts "-----------------------------------------------------------------------"

if {[catch {execute_module -tool map} result]} {
    puts "ERROR: Analysis & Synthesis failed."
    puts "$result"
    project_close
    exit 1
}

project_close
puts "Synthesis completed successfully."

# ── RouteRTL Report Emitter ──────────────────────────────────
source ${script_dir}/report_emitter.tcl
emit_synthesis_report $g_root_dir $g_project_dir $g_project_name
