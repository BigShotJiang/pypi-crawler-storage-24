# RouteRTL — Query Licensed FPGA Devices (Altera / Intel)
# Invoked by: quartus_sh -t query_devices.tcl
#
# Output format (one line per entry, machine-parseable):
#   FAMILY:<family_name>
#   PART:<family_name>:<part_number>

package require ::quartus::device

foreach fam [lsort [get_family_list]] {
    puts "FAMILY:$fam"
    foreach dev [get_part_list -family $fam] {
        puts "PART:$fam:$dev"
    }
}
