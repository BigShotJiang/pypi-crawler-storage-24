# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/checks.py
"""Queue-draining helpers for monitor-based verification.

Each function extracts captured words from a monitor's async queue
into a plain Python list, using different consumption strategies.
"""

from typing import List

from cocotb.triggers import RisingEdge


async def queue_to_list_n(csmon, n: int, per_item_timeout_cycles: int = 10_000) -> List[int]:
    """Grab exactly *n* words from a monitor queue.

    Parameters
    ----------
    csmon : monitor
        Monitor with an async ``get(timeout_cycles=...)`` method.
    n : int
        Number of words to collect.
    per_item_timeout_cycles : int
        Max cycles to wait for each individual word. Default ``10_000``.

    Returns
    -------
    list[int]
        Collected words in arrival order.
    """
    out: List[int] = []
    for _ in range(n):
        sample = await csmon.get(timeout_cycles=per_item_timeout_cycles)
        out.append(sample.word)
    return out


async def queue_to_list_now(csmon) -> List[int]:
    """Drain all currently queued words without blocking.

    Returns
    -------
    list[int]
        Words that were already queued at call time.
    """
    out: List[int] = []
    while not csmon.q.empty():
        s = await csmon.q.get()  # safe: we checked .empty() first
        out.append(s.word)
    return out


async def queue_to_list_until_idle(csmon, idle_cycles: int = 20, max_cycles: int = 100_000) -> List[int]:
    """Drain words until the queue stays empty for *idle_cycles* in a row.

    Parameters
    ----------
    csmon : monitor
        Monitor with a ``q`` Queue and ``env.clk``.
    idle_cycles : int
        Consecutive empty cycles before returning. Default ``20``.
    max_cycles : int
        Absolute cycle limit to prevent hangs. Default ``100_000``.

    Returns
    -------
    list[int]
        All collected words.
    """
    out: List[int] = []
    idle = 0
    cycles = 0
    while cycles < max_cycles:
        # pull everything currently in the queue
        while not csmon.q.empty():
            s = await csmon.q.get()
            out.append(s.word)
            idle = 0  # activity seen, reset idle counter
        if idle >= idle_cycles:
            break
        idle += 1
        cycles += 1
        await RisingEdge(csmon.env.clk)
    return out
