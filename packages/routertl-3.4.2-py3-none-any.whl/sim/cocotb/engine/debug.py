# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# utils/debug.py  (or tb/debug.py)
from __future__ import annotations

from typing import Callable, Optional


def dump_hierarchy(
    hdl,
    log=None,  # env.log or any logger; if None, print()
    depth: Optional[int] = None,  # None = unlimited
    pred: Optional[Callable] = None,  # predicate(hdl) -> bool to filter nodes
    indent: str = "",
):
    """Recursively list HDL hierarchy from 'hdl' (usually 'dut')."""

    def _is_sig(x):
        return hasattr(x, "value")

    def _width(x):
        try:
            return x.value.n_bits
        except Exception:
            return None

    if pred and not pred(hdl):
        return

    kind = "sig" if _is_sig(hdl) else "inst"
    w = _width(hdl)
    line = f"{indent}{hdl._name} ({kind}) -> {hdl._path}" + (f" [{w}-bit]" if w else "")
    if log:
        log.info(line)
    else:
        print(line)

    if depth is not None and depth <= 0:
        return

    next_depth = None if depth is None else depth - 1
    for child in hdl:
        dump_hierarchy(child, log=log, depth=next_depth, pred=pred, indent=indent + "  ")
