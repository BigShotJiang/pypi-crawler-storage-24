# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Centralized path management for simulation infrastructure.

This module provides a single source of truth for all path references
across the simulation framework, eliminating path duplication and
making the project structure easier to maintain.
"""

import os
from pathlib import Path

# ============================================================================
# Core Project Paths (Single Source of Truth)
# ============================================================================

_THIS_FILE = Path(__file__).resolve()
"""Absolute path to this module."""

COCOTB_ROOT = _THIS_FILE.parent.parent
"""Root of sim/cocotb directory."""

# Project Root Resolution:
# Priority: 1. $CLIENT_PROJECT_ROOT env var (explicit)
#           2. Auto-detect by walking up from CWD for project.yml
#           3. Fall back to SDK structure (COCOTB_ROOT.parent.parent)
_client_root = os.environ.get("CLIENT_PROJECT_ROOT")
if _client_root:
    PROJECT_ROOT = Path(_client_root).resolve()
else:
    # Auto-detect: walk up from CWD looking for project.yml
    _cwd = Path.cwd()
    _detected = None
    for _parent in [_cwd] + list(_cwd.parents):
        if (_parent / "project.yml").exists():
            _detected = _parent
            break
    if _detected:
        PROJECT_ROOT = _detected
    else:
        PROJECT_ROOT = COCOTB_ROOT.parent.parent
        # Warn if this resolves inside vendor/ (client project context)
        if "vendor" in str(COCOTB_ROOT):
            import warnings

            warnings.warn(
                "PROJECT_ROOT resolved to SDK directory. "
                "Set CLIENT_PROJECT_ROOT to your project root, "
                "or run from a directory containing project.yml.",
                stacklevel=2,
            )
"""Root of the entire project (Client or SDK)."""

SDK_ROOT = COCOTB_ROOT.parent.parent
"""Root of the SDK (resolved via __file__ traversal)."""

SRC_PATH = PROJECT_ROOT / "src"
"""HDL source code directory (Project)."""

SDK_SRC_PATH = SDK_ROOT / "src"
"""HDL source code directory (SDK)."""

SIM_PATH = PROJECT_ROOT / "sim"
"""Simulation infrastructure directory."""

TESTS_PATH = COCOTB_ROOT / "tests"
"""Test files directory."""

UTILS_PATH = COCOTB_ROOT / "utils"
"""Utilities directory."""

# ============================================================================
# Vendor Library Paths
# ============================================================================

LIBS_PATH = PROJECT_ROOT / "libs"
"""Libraries directory."""

XIL_PATH = SIM_PATH / "unisim"
"""Xilinx UNISIM simulation library (resolved dynamically)."""

# Dynamic resolution: prefer in-repo, then system cache
_unisim_cache = Path.home() / ".routertl" / "vendor_libs" / "unisim"
if not (XIL_PATH.is_dir() and any(XIL_PATH.glob("*.vhd"))):
    if _unisim_cache.is_dir() and any(_unisim_cache.glob("*.vhd")):
        XIL_PATH = _unisim_cache


XPM_PATH = LIBS_PATH / "xpm_vhdl" / "src" / "xpm"
"""Xilinx XPM (Xilinx Parameterized Macros) library."""

# ============================================================================
# Build/Output Directories
# ============================================================================

# Build Root Resolution:
# Priority: 1. $CLIENT_SIM_WORK env var (explicit)
#           2. Client project auto-redirect (sim/work/ in project root)
#           3. SDK default (COCOTB_ROOT/build)
_client_work = os.environ.get("CLIENT_SIM_WORK")
if _client_work:
    BUILD_ROOT = Path(_client_work).resolve()
elif PROJECT_ROOT != SDK_ROOT:
    # Client project: build outside the SDK submodule
    BUILD_ROOT = PROJECT_ROOT / "sim" / "work"
else:
    BUILD_ROOT = COCOTB_ROOT / "build"
"""Root build directory."""

GHDL_BUILD_DIR = BUILD_ROOT / "ghdl"
"""GHDL working directory for compiled libraries."""

NVC_BUILD_DIR = BUILD_ROOT / "nvc"
"""NVC working directory for compiled libraries."""

VERILATOR_BUILD_DIR = BUILD_ROOT / "verilator"
"""Verilator working directory for compiled artifacts."""

RIVIERA_BUILD_DIR = BUILD_ROOT / "riviera"
"""Riviera-PRO working directory for compiled artifacts."""

QUESTA_BUILD_DIR = BUILD_ROOT / "questa"
"""Questa working directory for compiled artifacts."""

XCELIUM_BUILD_DIR = BUILD_ROOT / "xcelium"
"""Xcelium working directory for compiled artifacts."""

ACTIVEHDL_BUILD_DIR = BUILD_ROOT / "activehdl"
"""Active-HDL working directory for compiled artifacts."""

ICARUS_BUILD_DIR = BUILD_ROOT / "icarus"
"""Icarus Verilog working directory for compiled artifacts."""

# Simulation output directories.
# Priority: 1. Environment variable (set by Common.mk from project.yml)
#           2. Client-project-aware default
_default_waves = (PROJECT_ROOT / "sim" / "waves") if PROJECT_ROOT != SDK_ROOT else (COCOTB_ROOT / "waves")
WAVES_DIR = Path(os.environ.get("ROUTERTL_WAVES_DIR", str(_default_waves)))
"""Waveform output directory."""

_default_logs = (PROJECT_ROOT / "sim" / "logs") if PROJECT_ROOT != SDK_ROOT else (COCOTB_ROOT / "logs")
LOGS_DIR = Path(os.environ.get("ROUTERTL_LOGS_DIR", str(_default_logs)))
"""Simulation log directory."""

_default_results = (PROJECT_ROOT / "sim" / "results") if PROJECT_ROOT != SDK_ROOT else (COCOTB_ROOT / "results")
RESULTS_DIR = Path(os.environ.get("ROUTERTL_RESULTS_DIR", str(_default_results)))
"""Simulation results directory (JUnit XML + JSON history)."""

GENERATED_DIR = COCOTB_ROOT / "generated"
"""Generated artifacts directory."""

# ============================================================================
# Configuration (from environment with defaults)
# ============================================================================

VHDL_STD = os.environ.get("VHDL_STD", "08")
"""VHDL standard version: 93, 02, 08, or 19. Default: 08."""

COCOTB_VERBOSE = os.environ.get("COCOTB_VERBOSE", "0") == "1"
"""Enable verbose output. Set COCOTB_VERBOSE=1 to enable."""

NVC_PRESERVE_CASE = os.environ.get("NVC_PRESERVE_CASE", "0") == "1"
"""Preserve case in NVC identifiers. Set NVC_PRESERVE_CASE=1 to enable."""

# ============================================================================
# Helper Functions
# ============================================================================


def get_build_dir_for_simulator(simulator_name: str) -> Path:
    """
    Get the build directory for a specific simulator.

    Args:
        simulator_name: Either 'ghdl' or 'nvc'

    Returns:
        Path to the build directory for that simulator

    Raises:
        ValueError: If simulator_name is not recognized
    """
    simulator_name = simulator_name.lower()
    if simulator_name == "ghdl":
        return GHDL_BUILD_DIR
    elif simulator_name == "nvc":
        return NVC_BUILD_DIR
    elif simulator_name == "verilator":
        return VERILATOR_BUILD_DIR
    elif simulator_name == "riviera":
        return RIVIERA_BUILD_DIR
    elif simulator_name == "questa":
        return QUESTA_BUILD_DIR
    elif simulator_name == "xcelium":
        return XCELIUM_BUILD_DIR
    elif simulator_name == "activehdl":
        return ACTIVEHDL_BUILD_DIR
    elif simulator_name == "icarus":
        return ICARUS_BUILD_DIR
    else:
        raise ValueError(f"Unknown simulator: {simulator_name}")


def ensure_dir(path: Path) -> Path:
    """
    Ensure a directory exists, creating it if necessary.

    Args:
        path: Directory path to create

    Returns:
        The path object (for chaining)
    """
    path.mkdir(parents=True, exist_ok=True)
    return path
