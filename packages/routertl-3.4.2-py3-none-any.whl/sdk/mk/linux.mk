# === RouteRTL SDK — Embedded Linux Targets ===
# Requires: platform.mk (SDK_ROOT, ROOT_DIR, LINUX_UTILS, SYSTEM_MMAP, etc.)

# ====================================================================================
# 🐧 Embedded Linux
# ====================================================================================

# Parse Target from system_memory_map.yml to set cross-toolchains
ifeq ($(wildcard $(SYSTEM_MMAP)),)
  LINUX_TARGET := zynq-7000
  LINUX_ARCH := arm
  LINUX_CROSS_COMPILE := arm-linux-gnueabihf-
else
  $(eval $(shell python3 $(LINUX_UTILS)/get_target_config.py $(SYSTEM_MMAP) $(LINUX_UTILS)/supported_targets.yml))
endif

.PHONY: gen-linux-all gen-dtbo gen-uio-header gen-uio-bindings update-mmap crosscheck-hw linux-help
.PHONY: build-fsbl build-uboot build-kernel build-sdcard export-xsa

linux-help: ## Show help for Embedded Linux integration and system_memory_map.yml
	@echo "======================================================================"
	@echo "🐧 Embedded Linux Integration Help"
	@echo "======================================================================"
	@echo "The RouteRTL SDK relies on a 'system_memory_map.yml' file in your"
	@echo "project root to generate Linux software artifacts."
	@echo ""
	@echo "Basic Template:"
	@echo "  version: \"1.0.0\""
	@echo "  target: zynq-7000          # Required. Must be: zynq-7000, zynqmp, cyclone-v-soc, polarfire-soc"
	@echo "  devices:"
	@echo "    - name: system_regs      # Name of the IP block"
	@echo "      base_addr: 0x43C00000  # AXI memory-mapped base address"
	@echo "      span: 0x10000          # Size of address space in bytes"
	@echo ""
	@echo "For full details, see docs/embedded-linux/USER_GUIDE.md"
	@echo "======================================================================"

crosscheck-hw: ## Cross-check system_memory_map.yml against Vivado XSA hardware truth
	@HW_PATH=$(build_path)/$(PROJECT_NAME)$(HW_HANDOFF_EXT); \
	if [ -f $(SYSTEM_MMAP) ] && [ -f $$HW_PATH ]; then \
		$(HW_CROSSCHECK_SCRIPT) $(SYSTEM_MMAP) $$HW_PATH; \
	elif [ ! -f $$HW_PATH ]; then \
		echo "❌ Error: HW not exported. Expected handoff file at $$HW_PATH"; \
		exit 1; \
	else \
		echo "❌ Error: $(SYSTEM_MMAP) not found."; \
		exit 1; \
	fi

EXPORT_XSA_TCL ?= $(SDK_ROOT)/tcl/$(VENDOR)/export_xsa.tcl

export-xsa: ## Export Vivado Hardware Platform (.xsa) from implementation checkpoint
	@if [ "$(VENDOR)" != "xilinx" ]; then \
		echo "❌ XSA export is only supported for Xilinx/AMD projects."; \
		exit 1; \
	fi
	@if [ ! -f $(ROOT_DIR)/dcp/implementation.dcp ]; then \
		echo "❌ No implementation checkpoint found. Run 'rr implementation' first."; \
		exit 1; \
	fi
	@echo "📦 Exporting XSA Hardware Platform..."
	@$(VIVADO_XLNX) $(EXPORT_XSA_TCL) -tclargs $(ROOT_DIR)

fetch-sw: ## Fetch custom software repositories
	@bash $(SDK_ROOT)/sdk/scripts/fetch_sw_repos.sh

build-bsp: ## Generate Board Support Package (xparameters.h) via XSCT
	@FSBL_REPO="$(FSBL_REPO)" bash $(SDK_ROOT)/sdk/scripts/build_bsp.sh

build-dtb: ## Generate Base Device Tree (system.dtb) via XSCT
	@bash $(SDK_ROOT)/sdk/scripts/build_dtb.sh

HW_CROSSCHECK_SCRIPT = python3 $(LINUX_UTILS)/xsa_parser.py
FSBL_COMMAND = ARCH=$(LINUX_ARCH) CROSS_COMPILE=$(LINUX_CROSS_COMPILE) FSBL_REPO="$(FSBL_REPO)" bash $(SDK_ROOT)/sdk/scripts/build_fsbl.sh

build-fsbl: fetch-sw build-bsp ## Build FSBL from vendor sources
	@$(FSBL_COMMAND)

build-uboot: fetch-sw ## Build U-Boot from vendor sources
ifeq ($(VENDOR), altera)
	@echo "ℹ️  Intel SoC FPGA target: Please ensure UBOOT_DEFCONFIG is set to a socfpga configuration."
endif
	@ARCH=$(LINUX_ARCH) CROSS_COMPILE=$(LINUX_CROSS_COMPILE) bash $(SDK_ROOT)/sdk/scripts/build_uboot.sh

build-kernel: fetch-sw ## Build Linux Kernel from Xilinx linux-xlnx
	@ARCH=$(LINUX_ARCH) CROSS_COMPILE=$(LINUX_CROSS_COMPILE) bash $(SDK_ROOT)/sdk/scripts/build_kernel.sh

build-bootscr: ## Compile U-Boot boot script (boot.txt -> boot.scr)
	@BOOT_SCRIPT="$(BOOT_SCRIPT)" ARCH=$(LINUX_ARCH) bash $(SDK_ROOT)/sdk/scripts/build_bootscr.sh

build-sdcard: ## Assemble BOOT.bin and SD Card image
	@bash $(SDK_ROOT)/sdk/scripts/build_sdcard.sh

gen-linux-all: gen-dtbo gen-uio-header gen-uio-bindings ## Generate all Linux artifacts (DTS, C, Python)

gen-dtbo: ## Generate Device Tree Overlay (.dts)
	@if [ -f $(SYSTEM_MMAP) ]; then \
		echo "Generating DTS overlay..."; \
		mkdir -p $(LINUX_DIR)/dtbo; \
		python3 $(LINUX_UTILS)/generate_dtbo.py $(SYSTEM_MMAP) -o $(LINUX_DIR)/dtbo/$(PROJECT_NAME)_overlay.dts; \
	fi

gen-uio-header: ## Generate C UIO headers
	@if [ -f $(SYSTEM_MMAP) ]; then \
		echo "Generating C UIO headers..."; \
		mkdir -p $(LINUX_DIR)/include; \
		python3 $(LINUX_UTILS)/generate_uio_header.py $(SYSTEM_MMAP) -o $(LINUX_DIR)/include; \
	fi

gen-uio-bindings: ## Generate completely Python-wrapped UIO Drivers
	@if [ -f $(SYSTEM_MMAP) ]; then \
		echo "Generating Python UIO drivers..."; \
		mkdir -p $(LINUX_DIR)/python; \
		python3 $(LINUX_UTILS)/generate_uio_bindings.py $(SYSTEM_MMAP) -o $(LINUX_DIR)/python; \
	fi

gen-xdc-template: ## Generate XDC constraint template (Usage: make gen-xdc-template TOP=module)
	@if [ -z "$(TOP)" ]; then \
		echo "❌ Error: TOP not specified. Use 'make gen-xdc-template TOP=my_entity'"; \
		exit 1; \
	fi
	@mkdir -p $(XDC_DIR)
	@python3 $(SDK_ROOT)/sdk/generators/constraints/gen_template.py --src $(SRC_DIR) --top $(TOP) --out $(XDC_DIR)/$(TOP)_timing.xdc

update-mmap: ## Update Vivado block design address map from system_memory_map.yml
	@if [ -f $(SYSTEM_MMAP) ]; then \
		echo "Updating Vivado address map..."; \
		mkdir -p $(LINUX_DIR)/tcl; \
		python3 $(LINUX_UTILS)/generate_address_tcl.py $(SYSTEM_MMAP) -o $(LINUX_DIR)/tcl/update_address_map.tcl; \
		if [ -f $(vivado_prj) ]; then \
			$(VIVADO_XLNX) $(LINUX_DIR)/tcl/update_address_map.tcl -tclargs $(vivado_prj); \
		else \
			echo "⚠️  Vivado project not found at $(vivado_prj). Only TCL generated."; \
		fi \
	else \
		echo "❌ Error: $(SYSTEM_MMAP) not found."; \
		exit 1; \
	fi
