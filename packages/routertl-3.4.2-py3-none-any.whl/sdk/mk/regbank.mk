# === RouteRTL SDK — Register Bank & ROM Targets ===
# Requires: platform.mk (SDK_ROOT, ROOT_DIR, SRC_DIR, REGBANK_UTILS, etc.)

# ====================================================================================
# 📚 Register Bank & ROM
# ====================================================================================
REGBANK_YAML    ?= project_regbank.yml
REGBANK_PKG     ?= $(SRC_DIR)/pkg/system_regbank_pkg.vhd
ROM_DATA        ?= misc/rom.data

# If the project doesn't have a regbank yaml, we might skip this or error?
# For now, we assume if REGBANK_YAML exists, we use it.

.PHONY: parse_regbank
parse_regbank: ## Generate VHDL package from Regbank YAML
	@if [ -f $(REGBANK_YAML) ]; then \
		echo "Parsing $(REGBANK_YAML)..."; \
		python3 $(REGBANK_UTILS)/generate_regbank_pkg.py $(REGBANK_YAML) $(REGBANK_PKG); \
	else \
		echo "No register bank YAML found at $(REGBANK_YAML). Skipping."; \
	fi

.PHONY: add-register
add-register: ## Add a new register to the register bank (interactive)
	@python3 $(REGBANK_UTILS)/add_register.py $(REGBANK_YAML)

.PHONY: remove-register
remove-register: ## Remove a register from the register bank (Usage: make remove-register NAME=reg_name)
	@if [ -z "$(NAME)" ]; then \
		echo "❌ Error: NAME not specified. Use 'make remove-register NAME=reg_name'"; \
		exit 1; \
	fi
	@python3 $(REGBANK_UTILS)/remove_register.py $(REGBANK_YAML) $(NAME)

.PHONY: rom_info
rom_info: $(SRC_DIR)/pkg/rom_info_pkg.vhd ## Generate ROM Data & Package

# ROM Data Generation Dependencies
REGBANK_HEX      ?= $(SRC_DIR)/regbank/regbank_schema.hex
CONFIG_HEX       ?= $(SRC_DIR)/regbank/config_schema.hex
SYS_CONFIG_RTL   ?= $(SRC_DIR)/pkg/system_config_pkg$(HDL_EXT)
REGBANK_CONST_PY ?= $(VERIFICATION_DIR)/constants.py

misc/rom.data: $(REGBANK_YAML) $(REGBANK_HEX) $(CONFIG_HEX) $(SYS_CONFIG_RTL)
	@mkdir -p misc
	@echo "Generating ROM data..."
	@# create_rom.sh usage: root_dir constants_file regbank_yml regbank_hex config_hex
	@bash $(SDK_ROOT)/sdk/scripts/create_rom.sh $(ROOT_DIR) $@ $(REGBANK_YAML) $(REGBANK_HEX) $(CONFIG_HEX)
	@echo "Generating Python constants..."
	@python3 $(REGBANK_UTILS)/generate_constants.py $(REGBANK_YAML) $(REGBANK_CONST_PY)

$(SRC_DIR)/pkg/rom_info_pkg.vhd: misc/rom.data
	@# gen_info_pkg.py usage: root_dir rom_data config_hex
	@python3 $(REGBANK_UTILS)/gen_info_pkg.py $(ROOT_DIR) $< $(CONFIG_HEX)

# Trigger rom_info always to ensure version stamping
# Trigger parse_regbank always (it self-checks for yaml existence)
ifeq ($(CONFIG_ENABLE_REGBANK), true)
REGBANK_DEPS := rom_info parse_regbank
else
REGBANK_DEPS :=
endif
