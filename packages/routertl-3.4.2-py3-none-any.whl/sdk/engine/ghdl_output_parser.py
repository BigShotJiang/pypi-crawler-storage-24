#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
GHDL Output Parser
==================
Parses GHDL linting output and presents it in a clean, organized format.
Groups errors by file, deduplicates messages, and provides clear summaries.
"""

import re
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from sdk.cli.console import console as _ghdl_con


@dataclass
class GHDLMessage:
    """Represents a single GHDL error or warning message."""

    file_path: str
    line: int
    column: int
    level: str  # 'error', 'warning', 'note'
    message: str
    context_line: Optional[str] = None
    pointer_line: Optional[str] = None

    def __hash__(self):
        return hash((self.file_path, self.line, self.column, self.level, self.message))

    def __eq__(self, other):
        if not isinstance(other, GHDLMessage):
            return False
        return (
            self.file_path == other.file_path
            and self.line == other.line
            and self.column == other.column
            and self.level == other.level
            and self.message == other.message
        )


@dataclass
class ParsedOutput:
    """Container for parsed GHDL output."""

    messages: List[GHDLMessage] = field(default_factory=list)
    raw_errors: List[str] = field(default_factory=list)

    @property
    def error_count(self) -> int:
        """Return the total number of parsed errors (including raw GHDL errors)."""
        return sum(1 for m in self.messages if m.level == "error") + len(self.raw_errors)

    @property
    def warning_count(self) -> int:
        """Return the total number of parsed warnings."""
        return sum(1 for m in self.messages if m.level == "warning")


class GHDLOutputParser:
    """Parses GHDL output and formats it for cleaner presentation."""

    # Pattern matches: /path/file.vhd:16:9:error: message text
    MESSAGE_PATTERN = re.compile(
        r"^(?P<file>[^:]+):(?P<line>\d+):(?P<col>\d+):(?P<level>error|warning|note):\s*(?P<msg>.+)$"
    )

    # Pattern for ghdl executable error lines (e.g. /usr/bin/ghdl:error: ...)
    GHDL_ERROR_PATTERN = re.compile(r"^.*/ghdl:error:\s*(.+)$")

    # Pattern for unrecognized error-like lines that neither regex above
    # would catch (e.g. "cannot open ...", GHDL stderr messages with
    # non-standard format).  Used as a safety net.
    UNRECOGNIZED_ERROR_RE = re.compile(r"(?i)\b(error|cannot|fatal|failed to)\b")

    def __init__(self, project_root: Optional[str] = None):
        """Create a GHDL output parser."""
        self.project_root = Path(project_root) if project_root else None

    def _shorten_path(self, filepath: str) -> str:
        """Shorten file path relative to project root for cleaner display."""
        try:
            path = Path(filepath)
            if self.project_root and path.is_absolute():
                try:
                    return str(path.relative_to(self.project_root))
                except ValueError:
                    pass
            return filepath
        except (ValueError, IndexError):
            import logging

            logging.debug("Path shortening failed for %s", filepath, exc_info=True)
            return filepath

    def parse(self, output: str) -> ParsedOutput:
        """Parse GHDL output and extract structured messages."""
        result = ParsedOutput()
        lines = output.strip().split("\n")

        i = 0
        while i < len(lines):
            line = lines[i].strip()

            # Check for GHDL executable errors
            ghdl_match = self.GHDL_ERROR_PATTERN.match(line)
            if ghdl_match:
                result.raw_errors.append(ghdl_match.group(1))
                i += 1
                continue

            # Check for standard message format
            match = self.MESSAGE_PATTERN.match(line)
            if match:
                msg = GHDLMessage(
                    file_path=match.group("file"),
                    line=int(match.group("line")),
                    column=int(match.group("col")),
                    level=match.group("level"),
                    message=match.group("msg"),
                )

                # Look ahead for context lines (source code + pointer)
                if i + 1 < len(lines) and not self.MESSAGE_PATTERN.match(lines[i + 1]):
                    # Next line might be source context
                    potential_context = lines[i + 1]
                    if not potential_context.startswith("/") and not self.GHDL_ERROR_PATTERN.match(potential_context):
                        msg.context_line = potential_context
                        i += 1

                        # And the line after might be the pointer
                        if i + 1 < len(lines):
                            potential_pointer = lines[i + 1]
                            if "^" in potential_pointer and not self.MESSAGE_PATTERN.match(potential_pointer):
                                msg.pointer_line = potential_pointer
                                i += 1

                result.messages.append(msg)
            elif line and self.UNRECOGNIZED_ERROR_RE.search(line):
                # Safety net: capture error-like lines that matched
                # neither the standard message nor the ghdl:error pattern
                result.raw_errors.append(line)

            i += 1

        return result

    def deduplicate(self, parsed: ParsedOutput) -> ParsedOutput:
        """Remove duplicate messages (often GHDL reports same error multiple times)."""
        seen = set()
        unique_messages = []

        for msg in parsed.messages:
            if msg not in seen:
                seen.add(msg)
                unique_messages.append(msg)

        return ParsedOutput(messages=unique_messages, raw_errors=list(set(parsed.raw_errors)))

    def format_output(self, parsed: ParsedOutput, show_context: bool = True) -> str:
        """Format parsed output for terminal display using Rich markup."""
        if not parsed.messages and not parsed.raw_errors:
            return "[green]✓ No issues found[/]"

        output_lines = []

        # Render raw GHDL errors (file-not-found, missing library, etc.)
        if parsed.raw_errors:
            output_lines.append("")
            output_lines.append("[bold red]⚙ GHDL Errors[/]")
            for err in parsed.raw_errors:
                output_lines.append(f"  [red]✗ {err}[/]")

        # Group messages by file
        by_file = defaultdict(list)
        for msg in parsed.messages:
            by_file[msg.file_path].append(msg)

        # Sort files and messages within files by line number
        for filepath in sorted(by_file.keys()):
            messages = sorted(by_file[filepath], key=lambda m: (m.line, m.column))
            short_path = self._shorten_path(filepath)

            # File header
            output_lines.append("")
            output_lines.append(f"[bold white]╭─ {short_path}[/]")

            for msg in messages:
                # Determine color based on level
                if msg.level == "error":
                    level_color = "red"
                    icon = "✗"
                elif msg.level == "warning":
                    level_color = "yellow"
                    icon = "⚠"
                else:
                    level_color = "cyan"
                    icon = "ℹ"

                # Location and message
                location = f"L{msg.line}:{msg.column}"
                output_lines.append(
                    f"[dim]│[/]  [{level_color}]{icon} [bold]{location}[/bold] "
                    f"{msg.message}[/{level_color}]"
                )

                # Show context if available
                if show_context and msg.context_line:
                    # Indent context
                    output_lines.append(f"[dim]│     {msg.context_line.rstrip()}[/]")
                    if msg.pointer_line:
                        output_lines.append(f"[dim]│     [red]{msg.pointer_line.rstrip()}[/red][/]")

            output_lines.append(f"[dim]╰{'─' * 40}[/]")

        # Summary
        output_lines.append("")
        error_count = parsed.error_count
        warning_count = parsed.warning_count

        if error_count > 0:
            output_lines.append(
                f"[red bold]✗ {error_count} error{'s' if error_count != 1 else ''}[/]"
                + (
                    f"[yellow] • {warning_count} warning{'s' if warning_count != 1 else ''}[/]"
                    if warning_count > 0
                    else ""
                )
            )
        elif warning_count > 0:
            output_lines.append(
                f"[yellow]⚠ {warning_count} warning{'s' if warning_count != 1 else ''}[/]"
            )

        return "\n".join(output_lines)


def parse_and_format(
    raw_output: str, project_root: Optional[str] = None, show_context: bool = True, dedupe: bool = True
) -> tuple[str, int]:
    """
    Main entry point for parsing GHDL output.

    Args:
        raw_output: Raw GHDL stderr/stdout text
        project_root: Project root for path shortening
        show_context: Whether to show source context lines
        dedupe: Whether to deduplicate repeated messages

    Returns:
        Tuple of (formatted_output, exit_code)
    """
    parser = GHDLOutputParser(project_root)
    parsed = parser.parse(raw_output)

    if dedupe:
        parsed = parser.deduplicate(parsed)

    formatted = parser.format_output(parsed, show_context)
    exit_code = 1 if parsed.error_count > 0 else 0

    return formatted, exit_code


def main():
    """Read from stdin and output formatted result."""
    import argparse

    arg_parser = argparse.ArgumentParser(description="Parse GHDL output for cleaner display")
    arg_parser.add_argument("--root", help="Project root directory for path shortening")
    arg_parser.add_argument("--no-context", action="store_true", help="Don't show source context")
    arg_parser.add_argument("--no-dedupe", action="store_true", help="Don't deduplicate messages")

    args = arg_parser.parse_args()

    # Read from stdin
    raw_input = sys.stdin.read()

    formatted, exit_code = parse_and_format(
        raw_input, project_root=args.root, show_context=not args.no_context, dedupe=not args.no_dedupe
    )

    _ghdl_con.print(formatted)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
