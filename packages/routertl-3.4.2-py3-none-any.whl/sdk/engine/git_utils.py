# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Git-aware utilities for RouteRTL SDK tooling."""

import os
import subprocess
from pathlib import Path

# Environment variables set by git when running hooks.  These can poison
# ``git rev-parse --show-toplevel`` (returning the subprocess CWD instead
# of the real worktree root), so we strip them before calling git.
_GIT_HOOK_ENV_VARS = ("GIT_DIR", "GIT_INDEX_FILE", "GIT_WORK_TREE")


def _clean_git_env():
    """Return a copy of ``os.environ`` without git-hook variables."""
    return {k: v for k, v in os.environ.items() if k not in _GIT_HOOK_ENV_VARS}


def filter_git_tracked(files, repo_root=None):
    """Return only files that are tracked by git.

    Runs ``git ls-files`` on *repo_root* (or the first file's parent if
    *repo_root* is ``None``) and intersects the result with *files*.

    **Fail-open**: if ``git`` is not available or the directory is not a
    git repository, every file in *files* is returned unchanged.  This
    ensures non-git contexts (tarballs, CI without ``.git``) keep working.

    Parameters
    ----------
    files : list[Path]
        Candidate file paths (absolute or relative).
    repo_root : Path | None
        Root of the git repository.  When ``None``, auto-detected via
        ``git rev-parse --show-toplevel``.

    Returns
    -------
    list[Path]
        Subset of *files* that ``git ls-files`` reports as tracked.
    """
    if not files:
        return []

    # Strip git-hook env vars so rev-parse resolves from the filesystem,
    # not from an inherited GIT_DIR that points at the gitdir rather than
    # the worktree.
    env = _clean_git_env()

    try:
        # Resolve repo root
        if repo_root is None:
            result = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                capture_output=True,
                text=True,
                cwd=str(files[0].parent),
                env=env,
            )
            if result.returncode != 0:
                return list(files)  # fail-open
            repo_root = Path(result.stdout.strip())
        else:
            repo_root = Path(repo_root).resolve()

        # Get the set of tracked files (relative to repo root)
        result = subprocess.run(
            ["git", "ls-files"],
            capture_output=True,
            text=True,
            cwd=str(repo_root),
            env=env,
        )
        if result.returncode != 0:
            return list(files)  # fail-open

        tracked = set()
        for line in result.stdout.splitlines():
            tracked.add((repo_root / line).resolve())

        # Filter input files
        return [f for f in files if f.resolve() in tracked]

    except (FileNotFoundError, OSError):
        # git not installed or other OS error — fail-open
        return list(files)
