# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Project initialization sub-package.

Extracted from the monolithic init_project.py (1,057 lines) as part of P2.67.

Modules:
    scaffold   — project.yml, Makefile, .gitignore, VERSION, regbank generation
    venv       — venv setup, resilient wrapper, branding, shell completion
    templates  — template discovery, listing, and application
    env_check  — environment validation and Git LFS auto-pull
"""

# ── Re-exports for backward compatibility ──
# Tests and other callers import these from `init_project` (which re-exports
# from this package). Keep the public surface stable.

from sdk.engine.init.env_check import _check_lfs, check_environment
from sdk.engine.init.scaffold import (
    PYPROJECT_TEMPLATE,
    TEMPLATE,
    _generate_pyproject_toml,
    _scaffold_project,
)
from sdk.engine.init.templates import _apply_template, _discover_templates, _list_templates
from sdk.engine.init.venv import (
    _COMP_SENTINEL_END,
    _COMP_SENTINEL_START,
    _create_branded_symlink,
    _create_shortcut_alias,
    _detect_shell,
    _hook_shell_completion,
    _install_resilient_wrapper,
    setup_python_env,
)

__all__ = [
    # scaffold
    "TEMPLATE",
    "PYPROJECT_TEMPLATE",
    "_generate_pyproject_toml",
    "_scaffold_project",
    # venv
    "setup_python_env",
    "_install_resilient_wrapper",
    "_create_branded_symlink",
    "_create_shortcut_alias",
    "_detect_shell",
    "_hook_shell_completion",
    "_COMP_SENTINEL_START",
    "_COMP_SENTINEL_END",
    # templates
    "_discover_templates",
    "_list_templates",
    "_apply_template",
    # env_check
    "check_environment",
    "_check_lfs",
]
