#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import argparse
from pathlib import Path


def scan_tests(search_dirs):
    """
    Scans given directories for Cocotb test files (test_*.py).
    Returns a list of (module_name, file_path) tuples.
    """
    tests = []
    seen_modules = set()

    print(f"\n🔍 Scanning for Cocotb tests in: {', '.join(str(d) for d in search_dirs)}\n")
    print(f"{'MODULE':<35} {'LOCATION':<55} {'COMMAND'}")
    print("-" * 130)

    for root_dir in search_dirs:
        root_path = Path(root_dir).resolve()
        if not root_path.exists():
            continue

        for path in root_path.rglob("test_*.py"):
            short_name = path.stem  # e.g., test_uart_sniffer

            if short_name in seen_modules:
                continue
            seen_modules.add(short_name)

            # Show relative location for context
            try:
                rel_location = path.relative_to(root_path.parent.parent)
            except ValueError:
                rel_location = path.name

            cmd = f"routertl sim {short_name}"
            print(f"{short_name:<35} {str(rel_location):<55} {cmd}")
            tests.append((short_name, cmd))

    print("-" * 130)
    print(f"✅ Found {len(tests)} tests.\n")


def main():
    """CLI entry point for test scanner."""
    parser = argparse.ArgumentParser(description="Scan for Cocotb tests.")
    parser.add_argument("--dirs", nargs="+", help="Directories to scan", required=True)
    args = parser.parse_args()

    scan_tests(args.dirs)


if __name__ == "__main__":
    main()
