# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
IP Manifest Resolver for RouteRTL SDK.

Parses ip.yml manifests, validates vendor compatibility, resolves
recursive IP-to-IP dependencies, and classifies files by synthesis mode.
"""

import logging
import os
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

import yaml

logger = logging.getLogger(__name__)

# ── Valid synthesis modes ──────────────────────────────────────
VALID_MODES = {"rtl", "xci", "qsys", "ipx", "cxz", "netlist", "ooc_dcp"}

# Vendor → which modes are legal
VENDOR_MODES = {
    "xilinx": {"rtl", "xci", "netlist", "ooc_dcp"},
    "altera": {"rtl", "qsys", "netlist"},
    "lattice": {"rtl", "ipx", "netlist"},
    "microchip": {"rtl", "cxz", "netlist"},
}

# Mode → human-readable description
MODE_DESCRIPTIONS = {
    "rtl": "RTL sources (compiled with top)",
    "xci": "Xilinx IP Catalog entry (.xci)",
    "qsys": "Intel Platform Designer entry (.qsys)",
    "ipx": "Lattice Radiant IP entry (.ipx)",
    "cxz": "Microchip Libero SmartDesign (.cxz)",
    "netlist": "Pre-compiled netlist (.edf/.ngc)",
    "ooc_dcp": "Xilinx Out-of-Context checkpoint (.dcp)",
}


@dataclass
class IpManifest:
    """Parsed representation of a single ip.yml file."""

    name: str
    path: Path  # Absolute path to the ip.yml file
    ip_dir: Path  # Absolute path to the directory containing ip.yml
    mode: str  # Synthesis mode
    library: str  # VHDL library name
    language: str  # vhdl | systemverilog | mixed
    sources: List[str]  # Absolute paths to source/IP files
    source_scan_dir: Optional[str]  # Relative scan dir from paths.sources
    dependencies: List[str] = field(default_factory=list)  # e.g. ["routertl/fifo_xpm_async"]
    children: List["IpManifest"] = field(default_factory=list)

    @property
    def source_count(self) -> int:
        """Return the number of source files in this IP."""
        return len(self.sources)


@dataclass
class IpResolutionResult:
    """Result of resolving all IPs from project.yml."""

    syn_files: List[str] = field(default_factory=list)
    xci_files: List[str] = field(default_factory=list)
    netlist_files: List[str] = field(default_factory=list)
    ooc_dcp_files: List[str] = field(default_factory=list)
    libraries: Dict[str, List[str]] = field(default_factory=dict)
    manifests: List[IpManifest] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class IpResolver:
    """
    Resolves ip.yml manifests referenced from project.yml.

    Validates vendor compatibility, resolves recursive IP dependencies,
    and classifies files into SYN_FILES, XCI_FILES, NETLIST_FILES, etc.
    """

    def __init__(self, project_root: Path, vendor: str):
        """Create an IP resolver for the given IP directory."""
        self.project_root = Path(project_root).resolve()
        self.vendor = vendor.lower()
        self._resolved_paths: Set[str] = set()  # Cycle detection (absolute paths)
        self._resolution_stack: List[str] = []  # For error messages

    def resolve(self, ip_yml_paths: List[str]) -> IpResolutionResult:
        """
        Resolve a list of ip.yml paths (relative to project root).

        Returns an IpResolutionResult with classified files and any errors.
        """
        result = IpResolutionResult()

        for ip_path_str in ip_yml_paths:
            ip_path = (self.project_root / ip_path_str).resolve()
            self._resolution_stack = []
            self._resolve_one(ip_path, result)

        return result

    def _resolve_one(self, ip_path: Path, result: IpResolutionResult) -> Optional[IpManifest]:
        """Resolve a single ip.yml, recursing into child IPs."""

        abs_key = str(ip_path)

        # ── Cycle detection ──
        if abs_key in self._resolution_stack:
            cycle = " → ".join(self._resolution_stack + [abs_key])
            result.errors.append(f"Circular IP dependency detected: {cycle}")
            return None

        # ── Deduplication ──
        if abs_key in self._resolved_paths:
            return None  # Already resolved, skip silently

        self._resolution_stack.append(abs_key)

        # ── Load YAML ──
        if not ip_path.exists():
            result.errors.append(
                f"IP manifest not found: {ip_path} "
                f"(referenced from {self._resolution_stack[-2] if len(self._resolution_stack) > 1 else 'project.yml'})"
            )
            self._resolution_stack.pop()
            return None

        try:
            with open(ip_path, "r") as f:
                data = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            result.errors.append(f"Failed to parse {ip_path}: {e}")
            self._resolution_stack.pop()
            return None

        # ── Validate schema ──
        manifest = self._validate_and_build(ip_path, data, result)
        if manifest is None:
            self._resolution_stack.pop()
            return None

        # ── Resolve child IPs first (depth-first) ──
        child_ips = data.get("ips", [])
        for child_path_str in child_ips:
            child_path = (manifest.ip_dir / child_path_str).resolve()
            child = self._resolve_one(child_path, result)
            if child is not None:
                manifest.children.append(child)

        # ── Classify this IP's files ──
        self._classify(manifest, result)

        self._resolved_paths.add(abs_key)
        result.manifests.append(manifest)
        self._resolution_stack.pop()
        return manifest

    def _validate_and_build(self, ip_path: Path, data: dict, result: IpResolutionResult) -> Optional[IpManifest]:
        """Validate ip.yml schema and build an IpManifest."""

        ip_dir = ip_path.parent
        ip_section = data.get("ip", {})

        # ── Required: ip.name ──
        name = ip_section.get("name")
        if not name:
            result.errors.append(f"Missing 'ip.name' in {ip_path}")
            return None

        # ── Synthesis section ──
        syn_section = data.get("synthesis", {})
        mode = syn_section.get("mode", "rtl")

        if mode not in VALID_MODES:
            result.errors.append(
                f"IP '{name}': invalid synthesis.mode '{mode}'. Valid modes: {', '.join(sorted(VALID_MODES))}"
            )
            return None

        # ── Vendor compatibility ──
        allowed = VENDOR_MODES.get(self.vendor, set())
        if mode not in allowed:
            result.errors.append(
                f"❌ IP '{name}' uses mode '{mode}' which is incompatible "
                f"with vendor '{self.vendor}'. "
                f"Allowed modes for {self.vendor}: {', '.join(sorted(allowed))}"
            )
            return None

        # ── Optional fields ──
        library = ip_section.get("library", "work")
        language = ip_section.get("language", "vhdl")

        # ── Paths ──
        paths_section = data.get("paths", {})
        source_scan_dir = paths_section.get("sources")

        # ── Sources ──
        raw_sources = syn_section.get("sources", [])
        abs_sources = []
        for src in raw_sources:
            abs_src = (ip_dir / src).resolve()
            abs_sources.append(str(abs_src))

        # ── Dependencies (P2.81) ──
        raw_deps = data.get("dependencies", [])
        if not isinstance(raw_deps, list):
            raw_deps = []

        return IpManifest(
            name=name,
            path=ip_path,
            ip_dir=ip_dir,
            mode=mode,
            library=library,
            language=language,
            sources=abs_sources,
            source_scan_dir=source_scan_dir,
            dependencies=raw_deps,
        )

    def _classify(self, manifest: IpManifest, result: IpResolutionResult):
        """Route an IP's sources into the correct output list."""

        # Convert absolute paths to project-relative for Make variables
        rel_sources = []
        for src in manifest.sources:
            try:
                rel = os.path.relpath(src, self.project_root)
                rel_sources.append(rel)
            except ValueError:
                rel_sources.append(src)

        mode = manifest.mode
        if mode == "rtl":
            result.syn_files.extend(rel_sources)
            # Register library mapping
            if manifest.library != "work":
                if manifest.library not in result.libraries:
                    result.libraries[manifest.library] = []
                result.libraries[manifest.library].extend(rel_sources)

        elif mode in ("xci", "qsys", "ipx", "cxz"):
            result.xci_files.extend(rel_sources)

        elif mode == "netlist":
            result.netlist_files.extend(rel_sources)

        elif mode == "ooc_dcp":
            result.ooc_dcp_files.extend(rel_sources)


def print_ip_list(result: IpResolutionResult):
    """Print a summary table of resolved IPs."""
    if not result.manifests:
        print("  No IPs found in project.yml sources.ips")
        return

    print(f"\n🧩 IP Manifest Summary ({len(result.manifests)} IPs)\n")
    for m in result.manifests:
        lib_info = f"library={m.library}" if m.library != "work" else "—"
        count = f"{m.source_count} {'source' if m.source_count == 1 else 'sources'}"
        if m.mode in ("xci", "qsys", "ipx", "cxz"):
            count = f"{m.source_count} IP {'file' if m.source_count == 1 else 'files'}"
        elif m.mode in ("netlist", "ooc_dcp"):
            count = f"{m.source_count} {'netlist' if m.source_count == 1 else 'netlists'}"

        print(f"  ✅ {m.name:<25} {m.mode:<10} {lib_info:<20} {count}")
    print()


def print_ip_hierarchy(result: IpResolutionResult, indent: int = 0):
    """Print a tree view of IP dependencies."""
    if not result.manifests:
        print("  No IPs found in project.yml sources.ips")
        return

    if indent == 0:
        print("\n🌳 IP Dependency Tree\n")

    # Build a set of all child paths so we only print top-level roots
    child_paths = set()
    for m in result.manifests:
        for c in m.children:
            child_paths.add(str(c.path))

    roots = [m for m in result.manifests if str(m.path) not in child_paths]

    for i, m in enumerate(roots):
        is_last = i == len(roots) - 1
        _print_tree_node(m, "", is_last)
    print()


def _print_tree_node(manifest: IpManifest, prefix: str, is_last: bool):
    """Recursively print a tree node."""
    connector = "└── " if is_last else "├── "
    count_label = f"{manifest.source_count} file{'s' if manifest.source_count != 1 else ''}"
    print(f"{prefix}{connector}{manifest.name} ({manifest.mode}, {count_label})")

    new_prefix = prefix + ("    " if is_last else "│   ")
    for i, child in enumerate(manifest.children):
        child_is_last = i == len(manifest.children) - 1
        _print_tree_node(child, new_prefix, child_is_last)


def load_ips_from_project(project_yml_path: str) -> tuple:
    """
    Load IP paths and vendor from a project.yml.

    Returns (ip_paths, vendor, project_root) or raises on error.
    """
    project_root = Path(project_yml_path).resolve().parent

    with open(project_yml_path, "r") as f:
        config = yaml.safe_load(f) or {}

    vendor = config.get("hardware", {}).get("vendor", "xilinx")
    ip_paths = config.get("sources", {}).get("ips", [])

    return ip_paths, vendor, project_root


# ── IP Dependency Resolution (P2.81) ────────────────────────────

# Known SDK-bundled IP source extensions
_HDL_EXTS = {".vhd", ".vhdl", ".v", ".sv"}


@dataclass
class FetchResult:
    """Outcome of an IP dependency fetch operation."""

    fetched: List[str] = field(default_factory=list)
    already_present: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.fetched) + len(self.already_present) + len(self.errors)


class IpDependencyResolver:
    """Resolve and fetch SDK-bundled IP dependencies declared in ip.yml.

    Dependencies use a namespace/name format::

        dependencies:
          - routertl/fifo_xpm_async
          - routertl/cdc_synchronizer

    The ``routertl/*`` namespace resolves IPs from ``<SDK_ROOT>/src/units/``.
    Fetched sources are copied into the consumer's local ``deps/`` directory.
    """

    # Namespace → relative directory within SDK root containing IP sources
    _SDK_IP_DIRS = {
        "routertl": Path("src") / "units",
    }

    def __init__(self, sdk_root: Optional[Path] = None):
        self._sdk_root = sdk_root

    @property
    def sdk_root(self) -> Optional[Path]:
        """Lazily resolve SDK root."""
        if self._sdk_root is None:
            try:
                from sdk.cli.sdk_root import resolve_sdk_root
                self._sdk_root = resolve_sdk_root()
            except ImportError:
                pass
        return self._sdk_root

    def resolve_sdk_ip(self, namespace: str, ip_name: str) -> Optional[Path]:
        """Locate a single SDK-bundled IP source file.

        Returns the absolute path to the IP source if found, else ``None``.
        """
        sdk = self.sdk_root
        if sdk is None:
            return None

        ip_dir = self._SDK_IP_DIRS.get(namespace)
        if ip_dir is None:
            return None

        units_dir = sdk / ip_dir
        if not units_dir.is_dir():
            return None

        # Try each HDL extension
        for ext in sorted(_HDL_EXTS):
            candidate = units_dir / f"{ip_name}{ext}"
            if candidate.exists():
                return candidate.resolve()

        return None

    def parse_dep_id(self, dep_id: str) -> tuple:
        """Parse a dependency identifier into (namespace, name).

        Returns (namespace, name) or (None, None) on invalid format.
        """
        parts = dep_id.strip().split("/", 1)
        if len(parts) != 2 or not parts[0] or not parts[1]:
            return (None, None)
        return (parts[0], parts[1])

    def fetch_all(
        self,
        manifests: List[IpManifest],
        dest_dir: Path,
        dry_run: bool = False,
    ) -> FetchResult:
        """Fetch all dependencies declared across the given IP manifests.

        Parameters
        ----------
        manifests : list of IpManifest
            Resolved IP manifests whose ``dependencies`` lists will be walked.
        dest_dir : Path
            Root destination directory (e.g. ``deps/``).  SDK IPs are placed
            under ``<dest_dir>/<namespace>/<ip_name>/``.
        dry_run : bool
            If True, report what would happen without copying files.

        Returns
        -------
        FetchResult
        """
        result = FetchResult()
        seen: Set[str] = set()  # dedup across manifests

        for manifest in manifests:
            for dep_id in manifest.dependencies:
                if dep_id in seen:
                    continue
                seen.add(dep_id)

                ns, name = self.parse_dep_id(dep_id)
                if ns is None:
                    result.errors.append(
                        f"Invalid dependency format '{dep_id}' in {manifest.name} — "
                        f"expected 'namespace/ip_name'"
                    )
                    continue

                ip_dest = dest_dir / ns / name

                # Already fetched?
                if ip_dest.exists() and any(ip_dest.iterdir()):
                    result.already_present.append(dep_id)
                    continue

                src_path = self.resolve_sdk_ip(ns, name)
                if src_path is None:
                    result.errors.append(
                        f"Cannot resolve '{dep_id}' — not found in SDK "
                        f"(looked in {ns}/ namespace)"
                    )
                    continue

                if dry_run:
                    result.fetched.append(dep_id)
                    continue

                # Copy source file into dest
                ip_dest.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(src_path), str(ip_dest / src_path.name))
                result.fetched.append(dep_id)
                logger.info("Fetched %s → %s", dep_id, ip_dest)

        return result

    def check_all(
        self,
        manifests: List[IpManifest],
        dest_dir: Path,
    ) -> List[dict]:
        """Check dependency availability without fetching.

        Returns a list of dicts with keys: dep_id, status ('ok', 'missing',
        'error'), detail.
        """
        results = []
        seen: Set[str] = set()

        for manifest in manifests:
            for dep_id in manifest.dependencies:
                if dep_id in seen:
                    continue
                seen.add(dep_id)

                ns, name = self.parse_dep_id(dep_id)
                if ns is None:
                    results.append({
                        "dep_id": dep_id,
                        "status": "error",
                        "detail": "invalid format",
                    })
                    continue

                ip_dest = dest_dir / ns / name
                if ip_dest.exists() and any(ip_dest.iterdir()):
                    results.append({
                        "dep_id": dep_id,
                        "status": "ok",
                        "detail": str(ip_dest),
                    })
                    continue

                src_path = self.resolve_sdk_ip(ns, name)
                if src_path is not None:
                    results.append({
                        "dep_id": dep_id,
                        "status": "missing",
                        "detail": "available in SDK — run: rr deps fetch",
                    })
                else:
                    results.append({
                        "dep_id": dep_id,
                        "status": "missing",
                        "detail": f"not found in SDK ({ns}/ namespace)",
                    })

        return results
