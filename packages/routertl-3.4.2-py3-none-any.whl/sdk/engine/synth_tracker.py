# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Synthesis Result Tracker for RouteRTL SDK.

Persists synthesis PASS/FAIL results to `.routertl_cache/synth_results.json`
and provides staleness detection by comparing result timestamps against
source file modification times.
"""

import json
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class SynthResult:
    """A single synthesis run result."""

    module: str
    status: str  # "PASS" or "FAIL"
    timestamp: str  # ISO-8601 UTC
    duration_s: float = 0.0
    resources: Dict[str, int] = field(default_factory=dict)
    warnings: int = 0
    vendor: str = ""
    part: str = ""
    timing_wns: float = 0.0
    timing_fmax: float = 0.0
    timing_clock: str = ""
    phases: List[Dict] = field(default_factory=list)


# Cache file schema version — bump when the format changes
_CACHE_VERSION = 2


class SynthTracker:
    """Load, query, and persist synthesis results.

    Results are stored in ``<project_root>/.routertl_cache/synth_results.json``.
    Each module has at most one entry (latest run wins).
    """

    def __init__(self, project_root: Optional[str] = None):
        """Create a tracker rooted at *project_root* (defaults to cwd)."""
        root = Path(project_root) if project_root else Path.cwd()
        self._cache_dir = root / ".routertl_cache"
        self._cache_file = self._cache_dir / "synth_results.json"
        self._results: Dict[str, SynthResult] = {}
        self._load()

    # ── Persistence ──────────────────────────────────────────────

    def _load(self) -> None:
        """Load results from disk, tolerating missing/corrupt files."""
        if not self._cache_file.exists():
            return
        try:
            with open(self._cache_file, "r") as f:
                data = json.load(f)
            if data.get("version", 0) != _CACHE_VERSION:
                return  # incompatible version — start fresh
            for name, entry in data.get("results", {}).items():
                self._results[name] = SynthResult(
                    module=entry.get("module", name),
                    status=entry.get("status", "FAIL"),
                    timestamp=entry.get("timestamp", ""),
                    duration_s=entry.get("duration_s", 0.0),
                    resources=entry.get("resources", {}),
                    warnings=entry.get("warnings", 0),
                    vendor=entry.get("vendor", ""),
                    part=entry.get("part", ""),
                    timing_wns=entry.get("timing_wns", 0.0),
                    timing_fmax=entry.get("timing_fmax", 0.0),
                    timing_clock=entry.get("timing_clock", ""),
                    phases=entry.get("phases", []),
                )
        except (json.JSONDecodeError, KeyError, TypeError):
            self._results = {}

    def save(self) -> None:
        """Write current results to disk."""
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": _CACHE_VERSION,
            "results": {name: asdict(r) for name, r in self._results.items()},
        }
        with open(self._cache_file, "w") as f:
            json.dump(payload, f, indent=2)

    # ── Queries ──────────────────────────────────────────────────

    def record(self, result: SynthResult) -> None:
        """Upsert a synthesis result (by module name) and save."""
        self._results[result.module] = result
        self.save()

    def get(self, module: str) -> Optional[SynthResult]:
        """Return the cached result for *module*, or ``None``."""
        return self._results.get(module)

    def all_results(self) -> Dict[str, SynthResult]:
        """Return all cached results."""
        return dict(self._results)

    def clear(self, module: Optional[str] = None) -> None:
        """Clear one module's result or all results."""
        if module:
            self._results.pop(module, None)
        else:
            self._results.clear()
        self.save()

    # ── Staleness ────────────────────────────────────────────────

    def staleness_check(self, module: str, src_files: List[str]) -> str:
        """Return the effective status of *module*.

        Returns one of:
            ``"PASS"``    — last synthesis passed, sources unchanged since.
            ``"FAIL"``    — last synthesis failed.
            ``"STALE"``   — last synthesis passed, but sources modified since.
            ``"UNKNOWN"`` — no cached result for this module.
        """
        result = self.get(module)
        if result is None:
            return "UNKNOWN"
        if result.status != "PASS":
            return "FAIL"

        # Compare result timestamp against source file mtimes
        try:
            result_ts = datetime.fromisoformat(result.timestamp).timestamp()
        except (ValueError, TypeError):
            return "STALE"

        for src in src_files:
            try:
                if os.path.getmtime(src) > result_ts:
                    return "STALE"
            except OSError:
                continue  # file may have been deleted

        return "PASS"
