# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Unified Synthesis Report Parser for RouteRTL SDK.

Parses vendor-specific FPGA build reports (Vivado, Quartus, Radiant,
Libero) into a unified data model so that ``rr synth report`` can
display a consistent, vendor-agnostic summary.

Two data paths are supported:

1. **Structured JSON** — emitted by the TCL ``report_emitter.tcl``
   scripts at the end of each build stage.  This is the preferred path.
2. **Native text reports** — fallback parsers that scrape the
   vendor-specific ``.rpt`` files produced by the EDA tools.
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

# ── Data Model ────────────────────────────────────────────────────


@dataclass
class PhaseResult:
    """Outcome of a single build phase (e.g. Synthesis, Place & Route)."""

    name: str
    passed: bool = True
    duration_s: float = 0.0


@dataclass
class ResourceEntry:
    """A single resource usage value with optional capacity."""

    used: int = 0
    available: int = 0  # 0 means "unknown / not reported"

    @property
    def pct(self) -> float:
        """Utilization percentage (0.0 when capacity is unknown)."""
        return (self.used / self.available * 100) if self.available else 0.0


@dataclass
class TimingResult:
    """Timing closure summary."""

    fmax_mhz: float = 0.0
    clock_name: str = ""
    wns_ns: float = 0.0  # Worst Negative Slack
    tns_ns: float = 0.0  # Total Negative Slack
    met: bool = True


@dataclass
class BuildReport:
    """Vendor-agnostic build report extracted from EDA tool outputs."""

    vendor: str = ""  # "xilinx", "altera", "lattice", "microchip"
    part: str = ""
    top_module: str = ""
    tool_name: str = ""  # e.g. "Vivado 2024.1", "Quartus Prime 23.1 Pro"

    phases: list[PhaseResult] = field(default_factory=list)
    resources: dict[str, ResourceEntry] = field(default_factory=dict)
    timing: TimingResult = field(default_factory=TimingResult)

    warnings: int = 0
    errors: int = 0
    timestamp: str = ""  # ISO-8601

    def to_dict(self) -> dict:
        """Serialize to a plain dict (for JSON cache)."""
        d = asdict(self)
        # Convert ResourceEntry → {used, available, pct}
        for key, entry in d.get("resources", {}).items():
            entry["pct"] = round(
                entry["used"] / entry["available"] * 100, 1
            ) if entry.get("available") else 0.0
        return d

    def to_synth_result_fields(self) -> dict:
        """Return fields suitable for updating a SynthResult."""
        res_dict = {}
        for key, entry in self.resources.items():
            res_dict[key] = entry.used
        return {
            "resources": res_dict,
            "warnings": self.warnings,
            "timing_wns": self.timing.wns_ns,
            "timing_fmax": self.timing.fmax_mhz,
            "timing_clock": self.timing.clock_name,
        }


# ── JSON Report Loader ───────────────────────────────────────────


def parse_json_report(path: Path) -> Optional[BuildReport]:
    """Load a ``build_report.json`` emitted by the TCL layer.

    Returns ``None`` if the file does not exist or is malformed.
    """
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None

    report = BuildReport(
        vendor=data.get("vendor", ""),
        part=data.get("part", ""),
        top_module=data.get("top_module", ""),
        tool_name=data.get("tool_name", ""),
        warnings=data.get("warnings", 0),
        errors=data.get("errors", 0),
        timestamp=data.get("timestamp", ""),
    )

    for ph in data.get("phases", []):
        report.phases.append(PhaseResult(
            name=ph.get("name", ""),
            passed=ph.get("passed", True),
            duration_s=ph.get("duration_s", 0.0),
        ))

    for key, res in data.get("resources", {}).items():
        report.resources[key] = ResourceEntry(
            used=res.get("used", 0),
            available=res.get("available", 0),
        )

    t = data.get("timing", {})
    report.timing = TimingResult(
        fmax_mhz=t.get("fmax_mhz", 0.0),
        clock_name=t.get("clock_name", ""),
        wns_ns=t.get("wns_ns", 0.0),
        tns_ns=t.get("tns_ns", 0.0),
        met=t.get("met", True),
    )

    return report


# ── Xilinx / Vivado Parser ───────────────────────────────────────


def _parse_vivado_utilization(text: str) -> dict[str, ResourceEntry]:
    """Extract resource entries from a Vivado ``utilization.rpt`` file.

    Handles two table formats produced by Vivado:

    **5-column** (7-series)::

        | Site Type | Used | Fixed | Available | Util% |

    **6-column** (UltraScale+)::

        | Site Type | Used | Fixed | Prohibited | Available | Util% |
    """
    resources: dict[str, ResourceEntry] = {}

    # Map Vivado site type names → unified keys
    # The * suffix (e.g. "CLB LUTs*") is stripped before lookup.
    name_map = {
        "Slice LUTs": "LUTs",
        "LUT as Logic": "LUTs",
        "CLB LUTs": "LUTs",
        "Slice Registers": "FFs",
        "Register as Flip Flop": "FFs",
        "CLB Registers": "FFs",
        "Block RAM Tile": "BRAM",
        "RAMB36/FIFO": "BRAM",
        "RAMB36E1": "BRAM",
        "RAMB36E2": "BRAM",
        "DSPs": "DSPs",
        "DSP Slices": "DSPs",
        "DSP48E1": "DSPs",
        "DSP48E2": "DSPs",
        "Bonded IOB": "IOs",
        "Bonded IPADs": "IOs",
    }

    seen: set[str] = set()

    # Split into lines and parse each table row.
    # We look for pipe-delimited rows and extract all integer columns,
    # then use heuristics to identify Used and Available.
    for line in text.splitlines():
        if not line.startswith("|"):
            continue

        # Split by pipe, strip whitespace
        cells = [c.strip() for c in line.split("|")]
        # Remove empty first/last elements from the split
        cells = [c for c in cells if c]

        if len(cells) < 2:
            continue

        # First cell is the name, remaining cells are values
        raw_name = cells[0].rstrip("*").strip()  # strip footnote asterisks

        unified = name_map.get(raw_name)
        if not unified or unified in seen:
            continue

        # Extract all numeric values from the remaining cells
        nums = []
        for cell in cells[1:]:
            # Handle "<0.01" style values — not a number we want
            cleaned = cell.lstrip("<")
            try:
                nums.append(int(cleaned))
            except ValueError:
                try:
                    float(cleaned)  # util% — skip
                except ValueError:
                    pass  # header or text cell

        if not nums:
            continue

        # First integer is always "Used"
        used = nums[0]

        # Available is the largest integer (it's always > Used)
        # In 5-col: nums = [used, fixed, available]
        # In 6-col: nums = [used, fixed, prohibited, available]
        available = 0
        if len(nums) >= 3:
            # Available is typically the last integer before util%
            # or simply the largest value in the row
            available = max(nums[1:])

        seen.add(unified)
        resources[unified] = ResourceEntry(used=used, available=available)

    return resources


def _parse_vivado_header(text: str) -> dict:
    """Extract metadata from the Vivado report header.

    Returns a dict with tool_name, part, top_module if found.
    """
    meta: dict = {}

    m = re.search(r"Tool Version\s*:\s*(.+?)$", text, re.MULTILINE)
    if m:
        meta["tool_name"] = m.group(1).strip()

    m = re.search(r"Device\s*:\s*(\S+)", text)
    if m:
        meta["part"] = m.group(1).strip()

    m = re.search(r"Design\s*:\s*(\S+)", text)
    if m:
        meta["top_module"] = m.group(1).strip()

    return meta


def _parse_vivado_summary(text: str) -> tuple[TimingResult, dict]:
    """Extract timing and metadata from a Vivado ``summary.rpt`` file.

    The summary.rpt written by gen_implementation.tcl contains::

        Design WNS=0.123ns
        * Place Directive used: Explore
        * Post synthesis optimization @ 00:01:23
    """
    timing = TimingResult()
    meta: dict = {}

    # WNS
    m = re.search(r"Design\s+WNS\s*=\s*([-\d.]+)\s*ns", text)
    if m:
        timing.wns_ns = float(m.group(1))
        timing.met = timing.wns_ns >= 0.0

    # Timing closure message
    if "The design closed timing" in text:
        timing.met = True
    elif "Timing constraints are not met" in text:
        timing.met = False

    # Directives
    m = re.search(r"Place Directive used:\s*(\S+)", text)
    if m:
        meta["place_directive"] = m.group(1)
    m = re.search(r"Route Directive used:\s*(\S+)", text)
    if m:
        meta["route_directive"] = m.group(1)

    return timing, meta


def _parse_vivado_timing_summary(text: str) -> TimingResult:
    """Parse a Vivado ``timing_summary.rpt`` or timing log output.

    Looks for patterns like::

        Worst Negative Slack (WNS):        0.123 ns
        Total Negative Slack (TNS):        0.000 ns
        Worst Hold Slack (WHS):            0.045 ns
    """
    timing = TimingResult()

    m = re.search(r"Worst Negative Slack \(WNS\):\s*([-\d.]+)", text)
    if m:
        timing.wns_ns = float(m.group(1))
        timing.met = timing.wns_ns >= 0.0

    m = re.search(r"Total Negative Slack \(TNS\):\s*([-\d.]+)", text)
    if m:
        timing.tns_ns = float(m.group(1))

    return timing


def parse_vivado_reports(report_dir: Path) -> Optional[BuildReport]:
    """Parse Vivado reports from the project's ``reports/`` directory.

    Attempts to read:
    - ``utilization.rpt`` — resource utilization
    - ``summary.rpt`` — timing + directives (written by gen_implementation.tcl)
    - ``timing_summary.rpt`` — detailed timing (if present)

    Returns ``None`` if no recognizable reports are found.
    """
    util_file = report_dir / "utilization.rpt"
    summary_file = report_dir / "summary.rpt"
    timing_file = report_dir / "timing_summary.rpt"

    has_data = False
    report = BuildReport(vendor="xilinx")

    if util_file.exists():
        text = util_file.read_text(errors="replace")
        report.resources = _parse_vivado_utilization(text)
        has_data = bool(report.resources)
        # Extract metadata from the report header
        meta = _parse_vivado_header(text)
        if meta.get("part"):
            report.part = meta["part"]
        if meta.get("top_module"):
            report.top_module = meta["top_module"]
        if meta.get("tool_name"):
            report.tool_name = meta["tool_name"]

    if summary_file.exists():
        text = summary_file.read_text(errors="replace")
        timing, meta = _parse_vivado_summary(text)
        report.timing = timing
        has_data = True

    if timing_file.exists():
        text = timing_file.read_text(errors="replace")
        ts = _parse_vivado_timing_summary(text)
        # Merge — more detailed source wins
        if ts.wns_ns != 0.0 or report.timing.wns_ns == 0.0:
            report.timing.wns_ns = ts.wns_ns
            report.timing.met = ts.wns_ns >= 0.0
        if ts.tns_ns != 0.0:
            report.timing.tns_ns = ts.tns_ns

    return report if has_data else None


# ── Altera / Quartus Parser ──────────────────────────────────────


def _extract_quartus_sections(filepath: Path, section_markers: list[str],
                               max_section_lines: int = 200) -> str:
    """Read only the relevant sections from a potentially huge Quartus report.

    Quartus reports can be 45 MB+.  Instead of reading the entire file,
    we scan line-by-line for section headers and capture only the content
    within those sections.

    Parameters
    ----------
    filepath : Path
        Path to the .rpt file.
    section_markers : list[str]
        Substrings that identify section header lines (e.g. "Fitter Summary").
    max_section_lines : int
        Maximum lines to capture per section (safety cap).

    Returns
    -------
    str
        Concatenated text from all matched sections.
    """
    chunks: list[str] = []
    in_section = False
    lines_captured = 0

    try:
        with open(filepath, errors="replace") as f:
            for line in f:
                if not in_section:
                    # Check if this line starts a target section
                    for marker in section_markers:
                        if marker in line:
                            in_section = True
                            lines_captured = 0
                            chunks.append(line)
                            break
                else:
                    chunks.append(line)
                    lines_captured += 1
                    # End section on next section header or blank separator
                    if lines_captured >= max_section_lines:
                        in_section = False
                    elif line.strip() == "" and lines_captured > 5:
                        # Blank line after some content = end of section
                        in_section = False
    except OSError:
        pass

    return "".join(chunks)


def _parse_quartus_map_report(text: str) -> dict[str, ResourceEntry]:
    """Extract resource entries from a Quartus ``.map.rpt`` or ``.fit.rpt``.

    Handles both Quartus Standard and Pro Edition report formats::

        ; Logic utilization (ALMs needed / total ALMs on device) ; 196,387 / 427,200 ; 46 % ;
        ; Total registers                                        ; 3,847             ;      ;
        ; M20K blocks                                            ; 705 / 2,713       ; 26 % ;
        ; Total DSP Blocks                                       ; 274 / 1,518       ; 18 % ;
    """
    resources: dict[str, ResourceEntry] = {}

    # Pattern: name ; value / total ( pct % ) or just ; value
    row_re = re.compile(
        r";\s*(.+?)\s*;\s*([\d,]+)\s*(?:/\s*([\d,]+))?\s*(?:\(\s*[\d.]+\s*%\s*\))?\s*;",
    )

    name_map = {
        "Total combinational functions": "ALMs",
        "Estimate of Logic utilization (ALMs)": "ALMs",
        "Logic utilization (ALMs needed / total ALMs on device)": "ALMs",
        "Logic utilization (in ALMs)": "ALMs",
        "Dedicated logic registers": "Regs",
        "Total registers": "Regs",
        "Total block memory bits": "M10K",
        "Total MLAB memory bits": "MLAB",
        "Total block memory implementation bits": "M10K",
        "Total RAM Blocks": "M10K",
        "M10K blocks": "M10K",
        "M20K blocks": "M20K",
        "Total DSP Blocks": "DSPs",
        "DSP block 18-bit elements": "DSPs",
        "Total pins": "IOs",
        "Total I/O pins": "IOs",
        "Total PLLs": "PLLs",
    }

    seen: set[str] = set()

    for m in row_re.finditer(text):
        raw_name = m.group(1).strip()
        used = int(m.group(2).replace(",", ""))
        available = int(m.group(3).replace(",", "")) if m.group(3) else 0

        unified = name_map.get(raw_name)
        if unified and unified not in seen:
            seen.add(unified)
            resources[unified] = ResourceEntry(used=used, available=available)

    return resources


def _parse_quartus_sta_report(text: str) -> TimingResult:
    """Extract timing from a Quartus STA ``.sta.rpt`` or Fitter summary.

    Looks for patterns like::

        ; Fmax           ; 156.2 MHz  ; clk_100  ;
        ; Worst-case setup slack ; 0.123 ;

    Or the Slow Model Fmax Summary table::

        ; Fmax       ; Restricted Fmax ; Clock Name ;
        ; 156.2 MHz  ; 156.2 MHz       ; clk_100    ;
    """
    timing = TimingResult()

    # Fmax from STA summary table
    fmax_re = re.compile(
        r";\s*([\d.]+)\s*MHz\s*;\s*[\d.]+\s*MHz\s*;\s*(\S+)\s*;",
    )
    for m in fmax_re.finditer(text):
        freq = float(m.group(1))
        if timing.fmax_mhz == 0.0 or freq < timing.fmax_mhz:
            timing.fmax_mhz = freq
            timing.clock_name = m.group(2)

    # Setup slack
    slack_re = re.compile(r"Worst-case.*?setup.*?slack\s*;\s*([-\d.]+)", re.I)
    m = slack_re.search(text)
    if m:
        timing.wns_ns = float(m.group(1))
        timing.met = timing.wns_ns >= 0.0

    return timing


def parse_quartus_reports(
    project_dir: Path,
    project_name: str = "",
) -> Optional[BuildReport]:
    """Parse Quartus reports from a project directory.

    Looks for ``<project_name>.map.rpt``, ``<project_name>.fit.rpt``,
    and ``<project_name>.sta.rpt`` in the project directory.

    If *project_name* is empty, auto-detects by scanning for ``.qpf`` files.

    Uses section-aware reading for large reports (Quartus fit.rpt can be 45 MB+).

    Returns ``None`` if no recognizable reports are found.
    """
    if not project_name:
        qpf_files = list(project_dir.glob("*.qpf"))
        if qpf_files:
            project_name = qpf_files[0].stem
        else:
            # Try finding .map.rpt directly
            map_files = list(project_dir.glob("*.map.rpt"))
            if map_files:
                project_name = map_files[0].stem.replace(".map", "")

    if not project_name:
        return None

    has_data = False
    report = BuildReport(vendor="altera")

    # Section markers for resource summaries
    resource_markers = [
        "Resource Usage Summary",
        "Fitter Summary",
        "Analysis & Synthesis Resource Usage Summary",
    ]

    # Map report (synthesis)
    map_file = project_dir / f"{project_name}.map.rpt"
    if map_file.exists():
        text = _extract_quartus_sections(map_file, resource_markers)
        report.resources = _parse_quartus_map_report(text)
        has_data = bool(report.resources)

    # Fit report (place & route) — may also have resources
    fit_file = project_dir / f"{project_name}.fit.rpt"
    if fit_file.exists():
        text = _extract_quartus_sections(fit_file, resource_markers)
        fit_resources = _parse_quartus_map_report(text)
        # Fit report resources override map report (more accurate post-fit)
        if fit_resources:
            report.resources.update(fit_resources)
            has_data = True

    # STA report (timing) — Fmax Summary section
    sta_file = project_dir / f"{project_name}.sta.rpt"
    if sta_file.exists():
        timing_markers = ["Fmax Summary", "Setup Summary"]
        text = _extract_quartus_sections(sta_file, timing_markers)
        report.timing = _parse_quartus_sta_report(text)
        has_data = True

    return report if has_data else None



# ── Lattice Radiant Report Parser ────────────────────────────────


def _parse_synplify_srr_resources(text: str) -> dict[str, ResourceEntry]:
    """Extract resource entries from a Synplify ``.srr`` report.

    Handles patterns commonly found in Synplify Pro reports for
    Lattice iCE40 and CrossLink-NX devices::

        Resource Usage Report for system_top

           Register bits:  567 out of  5280 (11%)
           LUT4s:          1234 out of  5280 (23%)
           EBR:            12 out of  30 (40%)
           DSP:             2 out of   8 (25%)
           I/O pins:       24 out of  39 (62%)
    """
    resources: dict[str, ResourceEntry] = {}

    # Pattern: "Resource: NNN out of NNN (NN%)"
    resource_re = re.compile(
        r"^\s*(.+?):\s+([\d,]+)\s+out of\s+([\d,]+)\s+\(",
        re.MULTILINE,
    )

    name_map = {
        "Register bits": "Regs",
        "SLICEs": "SLICEs",
        "LUT4s": "LUT4",
        "LUTs": "LUT4",
        "EBR": "EBR",
        "EBRs": "EBR",
        "DSPs": "DSPs",
        "DSP": "DSPs",
        "I/O pins": "IOs",
        "IOBs": "IOs",
        "PLLs": "PLLs",
        "I2C": "I2C",
        "SPI": "SPI",
    }

    for m in resource_re.finditer(text):
        raw_name = m.group(1).strip()
        used = int(m.group(2).replace(",", ""))
        available = int(m.group(3).replace(",", ""))

        unified = name_map.get(raw_name)
        if unified and unified not in resources:
            resources[unified] = ResourceEntry(used=used, available=available)

    return resources


def _parse_synplify_srr_phases(text: str) -> list[PhaseResult]:
    """Extract build phase durations from a Synplify ``.srr`` report.

    Looks for::

        Process took 0h:01m:23s realtime
    """
    phases = []

    # Check if synthesis completed successfully
    synthesis_ok = "Synthesis succeeded" in text or "Process completed" in text
    phases.append(PhaseResult(
        name="Synthesis",
        passed=synthesis_ok,
        duration_s=0.0,
    ))

    # Extract runtime
    time_re = re.compile(
        r"Process took (\d+)h:(\d+)m:(\d+)s realtime",
    )
    m = time_re.search(text)
    if m:
        h, mins, s = int(m.group(1)), int(m.group(2)), int(m.group(3))
        phases[0].duration_s = h * 3600 + mins * 60 + s

    return phases


def _parse_radiant_par_timing(text: str) -> TimingResult:
    """Extract timing data from a Radiant PAR report.

    Looks for patterns like::

        Timing Report Summary
        ---------------------
        Constraint                   |  Coverage  |  Met  |  Slack (ns)
        clk_osc                      |  100.0%    |  Yes  |  14.123

    Or Fmax from the timing summary::

        Maximum Clock Frequency: 83.33 MHz (clk_osc)
    """
    timing = TimingResult()

    # Fmax pattern
    fmax_re = re.compile(
        r"Maximum\s+(?:Clock\s+)?Frequency[:\s]+(\d+\.?\d*)\s*MHz"
        r"(?:\s*\((\S+)\))?",
        re.I,
    )
    m = fmax_re.search(text)
    if m:
        timing.fmax_mhz = float(m.group(1))
        if m.group(2):
            timing.clock_name = m.group(2)

    # WNS / slack
    wns_re = re.compile(
        r"(?:Worst\s+)?(?:Negative\s+)?Slack\s*[:\s]+([-\d.]+)\s*ns",
        re.I,
    )
    m = wns_re.search(text)
    if m:
        timing.wns_ns = float(m.group(1))
        timing.met = timing.wns_ns >= 0.0

    # Alternative: constraint table with slack column
    # "clk_xxx  |  100.0%  |  Yes  |  14.123"
    constraint_re = re.compile(
        r"(\S+)\s*\|\s*[\d.]+%\s*\|\s*(Yes|No)\s*\|\s*([-\d.]+)",
        re.I,
    )
    for m in constraint_re.finditer(text):
        slack = float(m.group(3))
        if timing.wns_ns == 0.0 or slack < timing.wns_ns:
            timing.wns_ns = slack
            timing.clock_name = m.group(1)
            timing.met = m.group(2).lower() == "yes"

    return timing


def _count_warnings_srr(text: str) -> int:
    """Count warning lines in a Synplify report."""
    return len(re.findall(r"^@W:", text, re.MULTILINE))


def parse_radiant_reports(
    project_dir: Path,
    project_name: str = "",
) -> Optional[BuildReport]:
    """Parse Lattice Radiant reports from a project directory.

    Looks for:
    - ``<project_name>_impl_1.srr`` — Synplify synthesis report (resources)
    - ``<project_name>_impl_1.par`` — PAR report (timing)

    If *project_name* is empty, auto-detects by scanning for ``.rdf`` files.

    Returns ``None`` if no recognizable reports are found.
    """
    if not project_name:
        rdf_files = list(project_dir.glob("*.rdf"))
        if rdf_files:
            project_name = rdf_files[0].stem
        else:
            # Try auto-detecting from .srr files
            srr_files = list(project_dir.glob("*_impl_1.srr"))
            if srr_files:
                stem = srr_files[0].stem
                project_name = stem.replace("_impl_1", "")

    if not project_name:
        return None

    has_data = False
    report = BuildReport(vendor="lattice")

    # Synplify synthesis report (.srr) — phases and warnings
    srr_file = project_dir / f"{project_name}_impl_1.srr"
    if not srr_file.exists():
        srr_file = project_dir / "synlog" / f"{project_name}_impl_1_compiler.srr"

    if srr_file.exists():
        try:
            text = srr_file.read_text(errors="replace")

            # Extract tool version
            version_re = re.compile(
                r"Synplify Pro.*?Version\s+(\S+)", re.I,
            )
            m = version_re.search(text)
            if m:
                report.tool_name = f"Radiant (Synplify {m.group(1)})"
            else:
                report.tool_name = "Radiant"

            # Resources from .srr (fallback, uses "X out of Y" format)
            report.resources = _parse_synplify_srr_resources(text)
            if report.resources:
                has_data = True

            # Phases
            report.phases = _parse_synplify_srr_phases(text)
            if report.phases:
                has_data = True

            # Warnings
            report.warnings = _count_warnings_srr(text)

            # Timing from .srr (Synplify worst slack)
            slack_re = re.compile(
                r"Slack\s*\(critical\)\s*:\s*([-\d.]+)", re.I,
            )
            m = slack_re.search(text)
            if m:
                report.timing.wns_ns = float(m.group(1))
                report.timing.met = report.timing.wns_ns >= 0.0
        except OSError:
            pass

    # Map report (.mrp) — primary resource data (post-map, more accurate)
    mrp_file = project_dir / f"{project_name}_impl_1.mrp"
    if mrp_file.exists():
        try:
            text = mrp_file.read_text(errors="replace")

            # Pattern: "Number of XXX: NNN out of NNN (N%)"
            mrp_re = re.compile(
                r"Number of\s+(.+?):\s+([\d,]+)\s+out of\s+([\d,]+)\s+\(",
                re.MULTILINE,
            )
            mrp_name_map = {
                "slice registers": "Regs",
                "LUT4s": "LUT4",
                "IO sites used": "IOs",
                "DSPs": "DSPs",
                "EBRs": "EBR",
                "PLLs": "PLLs",
                "SRAMs": "SRAM",
                "I2Cs": "I2C",
                "SPIs": "SPI",
                "I/O registers": "IO_Regs",
            }

            for m in mrp_re.finditer(text):
                raw_name = m.group(1).strip()
                used = int(m.group(2).replace(",", ""))
                available = int(m.group(3).replace(",", ""))
                unified = mrp_name_map.get(raw_name)
                if unified and unified not in report.resources:
                    report.resources[unified] = ResourceEntry(
                        used=used, available=available,
                    )

            if report.resources:
                has_data = True
        except OSError:
            pass

    # PAR report (.par) — timing data and P&R phase
    par_file = project_dir / f"{project_name}_impl_1.par"
    if par_file.exists():
        try:
            text = par_file.read_text(errors="replace")
            report.timing = _parse_radiant_par_timing(text)

            # Also check for Slack (critical) in PAR output
            slack_re = re.compile(
                r"Slack\s*\(critical\)\s*:\s*([-\d.]+)", re.I,
            )
            m = slack_re.search(text)
            if m:
                slack = float(m.group(1))
                if report.timing.wns_ns == 0.0 or slack < report.timing.wns_ns:
                    report.timing.wns_ns = slack
                    report.timing.met = slack >= 0.0

            # "Worst Slack" from PAR summary table
            worst_slack_re = re.compile(
                r"Worst Slack\b.*?([-\d.]+)", re.I,
            )
            for m in worst_slack_re.finditer(text):
                try:
                    slack = float(m.group(1))
                    if report.timing.wns_ns == 0.0 or slack < report.timing.wns_ns:
                        report.timing.wns_ns = slack
                        report.timing.met = slack >= 0.0
                except ValueError:
                    pass

            # Add P&R phase
            par_ok = "unrouted conns = 0" in text.lower() or "completed" in text.lower()
            par_phase = PhaseResult(name="Place & Route", passed=par_ok)
            time_re = re.compile(
                r"Total CPU time.*?(\d+)h:(\d+)m:(\d+)s",
                re.I,
            )
            m = time_re.search(text)
            if m:
                h, mins, s = int(m.group(1)), int(m.group(2)), int(m.group(3))
                par_phase.duration_s = h * 3600 + mins * 60 + s
            report.phases.append(par_phase)
            has_data = True
        except OSError:
            pass

    # Bitstream phase (check if .bin exists)
    bin_files = list(project_dir.glob("*.bin"))
    if bin_files:
        report.phases.append(PhaseResult(name="Bitstream", passed=True))
        has_data = True

    return report if has_data else None


# ── Auto-detection ───────────────────────────────────────────────


def detect_and_parse(
    root_dir: Path,
    vendor: str = "",
) -> Optional[BuildReport]:
    """Auto-detect and parse build reports from a project directory.

    Strategy:
    1. Check for JSON report (``reports/build_report.json``) first.
    2. Fall back to vendor-specific text report parsing.

    Parameters
    ----------
    root_dir : Path
        Project root directory.
    vendor : str, optional
        Vendor hint (``xilinx``, ``altera``, etc.).  If empty, tries
        all vendors.
    """
    # Priority 1: Structured JSON from TCL emitter
    json_path = root_dir / "reports" / "build_report.json"
    report = parse_json_report(json_path)
    if report:
        return report

    # Priority 2: Vendor-specific text reports
    report_dir = root_dir / "reports"
    project_dir = root_dir / "project"

    if vendor in ("xilinx", ""):
        report = parse_vivado_reports(report_dir)
        if report:
            return report

    if vendor in ("altera", ""):
        # Quartus reports are usually in the project directory
        report = parse_quartus_reports(project_dir)
        if report:
            return report
        # Also check root/output/ for some project layouts
        report = parse_quartus_reports(root_dir / "output")
        if report:
            return report

    if vendor in ("lattice", ""):
        report = parse_radiant_reports(project_dir)
        if report:
            return report

    # Microchip — placeholder for future parser
    # if vendor in ("microchip", ""):
    #     report = parse_libero_reports(report_dir)

    return None

