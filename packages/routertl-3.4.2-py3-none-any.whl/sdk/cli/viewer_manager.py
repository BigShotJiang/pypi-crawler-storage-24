# SPDX-License-Identifier: MIT
# Copyright (c) 2024-2026 Daniel J. Mazure
"""Logic-trace waveform viewer manager.

Handles downloading, caching, and launching the logic-trace binary.
Follows the Playwright model: auto-download on first use, cache locally.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import subprocess
import tarfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

GITHUB_REPO = "djmazure/logic-trace"
CACHE_DIR = Path.home() / ".routertl" / "bin" / "logic-trace"
VERSION_FILE = CACHE_DIR / ".version"

# Map (system, machine) → asset name suffix
_PLATFORM_MAP = {
    ("Linux", "x86_64"): "linux-x86_64",
    ("Linux", "aarch64"): "linux-aarch64",
    ("Windows", "AMD64"): "windows-x86_64",
    ("Darwin", "arm64"): "macos-arm64",
    ("Darwin", "x86_64"): "macos-x86_64",
}

# Viewer binary name per platform
_BINARY_NAME = {
    "Linux": "logic_gui",
    "Darwin": "logic_gui",
    "Windows": "logic_cli.exe",  # GUI not available on Windows cross-build
}


def _detect_platform() -> str:
    """Return the platform suffix for the current OS+arch."""
    key = (platform.system(), platform.machine())
    suffix = _PLATFORM_MAP.get(key)
    if suffix is None:
        raise RuntimeError(
            f"Unsupported platform: {key[0]} {key[1]}. "
            f"Supported: {', '.join(v for v in _PLATFORM_MAP.values())}"
        )
    return suffix


def _binary_name() -> str:
    """Return the expected binary filename for this platform."""
    return _BINARY_NAME.get(platform.system(), "logic_gui")


def _fetch_latest_release() -> dict:
    """Query GitHub API for the latest release metadata."""
    url = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json"})
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode())


def _find_asset(release: dict, platform_suffix: str) -> tuple[str, str, str]:
    """Find the download URL and version for the given platform in a release.

    Returns:
        (browser_download_url, api_asset_url, version).
        For public repos, browser_download_url works without auth.
        For private repos, api_asset_url with Accept: application/octet-stream
        is the only reliable download path.
    """
    version = release.get("tag_name", "unknown")
    for asset in release.get("assets", []):
        name = asset.get("name", "")
        if platform_suffix in name:
            return asset["browser_download_url"], asset["url"], version
    raise RuntimeError(
        f"No release asset found for platform '{platform_suffix}' "
        f"in release {version}. Available: "
        + ", ".join(a["name"] for a in release.get("assets", []))
    )


def _build_download_request(url: str, api_url: str) -> urllib.request.Request:
    """Build a download request, preferring browser URL but falling back to API.

    For public repos, browser_download_url works without auth.
    For private repos, the API asset URL with Accept: application/octet-stream
    and a Bearer token is required (browser_download_url returns 404).
    """
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")

    if not token:
        # No auth — try browser URL (works for public repos only)
        return urllib.request.Request(url)

    # Try browser URL with auth first — fast redirect for public repos
    # But for private repos this still 404s, so we'll catch and retry
    # with the API URL in the caller.
    req = urllib.request.Request(api_url)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", "application/octet-stream")
    return req


def _download_and_extract(url: str, dest: Path, *, api_url: str = "") -> None:
    """Download an archive from URL and extract to dest directory."""
    dest.mkdir(parents=True, exist_ok=True)

    req = _build_download_request(url, api_url or url)

    # Try to use rich progress if available
    try:
        from rich.progress import (
            BarColumn,
            DownloadColumn,
            Progress,
            TransferSpeedColumn,
        )

        with Progress(
            "[progress.description]{task.description}",
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
        ) as progress:
            task = progress.add_task("Downloading logic-trace...", total=None)
            with urllib.request.urlopen(req, timeout=60) as resp:
                total = resp.headers.get("Content-Length")
                if total:
                    progress.update(task, total=int(total))
                data = bytearray()
                while True:
                    chunk = resp.read(8192)
                    if not chunk:
                        break
                    data.extend(chunk)
                    progress.update(task, advance=len(chunk))
    except ImportError:
        # Fallback without progress bar
        print("Downloading logic-trace...")
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = resp.read()

    # Extract based on file type
    import io

    if url.endswith(".tar.gz") or url.endswith(".tgz"):
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
            # Extract files, flattening one level of directory nesting
            for member in tf.getmembers():
                if member.isfile():
                    # Strip the top-level directory
                    parts = Path(member.name).parts
                    if len(parts) > 1:
                        member.name = str(Path(*parts[1:]))
                    else:
                        member.name = parts[0]
                    tf.extract(member, dest)
    elif url.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                parts = Path(info.filename).parts
                if len(parts) > 1:
                    info.filename = str(Path(*parts[1:]))
                else:
                    info.filename = parts[0]
                zf.extract(info, dest)
    else:
        raise RuntimeError(f"Unknown archive format: {url}")


def get_cached_version() -> Optional[str]:
    """Return the currently cached version, or None if not installed."""
    if VERSION_FILE.exists():
        return VERSION_FILE.read_text().strip()
    return None


def get_viewer_path(*, force_download: bool = False) -> Optional[Path]:
    """Return the path to the logic-trace binary, downloading if needed.

    Args:
        force_download: If True, re-download even if a cached version exists.

    Returns:
        Path to the viewer binary, or None if download fails.
    """
    binary = CACHE_DIR / _binary_name()

    if binary.exists() and not force_download:
        logger.debug("Using cached logic-trace at %s", binary)
        return binary

    try:
        plat = _detect_platform()
        release = _fetch_latest_release()
        url, api_url, version = _find_asset(release, plat)

        # Clean previous installation
        if CACHE_DIR.exists():
            shutil.rmtree(CACHE_DIR)

        _download_and_extract(url, CACHE_DIR, api_url=api_url)

        # Make binary executable on Unix
        if platform.system() != "Windows" and binary.exists():
            binary.chmod(0o755)

        # Record version
        VERSION_FILE.write_text(version + "\n")
        logger.info("Installed logic-trace %s to %s", version, CACHE_DIR)
        return binary

    except (OSError, RuntimeError, urllib.error.URLError, ValueError) as exc:
        logger.warning("Failed to download logic-trace: %s", exc)
        return None


def launch_viewer(waveform_path: Path, *, viewer_path: Optional[Path] = None) -> Optional[subprocess.Popen]:
    """Launch the logic-trace viewer with a waveform file.

    Args:
        waveform_path: Path to the .fst, .vcd, .ghw, or .ltrace file.
        viewer_path: Override for the viewer binary path. If None, auto-resolve.

    Returns:
        The Popen handle, or None if the viewer could not be launched.
    """
    if viewer_path is None:
        viewer_path = get_viewer_path()

    if viewer_path is None or not viewer_path.exists():
        return None

    waveform_path = Path(waveform_path).resolve()
    if not waveform_path.exists():
        logger.warning("Waveform file not found: %s", waveform_path)
        return None

    cmd = [str(viewer_path), str(waveform_path)]
    logger.info("Launching: %s", " ".join(cmd))

    try:
        # Detach the viewer process so it survives after the CLI exits
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        return proc
    except OSError as exc:
        logger.warning("Failed to launch logic-trace: %s", exc)
        return None


def find_latest_waveform(search_dir: Path, *, extensions: tuple[str, ...] = (".fst", ".vcd", ".ghw")) -> Optional[Path]:
    """Find the most recently modified waveform file in a directory.

    Args:
        search_dir: Directory to search (typically sim/waves/).
        extensions: File extensions to look for.

    Returns:
        Path to the newest waveform file, or None if none found.
    """
    if not search_dir.exists():
        return None

    candidates = []
    for ext in extensions:
        candidates.extend(search_dir.rglob(f"*{ext}"))

    if not candidates:
        return None

    return max(candidates, key=lambda p: p.stat().st_mtime)


def find_gtkwave() -> Optional[Path]:
    """Find GTKWave as a fallback viewer."""
    gtkwave = shutil.which("gtkwave")
    return Path(gtkwave) if gtkwave else None
