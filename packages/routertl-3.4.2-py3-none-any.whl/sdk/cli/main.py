# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import sys

import rich_click as click
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from routertl_core import __version__
from sdk.cli.commands.ci import ci_group
from sdk.cli.commands.completion import completion_command
from sdk.cli.commands.config import config_command
from sdk.cli.commands.deps import deps_group
from sdk.cli.commands.diff import diff_command
from sdk.cli.commands.docker import docker_group
from sdk.cli.commands.doctor import doctor
from sdk.cli.commands.eda import eda_group
from sdk.cli.commands.fpga import fpga_group
from sdk.cli.commands.hardware import (
    bitstream_group,
    hierarchy,
    impl_group,
    linting,
    npm_synthesis,
    project_group,
    schematic,
    synth_targets,
)
from sdk.cli.commands.info import info_command
from sdk.cli.commands.ip import ip_group, regbank_group, rom
from sdk.cli.commands.license import license_command
from sdk.cli.commands.linux import linux_group
from sdk.cli.commands.report import report_command
from sdk.cli.commands.sim import regression, scan_tests, sim_command, testgen, view_sim_log, waves
from sdk.cli.commands.sources import sources_command
from sdk.cli.commands.status import status
from sdk.cli.commands.synth import synth_group
from sdk.cli.commands.telemetry import telemetry_group
from sdk.cli.commands.watch import watch_command
from sdk.cli.commands.workspace import workspace_group
from sdk.cli.console import console as _console
from sdk.cli.resilience import cli_resilient, cli_resilient_block

# ── CLI Branding ──────────────────────────────────────────────
# Projects can white-label the CLI via project.yml:
#
#   branding:
#     cli_name: dskopsdk          # binary alias
#     display_name: Deepskopion SDK     # shown in help / version
#
# Defaults to "routertl" / "RouteRTL SDK" when not set.


@cli_resilient(
    "branding config",
    default={"cli_name": "routertl", "display_name": "RouteRTL SDK"},
)
def _resolve_branding():
    """Read branding config from project.yml in CWD."""
    import yaml

    defaults = {"cli_name": "routertl", "display_name": "RouteRTL SDK"}
    with open("project.yml", "r") as f:
        config = yaml.safe_load(f) or {}
    branding = config.get("branding", {})
    return {
        "cli_name": branding.get("cli_name", defaults["cli_name"]),
        "display_name": branding.get("display_name", defaults["display_name"]),
    }


_BRANDING = _resolve_branding()
CLI_NAME = _BRANDING["cli_name"]
"""The effective CLI binary name (e.g. 'routertl' or 'dskopsdk')."""
DISPLAY_NAME = _BRANDING["display_name"]
"""Human-readable SDK name for help text (e.g. 'RouteRTL SDK' or 'Deepskopion SDK')."""
# Configure rich-click to match RouteRTL's aesthetic
click.rich_click.TEXT_MARKUP = "rich"
click.rich_click.SHOW_ARGUMENTS = True
click.rich_click.GROUP_ARGUMENTS_OPTIONS = True
click.rich_click.STYLE_ERRORS_SUGGESTION = "magenta italic"
click.rich_click.ERRORS_SUGGESTION = "Try running '--help' for more information."

# Custom Help Layout
_COMMAND_LAYOUT = [
    {
        "name": "🚀 Quickstart",
        "commands": ["init", "status", "doctor", "license", "version", "sdk-path", "help", "completion"],
    },
    {
        "name": "🔨 Hardware Build",
        "commands": [
            "project",
            "synth",
            "implementation",
            "bitstream",
            "linting",
            "hierarchy",
            "schematic",
            "fpga",
        ],
    },
    {
        "name": "🧪 Verification",
        "commands": [
            "sim",
            "testgen",
            "scan-tests",
            "waves",
            "regression",
            "view-log",
            "diff",
            "watch",
            "deps",
            "info",
        ],
    },
    {
        "name": "📊 Reporting",
        "commands": ["report", "telemetry"],
    },
    {
        "name": "📦 Workspace Management",
        "commands": ["workspace", "sources", "config", "ci"],
    },
    {
        "name": "🧩 IP & Config Data",
        "commands": ["ip", "regbank", "rom"],
    },
    {
        "name": "🐧 Embedded Linux",
        "commands": ["linux"],
    },
    {
        "name": "🐳 Docker Environments",
        "commands": ["docker"],
    },
    {
        "name": "🔧 EDA Tool Management",
        "commands": ["eda"],
    },
]

click.rich_click.COMMAND_GROUPS = {
    CLI_NAME: _COMMAND_LAYOUT,
}

import importlib.metadata
import logging


def _load_plugins(group):
    """
    Discover and load external CLI commands via entry points.

    Third-party packages expose Click commands/groups by registering
    entry points under the ``routertl.plugins`` group in their
    ``pyproject.toml``::

        [project.entry-points."routertl.plugins"]
        my_tool = "my_package.cli:my_command"

    Each entry point must resolve to a :class:`click.Command`.
    Plugins that fail to load are skipped with a warning.
    """
    loaded = []
    plugin_eps = []
    with cli_resilient_block("plugin entry point discovery"):
        eps = importlib.metadata.entry_points()
        # Python 3.12+ returns a SelectableGroups; 3.9-3.11 returns dict
        if hasattr(eps, "select"):
            plugin_eps = eps.select(group=group)
        elif isinstance(eps, dict):
            plugin_eps = eps.get(group, [])
        else:
            plugin_eps = [ep for ep in eps if ep.group == group]

    for ep in plugin_eps:
        try:
            cmd = ep.load()
            if isinstance(cmd, click.Command):
                loaded.append((ep.name, cmd))
            else:
                logging.warning(
                    f"Plugin '{ep.name}' did not resolve to a Click command (got {type(cmd).__name__}). Skipping."
                )
        except (ImportError, AttributeError, TypeError) as exc:
            logging.warning(f"Failed to load plugin '{ep.name}': {exc}")

    return loaded


@click.group(name=CLI_NAME, context_settings=dict(help_option_names=["-h", "--help"]))
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose output and expanded plugin logging.")
@click.version_option(version=__version__, prog_name=DISPLAY_NAME)
@click.pass_context
def cli(ctx, verbose):
    """The Hybrid Hardware Development Engine."""
    ctx.ensure_object(dict)
    ctx.obj["VERBOSE"] = verbose

    if verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(message)s")
    else:
        logging.basicConfig(level=logging.INFO, format="%(message)s")

    # ── Telemetry instrumentation ──
    from sdk.telemetry.collector import TelemetryCollector

    collector = TelemetryCollector()
    collector.start()
    ctx.obj["_telemetry"] = collector

    @ctx.call_on_close
    def _record_telemetry():
        """Record the CLI invocation after the command finishes."""
        invoked = ctx.invoked_subcommand or "help"
        exit_code = ctx.obj.get("_exit_code", 0)
        collector.stop_and_record(
            command=invoked,
            exit_code=exit_code,
        )


# Dynamic docstring — Click reads __doc__ for help text
cli.__doc__ = (
    f"[bold cyan]{DISPLAY_NAME}[/] — The Hybrid Hardware Development Engine\n\n"
    "This CLI manages Vivado/Cocotb/Linux project lifecycles, ensuring\n"
    "strict reproducibility and zero-friction embedded generation.\n\n"
    f"[dim]v{__version__}  •  © 2026 Daniel J. Mazure  •  MIT + Proprietary[/]"
)


@cli.command()
def version():
    """Show the SDK version and exit."""
    from routertl_core import __copyright__, __version__

    _console.print(
        Panel(
            Text.from_markup(
                f"[bold cyan]{DISPLAY_NAME}[/] v[bold]{__version__}[/]\n"
                f"[dim]{__copyright__}[/]\n"
                f"[dim]MIT License[/]"
            ),
            border_style="cyan",
            padding=(0, 2),
            expand=False,
        )
    )


@cli.command(name="sdk-path")
def sdk_path_cmd():
    """Print the resolved SDK root path and exit.

    Useful for Makefiles and scripts that need to locate the SDK
    regardless of whether it was installed via pip or git submodule:

    \b
        SDK_ROOT := $(shell rr sdk-path 2>/dev/null || echo vendor/routertl)
    """
    from sdk.cli.sdk_root import resolve_sdk_root

    root = resolve_sdk_root()
    if root is None:
        sys.exit(1)
    click.echo(str(root))


def _default_sdk_path() -> str:
    """Resolve the default --sdk-path value for `rr init`."""
    from sdk.cli.sdk_root import resolve_sdk_root

    root = resolve_sdk_root()
    return str(root) if root else "vendor/routertl"


@cli.command()
@click.option("--template", "-t", default=None, help="Initialize from a template (e.g., blinky, counter, axi).")
@click.option("--list-templates", is_flag=True, help="List available project templates and exit.")
@click.option("--name", default=None, help="Project name (used with --template).")
@click.option("--sdk-path", default=None, help="Path to RouteRTL SDK root (auto-detected if omitted).")
@click.option("--no-venv", is_flag=True, help="Skip Python virtual environment configuration.")
@click.option("-y", "--non-interactive", is_flag=True, help="Run in non-interactive mode.")
def init(template, list_templates, name, sdk_path, no_venv, non_interactive):
    """Initialize a new RouteRTL FPGA project."""
    import subprocess

    # Locate init_project.py relative to the CLI's installation path
    this_dir = os.path.dirname(os.path.abspath(__file__))
    tools_dir = os.path.dirname(this_dir)
    init_script = os.path.join(tools_dir, "engine", "init_project.py")

    if not os.path.exists(init_script):
        _console.print(f"❌ [red]Error: Cannot locate init_project.py at {init_script}[/]")
        sys.exit(1)

    # Resolve SDK path: explicit > auto-detect > default
    if sdk_path is None:
        sdk_path = _default_sdk_path()

    # Build subprocess args
    cmd = [sys.executable, init_script]
    if list_templates:
        cmd.append("--list-templates")
    if template:
        cmd.extend(["--template", template])
    if name:
        cmd.extend(["--name", name])
    cmd.extend(["--sdk-path", sdk_path])
    if no_venv:
        cmd.append("--no-venv")
    if non_interactive:
        cmd.append("--non-interactive")

    try:
        result = subprocess.run(cmd)
        if result.returncode != 0:
            sys.exit(result.returncode)
    except KeyboardInterrupt:
        _console.print("\n[yellow]Initialization aborted.[/]")
        return

    # P2.81: Auto-generate build_env.mk so the build system works immediately
    if not list_templates and os.path.exists("project.yml"):
        with cli_resilient_block("auto update-config after init"):
            from sdk.cli.commands.workspace import _run_update_config
            _console.print("\n🔧 [blue]Generating build configuration...[/]")
            _run_update_config(exit_on_error=False)


@cli.command(name="help")
@click.argument("command_name", required=False)
@click.pass_context
def help_cmd(ctx, command_name):
    """
    Display deep, interactive manual-page documentation for a command.
    """
    import subprocess

    if not command_name:
        # Header
        header = Text()
        header.append(f"📘 {DISPLAY_NAME} ", style="bold cyan")
        header.append("— Command Reference", style="dim")
        _console.print(Panel(header, border_style="cyan", padding=(0, 1)))
        _console.print()

        # Command descriptions for the help index
        cmd_descriptions = {
            "init": "Initialize a new FPGA project",
            "status": "Project health dashboard",
            "doctor": "Environment health check (flutter-doctor style)",
            "license": "Deep license diagnostic (FlexLM family validation)",
            "version": "Show SDK version",
            "sdk-path": "Print the resolved SDK root path (Makefile-friendly)",
            "help": "Deep manual-page documentation",
            "completion": "Generate shell completions",
            "project": "Generate FPGA project files",
            "synth": "Synthesis validation status board (list, batch, discover)",
            "implementation": "Run implementation / Place & Route (alias: impl)",
            "bitstream": "Generate bitstream (alias: bit)",
            "linting": "HDL smart linter (alias: lint)",
            "hierarchy": "Design hierarchy viewer & project forest",
            "schematic": "SVG schematic generator",
            "fpga": "FPGA toolchain queries — device families, parts, licenses",
            "sim": "Run cocotb simulation",
            "testgen": "Generate test boilerplates",
            "scan-tests": "List available tests",
            "waves": "Open waveform viewer",
            "regression": "Run regression suite",
            "view-log": "View simulation log",
            "diff": "Impact analysis from git diff",
            "watch": "Auto-rerun on file changes",
            "deps": "Dependency tree, graph export, and IP fetch",
            "info": "RTL entity/module inspector — ports, generics, deps",
            "report": "Unified project report (lint + sim + synthesis)",
            "telemetry": "Manage local SDK telemetry data",
            "workspace": "Config & workspace management (alias: ws)",
            "sources": "List project source files by category (syn/sim/xdc/ip)",
            "config": "Read/write project.yml fields — beautiful Rich display via 'list'",
            "ci": "CI/CD pipeline management (generate GitHub/GitLab configs)",
            "ip": "IP manifest management (init, list, hierarchy, update)",
            "regbank": "Register bank tools",
            "rom": "ROM data generation",
            "linux": "Embedded Linux tools",
            "docker": "Docker dev environments",
            "eda": "Native EDA tool management (status, add-device, add-patch)",
        }

        for group in click.rich_click.COMMAND_GROUPS.get(CLI_NAME, []):
            table = Table(
                show_header=False,
                box=None,
                padding=(0, 2),
                expand=True,
            )
            table.add_column("Command", style="bold cyan", min_width=18)
            table.add_column("Description", style="dim")
            for cmd in group["commands"]:
                desc = cmd_descriptions.get(cmd, "")
                table.add_row(cmd, desc)

            _console.print(
                Panel(
                    table,
                    title=f"[bold]{group['name']}[/bold]",
                    title_align="left",
                    border_style="bright_black",
                    padding=(0, 1),
                )
            )

        _console.print()
        _console.print(f"  [dim]Usage:[/dim]  [bold yellow]{CLI_NAME} help <command>[/bold yellow]")
        _console.print(f"  [dim]Example:[/dim] [cyan]{CLI_NAME} help docker[/cyan]")
        _console.print()
        return

    # Map CLI command name to its underlying Makefile target string (if different)
    # Also map group names to their anchor targets in the documentation
    target_map = {
        "npm-synthesis": "npm-synthesis",
        "regbank": "regbank",
        "docker": "docker",
        "docker-build": "docker-build",
        "docker-shell": "docker-shell",
        "docker-run": "docker-run",
        "scan-tests": "scan-tests",
    }
    make_target = target_map.get(command_name, command_name)

    # Locate the markdown help parser
    this_dir = os.path.dirname(os.path.abspath(__file__))
    tools_dir = os.path.dirname(this_dir)
    help_script = os.path.join(tools_dir, "engine", "show_target_help.py")

    if not os.path.exists(help_script):
        _console.print(f"❌ [red]Error: Cannot locate documentation engine at {help_script}[/]")
        sys.exit(1)

    # Execute the deep parser
    result = subprocess.run([sys.executable, help_script, make_target], capture_output=True, text=True)

    if result.returncode != 0:
        click.echo(result.stdout)  # show_target_help.py prints error to stdout
        sys.exit(result.returncode)

    click.echo(result.stdout)


cli.add_command(help_cmd)
cli.add_command(status)
cli.add_command(project_group)
# Note: 'synth' name is now used by synth_group (status board and run).
cli.add_command(npm_synthesis)  # hidden, deprecated — kept for backward compat
cli.add_command(impl_group)
cli.add_command(impl_group, name="impl")  # shortcut alias
cli.add_command(bitstream_group)
cli.add_command(bitstream_group, name="bit")  # shortcut alias
cli.add_command(linting)
cli.add_command(linting, name="lint")  # shortcut alias
cli.add_command(hierarchy)
cli.add_command(synth_targets)
cli.add_command(schematic)
cli.add_command(sim_command)
cli.add_command(testgen)
cli.add_command(workspace_group)
cli.add_command(workspace_group, name="ws")  # shortcut alias
cli.add_command(regbank_group)
cli.add_command(rom)
cli.add_command(ip_group)
cli.add_command(linux_group)
cli.add_command(docker_group)
cli.add_command(eda_group)
cli.add_command(scan_tests)
cli.add_command(waves)
cli.add_command(regression)
cli.add_command(view_sim_log)
cli.add_command(diff_command)
cli.add_command(completion_command)
cli.add_command(watch_command)
cli.add_command(deps_group)
cli.add_command(sources_command)
cli.add_command(info_command)
cli.add_command(doctor)
cli.add_command(license_command)
cli.add_command(report_command)
cli.add_command(config_command)
cli.add_command(fpga_group)
cli.add_command(synth_group)
cli.add_command(ci_group)
cli.add_command(telemetry_group)

# ── Plugin Discovery ──
for _plugin_name, _plugin_cmd in _load_plugins("routertl.plugins"):
    cli.add_command(_plugin_cmd, _plugin_name)


if __name__ == "__main__":
    # ── Universal trailing "help" interceptor ──
    # Accept: rr docker help → rr docker --help
    # Accept: rr docker install help → rr docker install --help
    if len(sys.argv) > 1 and sys.argv[-1] == "help":
        sys.argv[-1] = "--help"
    cli(prog_name=CLI_NAME)
