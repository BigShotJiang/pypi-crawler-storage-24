# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Doctor Check Framework
======================

Provides the ``CheckResult`` data class and ``CheckRegistry`` for
self-registering health checks used by ``rr doctor``.

Each check module in this package calls ``@CheckRegistry.register()``
at import time.  The doctor command simply calls
``CheckRegistry.run_all()`` to execute every registered check in order.

Adding a new check
------------------
1. Create a function in the appropriate module (or a new module).
2. Decorate it with ``@CheckRegistry.register("My Check", order=N)``.
3. Import the module in the ``_import_all_checks()`` call below.
"""

from __future__ import annotations

from typing import Callable

# ──────────────────────────────────────────────────────────────
# Result model
# ──────────────────────────────────────────────────────────────


class CheckResult:
    """Single health-check result."""

    OK = "ok"
    WARN = "warn"
    FAIL = "fail"

    def __init__(self, title, status, detail, fix=None, fix_cmd=None):
        """Create a diagnostic check result.

        Args:
            title: Short name for this check (e.g. "Git Hooks").
            status: One of OK / WARN / FAIL.
            detail: Human-readable status detail.
            fix: Optional prose description of how to fix the issue.
            fix_cmd: Optional exact CLI command to fix the issue
                     (rendered in cyan for copy-paste).
        """
        self.title = title
        self.status = status
        self.detail = detail
        self.fix = fix
        self.fix_cmd = fix_cmd

    def icon(self):
        """Return a status icon emoji for this check result."""
        return {"ok": "✅", "warn": "⚠️", "fail": "❌"}.get(self.status, "❓")


# ──────────────────────────────────────────────────────────────
# Check registry
# ──────────────────────────────────────────────────────────────


class CheckRegistry:
    """Registry for self-registering doctor health checks."""

    _checks: list[tuple[int, str, Callable]] = []

    @classmethod
    def register(cls, name: str, order: int = 100):
        """Decorator to register a doctor check function.

        Parameters
        ----------
        name:
            Human-readable name for the check (used in logs).
        order:
            Sort key — lower values run first.  Use increments of 10
            to leave room for future insertions.
        """

        def decorator(fn):
            cls._checks.append((order, name, fn))
            return fn

        return decorator

    @classmethod
    def run_all(cls) -> list[CheckResult]:
        """Execute all registered checks in order and return results."""
        results: list[CheckResult] = []
        for _order, _name, fn in sorted(cls._checks, key=lambda t: t[0]):
            result = fn()
            if isinstance(result, list):
                results.extend(result)
            else:
                results.append(result)
        return results

    @classmethod
    def clear(cls):
        """Remove all registered checks (for testing)."""
        cls._checks.clear()


def _import_all_checks():
    """Import every check module to trigger registration."""
    from sdk.cli.checks import (  # noqa: F401
        environment,
        simulators,
        vendor_tools,
        workspace,
    )


_import_all_checks()
