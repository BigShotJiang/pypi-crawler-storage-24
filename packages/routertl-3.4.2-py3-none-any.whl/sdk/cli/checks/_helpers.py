# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Shared utility helpers for doctor health checks.

These functions are used across multiple check modules but are not
part of the public API.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

import yaml

from sdk.cli.resilience import cli_resilient

# ──────────────────────────────────────────────────────────────
# CLI name resolution
# ──────────────────────────────────────────────────────────────


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


# ──────────────────────────────────────────────────────────────
# Utility helpers
# ──────────────────────────────────────────────────────────────


def _run(cmd, timeout=10, env=None):
    """Run a command and return (returncode, stdout+stderr)."""
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
        )
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except FileNotFoundError:
        return 1, ""
    except subprocess.TimeoutExpired:
        return 1, ""
    except (OSError, ValueError, subprocess.SubprocessError):
        return 1, ""


def _which(binary):
    """Resolve binary on PATH."""
    return shutil.which(binary)


def _parse_version(text, pattern):
    """Extract a version string from text using a regex with group(1)."""
    m = re.search(pattern, text)
    return m.group(1) if m else None


def _ver_tuple(v):
    """Convert '3.10.2' to (3, 10, 2)."""
    return tuple(int(x) for x in str(v).split("."))


def _sdk_root():
    """Locate the SDK root (path-agnostic)."""
    from sdk.cli.sdk_root import resolve_sdk_root

    return resolve_sdk_root()


def _load_project_yml():
    """Load project.yml from cwd."""
    p = Path("project.yml")
    if not p.exists():
        return None
    try:
        with open(p) as f:
            return yaml.safe_load(f)
    except (yaml.YAMLError, OSError):
        return None


def _detect_docker_container():
    """Detect if running inside a RouteRTL Docker container.

    Returns the container type (e.g. 'riviera', 'quartus', 'vivado', 'questa')
    or None if not in a Docker container.
    """
    marker = os.environ.get("ROUTERTL_DOCKER_ENV")
    if marker:
        return marker

    # Fallback: check for /.dockerenv
    if Path("/.dockerenv").exists():
        return "unknown"

    return None
