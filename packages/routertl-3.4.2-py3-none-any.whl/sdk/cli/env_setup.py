# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
SDK Environment Setup — replicate the env vars that Make sets.

This module reads ``project.yml`` and configures the environment so that
Python scripts (run_tests.py, smart_linter.py, etc.) can be invoked
directly without going through Make.

The env-var contract between Make and Python is the real API:

- ``ROUTERTL_ROOT``:       SDK root path
- ``CLIENT_PROJECT_ROOT``: Consumer project root (CWD)
- ``PYTHONPATH``:          Includes SDK sim engine + project root
- ``ROUTERTL_WAVES_DIR``:  Where waveforms are written
- ``ROUTERTL_LOGS_DIR``:   Where sim logs are written
- ``CLIENT_SIM_WORK``:     Simulation work directory
- ``SIM``:                 Simulator backend (nvc, ghdl, verilator, icarus)
- ``WAVES``:               (Not set by SDK — engine-managed via project.yml)
"""

import os
import sys
from pathlib import Path

import yaml

from sdk.cli.resilience import cli_resilient_block
from sdk.cli.sdk_root import resolve_sdk_root


def _load_project_config() -> dict:
    """Load project.yml from CWD, returning empty dict on failure."""
    yml = Path("project.yml")
    if not yml.exists():
        return {}
    with cli_resilient_block("project.yml loading"):
        with open(yml) as f:
            return yaml.safe_load(f) or {}
    return {}


def setup_sim_env(*, seed: int | None = None) -> dict:
    """Configure environment for simulation script execution.

    Returns the env dict (a copy of os.environ with SDK vars injected).
    """
    sdk_root = resolve_sdk_root()
    if sdk_root is None:
        from sdk.cli.console import console

        console.print("[bold red]❌ Cannot locate SDK root for simulation.[/]")
        sys.exit(1)

    config = _load_project_config()
    project_root = Path.cwd()

    # Resolve simulation paths from project.yml
    sim_cfg = config.get("simulation") or {}
    if not isinstance(sim_cfg, dict):
        sim_cfg = {}
    test_dir = sim_cfg.get("test_dir", "sim/cocotb/tests")
    simulator = sim_cfg.get("simulator", os.environ.get("SIM", "nvc"))

    # Resolve source paths
    paths_cfg = config.get("paths") or {}
    if not isinstance(paths_cfg, dict):
        paths_cfg = {}
    sim_path = paths_cfg.get("sim", "sim")

    # Build env
    env = os.environ.copy()
    env["ROUTERTL_ROOT"] = str(sdk_root)
    env["CLIENT_PROJECT_ROOT"] = str(project_root)
    env["CLIENT_SIM_WORK"] = str(project_root / test_dir / ".." / ".." / "work")
    env["ROUTERTL_WAVES_DIR"] = str(project_root / sim_path / "waves")
    env["ROUTERTL_LOGS_DIR"] = str(project_root / sim_path / "cocotb" / "logs")
    env["SIM"] = simulator
    # NOTE: Do NOT set the WAVES env var here.  The engine's
    # run_simulation() handles wave enable/disable internally (reading
    # simulation.waves.enabled from project.yml) and passes the result
    # to cocotb_tools.runner.test() as a kwarg.  runner.test() does
    #   self.waves = bool(int(os.getenv("WAVES", waves)))
    # so any WAVES in the env overrides the engine's decision.  By not
    # setting it, the runner respects the kwarg from the engine.
    # Users who need a CI override can still do: WAVES=0 rr sim ...

    if seed is not None:
        env["RANDOM_SEED"] = str(seed)

    # PYTHONPATH: project root + SDK sim engine + SDK cocotb
    extra_paths = [
        str(project_root),
        str(sdk_root / "sim" / "cocotb" / "engine"),
        str(sdk_root / "sim" / "cocotb"),
        str(sdk_root),
    ]
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = ":".join(extra_paths + ([existing] if existing else []))

    return env


def resolve_sim_dir() -> Path:
    """Resolve the simulation test directory from project.yml or defaults."""
    config = _load_project_config()
    sim_cfg = config.get("simulation") or {}
    if not isinstance(sim_cfg, dict):
        sim_cfg = {}
    test_dir = sim_cfg.get("test_dir", "sim/cocotb/tests")
    return Path(test_dir)


def _get_sdk_units_dir() -> Path | None:
    """Return the SDK ``src/units/`` path when pip-installed.

    In the submodule workflow, consumers list ``vendor/routertl/src/units``
    explicitly in ``project.yml``.  When the SDK is pip-installed there is
    no submodule, so the utility entities (``edge_detector``, ``infilter``,
    ``fifo_xpm_sync``, …) would be invisible to linting and synthesis.

    Returns ``None`` when a vendor submodule is present (the user manages
    paths manually) or when the SDK root can't be resolved.
    """
    from sdk.cli.sdk_root import _SUBMODULE_CANDIDATES

    for sub in _SUBMODULE_CANDIDATES:
        if sub.is_dir():
            return None  # submodule present — user manages paths
    sdk_root = resolve_sdk_root()
    if sdk_root is None:
        return None
    units = sdk_root / "src" / "units"
    return units if units.is_dir() else None


def resolve_src_dirs() -> list[str]:
    """Resolve source directories from build_env.mk or project.yml.

    When the SDK is pip-installed (no vendor submodule), the SDK's
    ``src/units/`` directory is auto-appended so that utility entities
    like ``edge_detector`` and ``infilter`` are discoverable by the
    dependency resolver, linter, and synthesis tools.
    """
    dirs: list[str] = []

    # Try build_env.mk first (generated by project_manager.py)
    from sdk.cli.engine_dispatch import read_build_env

    benv = read_build_env()
    src_dir_str = benv.get("SRC_DIR")
    if src_dir_str:
        dirs = src_dir_str.split()

    # Fallback to project.yml
    if not dirs:
        config = _load_project_config()
        paths_cfg = config.get("paths") or {}
        if isinstance(paths_cfg, dict):
            sources = paths_cfg.get("sources", "src")
            if isinstance(sources, list):
                dirs = list(sources)
            else:
                dirs = [str(sources)]
        else:
            dirs = ["src"]

    # Auto-inject SDK utility units for pip-installed consumers
    sdk_units = _get_sdk_units_dir()
    if sdk_units and str(sdk_units) not in dirs:
        dirs.append(str(sdk_units))

    return dirs


def inject_tool_path(env: dict, tool_path: str) -> dict:
    """Inject a vendor ``hardware.tool_path`` into *env*'s ``PATH``.

    Probes common subdirectory layouts used by different vendors:

    - ``quartus/bin``  — Intel Quartus Prime
    - ``bin``          — Xilinx Vivado, generic
    - ``bin/lin64``    — Lattice Radiant
    - ``Libero/bin``   — Microchip Libero SoC

    The first matching directory is prepended to ``PATH`` in *env*.
    The original *env* dict is **not** mutated; a shallow copy is returned.

    Parameters
    ----------
    env : dict
        Environment dict (typically ``os.environ.copy()``).
    tool_path : str
        Root path to the vendor tool installation.

    Returns
    -------
    dict
        Updated copy of *env* with ``PATH`` prepended, or the original
        *env* unchanged if no matching subdirectory exists.
    """
    tp = Path(tool_path)
    for sub in ["quartus/bin", "bin", "bin/lin64", "Libero/bin"]:
        candidate = tp / sub
        if candidate.is_dir():
            env = dict(env)  # shallow copy
            env["PATH"] = f"{candidate}:{env.get('PATH', '')}"
            return env
    return env


def resolve_sdk_script(script_name: str) -> Path | None:
    """Locate a script within the SDK's tools directory.

    Parameters
    ----------
    script_name : str
        Relative path from ``sdk/``, e.g.
        ``project-manager/run_tests.py``.

    Returns
    -------
    Path or None
        Absolute path to the script, or None if not found.
    """
    sdk_root = resolve_sdk_root()
    if sdk_root is None:
        return None

    # Try legacy tools/ layout first (backward compat shim)
    candidate = sdk_root / "tools" / script_name
    if candidate.exists():
        return candidate

    # Try current sdk/engine/ layout (handles project-manager/ → engine/ rename)
    basename = Path(script_name).name  # e.g. "run_tests.py"
    candidate = sdk_root / "sdk" / "engine" / basename
    if candidate.exists():
        return candidate

    return None
