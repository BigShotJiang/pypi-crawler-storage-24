# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Shared Rich console instance for the RouteRTL CLI.

All CLI commands should import ``console`` from this module instead of
creating their own instances.

For subprocess contexts where stdout is piped (e.g. the smart linter),
use ``get_console()`` which auto-detects TTY status from stderr.

Usage::

    from sdk.cli.console import console, success, warning, error

    console.print(f"[cyan]Info:[/] something happened")
    success("Build passed")
    warning("Missing optional dependency")
    error("File not found")

    # In subprocess-piped contexts:
    from sdk.cli.console import get_console
    _con = get_console()   # inherits TTY from stderr
"""

import sys

from rich.console import Console

console = Console()


def get_console() -> Console:
    """Return a Console tuned for the current execution context.

    When stdout is piped (common when invoked as a subprocess),
    Rich disables markup rendering.  This factory inherits TTY
    status from stderr — which stays connected to the real
    terminal — so that ``[green]PASS[/]`` renders as coloured text.

    If stderr is also not a TTY (e.g. CI logs), markup is
    disabled to avoid literal tag leakage.
    """
    return Console(force_terminal=sys.stderr.isatty())


def success(msg: str) -> None:
    """Print a green success message."""
    console.print(f"[green]{msg}[/]")


def warning(msg: str) -> None:
    """Print a yellow warning message."""
    console.print(f"[yellow]{msg}[/]")


def error(msg: str) -> None:
    """Print a red error message."""
    console.print(f"[red]{msg}[/]")
