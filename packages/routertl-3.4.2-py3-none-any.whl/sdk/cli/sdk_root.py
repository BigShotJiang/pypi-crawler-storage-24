# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
SDK Root Resolver — Single Source of Truth.

Every CLI command that needs to locate SDK files (VERSION, sdk/,
sim/, hooks, etc.) must use :func:`resolve_sdk_root` instead of
hardcoding ``vendor/routertl``.

Resolution order
----------------
1. ``$ROUTERTL_ROOT`` environment variable (explicit override)
2. ``vendor/routertl/`` relative to CWD (backward-compat submodule)
3. ``__file__`` traversal: this file → cli/ → sdk/ → SDK root
4. ``None`` if nothing found

The resolver validates each candidate by checking for the ``VERSION``
file at the candidate root.  This file is present in every SDK checkout.
"""

import os
from pathlib import Path

# Candidates checked in CWD for backward-compatible submodule detection.
_SUBMODULE_CANDIDATES = [
    Path("vendor/routertl"),
    Path("vendor/rapidrtl"),
]

# This file lives at:  <SDK_ROOT>/sdk/cli/sdk_root.py
#                       ^^^^^^^^^^^      ^^^^^^^^^^^^^^
#                       3 parents up
_THIS_FILE = Path(__file__).resolve()


def resolve_sdk_root() -> Path | None:
    """Resolve the SDK root directory, regardless of install method.

    Returns
    -------
    Path or None
        Absolute path to the SDK root, or ``None`` if the SDK cannot
        be located.
    """
    # 1. Explicit env var takes priority
    env_root = os.environ.get("ROUTERTL_ROOT")
    if env_root:
        candidate = Path(env_root).resolve()
        if _is_sdk_root(candidate):
            return candidate

    # 2. Submodule in CWD (backward compat)
    for sub in _SUBMODULE_CANDIDATES:
        if _is_sdk_root(sub):
            return sub.resolve()

    # 3. __file__ traversal: sdk_root.py → cli/ → tools/ → SDK root
    file_based = _THIS_FILE.parent.parent.parent
    if _is_sdk_root(file_based):
        return file_based

    # 4. Nothing found
    return None


def _is_sdk_root(path: Path) -> bool:
    """Check whether *path* looks like an SDK root.

    Accepts two sentinels:
    - ``VERSION`` file (present in source checkouts and sdist)
    - ``sdk/cli/`` directory (present in pip wheels where VERSION is absent)
    """
    return (path / "VERSION").exists() or (path / "sdk" / "cli").is_dir()


def resolve_sdk_root_or_exit() -> Path:
    """Like :func:`resolve_sdk_root` but exits with a helpful error.

    Use this in CLI commands where the SDK root is mandatory.
    """
    import sys

    from sdk.cli.console import console

    root = resolve_sdk_root()
    if root is None:
        console.print("[bold red]❌ Could not locate SDK root.[/]")
        console.print(
            "   Set [cyan]$ROUTERTL_ROOT[/] or run from a directory "
            "containing [cyan]vendor/routertl/[/]."
        )
        sys.exit(1)
    return root
