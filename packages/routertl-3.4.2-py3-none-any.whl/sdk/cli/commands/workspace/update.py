# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Workspace update commands — source scanning and SDK update."""

import subprocess
import sys

import rich_click as click

from sdk.cli.commands.workspace import (
    _fix_makefile_include,
    _inject_venv_completion,
    _inject_venv_environment,
    _run_make,
    _run_update_config,
    _sync_gitignore_prebuild_outputs,
    workspace_group,
)
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient, cli_resilient_block


@workspace_group.command(name="update")
@click.option("--all", "update_all", is_flag=True, help="Update all source lists")
@click.option("--src", is_flag=True, help="Update synthesis sources")
@click.option("--sim", is_flag=True, help="Update simulation testbenches")
@click.option("--xdc", is_flag=True, help="Update constraint files")
@click.option("--tcl", is_flag=True, help="Update TCL hooks")
@click.option("--mmap", is_flag=True, help="Update memory map from YAML")
@click.option("--ips", is_flag=True, help="Update IP manifest source lists")
def update(update_all, src, sim, xdc, tcl, mmap, ips):
    """Scan directories and update project.yml source lists."""
    from sdk.cli.engine_dispatch import (
        ScriptNotFound,
        ensure_build_env,
        run_engine_script,
    )

    env = ensure_build_env()
    project_yml = env.get("PROJECT_YML", "project.yml")
    base_args = ["--project", project_yml]

    def _run_scan(*extra_args):
        try:
            result = run_engine_script("scan_sources.py", base_args + list(extra_args))
            if result.returncode != 0:
                sys.exit(result.returncode)
        except ScriptNotFound:
            # Fallback to Make for submodule installs
            _run_make("update-all")

    if update_all or not any([src, sim, xdc, tcl, mmap, ips]):
        console.print("🔄 [blue]Updating all workspace sources...[/]")
        _run_scan(
            "--src", env.get("SRC_DIR", "src"),
            "--sim", env.get("SIM_PATH", "sim/cocotb/tests"),
            "--dc", env.get("XDC_DIR", "xdc"),
            "--vendor", env.get("VENDOR", "xilinx"),
            "--tcl", env.get("TCL_SCAN_DIR", "tcl"),
            "--ip-update",
        )
    else:
        if src:
            console.print("🔄 [blue]Updating synthesis sources...[/]")
            _run_scan("--src", env.get("SRC_DIR", "src"))
        if sim:
            console.print("🔄 [blue]Updating simulation testbenches...[/]")
            _run_scan("--sim", env.get("SIM_PATH", "sim/cocotb/tests"))
        if xdc:
            console.print("🔄 [blue]Updating constraint files...[/]")
            _run_scan("--dc", env.get("XDC_DIR", "xdc"), "--vendor", env.get("VENDOR", "xilinx"))
        if tcl:
            console.print("🔄 [blue]Updating TCL hooks...[/]")
            _run_scan("--tcl", env.get("TCL_SCAN_DIR", "tcl"))
        if mmap:
            console.print("🔄 [blue]Updating memory map...[/]")
            _run_make("update-mmap")  # Linux target — stays on Make
        if ips:
            console.print("🔄 [blue]Updating IP manifests...[/]")
            _run_scan("--ip-update")


@workspace_group.command(name="update-config")
def update_config():
    """Update build_env.mk from project.yml"""
    _run_update_config(exit_on_error=True)
    # Refresh environment variables and completion in .venv/bin/activate
    with cli_resilient_block("venv environment injection"):
        _inject_venv_environment()
    with cli_resilient_block("venv completion injection"):
        _inject_venv_completion()
    # Sync pre-build expected_outputs into .gitignore (P2.89)
    with cli_resilient_block("gitignore prebuild sync"):
        _sync_gitignore_prebuild_outputs()


@workspace_group.command(name="update-sdk")
def update_sdk():
    """Update the RouteRTL SDK to the latest version.

    Detects the install mode automatically:

    \b
    • **pip mode** — runs ``pip install --upgrade routertl``
    • **git mode** — pulls the latest commit and re-installs
    """
    from sdk.cli.sdk_root import resolve_sdk_root

    sdk_path = resolve_sdk_root()

    if sdk_path is None:
        console.print("❌ [red]Could not find SDK installation.[/]")
        click.echo("   Set ROUTERTL_ROOT or ensure vendor/routertl exists.")
        sys.exit(1)

    console.print(f"📦 [cyan]SDK location:[/] {sdk_path}")

    # ── Detect install mode ──
    git_backed = (sdk_path / ".git").exists() or (sdk_path / ".git").is_file()

    if not git_backed:
        _update_sdk_pip_mode()
    else:
        _update_sdk_git_mode(sdk_path)


def _update_sdk_pip_mode():
    """Update SDK via pip — for pure pip installs without a git checkout."""
    # ── Read current version ──
    before_version = "unknown"
    with cli_resilient_block("pip package version (before)"):
        from importlib.metadata import version as _meta_version

        before_version = _meta_version("routertl")

    console.print(f"🔄 [blue]Upgrading via pip...[/]  (current: [yellow]v{before_version}[/])")

    # ── Run pip install --upgrade ──
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "routertl"],
        capture_output=True,
        text=True,
        timeout=120,
    )

    if result.returncode != 0:
        console.print("❌ [red]pip upgrade failed:[/]")
        click.echo(result.stderr.strip() or result.stdout.strip())
        sys.exit(1)

    # ── Read new version (invalidate importlib cache) ──
    after_version = "unknown"
    with cli_resilient_block("pip package version (after)"):
        import importlib
        from importlib.metadata import version as _meta_version

        # importlib.metadata caches; reimport to pick up the new version
        importlib.invalidate_caches()
        from importlib import metadata as _md

        _md._cache.clear() if hasattr(_md, "_cache") else None  # noqa: B018
        after_version = _meta_version("routertl")

    if before_version == after_version:
        console.print(f"✅ [green]Already up to date[/] (v{before_version})")
    else:
        console.print(
            f"✅ [green]Updated:[/] "
            f"[yellow]v{before_version}[/] → "
            f"[cyan]v{after_version}[/]"
        )


def _update_sdk_git_mode(sdk_path):
    """Update SDK via git pull — for submodule and editable installs."""
    import os

    # ── Read current version (before) ──
    @cli_resilient("git short SHA", default="unknown")
    def _get_short_sha(path):
        r = subprocess.run(
            ["git", "-C", str(path), "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return r.stdout.strip() if r.returncode == 0 else "unknown"

    before_sha = _get_short_sha(sdk_path)

    # ── Ensure we're on a branch (submodules default to detached HEAD) ──
    console.print("🔄 [blue]Fetching latest SDK changes...[/]")

    # Determine the tracking branch (.gitmodules branch or default 'main')
    track_branch = "main"
    with cli_resilient_block("tracking branch detection"):
        r = subprocess.run(
            ["git", "config", "-f", ".gitmodules", f"submodule.{sdk_path}.branch"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if r.returncode == 0 and r.stdout.strip():
            track_branch = r.stdout.strip()

    # Checkout the tracking branch (no-op if already on it)
    with cli_resilient_block("SDK branch checkout"):
        subprocess.run(
            ["git", "-C", str(sdk_path), "checkout", track_branch],
            capture_output=True,
            text=True,
            timeout=10,
        )

    fetch_env = {
        **os.environ,
        "GIT_SSH_COMMAND": "ssh -o StrictHostKeyChecking=accept-new -o BatchMode=yes",
    }
    try:
        result = subprocess.run(
            ["git", "-C", str(sdk_path), "pull", "--ff-only"],
            capture_output=True,
            text=True,
            timeout=60,
            env=fetch_env,
        )
    except subprocess.TimeoutExpired:
        console.print("❌ [red]Timed out fetching from remote.[/]")
        sys.exit(1)
    except FileNotFoundError:
        console.print("❌ [red]git not found on PATH.[/]")
        sys.exit(1)

    if result.returncode != 0:
        console.print("❌ [red]git pull failed:[/]")
        click.echo(result.stderr.strip() or result.stdout.strip())
        sys.exit(1)

    after_sha = _get_short_sha(sdk_path)

    if before_sha == after_sha:
        console.print(f"✅ [green]Already up to date[/] ({before_sha})")
    else:
        # Count new commits
        count = "?"
        with cli_resilient_block("new commit count"):
            r = subprocess.run(
                ["git", "-C", str(sdk_path), "rev-list", "--count", f"{before_sha}..{after_sha}"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if r.returncode == 0:
                count = r.stdout.strip()

        console.print(
            f"✅ [green]Updated:[/] "
            f"[yellow]{before_sha}[/] → "
            f"[cyan]{after_sha}[/] "
            f"({count} new commit{'s' if count != '1' else ''})"
        )

        # Show one-liner changelog
        with cli_resilient_block("SDK changelog display"):
            r = subprocess.run(
                ["git", "-C", str(sdk_path), "log", "--oneline", f"{before_sha}..{after_sha}"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if r.returncode == 0 and r.stdout.strip():
                console.print("\n[dim]  Changelog:[/]")
                for line in r.stdout.strip().splitlines():
                    console.print(f"    [dim]{line}[/]")
                click.echo()

    # ── Re-install pip package ──
    console.print("📦 [blue]Re-installing SDK package...[/]")
    with cli_resilient_block("SDK package reinstall"):
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-e", str(sdk_path), "-q"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            console.print("✅ [green]SDK package re-installed successfully.[/]")
        else:
            console.print("⚠️  [yellow]pip install returned errors:[/]")
            click.echo(result.stderr.strip() or result.stdout.strip())

    # ── Fix Makefile include path if stale ──
    _fix_makefile_include(sdk_path)

    # ── Regenerate build_env.mk (may be stale against updated Common.mk) ──
    _run_update_config(exit_on_error=False)
