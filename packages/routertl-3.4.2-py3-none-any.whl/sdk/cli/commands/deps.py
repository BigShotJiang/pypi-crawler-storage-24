# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command group: deps — Dependency inspection, graph export, and IP fetch."""


from sdk.cli.resilience import cli_resilient, cli_resilient_block


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


import os
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console


@click.group(name="deps", invoke_without_command=True)
@click.pass_context
def deps_group(ctx):
    """Dependency inspection, graph export, and IP dependency fetch.

    \b
    Subcommands:
        tree     Print entity dependency tree or forest
        fetch    Fetch SDK-bundled IP dependencies declared in ip.yml
        status   Show IP dependency availability
        graph    Export full dependency graph (mermaid, html, json)
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── tree (existing bare deps behavior) ─────────────────────────


@deps_group.command(name="tree")
@click.argument("entity", required=False, default=None)
@click.option("--src", "src_dir", default=None, help="Source directory to scan (default: from project.yml or 'src').")
def deps_tree(entity, src_dir):
    """Print the entity dependency tree or project forest summary.

    Without ENTITY, prints the full forest summary.
    With ENTITY, prints the dependency tree for that entity/module.

    \b
    Examples:
        routertl deps tree                   # print forest summary
        routertl deps tree my_top            # print tree for my_top
    """
    import yaml

    # ── Resolve source directories ──
    if not src_dir:
        src_dirs = [Path("src")]
        if os.path.exists("project.yml"):
            with cli_resilient_block("project YAML source dirs"):
                with open("project.yml", "r") as f:
                    config = yaml.safe_load(f) or {}
                    paths_cfg = config.get("paths") or {}
                    src_raw = paths_cfg.get("sources", "src")
                    if isinstance(src_raw, list):
                        src_dirs = [Path(d) for d in src_raw]
                    else:
                        src_dirs = [Path(src_raw)]
    else:
        src_dirs = [Path(src_dir)]

    existing = [d for d in src_dirs if d.exists()]
    if not existing:
        console.print(f"⚠️  [yellow]No source directories found: {[str(d) for d in src_dirs]}[/]")
        sys.exit(1)

    # Lazy import
    from sdk.engine.dependency_resolver import DependencyResolver

    resolver = DependencyResolver(existing, verbose=False)

    if not entity:
        # Show forest summary
        forest = resolver.resolve_forest()
        trees = forest.get("trees") or []
        orphans = forest.get("orphans") or []

        console.print("\n🌳 [cyan]Project Dependency Forest[/]")
        console.print(f"   {len(trees)} tree(s), {len(orphans)} orphan(s)\n")

        for t in trees:
            weight = t["weight"]
            console.print(
                f"   [green]▸[/] [cyan]{t['top']}[/]  ({weight} file{'s' if weight != 1 else ''})"
            )

        if orphans:
            console.print("\n   [yellow]Orphans:[/]")
            for o in orphans:
                console.print(f"     [dim]{Path(o).name}[/]")

        console.print(f"\n   [dim]Use: {_cli_name()} deps tree <entity> for detailed tree[/]")
        console.print(f"   [dim]Use: {_cli_name()} deps graph mermaid|html|json[/]")
        return

    # Print tree for specific entity
    if entity not in resolver.entity_map and entity not in resolver.package_map:
        console.print(f"❌ [red]Entity/module '{entity}' not found in source tree.[/]")
        sys.exit(1)

    console.print(f"\n🌳 [cyan]Dependency Tree: {entity}[/]")
    click.echo("=" * 50)
    resolver.print_tree(entity)
    click.echo()


# ── graph ──────────────────────────────────────────────────────


@deps_group.command(name="graph")
@click.argument("fmt", type=click.Choice(["mermaid", "html", "json"]))
@click.option("--src", "src_dir", default=None, help="Source directory to scan.")
@click.option("-o", "--output", "output_file", default=None, help="Write graph output to a file.")
def deps_graph(fmt, src_dir, output_file):
    """Export the full dependency graph as Mermaid, HTML, or JSON.

    \b
    Examples:
        routertl deps graph mermaid            # Mermaid to stdout
        routertl deps graph html -o deps.html  # interactive HTML
        routertl deps graph json               # JSON to stdout
    """
    import yaml

    if not src_dir:
        src_dirs = [Path("src")]
        if os.path.exists("project.yml"):
            with cli_resilient_block("project YAML source dirs"):
                with open("project.yml", "r") as f:
                    config = yaml.safe_load(f) or {}
                    paths_cfg = config.get("paths") or {}
                    src_raw = paths_cfg.get("sources", "src")
                    if isinstance(src_raw, list):
                        src_dirs = [Path(d) for d in src_raw]
                    else:
                        src_dirs = [Path(src_raw)]
    else:
        src_dirs = [Path(src_dir)]

    existing = [d for d in src_dirs if d.exists()]
    if not existing:
        console.print(f"⚠️  [yellow]No source directories found: {[str(d) for d in src_dirs]}[/]")
        sys.exit(1)

    from sdk.engine.dependency_resolver import DependencyResolver

    resolver = DependencyResolver(existing, verbose=False)
    result = resolver.export_graph(fmt=fmt)

    if output_file:
        Path(output_file).write_text(result, encoding="utf-8")
        console.print(f"✅ [green]Graph exported to [cyan]{output_file}[/][/]")
    else:
        click.echo(result)


# ── fetch (P2.81) ─────────────────────────────────────────────


@deps_group.command(name="fetch")
@click.option("--dest", default="deps", help="Destination directory for fetched IPs (default: deps/).")
@click.option("--dry-run", is_flag=True, help="Preview what would be fetched without copying.")
def deps_fetch(dest, dry_run):
    """Fetch SDK-bundled IP dependencies declared in ip.yml manifests.

    Reads project.yml → sources.ips → each ip.yml → dependencies, then
    resolves and copies SDK-bundled IP source files into a local directory.

    \b
    Examples:
        routertl deps fetch                  # fetch into deps/
        routertl deps fetch --dest lib/sdk   # custom destination
        routertl deps fetch --dry-run        # preview only
    """
    if not os.path.exists("project.yml"):
        console.print("❌ [red]No project.yml found in current directory.[/]")
        sys.exit(1)

    from sdk.engine.ip_resolver import IpDependencyResolver, IpResolver, load_ips_from_project

    ip_paths, vendor, project_root = load_ips_from_project("project.yml")

    if not ip_paths:
        console.print("  [dim]No IPs declared in project.yml sources.ips — nothing to fetch.[/]")
        return

    resolver = IpResolver(project_root, vendor)
    result = resolver.resolve(ip_paths)

    if result.errors:
        for err in result.errors:
            console.print(f"  [red]⚠ {err}[/]")

    # Collect all dependencies across manifests
    all_deps = []
    for m in result.manifests:
        all_deps.extend(m.dependencies)

    if not all_deps:
        console.print("  [dim]No IP dependencies declared in any ip.yml — nothing to fetch.[/]")
        return

    dest_dir = Path(dest)
    dep_resolver = IpDependencyResolver()
    fetch_result = dep_resolver.fetch_all(result.manifests, dest_dir, dry_run=dry_run)

    # ── Report ──
    action = "Would fetch" if dry_run else "Fetched"

    if fetch_result.fetched:
        for dep in fetch_result.fetched:
            console.print(f"  [green]✅[/] {action}: [cyan]{dep}[/]")

    if fetch_result.already_present:
        for dep in fetch_result.already_present:
            console.print(f"  [dim]⏭  Already present: {dep}[/]")

    if fetch_result.errors:
        for err in fetch_result.errors:
            console.print(f"  [red]❌ {err}[/]")

    # Summary
    console.print()
    parts = []
    if fetch_result.fetched:
        parts.append(f"[green]{len(fetch_result.fetched)} fetched[/]")
    if fetch_result.already_present:
        parts.append(f"[dim]{len(fetch_result.already_present)} present[/]")
    if fetch_result.errors:
        parts.append(f"[red]{len(fetch_result.errors)} failed[/]")

    if parts:
        console.print(f"  {' · '.join(parts)}")

    if fetch_result.errors:
        sys.exit(1)


# ── status (P2.81) ────────────────────────────────────────────


@deps_group.command(name="status")
@click.option("--dest", default="deps", help="Dependency directory to check (default: deps/).")
def deps_status(dest):
    """Show which IP dependencies are present, missing, or in error.

    \b
    Examples:
        routertl deps status
        routertl deps status --dest lib/sdk
    """
    if not os.path.exists("project.yml"):
        console.print("❌ [red]No project.yml found in current directory.[/]")
        sys.exit(1)

    from sdk.engine.ip_resolver import IpDependencyResolver, IpResolver, load_ips_from_project

    ip_paths, vendor, project_root = load_ips_from_project("project.yml")

    if not ip_paths:
        console.print("  [dim]No IPs declared in project.yml sources.ips.[/]")
        return

    resolver = IpResolver(project_root, vendor)
    result = resolver.resolve(ip_paths)

    # Collect deps
    all_deps = []
    for m in result.manifests:
        all_deps.extend(m.dependencies)

    if not all_deps:
        console.print("  [dim]No IP dependencies declared in any ip.yml.[/]")
        return

    dest_dir = Path(dest)
    dep_resolver = IpDependencyResolver()
    checks = dep_resolver.check_all(result.manifests, dest_dir)

    console.print(f"\n📦 [cyan]IP Dependency Status[/] ({len(checks)} dependencies)\n")

    ok_count = 0
    missing_count = 0
    err_count = 0

    for c in checks:
        if c["status"] == "ok":
            console.print(f"  [green]✅[/] [cyan]{c['dep_id']}[/]  [dim]{c['detail']}[/]")
            ok_count += 1
        elif c["status"] == "missing":
            console.print(f"  [yellow]⚠[/]  [cyan]{c['dep_id']}[/]  [yellow]{c['detail']}[/]")
            missing_count += 1
        else:
            console.print(f"  [red]❌[/] [cyan]{c['dep_id']}[/]  [red]{c['detail']}[/]")
            err_count += 1

    console.print()
    parts = []
    if ok_count:
        parts.append(f"[green]{ok_count} present[/]")
    if missing_count:
        parts.append(f"[yellow]{missing_count} missing[/]")
    if err_count:
        parts.append(f"[red]{err_count} error{'s' if err_count != 1 else ''}[/]")

    if parts:
        console.print(f"  {' · '.join(parts)}")
    console.print()

    if missing_count:
        console.print(f"  [dim]Run: {_cli_name()} deps fetch[/]")
        console.print()
