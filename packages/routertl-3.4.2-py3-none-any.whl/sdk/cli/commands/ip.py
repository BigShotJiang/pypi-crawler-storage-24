# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import subprocess
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console


def _run_make(target, *args):
    """Helper to delegate IP targets to the Master Makefile"""
    cmd = ["make", target, *args]
    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            console.print(f"\n❌ [red]Command failed (Make exit code: {result.returncode})[/]")
            sys.exit(result.returncode)
    except FileNotFoundError:
        console.print("❌ [red]Error:[/] 'make' not found. Ensure build-essential is installed.")
        sys.exit(1)


# ── Register Bank Group ───────────────────────────────────────
@click.group(name="regbank")
def regbank_group():
    """Register Bank — validate, generate, template, and export tools.

    All subcommands consume ``project_regbank.yml`` (or a custom path)
    as the single source of truth for the register bank schema.
    """
    pass


@regbank_group.command(name="parse")
def parse():
    """Generate VHDL package from Regbank YAML (legacy Make target)."""
    console.print("📝 [blue]Parsing Register Bank...[/]")
    _run_make("parse_regbank")


@regbank_group.command(name="add")
def add_register():
    """Add a new register to the register bank (interactive)."""
    _run_make("add-register")


@regbank_group.command(name="remove")
@click.argument("name", required=True)
def remove_register(name):
    """Remove a register from the register bank."""
    console.print(f"🗑️ [blue]Removing register [cyan]{name}[/]...")
    _run_make("remove-register", f"NAME={name}")


# ── P2.106: rr regbank validate ───────────────────────────────
@regbank_group.command(name="validate")
@click.argument("schema", default="project_regbank.yml")
@click.option("--strict", is_flag=True, help="Treat warnings as errors.")
@click.option(
    "--address-mode",
    default="words",
    type=click.Choice(["words", "bytes"]),
    help="Interpret addresses as word or byte offsets.",
)
def validate(schema, strict, address_mode):
    """Validate a regbank YAML schema for consistency errors."""
    from sdk.generators.regbank.validate_schema import validate_schema

    if not Path(schema).exists():
        console.print(f"❌ [red]Schema not found:[/] {schema}")
        sys.exit(1)

    result = validate_schema(schema, address_mode=address_mode, strict=strict)

    for issue in result["issues"]:
        console.print(f"  {issue}")
    for warn in result["warnings"]:
        console.print(f"  {warn}")

    console.print(
        f"\n  📋 [cyan]Registers:[/] {result['reg_count']}  "
        f"(max index: {result['max_index']})"
    )

    if result["issues"] or (strict and result["warnings"]):
        console.print("  ❌ [red]Validation failed.[/]")
        sys.exit(1)
    else:
        console.print("  ✅ [green]Schema is valid.[/]")


# ── P2.106+: rr regbank template ──────────────────────────────
# Imported from a zero-dependency module so that unit tests can access
# _TEMPLATE_YAML without pulling in rich_click (see template_yaml.py).
from sdk.generators.regbank.template_yaml import _TEMPLATE_YAML  # noqa: F401


@regbank_group.command(name="template")
@click.option(
    "-o", "--output",
    default="project_regbank.yml",
    help="Output YAML file path.",
)
@click.option("--force", is_flag=True, help="Overwrite existing file.")
def template(output, force):
    """Scaffold a register bank YAML skeleton with traceability registers.

    Creates a project_regbank.yml with mandatory ROM registers (git hash,
    FW version, build date, regbank version) plus showcase registers
    demonstrating fields, enums, and telemetry counter patterns.
    """
    out_path = Path(output)
    if out_path.exists() and not force:
        console.print(
            f"⚠️  [yellow]{output} already exists.[/] "
            "Use [cyan]--force[/] to overwrite."
        )
        sys.exit(1)

    out_path.write_text(_TEMPLATE_YAML, encoding="utf-8")
    console.print(f"✅ [green]Created register bank template:[/] {output}")
    console.print("  Next steps:")
    console.print("    rr regbank validate       — check schema")
    console.print("    rr regbank generate       — generate all outputs")
    console.print("    rr regbank html           — generate HTML docs")


# ── P2.105: rr regbank generate ───────────────────────────────
@regbank_group.command(name="generate")
@click.argument("schema", default="project_regbank.yml")
@click.option("--output-dir", default="src/pkg", help="Output directory for VHDL package.")
@click.option("--library", "-l", default="work", help="VHDL library name.")
@click.option("--verbose", "-v", is_flag=True, help="Verbose output.")
def generate(schema, output_dir, library, verbose):
    """Run the full register bank generation chain.

    Validates the schema, then generates:
    1. system_regbank_pkg.vhd (VHDL constants & types)
    2. regbank_manifest.hex / .bin (BRAM payload)
    3. Python constants file
    """
    from sdk.generators.regbank.generate_regbank_pkg import generate_pkg
    from sdk.generators.regbank.validate_schema import validate_schema

    schema_path = Path(schema)
    if not schema_path.exists():
        console.print(f"❌ [red]Schema not found:[/] {schema}")
        sys.exit(1)

    # 1. Validate
    console.print("🔍 [blue]Validating schema...[/]")
    result = validate_schema(str(schema_path))
    if result["issues"]:
        for issue in result["issues"]:
            console.print(f"  {issue}")
        console.print("  ❌ [red]Validation failed — fix errors first.[/]")
        sys.exit(1)
    console.print(f"  ✅ [green]Valid[/] ({result['reg_count']} registers)")

    # 2. Generate VHDL package
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    vhdl_out = out_dir / "system_regbank_pkg.vhd"
    console.print(f"📝 [blue]Generating VHDL package → {vhdl_out}[/]")
    generate_pkg(str(schema_path), str(vhdl_out), "dec", verbose=verbose, library=library)

    # 3. Generate hex/bin payload
    console.print("📦 [blue]Generating hex/bin payload...[/]")
    encoder_cmd = [
        sys.executable,
        str(Path(__file__).resolve().parent.parent.parent / "generators" / "regbank" / "payload_encoder.py"),
        str(schema_path),
    ]
    subprocess.run(encoder_cmd, check=False)

    # 4. Generate Python constants (if verification dir exists)
    const_py = Path("sim") / "cocotb" / "constants.py"
    if const_py.parent.exists():
        console.print(f"🐍 [blue]Generating Python constants → {const_py}[/]")
        const_cmd = [
            sys.executable,
            str(Path(__file__).resolve().parent.parent.parent / "generators" / "regbank" / "generate_constants.py"),
            str(schema_path),
            str(const_py),
        ]
        subprocess.run(const_cmd, check=False)

    console.print("\n✅ [green]Register bank generation complete.[/]")


# ── P2.109: rr regbank axilite ────────────────────────────────
@regbank_group.command(name="axilite")
@click.argument("schema", default="project_regbank.yml")
@click.option("-o", "--output", default=None, help="Output VHDL file.")
@click.option("-l", "--library", default="work", help="VHDL library name.")
def axilite(schema, output, library):
    """Generate a synthesizable AXI-Lite register file entity.

    Produces a VHDL entity with full AXI4-Lite slave handshaking and
    the same REGS_IN/REGS_OUT record interface used in existing designs.
    """
    from sdk.generators.regbank.generate_axilite import write_axilite
    from sdk.generators.regbank.regbank_parser import load_schema as _load

    schema_path = Path(schema)
    if not schema_path.exists():
        console.print(f"❌ [red]Schema not found:[/] {schema}")
        sys.exit(1)

    out_path = Path(output) if output else Path("src/regbank/axilite_regbank.vhd")
    parsed = _load(schema_path)
    write_axilite(parsed, out_path, library=library)


# ── P2.110: rr regbank c-header ───────────────────────────────
@regbank_group.command(name="c-header")
@click.argument("schema", default="project_regbank.yml")
@click.option("-o", "--output", default="regbank.h", help="Output header file.")
@click.option("--cpp", is_flag=True, help="Include C++ register accessor class.")
def c_header(schema, output, cpp):
    """Generate C/C++ register header with offset defines and field macros.

    Produces byte-addressed offset defines, per-field MASK/SHIFT/GET/SET
    macros, and optionally a C++ register class with typed accessors.
    """
    from sdk.generators.regbank.generate_c_header import write_c_header
    from sdk.generators.regbank.regbank_parser import load_schema as _load

    schema_path = Path(schema)
    if not schema_path.exists():
        console.print(f"❌ [red]Schema not found:[/] {schema}")
        sys.exit(1)

    parsed = _load(schema_path)
    write_c_header(parsed, Path(output), cpp=cpp)


# ── P2.111: rr regbank html ──────────────────────────────────
@regbank_group.command(name="html")
@click.argument("schema", default="project_regbank.yml")
@click.option("-o", "--output", default="register_bank.html", help="Output HTML file.")
def html(schema, output):
    """Generate a self-contained HTML register documentation page.

    Produces a dark-themed, sortable, searchable HTML page documenting
    all registers, fields, enums, and telemetry counters.
    """
    from sdk.generators.regbank.generate_html import write_html
    from sdk.generators.regbank.regbank_parser import load_schema as _load

    schema_path = Path(schema)
    if not schema_path.exists():
        console.print(f"❌ [red]Schema not found:[/] {schema}")
        sys.exit(1)

    parsed = _load(schema_path)
    write_html(parsed, Path(output))


@click.command(name="rom")
def rom():
    """Generate ROM Data & Package."""
    console.print("📝 [blue]Generating ROM Data...[/]")
    _run_make("rom_info")


# ── IP Manifest Group (new) ───────────────────────────────────
@click.group(name="ip")
def ip_group():
    """IP Manifest Management — init, list, hierarchy, update."""
    pass


def _get_resolver():
    """Load IpResolver with project context."""
    from sdk.engine.ip_resolver import IpResolver, load_ips_from_project

    project_yml = "project.yml"
    if not os.path.exists(project_yml):
        console.print("❌ [red]No project.yml found in current directory.[/]")
        sys.exit(1)

    ip_paths, vendor, project_root = load_ips_from_project(project_yml)
    resolver = IpResolver(project_root, vendor)
    return resolver, ip_paths


@ip_group.command(name="init")
@click.argument("name", required=False)
@click.option("--mode", default="rtl", help="Synthesis mode (rtl, xci, qsys, ipx, cxz, netlist, ooc_dcp)")
@click.option("--language", default="vhdl", help="HDL language (vhdl, systemverilog, mixed)")
@click.option("--library", default="work", help="VHDL library name")
def ip_init(name, mode, language, library):
    """Initialize a new IP manifest (ip.yml) interactively.

    Creates an ip/<name>/ directory with a pre-filled ip.yml manifest
    and (for RTL mode) an empty src/ directory.
    """
    tools_dir = Path(__file__).resolve().parent.parent.parent / "engine"
    init_script = tools_dir / "init_ip.py"

    if not init_script.exists():
        console.print(f"❌ [red]Cannot locate init_ip.py at {init_script}[/]")
        sys.exit(1)

    cmd = [sys.executable, str(init_script)]
    if name:
        cmd.extend(["--name", name])
    if mode != "rtl":
        cmd.extend(["--mode", mode])
    if language != "vhdl":
        cmd.extend(["--language", language])
    if library != "work":
        cmd.extend(["--library", library])

    try:
        subprocess.run(cmd, check=False)
    except KeyboardInterrupt:
        console.print("\n[yellow]Initialization aborted.[/]")


@ip_group.command(name="list")
def ip_list():
    """Show all IPs referenced in project.yml with their modes and status."""
    resolver, ip_paths = _get_resolver()

    if not ip_paths:
        console.print("\n  [dim]No IPs found in project.yml sources.ips[/]\n")
        console.print("  [dim]Use 'rr ip init' to create one.[/]")
        return

    result = resolver.resolve(ip_paths)

    if result.errors:
        for err in result.errors:
            console.print(f"  [red]⚠ {err}[/]")
        click.echo()

    if not result.manifests:
        console.print("\n  [dim]No valid IPs resolved.[/]")
        return

    console.print(f"\n🧩 [cyan]IP Manifest Summary[/] ({len(result.manifests)} IPs)\n")
    for m in result.manifests:
        lib_info = f"library={m.library}" if m.library != "work" else "—"
        count = f"{m.source_count} {'source' if m.source_count == 1 else 'sources'}"
        if m.mode in ("xci", "qsys", "ipx", "cxz"):
            count = f"{m.source_count} IP {'file' if m.source_count == 1 else 'files'}"
        elif m.mode in ("netlist", "ooc_dcp"):
            count = f"{m.source_count} {'netlist' if m.source_count == 1 else 'netlists'}"

        console.print(
            f"  [green]✅[/] [cyan]{m.name:<25}[/] "
            f"{m.mode:<10} [dim]{lib_info:<20}[/] [dim]{count}[/]"
        )
    click.echo()


@ip_group.command(name="hierarchy")
def ip_hierarchy():
    """Show the IP dependency tree."""
    resolver, ip_paths = _get_resolver()

    if not ip_paths:
        console.print("\n  [dim]No IPs found in project.yml sources.ips[/]")
        return

    result = resolver.resolve(ip_paths)

    if result.errors:
        for err in result.errors:
            console.print(f"  [red]⚠ {err}[/]")
        click.echo()

    if not result.manifests:
        console.print("\n  [dim]No valid IPs resolved.[/]")
        return

    console.print("\n🌳 [cyan]IP Dependency Tree[/]\n")

    # Find roots (manifests not referenced as children of others)
    child_paths = set()
    for m in result.manifests:
        for c in m.children:
            child_paths.add(str(c.path))

    roots = [m for m in result.manifests if str(m.path) not in child_paths]

    for i, root in enumerate(roots):
        is_last = i == len(roots) - 1
        _print_tree(root, "", is_last)
    click.echo()


def _print_tree(manifest, prefix, is_last):
    """Recursively print an IP tree node with box-drawing characters."""
    connector = "└── " if is_last else "├── "
    count = f"{manifest.source_count} file{'s' if manifest.source_count != 1 else ''}"
    mode_color = "[green]" if manifest.mode == "rtl" else "[yellow]"
    console.print(
        f"{prefix}{connector}[cyan]{manifest.name}[/] "
        f"({mode_color}{manifest.mode}[/], [dim]{count}[/])"
    )

    new_prefix = prefix + ("    " if is_last else "│   ")
    for i, child in enumerate(manifest.children):
        child_last = i == len(manifest.children) - 1
        _print_tree(child, new_prefix, child_last)


@ip_group.command(name="auto-discover")
@click.option("--src", multiple=True, help="Source directories to scan (repeatable; default: from project.yml).")
@click.option("--write", "do_write", is_flag=True, help="Create ip/<area>/ip.yml files.")
@click.option("--library", default=None, help="VHDL library name override for all areas.")
@click.option(
    "--group-by", "group_by", default="directory",
    type=click.Choice(["directory", "hierarchy"]),
    help="Grouping strategy (default: directory).",
)
def auto_discover(src, do_write, library, group_by):
    """Auto-discover IP areas from a source tree and propose ip.yml manifests.

    Scans the source tree, groups entities by directory (or hierarchy root),
    detects inter-area dependencies from instantiations and package use
    clauses, and proposes ip.yml manifests.

    \b
    Examples:
        rr ip auto-discover --src src                       # single dir
        rr ip auto-discover --src src --src 3rdParty/hdl    # multiple dirs
        rr ip auto-discover --src src --write               # create ip.yml files
        rr ip auto-discover --group-by hierarchy             # group by hierarchy root
    """
    from rich.table import Table

    from sdk.engine.ip_auto_discover import auto_discover as _auto_discover
    from sdk.engine.ip_auto_discover import write_manifests

    # Resolve source directories (--src is multiple=True → tuple)
    src_dirs = []
    if src:
        src_dirs = [Path(s) for s in src]
    else:
        # Try project.yml
        project_yml = Path("project.yml")
        if project_yml.exists():
            import yaml

            with open(project_yml) as f:
                config = yaml.safe_load(f) or {}
            paths_cfg = config.get("paths", {})
            src_cfg = paths_cfg.get("sources", "src")
            if isinstance(src_cfg, list):
                src_dirs = [Path(s) for s in src_cfg]
            else:
                src_dirs = [Path(src_cfg)]
        else:
            src_dirs = [Path("src")]

    # Validate
    for d in src_dirs:
        if not d.exists():
            console.print(f"❌ [red]Source directory not found:[/] {d}")
            sys.exit(1)

    console.print(
        f"\n🔍 [cyan]Scanning[/] {', '.join(str(d) for d in src_dirs)} "
        f"(group-by: {group_by})...\n"
    )

    areas = _auto_discover(src_dirs, group_by=group_by, library=library)

    if not areas:
        console.print("  [dim]No IP areas discovered.[/]\n")
        return

    # Rich table
    table = Table(
        title="🧩 Proposed IP Areas",
        title_style="bold cyan",
        show_lines=False,
        padding=(0, 1),
    )
    table.add_column("Area", style="cyan", min_width=20)
    table.add_column("Language", width=14)
    table.add_column("Library", width=14)
    table.add_column("Sources", justify="right", width=8)
    table.add_column("Dependencies", min_width=20)

    for area in areas:
        dep_str = ", ".join(area["dependencies"]) if area["dependencies"] else "—"
        table.add_row(
            area["name"],
            area["language"],
            area["library"],
            str(len(area["sources"])),
            dep_str,
        )

    console.print(table)
    console.print(
        f"\n  [green]{len(areas)}[/] area{'s' if len(areas) != 1 else ''} discovered, "
        f"{sum(len(a['sources']) for a in areas)} total source files\n"
    )

    if do_write:
        written = write_manifests(areas, Path.cwd())
        for w in written:
            console.print(f"  ✅ [green]Created:[/] {w}")
        console.print(
            f"\n  📦 [cyan]{len(written)} ip.yml manifest(s) written.[/]\n"
        )
    else:
        console.print(
            "  [dim]Dry-run mode — use --write to create ip.yml files.[/]\n"
        )


@ip_group.command(name="update")
def ip_update():
    """Scan RTL-mode IP directories and update ip.yml source lists."""
    console.print("🔄 [blue]Updating IP manifest source lists...[/]")
    _run_make("update-ips")
