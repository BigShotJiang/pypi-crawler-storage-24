# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Docker Container Development Environment — CLI commands.

This package replaces the former monolithic ``docker.py`` (P2.42).
Core orchestration logic lives in ``routertl_core.docker.orchestration``
(Cython-compiled on release builds, P2.59).  This module re-exports
those symbols and registers Click commands via submodule imports.
"""

import rich_click as click

# ──────────────────────────────────────────────────────────────
# Click group
# ──────────────────────────────────────────────────────────────


@click.group(name="docker")
def docker_group():
    """Docker Container Development Environment."""
    pass


# ──────────────────────────────────────────────────────────────
# Re-export core orchestration symbols (P2.59)
#
# All constants, helpers, and resolution functions are now in
# routertl_core.docker.orchestration — compiled to .so on release.
# Command submodules import them from this __init__.py as before,
# keeping the existing API surface unchanged.
# ──────────────────────────────────────────────────────────────

from routertl_core.docker.orchestration import (  # noqa: E402, F401
    _CONFIG_FILES,
    _EDITION_SUBDIRS,
    _INSTALL_DIR_VARS,
    _INSTALLER_PATH_VARS,
    _QUARTUS_EDITION_VOLUMES,
    _VOLUME_MAP,
    _VOLUME_PROBES,
    _detect_bind_mounts,
    _find_sdk_docker_dir,
    _load_project_yml_for_docker,
    _read_env_var,
    _remove_env_var,
    _resolve_install_mount,
    _resolve_quartus_volume,
    _resolve_volume,
    _run_docker_sh,
    _run_make,
)

# ── Import all submodules to register commands on docker_group ──
from sdk.cli.commands.docker import (  # noqa: E402, F401
    build,
    config,
    device,
    setup,
    status,
    uninstall,
)
