# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Docker uninstall command — remove volumes, images, and build cache."""

import subprocess
from pathlib import Path

import rich_click as click

from sdk.cli.commands.docker import (
    _EDITION_SUBDIRS,
    _INSTALL_DIR_VARS,
    _VOLUME_MAP,
    _read_env_var,
    _remove_env_var,
    _resolve_volume,
    docker_group,
)
from sdk.cli.console import console


@docker_group.command(name="uninstall")
@click.argument("env", type=click.Choice(sorted(_VOLUME_MAP.keys())), required=True)
@click.option(
    "--volume", "remove_volume", is_flag=True, default=False, help="Remove only the install volume (EDA tool data)."
)
@click.option("--image", "remove_image", is_flag=True, default=False, help="Remove only the Docker image.")
@click.option("--purge", is_flag=True, default=False, help="Also clear Docker build cache (forces full rebuild).")
def docker_uninstall(env, remove_volume, remove_image, purge):
    """Remove Docker volume and/or image for a vendor tool.

    \\b
    Without flags, removes both volume and image (with confirmation).

    \\b
    Examples:
        rr docker uninstall riviera            # Remove both
        rr docker uninstall quartus --volume   # Volume only
        rr docker uninstall vivado --image     # Image only
        rr docker uninstall riviera --purge    # Remove all + build cache
    """
    # If neither flag specified, remove both
    if not remove_volume and not remove_image:
        remove_volume = True
        remove_image = True

    volume_name = _resolve_volume(env)
    image_name = f"routertl-{env}:latest"

    removed_anything = False

    # --- Volume ---
    if remove_volume:
        if not volume_name:
            console.print(f"ℹ️  [blue]{env} has no persistent volume.[/]")
        else:
            vol_check = subprocess.run(["docker", "volume", "inspect", volume_name], capture_output=True, text=True)
            if vol_check.returncode != 0:
                console.print(f"ℹ️  [blue]Volume [cyan]{volume_name}[blue] does not exist.[/]")
            else:
                console.print(
                    f"⚠️  [yellow]Volume '{volume_name}' contains the {env.capitalize()} installation.[/]"
                )
                if click.confirm(f"Remove volume '{volume_name}'?"):
                    console.print("🗑️  [blue]Removing volume...[/]")
                    rm = subprocess.run(["docker", "volume", "rm", volume_name])
                    if rm.returncode == 0:
                        console.print(f"✅ [green]Volume '{volume_name}' removed.[/]")
                        removed_anything = True
                    else:
                        console.print("❌ [red]Failed to remove volume.[/]")
                        console.print(
                            f"   [dim]Tip: stop containers using it first: docker stop $(docker ps -q --filter volume={volume_name})[/]"
                        )
                else:
                    console.print("🛑 [blue]Volume removal skipped.[/]")

    # --- Image ---
    if remove_image:
        img_check = subprocess.run(["docker", "image", "inspect", image_name], capture_output=True, text=True)
        if img_check.returncode != 0:
            console.print(f"ℹ️  [blue]Image [cyan]{image_name}[blue] does not exist.[/]")
        else:
            # Get image size for context
            size_result = subprocess.run(
                ["docker", "image", "ls", image_name, "--format", "{{.Size}}"], capture_output=True, text=True
            )
            size = size_result.stdout.strip() if size_result.returncode == 0 else ""
            size_info = f" ({size})" if size else ""

            console.print(f"⚠️  [yellow]Image '{image_name}'{size_info} will be removed.[/]")
            console.print(f"   [dim]Reinstall with: rr docker install {env}[/]")
            if click.confirm(f"Remove image '{image_name}'?"):
                console.print("🗑️  [blue]Removing image...[/]")
                rm = subprocess.run(["docker", "rmi", image_name])
                if rm.returncode == 0:
                    console.print(f"✅ [green]Image '{image_name}' removed.[/]")
                    removed_anything = True
                else:
                    console.print("❌ [red]Failed to remove image.[/]")
                    console.print(
                        f"   [dim]Tip: remove containers using it first: docker rm $(docker ps -aq --filter ancestor={image_name})[/]"
                    )
            else:
                console.print("🛑 [blue]Image removal skipped.[/]")

    # --- Stale .env bind-mount cleanup ---
    if remove_volume:
        dir_var = _INSTALL_DIR_VARS.get(env)
        if dir_var:
            val = _read_env_var(dir_var)
            if val:
                p = Path(val).expanduser()
                if not p.exists():
                    console.print(
                        f"⚠️  [yellow].env has {dir_var}={val} "
                        f"but directory no longer exists.[/]"
                    )
                    if click.confirm(f"Remove {dir_var} from .env?"):
                        _remove_env_var(dir_var)
                        console.print(f"✅ [green]{dir_var} removed from .env[/]")
                        removed_anything = True
        # Also check EDA_INSTALL_DIR if it has no remaining EDA subdirs
        eda_val = _read_env_var("EDA_INSTALL_DIR")
        if eda_val:
            eda_p = Path(eda_val).expanduser()
            has_eda_children = eda_p.exists() and any(
                (eda_p / sub).exists() for sub in _EDITION_SUBDIRS.values()
            )
            if not eda_p.exists() or not has_eda_children:
                reason = "no longer exists" if not eda_p.exists() else "contains no EDA installations"
                console.print(
                    f"⚠️  [yellow].env has EDA_INSTALL_DIR={eda_val} "
                    f"but directory {reason}.[/]"
                )
                if click.confirm("Remove EDA_INSTALL_DIR from .env?"):
                    _remove_env_var("EDA_INSTALL_DIR")
                    console.print("✅ [green]EDA_INSTALL_DIR removed from .env[/]")
                    removed_anything = True

    if not removed_anything:
        console.print("\n[dim]Nothing was removed.[/]")

    # --- Build cache ---
    if purge:
        console.print("\n🧹 [blue]Pruning Docker build cache...[/]")
        prune = subprocess.run(["docker", "builder", "prune", "-f"], capture_output=True, text=True)
        if prune.returncode == 0:
            # Parse reclaimed space from output
            reclaimed = ""
            for line in prune.stdout.splitlines():
                if "reclaimed" in line.lower():
                    reclaimed = line.strip()
            msg = "✅ [green]Build cache cleared."
            if reclaimed:
                msg += f" {reclaimed}"
            console.print(f"{msg}[/]")
        else:
            console.print("⚠️  [yellow]Could not prune build cache.[/]")
