# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command: config — Read and write YAML configuration fields."""

import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


def _load_yaml(yml_path):
    """Load a YAML file, return (data, path) or exit."""
    import yaml

    p = Path(yml_path)
    if not p.exists():
        console.print(f"❌ [red]No {p.name} found at {p}[/]")
        if p.name == "project.yml":
            click.echo(f"   Run: {_cli_name()} init")
        sys.exit(1)

    with open(p) as f:
        data = yaml.safe_load(f) or {}
    return data, p


def _resolve_key(data, dotted_key):
    """Walk a dotted key path (e.g. 'hardware.part') and return
    (parent_dict, last_key, current_value_or_MISSING).
    """
    keys = dotted_key.split(".")
    node = data
    for k in keys[:-1]:
        if not isinstance(node, dict) or k not in node:
            return None, keys[-1], _MISSING
        node = node[k]
    last = keys[-1]
    if not isinstance(node, dict):
        return None, last, _MISSING
    return node, last, node.get(last, _MISSING)


_MISSING = object()


@click.group(name="config")
@click.option(
    "-f",
    "--file",
    "yml_file",
    default="project.yml",
    help="Target YAML file (default: project.yml). Use for ip.yml editing.",
    show_default=True,
)
@click.pass_context
def config_command(ctx, yml_file):
    """Read or write YAML configuration fields.

    \\b
    Targets project.yml by default. Use -f to edit ip.yml or any YAML file.

    \\b
    Examples:
        rr config get hardware.part
        rr config set hardware.part "10AX115S2F45I1SG"
        rr config -f ip/uart/ip.yml get ip.name
        rr config -f ip/uart/ip.yml set ip.library tich
        rr config list --flat
    """
    ctx.ensure_object(dict)
    ctx.obj["yml_file"] = yml_file


@config_command.command(name="get")
@click.argument("key", required=False)
@click.pass_context
def config_get(ctx, key):
    """Read a value from the target YAML file.

    KEY uses dot-notation for nested fields (e.g. hardware.part).
    Without KEY, shows all configuration (same as `rr config list`).
    """
    import yaml

    yml_file = ctx.obj["yml_file"]
    data, yml_path = _load_yaml(yml_file)

    if not key:
        console.print(f"\n📋 [cyan]{yml_path.name}[/]\n")
        click.echo(yaml.dump(data, default_flow_style=False, sort_keys=False).rstrip())
        click.echo()
        return

    parent, last_key, value = _resolve_key(data, key)

    if value is _MISSING:
        console.print(f"❌ Key '[yellow]{key}[/]' not found in {yml_path.name}")
        sys.exit(1)

    if isinstance(value, (dict, list)):
        click.echo(yaml.dump(value, default_flow_style=False).rstrip())
    else:
        click.echo(value)


@config_command.command(name="set")
@click.argument("key")
@click.argument("value")
@click.pass_context
def config_set(ctx, key, value):
    """Write a value to the target YAML file.

    KEY uses dot-notation for nested fields (e.g. hardware.part).
    VALUE is the new value to set. Booleans (true/false) and integers
    are auto-detected; use quotes for string values.
    """
    import yaml

    yml_file = ctx.obj["yml_file"]
    data, yml_path = _load_yaml(yml_file)

    # Auto-detect type
    if value.lower() == "true":
        typed_value = True
    elif value.lower() == "false":
        typed_value = False
    else:
        try:
            typed_value = int(value)
        except ValueError:
            typed_value = value

    # Walk/create the dotted key path
    keys = key.split(".")
    node = data
    for k in keys[:-1]:
        if k not in node or not isinstance(node.get(k), dict):
            node[k] = {}
        node = node[k]

    old_value = node.get(keys[-1], _MISSING)
    node[keys[-1]] = typed_value

    # Write back preserving YAML style
    with open(yml_path, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    label = yml_path.name
    if old_value is _MISSING:
        console.print(
            f"✅ [green]{key}[/] = [cyan]{typed_value}[/] (new in {label})"
        )
    else:
        console.print(
            f"✅ [green]{key}[/]: "
            f"[red]{old_value}[/] → [cyan]{typed_value}[/]"
            f" ({label})"
        )


@config_command.command(name="list")
@click.option("--flat", is_flag=True, help="Show as flat dot-notation keys.")
@click.option("--raw", is_flag=True, help="Show raw YAML output (no Rich formatting).")
@click.option("--section", "-s", "section_filter", default=None,
              help="Show only a specific section (e.g. hardware, simulation).")
@click.pass_context
def config_list(ctx, flat, raw, section_filter):
    """Show all configuration from the target YAML file.

    \\b
    By default, renders a beautiful section-by-section panel display.
    Use --raw for plain YAML output (useful for scripting).
    Use --section to show only one section.

    \\b
    Examples:
        rr config list                    # Rich panel display
        rr config list --raw              # Plain YAML
        rr config list --flat             # Dot-notation keys
        rr config list --section hardware # Only hardware section
    """
    import yaml

    yml_file = ctx.obj["yml_file"]
    data, yml_path = _load_yaml(yml_file)
    label = yml_path.name

    # Apply section filter
    if section_filter:
        if section_filter not in data:
            console.print(f"❌ Section '[yellow]{section_filter}[/]' not found in {label}")
            available = ", ".join(f"[cyan]{k}[/]" for k in data.keys())
            console.print(f"   Available sections: {available}")
            sys.exit(1)
        data = {section_filter: data[section_filter]}

    if flat:

        def _flatten(d, prefix=""):
            for k, v in d.items():
                full = f"{prefix}{k}" if not prefix else f"{prefix}.{k}"
                if isinstance(v, dict):
                    _flatten(v, full)
                elif isinstance(v, list):
                    console.print(f"  [cyan]{full}[/] = [{len(v)} items]")
                else:
                    console.print(f"  [cyan]{full}[/] = {v}")

        console.print(f"\n📋 [cyan]{label}[/] (flat)\n")
        _flatten(data)
        click.echo()
    elif raw:
        console.print(f"\n📋 [cyan]{label}[/]\n")
        click.echo(yaml.dump(data, default_flow_style=False, sort_keys=False).rstrip())
        click.echo()
    else:
        _render_rich_config(data, label)


# ── Section icons for Rich panel headers ──────────────────────
_SECTION_ICONS = {
    "project": "📋",
    "hardware": "🎯",
    "simulation": "🔬",
    "paths": "📂",
    "build_options": "🔧",
    "features": "🧩",
    "sources": "📁",
    "dependencies": "📚",
    "hooks": "🪝",
    "linux": "🐧",
    "cicd": "🚀",
    "branding": "🏷️",
    "vendor_overrides": "⚙️",
    "makefile_overrides": "⚙️",
    "system_config": "📄",
    "auto_sources": "🔍",
    "environment": "🌐",
    "includes": "📎",
    "tcl_hooks": "📜",
}


def _render_rich_config(data, label):
    """Render project.yml as beautiful Rich panels, one per section."""
    from rich.panel import Panel
    from rich.text import Text

    # Header
    header = Text()
    header.append("📋 ", style="bold")
    header.append(label, style="bold cyan")
    sections = list(data.keys())
    header.append(f"  ({len(sections)} sections)", style="dim")
    console.print(Panel(header, border_style="cyan", padding=(0, 1)))
    console.print()

    for section_name, section_data in data.items():
        icon = _SECTION_ICONS.get(section_name, "•")
        title = f"{icon} {section_name}"

        if section_data is None:
            console.print(f"  [dim]{title}: (empty)[/dim]")
            continue

        # Boolean scalars (e.g. auto_sources: true) — must come before
        # the scalar check because bool is a subclass of int.
        if isinstance(section_data, bool):
            val = "[green]true[/]" if section_data else "[red]false[/]"
            console.print(f"  [bold]{title}[/]: {val}")
            continue

        # Scalar values (e.g. system_config: path/to/file)
        if not isinstance(section_data, (dict, list)):
            console.print(f"  [bold]{title}[/]: [cyan]{section_data}[/]")
            continue

        # Dispatch to section-specific renderers
        if section_name == "sources":
            _render_sources(title, section_data)
        elif section_name == "dependencies":
            _render_dependencies(title, section_data)
        elif section_name == "hooks":
            _render_hooks(title, section_data)
        elif section_name == "features":
            _render_features(title, section_data)
        elif section_name == "environment":
            _render_environment(title, section_data)
        elif isinstance(section_data, dict):
            _render_kv_section(title, section_data)
        elif isinstance(section_data, list):
            _render_list_section(title, section_data)
        else:
            console.print(f"  [bold]{title}[/]: [cyan]{section_data}[/]")

    console.print()


def _render_kv_section(title, data):
    """Render a dict section as a key-value table inside a panel."""
    from rich.panel import Panel
    from rich.table import Table

    table = Table(show_header=False, box=None, padding=(0, 2), expand=True)
    table.add_column("Key", style="bold", min_width=16)
    table.add_column("Value")

    for k, v in data.items():
        if isinstance(v, dict):
            # Nested dict: show inline summary
            parts = []
            for nk, nv in v.items():
                if isinstance(nv, list):
                    parts.append(f"{nk}: [cyan]{len(nv)} items[/]")
                elif isinstance(nv, bool):
                    val = "[green]✓[/]" if nv else "[dim]✗[/dim]"
                    parts.append(f"{nk}: {val}")
                else:
                    parts.append(f"{nk}: [cyan]{nv}[/]")
            table.add_row(k, ", ".join(parts) if parts else "[dim](empty)[/dim]")
        elif isinstance(v, list):
            table.add_row(k, f"[cyan]{len(v)}[/] items")
        elif isinstance(v, bool):
            val = "[green]true[/]" if v else "[red]false[/]"
            table.add_row(k, val)
        else:
            table.add_row(k, f"[cyan]{v}[/]")

    console.print(Panel(table, title=f"[bold]{title}[/]", title_align="left",
                        border_style="bright_black", padding=(0, 1)))


def _render_sources(title, data):
    """Render the sources section with file counts and type breakdown."""
    from rich.panel import Panel
    from rich.table import Table

    if not isinstance(data, dict):
        console.print(f"  [bold]{title}[/]: [dim](invalid)[/dim]")
        return

    table = Table(show_header=True, box=None, padding=(0, 2), expand=True)
    table.add_column("Category", style="bold", min_width=12)
    table.add_column("Count", justify="right", style="cyan", min_width=6)
    table.add_column("Status", min_width=12)

    for cat, files in data.items():
        if cat == "libraries":
            # Libraries is a nested dict[name -> file_list]
            if isinstance(files, dict):
                for lib_name, lib_files in files.items():
                    count = len(lib_files) if isinstance(lib_files, list) else 0
                    table.add_row(
                        f"lib:{lib_name}",
                        str(count),
                        "[green]✓[/]" if count > 0 else "[dim]—[/dim]",
                    )
        elif isinstance(files, list):
            count = len(files)
            status = "[green]✓[/]" if count > 0 else "[dim]—[/dim]"
            table.add_row(cat, str(count), status)
        else:
            table.add_row(cat, "—", "[dim]scalar[/dim]")

    console.print(Panel(table, title=f"[bold]{title}[/]", title_align="left",
                        border_style="bright_black", padding=(0, 1)))


def _render_dependencies(title, data):
    """Render the dependencies section as a table with presence check."""
    from rich.panel import Panel
    from rich.table import Table

    if not isinstance(data, dict):
        console.print(f"  [bold]{title}[/]: [dim](invalid)[/dim]")
        return

    table = Table(show_header=True, box=None, padding=(0, 2), expand=True)
    table.add_column("Name", style="bold", min_width=14)
    table.add_column("Path", style="dim")
    table.add_column("Library", style="cyan")
    table.add_column("Present", justify="center")

    for dep_name, dep_conf in data.items():
        if not isinstance(dep_conf, dict):
            table.add_row(dep_name, "—", "—", "—")
            continue
        dep_path = dep_conf.get("path", "—")
        library = dep_conf.get("library", "—")
        present = Path(dep_path).exists()
        status = "[green]✅[/]" if present else "[red]❌[/]"
        table.add_row(dep_name, dep_path, library, status)

    console.print(Panel(table, title=f"[bold]{title}[/]", title_align="left",
                        border_style="bright_black", padding=(0, 1)))


def _render_hooks(title, data):
    """Render hooks section with pre-commit summary and pre-build list."""
    from rich.panel import Panel

    if not isinstance(data, dict):
        console.print(f"  [bold]{title}[/]: [dim](invalid)[/dim]")
        return

    lines = []

    # Pre-commit section
    pre_commit = data.get("pre_commit") or {}
    if isinstance(pre_commit, dict) and pre_commit:
        enabled = pre_commit.get("enabled", False)
        status = "[green]enabled[/]" if enabled else "[red]disabled[/]"
        parts = [f"Status: {status}"]

        checks = []
        if pre_commit.get("lint"):
            checks.append("lint")
        if pre_commit.get("check_yaml"):
            checks.append("yaml")
        if pre_commit.get("lint_python"):
            checks.append("python")
        if checks:
            parts.append(f"Checks: [cyan]{', '.join(checks)}[/]")

        tests = pre_commit.get("tests") or []
        if tests == "auto":
            parts.append("Tests: [cyan]auto-discover[/]")
        elif isinstance(tests, list):
            parts.append(f"Tests: [cyan]{len(tests)}[/]")

        excludes = pre_commit.get("exclude") or {}
        if isinstance(excludes, dict):
            exc_parts = []
            for exc_type, exc_list in excludes.items():
                if isinstance(exc_list, list) and exc_list:
                    exc_parts.append(f"{len(exc_list)} {exc_type}")
            if exc_parts:
                parts.append(f"Excludes: [dim]{', '.join(exc_parts)}[/dim]")

        lines.append(f"  [bold]pre_commit[/]  {' │ '.join(parts)}")

    # Pre-build section
    pre_build = data.get("pre_build") or []
    if isinstance(pre_build, list) and pre_build:
        names = [h.get("name", "unnamed") for h in pre_build if isinstance(h, dict)]
        lines.append(f"  [bold]pre_build[/]   [cyan]{len(names)}[/] hooks: {', '.join(names)}")

    if lines:
        content = "\n".join(lines)
        console.print(Panel(content, title=f"[bold]{title}[/]", title_align="left",
                            border_style="bright_black", padding=(0, 1)))
    else:
        console.print(f"  [bold]{title}[/]: [dim](empty)[/dim]")


def _render_features(title, data):
    """Render features as flag badges."""
    if not isinstance(data, dict):
        console.print(f"  [bold]{title}[/]: [dim](invalid)[/dim]")
        return

    flags = []
    for feat, enabled in data.items():
        if enabled:
            flags.append(f"[green]✓ {feat}[/]")
        else:
            flags.append(f"[dim]✗ {feat}[/dim]")

    console.print(f"  [bold]{_SECTION_ICONS.get('features', '•')} features[/]  {', '.join(flags)}")


def _render_environment(title, data):
    """Render environment variables as a key-value table."""
    from rich.panel import Panel
    from rich.table import Table

    if not isinstance(data, dict):
        console.print(f"  [bold]{title}[/]: [dim](invalid)[/dim]")
        return

    table = Table(show_header=True, box=None, padding=(0, 2), expand=True)
    table.add_column("Variable", style="bold", min_width=20)
    table.add_column("Value", style="cyan")

    for var, val in data.items():
        table.add_row(var, str(val))

    console.print(Panel(table, title=f"[bold]{title}[/]", title_align="left",
                        border_style="bright_black", padding=(0, 1)))


def _render_list_section(title, data):
    """Render a list section (e.g. includes) as a compact list."""
    from rich.panel import Panel

    if not data:
        console.print(f"  [bold]{title}[/]: [dim](empty)[/dim]")
        return

    lines = [f"  [cyan]{item}[/]" for item in data]
    content = "\n".join(lines)
    console.print(Panel(content, title=f"[bold]{title}[/]", title_align="left",
                        border_style="bright_black", padding=(0, 1)))
