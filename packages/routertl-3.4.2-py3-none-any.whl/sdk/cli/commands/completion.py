# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command: completion — emit shell completion scripts."""

import rich_click as click

_SUPPORTED_SHELLS = ("bash", "zsh", "fish")


from sdk.cli.resilience import cli_resilient


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    """Resolve the effective CLI binary name from branding config."""
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


_ALIASES = ("rr",)
"""Short aliases registered in pyproject.toml [project.scripts]."""


@click.command(name="completion")
@click.argument("shell", type=click.Choice(_SUPPORTED_SHELLS, case_sensitive=False))
def completion_command(shell):
    """Generate shell completion script.

    \\b
    Install completions:
      bash:  eval "$(rr completion bash)"
      zsh:   eval "$(rr completion zsh)"
      fish:  rr completion fish | source

    Or save to a file:
      rr completion bash > ~/.local/share/bash-completion/completions/rr
    """

    name = _cli_name()
    shell_lower = shell.lower()

    if shell_lower == "bash":
        script = _bash_completion_script(name)
    elif shell_lower == "zsh":
        script = _zsh_completion_script(name)
    elif shell_lower == "fish":
        script = _fish_completion_script(name)

    click.echo(script)


def _bash_completion_script(name: str) -> str:
    env_var = f"_{name.upper()}_COMPLETE"
    func = f"_{name}_completion"
    setup = f"_{name}_completion_setup"
    lines = f"""\
{func}() {{
    local IFS=$'\\n'
    COMPREPLY=( $( env COMP_WORDS="${{COMP_WORDS[*]}}" \\
                   COMP_CWORD=$COMP_CWORD \\
                   {env_var}=bash_complete $1 ) )
    return 0
}}

{setup}() {{
    complete -o default -F {func} {name}
}}

{setup};
"""
    # Register short aliases (rr) so they also get completion
    for alias in _ALIASES:
        if alias != name:
            a_env = f"_{alias.upper()}_COMPLETE"
            a_func = f"_{alias}_completion"
            a_setup = f"_{alias}_completion_setup"
            lines += f"""
{a_func}() {{
    local IFS=$'\\n'
    COMPREPLY=( $( env COMP_WORDS="${{COMP_WORDS[*]}}" \\
                   COMP_CWORD=$COMP_CWORD \\
                   {a_env}=bash_complete $1 ) )
    return 0
}}

{a_setup}() {{
    complete -o default -F {a_func} {alias}
}}

{a_setup};
"""
    return lines


def _zsh_completion_script(name: str) -> str:
    env_var = f"_{name.upper()}_COMPLETE"
    func = f"_{name}"
    lines = f"""\
#compdef {name}

{func}() {{
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[{name}] )) && return 1

    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" \\
                        COMP_CWORD=$((CURRENT-1)) \\
                        {env_var}=zsh_complete {name})}}")

    for key descr in ${{(kv)response}}; do
        if [[ "$descr" == "_" ]]; then
            completions+=("$key")
        else
            completions_with_descriptions+=("$key":"$descr")
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi

    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}}

if [[ $zsh_eval_context[-1] == loadautofun ]]; then
    {func} "$@"
else
    compdef {func} {name}
fi
"""
    # Register short aliases (rr) so they also get completion
    for alias in _ALIASES:
        if alias != name:
            a_env = f"_{alias.upper()}_COMPLETE"
            a_func = f"_{alias}"
            lines += f"""
{a_func}() {{
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[{alias}] )) && return 1

    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" \\
                        COMP_CWORD=$((CURRENT-1)) \\
                        {a_env}=zsh_complete {alias})}}")

    for key descr in ${{(kv)response}}; do
        if [[ "$descr" == "_" ]]; then
            completions+=("$key")
        else
            completions_with_descriptions+=("$key":"$descr")
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi

    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}}

compdef {a_func} {alias}
"""
    return lines


def _fish_completion_script(name: str) -> str:
    env_var = f"_{name.upper()}_COMPLETE"
    func = f"_{name}_completion"
    lines = f"""\
function {func}
    set -l response (env {env_var}=fish_complete \\
                     COMP_WORDS=(commandline -cp) \\
                     COMP_CWORD=(commandline -t) \\
                     {name})
    for completion in $response
        echo -e $completion
    end
end

complete -c {name} -f -a "({func})"
"""
    # Register short aliases (rr) so they also get completion
    for alias in _ALIASES:
        if alias != name:
            a_env = f"_{alias.upper()}_COMPLETE"
            a_func = f"_{alias}_completion"
            lines += f"""
function {a_func}
    set -l response (env {a_env}=fish_complete \\
                     COMP_WORDS=(commandline -cp) \\
                     COMP_CWORD=(commandline -t) \\
                     {alias})
    for completion in $response
        echo -e $completion
    end
end

complete -c {alias} -f -a "({a_func})"
"""
    return lines
