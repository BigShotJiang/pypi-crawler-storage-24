# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import subprocess
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console
from sdk.cli.eda_helpers import (
    check_version_compat,
    detect_quartus,
    detect_tool,
    extract_qdz,
    find_patch_zips,
    load_sdk_requirements,
    read_env_var,
    scan_device_families,
)
from sdk.cli.resilience import cli_resilient_block


@click.group(name="eda")
def eda_group():
    """Native EDA Tool Management."""
    pass


# ── .env variable names per tool ──
_INSTALL_DIR_VARS = {
    "quartus": "QUARTUS_INSTALL_DIR",
}
_INSTALLER_PATH_VARS = {
    "quartus": "QUARTUS_INSTALLER_PATH",
}


def _resolve_install_dir(env):
    """Resolve the installation directory for an EDA tool from .env, prompting if needed."""
    var_name = _INSTALL_DIR_VARS[env]
    install_dir = read_env_var(var_name)

    if not install_dir:
        console.print(f"⚠️  [yellow]{var_name} is not set in .env[/]")
        console.print(f"   [dim]This should point to the directory where {env.capitalize()} is installed.[/]")
        console.print("   [dim]e.g. /opt/altera, ~/intelFPGA_pro/25.3[/]\n")

        user_path = click.prompt(
            f"   Enter {env.capitalize()} install directory",
            default="",
            show_default=False,
        ).strip()

        if not user_path:
            console.print("   [dim]Skipped. Set it in .env or run rr docker setup.[/]")
            sys.exit(1)

        p = Path(user_path).expanduser().resolve()
        if not p.is_dir():
            console.print(f"   [red]❌ '{p}' is not a valid directory.[/]")
            sys.exit(1)

        install_dir = str(p)

        # Save to .env
        dotenv = Path(".env")
        if dotenv.exists():
            content = dotenv.read_text()
        else:
            content = ""
        lines = content.splitlines()
        found_key = False
        for i, ln in enumerate(lines):
            if ln.strip().startswith(f"{var_name}="):
                lines[i] = f"{var_name}={install_dir}"
                found_key = True
                break
        if not found_key:
            if lines and lines[-1].strip():
                lines.append("")
            lines.append(f"{var_name}={install_dir}")
        dotenv.write_text("\n".join(lines) + "\n")
        console.print("   [green]✅ Saved to .env[/]\n")

    return install_dir


def _resolve_installer_path(env):
    """Resolve the installer/source directory from .env."""
    var_name = _INSTALLER_PATH_VARS[env]
    path = read_env_var(var_name)
    if not path:
        console.print(f"❌ [red]{var_name} is not set in .env[/]")
        console.print("   [dim]Set it with: rr docker setup[/]")
        sys.exit(1)
    p = Path(path).expanduser()
    if not p.exists():
        console.print(f"❌ [red]Directory does not exist: {path}[/]")
        sys.exit(1)
    return str(p)


@eda_group.command(name="status")
@click.argument("tool_name", required=False, default=None)
def eda_status(tool_name):
    """Show installed EDA tools, versions, and device families.

    \\b
    Without arguments, scans all known tools from sdk_requirements.yml.
    With a tool name, shows only that tool.

    \\b
    Examples:
        rr eda status              # Show all
        rr eda status quartus      # Quartus only
        rr eda status vivado       # Vivado only
    """
    reqs = load_sdk_requirements()
    all_tools = reqs.get("tools", {})

    if tool_name:
        if tool_name not in all_tools:
            console.print(f"  [red]❌ Unknown tool '{tool_name}'[/]")
            console.print(f"  [dim]Known tools: {', '.join(sorted(all_tools.keys()))}[/]")
            return
        tools_to_check = {tool_name: all_tools[tool_name]}
    else:
        tools_to_check = all_tools

    console.print("\n🔧 [cyan]EDA Tool Status[/]\n")

    # Group tools by scope for display
    scope_groups = {}
    for name, spec in tools_to_check.items():
        scopes = spec.get("scope", ["other"])
        primary = scopes[0] if scopes else "other"
        scope_groups.setdefault(primary, []).append((name, spec))

    scope_labels = {
        "build": "🏗️  Synthesis & Implementation",
        "sim": "🔬 Simulation",
        "lint": "📝 Analysis & Linting",
        "other": "🔧 Other",
    }

    found_count = 0
    missing_count = 0

    for scope in ["build", "sim", "lint", "other"]:
        entries = scope_groups.get(scope, [])
        if not entries:
            continue

        label = scope_labels.get(scope, scope)
        console.print(f"  [bold]{label}[/]")

        for name, spec in entries:
            check_cmd = spec.get("check_cmd", "")
            parse_regex = spec.get("parse_regex", "")
            role = spec.get("role", "")
            required = spec.get("required", False)

            # Special path for Quartus: use .env-based detection with device families
            if name == "quartus_sh":
                _show_quartus_status(name, spec, role)
                continue

            # Generic detection via PATH
            version, binary_path = detect_tool(check_cmd, parse_regex)

            if version:
                found_count += 1
                console.print(f"    [green]●[/] [cyan]{name}[/] {version}")
                console.print(f"      [dim]{role}[/]")
                if binary_path:
                    console.print(f"      [dim]Binary: {binary_path}[/]")
            elif binary_path:
                found_count += 1
                console.print(f"    [yellow]●[/] [cyan]{name}[/] (version unknown)")
                console.print(f"      [dim]{role}[/]")
                console.print(f"      [dim]Binary: {binary_path}[/]")
            else:
                missing_count += 1
                marker = "[red]●[/]" if required else "[dim]○[/]"
                console.print(f"    {marker} [dim]{name}[/] — not found")
                hint = spec.get("install_hint", "")
                if hint:
                    console.print(f"      [dim]{hint}[/]")

        console.print("")

    console.print(f"  [dim]Summary: {found_count} found, {missing_count} not found[/]\n")


def _show_quartus_status(name, spec, role):
    """Show Quartus status with .env-based detection and device families."""
    var_name = _INSTALL_DIR_VARS.get("quartus", "QUARTUS_INSTALL_DIR")
    install_dir = read_env_var(var_name)

    if not install_dir:
        # Fall back to generic PATH detection
        version, binary_path = detect_tool(spec.get("check_cmd", ""), spec.get("parse_regex", ""))
        if version:
            console.print(f"    [green]●[/] [cyan]{name}[/] {version}")
            console.print(f"      [dim]{role}[/]")
            if binary_path:
                console.print(f"      [dim]Binary: {binary_path}[/]")
        else:
            console.print(f"    [dim]○[/] [dim]{name}[/] — not found")
            hint = spec.get("install_hint", "")
            if hint:
                console.print(f"      [dim]{hint}[/]")
        return

    p = Path(install_dir).expanduser()
    if not p.exists():
        console.print(f"    [red]●[/] [cyan]{name}[/] — {install_dir} does not exist")
        return

    version, major_minor, edition, quartus_sh = detect_quartus(str(p))

    if version:
        edition_label = edition or "unknown"
        console.print(f"    [green]●[/] [cyan]{name}[/] {version} ({edition_label})")
        console.print(f"      [dim]{role}[/]")
        console.print(f"      [dim]Path: {install_dir}[/]")
        if quartus_sh:
            console.print(f"      [dim]Binary: {quartus_sh}[/]")
    else:
        console.print(f"    [yellow]●[/] [cyan]{name}[/] — not detected in {install_dir}")
        return

    # Device families
    families = scan_device_families(str(p))
    if families:
        console.print(f"      [dim]Device families ({len(families)}):[/]")
        for fname, count in families:
            console.print(f"        [green]✅[/] {fname}  [dim]({count} files)[/]")
    else:
        console.print("      [yellow]⚠️  No device families detected[/]")



@eda_group.command(name="add-device")
@click.argument("env", type=click.Choice(["quartus"]), required=True)
def eda_add_device(env):
    """Install device packages (.qdz) into a native EDA installation.

    \\b
    Extracts .qdz device files directly into the Quartus installation
    directory. Same as 'rr docker add-device' but for native installs.

    \\b
    Examples:
        rr eda add-device quartus
    """
    install_dir = _resolve_install_dir(env)
    installer_path = _resolve_installer_path(env)

    console.print("\n📦 [cyan]Quartus Device Package Installer (native)[/]\n")

    # Detect installed Quartus
    version, major_minor, edition, _sh = detect_quartus(install_dir)
    if version:
        console.print(f"  ✅ Quartus {version} ({edition or 'unknown'}) in {install_dir}")
    else:
        console.print(f"  [yellow]⚠️  Quartus not detected in {install_dir}[/]")
        console.print("  [dim]Proceeding anyway — .qdz files will be extracted.[/]")

    # Scan for .qdz files
    p = Path(installer_path)
    qdz_files = sorted(p.glob("*.qdz"))
    if not qdz_files:
        console.print(f"\n  ⚠️  [yellow]No .qdz files found in {installer_path}[/]")
        console.print("  [dim]Download device packages from Intel FPGA Download Center.[/]")
        sys.exit(0)

    console.print(f"\n  📦 Found {len(qdz_files)} device package(s):\n")
    for qf in qdz_files:
        size_gb = qf.stat().st_size / (1024 ** 3)
        console.print(f"     [cyan]{qf.name}[/] ({size_gb:.1f} GB)")

    # Process each .qdz
    installed = 0
    skipped = 0
    failed = 0

    for qf in qdz_files:
        # Version compatibility check
        mismatch = check_version_compat(major_minor, edition, qf.name)
        if mismatch:
            console.print(f"\n  ⚠️  [yellow]{mismatch}[/]")

        # Check if already installed
        import zipfile as zf_mod

        family_dir = None
        with cli_resilient_block("device family detection"):
            z = zf_mod.ZipFile(qf)
            for n in z.namelist():
                if n.startswith("quartus/common/devinfo/") and n.endswith("/"):
                    parts = n.replace("quartus/common/devinfo/", "").strip("/").split("/")
                    if parts[0]:
                        family_dir = parts[0]
                        break

        if family_dir:
            existing = Path(install_dir) / "quartus" / "common" / "devinfo" / family_dir
            if existing.is_dir():
                count = sum(1 for _ in existing.rglob("*") if _.is_file())
                if count > 100:
                    console.print(f"\n  ⏭️  {qf.name}: {family_dir} already installed ({count} files) — skipping")
                    skipped += 1
                    continue

        console.print(f"\n  📥 Installing {qf.name}...")
        with cli_resilient_block("QDZ device extraction"):
            file_count = extract_qdz(str(qf), install_dir, progress=True)
            console.print(f"  ✅ Done ({file_count} files extracted)")
            installed += 1
            continue
        # Reached only if cli_resilient_block caught an error
        failed += 1

    # Summary
    console.print(f"\n  📊 Summary: {installed} installed, {skipped} skipped, {failed} failed")

    # Post-install device inventory
    families = scan_device_families(install_dir)
    if families:
        console.print(f"\n  📦 Installed Device Families ({len(families)}):")
        for name, count in families:
            console.print(f"     [green]✅[/] {name}  [dim]({count} files)[/]")
    console.print("")


@eda_group.command(name="add-patch")
@click.argument("env", type=click.Choice(["quartus"]), required=True)
def eda_add_patch(env):
    """Apply hotfix patches to a native EDA installation.

    \\b
    Extracts .run patch installers from Altera patch ZIPs and
    applies them to the local Quartus installation.

    \\b
    Examples:
        rr eda add-patch quartus
    """
    install_dir = _resolve_install_dir(env)
    installer_path = _resolve_installer_path(env)

    console.print("\n🩹 [cyan]Quartus Patch Installer (native)[/]\n")

    # Detect installed Quartus
    version, major_minor, edition, _sh = detect_quartus(install_dir)
    if version:
        console.print(f"  ✅ Quartus {version} ({edition or 'unknown'}) in {install_dir}")
    else:
        console.print(f"  [red]❌ Quartus not detected in {install_dir}[/]")
        console.print("  [dim]Install Quartus first before applying patches.[/]")
        sys.exit(1)

    # Find patch ZIPs
    patches = find_patch_zips(installer_path)
    if not patches:
        console.print(f"\n  ⚠️  [yellow]No patch .zip files found in {installer_path}[/]")
        console.print("  [dim]Download patches from Intel FPGA Download Center.[/]")
        sys.exit(0)

    console.print(f"\n  🩹 Found {len(patches)} patch(es):\n")
    for pf in patches:
        size_mb = pf.stat().st_size / (1024 ** 2)
        console.print(f"     [cyan]{pf.name}[/] ({size_mb:.0f} MB)")

    # Apply patches
    import tempfile
    import zipfile as zf_mod

    applied = 0
    fail = 0

    for pf in patches:
        console.print(f"\n  🩹 Applying {pf.name}...")

        with tempfile.TemporaryDirectory() as tmp:
            # Extract the ZIP
            with cli_resilient_block("patch ZIP extraction"):
                zf_mod.ZipFile(pf).extractall(tmp)

            # Find the .run file
            run_files = list(Path(tmp).rglob("*-linux.run"))
            if not run_files:
                console.print(f"  ❌ [red]No .run file found inside {pf.name}[/]")
                fail += 1
                continue

            run_file = run_files[0]
            run_file.chmod(run_file.stat().st_mode | 0o755)
            console.print(f"     Installer: {run_file.name}")

            # Show version
            with cli_resilient_block("patch version check"):
                result = subprocess.run(
                    [str(run_file), "--version"],
                    capture_output=True, text=True, timeout=10,
                )
                if result.stdout.strip():
                    console.print(f"     {result.stdout.strip().splitlines()[0]}")

            # Show readme
            readmes = list(Path(tmp).rglob("*-readme.txt"))
            if readmes:
                console.print("     📄 Patch notes:")
                with open(readmes[0]) as f:
                    for line in f.readlines()[:3]:
                        console.print(f"        [dim]{line.rstrip()}[/]")

            # Apply
            console.print("     ⏳ Running patch installer (unattended)...")
            result = subprocess.run(
                [str(run_file), "--mode", "unattended", "--accept_eula", "1", "--installdir", install_dir],
                check=False,
            )
            if result.returncode == 0:
                console.print("     ✅ Patch applied successfully")
                applied += 1
            else:
                console.print(f"     ❌ [red]Failed (exit code: {result.returncode})[/]")
                console.print("     [dim]Tip: you may need to run with sudo if Quartus is in /opt/[/]")
                fail += 1

    # Summary
    console.print(f"\n  📊 Summary: {applied} applied, {fail} failed")

    # Show updated version
    new_ver, _, _, _ = detect_quartus(install_dir)
    if new_ver:
        console.print(f"  📋 Quartus version after patching: {new_ver}")
    console.print("")


@eda_group.command(name="install-unisim")
@click.option("--force", is_flag=True, help="Re-download even if cache exists.")
@click.option("--compile", is_flag=True, help="Pre-compile for the active simulator after download.")
def eda_install_unisim(force, compile):
    """Download Xilinx unisim VHDL sources for simulation.

    \\b
    Fetches unisim_VCOMP.vhd and unisim_VPKG.vhd from the mirror repo
    into ~/.routertl/vendor_libs/unisim/. These are required for Xilinx
    primitive simulation (IBUFDS, MMCME2_ADV, BUFG, etc.).

    \\b
    Examples:
        rr eda install-unisim              # Download sources
        rr eda install-unisim --compile    # Download + pre-compile for NVC
        rr eda install-unisim --force      # Re-download even if cached
    """
    import shutil

    from routertl_core.sim.vendor_libraries import (
        UNISIM_CACHE,
        UNISIM_FILES,
        UNISIM_REPO,
        _has_unisim_sources,
        ensure_nvc_unisim,
    )

    console.print("\n📦 [cyan]Unisim VHDL Source Installer[/]\n")

    # Check existing cache
    if _has_unisim_sources(UNISIM_CACHE) and not force:
        console.print(f"  ✅ Unisim sources already cached at {UNISIM_CACHE}")
        for f in UNISIM_FILES:
            size = (UNISIM_CACHE / f).stat().st_size
            console.print(f"     [dim]{f} ({size / 1024:.0f} KB)[/]")
        console.print("\n  [dim]Use --force to re-download.[/]")
    else:
        # Clean existing cache if force
        if force and UNISIM_CACHE.exists():
            console.print("  🗑️  Removing existing cache...")
            shutil.rmtree(UNISIM_CACHE, ignore_errors=True)

        console.print(f"  📥 Cloning from {UNISIM_REPO}...")
        UNISIM_CACHE.parent.mkdir(parents=True, exist_ok=True)

        git_bin = shutil.which("git")
        if not git_bin:
            console.print("  ❌ [red]git not found on PATH[/]")
            console.print("  [dim]Install git to download unisim sources.[/]")
            return

        with cli_resilient_block("unisim clone"):
            result = subprocess.run(
                [git_bin, "clone", "--depth", "1", UNISIM_REPO, str(UNISIM_CACHE)],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                console.print(f"  ❌ [red]Clone failed[/]: {result.stderr.strip()}")
                return

        if _has_unisim_sources(UNISIM_CACHE):
            console.print(f"  ✅ Sources cached at {UNISIM_CACHE}")
            for f in UNISIM_FILES:
                size = (UNISIM_CACHE / f).stat().st_size
                console.print(f"     [dim]{f} ({size / 1024:.0f} KB)[/]")
        else:
            console.print("  ❌ [red]Clone succeeded but expected files not found[/]")
            return

    # Compile if requested
    if compile:
        console.print("\n  🔨 Pre-compiling for NVC...")
        if ensure_nvc_unisim(verbose=True):
            console.print("  ✅ NVC unisim library compiled")
        else:
            console.print("  ⚠️  [yellow]NVC compilation failed — sources are still cached for manual use[/]")

    console.print("")
