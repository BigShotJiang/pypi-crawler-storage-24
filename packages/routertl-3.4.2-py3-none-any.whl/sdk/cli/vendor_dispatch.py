# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Vendor Dispatch — construct and run vendor-specific TCL commands.

Replaces the Make-level vendor flow logic from ``synthesis.mk`` and
``Common.mk``.  Reads ``project.yml`` and ``build_env.mk`` to construct
the correct ``quartus_sh -t …`` / ``vivado -mode batch -source …`` /
``pnmainc …`` / ``libero SCRIPT:…`` invocations.
"""

import os
import shutil
import subprocess
from pathlib import Path

from sdk.cli.console import console
from sdk.cli.engine_dispatch import ensure_build_env
from sdk.cli.resilience import cli_resilient_block


class VendorToolNotFound(RuntimeError):
    """Raised when the required vendor EDA tool is not on PATH."""


class VendorDispatch:
    """Construct and execute vendor-specific TCL commands.

    Attributes
    ----------
    vendor : str
        One of ``xilinx``, ``altera``, ``lattice``, ``microchip``.
    tool_cmd : str
        The vendor tool command (e.g. ``vivado -mode batch -source``).
    tcl_run : str
        Base command for TCL script execution.
    tcl_flag : str
        Argument separator for TCL args (e.g. ``-tclargs`` for Vivado).
    root_dir : Path
        Project root directory.
    sdk_root : Path
        SDK root directory.
    """

    # Vendor → (tcl_run_builder, tcl_flag)
    _VENDOR_CONFIG = {
        "xilinx": {
            "tcl_flag": "-tclargs",
            "tool_candidates": ["vivado"],
            "tool_suffix": "",
        },
        "altera": {
            "tcl_flag": "",
            "tool_candidates": ["quartus_sh"],
            "tool_suffix": "-t",
        },
        "lattice": {
            "tcl_flag": "",
            "tool_candidates": ["radiantc", "pnmainc"],
            "tool_suffix": "",
        },
        "microchip": {
            "tcl_flag": "SCRIPT_ARGS:",
            "tool_candidates": ["libero"],
            "tool_suffix": "SCRIPT:",
        },
        "opensource": {
            "tcl_flag": "",
            "tool_candidates": ["yosys", "nextpnr-ice40", "nextpnr-ecp5", "nextpnr-gowin"],
            "tool_suffix": "",
        },
    }

    def __init__(
        self,
        vendor: str,
        tool_cmd: str,
        tcl_flag: str,
        root_dir: Path,
        sdk_root: Path,
        build_env: dict[str, str],
        tcl_backend: str | None = None,
        tool_path: str | None = None,
    ):
        self.vendor = vendor
        self.tool_cmd = tool_cmd
        self.tcl_flag = tcl_flag
        self.root_dir = root_dir
        self.sdk_root = sdk_root
        self.build_env = build_env
        self.tcl_backend = tcl_backend
        self.tool_path = tool_path

    @classmethod
    def from_project(
        cls,
        root_dir: Path | None = None,
        project_yml: str = "project.yml",
    ) -> "VendorDispatch":
        """Create a VendorDispatch from project.yml and build_env.mk.

        Parameters
        ----------
        root_dir : Path, optional
            Project root.  Defaults to cwd.
        project_yml : str
            Path to project.yml.
        """
        root_dir = root_dir or Path.cwd()

        # Read build environment
        build_env = ensure_build_env(project_yml)

        # Determine vendor
        vendor = build_env.get("VENDOR", "").lower()
        if not vendor:
            # Fallback: read from project.yml directly
            with cli_resilient_block("vendor detection"):
                import yaml

                yml_path = root_dir / project_yml
                if yml_path.exists():
                    with open(yml_path) as f:
                        cfg = yaml.safe_load(f) or {}
                    hw = cfg.get("hardware") or {}
                    vendor = (hw.get("vendor") or "xilinx").lower()
                else:
                    vendor = "xilinx"

        config = cls._VENDOR_CONFIG.get(vendor, cls._VENDOR_CONFIG["xilinx"])

        # Resolve tool command
        tool_cmd = build_env.get("TOOL_CMD", "")

        # Strip Make variable references like $(QUARTUS_SH) that leak
        # from legacy build_env.mk files (P2.101).  Extract the inner
        # name, lowercase it, and try shutil.which() on that.
        if tool_cmd and tool_cmd.startswith("$("):
            import re as _re

            m = _re.match(r"^\$\((\w+)\)$", tool_cmd)
            inner = m.group(1).lower() if m else ""
            resolved = shutil.which(inner) if inner else None
            tool_cmd = inner if resolved else ""

        # P3.42: tcl_backend may be set to a flow-specific TCL directory
        tcl_backend = None

        if not tool_cmd:
            # P3.25: Reorder candidates based on hardware.tool from project.yml
            hw_tool = ""
            with cli_resilient_block("hardware.tool detection"):
                import yaml as _yaml

                yml_path = root_dir / project_yml
                if yml_path.exists():
                    with open(yml_path) as f:
                        _cfg = _yaml.safe_load(f) or {}
                    _hw = _cfg.get("hardware") or {}
                    hw_tool = (_hw.get("tool") or "").lower() if isinstance(_hw, dict) else ""

            candidates = list(config["tool_candidates"])
            if hw_tool:
                # Look up the vendor database for the tool variant's tool_cmd
                # and tcl_backend (P3.42: edition vs flow distinction)
                with cli_resilient_block("vendor database tool lookup"):
                    import yaml as _yaml2

                    vdb_paths = [
                        root_dir / "vendor" / "routertl" / "sdk" / "engine" / "supported_vendors.yml",
                        Path(__file__).parent.parent / "engine" / "supported_vendors.yml",
                    ]
                    for vdb_path in vdb_paths:
                        if vdb_path.exists():
                            with open(vdb_path) as f:
                                vdb = _yaml2.safe_load(f) or {}
                            v_data = vdb.get(vendor, {})
                            tool_entry = v_data.get("tools", {}).get(hw_tool, {})
                            if tool_entry and "tool_cmd" in tool_entry:
                                preferred = tool_entry["tool_cmd"]
                                # Move preferred to front of candidates
                                if preferred in candidates:
                                    candidates.remove(preferred)
                                candidates.insert(0, preferred)
                            # P3.42: resolve tcl_backend for flow-variant tools
                            if tool_entry and "tcl_backend" in tool_entry:
                                tcl_backend = tool_entry["tcl_backend"]
                            break

            for candidate in candidates:
                if shutil.which(candidate):
                    tool_cmd = candidate
                    break
            if not tool_cmd:
                tool_cmd = candidates[0]

        # Store tool_path for later injection into subprocess env dicts
        # (do NOT mutate os.environ — see ADR D.5 / Roast audit Burn #2)
        _tool_path = None
        with cli_resilient_block("tool_path injection"):
            import yaml

            yml_path = root_dir / project_yml
            if yml_path.exists():
                with open(yml_path) as f:
                    cfg = yaml.safe_load(f) or {}
                hw = cfg.get("hardware") or {}
                _tool_path = hw.get("tool_path") if isinstance(hw, dict) else None

        # Resolve SDK root
        from sdk.cli.sdk_root import resolve_sdk_root

        sdk_root = resolve_sdk_root() or root_dir

        # Build tcl_run command
        suffix = config["tool_suffix"]
        if suffix:
            tool_cmd = f"{tool_cmd} {suffix}"

        return cls(
            vendor=vendor,
            tool_cmd=tool_cmd,
            tcl_flag=config["tcl_flag"],
            root_dir=root_dir,
            sdk_root=sdk_root,
            build_env=build_env,
            tcl_backend=tcl_backend,
            tool_path=_tool_path,
        )

    def _tcl_path(self, script_name: str) -> Path:
        """Resolve a vendor-specific TCL script path.

        P3.42: Uses ``tcl_backend`` when set (flow-variant tools that
        need a different TCL directory).  Falls back to ``self.vendor``
        for edition variants and legacy configurations.
        """
        backend = self.tcl_backend or self.vendor
        return self.sdk_root / "tcl" / backend / script_name

    def _check_tool_available(self):
        """Raise VendorToolNotFound if the vendor tool is not on PATH."""
        tool_bin = self.tool_cmd.split()[0]
        if not shutil.which(tool_bin):
            console.print(
                f"❌ [red]Vendor tool '{tool_bin}' not found on PATH.[/]\n"
                f"   VENDOR={self.vendor}\n"
                f"   Hint: Is the {self.vendor} toolchain installed?\n"
                "   Run [cyan]rr doctor[/] to diagnose."
            )
            raise VendorToolNotFound(tool_bin)

    def _run_tcl(self, tcl_script: Path, *tcl_args: str) -> int:
        """Run a vendor TCL script with correct invocation syntax.

        For Microchip/Libero, generates a temporary wrapper TCL because
        Libero's ``SCRIPT_ARGS:`` only passes the first token to
        ``$::argv`` — subsequent arguments are silently dropped (P2.100).

        Returns the process exit code.
        """
        self._check_tool_available()

        wrapper_path: Path | None = None

        if self.vendor == "microchip" and tcl_args:
            # Libero workaround: write a temp TCL wrapper that explicitly
            # sets $::argv / $::argc, then sources the real script.
            import tempfile

            tcl_list_items = " ".join(
                f'"{a}"' if a else '""' for a in tcl_args
            )
            wrapper_content = (
                f'set ::argv [list {tcl_list_items}]\n'
                f'set ::argc [llength $::argv]\n'
                f'source "{tcl_script}"\n'
            )
            fd, wrapper_file = tempfile.mkstemp(
                suffix=".tcl", prefix="rr_libero_"
            )
            wrapper_path = Path(wrapper_file)
            with os.fdopen(fd, "w") as f:
                f.write(wrapper_content)

            # Invoke: libero SCRIPT:<wrapper>
            tool_bin = self.tool_cmd.split()[0]
            cmd = [tool_bin, f"SCRIPT:{wrapper_path}"]
        else:
            parts = self.tool_cmd.split()
            cmd = parts + [str(tcl_script)]
            if self.tcl_flag:
                cmd.append(self.tcl_flag)
            cmd.extend(tcl_args)

        console.print(f"   [dim]→ {' '.join(cmd[:4])}…[/]")

        # Build subprocess env with tool_path injection (no os.environ mutation)
        env = os.environ.copy()
        if self.tool_path:
            from sdk.cli.env_setup import inject_tool_path

            env = inject_tool_path(env, self.tool_path)

        try:
            result = subprocess.run(cmd, check=False, env=env)
            return result.returncode
        finally:
            if wrapper_path and wrapper_path.exists():
                wrapper_path.unlink()

    # ── Public API ────────────────────────────────────────────────────

    def _project_file_exists(self) -> bool:
        """Check whether the vendor project file already exists."""
        ext_map = {
            "lattice": ".rdf",
            "microchip": ".prjx",
            "xilinx": ".xpr",
            "altera": ".qpf",
        }
        ext = ext_map.get(self.vendor, "")
        if not ext:
            return True
        project_dir = self.root_dir / "project"
        return any(project_dir.glob(f"*{ext}"))

    def ensure_project(self) -> int:
        """Create the vendor project if it doesn't exist yet.

        Returns 0 on success or if the project already exists.
        """
        if self._project_file_exists():
            return 0
        console.print(
            "   [dim]Project file not found — generating project first…[/]"
        )
        return self.project()

    def synthesis(self) -> int:
        """Run full project synthesis.

        Auto-generates the vendor project if it doesn't exist yet.
        """
        rc = self.ensure_project()
        if rc != 0:
            console.print(
                "❌ [red]Project generation failed — cannot proceed "
                "with synthesis.[/]"
            )
            return rc
        console.print("🚀 [blue]Synthesizing Project...[/]")
        tcl = self._tcl_path("gen_synthesis.tcl")
        rc = self._run_tcl(tcl, str(self.root_dir))
        if rc == 0:
            self._record_known_part()
        return rc

    def implementation(self) -> int:
        """Run implementation (place & route)."""
        console.print("🚀 [blue]Running Implementation...[/]")
        tcl = self._tcl_path("gen_implementation.tcl")
        return self._run_tcl(tcl, str(self.root_dir))

    def bitstream(self) -> int:
        """Generate bitstream."""
        console.print("🚀 [blue]Generating Bitstream...[/]")
        tcl = self._tcl_path("gen_bitstream.tcl")
        return self._run_tcl(tcl, str(self.root_dir))

    def project(
        self,
        syn_files: str = "",
        ip_files: str = "",
        sim_files: str = "",
        tcl_files: str = "",
        xdc_files: str = "",
        netlist_files: str = "",
    ) -> int:
        """Generate vendor project."""
        console.print("🏗  [blue]Building Project...[/]")
        tcl = self._tcl_path("gen_project.tcl")
        return self._run_tcl(
            tcl,
            str(self.root_dir),
            syn_files or self.build_env.get("SYN_FILES", ""),
            ip_files or self.build_env.get("IP_FILES", ""),
            sim_files or self.build_env.get("SIM_FILES", ""),
            tcl_files or self.build_env.get("TCL_FILES", ""),
            xdc_files or self.build_env.get("XDC_FILES", self.build_env.get("SDC_FILES", "")),
            netlist_files or self.build_env.get("NETLIST_FILES", ""),
        )

    def program(self) -> int:
        """Program FPGA device."""
        console.print("🚀 [blue]Programming FPGA device...[/]")
        tcl = self._tcl_path("gen_program.tcl")
        return self._run_tcl(tcl, str(self.root_dir))

    def npm_synthesis(
        self,
        top: str,
        npm_files: str,
        ip_files: str = "",
        xdc_files: str = "",
        netlist_files: str = "",
    ) -> int:
        """Run Non-Project Mode synthesis for a single module."""
        console.print(f"🚀 [blue]Synthesizing {top} (NPM)...[/]")
        tcl = self._tcl_path("non_project_mode.tcl")
        return self._run_tcl(
            tcl,
            str(self.root_dir),
            npm_files,
            ip_files or self.build_env.get("IP_FILES", ""),
            xdc_files or self.build_env.get("XDC_FILES", self.build_env.get("SDC_FILES", "")),
            top,
            netlist_files or self.build_env.get("NETLIST_FILES", ""),
        )

    def _record_known_part(self):
        """Record successfully synthesized FPGA part (mirrors Make behavior)."""
        parts_file = self.root_dir / ".routertl" / "known_parts.txt"
        parts_file.parent.mkdir(parents=True, exist_ok=True)
        fpga_part = self.build_env.get("FPGA_PART", "")
        if not fpga_part:
            return
        entry = f"{self.vendor} {fpga_part}"
        if parts_file.exists():
            existing = parts_file.read_text()
            if entry in existing:
                return
        else:
            # First-time creation: write header
            parts_file.write_text(
                "# RouteRTL — Known FPGA Parts (auto-updated)\n"
                "# Format: <vendor> <part>\n"
            )
        with open(parts_file, "a") as f:
            f.write(f"{entry}\n")
