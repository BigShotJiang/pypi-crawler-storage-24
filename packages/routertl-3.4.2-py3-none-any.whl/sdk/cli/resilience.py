# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
CLI Resilience Utilities
========================

Provides structured error handling for CLI commands that must never
crash but should *report* when things go wrong.

Usage::

    from sdk.cli.resilience import cli_resilient, cli_resilient_block

    # Pattern 1: Function-level — returns default on failure
    @cli_resilient("project YAML loading", default=None)
    def _read_project_yml():
        with open("project.yml") as f:
            return yaml.safe_load(f)

    # Pattern 2: Inline block — sets variable or skips on failure
    with cli_resilient_block("SDK version check"):
        patch = int(subprocess.run(...).stdout.strip())
"""

from __future__ import annotations

import functools
import logging
import traceback
from contextlib import contextmanager

_log = logging.getLogger("cli.resilience")


def cli_resilient(description: str, *, default=None):
    """Decorator for CLI helper functions that must not crash.

    On ``Exception``, logs the traceback at DEBUG level and returns
    *default* instead of propagating.  A dim warning is printed to
    stderr so the user knows something was skipped.

    Parameters
    ----------
    description:
        Human-readable label for what this function does, shown in
        the warning message (e.g. "project YAML loading").
    default:
        Value to return when the decorated function raises.
    """

    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except Exception as exc:
                _log.debug(
                    "cli_resilient caught %s in %s:\n%s",
                    type(exc).__name__,
                    fn.__qualname__,
                    traceback.format_exc(),
                )
                return default

        return wrapper

    return decorator


@contextmanager
def cli_resilient_block(description: str):
    """Context manager for inline resilience blocks.

    Catches ``Exception``, logs traceback at DEBUG, and continues.

    Usage::

        with cli_resilient_block("SDK commit hash"):
            commit = subprocess.run(...).stdout.strip()

    Parameters
    ----------
    description:
        Human-readable label for the block, used in log messages.
    """
    try:
        yield
    except Exception as exc:
        _log.debug(
            "cli_resilient_block caught %s in '%s':\n%s",
            type(exc).__name__,
            description,
            traceback.format_exc(),
        )
