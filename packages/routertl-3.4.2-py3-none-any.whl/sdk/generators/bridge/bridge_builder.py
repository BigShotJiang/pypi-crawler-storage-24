# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
bridge_builder.py — BridgeBuilder Utilities
============================================

Shared helpers that eliminate the copy-paste boilerplate found in every
``build_*`` function inside ``bridge_logic.py``.

Every bridge FSM builder repeats the same skeleton:

1. Resolve interface signals by name → lookup closure
2. Build a list of ``NonBlockingAssign`` reset statements
3. Build sensitivity list, ``If(reset_cond, ...)`` wrapper, and ``Always`` block

``BridgeBuilder`` encapsulates all three steps so that each ``build_*``
function only needs to express its unique FSM transition logic.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable, Dict, List, Tuple

if TYPE_CHECKING:
    from bus_interfaces import AvalonMMInterface, AXI4Interface, AXILiteInterface, NativeMemInterface

    BusInterface = AvalonMMInterface | AXI4Interface | AXILiteInterface | NativeMemInterface

from hdl_ast import (
    Always,
    Case,
    Edge,
    HdlNode,
    If,
    NonBlockingAssign,
    ResetStyle,
    Signal,
)

# Type alias for a signal-lookup callable: name → Signal
SignalLookup = Callable[[str], Signal]


class BridgeBuilder:
    """Shared utilities for bridge FSM construction.

    All methods are static — no instance state is needed.
    """

    # ------------------------------------------------------------------
    # Signal resolution
    # ------------------------------------------------------------------
    @staticmethod
    def resolve_signals(
        interface: "BusInterface",
    ) -> Tuple[Dict[str, Signal], SignalLookup]:
        """Build a name→Signal dict and a lookup closure for *interface*.

        Returns
        -------
        sig_dict :
            ``{full_name: Signal}`` for every signal on the interface.
        lookup :
            ``lookup("awvalid")`` → the ``Signal`` object, respecting
            the interface prefix.
        """
        sig_dict: Dict[str, Signal] = {
            s.name: s for s in interface.get_signals()
        }
        prefix = interface.prefix

        def _lookup(name: str) -> Signal:
            prefixed = f"{prefix}_{name}" if prefix else name
            return sig_dict[prefixed]

        return sig_dict, _lookup

    # ------------------------------------------------------------------
    # Reset statement list
    # ------------------------------------------------------------------
    @staticmethod
    def build_reset_stmts(
        registers: List[Tuple[Signal, object]],
        output_signals: List[Signal],
    ) -> List[HdlNode]:
        """Construct the reset branch assignment list.

        Parameters
        ----------
        registers :
            Pairs of ``(register_signal, reset_value)`` for internal
            registers (state, addr, data, …).
        output_signals :
            Output-direction signals that must be driven to zero (or
            their default) during reset.

        Returns
        -------
        A list of ``NonBlockingAssign`` nodes suitable for the *then_body*
        of the reset ``If`` node.
        """
        stmts: List[HdlNode] = []
        for reg, val in registers:
            stmts.append(NonBlockingAssign(reg, val))
        for sig in output_signals:
            stmts.append(NonBlockingAssign(sig, 0))
        return stmts

    # ------------------------------------------------------------------
    # Custom reset statement list (pre-built)
    # ------------------------------------------------------------------
    @staticmethod
    def build_reset_stmts_raw(
        assignments: List[Tuple[Signal, object]],
    ) -> List[HdlNode]:
        """Construct reset statements from explicit (signal, value) pairs.

        Use this when the caller needs full control over the reset value
        of each signal (e.g. waitrequest=1 instead of 0).
        """
        return [NonBlockingAssign(sig, val) for sig, val in assignments]

    # ------------------------------------------------------------------
    # Always block (tail boilerplate)
    # ------------------------------------------------------------------
    @staticmethod
    def build_always_block(
        clk: Signal,
        rst: Signal,
        reset_style: ResetStyle,
        active_low_reset: bool,
        reset_stmts: List[HdlNode],
        fsm_case: Case,
    ) -> Always:
        """Wrap an FSM ``Case`` node into a clocked ``Always`` block.

        Handles:
        * Reset condition string (``!rst_n`` or ``rst``)
        * ``If(reset_cond, then_body=reset_stmts, else_body=[fsm_case])``
        * Sensitivity list (``posedge clk`` ± async reset edge)

        Returns
        -------
        The fully-assembled ``Always`` node ready for the module body.
        """
        # Reset condition string
        reset_cond = f"!{rst.name}" if active_low_reset else rst.name

        # If (reset) … else case(state)
        fsm_if = If(
            reset_cond,
            then_body=reset_stmts,
            else_body=[fsm_case],
        )

        # Sensitivity list
        sensitivity: List[Tuple[Edge, Signal]] = [(Edge.POSEDGE, clk)]
        if reset_style == ResetStyle.ASYNC:
            edge = Edge.NEGEDGE if active_low_reset else Edge.POSEDGE
            sensitivity.append((edge, rst))

        return Always(sensitivity, body=[fsm_if])

    # ------------------------------------------------------------------
    # Register creation helper
    # ------------------------------------------------------------------
    @staticmethod
    def create_registers(
        specs: List[Tuple[str, int, object]],
    ) -> Tuple[List[Signal], Dict[str, Signal]]:
        """Create internal register signals from a spec list.

        Parameters
        ----------
        specs :
            List of ``(name, width, reset_val)`` tuples.  Pass ``None``
            for *reset_val* if no reset value is needed (defaults to 0).

        Returns
        -------
        signal_list :
            Flat list of ``Signal`` objects (for the caller's return
            value).
        signal_dict :
            Name→Signal dict for convenient access inside the builder.
        """
        from hdl_ast import Direction

        sig_list: List[Signal] = []
        sig_dict: Dict[str, Signal] = {}
        for name, width, reset_val in specs:
            s = Signal(name, width=width, direction=Direction.LOCAL, reset_val=reset_val)
            sig_list.append(s)
            sig_dict[name] = s
        return sig_list, sig_dict

    # ------------------------------------------------------------------
    # Full FSM assembly (Case + default + Always)
    # ------------------------------------------------------------------
    @staticmethod
    def build_fsm(
        state_reg: Signal,
        branches: List[Tuple[object, List[HdlNode]]],
        idle_state: object,
        clk: Signal,
        rst: Signal,
        reset_style: ResetStyle,
        active_low_reset: bool,
        reset_stmts: List[HdlNode],
    ) -> Always:
        """Assemble a complete FSM from branch bodies.

        Builds a ``Case`` statement with all *branches*, appends a
        default branch that transitions to *idle_state*, then wraps
        everything in a clocked ``Always`` block via
        :meth:`build_always_block`.
        """
        fsm_case = Case(state_reg)
        for state_val, body in branches:
            fsm_case.add_branch(state_val, body)
        fsm_case.add_branch(None, [NonBlockingAssign(state_reg, idle_state)])
        return BridgeBuilder.build_always_block(
            clk, rst, reset_style, active_low_reset, reset_stmts, fsm_case,
        )

    # ------------------------------------------------------------------
    # Output deassertion helper (IDLE defaults)
    # ------------------------------------------------------------------
    @staticmethod
    def deassert_outputs(signals: List[Signal]) -> List[HdlNode]:
        """Generate ``NonBlockingAssign(sig, 0)`` for each signal.

        Used for the common IDLE-state pattern of driving all output
        handshakes to zero before checking for new transactions.
        """
        return [NonBlockingAssign(sig, 0) for sig in signals]
