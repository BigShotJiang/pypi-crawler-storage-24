# RTL Bridge Generator — Emitter

> Backend layer: converts the HDL AST into synthesizable source files.

---

## Architecture

The emitter is split into two layers to maximise reuse:

```
BaseEmitter  (emitter_base.py)
│  NodeVisitor subclass
│  indent/dedent helpers, line buffer
│  emit() / save() public API
│  _render_expr() for expressions
│  _emit_header() for file header
│
├── SystemVerilogEmitter  (emitter_sv.py)
│     visit_Module, visit_Assign, visit_Always,
│     visit_NonBlockingAssign, visit_If, visit_Case
│     → outputs .sv files
│
└── VHDLEmitter  (emitter_vhdl.py)  [future]
      Same visit_* interface, different syntax
      → outputs .vhd files
```

**~80 % of the visitor plumbing** (dispatch, indentation, expression
rendering, header, save) lives in `BaseEmitter`.  A `VHDLEmitter` only
needs to override the `visit_*` methods.

---

## Usage

```python
from emitter_sv import SystemVerilogEmitter
from bus_interfaces import AXILiteInterface, InterfaceRole
from hdl_ast import Module, Signal, Direction

axi = AXILiteInterface(data_width=32, addr_width=16,
                       role=InterfaceRole.SLAVE, prefix="s_axi")
m = Module("my_bridge")
for sig in axi.get_signals():
    m.add_port(sig)

emitter = SystemVerilogEmitter(
    parameters={"Base Address": 0x4000_0000, "Data Width": 32}
)

# Print to stdout
print(emitter.emit(m))

# Save to file
emitter.save(m, "my_bridge.sv")
```

---

## Generated Output Example

```systemverilog
// ====================================================================
// Auto-generated SystemVerilog — DO NOT EDIT
// Generated: 2026-02-18 23:24:00 UTC
// Parameters:
//   Base Address: 0x40000000
//   Data Width: 32
// ====================================================================

module my_bridge (
    // Inputs
    input  logic [15:0] s_axi_awaddr,
    input  logic        s_axi_awvalid,
    ...
    // Outputs
    output logic        s_axi_awready,
    output logic [31:0] s_axi_rdata,
    output logic [1:0]  s_axi_rresp,
    output logic        s_axi_rvalid
);

    // Continuous assignments
    assign s_axi_awready = 1'b1;

    // always_ff block
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= 2'b00;
        end else begin
            state <= next_state;
        end
    end

endmodule
```

---

## Node → SV Mapping

| AST Node | SystemVerilog output |
|----------|---------------------|
| `Module` | `module … endmodule` |
| `Signal` (INPUT) | `input  logic [N:0] name,` |
| `Signal` (OUTPUT) | `output logic [N:0] name,` |
| `Signal` (LOCAL) | `logic [N:0] name;` |
| `Assign` | `assign target = source;` |
| `Always` (clocked) | `always_ff @(posedge clk …) begin … end` |
| `Always` (comb) | `always_comb begin … end` |
| `NonBlockingAssign` | `target <= source;` |
| `If` | `if (cond) begin … end else begin … end` |
| `Case` | `case (sel) … default: begin … end endcase` |
| `Slice` | `sig[msb:lsb]` or `sig[bit]` |
| `Concat` | `{a, b, c}` |
| `Ternary` | `(cond ? a : b)` |

---

## Formatting Rules

| Rule | Detail |
|------|--------|
| Indentation | 4 spaces per level (configurable) |
| Port grouping | Inputs first, then Outputs, with section comments |
| Trailing commas | All ports except the last have a trailing `,` |
| `begin`/`end` | Every `if`, `else`, and `case` branch is wrapped |
| Signal widths | `[N:0]` for multi-bit; no range for single-bit |
| Integer literals | Emitted as-is (`0`, `1`, …) |
| String expressions | Emitted verbatim (e.g. `(awaddr - 0x1000) >> 2`) |

> [!NOTE]
> Every `if` and `case` branch is wrapped in `begin`/`end` blocks,
> eliminating all "dangling else" ambiguities regardless of nesting depth.

---

## `BaseEmitter` API

```python
class BaseEmitter(NodeVisitor):
    LANGUAGE: str                    # set by subclass

    def emit(self, node: HdlNode) -> str: ...
    def save(self, node: HdlNode, filename: str | Path) -> Path: ...

    # Helpers for subclasses
    def _line(self, text: str = "") -> None: ...
    def _blank(self) -> None: ...
    def _indent(self) -> None: ...
    def _dedent(self) -> None: ...
    def _emit_header(self, comment_prefix: str = "//") -> None: ...
    def _render_expr(self, expr: object) -> str: ...
```

---

## Adding a VHDL Emitter

```python
from emitter_base import BaseEmitter
from hdl_ast import Module, Assign, Always, ...

class VHDLEmitter(BaseEmitter):
    LANGUAGE = "VHDL"

    def visit_Module(self, node: Module) -> None:
        self._emit_header(comment_prefix="--")
        self._line(f"entity {node.name} is")
        self._line("  port (")
        ...
        self._line(f"end entity {node.name};")
        self._blank()
        self._line(f"architecture rtl of {node.name} is")
        ...
        self._line("begin")
        self._indent()
        for stmt in node.body:
            self.visit(stmt)
        self._dedent()
        self._line("end architecture rtl;")

    def visit_Assign(self, node: Assign) -> None:
        target = self._render_expr(node.target)
        source = self._render_expr(node.source)
        self._line(f"{target} <= {source};")

    # ... override visit_Always, visit_If, visit_Case ...
```

Only the `visit_*` methods need to be written — `emit()`, `save()`,
`_render_expr()`, `_emit_header()`, and all indentation helpers are
inherited from `BaseEmitter`.
