# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
addr_map.py — Address Mapping and Transformation
=================================================

Middle-end helper for the RTL bridge generator.

The ``AddressMap`` class is a **pure-Python descriptor** that captures the
address-space parameters of a bridge and generates the AST ``Expression``
nodes needed by the Logic Layer.

Address transformation formula
-------------------------------
Given:
    * ``axi_byte_addr`` — the byte address presented by the AXI/Avalon master
    * ``base_addr``     — first byte address of the mapped region
    * ``data_width``    — bus data width in bits (must be power-of-two ≥ 8)

The native word address is:

    word_addr = (axi_byte_addr - base_addr) >> log2(data_width / 8)

Example (data_width=32, base_addr=0x4000_0000):
    AXI byte addr 0x4000_0004 → word addr 1
    AXI byte addr 0x4000_0008 → word addr 2

Range check:
    in_range = (axi_byte_addr >= base_addr) AND
               (axi_byte_addr <  base_addr + size_bytes)

Pipeline position:
    Frontend (Interfaces) → Middle-end (AST) → [THIS MODULE] → Logic Layer
"""

from __future__ import annotations

import math
from typing import Optional

from hdl_ast import Expression, Signal, Slice

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_power_of_two(n: int) -> bool:
    return n >= 1 and (n & (n - 1)) == 0


def _log2_exact(n: int) -> int:
    if not _is_power_of_two(n):
        raise ValueError(f"{n} is not a power of two")
    return int(math.log2(n))


# ---------------------------------------------------------------------------
# AddressMap
# ---------------------------------------------------------------------------


class AddressMap:
    """Describes the address-space mapping for one bridge instance.

    Parameters
    ----------
    data_width:
        Bus data width in bits.  Must be a power-of-two ≥ 8.
        Determines the byte-to-word shift amount.
    addr_width:
        Width of the *native* word-address bus in bits.
        Used to validate that ``size_bytes`` fits.
    base_addr:
        First *byte* address in the master's address space that maps to
        native word 0.  Defaults to ``0``.
    size_bytes:
        Total size of the mapped region in bytes.  If ``None``, defaults
        to ``2**addr_width * (data_width // 8)`` (full address space).

    Raises
    ------
    ValueError
        If ``data_width`` is not a power-of-two ≥ 8, if ``addr_width < 1``,
        or if ``size_bytes`` overflows the native address space.
    """

    def __init__(
        self,
        data_width: int,
        addr_width: int,
        base_addr: int = 0,
        size_bytes: Optional[int] = None,
    ) -> None:
        """Create an address map with base, size, and decode settings."""
        if not _is_power_of_two(data_width) or data_width < 8:
            raise ValueError(f"data_width must be a power-of-two ≥ 8, got {data_width}")
        if addr_width < 1:
            raise ValueError(f"addr_width must be ≥ 1, got {addr_width}")
        if base_addr < 0:
            raise ValueError(f"base_addr must be ≥ 0, got {base_addr}")

        self.data_width: int = data_width
        self.addr_width: int = addr_width
        self.base_addr: int = base_addr

        bytes_per_word: int = data_width // 8
        max_size: int = (2**addr_width) * bytes_per_word

        if size_bytes is None:
            self.size_bytes: int = max_size
        else:
            if size_bytes < 1:
                raise ValueError(f"size_bytes must be ≥ 1, got {size_bytes}")
            if size_bytes > max_size:
                raise ValueError(
                    f"size_bytes ({size_bytes:#x}) overflows native address space "
                    f"({max_size:#x} bytes for addr_width={addr_width}, "
                    f"data_width={data_width})"
                )
            self.size_bytes = size_bytes

        # Derived constants (useful for the Logic Layer)
        self.bytes_per_word: int = bytes_per_word
        self.byte_shift: int = _log2_exact(bytes_per_word)  # log2(data_width/8)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate(self) -> None:
        """Re-run all consistency checks.  Raises ``ValueError`` on failure."""
        # All checks are already in __init__; this is a public re-entry point
        # for callers that mutate fields after construction.
        AddressMap(
            data_width=self.data_width,
            addr_width=self.addr_width,
            base_addr=self.base_addr,
            size_bytes=self.size_bytes,
        )

    # ------------------------------------------------------------------
    # AST expression builders
    # ------------------------------------------------------------------

    def byte_offset_expr(self, axi_addr_sig: Signal) -> Expression:
        """Return an AST expression for ``axi_addr - base_addr``.

        If ``base_addr == 0`` the subtraction is omitted and the signal
        itself is returned (no unnecessary logic).

        Parameters
        ----------
        axi_addr_sig:
            The AXI/Avalon byte-address signal (e.g. ``awaddr``).

        Returns
        -------
        Expression
            A string expression suitable for use as an RHS in an ``Assign``
            or ``NonBlockingAssign`` node.
        """
        if self.base_addr == 0:
            return axi_addr_sig
        return f"({axi_addr_sig.name} - {self.base_addr:#x})"

    def word_addr_expr(self, axi_addr_sig: Signal) -> Expression:
        """Return an AST expression for the native word address.

        Formula::

            word_addr = (axi_byte_addr - base_addr) >> byte_shift

        If ``byte_shift == 0`` (8-bit data bus, byte-addressed), the shift
        is omitted.

        Parameters
        ----------
        axi_addr_sig:
            The AXI/Avalon byte-address signal.

        Returns
        -------
        Expression
            A string expression for the word address, truncated to
            ``addr_width`` bits via a Verilog/VHDL slice annotation.
        """
        offset = self.byte_offset_expr(axi_addr_sig)

        if self.byte_shift == 0:
            # 8-bit bus: byte address == word address
            word_expr: Expression = offset
        elif isinstance(offset, Signal):
            # base_addr == 0: use a Slice node for clean AST representation
            msb = axi_addr_sig.width - 1
            lsb = self.byte_shift
            word_expr = Slice(axi_addr_sig, msb, lsb)
        else:
            # base_addr != 0: emit a string shift expression
            word_expr = f"({offset} >> {self.byte_shift})"

        # Annotate with the target width so the emitter can truncate
        if isinstance(word_expr, str):
            return f"{word_expr}[{self.addr_width - 1}:0]"
        return word_expr

    def in_range_expr(self, axi_addr_sig: Signal) -> Expression:
        """Return an AST expression that is true when the address is in range.

        Formula::

            (axi_addr >= base_addr) && (axi_addr < base_addr + size_bytes)

        If ``base_addr == 0`` the lower-bound check is omitted (always true
        for unsigned addresses).

        Parameters
        ----------
        axi_addr_sig:
            The AXI/Avalon byte-address signal.

        Returns
        -------
        Expression
            A boolean string expression for use in an ``If`` condition.
        """
        upper = self.base_addr + self.size_bytes
        upper_hex = f"{upper:#x}"
        name = axi_addr_sig.name

        if self.base_addr == 0:
            return f"({name} < {upper_hex})"

        lower_hex = f"{self.base_addr:#x}"
        return f"(({name} >= {lower_hex}) && ({name} < {upper_hex}))"

    def out_of_range_expr(self, axi_addr_sig: Signal) -> Expression:
        """Logical inverse of ``in_range_expr`` — for error detection."""
        inner = self.in_range_expr(axi_addr_sig)
        return f"!({inner})"

    # ------------------------------------------------------------------
    # Introspection helpers
    # ------------------------------------------------------------------

    @property
    def max_byte_addr(self) -> int:
        """Last valid byte address (inclusive) in the mapped region."""
        return self.base_addr + self.size_bytes - 1

    @property
    def num_words(self) -> int:
        """Number of addressable words in the mapped region."""
        return self.size_bytes // self.bytes_per_word

    def __repr__(self) -> str:
        return (
            f"AddressMap("
            f"data_width={self.data_width}, "
            f"addr_width={self.addr_width}, "
            f"base_addr={self.base_addr:#x}, "
            f"size_bytes={self.size_bytes:#x}, "
            f"byte_shift={self.byte_shift})"
        )


# ---------------------------------------------------------------------------
# AddressTransformer  (thin wrapper — convenience alias)
# ---------------------------------------------------------------------------


class AddressTransformer(AddressMap):
    """Alias for ``AddressMap`` with an intent-revealing name.

    Use ``AddressTransformer`` when you want to emphasise the *active*
    role of computing the address transformation, and ``AddressMap`` when
    you want to emphasise the *declarative* description of the mapping.

    Both names are exported from this module.
    """


# ---------------------------------------------------------------------------
# AXI response codes (convenience constants for the Logic Layer)
# ---------------------------------------------------------------------------


class AXIResp:
    """AXI4 / AXI4-Lite BRESP / RRESP encoding constants."""

    OKAY: str = "2'b00"
    EXOKAY: str = "2'b01"  # exclusive access OK (not used in AXI-Lite)
    SLVERR: str = "2'b10"  # slave error
    DECERR: str = "2'b11"  # decode error


class AvalonResp:
    """Avalon-MM ``response[1:0]`` encoding constants."""

    OKAY: str = "2'b00"
    RESERVED: str = "2'b01"
    SLVERR: str = "2'b10"
    DECERR: str = "2'b11"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    "AddressMap",
    "AddressTransformer",
    "AXIResp",
    "AvalonResp",
]
