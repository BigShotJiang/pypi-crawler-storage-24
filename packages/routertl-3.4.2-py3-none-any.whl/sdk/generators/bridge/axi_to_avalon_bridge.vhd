-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

-- ====================================================================
-- Auto-generated VHDL — DO NOT EDIT
-- Generated: 2026-02-19 15:01:53 UTC
-- Parameters:
--   Base Address: 0
--   Data Width: 32
--   Protocol: axilite
-- ====================================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity axi_to_avalon_bridge is
    port (
        clk                     : in  std_logic;
        rst_n                   : in  std_logic;
        s_awaddr                : in  std_logic_vector(15 downto 0);
        s_awprot                : in  std_logic_vector(2 downto 0);
        s_awvalid               : in  std_logic;
        s_wdata                 : in  std_logic_vector(31 downto 0);
        s_wstrb                 : in  std_logic_vector(3 downto 0);
        s_wvalid                : in  std_logic;
        s_bready                : in  std_logic;
        s_araddr                : in  std_logic_vector(15 downto 0);
        s_arprot                : in  std_logic_vector(2 downto 0);
        s_arvalid               : in  std_logic;
        s_rready                : in  std_logic;
        m_avl_readdata          : in  std_logic_vector(31 downto 0);
        m_avl_readdatavalid     : in  std_logic;
        m_avl_waitrequest       : in  std_logic;
        m_avl_response          : in  std_logic_vector(1 downto 0);
        s_awready               : out std_logic;
        s_wready                : out std_logic;
        s_bresp                 : out std_logic_vector(1 downto 0);
        s_bvalid                : out std_logic;
        s_arready               : out std_logic;
        s_rdata                 : out std_logic_vector(31 downto 0);
        s_rresp                 : out std_logic_vector(1 downto 0);
        s_rvalid                : out std_logic;
        m_avl_address           : out std_logic_vector(13 downto 0);
        m_avl_read              : out std_logic;
        m_avl_write             : out std_logic;
        m_avl_writedata         : out std_logic_vector(31 downto 0);
        m_avl_byteenable        : out std_logic_vector(3 downto 0)
    );
end entity axi_to_avalon_bridge;

architecture rtl of axi_to_avalon_bridge is

    -- Internal signals
    signal state : std_logic_vector(2 downto 0);
    signal addr_reg : std_logic_vector(15 downto 0);
    signal wdata_reg : std_logic_vector(31 downto 0);
    signal wstrb_reg : std_logic_vector(3 downto 0);
    signal rdata_reg : std_logic_vector(31 downto 0);
    signal resp_reg : std_logic_vector(1 downto 0);

begin

    proc_clk_1 : process(clk, rst_n)
    begin
        if rst_n = '0' then
            state <= (others => '0');
            addr_reg <= (others => '0');
            wdata_reg <= (others => '0');
            wstrb_reg <= (others => '0');
            rdata_reg <= (others => '0');
            resp_reg <= (others => '0');
            s_awready <= '0';
            s_wready <= '0';
            s_bvalid <= '0';
            s_bresp <= (others => '0');
            s_arready <= '0';
            s_rvalid <= '0';
            s_rdata <= (others => '0');
            s_rresp <= (others => '0');
            m_avl_write <= '0';
            m_avl_read <= '0';
            m_avl_address <= (others => '0');
            m_avl_writedata <= (others => '0');
            m_avl_byteenable <= (others => '0');
        elsif rising_edge(clk) then
            case state is
                when "0" =>
                    s_awready <= '0';
                    s_wready <= '0';
                    s_bvalid <= '0';
                    s_arready <= '0';
                    s_rvalid <= '0';
                    m_avl_write <= '0';
                    m_avl_read <= '0';
                    if s_awvalid & s_wvalid then
                        addr_reg <= s_awaddr;
                        wdata_reg <= s_wdata;
                        wstrb_reg <= s_wstrb;
                        state <= "001";
                    else
                        if s_arvalid then
                            addr_reg <= s_araddr;
                            state <= "100";
                        end if;
                    end if;
                when "1" =>
                    s_awready <= '1';
                    s_wready <= '1';
                    m_avl_write <= '1';
                    m_avl_address <= addr_reg[15:2];
                    m_avl_writedata <= wdata_reg;
                    m_avl_byteenable <= wstrb_reg;
                    state <= "010";
                when "10" =>
                    s_awready <= '0';
                    s_wready <= '0';
                    m_avl_write <= '1';
                    m_avl_address <= addr_reg[15:2];
                    m_avl_writedata <= wdata_reg;
                    m_avl_byteenable <= wstrb_reg;
                    if !m_avl_waitrequest then
                        resp_reg <= m_avl_response;
                        m_avl_write <= '0';
                        state <= "011";
                    end if;
                when "11" =>
                    s_bvalid <= '1';
                    s_bresp <= resp_reg;
                    m_avl_write <= '0';
                    if s_bready then
                        s_bvalid <= '0';
                        state <= (others => '0');
                    end if;
                when "100" =>
                    s_arready <= '1';
                    m_avl_read <= '1';
                    m_avl_address <= addr_reg[15:2];
                    state <= "101";
                when "101" =>
                    s_arready <= '0';
                    m_avl_read <= '1';
                    m_avl_address <= addr_reg[15:2];
                    if !m_avl_waitrequest then
                        m_avl_read <= '0';
                        state <= "110";
                    end if;
                when "110" =>
                    m_avl_read <= '0';
                    if m_avl_readdatavalid then
                        rdata_reg <= m_avl_readdata;
                        resp_reg <= m_avl_response;
                        state <= "111";
                    end if;
                when "111" =>
                    s_rvalid <= '1';
                    s_rdata <= rdata_reg;
                    s_rresp <= resp_reg;
                    if s_rready then
                        s_rvalid <= '0';
                        state <= (others => '0');
                    end if;
                when others =>
                    state <= (others => '0');
            end case;
        end if;
    end process proc_clk_1;

end architecture rtl;
