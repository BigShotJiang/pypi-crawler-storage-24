# RTL Bridge Generator — Validator

> Pre-emission sanity checker for the hardware AST.

The `Validator` class runs structural checks on a `Module` tree **before**
any Verilog or VHDL is emitted, catching problems in Python terms rather
than as cryptic synthesis failures.

---

## Integration into the Generation Flow

```
build_module()
    │
    ▼
Validator(module)
    ├── check_widths()          ← raises ValidationError on mismatch
    ├── check_handshakes([axi]) ← raises ValidationError on floating handshake
    ├── check_address_bounds()  ← raises ValidationError on overflow
    └── inject_sva(axi)         ← returns List[SvaProperty]
    │
    ▼
Emitter(module, sva_properties=props)
    └── emit_systemverilog() / emit_vhdl()
```

Or use the convenience wrapper:

```python
from validator import Validator

v = Validator(module)
sva_props = v.run_all(
    axi_interfaces=[axi],
    addr_map=addr_map,
    native=nat,
)
# sva_props → List[SvaProperty], pass to emitter
```

---

## Check 1 — Width Check

Traverses every `Assign` and `NonBlockingAssign` node in the tree.
Raises `ValidationError` if the LHS and RHS have **different, statically
known widths**.

Assignments where one side is a raw string expression or integer literal
are skipped (width is context-dependent and resolved by the emitter).

```python
v.check_widths()
# ValidationError: [width]
#   • assign: 'dst' is 8 bits wide but source is 16 bits wide
```

| LHS | RHS | Result |
|-----|-----|--------|
| `Signal(width=8)` | `Signal(width=8)` | ✅ Pass |
| `Signal(width=8)` | `Signal(width=16)` | ❌ Fail |
| `Slice[7:4]` (4 bits) | `Signal(width=8)` | ❌ Fail |
| `Signal(width=8)` | `"some_expr"` | ✅ Skip (unknown width) |
| `Signal(width=8)` | `0` | ✅ Skip (literal) |

---

## Check 2 — Handshake Check

For each `AXILiteInterface`, verifies that all ten handshake signals
(`awvalid`, `awready`, `wvalid`, `wready`, `bvalid`, `bready`,
`arvalid`, `arready`, `rvalid`, `rready`) appear at least once in an
assignment target or condition within the module body.

A signal that is declared as a port but never driven or read is a
**floating handshake** — a common cause of AXI protocol deadlocks.

```python
v.check_handshakes([axi_slave])
# ValidationError: [handshake]
#   • AXILiteInterface(prefix='s_axi'): handshake signal 's_axi_bvalid'
#     is never used in any logic block
```

Both continuous `Assign` and procedural `NonBlockingAssign` (inside
`Always`) count as "used".  String expressions are scanned for signal
name tokens via regex.

---

## Check 3 — Address Bounds Check

Verifies that the AXI/Avalon address range described by an `AddressMap`
does not exceed the physical capacity of the `NativeMemInterface`.

Two sub-checks:

| Sub-check | Condition | Error |
|-----------|-----------|-------|
| Data width | `addr_map.data_width == native.data_width` | `data_width mismatch` |
| Word depth | `addr_map.num_words <= 2 ** native.addr_width` | `address overflow` |

```python
v.check_address_bounds(addr_map, native_iface)
# ValidationError: [address_bounds]
#   • address overflow: AddressMap maps 1025 words but
#     NativeMemInterface only has 1024 words (addr_width=10)
```

---

## Check 4 — SVA Injector

Generates **SystemVerilog Assertion** properties for AXI4-Lite protocol
compliance.  Returns a `List[SvaProperty]` — one per AXI channel.

The generated assertion checks the AXI4 rule:

> *Once VALID is asserted it must remain asserted until the handshake
> completes (READY is also asserted in the same cycle).*

```python
sva_props = v.inject_sva(
    axi,
    clk_name="clk",
    rst_name="rst_n",
    active_low_reset=True,
)
```

Generated SVA (example for AW channel):

```systemverilog
// AXI4-Lite: AWVALID must stay high until AWREADY
property s_axi_aw_valid_stable;
  @(posedge clk) disable iff (!rst_n)
    (s_axi_awvalid && !s_axi_awready) |=> s_axi_awvalid;
endproperty
assert property s_axi_aw_valid_stable;
```

Five properties are generated (one per channel: AW, W, B, AR, R).

### `SvaProperty` fields

| Field | Type | Description |
|-------|------|-------------|
| `name` | `str` | Property identifier / assertion label |
| `body` | `str` | Raw SVA between `property … endproperty` |
| `severity` | `str` | `"assert"` (default) or `"assume"` |
| `comment` | `str` | Optional comment emitted above the property |

Call `prop.render(indent=4)` to get the full formatted string.

---

## `ValidationError`

All checks raise `ValidationError` (a subclass of `ValueError`) on
failure.  All problems within a single check are collected before raising,
so the caller sees the **full list** at once.

```python
try:
    v.check_widths()
except ValidationError as e:
    print(e.check)    # "width"
    print(e.details)  # ["assign: 'dst' is 8 bits but source is 16 bits"]
```

---

## API Reference

```python
class Validator:
    def __init__(self, module: Module) -> None: ...

    def check_widths(self) -> None: ...
    def check_handshakes(self, interfaces: List[AXILiteInterface]) -> None: ...
    def check_address_bounds(
        self, addr_map: AddressMap, native: NativeMemInterface
    ) -> None: ...
    def inject_sva(
        self,
        axi: AXILiteInterface,
        clk_name: str = "clk",
        rst_name: str = "rst_n",
        active_low_reset: bool = True,
    ) -> List[SvaProperty]: ...
    def run_all(
        self,
        axi_interfaces: Optional[List[AXILiteInterface]] = None,
        addr_map: Optional[AddressMap] = None,
        native: Optional[NativeMemInterface] = None,
    ) -> List[SvaProperty]: ...
```
