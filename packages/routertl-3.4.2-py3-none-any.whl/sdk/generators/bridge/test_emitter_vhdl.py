# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_emitter_vhdl.py — Unit tests for emitter_vhdl.py
======================================================

Run with:
    python -m pytest sdk/generators/bridge/test_emitter_vhdl.py -v
"""

import tempfile
from datetime import datetime, timezone
from pathlib import Path

from bus_interfaces import AXILiteInterface, InterfaceRole
from emitter_vhdl import VHDLEmitter
from hdl_ast import (
    Always,
    Assign,
    Case,
    Concat,
    Direction,
    Edge,
    If,
    Module,
    NonBlockingAssign,
    Signal,
    Ternary,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FIXED_TS = datetime(2026, 2, 18, 23, 0, 0, tzinfo=timezone.utc)


def _emitter(**kwargs) -> VHDLEmitter:
    return VHDLEmitter(generated_at=FIXED_TS, **kwargs)


def _emit(module: Module, **kwargs) -> str:
    return _emitter(**kwargs).emit(module)


# ===========================================================================
# Header
# ===========================================================================


class TestHeader:
    def test_header_uses_vhdl_comment_prefix(self) -> None:
        sv = _emit(Module("dut"))
        header_lines = [l for l in sv.splitlines() if "DO NOT EDIT" in l]
        assert header_lines[0].startswith("--")

    def test_header_contains_vhdl_language(self) -> None:
        sv = _emit(Module("dut"))
        assert "VHDL" in sv

    def test_header_contains_timestamp(self) -> None:
        sv = _emit(Module("dut"))
        assert "2026-02-18" in sv

    def test_header_contains_parameter(self) -> None:
        sv = _emit(Module("dut"), parameters={"Base Address": 0x4000_0000})
        assert "Base Address" in sv
        assert "0x40000000" in sv


# ===========================================================================
# Library / use clauses
# ===========================================================================


class TestLibraryClauses:
    def test_ieee_library(self) -> None:
        sv = _emit(Module("dut"))
        assert "library ieee;" in sv

    def test_std_logic_1164(self) -> None:
        sv = _emit(Module("dut"))
        assert "use ieee.std_logic_1164.all;" in sv

    def test_numeric_std(self) -> None:
        sv = _emit(Module("dut"))
        assert "use ieee.numeric_std.all;" in sv


# ===========================================================================
# Entity structure
# ===========================================================================


class TestEntityStructure:
    def test_entity_keyword(self) -> None:
        sv = _emit(Module("my_bridge"))
        assert "entity my_bridge is" in sv

    def test_end_entity_keyword(self) -> None:
        sv = _emit(Module("my_bridge"))
        assert "end entity my_bridge;" in sv

    def test_port_section(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        m = Module("dut", ports=[clk])
        sv = _emit(m)
        assert "port (" in sv

    def test_last_port_no_semicolon(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        m = Module("dut", ports=[clk])
        sv = _emit(m)
        port_lines = [l for l in sv.splitlines() if "std_logic" in l and "clk" in l]
        assert port_lines, "No port line found"
        assert not port_lines[-1].rstrip().endswith(";")

    def test_non_last_port_has_semicolon(self) -> None:
        a = Signal("a", direction=Direction.INPUT)
        b = Signal("b", direction=Direction.INPUT)
        m = Module("dut", ports=[a, b])
        sv = _emit(m)
        a_lines = [l for l in sv.splitlines() if " a " in l or l.strip().startswith("a ")]
        # The first port (a) should end with ;
        assert any(l.rstrip().endswith(";") for l in a_lines)


# ===========================================================================
# Architecture structure
# ===========================================================================


class TestArchitectureStructure:
    def test_architecture_keyword(self) -> None:
        sv = _emit(Module("dut"))
        assert "architecture rtl of dut is" in sv

    def test_end_architecture_keyword(self) -> None:
        sv = _emit(Module("dut"))
        assert "end architecture rtl;" in sv

    def test_begin_keyword(self) -> None:
        sv = _emit(Module("dut"))
        assert "begin" in sv


# ===========================================================================
# Port declarations
# ===========================================================================


class TestPortDeclarations:
    def test_single_bit_input_std_logic(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        m = Module("dut", ports=[clk])
        sv = _emit(m)
        assert "in  std_logic" in sv

    def test_single_bit_output_std_logic(self) -> None:
        out = Signal("valid", direction=Direction.OUTPUT)
        m = Module("dut", ports=[out])
        sv = _emit(m)
        assert "out std_logic" in sv

    def test_wide_input_std_logic_vector(self) -> None:
        addr = Signal("addr", width=32, direction=Direction.INPUT)
        m = Module("dut", ports=[addr])
        sv = _emit(m)
        assert "std_logic_vector(31 downto 0)" in sv

    def test_wide_output_std_logic_vector(self) -> None:
        data = Signal("data", width=64, direction=Direction.OUTPUT)
        m = Module("dut", ports=[data])
        sv = _emit(m)
        assert "std_logic_vector(63 downto 0)" in sv


# ===========================================================================
# Internal signal declarations
# ===========================================================================


class TestSignalDeclarations:
    def test_signal_keyword(self) -> None:
        state = Signal("state", width=2, direction=Direction.LOCAL)
        m = Module("dut", signals=[state])
        sv = _emit(m)
        assert "signal state" in sv

    def test_signal_type_vector(self) -> None:
        state = Signal("state", width=2, direction=Direction.LOCAL)
        m = Module("dut", signals=[state])
        sv = _emit(m)
        assert "std_logic_vector(1 downto 0)" in sv

    def test_signal_type_std_logic(self) -> None:
        flag = Signal("flag", width=1, direction=Direction.LOCAL)
        m = Module("dut", signals=[flag])
        sv = _emit(m)
        assert "signal flag : std_logic;" in sv


# ===========================================================================
# Assign → concurrent signal assignment
# ===========================================================================


class TestAssignNodes:
    def test_assign_arrow(self) -> None:
        src = Signal("src", direction=Direction.INPUT)
        dst = Signal("dst", direction=Direction.OUTPUT)
        m = Module("dut", ports=[src, dst], body=[Assign(dst, src)])
        sv = _emit(m)
        assert "dst <= src;" in sv

    def test_assign_integer_zero_single_bit(self) -> None:
        dst = Signal("dst", width=1, direction=Direction.OUTPUT)
        m = Module("dut", ports=[dst], body=[Assign(dst, 0)])
        sv = _emit(m)
        assert "dst <= '0';" in sv

    def test_assign_integer_zero_multi_bit(self) -> None:
        dst = Signal("dst", width=8, direction=Direction.OUTPUT)
        m = Module("dut", ports=[dst], body=[Assign(dst, 0)])
        sv = _emit(m)
        assert "dst <= (others => '0');" in sv

    def test_assign_string_source(self) -> None:
        dst = Signal("dst", width=32, direction=Direction.OUTPUT)
        m = Module("dut", ports=[dst], body=[Assign(dst, "(awaddr - 0x1000) >> 2")])
        sv = _emit(m)
        assert "dst <= (awaddr - 0x1000) >> 2;" in sv


# ===========================================================================
# Clocked process (always_ff equivalent)
# ===========================================================================


class TestClockedProcess:
    def _clk(self) -> Signal:
        return Signal("clk", direction=Direction.INPUT)

    def _rst_n(self) -> Signal:
        return Signal("rst_n", direction=Direction.INPUT)

    def test_process_keyword(self) -> None:
        clk = self._clk()
        dst = Signal("q", direction=Direction.OUTPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[NonBlockingAssign(dst, 0)])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        assert "process(" in sv
        assert "end process" in sv

    def test_rising_edge_clk(self) -> None:
        clk = self._clk()
        dst = Signal("q", direction=Direction.OUTPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[NonBlockingAssign(dst, 0)])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        assert "rising_edge(clk)" in sv

    def test_async_reset_active_low(self) -> None:
        clk = self._clk()
        rst_n = self._rst_n()
        dst = Signal("q", direction=Direction.OUTPUT)
        if_node = If(
            condition="!rst_n",
            then_body=[NonBlockingAssign(dst, 0)],
            else_body=[NonBlockingAssign(dst, 1)],
        )
        blk = Always(
            [(Edge.POSEDGE, clk), (Edge.NEGEDGE, rst_n)],
            body=[if_node],
        )
        m = Module("dut", ports=[clk, rst_n, dst], body=[blk])
        sv = _emit(m)
        assert "rst_n = '0'" in sv
        assert "rising_edge(clk)" in sv

    def test_async_reset_sensitivity_list(self) -> None:
        clk = self._clk()
        rst_n = self._rst_n()
        dst = Signal("q", direction=Direction.OUTPUT)
        if_node = If(
            condition="!rst_n",
            then_body=[NonBlockingAssign(dst, 0)],
            else_body=[NonBlockingAssign(dst, 1)],
        )
        blk = Always(
            [(Edge.POSEDGE, clk), (Edge.NEGEDGE, rst_n)],
            body=[if_node],
        )
        m = Module("dut", ports=[clk, rst_n, dst], body=[blk])
        sv = _emit(m)
        assert "process(clk, rst_n)" in sv

    def test_nonblocking_assign_arrow(self) -> None:
        clk = self._clk()
        src = Signal("d", direction=Direction.INPUT)
        dst = Signal("q", direction=Direction.OUTPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[NonBlockingAssign(dst, src)])
        m = Module("dut", ports=[clk, src, dst], body=[blk])
        sv = _emit(m)
        assert "q <= d;" in sv

    def test_reset_val_zero_single_bit(self) -> None:
        clk = self._clk()
        rst_n = self._rst_n()
        dst = Signal("q", width=1, direction=Direction.OUTPUT)
        if_node = If(
            condition="!rst_n",
            then_body=[NonBlockingAssign(dst, 0)],
            else_body=[NonBlockingAssign(dst, 1)],
        )
        blk = Always(
            [(Edge.POSEDGE, clk), (Edge.NEGEDGE, rst_n)],
            body=[if_node],
        )
        m = Module("dut", ports=[clk, rst_n, dst], body=[blk])
        sv = _emit(m)
        assert "q <= '0';" in sv

    def test_reset_val_zero_multi_bit(self) -> None:
        clk = self._clk()
        rst_n = self._rst_n()
        dst = Signal("state", width=4, direction=Direction.OUTPUT)
        if_node = If(
            condition="!rst_n",
            then_body=[NonBlockingAssign(dst, 0)],
            else_body=[NonBlockingAssign(dst, 1)],
        )
        blk = Always(
            [(Edge.POSEDGE, clk), (Edge.NEGEDGE, rst_n)],
            body=[if_node],
        )
        m = Module("dut", ports=[clk, rst_n, dst], body=[blk])
        sv = _emit(m)
        assert "(others => '0')" in sv


# ===========================================================================
# Combinational process
# ===========================================================================


class TestCombProcess:
    def test_process_all(self) -> None:
        src = Signal("src", direction=Direction.INPUT)
        dst = Signal("dst", direction=Direction.OUTPUT)
        blk = Always([(Edge.LEVEL, None)], body=[NonBlockingAssign(dst, src)])
        m = Module("dut", ports=[src, dst], body=[blk])
        sv = _emit(m)
        assert "process(all)" in sv


# ===========================================================================
# If / else
# ===========================================================================


class TestIfElse:
    def test_if_then_keyword(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        dst = Signal("q", direction=Direction.OUTPUT)
        if_node = If(condition="flag", then_body=[NonBlockingAssign(dst, 1)])
        blk = Always([(Edge.POSEDGE, clk)], body=[if_node])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        assert "if flag then" in sv
        assert "end if;" in sv

    def test_else_keyword(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        dst = Signal("q", direction=Direction.OUTPUT)
        if_node = If(
            condition="flag",
            then_body=[NonBlockingAssign(dst, 1)],
            else_body=[NonBlockingAssign(dst, 0)],
        )
        blk = Always([(Edge.POSEDGE, clk)], body=[if_node])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        assert "else" in sv

    def test_no_begin_end_in_if(self) -> None:
        """VHDL if/else does NOT use begin/end."""
        clk = Signal("clk", direction=Direction.INPUT)
        dst = Signal("q", direction=Direction.OUTPUT)
        if_node = If(
            condition="flag",
            then_body=[NonBlockingAssign(dst, 1)],
            else_body=[NonBlockingAssign(dst, 0)],
        )
        blk = Always([(Edge.POSEDGE, clk)], body=[if_node])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        # VHDL if should not have 'begin' inside the if block
        if_idx = sv.index("if flag then")
        endif_idx = sv.index("end if;")
        between = sv[if_idx:endif_idx]
        # 'begin' should NOT appear between 'if' and 'end if'
        assert "begin" not in between


# ===========================================================================
# Case statements
# ===========================================================================


class TestCaseStatements:
    def test_case_is_keyword(self) -> None:
        sel = Signal("state", width=2, direction=Direction.LOCAL)
        dst = Signal("out", direction=Direction.OUTPUT)
        case_node = Case(
            selector=sel,
            branches=[
                (0, [NonBlockingAssign(dst, 0)]),
                (None, [NonBlockingAssign(dst, 0)]),
            ],
        )
        clk = Signal("clk", direction=Direction.INPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[case_node])
        m = Module("dut", ports=[clk, dst], signals=[sel], body=[blk])
        sv = _emit(m)
        assert "case state is" in sv
        assert "end case;" in sv

    def test_when_others(self) -> None:
        sel = Signal("s", width=2, direction=Direction.LOCAL)
        dst = Signal("out", direction=Direction.OUTPUT)
        case_node = Case(
            selector=sel,
            branches=[(None, [NonBlockingAssign(dst, 0)])],
        )
        clk = Signal("clk", direction=Direction.INPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[case_node])
        m = Module("dut", ports=[clk, dst], signals=[sel], body=[blk])
        sv = _emit(m)
        assert "when others =>" in sv


# ===========================================================================
# Expression rendering
# ===========================================================================


class TestExpressionRendering:
    def test_concat_uses_ampersand(self) -> None:
        a = Signal("a", width=4, direction=Direction.INPUT)
        b = Signal("b", width=4, direction=Direction.INPUT)
        dst = Signal("out", width=8, direction=Direction.OUTPUT)
        m = Module("dut", ports=[a, b, dst], body=[Assign(dst, Concat([a, b]))])
        sv = _emit(m)
        assert "a & b" in sv
        assert "{" not in sv  # no SV-style concat

    def test_ternary_uses_when_else(self) -> None:
        sel = Signal("sel", direction=Direction.INPUT)
        a = Signal("a", direction=Direction.INPUT)
        b = Signal("b", direction=Direction.INPUT)
        dst = Signal("out", direction=Direction.OUTPUT)
        m = Module("dut", ports=[sel, a, b, dst], body=[Assign(dst, Ternary(sel, a, b))])
        sv = _emit(m)
        assert "a when sel = '1' else b" in sv
        assert "?" not in sv  # no SV-style ternary

    def test_slice_range(self) -> None:
        sig = Signal("bus", width=8, direction=Direction.INPUT)
        dst = Signal("nibble", width=4, direction=Direction.OUTPUT)
        m = Module("dut", ports=[sig, dst], body=[Assign(dst, sig[7:4])])
        sv = _emit(m)
        assert "bus(7 downto 4)" in sv


# ===========================================================================
# save() API
# ===========================================================================


class TestSaveAPI:
    def test_save_creates_file(self) -> None:
        m = Module("dut")
        e = _emitter()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "dut.vhd"
            returned = e.save(m, path)
            assert returned == path
            assert path.exists()

    def test_save_content_matches_emit(self) -> None:
        m = Module("dut")
        e = _emitter()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "dut.vhd"
            e.save(m, path)
            assert path.read_text() == e.emit(m)


# ===========================================================================
# Integration: AXI-Lite interface
# ===========================================================================


class TestAXILiteIntegration:
    def test_axilite_module_emits(self) -> None:
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s_axi")
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)

        m = Module("axilite_bridge")
        m.add_port(clk)
        m.add_port(rst_n)
        for sig in axi.get_signals():
            m.add_port(sig)

        vhd = _emitter(parameters={"Base Address": 0x4000_0000}).emit(m)

        assert "entity axilite_bridge is" in vhd
        assert "end entity axilite_bridge;" in vhd
        assert "architecture rtl of axilite_bridge is" in vhd
        assert "end architecture rtl;" in vhd
        assert "s_axi_awvalid" in vhd
        assert "s_axi_rdata" in vhd
        assert "0x40000000" in vhd

    def test_axilite_all_ports_present(self) -> None:
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s")
        m = Module("dut")
        for sig in axi.get_signals():
            m.add_port(sig)

        vhd = _emit(m)
        for sig in axi.get_signals():
            assert sig.name in vhd

    def test_full_bridge_with_clocked_process(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)
        valid_in = Signal("valid_in", direction=Direction.INPUT)
        valid_out = Signal("valid_out", direction=Direction.OUTPUT)
        state = Signal("state", width=2, direction=Direction.LOCAL)

        if_node = If(
            condition="!rst_n",
            then_body=[NonBlockingAssign(state, 0)],
            else_body=[NonBlockingAssign(state, valid_in)],
        )
        blk = Always(
            [(Edge.POSEDGE, clk), (Edge.NEGEDGE, rst_n)],
            body=[if_node],
        )

        m = Module(
            "dut", ports=[clk, rst_n, valid_in, valid_out], signals=[state], body=[Assign(valid_out, state), blk]
        )

        vhd = _emit(m)
        assert "valid_out <= state;" in vhd
        assert "process(clk, rst_n)" in vhd
        assert "rst_n = '0'" in vhd
        assert "rising_edge(clk)" in vhd
        assert "(others => '0')" in vhd
