# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_emitter_sv.py — Unit tests for emitter_sv.py
==================================================

Run with:
    python -m pytest sdk/generators/bridge/test_emitter_sv.py -v
"""

import tempfile
from datetime import datetime, timezone
from pathlib import Path

from bus_interfaces import AXILiteInterface, InterfaceRole
from emitter_sv import SystemVerilogEmitter
from hdl_ast import (
    Always,
    Assign,
    Case,
    Concat,
    Direction,
    Edge,
    If,
    Module,
    NonBlockingAssign,
    Signal,
    Ternary,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FIXED_TS = datetime(2026, 2, 18, 23, 0, 0, tzinfo=timezone.utc)


def _emitter(**kwargs) -> SystemVerilogEmitter:
    return SystemVerilogEmitter(generated_at=FIXED_TS, **kwargs)


def _emit(module: Module, **kwargs) -> str:
    return _emitter(**kwargs).emit(module)


def _lines(sv: str) -> list:
    return [l.rstrip() for l in sv.splitlines()]


def _stripped_lines(sv: str) -> list:
    return [l.strip() for l in sv.splitlines() if l.strip()]


# ===========================================================================
# BaseEmitter
# ===========================================================================


class TestBaseEmitter:
    def test_language_attribute(self) -> None:
        e = _emitter()
        assert e.LANGUAGE == "SystemVerilog"

    def test_emit_returns_string(self) -> None:
        m = Module("dut")
        result = _emitter().emit(m)
        assert isinstance(result, str)

    def test_emit_ends_with_newline(self) -> None:
        m = Module("dut")
        result = _emitter().emit(m)
        assert result.endswith("\n")

    def test_emit_resets_buffer(self) -> None:
        m = Module("dut")
        e = _emitter()
        first = e.emit(m)
        second = e.emit(m)
        assert first == second

    def test_save_creates_file(self) -> None:
        m = Module("dut")
        e = _emitter()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "dut.sv"
            returned = e.save(m, path)
            assert returned == path
            assert path.exists()

    def test_save_creates_parent_dirs(self) -> None:
        m = Module("dut")
        e = _emitter()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sub" / "dir" / "dut.sv"
            e.save(m, path)
            assert path.exists()

    def test_save_content_matches_emit(self) -> None:
        m = Module("dut")
        e = _emitter()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "dut.sv"
            e.save(m, path)
            assert path.read_text() == e.emit(m)


# ===========================================================================
# Header
# ===========================================================================


class TestHeader:
    def test_header_contains_do_not_edit(self) -> None:
        sv = _emit(Module("dut"))
        assert "DO NOT EDIT" in sv

    def test_header_contains_systemverilog(self) -> None:
        sv = _emit(Module("dut"))
        assert "SystemVerilog" in sv

    def test_header_contains_timestamp(self) -> None:
        sv = _emit(Module("dut"))
        assert "2026-02-18" in sv

    def test_header_contains_parameter_key(self) -> None:
        sv = _emit(Module("dut"), parameters={"Base Address": 0x4000_0000})
        assert "Base Address" in sv

    def test_header_contains_parameter_hex_value(self) -> None:
        sv = _emit(Module("dut"), parameters={"Base Address": 0x4000_0000})
        assert "0x40000000" in sv

    def test_header_contains_small_int_as_decimal(self) -> None:
        sv = _emit(Module("dut"), parameters={"Data Width": 32})
        assert "32" in sv

    def test_header_uses_comment_prefix(self) -> None:
        sv = _emit(Module("dut"))
        header_lines = [l for l in sv.splitlines() if "DO NOT EDIT" in l]
        assert header_lines[0].startswith("//")


# ===========================================================================
# Module structure
# ===========================================================================


class TestModuleStructure:
    def test_module_keyword(self) -> None:
        sv = _emit(Module("my_bridge"))
        assert "module my_bridge" in sv

    def test_endmodule_keyword(self) -> None:
        sv = _emit(Module("my_bridge"))
        assert "endmodule" in sv

    def test_empty_module_parens(self) -> None:
        sv = _emit(Module("dut"))
        assert "module dut ()" in sv

    def test_module_with_ports_has_parens(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        m = Module("dut", ports=[clk])
        sv = _emit(m)
        assert "module dut (" in sv

    def test_last_port_no_trailing_comma(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        m = Module("dut", ports=[clk])
        sv = _emit(m)
        # The last port line must not end with a comma
        port_lines = [l for l in sv.splitlines() if "clk" in l and "input" in l]
        assert port_lines, "No port line found"
        assert not port_lines[-1].rstrip().endswith(",")

    def test_inputs_before_outputs(self) -> None:
        inp = Signal("a", direction=Direction.INPUT)
        out = Signal("b", direction=Direction.OUTPUT)
        m = Module("dut", ports=[inp, out])
        sv = _emit(m)
        assert sv.index("input") < sv.index("output")

    def test_inputs_comment_present(self) -> None:
        inp = Signal("a", direction=Direction.INPUT)
        m = Module("dut", ports=[inp])
        sv = _emit(m)
        assert "// Inputs" in sv

    def test_outputs_comment_present(self) -> None:
        inp = Signal("a", direction=Direction.INPUT)
        out = Signal("b", direction=Direction.OUTPUT)
        m = Module("dut", ports=[inp, out])
        sv = _emit(m)
        assert "// Outputs" in sv


# ===========================================================================
# Port declarations
# ===========================================================================


class TestPortDeclarations:
    def test_single_bit_input(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        m = Module("dut", ports=[clk])
        sv = _emit(m)
        assert "input  logic" in sv
        assert "clk" in sv

    def test_single_bit_output(self) -> None:
        out = Signal("valid", direction=Direction.OUTPUT)
        m = Module("dut", ports=[out])
        sv = _emit(m)
        assert "output logic" in sv

    def test_wide_input_has_range(self) -> None:
        addr = Signal("addr", width=32, direction=Direction.INPUT)
        m = Module("dut", ports=[addr])
        sv = _emit(m)
        assert "[31:0]" in sv

    def test_wide_output_has_range(self) -> None:
        data = Signal("data", width=64, direction=Direction.OUTPUT)
        m = Module("dut", ports=[data])
        sv = _emit(m)
        assert "[63:0]" in sv

    def test_multiple_ports_comma_separated(self) -> None:
        a = Signal("a", direction=Direction.INPUT)
        b = Signal("b", direction=Direction.INPUT)
        c = Signal("c", direction=Direction.OUTPUT)
        m = Module("dut", ports=[a, b, c])
        sv = _emit(m)
        # a and b should have commas, c should not
        lines = sv.splitlines()
        a_line = next(l for l in lines if "input" in l and " a" in l)
        c_line = next(l for l in lines if "output" in l and " c" in l)
        assert a_line.rstrip().endswith(",")
        assert not c_line.rstrip().endswith(",")


# ===========================================================================
# Internal signal declarations
# ===========================================================================


class TestSignalDeclarations:
    def test_internal_signal_declared(self) -> None:
        state = Signal("state", width=2, direction=Direction.LOCAL)
        m = Module("dut", signals=[state])
        sv = _emit(m)
        assert "logic [1:0] state" in sv

    def test_internal_signals_section_comment(self) -> None:
        state = Signal("state", direction=Direction.LOCAL)
        m = Module("dut", signals=[state])
        sv = _emit(m)
        assert "// Internal signals" in sv

    def test_single_bit_signal_no_range(self) -> None:
        flag = Signal("flag", width=1, direction=Direction.LOCAL)
        m = Module("dut", signals=[flag])
        sv = _emit(m)
        # Should be "logic flag" not "logic [0:0] flag"
        assert "logic flag" in sv
        assert "[0:0]" not in sv


# ===========================================================================
# Assign nodes
# ===========================================================================


class TestAssignNodes:
    def test_assign_keyword(self) -> None:
        src = Signal("src", direction=Direction.INPUT)
        dst = Signal("dst", direction=Direction.OUTPUT)
        m = Module("dut", ports=[src, dst], body=[Assign(dst, src)])
        sv = _emit(m)
        assert "assign dst = src;" in sv

    def test_assign_section_comment(self) -> None:
        src = Signal("src", direction=Direction.INPUT)
        dst = Signal("dst", direction=Direction.OUTPUT)
        m = Module("dut", ports=[src, dst], body=[Assign(dst, src)])
        sv = _emit(m)
        assert "// Continuous assignments" in sv

    def test_assign_integer_source(self) -> None:
        dst = Signal("dst", direction=Direction.OUTPUT)
        m = Module("dut", ports=[dst], body=[Assign(dst, 0)])
        sv = _emit(m)
        assert "assign dst = 0;" in sv

    def test_assign_slice_target(self) -> None:
        src = Signal("src", width=4, direction=Direction.INPUT)
        dst = Signal("dst", width=8, direction=Direction.OUTPUT)
        m = Module("dut", ports=[src, dst], body=[Assign(dst[7:4], src)])
        sv = _emit(m)
        assert "assign dst[7:4] = src;" in sv

    def test_assign_string_source(self) -> None:
        dst = Signal("dst", width=32, direction=Direction.OUTPUT)
        m = Module("dut", ports=[dst], body=[Assign(dst, "(awaddr - 0x1000) >> 2")])
        sv = _emit(m)
        assert "assign dst = (awaddr - 0x1000) >> 2;" in sv


# ===========================================================================
# Always blocks
# ===========================================================================


class TestAlwaysBlocks:
    def _clk(self) -> Signal:
        return Signal("clk", direction=Direction.INPUT)

    def _rst_n(self) -> Signal:
        return Signal("rst_n", direction=Direction.INPUT)

    def test_always_ff_keyword(self) -> None:
        clk = self._clk()
        dst = Signal("q", direction=Direction.OUTPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[NonBlockingAssign(dst, 0)])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        assert "always_ff" in sv

    def test_always_comb_keyword(self) -> None:
        src = Signal("src", direction=Direction.INPUT)
        dst = Signal("dst", direction=Direction.OUTPUT)
        blk = Always([(Edge.LEVEL, None)], body=[NonBlockingAssign(dst, src)])
        m = Module("dut", ports=[src, dst], body=[blk])
        sv = _emit(m)
        assert "always_comb" in sv

    def test_posedge_clk_in_sensitivity(self) -> None:
        clk = self._clk()
        dst = Signal("q", direction=Direction.OUTPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[NonBlockingAssign(dst, 0)])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        assert "posedge clk" in sv

    def test_async_reset_in_sensitivity(self) -> None:
        clk = self._clk()
        rst_n = self._rst_n()
        dst = Signal("q", direction=Direction.OUTPUT)
        blk = Always(
            [(Edge.POSEDGE, clk), (Edge.NEGEDGE, rst_n)],
            body=[NonBlockingAssign(dst, 0)],
        )
        m = Module("dut", ports=[clk, rst_n, dst], body=[blk])
        sv = _emit(m)
        assert "posedge clk or negedge rst_n" in sv

    def test_always_has_begin_end(self) -> None:
        clk = self._clk()
        dst = Signal("q", direction=Direction.OUTPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[NonBlockingAssign(dst, 0)])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        assert "begin" in sv
        assert "end" in sv

    def test_nonblocking_assign_arrow(self) -> None:
        clk = self._clk()
        src = Signal("d", direction=Direction.INPUT)
        dst = Signal("q", direction=Direction.OUTPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[NonBlockingAssign(dst, src)])
        m = Module("dut", ports=[clk, src, dst], body=[blk])
        sv = _emit(m)
        assert "q <= d;" in sv


# ===========================================================================
# If / else
# ===========================================================================


class TestIfElse:
    def test_if_begin_end(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)
        dst = Signal("q", direction=Direction.OUTPUT)
        if_node = If(
            condition="!rst_n",
            then_body=[NonBlockingAssign(dst, 0)],
            else_body=[NonBlockingAssign(dst, 1)],
        )
        blk = Always([(Edge.POSEDGE, clk)], body=[if_node])
        m = Module("dut", ports=[clk, rst_n, dst], body=[blk])
        sv = _emit(m)
        assert "if (!rst_n) begin" in sv
        assert "end else begin" in sv

    def test_if_without_else(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        dst = Signal("q", direction=Direction.OUTPUT)
        if_node = If(condition="flag", then_body=[NonBlockingAssign(dst, 1)])
        blk = Always([(Edge.POSEDGE, clk)], body=[if_node])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        assert "if (flag) begin" in sv
        assert "else" not in sv

    def test_no_dangling_else(self) -> None:
        """Every if/else branch must be wrapped in begin/end."""
        clk = Signal("clk", direction=Direction.INPUT)
        dst = Signal("q", direction=Direction.OUTPUT)
        if_node = If(
            condition="a",
            then_body=[NonBlockingAssign(dst, 0)],
            else_body=[NonBlockingAssign(dst, 1)],
        )
        blk = Always([(Edge.POSEDGE, clk)], body=[if_node])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        # Every 'if' must be followed by 'begin' on the same line
        for line in sv.splitlines():
            stripped = line.strip()
            if stripped.startswith("if ") or stripped.startswith("end else"):
                assert "begin" in stripped, f"Missing 'begin' on line: {line!r}"


# ===========================================================================
# Case statements
# ===========================================================================


class TestCaseStatements:
    def test_case_keyword(self) -> None:
        sel = Signal("state", width=2, direction=Direction.LOCAL)
        dst = Signal("out", direction=Direction.OUTPUT)
        case_node = Case(
            selector=sel,
            branches=[
                (0, [NonBlockingAssign(dst, 0)]),
                (1, [NonBlockingAssign(dst, 1)]),
                (None, [NonBlockingAssign(dst, 0)]),  # default
            ],
        )
        clk = Signal("clk", direction=Direction.INPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[case_node])
        m = Module("dut", ports=[clk, dst], signals=[sel], body=[blk])
        sv = _emit(m)
        assert "case (state)" in sv
        assert "endcase" in sv

    def test_default_branch(self) -> None:
        sel = Signal("s", width=2, direction=Direction.LOCAL)
        dst = Signal("out", direction=Direction.OUTPUT)
        case_node = Case(
            selector=sel,
            branches=[(None, [NonBlockingAssign(dst, 0)])],
        )
        clk = Signal("clk", direction=Direction.INPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[case_node])
        m = Module("dut", ports=[clk, dst], signals=[sel], body=[blk])
        sv = _emit(m)
        assert "default: begin" in sv

    def test_case_branches_have_begin_end(self) -> None:
        sel = Signal("s", width=2, direction=Direction.LOCAL)
        dst = Signal("out", direction=Direction.OUTPUT)
        case_node = Case(
            selector=sel,
            branches=[(0, [NonBlockingAssign(dst, 1)])],
        )
        clk = Signal("clk", direction=Direction.INPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[case_node])
        m = Module("dut", ports=[clk, dst], signals=[sel], body=[blk])
        sv = _emit(m)
        assert "0: begin" in sv


# ===========================================================================
# Expression rendering
# ===========================================================================


class TestExpressionRendering:
    def test_slice_single_bit(self) -> None:
        sig = Signal("bus", width=8, direction=Direction.INPUT)
        dst = Signal("bit0", direction=Direction.OUTPUT)
        m = Module("dut", ports=[sig, dst], body=[Assign(dst, sig[0])])
        sv = _emit(m)
        assert "bus[0]" in sv

    def test_slice_range(self) -> None:
        sig = Signal("bus", width=8, direction=Direction.INPUT)
        dst = Signal("nibble", width=4, direction=Direction.OUTPUT)
        m = Module("dut", ports=[sig, dst], body=[Assign(dst, sig[7:4])])
        sv = _emit(m)
        assert "bus[7:4]" in sv

    def test_concat_expression(self) -> None:
        a = Signal("a", width=4, direction=Direction.INPUT)
        b = Signal("b", width=4, direction=Direction.INPUT)
        dst = Signal("out", width=8, direction=Direction.OUTPUT)
        m = Module("dut", ports=[a, b, dst], body=[Assign(dst, Concat([a, b]))])
        sv = _emit(m)
        assert "{a, b}" in sv

    def test_ternary_expression(self) -> None:
        sel = Signal("sel", direction=Direction.INPUT)
        a = Signal("a", direction=Direction.INPUT)
        b = Signal("b", direction=Direction.INPUT)
        dst = Signal("out", direction=Direction.OUTPUT)
        m = Module("dut", ports=[sel, a, b, dst], body=[Assign(dst, Ternary(sel, a, b))])
        sv = _emit(m)
        assert "(sel ? a : b)" in sv


# ===========================================================================
# Indentation
# ===========================================================================


class TestIndentation:
    def test_port_indented_4_spaces(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        m = Module("dut", ports=[clk])
        sv = _emit(m)
        port_lines = [l for l in sv.splitlines() if "input" in l]
        assert port_lines[0].startswith("    ")

    def test_assign_indented_inside_module(self) -> None:
        src = Signal("s", direction=Direction.INPUT)
        dst = Signal("d", direction=Direction.OUTPUT)
        m = Module("dut", ports=[src, dst], body=[Assign(dst, src)])
        sv = _emit(m)
        assign_lines = [l for l in sv.splitlines() if l.strip().startswith("assign")]
        assert assign_lines[0].startswith("    ")

    def test_always_body_double_indented(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        dst = Signal("q", direction=Direction.OUTPUT)
        blk = Always([(Edge.POSEDGE, clk)], body=[NonBlockingAssign(dst, 0)])
        m = Module("dut", ports=[clk, dst], body=[blk])
        sv = _emit(m)
        nba_lines = [l for l in sv.splitlines() if "<=" in l]
        assert nba_lines[0].startswith("        ")  # 8 spaces


# ===========================================================================
# Integration: AXI-Lite interface
# ===========================================================================


class TestAXILiteIntegration:
    def test_axilite_module_emits(self) -> None:
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s_axi")
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)

        m = Module("axilite_bridge")
        m.add_port(clk)
        m.add_port(rst_n)
        for sig in axi.get_signals():
            m.add_port(sig)

        sv = _emitter(parameters={"Base Address": 0x4000_0000, "Data Width": 32}).emit(m)

        assert "module axilite_bridge" in sv
        assert "endmodule" in sv
        assert "s_axi_awvalid" in sv
        assert "s_axi_rdata" in sv
        assert "0x40000000" in sv

    def test_axilite_all_ports_present(self) -> None:
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s")
        m = Module("dut")
        for sig in axi.get_signals():
            m.add_port(sig)

        sv = _emit(m)
        for sig in axi.get_signals():
            assert sig.name in sv

    def test_axilite_with_assign_and_always(self) -> None:
        """Full module: ports + assign + always_ff with reset."""
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)
        valid_in = Signal("valid_in", direction=Direction.INPUT)
        valid_out = Signal("valid_out", direction=Direction.OUTPUT)
        state = Signal("state", width=2, direction=Direction.LOCAL)

        if_node = If(
            condition="!rst_n",
            then_body=[NonBlockingAssign(state, 0)],
            else_body=[NonBlockingAssign(state, valid_in)],
        )
        blk = Always(
            [(Edge.POSEDGE, clk), (Edge.NEGEDGE, rst_n)],
            body=[if_node],
        )

        m = Module(
            "dut", ports=[clk, rst_n, valid_in, valid_out], signals=[state], body=[Assign(valid_out, state), blk]
        )

        sv = _emit(m)
        assert "assign valid_out = state;" in sv
        assert "always_ff @(posedge clk or negedge rst_n) begin" in sv
        assert "if (!rst_n) begin" in sv
        assert "state <= 0;" in sv
        assert "state <= valid_in;" in sv

    def test_save_axilite_module(self) -> None:
        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s_axi")
        m = Module("axilite_bridge")
        for sig in axi.get_signals():
            m.add_port(sig)

        e = _emitter()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "axilite_bridge.sv"
            e.save(m, path)
            content = path.read_text()
            assert "module axilite_bridge" in content
            assert "endmodule" in content
