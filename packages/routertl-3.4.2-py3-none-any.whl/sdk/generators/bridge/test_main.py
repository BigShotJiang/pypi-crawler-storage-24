# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_main.py — Unit tests for main.py
======================================

Tests cover:
  - pre_elaborate_checks() for all 12 error codes (E1–E12)
  - _load_yaml_config() for YAML schema validation
  - main() CLI integration (inline mode, YAML mode, exit codes)
  - generate_bridge() end-to-end pipeline

Run with:
    python -m pytest sdk/generators/bridge/test_main.py -v
"""

import tempfile
from pathlib import Path

import pytest
from main import (
    ConfigError,
    _default_output,
    _load_yaml_config,
    _parse_int,
    generate_bridge,
    main,
    pre_elaborate_checks,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _good_cfg(**overrides) -> dict:
    """Return a valid baseline bridge config."""
    cfg = {
        "name": "bridge",
        "protocol": "axilite",
        "role": "slave",
        "data_width": 32,
        "addr_width": 16,
        "base_addr": 0x4000_0000,
        "size": 0x10000,
        "prefix": "s",
        "stages": 0,
        "reset_style": "async",
        "error_policy": "slverr",
        "lang": "sv",
        "no_sva": False,
    }
    cfg.update(overrides)
    return cfg


# ===========================================================================
# _parse_int
# ===========================================================================


class TestParseInt:
    def test_decimal_string(self) -> None:
        assert _parse_int("65536", "x") == 65536

    def test_hex_string(self) -> None:
        assert _parse_int("0x10000", "x") == 0x10000

    def test_plain_int(self) -> None:
        assert _parse_int(42, "x") == 42

    def test_invalid_raises(self) -> None:
        with pytest.raises(ConfigError):
            _parse_int("not_a_number", "x")


# ===========================================================================
# pre_elaborate_checks — happy path
# ===========================================================================


class TestPreElaborateChecksHappyPath:
    def test_valid_axilite_sv(self) -> None:
        pre_elaborate_checks(_good_cfg())  # must not raise

    def test_valid_avalon_sv(self) -> None:
        pre_elaborate_checks(_good_cfg(protocol="avalon", data_width=32))

    def test_valid_vhdl_no_sva(self) -> None:
        pre_elaborate_checks(_good_cfg(lang="vhdl", no_sva=True))

    def test_zero_base_addr(self) -> None:
        pre_elaborate_checks(_good_cfg(base_addr=0))

    def test_max_stages(self) -> None:
        pre_elaborate_checks(_good_cfg(stages=8))

    def test_data_width_8(self) -> None:
        pre_elaborate_checks(_good_cfg(data_width=8, size=256))

    def test_data_width_64(self) -> None:
        pre_elaborate_checks(_good_cfg(data_width=64, size=0x10000))

    def test_data_width_128(self) -> None:
        pre_elaborate_checks(_good_cfg(data_width=128, size=0x10000))


# ===========================================================================
# E1 — Unsupported data width
# ===========================================================================


class TestE1DataWidth:
    def test_data_width_7(self) -> None:
        with pytest.raises(ConfigError, match="data_width must be one of"):
            pre_elaborate_checks(_good_cfg(data_width=7))

    def test_data_width_24(self) -> None:
        with pytest.raises(ConfigError, match="data_width must be one of"):
            pre_elaborate_checks(_good_cfg(data_width=24))

    def test_data_width_256(self) -> None:
        with pytest.raises(ConfigError, match="data_width must be one of"):
            pre_elaborate_checks(_good_cfg(data_width=256))


# ===========================================================================
# E2 — Address width out of range
# ===========================================================================


class TestE2AddrWidth:
    def test_addr_width_0(self) -> None:
        with pytest.raises(ConfigError, match="addr_width must be in"):
            pre_elaborate_checks(_good_cfg(addr_width=0))

    def test_addr_width_65(self) -> None:
        with pytest.raises(ConfigError, match="addr_width must be in"):
            pre_elaborate_checks(_good_cfg(addr_width=65))

    def test_addr_width_1_valid(self) -> None:
        # addr_width=1 → 2 words max; size=4 (one word for 32-bit) is fine
        pre_elaborate_checks(_good_cfg(addr_width=1, size=4))

    def test_addr_width_64_valid(self) -> None:
        pre_elaborate_checks(_good_cfg(addr_width=64))


# ===========================================================================
# E3 — Misaligned base address
# ===========================================================================


class TestE3MisalignedBase:
    def test_misaligned_32bit(self) -> None:
        # data_width=32 → bytes_per_word=4; base_addr=1 is misaligned
        with pytest.raises(ConfigError, match="not aligned"):
            pre_elaborate_checks(_good_cfg(base_addr=1))

    def test_misaligned_by_2(self) -> None:
        with pytest.raises(ConfigError, match="not aligned"):
            pre_elaborate_checks(_good_cfg(base_addr=2))

    def test_aligned_4(self) -> None:
        pre_elaborate_checks(_good_cfg(base_addr=4))

    def test_aligned_0(self) -> None:
        pre_elaborate_checks(_good_cfg(base_addr=0))


# ===========================================================================
# E4 — Region size not a power of two
# ===========================================================================


class TestE4SizeNotPow2:
    def test_size_0(self) -> None:
        with pytest.raises(ConfigError, match="power of two"):
            pre_elaborate_checks(_good_cfg(size=0))

    def test_size_3(self) -> None:
        with pytest.raises(ConfigError, match="power of two"):
            pre_elaborate_checks(_good_cfg(size=3))

    def test_size_65535(self) -> None:
        with pytest.raises(ConfigError, match="power of two"):
            pre_elaborate_checks(_good_cfg(size=65535))

    def test_size_65536_valid(self) -> None:
        pre_elaborate_checks(_good_cfg(size=65536))


# ===========================================================================
# E5 — Region size smaller than one word
# ===========================================================================


class TestE5SizeTooSmall:
    def test_size_1_for_32bit(self) -> None:
        with pytest.raises(ConfigError, match="smaller than one word"):
            pre_elaborate_checks(_good_cfg(data_width=32, size=1))

    def test_size_2_for_32bit(self) -> None:
        with pytest.raises(ConfigError, match="smaller than one word"):
            pre_elaborate_checks(_good_cfg(data_width=32, size=2))

    def test_size_4_for_32bit_valid(self) -> None:
        pre_elaborate_checks(_good_cfg(data_width=32, size=4))


# ===========================================================================
# E6 — Address width too narrow for region
# ===========================================================================


class TestE6AddrWidthTooNarrow:
    def test_1bit_addr_2words(self) -> None:
        # addr_width=1 → max 2 words; size=16 → 4 words for 32-bit → too narrow
        with pytest.raises(ConfigError, match="cannot address"):
            pre_elaborate_checks(_good_cfg(addr_width=1, size=16))

    def test_exact_fit(self) -> None:
        # addr_width=2 → 4 words; size=16 → 4 words for 32-bit → exact fit
        pre_elaborate_checks(_good_cfg(addr_width=2, size=16))


# ===========================================================================
# E7 — Unsupported width ratio (Avalon only)
# ===========================================================================


class TestE7AvalonWidth:
    def test_avalon_16bit(self) -> None:
        with pytest.raises(ConfigError, match="Avalon-MM bridge supports data_width"):
            pre_elaborate_checks(_good_cfg(protocol="avalon", data_width=16))

    def test_avalon_8bit(self) -> None:
        with pytest.raises(ConfigError, match="Avalon-MM bridge supports data_width"):
            pre_elaborate_checks(_good_cfg(protocol="avalon", data_width=8))

    def test_avalon_32bit_valid(self) -> None:
        pre_elaborate_checks(_good_cfg(protocol="avalon", data_width=32))

    def test_avalon_64bit_valid(self) -> None:
        pre_elaborate_checks(_good_cfg(protocol="avalon", data_width=64))

    def test_axilite_16bit_valid(self) -> None:
        # E7 only applies to Avalon
        pre_elaborate_checks(_good_cfg(protocol="axilite", data_width=16, size=256))


# ===========================================================================
# E8 — SVA requested for VHDL output
# ===========================================================================


class TestE8VhdlSva:
    def test_vhdl_with_sva(self) -> None:
        with pytest.raises(ConfigError, match="SVA assertions are not supported"):
            pre_elaborate_checks(_good_cfg(lang="vhdl", no_sva=False))

    def test_vhdl_no_sva_valid(self) -> None:
        pre_elaborate_checks(_good_cfg(lang="vhdl", no_sva=True))

    def test_sv_with_sva_valid(self) -> None:
        pre_elaborate_checks(_good_cfg(lang="sv", no_sva=False))


# ===========================================================================
# E9 — Unknown protocol
# ===========================================================================


class TestE9UnknownProtocol:
    def test_unknown_protocol(self) -> None:
        with pytest.raises(ConfigError, match="Unknown protocol"):
            pre_elaborate_checks(_good_cfg(protocol="spi"))

    def test_case_sensitive(self) -> None:
        with pytest.raises(ConfigError, match="Unknown protocol"):
            pre_elaborate_checks(_good_cfg(protocol="AXILite"))


# ===========================================================================
# E12 — Pipeline stages out of range
# ===========================================================================


class TestE12Stages:
    def test_stages_negative(self) -> None:
        with pytest.raises(ConfigError, match="stages must be in"):
            pre_elaborate_checks(_good_cfg(stages=-1))

    def test_stages_9(self) -> None:
        with pytest.raises(ConfigError, match="stages must be in"):
            pre_elaborate_checks(_good_cfg(stages=9))

    def test_stages_0_valid(self) -> None:
        pre_elaborate_checks(_good_cfg(stages=0))

    def test_stages_8_valid(self) -> None:
        pre_elaborate_checks(_good_cfg(stages=8))


# ===========================================================================
# _default_output
# ===========================================================================


class TestDefaultOutput:
    def test_sv_extension(self) -> None:
        cfg = _good_cfg(name="my_bridge", lang="sv")
        assert _default_output(cfg, None).name == "my_bridge.sv"

    def test_vhdl_extension(self) -> None:
        cfg = _good_cfg(name="my_bridge", lang="vhdl")
        assert _default_output(cfg, None).name == "my_bridge.vhd"

    def test_with_output_dir(self) -> None:
        cfg = _good_cfg(name="bridge", lang="sv")
        out = _default_output(cfg, Path("/tmp/gen"))
        assert out == Path("/tmp/gen/bridge.sv")


# ===========================================================================
# YAML config loading — E10, E11
# ===========================================================================


class TestYamlConfig:
    def _write_yaml(self, content: str) -> Path:
        tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False)
        tmp.write(content)
        tmp.flush()
        return Path(tmp.name)

    def test_valid_single_bridge(self) -> None:
        path = self._write_yaml("""
version: "1"
bridges:
  - name: my_bridge
    protocol: axilite
    data_width: 32
    addr_width: 16
""")
        configs = _load_yaml_config(path)
        assert len(configs) == 1
        assert configs[0]["name"] == "my_bridge"

    def test_defaults_applied(self) -> None:
        path = self._write_yaml("""
version: "1"
defaults:
  lang: vhdl
  no_sva: true
bridges:
  - name: b1
    protocol: axilite
    data_width: 32
    addr_width: 16
""")
        configs = _load_yaml_config(path)
        assert configs[0]["lang"] == "vhdl"
        assert configs[0]["no_sva"] is True

    def test_bridge_overrides_defaults(self) -> None:
        path = self._write_yaml("""
version: "1"
defaults:
  lang: vhdl
  no_sva: true
bridges:
  - name: b1
    protocol: axilite
    data_width: 32
    addr_width: 16
    lang: sv
    no_sva: false
""")
        configs = _load_yaml_config(path)
        assert configs[0]["lang"] == "sv"
        assert configs[0]["no_sva"] is False

    def test_e10_version_mismatch(self) -> None:
        path = self._write_yaml("""
version: "2"
bridges:
  - name: b1
    protocol: axilite
    data_width: 32
    addr_width: 16
""")
        with pytest.raises(ConfigError, match="Unsupported config schema version"):
            _load_yaml_config(path)

    def test_e11_duplicate_names(self) -> None:
        path = self._write_yaml("""
version: "1"
bridges:
  - name: same
    protocol: axilite
    data_width: 32
    addr_width: 16
  - name: same
    protocol: axilite
    data_width: 32
    addr_width: 16
""")
        with pytest.raises(ConfigError, match="Duplicate bridge name"):
            _load_yaml_config(path)

    def test_empty_bridges_raises(self) -> None:
        path = self._write_yaml("""
version: "1"
bridges: []
""")
        with pytest.raises(ConfigError):
            _load_yaml_config(path)

    def test_output_dir_applied(self) -> None:
        path = self._write_yaml("""
version: "1"
output_dir: /tmp/gen
bridges:
  - name: b1
    protocol: axilite
    data_width: 32
    addr_width: 16
""")
        configs = _load_yaml_config(path)
        assert configs[0]["_output_path"] == Path("/tmp/gen/b1.sv")


# ===========================================================================
# generate_bridge — end-to-end
# ===========================================================================


class TestGenerateBridge:
    def test_generates_sv_file(self) -> None:
        cfg = _good_cfg()
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "bridge.sv"
            generate_bridge(cfg, out)
            assert out.exists()
            content = out.read_text()
            assert "module bridge" in content
            assert "endmodule" in content

    def test_generates_vhdl_file(self) -> None:
        cfg = _good_cfg(lang="vhdl", no_sva=True)
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "bridge.vhd"
            generate_bridge(cfg, out)
            assert out.exists()
            content = out.read_text()
            assert "entity bridge is" in content
            assert "end entity bridge;" in content

    def test_dry_run_does_not_write(self) -> None:
        cfg = _good_cfg()
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "bridge.sv"
            generate_bridge(cfg, out, dry_run=True)
            assert not out.exists()

    def test_config_error_propagates(self) -> None:
        cfg = _good_cfg(data_width=7)
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "bridge.sv"
            with pytest.raises(ConfigError):
                generate_bridge(cfg, out)

    def test_creates_parent_dirs(self) -> None:
        cfg = _good_cfg()
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "sub" / "dir" / "bridge.sv"
            generate_bridge(cfg, out)
            assert out.exists()


# ===========================================================================
# main() CLI — exit codes
# ===========================================================================


class TestMainCLI:
    def test_exit_0_inline(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = str(Path(tmp) / "bridge.sv")
            rc = main(
                [
                    "--protocol",
                    "axilite",
                    "--data-width",
                    "32",
                    "--addr-width",
                    "16",
                    "--base-addr",
                    "0x40000000",
                    "--size",
                    "0x10000",
                    "--module-name",
                    "bridge",
                    "--output",
                    out,
                ]
            )
        assert rc == 0

    def test_exit_2_bad_data_width(self) -> None:
        rc = main(
            [
                "--data-width",
                "7",
                "--addr-width",
                "16",
                "--output",
                "/tmp/x.sv",
            ]
        )
        assert rc == 2

    def test_exit_2_misaligned_base(self) -> None:
        rc = main(
            [
                "--data-width",
                "32",
                "--addr-width",
                "16",
                "--base-addr",
                "1",
                "--output",
                "/tmp/x.sv",
            ]
        )
        assert rc == 2

    def test_exit_2_vhdl_with_sva(self) -> None:
        rc = main(
            [
                "--lang",
                "vhdl",
                "--data-width",
                "32",
                "--addr-width",
                "16",
                "--output",
                "/tmp/x.vhd",
            ]
        )
        assert rc == 2

    def test_exit_0_vhdl_no_sva(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = str(Path(tmp) / "bridge.vhd")
            rc = main(
                [
                    "--lang",
                    "vhdl",
                    "--no-sva",
                    "--data-width",
                    "32",
                    "--addr-width",
                    "16",
                    "--output",
                    out,
                ]
            )
        assert rc == 0

    def test_exit_0_dry_run(self) -> None:
        rc = main(
            [
                "--dry-run",
                "--data-width",
                "32",
                "--addr-width",
                "16",
            ]
        )
        assert rc == 0

    def test_exit_0_yaml_config(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            yaml_path = Path(tmp) / "bridges.yaml"
            yaml_path.write_text(f"""
version: "1"
output_dir: {tmp}
bridges:
  - name: test_bridge
    protocol: axilite
    data_width: 32
    addr_width: 16
    base_addr: 0x0
    size: 0x10000
""")
            rc = main(["--config", str(yaml_path)])
        assert rc == 0

    def test_exit_2_yaml_bad_version(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            yaml_path = Path(tmp) / "bad.yaml"
            yaml_path.write_text("""
version: "99"
bridges:
  - name: b
    protocol: axilite
    data_width: 32
    addr_width: 16
""")
            rc = main(["--config", str(yaml_path)])
        assert rc == 2

    def test_default_output_name(self) -> None:
        """When --output is omitted, file is named <module-name>.sv."""
        import os

        orig = os.getcwd()
        with tempfile.TemporaryDirectory() as tmp:
            os.chdir(tmp)
            try:
                rc = main(
                    [
                        "--module-name",
                        "my_dut",
                        "--data-width",
                        "32",
                        "--addr-width",
                        "16",
                    ]
                )
                assert rc == 0
                assert (Path(tmp) / "my_dut.sv").exists()
            finally:
                os.chdir(orig)


# ===========================================================================
# Native → Avalon-MM cross-protocol bridge
# ===========================================================================


class TestNativeToAvalonCLI:
    def test_exit_0_inline(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = str(Path(tmp) / "native_avl.sv")
            rc = main(
                [
                    "--protocol",
                    "native",
                    "--target-protocol",
                    "avalon",
                    "--data-width",
                    "32",
                    "--addr-width",
                    "14",
                    "--prefix",
                    "s_mem",
                    "--module-name",
                    "native_avl_bridge",
                    "--output",
                    out,
                ]
            )
            assert rc == 0
            content = Path(out).read_text()
            assert "module native_avl_bridge" in content
            assert "s_mem_cs" in content
            assert "m_avl_write" in content
            assert "m_avl_waitrequest" in content

    def test_exit_0_vhdl(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = str(Path(tmp) / "native_avl.vhd")
            rc = main(
                [
                    "--protocol",
                    "native",
                    "--target-protocol",
                    "avalon",
                    "--data-width",
                    "32",
                    "--addr-width",
                    "14",
                    "--prefix",
                    "s_mem",
                    "--module-name",
                    "native_avl_bridge",
                    "--lang",
                    "vhdl",
                    "--no-sva",
                    "--output",
                    out,
                ]
            )
            assert rc == 0
            content = Path(out).read_text()
            assert "entity" in content.lower()

    def test_exit_0_yaml(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            yaml_path = Path(tmp) / "native_avl.yaml"
            yaml_path.write_text(f"""
version: "1"
output_dir: {tmp}
bridges:
  - name: my_native_avl
    protocol: native
    target_protocol: avalon
    data_width: 32
    addr_width: 14
    prefix: s_mem
""")
            rc = main(["--config", str(yaml_path)])
            assert rc == 0
            out = Path(tmp) / "my_native_avl.sv"
            assert out.exists()
            content = out.read_text()
            assert "module my_native_avl" in content

    def test_dry_run(self) -> None:
        rc = main(
            [
                "--protocol",
                "native",
                "--target-protocol",
                "avalon",
                "--data-width",
                "32",
                "--addr-width",
                "14",
                "--dry-run",
            ]
        )
        assert rc == 0


# ===========================================================================
# AXI-Lite → Native cross-protocol bridge
# ===========================================================================


class TestAxiLiteToNativeCLI:
    def test_exit_0_inline(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = str(Path(tmp) / "axilite_native.sv")
            rc = main(
                [
                    "--protocol",
                    "axilite",
                    "--target-protocol",
                    "native",
                    "--data-width",
                    "32",
                    "--addr-width",
                    "16",
                    "--prefix",
                    "s_axi",
                    "--module-name",
                    "axilite_native_bridge",
                    "--output",
                    out,
                ]
            )
            assert rc == 0
            content = Path(out).read_text()
            assert "module axilite_native_bridge" in content
            assert "s_axi_awvalid" in content
            assert "m_mem_cs" in content

    def test_exit_0_vhdl(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = str(Path(tmp) / "axilite_native.vhd")
            rc = main(
                [
                    "--protocol",
                    "axilite",
                    "--target-protocol",
                    "native",
                    "--data-width",
                    "32",
                    "--addr-width",
                    "16",
                    "--prefix",
                    "s_axi",
                    "--module-name",
                    "axilite_native_bridge",
                    "--lang",
                    "vhdl",
                    "--no-sva",
                    "--output",
                    out,
                ]
            )
            assert rc == 0

    def test_exit_0_yaml(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            yaml_path = Path(tmp) / "axilite_native.yaml"
            yaml_path.write_text(f"""
version: "1"
output_dir: {tmp}
bridges:
  - name: my_axilite_native
    protocol: axilite
    target_protocol: native
    data_width: 32
    addr_width: 16
    prefix: s_axi
    read_latency: 2
""")
            rc = main(["--config", str(yaml_path)])
            assert rc == 0
            out = Path(tmp) / "my_axilite_native.sv"
            assert out.exists()

    def test_dry_run(self) -> None:
        rc = main(
            [
                "--protocol",
                "axilite",
                "--target-protocol",
                "native",
                "--data-width",
                "32",
                "--addr-width",
                "16",
                "--dry-run",
            ]
        )
        assert rc == 0


# ===========================================================================
# Native → AXI-Lite cross-protocol bridge
# ===========================================================================


class TestNativeToAxiLiteCLI:
    def test_exit_0_inline(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = str(Path(tmp) / "native_axilite.sv")
            rc = main(
                [
                    "--protocol",
                    "native",
                    "--target-protocol",
                    "axilite",
                    "--data-width",
                    "32",
                    "--addr-width",
                    "14",
                    "--prefix",
                    "s_mem",
                    "--module-name",
                    "native_axilite_bridge",
                    "--output",
                    out,
                ]
            )
            assert rc == 0
            content = Path(out).read_text()
            assert "module native_axilite_bridge" in content
            assert "s_mem_cs" in content
            assert "m_axi_awvalid" in content

    def test_exit_0_vhdl(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = str(Path(tmp) / "native_axilite.vhd")
            rc = main(
                [
                    "--protocol",
                    "native",
                    "--target-protocol",
                    "axilite",
                    "--data-width",
                    "32",
                    "--addr-width",
                    "14",
                    "--prefix",
                    "s_mem",
                    "--module-name",
                    "native_axilite_bridge",
                    "--lang",
                    "vhdl",
                    "--no-sva",
                    "--output",
                    out,
                ]
            )
            assert rc == 0

    def test_exit_0_yaml(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            yaml_path = Path(tmp) / "native_axilite.yaml"
            yaml_path.write_text(f"""
version: "1"
output_dir: {tmp}
bridges:
  - name: my_native_axilite
    protocol: native
    target_protocol: axilite
    data_width: 32
    addr_width: 14
    prefix: s_mem
""")
            rc = main(["--config", str(yaml_path)])
            assert rc == 0
            out = Path(tmp) / "my_native_axilite.sv"
            assert out.exists()

    def test_dry_run(self) -> None:
        rc = main(
            [
                "--protocol",
                "native",
                "--target-protocol",
                "axilite",
                "--data-width",
                "32",
                "--addr-width",
                "14",
                "--dry-run",
            ]
        )
        assert rc == 0


