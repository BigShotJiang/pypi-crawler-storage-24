# Bridge Verification Architecture

> Full pipeline from YAML config → RTL generation → simulation → scoreboard verdict.

---

## End-to-End Flow

```mermaid
flowchart TB
    subgraph GEN["🔧 RTL Generator (bridge-gen)"]
        YAML["bridge.yaml\n<i>data_width, base_addr,\nprotocol, stages...</i>"]
        PRE["Pre-Elaboration\nChecks"]
        AST["HDL AST Builder"]
        VAL["Validator\n+ SVA Injector"]
        EMIT["Emitter\n(SV / VHDL)"]
        YAML --> PRE --> AST --> VAL --> EMIT
    end

    subgraph SIM["🧪 Cocotb Simulation (NVC)"]
        direction TB
        DUT["Generated Bridge RTL\n<i>(bridge.vhd)</i>"]

        subgraph DRIVE["Drivers"]
            MASTER["AxiLiteMaster\n<i>write() / read()</i>"]
        end

        subgraph RESPOND["Responders"]
            SLAVE["AxiLiteSlave\n<i>sparse memory model</i>"]
        end

        subgraph MONITOR["Monitors"]
            PROTO["Protocol Monitor\n<i>VALID stability\nX/Z guards</i>"]
            STATS["Transaction Stats\n<i>latency, throughput</i>"]
        end

        subgraph CHECK["Checkers"]
            SB["BridgeScoreboard\n<i>write-track → read-verify</i>"]
            VERDICT["Pass / Fail\n<i>+ mismatch report</i>"]
        end

        MASTER -->|"AW/W/B channels"| DUT
        DUT -->|"AR/R channels"| MASTER
        DUT -->|"native interface"| SLAVE
        MASTER -.->|"record_write()"| SB
        MASTER -.->|"check_read()"| SB
        DUT -.->|"signal tap"| PROTO
        MASTER -.->|"get_stats()"| STATS
        SB --> VERDICT
    end

    subgraph REG["🔄 Parametric Regression"]
        MATRIX["Parameter Matrix\n<i>data_width × base_addr</i>"]
        CLEAN["make clean"]
        RUN["run_simulation()"]
        REPORT["Summary Table\n<i>8 configs × pass/fail</i>"]
        MATRIX --> CLEAN --> RUN --> REPORT
    end

    EMIT -->|"bridge.vhd"| DUT
    YAML -.->|"config dict"| MATRIX
    MATRIX -->|"generate_bridge()"| GEN
    RUN -->|"launch"| SIM

    style GEN fill:#1a1a2e,stroke:#e94560,color:#fff
    style SIM fill:#0f3460,stroke:#e94560,color:#fff
    style REG fill:#162447,stroke:#e94560,color:#fff
    style DRIVE fill:#1a1a3e,stroke:#16c784,color:#fff
    style RESPOND fill:#1a1a3e,stroke:#3861fb,color:#fff
    style MONITOR fill:#1a1a3e,stroke:#f5a623,color:#fff
    style CHECK fill:#1a1a3e,stroke:#e94560,color:#fff
```

---

## Data Flow per Transaction

```mermaid
sequenceDiagram
    participant Test as Test Case
    participant Master as AxiLiteMaster
    participant DUT as Bridge RTL
    participant Slave as AxiLiteSlave
    participant SB as Scoreboard
    participant Mon as Protocol Monitor

    Note over Test: Write Phase
    Test->>Master: write(0x100, 0xDEAD)
    Master->>DUT: AW + W channels
    activate Mon
    Mon-->>Mon: check VALID stability
    deactivate Mon
    DUT->>Slave: native write
    Slave-->>DUT: write response
    DUT->>Master: B channel (OKAY)
    Master-->>SB: record_write(0x100, 0xDEAD)

    Note over Test: Read-back Phase
    Test->>Master: read(0x100)
    Master->>DUT: AR channel
    DUT->>Slave: native read
    Slave-->>DUT: read data
    DUT->>Master: R channel (0xDEAD)
    Master-->>SB: check_read(0x100, 0xDEAD)
    SB-->>Test: ✅ match

    Note over Test: Final Verdict
    Test->>SB: report()
    SB-->>Test: "0 mismatches, 1 write, 1 read"
```

---

## Component Progress Tracker

| Layer | Component | File | Status |
|-------|-----------|------|--------|
| **Generator** | YAML Parser | [main.py](file:///tools/bridge-gen/main.py) | ✅ Done |
| | Pre-Elaboration | [main.py](file:///tools/bridge-gen/main.py) | ✅ Done |
| | HDL AST | [hdl_ast.py](file:///tools/bridge-gen/hdl_ast.py) | ✅ Done |
| | Address Map | [addr_map.py](file:///tools/bridge-gen/addr_map.py) | ✅ Done |
| | Validator + SVA | [validator.py](file:///tools/bridge-gen/validator.py) | ✅ Done |
| | SV Emitter | [emitter_sv.py](file:///tools/bridge-gen/emitter_sv.py) | ✅ Done |
| | VHDL Emitter | [emitter_vhdl.py](file:///tools/bridge-gen/emitter_vhdl.py) | ✅ Done |
| | Pipeline Stages | [pipeline.py](file:///tools/bridge-gen/pipeline.py) | ✅ Done |
| **Drivers** | AXI-Lite Master | [axi_lite.py](file:///sim/cocotb/tb/drivers/axi_lite.py) | ✅ Done |
| | AXI-Lite Slave | [axi_lite.py](file:///sim/cocotb/tb/drivers/axi_lite.py) | ✅ Done |
| | SPI Master | [spi_master.py](file:///sim/cocotb/tb/drivers/spi_master.py) | ✅ Done |
| | UART Master | [uart_master.py](file:///sim/cocotb/tb/drivers/uart_master.py) | ✅ Done |
| | Avalon-MM Master | [avalon_mm.py](../../sim/cocotb/tb/drivers/avalon_mm.py) | ✅ Done |
| **Monitors** | X/Z Guards | [axi_lite.py](../../sim/cocotb/tb/drivers/axi_lite.py) | ✅ Done |
| | Transaction Stats | [axi_lite.py](../../sim/cocotb/tb/drivers/axi_lite.py) | ✅ Done |
| | VALID Stability | [axi_lite_monitor.py](../../sim/cocotb/tb/monitors/axi_lite_monitor.py) | ✅ Done |
| **Checkers** | BridgeScoreboard | [scoreboard.py](../../sim/cocotb/tb/scoreboard.py) | ✅ Done |
| **Regression** | Parametric Sweep | [tb_axilite_avalon_bridge.py](../../sim/cocotb/tests/drivers/test_axilite_avalon_bridge.py) | ✅ Done |

---

## Parameter Matrix (Default)

```mermaid
block-beta
    columns 5
    space header1["base = 0x0000"] header2["base = 0x4000"] space
    row1["8-bit"]  c1["8b @ 0x0"] c2["8b @ 0x4000"] space
    row2["16-bit"] c3["16b @ 0x0"] c4["16b @ 0x4000"] space
    row3["32-bit"] c5["32b @ 0x0"] c6["32b @ 0x4000"] space
    row4["64-bit"] c7["64b @ 0x0"] c8["64b @ 0x4000"] space

    style c1 fill:#162447,stroke:#16c784,color:#fff
    style c2 fill:#162447,stroke:#16c784,color:#fff
    style c3 fill:#162447,stroke:#16c784,color:#fff
    style c4 fill:#162447,stroke:#16c784,color:#fff
    style c5 fill:#162447,stroke:#16c784,color:#fff
    style c6 fill:#162447,stroke:#16c784,color:#fff
    style c7 fill:#162447,stroke:#16c784,color:#fff
    style c8 fill:#162447,stroke:#16c784,color:#fff
```

Each cell = one `generate_bridge()` → `make clean` → `run_simulation()` cycle.
