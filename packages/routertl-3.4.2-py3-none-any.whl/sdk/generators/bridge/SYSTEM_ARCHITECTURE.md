# RTL Bridge Generator — System Architecture

> Formal design specification for the AXI-Lite / Avalon-MM → Native Memory
> bridge generator.  This document describes the full compiler pipeline,
> all supported protocols, and the key design policies.

---

## Pipeline Overview

The generator follows a **compiler pipeline** architecture.  Each layer
has a single responsibility and communicates with adjacent layers through
well-defined Python objects.

```
┌─────────────────────────────────────────────────────────────────────┐
│  Frontend                                                           │
│  bus_interfaces.py                                                  │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐  │
│  │ AXILiteInterface │  │ AvalonMMInterface │  │NativeMemInterface│  │
│  └────────┬─────────┘  └────────┬─────────┘  └────────┬─────────┘  │
│           │ List[Signal]        │                      │            │
└───────────┼─────────────────────┼──────────────────────┼────────────┘
            │                     │                      │
┌───────────▼─────────────────────▼──────────────────────▼────────────┐
│  Middle-end (AST)                                                   │
│  hdl_ast.py                                                         │
│  Module ── ports ── signals ── body                                 │
│              │                   │                                  │
│           Signal             Assign / Always / If / Case            │
└───────────────────────────────────────────────────────────────────┬─┘
                                                                    │
┌───────────────────────────────────────────────────────────────────▼─┐
│  Logic Layer                                                        │
│  addr_map.py          error_policy (future)                         │
│  AddressMap ──► word_addr_expr() ──► Assign / If nodes              │
│                 in_range_expr()                                     │
│                                                                     │
│  pipeline.py                                                        │
│  RegisterSliceBuilder ──► LOCAL signals + Always blocks             │
└───────────────────────────────────────────────────────────────────┬─┘
                                                                    │
┌───────────────────────────────────────────────────────────────────▼─┐
│  Validator                                                          │
│  validator.py                                                       │
│  check_widths() / check_handshakes() / check_address_bounds()       │
│  inject_sva() ──► List[SvaProperty]                                 │
└───────────────────────────────────────────────────────────────────┬─┘
                                                                    │
┌───────────────────────────────────────────────────────────────────▼─┐
│  Backend (Emitter)  [future work]                                   │
│  emit_systemverilog(module, sva_properties)                         │
│  emit_vhdl(module)                                                  │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Supported Protocols

### AXI4-Lite (AMBA)

| Signal | Width | Direction (SLAVE) | Description |
|--------|-------|-------------------|-------------|
| `awaddr` | `addr_width` | INPUT | Write address |
| `awprot` | 3 | INPUT | Protection type |
| `awvalid` | 1 | INPUT | Write address valid |
| `awready` | 1 | OUTPUT | Write address ready |
| `wdata` | `data_width` | INPUT | Write data |
| `wstrb` | `data_width/8` | INPUT | Byte enables |
| `wvalid` | 1 | INPUT | Write data valid |
| `wready` | 1 | OUTPUT | Write data ready |
| `bresp` | 2 | OUTPUT | Write response |
| `bvalid` | 1 | OUTPUT | Write response valid |
| `bready` | 1 | INPUT | Write response ready |
| `araddr` | `addr_width` | INPUT | Read address |
| `arprot` | 3 | INPUT | Protection type |
| `arvalid` | 1 | INPUT | Read address valid |
| `arready` | 1 | OUTPUT | Read address ready |
| `rdata` | `data_width` | OUTPUT | Read data |
| `rresp` | 2 | OUTPUT | Read response |
| `rvalid` | 1 | OUTPUT | Read data valid |
| `rready` | 1 | INPUT | Read data ready |

**BRESP / RRESP encoding:**

| Code | Meaning |
|------|---------|
| `2'b00` | OKAY |
| `2'b01` | EXOKAY (not used in AXI-Lite) |
| `2'b10` | SLVERR (slave error) |
| `2'b11` | DECERR (decode error) |

---

### Avalon-MM (Intel)

| Signal | Width | Direction (SLAVE) | Description |
|--------|-------|-------------------|-------------|
| `address` | `addr_width` | INPUT | Word address |
| `read` | 1 | INPUT | Read strobe |
| `write` | 1 | INPUT | Write strobe |
| `writedata` | `data_width` | INPUT | Write data |
| `byteenable` | `data_width/8` | INPUT | Byte enables |
| `readdata` | `data_width` | OUTPUT | Read data |
| `readdatavalid` | 1 | OUTPUT | Read data valid |
| `waitrequest` | 1 | OUTPUT | Stall (active-high) |
| `response` | 2 | OUTPUT | Error response |

> [!NOTE]
> Avalon-MM uses a **word address** natively.  The `AddressTransformer`
> converts AXI byte addresses to Avalon word addresses.

**`response[1:0]` encoding:**

| Code | Meaning |
|------|---------|
| `2'b00` | OKAY |
| `2'b10` | SLVERR |
| `2'b11` | DECERR |

---

### Native Memory (SRAM-style)

| Signal | Width | Direction (MASTER) | Description |
|--------|-------|-------------------|-------------|
| `addr` | `addr_width` | OUTPUT | Word address |
| `din` | `data_width` | OUTPUT | Write data |
| `we` | `data_width/8` | OUTPUT | Byte-write enables |
| `re` | 1 | OUTPUT | Read enable |
| `cs` | 1 | OUTPUT | Chip select |
| `dout` | `data_width` | INPUT | Read data |
| `ack` | 1 | INPUT | Transaction acknowledged |

---

## Address Mapping

### Formula

```
word_addr = (axi_byte_addr - base_addr) >> log2(data_width / 8)
```

### Parameters

| Parameter | Description |
|-----------|-------------|
| `base_addr` | First AXI byte address that maps to native word 0 |
| `size_bytes` | Total mapped region size |
| `data_width` | Bus width in bits (must be power-of-two ≥ 8) |
| `addr_width` | Native word-address bus width |

### Worked Example

```
data_width = 32  →  bytes_per_word = 4  →  byte_shift = 2
base_addr  = 0x4000_0000
size_bytes = 0x0001_0000  (64 KiB = 16 384 words)

AXI byte addr 0x4000_0000 → word 0
AXI byte addr 0x4000_0004 → word 1
AXI byte addr 0x4000_FFFC → word 16383
AXI byte addr 0x4001_0000 → OUT OF RANGE → SLVERR
```

### AST Expression Optimisation

| `base_addr` | `byte_shift` | `word_addr_expr` returns |
|-------------|-------------|--------------------------|
| 0 | > 0 | `Slice(awaddr, msb, byte_shift)` — clean AST node |
| 0 | 0 | `awaddr` — signal pass-through |
| ≠ 0 | any | `"(awaddr - 0x…) >> N[addr_width-1:0]"` — string expr |

---

## Error Handling Policy

When the AXI master issues an address outside the mapped range, the bridge
must complete the AXI handshake with an error response.

| Policy | AXI response | Avalon response | Use case |
|--------|-------------|-----------------|----------|
| `SLVERR` | `2'b10` | `2'b10` | Default — slave-side error |
| `DECERR` | `2'b11` | `2'b11` | Interconnect decode error |
| `IGNORE` | `2'b00` | `2'b00` | Stub bridges / simulation |

The `Validator.inject_sva()` generates assertions that verify the
valid-stable rule for all five AXI-Lite channels, catching protocol
violations in simulation before synthesis.

---

## Timing Strategy — Register Slices

The `RegisterSliceBuilder` inserts flip-flop stages between signals.

### Signal naming

```
awaddr ──► awaddr_s1 ──► awaddr_s2 ──► (downstream)
           (stage 1)     (stage 2)
```

### Reset styles

| Style | Sensitivity list | Reset branch |
|-------|-----------------|--------------|
| `SYNC` | `posedge clk` | Inside the clocked block |
| `ASYNC` | `posedge clk, negedge rst_n` | Outside (first priority) |

### Latency budget

| Stages | Added latency | Typical use |
|--------|--------------|-------------|
| 0 | 0 cycles | Same-die, short path |
| 1 | 1 cycle | Moderate path |
| 2 | 2 cycles | Cross-die / > 250 MHz |

---

## VHDL vs SystemVerilog Output Differences

The AST is **HDL-agnostic**.  The emitter (future work) handles all
language-specific syntax.

| Concept | SystemVerilog | VHDL |
|---------|--------------|------|
| Signal declaration | `logic [N:0] sig;` | `signal sig : std_logic_vector(N downto 0);` |
| Clocked block | `always_ff @(posedge clk)` | `process(clk) … rising_edge(clk)` |
| Non-blocking assign | `sig <= val;` | `sig <= val;` (same) |
| Concatenation | `{a, b}` | `a & b` |
| Ternary | `cond ? a : b` | `a when cond else b` |
| Reset value | `'0` / integer | `(others => '0')` |
| SVA assertions | Native `assert property` | Not supported (VHDL PSL is separate) |

> [!IMPORTANT]
> SVA properties generated by `Validator.inject_sva()` are only valid for
> **SystemVerilog** output.  For VHDL, use PSL assertions or a separate
> formal verification flow.

---

## Module Inventory

| Module | File | Layer | Status |
|--------|------|-------|--------|
| `hdl_ast` | `hdl_ast.py` | Middle-end | ✅ Complete |
| `bus_interfaces` | `bus_interfaces.py` | Frontend | ✅ Complete |
| `addr_map` | `addr_map.py` | Logic Layer | ✅ Complete |
| `validator` | `validator.py` | Validator | ✅ Complete |
| `pipeline` | `pipeline.py` | Logic Layer | ✅ Complete |
| `emitter_base` | `emitter_base.py` | Backend | ✅ Complete |
| `emitter_sv` | `emitter_sv.py` | Backend | ✅ Complete |
| `emitter_vhdl` | `emitter_vhdl.py` | Backend | ✅ Complete |
| `main` | `main.py` | UI Layer | ✅ Complete |
| Error Policy | `error_policy.py` | Logic Layer | 🔲 Planned |
| AXI4 Full | `bus_interfaces.py` | Frontend | 🔲 Phase 2 |

---

## Section 4: User Configuration & CLI

### 4.1 CLI Arguments

The entry point is `main.py`, invoked as:

```
python main.py [OPTIONS]
python main.py --config bridge.yaml
```

#### Argument Reference

| Argument | Type | Default | Description |
|----------|------|---------|-------------|
| `--config` | `path` | — | Path to a YAML config file (batch / complex mode). Mutually exclusive with inline args. |
| `--protocol` | `str` | `axilite` | Bus protocol: `axilite` \| `avalon` |
| `--role` | `str` | `slave` | Interface role: `slave` \| `master` |
| `--data-width` | `int` | `32` | Data bus width in bits. Must be a power of two in `{8, 16, 32, 64, 128}`. |
| `--addr-width` | `int` | `32` | Address bus width in bits. Range: `1–64`. |
| `--base-addr` | `hex/int` | `0` | Base byte address of the mapped region. Must be aligned to `data_width / 8`. |
| `--size` | `hex/int` | `65536` | Mapped region size in bytes. Must be a power of two and ≥ `data_width / 8`. |
| `--prefix` | `str` | `s` | Signal name prefix (e.g. `s_axi`, `m_avl`). |
| `--stages` | `int` | `0` | Number of register-slice pipeline stages. Range: `0–8`. |
| `--reset-style` | `str` | `async` | Reset style: `async` \| `sync`. |
| `--error-policy` | `str` | `slverr` | Out-of-range error response: `slverr` \| `decerr` \| `ignore`. |
| `--lang` | `str` | `sv` | Output language: `sv` (SystemVerilog) \| `vhdl`. |
| `--output` | `path` | `<module>.sv` | Output file path. Defaults to `<module_name>.<lang_ext>`. |
| `--module-name` | `str` | `bridge` | Top-level module / entity name. |
| `--no-sva` | `flag` | `False` | Suppress SVA assertion injection (SV only). |
| `--verbose` | `flag` | `False` | Print generated source to stdout in addition to saving. |
| `--dry-run` | `flag` | `False` | Validate and print the output path, but do not write the file. |

> [!NOTE]
> `--base-addr` and `--size` accept both decimal (`65536`) and
> hex (`0x10000`) string literals.

---

### 4.2 YAML Configuration Schema

The YAML file enables **batch generation** (multiple bridges in one run)
and provides a structured alternative to long command lines.

```yaml
# bridge.yaml — RTL Bridge Generator configuration
# All fields are optional unless marked (required).

version: "1"                    # Schema version (must be "1")

defaults:                       # Applied to every bridge unless overridden
  lang: sv                      # "sv" | "vhdl"
  reset_style: async            # "async" | "sync"
  error_policy: slverr          # "slverr" | "decerr" | "ignore"
  stages: 0                     # Register-slice pipeline stages (0–8)
  no_sva: false                 # Suppress SVA injection

output_dir: ./generated         # Directory for all output files

bridges:
  - name: axi_to_sram           # (required) Module / entity name
    protocol: axilite            # (required) "axilite" | "avalon"
    role: slave                  # "slave" | "master"  (default: slave)
    data_width: 32               # (required) 8 | 16 | 32 | 64 | 128
    addr_width: 16               # (required) 1–64
    base_addr: 0x40000000        # Byte address (default: 0)
    size: 0x10000                # Mapped region bytes (default: 65536)
    prefix: s_axi                # Signal prefix (default: "s")
    output: axi_to_sram.sv       # Override output filename
    # Per-bridge overrides (take precedence over defaults):
    lang: sv
    stages: 1
    reset_style: async
    error_policy: slverr
    no_sva: false

  - name: avl_to_sram
    protocol: avalon
    data_width: 32
    addr_width: 14
    base_addr: 0x0
    size: 0x4000
    prefix: avl
    lang: vhdl
    stages: 0
```

#### Schema Rules

| Field | Type | Constraints |
|-------|------|-------------|
| `version` | string | Must be `"1"` |
| `defaults` | mapping | All keys optional; same names as CLI args |
| `output_dir` | path | Created if it does not exist |
| `bridges` | sequence | At least one entry required |
| `bridges[].name` | string | Valid Python identifier; used as module name |
| `bridges[].protocol` | string | `axilite` or `avalon` |
| `bridges[].data_width` | int | `{8, 16, 32, 64, 128}` |
| `bridges[].addr_width` | int | `1–64` |
| `bridges[].base_addr` | int/hex | Must be aligned to `data_width / 8` |
| `bridges[].size` | int/hex | Power of two; ≥ `data_width / 8` |
| `bridges[].stages` | int | `0–8` |

---

### 4.3 Pre-Elaboration Checks

These checks run **immediately after argument parsing / YAML loading**,
before any AST is constructed or emitter is called.  A failed check
raises a `ConfigError` with a human-readable message and exits with
code `2`.

#### E1 — Unsupported data width

**Trigger**: `data_width` ∉ `{8, 16, 32, 64, 128}`

**Message**: `data_width must be one of {8, 16, 32, 64, 128}; got <N>`

**Rationale**: The byte-enable width (`data_width / 8`) must be a whole
number of bits, and synthesis tools only support standard bus widths.

---

#### E2 — Address width out of range

**Trigger**: `addr_width` < 1 or `addr_width` > 64

**Message**: `addr_width must be in [1, 64]; got <N>`

---

#### E3 — Misaligned base address

**Trigger**: `base_addr % (data_width / 8) ≠ 0`

**Message**: `base_addr 0x<X> is not aligned to data_width/8 = <B> bytes`

**Rationale**: The address translator right-shifts by `log2(bytes_per_word)`.
An unaligned base address would silently discard the low bits, producing
incorrect word addresses.

---

#### E4 — Region size not a power of two

**Trigger**: `size & (size - 1) ≠ 0` (or `size == 0`)

**Message**: `size must be a power of two; got <N>`

**Rationale**: The in-range comparator uses a single bit-mask check
(`addr < size >> byte_shift`), which requires a power-of-two size.

---

#### E5 — Region size smaller than one word

**Trigger**: `size < data_width / 8`

**Message**: `size <N> bytes is smaller than one word (<B> bytes)`

---

#### E6 — Address width too narrow for region

**Trigger**: `(size / (data_width / 8)) > 2 ** addr_width`

**Message**: `addr_width=<A> bits cannot address <W> words (need ≥ <N> bits)`

**Rationale**: The native memory port would silently truncate the word
address, aliasing high addresses to low ones.

---

#### E7 — Unsupported width ratio (Avalon only)

**Trigger**: `protocol == "avalon"` and `data_width` not in `{32, 64}`

**Message**: `Avalon-MM bridge only supports data_width 32 or 64; got <N>`

**Rationale**: The Avalon-MM `byteenable` encoding is only well-defined
for 32-bit and 64-bit buses in the current implementation.

---

#### E8 — SVA requested for VHDL output

**Trigger**: `lang == "vhdl"` and `no_sva == False`

**Message**: `SVA assertions are not supported for VHDL output; use --no-sva or --lang sv`

**Rationale**: `Validator.inject_sva()` generates SystemVerilog
`assert property` constructs.  VHDL PSL is a separate flow.

---

#### E9 — Unknown protocol

**Trigger**: `protocol` ∉ `{"axilite", "avalon"}`

**Message**: `Unknown protocol '<P>'; supported: axilite, avalon`

---

#### E10 — YAML schema version mismatch

**Trigger**: YAML `version` field ≠ `"1"`

**Message**: `Unsupported config schema version '<V>'; expected "1"`

---

#### E11 — Duplicate bridge names in YAML

**Trigger**: Two or more `bridges[].name` values are identical

**Message**: `Duplicate bridge name '<N>' in config file`

**Rationale**: Each bridge maps to a distinct output file; duplicates
would silently overwrite each other.

---

#### E12 — Pipeline stages out of range

**Trigger**: `stages` < 0 or `stages` > 8

**Message**: `stages must be in [0, 8]; got <N>`

---

### 4.4 Exit Codes

| Code | Meaning |
|------|---------|
| `0` | Success — all files generated |
| `1` | Internal error (unexpected exception) |
| `2` | Configuration / pre-elaboration error (`ConfigError`) |
| `3` | Validation error (`ValidationError` from `validator.py`) |
