# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_bus_interfaces.py — Unit tests for bus_interfaces.py
==========================================================

Run with:
    python -m pytest sdk/generators/bridge/test_bus_interfaces.py -v
"""

import pytest
from bus_interfaces import (
    AvalonMMInterface,
    AXILiteInterface,
    InterfaceRole,
    NativeMemInterface,
    Protocol,
)
from hdl_ast import Assign, Direction, Signal

# ===========================================================================
# BusInterface base — validation
# ===========================================================================


class TestBusInterfaceValidation:
    def test_non_power_of_two_data_width_raises(self) -> None:
        with pytest.raises(ValueError, match="power-of-two"):
            AXILiteInterface(data_width=24, addr_width=16)

    def test_data_width_too_small_raises(self) -> None:
        with pytest.raises(ValueError, match="power-of-two"):
            AXILiteInterface(data_width=4, addr_width=8)

    def test_zero_addr_width_raises(self) -> None:
        with pytest.raises(ValueError, match="addr_width"):
            AXILiteInterface(data_width=32, addr_width=0)

    def test_valid_construction(self) -> None:
        iface = AXILiteInterface(data_width=32, addr_width=16)
        assert iface.data_width == 32
        assert iface.addr_width == 16


# ===========================================================================
# AXILiteInterface
# ===========================================================================


class TestAXILiteInterface:
    def _slave(self, dw: int = 32, aw: int = 16) -> AXILiteInterface:
        return AXILiteInterface(data_width=dw, addr_width=aw)

    def _master(self, dw: int = 32, aw: int = 16) -> AXILiteInterface:
        return AXILiteInterface(data_width=dw, addr_width=aw, role=InterfaceRole.MASTER)

    def test_protocol_tag(self) -> None:
        assert self._slave().protocol == Protocol.AXI_LITE

    def test_signal_count(self) -> None:
        # 4 (AW) + 4 (W) + 3 (B) + 4 (AR) + 4 (R) = 19 signals
        assert len(self._slave().get_signals()) == 19

    def test_all_signals_are_Signal_instances(self) -> None:
        for sig in self._slave().get_signals():
            assert isinstance(sig, Signal)

    def test_awaddr_width(self) -> None:
        iface = self._slave(aw=20)
        assert iface.awaddr.width == 20

    def test_wdata_width(self) -> None:
        iface = self._slave(dw=64)
        assert iface.wdata.width == 64

    def test_wstrb_width(self) -> None:
        iface = self._slave(dw=32)
        assert iface.wstrb.width == 4  # 32/8

    def test_wstrb_width_64bit(self) -> None:
        iface = self._slave(dw=64)
        assert iface.wstrb.width == 8  # 64/8

    def test_bresp_width(self) -> None:
        assert self._slave().bresp.width == 2

    def test_slave_awvalid_is_input(self) -> None:
        assert self._slave().awvalid.direction == Direction.INPUT

    def test_slave_awready_is_output(self) -> None:
        assert self._slave().awready.direction == Direction.OUTPUT

    def test_slave_rdata_is_output(self) -> None:
        assert self._slave().rdata.direction == Direction.OUTPUT

    def test_slave_rready_is_input(self) -> None:
        assert self._slave().rready.direction == Direction.INPUT

    def test_master_awvalid_is_output(self) -> None:
        assert self._master().awvalid.direction == Direction.OUTPUT

    def test_master_awready_is_input(self) -> None:
        assert self._master().awready.direction == Direction.INPUT

    def test_prefix_applied(self) -> None:
        iface = AXILiteInterface(data_width=32, addr_width=16, prefix="s_axi")
        assert iface.awvalid.name == "s_axi_awvalid"
        assert iface.rdata.name == "s_axi_rdata"

    def test_no_prefix(self) -> None:
        iface = AXILiteInterface(data_width=32, addr_width=16, prefix="")
        assert iface.awvalid.name == "awvalid"

    def test_attribute_access_unknown_raises(self) -> None:
        iface = self._slave()
        with pytest.raises(AttributeError, match="no signal"):
            _ = iface.nonexistent_signal

    def test_repr(self) -> None:
        iface = self._slave()
        r = repr(iface)
        assert "AXILiteInterface" in r
        assert "32" in r

    def test_get_signals_order_stable(self) -> None:
        """get_signals() must return signals in a consistent, defined order."""
        iface = self._slave()
        names = [s.name for s in iface.get_signals()]
        # awaddr must come before awvalid (definition order)
        assert names.index("awaddr") < names.index("awvalid")


# ===========================================================================
# AvalonMMInterface
# ===========================================================================


class TestAvalonMMInterface:
    def _slave(self, dw: int = 32, aw: int = 14) -> AvalonMMInterface:
        return AvalonMMInterface(data_width=dw, addr_width=aw)

    def _master(self, dw: int = 32, aw: int = 14) -> AvalonMMInterface:
        return AvalonMMInterface(data_width=dw, addr_width=aw, role=InterfaceRole.MASTER)

    def test_protocol_tag(self) -> None:
        assert self._slave().protocol == Protocol.AVALON_MM

    def test_signal_count(self) -> None:
        # 5 command + 4 response = 9 signals
        assert len(self._slave().get_signals()) == 9

    def test_address_width(self) -> None:
        iface = self._slave(aw=10)
        assert iface.address.width == 10

    def test_writedata_width(self) -> None:
        iface = self._slave(dw=64)
        assert iface.writedata.width == 64

    def test_byteenable_width(self) -> None:
        iface = self._slave(dw=32)
        assert iface.byteenable.width == 4

    def test_response_width(self) -> None:
        assert self._slave().response.width == 2

    def test_slave_address_is_input(self) -> None:
        assert self._slave().address.direction == Direction.INPUT

    def test_slave_waitrequest_is_output(self) -> None:
        assert self._slave().waitrequest.direction == Direction.OUTPUT

    def test_slave_readdata_is_output(self) -> None:
        assert self._slave().readdata.direction == Direction.OUTPUT

    def test_master_address_is_output(self) -> None:
        assert self._master().address.direction == Direction.OUTPUT

    def test_master_waitrequest_is_input(self) -> None:
        assert self._master().waitrequest.direction == Direction.INPUT

    def test_waitrequest_reset_val(self) -> None:
        # waitrequest defaults to 1 (stall until ready)
        assert self._slave().waitrequest.reset_val == 1

    def test_prefix(self) -> None:
        iface = AvalonMMInterface(data_width=32, addr_width=14, prefix="avmm")
        assert iface.address.name == "avmm_address"


# ===========================================================================
# NativeMemInterface
# ===========================================================================


class TestNativeMemInterface:
    def _master(self, dw: int = 32, aw: int = 14) -> NativeMemInterface:
        return NativeMemInterface(data_width=dw, addr_width=aw, role=InterfaceRole.MASTER)

    def _slave(self, dw: int = 32, aw: int = 14) -> NativeMemInterface:
        return NativeMemInterface(data_width=dw, addr_width=aw)

    def test_protocol_tag(self) -> None:
        assert self._master().protocol == Protocol.NATIVE_MEM

    def test_signal_count(self) -> None:
        # addr, din, we, re, cs, dout, ack = 7 signals
        assert len(self._master().get_signals()) == 7

    def test_addr_width(self) -> None:
        iface = self._master(aw=12)
        assert iface.addr.width == 12

    def test_we_width(self) -> None:
        iface = self._master(dw=32)
        assert iface.we.width == 4  # byte enables

    def test_master_addr_is_output(self) -> None:
        assert self._master().addr.direction == Direction.OUTPUT

    def test_master_dout_is_input(self) -> None:
        assert self._master().dout.direction == Direction.INPUT

    def test_slave_addr_is_input(self) -> None:
        assert self._slave().addr.direction == Direction.INPUT

    def test_slave_dout_is_output(self) -> None:
        assert self._slave().dout.direction == Direction.OUTPUT

    def test_prefix(self) -> None:
        iface = NativeMemInterface(data_width=32, addr_width=14, prefix="mem")
        assert iface.addr.name == "mem_addr"
        assert iface.dout.name == "mem_dout"


# ===========================================================================
# BusInterface.connect()
# ===========================================================================


class TestConnect:
    def test_axilite_connect_returns_assigns(self) -> None:
        slave = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s")
        master = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.MASTER, prefix="m")
        assigns = slave.connect(master)
        assert len(assigns) == 19
        for node in assigns:
            assert isinstance(node, Assign)

    def test_connect_different_types_raises(self) -> None:
        axi = AXILiteInterface(data_width=32, addr_width=16)
        nat = NativeMemInterface(data_width=32, addr_width=14)
        with pytest.raises(TypeError, match="Cannot connect"):
            axi.connect(nat)  # type: ignore[arg-type]

    def test_connect_targets_are_destination_signals(self) -> None:
        slave = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s")
        master = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.MASTER, prefix="m")
        assigns = slave.connect(master)
        target_names = {a.target.name for a in assigns}  # type: ignore[union-attr]
        # All targets should have the master prefix
        assert all(n.startswith("m_") for n in target_names)

    def test_native_mem_connect(self) -> None:
        src = NativeMemInterface(data_width=32, addr_width=14, role=InterfaceRole.MASTER, prefix="src")
        dst = NativeMemInterface(data_width=32, addr_width=14, role=InterfaceRole.SLAVE, prefix="dst")
        assigns = src.connect(dst)
        assert len(assigns) == 7


# ===========================================================================
# Integration: populate a Module with interface signals
# ===========================================================================


class TestModuleIntegration:
    def test_axilite_to_native_port_population(self) -> None:
        """Build a module with one AXI-Lite slave and one Native master."""
        from hdl_ast import Module

        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s_axi")
        nat = NativeMemInterface(data_width=32, addr_width=14, role=InterfaceRole.MASTER, prefix="mem")

        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)

        m = Module("axilite_to_native")
        m.add_port(clk)
        m.add_port(rst_n)
        for sig in axi.get_signals() + nat.get_signals():
            m.add_port(sig)

        # 2 clk/rst + 19 AXI-Lite + 7 Native = 28 ports
        assert len(m.ports) == 28

    def test_all_port_directions_valid(self) -> None:
        """Every port must be INPUT or OUTPUT (not LOCAL)."""
        from hdl_ast import Module

        axi = AXILiteInterface(data_width=32, addr_width=16, role=InterfaceRole.SLAVE, prefix="s_axi")
        nat = NativeMemInterface(data_width=32, addr_width=14, role=InterfaceRole.MASTER, prefix="mem")

        m = Module("dut")
        for sig in axi.get_signals() + nat.get_signals():
            m.add_port(sig)

        for port in m.ports:
            assert port.direction != Direction.LOCAL, f"Port {port.name!r} has direction LOCAL"
