# AXI-Lite ↔ Avalon-MM Bridge FSM — Implementation Plan

> Generate the **Logic Layer** that wires an AXI-Lite slave interface to an Avalon-MM master interface, producing fully synthesizable RTL through the existing AST → Emitter pipeline.

## Current Pipeline Scorecard

| Component | File | Tests | Status |
|-----------|------|-------|--------|
| AXI-Lite Interface | [bus_interfaces.py](file:///tools/bridge-gen/bus_interfaces.py) | 51 | ✅ Done |
| Avalon-MM Interface | [bus_interfaces.py](file:///tools/bridge-gen/bus_interfaces.py) | 51 | ✅ Done |
| Native Mem Interface | [bus_interfaces.py](file:///tools/bridge-gen/bus_interfaces.py) | 51 | ✅ Done |
| HDL AST | [hdl_ast.py](file:///tools/bridge-gen/hdl_ast.py) | 72 | ✅ Done |
| Validator | [validator.py](file:///tools/bridge-gen/validator.py) | 56 | ✅ Done |
| Pipeline Stages | [pipeline.py](file:///tools/bridge-gen/pipeline.py) | 36 | ✅ Done |
| SV Emitter | [emitter_sv.py](file:///tools/bridge-gen/emitter_sv.py) | — | ✅ Done |
| VHDL Emitter | [emitter_vhdl.py](file:///tools/bridge-gen/emitter_vhdl.py) | — | ✅ Done |
| CLI + Pre-Elab | [main.py](file:///tools/bridge-gen/main.py) | — | ✅ Done |
| Avalon-MM BFM | [avalon_mm.py](file:///sim/cocotb/tb/drivers/avalon_mm.py) | 14 | ✅ Done |
| AXI-Lite BFM | [axi_lite.py](file:///sim/cocotb/tb/drivers/axi_lite.py) | — | ✅ Done |
| **Bridge Logic Layer** | `bridge_logic.py` | 0 | 🔴 **This plan** |

---

## Protocol Mapping

### Signal Map: AXI-Lite Slave → Avalon-MM Master

| AXI-Lite (slave) | Dir | Avalon-MM (master) | Dir | Bridge Role |
|-------------------|-----|---------------------|-----|-------------|
| `awaddr` | IN | `address` | OUT | Write addr transform (byte → word) |
| `awvalid` | IN | — | — | FSM trigger |
| `awready` | OUT | — | — | FSM-driven |
| `wdata` | IN | `writedata` | OUT | Direct map |
| `wstrb` | IN | `byteenable` | OUT | Direct map |
| `wvalid` | IN | `write` | OUT | FSM-driven |
| `wready` | OUT | — | — | FSM-driven |
| `bresp` | OUT | `response` | IN | Error map (see below) |
| `bvalid` | OUT | — | — | FSM-driven |
| `bready` | IN | — | — | FSM gate |
| `araddr` | IN | `address` | OUT | Read addr transform |
| `arvalid` | IN | `read` | OUT | FSM-driven |
| `arready` | OUT | — | — | FSM-driven |
| `rdata` | OUT | `readdata` | IN | Direct map |
| `rresp` | OUT | `response` | IN | Error map |
| `rvalid` | OUT | `readdatavalid` | IN | Direct map |
| `rready` | IN | — | — | FSM gate |
| — | — | `waitrequest` | IN | FSM stall |

### Address Transformation

AXI-Lite uses **byte addresses**; Avalon-MM uses **word addresses**. The bridge strips the lower `log₂(data_width/8)` bits:

```
avalon_address = axi_addr >> log2(data_width / 8)
```

For 32-bit data: `avalon_address = axi_addr[addr_width-1 : 2]` (strip 2 LSBs).

### Error Response Mapping

| AXI BRESP/RRESP | Value | Avalon Response | Value |
|------------------|-------|-----------------|-------|
| OKAY | `2'b00` | OKAY | `2'b00` |
| SLVERR | `2'b10` | SLVERR | `2'b10` |
| DECERR | `2'b11` | DECERR | `2'b11` |

> [!TIP]
> Encoding is identical — direct assignment, no translation needed.

---

## FSM Design

### State Diagram

```mermaid
stateDiagram-v2
    [*] --> IDLE

    IDLE --> WR_ACCEPT : awvalid & wvalid
    IDLE --> RD_ACCEPT : arvalid & !awvalid

    WR_ACCEPT --> WR_AVALON : immediate
    WR_AVALON --> WR_RESP : !waitrequest
    WR_RESP --> IDLE : bready

    RD_ACCEPT --> RD_AVALON : immediate
    RD_AVALON --> RD_WAIT : !waitrequest
    RD_WAIT --> RD_RESP : readdatavalid
    RD_RESP --> IDLE : rready
```

### State Table

| State | AXI Outputs | Avalon Outputs | Transition |
|-------|-------------|----------------|------------|
| **IDLE** | All ready/valid=0 | write=0, read=0 | awvalid & wvalid → WR_ACCEPT; arvalid → RD_ACCEPT |
| **WR_ACCEPT** | awready=1, wready=1 | — | → WR_AVALON (combinational, same cycle) |
| **WR_AVALON** | — | write=1, address=addr, writedata=data, byteenable=strb | !waitrequest → WR_RESP |
| **WR_RESP** | bvalid=1, bresp=response | write=0 | bready → IDLE |
| **RD_ACCEPT** | arready=1 | — | → RD_AVALON |
| **RD_AVALON** | — | read=1, address=addr | !waitrequest → RD_WAIT |
| **RD_WAIT** | — | read=0 | readdatavalid → RD_RESP |
| **RD_RESP** | rvalid=1, rdata=readdata, rresp=response | — | rready → IDLE |

### Internal Registers

| Register | Width | Purpose |
|----------|-------|---------|
| `state` | 3 | FSM state (8 states) |
| `addr_reg` | addr_width | Latched AXI address (byte-aligned) |
| `wdata_reg` | data_width | Latched write data |
| `wstrb_reg` | data_width/8 | Latched write strobes |
| `rdata_reg` | data_width | Captured read data |
| `resp_reg` | 2 | Captured Avalon response |

> [!IMPORTANT]
> Writes require **both** `awvalid` and `wvalid` before proceeding. This simplifies the FSM (no need for separate AW-only or W-only states). AXI-Lite spec allows this — the master must present both channels simultaneously or in any order, but the slave can wait for both.

---

## Proposed Changes

### Logic Layer

#### [NEW] [bridge_logic.py](file:///tools/bridge-gen/bridge_logic.py)

The core FSM population function. Pattern follows the existing `pipeline.py` approach:

```python
def build_axilite_to_avalon(
    axi: AXILiteInterface,
    avl: AvalonMMInterface,
    clk: Signal,
    rst: Signal,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
) -> Tuple[List[Signal], List[HdlNode]]:
    """Populate a Module with AXI-Lite → Avalon-MM bridge logic.

    Returns
    -------
    internal_signals:
        State register + latching registers (add to module via add_signal).
    body_nodes:
        Always blocks + combinational assigns (add to module via add_block).
    """
```

The function:

1. Creates internal registers (`state`, `addr_reg`, `wdata_reg`, etc.)
2. Builds a single clocked `Always` block with `If(reset)` → `Case(state)` structure
3. Each case branch drives outputs via `NonBlockingAssign`
4. Returns signals + blocks for the caller to add to the `Module`

---

### CLI Integration

#### [MODIFY] [main.py](file:///tools/bridge-gen/main.py)

- Add `--target-protocol` argument (choices: `native`, `avalon`)
- When `--protocol=axilite --target-protocol=avalon` is specified, call `build_axilite_to_avalon()` to populate the module body
- Update `_build_module()` to create **both** interfaces and invoke the logic layer
- Add second interface ports to the module

---

### Tests

#### [NEW] [test_bridge_logic.py](file:///tools/bridge-gen/test_bridge_logic.py)

Unit tests for the FSM AST construction:

| Test Group | Description |
|------------|-------------|
| `TestBuildAxiLiteToAvalon` | Basic: produces signals + always blocks, correct state count |
| `TestFSMStates` | All 8 states present in Case branches |
| `TestSignalWidths` | Internal registers match data_width / addr_width params |
| `TestAddressTransform` | Slice uses correct bit range for word address |
| `TestRoundTrip` | Build → Validate → Emit to SV string → grep for key RTL patterns |
| `TestResetBehavior` | Sync vs async reset, active-low vs active-high |
| `TestParameterization` | 32-bit and 64-bit data widths produce correct strobe widths |

---

### End-to-End Cocotb Test (Phase 2)

> [!NOTE]
> This is a follow-up after the logic layer is solid. Requires emitting actual VHDL, compiling with NVC, and running the AXI-Lite + Avalon-MM BFMs against it.

#### [NEW] `test_bridge_e2e.py`

- Generate bridge VHDL via `bridge_logic.py` + `VHDLEmitter`
- Instantiate `AXILiteMaster` (existing BFM) as initiator
- Instantiate `AvalonMMSlave` (existing BFM) as target
- Write 16 words, read back, assert data integrity
- Test with `waitrequest_cycles > 0` to validate backpressure propagation

---

## Implementation Scorecard

| Deliverable | Priority | Est. Effort | Dependencies |
|-------------|----------|-------------|--------------|
| `bridge_logic.py` | **P0** | Medium | `hdl_ast`, `bus_interfaces` |
| `test_bridge_logic.py` | **P0** | Medium | `bridge_logic.py` |
| `main.py` CLI wiring | **P1** | Small | `bridge_logic.py` |
| `test_main.py` updates | **P1** | Small | CLI wiring |
| Cocotb E2E test | **P2** | Large | All above + BFMs + emitter |
| Design doc update | **P1** | Small | — |

---

## Verification Plan

### Automated Tests

1. `python -m pytest test_bridge_logic.py -v` — FSM AST unit tests
2. `python -m pytest test_main.py -v` — CLI integration
3. `python -m pytest test_validator.py -v` — existing validator still green
4. Full regression via pre-commit hook

### Manual Verification

- Inspect emitted SV/VHDL for correct RTL structure
- Review FSM state coverage in emitted output
