# RTL Bridge Generator — Pipeline / Register Slice Builder

> Timing strategy layer: inserts flip-flop stages between signals to
> break long combinational paths and improve timing closure.

---

## Concept

A **register slice** (also called a pipeline stage or retiming register)
is a row of flip-flops that samples a set of signals on a clock edge and
presents them one cycle later.  Inserting register slices between the
AXI master and the native memory slave:

1. Breaks the combinational path across the bridge.
2. Allows the place-and-route tool to meet timing at higher frequencies.
3. Adds exactly **N cycles of latency** for N stages.

```
Master ──[AXI signals]──► Stage 0 ──► Stage 1 ──► ... ──► Slave
                           (s1)        (s2)
```

---

## Usage

```python
from pipeline import RegisterSliceBuilder
from hdl_ast import ResetStyle, Direction, Signal, Edge

clk   = Signal("clk",   direction=Direction.INPUT)
rst_n = Signal("rst_n", direction=Direction.INPUT)

# Signals to pipeline (e.g. AXI write-address channel)
sigs = [axi.awaddr, axi.awvalid, axi.awprot]

builder = RegisterSliceBuilder(
    signals=sigs,
    stages=2,
    clk=clk,
    rst_n=rst_n,
    reset_style=ResetStyle.ASYNC,
    active_low_reset=True,
)

inter_sigs, always_blocks = builder.build()

# Add to module
for sig in inter_sigs:
    module.add_signal(sig)
for blk in always_blocks:
    module.add_block(blk)

# Connect downstream logic to the final stage outputs
final_awaddr  = builder.outputs[0]   # awaddr_s2
final_awvalid = builder.outputs[1]   # awvalid_s2
```

---

## Signal Naming Convention

For a signal named `awaddr` with `stages=2`:

| Stage | Signal name | Direction |
|-------|-------------|-----------|
| Source | `awaddr` | (original) |
| Stage 1 | `awaddr_s1` | `LOCAL` |
| Stage 2 | `awaddr_s2` | `LOCAL` |

`builder.outputs` always returns the **last stage** signals.

---

## Generated RTL (SystemVerilog)

For `stages=1`, `reset_style=ASYNC`, `active_low_reset=True`:

```systemverilog
always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        awaddr_s1  <= '0;
        awvalid_s1 <= 1'b0;
    end else begin
        awaddr_s1  <= awaddr;
        awvalid_s1 <= awvalid;
    end
end
```

For VHDL output (synchronous reset):

```vhdl
process(clk) begin
    if rising_edge(clk) then
        if rst_n = '0' then
            awaddr_s1  <= (others => '0');
            awvalid_s1 <= '0';
        else
            awaddr_s1  <= awaddr;
            awvalid_s1 <= awvalid;
        end if;
    end if;
end process;
```

---

## `PipelineStage` Descriptor

After calling `build()`, inspect each stage via `builder.pipeline_stages`:

```python
for stage in builder.pipeline_stages:
    print(stage.stage_id)      # 0, 1, ...
    print(stage.inputs)        # List[Signal] — stage inputs
    print(stage.outputs)       # List[Signal] — stage outputs (LOCAL)
    print(stage.always_block)  # Always node
```

---

## Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `signals` | `List[Signal]` | — | Signals to pipeline |
| `stages` | `int` | — | Number of register stages (0 = pass-through) |
| `clk` | `Signal` | — | Clock signal |
| `rst_n` | `Optional[Signal]` | `None` | Reset signal (omit for no reset) |
| `reset_style` | `ResetStyle` | `SYNC` | Synchronous or asynchronous reset |
| `active_low_reset` | `bool` | `True` | Active-low (`!rst_n`) or active-high (`rst`) |

---

## Timing Guidance

| Scenario | Recommended stages |
|----------|--------------------|
| Same-die, short path | 0 (no pipeline) |
| Moderate path (< 10 ns slack) | 1 |
| Cross-die or high-frequency (> 250 MHz) | 2 |
| Ultra-high-frequency (> 500 MHz) | 3+ |

> [!NOTE]
> Each stage adds **one clock cycle of latency** to the bridge response.
> For AXI-Lite, this means the read/write response arrives N cycles later.
> Ensure the AXI master supports the additional latency (most do via the
> handshake mechanism).

> [!TIP]
> Pipeline only the **critical path** signals (typically address and data
> buses).  Control signals like `valid`/`ready` can often be left
> un-pipelined or pipelined separately with a different stage count.
