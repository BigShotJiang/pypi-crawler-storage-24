# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_hdl_ast.py — Unit tests for the RTL Hardware AST
=====================================================

Run with:
    python -m pytest sdk/generators/bridge/test_hdl_ast.py -v
"""

import pytest
from hdl_ast import (
    Always,
    Assign,
    Case,
    Concat,
    Direction,
    Edge,
    HdlNode,
    If,
    Module,
    NodeVisitor,
    NonBlockingAssign,
    ResetStyle,
    Signal,
    Slice,
    Ternary,
)

# ===========================================================================
# Signal
# ===========================================================================


class TestSignal:
    def test_defaults(self) -> None:
        s = Signal("clk")
        assert s.name == "clk"
        assert s.width == 1
        assert s.direction == Direction.LOCAL
        assert s.reset_val == 0

    def test_explicit_fields(self) -> None:
        s = Signal("awaddr", width=32, direction=Direction.INPUT, reset_val=0xDEAD)
        assert s.width == 32
        assert s.direction == Direction.INPUT
        assert s.reset_val == 0xDEAD

    def test_invalid_width(self) -> None:
        with pytest.raises(ValueError, match="width must be >= 1"):
            Signal("bad", width=0)

    def test_repr(self) -> None:
        s = Signal("x", width=8, direction=Direction.OUTPUT)
        assert "x" in repr(s)
        assert "8" in repr(s)

    def test_equality(self) -> None:
        a = Signal("x", width=4, direction=Direction.INPUT)
        b = Signal("x", width=4, direction=Direction.INPUT)
        assert a == b

    def test_inequality(self) -> None:
        a = Signal("x", width=4)
        b = Signal("x", width=8)
        assert a != b

    def test_hashable(self) -> None:
        s = Signal("x")
        assert hash(s) == hash(Signal("x"))
        d = {s: "value"}
        assert d[Signal("x")] == "value"

    def test_iter(self) -> None:
        s = Signal("data", width=4)
        bits = list(s)
        assert len(bits) == 4
        # MSB first
        assert bits[0].msb == 3
        assert bits[-1].lsb == 0


# ===========================================================================
# Slice
# ===========================================================================


class TestSlice:
    def test_single_bit_index(self) -> None:
        s = Signal("data", width=8)
        sl = s[3]
        assert isinstance(sl, Slice)
        assert sl.msb == 3
        assert sl.lsb == 3
        assert sl.width == 1

    def test_range_slice(self) -> None:
        s = Signal("data", width=32)
        sl = s[15:0]
        assert sl.msb == 15
        assert sl.lsb == 0
        assert sl.width == 16

    def test_msb_lt_lsb_raises(self) -> None:
        s = Signal("data", width=8)
        with pytest.raises(ValueError, match="MSB"):
            Slice(s, 0, 7)

    def test_step_raises(self) -> None:
        s = Signal("data", width=8)
        with pytest.raises(ValueError, match="step"):
            _ = s[7:0:1]

    def test_repr_single(self) -> None:
        s = Signal("x", width=4)
        assert repr(s[2]) == "x[2]"

    def test_repr_range(self) -> None:
        s = Signal("x", width=8)
        assert repr(s[7:0]) == "x[7:0]"

    def test_bad_index_type(self) -> None:
        s = Signal("x")
        with pytest.raises(TypeError):
            _ = s["bad"]  # type: ignore[index]


# ===========================================================================
# Expression nodes
# ===========================================================================


class TestConcat:
    def test_basic(self) -> None:
        a = Signal("a", width=4)
        b = Signal("b", width=4)
        c = Concat(a, b)
        assert len(c.parts) == 2
        r = repr(c)
        assert r.startswith("{") and r.endswith("}")
        assert "a" in r
        assert "b" in r

    def test_is_hdl_node(self) -> None:
        assert isinstance(Concat(Signal("x")), HdlNode)


class TestTernary:
    def test_basic(self) -> None:
        cond = Signal("sel")
        t = Ternary(cond, "8'hFF", "8'h00")
        assert t.condition is cond
        assert t.true_val == "8'hFF"
        assert t.false_val == "8'h00"

    def test_repr(self) -> None:
        t = Ternary("a", "b", "c")
        assert "?" in repr(t)
        assert ":" in repr(t)


# ===========================================================================
# Module
# ===========================================================================


class TestModule:
    def _make_module(self) -> Module:
        return Module("dut")

    def test_empty_module(self) -> None:
        m = self._make_module()
        assert m.name == "dut"
        assert m.ports == []
        assert m.signals == []
        assert m.body == []

    def test_add_port(self) -> None:
        m = self._make_module()
        clk = Signal("clk", direction=Direction.INPUT)
        m.add_port(clk)
        assert clk in m.ports

    def test_add_local_as_port_raises(self) -> None:
        m = self._make_module()
        with pytest.raises(ValueError, match="LOCAL"):
            m.add_port(Signal("internal"))

    def test_add_signal(self) -> None:
        m = self._make_module()
        sig = Signal("state", width=2)
        m.add_signal(sig)
        assert sig in m.signals

    def test_add_port_as_signal_raises(self) -> None:
        m = self._make_module()
        with pytest.raises(ValueError, match="port"):
            m.add_signal(Signal("out", direction=Direction.OUTPUT))

    def test_chaining(self) -> None:
        m = (
            Module("dut")
            .add_port(Signal("clk", direction=Direction.INPUT))
            .add_port(Signal("q", direction=Direction.OUTPUT))
            .add_signal(Signal("cnt", width=4))
        )
        assert len(m.ports) == 2
        assert len(m.signals) == 1

    def test_add_block(self) -> None:
        m = self._make_module()
        a = Assign(Signal("x", direction=Direction.OUTPUT), 0)
        m.add_block(a)
        assert a in m.body

    def test_repr(self) -> None:
        m = Module("foo")
        assert "foo" in repr(m)


# ===========================================================================
# Assign
# ===========================================================================


class TestAssign:
    def test_signal_target(self) -> None:
        target = Signal("q", direction=Direction.OUTPUT)
        a = Assign(target, "1'b1")
        assert a.target is target
        assert a.source == "1'b1"

    def test_slice_target(self) -> None:
        s = Signal("data", width=8, direction=Direction.OUTPUT)
        a = Assign(s[3:0], "4'hF")
        assert isinstance(a.target, Slice)

    def test_repr(self) -> None:
        s = Signal("x", direction=Direction.OUTPUT)
        a = Assign(s, 0)
        assert "Assign" in repr(a)


# ===========================================================================
# NonBlockingAssign
# ===========================================================================


class TestNonBlockingAssign:
    def test_basic(self) -> None:
        s = Signal("q", direction=Direction.OUTPUT)
        nb = NonBlockingAssign(s, 0)
        assert nb.target is s
        assert nb.source == 0

    def test_repr(self) -> None:
        s = Signal("q", direction=Direction.OUTPUT)
        assert "<=" in repr(NonBlockingAssign(s, 1))


# ===========================================================================
# Always
# ===========================================================================


class TestAlways:
    def test_clocked(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        rst = Signal("rst_n", direction=Direction.INPUT)
        blk = Always([(Edge.POSEDGE, clk), (Edge.NEGEDGE, rst)])
        assert len(blk.sensitivity) == 2

    def test_combinational(self) -> None:
        blk = Always([(Edge.LEVEL, None)])
        assert blk.sensitivity[0] == (Edge.LEVEL, None)

    def test_add_statement_chaining(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        q = Signal("q", direction=Direction.OUTPUT)
        blk = Always([(Edge.POSEDGE, clk)]).add_statement(NonBlockingAssign(q, 0))
        assert len(blk.body) == 1

    def test_repr(self) -> None:
        clk = Signal("clk", direction=Direction.INPUT)
        blk = Always([(Edge.POSEDGE, clk)])
        assert "posedge" in repr(blk)


# ===========================================================================
# If
# ===========================================================================


class TestIf:
    def test_basic(self) -> None:
        rst = Signal("rst_n", direction=Direction.INPUT)
        q = Signal("q", direction=Direction.OUTPUT)
        node = If(
            condition=f"!{rst.name}",
            then_body=[NonBlockingAssign(q, 0)],
            else_body=[NonBlockingAssign(q, 1)],
        )
        assert len(node.then_body) == 1
        assert len(node.else_body) == 1

    def test_no_else(self) -> None:
        node = If("valid", then_body=[Assign(Signal("x", direction=Direction.OUTPUT), 1)])
        assert node.else_body == []

    def test_repr(self) -> None:
        node = If("cond")
        assert "If" in repr(node)


# ===========================================================================
# Case
# ===========================================================================


class TestCase:
    def test_basic(self) -> None:
        state = Signal("state", width=2)
        q = Signal("q", direction=Direction.OUTPUT)
        node = Case(
            selector=state,
            branches=[
                (0, [NonBlockingAssign(q, 0)]),
                (1, [NonBlockingAssign(q, 1)]),
                (None, [NonBlockingAssign(q, 0)]),  # default
            ],
        )
        assert len(node.branches) == 3

    def test_add_branch_chaining(self) -> None:
        s = Signal("s", width=2)
        q = Signal("q", direction=Direction.OUTPUT)
        node = Case(s).add_branch(0, [NonBlockingAssign(q, 0)]).add_branch(None, [NonBlockingAssign(q, 1)])
        assert len(node.branches) == 2

    def test_repr(self) -> None:
        s = Signal("s")
        assert "Case" in repr(Case(s))


# ===========================================================================
# NodeVisitor
# ===========================================================================


class TestNodeVisitor:
    def test_visit_dispatches(self) -> None:
        visited: list = []

        class Collector(NodeVisitor):
            def visit_Signal(self, node: Signal) -> None:
                visited.append(node.name)

        clk = Signal("clk", direction=Direction.INPUT)
        q = Signal("q", direction=Direction.OUTPUT)
        m = Module("dut", ports=[clk, q])

        Collector().visit(m)
        assert "clk" in visited
        assert "q" in visited

    def test_generic_visit_recurses_into_body(self) -> None:
        visited_types: list = []

        class TypeCollector(NodeVisitor):
            def generic_visit(self, node: HdlNode) -> None:
                visited_types.append(type(node).__name__)
                super().generic_visit(node)

        clk = Signal("clk", direction=Direction.INPUT)
        q = Signal("q", direction=Direction.OUTPUT)
        nb = NonBlockingAssign(q, 0)
        blk = Always([(Edge.POSEDGE, clk)], body=[nb])
        m = Module("dut", ports=[clk, q], body=[blk])

        TypeCollector().visit(m)
        assert "Module" in visited_types
        assert "Always" in visited_types
        assert "NonBlockingAssign" in visited_types

    def test_visitor_collects_all_signals(self) -> None:
        """Integration: build a small module and collect every Signal name."""
        names: list = []

        class SignalCollector(NodeVisitor):
            def visit_Signal(self, node: Signal) -> None:
                names.append(node.name)

        clk = Signal("clk", direction=Direction.INPUT)
        rst = Signal("rst_n", direction=Direction.INPUT)
        q = Signal("q", width=8, direction=Direction.OUTPUT)
        state = Signal("state", width=2)

        m = Module("dut", ports=[clk, rst, q], signals=[state])
        SignalCollector().visit(m)

        assert set(names) == {"clk", "rst_n", "q", "state"}

    def test_accept_is_hdl_node_method(self) -> None:
        """Every concrete node must be an HdlNode."""
        nodes: list[HdlNode] = [
            Signal("x"),
            Slice(Signal("x", width=4), 3, 0),
            Concat(Signal("a"), Signal("b")),
            Ternary("c", "t", "f"),
            Module("m"),
            Assign(Signal("x", direction=Direction.OUTPUT), 0),
            NonBlockingAssign(Signal("x", direction=Direction.OUTPUT), 0),
            Always([]),
            If("cond"),
            Case(Signal("s")),
        ]
        for node in nodes:
            assert isinstance(node, HdlNode), f"{type(node).__name__} is not HdlNode"


# ===========================================================================
# Enumerations
# ===========================================================================


class TestEnumerations:
    def test_direction_values(self) -> None:
        assert Direction.INPUT.value == "input"
        assert Direction.OUTPUT.value == "output"
        assert Direction.LOCAL.value == "local"

    def test_edge_values(self) -> None:
        assert Edge.POSEDGE.value == "posedge"
        assert Edge.NEGEDGE.value == "negedge"

    def test_reset_style(self) -> None:
        assert ResetStyle.SYNC.value == "sync"
        assert ResetStyle.ASYNC.value == "async"


# ===========================================================================
# Integration: build a minimal flip-flop module
# ===========================================================================


class TestIntegration:
    def test_dff_module(self) -> None:
        """Build a D flip-flop module tree and verify its structure."""
        clk = Signal("clk", direction=Direction.INPUT)
        rst_n = Signal("rst_n", direction=Direction.INPUT)
        d = Signal("d", direction=Direction.INPUT)
        q = Signal("q", direction=Direction.OUTPUT)

        always_block = Always(
            sensitivity=[(Edge.POSEDGE, clk), (Edge.NEGEDGE, rst_n)],
            body=[
                If(
                    condition="!rst_n",
                    then_body=[NonBlockingAssign(q, 0)],
                    else_body=[NonBlockingAssign(q, d)],
                )
            ],
        )

        dff = Module("dff").add_port(clk).add_port(rst_n).add_port(d).add_port(q).add_block(always_block)

        assert dff.name == "dff"
        assert len(dff.ports) == 4
        assert len(dff.body) == 1
        assert isinstance(dff.body[0], Always)
        assert isinstance(dff.body[0].body[0], If)

    def test_fsm_case_module(self) -> None:
        """Build a 2-state FSM using Case and verify branch count."""
        clk = Signal("clk", direction=Direction.INPUT)
        state = Signal("state", width=1)
        next_state = Signal("next_state", width=1)

        case_node = (
            Case(state)
            .add_branch(0, [NonBlockingAssign(next_state, 1)])
            .add_branch(1, [NonBlockingAssign(next_state, 0)])
            .add_branch(None, [NonBlockingAssign(next_state, 0)])
        )

        blk = Always([(Edge.POSEDGE, clk)], body=[case_node])
        m = Module("fsm", ports=[clk], signals=[state, next_state], body=[blk])

        assert len(m.body[0].body[0].branches) == 3  # type: ignore[attr-defined]
