# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
validator.py — RTL Bridge Generator Validator
==============================================

Pre-emission sanity checker for the hardware AST.

The ``Validator`` class walks a ``Module`` tree and raises ``ValidationError``
(a subclass of ``ValueError``) when it detects structural problems.  It is
designed to run *before* the Verilog/VHDL emitter so that errors are reported
in Python terms (signal names, interface names) rather than as cryptic
synthesis failures.

Five checks are implemented:

1. **Width Check** — every ``Assign`` / ``NonBlockingAssign`` LHS and RHS
   must have the same bit-width.

2. **Handshake Check** — for every ``AXILiteInterface`` attached to a module,
   all ``valid`` and ``ready`` signals must appear at least once inside a
   logic block body (no floating handshakes).

3. **Address Bounds Check** — verifies that the AXI/Avalon address range
   described by an ``AddressMap`` does not exceed the physical capacity of
   the ``NativeMemInterface`` it is paired with.

4. **SVA Injector** — generates a list of ``SvaProperty`` nodes (a thin
   wrapper around a string) that an emitter can optionally append to the
   module as SystemVerilog Assertions for AXI protocol compliance.

5. **Waitrequest Check** — for every ``AvalonMMInterface``, verifies that
   flow-control signals (``waitrequest``, ``read``, ``write``,
   ``readdatavalid``) are used in logic blocks (no floating handshakes).

Integration into the generation flow::

    module = build_axilite_to_native(axi, nat, addr_map)

    v = Validator(module)
    v.check_widths()
    v.check_handshakes([axi])
    v.check_address_bounds(addr_map, nat)
    sva_props = v.inject_sva(axi)   # returns List[SvaProperty]

    # Emitter picks up sva_props if --sva flag is set
    emit_systemverilog(module, sva_properties=sva_props)

Pipeline position:
    Logic Layer → [THIS MODULE] → Backend (Emitter)
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional, Set, Tuple

from addr_map import AddressMap
from bus_interfaces import AvalonMMInterface, AXILiteInterface, NativeMemInterface
from hdl_ast import (
    Always,
    Assign,
    Case,
    HdlNode,
    If,
    Module,
    NodeVisitor,
    NonBlockingAssign,
    Signal,
    Slice,
)

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class ValidationError(ValueError):
    """Raised when the AST fails a pre-emission sanity check.

    Attributes
    ----------
    check:
        Name of the check that failed (e.g. ``"width"``, ``"handshake"``).
    details:
        List of human-readable problem descriptions.
    """

    def __init__(self, check: str, details: List[str]) -> None:
        """Create a validation error with check name and detail messages."""
        self.check = check
        self.details = details
        bullet_list = "\n  • ".join(details)
        super().__init__(f"[{check}] Validation failed:\n  • {bullet_list}")


# ---------------------------------------------------------------------------
# SVA Property node
# ---------------------------------------------------------------------------


@dataclass
class SvaProperty:
    """A single SystemVerilog Assertion property.

    Attributes
    ----------
    name:
        Identifier for the property (used as the assertion label).
    body:
        The raw SVA string (everything between ``property … endproperty``).
    severity:
        ``"assert"`` (hard failure) or ``"assume"`` (formal tool hint).
    comment:
        Optional human-readable description emitted above the property.
    """

    name: str
    body: str
    severity: str = "assert"
    comment: str = ""

    def render(self, indent: int = 4) -> str:
        """Render the property as a SystemVerilog string."""
        pad = " " * indent
        lines: List[str] = []
        if self.comment:
            lines.append(f"{pad}// {self.comment}")
        lines.append(f"{pad}property {self.name};")
        for line in self.body.strip().splitlines():
            lines.append(f"{pad}  {line.strip()}")
        lines.append(f"{pad}endproperty")
        lines.append(f"{pad}{self.severity} property {self.name};")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Internal visitors
# ---------------------------------------------------------------------------


class _AssignmentCollector(NodeVisitor):
    """Collect every Assign / NonBlockingAssign in the module tree."""

    def __init__(self) -> None:
        """Initialize the assignment collector."""
        self.assignments: List[Tuple[HdlNode, str]] = []
        # (node, context_description)

    def visit_Assign(self, node: Assign) -> None:
        """Record a continuous assignment node."""
        self.assignments.append((node, "assign"))

    def visit_NonBlockingAssign(self, node: NonBlockingAssign) -> None:
        """Record a non-blocking assignment node."""
        self.assignments.append((node, "<="))

    def generic_visit(self, node: HdlNode) -> None:
        """Recursively visit child nodes."""
        super().generic_visit(node)


class _SignalUsageCollector(NodeVisitor):
    """Collect the names of all signals referenced inside logic block bodies."""

    def __init__(self) -> None:
        """Initialize the signal usage collector."""
        self._in_body = False
        self.used_in_body: Set[str] = set()

    def visit_Always(self, node: Always) -> None:
        """Enter an always block and collect signal usage."""
        old = self._in_body
        self._in_body = True
        for stmt in node.body:
            self.visit(stmt)
        self._in_body = old

    def visit_Assign(self, node: Assign) -> None:
        """Record signals used in a continuous assignment."""
        if self._in_body:
            self._record(node.target)
            self._record_expr(node.source)
        else:
            # Continuous assign — still counts as "used"
            self._record(node.target)
            self._record_expr(node.source)

    def visit_NonBlockingAssign(self, node: NonBlockingAssign) -> None:
        """Record signals used in a non-blocking assignment."""
        self._record(node.target)
        self._record_expr(node.source)

    def visit_If(self, node: If) -> None:
        """Record signals used in conditional branch expressions."""
        self._record_expr(node.condition)
        for stmt in node.then_body:
            self.visit(stmt)
        for stmt in node.else_body:
            self.visit(stmt)

    def visit_Case(self, node: Case) -> None:
        """Record signals used in case statement selectors."""
        self._record_expr(node.selector)
        for _val, body in node.branches:
            for stmt in body:
                self.visit(stmt)

    def _record(self, target: object) -> None:
        if isinstance(target, Signal):
            self.used_in_body.add(target.name)
        elif isinstance(target, Slice):
            self.used_in_body.add(target.signal.name)

    def _record_expr(self, expr: object) -> None:
        if isinstance(expr, Signal):
            self.used_in_body.add(expr.name)
        elif isinstance(expr, Slice):
            self.used_in_body.add(expr.signal.name)
        elif isinstance(expr, str):
            # Extract identifiers from string expressions (e.g. "awaddr - 0x1000")
            for token in re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", expr):
                self.used_in_body.add(token)

    def generic_visit(self, node: HdlNode) -> None:
        """Recursively visit child nodes."""
        super().generic_visit(node)


def _get_width(expr: object) -> Optional[int]:
    """Return the bit-width of an expression node, or None if unknown."""
    if isinstance(expr, Signal):
        return expr.width
    if isinstance(expr, Slice):
        return expr.width
    if isinstance(expr, int):
        return None  # literal — width is context-dependent
    if isinstance(expr, str):
        return None  # raw string expression — width unknown statically
    return None


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------


class Validator:
    """Pre-emission sanity checker for a hardware ``Module`` AST.

    Parameters
    ----------
    module:
        The ``Module`` node to validate.  All checks operate on this tree.

    Usage::

        v = Validator(module)
        v.check_widths()
        v.check_handshakes([axi_iface])
        v.check_address_bounds(addr_map, native_iface)
        sva = v.inject_sva(axi_iface)
    """

    def __init__(self, module: Module) -> None:
        """Create a validator for the given module AST."""
        self.module = module

    # ------------------------------------------------------------------
    # Check 1 — Width Check
    # ------------------------------------------------------------------

    def check_widths(self) -> None:
        """Traverse all assignment nodes and verify LHS/RHS width compatibility.

        A width mismatch is flagged when *both* sides have a statically known
        width and those widths differ.  Assignments where one side is a raw
        string expression or integer literal are skipped (width is unknown).

        Raises
        ------
        ValidationError
            If any width mismatches are found.  All mismatches are collected
            before raising so the caller sees the full list at once.
        """
        collector = _AssignmentCollector()
        collector.visit(self.module)

        problems: List[str] = []
        for node, ctx in collector.assignments:
            target = node.target  # type: ignore[union-attr]
            source = node.source  # type: ignore[union-attr]

            lhs_w = _get_width(target)
            rhs_w = _get_width(source)

            if lhs_w is not None and rhs_w is not None and lhs_w != rhs_w:
                lhs_name = target.name if isinstance(target, Signal) else repr(target)
                problems.append(f"{ctx}: '{lhs_name}' is {lhs_w} bits wide but source is {rhs_w} bits wide")

        if problems:
            raise ValidationError("width", problems)

    # ------------------------------------------------------------------
    # Check 2 — Handshake Check
    # ------------------------------------------------------------------

    def check_handshakes(self, interfaces: List[AXILiteInterface]) -> None:
        """Verify that AXI valid/ready signals are used in logic blocks.

        For each ``AXILiteInterface``, checks that every ``*valid`` and
        ``*ready`` signal appears at least once in an assignment target or
        condition within the module body.  A signal that is declared as a
        port but never driven or read is a "floating handshake" — a common
        source of protocol deadlocks.

        Parameters
        ----------
        interfaces:
            List of ``AXILiteInterface`` objects whose handshake signals
            should be verified.

        Raises
        ------
        ValidationError
            If any handshake signal is unused.
        """
        usage = _SignalUsageCollector()
        usage.visit(self.module)

        # AXI-Lite handshake signal short-names
        HANDSHAKE_SHORTS = {
            "awvalid",
            "awready",
            "wvalid",
            "wready",
            "bvalid",
            "bready",
            "arvalid",
            "arready",
            "rvalid",
            "rready",
        }

        problems: List[str] = []
        for iface in interfaces:
            for short, sig in iface._signals.items():
                if short in HANDSHAKE_SHORTS:
                    if sig.name not in usage.used_in_body:
                        problems.append(
                            f"AXILiteInterface(prefix={iface.prefix!r}): "
                            f"handshake signal '{sig.name}' is never used "
                            f"in any logic block"
                        )

        if problems:
            raise ValidationError("handshake", problems)

    # ------------------------------------------------------------------
    # Check 2b — Waitrequest Check (Avalon-MM)
    # ------------------------------------------------------------------

    def check_waitrequest(self, interfaces: List[AvalonMMInterface]) -> None:
        """Verify that Avalon-MM flow-control signals are used in logic blocks.

        For each ``AvalonMMInterface``, checks that every flow-control
        signal (``waitrequest``, ``read``, ``write``, ``readdatavalid``)
        appears at least once in an assignment target or condition within
        the module body.  A signal that is declared as a port but never
        driven or read is a "floating handshake" — a common source of
        protocol deadlocks.

        Parameters
        ----------
        interfaces:
            List of ``AvalonMMInterface`` objects whose flow-control
            signals should be verified.

        Raises
        ------
        ValidationError
            If any flow-control signal is unused.
        """
        usage = _SignalUsageCollector()
        usage.visit(self.module)

        # Avalon-MM flow-control signal short-names
        FLOW_SHORTS = {
            "waitrequest",
            "read",
            "write",
            "readdatavalid",
        }

        problems: List[str] = []
        for iface in interfaces:
            for short, sig in iface._signals.items():
                if short in FLOW_SHORTS:
                    if sig.name not in usage.used_in_body:
                        problems.append(
                            f"AvalonMMInterface(prefix={iface.prefix!r}): "
                            f"flow-control signal '{sig.name}' is never used "
                            f"in any logic block"
                        )

        if problems:
            raise ValidationError("waitrequest", problems)

    # ------------------------------------------------------------------
    # Check 3 — Address Bounds Check
    # ------------------------------------------------------------------

    def check_address_bounds(
        self,
        addr_map: AddressMap,
        native: NativeMemInterface,
    ) -> None:
        """Verify that the AXI address range fits within the native memory.

        Checks that the number of words described by ``addr_map`` does not
        exceed the capacity of the ``NativeMemInterface`` address bus.

        Specifically:
            ``addr_map.num_words  <=  2 ** native.addr_width``

        Also verifies that the data widths are compatible:
            ``addr_map.data_width == native.data_width``

        Parameters
        ----------
        addr_map:
            The ``AddressMap`` describing the AXI-side address space.
        native:
            The ``NativeMemInterface`` that will be driven.

        Raises
        ------
        ValidationError
            If the address range overflows the native memory or the data
            widths are mismatched.
        """
        problems: List[str] = []

        # Data width compatibility
        if addr_map.data_width != native.data_width:
            problems.append(
                f"data_width mismatch: AddressMap has {addr_map.data_width} bits "
                f"but NativeMemInterface has {native.data_width} bits"
            )

        # Address depth check
        native_capacity = 2**native.addr_width  # words
        if addr_map.num_words > native_capacity:
            problems.append(
                f"address overflow: AddressMap maps {addr_map.num_words} words "
                f"but NativeMemInterface only has {native_capacity} words "
                f"(addr_width={native.addr_width})"
            )

        # Native addr_width must be wide enough to hold the word address
        required_addr_bits = (addr_map.num_words - 1).bit_length() if addr_map.num_words > 1 else 1
        if native.addr_width < required_addr_bits:
            problems.append(
                f"native addr_width ({native.addr_width}) is too narrow: "
                f"need at least {required_addr_bits} bits to address "
                f"{addr_map.num_words} words"
            )

        if problems:
            raise ValidationError("address_bounds", problems)

    # ------------------------------------------------------------------
    # Check 4 — SVA Injector
    # ------------------------------------------------------------------

    def inject_sva(
        self,
        axi: AXILiteInterface,
        clk_name: str = "clk",
        rst_name: str = "rst_n",
        active_low_reset: bool = True,
    ) -> List[SvaProperty]:
        """Generate SystemVerilog Assertion properties for AXI-Lite compliance.

        The generated properties check the AXI4 protocol rule:
        *"Once VALID is asserted it must remain asserted until the handshake
        completes (READY is also asserted)."*

        This is checked for all five AXI-Lite channels:
        AW, W, B, AR, R.

        Parameters
        ----------
        axi:
            The ``AXILiteInterface`` to generate assertions for.
        clk_name:
            Name of the clock signal in the generated SVA.
        rst_name:
            Name of the reset signal.
        active_low_reset:
            If ``True``, the reset disable condition is ``!rst_n``.
            If ``False``, it is ``rst``.

        Returns
        -------
        List[SvaProperty]
            One property per AXI channel.  Pass these to the emitter's
            ``sva_properties`` argument to include them in the output file.
        """
        p = axi.prefix
        sep = "_" if p else ""

        def _n(short: str) -> str:
            """Resolve a short signal name to its full prefixed name."""
            return axi._signals[short].name

        rst_disable = f"!{rst_name}" if active_low_reset else rst_name

        # Channel definitions: (property_name, valid_sig, ready_sig, comment)
        channels = [
            ("aw", _n("awvalid"), _n("awready"), "AXI4-Lite: AWVALID must stay high until AWREADY"),
            ("w", _n("wvalid"), _n("wready"), "AXI4-Lite: WVALID must stay high until WREADY"),
            ("b", _n("bvalid"), _n("bready"), "AXI4-Lite: BVALID must stay high until BREADY"),
            ("ar", _n("arvalid"), _n("arready"), "AXI4-Lite: ARVALID must stay high until ARREADY"),
            ("r", _n("rvalid"), _n("rready"), "AXI4-Lite: RVALID must stay high until RREADY"),
        ]

        props: List[SvaProperty] = []
        for ch, valid, ready, comment in channels:
            prop_name = f"{p}{sep}axi_{ch}_valid_stable" if p else f"axi_{ch}_valid_stable"
            # SVA: once valid rises, it stays high until ready acknowledges
            body = f"@(posedge {clk_name}) disable iff ({rst_disable})\n  ({valid} && !{ready}) |=> {valid};"
            props.append(
                SvaProperty(
                    name=prop_name,
                    body=body,
                    severity="assert",
                    comment=comment,
                )
            )

        return props

    # ------------------------------------------------------------------
    # Convenience: run all checks at once
    # ------------------------------------------------------------------

    def run_all(
        self,
        axi_interfaces: Optional[List[AXILiteInterface]] = None,
        avalon_interfaces: Optional[List[AvalonMMInterface]] = None,
        addr_map: Optional[AddressMap] = None,
        native: Optional[NativeMemInterface] = None,
    ) -> List[SvaProperty]:
        """Run all applicable checks and return SVA properties.

        Parameters
        ----------
        axi_interfaces:
            If provided, ``check_handshakes`` is run for each interface.
        avalon_interfaces:
            If provided, ``check_waitrequest`` is run for each interface.
        addr_map:
            If provided (together with ``native``), ``check_address_bounds``
            is run.
        native:
            Required when ``addr_map`` is provided.

        Returns
        -------
        List[SvaProperty]
            SVA properties for all provided AXI interfaces (empty list if
            none provided).

        Raises
        ------
        ValidationError
            On the first check that fails.
        """
        self.check_widths()

        sva_props: List[SvaProperty] = []

        if axi_interfaces:
            self.check_handshakes(axi_interfaces)
            for iface in axi_interfaces:
                sva_props.extend(self.inject_sva(iface))

        if avalon_interfaces:
            self.check_waitrequest(avalon_interfaces)

        if addr_map is not None and native is not None:
            self.check_address_bounds(addr_map, native)

        return sva_props


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    "ValidationError",
    "SvaProperty",
    "Validator",
]
