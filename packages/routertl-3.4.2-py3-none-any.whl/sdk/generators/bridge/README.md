# RTL Bridge Generator

This directory contains the Python-based generator for bridging AXI and Avalon memory-mapped interfaces. It uses a phased compiler-like architecture (AST → Validator → Emitter).

## 📚 Documentation Index

The generator has extensive design and verification documentation. Start here to understand the architecture and how to extend it.

### System Architecture

* [System Architecture](SYSTEM_ARCHITECTURE.md) - High-level overview of the generator's structure.
* [Pipeline & Timing](PIPELINE.md) - Details on how register slices are inserted for timing closure.
* [Validator](VALIDATOR.md) - Information on the AST validation and SystemVerilog Assertions (SVA) injection layer.
* [Emitter Backend](EMITTER.md) - How the validated AST is lowered into SystemVerilog or VHDL.

### Bridge Logic & State Machines

* [Bridge Generator Design](BRIDGE_GENERATOR_DESIGN.md) - The core philosophy behind the bridge AST definitions.
* [Bridge FSM Design](BRIDGE_FSM_DESIGN.md) - Detailed breakdown of the read and write state machines used across the bridges.

### Verification

* [Verification Architecture](VERIFICATION_ARCHITECTURE.md) - **Contains comprehensive architectural diagrams** of the end-to-end parametric E2E verification testbench (Simulation, Scoreboards, Parametric Matrices).
