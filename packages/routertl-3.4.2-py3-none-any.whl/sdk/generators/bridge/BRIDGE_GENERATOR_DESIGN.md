# RTL Bridge Generator — Design Concept

> Python AST-driven code generator for AXI ↔ Avalon ↔ Native memory bus bridges.

## 1. Motivation

Hand-writing protocol bridges is tedious and error-prone.
Template-based generators (Jinja, string-format) become fragile as the
number of protocol variants grows.  An **AST-based approach** treats
RTL as structured data, enabling programmatic analysis (linting, width
checks) *before* any Verilog is emitted.

## 2. Compiler-Pipeline Architecture

```text
┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   Frontend   │────▶│  Middle-end  │────▶│ Logic Layer  │────▶│   Backend    │
│ (Interfaces) │     │   (AST)      │     │  (Bridges)   │     │  (Emitter)   │
└──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
  Python classes       Signal, Module,      FSM population       VerilogVisitor
  defining bus         Always, Case,        functions per        walks tree →
  protocols            If, Assignment       bridge variant       .v / .sv file
```

### 2.1 Frontend — Bus Interface Definitions

Python dataclasses that declaratively describe each bus protocol.

| Class               | Signals (excerpt)                                    |
|---------------------|------------------------------------------------------|
| `AXI4Interface`     | `AWADDR`, `AWVALID`, `AWREADY`, `WDATA`, `WSTRB`, … |
| `AXILiteInterface`  | Subset of AXI4 (no burst, no ID)                     |
| `AvalonMMInterface` | `address`, `read`, `write`, `readdata`, `writedata`  |
| `NativeMemInterface`| `addr`, `din`, `dout`, `we`, `re`, `waitrequest`     |

Each interface class exposes:

- A **signal list** (name, width, direction, reset value).
- A **`connect(other)`** helper for port-map generation.
- A **parameterization API** — widths derived from `data_width` and
  `addr_width` constructor args, with `log2` auto-calculation for
  memory-depth-based addressing.

### 2.2 Middle-end — Hardware AST

A minimal, visitable tree of hardware constructs.

```mermaid
classDiagram
    class HdlNode {
        +accept(visitor)
    }
    class Signal {
        +name: str
        +width: int
        +direction: Direction
        +reset_value: int
    }
    class Module {
        +name: str
        +signals: List[Signal]
        +body: List[HdlNode]
    }
    class Assignment {
        +target: Signal
        +source: Expression
    }
    class AlwaysBlock {
        +sensitivity: List[Edge]
        +body: List[HdlNode]
    }
    class IfStatement {
        +condition: Expression
        +then_body: List[HdlNode]
        +else_body: List[HdlNode]
    }
    class CaseStatement {
        +selector: Signal
        +branches: Dict[int, List[HdlNode]]
        +default: List[HdlNode]
    }

    HdlNode <|-- Signal
    HdlNode <|-- Module
    HdlNode <|-- Assignment
    HdlNode <|-- AlwaysBlock
    HdlNode <|-- IfStatement
    HdlNode <|-- CaseStatement
    Module *-- HdlNode
    AlwaysBlock *-- HdlNode
```

All nodes implement `accept(visitor)` for the **Visitor Pattern**.

### 2.3 Logic Layer — Bridge Population Functions

Each bridge variant is a Python function that:

1. Receives two interface objects (source + target).
2. Creates a `Module` and populates it with FSM logic as AST nodes.
3. Returns the populated `Module`.

#### Example: AXI-Lite → Native SRAM Write Path

```text
        ┌───────────────────────────── FSM ──────────────────────────────┐
        │                                                                │
  IDLE ──▶ awvalid & wvalid? ──yes──▶ WRITE_DATA ──▶ WRITE_RESP ──▶ IDLE
        │         │                        │               │             │
        │         no (stay)                │  addr←awaddr  │  bvalid=1   │
        │                                 │  din ←wdata   │  bresp=OKAY │
        │                                 │  we  =1       │             │
        └────────────────────────────────────────────────────────────────┘
```

### 2.4 Backend — Verilog Emitter

A `VerilogVisitor` class that:

- Walks the `Module` tree.
- Emits `module … endmodule` with Verilog-2001 ANSI port declarations.
- Classifies signals as `wire` vs `reg` based on driver context.
- Recursively renders `always`, `case`, `if/else`, and `assign` blocks
  with proper indentation.

Output format is selectable: `.v` (Verilog-2001) or `.sv` (SystemVerilog).

## 3. Supported Bridge Variants

| Source        | Target        | Data Path | Status    |
|---------------|---------------|-----------|-----------|
| AXI-Lite      | Native SRAM   | R + W     | Phase 1   |
| AXI4 (burst)  | Native SRAM   | R + W     | Phase 2   |
| AXI-Lite      | Avalon-MM     | R + W     | ✅ Done   |
| Avalon-MM     | Native SRAM   | R + W     | Phase 3   |
| AXI4          | Avalon-MM     | R + W     | Phase 3   |

## 4. Key Design Principles

### 4.1 Handshake Synchronisation

AXI uses `VALID`/`READY`.  Avalon uses `waitrequest`.
The bridge FSM must:

- **Stall AXI READY** when the native/Avalon side asserts `waitrequest`.
- **Never drop a beat** — if `WVALID` goes high, the data must be
  captured even if the native side is not ready yet (use a skid buffer
  where necessary).

### 4.2 Parameterisation

All widths are derived from two top-level parameters:

```python
bridge = generate_axilite_to_native(
    data_width=32,
    addr_width=16,      # → 64 KiB
    mem_depth=16384,     # auto-computes log2 = 14-bit internal addr
)
```

### 4.3 Reset Styles

A global `ResetStyle` enum (`SYNC` / `ASYNC`) controls whether the
emitter renders:

```verilog
always @(posedge clk)           // SYNC
always @(posedge clk or negedge rst_n)  // ASYNC
```

### 4.4 Pre-Emission Sanity Checks

A `SanityChecker` visitor analyses the AST before code generation:

| Check              | Severity | Description                                     |
|--------------------|----------|-------------------------------------------------|
| Width mismatch     | Error    | 32-bit signal assigned to 16-bit target         |
| Multiple drivers   | Error    | Signal driven by >1 `assign` / `always` block   |
| Unconnected port   | Warning  | Input declared but never read in any logic block |
| Unreachable state  | Warning  | FSM state with no incoming transition            |

## 5. Integration with RouteRTL SDK

- **Location**: `tools/bridge-gen/` inside the RouteRTL SDK
  (peer to `tools/regbank-utils/`, `tools/cocotb-testgen/`, etc.).
- **Generic by design**: No project-specific references — any client
  project consuming the SDK can invoke the generator.
- **Output directory**: Client projects receive generated Verilog in
  their own `hw/rtl/bridges/<variant>/` (or a path of their choosing
  via CLI `--output`).
