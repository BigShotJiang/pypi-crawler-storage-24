# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_addr_map.py — Unit tests for addr_map.py
==============================================

Run with:
    python -m pytest sdk/generators/bridge/test_addr_map.py -v
"""

import pytest
from addr_map import AddressMap, AddressTransformer, AvalonResp, AXIResp
from hdl_ast import Direction, Signal, Slice

# ===========================================================================
# AddressMap — construction and validation
# ===========================================================================


class TestAddressMapConstruction:
    def test_defaults(self) -> None:
        am = AddressMap(data_width=32, addr_width=14)
        assert am.data_width == 32
        assert am.addr_width == 14
        assert am.base_addr == 0
        # Full address space: 2^14 * 4 bytes = 65536 bytes
        assert am.size_bytes == 65536

    def test_explicit_size_bytes(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, size_bytes=4096)
        assert am.size_bytes == 4096

    def test_non_zero_base_addr(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0x4000_0000)
        assert am.base_addr == 0x4000_0000

    def test_byte_shift_32bit(self) -> None:
        am = AddressMap(data_width=32, addr_width=14)
        assert am.byte_shift == 2  # log2(32/8) = log2(4) = 2

    def test_byte_shift_64bit(self) -> None:
        am = AddressMap(data_width=64, addr_width=14)
        assert am.byte_shift == 3  # log2(64/8) = log2(8) = 3

    def test_byte_shift_8bit(self) -> None:
        am = AddressMap(data_width=8, addr_width=14)
        assert am.byte_shift == 0  # log2(8/8) = log2(1) = 0

    def test_byte_shift_16bit(self) -> None:
        am = AddressMap(data_width=16, addr_width=14)
        assert am.byte_shift == 1

    def test_bytes_per_word(self) -> None:
        am = AddressMap(data_width=32, addr_width=14)
        assert am.bytes_per_word == 4

    def test_num_words(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, size_bytes=4096)
        assert am.num_words == 1024  # 4096 / 4

    def test_max_byte_addr(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0x100, size_bytes=256)
        assert am.max_byte_addr == 0x100 + 256 - 1

    def test_repr(self) -> None:
        am = AddressMap(data_width=32, addr_width=14)
        r = repr(am)
        assert "AddressMap" in r
        assert "32" in r


class TestAddressMapValidation:
    def test_non_power_of_two_data_width_raises(self) -> None:
        with pytest.raises(ValueError, match="power-of-two"):
            AddressMap(data_width=24, addr_width=14)

    def test_data_width_too_small_raises(self) -> None:
        with pytest.raises(ValueError, match="power-of-two"):
            AddressMap(data_width=4, addr_width=14)

    def test_zero_addr_width_raises(self) -> None:
        with pytest.raises(ValueError, match="addr_width"):
            AddressMap(data_width=32, addr_width=0)

    def test_negative_base_addr_raises(self) -> None:
        with pytest.raises(ValueError, match="base_addr"):
            AddressMap(data_width=32, addr_width=14, base_addr=-1)

    def test_size_bytes_overflow_raises(self) -> None:
        # 2^14 * 4 = 65536 bytes max; 65537 should fail
        with pytest.raises(ValueError, match="overflows"):
            AddressMap(data_width=32, addr_width=14, size_bytes=65537)

    def test_size_bytes_exactly_max_ok(self) -> None:
        # Exactly at the limit is fine
        am = AddressMap(data_width=32, addr_width=14, size_bytes=65536)
        assert am.size_bytes == 65536

    def test_zero_size_bytes_raises(self) -> None:
        with pytest.raises(ValueError, match="size_bytes"):
            AddressMap(data_width=32, addr_width=14, size_bytes=0)

    def test_validate_method(self) -> None:
        am = AddressMap(data_width=32, addr_width=14)
        am.validate()  # should not raise


# ===========================================================================
# byte_offset_expr
# ===========================================================================


class TestByteOffsetExpr:
    def _sig(self, width: int = 16) -> Signal:
        return Signal("awaddr", width=width, direction=Direction.INPUT)

    def test_zero_base_returns_signal(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0)
        sig = self._sig()
        result = am.byte_offset_expr(sig)
        assert result is sig

    def test_nonzero_base_returns_string(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0x1000)
        sig = self._sig()
        result = am.byte_offset_expr(sig)
        assert isinstance(result, str)
        assert "awaddr" in result
        assert "0x1000" in result

    def test_nonzero_base_subtraction(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0x4000_0000)
        sig = self._sig(width=32)
        result = am.byte_offset_expr(sig)
        assert "0x40000000" in str(result)


# ===========================================================================
# word_addr_expr
# ===========================================================================


class TestWordAddrExpr:
    def _sig(self, width: int = 16) -> Signal:
        return Signal("awaddr", width=width, direction=Direction.INPUT)

    def test_zero_base_32bit_returns_slice(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0)
        sig = self._sig(width=16)
        result = am.word_addr_expr(sig)
        # Should be a Slice node: awaddr[15:2]
        assert isinstance(result, Slice)
        assert result.signal is sig
        assert result.lsb == 2  # byte_shift for 32-bit
        assert result.msb == 15  # sig.width - 1

    def test_zero_base_64bit_returns_slice(self) -> None:
        am = AddressMap(data_width=64, addr_width=14, base_addr=0)
        sig = self._sig(width=16)
        result = am.word_addr_expr(sig)
        assert isinstance(result, Slice)
        assert result.lsb == 3  # byte_shift for 64-bit

    def test_zero_base_8bit_no_shift(self) -> None:
        am = AddressMap(data_width=8, addr_width=14, base_addr=0)
        sig = self._sig(width=14)
        result = am.word_addr_expr(sig)
        # No shift needed: byte address == word address
        assert result is sig

    def test_nonzero_base_returns_string(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0x1000)
        sig = self._sig(width=16)
        result = am.word_addr_expr(sig)
        assert isinstance(result, str)
        assert ">>" in result
        assert "2" in result  # byte_shift

    def test_slice_width(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0)
        sig = self._sig(width=16)
        result = am.word_addr_expr(sig)
        assert isinstance(result, Slice)
        assert result.width == 14  # addr_width bits


# ===========================================================================
# in_range_expr / out_of_range_expr
# ===========================================================================


class TestRangeExpr:
    def _sig(self) -> Signal:
        return Signal("awaddr", width=32, direction=Direction.INPUT)

    def test_zero_base_only_upper_bound(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0, size_bytes=4096)
        expr = am.in_range_expr(self._sig())
        assert isinstance(expr, str)
        assert "awaddr" in expr
        # No lower-bound check needed for base_addr=0
        assert ">=" not in expr
        assert "0x1000" in expr  # 4096 = 0x1000

    def test_nonzero_base_both_bounds(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0x1000, size_bytes=4096)
        expr = am.in_range_expr(self._sig())
        assert ">=" in expr
        assert "0x1000" in expr
        assert "0x2000" in expr  # 0x1000 + 0x1000

    def test_out_of_range_is_negation(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0, size_bytes=4096)
        in_expr = am.in_range_expr(self._sig())
        out_expr = am.out_of_range_expr(self._sig())
        assert "!" in str(out_expr)
        assert str(in_expr) in str(out_expr)

    def test_signal_name_in_expr(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0, size_bytes=4096)
        sig = Signal("s_axi_awaddr", width=32, direction=Direction.INPUT)
        expr = am.in_range_expr(sig)
        assert "s_axi_awaddr" in str(expr)


# ===========================================================================
# AddressTransformer alias
# ===========================================================================


class TestAddressTransformerAlias:
    def test_is_subclass_of_address_map(self) -> None:
        at = AddressTransformer(data_width=32, addr_width=14)
        assert isinstance(at, AddressMap)

    def test_same_behaviour(self) -> None:
        am = AddressMap(data_width=32, addr_width=14, base_addr=0x1000)
        at = AddressTransformer(data_width=32, addr_width=14, base_addr=0x1000)
        sig = Signal("awaddr", width=32, direction=Direction.INPUT)
        assert str(am.word_addr_expr(sig)) == str(at.word_addr_expr(sig))


# ===========================================================================
# Response code constants
# ===========================================================================


class TestResponseCodes:
    def test_axi_okay(self) -> None:
        assert AXIResp.OKAY == "2'b00"

    def test_axi_slverr(self) -> None:
        assert AXIResp.SLVERR == "2'b10"

    def test_axi_decerr(self) -> None:
        assert AXIResp.DECERR == "2'b11"

    def test_avalon_okay(self) -> None:
        assert AvalonResp.OKAY == "2'b00"

    def test_avalon_slverr(self) -> None:
        assert AvalonResp.SLVERR == "2'b10"

    def test_avalon_decerr(self) -> None:
        assert AvalonResp.DECERR == "2'b11"


# ===========================================================================
# Integration: word_addr_expr feeds into an Assign node
# ===========================================================================


class TestIntegration:
    def test_word_addr_in_assign(self) -> None:
        """word_addr_expr result can be used directly as an Assign source."""
        from hdl_ast import Assign, Direction, Signal

        am = AddressMap(data_width=32, addr_width=14, base_addr=0)
        axi_addr = Signal("awaddr", width=16, direction=Direction.INPUT)
        nat_addr = Signal("mem_addr", width=14, direction=Direction.OUTPUT)

        word_expr = am.word_addr_expr(axi_addr)
        assign_node = Assign(target=nat_addr, source=word_expr)

        assert assign_node.target is nat_addr
        assert assign_node.source is word_expr

    def test_in_range_in_if_condition(self) -> None:
        """in_range_expr result can be used as an If condition."""
        from hdl_ast import If

        am = AddressMap(data_width=32, addr_width=14, base_addr=0x1000, size_bytes=4096)
        axi_addr = Signal("awaddr", width=32, direction=Direction.INPUT)

        cond = am.in_range_expr(axi_addr)
        if_node = If(condition=cond)

        assert if_node.condition is cond
