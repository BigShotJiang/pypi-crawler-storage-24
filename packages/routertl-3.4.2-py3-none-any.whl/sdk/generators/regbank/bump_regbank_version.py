# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import subprocess
import sys
from pathlib import Path

import yaml


def has_changes(filepath):
    """Check if the file has uncommitted changes."""
    result = subprocess.run(["git", "diff", "--quiet", filepath])
    return result.returncode != 0  # return code 1 means changes detected


def bump_version(version_str):
    """Increment the build number in the version string (format: major.minor.build)."""
    parts = version_str.split(".")
    while len(parts) < 3:
        parts.append("0")
    major, minor, build = map(int, parts[:3])
    build += 1
    return f"{major}.{minor}.{build}"


def update_yaml_version(schema_path):
    """Bump the version field in a YAML register schema."""
    with open(schema_path, "r") as f:
        data = yaml.safe_load(f)

    old_version = str(data.get("version", "0.0.0"))
    new_version = bump_version(old_version)
    data["version"] = new_version

    with open(schema_path, "w") as f:
        yaml.dump(data, f, sort_keys=False)

    print(f"🔁 Version bumped: {old_version} → {new_version}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python bump_regbank_version.py <register_map.yml>")
        sys.exit(1)

    path = Path(sys.argv[1])
    if not path.exists() or path.suffix not in [".yml", ".yaml"]:
        print("❌ Input must be a valid .yml or .yaml file")
        sys.exit(1)

    if has_changes(path):
        update_yaml_version(path)
    else:
        print("✅ No changes detected in the Register Bank definition. Version unchanged.")
