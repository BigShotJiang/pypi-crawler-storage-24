# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import argparse
import re

import yaml


def parse_address_field(val):
    """Parse an address field value into an integer."""
    if isinstance(val, int):
        return val
    val_str = str(val)
    return int(val_str, 16) if val_str.startswith("0x") else int(val_str)


def validate_schema(schema_path, address_mode="words", strict=False):
    """Validate a YAML register schema for consistency errors."""
    with open(schema_path, "r") as f:
        data = yaml.safe_load(f)

    regs = data.get("registers", [])
    issues = []
    warnings = []
    seen_addrs = {}

    for reg in regs:
        name = reg["name"]
        addr = parse_address_field(reg["address"])

        # Check formatting of name
        if not re.match(r"^[A-Z0-9_]+$", name):
            warnings.append(f"⚠️ Register name '{name}' is not UPPER_SNAKE_CASE")

        if address_mode == "bytes":
            if addr % 4 != 0:
                warnings.append(f"⚠️ Address not aligned to 4 bytes: {name} @ 0x{addr:X}")
            word_index = addr // 4
        else:  # assume "words"
            word_index = addr

        if word_index in seen_addrs:
            issues.append(f"❌ Address overlap: {name} and {seen_addrs[word_index]} both use index {word_index}")
        else:
            seen_addrs[word_index] = name

        field_map = {}
        fields = reg.get("fields") or []
        for field in fields:
            fname = field["name"]
            bits = field.get("bits", [])
            if fname in field_map:
                warnings.append(f"⚠️ Duplicate field name '{fname}' in {name}")
            field_map[fname] = bits

            for b in bits:
                if b < 0 or b > 31:
                    issues.append(f"❌ Invalid bit {b} in field '{fname}' of {name}")

    max_index = max(seen_addrs.keys()) if seen_addrs else 0
    reg_count = len(seen_addrs)

    return {"issues": issues, "warnings": warnings, "max_index": max_index, "reg_count": reg_count, "strict": strict}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("schema", help="Path to register YAML schema")
    parser.add_argument(
        "--address-mode", choices=["bytes", "words"], default="words", help="Interpret addresses as byte or word offset"
    )
    parser.add_argument("--strict", action="store_true", help="Treat warnings as errors")
    args = parser.parse_args()

    result = validate_schema(args.schema, address_mode=args.address_mode, strict=args.strict)

    exit_code = 0
    for issue in result["issues"]:
        print(issue)
        exit_code = 1

    for warn in result["warnings"]:
        print(warn)
        if result["strict"]:
            exit_code = 1

    print(f"\n✅ Register entries: {result['reg_count']}  (Max index: {result['max_index']})")
    if result["strict"] and result["warnings"]:
        print("🔒 Strict mode enabled — warnings elevated to errors.")

    exit(exit_code)
