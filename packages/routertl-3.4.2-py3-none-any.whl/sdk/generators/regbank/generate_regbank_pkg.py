# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

from datetime import datetime
from math import ceil, log2

import yaml

EXTERNAL_CONSTANTS = {
    "GIT_HASH_VALUE": "C_GIT_HASH",
    "SYSTEM_FW_VERSION": "C_SYSTEM_VERSION",
    "BUILD_DATE": "C_BUILD_DATE",
    "REGISTER_BANK_VERSION": "C_REGBANK_VERSION",
    "REGBANK_NUM_WORDS": "C_REGBANK_NWORDS",
    "CONFIGURATION_NUM_WORDS": "C_CONFIG_NWORDS",
}

VHDL_HEADER_TEMPLATE = """library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
use IEEE.MATH_REAL.all;
library {lib};
use {lib}.rom_info_pkg.all;

package system_regbank_pkg is
"""

VHDL_FOOTER = """
end package system_regbank_pkg;
"""

TYPES_SECTION = """
  type t_memArray is array (0 to 2**C_REGBANK_DEPTH-1) of std_logic_vector(C_REGBANK_WIDTH-1 downto 0);

  type t_memReg is record
    data  : std_logic_vector(C_REGBANK_WIDTH-1 downto 0);
    valid : std_logic;
  end record t_memReg;

  type t_memArrayReg is array (0 to 2**C_REGBANK_DEPTH-1) of t_memReg;

  type t_pin_movement_array is array (natural range <>) of std_logic_vector(C_REGBANK_WIDTH-1 downto 0);

  constant C_REG_INIT : t_memReg := (
    data  => (others => '0'),
    valid => '0'
  );

  constant C_MEM_REG_INIT : t_memArrayReg := (
    others => C_REG_INIT
  );
"""


def parse_yaml(yaml_file):
    """Parse a YAML register schema file."""
    with open(yaml_file, "r") as f:
        return yaml.safe_load(f)


def parse_address(val, format="dec"):
    """Convert an address value to an integer index."""
    if isinstance(val, int):
        return val if format == "dec" else val // 4
    val_str = str(val)
    return (
        (int(val_str, 16) // 4 if val_str.startswith("0x") else int(val_str) // 4)
        if format == "hex"
        else (int(val_str, 16) if val_str.startswith("0x") else int(val_str))
    )


def generate_constants(regs):
    """Generate VHDL constant declarations for register indices."""
    lines = []
    for reg in regs:
        name = reg["name"].upper()
        index = parse_address(reg["address"])
        lines.append(f"  constant C_INDEX_{name:<32} : integer := {index};")
    return "\n".join(lines)


def generate_mask_vector(regs, mask_name, condition, max_index):
    """Generate a VHDL std_logic_vector mask for register properties."""
    vector = ["'0'"] * (max_index + 1)
    index_to_name = {parse_address(r["address"]): r["name"] for r in regs}
    for reg in regs:
        if condition(reg):
            vector[parse_address(reg["address"])] = "'1'"
    lines = []
    for i in range(max_index + 1):
        comment = f" -- {index_to_name.get(i, '')}"
        lines.append(f"    {vector[i]},{comment}")
    lines.append("    others => '0'")
    return f"  constant {mask_name} : std_logic_vector(0 to C_NUM_USER_REGS-1) := (\n" + "\n".join(lines) + "\n  );"


def generate_init_regbank(regs):
    """Generate a VHDL register bank initialisation constant."""
    lines = []
    for reg in regs:
        key = reg["name"].upper()
        if reg.get("access", "") == "rom" or key in EXTERNAL_CONSTANTS:
            const = EXTERNAL_CONSTANTS.get(key)
            if const:
                lines.append(f"    C_INDEX_{key:<32} => {const},")
            else:
                lines.append(f"    C_INDEX_{key:<32} => (others => '0'), -- Warning: missing external constant")
    lines.append("    others => (others => '0')")
    return "  constant C_INIT_REGBANK : t_memArray := (\n" + "\n".join(lines) + "\n  );"


def generate_pkg(yaml_file, output_file, format, verbose=False, library="work"):
    """Generate a complete VHDL register bank package file."""
    data = parse_yaml(yaml_file)
    regs = data["registers"]
    regs.sort(key=lambda r: parse_address(r["address"], format))

    if not regs:
        max_index = 0
        regbank_depth = 1  # Minimum depth (2 words) or 0 (1 word)? Let's use 1 to allow room? Or 0.
        # If max_index=0, depth=ceil(log2(1))=0. 2**0 = 1 register.
        # This is safe.
    else:
        max_index = max(parse_address(r["address"], format) for r in regs)
        regbank_depth = ceil(log2(max_index + 1))

    if verbose:
        print(f"[INFO] Max address index = {max_index}")
        print(f"[INFO] C_REGBANK_DEPTH   = {regbank_depth}")

    with open(output_file, "w") as f:
        today = datetime.now().strftime("%Y-%m-%d")
        f.write(f"--  This file is auto-generated by the regbank-utils tool on {today}\n")
        f.write(VHDL_HEADER_TEMPLATE.format(lib=library) + "\n")
        f.write(f"  constant C_REGBANK_DEPTH   : integer := {regbank_depth};  -- auto-calculated\n")
        f.write("  constant C_REGBANK_WIDTH   : integer := 32;\n")
        f.write("  constant C_NUM_USER_REGS   : integer := 2**C_REGBANK_DEPTH;\n")
        f.write("  constant C_REGBANK_NWORDS  : std_logic_vector(C_REGBANK_WIDTH-1 downto 0) := C_REGBANK_WORDS;\n")
        f.write("  constant C_CONFIG_NWORDS   : std_logic_vector(C_REGBANK_WIDTH-1 downto 0) := C_CONFIG_WORDS;\n")

        f.write("  -----------------------------------------------------------------------------\n")
        f.write("-- Indexes in the register Bank\n")
        f.write(generate_constants(regs) + "\n\n")

        f.write("  -- ROM regs are initialized with the bitstream\n")
        f.write(generate_mask_vector(regs, "C_ROM_REGS", lambda r: r.get("access", "ro") == "rom", max_index) + "\n\n")
        f.write("  -- Read Only regs can only be read, but they are init as 0x0\n")
        f.write(
            generate_mask_vector(regs, "C_READ_ONLY", lambda r: r.get("access", "ro") in ["ro", "rom"], max_index)
            + "\n\n"
        )

        f.write(TYPES_SECTION + "\n")
        f.write(generate_init_regbank(regs) + "\n")
        f.write(VHDL_FOOTER)

    print(f"✅ Generated VHDL register bank package: {output_file}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("yaml_file", help="Input YAML register schema")
    parser.add_argument("output_file", help="Output VHDL package file")
    parser.add_argument("--format", "-f", help="Schema address format", choices=["hex", "dec"], default="dec")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    parser.add_argument(
        "--library", "-l", default="work", help="VHDL library name for package dependencies (default: work)"
    )
    args = parser.parse_args()
    generate_pkg(args.yaml_file, args.output_file, args.format, args.verbose, args.library)
