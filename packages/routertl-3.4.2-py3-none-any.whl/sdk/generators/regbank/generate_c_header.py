# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Generate C/C++ register headers from regbank_schema.yml.

Produces:
- C ``#define`` macros with byte-addressed offsets and field masks
- Optional C++ register class with typed getters/setters (``--cpp``)
"""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path

from sdk.generators.regbank.regbank_parser import RegbankSchema, load_schema


def _guard_name(output: Path) -> str:
    """Generate an include-guard symbol from the output filename."""
    return output.stem.upper().replace("-", "_").replace(".", "_") + "_H"


def _field_mask(bits: list[int]) -> tuple[int, int]:
    """Return (mask, shift) for a field's bit range."""
    if len(bits) == 2:
        hi, lo = max(bits), min(bits)
    elif len(bits) == 1:
        hi = lo = bits[0]
    else:
        return 0, 0
    mask = ((1 << (hi - lo + 1)) - 1) << lo
    return mask, lo


def generate_c_header(schema: RegbankSchema) -> str:
    """Generate a C header string with register offset defines and field macros."""
    today = datetime.now().strftime("%Y-%m-%d")
    lines: list[str] = []
    a = lines.append

    guard = "REGBANK_H"
    a("/* SPDX-License-Identifier: MIT */")
    a(f"/* Auto-generated from regbank_schema.yml v{schema.version} — {today} */")
    a("/* DO NOT EDIT — regenerate with `rr regbank c-header` */")
    a("")
    a(f"#ifndef {guard}")
    a(f"#define {guard}")
    a("")
    a("#include <stdint.h>")
    a("")

    # ── Register offsets (byte-addressed) ─────────────────────────
    a("/* ── Register Offsets (byte-addressed) ─────────────────── */")
    a("")
    for reg in schema.registers:
        a(f"#define REG_{reg.name:<40s} 0x{reg.byte_offset:04X}u")
    a("")

    # ── Field macros ──────────────────────────────────────────────
    for reg in schema.registers:
        if not reg.fields:
            continue
        a(f"/* ── {reg.name} fields ─────────────────────────────── */")
        for field in reg.fields:
            mask, shift = _field_mask(field.bits)
            if mask == 0:
                continue
            prefix = f"REG_{reg.name}_{field.name}"
            a(f"#define {prefix + '_MASK':<50s} 0x{mask:08X}u")
            a(f"#define {prefix + '_SHIFT':<50s} {shift}u")
            a(f"#define {prefix + '_GET(v)':<50s} (((v) & {prefix}_MASK) >> {prefix}_SHIFT)")
            a(f"#define {prefix + '_SET(v)':<50s} (((v) << {prefix}_SHIFT) & {prefix}_MASK)")
            # Enum values
            if field.enum:
                for val, name in sorted(field.enum.items()):
                    enum_sym = f"{prefix}_{name.upper().replace(' ', '_')}"
                    a(f"#define {enum_sym:<50s} {val}u")
            a("")
        a("")

    # ── Convenience read/write helpers ────────────────────────────
    a("/* ── Convenience helpers (requires user-defined BASE_ADDR) ── */")
    a("")
    a("#ifndef REGBANK_BASE_ADDR")
    a("#define REGBANK_BASE_ADDR 0x00000000u")
    a("#endif")
    a("")
    a("#define REGBANK_READ(offset)       (*(volatile uint32_t *)(REGBANK_BASE_ADDR + (offset)))")
    a("#define REGBANK_WRITE(offset, val) (*(volatile uint32_t *)(REGBANK_BASE_ADDR + (offset)) = (val))")
    a("")
    a(f"#endif /* {guard} */")
    a("")
    return "\n".join(lines)


def generate_cpp_class(schema: RegbankSchema) -> str:
    """Generate a C++ register accessor class."""
    lines: list[str] = []
    a = lines.append

    a("")
    a("#ifdef __cplusplus")
    a("")
    a("#include <cstdint>")
    a("")
    a("namespace regbank {")
    a("")
    a("class Registers {")
    a("public:")
    a("    explicit Registers(volatile uint32_t* base) : base_(base) {}")
    a("")

    for reg in schema.registers:
        idx = reg.address
        # Getter
        a(f"    uint32_t {reg.name.lower()}() const {{ return base_[{idx}]; }}")
        if reg.is_read_write:
            a(f"    void set_{reg.name.lower()}(uint32_t v) {{ base_[{idx}] = v; }}")
        a("")

    a("private:")
    a("    volatile uint32_t* base_;")
    a("};")
    a("")
    a("}  // namespace regbank")
    a("")
    a("#endif  // __cplusplus")
    a("")
    return "\n".join(lines)


def write_c_header(
    schema: RegbankSchema,
    output: Path,
    *,
    cpp: bool = False,
) -> None:
    """Generate and write the C header file."""
    content = generate_c_header(schema)
    if cpp:
        content += generate_cpp_class(schema)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(content, encoding="utf-8")
    print(f"✅ Generated C header: {output}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate C/C++ register header from regbank YAML.")
    parser.add_argument("yaml_file", help="Input YAML register schema")
    parser.add_argument("-o", "--output", default="regbank.h", help="Output header file")
    parser.add_argument("--cpp", action="store_true", help="Include C++ register class")
    args = parser.parse_args()

    schema = load_schema(args.yaml_file)
    write_c_header(schema, Path(args.output), cpp=args.cpp)
