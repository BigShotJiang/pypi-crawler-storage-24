# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import shutil
import sys

import yaml


def parse_address(val):
    """Parse an address string into an integer."""
    if isinstance(val, int):
        return val
    s = str(val)
    return int(s, 16) if s.startswith("0x") else int(s)


def remove_and_shift(schema_path, target, no_shift=False):
    """Remove a register and shift subsequent addresses down."""
    with open(schema_path, "r") as f:
        data = yaml.safe_load(f)

    regs = data["registers"]
    backup_path = schema_path + ".bak"
    shutil.copy(schema_path, backup_path)

    # Try to interpret as address
    try:
        target_addr = parse_address(target)
        is_address = True
    except (ValueError, TypeError):
        is_address = False

    removed = None
    for reg in regs:
        if not is_address and str(reg["name"]).upper() == target.upper():
            removed = reg
            break
        elif is_address and parse_address(reg["address"]) == target_addr:
            removed = reg
            break

    if not removed:
        print(f"❌ Entry '{target}' not found.")
        return

    removed_addr = parse_address(removed["address"])
    print(f"🗑️ Removing: {removed['name']} @ 0x{removed_addr * 4:02X}")

    regs.remove(removed)

    if not no_shift:
        for reg in regs:
            addr = parse_address(reg["address"])
            if addr > removed_addr:
                reg["address"] = addr - 1
        print("🔃 Shifted all subsequent addresses down by 1")

    regs.sort(key=lambda r: parse_address(r["address"]))

    with open(schema_path, "w") as f:
        yaml.dump(data, f, sort_keys=False)

    print(f"✅ Updated schema saved (backup: {backup_path})")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python remove_register.py <schema.yml> <name|address> [--no-shift]")
        sys.exit(1)

    schema_file = sys.argv[1]
    target = sys.argv[2]
    no_shift = "--no-shift" in sys.argv

    remove_and_shift(schema_file, target, no_shift)
