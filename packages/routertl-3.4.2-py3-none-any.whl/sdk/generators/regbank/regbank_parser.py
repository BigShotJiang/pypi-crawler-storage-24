# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Shared parser for regbank_schema.yml — typed dataclasses used by all generators.

This module provides a single, validated representation of the register bank
schema that replaces the ad-hoc ``parse_yaml`` / ``load_yaml`` helpers
scattered across the generator scripts.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import yaml


@dataclass
class RegField:
    """A single bitfield within a register."""

    name: str
    bits: List[int]
    description: str = ""
    enum: Optional[Dict[int, str]] = None


@dataclass
class Register:
    """A single register entry in the bank."""

    name: str
    address: int
    access: str  # "rom", "ro", "rw"
    description: str = ""
    format: Optional[str] = None
    fields: List[RegField] = field(default_factory=list)

    @property
    def is_rom(self) -> bool:
        return self.access == "rom"

    @property
    def is_read_only(self) -> bool:
        return self.access in ("ro", "rom")

    @property
    def is_read_write(self) -> bool:
        return self.access == "rw"

    @property
    def byte_offset(self) -> int:
        """Byte-addressed offset (word address × 4)."""
        return self.address * 4


@dataclass
class RegbankSchema:
    """Complete parsed register bank schema."""

    version: str
    registers: List[Register]
    name: Optional[str] = None

    @property
    def max_address(self) -> int:
        if not self.registers:
            return 0
        return max(r.address for r in self.registers)


def _parse_address(val) -> int:
    """Normalise an address value (int, hex string, or decimal string) to int."""
    if isinstance(val, int):
        return val
    s = str(val).strip()
    return int(s, 16) if s.startswith("0x") or s.startswith("0X") else int(s)


def _parse_field(raw: dict) -> RegField:
    """Parse a single field dict from YAML into a RegField."""
    enum = raw.get("enum")
    if enum is not None:
        # Normalise keys to int
        enum = {int(k): str(v) for k, v in enum.items()}
    return RegField(
        name=raw["name"],
        bits=raw.get("bits", []),
        description=raw.get("description", ""),
        enum=enum,
    )


def _parse_register(raw: dict) -> Register:
    """Parse a single register dict from YAML into a Register."""
    fields = [_parse_field(f) for f in raw.get("fields", []) or []]
    access = str(raw.get("access", "ro")).lower()
    fmt = raw.get("format")
    if fmt is not None:
        fmt = str(fmt) if fmt else None

    return Register(
        name=raw["name"],
        address=_parse_address(raw["address"]),
        access=access,
        description=str(raw.get("description", "")).strip(),
        format=fmt,
        fields=fields,
    )


def load_schema(path: str | Path) -> RegbankSchema:
    """Load and parse a YAML register schema file.

    Args:
        path: Path to the YAML file (``regbank_schema.yml`` or
              ``project_regbank.yml``).

    Returns:
        A fully-typed :class:`RegbankSchema` instance.

    Raises:
        FileNotFoundError: If *path* does not exist.
        yaml.YAMLError: If the file is not valid YAML.
        KeyError: If required fields are missing.
    """
    path = Path(path)
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)

    registers = [_parse_register(r) for r in data.get("registers", [])]
    registers.sort(key=lambda r: r.address)

    return RegbankSchema(
        version=str(data.get("version", "0.0.0")),
        registers=registers,
        name=data.get("name"),
    )
