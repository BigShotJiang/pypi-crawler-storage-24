# System Register Bank Utilities

This toolkit manages your self-describing FPGA register bank using a YAML source file as the single source of truth. It auto-generates:

- Encoded binary + hex files for FPGA BRAM
- Python constants for software tests
- VHDL constants for ROM depth
- (Optional) Deserializer for runtime SW inspection

---

## 🔄 Register Population Flow

How registers go from YAML to running hardware:

```
 ┌───────────────────────────────────────────────────────────────────────────────┐
 │                        regbank_schema.yml (source of truth)                  │
 └───────────┬──────────────┬───────────────┬──────────────┬────────────────────┘
             │              │               │              │
             ▼              ▼               ▼              ▼
 ┌───────────────┐ ┌────────────────┐ ┌──────────┐ ┌──────────────────┐
 │ generate_     │ │ payload_       │ │validate_ │ │ generate_        │
 │ regbank_pkg.py│ │ encoder.py     │ │schema.py │ │ constants.py     │
 └───────┬───────┘ └───────┬────────┘ └──────────┘ └───────┬──────────┘
         │                 │                               │
         ▼                 ▼                               ▼
 ┌───────────────┐ ┌────────────────┐              ┌──────────────────┐
 │ system_       │ │ regbank_       │              │ constants.py     │
 │ regbank_pkg   │ │ schema.hex    │              │ (Python test     │
 │ .vhd          │ │ (.bin)         │              │  accessors)      │
 │               │ └───────┬────────┘              └──────────────────┘
 │ Contains:     │         │
 │ • C_INDEX_*   │         │
 │ • C_ROM_REGS  │         ▼
 │ • C_READ_ONLY │ ┌────────────────────────────────────────────────────┐
 │ • C_INIT_*    │ │              create_rom.sh (pre-synthesis hook)    │
 └───────┬───────┘ │                                                    │
         │         │  Reads:  VERSION file  →  system_major/minor       │
         │         │          git rev-list   →  patch count / hash      │
         │         │          regbank.hex    →  manifest word count     │
         │         │          config.hex     →  config word count       │
         │         │                                                    │
         │         │  Writes: misc/rom.data                             │
         │         │          (build_date, git_hash, fw_version,        │
         │         │           regbank_version, manifest_size,          │
         │         │           config_size)                             │
         │         └────────────────┬───────────────────────────────────┘
         │                         │
         │                         ▼
         │              ┌──────────────────┐
         │              │ gen_info_pkg.py   │
         │              │                  │
         │              │ Generates:       │
         │              │ rom_info_pkg.vhd │
         │              │ • C_GIT_HASH     │
         │              │ • C_BUILD_DATE   │
         │              │ • C_SSI_VERSION  │
         │              │ • C_REGBANK_VER  │
         │              │ • C_MANIFEST_*   │
         │              │ • C_CONFIG_*     │
         │              └────────┬─────────┘
         │                       │
         ▼                       ▼
 ┌──────────────────────────────────────────────────────────────────────┐
 │                     SYNTHESIS (Vivado / Quartus)                     │
 │                                                                      │
 │  1. system_regbank_pkg.vhd  →  Register constants & types compiled  │
 │  2. rom_info_pkg.vhd        →  ROM constants (hash, version, date)  │
 │  3. regbank_schema.hex      →  Loaded into BRAM via $readmemh       │
 │                                                                      │
 │  Result: ROM registers initialized at bitstream generation time      │
 └──────────────────────────┬───────────────────────────────────────────┘
                            │
                            ▼
 ┌──────────────────────────────────────────────────────────────────────┐
 │                    RUNNING HARDWARE (FPGA)                           │
 │                                                                      │
 │  Register Bank (distributed/BRAM memory):                            │
 │  ┌─────────┬──────────────────────┬──────┬────────────────────────┐  │
 │  │  Addr   │  Name                │ Type │  Value                 │  │
 │  ├─────────┼──────────────────────┼──────┼────────────────────────┤  │
 │  │  0x00   │  GIT_HASH_VALUE      │ ROM  │  ← from bitstream     │  │
 │  │  0x04   │  SYSTEM_FW_VERSION   │ ROM  │  ← from VERSION file  │  │
 │  │  0x08   │  BUILD_DATE          │ ROM  │  ← from gen time      │  │
 │  │  0x0C   │  REGISTER_BANK_VER   │ ROM  │  ← from schema ver    │  │
 │  │  0x10   │  REGBANK_NUM_WORDS   │ ROM  │  ← from hex size      │  │
 │  │  0x14   │  REGBANK_DATA        │ RO   │  ← BRAM readout       │  │
 │  │  ...    │  (user registers)    │ R/W  │  ← FPGA logic / SW    │  │
 │  └─────────┴──────────────────────┴──────┴────────────────────────┘  │
 │                                                                      │
 │  Access: AXI-Lite / SSI / native memory-mapped bus                  │
 └──────────────────────────────────────────────────────────────────────┘
```

**Key points:**

- **ROM registers** (addr 0–4) are written once at synthesis. They cannot be
  modified at runtime — the git hash and build date are frozen into the FPGA.
- **RO registers** are driven by FPGA logic via `REGS_IN` record ports.
- **R/W registers** can be written by both software (via bus) and FPGA logic.
- `create_rom.sh` runs as a **pre-synthesis hook**, so every build
  automatically stamps the correct git hash and date.

## 📁 Folder Layout

```
regbank-utils/
├── regbank_parser.py            # Shared typed parser (dataclasses)
├── add_register.py              # Add a register via CLI prompts
├── remove_register.py           # Remove register by name or address
├── validate_schema.py           # Validate schema structure and sanity
├── generate_regbank_pkg.py      # Generate VHDL system_regbank_pkg.vhd
├── generate_axilite.py          # Generate AXI-Lite register file (P2.109)
├── generate_c_header.py         # Generate C/C++ register headers (P2.110)
├── generate_html.py             # Generate HTML register docs (P2.111)
├── gen_info_pkg.py              # Generate VHDL rom_info_pkg.vhd
├── check_regbank_version.py     # Skip regeneration if versions match
├── payload_encoder.py           # YAML → MsgPack/hex for BRAM
├── payload_decoder.py           # Binary → Structured/Text decoding
├── markdown_encoder.py          # Generate Markdown docs from YAML
├── yml_to_csv.py                # Export YAML to CSV
├── bin_to_hex.py                # Convert raw binary to hex file
├── regbank_schema.yml           # 📜 Main register schema example
└── tests/                       # 🧪 Automated tests
    ├── test_regbank_utils.py
    ├── test_regbank_build_flow.py
    └── test_regbank_generators.py
```

---

## 📦 Requirements

```bash
pip install -r requirements.txt
```

## ⚙️ Usage

### 🔄 Encode Register Map
```bash
python payload_encoder.py register_map.yaml
```
Output:
- `regbank_manifest.hex` (for FPGA)
- `regbank_manifest.bin` (for software tools)

Flags:
- `--format=raw`        Encodes as raw 32-bit words (default)
- `--format=structured` Encodes as msgpack dictionary with metadata
- `--bin=<bin_file_name>` Defines the output binary file name

### 🧠 Generate Python Constants
```bash
python generate_constants.py register_map.yaml regbank_constants.py
```

### 🧮 Generate VHDL Info Package
```bash
python gen_info_pkg.py $(ROOT_DIR) $(MANIFEST_FILE) $(CONFIG_FILE)
```
Generates `src/pkg/rom_info_pkg.vhd` containing build info and register bank version constants.

### 📖 Generate VHDL Register Package
```bash
python generate_regbank_pkg.py register_map.yaml system_regbank_pkg.vhd
```
Generates `system_regbank_pkg.vhd` containing register index constants and types.

### 📖 Decode from Binary (optional)
```bash
python payload_decoder.py regbank_manifest.bin
python payload_decoder.py regbank_manifest.bin --out decoded.txt
```

Flags:
- `--format=raw`        Decodes a raw-encoded binary file (default)
- `--format=structured` Decodes a structured-packed binary file
- `--out=<out_file_name>` Defines the output file (text or binary depending on mode)

### 📝 Generate Documentation
```bash
python markdown_encoder.py register_map.yaml -o register_bank.md
```

### 📊 Export to CSV
```bash
python yml_to_csv.py register_map.yaml register_map.csv
```

### 🔍 Register Bank Schema Validators
- Duplicate address detection
- Bitfield overlap validation
- 4-byte alignment check (with `--address-mode` support)
- Register name format check (`UPPER_SNAKE_CASE`)
- Warnings with `--strict` support

---

## 🖥️ CLI Commands (`rr regbank`)

```bash
rr regbank template        # Scaffold project_regbank.yml skeleton
rr regbank validate        # Validate schema consistency
rr regbank generate        # Full chain: validate → VHDL → hex → constants
rr regbank parse           # Legacy: VHDL package via Make
rr regbank axilite         # Generate AXI-Lite register file entity
rr regbank c-header        # Generate C/C++ headers with field macros
rr regbank c-header --cpp  # Include C++ accessor class
rr regbank html            # Generate HTML register documentation
rr regbank add             # Add register interactively
rr regbank remove NAME     # Remove register by name
```

---

## 🤖 Future Ideas
- Register ABI diff tool (`rr regbank diff`)
- Simulator-aware register dumping
- Rust register bindings

---

Welcome to **spec-driven FPGA development**.
Maintain once. Generate everywhere. ⚡
- No redundant copies of constants
- No manual doc editing
- Fully traceable, testable, and git-friendly

