"""Tests for the fetch command with file:// URLs."""

import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import pytest_asyncio

from asta.resources.cli.index_cli import fetch_content_by_protocol
from asta.resources.document_store.local_index import LocalIndexDocumentStore
from asta.resources.model import DocumentMetadata


@pytest.fixture
def temp_index_path():
    """Create a temporary directory for test index files"""
    with tempfile.TemporaryDirectory() as tmpdir:
        index_path = Path(tmpdir) / ".asta" / "documents" / "index.yaml"
        yield index_path


@pytest_asyncio.fixture
async def store(temp_index_path):
    """Create a LocalIndexDocumentStore instance for testing"""
    store = LocalIndexDocumentStore(
        index_path=str(temp_index_path),
    )
    async with store:
        yield store


@pytest.fixture
def temp_file():
    """Create a temporary file for testing file:// URLs."""
    with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".txt") as f:
        f.write("This is test content.\nLine 2.\nLine 3.\n")
        temp_path = f.name

    yield temp_path

    # Cleanup
    Path(temp_path).unlink(missing_ok=True)


@pytest.mark.asyncio
async def test_file_protocol_url_validation(store, temp_file):
    """Test that file:// URLs are accepted by validation."""
    doc = DocumentMetadata(
        uri="",
        name="Test File Protocol Document",
        url=f"file://{temp_file}",
        summary="Test document with file:// protocol",
        mime_type="text/plain",
        tags=["test"],
    )

    # Should not raise ValidationError
    uuid = await store.store(doc)
    assert len(uuid) == 10

    # Verify stored correctly
    retrieved = await store.get(uuid)
    assert retrieved is not None
    # URL may be normalized to canonical path (e.g., /var -> /private/var on macOS)
    assert retrieved.url.startswith("file://")
    assert Path(temp_file).name in retrieved.url
    assert retrieved.mime_type == "text/plain"


@pytest.mark.asyncio
async def test_supported_url_protocols(store):
    """Test that only supported URL protocols are accepted."""
    supported_protocols = [
        "http://example.com/doc.pdf",
        "https://example.com/doc.pdf",
        "file:///path/to/document.pdf",
        "s3://my-bucket/path/to/doc.pdf",
        "gs://my-bucket/path/to/doc.pdf",
    ]

    for i, url in enumerate(supported_protocols):
        protocol = url.split("://")[0]
        doc = DocumentMetadata(
            uuid="",
            name=f"Test Document {i}",
            url=url,
            summary=f"Test document with {protocol} protocol",
            mime_type="application/pdf",
        )

        # Should not raise ValidationError
        uuid = await store.store(doc)
        assert len(uuid) == 10

        # Verify it was stored correctly
        retrieved = await store.get(uuid)
        assert retrieved is not None
        assert retrieved.url == url


@pytest.mark.asyncio
async def test_file_protocol_with_spaces_in_path(store):
    """Test that file:// URLs with spaces in path are handled correctly."""
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create file with spaces in path
        test_dir = Path(temp_dir) / "test folder with spaces"
        test_dir.mkdir()
        test_file = test_dir / "test document.txt"
        test_file.write_text("Content with spaces in path")

        doc = DocumentMetadata(
            uuid="",
            name="Test File with Spaces",
            url=f"file://{test_file}",
            summary="Test document with spaces in file path",
            mime_type="text/plain",
        )

        uuid = await store.store(doc)
        assert len(uuid) == 10

        retrieved = await store.get(uuid)
        assert retrieved is not None
        # URL may be normalized to canonical path (e.g., /var -> /private/var on macOS)
        assert retrieved.url.startswith("file://")
        assert "test folder with spaces" in retrieved.url
        assert "test document.txt" in retrieved.url


@pytest.mark.asyncio
async def test_multiple_file_protocol_documents(store, temp_file):
    """Test storing and retrieving multiple file:// protocol documents."""
    # Create additional temp files
    temp_files = [temp_file]

    with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".txt") as f:
        f.write("Second test file content")
        temp_files.append(f.name)

    with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".txt") as f:
        f.write("Third test file content")
        temp_files.append(f.name)

    try:
        uris = []
        for i, file_path in enumerate(temp_files):
            doc = DocumentMetadata(
                uri="",
                name=f"Test File {i+1}",
                url=f"file://{file_path}",
                summary=f"Test file number {i+1}",
                mime_type="text/plain",
            )
            uri = await store.store(doc)
            uris.append(uri)

        # Verify all documents are stored
        assert len(uris) == 3
        all_docs = await store.list_docs()
        file_docs = [d for d in all_docs if d.url.startswith("file://")]
        assert len(file_docs) == 3

        # Verify each can be retrieved
        for uri in uris:
            retrieved = await store.get(uri)
            assert retrieved is not None
            assert retrieved.url.startswith("file://")

    finally:
        # Cleanup temp files
        for file_path in temp_files[1:]:  # Skip first one (handled by fixture)
            Path(file_path).unlink(missing_ok=True)


def test_fetch_content_by_protocol_http():
    """Test fetch_content_by_protocol uses curl for HTTP URLs."""
    with patch("subprocess.run") as mock_run:
        mock_result = MagicMock()
        mock_result.stdout = b"http content"
        mock_run.return_value = mock_result

        content = fetch_content_by_protocol("http://example.com/doc.pdf")

        assert content == b"http content"
        mock_run.assert_called_once_with(
            ["curl", "-L", "-f", "-s", "http://example.com/doc.pdf"],
            capture_output=True,
            check=True,
        )


def test_fetch_content_by_protocol_https():
    """Test fetch_content_by_protocol uses curl for HTTPS URLs."""
    with patch("subprocess.run") as mock_run:
        mock_result = MagicMock()
        mock_result.stdout = b"https content"
        mock_run.return_value = mock_result

        content = fetch_content_by_protocol("https://example.com/doc.pdf")

        assert content == b"https content"
        mock_run.assert_called_once_with(
            ["curl", "-L", "-f", "-s", "https://example.com/doc.pdf"],
            capture_output=True,
            check=True,
        )


def test_fetch_content_by_protocol_file():
    """Test fetch_content_by_protocol uses curl for file:// URLs."""
    with patch("subprocess.run") as mock_run:
        mock_result = MagicMock()
        mock_result.stdout = b"file content"
        mock_run.return_value = mock_result

        content = fetch_content_by_protocol("file:///path/to/doc.pdf")

        assert content == b"file content"
        mock_run.assert_called_once_with(
            ["curl", "-L", "-f", "-s", "file:///path/to/doc.pdf"],
            capture_output=True,
            check=True,
        )


def test_fetch_content_by_protocol_s3():
    """Test fetch_content_by_protocol uses AWS CLI for S3 URLs."""
    with patch("subprocess.run") as mock_run:
        mock_result = MagicMock()
        mock_result.stdout = b"s3 content"
        mock_run.return_value = mock_result

        content = fetch_content_by_protocol("s3://my-bucket/path/to/doc.pdf")

        assert content == b"s3 content"
        mock_run.assert_called_once_with(
            ["aws", "s3", "cp", "s3://my-bucket/path/to/doc.pdf", "-"],
            capture_output=True,
            check=True,
        )


def test_fetch_content_by_protocol_gs():
    """Test fetch_content_by_protocol uses gsutil for GCS URLs."""
    with patch("subprocess.run") as mock_run:
        mock_result = MagicMock()
        mock_result.stdout = b"gs content"
        mock_run.return_value = mock_result

        content = fetch_content_by_protocol("gs://my-bucket/path/to/doc.pdf")

        assert content == b"gs content"
        mock_run.assert_called_once_with(
            ["gsutil", "cat", "gs://my-bucket/path/to/doc.pdf"],
            capture_output=True,
            check=True,
        )


def test_fetch_content_by_protocol_unsupported():
    """Test fetch_content_by_protocol raises ValueError for unsupported protocols."""
    with pytest.raises(ValueError) as exc_info:
        fetch_content_by_protocol("ftp://example.com/doc.pdf")

    assert "Unsupported protocol: ftp" in str(exc_info.value)
    assert "http, https, file, s3, gs" in str(exc_info.value)


def test_fetch_content_by_protocol_no_protocol():
    """Test fetch_content_by_protocol raises ValueError for URLs without protocol."""
    with pytest.raises(ValueError) as exc_info:
        fetch_content_by_protocol("example.com/doc.pdf")

    assert "Unsupported protocol" in str(exc_info.value)


@pytest.mark.asyncio
async def test_fetch_relative_path_document(store, temp_file):
    """Test fetching a document stored with a relative path."""
    # Create a temp file in the index's parent directory
    index_dir = Path(store.index_path).parent
    test_file = index_dir / "test_doc.txt"
    test_file.write_text("Test content for relative path")

    try:
        # Store document with relative path (simulating what normalize_file_url does)
        doc = DocumentMetadata(
            uuid="",
            name="Test Relative Path Document",
            url="test_doc.txt",  # Relative path, no protocol
            summary="Document with relative path URL",
            mime_type="text/plain",
        )

        uuid = await store.store(doc)

        # Verify document is stored with relative path
        retrieved = await store.get(uuid)
        assert retrieved is not None
        assert retrieved.url == "test_doc.txt"  # Should stay as relative path

    finally:
        # Cleanup
        test_file.unlink(missing_ok=True)


@pytest.mark.asyncio
async def test_cmd_fetch_with_relative_path(temp_index_path):
    """Test the full cmd_fetch workflow with a relative path URL."""
    import argparse

    from asta.resources.cli.index_cli import cmd_fetch

    # Setup: Create index directory and a test file
    index_dir = temp_index_path.parent
    index_dir.mkdir(parents=True, exist_ok=True)

    # Create a test file in the repo root (index parent)
    test_file = index_dir / "test_document.pdf"
    test_content = b"PDF test content for relative path"
    test_file.write_bytes(test_content)

    # Output file for fetch
    output_file = index_dir / "fetched_output.pdf"

    try:
        # Create a document with relative path
        store = LocalIndexDocumentStore(index_path=str(temp_index_path))
        async with store:
            doc = DocumentMetadata(
                uuid="",
                name="Test PDF",
                url="test_document.pdf",  # Relative path
                summary="Test document",
                mime_type="application/pdf",
            )
            uuid = await store.store(doc)

        # Mock cmd_fetch arguments to write to file
        args = argparse.Namespace(
            uuid=uuid,
            output=str(output_file),
            force=False,
            max_age=7,
            quiet=True,
            config_overrides={"index_path": str(temp_index_path)},
        )

        # Run fetch command
        await cmd_fetch(args)

        # Verify content was fetched correctly
        assert output_file.exists()
        fetched_content = output_file.read_bytes()
        assert fetched_content == test_content

    finally:
        # Cleanup
        test_file.unlink(missing_ok=True)
        output_file.unlink(missing_ok=True)
