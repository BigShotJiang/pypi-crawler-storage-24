# -*- coding: utf-8 -*-
#
#    Project: Fast Azimuthal integration
#             https://github.com/silx-kit/pyFAI
#
#    Copyright (C) 2014-2022 European Synchrotron Radiation Facility, Grenoble, France
#
#    Principal author:       Jérôme Kieffer (Jerome.Kieffer@ESRF.eu)
#
#  Permission is hereby granted, free of charge, to any person obtaining a copy
#  of this software and associated documentation files (the "Software"), to deal
#  in the Software without restriction, including without limitation the rights
#  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#  copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#  .
#  The above copyright notice and this permission notice shall be included in
#  all copies or substantial portions of the Software.
#  .
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#  THE SOFTWARE.

"""

Contains the directory name where data are:
 * gui directory with graphical user interface files
 * openCL directory with OpenCL kernels
 * calibrants directory with d-spacing files describing calibrants
 * testimages: if does not exist: create it.

This file is very short and simple in such a way to be mangled by installers
It is used by pyFAI.utils._get_data_path

See bug #144 for discussion about implementation
https://github.com/silx-kit/pyFAI/issues/144
"""

__author__ = "Jérôme Kieffer"
__contact__ = "Jerome.Kieffer@ESRF.eu"
__license__ = "MIT"
__copyright__ = "European Synchrotron Radiation Facility, Grenoble, France"
__date__ = "09/07/2025"
__status__ = "development"

import os
import logging
logger = logging.getLogger(__name__)

PYFAI_DATA = "/usr/share/pyFAI"

# testimage contains the directory name where
data_dir = ""
if "PYFAI_DATA" in os.environ:
    data_dir = os.environ.get("PYFAI_DATA")
    if not os.path.exists(data_dir):
        logger.warning("data directory %s does not exist", data_dir)
elif os.path.isdir(PYFAI_DATA):
    data_dir = PYFAI_DATA

# testimages contains the directory name where test images are located
testimages = "pyFAI_testdata"
if "PYFAI_TESTIMAGES" in os.environ:
    testimages = os.environ.get("PYFAI_TESTIMAGES")
