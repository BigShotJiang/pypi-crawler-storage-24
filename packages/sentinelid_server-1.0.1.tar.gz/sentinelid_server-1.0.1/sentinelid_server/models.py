from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class BanType(str, Enum):
    CHEAT = "cheat"
    SOCIAL = "social"


class BanScope(str, Enum):
    GAME = "game"
    PUBLISHER = "publisher"
    GLOBAL = "global"


@dataclass
class DeviceCheckRequest:
    device_id: str
    publisher_id: str
    game_id: str
    alg: str
    payload_b64: str
    sig_b64: str


@dataclass
class BanCategoryCounts:
    active: int
    inactive: int
    total: int


@dataclass
class BanSummary:
    cheat: BanCategoryCounts
    social: BanCategoryCounts


@dataclass
class Reputation:
    cheat_score: float
    social_score: float


@dataclass
class DeviceCheckResponse:
    device_id: str
    publisher_id: str
    game_id: str
    banned: bool
    bans: BanSummary
    reputation: Reputation
    status: str


@dataclass
class CreateBanRequest:
    device_id: str
    ban_type: BanType
    scope: BanScope
    reason_code: str
    expires_at: str | None = None
    details: dict[str, Any] | None = None
    idempotency_key: str | None = None


@dataclass
class CreateBanResponse:
    ban_id: str
    device_id: str
    ban_type: str
    scope: str
    publisher_id: str
    status: str
    game_id: str | None = None


@dataclass
class RevokeBanResponse:
    ban_id: str
    device_id: str
    status: str


@dataclass
class BanItem:
    ban_id: str
    ban_type: str
    scope: str
    publisher_id: str
    reason_code: str
    created_at: str
    game_id: str | None = None
    details_json: str | None = None
    expires_at: str | None = None
    revoked_at: str | None = None


@dataclass
class BanListResponse:
    device_id: str
    status: str
    counts: BanCategoryCounts
    items: list[BanItem]


@dataclass
class PublisherPolicy:
    publisher_id: str
    enforce_game: bool
    enforce_publisher: bool
    enforce_global: bool
    enforce_cheat_global: bool
    enforce_social_global: bool
    rep_include_game: bool
    rep_include_publisher: bool
    rep_include_global: bool
    updated_at: str


@dataclass
class UpdatePolicyRequest:
    enforce_game: bool | None = None
    enforce_publisher: bool | None = None
    enforce_global: bool | None = None
    enforce_cheat_global: bool | None = None
    enforce_social_global: bool | None = None
    rep_include_game: bool | None = None
    rep_include_publisher: bool | None = None
    rep_include_global: bool | None = None
