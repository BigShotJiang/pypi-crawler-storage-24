"""
Reduction feature extractors.
"""
