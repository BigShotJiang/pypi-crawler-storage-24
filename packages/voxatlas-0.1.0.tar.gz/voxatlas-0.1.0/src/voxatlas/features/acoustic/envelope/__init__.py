"""
Envelope feature family.
"""
