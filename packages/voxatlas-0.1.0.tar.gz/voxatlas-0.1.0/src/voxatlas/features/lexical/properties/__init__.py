"""
Lexical property feature family.
"""
