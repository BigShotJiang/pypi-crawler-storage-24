"""
Lexical frequency feature family.
"""
