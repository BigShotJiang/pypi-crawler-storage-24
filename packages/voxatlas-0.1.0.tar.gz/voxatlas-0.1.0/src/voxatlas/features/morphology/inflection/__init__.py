"""
Inflection feature family.
"""
