"""
Morphology feature extractors.
"""
