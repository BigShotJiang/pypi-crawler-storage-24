"""
Lexical utilities for VoxAtlas.
"""
