"""Translation backend router -- delegates to the configured provider."""

from transduck.providers import get_provider
from transduck.providers.prompts import build_messages, build_plural_messages


def translate(source_text, source_lang, target_lang, project_context, string_context, config):
    """Translate a single string using the configured provider."""
    provider = get_provider(config)
    return provider.translate(source_text, source_lang, target_lang, project_context, string_context, config)


def translate_plural(one, other, source_lang, target_lang, project_context, string_context, config):
    """Translate plural forms using the configured provider."""
    provider = get_provider(config)
    return provider.translate_plural(one, other, source_lang, target_lang, project_context, string_context, config)


def supports_batch(config):
    """Check if the configured provider supports batch translation."""
    provider = get_provider(config)
    return getattr(provider, 'supports_batch', False)


def translate_batch(strings, source_lang, target_lang, project_context, config):
    """Translate multiple strings in one call. Only supported by some providers."""
    provider = get_provider(config)
    return provider.translate_batch(strings, source_lang, target_lang, project_context, config)


def translate_plural_batch(plurals, source_lang, target_lang, project_context, config):
    """Translate multiple plural strings in one call. Only supported by some providers."""
    provider = get_provider(config)
    return provider.translate_plural_batch(plurals, source_lang, target_lang, project_context, config)
