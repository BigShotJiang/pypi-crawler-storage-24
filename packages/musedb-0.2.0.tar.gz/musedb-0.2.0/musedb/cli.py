"""MuseDB command-line interface.

Usage::

    musedb init [PATH]          # create .musedb/ in PATH (default: current dir)
    musedb index [PATH]         # index PATH (default: current dir)
    musedb search QUERY         # search indexed files
    musedb read FILENAME        # read a file
    musedb serve-mcp            # start MCP server (stdio, embedded mode)
    musedb serve                # start HTTP+MCP server (embedded mode)

Environment variables (FILEDB_ prefix) still apply. Setting
``FILEDB_BACKEND=sqlite`` activates embedded mode when using
``musedb serve``.
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

try:
    import typer
except ImportError:
    print(
        "typer is required for the CLI. Install it with: pip install musedb[cli]",
        file=sys.stderr,
    )
    sys.exit(1)

app = typer.Typer(
    name="musedb",
    help="MuseDB — AI-native file database",
    add_completion=False,
)


def _run(coro):
    """Run an async coroutine from a synchronous CLI context."""
    return asyncio.run(coro)


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------

@app.command()
def init(
    path: Path = typer.Argument(Path("."), help="Workspace root directory"),
    ocr: bool = typer.Option(True, help="Enable OCR for image/scanned PDFs"),
):
    """Initialise a MuseDB workspace (creates .musedb/ directory)."""
    from app.workspace import Workspace, WorkspaceConfig

    config = WorkspaceConfig(ocr_enabled=ocr)
    ws = Workspace(root=path.resolve(), config=config)

    async def _init():
        await ws.init()
        await ws.close()

    _run(_init())
    typer.echo(f"Workspace initialised at {ws.musedb_dir}")


# ---------------------------------------------------------------------------
# index
# ---------------------------------------------------------------------------

@app.command()
def index(
    path: Path = typer.Argument(Path("."), help="Directory to index"),
    workspace: Path = typer.Option(None, "--workspace", "-w", help="Workspace root (default: PATH)"),
    tags: str = typer.Option("", help="Comma-separated tags to apply"),
):
    """Index all supported files in a directory."""
    from app.workspace import Workspace

    ws_root = workspace or path
    ws = Workspace.open(ws_root)

    parsed_tags = [t.strip() for t in tags.split(",") if t.strip()]

    async def _index():
        await ws.init()
        typer.echo(f"Indexing {path.resolve()} ...")
        result = await ws.index(path)
        await ws.close()
        return result

    result = _run(_index())
    typer.echo(
        f"Done: {result['ingested']} ingested, {result['skipped']} skipped, "
        f"{result['failed']} failed, {result['unsupported']} unsupported"
    )


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------

@app.command()
def search(
    query: str = typer.Argument(..., help="Search query"),
    workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Workspace root"),
    limit: int = typer.Option(10, help="Maximum results"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Search indexed files."""
    from app.workspace import Workspace

    ws = Workspace.open(workspace)

    async def _search():
        await ws.init()
        result = await ws.search(query, limit=limit)
        await ws.close()
        return result

    result = _run(_search())

    if json_output:
        typer.echo(json.dumps(result, indent=2, ensure_ascii=False))
        return

    total = result.get("total", 0)
    typer.echo(f"Found {total} result(s) for '{query}':\n")
    for r in result.get("results", []):
        typer.echo(
            f"  [{r['filename']}] page {r['page_number']} "
            f"(score {r['relevance_score']})"
        )
        if r.get("highlight"):
            typer.echo(f"    {r['highlight'][:120]}")
        typer.echo("")


# ---------------------------------------------------------------------------
# read
# ---------------------------------------------------------------------------

@app.command()
def read(
    filename: str = typer.Argument(..., help="File name or UUID"),
    workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Workspace root"),
    pages: str = typer.Option(None, help="Page/slide/sheet range (e.g. '1-3', 'Revenue')"),
    lines: str = typer.Option(None, help="Line range (e.g. '50-80')"),
    grep: str = typer.Option(None, help="In-file search pattern"),
    numbered: bool = typer.Option(False, "--numbered", "-n", help="Show line numbers"),
    format: str = typer.Option(None, help="Output format: 'json' for spreadsheets"),
):
    """Read a file from the workspace."""
    from app.workspace import Workspace

    ws = Workspace.open(workspace)

    async def _read():
        await ws.init()
        text = await ws.read(
            filename, numbered=numbered, pages=pages,
            lines=lines, grep=grep, format=format,
        )
        await ws.close()
        return text

    text = _run(_read())
    typer.echo(text)


# ---------------------------------------------------------------------------
# serve-mcp (stdio, embedded)
# ---------------------------------------------------------------------------

@app.command(name="serve-mcp")
def serve_mcp(
    workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Workspace root"),
):
    """Start an MCP server in stdio transport (embedded mode, no PostgreSQL needed)."""
    from app.workspace import Workspace

    ws = Workspace.open(workspace)

    async def _start():
        await ws.init()
        typer.echo(
            f"MuseDB MCP server starting (embedded, workspace: {ws.root})",
            err=True,
        )
        # Import and run the MCP server using in-process services
        from mcp_server.server import mcp
        await mcp.run_async(transport="stdio")
        await ws.close()

    _run(_start())


# ---------------------------------------------------------------------------
# serve (HTTP + embedded)
# ---------------------------------------------------------------------------

@app.command()
def serve(
    workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Workspace root"),
    host: str = typer.Option("127.0.0.1", help="Bind host"),
    port: int = typer.Option(8000, help="Bind port"),
):
    """Start the HTTP server in embedded (SQLite) mode."""
    import uvicorn
    from app.config import settings

    # Configure for embedded mode
    settings.backend = "sqlite"
    settings.musedb_dir = workspace.resolve() / ".musedb"

    typer.echo(f"Starting MuseDB HTTP server (embedded) at http://{host}:{port}")
    uvicorn.run("app.main:app", host=host, port=port, reload=False)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    app()


if __name__ == "__main__":
    main()
