# -*- coding: utf-8 -*-
from gshield_pic_sdk.grpc_config import (
    MODEL_LABEL_MAP,
    MODEL_DATA_TYPES,
    MODES_LIST,
    MODES_ALL,
    get_grpc_config,
)


def test_default_config():
    assert "fire" in MODEL_LABEL_MAP
    assert MODEL_LABEL_MAP["fire"] == "fire.txt"
    assert "fire" in MODEL_DATA_TYPES
    assert "porn" in MODES_LIST
    assert "flag" in MODES_LIST
    assert "fire" in MODES_ALL


def test_get_grpc_config_merge():
    cfg = get_grpc_config(custom_data_types={"new_mode": "FP16"})
    assert cfg["data_types"]["new_mode"] == "FP16"
    assert cfg["data_types"]["fire"] == "FP16"
    assert "label_map" in cfg
    assert "modes_list" in cfg
    assert "modes_all" in cfg
