# -*- coding: utf-8 -*-
import pytest
from gshield_pic_sdk import GshieldPicClient
from gshield_pic_sdk.exceptions import GshieldValueError


def test_client_face_only():
    client = GshieldPicClient(face_base_url="http://localhost:8001")
    assert client._face is not None
    assert client._faiss is None
    assert client._grpc is None
    _ = client.face
    with pytest.raises(GshieldValueError, match="faiss_base_url"):
        _ = client.faiss
    with pytest.raises(GshieldValueError, match="triton_url"):
        _ = client.grpc


def test_client_faiss_only():
    client = GshieldPicClient(faiss_base_url="http://localhost:8000")
    assert client._faiss is not None
    _ = client.faiss
    with pytest.raises(GshieldValueError, match="face_base_url"):
        _ = client.face
