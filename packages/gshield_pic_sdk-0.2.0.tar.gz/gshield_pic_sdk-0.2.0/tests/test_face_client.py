# -*- coding: utf-8 -*-
import responses
import pytest
from gshield_pic_sdk.face_client import FaceClient
from gshield_pic_sdk.exceptions import GshieldConnectionError


@responses.activate
def test_face_detect_success():
    responses.add(
        responses.POST,
        "http://localhost:8001/detect",
        json={"faces": [{"name": "u1", "bbox": [0, 0, 10, 10], "det_score": 0.9, "sim_score": 0.8}], "count": 1},
        status=200,
    )
    client = FaceClient("http://localhost:8001")
    out = client.detect(b"\xff\xd8\xff\x00")
    assert out["count"] == 1
    assert len(out["faces"]) == 1
    assert out["faces"][0]["name"] == "u1"


@responses.activate
def test_face_detect_4xx():
    responses.add(responses.POST, "http://localhost:8001/detect", status=400, body="bad request")
    client = FaceClient("http://localhost:8001")
    with pytest.raises(GshieldConnectionError, match="400"):
        client.detect(b"\xff\xd8\xff")
