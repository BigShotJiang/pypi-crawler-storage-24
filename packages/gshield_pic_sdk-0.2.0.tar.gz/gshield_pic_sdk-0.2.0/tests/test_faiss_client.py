# -*- coding: utf-8 -*-
import responses
import pytest
from gshield_pic_sdk.faiss_client import FaissClient
from gshield_pic_sdk.exceptions import GshieldConnectionError


@responses.activate
def test_faiss_match_success():
    responses.add(
        responses.POST,
        "http://localhost:8000/match",
        json={"allowed": True, "in_whitelist": False, "in_blacklist": False, "whitelist_match": None, "blacklist_match": None},
        status=200,
    )
    client = FaissClient("http://localhost:8000")
    out = client.match(b"\xff\xd8\xff")
    assert out["allowed"] is True
    assert out["in_blacklist"] is False


@responses.activate
def test_faiss_blacklist_add():
    responses.add(
        responses.POST,
        "http://localhost:8000/blacklist/add",
        json={"id": 1, "message": "added to blacklist"},
        status=200,
    )
    client = FaissClient("http://localhost:8000")
    out = client.blacklist_add(b"\xff\xd8\xff", description="test")
    assert out["id"] == 1
