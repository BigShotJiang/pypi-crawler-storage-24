# -*- coding: utf-8 -*-
"""统一入口：Face、Faiss、gRPC 子客户端组装。"""
import os
from typing import Optional

from gshield_pic_sdk.exceptions import GshieldValueError
from gshield_pic_sdk.face_client import FaceClient
from gshield_pic_sdk.faiss_client import FaissClient
from gshield_pic_sdk.grpc_client import GrpcInferClient
from gshield_pic_sdk.grpc_config import get_grpc_config


def _env(key: str) -> Optional[str]:
    v = os.environ.get(key, "").strip()
    return v or None


class GshieldPicClient:
    """
    统一客户端：所有 URL 由用户传入（或从环境变量读取），不写死默认地址。
    仅配置了的服务才有对应子客户端，未配置时访问会报错。
    """

    def __init__(
        self,
        face_base_url: Optional[str] = None,
        faiss_base_url: Optional[str] = None,
        triton_url: Optional[str] = None,
        label_dir: Optional[str] = None,
        grpc_config: Optional[dict] = None,
    ):
        face_base_url = face_base_url or _env("GSHIELD_FACE_URL")
        faiss_base_url = faiss_base_url or _env("GSHIELD_FAISS_URL")
        triton_url = triton_url or _env("GSHIELD_TRITON_URL")
        label_dir = label_dir or _env("GSHIELD_LABEL_DIR")

        self._face = FaceClient(face_base_url) if face_base_url else None
        self._faiss = FaissClient(faiss_base_url) if faiss_base_url else None
        self._grpc = None
        if triton_url:
            self._grpc = GrpcInferClient(
                triton_url,
                label_dir=label_dir,
                grpc_config=grpc_config or get_grpc_config(),
            )

    @property
    def face(self) -> FaceClient:
        if self._face is None:
            raise GshieldValueError("face_base_url not configured")
        return self._face

    @property
    def faiss(self) -> FaissClient:
        if self._faiss is None:
            raise GshieldValueError("faiss_base_url not configured")
        return self._faiss

    @property
    def grpc(self) -> GrpcInferClient:
        if self._grpc is None:
            raise GshieldValueError("triton_url not configured")
        return self._grpc
