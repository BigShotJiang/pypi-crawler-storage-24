# -*- coding: utf-8 -*-
"""SDK 自定义异常。"""


class GshieldError(Exception):
    """Base exception for GshieldPicSDK."""


class GshieldConnectionError(GshieldError):
    """网络或服务连接失败（HTTP 4xx/5xx、gRPC 连接失败等）。"""


class GshieldValueError(GshieldError, ValueError):
    """参数错误（如未配置 URL、mode 不存在、图片格式无效）。"""


class GshieldInferError(GshieldError):
    """推理失败（Triton 推理异常等）。"""
