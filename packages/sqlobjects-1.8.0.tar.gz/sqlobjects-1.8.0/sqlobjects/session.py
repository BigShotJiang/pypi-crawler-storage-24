import contextvars
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

from sqlalchemy import CursorResult, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncResult

from .database.manager import get_database, get_default
from .exceptions import convert_sqlalchemy_error


__all__ = ["AsyncSession", "ctx_session", "ctx_sessions", "get_session", "has_session"]

# Explicit session management (highest priority)
_explicit_sessions: contextvars.ContextVar[dict[str, "AsyncSession"]] = contextvars.ContextVar("explicit_sessions")


class AsyncSession:
    """Async database session with smart connection and transaction management.

    Two main usage patterns:
    - Explicit sessions (ctx_session): auto_commit=False, manual transaction control
    - Implicit sessions (get_session): auto_commit=True, automatic transaction commit
    """

    def __init__(self, db_name: str, readonly: bool = True, auto_commit: bool = True):
        """Initialize AsyncSession with lazy connection.

        Args:
            db_name: Database name
            readonly: True for readonly (no transaction), False for transactional
            auto_commit: True to auto-commit transactions (ignored if readonly=True)
        """
        self._db_name = db_name
        self.readonly = readonly
        self.auto_commit = auto_commit and not readonly  # readonly sessions never auto-commit
        self._conn: AsyncConnection | None = None
        self._trans = None

    @property
    def db_name(self) -> str:
        """Database name for this session."""
        return self._db_name

    @property
    def is_active(self) -> bool:
        """Check if session has an active connection."""
        return self._conn is not None and not self._conn.closed

    @property
    def in_transaction(self) -> bool:
        """Check if session is currently in a transaction."""
        return self._trans is not None and self._trans.is_active

    @property
    def bind(self):
        """Get the engine/connection bind for dialect access."""
        if self._conn:
            return self._conn
        # Return engine if no connection yet
        return get_database(self._db_name).engine

    async def execute(self, statement: Any, parameters: Any = None) -> "CursorResult[Any]":
        """Execute statement with automatic transaction management.

        Supports both SQLAlchemy statement objects and raw SQL strings.
        Raw SQL strings are automatically wrapped with text().
        """
        await self._ensure_connection()

        # Auto-wrap string SQL with text()
        if isinstance(statement, str):
            statement = text(statement)

        # Auto-begin transaction for non-readonly sessions
        if not self.readonly and self._trans is None:
            self._trans = await self._conn.begin()  # type: ignore

        try:
            result = await self._conn.execute(statement, parameters)  # type: ignore

            # Auto-commit for implicit sessions
            if self.auto_commit:
                await self.commit()

            # Buffer rows before closing so the connection can be returned to the pool.
            # Readonly sessions only run SELECT queries, so freeze()() is safe.
            # Write sessions with auto_commit need rowcount/inserted_primary_key which
            # are already captured in the CursorResult before close() is called.
            if self.readonly:
                result = result.freeze()()

            return result  # type: ignore[return-value]
        except Exception as e:
            await self._handle_exception(e)
            raise  # unreachable, _handle_exception always raises
        finally:
            # Auto-close connection for implicit sessions to prevent resource leaks
            # This covers both auto_commit write sessions and readonly sessions
            if self.auto_commit or self.readonly:
                await self.close()

    async def stream(self, statement: Any, parameters: Any = None) -> AsyncResult[Any]:
        """Execute statement and return streaming result.

        Supports both SQLAlchemy statement objects and raw SQL strings.
        Raw SQL strings are automatically wrapped with text().

        Note: stream() is not supported with auto_commit=True sessions.
        Use explicit sessions (ctx_session) for streaming operations.
        """
        if self.auto_commit:
            raise ValueError(
                "stream() not supported with auto_commit=True. Use ctx_session() or explicit session management."
            )

        await self._ensure_connection()

        # Auto-wrap string SQL with text()
        if isinstance(statement, str):
            statement = text(statement)

        # Auto-begin transaction for non-readonly sessions
        if not self.readonly and self._trans is None:
            self._trans = await self._conn.begin()  # type: ignore

        try:
            return await self._conn.stream(statement, parameters)  # type: ignore
        except Exception as e:
            await self._handle_exception(e)

    async def commit(self):
        """Commit transaction if exists and not readonly."""
        if self._trans and not self.readonly:
            await self._trans.commit()
            self._trans = None

    async def rollback(self):
        """Rollback transaction if exists and not readonly."""
        if self._trans and not self.readonly:
            await self._trans.rollback()
            self._trans = None

    async def close(self):
        """Close session and cleanup resources."""
        if self._trans:
            try:
                await self._trans.rollback()
            except Exception:  # noqa
                pass
            finally:
                self._trans = None

        if self._conn:
            try:
                await self._conn.close()
            except Exception:  # noqa
                pass
            finally:
                self._conn = None

    async def begin_nested(self):
        """Begin nested transaction (savepoint)."""
        await self._ensure_connection()
        if not self._trans:
            self._trans = await self._conn.begin()  # type: ignore
        return await self._conn.begin_nested()  # type: ignore

    async def _ensure_connection(self):
        """Ensure connection is available with health check."""
        if self._conn is None or self._conn.closed:
            engine = get_database(self._db_name).engine
            self._conn = await engine.connect()
        elif self._conn.invalidated:
            await self._conn.close()
            engine = get_database(self._db_name).engine
            self._conn = await engine.connect()

    async def _handle_exception(self, exc: Exception):
        """Handle exceptions with unified error processing."""
        await self.rollback()

        # Log detailed error for debugging when echo is enabled
        if hasattr(self.bind, "echo") and getattr(self.bind, "echo", False):
            print(f"SQLObjects Session Error: {exc}")
            if hasattr(exc, "statement"):
                print(f"Statement: {exc.statement}")  # type: ignore[reportAttributeAccessIssue]
            if hasattr(exc, "params"):
                print(f"Parameters: {exc.params}")  # type: ignore[reportAttributeAccessIssue]

        if isinstance(exc, SQLAlchemyError):
            raise convert_sqlalchemy_error(exc) from exc
        raise

    async def __aenter__(self) -> "AsyncSession":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit with safe cleanup."""
        try:
            await self.close()
        except Exception:  # noqa
            if exc_type is None:
                raise
            # Ignore cleanup exceptions when original exception exists

    def __getattr__(self, name: str) -> Any:
        """Proxy AsyncConnection methods."""
        if self._conn and hasattr(self._conn, name):
            return getattr(self._conn, name)
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")


class _SessionContextManager:
    """Internal multi-database session context manager.

    Provides automatic session management based on SQLAlchemy Core,
    supporting both readonly and transactional modes with intelligent session reuse.

    Examples:
        >>> # Get readonly session (optimized for SELECT)
        >>> async with SessionContextManager.get_session(readonly=True) as session:
        ...     result = await session.execute(text("SELECT 1"))
        >>> # Get transactional session with auto-commit
        >>> async with SessionContextManager.get_session(readonly=False) as session:
        ...     await session.execute(text("UPDATE users SET status='active'"))
    """

    @classmethod
    def get_session(cls, db_name: str | None = None, readonly: bool = True, auto_commit: bool = True) -> AsyncSession:
        """Get database session with readonly optimization.

        Args:
            db_name: Database name (uses default database if None)
            readonly: True for readonly (no transaction), False for transactional
            auto_commit: True to auto-commit after each operation (ignored if readonly=True)

        Returns:
            AsyncSession instance

        Priority:
            - First try use explicitly set session (ctx_session, ctx_sessions)
            - Create a new AsyncSession with specified parameters if no explicit session
        """
        name = db_name or get_default()

        # Try use explicitly set session first
        try:
            explicit_sessions = _explicit_sessions.get({})
            if name in explicit_sessions:
                return explicit_sessions[name]
        except LookupError:
            pass

        # Create new session as fallback
        return AsyncSession(name, readonly, auto_commit)

    @classmethod
    def set_session(
        cls, session: AsyncSession, db_name: str | None = None
    ) -> contextvars.Token[dict[str, "AsyncSession"]]:
        """Set active session in current context.

        Returns a Token that can be used with reset_session() to restore the
        previous ContextVar state, enabling correct nested ctx_session() behavior.
        """
        name = db_name or get_default()
        try:
            current_sessions = _explicit_sessions.get({})
        except LookupError:
            current_sessions = {}
        new_sessions = current_sessions.copy()
        new_sessions[name] = session
        return _explicit_sessions.set(new_sessions)

    @classmethod
    def reset_session(cls, token: contextvars.Token[dict[str, "AsyncSession"]]) -> None:
        """Restore ContextVar to a previous state using a token from set_session()."""
        _explicit_sessions.reset(token)

    @classmethod
    def clear_session(cls, db_name: str | None = None) -> None:
        """Clear active session from current context."""
        try:
            current_sessions = _explicit_sessions.get({})
            if db_name:
                if db_name in current_sessions:
                    new_sessions = current_sessions.copy()
                    del new_sessions[db_name]
                    _explicit_sessions.set(new_sessions)
            else:
                _explicit_sessions.set({})
        except LookupError:
            pass


@asynccontextmanager
async def ctx_session(db_name: str | None = None) -> AsyncGenerator[AsyncSession, None]:
    """Get async context manager for single database transactional session.

    Creates a transactional session with manual commit control (auto_commit=False).
    Transaction is automatically committed on successful exit or rolled back on exception.

    Args:
        db_name: Database name (uses default database if None)

    Yields:
        AsyncSession: Transactional session with manual commit control
    """
    name = db_name or get_default()
    session = AsyncSession(name, readonly=False, auto_commit=False)

    # Set as explicit session in context, save token for nested restore
    token = _SessionContextManager.set_session(session, name)

    try:
        yield session
        # Auto-commit on successful exit
        await session.commit()
    except Exception:
        # Auto-rollback on exception
        await session.rollback()
        raise
    finally:
        # Cleanup
        await session.close()
        _SessionContextManager.reset_session(token)


@asynccontextmanager
async def ctx_sessions(*db_names: str) -> AsyncGenerator[dict[str, AsyncSession], None]:
    """Get async context manager for multiple database transactional sessions.

    Creates transactional sessions for multiple databases with manual commit control.
    All transactions are automatically committed on successful exit or rolled back on exception.

    Args:
        *db_names: Database names

    Yields:
        dict[str, AsyncSession]: Dictionary mapping database names to sessions
    """
    if not db_names:
        raise ValueError("At least one database name must be provided")

    sessions: dict[str, AsyncSession] = {}
    tokens: list[contextvars.Token[dict[str, AsyncSession]]] = []

    try:
        # Create sessions for all
        for db_name in db_names:
            session = AsyncSession(db_name, readonly=False, auto_commit=False)
            sessions[db_name] = session
            tokens.append(_SessionContextManager.set_session(session, db_name))

        yield sessions

        # Auto-commit all sessions on successful exit
        for session in sessions.values():
            await session.commit()

    except Exception:
        # Auto-rollback all sessions on exception
        for session in sessions.values():
            await session.rollback()
        raise

    finally:
        # Cleanup all sessions
        for session in sessions.values():
            await session.close()
        # Reset tokens in reverse order
        for token in reversed(tokens):
            _SessionContextManager.reset_session(token)


def get_session(
    db_or_name: str | AsyncSession | None = None, readonly: bool = True, auto_commit: bool = True
) -> AsyncSession:
    """Get database session with readonly optimization.

    Args:
        db_or_name: Database name, existing AsyncSession, or None for default database
        readonly: True for readonly (no transaction), False for transactional
        auto_commit: True to auto-commit transactions (ignored if readonly=True)

    Returns:
        AsyncSession instance

    Priority:
        - If db_or_name is an AsyncSession, return it directly
        - First try use explicitly set session (ctx_session, ctx_sessions)
        - Create a new AsyncSession with specified parameters if no explicit session
    """
    if isinstance(db_or_name, AsyncSession):
        return db_or_name
    return _SessionContextManager.get_session(db_or_name, readonly, auto_commit)


def has_session(db_name: str | None = None) -> bool:
    """Check if an explicit session exists in current context.

    Args:
        db_name: Database name (uses default database if None)

    Returns:
        True if explicit session exists, False otherwise
    """
    name = db_name or get_default()
    try:
        explicit_sessions = _explicit_sessions.get({})
        return name in explicit_sessions
    except LookupError:
        return False
