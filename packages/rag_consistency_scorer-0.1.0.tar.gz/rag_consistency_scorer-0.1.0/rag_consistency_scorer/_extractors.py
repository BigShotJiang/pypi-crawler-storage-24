"""
rag_consistency_scorer._extractors
====================================
Atomic-fact extraction from raw LLM answer strings.

Two implementations are provided:
- HeuristicExtractor  — regex-based, zero external deps, always available.
- LLMExtractor        — structured OpenAI chat-completion call, deterministic
                        (temperature=0), with automatic fallback to heuristic.

Both expose a synchronous `.extract(text) → List[str]` interface so the
rest of the package never needs to know which extractor is in use.
"""

from __future__ import annotations

import json
import re
import textwrap
from typing import List, Optional, Tuple


# ---------------------------------------------------------------------------
# Heuristic extractor
# ---------------------------------------------------------------------------

class HeuristicExtractor:
    """
    Rule-based atomic-fact extractor.

    Splits answers on sentence boundaries, normalises bullet lists, and
    further splits long clauses on coordinating conjunctions.

    Parameters
    ----------
    min_length : int
        Minimum character length for a fragment to be kept. Default 15.
    max_clause_length : int
        Clauses longer than this are split on conjunctions. Default 120.
    max_facts : int
        Maximum number of facts to return per answer. Default 40.
    """

    def __init__(
        self,
        min_length: int = 15,
        max_clause_length: int = 120,
        max_facts: int = 40,
    ) -> None:
        self.min_length = min_length
        self.max_clause_length = max_clause_length
        self.max_facts = max_facts

    def extract(self, answer: str) -> List[str]:
        """Return a deduplicated list of atomic-fact strings."""
        # Strip bullet / numbered list markers
        text = re.sub(r"^\s*[-*•]\s+", "", answer, flags=re.MULTILINE)
        text = re.sub(r"^\s*\d+\.\s+", "", text, flags=re.MULTILINE)

        # Split on sentence boundaries
        sentences = re.split(r"(?<=[.!?])\s+", text.strip())
        facts: List[str] = []

        for sent in sentences:
            sent = sent.strip()
            if len(sent) < self.min_length:
                continue
            if len(sent) > self.max_clause_length:
                parts = re.split(
                    r"\s+(?:and|but|however|additionally|furthermore)\s+",
                    sent,
                    flags=re.IGNORECASE,
                )
                facts.extend(p.strip() for p in parts if len(p.strip()) >= self.min_length)
            else:
                facts.append(sent)

        # Deduplicate preserving order
        seen = set()
        deduped = []
        for f in facts:
            key = f.lower()
            if key not in seen:
                seen.add(key)
                deduped.append(f)

        return deduped[: self.max_facts]


# ---------------------------------------------------------------------------
# LLM extractor
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = textwrap.dedent("""
    You are a precise information extraction assistant.
    Your only task is to extract a list of ATOMIC FACTS from the text provided.

    Rules:
    - Each fact must be a single, self-contained claim (one subject + one predicate).
    - Do NOT combine two claims into one fact.
    - Do NOT include opinions, hedges, or meta-commentary ("the document states…").
    - Do NOT include boilerplate, disclaimers, or filler text.
    - Output ONLY valid JSON: a list of strings, e.g. ["fact 1", "fact 2"].
    - No markdown, no preamble, no explanation — JSON list only.
""").strip()


class LLMExtractor:
    """
    Atomic-fact extractor backed by an OpenAI-compatible chat-completion model.

    Uses temperature=0 to make extraction deterministic — removing extractor
    variance from the stability measurement entirely.

    Falls back to HeuristicExtractor on any API or parsing error when
    ``heuristic_fallback=True`` (default).

    Parameters
    ----------
    api_key : str
        OpenAI / Azure OpenAI API key.
    model : str
        Model name or Azure deployment name (e.g. ``"gpt-4o-mini"``).
    api_base : str, optional
        Base URL override for Azure OpenAI or custom endpoints.
        E.g. ``"https://my-resource.openai.azure.com/"``.
    api_version : str, optional
        API version string required by Azure OpenAI.
        E.g. ``"2024-02-01"``.
    max_facts : int
        Cap on extracted facts per answer. Default 40.
    heuristic_fallback : bool
        If True (default), fall back silently to HeuristicExtractor on failure.
    """

    def __init__(
        self,
        api_key: str,
        model: str,
        api_base: Optional[str] = None,
        api_version: Optional[str] = None,
        max_facts: int = 40,
        heuristic_fallback: bool = True,
    ) -> None:
        self.model = model
        self.max_facts = max_facts
        self.heuristic_fallback = heuristic_fallback
        self._fallback = HeuristicExtractor(max_facts=max_facts)
        self._client = self._build_client(api_key, api_base, api_version)

    @staticmethod
    def _build_client(
        api_key: str,
        api_base: Optional[str],
        api_version: Optional[str],
    ):
        """Build a synchronous OpenAI client (standard or Azure)."""
        try:
            import openai  # noqa: PLC0415
        except ImportError as exc:
            raise ImportError(
                "The 'openai' package is required for LLM-based extraction. "
                "Install it with:  pip install openai"
            ) from exc

        if api_base is not None:
            # Azure OpenAI
            return openai.AzureOpenAI(
                api_key=api_key,
                azure_endpoint=api_base,
                api_version=api_version or "2024-02-01",
            )
        return openai.OpenAI(api_key=api_key)

    def extract(self, answer: str) -> List[str]:
        """
        Extract atomic facts from an answer string.

        Returns a deduplicated list of fact strings.
        Falls back to heuristic extraction on any error.
        """
        try:
            response = self._client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user", "content": answer},
                ],
                temperature=0.0,
                max_tokens=1024,
            )
            raw = response.choices[0].message.content.strip()
            # Strip accidental markdown fences
            raw = re.sub(r"^```[a-zA-Z]*\n?", "", raw)
            raw = re.sub(r"\n?```$", "", raw)
            parsed = json.loads(raw)
            if not isinstance(parsed, list):
                raise ValueError("LLM response was not a JSON list.")
            facts = [str(f).strip() for f in parsed if str(f).strip()]
            # Deduplicate preserving order
            seen: set = set()
            deduped = []
            for f in facts:
                if f.lower() not in seen:
                    seen.add(f.lower())
                    deduped.append(f)
            return deduped[: self.max_facts]

        except Exception:  # noqa: BLE001
            if self.heuristic_fallback:
                return self._fallback.extract(answer)
            raise


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def build_extractor(
    extraction_mode: str,
    llm_config: Optional[dict] = None,
) -> "HeuristicExtractor | LLMExtractor":
    """
    Factory: return the correct extractor based on extraction_mode.

    Parameters
    ----------
    extraction_mode : str
        ``"heuristic"`` — no LLM needed.
        ``"llm"``        — requires llm_config.
    llm_config : dict, optional
        Must be provided when extraction_mode="llm". Keys:
          - ``api_key``     (required) : str
          - ``model``       (required) : str
          - ``api_base``    (optional) : str  — Azure endpoint
          - ``api_version`` (optional) : str  — Azure API version
          - ``max_facts``   (optional) : int
          - ``heuristic_fallback`` (optional) : bool

    Raises
    ------
    ValueError
        If extraction_mode is not recognised or llm_config is missing for "llm".
    """
    mode = extraction_mode.lower().strip()
    if mode == "heuristic":
        kw = {}
        if llm_config:
            kw["max_facts"] = llm_config.get("max_facts", 40)
        return HeuristicExtractor(**kw)
    elif mode == "llm":
        if not llm_config:
            raise ValueError(
                "llm_config dict is required when extraction_mode='llm'. "
                "Provide at minimum: {'api_key': '...', 'model': '...'}."
            )
        required = {"api_key", "model"}
        missing = required - set(llm_config)
        if missing:
            raise ValueError(f"llm_config is missing required keys: {missing}")
        return LLMExtractor(
            api_key=llm_config["api_key"],
            model=llm_config["model"],
            api_base=llm_config.get("api_base"),
            api_version=llm_config.get("api_version"),
            max_facts=llm_config.get("max_facts", 40),
            heuristic_fallback=llm_config.get("heuristic_fallback", True),
        )
    else:
        raise ValueError(
            f"Unknown extraction_mode '{extraction_mode}'. "
            "Use 'heuristic' or 'llm'."
        )
