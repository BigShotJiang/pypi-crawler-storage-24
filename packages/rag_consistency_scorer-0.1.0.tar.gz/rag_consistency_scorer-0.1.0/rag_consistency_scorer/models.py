"""
rag_consistency_scorer.models
==============================
Public data models for inputs and outputs.

All classes use plain dataclasses (stdlib only) so the package has no
dependency on pydantic or attrs.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Input
# ---------------------------------------------------------------------------

@dataclass
class QueryBundle:
    """
    A single query and its associated LLM responses (one response per run).

    Parameters
    ----------
    query : str
        The prompt / question sent to the RAG pipeline.
    responses : List[str]
        One answer string per run. Must contain at least 2 responses.
        Recommended minimum: 8 responses (see RunSampler documentation).
    query_id : str, optional
        Optional identifier for this query (used in output and logs).
        Defaults to a truncated hash of the query string.
    """
    query: str
    responses: List[str]
    query_id: Optional[str] = None

    def __post_init__(self) -> None:
        if len(self.responses) < 2:
            raise ValueError(
                f"QueryBundle requires at least 2 responses for MMD comparison; "
                f"got {len(self.responses)}. "
                "Tip: collect 8–15 responses per query for reliable scores."
            )
        if self.query_id is None:
            import hashlib
            self.query_id = "q_" + hashlib.sha256(self.query.encode()).hexdigest()[:8]


# ---------------------------------------------------------------------------
# Per-pair diagnostic
# ---------------------------------------------------------------------------

@dataclass
class PairResult:
    """
    Statistical results for a single (run_i, run_j) pair.

    Attributes
    ----------
    run_i, run_j : int
        Zero-based indices of the two runs being compared.
    mmd2 : float
        Raw (possibly negative) unbiased MMD² estimate.
    p_value : float
        Phipson-Smyth corrected permutation p-value.
    p_value_bh : float
        BH-FDR adjusted p-value across all pairs for this query.
    significant : bool
        True if p_value_bh ≤ alpha (default alpha=0.05).
    """
    run_i: int
    run_j: int
    mmd2: float
    p_value: float
    p_value_bh: float
    significant: bool


# ---------------------------------------------------------------------------
# Per-run outlier info
# ---------------------------------------------------------------------------

@dataclass
class RunDiagnostic:
    """
    Outlier scoring for a single run within a query.

    Attributes
    ----------
    run_index : int
    outlier_score : float
        Mean pairwise MMD² to all other runs. Higher = more anomalous.
    z_score : float
        Bootstrap z-score of the outlier score. z > 2 is suspicious.
    n_facts : int
        Number of atomic facts extracted from this run's response.
    extraction_source : str
        ``"llm"`` or ``"heuristic"`` (or ``"heuristic (llm_error=...)"``).
    """
    run_index: int
    outlier_score: float
    z_score: float
    n_facts: int
    extraction_source: str


# ---------------------------------------------------------------------------
# Per-query output
# ---------------------------------------------------------------------------

@dataclass
class QueryScore:
    """
    Complete stability scoring result for a single query.

    Primary output
    --------------
    stability_score : float
        Interpretable [0, 1] stability score.
        1.0 = perfectly stable; < 0.55 = investigate.
        Derived as exp(-max(0, mmd2_mean) / τ).

    Raw statistics
    --------------
    mmd2_mean : float
        Mean pairwise MMD² across all run pairs. Core metric.
    mmd2_min, mmd2_max : float
        Range of pairwise MMD² values. Large max indicates an outlier run.
    sigma_used : float
        Kernel bandwidth used for this query's computation.
    tau_used : float
        Scale parameter used in the stability_score mapping.
    n_runs : int
        Number of responses that were actually scored.

    Diagnostics
    -----------
    pairs : List[PairResult]
        Per-pair MMD², p-values, and BH significance flags.
    runs : List[RunDiagnostic]
        Per-run outlier scores and fact extraction metadata.
    embedding_validation : dict
        Output of EmbeddingModelValidator checks.
    sigma_diagnostics : dict
        Bandwidth selection details (candidates, power proxies).
    tau_diagnostics : dict
        Tau calibration details.

    Identifiers
    -----------
    query_id : str
    query : str
        Original query string (truncated to 200 chars in repr).
    """
    query_id: str
    query: str
    stability_score: float
    mmd2_mean: float
    mmd2_min: float
    mmd2_max: float
    sigma_used: float
    tau_used: float
    n_runs: int
    pairs: List[PairResult] = field(default_factory=list)
    runs: List[RunDiagnostic] = field(default_factory=list)
    embedding_validation: Dict[str, Any] = field(default_factory=dict)
    sigma_diagnostics: Dict[str, Any] = field(default_factory=dict)
    tau_diagnostics: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        q_short = self.query[:80] + "…" if len(self.query) > 80 else self.query
        return (
            f"QueryScore(id={self.query_id!r}, "
            f"stability={self.stability_score:.3f}, "
            f"mmd2_mean={self.mmd2_mean:.5f}, "
            f"n_runs={self.n_runs}, "
            f"query={q_short!r})"
        )

    def to_dict(self) -> dict:
        """Serialise to a plain dict (JSON-safe, no numpy types)."""
        return {
            "query_id": self.query_id,
            "query": self.query,
            "stability_score": round(self.stability_score, 6),
            "mmd2_mean": round(self.mmd2_mean, 8),
            "mmd2_min": round(self.mmd2_min, 8),
            "mmd2_max": round(self.mmd2_max, 8),
            "sigma_used": round(self.sigma_used, 8),
            "tau_used": round(self.tau_used, 8),
            "n_runs": self.n_runs,
            "pairs": [
                {
                    "run_i": p.run_i,
                    "run_j": p.run_j,
                    "mmd2": round(p.mmd2, 8),
                    "p_value": round(p.p_value, 6),
                    "p_value_bh": round(p.p_value_bh, 6),
                    "significant": p.significant,
                }
                for p in self.pairs
            ],
            "runs": [
                {
                    "run_index": r.run_index,
                    "outlier_score": round(r.outlier_score, 8),
                    "z_score": round(r.z_score, 4),
                    "n_facts": r.n_facts,
                    "extraction_source": r.extraction_source,
                }
                for r in self.runs
            ],
            "embedding_validation": self.embedding_validation,
            "sigma_diagnostics": _json_safe(self.sigma_diagnostics),
            "tau_diagnostics": _json_safe(self.tau_diagnostics),
        }


def _json_safe(obj):
    """Recursively convert numpy scalars/arrays to Python native types."""
    import numpy as np  # noqa: PLC0415
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_json_safe(v) for v in obj]
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    return obj
