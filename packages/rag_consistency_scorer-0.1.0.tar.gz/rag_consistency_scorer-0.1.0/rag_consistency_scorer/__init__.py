"""
rag_consistency_scorer
======================
MMD-based semantic consistency scorer for RAG pipeline outputs.

Quick start
-----------
>>> from rag_consistency_scorer import ConsistencyScorer
>>>
>>> data = [
...     {
...         "query": "What is the boiling point of water?",
...         "responses": [
...             "Water boils at 100 degrees Celsius at sea level.",
...             "The boiling point of water is 100°C (212°F) at standard pressure.",
...             "At 1 atm pressure, water boils at 100 degrees Celsius.",
...             "Water reaches its boiling point at 100°C under normal conditions.",
...             "The boiling point of water is 100 degrees Celsius.",
...             "Under standard atmospheric pressure, water boils at 100°C.",
...             "Water boils at 212 degrees Fahrenheit, which is 100°C.",
...             "The boiling point of water is 373 Kelvin or 100°C.",
...         ],
...     }
... ]
>>>
>>> scorer = ConsistencyScorer()
>>> results = scorer.score(data)
>>> print(results[0])
QueryScore(id='q_...', stability=0.923, mmd2_mean=0.00123, n_runs=8, ...)

Public API
----------
ConsistencyScorer   Main scorer class. Call .score(data) → List[QueryScore].
ScorerConfig        Configuration dataclass.
QueryScore          Per-query output with stability_score + diagnostics.
QueryBundle         Typed input alternative to plain dicts.
PairResult          Per-pair MMD² / p-value diagnostic.
RunDiagnostic       Per-run outlier score diagnostic.
"""

from .scorer import ConsistencyScorer, ScorerConfig
from .models import QueryScore, QueryBundle, PairResult, RunDiagnostic

__all__ = [
    "ConsistencyScorer",
    "ScorerConfig",
    "QueryScore",
    "QueryBundle",
    "PairResult",
    "RunDiagnostic",
]

__version__ = "0.1.0"
