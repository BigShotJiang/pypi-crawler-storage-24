"""
rag_consistency_scorer._embedder
==================================
Thin wrapper around the OpenAI embeddings API.

Responsibilities
----------------
- Batch fact strings into API-sized chunks (default 256 per request).
- L2-normalise every returned vector.
- Cache embeddings per (query, fact) pair within one scorer call so the
  same fact string is never embedded twice.
- Validate that embedding dimensionality is consistent across calls
  (a changed model → dimension change → incomparable MMD² values).
"""

from __future__ import annotations

import hashlib
from typing import Dict, List, Optional, Tuple

import numpy as np


_EMBED_BATCH_SIZE = 256


class EmbeddingEngine:
    """
    Embedding engine with batching, L2 normalisation, and dimension tracking.

    Parameters
    ----------
    api_key : str
        OpenAI / Azure OpenAI API key.
    model : str
        Embedding model name or Azure deployment name.
        E.g. ``"text-embedding-3-small"`` or ``"text-embedding-ada-002"``.
    api_base : str, optional
        Base URL for Azure OpenAI or custom endpoints.
    api_version : str, optional
        Azure API version string.
    batch_size : int
        Max facts per embedding API call. Default 256.
    expected_dim : int, optional
        If set, raises ``DimensionMismatchError`` when the returned
        embedding dimension differs from this value.
    """

    def __init__(
        self,
        api_key: str,
        model: str,
        api_base: Optional[str] = None,
        api_version: Optional[str] = None,
        batch_size: int = _EMBED_BATCH_SIZE,
        expected_dim: Optional[int] = None,
    ) -> None:
        self.model = model
        self.batch_size = batch_size
        self.expected_dim = expected_dim
        self._observed_dim: Optional[int] = None
        self._cache: Dict[str, np.ndarray] = {}
        self._client = self._build_client(api_key, api_base, api_version)

    @staticmethod
    def _build_client(
        api_key: str,
        api_base: Optional[str],
        api_version: Optional[str],
    ):
        try:
            import openai  # noqa: PLC0415
        except ImportError as exc:
            raise ImportError(
                "The 'openai' package is required for embedding. "
                "Install it with:  pip install openai"
            ) from exc

        if api_base is not None:
            return openai.AzureOpenAI(
                api_key=api_key,
                azure_endpoint=api_base,
                api_version=api_version or "2024-02-01",
            )
        return openai.OpenAI(api_key=api_key)

    def _cache_key(self, text: str) -> str:
        return hashlib.sha256(f"{self.model}:{text}".encode()).hexdigest()

    def embed(self, texts: List[str]) -> np.ndarray:
        """
        Embed a list of strings and return an L2-normalised (n, d) array.

        Hits the cache first; only sends uncached texts to the API.
        Raises ``DimensionMismatchError`` if the model returns a different
        dimension than previously observed.

        Parameters
        ----------
        texts : List[str]

        Returns
        -------
        embeddings : ndarray of shape (len(texts), d)
        """
        if not texts:
            raise ValueError("Cannot embed an empty list of texts.")

        # Split into cached vs. uncached
        keys = [self._cache_key(t) for t in texts]
        uncached_indices = [i for i, k in enumerate(keys) if k not in self._cache]
        uncached_texts = [texts[i] for i in uncached_indices]

        if uncached_texts:
            new_vectors = self._fetch_embeddings(uncached_texts)
            for idx, vec in zip(uncached_indices, new_vectors):
                self._cache[keys[idx]] = vec

        # Assemble in original order
        result = np.stack([self._cache[k] for k in keys], axis=0)  # (n, d)
        return result

    def _fetch_embeddings(self, texts: List[str]) -> List[np.ndarray]:
        """
        Call the embeddings API in batches and L2-normalise results.
        """
        all_vectors: List[np.ndarray] = []

        for start in range(0, len(texts), self.batch_size):
            batch = texts[start: start + self.batch_size]
            response = self._client.embeddings.create(
                model=self.model,
                input=batch,
            )
            for item in response.data:
                vec = np.array(item.embedding, dtype=np.float32)
                # L2 normalise
                norm = float(np.linalg.norm(vec))
                if norm > 1e-10:
                    vec = vec / norm
                all_vectors.append(vec)

        # Dimension consistency check
        if all_vectors:
            dim = all_vectors[0].shape[0]
            if self._observed_dim is None:
                self._observed_dim = dim
            elif dim != self._observed_dim:
                raise DimensionMismatchError(
                    f"Embedding dimension changed from {self._observed_dim} to {dim}. "
                    "A model change has occurred. Reset the scorer and recalibrate τ and σ."
                )
            if self.expected_dim and dim != self.expected_dim:
                raise DimensionMismatchError(
                    f"Embedding dim {dim} ≠ expected {self.expected_dim}. "
                    "Check that the correct model endpoint is configured."
                )

        return all_vectors

    def clear_cache(self) -> None:
        """Clear the in-process embedding cache."""
        self._cache.clear()

    @property
    def embedding_dim(self) -> Optional[int]:
        """Return the observed embedding dimension, or None if no calls made yet."""
        return self._observed_dim


class DimensionMismatchError(RuntimeError):
    """Raised when the embedding model returns a different dimension than expected."""
