"""
rag_consistency_scorer._kernel
================================
Low-level, dependency-free kernel and MMD² primitives.

All functions operate on L2-normalised numpy arrays of shape (n, d).
These are intentionally kept as pure functions (no classes, no state)
so they are easily unit-tested and reused across the package.
"""

from __future__ import annotations

import math
from typing import List, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Kernel
# ---------------------------------------------------------------------------

def rbf_kernel_matrix(X: np.ndarray, Y: np.ndarray, sigma: float) -> np.ndarray:
    """
    Compute the RBF (Gaussian) kernel matrix.

    K[i, j] = exp( -||X[i] - Y[j]||² / (2 σ²) )

    Parameters
    ----------
    X : ndarray of shape (n, d)
    Y : ndarray of shape (m, d)
    sigma : float — kernel bandwidth (> 0)

    Returns
    -------
    K : ndarray of shape (n, m)
    """
    if sigma <= 0:
        raise ValueError(f"sigma must be > 0, got {sigma}")
    diff = X[:, None, :] - Y[None, :, :]    # (n, m, d)
    sq_dist = np.sum(diff ** 2, axis=-1)    # (n, m)
    return np.exp(-sq_dist / (2.0 * sigma ** 2))


# ---------------------------------------------------------------------------
# MMD²
# ---------------------------------------------------------------------------

def unbiased_mmd2(X: np.ndarray, Y: np.ndarray, sigma: float) -> float:
    """
    Unbiased U-statistic estimator of MMD² under the RBF kernel.

    Diagonal self-pairs are excluded from within-sample expectations.
    May return small negative values for finite samples; this is statistically
    correct and should NOT be clamped at this level (clamp only at display time).

    Complexity: O(n² + m²) kernel evaluations.

    Parameters
    ----------
    X : ndarray of shape (n, d) — L2-normalised fact embeddings, run A
    Y : ndarray of shape (m, d) — L2-normalised fact embeddings, run B
    sigma : float

    Returns
    -------
    mmd2 : float
    """
    n, m = len(X), len(Y)
    if n < 2 or m < 2:
        # With fewer than 2 facts we cannot form an unbiased estimate.
        return 0.0

    Kxx = rbf_kernel_matrix(X, X, sigma)
    Kyy = rbf_kernel_matrix(Y, Y, sigma)
    Kxy = rbf_kernel_matrix(X, Y, sigma)

    np.fill_diagonal(Kxx, 0.0)
    np.fill_diagonal(Kyy, 0.0)

    term_xx = Kxx.sum() / (n * (n - 1))
    term_yy = Kyy.sum() / (m * (m - 1))
    term_xy = Kxy.mean()

    return float(term_xx + term_yy - 2.0 * term_xy)


# ---------------------------------------------------------------------------
# Permutation test
# ---------------------------------------------------------------------------

def permutation_pvalue(
    X: np.ndarray,
    Y: np.ndarray,
    sigma: float,
    n_permutations: int = 2000,
    seed: int = 0,
) -> Tuple[float, float]:
    """
    One-sided permutation p-value for the null H₀: P = Q.

    Uses the Phipson & Smyth (2010) correction — p ≥ 1/(B+1) — to prevent
    zero p-values that would corrupt downstream BH-FDR correction.

    Parameters
    ----------
    X, Y : ndarray — L2-normalised embeddings for two runs
    sigma : float
    n_permutations : int — number of label permutations (B)
    seed : int — RNG seed for reproducibility

    Returns
    -------
    observed_mmd2 : float
    p_value : float — Phipson-Smyth corrected permutation p-value
    """
    rng = np.random.default_rng(seed)
    obs = unbiased_mmd2(X, Y, sigma)
    n, m = len(X), len(Y)
    Z = np.vstack([X, Y])

    exceed = 0
    for _ in range(n_permutations):
        perm = rng.permutation(n + m)
        Xp, Yp = Z[perm[:n]], Z[perm[n:]]
        if unbiased_mmd2(Xp, Yp, sigma) >= obs:
            exceed += 1

    # Phipson & Smyth correction: minimum p = 1/(B+1)
    p_val = (exceed + 1) / (n_permutations + 1)
    return obs, p_val


# ---------------------------------------------------------------------------
# BH-FDR correction
# ---------------------------------------------------------------------------

def bh_fdr_correction(p_values: List[float], alpha: float = 0.05) -> List[float]:
    """
    Benjamini-Hochberg FDR correction for a list of p-values.

    Parameters
    ----------
    p_values : List[float]
    alpha : float — target FDR level (default 0.05)

    Returns
    -------
    adjusted_p_values : List[float] — BH-adjusted p-values (same order as input)
    """
    m = len(p_values)
    if m == 0:
        return []

    # Rank p-values (ascending), compute BH threshold
    order = sorted(range(m), key=lambda i: p_values[i])
    adjusted = [0.0] * m

    # Step-up procedure
    prev = 1.0
    for rank_rev, idx in enumerate(reversed(order)):
        rank = m - rank_rev        # rank in 1..m (largest first)
        adj = min(prev, p_values[idx] * m / rank)
        adjusted[idx] = adj
        prev = adj

    return adjusted


# ---------------------------------------------------------------------------
# Bandwidth selection
# ---------------------------------------------------------------------------

def median_sigma(
    X: np.ndarray,
    Y: np.ndarray,
    max_sample: int = 500,
    seed: int = 42,
) -> float:
    """
    Classic median heuristic: σ = sqrt( median(‖z-z'‖²) / 2 ).

    Samples at most `max_sample` points from the pooled set to keep
    computation tractable for large fact sets.
    """
    rng = np.random.default_rng(seed)
    Z = np.vstack([X, Y])
    n = len(Z)
    idx = rng.choice(n, size=min(n, max_sample), replace=False)
    Z_sub = Z[idx]
    diff = Z_sub[:, None, :] - Z_sub[None, :, :]
    sq_dists = np.sum(diff ** 2, axis=-1)
    upper = sq_dists[np.triu_indices_from(sq_dists, k=1)]
    med_sq = float(np.median(upper))
    return math.sqrt(max(med_sq, 1e-10) / 2.0)


def power_guided_sigma(
    X: np.ndarray,
    Y: np.ndarray,
    n_candidates: int = 10,
    seed: int = 42,
) -> Tuple[float, dict]:
    """
    Select σ by maximising a proxy for test power over a log-uniform grid
    centred on the median heuristic.

    Power proxy: J(σ) = MMD²(X, Y; σ) / std(K_XY) — higher is better.

    Returns
    -------
    sigma : float — selected bandwidth
    diagnostics : dict
    """
    rng = np.random.default_rng(seed)
    sigma_med = median_sigma(X, Y, seed=seed)

    exponents = np.linspace(-1.0, 1.0, n_candidates)
    candidates = [sigma_med * (10.0 ** float(e)) for e in exponents]

    best_sigma, best_proxy = sigma_med, -math.inf
    proxies = []
    for s in candidates:
        mmd2 = unbiased_mmd2(X, Y, s)
        Kxy = rbf_kernel_matrix(X, Y, s)
        proxy = mmd2 / (float(np.std(Kxy)) + 1e-10)
        proxies.append(proxy)
        if proxy > best_proxy:
            best_proxy, best_sigma = proxy, s

    return best_sigma, {
        "sigma_median_heuristic": sigma_med,
        "sigma_selected": best_sigma,
        "candidates": candidates,
        "power_proxies": proxies,
    }


def select_dataset_sigma(
    run_embeddings: List[np.ndarray],
    n_candidates: int = 10,
    seed: int = 42,
) -> Tuple[float, dict]:
    """
    Pick a single σ shared across all run-pairs by pooling all embeddings
    and running power-guided selection on a random 50/50 split of the pool.
    Ensures MMD² values are on a consistent scale within one dataset.
    """
    rng = np.random.default_rng(seed)
    all_embs = np.vstack(run_embeddings)
    n = len(all_embs)
    half = n // 2
    perm = rng.permutation(n)
    X_split = all_embs[perm[:half]]
    Y_split = all_embs[perm[half: 2 * half]]
    return power_guided_sigma(X_split, Y_split, n_candidates=n_candidates, seed=seed)


# ---------------------------------------------------------------------------
# Outlier detection
# ---------------------------------------------------------------------------

def outlier_scores(
    pairwise_mmd2: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute per-run outlier scores and bootstrap z-scores.

    Parameters
    ----------
    pairwise_mmd2 : ndarray of shape (N, N) — symmetric MMD² matrix,
                    diagonal should be 0.

    Returns
    -------
    scores : ndarray of shape (N,) — mean pairwise MMD² to other runs
    z_scores : ndarray of shape (N,) — bootstrap z-scores (higher = more outlier)
    """
    N = len(pairwise_mmd2)
    rng = np.random.default_rng(0)

    scores = np.array([
        pairwise_mmd2[i, np.arange(N) != i].mean()
        for i in range(N)
    ])

    # Bootstrap mean/std for z-score normalisation
    n_boot = 1000
    boot_means = np.array([
        rng.choice(scores, size=N, replace=True).mean()
        for _ in range(n_boot)
    ])
    mu = float(boot_means.mean())
    std = float(boot_means.std()) + 1e-10
    z = (scores - mu) / std

    return scores, z


# ---------------------------------------------------------------------------
# τ → stability score
# ---------------------------------------------------------------------------

def stability_score(mmd2_mean: float, tau: float) -> float:
    """
    Map mean MMD² to a [0, 1] stability score.

    stability = exp( -max(0, MMD²_mean) / τ )

    1.0 → perfectly stable; values near 0 → highly unstable.
    """
    if tau <= 0:
        raise ValueError(f"tau must be > 0, got {tau}")
    return math.exp(-max(0.0, mmd2_mean) / tau)


def calibrate_tau_from_observed(
    observed_mmd2_values: List[float],
    percentile: float = 75.0,
) -> float:
    """
    Self-calibrating τ: set so that the p-th percentile of observed MMD²
    values maps to a stability score of 0.50.

    τ = MMD²_p / ln(2)

    This ensures the score distribution is spread across [0, 1] rather
    than being compressed near 1 (τ too large) or near 0 (τ too small).
    """
    if not observed_mmd2_values:
        return 0.05  # safe default
    p_val = float(np.percentile(observed_mmd2_values, percentile))
    return max(p_val / math.log(2.0), 1e-6)
