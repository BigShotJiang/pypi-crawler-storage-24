"""
rag_consistency_scorer.scorer
==============================
Main public interface for the RAG consistency scoring package.

Typical usage
-------------
>>> from rag_consistency_scorer import ConsistencyScorer, ScorerConfig
>>>
>>> data = [
...     {
...         "query": "What is the capital of France?",
...         "responses": ["Paris is the capital.", "The capital is Paris.",
...                       "France's capital city is Paris.", ...]
...     },
...     ...
... ]
>>>
>>> # Heuristic extraction (no LLM key needed)
>>> scorer = ConsistencyScorer()
>>> results = scorer.score(data)
>>>
>>> # LLM-backed extraction
>>> scorer = ConsistencyScorer(
...     config=ScorerConfig(
...         extraction_mode="llm",
...         llm_config={
...             "api_key": "sk-...",
...             "model": "gpt-4o-mini",
...         },
...         embedding_config={
...             "api_key": "sk-...",
...             "model": "text-embedding-3-small",
...         },
...     )
... )
>>> results = scorer.score(data)
>>> for r in results:
...     print(r)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

import numpy as np

from ._embedder import EmbeddingEngine
from ._extractors import HeuristicExtractor, build_extractor
from ._kernel import (
    bh_fdr_correction,
    calibrate_tau_from_observed,
    outlier_scores,
    permutation_pvalue,
    select_dataset_sigma,
    stability_score,
    unbiased_mmd2,
)
from .models import PairResult, QueryBundle, QueryScore, RunDiagnostic


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class ScorerConfig:
    """
    Configuration for ConsistencyScorer.

    Extraction
    ----------
    extraction_mode : str
        ``"heuristic"`` (default) — no LLM needed, fast, always available.
        ``"llm"``       — structured LLM call, deterministic (temp=0),
                          requires ``llm_config``.
    llm_config : dict, optional
        Required when extraction_mode="llm". Keys:

        =================== ============= ====================================
        Key                 Required      Description
        =================== ============= ====================================
        ``api_key``         ✓             OpenAI or Azure OpenAI API key
        ``model``           ✓             Model / deployment name
        ``api_base``        –             Azure endpoint URL
        ``api_version``     –             Azure API version (default 2024-02-01)
        ``max_facts``       –             Max facts per response (default 40)
        ``heuristic_fallback`` –          Fall back on LLM error (default True)
        =================== ============= ====================================

    Embedding
    ---------
    embedding_config : dict, optional
        Configuration for the OpenAI embedding model used to encode facts.
        Required when extraction_mode="llm" (you already have an API key).
        Can also be used with heuristic extraction for higher-quality embeddings.

        =================== ============= ====================================
        Key                 Required      Description
        =================== ============= ====================================
        ``api_key``         ✓             OpenAI or Azure OpenAI API key
        ``model``           ✓             Embedding model name
        ``api_base``        –             Azure endpoint URL
        ``api_version``     –             Azure API version
        ``batch_size``      –             Facts per API call (default 256)
        ``expected_dim``    –             Expected embedding dim (safety check)
        ``use_pca``         –             Reduce to ``pca_components`` dims
        ``pca_components``  –             PCA target dim (default 128)
        =================== ============= ====================================

        If ``embedding_config`` is not provided, the scorer uses a lightweight
        deterministic bag-of-words TF-IDF vector fallback so the package
        works with zero external dependencies for quick local testing.

    Statistical
    -----------
    tau : float or None
        Scale parameter for stability_score = exp(-MMD²/τ).
        If None (default), τ is auto-calibrated from the observed MMD²
        distribution using the 75th-percentile rule.
    n_permutations : int
        Permutation test iterations per pair. Default 500.
        (Increase to 2000 for publication-quality p-values.)
    alpha : float
        Significance level for BH-FDR correction. Default 0.05.
    bandwidth_candidates : int
        Number of σ candidates in power-guided bandwidth selection. Default 10.
    seed : int
        Global RNG seed for reproducibility. Default 42.
    """

    extraction_mode: str = "heuristic"
    llm_config: Optional[Dict[str, Any]] = None
    embedding_config: Optional[Dict[str, Any]] = None

    tau: Optional[float] = None
    n_permutations: int = 500
    alpha: float = 0.05
    bandwidth_candidates: int = 10
    seed: int = 42


# ---------------------------------------------------------------------------
# Scorer
# ---------------------------------------------------------------------------

class ConsistencyScorer:
    """
    MMD-based semantic consistency scorer for RAG pipeline outputs.

    Accepts a list of dicts (or QueryBundle objects), scores each query,
    and returns a list of QueryScore objects.

    Parameters
    ----------
    config : ScorerConfig, optional
        Full configuration. Defaults to heuristic extraction with TF-IDF
        embeddings — no API keys needed.

    See Also
    --------
    ScorerConfig : full configuration reference.
    QueryScore   : output schema.
    """

    def __init__(self, config: Optional[ScorerConfig] = None) -> None:
        self.config = config or ScorerConfig()
        self._extractor = build_extractor(
            self.config.extraction_mode,
            self.config.llm_config,
        )
        self._embedder: Optional[EmbeddingEngine] = None
        if self.config.embedding_config:
            ec = self.config.embedding_config
            self._embedder = EmbeddingEngine(
                api_key=ec["api_key"],
                model=ec["model"],
                api_base=ec.get("api_base"),
                api_version=ec.get("api_version"),
                batch_size=ec.get("batch_size", 256),
                expected_dim=ec.get("expected_dim"),
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def score(
        self,
        data: List[Union[Dict[str, Any], QueryBundle]],
    ) -> List[QueryScore]:
        """
        Score a list of query/response bundles.

        Parameters
        ----------
        data : List[dict | QueryBundle]
            Each element must be a dict with keys:
              - ``"query"``     : str — the prompt / question
              - ``"responses"`` : List[str] — one answer per run (≥ 2 required,
                                  8–15 recommended)
              - ``"query_id"``  : str (optional) — identifier

            Or a ``QueryBundle`` dataclass directly.

        Returns
        -------
        List[QueryScore]
            One ``QueryScore`` per input element, in the same order.

        Raises
        ------
        ValueError
            If any item is missing required keys or has fewer than 2 responses.
        TypeError
            If any item is not a dict or QueryBundle.
        """
        bundles = [self._coerce(item) for item in data]
        results: List[QueryScore] = []

        # Auto-calibrate τ across the whole batch if not user-supplied
        # Phase 1: extract + embed all, collect MMD² values
        all_run_embeddings: List[List[np.ndarray]] = []
        all_extraction_meta: List[List[tuple]] = []  # (n_facts, source) per run

        for bundle in bundles:
            run_embs, run_meta = self._extract_and_embed(bundle)
            all_run_embeddings.append(run_embs)
            all_extraction_meta.append(run_meta)

        # Phase 2: select sigma per query, compute pilot MMD² for tau calibration
        all_sigmas: List[float] = []
        all_sigma_diags: List[dict] = []
        pilot_mmd2s: List[float] = []

        for run_embs in all_run_embeddings:
            if len(run_embs) < 2:
                all_sigmas.append(0.1)
                all_sigma_diags.append({})
                continue
            sigma, s_diag = select_dataset_sigma(
                run_embs,
                n_candidates=self.config.bandwidth_candidates,
                seed=self.config.seed,
            )
            all_sigmas.append(sigma)
            all_sigma_diags.append(s_diag)
            # Collect a few MMD² samples for tau calibration
            n = len(run_embs)
            for i in range(min(n, 4)):
                for j in range(i + 1, min(n, 4)):
                    pilot_mmd2s.append(unbiased_mmd2(run_embs[i], run_embs[j], sigma))

        # Phase 3: resolve tau
        tau = self.config.tau
        tau_diag: dict = {}
        if tau is None:
            tau = calibrate_tau_from_observed(
                [max(0.0, v) for v in pilot_mmd2s],
                percentile=75.0,
            )
            tau_diag = {
                "mode": "auto_p75",
                "tau": tau,
                "n_pilot_mmd2": len(pilot_mmd2s),
            }
        else:
            tau_diag = {"mode": "user_supplied", "tau": tau}

        # Phase 4: full scoring per query
        for bundle, run_embs, run_meta, sigma, s_diag in zip(
            bundles, all_run_embeddings, all_extraction_meta,
            all_sigmas, all_sigma_diags
        ):
            qs = self._score_query(
                bundle=bundle,
                run_embs=run_embs,
                run_meta=run_meta,
                sigma=sigma,
                tau=tau,
                sigma_diag=s_diag,
                tau_diag=tau_diag,
            )
            results.append(qs)

        return results

    # ------------------------------------------------------------------
    # Internal: extraction + embedding
    # ------------------------------------------------------------------

    def _extract_and_embed(
        self, bundle: QueryBundle
    ) -> tuple[List[np.ndarray], List[tuple]]:
        """
        For each response in the bundle:
          1. Extract atomic facts
          2. Embed them
          3. L2-normalise (done inside EmbeddingEngine; or in TF-IDF fallback)

        Returns
        -------
        run_embs : List[ndarray shape (k_i, d)]
        run_meta : List[(n_facts, extraction_source)]
        """
        run_embs: List[np.ndarray] = []
        run_meta: List[tuple] = []

        all_facts_per_run: List[List[str]] = []
        all_sources: List[str] = []

        for response in bundle.responses:
            facts = self._extractor.extract(response)
            source = "llm" if self.config.extraction_mode == "llm" else "heuristic"
            all_facts_per_run.append(facts)
            all_sources.append(source)

        for facts, source in zip(all_facts_per_run, all_sources):
            if not facts:
                # Empty fact set — use a single zero vector as placeholder
                dim = self._embedder.embedding_dim or 1 if self._embedder else 1
                run_embs.append(np.zeros((1, dim), dtype=np.float32))
                run_meta.append((0, source))
                continue

            if self._embedder is not None:
                embs = self._embedder.embed(facts)
            else:
                embs = _tfidf_embed(facts)

            # Validate already-normalised: renormalise defensively
            norms = np.linalg.norm(embs, axis=1, keepdims=True)
            embs = embs / np.maximum(norms, 1e-10)

            run_embs.append(embs)
            run_meta.append((len(facts), source))

        return run_embs, run_meta

    # ------------------------------------------------------------------
    # Internal: per-query MMD + stats
    # ------------------------------------------------------------------

    def _score_query(
        self,
        bundle: QueryBundle,
        run_embs: List[np.ndarray],
        run_meta: List[tuple],
        sigma: float,
        tau: float,
        sigma_diag: dict,
        tau_diag: dict,
    ) -> QueryScore:
        N = len(run_embs)

        # --- Pairwise MMD² + permutation p-values ---
        pair_results: List[PairResult] = []
        raw_p_values: List[float] = []
        mmd2_matrix = np.zeros((N, N))

        pair_seed_base = self.config.seed
        for i in range(N):
            for j in range(i + 1, N):
                seed_ij = pair_seed_base + i * 10_000 + j
                obs_mmd2, p_val = permutation_pvalue(
                    run_embs[i],
                    run_embs[j],
                    sigma=sigma,
                    n_permutations=self.config.n_permutations,
                    seed=seed_ij,
                )
                mmd2_matrix[i, j] = obs_mmd2
                mmd2_matrix[j, i] = obs_mmd2
                raw_p_values.append(p_val)
                pair_results.append(
                    PairResult(
                        run_i=i, run_j=j,
                        mmd2=obs_mmd2,
                        p_value=p_val,
                        p_value_bh=0.0,   # filled below
                        significant=False, # filled below
                    )
                )

        # BH-FDR correction across all pairs
        bh_p = bh_fdr_correction(raw_p_values, alpha=self.config.alpha)
        for pr, bh in zip(pair_results, bh_p):
            pr.p_value_bh = bh
            pr.significant = bh <= self.config.alpha

        # --- Aggregate MMD² stats ---
        mmd2_values = [pr.mmd2 for pr in pair_results]
        mmd2_mean = float(np.mean(mmd2_values)) if mmd2_values else 0.0
        mmd2_min  = float(np.min(mmd2_values))  if mmd2_values else 0.0
        mmd2_max  = float(np.max(mmd2_values))  if mmd2_values else 0.0

        # --- Outlier detection ---
        o_scores, z_scores = outlier_scores(mmd2_matrix)

        # --- Per-run diagnostics ---
        run_diagnostics: List[RunDiagnostic] = []
        for idx, (n_facts, src) in enumerate(run_meta):
            run_diagnostics.append(
                RunDiagnostic(
                    run_index=idx,
                    outlier_score=float(o_scores[idx]),
                    z_score=float(z_scores[idx]),
                    n_facts=n_facts,
                    extraction_source=src,
                )
            )

        # Sort diagnostics so the most anomalous run appears first
        run_diagnostics.sort(key=lambda r: r.outlier_score, reverse=True)

        # --- Embedding validation ---
        emb_validation = _validate_embeddings(run_embs)

        # --- Final score ---
        score = stability_score(mmd2_mean, tau)

        return QueryScore(
            query_id=bundle.query_id,
            query=bundle.query,
            stability_score=score,
            mmd2_mean=mmd2_mean,
            mmd2_min=mmd2_min,
            mmd2_max=mmd2_max,
            sigma_used=sigma,
            tau_used=tau,
            n_runs=N,
            pairs=pair_results,
            runs=run_diagnostics,
            embedding_validation=emb_validation,
            sigma_diagnostics=sigma_diag,
            tau_diagnostics=tau_diag,
        )

    # ------------------------------------------------------------------
    # Internal: input coercion
    # ------------------------------------------------------------------

    @staticmethod
    def _coerce(item: Union[Dict[str, Any], QueryBundle]) -> QueryBundle:
        if isinstance(item, QueryBundle):
            return item
        if isinstance(item, dict):
            if "query" not in item:
                raise ValueError(
                    "Each input dict must have a 'query' key. "
                    f"Got keys: {list(item.keys())}"
                )
            if "responses" not in item:
                raise ValueError(
                    "Each input dict must have a 'responses' key "
                    "(a list of answer strings). "
                    f"Got keys: {list(item.keys())}"
                )
            return QueryBundle(
                query=str(item["query"]),
                responses=[str(r) for r in item["responses"]],
                query_id=item.get("query_id"),
            )
        raise TypeError(
            f"Expected a dict or QueryBundle, got {type(item).__name__}."
        )


# ---------------------------------------------------------------------------
# TF-IDF fallback embedder (zero external deps)
# ---------------------------------------------------------------------------

def _tfidf_embed(facts: List[str], dim: int = 64) -> np.ndarray:
    """
    Lightweight deterministic TF-IDF-style bag-of-words vectoriser.

    Used when no embedding_config is provided so the package works
    out-of-the-box with only numpy.

    Not recommended for production — the RBF kernel has limited
    discriminative power on BoW vectors. Provide an embedding_config
    for semantically meaningful scores.
    """
    import re as _re
    import hashlib as _hashlib

    vectors = np.zeros((len(facts), dim), dtype=np.float32)
    for fi, fact in enumerate(facts):
        tokens = _re.findall(r"[a-z]+", fact.lower())
        for tok in set(tokens):
            # Deterministic hash → bucket index
            bucket = int(_hashlib.sha256(tok.encode()).hexdigest(), 16) % dim
            # TF weight: log(1 + count)
            count = tokens.count(tok)
            vectors[fi, bucket] += math.log1p(count)

    # L2 normalise
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    vectors = vectors / np.maximum(norms, 1e-10)
    return vectors


# ---------------------------------------------------------------------------
# Embedding validation helper
# ---------------------------------------------------------------------------

def _validate_embeddings(run_embs: List[np.ndarray]) -> dict:
    """Run lightweight geometry checks and return a diagnostics dict."""
    issues: List[str] = []
    dims = [e.shape[1] for e in run_embs if e.ndim == 2 and len(e)]

    if len(set(dims)) > 1:
        issues.append(f"Inconsistent dims across runs: {set(dims)}")

    observed_dim = dims[0] if dims else None
    if observed_dim and observed_dim > 1024:
        issues.append(
            f"High embedding dim ({observed_dim}). Consider setting "
            "embedding_config['use_pca']=True to reduce power loss."
        )

    for i, embs in enumerate(run_embs):
        if not len(embs):
            continue
        mean_norm = float(np.linalg.norm(embs, axis=1).mean())
        if abs(mean_norm - 1.0) > 0.05:
            issues.append(f"Run {i} not L2-normalised (mean norm={mean_norm:.3f}).")

    return {
        "embedding_dim": observed_dim,
        "issues": issues,
        "passed": len(issues) == 0,
    }
