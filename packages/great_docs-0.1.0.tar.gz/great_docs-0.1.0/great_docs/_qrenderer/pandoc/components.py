"""
Pandoc element components.

Specification: https://pandoc.org/lua-filters.html#element-components-1
"""

from __future__ import annotations

import typing
from dataclasses import dataclass

if typing.TYPE_CHECKING:
    from typing import Optional, Sequence  # pragma: no cover

__all__ = ("Attr",)


@dataclass
class Attr:
    """
    Create a new set of attributes (Attr)
    """

    identifier: Optional[str] = None
    classes: Optional[Sequence[str]] = None
    attributes: Optional[dict[str, str]] = None

    def __str__(self):
        parts = []
        if self.identifier:
            parts.append(f"#{self.identifier}")

        if self.classes:
            parts.append(" ".join(f".{c}" for c in self.classes))

        if self.attributes:
            parts.append(" ".join(f'{k}="{v}"' for k, v in self.attributes.items()))

        return " ".join(parts)

    @property
    def html(self):
        parts = []

        if self.identifier:
            parts.append(f'id="{self.identifier}"')

        if self.classes:
            s = " ".join(c for c in self.classes)
            parts.append(f'class="{s}"')

        if self.attributes:
            parts.append(" ".join(f'{k}="{v}"' for k, v in self.attributes.items()))
        return " ".join(parts)

    @property
    def empty(self) -> bool:
        return not (self.identifier or self.classes or self.attributes)
