﻿#include <cstdlib>
#include <cstdint>
#include <string>

#include "cf_step_abi.h"
#include "cf_step_utils.h"
#include "cf_plugin_table.h"
#include "cf_basic_io_signature_hashes.h"

// Magic indices removed; cf_sig indices come from canonical semantics via siggen.
namespace {
static CfStatusCode call_handle_sink(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::HandleSinkStep;
  if (n_params < S::kParamCount || n_inputs < S::kInputCount || n_outputs < S::kOutputCount) {
    return CF_STATUS_INVALID;
  }
  if (cf_handle_is_empty(&params[S::P_handleUri])) return CF_STATUS_INVALID;
  if (inputs[S::I_data].storage_type != CF_STORAGE_VECTOR_F64 || !inputs[S::I_data].data) {
    return CF_STATUS_INVALID;
  }

  std::string handle_uri = cf_handle_to_string(&params[S::P_handleUri]);
  std::string status = "handled via " + handle_uri;
  return cf_out_string(ctx, &outputs[S::O_status_port], status.c_str());
}

static CfStatusCode call_json_field_select(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::JsonFieldSelectStep;
  if (n_params < S::kParamCount || n_inputs < S::kInputCount || n_outputs < S::kOutputCount) {
    return CF_STATUS_INVALID;
  }
  if (cf_handle_is_empty(&params[S::P_field]) || cf_handle_is_empty(&inputs[S::I_data])) {
    return CF_STATUS_INVALID;
  }

  std::string field = cf_handle_to_string(&params[S::P_field]);
  std::string payload = cf_handle_to_string(&inputs[S::I_data]);
  std::string value;
  if (!cf_extract_json_field(payload, field, value)) return CF_STATUS_INVALID;

  return cf_out_bytes(ctx, &outputs[S::O_value_port], CF_STORAGE_JSON, value.data(), value.size());
}

static CfStatusCode call_json_scalar_to_double(
  CfCallContext* ctx,
  const CfValueHandle*,
  size_t,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::JsonScalarToDoubleStep;
  if (n_inputs < S::kInputCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&inputs[S::I_value_port])) return CF_STATUS_INVALID;

  double value = 0.0;
  if (!cf_try_read_numeric_scalar(&inputs[S::I_value_port], value)) {
    return CF_STATUS_INVALID;
  }
  return cf_out_f64(ctx, &outputs[S::O_value_port], value);
}

static CfStatusCode call_timestamp_to_epoch(
  CfCallContext* ctx,
  const CfValueHandle*,
  size_t,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::TimestampToEpochStep;
  if (n_inputs < S::kInputCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&inputs[S::I_data])) return CF_STATUS_INVALID;

  std::string payload = cf_handle_to_string(&inputs[S::I_data]);
  double epoch = 0.0;
  if (!cf_parse_iso8601_to_epoch(payload, epoch)) {
    epoch = static_cast<double>(std::time(nullptr));
  }
  return cf_out_f64(ctx, &outputs[S::O_value_port], epoch);
}

static CfStatusCode call_epoch_to_timestamp(
  CfCallContext* ctx,
  const CfValueHandle*,
  size_t,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::EpochToTimestampStep;
  if (n_inputs < S::kInputCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&inputs[S::I_value_port])) return CF_STATUS_INVALID;

  double epoch = 0.0;
  if (inputs[S::I_value_port].storage_type == CF_STORAGE_F64 &&
      inputs[S::I_value_port].size >= sizeof(double)) {
    epoch = *reinterpret_cast<const double*>(inputs[S::I_value_port].data);
  } else {
    std::string raw = cf_handle_to_string(&inputs[S::I_value_port]);
    if (!raw.empty() && raw.front() == '"' && raw.back() == '"') {
      raw = raw.substr(1, raw.size() - 2);
    }
    char* end = nullptr;
    epoch = std::strtod(raw.c_str(), &end);
    if (!end || end == raw.c_str()) return CF_STATUS_INVALID;
  }

  std::string ts = cf_format_iso8601(epoch);
  if (ts.empty()) return CF_STATUS_INVALID;
  return cf_out_string(ctx, &outputs[S::O_timestamp], ts.c_str());
}

static CfStatusCode call_report_chart(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle*,
  size_t,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::ReportChartStep;
  if (n_params < S::kParamCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&params[S::P_chartSpec])) return CF_STATUS_INVALID;
  std::string title = cf_handle_to_string(&params[S::P_title]);
  std::string status = "report chart updated";
  if (!title.empty()) {
    status += ": " + title;
  }
  return cf_out_string(ctx, &outputs[S::O_status_port], status.c_str());
}

static CfStatusCode call_report_table(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle*,
  size_t,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::ReportTableStep;
  if (n_params < S::kParamCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  int64_t max_rows = 0;
  if (!cf_read_i64(&params[S::P_maxRows], max_rows) || max_rows < 1) return CF_STATUS_INVALID;
  std::string title = cf_handle_to_string(&params[S::P_title]);
  std::string status = "report table updated";
  if (!title.empty()) {
    status += ": " + title;
  }
  status += " (maxRows=" + std::to_string(max_rows) + ")";
  return cf_out_string(ctx, &outputs[S::O_status_port], status.c_str());
}

static CfStatusCode call_stats_row(
  CfCallContext* ctx,
  const CfValueHandle*,
  size_t n_params,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::StatsRowStep;
  if (n_params < S::kParamCount || n_inputs < S::kInputCount || n_outputs < S::kOutputCount) {
    return CF_STATUS_INVALID;
  }
  if (!inputs[S::I_data].data || inputs[S::I_data].size == 0) return CF_STATUS_INVALID;
  if (inputs[S::I_data].storage_type == CF_STORAGE_VECTOR_F64) return CF_STATUS_INVALID;
  return cf_out_bytes(ctx, &outputs[S::O_data], inputs[S::I_data].storage_type,
                      inputs[S::I_data].data, inputs[S::I_data].size);
}

#define CF_BASIC_IO_STEPS(X) \
  X(cf_generated::kHandleSinkStepIri, cf_generated::kHandleSinkStepSigHash, call_handle_sink, nullptr) \
  X(cf_generated::kJsonFieldSelectStepIri, cf_generated::kJsonFieldSelectStepSigHash, call_json_field_select, nullptr) \
  X(cf_generated::kJsonScalarToDoubleStepIri, cf_generated::kJsonScalarToDoubleStepSigHash, call_json_scalar_to_double, nullptr) \
  X(cf_generated::kTimestampToEpochStepIri, cf_generated::kTimestampToEpochStepSigHash, call_timestamp_to_epoch, nullptr) \
  X(cf_generated::kEpochToTimestampStepIri, cf_generated::kEpochToTimestampStepSigHash, call_epoch_to_timestamp, nullptr) \
  X(cf_generated::kReportChartStepIri, cf_generated::kReportChartStepSigHash, call_report_chart, nullptr) \
  X(cf_generated::kReportTableStepIri, cf_generated::kReportTableStepSigHash, call_report_table, nullptr) \
  X(cf_generated::kStatsRowStepIri, cf_generated::kStatsRowStepSigHash, call_stats_row, nullptr)

}  // namespace

CF_DEFINE_STEP_TABLE(CF_BASIC_IO_STEPS)

