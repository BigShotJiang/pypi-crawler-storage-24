# Standard Library
import re

try:
    # Standard Library
    import tomllib
except ImportError:
    # Third Party
    import tomli as tomllib

# This script prints the minimal version of Openfisca-Core to ensure their compatibility during CI testing
with open("./pyproject.toml", "rb") as file:
    config = tomllib.load(file)
    deps = config["project"]["dependencies"]
    for dep in deps:
        version = re.search(r"openfisca-core\[([^\]]+)\]\s*>=\s*([\d\.]*)", dep)
        if version:
            try:
                print(f"openfisca-core[{version[1]}]=={version[2]}")
            except Exception as e:
                print(f'Error processing "{dep}": {e}')
                exit(1)
