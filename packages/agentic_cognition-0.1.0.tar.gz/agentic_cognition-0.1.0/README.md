# AgenticCognition Python SDK

Longitudinal user modeling for AI agents -- belief revision, world models, and cognitive state tracking.

## Install

```bash
pip install agentic-cognition
```

## Usage

```python
from agentic_cognition import CognitionStore

cs = CognitionStore("project.acog")
cs.create_model("user-prefs", domain="preferences")
cs.update_model("user-prefs", belief="prefers-dark-mode", confidence=0.9)
cs.query_model("user-prefs")
```

Requires the `acog` CLI binary on PATH. Install via:

```bash
curl -fsSL https://agentralabs.tech/install/cognition | bash
```
