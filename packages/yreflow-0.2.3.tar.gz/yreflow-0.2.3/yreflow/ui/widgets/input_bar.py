"""Command input bar widget."""

from collections import deque

from textual.binding import Binding
from textual.events import Key
from textual.message import Message
from textual.widgets import Input

from ..highlighters import CompositeHighlighter, MarkupPreviewHighlighter, SpellCheckHighlighter

from ...commands.completion import (
    detect_completion_context, resolve_names, resolve_exits, resolve_teleport_nodes, CompletionType,
)

# Keys that should pass through to app-level bindings even when input is focused.
_PASSTHROUGH_KEYS = {
    "ctrl+u", "ctrl+w", "ctrl+n", "ctrl+p", "ctrl+f", "ctrl+grave_accent",
    "ctrl+s", "ctrl+t", "ctrl+d", "ctrl+g",
}

# Keys that pass through when nav mode is active (so they reach NavPanel).
_NAV_PASSTHROUGH_KEYS = {
    "up", "down", "left", "right",
    "home", "end", "pageup", "pagedown",
    "escape",
}

_MAX_HISTORY = 20


class InputBar(Input):
    """Single-line command input at the bottom of the screen."""

    DEFAULT_CSS = """
    InputBar {
        dock: bottom;
        margin: 0 0;
        border: solid $accent;
    }
    """

    BINDINGS = [
        Binding("tab", "autocomplete", "Fire Autocomplete", priority=True)
    ]

    class RecallDirected(Message):
        """Posted when the user presses ! to recall a directed message contact."""
        def __init__(self, index: int) -> None:
            super().__init__()
            self.index = index

    def __init__(self, **kwargs):
        self._composite = CompositeHighlighter()
        self._spell_highlighter = SpellCheckHighlighter()
        self._markup_highlighter = MarkupPreviewHighlighter()
        self._composite.register("markup", self._markup_highlighter)
        self._composite.register("spellcheck", self._spell_highlighter)

        super().__init__(
            placeholder="Type a command (say, :pose, >ooc, w Name=msg)...",
            highlighter=self._composite,
            **kwargs,
        )
        self._histories: dict[str, list[str]] = {}
        self._positions: dict[str, int] = {}
        self._active_char: str | None = None
        self._saved_input: dict[str, str] = {}
        self._in_recall_mode: bool = False
        self._recall_index: int = -1
        self._nav_mode: bool = False
        self._autocompleting: bool = False
        self._autocomplete_history: deque[str] = deque()
        self._autocomplete_to: int = -1
        self._autocomplete_length: int = -1

    def set_active_character(self, character: str) -> None:
        """Switch which character's history is active."""
        self._active_char = character
        if character not in self._histories:
            self._histories[character] = []
        self._positions[character] = len(self._histories[character])
        self._saved_input[character] = ""

    def push_history(self, command: str) -> None:
        """Add a command to the active character's history."""
        if not self._active_char or not command:
            return
        history = self._histories[self._active_char]
        if not history or history[-1] != command:
            history.append(command)
            if len(history) > _MAX_HISTORY:
                history.pop(0)
        self._positions[self._active_char] = len(history)
        self._saved_input[self._active_char] = ""

    def set_nav_mode(self, enabled: bool) -> None:
        """Enable/disable navigation mode (arrow keys pass through to NavPanel)."""
        self._nav_mode = enabled

    def cycle_completion(self) -> None:
        """Cycle to the next completion candidate."""
        if not self._autocompleting or not self._autocomplete_history:
            return
        self._autocomplete_history.rotate(-1)
        self.value = self.value[:self._autocomplete_to + 1]
        self.value += self._autocomplete_history[0][self._autocomplete_length:]
        self.cursor_position = len(self.value)

    async def autocomplete(self) -> None:
        ## If the input bar isn't focused, then focus it.
        if not self.has_focus:
            self.focus(False)
            return

        if self._autocompleting:
            self.cycle_completion()
            return

        ctx = detect_completion_context(self.value)
        if ctx.completion_type == CompletionType.NONE or not ctx.prefix:
            return

        controller = self.app.controller
        if not controller:
            return

        char_path = self.app._resolve_char_path(self.app.active_character) if self.app.active_character else None
        player = controller.connection.player

        if ctx.completion_type == CompletionType.EXITS:
            results = resolve_exits(controller.store, ctx.prefix, char_path)
        elif ctx.completion_type == CompletionType.TELEPORT_NODES:
            results = resolve_teleport_nodes(controller.store, ctx.prefix, char_path)
        else:
            results = resolve_names(
                controller.store, ctx.prefix, ctx.completion_type,
                char_path, player, ctx.prose,
            )
        if not results:
            return

        self._autocomplete_to = self.cursor_position - 1
        self._autocomplete_length = len(ctx.prefix)
        self._autocomplete_history = deque(results)
        self._autocompleting = True

        # Append the untyped remainder of the matched name.
        self.value += self._autocomplete_history[0][self._autocomplete_length:]
        self.cursor_position = len(self.value)


    def apply_completions(self, results: list[str], prefix_len: int) -> None:
        """Apply externally-provided completions (e.g. from a plugin).

        Args:
            results: List of completion strings.
            prefix_len: Length of the prefix the user already typed for this slot.
        """
        if not results:
            return
        self._autocomplete_to = self.cursor_position - 1
        self._autocomplete_length = prefix_len
        self._autocomplete_history = deque(results)
        self._autocompleting = True
        self.value += results[0][prefix_len:]
        self.cursor_position = len(self.value)

    async def _on_key(self, event: Key) -> None:
        if event.key == 'backspace' and self._autocompleting:
            self.value = self.value[0:self._autocomplete_to+2]
            self.cursor_position = len(self.value)
        # Don't reset autocomplete state on Tab — it's used for cycling.
        if event.key != "tab":
            self._autocompleting = False

        # In nav mode, let directional keys bubble up to NavPanel
        if self._nav_mode and event.key in _NAV_PASSTHROUGH_KEYS:
            return

        # Reset recall mode on any printable non-! key, or on backspace/delete
        if self._in_recall_mode:
            if event.key in ("backspace", "delete") or (
                event.character and event.character != "!"
            ):
                self._in_recall_mode = False
                self._recall_index = -1

        # ! recall: cycle through directed contacts
        if event.character == "!":
            if self.value == "" or self._in_recall_mode:
                if not self._in_recall_mode:
                    self._recall_index = 0
                else:
                    self._recall_index += 1
                self._in_recall_mode = True
                self.post_message(self.RecallDirected(self._recall_index))
                event.prevent_default()
                return

        if event.key == "up":
            if self._active_char:
                history = self._histories.get(self._active_char, [])
                pos = self._positions.get(self._active_char, 0)
                if pos > 0:
                    if pos == len(history):
                        self._saved_input[self._active_char] = self.value
                    pos -= 1
                    self._positions[self._active_char] = pos
                    self.value = history[pos]
                    self.cursor_position = len(self.value)
            event.prevent_default()
            return

        if event.key == "down":
            if self._active_char:
                history = self._histories.get(self._active_char, [])
                pos = self._positions.get(self._active_char, 0)
                if pos < len(history):
                    pos += 1
                    self._positions[self._active_char] = pos
                    if pos == len(history):
                        self.value = self._saved_input.get(self._active_char, "")
                    else:
                        self.value = history[pos]
                    self.cursor_position = len(self.value)
            event.prevent_default()
            return

        if event.key == "shift+enter":
            self.insert_text_at_cursor("\n")

        await super()._on_key(event)

    # --- Highlighter controls ---

    def toggle_spellcheck(self) -> bool:
        """Toggle spellcheck on/off. Returns new state."""
        new = not self._composite.is_enabled("spellcheck")
        self._composite.set_enabled("spellcheck", new)
        return new

    def toggle_markup_preview(self) -> bool:
        """Toggle markup preview on/off. Returns new state."""
        new = not self._composite.is_enabled("markup")
        self._composite.set_enabled("markup", new)
        return new

    def set_highlighter_state(self, name: str, enabled: bool) -> None:
        """Set a named highlighter's state (used when restoring config)."""
        self._composite.set_enabled(name, enabled)

    def update_spellcheck_words(self, words: set[str]) -> None:
        """Feed custom words (character names, etc.) to the spellchecker."""
        self._spell_highlighter.update_custom_words(words)
