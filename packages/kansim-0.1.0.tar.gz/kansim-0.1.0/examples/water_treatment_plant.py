from kansim import *

class WaterTreatmentPlant(Simulation):

    def __init__(self):
        self.flow_rate = Normal(mean=1000, std=50)
        self.removal_efficiency = Beta(successes=9, failures=1)
        self.operating_cost = Triangular(min=0.10, most_likely=0.15, max=0.25)

        treated = self.flow_rate * self.removal_efficiency
        self.treated_volume = treated
        self.daily_cost = treated * self.operating_cost
        self.pass_rate = treated > 900

        
if __name__ == "__main__":
    result = WaterTreatmentPlant.run(n=10_000, seed=42)
    print(result)
    print(result.result_id)
    print(result.df.describe())