from kansim import Simulation, Normal, Triangular, LogNormal, Boolean

class StartupRunway(Simulation):

    def __init__(self):
        # Financials
        self.initial_cash = 500_000
        self.monthly_burn = Normal(mean=45_000, std=8_000)
        self.monthly_revenue = LogNormal(mean=20_000, std=12_000)

        # Growth
        self.revenue_growth_rate = Triangular(min=0.02, most_likely=0.08, max=0.20)
        self.churn_rate = Triangular(min=0.02, most_likely=0.06, max=0.15)

        # Events
        self.raised_bridge_round = Boolean(p=0.3)
        self.bridge_amount = Normal(mean=150_000, std=50_000) if self.raised_bridge_round else 0
        self.lost_anchor_customer = Boolean(p=0.2)
        self.anchor_revenue_loss = Normal(mean=8_000, std=2_000) if self.lost_anchor_customer else 0

        # Derived
        net_revenue = self.monthly_revenue - self.anchor_revenue_loss
        net_monthly_burn = self.monthly_burn - net_revenue
        total_cash = self.initial_cash + self.bridge_amount

        self.runway_months = total_cash / net_monthly_burn if net_monthly_burn > 0 else 999
        self.default_risk = self.runway_months < 12
        self.healthy = self.runway_months > 18


if __name__=="__main__":
    result = StartupRunway.run(n=10_000, seed=42)
    result.plot_histogram("runway_months")
    result.plot_tornado(target="runway_months")
