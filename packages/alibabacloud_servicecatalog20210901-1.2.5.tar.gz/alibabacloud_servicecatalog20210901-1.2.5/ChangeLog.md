2026-02-03 Version: 1.2.4
- Update API AssociatePrincipalWithPortfolio: add request parameters PrincipalPattern.
- Update API DisassociatePrincipalFromPortfolio: add request parameters PrincipalPattern.
- Update API ListPrincipals: add response parameters Body.Principals.$.PrincipalPattern.
- Update API ListTagOptions: add request parameters MaxResults.
- Update API ListTagOptions: add request parameters NextToken.
- Update API ListTagOptions: add response parameters Body.NextToken.


2026-01-05 Version: 1.2.3
- Generated python 2021-09-01 for servicecatalog.

2024-02-27 Version: 1.2.2
- Update API CreateProduct: add param TemplateType.
- Update API GetProductAsAdmin: update response param.
- Update API GetProductAsEndUser: update response param.
- Update API ListProductsAsAdmin: update response param.
- Update API ListProductsAsEndUser: update response param.


2023-12-26 Version: 1.2.1
- Generated python 2021-09-01 for servicecatalog.

2023-09-28 Version: 1.2.0
- Generated python 2021-09-01 for servicecatalog.

2023-04-17 Version: 1.1.4
- Support TagOption.

2023-03-20 Version: 1.1.3
- Support create approval constraint and approver check and approve provisioned product plan.

2022-07-12 Version: 1.1.2
- Support delete provisioned product plan.

2022-06-29 Version: 1.1.1
- Support provisioned product plan.

2022-05-27 Version: 1.1.0
- Change the format of Parameters and Outputs.

2022-05-18 Version: 1.0.1
- Support endpoint map.

2022-05-18 Version: 1.0.0
- Initial version.

