from mcp_server_meridian import main

main()
