# python_time_functions

example

```
from datetime import datetime, timezone
from modules.time_functions import get_timestamp_unix_millis
# OR
from time_functions import get_timestamp_unix_millis
# OR 
import time_functions

timestamp = datetime.now(timezone.utc)
unix_millis = get_timestamp_unix_millis(timestamp)  # create unix timestamp from obj above

```

## local dev

    pip install pytest build 

## test

    pytest

## build ( create dist artifacts )

    python -m build

## install from location

    python -m  pip install  "C:\Users\corne\Documents\GitHub\python_time_functions\dist\pythom_time_functions-2.1.0-py3-none-any.whl"


### other

    pip3 freeze > requirements.txt

## bad formats I dreamed up for iot/psql. fix with sanitizer fx 

>>> time_functions.timestamp_sanitizer_psql(1729755232184)
1729755232.184
>>> time_functions.timestamp_sanitizer_psql(1729765227856.3)
1729765227.856
>>> time_functions.timestamp_sanitizer_psql(1729765228327.051)
1729765228.327