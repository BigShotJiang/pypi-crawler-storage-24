import logging
from datetime import datetime, timezone
import src.time_fuctions_cornebester.time_functions as time_functions


new_obj = datetime.now(timezone.utc)

iso = time_functions.get_timestamp_iso8601(new_obj)
iso_millis = time_functions.get_timestamp_iso8601_millis(new_obj)
iso_micros = time_functions.get_timestamp_iso8601_micros(new_obj)


unix = time_functions.get_timestamp_unix(new_obj)
unix_millis = time_functions.get_timestamp_unix_millis(new_obj)
unix_micros = time_functions.get_timestamp_unix_micros(new_obj)
unix_with_subseconds = time_functions.get_timestamp_unix_subseconds_decimal(new_obj)


obj_from_iso = time_functions.convert_iso_string_to_datetime_obj(iso)
obj_from_iso_millis = time_functions.convert_iso_string_to_datetime_obj(iso_millis)
obj_from_iso_micros = time_functions.convert_iso_string_to_datetime_obj(iso_micros)

obj_from_unix_seconds = time_functions.convert_unix_to_datetime_obj(unix)
obj_from_unix_milliseconds = time_functions.convert_unix_to_datetime_obj(unix_millis)
obj_from_unix_microseconds = time_functions.convert_unix_to_datetime_obj(unix_micros)

obj_from_unix_seconds_float_millis = time_functions.convert_unix_to_datetime_obj(unix_millis/1000)
obj_from_unix_seconds_float_micros = time_functions.convert_unix_to_datetime_obj(unix_micros/1000000)
obj_from_unix_seconds_float = time_functions.convert_unix_to_datetime_obj(unix_with_subseconds)


def test_convertions_from_sample():
    assert time_functions.convert_unix_to_datetime_obj(1742736574) == time_functions.convert_iso_string_to_datetime_obj("2025-03-23T13:29:34+00:00")


def test_convertions_from_sample2():
    assert time_functions.convert_unix_to_datetime_obj(1742737159020) == time_functions.convert_iso_string_to_datetime_obj("2025-03-23T13:39:19.020Z")


def test_convertions_from_sample3():
    assert time_functions.convert_unix_to_datetime_obj(1742737771434946) == time_functions.convert_iso_string_to_datetime_obj("2025-03-23T13:49:31.434946Z")


def test_convertions_from_sample4():
    assert time_functions.convert_unix_to_datetime_obj(unix) == time_functions.convert_iso_string_to_datetime_obj(iso)


def test_convertions_from_sample5():
    assert time_functions.convert_unix_to_datetime_obj(unix_millis) == time_functions.convert_iso_string_to_datetime_obj(iso_millis)


def test_convertions_from_sample6():
    assert time_functions.convert_unix_to_datetime_obj(unix_micros) == time_functions.convert_iso_string_to_datetime_obj(iso_micros)


def test_convertions_from_sample7():
    assert obj_from_iso == obj_from_unix_seconds


def test_convertions_from_sample8():
    assert obj_from_iso_millis == obj_from_unix_milliseconds


def test_convertions_from_sample9():
    assert obj_from_iso_micros == obj_from_unix_microseconds


def test_convertions_from_sample10():
    assert obj_from_iso_millis == obj_from_unix_seconds_float_millis


def test_convertions_from_sample11():
    assert obj_from_iso_micros == obj_from_unix_seconds_float_micros


def test_convertions_from_sample12():
    assert obj_from_iso_micros == obj_from_unix_seconds_float


def test_convertions_from_sample13():
    assert time_functions.convert_unix_to_datetime_obj(unix_with_subseconds) == time_functions.convert_iso_string_to_datetime_obj(iso_micros)


def test_convertions_from_sample14():
    '''
    # obj_from_iso = time_functions.convert_iso_string_to_datetime_obj("2025-03-23T15:10:25Z")
    # unix_with_subseconds = int(time_functions.get_timestamp_unix_subseconds_decimal(obj_from_iso))
    # unix_with_subseconds == 1742742625
    '''
    assert time_functions.timestamp_parser_psql_millis("2025-03-23T15:10:25Z") == 1742742625


def test_convertions_from_sample15():
    '''
    # obj_from_iso = time_functions.convert_iso_string_to_datetime_obj("2025-03-23T15:10:25.002Z")
    # unix_with_subseconds = time_functions.get_timestamp_unix_subseconds_decimal(obj_from_iso)
    # unix_with_subseconds == 1742742625.002
    '''
    assert time_functions.timestamp_parser_psql_millis("2025-03-23T15:10:25.002Z") == 1742742625.002


def test_convertions_from_sample16():
    '''
    # obj_from_iso = time_functions.convert_iso_string_to_datetime_obj("2025-03-23T15:10:25.002908Z")
    # unix_with_subseconds = time_functions.get_timestamp_unix_subseconds_decimal(obj_from_iso)
    # unix_with_subseconds == 1742742625.002908
    '''
    assert time_functions.timestamp_parser_psql_millis("2025-03-23T15:10:25.002908Z") == 1742742625.002


def test_convertions_from_sample17():
    assert time_functions.timestamp_parser_psql_millis(1742742625) == 1742742625


def test_convertions_from_sample18():
    '''
    postgresql timeformat
    '''
    assert time_functions.timestamp_parser_psql_millis(1742742625.0) == 1742742625.0


def test_convertions_from_sample19():
    '''
    postgresql timeformat
    '''
    assert time_functions.timestamp_parser_psql_millis(1742742625.002) == 1742742625.002


def test_convertions_from_sample20():
    '''
    postgresql timeformat
    '''
    assert time_functions.timestamp_parser_psql_millis(1742742625.002908) == 1742742625.002


def test_convertions_from_sample21():
    '''
    python millis timeformat
    '''
    assert time_functions.timestamp_parser_psql_millis(1742742625002) == 1742742625.002


def test_convertions_from_sample22():
    '''
    python micros timeformat
    '''
    assert time_functions.timestamp_parser_psql_millis(1742742625002908) == 1742742625.002

def test_convertions_from_sample33():
    '''
    postgresql nano timeformat
    '''
    assert time_functions.timestamp_parser_psql_millis(1742742625.002908123) == 1742742625.002


def test_convertions_from_sample32():
    '''
    bad timeformat
    '''
    assert time_functions.timestamp_parser_psql_millis(1742742625002.908) is None


def test_convertions_from_sample34():
    '''
    bad timeformat
    '''
    assert time_functions.timestamp_sanitizer_psql(1729755232184) == 1729755232.184

def test_convertions_from_sample35():
    '''
    bad timeformat
    '''
    assert time_functions.timestamp_sanitizer_psql(1729765227856.3) == 1729765227.856


def test_convertions_from_sample36():
    '''
    bad timeformat
    '''
    assert time_functions.timestamp_sanitizer_psql(1729765228327.051) == 1729765228.327