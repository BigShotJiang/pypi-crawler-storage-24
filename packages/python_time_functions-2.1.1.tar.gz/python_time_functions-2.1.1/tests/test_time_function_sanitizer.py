import src.time_fuctions_cornebester.time_functions as time_functions

def test_convertions_from_sample23():
    assert float(time_functions.timestamp_sanitizer_psql(1742758997)) == 1742758997


def test_convertions_from_sample24():
    '''
    # unix seconds
    '''
    assert int(time_functions.timestamp_sanitizer_psql(1742758997)) == 1742758997


def test_convertions_from_sample25():
    '''
    # unix millis
    '''
    assert float(time_functions.timestamp_sanitizer_psql(1742758997018)) == 1742758997.018


def test_convertions_from_sample26():
    '''
    # unix micros
    '''
    assert float(time_functions.timestamp_sanitizer_psql(1742758997018308)) == 1742758997.018


def test_convertions_from_sample27():
    '''
    # unix micros
    '''
    assert float(time_functions.timestamp_sanitizer_psql(1742758997018308)) == 1742758997.018


def test_convertions_from_sample28():
    '''
    # psql special
    '''
    assert float(time_functions.timestamp_sanitizer_psql(1742758997.018308)) == 1742758997.018


def test_convertions_from_sample29():
    '''
    # psql special
    '''
    assert float(time_functions.timestamp_sanitizer_psql(1742758997.018)) == 1742758997.018


def test_convertions_from_sample30():
    '''
    # bad format
    '''
    assert float(time_functions.timestamp_sanitizer_psql(1742758997018.308)) == 1742758997.018


def test_convertions_from_sample31():
    '''
    # bad format
    '''
    assert float(time_functions.timestamp_sanitizer_psql("2025-03-23T19:43:17.018Z")) == 1742758997.018


def test_convertions_from_sample32():
    assert time_functions.timestamp_sanitizer_psql(1742742625002.908) == 1742742625.002