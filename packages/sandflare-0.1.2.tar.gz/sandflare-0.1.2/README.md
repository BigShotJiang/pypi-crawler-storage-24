# Sandflare Python SDK

The official Python SDK for creating and managing Sandflare sandboxes and managed Postgres databases.

## Install

```bash
pip install sandflare
```

For local development:

```bash
pip install -e sdk/python/
```

## Quick start

```python
from sandflare import Sandbox

sandbox = Sandbox.create("agent")
sandbox.run_code("value = 10")
result = sandbox.run_code("value += 5\nprint(value)")
print(result.stdout)
```

## Environment variables

- `SANDFLARE_API_KEY`: preferred API key
- `SANDFLARE_API_URL`: optional API base URL override
- `PANDAAGENT_API_KEY`: legacy API key alias
- `PANDAAGENT_BASE_URL`: legacy base URL alias

## Build locally

```bash
cd sdk/python
python3 -m pip wheel . --no-deps -w dist/
```

## Publish to PyPI

```bash
cd sdk/python
rm -rf dist/
python3 -m pip wheel . --no-deps -w dist/
python3 -m twine upload dist/*
```

Use a PyPI API token via `TWINE_USERNAME=__token__` and `TWINE_PASSWORD=<pypi-token>`.
