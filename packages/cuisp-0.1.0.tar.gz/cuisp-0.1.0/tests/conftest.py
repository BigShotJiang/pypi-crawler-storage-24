"""Shared test fixtures."""

from __future__ import annotations

import pytest

from cuisp.config import (
    AudioConfig,
    CuispConfig,
    DaemonConfig,
    EnhanceConfig,
    WhisperConfig,
)


@pytest.fixture
def audio_config():
    return AudioConfig()


@pytest.fixture
def whisper_config():
    return WhisperConfig()


@pytest.fixture
def enhance_config():
    return EnhanceConfig(api_key="test-key")


@pytest.fixture
def daemon_config():
    return DaemonConfig()


@pytest.fixture
def config():
    return CuispConfig()
