"""Tests for configuration loading and validation."""

from __future__ import annotations

import pytest

from cuisp.config import CuispConfig, load_config, write_default_config


class TestDefaults:
    def test_audio_defaults(self):
        config = CuispConfig()
        assert config.audio.sample_rate == 16000
        assert config.audio.channels == 1
        assert config.audio.dtype == "float32"
        assert config.audio.device is None

    def test_whisper_defaults(self):
        config = CuispConfig()
        assert config.whisper.model_size == "base"
        assert config.whisper.vad_filter is True
        assert config.whisper.beam_size == 5

    def test_enhance_defaults(self):
        config = CuispConfig()
        assert config.enhance.enabled is True
        assert config.enhance.temperature == 0.3
        assert config.enhance.api_key == ""

    def test_daemon_defaults(self):
        import sys
        config = CuispConfig()
        assert config.daemon.mode == "push_to_talk"
        expected_hotkey = "FN" if sys.platform == "darwin" else "LEFTMETA"
        assert config.daemon.hotkey == expected_hotkey


class TestValidation:
    def test_invalid_model_size_rejected(self):
        with pytest.raises(ValueError, match="model_size must be one of"):
            CuispConfig(whisper={"model_size": "gigantic"})

    def test_negative_sample_rate_rejected(self):
        with pytest.raises(ValueError, match="sample_rate must be positive"):
            CuispConfig(audio={"sample_rate": -1})

    def test_temperature_out_of_range_rejected(self):
        with pytest.raises(ValueError, match="temperature must be between"):
            CuispConfig(enhance={"temperature": 3.0})

    def test_negative_beam_size_rejected(self):
        with pytest.raises(ValueError, match="beam_size must be >= 1"):
            CuispConfig(whisper={"beam_size": 0})

    def test_negative_max_tokens_rejected(self):
        with pytest.raises(ValueError, match="max_tokens must be >= 1"):
            CuispConfig(enhance={"max_tokens": -10})

    def test_valid_model_sizes_accepted(self):
        for size in ("tiny", "base", "small", "medium", "large-v3"):
            config = CuispConfig(whisper={"model_size": size})
            assert config.whisper.model_size == size


class TestLoadConfig:
    def test_missing_file_returns_defaults(self, tmp_path):
        config = load_config(tmp_path / "nonexistent.toml")
        assert config.audio.sample_rate == 16000

    def test_partial_toml_preserves_other_defaults(self, tmp_path):
        config_path = tmp_path / "config.toml"
        config_path.write_text('[whisper]\nmodel_size = "small"\n')
        config = load_config(config_path)
        assert config.whisper.model_size == "small"
        assert config.audio.sample_rate == 16000

    def test_env_var_overrides_file(self, tmp_path, monkeypatch):
        monkeypatch.setenv("CUISP_API_KEY", "sk-test-123")
        config = load_config(tmp_path / "nonexistent.toml")
        assert config.enhance.api_key == "sk-test-123"

    def test_write_and_reload(self, tmp_path):
        path = write_default_config(tmp_path / "config.toml")
        assert path.exists()
        config = load_config(path)
        assert config.whisper.model_size == "base"
