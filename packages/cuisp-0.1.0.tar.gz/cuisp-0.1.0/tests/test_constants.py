"""Tests for central constants and enums."""

from __future__ import annotations

from cuisp.constants import (
    AUDIO_SAMPLE_RATE,
    DaemonMode,
    DisplayServer,
    HotkeyEvent,
    MAX_AUDIO_DURATION,
    MIN_AUDIO_DURATION,
    PromptName,
    WhisperModelSize,
)


class TestConstants:
    def test_sample_rate_is_16khz(self):
        assert AUDIO_SAMPLE_RATE == 16_000

    def test_min_less_than_max_duration(self):
        assert MIN_AUDIO_DURATION < MAX_AUDIO_DURATION

    def test_min_duration_positive(self):
        assert MIN_AUDIO_DURATION > 0


class TestEnums:
    def test_whisper_models_are_strings(self):
        for model in WhisperModelSize:
            assert isinstance(model.value, str)

    def test_display_server_values(self):
        assert DisplayServer.WAYLAND.value == "wayland"
        assert DisplayServer.X11.value == "x11"
        assert DisplayServer.MACOS.value == "macos"
        assert DisplayServer.UNKNOWN.value == "unknown"

    def test_hotkey_events(self):
        assert HotkeyEvent.PRESS.value == "press"
        assert HotkeyEvent.RELEASE.value == "release"

    def test_daemon_modes(self):
        assert DaemonMode.PUSH_TO_TALK.value == "push_to_talk"
        assert DaemonMode.TOGGLE.value == "toggle"

    def test_prompt_names_match_builtins(self):
        from cuisp.enhance.prompts import BUILTIN_PROMPTS
        for name in PromptName:
            assert name in BUILTIN_PROMPTS
