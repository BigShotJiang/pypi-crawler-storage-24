"""Tests for the bar command output formatting and daemon state subscription."""

from __future__ import annotations

import json

from click.testing import CliRunner

from cuisp.cli import main
from cuisp.constants import DaemonState


class TestDaemonState:
    def test_state_values(self):
        assert DaemonState.IDLE.value == "idle"
        assert DaemonState.RECORDING.value == "recording"
        assert DaemonState.TRANSCRIBING.value == "transcribing"
        assert DaemonState.ENHANCING.value == "enhancing"
        assert DaemonState.INJECTING.value == "injecting"

    def test_all_states_are_strings(self):
        for state in DaemonState:
            assert isinstance(state.value, str)


class TestBarCommand:
    def test_bar_invalid_format_rejected(self):
        runner = CliRunner()
        result = runner.invoke(main, ["bar", "-f", "invalid"])
        assert result.exit_code != 0


class TestBarFormatting:
    """Test the bar formatting logic directly."""

    def test_waybar_json_structure(self):
        """Verify waybar JSON has required fields."""
        # Import the formatting logic indirectly by testing the output
        import json as json_mod

        _BAR_MAP = {
            "idle":         {"icon": "○", "text": "",     "class": "idle"},
            "recording":    {"icon": "●", "text": "REC",  "class": "recording"},
            "transcribing": {"icon": "◉", "text": "STT",  "class": "transcribing"},
            "enhancing":    {"icon": "◈", "text": "AI",   "class": "enhancing"},
            "injecting":    {"icon": "◇", "text": "PASTE","class": "injecting"},
        }

        for state_name, info in _BAR_MAP.items():
            line = json_mod.dumps({
                "text": info["icon"],
                "tooltip": f"cuisp: {state_name}",
                "class": info["class"],
                "alt": state_name,
            })
            data = json_mod.loads(line)
            assert "text" in data
            assert "tooltip" in data
            assert "class" in data
            assert "alt" in data
            assert data["class"] == state_name

    def test_all_daemon_states_have_bar_mapping(self):
        """Every DaemonState value should have a bar representation."""
        _BAR_MAP = {"idle", "recording", "transcribing", "enhancing", "injecting"}
        for state in DaemonState:
            assert state.value in _BAR_MAP


class TestSubscribe:
    def test_subscribe_handles_missing_socket(self, tmp_path):
        """subscribe_states should return empty when socket doesn't exist."""
        from cuisp.tray.subscribe import subscribe_states

        states = list(subscribe_states(str(tmp_path / "nonexistent.sock")))
        assert states == []
