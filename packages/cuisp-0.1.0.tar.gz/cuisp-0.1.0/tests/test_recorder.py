"""Tests for AudioStream (no sounddevice dependency required)."""

from __future__ import annotations

import numpy as np

from cuisp.audio.recorder import AudioStream
from cuisp.constants import AUDIO_SAMPLE_RATE


class TestAudioStream:
    def test_empty_stream_returns_empty_array(self):
        stream = AudioStream()
        audio = stream.get_audio()
        assert len(audio) == 0
        assert audio.dtype == np.float32

    def test_append_concatenates_chunks(self):
        stream = AudioStream()
        stream.append(np.ones(1600, dtype=np.float32))
        stream.append(np.zeros(1600, dtype=np.float32))
        audio = stream.get_audio()
        assert len(audio) == 3200
        assert audio[:1600].sum() == 1600.0
        assert audio[1600:].sum() == 0.0

    def test_duration_uses_default_sample_rate(self):
        stream = AudioStream()
        stream.append(np.zeros(AUDIO_SAMPLE_RATE, dtype=np.float32))
        assert abs(stream.duration - 1.0) < 0.01

    def test_append_copies_input(self):
        """Ensure mutations to the original array don't affect the stream."""
        stream = AudioStream()
        chunk = np.ones(100, dtype=np.float32)
        stream.append(chunk)
        chunk[:] = 0  # mutate original
        audio = stream.get_audio()
        assert audio.sum() == 100.0  # stream should still have ones
