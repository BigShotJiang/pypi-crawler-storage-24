"""Tests for AI enhancement: filters, prompts, and constants."""

from __future__ import annotations

import pytest

from cuisp.constants import PromptName
from cuisp.enhance.filters import filter_output
from cuisp.enhance.prompts import BUILTIN_PROMPTS, get_prompt


class TestFilterOutput:
    def test_strips_think_tags(self):
        assert filter_output("<think>reasoning</think>Clean") == "Clean"

    def test_strips_multiline_think_tags(self):
        text = "<think>\nlong\nreasoning\n</think>Result"
        assert filter_output(text) == "Result"

    def test_strips_code_fences(self):
        assert filter_output("```\nHello world\n```") == "Hello world"

    def test_strips_code_fences_with_language(self):
        assert filter_output("```text\nHello world\n```") == "Hello world"

    def test_strips_wrapping_quotes(self):
        assert filter_output('"Hello world"') == "Hello world"

    def test_preserves_short_quotes(self):
        assert filter_output('""') == '""'

    def test_combined_artifacts(self):
        text = '<think>blah</think>```\n"The answer"\n```'
        assert filter_output(text) == "The answer"

    def test_passthrough_clean_text(self):
        assert filter_output("Already clean text.") == "Already clean text."

    def test_strips_whitespace(self):
        assert filter_output("  hello  ") == "hello"


class TestPromptTemplates:
    def test_all_builtins_registered(self):
        for name in PromptName:
            assert name in BUILTIN_PROMPTS

    def test_builtin_prompt_builds_messages(self):
        prompt = get_prompt("default")
        assert prompt.name == "default"
        messages = prompt.build_messages("hello world")
        assert len(messages) == 2
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"
        assert "hello world" in messages[1]["content"]

    def test_context_placeholder_substituted(self):
        prompt = get_prompt("default")
        messages = prompt.build_messages("text", context="some context")
        # context is available in the template even if default templates don't use it
        assert messages[1]["content"]  # should not raise

    def test_unknown_prompt_raises(self):
        with pytest.raises(ValueError, match="Unknown prompt"):
            get_prompt("nonexistent_prompt_xyz")

    def test_custom_prompt_from_toml(self, tmp_path):
        prompts_dir = tmp_path / "prompts"
        prompts_dir.mkdir()
        (prompts_dir / "custom.toml").write_text(
            'system = "You are a custom assistant."\n'
            'user_template = "Input: {text}"\n'
        )
        prompt = get_prompt("custom", config_dir=tmp_path)
        assert prompt.name == "custom"
        assert prompt.system == "You are a custom assistant."
        messages = prompt.build_messages("test input")
        assert "test input" in messages[1]["content"]
