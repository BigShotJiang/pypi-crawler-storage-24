"""Central enums and constants for cuisp.

All top-level knobs, limits, and enumerations live here so that every module
references a single source of truth.  Keep this file flat and dependency-free
(stdlib only).
"""

from __future__ import annotations

from enum import Enum

# ---------------------------------------------------------------------------
# Audio
# ---------------------------------------------------------------------------

AUDIO_SAMPLE_RATE: int = 16_000
"""Default recording sample rate in Hz.  Whisper expects 16 kHz mono."""

AUDIO_CHANNELS: int = 1
AUDIO_DTYPE: str = "float32"

MIN_AUDIO_DURATION: float = 0.3
"""Ignore recordings shorter than this (seconds). Prevents accidental taps."""

MAX_AUDIO_DURATION: float = 300.0
"""Hard cap on a single recording (seconds). Prevents runaway captures."""


# ---------------------------------------------------------------------------
# Whisper
# ---------------------------------------------------------------------------

class WhisperModelSize(str, Enum):
    """Supported faster-whisper model sizes."""
    TINY = "tiny"
    BASE = "base"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large-v3"

DEFAULT_WHISPER_MODEL: str = WhisperModelSize.BASE.value
DEFAULT_COMPUTE_TYPE: str = "int8"
DEFAULT_BEAM_SIZE: int = 5


# ---------------------------------------------------------------------------
# Enhancement
# ---------------------------------------------------------------------------

class PromptName(str, Enum):
    """Built-in prompt template names."""
    DEFAULT = "default"
    EMAIL = "email"
    CHAT = "chat"
    REWRITE = "rewrite"

DEFAULT_LLM_TEMPERATURE: float = 0.3
DEFAULT_LLM_MAX_TOKENS: int = 2048
ENHANCE_HTTP_TIMEOUT: float = 30.0


# ---------------------------------------------------------------------------
# Daemon
# ---------------------------------------------------------------------------

class DaemonMode(str, Enum):
    """Daemon operating modes."""
    PUSH_TO_TALK = "push_to_talk"
    TOGGLE = "toggle"

class DaemonState(str, Enum):
    """Observable daemon states for toolbar/tray consumers."""
    IDLE = "idle"
    RECORDING = "recording"
    TRANSCRIBING = "transcribing"
    ENHANCING = "enhancing"
    INJECTING = "injecting"

import sys as _sys

DEFAULT_HOTKEY: str = "FN" if _sys.platform == "darwin" else "LEFTMETA"


# ---------------------------------------------------------------------------
# Platform
# ---------------------------------------------------------------------------

class DisplayServer(str, Enum):
    """Detected display server protocol."""
    WAYLAND = "wayland"
    X11 = "x11"
    MACOS = "macos"
    UNKNOWN = "unknown"


# ---------------------------------------------------------------------------
# Hotkey
# ---------------------------------------------------------------------------

class HotkeyEvent(str, Enum):
    """Hotkey press/release events forwarded from the listener to the daemon."""
    PRESS = "press"
    RELEASE = "release"
