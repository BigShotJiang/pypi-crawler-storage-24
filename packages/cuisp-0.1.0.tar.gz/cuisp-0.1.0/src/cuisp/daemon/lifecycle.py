"""Daemon process lifecycle management.

Handles daemonization (double-fork), PID file management, and
start/stop/status operations.
"""

from __future__ import annotations

import os
import signal
import sys
from pathlib import Path

from cuisp.config import CuispConfig


def write_pid_file(path: str) -> None:
    """Write the current PID to *path*."""
    Path(path).write_text(str(os.getpid()))


def read_pid_file(path: str) -> int | None:
    """Read PID from *path*. Returns ``None`` if missing or corrupt."""
    p = Path(path)
    if not p.exists():
        return None
    try:
        return int(p.read_text().strip())
    except (ValueError, OSError):
        return None


def remove_pid_file(path: str) -> None:
    """Remove PID file if it exists."""
    try:
        Path(path).unlink()
    except FileNotFoundError:
        pass


def is_daemon_running(config: CuispConfig) -> tuple[bool, int | None]:
    """Check if the daemon process is alive. Returns ``(running, pid)``."""
    pid = read_pid_file(config.daemon.pid_file)
    if pid is None:
        return False, None
    try:
        os.kill(pid, 0)  # signal 0 = existence check
        return True, pid
    except ProcessLookupError:
        remove_pid_file(config.daemon.pid_file)
        return False, None
    except PermissionError:
        return True, pid  # process exists but owned by another user


def start_daemon(config: CuispConfig, foreground: bool = False) -> None:
    """Start the daemon process.

    In background mode, performs a double-fork to fully detach from the
    controlling terminal and redirects stdio to a log file.
    """
    running, pid = is_daemon_running(config)
    if running:
        print(f"Daemon already running (PID {pid})", file=sys.stderr)
        sys.exit(1)

    if not foreground:
        pid = os.fork()
        if pid > 0:
            os._exit(0)  # _exit: skip atexit/Click cleanup in parent
        os.setsid()
        pid = os.fork()
        if pid > 0:
            os._exit(0)

        devnull = open(os.devnull, "r+b")
        os.dup2(devnull.fileno(), sys.stdin.fileno())

        log_dir = Path.home() / ".local" / "state" / "cuisp"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = open(log_dir / "daemon.log", "a")
        os.dup2(log_file.fileno(), sys.stdout.fileno())
        os.dup2(log_file.fileno(), sys.stderr.fileno())

    write_pid_file(config.daemon.pid_file)

    # Clean up stale socket from a previous crash
    socket_path = Path(config.daemon.socket_path)
    if socket_path.exists():
        socket_path.unlink()

    try:
        from cuisp.daemon.server import CuispDaemon

        import asyncio

        daemon = CuispDaemon(config)
        asyncio.run(daemon.run())
    finally:
        remove_pid_file(config.daemon.pid_file)


def stop_daemon(config: CuispConfig) -> None:
    """Send SIGTERM to the running daemon and remove its PID file."""
    running, pid = is_daemon_running(config)
    if not running:
        print("Daemon is not running.", file=sys.stderr)
        return
    os.kill(pid, signal.SIGTERM)
    print(f"Sent SIGTERM to daemon (PID {pid})")
    remove_pid_file(config.daemon.pid_file)
