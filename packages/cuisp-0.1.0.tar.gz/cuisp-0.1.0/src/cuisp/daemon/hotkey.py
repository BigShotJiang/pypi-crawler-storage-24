"""Global hotkey listener for Wayland (evdev), X11 and macOS (pynput).

Each listener runs a blocking loop in a background thread and bridges
key events into the asyncio event loop via ``call_soon_threadsafe``.
"""

from __future__ import annotations

import asyncio
from typing import Awaitable, Callable

from cuisp.config import DaemonConfig
from cuisp.constants import DisplayServer, HotkeyEvent
from cuisp.platform.detect import detect_display_server


class EvdevHotkeyListener:
    """Wayland hotkey via ``/dev/input`` (requires ``input`` group membership)."""

    def __init__(
        self,
        config: DaemonConfig,
        loop: asyncio.AbstractEventLoop,
        callback: Callable[[HotkeyEvent], Awaitable[None]],
    ):
        self._key_name = config.hotkey
        self._loop = loop
        self._callback = callback

    def run(self) -> None:
        """Blocking. Reads keyboard events from ``/dev/input`` devices."""
        import select

        from evdev import InputDevice, categorize, ecodes, list_devices

        key_code = ecodes.ecodes.get(f"KEY_{self._key_name.upper()}")
        if key_code is None:
            raise ValueError(
                f"Unknown key name '{self._key_name}'. "
                f"Use evdev key names like LEFTMETA, RIGHTCTRL, F9, etc."
            )

        devices = [InputDevice(path) for path in list_devices()]
        keyboards = [d for d in devices if ecodes.EV_KEY in d.capabilities()]

        if not keyboards:
            raise RuntimeError(
                "No keyboard devices found. Ensure you are in the 'input' group: "
                "sudo usermod -aG input $USER"
            )

        try:
            while True:
                r, _, _ = select.select(keyboards, [], [])
                for dev in r:
                    for event in dev.read():
                        if event.type != ecodes.EV_KEY:
                            continue
                        key_event = categorize(event)
                        if key_event.scancode != key_code:
                            continue
                        if key_event.keystate == key_event.key_down:
                            self._loop.call_soon_threadsafe(
                                asyncio.ensure_future,
                                self._callback(HotkeyEvent.PRESS),
                            )
                        elif key_event.keystate == key_event.key_up:
                            self._loop.call_soon_threadsafe(
                                asyncio.ensure_future,
                                self._callback(HotkeyEvent.RELEASE),
                            )
        finally:
            for dev in keyboards:
                dev.close()


class PynputHotkeyListener:
    """X11 / macOS hotkey via pynput."""

    # macOS virtual keycodes for keys not in pynput's Key enum
    _MACOS_VK_MAP: dict[str, int] = {
        "fn": 0x3F,
    }

    def __init__(
        self,
        config: DaemonConfig,
        loop: asyncio.AbstractEventLoop,
        callback: Callable[[HotkeyEvent], Awaitable[None]],
    ):
        self._key_name = config.hotkey
        self._loop = loop
        self._callback = callback

    def run(self) -> None:
        """Blocking. Listens for keyboard events via pynput."""
        import sys

        from pynput import keyboard

        name = self._key_name.lower()
        if name in self._MACOS_VK_MAP and sys.platform == "darwin":
            target_key = keyboard.KeyCode.from_vk(self._MACOS_VK_MAP[name])
        else:
            target_key = keyboard.Key[name]

        def on_press(key: keyboard.Key | keyboard.KeyCode) -> None:
            if key == target_key:
                self._loop.call_soon_threadsafe(
                    asyncio.ensure_future,
                    self._callback(HotkeyEvent.PRESS),
                )

        def on_release(key: keyboard.Key | keyboard.KeyCode) -> None:
            if key == target_key:
                self._loop.call_soon_threadsafe(
                    asyncio.ensure_future,
                    self._callback(HotkeyEvent.RELEASE),
                )

        with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
            listener.join()


def create_hotkey_listener(
    config: DaemonConfig,
    loop: asyncio.AbstractEventLoop,
    callback: Callable[[HotkeyEvent], Awaitable[None]],
) -> EvdevHotkeyListener | PynputHotkeyListener:
    """Factory: return the appropriate listener for the detected display server."""
    ds = detect_display_server()
    if ds == DisplayServer.WAYLAND:
        return EvdevHotkeyListener(config, loop, callback)
    return PynputHotkeyListener(config, loop, callback)
