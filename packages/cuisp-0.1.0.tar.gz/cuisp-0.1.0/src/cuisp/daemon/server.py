"""Async daemon core: hotkey listener + Unix socket server + transcription pipeline.

The daemon runs an asyncio event loop with two concurrent tasks:
1. A Unix socket server accepting JSON commands from the CLI.
2. A hotkey listener (in a thread) that triggers the record -> transcribe
   -> enhance -> inject pipeline on key press/release.
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys

import numpy as np

from cuisp.audio.recorder import AudioRecorder, AudioStream
from cuisp.config import CuispConfig
from cuisp.constants import DaemonState, HotkeyEvent, MIN_AUDIO_DURATION
from cuisp.daemon.hotkey import create_hotkey_listener
from cuisp.enhance.client import EnhanceClient
from cuisp.inject.paste import TextInjector
from cuisp.stt.whisper import WhisperTranscriber

logger = logging.getLogger("cuisp.daemon")


class CuispDaemon:
    """Main daemon process managing hotkey, transcription, and text injection."""

    def __init__(self, config: CuispConfig):
        self.config = config
        self.recorder = AudioRecorder(config.audio)
        self.transcriber = WhisperTranscriber(config.whisper)
        self.enhancer: EnhanceClient | None = (
            EnhanceClient(config.enhance)
            if config.enhance.enabled and config.enhance.api_key
            else None
        )
        self.injector = TextInjector()
        self._recording = False
        self._stream: AudioStream | None = None
        self._stream_ctx = None
        self._state = DaemonState.IDLE
        self._subscribers: list[asyncio.StreamWriter] = []

    async def run(self) -> None:
        """Start the socket server and hotkey listener, run until stopped."""
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
            stream=sys.stderr,
        )
        logger.info("Starting cuisp daemon")

        server = await asyncio.start_unix_server(
            self._handle_client, path=self.config.daemon.socket_path
        )
        logger.info("Listening on %s", self.config.daemon.socket_path)

        hotkey_task = asyncio.create_task(self._run_hotkey_listener())

        try:
            async with server:
                await asyncio.gather(server.serve_forever(), hotkey_task)
        finally:
            if self.enhancer:
                await self.enhancer.close()

    async def _set_state(self, state: DaemonState) -> None:
        """Update daemon state and notify all subscribers."""
        self._state = state
        msg = json.dumps({"state": state.value}).encode() + b"\n"
        stale: list[asyncio.StreamWriter] = []
        for writer in self._subscribers:
            try:
                writer.write(msg)
                await writer.drain()
            except (ConnectionError, OSError):
                stale.append(writer)
        for writer in stale:
            self._subscribers.remove(writer)
            writer.close()

    async def _handle_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        """Handle a single CLI command over the Unix socket."""
        try:
            data = await reader.readline()
            if not data:
                return
            msg = json.loads(data.decode())
            cmd = msg.get("cmd")

            if cmd == "status":
                response = {
                    "status": "running",
                    "recording": self._recording,
                    "state": self._state.value,
                }
            elif cmd == "subscribe":
                # Send initial state, then keep connection open
                init = json.dumps({"state": self._state.value}).encode() + b"\n"
                writer.write(init)
                await writer.drain()
                self._subscribers.append(writer)
                # Keep connection alive until client disconnects
                try:
                    while True:
                        data = await reader.read(1)
                        if not data:
                            break
                except (ConnectionError, asyncio.CancelledError):
                    pass
                finally:
                    if writer in self._subscribers:
                        self._subscribers.remove(writer)
                return  # skip the final close — handled above
            elif cmd == "stop":
                response = {"status": "stopping"}
                asyncio.get_running_loop().call_soon(
                    asyncio.get_running_loop().stop
                )
            else:
                response = {"error": f"unknown command: {cmd}"}

            writer.write(json.dumps(response).encode() + b"\n")
            await writer.drain()
        except Exception as e:
            logger.error("Client handler error: %s", e)
        finally:
            writer.close()

    async def _run_hotkey_listener(self) -> None:
        """Run the platform-specific hotkey listener in a background thread."""
        loop = asyncio.get_running_loop()
        listener = create_hotkey_listener(
            self.config.daemon, loop, self._on_hotkey
        )
        logger.info("Hotkey listener ready (key: %s)", self.config.daemon.hotkey)
        await loop.run_in_executor(None, listener.run)

    async def _on_hotkey(self, event: HotkeyEvent) -> None:
        """Handle a hotkey press or release event."""
        if event == HotkeyEvent.PRESS and not self._recording:
            await self._start_recording()
        elif event == HotkeyEvent.RELEASE and self._recording:
            audio = await self._stop_recording()
            if audio is not None and len(audio) > 0:
                duration = len(audio) / self.config.audio.sample_rate
                if duration < MIN_AUDIO_DURATION:
                    logger.info("Recording too short (%.2fs), ignoring", duration)
                    return
                asyncio.create_task(self._process(audio))

    async def _start_recording(self) -> None:
        logger.info("Recording started")
        self._recording = True
        await self._set_state(DaemonState.RECORDING)
        self._stream_ctx = self.recorder.record_stream()
        self._stream = self._stream_ctx.__enter__()

    async def _stop_recording(self) -> np.ndarray | None:
        logger.info("Recording stopped")
        self._recording = False
        if self._stream is None or self._stream_ctx is None:
            return None
        audio = self._stream.get_audio()
        self._stream_ctx.__exit__(None, None, None)
        self._stream = None
        self._stream_ctx = None
        duration = len(audio) / self.config.audio.sample_rate
        logger.info("Captured %.1fs of audio", duration)
        return audio

    async def _process(self, audio: np.ndarray) -> None:
        """Full pipeline: transcribe -> enhance -> inject."""
        loop = asyncio.get_running_loop()

        await self._set_state(DaemonState.TRANSCRIBING)
        logger.info("Transcribing...")
        result = await loop.run_in_executor(
            None, self.transcriber.transcribe, audio
        )
        logger.info(
            "Transcribed: %s (lang=%s, prob=%.2f)",
            result.text[:80],
            result.language,
            result.language_probability,
        )

        text = result.text
        if not text.strip():
            logger.info("Empty transcription, skipping")
            await self._set_state(DaemonState.IDLE)
            return

        if self.enhancer:
            await self._set_state(DaemonState.ENHANCING)
            logger.info("Enhancing...")
            text = await self.enhancer.enhance(text)
            logger.info("Enhanced: %s", text[:80])

        await self._set_state(DaemonState.INJECTING)
        logger.info("Injecting text")
        await loop.run_in_executor(None, self.injector.inject, text)
        logger.info("Done")
        await self._set_state(DaemonState.IDLE)
