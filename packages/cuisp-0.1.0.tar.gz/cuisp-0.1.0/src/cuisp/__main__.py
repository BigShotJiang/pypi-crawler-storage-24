"""Allow running cuisp as `python -m cuisp`."""

from cuisp.cli import main

main()
