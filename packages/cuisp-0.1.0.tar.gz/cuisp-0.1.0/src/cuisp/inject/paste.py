"""Text injection via clipboard save/set/paste/restore.

Injects text at the cursor position by temporarily replacing the clipboard
contents, simulating Ctrl+V, then restoring the original clipboard.
"""

from __future__ import annotations

import subprocess
import time

from cuisp.platform.detect import find_clipboard_tools, find_type_tool

_SUBPROCESS_TIMEOUT: float = 5.0
_CLIPBOARD_SETTLE_DELAY: float = 0.05
_PASTE_RESTORE_DELAY: float = 0.10


class TextInjector:
    """Injects text at cursor position via clipboard manipulation.

    Requires platform clipboard tools (pbcopy/pbpaste, wl-copy/wl-paste,
    or xclip) and a keystroke simulator (osascript, wtype, or xdotool).
    """

    def __init__(self) -> None:
        self._copy_cmd, self._paste_cmd = find_clipboard_tools()
        self._type_cmd = find_type_tool()

    def inject(self, text: str) -> None:
        """Inject *text* at the current cursor position.

        Steps: save clipboard -> set clipboard -> Ctrl+V -> restore clipboard.
        """
        if not text:
            return

        saved = subprocess.run(
            self._paste_cmd, capture_output=True, text=True,
            timeout=_SUBPROCESS_TIMEOUT,
        ).stdout

        try:
            proc = subprocess.Popen(
                self._copy_cmd, stdin=subprocess.PIPE, text=True,
            )
            proc.communicate(input=text, timeout=_SUBPROCESS_TIMEOUT)

            time.sleep(_CLIPBOARD_SETTLE_DELAY)

            subprocess.run(
                self._type_cmd, timeout=_SUBPROCESS_TIMEOUT, check=True,
            )
        finally:
            time.sleep(_PASTE_RESTORE_DELAY)
            proc = subprocess.Popen(
                self._copy_cmd, stdin=subprocess.PIPE, text=True,
            )
            proc.communicate(input=saved, timeout=_SUBPROCESS_TIMEOUT)
