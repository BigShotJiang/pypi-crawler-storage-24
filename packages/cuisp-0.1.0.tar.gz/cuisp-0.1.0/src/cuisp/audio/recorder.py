"""Microphone audio capture using sounddevice.

sounddevice is imported lazily so that modules which only need ``AudioStream``
(e.g. tests) do not require a working audio backend.
"""

from __future__ import annotations

import collections
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Generator

import numpy as np

from cuisp.config import AudioConfig
from cuisp.constants import AUDIO_SAMPLE_RATE, MAX_AUDIO_DURATION


@dataclass
class AudioStream:
    """Thread-safe accumulator for audio chunks during streaming recording."""

    _chunks: collections.deque[np.ndarray] = field(default_factory=collections.deque)

    def append(self, chunk: np.ndarray) -> None:
        self._chunks.append(chunk.copy())

    def get_audio(self) -> np.ndarray:
        """Return concatenated float32 mono audio."""
        if not self._chunks:
            return np.array([], dtype=np.float32)
        return np.concatenate(list(self._chunks)).flatten()

    @property
    def duration(self) -> float:
        """Approximate duration in seconds (assumes default sample rate)."""
        audio = self.get_audio()
        return len(audio) / AUDIO_SAMPLE_RATE


class AudioRecorder:
    """Records audio from a microphone into numpy arrays.

    The ``device`` field accepts an integer index or a substring device name.
    Use ``list_devices()`` to discover available inputs.
    """

    def __init__(self, config: AudioConfig):
        self._config = config
        self._device: int | str | None = config.device
        if self._device is not None:
            try:
                self._device = int(self._device)
            except ValueError:
                pass  # keep as string (device name)

    def record_blocking(self, duration: float) -> np.ndarray:
        """Record for a fixed *duration* seconds. Returns float32 numpy array.

        Raises ValueError if duration is outside allowed bounds.
        """
        if duration <= 0:
            raise ValueError("duration must be positive")
        if duration > MAX_AUDIO_DURATION:
            raise ValueError(f"duration exceeds maximum of {MAX_AUDIO_DURATION}s")

        import sounddevice as sd

        frames = int(duration * self._config.sample_rate)
        audio = sd.rec(
            frames,
            samplerate=self._config.sample_rate,
            channels=self._config.channels,
            dtype=self._config.dtype,
            device=self._device,
        )
        sd.wait()
        return audio.flatten()

    @contextmanager
    def record_stream(self) -> Generator[AudioStream, None, None]:
        """Context manager for streaming recording.

        Usage::

            with recorder.record_stream() as stream:
                input("Press Enter to stop")
            audio = stream.get_audio()
        """
        import sounddevice as sd

        stream = AudioStream()

        def callback(
            indata: np.ndarray, frames: int, time_info: object, status: object
        ) -> None:
            if status:
                pass  # overflow warnings are non-fatal
            stream.append(indata)

        with sd.InputStream(
            samplerate=self._config.sample_rate,
            channels=self._config.channels,
            dtype=self._config.dtype,
            device=self._device,
            callback=callback,
        ):
            yield stream

    @staticmethod
    def list_devices() -> list[dict]:
        """List available audio input devices."""
        import sounddevice as sd

        devices = sd.query_devices()
        result = []
        for i, dev in enumerate(devices):
            if dev["max_input_channels"] > 0:
                result.append(
                    {
                        "index": i,
                        "name": dev["name"],
                        "channels": dev["max_input_channels"],
                        "sample_rate": dev["default_samplerate"],
                        "is_default": i == sd.default.device[0],
                    }
                )
        return result
