"""Cuisp CLI interface.

Entry point for all user-facing commands: init, devices, transcribe,
enhance, start, stop, status.
"""

from __future__ import annotations

import asyncio
import sys

import click

from cuisp import __version__
from cuisp.config import load_config, write_default_config


@click.group()
@click.option("--config", "-c", "config_path", type=click.Path(), default=None,
              help="Path to config file")
@click.version_option(version=__version__)
@click.pass_context
def main(ctx: click.Context, config_path: str | None) -> None:
    """Cuisp - Voice-to-text for Linux with AI enhancement."""
    ctx.ensure_object(dict)
    from pathlib import Path
    path = Path(config_path) if config_path else None
    ctx.obj["config"] = load_config(path)


@main.command()
@click.pass_context
def init(ctx: click.Context) -> None:
    """Create default config file."""
    path = write_default_config()
    click.echo(f"Config written to {path}")
    click.echo("Edit the file to set your API key and preferences.")


@main.command()
@click.pass_context
def devices(ctx: click.Context) -> None:
    """List available audio input devices."""
    from cuisp.audio.recorder import AudioRecorder

    devs = AudioRecorder.list_devices()
    if not devs:
        click.echo("No input devices found.")
        return
    for d in devs:
        default = " (default)" if d["is_default"] else ""
        click.echo(f"  [{d['index']}] {d['name']} - {d['channels']}ch, "
                    f"{int(d['sample_rate'])}Hz{default}")


@main.command()
@click.option("--duration", "-d", type=float, default=None,
              help="Record for N seconds (default: until Enter)")
@click.option("--model", "-m", type=str, default=None, help="Whisper model size")
@click.option("--language", "-l", type=str, default=None, help="Language code (e.g. en)")
@click.option("--no-enhance", is_flag=True, help="Skip AI enhancement")
@click.option("--prompt", "-p", type=str, default=None, help="Enhancement prompt name")
@click.option("--device", type=str, default=None, help="Audio device index or name")
@click.option("--inject", is_flag=True, help="Paste result at cursor instead of printing")
@click.option("--vocab", "-v", type=str, multiple=True,
              help="Words to hint to Whisper (e.g. -v Marc -v cuisp)")
@click.pass_context
def transcribe(ctx: click.Context, duration: float | None, model: str | None,
               language: str | None, no_enhance: bool, prompt: str | None,
               device: str | None, inject: bool, vocab: tuple[str, ...]) -> None:
    """Record audio and transcribe to text."""
    config = ctx.obj["config"]

    if model:
        config.whisper.model_size = model
    if language:
        config.whisper.language = language
    if device:
        config.audio.device = device
    if vocab:
        config.whisper.vocabulary = list(vocab) + config.whisper.vocabulary

    from cuisp.audio.recorder import AudioRecorder
    from cuisp.stt.whisper import WhisperTranscriber

    recorder = AudioRecorder(config.audio)
    transcriber = WhisperTranscriber(config.whisper)

    if duration:
        click.echo(f"Recording for {duration}s...", err=True)
        audio = recorder.record_blocking(duration)
    else:
        click.echo("Recording... press Enter to stop.", err=True)
        with recorder.record_stream() as stream:
            try:
                input()
            except (EOFError, KeyboardInterrupt):
                pass
        audio = stream.get_audio()

    if len(audio) == 0:
        click.echo("No audio captured.", err=True)
        return

    duration_s = len(audio) / config.audio.sample_rate
    click.echo(f"Captured {duration_s:.1f}s of audio, transcribing...", err=True)

    result = transcriber.transcribe(audio)
    text = result.text
    click.echo(f"Language: {result.language} ({result.language_probability:.0%})", err=True)

    if not text.strip():
        click.echo("No speech detected.", err=True)
        return

    if not no_enhance and config.enhance.enabled and config.enhance.api_key:
        click.echo("Enhancing...", err=True)
        from cuisp.enhance.client import EnhanceClient

        async def do_enhance() -> str:
            client = EnhanceClient(config.enhance)
            try:
                return await client.enhance(text, prompt_name=prompt)
            finally:
                await client.close()

        text = asyncio.run(do_enhance())

    if inject:
        from cuisp.inject.paste import TextInjector
        injector = TextInjector()
        injector.inject(text)
    else:
        click.echo(text)


@main.command()
@click.argument("text", required=False)
@click.option("--prompt", "-p", type=str, default="default", help="Prompt template name")
@click.pass_context
def enhance(ctx: click.Context, text: str | None, prompt: str) -> None:
    """Enhance text with AI. Reads from argument or stdin."""
    config = ctx.obj["config"]

    if text is None:
        if sys.stdin.isatty():
            click.echo("Enter text (Ctrl+D to finish):", err=True)
        text = sys.stdin.read()

    if not text.strip():
        click.echo("No text provided.", err=True)
        return

    if not config.enhance.api_key:
        click.echo("Error: No API key set. Set CUISP_API_KEY or configure enhance.api_key",
                    err=True)
        sys.exit(1)

    from cuisp.enhance.client import EnhanceClient

    async def do_enhance() -> str:
        client = EnhanceClient(config.enhance)
        try:
            return await client.enhance(text, prompt_name=prompt)
        finally:
            await client.close()

    result = asyncio.run(do_enhance())
    click.echo(result)


@main.command()
@click.option("--foreground", "-f", is_flag=True, help="Run in foreground (don't daemonize)")
@click.pass_context
def start(ctx: click.Context, foreground: bool) -> None:
    """Start the cuisp daemon."""
    from cuisp.daemon.lifecycle import start_daemon
    start_daemon(ctx.obj["config"], foreground=foreground)


@main.command()
@click.pass_context
def stop(ctx: click.Context) -> None:
    """Stop the cuisp daemon."""
    from cuisp.daemon.lifecycle import stop_daemon
    stop_daemon(ctx.obj["config"])


@main.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show daemon status."""
    from cuisp.daemon.lifecycle import is_daemon_running
    running, pid = is_daemon_running(ctx.obj["config"])
    if running:
        click.echo(f"Daemon is running (PID {pid})")
    else:
        click.echo("Daemon is not running")


@main.command()
@click.option("--format", "-f", "fmt", type=click.Choice(["waybar", "polybar", "plain"]),
              default="waybar", help="Output format")
@click.pass_context
def bar(ctx: click.Context, fmt: str) -> None:
    """Stream daemon state for desktop bars (Waybar, polybar, etc.)."""
    import json
    import socket

    config = ctx.obj["config"]

    _BAR_MAP = {
        "idle":         {"icon": "○", "text": "",     "class": "idle"},
        "recording":    {"icon": "●", "text": "REC",  "class": "recording"},
        "transcribing": {"icon": "◉", "text": "STT",  "class": "transcribing"},
        "enhancing":    {"icon": "◈", "text": "AI",   "class": "enhancing"},
        "injecting":    {"icon": "◇", "text": "PASTE","class": "injecting"},
    }

    def format_line(state: str) -> str:
        info = _BAR_MAP.get(state, _BAR_MAP["idle"])
        if fmt == "waybar":
            return json.dumps({
                "text": info["icon"],
                "tooltip": f"cuisp: {state}",
                "class": info["class"],
                "alt": state,
            })
        elif fmt == "polybar":
            colors = {
                "idle": "#888888", "recording": "#ff4444",
                "transcribing": "#ffaa00", "enhancing": "#44aaff",
                "injecting": "#44ff44",
            }
            color = colors.get(state, "#888888")
            label = f"{info['icon']} {info['text']}".strip()
            return f"%{{F{color}}}{label}%{{F-}}"
        else:
            return f"cuisp: {state}"

    import time

    # Emit idle immediately so the bar has something to show
    click.echo(format_line("idle"))
    sys.stdout.flush()

    while True:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            sock.connect(config.daemon.socket_path)
        except (ConnectionRefusedError, FileNotFoundError):
            # Daemon not running — wait and retry
            time.sleep(2)
            continue

        sock.sendall(json.dumps({"cmd": "subscribe"}).encode() + b"\n")

        buf = b""
        try:
            while True:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    msg = json.loads(line.decode())
                    state = msg.get("state", "idle")
                    click.echo(format_line(state), nl=True)
                    sys.stdout.flush()
        except (BrokenPipeError, KeyboardInterrupt):
            return
        finally:
            sock.close()

        # Daemon disconnected — show idle, then retry
        click.echo(format_line("idle"))
        sys.stdout.flush()
        time.sleep(2)


@main.command()
@click.pass_context
def tray(ctx: click.Context) -> None:
    """Run a system tray indicator (requires dasbus on Linux, rumps on macOS)."""
    config = ctx.obj["config"]
    if sys.platform == "darwin":
        from cuisp.tray.macos import run_tray
    else:
        from cuisp.tray.indicator import run_tray
    run_tray(config)
