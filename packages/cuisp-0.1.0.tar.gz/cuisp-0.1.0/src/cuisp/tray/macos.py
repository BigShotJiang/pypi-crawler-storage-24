"""macOS system tray (menu bar) indicator using rumps.

``rumps`` is a pure-Python wrapper around ``NSStatusItem`` / ``PyObjC``.
It provides a native macOS menu bar icon with zero framework overhead.
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cuisp.config import CuispConfig

_STATE_DISPLAY = {
    "idle":         ("○", "cuisp: idle"),
    "recording":    ("●", "cuisp: recording"),
    "transcribing": ("◉", "cuisp: transcribing"),
    "enhancing":    ("◈", "cuisp: enhancing"),
    "injecting":    ("◇", "cuisp: injecting"),
}


def run_tray(config: CuispConfig) -> None:
    """Launch a macOS menu bar status item and subscribe to daemon state."""
    import rumps

    app = rumps.App("cuisp", title="○", quit_button="Quit")
    status_item = rumps.MenuItem("idle")
    app.menu = [status_item]

    def _subscribe_loop() -> None:
        import time

        from cuisp.tray.subscribe import subscribe_states

        while True:
            for state in subscribe_states(config.daemon.socket_path):
                icon, label = _STATE_DISPLAY.get(state, _STATE_DISPLAY["idle"])
                app.title = icon
                status_item.title = label
            time.sleep(2)

    t = threading.Thread(target=_subscribe_loop, daemon=True)
    t.start()
    app.run()
