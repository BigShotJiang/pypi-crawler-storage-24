"""System tray indicator for cuisp (Linux D-Bus SNI / macOS NSStatusItem)."""
