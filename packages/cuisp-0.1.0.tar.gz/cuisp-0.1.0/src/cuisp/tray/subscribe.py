"""Shared daemon subscription logic for tray indicators.

Connects to the daemon's Unix socket, sends ``{"cmd": "subscribe"}``,
and yields state strings as they arrive.
"""

from __future__ import annotations

import json
import socket
from typing import Generator


def subscribe_states(socket_path: str) -> Generator[str, None, None]:
    """Connect to the daemon and yield state strings until disconnected."""
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        sock.connect(socket_path)
    except (ConnectionRefusedError, FileNotFoundError):
        return

    sock.sendall(json.dumps({"cmd": "subscribe"}).encode() + b"\n")

    buf = b""
    try:
        while True:
            chunk = sock.recv(4096)
            if not chunk:
                break
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                msg = json.loads(line.decode())
                yield msg.get("state", "idle")
    except (ConnectionError, OSError):
        pass
    finally:
        sock.close()
