"""Linux system tray indicator using D-Bus StatusNotifierItem (SNI).

Uses ``dasbus`` (pure Python, ~50 KB) to register an SNI with the desktop
panel.  Works with Waybar, KDE Plasma, GNOME (with AppIndicator extension),
and any panel that implements ``org.kde.StatusNotifierWatcher``.
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cuisp.config import CuispConfig

# State → (icon-name, tooltip, attention)
_STATE_MAP = {
    "idle":         ("cuisp-idle",         "cuisp: idle",         False),
    "recording":    ("cuisp-recording",    "cuisp: recording",    True),
    "transcribing": ("cuisp-transcribing", "cuisp: transcribing", True),
    "enhancing":    ("cuisp-enhancing",    "cuisp: enhancing",    True),
    "injecting":    ("cuisp-injecting",    "cuisp: injecting",    False),
}


def run_tray(config: CuispConfig) -> None:
    """Launch the SNI tray icon and subscribe to daemon state."""
    from dasbus.connection import SessionMessageBus
    from dasbus.loop import EventLoop
    from dasbus.server.interface import dbus_interface
    from dasbus.typing import Str

    bus = SessionMessageBus()
    loop = EventLoop()

    # Mutable state holder for the D-Bus interface
    _current = {"icon": "cuisp-idle", "tooltip": "cuisp: idle", "status": "Passive"}

    @dbus_interface("org.kde.StatusNotifierItem")
    class CuispSNI:
        """Minimal StatusNotifierItem D-Bus interface."""

        @property
        def Id(self) -> Str:
            return "cuisp"

        @property
        def Category(self) -> Str:
            return "ApplicationStatus"

        @property
        def Status(self) -> Str:
            return _current["status"]

        @property
        def IconName(self) -> Str:
            return _current["icon"]

        @property
        def ToolTip(self) -> Str:
            return _current["tooltip"]

        @property
        def Title(self) -> Str:
            return "cuisp"

    sni = CuispSNI()
    bus.publish_object("/StatusNotifierItem", sni)
    bus.register_service("org.kde.StatusNotifierItem-cuisp")

    # Register with the watcher so panels discover us
    try:
        watcher = bus.get_proxy(
            "org.kde.StatusNotifierWatcher",
            "/StatusNotifierWatcher",
        )
        watcher.RegisterStatusNotifierItem("org.kde.StatusNotifierItem-cuisp")
    except Exception:
        pass  # watcher not running, some panels discover via bus name

    def _subscribe_loop() -> None:
        """Background thread: subscribe to daemon and update SNI state."""
        import time

        from cuisp.tray.subscribe import subscribe_states

        while True:
            for state in subscribe_states(config.daemon.socket_path):
                icon, tooltip, attention = _STATE_MAP.get(
                    state, _STATE_MAP["idle"]
                )
                _current["icon"] = icon
                _current["tooltip"] = tooltip
                _current["status"] = "NeedsAttention" if attention else "Passive"
            # Daemon disconnected — retry after a delay
            time.sleep(2)

    t = threading.Thread(target=_subscribe_loop, daemon=True)
    t.start()
    loop.run()
