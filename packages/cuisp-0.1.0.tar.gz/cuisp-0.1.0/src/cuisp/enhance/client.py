"""OpenAI-compatible API client for text enhancement.

Uses httpx for async HTTP.  Compatible with any provider that exposes
``/chat/completions`` (OpenAI, Ollama, LM Studio, vLLM, etc.).
"""

from __future__ import annotations

import httpx

from cuisp.config import EnhanceConfig
from cuisp.constants import ENHANCE_HTTP_TIMEOUT
from cuisp.enhance.filters import filter_output
from cuisp.enhance.prompts import get_prompt


class EnhanceClient:
    """Async client for LLM text enhancement via chat completions."""

    def __init__(self, config: EnhanceConfig):
        self._config = config
        self._http = httpx.AsyncClient(
            base_url=config.api_base,
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=ENHANCE_HTTP_TIMEOUT,
        )

    async def enhance(
        self, text: str, prompt_name: str | None = None, context: str | None = None
    ) -> str:
        """Send *text* through an LLM with the named prompt template.

        Returns the enhanced text after output filtering.
        """
        if not text.strip():
            return text

        name = prompt_name or self._config.default_prompt
        prompt = get_prompt(name)
        messages = prompt.build_messages(text, context=context)

        response = await self._http.post(
            "/chat/completions",
            json={
                "model": self._config.model,
                "messages": messages,
                "temperature": self._config.temperature,
                "max_tokens": self._config.max_tokens,
            },
        )
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"]
        return filter_output(content)

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.aclose()
