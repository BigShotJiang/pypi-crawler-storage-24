"""Prompt templates for AI text enhancement.

Built-in templates cover common use cases.  Users can add custom templates
by placing TOML files in ``~/.config/cuisp/prompts/<name>.toml`` with
``system`` and optional ``user_template`` keys.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path

from cuisp.constants import PromptName


@dataclass
class PromptTemplate:
    """A system + user message pair used to drive LLM enhancement."""
    name: str
    system: str
    user_template: str  # must contain {text}, may contain {context}

    def build_messages(self, text: str, context: str | None = None) -> list[dict]:
        """Build the chat messages list for a completions request."""
        return [
            {"role": "system", "content": self.system},
            {
                "role": "user",
                "content": self.user_template.format(
                    text=text, context=context or ""
                ),
            },
        ]


BUILTIN_PROMPTS: dict[str, PromptTemplate] = {
    PromptName.DEFAULT: PromptTemplate(
        name="default",
        system=(
            "You are a transcription assistant. Clean up the following dictated text: "
            "fix punctuation, capitalization, and obvious speech-to-text errors. "
            "Do not change the meaning or add new content. Output only the corrected text."
        ),
        user_template="Dictated text:\n{text}",
    ),
    PromptName.EMAIL: PromptTemplate(
        name="email",
        system=(
            "You are a writing assistant. Transform the following dictated text into a "
            "professional email. Fix grammar, add appropriate greeting and sign-off if missing. "
            "Output only the email text."
        ),
        user_template="Dictated text:\n{text}",
    ),
    PromptName.CHAT: PromptTemplate(
        name="chat",
        system=(
            "You are a writing assistant. Clean up the following dictated text for a casual "
            "chat message. Keep it short and natural. Fix obvious errors but preserve tone. "
            "Output only the message text."
        ),
        user_template="Dictated text:\n{text}",
    ),
    PromptName.REWRITE: PromptTemplate(
        name="rewrite",
        system=(
            "You are a writing assistant. Rewrite the following dictated text for clarity "
            "and conciseness. You may restructure sentences freely. "
            "Output only the rewritten text."
        ),
        user_template="Dictated text:\n{text}",
    ),
}


def get_prompt(name: str, config_dir: Path | None = None) -> PromptTemplate:
    """Look up a prompt template by name.

    Resolution order:
    1. Custom TOML file at ``<config_dir>/prompts/<name>.toml``
    2. Built-in templates (default, email, chat, rewrite)
    3. Raises ``ValueError`` if not found
    """
    if config_dir is None:
        config_dir = Path.home() / ".config" / "cuisp"

    custom_path = config_dir / "prompts" / f"{name}.toml"
    if custom_path.exists():
        with open(custom_path, "rb") as f:
            data = tomllib.load(f)
        return PromptTemplate(
            name=name,
            system=data["system"],
            user_template=data.get("user_template", "Dictated text:\n{text}"),
        )

    if name in BUILTIN_PROMPTS:
        return BUILTIN_PROMPTS[name]

    raise ValueError(
        f"Unknown prompt '{name}'. Available: {', '.join(BUILTIN_PROMPTS.keys())}"
    )
