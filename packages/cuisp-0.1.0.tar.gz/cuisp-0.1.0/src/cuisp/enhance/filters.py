"""Filter LLM output artifacts.

Strips reasoning traces, markdown fences, and wrapping quotes that models
commonly emit even when told not to.
"""

from __future__ import annotations

import re


def filter_output(text: str) -> str:
    """Remove common LLM artifacts from enhanced text.

    Handles:
    - ``<think>...</think>`` blocks (DeepSeek, Qwen reasoning models)
    - Markdown code fences wrapping the entire output
    - Wrapping double-quotes around the entire output
    """
    # Strip reasoning traces
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)

    # Strip markdown code fences if the entire output is wrapped
    text = re.sub(r"^```\w*\n(.*)\n```$", r"\1", text.strip(), flags=re.DOTALL)

    # Strip wrapping double-quotes (min length 3 to avoid stripping '""')
    if len(text) > 2 and text.startswith('"') and text.endswith('"'):
        text = text[1:-1]

    return text.strip()
