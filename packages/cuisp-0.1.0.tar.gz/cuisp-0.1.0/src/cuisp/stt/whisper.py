"""Speech-to-text using faster-whisper.

The model is loaded lazily on the first ``transcribe()`` call so that
importing this module is cheap and tests can mock the heavy dependency.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from cuisp.config import WhisperConfig
from cuisp.constants import AUDIO_SAMPLE_RATE, MIN_AUDIO_DURATION


@dataclass
class TranscriptionResult:
    """Structured output from a Whisper transcription run."""
    text: str
    language: str
    language_probability: float
    segments: list
    duration: float


class WhisperTranscriber:
    """Wraps faster-whisper for local speech-to-text."""

    def __init__(self, config: WhisperConfig):
        self._config = config
        self._model = None

    def _ensure_model(self):
        """Load the WhisperModel on first use."""
        if self._model is None:
            from faster_whisper import WhisperModel

            self._model = WhisperModel(
                self._config.model_size,
                device=self._config.device,
                compute_type=self._config.compute_type,
            )
        return self._model

    def _build_initial_prompt(self) -> str | None:
        """Build comma-separated vocabulary hint for the decoder."""
        if not self._config.vocabulary:
            return None
        return ", ".join(self._config.vocabulary)

    def transcribe(self, audio: np.ndarray) -> TranscriptionResult:
        """Transcribe a float32 numpy audio array.

        Skips transcription and returns empty text for audio shorter than
        ``MIN_AUDIO_DURATION``.
        """
        duration = len(audio) / AUDIO_SAMPLE_RATE if len(audio) > 0 else 0.0
        if duration < MIN_AUDIO_DURATION:
            return TranscriptionResult(
                text="", language="", language_probability=0.0,
                segments=[], duration=duration,
            )

        model = self._ensure_model()
        segments, info = model.transcribe(
            audio,
            language=self._config.language,
            beam_size=self._config.beam_size,
            vad_filter=self._config.vad_filter,
            initial_prompt=self._build_initial_prompt(),
        )
        segment_list = list(segments)
        text = " ".join(s.text.strip() for s in segment_list)
        return TranscriptionResult(
            text=text,
            language=info.language,
            language_probability=info.language_probability,
            segments=segment_list,
            duration=info.duration,
        )
