"""Configuration loading and validation.

Loads settings from TOML (~/.config/cuisp/config.toml), overlays environment
variables, and exposes typed Pydantic models.  Every numeric/string default is
drawn from ``cuisp.constants`` so there is one source of truth.
"""

from __future__ import annotations

import os
import tomllib
from pathlib import Path

from pydantic import BaseModel, Field, field_validator

from cuisp.constants import (
    AUDIO_CHANNELS,
    AUDIO_DTYPE,
    AUDIO_SAMPLE_RATE,
    DEFAULT_BEAM_SIZE,
    DEFAULT_COMPUTE_TYPE,
    DEFAULT_HOTKEY,
    DEFAULT_LLM_MAX_TOKENS,
    DEFAULT_LLM_TEMPERATURE,
    DEFAULT_WHISPER_MODEL,
    DaemonMode,
    WhisperModelSize,
)

import tomli_w


class AudioConfig(BaseModel):
    device: str | None = None
    sample_rate: int = AUDIO_SAMPLE_RATE
    channels: int = AUDIO_CHANNELS
    dtype: str = AUDIO_DTYPE

    @field_validator("sample_rate")
    @classmethod
    def _positive_sample_rate(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("sample_rate must be positive")
        return v


class WhisperConfig(BaseModel):
    model_size: str = DEFAULT_WHISPER_MODEL
    device: str = "auto"
    compute_type: str = DEFAULT_COMPUTE_TYPE
    language: str | None = None
    beam_size: int = DEFAULT_BEAM_SIZE
    vad_filter: bool = True
    vocabulary: list[str] = Field(default_factory=list)

    @field_validator("model_size")
    @classmethod
    def _valid_model(cls, v: str) -> str:
        allowed = {m.value for m in WhisperModelSize}
        if v not in allowed:
            raise ValueError(f"model_size must be one of {sorted(allowed)}, got '{v}'")
        return v

    @field_validator("beam_size")
    @classmethod
    def _positive_beam(cls, v: int) -> int:
        if v < 1:
            raise ValueError("beam_size must be >= 1")
        return v


class EnhanceConfig(BaseModel):
    enabled: bool = True
    api_base: str = "https://api.openai.com/v1"
    api_key: str = ""
    model: str = "gpt-4o-mini"
    default_prompt: str = "default"
    temperature: float = DEFAULT_LLM_TEMPERATURE
    max_tokens: int = DEFAULT_LLM_MAX_TOKENS

    @field_validator("temperature")
    @classmethod
    def _clamp_temperature(cls, v: float) -> float:
        if not 0.0 <= v <= 2.0:
            raise ValueError("temperature must be between 0.0 and 2.0")
        return v

    @field_validator("max_tokens")
    @classmethod
    def _positive_tokens(cls, v: int) -> int:
        if v < 1:
            raise ValueError("max_tokens must be >= 1")
        return v


class DaemonConfig(BaseModel):
    hotkey: str = DEFAULT_HOTKEY
    socket_path: str = Field(default="")
    pid_file: str = Field(default="")
    mode: str = DaemonMode.PUSH_TO_TALK.value

    def model_post_init(self, __context: object) -> None:
        import sys
        import tempfile

        if sys.platform == "darwin":
            runtime_dir = os.environ.get("TMPDIR", tempfile.gettempdir())
        else:
            uid = os.getuid()
            runtime_dir = os.environ.get("XDG_RUNTIME_DIR", f"/run/user/{uid}")
        if not self.socket_path:
            self.socket_path = f"{runtime_dir}/cuisp.sock"
        if not self.pid_file:
            self.pid_file = f"{runtime_dir}/cuisp.pid"


class CuispConfig(BaseModel):
    """Top-level configuration aggregating all sub-configs."""
    audio: AudioConfig = AudioConfig()
    whisper: WhisperConfig = WhisperConfig()
    enhance: EnhanceConfig = EnhanceConfig()
    daemon: DaemonConfig = DaemonConfig()


DEFAULT_CONFIG_DIR = Path.home() / ".config" / "cuisp"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.toml"


def load_config(path: Path | None = None) -> CuispConfig:
    """Load config from TOML, overlay environment variables.

    If the file does not exist, returns defaults.  Environment variables
    (CUISP_API_KEY, CUISP_API_BASE, CUISP_WHISPER_MODEL, CUISP_LANGUAGE)
    always win over file values.
    """
    config_path = path or DEFAULT_CONFIG_PATH
    data: dict = {}

    if config_path.exists():
        with open(config_path, "rb") as f:
            data = tomllib.load(f)

    config = CuispConfig(**data)

    env_map = {
        "CUISP_API_KEY": ("enhance", "api_key"),
        "CUISP_API_BASE": ("enhance", "api_base"),
        "CUISP_WHISPER_MODEL": ("whisper", "model_size"),
        "CUISP_LANGUAGE": ("whisper", "language"),
    }
    for env_var, (section, key) in env_map.items():
        val = os.environ.get(env_var)
        if val is not None:
            setattr(getattr(config, section), key, val)

    return config


def write_default_config(path: Path | None = None) -> Path:
    """Write a default config file with all options documented."""
    config_path = path or DEFAULT_CONFIG_PATH
    config_path.parent.mkdir(parents=True, exist_ok=True)

    defaults = CuispConfig()
    data = defaults.model_dump(exclude_none=True)

    with open(config_path, "wb") as f:
        tomli_w.dump(data, f)

    return config_path
