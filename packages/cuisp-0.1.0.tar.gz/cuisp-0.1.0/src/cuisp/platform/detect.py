"""Platform detection and tool resolution for Wayland/X11/macOS.

Detects the active display server and resolves clipboard / keystroke
simulation tools.  All external tool requirements are validated eagerly
so failures surface early with clear messages.
"""

from __future__ import annotations

import os
import shutil
import sys

from cuisp.constants import DisplayServer


def detect_display_server() -> DisplayServer:
    """Return the active display server based on environment variables."""
    if sys.platform == "darwin":
        return DisplayServer.MACOS
    if os.environ.get("WAYLAND_DISPLAY"):
        return DisplayServer.WAYLAND
    if os.environ.get("DISPLAY"):
        return DisplayServer.X11
    return DisplayServer.UNKNOWN


def _require_tool(name: str) -> str:
    """Verify an external CLI tool is on PATH; raise if missing."""
    path = shutil.which(name)
    if path is None:
        raise RuntimeError(
            f"Required tool '{name}' not found. Install it with your package manager."
        )
    return path


def find_clipboard_tools() -> tuple[list[str], list[str]]:
    """Return ``(copy_cmd, paste_cmd)`` for the current display server."""
    ds = detect_display_server()
    if ds == DisplayServer.MACOS:
        _require_tool("pbcopy")
        _require_tool("pbpaste")
        return (["pbcopy"], ["pbpaste"])
    elif ds == DisplayServer.WAYLAND:
        _require_tool("wl-copy")
        _require_tool("wl-paste")
        return (["wl-copy"], ["wl-paste"])
    elif ds == DisplayServer.X11:
        _require_tool("xclip")
        return (
            ["xclip", "-selection", "clipboard"],
            ["xclip", "-selection", "clipboard", "-o"],
        )
    raise RuntimeError(
        "Cannot detect display server (neither WAYLAND_DISPLAY nor DISPLAY set)"
    )


def find_type_tool() -> list[str]:
    """Return command list to simulate a paste keystroke."""
    ds = detect_display_server()
    if ds == DisplayServer.MACOS:
        _require_tool("osascript")
        return [
            "osascript", "-e",
            'tell application "System Events" to keystroke "v" using command down',
        ]
    elif ds == DisplayServer.WAYLAND:
        _require_tool("wtype")
        return ["wtype", "-M", "ctrl", "-k", "v", "-m", "ctrl"]
    elif ds == DisplayServer.X11:
        _require_tool("xdotool")
        return ["xdotool", "key", "ctrl+v"]
    raise RuntimeError("Cannot detect display server")
