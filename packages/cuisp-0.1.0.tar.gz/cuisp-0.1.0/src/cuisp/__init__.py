"""Cuisp - Voice-to-text daemon for Linux with AI enhancement."""

__version__ = "0.1.0"
