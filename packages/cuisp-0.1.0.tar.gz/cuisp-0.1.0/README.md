# Cuisp

Voice-to-text daemon for Linux with AI enhancement.  Press a hotkey, dictate,
release — cleaned-up text appears at your cursor.

## How It Works

```
microphone → Whisper (local STT) → LLM cleanup → paste at cursor
```

1. **Record** audio via sounddevice (PulseAudio/PipeWire).
2. **Transcribe** locally with [faster-whisper](https://github.com/SYSTRAN/faster-whisper) (runs on CPU or GPU).
3. **Enhance** the raw transcript through any OpenAI-compatible API — fix punctuation, grammar, and STT artifacts.
4. **Inject** the result at the cursor via clipboard + simulated Ctrl+V.

## Getting Started

### 1. Install uv (one-time)

[uv](https://docs.astral.sh/uv/) is a fast Python package manager. If you
don't have it yet, open a terminal and run:

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Close and reopen your terminal after installing.

### 2. Install cuisp

```bash
# macOS
uv tool install cuisp --with rumps

# Linux (Wayland)
uv tool install cuisp --with evdev

# Linux (X11)
uv tool install cuisp --with pynput

# Linux (all extras — Wayland + X11 + system tray)
uv tool install cuisp --with evdev --with pynput --with dasbus
```

This gives you the `cuisp` command globally — no need to activate virtual
environments or manage Python yourself.

### 3. Set up

```bash
# Create your config file
cuisp init

# Add your API key for AI text cleanup (or edit ~/.config/cuisp/config.toml)
export CUISP_API_KEY="sk-..."

# Check that your microphone is detected
cuisp devices
```

### 4. Try it out

```bash
# Record and transcribe (press Enter to stop)
cuisp transcribe

# Record for 5 seconds
cuisp transcribe -d 5

# Transcribe without AI enhancement
cuisp transcribe --no-enhance

# Use a specific prompt template
cuisp transcribe -p email

# Enhance text from stdin
echo "fix this sentance plz" | cuisp enhance
```

### Updating

```bash
uv tool upgrade cuisp
```

### Uninstalling

```bash
uv tool uninstall cuisp
```

### Requirements

- Linux (Wayland or X11) or macOS
- A working microphone
- Linux clipboard tools: `wl-copy`/`wl-paste`/`wtype` (Wayland) or `xclip`/`xdotool` (X11)
- Optional: an API key for any OpenAI-compatible service (OpenAI, Ollama, LM Studio, vLLM)

## Daemon Mode

The daemon listens for a global hotkey and runs the full pipeline automatically.

```bash
# Start (daemonizes by default)
cuisp start

# Start in foreground (useful for debugging)
cuisp start -f

# Check status
cuisp status

# Stop
cuisp stop
```

For systemd integration, install the provided service unit:

```bash
cp contrib/cuisp.service ~/.config/systemd/user/
systemctl --user enable --now cuisp
```

On Wayland, the hotkey listener needs access to `/dev/input` devices:

```bash
sudo cp contrib/99-cuisp-input.rules /etc/udev/rules.d/
sudo udevadm control --reload-rules && sudo udevadm trigger
sudo usermod -aG input $USER
# Log out and back in
```

## Configuration

Config lives at `~/.config/cuisp/config.toml`.  Every value has a sensible
default.  Environment variables override file values.

| Env Variable | Overrides |
|---|---|
| `CUISP_API_KEY` | `enhance.api_key` |
| `CUISP_API_BASE` | `enhance.api_base` |
| `CUISP_WHISPER_MODEL` | `whisper.model_size` |
| `CUISP_LANGUAGE` | `whisper.language` |

Example config:

```toml
[audio]
device = "0"          # device index or name substring
sample_rate = 16000

[whisper]
model_size = "base"   # tiny, base, small, medium, large-v3
language = "en"       # omit for auto-detect
vad_filter = true
vocabulary = ["cuisp", "Anthropic"]

[enhance]
enabled = true
api_base = "https://api.openai.com/v1"
model = "gpt-4o-mini"
default_prompt = "default"
temperature = 0.3

[daemon]
hotkey = "LEFTMETA"  # macOS default: "FN" (Globe key)
mode = "push_to_talk"
```

## Toolbar / Status Indicator

Cuisp can display its state in your desktop bar or system tray.

### Desktop bar (Waybar, polybar)

Zero extra dependencies — `cuisp bar` streams state as JSON:

```bash
# Waybar
cuisp bar            # outputs {"text":"●","tooltip":"cuisp: recording","class":"recording","alt":"recording"}

# Polybar
cuisp bar -f polybar # outputs %{F#ff4444}● REC%{F-}

# Plain text
cuisp bar -f plain
```

**Waybar config:**
```json
"custom/cuisp": {
    "exec": "cuisp bar",
    "return-type": "json",
    "restart-interval": 5
}
```

**Waybar CSS:**
```css
#custom-cuisp.recording { color: #ff4444; }
#custom-cuisp.transcribing { color: #ffaa00; }
#custom-cuisp.enhancing { color: #44aaff; }
```

### System tray icon

Requires the `tray` extra (installed if you used `--with dasbus` above):

```bash
cuisp tray    # launches SNI tray icon (Linux D-Bus)
```

On macOS, install with `tray-macos` extra and run `cuisp tray` for a native
menu bar indicator.

## Custom Prompts

Create TOML files in `~/.config/cuisp/prompts/`:

```toml
# ~/.config/cuisp/prompts/commit.toml
system = "Transform dictated text into a conventional git commit message."
user_template = "Dictated text:\n{text}"
```

Use with: `cuisp transcribe -p commit`

Built-in prompts: `default`, `email`, `chat`, `rewrite`.

## Architecture

```
src/cuisp/
├── constants.py          # Central enums, limits, defaults
├── config.py             # Pydantic config models + TOML loader
├── cli.py                # Click CLI commands
├── audio/
│   └── recorder.py       # Microphone capture (sounddevice)
├── stt/
│   └── whisper.py        # Local transcription (faster-whisper)
├── enhance/
│   ├── client.py         # Async LLM client (httpx)
│   ├── prompts.py        # Prompt template registry
│   └── filters.py        # LLM output artifact removal
├── inject/
│   └── paste.py          # Clipboard-based text injection
├── platform/
│   └── detect.py         # Wayland/X11 detection + tool resolution
├── tray/
│   ├── subscribe.py      # Shared daemon state subscription
│   ├── indicator.py      # Linux D-Bus SNI tray icon (dasbus)
│   └── macos.py          # macOS menu bar icon (rumps)
└── daemon/
    ├── hotkey.py          # Global hotkey listeners (evdev/pynput)
    ├── lifecycle.py       # Daemonization + PID management
    └── server.py          # Async daemon core
```

Key design decisions:
- **Lazy imports** for heavy dependencies (sounddevice, faster-whisper) so CLI startup is fast.
- **Central constants** in `constants.py` — all enums, limits, and defaults in one place.
- **Pydantic validators** enforce boundaries at config load time, not at runtime.
- **Platform abstraction** isolates Wayland/X11 differences behind factory functions.

## Phase Status

| Phase | Status |
|---|---|
| 1 — Core Transcription CLI | Done |
| 2 — AI Enhancement | Done |
| 3 — Daemon + Global Hotkey | Done |
| 4 — Meeting Mode | [Planned](docs/ROADMAP.md) |
| 5 — Context Awareness | [Planned](docs/ROADMAP.md) |

See [docs/ROADMAP.md](docs/ROADMAP.md) for Phase 4/5 design.

## Development

```bash
git clone <repo-url> && cd cuisp
uv sync --all-extras   # installs everything including dev tools
```

```bash
uv run pytest                    # run tests
uv run ruff check src/ tests/    # lint
uv run ruff format src/ tests/   # format
```

## License

MIT
