# Cuisp Roadmap

## Completed

### Phase 1 — Core Transcription CLI
- Config system (Pydantic + TOML + env vars)
- Audio recorder (sounddevice, lazy import)
- Whisper STT (faster-whisper, lazy model loading, Silero VAD, vocabulary hints)
- CLI: `cuisp transcribe`, `cuisp init`, `cuisp devices`

### Phase 2 — AI Enhancement
- httpx client for OpenAI-compatible APIs (OpenAI, Ollama, LM Studio, vLLM)
- Prompt templates (default/email/chat/rewrite) + custom TOML prompts
- Output filters (strip `<think>` tags, code fences, wrapping quotes)
- CLI: `cuisp enhance`, `--prompt` flag on transcribe

### Phase 3 — Daemon + Global Hotkey
- asyncio daemon with Unix socket server
- evdev hotkey listener (Wayland) + pynput fallback (X11)
- Text injection via clipboard (wl-copy/wtype or xclip/xdotool)
- Process lifecycle (double-fork, PID file, start/stop/status)
- CLI: `cuisp start`, `cuisp stop`, `cuisp status`

---

## Phase 4 — Meeting Mode

**Goal:** Continuous recording with chunked transcription and post-meeting
summarization.  The user starts a meeting session and gets a timestamped
transcript + summary when they stop.

### 4.1 — Continuous Chunked Recorder
- Add `MeetingRecorder` in `src/cuisp/audio/meeting.py`.
- Record in fixed-length chunks (default 30 s, configurable via
  `meeting.chunk_seconds` in config).
- Each chunk is a numpy array yielded to a processing queue.
- Guard rail: enforce `MAX_AUDIO_DURATION` per chunk; enforce a configurable
  `meeting.max_duration` (default 4 hours) for the whole session.

### 4.2 — Rolling Transcription Buffer
- Add `MeetingSession` in `src/cuisp/meeting/session.py`.
- Consumes chunks from the queue, transcribes each via `WhisperTranscriber`.
- Maintains an ordered list of `TranscriptionSegment` dataclasses:
  `(start_time, end_time, text, speaker_label)`.
- Optionally enhance each chunk in-flight (configurable: `meeting.enhance_chunks`).

### 4.3 — Speaker Change Detection (Heuristic)
- In `src/cuisp/meeting/speakers.py`, detect speaker changes using:
  - Silence gaps > 1.5 s between speech segments.
  - Energy envelope discontinuities.
- Label speakers as `Speaker 1`, `Speaker 2`, etc.
- **No pyannote dependency** — keep it lightweight. Pyannote diarization is
  deferred to a future optional feature.

### 4.4 — Post-Meeting Summarization
- At session end, concatenate all segment texts into a full transcript.
- Send transcript to the LLM with a new `meeting_summary` prompt template.
- Prompt requests: key decisions, action items, attendee summary.
- Output: Markdown file with timestamped transcript + summary block at top.

### 4.5 — CLI Integration
- `cuisp meeting start` — begin a meeting session.
- `cuisp meeting stop` — end session, produce transcript + summary.
- `cuisp meeting status` — show elapsed time, chunk count.
- `--output FILE` flag for custom output path.

### Config Additions
```toml
[meeting]
chunk_seconds = 30
max_duration = 14400   # 4 hours in seconds
enhance_chunks = false
output_dir = "~/Documents/cuisp-meetings"
```

### New Constants
- `MeetingState` enum: `IDLE`, `RECORDING`, `PROCESSING`, `DONE`
- `DEFAULT_CHUNK_SECONDS = 30`
- `MAX_MEETING_DURATION = 14400`

### Tests
- Unit: `MeetingRecorder` chunk boundaries, queue ordering.
- Unit: Speaker change detection on synthetic audio with silence gaps.
- Unit: `MeetingSession` segment accumulation.
- Integration: Full start → chunk → stop → summarize flow (mocked Whisper).

---

## Phase 5 — Context Awareness

**Goal:** Auto-select the enhancement prompt based on the currently focused
application window.  When dictating into a mail client, use the email prompt;
in Slack, use the chat prompt; in a code editor, use a code-comment prompt.

### 5.1 — Active Window Detection
- Add `src/cuisp/platform/window.py`.
- Wayland (Sway/Hyprland): parse `swaymsg -t get_tree` or
  `hyprctl activewindow -j` JSON output.
- X11: use `xdotool getactivewindow getwindowclassname`.
- Return `WindowInfo(app_id: str, title: str)` dataclass.

### 5.2 — Context Rules Engine
- Add `src/cuisp/context/rules.py`.
- A `ContextRule` matches on `app_id` regex and/or `title` regex, maps to a
  prompt name.
- Rules are defined in config:
  ```toml
  [[context.rules]]
  app_id = "thunderbird|evolution"
  prompt = "email"

  [[context.rules]]
  app_id = "slack|discord|telegram"
  prompt = "chat"

  [[context.rules]]
  title = ".*\\.py$"
  prompt = "code_comment"
  ```
- First matching rule wins. If no rule matches, fall back to
  `enhance.default_prompt`.

### 5.3 — Daemon Integration
- Before the enhance step in `CuispDaemon._process()`, query the active
  window and resolve the prompt via the rules engine.
- Pass the resolved prompt name to `EnhanceClient.enhance()`.
- Log the matched rule for debugging.

### 5.4 — CLI Override
- `--prompt` flag on `cuisp transcribe` continues to override context rules.
- `cuisp context show` — display the current window info and which rule
  would match, useful for debugging rules.

### Config Additions
```toml
[context]
enabled = true

[[context.rules]]
app_id = "thunderbird|evolution"
prompt = "email"

[[context.rules]]
app_id = "slack|discord|telegram"
prompt = "chat"
```

### New Constants
- No new enums needed; uses existing `PromptName` + custom prompt strings.

### Tests
- Unit: Rule matching (app_id regex, title regex, both, neither).
- Unit: First-match-wins ordering.
- Unit: Fallback to default when no rules match.
- Integration: Mock window detection → rule resolution → prompt selection.

---

## Future (Unscheduled)

- **Pyannote diarization** — optional speaker identification with voice
  embeddings. Requires `pyannote.audio` and a HuggingFace token.
- **Streaming transcription** — display partial results in real time during
  recording via Whisper's segment iterator.
- **PipeWire integration** — capture desktop audio for meeting mode.
- **Notification integration** — desktop notifications on transcription
  complete (via `notify-send`).
