"""Crossfire dashboard server."""
