"""Tests for drf_cedar.views module."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest
from rest_framework import serializers
from rest_framework import status
from rest_framework.exceptions import PermissionDenied
from rest_framework.parsers import FormParser
from rest_framework.parsers import JSONParser
from rest_framework.parsers import MultiPartParser
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.test import APIRequestFactory

from drf_cedar.views import ActionResult
from drf_cedar.views import BaseCedarAuthzView
from drf_cedar.views import CreateAPIView
from drf_cedar.views import CurrentUserScopedMixin
from drf_cedar.views import DestroyAPIView
from drf_cedar.views import import_from_path
from drf_cedar.views import ListAPIView
from drf_cedar.views import ListCreateAPIView
from drf_cedar.views import PostActionAPIView
from drf_cedar.views import RetrieveAPIView
from drf_cedar.views import RetrieveUpdateDestroyAPIView
from drf_cedar.views import ScopedViewMixin
from drf_cedar.views import UpdateAPIView

PERMIT_ALL = "permit(principal, action, resource);"
DENY_ALL = ""

_PARSERS = [JSONParser(), FormParser(), MultiPartParser()]


# ─── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def patch_view_deps(mocker):
    """Patch the cached view dependencies so views can be instantiated without
    a real policy file or attribute providers on disk."""
    mocker.patch("drf_cedar.views.get_policies", return_value=PERMIT_ALL)
    mocker.patch("drf_cedar.views.get_principal_attr_providers", return_value=[])


@pytest.fixture
def factory():
    return APIRequestFactory()


@pytest.fixture
def mock_user():
    u = MagicMock()
    u.pk = 1
    u.is_authenticated = True
    u.is_staff = False
    u.is_superuser = False
    u.groups.all.return_value = []
    return u


@pytest.fixture
def denied_authz():
    authz = MagicMock()
    authz.authorize.side_effect = PermissionDenied("Forbidden")
    return authz


# ─── Helpers ──────────────────────────────────────────────────────────────────


def _drf_request(raw, user):
    """Wrap a raw APIRequestFactory request in a DRF Request with a given user.

    Parsers are passed explicitly because Request(raw) without parsers defaults
    to an empty tuple, causing UnsupportedMediaType for JSON bodies.
    """
    req = Request(raw, authenticators=[], parsers=_PARSERS)
    req._user = user
    return req


class _Item:
    """Simple concrete test model — avoids MagicMock auto-creating authz_fields,
    which would otherwise cause json.dumps to fail inside Authz.authorize."""

    def __init__(self, pk=1, name="Widget"):
        self.pk = pk
        self.id = pk
        self.name = name


class ItemSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField()


# ─── Test view classes ────────────────────────────────────────────────────────
# Defined at module level so they can be reused across tests.
# Each view overrides the parts that would otherwise hit the database.


class ItemRetrieveView(RetrieveAPIView):
    model_name = "Item"
    serializer_class = ItemSerializer
    _item = None

    def get_object(self):
        return self._item


class ItemListView(ListAPIView):
    model_name = "Item"
    model_name_plural = "Items"
    serializer_class = ItemSerializer
    _qs = []

    def get_queryset(self):
        return self._qs


class ItemCreateView(CreateAPIView):
    model_name = "Item"
    serializer_class = ItemSerializer

    def get_queryset(self):
        return []

    def perform_create(self, serializer, request):
        pass  # skip DB save in tests


class ItemDestroyView(DestroyAPIView):
    model_name = "Item"
    serializer_class = ItemSerializer
    _item = None

    def get_object(self):
        return self._item

    def perform_destroy(self, instance, request):
        pass


class ItemUpdateView(UpdateAPIView):
    model_name = "Item"
    serializer_class = ItemSerializer
    _item = None

    def get_object(self):
        return self._item

    def perform_update(self, serializer, request):
        pass


class ItemRUDView(RetrieveUpdateDestroyAPIView):
    model_name = "Item"
    serializer_class = ItemSerializer
    _item = None

    def get_object(self):
        return self._item

    def perform_update(self, serializer, request):
        pass

    def perform_destroy(self, instance, request):
        pass


class ItemListCreateView(ListCreateAPIView):
    model_name = "Item"
    model_name_plural = "Items"
    serializer_class = ItemSerializer
    _qs = []

    def get_queryset(self):
        return self._qs

    def perform_create(self, serializer, request):
        pass


def _setup_view(view_class, request, *, item=None, qs=None, kwargs=None):
    """Instantiate a view and configure the minimal state for direct method calls."""
    view = view_class()
    view.request = request
    view.kwargs = kwargs or {}
    view.format_kwarg = None
    if item is not None:
        view._item = item
    if qs is not None:
        view._qs = qs
    return view


# ─── BaseCedarAuthzView ───────────────────────────────────────────────────────


class TestBaseCedarAuthzView:
    def test_action_uses_model_name(self):
        view = ItemRetrieveView()
        view.model_name = "Vehicle"
        assert view._action("Get") == "GetVehicle"

    def test_action_uses_action_prefix(self):
        view = ItemRetrieveView()
        view.action_prefix = "Admin"
        view.model_name = "Item"
        assert view._action("Get") == "AdminGetItem"

    def test_action_list_uses_model_name_plural(self):
        view = ItemListView()
        view.model_name = "Item"
        view.model_name_plural = "Items"
        assert view._action("List") == "ListItems"

    def test_action_list_falls_back_to_model_name_when_plural_unset(self):
        view = ItemListView()
        view.model_name = "Thing"
        view.model_name_plural = None
        assert view._action("List") == "ListThing"

    def test_action_falls_back_to_verbose_name_from_queryset(self):
        view = BaseCedarAuthzView()
        view.model_name = None
        view.model_name_plural = None
        view.action_prefix = ""
        mock_qs = MagicMock()
        mock_qs.model._meta.verbose_name = "my item"
        view.queryset = mock_qs
        assert view._action("Get") == "GetMyItem"

    def test_action_list_falls_back_to_verbose_name_plural_from_queryset(self):
        view = BaseCedarAuthzView()
        view.model_name = None
        view.model_name_plural = None
        view.action_prefix = ""
        mock_qs = MagicMock()
        mock_qs.model._meta.verbose_name = "my item"
        mock_qs.model._meta.verbose_name_plural = "my items"
        view.queryset = mock_qs
        assert view._action("List") == "ListMyItems"

    def test_get_scope_resource_returns_none_by_default(self, factory, mock_user):
        view = ItemListView()
        req = _drf_request(factory.get("/"), mock_user)
        assert view.get_scope_resource(req) is None

    def test_authz_constructed_with_policies_and_providers(self, mocker):
        providers = [MagicMock()]
        mocker.patch("drf_cedar.views.get_policies", return_value=PERMIT_ALL)
        mocker.patch(
            "drf_cedar.views.get_principal_attr_providers", return_value=providers
        )
        view = ItemRetrieveView()
        assert view.authz.policies == PERMIT_ALL
        assert view.authz.principal_attribute_providers is providers


# ─── RetrieveAPIView ──────────────────────────────────────────────────────────


class TestRetrieveAPIView:
    def test_get_returns_200_with_serialized_data(self, factory, mock_user):
        item = _Item(pk=5, name="Gizmo")
        req = _drf_request(factory.get("/"), mock_user)
        view = _setup_view(ItemRetrieveView, req, item=item)
        response = view.retrieve(req)
        assert response.status_code == status.HTTP_200_OK
        assert response.data == {"id": 5, "name": "Gizmo"}

    def test_get_calls_authorize_with_get_action_and_instance(self, factory, mock_user):
        item = _Item(pk=5)
        req = _drf_request(factory.get("/"), mock_user)
        view = _setup_view(ItemRetrieveView, req, item=item)
        view.authz = MagicMock()
        view.retrieve(req)
        view.authz.authorize.assert_called_once_with(mock_user, "GetItem", item)

    def test_get_raises_permission_denied_when_authz_denies(
        self, factory, mock_user, denied_authz
    ):
        item = _Item()
        req = _drf_request(factory.get("/"), mock_user)
        view = _setup_view(ItemRetrieveView, req, item=item)
        view.authz = denied_authz
        with pytest.raises(PermissionDenied):
            view.retrieve(req)


# ─── ListAPIView ──────────────────────────────────────────────────────────────


class TestListAPIView:
    def test_get_returns_200_with_list(self, factory, mock_user):
        items = [_Item(pk=1, name="A"), _Item(pk=2, name="B")]
        req = _drf_request(factory.get("/"), mock_user)
        view = _setup_view(ItemListView, req, qs=items)
        response = view.list(req)
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) == 2

    def test_get_calls_authorize_with_list_action_and_none_scope(
        self, factory, mock_user
    ):
        req = _drf_request(factory.get("/"), mock_user)
        view = _setup_view(ItemListView, req, qs=[])
        view.authz = MagicMock()
        view.list(req)
        view.authz.authorize.assert_called_once_with(mock_user, "ListItems", None)

    def test_get_returns_empty_list_when_queryset_empty(self, factory, mock_user):
        req = _drf_request(factory.get("/"), mock_user)
        view = _setup_view(ItemListView, req, qs=[])
        response = view.list(req)
        assert response.status_code == status.HTTP_200_OK
        assert response.data == []

    def test_get_raises_permission_denied_when_authz_denies(
        self, factory, mock_user, denied_authz
    ):
        req = _drf_request(factory.get("/"), mock_user)
        view = _setup_view(ItemListView, req, qs=[])
        view.authz = denied_authz
        with pytest.raises(PermissionDenied):
            view.list(req)


# ─── CreateAPIView ────────────────────────────────────────────────────────────


class TestCreateAPIView:
    def test_post_returns_201(self, factory, mock_user):
        raw = factory.post("/", {"id": 1, "name": "Foo"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_view(ItemCreateView, req)
        response = view.create(req)
        assert response.status_code == status.HTTP_201_CREATED

    def test_post_calls_authorize_with_create_action_and_none_scope(
        self, factory, mock_user
    ):
        raw = factory.post("/", {"id": 1, "name": "Foo"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_view(ItemCreateView, req)
        view.authz = MagicMock()
        view.create(req)
        view.authz.authorize.assert_called_once_with(mock_user, "CreateItem", None)

    def test_post_raises_permission_denied_when_authz_denies(
        self, factory, mock_user, denied_authz
    ):
        raw = factory.post("/", {"id": 1, "name": "Foo"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_view(ItemCreateView, req)
        view.authz = denied_authz
        with pytest.raises(PermissionDenied):
            view.create(req)

    def test_post_with_invalid_data_raises_validation_error(self, factory, mock_user):
        from rest_framework.exceptions import ValidationError

        raw = factory.post("/", {"bad": "data"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_view(ItemCreateView, req)
        with pytest.raises(ValidationError):
            view.create(req)


# ─── DestroyAPIView ───────────────────────────────────────────────────────────


class TestDestroyAPIView:
    def test_delete_returns_204(self, factory, mock_user):
        item = _Item()
        req = _drf_request(factory.delete("/"), mock_user)
        view = _setup_view(ItemDestroyView, req, item=item)
        response = view.destroy(req)
        assert response.status_code == status.HTTP_204_NO_CONTENT

    def test_delete_calls_authorize_with_delete_action_and_instance(
        self, factory, mock_user
    ):
        item = _Item(pk=3)
        req = _drf_request(factory.delete("/"), mock_user)
        view = _setup_view(ItemDestroyView, req, item=item)
        view.authz = MagicMock()
        view.destroy(req)
        view.authz.authorize.assert_called_once_with(mock_user, "DeleteItem", item)

    def test_delete_raises_permission_denied_when_authz_denies(
        self, factory, mock_user, denied_authz
    ):
        item = _Item()
        req = _drf_request(factory.delete("/"), mock_user)
        view = _setup_view(ItemDestroyView, req, item=item)
        view.authz = denied_authz
        with pytest.raises(PermissionDenied):
            view.destroy(req)


# ─── UpdateAPIView ────────────────────────────────────────────────────────────


class TestUpdateAPIView:
    def test_put_returns_200(self, factory, mock_user):
        item = _Item(pk=1, name="Old")
        raw = factory.put("/", {"id": 1, "name": "New"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_view(ItemUpdateView, req, item=item)
        response = view.update(req)
        assert response.status_code == status.HTTP_200_OK

    def test_put_calls_authorize_with_update_action_and_instance(
        self, factory, mock_user
    ):
        item = _Item(pk=7)
        raw = factory.put("/", {"id": 7, "name": "X"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_view(ItemUpdateView, req, item=item)
        view.authz = MagicMock()
        view.update(req)
        view.authz.authorize.assert_called_once_with(mock_user, "UpdateItem", item)

    def test_patch_calls_authorize_and_returns_200(self, factory, mock_user):
        item = _Item(pk=1, name="Orig")
        raw = factory.patch("/", {"name": "Patched"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_view(ItemUpdateView, req, item=item)
        view.authz = MagicMock()
        response = view.partial_update(req)
        view.authz.authorize.assert_called_once_with(mock_user, "UpdateItem", item)
        assert response.status_code == status.HTTP_200_OK

    def test_put_raises_permission_denied_when_authz_denies(
        self, factory, mock_user, denied_authz
    ):
        item = _Item()
        raw = factory.put("/", {"id": 1, "name": "X"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_view(ItemUpdateView, req, item=item)
        view.authz = denied_authz
        with pytest.raises(PermissionDenied):
            view.update(req)


# ─── RetrieveUpdateDestroyAPIView ─────────────────────────────────────────────


class TestRetrieveUpdateDestroyAPIView:
    def test_get_returns_200(self, factory, mock_user):
        item = _Item(pk=1, name="A")
        req = _drf_request(factory.get("/"), mock_user)
        view = _setup_view(ItemRUDView, req, item=item)
        response = view.retrieve(req)
        assert response.status_code == status.HTTP_200_OK

    def test_put_returns_200(self, factory, mock_user):
        item = _Item(pk=1, name="Old")
        raw = factory.put("/", {"id": 1, "name": "New"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_view(ItemRUDView, req, item=item)
        response = view.update(req)
        assert response.status_code == status.HTTP_200_OK

    def test_delete_returns_204(self, factory, mock_user):
        item = _Item()
        req = _drf_request(factory.delete("/"), mock_user)
        view = _setup_view(ItemRUDView, req, item=item)
        response = view.destroy(req)
        assert response.status_code == status.HTTP_204_NO_CONTENT

    def test_get_uses_get_action(self, factory, mock_user):
        item = _Item()
        req = _drf_request(factory.get("/"), mock_user)
        view = _setup_view(ItemRUDView, req, item=item)
        view.authz = MagicMock()
        view.retrieve(req)
        _, action, _ = view.authz.authorize.call_args[0]
        assert action == "GetItem"

    def test_put_uses_update_action(self, factory, mock_user):
        item = _Item()
        raw = factory.put("/", {"id": 1, "name": "X"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_view(ItemRUDView, req, item=item)
        view.authz = MagicMock()
        view.update(req)
        _, action, _ = view.authz.authorize.call_args[0]
        assert action == "UpdateItem"

    def test_delete_uses_delete_action(self, factory, mock_user):
        item = _Item()
        req = _drf_request(factory.delete("/"), mock_user)
        view = _setup_view(ItemRUDView, req, item=item)
        view.authz = MagicMock()
        view.destroy(req)
        _, action, _ = view.authz.authorize.call_args[0]
        assert action == "DeleteItem"

    def test_permission_denied_on_get_and_delete(
        self, factory, mock_user, denied_authz
    ):
        item = _Item()
        for call_name, raw in [
            ("retrieve", factory.get("/")),
            ("destroy", factory.delete("/")),
        ]:
            req = _drf_request(raw, mock_user)
            view = _setup_view(ItemRUDView, req, item=item)
            view.authz = denied_authz
            with pytest.raises(PermissionDenied):
                getattr(view, call_name)(req)


# ─── ScopedViewMixin ──────────────────────────────────────────────────────────
# The test view does NOT override get_queryset so that ScopedViewMixin.get_queryset
# is first in the MRO. queryset is set as an instance attribute in each test so
# that GenericAPIView.get_queryset() returns a mock queryset for super() calls.


class _ScopedItemView(ScopedViewMixin, ListCreateAPIView):
    model_name = "Item"
    model_name_plural = "Items"
    serializer_class = ItemSerializer
    scope_kwarg = "owner"
    lookup_url_kwarg = "user_pk"
    queryset = []  # overridden per-test via instance attribute


class TestScopedViewMixin:
    def test_get_scope_resource_fetches_scope_model_by_url_kwarg(
        self, factory, mock_user, mocker
    ):
        ScopeMock = MagicMock()
        scope_instance = MagicMock()
        mock_404 = mocker.patch(
            "drf_cedar.views.get_object_or_404", return_value=scope_instance
        )

        req = _drf_request(factory.get("/"), mock_user)
        view = _ScopedItemView()
        view.request = req
        view.kwargs = {"user_pk": "42"}
        view.format_kwarg = None
        view.scope_model = ScopeMock

        result = view.get_scope_resource(req)

        mock_404.assert_called_once_with(ScopeMock, id="42")
        assert result is scope_instance

    def test_get_scope_resource_returns_none_when_no_scope_model(
        self, factory, mock_user
    ):
        req = _drf_request(factory.get("/"), mock_user)
        view = _ScopedItemView()
        view.request = req
        view.kwargs = {}
        view.format_kwarg = None
        view.scope_model = None

        assert view.get_scope_resource(req) is None

    def test_get_queryset_filters_by_scope_kwarg(self, factory, mock_user):
        mock_qs = MagicMock()
        filtered_qs = MagicMock()
        mock_qs.filter.return_value = filtered_qs

        req = _drf_request(factory.get("/"), mock_user)
        view = _ScopedItemView()
        view.request = req
        view.kwargs = {"user_pk": "7"}
        view.format_kwarg = None
        view.queryset = mock_qs  # used by GenericAPIView.get_queryset via super()

        result = view.get_queryset()

        mock_qs.filter.assert_called_once_with(owner="7")
        assert result is filtered_qs

    def test_get_queryset_uses_lookup_url_kwarg_when_scope_kwarg_unset(
        self, factory, mock_user
    ):
        mock_qs = MagicMock()
        req = _drf_request(factory.get("/"), mock_user)
        view = _ScopedItemView()
        view.request = req
        view.kwargs = {"user_pk": "9"}
        view.format_kwarg = None
        view.scope_kwarg = None  # fall back to lookup_url_kwarg
        view.queryset = mock_qs

        view.get_queryset()

        mock_qs.filter.assert_called_once_with(user_pk="9")

    @pytest.mark.django_db
    def test_perform_create_saves_with_scope_attr(self, factory, mock_user, mocker):
        scope_obj = MagicMock()
        mocker.patch("drf_cedar.views.get_object_or_404", return_value=scope_obj)

        serializer = MagicMock()
        saved_obj = MagicMock()
        serializer.save.return_value = saved_obj

        req = _drf_request(factory.post("/"), mock_user)
        view = _ScopedItemView()
        view.request = req
        view.kwargs = {"user_pk": "5"}
        view.format_kwarg = None
        view.scope_model = MagicMock()

        ScopedViewMixin.perform_create(view, serializer, req)

        serializer.save.assert_called_once_with(owner=scope_obj)

    @pytest.mark.django_db
    def test_perform_create_uses_lookup_url_kwarg_as_scope_attr_when_scope_kwarg_unset(
        self, factory, mock_user, mocker
    ):
        scope_obj = MagicMock()
        mocker.patch("drf_cedar.views.get_object_or_404", return_value=scope_obj)

        serializer = MagicMock()
        req = _drf_request(factory.post("/"), mock_user)
        view = _ScopedItemView()
        view.request = req
        view.kwargs = {"user_pk": "5"}
        view.format_kwarg = None
        view.scope_model = MagicMock()
        view.scope_kwarg = None

        ScopedViewMixin.perform_create(view, serializer, req)

        serializer.save.assert_called_once_with(user_pk=scope_obj)

    def test_list_authorizes_against_scope_resource(self, factory, mock_user, mocker):
        scope_instance = MagicMock()
        mocker.patch("drf_cedar.views.get_object_or_404", return_value=scope_instance)

        mock_qs = MagicMock()
        mock_qs.filter.return_value = []

        req = _drf_request(factory.get("/"), mock_user)
        view = _ScopedItemView()
        view.request = req
        view.kwargs = {"user_pk": "3"}
        view.format_kwarg = None
        view.scope_model = MagicMock()
        view.queryset = mock_qs
        view.authz = MagicMock()

        view.list(req)

        _, _, resource = view.authz.authorize.call_args[0]
        assert resource is scope_instance


# ─── CurrentUserScopedMixin ───────────────────────────────────────────────────
# Same pattern as ScopedViewMixin: no get_queryset override so the mixin's
# implementation is first in MRO.


class _CurrentUserScopedItemView(CurrentUserScopedMixin, ListAPIView):
    model_name = "Item"
    model_name_plural = "Items"
    serializer_class = ItemSerializer
    queryset = []  # overridden per-test via instance attribute


class TestCurrentUserScopedMixin:
    def test_get_scope_resource_returns_current_user(self, factory, mock_user, mocker):
        mocker.patch("drf_cedar.views.get_user", return_value=mock_user)
        req = _drf_request(factory.get("/"), mock_user)
        view = _CurrentUserScopedItemView()
        view.request = req
        view.kwargs = {}
        view.format_kwarg = None

        result = view.get_scope_resource(req)
        assert result is mock_user

    def test_get_queryset_filters_by_user_when_authenticated(self, factory, mock_user):
        mock_qs = MagicMock()
        filtered = MagicMock()
        mock_qs.filter.return_value = filtered

        req = _drf_request(factory.get("/"), mock_user)
        view = _CurrentUserScopedItemView()
        view.request = req
        view.kwargs = {}
        view.format_kwarg = None
        view.queryset = mock_qs

        result = view.get_queryset()

        mock_qs.filter.assert_called_once_with(user=mock_user)
        assert result is filtered

    def test_get_queryset_returns_none_for_unauthenticated(self, factory):
        anon = MagicMock()
        anon.is_authenticated = False

        mock_qs = MagicMock()
        empty_qs = MagicMock()
        mock_qs.none.return_value = empty_qs

        req = _drf_request(factory.get("/"), anon)
        view = _CurrentUserScopedItemView()
        view.request = req
        view.kwargs = {}
        view.format_kwarg = None
        view.queryset = mock_qs

        result = view.get_queryset()

        mock_qs.none.assert_called_once()
        assert result is empty_qs

    def test_get_queryset_returns_none_when_user_is_none(self, factory):
        mock_qs = MagicMock()

        req = _drf_request(factory.get("/"), None)
        req._user = None

        view = _CurrentUserScopedItemView()
        view.request = req
        view.kwargs = {}
        view.format_kwarg = None
        view.queryset = mock_qs

        view.get_queryset()

        mock_qs.none.assert_called_once()

    def test_list_authorizes_against_current_user(self, factory, mock_user, mocker):
        mocker.patch("drf_cedar.views.get_user", return_value=mock_user)
        mock_qs = MagicMock()
        mock_qs.filter.return_value = []

        req = _drf_request(factory.get("/"), mock_user)
        view = _CurrentUserScopedItemView()
        view.request = req
        view.kwargs = {}
        view.format_kwarg = None
        view.queryset = mock_qs
        view.authz = MagicMock()

        view.list(req)

        _, _, resource = view.authz.authorize.call_args[0]
        assert resource is mock_user


# ─── PostActionMixin / PostActionAPIView ──────────────────────────────────────


class SimplePostActionView(PostActionAPIView):
    action_name = "DoSomething"
    serializer_class = None
    _result = None

    def perform_action(self, request, serializer, *args, **kwargs):
        return self._result


class SerializerPostActionView(PostActionAPIView):
    action_name = "DoThing"
    serializer_class = ItemSerializer
    _result = None

    def perform_action(self, request, serializer, *args, **kwargs):
        return self._result


def _setup_action_view(view_class, request, *, result=None):
    view = view_class()
    view.request = request
    view.kwargs = {}
    view.format_kwarg = None
    view.authz = MagicMock()
    if result is not None:
        view._result = result
    return view


class TestPostActionMixin:
    def test_post_calls_authorize_with_action_name(self, factory, mock_user):
        req = _drf_request(factory.post("/"), mock_user)
        view = _setup_action_view(
            SimplePostActionView, req, result=ActionResult(success=True)
        )
        view.create(req)
        view.authz.authorize.assert_called_once_with(mock_user, "DoSomething", None)

    def test_post_without_serializer_passes_none_to_perform_action(
        self, factory, mock_user, mocker
    ):
        req = _drf_request(factory.post("/"), mock_user)
        view = _setup_action_view(
            SimplePostActionView, req, result=ActionResult(success=True)
        )
        perform = mocker.patch.object(
            view, "perform_action", return_value=ActionResult(success=True)
        )

        view.create(req)

        perform.assert_called_once()
        serializer_arg = perform.call_args[0][1]
        assert serializer_arg is None

    def test_post_with_serializer_validates_and_passes_serializer(
        self, factory, mock_user, mocker
    ):
        raw = factory.post("/", {"id": 1, "name": "Foo"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_action_view(
            SerializerPostActionView, req, result=ActionResult(success=True)
        )
        captured = {}

        def capture(request, serializer, *args, **kwargs):
            captured["serializer"] = serializer
            return ActionResult(success=True)

        view.perform_action = capture
        view.create(req)

        assert captured["serializer"] is not None
        assert captured["serializer"].validated_data["name"] == "Foo"

    def test_post_with_invalid_data_raises_validation_error(self, factory, mock_user):
        from rest_framework.exceptions import ValidationError

        raw = factory.post("/", {"bad": "data"}, format="json")
        req = _drf_request(raw, mock_user)
        view = _setup_action_view(SerializerPostActionView, req)
        with pytest.raises(ValidationError):
            view.create(req)

    def test_action_result_returned_as_200_response(self, factory, mock_user):
        req = _drf_request(factory.post("/"), mock_user)
        view = _setup_action_view(
            SimplePostActionView, req, result=ActionResult(success=True, message="done")
        )
        response = view.create(req)
        assert response.status_code == status.HTTP_200_OK
        assert response.data["success"] is True
        assert response.data["message"] == "done"

    def test_action_result_failure_reflected_in_response(self, factory, mock_user):
        req = _drf_request(factory.post("/"), mock_user)
        view = _setup_action_view(
            SimplePostActionView,
            req,
            result=ActionResult(success=False, message="oops"),
        )
        response = view.create(req)
        assert response.status_code == status.HTTP_200_OK
        assert response.data["success"] is False
        assert response.data["message"] == "oops"

    def test_response_returned_directly_when_perform_action_returns_response(
        self, factory, mock_user
    ):
        custom_response = Response({"custom": True}, status=status.HTTP_202_ACCEPTED)
        req = _drf_request(factory.post("/"), mock_user)
        view = _setup_action_view(SimplePostActionView, req, result=custom_response)
        response = view.create(req)
        assert response is custom_response

    def test_raises_permission_denied_when_authz_denies(
        self, factory, mock_user, denied_authz
    ):
        req = _drf_request(factory.post("/"), mock_user)
        view = _setup_action_view(SimplePostActionView, req)
        view.authz = denied_authz
        with pytest.raises(PermissionDenied):
            view.create(req)

    def test_action_method_returns_action_name(self, factory, mock_user):
        view = SimplePostActionView()
        # PostActionAPIView._action() ignores prefix, always returns action_name
        assert view._action("anything") == "DoSomething"
        assert view._action("List") == "DoSomething"


# ─── import_from_path ─────────────────────────────────────────────────────────


class TestImportFromPath:
    def test_imports_class_by_dotted_path(self):
        from rest_framework.serializers import Serializer

        cls = import_from_path("rest_framework.serializers.Serializer")
        assert cls is Serializer

    def test_raises_improperly_configured_for_path_without_dot(self):
        from django.core.exceptions import ImproperlyConfigured

        with pytest.raises(ImproperlyConfigured, match="Invalid contributor path"):
            import_from_path("nodot")

    def test_raises_improperly_configured_for_missing_attribute(self):
        from django.core.exceptions import ImproperlyConfigured

        with pytest.raises(ImproperlyConfigured, match="not found"):
            import_from_path("rest_framework.serializers.DoesNotExist")
