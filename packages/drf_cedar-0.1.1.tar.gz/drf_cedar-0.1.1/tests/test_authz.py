"""Tests for drf_cedar.authz module."""

from __future__ import annotations

from unittest.mock import MagicMock
from unittest.mock import patch

import pytest
from django.contrib.auth.models import User
from rest_framework.exceptions import PermissionDenied

from drf_cedar.authz import Authz

# Cedar policy that permits everything — used for "allowed" integration tests.
PERMIT_ALL = "permit(principal, action, resource);"

# Empty policy string — Cedar is deny-by-default, so no policies = deny all.
DENY_ALL = ""


def _mock_user(pk=1, is_staff=False, is_superuser=False, groups=None):
    user = MagicMock()
    user.pk = pk
    user.is_staff = is_staff
    user.is_superuser = is_superuser
    user.is_authenticated = True
    user.groups.all.return_value = groups or []
    return user


def _mock_group(pk, name):
    g = MagicMock()
    g.pk = pk
    g.name = name
    return g


def _django_user(pk=1, is_staff=False, is_superuser=False, groups=None, mocker=None):
    """Return an unsaved Django User with groups.all() mocked."""
    user = User(
        pk=pk, username=f"user{pk}", is_staff=is_staff, is_superuser=is_superuser
    )
    if mocker:
        mocker.patch.object(user.groups, "all", return_value=groups or [])
    else:
        user.groups.all = MagicMock(return_value=groups or [])
    return user


class TestAuthzAuthorize:
    def test_permit_all_policy_does_not_raise(self):
        authz = Authz(PERMIT_ALL)
        user = _mock_user(pk=1)
        authz.authorize(user, "ListItems", None)  # no exception

    def test_deny_all_policy_raises_permission_denied(self):
        authz = Authz(DENY_ALL)
        user = _mock_user(pk=1)
        with pytest.raises(PermissionDenied):
            authz.authorize(user, "ListItems", None)

    def test_anonymous_user_uses_anonymous_principal(self):
        """Unauthenticated user should still get a Cedar decision (permit or deny)."""
        authz = Authz(PERMIT_ALL)
        anon = MagicMock()
        anon.is_authenticated = False
        # Should not raise with permit-all
        authz.authorize(anon, "SomeAction", None)

    def test_none_user_uses_anonymous_principal(self):
        authz = Authz(PERMIT_ALL)
        authz.authorize(None, "SomeAction", None)  # no exception

    def test_resource_none_uses_global_resource(self):
        """resource=None should map to System::"global" without error."""
        authz = Authz(PERMIT_ALL)
        user = _mock_user(pk=1)
        authz.authorize(user, "GlobalAction", None)

    def test_resource_provided_includes_resource_entity(self):
        authz = Authz(PERMIT_ALL)
        user = _mock_user(pk=1)
        resource = MagicMock(spec=["pk"])
        type(resource).__name__ = "Widget"
        resource.pk = "42"
        authz.authorize(user, "GetWidget", resource)

    def test_context_merged_into_cedar_context(self):
        """Extra context passed to authorize should appear in the Cedar request."""
        captured = {}

        def fake_is_authorized(request, policies, entities):
            captured.update(request)
            result = MagicMock()
            result.allowed = True
            return result

        with patch("drf_cedar.authz.is_authorized", side_effect=fake_is_authorized):
            authz = Authz(PERMIT_ALL)
            user = _mock_user(pk=1)
            authz.authorize(user, "Act", None, context={"allow": {"special": True}})

        ctx = captured["context"]
        assert ctx["allow"]["special"] is True
        assert "self_signup" in ctx["allow"]

    def test_self_signup_default_false(self):
        captured = {}

        def fake_is_authorized(request, policies, entities):
            captured.update(request)
            result = MagicMock()
            result.allowed = True
            return result

        with patch("drf_cedar.authz.is_authorized", side_effect=fake_is_authorized):
            authz = Authz(PERMIT_ALL)
            user = _mock_user(pk=1)
            authz.authorize(user, "Act", None)

        assert captured["context"]["allow"]["self_signup"] is False

    def test_self_signup_setting_respected(self):
        captured = {}

        def fake_is_authorized(request, policies, entities):
            captured.update(request)
            result = MagicMock()
            result.allowed = True
            return result

        with patch("drf_cedar.authz.is_authorized", side_effect=fake_is_authorized):
            with patch("drf_cedar.authz.django_settings") as mock_settings:
                mock_settings.ALLOW_SELF_SIGNUP = True
                authz = Authz(PERMIT_ALL)
                user = _mock_user(pk=1)
                authz.authorize(user, "Act", None)

        assert captured["context"]["allow"]["self_signup"] is True

    def test_principal_is_user_for_authenticated(self):
        captured = {}

        def fake_is_authorized(request, policies, entities):
            captured.update(request)
            result = MagicMock()
            result.allowed = True
            return result

        with patch("drf_cedar.authz.is_authorized", side_effect=fake_is_authorized):
            authz = Authz(PERMIT_ALL)
            user = _mock_user(pk=7)
            authz.authorize(user, "Act", None)

        assert captured["principal"] == 'User::"7"'

    def test_principal_is_anonymous_for_unauthenticated(self):
        captured = {}

        def fake_is_authorized(request, policies, entities):
            captured.update(request)
            result = MagicMock()
            result.allowed = True
            return result

        with patch("drf_cedar.authz.is_authorized", side_effect=fake_is_authorized):
            authz = Authz(PERMIT_ALL)
            anon = MagicMock()
            anon.is_authenticated = False
            authz.authorize(anon, "Act", None)

        assert captured["principal"] == 'Anonymous::"guest"'

    def test_resource_entity_uses_model_class_name_and_pk(self):
        captured = {}

        def fake_is_authorized(request, policies, entities):
            captured.update(request)
            result = MagicMock()
            result.allowed = True
            return result

        with patch("drf_cedar.authz.is_authorized", side_effect=fake_is_authorized):
            authz = Authz(PERMIT_ALL)
            user = _mock_user(pk=1)
            resource = MagicMock(spec=["pk"])
            type(resource).__name__ = "Document"
            resource.pk = "55"
            authz.authorize(user, "Read", resource)

        assert captured["resource"] == 'Document::"55"'

    def test_no_resource_uses_global(self):
        captured = {}

        def fake_is_authorized(request, policies, entities):
            captured.update(request)
            result = MagicMock()
            result.allowed = True
            return result

        with patch("drf_cedar.authz.is_authorized", side_effect=fake_is_authorized):
            authz = Authz(PERMIT_ALL)
            user = _mock_user(pk=1)
            authz.authorize(user, "Act", None)

        assert captured["resource"] == 'System::"global"'

    def test_action_wrapped_in_action_namespace(self):
        captured = {}

        def fake_is_authorized(request, policies, entities):
            captured.update(request)
            result = MagicMock()
            result.allowed = True
            return result

        with patch("drf_cedar.authz.is_authorized", side_effect=fake_is_authorized):
            authz = Authz(PERMIT_ALL)
            user = _mock_user(pk=1)
            authz.authorize(user, "ListWidgets", None)

        assert captured["action"] == 'Action::"ListWidgets"'

    def test_principal_attribute_providers_passed_through(self):
        """Principal attribute providers should enrich user entities."""
        provider = MagicMock()
        provider.get_attributes.return_value = {"tier": "premium"}
        authz = Authz(PERMIT_ALL, principal_attribute_providers=[provider])
        user = _mock_user(pk=1)
        authz.authorize(user, "Act", None)
        provider.get_attributes.assert_called_once_with(user)

    def test_permission_denied_message(self):
        authz = Authz(DENY_ALL)
        user = _mock_user(pk=1)
        with pytest.raises(PermissionDenied, match="Forbidden"):
            authz.authorize(user, "Act", None)

    def test_policies_passed_to_cedar(self):
        """Authz should forward the policy string to is_authorized."""
        captured = {}

        def fake_is_authorized(request, policies, entities):
            captured["policies"] = policies
            result = MagicMock()
            result.allowed = True
            return result

        custom_policy = "permit(principal, action, resource);"
        with patch("drf_cedar.authz.is_authorized", side_effect=fake_is_authorized):
            authz = Authz(custom_policy)
            user = _mock_user(pk=1)
            authz.authorize(user, "Act", None)

        assert captured["policies"] == custom_policy
