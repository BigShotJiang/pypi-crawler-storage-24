import importlib
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from django.conf import settings
from django.contrib.auth import get_user
from django.core.exceptions import ImproperlyConfigured
from django.db import transaction
from django.shortcuts import get_object_or_404
from rest_framework import mixins
from rest_framework import status
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response

from .authz import Authz
from .serializers import ActionResultSerializer


class CreateModelMixin(mixins.CreateModelMixin):
    def create(self, request, *args, **kwargs):
        resource = self.get_scope_resource(request, *args, **kwargs)
        self.authz.authorize(request.user, self._action("Create"), resource)
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer, request=request)
        headers = self.get_success_headers(serializer.data)
        return Response(
            serializer.data, status=status.HTTP_201_CREATED, headers=headers
        )

    @transaction.atomic
    def perform_create(self, serializer, request):
        obj = serializer.save()
        self.post_create(obj)
        transaction.on_commit(lambda: self.post_commit_create(obj))

    def post_create(self, obj):
        pass

    def post_commit_create(self, obj):
        pass


class DestroyModelMixin(mixins.DestroyModelMixin):
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.authz.authorize(request.user, self._action("Delete"), instance)
        self.perform_destroy(instance, request=request)
        return Response(status=status.HTTP_204_NO_CONTENT)

    @transaction.atomic
    def perform_destroy(self, instance, request):
        instance.delete()
        self.post_destroy(instance)
        transaction.on_commit(lambda: self.post_commit_destroy(instance))

    def post_destroy(self, obj):
        pass

    def post_commit_destroy(self, obj):
        pass


class ListModelMixin(mixins.ListModelMixin):
    def list(self, request, *args, **kwargs):
        resource = self.get_scope_resource(request, *args, **kwargs)
        self.authz.authorize(request.user, self._action("List"), resource)

        queryset = self.filter_queryset(self.get_queryset())

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class RetrieveModelMixin(mixins.RetrieveModelMixin):
    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        self.authz.authorize(request.user, self._action("Get"), instance)
        serializer = self.get_serializer(instance)
        return Response(serializer.data)


class UpdateModelMixin(mixins.UpdateModelMixin):
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop("partial", False)
        instance = self.get_object()
        self.authz.authorize(request.user, self._action("Update"), instance)
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer, request=request)

        if getattr(instance, "_prefetched_objects_cache", None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}

        return Response(serializer.data)

    @transaction.atomic
    def perform_update(self, serializer, request):
        obj = serializer.save()
        self.post_update(obj)
        transaction.on_commit(lambda: self.post_commit_update(obj))

    def post_update(self, obj):
        pass

    def post_commit_update(self, obj):
        pass


def _get_policy_path() -> Path:
    base = Path.cwd().resolve()
    raw = settings.CEDAR_POLICY_PATH
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = base / p
    p = p.resolve()
    if not p.is_file():
        raise FileNotFoundError(f"Policy file not found at {p}")
    return p


@lru_cache(maxsize=1)
def get_policies() -> str:
    path = _get_policy_path()
    return path.read_text()


def import_from_path(path: str):
    try:
        module_path, attr = path.rsplit(".", 1)
    except ValueError as e:
        raise ImproperlyConfigured(
            f"Invalid contributor path '{path}'. Expected 'some.module.ClassName'."
        ) from e

    module = importlib.import_module(module_path)
    try:
        return getattr(module, attr)
    except AttributeError as e:
        raise ImproperlyConfigured(
            f"Contributor '{path}' not found (no attribute '{attr}' in "
            f"'{module_path}')."
        ) from e


@lru_cache(maxsize=1)
def get_principal_attr_providers():
    paths = getattr(settings, "CEDAR_PRINCIPAL_ATTRIBUTE_PROVIDERS", [])
    if not isinstance(paths, (list, tuple)):
        raise ImproperlyConfigured(
            "CEDAR_PRINCIPAL_ATTRIBUTE_PROVIDERS must be a list/tuple."
        )

    providers = []
    for p in paths:
        cls = import_from_path(p)
        providers.append(cls())  # instantiate
    return providers


class BaseCedarAuthzView(GenericAPIView):
    """
    Base view that integrates Cedar authorization.

    Cedar authorization requests are performed for all requests, with the request
    containing:
    - The user as the principal
    - The resource determined by the view (either the object for detail views or a
    scope resource for list views)
    - The action determined by the view and HTTP method, e.g. "CreateVehicle" for a
    POST to a VehicleViewSet
    """

    action_prefix = ""
    model_name = None
    model_name_plural = None
    permission_classes = []  #  we'll do our own permission checking

    def __init__(self, **kwargs):
        self.authz = Authz(
            policies=get_policies(),
            principal_attribute_providers=get_principal_attr_providers(),
        )

    def _action(self, prefix):
        model_name = (
            self.model_name
            or self.queryset.model._meta.verbose_name.title().replace(" ", "")
        )  # type: ignore
        model_name_plural = (
            self.model_name_plural
            or self.model_name
            or self.queryset.model._meta.verbose_name_plural.title().replace(" ", "")
        )  # type: ignore
        if prefix == "List":
            model_name = model_name_plural
        return f"{self.action_prefix}{prefix}{model_name}"

    def get_scope_resource(self, request, *args, **kwargs) -> object | None:
        return None


@dataclass
class ActionResult:
    success: bool
    message: str | None = None


class PostActionMixin:
    """
    Non-model post action mixin used by PostActionAPIView.

    Handles Cedar authorization and optional request body deserialization for
    POST-only action endpoints, then delegates to perform_action. Subclasses
    should implement perform_action and either return an ActionResult or a DRF
    Response.
    """

    action_name = None
    serializer_class = None

    def create(self, request, *args, **kwargs):
        scope = self.get_scope_resource(request, *args, **kwargs)
        self.authz.authorize(request.user, self.action_name, scope)
        serializer = None
        if self.serializer_class:
            serializer = self.serializer_class(data=request.data)
            serializer.is_valid(raise_exception=True)
        result = self.perform_action(request, serializer, *args, **kwargs)
        if isinstance(result, Response):
            return result
        return Response(ActionResultSerializer(result).data, status=status.HTTP_200_OK)

    def get_scope_resource(self, request, *args, **kwargs) -> object | None:
        return None

    def perform_action(
        self, request, serializer, *args, **kwargs
    ) -> ActionResult | Response:
        raise NotImplementedError("Subclasses must implement perform_action")


class CurrentUserScopedMixin:
    def get_scope_resource(self, request, *args, **kwargs) -> object | None:
        user = get_user(self.request)
        return user

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if not user or not user.is_authenticated:
            return qs.none()
        return qs.filter(user=user)


class PostActionAPIView(PostActionMixin, BaseCedarAuthzView):
    """
    Base view for all POST-only non-model action endpoints.
    """

    def _action(self, prefix):
        return self.action_name

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)


class SimpleRetrieveAPIView(BaseCedarAuthzView):
    """
    Simple retrieve endpoint.
    """

    action_name = None
    serializer_class = None

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        self.authz.authorize(request.user, self.action_name, instance)
        serializer = self.get_serializer(instance)
        return Response(serializer.data)

    def get_object(self):
        raise NotImplementedError("Subclasses must implement get_object")


class CreateAPIView(CreateModelMixin, BaseCedarAuthzView):
    """
    Create endpoint.
    """

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)


class ListAPIView(ListModelMixin, BaseCedarAuthzView):
    """
    List endpoint.
    """

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)


class RetrieveAPIView(RetrieveModelMixin, BaseCedarAuthzView):
    """
    Read endpoint to retrieve a single model instance.
    """

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)


class DestroyAPIView(DestroyModelMixin, BaseCedarAuthzView):
    """
    Delete endpoint for a single model instance.
    """

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)


class UpdateAPIView(UpdateModelMixin, BaseCedarAuthzView):
    """
    Update endpoint for a single model instance.
    """

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)


class ListCreateAPIView(ListModelMixin, CreateModelMixin, BaseCedarAuthzView):
    """
    Read-write endpoint for a collection of model instances.
    """

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)


class RetrieveUpdateAPIView(RetrieveModelMixin, UpdateModelMixin, BaseCedarAuthzView):
    """
    Read-write endpoint for a single model instance.
    """

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)


class RetrieveDestroyAPIView(RetrieveModelMixin, DestroyModelMixin, BaseCedarAuthzView):
    """
    Read-delete endpoint for a single model instance.
    """

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)


class RetrieveUpdateDestroyAPIView(
    RetrieveModelMixin, UpdateModelMixin, DestroyModelMixin, BaseCedarAuthzView
):
    """
    Read-write-delete endpoint for a single model instance.
    """

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)


class ScopedViewMixin:
    """
    Apply this mixin to a view to enable scoping by a related model, e.g. listing or
    creating objects related to a specific User.

    This allows use of a factory URL that determine the scope of a list or create
    operation. For example, POST /users/{id}/vehicles/ to create a Vehicle owned by a
    specific User. The resulting authorization request is made with the User as the
    resource, rather than a global resource.
    """

    scope_model = None  # the class of the model we're scoping by, e.g. User
    scope_kwarg = None  # the kwarg defining the scope on the target model, e.g. "owner"

    def get_scope_resource(self, request=None, *args, **kwargs) -> object | None:
        if self.scope_model and self.lookup_url_kwarg:
            scope_id = self.kwargs[self.lookup_url_kwarg]
            return get_object_or_404(self.scope_model, id=scope_id)
        return None

    def get_queryset(self):
        scope_pk = self.kwargs[self.lookup_url_kwarg]
        scope_attr = self.scope_kwarg or self.lookup_url_kwarg
        return super().get_queryset().filter(**{scope_attr: scope_pk})

    @transaction.atomic
    def perform_create(self, serializer, request):
        scope_pk = self.kwargs[self.lookup_url_kwarg]
        scope_obj = get_object_or_404(self.scope_model, pk=scope_pk)
        scope_attr = self.scope_kwarg or self.lookup_url_kwarg
        obj = serializer.save(**{scope_attr: scope_obj})
        self.post_create(obj)
        transaction.on_commit(lambda: self.post_commit_create(obj))
