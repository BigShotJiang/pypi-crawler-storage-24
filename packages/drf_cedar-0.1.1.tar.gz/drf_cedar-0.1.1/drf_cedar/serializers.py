import base64
import binascii

from django.core.files.base import ContentFile
from rest_framework import serializers


class BaseModelSerializer(serializers.ModelSerializer):
    class Meta:
        fields = "__all__"
        read_only_fields = ["created_at", "updated_at", "id"]

    def _get_attr(self, attr, data):
        return data.get(
            attr, getattr(self.instance, attr, None) if self.instance else None
        )


class DataURLImageField(serializers.ImageField):
    """
    Accepts either:
      - a multipart uploaded file (normal ImageField behaviour)
      - a data URL string: "data:image/png;base64,...."
      - null to clear
    """

    def to_internal_value(self, data):
        if data is None:
            return None

        if isinstance(data, str):
            if not data.startswith("data:"):
                raise serializers.ValidationError("Expected a data URL.")

            try:
                header, b64 = data.split(";base64,", 1)
            except ValueError as e:
                raise serializers.ValidationError("Invalid data URL format.") from e

            # header like: data:image/png
            try:
                mime = header.split(":", 1)[1]
                ext = mime.split("/", 1)[1]
            except Exception as e:
                raise serializers.ValidationError("Invalid data URL header.") from e

            try:
                raw = base64.b64decode(b64)
            except (binascii.Error, ValueError) as e:
                raise serializers.ValidationError("Invalid base64 payload.") from e

            file = ContentFile(raw, name=f"signature.{ext}")
            return super().to_internal_value(file)

        return super().to_internal_value(data)


class ActionResultSerializer(serializers.Serializer):
    success = serializers.BooleanField()
    message = serializers.CharField(required=False, allow_null=True)
