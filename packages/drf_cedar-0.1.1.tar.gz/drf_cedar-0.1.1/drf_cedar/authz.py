from __future__ import annotations

import json
import logging
from collections.abc import Mapping
from dataclasses import dataclass
from dataclasses import field
from typing import Any

from cedarpy import is_authorized
from django.conf import settings as django_settings
from django.contrib.auth.models import AbstractUser
from django.db.models import Model
from rest_framework.exceptions import PermissionDenied

logger = logging.getLogger(__name__)


class Authz:
    def __init__(
        self, policies: str, principal_attribute_providers: list[Any] | None = None
    ):
        self.policies = policies
        self.principal_attribute_providers = principal_attribute_providers or []

    def authorize(
        self,
        user: AbstractUser,
        action: str,
        resource: Model | None,
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        entities = _make_principal_entities(
            user, principal_attribute_providers=self.principal_attribute_providers
        )
        if resource:
            entities.update(
                _make_entities(resource, self.principal_attribute_providers)
            )
        entities = [e.to_dict() for e in entities]
        cedar_resource = (
            resource
            and f'{type(resource).__name__}::"{resource.pk}"'
            or 'System::"global"'
        )
        principal = 'Anonymous::"guest"'
        if user and user.is_authenticated:
            principal = f'User::"{str(user.pk)}"'
        cedar_context: dict[str, Any] = {
            "allow": {
                "self_signup": getattr(django_settings, "ALLOW_SELF_SIGNUP", False)
            }
        }
        if context:
            _deep_merge(cedar_context, context)
        authz_request = dict(
            principal=principal,
            action=f'Action::"{action}"',
            resource=cedar_resource,
            context=cedar_context,
        )
        logger.debug(f"Entities:\n {json.dumps(entities, indent=2)}")
        logger.debug(f"AuthRequest:\n {json.dumps(authz_request, indent=2)}")
        authz_result = is_authorized(authz_request, self.policies, entities)
        if not authz_result.allowed:
            logger.debug(f"AuthzResult errors: {authz_result.diagnostics.errors}")
            logger.info(f"Authz denied: {authz_request}")
            raise PermissionDenied("Forbidden")


@dataclass(frozen=True)
class EntityRef:
    type: str
    id: str

    def to_dict(self) -> dict:
        return dict(type=self.type, id=self.id)


@dataclass(frozen=True)
class Entity:
    ref: EntityRef
    attrs: dict[str, Any] = field(default_factory=dict)
    parents: set[EntityRef] = field(default_factory=set)

    def __hash__(self):
        return hash((self.ref.type, self.ref.id))

    def __eq__(self, value):
        return isinstance(value, Entity) and self.ref == value.ref

    @staticmethod
    def create(type: str, id: str) -> Entity:
        return Entity(EntityRef(type, id))

    def to_dict(self) -> dict:
        return {
            "uid": {"__entity": self.ref.to_dict()},
            "attrs": self.attrs,
            "parents": [p.to_dict() for p in self.parents],
        }


def _make_user_entities(
    user: AbstractUser, principal_attribute_providers: list[Any]
) -> set[Entity]:
    result = set()
    attrs = {
        "id": str(user.pk),
        "is_staff": user.is_staff,
        "is_superuser": user.is_superuser,
    }
    for provider in principal_attribute_providers:
        attrs.update(provider.get_attributes(user))

    result.add(
        Entity(
            EntityRef("User", str(user.pk)),
            attrs=attrs,
            parents={EntityRef("Group", group.name) for group in user.groups.all()},
        )
    )
    for group in user.groups.all():
        result.add(
            Entity(
                EntityRef("Group", group.name),
                attrs={"id": str(group.pk)},
            )
        )
    return result


def _make_principal_entities(
    user: AbstractUser, principal_attribute_providers: list[Any]
) -> set[Entity]:
    if not user or not user.is_authenticated:
        return {Entity(EntityRef("Anonymous", "guest"))}

    return _make_user_entities(user, principal_attribute_providers)


def _make_entities(
    entity: Model, principal_attribute_providers: list[Any]
) -> set[Entity]:
    if isinstance(entity, AbstractUser):
        return _make_principal_entities(entity, principal_attribute_providers)

    result = set()

    attrs: dict[str, Any] = {}
    authz_fields = getattr(entity, "authz_fields", None)
    if callable(authz_fields):
        attrs = authz_fields()  # type: ignore[assignment]

    attrs["id"] = str(entity.pk)
    result.add(
        Entity(
            EntityRef(type(entity).__name__, str(entity.pk)),
            attrs=attrs,
        )
    )
    return result


def _deep_merge(dst: dict[str, Any], src: Mapping[str, Any]) -> dict[str, Any]:
    """
    Merge src into dst recursively.
    - dict + dict => recurse
    - otherwise src overwrites dst
    """
    for k, v in src.items():
        if isinstance(v, Mapping) and isinstance(dst.get(k), Mapping):
            _deep_merge(dst[k], v)  # type: ignore[index]
        else:
            dst[k] = v
    return dst
