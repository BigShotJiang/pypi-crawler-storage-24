from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class ConverterConfig(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="CONVERTER_",
        env_file=".env",
        env_file_encoding="utf-8",
    )

    input_dir: Path = Path("./export")
    output_dir: Path = Path("./archive")
    redact_pii: bool = True
    include_thinking: bool = False
    deduplicate_by_hash: bool = True
    max_filename_length: int = 200
    verbose: bool = False
