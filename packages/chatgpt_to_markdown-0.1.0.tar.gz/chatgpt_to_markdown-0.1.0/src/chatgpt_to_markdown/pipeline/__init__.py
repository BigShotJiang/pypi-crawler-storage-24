"""
Pipeline for processing ChatGPT data exports.

This module defines the pipeline components used to process ChatGPT data exports, including conversion to Markdown format and other transformations. The pipeline is designed to be modular and extensible, allowing for easy integration of additional processing steps or output formats in the future.
"""
