from __future__ import annotations

import json
import logging
import re
from typing import TYPE_CHECKING, Any, cast

from pydantic import ValidationError

from chatgpt_to_markdown.models.conversation import Conversation

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)

CONVERSATIONS_GLOB = "conversations-*.json"
_PARTITION_RE = re.compile(r"conversations-(\d+)\.json$")
_UNKNOWN_TITLE = "unknown"


def _sort_key(path: Path) -> int:
    """Extract partition number for sorting."""
    match = _PARTITION_RE.search(path.name)
    return int(match.group(1)) if match else 0


def _extract_title(entry: object) -> str:
    """Extract a conversation title from a raw JSON entry for logging."""
    if isinstance(entry, dict):
        return cast("dict[str, Any]", entry).get("title", _UNKNOWN_TITLE)
    return _UNKNOWN_TITLE


def _validate_entry(entry: object, index: int, filename: str) -> Conversation | None:
    """Validate a single raw JSON entry into a Conversation, or return None."""
    if not entry:
        logger.warning("Skipping empty entry %d in %s", index, filename)
        return None

    title = _extract_title(entry)
    try:
        conv = Conversation.model_validate(entry)
    except ValidationError as exc:
        details = "; ".join(f"{err['loc'][0]}={err['type']}" for err in exc.errors())
        logger.warning("Data inconsistency in conversation %d (%s) in %s: %s", index, title, filename, details)
        return None
    except (ValueError, KeyError) as exc:
        logger.warning("Skipping conversation %d in %s (%s): %s", index, filename, title, exc)
        return None

    if isinstance(entry, dict) and not cast("dict[str, Any]", entry).get("id"):
        logger.debug("Generated UUID for conversation %d (%s) in %s: missing id field", index, title, filename)
    return conv


def _parse_file(path: Path) -> list[Conversation]:
    """Parse and validate conversations from a single JSON file."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("Skipping %s: %s", path.name, exc)
        return []

    if not isinstance(raw, list):
        logger.warning("Skipping %s: expected a JSON array", path.name)
        return []

    conversations: list[Conversation] = []
    for i, entry in enumerate(raw):
        conv = _validate_entry(entry, i, path.name)
        if conv is not None:
            conversations.append(conv)
    return conversations


def parse_conversations(input_dir: Path) -> list[Conversation]:
    """Parse all conversations-*.json files and return validated Conversation objects."""
    files = sorted(input_dir.glob(CONVERSATIONS_GLOB), key=_sort_key)
    if not files:
        logger.warning("No conversations-*.json files found in %s", input_dir)
        return []

    conversations: list[Conversation] = []
    for path in files:
        logger.info("Parsing %s", path.name)
        conversations.extend(_parse_file(path))

    logger.info("Parsed %d conversations total", len(conversations))
    return conversations
