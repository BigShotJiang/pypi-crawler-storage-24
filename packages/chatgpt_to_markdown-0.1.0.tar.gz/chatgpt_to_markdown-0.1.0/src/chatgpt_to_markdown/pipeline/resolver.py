from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

from chatgpt_to_markdown.models.conversation import AssetPointer, Conversation, MultimodalTextContent

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)

_SERVICE_PREFIX_RE = re.compile(r"^(?:file-service://|sediment://)")


@dataclass(frozen=True)
class ResolvedAsset:
    file_id: str
    pointer: str
    path: Path | None


def strip_pointer_prefix(pointer: str) -> str:
    """Strip file-service:// or sediment:// prefix from an asset pointer."""
    return _SERVICE_PREFIX_RE.sub("", pointer)


def resolve_asset_pointer(pointer: str, file_index: dict[str, Path]) -> ResolvedAsset:
    """Resolve a single asset pointer against the file index."""
    file_id = strip_pointer_prefix(pointer)
    path = file_index.get(file_id)
    if path is None:
        logger.warning("Unresolved asset pointer: %s", pointer)
    return ResolvedAsset(file_id=file_id, pointer=pointer, path=path)


def resolve_conversation_assets(conversation: Conversation, file_index: dict[str, Path]) -> list[ResolvedAsset]:
    """Resolve all asset pointers in a conversation."""
    assets: list[ResolvedAsset] = []
    for node in conversation.mapping.values():
        if node.message is None:
            continue
        content = node.message.content
        if isinstance(content, MultimodalTextContent):
            for part in content.parts:
                if isinstance(part, dict) and "asset_pointer" in part:
                    ap = AssetPointer.model_validate(part)
                    assets.append(resolve_asset_pointer(ap.asset_pointer, file_index))
    return assets
