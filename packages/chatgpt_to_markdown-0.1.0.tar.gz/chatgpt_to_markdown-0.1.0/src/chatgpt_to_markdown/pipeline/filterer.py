from __future__ import annotations

from math import isclose

from chatgpt_to_markdown.constants import AuthorRole
from chatgpt_to_markdown.models.conversation import (
    Content,
    Message,
    MultimodalTextContent,
    TextContent,
    ThoughtsContent,
    UserEditableContextContent,
)


def filter_messages(messages: list[Message], *, include_thinking: bool = False) -> list[Message]:
    """Apply visibility filtering rules to a list of messages."""
    return [msg for msg in messages if _should_include(msg, include_thinking=include_thinking)]


def _should_include(msg: Message, *, include_thinking: bool) -> bool:
    """Return True if a message should be included in the output."""
    if isclose(msg.weight, 0.0):
        return False
    if msg.author.role == AuthorRole.SYSTEM and _is_empty_content(msg.content):
        return False
    if msg.metadata.get("is_visually_hidden_from_conversation"):
        return False
    if isinstance(msg.content, UserEditableContextContent):
        return False
    if isinstance(msg.content, ThoughtsContent) and not include_thinking:
        return False
    return not (msg.channel == "commentary" and not include_thinking)


def _is_empty_content(content: Content) -> bool:
    """Check if content is empty."""
    if isinstance(content, TextContent | MultimodalTextContent):
        return not content.parts or all(not p for p in content.parts)
    if hasattr(content, "text"):
        text_val: str = getattr(content, "text", "")
        return not text_val
    return False
