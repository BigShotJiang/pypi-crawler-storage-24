from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from chatgpt_to_markdown.constants import UNKNOWN, UNTITLED
from chatgpt_to_markdown.models.conversation import (
    CodeContent,
    ComputerOutputContent,
    Conversation,
    ExecutionOutputContent,
    Message,
    MultimodalTextContent,
    ReasoningRecapContent,
    SonicWebpageContent,
    SystemErrorContent,
    TetherBrowsingDisplayContent,
    TetherQuoteContent,
    TextContent,
    ThoughtsContent,
)
from chatgpt_to_markdown.pipeline._jinja import format_date, get_jinja_env
from chatgpt_to_markdown.pipeline.filterer import filter_messages
from chatgpt_to_markdown.pipeline.linearizer import linearize
from chatgpt_to_markdown.pipeline.resolver import strip_pointer_prefix

if TYPE_CHECKING:
    from chatgpt_to_markdown.types import AssetMap

logger = logging.getLogger(__name__)


@dataclass
class RenderedMessage:
    role: str
    content: str
    model: str | None = None
    tool_name: str | None = None
    thinking: str | None = None


def _render_content(msg: Message, asset_map: AssetMap) -> str:
    """Render message content to Markdown based on content_type."""
    match msg.content:
        case TextContent(parts=parts):
            return _render_parts(parts, asset_map)
        case MultimodalTextContent(parts=parts):
            return _render_parts(parts, asset_map, skip_empty=True)
        case CodeContent(language=lang, text=text):
            return f"```{lang or ''}\n{text}\n```"
        case ExecutionOutputContent(text=text):
            return f"```\n{text}\n```"
        case ThoughtsContent(thoughts=thoughts):
            return "\n\n".join(t.content for t in thoughts)
        case ReasoningRecapContent(content=c):
            return f"*{c}*"
        case SonicWebpageContent() as sw:
            title = sw.title or sw.domain or "Web Result"
            return f"> **[{title}]({sw.url or ''})**\n>\n> {sw.snippet or sw.text or ''}"
        case TetherQuoteContent() as tq:
            return f"> **{tq.title or tq.domain or 'File'}**\n>\n> {tq.text or ''}"
        case TetherBrowsingDisplayContent():
            return ""
        case ComputerOutputContent() as co:
            return _render_computer_output(co, asset_map)
        case SystemErrorContent(name=name, text=text):
            return f"**Error ({name}):** {text}"
        case _:
            return f"<!-- Unsupported content_type: {msg.content.content_type} -->"


def _render_computer_output(co: ComputerOutputContent, asset_map: AssetMap) -> str:
    """Render computer output content, including optional screenshot."""
    screenshot = co.screenshot
    if screenshot and "asset_pointer" in screenshot:
        pointer = screenshot["asset_pointer"]
        rel = asset_map.get(strip_pointer_prefix(pointer), "")
        return f"![Screenshot]({rel})" if rel else "<!-- MISSING ASSET: screenshot -->"
    return "*Computer output*"


def _render_parts(parts: list[Any], asset_map: AssetMap, *, skip_empty: bool = False) -> str:
    """Render text/multimodal parts to Markdown, unified for both content types."""
    rendered = []
    for part in parts:
        if isinstance(part, str):
            if skip_empty and not part.strip():
                continue
            rendered.append(part)
        elif isinstance(part, dict) and "asset_pointer" in part:
            rendered.append(_render_asset_pointer(part, asset_map))
    return "\n\n".join(rendered)


def _render_asset_pointer(part: dict[str, Any], asset_map: AssetMap) -> str:
    pointer = part.get("asset_pointer", "")
    file_id = strip_pointer_prefix(pointer)
    rel_path = asset_map.get(file_id)
    if rel_path:
        return f"![image]({rel_path})"
    return f"<!-- MISSING ASSET: {pointer} -->"


def render_conversation(
    conversation: Conversation,
    *,
    include_thinking: bool = False,
    asset_map: AssetMap | None = None,
) -> str:
    """Render a full conversation to Markdown."""
    env = get_jinja_env()
    template = env.get_template("conversation.md.j2")

    asset_map = asset_map or {}
    raw_messages = linearize(conversation)
    messages = filter_messages(raw_messages, include_thinking=include_thinking)

    rendered_messages: list[RenderedMessage] = []
    for msg in messages:
        model = msg.metadata.get("model_slug")
        tool_name = msg.metadata.get("command")

        if msg.channel == "commentary" and include_thinking:
            rendered = RenderedMessage(
                role=msg.author.role,
                content="",
                model=model,
                tool_name=tool_name,
                thinking=_render_content(msg, asset_map),
            )
        else:
            rendered = RenderedMessage(
                role=msg.author.role,
                content=_render_content(msg, asset_map),
                model=model,
                tool_name=tool_name,
            )
        rendered_messages.append(rendered)

    title = conversation.title or UNTITLED
    model = conversation.default_model_slug or UNKNOWN

    return template.render(
        conversation=conversation,
        title=title,
        created=format_date(conversation.create_time, fmt="%Y-%m-%dT%H:%M:%SZ"),
        updated=format_date(conversation.update_time, fmt="%Y-%m-%dT%H:%M:%SZ"),
        model=model,
        messages=rendered_messages,
    )
