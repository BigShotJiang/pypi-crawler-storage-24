from __future__ import annotations

import hashlib
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from chatgpt_to_markdown.naming import extract_file_id

if TYPE_CHECKING:
    from chatgpt_to_markdown.models.manifest import ExportManifest

logger = logging.getLogger(__name__)


def build_file_index(manifest: ExportManifest, input_dir: Path) -> dict[str, Path]:
    """Build a {file_id → absolute Path} index from the export manifest."""
    index: dict[str, Path] = {}
    for entry in manifest.export_files:
        filename = Path(entry.path).name
        file_id = extract_file_id(filename)
        if file_id:
            abs_path = input_dir / entry.path
            index[file_id] = abs_path
    logger.info("Built file index with %d entries", len(index))
    return index


def hash_file(path: Path, *, chunk_size: int = 8192) -> str:
    """Compute SHA-256 hex digest of a file."""
    sha256 = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(chunk_size):
            sha256.update(chunk)
    return sha256.hexdigest()


def build_dedup_index(file_index: dict[str, Path]) -> dict[str, list[str]]:
    """Build a {sha256_hash → [file_ids]} index for deduplication."""
    dedup: dict[str, list[str]] = {}
    for file_id, path in file_index.items():
        if path.exists():
            digest = hash_file(path)
            dedup.setdefault(digest, []).append(file_id)
    return dedup
