from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import TYPE_CHECKING

from chatgpt_to_markdown.naming import conversation_dirname, media_filename, sanitize_filename
from chatgpt_to_markdown.pipeline.indexer import hash_file
from chatgpt_to_markdown.types import DalleImage

if TYPE_CHECKING:
    from chatgpt_to_markdown.pipeline.resolver import ResolvedAsset

logger = logging.getLogger(__name__)


def organize_conversation(
    conversation_id: str,
    title: str | None,
    create_time: float | None,
    resolved_assets: list[ResolvedAsset],
    output_dir: Path,
    *,
    deduplicate: bool = True,
) -> tuple[Path, dict[str, str]]:
    """Create conversation directory, copy media/attachments, return asset mapping.

    Returns:
        Tuple of (conversation_dir, {file_id → relative_path_from_conv_dir}).
    """
    dirname = conversation_dirname(title, create_time, conversation_id)
    conv_dir = output_dir / "conversations" / dirname
    media_dir = conv_dir / "media"
    media_dir.mkdir(parents=True, exist_ok=True)

    asset_map: dict[str, str] = {}
    seen_hashes: dict[str, str] = {}
    ordinal = 1

    for asset in resolved_assets:
        if asset.path is None or not asset.path.exists():
            logger.warning("Missing asset file for %s", asset.file_id)
            continue

        ext = asset.path.suffix or ".bin"
        file_hash = hash_file(asset.path)

        if deduplicate and file_hash in seen_hashes:
            asset_map[asset.file_id] = seen_hashes[file_hash]
            continue

        dest_name = media_filename(ordinal, file_hash, ext)
        dest = media_dir / dest_name
        shutil.copy2(asset.path, dest)

        rel = f"media/{dest_name}"
        asset_map[asset.file_id] = rel
        seen_hashes[file_hash] = rel
        ordinal += 1

    return conv_dir, asset_map


def organize_attachments(
    conv_dir: Path,
    attachments: list[dict[str, str | Path]],
) -> dict[str, str]:
    """Copy attachment files into the conversation's attachments/ directory."""
    attach_dir = conv_dir / "attachments"
    attach_dir.mkdir(parents=True, exist_ok=True)

    mapping: dict[str, str] = {}
    for att in attachments:
        src = Path(str(att["source"]))
        name = sanitize_filename(str(att.get("name", src.name)))
        dest = attach_dir / name
        if src.exists():
            shutil.copy2(src, dest)
            mapping[str(att.get("id", ""))] = f"attachments/{name}"
    return mapping


def organize_dalle(input_dir: Path, output_dir: Path) -> list[DalleImage]:
    """Copy DALL-E generations to output dalle/ directory."""
    dalle_src = input_dir / "dalle-generations"
    if not dalle_src.exists():
        return []

    dalle_dst = output_dir / "dalle"
    dalle_dst.mkdir(parents=True, exist_ok=True)

    images: list[DalleImage] = []
    for src_file in sorted(dalle_src.iterdir()):
        if src_file.is_file():
            dest = dalle_dst / sanitize_filename(src_file.name)
            shutil.copy2(src_file, dest)
            images.append(DalleImage(name=src_file.stem, path=dest.name))

    return images
