from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from chatgpt_to_markdown.constants import REDACTED_PLACEHOLDER
from chatgpt_to_markdown.models.manifest import ExportManifest
from chatgpt_to_markdown.models.metadata import MessageFeedback, User, UserSettings

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)


def load_manifest(input_dir: Path) -> ExportManifest:
    """Load and validate export_manifest.json."""
    manifest_path = input_dir / "export_manifest.json"
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    return ExportManifest.model_validate(data)


def load_user(input_dir: Path, *, redact_pii: bool = True) -> User | None:
    """Load user.json with optional PII redaction."""
    user_path = input_dir / "user.json"
    if not user_path.exists():
        logger.warning("user.json not found")
        return None
    data = json.loads(user_path.read_text(encoding="utf-8"))
    user = User.model_validate(data)
    if redact_pii:
        user.email = REDACTED_PLACEHOLDER
        user.phone_number = REDACTED_PLACEHOLDER
        user.birth_year = None
    return user


def load_user_settings(input_dir: Path) -> list[UserSettings]:
    """Load user_settings.json."""
    settings_path = input_dir / "user_settings.json"
    if not settings_path.exists():
        logger.warning("user_settings.json not found")
        return []
    data = json.loads(settings_path.read_text(encoding="utf-8"))
    if isinstance(data, list):
        return [UserSettings.model_validate(item) for item in data]
    return [UserSettings.model_validate(data)]


def load_feedback(input_dir: Path) -> list[MessageFeedback]:
    """Load message_feedback.json."""
    feedback_path = input_dir / "message_feedback.json"
    if not feedback_path.exists():
        logger.warning("message_feedback.json not found")
        return []
    data = json.loads(feedback_path.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        return []
    feedbacks: list[MessageFeedback] = []
    for item in data:
        try:
            feedbacks.append(MessageFeedback.model_validate(item))
        except ValueError, KeyError:
            logger.warning("Skipping malformed feedback entry: %s", item.get("id", "unknown"))
    return feedbacks
