from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from chatgpt_to_markdown.constants import DATE_FORMAT, UNKNOWN, UNTITLED
from chatgpt_to_markdown.pipeline._jinja import format_date, get_jinja_env

if TYPE_CHECKING:
    from pathlib import Path

    from chatgpt_to_markdown.models.conversation import Conversation
    from chatgpt_to_markdown.models.metadata import MessageFeedback, User, UserSettings
    from chatgpt_to_markdown.types import DalleImage

logger = logging.getLogger(__name__)


def generate_root_index(
    output_dir: Path,
    *,
    conversation_count: int,
    total_files: int,
    has_dalle: bool = False,
    has_metadata: bool = True,
) -> None:
    """Generate root index.md."""
    env = get_jinja_env()
    template = env.get_template("root_index.md.j2")
    content = template.render(
        conversation_count=conversation_count,
        total_files=total_files,
        has_dalle=has_dalle,
        has_metadata=has_metadata,
        export_date=datetime.now(tz=UTC).strftime(DATE_FORMAT),
    )
    (output_dir / "index.md").write_text(content, encoding="utf-8")
    logger.info("Generated root index.md")


def generate_conversations_index(
    output_dir: Path,
    conversations: list[Conversation],
    conv_dirs: dict[str, str],
) -> None:
    """Generate conversations/index.md with a table of all conversations."""
    env = get_jinja_env()
    template = env.get_template("conversation_index.md.j2")

    entries = []
    for conv in sorted(conversations, key=lambda c: c.create_time or 0, reverse=True):
        date = format_date(conv.create_time)
        dirname = conv_dirs.get(conv.id, "")
        entries.append(
            {
                "date": date,
                "title": conv.title or UNTITLED,
                "model": conv.default_model_slug or UNKNOWN,
                "link": f"{dirname}/index.md" if dirname else "#",
            }
        )

    content = template.render(conversations=entries)
    conv_index = output_dir / "conversations" / "index.md"
    conv_index.parent.mkdir(parents=True, exist_ok=True)
    conv_index.write_text(content, encoding="utf-8")
    logger.info("Generated conversations index.md")


def generate_dalle_index(output_dir: Path, images: list[DalleImage]) -> None:
    """Generate dalle/index.md."""
    env = get_jinja_env()
    template = env.get_template("dalle_index.md.j2")
    content = template.render(images=images)
    dalle_index = output_dir / "dalle" / "index.md"
    dalle_index.parent.mkdir(parents=True, exist_ok=True)
    dalle_index.write_text(content, encoding="utf-8")
    logger.info("Generated DALL-E index.md")


def generate_metadata_files(
    output_dir: Path,
    *,
    user: User | None,
    settings: list[UserSettings],
    feedbacks: list[MessageFeedback],
    conversation_count: int,
    manifest_file_count: int,
    earliest_date: str = "unknown",
    latest_date: str = "unknown",
) -> None:
    """Generate metadata Markdown files."""
    env = get_jinja_env()
    meta_dir = output_dir / "metadata"
    meta_dir.mkdir(parents=True, exist_ok=True)

    if user:
        template = env.get_template("metadata/user_profile.md.j2")
        (meta_dir / "user_profile.md").write_text(template.render(user=user), encoding="utf-8")

    if settings:
        template = env.get_template("metadata/settings.md.j2")
        (meta_dir / "settings.md").write_text(template.render(settings=settings), encoding="utf-8")

    if feedbacks:
        template = env.get_template("metadata/feedback.md.j2")
        (meta_dir / "feedback.md").write_text(template.render(feedbacks=feedbacks), encoding="utf-8")

    template = env.get_template("metadata/export_stats.md.j2")
    (meta_dir / "export_stats.md").write_text(
        template.render(
            conversation_count=conversation_count,
            manifest_file_count=manifest_file_count,
            feedback_count=len(feedbacks),
            earliest_date=earliest_date,
            latest_date=latest_date,
        ),
        encoding="utf-8",
    )
    logger.info("Generated metadata files")
