from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from chatgpt_to_markdown.models.metadata import MessageFeedback


def build_feedback_index(feedbacks: list[MessageFeedback]) -> dict[str, list[MessageFeedback]]:
    """Build a {conversation_id → [MessageFeedback]} lookup from feedback records."""
    index: dict[str, list[MessageFeedback]] = {}
    for fb in feedbacks:
        index.setdefault(fb.conversation_id, []).append(fb)
    return index
