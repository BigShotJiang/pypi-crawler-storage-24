from __future__ import annotations

from datetime import UTC, datetime
from functools import cache

from jinja2 import Environment, PackageLoader, select_autoescape

from chatgpt_to_markdown.constants import DATE_FORMAT, DATETIME_FORMAT, ROLE_DISPLAY, UNKNOWN


def _format_timestamp(ts: float | None) -> str:
    if ts is None:
        return UNKNOWN
    return datetime.fromtimestamp(ts, tz=UTC).strftime(DATETIME_FORMAT)


def _role_display(role: str) -> str:
    return ROLE_DISPLAY.get(role, role.title())


@cache
def get_jinja_env() -> Environment:
    """Return a cached Jinja2 environment with shared filters."""
    env = Environment(
        loader=PackageLoader("chatgpt_to_markdown", "templates"),
        autoescape=select_autoescape([]),
        keep_trailing_newline=True,
        trim_blocks=True,
        lstrip_blocks=True,
    )
    env.filters["format_timestamp"] = _format_timestamp
    env.filters["role_display"] = _role_display
    return env


def format_date(ts: float | None, fmt: str = DATE_FORMAT) -> str:
    """Format a UNIX timestamp as a date string, or return 'unknown'."""
    if ts is None:
        return UNKNOWN
    return datetime.fromtimestamp(ts, tz=UTC).strftime(fmt)
