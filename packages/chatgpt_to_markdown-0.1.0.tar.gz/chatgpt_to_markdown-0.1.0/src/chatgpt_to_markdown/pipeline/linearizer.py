from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from chatgpt_to_markdown.models.conversation import Conversation, Message

logger = logging.getLogger(__name__)


def linearize(conversation: Conversation) -> list[Message]:
    """Walk from current_node to root and return messages in chronological order.

    Falls back to DFS from root if current_node is missing.
    Detects cycles via a visited set.
    """
    mapping = conversation.mapping

    if conversation.current_node and conversation.current_node in mapping:
        return _walk_to_root(mapping, conversation.current_node)

    # Fallback: find root and do DFS
    logger.warning(
        "current_node '%s' not in mapping for conversation %s; using DFS fallback",
        conversation.current_node,
        conversation.id,
    )
    return _dfs_from_root(mapping)


def _walk_to_root(mapping: dict[str, Any], start_id: str) -> list[Message]:
    """Walk from a node to root, collecting messages, then reverse."""
    from chatgpt_to_markdown.models.conversation import Node

    path: list[Message] = []
    visited: set[str] = set()
    node_id: str | None = start_id

    while node_id is not None:
        if node_id in visited:
            logger.warning("Cycle detected at node %s; breaking", node_id)
            break
        visited.add(node_id)

        node_data = mapping.get(node_id)
        if not isinstance(node_data, Node):
            break
        if node_data.message is not None:
            path.append(node_data.message)
        node_id = node_data.parent

    path.reverse()
    return path


def _dfs_from_root(mapping: dict[str, Any]) -> list[Message]:
    """Fallback DFS from the root node (parent is None)."""
    from chatgpt_to_markdown.models.conversation import Node

    root_id: str | None = None
    for nid, node_data in mapping.items():
        if isinstance(node_data, Node) and node_data.parent is None:
            root_id = nid
            break

    if root_id is None:
        logger.warning("No root node found")
        return []

    messages: list[Message] = []
    visited: set[str] = set()
    stack = [root_id]

    while stack:
        nid = stack.pop()
        if nid in visited:
            continue
        visited.add(nid)
        node_data = mapping.get(nid)
        if not isinstance(node_data, Node):
            continue
        if node_data.message is not None:
            messages.append(node_data.message)
        stack.extend(child_id for child_id in node_data.children if child_id not in visited)

    return messages
