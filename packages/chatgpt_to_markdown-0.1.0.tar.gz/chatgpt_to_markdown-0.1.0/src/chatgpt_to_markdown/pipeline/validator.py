from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)

_LINK_RE = re.compile(r"\[([^\]]*)\]\(([^)]+)\)")
_MISSING_ASSET_RE = re.compile(r"<!-- MISSING ASSET: (.+?) -->")


@dataclass
class ValidationReport:
    total_files: int = 0
    broken_links: list[str] = field(default_factory=list)
    missing_assets: list[str] = field(default_factory=list)
    orphan_files: list[str] = field(default_factory=list)


def validate_output(output_dir: Path) -> ValidationReport:
    """Validate the output archive for broken links and missing assets."""
    report = ValidationReport()

    if not output_dir.exists():
        logger.warning("Output directory does not exist: %s", output_dir)
        return report

    md_files = list(output_dir.rglob("*.md"))
    report.total_files = len(md_files)

    for md_file in md_files:
        content = md_file.read_text(encoding="utf-8")
        _check_links(md_file, content, report)
        _check_missing_assets(content, report)

    if report.broken_links:
        logger.warning("Found %d broken links", len(report.broken_links))
    if report.missing_assets:
        logger.warning("Found %d missing asset references", len(report.missing_assets))

    return report


def _check_links(md_file: Path, content: str, report: ValidationReport) -> None:
    """Check relative links in Markdown files."""
    for match in _LINK_RE.finditer(content):
        target = match.group(2)
        if target.startswith(("http://", "https://", "#", "mailto:")):
            continue
        resolved = md_file.parent / target
        if not resolved.exists():
            report.broken_links.append(f"{md_file.name}: {target}")


def _check_missing_assets(content: str, report: ValidationReport) -> None:
    """Check for MISSING ASSET comments in Markdown."""
    for match in _MISSING_ASSET_RE.finditer(content):
        report.missing_assets.append(match.group(1))
