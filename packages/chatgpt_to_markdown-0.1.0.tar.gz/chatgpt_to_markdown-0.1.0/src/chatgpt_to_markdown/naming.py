from __future__ import annotations

import re
from datetime import UTC, datetime

from slugify import slugify

from chatgpt_to_markdown.constants import DATE_FORMAT, UNKNOWN_DATE

_WINDOWS_RESERVED = frozenset(
    {
        "CON",
        "PRN",
        "AUX",
        "NUL",
        *(f"COM{i}" for i in range(1, 10)),
        *(f"LPT{i}" for i in range(1, 10)),
    }
)

_UNSAFE_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_MULTI_HYPHEN = re.compile(r"-{2,}")
_FILE_ID_MODERN = re.compile(r"^(file-[A-Za-z0-9]+)")
_FILE_ID_LEGACY = re.compile(r"^(file_[0-9a-fA-F]+)")


def create_url_slug(text: str, max_length: int = 60) -> str:
    """Convert text to a URL-safe slug using python-slugify."""
    result = slugify(text, max_length=max_length)
    return result or "untitled"


def sanitize_filename(name: str, max_length: int = 200) -> str:
    """Make a filename safe for all platforms."""
    name = _UNSAFE_CHARS.sub("-", name)
    name = name.strip(". ")
    name = _MULTI_HYPHEN.sub("-", name)
    stem = name.upper().split(".")[0]
    if stem in _WINDOWS_RESERVED:
        name = f"_{name}"
    if len(name) > max_length:
        name = name[:max_length]
    return name or "unnamed"


def conversation_dirname(title: str | None, create_time: float | None, conversation_id: str) -> str:
    """Build a conversation directory name: YYYY-MM-DD_slug_shortid."""
    if create_time is not None:
        date_str = datetime.fromtimestamp(create_time, tz=UTC).strftime(DATE_FORMAT)
    else:
        date_str = UNKNOWN_DATE
    slug = create_url_slug(title or "untitled")
    short_id = conversation_id[:8]
    return f"{date_str}_{slug}_{short_id}"


def media_filename(ordinal: int, file_hash: str, extension: str) -> str:
    """Build a media filename: NNN-shorthash.ext."""
    short_hash = file_hash[:8]
    ext = extension.lower().lstrip(".")
    return f"{ordinal:03d}-{short_hash}.{ext}"


def extract_file_id(filename: str) -> str | None:
    """Extract the file ID from a modern or legacy export filename."""
    match = _FILE_ID_MODERN.match(filename)
    if match:
        return match.group(1)
    match = _FILE_ID_LEGACY.match(filename)
    if match:
        return match.group(1)
    return None
