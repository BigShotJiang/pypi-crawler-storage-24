from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class User(BaseModel):
    id: str
    email: str | None = None
    phone_number: str | None = None
    birth_year: int | None = None
    chatgpt_plus_user: bool = False


class UserSettings(BaseModel, extra="allow"):
    user_id: str | None = None
    habitat_object_version: int | None = None
    announcements: dict[str, Any] | None = None
    beta_settings: dict[str, Any] | None = None
    settings: dict[str, Any] | None = None


class MessageFeedback(BaseModel):
    id: str
    conversation_id: str
    user_id: str | None = None
    rating: str
    content: str | None = None
    create_time: str | None = None
    update_time: str | None = None
    evaluation_name: str | None = None
    evaluation_treatment: str | None = None
    workspace_id: str | None = None
