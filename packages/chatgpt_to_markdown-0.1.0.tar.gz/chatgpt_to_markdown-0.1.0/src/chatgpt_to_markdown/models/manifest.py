from __future__ import annotations

from pydantic import BaseModel


class ExportManifestFile(BaseModel):
    path: str
    size_bytes: int


class ExportManifest(BaseModel):
    export_files: list[ExportManifestFile]
