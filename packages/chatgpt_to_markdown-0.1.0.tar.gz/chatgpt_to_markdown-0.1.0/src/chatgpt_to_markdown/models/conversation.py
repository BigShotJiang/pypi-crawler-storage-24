from __future__ import annotations

import uuid
from typing import Annotated, Any, Literal

from pydantic import BaseModel, BeforeValidator, Discriminator, Field, Tag

from chatgpt_to_markdown.constants import KNOWN_CONTENT_TYPES


def _coerce_str(v: object) -> str | None:
    """Coerce a value to a string, or None if the value is None."""
    if v is None:
        return None
    return str(v)


_CoercedStr = Annotated[str | None, BeforeValidator(_coerce_str)]


def _coerce_to_default_str(v: object) -> str:
    """Coerce a value to a string, defaulting None to empty string."""
    if v is None:
        return ""
    return str(v)


_DefaultStr = Annotated[str, BeforeValidator(_coerce_to_default_str)]


def _generate_id() -> str:
    """Generate a UUID for conversations missing an id."""
    return str(uuid.uuid4())


class Author(BaseModel):
    role: str
    name: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class AssetPointer(BaseModel):
    asset_pointer: str
    content_type: str = "image_asset_pointer"
    height: int | None = None
    width: int | None = None
    size_bytes: int | None = None
    fovea: int | None = None
    metadata: dict[str, Any] | None = None


# --- Content types ---


class TextContent(BaseModel):
    content_type: Literal["text"]
    parts: list[Any] = Field(default_factory=list)


class MultimodalTextContent(BaseModel):
    content_type: Literal["multimodal_text"]
    parts: list[Any] = Field(default_factory=list)


class CodeContent(BaseModel):
    content_type: Literal["code"]
    language: str | None = None
    response_format_name: str | None = None
    text: str = ""


class ThoughtChunk(BaseModel):
    chunks: list[str] = Field(default_factory=list)
    content: str = ""
    finished: bool = False
    summary: _DefaultStr = ""


class ThoughtsContent(BaseModel):
    content_type: Literal["thoughts"]
    source_analysis_msg_id: str | None = None
    thoughts: list[ThoughtChunk] = Field(default_factory=list)


class ReasoningRecapContent(BaseModel):
    content_type: Literal["reasoning_recap"]
    content: str = ""


class SonicWebpageContent(BaseModel):
    content_type: Literal["sonic_webpage"]
    domain: str | None = None
    url: str | None = None
    title: str | None = None
    snippet: str | None = None
    text: str | None = None
    ref_id: str | None = None
    pub_timestamp: float | None = None
    pub_date: str | None = None
    crawl_date: str | None = None
    crawl_timestamp: float | None = None


class TetherQuoteContent(BaseModel):
    content_type: Literal["tether_quote"]
    domain: str | None = None
    url: str | None = None
    title: str | None = None
    text: str | None = None
    tether_id: _CoercedStr = None


class TetherBrowsingDisplayContent(BaseModel):
    content_type: Literal["tether_browsing_display"]
    assets: Any = None
    result: _DefaultStr = ""
    summary: _DefaultStr = ""
    tether_id: _CoercedStr = None


class UserEditableContextContent(BaseModel):
    content_type: Literal["user_editable_context"]
    user_profile: str = ""
    user_instructions: str = ""


class ExecutionOutputContent(BaseModel):
    content_type: Literal["execution_output"]
    text: str = ""


class ComputerOutputContent(BaseModel, extra="allow"):
    content_type: Literal["computer_output"]
    computer_id: str | None = None
    is_ephemeral: bool | None = None
    screenshot: dict[str, Any] | None = None
    state: dict[str, Any] | None = None
    tether_id: int | None = None


class SystemErrorContent(BaseModel):
    content_type: Literal["system_error"]
    name: str = ""
    text: str = ""


class FallbackContent(BaseModel, extra="allow"):
    content_type: str


def _content_discriminator(v: dict[str, Any] | BaseModel) -> str:
    ct = v.get("content_type", "") if isinstance(v, dict) else getattr(v, "content_type", "")
    if ct in KNOWN_CONTENT_TYPES:
        return ct
    return "fallback"


Content = Annotated[
    Annotated[TextContent, Tag("text")]
    | Annotated[MultimodalTextContent, Tag("multimodal_text")]
    | Annotated[CodeContent, Tag("code")]
    | Annotated[ThoughtsContent, Tag("thoughts")]
    | Annotated[ReasoningRecapContent, Tag("reasoning_recap")]
    | Annotated[SonicWebpageContent, Tag("sonic_webpage")]
    | Annotated[TetherQuoteContent, Tag("tether_quote")]
    | Annotated[TetherBrowsingDisplayContent, Tag("tether_browsing_display")]
    | Annotated[UserEditableContextContent, Tag("user_editable_context")]
    | Annotated[ExecutionOutputContent, Tag("execution_output")]
    | Annotated[ComputerOutputContent, Tag("computer_output")]
    | Annotated[SystemErrorContent, Tag("system_error")]
    | Annotated[FallbackContent, Tag("fallback")],
    Discriminator(_content_discriminator),
]


class Attachment(BaseModel, extra="allow"):
    id: str | None = None
    name: str | None = None
    size: int | None = None
    height: int | None = None
    width: int | None = None


class Message(BaseModel, extra="allow"):
    id: str
    author: Author
    content: Content
    channel: str | None = None
    recipient: str = "all"
    create_time: float | None = None
    update_time: float | None = None
    end_turn: bool | None = None
    status: str | None = None
    weight: float = 1.0
    metadata: dict[str, Any] = Field(default_factory=dict)


class Node(BaseModel):
    id: str
    parent: str | None = None
    children: list[str] = Field(default_factory=list)
    message: Message | None = None


class Conversation(BaseModel, extra="allow"):
    id: str = Field(default_factory=_generate_id)
    conversation_id: str | None = None
    title: str | None = None
    create_time: float | None = None
    update_time: float | None = None
    current_node: str | None = None
    default_model_slug: str | None = None
    mapping: dict[str, Node] = Field(default_factory=dict)
    is_archived: bool = False
