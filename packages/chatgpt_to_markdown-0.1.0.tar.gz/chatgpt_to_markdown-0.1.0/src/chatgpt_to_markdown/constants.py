from __future__ import annotations

from enum import StrEnum


class AuthorRole(StrEnum):
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"
    SYSTEM = "system"


class ContentType(StrEnum):
    TEXT = "text"
    MULTIMODAL_TEXT = "multimodal_text"
    CODE = "code"
    THOUGHTS = "thoughts"
    REASONING_RECAP = "reasoning_recap"
    SONIC_WEBPAGE = "sonic_webpage"
    TETHER_QUOTE = "tether_quote"
    TETHER_BROWSING_DISPLAY = "tether_browsing_display"
    USER_EDITABLE_CONTEXT = "user_editable_context"
    EXECUTION_OUTPUT = "execution_output"
    COMPUTER_OUTPUT = "computer_output"
    SYSTEM_ERROR = "system_error"


KNOWN_CONTENT_TYPES: frozenset[str] = frozenset(ContentType)

# Date format constants
DATE_FORMAT = "%Y-%m-%d"
DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"

# Fallback / sentinel values
REDACTED_PLACEHOLDER = "[REDACTED]"
UNKNOWN = "unknown"
UNTITLED = "Untitled"
UNKNOWN_DATE = "unknown-date"

# Role display mapping
ROLE_DISPLAY: dict[str, str] = {
    AuthorRole.USER: "User",
    AuthorRole.ASSISTANT: "Assistant",
    AuthorRole.TOOL: "Tool",
    AuthorRole.SYSTEM: "System",
}
