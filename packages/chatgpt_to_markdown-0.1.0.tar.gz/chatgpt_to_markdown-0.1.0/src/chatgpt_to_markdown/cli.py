from __future__ import annotations

import logging
from pathlib import Path  # noqa: TC003 — cyclopts needs Path at runtime for type resolution
from typing import Annotated

from cyclopts import App, Parameter

from chatgpt_to_markdown.config import ConverterConfig

app = App(help="Convert ChatGPT data export to offline Markdown archive.")
logger = logging.getLogger(__name__)


@app.default
def main(
    input_dir: Annotated[Path, Parameter(help="Path to extracted ChatGPT export directory or ZIP file")],
    output_dir: Annotated[Path, Parameter(help="Path to output Markdown archive directory")],
    *,
    redact_pii: Annotated[bool, Parameter(help="Redact PII (email, phone, birth year)")] = True,
    include_thinking: Annotated[bool, Parameter(help="Include thinking/reasoning blocks")] = False,
    deduplicate: Annotated[bool, Parameter(help="Deduplicate assets by SHA-256 hash")] = True,
    verbose: Annotated[bool, Parameter(help="Display additional information regarding warnings")] = False,
) -> None:
    """Run the ChatGPT export to Markdown conversion."""
    log_level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(level=log_level, format="%(levelname)s: %(message)s")

    config = ConverterConfig(
        input_dir=input_dir,
        output_dir=output_dir,
        redact_pii=redact_pii,
        include_thinking=include_thinking,
        deduplicate_by_hash=deduplicate,
        verbose=verbose,
    )

    from chatgpt_to_markdown.converter import ChatGPTExportConverter

    converter = ChatGPTExportConverter(config)
    converter.run()
