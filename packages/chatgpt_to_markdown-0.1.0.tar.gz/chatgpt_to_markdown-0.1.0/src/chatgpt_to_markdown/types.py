"""Type aliases and shared data structures for the converter pipeline."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

# Mapping of {file_id → relative_path} for resolved assets.
type AssetMap = dict[str, str]

# Mapping of {file_id → absolute_path} from the export manifest.
type FileIndex = dict[str, Path]


@dataclass(frozen=True)
class DalleImage:
    """A single DALL-E generation image."""

    name: str
    path: str
