def main() -> None:
    from chatgpt_to_markdown.cli import app

    app()
