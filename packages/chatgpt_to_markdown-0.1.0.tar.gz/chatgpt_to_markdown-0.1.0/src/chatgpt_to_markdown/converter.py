from __future__ import annotations

import logging
import tempfile
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING

from chatgpt_to_markdown.naming import conversation_dirname
from chatgpt_to_markdown.pipeline._jinja import format_date
from chatgpt_to_markdown.pipeline.enricher import build_feedback_index
from chatgpt_to_markdown.pipeline.index_generator import (
    generate_conversations_index,
    generate_dalle_index,
    generate_metadata_files,
    generate_root_index,
)
from chatgpt_to_markdown.pipeline.indexer import build_file_index
from chatgpt_to_markdown.pipeline.loader import load_feedback, load_manifest, load_user, load_user_settings
from chatgpt_to_markdown.pipeline.organizer import organize_conversation, organize_dalle
from chatgpt_to_markdown.pipeline.parser import parse_conversations
from chatgpt_to_markdown.pipeline.renderer import render_conversation
from chatgpt_to_markdown.pipeline.resolver import resolve_conversation_assets
from chatgpt_to_markdown.pipeline.validator import validate_output

if TYPE_CHECKING:
    from chatgpt_to_markdown.config import ConverterConfig
    from chatgpt_to_markdown.models.conversation import Conversation
    from chatgpt_to_markdown.types import FileIndex

logger = logging.getLogger(__name__)


class ChatGPTExportConverter:
    def __init__(self, config: ConverterConfig) -> None:
        self.config = config
        self._tmp_dir: tempfile.TemporaryDirectory[str] | None = None

    def run(self) -> None:
        """Execute the full conversion pipeline."""
        input_dir = self._resolve_input()
        output_dir = self.config.output_dir
        output_dir.mkdir(parents=True, exist_ok=True)

        logger.info("Starting conversion: %s → %s", input_dir, output_dir)

        # Step 1: Load manifest and metadata
        logger.info("Step 1: Loading manifest and metadata")
        manifest = load_manifest(input_dir)
        user = load_user(input_dir, redact_pii=self.config.redact_pii)
        settings = load_user_settings(input_dir)
        feedbacks = load_feedback(input_dir)

        # Step 2: Build file index
        logger.info("Step 2: Building file index")
        file_index = build_file_index(manifest, input_dir)

        # Step 3: Parse conversations
        logger.info("Step 3: Parsing conversations")
        conversations = parse_conversations(input_dir)

        # Step 4: Build feedback index
        logger.info("Step 4: Building feedback index")
        build_feedback_index(feedbacks)

        # Step 5-9: Process each conversation
        logger.info("Step 5-9: Processing %d conversations", len(conversations))
        conv_dirs: dict[str, str] = {}
        for conv in conversations:
            try:
                self._process_conversation(conv, file_index, output_dir, conv_dirs)
            except Exception:
                logger.exception("Error processing conversation %s (%s)", conv.id, conv.title)

        # Step 9b: Organize DALL-E
        logger.info("Step 9b: Organizing DALL-E generations")
        dalle_images = organize_dalle(input_dir, output_dir)

        # Step 10: Generate index files
        logger.info("Step 10: Generating index files")
        generate_root_index(
            output_dir,
            conversation_count=len(conversations),
            total_files=len(manifest.export_files),
            has_dalle=bool(dalle_images),
        )
        generate_conversations_index(output_dir, conversations, conv_dirs)
        if dalle_images:
            generate_dalle_index(output_dir, dalle_images)

        # Generate metadata files
        earliest, latest = self._date_range(conversations)
        generate_metadata_files(
            output_dir,
            user=user,
            settings=settings,
            feedbacks=feedbacks,
            conversation_count=len(conversations),
            manifest_file_count=len(manifest.export_files),
            earliest_date=earliest,
            latest_date=latest,
        )

        # Step 11: Validate
        logger.info("Step 11: Validating output")
        report = validate_output(output_dir)
        logger.info(
            "Validation: %d files, %d broken links, %d missing assets",
            report.total_files,
            len(report.broken_links),
            len(report.missing_assets),
        )

        logger.info("Conversion complete: %d conversations written to %s", len(conversations), output_dir)

    def _resolve_input(self) -> Path:
        """If input_dir is a ZIP, extract to temp dir; otherwise use as-is."""
        input_path = self.config.input_dir
        if input_path.is_file() and zipfile.is_zipfile(input_path):
            logger.info("Extracting ZIP file: %s", input_path)
            self._tmp_dir = tempfile.TemporaryDirectory(prefix="chatgpt-export-")
            tmp = Path(self._tmp_dir.name)
            with zipfile.ZipFile(input_path, "r") as zf:
                zf.extractall(tmp)
            return tmp
        return input_path

    def _process_conversation(
        self,
        conv: Conversation,
        file_index: FileIndex,
        output_dir: Path,
        conv_dirs: dict[str, str],
    ) -> None:

        # Step 5: Resolve assets
        resolved = resolve_conversation_assets(conv, file_index)

        # Step 6-7: Linearize and filter happen inside renderer

        # Step 8: Organize files
        conv_dir, asset_map = organize_conversation(
            conv.id,
            conv.title,
            conv.create_time,
            resolved,
            output_dir,
            deduplicate=self.config.deduplicate_by_hash,
        )
        dirname = conversation_dirname(conv.title, conv.create_time, conv.id)
        conv_dirs[conv.id] = dirname

        # Step 9: Render to Markdown
        md_content = render_conversation(
            conv,
            include_thinking=self.config.include_thinking,
            asset_map=asset_map,
        )
        (conv_dir / "index.md").write_text(md_content, encoding="utf-8")

    @staticmethod
    def _date_range(conversations: list[Conversation]) -> tuple[str, str]:
        times = [c.create_time for c in conversations if c.create_time is not None]
        if not times:
            return ("unknown", "unknown")
        return (format_date(min(times)), format_date(max(times)))
