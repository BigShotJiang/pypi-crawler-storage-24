# Contributing to gpkit-core

Thank you for your interest in contributing to gpkit-core! This guide will help you set up your development environment and get started with contributing.

## Development Environment Setup

### Prerequisites

- Python 3.11 or higher
- Git
- [uv](https://docs.astral.sh/uv/getting-started/installation/)

### Setting Up

1. **Clone the repository**
   ```bash
   git clone https://github.com/beautifulmachines/gpkit-core.git
   cd gpkit-core
   ```

2. **Install dependencies**
   ```bash
   uv sync
   ```

3. **Install git hooks** (recommended — runs formatting and linting on each commit)
   ```bash
   uv run pre-commit install
   ```

4. **Verify**
   ```bash
   make test
   ```

## Development Workflow

### Code Style

We use several tools to maintain code quality:

- **Black** for code formatting
- **isort** for import sorting
- **pylint** for code analysis
- **flake8** for style checking

To format your code:
```bash
make format
```

To run all code quality checks:
```bash
make lint
```

### Running Tests

To run the full test suite:
```bash
make test
```

To run specific tests:
```bash
uv run pytest gpkit/tests/test_specific_file.py
```

### Making Changes

1. Create a new branch for your changes:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. Make your changes and commit them:
   ```bash
   git add .
   git commit -m "Description of your changes"
   ```

3. Run tests and code quality checks:
   ```bash
   make lint
   make test
   ```

4. Push your changes:
   ```bash
   git push origin feature/your-feature-name
   ```

### Pull Request Process

1. Create a pull request from your branch to `main`
2. Ensure all tests pass
3. Update documentation if necessary
4. Wait for review and address any feedback

## Documentation

- Code should be documented using docstrings (Google style)
- Update relevant documentation when making changes
- Build and test documentation locally:
  ```bash
  cd docs && make html
  ```

## Common Issues and Solutions

### Test Failures
- Ensure all dependencies are installed: `uv sync`
- Check if you have the required solvers installed
- Run tests with verbose output:
  ```bash
  uv run pytest -v
  ```

## Getting Help

- Open an issue on GitHub

## License

By contributing to gpkit-core, you agree that your contributions will be licensed under the project's MIT License.
