"""Concepts module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="Concept dynamics", rich_markup_mode="rich")


@app.command(
    epilog=generate_epilog(
        params.CONCEPTS_LATEST_PARAMS,
        [
            "reportify-cli concepts latest",
            "reportify-cli concepts latest --input '{\"include_docs\": false}'",
        ],
    )
)
def latest(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get latest concepts"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.concepts.latest(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(epilog=generate_epilog(params.CONCEPTS_TODAY_PARAMS, ["reportify-cli concepts today"]))
def today(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get today's concept dynamics"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.concepts.today(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
