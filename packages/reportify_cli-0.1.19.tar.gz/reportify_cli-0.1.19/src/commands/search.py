"""Search module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="Document search", rich_markup_mode="rich")


@app.command(
    epilog=generate_epilog(
        params.SEARCH_ALL_PARAMS,
        [
            'reportify-cli search all --input \'{"query": "Tesla earnings", "num": 10}\'',
            'reportify-cli search all --input \'{"query": "Apple", "symbols": ["US:AAPL"], "categories": ["news"]}\'',
        ],
    )
)
def all(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search all document types"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.search.all(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.SEARCH_NEWS_PARAMS,
        [
            'reportify-cli search news --input \'{"query": "Apple iPhone", "num": 10}\'',
            'reportify-cli search news --input \'{"query": "Tesla", "symbols": ["US:TSLA"]}\'',
        ],
    )
)
def news(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search news articles"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.search.news(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.SEARCH_REPORTS_PARAMS,
        [
            'reportify-cli search reports --input \'{"query": "semiconductor analysis", "num": 10}\'',
        ],
    )
)
def reports(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search research reports"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.search.reports(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.SEARCH_FILINGS_PARAMS,
        [
            'reportify-cli search filings --input \'{"query": "10-K", "symbols": ["US:AAPL"]}\'',
        ],
    )
)
def filings(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search company filings"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.search.filings(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="conference_calls",
    epilog=generate_epilog(
        params.SEARCH_CONFERENCE_CALLS_PARAMS,
        [
            'reportify-cli search conference_calls --input \'{"query": "AI strategy", "symbols": ["US:AAPL"]}\'',
        ],
    ),
)
def conference_calls(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search for earnings-related conference call transcripts and presentation slides. Query is optional - if not provided, returns documents in reverse chronological order; if provided, sorts by relevance (note sort_by parameter)."""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.search.conference_calls(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="earnings_pack",
    epilog=generate_epilog(
        params.SEARCH_EARNINGS_PACK_PARAMS,
        [
            'reportify-cli search earnings_pack --input \'{"query": "revenue", "symbols": ["US:AAPL"]}\'',
        ],
    ),
)
def earnings_pack(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search for earnings-related documents submitted to exchanges, including quarterly reports, semi-annual reports, and annual reports. Query is optional - if not provided, returns documents in reverse chronological order; if provided, sorts by relevance (note sort_by parameter)."""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.search.earnings_pack(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.SEARCH_MINUTES_PARAMS,
        [
            'reportify-cli search minutes --input \'{"query": "board meeting", "symbols": ["US:AAPL"]}\'',
        ],
    )
)
def minutes(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search conference calls and IR meetings"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.search.minutes(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.SEARCH_SOCIALS_PARAMS,
        [
            'reportify-cli search socials --input \'{"query": "Tesla stock", "symbols": ["US:TSLA"]}\'',
        ],
    )
)
def socials(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search social media content"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.search.socials(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.SEARCH_WEBPAGES_PARAMS,
        [
            'reportify-cli search webpages --input \'{"query": "AI technology", "num": 20}\'',
        ],
    )
)
def webpages(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search web pages"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.search.webpages(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="crawl",
    epilog=generate_epilog(
        params.SEARCH_CRAWL_PARAMS,
        [
            'reportify-cli search crawl --input \'{"urls": ["https://example.com"]}\'',
            'reportify-cli search crawl --input \'{"urls": ["https://example.com"], "summary": {"query": "核心观点"}}\'',
        ],
    ),
)
def crawl(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Crawl web content from given URLs"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        urls = params_dict.pop("urls", [])
        if not urls:
            raise ValueError("urls is required")
        result = client.search.crawl(urls, **params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

