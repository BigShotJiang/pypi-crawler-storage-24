"""User module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="User data", rich_markup_mode="rich")


@app.command(
    name="followed_companies",
    epilog=generate_epilog(
        params.USER_FOLLOWED_COMPANIES_PARAMS, ["reportify-cli user followed_companies"]
    ),
)
def followed_companies(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get all followed companies"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.user.followed_companies(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="follow_company",
    epilog=generate_epilog(
        params.USER_FOLLOW_COMPANY_PARAMS,
        [
            'reportify-cli user follow_company --input \'{"symbol": "US:AAPL"}\'',
            'reportify-cli user follow_company --input \'{"symbol": "HK:00700"}\'',
            'reportify-cli user follow_company --input \'{"symbol": "SH:600519"}\'',
            'reportify-cli user follow_company --input \'{"symbol": "SZ:000001"}\'',

        ],
    ),
)
def follow_company(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Follow a company (add to watchlist)"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        symbol = params_dict.get("symbol")
        if not symbol:
            raise ValueError("symbol is required")
        result = client.user.follow_company(symbol)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="unfollow_company",
    epilog=generate_epilog(
        params.USER_UNFOLLOW_COMPANY_PARAMS,
        [
            'reportify-cli user unfollow_company --input \'{"symbol": "US:AAPL"}\'',
            'reportify-cli user unfollow_company --input \'{"symbol": "HK:00700"}\'',
        ],
    ),
)
def unfollow_company(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Unfollow a company (remove from watchlist)"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        symbol = params_dict.get("symbol")
        if not symbol:
            raise ValueError("symbol is required")
        result = client.user.unfollow_company(symbol)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

