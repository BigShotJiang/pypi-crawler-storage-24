# Reportify API CLI

Access all [Reportify SDK](https://github.com/reportify-ai/reportify-doc/tree/main/sdks) features via command line.

## Features

- Complete coverage of all 8 SDK modules with 44+ methods
- Multiple output formats: JSON, Table, CSV, Markdown
- Simple unified JSON input format with clear help documentation
- AI-friendly design with detailed parameter descriptions

## Installation

```bash
# Install dependencies and CLI
make install

# Or install directly with uv
uv pip install -e .
```

## Configuration

Set API Key (required):

```bash
# Option 1: Environment variable
export REPORTIFY_API_KEY='your-api-key'

# Option 2: .env file
echo "REPORTIFY_API_KEY=your-api-key" > .env
```

## Quick Start

```bash
# Show help
reportify-cli --help
reportify-cli -h

# Show module help
reportify-cli docs --help

# Show command help
reportify-cli docs get --help

# Get document details (JSON format)
reportify-cli docs get --input '{"doc_id": "1214713494948155392"}'

# Get stock quote (Table format)
reportify-cli stock quote --input '{"symbol": "600519"}' --format table

# Get financial data (Markdown format)
reportify-cli stock income_statement \
  --input '{"symbol": "600519", "period": "annual"}' \
  --format markdown
```

## Available Modules

| Module | Description | Commands |
|--------|-------------|----------|
| `search` | Document search | 9 |
| `docs` | Document management | 4 |
| `stock` | Stock data | 14 |
| `timeline` | Timeline | 5 |
| `kb` | Knowledge base | 1 |
| `user` | User data | 1 |
| `quant` | Quantitative analysis | 8 |
| `concepts` | Concept dynamics | 2 |

## Output Formats

4 output formats supported:

- `--format json` - JSON (default)
- `--format table` - Table
- `--format csv` - CSV
- `--format markdown` or `--format md` - Markdown table

## Development

```bash
# Show all available commands
make help

# Run tests
make test

# Run unit tests
make test-unit

# Run integration tests (requires API Key)
make test-integration

# Format code
make format

# Lint code
make lint

# Clean cache
make clean

# Reinstall
make reinstall
```

## Project Structure

```
reportify-cli/
├── src/                    # Source code
│   ├── main.py            # CLI entry point
│   ├── commands/          # Command modules
│   ├── client.py          # SDK client
│   ├── output.py          # Output formatting
│   ├── params.py          # Parameter definitions
│   ├── settings.py        # Configuration
│   └── utils.py           # Utilities
├── tests/                 # Tests
│   ├── test_commands/     # Unit tests
│   └── integration/       # Integration tests
├── Makefile              # Dev commands
├── pyproject.toml        # Project config
└── README.md             # Documentation
```

## Examples

### Search Documents

```bash
reportify-cli search query \
  --input '{"query": "Tesla earnings", "limit": 10}'
```

### Stock Data

```bash
# Company overview
reportify-cli stock overview --input '{"symbol": "600519"}'

# Financial statements
reportify-cli stock income_statement \
  --input '{"symbol": "600519", "period": "annual"}'

# Stock prices
reportify-cli stock prices \
  --input '{"symbol": "600519", "start_date": "2024-01-01", "end_date": "2024-12-31"}'
```

### Quantitative Analysis

```bash
# Compute technical indicators
reportify-cli quant indicators_compute \
  --input '{"symbols": ["600519"], "formula": "RSI(14)"}' \
  --format table
```
