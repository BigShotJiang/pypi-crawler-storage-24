---
name: reportify-agent
description: Delegate complex financial research and stock screening tasks to the Reportify Agent for autonomous execution. Use when the task requires multi-step analysis that cannot be completed with a single CLI command — such as earnings call transcript analysis across multiple quarters, complex stock screening with custom logic beyond formula expressions, or any research question that needs document retrieval + synthesis. Triggers include deep financial research questions, cross-quarter comparisons, screening with output to Excel, and questions about specific statements in earnings calls or FOMC meetings.
---

# Reportify Agent

Delegate complex tasks to the Reportify Agent via `reportify-cli agent` commands. The agent handles multi-step workflows autonomously — searching documents, analyzing data, screening stocks, and producing structured output (Excel, charts, reports).

## When to Use

Use this skill when the task **cannot be solved with a single `reportify-cli` command** and requires:

- **Deep document research**: "What did TSMC say about CoWoS in 2025Q3 earnings call?"
- **Cross-quarter comparison**: "How did Microsoft's view on AI compute supply change across Q3-Q2 2025-2026?"
- **Complex stock screening with Excel output**: "Screen A-shares for 3 consecutive days of increasing volume, output to Excel"
- **Custom screening logic beyond formula syntax**: "Stocks that hit daily limit but opened during the day" (requires multi-condition logic)
- **Research synthesis**: "What did Powell say about monetary policy at the Jan 29 2026 FOMC press conference?"

Do NOT use when a single `reportify-cli search/stock/quant` command suffices. Use `reportify-ai` skill for those.

## Workflow

### Step 1: Create a conversation

```bash
AGENT_ID="${REPORTIFY_AGENT_ID}"
RESULT=$(reportify-cli agent create_conversation --input "{\"agent_id\": ${AGENT_ID}, \"conversation_type\": \"bot_chat\"}")
CONV_ID=$(echo "$RESULT" | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
```

**`conversation_type` must be `"bot_chat"`** — other types will not trigger the callback hook.

### Step 2: Send the task in background mode

Send the user's question directly as the message. Use `background: true` so the command returns immediately — the agent will process asynchronously.

```bash
CHAT_RESULT=$(reportify-cli agent chat --input "{\"conversation_id\": ${CONV_ID}, \"message\": \"用户的问题\", \"background\": true}")
MSG_ID=$(echo "$CHAT_RESULT" | python3 -c "import sys,json; print(json.load(sys.stdin)['assistant_message_id'])")
```

### Step 3: Notify the user and wait

After sending the task, inform the user that the task has been delegated:

> "已提交给 Reportify Agent 处理，完成后会通过消息通知你。"

The agent's result will be delivered via OpenClaw's callback hook — no need to poll.

### Step 4: (Optional) Check progress or retrieve results

If the user asks about the status, use `get_message_events` to check:

```bash
reportify-cli agent get_message_events --input "{\"conversation_id\": ${CONV_ID}, \"assistant_message_id\": \"${MSG_ID}\", \"stream\": false}"
```

If the agent produces a file (e.g., Excel), retrieve it:

```bash
reportify-cli agent get_file --input "{\"file_id\": \"${FILE_ID}\"}"
```

## Task Phrasing Guidelines

The agent understands Chinese and English. Pass the user's question as-is when possible, but ensure:

1. **Be specific about time scope**: Include fiscal year/quarter, exact dates
2. **Be specific about companies**: Use full company names or stock codes
3. **Specify output format when needed**: "output to Excel" / "输出到 Excel"

### Example: Earnings Call Research

User: "2025Q3财报电话会里，台积电对CoWos的相关讨论是什么"

```bash
reportify-cli agent chat --input "{\"conversation_id\": ${CONV_ID}, \"message\": \"2025Q3财报电话会里，台积电对CoWos的相关讨论是什么\", \"background\": true}"
```

### Example: Cross-Quarter Comparison

User: "在2025Q1-Q4电话会中，亚马逊管理层对 AWS 资本开支节奏的态度分别是什么？是否发生变化？"

```bash
reportify-cli agent chat --input "{\"conversation_id\": ${CONV_ID}, \"message\": \"在2025Q1-Q4电话会中，亚马逊管理层对 AWS 资本开支节奏的态度分别是什么？是否发生变化？\", \"background\": true}"
```

### Example: Stock Screening with Excel Output

User: "A股股票筛选：连续三天成交量增加，结果输出到excel"

```bash
reportify-cli agent chat --input "{\"conversation_id\": ${CONV_ID}, \"message\": \"A股股票筛选：连续三天成交量增加，结果输出到excel\", \"background\": true}"
```

### Example: Complex Custom Screening

User: "A股股票筛选，当日非一字涨停，结果输出到excel"

```bash
reportify-cli agent chat --input "{\"conversation_id\": ${CONV_ID}, \"message\": \"A股股票筛选，当日非一字涨停，结果输出到excel。非一字涨停板定义是：当天最终收在涨停价，但盘中曾经打开过涨停。也就是：收盘价 = 涨停价，但最低价 < 涨停价\", \"background\": true}"
```

## Applicable Task Types

### Financial Document Research
- Earnings call transcript analysis (single or cross-quarter)
- FOMC meeting minutes / press conference analysis
- Management commentary extraction on specific topics
- Cross-company comparison on a theme

### Stock Screening (with Excel output)
- Volume pattern screening (consecutive increase, volume spike)
- Technical pattern screening (MACD/KDJ golden cross, RSI reversal, MA breakout)
- Bollinger Band pattern screening
- Market cap / valuation filtering
- Turnover rate screening
- Price pattern screening (new high/low breakout, limit-up analysis)
- Complex multi-condition screening that goes beyond `quant screen` formula syntax

### Other Complex Tasks
- Multi-step quantitative analysis requiring intermediate calculations
- Research questions requiring document retrieval + synthesis
- Any task that needs structured output (Excel, charts)
