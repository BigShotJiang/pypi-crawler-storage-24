"""Tests for docs commands."""

from unittest.mock import Mock, patch

import pytest
from typer.testing import CliRunner

from src.commands.quant import app

runner = CliRunner()


class TestQuantCommand:

    def test_minute(self):
        res = runner.invoke(app, ["ohlcv", "--input",
                                  '{"symbol": "000001", "start_date": "2026-03-11", "end_date": "2026-03-12"}'],
                            env={"REPORTIFY_API_KEY": "11445916158751750aa638c98a8f24321940a4dac29b3839a"}
                            )
        print(res.output)
