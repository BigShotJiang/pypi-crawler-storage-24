#!/usr/bin/env bash

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get the directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo -e "${BLUE}   Reportify CLI - PyPI Publishing Script${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo ""

# Check if we're in the right directory
if [ ! -f "pyproject.toml" ]; then
    echo -e "${RED}Error: pyproject.toml not found. Are you in the right directory?${NC}"
    exit 1
fi

# Extract version from pyproject.toml
VERSION=$(grep '^version = ' pyproject.toml | sed 's/version = "\(.*\)"/\1/')
echo -e "${YELLOW}Current version: ${VERSION}${NC}"
echo ""

# Parse command line arguments
PUBLISH_TYPE="${1:-prod}"
DRY_RUN="${2:-false}"

if [ "$PUBLISH_TYPE" != "prod" ] && [ "$PUBLISH_TYPE" != "test" ]; then
    echo -e "${RED}Error: First argument must be 'prod' or 'test'${NC}"
    echo "Usage: $0 [prod|test] [dry-run]"
    exit 1
fi

if [ "$PUBLISH_TYPE" == "prod" ]; then
    echo -e "${YELLOW}⚠️  WARNING: Publishing to PRODUCTION PyPI${NC}"
    REPO_URL="https://upload.pypi.org/legacy/"
else
    echo -e "${GREEN}Publishing to TEST PyPI${NC}"
    REPO_URL="https://test.pypi.org/legacy/"
fi
echo ""

# Step 1: Check for uncommitted changes
#echo -e "${BLUE}Step 1: Checking for uncommitted changes...${NC}"
#if [ -n "$(git status --porcelain)" ]; then
#    echo -e "${RED}Error: You have uncommitted changes. Please commit or stash them first.${NC}"
#    git status --short
#    exit 1
#fi
#echo -e "${GREEN}✓ No uncommitted changes${NC}"
#echo ""

# Step 2: Run tests
# echo -e "${BLUE}Step 2: Running tests...${NC}"
# if ! make test > /dev/null 2>&1; then
#     echo -e "${RED}Error: Tests failed. Please fix them before publishing.${NC}"
#     exit 1
# fi
# echo -e "${GREEN}✓ All tests passed${NC}"
# echo ""

# Step 3: Run linter
# echo -e "${BLUE}Step 3: Running linter...${NC}"
# if ! make lint > /dev/null 2>&1; then
#     echo -e "${RED}Error: Linter found issues. Please fix them before publishing.${NC}"
#     exit 1
# fi
# echo -e "${GREEN}✓ Code is clean${NC}"
# echo ""

# Step 4: Clean previous builds
echo -e "${BLUE}Step 4: Cleaning previous builds...${NC}"
make clean > /dev/null 2>&1
echo -e "${GREEN}✓ Cleaned${NC}"
echo ""

# Step 5: Build package
echo -e "${BLUE}Step 5: Building package...${NC}"
if ! make build; then
    echo -e "${RED}Error: Build failed${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Package built successfully${NC}"
echo ""

# Step 6: Check build artifacts
echo -e "${BLUE}Step 6: Checking build artifacts...${NC}"
if [ ! -d "dist" ]; then
    echo -e "${RED}Error: dist/ directory not found${NC}"
    exit 1
fi

WHEEL_FILE=$(find dist -name "*.whl" | head -1)
TAR_FILE=$(find dist -name "*.tar.gz" | head -1)

if [ -z "$WHEEL_FILE" ] || [ -z "$TAR_FILE" ]; then
    echo -e "${RED}Error: Build artifacts not found${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Found build artifacts:${NC}"
echo "  - $WHEEL_FILE"
echo "  - $TAR_FILE"
echo ""

# Step 7: Publish
if [ "$DRY_RUN" == "dry-run" ]; then
    echo -e "${YELLOW}DRY RUN: Skipping actual publish${NC}"
    echo ""
    echo -e "${GREEN}✓ Dry run completed successfully${NC}"
    exit 0
fi

echo -e "${BLUE}Step 7: Publishing to PyPI...${NC}"

# Check if twine is installed
if ! command -v uv &> /dev/null; then
    echo -e "${RED}Error: uv is not installed${NC}"
    exit 1
fi

# Publish
if [ "$PUBLISH_TYPE" == "prod" ]; then
#    echo -e "${YELLOW}Publishing to PRODUCTION PyPI...${NC}"
#    read -p "Are you sure? Type 'y' to confirm: " CONFIRM
#    if [ "$CONFIRM" != "y" ]; then
#        echo -e "${YELLOW}Publish cancelled${NC}"
#        exit 1
#    fi
    uv publish
else
    echo -e "${GREEN}Publishing to TEST PyPI...${NC}"
    uv publish --publish-url https://test.pypi.org/legacy/
fi

echo ""
echo -e "${GREEN}✓ Package published successfully${NC}"
echo ""

# Step 8: Create git tag
#cho -e "${BLUE}Step 8: Creating git tag...${NC}"
#TAG="v${VERSION}"

#if git rev-parse "$TAG" >/dev/null 2>&1; then
#    echo -e "${YELLOW}Warning: Tag $TAG already exists${NC}"
#else
#    git tag -a "$TAG" -m "Release $VERSION"
#    echo -e "${GREEN}✓ Created tag: $TAG${NC}"
#
#    read -p "Push tag to remote? (y/n): " PUSH_TAG
#    if [ "$PUSH_TAG" == "y" ]; then
#        git push origin "$TAG"
#        echo -e "${GREEN}✓ Tag pushed to remote${NC}"
#    fi
#fi
echo ""

echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo -e "${GREEN}   ✓ Publishing Complete!${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo ""
echo -e "Version: ${GREEN}${VERSION}${NC}"
echo -e "Type: ${GREEN}${PUBLISH_TYPE}${NC}"
echo ""

if [ "$PUBLISH_TYPE" == "prod" ]; then
    echo -e "View on PyPI: ${BLUE}https://pypi.org/project/reportify-cli/${VERSION}/${NC}"
    echo -e "Install with: ${YELLOW}pip install reportify-cli${NC}"
else
    echo -e "View on Test PyPI: ${BLUE}https://test.pypi.org/project/reportify-cli/${VERSION}/${NC}"
    echo -e "Install with: ${YELLOW}pip install -i https://test.pypi.org/simple/ reportify-cli${NC}"
fi
echo ""
