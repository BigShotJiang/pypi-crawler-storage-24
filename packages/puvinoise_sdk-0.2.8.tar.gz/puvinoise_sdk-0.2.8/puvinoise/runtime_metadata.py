"""
Runtime metadata collection for PUVINoise Agent Admin UI.
Collected at SDK init and attached to all telemetry events.
"""

import os
import sys
import socket
from typing import Any, Dict, Optional

_RUNTIME_METADATA: Optional[Dict[str, Any]] = None


def _detect_sdk_language() -> str:
    """Detect SDK language (python/node/java). This SDK is Python."""
    return "python"


def _detect_sdk_version() -> str:
    """SDK package version."""
    try:
        from importlib.metadata import version as _version
        return str(_version("puvinoise-sdk")).strip()
    except Exception:
        try:
            from puvinoise import __version__
            return str(__version__).strip()
        except Exception:
            return "0.0.0"


def _detect_runtime() -> str:
    """Runtime version (e.g. Python 3.12.0)."""
    return f"{sys.implementation.name} {sys.version.split()[0]}".strip()


def _detect_host() -> str:
    """Host name."""
    try:
        return socket.gethostname() or ""
    except Exception:
        return ""


def collect_runtime_metadata(agent_id: Optional[str] = None, agent_name: Optional[str] = None) -> Dict[str, Any]:
    """
    Build runtime metadata from env and auto-detection.
    Called during SDK bootstrap. Reads:
      PUVI_AGENT_ID, PUVI_AGENT_NAME, PUVI_DEPLOY_ENV, PUVI_DEPLOY_VERSION, PUVI_REGION,
      PUVI_SDK_LANGUAGE, PUVI_SDK_VERSION (optional; auto-detected if unset).
    """
    global _RUNTIME_METADATA
    agent_id = (agent_id or os.getenv("PUVI_AGENT_ID") or "").strip()
    agent_name = (agent_name or os.getenv("PUVI_AGENT_NAME") or os.getenv("CUST_AGENT_NAME") or "").strip()
    deploy_env = (os.getenv("PUVI_DEPLOY_ENV") or os.getenv("DEPLOYMENT_ENV") or "").strip()
    deploy_version = (os.getenv("PUVI_DEPLOY_VERSION") or "").strip()
    region = (os.getenv("PUVI_REGION") or "").strip()
    sdk_language = (os.getenv("PUVI_SDK_LANGUAGE") or "").strip() or _detect_sdk_language()
    sdk_version = (os.getenv("PUVI_SDK_VERSION") or "").strip() or _detect_sdk_version()

    _RUNTIME_METADATA = {
        "agent_id": agent_id or "",
        "agent_name": agent_name or "",
        "sdk_language": sdk_language,
        "sdk_version": sdk_version,
        "deploy_env": deploy_env or "",
        "deploy_version": deploy_version or "",
        "runtime": _detect_runtime(),
        "host": _detect_host(),
        "region": region or "",
    }
    return _RUNTIME_METADATA


def get_runtime_metadata() -> Dict[str, Any]:
    """Return the current runtime metadata (from last collect). If never collected, collect now."""
    global _RUNTIME_METADATA
    if _RUNTIME_METADATA is None:
        collect_runtime_metadata()
    return dict(_RUNTIME_METADATA or {})


def set_runtime_metadata(metadata: Dict[str, Any]) -> None:
    """Override stored runtime metadata (e.g. for tests)."""
    global _RUNTIME_METADATA
    _RUNTIME_METADATA = dict(metadata) if metadata else None


def ensure_runtime_metadata_env(
    agent_name_default: str = "",
    deploy_env_default: str = "development",
    deploy_version_default: str = "",
) -> None:
    """
    Set PUVI_* environment variables with setdefault so .env can override.
    Call this before bootstrap() in production, test, and demo agents so runtime
    metadata is collected and attached to all telemetry events.
    Reads: PUVI_AGENT_ID, PUVI_AGENT_NAME, PUVI_DEPLOY_ENV, PUVI_DEPLOY_VERSION, PUVI_REGION,
    PUVI_SDK_LANGUAGE, PUVI_SDK_VERSION (optional; SDK auto-detects if unset).
    """
    name = (agent_name_default or os.getenv("CUST_AGENT_NAME") or "").strip()
    if name:
        os.environ.setdefault("PUVI_AGENT_NAME", name)
        if not os.environ.get("PUVI_AGENT_ID", "").strip():
            os.environ.setdefault("PUVI_AGENT_ID", name)
    if deploy_env_default:
        os.environ.setdefault("PUVI_DEPLOY_ENV", deploy_env_default)
    if deploy_version_default:
        os.environ.setdefault("PUVI_DEPLOY_VERSION", deploy_version_default)
    os.environ.setdefault("PUVI_REGION", "")
    # PUVI_SDK_LANGUAGE and PUVI_SDK_VERSION are optional; SDK auto-detects if unset (backward compatible)
