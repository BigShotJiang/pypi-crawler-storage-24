"""
Remote agent control worker for PUViNoise SDK.

Polls GET /api/agent-control/{agentId} at a configurable interval, detects new
commands, and dispatches to internal handlers via a command router. Handlers are
hooks that the agent runtime may override; this module does not assume any
specific agent framework.

Supported commands: pause, resume, stop, restart, deploy, rollback.
Emits telemetry events (agent.control.*) through the existing pipeline.
"""

from __future__ import annotations

import asyncio
import logging
import os
import threading
import time
from dataclasses import dataclass
from typing import Callable, Optional, Union, Awaitable

logger = logging.getLogger(__name__)

CONTROL_EVENT_PREFIX = "agent.control."
VALID_COMMANDS = ("pause", "resume", "stop", "restart", "deploy", "rollback")

DEFAULT_POLL_INTERVAL_SEC = 5.0
CONTROL_BACKOFF_BASE_SEC = 5.0
CONTROL_BACKOFF_MAX_SEC = 300.0
CONTROL_BACKOFF_MULTIPLIER = 2.0


@dataclass
class ControlCommand:
    """Parsed control response from the platform."""

    command: str
    command_id: Optional[str] = None  # API: commandId; used for dedupe
    timestamp: Optional[str] = None
    version: Optional[str] = None


# Type for a handler that accepts optional version; may be sync or async.
ControlHandler = Callable[[Optional[str]], Union[None, Awaitable[None]]]

# Lifecycle hooks: callables invoked on stop/restart. Override for custom behaviour.
OnAgentStopHook = Callable[[], Union[None, Awaitable[None]]]
OnAgentRestartHook = Callable[[], Union[None, Awaitable[None]]]
# Deploy/rollback: SDK notifies host only; host handles version changes.
OnDeployRequestedHook = Callable[[str], Union[None, Awaitable[None]]]
OnRollbackRequestedHook = Callable[[str], Union[None, Awaitable[None]]]


def _noop(_version: Optional[str] = None) -> None:
    """Placeholder handler (no-op). Override via handlers dict or subclassing."""
    pass


class AgentControlWorker:
    """
    Polls the control endpoint and dispatches commands to handlers.
    Prevents duplicate execution of the same command (same command + timestamp).
    """

    def __init__(
        self,
        agent_id: str,
        base_url: str,
        *,
        poll_interval_seconds: float = DEFAULT_POLL_INTERVAL_SEC,
        api_key: Optional[str] = None,
        handlers: Optional[dict[str, ControlHandler]] = None,
        lifecycle_hooks: Optional[dict] = None,
    ):
        """
        Args:
            agent_id: Agent identifier (used in GET /api/agent-control/{agent_id}).
            base_url: Platform base URL (e.g. https://api.example.com), no trailing slash.
            poll_interval_seconds: Seconds between polls (default 5).
            api_key: Optional API key for Authorization header.
            handlers: Optional map of command name -> callable(version). Unlisted commands use no-op.
            lifecycle_hooks: Optional dict with keys: "on_agent_stop", "on_agent_restart",
                "on_deploy_requested", "on_rollback_requested" to override default behaviour.
        """
        self._agent_id = agent_id
        self._base_url = base_url.rstrip("/")
        self._poll_interval = max(0.5, float(poll_interval_seconds))
        self._api_key = api_key or os.environ.get("PUVINOISE_AGENTACCESSKEY", "").strip()
        self._handlers = dict(handlers) if handlers else {}
        hooks = lifecycle_hooks or {}
        self._on_agent_stop = hooks.get("on_agent_stop") or self._default_on_agent_stop
        self._on_agent_restart = hooks.get("on_agent_restart") or self._default_on_agent_restart
        self._on_deploy_requested = hooks.get("on_deploy_requested") or self._default_on_deploy_requested
        self._on_rollback_requested = hooks.get("on_rollback_requested") or self._default_on_rollback_requested

        self._control_url = f"{self._base_url}/api/agent-control/{self._agent_id}"
        self._last_executed_command_id: Optional[str] = None  # last commandId executed
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._next_poll_wait = self._poll_interval  # for exponential backoff on API failure

        # Internal agent state (pause/resume/stop). Access under _lock.
        self._paused = False
        self._stopped = False
        self._resume_event = threading.Event()  # set when not paused; wait_if_paused blocks on this
        self._resume_event.set()  # initially not paused

    # -------------------------------------------------------------------------
    # Command router: dispatch_agent_command maps API command -> handler.
    # -------------------------------------------------------------------------

    def dispatch_agent_command(self, command: ControlCommand) -> None:
        """
        Route a control command to the appropriate handler.
        Ignores commands already executed (by commandId), stores last commandId,
        supports async handlers, and logs execution.
        """
        command_id = (command.command_id or "").strip() or None
        dedupe_key = command_id or f"{(command.command or '').strip()}:{(command.timestamp or '').strip()}"
        with self._lock:
            if dedupe_key and dedupe_key == self._last_executed_command_id:
                logger.debug("Ignoring already executed command commandId=%s", dedupe_key)
                return
            self._last_executed_command_id = dedupe_key

        cmd_name = (command.command or "").strip().lower()
        version = (command.version or "").strip() or None

        logger.info(
            "Executing control command command=%s commandId=%s version=%s",
            cmd_name,
            command_id or "(none)",
            version or "(none)",
        )

        if cmd_name not in VALID_COMMANDS:
            logger.debug("Unknown control command: %s", cmd_name)
            return

        status = "ok"
        try:
            result = None
            if cmd_name == "pause":
                result = self.handle_pause(version)
            elif cmd_name == "resume":
                result = self.handle_resume(version)
            elif cmd_name == "stop":
                result = self.handle_stop(version)
            elif cmd_name == "restart":
                result = self.handle_restart(version)
            elif cmd_name == "deploy":
                result = self.handle_deploy(version)
            elif cmd_name == "rollback":
                result = self.handle_rollback(version)

            if asyncio.iscoroutine(result):
                asyncio.run(result)
        except Exception as e:
            status = "failed"
            logger.warning("Control handler failed for command %s: %s", cmd_name, e)
        finally:
            self._emit_control_event(
                command=cmd_name,
                command_id=command_id,
                timestamp=command.timestamp,
                status=status,
            )

    def _emit_control_event(
        self,
        command: str,
        command_id: Optional[str],
        timestamp: Optional[str],
        status: str,
    ) -> None:
        """
        Emit a control command event through the existing telemetry pipeline.
        Event name: agent.control.{command}. Payload: agentId, command, commandId, timestamp, status.
        Failures are logged at debug and do not affect control flow.
        """
        if command not in VALID_COMMANDS:
            return
        event_name = f"{CONTROL_EVENT_PREFIX}{command}"
        try:
            from opentelemetry import trace
            from opentelemetry.trace import Status, StatusCode
            tracer = trace.get_tracer("puvinoise.control", None)
            with tracer.start_as_current_span(event_name) as span:
                span.set_attribute("agentId", self._agent_id)
                span.set_attribute("command", command)
                if command_id:
                    span.set_attribute("commandId", command_id)
                if timestamp:
                    span.set_attribute("timestamp", timestamp)
                span.set_attribute("status", status)
                if status == "failed":
                    span.set_status(Status(StatusCode.ERROR))
                else:
                    span.set_status(Status(StatusCode.OK))
        except Exception as e:
            logger.debug("Control telemetry emit failed: %s", e)

    # -------------------------------------------------------------------------
    # Internal agent state (pause/resume/stop).
    # -------------------------------------------------------------------------

    @property
    def agent_state(self) -> dict:
        """Current control state: { "paused": bool, "stopped": bool }."""
        with self._lock:
            return {"paused": self._paused, "stopped": self._stopped}

    def is_paused(self) -> bool:
        """True if the agent is currently paused."""
        with self._lock:
            return self._paused

    def is_stopped(self) -> bool:
        """True if the agent has been stopped."""
        with self._lock:
            return self._stopped

    async def wait_if_paused(self) -> None:
        """
        Agent runtimes can call this in their main loop to block execution while paused.
        Returns when not paused. Safe to call repeatedly.

        Example:
            while running:
                await wait_if_paused()
                run_agent_step()
        """
        while True:
            with self._lock:
                if not self._paused:
                    return
                ev = self._resume_event
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None
            if loop is not None:
                await loop.run_in_executor(None, ev.wait)
            else:
                ev.wait(timeout=0.2)

    def wait_if_paused_sync(self) -> None:
        """
        Blocking variant for sync runtimes. Returns when not paused.
        Use in a sync main loop: while running: worker.wait_if_paused_sync(); run_agent_step()
        """
        while self.is_paused():
            self._resume_event.wait(timeout=0.2)

    # -------------------------------------------------------------------------
    # Lifecycle hooks: default implementations (flush telemetry). Override via lifecycle_hooks.
    # -------------------------------------------------------------------------

    def on_agent_stop(self) -> Union[None, Awaitable[None]]:
        """
        Invoked when stop is requested. Override via lifecycle_hooks["on_agent_stop"] or subclassing.
        Default: flush telemetry before exit.
        """
        result = self._on_agent_stop()
        return result

    def on_agent_restart(self) -> Union[None, Awaitable[None]]:
        """
        Invoked after stop() during restart. Override via lifecycle_hooks["on_agent_restart"] or subclassing.
        Default: flush telemetry; override to reinitialize agent runtime and telemetry.
        """
        result = self._on_agent_restart()
        return result

    def _default_on_agent_stop(self) -> None:
        """Default: flush telemetry so nothing is lost before exit."""
        try:
            from puvinoise.bootstrap import force_flush
            from puvinoise.decision_telemetry import flush_decision_events
            force_flush(timeout_millis=5000)
            flush_decision_events(timeout_seconds=5.0)
        except Exception as e:
            logger.debug("Telemetry flush on stop: %s", e)

    def _default_on_agent_restart(self) -> None:
        """Default: flush telemetry. Override to reinitialize agent runtime and telemetry (e.g. bootstrap again)."""
        try:
            from puvinoise.bootstrap import force_flush
            from puvinoise.decision_telemetry import flush_decision_events
            force_flush(timeout_millis=5000)
            flush_decision_events(timeout_seconds=5.0)
        except Exception as e:
            logger.debug("Telemetry flush on restart: %s", e)

    def on_deploy_requested(self, version: str) -> Union[None, Awaitable[None]]:
        """
        Invoked when a deploy command is received. Override via lifecycle_hooks["on_deploy_requested"].
        SDK does not change code versions; host runtime handles deployment logic.
        """
        return self._on_deploy_requested(version or "")

    def on_rollback_requested(self, version: str) -> Union[None, Awaitable[None]]:
        """
        Invoked when a rollback command is received. Override via lifecycle_hooks["on_rollback_requested"].
        SDK does not change code versions; host runtime handles rollback logic.
        """
        return self._on_rollback_requested(version or "")

    def _default_on_deploy_requested(self, version: str) -> None:
        """Default: no-op. Host overrides to perform deploy (e.g. pull image, switch version)."""
        pass

    def _default_on_rollback_requested(self, version: str) -> None:
        """Default: no-op. Host overrides to perform rollback (e.g. switch to previous version)."""
        pass

    # -------------------------------------------------------------------------
    # Handlers: pause/resume update state and log; stop/restart use lifecycle hooks.
    # -------------------------------------------------------------------------

    def handle_pause(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """Set paused=True, log, then invoke optional handlers['pause']."""
        with self._lock:
            self._paused = True
            self._resume_event.clear()
        logger.info("Agent paused by PUVINoise")
        fn = self._handlers.get("pause", _noop)
        return fn(version)

    def handle_resume(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """Set paused=False, log, then invoke optional handlers['resume']."""
        with self._lock:
            self._paused = False
            self._resume_event.set()
        logger.info("Agent resumed by PUVINoise")
        fn = self._handlers.get("resume", _noop)
        return fn(version)

    def handle_stop(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Stop: set agentState.stopped = True, run on_agent_stop() (default: flush telemetry),
        then optional handlers['stop']. Runtimes should check is_stopped() and exit gracefully.
        """
        with self._lock:
            self._stopped = True
        logger.info("Agent stopped by PUVINoise")
        result = self.on_agent_stop()
        if asyncio.iscoroutine(result):
            asyncio.run(result)
        fn = self._handlers.get("stop", _noop)
        handler_result = fn(version)
        if asyncio.iscoroutine(handler_result):
            return handler_result
        return None

    def handle_restart(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Restart: call stop(), then set stopped=False, run on_agent_restart() (default: flush;
        override to reinitialize agent runtime and telemetry), then optional handlers['restart'].
        """
        self.handle_stop(version)
        with self._lock:
            self._stopped = False
        logger.info("Agent restart by PUVINoise")
        result = self.on_agent_restart()
        if asyncio.iscoroutine(result):
            asyncio.run(result)
        fn = self._handlers.get("restart", _noop)
        handler_result = fn(version)
        if asyncio.iscoroutine(handler_result):
            return handler_result
        return None

    def handle_deploy(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Deploy: log structured event, invoke on_deploy_requested(version) so host handles
        deployment (SDK does not change code versions). Then optional handlers['deploy'].
        """
        v = (version or "").strip() or ""
        logger.info(
            "action=deploy_requested agent_id=%s version=%s",
            self._agent_id,
            v or "(none)",
            extra={"action": "deploy_requested", "agent_id": self._agent_id, "version": v},
        )
        result = self.on_deploy_requested(v)
        if asyncio.iscoroutine(result):
            asyncio.run(result)
        logger.debug(
            "action=deploy_completed agent_id=%s version=%s",
            self._agent_id,
            v or "(none)",
            extra={"action": "deploy_completed", "agent_id": self._agent_id, "version": v},
        )
        fn = self._handlers.get("deploy", _noop)
        handler_result = fn(version)
        if asyncio.iscoroutine(handler_result):
            return handler_result
        return None

    def handle_rollback(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Rollback: log structured event, invoke on_rollback_requested(version) so host handles
        rollback (SDK does not change code versions). Then optional handlers['rollback'].
        """
        v = (version or "").strip() or ""
        logger.info(
            "action=rollback_requested agent_id=%s version=%s",
            self._agent_id,
            v or "(none)",
            extra={"action": "rollback_requested", "agent_id": self._agent_id, "version": v},
        )
        result = self.on_rollback_requested(v)
        if asyncio.iscoroutine(result):
            asyncio.run(result)
        logger.debug(
            "action=rollback_completed agent_id=%s version=%s",
            self._agent_id,
            v or "(none)",
            extra={"action": "rollback_completed", "agent_id": self._agent_id, "version": v},
        )
        fn = self._handlers.get("rollback", _noop)
        handler_result = fn(version)
        if asyncio.iscoroutine(handler_result):
            return handler_result
        return None

    def _dispatch(self, cmd: ControlCommand) -> None:
        """Poll loop entry: run command through the dispatcher."""
        self.dispatch_agent_command(cmd)

    def _fetch_control(self) -> Optional[ControlCommand]:
        """
        GET control endpoint and return parsed command or None (200 OK but no command).
        Raises on network/HTTP errors so callers can apply backoff.
        """
        import urllib.request

        req = urllib.request.Request(self._control_url, method="GET")
        req.add_header("Accept", "application/json")
        if self._api_key:
            req.add_header("Authorization", f"Bearer {self._api_key}")

        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            return self._parse_response(body)

    def _parse_response(self, body: str) -> Optional[ControlCommand]:
        """Parse JSON response into ControlCommand. Accepts { command, commandId?, timestamp?, version? }."""
        body = (body or "").strip()
        if not body:
            return None
        try:
            import json

            data = json.loads(body)
            if not isinstance(data, dict):
                return None
            command = data.get("command")
            if not command:
                return None
            command_id = data.get("commandId")
            timestamp = data.get("timestamp")
            version = data.get("version")
            return ControlCommand(
                command=str(command),
                command_id=str(command_id) if command_id is not None else None,
                timestamp=str(timestamp) if timestamp is not None else None,
                version=str(version) if version is not None else None,
            )
        except Exception:
            return None

    def _poll_loop(self) -> None:
        """Background loop: poll then dispatch if new command. Exponential backoff on API failure."""
        while True:
            wait_sec = self._next_poll_wait
            if self._stop.wait(timeout=wait_sec):
                break
            try:
                cmd = self._fetch_control()
                self._next_poll_wait = self._poll_interval  # reset backoff on any successful response
                if cmd is not None:
                    try:
                        self._dispatch(cmd)
                    except Exception as e:
                        logger.warning("Control handler failed for %s: %s", cmd.command, e)
            except Exception as e:
                logger.debug("Control API error (backoff): %s", e)
                self._apply_backoff()

    def _apply_backoff(self) -> None:
        """Increase poll wait time (exponential backoff) up to CONTROL_BACKOFF_MAX_SEC."""
        prev = self._next_poll_wait
        self._next_poll_wait = min(
            CONTROL_BACKOFF_MAX_SEC,
            max(self._poll_interval, prev * CONTROL_BACKOFF_MULTIPLIER),
        )
        if self._next_poll_wait > prev:
            logger.debug(
                "Control API backoff: next poll in %.1fs (was %.1fs)",
                self._next_poll_wait,
                prev,
            )

    def start(self) -> None:
        """Start the polling worker in a background thread."""
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread = threading.Thread(target=self._poll_loop, daemon=True)
            self._thread.start()
        logger.debug("Control worker started for agent %s", self._agent_id)

    def stop(self) -> None:
        """Stop the polling worker."""
        self._stop.set()
        t = self._thread
        self._thread = None
        if t is not None and t.is_alive():
            t.join(timeout=self._poll_interval * 2)
        logger.debug("Control worker stopped for agent %s", self._agent_id)
