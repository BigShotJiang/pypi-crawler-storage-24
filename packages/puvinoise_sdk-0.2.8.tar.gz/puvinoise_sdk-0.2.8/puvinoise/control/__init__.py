"""
Remote agent control for PUViNoise SDK.

Polling worker that fetches commands from GET /api/agent-control/{agentId}
and dispatches to configurable handlers (pause, resume, stop, restart, deploy, rollback).
Not wired into telemetry; framework-agnostic hooks only.
"""

from puvinoise.control.agent_control_worker import (
    AgentControlWorker,
    ControlCommand,
    ControlHandler,
    DEFAULT_POLL_INTERVAL_SEC,
    OnAgentStopHook,
    OnAgentRestartHook,
    OnDeployRequestedHook,
    OnRollbackRequestedHook,
)

__all__ = [
    "AgentControlWorker",
    "ControlCommand",
    "ControlHandler",
    "DEFAULT_POLL_INTERVAL_SEC",
    "OnAgentStopHook",
    "OnAgentRestartHook",
    "OnDeployRequestedHook",
    "OnRollbackRequestedHook",
]
