"""
OpenTelemetry bootstrap for PUViNoise SDK.

Production features:
 - Retry-capable OTLP exporter with configurable backoff
 - Reliable export: retry with exponential backoff + offline persistence (telemetry never lost)
 - Graceful shutdown with atexit hook (flushes pending spans, replays persisted)
 - Optional gzip compression
 - Configurable batch processor for high-frequency telemetry
 - Structured logging for telemetry pipeline status
"""

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
import atexit
import logging
import os

from puvinoise.reliable_export import ReliableSpanExporter
from puvinoise.runtime_metadata import collect_runtime_metadata, get_runtime_metadata

logger = logging.getLogger(__name__)

_initialized = False
_provider = None
_reliable_exporter = None  # for flush_persisted at exit
_control_worker = None  # AgentControlWorker when control is enabled


def _create_otlp_exporter(endpoint: str, headers: dict | None, compression: bool, timeout: int = 30):
    kwargs = {"endpoint": endpoint, "timeout": timeout}
    if headers:
        kwargs["headers"] = headers
    if compression:
        try:
            from opentelemetry.exporter.otlp.proto.http import Compression
            kwargs["compression"] = Compression.Gzip
        except ImportError:
            pass
    return OTLPSpanExporter(**kwargs)


def init(
    api_key: str = None,
    agent_name: str = None,
    agent_id: str = None,
    endpoint: str = None,
    tenant_id: str = None,
    console_export: bool = False,
    batch_config: dict = None,
    compression: bool = True,
    control_config: dict = None,
):
    """
    One-line init for minimal integration. Sets env from config and calls bootstrap.

    Example::
        puvinoise.init(api_key="PUVI_API_KEY", agent_name="research-agent", agent_id="agt_xxx", endpoint="https://api.example.com/v1/traces")
        agent = puvinoise.wrapAgent(my_agent)

    agent_id: Optional stable agent identity (e.g. agt_xxx from registration). Can also be set via PUVI_AGENT_ID.
    control_config: Optional dict with agentId, controlApiUrl, pollingInterval (seconds).
        When set, starts the agent control worker in the background after telemetry init.
    """
    if api_key:
        key = str(api_key).strip()
        os.environ["PUVINOISE_AGENTACCESSKEY"] = key
        os.environ["PUVI_API_KEY"] = key
    if agent_name:
        os.environ["CUST_AGENT_NAME"] = str(agent_name).strip()
    if agent_id:
        os.environ["PUVI_AGENT_ID"] = str(agent_id).strip()
    if endpoint:
        os.environ["PUVINOISE_END_POINT_URL"] = str(endpoint).rstrip("/")
    if tenant_id:
        tid = str(tenant_id).strip()
        os.environ["PUVINOISE_TENANT_ID"] = tid
        os.environ["PUVINOISE_TENANTID"] = tid
    return bootstrap(
        service_name=agent_name,
        otlp_endpoint=endpoint,
        console_export=console_export,
        batch_config=batch_config,
        compression=compression,
        control_config=control_config,
    )


def bootstrap(
    service_name: str = None,
    otlp_endpoint: str = None,
    console_export: bool = False,
    batch_config: dict = None,
    compression: bool = True,
    control_config: dict = None,
):
    """
    Initialize OpenTelemetry tracing for the agent, then optionally start the agent control worker.

    Tuned for high-frequency telemetry (e.g. every second per agent):
    batching every 1s, optional gzip compression, retry-capable export.

    Reads env: CUST_AGENT_NAME, PUVI_AGENT_ID, CUST_LLM_PROVIDER, PUVINOISE_TENANTID,
    PUVINOISE_AGENTACCESSKEY, PUVINOISE_END_POINT_URL; optional deployment metadata:
    PUVI_DEPLOY_ENV, PUVI_DEPLOY_VERSION, PUVI_REGION, PUVI_SDK_LANGUAGE, PUVI_SDK_VERSION
    (SDK auto-detects language/version if unset for backward compatibility).

    control_config: Optional dict with agentId, controlApiUrl, pollingInterval (seconds).
        Starts control worker in background; failures do not crash the SDK.
    """
    global _initialized, _provider

    puvicustagentname = (os.getenv("CUST_AGENT_NAME") or "").strip()
    name = (service_name or puvicustagentname or "").strip()
    if not name:
        raise ValueError(
            "Agent name must be set via service_name argument or CUST_AGENT_NAME environment variable"
        )

    if _initialized:
        logger.info("Tracer already initialized for service: %s", name)
        return trace.get_tracer(name)

    endpoint = (otlp_endpoint or os.getenv("PUVINOISE_END_POINT_URL") or "").strip()
    if not endpoint:
        raise ValueError(
            "OTLP endpoint must be set via otlp_endpoint or PUVINOISE_END_POINT_URL environment variable"
        )
    if not endpoint.endswith("/v1/traces"):
        endpoint = endpoint.rstrip("/") + "/v1/traces"

    access_key = (os.getenv("PUVINOISE_AGENTACCESSKEY") or "").strip()
    headers = {}
    if access_key:
        headers["Authorization"] = f"Bearer {access_key}"

    llm_provider = (os.getenv("CUST_LLM_PROVIDER") or "").strip()
    # Real tenant ID from env (matches backend tenantId). Reject placeholder.
    tenant_id = (os.getenv("PUVINOISE_TENANT_ID") or os.getenv("PUVINOISE_TENANTID") or "").strip()
    if tenant_id.lower() == "your-tenant-id":
        tenant_id = ""

    try:
        from puvinoise import __version__ as _sdk_version
        sdk_version = str(_sdk_version)
    except Exception:
        sdk_version = "0.0.0"
    puvi_agent_id = (os.getenv("PUVI_AGENT_ID") or "").strip()
    collect_runtime_metadata(agent_id=puvi_agent_id or None, agent_name=name)
    runtime_meta = get_runtime_metadata()
    resource_attrs = {
        "service.name": name,
        "service.version": sdk_version,
        "deployment.environment": runtime_meta.get("deploy_env") or os.getenv("DEPLOYMENT_ENV", "production"),
        "puvinoise.sdk.version": sdk_version,
        "puvinoise.telemetry.schema": "v2",
        "tenant.id": tenant_id,
        "agent.name": name,
        "puvinoise.sdk_language": runtime_meta.get("sdk_language", ""),
        "puvinoise.deploy_version": runtime_meta.get("deploy_version", ""),
        "puvinoise.runtime": runtime_meta.get("runtime", ""),
        "puvinoise.host": runtime_meta.get("host", ""),
        "puvinoise.region": runtime_meta.get("region", ""),
    }
    if puvi_agent_id:
        resource_attrs["agent.id"] = puvi_agent_id
        resource_attrs["puvinoise.agent_id"] = puvi_agent_id
    if llm_provider:
        resource_attrs["puvinoise.llm_provider"] = llm_provider
        resource_attrs["llm.provider"] = llm_provider
    resource = Resource.create(resource_attrs)

    provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(provider)

    default_batch_config = {
        "schedule_delay_millis": 1000,
        "max_export_batch_size": 128,
        "export_timeout_millis": 30000,
        "max_queue_size": 4096,
    }

    if batch_config:
        default_batch_config.update(batch_config)

    try:
        otlp_exporter = _create_otlp_exporter(
            endpoint=endpoint,
            headers=headers if headers else None,
            compression=compression,
            timeout=default_batch_config.get("export_timeout_millis", 30000) // 1000,
        )
        persist_dir = os.environ.get("PUVINOISE_SPAN_PERSIST_DIR") or os.path.join(
            os.path.expanduser("~"), ".puvinoise", "span_queue"
        )
        reliable_exporter = ReliableSpanExporter(
            otlp_exporter,
            persist_dir=persist_dir,
        )
        global _reliable_exporter
        _reliable_exporter = reliable_exporter
        provider.add_span_processor(
            BatchSpanProcessor(reliable_exporter, **default_batch_config)
        )
        # Replay any spans persisted from previous runs (e.g. API was down)
        replayed = reliable_exporter.flush_persisted()
        if replayed:
            logger.info("Replayed %s persisted spans from previous run", replayed)
        logger.info("OTLP exporter configured (reliable): %s", endpoint)
    except Exception as e:
        logger.error("Failed to configure OTLP exporter: %s", e)
        console_export = True

    if console_export:
        console_exporter = ConsoleSpanExporter()
        provider.add_span_processor(
            BatchSpanProcessor(console_exporter, **default_batch_config)
        )
        logger.info("Console exporter configured for debugging")

    _initialized = True
    _provider = provider

    atexit.register(_atexit_flush)

    # Optional: reliable buffer for decision events (HTTP ingest with persistence)
    try:
        from puvinoise.telemetry_buffer import init_decision_buffer_from_env
        if init_decision_buffer_from_env() is not None:
            logger.info("Decision telemetry buffer enabled (ingest URL); events will be persisted if API is unavailable")
    except Exception as e:
        logger.debug("Decision buffer not configured: %s", e)

    logger.info("OpenTelemetry initialized for service: %s", name)

    control_agent_id = (control_config.get("agentId") if control_config else None) or puvi_agent_id
    if control_config and control_config.get("controlApiUrl") and control_agent_id:
        start_agent_control_worker(
            agent_id=control_agent_id,
            control_api_url=control_config["controlApiUrl"],
            polling_interval=control_config.get("pollingInterval"),
            api_key=control_config.get("apiKey"),
            lifecycle_hooks=control_config.get("lifecycleHooks"),
        )

    return trace.get_tracer(name)


def get_control_worker():
    """Return the active agent control worker, or None if control is not enabled or failed to start."""
    return _control_worker


def start_agent_control_worker(
    agent_id: str,
    control_api_url: str,
    polling_interval: float = None,
    api_key: str = None,
    lifecycle_hooks: dict = None,
):
    """
    Start the agent control worker in a background thread.
    Failures (import, constructor, start) are logged and do not raise.
    """
    global _control_worker
    try:
        from puvinoise.control import AgentControlWorker, DEFAULT_POLL_INTERVAL_SEC
        base_url = (control_api_url or "").strip().rstrip("/")
        if not base_url or not (agent_id or "").strip():
            return
        interval = float(polling_interval) if polling_interval is not None else DEFAULT_POLL_INTERVAL_SEC
        interval = max(0.5, interval)
        _control_worker = AgentControlWorker(
            agent_id=agent_id.strip(),
            base_url=base_url,
            poll_interval_seconds=interval,
            api_key=(api_key or os.environ.get("PUVINOISE_AGENTACCESSKEY") or "").strip() or None,
            lifecycle_hooks=lifecycle_hooks,
        )
        _control_worker.start()
        logger.info(
            "Agent control worker started agent_id=%s control_api_url=%s polling_interval=%.1fs",
            agent_id,
            base_url,
            interval,
        )
    except Exception as e:
        logger.warning("Agent control worker failed to start (SDK continues): %s", e)
        _control_worker = None


def _atexit_flush():
    """Auto-flush on interpreter exit; replay persisted spans and decision buffer so telemetry is never lost."""
    try:
        if _provider is not None:
            _provider.force_flush(timeout_millis=5000)
        if _reliable_exporter is not None:
            _reliable_exporter.flush_persisted()
        try:
            from puvinoise.telemetry_buffer import get_decision_buffer
            buf = get_decision_buffer()
            if buf is not None:
                buf.flush(timeout_sec=5.0)
        except Exception:
            pass
    except Exception:
        pass


def shutdown():
    """
    Gracefully shutdown the tracer provider and stop the agent control worker.
    Call this when your application is terminating to ensure all spans are exported.
    Replays any persisted span batches before shutdown.
    """
    global _provider, _reliable_exporter, _control_worker
    if _control_worker is not None:
        try:
            _control_worker.stop()
            logger.debug("Agent control worker stopped")
        except Exception as e:
            logger.debug("Error stopping control worker: %s", e)
        _control_worker = None
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        if _reliable_exporter is not None:
            _reliable_exporter.flush_persisted()
            _reliable_exporter.shutdown()
        provider.shutdown()
        logger.info("OpenTelemetry tracer provider shut down successfully")
    _provider = None
    _reliable_exporter = None


def force_flush(timeout_millis: int = 30000):
    """
    Force flush all pending spans.

    Args:
        timeout_millis: Maximum time to wait for flush in milliseconds
    """
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        success = provider.force_flush(timeout_millis)
        if success:
            logger.info("Successfully flushed all pending spans")
        else:
            logger.warning("Flush timed out or failed")
        return success
    return False


def is_initialized() -> bool:
    """Check if the tracer has been initialized."""
    return _initialized
