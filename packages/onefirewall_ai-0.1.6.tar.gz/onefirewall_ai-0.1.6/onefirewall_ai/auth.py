"""
auth.py — Login flow: prompt endpoint + API key, test connection, save.
"""

import getpass
import sys
import json

import requests
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich import print as rprint

from onefirewall_ai.config import load_access, save_access

console = Console()

DEFAULT_ENDPOINT = "https://onefirewall.ai"


def _get_available_models(endpoint: str, api_key: str) -> list[str]:
    """
    Fetch all available workspaces/models from /api/v1/models.
    Returns a list of model IDs.
    """
    url = endpoint.rstrip("/") + "/api/v1/models"
    headers = {
        "Authorization": f"Bearer {api_key}",
    }
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code == 200:
            data = resp.json().get("data", [])
            return [m["id"] for m in data if "id" in m]
    except Exception:
        pass
    return []


def _test_connection(endpoint: str, api_key: str, model: str = "openai/gpt-4o") -> tuple[bool, str]:
    """
    Send a minimal chat request to verify the endpoint + key combo.
    Returns (success: bool, message: str).
    """
    url = endpoint.rstrip("/") + "/api/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": "ping"}],
        "stream": False,
    }
    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=15)
        if resp.status_code == 200:
            return True, "Connection successful ✓"
        elif resp.status_code == 401:
            return False, "Invalid API key (401 Unauthorized)"
        elif resp.status_code == 403:
            return False, "Access forbidden (403) — check your API key permissions"
        elif resp.status_code == 404:
            return False, f"Endpoint not found (404) — is '{endpoint}' correct?"
        else:
            return False, f"Unexpected response: HTTP {resp.status_code} — {resp.text[:200]}"
    except requests.exceptions.ConnectionError:
        return False, f"Cannot connect to '{endpoint}' — is the server running?"
    except requests.exceptions.Timeout:
        return False, "Connection timed out after 15 seconds"
    except Exception as exc:
        return False, f"Unexpected error: {exc}"


def login() -> None:
    """Interactive login: prompt endpoint, API key, test, then save."""
    console.print()
    console.print(Panel(
        "[bold cyan]OneFirewall AI — Login[/bold cyan]\n"
        "[dim]Set up your endpoint and API key to start chatting.[/dim]",
        border_style="cyan",
    ))
    console.print()

    # ── Step 1: Endpoint ──────────────────────────────────────────────────────
    existing = load_access()
    current_endpoint = existing.get("endpoint") or DEFAULT_ENDPOINT

    endpoint = Prompt.ask(
        "[bold]API Endpoint[/bold]",
        default=current_endpoint,
        console=console,
    ).strip().rstrip("/")

    # normalise — add https:// if scheme missing
    if endpoint and not endpoint.startswith(("http://", "https://")):
        endpoint = "https://" + endpoint

    # ── Step 2: API Key ───────────────────────────────────────────────────────
    console.print()
    console.print("[dim]Get your API key from the Profile page on the dashboard.[/dim]")
    try:
        api_key = getpass.getpass("API Key (hidden): ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Login cancelled.[/yellow]")
        sys.exit(0)

    if not api_key:
        console.print("[red]✗ API key cannot be empty.[/red]")
        sys.exit(1)

    # ── Step 3: Fetch workspaces ─────────────────────────────────────────────
    console.print()
    with console.status("[bold cyan]Fetching workspaces…[/bold cyan]", spinner="dots"):
        models = _get_available_models(endpoint, api_key)
    
    # Default model if none found
    selected_model = existing.get("model") or "openai/gpt-4o"
    
    if models:
        if len(models) == 1:
            selected_model = models[0]
            console.print(f"[dim]Found 1 workspace. Selecting '[bold cyan]{selected_model}[/bold cyan]' as default.[/dim]")
        else:
            console.print(f"[bold cyan]Found {len(models)} workspaces. Please select one:[/bold cyan]")
            for i, m in enumerate(models, 1):
                console.print(f"  {i}) [white]{m}[/white]")
            
            # Default to existing model if it's in the list, otherwise default to first
            default_choice = "1"
            if selected_model in models:
                default_choice = str(models.index(selected_model) + 1)

            choice = Prompt.ask(
                "\n[bold]Select workspace index[/bold]",
                choices=[str(i) for i in range(1, len(models) + 1)],
                default=default_choice,
                console=console,
            )
            selected_model = models[int(choice) - 1]
            console.print(f"[dim]Selected: '[bold cyan]{selected_model}[/bold cyan]'[/dim]")
    else:
        console.print("[yellow]! Could not fetch workspaces. Using default model.[/yellow]")

    # ── Step 4: Test connection ──────────────────────────────────────────────
    console.print()
    with console.status(f"[bold cyan]Testing connection with '{selected_model}'…[/bold cyan]", spinner="dots"):
        ok, msg = _test_connection(endpoint, api_key, model=selected_model)

    if ok:
        console.print(f"[bold green]✓ {msg}[/bold green]")
    else:
        console.print(f"[bold red]✗ {msg}[/bold red]")
        console.print("[dim]Please check your endpoint and API key and try again.[/dim]")
        sys.exit(1)

    console.print()
    console.print()
    # ── Step 4: Save ──────────────────────────────────────────────────────────
    data = {**existing, "endpoint": endpoint, "api_key": api_key, "model": selected_model}
    save_access(data)

    from onefirewall_ai.utils import sync_memory
    sync_memory()

    console.print()
    console.print(Panel(
        f"[bold green]Logged in successfully![/bold green]\n"
        f"[dim]Endpoint:[/dim] [cyan]{endpoint}[/cyan]\n"
        f"[dim]Config saved to:[/dim] [cyan]~/.onefirewall-ai/access.json[/cyan]",
        border_style="green",
    ))
    console.print()
    console.print("[dim]Run [bold]onefirewall-ai hello![/bold] to start chatting.[/dim]")
    console.print()
