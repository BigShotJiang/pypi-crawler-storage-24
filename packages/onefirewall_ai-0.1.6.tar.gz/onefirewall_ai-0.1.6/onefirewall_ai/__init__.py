"""
onefirewall-ai — CLI for the OneFirewall AI Gateway
"""

__version__ = "0.1.6"
__app_name__ = "onefirewall-ai"
__description__ = "CLI for the OneFirewall AI Gateway — chat, stream, and build agents from your terminal"
