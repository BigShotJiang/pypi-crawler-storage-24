"""Allow `python -m onefirewall_ai` execution."""

from onefirewall_ai.cli import main

if __name__ == "__main__":
    main()
