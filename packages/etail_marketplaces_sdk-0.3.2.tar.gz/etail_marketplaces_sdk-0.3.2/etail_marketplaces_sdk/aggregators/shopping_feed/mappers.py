"""
ShoppingFeed mappers — raw API response dict → canonical SDK models.

This is the ONLY file that should be updated when the ShoppingFeed OpenAPI spec changes.
Cross-reference with: specs/aggregators/shopping_feed/order.yml
                      specs/aggregators/shopping_feed/catalog_product.yml

ShoppingFeed API reference: https://developer.shopping-feed.com/order-api
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, Optional

from etail_marketplaces_sdk.core.decimal_utils import optional_decimal
from etail_marketplaces_sdk.models.address import Address
from etail_marketplaces_sdk.models.brand import Brand
from etail_marketplaces_sdk.models.invoice import Invoice, InvoiceAddress, InvoiceItem
from etail_marketplaces_sdk.models.order import Order, OrderItem
from etail_marketplaces_sdk.models.product import Product, ProductAttribute, ProductImage
from etail_marketplaces_sdk.models.stock import StockLevel


def _parse_dt(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _build_name(data: dict[str, Any]) -> str:
    """Combine first name, last name, and company into a display name."""
    first = data.get("firstName") or ""
    last = data.get("lastName") or ""
    full = f"{first} {last}".strip()
    company = data.get("company") or ""
    if company and full:
        return f"{full} ({company})"
    return company or full


def _shoppingfeed_marketplace_name(raw: dict[str, Any]) -> Optional[str]:
    """Channel display name from ``_embedded.channel.name`` (list/detail order payloads)."""
    ch = (raw.get("_embedded") or {}).get("channel") or {}
    name = ch.get("name")
    return str(name).strip() if name else None


def _shoppingfeed_order_commission(raw: dict[str, Any]) -> Optional[Decimal]:
    """Order-level ``commission`` or sum of per-line ``items[].commission``."""
    top = optional_decimal(raw.get("commission"))
    if top is not None:
        return top
    total = Decimal("0")
    found = False
    for item in raw.get("items", []) or []:
        c = optional_decimal(item.get("commission"))
        if c is not None:
            total += c
            found = True
    return total if found else None


def _map_address(data: dict[str, Any]) -> Address:
    return Address(
        name=_build_name(data),
        address_line1=data.get("street") or "",
        address_line2=data.get("street2") or None,
        postal_code=data.get("postalCode") or "",
        city=data.get("city") or "",
        country=data.get("country") or "",
        phone=data.get("phone") or data.get("mobilePhone"),
        email=data.get("email"),
    )


def _map_invoice_address(data: dict[str, Any]) -> InvoiceAddress:
    street = data.get("street") or ""
    street2 = data.get("street2") or ""
    full_street = f"{street}, {street2}".strip(", ") if street2 else street
    return InvoiceAddress(
        name=_build_name(data),
        address=full_street,
        postal_code=data.get("postalCode") or "",
        city=data.get("city") or "",
        country=data.get("country") or "",
        phone=data.get("phone") or data.get("mobilePhone"),
        email=data.get("email"),
    )


def map_stock_level(
    record: dict[str, Any],
    aggregator_id: int,
    store_id: str,
) -> StockLevel:
    """Map a single ``GET /v1/catalog/{catalogId}/inventory`` item to a canonical :class:`StockLevel`.

    Args:
        record:        One item from ``_embedded.inventory[]``.
                       Fields: id (inventory ID), reference (SKU), quantity, updatedAt.
        aggregator_id: Numeric aggregator ID.
        store_id:      ShoppingFeed store/catalog ID (used as warehouse_id).

    Returns:
        A populated :class:`~etail_marketplaces_sdk.models.stock.StockLevel`.
    """
    return StockLevel(
        sku=record.get("reference") or "",
        quantity_available=int(record.get("quantity") or 0),
        aggregator_id=aggregator_id,
        platform_id=str(record.get("id")) if record.get("id") is not None else None,
        warehouse_id=str(store_id),
        last_updated=_parse_dt(record.get("updatedAt")),
        raw=record,
    )


def map_product(
    record: dict[str, Any],
    aggregator_id: int,
    store_id: str,
) -> Product:
    """Map a single ``GET /v1/catalog/{catalogId}/reference`` item to a canonical :class:`Product`.

    The ShoppingFeed reference model is a flat representation of a catalog product.
    Nested ``_embedded.images`` and ``_embedded.attributes`` are mapped to
    :class:`ProductImage` and :class:`ProductAttribute` collections respectively.

    Args:
        record:        One item from ``_embedded.reference[]``.
                       Fields: id, reference (SKU), name, status, price,
                       quantity, _embedded.images, _embedded.attributes.
        aggregator_id: Numeric aggregator ID.
        store_id:      ShoppingFeed store/catalog ID (used as marketplace_id context).

    Returns:
        A populated :class:`~etail_marketplaces_sdk.models.product.Product`.
    """
    embedded = record.get("_embedded") or {}

    images: list[ProductImage] = []
    for pos, img in enumerate(embedded.get("images") or []):
        url = img.get("url") or img.get("link") or img.get("href") or ""
        if url:
            images.append(ProductImage(url=url, position=pos))

    attributes: list[ProductAttribute] = []
    for attr in embedded.get("attributes") or []:
        name = attr.get("name") or attr.get("key") or ""
        value = attr.get("value") or ""
        if name:
            attributes.append(ProductAttribute(name=name, value=str(value)))

    price_raw = record.get("price")
    price = Decimal(str(price_raw)) if price_raw is not None else None

    status = record.get("status") or record.get("state") or "published"
    is_active = str(status).lower() != "unpublished"

    return Product(
        sku=record.get("reference") or "",
        name=record.get("name") or "",
        aggregator_id=aggregator_id,
        marketplace_id=None,
        platform_id=str(record.get("id")) if record.get("id") is not None else None,
        ean=record.get("ean") or record.get("gtin"),
        description=record.get("description"),
        price_incl_vat=price,
        brand=record.get("brand") or (embedded.get("brand") or {}).get("name"),
        category=(embedded.get("category") or {}).get("name") or record.get("category"),
        images=images,
        attributes=attributes,
        is_active=is_active,
        updated_at=_parse_dt(record.get("updatedAt") or record.get("publishedAt")),
        raw=record,
    )


def map_order(
    raw: dict[str, Any],
    aggregator_id: int,
    brand: Brand,
) -> Order:
    created_at = _parse_dt(raw.get("createdAt")) or datetime.now()
    updated_at = _parse_dt(raw.get("updatedAt"))
    payment = raw.get("payment", {})
    total_incl = Decimal(str(payment.get("totalAmount", "0")))
    shipping_incl = Decimal(str(payment.get("shippingAmount", "0")))

    billing = raw.get("billingAddress", {})
    shipping = raw.get("shippingAddress", {})

    items = _map_order_items(raw)

    return Order(
        aggregator_order_id=str(raw.get("id", "")),
        marketplace_order_id=raw.get("reference", ""),
        aggregator_id=aggregator_id,
        marketplace_id=raw.get("_embedded", {}).get("channel", {}).get("id") or raw.get("channelId") or 0,
        brand_id=brand.id,
        order_date=created_at,
        status=raw.get("status", ""),
        eur_amount_excl_vat=Decimal("0"),
        eur_amount_incl_vat=total_incl,
        eur_shipping_fee_excl_vat=Decimal("0"),
        eur_shipping_fee_incl_vat=shipping_incl,
        original_currency=payment.get("currency", "EUR"),
        original_amount=total_incl,
        original_shipping_fee=shipping_incl,
        items=items,
        billing_address=_map_address(billing) if billing else None,
        shipping_address=_map_address(shipping) if shipping and shipping != billing else None,
        created_date=created_at,
        updated_date=updated_at,
        marketplace_name=_shoppingfeed_marketplace_name(raw),
        commission=_shoppingfeed_order_commission(raw),
        raw=raw,
    )


def _map_order_items(raw: dict[str, Any]) -> list[OrderItem]:
    items = []
    for item in raw.get("items", []):
        price_incl = Decimal(str(item.get("price", "0")))
        quantity = int(item.get("quantity", 0))
        items.append(
            OrderItem(
                reference=item.get("reference", ""),
                name=item.get("name", ""),
                quantity=quantity,
                unit_price_excl_vat=Decimal("0"),
                unit_price_incl_vat=price_incl,
                vat_rate=Decimal("0"),
                total_price_excl_vat=Decimal("0"),
                total_price_incl_vat=price_incl * quantity,
                sku=item.get("reference", ""),
                commission=optional_decimal(item.get("commission")),
            )
        )
    return items


def map_invoice(
    raw: dict[str, Any],
    aggregator_id: int,
    brand: Brand,
    tax_rate: Decimal = Decimal("20"),
) -> Optional[Invoice]:
    if raw.get("status") != "shipped":
        return None

    billing = raw.get("billingAddress", {})
    shipping = raw.get("shippingAddress", {})

    billing_address = _map_invoice_address(billing)
    shipping_address = _map_invoice_address(shipping) if shipping and shipping != billing else None

    items, subtotal, _ = _map_invoice_items(raw, tax_rate)

    payment = raw.get("payment", {})
    shipping_incl = Decimal(str(payment.get("shippingAmount", "0")))
    shipping_excl = (shipping_incl * 100) / (100 + tax_rate)
    payment_method = payment.get("method", "")

    return Invoice(
        invoice_number=str(raw["id"]),
        order_reference=raw.get("reference", ""),
        order_date=_parse_dt(raw.get("createdAt")) or datetime.now(),
        brand_id=brand.id,
        aggregator_id=aggregator_id,
        marketplace_id=raw.get("_embedded", {}).get("channel", {}).get("id") or raw.get("channelId") or 0,
        company_info=brand.company_info,
        logo_path=brand.logo_url,
        footer_text=brand.invoice_footer_text,
        brand_initials=brand.initials,
        billing_address=billing_address,
        shipping_address=shipping_address,
        subtotal=subtotal,
        vat_rate=tax_rate,
        total_amount=Decimal(str(payment.get("totalAmount", "0"))),
        items=items,
        shipping_cost=shipping_excl,
        payment_method=payment_method,
        invoice_status="paid",
        currency=payment.get("currency", "EUR"),
        payment_plan_commission=Decimal("0"),
    )


def _map_invoice_items(
    raw: dict[str, Any], tax_rate: Decimal
) -> tuple[list[InvoiceItem], Decimal, Decimal]:
    items = []
    subtotal = Decimal("0")
    total_tax = Decimal("0")

    for item in raw.get("items", []):
        price_incl = Decimal(str(item.get("price", "0")))
        quantity = int(item.get("quantity", 0))
        price_excl = (price_incl * 100) / (100 + tax_rate)
        item_total = price_excl * quantity
        item_tax = item_total * (tax_rate / 100)

        items.append(
            InvoiceItem(
                reference=item.get("reference", ""),
                name=item.get("name", ""),
                quantity=quantity,
                unit_price=price_excl,
                total_price=item_total,
                tax_rate=tax_rate,
                sku=item.get("reference", ""),
            )
        )
        subtotal += item_total
        total_tax += item_tax

    return items, subtotal, total_tax
