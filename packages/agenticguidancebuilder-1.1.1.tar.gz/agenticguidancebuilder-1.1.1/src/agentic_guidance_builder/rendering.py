from importlib import resources
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, StrictUndefined

from agentic_guidance_builder.discovery import GUIDANCE_ROOT
from agentic_guidance_builder.enums import ArtifactKind
from agentic_guidance_builder.models import BuildContext, BuildPlan, RenderedArtifact, RenderedDocument, RenderedScopePackage
from agentic_guidance_builder.planning import sort_documents


class TemplateRenderer:
	def __init__(self, target: Path):
		self.target = target
		self.environment = Environment(
			autoescape=False,
			keep_trailing_newline=True,
			undefined=StrictUndefined,
			loader=FileSystemLoader(self._template_search_paths()),
		)

	def render_document(self, document, context: BuildContext) -> RenderedDocument:
		template = self.environment.from_string(document.body)
		rendered_body = template.render(**self._document_context(document, context))
		return RenderedDocument(source=document, rendered_body=rendered_body)

	def render_agents_md(self, plan: BuildPlan, context: BuildContext) -> RenderedArtifact:
		global_guidance = None
		if plan.global_guidance is not None:
			global_guidance = self.render_document(plan.global_guidance, context)

		language_packages = [self._render_package(package, context) for package in plan.language_packages]
		framework_packages = [self._render_package(package, context) for package in plan.framework_packages]

		project_package = None
		if plan.project_package is not None:
			project_package = self._render_package(plan.project_package, context)

		template = self.environment.get_template('agents.md.j2')
		template.globals.update(
			render_guidance_section=self._render_guidance_section,
			render_package_section=self._render_package_section,
		)
		content = template.render(
			project={'name': context.project_name},
			build={
				'adapter_name': context.adapter_name,
				'output_path': context.output_path.as_posix(),
				'include_examples': context.include_examples,
			},
			selection={
				'languages': context.selected_languages,
				'frameworks': context.selected_frameworks,
			},
			settings=context.settings,
			vars=context.extra_vars,
			global_guidance=global_guidance,
			language_packages=language_packages,
			framework_packages=framework_packages,
			project_package=project_package,
			include_examples=context.include_examples,
		)

		return RenderedArtifact(kind=ArtifactKind.GUIDANCE_OUTPUT, path=context.output_path, content=content)

	def _render_package(self, package, context: BuildContext) -> RenderedScopePackage:
		guidance = None
		if package.guidance is not None:
			guidance = self.render_document(package.guidance, context)

		rendered_examples = [self.render_document(document, context) for document in sort_documents(package.examples)]
		return RenderedScopePackage(
			scope=package.scope,
			name=package.name,
			root=package.root,
			guidance=guidance,
			examples=rendered_examples,
		)

	def _render_guidance_section(self, document: RenderedDocument) -> str:
		template = self.environment.get_template('section.guidance.md.j2')
		return template.render(doc=document)

	def _render_package_section(self, package: RenderedScopePackage, include_examples: bool) -> str:
		sections: list[str] = []
		if package.guidance is not None:
			sections.append(self._render_guidance_section(package.guidance).strip())

		if include_examples and package.examples:
			template = self.environment.get_template('section.examples.md.j2')
			sections.append(template.render(package=package).strip())

		return '\n\n'.join(section for section in sections if section)

	def _template_search_paths(self) -> list[str]:
		project_templates = self.target / GUIDANCE_ROOT / 'templates/base'
		package_templates = resources.files('agentic_guidance_builder.template_data').joinpath('base')
		return [project_templates.as_posix(), str(package_templates)]

	@staticmethod
	def _document_context(document, context: BuildContext) -> dict[str, object]:
		return {
			'project': {'name': context.project_name},
			'build': {
				'adapter_name': context.adapter_name,
				'output_path': context.output_path.as_posix(),
				'include_examples': context.include_examples,
			},
			'selection': {
				'languages': context.selected_languages,
				'frameworks': context.selected_frameworks,
			},
			'settings': context.settings,
			'vars': context.extra_vars,
			'doc': {
				'id': document.id,
				'title': document.title,
				'description': document.description,
				'kind': document.kind,
				'scope': document.scope,
				'name': document.name,
				'path': document.path.as_posix(),
				'tags': document.tags,
				'applies_to': document.applies_to,
			},
		}
