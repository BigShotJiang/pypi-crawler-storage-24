# Oris Python SDK

Compliant payment infrastructure for autonomous AI agents. Oris provides wallets, identity verification (KYA), spending controls, and compliance monitoring designed specifically for AI agents.

## Installation

```bash
pip install oris-sdk
```

For local source installation:

```bash
git clone https://github.com/fluxaventures/useoris.git
cd useoris
pip install -e .
```

## Quick Start

Send your first autonomous, compliant payment in under 10 lines of code.

```python
from oris import OrisClient

# 1. Initialize client
client = OrisClient(api_key="YOUR_API_KEY", api_secret="YOUR_API_SECRET")

# 2. Register and verify agent
agent = client.agents.register(name="Researcher-01", description="Data procurement agent")
client.agents.verify(agent.id)

# 3. Create an ERC-4337 Smart Account
wallet = client.wallets.create(agent_id=agent.id, chain="polygon")

# 4. Set a spending policy
client.policies.create(
    agent_id=agent.id,
    daily_limit_usd=100.0,
    allowed_contracts=["0xDatasetProviderAddress"]
)

# 5. Execute autonomous payment
tx = client.payments.send(
    agent_id=agent.id,
    to_address="0xDatasetProviderAddress",
    amount=1.0,
    chain="polygon",
    token="POL"
)

print(f"Transaction settled. Hash: {tx.transaction_hash}")
```

## Authentication

Oris enforces HMAC-SHA256 request signing with strict replay protection (30s window). The SDK handles all cryptographic signing, envelope encryption, and rate-limit retries automatically.

Provide your credentials directly or via environment variables (`ORIS_API_KEY`, `ORIS_API_SECRET`).

## Agent Lifecycle

The Oris infrastructure requires agents to follow a strict compliance lifecycle before accessing on-chain liquidity:

1. **Registration**: Agent identity is recorded.
2. **KYA (Know Your Agent) Verification**: Agent undergoes AML and risk screening.
3. **Wallet Creation**: Counterfactual deployment of an ERC-4337 smart account.
4. **Policy Attachment**: Hardcoded on-chain and off-chain spending limits.
5. **Execution**: Gas-abstracted, sponsored transaction routing.

## Core Methods Reference

### Agents

```python
client.agents.register(name: str, description: str) -> Agent
client.agents.verify(agent_id: str) -> bool
client.agents.get_profile(agent_id: str) -> AgentProfile
```

### Wallets

```python
client.wallets.create(agent_id: str, chain: str) -> Wallet
client.wallets.get_balance(wallet_id: str) -> Balance
client.wallets.get_wallets(agent_id: str) -> list[Wallet]
```

### Policies

```python
client.policies.create(agent_id: str, **kwargs) -> Policy
client.policies.simulate_payment(agent_id: str, amount: float) -> SimulationResult
```

### Payments

```python
client.payments.send(agent_id: str, to_address: str, amount: float, chain: str, token: str) -> PaymentResult
client.payments.get_payment(payment_id: str) -> PaymentStatus
```

## Async Support

Every synchronous method has an asynchronous counterpart for high-concurrency environments.

```python
import asyncio
from oris import AsyncOrisClient

async def main():
    client = AsyncOrisClient(api_key="...", api_secret="...")
    tx = await client.payments.asend(...)
    print(tx.transaction_hash)

asyncio.run(main())
```

## Error Handling

The SDK provides a structured exception hierarchy.

```python
from oris.exceptions import OrisAuthError, OrisRateLimitError, OrisComplianceError

try:
    client.payments.send(...)
except OrisComplianceError as e:
    print(f"Transaction blocked by Veris compliance engine: {e}")
except OrisRateLimitError as e:
    print(f"Rate limit exceeded. Retry after {e.retry_after}s")
```

## Supported Chains

Oris currently manages RPC routing and bundler infrastructure for the following networks:

| Chain | Identifier | Support Type |
|-------|-----------|--------------|
| Polygon | `polygon` | Native / ERC-4337 |
| Base | `base` | Native / ERC-4337 |
| Ethereum | `ethereum` | Native / ERC-4337 |
| Arbitrum | `arbitrum` | Native / ERC-4337 |
| Optimism | `optimism` | Native / ERC-4337 |
| Avalanche | `avalanche` | Native / ERC-4337 |
| BSC | `bsc` | Native / ERC-4337 |
| Celo | `celo` | Native / ERC-4337 |
