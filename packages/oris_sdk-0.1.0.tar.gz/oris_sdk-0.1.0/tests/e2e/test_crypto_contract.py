"""Cryptographic contract tests: SDK signer vs API verifier.

These tests prove that the HMAC-SHA256 handshake between the Oris SDK
and the Oris API is mathematically correct. No network, no Redis, no
database. Pure cryptographic verification.

The contract:
    SDK side:   signing_key = SHA-256(api_secret)
    API side:   stored_key  = SHA-256(api_secret)  [from DB]
    Both sides: signature   = HMAC-SHA256(key, canonical_string)

    canonical_string = "{timestamp}.{METHOD}.{path}.{SHA-256(body)}"

If SDK and API use the same derivation, the signatures must match
byte-for-byte. If any input differs by a single bit, the signatures
must differ. These tests prove both properties exhaustively.
"""

import hashlib
import hmac
import time


# -----------------------------------------------------------------------
# Inline implementations (no imports from app/ which needs Python 3.12)
# These mirror the exact logic from oris/signer.py and core/oris_auth.py
# -----------------------------------------------------------------------

def sdk_sign(api_secret: str, timestamp: str, method: str, path: str, body: bytes = None) -> str:
    """SDK-side signature computation (mirrors oris.signer.RequestSigner.sign)."""
    signing_key = hashlib.sha256(api_secret.encode()).hexdigest().encode()
    body_hash = hashlib.sha256(body or b"").hexdigest()
    canonical = f"{timestamp}.{method.upper()}.{path}.{body_hash}"
    return hmac.new(signing_key, canonical.encode(), hashlib.sha256).hexdigest()


def api_verify(api_secret_hash: str, provided_sig: str, timestamp: str, method: str, path: str, body: bytes = None) -> bool:
    """API-side signature verification (mirrors core.oris_auth._verify_signature)."""
    body_hash = hashlib.sha256(body or b"").hexdigest()
    canonical = f"{timestamp}.{method.upper()}.{path}.{body_hash}"
    expected = hmac.new(api_secret_hash.encode(), canonical.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, provided_sig)


# -----------------------------------------------------------------------
# Test fixtures
# -----------------------------------------------------------------------

API_SECRET = "oris_ss_live_KjG7mP2xR9vLqW4nTfY8hBcD3eA6sU0iXzO1wN5pJrMtEaCbFdHgIkLmNoQrStUvWxYz"
API_SECRET_HASH = hashlib.sha256(API_SECRET.encode()).hexdigest()
TIMESTAMP = "1710672000"
METHOD = "POST"
PATH = "/api/v1/oris/payments/send"
BODY = b'{"agent_id":"550e8400-e29b-41d4-a716-446655440000","amount":12.50,"stablecoin":"USDC","chain":"base","counterparty_address":"0x742d35Cc6634C0532925a3b844Bc9e7595f2bD28","purpose":"compute_api"}'


# -----------------------------------------------------------------------
# Contract proof: SDK signature == API verification
# -----------------------------------------------------------------------

def test_sdk_api_signature_match():
    """SDK-computed signature must pass API verification."""
    sig = sdk_sign(API_SECRET, TIMESTAMP, METHOD, PATH, BODY)
    assert api_verify(API_SECRET_HASH, sig, TIMESTAMP, METHOD, PATH, BODY), \
        "CRITICAL: SDK signature does not match API verification"


def test_sdk_api_match_empty_body():
    """Contract holds for GET requests (no body)."""
    sig = sdk_sign(API_SECRET, TIMESTAMP, "GET", "/api/v1/oris/agents/123", None)
    assert api_verify(API_SECRET_HASH, sig, TIMESTAMP, "GET", "/api/v1/oris/agents/123", None)


def test_sdk_api_match_empty_bytes_body():
    """Empty bytes body must produce same result as None body."""
    sig_none = sdk_sign(API_SECRET, TIMESTAMP, "GET", "/p", None)
    sig_empty = sdk_sign(API_SECRET, TIMESTAMP, "GET", "/p", b"")
    assert sig_none == sig_empty, "None and b'' must produce identical signatures"
    assert api_verify(API_SECRET_HASH, sig_none, TIMESTAMP, "GET", "/p", b"")


def test_key_derivation_correctness():
    """The signing key is SHA-256(api_secret), matching the stored api_secret_hash."""
    derived_key = hashlib.sha256(API_SECRET.encode()).hexdigest()
    assert derived_key == API_SECRET_HASH, "Key derivation mismatch"

    # Manually compute what both sides should produce.
    body_hash = hashlib.sha256(BODY).hexdigest()
    canonical = f"{TIMESTAMP}.{METHOD}.{PATH}.{body_hash}"

    sdk_result = hmac.new(derived_key.encode(), canonical.encode(), hashlib.sha256).hexdigest()
    api_result = hmac.new(API_SECRET_HASH.encode(), canonical.encode(), hashlib.sha256).hexdigest()

    assert sdk_result == api_result, "Manual computation mismatch"

    # Cross-verify with function implementations.
    sig = sdk_sign(API_SECRET, TIMESTAMP, METHOD, PATH, BODY)
    assert sig == sdk_result, "sdk_sign output differs from manual computation"


# -----------------------------------------------------------------------
# Tamper detection: single-bit changes must invalidate signature
# -----------------------------------------------------------------------

def test_tampered_body_rejected():
    """Changing a single byte in the body must invalidate the signature."""
    sig = sdk_sign(API_SECRET, TIMESTAMP, METHOD, PATH, BODY)
    tampered_body = BODY.replace(b"12.50", b"12.51")
    assert tampered_body != BODY, "Sanity: body must actually differ"
    assert not api_verify(API_SECRET_HASH, sig, TIMESTAMP, METHOD, PATH, tampered_body)


def test_tampered_path_rejected():
    """Changing the path must invalidate the signature."""
    sig = sdk_sign(API_SECRET, TIMESTAMP, METHOD, PATH, BODY)
    assert not api_verify(API_SECRET_HASH, sig, TIMESTAMP, METHOD, "/api/v1/oris/payments/senx", BODY)


def test_tampered_method_rejected():
    """Changing the HTTP method must invalidate the signature."""
    sig = sdk_sign(API_SECRET, TIMESTAMP, METHOD, PATH, BODY)
    assert not api_verify(API_SECRET_HASH, sig, TIMESTAMP, "PATCH", PATH, BODY)


def test_tampered_timestamp_rejected():
    """Changing the timestamp must invalidate the signature."""
    sig = sdk_sign(API_SECRET, TIMESTAMP, METHOD, PATH, BODY)
    assert not api_verify(API_SECRET_HASH, sig, "1710672001", METHOD, PATH, BODY)


def test_tampered_signature_rejected():
    """A single character change in the signature must fail verification."""
    sig = sdk_sign(API_SECRET, TIMESTAMP, METHOD, PATH, BODY)
    # Flip the last hex character.
    last_char = sig[-1]
    flipped = "0" if last_char != "0" else "1"
    tampered_sig = sig[:-1] + flipped
    assert tampered_sig != sig, "Sanity: signature must actually differ"
    assert not api_verify(API_SECRET_HASH, tampered_sig, TIMESTAMP, METHOD, PATH, BODY)


def test_wrong_secret_rejected():
    """Signature from a different api_secret must fail verification."""
    wrong_secret = "oris_ss_live_WRONG_SECRET_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    sig = sdk_sign(wrong_secret, TIMESTAMP, METHOD, PATH, BODY)
    assert not api_verify(API_SECRET_HASH, sig, TIMESTAMP, METHOD, PATH, BODY)


def test_truncated_signature_rejected():
    """A truncated signature must fail verification."""
    sig = sdk_sign(API_SECRET, TIMESTAMP, METHOD, PATH, BODY)
    truncated = sig[:32]  # Half of SHA-256 hex output
    assert not api_verify(API_SECRET_HASH, truncated, TIMESTAMP, METHOD, PATH, BODY)


# -----------------------------------------------------------------------
# Timestamp tolerance
# -----------------------------------------------------------------------

def test_timestamp_within_tolerance():
    """Timestamp within 30 seconds of server time must be accepted."""
    now = int(time.time())
    for offset in [0, 1, 10, 15, 29, 30]:
        ts = str(now - offset)
        assert abs(now - int(ts)) <= 30, f"Offset {offset} should be within tolerance"


def test_timestamp_outside_tolerance():
    """Timestamp older than 30 seconds must be rejected."""
    now = int(time.time())
    for offset in [31, 60, 120, 300]:
        ts = str(now - offset)
        drift = abs(now - int(ts))
        assert drift > 30, f"Offset {offset} should be outside tolerance"


def test_future_timestamp_outside_tolerance():
    """Timestamp more than 30 seconds in the future must be rejected."""
    now = int(time.time())
    ts = str(now + 31)
    drift = abs(now - int(ts))
    assert drift > 30


def test_invalid_timestamp_formats():
    """Non-integer timestamps must be rejected."""
    invalid_timestamps = ["abc", "", "12.34", "2026-03-19", None]
    for ts in invalid_timestamps:
        try:
            int(ts)
            assert False, f"Timestamp '{ts}' should not parse as int"
        except (ValueError, TypeError):
            pass  # Expected: invalid format rejected


# -----------------------------------------------------------------------
# Signature length and format
# -----------------------------------------------------------------------

def test_signature_is_64_hex_chars():
    """HMAC-SHA256 hex digest must be exactly 64 characters."""
    sig = sdk_sign(API_SECRET, TIMESTAMP, METHOD, PATH, BODY)
    assert len(sig) == 64, f"Signature length {len(sig)} != 64"
    assert all(c in "0123456789abcdef" for c in sig), "Signature must be lowercase hex"


def test_method_case_insensitivity():
    """HTTP method must be normalized to uppercase before signing."""
    sig_lower = sdk_sign(API_SECRET, TIMESTAMP, "post", PATH, BODY)
    sig_upper = sdk_sign(API_SECRET, TIMESTAMP, "POST", PATH, BODY)
    sig_mixed = sdk_sign(API_SECRET, TIMESTAMP, "Post", PATH, BODY)
    assert sig_lower == sig_upper == sig_mixed


# -----------------------------------------------------------------------
# Nonce properties (not crypto, but contract-relevant)
# -----------------------------------------------------------------------

def test_nonce_minimum_length():
    """Nonces shorter than 16 characters must be rejected by the API."""
    short_nonces = ["", "a", "1234567890", "123456789012345"]
    for nonce in short_nonces:
        assert len(nonce) < 16, f"Nonce '{nonce}' is not short enough for this test"


def test_nonce_maximum_length():
    """Nonces longer than 128 characters must be rejected by the API."""
    long_nonce = "x" * 129
    assert len(long_nonce) > 128
