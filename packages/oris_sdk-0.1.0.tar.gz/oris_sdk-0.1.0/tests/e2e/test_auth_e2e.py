"""E2E authentication tests: SDK client against a minimal FastAPI test app.

These tests stand up a minimal FastAPI application that mounts the Oris auth
dependency with an in-memory Redis mock. Requests flow through the real HTTP
stack via httpx.ASGITransport (in-process, no TCP sockets needed).

Tested scenarios:
    1. Valid HMAC handshake -> 200
    2. Stale timestamp (31s) -> 401
    3. Replay nonce (same nonce twice) -> 401
    4. Tampered signature -> 401
    5. Tampered body -> 401
    6. Missing headers -> 401
    7. Rate limit exhaustion -> 429
    8. SDK exponential backoff on 429

Requirements: Python 3.10+, httpx, fastapi, pydantic
Run inside Docker environment (CT 103) or with `pip install oris[dev] fastapi`.
"""

import asyncio
import hashlib
import hmac as hmac_mod
import json
import secrets
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

import httpx
import pytest

# ---------------------------------------------------------------------------
# In-memory Redis mock (async interface matching redis.asyncio)
# ---------------------------------------------------------------------------


class FakeRedis:
    """Minimal async Redis mock for auth testing.

    Implements only the methods used by oris_auth.py:
    set (with nx/ex), get, hset, hgetall, expire, eval, delete, pipeline.
    """

    def __init__(self):
        self._data: Dict[str, Any] = {}
        self._expiry: Dict[str, float] = {}

    def _is_expired(self, key: str) -> bool:
        if key in self._expiry and time.time() > self._expiry[key]:
            self._data.pop(key, None)
            self._expiry.pop(key, None)
            return True
        return False

    async def set(self, key: str, value: str, nx: bool = False, ex: Optional[int] = None) -> Optional[bool]:
        self._is_expired(key)
        if nx and key in self._data:
            return False
        self._data[key] = value
        if ex:
            self._expiry[key] = time.time() + ex
        return True

    async def get(self, key: str) -> Optional[str]:
        self._is_expired(key)
        val = self._data.get(key)
        if isinstance(val, dict):
            return None
        return val

    async def hset(self, key: str, mapping: Optional[dict] = None, **kwargs):
        self._is_expired(key)
        if key not in self._data or not isinstance(self._data[key], dict):
            self._data[key] = {}
        if mapping:
            self._data[key].update(mapping)
        self._data[key].update(kwargs)

    async def hgetall(self, key: str) -> dict:
        self._is_expired(key)
        val = self._data.get(key, {})
        if isinstance(val, dict):
            return val
        return {}

    async def expire(self, key: str, seconds: int):
        self._expiry[key] = time.time() + seconds

    async def delete(self, key: str):
        self._data.pop(key, None)
        self._expiry.pop(key, None)

    async def eval(self, script: str, numkeys: int, *args):
        """Minimal Lua token bucket simulation."""
        key = args[0] if args else ""
        limit = int(args[1]) if len(args) > 1 else 10
        window = int(args[2]) if len(args) > 2 else 1

        self._is_expired(key)
        current = self._data.get(key)

        if current is None:
            self._data[key] = str(limit - 1)
            self._expiry[key] = time.time() + window
            return [limit - 1, limit, window]

        remaining = int(current) - 1
        if remaining < 0:
            self._data[key] = str(int(current))
            ttl = max(1, int(self._expiry.get(key, time.time() + 1) - time.time()))
            return [-1, limit, ttl]

        self._data[key] = str(remaining)
        ttl = max(1, int(self._expiry.get(key, time.time() + 1) - time.time()))
        return [remaining, limit, ttl]

    def pipeline(self, transaction=False):
        return FakePipeline(self)


class FakePipeline:
    def __init__(self, redis: FakeRedis):
        self._redis = redis
        self._commands: List[tuple] = []

    def get(self, key):
        self._commands.append(("get", key))
        return self

    def scard(self, key):
        self._commands.append(("scard", key))
        return self

    def incrbyfloat(self, key, amount):
        self._commands.append(("incrbyfloat", key, amount))
        return self

    def incr(self, key):
        self._commands.append(("incr", key))
        return self

    def sadd(self, key, *members):
        self._commands.append(("sadd", key, members))
        return self

    def expire(self, key, seconds):
        self._commands.append(("expire", key, seconds))
        return self

    async def execute(self):
        results = []
        for cmd in self._commands:
            if cmd[0] == "get":
                results.append(await self._redis.get(cmd[1]))
            elif cmd[0] == "scard":
                val = self._redis._data.get(cmd[1], set())
                results.append(len(val) if isinstance(val, set) else 0)
            elif cmd[0] == "incrbyfloat":
                key, amount = cmd[1], cmd[2]
                current = float(self._redis._data.get(key, "0") or "0")
                new_val = current + float(amount)
                self._redis._data[key] = str(new_val)
                results.append(str(new_val))
            elif cmd[0] == "incr":
                key = cmd[1]
                current = int(self._redis._data.get(key, "0") or "0")
                self._redis._data[key] = str(current + 1)
                results.append(current + 1)
            elif cmd[0] == "sadd":
                key = cmd[1]
                if key not in self._redis._data or not isinstance(self._redis._data[key], set):
                    self._redis._data[key] = set()
                self._redis._data[key].update(cmd[2])
                results.append(len(cmd[2]))
            elif cmd[0] == "expire":
                await self._redis.expire(cmd[1], cmd[2])
                results.append(True)
        self._commands.clear()
        return results


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------

API_KEY = "oris_sk_live_testkey_E2E_abcdefghijklmnopqrst"
API_SECRET = "oris_ss_live_testsecret_E2E_abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGH"
API_KEY_HASH = hashlib.sha256(API_KEY.encode()).hexdigest()
API_SECRET_HASH = hashlib.sha256(API_SECRET.encode()).hexdigest()
API_KEY_PREFIX = API_KEY[:12]

TENANT_ID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
DEVELOPER_ID = "11111111-2222-3333-4444-555555555555"


def _sign_request(method: str, path: str, body: Optional[bytes] = None,
                  timestamp: Optional[int] = None, nonce: Optional[str] = None,
                  secret: str = API_SECRET) -> Dict[str, str]:
    """Produce auth headers identical to SDK signer output."""
    ts = str(timestamp or int(time.time()))
    nc = nonce or secrets.token_urlsafe(24)
    signing_key = hashlib.sha256(secret.encode()).hexdigest()
    body_hash = hashlib.sha256(body or b"").hexdigest()
    canonical = f"{ts}.{method.upper()}.{path}.{body_hash}"
    signature = hmac_mod.new(signing_key.encode(), canonical.encode(), hashlib.sha256).hexdigest()
    return {
        "Authorization": API_KEY,
        "X-Request-Signature": signature,
        "X-Timestamp": ts,
        "X-Nonce": nc,
    }


def _build_test_app(fake_redis: FakeRedis):
    """Build a minimal FastAPI app with Oris auth dependency for testing.

    Seeds the FakeRedis with a cached developer record so auth lookups
    succeed without a real database.
    """
    from fastapi import Depends, FastAPI, Request
    from fastapi.responses import JSONResponse

    app = FastAPI()

    # Seed developer cache in FakeRedis.
    cache_key = f"oris:dev:{API_KEY_PREFIX}"
    fake_redis._data[cache_key] = {
        "id": DEVELOPER_ID,
        "tenant_id": TENANT_ID,
        "api_key_hash": API_KEY_HASH,
        "api_secret_hash": API_SECRET_HASH,
        "kyb_status": "verified",
        "risk_tier": "standard",
        "rate_limit_per_minute": "60",
    }

    # Inject FakeRedis as app.state.redis.
    app.state.redis = fake_redis

    # --- Auth dependency (inlined to avoid full app imports) ---

    async def test_auth(request: Request) -> dict:
        """Mirrors core.oris_auth.authenticate_oris_request logic."""
        redis = request.app.state.redis

        auth_header = request.headers.get("authorization", "")
        if not auth_header.startswith("oris_sk_live_"):
            raise _auth_error()

        ts = request.headers.get("x-timestamp")
        nonce = request.headers.get("x-nonce")
        sig = request.headers.get("x-request-signature")

        if not ts or not nonce or not sig:
            raise _auth_error()

        # Timestamp validation (30s tolerance).
        try:
            req_time = int(ts)
        except (ValueError, TypeError):
            raise _auth_error()
        if abs(int(time.time()) - req_time) > 30:
            raise _auth_error()

        # Nonce validation (SETNX).
        nonce_key = f"oris:nonce:{nonce}"
        was_set = await redis.set(nonce_key, "1", nx=True, ex=30)
        if not was_set:
            raise _auth_error()

        # Developer lookup from cache.
        prefix = auth_header[:12]
        dev_data = await redis.hgetall(f"oris:dev:{prefix}")
        if not dev_data:
            raise _auth_error()

        key_hash = hashlib.sha256(auth_header.encode()).hexdigest()
        if not hmac_mod.compare_digest(dev_data.get("api_key_hash", ""), key_hash):
            raise _auth_error()

        # HMAC verification.
        body = await request.body()
        path = request.url.path
        stored_secret_hash = dev_data.get("api_secret_hash", "")
        body_hash = hashlib.sha256(body or b"").hexdigest()
        canonical = f"{ts}.{request.method.upper()}.{path}.{body_hash}"
        expected = hmac_mod.new(stored_secret_hash.encode(), canonical.encode(), hashlib.sha256).hexdigest()
        if not hmac_mod.compare_digest(expected, sig):
            raise _auth_error()

        # Rate limit.
        rate_limit = int(dev_data.get("rate_limit_per_minute", "60"))
        per_second = max(1, rate_limit // 60)
        rl_key = f"rate_limit:oris:{dev_data['id']}"
        rl_result = await redis.eval("", 1, rl_key, per_second, 1, int(time.time()))
        remaining = int(rl_result[0])
        if remaining < 0:
            from fastapi import HTTPException
            raise HTTPException(
                status_code=429,
                detail="Rate limit exceeded.",
                headers={"Retry-After": str(rl_result[2])},
            )

        return {
            "developer_id": dev_data["id"],
            "tenant_id": dev_data["tenant_id"],
        }

    def _auth_error():
        from fastapi import HTTPException
        return HTTPException(status_code=401, detail="Authentication failed.")

    @app.get("/api/v1/oris/test")
    async def test_endpoint(request: Request):
        ctx = await test_auth(request)
        return {"status": "ok", "developer_id": ctx["developer_id"]}

    @app.post("/api/v1/oris/test")
    async def test_post_endpoint(request: Request):
        ctx = await test_auth(request)
        body = await request.body()
        return {"status": "ok", "received_bytes": len(body)}

    return app


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.fixture
def fake_redis():
    return FakeRedis()


@pytest.fixture
def app(fake_redis):
    return _build_test_app(fake_redis)


@pytest.fixture
def client(app):
    transport = httpx.ASGITransport(app=app)
    return httpx.AsyncClient(transport=transport, base_url="http://testserver")


# --- 1. Valid handshake ---

@pytest.mark.asyncio
async def test_valid_hmac_handshake(client):
    """Valid HMAC signature must return 200."""
    headers = _sign_request("GET", "/api/v1/oris/test")
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
    data = resp.json()
    assert data["developer_id"] == DEVELOPER_ID


@pytest.mark.asyncio
async def test_valid_post_with_body(client):
    """Valid HMAC with POST body must return 200."""
    body = b'{"agent_id":"test-123","amount":50.0}'
    headers = _sign_request("POST", "/api/v1/oris/test", body=body)
    resp = await client.post("/api/v1/oris/test", content=body, headers=headers)
    assert resp.status_code == 200
    assert resp.json()["received_bytes"] == len(body)


# --- 2. Stale timestamp ---

@pytest.mark.asyncio
async def test_stale_timestamp_31s_rejected(client):
    """Timestamp 31 seconds old must be rejected with 401."""
    stale_ts = int(time.time()) - 31
    headers = _sign_request("GET", "/api/v1/oris/test", timestamp=stale_ts)
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401, f"31s stale timestamp should be rejected, got {resp.status_code}"


@pytest.mark.asyncio
async def test_stale_timestamp_60s_rejected(client):
    """Timestamp 60 seconds old must be rejected with 401."""
    stale_ts = int(time.time()) - 60
    headers = _sign_request("GET", "/api/v1/oris/test", timestamp=stale_ts)
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_future_timestamp_31s_rejected(client):
    """Timestamp 31 seconds in the future must be rejected."""
    future_ts = int(time.time()) + 31
    headers = _sign_request("GET", "/api/v1/oris/test", timestamp=future_ts)
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_timestamp_at_boundary_30s_accepted(client):
    """Timestamp exactly 30 seconds old must be accepted."""
    boundary_ts = int(time.time()) - 30
    headers = _sign_request("GET", "/api/v1/oris/test", timestamp=boundary_ts)
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 200, f"30s boundary should be accepted, got {resp.status_code}"


# --- 3. Replay nonce ---

@pytest.mark.asyncio
async def test_replay_nonce_rejected(client):
    """Same nonce used twice within 30s window must be rejected."""
    fixed_nonce = "replay_test_nonce_1234567890abcdef"

    headers1 = _sign_request("GET", "/api/v1/oris/test", nonce=fixed_nonce)
    resp1 = await client.get("/api/v1/oris/test", headers=headers1)
    assert resp1.status_code == 200, f"First request should succeed, got {resp1.status_code}"

    headers2 = _sign_request("GET", "/api/v1/oris/test", nonce=fixed_nonce)
    resp2 = await client.get("/api/v1/oris/test", headers=headers2)
    assert resp2.status_code == 401, f"Replayed nonce should be rejected, got {resp2.status_code}"


@pytest.mark.asyncio
async def test_different_nonces_both_accepted():
    """Two requests with different nonces must both succeed.

    Uses a dedicated FakeRedis with high rate limit to avoid
    rate limit interference between the two requests.
    """
    fr = FakeRedis()
    test_app = _build_test_app(fr)
    # Override rate limit to allow multiple requests per second.
    cache_key = f"oris:dev:{API_KEY_PREFIX}"
    fr._data[cache_key]["rate_limit_per_minute"] = "6000"

    transport = httpx.ASGITransport(app=test_app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as c:
        headers1 = _sign_request("GET", "/api/v1/oris/test", nonce="unique_nonce_aaaaaaaaaaaaaaa1")
        resp1 = await c.get("/api/v1/oris/test", headers=headers1)
        assert resp1.status_code == 200

        headers2 = _sign_request("GET", "/api/v1/oris/test", nonce="unique_nonce_bbbbbbbbbbbbbbb2")
        resp2 = await c.get("/api/v1/oris/test", headers=headers2)
        assert resp2.status_code == 200


# --- 4. Tampered signature ---

@pytest.mark.asyncio
async def test_tampered_signature_rejected(client):
    """Flipping a single character in the signature must return 401."""
    headers = _sign_request("GET", "/api/v1/oris/test")
    sig = headers["X-Request-Signature"]
    last = sig[-1]
    flipped = "0" if last != "0" else "1"
    headers["X-Request-Signature"] = sig[:-1] + flipped
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_empty_signature_rejected(client):
    """Empty signature must return 401."""
    headers = _sign_request("GET", "/api/v1/oris/test")
    headers["X-Request-Signature"] = ""
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_wrong_secret_signature_rejected(client):
    """Signature computed with wrong api_secret must return 401."""
    wrong_secret = "oris_ss_live_WRONG_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    headers = _sign_request("GET", "/api/v1/oris/test", secret=wrong_secret)
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401


# --- 5. Tampered body ---

@pytest.mark.asyncio
async def test_tampered_body_rejected(client):
    """Sending a different body than what was signed must return 401."""
    original_body = b'{"amount":100}'
    headers = _sign_request("POST", "/api/v1/oris/test", body=original_body)
    tampered_body = b'{"amount":999}'
    resp = await client.post("/api/v1/oris/test", content=tampered_body, headers=headers)
    assert resp.status_code == 401


# --- 6. Missing headers ---

@pytest.mark.asyncio
async def test_missing_authorization_rejected(client):
    """Missing Authorization header must return 401."""
    headers = _sign_request("GET", "/api/v1/oris/test")
    del headers["Authorization"]
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_missing_timestamp_rejected(client):
    """Missing X-Timestamp header must return 401."""
    headers = _sign_request("GET", "/api/v1/oris/test")
    del headers["X-Timestamp"]
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_missing_nonce_rejected(client):
    """Missing X-Nonce header must return 401."""
    headers = _sign_request("GET", "/api/v1/oris/test")
    del headers["X-Nonce"]
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_missing_signature_rejected(client):
    """Missing X-Request-Signature header must return 401."""
    headers = _sign_request("GET", "/api/v1/oris/test")
    del headers["X-Request-Signature"]
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401


# --- 7. Rate limit exhaustion ---

@pytest.mark.asyncio
async def test_rate_limit_exhaustion(client):
    """Exceeding rate limit must return 429 with Retry-After header."""
    # Developer rate_limit_per_minute = 60, so per_second = 1.
    # First request consumes the single token.
    headers1 = _sign_request("GET", "/api/v1/oris/test")
    resp1 = await client.get("/api/v1/oris/test", headers=headers1)
    assert resp1.status_code == 200

    # Second request in same second should be rate-limited.
    headers2 = _sign_request("GET", "/api/v1/oris/test")
    resp2 = await client.get("/api/v1/oris/test", headers=headers2)
    assert resp2.status_code == 429, f"Expected 429, got {resp2.status_code}"
    assert "retry-after" in resp2.headers, "429 response must include Retry-After header"


# --- 8. Wrong API key format ---

@pytest.mark.asyncio
async def test_wrong_api_key_prefix_rejected(client):
    """API key with wrong prefix must return 401."""
    headers = _sign_request("GET", "/api/v1/oris/test")
    headers["Authorization"] = "vrs_live_wrong_prefix_key"
    resp = await client.get("/api/v1/oris/test", headers=headers)
    assert resp.status_code == 401
