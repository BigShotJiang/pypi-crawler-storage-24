"""Deterministic tests for the HMAC-SHA256 request signer.

These tests verify:
    1. Signature determinism (same input -> same output)
    2. Signing key derivation (SHA-256 of api_secret)
    3. Canonical string construction
    4. Signature changes when any input parameter changes
    5. Nonce generation produces sufficient entropy
"""

import hashlib
import hmac

from oris.signer import RequestSigner


API_SECRET = "oris_ss_live_test_secret_for_unit_tests_only_abc123"
DERIVED_KEY = hashlib.sha256(API_SECRET.encode()).hexdigest()


def test_signature_determinism():
    """Same inputs must produce the same signature."""
    signer = RequestSigner(API_SECRET)
    sig1, _, _ = signer.sign("POST", "/api/v1/oris/payments/send", b'{"amount":10}', timestamp=1710672000, nonce="fixed-nonce-1234567890123456")
    sig2, _, _ = signer.sign("POST", "/api/v1/oris/payments/send", b'{"amount":10}', timestamp=1710672000, nonce="fixed-nonce-1234567890123456")
    assert sig1 == sig2


def test_signing_key_derivation():
    """The signing key must be SHA-256(api_secret)."""
    signer = RequestSigner(API_SECRET)
    # Manually compute what the signer should produce.
    body = b'{"test":true}'
    body_hash = hashlib.sha256(body).hexdigest()
    canonical = f"1710672000.POST./api/v1/test.{body_hash}"
    expected = hmac.new(DERIVED_KEY.encode(), canonical.encode(), hashlib.sha256).hexdigest()

    sig, _, _ = signer.sign("POST", "/api/v1/test", body, timestamp=1710672000, nonce="n")
    assert sig == expected


def test_canonical_string_method_uppercase():
    """HTTP method must be uppercased in the canonical string."""
    signer = RequestSigner(API_SECRET)
    sig_lower, _, _ = signer.sign("post", "/path", None, timestamp=100, nonce="n")
    sig_upper, _, _ = signer.sign("POST", "/path", None, timestamp=100, nonce="n")
    assert sig_lower == sig_upper


def test_empty_body_uses_empty_hash():
    """None body and empty bytes body must produce the same signature."""
    signer = RequestSigner(API_SECRET)
    sig_none, _, _ = signer.sign("GET", "/path", None, timestamp=100, nonce="n")
    sig_empty, _, _ = signer.sign("GET", "/path", b"", timestamp=100, nonce="n")
    assert sig_none == sig_empty


def test_signature_changes_with_different_body():
    """Different body must produce different signature."""
    signer = RequestSigner(API_SECRET)
    sig1, _, _ = signer.sign("POST", "/path", b'{"a":1}', timestamp=100, nonce="n")
    sig2, _, _ = signer.sign("POST", "/path", b'{"a":2}', timestamp=100, nonce="n")
    assert sig1 != sig2


def test_signature_changes_with_different_path():
    """Different path must produce different signature."""
    signer = RequestSigner(API_SECRET)
    sig1, _, _ = signer.sign("GET", "/path/a", None, timestamp=100, nonce="n")
    sig2, _, _ = signer.sign("GET", "/path/b", None, timestamp=100, nonce="n")
    assert sig1 != sig2


def test_signature_changes_with_different_timestamp():
    """Different timestamp must produce different signature."""
    signer = RequestSigner(API_SECRET)
    sig1, _, _ = signer.sign("GET", "/path", None, timestamp=100, nonce="n")
    sig2, _, _ = signer.sign("GET", "/path", None, timestamp=200, nonce="n")
    assert sig1 != sig2


def test_signature_changes_with_different_method():
    """Different HTTP method must produce different signature."""
    signer = RequestSigner(API_SECRET)
    sig1, _, _ = signer.sign("GET", "/path", None, timestamp=100, nonce="n")
    sig2, _, _ = signer.sign("DELETE", "/path", None, timestamp=100, nonce="n")
    assert sig1 != sig2


def test_nonce_generation_entropy():
    """Auto-generated nonces must be unique and sufficiently long."""
    signer = RequestSigner(API_SECRET)
    nonces = set()
    for _ in range(100):
        _, _, nonce = signer.sign("GET", "/path")
        assert len(nonce) >= 16, "Nonce must be at least 16 characters"
        nonces.add(nonce)
    assert len(nonces) == 100, "All 100 nonces must be unique"


def test_different_secrets_produce_different_signatures():
    """Two signers with different secrets must produce different signatures."""
    signer1 = RequestSigner("oris_ss_live_secret_one_aaaaaaaaaa")
    signer2 = RequestSigner("oris_ss_live_secret_two_bbbbbbbbbb")
    sig1, _, _ = signer1.sign("GET", "/path", None, timestamp=100, nonce="n")
    sig2, _, _ = signer2.sign("GET", "/path", None, timestamp=100, nonce="n")
    assert sig1 != sig2
