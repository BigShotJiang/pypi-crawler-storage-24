"""HMAC-SHA256 request signer for Oris API authentication.

The signer computes a deterministic signature for every outgoing request
using the canonical request format defined by the Oris API:

    canonical = "{timestamp}.{METHOD}.{path}.{SHA-256(body)}"
    signing_key = SHA-256(api_secret)
    signature = HMAC-SHA256(signing_key, canonical)

The signing key is derived once at initialization as SHA-256(api_secret)
and held in memory. The raw api_secret is discarded after derivation.
This matches the server-side verification which stores only the
SHA-256(api_secret) hash.

Security properties:
    - Raw api_secret never leaves the constructor
    - Signing key is the SHA-256 derived hash (matches server-side)
    - Nonces are 24-byte URL-safe random tokens (192 bits of entropy)
    - Timestamps use integer Unix epoch (no fractional seconds)
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
import time


class RequestSigner:
    """Stateless HMAC-SHA256 request signer.

    Initialized once with the api_secret. The derived signing key is
    held in memory for the lifetime of the signer instance. Thread-safe
    and async-safe (no mutable state after initialization).
    """

    __slots__ = ("_signing_key",)

    def __init__(self, api_secret: str) -> None:
        """Derive the signing key from the api_secret and discard the raw secret."""
        self._signing_key: bytes = hashlib.sha256(api_secret.encode()).hexdigest().encode()

    def sign(
        self,
        method: str,
        path: str,
        body: bytes | None = None,
        timestamp: int | None = None,
        nonce: str | None = None,
    ) -> tuple[str, str, str]:
        """Compute the request signature and generate timestamp/nonce.

        Returns:
            (signature, timestamp_str, nonce_str)

        The caller must attach these as headers:
            X-Request-Signature: {signature}
            X-Timestamp: {timestamp_str}
            X-Nonce: {nonce_str}
        """
        ts = str(timestamp or int(time.time()))
        nc = nonce or secrets.token_urlsafe(24)

        body_hash = hashlib.sha256(body or b"").hexdigest()
        canonical = f"{ts}.{method.upper()}.{path}.{body_hash}"

        signature = hmac.new(
            self._signing_key,
            canonical.encode(),
            hashlib.sha256,
        ).hexdigest()

        return signature, ts, nc
