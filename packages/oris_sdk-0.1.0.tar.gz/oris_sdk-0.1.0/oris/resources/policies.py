"""Policies resource: spending controls and dry-run evaluation."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from oris.types import Policy, PolicyList, PolicyEvaluation

if TYPE_CHECKING:
    from oris.client import OrisClient


class PoliciesResource:
    """Manage spending policies for AI agents.

    Policies enforce transaction limits, counterparty restrictions, and
    compliance rules. Evaluation is Redis-cached for sub-10ms latency.

    Usage:
        policy = client.policies.create(agent_id="...", daily_limit_usd=100.0)
        result = client.policies.simulate_payment(agent_id="...", amount=50.0)
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def acreate(
        self,
        agent_id: str,
        policy_name: str = "default",
        daily_limit_usd: float | None = None,
        weekly_limit_usd: float | None = None,
        monthly_limit_usd: float | None = None,
        per_tx_limit_usd: float | None = None,
        allowed_contracts: list[str] | None = None,
        blocked_contracts: list[str] | None = None,
        enforcement_mode: str = "enforce",
    ) -> Policy:
        """Create a spending policy for an agent.

        Args:
            agent_id: Agent to attach policy to.
            policy_name: Human-readable policy name.
            daily_limit_usd: Maximum daily spend in USD.
            weekly_limit_usd: Maximum weekly spend in USD.
            monthly_limit_usd: Maximum monthly spend in USD.
            per_tx_limit_usd: Maximum single transaction in USD.
            allowed_contracts: Counterparty whitelist (addresses).
            blocked_contracts: Counterparty blacklist (addresses).
            enforcement_mode: "enforce" (block), "warn" (log), or "audit_only".
        """
        rules: dict[str, Any] = {}
        if per_tx_limit_usd is not None:
            rules["max_per_transaction"] = per_tx_limit_usd
        if daily_limit_usd is not None:
            rules["max_daily"] = daily_limit_usd
        if weekly_limit_usd is not None:
            rules["max_weekly"] = weekly_limit_usd
        if monthly_limit_usd is not None:
            rules["max_monthly"] = monthly_limit_usd
        if allowed_contracts is not None:
            rules["counterparty_whitelist"] = allowed_contracts
        if blocked_contracts is not None:
            rules["counterparty_blacklist"] = blocked_contracts

        data = await self._client.post("/oris/policies", json={
            "agent_id": agent_id,
            "policy_name": policy_name,
            "rules": rules,
            "enforcement_mode": enforcement_mode,
        })
        return Policy.from_dict(data)

    def create(self, **kwargs) -> Policy:
        """Create a spending policy (sync)."""
        return self._client._run_sync(self.acreate(**kwargs))

    async def alist(self, agent_id: str) -> PolicyList:
        """List all active policies for an agent."""
        data = await self._client.get(f"/oris/policies/agent/{agent_id}")
        return PolicyList.from_dict(data)

    def list(self, agent_id: str) -> PolicyList:
        """List all policies (sync)."""
        return self._client._run_sync(self.alist(agent_id))

    async def aupdate(self, policy_id: str, **kwargs) -> Policy:
        """Update a policy's rules or settings."""
        data = await self._client.patch(f"/oris/policies/{policy_id}", json=kwargs)
        return Policy.from_dict(data)

    def update(self, policy_id: str, **kwargs) -> Policy:
        """Update a policy (sync)."""
        return self._client._run_sync(self.aupdate(policy_id, **kwargs))

    async def adelete(self, policy_id: str) -> dict[str, Any]:
        """Delete a policy."""
        return await self._client.delete(f"/oris/policies/{policy_id}")

    def delete(self, policy_id: str) -> dict[str, Any]:
        """Delete a policy (sync)."""
        return self._client._run_sync(self.adelete(policy_id))

    async def asimulate_payment(
        self,
        agent_id: str,
        amount: float,
        stablecoin: str = "USDC",
        chain: str = "base",
        counterparty_address: str | None = None,
    ) -> PolicyEvaluation:
        """Dry-run policy evaluation without executing a payment.

        Returns whether the transaction would pass all active policies.
        """
        data = await self._client.post("/oris/policies/evaluate", json={
            "agent_id": agent_id,
            "amount": amount,
            "stablecoin": stablecoin,
            "chain": chain,
            "counterparty_address": counterparty_address,
        })
        return PolicyEvaluation.from_dict(data)

    def simulate_payment(self, **kwargs) -> PolicyEvaluation:
        """Dry-run policy evaluation (sync)."""
        return self._client._run_sync(self.asimulate_payment(**kwargs))
