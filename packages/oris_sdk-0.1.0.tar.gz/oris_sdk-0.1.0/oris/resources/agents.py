"""Agents resource: registration, verification, and profile management."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from oris.types import Agent, AgentRegisterResponse, AgentKyaTransition

if TYPE_CHECKING:
    from oris.client import OrisClient


class AgentsResource:
    """Manage AI agent identities on the Oris platform.

    Usage:
        agent = client.agents.register(name="Researcher-01", description="Data procurement")
        client.agents.verify(agent.id)
        profile = client.agents.get_profile(agent.id)
    """

    def __init__(self, client: OrisClient) -> None:
        self._client = client

    async def aregister(
        self,
        name: str,
        description: str = "",
        platform: str = "custom",
        agent_type: str = "autonomous",
        capabilities: list[str] | None = None,
        operating_chains: list[str] | None = None,
    ) -> AgentRegisterResponse:
        """Register a new agent on the Oris platform.

        The agent starts in PENDING KYA status. Call verify() to activate.
        """
        data = await self._client.post("/oris/agents/register", json={
            "external_agent_id": name,
            "agent_name": name,
            "agent_description": description,
            "platform": platform,
            "agent_type": agent_type,
            "declared_capabilities": capabilities or [],
            "operating_chains": operating_chains or ["base"],
        })
        return AgentRegisterResponse.from_dict(data)

    def register(self, **kwargs) -> AgentRegisterResponse:
        """Register a new agent (sync)."""
        return self._client._run_sync(self.aregister(**kwargs))

    async def averify(self, agent_id: str) -> AgentKyaTransition:
        """Verify an agent (transition PENDING to VERIFIED)."""
        data = await self._client.post(
            f"/oris/agents/{agent_id}/kya",
            json={"action": "verify"},
        )
        return AgentKyaTransition.from_dict(data)

    def verify(self, agent_id: str) -> AgentKyaTransition:
        """Verify an agent (sync)."""
        return self._client._run_sync(self.averify(agent_id))

    async def aget_profile(self, agent_id: str) -> Agent:
        """Get an agent's profile and KYA status."""
        data = await self._client.get(f"/oris/agents/{agent_id}")
        return Agent.from_dict(data)

    def get_profile(self, agent_id: str) -> Agent:
        """Get an agent's profile (sync)."""
        return self._client._run_sync(self.aget_profile(agent_id))

    async def aupdate(
        self,
        agent_id: str,
        name: str | None = None,
        description: str | None = None,
        capabilities: list[str] | None = None,
        operating_chains: list[str] | None = None,
    ) -> Agent:
        """Update an agent's profile."""
        body: dict[str, Any] = {}
        if name is not None:
            body["agent_name"] = name
        if description is not None:
            body["agent_description"] = description
        if capabilities is not None:
            body["declared_capabilities"] = capabilities
        if operating_chains is not None:
            body["operating_chains"] = operating_chains
        data = await self._client.patch(f"/oris/agents/{agent_id}", json=body)
        return Agent.from_dict(data)

    def update(self, agent_id: str, **kwargs) -> Agent:
        """Update an agent's profile (sync)."""
        return self._client._run_sync(self.aupdate(agent_id, **kwargs))

    async def asuspend(self, agent_id: str, reason: str) -> AgentKyaTransition:
        """Suspend an agent's transaction privileges."""
        data = await self._client.post(
            f"/oris/agents/{agent_id}/kya",
            json={"action": "suspend", "reason": reason},
        )
        return AgentKyaTransition.from_dict(data)

    def suspend(self, agent_id: str, reason: str) -> AgentKyaTransition:
        """Suspend an agent (sync)."""
        return self._client._run_sync(self.asuspend(agent_id, reason))
