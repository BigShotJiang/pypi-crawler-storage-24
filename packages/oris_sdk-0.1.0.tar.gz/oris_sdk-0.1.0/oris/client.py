"""Oris base HTTP client: async-first, HMAC-signed, resilient.

The OrisClient is the transport layer for all SDK operations. It handles:

    1. Automatic HMAC-SHA256 signing of every request
    2. Nonce and timestamp injection for replay protection
    3. Idempotency-Key generation for mutating requests
    4. Exponential backoff with jitter for transient failures
    5. Structured error mapping to typed exceptions
    6. Connection pooling via httpx.AsyncClient

All public methods are async. For synchronous usage, the Agent class
provides sync wrappers using a managed event loop.

Retry policy:
    - Retryable status codes: 429 (rate limit), 502, 503, 504 (server error)
    - Max retries: 3 (configurable)
    - Backoff: 2^attempt * base_delay + random jitter (0-500ms)
    - Rate limit 429: respects Retry-After header
    - Non-retryable errors (4xx except 429): raised immediately
    - Network errors (connection, timeout): retried with backoff
"""

from __future__ import annotations

import asyncio
import random
import uuid
from typing import Any
from urllib.parse import urljoin

import httpx

from oris._version import __version__
from oris.exceptions import (
    OrisAuthError,
    OrisError,
    OrisNetworkError,
    OrisPaymentError,
    OrisRateLimitError,
    OrisValidationError,
)
from oris.signer import RequestSigner

# Status codes that trigger automatic retry with backoff.
_RETRYABLE_STATUS = {429, 502, 503, 504}

# Default configuration.
_DEFAULT_BASE_URL = "https://api.useoris.finance"
_DEFAULT_TIMEOUT = 30.0  # seconds
_DEFAULT_MAX_RETRIES = 3
_DEFAULT_BASE_DELAY = 0.5  # seconds
_MAX_BACKOFF = 30.0  # seconds

# Payment-specific error codes that map to OrisPaymentError.
_PAYMENT_ERROR_CODES = {
    "POLICY_VIOLATED",
    "PAYMENT_REJECTED",
    "PAYMENT_COMPLIANCE_BLOCKED",
    "PAYMENT_ESCALATED",
    "WALLET_INSUFFICIENT_BALANCE",
    "WALLET_FROZEN",
    "WALLET_NOT_FOUND",
}


class OrisClient:
    """Oris API client with Stripe-style resource access.

    Usage (resource-based):
        client = OrisClient(api_key="...", api_secret="...")
        agent = client.agents.register(name="Researcher-01", description="...")
        client.agents.verify(agent["id"])
        wallet = client.wallets.create(agent_id=agent["id"], chain="polygon")
        tx = client.payments.send(agent_id=agent["id"], to_address="0x...", amount=10.0)

    Usage (low-level):
        async with OrisClient(api_key="...", api_secret="...") as client:
            result = await client.post("/oris/agents/register", json={...})
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        agent_id: str | None = None,
    ) -> None:
        if not api_key or not api_key.startswith("oris_sk_live_"):
            raise ValueError("api_key must start with 'oris_sk_live_'")
        if not api_secret or not api_secret.startswith("oris_ss_live_"):
            raise ValueError("api_secret must start with 'oris_ss_live_'")

        self._api_key = api_key
        self._signer = RequestSigner(api_secret)
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._agent_id = agent_id

        self._http: httpx.AsyncClient | None = None

        # Resource sub-objects (Stripe-style API surface).
        from oris.resources import AgentsResource, WalletsResource, PoliciesResource, PaymentsResource
        self.agents = AgentsResource(self)
        self.wallets = WalletsResource(self)
        self.policies = PoliciesResource(self)
        self.payments = PaymentsResource(self)

    def _run_sync(self, coro) -> Any:
        """Run an async coroutine synchronously for resource sub-objects."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(asyncio.run, coro).result()
        return asyncio.run(coro)

    async def _ensure_client(self) -> httpx.AsyncClient:
        """Lazily initialize the httpx.AsyncClient with connection pooling."""
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=httpx.Timeout(self._timeout),
                limits=httpx.Limits(
                    max_connections=50,
                    max_keepalive_connections=10,
                    keepalive_expiry=30,
                ),
                headers={
                    "User-Agent": f"oris-python/{__version__}",
                    "Accept": "application/json",
                },
            )
        return self._http

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        if self._http and not self._http.is_closed:
            await self._http.aclose()
            self._http = None

    async def __aenter__(self) -> "OrisClient":
        await self._ensure_client()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    # -------------------------------------------------------------------
    # Core request method
    # -------------------------------------------------------------------

    async def request(
        self,
        method: str,
        path: str,
        json: dict | None = None,
        params: dict | None = None,
        idempotent: bool | None = None,
    ) -> dict[str, Any]:
        """Execute an authenticated API request with retry logic.

        Args:
            method: HTTP method (GET, POST, PATCH, DELETE).
            path: API path (e.g. "/oris/agents/register").
            json: Request body (serialized to JSON).
            params: Query parameters.
            idempotent: Force idempotency key injection. Auto-detected
                        for POST and PATCH if not specified.

        Returns:
            Parsed JSON response body.

        Raises:
            OrisAuthError: 401 or 403 response.
            OrisRateLimitError: 429 response (after exhausting retries).
            OrisValidationError: 400 or 422 response.
            OrisPaymentError: Payment-specific failures.
            OrisNetworkError: Connection or timeout failures.
            OrisError: Any other API error.
        """
        client = await self._ensure_client()
        full_path = f"/api/v1{path}" if not path.startswith("/api/") else path

        # Serialize body.
        body_bytes: bytes | None = None
        if json is not None:
            import json as _json
            body_bytes = _json.dumps(json, default=str).encode()

        # Determine idempotency.
        needs_idempotency = idempotent if idempotent is not None else method.upper() in ("POST", "PATCH")

        last_error: Exception | None = None

        for attempt in range(self._max_retries + 1):
            # Sign the request (fresh timestamp and nonce per attempt).
            signature, timestamp, nonce = self._signer.sign(
                method=method.upper(),
                path=full_path,
                body=body_bytes,
            )

            headers: dict[str, str] = {
                "Authorization": self._api_key,
                "X-Request-Signature": signature,
                "X-Timestamp": timestamp,
                "X-Nonce": nonce,
            }

            if self._agent_id:
                headers["X-Agent-ID"] = self._agent_id

            if needs_idempotency:
                headers["Idempotency-Key"] = str(uuid.uuid4())

            try:
                response = await client.request(
                    method=method.upper(),
                    url=full_path,
                    content=body_bytes,
                    params=params,
                    headers=headers,
                )

                # Success: parse and return.
                if response.status_code < 400:
                    if response.status_code == 204:
                        return {}
                    return response.json()

                # Non-retryable client error (except 429).
                if response.status_code not in _RETRYABLE_STATUS:
                    self._raise_for_status(response)

                # Retryable error: back off and retry.
                last_error = self._build_exception(response)

                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", "1"))
                    await asyncio.sleep(retry_after)
                else:
                    delay = self._backoff_delay(attempt)
                    await asyncio.sleep(delay)

            except httpx.TimeoutException as exc:
                last_error = OrisNetworkError(
                    f"Request timed out after {self._timeout}s",
                    details={"path": full_path, "attempt": attempt},
                )
                if attempt < self._max_retries:
                    await asyncio.sleep(self._backoff_delay(attempt))
                    continue
                raise last_error from exc

            except httpx.ConnectError as exc:
                last_error = OrisNetworkError(
                    f"Connection failed to {self._base_url}",
                    details={"path": full_path, "attempt": attempt},
                )
                if attempt < self._max_retries:
                    await asyncio.sleep(self._backoff_delay(attempt))
                    continue
                raise last_error from exc

            except httpx.HTTPError as exc:
                last_error = OrisNetworkError(
                    str(exc),
                    details={"path": full_path, "attempt": attempt},
                )
                if attempt < self._max_retries:
                    await asyncio.sleep(self._backoff_delay(attempt))
                    continue
                raise last_error from exc

        # Exhausted retries.
        if last_error:
            raise last_error
        raise OrisError("Request failed after all retries.")

    # -------------------------------------------------------------------
    # Convenience methods
    # -------------------------------------------------------------------

    async def get(self, path: str, params: dict | None = None) -> dict:
        return await self.request("GET", path, params=params)

    async def post(self, path: str, json: dict | None = None) -> dict:
        return await self.request("POST", path, json=json)

    async def patch(self, path: str, json: dict | None = None) -> dict:
        return await self.request("PATCH", path, json=json)

    async def delete(self, path: str) -> dict:
        return await self.request("DELETE", path)

    # -------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------

    @staticmethod
    def _backoff_delay(attempt: int) -> float:
        """Exponential backoff with jitter. Capped at _MAX_BACKOFF."""
        base = min(_DEFAULT_BASE_DELAY * (2 ** attempt), _MAX_BACKOFF)
        jitter = random.uniform(0, 0.5)
        return base + jitter

    @staticmethod
    def _build_exception(response: httpx.Response) -> OrisError:
        """Build a typed exception from an HTTP error response."""
        try:
            body = response.json()
            error = body.get("error", body)
            message = error.get("message", response.text)
            error_code = error.get("code", "")
            request_id = error.get("request_id")
            details = error.get("details")
        except Exception:
            message = response.text or f"HTTP {response.status_code}"
            error_code = ""
            request_id = None
            details = None

        kwargs = {
            "status_code": response.status_code,
            "error_code": error_code,
            "request_id": request_id,
            "details": details,
        }

        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "1"))
            return OrisRateLimitError(message, retry_after=retry_after, **kwargs)
        if response.status_code in (401, 403):
            return OrisAuthError(message, **kwargs)
        if response.status_code in (400, 422):
            return OrisValidationError(message, **kwargs)
        if error_code in _PAYMENT_ERROR_CODES:
            return OrisPaymentError(message, **kwargs)
        return OrisError(message, **kwargs)

    def _raise_for_status(self, response: httpx.Response) -> None:
        """Raise the appropriate typed exception for a non-retryable error."""
        raise self._build_exception(response)
