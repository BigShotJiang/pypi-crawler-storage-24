"""A script to test the strong scaling of the particle spectra calculation.

Usage:
    python part_spectra_strong_scaling.py --basename test --max_threads 8
       --nstars 10**5
"""

import argparse

import matplotlib.pyplot as plt
import numpy as np
from unyt import Msun, Myr, km, s

from synthesizer.emission_models import IncidentEmission
from synthesizer.grid import Grid
from synthesizer.parametric import SFH, ZDist
from synthesizer.parametric import Stars as ParametricStars
from synthesizer.particle.stars import sample_sfzh
from synthesizer.utils.profiling_utils import run_scaling_test

plt.rcParams["font.family"] = "DeJavu Serif"
plt.rcParams["font.serif"] = ["Times New Roman"]

# Set the seed
np.random.seed(42)


def part_spectra_strong_scaling(
    basename,
    out_dir,
    max_threads,
    nstars,
    average_over,
    gam,
    low_thresh,
    doppler,
    paper_style,
):
    """Profile the cpu time usage of the particle spectra calculation."""
    # Define the grid
    grid_name = "test_grid"

    grid = Grid(grid_name)

    # Get the emission model
    model = IncidentEmission(grid, vel_shift=doppler, per_particle=True)

    # Generate the star formation metallicity history
    mass = 10**10 * Msun
    param_stars = ParametricStars(
        grid.log10ages,
        grid.metallicities,
        sf_hist=SFH.Constant(100 * Myr),
        metal_dist=ZDist.Normal(0.005, 0.01),
        initial_mass=mass,
    )

    # Sample the SFZH, producing a Stars object
    stars = sample_sfzh(
        param_stars.sfzh,
        param_stars.log10ages,
        param_stars.log10metallicities,
        nstars,
        redshift=1,
        velocities=np.random.normal(0.0, 100.0, size=(nstars, 3)) * km / s,
    )

    # Get spectra in serial first to get over any overhead due to linking
    # the first time the function is called
    print("Initial serial spectra calculation")
    stars.get_spectra(model, nthreads=1, grid_assignment_method=gam)
    print()

    # Define the log and plot output paths
    if doppler:
        log_outpath = (
            f"{out_dir}/{basename}_part_spectra_{gam}_"
            f"totThreads{max_threads}_nstars{nstars}_doppler.log"
        )
        plot_outpath = (
            f"{out_dir}/{basename}_part_spectra_{gam}_"
            f"totThreads{max_threads}_nstars{nstars}_doppler.png"
        )
    else:
        log_outpath = (
            f"{out_dir}/{basename}_part_spectra_{gam}_"
            f"totThreads{max_threads}_nstars{nstars}.log"
        )
        plot_outpath = (
            f"{out_dir}/{basename}_part_spectra_{gam}_"
            f"totThreads{max_threads}_nstars{nstars}.png"
        )

    # Run the scaling test
    run_scaling_test(
        max_threads,
        average_over,
        log_outpath,
        plot_outpath,
        stars.get_spectra,
        {
            "emission_model": model,
            "grid_assignment_method": gam,
        },
        total_msg="Generating spectra",
        low_thresh=low_thresh,
        paper_style=paper_style,
    )


if __name__ == "__main__":
    # Get the command line args
    args = argparse.ArgumentParser()

    args.add_argument(
        "--basename",
        type=str,
        default="test",
        help="The basename of the output files.",
    )

    args.add_argument(
        "--out_dir",
        type=str,
        default="./",
        help="The output directory for the log and plot files."
        " Defaults to the current directory.",
    )

    args.add_argument(
        "--max_threads",
        type=int,
        default=8,
        help="The maximum number of threads to use.",
    )

    args.add_argument(
        "--nstars",
        type=int,
        default=10**5,
        help="The number of stars to use in the simulation.",
    )

    args.add_argument(
        "--average_over",
        type=int,
        default=10,
        help="The number of times to average over.",
    )

    args.add_argument(
        "--grid_assign",
        type=str,
        default="cic",
        help="The grid assignment method (cic or ngp).",
    )

    args.add_argument(
        "--low_thresh",
        type=float,
        default=0.01,
        help="the lower threshold on time for an operation to "
        "be included in the scaling test plot.",
    )
    args.add_argument(
        "--paper_style",
        action="store_true",
        help="Use the paper style for the plot (legend below the plot and "
        "smaller proportions).",
    )

    args.add_argument(
        "--doppler",
        action="store_true",
        help="Whether to apply velocity shifts to the spectra calculation.",
    )

    args = args.parse_args()

    # Check for atomic timing
    from synthesizer import check_atomic_timing

    if not check_atomic_timing():
        raise RuntimeError(
            "Atomic timing not available. Recompile with: "
            "ATOMIC_TIMING=1 pip install -e ."
        )

    part_spectra_strong_scaling(
        args.basename,
        args.out_dir,
        args.max_threads,
        args.nstars,
        args.average_over,
        args.grid_assign,
        args.low_thresh,
        args.doppler,
        args.paper_style,
    )
