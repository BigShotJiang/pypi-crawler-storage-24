"""Normalization statistics computation for time series datasets."""

import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import NamedTuple

import h5py
import numpy as np
import torch


@dataclass(frozen=True)
class NormPair:
    """Per-signal normalization statistics (mean, std, min, max as 1-D numpy arrays).

    Args:
        mean: per-feature mean values
        std: per-feature standard deviation values
        min: per-feature minimum values
        max: per-feature maximum values
    """

    mean: np.ndarray
    std: np.ndarray
    min: np.ndarray
    max: np.ndarray

    def __add__(self, other: "NormPair") -> "NormPair":
        """Concatenate two NormPairs feature-wise."""
        return NormPair(*(np.hstack([a, b]) for a, b in zip(self, other)))

    def __iter__(self):
        return iter((self.mean, self.std, self.min, self.max))

    def __getitem__(self, idx):
        return (self.mean, self.std, self.min, self.max)[idx]


class NormStats(NamedTuple):
    """Normalization statistics for input and output signals.

    Args:
        u: normalization stats for input signals
        y: normalization stats for output signals
    """

    u: NormPair
    y: NormPair


def _cache_path(dls_id: str) -> Path:
    return Path(f".tsfast_cache/{dls_id}.pkl")


def _save_norm_stats(dls_id: str, norm_stats: NormStats) -> None:
    p = _cache_path(dls_id)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "wb") as f:
        pickle.dump(norm_stats, f)


def _load_norm_stats(dls_id: str) -> NormStats | None:
    p = _cache_path(dls_id)
    if not p.exists():
        return None
    with open(p, "rb") as f:
        return pickle.load(f)


def compute_stats_from_files(files: list, signals: list[str]) -> NormPair | None:
    """Compute exact NormPair (mean, std, min, max) from all samples in HDF5 files.

    Args:
        files: paths to HDF5 files
        signals: signal dataset names within each file
    """
    if len(signals) == 0:
        return None

    sums = np.zeros(len(signals))
    squares = np.zeros(len(signals))
    mins = np.full(len(signals), np.inf)
    maxs = np.full(len(signals), -np.inf)
    counts = np.zeros(len(signals))

    for file in files:
        with h5py.File(file, "r") as f:
            for i, signal in enumerate(signals):
                data = f[signal][:]
                if data.ndim > 1:
                    raise ValueError(f"Each dataset in a file has to be 1d. {signal} is {data.ndim}.")
                sums[i] += np.nansum(data)
                squares[i] += np.nansum(data**2)
                mins[i] = min(mins[i], np.nanmin(data))
                maxs[i] = max(maxs[i], np.nanmax(data))
                counts[i] += np.sum(~np.isnan(data))

    means = sums / counts
    stds = np.sqrt((squares / counts) - (means**2))
    return NormPair(
        means.astype(np.float32),
        stds.astype(np.float32),
        mins.astype(np.float32),
        maxs.astype(np.float32),
    )


def compute_stats(dl, n_batches: int = 10) -> tuple[NormPair, ...]:
    """Estimate per-feature mean/std/min/max from training batches.

    Args:
        dl: DataLoader to sample from
        n_batches: number of batches to use for estimation
    """
    acc = None
    for i, batch in enumerate(dl):
        if i >= n_batches:
            break
        if acc is None:
            acc = [[t] for t in batch]
        else:
            for j, t in enumerate(batch):
                acc[j].append(t)

    stats = []
    for tensors in acc:
        t = torch.cat(tensors).flatten(0, -2)  # [total_samples, features]
        mean = torch.nanmean(t, 0)
        std = torch.nanmean((t - mean).pow(2), 0).sqrt()
        t_min = torch.where(torch.isnan(t), torch.tensor(float("inf")), t).min(0).values
        t_max = torch.where(torch.isnan(t), torch.tensor(float("-inf")), t).max(0).values
        stats.append(
            NormPair(
                mean=mean.cpu().numpy().astype(np.float32),
                std=std.cpu().numpy().astype(np.float32),
                min=t_min.cpu().numpy().astype(np.float32),
                max=t_max.cpu().numpy().astype(np.float32),
            )
        )
    return tuple(stats)
