"""Testes unitários para o cliente HTTP do Jira (Basic Auth)."""

from unittest.mock import MagicMock, patch

import pytest
import requests

from mcp_jira.jira_client import (
    JiraAuthError,
    JiraClient,
    JiraConnectionError,
    JiraError,
    JiraValidationError,
)


# --- Helpers ---


def _make_response(
    status_code: int = 200,
    json_data: dict | None = None,
    text: str = "",
    headers: dict | None = None,
) -> MagicMock:
    """Cria um mock de requests.Response."""
    resp = MagicMock(spec=requests.Response)
    resp.status_code = status_code
    resp.text = text
    resp.json.return_value = json_data or {}
    resp.headers = headers or {"Content-Type": "application/json"}
    resp.raise_for_status = MagicMock()
    if status_code >= 400:
        resp.raise_for_status.side_effect = requests.HTTPError(response=resp)
    return resp


def _make_client() -> JiraClient:
    """Cria um JiraClient para testes."""
    return JiraClient("https://jira.example.com", "dGVzdDoxMjM=")


# --- Testes de Exceções ---


class TestExceptions:
    def test_exception_hierarchy(self):
        assert issubclass(JiraConnectionError, JiraError)
        assert issubclass(JiraAuthError, JiraError)
        assert issubclass(JiraValidationError, JiraError)

    def test_jira_error_is_exception(self):
        assert issubclass(JiraError, Exception)


# --- Testes de __init__ ---


class TestInit:
    def test_strips_trailing_slash_from_url(self):
        client = JiraClient("https://jira.example.com/", "token")
        assert client.jira_url == "https://jira.example.com"

    def test_sets_auth_header(self):
        client = JiraClient("https://jira.example.com", "mytoken123")
        assert client._headers["Authorization"] == "Basic mytoken123"

    def test_sets_json_headers(self):
        client = _make_client()
        assert client._headers["Accept"] == "application/json"
        assert client._headers["Content-Type"] == "application/json"


# --- Testes de _request ---


class TestRequest:
    @patch("mcp_jira.jira_client.requests.request")
    def test_successful_get(self, mock_request):
        mock_request.return_value = _make_response(json_data={"ok": True})
        client = _make_client()
        resp = client._request("GET", "/rest/api/2/myself")
        assert resp.status_code == 200
        mock_request.assert_called_once()

    @patch("mcp_jira.jira_client.requests.request")
    def test_401_raises_auth_error(self, mock_request):
        mock_request.return_value = _make_response(status_code=401)
        client = _make_client()
        with pytest.raises(JiraAuthError, match="401"):
            client._request("GET", "/rest/api/2/myself")

    @patch("mcp_jira.jira_client.requests.request")
    def test_403_raises_auth_error(self, mock_request):
        mock_request.return_value = _make_response(status_code=403)
        client = _make_client()
        with pytest.raises(JiraAuthError, match="403"):
            client._request("GET", "/rest/api/2/issue/X-1")

    @patch("mcp_jira.jira_client.requests.request")
    def test_passes_headers_and_params(self, mock_request):
        mock_request.return_value = _make_response()
        client = _make_client()
        client._request("GET", "/rest/api/2/search", params={"jql": "x"})
        call_kwargs = mock_request.call_args
        assert call_kwargs.kwargs["params"] == {"jql": "x"}
        assert "Basic" in call_kwargs.kwargs["headers"]["Authorization"]

    @patch("mcp_jira.jira_client.requests.request")
    def test_get_does_not_send_content_type(self, mock_request):
        """GET requests não devem enviar Content-Type (sem body)."""
        mock_request.return_value = _make_response()
        client = _make_client()
        client._request("GET", "/rest/api/2/search")
        headers_sent = mock_request.call_args.kwargs["headers"]
        assert "Content-Type" not in headers_sent
        assert headers_sent["Accept"] == "application/json"

    @patch("mcp_jira.jira_client.requests.request")
    def test_post_sends_content_type(self, mock_request):
        """POST requests devem enviar Content-Type."""
        mock_request.return_value = _make_response(status_code=201)
        client = _make_client()
        client._request("POST", "/rest/api/2/issue", json={"fields": {}})
        headers_sent = mock_request.call_args.kwargs["headers"]
        assert headers_sent["Content-Type"] == "application/json"

    @patch("mcp_jira.jira_client.requests.request")
    def test_passes_json_body(self, mock_request):
        mock_request.return_value = _make_response(status_code=201)
        client = _make_client()
        client._request("POST", "/rest/api/2/issue", json={"fields": {}})
        call_kwargs = mock_request.call_args
        assert call_kwargs.kwargs["json"] == {"fields": {}}


# --- Testes de get_issue ---


class TestGetIssue:
    @patch("mcp_jira.jira_client.requests.request")
    def test_returns_issue_data(self, mock_request):
        issue_data = {
            "key": "PROJ-123",
            "names": {},
            "fields": {
                "summary": "Test issue",
                "description": "Some desc",
                "status": {"name": "Open"},
                "priority": {"name": "High"},
                "issuetype": {"name": "Bug"},
                "assignee": {"displayName": "Dev"},
                "reporter": {"displayName": "QA"},
                "created": "2025-01-01",
                "updated": "2025-01-02",
                "labels": ["test"],
                "components": [{"name": "backend"}],
            },
        }
        mock_request.return_value = _make_response(json_data=issue_data)
        client = _make_client()
        result = client.get_issue("PROJ-123")
        assert result["key"] == "PROJ-123"
        assert result["summary"] == "Test issue"
        assert result["status"] == "Open"
        assert result["assignee"] == "Dev"
        assert result["url"] == "https://jira.example.com/browse/PROJ-123"


# --- Testes de create_issue ---


class TestCreateIssue:
    def test_missing_project_key_raises_validation_error(self):
        client = _make_client()
        with pytest.raises(JiraValidationError, match="project_key"):
            client.create_issue("", "summary", "desc")

    def test_missing_summary_raises_validation_error(self):
        client = _make_client()
        with pytest.raises(JiraValidationError, match="summary"):
            client.create_issue("PROJ", "", "desc")

    def test_missing_description_raises_validation_error(self):
        client = _make_client()
        with pytest.raises(JiraValidationError, match="description"):
            client.create_issue("PROJ", "summary", "")

    def test_missing_multiple_fields_lists_all(self):
        client = _make_client()
        with pytest.raises(JiraValidationError, match="project_key.*summary.*description"):
            client.create_issue("", "", "")

    @patch("mcp_jira.jira_client.requests.request")
    def test_successful_create_returns_key_and_url(self, mock_request):
        mock_request.return_value = _make_response(
            status_code=201, json_data={"key": "PROJ-456", "id": "10001"}
        )
        client = _make_client()
        result = client.create_issue("PROJ", "Bug title", "Bug description")
        assert result["key"] == "PROJ-456"
        assert result["url"] == "https://jira.example.com/browse/PROJ-456"

    @patch("mcp_jira.jira_client.requests.request")
    def test_create_with_optional_fields(self, mock_request):
        mock_request.return_value = _make_response(
            status_code=201, json_data={"key": "PROJ-789"}
        )
        client = _make_client()
        client.create_issue(
            "PROJ", "Title", "Desc",
            issue_type="Task", priority="High",
            labels=["urgent"], components=["backend"],
        )
        body = mock_request.call_args.kwargs["json"]["fields"]
        assert body["issuetype"]["name"] == "Task"
        assert body["priority"]["name"] == "High"
        assert body["labels"] == ["urgent"]
        assert body["components"] == [{"name": "backend"}]

    @patch("mcp_jira.jira_client.requests.request")
    def test_create_error_raises_jira_error(self, mock_request):
        mock_request.return_value = _make_response(
            status_code=400,
            json_data={"errors": {"issuetype": "Tipo inválido"}, "errorMessages": []},
        )
        client = _make_client()
        with pytest.raises(JiraError, match="Tipo inválido"):
            client.create_issue("PROJ", "Title", "Desc")

    def test_create_issue_signature_maintains_required_params(self):
        import inspect

        sig = inspect.signature(JiraClient.create_issue)
        params = sig.parameters

        # Positional required params (no default)
        for name in ("self", "project_key", "summary", "description"):
            assert name in params, f"Parâmetro obrigatório '{name}' ausente"
            assert params[name].default is inspect.Parameter.empty

        # Optional params (have defaults)
        optional = {
            "issue_type": "Bug",
            "priority": None,
            "labels": None,
            "components": None,
            "custom_fields": None,
        }
        for name, default in optional.items():
            assert name in params, f"Parâmetro opcional '{name}' ausente"
            assert params[name].default == default


# --- Testes de search_issues ---


class TestSearchIssues:
    @patch("mcp_jira.jira_client.requests.request")
    def test_returns_list_of_issues(self, mock_request):
        issues = [
            {"key": "PROJ-1", "fields": {"summary": "A"}},
            {"key": "PROJ-2", "fields": {"summary": "B"}},
        ]
        mock_request.return_value = _make_response(json_data={"issues": issues, "total": 2})
        client = _make_client()
        result = client.search_issues("project = PROJ")
        assert len(result) == 2
        assert result[0]["key"] == "PROJ-1"

    @patch("mcp_jira.jira_client.requests.request")
    def test_passes_fields_parameter(self, mock_request):
        mock_request.return_value = _make_response(json_data={"issues": []})
        client = _make_client()
        client.search_issues("project = PROJ", fields=["summary", "status"])
        params = mock_request.call_args.kwargs["params"]
        assert params["fields"] == "summary,status"


# --- Testes de update_issue ---


class TestUpdateIssue:
    @patch("mcp_jira.jira_client.requests.request")
    def test_update_success(self, mock_request):
        mock_request.return_value = _make_response(status_code=204)
        client = _make_client()
        client.update_issue("PROJ-1", {"summary": "Updated"})
        assert mock_request.call_args.args[0] == "PUT"

    @patch("mcp_jira.jira_client.requests.request")
    def test_update_error_raises_jira_error(self, mock_request):
        mock_request.return_value = _make_response(
            status_code=400, json_data={"errors": {"summary": "obrigatório"}}
        )
        client = _make_client()
        with pytest.raises(JiraError, match="obrigatório"):
            client.update_issue("PROJ-1", {"summary": ""})


# --- Testes de add_comment ---


class TestAddComment:
    @patch("mcp_jira.jira_client.requests.request")
    def test_returns_comment_data(self, mock_request):
        comment_data = {"id": "10001", "body": "Test comment"}
        mock_request.return_value = _make_response(
            status_code=201, json_data=comment_data
        )
        client = _make_client()
        result = client.add_comment("PROJ-1", "Test comment")
        assert result["id"] == "10001"

    @patch("mcp_jira.jira_client.requests.request")
    def test_comment_error_raises_jira_error(self, mock_request):
        mock_request.return_value = _make_response(
            status_code=404, json_data={"errorMessages": ["Issue não encontrada"]}
        )
        client = _make_client()
        with pytest.raises(JiraError, match="404"):
            client.add_comment("PROJ-999", "comment")


# --- Testes de Propriedade (Hypothesis) ---

from hypothesis import given, settings
from hypothesis import strategies as st


# Feature: mcp-jira-custom-fields-and-tools, Property 1: Passthrough de IDs técnicos
class TestPassthroughTechnicalIds:
    """
    Propriedade 1: Para qualquer dicionário custom_fields contendo chaves no formato
    customfield_XXXXX com valores de qualquer tipo JSON, o payload enviado ao Jira deve
    conter cada campo com exatamente o mesmo valor recebido, sem conversão de tipo,
    e sem consultar o endpoint createmeta para essas chaves.

    **Validates: Requirements 1.1, 1.2, 1.3**
    """

    # Strategy: gera dicionários com chaves customfield_<digits> e valores JSON variados
    _json_values = st.one_of(
        st.text(),
        st.integers(),
        st.lists(st.text()),
        st.booleans(),
        st.none(),
    )
    _technical_fields = st.dictionaries(
        keys=st.from_regex(r"customfield_[0-9]{1,5}", fullmatch=True),
        values=_json_values,
        min_size=1,
    )

    @given(custom_fields=_technical_fields)
    @settings(max_examples=100)
    @patch("mcp_jira.jira_client.requests.request")
    def test_passthrough_technical_ids(self, mock_request, custom_fields):
        """
        Dado um dicionário de campos técnicos (customfield_XXXXX) com valores JSON,
        o payload enviado ao Jira deve conter cada campo com exatamente o mesmo valor,
        e _resolve_custom_field_ids NÃO deve ser chamado.
        """
        # Arrange: mock _request para retornar 201 com uma key
        mock_request.return_value = _make_response(
            status_code=201, json_data={"key": "PROJ-1"}
        )
        client = _make_client()

        # Act: chamar create_issue com campos técnicos
        with patch.object(client, "_resolve_custom_field_ids") as mock_resolve:
            client.create_issue(
                project_key="PROJ",
                summary="Test",
                description="Desc",
                custom_fields=custom_fields,
            )

            # Assert 1: _resolve_custom_field_ids NÃO foi chamado
            mock_resolve.assert_not_called()

        # Assert 2: cada campo técnico aparece no payload com o mesmo valor
        payload = mock_request.call_args.kwargs["json"]["fields"]
        for key, value in custom_fields.items():
            assert key in payload, f"Campo {key} ausente no payload"
            assert payload[key] is value, (
                f"Campo {key}: esperado {value!r} (tipo {type(value).__name__}), "
                f"obtido {payload[key]!r} (tipo {type(payload[key]).__name__})"
            )


# Feature: mcp-jira-custom-fields-and-tools, Property 2: Retrocompatibilidade de nomes legíveis
class TestBackwardCompatNamedFields:
    """
    Propriedade 2: Para qualquer dicionário custom_fields contendo apenas nomes legíveis
    (sem IDs técnicos) e valores string, o payload gerado pelo novo código deve ser
    idêntico ao payload que seria gerado pela lógica anterior (resolução via createmeta
    com conversões nFeed, option, array-option).

    **Validates: Requirements 1.4, 1.7, 4.2**
    """

    # Strategy: gera nomes de campos lowercase que NÃO casam com customfield_\d+
    # Usa apenas lowercase para evitar colisões de case (ex: 'A' e 'a' mapeiam para o mesmo meta key)
    _field_names = st.text(
        alphabet=st.characters(whitelist_categories=("Ll",)),
        min_size=1,
    )
    _named_fields = st.dictionaries(
        keys=_field_names,
        values=st.text(min_size=1),
        min_size=1,
    )

    @given(custom_fields=_named_fields)
    @settings(max_examples=100)
    @patch("mcp_jira.jira_client.requests.request")
    def test_backward_compat_named_fields(self, mock_request, custom_fields):
        """
        Dado um dicionário de campos com nomes legíveis e valores string,
        _resolve_custom_field_ids DEVE ser chamado e os campos devem ser
        resolvidos via createmeta (meta mapping).
        """
        # Arrange: construir meta mapping fake — cada nome mapeia para customfield_NNNNN tipo string
        meta = {}
        for idx, name in enumerate(custom_fields):
            meta[name.lower()] = {
                "id": f"customfield_{10000 + idx}",
                "type": "string",
                "items": "",
                "custom": "",
            }

        mock_request.return_value = _make_response(
            status_code=201, json_data={"key": "PROJ-1"}
        )
        client = _make_client()

        # Act
        with patch.object(client, "_resolve_custom_field_ids", return_value=meta) as mock_resolve:
            client.create_issue(
                project_key="PROJ",
                summary="Test",
                description="Desc",
                custom_fields=custom_fields,
            )

            # Assert 1: _resolve_custom_field_ids FOI chamado (nomes legíveis precisam de resolução)
            mock_resolve.assert_called_once()

        # Assert 2: cada campo nomeado aparece no payload com o ID resolvido e valor original
        payload = mock_request.call_args.kwargs["json"]["fields"]
        for name, value in custom_fields.items():
            field_meta = meta.get(name.lower())
            if field_meta:
                field_id = field_meta["id"]
                assert field_id in payload, (
                    f"Campo '{name}' (resolvido para {field_id}) ausente no payload"
                )
                # Tipo "string" com custom="" → passthrough direto do valor
                assert payload[field_id] == value, (
                    f"Campo '{name}' ({field_id}): esperado {value!r}, obtido {payload[field_id]!r}"
                )


# Feature: mcp-jira-custom-fields-and-tools, Property 3: Processamento misto de IDs técnicos e nomes legíveis
class TestMixedFieldsProcessing:
    """
    Propriedade 3: Para qualquer dicionário custom_fields contendo uma mistura de IDs
    técnicos e nomes legíveis, cada entrada com ID técnico deve aparecer como passthrough
    no payload, e cada entrada com nome legível deve ser resolvida via createmeta com as
    conversões de tipo existentes.

    **Validates: Requirements 1.6**
    """

    # Strategy: gera campos técnicos (customfield_XXXXX) com valores JSON variados
    _json_values = st.one_of(
        st.text(),
        st.integers(),
        st.lists(st.text()),
        st.booleans(),
        st.none(),
    )
    _tech_fields = st.dictionaries(
        keys=st.from_regex(r"customfield_[0-9]{1,5}", fullmatch=True),
        values=_json_values,
        min_size=1,
    )

    # Strategy: gera campos com nomes legíveis (alfabéticos) e valores string
    _named_fields = st.dictionaries(
        keys=st.text(
            alphabet=st.characters(whitelist_categories=("L",)),
            min_size=1,
        ),
        values=st.text(min_size=1),
        min_size=1,
    )

    @given(tech_fields=_tech_fields, named_fields=_named_fields)
    @settings(max_examples=100)
    @patch("mcp_jira.jira_client.requests.request")
    def test_mixed_fields_processing(self, mock_request, tech_fields, named_fields):
        """
        Dado um dicionário misto de campos técnicos e nomes legíveis,
        os campos técnicos devem aparecer como passthrough no payload,
        os campos nomeados devem ser resolvidos via createmeta,
        e _resolve_custom_field_ids DEVE ser chamado.
        """
        # Arrange: merge both dicts into one custom_fields dict
        custom_fields = {**tech_fields, **named_fields}

        # Build fake meta mapping for named fields
        meta = {}
        for idx, name in enumerate(named_fields):
            meta[name.lower()] = {
                "id": f"customfield_{20000 + idx}",
                "type": "string",
                "items": "",
                "custom": "",
            }

        mock_request.return_value = _make_response(
            status_code=201, json_data={"key": "PROJ-1"}
        )
        client = _make_client()

        # Act
        with patch.object(client, "_resolve_custom_field_ids", return_value=meta) as mock_resolve:
            client.create_issue(
                project_key="PROJ",
                summary="Test",
                description="Desc",
                custom_fields=custom_fields,
            )

            # Assert 1: _resolve_custom_field_ids FOI chamado (há nomes legíveis)
            mock_resolve.assert_called_once()

        # Assert 2: cada campo técnico aparece no payload com o mesmo valor (passthrough)
        payload = mock_request.call_args.kwargs["json"]["fields"]
        for key, value in tech_fields.items():
            assert key in payload, f"Campo técnico {key} ausente no payload"
            assert payload[key] is value, (
                f"Campo técnico {key}: esperado {value!r} (tipo {type(value).__name__}), "
                f"obtido {payload[key]!r} (tipo {type(payload[key]).__name__})"
            )

        # Assert 3: cada campo nomeado aparece no payload resolvido via meta mapping
        for name, value in named_fields.items():
            field_meta = meta.get(name.lower())
            if field_meta:
                field_id = field_meta["id"]
                assert field_id in payload, (
                    f"Campo nomeado '{name}' (resolvido para {field_id}) ausente no payload"
                )
                assert payload[field_id] == value, (
                    f"Campo nomeado '{name}' ({field_id}): esperado {value!r}, obtido {payload[field_id]!r}"
                )


# Feature: mcp-jira-custom-fields-and-tools, Property 4: nFeed search envia query como userInput
class TestNfeedSearchSendsQuery:
    """
    Propriedade 4: Para qualquer string de busca query, quando nfeed_search é chamado,
    o body da requisição HTTP enviada ao endpoint /rest/nfeed/3.0/nFeed/field/input/options
    deve conter o campo userInput com valor igual à query fornecida.

    **Validates: Requirements 2.2**
    """

    @given(query=st.text(min_size=1))
    @settings(max_examples=100)
    def test_nfeed_search_sends_query_as_user_input(self, query):
        """
        Dado qualquer string de busca, o body enviado ao endpoint nFeed
        deve conter userInput igual à query fornecida.
        """
        client = _make_client()

        mock_resp = _make_response(
            status_code=200,
            json_data={"options": [], "hasNext": False},
        )

        with patch.object(client, "_request", return_value=mock_resp) as mock_req:
            client.nfeed_search(
                field_id="customfield_10500",
                query=query,
                project_id="10000",
                issue_type_id="10001",
            )

            # Assert: _request foi chamado com body contendo userInput == query
            mock_req.assert_called_once()
            call_kwargs = mock_req.call_args
            body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
            assert body["userInput"] == query


# Feature: mcp-jira-custom-fields-and-tools, Property 5: nFeed search retorna id e label corretos
class TestNfeedSearchReturnsIdLabel:
    """
    Propriedade 5: Para qualquer resposta válida do endpoint nFeed contendo uma lista
    de opções, o resultado de nfeed_search deve conter um objeto {"id": str, "label": str}
    para cada opção, onde id corresponde ao campo id da opção e label corresponde ao
    primeiro valor do campo values.

    **Validates: Requirements 2.4**
    """

    _options_strategy = st.lists(
        st.fixed_dictionaries({
            "id": st.text(min_size=1),
            "values": st.lists(st.text(min_size=1), min_size=1),
        }),
        min_size=1,
    )

    @given(options=_options_strategy)
    @settings(max_examples=100)
    def test_nfeed_search_returns_id_and_label(self, options):
        """
        Dado uma lista de opções nFeed com ids e values, o resultado deve conter
        um objeto com id (str) e label (primeiro valor de values) para cada opção.
        """
        client = _make_client()

        mock_resp = _make_response(
            status_code=200,
            json_data={"options": options, "hasNext": False},
        )

        with patch.object(client, "_request", return_value=mock_resp):
            result = client.nfeed_search(
                field_id="customfield_10500",
                query="test",
                project_id="10000",
                issue_type_id="10001",
            )

            # Assert: mesmo número de resultados
            assert len(result) == len(options)

            # Assert: cada resultado tem id e label corretos
            for res, opt in zip(result, options):
                assert res["id"] == str(opt["id"])
                assert res["label"] == opt["values"][0]


# Feature: mcp-jira-custom-fields-and-tools, Property 6: nFeed search retorna lista vazia em erro HTTP
class TestNfeedSearchErrorReturnsEmpty:
    """
    Propriedade 6: Para qualquer status HTTP diferente de 200 retornado pelo endpoint nFeed,
    o método nfeed_search deve retornar uma lista vazia sem lançar exceção.

    **Validates: Requirements 2.5**
    """

    @given(status_code=st.integers(min_value=400, max_value=599))
    @settings(max_examples=100)
    def test_nfeed_search_error_returns_empty(self, status_code):
        """
        Dado qualquer status HTTP de erro (4xx ou 5xx), nfeed_search deve
        retornar lista vazia sem lançar exceção.
        """
        client = _make_client()

        # Mock _request to return error status (bypass auth error raising)
        mock_resp = MagicMock()
        mock_resp.status_code = status_code
        mock_resp.text = "error"
        mock_resp.json.return_value = {}

        with patch.object(client, "_request", return_value=mock_resp):
            result = client.nfeed_search(
                field_id="customfield_10500",
                query="test",
                project_id="10000",
                issue_type_id="10001",
            )

            # Assert: resultado é lista vazia
            assert result == []


# Feature: mcp-jira-custom-fields-and-tools, Property 7: nFeed search paginação automática
class TestNfeedSearchPagination:
    """
    Propriedade 7: Para qualquer sequência de páginas retornadas pelo endpoint nFeed
    onde hasNext é verdadeiro nas N-1 primeiras páginas e falso na última, o resultado
    de nfeed_search deve conter todas as opções de todas as páginas concatenadas em ordem.

    **Validates: Requirements 2.6**
    """

    _pages_strategy = st.lists(
        st.lists(
            st.fixed_dictionaries({
                "id": st.text(min_size=1),
                "values": st.lists(st.text(min_size=1), min_size=1),
            }),
            min_size=1,
        ),
        min_size=2,
        max_size=3,
    )

    @given(pages=_pages_strategy)
    @settings(max_examples=100)
    def test_nfeed_search_pagination(self, pages):
        """
        Dado múltiplas páginas de opções nFeed, o resultado deve conter todas
        as opções de todas as páginas concatenadas em ordem, e _request deve
        ser chamado uma vez por página.
        """
        client = _make_client()

        # Build mock responses: all pages except last have hasNext=True
        mock_responses = []
        for i, page_options in enumerate(pages):
            is_last = i == len(pages) - 1
            resp = _make_response(
                status_code=200,
                json_data={
                    "options": page_options,
                    "hasNext": not is_last,
                },
            )
            mock_responses.append(resp)

        with patch.object(client, "_request", side_effect=mock_responses) as mock_req:
            result = client.nfeed_search(
                field_id="customfield_10500",
                query="test",
                project_id="10000",
                issue_type_id="10001",
            )

            # Assert: _request chamado uma vez por página
            assert mock_req.call_count == len(pages)

            # Assert: resultado contém todas as opções de todas as páginas
            all_options = [opt for page in pages for opt in page]
            assert len(result) == len(all_options)

            # Assert: ordem preservada
            for res, opt in zip(result, all_options):
                assert res["id"] == str(opt["id"])
                assert res["label"] == opt["values"][0]


# Feature: mcp-jira-custom-fields-and-tools, Property 8: Sprint search filtragem e formato de resultado
class TestSprintSearchFilterAndFormat:
    """
    Propriedade 8: Para qualquer lista de sprints retornada pela API do Jira e qualquer
    string de busca sprint_name, o resultado de search_sprint deve conter apenas sprints
    cujo nome contém sprint_name como substring (case-insensitive), e cada resultado deve
    conter os campos id, name, state, startDate e endDate.

    **Validates: Requirements 3.5, 3.7**
    """

    _sprints_strategy = st.lists(
        st.fixed_dictionaries({
            "id": st.integers(min_value=1),
            "name": st.text(min_size=1),
            "state": st.just("active"),
            "startDate": st.just("2025-01-01T00:00:00.000Z"),
            "endDate": st.just("2025-01-15T00:00:00.000Z"),
        }),
        min_size=1,
    )

    _search_term_strategy = st.text(
        min_size=1,
        max_size=5,
        alphabet=st.characters(whitelist_categories=("L",)),
    )

    @given(sprints=_sprints_strategy, search_term=_search_term_strategy)
    @settings(max_examples=100)
    def test_sprint_search_filter_and_format(self, sprints, search_term):
        """
        Dado uma lista de sprints e um termo de busca, search_sprint deve retornar
        apenas sprints cujo nome contém o termo (case-insensitive) e cada resultado
        deve ter os campos id, name, state, startDate, endDate.
        """
        client = _make_client()

        mock_resp = _make_response(
            status_code=200,
            json_data={"values": sprints},
        )

        with patch.object(client, "_request", return_value=mock_resp):
            result = client.search_sprint(
                board_id="100",
                sprint_name=search_term,
            )

            # Assert: resultado contém apenas sprints cujo nome contém o termo
            expected = [
                s for s in sprints
                if search_term.lower() in s["name"].lower()
            ]
            assert len(result) == len(expected)

            # Assert: cada resultado tem os campos corretos
            for item in result:
                assert set(item.keys()) == {"id", "name", "state", "startDate", "endDate"}

            # Assert: filtragem case-insensitive correta
            for item in result:
                assert search_term.lower() in item["name"].lower()


# Feature: mcp-jira-custom-fields-and-tools, Property 9: Sprint search fallback active→future
class TestSprintSearchFallback:
    """
    Propriedade 9: Para qualquer board onde não existem sprints ativos cujo nome
    corresponda à busca, quando state="active", o método search_sprint deve
    automaticamente buscar sprints no estado future antes de retornar resultado vazio.

    **Validates: Requirement 3.6**
    """

    _sprint_strategy = st.fixed_dictionaries({
        "id": st.integers(min_value=1),
        "name": st.text(min_size=1),
        "state": st.just("future"),
        "startDate": st.just("2025-02-01T00:00:00.000Z"),
        "endDate": st.just("2025-02-15T00:00:00.000Z"),
    })

    @given(
        sprint_name=st.text(
            min_size=1,
            max_size=5,
            alphabet=st.characters(whitelist_categories=("L",)),
        ),
        future_sprints=st.lists(_sprint_strategy, min_size=1, max_size=3),
    )
    @settings(max_examples=100)
    def test_sprint_search_fallback(self, sprint_name, future_sprints):
        """
        Dado que não há sprints ativos correspondentes, search_sprint deve
        fazer fallback para state=future e retornar os sprints futuros.
        """
        client = _make_client()

        # Ensure future sprints contain the search term in their name
        for s in future_sprints:
            s["name"] = sprint_name + s["name"]

        # First call (active): empty results; Second call (future): has results
        active_resp = _make_response(
            status_code=200,
            json_data={"values": []},
        )
        future_resp = _make_response(
            status_code=200,
            json_data={"values": future_sprints},
        )

        with patch.object(
            client, "_request", side_effect=[active_resp, future_resp]
        ) as mock_req:
            result = client.search_sprint(
                board_id="100",
                sprint_name=sprint_name,
                state="active",
            )

            # Assert: _request chamado duas vezes (active, depois future)
            assert mock_req.call_count == 2

            # Assert: resultado contém os sprints futuros filtrados
            expected = [
                s for s in future_sprints
                if sprint_name.lower() in s["name"].lower()
            ]
            assert len(result) == len(expected)


# Feature: mcp-jira-custom-fields-and-tools, Property 10: Sprint search erro HTTP lança exceção
class TestSprintSearchErrorRaises:
    """
    Propriedade 10: Para qualquer status HTTP diferente de 200 retornado pelo endpoint
    de sprints, o método search_sprint deve lançar JiraError contendo o código de status
    e a mensagem da resposta.

    **Validates: Requirement 3.8**
    """

    @given(status_code=st.integers(min_value=400, max_value=599))
    @settings(max_examples=100)
    def test_sprint_search_error_raises(self, status_code):
        """
        Dado qualquer status HTTP de erro (4xx ou 5xx), search_sprint deve
        lançar JiraError contendo o código de status.
        """
        client = _make_client()

        # Mock _request directly to bypass auth error interception at 401/403
        mock_resp = MagicMock()
        mock_resp.status_code = status_code
        mock_resp.text = "error details"
        mock_resp.json.return_value = {"errorMessages": ["something went wrong"]}

        with patch.object(client, "_request", return_value=mock_resp):
            with pytest.raises(JiraError) as exc_info:
                client.search_sprint(
                    board_id="100",
                    sprint_name="Sprint 1",
                )

            # Assert: mensagem de erro contém o status code
            assert str(status_code) in str(exc_info.value)
