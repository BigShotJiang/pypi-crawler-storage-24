"""Testes unitários para mcp_jira/tools.py."""

import json
from unittest.mock import MagicMock

import pytest

from mcp.server import Server
from mcp.types import Tool

from mcp_jira.jira_client import (
    JiraAuthError,
    JiraConnectionError,
    JiraValidationError,
)
from mcp_jira.tools import (
    TOOLS,
    _error_content,
    _handle_add_comment,
    _handle_create_issue,
    _handle_nfeed_search,
    _handle_search,
    _handle_search_sprint,
    _handle_update_issue,
    _success_content,
    register_tools,
)


# --- Tool definitions ---


class TestToolDefinitions:
    def test_all_tools_defined(self):
        assert len(TOOLS) == 15

    def test_tool_names(self):
        names = {t.name for t in TOOLS}
        assert names == {
            "jira_get_issue",
            "jira_create_issue",
            "jira_search",
            "jira_update_issue",
            "jira_add_comment",
            "jira_list_issue_types",
            "jira_list_components",
            "jira_list_field_options",
            "jira_list_funcionalidades",
            "jira_list_comments",
            "jira_list_attachments",
            "jira_download_attachment",
            "jira_xray_list_test_set_tests",
            "jira_nfeed_search",
            "jira_search_sprint",
        }

    def test_create_issue_required_fields(self):
        tool = next(t for t in TOOLS if t.name == "jira_create_issue")
        assert tool.inputSchema["required"] == [
            "projectKey",
            "summary",
            "description",
            "issueType",
        ]

    def test_search_required_fields(self):
        tool = next(t for t in TOOLS if t.name == "jira_search")
        assert tool.inputSchema["required"] == ["jql"]

    def test_update_issue_required_fields(self):
        tool = next(t for t in TOOLS if t.name == "jira_update_issue")
        assert tool.inputSchema["required"] == ["issueKey", "fields"]

    def test_add_comment_required_fields(self):
        tool = next(t for t in TOOLS if t.name == "jira_add_comment")
        assert tool.inputSchema["required"] == ["issueKey", "body"]

    def test_custom_fields_schema_accepts_any_json_type(self):
        tool = next(t for t in TOOLS if t.name == "jira_create_issue")
        cf_schema = tool.inputSchema["properties"]["customFields"]
        assert cf_schema["type"] == "object"
        assert "additionalProperties" not in cf_schema

    def test_nfeed_search_required_fields(self):
        tool = next(t for t in TOOLS if t.name == "jira_nfeed_search")
        assert tool.inputSchema["required"] == [
            "fieldId",
            "query",
            "projectId",
            "issueTypeId",
        ]

    def test_nfeed_search_in_tools_list(self):
        names = {t.name for t in TOOLS}
        assert "jira_nfeed_search" in names

    def test_search_sprint_required_fields(self):
        tool = next(t for t in TOOLS if t.name == "jira_search_sprint")
        assert tool.inputSchema["required"] == ["boardId", "sprintName"]

    def test_search_sprint_in_tools_list(self):
        names = {t.name for t in TOOLS}
        assert "jira_search_sprint" in names


# --- Helper functions ---


class TestHelpers:
    def test_error_content_returns_text_content(self):
        result = _error_content("algo deu errado")
        assert len(result) == 1
        assert result[0].type == "text"
        assert result[0].text == "algo deu errado"

    def test_success_content_with_dict(self):
        result = _success_content({"key": "PROJ-1", "url": "http://x"})
        assert len(result) == 1
        data = json.loads(result[0].text)
        assert data["key"] == "PROJ-1"

    def test_success_content_with_string(self):
        result = _success_content("ok")
        assert result[0].text == "ok"

    def test_success_content_with_list(self):
        result = _success_content([{"a": 1}])
        data = json.loads(result[0].text)
        assert isinstance(data, list)


# --- Handler tests ---


class TestHandleCreateIssue:
    def test_success(self):
        client = MagicMock()
        client.create_issue.return_value = {
            "key": "PROJ-42",
            "url": "https://jira.example.com/browse/PROJ-42",
        }
        result = _handle_create_issue(
            client,
            {
                "projectKey": "PROJ",
                "summary": "Incidente crítico",
                "description": "Detalhes do incidente",
                "issueType": "Bug",
            },
        )
        data = json.loads(result[0].text)
        assert data["key"] == "PROJ-42"
        assert "PROJ-42" in data["url"]
        client.create_issue.assert_called_once_with(
            project_key="PROJ",
            summary="Incidente crítico",
            description="Detalhes do incidente",
            issue_type="Bug",
            priority=None,
            labels=None,
            components=None,
            custom_fields=None,
        )

    def test_with_optional_fields(self):
        client = MagicMock()
        client.create_issue.return_value = {"key": "PROJ-1", "url": "http://x"}
        _handle_create_issue(
            client,
            {
                "projectKey": "PROJ",
                "summary": "Test",
                "description": "Desc",
                "issueType": "Incident",
                "priority": "High",
                "labels": ["prod", "urgent"],
                "components": ["backend"],
            },
        )
        client.create_issue.assert_called_once_with(
            project_key="PROJ",
            summary="Test",
            description="Desc",
            issue_type="Incident",
            priority="High",
            labels=["prod", "urgent"],
            components=["backend"],
            custom_fields=None,
        )

    def test_missing_required_fields(self):
        client = MagicMock()
        with pytest.raises(JiraValidationError, match="projectKey.*summary"):
            _handle_create_issue(
                client, {"description": "only desc", "issueType": "Bug"}
            )

    def test_missing_single_field(self):
        client = MagicMock()
        with pytest.raises(JiraValidationError, match="description"):
            _handle_create_issue(
                client,
                {"projectKey": "PROJ", "summary": "Test", "issueType": "Bug"},
            )


class TestHandleSearch:
    def test_success_extracts_key_summary_status(self):
        client = MagicMock()
        client.search_issues.return_value = [
            {
                "key": "PROJ-1",
                "fields": {
                    "summary": "Bug no login",
                    "status": {"name": "Open"},
                },
            },
            {
                "key": "PROJ-2",
                "fields": {
                    "summary": "Erro 500",
                    "status": {"name": "In Progress"},
                },
            },
        ]
        result = _handle_search(client, {"jql": "project=PROJ"})
        data = json.loads(result[0].text)
        assert len(data) == 2
        assert data[0]["key"] == "PROJ-1"
        assert data[0]["summary"] == "Bug no login"
        assert data[0]["status"] == "Open"

    def test_passes_optional_params(self):
        client = MagicMock()
        client.search_issues.return_value = []
        _handle_search(
            client,
            {"jql": "project=X", "maxResults": 10, "fields": ["summary"]},
        )
        client.search_issues.assert_called_once_with(
            jql="project=X", max_results=10, fields=["summary"]
        )

    def test_empty_results(self):
        client = MagicMock()
        client.search_issues.return_value = []
        result = _handle_search(client, {"jql": "project=EMPTY"})
        data = json.loads(result[0].text)
        assert data == []


class TestHandleUpdateIssue:
    def test_success(self):
        client = MagicMock()
        result = _handle_update_issue(
            client,
            {"issueKey": "PROJ-1", "fields": {"summary": "Novo título"}},
        )
        data = json.loads(result[0].text)
        assert "PROJ-1" in data["message"]
        assert "atualizada" in data["message"]
        client.update_issue.assert_called_once_with(
            issue_key="PROJ-1", fields={"summary": "Novo título"}
        )


class TestHandleAddComment:
    def test_success(self):
        client = MagicMock()
        client.add_comment.return_value = {"id": "12345"}
        result = _handle_add_comment(
            client,
            {"issueKey": "PROJ-1", "body": "Investigando o problema"},
        )
        data = json.loads(result[0].text)
        assert data["id"] == "12345"
        assert "PROJ-1" in data["message"]
        client.add_comment.assert_called_once_with(
            issue_key="PROJ-1", body="Investigando o problema"
        )


class TestHandleNfeedSearch:
    def test_success(self):
        client = MagicMock()
        client.nfeed_search.return_value = [
            {"id": "123", "label": "Cliente ABC"},
            {"id": "456", "label": "Cliente XYZ"},
        ]
        result = _handle_nfeed_search(
            client,
            {
                "fieldId": "customfield_10500",
                "query": "Cliente",
                "projectId": "10000",
                "issueTypeId": "10001",
            },
        )
        data = json.loads(result[0].text)
        assert len(data) == 2
        assert data[0]["id"] == "123"
        assert data[0]["label"] == "Cliente ABC"
        client.nfeed_search.assert_called_once_with(
            field_id="customfield_10500",
            query="Cliente",
            project_id="10000",
            issue_type_id="10001",
        )

    def test_missing_required_fields(self):
        client = MagicMock()
        with pytest.raises(JiraValidationError, match="fieldId.*query"):
            _handle_nfeed_search(
                client,
                {"projectId": "10000", "issueTypeId": "10001"},
            )


class TestHandleSearchSprint:
    def test_success(self):
        client = MagicMock()
        client.search_sprint.return_value = [
            {
                "id": 100,
                "name": "Sprint 42",
                "state": "active",
                "startDate": "2025-01-01T00:00:00.000Z",
                "endDate": "2025-01-15T00:00:00.000Z",
            },
        ]
        result = _handle_search_sprint(
            client,
            {"boardId": "10", "sprintName": "Sprint 42"},
        )
        data = json.loads(result[0].text)
        assert len(data) == 1
        assert data[0]["id"] == 100
        assert data[0]["name"] == "Sprint 42"
        client.search_sprint.assert_called_once_with(
            board_id="10",
            sprint_name="Sprint 42",
            state="active",
        )

    def test_missing_required_fields(self):
        client = MagicMock()
        with pytest.raises(JiraValidationError, match="boardId.*sprintName"):
            _handle_search_sprint(client, {})

    def test_default_state_is_active(self):
        client = MagicMock()
        client.search_sprint.return_value = []
        _handle_search_sprint(
            client,
            {"boardId": "10", "sprintName": "Sprint 1"},
        )
        client.search_sprint.assert_called_once_with(
            board_id="10",
            sprint_name="Sprint 1",
            state="active",
        )


# --- register_tools integration ---


class TestRegisterTools:
    def test_registers_list_tools_and_call_tool(self):
        app = Server("test-jira")
        client = MagicMock()
        register_tools(app, client)
        assert app.list_tools is not None
        assert app.call_tool is not None


# --- Error handling via call_tool ---


class TestCallToolErrorHandling:
    """Tests that errors from JiraClient propagate as exceptions."""

    @pytest.fixture
    def app_and_client(self):
        app = Server("test-jira")
        client = MagicMock()
        register_tools(app, client)
        return app, client

    def _get_call_tool_handler(self, app):
        from mcp.types import CallToolRequest
        return app.request_handlers[CallToolRequest]

    def _make_request(self, name, arguments):
        from mcp.types import CallToolRequest, CallToolRequestParams
        return CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name=name, arguments=arguments),
        )

    @pytest.mark.asyncio
    async def test_validation_error_returns_is_error(self, app_and_client):
        app, client = app_and_client
        handler = self._get_call_tool_handler(app)
        req = self._make_request(
            "jira_create_issue",
            {"projectKey": "", "summary": "", "description": "", "issueType": "Bug"},
        )
        result = await handler(req)
        assert result.root.isError is True
        assert "obrigatórios ausentes" in result.root.content[0].text

    @pytest.mark.asyncio
    async def test_connection_error_returns_is_error(self, app_and_client):
        app, client = app_and_client
        client.search_issues.side_effect = JiraConnectionError(
            "Falha de conexão com o Jira em https://jira.example.com"
        )
        handler = self._get_call_tool_handler(app)
        req = self._make_request("jira_search", {"jql": "project=X"})
        result = await handler(req)
        assert result.root.isError is True
        assert "Falha de conexão" in result.root.content[0].text

    @pytest.mark.asyncio
    async def test_auth_error_returns_is_error(self, app_and_client):
        app, client = app_and_client
        client.create_issue.side_effect = JiraAuthError("Credenciais inválidas")
        handler = self._get_call_tool_handler(app)
        req = self._make_request(
            "jira_create_issue",
            {
                "projectKey": "PROJ",
                "summary": "Test",
                "description": "Desc",
                "issueType": "Bug",
            },
        )
        result = await handler(req)
        assert result.root.isError is True
        assert "autenticação" in result.root.content[0].text.lower()

    @pytest.mark.asyncio
    async def test_unknown_tool_returns_is_error(self, app_and_client):
        app, client = app_and_client
        handler = self._get_call_tool_handler(app)
        req = self._make_request("nonexistent_tool", {})
        result = await handler(req)
        assert result.root.isError is True
        assert "desconhecida" in result.root.content[0].text

    @pytest.mark.asyncio
    async def test_successful_call_returns_is_error_false(self, app_and_client):
        app, client = app_and_client
        client.search_issues.return_value = []
        handler = self._get_call_tool_handler(app)
        req = self._make_request("jira_search", {"jql": "project=X"})
        result = await handler(req)
        assert result.root.isError is False
