"""Cliente HTTP do Jira com autenticação Basic Auth via REST API v2.

Usa header Authorization: Basic <token> direto na API REST.
Simples, sem estado, sem gerenciamento de sessão.
"""

import logging
import os
import re
from pathlib import Path

import requests

# Threshold em caracteres para salvar campo em arquivo TXT ao invés de inline.
# Campos com texto acima desse limite são salvos em arquivo e o path é retornado.
# Configurável via variável de ambiente JIRA_LARGE_FIELD_THRESHOLD (0 = desabilita).
LARGE_FIELD_THRESHOLD = int(os.environ.get("JIRA_LARGE_FIELD_THRESHOLD", "5000"))

logger = logging.getLogger(__name__)


# --- Exceções ---


class JiraError(Exception):
    """Erro base para operações do Jira."""


class JiraConnectionError(JiraError):
    """Falha de conexão com o Jira."""


class JiraAuthError(JiraError):
    """Falha de autenticação no Jira."""


class JiraValidationError(JiraError):
    """Erro de validação de campos."""


# --- Cliente ---


class JiraClient:
    """Cliente HTTP para Jira via REST API v2 com Basic Auth."""

    def __init__(self, jira_url: str, token: str) -> None:
        self.jira_url = jira_url.rstrip("/")
        self._headers = {
            "Authorization": f"Basic {token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
        timeout: int = 30,
    ) -> requests.Response:
        """Executa request na REST API v2."""
        url = f"{self.jira_url}{path}"

        headers = dict(self._headers)
        # GET não deve enviar Content-Type (não tem body).
        # Algumas APIs (ex: Xray/Raven) podem se comportar de forma
        # inesperada quando recebem Content-Type em GET.
        if method.upper() == "GET":
            headers.pop("Content-Type", None)

        response = requests.request(
            method,
            url,
            headers=headers,
            json=json,
            params=params,
            timeout=timeout,
        )

        if response.status_code == 401:
            raise JiraAuthError("Token inválido ou expirado (401)")
        if response.status_code == 403:
            raise JiraAuthError("Sem permissão para esta operação (403)")

        return response

    def _maybe_save_to_file(
        self, issue_key: str, field_name: str, content: str,
        output_dir: str | None = None,
    ) -> str:
        """Salva conteúdo em arquivo TXT se exceder o threshold.

        Retorna o conteúdo original se abaixo do threshold, ou o path do arquivo salvo.
        Se output_dir não for informado, resolve automaticamente para o cwd do processo.
        """
        if LARGE_FIELD_THRESHOLD <= 0 or len(content) <= LARGE_FIELD_THRESHOLD:
            return content

        if not output_dir:
            output_dir = str(Path.cwd())

        safe_name = re.sub(r"[^\w\-]", "_", field_name).strip("_")
        out_dir = Path(output_dir) / ".jira_fields" / issue_key
        out_dir.mkdir(parents=True, exist_ok=True)
        file_path = out_dir / f"{safe_name}.txt"
        file_path.write_text(content, encoding="utf-8")
        resolved = str(file_path.resolve())
        logger.info("Campo '%s' salvo em %s (%d chars)", field_name, resolved, len(content))
        return f"[conteúdo salvo em arquivo: {resolved}]"



    @staticmethod
    def _extract_custom_field_value(field_value: object) -> str | None:
        """Extrai valor legível de um campo customizado do Jira.

        Suporta strings, dicts (com value/name), listas de dicts e listas simples.
        Retorna None se o valor não for relevante.
        """
        if isinstance(field_value, str):
            clean = re.sub(r"<[^>]+>", "", field_value).strip()
            return clean if clean else None

        if isinstance(field_value, dict):
            return str(field_value.get("value", field_value.get("name", ""))) or None

        if isinstance(field_value, list) and field_value:
            parts = []
            for item in field_value:
                if isinstance(item, dict):
                    val = item.get("value", item.get("name", ""))
                    if val:
                        parts.append(str(val))
                elif isinstance(item, str):
                    parts.append(item)
            return ", ".join(parts) if parts else None

        return None

    def get_issue(self, issue_key: str, output_dir: str | None = None) -> dict:
        """Busca uma issue pelo key."""
        response = self._request(
            "GET",
            f"/rest/api/2/issue/{issue_key}",
            params={"expand": "names,renderedFields"},
        )
        response.raise_for_status()

        data = response.json()
        fields = data.get("fields", {})
        names = data.get("names", {})

        # Coleta campos customizados relevantes (sem truncamento)
        custom_fields = {}
        for field_key, field_value in fields.items():
            if field_key.startswith("customfield_") and field_value:
                field_name = names.get(field_key, field_key)
                extracted = self._extract_custom_field_value(field_value)
                if extracted:
                    custom_fields[field_name] = self._maybe_save_to_file(
                        issue_key, field_name, extracted, output_dir=output_dir
                    )

        status_obj = fields.get("status", {})
        priority_obj = fields.get("priority", {})
        issuetype_obj = fields.get("issuetype", {})
        assignee_obj = fields.get("assignee") or {}
        reporter_obj = fields.get("reporter") or {}

        description = fields.get("description", "") or ""
        if isinstance(description, str):
            description = re.sub(r"<[^>]+>", "", description).strip()

        description = self._maybe_save_to_file(issue_key, "description", description, output_dir=output_dir)

        return {
            "key": data.get("key", issue_key),
            "summary": fields.get("summary", f"Issue {issue_key}"),
            "description": description,
            "status": status_obj.get("name", "") if isinstance(status_obj, dict) else str(status_obj),
            "priority": priority_obj.get("name", "") if isinstance(priority_obj, dict) else str(priority_obj),
            "issuetype": issuetype_obj.get("name", "") if isinstance(issuetype_obj, dict) else str(issuetype_obj),
            "assignee": assignee_obj.get("displayName", "Não atribuído"),
            "reporter": reporter_obj.get("displayName", ""),
            "created": fields.get("created", ""),
            "updated": fields.get("updated", ""),
            "labels": fields.get("labels", []),
            "components": [c.get("name", "") for c in fields.get("components", [])],
            "custom_fields": custom_fields,
            "url": f"{self.jira_url}/browse/{data.get('key', issue_key)}",
        }

    def _resolve_custom_field_ids(self, project_key: str, issue_type_name: str) -> dict[str, dict]:
        """Retorna mapa {nome_campo_lower: {id, schema}} para campos customizados."""
        response = self._request(
            "GET",
            "/rest/api/2/issue/createmeta",
            params={
                "projectKeys": project_key,
                "issuetypeNames": issue_type_name,
                "expand": "projects.issuetypes.fields",
            },
        )
        if response.status_code != 200:
            return {}

        result: dict[str, dict] = {}
        data = response.json()
        for project in data.get("projects", []):
            for issuetype in project.get("issuetypes", []):
                for field_key, field_info in issuetype.get("fields", {}).items():
                    if field_key.startswith("customfield_"):
                        schema = field_info.get("schema", {})
                        result[field_info.get("name", "").lower()] = {
                            "id": field_key,
                            "type": schema.get("type", ""),
                            "items": schema.get("items", ""),
                            "custom": schema.get("custom", ""),
                        }
        return result

    def create_issue(
        self,
        project_key: str,
        summary: str,
        description: str,
        issue_type: str = "Bug",
        priority: str | None = None,
        labels: list[str] | None = None,
        components: list[str] | None = None,
        custom_fields: dict[str, object] | None = None,
    ) -> dict:
        """Cria uma nova issue no Jira."""
        missing = []
        if not project_key:
            missing.append("project_key")
        if not summary:
            missing.append("summary")
        if not description:
            missing.append("description")
        if missing:
            raise JiraValidationError(
                f"Campos obrigatórios ausentes: {', '.join(missing)}"
            )

        fields: dict = {
            "project": {"key": project_key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": issue_type},
        }
        if priority:
            fields["priority"] = {"name": priority}
        if labels:
            fields["labels"] = labels
        if components:
            fields["components"] = [{"name": c} for c in components]

        # Resolve campos customizados: IDs técnicos passam direto, nomes legíveis via createmeta
        if custom_fields:
            technical_fields = {}
            named_fields = {}
            for key, value in custom_fields.items():
                if re.match(r"^customfield_\d+$", key):
                    technical_fields[key] = value
                else:
                    named_fields[key] = value

            # IDs técnicos: passthrough direto (sem conversão)
            for field_id, field_value in technical_fields.items():
                fields[field_id] = field_value

            # Nomes legíveis: resolução via createmeta (lógica existente)
            if named_fields:
                meta = self._resolve_custom_field_ids(project_key, issue_type)
                for field_name, field_value in named_fields.items():
                    field_meta = meta.get(field_name.lower())
                    if not field_meta:
                        continue
                    field_id = field_meta["id"]
                    field_type = field_meta.get("type", "")
                    field_custom = field_meta.get("custom", "")

                    # nFeed/SQLFeed fields: enviar como array de IDs (strings)
                    if "nfeed" in field_custom.lower() or "sqlfeed" in field_custom.lower():
                        if isinstance(field_value, list):
                            fields[field_id] = field_value
                        else:
                            fields[field_id] = [str(field_value)]
                    # Select list (single): enviar como {"id": "valor"}
                    elif field_type == "option":
                        fields[field_id] = {"id": str(field_value)}
                    # Select list (multiple): enviar como [{"id": "valor"}]
                    elif field_type == "array" and field_meta.get("items") == "option":
                        if isinstance(field_value, list):
                            fields[field_id] = [{"id": str(v)} for v in field_value]
                        else:
                            fields[field_id] = [{"id": str(field_value)}]
                    else:
                        fields[field_id] = field_value

        response = self._request("POST", "/rest/api/2/issue", json={"fields": fields})

        if response.status_code in (200, 201):
            data = response.json()
            return {
                "key": data["key"],
                "url": f"{self.jira_url}/browse/{data['key']}",
            }

        # Tenta extrair mensagem de erro do Jira
        try:
            error_data = response.json()
            errors = error_data.get("errors", {})
            messages = error_data.get("errorMessages", [])
            detail = "; ".join(
                [f"{k}: {v}" for k, v in errors.items()] + messages
            )
        except Exception:
            detail = response.text[:300]

        raise JiraError(f"Erro ao criar issue (status {response.status_code}): {detail}")

    def search_issues(
        self,
        jql: str,
        max_results: int = 50,
        fields: list[str] | None = None,
    ) -> list[dict]:
        """Busca issues via JQL."""
        params: dict = {
            "jql": jql,
            "maxResults": max_results,
        }
        if fields:
            params["fields"] = ",".join(fields)

        response = self._request("GET", "/rest/api/2/search", params=params)
        response.raise_for_status()
        return response.json().get("issues", [])

    def update_issue(self, issue_key: str, fields: dict) -> None:
        """Atualiza campos de uma issue existente."""
        response = self._request(
            "PUT",
            f"/rest/api/2/issue/{issue_key}",
            json={"fields": fields},
        )

        if response.status_code not in (200, 204):
            try:
                detail = str(response.json())
            except Exception:
                detail = response.text[:300]
            raise JiraError(
                f"Erro ao atualizar {issue_key} (status {response.status_code}): {detail}"
            )

    def list_issue_types(self, project_key: str | None = None) -> list[dict]:
        """Lista os tipos de issue disponíveis, opcionalmente filtrados por projeto."""
        if project_key:
            response = self._request(
                "GET",
                f"/rest/api/2/project/{project_key}",
            )
            if response.status_code == 200:
                data = response.json()
                return [
                    {"id": it.get("id", ""), "name": it.get("name", ""), "subtask": it.get("subtask", False)}
                    for it in data.get("issueTypes", [])
                ]
            try:
                detail = str(response.json())
            except Exception:
                detail = response.text[:300]
            raise JiraError(
                f"Erro ao buscar tipos do projeto {project_key} (status {response.status_code}): {detail}"
            )

        response = self._request("GET", "/rest/api/2/issuetype")
        response.raise_for_status()
        return [
            {"id": it.get("id", ""), "name": it.get("name", ""), "subtask": it.get("subtask", False)}
            for it in response.json()
        ]

    def add_comment(self, issue_key: str, body: str) -> dict:
        """Adiciona um comentário a uma issue."""
        response = self._request(
            "POST",
            f"/rest/api/2/issue/{issue_key}/comment",
            json={"body": body},
        )

        if response.status_code in (200, 201):
            return response.json()

        try:
            detail = str(response.json())
        except Exception:
            detail = response.text[:300]
        raise JiraError(
            f"Erro ao comentar em {issue_key} (status {response.status_code}): {detail}"
        )
    def list_comments(self, issue_key: str) -> list[dict]:
        """Lista os comentários de uma issue."""
        if not issue_key:
            raise JiraValidationError("Campo obrigatório ausente: issue_key")

        response = self._request(
            "GET",
            f"/rest/api/2/issue/{issue_key}/comment",
        )
        response.raise_for_status()

        comments = response.json().get("comments", [])
        return [
            {
                "id": c.get("id", ""),
                "body": c.get("body", ""),
                "author": {
                    "name": c.get("author", {}).get("displayName", ""),
                    "username": c.get("author", {}).get("name", ""),
                },
                "created": c.get("created", ""),
                "updated": c.get("updated", ""),
            }
            for c in comments
        ]

    def list_comments(self, issue_key: str) -> list[dict]:
        """Lista os comentários de uma issue."""
        if not issue_key:
            raise JiraValidationError("Campo obrigatório ausente: issue_key")

        response = self._request(
            "GET",
            f"/rest/api/2/issue/{issue_key}/comment",
        )
        response.raise_for_status()

        comments = response.json().get("comments", [])
        return [
            {
                "id": c.get("id", ""),
                "body": c.get("body", ""),
                "author": {
                    "name": c.get("author", {}).get("displayName", ""),
                    "username": c.get("author", {}).get("name", ""),
                },
                "created": c.get("created", ""),
                "updated": c.get("updated", ""),
            }
            for c in comments
        ]

    def list_components(self, project_key: str) -> list[dict]:
        """Lista os componentes (funcionalidades) disponíveis em um projeto."""
        if not project_key:
            raise JiraValidationError("Campo obrigatório ausente: project_key")

        response = self._request(
            "GET",
            f"/rest/api/2/project/{project_key}/components",
        )

        if response.status_code == 200:
            return [
                {"id": c.get("id", ""), "name": c.get("name", ""), "description": c.get("description", "")}
                for c in response.json()
            ]

        try:
            detail = str(response.json())
        except Exception:
            detail = response.text[:300]
        raise JiraError(
            f"Erro ao buscar componentes do projeto {project_key} (status {response.status_code}): {detail}"
        )

    def list_custom_field_options(self, project_key: str, issue_type_name: str, field_name: str) -> list[dict]:
        """Lista as opções de um campo customizado para um projeto e tipo de issue."""
        if not project_key or not issue_type_name or not field_name:
            raise JiraValidationError("Campos obrigatórios: project_key, issue_type_name, field_name")

        # Busca metadados de criação para encontrar o field_id e allowedValues
        response = self._request(
            "GET",
            "/rest/api/2/issue/createmeta",
            params={
                "projectKeys": project_key,
                "issuetypeNames": issue_type_name,
                "expand": "projects.issuetypes.fields",
            },
        )

        if response.status_code != 200:
            try:
                detail = str(response.json())
            except Exception:
                detail = response.text[:300]
            raise JiraError(
                f"Erro ao buscar metadados de criação (status {response.status_code}): {detail}"
            )

        data = response.json()
        field_name_lower = field_name.lower()
        field_id = None
        project_id = None
        issue_type_id = None

        for project in data.get("projects", []):
            p_id = project.get("id", "")
            for issuetype in project.get("issuetypes", []):
                it_id = issuetype.get("id", "")
                # Guardar IDs do projeto/issuetype para fallback nFeed
                if project_id is None:
                    project_id = p_id
                    issue_type_id = it_id
                fields = issuetype.get("fields", {})
                for field_key, field_info in fields.items():
                    if field_info.get("name", "").lower() == field_name_lower:
                        field_id = field_key
                        project_id = p_id
                        issue_type_id = it_id
                        allowed = field_info.get("allowedValues", [])
                        if allowed:
                            return [
                                {
                                    "id": v.get("id", ""),
                                    "name": v.get("name", v.get("value", "")),
                                    "value": v.get("value", v.get("name", "")),
                                }
                                for v in allowed
                            ]

        # Fallback: tenta API do nFeed (plugin de campos dinâmicos)
        if field_id and field_id.startswith("customfield_") and project_id and issue_type_id:
            return self._list_nfeed_options(field_id, project_id, issue_type_id)

        # Se não encontrou o campo no createmeta, tenta buscar o field_id via /rest/api/2/field
        if not field_id:
            field_id = self._find_field_id_by_name(field_name)
            if field_id and project_id and issue_type_id:
                return self._list_nfeed_options(field_id, project_id, issue_type_id)

        return []

    def _find_field_id_by_name(self, field_name: str) -> str | None:
        """Busca o ID de um campo pelo nome via /rest/api/2/field."""
        response = self._request("GET", "/rest/api/2/field")
        if response.status_code != 200:
            return None
        field_name_lower = field_name.lower()
        for field in response.json():
            if field.get("name", "").lower() == field_name_lower:
                return field.get("id")
        return None

    def _list_nfeed_options(self, field_id: str, project_id: str, issue_type_id: str) -> list[dict]:
        """Busca opções de um campo nFeed/Elements Connect via API REST do plugin.

        Usa o endpoint POST /rest/nfeed/3.0/nFeed/field/input/options com o body
        exato que o frontend do Jira envia, incluindo fieldContext e formData.
        Suporta paginação automática via hasNext/startIndex.
        """
        all_options: list[dict] = []
        start_index = 0

        while True:
            body = {
                "customFieldId": field_id,
                "userInput": "",
                "view": "EDIT",
                "fieldContext": {
                    "issueCreateProjectId": str(project_id),
                    "issueCreateIssueTypeId": str(issue_type_id),
                },
                "formData": {
                    "pid": [str(project_id)],
                    field_id: [""],
                },
                "startIndex": start_index,
            }

            response = self._request(
                "POST",
                "/rest/nfeed/3.0/nFeed/field/input/options",
                json=body,
            )

            if response.status_code != 200:
                logger.warning(
                    "nFeed options request failed (status %d): %s",
                    response.status_code,
                    response.text[:300],
                )
                return all_options

            data = response.json()
            options = data.get("options", [])

            for opt in options:
                opt_id = str(opt.get("id", ""))
                values = opt.get("values", [])
                name = values[0] if values else opt_id
                all_options.append({
                    "id": opt_id,
                    "name": name,
                    "value": opt_id,
                })

            if not data.get("hasNext", False):
                break

            start_index += len(options)

        return all_options

    def nfeed_search(
        self,
        field_id: str,
        query: str,
        project_id: str,
        issue_type_id: str,
    ) -> list[dict]:
        """Busca opções de um campo nFeed/Elements Connect filtrando por texto.

        Similar a _list_nfeed_options, mas envia `query` como userInput para
        filtrar resultados no servidor. Retorna formato simplificado com id/label.
        Suporta paginação automática via hasNext/startIndex.
        """
        all_options: list[dict] = []
        start_index = 0

        while True:
            body = {
                "customFieldId": field_id,
                "userInput": query,
                "view": "EDIT",
                "fieldContext": {
                    "issueCreateProjectId": str(project_id),
                    "issueCreateIssueTypeId": str(issue_type_id),
                },
                "formData": {
                    "pid": [str(project_id)],
                    field_id: [""],
                },
                "startIndex": start_index,
            }

            response = self._request(
                "POST",
                "/rest/nfeed/3.0/nFeed/field/input/options",
                json=body,
            )

            if response.status_code != 200:
                logger.warning(
                    "nFeed search request failed (status %d): %s",
                    response.status_code,
                    response.text[:300],
                )
                return all_options

            data = response.json()
            options = data.get("options", [])

            for opt in options:
                opt_id = str(opt.get("id", ""))
                values = opt.get("values", [])
                label = values[0] if values else opt_id
                all_options.append({
                    "id": opt_id,
                    "label": label,
                })

            if not data.get("hasNext", False):
                break

            start_index += len(options)

        return all_options

    def search_sprint(
        self,
        board_id: str,
        sprint_name: str,
        state: str = "active",
    ) -> list[dict]:
        """Busca sprints de um board Scrum por nome.

        Consulta a API Agile do Jira para listar sprints de um board,
        filtrando por nome (case-insensitive, substring match).
        Se state="active" e nenhum resultado for encontrado, faz fallback
        automático para state="future".

        Args:
            board_id: ID do board Scrum.
            sprint_name: Nome (ou parte) do sprint para filtrar.
            state: Estado dos sprints a buscar (default: "active").

        Returns:
            Lista de dicts com id, name, state, startDate e endDate.

        Raises:
            JiraError: Se a API retornar erro HTTP.
        """
        response = self._request(
            "GET",
            f"/rest/agile/1.0/board/{board_id}/sprint",
            params={"state": state},
        )

        if response.status_code != 200:
            try:
                detail = response.json()
            except Exception:
                detail = response.text[:300]
            raise JiraError(
                f"Erro ao buscar sprints do board {board_id} "
                f"(status {response.status_code}): {detail}"
            )

        sprints = response.json().get("values", [])
        search_lower = sprint_name.lower()
        matched = [
            {
                "id": s["id"],
                "name": s["name"],
                "state": s["state"],
                "startDate": s.get("startDate"),
                "endDate": s.get("endDate"),
            }
            for s in sprints
            if search_lower in s.get("name", "").lower()
        ]

        # Fallback: se state="active" e sem resultados, buscar "future"
        if not matched and state == "active":
            return self.search_sprint(board_id, sprint_name, state="future")

        return matched



    def list_attachments(self, issue_key: str) -> list[dict]:
        """Lista os anexos de uma issue."""
        if not issue_key:
            raise JiraValidationError("Campo obrigatório ausente: issue_key")

        response = self._request(
            "GET",
            f"/rest/api/2/issue/{issue_key}",
            params={"fields": "attachment"},
        )
        response.raise_for_status()

        attachments = response.json().get("fields", {}).get("attachment", [])
        return [
            {
                "id": att.get("id", ""),
                "filename": att.get("filename", ""),
                "size": att.get("size", 0),
                "mimeType": att.get("mimeType", ""),
                "created": att.get("created", ""),
                "author": att.get("author", {}).get("displayName", ""),
                "content": att.get("content", ""),
            }
            for att in attachments
        ]

    def download_attachment(
        self,
        issue_key: str,
        attachment_id: str | None = None,
        output_dir: str | None = None,
    ) -> list[dict]:
        """Baixa anexo(s) de uma issue para o diretório especificado.

        Se attachment_id for informado, baixa apenas esse anexo.
        Caso contrário, baixa todos os anexos da issue.
        Se output_dir não for informado, resolve automaticamente para o cwd do processo.

        Returns:
            Lista de dicts com filename e path dos arquivos baixados.
        """
        if not output_dir:
            output_dir = str(Path.cwd())

        attachments = self.list_attachments(issue_key)
        if not attachments:
            return []

        if attachment_id:
            attachments = [a for a in attachments if str(a["id"]) == str(attachment_id)]
            if not attachments:
                raise JiraValidationError(
                    f"Anexo {attachment_id} não encontrado na issue {issue_key}"
                )

        out_path = Path(output_dir)
        out_path.mkdir(parents=True, exist_ok=True)

        downloaded = []
        for att in attachments:
            content_url = att.get("content", "")
            if not content_url:
                continue

            resp = requests.get(
                content_url,
                headers={"Authorization": self._headers["Authorization"]},
                timeout=120,
                stream=True,
            )
            resp.raise_for_status()

            file_path = out_path / att["filename"]
            with open(file_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)

            downloaded.append({
                "filename": att["filename"],
                "path": str(file_path.resolve()),
                "size": att["size"],
            })

        return downloaded

    def list_test_set_tests(self, test_set_key: str) -> list[dict]:
        """Lista os test cases vinculados a um Test Set via API Xray/Raven.

        Tenta primeiro a API REST do Xray. Se falhar com erro de servidor
        (5xx), usa fallback via campo customizado da issue do Test Set.

        Args:
            test_set_key: Chave do Test Set (ex: PKWT-3593).

        Returns:
            Lista de dicts com key, summary e status de cada test case.

        Raises:
            JiraValidationError: Se test_set_key estiver vazio.
            JiraError: Se a API retornar erro.
        """
        if not test_set_key:
            raise JiraValidationError("test_set_key é obrigatório")

        path = f"/rest/raven/1.0/api/testset/{test_set_key}/test"
        response = self._request("GET", path)

        if response.status_code == 404:
            raise JiraError(f"Test Set '{test_set_key}' não encontrado (404)")

        # Erro de servidor (5xx) — fallback via campo customizado
        if response.status_code >= 500:
            return self._list_test_set_tests_fallback(test_set_key)

        if not response.ok:
            raise JiraError(
                f"Erro ao buscar test cases do Test Set {test_set_key}: "
                f"{response.status_code} - {response.text}"
            )

        tests = response.json()
        return [
            {
                "key": t.get("key", ""),
                "summary": t.get("summary", ""),
                "status": t.get("status", ""),
            }
            for t in tests
        ]

    def _list_test_set_tests_fallback(self, test_set_key: str) -> list[dict]:
        """Fallback: extrai test cases do campo customizado do Test Set.

        Quando a API Xray retorna 5xx (ex: NullPointerException), busca
        a issue do Test Set e lê as keys do campo 'Tests association with
        a Test Set', depois busca summary e status de cada test case via
        JQL em batch.
        """
        issue = self.get_issue(test_set_key)
        custom = issue.get("custom_fields", {})
        assoc = custom.get("Tests association with a Test Set", "")
        if not assoc:
            return []

        keys = [k.strip() for k in assoc.split(",") if k.strip()]
        if not keys:
            return []

        # Busca em batch via JQL
        keys_jql = ", ".join(keys)
        jql = f"key in ({keys_jql})"
        issues = self.search_issues(jql, fields=["summary", "status"],
                                    max_results=len(keys))

        results = []
        for item in issues:
            f = item.get("fields", {})
            status_obj = f.get("status", {})
            results.append({
                "key": item.get("key", ""),
                "summary": f.get("summary", ""),
                "status": status_obj.get("name", "") if isinstance(status_obj, dict) else str(status_obj),
            })
        return results


