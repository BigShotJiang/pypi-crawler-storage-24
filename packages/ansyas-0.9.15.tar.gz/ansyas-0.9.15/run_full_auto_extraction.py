#!/usr/bin/env python3
"""
FULLY AUTOMATED - PyAEDT 1.0.0rc1
Create Icepak simulation with gravity and extract temperatures automatically
"""

import os
import sys
import json
import time
import subprocess
from pathlib import Path
from datetime import datetime

sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import ansys.aedt.core as pyaedt
from Ansyas import Ansyas
import mas_autocomplete

# Configuration
OUTPUT_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\automated_temp_extraction'
MKF_TEST_FILE = r'\wsl.localhost\Ubuntu-22.04\home\alf\OpenMagnetics\MKF\tests\TestTemperature.cpp'
MAS_FILE = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'

os.makedirs(OUTPUT_DIR, exist_ok=True)

print("="*80)
print(f"FULLY AUTOMATED TEMPERATURE EXTRACTION - PyAEDT {pyaedt.__version__}")
print("="*80)

# Kill existing processes
print("\nCleaning up existing Ansys processes...")
subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], capture_output=True)
time.sleep(3)

# Load MAS
print("\nLoading MAS file...")
with open(MAS_FILE, 'r') as f:
    mas_dict = json.load(f)
mas = mas_autocomplete.autocomplete(mas_dict)
print("  [OK] MAS loaded")

# Create project
print("\nCreating Icepak project...")
ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project = ansyas.create_project(
    outputs_folder=OUTPUT_DIR,
    project_name="temp_extraction",
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=True
)

ansyas.set_units("meter")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)
print("  [OK] Geometry created")

# Enable gravity
print("\nEnabling gravity for natural convection...")
setup = project.setups[0]
setup.props['Include Gravity'] = True
setup.update()
print("  [OK] Gravity enabled (9.81 m/s² in -Z direction)")

# Run simulation
print("\nRunning thermal simulation...")
project.analyze_setup(setup.name)
print("  [OK] Simulation completed")

# Export temperature data
print("\nExporting temperature data...")
export_result = project.export_summary(
    output_dir=OUTPUT_DIR,
    solution_name=setup.name,
    type='Object',
    geometry_type='Volume',
    quantity='Temperature',
    filename='temperatures'
)

if export_result:
    print("  [OK] Temperature data exported")
else:
    print("  [ERROR] Export failed")
    sys.exit(1)

# Find and parse the exported file
print("\nReading exported temperature data...")
temp_file = os.path.join(OUTPUT_DIR, 'temperatures.csv')
temperatures = {}

if os.path.exists(temp_file):
    with open(temp_file, 'r') as f:
        lines = f.readlines()
    
    print(f"  Reading {len(lines)} lines from CSV")
    
    # Parse CSV - typically has headers and data rows
    # Format: Object, Min, Max, Avg, etc.
    for i, line in enumerate(lines[1:], 1):  # Skip header
        parts = line.strip().split(',')
        if len(parts) >= 4:
            obj_name = parts[0].strip()
            try:
                temp_avg = float(parts[3])  # Average temperature
                temperatures[obj_name] = temp_avg
                print(f"    {obj_name}: {temp_avg:.2f}°C")
            except (ValueError, IndexError):
                pass
else:
    print(f"  [WARNING] Temperature file not found: {temp_file}")
    print(f"  Files in output: {os.listdir(OUTPUT_DIR)}")

if not temperatures:
    print("  [ERROR] No temperatures extracted")
    sys.exit(1)

print(f"\n  [OK] Extracted {len(temperatures)} temperatures")

# Generate C++ test case
print("\nGenerating C++ test case...")

mas_basename = os.path.splitext(os.path.basename(MAS_FILE))[0]
test_name = f"AutoTemp_{mas_basename}_{int(time.time())}"

# Calculate statistics
core_temps = [t for name, t in temperatures.items() if 'core' in name.lower()]
bobbin_temps = [t for name, t in temperatures.items() if 'bobbin' in name.lower()]
turn_temps = [(name, t) for name, t in temperatures.items() 
              if any(kw in name.lower() for kw in ['turn', 'copper', 'primary', 'secondary'])]

avg_core = sum(core_temps) / len(core_temps) if core_temps else 0
max_core = max(core_temps) if core_temps else 0
min_core = min(core_temps) if core_temps else 0
avg_bobbin = sum(bobbin_temps) / len(bobbin_temps) if bobbin_temps else 0

cpp_code = f"""
// =============================================================================
// Auto-generated Icepak Temperature Test - PyAEDT {pyaedt.__version__}
// Source MAS: {mas_basename}
// Generated: {datetime.now().isoformat()}
// Method: Icepak thermal simulation with natural convection + gravity
// =============================================================================

TEST_F(TemperatureTests, {test_name}) {{
    // Load MAS file
    std::string masFile = "{MAS_FILE}";
    auto masData = OpenMagnetics::loadMas(masFile);
    
    // Configure thermal simulation
    OpenMagnetics::ThermalSimulation thermalSim;
    thermalSim.setMeshDensity(OpenMagnetics::MeshDensity::Medium);
    thermalSim.setConvergenceCriteria(5.0);
    thermalSim.setGravity(true);  // Enable gravity for natural convection
    
    // Run thermal simulation
    auto result = thermalSim.run(masData);
    
    // Reference values from Icepak (Icepak simulation with gravity)
    // Core temperatures
    EXPECT_NEAR(result.getCoreAverageTemperature(), {avg_core:.2f}, 10.0);
    EXPECT_NEAR(result.getCoreMaxTemperature(), {max_core:.2f}, 10.0);
    EXPECT_NEAR(result.getCoreMinTemperature(), {min_core:.2f}, 10.0);
    
    // Bobbin temperature
    EXPECT_NEAR(result.getBobbinTemperature(), {avg_bobbin:.2f}, 10.0);
    
    // Winding count
    EXPECT_EQ(result.getWindingCount(), {len(turn_temps)});
"""

# Add individual turn assertions
for name, temp in turn_temps[:5]:
    short_name = name.replace('Primary_Parallel_', 'P').replace('Secondary_Parallel_', 'S').replace('_copper', '')
    cpp_code += f"    EXPECT_NEAR(result.getWindingTemperature(\"{short_name}\"), {temp:.2f}, 15.0); // {name}\n"

if len(turn_temps) > 5:
    cpp_code += f"    // ... and {len(turn_temps) - 5} more winding temperature checks\n"

cpp_code += "}\n"

# Save test case
output_cpp_file = os.path.join(OUTPUT_DIR, f"test_{mas_basename}.cpp")
with open(output_cpp_file, 'w') as f:
    f.write(cpp_code)

print(f"  [OK] Test saved to: {output_cpp_file}")

# Append to MKF test file
try:
    if os.path.exists(MKF_TEST_FILE):
        with open(MKF_TEST_FILE, 'r') as f:
            existing = f.read()
        
        # Check for duplicates
        if test_name in existing:
            print(f"  [INFO] Test '{test_name}' already exists")
        else:
            # Create backup
            import shutil
            backup = f"{MKF_TEST_FILE}.backup_{int(time.time())}"
            shutil.copy2(MKF_TEST_FILE, backup)
            
            # Append
            with open(MKF_TEST_FILE, 'a') as f:
                if not existing.endswith('\n'):
                    f.write('\n')
                f.write(cpp_code)
            
            print(f"  [OK] Test appended to: {MKF_TEST_FILE}")
    else:
        print(f"  [INFO] MKF test file not found, saved to output only")
except Exception as e:
    print(f"  [WARN] Could not append to MKF: {e}")

# Cleanup
project.save_project()
ansyas.solver_backend.close()

print("\n" + "="*80)
print("COMPLETE!")
print("="*80)
print(f"Temperatures extracted: {len(temperatures)}")
print(f"Test case: {test_name}")
print(f"Output: {OUTPUT_DIR}")
print("\nThe test has been appended to TestTemperature.cpp")
