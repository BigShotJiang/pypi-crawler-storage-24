#!/usr/bin/env python3
"""
Check where turns are stored after mas_autocomplete
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import json
import mas_autocomplete as ansyas_mas

# Load MAS file
mas_file = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'
with open(mas_file, 'r') as f:
    mas_dict = json.load(f)

print("Before mas_autocomplete:")
print(f"  turnsDescription: {len(mas_dict.get('magnetic', {}).get('coil', {}).get('turnsDescription', []))} items")

# Try Ansyas mas_autocomplete
mas = ansyas_mas.autocomplete(mas_dict)

print("\nAfter mas_autocomplete:")
coil = mas.magnetic.coil
print(f"  coil type: {type(coil)}")
print(f"  coil attributes: {[attr for attr in dir(coil) if not attr.startswith('_')]}")

if hasattr(coil, 'turnsDescription'):
    print(f"  turnsDescription: {len(coil.turnsDescription)} items")
    if coil.turnsDescription:
        print(f"    First turn: {coil.turnsDescription[0]}")

if hasattr(coil, 'functionalDescription'):
    print(f"\n  functionalDescription: {len(coil.functionalDescription)} windings")
    for i, winding in enumerate(coil.functionalDescription):
        print(f"    Winding {i}:")
        print(f"      attributes: {[attr for attr in dir(winding) if not attr.startswith('_')][:10]}")
        if hasattr(winding, 'turns'):
            print(f"      turns: {len(winding.turns)} items")
        if hasattr(winding, 'numberTurns'):
            print(f"      numberTurns: {winding.numberTurns}")

print("\n\nChecking MAS.to_dict():")
mas_dict_out = mas.to_dict()
print(f"  magnetic.coil keys: {list(mas_dict_out.get('magnetic', {}).get('coil', {}).keys())}")
coil_out = mas_dict_out.get('magnetic', {}).get('coil', {})
print(f"  turnsDescription count: {len(coil_out.get('turnsDescription', []))}")

print("\nDone!")
