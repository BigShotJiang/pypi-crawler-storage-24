#!/usr/bin/env python3
"""
Test runner for generate_temperature_tests.py
This creates a temporary test environment to demonstrate the script.
"""

import json
import os
import sys
from pathlib import Path
from datetime import datetime

# Add the script directory to path
sys.path.insert(0, str(Path(__file__).parent))

# Import the functions from the generator script
# We'll manually define them here for testing

def parse_mas_file(filepath):
    """Parse a MAS JSON file and extract component information."""
    with open(filepath, 'r') as f:
        data = json.load(f)
    
    magnetic = data.get('magnetic', {})
    core = magnetic.get('core', {})
    coil = magnetic.get('coil', {})
    
    # Extract core info
    core_functional = core.get('functionalDescription', {})
    shape = core_functional.get('shape', {})
    core_shape = shape.get('name', 'Unknown')
    core_material = core_functional.get('material', 'N87')
    
    # Check if toroidal
    is_toroidal = shape.get('family', '') == 't'
    
    # Extract coil info
    functional_desc = coil.get('functionalDescription', [])
    num_turns = [w.get('numberTurns', 0) for w in functional_desc]
    num_windings = len(num_turns)
    
    # Check for bobbin
    bobbin = coil.get('bobbin', {})
    has_bobbin = isinstance(bobbin, dict) and bobbin.get('processedDescription') is not None
    
    return {
        'filename': filepath.stem,
        'core_shape': core_shape,
        'core_material': core_material,
        'num_turns': num_turns,
        'num_windings': num_windings,
        'is_toroidal': is_toroidal,
        'has_bobbin': has_bobbin
    }

def generate_test_name(info):
    """Generate a unique test name from component info."""
    shape_clean = info['core_shape'].replace(' ', '_').replace('/', '_')
    
    parts = ["Temperature"]
    
    if info['is_toroidal']:
        parts.append("Toroidal")
    else:
        parts.append("Concentric")
    
    parts.append(shape_clean)
    
    if info['num_windings'] > 1:
        parts.append(f"{info['num_windings']}W")
    
    parts.append(f"{sum(info['num_turns'])}T")
    
    if info['has_bobbin']:
        parts.append("Bobbin")
    
    parts.append("Icepak")
    
    return "_".join(parts)

def main():
    print("=" * 70)
    print("Testing generate_temperature_tests.py")
    print("=" * 70)
    print()
    
    # Path to the example file
    example_file = Path("C:/Users/Alfonso/wuerth/Ansyas/examples/concentric_transformer.json")
    
    if not example_file.exists():
        print(f"ERROR: Example file not found: {example_file}")
        print("Looking for file...")
        # Try to find it
        examples_dir = Path("C:/Users/Alfonso/wuerth/Ansyas/examples")
        if examples_dir.exists():
            print(f"Examples directory exists: {examples_dir}")
            files = list(examples_dir.glob("*.json"))
            print(f"Found {len(files)} JSON files:")
            for f in files:
                print(f"  - {f.name}")
        return
    
    print(f"✓ Found example file: {example_file}")
    print()
    
    # Parse the MAS file
    print("Parsing MAS file...")
    info = parse_mas_file(example_file)
    
    print(f"  Filename: {info['filename']}")
    print(f"  Core Shape: {info['core_shape']}")
    print(f"  Core Material: {info['core_material']}")
    print(f"  Number of Windings: {info['num_windings']}")
    print(f"  Turns per Winding: {info['num_turns']}")
    print(f"  Is Toroidal: {info['is_toroidal']}")
    print(f"  Has Bobbin: {info['has_bobbin']}")
    print()
    
    # Generate test name
    test_name = generate_test_name(info)
    print(f"Generated Test Name: {test_name}")
    print()
    
    # Show what the test would look like
    print("=" * 70)
    print("Generated C++ Test Code Preview:")
    print("=" * 70)
    print()
    
    cpp_test = f'''TEST_CASE("{test_name}", "[temperature][icepak-validation][smoke-test]") {{
    // Icepak validation test generated on {datetime.now().strftime("%Y-%m-%d %H:%M")}
    // Source MAS file: {info['filename']}.json
    // Core: {info['core_shape']} ({info['core_material']})
    // Windings: {info['num_windings']} with turns: {info['num_turns']}
    
    std::vector<int64_t> numberTurns({{{', '.join(map(str, info['num_turns']))}}});
    std::vector<int64_t> numberParallels({{{', '.join(['1'] * info['num_windings'])}}});
    std::string shapeName = "{info['core_shape']}";

    auto coil = OpenMagneticsTesting::get_quick_coil(numberTurns,
                                                     numberParallels,
                                                     shapeName,
                                                     1,
                                                     WindingOrientation::OVERLAPPING,
                                                     WindingOrientation::OVERLAPPING,
                                                     CoilAlignment::SPREAD,
                                                     CoilAlignment::SPREAD);

    std::string coreMaterial = "{info['core_material']}";
    auto gapping = json::array();
    auto core = OpenMagneticsTesting::get_quick_core(shapeName, gapping, 1, coreMaterial);
    
    OpenMagnetics::Magnetic magnetic;
    magnetic.set_core(core);
    magnetic.set_coil(coil);

    // For toroidal cores, wind to generate turn coordinates
    if (core.get_shape_family() == MAS::CoreShapeFamily::T) {{
        magnetic.get_mutable_coil().wind();
    }}

    TemperatureConfig config;
    config.ambientTemperature = 25.0;
    config.coreLosses = 1.0;  // TODO: Replace with Icepak extracted value
    applySimulatedLosses(config, magnetic);
    config.plotSchematic = false;
    
    Temperature temp(magnetic, config);
    auto result = temp.calculateTemperatures();
    
    REQUIRE(result.converged);
    REQUIRE(result.maximumTemperature > config.ambientTemperature);
    
    // Icepak reference thermal resistance validation
    // TODO: Add specific temperature checks for:
    // - Core Central Column
    // - Core Lateral Column  
    // - Core Top Yoke
    // - Core Bottom Yoke
    // - Bobbin parts (if present)
    // - Individual turns
    REQUIRE(result.totalThermalResistance > 0.0);
}}
'''
    
    print(cpp_test)
    
    print("=" * 70)
    print("Test Generation Summary:")
    print("=" * 70)
    print()
    print("✓ Successfully parsed MAS file")
    print("✓ Generated unique test name")
    print("✓ Created C++ test code")
    print()
    print("Next steps:")
    print("1. Implement Icepak simulation extraction in the script")
    print("2. Run the script to append this test to TestTemperature.cpp")
    print("3. Compile and run the test to verify it works")
    print()
    print("To actually generate the test, run:")
    print("  python3 generate_temperature_tests.py")
    print()

if __name__ == "__main__":
    main()
