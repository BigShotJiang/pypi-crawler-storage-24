#!/usr/bin/env python3
"""
Test Ansyas mas_autocomplete vs PyOpenMagnetics
"""

import sys
import os
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import json
import mas_autocomplete as ansyas_mas

# Load MAS file
mas_file = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'
with open(mas_file, 'r') as f:
    mas_dict = json.load(f)

print("Original MAS structure:")
print(f"  Inputs: {list(mas_dict.get('inputs', {}).keys())}")
print(f"  Magnetic: {list(mas_dict.get('magnetic', {}).keys())}")

# Check coil
coil = mas_dict.get('magnetic', {}).get('coil', {})
print(f"  Coil keys: {list(coil.keys())}")

functional_desc = coil.get('functionalDescription', [])
print(f"  Functional descriptions: {len(functional_desc)}")
for i, winding in enumerate(functional_desc):
    print(f"    Winding {i}: {winding.get('numberTurns', 0)} turns, has turns array: {'turns' in winding}")

# Try Ansyas mas_autocomplete
print("\n\nTrying Ansyas mas_autocomplete...")
try:
    mas = ansyas_mas.autocomplete(mas_dict)
    print(f"  Success! Result type: {type(mas)}")
    
    # Check if turns were generated
    magnetic = mas.magnetic
    coil = magnetic.coil
    functional_desc = coil.functionalDescription
    print(f"\n  After autocomplete:")
    for i, winding in enumerate(functional_desc):
        turns_count = len(winding.turns) if hasattr(winding, 'turns') else 0
        print(f"    Winding {i}: {turns_count} turns in array")
        if turns_count > 0:
            print(f"      First turn: {winding.turns[0].name}")
            print(f"      Coordinates: {winding.turns[0].coordinates}")
except Exception as e:
    print(f"  ERROR: {e}")
    import traceback
    traceback.print_exc()

print("\nDone!")
