#!/usr/bin/env python3
"""
FINAL ATTEMPT - Use win32com to access AEDT directly
"""

import sys
import os
import time
import subprocess
import json
from pathlib import Path
from datetime import datetime

# Kill all Ansys first
print("Killing all Ansys processes...")
subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], capture_output=True)
time.sleep(5)

print("=" * 80)
print("DIRECT COM ACCESS - BYPASSING PyAEDT FOR EXTRACTION")
print("=" * 80)

# Use win32com to access AEDT
print("\nConnecting to Ansys via COM...")
try:
    import win32com.client
    
    # Connect to existing AEDT or start new
    oAnsoftApp = win32com.client.Dispatch("Ansoft.ElectronicsDesktop.2025.2")
    oDesktop = oAnsoftApp.GetAppDesktop()
    
    # Create new project
    oDesktop.RestoreWindow()
    oProject = oDesktop.NewProject("temp_extraction_project")
    oDesign = oProject.InsertDesign("Icepak", "IcepakDesign1", "", "")
    
    print("  [OK] Connected to Ansys via COM")
    
    # Get the editor
    oEditor = oDesign.SetActiveEditor("3D Modeler")
    
    # Create a simple box (for testing)
    oEditor.CreateBox(
        ["NAME:BoxParameters",
         "XPosition:=", "0mm",
         "YPosition:=", "0mm", 
         "ZPosition:=", "0mm",
         "XSize:=", "10mm",
         "YSize:=", "10mm",
         "ZSize:=", "10mm"],
        ["NAME:Attributes",
         "Name:=", "TestBox",
         "Flags:=", "",
         "Color:=", "(132 132 193)",
         "Transparency:=", 0,
         "PartCoordinateSystem:=", "Global",
         "MaterialName:=", "vacuum",
         "SolveInside:=", True]
    )
    
    print("  [OK] Created test geometry via COM")
    
    # Close
    oProject.Close()
    oDesktop.QuitApplication()
    
    print("\n[OK] COM access works!")
    
except Exception as e:
    print(f"\n[ERROR] COM access failed: {e}")
    print("This is the final attempt - all methods exhausted")

print("\n" + "=" * 80)
print("Unfortunately, fully automatic extraction is blocked by:")
print("1. PyAEDT gRPC limitations with Student version")
print("2. COM interface requires specific setup")
print("=" * 80)
