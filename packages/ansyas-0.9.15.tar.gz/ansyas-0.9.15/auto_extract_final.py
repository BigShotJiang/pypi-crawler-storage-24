#!/usr/bin/env python3
"""
FULLY AUTOMATED temperature extraction with gravity
Uses PyAEDT export_summary method (equivalent to IronPython script)
"""

import os
import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import json
import time
import ansys.aedt.core as pyaedt
from Ansyas import Ansyas
import mas_autocomplete

# Configuration
OUTPUT_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\auto_extract_final'
os.makedirs(OUTPUT_DIR, exist_ok=True)

MAS_FILE = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'

def main():
    print("="*80)
    print("FULLY AUTOMATED TEMPERATURE EXTRACTION WITH GRAVITY")
    print("="*80)
    
    # Load MAS
    print("\nLoading MAS file...")
    with open(MAS_FILE, 'r') as f:
        mas_dict = json.load(f)
    mas = mas_autocomplete.autocomplete(mas_dict)
    print("  [OK] MAS loaded")
    
    # Create project
    print("\nCreating Icepak project...")
    ansyas = Ansyas(
        number_segments_arcs=12,
        initial_mesh_configuration=2,
        maximum_error_percent=5,
        refinement_percent=30,
        maximum_passes=15,
        scale=1
    )
    
    project = ansyas.create_project(
        outputs_folder=OUTPUT_DIR,
        project_name="auto_extract_final",
        non_graphical=True,
        solution_type="SteadyState",
        new_desktop_session=True
    )
    
    ansyas.set_units("meter")
    ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)
    print("  [OK] Project created")
    
    # Enable gravity in setup
    print("\n" + "="*80)
    print("ENABLING GRAVITY")
    print("="*80)
    setup = project.setups[0]
    setup.props['Include Gravity'] = True
    setup.update()
    print("  [OK] Gravity enabled (9.81 m/s²)")
    
    # Run simulation
    print("\n" + "="*80)
    print("RUNNING SIMULATION")
    print("="*80)
    project.analyze_setup(setup.name)
    print("  [OK] Simulation completed")
    
    # Export temperature summary
    print("\n" + "="*80)
    print("EXPORTING TEMPERATURE DATA")
    print("="*80)
    
    try:
        # Use export_summary with correct parameters
        result = project.export_summary(
            output_dir=OUTPUT_DIR,
            solution_name=setup.name,
            type='Object',
            geometry_type='Volume',
            quantity='Temperature',
            filename='temperature_summary'
        )
        
        if result:
            print("  [OK] Temperature data exported successfully")
            
            # Read the exported file
            summary_file = os.path.join(OUTPUT_DIR, 'temperature_summary.csv')
            if os.path.exists(summary_file):
                print(f"\n  Exported file: {summary_file}")
                with open(summary_file, 'r') as f:
                    content = f.read()
                    print(f"  File size: {len(content)} bytes")
                    print("\n  Temperature Data:")
                    print("  " + "-"*60)
                    # Print first 20 lines
                    lines = content.split('\n')[:20]
                    for line in lines:
                        if line.strip():
                            print(f"  {line}")
                    print("  " + "-"*60)
            else:
                print(f"  [WARNING] Expected file not found: {summary_file}")
                # List files in output directory
                files = os.listdir(OUTPUT_DIR)
                print(f"  Files in output dir: {files}")
        else:
            print("  [ERROR] Export failed (returned False)")
            
    except Exception as e:
        print(f"  [ERROR] Export failed: {e}")
        import traceback
        traceback.print_exc()
    
    # Save project
    project.save_project()
    print(f"\n  Project saved: {project.project_path}")
    
    print("\n" + "="*80)
    print("COMPLETE!")
    print("="*80)
    
    ansyas.solver_backend.close()

if __name__ == "__main__":
    main()
