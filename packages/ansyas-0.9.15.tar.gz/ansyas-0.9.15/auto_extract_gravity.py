#!/usr/bin/env python3
"""
Enable gravity in setup and extract temperatures using PyAEDT
Based on IronPython script structure
"""

import sys
import os
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import json
import ansys.aedt.core as pyaedt
from Ansyas import Ansyas
import mas_autocomplete

# Configuration
OUTPUT_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\auto_extract'
os.makedirs(OUTPUT_DIR, exist_ok=True)

MAS_FILE = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'

print("="*80)
print("AUTO EXTRACTION WITH GRAVITY - PyAEDT")
print("="*80)

# Load MAS
with open(MAS_FILE, 'r') as f:
    mas_dict = json.load(f)
mas = mas_autocomplete.autocomplete(mas_dict)

# Create project
ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project = ansyas.create_project(
    outputs_folder=OUTPUT_DIR,
    project_name="auto_extract_gravity",
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=True
)

ansyas.set_units("meter")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)

print("\n" + "="*80)
print("Enabling Gravity in Setup")
print("="*80)

# Get the setup and enable gravity
setup = project.setups[0]
print(f"Setup name: {setup.name}")
print(f"Setup properties: {setup.props}")

# Try to enable gravity
# In PyAEDT, we can modify setup properties
try:
    # Check if gravity can be set through props
    if 'Gravity' in setup.props:
        setup.props['Gravity'] = [0, 0, -9.81]
        print("  [OK] Gravity set via props")
    elif 'Include Gravity' in setup.props:
        setup.props['Include Gravity'] = True
        setup.props['Gravity Vector'] = [0, 0, -9.81]
        print("  [OK] Gravity enabled via props")
    else:
        print(f"  Available props: {list(setup.props.keys())[:10]}")
        
    # Update the setup
    setup.update()
    print("  [OK] Setup updated")
    
except Exception as e:
    print(f"  [ERROR] Could not set gravity: {e}")

# Run simulation
print("\n" + "="*80)
print("Running Simulation")
print("="*80)
project.analyze_setup(setup.name)
print("  [OK] Simulation completed")

# Export solution data
print("\n" + "="*80)
print("Exporting Solution Data")
print("="*80)

try:
    # Try export_results
    export_file = os.path.join(OUTPUT_DIR, "solution_export.txt")
    result = project.export_results(
        setup_name=setup.name,
        output_file=export_file
    )
    print(f"  export_results result: {result}")
    
    if os.path.exists(export_file):
        print(f"  [OK] Export file created: {export_file}")
        with open(export_file, 'r') as f:
            content = f.read()
            print(f"  File size: {len(content)} bytes")
            print(f"  First 500 chars:\n{content[:500]}")
    
except Exception as e:
    print(f"  [ERROR] export_results failed: {e}")

try:
    # Try export_summary
    summary_file = os.path.join(OUTPUT_DIR, "solution_summary.txt")
    result = project.export_summary(
        output_file=summary_file
    )
    print(f"  export_summary result: {result}")
    
    if os.path.exists(summary_file):
        print(f"  [OK] Summary file created: {summary_file}")
        
except Exception as e:
    print(f"  [ERROR] export_summary failed: {e}")

try:
    # Try using odesign directly via project methods
    print("\n  Trying to access design methods...")
    
    # Check if we can access osolution
    if hasattr(project, 'osolution'):
        print("    osolution available")
        
except Exception as e:
    print(f"  [ERROR] {e}")

print("\n" + "="*80)
print("Done")
print("="*80)

ansyas.solver_backend.close()
