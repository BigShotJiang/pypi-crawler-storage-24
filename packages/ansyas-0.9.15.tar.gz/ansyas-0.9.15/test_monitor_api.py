#!/usr/bin/env python3
"""
Test get_monitor_data signature
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import ansys.aedt.core as pyaedt
from ansys.aedt.core import Icepak
import inspect

print("Testing get_monitor_data signature...")

# Check if get_monitor_data exists
if hasattr(Icepak, 'get_monitor_data'):
    print(f"get_monitor_data exists: Yes")
    print(f"Signature: {inspect.signature(Icepak.get_monitor_data)}")
    
    # Check monitor attribute
    if hasattr(Icepak, 'monitor'):
        print(f"\nmonitor attribute exists: Yes")
        print(f"Type: {type(Icepak.monitor)}")
        if hasattr(Icepak.monitor, 'get_monitor_data'):
            print(f"monitor.get_monitor_data signature: {inspect.signature(Icepak.monitor.get_monitor_data)}")
else:
    print("get_monitor_data not found directly on Icepak")

# Check for monitors property
if hasattr(Icepak, 'monitors'):
    print(f"\nmonitors property exists: Yes")

print("\nDone!")
