#!/usr/bin/env python3
"""
Test PyAEDT 1.0.0rc1 Icepak field summary extraction
"""

import sys
import os
import json
import time
import subprocess

# Kill any existing Ansys processes
print("Killing existing Ansys processes...")
subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], capture_output=True)
time.sleep(3)

# Add Ansyas to path
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import ansys.aedt.core as pyaedt
from Ansyas import AnsyasMasLoader

print(f"PyAEDT Version: {pyaedt.__version__}")
print()

# Test with a simple example
mas_file = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'

if not os.path.exists(mas_file):
    print(f"ERROR: MAS file not found: {mas_file}")
    sys.exit(1)

print(f"Loading MAS file: {mas_file}")

# Create output directory
output_dir = r'C:\Users\Alfonso\wuerth\Ansyas\output\test_field_summary'
os.makedirs(output_dir, exist_ok=True)

# Initialize Ansyas with Icepak
print("\nInitializing Ansyas with Icepak...")
try:
    loader = AnsyasMasLoader(
        output_path=output_dir,
        ansys_version="2025.2",
        non_graphical=True,
        solution_type="Icepak"
    )
    
    # Load MAS file
    loader.load(mas_file)
    print("  [OK] MAS file loaded")
    
    # Get the Icepak project
    project = loader.ansyas.project
    
    # Check if post.create_field_summary exists
    print(f"\nChecking post.create_field_summary...")
    print(f"  project type: {type(project)}")
    print(f"  Has post attribute: {hasattr(project, 'post')}")
    
    if hasattr(project, 'post'):
        print(f"  post type: {type(project.post)}")
        print(f"  Has create_field_summary: {hasattr(project.post, 'create_field_summary')}")
        
        if hasattr(project.post, 'create_field_summary'):
            print("\n  [OK] create_field_summary is available!")
            
            # Try to create field summary
            print("\n  Creating field summary...")
            try:
                fs = project.post.create_field_summary()
                print(f"    FieldSummary created: {type(fs)}")
                print(f"    Has add_calculation: {hasattr(fs, 'add_calculation')}")
                print(f"    Has get_field_summary_data: {hasattr(fs, 'get_field_summary_data')}")
                print(f"    Has export_csv: {hasattr(fs, 'export_csv')}")
                print("\n  [SUCCESS] Field summary extraction API is working!")
            except Exception as e:
                print(f"    [ERROR] Failed to create field summary: {e}")
        else:
            print("\n  [ERROR] create_field_summary not found in post processor")
    else:
        print("\n  [ERROR] project does not have post attribute")
    
    # Close project
    loader.close()
    print("\n[OK] Test completed successfully!")
    
except Exception as e:
    print(f"\n[ERROR] {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
