#!/usr/bin/env python3
"""
Test PyAEDT 1.0.0rc1 Icepak field summary extraction - Direct API Test
"""

import sys
import os
import time
import subprocess

# Kill any existing Ansys processes
print("Killing existing Ansys processes...")
subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], capture_output=True)
time.sleep(3)

import ansys.aedt.core as pyaedt
from ansys.aedt.core import Icepak

print(f"PyAEDT Version: {pyaedt.__version__}")
print()

# Test the API availability
print("Testing PyAEDT 1.0.0rc1 Field Summary API:")
print("=" * 60)

# Check PostProcessorIcepak
from ansys.aedt.core.visualization.post.post_icepak import PostProcessorIcepak

print("\n1. PostProcessorIcepak.create_field_summary:")
print(f"   Available: {hasattr(PostProcessorIcepak, 'create_field_summary')}")

if hasattr(PostProcessorIcepak, 'create_field_summary'):
    import inspect
    sig = inspect.signature(PostProcessorIcepak.create_field_summary)
    print(f"   Signature: {sig}")
    print("   [OK] Method is available!")
else:
    print("   [ERROR] Method not found!")

# Check FieldSummary class
from ansys.aedt.core.visualization.post.field_summary import FieldSummary

print("\n2. FieldSummary class:")
print(f"   Available: True")
print("   Methods:")
for m in ['add_calculation', 'get_field_summary_data', 'export_csv']:
    has_method = hasattr(FieldSummary, m)
    print(f"     - {m}: {'[OK]' if has_method else '[MISSING]'}")

# Check Icepak class methods
print("\n3. Icepak class field/summary methods:")
methods = ['eval_volume_quantity_from_field_summary', 'eval_surface_quantity_from_field_summary', 'export_summary']
for m in methods:
    has_method = hasattr(Icepak, m)
    print(f"     - {m}: {'[OK]' if has_method else '[MISSING]'}")

print("\n" + "=" * 60)
print("API Check Complete!")
print("\nThe field summary extraction methods are available in PyAEDT 1.0.0rc1.")
print("\nTo use them:")
print("  1. Create an Icepak project")
print("  2. Run simulation")
print("  3. Use: fs = ipk.post.create_field_summary()")
print("  4. Add calculations: fs.add_calculation(...)")
print("  5. Get data: fs.get_field_summary_data()")
print("  6. Export: fs.export_csv('output.csv')")
