#!/usr/bin/env python3
"""
Temperature extraction using alternative method
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

from pathlib import Path
import json
import time

print("=" * 80)
print("ALTERNATIVE TEMPERATURE EXTRACTION")
print("=" * 80)
print()

# Connect to existing project
output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/demo")

print("Connecting to completed project...")

from ansyas import Ansyas

ansyas = Ansyas()
project = ansyas.create_project(
    outputs_folder=str(output_path),
    project_name="demo_extraction",
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=False
)

print("[OK] Connected to project")
print()

# Get available objects
print("Objects in project:")
for name in sorted(project.modeler.objects.keys())[:10]:
    print(f"  - {name}")
print()

# Try to get temperature using post-processing
print("Attempting temperature extraction...")

try:
    post = project.post
    
    # Get setup
    if project.setups:
        setup_name = project.setups[0].name
        print(f"Setup: {setup_name}")
        
        # Try to get solution data
        try:
            solution_data = post.get_solution_data(
                expressions=["Temp"],
                setup_sweep_name=f"{setup_name} : LastAdaptive"
            )
            
            if solution_data:
                print(f"[OK] Got solution data")
                print(f"  Data magnitude: {solution_data.data_magnitude()}")
                
        except Exception as e:
            print(f"  get_solution_data failed: {e}")
        
        # Try alternative - create a simple report
        try:
            success = post.create_report(
                plot_name="TemperatureReport",
                expressions=["Temp"],
                setup_sweep_name=f"{setup_name} : LastAdaptive"
            )
            
            if success:
                print("[OK] Created temperature report")
                report_data = post.get_report_data("TemperatureReport")
                if report_data:
                    print(f"  Report data: {report_data.data_magnitude()}")
            else:
                print("  create_report returned False")
                
        except Exception as e:
            print(f"  create_report failed: {e}")
    else:
        print("  No setups found!")
        
except Exception as e:
    print(f"[ERROR] {e}")

print("\nClosing...")
try:
    project.release_desktop(close_projects=False, close_desktop=False)
except:
    pass

print("[OK] Complete")
