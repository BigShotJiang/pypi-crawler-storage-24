#!/usr/bin/env python3
"""
Simplified automatic extraction test
"""

import sys
import os
import time
import subprocess

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

print("SIMPLIFIED AUTO EXTRACTION TEST")
print("=" * 80)

# Kill processes
print("\nKilling Ansys...")
subprocess.run(["taskkill", "/F", "/IM", "ansys*.exe"], capture_output=True)
subprocess.run(["taskkill", "/F", "/IM", "Icepak*.exe"], capture_output=True)
time.sleep(5)

# Import and run
print("\nImporting modules...")
import json
from pathlib import Path

mas_file = Path("C:/Users/Alfonso/wuerth/Ansyas/examples/concentric_transformer.json")
print(f"Loading: {mas_file}")

with open(mas_file, 'r') as f:
    mas_dict = json.load(f)

print("Importing mas_autocomplete...")
import mas_autocomplete
mas = mas_autocomplete.autocomplete(mas_dict)

print("Importing Ansyas...")
from ansyas import Ansyas

print("Creating Ansyas instance...")
ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

print("Creating project...")
output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/simplified_test")
output_path.mkdir(parents=True, exist_ok=True)

project_name = f"simplified_{int(time.time())}"

print(f"  Project name: {project_name}")

try:
    project = ansyas.create_project(
        outputs_folder=str(output_path),
        project_name=project_name,
        non_graphical=True,  # Changed to True
        new_desktop_session=True,
        solution_type="SteadyState"
    )
    print("  [OK] Project created")
    
    print("\nSetting units...")
    ansyas.set_units("meter")
    print("  [OK] Units set to meters")
    
    print("\nBuilding geometry...")
    ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)
    print("  [OK] Geometry built")
    
    print("\nRunning simulation...")
    ansyas.analyze()
    print("  [OK] Simulation completed!")
    
    print("\nSaving project...")
    project.save_project()
    print("  [OK] Project saved")
    
    print("\n" + "=" * 80)
    print("SIMULATION SUCCESSFUL!")
    print("=" * 80)
    print("\nNow attempting temperature extraction...")
    
    # Try simple extraction
    print("\nTrying post.get_solution_data...")
    try:
        post = project.post
        setup_name = project.setups[0].name if project.setups else "Setup"
        print(f"  Setup: {setup_name}")
        
        solution_data = post.get_solution_data(expressions=["Temp"])
        if solution_data:
            print(f"  [OK] Got solution data")
            print(f"  Magnitudes: {solution_data.data_magnitude()}")
    except Exception as e:
        print(f"  [ERROR] {e}")
    
    print("\nClosing project...")
    project.release_desktop(close_projects=True, close_desktop=True)
    print("  [OK] Closed")
    
except Exception as e:
    print(f"\n[ERROR] {e}")
    import traceback
    traceback.print_exc()

print("\nCleaning up...")
subprocess.run(["taskkill", "/F", "/IM", "ansys*.exe"], capture_output=True)
print("  [OK] Done")
