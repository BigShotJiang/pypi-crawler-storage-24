#!/usr/bin/env python3
"""
WORKING SOLUTION - Semi-automated with clear instructions
Runs simulation, then guides you to extract temperatures from GUI
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

import time
import subprocess
from pathlib import Path
import json
from datetime import datetime

print("=" * 80)
print("WORKING SOLUTION - Semi-Automated Temperature Extraction")
print("=" * 80)
print()

# Setup
examples_dir = Path("C:/Users/Alfonso/wuerth/Ansyas/examples")
test_file = Path("//wsl.localhost/Ubuntu-22.04/home/alf/OpenMagnetics/MKF/tests/TestTemperature.cpp")
output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/working_solution")
output_path.mkdir(parents=True, exist_ok=True)

mas_file = examples_dir / "concentric_transformer.json"

print("Step 1: Parsing MAS file...")
with open(mas_file, 'r') as f:
    mas_dict = json.load(f)

magnetic = mas_dict.get('magnetic', {})
core = magnetic.get('core', {})
coil = magnetic.get('coil', {})

core_shape = core.get('functionalDescription', {}).get('shape', {}).get('name', 'Unknown')
core_material = core.get('functionalDescription', {}).get('material', 'N87')
if isinstance(core_material, dict):
    core_material = core_material.get('name', 'N87')

functional_desc = coil.get('functionalDescription', [])
num_turns = [w.get('numberTurns', 0) for w in functional_desc]
num_windings = len(num_turns)
ambient_temp = 25.0

print(f"  Core: {core_shape} ({core_material})")
print(f"  Windings: {num_windings}, Turns: {num_turns}")
print()

# Generate test name
shape_clean = core_shape.replace(' ', '_').replace('/', '_')
test_name = f"Temperature_Concentric_{shape_clean}_{num_windings}W_{sum(num_turns)}T_Bobbin_Icepak"
print(f"Test name: {test_name}")
print()

# Kill existing processes
print("Step 2: Cleaning up...")
subprocess.run(["taskkill", "/F", "/IM", "ansys*.exe"], capture_output=True)
subprocess.run(["taskkill", "/F", "/IM", "Icepak*.exe"], capture_output=True)
time.sleep(3)
print("  [OK] Cleaned up")
print()

# Run simulation
print("Step 3: Running Icepak simulation...")
print("  (This will take about 1 minute)")
print()

import mas_autocomplete
from ansyas import Ansyas

mas = mas_autocomplete.autocomplete(mas_dict)

ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project_name = f"working_{mas_file.stem}_{int(time.time())}"
project = ansyas.create_project(
    outputs_folder=str(output_path),
    project_name=project_name,
    non_graphical=False,  # GUI visible
    new_desktop_session=True,
    solution_type="SteadyState"
)

ansyas.set_units("meter")

# Build geometry
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)

# Run simulation
print("  Running thermal analysis...")
ansyas.analyze()
print("  [OK] Simulation completed!")
print()

project.save_project()

print("=" * 80)
print("EXTRACTION INSTRUCTIONS")
print("=" * 80)
print()
print("The Ansys GUI is still open. Please follow these steps:")
print()
print("1. In the Ansys GUI, go to the 'Results' tab")
print("2. Click on 'Icepak' menu → 'Field Summary'")
print("3. Select these objects one by one:")
print("     - core_0 (central column)")
print("     - core_1 (lateral column)")  
print("     - bobbin")
print("4. For each object, note down the 'Temperature' value")
print("5. Enter the values below when prompted")
print()
print("Object names in the model:")
print("  - core_0")
print("  - core_1")
print("  - bobbin")
print()
print("Press Enter when ready to input temperatures...")
input()

print()
print("Step 4: Enter extracted temperatures")
print("-" * 80)

temperatures = {}

temp = input("core_0 temperature [C]: ").strip()
if temp:
    temperatures['core_0'] = float(temp)

temp = input("core_1 temperature [C]: ").strip()
if temp:
    temperatures['core_1'] = float(temp)

temp = input("bobbin temperature [C]: ").strip()
if temp:
    temperatures['bobbin'] = float(temp)

print()
print(f"[OK] Collected {len(temperatures)} temperatures")

# Close Ansys
try:
    project.release_desktop(close_projects=True, close_desktop=True)
except:
    pass

subprocess.run(["taskkill", "/F", "/IM", "ansys*.exe"], capture_output=True)

print()
print("Step 5: Generating test...")

# Build test
tags = ["temperature", "icepak-validation", "smoke-test", "rectangular-winding-window"]
tags_str = ']['.join(tags)

turns_str = ', '.join(map(str, num_turns))
parallels_str = ', '.join(['1'] * num_windings)

temp_comments = [f"    // Icepak reference temperatures (ambient: {ambient_temp}C):"]
if 'core_0' in temperatures:
    temp_comments.append(f"    // Core Central Column: {temperatures['core_0']:.2f}C")
if 'core_1' in temperatures:
    temp_comments.append(f"    // Core Lateral Column: {temperatures['core_1']:.2f}C")
if 'bobbin' in temperatures:
    temp_comments.append(f"    // Bobbin: {temperatures['bobbin']:.2f}C")

temp_comments_str = '\n'.join(temp_comments)

cpp_test = f'''
TEST_CASE("{test_name}", "[{tags_str}]") {{
    // Icepak validation test generated on {datetime.now().strftime("%Y-%m-%d %H:%M")}
    // Source MAS file: {mas_file.stem}.json
    // Core: {core_shape} ({core_material})
    // Windings: {num_windings} with turns: {num_turns}
    
    std::vector<int64_t> numberTurns({{{turns_str}}});
    std::vector<int64_t> numberParallels({{{parallels_str}}});
    std::string shapeName = "{core_shape}";

    auto coil = OpenMagneticsTesting::get_quick_coil(numberTurns,
                                                     numberParallels,
                                                     shapeName,
                                                     1,
                                                     WindingOrientation::OVERLAPPING,
                                                     WindingOrientation::OVERLAPPING,
                                                     CoilAlignment::SPREAD,
                                                     CoilAlignment::SPREAD);

    std::string coreMaterial = "{core_material}";
    auto gapping = json::array();
    auto core = OpenMagneticsTesting::get_quick_core(shapeName, gapping, 1, coreMaterial);
    
    OpenMagnetics::Magnetic magnetic;
    magnetic.set_core(core);
    magnetic.set_coil(coil);

    TemperatureConfig config;
    config.ambientTemperature = {ambient_temp:.1f};
    config.coreLosses = 1.0;
    config.windingLosses = 0.5;
    applySimulatedLosses(config, magnetic);
    config.plotSchematic = false;
    
    Temperature temp(magnetic, config);
    auto result = temp.calculateTemperatures();
    
    REQUIRE(result.converged);
    REQUIRE(result.maximumTemperature > config.ambientTemperature);
    
{temp_comments_str}
    
    REQUIRE(result.totalThermalResistance > 0.0);
}}
'''

# Append to test file
with open(test_file, 'r') as f:
    content = f.read()

if content.rstrip().endswith('}'):
    last_brace = content.rstrip().rfind('}')
    if last_brace > 0:
        content = content[:last_brace] + cpp_test + '\n}\n'
    else:
        content += cpp_test
else:
    content += cpp_test

with open(test_file, 'w') as f:
    f.write(content)

print("  [OK] Test added to TestTemperature.cpp")
print()
print("=" * 80)
print("COMPLETE!")
print("=" * 80)
print()
print(f"Test file: {test_file}")
print(f"Temperatures collected: {len(temperatures)}")
print()
print("Next steps:")
print("  1. Build MKF: cd /home/alf/OpenMagnetics/MKF/build && make -j$(nproc)")
print(f"  2. Run test: ./tests/TestTemperature '{test_name}'")
