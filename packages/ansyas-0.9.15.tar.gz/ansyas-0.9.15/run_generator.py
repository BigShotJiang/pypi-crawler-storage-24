#!/usr/bin/env python3
"""
Simplified test generator that actually creates the test file
"""

import json
import re
from pathlib import Path
from datetime import datetime

print("=" * 80)
print("Temperature Test Generator - Running...")
print("=" * 80)
print()

# Paths
examples_dir = Path("C:/Users/Alfonso/wuerth/Ansyas/examples")
test_file = Path("//wsl.localhost/Ubuntu-22.04/home/alf/OpenMagnetics/MKF/tests/TestTemperature.cpp")

# Find all JSON files
mas_files = list(examples_dir.glob("*.json"))
print(f"Found {len(mas_files)} JSON files in examples folder")
print()

# Process each file
for mas_file in sorted(mas_files):
    print(f"Processing: {mas_file.name}")
    
    # Load and parse the file
    with open(mas_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    magnetic = data.get('magnetic', {})
    core = magnetic.get('core', {})
    coil = magnetic.get('coil', {})
    
    # Extract info
    core_functional = core.get('functionalDescription', {})
    shape = core_functional.get('shape', {})
    core_shape = shape.get('name', 'Unknown')
    
    # Handle material
    material_data = core_functional.get('material', 'N87')
    if isinstance(material_data, dict):
        core_material = material_data.get('name', 'N87')
    else:
        core_material = material_data
    
    # Coil info
    functional_desc = coil.get('functionalDescription', [])
    num_turns = [w.get('numberTurns', 0) for w in functional_desc]
    num_windings = len(num_turns)
    
    # Bobbin
    bobbin = coil.get('bobbin', {})
    has_bobbin = isinstance(bobbin, dict) and bobbin.get('processedDescription') is not None
    
    # Toroidal check
    family = shape.get('family', '')
    is_toroidal = family.lower() == 't' if isinstance(family, str) else False
    
    print(f"  Core: {core_shape} ({core_material})")
    print(f"  Windings: {num_windings}, Turns: {num_turns}")
    print(f"  Toroidal: {is_toroidal}, Bobbin: {has_bobbin}")
    
    # Generate test name
    shape_clean = core_shape.replace(' ', '_').replace('/', '_')
    parts = ["Temperature"]
    parts.append("Toroidal" if is_toroidal else "Concentric")
    parts.append(shape_clean)
    if num_windings > 1:
        parts.append(f"{num_windings}W")
    total_turns = sum(num_turns) if num_turns else 0
    parts.append(f"{total_turns}T")
    if has_bobbin:
        parts.append("Bobbin")
    parts.append("Icepak")
    test_name = "_".join(parts)
    
    print(f"  Test name: {test_name}")
    
    # Check if test already exists
    if test_file.exists():
        with open(test_file, 'r', encoding='utf-8') as f:
            content = f.read()
        pattern = rf'TEST_CASE\s*\(\s*"{re.escape(test_name)}"'
        if re.search(pattern, content):
            print("  [SKIP] Test already exists")
            print()
            continue
    
    print("  [GENERATE] Creating new test...")
    
    # Generate test code
    tags = ["temperature", "icepak-validation", "smoke-test"]
    if is_toroidal:
        tags.append("round-winding-window")
    else:
        tags.append("rectangular-winding-window")
    tags_str = ']['.join(tags)
    
    turns_str = ', '.join(map(str, num_turns))
    parallels_str = ', '.join(['1'] * num_windings) if num_windings > 0 else '1'
    
    cpp_test = f'''
TEST_CASE("{test_name}", "[{tags_str}]") {{
    // Icepak validation test generated on {datetime.now().strftime("%Y-%m-%d %H:%M")}
    // Source MAS file: {mas_file.stem}.json
    // Core: {core_shape} ({core_material})
    // Windings: {num_windings} with turns: {num_turns}
    
    std::vector<int64_t> numberTurns({{{turns_str}}});
    std::vector<int64_t> numberParallels({{{parallels_str}}});
    std::string shapeName = "{core_shape}";

    auto coil = OpenMagneticsTesting::get_quick_coil(numberTurns,
                                                     numberParallels,
                                                     shapeName,
                                                     1,
                                                     WindingOrientation::OVERLAPPING,
                                                     WindingOrientation::OVERLAPPING,
                                                     CoilAlignment::SPREAD,
                                                     CoilAlignment::SPREAD);

    std::string coreMaterial = "{core_material}";
    auto gapping = json::array();
    auto core = OpenMagneticsTesting::get_quick_core(shapeName, gapping, 1, coreMaterial);
    
    OpenMagnetics::Magnetic magnetic;
    magnetic.set_core(core);
    magnetic.set_coil(coil);

    TemperatureConfig config;
    config.ambientTemperature = 25.0;
    config.coreLosses = 1.0;
    config.windingLosses = 0.5;
    applySimulatedLosses(config, magnetic);
    config.plotSchematic = false;
    
    Temperature temp(magnetic, config);
    auto result = temp.calculateTemperatures();
    
    REQUIRE(result.converged);
    REQUIRE(result.maximumTemperature > config.ambientTemperature);
    
    // Icepak reference temperatures (placeholder values):
    // Core Central Column: 62.5C
    // Core Lateral Column: 58.3C
    // Core Top Yoke: 60.1C
    // Core Bottom Yoke: 60.1C
    // Bobbin Central Column: 55.2C
    // {total_turns} turns with temperatures ranging from 40C to 52C
    
    REQUIRE(result.totalThermalResistance > 0.0);
}}
'''
    
    # Append to test file
    if test_file.exists():
        with open(test_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Find the end of the file
        if content.rstrip().endswith('}'):
            last_brace = content.rstrip().rfind('}')
            if last_brace > 0:
                content = content[:last_brace] + cpp_test + '\n}\n'
            else:
                content += cpp_test
        else:
            content += cpp_test
    else:
        content = cpp_test
    
    # Write back
    with open(test_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"  [OK] Test added to TestTemperature.cpp")
    print()

print("=" * 80)
print("COMPLETE")
print("=" * 80)
print(f"Test file: {test_file}")
print()
print("Next steps:")
print("1. Build MKF: cd /home/alf/OpenMagnetics/MKF/build && make -j$(nproc)")
print("2. Run test: ./tests/TestTemperature '[icepak-validation]'")
