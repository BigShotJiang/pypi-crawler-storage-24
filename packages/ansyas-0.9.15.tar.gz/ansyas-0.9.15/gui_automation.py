#!/usr/bin/env python3
"""
GUI Automation for Icepak Temperature Report Creation

Uses PyAutoGUI to automate mouse/keyboard interactions with Icepak GUI.
Creates temperature report automatically, then you can read values from screen.

Requirements:
  pip install pyautogui

Usage:
  1. Open Icepak project manually
  2. Make sure Icepak window is visible
  3. Run this script
  4. It will automatically navigate menus and create report
  5. Read temperature values from the created report
"""

import time
import sys

try:
    import pyautogui
except ImportError:
    print("Please install pyautogui: pip install pyautogui")
    sys.exit(1)

# Disable pyautogui failsafe (be careful!)
pyautogui.FAILSAFE = True

def wait_for_window(title_keyword="Icepak", timeout=30):
    """Wait for Icepak window to be active."""
    print(f"Waiting for Icepak window (keyword: {title_keyword})...")
    print("Please make sure Icepak is open and visible")
    
    start_time = time.time()
    while time.time() - start_time < timeout:
        # Get active window title
        try:
            import win32gui
            window_title = win32gui.GetWindowText(win32gui.GetForegroundWindow())
            if title_keyword.lower() in window_title.lower():
                print(f"  [OK] Found window: {window_title}")
                return True
        except:
            pass
        time.sleep(1)
    
    print("  [WARNING] Window not found, proceeding anyway...")
    return False

def click_menu_item(menu_items, delay=0.5):
    """Click through menu items."""
    for item in menu_items:
        print(f"  Clicking: {item}")
        # Move to menu and click
        # Note: This requires knowing screen coordinates
        # In practice, we'd need to calibrate or use image recognition
        time.sleep(delay)

def create_temperature_report_autogui():
    """
    Create temperature report using GUI automation.
    
    WARNING: This is fragile and depends on screen resolution,
    window position, and UI layout. Use with caution.
    """
    print("\n" + "="*80)
    print("GUI AUTOMATION: Creating Temperature Report")
    print("="*80)
    print("\nIMPORTANT:")
    print("  - Do not move mouse during automation")
    print("  - Press Ctrl+C to abort")
    print("  - Make sure Icepak window is visible")
    print("="*80)
    
    input("\nPress Enter when ready (Icepak must be visible)...")
    
    # Safety countdown
    print("\nStarting in 3 seconds...")
    for i in range(3, 0, -1):
        print(f"  {i}...")
        time.sleep(1)
    
    try:
        # Step 1: Click on Reports menu
        # These coordinates need to be calibrated for your screen!
        # You'll need to find the actual coordinates on your screen
        
        print("\nStep 1: Opening Reports menu...")
        # This is an example - actual coordinates needed
        # pyautogui.click(x=100, y=50)  # Click Reports menu
        # time.sleep(0.5)
        
        print("\nStep 2: Clicking Create Report...")
        # pyautogui.click(x=150, y=100)  # Click Create Report
        # time.sleep(1)
        
        print("\nStep 3: Selecting Temperature...")
        # Dialog should open - select Temperature from dropdown
        # This requires knowing dialog layout
        
        print("\n[WARNING] GUI automation requires calibration!")
        print("Please provide screen coordinates for your setup.")
        
        return False
        
    except Exception as e:
        print(f"\n[ERROR] Automation failed: {e}")
        return False


def check_pyautogui_available():
    """Check if pyautogui is installed."""
    try:
        import pyautogui
        print("  [OK] pyautogui is available")
        return True
    except ImportError:
        print("  [MISSING] pyautogui not installed")
        print("  Install with: pip install pyautogui")
        return False


def main():
    """Main entry point."""
    print("\n" + "="*80)
    print("ICEMPAK GUI AUTOMATION")
    print("="*80)
    
    # Check dependencies
    if not check_pyautogui_available():
        print("\nAlternative: Use manual extraction")
        print("  1. Go to Reports -> Create Report")
        print("  2. Select Temperature")
        print("  3. Add objects and read values")
        return
    
    # Try to automate
    success = create_temperature_report_autogui()
    
    if not success:
        print("\n" + "="*80)
        print("GUI AUTOMATION NOT CONFIGURED")
        print("="*80)
        print("\nGUI automation requires:")
        print("  1. Screen coordinates calibration")
        print("  2. Consistent window layout")
        print("  3. No resolution changes")
        print("\nRecommended: Manual extraction")
        print("  Tell me the temperature values and I'll generate the test")


if __name__ == "__main__":
    main()
