#!/usr/bin/env python3
"""
Debug - access project directly via pyaedt
"""

import sys
sys.path.insert(0, 'C:/Users/Alfonso/wuerth/Ansyas/src')

from pathlib import Path
from ansys.aedt.core import Icepak

print("Connecting to existing project...")

output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/auto_extraction")
aedt_files = list(output_path.glob("auto_*.aedt"))
latest = max(aedt_files, key=lambda p: p.stat().st_mtime)

print(f"Opening: {latest}")

# Open existing project
ipk = Icepak(
    project=str(latest),
    non_graphical=True
)

print("\nChecking monitors...")
if hasattr(ipk, 'monitors'):
    print(f"  ipk.monitors: {ipk.monitors}")
else:
    print("  No monitors attribute")

print("\nChecking setup...")
if ipk.setups:
    setup = ipk.setups[0]
    print(f"  Setup: {setup.name}")
    
    print("\nTrying to get solution data...")
    try:
        solution_data = ipk.post.get_solution_data(expressions=["Temp"])
        print(f"  Got data: {solution_data}")
        if solution_data:
            print(f"  Magnitudes: {solution_data.data_magnitude()}")
    except Exception as e:
        print(f"  Error: {e}")

print("\nChecking available reports...")
try:
    reports = ipk.post.available_report_quantities()
    print(f"  Available: {reports[:5] if reports else 'None'}")
except Exception as e:
    print(f"  Error: {e}")

print("\nClosing...")
ipk.release_desktop(close_projects=False, close_desktop=False)
print("Done")
