#!/usr/bin/env python3
"""
Hybrid approach: Automated simulation + Manual temperature entry

This script:
1. Creates and runs Icepak thermal simulation automatically
2. Prompts you to enter temperature values from the GUI
3. Generates C++ test cases with your entered values

Usage:
  1. Run this script
  2. It will create and solve the simulation
  3. Open the project in Icepak GUI
  4. Extract temperatures manually (Reports -> Create Report -> Temperature)
  5. Enter the values when prompted
  6. Script generates C++ test cases
"""

import os
import sys
import json
import time
import subprocess
import shutil
from pathlib import Path
from datetime import datetime

# Add Ansyas to path
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import ansys.aedt.core as pyaedt
from Ansyas import Ansyas
import mas_autocomplete

# Configuration
ANSYS_VERSION = "2025.2"
NON_GRAPHICAL = True  # Run simulation headless
OUTPUT_BASE_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\hybrid_manual'
MKF_TEST_FILE = r'\wsl.localhost\Ubuntu-22.04\home\alf\OpenMagnetics\MKF\tests\TestTemperature.cpp'


def kill_ansys_processes():
    """Kill any existing Ansys processes to free license."""
    print("\nKilling existing Ansys processes...")
    subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], 
                   capture_output=True, check=False)
    subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], 
                   capture_output=True, check=False)
    time.sleep(3)
    print("  [OK] Processes killed")


def create_and_run_simulation(mas_file: str, output_dir: str):
    """
    Create Icepak project and run simulation.
    Returns project object and file path.
    """
    mas_basename = os.path.splitext(os.path.basename(mas_file))[0]
    
    # Create unique output directory
    timestamp = int(time.time())
    project_name = f"hybrid_{mas_basename}_{timestamp}"
    project_output_dir = os.path.join(output_dir, project_name)
    os.makedirs(project_output_dir, exist_ok=True)
    
    print(f"\n{'='*80}")
    print(f"Creating Icepak simulation: {mas_basename}")
    print(f"{'='*80}")
    
    # Kill existing processes first
    kill_ansys_processes()
    
    # Load MAS file
    print("\nLoading MAS file...")
    with open(mas_file, 'r') as f:
        mas_dict = json.load(f)
    
    mas = mas_autocomplete.autocomplete(mas_dict)
    print("  [OK] MAS file loaded and auto-completed")
    
    # Initialize Ansyas
    print("\nInitializing Ansyas...")
    ansyas = Ansyas(
        number_segments_arcs=12,
        initial_mesh_configuration=2,
        maximum_error_percent=5,
        refinement_percent=30,
        maximum_passes=15,
        scale=1
    )
    
    # Create project
    print("\nCreating Icepak project...")
    project = ansyas.create_project(
        outputs_folder=project_output_dir,
        project_name=project_name,
        non_graphical=NON_GRAPHICAL,
        solution_type="SteadyState",
        new_desktop_session=True
    )
    
    if project is None:
        raise RuntimeError("Failed to create AEDT project")
    
    # Set units
    ansyas.set_units("meter")
    print("  [OK] Project created and units set to meters")
    
    # Create geometry
    print("\nCreating geometry...")
    ansyas.create_magnetic_simulation(
        mas=mas,
        simulate=False,
        operating_point_index=0
    )
    print("  [OK] Geometry created")
    
    # Get project file path
    project_file = os.path.join(project_output_dir, f"{project_name}.aedt")
    
    # Run simulation
    print("\n" + "="*80)
    print("Running thermal simulation...")
    print("="*80)
    
    # Create setup
    if not project.setups:
        print("  Creating setup...")
        setup = project.create_setup("Setup")
        print(f"  [OK] Setup created: {setup.name}")
    else:
        setup = project.setups[0]
        print(f"  [OK] Using existing setup: {setup.name}")
    
    # Run analysis
    print("  Running Icepak analysis (this takes ~20 seconds)...")
    project.analyze_setup(setup.name)
    print("  [OK] Simulation completed")
    
    # Create temperature reports for all objects
    print("\n  Creating temperature reports...")
    create_temperature_reports(project, setup.name)
    
    # Save project
    print("  Saving project...")
    project.save_project()
    print("  [OK] Project saved")
    
    print(f"\n{'='*80}")
    print("SIMULATION COMPLETE")
    print(f"{'='*80}")
    print(f"Project file: {project_file}")
    
    # Close project
    ansyas.solver_backend.close()
    
    return project_file, mas_basename, project_name


def create_temperature_reports(project, setup_name):
    """
    Create temperature reports for all thermal objects.
    These reports will be visible in the GUI when you open the project.
    """
    try:
        # Get list of thermal objects
        object_names = project.modeler.object_names
        thermal_objects = []
        
        for obj_name in object_names:
            if any(keyword in obj_name.lower() for keyword in 
                   ['core', 'bobbin', 'copper', 'turn', 'primary', 'secondary', 'winding']):
                thermal_objects.append(obj_name)
        
        print(f"    Found {len(thermal_objects)} thermal objects")
        
        if not thermal_objects:
            print("    [WARNING] No thermal objects found")
            return
        
        # Create individual reports for key objects
        key_objects = [
            'core_0',
            'core_1', 
            'bobbin',
            'Primary_Parallel_0_Turn_0_copper',
            'Primary_Parallel_0_Turn_5_copper',
            'Primary_Parallel_0_Turn_10_copper',
            'Secondary_Parallel_0_Turn_0_copper',
            'Secondary_Parallel_0_Turn_5_copper',
            'Secondary_Parallel_0_Turn_10_copper',
            'Primary_Parallel_1_Turn_0_copper',
            'Primary_Parallel_1_Turn_5_copper',
            'Primary_Parallel_1_Turn_10_copper',
        ]
        
        created_count = 0
        for obj_name in key_objects:
            if obj_name in thermal_objects:
                try:
                    # Create a report for this object
                    report_name = f"Temp_{obj_name.replace(' ', '_').replace('-', '_')}"
                    
                    # Create report using post.create_report
                    success = project.post.create_report(
                        expressions=["Temperature"],
                        setup_sweep_name=f"{setup_name} : LastAdaptive",
                        domain="Point",
                        variations={
                            "Temperature": [f"{obj_name}"]
                        },
                        primary_sweep_variable="Temperature",
                        report_category="Temperature",
                        plot_type="Data Table",
                        context={
                            "Object": obj_name
                        }
                    )
                    
                    if success:
                        created_count += 1
                        print(f"      [OK] Report created: {report_name}")
                    
                except Exception as e:
                    print(f"      [WARN] Could not create report for {obj_name}: {e}")
        
        # Create a summary report with all objects
        try:
            print("    Creating summary report with all objects...")
            
            # Create a comprehensive temperature report
            all_objects_str = ", ".join([f'"{obj}"' for obj in key_objects if obj in thermal_objects])
            
            # Try to create a table report with all temperatures
            success = project.post.create_report(
                expressions=["Temperature"],
                setup_sweep_name=f"{setup_name} : LastAdaptive",
                domain="Volume",
                report_category="Temperature",
                plot_type="Data Table",
                context={
                    "Objects": key_objects
                }
            )
            
            if success:
                print(f"      [OK] Summary report created")
                created_count += 1
                
        except Exception as e:
            print(f"      [WARN] Could not create summary report: {e}")
        
        print(f"    [OK] Created {created_count} temperature reports")
        print(f"\n    When you open the project in GUI:")
        print(f"    - Go to 'Results' tab")
        print(f"    - Look for temperature reports")
        print(f"    - Values will be displayed in tables")
        
    except Exception as e:
        print(f"    [WARNING] Could not create reports: {e}")
        import traceback
        traceback.print_exc()


def get_manual_temperatures():
    """
    Prompt user to enter temperature values manually.
    """
    print("\n" + "="*80)
    print("MANUAL TEMPERATURE ENTRY")
    print("="*80)
    print("\nPlease open the project in Icepak GUI and extract temperatures:")
    print("  1. Open the .aedt file in Ansys Electronics Desktop")
    print("  2. Go to Reports -> Create Report -> Temperature")
    print("  3. Select objects: core_0, core_1, bobbin, and turns")
    print("  4. Note the temperature values")
    print("\nEnter the temperatures below (in Celsius):")
    print("="*80)
    
    temperatures = {}
    
    # Core temperatures
    print("\n--- Core Temperatures ---")
    try:
        core_0 = float(input("Core 0 temperature (°C): "))
        temperatures['core_0'] = core_0
    except ValueError:
        print("Invalid input, skipping core_0")
    
    try:
        core_1 = float(input("Core 1 temperature (°C): "))
        temperatures['core_1'] = core_1
    except ValueError:
        print("Invalid input, skipping core_1")
    
    # Bobbin temperature
    print("\n--- Bobbin Temperature ---")
    try:
        bobbin = float(input("Bobbin temperature (°C): "))
        temperatures['bobbin'] = bobbin
    except ValueError:
        print("Invalid input, skipping bobbin")
    
    # Turn temperatures
    print("\n--- Winding Temperatures ---")
    print("Enter temperatures for representative turns (or press Enter to skip):")
    
    turn_names = [
        'Primary_Parallel_0_Turn_0_copper',
        'Primary_Parallel_0_Turn_5_copper',
        'Primary_Parallel_0_Turn_10_copper',
        'Secondary_Parallel_0_Turn_0_copper',
        'Secondary_Parallel_0_Turn_5_copper',
        'Secondary_Parallel_0_Turn_10_copper',
        'Primary_Parallel_1_Turn_0_copper',
        'Primary_Parallel_1_Turn_5_copper',
        'Primary_Parallel_1_Turn_10_copper',
    ]
    
    for turn_name in turn_names:
        try:
            temp = input(f"{turn_name} (°C): ").strip()
            if temp:
                temperatures[turn_name] = float(temp)
        except ValueError:
            print(f"Invalid input, skipping {turn_name}")
    
    print(f"\n[OK] Collected {len(temperatures)} temperature values")
    return temperatures


def generate_cpp_test_case(mas_file: str, temperatures: dict, test_name: str):
    """
    Generate C++ test case code with manually entered temperatures.
    """
    print(f"\n[STEP] Generating C++ test case: {test_name}")
    
    # Calculate statistics from entered values
    core_temps = []
    bobbin_temps = []
    turn_temps = []
    
    for name, temp in temperatures.items():
        if 'core' in name.lower():
            core_temps.append(temp)
        elif 'bobbin' in name.lower():
            bobbin_temps.append(temp)
        elif 'turn' in name.lower() or 'copper' in name.lower():
            turn_temps.append((name, temp))
    
    avg_core = sum(core_temps) / len(core_temps) if core_temps else 0
    max_core = max(core_temps) if core_temps else 0
    min_core = min(core_temps) if core_temps else 0
    avg_bobbin = sum(bobbin_temps) / len(bobbin_temps) if bobbin_temps else 0
    
    mas_basename = os.path.splitext(os.path.basename(mas_file))[0]
    
    # Generate test case
    cpp_code = f"""
// =============================================================================
// Temperature Test - Manual Entry
// Source MAS: {mas_basename}
// Generated: {datetime.now().isoformat()}
// Method: Icepak simulation with manual temperature extraction
// =============================================================================

TEST_F(TemperatureTests, {test_name}) {{
    // Load MAS file
    std::string masFile = "{mas_file}";
    auto masData = OpenMagnetics::loadMas(masFile);
    
    // Run thermal simulation
    OpenMagnetics::ThermalSimulation thermalSim;
    thermalSim.setMeshDensity(OpenMagnetics::MeshDensity::Medium);
    thermalSim.setConvergenceCriteria(5.0);
    
    auto result = thermalSim.run(masData);
    
    // Reference values from Icepak (manually extracted)
    // Core temperatures
    EXPECT_NEAR(result.getCoreAverageTemperature(), {avg_core:.2f}, 10.0);
    EXPECT_NEAR(result.getCoreMaxTemperature(), {max_core:.2f}, 10.0);
    EXPECT_NEAR(result.getCoreMinTemperature(), {min_core:.2f}, 10.0);
    
    // Bobbin temperature
    EXPECT_NEAR(result.getBobbinTemperature(), {avg_bobbin:.2f}, 10.0);
    
    // Winding temperatures (selected turns)
"""
    
    # Add per-turn assertions
    for name, temp in turn_temps[:5]:  # First 5 turns
        short_name = name.replace('Primary_Parallel_', 'P').replace('Secondary_Parallel_', 'S').replace('_copper', '')
        cpp_code += f"    EXPECT_NEAR(result.getWindingTemperature(\"{short_name}\"), {temp:.2f}, 15.0); // {name}\n"
    
    if len(turn_temps) > 5:
        cpp_code += f"    // ... and {len(turn_temps) - 5} more winding temperature checks\n"
    
    cpp_code += "}\n"
    
    return cpp_code


def save_test_case(cpp_code: str, mas_basename: str, test_name: str):
    """
    Save test case to file - safely appends to existing files.
    """
    output_file = os.path.join(OUTPUT_BASE_DIR, f"test_{mas_basename}.cpp")
    
    # Save individual test file (overwrite is fine for individual file)
    with open(output_file, 'w') as f:
        f.write(cpp_code)
    
    print(f"\n[OK] Test case saved to: {output_file}")
    
    # Also try to append to MKF test file - NEVER overwrite!
    try:
        if os.path.exists(MKF_TEST_FILE):
            # Read existing content
            with open(MKF_TEST_FILE, 'r') as f:
                existing = f.read()
            
            # Check if this test already exists (avoid duplicates)
            if test_name in existing:
                print(f"[INFO] Test '{test_name}' already exists in {MKF_TEST_FILE}")
                print(f"       Skipping to avoid duplicates")
                return
            
            # Create backup before modifying
            backup_file = f"{MKF_TEST_FILE}.backup_{int(time.time())}"
            try:
                shutil.copy2(MKF_TEST_FILE, backup_file)
                print(f"[OK] Created backup: {backup_file}")
            except Exception as backup_error:
                print(f"[WARN] Could not create backup: {backup_error}")
            
            # Append new test case
            with open(MKF_TEST_FILE, 'a') as f:
                if not existing.endswith('\n'):
                    f.write('\n')
                f.write(cpp_code)
            
            print(f"[OK] Test case appended to: {MKF_TEST_FILE}")
            print(f"[INFO] Total tests in file: {existing.count('TEST_F') + 1}")
        else:
            print(f"[INFO] MKF test file not found at: {MKF_TEST_FILE}")
            print(f"       Test saved to: {output_file}")
    except Exception as e:
        print(f"[WARN] Could not append to MKF test file: {e}")
        print(f"       Test saved to: {output_file}")


def main():
    """Main entry point."""
    print("\n" + "="*80)
    print("HYBRID APPROACH: Auto Simulation + Manual Temperature Entry")
    print("="*80)
    print(f"PyAEDT Version: {pyaedt.__version__}")
    print(f"Ansys Version: {ANSYS_VERSION}")
    print(f"Output Directory: {OUTPUT_BASE_DIR}")
    print("="*80)
    
    # MAS file to process
    mas_file = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'
    
    try:
        # Step 1: Create and run simulation
        project_file, mas_basename, project_name = create_and_run_simulation(mas_file, OUTPUT_BASE_DIR)
        
        # Step 2: Prompt user to open GUI and read reports
        print("\n" + "="*80)
        print("NEXT STEPS:")
        print("="*80)
        print(f"\n1. Open this project in Ansys Icepak:")
        print(f"   {project_file}")
        print(f"\n2. Temperature reports have been created automatically!")
        print(f"   - Go to 'Results' tab in Icepak")
        print(f"   - Look for temperature reports in the report list")
        print(f"   - Or go to 'Reports' -> existing reports")
        print(f"\n3. Read the temperature values from the reports")
        print(f"   - Core temperatures: core_0, core_1")
        print(f"   - Bobbin temperature")
        print(f"   - Turn temperatures (11 primary, 11 secondary, 11 primary parallel)")
        
        input("\nPress Enter when ready to enter temperatures...")
        
        # Step 3: Get manual temperature entry
        temperatures = get_manual_temperatures()
        
        if not temperatures:
            print("\n[ERROR] No temperatures entered. Cannot generate test case.")
            sys.exit(1)
        
        # Step 4: Generate test case
        test_name = f"ManualTemp_{mas_basename}_{int(time.time())}"
        cpp_code = generate_cpp_test_case(mas_file, temperatures, test_name)
        
        # Step 5: Save test case
        save_test_case(cpp_code, mas_basename, test_name)
        
        print("\n" + "="*80)
        print("COMPLETE!")
        print("="*80)
        print(f"Generated test case: {test_name}")
        print(f"Temperatures entered: {len(temperatures)}")
        print("\nYou can now:")
        print("  - Review the generated test case")
        print("  - Compile MKF with the new test")
        print("  - Run the test to validate your thermal simulation")
        
    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        # Kill Ansys processes
        print("\nCleaning up...")
        kill_ansys_processes()


if __name__ == "__main__":
    main()
