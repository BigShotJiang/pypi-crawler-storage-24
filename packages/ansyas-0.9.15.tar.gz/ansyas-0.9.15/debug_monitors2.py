#!/usr/bin/env python3
"""
Debug - try different ways to access monitors
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

from pathlib import Path

print("Connecting...")

from ansyas import Ansyas

output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/auto_extraction")
aedt_files = list(output_path.glob("auto_*.aedt"))
latest = max(aedt_files, key=lambda p: p.stat().st_mtime)

ansyas = Ansyas()
project = ansyas.create_project(
    outputs_folder=str(output_path),
    project_name=latest.stem,
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=False
)

print("\nChecking project.monitors:")
try:
    if hasattr(project, 'monitors'):
        print(f"  Found {len(project.monitors)} monitors")
        for m in project.monitors:
            print(f"    {m}")
    else:
        print("  No monitors attribute")
except Exception as e:
    print(f"  Error: {e}")

print("\nChecking project.setups:")
try:
    if project.setups:
        for setup in project.setups:
            print(f"  Setup: {setup.name}")
            if hasattr(setup, 'monitors'):
                print(f"    Monitors: {setup.monitors}")
    else:
        print("  No setups")
except Exception as e:
    print(f"  Error: {e}")

print("\nTrying to get temperature directly...")
try:
    # Try using the post processor
    post = project.post
    
    # Try solution data
    solution_data = post.get_solution_data(expressions=["Temp"])
    if solution_data:
        print(f"  Solution data magnitudes: {solution_data.data_magnitude()}")
except Exception as e:
    print(f"  Error: {e}")

print("\nChecking available expressions...")
try:
    post = project.post
    available = post.available_report_quantities()
    print(f"  Available: {available[:10] if available else 'None'}")
except Exception as e:
    print(f"  Error: {e}")

print("\nClosing...")
project.release_desktop(close_projects=False, close_desktop=False)
