#!/usr/bin/env python3
"""
Check project structure and extract temps
"""

import sys
sys.path.insert(0, 'C:/Users/Alfonso/wuerth/Ansyas/src')

from pathlib import Path
from ansys.aedt.core import Icepak

print("Opening last project...")

output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/robust_auto")
aedt_files = list(output_path.glob("robust_*.aedt"))
latest = max(aedt_files, key=lambda p: p.stat().st_mtime)

print(f"Opening: {latest}")

ipk = Icepak(
    project=str(latest),
    non_graphical=True
)

print("\nSetups:")
for setup in ipk.setups:
    print(f"  - {setup.name}")

print("\nObjects:")
for name in list(ipk.modeler.objects.keys())[:10]:
    print(f"  - {name}")

print("\nTrying to get temperature...")
try:
    # Try with the first setup name
    if ipk.setups:
        setup_name = ipk.setups[0].name
        print(f"Using setup: {setup_name}")
        
        # Try solution data
        data = ipk.post.get_solution_data(
            expressions=["Temp"],
            setup_sweep_name=f"{setup_name} : LastAdaptive"
        )
        print(f"Data: {data}")
        if data:
            print(f"Magnitudes: {data.data_magnitude()}")
except Exception as e:
    print(f"Error: {e}")

print("\nClosing...")
ipk.release_desktop(close_projects=False, close_desktop=False)
