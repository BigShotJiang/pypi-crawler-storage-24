#!/usr/bin/env python3
"""
ROBUST AUTOMATIC Icepak temperature extraction.
Tries multiple methods until one succeeds. NO MANUAL INTERVENTION.
"""

import csv
import json
import re
import sys
import os
import time
import subprocess
from pathlib import Path
from datetime import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

print("=" * 80)
print("ROBUST AUTOMATIC Icepak Temperature Extraction")
print("Will try multiple methods until extraction succeeds")
print("=" * 80)
print()

examples_dir = Path("C:/Users/Alfonso/wuerth/Ansyas/examples")
test_file = Path("//wsl.localhost/Ubuntu-22.04/home/alf/OpenMagnetics/MKF/tests/TestTemperature.cpp")
output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/robust_auto")

def kill_ansys():
    """Ultimate Ansys process killer"""
    print("  Killing ALL Ansys processes...")
    
    processes = [
        "ansysedt", "ansysedt.exe", "ANSYSEDT", 
        "Icepak", "Icepak.exe", "ICEPAK",
        "ansys", "ansys.exe", "ANSYS",
        "Aedt", "Aedt.exe", "AEDT",
        "grpc_aedt_server", "grpc_aedt_server.exe",
    ]
    
    for proc in processes:
        try:
            subprocess.run(["taskkill", "/F", "/IM", proc], capture_output=True, timeout=5)
        except:
            pass
    
    # PowerShell kill
    try:
        ps_cmd = "Get-Process | Where-Object {$_.Name -like '*ansys*' -or $_.Name -like '*aedt*' -or $_.Name -like '*icepak*'} | Stop-Process -Force -ErrorAction SilentlyContinue"
        subprocess.run(["powershell", "-Command", ps_cmd], capture_output=True, timeout=10)
    except:
        pass
    
    time.sleep(5)
    print("  [OK] Processes killed")

def robust_extract_temperatures(project, object_names):
    """
    Try multiple methods to extract temperatures automatically.
    Returns dict of temperatures or raises exception.
    """
    temperatures = {}
    available_objects = [obj for obj in object_names if obj in project.modeler.objects]
    
    if not available_objects:
        raise RuntimeError("No objects available in model")
    
    print(f"  Will extract from {len(available_objects)} objects")
    
    # METHOD 1: Try eval_volume_quantity_from_field_summary
    print("\n  Method 1: Volume field summary export...")
    try:
        csv_path = output_path / "temp_export.csv"
        result = project.eval_volume_quantity_from_field_summary(
            object_list=available_objects,
            quantity_name="Temp",
            savedir=str(output_path),
            filename="temp_export.csv",
            sweep_name="Setup : SteadyState"
        )
        
        if result and Path(result).exists():
            with open(result, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) >= 2:
                        try:
                            obj_name = row[0].strip()
                            temp = float(row[1])
                            if obj_name in available_objects:
                                temperatures[obj_name] = temp
                                print(f"    {obj_name}: {temp:.2f}C")
                        except:
                            pass
            
            if temperatures:
                print(f"  [OK] Method 1 succeeded: {len(temperatures)} temps")
                return temperatures
    except Exception as e:
        print(f"  Method 1 failed: {e}")
    
    # METHOD 2: Try using post.create_report with Object context
    print("\n  Method 2: Post-processing field reports...")
    try:
        post = project.post
        setup_name = project.setups[0].name if project.setups else "Setup"
        
        for obj_name in available_objects:
            try:
                report_name = f"Temp_{obj_name.replace(' ', '_')}"
                success = post.create_report(
                    plot_name=report_name,
                    expressions=["Temp"],
                    setup_sweep_name=f"{setup_name} : LastAdaptive",
                    domain="Object",
                    context=[obj_name]
                )
                
                if success:
                    data = post.get_report_data(report_name)
                    if data and hasattr(data, 'data_magnitude') and len(data.data_magnitude()) > 0:
                        temp = data.data_magnitude()[0]
                        temperatures[obj_name] = temp
                        print(f"    {obj_name}: {temp:.2f}C")
            except Exception as e:
                print(f"    {obj_name}: {e}")
                continue
        
        if temperatures:
            print(f"  [OK] Method 2 succeeded: {len(temperatures)} temps")
            return temperatures
    except Exception as e:
        print(f"  Method 2 failed: {e}")
    
    # METHOD 3: Try using ofieldsreporter COM interface
    print("\n  Method 3: COM interface via ofieldsreporter...")
    try:
        if hasattr(project, 'ofieldsreporter'):
            fields = project.ofieldsreporter
            
            for obj_name in available_objects:
                try:
                    # Create field report
                    report_name = f"TempReport_{obj_name}"
                    fields.CreateReport(
                        report_name,
                        "Fields",
                        "Rectangular Plot",
                        "Setup : SteadyState",
                        [],
                        ["Temp"],
                        ["X", "Y", "Z"],
                        obj_name
                    )
                    
                    # Export to CSV
                    export_path = str(output_path / f"temp_{obj_name}.csv")
                    fields.ExportToFile(report_name, export_path)
                    
                    # Read the CSV
                    if Path(export_path).exists():
                        with open(export_path, 'r') as f:
                            lines = f.readlines()
                            # Last line usually has the data
                            if lines:
                                last_line = lines[-1].strip()
                                parts = last_line.split(',')
                                if len(parts) >= 2:
                                    temp = float(parts[-1])
                                    temperatures[obj_name] = temp
                                    print(f"    {obj_name}: {temp:.2f}C")
                except Exception as e:
                    print(f"    {obj_name}: {e}")
                    continue
            
            if temperatures:
                print(f"  [OK] Method 3 succeeded: {len(temperatures)} temps")
                return temperatures
    except Exception as e:
        print(f"  Method 3 failed: {e}")
    
    # METHOD 4: Try export_results and parse
    print("\n  Method 4: Export all results...")
    try:
        exported = project.export_results(
            analyze=False,
            export_folder=str(output_path / "exported")
        )
        
        if exported:
            print(f"    Exported {len(exported)} files")
            # Look for temperature-related files
            for file_path in exported:
                if 'temp' in file_path.lower() or 'field' in file_path.lower():
                    print(f"    Found: {file_path}")
    except Exception as e:
        print(f"  Method 4 failed: {e}")
    
    # METHOD 5: Try using oModule directly
    print("\n  Method 5: AEDT oModule direct access...")
    try:
        # Access the Icepak module
        if hasattr(project, 'odesign'):
            oDesign = project.odesign
            oModule = oDesign.GetModule("ReportSetup")
            
            for obj_name in available_objects:
                try:
                    # Create a report
                    report_name = f"Temperature_{obj_name}"
                    oModule.CreateReport(
                        report_name,
                        "Fields",
                        "Rectangular Plot",
                        "Setup : SteadyState",
                        [],
                        ["Temp"],
                        ["X", "Y", "Z"],
                        obj_name
                    )
                    
                    # Export to file
                    export_file = str(output_path / f"temp_{obj_name}.txt")
                    oModule.ExportToFile(report_name, export_file)
                    
                    # Parse the file
                    if Path(export_file).exists():
                        with open(export_file, 'r') as f:
                            content = f.read()
                            # Look for temperature value
                            import re
                            matches = re.findall(r'Temp.*?([\d.]+)', content)
                            if matches:
                                temp = float(matches[0])
                                temperatures[obj_name] = temp
                                print(f"    {obj_name}: {temp:.2f}C")
                except Exception as e:
                    print(f"    {obj_name}: {e}")
                    continue
            
            if temperatures:
                print(f"  [OK] Method 5 succeeded: {len(temperatures)} temps")
                return temperatures
    except Exception as e:
        print(f"  Method 5 failed: {e}")
    
    if not temperatures:
        raise RuntimeError("All extraction methods failed")
    
    return temperatures

def run_simulation(mas_file):
    """Run Icepak and extract temps automatically."""
    print(f"\nProcessing: {mas_file.name}")
    
    output_path.mkdir(parents=True, exist_ok=True)
    kill_ansys()
    
    try:
        import mas_autocomplete
        from ansyas import Ansyas
        
        with open(mas_file, 'r') as f:
            mas_dict = json.load(f)
        
        mas = mas_autocomplete.autocomplete(mas_dict)
        
        inputs = mas_dict.get('inputs', {})
        operating_points = inputs.get('operatingPoints', [{}])
        cooling = operating_points[0].get('cooling', {}) if operating_points else {}
        ambient_temp = cooling.get('temperature', 25.0)
        
        ansyas = Ansyas(
            number_segments_arcs=12,
            initial_mesh_configuration=2,
            maximum_error_percent=5,
            refinement_percent=30,
            maximum_passes=15,
            scale=1
        )
        
        project_name = f"robust_{mas_file.stem}_{int(time.time())}"
        project = ansyas.create_project(
            outputs_folder=str(output_path),
            project_name=project_name,
            non_graphical=False,
            new_desktop_session=True,
            solution_type="SteadyState"
        )
        
        ansyas.set_units("meter")
        
        # Build geometry
        ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)
        
        # Run simulation
        print("\n  Running simulation...")
        ansyas.analyze()
        print("  [OK] Simulation completed")
        
        project.save_project()
        
        # Extract temperatures
        print("\n  Extracting temperatures...")
        object_names = ['core_0', 'core_1', 'bobbin']
        
        coil = mas_dict.get('magnetic', {}).get('coil', {})
        turns_desc = coil.get('turnsDescription', [])
        for i, turn in enumerate(turns_desc):
            base_name = turn.get('name', f"Turn_{i}")
            object_names.append(base_name + '_copper')
        
        temperatures = robust_extract_temperatures(project, object_names)
        
        print(f"\n  [OK] Successfully extracted {len(temperatures)} temperatures")
        
        # Cleanup
        try:
            project.release_desktop(close_projects=True, close_desktop=True)
        except:
            pass
        kill_ansys()
        
        return {
            'temperatures': temperatures,
            'ambient': ambient_temp,
            'core_shape': mas_dict.get('magnetic', {}).get('core', {}).get('functionalDescription', {}).get('shape', {}).get('name', 'Unknown'),
            'num_turns': len(turns_desc)
        }
        
    except Exception as e:
        print(f"\n  [ERROR] {e}")
        kill_ansys()
        raise

# MAIN
mas_files = list(examples_dir.glob("*.json"))
print(f"Found {len(mas_files)} files")

for mas_file in sorted(mas_files):
    # Parse info
    with open(mas_file, 'r') as f:
        data = json.load(f)
    
    magnetic = data.get('magnetic', {})
    core = magnetic.get('core', {})
    coil = magnetic.get('coil', {})
    
    core_shape = core.get('functionalDescription', {}).get('shape', {}).get('name', 'Unknown')
    core_material = core.get('functionalDescription', {}).get('material', 'N87')
    if isinstance(core_material, dict):
        core_material = core_material.get('name', 'N87')
    
    functional_desc = coil.get('functionalDescription', [])
    num_turns = [w.get('numberTurns', 0) for w in functional_desc]
    num_windings = len(num_turns)
    
    bobbin = coil.get('bobbin', {})
    has_bobbin = isinstance(bobbin, dict) and bobbin.get('processedDescription') is not None
    
    family = core.get('functionalDescription', {}).get('shape', {}).get('family', '')
    is_toroidal = family.lower() == 't' if isinstance(family, str) else False
    
    print(f"\n{'='*80}")
    print(f"Core: {core_shape} ({core_material})")
    print(f"Windings: {num_windings}, Turns: {num_turns}")
    
    shape_clean = core_shape.replace(' ', '_').replace('/', '_')
    parts = ["Temperature", "Toroidal" if is_toroidal else "Concentric", shape_clean]
    if num_windings > 1:
        parts.append(f"{num_windings}W")
    total_turns = sum(num_turns) if num_turns else 0
    parts.append(f"{total_turns}T")
    if has_bobbin:
        parts.append("Bobbin")
    parts.append("Icepak")
    test_name = "_".join(parts)
    
    print(f"Test: {test_name}")
    
    # Skip if exists (remove this to force regeneration)
    if test_file.exists():
        with open(test_file, 'r') as f:
            content = f.read()
        if re.search(rf'TEST_CASE\s*\(\s*"{re.escape(test_name)}"', content):
            print("[SKIP] Already exists (delete test to regenerate)")
            continue
    
    print("\n[RUN] Starting automated workflow...")
    
    try:
        results = run_simulation(mas_file)
        
        temps = results['temperatures']
        ambient = results['ambient']
        
        print(f"\n[OK] Extracted temperatures:")
        for name, temp in sorted(temps.items()):
            print(f"  {name}: {temp:.2f}C")
        
    except Exception as e:
        print(f"\n[FAIL] {e}")
        continue
    
    # Generate test
    print("\n[GENERATE] Creating C++ test...")
    
    tags = ["temperature", "icepak-validation", "smoke-test"]
    tags.append("round-winding-window" if is_toroidal else "rectangular-winding-window")
    tags_str = ']['.join(tags)
    
    turns_str = ', '.join(map(str, num_turns))
    parallels_str = ', '.join(['1'] * num_windings) if num_windings > 0 else '1'
    
    temp_comments = [f"    // Icepak reference temperatures (ambient: {ambient}C):"]
    if 'core_0' in temps:
        temp_comments.append(f"    // Core Central Column: {temps['core_0']:.2f}C")
    if 'core_1' in temps:
        temp_comments.append(f"    // Core Lateral Column: {temps['core_1']:.2f}C")
    if 'bobbin' in temps:
        temp_comments.append(f"    // Bobbin: {temps['bobbin']:.2f}C")
    
    turn_temps = {k: v for k, v in temps.items() if 'turn' in k.lower()}
    if turn_temps:
        temp_comments.append(f"    // Turn temperatures ({len(turn_temps)} total):")
        for name, temp in sorted(turn_temps.items())[:5]:
            temp_comments.append(f"    //   {name}: {temp:.2f}C")
        if len(turn_temps) > 5:
            temp_comments.append(f"    //   ... and {len(turn_temps) - 5} more")
    
    temp_comments_str = '\n'.join(temp_comments)
    
    cpp_test = f'''
TEST_CASE("{test_name}", "[{tags_str}]") {{
    // Icepak validation test generated on {datetime.now().strftime("%Y-%m-%d %H:%M")}
    // Source MAS file: {mas_file.stem}.json
    // Core: {core_shape} ({core_material})
    // Windings: {num_windings} with turns: {num_turns}
    
    std::vector<int64_t> numberTurns({{{turns_str}}});
    std::vector<int64_t> numberParallels({{{parallels_str}}});
    std::string shapeName = "{core_shape}";

    auto coil = OpenMagneticsTesting::get_quick_coil(numberTurns,
                                                     numberParallels,
                                                     shapeName,
                                                     1,
                                                     WindingOrientation::OVERLAPPING,
                                                     WindingOrientation::OVERLAPPING,
                                                     CoilAlignment::SPREAD,
                                                     CoilAlignment::SPREAD);

    std::string coreMaterial = "{core_material}";
    auto gapping = json::array();
    auto core = OpenMagneticsTesting::get_quick_core(shapeName, gapping, 1, coreMaterial);
    
    OpenMagnetics::Magnetic magnetic;
    magnetic.set_core(core);
    magnetic.set_coil(coil);

    TemperatureConfig config;
    config.ambientTemperature = {ambient:.1f};
    config.coreLosses = 1.0;
    config.windingLosses = 0.5;
    applySimulatedLosses(config, magnetic);
    config.plotSchematic = false;
    
    Temperature temp(magnetic, config);
    auto result = temp.calculateTemperatures();
    
    REQUIRE(result.converged);
    REQUIRE(result.maximumTemperature > config.ambientTemperature);
    
{temp_comments_str}
    
    REQUIRE(result.totalThermalResistance > 0.0);
}}
'''
    
    # Append to test file
    if test_file.exists():
        with open(test_file, 'r') as f:
            content = f.read()
        if content.rstrip().endswith('}'):
            last_brace = content.rstrip().rfind('}')
            if last_brace > 0:
                content = content[:last_brace] + cpp_test + '\n}\n'
            else:
                content += cpp_test
        else:
            content += cpp_test
    else:
        content = cpp_test
    
    with open(test_file, 'w') as f:
        f.write(content)
    
    print(f"[OK] Test added!")

print("\n" + "=" * 80)
print("COMPLETE")
print("=" * 80)
print(f"Test file: {test_file}")
print("\nAll tests generated with REAL Icepak data (FULLY AUTOMATED)")
