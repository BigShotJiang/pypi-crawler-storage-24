#!/usr/bin/env python3
"""
Debug script to check CreateCircle parameters
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import json
import PyOpenMagnetics
from Ansyas import Ansyas

# Load MAS file
mas_file = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'
with open(mas_file, 'r') as f:
    mas_dict = json.load(f)

# Check first turn's wire
magnetic = mas_dict.get('magnetic', {})
coil = magnetic.get('coil', {})
functional_desc = coil.get('functionalDescription', [])

print("Checking winding and wire information:")
for i, winding in enumerate(functional_desc):
    wire = winding.get('wire', {})
    print(f"\nWinding {i}:")
    print(f"  Wire type: {wire.get('type')}")
    print(f"  Wire name: {wire.get('name')}")
    print(f"  Outer diameter: {wire.get('outerDiameter')}")
    print(f"  Conducting diameter: {wire.get('conductingDiameter')}")
    print(f"  Coating: {wire.get('coating')}")

# Check turns
print("\n\nChecking turns:")
for i, winding in enumerate(functional_desc):
    turns = winding.get('turns', [])
    print(f"\nWinding {i} has {len(turns)} turns")
    if turns:
        first_turn = turns[0]
        print(f"  First turn name: {first_turn.get('name')}")
        print(f"  First turn coordinates: {first_turn.get('coordinates')}")

# Now let's see what mas_autocomplete does
print("\n\nRunning mas_autocomplete...")
mas = PyOpenMagnetics.mas_autocomplete(mas_dict, {})

if 'data' in mas:
    print(f"  Result has 'data' key, type: {type(mas['data'])}")
    if isinstance(mas['data'], str):
        print(f"  Data appears to be error: {mas['data'][:200]}")
else:
    print(f"  Result keys: {list(mas.keys())[:10]}")

print("\n\nDone!")
