#!/usr/bin/env python3
"""
FINAL WORKING SOLUTION - Uses export_results() + file parsing
This is the approach recommended in PyAEDT GitHub discussions
"""

import sys
import os
import time
import subprocess
import json
import csv
import re
from pathlib import Path
from datetime import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

print("=" * 80)
print("FINAL SOLUTION - Export Results + File Parsing")
print("=" * 80)
print()

def kill_all_ansys():
    """Kill all Ansys processes"""
    print("  Cleaning up Ansys...")
    subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
    subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], capture_output=True)
    time.sleep(5)
    print("  [OK]")

# Setup
examples_dir = Path("C:/Users/Alfonso/wuerth/Ansyas/examples")
test_file = Path("//wsl.localhost/Ubuntu-22.04/home/alf/OpenMagnetics/MKF/tests/TestTemperature.cpp")
output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/final_solution")
output_path.mkdir(parents=True, exist_ok=True)

mas_file = examples_dir / "concentric_transformer.json"

print(f"Processing: {mas_file.name}")

with open(mas_file, 'r') as f:
    mas_dict = json.load(f)

magnetic = mas_dict.get('magnetic', {})
core = magnetic.get('core', {})
coil = magnetic.get('coil', {})

core_shape = core.get('functionalDescription', {}).get('shape', {}).get('name', 'Unknown')
core_material = core.get('functionalDescription', {}).get('material', 'N87')
if isinstance(core_material, dict):
    core_material = core_material.get('name', 'N87')

functional_desc = coil.get('functionalDescription', [])
num_turns = [w.get('numberTurns', 0) for w in functional_desc]
num_windings = len(num_turns)
ambient_temp = 25.0

print(f"  Core: {core_shape} ({core_material})")
print(f"  Windings: {num_windings}, Turns: {num_turns}")

# Kill existing
kill_all_ansys()

# Import and run simulation
print("\n  Running simulation...")
import mas_autocomplete
from ansyas import Ansyas

mas = mas_autocomplete.autocomplete(mas_dict)

ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project_name = f"final_{mas_file.stem}_{int(time.time())}"
project = ansyas.create_project(
    outputs_folder=str(output_path),
    project_name=project_name,
    non_graphical=True,
    new_desktop_session=True,
    solution_type="SteadyState"
)

ansyas.set_units("meter")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)

print("  Solving...")
ansyas.analyze()
print("  [OK] Simulation completed!")

project.save_project()

# EXPORT RESULTS - This should work!
print("\n  Exporting results...")
export_dir = output_path / "exported_results"
export_dir.mkdir(exist_ok=True)

try:
    exported_files = project.export_results(
        analyze=False,
        export_folder=str(export_dir)
    )
    
    print(f"  [OK] Exported {len(exported_files)} files")
    
    # List exported files
    for f in exported_files:
        print(f"    - {Path(f).name}")
    
    # Try to parse temperature data from exported files
    temperatures = {}
    
    # Look for field summary or temperature-related files
    for file_path in exported_files:
        file_path = Path(file_path)
        if 'summary' in file_path.name.lower() or 'field' in file_path.name.lower():
            print(f"\n  Parsing: {file_path.name}")
            try:
                with open(file_path, 'r') as f:
                    content = f.read()
                    # Look for temperature values and object names
                    # This is format-specific
                    print(f"    Content preview: {content[:200]}")
            except Exception as e:
                print(f"    Error parsing: {e}")
    
    # Try alternative: export_summary
    print("\n  Trying export_summary...")
    try:
        summary_dir = output_path / "summary"
        summary_dir.mkdir(exist_ok=True)
        
        project.export_summary(
            output_dir=str(summary_dir),
            type='Object',
            geometryType='Volume'
        )
        
        # Parse summary files
        summary_files = list(summary_dir.glob("*.csv"))
        print(f"    Created {len(summary_files)} summary files")
        
        for sf in summary_files:
            print(f"\n    File: {sf.name}")
            try:
                with open(sf, 'r') as f:
                    reader = csv.reader(f)
                    for row in reader:
                        print(f"      {row}")
            except Exception as e:
                print(f"      Error: {e}")
                
    except Exception as e:
        print(f"    export_summary failed: {e}")
    
except Exception as e:
    print(f"  [ERROR] Export failed: {e}")

# Close
try:
    project.release_desktop(close_projects=True, close_desktop=True)
except:
    pass

kill_all_ansys()

print("\n" + "=" * 80)
print("Check the exported files in:")
print(f"  {export_dir}")
print(f"  {output_path / 'summary'}")
print("=" * 80)
