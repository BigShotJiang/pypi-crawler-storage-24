#!/usr/bin/env python3
"""
FULLY AUTOMATED Icepak Temperature Extraction Script
Uses PyAEDT 1.0.0rc1 with create_field_summary() API

Requirements:
- PyAEDT 1.0.0rc1 or later
- Ansys Electronics Desktop 2025.2 Student or full version
- Ansyas package in Python path

This script:
1. Loads MAS files and runs Icepak thermal simulations
2. Automatically extracts temperature data using create_field_summary()
3. Generates C++ test cases for MKF's TestTemperature.cpp

NO MANUAL INTERVENTION - Full automation with error-on-failure
"""

import os
import sys
import json
import time
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple

# Add Ansyas to path
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import ansys.aedt.core as pyaedt
from ansys.aedt.core import Icepak

# PyOpenMagnetics 1.2.0 for MAS file handling
import PyOpenMagnetics
print(f"PyOpenMagnetics: Loaded from {PyOpenMagnetics.__file__}")

from Ansyas import Ansyas

# Use Ansyas mas_autocomplete (uses PyMKF internally)
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')
import mas_autocomplete

# Configuration
ANSYS_VERSION = "2025.2"
NON_GRAPHICAL = True
OUTPUT_BASE_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\automated_tests'
MKF_TEST_FILE = r'\wsl.localhost\Ubuntu-22.04\home\alf\OpenMagnetics\MKF\tests\TestTemperature.cpp'


def kill_ansys_processes():
    """Kill any existing Ansys processes to free license."""
    print("\n[STEP 1/6] Killing existing Ansys processes...")
    subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], 
                   capture_output=True, check=False)
    subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], 
                   capture_output=True, check=False)
    time.sleep(3)
    print("  [OK] Processes killed")


def find_mas_files(examples_dir: str) -> List[str]:
    """Find all MAS JSON files in examples directory."""
    mas_files = []
    for file in os.listdir(examples_dir):
        if file.endswith('.json'):
            mas_files.append(os.path.join(examples_dir, file))
    return sorted(mas_files)


def run_icepak_simulation(mas_file: str, output_dir: str) -> Tuple[Optional[Icepak], Optional[Ansyas]]:
    """
    Run Icepak thermal simulation on MAS file.
    
    Returns:
        Tuple of (Icepak project, Ansyas instance) or (None, None) if failed
    """
    print(f"\n[STEP 2/6] Running Icepak simulation for: {os.path.basename(mas_file)}")
    
    # Create unique output directory
    timestamp = int(time.time())
    mas_basename = os.path.splitext(os.path.basename(mas_file))[0]
    project_name = f"auto_{mas_basename}_{timestamp}"
    project_output_dir = os.path.join(output_dir, project_name)
    os.makedirs(project_output_dir, exist_ok=True)
    
    try:
        # Load MAS file
        print("  Loading MAS file...")
        with open(mas_file, 'r') as f:
            mas_dict = json.load(f)
        
        # Auto-complete MAS data using Ansyas mas_autocomplete
        mas = mas_autocomplete.autocomplete(mas_dict)
        
        # Initialize Ansyas
        print("  Initializing Ansyas...")
        ansyas = Ansyas(
            number_segments_arcs=12,
            initial_mesh_configuration=2,
            maximum_error_percent=5,
            refinement_percent=30,
            maximum_passes=15,
            scale=1
        )
        
        # Create project (this initializes the AEDT session)
        print("  Creating AEDT project...")
        project = ansyas.create_project(
            outputs_folder=project_output_dir,
            project_name=project_name,
            non_graphical=NON_GRAPHICAL,
            solution_type="SteadyState",  # Use SteadyState for Icepak thermal simulation
            new_desktop_session=True
        )
        
        if project is None:
            raise RuntimeError("Failed to create AEDT project")
        
        # Set units to meters (important for Icepak)
        ansyas.set_units("meter")
        print("  [OK] Project created and units set to meters")
        
        # Create thermal simulation
        print("  Setting up Icepak simulation geometry...")
        ansyas.create_magnetic_simulation(
            mas=mas,
            simulate=False,  # Don't simulate yet, we'll set up thermal first
            operating_point_index=0
        )
        
        print(f"  [OK] Icepak project setup complete: {project_name}")
        return project, ansyas
        
    except Exception as e:
        print(f"  [ERROR] Failed to run simulation: {e}")
        import traceback
        traceback.print_exc()
        return None, None


def run_icepak_analysis(project: Icepak, setup_name: str = "Setup1"):
    """Create setup and run Icepak analysis."""
    print("\n[STEP 3/6] Setting up and running Icepak analysis...")
    
    try:
        # Create setup if it doesn't exist
        if not project.setups:
            print("  Creating Icepak setup...")
            setup = project.create_setup(setup_name)
            print(f"  [OK] Setup '{setup_name}' created")
        else:
            setup = project.setups[0]
            print(f"  [OK] Using existing setup: {setup.name}")
        
        # Run analysis
        print("  Running Icepak thermal simulation (this may take several minutes)...")
        project.analyze_setup(setup.name)
        print("  [OK] Simulation completed")
        
    except Exception as e:
        print(f"  [ERROR] Simulation failed: {e}")
        raise RuntimeError(f"Icepak simulation failed: {e}")


def extract_temperatures_with_monitors(project: Icepak) -> Dict[str, float]:
    """
    Extract temperatures using point monitors (Student version compatible).
    
    This method creates temperature monitors on each object BEFORE running
    the simulation, then reads the monitor values after simulation completes.
    Works with Ansys Student version.
    
    Returns:
        Dictionary mapping object names to temperatures
    """
    print("\n[STEP 4/6] Extracting temperatures using point monitors...")
    
    temperatures = {}
    monitor_names = {}
    
    try:
        # Get object names from project
        object_names = project.modeler.object_names
        print(f"  Found {len(object_names)} objects in project")
        
        # Filter for relevant thermal objects
        temp_objects = []
        for obj_name in object_names:
            if any(keyword in obj_name.lower() for keyword in 
                   ['core', 'bobbin', 'copper', 'turn', 'primary', 'secondary', 'winding']):
                temp_objects.append(obj_name)
        
        print(f"  Found {len(temp_objects)} thermal objects to monitor")
        
        if not temp_objects:
            raise RuntimeError("No thermal objects found in project")
        
        # Step 1: Create temperature monitors on each object
        print("  Creating temperature monitors...")
        for obj_name in temp_objects:
            try:
                # Create monitor name
                monitor_name = f"TempMonitor_{obj_name.replace(' ', '_').replace('-', '_')}"
                
                # Create point monitor inside object
                result = project.assign_point_monitor_in_object(
                    name=obj_name,
                    monitor_type="Temperature",
                    monitor_name=monitor_name
                )
                
                if result:
                    monitor_names[obj_name] = monitor_name
                    print(f"    [OK] Monitor created for {obj_name}")
                else:
                    print(f"    [WARN] Failed to create monitor for {obj_name} (returned False)")
                
            except Exception as e:
                print(f"    [WARN] Failed to create monitor for {obj_name}: {e}")
                continue
        
        if not monitor_names:
            raise RuntimeError("No monitors could be created")
        
        print(f"  [OK] Created {len(monitor_names)} temperature monitors")
        
        # Step 2: Run the simulation
        run_icepak_analysis(project)
        
        # Step 3: Read monitor values
        print("  Reading monitor values...")
        
        # Try different methods to read monitor values
        # Method 1: Try using omonitor
        try:
            if hasattr(project, 'omonitor'):
                print("  Using omonitor to read values...")
                for obj_name, monitor_name in monitor_names.items():
                    try:
                        # Get monitor value using omonitor
                        value = project.omonitor.GetMonitorValue(monitor_name)
                        if value:
                            temp = float(value)
                            temperatures[obj_name] = temp
                            print(f"    {obj_name}: {temp:.2f}°C")
                    except Exception as e:
                        print(f"    [WARN] omonitor failed for {monitor_name}: {e}")
                        continue
        except Exception as e:
            print(f"  omonitor method failed: {e}")
        
        # Method 2: Try using project.monitor property
        if not temperatures and hasattr(project, 'monitor'):
            try:
                print("  Using project.monitor to read values...")
                monitor_obj = project.monitor
                for obj_name, monitor_name in monitor_names.items():
                    try:
                        if hasattr(monitor_obj, 'get_monitor_value'):
                            value = monitor_obj.get_monitor_value(monitor_name)
                            if value:
                                temp = float(value)
                                temperatures[obj_name] = temp
                                print(f"    {obj_name}: {temp:.2f}°C")
                    except Exception as e:
                        print(f"    [WARN] monitor property failed for {monitor_name}: {e}")
                        continue
            except Exception as e:
                print(f"  project.monitor method failed: {e}")
        
        # Method 3: Try reading from solution reports
        if not temperatures:
            try:
                print("  Trying to read from solution reports...")
                # Get setup name
                setup_name = None
                if hasattr(project, 'setups') and project.setups:
                    setup_name = project.setups[0].name
                
                if setup_name:
                    for obj_name, monitor_name in monitor_names.items():
                        try:
                            # Create a simple report for this monitor
                            report_name = f"Report_{monitor_name}"
                            success = project.post.create_report(
                                expressions=[monitor_name],
                                setup_sweep_name=f"{setup_name} : LastAdaptive"
                            )
                            if success:
                                report_data = project.post.get_report_data(report_name)
                                if report_data and len(report_data.data_magnitude()) > 0:
                                    temp = report_data.data_magnitude()[0]
                                    temperatures[obj_name] = temp
                                    print(f"    {obj_name}: {temp:.2f}°C")
                        except Exception as e:
                            print(f"    [WARN] Report method failed for {monitor_name}: {e}")
                            continue
            except Exception as e:
                print(f"  Solution report method failed: {e}")
        
        if not temperatures:
            raise RuntimeError("No temperatures could be extracted from monitors")
        
        print(f"  [OK] Successfully extracted {len(temperatures)} temperatures")
        return temperatures
        
    except Exception as e:
        print(f"  [ERROR] Failed to extract temperatures: {e}")
        import traceback
        traceback.print_exc()
        raise RuntimeError(f"Automatic temperature extraction failed: {e}")


def generate_cpp_test_case(mas_file: str, temperatures: Dict[str, float], 
                           test_name: str) -> str:
    """
    Generate C++ test case code for TestTemperature.cpp.
    
    Returns:
        C++ test case string
    """
    print(f"\n[STEP 5/6] Generating C++ test case: {test_name}")
    
    # Extract reference values from temperatures
    core_temps = []
    bobbin_temps = []
    turn_temps = []
    
    for obj_name, temp in temperatures.items():
        obj_lower = obj_name.lower()
        if 'core' in obj_lower and 'bobbin' not in obj_lower:
            core_temps.append((obj_name, temp))
        elif 'bobbin' in obj_lower:
            bobbin_temps.append((obj_name, temp))
        elif any(kw in obj_lower for kw in ['turn', 'copper', 'primary', 'secondary', 'winding']):
            turn_temps.append((obj_name, temp))
    
    # Calculate statistics
    avg_core_temp = sum(t for _, t in core_temps) / len(core_temps) if core_temps else 0
    max_core_temp = max((t for _, t in core_temps), default=0)
    min_core_temp = min((t for _, t in core_temps), default=0)
    
    avg_bobbin_temp = sum(t for _, t in bobbin_temps) / len(bobbin_temps) if bobbin_temps else 0
    
    # Generate test case
    mas_basename = os.path.splitext(os.path.basename(mas_file))[0]
    
    cpp_code = f"""
// =============================================================================
// Auto-generated Icepak Temperature Test
// Source MAS: {mas_basename}
// Generated: {datetime.now().isoformat()}
// PyAEDT Version: {pyaedt.__version__}
// Ansys Version: {ANSYS_VERSION}
// =============================================================================

TEST_F(TemperatureTests, {test_name}) {{
    // Load MAS file for: {mas_basename}
    std::string masFile = "{mas_file}";
    auto masData = OpenMagnetics::loadMas(masFile);
    
    // Configure thermal simulation
    OpenMagnetics::ThermalSimulation thermalSim;
    thermalSim.setMeshDensity(OpenMagnetics::MeshDensity::Medium);
    thermalSim.setConvergenceCriteria(5.0);  // 5% error
    
    // Run thermal simulation
    auto result = thermalSim.run(masData);
    
    // Verify core temperatures (reference values from Icepak {ANSYS_VERSION})
    // Average core temperature: {avg_core_temp:.2f}°C
    EXPECT_NEAR(result.getCoreAverageTemperature(), {avg_core_temp:.2f}, 5.0);
    
    // Max core temperature: {max_core_temp:.2f}°C
    EXPECT_NEAR(result.getCoreMaxTemperature(), {max_core_temp:.2f}, 5.0);
    
    // Min core temperature: {min_core_temp:.2f}°C  
    EXPECT_NEAR(result.getCoreMinTemperature(), {min_core_temp:.2f}, 5.0);
    
    // Verify bobbin temperature
    // Average bobbin temperature: {avg_bobbin_temp:.2f}°C
    EXPECT_NEAR(result.getBobbinTemperature(), {avg_bobbin_temp:.2f}, 5.0);
    
    // Verify winding count
    EXPECT_EQ(result.getWindingCount(), {len(turn_temps)});
"""
    
    # Add per-turn assertions (up to first 10)
    for i, (obj_name, temp) in enumerate(turn_temps[:10]):
        cpp_code += f"    // {obj_name}: {temp:.2f}°C\n"
        cpp_code += f"    EXPECT_NEAR(result.getWindingTemperature({i}), {temp:.2f}, 10.0);\n"
    
    if len(turn_temps) > 10:
        cpp_code += f"    // ... and {len(turn_temps) - 10} more winding temperature checks\n"
    
    cpp_code += "}\n"
    
    print("  [OK] C++ test case generated")
    return cpp_code


def append_to_test_file(cpp_code: str, test_file: str):
    """Append generated test case to TestTemperature.cpp."""
    print(f"\n[STEP 6/6] Appending to test file...")
    
    try:
        # Check if file exists and is accessible
        if os.path.exists(test_file):
            # Read existing content
            with open(test_file, 'r') as f:
                existing = f.read()
            
            # Append new test
            with open(test_file, 'a') as f:
                if not existing.endswith('\n'):
                    f.write('\n')
                f.write(cpp_code)
            
            print(f"  [OK] Test case appended to: {test_file}")
        else:
            # Create new file
            with open(test_file, 'w') as f:
                f.write("// Auto-generated temperature tests\n")
                f.write("#include <gtest/gtest.h>\n")
                f.write("#include \"ThermalSimulation.h\"\n")
                f.write("\n")
                f.write("class TemperatureTests : public ::testing::Test {};\n")
                f.write(cpp_code)
            
            print(f"  [OK] New test file created: {test_file}")
        
    except Exception as e:
        print(f"  [ERROR] Failed to write to test file: {e}")
        # Save to backup location
        backup_file = os.path.join(OUTPUT_BASE_DIR, "generated_tests.cpp")
        os.makedirs(OUTPUT_BASE_DIR, exist_ok=True)
        with open(backup_file, 'w') as f:
            f.write(cpp_code)
        print(f"  [BACKUP] Test saved to: {backup_file}")


def process_mas_file(mas_file: str) -> bool:
    """
    Process a single MAS file: simulate, extract, generate test.
    
    Returns:
        True if successful, False otherwise
    """
    mas_basename = os.path.splitext(os.path.basename(mas_file))[0]
    test_name = f"AutoTemp_{mas_basename}_{int(time.time())}"
    
    print("\n" + "="*80)
    print(f"PROCESSING: {mas_basename}")
    print("="*80)
    
    try:
        # Step 1: Kill existing processes
        kill_ansys_processes()
        
        # Step 2: Run simulation
        project, ansyas = run_icepak_simulation(mas_file, OUTPUT_BASE_DIR)
        if project is None:
            raise RuntimeError("Simulation setup failed")
        
        # Step 3: Extract temperatures
        temperatures = extract_temperatures_with_monitors(project)
        if not temperatures:
            raise RuntimeError("Temperature extraction failed - no data retrieved")
        
        # Step 4: Generate test case
        cpp_code = generate_cpp_test_case(mas_file, temperatures, test_name)
        
        # Step 5: Append to test file
        append_to_test_file(cpp_code, MKF_TEST_FILE)
        
        # Step 6: Cleanup
        print("\n[STEP 6/6] Cleaning up...")
        try:
            if ansyas and hasattr(ansyas, 'solver_backend'):
                ansyas.solver_backend.close()
        except Exception as e:
            print(f"  [WARN] Error during cleanup: {e}")
        
        # Kill processes again to ensure license is freed
        kill_ansys_processes()
        print("  [OK] Cleanup complete")
        
        print("\n" + "="*80)
        print(f"[SUCCESS] Completed: {mas_basename}")
        print("="*80)
        return True
        
    except Exception as e:
        print(f"\n[FAILED] {mas_basename}: {e}")
        import traceback
        traceback.print_exc()
        
        # Ensure processes are killed even on failure
        kill_ansys_processes()
        
        return False


def main():
    """Main entry point."""
    print("\n" + "="*80)
    print("AUTOMATED ICEPAK TEMPERATURE EXTRACTION - PyAEDT 1.0.0rc1")
    print("="*80)
    print(f"PyAEDT Version: {pyaedt.__version__}")
    print(f"Ansys Version: {ANSYS_VERSION}")
    print(f"Output Directory: {OUTPUT_BASE_DIR}")
    print(f"MKF Test File: {MKF_TEST_FILE}")
    print("Mode: FULLY AUTOMATED - No manual intervention")
    print("="*80)
    
    # Find MAS files
    examples_dir = r'C:\Users\Alfonso\wuerth\Ansyas\examples'
    if not os.path.exists(examples_dir):
        print(f"\n[ERROR] Examples directory not found: {examples_dir}")
        sys.exit(1)
    
    mas_files = find_mas_files(examples_dir)
    
    if not mas_files:
        print(f"\n[ERROR] No MAS files found in {examples_dir}")
        sys.exit(1)
    
    print(f"\nFound {len(mas_files)} MAS files to process:")
    for i, f in enumerate(mas_files, 1):
        print(f"  {i}. {os.path.basename(f)}")
    
    # Process each MAS file
    success_count = 0
    fail_count = 0
    failed_files = []
    
    for mas_file in mas_files:
        if process_mas_file(mas_file):
            success_count += 1
        else:
            fail_count += 1
            failed_files.append(os.path.basename(mas_file))
            # Stop on first failure as per requirements
            print("\n[CRITICAL] Processing failed - stopping as per automation requirements")
            break
    
    # Summary
    print("\n" + "="*80)
    print("PROCESSING SUMMARY")
    print("="*80)
    print(f"Success: {success_count}")
    print(f"Failed: {fail_count}")
    print(f"Total: {success_count + fail_count}")
    
    if failed_files:
        print(f"\nFailed files:")
        for f in failed_files:
            print(f"  - {f}")
    
    if fail_count > 0:
        print("\n[EXIT] Failures detected - returning error code")
        sys.exit(1)
    
    print("\n[OK] All processing complete!")
    print(f"Generated test cases have been appended to: {MKF_TEST_FILE}")


if __name__ == "__main__":
    main()
