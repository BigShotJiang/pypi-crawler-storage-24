#!/usr/bin/env python3
"""
Test runner for generate_temperature_tests.py
Run this from C:\Users\Alfonso\wuerth\Ansyas
"""

import sys
import os
from pathlib import Path

# Add the script path
script_path = Path("/home/alf/OpenMagnetics/MKF/src/scripts")
if script_path.exists():
    sys.path.insert(0, str(script_path))
    print(f"Added to path: {script_path}")
else:
    print(f"WARNING: Script path not found: {script_path}")
    print("Trying alternative path...")
    # Try WSL path
    script_path = Path("//wsl.localhost/Ubuntu-22.04/home/alf/OpenMagnetics/MKF/src/scripts")
    if script_path.exists():
        sys.path.insert(0, str(script_path))
        print(f"Added to path: {script_path}")

# Now run the script
if __name__ == "__main__":
    try:
        # Import and run
        import generate_temperature_tests
        generate_temperature_tests.main()
    except ImportError as e:
        print(f"ERROR: Could not import generate_temperature_tests: {e}")
        print("\nTrying to run script directly...")
        
        # Try running directly
        import subprocess
        result = subprocess.run(
            [sys.executable, str(script_path / "generate_temperature_tests.py")],
            capture_output=True,
            text=True
        )
        print(result.stdout)
        if result.stderr:
            print("STDERR:", result.stderr)
