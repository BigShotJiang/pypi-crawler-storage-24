#!/usr/bin/env python3
"""
Quick demo - forces test regeneration with temperature extraction
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

from pathlib import Path
import json

print("=" * 80)
print("QUICK DEMO - Temperature Auto-Extraction")
print("=" * 80)
print()

# Paths
output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/demo")
output_path.mkdir(parents=True, exist_ok=True)

mas_file = Path("C:/Users/Alfonso/wuerth/Ansyas/examples/concentric_transformer.json")

print("Loading MAS...")
with open(mas_file, 'r') as f:
    mas_dict = json.load(f)

print("Importing Ansyas...")
import mas_autocomplete
from ansyas import Ansyas

mas = mas_autocomplete.autocomplete(mas_dict)

print("Creating Icepak project...")
ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project = ansyas.create_project(
    outputs_folder=str(output_path),
    project_name="demo_extraction",
    non_graphical=False,
    new_desktop_session=True,
    solution_type="SteadyState"
)

ansyas.set_units("meter")
print("[OK] Units set to meters")

print("Building geometry...")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)
print("[OK] Geometry built")

print("\n" + "=" * 80)
print("RUNNING SIMULATION...")
print("=" * 80)

ansyas.analyze()

print("[OK] Simulation completed!")

project.save_project()

print("\n" + "=" * 80)
print("AUTO-EXTRACTING TEMPERATURES")
print("=" * 80)

# Extract using CSV export
object_names = ['core_0', 'core_1', 'bobbin']
coil = mas_dict.get('magnetic', {}).get('coil', {})
turns_desc = coil.get('turnsDescription', [])
for i, turn in enumerate(turns_desc[:3]):  # Just first 3 turns for demo
    base_name = turn.get('name', f"Turn_{i}")
    object_names.append(base_name + '_copper')

print(f"\nExporting {len(object_names)} objects...")

try:
    csv_file = project.eval_volume_quantity_from_field_summary(
        object_list=object_names,
        quantity_name="Temp",
        savedir=str(output_path),
        filename="demo_temperatures.csv",
        sweep_name="Setup : SteadyState"
    )
    
    print(f"[OK] CSV exported: {csv_file}")
    
    # Read and display the CSV
    import csv
    with open(csv_file, 'r') as f:
        reader = csv.reader(f)
        print("\nExtracted Temperatures:")
        print("-" * 40)
        for i, row in enumerate(reader):
            if i < 10:  # Show first 10 rows
                print(f"  {row}")
        print("-" * 40)
    
    print("\n[OK] Auto-extraction successful!")
    
except Exception as e:
    print(f"[ERROR] Extraction failed: {e}")

print("\nClosing project...")
try:
    project.release_desktop(close_projects=True, close_desktop=True)
except:
    pass

print("\n" + "=" * 80)
print("DEMO COMPLETE")
print("=" * 80)
