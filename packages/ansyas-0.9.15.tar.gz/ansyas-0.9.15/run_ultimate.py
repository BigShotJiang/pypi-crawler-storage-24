#!/usr/bin/env python3
"""
ULTIMATE Icepak extraction - uses COM directly
NO EXCUSES - FULL AUTOMATION
"""

import sys
import os
import time
import subprocess
import json
from pathlib import Path
from datetime import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

print("=" * 80)
print("ULTIMATE AUTOMATIC Icepak Temperature Extraction")
print("ZERO USER INPUT - FULL AUTOMATION")
print("=" * 80)
print()

def kill_all_ansys():
    """Kill everything Ansys-related"""
    print("  Killing ALL Ansys processes...")
    
    # Multiple methods to ensure everything dies
    subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
    subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], capture_output=True)
    subprocess.run(["wmic", "process", "where", "name like '%icepak%'", "delete"], capture_output=True)
    
    time.sleep(5)
    print("  [OK] Processes killed")

# KILL EVERYTHING FIRST
kill_all_ansys()

# Setup paths
examples_dir = Path("C:/Users/Alfonso/wuerth/Ansyas/examples")
test_file = Path("//wsl.localhost/Ubuntu-22.04/home/alf/OpenMagnetics/MKF/tests/TestTemperature.cpp")
output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/ultimate_auto")
output_path.mkdir(parents=True, exist_ok=True)

# Get MAS file
mas_file = examples_dir / "concentric_transformer.json"
print(f"Processing: {mas_file.name}")

with open(mas_file, 'r') as f:
    mas_dict = json.load(f)

magnetic = mas_dict.get('magnetic', {})
core = magnetic.get('core', {})
coil = magnetic.get('coil', {})

core_shape = core.get('functionalDescription', {}).get('shape', {}).get('name', 'Unknown')
core_material = core.get('functionalDescription', {}).get('material', 'N87')
if isinstance(core_material, dict):
    core_material = core_material.get('name', 'N87')

functional_desc = coil.get('functionalDescription', [])
num_turns = [w.get('numberTurns', 0) for w in functional_desc]
num_windings = len(num_turns)
ambient_temp = 25.0

print(f"  Core: {core_shape} ({core_material})")
print(f"  Windings: {num_windings}, Turns: {num_turns}")

# Import and run
print("\n  Importing Ansyas...")
import mas_autocomplete
from ansyas import Ansyas

mas = mas_autocomplete.autocomplete(mas_dict)

ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project_name = f"ultimate_{mas_file.stem}_{int(time.time())}"
print(f"  Creating project: {project_name}")

project = ansyas.create_project(
    outputs_folder=str(output_path),
    project_name=project_name,
    non_graphical=True,
    new_desktop_session=True,
    solution_type="SteadyState"
)

ansyas.set_units("meter")

# Build geometry
print("  Building geometry...")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)

# Run simulation
print("\n  Running simulation...")
ansyas.analyze()
print("  [OK] Simulation completed!")

project.save_project()

# EXTRACT TEMPERATURES - METHOD 1: Try to use IronPython within AEDT
print("\n  Extracting temperatures...")

temperatures = {}
object_names = ['core_0', 'core_1', 'bobbin']

# Get design and module
print("  Using COM interface...")
try:
    oDesign = project._odesign
    oModule = oDesign.GetModule("ReportSetup")
    
    print("  Creating temperature reports...")
    for obj_name in object_names:
        try:
            report_name = f"Temp_{obj_name}"
            
            # Create report
            oModule.CreateReport(
                report_name,
                "Fields",
                "Rectangular Plot",
                "Setup : SteadyState",
                [],
                ["Temp"],
                ["X", "Y", "Z"],
                obj_name
            )
            
            # Export to CSV
            export_file = str(output_path / f"{obj_name}_temp.csv")
            oModule.ExportToFile(report_name, export_file)
            
            # Read CSV
            if Path(export_file).exists():
                with open(export_file, 'r') as f:
                    lines = f.readlines()
                    for line in lines:
                        if 'Temp' in line or ',' in line:
                            parts = line.strip().split(',')
                            if len(parts) >= 2:
                                try:
                                    temp = float(parts[-1])
                                    temperatures[obj_name] = temp
                                    print(f"    {obj_name}: {temp:.2f}C")
                                    break
                                except:
                                    continue
        except Exception as e:
            print(f"    {obj_name}: {e}")
            continue
    
except Exception as e:
    print(f"  COM method failed: {e}")

# METHOD 2: Try using field calculator directly
if not temperatures:
    print("\n  Trying field calculator...")
    try:
        oDesign = project._odesign
        oFields = oDesign.GetModule("FieldsReporter")
        
        for obj_name in object_names:
            try:
                # Use field calculator to get average temp
                # EnterQty("Temp")
                # EnterVol(obj_name)
                # CalcOp("Average")
                # AddNamedExpression("AvgTemp", "Fields")
                
                oFields.EnterQty("Temp")
                oFields.EnterVol(obj_name)
                oFields.CalcOp("Average")
                
                # Get the value
                # This is tricky - need to use GetTopEntryValue or similar
                # For now, try a simpler approach
                
                # Export field data
                export_file = str(output_path / f"{obj_name}_field.csv")
                oFields.ExportFieldData(
                    "Temp",
                    obj_name,
                    export_file,
                    [],
                    "Setup : SteadyState"
                )
                
                if Path(export_file).exists():
                    with open(export_file, 'r') as f:
                        content = f.read()
                        # Parse average from content
                        # This is format-dependent
                        print(f"    Exported {obj_name} field data")
                        
            except Exception as e:
                print(f"    {obj_name}: {e}")
                continue
                
    except Exception as e:
        print(f"  Field calculator failed: {e}")

# Close project
try:
    project.release_desktop(close_projects=True, close_desktop=True)
except:
    pass

kill_all_ansys()

if not temperatures:
    print("\n  [ERROR] Could not extract temperatures automatically")
    print("  This is a PyAEDT/Ansys Student version limitation")
    sys.exit(1)

print(f"\n  [OK] Extracted {len(temperatures)} temperatures")

# Generate test
print("\n  Generating C++ test...")

shape_clean = core_shape.replace(' ', '_').replace('/', '_')
test_name = f"Temperature_Concentric_{shape_clean}_{num_windings}W_{sum(num_turns)}T_Bobbin_Icepak"

tags = ["temperature", "icepak-validation", "smoke-test", "rectangular-winding-window"]
tags_str = ']['.join(tags)

turns_str = ', '.join(map(str, num_turns))
parallels_str = ', '.join(['1'] * num_windings)

temp_comments = [f"    // Icepak reference temperatures (ambient: {ambient_temp}C):"]
if 'core_0' in temperatures:
    temp_comments.append(f"    // Core Central Column: {temperatures['core_0']:.2f}C")
if 'core_1' in temperatures:
    temp_comments.append(f"    // Core Lateral Column: {temperatures['core_1']:.2f}C")
if 'bobbin' in temperatures:
    temp_comments.append(f"    // Bobbin: {temperatures['bobbin']:.2f}C")

temp_comments_str = '\n'.join(temp_comments)

cpp_test = f'''
TEST_CASE("{test_name}", "[{tags_str}]") {{
    // Icepak validation test generated on {datetime.now().strftime("%Y-%m-%d %H:%M")}
    // Source MAS file: {mas_file.stem}.json
    // Core: {core_shape} ({core_material})
    // Windings: {num_windings} with turns: {num_turns}
    
    std::vector<int64_t> numberTurns({{{turns_str}}});
    std::vector<int64_t> numberParallels({{{parallels_str}}});
    std::string shapeName = "{core_shape}";

    auto coil = OpenMagneticsTesting::get_quick_coil(numberTurns,
                                                     numberParallels,
                                                     shapeName,
                                                     1,
                                                     WindingOrientation::OVERLAPPING,
                                                     WindingOrientation::OVERLAPPING,
                                                     CoilAlignment::SPREAD,
                                                     CoilAlignment::SPREAD);

    std::string coreMaterial = "{core_material}";
    auto gapping = json::array();
    auto core = OpenMagneticsTesting::get_quick_core(shapeName, gapping, 1, coreMaterial);
    
    OpenMagnetics::Magnetic magnetic;
    magnetic.set_core(core);
    magnetic.set_coil(coil);

    TemperatureConfig config;
    config.ambientTemperature = {ambient_temp:.1f};
    config.coreLosses = 1.0;
    config.windingLosses = 0.5;
    applySimulatedLosses(config, magnetic);
    config.plotSchematic = false;
    
    Temperature temp(magnetic, config);
    auto result = temp.calculateTemperatures();
    
    REQUIRE(result.converged);
    REQUIRE(result.maximumTemperature > config.ambientTemperature);
    
{temp_comments_str}
    
    REQUIRE(result.totalThermalResistance > 0.0);
}}
'''

# Append to test file
with open(test_file, 'r') as f:
    content = f.read()

if content.rstrip().endswith('}'):
    last_brace = content.rstrip().rfind('}')
    if last_brace > 0:
        content = content[:last_brace] + cpp_test + '\n}\n'
    else:
        content += cpp_test
else:
    content += cpp_test

with open(test_file, 'w') as f:
    f.write(content)

print(f"  [OK] Test added!")
print()
print("=" * 80)
print("COMPLETE - FULLY AUTOMATED")
print("=" * 80)
print(f"\nExtracted temperatures:")
for name, temp in temperatures.items():
    print(f"  {name}: {temp:.2f}C")
print(f"\nTest file: {test_file}")
