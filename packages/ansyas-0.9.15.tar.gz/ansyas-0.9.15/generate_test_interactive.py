#!/usr/bin/env python3
"""
Temperature test generator with manual temperature extraction.
Runs Icepak simulation and creates test template for manual temperature entry.
"""

import json
import re
import sys
import os
import time
import subprocess
from pathlib import Path
from datetime import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

print("=" * 80)
print("Temperature Test Generator - Semi-Automated")
print("Runs Icepak simulation, creates test template")
print("=" * 80)
print()

examples_dir = Path("C:/Users/Alfonso/wuerth/Ansyas/examples")
test_file = Path("//wsl.localhost/Ubuntu-22.04/home/alf/OpenMagnetics/MKF/tests/TestTemperature.cpp")
output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/temp_generator")

def kill_ansys_processes():
    print("  Cleaning up Ansys processes...")
    subprocess.run(["taskkill", "/F", "/IM", "ansys*.exe"], capture_output=True)
    subprocess.run(["taskkill", "/F", "/IM", "Icepak*.exe"], capture_output=True)
    time.sleep(2)

# Process the example
mas_file = examples_dir / "concentric_transformer.json"
print(f"Processing: {mas_file.name}")

with open(mas_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

magnetic = data.get('magnetic', {})
core = magnetic.get('core', {})
coil_data = magnetic.get('coil', {})

core_functional = core.get('functionalDescription', {})
shape = core_functional.get('shape', {})
core_shape = shape.get('name', 'Unknown')

material_data = core_functional.get('material', 'N87')
if isinstance(material_data, dict):
    core_material = material_data.get('name', 'N87')
else:
    core_material = material_data

functional_desc = coil_data.get('functionalDescription', [])
num_turns = [w.get('numberTurns', 0) for w in functional_desc]
num_windings = len(num_turns)

bobbin = coil_data.get('bobbin', {})
has_bobbin = isinstance(bobbin, dict) and bobbin.get('processedDescription') is not None

family = shape.get('family', '')
is_toroidal = family.lower() == 't' if isinstance(family, str) else False

print(f"  Core: {core_shape} ({core_material})")
print(f"  Windings: {num_windings}, Turns: {num_turns}")

# Generate test name
shape_clean = core_shape.replace(' ', '_').replace('/', '_')
parts = ["Temperature"]
parts.append("Toroidal" if is_toroidal else "Concentric")
parts.append(shape_clean)
if num_windings > 1:
    parts.append(f"{num_windings}W")
total_turns = sum(num_turns) if num_turns else 0
parts.append(f"{total_turns}T")
if has_bobbin:
    parts.append("Bobbin")
parts.append("Icepak")
test_name = "_".join(parts)

print(f"  Test name: {test_name}")

# Check if test exists
if test_file.exists():
    with open(test_file, 'r', encoding='utf-8') as f:
        content = f.read()
    pattern = rf'TEST_CASE\s*\(\s*"{re.escape(test_name)}"'
    if re.search(pattern, content):
        print("  [SKIP] Test already exists")
        sys.exit(0)

# Run Icepak simulation
print("\n  [RUN] Starting Icepak simulation...")
print("  Ansys GUI will open. Please wait for simulation to complete.")
print()

output_path.mkdir(parents=True, exist_ok=True)
kill_ansys_processes()

try:
    import mas_autocomplete
    from ansyas import Ansyas
    
    with open(mas_file, 'r', encoding='utf-8') as f:
        mas_dict = json.load(f)
    
    mas = mas_autocomplete.autocomplete(mas_dict)
    
    # Get cooling info
    inputs = mas_dict.get('inputs', {})
    operating_points = inputs.get('operatingPoints', [{}])
    cooling = operating_points[0].get('cooling', {}) if operating_points else {}
    ambient_temp = cooling.get('temperature', 25.0)
    
    ansyas = Ansyas(
        number_segments_arcs=12,
        initial_mesh_configuration=2,
        maximum_error_percent=5,
        refinement_percent=30,
        maximum_passes=15,
        scale=1
    )
    
    project_name = f"temp_test_{mas_file.stem}_{int(time.time())}"
    project = ansyas.create_project(
        outputs_folder=str(output_path),
        project_name=project_name,
        non_graphical=False,
        new_desktop_session=True,
        solution_type="SteadyState"
    )
    
    ansyas.set_units("meter")
    print("  [OK] Project created with meter units")
    
    # Build and simulate
    ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)
    print("  [OK] Geometry built")
    
    print("\n" + "=" * 80)
    print("RUNNING SIMULATION - PLEASE WAIT")
    print("=" * 80)
    
    ansyas.analyze()
    
    print("\n  [OK] Simulation completed!")
    project.save_project()
    print(f"  [OK] Project saved: {output_path / project_name}.aedt")
    
    # Keep project open for review
    print("\n" + "=" * 80)
    print("SIMULATION COMPLETE")
    print("=" * 80)
    print()
    print("The Icepak project is still open in Ansys.")
    print()
    print("TO EXTRACT TEMPERATURES:")
    print("  1. In Ansys GUI, go to 'Results' tab")
    print("  2. Click 'Create Field Report'")
    print("  3. Select Quantity: 'Temp'")
    print("  4. Select Geometry: core_0, core_1, bobbin, turns")
    print("  5. Note down the average temperatures")
    print()
    print("OBJECTS IN MODEL:")
    print("  - core_0 (central column)")
    print("  - core_1 (lateral column)")
    print("  - bobbin")
    print("  - Turns: 'Primary parallel X turn Y_copper'")
    print()
    print("Press Ctrl+C when you're ready to close Ansys and create the test.")
    print("=" * 80)
    
    # Wait for user
    input("\nPress Enter when you have extracted the temperatures...")
    
    # Ask for temperatures
    print("\nEnter the temperatures you extracted from Ansys:")
    print("(Press Enter to skip if you didn't extract a value)")
    print()
    
    temperatures = {}
    
    temp = input("Core Central Column (core_0) temperature [C]: ").strip()
    if temp:
        temperatures['core_central_column'] = float(temp)
    
    temp = input("Core Lateral Column (core_1) temperature [C]: ").strip()
    if temp:
        temperatures['core_lateral_column'] = float(temp)
    
    temp = input("Bobbin temperature [C]: ").strip()
    if temp:
        temperatures['bobbin'] = float(temp)
    
    # Get a few turn temperatures
    turn_temps = {}
    for i in range(min(5, total_turns)):
        temp = input(f"Turn {i} temperature [C] (or press Enter to skip): ").strip()
        if temp:
            turn_temps[f"turn_{i}"] = float(temp)
    
    temperatures.update(turn_temps)
    
    print(f"\n  [OK] Collected {len(temperatures)} temperatures")
    
    # Close Ansys
    try:
        project.save_project()
        project.release_desktop(close_projects=True, close_desktop=True)
    except:
        pass
    
    kill_ansys_processes()
    
except Exception as e:
    print(f"\n  [ERROR] {e}")
    kill_ansys_processes()
    sys.exit(1)

# Generate test
print("\n  [GENERATE] Creating test...")

tags = ["temperature", "icepak-validation", "smoke-test"]
tags.append("round-winding-window" if is_toroidal else "rectangular-winding-window")
tags_str = ']['.join(tags)

turns_str = ', '.join(map(str, num_turns))
parallels_str = ', '.join(['1'] * num_windings) if num_windings > 0 else '1'

# Build temperature comments
temp_comments = [f"    // Icepak reference temperatures (ambient: {ambient_temp}C):"]

if 'core_central_column' in temperatures:
    temp_comments.append(f"    // Core Central Column: {temperatures['core_central_column']:.2f}C")
if 'core_lateral_column' in temperatures:
    temp_comments.append(f"    // Core Lateral Column: {temperatures['core_lateral_column']:.2f}C")
if 'bobbin' in temperatures:
    temp_comments.append(f"    // Bobbin: {temperatures['bobbin']:.2f}C")

if turn_temps:
    temp_comments.append(f"    // Turn temperatures ({len(turn_temps)} extracted):")
    for name, temp in sorted(turn_temps.items()):
        temp_comments.append(f"    //   {name}: {temp:.2f}C")
    if len(turn_temps) < total_turns:
        temp_comments.append(f"    //   ... and {total_turns - len(turn_temps)} more turns")

temp_comments_str = '\n'.join(temp_comments)

cpp_test = f'''
TEST_CASE("{test_name}", "[{tags_str}]") {{
    // Icepak validation test generated on {datetime.now().strftime("%Y-%m-%d %H:%M")}
    // Source MAS file: {mas_file.stem}.json
    // Core: {core_shape} ({core_material})
    // Windings: {num_windings} with turns: {num_turns}
    // Cooling: natural convection
    
    std::vector<int64_t> numberTurns({{{turns_str}}});
    std::vector<int64_t> numberParallels({{{parallels_str}}});
    std::string shapeName = "{core_shape}";

    auto coil = OpenMagneticsTesting::get_quick_coil(numberTurns,
                                                     numberParallels,
                                                     shapeName,
                                                     1,
                                                     WindingOrientation::OVERLAPPING,
                                                     WindingOrientation::OVERLAPPING,
                                                     CoilAlignment::SPREAD,
                                                     CoilAlignment::SPREAD);

    std::string coreMaterial = "{core_material}";
    auto gapping = json::array();
    auto core = OpenMagneticsTesting::get_quick_core(shapeName, gapping, 1, coreMaterial);
    
    OpenMagnetics::Magnetic magnetic;
    magnetic.set_core(core);
    magnetic.set_coil(coil);

    TemperatureConfig config;
    config.ambientTemperature = {ambient_temp:.1f};
    config.coreLosses = 1.0;
    config.windingLosses = 0.5;
    applySimulatedLosses(config, magnetic);
    config.plotSchematic = false;
    
    Temperature temp(magnetic, config);
    auto result = temp.calculateTemperatures();
    
    REQUIRE(result.converged);
    REQUIRE(result.maximumTemperature > config.ambientTemperature);
    
{temp_comments_str}
    
    REQUIRE(result.totalThermalResistance > 0.0);
}}
'''

# Append to test file
if test_file.exists():
    with open(test_file, 'r', encoding='utf-8') as f:
        content = f.read()
    if content.rstrip().endswith('}'):
        last_brace = content.rstrip().rfind('}')
        if last_brace > 0:
            content = content[:last_brace] + cpp_test + '\n}\n'
        else:
            content += cpp_test
    else:
        content += cpp_test
else:
    content = cpp_test

with open(test_file, 'w', encoding='utf-8') as f:
    f.write(content)

print(f"  [OK] Test added to TestTemperature.cpp")
print()
print("=" * 80)
print("COMPLETE")
print("=" * 80)
print(f"\nTest file: {test_file}")
print(f"Temperatures collected: {len(temperatures)}")
print("\nNext steps:")
print("  1. Build MKF: cd /home/alf/OpenMagnetics/MKF/build && make -j$(nproc)")
print("  2. Run test: ./tests/TestTemperature '{test_name}'")
