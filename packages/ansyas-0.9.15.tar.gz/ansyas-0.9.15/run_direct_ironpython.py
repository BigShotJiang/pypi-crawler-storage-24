#!/usr/bin/env python3
"""
Execute IronPython code directly via PyAEDT oDesktop
This runs inside AEDT, not via gRPC, so it should work with Student version
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import os
import json

import ansys.aedt.core as pyaedt
from Ansyas import Ansyas
import mas_autocomplete

OUTPUT_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\direct_ironpython'
os.makedirs(OUTPUT_DIR, exist_ok=True)

MAS_FILE = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'

print("="*80)
print("DIRECT IRONPYTHON EXECUTION VIA oDesktop")
print("="*80)

# Load and create simulation
print("\n1. Creating simulation...")
with open(MAS_FILE, 'r') as f:
    mas_dict = json.load(f)
mas = mas_autocomplete.autocomplete(mas_dict)

ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project = ansyas.create_project(
    outputs_folder=OUTPUT_DIR,
    project_name="direct_ironpython",
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=True
)

ansyas.set_units("meter")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)

# Enable gravity
setup = project.setups[0]
setup.props['Include Gravity'] = True
setup.update()

# Run simulation
print("\n2. Running simulation...")
project.analyze_setup(setup.name)
print("   Simulation completed")

# Execute IronPython code via oDesktop
print("\n3. Executing IronPython code via oDesktop...")

# Get objects
object_names = [obj for obj in project.modeler.object_names 
                if any(kw in obj.lower() for kw in ['core', 'bobbin', 'copper', 'turn'])]

print(f"   Objects to extract: {len(object_names)}")

# Build IronPython script
ironpython_script = """
# IronPython script to export temperatures
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
oModule = oDesign.GetModule("FieldsReporter")

# Setup field summary calculations
"""

for obj_name in object_names[:10]:  # Limit to first 10 for testing
    ironpython_script += f'''
try:
    oModule.EditFieldsSummarySetting(
        ["Calculation:=", ["Object", "Volume", "{obj_name}", "Temperature", "", "Default"]]
    )
except:
    pass
'''

export_file = os.path.join(OUTPUT_DIR, "temperatures_from_ironpython.csv").replace('\\', '/')

ironpython_script += f'''
# Export
variations = oDesign.GetNominalVariation()
oModule.ExportFieldsSummary(
    [
        "SolutionName:=", "Setup : LastAdaptive",
        "DesignVariationKey:=", variations,
        "ExportFileName:=", "{export_file}"
    ]
)

# Also export solution overview
oDesign.ExportSolutionOverview(
    [
        "SetupName:=", "Setup",
        "ExportFilePath:=", "{OUTPUT_DIR}/solution_overview.txt".replace('\\\\', '/'),
        "Overwrite:=", True
    ]
)
'''

print("   IronPython script built")

# Execute the script
try:
    odesktop = project.odesktop
    odesktop.ExecuteCommand(ironpython_script)
    print("   [OK] IronPython script executed")
    
    # Check for output files
    print("\n   Checking for output files...")
    if os.path.exists(export_file):
        print(f"   [SUCCESS] Temperature file created: {export_file}")
        with open(export_file, 'r') as f:
            content = f.read()
            print(f"   File size: {len(content)} bytes")
            print("   First 500 chars:")
            print(content[:500])
    else:
        print(f"   [WARNING] File not found: {export_file}")
        print(f"   Files in output: {os.listdir(OUTPUT_DIR)}")
        
except Exception as e:
    print(f"   [ERROR] Execution failed: {e}")
    import traceback
    traceback.print_exc()

# Cleanup
project.save_project()
ansyas.solver_backend.close()

print("\n" + "="*80)
print("Done")
print("="*80)
