#!/usr/bin/env python3
"""
Extract temperatures using IronPython approach via PyAEDT
This uses oModule.EditFieldsSummarySetting and oModule.ExportFieldsSummary
which work in Student version when called directly (not via gRPC)
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import os
import json
import time
from datetime import datetime

import ansys.aedt.core as pyaedt
from Ansyas import Ansyas
import mas_autocomplete

OUTPUT_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\ironpython_extraction'
os.makedirs(OUTPUT_DIR, exist_ok=True)

MAS_FILE = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'

print("="*80)
print("TEMPERATURE EXTRACTION - IronPython Approach via PyAEDT")
print("="*80)

# Load and run simulation
print("\n1. Creating and running simulation...")
with open(MAS_FILE, 'r') as f:
    mas_dict = json.load(f)
mas = mas_autocomplete.autocomplete(mas_dict)

ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project = ansyas.create_project(
    outputs_folder=OUTPUT_DIR,
    project_name="ironpython_extraction",
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=True
)

ansyas.set_units("meter")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)

# Enable gravity
setup = project.setups[0]
setup.props['Include Gravity'] = True
setup.update()

# Run simulation
project.analyze_setup(setup.name)
print("   Simulation completed")

# Extract temperatures using IronPython approach
print("\n2. Extracting temperatures using IronPython approach...")

# Get objects to measure
object_names = [obj for obj in project.modeler.object_names 
                if any(kw in obj.lower() for kw in ['core', 'bobbin', 'copper', 'turn'])]

print(f"   Found {len(object_names)} objects")

temperatures = {}

# Try to use the osolution module directly
try:
    # Access the osolution module
    osolution = project.osolution
    
    # Set up field summary calculations for each object
    print("\n   Setting up field summary...")
    calc_settings = []
    for obj_name in object_names:
        try:
            # Add calculation: Object, Volume, object_name, Temperature
            calc_settings.extend([
                "Calculation:=", 
                ["Object", "Volume", obj_name, "Temperature", "", "Default"]
            ])
        except Exception as e:
            print(f"   [WARN] Could not add {obj_name}: {e}")
    
    # Edit fields summary settings
    osolution.EditFieldsSummarySetting(calc_settings)
    print("   Field summary settings configured")
    
    # Export to CSV
    export_file = os.path.join(OUTPUT_DIR, "temperatures.csv")
    
    # Get variation string
    variations = project.available_variations.nominal_values
    var_string = " ".join([f"{k}='{v}'" for k, v in variations.items()])
    
    osolution.ExportFieldsSummary([
        "SolutionName:=", setup.name,
        "DesignVariationKey:=", var_string,
        "ExportFileName:=", export_file
    ])
    
    print(f"   Exported to: {export_file}")
    
    # Read the exported CSV
    if os.path.exists(export_file):
        with open(export_file, 'r') as f:
            lines = f.readlines()
        
        print(f"\n   Reading {len(lines)} lines...")
        for line in lines[1:]:  # Skip header
            parts = line.strip().split(',')
            if len(parts) >= 4:
                obj_name = parts[0].strip()
                try:
                    avg_temp = float(parts[3])
                    temperatures[obj_name] = avg_temp
                    print(f"     {obj_name}: {avg_temp:.2f}°C")
                except (ValueError, IndexError):
                    pass
    else:
        print(f"   [WARNING] Export file not found: {export_file}")
        
except Exception as e:
    print(f"   [ERROR] Extraction failed: {e}")
    import traceback
    traceback.print_exc()

# Cleanup
project.save_project()
ansyas.solver_backend.close()

print("\n" + "="*80)
if temperatures:
    print(f"SUCCESS! Extracted {len(temperatures)} temperatures")
    print("\nSummary:")
    for name, temp in sorted(temperatures.items())[:10]:
        print(f"  {name}: {temp:.2f}°C")
else:
    print("FAILED to extract temperatures")
print("="*80)
