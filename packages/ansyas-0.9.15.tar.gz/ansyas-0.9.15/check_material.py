"""
Create an Ansys project with WE_A material for manual inspection.
Run this script to generate a project that can be opened in Ansys GUI.
"""
import sys
import os
sys.path.insert(0, 'src/')
sys.path.insert(0, 'src/Ansyas/')

import json
from Ansyas import Ansyas
try:
    from Ansyas import mas_autocomplete
except ImportError:
    import mas_autocomplete

# Load CMC MAS file
with open('tests/mas_files/cmc.json', 'r') as f:
    mas_dict = json.load(f)

# Load core materials
material_file_path = 'external_data/core_materials.ndjson'
if os.path.exists(material_file_path):
    with open(material_file_path, 'r') as material_file:
        material_data = material_file.read()
        import PyMKF
        PyMKF.load_core_materials(material_data)

# Process MAS
mas = mas_autocomplete.autocomplete(mas_dict)

# Create Ansyas instance
ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=20,
    refinement_percent=5,
    maximum_passes=100,
    scale=1
)

# Create project - use non_graphical=False so they can see it in GUI
project = ansyas.create_project(
    outputs_folder='output/',
    project_name='cmc_material_check',
    non_graphical=False,  # This will open Ansys GUI
    solution_type="EddyCurrent",
    new_desktop_session=True
)

# Set units and create simulation (but don't analyze)
ansyas.set_units("meter")
ansyas.create_magnetic_simulation(mas=mas, simulate=False)

print("Project created successfully!")
print("Project location: output/cmc_material_check.aedt")
print("\nYou can now open this project in Ansys GUI to check the WE_A material properties.")
print("Look for: Materials -> WE_A -> View/Edit -> Relative Permeability")
print("\nPress Enter to close the script and keep the project open...")
input()
