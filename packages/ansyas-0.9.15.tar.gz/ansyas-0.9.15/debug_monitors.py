#!/usr/bin/env python3
"""
Debug monitor extraction
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

from pathlib import Path

print("Connecting to last project...")

from ansyas import Ansyas

output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/auto_extraction")

# Find most recent project
aedt_files = list(output_path.glob("auto_*.aedt"))
if not aedt_files:
    print("No projects found")
    sys.exit(1)

latest = max(aedt_files, key=lambda p: p.stat().st_mtime)
print(f"Opening: {latest.name}")

ansyas = Ansyas()
project = ansyas.create_project(
    outputs_folder=str(output_path),
    project_name=latest.stem,
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=False
)

print("\nGetting monitor data...")

try:
    monitor_data = project.get_monitor_data()
    print(f"Got {len(monitor_data)} entries:")
    for name, value in monitor_data.items():
        print(f"  {name}: {value}")
except Exception as e:
    print(f"Error: {e}")

print("\nClosing...")
project.release_desktop(close_projects=False, close_desktop=False)
