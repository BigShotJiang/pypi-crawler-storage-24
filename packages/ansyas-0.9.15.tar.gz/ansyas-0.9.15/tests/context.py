import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src/')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src/Ansyas/')))
