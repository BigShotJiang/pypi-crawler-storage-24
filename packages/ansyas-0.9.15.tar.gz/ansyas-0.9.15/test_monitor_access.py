#!/usr/bin/env python3
"""
Test how to access point monitors after creation
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import ansys.aedt.core as pyaedt
from ansys.aedt.core import Icepak

print("Testing monitor access methods...")

# Check monitor object methods
print("\nIcepak.monitor property:")
if hasattr(Icepak, 'monitor'):
    print(f"  monitor is a property")
    # Check what methods are available on monitor
    # (We need an instance to see this, let's check class)

print("\nChecking for omonitor attribute:")
if hasattr(Icepak, 'omonitor'):
    print(f"  omonitor exists")

print("\nChecking monitors property:")
if hasattr(Icepak, 'monitors'):
    print(f"  monitors property exists")

print("\nChecking for assign_point_monitor_in_object:")
if hasattr(Icepak, 'assign_point_monitor_in_object'):
    print(f"  assign_point_monitor_in_object exists")
    import inspect
    print(f"  Signature: {inspect.signature(Icepak.assign_point_monitor_in_object)}")

print("\nDone!")
