#!/usr/bin/env python3
"""
FINAL WORKING SOLUTION - PyAEDT 1.0.0rc1
1. Creates Icepak project with gravity (automated)
2. Solves simulation (automated)
3. Generates IronPython script for you to run in GUI
4. Reads exported CSV and generates C++ test (automated)
"""

import os
import sys
import json
import time
import subprocess
from datetime import datetime

sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import ansys.aedt.core as pyaedt
from Ansyas import Ansyas
import mas_autocomplete

# Configuration
OUTPUT_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\final_solution'
MKF_TEST_FILE = r'\wsl.localhost\Ubuntu-22.04\home\alf\OpenMagnetics\MKF\tests\TestTemperature.cpp'
MAS_FILE = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'

os.makedirs(OUTPUT_DIR, exist_ok=True)

print("="*80)
print(f"FINAL SOLUTION - PyAEDT {pyaedt.__version__}")
print("="*80)

# Kill existing processes
print("\n1. Cleaning up...")
subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], capture_output=True)
time.sleep(3)

# Create and solve
print("\n2. Creating and solving Icepak simulation...")
with open(MAS_FILE, 'r') as f:
    mas_dict = json.load(f)
mas = mas_autocomplete.autocomplete(mas_dict)

ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project = ansyas.create_project(
    outputs_folder=OUTPUT_DIR,
    project_name="final_solution",
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=True
)

ansyas.set_units("meter")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)

# Enable gravity
setup = project.setups[0]
setup.props['Include Gravity'] = True
setup.update()

# Run simulation
project.analyze_setup(setup.name)
project.save_project()

print("   [OK] Simulation completed and saved")

# Generate IronPython script for GUI export
print("\n3. Generating IronPython export script...")

project_file = os.path.join(OUTPUT_DIR, "final_solution.aedt")
export_script_file = os.path.join(OUTPUT_DIR, "export_temperatures.py")

# Get object names
object_names = [obj for obj in project.modeler.object_names 
                if any(kw in obj.lower() for kw in ['core', 'bobbin', 'copper', 'turn'])]

ironpython_script = '''# IronPython script to export temperatures from Icepak
# Run this script in Ansys Electronics Desktop: Tools -> Run Script

import os

oDesktop.RestoreWindow()
oProject = oDesktop.SetActiveProject("final_solution")
oDesign = oProject.SetActiveDesign("Icepak_FINAL")
oModule = oDesign.GetModule("FieldsReporter")

# Objects to extract temperatures from
objects = [
    "core_0",
    "core_1", 
    "bobbin",
    "Primary_Parallel_0_Turn_0_copper",
    "Primary_Parallel_0_Turn_5_copper",
    "Primary_Parallel_0_Turn_10_copper",
    "Secondary_Parallel_0_Turn_0_copper",
    "Secondary_Parallel_0_Turn_5_copper",
    "Secondary_Parallel_0_Turn_10_copper",
    "Primary_Parallel_1_Turn_0_copper",
    "Primary_Parallel_1_Turn_5_copper",
    "Primary_Parallel_1_Turn_10_copper"
]

# Setup field summary
for obj in objects:
    try:
        oModule.EditFieldsSummarySetting(
            ["Calculation:=", ["Object", "Volume", obj, "Temperature", "", "Default"]]
        )
    except:
        pass

# Export
csv_path = r"''' + os.path.join(OUTPUT_DIR, "temperatures.csv").replace('\\', '\\\\') + '''"

oModule.ExportFieldsSummary([
    "SolutionName:=", "Setup : LastAdaptive",
    "DesignVariationKey:=", "",
    "ExportFileName:=", csv_path
])

# Also export solution overview  
txt_path = r"''' + os.path.join(OUTPUT_DIR, "solution_overview.txt").replace('\\', '\\\\') + '''"

oDesign.ExportSolutionOverview([
    "SetupName:=", "Setup",
    "ExportFilePath:=", txt_path,
    "Overwrite:=", True
])

print("Temperatures exported to: " + csv_path)
'''

with open(export_script_file, 'w') as f:
    f.write(ironpython_script)

print(f"   [OK] Export script created: {export_script_file}")

# Cleanup
ansyas.solver_backend.close()

print("\n" + "="*80)
print("NEXT STEPS (MANUAL - ONE TIME ONLY):")
print("="*80)
print(f"\n1. Open the project in Ansys Icepak:")
print(f"   {project_file}")
print(f"\n2. In Icepak GUI, run the IronPython script:")
print(f"   Tools -> Run Script -> Select: {export_script_file}")
print(f"\n3. This will export temperatures to:")
print(f"   {os.path.join(OUTPUT_DIR, 'temperatures.csv')}")

# Wait for user to confirm export
input("\n   Press Enter AFTER running the IronPython script in GUI...")

# Read exported temperatures
print("\n4. Reading exported temperatures...")
temperatures = {}

csv_file = os.path.join(OUTPUT_DIR, "temperatures.csv")
if os.path.exists(csv_file):
    with open(csv_file, 'r') as f:
        lines = f.readlines()
    
    for line in lines[1:]:  # Skip header
        parts = line.strip().split(',')
        if len(parts) >= 4:
            obj_name = parts[0].strip()
            try:
                avg_temp = float(parts[3])
                temperatures[obj_name] = avg_temp
            except:
                pass
    
    print(f"   [OK] Read {len(temperatures)} temperatures")
    for name, temp in sorted(temperatures.items())[:10]:
        print(f"     {name}: {temp:.2f}°C")
else:
    print(f"   [ERROR] CSV file not found: {csv_file}")
    sys.exit(1)

# Generate C++ test
print("\n5. Generating C++ test case...")

mas_basename = os.path.splitext(os.path.basename(MAS_FILE))[0]
test_name = f"AutoTemp_{mas_basename}_{int(time.time())}"

core_temps = [t for name, t in temperatures.items() if 'core' in name.lower()]
bobbin_temps = [t for name, t in temperatures.items() if 'bobbin' in name.lower()]
turn_temps = [(name, t) for name, t in temperatures.items() 
              if any(kw in name.lower() for kw in ['turn', 'copper'])]

avg_core = sum(core_temps) / len(core_temps) if core_temps else 0
max_core = max(core_temps) if core_temps else 0
min_core = min(core_temps) if core_temps else 0
avg_bobbin = sum(bobbin_temps) / len(bobbin_temps) if bobbin_temps else 0

cpp_code = f"""
// =============================================================================
// Auto-generated Icepak Temperature Test - PyAEDT {pyaedt.__version__}
// Source MAS: {mas_basename}
// Generated: {datetime.now().isoformat()}
// Method: Icepak thermal simulation with natural convection + gravity
// =============================================================================

TEST_F(TemperatureTests, {test_name}) {{
    std::string masFile = "{MAS_FILE}";
    auto masData = OpenMagnetics::loadMas(masFile);
    
    OpenMagnetics::ThermalSimulation thermalSim;
    thermalSim.setMeshDensity(OpenMagnetics::MeshDensity::Medium);
    thermalSim.setConvergenceCriteria(5.0);
    thermalSim.setGravity(true);
    
    auto result = thermalSim.run(masData);
    
    EXPECT_NEAR(result.getCoreAverageTemperature(), {avg_core:.2f}, 10.0);
    EXPECT_NEAR(result.getCoreMaxTemperature(), {max_core:.2f}, 10.0);
    EXPECT_NEAR(result.getCoreMinTemperature(), {min_core:.2f}, 10.0);
    EXPECT_NEAR(result.getBobbinTemperature(), {avg_bobbin:.2f}, 10.0);
    EXPECT_EQ(result.getWindingCount(), {len(turn_temps)});
"""

for name, temp in turn_temps[:5]:
    short_name = name.replace('Primary_Parallel_', 'P').replace('Secondary_Parallel_', 'S').replace('_copper', '')
    cpp_code += f"    EXPECT_NEAR(result.getWindingTemperature(\"{short_name}\"), {temp:.2f}, 15.0); // {name}\n"

if len(turn_temps) > 5:
    cpp_code += f"    // ... and {len(turn_temps) - 5} more winding temperature checks\n"

cpp_code += "}\n"

# Save and append
test_file = os.path.join(OUTPUT_DIR, f"test_{mas_basename}.cpp")
with open(test_file, 'w') as f:
    f.write(cpp_code)

print(f"   [OK] Test saved: {test_file}")

# Append to MKF
try:
    if os.path.exists(MKF_TEST_FILE):
        with open(MKF_TEST_FILE, 'r') as f:
            existing = f.read()
        
        if test_name not in existing:
            import shutil
            shutil.copy2(MKF_TEST_FILE, f"{MKF_TEST_FILE}.backup_{int(time.time())}")
            
            with open(MKF_TEST_FILE, 'a') as f:
                if not existing.endswith('\n'):
                    f.write('\n')
                f.write(cpp_code)
            
            print(f"   [OK] Test appended to: {MKF_TEST_FILE}")
        else:
            print(f"   [INFO] Test already exists")
    else:
        print(f"   [INFO] MKF file not found")
except Exception as e:
    print(f"   [WARN] Could not append: {e}")

print("\n" + "="*80)
print("COMPLETE!")
print("="*80)
print(f"Temperatures: {len(temperatures)}")
print(f"Test: {test_name}")
print(f"Output: {OUTPUT_DIR}")
