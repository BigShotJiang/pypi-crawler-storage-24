#!/usr/bin/env python3
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

from pathlib import Path
from ansyas import Ansyas

print("Connecting to existing Icepak project...")

# Find latest project
output_dir = Path("C:/Users/Alfonso/wuerth/Ansyas/output/temp_generator")
aedt_files = list(output_dir.glob("temp_test_*.aedt"))
if not aedt_files:
    print("No projects found!")
    sys.exit(1)

latest = max(aedt_files, key=lambda p: p.stat().st_mtime)
print(f"Opening: {latest.name}")

# Use Ansyas to open project
ansyas = Ansyas()
project = ansyas.create_project(
    outputs_folder=str(output_dir),
    project_name=latest.stem,
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=False
)

print("\nObjects in project:")
for name in sorted(project.modeler.objects.keys()):
    print(f"  {name}")

print("\nBoundaries/Sources:")
for boundary in project.boundaries:
    print(f"  {boundary.name}: {boundary.type}")
