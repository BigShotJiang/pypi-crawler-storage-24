#!/usr/bin/env python3
"""
Quick test of PyAEDT 1.0.0rc1 Icepak field summary extraction
"""

import os
import sys
import json
import time
import subprocess

# Add Ansyas to path
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import ansys.aedt.core as pyaedt
import PyOpenMagnetics
print(f"PyOpenMagnetics: Loaded from {PyOpenMagnetics.__file__}")

from Ansyas import Ansyas

# Use Ansyas mas_autocomplete
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')
import mas_autocomplete

print("="*80)
print("QUICK TEST: PyAEDT 1.0.0rc1 Field Summary API")
print("="*80)
print(f"PyAEDT Version: {pyaedt.__version__}")
print()

# Kill processes
print("Killing Ansys processes...")
subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], capture_output=True)
time.sleep(3)

# Test with concentric transformer
mas_file = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'
output_dir = r'C:\Users\Alfonso\wuerth\Ansyas\output\test_field_summary'
os.makedirs(output_dir, exist_ok=True)

try:
    print(f"\nLoading MAS file: {os.path.basename(mas_file)}")
    with open(mas_file, 'r') as f:
        mas_dict = json.load(f)
    
    # Auto-complete MAS data using Ansyas mas_autocomplete
    mas = mas_autocomplete.autocomplete(mas_dict)
    print("  [OK] MAS file loaded and auto-completed")
    
    # Initialize Ansyas
    print("\nInitializing Ansyas...")
    ansyas = Ansyas(
        number_segments_arcs=12,
        initial_mesh_configuration=2,
        maximum_error_percent=5,
        refinement_percent=30,
        maximum_passes=15,
        scale=1
    )
    
    # Create project
    print("Creating Icepak project...")
    project_name = f"test_field_summary_{int(time.time())}"
    project = ansyas.create_project(
        outputs_folder=output_dir,
        project_name=project_name,
        non_graphical=True,
        solution_type="Icepak",
        new_desktop_session=True
    )
    
    if project is None:
        raise RuntimeError("Failed to create project")
    
    print(f"  [OK] Project created: {project_name}")
    
    # Set units
    ansyas.set_units("meter")
    print("  [OK] Units set to meters")
    
    # Create geometry
    print("\nCreating magnetic simulation geometry...")
    ansyas.create_magnetic_simulation(
        mas=mas,
        simulate=False,
        operating_point_index=0
    )
    print("  [OK] Geometry created")
    
    # Test field summary API
    print("\n" + "="*80)
    print("TESTING: create_field_summary() API")
    print("="*80)
    
    # Get objects
    object_names = project.modeler.object_names
    print(f"\nFound {len(object_names)} objects")
    
    # Filter thermal objects
    temp_objects = [n for n in object_names if any(kw in n.lower() 
                    for kw in ['core', 'bobbin', 'copper', 'turn'])]
    print(f"Found {len(temp_objects)} thermal objects")
    
    if temp_objects:
        print("\nCreating field summary...")
        fs = project.post.create_field_summary()
        print("  [OK] Field summary created")
        
        print("\nAdding temperature calculations...")
        for obj_name in temp_objects[:5]:  # Test with first 5
            print(f"  Adding: {obj_name}")
            fs.add_calculation(
                entity="Object",
                geometry="Volume", 
                geometry_name=obj_name,
                quantity="Temperature"
            )
        print("  [OK] Calculations added")
        
        print("\nGetting field summary data...")
        data = fs.get_field_summary_data(pandas_output=True)
        
        if data is not None and hasattr(data, 'empty') and not data.empty:
            print(f"  [OK] Data retrieved: {len(data)} rows")
            print("\nTemperature Results:")
            print("-" * 80)
            for _, row in data.iterrows():
                print(f"  {row.get('Geometry Name', 'N/A')}: {row.get('Value', 'N/A')}°C")
            print("-" * 80)
            print("\n[SUCCESS] Field summary API is working correctly!")
        else:
            print("  [WARNING] No data returned (simulation may not be solved yet)")
            print("  This is expected if the simulation hasn't been run.")
    
    # Cleanup
    print("\nCleaning up...")
    ansyas.solver_backend.close()
    subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
    print("  [OK] Cleanup complete")
    
    print("\n" + "="*80)
    print("TEST COMPLETE - API is available and working!")
    print("="*80)
    
except Exception as e:
    print(f"\n[ERROR] {e}")
    import traceback
    traceback.print_exc()
    
    # Cleanup on error
    try:
        subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
    except:
        pass
    
    sys.exit(1)
