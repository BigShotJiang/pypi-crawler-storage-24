#!/usr/bin/env python3
"""
Test PyAEDT setup properties for gravity
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import ansys.aedt.core as pyaedt
from ansys.aedt.core import Icepak

print("Testing PyAEDT setup properties...")

# Check if Icepak has gravity property
print(f"\nIcepak has 'gravity' attribute: {hasattr(Icepak, 'gravity')}")

# Check setup object
print("\nSetup object attributes with 'grav' or 'flow':")
# We need to check actual setup class
from ansys.aedt.core.modules.solve_setup import Setup
setup_attrs = [a for a in dir(Setup) if 'grav' in a.lower() or 'flow' in a.lower() or 'natural' in a.lower()]
for a in setup_attrs:
    print(f"  - {a}")

print("\nChecking Icepak-specific setup...")
try:
    from ansys.aedt.core.application.analysis_icepak import FieldAnalysisIcepak
    icepak_attrs = [a for a in dir(FieldAnalysisIcepak) if not a.startswith('_') and ('grav' in a.lower() or 'flow' in a.lower() or 'export' in a.lower())]
    for a in icepak_attrs[:20]:
        print(f"  - {a}")
except Exception as e:
    print(f"Error: {e}")

print("\nDone!")
