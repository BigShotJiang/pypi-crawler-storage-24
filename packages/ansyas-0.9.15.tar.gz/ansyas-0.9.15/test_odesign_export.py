#!/usr/bin/env python3
"""
Try to access oDesign directly and call ExportSolutionOverview
This bypasses gRPC by using the COM/object model directly
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import os
import json

import ansys.aedt.core as pyaedt
from Ansyas import Ansyas
import mas_autocomplete

OUTPUT_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\odesign_test'
os.makedirs(OUTPUT_DIR, exist_ok=True)

MAS_FILE = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'

print("="*80)
print("TESTING: oDesign ExportSolutionOverview via PyAEDT")
print("="*80)

# Load and create
print("\n1. Creating simulation...")
with open(MAS_FILE, 'r') as f:
    mas_dict = json.load(f)
mas = mas_autocomplete.autocomplete(mas_dict)

ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project = ansyas.create_project(
    outputs_folder=OUTPUT_DIR,
    project_name="odesign_test",
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=True
)

ansyas.set_units("meter")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)

# Enable gravity and run
setup = project.setups[0]
setup.props['Include Gravity'] = True
setup.update()

print("\n2. Running simulation...")
project.analyze_setup(setup.name)
print("   [OK] Simulation completed")

# Try to access oDesign directly
print("\n3. Trying to access oDesign...")

try:
    # Check available attributes
    print("   Checking project attributes...")
    attrs = [a for a in dir(project) if not a.startswith('_') and 'design' in a.lower()]
    print(f"   Design-related attributes: {attrs}")
    
    # Try different ways to access oDesign
    print("\n   Trying project._odesign...")
    if hasattr(project, '_odesign'):
        odesign = project._odesign
        print(f"   Got odesign: {type(odesign)}")
        
        # Try ExportSolutionOverview
        export_file = os.path.join(OUTPUT_DIR, "solution_overview.txt").replace('\\', '/')
        print(f"\n   Exporting to: {export_file}")
        
        try:
            odesign.ExportSolutionOverview(
                [
                    "SetupName:=", "Setup",
                    "DesignVariationKey:=", "",
                    "ExportFilePath:=", export_file,
                    "TimeStep:=", -1,
                    "Overwrite:=", True
                ]
            )
            print("   [SUCCESS] ExportSolutionOverview completed!")
            
            if os.path.exists(export_file):
                print(f"   [OK] File created: {export_file}")
                with open(export_file, 'r') as f:
                    content = f.read()
                    print(f"   File size: {len(content)} bytes")
                    print("   First 1000 chars:")
                    print(content[:1000])
            else:
                print(f"   [WARNING] File not found")
                
        except Exception as e:
            print(f"   [ERROR] ExportSolutionOverview failed: {e}")
    else:
        print("   _odesign not found")
        
    # Try odesign property
    print("\n   Trying project.odesign...")
    if hasattr(project, 'odesign'):
        odesign2 = project.odesign
        print(f"   Got odesign: {type(odesign2)}")
    else:
        print("   odesign property not found")
        
except Exception as e:
    print(f"   [ERROR] {e}")
    import traceback
    traceback.print_exc()

# Cleanup
project.save_project()
ansyas.solver_backend.close()

print("\n" + "="*80)
print("Done")
print("="*80)
