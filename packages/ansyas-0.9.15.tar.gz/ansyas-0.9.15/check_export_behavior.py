#!/usr/bin/env python3
"""
Check export_summary behavior in detail
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import os
import ansys.aedt.core as pyaedt

# Try to open the existing project
output_dir = r'C:\Users\Alfonso\wuerth\Ansyas\output\auto_extract_final'
project_file = os.path.join(output_dir, 'auto_extract_final.aedt')

print("Opening existing project...")
from ansys.aedt.core import Icepak

project = Icepak(
    projectname=project_file,
    non_graphical=True,
    new_desktop_session=True
)

print(f"Project opened: {project.project_name}")
print(f"Setups: {[s.name for s in project.setups]}")

setup = project.setups[0]
print(f"Using setup: {setup.name}")

# Try export_summary with full path
print("\nTrying export_summary...")
result = project.export_summary(
    output_dir=output_dir,
    solution_name=setup.name,
    type='Object',
    geometry_type='Volume', 
    quantity='Temperature',
    filename='test_export'
)

print(f"Result: {result}")

# Check all files created
print("\nFiles in output directory after export:")
for root, dirs, files in os.walk(output_dir):
    for file in files:
        filepath = os.path.join(root, file)
        print(f"  {filepath}")

# Check current working directory
print(f"\nCurrent working directory: {os.getcwd()}")
print("Files in CWD:")
for f in os.listdir('.'):
    if 'export' in f.lower() or 'summary' in f.lower() or 'temperature' in f.lower():
        print(f"  {f}")

project.release_desktop()
print("\nDone!")
