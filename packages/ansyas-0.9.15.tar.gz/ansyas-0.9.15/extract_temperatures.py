#!/usr/bin/env python3
"""
Extract temperatures from existing Icepak project using PyAEDT export_summary
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import os
import ansys.aedt.core as pyaedt
from ansys.aedt.core import Icepak

output_dir = r'C:\Users\Alfonso\wuerth\Ansyas\output\auto_extract_final'
project_file = os.path.join(output_dir, 'auto_extract_final.aedt')

print("="*80)
print("EXTRACTING TEMPERATURES FROM ICEPAK PROJECT")
print("="*80)
print(f"Project: {project_file}")

# Open existing project
print("\nOpening project...")
project = Icepak(
    project=project_file,
    non_graphical=True,
    new_desktop=True
)

print(f"  [OK] Project opened: {project.project_name}")
print(f"  Setups: {[s.name for s in project.setups]}")

setup = project.setups[0]
print(f"  Using setup: {setup.name}")

# Export temperature summary
print("\n" + "="*80)
print("EXPORTING TEMPERATURE DATA")
print("="*80)

try:
    result = project.export_summary(
        output_dir=output_dir,
        solution_name=setup.name,
        type='Object',
        geometry_type='Volume',
        quantity='Temperature',
        filename='temperature_data'
    )
    
    print(f"  Export result: {result}")
    
    # Check what files were created
    print("\n  Checking for exported files...")
    found_files = []
    for root, dirs, files in os.walk(output_dir):
        for file in files:
            if file.endswith('.csv') or 'summary' in file.lower() or 'temperature' in file.lower():
                filepath = os.path.join(root, file)
                found_files.append(filepath)
                print(f"    Found: {filepath}")
    
    if not found_files:
        print("    No CSV or temperature files found")
        print(f"    Files in output dir: {os.listdir(output_dir)}")
    
    # Also check if file was created in CWD
    cwd_files = [f for f in os.listdir('.') if f.endswith('.csv') or 'temperature' in f.lower()]
    if cwd_files:
        print(f"\n  Files in current directory:")
        for f in cwd_files:
            print(f"    {f}")
            
except Exception as e:
    print(f"  [ERROR] Export failed: {e}")
    import traceback
    traceback.print_exc()

project.release_desktop()

print("\n" + "="*80)
print("Done!")
print("="*80)
