#!/usr/bin/env python3
"""
Extract temperatures using PyAEDT methods equivalent to IronPython script
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import ansys.aedt.core as pyaedt

print("Testing PyAEDT methods for setup and export...")

# Check available Icepak methods
from ansys.aedt.core import Icepak

print("\nChecking Icepak methods:")
methods = [m for m in dir(Icepak) if 'export' in m.lower() or 'solution' in m.lower() or 'overview' in m.lower()]
for m in methods:
    print(f"  - {m}")

print("\nChecking setup methods:")
setup_methods = [m for m in dir(Icepak) if 'setup' in m.lower() or 'gravity' in m.lower()]
for m in setup_methods:
    print(f"  - {m}")

print("\nDone!")
