#!/usr/bin/env python3
"""
ULTIMATE Ansys Process Killer - kills everything
"""

import subprocess
import time
import os

def kill_all_ansys():
    """Kill all Ansys-related processes thoroughly"""
    print("Killing ALL Ansys processes...")
    
    processes = [
        "ansysedt", "ansysedt.exe", "ANSYSEDT", 
        "Icepak", "Icepak.exe", "ICEPAK",
        "ansys", "ansys.exe", "ANSYS",
        "Aedt", "Aedt.exe", "AEDT",
        "grpc_aedt_server", "grpc_aedt_server.exe",
        "ansyswbu", "ansyswbu.exe",
        "ANSYSli", "ANSYSli.exe",
        "lmgrd", "lmgrd.exe"
    ]
    
    for proc in processes:
        try:
            # Try multiple methods
            subprocess.run(["taskkill", "/F", "/IM", proc], capture_output=True, timeout=5)
            subprocess.run(["taskkill", "/F", "/FI", f"IMAGENAME eq {proc}"], capture_output=True, timeout=5)
        except:
            pass
    
    # Also use PowerShell for stubborn processes
    try:
        ps_cmd = "Get-Process | Where-Object {$_.Name -like '*ansys*' -or $_.Name -like '*aedt*' -or $_.Name -like '*icepak*'} | Stop-Process -Force"
        subprocess.run(["powershell", "-Command", ps_cmd], capture_output=True, timeout=10)
    except:
        pass
    
    # Clean up temp files
    import tempfile
    from pathlib import Path
    temp_dir = Path(tempfile.gettempdir())
    
    patterns = ['aedt_pipe*', 'pyaedt*', 'aedt_port*', 'ansys*']
    for pattern in patterns:
        for file in temp_dir.glob(pattern):
            try:
                file.unlink()
            except:
                pass
    
    print("  Waiting for processes to die...")
    time.sleep(5)
    
    # Verify
    result = subprocess.run(["tasklist"], capture_output=True, text=True)
    ansys_running = any("ansys" in line.lower() or "aedt" in line.lower() or "icepak" in line.lower() 
                       for line in result.stdout.split('\n'))
    
    if ansys_running:
        print("  WARNING: Some Ansys processes still running")
        # Force kill again
        subprocess.run(["taskkill", "/F", "/IM", "ansysedt.exe"], capture_output=True)
        time.sleep(3)
    else:
        print("  [OK] All Ansys processes killed")

if __name__ == "__main__":
    kill_all_ansys()
    print("\nDone. You can now run your Icepak simulation.")
