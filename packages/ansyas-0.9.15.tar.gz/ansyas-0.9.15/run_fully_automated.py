#!/usr/bin/env python3
"""
FULLY AUTOMATED - Using oDesign.ExportSolutionOverview (bypasses gRPC!)
This works with Ansys Student version!
"""

import os
import sys
import json
import time
import subprocess
import re
from datetime import datetime

sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import ansys.aedt.core as pyaedt
from Ansyas import Ansyas
import mas_autocomplete

OUTPUT_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\fully_automated'
MKF_TEST_FILE = r'\wsl.localhost\Ubuntu-22.04\home\alf\OpenMagnetics\MKF\tests\TestTemperature.cpp'
MAS_FILE = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'

os.makedirs(OUTPUT_DIR, exist_ok=True)

print("="*80)
print(f"FULLY AUTOMATED TEMPERATURE EXTRACTION - PyAEDT {pyaedt.__version__}")
print("Using oDesign.ExportSolutionOverview (bypasses gRPC limitations)")
print("="*80)

# Kill existing processes
print("\n1. Cleaning up...")
subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], capture_output=True)
subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], capture_output=True)
time.sleep(3)

# Create and solve
print("\n2. Creating and solving Icepak simulation...")
with open(MAS_FILE, 'r') as f:
    mas_dict = json.load(f)
mas = mas_autocomplete.autocomplete(mas_dict)

ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project = ansyas.create_project(
    outputs_folder=OUTPUT_DIR,
    project_name="fully_automated",
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=True
)

ansyas.set_units("meter")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)

# Enable gravity
setup = project.setups[0]
setup.props['Include Gravity'] = True
setup.update()

# Run simulation
print("\n3. Running thermal simulation...")
project.analyze_setup(setup.name)
project.save_project()
print("   [OK] Simulation completed")

# Export using oDesign (bypasses gRPC!)
print("\n4. Exporting temperature data using oDesign...")

export_file = os.path.join(OUTPUT_DIR, "temperatures.csv").replace('\\', '/')

try:
    odesign = project._odesign
    
    # Get the solution module through _odesign to bypass gRPC
    # In IronPython: oModule = oDesign.GetModule("FieldsReporter")
    osolution = odesign.GetModule("FieldsReporter")
    
    # Setup field summary for each object
    object_names = [obj for obj in project.modeler.object_names 
                    if any(kw in obj.lower() for kw in ['core', 'bobbin', 'copper', 'turn'])]
    
    print(f"   Setting up field summary for {len(object_names)} objects...")
    
    # Setup calculations for each object
    for obj_name in object_names[:10]:  # Limit to first 10 for testing
        try:
            osolution.EditFieldsSummarySetting(
                ["Calculation:=", ["Object", "Volume", obj_name, "Temperature", "", "Default"]]
            )
        except Exception as e:
            print(f"   [WARN] Could not add {obj_name}: {e}")
    
    print("   Field summary configured")
    
    # Export to CSV
    export_result = osolution.ExportFieldsSummary(
        [
            "SolutionName:=", f"{setup.name} : LastAdaptive",
            "DesignVariationKey:=", "",
            "ExportFileName:=", export_file
        ]
    )
    
    print(f"   Export result: {export_result}")
    print(f"   [OK] Exported to: {export_file}")
except Exception as e:
    print(f"   [ERROR] Export failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Parse the exported CSV
print("\n5. Parsing exported temperature data...")

temperatures = {}

if os.path.exists(export_file):
    with open(export_file, 'r') as f:
        lines = f.readlines()
    
    print(f"   Reading {len(lines)} lines from CSV")
    
    # Skip header line
    for line in lines[1:]:
        parts = line.strip().split(',')
        if len(parts) >= 4:
            obj_name = parts[0].strip()
            try:
                # Column 3 is typically the average value
                avg_temp = float(parts[3])
                temperatures[obj_name] = avg_temp
                print(f"     {obj_name}: {avg_temp:.2f}C")
            except (ValueError, IndexError):
                pass

print(f"   [OK] Extracted {len(temperatures)} temperatures")

if not temperatures:
    print("   [WARNING] No temperatures found in export file")
    print("   Files in output directory:")
    for f in os.listdir(OUTPUT_DIR):
        print(f"     {f}")

# Generate C++ test
print("\n6. Generating C++ test case...")

mas_basename = os.path.splitext(os.path.basename(MAS_FILE))[0]
test_name = f"AutoTemp_{mas_basename}_{int(time.time())}"

core_temps = [t for name, t in temperatures.items() if 'core' in name.lower()]
bobbin_temps = [t for name, t in temperatures.items() if 'bobbin' in name.lower()]
turn_temps = [(name, t) for name, t in temperatures.items() 
              if any(kw in name.lower() for kw in ['turn', 'copper'])]

avg_core = sum(core_temps) / len(core_temps) if core_temps else 0
max_core = max(core_temps) if core_temps else 0
min_core = min(core_temps) if core_temps else 0
avg_bobbin = sum(bobbin_temps) / len(bobbin_temps) if bobbin_temps else 0

cpp_code = f"""
// =============================================================================
// Auto-generated Icepak Temperature Test - PyAEDT {pyaedt.__version__}
// Source MAS: {mas_basename}
// Generated: {datetime.now().isoformat()}
// Method: Icepak thermal simulation with natural convection + gravity
// =============================================================================

TEST_F(TemperatureTests, {test_name}) {{
    std::string masFile = "{MAS_FILE}";
    auto masData = OpenMagnetics::loadMas(masFile);
    
    OpenMagnetics::ThermalSimulation thermalSim;
    thermalSim.setMeshDensity(OpenMagnetics::MeshDensity::Medium);
    thermalSim.setConvergenceCriteria(5.0);
    thermalSim.setGravity(true);
    
    auto result = thermalSim.run(masData);
    
    EXPECT_NEAR(result.getCoreAverageTemperature(), {avg_core:.2f}, 10.0);
    EXPECT_NEAR(result.getCoreMaxTemperature(), {max_core:.2f}, 10.0);
    EXPECT_NEAR(result.getCoreMinTemperature(), {min_core:.2f}, 10.0);
    EXPECT_NEAR(result.getBobbinTemperature(), {avg_bobbin:.2f}, 10.0);
    EXPECT_EQ(result.getWindingCount(), {len(turn_temps)});
"""

for name, temp in turn_temps[:5]:
    short_name = name.replace('Primary_Parallel_', 'P').replace('Secondary_Parallel_', 'S').replace('_copper', '')
    cpp_code += f"    EXPECT_NEAR(result.getWindingTemperature(\"{short_name}\"), {temp:.2f}, 15.0); // {name}\n"

if len(turn_temps) > 5:
    cpp_code += f"    // ... and {len(turn_temps) - 5} more winding temperature checks\n"

cpp_code += "}\n"

# Save
test_file = os.path.join(OUTPUT_DIR, f"test_{mas_basename}.cpp")
with open(test_file, 'w') as f:
    f.write(cpp_code)

print(f"   [OK] Test saved: {test_file}")

# Append to MKF
try:
    if os.path.exists(MKF_TEST_FILE):
        with open(MKF_TEST_FILE, 'r') as f:
            existing = f.read()
        
        if test_name not in existing:
            import shutil
            shutil.copy2(MKF_TEST_FILE, f"{MKF_TEST_FILE}.backup_{int(time.time())}")
            
            with open(MKF_TEST_FILE, 'a') as f:
                if not existing.endswith('\n'):
                    f.write('\n')
                f.write(cpp_code)
            
            print(f"   [OK] Test appended to: {MKF_TEST_FILE}")
        else:
            print(f"   [INFO] Test already exists")
except Exception as e:
    print(f"   [WARN] Could not append: {e}")

# Cleanup
ansyas.solver_backend.close()

print("\n" + "="*80)
print("COMPLETE!")
print("="*80)
print(f"Temperatures: {len(temperatures)}")
print(f"Test: {test_name}")
print(f"Output: {OUTPUT_DIR}")
print("\n✅ FULLY AUTOMATED - No manual GUI interaction needed!")
