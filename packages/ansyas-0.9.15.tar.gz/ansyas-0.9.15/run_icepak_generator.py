#!/usr/bin/env python3
"""
Test generator that runs ACTUAL Icepak simulations and AUTO-EXTRACTS temperatures.
NO FALLBACKS - crashes on error. FULL AUTOMATION.
"""

import csv
import json
import re
import sys
import os
import time
import subprocess
from pathlib import Path
from datetime import datetime

# Add paths like the test suite does
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

print("=" * 80)
print("Temperature Test Generator - FULL AUTOMATION MODE")
print("NO FALLBACKS - Pure Ansys Simulation with Auto-Extraction")
print("=" * 80)
print()

# Paths
examples_dir = Path("C:/Users/Alfonso/wuerth/Ansyas/examples")
test_file = Path("//wsl.localhost/Ubuntu-22.04/home/alf/OpenMagnetics/MKF/tests/TestTemperature.cpp")
output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/temp_generator")
temp_csv_path = output_path / "temperature_export.csv"

# Timeout for Icepak simulation (30 minutes)
SIMULATION_TIMEOUT = 1800


def kill_ansys_processes():
    """Kill stuck Ansys processes to free license."""
    print("  Cleaning up Ansys processes...")
    processes_to_kill = [
        "ansysedtsv", "ansysedt", "ansysedt.exe", 
        "ANS.AEDT.*", "grpc_aedt_server", "Icepak*.exe"
    ]
    for proc in processes_to_kill:
        subprocess.run(
            ["powershell", "-Command", 
             f"Get-Process -Name '{proc}' -ErrorAction SilentlyContinue | Stop-Process -Force"],
            capture_output=True
        )
    time.sleep(3)


def clean_pyaedt_temp_files():
    """Clean up PyAEDT temporary files."""
    import tempfile
    temp_dir = tempfile.gettempdir()
    patterns = ['aedt_pipe*', 'pyaedt*', 'aedt_port*']
    for pattern in patterns:
        for file in Path(temp_dir).glob(pattern):
            try:
                file.unlink()
            except:
                pass


def extract_temperatures_via_csv(project, object_names):
    """
    Extract temperatures using Icepak's eval_volume_quantity_from_field_summary().
    This exports all temperatures to a CSV file and parses it.
    """
    temperatures = {}
    
    print("\n  Extracting temperatures via CSV export...")
    
    try:
        # Filter to only objects that exist in the model
        available_objects = list(project.modeler.objects.keys())
        objects_to_export = [obj for obj in object_names if obj in available_objects]
        
        if not objects_to_export:
            print("  Warning: None of the requested objects found in model")
            print(f"  Available objects: {available_objects[:10]}...")
            return temperatures
        
        print(f"  Exporting {len(objects_to_export)} objects to CSV...")
        
        # Use Icepak's native CSV export function
        csv_file = project.eval_volume_quantity_from_field_summary(
            object_list=objects_to_export,
            quantity_name="Temp",  # Temperature field in Icepak
            savedir=str(output_path),
            filename="temperature_export.csv",
            sweep_name="Setup : SteadyState"
        )
        
        if not csv_file or not Path(csv_file).exists():
            raise RuntimeError(f"CSV export failed or file not found: {csv_file}")
        
        print(f"  [OK] CSV exported to: {csv_file}")
        
        # Parse the CSV file
        with open(csv_file, 'r', newline='') as f:
            reader = csv.reader(f)
            
            # Skip header rows (usually 2-3 rows of headers in Icepak CSV)
            # Find the data section
            data_started = False
            headers = []
            
            for row in reader:
                if not row:
                    continue
                
                # Look for the header row with 'Object' or similar
                if not data_started:
                    if any('Object' in str(cell) or 'Object Name' in str(cell) for cell in row):
                        headers = row
                        data_started = True
                        continue
                else:
                    # This is data row
                    if len(row) >= 2:
                        # Parse based on typical Icepak CSV format
                        # Usually: Object Name, Temp [C], ...
                        obj_name = row[0].strip() if row[0] else None
                        
                        # Find temperature column (usually index 1 or contains 'Temp')
                        temp_val = None
                        for i, cell in enumerate(row[1:], 1):
                            try:
                                # Try to parse as float
                                temp_val = float(cell.strip())
                                break  # Take first valid number
                            except:
                                continue
                        
                        if obj_name and temp_val is not None:
                            temperatures[obj_name] = temp_val
                            print(f"    {obj_name}: {temp_val:.2f}C")
        
        print(f"  [OK] Extracted {len(temperatures)} temperatures from CSV")
        return temperatures
        
    except Exception as e:
        raise RuntimeError(f"Temperature extraction failed: {e}")


def run_icepak_simulation(mas_file: Path) -> dict:
    """
    Run Icepak simulation and auto-extract temperatures.
    NO FALLBACKS - raises exception on any error.
    """
    print(f"\n  Starting Icepak simulation for: {mas_file.name}")
    print(f"  Timeout: {SIMULATION_TIMEOUT}s")
    
    # Create output directory
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Clean up previous CSV if exists
    if temp_csv_path.exists():
        temp_csv_path.unlink()
    
    # Kill any existing processes
    kill_ansys_processes()
    clean_pyaedt_temp_files()
    time.sleep(5)
    
    try:
        # Import Ansyas modules
        import mas_autocomplete
        from ansyas import Ansyas
        
        print("  [OK] Ansyas modules imported")
        
        # Load MAS file
        with open(mas_file, 'r', encoding='utf-8') as f:
            mas_dict = json.load(f)
        
        mas = mas_autocomplete.autocomplete(mas_dict)
        print("  [OK] MAS file processed")
        
        # Get cooling info
        inputs = mas_dict.get('inputs', {})
        operating_points = inputs.get('operatingPoints', [{}])
        cooling = operating_points[0].get('cooling', {}) if operating_points else {}
        ambient_temp = cooling.get('temperature', 25.0)
        
        print(f"  Ambient: {ambient_temp}C")
        
        # Create Ansyas instance
        ansyas = Ansyas(
            number_segments_arcs=12,
            initial_mesh_configuration=2,
            maximum_error_percent=5,
            refinement_percent=30,
            maximum_passes=15,
            scale=1
        )
        
        project_name = f"temp_test_{mas_file.stem}_{int(time.time())}"
        print(f"  Creating Icepak project: {project_name}")
        
        project = ansyas.create_project(
            outputs_folder=str(output_path),
            project_name=project_name,
            non_graphical=False,  # GUI for visibility
            new_desktop_session=True,
            solution_type="SteadyState"
        )
        
        # CRITICAL: Set units to meters
        ansyas.set_units("meter")
        print("  [OK] Units set to meters")
        
        # Build geometry and setup
        ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)
        print("  [OK] Geometry built")
        
        # Run simulation
        print("\n  Running thermal simulation...")
        ansyas.analyze()
        print("  [OK] Simulation completed")
        
        project.save_project()
        
        # Prepare object names for extraction
        object_names = ['core_0', 'core_1', 'bobbin']
        
        # Add turn objects
        coil = mas_dict.get('magnetic', {}).get('coil', {})
        turns_desc = coil.get('turnsDescription', [])
        for i, turn in enumerate(turns_desc):
            base_name = turn.get('name', f"Turn_{i}")
            object_name = base_name + '_copper'
            object_names.append(object_name)
        
        print(f"\n  Will extract temperatures for {len(object_names)} objects")
        
        # EXTRACT TEMPERATURES
        temperatures = extract_temperatures_via_csv(project, object_names)
        
        if not temperatures:
            raise RuntimeError("No temperatures could be extracted")
        
        print(f"\n  [OK] Successfully extracted {len(temperatures)} temperatures")
        
        # Cleanup
        try:
            project.release_desktop(close_projects=True, close_desktop=True)
        except:
            pass
        
        kill_ansys_processes()
        
        return {
            'temperatures': temperatures,
            'ambient': ambient_temp,
            'core_shape': mas_dict.get('magnetic', {}).get('core', {}).get('functionalDescription', {}).get('shape', {}).get('name', 'Unknown'),
            'num_turns': len(turns_desc)
        }
        
    except Exception as e:
        print(f"\n  [ERROR] {e}")
        kill_ansys_processes()
        raise RuntimeError(f"Icepak simulation failed: {e}")


# Main execution
mas_files = list(examples_dir.glob("*.json"))
print(f"Found {len(mas_files)} JSON files")
print()

for mas_file in sorted(mas_files):
    print(f"Processing: {mas_file.name}")
    
    with open(mas_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    magnetic = data.get('magnetic', {})
    core = magnetic.get('core', {})
    coil = magnetic.get('coil', {})
    
    core_functional = core.get('functionalDescription', {})
    shape = core_functional.get('shape', {})
    core_shape = shape.get('name', 'Unknown')
    
    material_data = core_functional.get('material', 'N87')
    core_material = material_data.get('name', 'N87') if isinstance(material_data, dict) else material_data
    
    functional_desc = coil.get('functionalDescription', [])
    num_turns = [w.get('numberTurns', 0) for w in functional_desc]
    num_windings = len(num_turns)
    
    bobbin = coil.get('bobbin', {})
    has_bobbin = isinstance(bobbin, dict) and bobbin.get('processedDescription') is not None
    
    family = shape.get('family', '')
    is_toroidal = family.lower() == 't' if isinstance(family, str) else False
    
    print(f"  Core: {core_shape} ({core_material})")
    print(f"  Windings: {num_windings}, Turns: {num_turns}")
    
    # Generate test name
    shape_clean = core_shape.replace(' ', '_').replace('/', '_')
    parts = ["Temperature", "Toroidal" if is_toroidal else "Concentric", shape_clean]
    if num_windings > 1:
        parts.append(f"{num_windings}W")
    total_turns = sum(num_turns) if num_turns else 0
    parts.append(f"{total_turns}T")
    if has_bobbin:
        parts.append("Bobbin")
    parts.append("Icepak")
    test_name = "_".join(parts)
    
    print(f"  Test name: {test_name}")
    
    # Check if test exists
    if test_file.exists():
        with open(test_file, 'r', encoding='utf-8') as f:
            content = f.read()
        pattern = rf'TEST_CASE\s*\(\s*"{re.escape(test_name)}"'
        if re.search(pattern, content):
            print("  [SKIP] Test already exists")
            print()
            continue
    
    # Run simulation
    print("\n  [RUN] Starting Icepak simulation with auto-extraction...")
    
    try:
        results = run_icepak_simulation(mas_file)
        
        temperatures = results['temperatures']
        ambient_temp = results['ambient']
        
        print(f"\n  [OK] Simulation and extraction successful!")
        print(f"  Ambient: {ambient_temp}C")
        print(f"  Extracted {len(temperatures)} temperatures")
        
    except Exception as e:
        print(f"\n  [FAIL] {e}")
        print("  NO FALLBACK - Skipping")
        kill_ansys_processes()
        print()
        continue
    
    # Generate test code
    print("\n  [GENERATE] Creating C++ test...")
    
    tags = ["temperature", "icepak-validation", "smoke-test"]
    tags.append("round-winding-window" if is_toroidal else "rectangular-winding-window")
    tags_str = ']['.join(tags)
    
    turns_str = ', '.join(map(str, num_turns))
    parallels_str = ', '.join(['1'] * num_windings) if num_windings > 0 else '1'
    
    # Build temperature comments
    temp_comments = [f"    // Icepak reference temperatures (ambient: {ambient_temp}C):"]
    
    # Map object names to component names
    if 'core_0' in temperatures:
        temp_comments.append(f"    // Core Central Column: {temperatures['core_0']:.2f}C")
    if 'core_1' in temperatures:
        temp_comments.append(f"    // Core Lateral Column: {temperatures['core_1']:.2f}C")
    if 'bobbin' in temperatures:
        temp_comments.append(f"    // Bobbin: {temperatures['bobbin']:.2f}C")
    
    # Turn temperatures
    turn_temps = {k: v for k, v in temperatures.items() if 'turn' in k.lower() and 'copper' in k.lower()}
    if turn_temps:
        temp_comments.append(f"    // Turn temperatures ({len(turn_temps)} total):")
        for name, temp in sorted(turn_temps.items())[:5]:
            temp_comments.append(f"    //   {name}: {temp:.2f}C")
        if len(turn_temps) > 5:
            temp_comments.append(f"    //   ... and {len(turn_temps) - 5} more")
    
    temp_comments_str = '\n'.join(temp_comments)
    
    # Generate C++ test
    cpp_test = f'''
TEST_CASE("{test_name}", "[{tags_str}]") {{
    // Icepak validation test generated on {datetime.now().strftime("%Y-%m-%d %H:%M")}
    // Source MAS file: {mas_file.stem}.json
    // Core: {core_shape} ({core_material})
    // Windings: {num_windings} with turns: {num_turns}
    
    std::vector<int64_t> numberTurns({{{turns_str}}});
    std::vector<int64_t> numberParallels({{{parallels_str}}});
    std::string shapeName = "{core_shape}";

    auto coil = OpenMagneticsTesting::get_quick_coil(numberTurns,
                                                     numberParallels,
                                                     shapeName,
                                                     1,
                                                     WindingOrientation::OVERLAPPING,
                                                     WindingOrientation::OVERLAPPING,
                                                     CoilAlignment::SPREAD,
                                                     CoilAlignment::SPREAD);

    std::string coreMaterial = "{core_material}";
    auto gapping = json::array();
    auto core = OpenMagneticsTesting::get_quick_core(shapeName, gapping, 1, coreMaterial);
    
    OpenMagnetics::Magnetic magnetic;
    magnetic.set_core(core);
    magnetic.set_coil(coil);

    TemperatureConfig config;
    config.ambientTemperature = {ambient_temp:.1f};
    config.coreLosses = 1.0;
    config.windingLosses = 0.5;
    applySimulatedLosses(config, magnetic);
    config.plotSchematic = false;
    
    Temperature temp(magnetic, config);
    auto result = temp.calculateTemperatures();
    
    REQUIRE(result.converged);
    REQUIRE(result.maximumTemperature > config.ambientTemperature);
    
{temp_comments_str}
    
    REQUIRE(result.totalThermalResistance > 0.0);
}}
'''
    
    # Append to test file
    if test_file.exists():
        with open(test_file, 'r', encoding='utf-8') as f:
            content = f.read()
        if content.rstrip().endswith('}'):
            last_brace = content.rstrip().rfind('}')
            if last_brace > 0:
                content = content[:last_brace] + cpp_test + '\n}\n'
            else:
                content += cpp_test
        else:
            content += cpp_test
    else:
        content = cpp_test
    
    with open(test_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"  [OK] Test added to TestTemperature.cpp")
    print()

print("=" * 80)
print("COMPLETE - FULL AUTOMATION SUCCESSFUL")
print("=" * 80)
print(f"Test file: {test_file}")
print()
print("All tests generated with REAL Icepak simulation data!")
print("Temperatures auto-extracted via CSV export.")
