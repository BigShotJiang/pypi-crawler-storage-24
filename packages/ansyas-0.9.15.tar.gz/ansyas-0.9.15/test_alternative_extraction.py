#!/usr/bin/env python3
"""
Alternative temperature extraction using Icepak monitors
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import ansys.aedt.core as pyaedt
from ansys.aedt.core import Icepak

print("Testing Icepak temperature extraction methods...")

# Try to find alternative methods to get temperature
print("\nAvailable Icepak post-processing methods:")
ipk_methods = [m for m in dir(Icepak) if 'temp' in m.lower() or 'monitor' in m.lower() or 'field' in m.lower()]
for m in ipk_methods:
    print(f"  - {m}")

print("\nChecking PostProcessorIcepak:")
from ansys.aedt.core.visualization.post.post_icepak import PostProcessorIcepak
post_methods = [m for m in dir(PostProcessorIcepak) if not m.startswith('_') and ('temp' in m.lower() or 'monitor' in m.lower() or 'field' in m.lower())]
for m in post_methods:
    print(f"  - {m}")

print("\nDone!")
