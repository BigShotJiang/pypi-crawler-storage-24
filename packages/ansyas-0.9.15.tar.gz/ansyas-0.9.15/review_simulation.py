#!/usr/bin/env python3
"""
Simplified Icepak runner - creates simulation and leaves it open for review
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './src/Ansyas/')))

import time
from pathlib import Path
import json

print("=" * 80)
print("Icepak Simulation - Review Mode")
print("=" * 80)
print()

# Paths
examples_dir = Path("C:/Users/Alfonso/wuerth/Ansyas/examples")
output_path = Path("C:/Users/Alfonso/wuerth/Ansyas/output/review_mode")
output_path.mkdir(parents=True, exist_ok=True)

# Find MAS file
mas_file = examples_dir / "concentric_transformer.json"
print(f"Processing: {mas_file.name}")
print()

# Import Ansyas
import mas_autocomplete
from ansyas import Ansyas

print("Loading MAS file...")
with open(mas_file, 'r', encoding='utf-8') as f:
    mas_dict = json.load(f)

mas = mas_autocomplete.autocomplete(mas_dict)
print("[OK] MAS file loaded")
print()

# Create Ansyas instance
print("Creating Icepak project...")
ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

project_name = f"review_{mas_file.stem}_{int(time.time())}"
project = ansyas.create_project(
    outputs_folder=str(output_path),
    project_name=project_name,
    non_graphical=False,  # GUI ON
    new_desktop_session=True,
    solution_type="SteadyState"
)

# IMPORTANT: Set units to meters (MAS uses meters!)
ansyas.set_units("meter")

print("[OK] Icepak project created - Ansys GUI is now open")
print("[OK] Units set to meters")
print()

# Build geometry
print("Building geometry...")
ansyas.create_magnetic_simulation(mas=mas, simulate=False, operating_point_index=0)
print("[OK] Geometry built with core, coil, and heat sources")
print()

# Run simulation
print("=" * 80)
print("Running thermal simulation...")
print("You can watch the progress in the Ansys GUI")
print("=" * 80)
print()

ansyas.analyze()

print("[OK] Simulation completed!")
print()

# Save project
project.save_project()
print(f"[OK] Project saved to: {output_path / project_name}.aedt")
print()

# Display summary
print("=" * 80)
print("SIMULATION COMPLETE - REVIEW MODE")
print("=" * 80)
print()
print("Ansys Icepak is still running with the project open.")
print()
print("You can now:")
print("  1. Review the temperature field in the GUI")
print("  2. Create your own field reports")
print("  3. Extract temperatures manually")
print()
print("Project location:")
print(f"  {output_path / project_name}.aedt")
print()
print("Object names in the model:")
print("  - Core parts: core_0, core_1")
print("  - Bobbin: bobbin")
print("  - Turns: e.g., 'Primary parallel 0 turn 0_copper'")
print()
print("To extract temperatures manually in Ansys:")
print("  1. Go to Results tab")
print("  2. Create Field Report")
print("  3. Select 'Temp' as quantity")
print("  4. Select objects (core_0, turns, etc.)")
print()
print("=" * 80)
print()

# Extract temperatures from the completed simulation
print("Extracting temperatures...")
print()

try:
    # Get the post processor
    post = project.post
    
    # List available objects
    print("Available objects in model:")
    for name in sorted(project.modeler.objects.keys()):
        print(f"  - {name}")
    print()
    
    # Try to get temperature for core
    if 'core_0' in project.modeler.objects:
        print("Getting temperature for core_0...")
        # Create a simple field report
        success = post.create_report(
            plot_name="Core_Temp",
            expressions=["Temp"],
            setup_sweep_name="Setup : LastAdaptive"
        )
        if success:
            print("  [OK] Temperature report created")
        else:
            print("  [Warning] Could not create temperature report")
    
    print()
    print("Temperature extraction attempted.")
    print("You can now review the full results in the Ansys GUI.")
    
except Exception as e:
    print(f"  [Warning] Could not extract temperatures: {e}")
    print("  You can manually extract temperatures from the Ansys GUI.")

print()
print("=" * 80)
print("Press Ctrl+C to close and save the project")
print("=" * 80)

# Keep script running
while True:
    try:
        time.sleep(1)
    except KeyboardInterrupt:
        print("\n\nClosing...")
        try:
            project.save_project()
            project.release_desktop(close_projects=False, close_desktop=False)
        except:
            pass
        break
