#!/usr/bin/env python3
"""
Debug script to check setup availability after simulation
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import ansys.aedt.core as pyaedt
from Ansyas import Ansyas
import mas_autocomplete
import json
import os

# Load MAS
mas_file = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'
with open(mas_file, 'r') as f:
    mas_dict = json.load(f)

mas = mas_autocomplete.autocomplete(mas_dict)

# Create project
ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)

output_dir = r'C:\Users\Alfonso\wuerth\Ansyas\output\debug_setup'
os.makedirs(output_dir, exist_ok=True)

project = ansyas.create_project(
    outputs_folder=output_dir,
    project_name="debug_setup_test",
    non_graphical=True,
    solution_type="SteadyState",
    new_desktop_session=True
)

ansyas.set_units("meter")
ansyas.create_magnetic_simulation(
    mas=mas,
    simulate=False,
    operating_point_index=0
)

print("\n" + "="*80)
print("CHECKING SETUP AVAILABILITY")
print("="*80)

# Check setups before running
print("\n1. Setups BEFORE running simulation:")
if hasattr(project, 'setups'):
    print(f"   Number of setups: {len(project.setups)}")
    for i, setup in enumerate(project.setups):
        print(f"   Setup {i}: {setup.name}")
else:
    print("   No setups attribute")

# Create setup
setup = project.create_setup("Setup")
print(f"\n2. Created setup: {setup.name}")

# Check setups after creating
print("\n3. Setups AFTER creating:")
print(f"   Number of setups: {len(project.setups)}")
for i, setup in enumerate(project.setups):
    print(f"   Setup {i}: {setup.name}")

# Run simulation
print("\n4. Running simulation...")
project.analyze_setup("Setup")
print("   [OK] Simulation completed")

# Check setups after simulation
print("\n5. Setups AFTER simulation:")
print(f"   Number of setups: {len(project.setups)}")
for i, setup in enumerate(project.setups):
    print(f"   Setup {i}: {setup.name}")

# Try to access post
print("\n6. Checking post-processor:")
print(f"   Has post attribute: {hasattr(project, 'post')}")
if hasattr(project, 'post'):
    print(f"   Post type: {type(project.post)}")
    
# Try to create report
print("\n7. Trying to create report:")
try:
    setup_name = project.setups[0].name
    full_setup_name = f"{setup_name} : LastAdaptive"
    print(f"   Using setup name: {full_setup_name}")
    
    success = project.post.create_report(
        expressions=["Temperature"],
        setup_sweep_name=full_setup_name
    )
    print(f"   Report creation result: {success}")
except Exception as e:
    print(f"   ERROR: {e}")

print("\n" + "="*80)
print("DEBUG COMPLETE")
print("="*80)

ansyas.solver_backend.close()
