#!/usr/bin/env python3
"""
Test to verify bobbin column shape and turn creation
"""

import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import json
import mas_autocomplete as ansyas_mas
import MAS_models as MAS

# Load MAS file
mas_file = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'
with open(mas_file, 'r') as f:
    mas_dict = json.load(f)

# Check bobbin column shape in raw MAS
print("Raw MAS file bobbin column shape:")
print(f"  columnShape: {mas_dict.get('magnetic', {}).get('bobbin', {}).get('processedDescription', {}).get('columnShape')}")

# Auto-complete
mas = ansyas_mas.autocomplete(mas_dict)

# Check after autocomplete - access via magnetic.coil.bobbin
print("\nAfter autocomplete:")
if hasattr(mas.magnetic, 'bobbin') and mas.magnetic.bobbin:
    print(f"  Bobbin column shape: {mas.magnetic.bobbin.processedDescription.columnShape}")
    print(f"  Bobbin column shape type: {type(mas.magnetic.bobbin.processedDescription.columnShape)}")
    
    bobbin_shape = mas.magnetic.bobbin.processedDescription.columnShape
    print(f"\nEnum comparison tests:")
    print(f"  bobbin_shape is MAS.ColumnShape.round: {bobbin_shape is MAS.ColumnShape.round}")
    print(f"  bobbin_shape == MAS.ColumnShape.round: {bobbin_shape == MAS.ColumnShape.round}")
    print(f"  bobbin_shape.value == 'round': {bobbin_shape.value == 'round'}")
else:
    print("  No bobbin found in mas.magnetic!")
    print(f"  Available attributes: {[attr for attr in dir(mas.magnetic) if not attr.startswith('_')]}")

# Check coil
print("\nCoil info:")
if hasattr(mas.magnetic, 'coil') and mas.magnetic.coil:
    if hasattr(mas.magnetic.coil, 'bobbin') and mas.magnetic.coil.bobbin:
        print(f"  Bobbin in coil found!")
        print(f"  Column shape: {mas.magnetic.coil.bobbin.processedDescription.columnShape}")
        
        bobbin_shape = mas.magnetic.coil.bobbin.processedDescription.columnShape
        print(f"\n  Enum comparison tests:")
        print(f"    bobbin_shape is MAS.ColumnShape.round: {bobbin_shape is MAS.ColumnShape.round}")
        print(f"    bobbin_shape == MAS.ColumnShape.round: {bobbin_shape == MAS.ColumnShape.round}")
        if hasattr(bobbin_shape, 'value'):
            print(f"    bobbin_shape.value == 'round': {bobbin_shape.value == 'round'}")
            print(f"    Value: {bobbin_shape.value}")
    else:
        print("  No bobbin in mas.magnetic.coil")
        
    print(f"\n  Coil functional description:")
    for i, winding in enumerate(mas.magnetic.coil.functionalDescription):
        print(f"    Winding {i}: {winding.numberTurns} turns")
        print(f"      Wire type: {winding.wire.type}")
        if hasattr(winding.wire.type, 'value'):
            print(f"      Wire type value: {winding.wire.type.value}")
    
    if hasattr(mas.magnetic.coil, 'turnsDescription'):
        print(f"\n  Number of turns: {len(mas.magnetic.coil.turnsDescription)}")
        if len(mas.magnetic.coil.turnsDescription) > 0:
            first_turn = mas.magnetic.coil.turnsDescription[0]
            print(f"    First turn: {first_turn.name}")
            print(f"    Coordinates: {first_turn.coordinates}")
else:
    print("  No coil found!")
    
print("\nDone!")
