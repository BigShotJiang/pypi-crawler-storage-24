#!/usr/bin/env python3
"""
Simple demonstration of the temperature test generator
This shows what the script would do with the example file
"""

import json
from pathlib import Path
from datetime import datetime

print("=" * 80)
print("Temperature Test Generator - Demonstration")
print("=" * 80)
print()

# Load the example file
example_file = Path("C:/Users/Alfonso/wuerth/Ansyas/examples/concentric_transformer.json")
print(f"Loading: {example_file}")

try:
    with open(example_file, 'r') as f:
        data = json.load(f)
    print("[OK] File loaded successfully")
except Exception as e:
    print(f"[ERROR] Error loading file: {e}")
    exit(1)

# Extract information
magnetic = data.get('magnetic', {})
core = magnetic.get('core', {})
coil = magnetic.get('coil', {})

# Core info
core_functional = core.get('functionalDescription', {})
shape = core_functional.get('shape', {})
core_shape = shape.get('name', 'ETD 25')  # Default if not found

# Handle material - could be a string or a dict
material_data = core_functional.get('material', '3C95')
if isinstance(material_data, dict):
    core_material = material_data.get('name', '3C95')
else:
    core_material = material_data

# Coil info
functional_desc = coil.get('functionalDescription', [])
num_turns = [w.get('numberTurns', 0) for w in functional_desc]
num_windings = len(num_turns)

# Bobbin
bobbin = coil.get('bobbin', {})
has_bobbin = isinstance(bobbin, dict) and bobbin.get('processedDescription') is not None

print()
print("Extracted Component Information:")
print(f"  Core Shape: {core_shape}")
print(f"  Core Material: {core_material}")
print(f"  Number of Windings: {num_windings}")
print(f"  Turns per Winding: {num_turns}")
print(f"  Has Bobbin: {has_bobbin}")
print()

# Generate test name
shape_clean = core_shape.replace(' ', '_').replace('/', '_')
test_name = f"Temperature_Concentric_{shape_clean}_{num_windings}W_{sum(num_turns)}T"
if has_bobbin:
    test_name += "_Bobbin"
test_name += "_Icepak"

print(f"Generated Test Name: {test_name}")
print()

# Generate C++ test code
cpp_test = f'''TEST_CASE("{test_name}", "[temperature][icepak-validation][smoke-test][rectangular-winding-window]") {{
    // Icepak validation test generated on {datetime.now().strftime("%Y-%m-%d %H:%M")}
    // Source MAS file: concentric_transformer.json
    // Core: {core_shape} ({core_material})
    // Windings: {num_windings} with turns: {num_turns}
    
    std::vector<int64_t> numberTurns({{{', '.join(map(str, num_turns))}}});
    std::vector<int64_t> numberParallels({{{', '.join(['1'] * num_windings)}}});
    std::string shapeName = "{core_shape}";

    auto coil = OpenMagneticsTesting::get_quick_coil(numberTurns,
                                                     numberParallels,
                                                     shapeName,
                                                     1,
                                                     WindingOrientation::OVERLAPPING,
                                                     WindingOrientation::OVERLAPPING,
                                                     CoilAlignment::SPREAD,
                                                     CoilAlignment::SPREAD);

    std::string coreMaterial = "{core_material}";
    auto gapping = json::array();
    auto core = OpenMagneticsTesting::get_quick_core(shapeName, gapping, 1, coreMaterial);
    
    OpenMagnetics::Magnetic magnetic;
    magnetic.set_core(core);
    magnetic.set_coil(coil);

    TemperatureConfig config;
    config.ambientTemperature = 25.0;
    config.coreLosses = 1.0;
    config.windingLosses = 0.5;
    applySimulatedLosses(config, magnetic);
    config.plotSchematic = false;
    
    Temperature temp(magnetic, config);
    auto result = temp.calculateTemperatures();
    
    REQUIRE(result.converged);
    REQUIRE(result.maximumTemperature > config.ambientTemperature);
    
    // Icepak reference temperatures (placeholder values):
    // Core Central Column: 62.5°C
    // Core Lateral Column: 58.3°C
    // Core Top Yoke: 60.1°C
    // Core Bottom Yoke: 60.1°C
    // Bobbin Central Column: 55.2°C
    // 22 turns with temperatures ranging from 40°C to 52°C
    
    REQUIRE(result.totalThermalResistance > 0.0);
}}
'''

print("=" * 80)
print("Generated C++ Test Code:")
print("=" * 80)
print()
print(cpp_test)

print("=" * 80)
print("What would happen next:")
print("=" * 80)
print()
print("1. [OK] Parse MAS file and extract component info")
print("2. [OK] Generate unique test name")
print("3. [OK] Create C++ test code with Icepak reference values")
print("4. [NEXT] Check if test already exists in TestTemperature.cpp")
print("5. [NEXT] If not, append test to file")
print("6. [NEXT] User runs MKF build and executes new test")
print()
print("To run the actual script:")
print("  python3 /home/alf/OpenMagnetics/MKF/src/scripts/generate_temperature_tests.py")
print()
print("Note: Currently uses placeholder values. Once cooling.py is implemented,")
print("the script will run actual Icepak simulations and extract real temperatures.")
