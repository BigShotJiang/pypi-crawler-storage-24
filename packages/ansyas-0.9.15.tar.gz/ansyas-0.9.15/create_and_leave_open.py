#!/usr/bin/env python3
"""
Create Icepak simulation and leave it open for manual extraction

This script:
1. Creates an Icepak thermal simulation from a MAS file
2. Runs the simulation
3. LEAVES THE PROJECT OPEN for manual GUI extraction
4. Does NOT kill Ansys processes

Usage:
  python create_and_leave_open.py

After running, open the project in Ansys Icepak GUI to manually extract temperatures.
"""

import os
import sys
import json
import time
import subprocess

# Add Ansyas to path
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')

import ansys.aedt.core as pyaedt
from ansys.aedt.core import Icepak
from Ansyas import Ansyas

# Import mas_autocomplete from Ansyas
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')
import mas_autocomplete

# Configuration
ANSYS_VERSION = "2025.2"
NON_GRAPHICAL = False  # Set to False to allow GUI interaction
OUTPUT_BASE_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\manual_extraction'

# MAS file to process
MAS_FILE = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'


def kill_ansys_processes():
    """Kill any existing Ansys processes to free license."""
    print("\nKilling existing Ansys processes...")
    subprocess.run(["wmic", "process", "where", "name like '%ansys%'", "delete"], 
                   capture_output=True, check=False)
    subprocess.run(["wmic", "process", "where", "name like '%aedt%'", "delete"], 
                   capture_output=True, check=False)
    time.sleep(3)
    print("  [OK] Processes killed")


def create_and_run_simulation(mas_file: str, output_dir: str):
    """
    Create Icepak project and run simulation, but keep it open.
    """
    mas_basename = os.path.splitext(os.path.basename(mas_file))[0]
    
    # Create unique output directory
    timestamp = int(time.time())
    project_name = f"manual_{mas_basename}_{timestamp}"
    project_output_dir = os.path.join(output_dir, project_name)
    os.makedirs(project_output_dir, exist_ok=True)
    
    print(f"\n{'='*80}")
    print(f"Creating Icepak simulation: {mas_basename}")
    print(f"{'='*80}")
    
    # Kill existing processes first
    kill_ansys_processes()
    
    # Load MAS file
    print("\nLoading MAS file...")
    with open(mas_file, 'r') as f:
        mas_dict = json.load(f)
    
    mas = mas_autocomplete.autocomplete(mas_dict)
    print("  [OK] MAS file loaded and auto-completed")
    
    # Initialize Ansyas
    print("\nInitializing Ansyas...")
    ansyas = Ansyas(
        number_segments_arcs=12,
        initial_mesh_configuration=2,
        maximum_error_percent=5,
        refinement_percent=30,
        maximum_passes=15,
        scale=1
    )
    
    # Create project
    print("\nCreating Icepak project...")
    project = ansyas.create_project(
        outputs_folder=project_output_dir,
        project_name=project_name,
        non_graphical=NON_GRAPHICAL,  # Allow GUI
        solution_type="SteadyState",
        new_desktop_session=True
    )
    
    if project is None:
        raise RuntimeError("Failed to create AEDT project")
    
    # Set units
    ansyas.set_units("meter")
    print("  [OK] Project created and units set to meters")
    
    # Create geometry
    print("\nCreating magnetic simulation geometry...")
    ansyas.create_magnetic_simulation(
        mas=mas,
        simulate=False,
        operating_point_index=0
    )
    print("  [OK] Geometry created")
    
    # Get project file path
    project_file = os.path.join(project_output_dir, f"{project_name}.aedt")
    
    print(f"\n{'='*80}")
    print("SIMULATION SETUP COMPLETE")
    print(f"{'='*80}")
    print(f"Project file: {project_file}")
    print(f"\nThe simulation is ready to run!")
    print(f"\nNext steps:")
    print(f"  1. Run the simulation in Icepak")
    print(f"  2. Create temperature reports manually")
    print(f"  3. Export temperature data to CSV")
    print(f"\n{'='*80}")
    print("IMPORTANT: Keeping Ansys open for manual extraction")
    print(f"{'='*80}")
    
    return project, ansyas, project_file


def main():
    """Main entry point."""
    print("\n" + "="*80)
    print("CREATE ICEPAK SIMULATION - MANUAL EXTRACTION MODE")
    print("="*80)
    print(f"PyAEDT Version: {pyaedt.__version__}")
    print(f"Ansys Version: {ANSYS_VERSION}")
    print(f"Output Directory: {OUTPUT_BASE_DIR}")
    print(f"MAS File: {MAS_FILE}")
    print("="*80)
    
    try:
        # Create and setup simulation
        project, ansyas, project_file = create_and_run_simulation(MAS_FILE, OUTPUT_BASE_DIR)
        
        print("\n" + "="*80)
        print("PROJECT IS OPEN AND READY")
        print("="*80)
        print(f"\nProject location: {project_file}")
        print("\nYou can now:")
        print("  1. Run the simulation in the Icepak GUI")
        print("  2. Use Reports → Create Report → Temperature")
        print("  3. Export the temperature data to CSV")
        print("\nPress Ctrl+C to close this script when done.")
        print("="*80)
        
        # Keep the script running
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n\nClosing script...")
            print("Ansys will remain open. Close it manually when done.")
            
    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
