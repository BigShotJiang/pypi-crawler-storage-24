# IronPython script to export temperatures
# This script runs inside AEDT

import clr
clr.AddReference('Ansys.Ansoft.IcepakAutomation')
from Ansys.Ansoft.IcepakAutomation import *

# Get the active design
oDesktop = GetActiveDesktop()
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()

# Get the module
oModule = oDesign.GetModule("ReportSetup")

# Objects to extract
temp_file = r"C:\Users\Alfonso\wuerth\Ansyas\output\temperatures.txt"

# Create a simple report and export
try:
    # For each object, get temperature
    objects = ['core_0', 'core_1', 'bobbin']
    results = []
    
    for obj in objects:
        try:
            # Create field report
            report_name = "Temp_" + obj
            oModule.CreateReport(
                report_name,
                "Fields",
                "Rectangular Plot",
                "Setup : SteadyState",
                [],
                ["Temp"],
                ["X", "Y", "Z"],
                obj
            )
            
            # Export to CSV
            csv_file = r"C:\Users\Alfonso\wuerth\Ansyas\output\temp_" + obj + ".csv"
            oModule.ExportToFile(report_name, csv_file)
            results.append(obj + ": exported")
        except Exception as e:
            results.append(obj + ": " + str(e))
    
    # Write summary
    with open(temp_file, 'w') as f:
        f.write('\n'.join(results))
        
    print("Temperature export completed")
    
except Exception as e:
    print("Error: " + str(e))
