#!/usr/bin/env python3
"""Debug script to test Ansys simulation setup"""
import os
import sys
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src')
sys.path.insert(0, r'C:\Users\Alfonso\wuerth\Ansyas\src\Ansyas')

import json
import mas_autocomplete
from Ansyas import Ansyas

MAS_FILE = r'C:\Users\Alfonso\wuerth\Ansyas\examples\concentric_transformer.json'
OUTPUT_DIR = r'C:\Users\Alfonso\wuerth\Ansyas\output\debug'

os.makedirs(OUTPUT_DIR, exist_ok=True)

print("="*80)
print("DEBUG: Testing Ansys Simulation")
print("="*80)

# Load MAS file
print("\n1. Loading MAS file...")
with open(MAS_FILE, 'r') as f:
    mas_dict = json.load(f)
mas = mas_autocomplete.autocomplete(mas_dict)
print("   [OK] MAS file loaded")

# Create Ansyas instance
print("\n2. Creating Ansyas instance...")
ansyas = Ansyas(
    number_segments_arcs=12,
    initial_mesh_configuration=2,
    maximum_error_percent=5,
    refinement_percent=30,
    maximum_passes=15,
    scale=1
)
print("   [OK] Ansyas instance created")

# Create project
print("\n3. Creating project...")
project = ansyas.create_project(
    outputs_folder=OUTPUT_DIR,
    project_name="debug_test",
    non_graphical=True,
    solution_type="EddyCurrent",
    new_desktop_session=True
)
print(f"   [OK] Project created: {project.project_name}")

# Set units
print("\n4. Setting units...")
ansyas.set_units("meter")
print("   [OK] Units set")

# Create magnetic simulation
print("\n5. Creating magnetic simulation...")
ansyas.create_magnetic_simulation(mas=mas, single_frequency=True)
print("   [OK] Magnetic simulation created")

# Check setup
print("\n6. Checking setup...")
if hasattr(project, 'setups') and project.setups:
    print(f"   [OK] Found {len(project.setups)} setup(s)")
    for i, setup in enumerate(project.setups):
        print(f"      Setup {i}: {setup.name}")
        print(f"      Props: {setup.props}")
else:
    print("   [ERROR] No setups found!")

# Try to analyze
print("\n7. Running analysis...")
try:
    ansyas.analyze()
    print("   [OK] Analysis completed")
except Exception as e:
    print(f"   [ERROR] Analysis failed: {e}")
    import traceback
    traceback.print_exc()

# Try to get results
print("\n8. Getting results...")
try:
    results = ansyas.outputs_extractor.get_results()
    print(f"   [OK] Results: {results}")
    if hasattr(results, 'inductanceMatrix'):
        print(f"   Inductance matrix length: {len(results.inductanceMatrix)}")
except Exception as e:
    print(f"   [ERROR] Failed to get results: {e}")
    import traceback
    traceback.print_exc()

# Save project
print("\n9. Saving project...")
ansyas.save()
print("   [OK] Project saved")

print("\n" + "="*80)
print("DEBUG COMPLETE")
print("="*80)

# Release desktop
project.release_desktop(close_projects=False, close_desktop=False)
