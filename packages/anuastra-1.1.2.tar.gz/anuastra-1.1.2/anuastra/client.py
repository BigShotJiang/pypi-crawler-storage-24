import requests
from typing import List, Dict, Any, Optional, Union
from .circuit import QuantumCircuit

class KyberPQC:
    def __init__(self, request_fn):
        self._request = request_fn

    def keygen(self, level: int = 768) -> Dict[str, Any]:
        """
        DEPRECATED: Server-side generation transmits private keys over HTTPS. 
        Use keygen_local() for true Zero-Knowledge Key Encapsulation.
        """
        return self._request('/quantum/pqc/kyber/keygen', 'POST', {'level': level})

    def keygen_local(self, level: int = 768) -> Dict[str, Any]:
        """
        Generates a Kyber keypair LOCALLY in the SDK to ensure zero-knowledge transmission.
        The private key never leaves the client device.
        """
        import pqcrypto.kem.kyber512 as kyber512
        import pqcrypto.kem.kyber768 as kyber768
        import pqcrypto.kem.kyber1024 as kyber1024
        import base64

        kem = kyber512 if level == 512 else kyber1024 if level == 1024 else kyber768
        public_key_bytes, secret_key_bytes = kem.generate_keypair()
        
        return {
            'status': 'success',
            'algorithm': f'ML-KEM-{level}',
            'public_key': base64.b64encode(public_key_bytes).decode('utf-8'),
            'private_key': base64.b64encode(secret_key_bytes).decode('utf-8')
        }

    def encapsulate(self, public_key: str, level: int = 768) -> Dict[str, Any]:
        return self._request('/quantum/pqc/kyber/encapsulate', 'POST', {'publicKey': public_key, 'level': level})

    def decapsulate(self, ciphertext: str, private_key: str, level: int = 768) -> Dict[str, Any]:
        """
        DEPRECATED: Server-side decapsulation requires transmitting private keys over HTTPS.
        Use decapsulate_local() for true Zero-Knowledge Key Encapsulation.
        """
        return self._request('/quantum/pqc/kyber/decapsulate', 'POST', {'ciphertext': ciphertext, 'privateKey': private_key, 'level': level})
        
    def decapsulate_local(self, ciphertext: str, private_key: str, level: int = 768) -> Dict[str, Any]:
        """
        Decapsulates a ciphertext LOCALLY in the SDK using the local private key.
        """
        import pqcrypto.kem.kyber512 as kyber512
        import pqcrypto.kem.kyber768 as kyber768
        import pqcrypto.kem.kyber1024 as kyber1024
        import base64

        kem = kyber512 if level == 512 else kyber1024 if level == 1024 else kyber768
        c_bytes = base64.b64decode(ciphertext)
        p_bytes = base64.b64decode(private_key)
        
        shared_secret = kem.decrypt(c_bytes, p_bytes)
        
        return {
            'status': 'success',
            'algorithm': f'ML-KEM-{level}',
            'shared_secret': base64.b64encode(shared_secret).decode('utf-8')
        }

class DilithiumPQC:
    def __init__(self, request_fn):
        self._request = request_fn

    def keygen(self, level: int = 3) -> Dict[str, Any]:
        return self._request('/quantum/pqc/dilithium/keygen', 'POST', {'level': level})

    def sign(self, message: str, private_key: str, level: int = 3) -> Dict[str, Any]:
        return self._request('/quantum/pqc/dilithium/sign', 'POST', {'message': message, 'privateKey': private_key, 'level': level})

    def verify(self, signature: str, message: str, public_key: str, level: int = 3) -> Dict[str, Any]:
        return self._request('/quantum/pqc/dilithium/verify', 'POST', {'signature': signature, 'message': message, 'publicKey': public_key, 'level': level})


class Qrng:
    """
    Quantum Random Number Generator (QRNG) native to the Aṇu Astra VQP.
    Uses pure quantum entropy via Hadamard-superposition.
    """
    def __init__(self, request_fn):
        self._request = request_fn

    def get_random_bits(self, size: int = 32) -> Dict[str, Any]:
        """Generate a random bit string of the specified size."""
        return self._request('/quantum/qrng', 'POST', {'type': 'bits', 'size': size})

    def get_random_bytes(self, length: int = 32) -> Dict[str, Any]:
        """Generate random bytes (returned as a hex string)."""
        return self._request('/quantum/qrng', 'POST', {'type': 'bytes', 'size': length})

    def get_random_int(self, min: int = 0, max: int = 100) -> Dict[str, Any]:
        """Generate a random integer within the range [min, max]."""
        return self._request('/quantum/qrng', 'POST', {'type': 'int', 'min': min, 'max': max})

    def get_random_float(self) -> Dict[str, Any]:
        """Generate a random float in the range [0.0, 1.0)."""
        return self._request('/quantum/qrng', 'POST', {'type': 'float'})


class Qkd:
    """
    Virtual Quantum Key Distribution (vQKD) via Aṇu Astra VQP.
    Supports BB84 (prepare-and-measure) and E91 (Ekert entanglement) protocols.
    Both are fully quantum-seeded via the QRNG engine.
    """
    def __init__(self, request_fn):
        self._request = request_fn

    def bb84(self, key_length: int = 256) -> Dict[str, Any]:
        """
        Run a BB84 QKD session.
        Alice prepares qubits → Bob measures → Basis sifting → Shared key.
        
        Returns: session_id, shared_key (base64), final_key_length,
                 error_rate, eavesdropping_detected, quantum_seeded,
                 cost_deducted, verification_url
        """
        return self._request('/quantum/qkd/bb84', 'POST', {'keyLength': key_length})

    def e91(self, key_length: int = 256) -> Dict[str, Any]:
        """
        Run an E91 (Ekert) QKD session using entangled Bell pairs.
        Includes CHSH inequality check for eavesdropping detection.
        
        Returns: session_id, shared_key (base64), final_key_length,
                 error_rate, chsh_value, eavesdropping_detected, quantum_seeded,
                 cost_deducted, verification_url
        """
        return self._request('/quantum/qkd/e91', 'POST', {'keyLength': key_length})


class Client:
    """
    Official Python SDK for the Aṇu Astra Virtual Quantum Processor (v1.3.0)
    
    Enterprise-grade quantum computing API with:
    - QRNG (Quantum Random Number Generation)
    - PQC (Post-Quantum Cryptography: ML-KEM + ML-DSA)
    - vQKD (Virtual Quantum Key Distribution: BB84 + E91)
    - Quantum Circuit Execution (OpenQASM 2.0 compatible)
    - Immutable Audit Ledger with Ed25519 cryptographic signatures
    - Credit-based usage tracking
    """
    def __init__(self, api_key: str, base_url: str = 'https://astra.cryptopix.in/api/v1'):
        if not api_key:
            raise ValueError("Aṇu Astra API Key is required")
        self.api_key = api_key
        self.base_url = base_url
        self.kyber = KyberPQC(self._request)
        self.dilithium = DilithiumPQC(self._request)
        self.qrng = Qrng(self._request)
        self.qkd = Qkd(self._request)

    def _request(self, endpoint: str, method: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        url = f"{self.base_url}{endpoint}"
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
        
        response = requests.request(method, url, headers=headers, json=data)
        
        try:
            result = response.json()
        except ValueError:
            response.raise_for_status()
            return {}

        if not response.ok:
            error_msg = result.get('error', response.reason)
            request_id = result.get('requestId', '')
            suffix = f" (requestId: {request_id})" if request_id else ''
            raise Exception(f"Aṇu Astra API Error [{response.status_code}]: {error_msg}{suffix}")
            
        # Enterprise Envelope Unwrapping
        if 'data' in result and 'compliance' in result and 'metadata' in result:
            unwrapped = result['data']
            unwrapped['status'] = result.get('status', 'success')
            unwrapped['_metadata'] = result['metadata']
            unwrapped['_compliance'] = result['compliance']
            unwrapped['_cost_deducted'] = result.get('cost_deducted', 0)
            unwrapped['_verification_url'] = result['compliance'].get('verification_url', '')
            return unwrapped

        return result

    def get_balance(self) -> Dict[str, Any]:
        """Get your current quantum credit balance."""
        return self._request('/billing/balance', 'GET')

    def get_usage(self, limit: int = 50) -> Dict[str, Any]:
        """Get your API usage history (most recent first)."""
        return self._request(f'/usage/history?limit={limit}', 'GET')

    def verify(self, transaction_id: str) -> Dict[str, Any]:
        """
        Verify any Aṇu Astra transaction against the immutable audit ledger.
        Returns the Cryptographic Certificate of Execution including:
        - Request/response hashes (SHA-256)
        - Ed25519 signature
        - Full metadata (service, timestamp, parameters)
        """
        return self._request(f'/verify/{transaction_id}', 'GET')

    def execute_quantum(self, qubits: Union[int, 'QuantumCircuit'], circuit: Optional[List[Dict[str, Any]]] = None, shots: int = 1) -> Any:
        """
        Submit a quantum payload circuit natively to the engine for physical resolution.
        """
        if type(qubits).__name__ == 'QuantumCircuit':
            _q = qubits.qubits
            _circ = qubits.operations
        else:
            _q = qubits
            _circ = circuit or []
            
        res = self._request('/quantum/execute', 'POST', {
            'qubits': _q,
            'circuit': _circ,
            'shots': shots
        })
        return QuantumResult(res)

    def execute(self, circuit: 'QuantumCircuit', shots: int = 1) -> Any:
        """
        Execute a QuantumCircuit object gracefully.
        """
        return self.execute_quantum(circuit, shots=shots)

    def execute_qasm(self, qasm_string: str, shots: int = 1) -> Dict[str, Any]:
        """
        Submit a raw OpenQASM 2.0 string for server-side compilation and execution.
        """
        return self._request('/quantum/execute-qasm', 'POST', {
            'qasm': qasm_string,
            'shots': shots
        })

class QuantumResult(dict):
    """
    Wrapper for Aṇu Astra API responses to allow easy dot-notation access
    and pretty-printing of quantum states for students.
    """
    def __getattr__(self, name):
        if name in self:
            return self[name]
        # Attempt to dig into the 'results' block automatically
        if 'results' in self and name in self['results']:
            return self['results'][name]
        # Map 'states' to 'state_binaries' as commonly requested
        if name == 'states' and 'results' in self and 'state_binaries' in self['results']:
            return self['results']['state_binaries']
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")

    def __setattr__(self, name, value):
        self[name] = value

    def __str__(self):
        import json
        return json.dumps(self, indent=2)
