"""Tests for cad2scad."""

import numpy as np
import pytest

from cad2scad.loader import MeshData, MeshBundle
from cad2scad.optimizer import MeshOptimizer, OptimizeOptions
from cad2scad.scad_writer import ScadWriter, WriterOptions
from cad2scad.analysis import analyze_body
from cad2scad.converter import Converter


# ---------------------------------------------------------------------------
# Fixtures: a simple cube mesh
# ---------------------------------------------------------------------------

def make_cube() -> MeshData:
    """Create a unit cube MeshData centered at origin."""
    vertices = np.array([
        [-1, -1, -1], [+1, -1, -1], [+1, +1, -1], [-1, +1, -1],
        [-1, -1, +1], [+1, -1, +1], [+1, +1, +1], [-1, +1, +1],
    ], dtype=np.float64)
    faces = np.array([
        [0, 3, 1], [1, 3, 2],  # bottom
        [4, 5, 7], [5, 6, 7],  # top
        [0, 1, 5], [0, 5, 4],  # front
        [2, 3, 7], [2, 7, 6],  # back
        [0, 4, 7], [0, 7, 3],  # left
        [1, 2, 6], [1, 6, 5],  # right
    ], dtype=np.int32)
    return MeshData(
        name="test_cube",
        vertices=vertices,
        faces=faces,
        metadata={"watertight": True, "volume": 8.0},
    )


def make_bundle(bodies=None) -> MeshBundle:
    if bodies is None:
        bodies = [make_cube()]
    return MeshBundle(
        source_path="test.stl",
        source_format=".stl",
        bodies=bodies,
    )


# ---------------------------------------------------------------------------
# MeshData tests
# ---------------------------------------------------------------------------

class TestMeshData:
    def test_properties(self):
        cube = make_cube()
        assert cube.num_vertices == 8
        assert cube.num_faces == 12

    def test_bounds(self):
        cube = make_cube()
        lo, hi = cube.bounds
        np.testing.assert_array_equal(lo, [-1, -1, -1])
        np.testing.assert_array_equal(hi, [+1, +1, +1])

    def test_extents(self):
        cube = make_cube()
        np.testing.assert_array_equal(cube.extents, [2, 2, 2])

    def test_center(self):
        cube = make_cube()
        np.testing.assert_array_equal(cube.center, [0, 0, 0])


# ---------------------------------------------------------------------------
# Optimizer tests
# ---------------------------------------------------------------------------

class TestOptimizer:
    def test_no_changes(self):
        """Default options should preserve mesh (no duplicates in cube)."""
        bundle = make_bundle()
        opt = MeshOptimizer()
        result = opt.optimize(bundle)
        assert result.total_vertices == 8
        assert result.total_faces == 12

    def test_weld_duplicates(self):
        """Duplicate vertices should be merged."""
        cube = make_cube()
        # Double all vertices (each vertex appears twice)
        dup_verts = np.vstack([cube.vertices, cube.vertices])
        dup_faces = np.vstack([cube.faces, cube.faces + 8])
        body = MeshData(
            name="dup_cube", vertices=dup_verts, faces=dup_faces
        )
        bundle = make_bundle([body])
        opt = MeshOptimizer(OptimizeOptions(weld_tolerance=1e-6))
        result = opt.optimize(bundle)
        assert result.total_vertices == 8  # duplicates merged

    def test_center(self):
        cube = make_cube()
        # Offset the cube
        cube.vertices += 10.0
        bundle = make_bundle([cube])
        opt = MeshOptimizer(OptimizeOptions(center=True))
        result = opt.optimize(bundle)
        center = result[0].center
        np.testing.assert_array_almost_equal(center, [0, 0, 0], decimal=6)

    def test_round_precision(self):
        cube = make_cube()
        cube.vertices += 0.123456789
        bundle = make_bundle([cube])
        opt = MeshOptimizer(OptimizeOptions(round_precision=2))
        result = opt.optimize(bundle)
        # All vertices should have at most 2 decimal places
        rounded = np.round(result[0].vertices, 2)
        np.testing.assert_array_equal(result[0].vertices, rounded)

    def test_degenerate_removal(self):
        cube = make_cube()
        # Add a degenerate triangle (all same vertex)
        degen = np.array([[0, 0, 0]], dtype=np.int32)
        cube.faces = np.vstack([cube.faces, degen])
        bundle = make_bundle([cube])
        opt = MeshOptimizer(OptimizeOptions(remove_degenerate=True))
        result = opt.optimize(bundle)
        assert result.total_faces == 12  # degenerate removed


# ---------------------------------------------------------------------------
# Writer tests
# ---------------------------------------------------------------------------

class TestScadWriter:
    def test_basic_output(self):
        bundle = make_bundle()
        writer = ScadWriter(WriterOptions(include_metadata=False))
        output = writer.to_string(bundle)
        assert "module test_cube()" in output
        assert "polyhedron(" in output
        assert "points = [" in output
        assert "faces = [" in output
        assert "test_cube();" in output

    def test_metadata_header(self):
        bundle = make_bundle()
        writer = ScadWriter(WriterOptions(include_metadata=True))
        output = writer.to_string(bundle)
        assert "Generated by cad2scad" in output
        assert "test.stl" in output

    def test_color_output(self):
        cube = make_cube()
        cube.color = (255, 0, 0, 255)
        bundle = make_bundle([cube])
        writer = ScadWriter(WriterOptions(
            include_metadata=False, include_colors=True
        ))
        output = writer.to_string(bundle)
        assert "color([1.000, 0.000, 0.000, 1.000])" in output

    def test_no_color_when_disabled(self):
        cube = make_cube()
        cube.color = (255, 0, 0, 255)
        bundle = make_bundle([cube])
        writer = ScadWriter(WriterOptions(
            include_metadata=False, include_colors=False
        ))
        output = writer.to_string(bundle)
        assert "color(" not in output

    def test_precision(self):
        cube = make_cube()
        bundle = make_bundle([cube])
        writer = ScadWriter(WriterOptions(
            include_metadata=False, precision=2
        ))
        output = writer.to_string(bundle)
        assert "-1.00" in output
        assert "1.00" in output

    def test_compact_mode(self):
        bundle = make_bundle()
        writer = ScadWriter(WriterOptions(
            include_metadata=False, compact_arrays=True
        ))
        output = writer.to_string(bundle)
        # Multiple vertices on one line
        # Count lines — compact should have fewer
        normal_writer = ScadWriter(WriterOptions(
            include_metadata=False, compact_arrays=False
        ))
        normal_output = normal_writer.to_string(bundle)
        assert len(output.split("\n")) < len(normal_output.split("\n"))

    def test_module_prefix(self):
        bundle = make_bundle()
        writer = ScadWriter(WriterOptions(
            include_metadata=False, module_prefix="imported_"
        ))
        output = writer.to_string(bundle)
        assert "module imported_test_cube()" in output
        assert "imported_test_cube();" in output


# ---------------------------------------------------------------------------
# Analysis tests
# ---------------------------------------------------------------------------

class TestAnalysis:
    def test_basic_analysis(self):
        cube = make_cube()
        report = analyze_body(cube)
        assert report.num_vertices == 8
        assert report.num_faces == 12
        assert report.surface_area is not None
        assert report.surface_area > 0
        assert report.min_edge_length is not None

    def test_overhang_detection(self):
        cube = make_cube()
        # Bottom faces point straight down (angle_from_z = 180°)
        # With 45° threshold: overhangs are faces with angle > 135°
        # The 2 bottom faces of the cube qualify
        report = analyze_body(cube, overhang_angle=45.0)
        assert report.overhang_faces == 2

    def test_no_thin_walls(self):
        cube = make_cube()
        report = analyze_body(cube, min_wall=0.1)
        # Cube edges are 2mm, so no thin walls at 0.1mm threshold
        assert report.thin_wall_faces == 0


# ---------------------------------------------------------------------------
# Physics engine tests
# ---------------------------------------------------------------------------

class TestPhysics:
    def test_material_lookup(self):
        from cad2scad.physics import PhysicsEngine, MATERIALS
        engine = PhysicsEngine("PLA")
        assert engine.material.name == "PLA"
        assert engine.material.density == 1.24
        assert engine.material.min_wall == 0.8

    def test_unknown_material_raises(self):
        from cad2scad.physics import PhysicsEngine
        with pytest.raises(ValueError, match="Unknown material"):
            PhysicsEngine("Unobtainium")

    def test_all_materials_exist(self):
        from cad2scad.physics import MATERIALS
        for name in ("PLA", "ABS", "PETG", "TPU", "Nylon", "ASA", "PC", "Resin"):
            assert name in MATERIALS

    def test_analyze_cube(self):
        from cad2scad.physics import PhysicsEngine
        cube = make_cube()
        engine = PhysicsEngine("PLA")
        rpt = engine.analyze(cube.vertices, cube.faces)

        # Basic geometry
        assert rpt.volume_mm3 > 0
        assert rpt.surface_area_mm2 > 0
        assert rpt.mass_grams > 0
        assert len(rpt.extents) == 3
        assert rpt.extents[0] == pytest.approx(2.0, abs=0.01)
        assert rpt.center_of_mass is not None
        assert rpt.inertia_tensor.shape == (3, 3)

    def test_physics_scores(self):
        from cad2scad.physics import PhysicsEngine
        cube = make_cube()
        engine = PhysicsEngine("PLA")
        rpt = engine.analyze(cube.vertices, cube.faces)

        assert 0 <= rpt.printability_score <= 100
        assert 0 <= rpt.stability_score <= 100
        assert 0 <= rpt.warp_risk <= 100
        assert rpt.structural_safety_factor > 0

    def test_physics_constraints_generated(self):
        from cad2scad.physics import PhysicsEngine
        cube = make_cube()
        engine = PhysicsEngine("PLA")
        rpt = engine.analyze(cube.vertices, cube.faces)

        pc = rpt.parameter_constraints
        assert "scale_x" in pc
        assert "scale_y" in pc
        assert "scale_z" in pc
        assert "wall_factor" in pc
        assert "shell_thickness" in pc
        # Each constraint is (min, max, reason)
        lo, hi, reason = pc["scale_x"]
        assert lo > 0
        assert hi > lo
        assert isinstance(reason, str)

    def test_format_report(self):
        from cad2scad.physics import PhysicsEngine
        cube = make_cube()
        engine = PhysicsEngine("PLA")
        rpt = engine.analyze(cube.vertices, cube.faces)
        text = engine.format_report(rpt)
        assert "PLA" in text
        assert "Mass:" in text
        assert "Printability:" in text

    def test_thin_wall_detection_with_thin_mesh(self):
        """Very thin triangle should trigger thin-wall detection."""
        from cad2scad.physics import PhysicsEngine
        # Triangle with 0.1mm short edge
        verts = np.array([[0, 0, 0], [0.1, 0, 0], [0, 10, 0], [0.1, 10, 0]], dtype=np.float64)
        faces = np.array([[0, 1, 2], [1, 3, 2]], dtype=np.int32)
        engine = PhysicsEngine("PLA")  # min_wall = 0.8
        rpt = engine.analyze(verts, faces, is_watertight=False)
        assert len(rpt.thin_regions) > 0

    def test_overhang_detection_downward_face(self):
        """Downward-facing face should trigger overhang for PLA (45 deg)."""
        from cad2scad.physics import PhysicsEngine
        cube = make_cube()
        engine = PhysicsEngine("PLA")
        rpt = engine.analyze(cube.vertices, cube.faces)
        # Bottom faces of cube point straight down -> overhangs
        assert len(rpt.overhang_regions) > 0

    def test_different_materials_different_constraints(self):
        from cad2scad.physics import PhysicsEngine
        cube = make_cube()
        pla = PhysicsEngine("PLA").analyze(cube.vertices, cube.faces)
        tpu = PhysicsEngine("TPU").analyze(cube.vertices, cube.faces)
        # TPU has higher min_wall (1.2 vs 0.8), so tighter scale constraints
        pla_lo = pla.parameter_constraints["scale_x"][0]
        tpu_lo = tpu.parameter_constraints["scale_x"][0]
        assert tpu_lo >= pla_lo  # TPU needs higher minimum scale


# ---------------------------------------------------------------------------
# Parameterizer tests
# ---------------------------------------------------------------------------

class TestParameterizer:
    def test_generate_parameters(self):
        from cad2scad.parameterizer import Parameterizer
        cube = make_cube()
        p = Parameterizer(material="PLA")
        params = p.generate_parameters(cube.vertices, cube.faces)
        assert len(params) > 10  # many parameters generated
        names = [pp.name for pp in params]
        assert "scale_x" in names
        assert "scale_y" in names
        assert "scale_z" in names
        assert "hollow" in names
        assert "shell_thickness" in names
        assert "material" in names

    def test_detect_features(self):
        from cad2scad.parameterizer import Parameterizer
        cube = make_cube()
        p = Parameterizer(material="PLA")
        feat = p.detect_features(cube.vertices, cube.faces)
        # Cube has no holes and several flat surfaces
        assert isinstance(feat.holes, list)
        assert len(feat.flats) > 0  # cube has 6 flat face groups
        assert feat.principal_axes is not None
        assert feat.principal_axes.shape == (3, 3)

    def test_scad_block_generation(self):
        from cad2scad.parameterizer import Parameterizer
        cube = make_cube()
        p = Parameterizer(material="PLA")
        params = p.generate_parameters(cube.vertices, cube.faces)
        block = p.generate_scad_block(params)
        # Should contain Customizer group markers
        assert "/* [Material] */" in block
        assert "/* [Dimensions] */" in block
        assert "/* [Structure] */" in block
        assert "/* [Physics (read-only)] */" in block
        # Should contain slider syntax
        assert "// [" in block

    def test_physics_reason_in_block(self):
        from cad2scad.parameterizer import Parameterizer
        cube = make_cube()
        p = Parameterizer(material="PLA")
        params = p.generate_parameters(cube.vertices, cube.faces)
        block = p.generate_scad_block(params)
        assert "constraint:" in block  # physics reasons included

    def test_customizer_param_scad_line(self):
        from cad2scad.parameterizer import CustomizerParam
        param = CustomizerParam(
            name="test_param", group="Test", value=5.0,
            min_val=1.0, max_val=10.0, step=0.5,
            description="A test", unit="mm",
        )
        line = param.scad_line()
        assert "test_param = 5.0" in line
        assert "[1.0:0.5:10.0]" in line
        assert "(mm)" in line

    def test_customizer_dropdown_scad_line(self):
        from cad2scad.parameterizer import CustomizerDropdown
        dd = CustomizerDropdown(
            name="choice", group="Options",
            value="A", options=["A", "B", "C"],
            description="Pick one",
        )
        line = dd.scad_line()
        assert 'choice = "A"' in line
        assert '"A", "B", "C"' in line

    def test_hole_detection_on_mesh_with_holes(self):
        """Ring mesh should have detected holes."""
        from cad2scad.parameterizer import Parameterizer
        # Create a simple ring (torus cross-section approximation)
        # Outer circle of 8 verts at r=10, inner circle at r=5
        n = 16
        angles = np.linspace(0, 2 * np.pi, n, endpoint=False)
        outer = np.column_stack([10 * np.cos(angles), 10 * np.sin(angles), np.zeros(n)])
        inner = np.column_stack([5 * np.cos(angles), 5 * np.sin(angles), np.zeros(n)])
        outer_top = outer.copy(); outer_top[:, 2] = 2.0
        inner_top = inner.copy(); inner_top[:, 2] = 2.0
        verts = np.vstack([outer, inner, outer_top, inner_top])

        faces = []
        for i in range(n):
            j = (i + 1) % n
            # Bottom face (between outer and inner)
            faces.append([i, j, n + j])
            faces.append([i, n + j, n + i])
            # Top face
            faces.append([2*n + i, 2*n + n + i, 2*n + n + j])
            faces.append([2*n + i, 2*n + n + j, 2*n + j])
            # Outer wall
            faces.append([i, 2*n + i, 2*n + j])
            faces.append([i, 2*n + j, j])
            # Inner wall
            faces.append([n + i, n + j, 2*n + n + j])
            faces.append([n + i, 2*n + n + j, 2*n + n + i])

        verts = np.array(verts, dtype=np.float64)
        faces = np.array(faces, dtype=np.int32)

        p = Parameterizer(material="PLA")
        feat = p.detect_features(verts, faces)
        # Watertight ring mesh has no boundary edges -> no holes detected
        # (holes are detected via boundary edges, not topology)
        # This validates the code path runs without error
        assert isinstance(feat.holes, list)


# ---------------------------------------------------------------------------
# Parameterized writer integration test
# ---------------------------------------------------------------------------

class TestParameterizedWriter:
    def test_parameterized_output(self):
        """Ensure parameterized mode generates Customizer-compatible .scad."""
        bundle = make_bundle()
        writer = ScadWriter(WriterOptions(
            parameterize=True,
            material="PLA",
            precision=4,
            include_metadata=True,
        ))
        output = writer.to_string(bundle)

        # Should have Customizer group markers
        assert "/* [Material] */" in output
        assert "/* [Dimensions] */" in output
        assert "/* [Structure] */" in output
        assert "/* [Physics (read-only)] */" in output

        # Should have physics summary
        assert "Physics Summary" in output
        assert "Mass:" in output
        assert "COM:" in output

        # Should have base module + wrapper module
        assert "module test_cube_base()" in output
        assert "module test_cube()" in output

        # Should have scale/translate/rotate in wrapper
        assert "scale([_x_eff, _y_eff, _z_eff])" in output
        assert "translate([offset_x, offset_y, offset_z])" in output
        assert "rotate([rotate_x, rotate_y, rotate_z])" in output

        # Should have hollow logic
        assert "if (hollow == 1)" in output
        assert "difference()" in output
        assert "shell_thickness" in output

        # Should have assembly at end
        assert "test_cube();" in output

    def test_standard_mode_unchanged(self):
        """Standard mode (no parameterize) should not change."""
        bundle = make_bundle()
        writer = ScadWriter(WriterOptions(precision=4))
        output = writer.to_string(bundle)
        assert "module test_cube()" in output
        assert "/* [Material] */" not in output  # no customizer
        assert "Physics Summary" not in output
