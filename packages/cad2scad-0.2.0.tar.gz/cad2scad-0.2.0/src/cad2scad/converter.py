"""
cad2scad.converter — High-level API that ties loader + optimizer + writer.

Usage::

    # One-liner
    from cad2scad import convert
    convert("model.3mf", "model.scad")

    # Full control
    from cad2scad import Converter
    c = Converter(decimate=0.5, center=True, split_bodies=True)
    c.load("model.3mf")
    print(c.summary())
    c.save("model.scad")
"""

from __future__ import annotations

import logging
import pathlib
from typing import Optional

from cad2scad.loader import MeshBundle, load_mesh
from cad2scad.optimizer import MeshOptimizer, OptimizeOptions
from cad2scad.scad_writer import ScadWriter, WriterOptions

logger = logging.getLogger(__name__)


class Converter:
    """
    Full pipeline: load → optimize → write .scad.

    Parameters
    ----------
    weld_tolerance : float
        Merge vertices within this distance (mm). Default 1e-6.
    decimate : float or None
        Target face ratio (0.0–1.0). None disables decimation.
    decimate_target : int or None
        Exact target face count. Overrides decimate ratio.
    center : bool
        Move mesh center to origin.
    split_bodies : bool
        Split disconnected components into separate modules.
    round_precision : int or None
        Round vertex coordinates to N decimal places.
    precision : int
        Decimal places in .scad output. Default 6.
    compact : bool
        Use compact array formatting (smaller files, less readable).
    include_colors : bool
        Preserve color data in .scad output.
    module_prefix : str
        Prefix for generated module names.
    parameterize : bool
        Generate OpenSCAD Customizer parameters with physics constraints.
    material : str
        Material for physics analysis (PLA, ABS, PETG, TPU, Nylon, ASA, PC, Resin).
    """

    def __init__(
        self,
        weld_tolerance: float = 1e-6,
        decimate: Optional[float] = None,
        decimate_target: Optional[int] = None,
        center: bool = False,
        split_bodies: bool = False,
        round_precision: Optional[int] = None,
        precision: int = 6,
        compact: bool = False,
        include_colors: bool = True,
        module_prefix: str = "",
        parameterize: bool = False,
        material: str = "PLA",
    ):
        self._opt_options = OptimizeOptions(
            weld_tolerance=weld_tolerance,
            decimate_ratio=decimate,
            decimate_target=decimate_target,
            center=center,
            split_bodies=split_bodies,
            round_precision=round_precision,
        )
        self._writer_options = WriterOptions(
            precision=precision,
            compact_arrays=compact,
            include_colors=include_colors,
            module_prefix=module_prefix,
            parameterize=parameterize,
            material=material,
        )
        self._optimizer = MeshOptimizer(self._opt_options)
        self._writer = ScadWriter(self._writer_options)

        self._raw_bundle: Optional[MeshBundle] = None
        self._optimized_bundle: Optional[MeshBundle] = None

    def load(self, path: str | pathlib.Path) -> "Converter":
        """Load a CAD file. Returns self for chaining."""
        self._raw_bundle = load_mesh(path)
        self._optimized_bundle = self._optimizer.optimize(self._raw_bundle)
        return self

    @property
    def bundle(self) -> MeshBundle:
        """The optimized MeshBundle (after load)."""
        if self._optimized_bundle is None:
            raise RuntimeError("No file loaded. Call .load() first.")
        return self._optimized_bundle

    @property
    def raw_bundle(self) -> MeshBundle:
        """The raw MeshBundle before optimization."""
        if self._raw_bundle is None:
            raise RuntimeError("No file loaded. Call .load() first.")
        return self._raw_bundle

    def save(self, output: str | pathlib.Path) -> None:
        """Write optimized mesh as .scad file."""
        self._writer.write(self.bundle, output)

    def to_string(self) -> str:
        """Return .scad content as a string."""
        return self._writer.to_string(self.bundle)

    def summary(self) -> str:
        """Return a human-readable summary of the loaded/optimized mesh."""
        raw = self.raw_bundle
        opt = self.bundle
        lines = [
            f"Source:  {raw.source_path}",
            f"Format:  {raw.source_format}",
            f"",
            f"{'':>20s}  {'Raw':>10s}  {'Optimized':>10s}",
            f"{'Bodies':<20s}  {len(raw):>10d}  {len(opt):>10d}",
            f"{'Vertices':<20s}  {raw.total_vertices:>10d}  {opt.total_vertices:>10d}",
            f"{'Faces':<20s}  {raw.total_faces:>10d}  {opt.total_faces:>10d}",
            f"",
        ]
        for body in opt.bodies:
            lo, hi = body.bounds
            ext = body.extents
            lines.append(
                f"  [{body.name}]  "
                f"{body.num_vertices} verts, {body.num_faces} faces, "
                f"size {ext[0]:.1f} x {ext[1]:.1f} x {ext[2]:.1f} mm"
            )
            if body.metadata.get("watertight"):
                lines.append(f"    watertight, volume={body.metadata.get('volume', '?'):.1f} mm³")

        return "\n".join(lines)


def convert(
    input_path: str | pathlib.Path,
    output_path: str | pathlib.Path,
    *,
    decimate: Optional[float] = None,
    center: bool = False,
    split_bodies: bool = False,
    precision: int = 6,
    compact: bool = False,
    parameterize: bool = False,
    material: str = "PLA",
    **kwargs,
) -> Converter:
    """
    One-shot convert: load file -> optimize -> write .scad.

    Returns the Converter instance for further inspection.

    Examples::

        convert("model.3mf", "model.scad")
        convert("model.stl", "model.scad", parameterize=True, material="PETG")
    """
    c = Converter(
        decimate=decimate,
        center=center,
        split_bodies=split_bodies,
        precision=precision,
        compact=compact,
        parameterize=parameterize,
        material=material,
        **kwargs,
    )
    c.load(input_path)
    c.save(output_path)
    return c
