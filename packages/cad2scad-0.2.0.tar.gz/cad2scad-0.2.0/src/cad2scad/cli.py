"""
cad2scad.cli — Command-line interface.

Usage::

    # Basic conversion
    cad2scad model.3mf -o model.scad

    # With decimation and centering
    cad2scad model.stl -o model.scad --decimate 0.5 --center

    # Analyze without converting
    cad2scad model.3mf --analyze

    # Batch conversion
    cad2scad *.stl -o output_dir/

    # Split multi-body into separate modules
    cad2scad assembly.3mf -o assembly.scad --split
"""

from __future__ import annotations

import argparse
import logging
import pathlib
import sys
from typing import Sequence


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="cad2scad",
        description="Convert CAD/mesh files to OpenSCAD .scad",
        epilog="Supports: STL, 3MF, OBJ, PLY, OFF, GLTF/GLB, DAE, STEP (needs cadquery)",
    )

    p.add_argument(
        "input",
        nargs="+",
        help="Input file(s) to convert",
    )
    p.add_argument(
        "-o", "--output",
        help="Output .scad file or directory. Default: input name with .scad extension",
    )

    # Optimization
    opt = p.add_argument_group("optimization")
    opt.add_argument(
        "--decimate", type=float, default=None, metavar="RATIO",
        help="Decimate faces to RATIO (0.0–1.0). E.g. 0.5 = halve triangle count",
    )
    opt.add_argument(
        "--decimate-target", type=int, default=None, metavar="N",
        help="Decimate to exactly N faces",
    )
    opt.add_argument(
        "--center", action="store_true",
        help="Move bounding box center to origin",
    )
    opt.add_argument(
        "--split", action="store_true",
        help="Split disconnected components into separate modules",
    )
    opt.add_argument(
        "--weld", type=float, default=1e-6, metavar="TOL",
        help="Vertex weld tolerance in mm (default: 1e-6)",
    )
    opt.add_argument(
        "--round", type=int, default=None, metavar="N",
        help="Round coordinates to N decimal places",
    )

    # Output format
    fmt = p.add_argument_group("formatting")
    fmt.add_argument(
        "--precision", type=int, default=6,
        help="Decimal places in .scad output (default: 6)",
    )
    fmt.add_argument(
        "--compact", action="store_true",
        help="Compact array formatting (smaller files)",
    )
    fmt.add_argument(
        "--no-color", action="store_true",
        help="Strip color data from output",
    )
    fmt.add_argument(
        "--prefix", default="", metavar="STR",
        help="Module name prefix (e.g. 'imported_')",
    )

    # Analysis
    ana = p.add_argument_group("analysis")
    ana.add_argument(
        "--analyze", action="store_true",
        help="Print analysis report (no conversion)",
    )
    ana.add_argument(
        "--min-wall", type=float, default=0.8,
        help="Min wall thickness for analysis (mm, default: 0.8)",
    )
    ana.add_argument(
        "--overhang", type=float, default=45.0,
        help="Overhang angle threshold (degrees, default: 45)",
    )

    # Physics & Customizer
    phys = p.add_argument_group("physics / customizer")
    phys.add_argument(
        "--parameterize", action="store_true",
        help="Generate OpenSCAD Customizer parameters with physics constraints",
    )
    phys.add_argument(
        "--material", default="PLA", metavar="MAT",
        help="Material for physics analysis (PLA, ABS, PETG, TPU, Nylon, ASA, PC, Resin). Default: PLA",
    )
    phys.add_argument(
        "--physics", action="store_true",
        help="Include full physics report in --analyze output",
    )

    # General
    p.add_argument(
        "-v", "--verbose", action="count", default=0,
        help="Increase verbosity (-v info, -vv debug)",
    )
    p.add_argument(
        "--version", action="version",
        version="cad2scad 0.1.0",
    )

    return p


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entry point."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Setup logging
    level = logging.WARNING
    if args.verbose >= 2:
        level = logging.DEBUG
    elif args.verbose >= 1:
        level = logging.INFO

    logging.basicConfig(
        level=level,
        format="%(levelname)s: %(message)s",
    )

    # Process each input file
    input_paths = []
    for pattern in args.input:
        p = pathlib.Path(pattern)
        if "*" in pattern or "?" in pattern:
            input_paths.extend(p.parent.glob(p.name))
        else:
            input_paths.append(p)

    if not input_paths:
        print("Error: No input files found", file=sys.stderr)
        return 1

    # Determine if output is a directory (for batch) or single file
    output_is_dir = (
        args.output
        and (len(input_paths) > 1 or pathlib.Path(args.output).is_dir())
    )

    for input_path in input_paths:
        if not input_path.exists():
            print(f"Error: File not found: {input_path}", file=sys.stderr)
            continue

        try:
            if args.analyze:
                _run_analysis(input_path, args)
            else:
                _run_conversion(input_path, args, output_is_dir)
        except Exception as e:
            print(f"Error processing {input_path}: {e}", file=sys.stderr)
            if args.verbose >= 2:
                import traceback
                traceback.print_exc()
            return 1

    return 0


def _run_conversion(
    input_path: pathlib.Path,
    args: argparse.Namespace,
    output_is_dir: bool,
) -> None:
    """Convert a single file."""
    from cad2scad.converter import Converter

    # Determine output path
    if args.output:
        if output_is_dir:
            out_dir = pathlib.Path(args.output)
            out_dir.mkdir(parents=True, exist_ok=True)
            output_path = out_dir / input_path.with_suffix(".scad").name
        else:
            output_path = pathlib.Path(args.output)
    else:
        output_path = input_path.with_suffix(".scad")

    converter = Converter(
        weld_tolerance=args.weld,
        decimate=args.decimate,
        decimate_target=args.decimate_target,
        center=args.center,
        split_bodies=args.split,
        round_precision=getattr(args, "round", None),
        precision=args.precision,
        compact=args.compact,
        include_colors=not args.no_color,
        module_prefix=args.prefix,
        parameterize=args.parameterize,
        material=args.material,
    )

    converter.load(input_path)
    converter.save(output_path)

    # Print summary
    b = converter.bundle
    mode = "parameterized" if args.parameterize else "standard"
    print(f"Done: {input_path.name} -> {output_path.name} [{mode}]")
    print(f"  {len(b)} body(ies), {b.total_vertices} vertices, {b.total_faces} faces")
    if args.parameterize:
        print(f"  Material: {args.material} | Customizer sliders generated")
    for body in b.bodies:
        ext = body.extents
        print(f"  [{body.name}] {ext[0]:.1f} x {ext[1]:.1f} x {ext[2]:.1f} mm")


def _run_analysis(input_path: pathlib.Path, args: argparse.Namespace) -> None:
    """Analyze a file and print report."""
    from cad2scad.loader import load_mesh
    from cad2scad.analysis import analyze_bundle

    bundle = load_mesh(input_path)
    reports = analyze_bundle(bundle, args.min_wall, args.overhang)

    print(f"\n{'=' * 50}")
    print(f"Analysis: {input_path.name}")
    print(f"{'=' * 50}")

    for r in reports:
        print(f"\n--- {r.name} ---")
        print(f"  Vertices:  {r.num_vertices:,}")
        print(f"  Faces:     {r.num_faces:,}")
        print(f"  Bounds:    [{r.bounds_min[0]:.2f}, {r.bounds_min[1]:.2f}, "
              f"{r.bounds_min[2]:.2f}] -> [{r.bounds_max[0]:.2f}, "
              f"{r.bounds_max[1]:.2f}, {r.bounds_max[2]:.2f}]")
        print(f"  Size:      {r.extents[0]:.2f} x {r.extents[1]:.2f} "
              f"x {r.extents[2]:.2f} mm")

        if r.is_watertight is not None:
            print(f"  Watertight: {'yes' if r.is_watertight else 'NO'}")
        if r.volume is not None:
            print(f"  Volume:    {r.volume:.2f} mm3")
        if r.surface_area is not None:
            print(f"  Surface:   {r.surface_area:.2f} mm2")

        if r.min_edge_length is not None:
            print(f"  Edge len:  {r.min_edge_length:.3f} - "
                  f"{r.max_edge_length:.3f} mm (mean {r.mean_edge_length:.3f})")

        if r.thin_wall_faces > 0:
            pct = 100 * r.thin_wall_faces / r.num_faces
            print(f"  ! Thin walls: {r.thin_wall_faces} faces "
                  f"({pct:.1f}%) with edge < {args.min_wall}mm")

        if r.overhang_faces > 0:
            pct = 100 * r.overhang_ratio
            print(f"  ! Overhangs:  {r.overhang_faces} faces "
                  f"({pct:.1f}%) steeper than {args.overhang} deg")

    # Physics report if requested
    if getattr(args, "physics", False) or getattr(args, "parameterize", False):
        from cad2scad.physics import PhysicsEngine
        from cad2scad.parameterizer import Parameterizer

        mat_name = getattr(args, "material", "PLA")
        engine = PhysicsEngine(mat_name)
        param = Parameterizer(physics=engine, material=mat_name)

        for body in bundle.bodies:
            print(f"\n--- Physics: {body.name} ({mat_name}) ---")
            rpt = engine.analyze(body.vertices, body.faces)
            print(engine.format_report(rpt))

            feat = param.detect_features(body.vertices, body.faces)
            print(f"\nDetected features:")
            print(f"  Holes: {len(feat.holes)}")
            for h in feat.holes:
                print(f"    dia={h.diameter:.2f}mm at "
                      f"({h.center[0]:.1f}, {h.center[1]:.1f}, {h.center[2]:.1f})")
            print(f"  Flat surfaces: {len(feat.flats)}")
            print(f"  Symmetry axes: {[s.axis for s in feat.symmetry]}")

    print()


if __name__ == "__main__":
    sys.exit(main())
