"""
cad2scad.physics — Material-aware physics engine for mesh analysis.

Provides:
  - Material properties database (PLA, ABS, PETG, TPU, Nylon, ASA, PC, Resin)
  - Center-of-mass and inertia tensor computation
  - Thin-wall detection with material constraints
  - Stress-concentration estimation via dihedral-angle analysis
  - Overhang detection using material-specific limits
  - Stability scoring (tip-over resistance on build plate)
  - Warp-risk estimation from footprint × shrinkage
  - Structural safety factor and max-load estimation
  - Printability scoring (combined metric)
  - Physics-based min/max constraints for Customizer parameters
"""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

# ---------------------------------------------------------------------------
# Material database
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Material:
    """Mechanical and thermal properties of a 3D-printing material."""

    name: str
    density: float              # g/cm^3
    tensile_strength: float     # MPa
    yield_strength: float       # MPa
    elastic_modulus: float      # MPa (Young's modulus)
    poisson_ratio: float
    thermal_expansion: float    # um/(m*degC)
    glass_transition: float     # degC
    print_temp_range: Tuple[float, float]  # degC
    min_wall: float             # mm  (practical FDM minimum)
    max_bridge: float           # mm  (unsupported horizontal span)
    max_overhang: float         # degrees from vertical
    layer_adhesion: float       # 0-1  (Z-strength / XY-strength)
    shrinkage: float            # linear %
    color: Tuple[float, float, float]  # RGB 0-1


MATERIALS: Dict[str, Material] = {
    "PLA": Material(
        name="PLA", density=1.24,
        tensile_strength=50.0, yield_strength=35.0,
        elastic_modulus=3500.0, poisson_ratio=0.36,
        thermal_expansion=68.0, glass_transition=60.0,
        print_temp_range=(190.0, 220.0),
        min_wall=0.8, max_bridge=10.0, max_overhang=45.0,
        layer_adhesion=0.70, shrinkage=0.3,
        color=(0.9, 0.9, 0.85),
    ),
    "ABS": Material(
        name="ABS", density=1.04,
        tensile_strength=40.0, yield_strength=30.0,
        elastic_modulus=2300.0, poisson_ratio=0.35,
        thermal_expansion=90.0, glass_transition=105.0,
        print_temp_range=(230.0, 260.0),
        min_wall=1.0, max_bridge=8.0, max_overhang=40.0,
        layer_adhesion=0.60, shrinkage=0.7,
        color=(0.95, 0.95, 0.90),
    ),
    "PETG": Material(
        name="PETG", density=1.27,
        tensile_strength=50.0, yield_strength=40.0,
        elastic_modulus=2100.0, poisson_ratio=0.38,
        thermal_expansion=60.0, glass_transition=80.0,
        print_temp_range=(220.0, 250.0),
        min_wall=0.8, max_bridge=8.0, max_overhang=40.0,
        layer_adhesion=0.75, shrinkage=0.4,
        color=(0.85, 0.92, 0.95),
    ),
    "TPU": Material(
        name="TPU", density=1.21,
        tensile_strength=30.0, yield_strength=10.0,
        elastic_modulus=26.0, poisson_ratio=0.48,
        thermal_expansion=150.0, glass_transition=-40.0,
        print_temp_range=(210.0, 230.0),
        min_wall=1.2, max_bridge=5.0, max_overhang=35.0,
        layer_adhesion=0.85, shrinkage=0.5,
        color=(0.70, 0.70, 0.75),
    ),
    "Nylon": Material(
        name="Nylon", density=1.14,
        tensile_strength=70.0, yield_strength=45.0,
        elastic_modulus=2700.0, poisson_ratio=0.40,
        thermal_expansion=80.0, glass_transition=70.0,
        print_temp_range=(240.0, 270.0),
        min_wall=1.0, max_bridge=6.0, max_overhang=35.0,
        layer_adhesion=0.65, shrinkage=1.5,
        color=(0.95, 0.95, 0.92),
    ),
    "ASA": Material(
        name="ASA", density=1.07,
        tensile_strength=45.0, yield_strength=32.0,
        elastic_modulus=2100.0, poisson_ratio=0.35,
        thermal_expansion=95.0, glass_transition=100.0,
        print_temp_range=(235.0, 260.0),
        min_wall=1.0, max_bridge=8.0, max_overhang=40.0,
        layer_adhesion=0.62, shrinkage=0.6,
        color=(0.90, 0.88, 0.80),
    ),
    "PC": Material(
        name="PC", density=1.20,
        tensile_strength=65.0, yield_strength=55.0,
        elastic_modulus=2400.0, poisson_ratio=0.37,
        thermal_expansion=65.0, glass_transition=147.0,
        print_temp_range=(270.0, 310.0),
        min_wall=1.0, max_bridge=6.0, max_overhang=35.0,
        layer_adhesion=0.55, shrinkage=0.7,
        color=(0.92, 0.92, 0.95),
    ),
    "Resin": Material(
        name="Resin", density=1.12,
        tensile_strength=45.0, yield_strength=25.0,
        elastic_modulus=2800.0, poisson_ratio=0.38,
        thermal_expansion=100.0, glass_transition=80.0,
        print_temp_range=(20.0, 35.0),
        min_wall=0.3, max_bridge=50.0, max_overhang=80.0,
        layer_adhesion=0.95, shrinkage=0.5,
        color=(0.80, 0.80, 0.80),
    ),
}


# ---------------------------------------------------------------------------
# Report data classes
# ---------------------------------------------------------------------------

@dataclass
class StressRegion:
    """A mesh region with notable stress concentration."""
    face_indices: np.ndarray
    centroid: np.ndarray
    estimated_stress: float     # MPa (rough)
    description: str


@dataclass
class ThinRegion:
    """A mesh region below minimum wall thickness."""
    face_indices: np.ndarray
    centroid: np.ndarray
    thickness: float            # mm (measured)
    required: float             # mm (material limit)


@dataclass
class OverhangRegion:
    """A mesh region exceeding material overhang limit."""
    face_indices: np.ndarray
    centroid: np.ndarray
    angle: float                # degrees from build plate normal
    max_allowed: float          # degrees


@dataclass
class PhysicsReport:
    """Complete physics analysis of a mesh body."""

    material: Material

    # Mass and geometry
    mass_grams: float
    volume_mm3: float
    surface_area_mm2: float
    center_of_mass: np.ndarray          # [x, y, z]
    inertia_tensor: np.ndarray          # 3x3
    bounding_box: Tuple[np.ndarray, np.ndarray]
    extents: np.ndarray                 # [dx, dy, dz]

    # Structural
    thin_regions: List[ThinRegion] = field(default_factory=list)
    stress_regions: List[StressRegion] = field(default_factory=list)
    overhang_regions: List[OverhangRegion] = field(default_factory=list)
    structural_safety_factor: float = 1.0
    max_load_newtons: float = 0.0

    # Printability
    printability_score: float = 0.0     # 0-100
    stability_score: float = 0.0        # 0-100
    warp_risk: float = 0.0              # 0-100
    support_volume_pct: float = 0.0     # %
    recommended_infill_pct: float = 20.0
    recommended_orientation: Optional[np.ndarray] = None

    # Constraints  name -> (min, max, reason)
    parameter_constraints: Dict[str, Tuple[float, float, str]] = field(
        default_factory=dict
    )


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class PhysicsEngine:
    """Material-aware mesh physics analysis engine.

    Usage::

        engine = PhysicsEngine("PLA")
        report = engine.analyze(vertices, faces)
        print(engine.format_report(report))
    """

    def __init__(self, material: str = "PLA"):
        if material not in MATERIALS:
            raise ValueError(
                f"Unknown material '{material}'. "
                f"Available: {', '.join(MATERIALS)}"
            )
        self.material = MATERIALS[material]

    # ── public API ─────────────────────────────────────────────────────────

    def analyze(
        self,
        vertices: np.ndarray,
        faces: np.ndarray,
        *,
        is_watertight: bool = True,
    ) -> PhysicsReport:
        """Run full physics analysis on a mesh."""
        verts = np.asarray(vertices, dtype=np.float64)
        tris = np.asarray(faces, dtype=np.int32)

        bb_min = verts.min(axis=0)
        bb_max = verts.max(axis=0)
        extents = bb_max - bb_min

        sa = self._surface_area(verts, tris)
        vol = abs(self._signed_volume(verts, tris)) if is_watertight else 0.0
        mass = self._mass(vol)
        com = self._center_of_mass(verts, tris) if vol > 0 else verts.mean(axis=0)
        inertia = self._inertia_tensor(verts, tris, com) if vol > 0 else np.zeros((3, 3))

        normals = self._face_normals(verts, tris)

        thin = self._detect_thin_walls(verts, tris)
        stress = self._estimate_stress_regions(verts, tris, normals, mass)
        overhang = self._detect_overhangs(verts, tris, normals)

        stability = self._stability_score(com, verts)
        warp = self._warp_risk(extents)
        support_pct = self._support_estimate(overhang, len(tris))
        safety, max_load = self._structural_estimate(extents, vol)
        printability = self._printability_score(thin, overhang, warp, stability)
        infill = self._recommended_infill(extents, vol)
        orientation = self._optimal_orientation(extents)
        constraints = self._compute_constraints(extents, vol, thin)

        return PhysicsReport(
            material=self.material,
            mass_grams=mass,
            volume_mm3=vol,
            surface_area_mm2=sa,
            center_of_mass=com,
            inertia_tensor=inertia,
            bounding_box=(bb_min, bb_max),
            extents=extents,
            thin_regions=thin,
            stress_regions=stress,
            overhang_regions=overhang,
            structural_safety_factor=safety,
            max_load_newtons=max_load,
            printability_score=printability,
            stability_score=stability,
            warp_risk=warp,
            support_volume_pct=support_pct,
            recommended_infill_pct=infill,
            recommended_orientation=orientation,
            parameter_constraints=constraints,
        )

    # ── geometry primitives ────────────────────────────────────────────────

    @staticmethod
    def _face_normals(verts: np.ndarray, tris: np.ndarray) -> np.ndarray:
        v0, v1, v2 = verts[tris[:, 0]], verts[tris[:, 1]], verts[tris[:, 2]]
        n = np.cross(v1 - v0, v2 - v0)
        norms = np.linalg.norm(n, axis=1, keepdims=True)
        norms = np.where(norms < 1e-12, 1.0, norms)
        return n / norms

    @staticmethod
    def _face_areas(verts: np.ndarray, tris: np.ndarray) -> np.ndarray:
        v0, v1, v2 = verts[tris[:, 0]], verts[tris[:, 1]], verts[tris[:, 2]]
        return 0.5 * np.linalg.norm(np.cross(v1 - v0, v2 - v0), axis=1)

    @staticmethod
    def _face_centroids(verts: np.ndarray, tris: np.ndarray) -> np.ndarray:
        return (verts[tris[:, 0]] + verts[tris[:, 1]] + verts[tris[:, 2]]) / 3.0

    @staticmethod
    def _surface_area(verts: np.ndarray, tris: np.ndarray) -> float:
        v0, v1, v2 = verts[tris[:, 0]], verts[tris[:, 1]], verts[tris[:, 2]]
        return float(0.5 * np.sum(np.linalg.norm(np.cross(v1 - v0, v2 - v0), axis=1)))

    @staticmethod
    def _signed_volume(verts: np.ndarray, tris: np.ndarray) -> float:
        """Signed volume via divergence theorem."""
        v0, v1, v2 = verts[tris[:, 0]], verts[tris[:, 1]], verts[tris[:, 2]]
        return float(np.sum(
            v0[:, 0] * (v1[:, 1] * v2[:, 2] - v1[:, 2] * v2[:, 1])
            + v0[:, 1] * (v1[:, 2] * v2[:, 0] - v1[:, 0] * v2[:, 2])
            + v0[:, 2] * (v1[:, 0] * v2[:, 1] - v1[:, 1] * v2[:, 0])
        ) / 6.0)

    def _mass(self, volume_mm3: float) -> float:
        """Mass in grams from volume in mm^3."""
        return (volume_mm3 / 1000.0) * self.material.density

    @staticmethod
    def _center_of_mass(verts: np.ndarray, tris: np.ndarray) -> np.ndarray:
        """Center of mass assuming solid uniform density."""
        v0, v1, v2 = verts[tris[:, 0]], verts[tris[:, 1]], verts[tris[:, 2]]
        tet_vols = np.einsum("ij,ij->i", v0, np.cross(v1, v2)) / 6.0
        total = np.sum(tet_vols)
        if abs(total) < 1e-12:
            return verts.mean(axis=0)
        centroids = (v0 + v1 + v2) / 4.0
        return np.sum(centroids * tet_vols[:, np.newaxis], axis=0) / total

    def _inertia_tensor(
        self, verts: np.ndarray, tris: np.ndarray, com: np.ndarray
    ) -> np.ndarray:
        """Approximate inertia tensor about centre of mass."""
        areas = self._face_areas(verts, tris)
        pts = self._face_centroids(verts, tris) - com
        if len(pts) == 0:
            return np.zeros((3, 3))
        w = areas
        tw = w.sum()
        if tw < 1e-12:
            return np.zeros((3, 3))
        x, y, z = pts[:, 0], pts[:, 1], pts[:, 2]
        Ixx = np.sum(w * (y**2 + z**2))
        Iyy = np.sum(w * (x**2 + z**2))
        Izz = np.sum(w * (x**2 + y**2))
        Ixy = -np.sum(w * x * y)
        Ixz = -np.sum(w * x * z)
        Iyz = -np.sum(w * y * z)
        return np.array([[Ixx, Ixy, Ixz],
                         [Ixy, Iyy, Iyz],
                         [Ixz, Iyz, Izz]]) / tw

    # ── thin-wall detection ────────────────────────────────────────────────

    def _detect_thin_walls(
        self, verts: np.ndarray, tris: np.ndarray
    ) -> List[ThinRegion]:
        """Faces whose shortest edge is below material min_wall."""
        min_wall = self.material.min_wall
        edges = np.vstack([tris[:, [0, 1]], tris[:, [1, 2]], tris[:, [2, 0]]])
        lens = np.linalg.norm(verts[edges[:, 1]] - verts[edges[:, 0]], axis=1)
        per_face = lens.reshape(3, -1).T  # (n_faces, 3)
        shortest = per_face.min(axis=1)
        mask = shortest < min_wall
        if not np.any(mask):
            return []
        idx = np.where(mask)[0]
        centroids = self._face_centroids(verts, tris)
        clusters = self._cluster(centroids[idx], idx, min_wall * 5)
        return [
            ThinRegion(
                face_indices=ci,
                centroid=cc.mean(axis=0),
                thickness=float(shortest[ci].mean()),
                required=min_wall,
            )
            for ci, cc in clusters
        ]

    # ── stress estimation ──────────────────────────────────────────────────

    def _estimate_stress_regions(
        self,
        verts: np.ndarray,
        tris: np.ndarray,
        normals: np.ndarray,
        mass_grams: float,
    ) -> List[StressRegion]:
        """Stress concentration via dihedral-angle analysis."""
        if len(tris) < 4:
            return []

        edge_to_faces: Dict[Tuple[int, int], List[int]] = defaultdict(list)
        for fi, face in enumerate(tris):
            for e in ((face[0], face[1]), (face[1], face[2]), (face[2], face[0])):
                edge_to_faces[(min(e), max(e))].append(fi)

        dihedral_sum = np.zeros(len(tris))
        dihedral_cnt = np.zeros(len(tris))
        for (_, _), fids in edge_to_faces.items():
            if len(fids) == 2:
                cos_a = np.clip(np.dot(normals[fids[0]], normals[fids[1]]), -1, 1)
                angle = np.degrees(np.arccos(cos_a))
                for fi in fids:
                    dihedral_sum[fi] += angle
                    dihedral_cnt[fi] += 1

        valid = dihedral_cnt > 0
        avg = np.zeros(len(tris))
        avg[valid] = dihedral_sum[valid] / dihedral_cnt[valid]

        sharp_mask = (avg < 120.0) & valid
        if not np.any(sharp_mask):
            return []

        idx = np.where(sharp_mask)[0]
        centroids = self._face_centroids(verts, tris)
        clusters = self._cluster(centroids[idx], idx, 2.0)
        weight_n = mass_grams * 0.00981  # N
        areas = self._face_areas(verts, tris)

        regions: List[StressRegion] = []
        for ci, cc in clusters:
            avg_a = float(avg[ci].mean())
            k_t = max(1.0, (180 - avg_a) / 30.0)
            area = max(float(areas[ci].sum()), 1e-6)
            sigma = k_t * weight_n / area
            regions.append(StressRegion(
                face_indices=ci,
                centroid=cc.mean(axis=0),
                estimated_stress=sigma,
                description=(
                    f"Sharp edges (avg dihedral {avg_a:.0f} deg, "
                    f"K_t={k_t:.1f})"
                ),
            ))
        return regions

    # ── overhang detection ─────────────────────────────────────────────────

    def _detect_overhangs(
        self, verts: np.ndarray, tris: np.ndarray, normals: np.ndarray
    ) -> List[OverhangRegion]:
        """Faces exceeding material overhang limit from +Z."""
        max_oh = self.material.max_overhang
        angle_z = np.degrees(np.arccos(np.clip(normals[:, 2], -1, 1)))
        mask = angle_z > (90.0 + max_oh)
        if not np.any(mask):
            return []
        idx = np.where(mask)[0]
        centroids = self._face_centroids(verts, tris)
        clusters = self._cluster(centroids[idx], idx, 5.0)
        return [
            OverhangRegion(
                face_indices=ci,
                centroid=cc.mean(axis=0),
                angle=float(angle_z[ci].mean()),
                max_allowed=90.0 + max_oh,
            )
            for ci, cc in clusters
        ]

    # ── scoring helpers ────────────────────────────────────────────────────

    def _stability_score(self, com: np.ndarray, verts: np.ndarray) -> float:
        """0-100: tip-over resistance on build plate."""
        bb_min, bb_max = verts.min(axis=0), verts.max(axis=0)
        ext = bb_max - bb_min
        h = max(ext[2], 1e-6)
        height_ratio = (com[2] - bb_min[2]) / h
        base_ratio = min(ext[0], ext[1]) / h
        return float(np.clip(50 * (1 - height_ratio) + 50 * min(base_ratio, 1.0), 0, 100))

    def _warp_risk(self, ext: np.ndarray) -> float:
        """0-100: warping risk based on footprint x material shrinkage."""
        footprint = ext[0] * ext[1]
        risk = (
            (footprint / 10000.0)
            * (self.material.shrinkage + self.material.thermal_expansion / 100)
            * 50
        )
        return float(np.clip(risk, 0, 100))

    @staticmethod
    def _support_estimate(overhangs: List[OverhangRegion], n_faces: int) -> float:
        """Rough % of faces requiring support."""
        if n_faces == 0:
            return 0.0
        oh = sum(len(r.face_indices) for r in overhangs)
        return float(min(100, 100 * oh / n_faces))

    def _structural_estimate(
        self, ext: np.ndarray, vol: float
    ) -> Tuple[float, float]:
        """Safety factor and max load (N)."""
        if vol < 1e-6:
            return 1.0, 0.0
        max_ext = max(float(ext.max()), 1e-6)
        xsec = vol / max_ext
        max_load = self.material.yield_strength * xsec * self.material.layer_adhesion
        weight = self._mass(vol) * 0.00981
        safety = min(max_load / max(weight, 1e-6), 999.0)
        return float(safety), float(max_load)

    @staticmethod
    def _printability_score(
        thin: List[ThinRegion],
        overhang: List[OverhangRegion],
        warp: float,
        stability: float,
    ) -> float:
        s = 100.0
        if thin:
            s -= min(30, sum(len(r.face_indices) for r in thin) * 0.5)
        if overhang:
            s -= min(30, sum(len(r.face_indices) for r in overhang) * 0.3)
        s -= warp * 0.2
        s += stability * 0.1
        return float(np.clip(s, 0, 100))

    @staticmethod
    def _recommended_infill(ext: np.ndarray, vol: float) -> float:
        bb = float(np.prod(ext))
        if bb < 1e-6:
            return 20.0
        fill = vol / bb
        if fill < 0.3:
            return 15.0
        elif fill < 0.6:
            return 20.0
        return 30.0

    @staticmethod
    def _optimal_orientation(ext: np.ndarray) -> np.ndarray:
        """Suggest Euler angles — current heuristic: tallest axis upright."""
        return np.array([0.0, 0.0, 0.0])

    # ── parameter constraints ──────────────────────────────────────────────

    def _compute_constraints(
        self,
        ext: np.ndarray,
        vol: float,
        thin: List[ThinRegion],
    ) -> Dict[str, Tuple[float, float, str]]:
        """Physics-based min/max for Customizer parameters."""
        mat = self.material
        c: Dict[str, Tuple[float, float, str]] = {}

        min_dim = max(float(ext.min()), 1e-6)
        min_scale = mat.min_wall / min_dim

        for axis in ("x", "y", "z"):
            c[f"scale_{axis}"] = (
                round(max(0.1, min_scale), 4),
                5.0,
                f"Min {mat.min_wall}mm wall for {mat.name}",
            )

        if thin:
            thinnest = min(r.thickness for r in thin)
            wf = mat.min_wall / max(thinnest, 1e-6)
        else:
            wf = 0.5
        c["wall_factor"] = (
            round(max(0.3, wf), 3),
            3.0,
            f"Min wall {mat.min_wall}mm for {mat.name}",
        )

        half = float(ext.max()) * 0.5
        for axis in ("x", "y", "z"):
            c[f"offset_{axis}"] = (-round(half, 1), round(half, 1), "Half bounding-box extent")

        c["shell_thickness"] = (
            mat.min_wall,
            round(min(10.0, min_dim * 0.4), 2),
            f"Min {mat.min_wall}mm, max 40% of smallest dimension",
        )
        return c

    # ── clustering helper ──────────────────────────────────────────────────

    @staticmethod
    def _cluster(
        centroids: np.ndarray,
        indices: np.ndarray,
        threshold: float,
    ) -> List[Tuple[np.ndarray, np.ndarray]]:
        """Simple greedy distance-based clustering."""
        if len(indices) == 0:
            return []
        visited = np.zeros(len(indices), dtype=bool)
        out: List[Tuple[np.ndarray, np.ndarray]] = []
        for i in range(len(indices)):
            if visited[i]:
                continue
            cluster = [i]
            visited[i] = True
            queue = [i]
            while queue:
                cur = queue.pop(0)
                dists = np.linalg.norm(centroids - centroids[cur], axis=1)
                nbrs = np.where((dists < threshold) & (~visited))[0]
                for n in nbrs:
                    visited[n] = True
                    cluster.append(n)
                    queue.append(n)
            out.append((indices[cluster], centroids[cluster]))
        return out

    # ── text report ────────────────────────────────────────────────────────

    def format_report(self, rpt: PhysicsReport) -> str:
        """Human-readable physics report."""
        m = rpt.material
        lines = [
            f"=== Physics Report ({m.name}) ===",
            f"Material:        {m.name} (density {m.density} g/cm3)",
            f"Mass:            {rpt.mass_grams:.2f} g",
            f"Volume:          {rpt.volume_mm3:.1f} mm3",
            f"Surface area:    {rpt.surface_area_mm2:.1f} mm2",
            f"Extents:         {rpt.extents[0]:.1f} x {rpt.extents[1]:.1f} x {rpt.extents[2]:.1f} mm",
            f"Center of mass:  ({rpt.center_of_mass[0]:.2f}, "
            f"{rpt.center_of_mass[1]:.2f}, {rpt.center_of_mass[2]:.2f})",
            "",
            f"Printability:    {rpt.printability_score:.0f}/100",
            f"Stability:       {rpt.stability_score:.0f}/100",
            f"Warp risk:       {rpt.warp_risk:.0f}/100",
            f"Safety factor:   {rpt.structural_safety_factor:.1f}x",
            f"Max load:        {rpt.max_load_newtons:.1f} N",
            f"Rec. infill:     {rpt.recommended_infill_pct:.0f}%",
            f"Support needed:  ~{rpt.support_volume_pct:.1f}%",
            "",
            f"Thin regions:    {len(rpt.thin_regions)}",
        ]
        for i, r in enumerate(rpt.thin_regions):
            lines.append(
                f"  [{i+1}] {r.thickness:.2f}mm (need {r.required:.1f}mm) "
                f"at ({r.centroid[0]:.1f}, {r.centroid[1]:.1f}, {r.centroid[2]:.1f})"
            )
        lines.append(f"Stress regions:  {len(rpt.stress_regions)}")
        for i, r in enumerate(rpt.stress_regions):
            lines.append(f"  [{i+1}] {r.estimated_stress:.3f} MPa - {r.description}")
        lines.append(f"Overhang regions: {len(rpt.overhang_regions)}")
        for i, r in enumerate(rpt.overhang_regions):
            lines.append(
                f"  [{i+1}] {r.angle:.1f} deg (max {r.max_allowed:.0f} deg) "
                f"at ({r.centroid[0]:.1f}, {r.centroid[1]:.1f}, {r.centroid[2]:.1f})"
            )
        if rpt.parameter_constraints:
            lines.append("")
            lines.append("Parameter constraints:")
            for name, (lo, hi, reason) in sorted(rpt.parameter_constraints.items()):
                lines.append(f"  {name}: [{lo:.3f} .. {hi:.3f}]  ({reason})")
        return "\n".join(lines)
