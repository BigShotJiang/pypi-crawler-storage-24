"""
cad2scad.loader — Unified mesh loading from any supported format.

Wraps trimesh for most formats, with special handling for:
  • 3MF (multi-body, color extraction)
  • STEP (via CadQuery tessellation, if available)
  • Multi-body files → list of named MeshData objects
"""

from __future__ import annotations

import logging
import pathlib
from dataclasses import dataclass, field
from typing import Optional, Sequence

import numpy as np

logger = logging.getLogger(__name__)

# Formats trimesh handles natively
_TRIMESH_FORMATS = {
    ".stl", ".obj", ".ply", ".off", ".gltf", ".glb",
    ".3mf", ".dae", ".svg", ".amf", ".xyz",
}

# Formats that need CadQuery / OCP for BREP → mesh
_BREP_FORMATS = {".step", ".stp", ".iges", ".igs", ".brep"}


@dataclass
class MeshData:
    """One solid body extracted from a CAD file."""

    name: str
    vertices: np.ndarray          # (N, 3) float64
    faces: np.ndarray             # (M, 3) int — vertex indices
    color: Optional[tuple] = None # (R, G, B, A) 0-255 or None
    metadata: dict = field(default_factory=dict)

    @property
    def num_vertices(self) -> int:
        return self.vertices.shape[0]

    @property
    def num_faces(self) -> int:
        return self.faces.shape[0]

    @property
    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        """Return (min_corner, max_corner) bounding box."""
        return self.vertices.min(axis=0), self.vertices.max(axis=0)

    @property
    def extents(self) -> np.ndarray:
        """Bounding box size [x, y, z]."""
        lo, hi = self.bounds
        return hi - lo

    @property
    def center(self) -> np.ndarray:
        """Bounding box center."""
        lo, hi = self.bounds
        return (lo + hi) / 2.0


@dataclass
class MeshBundle:
    """Collection of bodies from a single CAD file."""

    source_path: str
    source_format: str
    bodies: list[MeshData] = field(default_factory=list)

    @property
    def total_vertices(self) -> int:
        return sum(b.num_vertices for b in self.bodies)

    @property
    def total_faces(self) -> int:
        return sum(b.num_faces for b in self.bodies)

    def __len__(self) -> int:
        return len(self.bodies)

    def __iter__(self):
        return iter(self.bodies)

    def __getitem__(self, idx):
        return self.bodies[idx]


def load_mesh(path: str | pathlib.Path) -> MeshBundle:
    """
    Load a CAD or mesh file and return a MeshBundle.

    Supports: .stl, .3mf, .obj, .ply, .off, .gltf, .glb, .dae,
              .step/.stp (requires cadquery), .amf
    """
    path = pathlib.Path(path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    ext = path.suffix.lower()
    logger.info("Loading %s (format: %s)", path.name, ext)

    if ext in _BREP_FORMATS:
        return _load_brep(path, ext)
    elif ext in _TRIMESH_FORMATS:
        return _load_trimesh(path, ext)
    else:
        # Try trimesh anyway — it might handle it
        logger.warning("Unknown format '%s', attempting trimesh load", ext)
        return _load_trimesh(path, ext)


def _load_trimesh(path: pathlib.Path, ext: str) -> MeshBundle:
    """Load using trimesh, handling Scenes (multi-body) and single meshes."""
    import trimesh

    thing = trimesh.load(str(path))
    bundle = MeshBundle(source_path=str(path), source_format=ext)

    if isinstance(thing, trimesh.Scene):
        # Multi-body: each geometry is a separate body
        for name, geom in thing.geometry.items():
            if not isinstance(geom, trimesh.Trimesh):
                logger.debug("Skipping non-mesh geometry: %s", name)
                continue
            body = _trimesh_to_meshdata(geom, name)
            bundle.bodies.append(body)
        logger.info(
            "Loaded scene with %d bodies (%d verts, %d faces)",
            len(bundle), bundle.total_vertices, bundle.total_faces,
        )
    elif isinstance(thing, trimesh.Trimesh):
        body = _trimesh_to_meshdata(thing, path.stem)
        bundle.bodies.append(body)
        logger.info(
            "Loaded mesh: %d verts, %d faces",
            body.num_vertices, body.num_faces,
        )
    else:
        raise TypeError(f"Unsupported trimesh result type: {type(thing)}")

    return bundle


def _trimesh_to_meshdata(mesh, name: str) -> MeshData:
    """Convert a trimesh.Trimesh to our MeshData."""
    import trimesh

    color = None
    if hasattr(mesh.visual, "face_colors") and mesh.visual.face_colors is not None:
        # Extract dominant color (mode of face colors)
        try:
            colors = mesh.visual.face_colors
            if len(colors) > 0:
                # Use mean color as representative
                color = tuple(int(c) for c in colors.mean(axis=0))
        except Exception:
            pass

    return MeshData(
        name=_sanitize_name(name),
        vertices=np.array(mesh.vertices, dtype=np.float64),
        faces=np.array(mesh.faces, dtype=np.int32),
        color=color,
        metadata={
            "watertight": bool(mesh.is_watertight),
            "volume": float(mesh.volume) if mesh.is_watertight else None,
        },
    )


def _load_brep(path: pathlib.Path, ext: str) -> MeshBundle:
    """Load STEP/IGES/BREP via CadQuery → tessellate → MeshData."""
    try:
        import cadquery as cq
    except ImportError:
        raise ImportError(
            f"Loading {ext} files requires CadQuery. "
            "Install with: pip install cadquery"
        )

    result = cq.importers.importStep(str(path))

    bundle = MeshBundle(source_path=str(path), source_format=ext)

    # Each solid in the STEP file becomes a body
    solids = result.solids().vals()
    for i, solid in enumerate(solids):
        name = f"{path.stem}_body{i}" if len(solids) > 1 else path.stem

        # Tessellate with default tolerance
        tess = solid.tessellate(0.1)  # tolerance in mm
        vertices = np.array([[v.x, v.y, v.z] for v in tess[0]], dtype=np.float64)
        faces = np.array(tess[1], dtype=np.int32)

        body = MeshData(
            name=_sanitize_name(name),
            vertices=vertices,
            faces=faces,
            metadata={"source": "cadquery_tessellation"},
        )
        bundle.bodies.append(body)

    logger.info(
        "Loaded BREP with %d solids (%d verts, %d faces)",
        len(bundle), bundle.total_vertices, bundle.total_faces,
    )
    return bundle


def _sanitize_name(name: str) -> str:
    """Make a string safe for use as an OpenSCAD module name."""
    import re
    # Replace non-alphanumeric with underscore
    safe = re.sub(r"[^a-zA-Z0-9_]", "_", name)
    # Collapse multiple underscores and strip trailing
    safe = re.sub(r"_+", "_", safe).rstrip("_")
    # Ensure it starts with a letter/underscore
    if safe and safe[0].isdigit():
        safe = "mesh_" + safe
    return safe or "unnamed"
