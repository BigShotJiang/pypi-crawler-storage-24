"""
cad2scad.parameterizer — Feature detection + OpenSCAD Customizer generation.

Analyzes a mesh to extract geometric features (holes, flat surfaces,
symmetry axes) and generates OpenSCAD Customizer parameters with
physics-based constraints from the PhysicsEngine.

The resulting .scad file includes slider-friendly parameter blocks
that let users adjust dimensions, hollowing, orientation, etc. —
all bounded by real material / structural limits.
"""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union

import numpy as np

from .physics import MATERIALS, Material, PhysicsEngine, PhysicsReport

# ---------------------------------------------------------------------------
# Parameter descriptors
# ---------------------------------------------------------------------------

@dataclass
class CustomizerParam:
    """Numeric slider parameter for OpenSCAD Customizer."""

    name: str
    group: str
    value: float
    min_val: float
    max_val: float
    step: float
    description: str
    unit: str
    physics_reason: str = ""

    def scad_line(self) -> str:
        return (
            f"{self.name} = {self.value}; "
            f"// [{self.min_val}:{self.step}:{self.max_val}] "
            f"{self.description} ({self.unit})"
        )


@dataclass
class CustomizerDropdown:
    """Dropdown / enum parameter for OpenSCAD Customizer."""

    name: str
    group: str
    value: str
    options: List[str]
    description: str

    def scad_line(self) -> str:
        opts = ", ".join(f'"{o}"' for o in self.options)
        return f'{self.name} = "{self.value}"; // [{opts}] {self.description}'


# Union type for all parameter kinds
AnyParam = Union[CustomizerParam, CustomizerDropdown]


# ---------------------------------------------------------------------------
# Detected geometric features
# ---------------------------------------------------------------------------

@dataclass
class DetectedHole:
    """Circular hole in the mesh."""
    center: np.ndarray
    normal: np.ndarray
    diameter: float
    boundary_verts: np.ndarray


@dataclass
class DetectedFlat:
    """Large coplanar face group."""
    normal: np.ndarray
    centroid: np.ndarray
    area: float
    face_indices: np.ndarray


@dataclass
class DetectedSymmetry:
    """Mirror-symmetry plane."""
    axis: str           # "X", "Y", "Z"
    plane_point: np.ndarray
    confidence: float   # 0-1


@dataclass
class MeshFeatures:
    """All detected features for one mesh body."""
    holes: List[DetectedHole] = field(default_factory=list)
    flats: List[DetectedFlat] = field(default_factory=list)
    symmetry: List[DetectedSymmetry] = field(default_factory=list)
    principal_axes: Optional[np.ndarray] = None
    aspect_ratio: Tuple[float, float, float] = (1.0, 1.0, 1.0)


# ---------------------------------------------------------------------------
# Parameterizer
# ---------------------------------------------------------------------------

class Parameterizer:
    """Analyse a mesh and emit OpenSCAD Customizer parameters.

    Usage::

        from cad2scad.parameterizer import Parameterizer
        p = Parameterizer(material="PETG")
        params = p.generate_parameters(vertices, faces)
        print(p.generate_scad_block(params))
    """

    def __init__(
        self,
        physics: PhysicsEngine | None = None,
        material: str = "PLA",
    ):
        self.physics = physics or PhysicsEngine(material)
        self.material = self.physics.material

    # ── public API ─────────────────────────────────────────────────────────

    def detect_features(
        self, vertices: np.ndarray, faces: np.ndarray
    ) -> MeshFeatures:
        """Detect geometric features (holes, flats, symmetry)."""
        verts = np.asarray(vertices, dtype=np.float64)
        tris = np.asarray(faces, dtype=np.int32)

        feat = MeshFeatures()
        feat.holes = self._detect_holes(verts, tris)
        feat.flats = self._detect_flats(verts, tris)
        feat.symmetry = self._detect_symmetry(verts)
        feat.principal_axes = self._principal_axes(verts)

        ext = verts.max(axis=0) - verts.min(axis=0)
        mx = max(float(ext.max()), 1e-6)
        feat.aspect_ratio = tuple(float(e / mx) for e in ext)
        return feat

    def generate_parameters(
        self,
        vertices: np.ndarray,
        faces: np.ndarray,
        physics_report: PhysicsReport | None = None,
        features: MeshFeatures | None = None,
    ) -> List[AnyParam]:
        """Build the full Customizer parameter list."""
        verts = np.asarray(vertices, dtype=np.float64)
        tris = np.asarray(faces, dtype=np.int32)

        if features is None:
            features = self.detect_features(verts, tris)
        if physics_report is None:
            physics_report = self.physics.analyze(verts, tris)

        params: List[AnyParam] = []
        pc = physics_report.parameter_constraints
        ext = physics_report.extents

        # ── Material ──────────────────────────────────────────────────
        params.append(CustomizerDropdown(
            name="material", group="Material",
            value=self.material.name,
            options=list(MATERIALS.keys()),
            description="Printing material",
        ))

        # ── Dimensions (scale factors) ───────────────────────────────
        for axis, idx in [("x", 0), ("y", 1), ("z", 2)]:
            key = f"scale_{axis}"
            lo, hi, reason = pc.get(key, (0.1, 5.0, ""))
            params.append(CustomizerParam(
                name=key, group="Dimensions",
                value=1.0,
                min_val=round(lo, 3), max_val=round(hi, 1),
                step=0.01,
                description=f"{axis.upper()} scale ({ext[idx]:.1f}mm nominal)",
                unit="factor",
                physics_reason=reason,
            ))

        # ── Absolute size (mm) ────────────────────────────────────────
        for axis, idx in [("x", 0), ("y", 1), ("z", 2)]:
            nom = float(ext[idx])
            lo_mm = max(self.material.min_wall, nom * 0.1)
            hi_mm = nom * 5.0
            params.append(CustomizerParam(
                name=f"size_{axis}", group="Absolute Size",
                value=round(nom, 2),
                min_val=round(lo_mm, 2), max_val=round(hi_mm, 1),
                step=0.1,
                description=f"{axis.upper()} dimension",
                unit="mm",
                physics_reason=f"Min {self.material.min_wall}mm wall for {self.material.name}",
            ))

        # ── Position offsets ──────────────────────────────────────────
        for axis in ("x", "y", "z"):
            key = f"offset_{axis}"
            lo, hi, reason = pc.get(key, (-100, 100, ""))
            params.append(CustomizerParam(
                name=key, group="Position",
                value=0.0,
                min_val=round(lo, 1), max_val=round(hi, 1),
                step=0.5,
                description=f"{axis.upper()} offset",
                unit="mm",
                physics_reason=reason,
            ))

        # ── Rotation ──────────────────────────────────────────────────
        for axis in ("x", "y", "z"):
            params.append(CustomizerParam(
                name=f"rotate_{axis}", group="Rotation",
                value=0.0,
                min_val=0.0, max_val=360.0,
                step=1.0,
                description=f"Rotation around {axis.upper()}",
                unit="deg",
            ))

        # ── Shell / hollow ────────────────────────────────────────────
        shell_lo, shell_hi, shell_reason = pc.get(
            "shell_thickness",
            (self.material.min_wall, 10.0, ""),
        )
        params.append(CustomizerParam(
            name="hollow", group="Structure",
            value=0.0, min_val=0.0, max_val=1.0, step=1.0,
            description="Hollow the part (0=solid, 1=shell)",
            unit="bool",
        ))
        params.append(CustomizerParam(
            name="shell_thickness", group="Structure",
            value=round(self.material.min_wall * 2, 1),
            min_val=round(shell_lo, 2), max_val=round(shell_hi, 1),
            step=0.1,
            description="Shell wall thickness",
            unit="mm",
            physics_reason=shell_reason,
        ))

        # ── Detected holes ────────────────────────────────────────────
        for i, hole in enumerate(features.holes[:8]):
            params.append(CustomizerParam(
                name=f"hole_{i+1}_dia", group="Detected Holes",
                value=round(hole.diameter, 2),
                min_val=round(max(0.5, hole.diameter * 0.2), 2),
                max_val=round(hole.diameter * 3.0, 1),
                step=0.1,
                description=f"Hole {i+1} diameter",
                unit="mm",
                physics_reason="Min 0.5mm for printability",
            ))

        # ── Print settings ────────────────────────────────────────────
        params.append(CustomizerParam(
            name="layer_height", group="Print Settings",
            value=0.2, min_val=0.08, max_val=0.4, step=0.02,
            description="Layer height", unit="mm",
        ))
        params.append(CustomizerParam(
            name="infill_pct", group="Print Settings",
            value=round(physics_report.recommended_infill_pct),
            min_val=5.0, max_val=100.0, step=5.0,
            description="Recommended infill", unit="%",
            physics_reason="Based on geometry fill ratio",
        ))
        params.append(CustomizerParam(
            name="nozzle_dia", group="Print Settings",
            value=0.4, min_val=0.2, max_val=1.0, step=0.1,
            description="Nozzle diameter", unit="mm",
        ))

        # ── Physics read-only reference ───────────────────────────────
        params.append(CustomizerParam(
            name="_mass_g", group="Physics (read-only)",
            value=round(physics_report.mass_grams, 2),
            min_val=0, max_val=99999, step=0.01,
            description="Estimated mass", unit="g",
            physics_reason=f"At 100% infill, {self.material.name}",
        ))
        params.append(CustomizerParam(
            name="_printability", group="Physics (read-only)",
            value=round(physics_report.printability_score),
            min_val=0, max_val=100, step=1,
            description="Printability score", unit="/100",
        ))
        params.append(CustomizerParam(
            name="_stability", group="Physics (read-only)",
            value=round(physics_report.stability_score),
            min_val=0, max_val=100, step=1,
            description="Stability score", unit="/100",
        ))
        params.append(CustomizerParam(
            name="_warp_risk", group="Physics (read-only)",
            value=round(physics_report.warp_risk),
            min_val=0, max_val=100, step=1,
            description="Warp risk", unit="/100",
        ))
        params.append(CustomizerParam(
            name="_safety_factor", group="Physics (read-only)",
            value=round(min(physics_report.structural_safety_factor, 999), 1),
            min_val=0, max_val=999, step=0.1,
            description="Structural safety factor", unit="x",
        ))
        params.append(CustomizerParam(
            name="_max_load_N", group="Physics (read-only)",
            value=round(physics_report.max_load_newtons, 1),
            min_val=0, max_val=99999, step=0.1,
            description="Max load estimate", unit="N",
        ))

        return params

    def generate_scad_block(self, params: List[AnyParam]) -> str:
        """Render all parameters as an OpenSCAD Customizer block."""
        lines: List[str] = []
        current_group: Optional[str] = None
        for p in params:
            g = p.group
            if g != current_group:
                if current_group is not None:
                    lines.append("")
                lines.append(f"/* [{g}] */")
                current_group = g
            lines.append(p.scad_line())
            reason = getattr(p, "physics_reason", "")
            if reason:
                lines.append(f"// ^ constraint: {reason}")
        return "\n".join(lines)

    # ── feature detection ──────────────────────────────────────────────────

    def _detect_holes(
        self, verts: np.ndarray, tris: np.ndarray
    ) -> List[DetectedHole]:
        """Find circular holes via boundary-edge loop tracing."""
        edge_count: Dict[Tuple[int, int], int] = defaultdict(int)
        for face in tris:
            for e in ((face[0], face[1]), (face[1], face[2]), (face[2], face[0])):
                edge_count[(min(e), max(e))] += 1

        boundary = {e for e, c in edge_count.items() if c == 1}
        if not boundary:
            return []

        adj: Dict[int, set] = defaultdict(set)
        for v0, v1 in boundary:
            adj[v0].add(v1)
            adj[v1].add(v0)

        visited: set = set()
        loops: List[np.ndarray] = []
        for start in adj:
            if start in visited:
                continue
            loop: List[int] = []
            cur = start
            while cur not in visited:
                visited.add(cur)
                loop.append(cur)
                nbs = adj[cur] - visited
                if not nbs:
                    break
                cur = nbs.pop()
            if len(loop) >= 6:
                loops.append(np.array(loop))

        holes: List[DetectedHole] = []
        for loop in loops:
            pts = verts[loop]
            center = pts.mean(axis=0)
            radii = np.linalg.norm(pts - center, axis=1)
            mean_r = radii.mean()
            if mean_r < 0.1:
                continue
            if radii.std() / mean_r < 0.3:  # circularity check
                if len(pts) >= 3:
                    v1 = pts[1] - pts[0]
                    v2 = pts[-1] - pts[0]
                    normal = np.cross(v1, v2)
                    n = np.linalg.norm(normal)
                    normal = normal / n if n > 1e-12 else np.array([0, 0, 1.0])
                else:
                    normal = np.array([0, 0, 1.0])
                holes.append(DetectedHole(
                    center=center,
                    normal=normal,
                    diameter=float(mean_r * 2),
                    boundary_verts=loop,
                ))
        return holes

    def _detect_flats(
        self, verts: np.ndarray, tris: np.ndarray
    ) -> List[DetectedFlat]:
        """Find large coplanar face groups."""
        normals = self._face_normals(verts, tris)
        areas = self._face_areas(verts, tris)
        total = areas.sum()
        if total < 1e-6:
            return []

        cos_thresh = math.cos(math.radians(5.0))
        visited = np.zeros(len(tris), dtype=bool)
        flats: List[DetectedFlat] = []

        for seed in np.argsort(-areas):
            if visited[seed]:
                continue
            n = normals[seed]
            dots = np.abs(np.dot(normals, n))
            group = (dots > cos_thresh) & (~visited)
            idx = np.where(group)[0]
            visited[idx] = True
            ga = float(areas[idx].sum())
            if ga > total * 0.02:
                c = (
                    verts[tris[idx, 0]] + verts[tris[idx, 1]] + verts[tris[idx, 2]]
                ) / 3.0
                flats.append(DetectedFlat(
                    normal=n.copy(),
                    centroid=c.mean(axis=0),
                    area=ga,
                    face_indices=idx,
                ))
        return flats

    def _detect_symmetry(self, verts: np.ndarray) -> List[DetectedSymmetry]:
        """Check mirror symmetry about X, Y, Z through centroid."""
        try:
            from scipy.spatial import cKDTree
        except ImportError:
            return []

        center = verts.mean(axis=0)
        out: List[DetectedSymmetry] = []
        for idx, name in enumerate(["X", "Y", "Z"]):
            mirrored = verts.copy()
            mirrored[:, idx] = 2 * center[idx] - mirrored[:, idx]
            tree = cKDTree(verts)
            dists, _ = tree.query(mirrored)
            max_dim = max((verts.max(axis=0) - verts.min(axis=0)).max(), 1e-6)
            conf = max(0, 1 - dists.mean() / (max_dim * 0.05))
            if conf > 0.5:
                out.append(DetectedSymmetry(
                    axis=name, plane_point=center.copy(), confidence=float(conf),
                ))
        return out

    @staticmethod
    def _principal_axes(verts: np.ndarray) -> np.ndarray:
        """PCA axes of vertex cloud."""
        cov = np.cov((verts - verts.mean(axis=0)).T)
        vals, vecs = np.linalg.eigh(cov)
        return vecs[:, np.argsort(-vals)]

    # ── geometry helpers ───────────────────────────────────────────────────

    @staticmethod
    def _face_normals(verts, tris):
        v0, v1, v2 = verts[tris[:, 0]], verts[tris[:, 1]], verts[tris[:, 2]]
        n = np.cross(v1 - v0, v2 - v0)
        norms = np.linalg.norm(n, axis=1, keepdims=True)
        norms = np.where(norms < 1e-12, 1.0, norms)
        return n / norms

    @staticmethod
    def _face_areas(verts, tris):
        v0, v1, v2 = verts[tris[:, 0]], verts[tris[:, 1]], verts[tris[:, 2]]
        return 0.5 * np.linalg.norm(np.cross(v1 - v0, v2 - v0), axis=1)
