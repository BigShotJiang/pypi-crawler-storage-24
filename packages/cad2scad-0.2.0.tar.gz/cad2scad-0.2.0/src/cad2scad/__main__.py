"""Allow running cad2scad as: python -m cad2scad"""

import sys
from cad2scad.cli import main

sys.exit(main())
