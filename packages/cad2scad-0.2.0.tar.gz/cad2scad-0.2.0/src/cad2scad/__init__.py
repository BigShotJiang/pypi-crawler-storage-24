"""
cad2scad — Convert any CAD/mesh file to OpenSCAD .scad
======================================================

Supports: STL, 3MF, OBJ, PLY, OFF, GLTF/GLB, STEP* (via CadQuery), DAE

Features beyond raw polyhedron dump:
  * Vertex deduplication & weld (shared vertices -> smaller files)
  * Mesh decimation (configurable triangle reduction for faster OpenSCAD preview)
  * Multi-body splitting (each solid -> separate OpenSCAD module)
  * Auto-centering & bounding-box analysis
  * Color/material extraction from 3MF & OBJ
  * Wall-thickness estimation for FDM printability warnings
  * Clean, human-readable .scad output with metadata comments
  * Physics engine: centre-of-mass, stress, overhang, stability, warp risk
  * OpenSCAD Customizer: auto-generated sliders with physics constraints
  * Material database: PLA, ABS, PETG, TPU, Nylon, ASA, PC, Resin
  * Feature detection: holes, flat surfaces, symmetry axes
  * CLI tool + full Python API

Quick start::

    from cad2scad import convert
    convert("model.3mf", "model.scad")

    # Parameterized with physics constraints
    convert("model.3mf", "model.scad", parameterize=True, material="PETG")

    # Full control
    from cad2scad import Converter
    c = Converter(parameterize=True, material="PLA", decimate=0.5)
    c.load("model.3mf")
    c.save("model.scad")
"""

__version__ = "0.2.0"

from cad2scad.converter import Converter, convert
from cad2scad.loader import MeshBundle, load_mesh
from cad2scad.scad_writer import ScadWriter
from cad2scad.optimizer import MeshOptimizer
from cad2scad.physics import PhysicsEngine, PhysicsReport, Material, MATERIALS
from cad2scad.parameterizer import Parameterizer, MeshFeatures

__all__ = [
    "Converter",
    "convert",
    "MeshBundle",
    "load_mesh",
    "ScadWriter",
    "MeshOptimizer",
    "PhysicsEngine",
    "PhysicsReport",
    "Material",
    "MATERIALS",
    "Parameterizer",
    "MeshFeatures",
]
