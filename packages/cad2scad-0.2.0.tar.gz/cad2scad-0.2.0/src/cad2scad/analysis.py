"""
cad2scad.analysis — Mesh analysis utilities for printability checks.

Provides:
  • Wall thickness estimation
  • Overhang detection
  • Bounding box & volume summary
  • Manifold / watertight checks
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import numpy as np

from cad2scad.loader import MeshData

logger = logging.getLogger(__name__)


@dataclass
class AnalysisReport:
    """Results of mesh analysis for one body."""

    name: str
    num_vertices: int
    num_faces: int
    bounds_min: np.ndarray
    bounds_max: np.ndarray
    extents: np.ndarray
    center: np.ndarray
    is_watertight: Optional[bool] = None
    volume: Optional[float] = None
    surface_area: Optional[float] = None
    min_edge_length: Optional[float] = None
    max_edge_length: Optional[float] = None
    mean_edge_length: Optional[float] = None
    thin_wall_faces: int = 0            # faces with edges < min_wall
    overhang_faces: int = 0             # faces steeper than overhang threshold
    overhang_ratio: float = 0.0         # fraction of faces that are overhangs

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "vertices": self.num_vertices,
            "faces": self.num_faces,
            "bounds_min": self.bounds_min.tolist(),
            "bounds_max": self.bounds_max.tolist(),
            "extents": self.extents.tolist(),
            "center": self.center.tolist(),
            "watertight": self.is_watertight,
            "volume_mm3": self.volume,
            "surface_area_mm2": self.surface_area,
            "edge_length_min": self.min_edge_length,
            "edge_length_max": self.max_edge_length,
            "edge_length_mean": self.mean_edge_length,
            "thin_wall_faces": self.thin_wall_faces,
            "overhang_faces": self.overhang_faces,
            "overhang_ratio": self.overhang_ratio,
        }


def analyze_body(
    body: MeshData,
    min_wall: float = 0.8,
    overhang_angle: float = 45.0,
) -> AnalysisReport:
    """
    Analyze a single mesh body for printability.

    Parameters
    ----------
    body : MeshData
        The mesh to analyze.
    min_wall : float
        Minimum wall thickness in mm. Edges shorter than this
        are flagged (potential thin-wall issues). Default 0.8mm.
    overhang_angle : float
        Maximum overhang angle from vertical (degrees).
        Faces steeper than this need support. Default 45°.
    """
    verts, faces = body.vertices, body.faces
    lo, hi = body.bounds
    ext = body.extents

    report = AnalysisReport(
        name=body.name,
        num_vertices=body.num_vertices,
        num_faces=body.num_faces,
        bounds_min=lo,
        bounds_max=hi,
        extents=ext,
        center=body.center,
        is_watertight=body.metadata.get("watertight"),
        volume=body.metadata.get("volume"),
    )

    # Edge length analysis
    try:
        edges = np.concatenate([
            verts[faces[:, 1]] - verts[faces[:, 0]],
            verts[faces[:, 2]] - verts[faces[:, 1]],
            verts[faces[:, 0]] - verts[faces[:, 2]],
        ])
        edge_lengths = np.linalg.norm(edges, axis=1)
        report.min_edge_length = float(edge_lengths.min())
        report.max_edge_length = float(edge_lengths.max())
        report.mean_edge_length = float(edge_lengths.mean())

        # Thin wall detection (edges shorter than min_wall)
        # Group by face: each face has 3 edges
        face_edge_lengths = edge_lengths.reshape(3, -1)  # (3, num_faces)
        face_min_edge = face_edge_lengths.min(axis=0)
        report.thin_wall_faces = int((face_min_edge < min_wall).sum())
    except Exception as e:
        logger.debug("Edge analysis failed: %s", e)

    # Overhang analysis — face normals vs build direction (Z up)
    try:
        v0 = verts[faces[:, 0]]
        v1 = verts[faces[:, 1]]
        v2 = verts[faces[:, 2]]
        normals = np.cross(v1 - v0, v2 - v0)
        norms = np.linalg.norm(normals, axis=1, keepdims=True)
        norms[norms < 1e-10] = 1.0  # avoid div by zero
        normals = normals / norms

        # Overhang angle = angle between face normal and build direction (+Z)
        # nz = 1 means face points up (0° from Z, no overhang)
        # nz = 0 means face is vertical (90° from Z)
        # nz = -1 means face points down (180° from Z, worst overhang)
        # Overhang threshold: faces where the angle from Z > (90 + overhang_angle)
        # i.e. face tilts past vertical by more than overhang_angle degrees
        z_component = normals[:, 2]
        # Angle from +Z axis (0° = up, 180° = down)
        angle_from_z = np.degrees(np.arccos(np.clip(z_component, -1, 1)))
        # A face is an overhang if it points downward past the threshold
        # overhang_angle=45 means faces tilted >135° from Z (>45° past horizontal)
        overhang_mask = angle_from_z > (90.0 + overhang_angle)
        report.overhang_faces = int(overhang_mask.sum())
        report.overhang_ratio = float(overhang_mask.sum() / len(faces)) if len(faces) > 0 else 0.0
    except Exception as e:
        logger.debug("Overhang analysis failed: %s", e)

    # Surface area
    try:
        v0 = verts[faces[:, 0]]
        v1 = verts[faces[:, 1]]
        v2 = verts[faces[:, 2]]
        cross = np.cross(v1 - v0, v2 - v0)
        areas = np.linalg.norm(cross, axis=1) / 2.0
        report.surface_area = float(areas.sum())
    except Exception as e:
        logger.debug("Surface area calculation failed: %s", e)

    return report


def analyze_bundle(bundle, min_wall: float = 0.8, overhang_angle: float = 45.0):
    """Analyze all bodies in a MeshBundle."""
    return [analyze_body(b, min_wall, overhang_angle) for b in bundle.bodies]
