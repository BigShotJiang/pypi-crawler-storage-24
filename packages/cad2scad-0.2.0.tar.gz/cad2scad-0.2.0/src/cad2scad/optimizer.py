"""
cad2scad.optimizer — Mesh optimization pipeline for clean OpenSCAD output.

Operations (all optional, configurable):
  • Vertex welding — merge vertices within tolerance (deduplication)
  • Decimation — reduce triangle count while preserving shape
  • Body splitting — separate disconnected components into modules
  • Auto-centering — move mesh center to origin
  • Coordinate rounding — snap to FDM-relevant precision
  • Degenerate removal — drop zero-area triangles
  • Normal consistency — ensure outward-facing normals
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import numpy as np

from cad2scad.loader import MeshBundle, MeshData

logger = logging.getLogger(__name__)


@dataclass
class OptimizeOptions:
    """Configuration for the mesh optimization pipeline."""

    weld_tolerance: float = 1e-6
    """Merge vertices closer than this distance (mm)."""

    decimate_ratio: Optional[float] = None
    """Target face ratio (0.0–1.0). None = no decimation. 0.5 = halve triangles."""

    decimate_target: Optional[int] = None
    """Target face count. Overrides decimate_ratio if set."""

    center: bool = False
    """Move bounding box center to origin."""

    round_precision: Optional[int] = None
    """Round coordinates to N decimal places. None = no rounding. 4 = 0.0001mm."""

    split_bodies: bool = False
    """Split disconnected mesh components into separate bodies."""

    remove_degenerate: bool = True
    """Remove zero-area triangles."""

    fix_normals: bool = True
    """Attempt to make face normals consistent (outward-facing)."""


class MeshOptimizer:
    """Apply optimization pipeline to a MeshBundle."""

    def __init__(self, options: Optional[OptimizeOptions] = None):
        self.opts = options or OptimizeOptions()

    def optimize(self, bundle: MeshBundle) -> MeshBundle:
        """Run the full optimization pipeline on all bodies."""
        optimized_bodies: list[MeshData] = []

        for body in bundle.bodies:
            logger.info("Optimizing body '%s' (%d verts, %d faces)",
                        body.name, body.num_vertices, body.num_faces)

            verts, faces = body.vertices.copy(), body.faces.copy()

            # 1. Remove degenerate triangles
            if self.opts.remove_degenerate:
                verts, faces = self._remove_degenerate(verts, faces)

            # 2. Weld vertices
            verts, faces = self._weld_vertices(verts, faces)

            # 3. Fix normals
            if self.opts.fix_normals:
                verts, faces = self._fix_normals(verts, faces)

            # 4. Decimation
            if self.opts.decimate_ratio is not None or self.opts.decimate_target is not None:
                verts, faces = self._decimate(verts, faces)

            # 5. Center
            if self.opts.center:
                verts = self._center(verts)

            # 6. Round coordinates
            if self.opts.round_precision is not None:
                verts = np.round(verts, self.opts.round_precision)

            optimized = MeshData(
                name=body.name,
                vertices=verts,
                faces=faces,
                color=body.color,
                metadata={**body.metadata, "optimized": True},
            )
            optimized_bodies.append(optimized)

            logger.info("  → %d verts, %d faces (was %d / %d)",
                        optimized.num_vertices, optimized.num_faces,
                        body.num_vertices, body.num_faces)

        # 7. Split disconnected bodies (if requested)
        if self.opts.split_bodies:
            optimized_bodies = self._split_all(optimized_bodies)

        return MeshBundle(
            source_path=bundle.source_path,
            source_format=bundle.source_format,
            bodies=optimized_bodies,
        )

    def _remove_degenerate(
        self, verts: np.ndarray, faces: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        """Remove triangles with zero area."""
        v0 = verts[faces[:, 0]]
        v1 = verts[faces[:, 1]]
        v2 = verts[faces[:, 2]]
        # Cross product magnitude = 2x triangle area
        cross = np.cross(v1 - v0, v2 - v0)
        areas = np.linalg.norm(cross, axis=1)
        mask = areas > 1e-10
        removed = faces.shape[0] - mask.sum()
        if removed > 0:
            logger.debug("  Removed %d degenerate triangles", removed)
        return verts, faces[mask]

    def _weld_vertices(
        self, verts: np.ndarray, faces: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        """Merge vertices within weld_tolerance, rebuild face indices."""
        tol = self.opts.weld_tolerance
        # Round to tolerance grid for grouping
        quantized = np.round(verts / tol) * tol

        # Find unique vertices
        _, unique_idx, inverse = np.unique(
            quantized, axis=0, return_index=True, return_inverse=True
        )

        new_verts = verts[unique_idx]
        new_faces = inverse[faces]

        removed = verts.shape[0] - new_verts.shape[0]
        if removed > 0:
            logger.debug("  Welded %d duplicate vertices (tol=%.6f)", removed, tol)

        return new_verts, new_faces.astype(np.int32)

    def _fix_normals(
        self, verts: np.ndarray, faces: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        """Attempt to make normals consistent using trimesh."""
        try:
            import trimesh
            mesh = trimesh.Trimesh(vertices=verts, faces=faces, process=False)
            trimesh.repair.fix_normals(mesh)
            return np.array(mesh.vertices), np.array(mesh.faces, dtype=np.int32)
        except ImportError:
            logger.debug("  trimesh not available for normal fixing, skipping")
            return verts, faces
        except Exception as e:
            logger.debug("  Normal fix failed: %s", e)
            return verts, faces

    def _decimate(
        self, verts: np.ndarray, faces: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        """Reduce triangle count using quadric decimation (needs scipy)."""
        try:
            import trimesh
        except ImportError:
            logger.warning("  Decimation requires trimesh; skipping")
            return verts, faces

        mesh = trimesh.Trimesh(vertices=verts, faces=faces, process=False)
        original_count = len(mesh.faces)

        if self.opts.decimate_target is not None:
            target = self.opts.decimate_target
        elif self.opts.decimate_ratio is not None:
            target = max(4, int(original_count * self.opts.decimate_ratio))
        else:
            return verts, faces

        if target >= original_count:
            logger.debug("  Decimation target %d >= current %d, skipping",
                         target, original_count)
            return verts, faces

        try:
            # Try fast_simplification (if available)
            decimated = mesh.simplify_quadric_decimation(target)
            logger.debug("  Decimated %d → %d faces", original_count, len(decimated.faces))
            return (
                np.array(decimated.vertices, dtype=np.float64),
                np.array(decimated.faces, dtype=np.int32),
            )
        except Exception as e:
            logger.warning("  Decimation failed: %s", e)
            return verts, faces

    def _center(self, verts: np.ndarray) -> np.ndarray:
        """Move bounding box center to origin."""
        center = (verts.min(axis=0) + verts.max(axis=0)) / 2.0
        return verts - center

    def _split_all(self, bodies: list[MeshData]) -> list[MeshData]:
        """Split each body into connected components."""
        result = []
        for body in bodies:
            components = self._split_body(body)
            result.extend(components)
        return result

    def _split_body(self, body: MeshData) -> list[MeshData]:
        """Split a single body into connected components."""
        try:
            import trimesh
            mesh = trimesh.Trimesh(
                vertices=body.vertices, faces=body.faces, process=False
            )
            components = mesh.split(only_watertight=False)

            if len(components) <= 1:
                return [body]

            logger.info("  Split '%s' into %d components", body.name, len(components))
            result = []
            for i, comp in enumerate(components):
                name = f"{body.name}_part{i}" if len(components) > 1 else body.name
                result.append(MeshData(
                    name=name,
                    vertices=np.array(comp.vertices, dtype=np.float64),
                    faces=np.array(comp.faces, dtype=np.int32),
                    color=body.color,
                    metadata={**body.metadata, "component_index": i},
                ))
            return result

        except ImportError:
            logger.warning("  Body splitting requires trimesh+networkx; skipping")
            return [body]
