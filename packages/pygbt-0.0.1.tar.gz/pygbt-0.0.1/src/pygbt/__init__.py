def main() -> None:
    print("Hello from pygbt!")
