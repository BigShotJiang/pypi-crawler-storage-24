# X Thread

## 🧵1/6

been building agents for a while and the most annoying part isn't the agent itself — it's maintaining the tool library.

every new edge case = another tool to write, test, deploy. it never ends.

so i built ARISE (Adaptive Runtime Improvement through Self-Evolution) — agents that write their own tools when they fail.

![Architecture](twitter/architecture.svg)

## 🧵2/6

the loop:

agent runs a task → ARISE records the full trajectory (what tools were called, what failed, what the output was) → computes a reward score → if enough failures pile up → analyzes what tool is missing → synthesizes it → validates → promotes

reward is any function you write: (trajectory) → float between 0 and 1. comes with builtins like task_success, answer_match, llm_judge, or you combine them.

## 🧵3/6

generated code is not trusted. every tool goes through:

1. sandbox execution (isolated subprocess or docker, with timeout)
2. LLM writes tests alongside the tool
3. adversarial validation — a separate LLM call specifically tries to break it. empty inputs, wrong types, huge values, division by zero. if it crashes, tool gets rejected
4. import restrictions — you whitelist which modules tools can use. no subprocess, no socket, no os.system

only tools that pass everything get promoted. failed ones stay in testing. everything is versioned in sqlite, you can rollback anytime.

## 🧵4/6

the skill library is just sqlite. tools are python functions with tests. you can:

- `arise skills` — list what the agent evolved
- `arise inspect <id>` — read the actual code
- `arise export` — dump as .py files
- `arise rollback <version>` — undo

for production there's distributed mode: skills in S3, trajectories in SQS, stateless agent + background worker.

## 🧵5/6

here's what it looks like in practice. agent starts with no tools, fails on a metrics API task. ARISE evolves a decoder. next time — it passes.

![Terminal log](twitter/terminal-log.svg)

## 🧵6/6

right now it works with any agent via a simple agent_fn wrapper, and has a first-class adapter for strands agents. langchain/crewai adapters don't exist yet — contributions very welcome.

still early, ~150 tests, paper in the repo. based on VOYAGER/LATM research but nothing production-ready existed.

pip install arise-ai

## Reply to 🧵1/6 (not part of thread)

github.com/abekek/arise
