# cedric-ai

**cedric-ai** est une bibliothèque Python qui te permet d'interagir avec **Cédric**, une intelligence artificielle conversationnelle rapide, sans filtre et disponible à la demande.

Cédric répond à tes questions, discute de n'importe quel sujet, génère du texte, et s'adapte à n'importe quelle personnalité que tu lui donnes. La lib gère automatiquement les cas où le serveur est temporairement hors ligne grâce à un système de **file d'attente persistante** — tes requêtes ne sont jamais perdues.

---

## Installation

```bash
pip install cedric-ai
```

Aucune dépendance externe sauf `requests`. Compatible Python 3.8+.

---

## Accès & Limites

- **Aucun token requis** — l'accès est identifié par ton adresse IP automatiquement
- **500 requêtes gratuites par jour** par adresse IP
- Au-delà du quota, les requêtes sont mises en file et traitées le lendemain
- Aucune inscription, aucune clé API à gérer

---

## Démarrage rapide

```python
from cedric_ai import CedricAI

ai = CedricAI()
reponse = ai.ask("C'est quoi Python ?")
print(reponse)
```

---

## Guide complet

### Requête directe

```python
from cedric_ai import CedricAI

ai = CedricAI()
reponse = ai.ask("Explique moi la gravité en deux phrases")
print(reponse)
```

Attendre max 5 minutes si hors ligne :

```python
reponse = ai.ask("Bonjour !", max_wait=300)
```

Ne pas attendre :

```python
reponse = ai.ask("Bonjour !", wait_if_offline=False)
```

---

### Requête asynchrone avec file d'attente

```python
job_id = ai.ask_async("Écris moi un poème sur la pluie")
result = ai.wait_for_result(job_id, timeout=600)
print(result)
```

---

### Vérifier sans bloquer

```python
result = ai.get_result(job_id)
if result is None:
    print("Pas encore prêt...")
else:
    print(result)
```

---

### Callback

```python
def quand_ca_repond(job_id, reponse):
    print(f"[{job_id}] {reponse}")

ai.ask_async("Donne moi 5 idées", callback=quand_ca_repond)
```

---

### Personnalité personnalisée

```python
ASSISTANT = "Tu es un assistant RH professionnel. Tu réponds de manière formelle."
reponse = ai.ask("Rédige une offre d'emploi Python senior", system=ASSISTANT)
```

---

### Quota restant

```python
print(ai.quota())
# {"ip": "...", "used": 12, "remaining": 488, "limit": 500}
```

---

### Statut de la file

```python
print(ai.queue_status())
# {"online": True, "pending": 2, "done": 8, "errors": 0, "total": 10}

ai.clear_done()
```

---

## Gestion des erreurs

```python
try:
    reponse = ai.ask("Bonjour", wait_if_offline=False)
except ConnectionError:
    print("Serveur indisponible")
except PermissionError:
    print("Quota de 500 requêtes/jour atteint")
except TimeoutError:
    print("Timeout dépassé")
```

---

## Exemple complet — chatbot CLI

```python
from cedric_ai import CedricAI

ai = CedricAI()
print("Tape 'exit' pour quitter\n")

while True:
    question = input("Toi : ").strip()
    if question.lower() == "exit":
        break
    try:
        print(f"Cédric : {ai.ask(question)}\n")
    except PermissionError:
        print("⚠️ Quota atteint\n")
    except TimeoutError:
        print("⏱️ Serveur indisponible\n")
```

---

## Licence

MIT
