from .client import CedricAI
__version__ = "6.0.0"
__all__ = ["CedricAI"]
