"""Tests for the WAN IP Tracker module."""

import json
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from project_toolkit.wan_ip.tracker import WanIpTracker
from project_toolkit.settings.wan_ip import WanIpSettings


TEST_LOG_DIR = "/tmp/wan-ip-test-logs"


@pytest.fixture(autouse=True)
def cleanup_logs():
    """Clean up test log directory before and after each test."""
    shutil.rmtree(TEST_LOG_DIR, ignore_errors=True)
    yield
    shutil.rmtree(TEST_LOG_DIR, ignore_errors=True)


class TestWanIpSettings:
    """Test WanIpSettings model."""

    def test_defaults(self):
        """WanIpSettings should have sensible defaults."""
        ws = WanIpSettings()
        assert ws.wan_ip_log_dir == "/tmp/ip-logs"
        assert len(ws.wan_ip_services_v4) == 3
        assert len(ws.wan_ip_services_v6) == 3
        assert ws.wan_ip_timeout == 10

    def test_custom_values(self):
        """WanIpSettings should accept custom values."""
        ws = WanIpSettings(
            wan_ip_log_dir="/custom/logs",
            wan_ip_services_v4=["https://custom.ipservice.com"],
            wan_ip_timeout=5,
        )
        assert ws.wan_ip_log_dir == "/custom/logs"
        assert ws.wan_ip_services_v4 == ["https://custom.ipservice.com"]
        assert ws.wan_ip_timeout == 5


class TestWanIpTracker:
    """Test WanIpTracker functionality with mocked HTTP."""

    def _mock_response(self, text, status_code=200):
        mock = MagicMock()
        mock.text = text
        mock.status_code = status_code
        return mock

    def test_from_settings(self):
        """Create WanIpTracker from WanIpSettings."""
        ws = WanIpSettings(wan_ip_log_dir=TEST_LOG_DIR)
        tracker = WanIpTracker.from_settings(ws)
        assert str(tracker.log_dir) == TEST_LOG_DIR

    @patch("project_toolkit.wan_ip.tracker.requests")
    def test_get_wan_ip_success(self, mock_requests_module):
        """Should return IPv4 and IPv6 when services respond."""
        mock_session = MagicMock()
        mock_requests_module.Session.return_value = mock_session
        mock_requests_module.RequestException = Exception

        # First call returns IPv4, second returns IPv6
        mock_session.get.side_effect = [
            self._mock_response("1.2.3.4"),
            self._mock_response("2001:db8::1"),
        ]

        tracker = WanIpTracker(log_dir=TEST_LOG_DIR)
        result = tracker.get_wan_ip()
        assert result["ipv4"] == "1.2.3.4"
        assert result["ipv6"] == "2001:db8::1"
        print(f"WAN IP result: {result}")

    @patch("project_toolkit.wan_ip.tracker.requests")
    def test_get_wan_ip_ipv6_unavailable(self, mock_requests_module):
        """Should return None for IPv6 when all v6 services fail."""
        mock_session = MagicMock()
        mock_requests_module.Session.return_value = mock_session
        mock_requests_module.RequestException = Exception

        # IPv4 works, all IPv6 fail
        mock_session.get.side_effect = [
            self._mock_response("1.2.3.4"),
            self._mock_response("", status_code=500),
            self._mock_response("", status_code=500),
            self._mock_response("", status_code=500),
        ]

        tracker = WanIpTracker(log_dir=TEST_LOG_DIR)
        result = tracker.get_wan_ip()
        assert result["ipv4"] == "1.2.3.4"
        assert result["ipv6"] is None

    @patch("project_toolkit.wan_ip.tracker.requests")
    def test_log_if_changed_creates_log(self, mock_requests_module):
        """Should create a log file when IP changes."""
        mock_session = MagicMock()
        mock_requests_module.Session.return_value = mock_session
        mock_requests_module.RequestException = Exception

        mock_session.get.side_effect = [
            self._mock_response("1.2.3.4"),
            self._mock_response("2001:db8::1"),
        ]

        tracker = WanIpTracker(log_dir=TEST_LOG_DIR)
        entry = tracker.log_if_changed()

        assert entry is not None
        assert entry["ipv4"] == "1.2.3.4"
        assert entry["ipv6"] == "2001:db8::1"
        assert "timestamp" in entry

        # Verify log file was created
        log_dir = Path(TEST_LOG_DIR)
        assert log_dir.exists()
        log_files = list(log_dir.glob("ip_log_*.json"))
        assert len(log_files) == 1

        # Verify file contents
        with open(log_files[0]) as f:
            data = json.load(f)
        assert len(data) == 1
        assert data[0]["ipv4"] == "1.2.3.4"
        print(f"Log file created: {log_files[0]}")

    @patch("project_toolkit.wan_ip.tracker.requests")
    def test_log_if_unchanged_returns_none(self, mock_requests_module):
        """Should return None when IP hasn't changed."""
        mock_session = MagicMock()
        mock_requests_module.Session.return_value = mock_session
        mock_requests_module.RequestException = Exception

        # First call — creates log
        mock_session.get.side_effect = [
            self._mock_response("1.2.3.4"),
            self._mock_response("2001:db8::1"),
        ]
        tracker = WanIpTracker(log_dir=TEST_LOG_DIR)
        entry1 = tracker.log_if_changed()
        assert entry1 is not None

        # Second call — same IP, should return None
        mock_session.get.side_effect = [
            self._mock_response("1.2.3.4"),
            self._mock_response("2001:db8::1"),
        ]
        entry2 = tracker.log_if_changed()
        assert entry2 is None
        print("No change detected — correct!")

    @patch("project_toolkit.wan_ip.tracker.requests")
    def test_str_output(self, mock_requests_module):
        """__str__ should format IP addresses nicely."""
        mock_session = MagicMock()
        mock_requests_module.Session.return_value = mock_session
        mock_requests_module.RequestException = Exception

        mock_session.get.side_effect = [
            self._mock_response("1.2.3.4"),
            self._mock_response("2001:db8::1"),
        ]

        tracker = WanIpTracker(log_dir=TEST_LOG_DIR)
        output = str(tracker)
        assert "Date:" in output
        assert "IPv4: 1.2.3.4" in output
        assert "IPv6: 2001:db8::1" in output
        print(f"Output:\n{output}")

    @patch("project_toolkit.wan_ip.tracker.requests")
    def test_str_output_no_ipv6(self, mock_requests_module):
        """__str__ should omit IPv6 line when not available."""
        mock_session = MagicMock()
        mock_requests_module.Session.return_value = mock_session
        mock_requests_module.RequestException = Exception

        mock_session.get.side_effect = [
            self._mock_response("1.2.3.4"),
            self._mock_response("", status_code=500),
            self._mock_response("", status_code=500),
            self._mock_response("", status_code=500),
        ]

        tracker = WanIpTracker(log_dir=TEST_LOG_DIR)
        output = str(tracker)
        assert "Date:" in output
        assert "IPv4: 1.2.3.4" in output
        assert "IPv6" not in output
        print(f"Output (no v6):\n{output}")
