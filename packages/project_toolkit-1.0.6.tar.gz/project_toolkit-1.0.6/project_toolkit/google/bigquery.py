import logging
import os
from typing import Optional, List

import pandas as pd
from google.cloud import bigquery
from google.oauth2 import service_account
from pandas_gbq import to_gbq

logger = logging.getLogger(__name__)


class BigQueryManager:
    """
    A manager class for interacting with Google BigQuery.

    Can be initialized with explicit credentials or from GoogleSettings:

        # Explicit
        manager = BigQueryManager(credentials_file="path/to/creds.json")

        # From settings
        from project_toolkit.settings import get_settings
        manager = BigQueryManager.from_settings(get_settings().google)
    """

    def __init__(self, credentials_file: Optional[str] = None):
        if credentials_file is None:
            from project_toolkit.settings.google import GoogleSettings
            credentials_file = GoogleSettings().google_service_account_json
        self.credentials_file = credentials_file
        if not self.credentials_file:
            raise ValueError("GOOGLE_SERVICE_ACCOUNT_JSON not set in .env")
        self.client = self._get_bq_client()

    @classmethod
    def from_settings(cls, google_settings) -> "BigQueryManager":
        """Create manager from a GoogleSettings instance.

        Args:
            google_settings: A GoogleSettings instance.

        Returns:
            Configured BigQueryManager.
        """
        return cls(credentials_file=google_settings.google_service_account_json)

    def _get_bq_client(self):
        """Initialize and return the BigQuery client."""
        try:
            creds = service_account.Credentials.from_service_account_file(
                self.credentials_file
            )
            return bigquery.Client(credentials=creds)
        except Exception as e:
            logger.error("Failed to load BigQuery client credentials: %s", e)
            raise

    def upload_dataframe(
        self,
        df: pd.DataFrame,
        dataset_id: str,
        table_id: str,
        project_id: Optional[str] = None,
        if_exists: str = "replace",
    ) -> str:
        """Upload a pandas DataFrame to BigQuery."""
        try:
            project = project_id or self.client.project
            table_id_full = f"{project}.{dataset_id}.{table_id}"
            dataset_ref = bigquery.DatasetReference(project, dataset_id)
            try:
                self.client.get_dataset(dataset_ref)
            except Exception:
                raise ValueError(
                    f"Dataset {dataset_id} does not exist in project {project}"
                )
            credentials = service_account.Credentials.from_service_account_file(
                self.credentials_file,
                scopes=["https://www.googleapis.com/auth/bigquery"],
            )
            to_gbq(
                df,
                destination_table=table_id_full,
                project_id=project,
                if_exists=if_exists,
                credentials=credentials,
            )
            logger.info(
                "Uploaded DataFrame to BigQuery table %s.%s", dataset_id, table_id
            )
            return table_id_full
        except Exception as e:
            logger.error("Error uploading DataFrame: %s", e)
            raise

    def upload_csv(
        self,
        csv_path: str,
        dataset_id: str,
        table_id: str,
        project_id: Optional[str] = None,
        if_exists: str = "replace",
        skip_leading_rows: int = 1,
    ) -> str:
        """Upload a CSV file to BigQuery."""
        try:
            project = project_id or self.client.project
            table_id_full = f"{project}.{dataset_id}.{table_id}"

            job_config = bigquery.LoadJobConfig(
                source_format=bigquery.SourceFormat.CSV,
                skip_leading_rows=skip_leading_rows,
                autodetect=True,
            )
            if if_exists == "replace":
                job_config.write_disposition = (
                    bigquery.WriteDisposition.WRITE_TRUNCATE
                )
            elif if_exists == "append":
                job_config.write_disposition = (
                    bigquery.WriteDisposition.WRITE_APPEND
                )
            elif if_exists == "fail":
                job_config.write_disposition = (
                    bigquery.WriteDisposition.WRITE_EMPTY
                )

            with open(csv_path, "rb") as source_file:
                job = self.client.load_table_from_file(
                    source_file, table_id_full, job_config=job_config
                )
            job.result()
            logger.info(
                "Uploaded CSV to BigQuery table %s.%s", dataset_id, table_id
            )
            return job.job_id
        except Exception as e:
            logger.error("Error uploading CSV: %s", e)
            raise

    def list_datasets(self, project_id: Optional[str] = None) -> List[str]:
        """List all datasets in the project."""
        try:
            project = project_id or self.client.project
            datasets = self.client.list_datasets(project=project)
            return [dataset.dataset_id for dataset in datasets]
        except Exception as e:
            logger.error("Error listing datasets: %s", e)
            raise

    def list_tables(
        self, dataset_id: str, project_id: Optional[str] = None
    ) -> List[str]:
        """List all tables in a dataset."""
        try:
            project = project_id or self.client.project
            dataset_ref = bigquery.DatasetReference(project, dataset_id)
            tables = self.client.list_tables(dataset_ref)
            return [table.table_id for table in tables]
        except Exception as e:
            logger.error("Error listing tables: %s", e)
            raise

    def create_dataset(
        self, dataset_id: str, project_id: Optional[str] = None
    ) -> None:
        """Create a new dataset in BigQuery."""
        try:
            project = project_id or self.client.project
            dataset_ref = bigquery.DatasetReference(project, dataset_id)
            dataset = bigquery.Dataset(dataset_ref)
            self.client.create_dataset(dataset)
            logger.info(
                "Created dataset %s in project %s", dataset_id, project
            )
        except Exception as e:
            logger.error("Error creating dataset: %s", e)
            raise

    def create_table(
        self,
        dataset_id: str,
        table_id: str,
        schema: List[bigquery.SchemaField],
        project_id: Optional[str] = None,
    ) -> None:
        """Create a new table in BigQuery with the given schema."""
        try:
            project = project_id or self.client.project
            table_ref = bigquery.TableReference(
                bigquery.DatasetReference(project, dataset_id), table_id
            )
            table = bigquery.Table(table_ref, schema=schema)
            self.client.create_table(table)
            logger.info(
                "Created table %s.%s in project %s",
                dataset_id,
                table_id,
                project,
            )
        except Exception as e:
            logger.error("Error creating table: %s", e)
            raise

    def query_table(
        self, query: str, project_id: Optional[str] = None
    ) -> pd.DataFrame:
        """Execute a query on BigQuery and return results as a DataFrame."""
        try:
            project = project_id or self.client.project
            job = self.client.query(query, project=project)
            return job.to_dataframe()
        except Exception as e:
            logger.error("Error querying table: %s", e)
            raise