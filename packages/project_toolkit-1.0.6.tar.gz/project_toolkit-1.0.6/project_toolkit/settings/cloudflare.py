"""Cloudflare R2 configuration settings module."""

from __future__ import annotations

from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class CloudflareSettings(BaseSettings):
    """Settings for Cloudflare R2 storage.

    Env vars loaded automatically: R2_ACCESS_TOKEN, R2_ACCOUNT_ID, R2_DOMAIN
    """

    model_config = SettingsConfigDict(extra="ignore")

    r2_access_token: Optional[str] = Field(
        default=None,
        description="Cloudflare R2 API access token.",
    )
    r2_account_id: Optional[str] = Field(
        default=None,
        description="Cloudflare account ID.",
    )
    r2_domain: Optional[str] = Field(
        default=None,
        description="Custom R2 domain URL (e.g., https://r2.example.com/).",
    )
