"""WAN IP tracker configuration settings module."""

from __future__ import annotations

from typing import List

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class WanIpSettings(BaseSettings):
    """Settings for the WAN IP tracker module.

    Configures where to log IP changes and which services to query.
    Env var loaded automatically: WAN_IP_LOG_DIR
    """

    model_config = SettingsConfigDict(extra="ignore")

    wan_ip_log_dir: str = Field(
        default="/tmp/ip-logs",
        description="Directory to store IP change log files.",
    )
    wan_ip_services_v4: List[str] = Field(
        default=[
            "https://api.ipify.org",
            "https://ipv4.icanhazip.com",
            "https://v4.ident.me",
        ],
        description="List of URLs to query for WAN IPv4 address.",
    )
    wan_ip_services_v6: List[str] = Field(
        default=[
            "https://api6.ipify.org",
            "https://ipv6.icanhazip.com",
            "https://v6.ident.me",
        ],
        description="List of URLs to query for WAN IPv6 address.",
    )
    wan_ip_timeout: int = Field(
        default=10,
        description="HTTP timeout in seconds for IP service requests.",
    )
