"""
WAN IP Tracker — detects and logs public IPv4/IPv6 address changes.

Usage:
    from project_toolkit.wan_ip import WanIpTracker

    tracker = WanIpTracker()
    result = tracker.get_wan_ip()
    print(result)  # {"ipv4": "1.2.3.4", "ipv6": "2001:db8::1"}

    # Log changes to file
    tracker.log_if_changed()
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


class WanIpTracker:
    """Tracks WAN IP address changes and logs them to files.

    Can be initialized with explicit settings or from WanIpSettings:

        # Explicit
        tracker = WanIpTracker(log_dir="/tmp/ip-logs")

        # From settings
        from project_toolkit.settings import get_settings
        tracker = WanIpTracker.from_settings(get_settings().wan_ip)
    """

    def __init__(
        self,
        log_dir: str = "/tmp/ip-logs",
        services_v4: Optional[List[str]] = None,
        services_v6: Optional[List[str]] = None,
        timeout: int = 10,
    ):
        self.log_dir = Path(log_dir)
        self.services_v4 = services_v4 or [
            "https://api.ipify.org",
            "https://ipv4.icanhazip.com",
            "https://v4.ident.me",
        ]
        self.services_v6 = services_v6 or [
            "https://api6.ipify.org",
            "https://ipv6.icanhazip.com",
            "https://v6.ident.me",
        ]
        self.timeout = timeout

    @classmethod
    def from_settings(cls, wan_ip_settings) -> "WanIpTracker":
        """Create tracker from a WanIpSettings instance."""
        return cls(
            log_dir=wan_ip_settings.wan_ip_log_dir,
            services_v4=wan_ip_settings.wan_ip_services_v4,
            services_v6=wan_ip_settings.wan_ip_services_v6,
            timeout=wan_ip_settings.wan_ip_timeout,
        )

    def _fetch_ip(self, services: List[str]) -> Optional[str]:
        """Try each service URL until one returns a valid IP.

        Args:
            services: List of service URLs to query.

        Returns:
            IP address string, or None if all services fail.
        """
        session = requests.Session()
        for url in services:
            try:
                response = session.get(url, timeout=self.timeout)
                if response.status_code == 200:
                    ip = response.text.strip()
                    if ip:
                        return ip
            except requests.RequestException as e:
                logger.debug("Failed to fetch IP from %s: %s", url, e)
                continue
        return None

    def get_wan_ip(self) -> Dict[str, Optional[str]]:
        """Get current WAN IPv4 and IPv6 addresses.

        Returns:
            Dictionary with 'ipv4' and 'ipv6' keys.
        """
        ipv4 = self._fetch_ip(self.services_v4)
        ipv6 = self._fetch_ip(self.services_v6)
        return {"ipv4": ipv4, "ipv6": ipv6}

    def _get_last_log(self) -> Optional[Dict]:
        """Read the most recent log entry."""
        if not self.log_dir.exists():
            return None

        log_files = sorted(self.log_dir.glob("ip_log_*.json"), reverse=True)
        if not log_files:
            return None

        try:
            with open(log_files[0], "r") as f:
                entries = json.load(f)
                if entries:
                    return entries[-1] if isinstance(entries, list) else entries
        except (json.JSONDecodeError, IOError):
            pass
        return None

    def log_if_changed(self) -> Optional[Dict]:
        """Check current WAN IP and log if it has changed from the last entry.

        Returns:
            The new log entry if IP changed, or None if unchanged.
        """
        current = self.get_wan_ip()
        if not current["ipv4"] and not current["ipv6"]:
            logger.warning("Could not determine any WAN IP address")
            return None

        last = self._get_last_log()

        # Check if IP has changed
        if last:
            if last.get("ipv4") == current["ipv4"] and last.get("ipv6") == current["ipv6"]:
                logger.info("WAN IP unchanged: %s", current)
                return None

        # Create log entry
        entry = {
            "timestamp": datetime.now().isoformat(),
            "ipv4": current["ipv4"],
            "ipv6": current["ipv6"],
        }

        # Write to log file
        self.log_dir.mkdir(parents=True, exist_ok=True)
        log_file = self.log_dir / f"ip_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

        with open(log_file, "w") as f:
            json.dump([entry], f, indent=2)

        logger.info("WAN IP changed, logged to %s: %s", log_file, entry)
        return entry

    def __str__(self) -> str:
        result = self.get_wan_ip()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = [f"Date: {now}", f"IPv4: {result['ipv4'] or 'N/A'}"]
        if result["ipv6"]:
            lines.append(f"IPv6: {result['ipv6']}")
        return "\n".join(lines)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    tracker = WanIpTracker()
    print(tracker)
    result = tracker.log_if_changed()
    if result:
        print(f"IP change logged: {result}")
    else:
        print("No IP change detected")
