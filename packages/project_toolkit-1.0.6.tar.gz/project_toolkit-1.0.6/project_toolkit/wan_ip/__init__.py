"""WAN IP tracker module."""

from project_toolkit.wan_ip.tracker import WanIpTracker

__all__ = ["WanIpTracker"]
