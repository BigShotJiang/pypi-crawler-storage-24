import boto3
import hashlib
import mimetypes
import os
import logging
from typing import Optional

import requests

logger = logging.getLogger(__name__)


class CloudflareBoto3Client:
    """Cloudflare R2 client using boto3 S3-compatible API.

    Can be initialized with explicit args or from CloudflareSettings:

        # Explicit
        client = CloudflareBoto3Client(token="...", account_id="...")

        # From settings
        from project_toolkit.settings import get_settings
        client = CloudflareBoto3Client.from_settings(get_settings().cloudflare)
    """

    def __init__(self, token: Optional[str] = None, account_id: Optional[str] = None):
        if token is None or account_id is None:
            from project_toolkit.settings.cloudflare import CloudflareSettings
            _settings = CloudflareSettings()
            if token is None:
                token = _settings.r2_access_token
            if account_id is None:
                account_id = _settings.r2_account_id
        if not token or not account_id:
            raise ValueError(
                "Token and account_id must be provided or set in environment "
                "variables R2_ACCESS_TOKEN and R2_ACCOUNT_ID"
            )
        self.token = token
        self.account_id = account_id
        self.s3_client = None
        self._setup_s3_client()

    @classmethod
    def from_settings(cls, cloudflare_settings) -> "CloudflareBoto3Client":
        """Create client from a CloudflareSettings instance.

        Args:
            cloudflare_settings: A CloudflareSettings instance.

        Returns:
            Configured CloudflareBoto3Client.
        """
        return cls(
            token=cloudflare_settings.r2_access_token,
            account_id=cloudflare_settings.r2_account_id,
        )

    def get_id(self):
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(
            "https://api.cloudflare.com/client/v4/user/tokens/verify",
            headers=headers,
        )
        if response.status_code == 200:
            return response.json()["result"]["id"]
        else:
            return None

    def _setup_s3_client(self):
        token_id = self.get_id()
        if token_id and self.account_id:
            access_key_id = token_id
            secret_access_key = hashlib.sha256(self.token.encode()).hexdigest()
            self.s3_client = boto3.client(
                "s3",
                endpoint_url=f"https://{self.account_id}.r2.cloudflarestorage.com",
                aws_access_key_id=access_key_id,
                aws_secret_access_key=secret_access_key,
            )

    def list_buckets(self):
        if self.s3_client:
            buckets = self.s3_client.list_buckets()
            return buckets["Buckets"]
        return None

    def upload_file(self, bucket_name, key, content, content_type=None):
        if self.s3_client:
            if content_type is None:
                content_type = mimetypes.guess_type(key)[0]
            kwargs = {"Bucket": bucket_name, "Key": key, "Body": content}
            if content_type:
                kwargs["ContentType"] = content_type
            self.s3_client.put_object(**kwargs)
            return True
        return False

    def delete_file(self, bucket_name, key):
        if self.s3_client:
            self.s3_client.delete_object(Bucket=bucket_name, Key=key)
            return True
        return False

    def create_bucket(self, bucket_name):
        if self.s3_client:
            self.s3_client.create_bucket(Bucket=bucket_name)
            return True
        return False

    def delete_bucket(self, bucket_name):
        if self.s3_client:
            self.s3_client.delete_bucket(Bucket=bucket_name)
            return True
        return False