from yta_editor_frame.frame.resource.abstract import FrameResourceABC
from yta_editor_frame.frame.resource.types import FrameResourceType


class CPUNumpyArrayFrameResource(
    FrameResourceABC
):
    """
    A frame resource based on a numpy array.

    The `.frame` attribute is a `np.ndarray`.
    """
    
    @property
    def width(
        self
    ) -> int:
        return self.array.shape[1]
    
    @property
    def height(
        self
    ) -> int:
        return self.array.shape[0]
    
    @property
    def format(
        self
    ) -> str:
        return str(self.array.dtype)
    
    @property
    def type(
        self
    ) -> FrameResourceType:
        return FrameResourceType.CPU

    def __init__(
        self,
        frame: 'np.ndarray'
    ):
        self.frame: 'np.ndarray' = frame
        """
        The `frame` itself, as a `np.ndarray`.
        """

    def release(
        self,
        render_context: 'RenderContext'
    ):
        pass