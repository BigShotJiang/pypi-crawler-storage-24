from yta_editor_frame.frame.resource.abstract import FrameResourceABC
from yta_editor_frame.frame.resource.types import FrameResourceType


class RenderTargetFrameResource(
    FrameResourceABC
):
    """
    A frame resource based on a render target.

    The `.frame` attribute is a `RenderTarget`.
    """
    
    @property
    def width(
        self
    ) -> int:
        return self.render_target.width
    
    @property
    def height(
        self
    ) -> int:
        return self.render_target.height
    
    @property
    def format(
        self
    ) -> str:
        return self.render_target.dtype
    
    @property
    def type(
        self
    ) -> FrameResourceType:
        return FrameResourceType.GPU_RENDER_TARGET

    def __init__(
        self,
        frame: 'RenderTarget'
    ):
        self.frame: 'RenderTarget' = frame
        """
        The `frame` itself, as a `RenderTarget`.
        """

    def release(
        self,
        render_context: 'RenderContext'
    ):
        render_context.render_target.release(self.frame)