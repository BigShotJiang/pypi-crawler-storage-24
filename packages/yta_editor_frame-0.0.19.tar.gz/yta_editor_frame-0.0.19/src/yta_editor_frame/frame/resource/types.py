from yta_constants.enum import YTAEnum as Enum


class FrameResourceType(Enum):
    """
    The different frame resource types we have.
    """

    CPU = 'cpu'
    """
    The basic CPU frame resource we use to make
    transformations with the nodes and to work
    with:
    - `np.ndarray`
    """
    GPU = 'gpu'
    """
    The basic GPU frame resource we use to make
    transformations when we need to upload 
    something from CPU to GPU or similar:
    - `moderngl.Texture`
    """
    CPU_AV_VIDEOFRAME = 'cpu_av_videoframe'
    """
    The CPU frame resource that we obtain when
    reading a video or that we use to write into
    a new video file:
    - `pyav.VideoFrame`
    """
    GPU_RENDER_TARGET = 'gpu_render_target'
    """
    The GPU frame resource that we manage in our
    own way (with our own created class) to be
    able to write properly with the nodes we
    have and being efficient with the resources
    and memory:
    - `render_target`
    """