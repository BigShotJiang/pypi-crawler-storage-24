from abc import abstractmethod, ABC


class FrameResourceABC(ABC):
    """
    Abstract method to represent a frame resource.
    """

    @property
    @abstractmethod
    def width(
        self
    ) -> int:
        """
        The width of the frame resource, in pixels.
        """
        pass

    @property
    @abstractmethod
    def height(
        self
    ) -> int:
        """
        The height of the frame resource, in pixels.
        """
        pass

    @property
    @abstractmethod
    def format(
        self
    ) -> int:
        """
        The format of the frame resource.

        TODO: Is this useful (?)
        """
        pass

    @property
    @abstractmethod
    def type(
        self
    ) -> 'FrameResourceType':
        """
        The type of frame resource.
        """
        pass

    @abstractmethod
    def release(
        self,
        render_context: 'RenderContext'
    ):
        """
        Release the resource, if needed.
        """
        raise NotImplementedError