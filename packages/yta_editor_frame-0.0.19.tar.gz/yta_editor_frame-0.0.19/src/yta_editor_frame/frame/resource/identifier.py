from yta_editor_frame.frame.resource.types import FrameResourceType


class FrameResourceIdentifier:
    """
    Class to simplify the way we identify the type
    of `FrameResource` instances we are dealing
    with.
    """

    @staticmethod
    def is_cpu(
        frame_resource: 'FrameResource'
    ) -> bool:
        try:
            return frame_resource.type == FrameResourceType.CPU
        except:
            return False
        
    @staticmethod
    def is_gpu(
        frame_resource: 'FrameResource'
    ) -> bool:
        try:
            return frame_resource.type == FrameResourceType.GPU
        except:
            return False
        
    @staticmethod
    def is_cpu_av_videoframe(
        frame_resource: 'FrameResource'
    ) -> bool:
        try:
            return frame_resource.type == FrameResourceType.CPU_AV_VIDEOFRAME
        except:
            return False
    
    @staticmethod
    def is_gpu_render_target(
        frame_resource: 'FrameResource'
    ) -> bool:
        try:
            return frame_resource.type == FrameResourceType.GPU_RENDER_TARGET
        except:
            return False