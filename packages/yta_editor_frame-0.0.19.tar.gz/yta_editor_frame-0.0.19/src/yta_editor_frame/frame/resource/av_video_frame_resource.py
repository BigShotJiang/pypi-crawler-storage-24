from yta_editor_frame.frame.resource.abstract import FrameResourceABC
from yta_editor_frame.frame.resource.types import FrameResourceType


class AvVideoFrameResource(
    FrameResourceABC
):
    """
    A frame resource based on a pyav VideoFrame.

    The `.frame` attribute is an `av.VideoFrame`.
    """

    @property
    def width(
        self
    ) -> int:
        return self.video_frame.width
    
    @property
    def height(
        self
    ) -> int:
        return self.video_frame.height
    
    @property
    def format(
        self
    ) -> str:
        return str(self.video_frame.format.name)
    
    @property
    def type(
        self
    ) -> FrameResourceType:
        return FrameResourceType.CPU_AV_VIDEOFRAME

    def __init__(
        self,
        frame: 'av.VideoFrame'
    ):
        self.frame: 'av.VideoFrame' = frame
        """
        The `frame` itself, as an `av.VideoFrame`.
        """

    def release(
        self,
        render_context: 'RenderContext'
    ):
        pass