from yta_editor_frame.frame.resource.abstract import FrameResourceABC
from yta_editor_frame.frame.resource.types import FrameResourceType


class GPUTextureFrameResource(
    FrameResourceABC
):
    """
    A frame resource based on a texture.

    The `.frame` attribute is a `moderngl.Texture`.
    """
    
    @property
    def width(
        self
    ) -> int:
        return self.texture.width
    
    @property
    def height(
        self
    ) -> int:
        return self.texture.height
    
    @property
    def format(
        self
    ) -> str:
        return self.texture.dtype
    
    @property
    def type(
        self
    ) -> FrameResourceType:
        return FrameResourceType.GPU

    def __init__(
        self,
        frame: 'moderngl.Texture'
    ):
        self.frame: 'moderngl.Texture' = frame
        """
        The `frame` itself, as a `moderngl.Texture`.
        """

    def release(
        self,
        render_context: 'RenderContext'
    ):
        render_context.texture.release(self.frame)
        