"""Style primitives for unified OOXML styling.

This module provides a unified approach to handling colors, fills, strokes,
and effects that can be used across shapes, tables, text, and other elements.

The primitives map directly to OOXML DrawingML concepts while providing
a clean Python API for building and manipulating styles.

Key concepts:
- ColorRef: A color that can be a theme reference or direct RGB, with modifications
- Fill: Solid, gradient, pattern, or no fill
- Stroke: Line/border properties including width, color, dash pattern
- Effect: Shadows, glows, and other visual effects

================================================================================
⚠️  GUARDRAIL: NO HARDCODED DEFAULTS ⚠️
================================================================================

All numeric values in effect/style dataclasses (EMU, percentages, angles, etc.)
MUST be required parameters without defaults. Values should come from:

1. DTCG design tokens (primary source of truth)
2. IR builder which reads from tokens
3. Recipe classes that compute values from brand_tone

DO NOT add default values like:
    blur_radius: int = 12700  # BAD - hardcoded magic number
    start_alpha: int = 50000  # BAD - arbitrary default

Instead, make them required:
    blur_radius: int  # GOOD - must be provided by caller
    start_alpha: int  # GOOD - forces explicit token-driven value

Exceptions (where defaults are OK):
- Boolean flags with clear semantic defaults (e.g., rotate_with_shape=True)
- Enum values with obvious defaults (e.g., align="center")
- Factory methods on ColorRef/Fill/Stroke that document their purpose

If you're tempted to add a default, ask: "Where should this value really come from?"
================================================================================
"""

from __future__ import annotations

# Re-export unit conversion constant

# Re-export all color primitives
from tokenmoulds.ir.colors import (
    ColorMod,
    ColorModifiers,
    ColorModStack,
    ColorModType,
    ColorRef,
    ExtraColorScheme,
    ExtraColorSlot,
    ThemeColor,
)

# Re-export all custom geometry primitives
from tokenmoulds.ir.custom_geometry import (
    ArcParams,
    CustomGeometry,
    GeometryPath,
    PathCommand,
    PathPoint,
    PathSegment,
)

# Re-export all effect primitives
from tokenmoulds.ir.effects import (
    Bevel3D,
    Camera3D,
    CameraPreset,
    Effects,
    Glow,
    LightDirection,
    LightRig3D,
    LightRigPreset,
    Reflection,
    Rotation3D,
    Scene3D,
    Shadow,
    SoftEdge,
)

# Re-export all fill primitives
from tokenmoulds.ir.fills import (
    Fill,
    FillToRect,
    FillType,
    GradientFill,
    GradientStop,
    GradientType,
    PathGradientShape,
)

# Re-export all stroke primitives
from tokenmoulds.ir.strokes import (
    CustomDash,
    DashSegment,
    LineAlign,
    LineCap,
    LineCompound,
    LineDash,
    LineJoin,
    Stroke,
)

# Re-export all style primitives
from tokenmoulds.ir.styles import (
    CellStyle,
    FormatScheme,
    ShapeStyle,
)

__all__ = [
    # Color primitives
    "ThemeColor",
    "ColorModifiers",
    "ColorModType",
    "ColorMod",
    "ColorModStack",
    "ColorRef",
    # Fill primitives
    "GradientStop",
    "GradientType",
    "PathGradientShape",
    "FillToRect",
    "GradientFill",
    "FillType",
    "Fill",
    # Stroke primitives
    "LineCap",
    "LineJoin",
    "LineCompound",
    "LineDash",
    "DashSegment",
    "CustomDash",
    "LineAlign",
    "Stroke",
    # 3D scene primitives
    "CameraPreset",
    "LightRigPreset",
    "LightDirection",
    "Rotation3D",
    "Camera3D",
    "LightRig3D",
    "Scene3D",
    # Effect primitives
    "Shadow",
    "Glow",
    "Reflection",
    "SoftEdge",
    "Bevel3D",
    "Effects",
    # Combined styles
    "ShapeStyle",
    "CellStyle",
    "FormatScheme",
    # Custom geometry
    "PathCommand",
    "PathPoint",
    "ArcParams",
    "PathSegment",
    "GeometryPath",
    "CustomGeometry",
    # Extra color schemes
    "ExtraColorSlot",
    "ExtraColorScheme",
]
