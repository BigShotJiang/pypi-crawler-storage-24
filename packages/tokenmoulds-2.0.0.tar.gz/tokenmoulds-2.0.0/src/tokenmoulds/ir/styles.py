"""Combined shape/cell style and format scheme primitives.

Provides top-level style objects that compose fills, strokes, and effects
into complete style definitions for shapes, table cells, and theme format schemes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from tokenmoulds.ir.effects import Effects
from tokenmoulds.ir.fills import Fill
from tokenmoulds.ir.strokes import Stroke


__all__ = [
    "ShapeStyle",
    "CellStyle",
    "FormatScheme",
]


# =============================================================================
# COMBINED STYLE PRIMITIVES
# =============================================================================


@dataclass
class ShapeStyle:
    """Complete style for a shape (fill + stroke + effects).

    This is the top-level style object for shapes, cells, backgrounds, etc.
    All values should be populated from DTCG tokens through the IR builder.
    """

    fill: Optional[Fill] = None
    stroke: Optional[Stroke] = None
    effects: Optional[Effects] = None


@dataclass
class CellStyle:
    """Style for a table cell (fill + borders).

    Borders are specified per-side for flexibility.
    All values should be populated from DTCG tokens through the IR builder.
    """

    fill: Optional[Fill] = None
    border_top: Optional[Stroke] = None
    border_bottom: Optional[Stroke] = None
    border_left: Optional[Stroke] = None
    border_right: Optional[Stroke] = None
    # Diagonal borders (less common)
    border_tl_br: Optional[Stroke] = None  # Top-left to bottom-right
    border_bl_tr: Optional[Stroke] = None  # Bottom-left to top-right


# =============================================================================
# FORMAT SCHEME PRIMITIVES (for theme.xml fmtScheme)
# =============================================================================


@dataclass
class FormatScheme:
    """Format scheme definition for OOXML themes.

    A format scheme defines the three style levels (subtle, moderate, intense)
    for fills, lines, and effects that can be referenced by shapes.

    The fmtScheme in theme.xml has:
    - fillStyleLst: 3 fill styles
    - lnStyleLst: 3 line styles
    - effectStyleLst: 3 effect styles
    - bgFillStyleLst: 3 background fill styles

    Values should come from DTCG tokens or XML templates (SSOT), not hardcoded.
    """

    name: str
    fill_styles: List[Fill] = field(default_factory=list)  # 3 styles
    line_styles: List[Stroke] = field(default_factory=list)  # 3 styles
    effect_styles: List[Effects] = field(default_factory=list)  # 3 styles
    bg_fill_styles: List[Fill] = field(default_factory=list)  # 3 styles
