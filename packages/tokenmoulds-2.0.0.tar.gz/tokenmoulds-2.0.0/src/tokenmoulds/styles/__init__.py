"""Style definitions and derivation for Office templates."""

from tokenmoulds.styles.factory import (
    create_style_resolver_from_document_ir,
    create_style_resolver_from_tokens,
)
from tokenmoulds.styles.resolver import ResolvedStyle, StyleResolver
from tokenmoulds.styles.word_builtin import (
    BUILTIN_STYLES,
    BUILTIN_STYLE_COUNT,
    BuiltinStyleDef,
    StyleCategory,
    StyleType,
    get_builtin_style,
    get_builtin_styles_by_category,
    get_builtin_styles_by_type,
)

__all__ = [
    # Factory functions
    "create_style_resolver_from_document_ir",
    "create_style_resolver_from_tokens",
    # Resolver
    "ResolvedStyle",
    "StyleResolver",
    # Built-in style catalog
    "BUILTIN_STYLES",
    "BUILTIN_STYLE_COUNT",
    "BuiltinStyleDef",
    "StyleCategory",
    "StyleType",
    "get_builtin_style",
    "get_builtin_styles_by_category",
    "get_builtin_styles_by_type",
]
