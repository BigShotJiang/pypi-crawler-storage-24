"""Word built-in style definitions and derivation rules.

Word has ~300 built-in styles. To prevent Word from using its defaults
(which conflict with our design system), we must define ALL built-in
styles explicitly - either with full overrides or as stubs that inherit
from our Normal style.

Style Categories:
1. Document styles (Normal, headings, body text variants)
2. List styles (List Bullet, List Number, etc.)
3. TOC styles (TOC 1-9, TOC Heading)
4. Index styles (Index 1-9, Index Heading)
5. Footnote/Endnote styles
6. Table styles (Table Grid, accent variants)
7. Character styles (Strong, Emphasis, etc.)
8. Special styles (Header, Footer, Caption, etc.)

Each style has:
- style_id: Internal ID (no spaces, PascalCase)
- name: Display name (with spaces)
- type: paragraph, character, table, numbering
- based_on: Parent style ID
- derivation: How to calculate settings from design tokens
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import List, Optional


class StyleType(Enum):
    """Word style types."""

    PARAGRAPH = "paragraph"
    CHARACTER = "character"
    TABLE = "table"
    NUMBERING = "numbering"


class StyleCategory(Enum):
    """Style categories for derivation grouping."""

    DOCUMENT = "document"  # Normal, Body Text, etc.
    HEADING = "heading"  # Heading 1-9
    LIST = "list"  # List Bullet, List Number, etc.
    TOC = "toc"  # Table of Contents
    INDEX = "index"  # Index entries
    FOOTNOTE = "footnote"  # Footnotes, endnotes
    TABLE = "table"  # Table styles
    CHARACTER = "character"  # Inline character styles
    SPECIAL = "special"  # Header, Footer, Caption, etc.


@dataclass
class BuiltinStyleDef:
    """Definition of a Word built-in style."""

    style_id: str  # e.g., "Heading1", "ListBullet"
    name: str  # e.g., "heading 1", "List Bullet"
    style_type: StyleType
    category: StyleCategory
    based_on: Optional[str] = None  # Parent style ID
    next_style: Optional[str] = None  # Style for next paragraph
    ui_priority: int = 99
    qformat: bool = False  # Show in Quick Styles gallery
    semi_hidden: bool = False
    unhide_when_used: bool = True
    # Derivation hints
    role: Optional[str] = None  # Design engine role to use
    size_scale: Optional[float] = None  # Multiplier for body size
    tracking_adjustment: int = 0  # Additional tracking twips
    space_before_scale: float = 0  # Multiplier for baseline
    space_after_scale: float = 0
    indent_scale: float = 0  # For list/quote indents
    bold: bool = False
    italic: bool = False
    all_caps: bool = False
    small_caps: bool = False
    # Special flags
    outline_level: Optional[int] = None  # For headings (0-8)
    number_format: Optional[str] = None  # For numbered styles


# =============================================================================
# BUILT-IN STYLE CATALOG
# =============================================================================

BUILTIN_STYLES: List[BuiltinStyleDef] = [
    # -------------------------------------------------------------------------
    # DOCUMENT STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="Normal",
        name="Normal",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        ui_priority=0,
        qformat=True,
        semi_hidden=False,
        role="text.body.primary",
    ),
    BuiltinStyleDef(
        style_id="NoSpacing",
        name="No Spacing",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="Normal",
        ui_priority=1,
        qformat=True,
        space_before_scale=0,
        space_after_scale=0,
    ),
    BuiltinStyleDef(
        style_id="BodyText",
        name="Body Text",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="Normal",
        ui_priority=99,
        space_after_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="BodyText2",
        name="Body Text 2",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="Normal",
        ui_priority=99,
        space_after_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="BodyText3",
        name="Body Text 3",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="Normal",
        ui_priority=99,
        size_scale=0.8,
        space_after_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="BodyTextFirstIndent",
        name="Body Text First Indent",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="BodyText",
        ui_priority=99,
        indent_scale=1.0,  # First line indent
    ),
    BuiltinStyleDef(
        style_id="BodyTextIndent",
        name="Body Text Indent",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="Normal",
        ui_priority=99,
        indent_scale=1.0,  # Left indent
    ),
    BuiltinStyleDef(
        style_id="BodyTextIndent2",
        name="Body Text Indent 2",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="Normal",
        ui_priority=99,
        indent_scale=2.0,
    ),
    BuiltinStyleDef(
        style_id="BodyTextIndent3",
        name="Body Text Indent 3",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="Normal",
        ui_priority=99,
        indent_scale=3.0,
    ),
    # -------------------------------------------------------------------------
    # HEADING STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="Heading1",
        name="heading 1",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.HEADING,
        based_on="Normal",
        next_style="Normal",
        ui_priority=9,
        qformat=True,
        semi_hidden=False,
        role="display.primary",
        outline_level=0,
        bold=True,
        space_before_scale=2.0,
        tracking_adjustment=-20,
    ),
    BuiltinStyleDef(
        style_id="Heading2",
        name="heading 2",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.HEADING,
        based_on="Normal",
        next_style="Normal",
        ui_priority=9,
        qformat=True,
        role="display.secondary",
        outline_level=1,
        bold=True,
        space_before_scale=1.5,
        tracking_adjustment=-15,
    ),
    BuiltinStyleDef(
        style_id="Heading3",
        name="heading 3",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.HEADING,
        based_on="Normal",
        next_style="Normal",
        ui_priority=9,
        qformat=True,
        role="heading.section",
        outline_level=2,
        bold=True,
        space_before_scale=1.25,
        tracking_adjustment=-10,
    ),
    BuiltinStyleDef(
        style_id="Heading4",
        name="heading 4",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.HEADING,
        based_on="Normal",
        next_style="Normal",
        ui_priority=9,
        qformat=True,
        role="heading.subsection",
        outline_level=3,
        bold=True,
        italic=True,
        space_before_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="Heading5",
        name="heading 5",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.HEADING,
        based_on="Normal",
        next_style="Normal",
        ui_priority=9,
        semi_hidden=True,
        role="heading.minor",
        outline_level=4,
        space_before_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="Heading6",
        name="heading 6",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.HEADING,
        based_on="Normal",
        next_style="Normal",
        ui_priority=9,
        semi_hidden=True,
        role="heading.minor",
        outline_level=5,
        italic=True,
        space_before_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="Heading7",
        name="heading 7",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.HEADING,
        based_on="Normal",
        next_style="Normal",
        ui_priority=9,
        semi_hidden=True,
        outline_level=6,
        italic=True,
        size_scale=0.9,
    ),
    BuiltinStyleDef(
        style_id="Heading8",
        name="heading 8",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.HEADING,
        based_on="Normal",
        next_style="Normal",
        ui_priority=9,
        semi_hidden=True,
        outline_level=7,
        size_scale=0.85,
    ),
    BuiltinStyleDef(
        style_id="Heading9",
        name="heading 9",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.HEADING,
        based_on="Normal",
        next_style="Normal",
        ui_priority=9,
        semi_hidden=True,
        outline_level=8,
        italic=True,
        size_scale=0.8,
    ),
    # -------------------------------------------------------------------------
    # TITLE STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="Title",
        name="Title",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="Normal",
        next_style="Normal",
        ui_priority=10,
        qformat=True,
        size_scale=2.5,
        space_after_scale=2.0,
        tracking_adjustment=-30,
    ),
    BuiltinStyleDef(
        style_id="Subtitle",
        name="Subtitle",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="Normal",
        next_style="Normal",
        ui_priority=11,
        qformat=True,
        size_scale=1.25,
        italic=True,
        tracking_adjustment=15,
    ),
    # -------------------------------------------------------------------------
    # LIST STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="ListParagraph",
        name="List Paragraph",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=34,
        qformat=True,
        indent_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="List",
        name="List",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="List2",
        name="List 2",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=2.0,
    ),
    BuiltinStyleDef(
        style_id="List3",
        name="List 3",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=3.0,
    ),
    BuiltinStyleDef(
        style_id="List4",
        name="List 4",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=4.0,
    ),
    BuiltinStyleDef(
        style_id="List5",
        name="List 5",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=5.0,
    ),
    BuiltinStyleDef(
        style_id="ListBullet",
        name="List Bullet",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="ListBullet2",
        name="List Bullet 2",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=2.0,
    ),
    BuiltinStyleDef(
        style_id="ListBullet3",
        name="List Bullet 3",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=3.0,
    ),
    BuiltinStyleDef(
        style_id="ListBullet4",
        name="List Bullet 4",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=4.0,
    ),
    BuiltinStyleDef(
        style_id="ListBullet5",
        name="List Bullet 5",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=5.0,
    ),
    BuiltinStyleDef(
        style_id="ListNumber",
        name="List Number",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="ListNumber2",
        name="List Number 2",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=2.0,
    ),
    BuiltinStyleDef(
        style_id="ListNumber3",
        name="List Number 3",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=3.0,
    ),
    BuiltinStyleDef(
        style_id="ListNumber4",
        name="List Number 4",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=4.0,
    ),
    BuiltinStyleDef(
        style_id="ListNumber5",
        name="List Number 5",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=5.0,
    ),
    BuiltinStyleDef(
        style_id="ListContinue",
        name="List Continue",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="ListContinue2",
        name="List Continue 2",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=2.0,
    ),
    BuiltinStyleDef(
        style_id="ListContinue3",
        name="List Continue 3",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=3.0,
    ),
    BuiltinStyleDef(
        style_id="ListContinue4",
        name="List Continue 4",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=4.0,
    ),
    BuiltinStyleDef(
        style_id="ListContinue5",
        name="List Continue 5",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.LIST,
        based_on="Normal",
        ui_priority=99,
        indent_scale=5.0,
    ),
    # -------------------------------------------------------------------------
    # TOC STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="TOCHeading",
        name="TOC Heading",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.TOC,
        based_on="Heading1",
        next_style="Normal",
        ui_priority=39,
        qformat=True,
        outline_level=None,  # Not an outline level
    ),
    BuiltinStyleDef(
        style_id="TOC1",
        name="toc 1",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.TOC,
        based_on="Normal",
        next_style="Normal",
        ui_priority=39,
        bold=True,
        space_before_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="TOC2",
        name="toc 2",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.TOC,
        based_on="Normal",
        next_style="Normal",
        ui_priority=39,
        indent_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="TOC3",
        name="toc 3",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.TOC,
        based_on="Normal",
        next_style="Normal",
        ui_priority=39,
        indent_scale=2.0,
    ),
    BuiltinStyleDef(
        style_id="TOC4",
        name="toc 4",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.TOC,
        based_on="Normal",
        next_style="Normal",
        ui_priority=39,
        indent_scale=3.0,
    ),
    BuiltinStyleDef(
        style_id="TOC5",
        name="toc 5",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.TOC,
        based_on="Normal",
        next_style="Normal",
        ui_priority=39,
        indent_scale=4.0,
    ),
    BuiltinStyleDef(
        style_id="TOC6",
        name="toc 6",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.TOC,
        based_on="Normal",
        next_style="Normal",
        ui_priority=39,
        indent_scale=5.0,
    ),
    BuiltinStyleDef(
        style_id="TOC7",
        name="toc 7",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.TOC,
        based_on="Normal",
        next_style="Normal",
        ui_priority=39,
        indent_scale=6.0,
    ),
    BuiltinStyleDef(
        style_id="TOC8",
        name="toc 8",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.TOC,
        based_on="Normal",
        next_style="Normal",
        ui_priority=39,
        indent_scale=7.0,
    ),
    BuiltinStyleDef(
        style_id="TOC9",
        name="toc 9",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.TOC,
        based_on="Normal",
        next_style="Normal",
        ui_priority=39,
        indent_scale=8.0,
    ),
    # -------------------------------------------------------------------------
    # INDEX STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="IndexHeading",
        name="Index Heading",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.INDEX,
        based_on="Normal",
        next_style="Index1",
        ui_priority=99,
        bold=True,
        space_before_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="Index1",
        name="index 1",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.INDEX,
        based_on="Normal",
        next_style="Normal",
        ui_priority=99,
    ),
    BuiltinStyleDef(
        style_id="Index2",
        name="index 2",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.INDEX,
        based_on="Normal",
        next_style="Normal",
        ui_priority=99,
        indent_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="Index3",
        name="index 3",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.INDEX,
        based_on="Normal",
        next_style="Normal",
        ui_priority=99,
        indent_scale=2.0,
    ),
    BuiltinStyleDef(
        style_id="Index4",
        name="index 4",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.INDEX,
        based_on="Normal",
        next_style="Normal",
        ui_priority=99,
        indent_scale=3.0,
    ),
    BuiltinStyleDef(
        style_id="Index5",
        name="index 5",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.INDEX,
        based_on="Normal",
        next_style="Normal",
        ui_priority=99,
        indent_scale=4.0,
    ),
    BuiltinStyleDef(
        style_id="Index6",
        name="index 6",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.INDEX,
        based_on="Normal",
        next_style="Normal",
        ui_priority=99,
        indent_scale=5.0,
    ),
    BuiltinStyleDef(
        style_id="Index7",
        name="index 7",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.INDEX,
        based_on="Normal",
        next_style="Normal",
        ui_priority=99,
        indent_scale=6.0,
    ),
    BuiltinStyleDef(
        style_id="Index8",
        name="index 8",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.INDEX,
        based_on="Normal",
        next_style="Normal",
        ui_priority=99,
        indent_scale=7.0,
    ),
    BuiltinStyleDef(
        style_id="Index9",
        name="index 9",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.INDEX,
        based_on="Normal",
        next_style="Normal",
        ui_priority=99,
        indent_scale=8.0,
    ),
    # -------------------------------------------------------------------------
    # FOOTNOTE/ENDNOTE STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="FootnoteText",
        name="footnote text",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.FOOTNOTE,
        based_on="Normal",
        ui_priority=99,
        size_scale=0.8,
        role="text.caption",
    ),
    BuiltinStyleDef(
        style_id="EndnoteText",
        name="endnote text",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.FOOTNOTE,
        based_on="Normal",
        ui_priority=99,
        size_scale=0.8,
        role="text.caption",
    ),
    BuiltinStyleDef(
        style_id="FootnoteReference",
        name="footnote reference",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.FOOTNOTE,
        ui_priority=99,
        size_scale=0.7,
    ),
    BuiltinStyleDef(
        style_id="EndnoteReference",
        name="endnote reference",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.FOOTNOTE,
        ui_priority=99,
        size_scale=0.7,
    ),
    # -------------------------------------------------------------------------
    # SPECIAL STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="Header",
        name="header",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        ui_priority=99,
        size_scale=0.85,
    ),
    BuiltinStyleDef(
        style_id="Footer",
        name="footer",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        ui_priority=99,
        size_scale=0.85,
    ),
    BuiltinStyleDef(
        style_id="Caption",
        name="caption",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        next_style="Normal",
        ui_priority=35,
        qformat=True,
        size_scale=0.85,
        italic=True,
        role="text.caption",
        tracking_adjustment=10,
    ),
    BuiltinStyleDef(
        style_id="Quote",
        name="Quote",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        next_style="Normal",
        ui_priority=29,
        qformat=True,
        italic=True,
        indent_scale=1.0,
        space_before_scale=1.0,
        space_after_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="IntenseQuote",
        name="Intense Quote",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        next_style="Normal",
        ui_priority=30,
        qformat=True,
        bold=True,
        italic=True,
        indent_scale=1.5,
        space_before_scale=1.5,
        space_after_scale=1.5,
    ),
    BuiltinStyleDef(
        style_id="BlockText",
        name="Block Text",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        ui_priority=99,
        indent_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="MacroText",
        name="macro",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        ui_priority=99,
        # Monospace font would be set by emitter
    ),
    BuiltinStyleDef(
        style_id="PlainText",
        name="Plain Text",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        ui_priority=99,
        # Monospace font would be set by emitter
    ),
    BuiltinStyleDef(
        style_id="Date",
        name="Date",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        ui_priority=99,
    ),
    BuiltinStyleDef(
        style_id="Salutation",
        name="Salutation",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        next_style="Normal",
        ui_priority=99,
    ),
    BuiltinStyleDef(
        style_id="Closing",
        name="Closing",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        ui_priority=99,
        indent_scale=4.0,
    ),
    BuiltinStyleDef(
        style_id="Signature",
        name="Signature",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        ui_priority=99,
        indent_scale=4.0,
    ),
    BuiltinStyleDef(
        style_id="MessageHeader",
        name="Message Header",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.SPECIAL,
        based_on="Normal",
        ui_priority=99,
        indent_scale=1.0,
    ),
    BuiltinStyleDef(
        style_id="NormalIndent",
        name="Normal Indent",
        style_type=StyleType.PARAGRAPH,
        category=StyleCategory.DOCUMENT,
        based_on="Normal",
        ui_priority=99,
        indent_scale=1.0,
    ),
    # -------------------------------------------------------------------------
    # CHARACTER STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="DefaultParagraphFont",
        name="Default Paragraph Font",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=1,
        semi_hidden=True,
    ),
    BuiltinStyleDef(
        style_id="Strong",
        name="Strong",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=22,
        qformat=True,
        bold=True,
        tracking_adjustment=5,
    ),
    BuiltinStyleDef(
        style_id="Emphasis",
        name="Emphasis",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=20,
        qformat=True,
        italic=True,
    ),
    BuiltinStyleDef(
        style_id="SubtleEmphasis",
        name="Subtle Emphasis",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=19,
        qformat=True,
        italic=True,
    ),
    BuiltinStyleDef(
        style_id="IntenseEmphasis",
        name="Intense Emphasis",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=21,
        qformat=True,
        bold=True,
        italic=True,
    ),
    BuiltinStyleDef(
        style_id="SubtleReference",
        name="Subtle Reference",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=31,
        qformat=True,
        small_caps=True,
    ),
    BuiltinStyleDef(
        style_id="IntenseReference",
        name="Intense Reference",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=32,
        qformat=True,
        bold=True,
        small_caps=True,
        tracking_adjustment=25,
    ),
    BuiltinStyleDef(
        style_id="BookTitle",
        name="Book Title",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=33,
        qformat=True,
        bold=True,
        small_caps=True,
        tracking_adjustment=25,
    ),
    BuiltinStyleDef(
        style_id="Hyperlink",
        name="Hyperlink",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=99,
        unhide_when_used=True,
        # Color set by hyperlink style
    ),
    BuiltinStyleDef(
        style_id="FollowedHyperlink",
        name="FollowedHyperlink",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=99,
        semi_hidden=True,
        # Color set by hyperlink style
    ),
    BuiltinStyleDef(
        style_id="CommentReference",
        name="annotation reference",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=99,
        semi_hidden=True,
        size_scale=0.65,
    ),
    BuiltinStyleDef(
        style_id="LineNumber",
        name="line number",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=99,
        semi_hidden=True,
    ),
    BuiltinStyleDef(
        style_id="PageNumber",
        name="page number",
        style_type=StyleType.CHARACTER,
        category=StyleCategory.CHARACTER,
        ui_priority=99,
        semi_hidden=True,
    ),
    # -------------------------------------------------------------------------
    # TABLE STYLES (defaults only, accents generated separately)
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="TableNormal",
        name="Normal Table",
        style_type=StyleType.TABLE,
        category=StyleCategory.TABLE,
        ui_priority=99,
        semi_hidden=True,
    ),
    BuiltinStyleDef(
        style_id="TableGrid",
        name="Table Grid",
        style_type=StyleType.TABLE,
        category=StyleCategory.TABLE,
        ui_priority=59,
    ),
    # -------------------------------------------------------------------------
    # NUMBERING STYLES
    # -------------------------------------------------------------------------
    BuiltinStyleDef(
        style_id="NoList",
        name="No List",
        style_type=StyleType.NUMBERING,
        category=StyleCategory.LIST,
        ui_priority=99,
        semi_hidden=True,
    ),
]


def get_builtin_styles_by_category(category: StyleCategory) -> List[BuiltinStyleDef]:
    """Get all built-in styles in a category."""
    return [s for s in BUILTIN_STYLES if s.category == category]


def get_builtin_styles_by_type(style_type: StyleType) -> List[BuiltinStyleDef]:
    """Get all built-in styles of a type."""
    return [s for s in BUILTIN_STYLES if s.style_type == style_type]


def get_builtin_style(style_id: str) -> Optional[BuiltinStyleDef]:
    """Get a built-in style by ID."""
    for style in BUILTIN_STYLES:
        if style.style_id == style_id:
            return style
    return None


# =============================================================================
# TABLE STYLE VARIANTS (generated programmatically)
# =============================================================================

# Table style base names that have accent variants
TABLE_STYLE_BASES = [
    ("LightShading", "Light Shading"),
    ("LightList", "Light List"),
    ("LightGrid", "Light Grid"),
    ("MediumShading1", "Medium Shading 1"),
    ("MediumShading2", "Medium Shading 2"),
    ("MediumList1", "Medium List 1"),
    ("MediumList2", "Medium List 2"),
    ("MediumGrid1", "Medium Grid 1"),
    ("MediumGrid2", "Medium Grid 2"),
    ("MediumGrid3", "Medium Grid 3"),
    ("DarkList", "Dark List"),
    ("ColorfulShading", "Colorful Shading"),
    ("ColorfulList", "Colorful List"),
    ("ColorfulGrid", "Colorful Grid"),
]


# Generate table styles with accent variants
def _generate_table_styles() -> List[BuiltinStyleDef]:
    """Generate table style definitions with accent variants."""
    styles = []

    for style_id_base, name_base in TABLE_STYLE_BASES:
        # Base style (no accent)
        styles.append(
            BuiltinStyleDef(
                style_id=style_id_base,
                name=name_base,
                style_type=StyleType.TABLE,
                category=StyleCategory.TABLE,
                ui_priority=60,
                semi_hidden=False,
            )
        )

        # Accent variants 1-6
        for i in range(1, 7):
            styles.append(
                BuiltinStyleDef(
                    style_id=f"{style_id_base}Accent{i}",
                    name=f"{name_base} Accent {i}",
                    style_type=StyleType.TABLE,
                    category=StyleCategory.TABLE,
                    ui_priority=60 + i,
                    semi_hidden=False,
                )
            )

    return styles


# Add generated table styles
BUILTIN_STYLES.extend(_generate_table_styles())


# =============================================================================
# LINKED CHARACTER STYLES (generated programmatically)
# =============================================================================

# Paragraph styles that have linked character styles
LINKED_STYLES = [
    ("Heading1", "Heading 1 Char"),
    ("Heading2", "Heading 2 Char"),
    ("Heading3", "Heading 3 Char"),
    ("Heading4", "Heading 4 Char"),
    ("Heading5", "Heading 5 Char"),
    ("Heading6", "Heading 6 Char"),
    ("Heading7", "Heading 7 Char"),
    ("Heading8", "Heading 8 Char"),
    ("Heading9", "Heading 9 Char"),
    ("Title", "Title Char"),
    ("Subtitle", "Subtitle Char"),
    ("Quote", "Quote Char"),
    ("IntenseQuote", "Intense Quote Char"),
    ("Header", "Header Char"),
    ("Footer", "Footer Char"),
    ("BodyText", "Body Text Char"),
    ("BodyText2", "Body Text 2 Char"),
    ("BodyText3", "Body Text 3 Char"),
    ("FootnoteText", "Footnote Text Char"),
    ("EndnoteText", "Endnote Text Char"),
    ("MacroText", "Macro Text Char"),
    ("Caption", "Caption Char"),
    ("TOCHeading", "TOC Heading Char"),
]


def _generate_linked_char_styles() -> List[BuiltinStyleDef]:
    """Generate linked character styles for paragraph styles."""
    styles = []

    for para_style_id, char_name in LINKED_STYLES:
        char_style_id = para_style_id + "Char"
        styles.append(
            BuiltinStyleDef(
                style_id=char_style_id,
                name=char_name,
                style_type=StyleType.CHARACTER,
                category=StyleCategory.CHARACTER,
                based_on="DefaultParagraphFont",
                ui_priority=99,
                semi_hidden=True,
            )
        )

    return styles


# Add generated linked character styles
BUILTIN_STYLES.extend(_generate_linked_char_styles())


# Count for verification
BUILTIN_STYLE_COUNT = len(BUILTIN_STYLES)
