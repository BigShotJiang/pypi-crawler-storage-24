"""LibreOffice Writer built-in style definitions and derivation rules.

LibreOffice Writer has ~234 built-in styles (from sw/inc/poolfmt.hxx).
Unlike Word, LibreOffice won't inject defaults for missing styles, but
templates should define them to give users a complete, branded style palette.

Design decisions mirror Word's built-in styles where applicable — same
size scales, spacing ratios, bold/italic choices — translated to ODF
naming conventions and XML format.

ODF naming convention: spaces → ``_20_``
  e.g., "Heading 1" → "Heading_20_1", "List Bullet" → "List_20_Bullet"
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

# ---------------------------------------------------------------------------
# Formulaic constants for leveled styles
# ---------------------------------------------------------------------------
_INDEX_TOC_INDENT_STEP_EM = 1.25  # Per-level indent for Index/TOC (× body font size)
_LIST_INDENT_BASE_EM = 3.0  # Level-1 left margin for lists
_LIST_INDENT_STEP_EM = 1.5  # Per-level increment
_LIST_HANGING_EM = -1.5  # Hanging indent for bullet/number markers


class OdfStyleFamily(Enum):
    """ODF style:family values."""

    PARAGRAPH = "paragraph"
    TEXT = "text"
    TABLE_CELL = "table-cell"


class OdfStyleCategory(Enum):
    """Style categories for grouping."""

    DOCUMENT = "document"
    HEADING = "heading"
    TITLE = "title"
    LIST = "list"
    TOC = "toc"
    INDEX = "index"
    FOOTNOTE = "footnote"
    HEADER_FOOTER = "header_footer"
    CAPTION = "caption"
    SPECIAL = "special"
    CHARACTER = "character"
    TABLE = "table"


@dataclass
class OdfBuiltinStyleDef:
    """Definition of a LibreOffice Writer built-in style.

    Design fields use scales/ratios relative to the DocumentIR's body style,
    so styles adapt to any brand configuration.
    """

    style_name: str  # ODF style:name (e.g., "Heading_20_1")
    display_name: str  # ODF style:display-name (e.g., "Heading 1")
    family: OdfStyleFamily
    category: OdfStyleCategory
    parent_style: str | None = None  # ODF style:parent-style-name
    next_style: str | None = None  # ODF style:next-style-name
    # Typography decisions
    use_heading_font: bool = False  # True = heading font, False = body font
    size_scale: float = 1.0  # Multiplier on body font size
    bold: bool = False
    italic: bool = False
    small_caps: bool = False
    # Color
    use_muted_color: bool = False  # True = secondary/muted text color
    # Paragraph spacing (scales on body spacing)
    space_before_scale: float = 0.0
    space_after_scale: float = 1.0  # 1.0 = same as body
    # Indentation (em-based, resolved to pt at build time: em × body font size)
    indent_em: float = 0.0  # Left margin
    text_indent_em: float = 0.0  # First-line / hanging indent
    right_indent_em: float = 0.0  # Right margin
    # Alignment
    text_align: str | None = None  # "start", "center", "end", "justify"
    # Superscript (for anchors)
    superscript: bool = False
    # Monospace font (resolved by emitter from TypographyScheme.monospace_font)
    use_monospace: bool = False


def _depth_size_scale(level: int) -> float:
    """Size scale that diminishes with depth: 1.0 → 0.91 → 0.82."""
    if level <= 3:
        return 1.0
    if level <= 5:
        return 0.91
    return 0.82


def _generate_index_levels() -> list[OdfBuiltinStyleDef]:
    """Generate Index 1-9 with formulaic indent and size."""
    styles: list[OdfBuiltinStyleDef] = []
    for i in range(1, 10):
        styles.append(
            OdfBuiltinStyleDef(
                style_name=f"Index_20_{i}",
                display_name=f"Index {i}",
                family=OdfStyleFamily.PARAGRAPH,
                category=OdfStyleCategory.INDEX,
                parent_style="Standard",
                indent_em=(i - 1) * _INDEX_TOC_INDENT_STEP_EM,
                size_scale=_depth_size_scale(i),
                space_before_scale=0.0,
                space_after_scale=0.33,
            )
        )
    return styles


def _generate_toc_levels() -> list[OdfBuiltinStyleDef]:
    """Generate Contents 1-10 with formulaic indent and size."""
    styles: list[OdfBuiltinStyleDef] = []
    for i in range(1, 11):
        styles.append(
            OdfBuiltinStyleDef(
                style_name=f"Contents_20_{i}",
                display_name=f"Contents {i}",
                family=OdfStyleFamily.PARAGRAPH,
                category=OdfStyleCategory.TOC,
                parent_style="Standard",
                indent_em=(i - 1) * _INDEX_TOC_INDENT_STEP_EM,
                size_scale=_depth_size_scale(i),
                bold=(i == 1),
                space_before_scale=0.5 if i == 1 else 0.0,
                space_after_scale=0.33,
            )
        )
    return styles


def _list_indent_em(level: int) -> float:
    """Left margin for list level (1-based)."""
    return _LIST_INDENT_BASE_EM + (level - 1) * _LIST_INDENT_STEP_EM


def _generate_list_sublevels(
    base_name: str,
    display_base: str,
    parent: str,
    *,
    hanging: bool,
) -> list[OdfBuiltinStyleDef]:
    """Generate list sublevel styles 2-5."""
    styles: list[OdfBuiltinStyleDef] = []
    for i in range(2, 6):
        suffix = f"_20_{i}"
        styles.append(
            OdfBuiltinStyleDef(
                style_name=f"{base_name}{suffix}",
                display_name=f"{display_base} {i}",
                family=OdfStyleFamily.PARAGRAPH,
                category=OdfStyleCategory.LIST,
                parent_style=parent,
                indent_em=_list_indent_em(i),
                text_indent_em=_LIST_HANGING_EM if hanging else 0.0,
                space_before_scale=0.0,
                space_after_scale=0.5,
            )
        )
    return styles


# =============================================================================
# BUILT-IN STYLE CATALOG
# =============================================================================

WRITER_BUILTIN_STYLES: list[OdfBuiltinStyleDef] = [
    # =========================================================================
    # DOCUMENT STYLES
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Standard",
        display_name="Default Style",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        space_before_scale=1.0,
        space_after_scale=1.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Text_20_body",
        display_name="Text body",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Standard",
        space_before_scale=1.0,
        space_after_scale=1.0,
    ),
    OdfBuiltinStyleDef(
        style_name="First_20_line_20_indent",
        display_name="First line indent",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Text_20_body",
        text_indent_em=2.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Hanging_20_indent",
        display_name="Hanging indent",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Text_20_body",
        indent_em=3.0,
        text_indent_em=-3.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Text_20_body_20_indent",
        display_name="Text body indent",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Text_20_body",
        indent_em=3.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Text_20_body_20_indent_20_2",
        display_name="Text body indent 2",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Text_20_body",
        indent_em=6.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Text_20_body_20_indent_20_3",
        display_name="Text body indent 3",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Text_20_body",
        indent_em=9.0,
        size_scale=0.8,
    ),
    OdfBuiltinStyleDef(
        style_name="Salutation",
        display_name="Salutation",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Standard",
    ),
    OdfBuiltinStyleDef(
        style_name="Signature",
        display_name="Signature",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Standard",
        indent_em=12.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Complimentary_20_close",
        display_name="Complimentary close",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Standard",
        indent_em=12.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Marginalia",
        display_name="Marginalia",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Text_20_body",
        size_scale=0.82,
        indent_em=10.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Addressee",
        display_name="Addressee",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Standard",
    ),
    OdfBuiltinStyleDef(
        style_name="Sender",
        display_name="Sender",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.DOCUMENT,
        parent_style="Standard",
        size_scale=0.82,
    ),
    # =========================================================================
    # TITLE / SUBTITLE
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Title",
        display_name="Title",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.TITLE,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=2.2,
        bold=True,
        space_before_scale=0.0,
        space_after_scale=0.5,
        text_align="center",
    ),
    OdfBuiltinStyleDef(
        style_name="Subtitle",
        display_name="Subtitle",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.TITLE,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=1.45,
        use_muted_color=True,
        italic=True,
        space_before_scale=0.0,
        space_after_scale=2.0,
        text_align="center",
    ),
    # =========================================================================
    # HEADINGS 1-10
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Heading_20_1",
        display_name="Heading 1",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADING,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=1.64,
        bold=True,
        space_before_scale=2.0,
        space_after_scale=1.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Heading_20_2",
        display_name="Heading 2",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADING,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=1.45,
        bold=True,
        space_before_scale=1.5,
        space_after_scale=0.67,
    ),
    OdfBuiltinStyleDef(
        style_name="Heading_20_3",
        display_name="Heading 3",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADING,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=1.27,
        bold=True,
        space_before_scale=1.25,
        space_after_scale=0.67,
    ),
    OdfBuiltinStyleDef(
        style_name="Heading_20_4",
        display_name="Heading 4",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADING,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=1.18,
        bold=True,
        italic=True,
        space_before_scale=1.0,
        space_after_scale=0.5,
    ),
    OdfBuiltinStyleDef(
        style_name="Heading_20_5",
        display_name="Heading 5",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADING,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=1.09,
        space_before_scale=1.0,
        space_after_scale=0.5,
    ),
    OdfBuiltinStyleDef(
        style_name="Heading_20_6",
        display_name="Heading 6",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADING,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=1.0,
        italic=True,
        space_before_scale=1.0,
        space_after_scale=0.5,
    ),
    OdfBuiltinStyleDef(
        style_name="Heading_20_7",
        display_name="Heading 7",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADING,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=0.9,
        bold=True,
        italic=True,
        use_muted_color=True,
        space_before_scale=1.0,
        space_after_scale=0.5,
    ),
    OdfBuiltinStyleDef(
        style_name="Heading_20_8",
        display_name="Heading 8",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADING,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=0.85,
        bold=True,
        use_muted_color=True,
        space_before_scale=0.67,
        space_after_scale=0.33,
    ),
    OdfBuiltinStyleDef(
        style_name="Heading_20_9",
        display_name="Heading 9",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADING,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=0.8,
        italic=True,
        use_muted_color=True,
        space_before_scale=0.67,
        space_after_scale=0.33,
    ),
    OdfBuiltinStyleDef(
        style_name="Heading_20_10",
        display_name="Heading 10",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADING,
        parent_style="Standard",
        next_style="Text_20_body",
        use_heading_font=True,
        size_scale=0.8,
        use_muted_color=True,
        space_before_scale=0.67,
        space_after_scale=0.33,
    ),
    # =========================================================================
    # QUOTATIONS
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Quotations",
        display_name="Quotations",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.SPECIAL,
        parent_style="Standard",
        next_style="Text_20_body",
        italic=True,
        use_muted_color=True,
        indent_em=3.0,
        right_indent_em=3.0,
        space_before_scale=1.0,
        space_after_scale=1.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Quotations_20_intense",
        display_name="Intense quotations",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.SPECIAL,
        parent_style="Standard",
        next_style="Text_20_body",
        bold=True,
        italic=True,
        use_muted_color=True,
        indent_em=4.5,
        right_indent_em=4.5,
        space_before_scale=1.5,
        space_after_scale=1.5,
    ),
    # =========================================================================
    # LIST STYLES (bullet, number, indent — 5 levels each)
    # =========================================================================
    # List Bullet 1-5
    # List Bullet 1 (base) + generated 2-5
    OdfBuiltinStyleDef(
        style_name="List_20_Bullet",
        display_name="List Bullet",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        indent_em=_LIST_INDENT_BASE_EM,
        text_indent_em=_LIST_HANGING_EM,
        space_before_scale=0.0,
        space_after_scale=0.5,
    ),
    *_generate_list_sublevels(
        "List_20_Bullet",
        "List Bullet",
        "List_20_Bullet",
        hanging=True,
    ),
    # List Number 1 (base) + generated 2-5
    OdfBuiltinStyleDef(
        style_name="List_20_Number",
        display_name="List Number",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        indent_em=_LIST_INDENT_BASE_EM,
        text_indent_em=_LIST_HANGING_EM,
        space_before_scale=0.0,
        space_after_scale=0.5,
    ),
    *_generate_list_sublevels(
        "List_20_Number",
        "List Number",
        "List_20_Number",
        hanging=True,
    ),
    # List Indent / Contents / Heading
    OdfBuiltinStyleDef(
        style_name="List_20_Indent",
        display_name="List Indent",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        indent_em=_LIST_INDENT_BASE_EM,
        space_before_scale=0.0,
        space_after_scale=0.5,
    ),
    OdfBuiltinStyleDef(
        style_name="List_20_Contents",
        display_name="List Contents",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        indent_em=_LIST_INDENT_BASE_EM,
        space_before_scale=0.0,
        space_after_scale=0.5,
    ),
    OdfBuiltinStyleDef(
        style_name="List_20_Heading",
        display_name="List Heading",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        use_heading_font=True,
        bold=True,
        size_scale=1.09,
        space_before_scale=1.0,
        space_after_scale=0.5,
    ),
    # List Continue 1 (base) + generated 2-5
    OdfBuiltinStyleDef(
        style_name="List_20_Continue",
        display_name="List Continue",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.LIST,
        parent_style="Standard",
        indent_em=_LIST_INDENT_BASE_EM,
        space_before_scale=0.0,
        space_after_scale=0.5,
    ),
    *_generate_list_sublevels(
        "List_20_Continue",
        "List Continue",
        "List_20_Continue",
        hanging=False,
    ),
    # =========================================================================
    # TABLE OF CONTENTS
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Contents_20_Heading",
        display_name="Contents Heading",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.TOC,
        parent_style="Standard",
        next_style="Contents_20_1",
        use_heading_font=True,
        size_scale=1.27,
        bold=True,
        space_before_scale=2.0,
        space_after_scale=1.0,
    ),
    *_generate_toc_levels(),
    # =========================================================================
    # INDEX
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Index_20_Heading",
        display_name="Index Heading",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.INDEX,
        parent_style="Standard",
        next_style="Index_20_1",
        use_heading_font=True,
        size_scale=1.27,
        bold=True,
        space_before_scale=2.0,
        space_after_scale=1.0,
    ),
    *_generate_index_levels(),
    # =========================================================================
    # HEADER / FOOTER
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Header",
        display_name="Header",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Standard",
        size_scale=0.82,
        space_before_scale=0.0,
        space_after_scale=0.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Header_20_left",
        display_name="Header left",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Header",
        text_align="start",
    ),
    OdfBuiltinStyleDef(
        style_name="Header_20_right",
        display_name="Header right",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Header",
        text_align="end",
    ),
    OdfBuiltinStyleDef(
        style_name="Footer",
        display_name="Footer",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Standard",
        size_scale=0.82,
        space_before_scale=0.0,
        space_after_scale=0.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Footer_20_left",
        display_name="Footer left",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Footer",
        text_align="start",
    ),
    OdfBuiltinStyleDef(
        style_name="Footer_20_right",
        display_name="Footer right",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.HEADER_FOOTER,
        parent_style="Footer",
        text_align="end",
    ),
    # =========================================================================
    # FOOTNOTE / ENDNOTE
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Footnote",
        display_name="Footnote",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.FOOTNOTE,
        parent_style="Standard",
        size_scale=0.73,
        space_before_scale=0.0,
        space_after_scale=0.33,
    ),
    OdfBuiltinStyleDef(
        style_name="Endnote",
        display_name="Endnote",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.FOOTNOTE,
        parent_style="Standard",
        size_scale=0.73,
        space_before_scale=0.0,
        space_after_scale=0.33,
    ),
    # =========================================================================
    # CAPTIONS / LABELS
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Caption",
        display_name="Caption",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.CAPTION,
        parent_style="Standard",
        next_style="Text_20_body",
        size_scale=0.82,
        italic=True,
        use_muted_color=True,
        space_before_scale=0.5,
        space_after_scale=1.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Illustration",
        display_name="Illustration",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.CAPTION,
        parent_style="Caption",
        size_scale=0.82,
        italic=True,
        use_muted_color=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Table",
        display_name="Table",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.CAPTION,
        parent_style="Caption",
        size_scale=0.82,
        italic=True,
        use_muted_color=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Drawing",
        display_name="Drawing",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.CAPTION,
        parent_style="Caption",
        size_scale=0.82,
        italic=True,
        use_muted_color=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Figure",
        display_name="Figure",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.CAPTION,
        parent_style="Caption",
        size_scale=0.82,
        italic=True,
        use_muted_color=True,
    ),
    # =========================================================================
    # SPECIAL PARAGRAPH STYLES
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Preformatted_20_Text",
        display_name="Preformatted Text",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.SPECIAL,
        parent_style="Standard",
        size_scale=0.91,
        use_monospace=True,
        space_before_scale=0.0,
        space_after_scale=0.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Horizontal_20_Line",
        display_name="Horizontal Line",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.SPECIAL,
        parent_style="Standard",
        space_before_scale=0.0,
        space_after_scale=1.0,
    ),
    OdfBuiltinStyleDef(
        style_name="Frame_20_contents",
        display_name="Frame contents",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.SPECIAL,
        parent_style="Text_20_body",
    ),
    OdfBuiltinStyleDef(
        style_name="Comment",
        display_name="Comment",
        family=OdfStyleFamily.PARAGRAPH,
        category=OdfStyleCategory.SPECIAL,
        parent_style="Standard",
        size_scale=0.82,
        use_muted_color=True,
    ),
    # =========================================================================
    # CHARACTER STYLES
    # =========================================================================
    OdfBuiltinStyleDef(
        style_name="Internet_20_link",
        display_name="Internet link",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
    ),
    OdfBuiltinStyleDef(
        style_name="Visited_20_link",
        display_name="Visited link",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
    ),
    OdfBuiltinStyleDef(
        style_name="Emphasis",
        display_name="Emphasis",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        italic=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Strong_20_Emphasis",
        display_name="Strong Emphasis",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        bold=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Citation",
        display_name="Citation",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        italic=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Source_20_Text",
        display_name="Source Text",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        use_monospace=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Subtle_20_Emphasis",
        display_name="Subtle Emphasis",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        italic=True,
        use_muted_color=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Intense_20_Emphasis",
        display_name="Intense Emphasis",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        bold=True,
        italic=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Subtle_20_Reference",
        display_name="Subtle Reference",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        small_caps=True,
        use_muted_color=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Intense_20_Reference",
        display_name="Intense Reference",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        bold=True,
        small_caps=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Book_20_Title",
        display_name="Book Title",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        bold=True,
        small_caps=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Footnote_20_anchor",
        display_name="Footnote anchor",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        superscript=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Endnote_20_anchor",
        display_name="Endnote anchor",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        superscript=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Numbering_20_Symbols",
        display_name="Numbering Symbols",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
    ),
    OdfBuiltinStyleDef(
        style_name="Bullet_20_Symbols",
        display_name="Bullet Symbols",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
    ),
    OdfBuiltinStyleDef(
        style_name="Page_20_Number",
        display_name="Page Number",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
    ),
    OdfBuiltinStyleDef(
        style_name="Caption_20_characters",
        display_name="Caption characters",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        bold=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Drop_20_Caps",
        display_name="Drop Caps",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        size_scale=2.2,
    ),
    OdfBuiltinStyleDef(
        style_name="Line_20_numbering",
        display_name="Line numbering",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        size_scale=0.73,
    ),
    OdfBuiltinStyleDef(
        style_name="Index_20_Link",
        display_name="Index Link",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
    ),
    OdfBuiltinStyleDef(
        style_name="Main_20_index_20_entry",
        display_name="Main index entry",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        bold=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Placeholder",
        display_name="Placeholder",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        italic=True,
        use_muted_color=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Rubies",
        display_name="Rubies",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        size_scale=0.55,
        superscript=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Definition",
        display_name="Definition",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        italic=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Teletype",
        display_name="Teletype",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        use_monospace=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Variable",
        display_name="Variable",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        italic=True,
    ),
    OdfBuiltinStyleDef(
        style_name="Example",
        display_name="Example",
        family=OdfStyleFamily.TEXT,
        category=OdfStyleCategory.CHARACTER,
        use_monospace=True,
    ),
]


WRITER_BUILTIN_STYLE_COUNT = len(WRITER_BUILTIN_STYLES)
