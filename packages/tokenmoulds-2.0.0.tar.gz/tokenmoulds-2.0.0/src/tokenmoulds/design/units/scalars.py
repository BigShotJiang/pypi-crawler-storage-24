"""Numeric constants for OOXML unit conversions.

OOXML uses three primary unit systems for typography:
- EMU (English Metric Units): Base unit, 914400 EMU = 1 inch
- Points (pt): Standard typographic unit, 72 pt = 1 inch
- Twips: 1/20 of a point, used in WordprocessingML

Additional units used in specific contexts:
- Half-points: Font sizes in OOXML (sz attribute)
- Hundredths of a point: Line spacing in some contexts
"""

from __future__ import annotations

# Base conversion
EMU_PER_INCH: int = 914_400
POINTS_PER_INCH: float = 72.0

# EMU conversions
EMU_PER_POINT: float = EMU_PER_INCH / POINTS_PER_INCH  # 12700
EMU_PER_TWIP: float = EMU_PER_POINT / 20.0  # 635
EMU_PER_CM: float = EMU_PER_INCH / 2.54
EMU_PER_MM: float = EMU_PER_CM / 10.0

# Twips conversions
TWIPS_PER_POINT: int = 20
TWIPS_PER_INCH: int = int(POINTS_PER_INCH * TWIPS_PER_POINT)  # 1440

# Half-points (OOXML font size unit)
HALF_POINTS_PER_POINT: int = 2

# Hundredths of a point (OOXML line spacing)
HUNDREDTHS_PER_POINT: int = 100

__all__ = [
    "EMU_PER_INCH",
    "EMU_PER_POINT",
    "EMU_PER_TWIP",
    "EMU_PER_CM",
    "EMU_PER_MM",
    "POINTS_PER_INCH",
    "TWIPS_PER_POINT",
    "TWIPS_PER_INCH",
    "HALF_POINTS_PER_POINT",
    "HUNDREDTHS_PER_POINT",
]
