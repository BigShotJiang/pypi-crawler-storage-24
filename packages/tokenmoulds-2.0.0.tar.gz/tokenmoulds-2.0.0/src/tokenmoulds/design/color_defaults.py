"""Centralized default color constants.

All fallback colors that previously existed as scattered hex literals
are defined here.  Import these instead of repeating ``"#000000"``
across emitters, adapters, and token builders.

These are *fallback* defaults used when no design tokens or color theme
is available.  They are intentionally neutral — the design engine and
user tokens override them.
"""

from __future__ import annotations

# ─────────────────────────────────────────────────────────────────────────────
# Pure black / white (OOXML dk1 / lt1)
# ─────────────────────────────────────────────────────────────────────────────
PURE_BLACK: str = "#000000"
PURE_WHITE: str = "#FFFFFF"

# ─────────────────────────────────────────────────────────────────────────────
# Semantic text color defaults
# ─────────────────────────────────────────────────────────────────────────────
TEXT_PRIMARY: str = "#000000"
TEXT_SECONDARY: str = "#4A4A4A"
TEXT_MUTED: str = "#8A8A8A"
TEXT_INVERSE: str = "#FFFFFF"

# ─────────────────────────────────────────────────────────────────────────────
# Neutral surface palette defaults
# ─────────────────────────────────────────────────────────────────────────────
SURFACE_WHITE: str = "#FFFFFF"
SURFACE_LIGHTEST: str = "#F8F9FA"
SURFACE_LIGHT: str = "#F5F5F5"
SURFACE_MEDIUM: str = "#6C757D"
SURFACE_DARK: str = "#343A40"
SURFACE_DARKEST: str = "#333333"
SURFACE_BLACK: str = "#000000"

# ─────────────────────────────────────────────────────────────────────────────
# Border / rule / separator defaults
# ─────────────────────────────────────────────────────────────────────────────
BORDER_DEFAULT: str = "#CCCCCC"
BORDER_TABLE: str = "#E5E7EB"  # Tailwind gray-200

# ─────────────────────────────────────────────────────────────────────────────
# Shadow default
# ─────────────────────────────────────────────────────────────────────────────
SHADOW_COLOR: str = "#000000"

# ─────────────────────────────────────────────────────────────────────────────
# Fallback brand accent colors (used when no user colors provided)
# ─────────────────────────────────────────────────────────────────────────────
DEFAULT_PRIMARY: str = "#2563EB"  # Blue-600
DEFAULT_SECONDARY: str = "#DC2626"  # Red-600

# ─────────────────────────────────────────────────────────────────────────────
# Fallback OOXML 12-slot theme (used only when theme_mapping is missing)
# Accent slots 3–6 are tints/shades of the brand primaries.
# ─────────────────────────────────────────────────────────────────────────────
DEFAULT_THEME_MAPPING: dict[str, str] = {
    "dk1": PURE_BLACK,
    "lt1": PURE_WHITE,
    "dk2": SURFACE_DARKEST,
    "lt2": SURFACE_LIGHT,
    "accent1": DEFAULT_PRIMARY,
    "accent2": DEFAULT_SECONDARY,
    "accent3": "#60A5FA",  # Blue-400  (tint of primary)
    "accent4": "#F472B6",  # Pink-400  (tint of secondary)
    "accent5": "#1E40AF",  # Blue-800  (shade of primary)
    "accent6": "#9F1239",  # Rose-800  (shade of secondary)
    "hlink": DEFAULT_PRIMARY,
    "folHlink": DEFAULT_SECONDARY,
}

# ─────────────────────────────────────────────────────────────────────────────
# Microsoft Office standard theme colors (used in design_bridge.py when
# creating a "brand-neutral" DocumentIR).
# ─────────────────────────────────────────────────────────────────────────────
OFFICE_ACCENT1: str = "#4472C4"  # Office blue
OFFICE_ACCENT2: str = "#ED7D31"  # Office orange
OFFICE_DK2: str = "#44546A"  # Office secondary text
OFFICE_LT2: str = "#E7E6E6"  # Office secondary background
OFFICE_ACCENT3: str = "#B4C4E0"  # Light tint of accent1
OFFICE_ACCENT4: str = "#2F4266"  # Dark shade of accent1
OFFICE_ACCENT5: str = "#96A0AA"  # Cool neutral
OFFICE_ACCENT6: str = "#8D847D"  # Warm neutral


__all__ = [
    # Pure
    "PURE_BLACK",
    "PURE_WHITE",
    # Text
    "TEXT_PRIMARY",
    "TEXT_SECONDARY",
    "TEXT_MUTED",
    "TEXT_INVERSE",
    # Surfaces
    "SURFACE_WHITE",
    "SURFACE_LIGHTEST",
    "SURFACE_LIGHT",
    "SURFACE_MEDIUM",
    "SURFACE_DARK",
    "SURFACE_DARKEST",
    "SURFACE_BLACK",
    # Borders
    "BORDER_DEFAULT",
    "BORDER_TABLE",
    # Shadow
    "SHADOW_COLOR",
    # Brand
    "DEFAULT_PRIMARY",
    "DEFAULT_SECONDARY",
    # Theme
    "DEFAULT_THEME_MAPPING",
    # Office standard
    "OFFICE_ACCENT1",
    "OFFICE_ACCENT2",
    "OFFICE_DK2",
    "OFFICE_LT2",
    "OFFICE_ACCENT3",
    "OFFICE_ACCENT4",
    "OFFICE_ACCENT5",
    "OFFICE_ACCENT6",
]
