"""Centralized layout defaults derived from the grid system.

All layout measurements that previously existed as scattered magic numbers
are defined here as functions of a baseline grid.  Import these instead of
hardcoding twip/EMU/pt values in emitters, adapters, or token builders.

Page sizes and slide dimensions are sourced from the canonical
:mod:`tokenmoulds.themes.aspect_ratios` registry.  Conversion constants
(EMU_PER_INCH, etc.) stay in :mod:`tokenmoulds.design.units`.
"""

from __future__ import annotations

from tokenmoulds.design.units import (
    EMU_PER_INCH,
    pt_to_emu,
    pt_to_twips,
)
from tokenmoulds.themes.aspect_ratios import (
    A4_LANDSCAPE,
    A4_PORTRAIT,
    LETTER_LANDSCAPE,
    LETTER_PORTRAIT,
    STANDARD_4_3,
    WIDESCREEN_16_9,
    WIDESCREEN_16_10,
)

# ─────────────────────────────────────────────────────────────────────────────
# Standard baseline grid (12pt).  The design engine may override this.
# ─────────────────────────────────────────────────────────────────────────────
DEFAULT_BASELINE_PT: float = 12.0
DEFAULT_BASELINE_EMU: int = pt_to_emu(DEFAULT_BASELINE_PT)  # 152400

# ─────────────────────────────────────────────────────────────────────────────
# Slide dimensions – sourced from aspect_ratios.py constants.
# ─────────────────────────────────────────────────────────────────────────────
SLIDE_16_9_WIDTH_EMU: int = WIDESCREEN_16_9.width_emu  # 12192000
SLIDE_16_9_HEIGHT_EMU: int = WIDESCREEN_16_9.height_emu  # 6858000
SLIDE_16_10_WIDTH_EMU: int = WIDESCREEN_16_10.width_emu  # 12192000
SLIDE_16_10_HEIGHT_EMU: int = WIDESCREEN_16_10.height_emu  # 7620000
SLIDE_4_3_WIDTH_EMU: int = STANDARD_4_3.width_emu  # 9144000
SLIDE_4_3_HEIGHT_EMU: int = STANDARD_4_3.height_emu  # 6858000

# ─────────────────────────────────────────────────────────────────────────────
# Document page sizes – sourced from aspect_ratios.py constants.
# Each page standard is an AspectRatio with both portrait and landscape.
# ─────────────────────────────────────────────────────────────────────────────
A4_WIDTH_EMU: int = A4_PORTRAIT.width_emu  # 7559055
A4_HEIGHT_EMU: int = A4_PORTRAIT.height_emu  # 10691818
A4_LANDSCAPE_WIDTH_EMU: int = A4_LANDSCAPE.width_emu  # 10691818
A4_LANDSCAPE_HEIGHT_EMU: int = A4_LANDSCAPE.height_emu  # 7559055

LETTER_WIDTH_EMU: int = LETTER_PORTRAIT.width_emu  # 7772400
LETTER_HEIGHT_EMU: int = LETTER_PORTRAIT.height_emu  # 10058400
LETTER_LANDSCAPE_WIDTH_EMU: int = LETTER_LANDSCAPE.width_emu  # 10058400
LETTER_LANDSCAPE_HEIGHT_EMU: int = LETTER_LANDSCAPE.height_emu  # 7772400


# ─────────────────────────────────────────────────────────────────────────────
# Grid-derived layout measurements (functions of baseline_pt).
# ─────────────────────────────────────────────────────────────────────────────


def list_indent_twips(baseline_pt: float = DEFAULT_BASELINE_PT) -> int:
    """List indent = 1× baseline grid."""
    return pt_to_twips(baseline_pt)


def list_hanging_twips(baseline_pt: float = DEFAULT_BASELINE_PT) -> int:
    """List hanging indent = 0.5× baseline grid."""
    return pt_to_twips(baseline_pt * 0.5)


def quote_border_width_twips() -> int:
    """Quote border width ≈ 1.5pt (a visual constant, not grid-derived)."""
    return pt_to_twips(1.5)  # 30 twips


def quote_indent_twips(baseline_pt: float = DEFAULT_BASELINE_PT) -> int:
    """Quote indent = 1× baseline grid."""
    return pt_to_twips(baseline_pt)


def tab_stop_twips(baseline_pt: float = DEFAULT_BASELINE_PT) -> int:
    """Default tab stop = 3× baseline grid."""
    return pt_to_twips(baseline_pt * 3)


def table_cell_padding_twips(
    baseline_pt: float = DEFAULT_BASELINE_PT,
) -> dict[str, int]:
    """Table cell padding: x ≈ 0.5×, y ≈ 0.25× baseline.

    Returns dict with ``x`` (horizontal) and ``y`` (vertical) keys.
    """
    return {
        "x": pt_to_twips(baseline_pt * 0.5),
        "y": pt_to_twips(baseline_pt * 0.25),
    }


def table_cell_padding_pt(baseline_pt: float = DEFAULT_BASELINE_PT) -> dict[str, float]:
    """Table cell padding in points: x ≈ 0.5×, y ≈ 0.25× baseline."""
    return {
        "left": baseline_pt * 0.5,
        "right": baseline_pt * 0.5,
        "top": baseline_pt * 0.25,
        "bottom": baseline_pt * 0.25,
    }


def hyphenation_zone_twips(baseline_pt: float = DEFAULT_BASELINE_PT) -> int:
    """Hyphenation zone ≈ 1.5× baseline grid."""
    return pt_to_twips(baseline_pt * 1.5)


def column_gutter_twips(baseline_pt: float = DEFAULT_BASELINE_PT) -> int:
    """Column gutter = 3× baseline grid."""
    return pt_to_twips(baseline_pt * 3)


def doc_grid_line_pitch_twips(baseline_pt: float = DEFAULT_BASELINE_PT) -> int:
    """Document grid line pitch = 1.5× baseline."""
    return pt_to_twips(baseline_pt * 1.5)


def inline_image_emu(content_width_emu: int = 0) -> tuple[int, int]:
    """Default inline image size in EMU.

    Uses 50% of content width (or 4 inches if unknown) with 4:3 aspect.
    """
    if content_width_emu > 0:
        cx = content_width_emu // 2
    else:
        cx = 4 * EMU_PER_INCH  # 3657600
    cy = cx * 3 // 4  # 4:3 aspect
    return cx, cy


# Word fallback margins when no PageGeometry is provided
def word_fallback_margin_twips(baseline_pt: float = DEFAULT_BASELINE_PT) -> int:
    """Word margin fallback = 4× baseline grid."""
    return pt_to_twips(baseline_pt * 4)


def word_fallback_header_footer_twips(baseline_pt: float = DEFAULT_BASELINE_PT) -> int:
    """Word header/footer distance = 2× baseline grid."""
    return pt_to_twips(baseline_pt * 2)


__all__ = [
    # Baseline
    "DEFAULT_BASELINE_PT",
    "DEFAULT_BASELINE_EMU",
    # Slide dimensions (from aspect_ratios registry)
    "SLIDE_16_9_WIDTH_EMU",
    "SLIDE_16_9_HEIGHT_EMU",
    "SLIDE_16_10_WIDTH_EMU",
    "SLIDE_16_10_HEIGHT_EMU",
    "SLIDE_4_3_WIDTH_EMU",
    "SLIDE_4_3_HEIGHT_EMU",
    # Document page sizes (from aspect_ratios registry)
    "A4_WIDTH_EMU",
    "A4_HEIGHT_EMU",
    "A4_LANDSCAPE_WIDTH_EMU",
    "A4_LANDSCAPE_HEIGHT_EMU",
    "LETTER_WIDTH_EMU",
    "LETTER_HEIGHT_EMU",
    "LETTER_LANDSCAPE_WIDTH_EMU",
    "LETTER_LANDSCAPE_HEIGHT_EMU",
    # Grid-derived functions
    "list_indent_twips",
    "list_hanging_twips",
    "quote_border_width_twips",
    "quote_indent_twips",
    "tab_stop_twips",
    "table_cell_padding_twips",
    "table_cell_padding_pt",
    "hyphenation_zone_twips",
    "column_gutter_twips",
    "doc_grid_line_pitch_twips",
    "inline_image_emu",
    "word_fallback_margin_twips",
    "word_fallback_header_footer_twips",
]
