"""Design system resolution - typography, color, and spacing calculations.

This package provides the core design token resolution engine and supporting
utilities for generating OOXML-compatible typography and color tokens.

Example:
    from tokenmoulds.design import DesignResolutionEngine, ScaleRatio

    engine = DesignResolutionEngine(
        fonts=font_config,
        brand=brand_config,
        locale="en-US",
        colors=color_inputs,
        scale_ratio=ScaleRatio.MAJOR_THIRD,
    )
    design = engine.resolve()
"""

from importlib import import_module as _im
from typing import Any as _Any

__all__ = [
    # Engine
    "DesignResolutionEngine",
    "ResolvedDesign",
    # Policy-aware engine
    "PolicyAwareDesignEngine",
    "DesignConfig",
    "create_design_engine",
    # Data classes
    "Baseline",
    "RoleTypography",
    "TypeScaleStep",
    "SpacingScale",
    # Enums
    "ScaleRatio",
    "LineHeightMode",
    # Roles
    "ROLE_SCALE_MAP",
    # Units
    "units",
    # Submodules
    "engine",
    "roles",
    "policy",
    "services",
]

# Symbol -> module mapping for lazy loading
_symbol_map = {
    # engine.py exports
    "DesignResolutionEngine": "engine",
    "ResolvedDesign": "engine",
    "Baseline": "engine",
    "RoleTypography": "engine",
    "TypeScaleStep": "engine",
    "SpacingScale": "engine",
    "ScaleRatio": "engine",
    "LineHeightMode": "engine",
    # roles.py exports
    "ROLE_SCALE_MAP": "roles",
    # policy_adapter.py exports
    "PolicyAwareDesignEngine": "policy_adapter",
    "DesignConfig": "policy_adapter",
    "create_design_engine": "policy_adapter",
}

# Submodule mapping
_module_map = {
    "engine": "engine",
    "roles": "roles",
    "units": "units",
    "policy": "policy",
    "services": "services",
}


def __getattr__(name: str) -> _Any:  # PEP 562
    """Lazy attribute loading for faster imports."""
    mod = _symbol_map.get(name)
    if mod is not None:
        module = _im(f".{mod}", __name__)
        return getattr(module, name)

    pkg = _module_map.get(name)
    if pkg is not None:
        return _im(f".{pkg}", __name__)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(globals().keys()) | set(__all__))
