# Word style → semantic role mapping
# First-class mapping for Word templates

WORD_STYLE_ROLE_MAP = {
    "Normal": "text.body.primary",
    "Heading1": "display.section",
    "Heading2": "display.section",
    "Heading3": "display.subsection",
    "Heading4": "display.subsection",
    "Heading5": "display.subsection",
    "Heading6": "display.subsection",
    "Heading7": "display.subsection",
    "Heading8": "display.subsection",
    "Heading9": "display.subsection",
    "Quote": "text.body.secondary",
    "ListParagraph": "text.body.primary",
    "Hyperlink": "inline.semantic",
}
