"""Quick heuristics for palette QA feedback."""

from __future__ import annotations

from typing import Dict, List


def evaluate_palette(summary: Dict[str, object]) -> List[str]:
    warnings: List[str] = []
    unique = summary.get("unique")
    if isinstance(unique, int) and unique < 4:
        warnings.append("Palette exposes fewer than four unique colors.")

    complexity = summary.get("complexity")
    if isinstance(complexity, (int, float)) and complexity < 0.25:
        warnings.append(
            "Color complexity below 0.25; consider widening contrast spread."
        )

    max_distance = summary.get("max_oklab_distance")
    if isinstance(max_distance, (int, float)) and max_distance < 0.15:
        warnings.append(
            "OKLab distance is tight (<0.15); accents may appear indistinguishable."
        )

    return warnings


__all__ = ["evaluate_palette"]
