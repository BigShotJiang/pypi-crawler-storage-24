"""
TokenMoulds E2E Testing Framework.

Provides comprehensive testing infrastructure for OOXML template validation
using GitHub Actions and LibreOffice headless integration.
"""

from tokenmoulds import __version__ as __version__  # noqa: F401 — re-export

__author__ = "TokenMoulds Team"

from .libreoffice_setup import install_libreoffice, validate_headless_mode
from .environment_setup import setup_python_environment, validate_github_environment
from .e2e_workflow import execute_complete_workflow

# Baseline management and visual comparison
from .baseline_manager import (
    create_baseline_structure,
    store_baseline_image,
    retrieve_baseline_image,
    validate_baseline_hash,
    update_baseline_image,
    update_baseline_with_backup,
)

from .visual_comparison import (
    load_image_safely,
    normalize_images,
    calculate_perceptual_hash_distance,
    calculate_pixel_difference_count,
    calculate_structural_similarity,
    generate_diff_image,
    compare_images,
    comprehensive_comparison,
    validate_comparison_environment,
)

_has_screenshot_capture = False
try:
    from .screenshot_capture import (
        capture_template_screenshot,
        convert_template_to_pdf,
        convert_pdf_to_png,
        validate_libreoffice_availability,
    )

    _has_screenshot_capture = True
except ImportError:
    # Screenshot capture module may not be available if LibreOffice not installed
    pass

__all__ = [
    "install_libreoffice",
    "validate_headless_mode",
    "setup_python_environment",
    "validate_github_environment",
    "execute_complete_workflow",
    # Baseline management
    "create_baseline_structure",
    "store_baseline_image",
    "retrieve_baseline_image",
    "validate_baseline_hash",
    "update_baseline_image",
    "update_baseline_with_backup",
    # Visual comparison
    "load_image_safely",
    "normalize_images",
    "calculate_perceptual_hash_distance",
    "calculate_pixel_difference_count",
    "calculate_structural_similarity",
    "generate_diff_image",
    "compare_images",
    "comprehensive_comparison",
    "validate_comparison_environment",
]

if _has_screenshot_capture:
    __all__ += [
        "capture_template_screenshot",
        "convert_template_to_pdf",
        "convert_pdf_to_png",
        "validate_libreoffice_availability",
    ]
