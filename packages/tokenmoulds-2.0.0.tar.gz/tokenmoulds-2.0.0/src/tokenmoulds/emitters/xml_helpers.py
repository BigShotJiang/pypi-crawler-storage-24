"""Shared XML manipulation helpers using lxml.

Facade module that re-exports XML helper functions used by emitters.
"""

from __future__ import annotations

from tokenmoulds.emitters.xml_constants import (
    A_NS,
    CT_NS,
    DC_NS,
    DCTERMS_NS,
    REL_NS,
    R_NS,
    THEMEML_NS,
)
from tokenmoulds.emitters.xml_helpers_colors import (
    add_color_modifiers,
    create_color_element,
    create_color_from_ref,
    normalize_hex_color,
    set_color_slot,
    set_color_value,
)
from tokenmoulds.emitters.xml_helpers_effects import (
    create_bevel,
    create_custom_geometry,
    create_effect_list,
    create_effect_style,
    create_glow,
    create_inner_shadow,
    create_outer_shadow,
    create_reflection,
    create_scene3d,
    create_soft_edge,
    create_sp3d,
)
from tokenmoulds.emitters.xml_helpers_search import (
    find_element,
    find_elements,
    set_element_attr,
)
from tokenmoulds.emitters.xml_helpers_template import (
    clone_template_element,
    parse_xml,
    remove_template_elements,
    replace_placeholders,
    serialize_tree,
)
from tokenmoulds.emitters.xml_helpers_theme import (
    apply_extra_color_schemes,
    create_extra_color_scheme,
    set_font_typeface,
    set_scheme_name,
    set_theme_name,
)


__all__ = [
    # Namespaces
    "A_NS",
    "R_NS",
    "CT_NS",
    "REL_NS",
    "DC_NS",
    "DCTERMS_NS",
    "THEMEML_NS",
    # Element finding
    "find_element",
    "find_elements",
    "set_element_attr",
    # Color manipulation
    "normalize_hex_color",
    "set_color_value",
    "set_color_slot",
    "add_color_modifiers",
    "create_color_element",
    "create_color_from_ref",
    # Effect primitives
    "create_outer_shadow",
    "create_inner_shadow",
    "create_glow",
    "create_reflection",
    "create_soft_edge",
    "create_effect_list",
    "create_bevel",
    "create_sp3d",
    "create_scene3d",
    "create_effect_style",
    # Custom geometry
    "create_custom_geometry",
    # Extra color schemes
    "create_extra_color_scheme",
    "apply_extra_color_schemes",
    # Font manipulation
    "set_font_typeface",
    # Placeholder replacement
    "replace_placeholders",
    # Template cloning (SSOT pattern)
    "clone_template_element",
    "remove_template_elements",
    # Serialization
    "serialize_tree",
    "parse_xml",
    # Scheme helpers
    "set_scheme_name",
    "set_theme_name",
]
