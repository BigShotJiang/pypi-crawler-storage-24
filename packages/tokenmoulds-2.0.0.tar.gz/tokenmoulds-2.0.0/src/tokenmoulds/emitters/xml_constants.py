"""Shared XML namespace constants for OOXML emitters.

Re-exports from the canonical registry at ``ooxml.namespaces`` (ADR 020).
Emitter code uses short aliases (A_NS, R_NS, etc.) for brevity.
"""

from __future__ import annotations

from tokenmoulds.ooxml.namespaces import (
    CONTENT_TYPES as CT_NS,
    DC as DC_NS,
    DCTERMS as DCTERMS_NS,
    DRAWINGML as A_NS,
    RELATIONSHIPS as REL_NS,
    RELATIONSHIPS_DOC as R_NS,
    THEMEML as THEMEML_NS,
)

__all__ = ["A_NS", "R_NS", "CT_NS", "REL_NS", "DC_NS", "DCTERMS_NS", "THEMEML_NS"]
