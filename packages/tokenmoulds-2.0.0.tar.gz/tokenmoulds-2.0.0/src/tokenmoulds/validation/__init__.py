"""Unified validation framework for TokenMoulds.

Provides a single error model used across all validators:
OOXML/ODF structure checks, SuperTheme quality rules, and
openxml-audit integration.
"""

from tokenmoulds.validation.model import (
    Severity,
    ValidationIssue,
    ValidationReport,
)
from tokenmoulds.validation.ooxml import (
    OOXMLDeepValidationOutcome,
    normalize_ooxml_format,
    supports_ooxml_deep_validation,
    validate_ooxml_bytes,
    validate_ooxml_file,
)

__all__ = [
    "Severity",
    "ValidationIssue",
    "ValidationReport",
    "OOXMLDeepValidationOutcome",
    "normalize_ooxml_format",
    "supports_ooxml_deep_validation",
    "validate_ooxml_bytes",
    "validate_ooxml_file",
]
