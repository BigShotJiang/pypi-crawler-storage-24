"""Brand control plane — manifest loading and source resolution.

Implements ADR 026 (F3): GitHub-native brand control.
"""

from __future__ import annotations

from tokenmoulds.brand.manifest import (
    BrandManifest,
    load_manifest,
    manifest_to_build_config,
)

__all__ = [
    "BrandManifest",
    "load_manifest",
    "manifest_to_build_config",
]
