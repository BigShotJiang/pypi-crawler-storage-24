"""Locale data constants for the DTCG generator."""

from __future__ import annotations

from typing import Any, Dict

_PUNCT_EN = {
    "quotes": {"open": "\u201c", "close": "\u201d"},
    "single_quotes": {"open": "\u2018", "close": "\u2019"},
    "ellipsis": "\u2026",
    "em_dash": "\u2014",
    "en_dash": "\u2013",
}


def _ltr(
    paper: str,
    units: str,
    dec: str,
    thou: str,
    cur: str,
    dfmt: str,
    nfmt: str,
    punct: Dict[str, Any],
    **extra: Any,
) -> Dict[str, Any]:
    return {
        "paper_size": paper,
        "units": units,
        "decimal": dec,
        "thousands": thou,
        "currency": cur,
        "date_format": dfmt,
        "text_direction": "ltr",
        "reading_order": "left-to-right",
        "number_format": nfmt,
        "autotext_punctuation": punct,
        **extra,
    }


_PUNCT_DE = {
    "quotes": {"open": "\u201e", "close": "\u201c"},
    "single_quotes": {"open": "\u201a", "close": "\u2018"},
    "ellipsis": "\u2026",
    "em_dash": "\u2014",
    "en_dash": "\u2013",
}
_PUNCT_FR = {
    "quotes": {"open": "\u00ab", "close": "\u00bb"},
    "single_quotes": {"open": "\u2018", "close": "\u2019"},
    "ellipsis": "\u2026",
    "em_dash": "\u2014",
    "en_dash": "\u2013",
}
_PUNCT_JP = {
    "quotes": {"open": "\u300c", "close": "\u300d"},
    "single_quotes": {"open": "\u300e", "close": "\u300f"},
    "ellipsis": "\u2026",
    "em_dash": "\u2014",
    "en_dash": "\u2013",
    "full_width_forms": True,
    "parentheses": {"open": "\uff08", "close": "\uff09"},
    "brackets": {"open": "\uff3b", "close": "\uff3d"},
    "period": "\u3002",
    "comma": "\u3001",
}

LOCALE_DATA: Dict[str, Dict[str, Any]] = {
    "GB": _ltr("A4", "metric", ".", ",", "\u00a3", "dd/mm/yyyy", "#,##0.00", _PUNCT_EN),
    "US": _ltr(
        "Letter", "imperial", ".", ",", "$", "mm/dd/yyyy", "#,##0.00", _PUNCT_EN
    ),
    "DE": _ltr("A4", "metric", ",", ".", "\u20ac", "dd.mm.yyyy", "#.##0,00", _PUNCT_DE),
    "FR": _ltr("A4", "metric", ",", " ", "\u20ac", "dd/mm/yyyy", "# ##0,00", _PUNCT_FR),
    "JP": _ltr(
        "A4",
        "metric",
        ".",
        ",",
        "\u00a5",
        "yyyy/mm/dd",
        "#,##0",
        _PUNCT_JP,
        font_fallback=["Noto Sans CJK JP", "Yu Gothic", "Meiryo"],
        vertical_writing=True,
        line_break_rules="japanese",
    ),
    "HE": {
        "paper_size": "A4",
        "units": "metric",
        "decimal": ".",
        "thousands": ",",
        "currency": "\u20aa",
        "date_format": "dd/mm/yyyy",
        "text_direction": "rtl",
        "reading_order": "right-to-left",
        "number_format": "#,##0.00",
        "autotext_punctuation": _PUNCT_EN,
        "font_fallback": ["Noto Sans Hebrew", "David", "Times New Roman"],
        "bidi_support": True,
        "mixed_direction": True,
    },
}
