"""Canonical style definitions with derivation formulas.

This module defines all styleable elements in Office documents with
formulas that derive their values from brand inputs.

The style catalog follows the ODF/OOXML style families:
- paragraph: 138 styles (headings, body, TOC, lists, etc.)
- character: 32 styles (emphasis, code, footnote, etc.)
- table: 29 styles
- page: 12 styles
- list: 13 styles
- frame: 10 styles

Each style is defined with:
- Canonical name (format-agnostic)
- OOXML mapping (Word styleId)
- ODF mapping (style:name)
- Properties with derivation formulas from inputs
"""

from tokenmoulds.dtcg.styles.paragraph import (
    build_paragraph_styles,
    ALL_PARAGRAPH_STYLES,
    HEADING_STYLES,
)
from tokenmoulds.dtcg.styles.character import (
    build_character_styles,
    ALL_CHARACTER_STYLES,
)

__all__ = [
    "build_paragraph_styles",
    "build_character_styles",
    "ALL_PARAGRAPH_STYLES",
    "ALL_CHARACTER_STYLES",
    "HEADING_STYLES",
]
