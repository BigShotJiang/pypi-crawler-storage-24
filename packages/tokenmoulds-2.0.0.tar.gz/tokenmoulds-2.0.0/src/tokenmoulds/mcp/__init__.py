"""TokenMoulds MCP Server.

Model Context Protocol server for AI-powered document generation.
Enables AI agents to generate professionally styled Office documents
using TokenMoulds' design token system.

Import of the actual server module is deferred so
``tokenmoulds.mcp.tools.*`` can be used without the optional ``mcp``
runtime dependency installed.
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from tokenmoulds.mcp.server import create_server, run_server

__all__ = ["create_server", "run_server"]

_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "create_server": (".server", "create_server"),
    "run_server": (".server", "run_server"),
}


def __getattr__(name: str) -> Any:
    if name in _LAZY_IMPORTS:
        module_path, attr_name = _LAZY_IMPORTS[name]
        module = importlib.import_module(module_path, __package__)
        value = getattr(module, attr_name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
