"""Public API for MCP tool callables and schemas."""

from __future__ import annotations

import importlib
from typing import Any

__all__ = [
    "create_document",
    "configure_brand",
    "list_styles",
    "DOCUMENT_TOOL_SCHEMA",
    "BRAND_TOOL_SCHEMA",
    "STYLES_TOOL_SCHEMA",
]


_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "create_document": (".document", "create_document"),
    "DOCUMENT_TOOL_SCHEMA": (".document", "DOCUMENT_TOOL_SCHEMA"),
    "configure_brand": (".brand", "configure_brand"),
    "list_styles": (".brand", "list_styles"),
    "BRAND_TOOL_SCHEMA": (".brand", "BRAND_TOOL_SCHEMA"),
    "STYLES_TOOL_SCHEMA": (".brand", "STYLES_TOOL_SCHEMA"),
}


def __getattr__(name: str) -> Any:
    if name in _LAZY_IMPORTS:
        module_path, attr_name = _LAZY_IMPORTS[name]
        module = importlib.import_module(module_path, __package__)
        value = getattr(module, attr_name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
