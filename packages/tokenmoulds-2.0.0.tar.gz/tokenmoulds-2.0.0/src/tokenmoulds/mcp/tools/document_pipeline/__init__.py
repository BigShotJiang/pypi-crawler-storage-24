"""Pipeline helpers used by MCP document creation tools."""
