"""Font embedding data types and utilities.

These types are shared between emitters and the font embedding service
to avoid circular imports.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from pathlib import Path


@dataclass
class EmbeddedFont:
    """Represents a font to be embedded in an OOXML package.

    This dataclass is format-agnostic but includes fields for
    format-specific metadata (font_key for Word, fntdata for PowerPoint).
    """

    family_name: str
    font_path: Path
    relationship_id: str
    is_bold: bool = False
    is_italic: bool = False

    # Word-specific (ODTTF format)
    font_key: str = ""  # GUID for obfuscation
    odttf_filename: str = ""

    # PowerPoint-specific (EOT/fntdata format)
    fntdata_filename: str = ""


def obfuscate_font_odttf(font_data: bytes, guid: uuid.UUID) -> bytes:
    """Apply ODTTF XOR obfuscation to font data.

    Word uses GUID-based XOR obfuscation on the first 32 bytes of embedded fonts.
    The GUID is stored as a font key in fontTable.xml.

    Args:
        font_data: Raw TTF font bytes
        guid: UUID for obfuscation key

    Returns:
        Obfuscated font bytes
    """
    key = guid.bytes_le  # Little-endian GUID bytes
    obfuscated = bytearray(font_data)

    # XOR first 32 bytes with the GUID (cycling through 16-byte key)
    for i in range(min(32, len(obfuscated))):
        obfuscated[i] ^= key[i % 16]

    return bytes(obfuscated)
