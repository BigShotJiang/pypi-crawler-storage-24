"""Superfamily monospace font resolution.

Maps font families to their monospace counterpart within the same
superfamily. When a brand uses e.g. "IBM Plex Sans", the matched
monospace is "IBM Plex Mono" — giving a visually cohesive code style.

Resolution order:
  1. Explicit ``mono`` key in font_pair dict
  2. Superfamily match from body font
  3. Superfamily match from heading font
  4. Fallback: "Courier New"
"""

from __future__ import annotations

# Maps a font family name to its monospace sibling.
# Keys are normalized to lowercase for case-insensitive lookup.
_SUPERFAMILY_MONO: dict[str, str] = {
    # IBM Plex
    "ibm plex sans": "IBM Plex Mono",
    "ibm plex serif": "IBM Plex Mono",
    "ibm plex mono": "IBM Plex Mono",
    # Source / Adobe
    "source sans 3": "Source Code Pro",
    "source sans pro": "Source Code Pro",
    "source serif 4": "Source Code Pro",
    "source serif pro": "Source Code Pro",
    "source code pro": "Source Code Pro",
    # Noto
    "noto sans": "Noto Sans Mono",
    "noto serif": "Noto Sans Mono",
    "noto sans mono": "Noto Sans Mono",
    # Fira
    "fira sans": "Fira Code",
    "fira code": "Fira Code",
    "fira mono": "Fira Mono",
    # JetBrains
    "jetbrains mono": "JetBrains Mono",
    # Inter → use Recursive (same design philosophy: variable, geometric)
    "inter": "Recursive",
    # Roboto
    "roboto": "Roboto Mono",
    "roboto slab": "Roboto Mono",
    "roboto mono": "Roboto Mono",
    "roboto flex": "Roboto Mono",
    "roboto condensed": "Roboto Mono",
    # PT family
    "pt sans": "PT Mono",
    "pt serif": "PT Mono",
    "pt mono": "PT Mono",
    # Ubuntu
    "ubuntu": "Ubuntu Mono",
    "ubuntu sans": "Ubuntu Sans Mono",
    "ubuntu mono": "Ubuntu Mono",
    "ubuntu sans mono": "Ubuntu Sans Mono",
    # Inconsolata (standalone mono, maps to itself)
    "inconsolata": "Inconsolata",
    # Work Sans → Space Mono (geometric sans → geometric mono)
    "work sans": "Space Mono",
    "space mono": "Space Mono",
    # DM Sans → DM Mono
    "dm sans": "DM Mono",
    "dm serif display": "DM Mono",
    "dm serif text": "DM Mono",
    "dm mono": "DM Mono",
    # Overpass
    "overpass": "Overpass Mono",
    "overpass mono": "Overpass Mono",
    # Red Hat
    "red hat display": "Red Hat Mono",
    "red hat text": "Red Hat Mono",
    "red hat mono": "Red Hat Mono",
    # Cascadia
    "cascadia code": "Cascadia Code",
    "cascadia mono": "Cascadia Mono",
    # SF (Apple system fonts)
    "sf pro": "SF Mono",
    "sf pro display": "SF Mono",
    "sf pro text": "SF Mono",
    "sf mono": "SF Mono",
}

_DEFAULT_MONO = "Courier New"


def resolve_monospace(
    body_font: str,
    heading_font: str,
    explicit_mono: str | None = None,
) -> str:
    """Resolve the monospace font for a font pair/triplet.

    Args:
        body_font: Body font family name
        heading_font: Heading font family name
        explicit_mono: Explicitly requested monospace font (highest priority)

    Returns:
        Monospace font family name
    """
    if explicit_mono:
        return explicit_mono

    # Try body font first (most common match)
    mono = _SUPERFAMILY_MONO.get(body_font.lower())
    if mono:
        return mono

    # Try heading font
    mono = _SUPERFAMILY_MONO.get(heading_font.lower())
    if mono:
        return mono

    return _DEFAULT_MONO
