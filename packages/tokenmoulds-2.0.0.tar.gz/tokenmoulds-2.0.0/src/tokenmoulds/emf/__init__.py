"""Lightweight EMF helpers lifted from svg2ooxml."""

from .blob import (
    DashPattern,
    EMFBlob,
    EMFBrushStyle,
    EMFHatchStyle,
    EMFRecordType,
    NULL_BRUSH_HANDLE,
    NULL_PEN_HANDLE,
)
from .packager import EMFMedia, EMFRelationshipManager

__all__ = [
    "DashPattern",
    "EMFBlob",
    "EMFBrushStyle",
    "EMFHatchStyle",
    "EMFRecordType",
    "NULL_BRUSH_HANDLE",
    "NULL_PEN_HANDLE",
    "EMFMedia",
    "EMFRelationshipManager",
]
