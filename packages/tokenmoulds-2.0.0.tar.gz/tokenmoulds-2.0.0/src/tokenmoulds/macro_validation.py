"""
Static VBA validation utilities.

Phase 3:
- Fail fast on forbidden APIs
- Pure text analysis (no execution)
"""

from __future__ import annotations

from pathlib import Path

# Allowed high-level VBA namespaces
ALLOWED_PREFIXES = [
    "Sub ",
    "Function ",
    "End Sub",
    "End Function",
    "Dim ",
    "Public ",
    "Private ",
    "Call ",
]

FORBIDDEN_PATTERNS = [
    "Shell(",
    "CreateObject(",
    "GetObject(",
    "WScript.",
    "ADODB.",
    "Scripting.FileSystemObject",
]


def validate_macro_sources(macros_root: Path) -> None:
    if not macros_root.exists():
        return

    for bas in macros_root.rglob("*.bas"):
        text = bas.read_text(errors="ignore")
        for pattern in FORBIDDEN_PATTERNS:
            if pattern.lower() in text.lower():
                raise RuntimeError(f"Forbidden VBA API '{pattern}' found in {bas}")
