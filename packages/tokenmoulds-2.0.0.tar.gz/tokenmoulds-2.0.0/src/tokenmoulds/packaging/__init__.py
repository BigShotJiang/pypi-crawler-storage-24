"""Unified packaging layer for ZIP-based document formats.

Provides format-agnostic infrastructure for building OOXML and ODF packages:
- PackageManifest: Declarative package structure description
- PackageWriter: Mechanical ZIP assembly
- PackagingContext: ID allocation and content-hash deduplication (standalone utility)
- AssetRegistry: Accumulator → snapshot for fonts and media
"""

from tokenmoulds.packaging.assets import (
    AssetRegistry,
    AssetSnapshot,
    FontAsset,
    MediaAsset,
)
from tokenmoulds.packaging.context import PackagingContext
from tokenmoulds.packaging.manifest import ManifestEntry, PackageManifest
from tokenmoulds.packaging.types import CompressionMode, PackagedEntry
from tokenmoulds.packaging.writer import PackageWriter

__all__ = [
    "AssetRegistry",
    "AssetSnapshot",
    "CompressionMode",
    "FontAsset",
    "ManifestEntry",
    "MediaAsset",
    "PackagedEntry",
    "PackageManifest",
    "PackageWriter",
    "PackagingContext",
]
