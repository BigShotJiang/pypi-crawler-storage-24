RESET = "\033[0m"

# Standard log levels
DEBUG = "\033[36m"    # Cyan
INFO = "\033[32m"     # Green
WARNING = "\033[33m"  # Yellow
ERROR = "\033[31m"    # Red
CRITICAL = "\033[41m" # Red background

# Extra useful ones
SUCCESS = "\033[92m"  # Bright Green
FAIL = "\033[91m"     # Bright Red

# Optional colors
BLUE = "\033[34m"
MAGENTA = "\033[35m"
WHITE = "\033[37m"
GRAY = "\033[90m"