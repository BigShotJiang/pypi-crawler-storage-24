__all__ = ["init_logfile", "commit_file", "clear_logs", "log_to_file"]


logs = []
log_file = True
auto_save=True
filename='logs'
ext='.log'
def log_to_file(logs, name, ext):
    try:
        filename = name + ext
        with open(filename, "a") as f:
            f.write(logs)
    except OSError as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def init_logfile(name='logs', extension='.log', clear=True):
    global log_file, auto_save, filename, ext
    filename = name
    ext = extension
    mode = "w" if clear else "a"
    with open(filename + ext, mode) as f:
        pass
    log_file = True
    auto_save = False

def commit_file(name=None, extension=None):
    target_name = name if name is not None else filename
    target_ext = extension if extension is not None else ext
    with open(target_name + target_ext, "a") as f:
        for eachlog in logs:
            f.write(eachlog)
    logs.clear()

def clear_logs():
    logs.clear()