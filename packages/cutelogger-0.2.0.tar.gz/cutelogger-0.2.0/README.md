# CuteLogger

A super lightweight and simple colored logging utility for Python.  
No setup, no dependencies — just import and go.

## Why?

Sometimes you don’t need Python’s full logging system.  
You just want quick, clean, colored output.

## Features

- Minimal and fast
- Colored logs (ANSI)
- Multiple log levels
- Built-in help guide
- Zero dependencies

## Installation

```bash
pip install cutelogger
```

# Usage
```python
from cutelogger import log, help

log("This is debug", "debug")
log("All good", "info")
log("Something off", "warning")
log("Something broke", "error")
log("System dying", "critical")

log("Task done", "success")
log("Task failed", "fail")
```
## Log States

| State     | Color         | Use Case                  |
|-----------|--------------|--------------------------|
| debug     | cyan         | developer info           |
| info      | green        | general info             |
| warning   | yellow       | something might go wrong |
| error     | red          | something failed         |
| critical  | red bg       | serious failure          |
| success   | bright green | success                  |
| fail      | bright red   | failure                  |
| blue      | blue         | custom logs              |
| magenta   | magenta      | rare logs                |
| white     | white        | default text             |
| gray      | gray         | low priority             | 

# Help
```python
help()          # shows everything
help("error")   # shows specific
```

# Example
```python
log("Server started", "success")
log("Fetching data...", "info")
log("Timeout warning", "warning")
```

# Notes
- Works in terminals that support ANSI colors

- Windows may need color support enabled

# Author
Trooff
