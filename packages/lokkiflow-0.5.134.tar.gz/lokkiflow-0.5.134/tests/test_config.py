"""Unit tests for lokki configuration module."""

from pathlib import Path

import pytest

from lokki.config import (
    BatchConfig,
    LambdaConfig,
    LokkiConfig,
    _deep_merge,
    _load_toml,
    load_config,
)


class TestDeepMerge:
    """Tests for _deep_merge function."""

    def test_scalar_override(self) -> None:
        """Test that scalar values in override replace base values."""
        base = {"key": "base_value"}
        override = {"key": "override_value"}
        result = _deep_merge(base, override)
        assert result["key"] == "override_value"

    def test_list_replacement(self) -> None:
        """Test that lists are replaced entirely, not concatenated."""
        base = {"items": [1, 2, 3]}
        override = {"items": [4, 5]}
        result = _deep_merge(base, override)
        assert result["items"] == [4, 5]

    def test_nested_dict_merge(self) -> None:
        """Test that nested dicts are merged recursively."""
        base = {"parent": {"child1": "base1", "child2": "base2"}}
        override = {"parent": {"child1": "override1"}}
        result = _deep_merge(base, override)
        assert result["parent"]["child1"] == "override1"
        assert result["parent"]["child2"] == "base2"

    def test_missing_keys_in_base(self) -> None:
        """Test that new keys in override are added."""
        base = {"existing": "value"}
        override = {"new": "added"}
        result = _deep_merge(base, override)
        assert result["existing"] == "value"
        assert result["new"] == "added"

    def test_missing_keys_in_override(self) -> None:
        """Test that missing keys in override preserve base values."""
        base = {"keep": "this", "replace": "old"}
        override = {"replace": "new"}
        result = _deep_merge(base, override)
        assert result["keep"] == "this"
        assert result["replace"] == "new"

    def test_empty_override(self) -> None:
        """Test that empty override returns copy of base."""
        base = {"key": "value"}
        override: dict = {}
        result = _deep_merge(base, override)
        assert result == base
        assert result is not base

    def test_empty_base(self) -> None:
        """Test that empty base returns copy of override."""
        base: dict = {}
        override = {"key": "value"}
        result = _deep_merge(base, override)
        assert result == override
        assert result is not override


class TestLoadToml:
    """Tests for _load_toml function."""

    def test_load_existing_file(self, tmp_path: Path) -> None:
        """Test loading an existing TOML file."""
        config_file = tmp_path / "config.toml"
        config_file.write_text('key = "value"\nnested = { item = 123 }')
        result = _load_toml(config_file)
        assert result == {"key": "value", "nested": {"item": 123}}

    def test_load_nonexistent_file(self) -> None:
        """Test loading a non-existent file returns empty dict."""
        result = _load_toml(Path("/nonexistent/path/config.toml"))
        assert result == {}

    def test_load_empty_file(self, tmp_path: Path) -> None:
        """Test loading an empty TOML file returns empty dict."""
        config_file = tmp_path / "empty.toml"
        config_file.write_text("")
        result = _load_toml(config_file)
        assert result == {}


class TestLambdaConfig:
    """Tests for LambdaConfig dataclass."""

    def test_default_values(self) -> None:
        """Test default values for LambdaConfig."""
        config = LambdaConfig()
        assert config.package_type == "image"
        assert config.timeout == 900
        assert config.memory == 512
        assert config.image_tag == "latest"
        assert config.env == {}

    def test_custom_values(self) -> None:
        """Test custom values for LambdaConfig."""
        config = LambdaConfig(
            package_type="zip",
            timeout=300,
            memory=256,
            image_tag="v1.0",
            env={"KEY": "val"},
        )
        assert config.package_type == "zip"
        assert config.timeout == 300

    def test_invalid_package_type(self) -> None:
        """Test invalid package_type raises ValueError."""
        with pytest.raises(ValueError, match="package_type must be"):
            LambdaConfig(package_type="invalid")

    def test_invalid_timeout_too_low(self) -> None:
        """Test timeout < 1 raises ValueError."""
        with pytest.raises(ValueError, match="timeout must be between"):
            LambdaConfig(timeout=0)

    def test_invalid_timeout_too_high(self) -> None:
        """Test timeout > 900 raises ValueError."""
        with pytest.raises(ValueError, match="timeout must be between"):
            LambdaConfig(timeout=901)

    def test_invalid_memory_too_low(self) -> None:
        """Test memory < 128 raises ValueError."""
        with pytest.raises(ValueError, match="memory must be between"):
            LambdaConfig(memory=64)

    def test_invalid_memory_too_high(self) -> None:
        """Test memory > 10240 raises ValueError."""
        with pytest.raises(ValueError, match="memory must be between"):
            LambdaConfig(memory=11000)

    def test_architecture_x86_64(self) -> None:
        """Test default x86_64 architecture."""
        config = LambdaConfig()
        assert config.architecture == "x86_64"

    def test_architecture_arm64(self) -> None:
        """Test arm64 architecture."""
        config = LambdaConfig(architecture="arm64")
        assert config.architecture == "arm64"

    def test_invalid_architecture(self) -> None:
        """Test invalid architecture raises ValueError."""
        with pytest.raises(ValueError, match="architecture must be"):
            LambdaConfig(architecture="invalid")


class TestBatchConfig:
    """Tests for BatchConfig dataclass."""

    def test_batch_config_defaults(self):
        config = BatchConfig()
        assert config.job_queue == ""
        assert config.job_definition_name == ""
        assert config.timeout_seconds == 3600
        assert config.vcpu == 2
        assert config.memory_mb == 4096
        assert config.image == ""
        assert config.architecture == "x86_64"

    def test_batch_config_arm64(self) -> None:
        """Test BatchConfig with arm64 architecture."""
        config = BatchConfig(architecture="arm64")
        assert config.architecture == "arm64"

    def test_batch_invalid_architecture(self) -> None:
        """Test invalid architecture raises ValueError."""
        with pytest.raises(ValueError, match="architecture must be"):
            BatchConfig(architecture="invalid")

    def test_batch_invalid_vcpu(self) -> None:
        """Test vcpu <= 0 raises ValueError."""
        with pytest.raises(ValueError, match="vcpu must be positive"):
            BatchConfig(vcpu=0)


class TestLokkiConfig:
    def test_default_values(self) -> None:
        """Test default values for LokkiConfig."""
        config = LokkiConfig()
        assert config.build_dir == "lokki-build"
        assert config.artifact_bucket == ""
        assert config.image_repository == ""
        assert config.stepfunctions_role == ""
        assert config.lambda_execution_role == ""
        assert config.aws_endpoint == ""
        assert config.lambda_cfg.package_type == "image"
        assert config.lambda_cfg.timeout == 900
        assert config.lambda_cfg.memory == 512

    def test_from_dict_minimal(self) -> None:
        """Test creating LokkiConfig from minimal dict."""
        config = LokkiConfig.from_dict({})
        assert config.build_dir == "lokki-build"
        assert config.artifact_bucket == ""
        assert config.image_repository == ""
        assert config.stepfunctions_role == ""
        assert config.lambda_execution_role == ""
        assert config.aws_endpoint == ""
        assert config.lambda_cfg.package_type == "image"
        assert config.lambda_cfg.timeout == 900
        assert config.lambda_cfg.memory == 512

    def test_from_dict_full(self) -> None:
        """Test creating LokkiConfig from full dict."""
        data = {
            "build_dir": "custom-build",
            "aws": {
                "artifact_bucket": "my-bucket",
                "image_repository": (
                    "123456789.dkr.ecr.us-east-1.amazonaws.com/myproject"
                ),
                "endpoint": "http://localhost:4566",
                "stepfunctions_role": "arn:aws:iam::123::role/sfn",
                "lambda_execution_role": "arn:aws:iam::123::role/lambda",
            },
            "lambda": {
                "package_type": "zip",
                "timeout": 600,
                "memory": 256,
                "image_tag": "v1.0",
                "env": {"LOG_LEVEL": "INFO"},
            },
            "logging": {
                "level": "DEBUG",
                "format": "json",
            },
        }
        config = LokkiConfig.from_dict(data)
        assert config.build_dir == "custom-build"
        assert config.artifact_bucket == "my-bucket"
        assert (
            config.image_repository
            == "123456789.dkr.ecr.us-east-1.amazonaws.com/myproject"
        )
        assert config.stepfunctions_role == "arn:aws:iam::123::role/sfn"
        assert config.lambda_execution_role == "arn:aws:iam::123::role/lambda"
        assert config.aws_endpoint == "http://localhost:4566"
        assert config.lambda_cfg.package_type == "zip"
        assert config.lambda_cfg.timeout == 600
        assert config.lambda_cfg.memory == 256
        assert config.lambda_cfg.image_tag == "v1.0"
        assert config.lambda_cfg.env == {"LOG_LEVEL": "INFO"}
        assert config.logging.level == "DEBUG"
        assert config.logging.format == "json"


class TestLoadConfig:
    """Tests for load_config function."""

    def test_load_config_with_no_files(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test load_config when no config files exist."""
        monkeypatch.setenv("LOKKI_ARTIFACT_BUCKET", "")
        monkeypatch.setenv("LOKKI_IMAGE_REPOSITORY", "")
        monkeypatch.setenv("LOKKI_AWS_ENDPOINT", "")
        monkeypatch.setenv("LOKKI_BUILD_DIR", "")

        with pytest.MonkeyPatch.context() as mp:
            mp.setattr(
                "lokki.config.GLOBAL_CONFIG_PATH", Path("/nonexistent/global.toml")
            )
            mp.setattr(
                "lokki.config.LOCAL_CONFIG_PATH", Path("/nonexistent/local.toml")
            )

            config = load_config()
            assert config.artifact_bucket == ""
            assert config.build_dir == "lokki-build"

    def test_load_config_env_overrides(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that environment variables override config file values."""
        monkeypatch.setenv("LOKKI_ARTIFACT_BUCKET", "env-bucket")
        monkeypatch.setenv("LOKKI_IMAGE_REPOSITORY", "env-repo")
        monkeypatch.setenv("LOKKI_AWS_ENDPOINT", "http://localhost:4566")
        monkeypatch.setenv("LOKKI_BUILD_DIR", "env-build")

        with pytest.MonkeyPatch.context() as mp:
            mp.setattr(
                "lokki.config.GLOBAL_CONFIG_PATH", Path("/nonexistent/global.toml")
            )
            mp.setattr(
                "lokki.config.LOCAL_CONFIG_PATH", Path("/nonexistent/local.toml")
            )

            config = load_config()
            assert config.artifact_bucket == "env-bucket"
            assert config.image_repository == "env-repo"
            assert config.aws_endpoint == "http://localhost:4566"
            assert config.build_dir == "env-build"

    def test_load_config_with_local_file(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test loading config with local config file."""
        local_config = tmp_path / "lokki.toml"
        local_config.write_text("[aws]\nartifact_bucket = 'local-bucket'")

        monkeypatch.setenv("LOKKI_ARTIFACT_BUCKET", "")
        monkeypatch.setenv("LOKKI_IMAGE_REPOSITORY", "")
        monkeypatch.setenv("LOKKI_AWS_ENDPOINT", "")
        monkeypatch.setenv("LOKKI_BUILD_DIR", "")

        with pytest.MonkeyPatch.context() as mp:
            mp.setattr(
                "lokki.config.GLOBAL_CONFIG_PATH", Path("/nonexistent/global.toml")
            )
            mp.setattr("lokki.config.LOCAL_CONFIG_PATH", local_config)

            config = load_config()
            assert config.artifact_bucket == "local-bucket"

    def test_load_config_env_batch_overrides(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test that batch environment variables override config."""
        monkeypatch.setenv("LOKKI_BATCH_JOB_QUEUE", "env-queue")
        monkeypatch.setenv("LOKKI_BATCH_JOB_DEFINITION", "env-definition")
        monkeypatch.setenv("LOKKI_AWS_REGION", "us-west-2")
        monkeypatch.setenv("LOKKI_LOG_LEVEL", "DEBUG")

        with pytest.MonkeyPatch.context() as mp:
            mp.setattr(
                "lokki.config.GLOBAL_CONFIG_PATH", Path("/nonexistent/global.toml")
            )
            mp.setattr(
                "lokki.config.LOCAL_CONFIG_PATH", Path("/nonexistent/local.toml")
            )

            config = load_config()
            assert config.batch_cfg.job_queue == "env-queue"
            assert config.batch_cfg.job_definition_name == "env-definition"
            assert config.aws_region == "us-west-2"
            assert config.logging.level == "DEBUG"

    def test_load_config_include_env_override(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test that LOKKI_INCLUDE_PATHS environment variable is parsed."""
        monkeypatch.setenv("LOKKI_INCLUDE_PATHS", "data/*.parquet,models/*.pkl")

        with pytest.MonkeyPatch.context() as mp:
            mp.setattr(
                "lokki.config.GLOBAL_CONFIG_PATH", Path("/nonexistent/global.toml")
            )
            mp.setattr(
                "lokki.config.LOCAL_CONFIG_PATH", Path("/nonexistent/local.toml")
            )

            config = load_config()
            assert config.include.paths == ["data/*.parquet", "models/*.pkl"]


class TestIncludeConfig:
    """Tests for IncludeConfig dataclass."""

    def test_default_values(self) -> None:
        """Test IncludeConfig default values."""
        from lokki.config import IncludeConfig

        config = IncludeConfig()
        assert config.paths == []

    def test_from_dict(self) -> None:
        """Test IncludeConfig from_dict."""
        from lokki.config import IncludeConfig, LokkiConfig

        d = {
            "include": {
                "paths": ["data/*.parquet", "config/*.json"],
            }
        }
        config = LokkiConfig.from_dict(d)
        assert config.include.paths == ["data/*.parquet", "config/*.json"]

    def test_from_dict_empty(self) -> None:
        """Test IncludeConfig from dict with no include section."""
        from lokki.config import IncludeConfig, LokkiConfig

        config = LokkiConfig.from_dict({})
        assert config.include.paths == []
