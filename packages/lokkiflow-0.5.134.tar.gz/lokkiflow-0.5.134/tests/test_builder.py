"""Unit tests for builder module."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import patch

from lokki.builder.builder import (
    Builder,
    _get_flow_module_name,
    _has_batch_steps,
    _has_lambda_steps,
)
from lokki.config import LokkiConfig
from lokki.decorators import step
from lokki.graph import FlowGraph


class TestHasLambdaSteps:
    """Tests for _has_lambda_steps helper."""

    def test_has_lambda_steps_with_task_entry(self) -> None:
        """Test returns True for TaskEntry with lambda job type."""

        @step
        def step1():
            pass

        step1_node = step1()
        graph = FlowGraph(name="test-flow", head=step1_node)

        assert _has_lambda_steps(graph) is True

    def test_has_lambda_steps_with_batch_entry(self) -> None:
        """Test returns False for TaskEntry with batch job type."""

        @step(job_type="batch")
        def batch_step():
            pass

        batch_node = batch_step()
        graph = FlowGraph(name="test-flow", head=batch_node)

        assert _has_lambda_steps(graph) is False

    def test_has_lambda_steps_with_map_open_entry(self) -> None:
        """Test returns True for MapOpenEntry with lambda steps."""

        @step
        def get_items():
            return [1, 2, 3]

        @step
        def process_item(item):
            return item * 2

        @step
        def aggregate(items):
            return items

        get_items_node = get_items()
        mapped = get_items_node.map(process_item).agg(aggregate)

        graph = FlowGraph(name="test-flow", head=mapped)

        assert _has_lambda_steps(graph) is True

    def test_has_lambda_steps_with_map_open_batch(self) -> None:
        """Test returns True for MapCloseEntry with lambda agg step."""

        @step
        def get_items():
            return [1, 2, 3]

        @step(job_type="batch")
        def process_batch(item):
            return item * 2

        @step
        def aggregate(items):
            return items

        get_items_node = get_items()
        mapped = get_items_node.map(process_batch).agg(aggregate)

        graph = FlowGraph(name="test-flow", head=mapped)

        assert _has_lambda_steps(graph) is True


class TestHasBatchSteps:
    """Tests for _has_batch_steps helper."""

    def test_has_batch_steps_with_task_entry(self) -> None:
        """Test returns True for TaskEntry with batch job type."""

        @step(job_type="batch")
        def batch_step():
            pass

        batch_node = batch_step()
        graph = FlowGraph(name="test-flow", head=batch_node)

        assert _has_batch_steps(graph) is True

    def test_has_batch_steps_with_lambda_entry(self) -> None:
        """Test returns False for TaskEntry with lambda job type."""

        @step
        def lambda_step():
            pass

        lambda_node = lambda_step()
        graph = FlowGraph(name="test-flow", head=lambda_node)

        assert _has_batch_steps(graph) is False

    def test_has_batch_steps_with_map_open_batch(self) -> None:
        """Test returns True for MapOpenEntry with batch steps."""

        @step
        def get_items():
            return [1, 2, 3]

        @step(job_type="batch")
        def process_batch(item):
            return item * 2

        @step
        def aggregate(items):
            return items

        get_items_node = get_items()
        mapped = get_items_node.map(process_batch).agg(aggregate)

        graph = FlowGraph(name="test-flow", head=mapped)

        assert _has_batch_steps(graph) is True

    def test_has_batch_steps_with_map_close_aggregate(self) -> None:
        """Test returns True for MapCloseEntry with batch agg step."""

        @step
        def get_items():
            return [1, 2, 3]

        @step
        def process(item):
            return item * 2

        @step(job_type="batch")
        def aggregate(items):
            return sum(items)

        get_items_node = get_items()
        mapped = get_items_node.map(process).agg(aggregate)

        graph = FlowGraph(name="test-flow", head=mapped)

        assert _has_batch_steps(graph) is True


class TestGetFlowModuleName:
    """Tests for _get_flow_module_name helper."""

    def test_with_flow_fn(self) -> None:
        """Test getting module name from flow function."""

        @step
        def my_flow() -> None:
            pass

        graph = FlowGraph(name="my-flow", head=my_flow)

        with patch("lokki.builder.builder._get_flow_module_path") as mock_path:
            mock_path.return_value = Path("/path/to/my_flow.py")
            name = _get_flow_module_name(my_flow, graph)
            assert name == "my_flow"

    def test_without_flow_fn(self) -> None:
        """Test getting module name from graph name."""

        @step
        def step1() -> None:
            pass

        graph = FlowGraph(name="my-test-flow", head=step1)
        name = _get_flow_module_name(None, graph)
        assert name == "my_test_flow"


class TestBuilderBuild:
    """Tests for Builder.build method."""

    def test_build_creates_directories(self) -> None:
        """Test that build creates required directories."""

        @step
        def step1() -> None:
            pass

        graph = FlowGraph(name="test-flow", head=step1)
        config = LokkiConfig()
        config.build_dir = "lokki-build"

        with tempfile.TemporaryDirectory() as tmpdir:
            config.build_dir = str(Path(tmpdir) / "lokki-build")

            Builder.build(graph, config, flow_fn=None)

            build_dir = Path(config.build_dir)
            assert build_dir.exists()
            assert (build_dir / "lambdas").exists()

    def test_build_creates_state_machine(self) -> None:
        """Test that build creates statemachine.json."""

        @step
        def step1() -> None:
            pass

        graph = FlowGraph(name="test-flow", head=step1)
        config = LokkiConfig()

        with tempfile.TemporaryDirectory() as tmpdir:
            config.build_dir = str(Path(tmpdir) / "lokki-build")

            Builder.build(graph, config, flow_fn=None)

            sm_path = Path(config.build_dir) / "statemachine.json"
            assert sm_path.exists()

            sm = json.loads(sm_path.read_text())
            assert "StartAt" in sm
            assert "States" in sm

    def test_build_creates_cloudformation_template(self) -> None:
        """Test that build creates template.yaml."""

        @step
        def step1() -> None:
            pass

        graph = FlowGraph(name="test-flow", head=step1)
        config = LokkiConfig()

        with tempfile.TemporaryDirectory() as tmpdir:
            config.build_dir = str(Path(tmpdir) / "lokki-build")

            Builder.build(graph, config, flow_fn=None)

            template_path = Path(config.build_dir) / "template.yaml"
            assert template_path.exists()

            content = template_path.read_text()
            assert "AWSTemplateFormatVersion" in content

    def test_build_with_multiple_steps(self) -> None:
        """Test build with multiple steps."""

        @step
        def step1() -> None:
            pass

        @step
        def step2() -> None:
            pass

        step1().next(step2)
        graph = FlowGraph(name="multi-step-flow", head=step2)
        config = LokkiConfig()

        with tempfile.TemporaryDirectory() as tmpdir:
            config.build_dir = str(Path(tmpdir) / "lokki-build")

            Builder.build(graph, config, flow_fn=None)

            sm_path = Path(config.build_dir) / "statemachine.json"
            sm = json.loads(sm_path.read_text())

            # Both steps should be in the state machine
            assert "Step1" in sm["States"] or "GetItems" in sm["States"]

    def test_build_lambda_zip_x86_64(self) -> None:
        """Test that ZIP Lambda build uses x86_64 platform."""

        @step
        def step1() -> None:
            pass

        graph = FlowGraph(name="test-flow", head=step1)
        config = LokkiConfig()
        config.lambda_cfg.package_type = "zip"

        with tempfile.TemporaryDirectory() as tmpdir:
            config.build_dir = str(Path(tmpdir) / "lokki-build")
            Builder.build(graph, config, flow_fn=None)

            template_path = Path(config.build_dir) / "template.yaml"
            content = template_path.read_text()
            assert "Architectures" in content
            assert "x86_64" in content

    def test_build_lambda_zip_arm64(self) -> None:
        """Test that ZIP Lambda build uses arm64 platform."""

        @step
        def step1() -> None:
            pass

        graph = FlowGraph(name="test-flow", head=step1)
        config = LokkiConfig()
        config.lambda_cfg.package_type = "zip"
        config.lambda_cfg.architecture = "arm64"

        with tempfile.TemporaryDirectory() as tmpdir:
            config.build_dir = str(Path(tmpdir) / "lokki-build")
            Builder.build(graph, config, flow_fn=None)

            template_path = Path(config.build_dir) / "template.yaml"
            content = template_path.read_text()
            assert "Architectures" in content
            assert "arm64" in content

    def test_build_lambda_image_x86_64(self) -> None:
        """Test that Image Lambda has x86_64 architecture."""

        @step
        def step1() -> None:
            pass

        graph = FlowGraph(name="test-flow", head=step1)
        config = LokkiConfig()
        config.lambda_cfg.package_type = "image"

        with tempfile.TemporaryDirectory() as tmpdir:
            config.build_dir = str(Path(tmpdir) / "lokki-build")
            Builder.build(graph, config, flow_fn=None)

            template_path = Path(config.build_dir) / "template.yaml"
            content = template_path.read_text()
            assert "Architectures" in content
            assert "x86_64" in content

    def test_build_lambda_image_arm64(self) -> None:
        """Test that Image Lambda has arm64 architecture."""

        @step
        def step1() -> None:
            pass

        graph = FlowGraph(name="test-flow", head=step1)
        config = LokkiConfig()
        config.lambda_cfg.package_type = "image"
        config.lambda_cfg.architecture = "arm64"

        with tempfile.TemporaryDirectory() as tmpdir:
            config.build_dir = str(Path(tmpdir) / "lokki-build")
            Builder.build(graph, config, flow_fn=None)

            template_path = Path(config.build_dir) / "template.yaml"
            content = template_path.read_text()
            assert "Architectures" in content
            assert "arm64" in content

    def test_build_batch_x86_64(self) -> None:
        """Test that Batch job has x86_64 platform capability."""

        @step(job_type="batch")
        def batch_step() -> None:
            pass

        @step
        def get_items() -> list[str]:
            return ["a"]

        get_items().map(batch_step).agg(batch_step)
        graph = FlowGraph(name="batch-flow", head=batch_step)
        config = LokkiConfig()

        with tempfile.TemporaryDirectory() as tmpdir:
            config.build_dir = str(Path(tmpdir) / "lokki-build")
            Builder.build(graph, config, flow_fn=None)

            template_path = Path(config.build_dir) / "template.yaml"
            content = template_path.read_text()
            assert "PlatformCapabilities" in content
            assert "X86_64" in content

    def test_build_batch_arm64(self) -> None:
        """Test that Batch job has ARM64 platform capability."""

        @step(job_type="batch")
        def batch_step() -> None:
            pass

        @step
        def get_items() -> list[str]:
            return ["a"]

        get_items().map(batch_step).agg(batch_step)
        graph = FlowGraph(name="batch-flow", head=batch_step)
        config = LokkiConfig()
        config.batch_cfg.architecture = "arm64"

        with tempfile.TemporaryDirectory() as tmpdir:
            config.build_dir = str(Path(tmpdir) / "lokki-build")
            Builder.build(graph, config, flow_fn=None)

            template_path = Path(config.build_dir) / "template.yaml"
            content = template_path.read_text()
            assert "PlatformCapabilities" in content
            assert "ARM64" in content


class TestIncludeConfiguration:
    """Tests for include configuration in builder."""

    def test_lambda_dockerfile_with_include(self, tmp_path: Path) -> None:
        """Test that Lambda Dockerfile includes COPY command for included files."""
        from lokki.builder.lambdafunction.lambda_pkg import (
            _generate_docker_packages,
        )
        from lokki.config import IncludeConfig, LambdaConfig, LokkiConfig

        flow_dir = tmp_path / "flow_dir"
        flow_dir.mkdir()

        data_dir = flow_dir / "data"
        data_dir.mkdir()
        (data_dir / "test.parquet").write_text("test data")
        (data_dir / "train.parquet").write_text("train data")

        flow_file = flow_dir / "flow.py"
        flow_file.write_text("# flow module")

        config = LokkiConfig()
        config.lambda_cfg = LambdaConfig(package_type="image")
        config.include = IncludeConfig(paths=["data/*.parquet"])

        lambdas_dir = tmp_path / "lambdas"
        lambdas_dir.mkdir()

        from types import FunctionType

        def mock_flow_fn() -> None:
            pass

        mock_flow_fn.__module__ = "test_flow"

        import sys
        from types import ModuleType

        mock_module = ModuleType("test_flow")
        mock_module.__file__ = str(flow_file)
        sys.modules["test_flow"] = mock_module

        try:
            _generate_docker_packages(
                graph=FlowGraph(name="test", head=None),
                config=config,
                lambdas_dir=lambdas_dir,
                flow_fn=mock_flow_fn,
            )

            dockerfile_content = (lambdas_dir / "Dockerfile").read_text()
            assert "COPY included/" in dockerfile_content
            assert "${LAMBDA_TASK_ROOT}" in dockerfile_content

            included_dir = lambdas_dir / "included"
            assert included_dir.exists()
            assert (included_dir / "test.parquet").exists()
            assert (included_dir / "train.parquet").exists()
        finally:
            del sys.modules["test_flow"]

    def test_lambda_dockerfile_without_include(self, tmp_path: Path) -> None:
        """Test that Lambda Dockerfile has no COPY command when no includes."""
        from lokki.builder.lambdafunction.lambda_pkg import (
            _generate_docker_packages,
        )
        from lokki.config import LambdaConfig, LokkiConfig

        config = LokkiConfig()
        config.lambda_cfg = LambdaConfig(package_type="image")
        config.include.paths = []

        lambdas_dir = tmp_path / "lambdas"
        lambdas_dir.mkdir()

        _generate_docker_packages(
            graph=FlowGraph(name="test", head=None),
            config=config,
            lambdas_dir=lambdas_dir,
            flow_fn=None,
        )

        dockerfile_content = (lambdas_dir / "Dockerfile").read_text()
        assert "COPY included/" not in dockerfile_content

    def test_batch_dockerfile_with_include(self, tmp_path: Path) -> None:
        """Test that Batch Dockerfile includes COPY command for included files."""
        from lokki.builder.batchjob.batch_pkg import (
            generate_batch_files,
        )
        from lokki.config import BatchConfig, IncludeConfig, LokkiConfig

        flow_dir = tmp_path / "flow_dir"
        flow_dir.mkdir()

        config_dir = flow_dir / "config"
        config_dir.mkdir()
        (config_dir / "settings.json").write_text('{"key": "value"}')

        flow_file = flow_dir / "flow.py"
        flow_file.write_text("# flow module")

        config = LokkiConfig()
        config.batch_cfg = BatchConfig()
        config.include = IncludeConfig(paths=["config/*.json"])

        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()

        def mock_flow_fn() -> None:
            pass

        mock_flow_fn.__module__ = "test_flow"

        import sys
        from types import ModuleType

        mock_module = ModuleType("test_flow")
        mock_module.__file__ = str(flow_file)
        sys.modules["test_flow"] = mock_module

        try:
            generate_batch_files(
                build_dir=batch_dir,
                config=config,
                flow_fn=mock_flow_fn,
            )

            dockerfile_content = (batch_dir / "Dockerfile").read_text()
            assert "COPY included/" in dockerfile_content

            included_dir = batch_dir / "included"
            assert included_dir.exists()
            assert (included_dir / "settings.json").exists()
        finally:
            del sys.modules["test_flow"]

    def test_include_no_files_match(self, tmp_path: Path, capsys) -> None:
        """Test that warning is printed when include pattern matches no files."""
        from lokki.builder.lambdafunction.lambda_pkg import (
            _copy_included_files,
        )
        from lokki.config import IncludeConfig, LokkiConfig

        flow_dir = tmp_path / "flow_dir"
        flow_dir.mkdir()

        flow_file = flow_dir / "flow.py"
        flow_file.write_text("# flow module")

        config = LokkiConfig()
        config.include = IncludeConfig(paths=["nonexistent/*.txt"])

        def mock_flow_fn() -> None:
            pass

        mock_flow_fn.__module__ = "test_flow"

        import sys
        from types import ModuleType

        mock_module = ModuleType("test_flow")
        mock_module.__file__ = str(flow_file)
        sys.modules["test_flow"] = mock_module

        try:
            result = _copy_included_files(
                config=config,
                build_dir=tmp_path / "build",
                flow_fn=mock_flow_fn,
            )

            assert result == []
            captured = capsys.readouterr()
            assert "Warning" in captured.out
            assert "nonexistent/*.txt" in captured.out
        finally:
            del sys.modules["test_flow"]

    def test_lambda_dockerfile_without_include(self, tmp_path: Path) -> None:
        """Test that Lambda Dockerfile has no COPY command when no includes."""
        from lokki.builder.lambdafunction.lambda_pkg import (
            _generate_docker_packages,
        )
        from lokki.config import LambdaConfig, LokkiConfig

        config = LokkiConfig()
        config.lambda_cfg = LambdaConfig(package_type="image")
        config.include.paths = []

        lambdas_dir = tmp_path / "lambdas"
        lambdas_dir.mkdir()

        _generate_docker_packages(
            graph=FlowGraph(name="test", head=None),
            config=config,
            lambdas_dir=lambdas_dir,
            flow_fn=None,
        )

        dockerfile_content = (lambdas_dir / "Dockerfile").read_text()
        assert "COPY included/" not in dockerfile_content

    def test_batch_dockerfile_with_include(self, tmp_path: Path) -> None:
        """Test that Batch Dockerfile includes COPY command for included files."""
        from lokki.builder.batchjob.batch_pkg import (
            generate_batch_files,
        )
        from lokki.config import BatchConfig, IncludeConfig, LokkiConfig

        flow_dir = tmp_path / "flow_dir"
        flow_dir.mkdir()

        config_dir = flow_dir / "config"
        config_dir.mkdir()
        (config_dir / "settings.json").write_text('{"key": "value"}')

        flow_file = flow_dir / "flow.py"
        flow_file.write_text("# flow module")

        config = LokkiConfig()
        config.batch_cfg = BatchConfig()
        config.include = IncludeConfig(paths=["config/*.json"])

        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()

        def mock_flow_fn() -> None:
            pass

        mock_flow_fn.__module__ = "test_flow"

        import sys
        from types import ModuleType

        mock_module = ModuleType("test_flow")
        mock_module.__file__ = str(flow_file)
        sys.modules["test_flow"] = mock_module

        try:
            generate_batch_files(
                build_dir=batch_dir,
                config=config,
                flow_fn=mock_flow_fn,
            )

            dockerfile_content = (batch_dir / "Dockerfile").read_text()
            assert "COPY included/" in dockerfile_content

            included_dir = batch_dir / "included"
            assert included_dir.exists()
            assert (included_dir / "settings.json").exists()
        finally:
            del sys.modules["test_flow"]

    def test_include_no_files_match(self, tmp_path: Path, capsys) -> None:
        """Test that warning is printed when include pattern matches no files."""
        from lokki.builder.lambdafunction.lambda_pkg import (
            _copy_included_files,
        )
        from lokki.config import IncludeConfig, LokkiConfig

        flow_dir = tmp_path / "flow_dir"
        flow_dir.mkdir()

        config = LokkiConfig()
        config.include = IncludeConfig(paths=["nonexistent/*.txt"])

        def mock_flow_fn():
            from lokki.graph import FlowGraph

            return FlowGraph(name="test", head=None)

        import sys
        from types import ModuleType

        mock_module = ModuleType("test_flow")
        mock_module.__file__ = str(flow_dir / "flow.py")
        sys.modules["test_flow"] = mock_module

        try:
            result = _copy_included_files(
                config=config,
                build_dir=tmp_path / "build",
                flow_fn=mock_flow_fn,
            )

            assert result == []
            captured = capsys.readouterr()
            assert "Warning" in captured.out
            assert "nonexistent/*.txt" in captured.out
        finally:
            del sys.modules["test_flow"]
