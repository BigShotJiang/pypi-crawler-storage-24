from amaranth.build import *
from amaranth.vendor import LatticeMachXO2Platform
from .resources import *


__all__ = ["TinyFPGAAX2Platform"]


class TinyFPGAAX2Platform(LatticeMachXO2Platform):
    device      = "LCMXO2-1200HC"
    package     = "SG32"
    speed       = "4"
    connectors  = [
        Connector("gpio", 0,
            # Left side of the board
            #  1  2  3  4  5  6  7  8  9 10 11
             "13 14 16 17 20 21 23 25 26 27 28 "
            # Right side of the board
            # 12 13 14 15 16 17 18 19 20 21 22
             "-  -  -  -  4  5  8  9  10 11 12 "
        ),
    ]
    resources = []
    # This board doesn't have an integrated programmer.
