# SPDX-FileCopyrightText: 2026 ModelCloud.ai
# SPDX-FileCopyrightText: 2026 qubitium@modelcloud.ai
# SPDX-License-Identifier: Apache-2.0
# Contact: qubitium@modelcloud.ai, x.com/qubitium
from enum import Enum

from transformers.core_model_loading import WeightConverter, WeightRenaming

from defuser.checkpoint_ops import OwnedChunk, SplitFusedExpertDownProj, SplitFusedExpertGateUpProj
from defuser.utils.common import MIN_SUPPORTED_TRANSFORMERS_VERSION


class PATCH(str, Enum):
    REPLACE_MODULE = "replace_module"
    EXPERTS_DEFUSE = "experts_defuse"


MODEL_CONFIG = {
    "mixtral": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
        PATCH.REPLACE_MODULE: [
            (
                "transformers.models.mixtral.modeling_mixtral.MixtralSparseMoeBlock",
                "defuser.modeling.unfused_moe.mixtral.LinearMixtralSparseMoeBlock",
            )
        ],
        "checkpoint_mapping": [
            WeightRenaming(".block_sparse_moe.", ".mlp."),
            WeightRenaming(r".experts.(\d+).w1.weight", r".experts.\1.gate_proj.weight"),
            WeightRenaming(r".experts.(\d+).w2.weight", r".experts.\1.down_proj.weight"),
            WeightRenaming(r".experts.(\d+).w3.weight", r".experts.\1.up_proj.weight"),
            WeightConverter(
                source_patterns=".experts.gate_up_proj",
                target_patterns=[
                    ".experts.0.gate_proj.weight",
                    ".experts.0.up_proj.weight",
                ],
                operations=[SplitFusedExpertGateUpProj()],
            ),
            WeightConverter(
                source_patterns=".experts.down_proj",
                target_patterns=".experts.0.down_proj.weight",
                operations=[SplitFusedExpertDownProj()],
            ),
        ],
    },
    "qwen2_moe": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
        PATCH.REPLACE_MODULE: [
            (
                "transformers.models.qwen2_moe.modeling_qwen2_moe.Qwen2MoeSparseMoeBlock",
                "defuser.modeling.unfused_moe.qwen2_moe.LinearQwen2MoeSparseMoeBlock",
            )
        ],
    },
    "qwen3_moe": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
        # structure path only replaces modeling structure
        PATCH.REPLACE_MODULE: [
            (
                "transformers.models.qwen3_moe.modeling_qwen3_moe.Qwen3MoeSparseMoeBlock",
                "defuser.modeling.unfused_moe.qwen3_moe.LinearQwen3MoeSparseMoeBlock",
            )
        ],
    },
    "qwen3_5_moe": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
    },
    "qwen3_5_moe_text": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
    },
    "qwen3_next": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
        PATCH.REPLACE_MODULE: [
            (
                "transformers.models.qwen3_next.modeling_qwen3_next.Qwen3NextSparseMoeBlock",
                "defuser.modeling.unfused_moe.qwen3_next.LinearQwen3NextSparseMoeBlock",
            )
        ],
    },
    "qwen3_omni_moe": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
        PATCH.REPLACE_MODULE: [
            (
                "transformers.models.qwen3_omni_moe.modeling_qwen3_omni_moe.Qwen3OmniMoeThinkerTextSparseMoeBlock",
                "defuser.modeling.unfused_moe.qwen3_omni_moe.LinearQwen3OmniMoeThinkerTextSparseMoeBlock",
            )
        ],
    },
    "glm4_moe": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
        PATCH.REPLACE_MODULE: [
            (
                "transformers.models.glm4_moe.modeling_glm4_moe.Glm4MoeMoE",
                "defuser.modeling.unfused_moe.glm4_moe.LinearGlm4MoeMoE",
            )
        ],
    },
    "glm4v": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
        PATCH.REPLACE_MODULE: [
            (
                "transformers.models.glm4v.modeling_glm4v.Glm4vTextMLP",
                "defuser.modeling.glm4v.LinearGlm4vTextMLP",
            )
        ],
        # Split HF checkpoints that still store `gate_up_proj` as one fused tensor.
        "checkpoint_mapping": [
            WeightConverter(
                source_patterns="mlp.gate_up_proj.weight",
                target_patterns=[
                    "mlp.gate_proj.weight",
                    "mlp.up_proj.weight",
                ],
                operations=[OwnedChunk(dim=0)],
            ),
        ],
    },
    "gpt_oss": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
    },
    "llama4": {
        "min_transformers_version": MIN_SUPPORTED_TRANSFORMERS_VERSION,
        PATCH.EXPERTS_DEFUSE: [
            {
                "module_class": "transformers.models.llama4.modeling_llama4.Llama4TextExperts",
                "forward_impl": "batched_input",
            }
        ],
    },
}
