"""
Unit tests for the LCA calculator.
"""

import pytest
from datetime import datetime, timezone

from dynlca.lca.calculator import LCACalculator
from dynlca.models import LCAResult


@pytest.fixture
def calc():
    return LCACalculator()


def test_aluminum_smelting_gwp(calc):
    """Aluminium smelting in Germany (385 gCO₂/kWh) should give ~10 kg CO₂ for 1 kg Al."""
    result = calc.compute(
        process="aluminum_smelting",
        region="DE",
        units=1.0,
        carbon_intensity=385.0,
        data_source="test",
        is_realtime=False,
    )
    assert isinstance(result, LCAResult)
    # 13.5 kWh × 0.385 kg/kWh + 4.8 = ~10.0 kg CO₂-eq
    assert 9.5 < result.gwp < 10.5, f"Unexpected GWP: {result.gwp}"


def test_electricity_dominates_for_aluminum(calc):
    """For aluminium (13.5 kWh/kg), electricity should be >70% of GWP at avg intensity."""
    result = calc.compute(
        process="aluminum_smelting",
        region="WORLD",
        units=1.0,
        carbon_intensity=436.0,
        data_source="test",
        is_realtime=False,
    )
    assert result.gwp_electricity_share > 0.5


def test_cement_background_dominates(calc):
    """For cement (780 kg CO₂ background), background should dominate over electricity."""
    result = calc.compute(
        process="cement_production",
        region="DE",
        units=1.0,
        carbon_intensity=385.0,
        data_source="test",
        is_realtime=False,
    )
    # 110 kWh × 0.385 + 780 ≈ 822 kg CO₂, electricity share ≈ 5%
    assert result.gwp_electricity_share < 0.1


def test_units_scale_linearly(calc):
    """Doubling units should double GWP."""
    r1 = calc.compute("injection_molding", "GB", 1.0, 200.0, "test")
    r2 = calc.compute("injection_molding", "GB", 2.0, 200.0, "test")
    assert abs(r2.gwp - 2 * r1.gwp) < 0.001


def test_high_vs_low_carbon_grid(calc):
    """Same process should have much higher GWP on coal grid vs renewable grid."""
    r_coal       = calc.compute("data_center", "PL", 1.0, 722.0, "test")   # Poland: high coal
    r_renewable  = calc.compute("data_center", "FR", 1.0, 58.0,  "test")   # France: nuclear
    assert r_coal.gwp > r_renewable.gwp * 3


def test_vs_annual_avg_positive_for_coal(calc):
    """Using a high-carbon intensity (coal) should show positive deviation vs avg."""
    result = calc.compute(
        process="steel_production",
        region="GB",
        units=1.0,
        carbon_intensity=600.0,   # above UK annual avg (233)
        data_source="test",
    )
    assert result.vs_annual_avg_pct > 0


def test_unknown_process_raises(calc):
    with pytest.raises(ValueError, match="Unknown process"):
        calc.compute("nonexistent_process", "GB", 1.0, 300.0, "test")


def test_all_processes_compute(calc):
    """All built-in processes should compute without error."""
    from dynlca.lca.factors import PROCESS_FACTORS
    for key in PROCESS_FACTORS:
        result = calc.compute(key, "WORLD", 1.0, 436.0, "test")
        assert result.gwp >= 0, f"Negative GWP for {key}"
        assert len(result.impacts) == 5
