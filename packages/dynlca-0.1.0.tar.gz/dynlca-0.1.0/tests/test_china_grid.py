"""
Tests for China regional grid carbon intensity source.
"""

import pytest
from datetime import datetime, timezone

from dynlca.sources.china_grid import ChinaGridSource, PROVINCE_TO_REGION, NDRC_BASELINE_2023


@pytest.fixture
def src():
    return ChinaGridSource()


def test_all_regions_return_value(src):
    for region in NDRC_BASELINE_2023:
        ci = src.get_current(region)
        assert ci.value_gco2_per_kwh > 0
        assert ci.region == region
        assert ci.source == "china_grid_ndrc"


def test_seasonal_variation(src):
    """Winter months should be higher than summer for coal-heavy grids."""
    jan = src.get_at("CN-NORTH", datetime(2024, 1, 15, tzinfo=timezone.utc))
    jul = src.get_at("CN-NORTH", datetime(2024, 7, 15, tzinfo=timezone.utc))
    assert jan.value_gco2_per_kwh > jul.value_gco2_per_kwh, \
        "Northern China should be more carbon-intensive in winter (heating coal)"


def test_southern_grid_lower_than_north(src):
    """Southern grid (hydro-rich) should be lower than northern (coal-heavy)."""
    cn_south = src.get_current("CN-SOUTH")
    cn_north = src.get_current("CN-NORTH")
    assert cn_south.value_gco2_per_kwh < cn_north.value_gco2_per_kwh


def test_national_average(src):
    """National average should be between min and max regional values."""
    cn = src.get_current("CN")
    values = [src.get_current(r).value_gco2_per_kwh for r in NDRC_BASELINE_2023]
    assert min(values) < cn.value_gco2_per_kwh < max(values)


def test_province_lookup():
    assert PROVINCE_TO_REGION["北京"] == "CN-NORTH"
    assert PROVINCE_TO_REGION["上海"] == "CN-EAST"
    assert PROVINCE_TO_REGION["广东"] == "CN-SOUTH"
    assert PROVINCE_TO_REGION["新疆"] == "CN-NW"


def test_ndrc_factors(src):
    """NDRC factors should include OM, BM, and combined margin."""
    factors = src.get_ndrc_factors("CN-EAST")
    assert "ef_om_kgco2_kwh" in factors
    assert "ef_bm_kgco2_kwh" in factors
    assert "ef_combined_kgco2_kwh" in factors
    assert factors["ef_combined_kgco2_kwh"] > 0


def test_northwest_lowest_due_to_renewables(src):
    """Northwest (wind/solar belt) should be the lowest CO₂ region."""
    nw = src.get_current("CN-NW")
    others = [src.get_current(r) for r in NDRC_BASELINE_2023 if r != "CN-NW"]
    assert all(nw.value_gco2_per_kwh < o.value_gco2_per_kwh for o in others), \
        "CN-NW should be cleanest due to wind/solar"
