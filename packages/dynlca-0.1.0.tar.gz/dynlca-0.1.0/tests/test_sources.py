"""
Tests for data sources (uses mocked HTTP responses).
"""

import pytest
from datetime import datetime, timezone
from unittest.mock import patch, MagicMock

from dynlca.sources.static import StaticFallback
from dynlca.sources.registry import get_intensity


# ── Static fallback ───────────────────────────────────────────────────────────

def test_static_gb():
    s = StaticFallback()
    ci = s.get_current("GB")
    assert ci.value_gco2_per_kwh == 233.0
    assert ci.source == "static_fallback"
    assert ci.region == "GB"


def test_static_china_regional():
    s = StaticFallback()
    for region in ["CN-NORTH", "CN-EAST", "CN-SOUTH", "CN-CENTRAL", "CN-NW", "CN-NE"]:
        ci = s.get_current(region)
        assert ci.value_gco2_per_kwh > 0, f"Missing factor for {region}"


def test_static_unknown_region_falls_back_to_world():
    s = StaticFallback()
    ci = s.get_current("XX-UNKNOWN")
    assert ci.value_gco2_per_kwh == 436.0   # WORLD fallback


def test_static_historical_is_same_as_current():
    s = StaticFallback()
    ts = datetime(2023, 6, 15, 12, 0, tzinfo=timezone.utc)
    ci = s.get_at("DE", ts)
    assert ci.value_gco2_per_kwh == 385.0
    assert ci.timestamp == ts


# ── Registry fallback chain ───────────────────────────────────────────────────

def test_registry_always_returns_result():
    """Registry should always return a result, even if all live sources fail."""
    with patch("dynlca.sources.carbon_intensity_uk.CarbonIntensityUK.get_current",
               side_effect=Exception("API down")):
        with patch("dynlca.sources.electricity_maps.ElectricityMaps._fetch_live",
                   side_effect=Exception("API down")):
            ci = get_intensity("GB")
            # Falls back to static
            assert ci.value_gco2_per_kwh > 0


def test_registry_prefers_live_over_static():
    """Registry should prefer live source over static fallback."""
    mock_ci = MagicMock()
    mock_ci.value_gco2_per_kwh = 180.0
    mock_ci.source = "carbon_intensity_uk"

    with patch("dynlca.sources.carbon_intensity_uk.CarbonIntensityUK.get_current",
               return_value=mock_ci):
        ci = get_intensity("GB")
        assert ci.value_gco2_per_kwh == 180.0
        assert ci.source == "carbon_intensity_uk"
