# 🌍 DynLCA — Real-time Dynamic Life Cycle Assessment

[![Python](https://img.shields.io/badge/python-3.9+-blue.svg)](https://python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![PyPI](https://img.shields.io/pypi/v/dynlca.svg)](https://pypi.org/project/dynlca/)

> **Dynamic LCA that breathes with the real world.**

Traditional LCA uses static, annual-average emission factors. But the carbon intensity of electricity changes every 15 minutes. A product manufactured on a windy Sunday has a very different footprint than one made on a coal-heavy Monday morning.

**DynLCA** connects live data streams — electricity grid carbon intensity, weather, transport — into full LCA calculations, updating your environmental impact in real time.

---

## ✨ Key Features

| Feature | DynLCA | EcoDynElec | Brightway2 |
|---------|--------|------------|------------|
| Real-time data | ✅ | ❌ (historical only) | ❌ |
| Full LCA (not just electricity) | ✅ | ❌ | ✅ |
| Global coverage (incl. China) | ✅ | ❌ (Europe only) | ✅ |
| REST API | ✅ | ❌ | ❌ |
| Live dashboard | ✅ | ❌ | ❌ |
| Brightway2 integration | ✅ | ❌ | — |
| No API key needed (basic mode) | ✅ | ✅ | ✅ |

---

## 🚀 Quick Start

```bash
pip install dynlca
```

```python
from dynlca import DynLCA

# Initialize with a process that uses electricity
lca = DynLCA(
    process="injection_molding",
    electricity_kwh=100,
    region="CN-EAST",   # China Eastern Grid
)

# Get current carbon footprint (uses real-time grid data)
result = lca.calculate()
print(f"Carbon footprint right now: {result.gwp:.2f} kg CO₂-eq")

# Compare: same process at different times
result_peak   = lca.calculate(at="2024-01-15 09:00")  # Peak coal hours
result_offpeak = lca.calculate(at="2024-01-15 03:00") # Low demand, more renewables
print(f"Peak vs off-peak: {result_peak.gwp:.1f} vs {result_offpeak.gwp:.1f} kg CO₂-eq")
```

---

## 📡 Data Sources

DynLCA aggregates from multiple free and paid APIs:

| Source | Coverage | API Key | Update Freq |
|--------|----------|---------|-------------|
| [Carbon Intensity UK](https://carbonintensity.org.uk/) | Great Britain | ❌ Free | 30 min |
| [Electricity Maps](https://electricitymaps.com/) | 50+ countries | Optional | 15 min |
| [WattTime](https://watttime.org/) | USA + global | Free tier | 5 min |
| [ENTSO-E](https://transparency.entsoe.eu/) | Europe | Free | 1 hour |
| Static fallback (ecoinvent avg) | Global | ❌ | — |

For China specifically, DynLCA uses regional grid data from publicly available sources (CEPD/CATARC).

---

## 🔬 Architecture

```
┌─────────────────────────────────────────────────────┐
│                    DynLCA Core                      │
│                                                     │
│  ┌──────────────┐    ┌──────────────────────────┐  │
│  │  Data Sources│───▶│   Emission Factor Cache  │  │
│  │  (real-time) │    │   (TTL-based, 15min)     │  │
│  └──────────────┘    └────────────┬─────────────┘  │
│                                   │                 │
│  ┌──────────────────────────────────────────────┐  │
│  │            LCA Calculator                   │  │
│  │  - Midpoint indicators (GWP, AP, EP, ...)   │  │
│  │  - Endpoint (ReCiPe)                        │  │
│  │  - Temporal weighting                       │  │
│  │  - Uncertainty (Monte Carlo)                │  │
│  └──────────────┬───────────────────────────────┘  │
│                 │                                   │
│     ┌───────────┴──────────┐                       │
│     │                      │                       │
│  REST API              Dashboard                   │
│  (FastAPI)            (Plotly Dash)                │
└─────────────────────────────────────────────────────┘
```

---

## 📊 Dashboard

```bash
dynlca dashboard --region CN-EAST --process cement
```

Opens a live browser dashboard showing:
- Real-time carbon intensity heatmap
- LCA results for your process updated every 15 min
- Historical comparison (today vs. last week vs. annual average)
- Optimal manufacturing window prediction

---

## 🔌 REST API

```bash
dynlca serve --port 8000
```

```bash
# Get current LCA for a process
GET /lca/now?process=injection_molding&kwh=100&region=CN-EAST

# Historical query
GET /lca/history?process=injection_molding&kwh=100&region=DE&from=2024-01-01&to=2024-01-31

# Best time to run energy-intensive process (next 24h)
GET /lca/optimal?process=aluminum_smelting&kwh=5000&region=GB
```

---

## 🌏 Supported Regions

- **Europe**: DE, FR, GB, ES, IT, SE, NO, PL, ...
- **USA**: CAISO, ERCOT, PJM, MISO, ...
- **China**: CN-NORTH, CN-EAST, CN-SOUTH, CN-CENTRAL, CN-NORTHWEST, CN-NORTHEAST
- **Global fallback**: using ecoinvent world-average grid mix

---

## 📦 Integration with Brightway2

```python
import brightway2 as bw
from dynlca.brightway import DynLCAActivity

bw.projects.set_current("my_project")

# Wrap any brightway activity with dynamic electricity
activity = DynLCAActivity(
    bw.get_activity(("ecoinvent", "some_process_key")),
    electricity_input_kwh=500,
    region="DE"
)

# LCA with real-time electricity factor
result = activity.lca_now(method=("ReCiPe 2016", "Midpoint", "GWP100"))
```

---

## 🗺️ Roadmap

- [x] Core calculation engine
- [x] UK Carbon Intensity API integration (no key needed)
- [x] Electricity Maps integration
- [x] Static fallback factors
- [ ] WattTime integration
- [ ] ENTSO-E integration
- [ ] China regional grid data
- [ ] FastAPI REST server
- [ ] Plotly Dash dashboard
- [ ] Brightway2 plugin
- [ ] PyPI release
- [ ] Docker image

---

## 🤝 Contributing

PRs welcome! See [CONTRIBUTING.md](CONTRIBUTING.md).

---

## 📄 License

MIT © 2024
