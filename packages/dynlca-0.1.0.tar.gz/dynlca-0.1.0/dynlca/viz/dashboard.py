"""
DynLCA Live Dashboard — built with Plotly Dash.

Usage:  dynlca dashboard --region GB --process aluminum_smelting
"""

try:
    import dash
    from dash import dcc, html, Input, Output
    import plotly.graph_objects as go
    import plotly.express as px
except ImportError:
    raise ImportError("Dash not installed. Install with: pip install dynlca[dashboard]")

import pandas as pd
from datetime import datetime, timedelta, timezone

from dynlca.core import DynLCA
from dynlca.sources.registry import get_intensity, get_forecast
from dynlca.lca.factors import PROCESS_FACTORS
from dynlca.sources.static import STATIC_FACTORS


def run_dashboard(region: str = "GB", process: str = "aluminum_smelting", port: int = 8050):
    """Launch the live DynLCA dashboard."""

    app = dash.Dash(
        __name__,
        title="DynLCA — Real-time LCA Dashboard",
        external_stylesheets=[
            "https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap"
        ],
    )

    process_options = [
        {"label": PROCESS_FACTORS[k].name, "value": k}
        for k in PROCESS_FACTORS
    ]
    region_options = [{"label": r, "value": r} for r in sorted(STATIC_FACTORS.keys())]

    app.layout = html.Div(
        style={"fontFamily": "Inter, sans-serif", "backgroundColor": "#f8fafc", "minHeight": "100vh"},
        children=[
            # Header
            html.Div(
                style={"backgroundColor": "#1e3a5f", "color": "white", "padding": "20px 40px"},
                children=[
                    html.H1("🌍 DynLCA", style={"margin": 0, "fontSize": "28px"}),
                    html.P("Real-time Dynamic Life Cycle Assessment", style={"margin": "4px 0 0", "opacity": 0.8}),
                ],
            ),
            # Controls
            html.Div(
                style={"padding": "20px 40px", "display": "flex", "gap": "20px", "flexWrap": "wrap"},
                children=[
                    html.Div([
                        html.Label("Region", style={"fontWeight": "600", "fontSize": "13px"}),
                        dcc.Dropdown(
                            id="region-selector",
                            options=region_options,
                            value=region,
                            clearable=False,
                            style={"width": "180px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("Process", style={"fontWeight": "600", "fontSize": "13px"}),
                        dcc.Dropdown(
                            id="process-selector",
                            options=process_options,
                            value=process,
                            clearable=False,
                            style={"width": "320px"},
                        ),
                    ]),
                    html.Div([
                        html.Label("Units", style={"fontWeight": "600", "fontSize": "13px"}),
                        dcc.Input(
                            id="units-input",
                            type="number",
                            value=1.0,
                            min=0.01,
                            step=0.1,
                            style={"width": "100px", "padding": "6px", "borderRadius": "4px", "border": "1px solid #ccc"},
                        ),
                    ]),
                ],
            ),
            # KPI cards
            html.Div(id="kpi-cards", style={"padding": "0 40px 20px"}),
            # Charts
            html.Div(
                style={"padding": "0 40px", "display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "20px"},
                children=[
                    dcc.Graph(id="forecast-chart"),
                    dcc.Graph(id="impacts-chart"),
                ],
            ),
            # Auto-refresh every 5 minutes
            dcc.Interval(id="interval", interval=5 * 60 * 1000, n_intervals=0),
        ],
    )

    @app.callback(
        [Output("kpi-cards", "children"),
         Output("forecast-chart", "figure"),
         Output("impacts-chart", "figure")],
        [Input("region-selector", "value"),
         Input("process-selector", "value"),
         Input("units-input", "value"),
         Input("interval", "n_intervals")],
    )
    def update(region_val, process_val, units_val, _):
        units_val = units_val or 1.0
        lca = DynLCA(process=process_val, region=region_val, units=units_val)

        # Current result
        result = lca.calculate()

        # KPI cards
        sign = ("+" if (result.vs_annual_avg_pct or 0) > 0 else "")
        vs_text = f"{sign}{result.vs_annual_avg_pct:.1f}% vs annual avg" if result.vs_annual_avg_pct else "—"
        vs_color = "#e74c3c" if (result.vs_annual_avg_pct or 0) > 0 else "#27ae60"

        cards = html.Div(
            style={"display": "flex", "gap": "16px", "flexWrap": "wrap"},
            children=[
                _kpi_card("GWP (now)", f"{result.gwp:.3f}", "kg CO₂-eq", "#1e3a5f"),
                _kpi_card("Carbon Intensity", f"{result.carbon_intensity_used:.0f}", "gCO₂/kWh", "#2980b9"),
                _kpi_card("Electricity Share", f"{result.gwp_electricity_share * 100:.0f}%", "of GWP", "#8e44ad"),
                _kpi_card("vs Annual Avg", vs_text, "", vs_color),
                _kpi_card("Data Source", result.data_source.replace("_", " ").title(), "live" if result.is_realtime else "historical", "#27ae60"),
            ],
        )

        # Forecast chart
        forecast = get_forecast(region_val, hours=24)
        if forecast:
            from dynlca.lca.calculator import LCACalculator
            calc = LCACalculator()
            rows = []
            for ci in forecast:
                r = calc.compute(
                    process=process_val, region=region_val, units=units_val,
                    carbon_intensity=ci.value_gco2_per_kwh,
                    data_source=ci.source, is_realtime=False, timestamp=ci.timestamp,
                )
                rows.append({"time": ci.timestamp, "gwp": r.gwp, "intensity": ci.value_gco2_per_kwh})
            df = pd.DataFrame(rows)
            fig_forecast = go.Figure()
            fig_forecast.add_trace(go.Scatter(
                x=df["time"], y=df["gwp"], mode="lines+markers",
                name="GWP forecast", line=dict(color="#1e3a5f", width=2),
            ))
            fig_forecast.update_layout(
                title="24h GWP Forecast",
                xaxis_title="Time", yaxis_title="GWP (kg CO₂-eq)",
                template="plotly_white", height=350,
            )
        else:
            fig_forecast = go.Figure()
            fig_forecast.add_annotation(text="No forecast available for this region",
                                         xref="paper", yref="paper", x=0.5, y=0.5,
                                         showarrow=False, font=dict(size=14, color="gray"))
            fig_forecast.update_layout(title="24h GWP Forecast", template="plotly_white", height=350)

        # Impacts breakdown chart
        impact_names  = [i.name for i in result.impacts]
        impact_values = [i.value for i in result.impacts]
        impact_units  = [i.unit  for i in result.impacts]
        fig_impacts = go.Figure(go.Bar(
            x=impact_names,
            y=impact_values,
            text=[f"{v:.4g} {u}" for v, u in zip(impact_values, impact_units)],
            textposition="outside",
            marker_color=["#1e3a5f", "#2980b9", "#27ae60", "#8e44ad", "#e67e22"],
        ))
        fig_impacts.update_layout(
            title="Midpoint Impact Categories",
            template="plotly_white", height=350,
            yaxis_title="Value (varies by indicator)",
        )

        return cards, fig_forecast, fig_impacts

    app.run(debug=False, port=port)


def _kpi_card(title: str, value: str, unit: str, color: str) -> html.Div:
    return html.Div(
        style={
            "backgroundColor": "white",
            "borderRadius": "8px",
            "padding": "16px 20px",
            "boxShadow": "0 1px 4px rgba(0,0,0,0.08)",
            "borderTop": f"3px solid {color}",
            "minWidth": "160px",
        },
        children=[
            html.P(title, style={"margin": "0 0 4px", "fontSize": "12px", "color": "#888", "fontWeight": "600", "textTransform": "uppercase"}),
            html.P(value, style={"margin": "0", "fontSize": "22px", "fontWeight": "700", "color": color}),
            html.P(unit,  style={"margin": "0", "fontSize": "11px", "color": "#aaa"}),
        ],
    )
