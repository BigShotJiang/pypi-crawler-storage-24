"""
DynLCA — Real-time Dynamic Life Cycle Assessment

Connect live grid carbon data to full LCA calculations.
"""

from dynlca.core import DynLCA
from dynlca.models import LCAResult, Region, Process

__version__ = "0.1.0"
__all__ = ["DynLCA", "LCAResult", "Region", "Process"]
