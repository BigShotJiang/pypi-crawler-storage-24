"""
DynLCA REST API — built with FastAPI.

Start with:  dynlca serve --port 8000
Or:          uvicorn dynlca.api.server:app
"""

try:
    from fastapi import FastAPI, HTTPException, Query
    from fastapi.middleware.cors import CORSMiddleware
except ImportError:
    raise ImportError(
        "FastAPI not installed. Install with: pip install dynlca[api]"
    )

from datetime import datetime
from typing import Optional

from dynlca.core import DynLCA
from dynlca.models import LCAResult, OptimalWindow
from dynlca.sources.registry import get_intensity


def create_app() -> FastAPI:
    app = FastAPI(
        title="DynLCA API",
        description="Real-time Dynamic Life Cycle Assessment",
        version="0.1.0",
        docs_url="/docs",
        redoc_url="/redoc",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["GET"],
        allow_headers=["*"],
    )

    # ── Health ────────────────────────────────────────────────────────────────
    @app.get("/", tags=["health"])
    def root():
        return {"service": "DynLCA", "version": "0.1.0", "status": "ok"}

    @app.get("/health", tags=["health"])
    def health():
        return {"status": "ok"}

    # ── Processes & Regions ───────────────────────────────────────────────────
    @app.get("/processes", tags=["metadata"])
    def list_processes():
        """List all available built-in processes."""
        from dynlca.lca.factors import PROCESS_FACTORS
        return {
            key: {
                "name": f.name,
                "description": f.description,
                "functional_unit": f.functional_unit,
                "electricity_kwh_per_unit": f.electricity_kwh_per_unit,
            }
            for key, f in PROCESS_FACTORS.items()
        }

    @app.get("/regions", tags=["metadata"])
    def list_regions():
        """List all regions with available static fallback factors."""
        return {"regions": DynLCA.list_regions()}

    # ── Carbon Intensity ──────────────────────────────────────────────────────
    @app.get("/intensity/now", tags=["carbon-intensity"])
    def intensity_now(region: str = Query(..., description="Region code, e.g. GB, DE, CN-EAST")):
        """Get current carbon intensity for a region."""
        try:
            ci = get_intensity(region)
            return ci.model_dump()
        except Exception as e:
            raise HTTPException(status_code=502, detail=str(e))

    # ── LCA Calculations ──────────────────────────────────────────────────────
    @app.get("/lca/now", response_model=LCAResult, tags=["lca"])
    def lca_now(
        process: str = Query(..., description="Process key"),
        region:  str = Query(..., description="Grid region code"),
        units:   float = Query(1.0, description="Number of functional units"),
        kwh:     Optional[float] = Query(None, description="Override electricity kWh"),
    ):
        """
        Calculate LCA for a process using current real-time grid carbon intensity.
        """
        try:
            lca = DynLCA(process=process, region=region, units=units, electricity_kwh=kwh)
            return lca.calculate()
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        except Exception as e:
            raise HTTPException(status_code=502, detail=str(e))

    @app.get("/lca/at", response_model=LCAResult, tags=["lca"])
    def lca_at(
        process:   str = Query(...),
        region:    str = Query(...),
        timestamp: str = Query(..., description="ISO 8601 datetime, e.g. 2024-01-15T09:00:00Z"),
        units:     float = Query(1.0),
    ):
        """
        Calculate LCA at a specific historical timestamp.
        """
        try:
            dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid timestamp format")

        try:
            lca = DynLCA(process=process, region=region, units=units)
            return lca.calculate(at=dt)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.get("/lca/optimal", response_model=OptimalWindow, tags=["lca"])
    def lca_optimal(
        process: str   = Query(...),
        region:  str   = Query(...),
        units:   float = Query(1.0),
        hours:   int   = Query(24, ge=1, le=48, description="Forecast horizon in hours"),
    ):
        """
        Find the best time in the next N hours to run a process to minimise GWP.
        Requires a source that provides forecasts (e.g. GB via Carbon Intensity UK API).
        """
        try:
            lca = DynLCA(process=process, region=region, units=units)
            result = lca.find_optimal_window(hours=hours)
            if result is None:
                raise HTTPException(
                    status_code=422,
                    detail=f"No forecast data available for region '{region}'",
                )
            return result
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    return app


# Module-level app instance for uvicorn
app = create_app()
