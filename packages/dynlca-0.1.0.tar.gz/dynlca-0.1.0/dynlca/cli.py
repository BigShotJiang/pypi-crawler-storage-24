"""
DynLCA CLI — command line interface.

Usage:
    dynlca calculate --process aluminum_smelting --region DE --units 5
    dynlca intensity  --region GB
    dynlca optimal    --process steel_production --region GB --hours 24
    dynlca serve      --port 8000
    dynlca dashboard  --region GB --process aluminum_smelting
    dynlca processes
    dynlca regions
"""

import typer
from rich.console import Console
from rich.table import Table
from rich import print as rprint

app    = typer.Typer(help="DynLCA — Real-time Dynamic Life Cycle Assessment")
console = Console()


@app.command()
def calculate(
    process: str  = typer.Option(..., "--process", "-p", help="Process key"),
    region:  str  = typer.Option("WORLD", "--region", "-r", help="Grid region code"),
    units:   float = typer.Option(1.0,   "--units",  "-u", help="Number of functional units"),
    kwh:     float = typer.Option(None,  "--kwh",         help="Override electricity kWh"),
    json:    bool  = typer.Option(False, "--json",         help="Output as JSON"),
):
    """Calculate LCA using real-time grid carbon intensity."""
    from dynlca.core import DynLCA
    lca = DynLCA(process=process, region=region, units=units, electricity_kwh=kwh)
    with console.status(f"Fetching carbon intensity for [bold]{region}[/bold]..."):
        result = lca.calculate()

    if json:
        rprint(result.model_dump_json(indent=2))
        return

    console.print()
    console.print(f"[bold green]{result.summary()}[/bold green]")
    console.print()

    table = Table(title="Midpoint Impact Categories", show_header=True)
    table.add_column("Indicator", style="cyan")
    table.add_column("Value", justify="right")
    table.add_column("Unit", style="dim")
    table.add_column("Description", style="dim")
    for impact in result.impacts:
        table.add_row(impact.name, f"{impact.value:.4g}", impact.unit, impact.description)
    console.print(table)


@app.command()
def intensity(
    region: str = typer.Option(..., "--region", "-r", help="Region code (e.g. GB, DE, CN-EAST)"),
    json:   bool = typer.Option(False, "--json"),
):
    """Get current carbon intensity for a region."""
    from dynlca.sources.registry import get_intensity
    with console.status(f"Fetching intensity for [bold]{region}[/bold]..."):
        ci = get_intensity(region)

    if json:
        rprint(ci.model_dump_json(indent=2))
        return

    console.print(f"\n⚡ [bold]{region}[/bold]: [yellow]{ci.value_gco2_per_kwh:.1f} gCO₂/kWh[/yellow] "
                  f"([dim]{ci.source}[/dim])\n")


@app.command()
def optimal(
    process: str = typer.Option(..., "--process", "-p"),
    region:  str = typer.Option("GB",  "--region",  "-r"),
    units:   float = typer.Option(1.0, "--units",   "-u"),
    hours:   int   = typer.Option(24,  "--hours",        help="Forecast horizon (1-48)"),
    json:    bool  = typer.Option(False, "--json"),
):
    """Find the best time window to run a process to minimise GWP."""
    from dynlca.core import DynLCA
    lca = DynLCA(process=process, region=region, units=units)

    with console.status(f"Fetching 24h forecast for [bold]{region}[/bold]..."):
        result = lca.find_optimal_window(hours=hours)

    if result is None:
        console.print(f"[red]No forecast available for region '{region}'.[/red]")
        console.print("[dim]Try --region GB (UK Carbon Intensity API provides free forecasts)[/dim]")
        raise typer.Exit(1)

    if json:
        rprint(result.model_dump_json(indent=2))
        return

    console.print(f"\n🌿 [bold green]Best window:[/bold green]  {result.best_start.strftime('%Y-%m-%d %H:%M')} UTC "
                  f"→ [green]{result.best_gwp:.3f} kg CO₂-eq[/green]")
    console.print(f"⚠️  [bold red]Worst window:[/bold red] {result.worst_start.strftime('%Y-%m-%d %H:%M')} UTC "
                  f"→ [red]{result.worst_gwp:.3f} kg CO₂-eq[/red]")
    console.print(f"\n💡 Running at the optimal time saves [bold]{result.savings_pct:.1f}%[/bold] GWP\n")


@app.command()
def serve(
    port:  int  = typer.Option(8000, "--port"),
    host:  str  = typer.Option("0.0.0.0", "--host"),
    reload: bool = typer.Option(False, "--reload"),
):
    """Start the DynLCA REST API server."""
    try:
        import uvicorn
    except ImportError:
        console.print("[red]uvicorn not installed. Run: pip install dynlca[api][/red]")
        raise typer.Exit(1)

    console.print(f"🚀 DynLCA API running at [link]http://localhost:{port}/docs[/link]")
    uvicorn.run("dynlca.api.server:app", host=host, port=port, reload=reload)


@app.command()
def dashboard(
    region:  str = typer.Option("GB",                "--region",  "-r"),
    process: str = typer.Option("aluminum_smelting", "--process", "-p"),
    port:    int = typer.Option(8050,                "--port"),
):
    """Launch the live LCA dashboard in your browser."""
    try:
        from dynlca.viz.dashboard import run_dashboard
    except ImportError:
        console.print("[red]Dash not installed. Run: pip install dynlca[dashboard][/red]")
        raise typer.Exit(1)

    console.print(f"🌍 DynLCA Dashboard at [link]http://localhost:{port}[/link]")
    run_dashboard(region=region, process=process, port=port)


@app.command()
def processes():
    """List all available built-in processes."""
    from dynlca.lca.factors import PROCESS_FACTORS
    table = Table(title="Available Processes", show_header=True)
    table.add_column("Key", style="cyan", no_wrap=True)
    table.add_column("Name")
    table.add_column("Functional Unit", style="dim")
    table.add_column("kWh/unit", justify="right", style="yellow")
    for key, f in PROCESS_FACTORS.items():
        table.add_row(key, f.name, f.functional_unit, str(f.electricity_kwh_per_unit))
    console.print(table)


@app.command()
def regions():
    """List regions with available static fallback factors."""
    from dynlca.sources.static import STATIC_FACTORS
    table = Table(title="Available Regions", show_header=True)
    table.add_column("Code", style="cyan")
    table.add_column("gCO₂/kWh (annual avg)", justify="right", style="yellow")
    for r, v in sorted(STATIC_FACTORS.items()):
        table.add_row(r, str(v))
    console.print(table)


if __name__ == "__main__":
    app()
