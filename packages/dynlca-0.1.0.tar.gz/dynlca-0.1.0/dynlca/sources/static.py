"""
Static fallback emission factors.
Used when no live API is available or reachable.
Values are annual averages from ecoinvent 3.9 / IEA 2022.
"""

from datetime import datetime, timezone
from dynlca.sources.base import CarbonDataSource
from dynlca.models import CarbonIntensity

# ── Annual average grid carbon intensity (gCO₂eq/kWh) ─────────────────────
# Sources: IEA Electricity 2023, ecoinvent 3.9, IPCC AR6
STATIC_FACTORS: dict[str, float] = {
    # Europe
    "GB":  233.0,
    "DE":  385.0,
    "FR":   58.0,   # mostly nuclear
    "SE":   13.0,   # mostly hydro + nuclear
    "NO":   26.0,
    "ES":  193.0,
    "IT":  372.0,
    "NL":  289.0,
    "PL":  722.0,
    "AT":  158.0,
    # USA
    "US-CAL": 202.0,
    "US-TEX": 397.0,
    "US-NY":  196.0,
    "US-NE":  188.0,
    "US":     368.0,
    # China regional
    "CN-NORTH":     537.0,
    "CN-EAST":      496.0,
    "CN-SOUTH":     399.0,
    "CN-CENTRAL":   438.0,
    "CN-NW":        323.0,
    "CN-NE":        551.0,
    "CN":           581.0,    # national average
    # Other
    "AU":    656.0,
    "IN":    708.0,
    "JP":    474.0,
    "KR":    415.0,
    "ZA":    903.0,
    "BR":    100.0,
    "CA":    130.0,
    "WORLD": 436.0,           # global average
}


class StaticFallback(CarbonDataSource):
    """
    Returns static annual-average emission factors.
    Always available, no API key needed, covers all regions.
    Used as last-resort fallback.
    """

    name = "static_fallback"
    requires_api_key = False
    supported_regions = ["*"]   # wildcard: covers everything

    def get_current(self, region: str) -> CarbonIntensity:
        value = self._lookup(region)
        return self._make_result(
            region=region,
            value=value,
            timestamp=datetime.now(timezone.utc),
        )

    def get_at(self, region: str, timestamp: datetime) -> CarbonIntensity:
        # Static factors are time-invariant — always return the annual average
        value = self._lookup(region)
        return self._make_result(region=region, value=value, timestamp=timestamp)

    def _lookup(self, region: str) -> float:
        """Look up static factor, with country-prefix fallback."""
        if region in STATIC_FACTORS:
            return STATIC_FACTORS[region]
        # Try country prefix (e.g. "CN-EAST" → "CN")
        prefix = region.split("-")[0]
        if prefix in STATIC_FACTORS:
            return STATIC_FACTORS[prefix]
        return STATIC_FACTORS["WORLD"]
