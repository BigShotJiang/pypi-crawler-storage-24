"""
Abstract base class for all carbon intensity data sources.
"""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional

from dynlca.models import CarbonIntensity


class CarbonDataSource(ABC):
    """
    All data sources implement this interface.
    DynLCA will pick the best available source for a given region,
    falling back gracefully if a source is unavailable or rate-limited.
    """

    name: str = "base"
    requires_api_key: bool = False
    supported_regions: list[str] = []

    def supports(self, region: str) -> bool:
        """Check if this source supports the given region code."""
        return region in self.supported_regions or "*" in self.supported_regions

    @abstractmethod
    def get_current(self, region: str) -> CarbonIntensity:
        """Return the most recent carbon intensity for a region."""
        ...

    def get_at(self, region: str, timestamp: datetime) -> Optional[CarbonIntensity]:
        """
        Return carbon intensity at a specific point in time.
        Historical queries are optional — sources that don't support them
        return None and the core falls back to static values.
        """
        return None

    def get_forecast(self, region: str, hours: int = 24) -> list[CarbonIntensity]:
        """
        Return forecasted carbon intensity for the next `hours` hours.
        Used for optimal scheduling. Returns empty list if not supported.
        """
        return []

    def _make_result(self, region: str, value: float, **kwargs) -> CarbonIntensity:
        """Helper to build a CarbonIntensity from raw values."""
        return CarbonIntensity(
            region=region,
            timestamp=kwargs.get("timestamp", datetime.utcnow()),
            value_gco2_per_kwh=value,
            source=self.name,
            fossil_percent=kwargs.get("fossil_percent"),
            renewable_percent=kwargs.get("renewable_percent"),
        )
