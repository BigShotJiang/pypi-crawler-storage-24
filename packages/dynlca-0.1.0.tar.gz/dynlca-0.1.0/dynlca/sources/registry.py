"""
Source registry — picks the best available data source for a given region,
with automatic fallback chain.
"""

import logging
from dynlca.sources.base import CarbonDataSource
from dynlca.sources.carbon_intensity_uk import CarbonIntensityUK
from dynlca.sources.electricity_maps import ElectricityMaps
from dynlca.sources.china_grid import ChinaGridSource
from dynlca.sources.static import StaticFallback
from dynlca.models import CarbonIntensity

logger = logging.getLogger(__name__)


# Priority order: specific → general → static
_SOURCE_PRIORITY: list[CarbonDataSource] = [
    CarbonIntensityUK(),       # free, no key, GB only — very reliable
    ChinaGridSource(),         # NDRC baseline + seasonal model, CN-* regions
    ElectricityMaps(),         # free tier for current data, global
    StaticFallback(),          # always works
]


def get_source_for_region(region: str) -> CarbonDataSource:
    """Return the highest-priority source that supports this region."""
    for source in _SOURCE_PRIORITY:
        if source.supports(region):
            return source
    return StaticFallback()


def get_intensity(region: str) -> CarbonIntensity:
    """
    Get carbon intensity using the best available source,
    with automatic fallback on error.
    """
    for source in _SOURCE_PRIORITY:
        if not source.supports(region):
            continue
        try:
            result = source.get_current(region)
            logger.debug(f"[{region}] Got {result.value_gco2_per_kwh} gCO₂/kWh from {source.name}")
            return result
        except Exception as e:
            logger.warning(f"[{region}] {source.name} failed: {e} — trying next source")
            continue

    # Final fallback: static (should never fail)
    logger.warning(f"[{region}] All live sources failed, using static fallback")
    return StaticFallback().get_current(region)


def get_forecast(region: str, hours: int = 24) -> list[CarbonIntensity]:
    """
    Get carbon intensity forecast, returning the richest available forecast.
    Falls back to empty list if no source provides forecasts for this region.
    """
    for source in _SOURCE_PRIORITY:
        if not source.supports(region):
            continue
        try:
            forecast = source.get_forecast(region, hours=hours)
            if forecast:
                return forecast
        except Exception as e:
            logger.warning(f"[{region}] Forecast from {source.name} failed: {e}")
    return []
