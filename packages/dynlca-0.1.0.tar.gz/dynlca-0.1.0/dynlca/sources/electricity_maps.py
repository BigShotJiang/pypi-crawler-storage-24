"""
Electricity Maps API — https://electricitymaps.com/
Free tier: current data for all zones.
API key from environment: ELECTRICITY_MAPS_TOKEN
Coverage: 50+ countries worldwide
"""

import os
from datetime import datetime, timezone

import requests

from dynlca.sources.base import CarbonDataSource
from dynlca.models import CarbonIntensity

BASE_URL = "https://api.electricitymap.org/v3"
TIMEOUT  = 10


class ElectricityMaps(CarbonDataSource):
    name = "electricity_maps"
    requires_api_key = False   # free tier works without key for current data
    # Wildcard — supports all zones that Electricity Maps covers
    supported_regions = ["*"]

    def __init__(self, api_token: str | None = None):
        self.token = api_token or os.getenv("ELECTRICITY_MAPS_TOKEN", "")

    @property
    def _headers(self) -> dict:
        if self.token:
            return {"auth-token": self.token}
        return {}

    def get_current(self, region: str) -> CarbonIntensity:
        """Fetch live carbon intensity for any Electricity Maps zone."""
        resp = requests.get(
            f"{BASE_URL}/carbon-intensity/latest",
            params={"zone": region},
            headers=self._headers,
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()

        value = data.get("carbonIntensity") or 0.0
        ts_str = data.get("datetime", "")
        ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00")) if ts_str else datetime.now(timezone.utc)

        return self._make_result(region=region, value=float(value), timestamp=ts)

    def get_forecast(self, region: str, hours: int = 24) -> list[CarbonIntensity]:
        """Fetch carbon intensity forecast (requires paid tier)."""
        if not self.token:
            return []
        try:
            resp = requests.get(
                f"{BASE_URL}/carbon-intensity/forecast",
                params={"zone": region},
                headers=self._headers,
                timeout=TIMEOUT,
            )
            resp.raise_for_status()
            forecasts = resp.json().get("forecast", [])
            results = []
            for item in forecasts[:hours]:
                ts = datetime.fromisoformat(item["datetime"].replace("Z", "+00:00"))
                results.append(
                    self._make_result(region=region, value=float(item["carbonIntensity"]), timestamp=ts)
                )
            return results
        except Exception:
            return []

    # ── China regional mapping ──────────────────────────────────────────────
    # China's state grid does not have public real-time API.
    # We use regional annual averages from CEPD / CLCD as static fallback,
    # and can layer in real-time data when Electricity Maps adds CN zones.

    CN_STATIC_FACTORS: dict[str, float] = {
        "CN-NORTH":    537.0,   # gCO₂/kWh — heavy coal
        "CN-EAST":     496.0,
        "CN-SOUTH":    399.0,   # more hydro
        "CN-CENTRAL":  438.0,
        "CN-NW":       323.0,   # wind/solar corridor
        "CN-NE":       551.0,
    }

    def get_current(self, region: str) -> CarbonIntensity:  # noqa: F811
        # Override for China regions — use static factors until live data available
        if region.startswith("CN-"):
            value = self.CN_STATIC_FACTORS.get(region, 500.0)
            return self._make_result(
                region=region,
                value=value,
                timestamp=datetime.now(timezone.utc),
            )
        # All other regions: call Electricity Maps
        return self._fetch_live(region)

    def _fetch_live(self, region: str) -> CarbonIntensity:
        resp = requests.get(
            f"{BASE_URL}/carbon-intensity/latest",
            params={"zone": region},
            headers=self._headers,
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
        value = data.get("carbonIntensity") or 0.0
        ts_str = data.get("datetime", "")
        ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00")) if ts_str else datetime.now(timezone.utc)
        return self._make_result(region=region, value=float(value), timestamp=ts)
