"""
UK Carbon Intensity API — https://carbonintensity.org.uk/
No API key needed. Updates every 30 minutes.
Coverage: Great Britain (GB)
"""

from datetime import datetime, timezone
import requests

from dynlca.sources.base import CarbonDataSource
from dynlca.models import CarbonIntensity

BASE_URL = "https://api.carbonintensity.org.uk"
TIMEOUT  = 10  # seconds


class CarbonIntensityUK(CarbonDataSource):
    name = "carbon_intensity_uk"
    requires_api_key = False
    supported_regions = ["GB"]

    def get_current(self, region: str = "GB") -> CarbonIntensity:
        """Fetch current carbon intensity for Great Britain."""
        resp = requests.get(f"{BASE_URL}/intensity", timeout=TIMEOUT)
        resp.raise_for_status()
        data = resp.json()["data"][0]

        intensity = data["intensity"]
        value = intensity.get("actual") or intensity.get("forecast") or 0.0

        # Generation mix for renewable/fossil breakdown
        mix = self._get_generation_mix()

        return self._make_result(
            region="GB",
            value=float(value),
            timestamp=datetime.now(timezone.utc),
            fossil_percent=mix.get("fossil_pct"),
            renewable_percent=mix.get("renewable_pct"),
        )

    def get_at(self, region: str, timestamp: datetime) -> CarbonIntensity | None:
        """Fetch historical carbon intensity for a specific datetime (GB only)."""
        iso = timestamp.strftime("%Y-%m-%dT%H:%MZ")
        try:
            resp = requests.get(f"{BASE_URL}/intensity/{iso}", timeout=TIMEOUT)
            resp.raise_for_status()
            data = resp.json()["data"][0]
            value = data["intensity"].get("actual") or data["intensity"].get("forecast") or 0.0
            return self._make_result(region="GB", value=float(value), timestamp=timestamp)
        except Exception:
            return None

    def get_forecast(self, region: str = "GB", hours: int = 24) -> list[CarbonIntensity]:
        """Fetch 48-hour forecast (API provides 48h windows)."""
        results = []
        try:
            resp = requests.get(f"{BASE_URL}/intensity/pt24h/fw48h", timeout=TIMEOUT)
            resp.raise_for_status()
            for item in resp.json()["data"][:hours * 2]:  # 30-min slots
                ts_str = item["from"]
                ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                value = item["intensity"].get("forecast") or 0.0
                results.append(self._make_result(region="GB", value=float(value), timestamp=ts))
        except Exception:
            pass
        return results

    def _get_generation_mix(self) -> dict:
        """Get current generation mix to compute fossil/renewable percentages."""
        try:
            resp = requests.get(f"{BASE_URL}/generation", timeout=TIMEOUT)
            resp.raise_for_status()
            gen_list = resp.json()["data"]["generationmix"]

            fossil_fuels = {"gas", "coal", "oil"}
            renewables   = {"wind", "solar", "hydro", "biomass", "nuclear"}

            fossil_pct    = sum(g["perc"] for g in gen_list if g["fuel"] in fossil_fuels)
            renewable_pct = sum(g["perc"] for g in gen_list if g["fuel"] in renewables)
            return {"fossil_pct": fossil_pct, "renewable_pct": renewable_pct}
        except Exception:
            return {}
