"""
Pydantic models for DynLCA data structures.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


# ─────────────────────────────────────────────
# Regions
# ─────────────────────────────────────────────

class Region(str, Enum):
    # United Kingdom
    GB = "GB"
    # Europe
    DE = "DE"
    FR = "FR"
    ES = "ES"
    IT = "IT"
    SE = "SE"
    NO = "NO"
    PL = "PL"
    NL = "NL"
    AT = "AT"
    # USA
    US_CA = "US-CAL"      # CAISO (California)
    US_TX = "US-TEX"      # ERCOT (Texas)
    US_NY = "US-NY"       # NYISO
    US_NE = "US-NE"       # ISO-NE
    # China regional grids
    CN_NORTH = "CN-NORTH"
    CN_EAST  = "CN-EAST"
    CN_SOUTH = "CN-SOUTH"
    CN_CENTRAL = "CN-CENTRAL"
    CN_NORTHWEST = "CN-NW"
    CN_NORTHEAST = "CN-NE"
    # Global fallback
    WORLD = "WORLD"


# ─────────────────────────────────────────────
# Processes (example library)
# ─────────────────────────────────────────────

class Process(str, Enum):
    INJECTION_MOLDING = "injection_molding"
    ALUMINUM_SMELTING = "aluminum_smelting"
    CEMENT_PRODUCTION = "cement_production"
    STEEL_PRODUCTION   = "steel_production"
    DATA_CENTER        = "data_center"
    EV_CHARGING        = "ev_charging"
    CUSTOM             = "custom"


# ─────────────────────────────────────────────
# Carbon intensity snapshot
# ─────────────────────────────────────────────

class CarbonIntensity(BaseModel):
    """A single carbon intensity reading from a data source."""
    region: str
    timestamp: datetime
    value_gco2_per_kwh: float = Field(..., description="gCO₂eq/kWh")
    source: str = Field(..., description="API source name")
    fossil_percent: Optional[float] = None
    renewable_percent: Optional[float] = None


# ─────────────────────────────────────────────
# LCA Result
# ─────────────────────────────────────────────

class ImpactCategory(BaseModel):
    name: str
    unit: str
    value: float
    description: str = ""


class LCAResult(BaseModel):
    """Full LCA result for a process at a given time."""

    # Identity
    process: str
    region: str
    timestamp: datetime
    electricity_kwh: float

    # Key indicator (always present)
    gwp: float = Field(..., description="Global Warming Potential [kg CO₂-eq]")
    gwp_electricity_share: float = Field(..., description="Share of GWP from electricity [0-1]")

    # All midpoint indicators (optional, populated when available)
    impacts: list[ImpactCategory] = Field(default_factory=list)

    # Source metadata
    carbon_intensity_used: float = Field(..., description="gCO₂eq/kWh used in calculation")
    data_source: str
    is_realtime: bool = True

    # Comparison with annual average
    annual_avg_gwp: Optional[float] = None
    vs_annual_avg_pct: Optional[float] = None   # % difference vs annual average

    model_config = {"json_encoders": {datetime: lambda v: v.isoformat()}}

    def summary(self) -> str:
        lines = [
            f"🌍 LCA Result — {self.process} @ {self.region}",
            f"   Time      : {self.timestamp.strftime('%Y-%m-%d %H:%M')}",
            f"   GWP       : {self.gwp:.3f} kg CO₂-eq",
            f"   Intensity : {self.carbon_intensity_used:.1f} gCO₂/kWh ({self.data_source})",
        ]
        if self.vs_annual_avg_pct is not None:
            sign = "+" if self.vs_annual_avg_pct > 0 else ""
            lines.append(f"   vs avg    : {sign}{self.vs_annual_avg_pct:.1f}% vs annual average")
        return "\n".join(lines)


# ─────────────────────────────────────────────
# Optimal window result
# ─────────────────────────────────────────────

class OptimalWindow(BaseModel):
    """Best time window to run an energy-intensive process."""
    region: str
    process: str
    electricity_kwh: float
    best_start: datetime
    best_gwp: float
    worst_start: datetime
    worst_gwp: float
    savings_pct: float = Field(..., description="GWP savings vs worst window [%]")
    forecast_source: str
    windows: list[dict] = Field(default_factory=list, description="Hourly forecast")
