"""
Core LCA calculator.

Combines:
  - Static background impacts (materials, non-electricity processes)
  - Dynamic electricity impact (real-time carbon intensity × kWh)
"""

from datetime import datetime, timezone
from typing import Optional

from dynlca.models import LCAResult, ImpactCategory, OptimalWindow
from dynlca.lca.factors import PROCESS_FACTORS, ImpactFactor
from dynlca.sources.static import STATIC_FACTORS


class LCACalculator:
    """
    Compute LCA for a process given a carbon intensity value and scale factor.

    Usage:
        calc = LCACalculator()
        result = calc.compute(
            process="aluminum_smelting",
            region="DE",
            units=5.0,          # 5 kg aluminium
            carbon_intensity=385.0,   # gCO₂/kWh (from real-time source)
            data_source="electricity_maps",
            is_realtime=True,
        )
    """

    def __init__(self):
        self.processes = PROCESS_FACTORS

    def compute(
        self,
        process: str,
        region: str,
        units: float,
        carbon_intensity: float,      # gCO₂eq/kWh — the dynamic part
        data_source: str = "unknown",
        is_realtime: bool = True,
        timestamp: Optional[datetime] = None,
    ) -> LCAResult:
        if process not in self.processes:
            raise ValueError(
                f"Unknown process '{process}'. "
                f"Available: {list(self.processes.keys())}"
            )

        f: ImpactFactor = self.processes[process]
        ts = timestamp or datetime.now(timezone.utc)

        # ── Electricity GWP (dynamic) ─────────────────────────────────────
        # carbon_intensity is in gCO₂/kWh → convert to kg CO₂/kWh
        electricity_gwp = (
            f.electricity_kwh_per_unit
            * units
            * (carbon_intensity / 1000.0)   # g → kg
        )

        # ── Background GWP (static) ───────────────────────────────────────
        background_gwp = f.background_gwp_per_unit * units

        total_gwp = electricity_gwp + background_gwp
        elec_share = electricity_gwp / total_gwp if total_gwp > 0 else 0.0

        # ── Other midpoint indicators (static, scale with units) ──────────
        impacts = [
            ImpactCategory(
                name="GWP100",
                unit="kg CO₂-eq",
                value=round(total_gwp, 4),
                description="Global Warming Potential (100-year horizon)",
            ),
            ImpactCategory(
                name="AP",
                unit="kg SO₂-eq",
                value=round(f.ap_per_unit * units, 6),
                description="Acidification Potential",
            ),
            ImpactCategory(
                name="EP",
                unit="kg PO₄-eq",
                value=round(f.ep_per_unit * units, 6),
                description="Eutrophication Potential",
            ),
            ImpactCategory(
                name="ODP",
                unit="kg CFC11-eq",
                value=round(f.odp_per_unit * units, 8),
                description="Ozone Depletion Potential",
            ),
            ImpactCategory(
                name="ADP",
                unit="MJ",
                value=round(f.adp_per_unit * units, 3),
                description="Abiotic Resource Depletion (energy)",
            ),
        ]

        # ── Comparison vs annual average ──────────────────────────────────
        annual_avg_intensity = STATIC_FACTORS.get(region, STATIC_FACTORS["WORLD"])
        annual_avg_gwp = (
            f.electricity_kwh_per_unit * units * (annual_avg_intensity / 1000.0)
            + background_gwp
        )
        vs_pct = ((total_gwp - annual_avg_gwp) / annual_avg_gwp * 100) if annual_avg_gwp > 0 else 0.0

        return LCAResult(
            process=process,
            region=region,
            timestamp=ts,
            electricity_kwh=f.electricity_kwh_per_unit * units,
            gwp=round(total_gwp, 4),
            gwp_electricity_share=round(elec_share, 4),
            impacts=impacts,
            carbon_intensity_used=carbon_intensity,
            data_source=data_source,
            is_realtime=is_realtime,
            annual_avg_gwp=round(annual_avg_gwp, 4),
            vs_annual_avg_pct=round(vs_pct, 2),
        )

    def optimal_window(
        self,
        process: str,
        region: str,
        units: float,
        forecast: list,   # list[CarbonIntensity]
    ) -> OptimalWindow | None:
        """
        Given a carbon intensity forecast, find the best and worst windows
        to run an energy-intensive process.
        Returns None if forecast is empty.
        """
        if not forecast:
            return None

        windows = []
        for ci in forecast:
            result = self.compute(
                process=process,
                region=region,
                units=units,
                carbon_intensity=ci.value_gco2_per_kwh,
                data_source=ci.source,
                is_realtime=False,
                timestamp=ci.timestamp,
            )
            windows.append({
                "timestamp": ci.timestamp.isoformat(),
                "carbon_intensity": ci.value_gco2_per_kwh,
                "gwp": result.gwp,
            })

        best  = min(windows, key=lambda w: w["gwp"])
        worst = max(windows, key=lambda w: w["gwp"])
        savings = (worst["gwp"] - best["gwp"]) / worst["gwp"] * 100 if worst["gwp"] > 0 else 0.0

        from datetime import datetime
        return OptimalWindow(
            region=region,
            process=process,
            electricity_kwh=PROCESS_FACTORS[process].electricity_kwh_per_unit * units,
            best_start=datetime.fromisoformat(best["timestamp"]),
            best_gwp=best["gwp"],
            worst_start=datetime.fromisoformat(worst["timestamp"]),
            worst_gwp=worst["gwp"],
            savings_pct=round(savings, 1),
            forecast_source=forecast[0].source,
            windows=windows,
        )
