"""
LCA impact factors for built-in process library.

Each process defines:
  - electricity_kwh_per_unit: How much electricity per functional unit
  - background_gwp_per_unit: All non-electricity GWP (materials, transport, etc.)
    This is the STATIC part that doesn't change with real-time data.
  - other_impacts: AP, EP, etc. (static, from ecoinvent averages)

Electricity-related impacts are computed dynamically using real-time carbon intensity.
"""

from dataclasses import dataclass, field


@dataclass
class ImpactFactor:
    name: str
    description: str
    functional_unit: str

    # ── Electricity ──────────────────────────────────────────────────────────
    electricity_kwh_per_unit: float = 0.0

    # ── Background (non-electricity) static GWP ─────────────────────────────
    # kg CO₂-eq per functional unit, from ecoinvent 3.9 world-average
    background_gwp_per_unit: float = 0.0

    # ── Other midpoint indicators (static) ──────────────────────────────────
    # AP  = Acidification Potential (kg SO₂-eq)
    # EP  = Eutrophication Potential (kg PO₄-eq)
    # ODP = Ozone Depletion Potential (kg CFC11-eq)
    # POCP = Photochemical Ozone Creation (kg ethene-eq)
    # ADP = Abiotic Depletion Potential (MJ)
    ap_per_unit:   float = 0.0
    ep_per_unit:   float = 0.0
    odp_per_unit:  float = 0.0
    pocp_per_unit: float = 0.0
    adp_per_unit:  float = 0.0   # MJ, primary energy demand


# ── Process library ──────────────────────────────────────────────────────────
# Functional unit = 1 kg of product output (unless noted)

PROCESS_FACTORS: dict[str, ImpactFactor] = {

    "injection_molding": ImpactFactor(
        name="Injection Moulding (plastic)",
        description="Injection moulding of generic thermoplastic",
        functional_unit="1 kg plastic part",
        electricity_kwh_per_unit=0.55,      # kWh/kg
        background_gwp_per_unit=2.10,       # materials + mould heating (non-elec)
        ap_per_unit=0.0052,
        ep_per_unit=0.00041,
        adp_per_unit=48.0,
    ),

    "aluminum_smelting": ImpactFactor(
        name="Aluminium Smelting (primary)",
        description="Primary aluminium production via Hall–Héroult process",
        functional_unit="1 kg aluminium ingot",
        electricity_kwh_per_unit=13.5,      # extremely electricity-intensive
        background_gwp_per_unit=4.8,        # anode baking, PFC emissions
        ap_per_unit=0.031,
        ep_per_unit=0.0022,
        adp_per_unit=195.0,
    ),

    "cement_production": ImpactFactor(
        name="Portland Cement Production",
        description="OPC clinker production and grinding",
        functional_unit="1 tonne cement",
        electricity_kwh_per_unit=110.0,     # kWh/tonne
        background_gwp_per_unit=780.0,      # calcination process CO₂ dominates
        ap_per_unit=1.2,
        ep_per_unit=0.091,
        adp_per_unit=3200.0,
    ),

    "steel_production": ImpactFactor(
        name="Electric Arc Furnace Steel",
        description="EAF secondary steel production",
        functional_unit="1 tonne crude steel",
        electricity_kwh_per_unit=400.0,     # kWh/tonne — very sensitive to grid
        background_gwp_per_unit=190.0,      # scrap pre-processing, alloys
        ap_per_unit=2.1,
        ep_per_unit=0.15,
        adp_per_unit=6200.0,
    ),

    "data_center": ImpactFactor(
        name="Data Centre Operation",
        description="1 hour of 1 kW server rack (PUE = 1.4)",
        functional_unit="1 kWh IT load",
        electricity_kwh_per_unit=1.4,       # includes PUE overhead
        background_gwp_per_unit=0.012,      # hardware manufacturing amortised
        ap_per_unit=0.00083,
        ep_per_unit=0.000061,
        adp_per_unit=16.5,
    ),

    "ev_charging": ImpactFactor(
        name="Electric Vehicle Charging",
        description="1 kWh delivered to EV battery (charger efficiency = 92%)",
        functional_unit="1 kWh to battery",
        electricity_kwh_per_unit=1.087,     # AC charging efficiency
        background_gwp_per_unit=0.0,        # no background — pure electricity
        ap_per_unit=0.0,
        ep_per_unit=0.0,
        adp_per_unit=0.0,
    ),

    "pcb_manufacturing": ImpactFactor(
        name="PCB Manufacturing",
        description="FR4 double-sided PCB, 1 dm²",
        functional_unit="1 dm² PCB",
        electricity_kwh_per_unit=2.3,
        background_gwp_per_unit=1.8,
        ap_per_unit=0.018,
        ep_per_unit=0.0013,
        adp_per_unit=42.0,
    ),

    "glass_production": ImpactFactor(
        name="Float Glass Production",
        description="Flat glass for construction/automotive",
        functional_unit="1 kg float glass",
        electricity_kwh_per_unit=0.28,
        background_gwp_per_unit=0.74,
        ap_per_unit=0.0017,
        ep_per_unit=0.00013,
        adp_per_unit=10.5,
    ),
}
