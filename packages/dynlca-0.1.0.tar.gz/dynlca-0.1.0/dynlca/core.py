"""
DynLCA — Main entry point.

High-level API wrapping data sources + calculator.
"""

from datetime import datetime
from typing import Optional

from cachetools import TTLCache

from dynlca.models import LCAResult, OptimalWindow
from dynlca.lca.calculator import LCACalculator
from dynlca.sources.registry import get_intensity, get_forecast


# Cache carbon intensity readings for 15 minutes to avoid hammering APIs
_INTENSITY_CACHE: TTLCache = TTLCache(maxsize=128, ttl=900)


class DynLCA:
    """
    Real-time Dynamic LCA calculator.

    Example:
        lca = DynLCA(process="aluminum_smelting", region="DE", units=10.0)
        result = lca.calculate()
        print(result.summary())
    """

    def __init__(
        self,
        process: str,
        region: str = "WORLD",
        units: float = 1.0,
        electricity_kwh: Optional[float] = None,   # override if you know exact kWh
    ):
        """
        Parameters
        ----------
        process : str
            Process key (see dynlca.lca.factors.PROCESS_FACTORS).
            Use DynLCA.list_processes() to see available processes.
        region : str
            Grid region code (e.g. "GB", "DE", "CN-EAST").
        units : float
            Number of functional units to calculate for.
        electricity_kwh : float, optional
            Override the electricity consumption instead of using the process factor.
        """
        self.process = process
        self.region = region
        self.units = units
        self.electricity_kwh_override = electricity_kwh
        self._calc = LCACalculator()

    # ── Main calculation ──────────────────────────────────────────────────────

    def calculate(self, at: Optional[datetime] = None) -> LCAResult:
        """
        Compute LCA for this process.

        Parameters
        ----------
        at : datetime, optional
            If provided, use the carbon intensity at this historical timestamp.
            If None, use current real-time data.

        Returns
        -------
        LCAResult with GWP and all midpoint indicators.
        """
        if at is not None:
            return self._calculate_historical(at)

        # Real-time path — check cache first
        cache_key = self.region
        if cache_key not in _INTENSITY_CACHE:
            ci = get_intensity(self.region)
            _INTENSITY_CACHE[cache_key] = ci
        else:
            ci = _INTENSITY_CACHE[cache_key]

        return self._calc.compute(
            process=self.process,
            region=self.region,
            units=self._effective_units(),
            carbon_intensity=ci.value_gco2_per_kwh,
            data_source=ci.source,
            is_realtime=True,
            timestamp=ci.timestamp,
        )

    def _calculate_historical(self, at: datetime) -> LCAResult:
        """Calculate using historical carbon intensity for a specific time."""
        from dynlca.sources.registry import _SOURCE_PRIORITY
        ci = None
        for source in _SOURCE_PRIORITY:
            if source.supports(self.region):
                ci = source.get_at(self.region, at)
                if ci:
                    break

        if ci is None:
            from dynlca.sources.static import StaticFallback
            ci = StaticFallback().get_at(self.region, at)

        return self._calc.compute(
            process=self.process,
            region=self.region,
            units=self._effective_units(),
            carbon_intensity=ci.value_gco2_per_kwh,
            data_source=ci.source,
            is_realtime=False,
            timestamp=at,
        )

    def _effective_units(self) -> float:
        """Return units, adjusted if electricity_kwh override is set."""
        if self.electricity_kwh_override is not None:
            from dynlca.lca.factors import PROCESS_FACTORS
            factor = PROCESS_FACTORS.get(self.process)
            if factor and factor.electricity_kwh_per_unit > 0:
                return self.electricity_kwh_override / factor.electricity_kwh_per_unit
        return self.units

    # ── Optimal scheduling ────────────────────────────────────────────────────

    def find_optimal_window(self, hours: int = 24) -> Optional[OptimalWindow]:
        """
        Find the best time in the next `hours` hours to run this process
        to minimise GWP. Uses carbon intensity forecast from available sources.

        Returns None if no forecast data is available for this region.
        """
        forecast = get_forecast(self.region, hours=hours)
        if not forecast:
            return None
        return self._calc.optimal_window(
            process=self.process,
            region=self.region,
            units=self._effective_units(),
            forecast=forecast,
        )

    # ── Utilities ─────────────────────────────────────────────────────────────

    @staticmethod
    def list_processes() -> list[str]:
        """Return available built-in process keys."""
        from dynlca.lca.factors import PROCESS_FACTORS
        return list(PROCESS_FACTORS.keys())

    @staticmethod
    def list_regions() -> list[str]:
        """Return regions with known static fallback factors."""
        from dynlca.sources.static import STATIC_FACTORS
        return sorted(STATIC_FACTORS.keys())

    def __repr__(self) -> str:
        return f"DynLCA(process={self.process!r}, region={self.region!r}, units={self.units})"
