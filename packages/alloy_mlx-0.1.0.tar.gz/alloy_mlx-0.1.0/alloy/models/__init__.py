"""Model components for Alloy."""
