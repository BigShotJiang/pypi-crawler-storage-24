"""Tests for individual check modules."""

import tempfile
from pathlib import Path

from ktest.checks.base import CheckBase
from ktest.checks.safety import SafetyChecks
from ktest.checks.logging import LoggingChecks


def test_check_base_get_python_files():
    """CheckBase finds Python files and skips excluded dirs."""
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        (root / "main.py").write_text("x = 1")
        (root / "__pycache__").mkdir()
        (root / "__pycache__" / "main.cpython-312.pyc").write_text("")
        (root / "sub").mkdir()
        (root / "sub" / "helper.py").write_text("y = 2")

        base = CheckBase(project_root=root)
        files = base.get_python_files()
        names = {f.name for f in files}

        assert "main.py" in names
        assert "helper.py" in names
        assert "main.cpython-312.pyc" not in names


def test_safety_bare_except():
    """SafetyChecks catches bare except clauses."""
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        (root / "bad.py").write_text("try:\n    x = 1\nexcept:\n    pass\n")
        (root / "good.py").write_text("try:\n    x = 1\nexcept Exception:\n    pass\n")

        checks = SafetyChecks(project_root=root)
        result = checks.validate_bare_except()

        assert not result["valid"]
        assert len(result["violations"]) == 1
        assert "bad.py" in result["violations"][0]


def test_safety_no_violations():
    """SafetyChecks passes clean code."""
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        (root / "clean.py").write_text("try:\n    x = 1\nexcept ValueError:\n    pass\n")

        checks = SafetyChecks(project_root=root)
        result = checks.validate_bare_except()

        assert result["valid"]
        assert len(result["violations"]) == 0


def test_logging_print_statements():
    """LoggingChecks catches print() usage."""
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        (root / "noisy.py").write_text('print("hello")\n')
        (root / "quiet.py").write_text('logger.info("hello")\n')

        checks = LoggingChecks(project_root=root)
        result = checks.validate_print_statements()

        assert not result["valid"]
        assert len(result["violations"]) == 1
        assert "noisy.py" in result["violations"][0]
