"""Tests for ktest tools."""

from ktest.tools.promql import extract_metrics_from_promql


def test_extract_metrics_basic():
    """Extracts metric names from PromQL queries."""
    metrics = extract_metrics_from_promql([
        "rate(http_requests_total[5m])",
        "sum(cpu_usage{instance='localhost'}) by (instance)",
    ])
    assert "http_requests_total" in metrics
    assert "cpu_usage" in metrics


def test_extract_metrics_excludes_functions():
    """PromQL functions are not returned as metrics."""
    metrics = extract_metrics_from_promql([
        "rate(my_metric[5m])",
    ])
    assert "rate" not in metrics
    assert "my_metric" in metrics


def test_extract_metrics_empty():
    """Empty input returns empty set."""
    assert extract_metrics_from_promql([]) == set()
    assert extract_metrics_from_promql([""]) == set()
