"""Tests for ktest analysis module."""

from ktest.analysis.utils import classify_error, extract_root_cause


def test_classify_database_error():
    """Database errors are classified correctly."""
    cats = classify_error("OperationalError: could not connect to server")
    assert "database" in cats


def test_classify_import_error():
    """Import errors are classified correctly."""
    cats = classify_error("ModuleNotFoundError: No module named 'foo'")
    assert "import" in cats


def test_classify_unknown_error():
    """Unknown errors get 'unknown' category."""
    cats = classify_error("something completely different")
    assert "unknown" in cats


def test_extract_root_cause():
    """Root cause extraction finds deepest non-test frame."""
    traceback = '''
Traceback (most recent call last):
  File "tests/test_main.py", line 10, in test_foo
    result = app.main.process()
  File "app/main.py", line 42, in process
    return db.query("SELECT 1")
OperationalError: connection refused
'''
    cause = extract_root_cause(traceback)
    assert cause is not None
    assert cause["function"] == "process"
    assert cause["line"] == 42


def test_extract_root_cause_empty():
    """Returns None for non-traceback text."""
    assert extract_root_cause("no traceback here") is None
