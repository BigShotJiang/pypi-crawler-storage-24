"""Tests for ktest TestSuite."""

from pathlib import Path

from ktest import TestSuite


def test_suite_no_grafana():
    """TestSuite works without Grafana configuration."""
    suite = TestSuite(project_root=Path("."))
    assert suite.grafana is None
    TestClass = suite.create_test_class()
    methods = [m for m in dir(TestClass) if m.startswith("test_")]
    assert len(methods) > 0


def test_suite_with_grafana():
    """TestSuite includes Grafana tests when configured."""
    suite_no_grafana = TestSuite(project_root=Path("."))
    suite_grafana = TestSuite(
        project_root=Path("."),
        grafana_dashboard_uid="test-uid",
        grafana_url="http://localhost:3000",
    )
    assert suite_grafana.grafana is not None

    methods_without = [
        m
        for m in dir(suite_no_grafana.create_test_class())
        if m.startswith("test_")
    ]
    methods_with = [
        m
        for m in dir(suite_grafana.create_test_class())
        if m.startswith("test_")
    ]
    assert len(methods_with) > len(methods_without)


def test_suite_check_modules():
    """All check modules are accessible."""
    suite = TestSuite(project_root=Path("."))
    assert suite.formatting is not None
    assert suite.imports is not None
    assert suite.logging is not None
    assert suite.config is not None
    assert suite.style is not None
    assert suite.safety is not None
    assert suite.schema is not None


def test_suite_skip_tests():
    """skip_tests parameter is respected."""
    suite = TestSuite(
        project_root=Path("."),
        skip_tests={"test_black_formatted", "test_imports_sorted"},
    )
    assert "test_black_formatted" in suite.skip_tests
