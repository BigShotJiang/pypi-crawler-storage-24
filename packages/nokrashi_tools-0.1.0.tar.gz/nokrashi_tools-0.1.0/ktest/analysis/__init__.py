"""
Analysis utilities for test gap identification and code quality.

Modules:
- analyze: Unified project analysis
- coverage: Coverage analysis, mutation testing, complexity metrics
- quality: Dead code, maintainability, slow/flaky tests, security
- runners: Test execution, health checks, error classification
- mock_analysis: Mock completeness and interface verification
- pattern_analysis: Test patterns, assertions, isolation checks
"""

from .analyze import AnalysisConfig, AnalysisReport, analyze_project
from .coverage import (compute_priority_score, get_complex_uncovered,
                       get_current_branch, get_new_untested_functions,
                       get_recently_changed_files, get_surviving_mutations,
                       get_uncovered_lines, score_and_sort_gaps)
from .mock_analysis import (MOCKABLE_PATTERNS, analyze_mock_completeness,
                            analyze_mock_interface_mismatches)
from .pattern_analysis import (analyze_assertion_quality,
                               analyze_import_chains,
                               analyze_timeout_prone_patterns,
                               check_test_isolation, get_test_to_code_mapping)
from .quality import (get_dead_code, get_flaky_tests,
                      get_maintainability_index, get_security_issues,
                      get_slow_tests, get_test_patterns, get_test_structure)
from .utils import (ERROR_PATTERNS, classify_error, detect_modules,
                    extract_root_cause, get_cache_dir, get_coverage_xml_path,
                    group_failures_by_root_cause, run_command, run_coverage,
                    run_test_health_check)

__all__ = [
    # Unified analysis
    "analyze_project",
    "AnalysisConfig",
    "AnalysisReport",
    # Coverage
    "get_uncovered_lines",
    "get_complex_uncovered",
    "get_new_untested_functions",
    "get_surviving_mutations",
    "get_current_branch",
    "get_recently_changed_files",
    "compute_priority_score",
    "score_and_sort_gaps",
    # Quality
    "get_test_structure",
    "get_dead_code",
    "get_maintainability_index",
    "get_slow_tests",
    "get_flaky_tests",
    "get_security_issues",
    "get_test_patterns",
    # Runners
    "run_command",
    "run_coverage",
    "run_test_health_check",
    "classify_error",
    "extract_root_cause",
    "group_failures_by_root_cause",
    "get_cache_dir",
    "get_coverage_xml_path",
    "detect_modules",
    "ERROR_PATTERNS",
    # Mock analysis
    "MOCKABLE_PATTERNS",
    "analyze_mock_completeness",
    "analyze_mock_interface_mismatches",
    # Pattern analysis
    "analyze_timeout_prone_patterns",
    "get_test_to_code_mapping",
    "analyze_assertion_quality",
    "check_test_isolation",
    "analyze_import_chains",
]
