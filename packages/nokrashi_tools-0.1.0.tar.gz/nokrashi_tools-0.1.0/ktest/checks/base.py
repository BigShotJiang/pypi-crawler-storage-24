"""
Base class for check modules with shared functionality.
"""

import ast
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CheckBase:
    """Base configuration and utilities for all check modules."""

    project_root: Path
    test_dir: str = "tests"
    skip_tests: set[str] = field(default_factory=set)
    skip_dirs: set[str] = field(
        default_factory=lambda: {
            ".git",
            "venv",
            ".venv",
            "__pycache__",
            ".pytest_cache",
            "node_modules",
        }
    )

    def get_python_files(self) -> list[Path]:
        """Get all Python files in project, excluding skip directories."""
        files = []
        for py_file in self.project_root.rglob("*.py"):
            if any(skip in py_file.parts for skip in self.skip_dirs):
                continue
            files.append(py_file)
        return files

    def get_relative_path(self, path: Path) -> str:
        """Get path relative to project root."""
        return str(path.relative_to(self.project_root))

    def parse_ast(self, content: str) -> ast.Module | None:
        """Parse Python content to AST, returning None on syntax error."""
        try:
            return ast.parse(content)
        except SyntaxError:
            return None
