#!/usr/bin/env python3
"""
Combined enrichment + decomposition run.

Phase 1: Enrich unenriched memories (adds tags, summary, keywords, search_queries)
Phase 2: Re-decompose all memories into atomic facts via re_decompose()

Uses the antaris_memory v5.3.0 editable install.
Checkpoints every CHECKPOINT_EVERY entries in Phase 1.
Reports progress to /tmp/enrich_decompose_progress.json
"""
import sys, os, time, json, warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
sys.stdout.reconfigure(line_buffering=True)
warnings.filterwarnings('ignore')
from urllib.request import Request, urlopen

# ── Config ─────────────────────────────────────────────────────────────────
API_KEY   = "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"
MODEL     = "claude-haiku-4-5-20251001"
WORKERS   = 6
CHECKPOINT_EVERY = 100
STORE_PATH = '/Users/moro/.openclaw/workspace/antaris_memory_store'
PROGRESS_FILE = '/tmp/enrich_decompose_progress.json'
LOG_FILE  = '/tmp/enrich_decompose.log'

PROMPT = (
    "Analyze this memory/note and extract semantic metadata to improve search recall.\n"
    "Focus on SYNONYMS and RELATED CONCEPTS that someone might use when searching.\n"
    "Return ONLY a valid JSON object with exactly these fields:\n"
    '- "tags": 5-10 snake_case semantic labels\n'
    '- "summary": one sentence rephrasing the core fact using DIFFERENT vocabulary than the original\n'
    '- "keywords": 8-15 terms someone might search to find this memory\n'
    '- "search_queries": 3 SPECIFIC natural language questions that ONLY this exact memory answers. '
    'Include exact names, version numbers, decisions. Each must be discriminative.\n'
    '- "facts": 2-5 atomic facts as short declarative sentences extracted from this memory. '
    'Each fact must be self-contained and specific.\n\n'
    "Memory:\n{text}\n\nJSON:"
)

# ── Logging ─────────────────────────────────────────────────────────────────
def log(msg):
    ts = time.strftime('%H:%M:%S')
    line = f'[{ts}] {msg}'
    print(line, flush=True)
    with open(LOG_FILE, 'a') as f:
        f.write(line + '\n')

def save_progress(phase, done, total, facts=0, errors=0):
    with open(PROGRESS_FILE, 'w') as f:
        json.dump({
            'phase': phase, 'done': done, 'total': total,
            'facts': facts, 'errors': errors,
            'pct': round(100 * done / total, 1) if total else 0,
            'ts': time.strftime('%H:%M:%S')
        }, f)

# ── API call ─────────────────────────────────────────────────────────────────
def enrich_one(args):
    h, content = args
    try:
        url = "https://api.anthropic.com/v1/messages"
        payload = json.dumps({
            "model": MODEL,
            "max_tokens": 600,
            "messages": [{"role": "user", "content": PROMPT.format(text=content[:800])}],
        })
        req = Request(url, data=payload.encode("utf-8"), method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("x-api-key", API_KEY)
        req.add_header("anthropic-version", "2023-06-01")
        with urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            raw = data["content"][0]["text"].strip()
            start = raw.find('{'); end = raw.rfind('}')
            if start != -1 and end > start:
                return h, json.loads(raw[start:end+1]), None
            return h, None, "no JSON"
    except Exception as e:
        return h, None, str(e)

# ── Shard helpers ─────────────────────────────────────────────────────────────
def load_all_shards(store_path):
    shards = {}
    for p in Path(store_path).glob('shards/shard_*.json'):
        if '.bak' in p.name:
            continue
        with open(p) as f:
            shards[p] = json.load(f)
    return shards

def save_shard(path, data):
    tmp = str(path) + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(data, f)
    os.replace(tmp, path)

# ── Phase 1: Enrich ──────────────────────────────────────────────────────────
def phase1_enrich(store_path):
    log("=== PHASE 1: Enrichment ===")
    shards = load_all_shards(store_path)

    # Collect unenriched
    todo = []
    for path, data in shards.items():
        for m in data.get('memories', []):
            if not m.get('enriched_summary') and m.get('content'):
                todo.append((m['hash'], m['content'], path))

    total = len(todo)
    if total == 0:
        log("All memories already enriched. Skipping Phase 1.")
        return

    log(f"Found {total} unenriched memories. Starting enrichment with {WORKERS} workers...")
    save_progress('enrich', 0, total)

    # Index by hash for fast lookup
    hash_to_shard = {}
    for path, data in shards.items():
        for m in data.get('memories', []):
            hash_to_shard[m['hash']] = path

    done = errors = 0
    pending_writes = {}  # path -> list of (hash, result)

    with ThreadPoolExecutor(max_workers=WORKERS) as executor:
        futures = {executor.submit(enrich_one, (h, c)): (h, p) for h, c, p in todo}
        for future in as_completed(futures):
            h, shard_path = futures[future]
            h_res, result, err = future.result()
            done += 1

            if result:
                if shard_path not in pending_writes:
                    pending_writes[shard_path] = []
                pending_writes[shard_path].append((h, result))
            else:
                errors += 1

            # Checkpoint
            if done % CHECKPOINT_EVERY == 0 or done == total:
                # Apply pending writes
                for spath, updates in pending_writes.items():
                    data = shards[spath]
                    update_map = {h: r for h, r in updates}
                    for m in data.get('memories', []):
                        if m['hash'] in update_map:
                            r = update_map[m['hash']]
                            m['enriched_summary'] = r.get('summary', '')
                            m['tags'] = r.get('tags', [])
                            m['search_keywords'] = r.get('keywords', [])
                            m['search_queries'] = r.get('search_queries', [])
                            # Store facts for Phase 2
                            if r.get('facts'):
                                m['_pending_facts'] = r['facts']
                    save_shard(spath, data)
                pending_writes.clear()
                save_progress('enrich', done, total, errors=errors)
                log(f"Phase 1: {done}/{total} ({100*done//total}%) | errors: {errors}")

    log(f"Phase 1 complete. Enriched {done - errors}/{total}. Errors: {errors}")

# ── Phase 2: Decompose ────────────────────────────────────────────────────────
def phase2_decompose(store_path):
    log("=== PHASE 2: Fact Decomposition ===")
    shards = load_all_shards(store_path)

    # Collect memories with pending facts or all non-fact memories
    all_mems = []
    for path, data in shards.items():
        for m in data.get('memories', []):
            if m.get('memory_type') != 'fact':
                all_mems.append((path, m))

    total = len(all_mems)
    log(f"Running re_decompose() on {total} non-fact memories via antaris_memory v5.3.0...")
    save_progress('decompose', 0, total)

    sys.path.insert(0, '/Users/moro/.openclaw/workspace/antaris-suite/antaris-memory')
    from antaris_memory import MemorySystem as MemorySystemV4

    def enricher(text):
        _, result, err = enrich_one(('_', text))
        return result

    mem = MemorySystemV4(
        workspace=store_path,
        agent_name='moro',
        enricher=enricher,
    )

    facts_created = [0]
    def progress_fn(processed, total_count, new_facts):
        facts_created[0] = new_facts
        save_progress('decompose', processed, total_count, facts=new_facts)
        log(f"Phase 2: {processed}/{total_count} processed | {new_facts} facts created")

    count = mem.re_decompose(batch_size=50, progress_fn=progress_fn, overwrite=False)
    log(f"Phase 2 complete. Created {count} atomic facts.")
    save_progress('decompose', total, total, facts=count)

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    log("=== Combined Enrichment + Decomposition Run ===")
    log(f"Store: {STORE_PATH}")
    log(f"Model: {MODEL}")
    log(f"Workers: {WORKERS}")

    # Verify API key works
    try:
        from urllib.request import urlopen, Request
        req = Request("https://api.anthropic.com/v1/messages",
            data=json.dumps({"model": MODEL, "max_tokens": 5,
                "messages": [{"role": "user", "content": "hi"}]}).encode(),
            method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("x-api-key", API_KEY)
        req.add_header("anthropic-version", "2023-06-01")
        with urlopen(req, timeout=10) as r:
            log(f"API key verified ✅ (status {r.status})")
    except Exception as e:
        log(f"API key check FAILED: {e}")
        sys.exit(1)

    phase1_enrich(STORE_PATH)
    phase2_decompose(STORE_PATH)
    log("=== ALL DONE ===")
