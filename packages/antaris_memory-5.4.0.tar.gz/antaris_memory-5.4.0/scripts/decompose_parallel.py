#!/usr/bin/env python3
"""
Parallel atomic fact decomposition — saves every CHECKPOINT_EVERY memories.
- 6 parallel API workers
- Checkpoints to disk every 50 processed (idempotent on restart)
- Tracks decomposed hashes in /tmp/decompose_done.json
- Resumes from where it left off if killed
"""
import sys, os, time, json, warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
sys.stdout.reconfigure(line_buffering=True)
warnings.filterwarnings('ignore')
from urllib.request import Request, urlopen

# ── Config ──────────────────────────────────────────────────────────────────
API_KEY   = "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"
MODEL     = "claude-sonnet-4-6"
WORKERS   = 5
CHECKPOINT_EVERY = 50
STORE_PATH = Path('/Users/moro/.openclaw/workspace/antaris_memory_store/shards')
PROGRESS_FILE = Path('/tmp/decompose_progress.json')
DONE_FILE     = Path('/tmp/decompose_done.json')   # set of hashes already decomposed
LOG_FILE      = Path('/tmp/decompose.log')

PROMPT = (
    "Extract 2-5 atomic facts from this memory as short, self-contained declarative sentences.\n"
    "Each fact must be specific, standalone, and searchable.\n"
    "Include exact names, versions, decisions, and outcomes.\n"
    "Return ONLY valid JSON: {{\"facts\": [\"fact1\", \"fact2\", ...]}}\n\n"
    "Memory:\n{text}\n\nJSON:"
)

# ── Helpers ──────────────────────────────────────────────────────────────────
def log(msg):
    ts = time.strftime('%H:%M:%S')
    line = f'[{ts}] {msg}'
    print(line, flush=True)
    with open(LOG_FILE, 'a') as f:
        f.write(line + '\n')

def save_progress(done, total, facts, errors, skipped):
    with open(PROGRESS_FILE, 'w') as f:
        json.dump({
            'phase': 'decompose', 'done': done, 'total': total,
            'facts': facts, 'errors': errors, 'skipped': skipped,
            'pct': round(100 * done / total, 1) if total else 0,
            'ts': time.strftime('%H:%M:%S')
        }, f)

def load_done_set():
    if DONE_FILE.exists():
        with open(DONE_FILE) as f:
            return set(json.load(f))
    return set()

def save_done_set(done_set):
    with open(DONE_FILE, 'w') as f:
        json.dump(list(done_set), f)

def load_shard(path):
    with open(path) as f:
        return json.load(f)

def save_shard(path, data):
    tmp = str(path) + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(data, f)
    os.replace(tmp, path)

# ── API call ──────────────────────────────────────────────────────────────────
def get_facts(h, content):
    try:
        payload = json.dumps({
            "model": MODEL, "max_tokens": 400,
            "messages": [{"role": "user", "content": PROMPT.format(text=content[:600])}],
        })
        req = Request("https://api.anthropic.com/v1/messages",
            data=payload.encode(), method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("x-api-key", API_KEY)
        req.add_header("anthropic-version", "2023-06-01")
        with urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode())
            raw = data["content"][0]["text"].strip()
            s, e = raw.find('{'), raw.rfind('}')
            if s != -1 and e > s:
                result = json.loads(raw[s:e+1])
                facts = result.get("facts", [])
                if isinstance(facts, list):
                    return h, [f.strip() for f in facts if isinstance(f, str) and len(f.strip()) >= 10], None
        return h, [], "no valid JSON"
    except Exception as ex:
        return h, [], str(ex)

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    log("=== Parallel Decompose ===")
    log(f"Workers: {WORKERS} | Checkpoint every: {CHECKPOINT_EVERY} | Model: {MODEL}")

    # Load all shards
    shard_files = sorted(STORE_PATH.glob('shard_*.json'))
    log(f"Loading {len(shard_files)} shards...")

    # Build work list — all non-fact memories not yet decomposed
    done_set = load_done_set()
    log(f"Resuming — {len(done_set)} already decomposed")

    # Build index: hash -> (shard_path, memory_index)
    shard_data = {}
    todo = []
    existing_parent_hashes = set()

    for sp in shard_files:
        data = load_shard(sp)
        shard_data[sp] = data
        for m in data.get('memories', []):
            ph = m.get('parent_hash', '')
            if ph:
                existing_parent_hashes.add(ph)

    for sp, data in shard_data.items():
        for m in data.get('memories', []):
            h = m.get('hash', '')
            mt = m.get('memory_type', 'semantic')
            if mt == 'fact':
                continue
            if h in done_set:
                continue
            if h in existing_parent_hashes:
                done_set.add(h)  # already decomposed in a previous run
                continue
            content = m.get('content', '')
            if content:
                todo.append((h, content, sp))

    total = len(todo) + len(done_set)
    skipped = len(done_set)
    log(f"Total non-fact memories: {total} | Already done: {skipped} | To process: {len(todo)}")
    save_progress(skipped, total, 0, 0, skipped)

    if not todo:
        log("Nothing to decompose. All done!")
        return

    # Process in parallel
    done = skipped
    errors = 0
    facts_created = 0
    pending = {}  # shard_path -> list of new fact dicts
    newly_done = set()

    def make_fact_entry(content, source_entry, parent_hash):
        import hashlib, time as _time
        h = hashlib.sha256(content.encode()).hexdigest()[:16]
        return {
            "hash": h,
            "content": content,
            "source": source_entry.get('source', 'decomposed'),
            "line": 0,
            "timestamp": _time.strftime('%Y-%m-%dT%H:%M:%SZ', _time.gmtime()),
            "memory_type": "fact",
            "category": source_entry.get('category', 'general'),
            "importance": 0.8,
            "confidence": 0.8,
            "provenance": "decomposed",
            "parent_hash": parent_hash,
            "session_id": source_entry.get('session_id', ''),
            "agent_id": source_entry.get('agent_id', 'moro'),
            "tags": source_entry.get('tags', []),
            "access_count": 0,
        }

    # Build hash -> source memory lookup
    hash_to_entry = {}
    hash_to_shard = {}
    for sp, data in shard_data.items():
        for m in data.get('memories', []):
            h = m.get('hash', '')
            if h:
                hash_to_entry[h] = m
                hash_to_shard[h] = sp

    # Track all existing hashes to avoid duplicates
    all_hashes = set()
    for sp, data in shard_data.items():
        for m in data.get('memories', []):
            all_hashes.add(m.get('hash', ''))

    log(f"Starting parallel decompose with {WORKERS} workers...")

    with ThreadPoolExecutor(max_workers=WORKERS) as executor:
        futures = {executor.submit(get_facts, h, c): (h, sp) for h, c, sp in todo}

        for future in as_completed(futures):
            h, sp = futures[future]
            h_res, facts, err = future.result()
            done += 1

            if err and not facts:
                errors += 1
            else:
                newly_done.add(h)
                source_entry = hash_to_entry.get(h, {})
                for fact_text in facts:
                    fact = make_fact_entry(fact_text, source_entry, h)
                    if fact['hash'] not in all_hashes:
                        all_hashes.add(fact['hash'])
                        if sp not in pending:
                            pending[sp] = []
                        pending[sp].append(fact)
                        facts_created += 1

            # Checkpoint
            if (done - skipped) % CHECKPOINT_EVERY == 0 or done == total:
                # Write pending facts to shards
                for spath, new_facts in pending.items():
                    data = shard_data[spath]
                    data.setdefault('memories', []).extend(new_facts)
                    save_shard(spath, data)
                pending.clear()

                # Update done set
                done_set.update(newly_done)
                newly_done.clear()
                save_done_set(done_set)
                save_progress(done, total, facts_created, errors, skipped)
                log(f"Progress: {done}/{total} ({100*(done-skipped)//(total-skipped) if total>skipped else 100}%) | facts: {facts_created} | errors: {errors}")

    log(f"=== DECOMPOSE COMPLETE ===")
    log(f"Processed: {done - skipped} | Facts created: {facts_created} | Errors: {errors}")
    save_progress(done, total, facts_created, errors, skipped)

if __name__ == '__main__':
    main()
