"""python -m antarisbot.suite.memory entry point."""
import sys
from antaris_memory.cli import main

if __name__ == "__main__":
    sys.exit(main())
