"""Web crawling and content extraction for knowledge ingestion (v4.7.0)."""

import hashlib
import html.parser
import logging
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser
import xml.etree.ElementTree as ET
from typing import List, Optional, Set

_log = logging.getLogger("antarisbot.suite.memory.ingest_web")

USER_AGENT = "antaris-memory/4.7.0"
TIMEOUT = 10
MIN_CHUNK_LEN = 50


class _HTMLTextExtractor(html.parser.HTMLParser):
    """Strip HTML tags and collect text paragraphs."""

    _SKIP_TAGS = frozenset(["script", "style", "noscript", "head", "meta", "link"])

    def __init__(self):
        super().__init__()
        self._texts: List[str] = []
        self._current: List[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag, attrs):
        if tag in self._SKIP_TAGS:
            self._skip_depth += 1
        if tag in ("p", "div", "br", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "blockquote"):
            self._flush()

    def handle_endtag(self, tag):
        if tag in self._SKIP_TAGS and self._skip_depth > 0:
            self._skip_depth -= 1
        if tag in ("p", "div", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "blockquote"):
            self._flush()

    def handle_data(self, data):
        if self._skip_depth == 0:
            self._current.append(data)

    def _flush(self):
        text = " ".join(self._current).strip()
        text = re.sub(r"\s+", " ", text)
        if len(text) >= MIN_CHUNK_LEN:
            self._texts.append(text)
        self._current = []

    def get_chunks(self) -> List[str]:
        self._flush()
        return self._texts


def _content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


class WebCrawler:
    """Crawl URLs and extract text chunks for ingestion."""

    def __init__(self):
        self._robot_parsers: dict = {}

    def _check_robots(self, url: str) -> bool:
        """Return True if crawling is allowed by robots.txt."""
        try:
            parsed = urllib.parse.urlparse(url)
            robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
            if robots_url not in self._robot_parsers:
                rp = urllib.robotparser.RobotFileParser()
                rp.set_url(robots_url)
                try:
                    rp.read()
                except Exception:
                    # If we can't read robots.txt, assume allowed
                    return True
                self._robot_parsers[robots_url] = rp
            return self._robot_parsers[robots_url].can_fetch(USER_AGENT, url)
        except Exception:
            return True

    def _fetch(self, url: str) -> Optional[str]:
        """Fetch HTML content from a URL."""
        try:
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                charset = resp.headers.get_content_charset() or "utf-8"
                return resp.read().decode(charset, errors="replace")
        except Exception as e:
            _log.warning("Failed to fetch %s: %s", url, e)
            return None

    def _extract_chunks(self, html_content: str, source_url: str) -> List[dict]:
        """Extract text chunks from HTML."""
        parser = _HTMLTextExtractor()
        try:
            parser.feed(html_content)
        except Exception:
            pass
        chunks = []
        for text in parser.get_chunks():
            chunks.append({
                "text": text,
                "source_url": source_url,
                "content_hash": _content_hash(text),
                "crawl_ts": time.time(),
            })
        return chunks

    def _extract_links(self, html_content: str, base_url: str) -> List[str]:
        """Extract absolute links from HTML for depth crawling."""
        links = []
        try:
            for match in re.finditer(r'href=["\']([^"\']+)["\']', html_content, re.IGNORECASE):
                href = match.group(1)
                absolute = urllib.parse.urljoin(base_url, href)
                parsed = urllib.parse.urlparse(absolute)
                if parsed.scheme in ("http", "https"):
                    # Stay on same domain
                    base_parsed = urllib.parse.urlparse(base_url)
                    if parsed.netloc == base_parsed.netloc:
                        links.append(absolute.split("#")[0])
        except Exception:
            pass
        return list(set(links))

    def crawl(self, url: str, depth: int = 1) -> List[dict]:
        """Crawl a URL and return text chunks.

        Args:
            url: Starting URL.
            depth: How many link-levels deep to crawl (1 = just this page).

        Returns:
            List of {text, source_url, content_hash, crawl_ts}.
        """
        results: List[dict] = []
        seen_hashes: Set[str] = set()
        visited: Set[str] = set()
        to_visit = [(url, 0)]

        while to_visit:
            current_url, current_depth = to_visit.pop(0)
            if current_url in visited:
                continue
            visited.add(current_url)

            if not self._check_robots(current_url):
                _log.info("Blocked by robots.txt: %s", current_url)
                continue

            html_content = self._fetch(current_url)
            if html_content is None:
                continue

            for chunk in self._extract_chunks(html_content, current_url):
                if chunk["content_hash"] not in seen_hashes:
                    seen_hashes.add(chunk["content_hash"])
                    results.append(chunk)

            if current_depth + 1 < depth:
                for link in self._extract_links(html_content, current_url):
                    if link not in visited:
                        to_visit.append((link, current_depth + 1))

        return results

    def crawl_sitemap(self, sitemap_url: str) -> List[dict]:
        """Parse an XML sitemap and crawl each URL found.

        Args:
            sitemap_url: URL to a sitemap.xml file.

        Returns:
            Combined list of chunks from all sitemap URLs.
        """
        results: List[dict] = []
        seen_hashes: Set[str] = set()

        html_content = self._fetch(sitemap_url)
        if html_content is None:
            return results

        try:
            root = ET.fromstring(html_content)
            # Handle namespace
            ns = ""
            if root.tag.startswith("{"):
                ns = root.tag.split("}")[0] + "}"

            for loc_elem in root.iter(f"{ns}loc"):
                page_url = (loc_elem.text or "").strip()
                if not page_url:
                    continue

                # Check if it's a nested sitemap
                if page_url.endswith(".xml"):
                    try:
                        nested = self.crawl_sitemap(page_url)
                        for chunk in nested:
                            if chunk["content_hash"] not in seen_hashes:
                                seen_hashes.add(chunk["content_hash"])
                                results.append(chunk)
                    except Exception as e:
                        _log.warning("Nested sitemap failed %s: %s", page_url, e)
                    continue

                for chunk in self.crawl(page_url, depth=1):
                    if chunk["content_hash"] not in seen_hashes:
                        seen_hashes.add(chunk["content_hash"])
                        results.append(chunk)
        except ET.ParseError as e:
            _log.warning("Failed to parse sitemap %s: %s", sitemap_url, e)

        return results
