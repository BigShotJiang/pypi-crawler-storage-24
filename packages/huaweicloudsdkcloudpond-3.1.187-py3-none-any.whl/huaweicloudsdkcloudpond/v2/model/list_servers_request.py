# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListServersRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'edge_site_id': 'str',
        'limit': 'int',
        'marker': 'str',
        'status': 'list[ServerStatus]',
        'id': 'list[str]'
    }

    attribute_map = {
        'edge_site_id': 'edge_site_id',
        'limit': 'limit',
        'marker': 'marker',
        'status': 'status',
        'id': 'id'
    }

    def __init__(self, edge_site_id=None, limit=None, marker=None, status=None, id=None):
        r"""ListServersRequest

        The model defined in huaweicloud sdk

        :param edge_site_id: 边缘小站ID
        :type edge_site_id: str
        :param limit: 每页的数量
        :type limit: int
        :param marker: 分页标识
        :type marker: str
        :param status: 根据服务器状态查询，支持多值查询
        :type status: list[:class:`huaweicloudsdkcloudpond.v2.ServerStatus`]
        :param id: 根据ID过滤，支持多值查询，查询条件格式：id&#x3D;xxx&amp;id&#x3D;xxx。
        :type id: list[str]
        """
        
        

        self._edge_site_id = None
        self._limit = None
        self._marker = None
        self._status = None
        self._id = None
        self.discriminator = None

        if edge_site_id is not None:
            self.edge_site_id = edge_site_id
        if limit is not None:
            self.limit = limit
        if marker is not None:
            self.marker = marker
        if status is not None:
            self.status = status
        if id is not None:
            self.id = id

    @property
    def edge_site_id(self):
        r"""Gets the edge_site_id of this ListServersRequest.

        边缘小站ID

        :return: The edge_site_id of this ListServersRequest.
        :rtype: str
        """
        return self._edge_site_id

    @edge_site_id.setter
    def edge_site_id(self, edge_site_id):
        r"""Sets the edge_site_id of this ListServersRequest.

        边缘小站ID

        :param edge_site_id: The edge_site_id of this ListServersRequest.
        :type edge_site_id: str
        """
        self._edge_site_id = edge_site_id

    @property
    def limit(self):
        r"""Gets the limit of this ListServersRequest.

        每页的数量

        :return: The limit of this ListServersRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListServersRequest.

        每页的数量

        :param limit: The limit of this ListServersRequest.
        :type limit: int
        """
        self._limit = limit

    @property
    def marker(self):
        r"""Gets the marker of this ListServersRequest.

        分页标识

        :return: The marker of this ListServersRequest.
        :rtype: str
        """
        return self._marker

    @marker.setter
    def marker(self, marker):
        r"""Sets the marker of this ListServersRequest.

        分页标识

        :param marker: The marker of this ListServersRequest.
        :type marker: str
        """
        self._marker = marker

    @property
    def status(self):
        r"""Gets the status of this ListServersRequest.

        根据服务器状态查询，支持多值查询

        :return: The status of this ListServersRequest.
        :rtype: list[:class:`huaweicloudsdkcloudpond.v2.ServerStatus`]
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this ListServersRequest.

        根据服务器状态查询，支持多值查询

        :param status: The status of this ListServersRequest.
        :type status: list[:class:`huaweicloudsdkcloudpond.v2.ServerStatus`]
        """
        self._status = status

    @property
    def id(self):
        r"""Gets the id of this ListServersRequest.

        根据ID过滤，支持多值查询，查询条件格式：id=xxx&id=xxx。

        :return: The id of this ListServersRequest.
        :rtype: list[str]
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this ListServersRequest.

        根据ID过滤，支持多值查询，查询条件格式：id=xxx&id=xxx。

        :param id: The id of this ListServersRequest.
        :type id: list[str]
        """
        self._id = id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListServersRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
