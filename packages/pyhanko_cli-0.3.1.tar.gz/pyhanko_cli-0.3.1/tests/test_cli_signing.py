import asyncio
import getpass
import itertools
from typing import Optional

import pytest
from asn1crypto import pem
from asn1crypto.cms import ContentInfo
from certomancer import PKIArchitecture
from certomancer.registry import CertLabel, KeyLabel
from cryptography.hazmat.primitives import serialization
from pyhanko.cli import cli_root
from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
from pyhanko.pdf_utils.reader import PdfFileReader
from pyhanko.sign.validation import async_validate_detached_cms
from pyhanko_certvalidator import ValidationContext
from pyhanko_testing_commons.test_data.samples import (
    MINIMAL_AES256,
    MINIMAL_HYBRID,
    MINIMAL_ONE_FIELD,
    MINIMAL_PUBKEY_AES256,
    MINIMAL_SLIGHTLY_BROKEN,
    TESTING_CA,
)

from .conftest import (
    DUMMY_PASSPHRASE,
    INPUT_PATH,
    LTV_CERTOMANCER_ARCHITECTURES,
    SIGNED_OUTPUT_PATH,
    _const,
    _write_cert,
    _write_config,
)


@pytest.fixture
def unencrypted_p12(pki_arch, post_validate):
    p12_bytes = pki_arch.package_pkcs12(CertLabel("signer1"))
    fname = 'signer.p12'
    with open(fname, 'wb') as outf:
        outf.write(p12_bytes)
    return fname


def _write_user_key(
    pki_arch: PKIArchitecture, passphrase: Optional[bytes] = None
):
    key = pki_arch.key_set.get_private_key(KeyLabel('signer1'))
    key_handle = serialization.load_der_private_key(key.dump(), password=None)
    pem_bytes = key_handle.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=(
            serialization.BestAvailableEncryption(passphrase)
            if passphrase
            else serialization.NoEncryption()
        ),
    )

    fname = 'signer.key.pem'
    with open(fname, 'wb') as outf:
        outf.write(pem_bytes)
    return fname


@pytest.fixture
def user_key(pki_arch, post_validate):
    return _write_user_key(pki_arch)


@pytest.fixture
def encrypted_user_key(pki_arch, post_validate):
    return _write_user_key(pki_arch, passphrase=DUMMY_PASSPHRASE.encode("utf8"))


def test_cli_addsig_pemder(cli_runner, cert_chain, user_key):
    root_cert, interm_cert, user_cert = cert_chain
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


def test_cli_addsig_pemder_without_nopass(
    cli_runner, cert_chain, user_key, monkeypatch
):
    # expect a warning, but no errors
    monkeypatch.setattr(getpass, 'getpass', _const(""))

    root_cert, interm_cert, user_cert = cert_chain
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


def _pemder_setup_config(user_key, cert_chain) -> dict:
    root_cert, interm_cert, user_cert = cert_chain
    return {
        'pemder-setups': {
            'test': {
                'key-file': user_key,
                'cert-file': user_cert,
                'other-certs': [interm_cert, root_cert],
            }
        }
    }


def test_cli_addsig_pemder_with_setup(cli_runner, cert_chain, user_key):
    cfg = _pemder_setup_config(user_key, cert_chain)
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--pemder-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.parametrize('pki_arch_name', ['ed25519'])
def test_cli_addsig_pemder_with_wrong_key_usage(
    cli_runner, cert_chain, user_key, root_cert, pki_arch_name
):
    cfg = _pemder_setup_config(user_key, cert_chain)
    cfg['validation-contexts'] = {
        'test': {
            'trust': root_cert,
            # makes no sense
            'signer-key-usage': 'crl_sign',
        }
    }
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            '--validation-context',
            'test',
            '--with-validation-info',
            'pemder',
            '--no-pass',
            '--pemder-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "not valid for the purpose" in result.output


@pytest.mark.xfail
@pytest.mark.parametrize('pki_arch_name', ['ed25519'])
def test_cli_addsig_pemder_with_wrong_extd_key_usage(
    cli_runner, cert_chain, user_key, root_cert, pki_arch_name
):
    # This validation should actually fail, but there's
    # no support for extended key usage in presign checks now,
    # so we use this test to document the limitation
    cfg = _pemder_setup_config(user_key, cert_chain)
    cfg['validation-contexts'] = {
        'test': {
            'trust': root_cert,
            'signer-extd-key-usage': '2.999',
        }
    }
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            '--validation-context',
            'test',
            '--with-validation-info',
            'pemder',
            '--no-pass',
            '--pemder-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1


def test_cli_addsig_pemder_with_setup_in_custom_config_file(
    cli_runner, cert_chain, user_key
):
    cfg = _pemder_setup_config(user_key, cert_chain)
    _write_config(cfg, 'pyhanko-config.yml')
    result = cli_runner.invoke(
        cli_root,
        [
            '--config',
            'pyhanko-config.yml',
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--pemder-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.parametrize('loc', ['config', 'passfile', 'prompt'])
def test_cli_addsig_pemder_with_setup_encrypted_key(
    cli_runner, cert_chain, encrypted_user_key, monkeypatch, loc
):
    cfg = _pemder_setup_config(encrypted_user_key, cert_chain)
    if loc == 'config':
        cfg['pemder-setups']['test']['key-passphrase'] = DUMMY_PASSPHRASE
        args = []
    elif loc == 'passfile':
        with open('passfile', 'w') as passf:
            passf.write(DUMMY_PASSPHRASE)
        args = ['--passfile', 'passfile']
    else:
        args = []
        monkeypatch.setattr(getpass, 'getpass', _const(DUMMY_PASSPHRASE))

    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--pemder-setup',
            'test',
            *args,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


def test_cli_addsig_pemder_setup_requires_config(cli_runner):
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--pemder-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "requires a configuration file" in result.output


def test_cli_addsig_pemder_some_args_required(cli_runner):
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "option must be provided" in result.output


def test_cli_addsig_pemder_setup_does_not_exist(cli_runner):
    cfg = {'pemder-setups': {}}
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--pemder-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "Error while reading PEM/DER setup" in result.output


def test_cli_addsig_pemder_with_unreadable_additional_certs(cli_runner):
    with open("bad-cert.pem", "w") as outf:
        outf.write("blah")
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--key',
            _write_user_key(TESTING_CA),
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            '--chain',
            'bad-cert.pem',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "Could not load certificates" in result.output


@pytest.mark.parametrize(
    'with_timestamp,pki_arch_name,fmt',
    list(
        itertools.product(
            ['claimed', 'tsa'], LTV_CERTOMANCER_ARCHITECTURES, ['pem', 'der']
        )
    ),
)
def test_cli_addsig_pemder_detached(
    cli_runner,
    pki_arch_name,
    pki_arch,
    cert_chain,
    user_key,
    timestamp_url,
    with_timestamp,
    fmt,
):
    cfg = _pemder_setup_config(user_key, cert_chain)
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            *(
                ('--timestamp-url', timestamp_url)
                if with_timestamp == 'tsa'
                else ()
            ),
            '--detach-pem' if fmt == 'pem' else '--detach',
            'pemder',
            '--no-pass',
            '--pemder-setup',
            'test',
            INPUT_PATH,
            'output.sig.pem',
        ],
    )
    assert not result.exception, result.output
    with open(INPUT_PATH, 'rb') as in_data:
        with open('output.sig.pem', 'rb') as sig_data:
            sig_data_bytes = sig_data.read()
            if fmt == 'pem':
                cms_der = pem.unarmor(sig_data_bytes)[2]
            else:
                cms_der = sig_data_bytes
            sd = ContentInfo.load(cms_der)['content']
            status = asyncio.run(
                async_validate_detached_cms(
                    in_data,
                    sd,
                    signer_validation_context=ValidationContext(
                        trust_roots=[pki_arch.get_cert(CertLabel('root'))],
                        allow_fetching=True,
                    ),
                )
            )
            assert status.bottom_line, status.pretty_print_details()
            if with_timestamp == 'tsa':
                assert status.timestamp_validity is not None
            else:
                assert status.timestamp_validity is None


def test_cli_addsig_pemder_detached_no_field_arg(
    cli_runner,
):
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--detach-pem',
            '--field',
            'Sig1',
            'pemder',
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            '--key',
            _write_user_key(TESTING_CA),
            INPUT_PATH,
            'output.sig.pem',
        ],
    )
    assert result.exit_code == 1
    assert '--field is not compatible with --detach' in result.output


def test_cli_addsig_p12(cli_runner, p12_keys, monkeypatch):
    monkeypatch.setattr(getpass, 'getpass', value=_const(DUMMY_PASSPHRASE))
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs12',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
            p12_keys,
        ],
    )
    assert not result.exception, result.output


def test_cli_addsig_unencrypted_p12(cli_runner, unencrypted_p12):
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs12',
            '--no-pass',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
            unencrypted_p12,
        ],
    )
    assert not result.exception, result.output


def test_cli_addsig_unencrypted_p12_without_nopass(
    cli_runner, unencrypted_p12, monkeypatch
):
    # expect a warning, but no errors
    monkeypatch.setattr(getpass, 'getpass', _const(""))

    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs12',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
            unencrypted_p12,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.parametrize('passphrase_loc', ['config', 'prompt', 'file'])
def test_cli_addsig_p12_with_setup(
    cli_runner, p12_keys, monkeypatch, passphrase_loc
):
    cfg = {
        'pkcs12-setups': {
            'test': {
                'pfx-file': p12_keys,
            }
        }
    }
    args = []
    if passphrase_loc == 'config':
        cfg['pkcs12-setups']['test']['pfx_passphrase'] = DUMMY_PASSPHRASE
    elif passphrase_loc == 'prompt':
        monkeypatch.setattr(getpass, 'getpass', value=_const(DUMMY_PASSPHRASE))
    elif passphrase_loc == 'file':
        args = ['--passfile', 'passfile']
        with open('passfile', 'w') as pf:
            pf.write(DUMMY_PASSPHRASE)

    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs12',
            '--p12-setup',
            'test',
            *args,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


def test_cli_addsig_p12_setup_requires_config(cli_runner):
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs12',
            '--p12-setup',
            'blah',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "requires a configuration file" in result.output


def test_cli_addsig_p12_setup_unreadable(cli_runner):
    _write_config({'p12-setup': {}})
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs12',
            '--p12-setup',
            'blah',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "Error while reading PKCS#12 config" in result.output


def test_cli_addsig_p12_setup_corrupted_keystore(cli_runner):
    _write_config(
        {
            'pkcs12-setups': {
                'blah': {
                    'pfx-file': 'test.p12',
                }
            }
        }
    )
    with open('test.p12', 'wb') as f:
        f.write(b"\xde\xad\xbe\xef")
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs12',
            '--no-pass',
            '--p12-setup',
            'blah',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    print(result.output)
    assert result.exit_code == 1
    assert "Could not load key material" in result.output


def test_cli_addsig_p12_setup_or_pfx_argument_required(cli_runner):
    _write_config({'p12-setup': {}})
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs12',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "argument or the --p12-setup" in result.output


def test_cli_addsig_p12_passfile(cli_runner, p12_keys):
    with open('passfile', 'w') as pf:
        pf.write(DUMMY_PASSPHRASE)

    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pkcs12',
            '--passfile',
            'passfile',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
            p12_keys,
        ],
    )
    assert not result.exception, result.output


def test_cli_sign_pkcs12_visible_while_creating_field(
    cli_runner, monkeypatch, p12_keys, post_validate
):
    monkeypatch.setattr(getpass, 'getpass', value=_const(DUMMY_PASSPHRASE))
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            '1/0,0,100,100/Sig1',
            'pkcs12',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
            p12_keys,
        ],
    )
    assert not result.exception, result.output


def test_cli_sign_visible_no_style(
    cli_runner, cert_chain, user_key, post_validate
):
    root_cert, interm_cert, user_cert = cert_chain
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            '1/0,0,100,100/Sig1',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


def test_cli_sign_visible_with_style(
    cli_runner, cert_chain, user_key, post_validate
):
    cfg = {
        'stamp-styles': {'test': {'type': 'text', 'background': '__stamp__'}}
    }
    _write_config(cfg)
    root_cert, interm_cert, user_cert = cert_chain
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--style-name',
            'test',
            '--field',
            '1/0,0,100,100/Sig1',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.nosmoke
def test_cli_sign_visible_with_qr_style(
    cli_runner, cert_chain, user_key, post_validate
):
    cfg = {'stamp-styles': {'test': {'type': 'qr', 'background': '__stamp__'}}}
    _write_config(cfg)
    root_cert, interm_cert, user_cert = cert_chain
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--stamp-url',
            'https://example.com',
            '--style-name',
            'test',
            '--field',
            '1/0,0,100,100/Sig1',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.nosmoke
@pytest.mark.parametrize('pki_arch_name', ['ed25519'])
def test_cli_sign_visible_with_qr_style_omit_stamp_url(
    cli_runner, cert_chain, user_key, post_validate, pki_arch_name
):
    cfg = {'stamp-styles': {'test': {'type': 'qr', 'background': '__stamp__'}}}
    _write_config(cfg)
    root_cert, interm_cert, user_cert = cert_chain
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--style-name',
            'test',
            '--field',
            '1/0,0,100,100/Sig1',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert 'QR stamp styles require the --stamp-url option' in result.output


def test_cli_add_field_then_sign(cli_runner, cert_chain, user_key):
    root_cert, interm_cert, user_cert = cert_chain
    intermediate_file_path = 'presign.pdf'
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addfields',
            '--field',
            '1/0,0,100,100/Sig1',
            INPUT_PATH,
            intermediate_file_path,
        ],
    )
    assert not result.exception, result.output
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            '--existing-only',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            intermediate_file_path,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


def test_cli_sign_implied_field(cli_runner, cert_chain, user_key):
    root_cert, interm_cert, user_cert = cert_chain
    with open(INPUT_PATH, 'wb') as f:
        f.write(MINIMAL_ONE_FIELD)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--existing-only',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


def test_cli_sign_field_param_required(cli_runner):
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--existing-only',
            'pemder',
            '--no-pass',
            '--key',
            _write_user_key(TESTING_CA),
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "There are no empty signature fields" in result.output


@pytest.mark.parametrize('pki_arch_name', LTV_CERTOMANCER_ARCHITECTURES)
def test_cli_pades_lta(
    pki_arch_name, timestamp_url, cli_runner, root_cert, p12_keys
):
    cfg = {
        'pkcs12-setups': {
            'test': {'pfx-file': p12_keys, 'pfx-passphrase': DUMMY_PASSPHRASE}
        },
        'validation-contexts': {
            'test': {
                'trust': root_cert,
            }
        },
    }

    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            '--validation-context',
            'test',
            '--with-validation-info',
            '--use-pades-lta',
            '--timestamp-url',
            timestamp_url,
            'pkcs12',
            '--p12-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


@pytest.mark.parametrize('pki_arch_name', LTV_CERTOMANCER_ARCHITECTURES)
def test_cli_pades_lta_nonstrict(
    pki_arch_name, timestamp_url, cli_runner, root_cert, p12_keys
):
    cfg = {
        'pkcs12-setups': {
            'test': {'pfx-file': p12_keys, 'pfx-passphrase': DUMMY_PASSPHRASE}
        },
        'validation-contexts': {
            'test': {
                'trust': root_cert,
            }
        },
    }

    _write_config(cfg)
    with open(INPUT_PATH, 'wb') as inf:
        inf.write(MINIMAL_SLIGHTLY_BROKEN)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            '--no-strict-syntax',
            '--validation-context',
            'test',
            '--with-validation-info',
            '--use-pades-lta',
            '--timestamp-url',
            timestamp_url,
            'pkcs12',
            '--p12-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


def test_cli_addsig_pemder_encrypted_file(
    cli_runner, cert_chain, user_key, monkeypatch
):
    with open(INPUT_PATH, 'wb') as inf:
        inf.write(MINIMAL_AES256)
    monkeypatch.setattr(getpass, 'getpass', _const("ownersecret"))
    cfg = _pemder_setup_config(user_key, cert_chain)
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--pemder-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output


def test_cli_addsig_no_pubkey_encryption(cli_runner):
    with open(INPUT_PATH, 'wb') as inf:
        inf.write(MINIMAL_PUBKEY_AES256)
    cfg = {
        'pemder-setups': {
            'test': {
                'key-file': _write_user_key(TESTING_CA),
                'cert-file': _write_cert(
                    TESTING_CA, CertLabel('signer1'), fname='cert.pem'
                ),
            }
        }
    }
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--pemder-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "Public-key document encryption is not supported" in result.output


def test_cli_addsig_wrong_password(cli_runner, monkeypatch):
    with open(INPUT_PATH, 'wb') as inf:
        inf.write(MINIMAL_AES256)
    monkeypatch.setattr(getpass, 'getpass', _const("wrong"))
    cfg = {
        'pemder-setups': {
            'test': {
                'key-file': _write_user_key(TESTING_CA),
                'cert-file': _write_cert(
                    TESTING_CA, CertLabel('signer1'), fname='cert.pem'
                ),
            }
        }
    }
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--pemder-setup',
            'test',
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "Invalid password" in result.output


def test_cli_sign_visible_with_custom_default_style(
    cli_runner, cert_chain, user_key
):
    cfg = {
        'default-stamp-style': 'test',
        'stamp-styles': {
            'test': {
                'type': 'text',
                'background': '__stamp__',
                'stamp_text': 'Blah',
            }
        },
    }
    _write_config(cfg)
    root_cert, interm_cert, user_cert = cert_chain
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            '1/0,0,100,100/Sig1',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    with open(SIGNED_OUTPUT_PATH, 'rb') as outf:
        r = PdfFileReader(outf)
        page = r.root['/Pages']['/Kids'][0]
        assert b'Blah' in page['/Annots'][0]['/AP']['/N'].data
    assert not result.exception, result.output


def test_cli_sign_visible_with_default_style_and_others_in_config(
    cli_runner, cert_chain, user_key
):
    cfg = {
        'stamp-styles': {
            'test': {
                'type': 'text',
                'background': '__stamp__',
                'stamp_text': 'Blah',
            }
        },
    }
    _write_config(cfg)
    root_cert, interm_cert, user_cert = cert_chain
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            '1/0,0,100,100/Sig1',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    with open(SIGNED_OUTPUT_PATH, 'rb') as outf:
        r = PdfFileReader(outf)
        page = r.root['/Pages']['/Kids'][0]
        assert b'Digitally signed by' in page['/Annots'][0]['/AP']['/N'].data
    assert not result.exception, result.output


def test_cli_sign_visible_with_undefined_default_style(
    cli_runner, cert_chain, user_key
):
    cfg = {
        'default-stamp-style': 'undefined',
        'stamp-styles': {
            'test': {'type': 'text', 'background': '__stamp__'},
        },
    }
    _write_config(cfg)
    root_cert, interm_cert, user_cert = cert_chain
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            '1/0,0,100,100/Sig1',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "There is no stamp style named 'undefined'" in result.output


def test_cli_sign_visible_with_style_but_no_config(
    cli_runner, cert_chain, user_key
):
    root_cert, interm_cert, user_cert = cert_chain
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--style-name',
            'test',
            '--field',
            '1/0,0,100,100/Sig1',
            'pemder',
            '--no-pass',
            '--cert',
            user_cert,
            '--chain',
            interm_cert,
            '--key',
            user_key,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "requires a configuration file" in result.output


def test_cli_new_field_spec_bars_existing_only(cli_runner):
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            '1/0,0,100,100/Sig1',
            '--existing-only',
            'pemder',
            '--no-pass',
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            '--key',
            _write_user_key(TESTING_CA),
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "incompatible with --existing-only" in result.output


def test_cli_underspecified_visible_new_field(cli_runner):
    cfg = {
        'stamp-styles': {'test': {'type': 'text', 'background': '__stamp__'}}
    }
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            '--style-name',
            'test',
            'pemder',
            '--no-pass',
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            '--key',
            _write_user_key(TESTING_CA),
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "'Sig1' does not exist in the PDF file" in result.output
    assert "you did not specify a bounding box" in result.output


def test_cli_underspecified_visible_new_field_no_name(cli_runner):
    cfg = {
        'stamp-styles': {'test': {'type': 'text', 'background': '__stamp__'}}
    }
    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--style-name',
            'test',
            'pemder',
            '--no-pass',
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            '--key',
            _write_user_key(TESTING_CA),
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "did not contain any signature fields" in result.output
    assert "you did not specify a bounding box" in result.output


@pytest.mark.parametrize(
    'field_name_passed,box',
    list(
        itertools.product(
            [True, False], [None, (0, 0, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1)]
        )
    ),
)
def test_cli_explicit_style_but_field_invisible(
    cli_runner, field_name_passed, box
):
    cfg = {
        'stamp-styles': {'test': {'type': 'text', 'background': '__stamp__'}}
    }
    _write_config(cfg)

    with open(INPUT_PATH, 'rb+') as inf:
        w = IncrementalPdfFileWriter(inf)
        from pyhanko.sign import fields

        fields.append_signature_field(
            w, sig_field_spec=fields.SigFieldSpec("Sig1", box=box)
        )
        w.write_in_place()

    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            *(('--field', 'Sig1') if field_name_passed else ()),
            '--style-name',
            'test',
            'pemder',
            '--no-pass',
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            '--key',
            _write_user_key(TESTING_CA),
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "the field 'Sig1' in the PDF is not a visible one" in result.output


def test_cli_pades_lta_no_timestamp_url(cli_runner):
    cfg = {
        'validation-contexts': {
            'test': {
                'trust': _write_cert(TESTING_CA, CertLabel('root'), "root.pem"),
            }
        },
    }

    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            '--validation-context',
            'test',
            '--with-validation-info',
            '--use-pades-lta',
            'pemder',
            '--key',
            _write_user_key(TESTING_CA),
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert result.exit_code == 1
    assert "--timestamp-url is required" in result.output


def test_fail_strict_hybrid(cli_runner):
    with open(INPUT_PATH, 'wb') as inf:
        inf.write(MINIMAL_HYBRID)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--key',
            _write_user_key(TESTING_CA),
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            INPUT_PATH,
            "out.pdf",
        ],
    )
    assert result.exit_code == 1
    assert "hybrid cross-ref" in result.output


def test_succeed_non_strict_hybrid(cli_runner):
    with open(INPUT_PATH, 'wb') as inf:
        inf.write(MINIMAL_HYBRID)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--no-strict-syntax',
            '--field',
            'Sig1',
            'pemder',
            '--no-pass',
            '--key',
            _write_user_key(TESTING_CA),
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            INPUT_PATH,
            "out.pdf",
        ],
    )
    assert result.exit_code == 0


def test_cli_with_signature_dictionary_entries(cli_runner):
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'addsig',
            '--field',
            'Sig1',
            '--reason',
            'I agree with this document',
            '--location',
            'THIS-COMPUTER',
            '--contact-info',
            'www.pyhanko.com/verify',
            'pemder',
            '--no-pass',
            '--cert',
            _write_cert(TESTING_CA, CertLabel('signer1'), "cert.pem"),
            '--key',
            _write_user_key(TESTING_CA),
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output
    with open(SIGNED_OUTPUT_PATH, 'rb') as outf:
        r = PdfFileReader(outf)
        last_sign = r.embedded_signatures[-1].sig_object

        assert last_sign['/ContactInfo'] == 'www.pyhanko.com/verify'
        assert last_sign['/Location'] == 'THIS-COMPUTER'


@pytest.mark.parametrize('pki_arch_name', LTV_CERTOMANCER_ARCHITECTURES)
def test_cli_timestamp(pki_arch_name, timestamp_url, cli_runner, root_cert):
    cfg = {
        'validation-contexts': {
            'test': {
                'trust': root_cert,
            }
        },
    }

    _write_config(cfg)
    result = cli_runner.invoke(
        cli_root,
        [
            'sign',
            'timestamp',
            '--validation-context',
            'test',
            '--timestamp-url',
            timestamp_url,
            INPUT_PATH,
            SIGNED_OUTPUT_PATH,
        ],
    )
    assert not result.exception, result.output
