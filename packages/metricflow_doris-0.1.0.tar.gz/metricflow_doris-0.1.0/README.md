# metricflow-doris

Apache Doris adapter for [MetricFlow](https://github.com/dbt-labs/metricflow).

## Installation

```bash
pip install metricflow-doris
```

## Features

- SQL rendering for Apache Doris dialect
- DATETIME type support (Doris uses DATETIME instead of TIMESTAMP)
- DATE_ADD/DATE_SUB with INTERVAL syntax
- PERCENTILE_APPROX for approximate continuous percentile
- ISO day-of-week conversion
- Case-sensitive table alias handling

## Usage

```python
from metricflow_doris import DorisSqlPlanRenderer

renderer = DorisSqlPlanRenderer()
```

## Requirements

- Python >=3.9, <3.13
- metricflow >= 0.209.0
- pydoris == 1.2.0
- dbt-doris == 1.0.0
- mysqlclient >= 2.1.0, < 3
