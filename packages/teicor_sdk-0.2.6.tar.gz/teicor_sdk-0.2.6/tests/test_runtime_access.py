from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import Mock


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) in sys.path:
    sys.path.remove(str(SRC_ROOT))
sys.path.insert(0, str(SRC_ROOT))

from teicor_sdk import (  # noqa: E402
    RuntimeAuthorityToken,
    TeicorClient,
)


class RuntimeAccessTestCase(unittest.TestCase):
    def _client(self) -> TeicorClient:
        return TeicorClient(
            base_url="http://example.test",
            team_slug="team-a",
            app_slug="app-a",
            service_token="token",
        )

    def test_get_context_includes_runtime_fallback(self) -> None:
        client = self._client()
        client._request = Mock(
            return_value={
                "team": {"id": 7, "slug": "team-a"},
                "app": {"slug": "app-a"},
                "runtime_access_mode": "direct",
                "runtime_proxy_base_url": "https://app.teicor.test/v1/teams/team-a/runtime/",
                "runtime_api_base_url": "https://team-a.runtime.teicor.test",
                "runtime_fallback": {
                    "recommended_mode": "proxy",
                    "retry_via_proxy_on_network_error": True,
                },
                "core_state_url": "https://app.teicor.test/v1/teams/team-a/core/state/",
            }
        )

        context = client.get_context()

        self.assertEqual(context.runtime_access_mode, "direct")
        self.assertEqual(
            context.runtime_proxy_base_url,
            "https://app.teicor.test/v1/teams/team-a/runtime/",
        )
        self.assertEqual(
            context.runtime_api_base_url,
            "https://team-a.runtime.teicor.test",
        )
        self.assertEqual(
            context.runtime_fallback,
            {
                "recommended_mode": "proxy",
                "retry_via_proxy_on_network_error": True,
            },
        )

    def test_get_runtime_authority_token_returns_typed_contract(self) -> None:
        client = self._client()
        client._request = Mock(
            return_value={
                "token_type": "Bearer",
                "runtime_authority_token": "eyJhbGci...",
                "scope": "write",
                "runtime_access_mode": "direct",
                "runtime_api_base_url": "https://team-a.runtime.teicor.test",
                "runtime_proxy_base_url": "https://app.teicor.test/v1/teams/team-a/runtime/",
                "runtime_fallback": {
                    "recommended_mode": "proxy",
                    "never_auto_fallback_status_codes": [401, 403],
                },
                "runtime_host_id": "team-a",
                "expires_at": "2026-02-22T01:00:00+00:00",
                "expires_in_seconds": "59",
                "runtime_authority_token_url": "https://app.teicor.test/v1/teams/team-a/runtime/authority-token/",
            }
        )

        token = client.get_runtime_authority_token(scope="write")

        self.assertIsInstance(token, RuntimeAuthorityToken)
        self.assertEqual(token.scope, "write")
        self.assertEqual(token.expires_in_seconds, 59)
        self.assertEqual(token.runtime_access_mode, "direct")
        self.assertEqual(
            token.runtime_fallback,
            {
                "recommended_mode": "proxy",
                "never_auto_fallback_status_codes": [401, 403],
            },
        )

        client._request.assert_called_once_with(
            "GET",
            "/v1/teams/team-a/runtime/authority-token/",
            query={"scope": "write"},
        )

    def test_get_runtime_authority_token_uses_safe_defaults(self) -> None:
        client = self._client()
        client._request = Mock(
            return_value={
                "runtime_authority_token": "eyJhbGci...",
                "expires_in_seconds": "invalid",
            }
        )

        token = client.get_runtime_authority_token()

        self.assertEqual(token.token_type, "Bearer")
        self.assertEqual(token.scope, "read")
        self.assertEqual(token.runtime_fallback, {})
        self.assertEqual(token.expires_in_seconds, 0)


if __name__ == "__main__":
    unittest.main()
