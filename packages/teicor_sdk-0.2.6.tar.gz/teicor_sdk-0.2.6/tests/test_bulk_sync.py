from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) in sys.path:
    sys.path.remove(str(SRC_ROOT))
sys.path.insert(0, str(SRC_ROOT))

from teicor_sdk import (  # noqa: E402
    BulkSyncCheckpoint,
    BulkSyncSummary,
    TeicorApiError,
    TeicorClient,
    TeicorSdkError,
)


class BulkSyncTestCase(unittest.TestCase):
    def _client(self) -> TeicorClient:
        return TeicorClient(
            base_url="http://example.test",
            team_slug="team-a",
            app_slug="app-a",
            service_token="token",
        )

    def test_sync_records_bulk_chunks_payload(self) -> None:
        client = self._client()
        records = [{"id": i} for i in range(1200)]

        client.create_records_bulk = Mock(return_value={"created": 500})

        summary = client.sync_records_bulk(
            table_id="tbl_1",
            records=records,
            chunk_size=500,
        )

        self.assertIsInstance(summary, BulkSyncSummary)
        self.assertEqual(summary.total_records, 1200)
        self.assertEqual(summary.total_chunks, 3)
        self.assertEqual(summary.records_processed, 1200)
        self.assertEqual(summary.retries_used, 0)
        self.assertEqual(client.create_records_bulk.call_count, 3)

    def test_sync_records_bulk_retries_transient_errors(self) -> None:
        client = self._client()
        records = [{"id": 1}, {"id": 2}]

        client.create_records_bulk = Mock(
            side_effect=[
                TeicorSdkError("network"),
                {"created": 2},
            ]
        )

        with patch("teicor_sdk.client.time.sleep"):
            summary = client.sync_records_bulk(
                table_id="tbl_1",
                records=records,
                chunk_size=2,
                max_retries=3,
            )

        self.assertEqual(summary.total_chunks, 1)
        self.assertEqual(summary.records_processed, 2)
        self.assertEqual(summary.retries_used, 1)
        self.assertEqual(summary.chunks[0].attempts, 2)

    def test_sync_records_bulk_fails_fast_on_non_retriable_4xx(self) -> None:
        client = self._client()
        records = [{"id": 1}]

        client.create_records_bulk = Mock(
            side_effect=TeicorApiError(
                status_code=400,
                detail="bad request",
            )
        )

        with self.assertRaises(TeicorSdkError):
            client.sync_records_bulk(
                table_id="tbl_1",
                records=records,
                chunk_size=1,
                max_retries=3,
            )

    def test_sync_records_bulk_validates_chunk_size(self) -> None:
        client = self._client()

        with self.assertRaises(ValueError):
            client.sync_records_bulk(
                table_id="tbl_1",
                records=[{"id": 1}],
                chunk_size=600,
                max_bulk_records=500,
            )

    def test_sync_records_bulk_emits_checkpoint_and_resume(self) -> None:
        client = self._client()
        records = [{"id": i} for i in range(10)]
        checkpoints: list[BulkSyncCheckpoint] = []

        client.create_records_bulk = Mock(return_value={"created": 2})

        summary = client.sync_records_bulk(
            table_id="tbl_1",
            records=records,
            chunk_size=2,
            on_checkpoint=checkpoints.append,
        )

        self.assertEqual(summary.total_chunks, 5)
        self.assertEqual(summary.records_processed, 10)
        self.assertEqual(len(checkpoints), 5)
        self.assertEqual(checkpoints[-1].next_chunk_index, 5)

        client.create_records_bulk.reset_mock()
        resumed = client.sync_records_bulk(
            table_id="tbl_1",
            records=records,
            chunk_size=2,
            start_chunk_index=3,
        )

        self.assertEqual(resumed.records_processed, 10)
        self.assertEqual(resumed.total_chunks, 5)
        self.assertEqual(client.create_records_bulk.call_count, 2)

    def test_parse_bulk_sync_checkpoint(self) -> None:
        client = self._client()

        self.assertEqual(client.parse_bulk_sync_checkpoint(None), 0)
        self.assertEqual(client.parse_bulk_sync_checkpoint({}), 0)
        self.assertEqual(
            client.parse_bulk_sync_checkpoint({"next_chunk_index": "4"}),
            4,
        )

    def test_core_state_checkpoint_helpers(self) -> None:
        client = self._client()

        client.get_core_state = Mock(
            return_value={
                "bulk_sync_checkpoint": {
                    "next_chunk_index": 3,
                    "records_processed": 1500,
                }
            }
        )
        loaded = client.get_bulk_sync_checkpoint()
        self.assertEqual(loaded.get("next_chunk_index"), 3)

        client.patch_core_state = Mock(return_value={})
        client.save_bulk_sync_checkpoint(
            checkpoint=BulkSyncCheckpoint(
                next_chunk_index=4,
                records_processed=2000,
                total_records=70000,
                chunk_size=500,
                total_chunks=140,
            )
        )
        client.patch_core_state.assert_called_with(
            {
                "bulk_sync_checkpoint": {
                    "next_chunk_index": 4,
                    "records_processed": 2000,
                    "total_records": 70000,
                    "chunk_size": 500,
                    "total_chunks": 140,
                }
            }
        )

        client.clear_bulk_sync_checkpoint()
        client.patch_core_state.assert_called_with(
            {"bulk_sync_checkpoint": None}
        )

    def test_sync_records_bulk_with_core_checkpoint(self) -> None:
        client = self._client()
        records = [{"id": i} for i in range(4)]

        client.get_bulk_sync_checkpoint = Mock(
            return_value={"next_chunk_index": 1}
        )
        client.save_bulk_sync_checkpoint = Mock()
        client.clear_bulk_sync_checkpoint = Mock()

        def _fake_sync_records_bulk(**kwargs):
            on_checkpoint = kwargs.get("on_checkpoint")
            if on_checkpoint is not None:
                on_checkpoint(
                    BulkSyncCheckpoint(
                        next_chunk_index=2,
                        records_processed=4,
                        total_records=4,
                        chunk_size=2,
                        total_chunks=2,
                    )
                )
            return BulkSyncSummary(
                total_records=4,
                chunk_size=2,
                total_chunks=2,
                records_processed=4,
                retries_used=0,
                chunks=[],
            )

        client.sync_records_bulk = Mock(side_effect=_fake_sync_records_bulk)

        summary = client.sync_records_bulk_with_core_checkpoint(
            table_id="tbl_1",
            records=records,
            chunk_size=2,
        )

        self.assertEqual(summary.records_processed, 4)
        client.get_bulk_sync_checkpoint.assert_called_once()
        client.save_bulk_sync_checkpoint.assert_called_once()
        client.clear_bulk_sync_checkpoint.assert_called_once()


if __name__ == "__main__":
    unittest.main()
