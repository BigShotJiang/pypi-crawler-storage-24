"""Job control repository for BigQuery operations."""

import logging
from datetime import datetime, date
from typing import Optional, List

from google.cloud import bigquery

from .types import JobStatus, FailureStage
from .models import PipelineJob

logger = logging.getLogger(__name__)


class JobControlRepository:
    """
    Repository for pipeline job control operations.

    Manages CRUD operations for job_control.pipeline_jobs table.

    Example:
        >>> repo = JobControlRepository(project_id="my-project")
        >>> job = PipelineJob(
        ...     run_id="application1_customer_20260101_001",
        ...     system_id="Application1",
        ...     entity_type="Customer",
        ...     extract_date=date(2026, 1, 1),
        ...     source_files=["gs://bucket/file.csv"]
        ... )
        >>> repo.create_job(job)
        >>> repo.update_status(job.run_id, JobStatus.RUNNING)
        >>> repo.update_status(job.run_id, JobStatus.SUCCESS, total_records=5000)
    """

    def __init__(
        self,
        project_id: str,
        dataset: str = "job_control",
        table: str = "pipeline_jobs"
    ):
        """
        Initialize job control repository.

        Args:
            project_id: GCP project ID
            dataset: BigQuery dataset name
            table: BigQuery table name
        """
        self.project_id = project_id
        self.dataset = dataset
        self.table = table
        self.full_table_id = f"{project_id}.{dataset}.{table}"
        self.client = bigquery.Client(project=project_id)

    def create_job(self, job: PipelineJob) -> None:
        """
        Insert new job record.

        Args:
            job: PipelineJob instance to create
        """
        query = f"""
            INSERT INTO `{self.full_table_id}` (
                run_id, system_id, entity_type, extract_date,
                status, started_at, source_files,
                job_type, retry_count, max_retries,
                parent_run_ids, dbt_model_name,
                created_at, updated_at
            ) VALUES (
                @run_id, @system_id, @entity_type, @extract_date,
                @status, @started_at, @source_files,
                @job_type, @retry_count, @max_retries,
                @parent_run_ids, @dbt_model_name,
                CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
            )
        """

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("run_id", "STRING", job.run_id),
                bigquery.ScalarQueryParameter("system_id", "STRING", job.system_id),
                bigquery.ScalarQueryParameter("entity_type", "STRING", job.entity_type),
                bigquery.ScalarQueryParameter("extract_date", "DATE", job.extract_date),
                bigquery.ScalarQueryParameter("status", "STRING", job.status.value),
                bigquery.ScalarQueryParameter("started_at", "TIMESTAMP", job.started_at),
                bigquery.ArrayQueryParameter("source_files", "STRING", job.source_files),
                bigquery.ScalarQueryParameter("job_type", "STRING", job.job_type),
                bigquery.ScalarQueryParameter("retry_count", "INT64", job.retry_count),
                bigquery.ScalarQueryParameter("max_retries", "INT64", job.max_retries),
                bigquery.ArrayQueryParameter("parent_run_ids", "STRING", job.parent_run_ids),
                bigquery.ScalarQueryParameter("dbt_model_name", "STRING", job.dbt_model_name),
            ]
        )

        self.client.query(query, job_config=job_config).result()
        logger.info(f"Created job: {job.run_id}")

    def update_status(
        self,
        run_id: str,
        status: JobStatus,
        total_records: Optional[int] = None
    ) -> None:
        """
        Update job status.

        Args:
            run_id: Job run ID
            status: New status
            total_records: Total records processed (for SUCCESS status)
        """
        if status == JobStatus.SUCCESS:
            query = f"""
                UPDATE `{self.full_table_id}`
                SET status = @status,
                    completed_at = CURRENT_TIMESTAMP(),
                    total_records = @total_records,
                    updated_at = CURRENT_TIMESTAMP()
                WHERE run_id = @run_id
            """
        elif status == JobStatus.RUNNING:
            query = f"""
                UPDATE `{self.full_table_id}`
                SET status = @status,
                    started_at = CURRENT_TIMESTAMP(),
                    updated_at = CURRENT_TIMESTAMP()
                WHERE run_id = @run_id
            """
        else:
            query = f"""
                UPDATE `{self.full_table_id}`
                SET status = @status,
                    updated_at = CURRENT_TIMESTAMP()
                WHERE run_id = @run_id
            """

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("run_id", "STRING", run_id),
                bigquery.ScalarQueryParameter("status", "STRING", status.value),
                bigquery.ScalarQueryParameter("total_records", "INT64", total_records),
            ]
        )

        self.client.query(query, job_config=job_config).result()
        logger.info(f"Updated job {run_id} to {status.value}")

    def mark_failed(
        self,
        run_id: str,
        error_code: str,
        error_message: str,
        failure_stage: FailureStage,
        error_file_path: Optional[str] = None
    ) -> None:
        """
        Mark job as failed with error details.

        Args:
            run_id: Job run ID
            error_code: Error code
            error_message: Detailed error message
            failure_stage: Stage where failure occurred
            error_file_path: Path to error file if applicable
        """
        query = f"""
            UPDATE `{self.full_table_id}`
            SET status = 'FAILED',
                error_code = @error_code,
                error_message = @error_message,
                failure_stage = @failure_stage,
                error_file_path = @error_file_path,
                failed_at = CURRENT_TIMESTAMP(),
                updated_at = CURRENT_TIMESTAMP()
            WHERE run_id = @run_id
        """

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("run_id", "STRING", run_id),
                bigquery.ScalarQueryParameter("error_code", "STRING", error_code),
                bigquery.ScalarQueryParameter("error_message", "STRING", error_message),
                bigquery.ScalarQueryParameter("failure_stage", "STRING", failure_stage.value),
                bigquery.ScalarQueryParameter("error_file_path", "STRING", error_file_path),
            ]
        )

        self.client.query(query, job_config=job_config).result()
        logger.info(f"Marked job {run_id} as FAILED: {error_code}")

    def get_job(self, run_id: str) -> Optional[PipelineJob]:
        """
        Get job by run_id.

        Args:
            run_id: Job run ID

        Returns:
            PipelineJob if found, None otherwise
        """
        query = f"""
            SELECT * FROM `{self.full_table_id}`
            WHERE run_id = @run_id
        """

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("run_id", "STRING", run_id),
            ]
        )

        results = list(self.client.query(query, job_config=job_config).result())

        if not results:
            return None

        row = results[0]
        return PipelineJob(
            run_id=row.run_id,
            system_id=row.system_id,
            entity_type=row.entity_type,
            extract_date=row.extract_date,
            status=JobStatus(row.status),
            started_at=row.started_at,
            completed_at=row.completed_at,
            total_records=row.total_records,
            error_code=row.error_code,
            error_message=row.error_message,
        )

    def get_entity_status(
        self,
        system_id: str,
        extract_date: date
    ) -> List[dict]:
        """
        Get status of all entities for a system/date.

        Args:
            system_id: Source system ID
            extract_date: Extract date

        Returns:
            List of dicts with entity_type, status, and run_id
        """
        query = f"""
            SELECT entity_type, status, run_id
            FROM `{self.full_table_id}`
            WHERE system_id = @system_id
              AND extract_date = @extract_date
        """

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("system_id", "STRING", system_id),
                bigquery.ScalarQueryParameter("extract_date", "DATE", extract_date),
            ]
        )

        results = self.client.query(query, job_config=job_config).result()

        return [
            {"entity_type": row.entity_type, "status": row.status, "run_id": row.run_id}
            for row in results
        ]

    def get_pending_jobs(self, system_id: Optional[str] = None) -> List[PipelineJob]:
        """
        Get all pending jobs, optionally filtered by system.

        Args:
            system_id: Optional system ID filter

        Returns:
            List of pending PipelineJob instances
        """
        if system_id:
            query = f"""
                SELECT * FROM `{self.full_table_id}`
                WHERE status = 'PENDING'
                  AND system_id = @system_id
                ORDER BY created_at
            """
            job_config = bigquery.QueryJobConfig(
                query_parameters=[
                    bigquery.ScalarQueryParameter("system_id", "STRING", system_id),
                ]
            )
        else:
            query = f"""
                SELECT * FROM `{self.full_table_id}`
                WHERE status = 'PENDING'
                ORDER BY created_at
            """
            job_config = None

        results = self.client.query(query, job_config=job_config).result()

        jobs = []
        for row in results:
            jobs.append(PipelineJob(
                run_id=row.run_id,
                system_id=row.system_id,
                entity_type=row.entity_type,
                extract_date=row.extract_date,
                status=JobStatus(row.status),
                started_at=row.started_at,
                source_files=list(row.source_files) if row.source_files else [],
            ))

        return jobs

    def mark_retrying(self, run_id: str, retry_count: int) -> None:
        """
        Transition job to RETRYING status with retry count.

        Args:
            run_id: Job run ID
            retry_count: Current retry attempt number
        """
        query = f"""
            UPDATE `{self.full_table_id}`
            SET status = 'RETRYING',
                retry_count = @retry_count,
                updated_at = CURRENT_TIMESTAMP()
            WHERE run_id = @run_id
        """

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("run_id", "STRING", run_id),
                bigquery.ScalarQueryParameter("retry_count", "INT64", retry_count),
            ]
        )

        self.client.query(query, job_config=job_config).result()
        logger.info(f"Marked job {run_id} as RETRYING (attempt {retry_count})")

    def cleanup_partial_load(self, run_id: str, table_id: str) -> int:
        """
        Delete rows from a failed partial ODP load.

        Uses the _run_id column stamped on every row by the Beam pipeline
        to identify and remove rows belonging to a specific failed run.

        Args:
            run_id: Job run ID whose partial rows should be deleted
            table_id: Fully-qualified BigQuery table (project.dataset.table)

        Returns:
            Number of rows deleted
        """
        query = f"""
            DELETE FROM `{table_id}`
            WHERE _run_id = @run_id
        """

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("run_id", "STRING", run_id),
            ]
        )

        result = self.client.query(query, job_config=job_config).result()
        deleted = result.num_dml_affected_rows or 0
        logger.info(f"Cleaned up {deleted} partial rows from {table_id} for run {run_id}")
        return deleted

    def get_failed_jobs(
        self,
        system_id: str,
        extract_date: date
    ) -> List[dict]:
        """
        Get all FAILED jobs for a system/date.

        Used for retry cleanup decisions — find previous failed attempts
        before starting a new run.

        Args:
            system_id: Source system ID
            extract_date: Extract date

        Returns:
            List of dicts with run_id, entity_type, status, retry_count
        """
        query = f"""
            SELECT run_id, entity_type, status, retry_count
            FROM `{self.full_table_id}`
            WHERE system_id = @system_id
              AND extract_date = @extract_date
              AND status = 'FAILED'
        """

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("system_id", "STRING", system_id),
                bigquery.ScalarQueryParameter("extract_date", "DATE", extract_date),
            ]
        )

        results = self.client.query(query, job_config=job_config).result()

        return [
            {
                "run_id": row.run_id,
                "entity_type": row.entity_type,
                "status": row.status,
                "retry_count": row.retry_count or 0,
            }
            for row in results
        ]

    def get_fdp_job_status(
        self,
        system_id: str,
        extract_date: date,
        model_name: str
    ) -> Optional[dict]:
        """
        Get FDP job status for a specific model/date.

        Used to check if an FDP model has already been successfully built,
        preventing duplicate transformation runs.

        Args:
            system_id: Source system ID
            extract_date: Extract date
            model_name: dbt model name

        Returns:
            Dict with run_id, status, dbt_model_name, or None if not found
        """
        query = f"""
            SELECT run_id, status, dbt_model_name
            FROM `{self.full_table_id}`
            WHERE system_id = @system_id
              AND extract_date = @extract_date
              AND job_type = 'FDP_TRANSFORMATION'
              AND dbt_model_name = @model_name
            ORDER BY created_at DESC
            LIMIT 1
        """

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("system_id", "STRING", system_id),
                bigquery.ScalarQueryParameter("extract_date", "DATE", extract_date),
                bigquery.ScalarQueryParameter("model_name", "STRING", model_name),
            ]
        )

        results = list(self.client.query(query, job_config=job_config).result())

        if not results:
            return None

        row = results[0]
        return {
            "run_id": row.run_id,
            "status": row.status,
            "dbt_model_name": row.dbt_model_name,
        }


__all__ = [
    'JobControlRepository',
]

