"""aiowata — Async Python SDK for the WATA payment system.

::

    from aiowata import WataClient, Currency

    async with WataClient(token="your-access-token") as client:
        link = await client.create_link(amount=500, currency=Currency.RUB)
        print(link.url)
"""

from __future__ import annotations

from .client import PRODUCTION_URL, SANDBOX_URL, WataClient
from .enums import (
    Currency,
    LinkStatus,
    LinkType,
    TransactionKind,
    TransactionStatus,
    TransactionType,
)
from .exceptions import (
    ValidationItem,
    WataAPIError,
    WataAuthError,
    WataError,
    WataForbiddenError,
    WataRateLimitError,
    WataServerError,
    WataValidationError,
)
from .models import (
    PaymentLink,
    PaymentLinkList,
    RefundResult,
    Transaction,
    TransactionList,
    WebhookPayload,
)
from .webhook import parse_webhook, verify_webhook_signature

__all__ = [
    # client
    "WataClient",
    "PRODUCTION_URL",
    "SANDBOX_URL",
    # enums
    "Currency",
    "LinkStatus",
    "LinkType",
    "TransactionKind",
    "TransactionStatus",
    "TransactionType",
    # exceptions
    "ValidationItem",
    "WataAPIError",
    "WataAuthError",
    "WataError",
    "WataForbiddenError",
    "WataRateLimitError",
    "WataServerError",
    "WataValidationError",
    # models
    "PaymentLink",
    "PaymentLinkList",
    "RefundResult",
    "Transaction",
    "TransactionList",
    "WebhookPayload",
    # webhook
    "parse_webhook",
    "verify_webhook_signature",
]

__version__ = "0.1.0"
