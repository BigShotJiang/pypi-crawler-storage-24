from __future__ import annotations

from enum import Enum


class _ExtensibleEnum(str, Enum):
    """Enum base that gracefully handles unknown values returned by the API.

    If WATA introduces a new status or type that this SDK version does not
    yet define, the value is wrapped transparently instead of raising
    ``ValueError``.
    """

    @classmethod
    def _missing_(cls, value: object) -> Enum | None:
        if not isinstance(value, str):
            return None
        member = str.__new__(cls, value)
        member._name_ = value
        member._value_ = value
        return member


class LinkType(_ExtensibleEnum):
    """Payment link type."""

    ONE_TIME = "OneTime"
    """Single-use link — becomes invalid after the first successful payment."""

    MANY_TIME = "ManyTime"
    """Multi-use link — remains valid until its expiration time."""


class LinkStatus(_ExtensibleEnum):
    """Payment link status."""

    OPENED = "Opened"
    """Link is active and can accept payments."""

    CLOSED = "Closed"
    """Link is no longer active."""


class TransactionStatus(_ExtensibleEnum):
    """Transaction processing status."""

    CREATED = "Created"
    """Transaction created, waiting for the backend to acknowledge the webhook."""

    PENDING = "Pending"
    """Payment is being processed by the bank."""

    PAID = "Paid"
    """Payment completed successfully."""

    DECLINED = "Declined"
    """Payment was declined."""


class TransactionType(_ExtensibleEnum):
    """Payment method type used in the transaction."""

    CARD_CRYPTO = "CardCrypto"
    """Domestic or international bank card."""

    SBP = "SBP"
    """Russian Faster Payments System (SBP)."""

    TPAY = "TPay"
    """T-Bank payment method."""

    SBER_PAY = "SberPay"
    """Sberbank payment method."""


class TransactionKind(_ExtensibleEnum):
    """Distinguishes payments from refunds."""

    PAYMENT = "Payment"
    REFUND = "Refund"


class Currency(_ExtensibleEnum):
    """Supported payment currencies."""

    RUB = "RUB"
    EUR = "EUR"
    USD = "USD"
