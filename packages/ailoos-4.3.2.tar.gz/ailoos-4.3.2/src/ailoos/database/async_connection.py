"""
Async Database Connection
=========================

Provides asynchronous SQLAlchemy engine and session management.
Required for high-throughput non-blocking DB operations.
"""

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from contextlib import asynccontextmanager
from typing import AsyncGenerator
import asyncio
import os

from ..core.logging import get_logger
from ..core.config import get_config
from .models import Base

logger = get_logger(__name__)
config = get_config()

# Global variables for lazy initialization
_async_engine = None
_AsyncSessionLocal = None

def _get_engine():
    """Lazy engine creation with error handling for greenlet/missing drivers."""
    global _async_engine, _AsyncSessionLocal
    
    if _async_engine is not None:
        return _async_engine, _AsyncSessionLocal
        
    # Robust DB URL logic with SQLite Fallback
    db_url = config.database.connection_string

    if db_url.startswith("postgresql://"):
        db_url = db_url.replace("postgresql://", "postgresql+asyncpg://")
    elif db_url.startswith("sqlite://"):
        if "sqlite+aiosqlite" not in db_url:
            db_url = db_url.replace("sqlite://", "sqlite+aiosqlite://")
    else:
        db_url = "sqlite+aiosqlite:///./data/ailoos_local.db"

    try:
        # Create Async Engine
        _async_engine = create_async_engine(
            db_url,
            echo=config.debug_mode,
            pool_size=config.database.connection_pool_size if "sqlite" not in db_url else None,
            max_overflow=10 if "sqlite" not in db_url else None,
            pool_pre_ping=True if "sqlite" not in db_url else False
        )
        
        # Create Async Session Factory
        _AsyncSessionLocal = sessionmaker(
            bind=_async_engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False
        )
        
        return _async_engine, _AsyncSessionLocal
        
    except Exception as e:
        logger.warning(f"⚠️ Could not initialize async database ({db_url}): {e}")
        # Return None to allow caller to handle the failure
        return None, None

@asynccontextmanager
async def get_async_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency for getting async DB session with fallback handling.
    """
    try:
        engine, session_factory = _get_engine()
        
        if session_factory is None:
            logger.warning("Async Database session factory not available. Skipping DB operation.")
            yield None
            return
            
        async with session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception as e:
                await session.rollback()
                logger.error(f"DB Transaction error: {e}")
                raise
    except Exception as e:
        logger.warning(f"⚠️ Async Database operation failed gracefully: {e}")
        yield None
