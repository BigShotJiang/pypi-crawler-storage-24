"""
Standalone DataHub API Server for testing upload functionality.
This is a simplified version that doesn't require blockchain dependencies.
"""

import asyncio
import json
import math
import time
import uuid
import hashlib
from typing import Dict, List, Any, Optional
from datetime import datetime
from pathlib import Path
import tempfile

from fastapi import FastAPI, HTTPException, Depends, Query, BackgroundTasks, UploadFile, File, Form
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

# Mock storage for testing (in production, use database)
test_datasets = []

# Modelos Pydantic
class DatasetUploadRequest(BaseModel):
    name: str
    description: Optional[str] = None
    category: str
    tags: List[str] = []
    license: Optional[str] = None

class DatasetUploadResponse(BaseModel):
    success: bool
    dataset_id: str
    ipfs_cid: Optional[str] = None
    name: str
    size_bytes: int
    category: str
    tags: List[str]
    uploaded_at: str
    message: Optional[str] = None

# Create FastAPI app
app = FastAPI(
    title="AILOOS Data Hub API (Standalone)",
    description="Standalone API for Data Hub testing",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "mode": "standalone",
        "total_datasets": len(test_datasets)
    }

@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "message": "AILOOS Data Hub API",
        "version": "1.0.0",
        "docs": "/docs"
    }

@app.get("/api/datahub/datasets", response_model=List[Dict[str, Any]])
async def get_datasets_datahub(
    status: str = Query("", description="Filter by status"),
    source: str = Query("", description="Filter by source"),
    limit: int = Query(50, ge=1, le=200)
):
    """Get list of datasets (DataHub path)."""
    return test_datasets[:limit]

@app.get("/datasets", response_model=List[Dict[str, Any]])
async def get_datasets(
    status: str = Query("", description="Filter by status"),
    source: str = Query("", description="Filter by source"),
    limit: int = Query(50, ge=1, le=200)
):
    """Get list of datasets."""
    return test_datasets[:limit]

@app.post("/api/datahub/datasets/upload", response_model=DatasetUploadResponse)
async def upload_dataset_datahub(
    file: UploadFile = File(..., description="Dataset file"),
    name: str = Form(..., description="Dataset name"),
    description: Optional[str] = Form(None, description="Description"),
    category: str = Form(..., description="Category"),
    tags: str = Form("[]", description="Tags as JSON array"),
    license: Optional[str] = Form(None, description="License"),
):
    """Upload a new dataset (DataHub path)."""
    return await upload_dataset_internal(file, name, description, category, tags, license)

@app.post("/datasets/upload", response_model=DatasetUploadResponse)
async def upload_dataset(
    file: UploadFile = File(..., description="Dataset file"),
    name: str = Form(..., description="Dataset name"),
    description: Optional[str] = Form(None, description="Description"),
    category: str = Form(..., description="Category"),
    tags: str = Form("[]", description="Tags as JSON array"),
    license: Optional[str] = Form(None, description="License"),
):
    """Upload a new dataset."""
    return await upload_dataset_internal(file, name, description, category, tags, license)

async def upload_dataset_internal(
    file: UploadFile,
    name: str,
    description: Optional[str],
    category: str,
    tags: str,
    license: Optional[str]
):
    """Internal function to handle dataset upload."""
    try:
        # Parse tags
        try:
            tags_list = json.loads(tags) if tags else []
        except:
            tags_list = []

        # Generate dataset ID
        dataset_id = f"dataset_{uuid.uuid4().hex[:16]}"

        # Read file content
        file_content = await file.read()
        file_size = len(file_content)

        # Calculate hash
        file_hash = hashlib.sha256(file_content).hexdigest()

        # Generate mock IPFS CID (in production, use real IPFS)
        ipfs_cid = f"Qm{hashlib.sha256(file_content).hexdigest()[:44]}"

        # Create dataset record
        dataset = {
            "dataset_id": dataset_id,
            "name": name,
            "description": description,
            "category": category,
            "tags": tags_list,
            "license": license,
            "size_bytes": file_size,
            "ipfs_cid": ipfs_cid,
            "content_hash": file_hash,
            "original_filename": file.filename,
            "uploaded_at": datetime.utcnow().isoformat(),
            "status": "completed"
        }

        test_datasets.append(dataset)

        return DatasetUploadResponse(
            success=True,
            dataset_id=dataset_id,
            ipfs_cid=ipfs_cid,
            name=name,
            size_bytes=file_size,
            category=category,
            tags=tags_list,
            uploaded_at=datetime.utcnow().isoformat(),
            message="Dataset uploaded successfully (mock mode)"
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading dataset: {str(e)}")

@app.get("/api/datahub/datasets/{dataset_id}")
async def get_dataset_details_datahub(dataset_id: str):
    """Get dataset details (DataHub path)."""
    return await get_dataset_details_internal(dataset_id)

@app.get("/datasets/{dataset_id}")
async def get_dataset_details(dataset_id: str):
    """Get dataset details."""
    return await get_dataset_details_internal(dataset_id)

async def get_dataset_details_internal(dataset_id: str):
    """Internal function to get dataset details."""
    for dataset in test_datasets:
        if dataset["dataset_id"] == dataset_id:
            return dataset
    raise HTTPException(status_code=404, detail="Dataset not found")

@app.get("/api/datahub/datasets/category/{category}")
async def get_datasets_by_category_datahub(category: str, limit: int = 50):
    """Get datasets by category (DataHub path)."""
    return [d for d in test_datasets if d.get("category", "").lower() == category.lower()][:limit]

@app.get("/datasets/category/{category}")
async def get_datasets_by_category(category: str, limit: int = 50):
    """Get datasets by category."""
    return [d for d in test_datasets if d.get("category", "").lower() == category.lower()][:limit]

@app.get("/api/datahub/datasets/{dataset_id}/download")
async def get_dataset_download_datahub(dataset_id: str):
    """Get dataset download info (DataHub path)."""
    return await get_dataset_download_internal(dataset_id)

@app.get("/datasets/{dataset_id}/download")
async def get_dataset_download(dataset_id: str):
    """Get dataset download info."""
    return await get_dataset_download_internal(dataset_id)

async def get_dataset_download_internal(dataset_id: str):
    """Internal function to get dataset download info."""
    for dataset in test_datasets:
        if dataset["dataset_id"] == dataset_id:
            return {
                "dataset_id": dataset_id,
                "ipfs_cid": dataset.get("ipfs_cid"),
                "download_url": f"https://ipfs.io/ipfs/{dataset.get('ipfs_cid')}",
                "filename": dataset.get("original_filename", f"{dataset_id}.dat"),
                "size_bytes": dataset.get("size_bytes"),
                "expires_at": datetime.utcnow().isoformat()
            }
    raise HTTPException(status_code=404, detail="Dataset not found")

@app.delete("/api/datahub/datasets/{dataset_id}")
async def delete_dataset_datahub(dataset_id: str):
    """Delete a dataset (DataHub path)."""
    return await delete_dataset_internal(dataset_id)

@app.delete("/datasets/{dataset_id}")
async def delete_dataset(dataset_id: str):
    """Delete a dataset."""
    return await delete_dataset_internal(dataset_id)

async def delete_dataset_internal(dataset_id: str):
    """Internal function to delete a dataset."""
    global test_datasets
    for i, dataset in enumerate(test_datasets):
        if dataset["dataset_id"] == dataset_id:
            test_datasets.pop(i)
            return {"success": True, "message": "Dataset deleted", "dataset_id": dataset_id}
    raise HTTPException(status_code=404, detail="Dataset not found")

@app.get("/api/datahub/datasets/user/{user_id}")
async def get_user_datasets_datahub(user_id: str, limit: int = 50):
    """Get datasets by user (DataHub path)."""
    return test_datasets[:limit]

@app.get("/datasets/user/{user_id}")
async def get_user_datasets(user_id: str, limit: int = 50):
    """Get datasets by user."""
    return test_datasets[:limit]

def start_server(host: str = "0.0.0.0", port: int = 8000):
    """Start the server."""
    print(f"🚀 Starting AILOOS Data Hub Standalone API on {host}:{port}")
    uvicorn.run(app, host=host, port=port)

if __name__ == "__main__":
    start_server()
