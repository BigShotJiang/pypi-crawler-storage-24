"""
Blockchain infrastructure para AILOOS.
"""

from importlib import import_module

__all__ = [
    "Blockchain",
    "Block",
    "Transaction",
    "Wallet",
    "get_blockchain",
    "create_transaction",
    "send_transaction",
    "generate_keypair",
    "address_from_public_key",
    "dracmaManager",
    "get_token_manager",
    "initialize_dracma_infrastructure",
    "TokenConfig",
    "TokenStandard",
    "NetworkType",
    "TransactionResult",
]


def __getattr__(name):
    if name in {
        "Blockchain",
        "Block",
        "Transaction",
        "Wallet",
        "get_blockchain",
        "create_transaction",
        "send_transaction",
        "generate_keypair",
        "address_from_public_key",
    }:
        module = import_module(".core", __name__)
        return getattr(module, name)
    if name in {
        "dracmaManager",
        "get_token_manager",
        "initialize_dracma_infrastructure",
        "TokenConfig",
        "TokenStandard",
        "NetworkType",
        "TransactionResult",
    }:
        module = import_module(".dracma_token", __name__)
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
