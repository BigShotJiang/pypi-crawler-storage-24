"""
Configuración específica para integración Dracma en Ailoos.

Contiene direcciones de contratos, endpoints RPC, configuración del puente
y parámetros de red para EmporioChain.
"""

import os
from dotenv import load_dotenv
load_dotenv()
from typing import Dict, Any, Optional
from dataclasses import dataclass
from urllib.parse import urlparse

# Logging: fallback a stdlib si faltan deps del core (pyyaml, etc.)
try:
    from ..core.logging import get_logger  # type: ignore
    logger = get_logger(__name__)
except Exception:  # pragma: no cover
    import logging
    logger = logging.getLogger(__name__)


@dataclass
class DracmaContractAddresses:
    """Direcciones de contratos principales en EmporioChain."""
    token_contract: str = "emp1qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq"
    ailoos_contract: str = "emp1ppppppppppppppppppppppppppppppppppppp"
    pool_address: str = "emp1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"

    def validate_addresses(self, allow_mock: bool = False) -> bool:
        """Valida que las direcciones tengan formato correcto de CosmWasm."""
        for field_name, address in self.__dict__.items():
            if not address:
                logger.error(f"Dirección vacía para {field_name}")
                return False
            if not address.startswith('emp'):
                logger.error(f"Dirección inválida para {field_name}: {address}")
                return False
            if len(address) < 40:  # Longitud típica de direcciones SS58/emp
                logger.warning(f"Dirección {field_name} tiene longitud inusual: {len(address)}")
            if not allow_mock and any(marker in address for marker in ("dracmacontract", "ailooscontract", "ailoospool")):
                logger.error(
                    f"Dirección mock detectada para {field_name}. "
                    "Define direcciones reales vía variables de entorno."
                )
                return False
            # Default placeholders (emp1qqq/emp1ppp/emp1aaa) must not leak into testnet/mainnet.
            if not allow_mock and any(pat in address for pat in ("emp1qqqq", "emp1pppp", "emp1aaaa")):
                logger.error(
                    f"Dirección placeholder detectada para {field_name}. "
                    "Define direcciones reales vía variables de entorno."
                )
                return False
        return True


@dataclass
class EmporioChainConfig:
    """Configuración de red para EmporioChain."""
    rpc_url: str = "https://rpc.empooriochain.org:443"
    chain_id: str = "emporiochain-1"
    gas_price: str = "0.025uemp"
    gas_limit: int = 200000
    timeout: int = 30

    def validate_rpc_url(self) -> bool:
        """Valida que la URL RPC sea válida."""
        try:
            parsed = urlparse(self.rpc_url)
            if parsed.scheme not in ['http', 'https']:
                logger.error(f"Esquema inválido en RPC URL: {self.rpc_url}")
                return False
            if not parsed.netloc:
                logger.error(f"URL RPC inválida: {self.rpc_url}")
                return False
            return True
        except Exception as e:
            logger.error(f"Error validando RPC URL: {e}")
            return False


@dataclass
class BridgeConfig:
    """Configuración del puente cross-chain."""
    bridge_url: str = "http://localhost:3000"
    api_key: Optional[str] = None
    timeout: int = 30
    retry_attempts: int = 3
    backoff_factor: float = 1.0

    def validate_bridge_url(self) -> bool:
        """Valida que la URL del puente sea válida."""
        try:
            parsed = urlparse(self.bridge_url)
            if parsed.scheme not in ['http', 'https']:
                logger.error(f"Esquema inválido en bridge URL: {self.bridge_url}")
                return False
            if not parsed.netloc:
                logger.error(f"URL del puente inválida: {self.bridge_url}")
                return False
            return True
        except Exception as e:
            logger.error(f"Error validando bridge URL: {e}")
            return False


@dataclass
class DracmaConfig:
    """Configuración completa para Dracma."""
    contracts: DracmaContractAddresses
    network: EmporioChainConfig
    bridge: BridgeConfig

    def __post_init__(self):
        """Validar configuración después de inicialización."""
        bridge_only = os.getenv("AILOOS_REWARDS_BRIDGE_ONLY", "0").lower() in {"1", "true", "yes"}
        allow_mock = os.getenv("DRACMA_ALLOW_MOCK_ADDRESSES", "0").lower() in {"1", "true", "yes"}
        # In bridge-only mode, rewards flow via DRACMA bridge and on-chain contracts are not used directly.
        if not bridge_only and not self.contracts.validate_addresses(allow_mock=allow_mock):
            raise ValueError("Direcciones de contratos inválidas")
        if not self.network.validate_rpc_url():
            raise ValueError("URL RPC inválida")
        if not self.bridge.validate_bridge_url():
            raise ValueError("URL del puente inválida")

    @classmethod
    def from_env(cls) -> 'DracmaConfig':
        """Crea configuración desde variables de entorno."""
        is_production = (os.getenv("AILOOS_ENV") or os.getenv("DRACMA_ENV") or "").lower() in {
            "prod",
            "production",
        }
        bridge_only = os.getenv("AILOOS_REWARDS_BRIDGE_ONLY", "0").lower() in {"1", "true", "yes"}
        defaults = DracmaContractAddresses()
        token_contract_env = os.getenv('DRACMA_TOKEN_CONTRACT') or os.getenv('dracma_TOKEN_CONTRACT')
        ailoos_contract_env = os.getenv('DRACMA_AILOOS_CONTRACT') or os.getenv('dracma_AILOOS_CONTRACT')
        pool_address_env = os.getenv('DRACMA_POOL_ADDRESS') or os.getenv('dracma_POOL_ADDRESS')
        token_contract = token_contract_env or defaults.token_contract
        ailoos_contract = ailoos_contract_env or defaults.ailoos_contract
        pool_address = pool_address_env or defaults.pool_address

        if is_production and not bridge_only:
            missing = [
                name for name, value in (
                    ("DRACMA_TOKEN_CONTRACT", token_contract_env),
                    ("DRACMA_AILOOS_CONTRACT", ailoos_contract_env),
                    ("DRACMA_POOL_ADDRESS", pool_address_env),
                )
                if not value
            ]
            if missing:
                raise ValueError(
                    f"Configuración Dracma incompleta en producción. Faltan: {', '.join(missing)}"
                )

        contracts = DracmaContractAddresses(
            token_contract=token_contract,
            ailoos_contract=ailoos_contract,
            pool_address=pool_address,
        )

        network = EmporioChainConfig(
            rpc_url=os.getenv('EMPORIO_RPC_URL', 'https://rpc.empooriochain.org:443')
        )

        bridge = BridgeConfig(
            bridge_url=os.getenv('DRACMA_BRIDGE_URL') or os.getenv('dracma_BRIDGE_URL', 'http://localhost:3000'),
            api_key=os.getenv('DRACMA_BRIDGE_API_KEY') or os.getenv('dracma_BRIDGE_API_KEY')
        )

        if is_production:
            # In prod/testnet, we want an explicit bridge URL (no silent localhost defaults).
            if not (os.getenv('DRACMA_BRIDGE_URL') or os.getenv('dracma_BRIDGE_URL')):
                raise ValueError("DRACMA_BRIDGE_URL is required in production/testnet environments")

        return cls(contracts=contracts, network=network, bridge=bridge)

    def to_dict(self) -> Dict[str, Any]:
        """Convierte configuración a diccionario."""
        return {
            'contracts': {
                'token_contract': self.contracts.token_contract,
                'ailoos_contract': self.contracts.ailoos_contract,
                'pool_address': self.contracts.pool_address
            },
            'network': {
                'rpc_url': self.network.rpc_url,
                'chain_id': self.network.chain_id,
                'gas_price': self.network.gas_price,
                'gas_limit': self.network.gas_limit,
                'timeout': self.network.timeout
            },
            'bridge': {
                'bridge_url': self.bridge.bridge_url,
                'api_key': self.bridge.api_key,
                'timeout': self.bridge.timeout,
                'retry_attempts': self.bridge.retry_attempts,
                'backoff_factor': self.bridge.backoff_factor
            }
        }


# Instancia global de configuración
_dracma_config: Optional[DracmaConfig] = None


def get_dracma_config() -> DracmaConfig:
    """Obtiene instancia global de configuración Dracma."""
    global _dracma_config
    if _dracma_config is None:
        _dracma_config = DracmaConfig.from_env()
        logger.info("✅ Dracma configuration loaded from environment")
    return _dracma_config


def reload_dracma_config() -> DracmaConfig:
    """Recarga configuración desde variables de entorno."""
    global _dracma_config
    _dracma_config = DracmaConfig.from_env()
    logger.info("🔄 Dracma configuration reloaded")
    return _dracma_config


# Backward-compatible aliases (legacy plural names)
def get_dracmas_config() -> DracmaConfig:
    return get_dracma_config()


def reload_dracmas_config() -> DracmaConfig:
    return reload_dracma_config()


# NOTE:
# Do NOT instantiate a default DracmaConfig at import time.
# DracmaConfig validates contract addresses in __post_init__, and placeholder defaults
# must not crash any import path (smoke tests, CLI help, etc.).
#
# If a caller really needs defaults, they should call `DracmaConfig.from_env()`
# or construct DracmaConfig explicitly after setting `DRACMA_ALLOW_MOCK_ADDRESSES=1`.
