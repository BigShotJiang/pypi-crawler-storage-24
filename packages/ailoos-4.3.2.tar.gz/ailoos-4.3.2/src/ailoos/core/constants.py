"""
Constantes globales para el ecosistema AILOOS.
"""

from enum import Enum

class NodeArchetype(str, Enum):
    """Arquetipos de escala de nodos basados en el volumen de red."""
    SOVEREIGN = "Sovereign"  # 1 Nodo
    BINARY = "Binary"        # 2 Nodos (Nuevo)
    PHALANX = "Phalanx"      # 3-20 Nodos
    FOUNDRY = "Foundry"      # 100-5000 Nodos
    NEXUS = "Nexus"          # 100,000+ Nodos

def get_archetype_by_count(count: int) -> str:
    """
    Determina el arquetipo de despliegue basado en el número de nodos.
    
    Args:
        count: Número de nodos en el clúster o sesión.
        
    Returns:
        Nombre del arquetipo.
    """
    if count >= 100000:
        return NodeArchetype.NEXUS.value
    elif count >= 100:
        return NodeArchetype.FOUNDRY.value
    elif count >= 3:
        return NodeArchetype.PHALANX.value
    elif count == 2:
        return NodeArchetype.BINARY.value
    else:
        return NodeArchetype.SOVEREIGN.value

class NodeRole(str, Enum):
    """Roles funcionales de los nodos."""
    SCOUT = "Scout"
    FORGE = "Forge"
    VALIDATOR = "Validator"
    AGGREGATOR = "Aggregator"
    ORACLE = "Oracle"
    ARCHIVAL = "Archival"
    RELAY = "Relay"
