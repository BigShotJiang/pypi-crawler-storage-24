"""
Deployment Archetypes for AILOOS Nodes.
Defines the scale and operational characteristics of a node deployment.
"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict, Any, Optional

from .constants import NodeArchetype as DeploymentArchetype


@dataclass
class ArchetypeConfig:
    """Configuration overrides imposed by the archetype."""
    description: str
    max_concurrent_sessions_multiplier: float = 1.0
    p2p_connection_limit: int = 50
    enable_high_performance_logging: bool = True  # False for Nexus to save I/O
    local_aggregation_enabled: bool = False       # True for Phalanx/Foundry
    security_strictness_level: str = "standard"   # standard, high, paranoid
    
    # Resource Constraints (Strict Validation)
    min_phys_cores: int = 2
    min_ram_gb: int = 4
    requires_gpu: bool = False
    min_storage_tb: float = 0.5
    
    # Resource Hints
    suggested_min_memory_gb: int = 8


ARCHETYPE_CONFIGS: Dict[DeploymentArchetype, ArchetypeConfig] = {
    DeploymentArchetype.SOVEREIGN: ArchetypeConfig(
        description="The Atom. Individual deployment.",
        max_concurrent_sessions_multiplier=1.0,
        p2p_connection_limit=50,
        security_strictness_level="standard",
        suggested_min_memory_gb=8,
        # Constraints
        min_phys_cores=2,
        min_ram_gb=4,
        requires_gpu=False,
        min_storage_tb=0.1
    ),
    DeploymentArchetype.BINARY: ArchetypeConfig(
        description="The Pair. Two-node synchronized cluster.",
        max_concurrent_sessions_multiplier=1.5,
        p2p_connection_limit=100,
        security_strictness_level="standard",
        suggested_min_memory_gb=16,
        # Constraints
        min_phys_cores=4,
        min_ram_gb=8,
        requires_gpu=False,
        min_storage_tb=0.5
    ),
    DeploymentArchetype.PHALANX: ArchetypeConfig(
        description="The Squad. Coordinated local cluster.",
        max_concurrent_sessions_multiplier=2.0,
        p2p_connection_limit=200,
        local_aggregation_enabled=True,
        security_strictness_level="standard",
        suggested_min_memory_gb=32,
        # Constraints
        min_phys_cores=8,
        min_ram_gb=16,
        requires_gpu=False,
        min_storage_tb=1.0
    ),
    DeploymentArchetype.FOUNDRY: ArchetypeConfig(
        description="The Factory. Renewed mining farm.",
        max_concurrent_sessions_multiplier=10.0,
        p2p_connection_limit=2000,
        local_aggregation_enabled=True,
        security_strictness_level="high",  # Protect the asset
        suggested_min_memory_gb=64,
        # Constraints - High bar for Foundry
        min_phys_cores=16,
        min_ram_gb=64,
        requires_gpu=True, # Foundries MUST be gpu-accelerated
        min_storage_tb=4.0
    ),
    DeploymentArchetype.NEXUS: ArchetypeConfig(
        description="The Titan. Massive data center.",
        max_concurrent_sessions_multiplier=100.0,
        p2p_connection_limit=50000,
        enable_high_performance_logging=False, # Reduce logging overhead
        local_aggregation_enabled=True,
        security_strictness_level="paranoid",
        suggested_min_memory_gb=512,
        # Constraints - Impossible for consumer hardware
        min_phys_cores=64,
        min_ram_gb=256,
        requires_gpu=True,
        min_storage_tb=100.0
    )
}

def get_archetype_config(archetype: DeploymentArchetype) -> ArchetypeConfig:
    return ARCHETYPE_CONFIGS[archetype]
