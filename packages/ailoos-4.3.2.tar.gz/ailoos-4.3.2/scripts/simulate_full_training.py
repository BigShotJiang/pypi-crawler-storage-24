#!/usr/bin/env python3
import os
import sys
import json
import logging
import asyncio
import torch
from datetime import datetime
from dataclasses import asdict

# Añadir src al path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from ailoos.data.dataset_manager import get_dataset_manager
from ailoos.data.registry import get_dataset_registry
from ailoos.coordinator.services.session_service import SessionService
from ailoos.coordinator.services.round_service import RoundService
from ailoos.coordinator.models.schemas import FederatedSessionCreate
from ailoos.coordinator.database.connection import SessionLocal, engine, Base, create_tables
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# FORZAR SQLITE PARA SIMULACIÓN LOCAL
sqlite_url = "sqlite:///data/simulation.db"
os.makedirs("data", exist_ok=True)
engine_sqlite = create_engine(sqlite_url, connect_args={"check_same_thread": False})
SessionLocal_sqlite = sessionmaker(autocommit=False, autoflush=False, bind=engine_sqlite)

# Monkeypatch
import ailoos.coordinator.database.connection
ailoos.coordinator.database.connection.engine = engine_sqlite
ailoos.coordinator.database.connection.SessionLocal = SessionLocal_sqlite

# IMPORTAR MODELOS PARA QUE SQLALCHEMY LOS REGISTRE EN Base.metadata
from ailoos.coordinator.models.base import (
    Base, Node, FederatedSession, SessionParticipant, 
    FederatedRound, Contribution, RewardTransaction
)

# Crear tablas en el nuevo engine
Base.metadata.create_all(bind=engine_sqlite)

def get_db_session():
    return SessionLocal_sqlite()

from ailoos.verification.training_prover import TrainingProver, TrainingParameters
from ailoos.core.config import Config

# Configuración de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("FullTrainingSim")

async def run_simulation():
    logger.info("🎬 Iniciando simulación de entrenamiento completo...")
    
    # 0. Asegurar tablas y DB
    create_tables()
    db = get_db_session()
    
    try:
        # 1. Preparar Dataset Real
        logger.info("Step 1: Ingesta de Dataset...")
        data_dir = os.path.abspath("data/training_samples")
        os.makedirs(data_dir, exist_ok=True)
        sample_path = os.path.join(data_dir, "production_sample.txt")
        with open(sample_path, 'w') as f:
            f.write("Datos de producción para EmpoorioLM. Confidencial.\n" * 100)
            
        manager = get_dataset_manager()
        ds_result = manager.process_text_file(
            file_path=sample_path,
            dataset_name="EmpoorioLM_Prod_v1",
            shard_size_mb=1.0
        )
        dataset_id = ds_result["dataset_id"]
        logger.info(f"✅ Dataset listo: {dataset_id}")

        # 2. Crear Sesión
        logger.info("Step 2: Creación de Sesión Federada...")
        session_id = f"session_prod_{int(datetime.now().timestamp())}"
        session_create = FederatedSessionCreate(
            id=session_id,
            name="EmpoorioLM Production Run #1",
            description="Simulación de entrenamiento de producción federado",
            model_type="EmpoorioLM-MoE",
            total_rounds=1,
            min_nodes=3,
            dataset_info={"dataset_id": dataset_id},
            configuration={
                "min_participants_per_round": 3,
                "learning_rate": 0.0001
            }
        )
        await SessionService.create_session(db, session_create)
        logger.info(f"✅ Sesión creada: {session_id}")

        # 3. Iniciar Ronda
        round_id = f"{session_id}:1"
        logger.info(f"Step 3: Iniciando Ronda {round_id}...")
        await RoundService.start_round(db, round_id)

        # 4. Simular 3 Nodos y sus Contribuciones
        nodes = ["node_alpha", "node_beta", "node_gamma"]
        prover = TrainingProver()
        
        logger.info(f"Step 4: Simulando 3 nodos contribuyendo a {round_id}...")

        # Necesitamos que los nodos se unan a la sesión primero
        from ailoos.coordinator.models.base import SessionParticipant, Node
        for node_id in nodes:
            # Asegurar que el nodo existe en la DB
            if not db.query(Node).filter(Node.id == node_id).first():
                db.add(Node(id=node_id, public_key="0"*64, status="active"))
            
            # Limpiar participantes previos si existen (para re-ejecución)
            db.query(SessionParticipant).filter(
                SessionParticipant.session_id == session_id,
                SessionParticipant.node_id == node_id
            ).delete()
            
            db.add(SessionParticipant(
                session_id=session_id,
                node_id=node_id,
                status="joined"
            ))
        db.commit()

        for i, node_id in enumerate(nodes):
            logger.info(f"   Node {node_id}: Entrenando y generando prueba ZKP...")
            
            # Generar pesos simulados (tensores)
            weights = {
                "transformer.layer.0.weight": torch.randn(4, 4) + (i * 0.1), # Un poco de variación
                "transformer.layer.0.bias": torch.randn(4)
            }
            
            # Generar Prueba ZKP Real
            training_results = {"initial_accuracy": 0.5, "final_accuracy": 0.72 + (i * 0.01)}
            params = TrainingParameters(epochs=1, batch_size=32)
            
            # El prover genera un objeto TrainingProof
            proof_obj = await prover.generate_training_proof(
                node_id=node_id,
                session_id=session_id,
                round_number=1,
                training_data_stats={"samples": 100},
                training_parameters=params,
                training_results=training_results,
                model_parameters=weights
            )
            
            # Convertir pesos a lista para JSON serializability si es necesario, 
            # pero el Service espera tensores dentro del dict si va a agregar.
            # Sin embargo, la API suele recibir listas. 
            # El Service hace `torch.tensor(v)` si es lista.
            weights_list = {k: v.tolist() for k, v in weights.items()}
            
            update_payload = {
                "training_proof": asdict(proof_obj),
                "model_weights": weights_list, # Se pasará como model_parameters en submit_model_update
                "num_samples": 100,
                "accuracy": 0.72 + (i * 0.01),
                "loss": 0.45 - (i * 0.05),
                "training_time": 12.5,
                "parameters_trained": 1000,
                "public_key": "0" * 64, # Mock sig
                "signature": "0" * 128
            }

            # Enviar actualización
            # RoundService.submit_model_update espera model_update que contiene model_weights
            result = await RoundService.submit_model_update(
                db=db,
                round_id=round_id,
                node_id=node_id,
                model_update=update_payload
            )
            logger.info(f"   ✅ Nodo {node_id} enviado. Status: {result['status']}")
            
            if result['status'] == "aggregated":
                logger.info("🌟 UMBRAL DE AGREGACIÓN ALCANZADO 🌟")
                logger.info(f"📁 Modelo global guardado en: {result['model_path']}")

        # 4. Verificar Recompensas
        from ailoos.coordinator.models.base import RewardTransaction
        rewards = db.query(RewardTransaction).filter(RewardTransaction.session_id == session_id).all()
        
        print("\n" + "═"*60)
        print("🌍 RESULTADO DE LA SIMULACIÓN DE PRODUCCIÓN")
        print("═"*60)
        print(f"Sesión ID:     {session_id}")
        print(f"Participantes: {len(nodes)}")
        print(f"Estado Final:  COMPLETED (Aggregated)")
        print("\n💰 RECOMPENSAS DISTRIBUIDAS (DRACMA):")
        for r in rewards:
            print(f"   Node: {r.node_id:12} | Reward: {r.dracma_amount:10.4f} EMP")
        print("═"*60)

    except Exception as e:
        logger.exception(f"❌ Error en la simulación: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    asyncio.run(run_simulation())
