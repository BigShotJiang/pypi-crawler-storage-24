
import sys
import os

# Add src to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from ailoos.core.constants import get_archetype_by_count, NodeArchetype

def test_archetypes():
    test_cases = [
        (1, NodeArchetype.SOVEREIGN.value),
        (2, NodeArchetype.BINARY.value),
        (3, NodeArchetype.PHALANX.value),
        (10, NodeArchetype.PHALANX.value),
        (20, NodeArchetype.PHALANX.value),
        (50, NodeArchetype.PHALANX.value), # Phalanx actually ends at 100 according to my logic
        (100, NodeArchetype.FOUNDRY.value),
        (1000, NodeArchetype.FOUNDRY.value),
        (100000, NodeArchetype.NEXUS.value)
    ]
    
    print("--- Verificando Escalas de Red (Arquetipos) ---")
    all_passed = True
    for count, expected in test_cases:
        result = get_archetype_by_count(count)
        status = "✅ PASS" if result == expected else f"❌ FAIL (Got {result})"
        print(f"Nodes: {count:<8} | Expected: {expected:<10} | Result: {result:<10} | {status}")
        if result != expected:
            all_passed = False
            
    if all_passed:
        print("\n✨ Toda la lógica de arquetipos es correcta.")
    else:
        print("\n⚠️ Se encontraron discrepancias en la lógica.")
        sys.exit(1)

if __name__ == "__main__":
    test_archetypes()
