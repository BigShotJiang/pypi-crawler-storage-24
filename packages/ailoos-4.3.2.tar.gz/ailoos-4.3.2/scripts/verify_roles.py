import sys
import os
from enum import Enum
from typing import List

# Add src to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from ailoos.core.constants import NodeArchetype, get_archetype_by_count

def test_archetypes():
    print("--- Testing Archetypes ---")
    test_cases = [
        (1, NodeArchetype.SOVEREIGN),
        (2, NodeArchetype.BINARY),
        (3, NodeArchetype.PHALANX),
        (10, NodeArchetype.PHALANX),
        (50, NodeArchetype.PHALANX),
        (1000, NodeArchetype.FOUNDRY),
        (100000, NodeArchetype.NEXUS)
    ]
    
    for count, expected in test_cases:
        actual = get_archetype_by_count(count)
        # expected is an Enum member, actual is a string (value)
        status = "✅" if actual == expected.value else "❌"
        print(f"Nodes: {count:6} | Expected: {expected.value:10} | Actual: {actual:10} | {status}")

def test_roles_logic():
    print("\n--- Testing Roles Integration (Simulated) ---")
    
    # Mocking some objects for logic check
    class MockNode:
        def __init__(self, role):
            self.role = role

    class MockSession:
        def __init__(self, required_roles):
            self.required_roles = required_roles

    # Simulate Join Logic
    def can_join(node, session):
        if not session.required_roles:
            return True
        return node.role in session.required_roles

    # Test cases
    s1 = MockSession(required_roles=["Forge", "Validator"])
    n_forge = MockNode(role="Forge")
    n_scout = MockNode(role="Scout")
    
    print(f"Node Forge can join session [Forge, Validator]: {can_join(n_forge, s1)}")
    print(f"Node Scout can join session [Forge, Validator]: {can_join(n_scout, s1)}")

if __name__ == "__main__":
    test_archetypes()
    test_roles_logic()
    print("\nVerification Complete.")
