#!/usr/bin/env python3
import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple
from urllib.parse import urlparse

import aiohttp

# Prioritize local package code.
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.blockchain.wallet_manager import WalletManager
from ailoos.blockchain.bridge_client import get_bridge_client


def _candidate_coordinator_urls(primary: str, env_file: Dict[str, str]) -> List[str]:
    candidates: List[str] = []
    for value in (
        primary,
        _env_value("AILOOS_COORDINATOR_URL", env_file),
        _env_value("AILOOS_COORDINATOR_URL_FALLBACK", env_file),
        "https://coordinator.ailoos.com",
        "https://api.testnet.ailoos.com",
        "http://212.227.95.247:8000",
    ):
        if not value:
            continue
        normalized = value.rstrip("/")
        if normalized and normalized not in candidates:
            candidates.append(normalized)
    return candidates


def _load_env_file(path: Path) -> Dict[str, str]:
    data: Dict[str, str] = {}
    if not path.exists():
        return data
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        data[key.strip()] = value.strip().strip("'").strip('"')
    return data


def _env_value(key: str, env_file: Dict[str, str]) -> str:
    return os.getenv(key, env_file.get(key, "")).strip()


def _is_placeholder(value: str) -> bool:
    lowered = value.lower().strip()
    return lowered in {
        "",
        "change_me",
        "your_api_key_here",
        "changeme",
        "default",
        "password",
        "admin",
    }


def _check_env(env_file: Dict[str, str]) -> Tuple[List[Dict[str, Any]], bool]:
    checks: List[Dict[str, Any]] = []
    ok = True

    coordinator = _env_value("AILOOS_COORDINATOR_URL", env_file)
    bridge = _env_value("DRACMA_BRIDGE_URL", env_file)
    ws_url = (
        _env_value("AILOOS_SUBSTRATE_WS_URL", env_file)
        or _env_value("EMPOORIOCHAIN_WS_URL", env_file)
        or ""
    )
    api_key = _env_value("AILOOS_API_KEY", env_file)
    bridge_pk = _env_value("AILOOS_BRIDGE_PRIVATE_KEY", env_file)

    def add(name: str, status: str, detail: str):
        nonlocal ok
        checks.append({"component": name, "status": status, "detail": detail})
        if status == "FAIL":
            ok = False

    if not coordinator:
        add("env.coordinator", "FAIL", "AILOOS_COORDINATOR_URL missing")
    elif "localhost" in coordinator or "127.0.0.1" in coordinator:
        add("env.coordinator", "FAIL", f"local endpoint configured: {coordinator}")
    else:
        add("env.coordinator", "OK", coordinator)

    if not bridge:
        add("env.bridge", "FAIL", "DRACMA_BRIDGE_URL missing")
    elif "localhost" in bridge or "127.0.0.1" in bridge:
        add("env.bridge", "FAIL", f"local endpoint configured: {bridge}")
    else:
        add("env.bridge", "OK", bridge)

    if not ws_url:
        add("env.substrate", "FAIL", "EMPOORIOCHAIN_WS_URL missing")
    elif "localhost" in ws_url or "127.0.0.1" in ws_url:
        add("env.substrate", "FAIL", f"local endpoint configured: {ws_url}")
    else:
        add("env.substrate", "OK", ws_url)

    if _is_placeholder(api_key):
        add("env.api_key", "WARN", "AILOOS_API_KEY missing or placeholder")
    else:
        add("env.api_key", "OK", "configured")

    if _is_placeholder(bridge_pk):
        add("env.bridge_signer", "WARN", "AILOOS_BRIDGE_PRIVATE_KEY missing or placeholder")
    else:
        add("env.bridge_signer", "OK", "configured")

    return checks, ok


async def _http_probe(
    session: aiohttp.ClientSession,
    method: str,
    url: str,
    *,
    json_payload: Dict[str, Any] = None,
) -> Dict[str, Any]:
    result = {"url": url, "method": method, "ok": False}
    try:
        async with session.request(method, url, json=json_payload) as resp:
            body = await resp.text()
            result.update(
                {
                    "ok": 200 <= resp.status < 300,
                    "status_code": resp.status,
                    "body_preview": body[:240],
                }
            )
    except Exception as e:
        result["error"] = str(e)
    return result


async def _check_coordinator(base_url: str) -> List[Dict[str, Any]]:
    checks: List[Dict[str, Any]] = []
    timeout = aiohttp.ClientTimeout(total=10)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        health_candidates = [
            f"{base_url}/health",
            f"{base_url}/api/health",
            f"{base_url}/docs",
        ]
        health_ok = False
        for url in health_candidates:
            probe = await _http_probe(session, "GET", url)
            if probe.get("ok") or probe.get("status_code") in {200, 204, 307, 308}:
                checks.append({"component": "coordinator.health", "status": "OK", "detail": probe})
                health_ok = True
                break
        if not health_ok:
            checks.append(
                {
                    "component": "coordinator.health",
                    "status": "FAIL",
                    "detail": "No health/docs endpoint responded successfully",
                }
            )

        auth_candidates = [
            f"{base_url}/api/auth/nodes/login",
            f"{base_url}/auth/nodes/login",
            f"{base_url}/api/auth/login",
        ]
        auth_payload = {"node_id": "probe", "signature": "probe"}
        auth_found = False
        for url in auth_candidates:
            probe = await _http_probe(session, "POST", url, json_payload=auth_payload)
            code = probe.get("status_code")
            if code in {200, 400, 401, 403, 404, 422}:
                status = "OK" if code != 404 else "WARN"
                checks.append({"component": "coordinator.auth", "status": status, "detail": probe})
                if code != 404:
                    auth_found = True
                    break
        if not auth_found:
            checks.append(
                {
                    "component": "coordinator.auth",
                    "status": "FAIL",
                    "detail": "No auth endpoint responded as expected",
                }
            )
    return checks


def _check_substrate() -> Dict[str, Any]:
    wallet = WalletManager()
    info = wallet.get_chain_info()
    if info.get("is_valid"):
        return {"component": "substrate.rpc", "status": "OK", "detail": info}
    return {"component": "substrate.rpc", "status": "FAIL", "detail": info}


async def _check_bridge() -> Dict[str, Any]:
    try:
        bridge = get_bridge_client()
        status = await bridge.get_bridge_status()
        detail = {
            "base_url": getattr(bridge, "base_url", ""),
            "status": status,
            "signer_active": bool(getattr(bridge, "signer", None)),
        }
        ok = status.get("success", False) or status.get("status") not in {"unknown", None}
        return {"component": "bridge.status", "status": "OK" if ok else "FAIL", "detail": detail}
    except Exception as e:
        return {"component": "bridge.status", "status": "FAIL", "detail": str(e)}


async def main() -> int:
    repo_root = Path(__file__).resolve().parent.parent
    env_file = _load_env_file(repo_root / ".env")
    env_checks, _ = _check_env(env_file)

    coordinator_url = _env_value("AILOOS_COORDINATOR_URL", env_file)
    checks: List[Dict[str, Any]] = list(env_checks)
    checks.append(_check_substrate())
    checks.append(await _check_bridge())

    if coordinator_url:
        coordinator_checks: List[Dict[str, Any]] = []
        for candidate in _candidate_coordinator_urls(coordinator_url, env_file):
            result = await _check_coordinator(candidate)
            coordinator_checks = result
            health_ok = any(
                item["component"] == "coordinator.health" and item["status"] == "OK"
                for item in result
            )
            auth_ok = any(
                item["component"] == "coordinator.auth" and item["status"] in {"OK", "WARN"}
                for item in result
            )
            if health_ok or auth_ok:
                break
        checks.extend(coordinator_checks)
    else:
        checks.append(
            {"component": "coordinator.health", "status": "FAIL", "detail": "AILOOS_COORDINATOR_URL missing"}
        )

    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    warn_count = sum(1 for item in checks if item["status"] == "WARN")
    ok_count = sum(1 for item in checks if item["status"] == "OK")

    report = {
        "summary": {"ok": ok_count, "warn": warn_count, "fail": fail_count},
        "checks": checks,
    }
    print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
    return 0 if fail_count == 0 else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
