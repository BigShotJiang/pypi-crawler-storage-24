#!/usr/bin/env python3
import os
import sys
import json
import logging
from datetime import datetime

# Añadir src al path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from ailoos.data.dataset_manager import get_dataset_manager
from ailoos.data.registry import get_dataset_registry
from ailoos.coordinator.services.session_service import SessionService
from ailoos.coordinator.models.schemas import FederatedSessionCreate
from sqlalchemy import create_mock_engine # Usaremos el DB real si es posible

# Configuración de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("PrepareTraining")

def create_sample_training_data(file_path: str):
    """Crea un archivo de datos de entrenamiento con información sensible simulada."""
    logger.info(f"📝 Creando datos de entrenamiento en {file_path}")
    raw_data = [
        "Usuario Julio Javier (julio@example.com) prefiere el modo oscuro.",
        "La clave de API sk-123456789 no debe ser compartida.",
        "EmpoorioLM es un modelo de lenguaje federado diseñado por DeepMind.",
        "Los nodos ganan recompensas en Dracma por su contribución.",
        "Dirección IP del servidor: 192.168.1.100.",
        "El entrenamiento federado preserva la privacidad al no mover los datos crudos."
    ]
    
    # Generar 1000 líneas para tener algo de volumen
    with open(file_path, 'w') as f:
        for i in range(200):
            for line in raw_data:
                f.write(f"{line} [Index {i}]\n")

async def main():
    # 1. Preparar archivo local
    data_dir = os.path.abspath("data/training_samples")
    os.makedirs(data_dir, exist_ok=True)
    sample_path = os.path.join(data_dir, "empooriolm_v1_raw.txt")
    create_sample_training_data(sample_path)
    
    # 2. Ingesta y Procesamiento Real (Sanitización + IPFS)
    logger.info("🚀 Iniciando circuito de ingesta (Sanitización PII + IPFS)...")
    manager = get_dataset_manager()
    
    # Esto activará el PII Scrubber y subirá shards a IPFS
    result = manager.process_text_file(
        file_path=sample_path,
        dataset_name="EmpoorioLM Core Dataset v1",
        shard_size_mb=0.1,  # Shards pequeños para esta prueba
        metadata={
            "domain": "AI Research",
            "model_target": "EmpoorioLM"
        }
    )
    
    dataset_id = result["dataset_id"]
    logger.info(f"✅ Dataset procesado y registrado: {dataset_id}")
    logger.info(f"🔗 Shards subidos a IPFS: {len(result['shard_cids'])}")
    
    # 3. Crear Sesión Federada Automáticamente
    logger.info("📡 Creando sesión federada vinculada al dataset real...")
    
    # Nota: SessionService requiere una DB real (SQLAlchemy Session)
    # En este script de demo, mostramos cómo se llamaría
    session_data = FederatedSessionCreate(
        name="EmpoorioLM Production Training Round 1",
        description="Entrenamiento inicial de EmpoorioLM con datos sanitizados",
        model_type="EmpoorioLM-MoE",
        total_rounds=5,
        min_nodes=3,
        max_nodes=100,
        dataset_info={
            "dataset_id": dataset_id,
            "manifest_cid": result.get("manifest_cid")
        },
        configuration={
            "learning_rate": 2e-5,
            "batch_size": 32,
            "aggregation": "FedAvg-Production"
        }
    )
    
    print("\n" + "="*50)
    print("RESUMEN DEL CIRCUITO")
    print("="*50)
    print(f"Dataset Name: {result['dataset_name']}")
    print(f"Dataset ID:   {dataset_id}")
    print(f"Status:       Sanitized (PII Checked)")
    print(f"IPFS Shards:  {len(result['shard_cids'])}")
    print(f"Session Plan: {session_data.name}")
    print("="*50)
    print("\nEl circuito está listo para la ejecución federada.")

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
