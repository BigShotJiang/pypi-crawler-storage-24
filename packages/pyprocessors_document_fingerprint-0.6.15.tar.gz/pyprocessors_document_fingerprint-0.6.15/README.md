# pyprocessors_document_fingerprint

[![license](https://img.shields.io/github/license/oterrier/pyprocessors_document_fingerprint)](https://github.com/oterrier/pyprocessors_document_fingerprint/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyprocessors_document_fingerprint/workflows/tests/badge.svg)](https://github.com/oterrier/pyprocessors_document_fingerprint/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyprocessors_document_fingerprint)](https://codecov.io/gh/oterrier/pyprocessors_document_fingerprint)
[![docs](https://img.shields.io/readthedocs/pyprocessors_document_fingerprint)](https://pyprocessors_document_fingerprint.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyprocessors_document_fingerprint)](https://pypi.org/project/pyprocessors_document_fingerprint/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyprocessors_document_fingerprint)](https://pypi.org/project/pyprocessors_document_fingerprint/)

DocumentFingerprint annotations coming from different annotators

## Installation

You can simply `pip install pyprocessors_document_fingerprint`.

## Developing

### Pre-requisites

You will need to install `uv` (for managing dependencies and running tests):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyprocessors_document_fingerprint
```

### Running the test suite

Install dependencies and run the full test suite:

```
uv sync --extra test
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
