"""kv — encrypted secrets management for developers."""
__version__ = "0.2.0"
