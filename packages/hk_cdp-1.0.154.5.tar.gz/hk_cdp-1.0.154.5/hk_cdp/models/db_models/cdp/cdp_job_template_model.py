# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2024-11-06 09:39:45
@LastEditTime: 2026-03-19 19:38:14
@LastEditors: HuangJianYi
@Description: 
"""

# 此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class CdpJobTemplateModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(CdpJobTemplateModel, self).__init__(CdpJobTemplate, sub_table)
        self.db = MySQLHelper(self.convert_db_config(db_connect_key, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class CdpJobTemplate:
    def __init__(self):
        super(CdpJobTemplate, self).__init__()
        self.id = 0  # id
        self.job_code = ""  # 作业代码(对应函数名)
        self.job_desc = ""  # 作业描述
        self.engineer_code = ""  # 工程代码
        self.job_type = 0  # 任务类型(1-商家 2-店铺)
        self.tag_name = ""  # 标签名称(多个逗号分隔)
        self.sort_index = 0  # 排序
        self.is_release = 0  # 是否发布（1-是 0-否）
        self.create_date = '1970-01-01 00:00:00.000'  # 创建时间
        self.modify_date = '1970-01-01 00:00:00.000'  # 修改时间



    @classmethod
    def get_field_list(self):
        return [
            'id', 'job_code', 'job_desc', 'engineer_code', 'job_type', 'tag_name', 'sort_index', 'is_release', 'create_date', 'modify_date'
        ]

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "cdp_job_template_tb"
