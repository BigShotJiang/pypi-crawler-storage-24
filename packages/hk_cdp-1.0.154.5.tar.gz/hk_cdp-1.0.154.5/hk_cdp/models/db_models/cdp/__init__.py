# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2024-11-22 17:23:58
@LastEditTime: 2026-03-19 16:50:46
@LastEditors: HuangJianYi
@Description: 
"""
__all__ = ["cdp_store_info_model","cdp_work_info_model","cdp_job_info_model","cdp_job_template_model"]
