# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-03-10 00:00:00
@LastEditTime: 2026-03-10 00:00:00
@LastEditors: HuangJianYi
@Description: 京东商品表
"""
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class JdSourceItemModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', db_config_dict=None, sub_table=None, db_transaction=None, context=None, is_auto=False, cache_sub_table=None):
        super(JdSourceItemModel, self).__init__(JdSourceItem, sub_table, cache_sub_table)
        if not db_config_dict:
            db_config_dict = config.get_value(db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_config_dict, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class JdSourceItem:
    def __init__(self):
        super(JdSourceItem, self).__init__()
        self.wareId = 0  # 商品id
        self.shopId = 0  # 店铺id
        self.venderId = 0  # 商家id
        self.title = ''  # 商品名称
        self.categoryId = 0  # 3级类目ID，来源于类目接口返回ID
        self.wareStatus = 0  # 商品状态
        self.outerId = ''  # 商品外部ID,商家自行设置的ID（便于关联京东商品）
        self.logo = ''  # 商品主图。该字段返回的不是完整的图片jpg链接，需要拼接https://img10.360buyimg.com/imgzone/前缀
        self.marketPrice = 0.0  # 市场价单位：元
        self.costPrice = 0.0  # 成本价单位：元
        self.jdPrice = 0.0  # 京东价单位：元
        self.stockNum = 0  # 总库存数
        self.transportId = 0  # 运费模板ID
        self.skuJson = {}  # sku详情(JSON)
        self.offlineTime = '1900-01-01 00:00:00.000'  # 最后下架时间
        self.onlineTime = '1900-01-01 00:00:00.000'  # 最后上架时间
        self.modified = '1900-01-01 00:00:00.000'  # 商品最后一次修改时间
        self.created = '1900-01-01 00:00:00.000'  # 商品创建时间

    @classmethod
    def get_field_list(self):
        return [
            'wareId', 'shopId', 'venderId', 'title', 'categoryId', 'wareStatus', 'outerId', 'logo',
            'marketPrice', 'costPrice', 'jdPrice', 'stockNum', 'transportId', 'skuJson', 'offlineTime',
            'onlineTime', 'modified', 'created'
        ]

    @classmethod
    def get_primary_key(self):
        return "wareId"

    def __str__(self):
        return "jd_source_item_tb"
