# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-03-10 00:00:00
@LastEditTime: 2026-03-10 00:00:00
@LastEditors: HuangJianYi
@Description: 京东买家用户表
"""
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class JdSourceBuyerModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', db_config_dict=None, sub_table=None, db_transaction=None, context=None, is_auto=False, cache_sub_table=None):
        super(JdSourceBuyerModel, self).__init__(JdSourceBuyer, sub_table, cache_sub_table)
        if not db_config_dict:
            db_config_dict = config.get_value(db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_config_dict, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class JdSourceBuyer:
    def __init__(self):
        super(JdSourceBuyer, self).__init__()
        self.xid = ''  # xid
        self.pin = ''  # pin
        self.open_uid = ''  # open_id_buyer
        self.store_id = ''  # 店铺id
        self.vender_id = ''  # 商家id
        self.status = ''  # 显示会员的状态，normal正常，blacklist黑名单
        self.grade = 0  # 会员等级
        self.province = ''  # 省份
        self.city = ''  # 城市
        self.last_trade_time = '1900-01-01 00:00:00.000'  # 最后交易的日期
        self.item_num = 0  # 购买的宝贝件数
        self.trade_amount = 0.0  # 交易的金额
        self.trade_count = 0  # 交易成功的次数
        self.item_close_count = 0  # 交易关闭的宝贝件数
        self.close_trade_amount = 0.0  # 交易关闭金额
        self.close_trade_count = 0  # 交易关闭的笔数
        self.avg_price = 0.0  # 平均客单价
        self.modify_time = '1900-01-01 00:00:00.000'  # 修改时间
        self.create_time = '1900-01-01 00:00:00.000'  # 创建时间

    @classmethod
    def get_field_list(self):
        return [
            'xid', 'pin', 'open_uid', 'store_id', 'vender_id', 'status', 'grade', 'province', 'city',
            'last_trade_time', 'item_num', 'trade_amount', 'trade_count', 'item_close_count', 'close_trade_amount',
            'close_trade_count', 'avg_price', 'modify_time', 'create_time'
        ]

    @classmethod
    def get_primary_key(self):
        return "xid"

    def __str__(self):
        return "jd_source_buyer_tb"
