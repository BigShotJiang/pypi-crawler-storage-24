# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-03-10 00:00:00
@LastEditTime: 2026-03-10 00:00:00
@LastEditors: HuangJianYi
@Description: 京东用户pin表
"""
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class JdUserPinModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', db_config_dict=None, sub_table=None, db_transaction=None, context=None, is_auto=False, cache_sub_table=None):
        super(JdUserPinModel, self).__init__(JdUserPin, sub_table, cache_sub_table)
        if not db_config_dict:
            db_config_dict = config.get_value(db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_config_dict, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class JdUserPin:
    def __init__(self):
        super(JdUserPin, self).__init__()
        self.id = 0  # id
        self.business_id = 0  # 商家标识
        self.real_pin = ''  # real_pin
        self.xid = ''  # xid
        self.create_date = '1970-01-01 00:00:00.000'  # 创建时间

    @classmethod
    def get_field_list(self):
        return [
            'id', 'business_id', 'real_pin', 'xid', 'create_date'
        ]

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "jd_user_pin_tb"
