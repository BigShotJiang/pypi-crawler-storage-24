"""Unit tests for SchiftVectorStore."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


def test_import() -> None:
    """Test that the package can be imported."""
    from langchain_schift import SchiftVectorStore

    assert SchiftVectorStore is not None


def test_must_specify_bucket_or_collection() -> None:
    """Must specify exactly one of bucket or collection."""
    from langchain_schift import SchiftVectorStore

    with pytest.raises(ValueError, match="Must specify either"):
        SchiftVectorStore(api_key="sk-test")


def test_cannot_specify_both() -> None:
    """Cannot specify both bucket and collection."""
    from langchain_schift import SchiftVectorStore

    with pytest.raises(ValueError, match="not both"):
        SchiftVectorStore(api_key="sk-test", bucket="b", collection="c")


def test_api_key_required() -> None:
    """API key must be provided."""
    from langchain_schift import SchiftVectorStore

    with patch.dict("os.environ", {}, clear=True):
        with pytest.raises(ValueError, match="api_key"):
            SchiftVectorStore(bucket="b")


@patch("schift.Client")
def test_bucket_mode_init(mock_schift_cls: MagicMock) -> None:
    """Initialize in bucket mode."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_schift_cls.return_value = mock_client

    store = SchiftVectorStore(api_key="sk-test", bucket="my-bucket")
    assert store._bucket_name == "my-bucket"
    assert store._collection_name is None
    assert store.embeddings is None
    mock_client.bucket.assert_called_once_with("my-bucket")


@patch("schift.Client")
def test_collection_mode_init(mock_schift_cls: MagicMock) -> None:
    """Initialize in collection mode."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_schift_cls.return_value = mock_client

    store = SchiftVectorStore(api_key="sk-test", collection="my-coll")
    assert store._collection_name == "my-coll"
    assert store._bucket_name is None
    mock_client.collection.assert_called_once_with("my-coll")


@patch("schift.Client")
def test_add_texts_bucket(mock_schift_cls: MagicMock) -> None:
    """add_texts in bucket mode calls bucket.upload."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_bucket = MagicMock()
    mock_job = MagicMock()
    mock_job.job_id = "job-1"
    mock_bucket.upload.return_value = MagicMock(jobs=[mock_job])
    mock_client.bucket.return_value = mock_bucket
    mock_schift_cls.return_value = mock_client

    store = SchiftVectorStore(api_key="sk-test", bucket="b")
    result = store.add_texts(["hello", "world"])

    assert result == ["job-1"]
    mock_bucket.upload.assert_called_once()


@patch("schift.Client")
def test_add_texts_collection(mock_schift_cls: MagicMock) -> None:
    """add_texts in collection mode calls collection.add."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_coll = MagicMock()
    mock_client.collection.return_value = mock_coll
    mock_schift_cls.return_value = mock_client

    store = SchiftVectorStore(api_key="sk-test", collection="c")
    result = store.add_texts(["hello"], ids=["id-1"])

    assert result == ["id-1"]
    mock_coll.add.assert_called_once()


@patch("schift.Client")
def test_similarity_search_bucket(mock_schift_cls: MagicMock) -> None:
    """similarity_search in bucket mode."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_bucket = MagicMock()
    mock_bucket.search.return_value = [
        {"id": "doc1", "text": "hello world", "score": 0.95, "metadata": {"source": "test"}},
        {"id": "doc2", "text": "foo bar", "score": 0.80, "metadata": None},
    ]
    mock_client.bucket.return_value = mock_bucket
    mock_schift_cls.return_value = mock_client

    store = SchiftVectorStore(api_key="sk-test", bucket="b")
    docs = store.similarity_search("hello", k=2)

    assert len(docs) == 2
    assert docs[0].page_content == "hello world"
    assert docs[0].metadata["source"] == "test"
    assert docs[1].page_content == "foo bar"


@patch("schift.Client")
def test_similarity_search_with_score(mock_schift_cls: MagicMock) -> None:
    """similarity_search_with_score returns tuples."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_bucket = MagicMock()
    mock_bucket.search.return_value = [
        {"id": "doc1", "text": "hello", "score": 0.95, "metadata": {}},
    ]
    mock_client.bucket.return_value = mock_bucket
    mock_schift_cls.return_value = mock_client

    store = SchiftVectorStore(api_key="sk-test", bucket="b")
    results = store.similarity_search_with_score("hello", k=1)

    assert len(results) == 1
    doc, score = results[0]
    assert doc.page_content == "hello"
    assert score == 0.95


@patch("schift.Client")
def test_add_edges(mock_schift_cls: MagicMock) -> None:
    """add_edges calls bucket.add_edges."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_bucket = MagicMock()
    mock_bucket.add_edges.return_value = 2
    mock_client.bucket.return_value = mock_bucket
    mock_schift_cls.return_value = mock_client

    store = SchiftVectorStore(api_key="sk-test", bucket="b")
    count = store.add_edges([
        {"source": "a", "target": "b", "relation": "follows"},
        {"source": "b", "target": "c", "relation": "supersedes"},
    ])

    assert count == 2


@patch("schift.Client")
def test_add_edges_collection_mode_raises(mock_schift_cls: MagicMock) -> None:
    """add_edges in collection mode raises NotImplementedError."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_schift_cls.return_value = mock_client

    store = SchiftVectorStore(api_key="sk-test", collection="c")
    with pytest.raises(NotImplementedError):
        store.add_edges([{"source": "a", "target": "b", "relation": "follows"}])


@patch("schift.Client")
def test_from_texts(mock_schift_cls: MagicMock) -> None:
    """from_texts class method."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_bucket = MagicMock()
    mock_job = MagicMock()
    mock_job.job_id = "j1"
    mock_bucket.upload.return_value = MagicMock(jobs=[mock_job])
    mock_client.bucket.return_value = mock_bucket
    mock_schift_cls.return_value = mock_client

    store = SchiftVectorStore.from_texts(
        texts=["hello"],
        api_key="sk-test",
        bucket="b",
    )
    assert isinstance(store, SchiftVectorStore)
    mock_bucket.upload.assert_called_once()


@patch("schift.Client")
def test_from_texts_no_embedding_needed(mock_schift_cls: MagicMock) -> None:
    """from_texts works without embedding (server-side embedding)."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_bucket = MagicMock()
    mock_bucket.upload.return_value = MagicMock(jobs=[])
    mock_client.bucket.return_value = mock_bucket
    mock_schift_cls.return_value = mock_client

    # No embedding parameter -- this is the key differentiator
    store = SchiftVectorStore.from_texts(
        texts=["hello"],
        api_key="sk-test",
        bucket="b",
    )
    assert store.embeddings is None


@patch("schift.Client")
def test_graph_expand_search(mock_schift_cls: MagicMock) -> None:
    """Graph-expanded search follows edges."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_bucket = MagicMock()
    mock_bucket.search.return_value = [
        {"id": "doc1", "text": "main result", "score": 0.95, "metadata": {}},
    ]
    mock_bucket.list_edges.return_value = [
        {"source": "doc1", "target": "doc2", "relation": "supersedes", "weight": 0.8,
         "target_text": "related doc"},
    ]
    mock_client.bucket.return_value = mock_bucket
    mock_schift_cls.return_value = mock_client

    store = SchiftVectorStore(api_key="sk-test", bucket="b")
    results = store.similarity_search("test", k=10, graph_expand=True)

    assert len(results) == 2
    assert results[0].page_content == "main result"
    assert results[1].page_content == "related doc"
    assert results[1].metadata["graph_expanded"] is True
    assert results[1].metadata["edge_relation"] == "supersedes"


# -- BYOK (Bring Your Own Provider) tests --


@patch("schift.Client")
def test_byok_add_texts(mock_schift_cls: MagicMock) -> None:
    """BYOK: add_texts embeds client-side and upserts vectors."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_coll = MagicMock()
    mock_client.collection.return_value = mock_coll
    mock_schift_cls.return_value = mock_client

    mock_embeddings = MagicMock()
    mock_embeddings.embed_documents.return_value = [[0.1, 0.2], [0.3, 0.4]]

    store = SchiftVectorStore(
        api_key="sk-test", collection="c", embedding=mock_embeddings
    )
    result = store.add_texts(["hello", "world"], ids=["id-1", "id-2"])

    assert result == ["id-1", "id-2"]
    assert store.embeddings is mock_embeddings
    mock_embeddings.embed_documents.assert_called_once_with(["hello", "world"])
    mock_coll.upsert.assert_called_once()
    # Verify the vectors payload
    call_kwargs = mock_coll.upsert.call_args
    vectors = call_kwargs[1]["vectors"] if "vectors" in (call_kwargs[1] or {}) else call_kwargs[0][0] if call_kwargs[0] else call_kwargs[1].get("vectors")
    # Just verify upsert was called (payload structure tested implicitly)


@patch("schift.Client")
def test_byok_similarity_search(mock_schift_cls: MagicMock) -> None:
    """BYOK: similarity_search embeds query client-side."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_coll = MagicMock()

    # Mock SearchResult objects
    mock_result = MagicMock()
    mock_result.id = "doc1"
    mock_result.score = 0.9
    mock_result.text = "hello world"
    mock_result.metadata = {"source": "test"}
    mock_coll.search_by_vector.return_value = [mock_result]
    mock_client.collection.return_value = mock_coll
    mock_schift_cls.return_value = mock_client

    mock_embeddings = MagicMock()
    mock_embeddings.embed_query.return_value = [0.1, 0.2, 0.3]

    store = SchiftVectorStore(
        api_key="sk-test", collection="c", embedding=mock_embeddings
    )
    docs = store.similarity_search("hello", k=3)

    assert len(docs) == 1
    assert docs[0].page_content == "hello world"
    mock_embeddings.embed_query.assert_called_once_with("hello")
    mock_coll.search_by_vector.assert_called_once()


@patch("schift.Client")
def test_byok_with_metadata(mock_schift_cls: MagicMock) -> None:
    """BYOK: metadata is preserved in upsert payload."""
    from langchain_schift import SchiftVectorStore

    mock_client = MagicMock()
    mock_coll = MagicMock()
    mock_client.collection.return_value = mock_coll
    mock_schift_cls.return_value = mock_client

    mock_embeddings = MagicMock()
    mock_embeddings.embed_documents.return_value = [[0.1, 0.2]]

    store = SchiftVectorStore(
        api_key="sk-test", collection="c", embedding=mock_embeddings
    )
    store.add_texts(
        ["hello"],
        ids=["id-1"],
        metadatas=[{"source": "test", "page": 1}],
    )

    call_args = mock_coll.upsert.call_args
    vectors = call_args[1]["vectors"]
    assert vectors[0]["id"] == "id-1"
    assert vectors[0]["values"] == [0.1, 0.2]
    assert vectors[0]["metadata"]["source"] == "test"
    assert vectors[0]["metadata"]["page"] == 1
    assert vectors[0]["metadata"]["text"] == "hello"
