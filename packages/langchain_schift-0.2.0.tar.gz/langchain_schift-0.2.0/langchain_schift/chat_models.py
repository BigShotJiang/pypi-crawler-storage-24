"""Schift chat model integration for LangChain."""
from __future__ import annotations

import os
from typing import Any, List, Optional

from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
)
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import PrivateAttr, model_validator


class SchiftChatModel(BaseChatModel):
    """LangChain Chat Model using Schift LLM proxy (OpenAI-compatible).

    Schift proxies requests to models like ``openai/gpt-4o-mini``,
    ``anthropic/claude-3-5-sonnet``, etc., while tracking usage and
    enforcing tier limits on your Schift account.

    Usage::

        from langchain_schift import SchiftChatModel

        llm = SchiftChatModel(api_key="sch_xxx", model="openai/gpt-4o-mini")
        response = llm.invoke("Hello!")

    Via environment variable::

        # export SCHIFT_API_KEY=sch_xxx
        llm = SchiftChatModel(model="openai/gpt-4o-mini")
        response = llm.invoke("Hello!")

    With temperature and max_tokens::

        llm = SchiftChatModel(
            model="openai/gpt-4o-mini",
            temperature=0.2,
            max_tokens=512,
        )
    """

    api_key: Optional[str] = None
    """Schift API key. Falls back to SCHIFT_API_KEY environment variable."""

    model: str = "openai/gpt-4o-mini"
    """Model ID to use, e.g. ``"openai/gpt-4o-mini"`` or ``"anthropic/claude-3-5-sonnet"``."""

    base_url: str = "https://api.schift.io/v1"
    """Schift API base URL."""

    temperature: Optional[float] = None
    """Sampling temperature. Uses server default when ``None``."""

    max_tokens: Optional[int] = None
    """Maximum tokens to generate. Uses server default when ``None``."""

    _client: Any = PrivateAttr(default=None)

    @model_validator(mode="after")
    def _init_client(self) -> "SchiftChatModel":
        try:
            from schift import Schift
        except ImportError as exc:
            raise ImportError(
                "Could not import schift python package. "
                "Please install it with: pip install schift"
            ) from exc

        resolved_key = self.api_key or os.environ.get("SCHIFT_API_KEY", "")
        if not resolved_key:
            raise ValueError(
                "API key required. Pass api_key= or set SCHIFT_API_KEY."
            )
        self._client = Schift(api_key=resolved_key, base_url=self.base_url)
        return self

    @property
    def _llm_type(self) -> str:
        return "schift-chat"

    @property
    def _identifying_params(self) -> dict[str, Any]:
        return {"model": self.model, "base_url": self.base_url}

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Call the Schift completions API and return a ChatResult.

        Args:
            messages: List of LangChain ``BaseMessage`` objects.
            stop: Optional list of stop sequences.
            run_manager: Optional callback manager (unused, reserved for
                streaming callbacks in a future ``_stream`` implementation).
            **kwargs: Additional kwargs forwarded to the completions call.

        Returns:
            ``ChatResult`` containing a single ``ChatGeneration``.
        """
        formatted: List[dict] = []
        for msg in messages:
            if isinstance(msg, SystemMessage):
                formatted.append({"role": "system", "content": msg.content})
            elif isinstance(msg, HumanMessage):
                formatted.append({"role": "user", "content": msg.content})
            elif isinstance(msg, AIMessage):
                formatted.append({"role": "assistant", "content": msg.content})
            else:
                # Fallback: treat unknown message types as user turns
                formatted.append({"role": "user", "content": msg.content})

        response = self._client.completions.create(
            model=self.model,
            messages=formatted,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            stop=stop,
        )

        # CompletionResponse is a dataclass; choices[0].message is a dict.
        content = ""
        if hasattr(response, "choices") and response.choices:
            first_choice = response.choices[0]
            # message is a dict: {"role": "assistant", "content": "..."}
            msg_field = first_choice.message
            if isinstance(msg_field, dict):
                content = msg_field.get("content", "") or ""
            else:
                # Defensive: handle if SDK ever returns an object
                content = getattr(msg_field, "content", "") or ""
        elif isinstance(response, dict):
            choices = response.get("choices", [])
            if choices:
                msg_field = choices[0].get("message", {})
                content = msg_field.get("content", "") or ""

        return ChatResult(
            generations=[ChatGeneration(message=AIMessage(content=content))],
        )
