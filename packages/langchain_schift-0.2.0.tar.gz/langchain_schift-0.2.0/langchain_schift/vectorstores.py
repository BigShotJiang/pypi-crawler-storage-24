"""Schift vector store integration for LangChain.

Schift handles embedding server-side, so no Embeddings object is required.
This is the key differentiator from other vector store integrations.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple, Type

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import VectorStore

logger = logging.getLogger(__name__)


class SchiftVectorStore(VectorStore):
    """Schift vector store with server-side embedding and graph edges.

    Schift embeds documents server-side, so you do not need to provide an
    ``Embeddings`` object.  Just pass your API key and bucket name.

    Example:
        .. code-block:: python

            from langchain_schift import SchiftVectorStore

            store = SchiftVectorStore(
                api_key="sk-...",
                bucket="my-bucket",
            )
            store.add_texts(["hello world", "foo bar"])
            results = store.similarity_search("hello", k=3)

    Graph-enhanced retrieval:
        .. code-block:: python

            results = store.similarity_search(
                "hello",
                k=3,
                graph_expand=True,   # follow edges from top results
                graph_depth=1,       # how many hops
            )
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        bucket: Optional[str] = None,
        collection: Optional[str] = None,
        base_url: str = "https://embed.schift.io",
        embedding: Optional[Embeddings] = None,
        relevance_score_fn: Optional[Callable[[float], float]] = None,
    ) -> None:
        """Initialize SchiftVectorStore.

        Args:
            api_key: Schift API key. Falls back to SCHIFT_API_KEY env var.
            bucket: Bucket name (managed files + server-side embedding).
            collection: Collection name (raw vector mode).
                Exactly one of ``bucket`` or ``collection`` must be set.
            base_url: Schift API base URL.
            embedding: Optional LangChain Embeddings for client-side embedding.
                Only needed when using ``collection`` mode with your own
                embedding model. Ignored in ``bucket`` mode.
            relevance_score_fn: Optional function to convert distance to
                relevance score.
        """
        try:
            from schift import Client as _SchiftClient
        except ImportError as e:
            raise ImportError(
                "Could not import schift python package. "
                "Please install it with: pip install schift"
            ) from e

        if bucket and collection:
            raise ValueError("Specify either 'bucket' or 'collection', not both.")
        if not bucket and not collection:
            raise ValueError("Must specify either 'bucket' or 'collection'.")

        import os

        resolved_key = api_key or os.environ.get("SCHIFT_API_KEY")
        if not resolved_key:
            raise ValueError(
                "Must provide api_key or set SCHIFT_API_KEY environment variable."
            )

        self._client = _SchiftClient(api_key=resolved_key, base_url=base_url)
        self._bucket_name = bucket
        self._collection_name = collection
        self._embedding = embedding
        self._relevance_score_fn = relevance_score_fn

        if bucket:
            self._bucket = self._client.bucket(bucket)
            self._collection_obj = None
        else:
            self._bucket = None
            self._collection_obj = self._client.collection(collection)  # type: ignore[arg-type]

    @property
    def embeddings(self) -> Optional[Embeddings]:
        """Return the embedding object (None for bucket mode)."""
        return self._embedding

    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[dict]] = None,
        ids: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> List[str]:
        """Add texts to the vector store.

        In bucket mode, texts are embedded server-side by Schift.
        In collection mode, uses the provided Embeddings or Schift server-side.

        Args:
            texts: Texts to add.
            metadatas: Optional metadata for each text.
            ids: Optional IDs for each text.

        Returns:
            List of IDs of the added texts.
        """
        text_list = list(texts)
        if not text_list:
            return []

        if self._bucket is not None:
            # Bucket mode: upload as text, server handles embedding
            files = [
                (ids[i] if ids and i < len(ids) else f"doc_{i}.txt", t.encode())
                for i, t in enumerate(text_list)
            ]
            result = self._bucket.upload(files)
            return [j.job_id for j in result.jobs]

        # Collection mode
        resolved_ids = ids or [str(i) for i in range(len(text_list))]

        if self._embedding is not None:
            # BYOK: client-side embedding via user-provided Embeddings
            vectors = self._embedding.embed_documents(text_list)
            payloads = []
            for i, (vid, vec, txt) in enumerate(zip(resolved_ids, vectors, text_list)):
                entry: Dict[str, Any] = {
                    "id": vid,
                    "values": vec,
                    "metadata": {**(metadatas[i] if metadatas and i < len(metadatas) else {}), "text": txt},
                }
                payloads.append(entry)
            self._collection_obj.upsert(vectors=payloads)  # type: ignore[union-attr]
        else:
            # Server-side embedding
            self._collection_obj.add(  # type: ignore[union-attr]
                documents=text_list,
                ids=resolved_ids,
                metadata=metadatas,
                **kwargs,
            )
        return resolved_ids

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        *,
        graph_expand: bool = False,
        graph_depth: int = 1,
        graph_relations: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """Search for documents similar to query.

        Args:
            query: Query text.
            k: Number of results.
            filter: Optional metadata filter.
            graph_expand: If True, follow edges from top results to find
                related documents (unique to Schift).
            graph_depth: Number of edge hops for graph expansion.
            graph_relations: Filter graph expansion to specific relation types
                (e.g. ``["caused_by", "supersedes"]``).

        Returns:
            List of Documents most similar to the query.
        """
        docs_and_scores = self.similarity_search_with_score(
            query,
            k=k,
            filter=filter,
            graph_expand=graph_expand,
            graph_depth=graph_depth,
            graph_relations=graph_relations,
            **kwargs,
        )
        return [doc for doc, _ in docs_and_scores]

    def similarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        *,
        graph_expand: bool = False,
        graph_depth: int = 1,
        graph_relations: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """Search with relevance scores.

        Args:
            query: Query text.
            k: Number of results.
            filter: Optional metadata filter.
            graph_expand: Follow edges from top results.
            graph_depth: Number of edge hops.
            graph_relations: Filter to specific relation types.

        Returns:
            List of (Document, score) tuples.
        """
        if self._bucket is not None:
            raw = self._bucket.search(query=query, top_k=k, filter=filter)
        elif self._embedding is not None:
            # BYOK: embed query client-side, then vector search
            query_vec = self._embedding.embed_query(query)
            raw_results = self._collection_obj.search_by_vector(  # type: ignore[union-attr]
                query_vector=query_vec, top_k=k
            )
            raw = [
                {"id": getattr(r, "id", ""), "score": getattr(r, "score", 0.0),
                 "metadata": getattr(r, "metadata", {}), "text": getattr(r, "text", "")}
                if hasattr(r, "id") else r
                for r in raw_results
            ]
        else:
            # Server-side embedding in collection mode
            raw_results = self._collection_obj.search(  # type: ignore[union-attr]
                query=query, top_k=k, filter=filter
            )
            raw = [
                {"id": r.id, "score": r.score, "metadata": r.metadata, "text": r.text}
                if hasattr(r, "id")
                else r
                for r in raw_results
            ]

        results: List[Tuple[Document, float]] = []
        seen_ids: set = set()

        for item in raw:
            if isinstance(item, dict):
                doc_id = item.get("id", "")
                score = float(item.get("score", 0.0))
                text = item.get("text", item.get("content", ""))
                metadata = item.get("metadata", {})
                if metadata is None:
                    metadata = {}
                metadata["id"] = doc_id
            else:
                doc_id = getattr(item, "id", "")
                score = float(getattr(item, "score", 0.0))
                text = getattr(item, "text", getattr(item, "content", ""))
                metadata = getattr(item, "metadata", {}) or {}
                metadata["id"] = doc_id

            seen_ids.add(doc_id)
            results.append((
                Document(page_content=text, metadata=metadata),
                score,
            ))

        # Graph expansion: follow edges from top results
        if graph_expand and self._bucket is not None and results:
            expanded = self._graph_expand(
                seed_ids=[r[1] for r in [(doc.metadata.get("id"), s) for doc, s in results] if r[0]],
                seed_id_list=[doc.metadata.get("id", "") for doc, _ in results],
                seen=seen_ids,
                depth=graph_depth,
                relations=graph_relations,
                k=k,
            )
            results.extend(expanded)

        return results[:k] if not graph_expand else results

    def _graph_expand(
        self,
        seed_ids: List[Any],
        seed_id_list: List[str],
        seen: set,
        depth: int,
        relations: Optional[List[str]],
        k: int,
    ) -> List[Tuple[Document, float]]:
        """Expand results by traversing graph edges."""
        expanded: List[Tuple[Document, float]] = []
        frontier = [sid for sid in seed_id_list if sid]

        for _hop in range(depth):
            next_frontier: List[str] = []
            for node_id in frontier:
                try:
                    edges = self._bucket.list_edges(  # type: ignore[union-attr]
                        node_id=node_id, direction="both"
                    )
                except Exception:
                    continue

                for edge in edges:
                    target = edge.get("target", "") if edge.get("target") != node_id else edge.get("source", "")
                    if not target or target in seen:
                        continue
                    if relations and edge.get("relation") not in relations:
                        continue

                    seen.add(target)
                    next_frontier.append(target)

                    metadata = {
                        "id": target,
                        "edge_relation": edge.get("relation", ""),
                        "edge_source": edge.get("source", ""),
                        "edge_target": edge.get("target", ""),
                        "graph_expanded": True,
                    }
                    expanded.append((
                        Document(
                            page_content=edge.get("target_text", f"[node:{target}]"),
                            metadata=metadata,
                        ),
                        edge.get("weight", 0.5),
                    ))

            frontier = next_frontier

        return expanded

    def similarity_search_by_vector(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """Search by raw vector (collection mode only).

        Args:
            embedding: Query vector.
            k: Number of results.
            filter: Optional metadata filter.

        Returns:
            List of Documents.
        """
        if self._collection_obj is None:
            raise NotImplementedError(
                "similarity_search_by_vector requires collection mode. "
                "Bucket mode uses server-side embedding."
            )
        raw = self._collection_obj.search_by_vector(
            query_vector=embedding, top_k=k
        )
        results = []
        for item in raw:
            text = getattr(item, "text", getattr(item, "content", ""))
            metadata = getattr(item, "metadata", {}) or {}
            metadata["id"] = getattr(item, "id", "")
            results.append(Document(page_content=text, metadata=metadata))
        return results

    def delete(
        self,
        ids: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Optional[bool]:
        """Delete documents by IDs.

        Note: Full delete by ID requires bucket-level API support.
        """
        # Schift bucket delete removes the entire bucket; per-doc delete
        # would need to be implemented via the API.
        logger.warning(
            "Per-document delete is not yet supported in Schift. "
            "Use bucket.delete() to remove the entire bucket."
        )
        return None

    # -- Edge / Graph operations (Schift-unique) --

    def add_edges(
        self,
        edges: List[Dict[str, Any]],
    ) -> int:
        """Add edges between documents in the bucket.

        This is a Schift-unique feature not available in other vector stores.

        Args:
            edges: List of edge dicts with keys:
                - source: source document ID
                - target: target document ID
                - relation: one of contradicts, supersedes, caused_by,
                  is_a, related_to, has_child, follows
                - weight: optional float weight

        Returns:
            Number of edges added.

        Example:
            .. code-block:: python

                store.add_edges([
                    {"source": "doc1", "target": "doc2",
                     "relation": "supersedes", "weight": 1.0},
                ])
        """
        if self._bucket is None:
            raise NotImplementedError("add_edges requires bucket mode.")
        return self._bucket.add_edges(edges)

    def list_edges(
        self,
        node_id: str,
        direction: str = "both",
        relation: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List edges for a document node.

        Args:
            node_id: Document ID.
            direction: "both", "outgoing", or "incoming".
            relation: Optional filter by relation type.

        Returns:
            List of edge dicts.
        """
        if self._bucket is None:
            raise NotImplementedError("list_edges requires bucket mode.")
        return self._bucket.list_edges(
            node_id=node_id, direction=direction, relation=relation
        )

    def delete_edge(
        self,
        source: str,
        target: str,
        relation: str = "related_to",
    ) -> None:
        """Delete a specific edge between documents.

        Args:
            source: Source document ID.
            target: Target document ID.
            relation: Relation type.
        """
        if self._bucket is None:
            raise NotImplementedError("delete_edge requires bucket mode.")
        self._bucket.delete_edge(source=source, target=target, relation=relation)

    # -- Factory methods --

    @classmethod
    def from_texts(
        cls: Type["SchiftVectorStore"],
        texts: List[str],
        embedding: Optional[Embeddings] = None,  # type: ignore[override]
        metadatas: Optional[List[dict]] = None,
        ids: Optional[List[str]] = None,
        *,
        api_key: Optional[str] = None,
        bucket: Optional[str] = None,
        collection: Optional[str] = None,
        base_url: str = "https://embed.schift.io",
        **kwargs: Any,
    ) -> "SchiftVectorStore":
        """Create a SchiftVectorStore from a list of texts.

        Schift handles embedding server-side, so the ``embedding`` parameter
        is optional (unlike most LangChain vector stores).

        Args:
            texts: List of texts to add.
            embedding: Optional Embeddings (not required for bucket mode).
            metadatas: Optional metadata dicts.
            ids: Optional document IDs.
            api_key: Schift API key.
            bucket: Bucket name.
            collection: Collection name.
            base_url: API base URL.

        Returns:
            Initialized SchiftVectorStore with documents added.
        """
        store = cls(
            api_key=api_key,
            bucket=bucket,
            collection=collection,
            base_url=base_url,
            embedding=embedding,
        )
        store.add_texts(texts=texts, metadatas=metadatas, ids=ids)
        return store

    @classmethod
    def from_documents(
        cls: Type["SchiftVectorStore"],
        documents: List[Document],
        embedding: Optional[Embeddings] = None,  # type: ignore[override]
        *,
        api_key: Optional[str] = None,
        bucket: Optional[str] = None,
        collection: Optional[str] = None,
        base_url: str = "https://embed.schift.io",
        **kwargs: Any,
    ) -> "SchiftVectorStore":
        """Create from LangChain Documents.

        Args:
            documents: LangChain Document objects.
            embedding: Optional Embeddings (not required for bucket mode).
            api_key: Schift API key.
            bucket: Bucket name.
            collection: Collection name.
            base_url: API base URL.

        Returns:
            Initialized SchiftVectorStore with documents added.
        """
        texts = [doc.page_content for doc in documents]
        metadatas = [doc.metadata for doc in documents]
        return cls.from_texts(
            texts=texts,
            embedding=embedding,
            metadatas=metadatas,
            api_key=api_key,
            bucket=bucket,
            collection=collection,
            base_url=base_url,
            **kwargs,
        )

    def _select_relevance_score_fn(self) -> Callable[[float], float]:
        if self._relevance_score_fn:
            return self._relevance_score_fn
        # Schift returns cosine similarity scores (higher = more similar)
        return lambda score: score
